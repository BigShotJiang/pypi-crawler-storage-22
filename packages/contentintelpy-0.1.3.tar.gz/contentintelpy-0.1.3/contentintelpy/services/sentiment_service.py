from ..nodes.sentiment_node import SentimentNode
from ..pipeline.context import PipelineContext
from typing import Dict, Any

class SentimentService:
    """
    Service-first wrapper for Sentiment Analysis.
    Simplifies usage to a single method call.
    """
    def __init__(self):
        self.node = SentimentNode()

    def analyze(self, text: str) -> Dict[str, Any]:
        """
        Analyze the sentiment of the text.
        
        Args:
            text: Input text (English preferred for best accuracy, but multilingual supported via Node labels)
            
        Returns:
            Dict containing 'value', 'value_en', 'confidence'.
        """
        if not text:
            return {}

        # Create ad-hoc context
        context = PipelineContext({"text": text, "language": "en"})
        
        # Execute Node
        # We manually run the node. The node handles errors internally by logging/soft-failing.
        context = self.node.run(context)
        
        # Return the specific output or empty dict if failed
        return context.get("sentiment", {})
