from ..nodes.summarization_node import SummarizationNode
from ..pipeline.context import PipelineContext
from typing import Optional

class SummarizationService:
    """
    Service-first wrapper for Summarization.
    """
    def __init__(self, max_length: int = 130, min_length: int = 30):
        self.node = SummarizationNode(max_length=max_length, min_length=min_length)

    def summarize(self, text: str) -> str:
        """
        Generate a summary of the text.
        
        Returns:
            Summary string.
        """
        if not text:
            return ""

        context = PipelineContext({"text": text})
        context = self.node.run(context)
        
        return context.get("summary", "")
