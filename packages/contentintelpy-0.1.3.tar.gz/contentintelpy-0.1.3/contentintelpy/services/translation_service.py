from ..nodes.translation_node import TranslationNode
from ..pipeline.context import PipelineContext
from typing import Optional

class TranslationService:
    """
    Service-first wrapper for Translation.
    Allows quick translation of text to any target language.
    """
    def __init__(self):
        # We don't init node here because target_lang changes per request often,
        # or we default to 'en'.
        pass

    def translate(self, text: str, target: str = "en", source: str = "unknown") -> str:
        """
        Translate text.
        
        Args:
            text: Content to translate.
            target: Target language code (default 'en').
            source: Source language code (optional, optimizations if provided).
        
        Returns:
            Translated string. Returns original if failed.
        """
        if not text:
            return ""

        node = TranslationNode(target_lang=target)
        context = PipelineContext({
            "text": text,
            "language": source
        })
        
        context = node.run(context)
        
        return context.get("text_translated", text)
