import importlib
import logging

logger = logging.getLogger("contentintelpy.utils")

def ensure_dependency(module_name: str, extra_name: str):
    """
    Attempts to import a module. If it fails, raises an ImportError with a 
    helpful message directing the user to install the appropriate optional extra.
    """
    try:
        return importlib.import_module(module_name)
    except (ImportError, ModuleNotFoundError):
        msg = f"Missing optional dependency '{module_name}'. To use this feature, please install it using: pip install \"contentintelpy[{extra_name}]\""
        logger.error(msg)
        raise ImportError(msg) from None
