from .lazy_import import ensure_dependency
import logging
import threading
from typing import Any, Optional
import warnings

# Suppress HuggingFace warnings for cleaner logs
warnings.filterwarnings("ignore", category=UserWarning)

logger = logging.getLogger("contentintelpy.registry")

class ModelRegistry:
    """
    Centralized registry for ML models.
    Implements:
    - Singleton access
    - Lazy loading (models load only when requested)
    - Thread safety (locks for concurrent access)
    - Caching
    """
    _instance = None
    _lock = threading.Lock()
    _models = {}

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(ModelRegistry, cls).__new__(cls)
        return cls._instance

    def _load_if_missing(self, key: str, loader_func: callable) -> Any:
        """
        Generic thread-safe lazy loader.
        """
        if key not in self._models:
            with self._lock:
                # Double-check inside lock
                if key not in self._models:
                    try:
                        logger.info(f"Loading resource '{key}'... (This may take a moment)")
                        self._models[key] = loader_func()
                        logger.info(f"Successfully loaded '{key}'.")
                    except Exception as e:
                        logger.error(f"Failed to load '{key}': {e}")
                        raise e
        return self._models[key]

    # --------------------------------------------------------------------------
    # Sentiment Analysis (RoBERTa)
    # --------------------------------------------------------------------------
    def get_sentiment_pipeline(self):
        def _loader():
            ensure_dependency("transformers", "core")
            ensure_dependency("torch", "core")
            from transformers import pipeline
            # Use a high-quality multilingual or English sentiment model
            # CardiffNLP is standard for Twitter-like text, widely used
            model_name = "cardiffnlp/twitter-roberta-base-sentiment-latest"
            return pipeline("sentiment-analysis", model=model_name, tokenizer=model_name, top_k=None)
        
        return self._load_if_missing("sentiment", _loader)

    # --------------------------------------------------------------------------
    # Translation (NLLB - GPU/Heavy)
    # --------------------------------------------------------------------------
    def get_translation_pipeline(self):
        def _loader():
            ensure_dependency("transformers", "core")
            from transformers import pipeline
            # NLLB-200 Distilled (600M) is a good balance of size/quality
            model_name = "facebook/nllb-200-distilled-600M"
            return pipeline("translation", model=model_name, tokenizer=model_name)
        
        return self._load_if_missing("translation_nllb", _loader)

    # --------------------------------------------------------------------------
    # NER (GLiNER)
    # --------------------------------------------------------------------------
    def get_gliner_model(self):
        def _loader():
            ensure_dependency("gliner", "ner")
            from gliner import GLiNER
            # Standard GLiNER model
            return GLiNER.from_pretrained("urchade/gliner_large-v2.1")
        
        return self._load_if_missing("ner_gliner", _loader)

    # --------------------------------------------------------------------------
    # Zero-Shot Classification (BART)
    # --------------------------------------------------------------------------
    def get_classifier_pipeline(self):
        def _loader():
            ensure_dependency("transformers", "core")
            from transformers import pipeline
            return pipeline("zero-shot-classification", model="facebook/bart-large-mnli")
        
        return self._load_if_missing("classification_bart", _loader)

    # --------------------------------------------------------------------------
    # Summarization (BART)
    # --------------------------------------------------------------------------
    def get_summarization_pipeline(self):
        def _loader():
            ensure_dependency("transformers", "core")
            from transformers import pipeline
            return pipeline("summarization", model="facebook/bart-large-cnn")
        
        return self._load_if_missing("summarization", _loader)

    # --------------------------------------------------------------------------
    # Language Detection (Transformers)
    # --------------------------------------------------------------------------
    def get_language_detector(self):
        def _loader():
            ensure_dependency("transformers", "core")
            from transformers import pipeline
            return pipeline("text-classification", model="qanastek/51-languages-classifier")
        
        return self._load_if_missing("language_detection", _loader)

    # --------------------------------------------------------------------------
    # Keyword Extraction (Embeddings)
    # --------------------------------------------------------------------------
    def get_embedding_model(self):
        def _loader():
            ensure_dependency("sentence_transformers", "core")
            from sentence_transformers import SentenceTransformer
            # Fast, effective embedding model for semantic similarity
            return SentenceTransformer('all-MiniLM-L6-v2')
        
        return self._load_if_missing("keywords_embedding", _loader)

# Global accessor
registry = ModelRegistry()
