# Changelog

All notable changes to ContextGuard are documented in this file.

This project follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html) and the format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [0.1.0] - 2026-02-13

Initial public release of ContextGuard, published on PyPI as [`contextguard-ai`](https://pypi.org/project/contextguard-ai/).

### Added

**Core Detection Modules**
- Prompt injection detection with rule-based regex scanning and optional embedding-based semantic analysis.
- Secret scanning for API keys, credentials, JWT tokens, RSA private keys, database URLs, and 16+ other patterns.
- PII detection covering emails, phone numbers, credit card numbers (Luhn-validated), Social Security numbers, and IP addresses.

**Analysis and Scoring**
- Dependency auditing via the OSV vulnerability database, PyPI freshness checks, and typosquatting warnings.
- Weighted risk scoring engine with configurable weights and thresholds for injection, secrets, PII, and entropy.

**Developer Tools**
- `Guard` API with `scan()`, `sanitize()`, and `score()` as the primary interface.
- `GuardedLLM` middleware wrapper for OpenAI and Anthropic APIs with automatic scanning, sanitization, and logging.
- Audit logging to JSON lines and SQLite with structured event tracking.
- CLI with `contextguard scan`, `contextguard audit`, and `contextguard report` commands.

**Quality**
- Comprehensive test suite with 92 unit tests covering all modules.
- Optional extras for spaCy NER-based PII detection and sentence-transformers-based semantic injection detection.

### Known Limitations

- Embedding-based injection detection is optional and trades accuracy for speed on systems without GPU acceleration.
- OSV API lookups during dependency auditing may be slow on the first run while the cache is cold.
- Fine-tuned detection rules are not yet persisted between sessions.

---

## Roadmap

Planned for future releases:

- FastAPI and Django middleware plugins
- Real-time monitoring dashboard
- CI/CD integration for GitHub Actions and GitLab pipelines
- Adaptive ML-based injection detection
- Prompt mutation attack resistance
- Context-aware AI firewall capabilities


## [0.1.1] - 2026-02-13
**Code Quality**
- Refactored internal detection module interfaces for better maintainability and reduced code duplication.
- Optimized dependency analyzer to batch OSV API requests, decreasing audit times on large `requirements.txt` files.
