# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in ContextGuard, please **do not** open a public GitHub issue. Responsible disclosure helps protect users while the issue is being fixed.

Instead, report it by emailing **jasht.developer+contextguard** or by opening a private security advisory through GitHub's Security tab on this repository.

### What to include in your report

- A clear description of the vulnerability and its potential impact.
- Steps to reproduce the issue, if applicable.
- Any suggested fixes or patches you may have.

### What to expect from us

- We will acknowledge your report within **48 hours**.
- We will provide a status update within **5 business days**.
- We will work with you on a responsible disclosure timeline.
- We will credit you in the advisory unless you prefer to remain anonymous.

---

## Scope

The following categories of issues are considered in scope for security reports:

- **Input validation bypasses** - Techniques that evade injection detection, secret scanning, or PII identification.
- **Information disclosure** - Unintended exposure of audit logs, scan results, or internal state.
- **Denial of service** - Inputs that cause excessive memory use, CPU consumption, or crashes.
- **Cryptographic weaknesses** - If any cryptographic operations are introduced in the future.
- **Dependency vulnerabilities** - Known CVEs in packages that ContextGuard directly depends on. We will update as quickly as possible.

## Out of Scope

The following are not considered security vulnerabilities in ContextGuard:

- Social engineering or phishing attacks.
- Physical security concerns.
- Bugs in third-party libraries that ContextGuard does not directly control. Please report those to the upstream maintainers.
- Design limitations that are documented, such as the inherent accuracy ceiling of regex-based detection compared to ML-based approaches.

---

## Security Best Practices for Users

When deploying ContextGuard in production, keep these recommendations in mind:

- **Review detected categories** in every `ScanResult`. They tell you exactly what type of risk was found and help you decide how to respond.
- **Set an appropriate block threshold** for your application. The default of 0.9 is conservative. Tighten it if your use case demands stricter filtering.
- **Monitor audit logs regularly** and look for patterns that may indicate adversarial probing.
- **Keep the package updated** by running `pip install --upgrade contextguard-ai` periodically.
- **Test with realistic prompts** from your actual user base before deploying to production. Detection patterns tuned to generic attacks may need adjustment for your domain.

---

Thank you for helping keep ContextGuard and its users safe.
