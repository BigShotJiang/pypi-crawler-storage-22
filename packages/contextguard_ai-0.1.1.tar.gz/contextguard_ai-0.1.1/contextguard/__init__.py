"""ContextGuard — Runtime security and auditing middleware for LLM-powered applications."""

__version__ = "0.1.0"

from contextguard.guard import Guard, ScanResult
from contextguard.scoring import RiskLevel

__all__ = ["Guard", "ScanResult", "RiskLevel"]
