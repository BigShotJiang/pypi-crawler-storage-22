"""Secret Detection Module.

Detects sensitive credentials and secrets in text using regex patterns
and Shannon entropy analysis.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import List, Optional

# ---------------------------------------------------------------------------
# Secret patterns:  (label, regex, severity)
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[tuple[str, re.Pattern, float]] = [
    (
        "aws_access_key",
        re.compile(r"(?<![A-Za-z0-9/+])(AKIA[0-9A-Z]{16})(?![A-Za-z0-9/+=])"),
        1.0,
    ),
    (
        "aws_secret_key",
        re.compile(r"(?<![A-Za-z0-9/+])([A-Za-z0-9/+=]{40})(?![A-Za-z0-9/+=])"),
        0.5,  # lower base — entropy check elevates it
    ),
    (
        "openai_api_key",
        re.compile(r"(sk-[A-Za-z0-9]{20,})"),
        1.0,
    ),
    (
        "anthropic_api_key",
        re.compile(r"(sk-ant-[A-Za-z0-9\-]{20,})"),
        1.0,
    ),
    (
        "stripe_secret_key",
        re.compile(r"(sk_live_[A-Za-z0-9]{20,})"),
        1.0,
    ),
    (
        "stripe_publishable_key",
        re.compile(r"(pk_live_[A-Za-z0-9]{20,})"),
        0.7,
    ),
    (
        "jwt_token",
        re.compile(r"(eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})"),
        0.9,
    ),
    (
        "rsa_private_key",
        re.compile(r"-----BEGIN (RSA |EC )?PRIVATE KEY-----"),
        1.0,
    ),
    (
        "database_url",
        re.compile(
            r"(postgres(ql)?|mysql|mongodb(\+srv)?|redis|sqlite):\/\/[^\s\"']{10,}",
            re.IGNORECASE,
        ),
        0.9,
    ),
    (
        "github_token",
        re.compile(r"(ghp_[A-Za-z0-9]{20,}|gho_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})"),
        1.0,
    ),
    (
        "google_api_key",
        re.compile(r"AIza[0-9A-Za-z\-_]{35}"),
        0.9,
    ),
    (
        "slack_token",
        re.compile(r"xox[bposatr]-[0-9A-Za-z\-]{10,}"),
        0.9,
    ),
    (
        "generic_secret_assignment",
        re.compile(
            r"""(?:password|passwd|pwd|secret|token|api_key|apikey|access_key)"""
            r"""\s*[=:]\s*['"][^\s'"]{8,}['"]""",
            re.IGNORECASE,
        ),
        0.6,
    ),
]

# Entropy threshold — random hex/base64 strings tend to be ≥ 3.5
_ENTROPY_THRESHOLD = 3.5
_HIGH_ENTROPY_THRESHOLD = 4.5


def _shannon_entropy(data: str) -> float:
    """Calculate Shannon entropy of a string."""
    if not data:
        return 0.0
    freq: dict[str, int] = {}
    for ch in data:
        freq[ch] = freq.get(ch, 0) + 1
    length = len(data)
    return -sum((c / length) * math.log2(c / length) for c in freq.values())


@dataclass
class SecretMatch:
    """A single secret detection match."""

    label: str
    matched_text: str
    severity: float
    entropy: float
    start: int
    end: int
    redacted: str = ""

    def __post_init__(self) -> None:
        if not self.redacted:
            self.redacted = self._redact(self.matched_text)

    @staticmethod
    def _redact(text: str, visible: int = 4) -> str:
        if len(text) <= visible * 2:
            return "***"
        return text[:visible] + "***" + text[-visible:]


@dataclass
class SecretResult:
    """Result of secret scanning."""

    is_detected: bool = False
    score: float = 0.0
    matches: List[SecretMatch] = field(default_factory=list)

    @property
    def labels(self) -> list[str]:
        return [m.label for m in self.matches]

    @property
    def redaction_map(self) -> dict[str, str]:
        """Map of original text → redacted text for sanitization."""
        return {m.matched_text: m.redacted for m in self.matches}


class SecretDetector:
    """Detects secrets, API keys, and credentials in text."""

    def __init__(
        self,
        custom_patterns: Optional[list[tuple[str, str, float]]] = None,
        entropy_threshold: float = _ENTROPY_THRESHOLD,
    ) -> None:
        self._patterns = list(_SECRET_PATTERNS)
        if custom_patterns:
            for label, pattern, severity in custom_patterns:
                self._patterns.append((label, re.compile(pattern), severity))
        self._entropy_threshold = entropy_threshold

    # ------------------------------------------------------------------
    # High-entropy token scanner
    # ------------------------------------------------------------------

    def _scan_entropy(self, text: str) -> list[SecretMatch]:
        """Find high-entropy tokens that look like secrets."""
        matches: list[SecretMatch] = []
        # Split on whitespace and common delimiters
        token_re = re.compile(r"[A-Za-z0-9+/=_\-]{16,}")
        for m in token_re.finditer(text):
            token = m.group()
            ent = _shannon_entropy(token)
            if ent >= _HIGH_ENTROPY_THRESHOLD:
                matches.append(
                    SecretMatch(
                        label="high_entropy_string",
                        matched_text=token,
                        severity=min(1.0, ent / 6.0),
                        entropy=round(ent, 3),
                        start=m.start(),
                        end=m.end(),
                    )
                )
        return matches

    # ------------------------------------------------------------------
    # Main API
    # ------------------------------------------------------------------

    def detect(self, text: str) -> SecretResult:
        """Scan *text* for secrets and high-entropy strings."""
        matches: list[SecretMatch] = []
        seen_spans: set[tuple[int, int]] = set()

        # Pattern-based detection
        for label, pattern, severity in self._patterns:
            for m in pattern.finditer(text):
                span = (m.start(), m.end())
                if span in seen_spans:
                    continue
                seen_spans.add(span)
                matched = m.group()
                ent = _shannon_entropy(matched)
                # Boost severity if entropy is high
                effective_severity = min(1.0, severity + (0.2 if ent > self._entropy_threshold else 0.0))
                matches.append(
                    SecretMatch(
                        label=label,
                        matched_text=matched,
                        severity=effective_severity,
                        entropy=round(ent, 3),
                        start=m.start(),
                        end=m.end(),
                    )
                )

        # Also scan for high-entropy strings not caught by patterns
        entropy_matches = self._scan_entropy(text)
        for em in entropy_matches:
            span = (em.start, em.end)
            if span not in seen_spans:
                seen_spans.add(span)
                matches.append(em)

        # Score: max severity found
        score = max((m.severity for m in matches), default=0.0)

        return SecretResult(
            is_detected=len(matches) > 0,
            score=round(score, 4),
            matches=matches,
        )

    def entropy(self, text: str) -> float:
        """Return Shannon entropy of the entire text (convenience method)."""
        return round(_shannon_entropy(text), 4)
