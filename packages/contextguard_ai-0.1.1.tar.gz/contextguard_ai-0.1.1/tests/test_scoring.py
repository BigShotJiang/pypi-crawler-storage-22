"""Tests for the Risk Scoring Engine."""

from contextguard.scoring import RiskLevel, RiskScorer, RiskThresholds, RiskWeights


class TestRiskScorer:
    """Test suite for RiskScorer."""

    def test_zero_scores(self):
        scorer = RiskScorer()
        score, level = scorer.compute()
        assert score == 0.0
        assert level == RiskLevel.LOW

    def test_high_injection_only(self):
        scorer = RiskScorer()
        score, level = scorer.compute(injection_score=1.0)
        assert score == 0.4
        assert level == RiskLevel.MEDIUM

    def test_all_max(self):
        scorer = RiskScorer()
        score, level = scorer.compute(
            injection_score=1.0,
            secret_score=1.0,
            pii_score=1.0,
            entropy_score=1.0,
        )
        assert score == 1.0
        assert level == RiskLevel.HIGH

    def test_custom_weights(self):
        weights = RiskWeights(injection=1.0, secret=0.0, pii=0.0, entropy=0.0)
        scorer = RiskScorer(weights=weights)
        score, _ = scorer.compute(injection_score=0.5)
        assert score == 0.5

    def test_custom_thresholds(self):
        thresholds = RiskThresholds(low_max=0.1, high_min=0.5)
        scorer = RiskScorer(thresholds=thresholds)
        _, level = scorer.compute(injection_score=0.4)
        # 0.4 * 0.4 = 0.16 → medium (between 0.1 and 0.5)
        assert level == RiskLevel.MEDIUM

    def test_weight_normalization(self):
        # Weights don't sum to 1 — should be normalised
        weights = RiskWeights(injection=2.0, secret=2.0, pii=2.0, entropy=2.0)
        scorer = RiskScorer(weights=weights)
        score, _ = scorer.compute(
            injection_score=1.0,
            secret_score=1.0,
            pii_score=1.0,
            entropy_score=1.0,
        )
        assert abs(score - 1.0) < 0.01

    def test_risk_levels(self):
        scorer = RiskScorer()
        _, low = scorer.compute(injection_score=0.1)
        _, med = scorer.compute(injection_score=0.5, secret_score=0.5)
        _, high = scorer.compute(injection_score=1.0, secret_score=1.0, pii_score=1.0)
        assert low == RiskLevel.LOW
        assert med == RiskLevel.MEDIUM
        assert high == RiskLevel.HIGH

    def test_score_clamped(self):
        scorer = RiskScorer()
        score, _ = scorer.compute(
            injection_score=2.0,
            secret_score=2.0,
            pii_score=2.0,
            entropy_score=2.0,
        )
        assert score <= 1.0
