"""Tests for the Secret Detection Module."""

import pytest
from contextguard.secrets import SecretDetector, _shannon_entropy


@pytest.fixture
def detector():
    return SecretDetector()


class TestSecretDetector:
    """Test suite for SecretDetector."""

    def test_clean_text(self, detector):
        result = detector.detect("Hello, how are you today?")
        assert not result.is_detected
        assert result.score == 0.0

    def test_aws_access_key(self, detector):
        result = detector.detect("My key is AKIAIOSFODNN7EXAMPLE")
        assert result.is_detected
        assert "aws_access_key" in result.labels

    def test_openai_key(self, detector):
        result = detector.detect("Use this key: sk-abcdefghijklmnopqrstuvwxyz123456")
        assert result.is_detected
        assert "openai_api_key" in result.labels

    def test_stripe_key(self, detector):
        result = detector.detect("sk_live_abcdefghijklmnopqrstuvwxyz")
        assert result.is_detected
        assert "stripe_secret_key" in result.labels

    def test_jwt_token(self, detector):
        jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
        result = detector.detect(f"Token: {jwt}")
        assert result.is_detected
        assert "jwt_token" in result.labels

    def test_rsa_private_key(self, detector):
        result = detector.detect("-----BEGIN RSA PRIVATE KEY-----\nMIIE...")
        assert result.is_detected
        assert "rsa_private_key" in result.labels

    def test_database_url(self, detector):
        result = detector.detect("DATABASE_URL=postgresql://user:pass@localhost:5432/db")
        assert result.is_detected
        assert "database_url" in result.labels

    def test_github_token(self, detector):
        result = detector.detect("ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh")
        assert result.is_detected
        assert "github_token" in result.labels

    def test_generic_secret_assignment(self, detector):
        result = detector.detect('password = "supersecretpassword123"')
        assert result.is_detected
        assert "generic_secret_assignment" in result.labels

    def test_multiple_secrets(self, detector):
        text = (
            "AWS: AKIAIOSFODNN7EXAMPLE\n"
            "OpenAI: sk-abcdefghijklmnopqrstuvwxyz123456\n"
        )
        result = detector.detect(text)
        assert result.is_detected
        assert len(result.matches) >= 2

    def test_redaction_map(self, detector):
        result = detector.detect("AKIAIOSFODNN7EXAMPLE")
        assert result.redaction_map
        for original, redacted in result.redaction_map.items():
            assert "***" in redacted

    def test_entropy_method(self, detector):
        # High entropy strings
        assert detector.entropy("aB3$xZ9!qW2@kL7") > 3.0
        # Low entropy strings
        assert detector.entropy("aaaaaaaaaa") < 1.0


class TestShannonEntropy:
    def test_empty_string(self):
        assert _shannon_entropy("") == 0.0

    def test_single_char(self):
        assert _shannon_entropy("aaaa") == 0.0

    def test_high_entropy(self):
        assert _shannon_entropy("aB3$xZ9!qW2@") > 3.0
