# ContiPay Python SDK

Official Python SDK for ContiPay payments.

## Installation
```bash
pip install contipay


from contipay import Card, Mobile

card = Card("API_KEY", "API_SECRET")



---

# 3️⃣ `LICENSE` (REQUIRED)

```text
MIT License

Copyright (c) 2026 ContiPay

Permission is hereby granted, free of charge, to any person obtaining a copy...
