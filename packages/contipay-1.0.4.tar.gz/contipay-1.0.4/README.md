# ContiPay Python SDK

Official **ContiPay Python SDK** for processing **Mobile Money** and **Card Payments**.

This SDK provides a clean, secure, and flexible way to integrate ContiPay payment services into your Python applications.

---

## ✨ Features

- 📱 Mobile payments: **EcoCash, OneMoney, Omari, InnBucks**
- 💳 Card payments: **Visa, MasterCard, ZimSwitch**
- 🌍 Supports **Dev** and **Live** environments
- 🔁 **Direct** and **Redirect** payment flows
- 🔐 Secure API key authentication
- 🐍 Pythonic, chainable API design

---

## 📦 Installation

Install from PyPI:

```bash
pip install contipay


```


## 🚀 Quick Start
Import & Credentials

```bash

from contipay import Card, Mobile

API_KEY = "your_api_key"
API_SECRET = "your_api_secret"
MERCHANT_ID = 123

```

## 💳 Full Card Payment Example (Visa)

```bash

from contipay import Card, Mobile

API_KEY = "your_api_key"
API_SECRET = "your_api_secret"
MERCHANT_ID = 123

card = (
    Card(API_KEY, API_SECRET, mode="dev")
    .set_urls(
        callback="https://webhook.site/your-test-id",
        success="https://example.com/success",
        error="https://example.com/error"
    )
)

card_payload = {
    "customer": {
        "nationalId": "00000000",
        "surname": "Doe",
        "firstName": "John",
        "middleName": "",
        "email": "john.doe@example.com",
        "cell": "0770000000",
        "countryCode": "ZW"
    },
    "transaction": {
        "providerCode": "VA",
        "providerName": "VISA",
        "currencyCode": "USD",
        "merchantId": MERCHANT_ID,
        "reference": "PYT_121",
        "description": "Payment for Order #1631",
        "amount": 100.00,
        "webhookUrl": "https://yoursite.com/webhook",
        "successUrl": "https://yoursite.com/success",
        "cancelUrl": "https://yoursite.com/cancel"
    },
    "accountDetails": {
        "accountNumber": "5123450000000008",
        "accountName": "John Doe",
        "accountExtra": {
            "code": "123",
            "expiry": "12/2030"
        }
    }
}

print(card.pay("visa", card_payload))

```

## 📱 Full Mobile Payment Example (EcoCash)

```bash

from contipay import Card, Mobile

API_KEY = "your_api_key"
API_SECRET = "your_api_secret"
MERCHANT_ID = 123


mobile = (
    Mobile(API_KEY, API_SECRET, mode="dev")
    .set_callback("https://webhook.site/your-test-id")
)

mobile_payload = {
    "customer": {
        "nationalId": "00000000",
        "surname": "Doe",
        "firstName": "John",
        "middleName": "",
        "email": "john.doe@example.com",
        "cell": "0771234567",
        "countryCode": "ZW"
    },
    "transaction": {
        "providerCode": "EC",
        "providerName": "EcoCash",
        "currencyCode": "USD",
        "merchantId": MERCHANT_ID,
        "reference": "PYT_11",
        "description": "Payment for Order #1631",
        "amount": 100.00,
        "webhookUrl": "https://yoursite.com/webhook",
        "successUrl": "https://yoursite.com/success",
        "cancelUrl": "https://yoursite.com/cancel"
    },
    "accountDetails": {
        "accountNumber": "0771234567",
        "accountName": "John Doe"
    }
}

print(mobile.pay("ecocash", mobile_payload))

```

## ⚙️ Configuration
## Core Classes

The SDK exposes two main classes:

-> Mobile – Mobile money payments

-> Card – Card payments

## Basic Setup

```bash
from contipay import Card, Mobile

card = (
    Card(API_KEY, API_SECRET, mode="dev")
    .set_urls(
        callback="https://webhook.site/your-test-id",
        success="https://example.com/success",
        error="https://example.com/error"
    )
)

mobile = (
    Mobile(API_KEY, API_SECRET, mode="dev")
    .set_callback("https://webhook.site/your-test-id")
)

```


## 📲 Mobile Payments
##    Supported Providers

✅ EcoCash

✅ OneMoney

✅ Omari

✅ InnBucks

Provider selection is done using the provider name or code when calling pay().

## 🔐 Security

All API requests are encrypted using TLS

Sensitive customer data is never logged

API credentials are required for every request
