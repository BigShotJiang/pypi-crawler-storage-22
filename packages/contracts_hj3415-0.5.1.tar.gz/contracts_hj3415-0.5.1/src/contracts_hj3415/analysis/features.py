# contracts_hj3415/analysis/features.py
from __future__ import annotations

from typing import Any, Literal, TypedDict

from contracts_hj3415.nfs.types import Endpoint, MetricKey

AggKind = Literal["sum", "avg"]
PeriodKind = Literal["y", "q"]


class FeatureValue(TypedDict):
    value: float | None
    picked: str | None
    from_kind: PeriodKind | None


class MetricDiagnostics(TypedDict):
    ok: bool
    reason: str | None
    details: dict[str, Any]  # pyright: ignore[reportExplicitAny]


class LatestAndTtm(TypedDict):
    latest_y: FeatureValue
    latest_q: FeatureValue
    ttm_q: FeatureValue
    chosen: FeatureValue
    diag: MetricDiagnostics


class FeaturesPayload(TypedDict):
    service: Literal["features"]
    endpoint: Endpoint
    blocks: dict[MetricKey, LatestAndTtm]
