# contracts_hj3415/analysis/payloads.py
from __future__ import annotations

from typing import TypeAlias

from contracts_hj3415.analysis.features import FeaturesPayload

AnalysisPayloadDTO: TypeAlias = FeaturesPayload
