# contracts_hj3415/analysis/types.py
from __future__ import annotations

from typing import Literal, TypeAlias

AnalysisService: TypeAlias = Literal[
    "features",
    "red",
]
