# contracts_hj3415/common/envelope.py
from __future__ import annotations

from datetime import datetime
from typing import Literal, TypedDict

from contracts_hj3415.analysis.payloads import AnalysisPayloadDTO
from contracts_hj3415.common.types import CodeKey, EnvelopeMeta, Source

# topic별 payload 유니온
from contracts_hj3415.nfs.payloads import NfsPayloadDTO
from contracts_hj3415.universe.payloads import UniversePayloadDTO
from contracts_hj3415.universe.types import Universe


class NfsEnvelopeDTO(TypedDict):
    topic: Literal["nfs"]
    key: CodeKey
    asof: datetime
    payload: NfsPayloadDTO
    meta: EnvelopeMeta


class UniverseEnvelopeDTO(TypedDict):
    topic: Literal["universe"]
    key: Universe
    asof: datetime
    payload: UniversePayloadDTO
    meta: EnvelopeMeta


class AnalysisEnvelopeDTO(TypedDict):
    topic: Literal["analysis"]
    key: CodeKey
    asof: datetime
    payload: AnalysisPayloadDTO
    meta: EnvelopeMeta


def _make_empty_envelope_meta(source: Source = "") -> EnvelopeMeta:
    return {"source": source, "trace_id": "", "note": "", "tags": []}


# ---------- topic별 convenience wrappers ----------


def make_nfs_envelope(
    *,
    key: CodeKey,
    asof: datetime,
    payload: NfsPayloadDTO,
    meta: EnvelopeMeta | None = None,
) -> NfsEnvelopeDTO:
    return {
        "topic": "nfs",
        "key": key,
        "asof": asof,
        "payload": payload,
        "meta": meta or _make_empty_envelope_meta("scraper2"),
    }


def make_universe_envelope(
    *,
    key: Universe,
    asof: datetime,
    payload: UniversePayloadDTO,
    meta: EnvelopeMeta | None = None,
) -> UniverseEnvelopeDTO:
    return {
        "topic": "universe",
        "key": key,
        "asof": asof,
        "payload": payload,
        "meta": meta or _make_empty_envelope_meta("krx"),
    }


def make_analysis_envelope(
    *,
    key: str,
    asof: datetime,
    payload: AnalysisPayloadDTO,
    meta: EnvelopeMeta | None = None,
) -> AnalysisEnvelopeDTO:
    return {
        "topic": "analysis",
        "key": key,
        "asof": asof,
        "payload": payload,
        "meta": meta or _make_empty_envelope_meta("analyser2"),
    }
