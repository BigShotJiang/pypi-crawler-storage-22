# contracts_hj3415/common/types.py
from __future__ import annotations

from typing import Literal, TypeAlias, TypedDict

Topic: TypeAlias = Literal["nfs", "universe", "analysis"]

CodeKey: TypeAlias = str

Num: TypeAlias = float | int | None

Source: TypeAlias = Literal["", "scraper2", "krx", "analyser2"]


class EnvelopeMeta(TypedDict, total=False):
    source: Source
    trace_id: str
    note: str
    tags: list[str]
