# contracts_hj3415/nfs/c101.py
from __future__ import annotations

from typing import Any, Literal, TypeAlias

from contracts_hj3415.common.types import Num
from typing_extensions import TypedDict

from .types import MetricKey, PeriodKey

Scalar: TypeAlias = str | float | int | None
ValuesMap: TypeAlias = dict[PeriodKey, Num]


class C101Blocks(TypedDict):
    요약: dict[str, Scalar]
    시세: dict[str, Scalar]
    주주현황: list[dict[str, Scalar]]
    기업개요: dict[str, Scalar]
    펀더멘털: dict[MetricKey, ValuesMap]

    어닝서프라이즈: dict[str, Any]  # pyright: ignore[reportExplicitAny]
    연간컨센서스: dict[MetricKey, ValuesMap]


class C101Payload(TypedDict):
    endpoint: Literal["c101"]
    blocks: C101Blocks
