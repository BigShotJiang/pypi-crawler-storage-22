# contracts_hj3415/nfs/c103.py
from __future__ import annotations

from typing import Literal, TypeAlias

from contracts_hj3415.common.types import Num
from typing_extensions import TypedDict

from .types import MetricKey, PeriodKey

C103ValuesMap: TypeAlias = dict[PeriodKey, Num]


class C103Blocks(TypedDict):
    손익계산서y: dict[MetricKey, C103ValuesMap]
    손익계산서q: dict[MetricKey, C103ValuesMap]
    재무상태표y: dict[MetricKey, C103ValuesMap]
    재무상태표q: dict[MetricKey, C103ValuesMap]
    현금흐름표y: dict[MetricKey, C103ValuesMap]
    현금흐름표q: dict[MetricKey, C103ValuesMap]


class C103Labels(TypedDict):
    손익계산서y: dict[MetricKey, str]
    손익계산서q: dict[MetricKey, str]
    재무상태표y: dict[MetricKey, str]
    재무상태표q: dict[MetricKey, str]
    현금흐름표y: dict[MetricKey, str]
    현금흐름표q: dict[MetricKey, str]


class C103Payload(TypedDict):
    endpoint: Literal["c103"]
    blocks: C103Blocks
    labels: C103Labels
