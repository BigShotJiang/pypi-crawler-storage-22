# contracts_hj3415/nfs/c108.py
from __future__ import annotations

from typing import Literal, TypeAlias

from typing_extensions import TypedDict

from .types import MetricKey

C108ValuesMap: TypeAlias = dict[MetricKey, str | int | None]


class C108Blocks(TypedDict):
    리포트: list[C108ValuesMap]


class C108Payload(TypedDict):
    endpoint: Literal["c108"]
    blocks: C108Blocks
