# contracts_hj3415/nfs/payloads.py
from __future__ import annotations

from typing import TypeAlias

from contracts_hj3415.nfs.c101 import C101Payload
from contracts_hj3415.nfs.c103 import C103Payload
from contracts_hj3415.nfs.c104 import C104Payload
from contracts_hj3415.nfs.c106 import C106Payload
from contracts_hj3415.nfs.c108 import C108Payload

NfsPayloadDTO: TypeAlias = (
    C101Payload | C103Payload | C104Payload | C106Payload | C108Payload
)
