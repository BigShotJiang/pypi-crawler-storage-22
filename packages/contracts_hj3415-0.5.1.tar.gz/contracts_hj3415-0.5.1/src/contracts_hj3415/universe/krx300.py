# contracts_hj3415/universe/dto.py
from __future__ import annotations

from typing import Any, TypedDict

from contracts_hj3415.common.types import CodeKey
from contracts_hj3415.universe.types import Universe


class UniverseItem(TypedDict, total=False):
    code: CodeKey
    name: str
    market: str
    meta: dict[str, Any]  # pyright: ignore[reportExplicitAny]


class KRX300Payload(TypedDict):
    source: str
    universe: Universe
    blocks: list[UniverseItem]
