# contracts_hj3415/universe/payloads.py
from __future__ import annotations

from typing import TypeAlias

from contracts_hj3415.universe.krx300 import KRX300Payload

UniversePayloadDTO: TypeAlias = KRX300Payload
