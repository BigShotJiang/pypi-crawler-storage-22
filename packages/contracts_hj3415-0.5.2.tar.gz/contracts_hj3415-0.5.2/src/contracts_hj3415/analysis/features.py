# contracts_hj3415/analysis/features.py
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeAlias, TypedDict

from contracts_hj3415.nfs.types import MetricKey

AggKind: TypeAlias = Literal["sum", "avg"]
PeriodKind: TypeAlias = Literal["y", "q"]


class FeatureValue(TypedDict):
    value: float | None
    picked: str | None
    from_kind: PeriodKind | None


class MetricDiagnostics(TypedDict):
    ok: bool
    reason: str | None
    details: dict[str, Any]  # pyright: ignore[reportExplicitAny]


class LatestAndTtm(TypedDict):
    latest_y: FeatureValue
    latest_q: FeatureValue
    ttm_q: FeatureValue
    chosen: FeatureValue
    diag: MetricDiagnostics


FeaturesContents: TypeAlias = Mapping[MetricKey, LatestAndTtm]
