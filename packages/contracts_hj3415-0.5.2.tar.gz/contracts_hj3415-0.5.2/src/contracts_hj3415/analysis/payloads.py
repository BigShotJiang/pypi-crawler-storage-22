# contracts_hj3415/analysis/payloads.py
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeAlias, TypedDict

from contracts_hj3415.analysis.features import FeaturesContents
from contracts_hj3415.analysis.red import RedContents
from contracts_hj3415.analysis.types import AnalysisService
from contracts_hj3415.common.payload import PayloadDTO
from contracts_hj3415.common.types import Endpoint


class AnalysisMetaDTO(TypedDict):
    service: AnalysisService
    endpoint: Endpoint | None


AnalysisContents: TypeAlias = FeaturesContents | RedContents


class AnalysisPayloadDTO(TypedDict):
    meta: AnalysisMetaDTO
    contents: AnalysisContents


def build_analysis_payload_dto(
    service: str,
    endpoint: str | None,
    contents: Mapping[str, Any],  # pyright: ignore[reportExplicitAny]
) -> PayloadDTO:
    return {
        "meta": {
            "service": service,
            "endpoint": "" if endpoint is None else endpoint,
        },
        "contents": contents,
    }
