# contracts_hj3415/analysis/red.py
from collections.abc import Mapping
from typing import Any, TypeAlias

RedContents: TypeAlias = Mapping[str, Any]  # pyright: ignore[reportExplicitAny]
