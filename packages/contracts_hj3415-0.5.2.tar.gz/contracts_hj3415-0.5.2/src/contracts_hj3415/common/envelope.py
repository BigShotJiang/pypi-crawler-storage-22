# contracts_hj3415/common/envelope.py
from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from typing import Any, TypedDict, cast

from contracts_hj3415.analysis.payloads import build_analysis_payload_dto
from contracts_hj3415.common.payload import PayloadDTO, ensure_payload_dto
from contracts_hj3415.common.types import Source
from contracts_hj3415.nfs.payloads import build_nfs_payload_dto
from contracts_hj3415.universe.payloads import build_universe_payload_dto


class EnvelopeMeta(TypedDict, total=False):
    source: Source
    trace_id: str
    note: str
    tags: list[str]


class EnvelopeDTO(TypedDict):
    topic: str
    key: str
    asof: datetime
    payload: PayloadDTO
    meta: EnvelopeMeta


def make_empty_envelope_meta(source: Source = "") -> EnvelopeMeta:
    return {"source": source, "trace_id": "", "note": "", "tags": []}


def ensure_envelope_meta_dto(
    meta: Mapping[str, Any],  # pyright: ignore[reportExplicitAny]
) -> EnvelopeMeta:
    if (
        "source" not in meta
        or "trace_id" not in meta
        or "note" not in meta
        or "tags" not in meta
    ):
        raise ValueError("invalid envelope meta")
    return cast(EnvelopeMeta, meta)


# ---------- topic별 convenience wrappers ----------


def make_envelope(
    *,
    topic: str,
    key: str,
    asof: datetime,
    payload: PayloadDTO,
    meta: Mapping[str, Any],  # pyright: ignore[reportExplicitAny]
) -> EnvelopeDTO:
    return {
        "topic": topic,
        "key": key,
        "asof": asof,
        "payload": ensure_payload_dto(payload),
        "meta": ensure_envelope_meta_dto(meta),
    }


def make_nfs_envelope(
    *,
    code: str,
    asof: datetime,
    labels: Mapping[str, str],
    endpoint: str,
    contents: Mapping[str, Any],  # pyright: ignore[reportExplicitAny]
    meta: Mapping[str, Any] | None = None,  # pyright: ignore[reportExplicitAny]
) -> EnvelopeDTO:
    payload = build_nfs_payload_dto(
        endpoint=endpoint,
        contents=contents,
        labels=labels,
    )
    return make_envelope(
        topic="nfs",
        key=code,
        asof=asof,
        payload=payload,
        meta=meta or make_empty_envelope_meta("scraper2"),
    )


def make_universe_envelope(
    *,
    universe: str,
    asof: datetime,
    source: str,
    contents: Mapping[str, Any],  # pyright: ignore[reportExplicitAny]
    meta: Mapping[str, Any] | None = None,  # pyright: ignore[reportExplicitAny]
) -> EnvelopeDTO:
    payload = build_universe_payload_dto(
        source=source,
        contents=contents,
    )
    return make_envelope(
        topic="universe",
        key=universe,
        asof=asof,
        payload=payload,
        meta=meta or make_empty_envelope_meta("krx"),
    )


def make_analysis_envelope(
    *,
    code: str,
    asof: datetime,
    service: str,
    endpoint: str,
    contents: Mapping[str, Any],  # pyright: ignore[reportExplicitAny]
    meta: Mapping[str, Any] | None = None,  # pyright: ignore[reportExplicitAny]
) -> EnvelopeDTO:
    payload = build_analysis_payload_dto(
        service=service,
        endpoint=endpoint,
        contents=contents,
    )
    return make_envelope(
        topic="analysis",
        key=code,
        asof=asof,
        payload=payload,
        meta=meta or make_empty_envelope_meta("analyser2"),
    )
