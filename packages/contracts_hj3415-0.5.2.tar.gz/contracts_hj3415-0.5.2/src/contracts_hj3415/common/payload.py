# contracts_hj3415/common/payload.py
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypedDict, cast

from contracts_hj3415.common.types import Contents, PayloadMeta


class PayloadDTO(TypedDict):
    meta: PayloadMeta
    contents: Contents


def ensure_payload_dto(
    payload: Mapping[str, Any],  # pyright: ignore[reportExplicitAny]
) -> PayloadDTO:
    if "meta" not in payload or "contents" not in payload:
        raise ValueError("invalid payload")
    return cast(PayloadDTO, payload)
