# contracts_hj3415/common/types.py
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeAlias

Topic: TypeAlias = Literal["nfs", "universe", "analysis"]

CodeKey: TypeAlias = str

Num: TypeAlias = float | int | None

Source: TypeAlias = Literal["", "scraper2", "krx", "analyser2"]

Contents: TypeAlias = Mapping[str, Any]  # pyright: ignore[reportExplicitAny]

PayloadMeta: TypeAlias = Mapping[str, Any]  # pyright: ignore[reportExplicitAny]

Endpoint: TypeAlias = Literal["c101", "c103", "c104", "c106", "c108"]
