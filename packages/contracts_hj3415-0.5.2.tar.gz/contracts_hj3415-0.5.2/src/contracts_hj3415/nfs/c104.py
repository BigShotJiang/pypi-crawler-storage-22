# contracts_hj3415/nfs/c104.py
from __future__ import annotations

from typing import TypeAlias

from contracts_hj3415.common.types import Num
from typing_extensions import TypedDict

from .types import MetricKey, PeriodKey

C104ValuesMap: TypeAlias = dict[PeriodKey, Num]


class C104Contents(TypedDict):
    수익성y: dict[MetricKey, C104ValuesMap]
    성장성y: dict[MetricKey, C104ValuesMap]
    안정성y: dict[MetricKey, C104ValuesMap]
    활동성y: dict[MetricKey, C104ValuesMap]
    가치분석y: dict[MetricKey, C104ValuesMap]
    수익성q: dict[MetricKey, C104ValuesMap]
    성장성q: dict[MetricKey, C104ValuesMap]
    안정성q: dict[MetricKey, C104ValuesMap]
    활동성q: dict[MetricKey, C104ValuesMap]
    가치분석q: dict[MetricKey, C104ValuesMap]


class C104Labels(TypedDict):
    수익성y: dict[MetricKey, str]
    성장성y: dict[MetricKey, str]
    안정성y: dict[MetricKey, str]
    활동성y: dict[MetricKey, str]
    가치분석y: dict[MetricKey, str]
    수익성q: dict[MetricKey, str]
    성장성q: dict[MetricKey, str]
    안정성q: dict[MetricKey, str]
    활동성q: dict[MetricKey, str]
    가치분석q: dict[MetricKey, str]
