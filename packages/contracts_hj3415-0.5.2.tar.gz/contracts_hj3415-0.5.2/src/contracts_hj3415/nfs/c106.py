# contracts_hj3415/nfs/c106.py
from __future__ import annotations

from typing import TypeAlias

from contracts_hj3415.common.types import CodeKey, Num
from typing_extensions import TypedDict

from .types import MetricKey

C106ValuesMap: TypeAlias = dict[CodeKey, Num]


class C106Contents(TypedDict):
    y: dict[MetricKey, C106ValuesMap]
    q: dict[MetricKey, C106ValuesMap]


class C106Labels(TypedDict):
    y: dict[MetricKey, str]
    q: dict[MetricKey, str]
