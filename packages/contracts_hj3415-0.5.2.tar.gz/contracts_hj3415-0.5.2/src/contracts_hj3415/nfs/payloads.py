# contracts_hj3415/nfs/payloads.py
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeAlias, TypedDict

from contracts_hj3415.common.payload import PayloadDTO
from contracts_hj3415.common.types import Endpoint
from contracts_hj3415.nfs.c101 import C101Contents
from contracts_hj3415.nfs.c103 import C103Contents
from contracts_hj3415.nfs.c104 import C104Contents
from contracts_hj3415.nfs.c106 import C106Contents
from contracts_hj3415.nfs.c108 import C108Contents


class NfsMetaDTO(TypedDict):
    endpoint: Endpoint
    labels: Mapping[str, str] | None


NfsContents: TypeAlias = (
    C101Contents | C104Contents | C106Contents | C108Contents | C103Contents
)


class NfsPayloadDTO(TypedDict):
    meta: NfsMetaDTO
    contents: NfsContents


def build_nfs_payload_dto(
    endpoint: str,
    contents: Mapping[str, Any],  # pyright: ignore[reportExplicitAny]
    labels: Mapping[str, Any] | None,  # pyright: ignore[reportExplicitAny]
) -> PayloadDTO:
    return {
        "meta": {
            "endpoint": endpoint,
            "labels": labels,
        },
        "contents": contents,
    }
