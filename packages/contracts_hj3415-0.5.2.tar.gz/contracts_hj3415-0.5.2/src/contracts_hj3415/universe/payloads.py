# contracts_hj3415/universe/payloads.py
from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeAlias, TypedDict

from contracts_hj3415.common.payload import PayloadDTO
from contracts_hj3415.universe.krx300 import Krx300Contents

Source: TypeAlias = Literal["samsungfund",]


class UniverseMetaDTO(TypedDict):
    source: Source


UniverseContents: TypeAlias = Krx300Contents


class UniversePayloadDTO(TypedDict):
    meta: UniverseMetaDTO
    contents: UniverseContents


def build_universe_payload_dto(
    source: str,
    contents: Mapping[str, Any],  # pyright: ignore[reportExplicitAny]
) -> PayloadDTO:
    return {
        "meta": {
            "source": source,
        },
        "contents": contents,
    }
