# contracts_hj3415/universe/types.py
from __future__ import annotations

from typing import Literal, TypeAlias

Universe: TypeAlias = Literal["krx300",]
