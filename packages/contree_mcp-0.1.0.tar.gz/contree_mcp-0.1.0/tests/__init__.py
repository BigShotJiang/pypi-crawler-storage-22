"""Tests for contree-mcp."""
