<table width="100%">
   <tr>
      <th valign="top" width="800px" align="left">Software</th>
      <th valign="top" align="left">License</th>
   </tr>
   <tr>
      <td valign="top"><a href="https://github.com/modelcontextprotocol/python-sdk">modelcontextprotocol/python-sdk</a></td>
      <td valign="top"><a href="https://github.com/modelcontextprotocol/python-sdk/blob/main/LICENSE">MIT</a></td>
   </tr>
   <tr>
      <td valign="top"><a href="https://github.com/encode/httpx">encode/httpx</a></td>
      <td valign="top"><a href="https://github.com/encode/httpx/blob/master/LICENSE.md">BSD 3-Clause</a></td>
   </tr>
   <tr>
      <td valign="top"><a href="https://github.com/pydantic/pydantic">pydantic/pydantic</a></td>
      <td valign="top"><a href="https://github.com/pydantic/pydantic/blob/main/LICENSE">MIT</a></td>
   </tr>
</table>