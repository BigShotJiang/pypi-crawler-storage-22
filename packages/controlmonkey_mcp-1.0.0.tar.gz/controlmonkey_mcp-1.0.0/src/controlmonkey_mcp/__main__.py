"""Allow running with ``python -m controlmonkey_mcp``."""

from controlmonkey_mcp import main

main()
