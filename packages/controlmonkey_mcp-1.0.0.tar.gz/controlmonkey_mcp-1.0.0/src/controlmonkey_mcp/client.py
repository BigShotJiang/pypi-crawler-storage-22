# Lightweight HTTP client for the ControlMonkey API.

from __future__ import annotations

import logging

import httpx

from . import config

logging.getLogger("httpx").setLevel(logging.WARNING)


def _build_headers() -> dict[str, str]:
    prefix = f"{config.AUTH_PREFIX} " if config.AUTH_PREFIX else ""
    return {
        config.AUTH_HEADER: f"{prefix}{config.API_TOKEN}",
        "Accept": "application/json",
        "User-Agent": "controlmonkey-mcp/1.0",
    }


def _client_kwargs() -> dict:
    """Common kwargs for both sync and async clients."""
    return {
        "base_url": config.BASE_URL,
        "headers": _build_headers(),
        "timeout": config.REQUEST_TIMEOUT,
    }


def _resolve_path(path: str, path_params: dict | None) -> str:
    """Substitute path parameters: /namespace/{namespaceId} → /namespace/ns-abc"""
    if not path_params:
        return path
    resolved = path
    for key, value in path_params.items():
        resolved = resolved.replace(f"{{{key}}}", str(value))
    return resolved


def _clean_query_params(params: dict | None) -> dict | None:
    """Strip None values from query params."""
    if not params:
        return None
    cleaned = {k: v for k, v in params.items() if v is not None}
    return cleaned or None


def _format_response(resp: httpx.Response) -> dict:
    """Build uniform response envelope."""
    if resp.status_code >= 400:
        return {
            "ok": False,
            "status": resp.status_code,
            "error": resp.text[:2000],
        }
    return {
        "ok": True,
        "status": resp.status_code,
        "data": resp.json(),
    }


# Async API call (used at runtime when AI invokes a tool)
async def async_request(
        method: str,
        path: str,
        *,
        path_params: dict | None = None,
        query_params: dict | None = None,
        body: dict | None = None,
) -> dict:
    """
    Execute an async HTTP request against the ControlMonkey API.
    Used by tool handlers to avoid blocking the event loop.
    """
    resolved_path = _resolve_path(path, path_params)
    cleaned_params = _clean_query_params(query_params)

    async with httpx.AsyncClient(**_client_kwargs()) as http:
        resp = await http.request(
            method=method.upper(),
            url=resolved_path,
            params=cleaned_params,
            json=body or None,
        )

    return _format_response(resp)


# Sync API call (used at startup for fetching tool definitions)
def sync_request(
        method: str,
        path: str,
        *,
        path_params: dict | None = None,
        query_params: dict | None = None,
        body: dict | None = None,
) -> dict:
    """Execute a sync HTTP request. Used only at startup."""
    resolved_path = _resolve_path(path, path_params)
    cleaned_params = _clean_query_params(query_params)

    with httpx.Client(**_client_kwargs()) as http:
        resp = http.request(
            method=method.upper(),
            url=resolved_path,
            params=cleaned_params,
            json=body or None,
        )

    return _format_response(resp)


# Fetch tool definitions from backend
def fetch_tool_definitions() -> list[dict]:
    """
    Call GET /mcp/tools to get the list of tool definitions.
    Returns a list of tool definition dicts, or raises on failure.
    Uses sync HTTP since this runs at startup before the event loop.
    """
    with httpx.Client(**_client_kwargs()) as http:
        resp = http.get("/mcp/tools")

    if resp.status_code != 200:
        raise RuntimeError(
            f"Failed to fetch tool definitions from /mcp/tools: "
            f"HTTP {resp.status_code} — {resp.text[:500]}"
        )

    data = resp.json()

    # Support plain array, {"items": [...]}, or {"data": {"items": [...]}}
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        if "items" in data:
            return data["items"]
        if "data" in data and "items" in data["data"]:
            return data["data"]["items"]

    raise RuntimeError(f"Unexpected response shape from /mcp/tools: {type(data).__name__}")
