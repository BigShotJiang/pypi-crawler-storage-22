"""
All settings are read from environment variables at import time.

Required:
    CM_BASE_URL   – ControlMonkey API base URL (e.g. https://api.controlmonkey.io/)
    CM_API_TOKEN  – API token for authentication

Optional:
    CM_AUTH_HEADER   – Header name (default: Authorization)
    CM_AUTH_PREFIX   – Token prefix (default: Bearer)
    CM_REQUEST_TIMEOUT – HTTP timeout in seconds (default: 30)
"""

from __future__ import annotations

import os


def _require(var: str) -> str:
    val = os.environ.get(var)
    if not val:
        raise RuntimeError(f"Missing required environment variable: {var}")
    return val


BASE_URL: str = _require("CM_BASE_URL").rstrip("/")
API_TOKEN: str = _require("CM_API_TOKEN")

AUTH_HEADER: str = os.getenv("CM_AUTH_HEADER", "Authorization")
AUTH_PREFIX: str = os.getenv("CM_AUTH_PREFIX", "Bearer")
REQUEST_TIMEOUT: float = float(os.getenv("CM_REQUEST_TIMEOUT", "30"))
