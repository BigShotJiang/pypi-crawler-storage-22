# Dynamic tool builder

from __future__ import annotations

import logging
from typing import Annotated, Any, Optional

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.tools import Tool
from mcp.server.fastmcp.utilities.func_metadata import FuncMetadata, ArgModelBase
from pydantic import Field, create_model

from . import client

logger = logging.getLogger(__name__)

# Python type mapping for dynamic model creation
_PYTHON_TYPES = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
}

# JSON Schema type → Python type for body_schema properties
_BODY_SCHEMA_TYPES = {
    **_PYTHON_TYPES,
    "object": dict,
    "array": list,
}


def _build_arg_model(
        tool_name: str,
        parameters: list[dict],
        body_schema: dict | None = None,
) -> type[ArgModelBase]:
    """Create a dynamic Pydantic model from parameter definitions and optional body schema.

    This model gives FastMCP proper JSON Schema with types, descriptions,
    required/optional fields, and enum constraints.

    For body_schema, nested objects become `dict` fields and arrays become
    `list` fields in the Pydantic model. The full nested JSON Schema is
    applied separately in _build_tool() so the AI sees the complete structure.
    """
    model_fields: dict[str, Any] = {}

    # Path / query / flat-body parameters
    for param in parameters:
        name = param["name"]
        base_type = _PYTHON_TYPES.get(param.get("type", "string"), str)
        description = param.get("description", "")
        required = param.get("required", False)

        field_kwargs: dict[str, Any] = {"description": description}
        if "enum" in param:
            field_kwargs["json_schema_extra"] = {"enum": param["enum"]}

        if required:
            model_fields[name] = (
                Annotated[base_type, Field(**field_kwargs)],
                ...,
            )
        else:
            default = param.get("default", None)
            model_fields[name] = (
                Annotated[Optional[base_type], Field(**field_kwargs)],
                default,
            )

    # Body schema properties
    if body_schema and "properties" in body_schema:
        required_fields = set(body_schema.get("required", []))

        for name, prop in body_schema["properties"].items():
            if name in model_fields:
                continue  # parameter-level definition takes precedence

            prop_type = prop.get("type", "string")
            base_type = _BODY_SCHEMA_TYPES.get(prop_type, str)
            description = prop.get("description", "")

            field_kwargs: dict[str, Any] = {"description": description}
            if "enum" in prop:
                field_kwargs["json_schema_extra"] = {"enum": prop["enum"]}

            if name in required_fields:
                model_fields[name] = (
                    Annotated[base_type, Field(**field_kwargs)],
                    ...,
                )
            else:
                model_fields[name] = (
                    Annotated[Optional[base_type], Field(**field_kwargs)],
                    None,
                )

    return create_model(
        f"{tool_name}Arguments",
        __base__=ArgModelBase,
        **model_fields,
    )


def _make_handler(tool_def: dict):
    """Create an async handler that routes arguments to the correct API call.

    Arguments are sorted into path/query/body based on:
      1. parameter[].in routing (path, query, body)
      2. body_schema property names → body
      3. anything else → query (safe default)
    """
    method = tool_def.get("method", "GET")
    path = tool_def["path"]
    parameters = tool_def.get("parameters", [])
    body_schema = tool_def.get("body_schema")
    body_wrapper = tool_def.get("body_wrapper")

    # Pre-compute where each parameter goes
    param_routing: dict[str, str] = {p["name"]: p["in"] for p in parameters}

    # Fields that belong to the request body
    body_field_names: set[str] = set()
    if body_schema and "properties" in body_schema:
        body_field_names = set(body_schema["properties"].keys())

    async def handler(**kwargs) -> dict:
        path_params: dict[str, Any] = {}
        query_params: dict[str, Any] = {}
        body_params: dict[str, Any] = {}

        for key, value in kwargs.items():
            if value is None:
                continue

            # Check explicit parameter routing first
            location = param_routing.get(key)
            if location == "path":
                path_params[key] = value
            elif location == "query":
                query_params[key] = value
            elif location == "body":
                body_params[key] = value
            elif key in body_field_names:
                # Field defined in body_schema
                body_params[key] = value
            else:
                # Default fallback
                query_params[key] = value

        # Wrap body if needed: {"name": "x"} → {"entity": {"name": "x"}}
        final_body = None
        if body_params:
            final_body = {body_wrapper: body_params} if body_wrapper else body_params

        return await client.async_request(
            method=method,
            path=path,
            path_params=path_params or None,
            query_params=query_params or None,
            body=final_body,
        )

    return handler


def _validate_tool_def(tool_def: dict) -> None:
    """Validate a tool definition has the required fields."""
    for field in ("name", "path"):
        if field not in tool_def:
            raise ValueError(f"Tool definition missing required field '{field}': {tool_def}")


def _build_tool(tool_def: dict) -> Tool:
    """Build a single FastMCP Tool from a backend tool definition."""
    _validate_tool_def(tool_def)

    name = tool_def["name"]
    description = tool_def.get("description", "")
    parameters = tool_def.get("parameters", [])
    body_schema = tool_def.get("body_schema")

    # Create the dynamic argument model (for validation)
    arg_model = _build_arg_model(name, parameters, body_schema)

    # Create metadata for argument validation
    fn_metadata = FuncMetadata(arg_model=arg_model)

    # Build the JSON Schema that the AI sees
    schema = arg_model.model_json_schema()

    # Override body field schemas with the richer body_schema definitions.
    # The Pydantic model uses `dict` for nested objects, but we want the AI
    # to see the full nested structure with property names and descriptions.
    if body_schema and "properties" in body_schema:
        for field_name, field_schema in body_schema["properties"].items():
            if field_name in schema.get("properties", {}):
                # Preserve description from our model, overlay full type schema
                existing_desc = schema["properties"][field_name].get("description", "")
                schema["properties"][field_name] = {
                    **field_schema,
                    "description": existing_desc or field_schema.get("description", ""),
                }

        # Ensure required fields from body_schema are in the schema
        if "required" in body_schema:
            existing_required = set(schema.get("required", []))
            existing_required.update(body_schema["required"])
            schema["required"] = sorted(existing_required)

    # Create the handler that calls the API
    handler = _make_handler(tool_def)

    return Tool(
        fn=handler,
        name=name,
        description=description,
        parameters=schema,
        fn_metadata=fn_metadata,
        is_async=True,
    )


def register_tools(mcp: FastMCP) -> int:
    """Fetch tool definitions from the backend and register them with FastMCP.

    Returns the number of tools registered.
    Raises RuntimeError if the backend is unreachable.
    """
    tool_defs = client.fetch_tool_definitions()

    if not tool_defs:
        logger.warning("Backend returned zero tool definitions")
        return 0

    registered = 0
    for tool_def in tool_defs:
        try:
            tool = _build_tool(tool_def)
            # NOTE: We inject directly into _tool_manager._tools because
            # FastMCP's public add_tool() calls Tool.from_function() which
            # inspects the function signature. Our dynamically-built handlers
            # use **kwargs, which produces the wrong schema. Direct injection
            # lets us provide pre-built Tool objects with correct schemas.
            mcp._tool_manager._tools[tool.name] = tool
            logger.debug("Registered tool: %s", tool.name)
            registered += 1
        except Exception:
            logger.exception("Failed to register tool: %s", tool_def.get("name", "unknown"))

    logger.info("Registered %d of %d tools from backend", registered, len(tool_defs))
    return registered
