from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .registry import register_tools

mcp = FastMCP("ControlMonkey")

# Fetch tool definitions from the backend and register them dynamically.
register_tools(mcp)
