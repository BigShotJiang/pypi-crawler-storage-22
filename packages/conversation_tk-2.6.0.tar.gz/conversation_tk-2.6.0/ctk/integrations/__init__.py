"""Integration plugins for various chat formats"""
