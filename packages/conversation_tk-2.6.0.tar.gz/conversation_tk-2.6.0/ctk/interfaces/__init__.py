"""
CTK Interfaces - Multiple interface implementations for the core CTK functionality
"""

from .base import BaseInterface, InterfaceResponse

__all__ = ["BaseInterface", "InterfaceResponse"]
