"""
RESTful API interface for CTK
"""

from .api import RestInterface

__all__ = ["RestInterface"]
