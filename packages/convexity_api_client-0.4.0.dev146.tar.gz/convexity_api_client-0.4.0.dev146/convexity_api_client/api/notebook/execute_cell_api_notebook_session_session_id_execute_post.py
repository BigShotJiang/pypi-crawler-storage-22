from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.execute_cell_request import ExecuteCellRequest
from ...models.http_validation_error import HTTPValidationError
from ...models.notebook_cell_output import NotebookCellOutput
from ...types import Response


def _get_kwargs(
    session_id: str,
    *,
    body: ExecuteCellRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/notebook/session/{session_id}/execute".format(
            session_id=quote(str(session_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | NotebookCellOutput | None:
    if response.status_code == 200:
        response_200 = NotebookCellOutput.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | NotebookCellOutput]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    session_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ExecuteCellRequest,
) -> Response[HTTPValidationError | NotebookCellOutput]:
    """Execute Cell

     Execute code in a notebook session.

    The code runs in the session's namespace, so variables from previous
    executions are available.

    Args:
        session_id (str):
        body (ExecuteCellRequest): Request to execute code in a session.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | NotebookCellOutput]
    """

    kwargs = _get_kwargs(
        session_id=session_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    session_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ExecuteCellRequest,
) -> HTTPValidationError | NotebookCellOutput | None:
    """Execute Cell

     Execute code in a notebook session.

    The code runs in the session's namespace, so variables from previous
    executions are available.

    Args:
        session_id (str):
        body (ExecuteCellRequest): Request to execute code in a session.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | NotebookCellOutput
    """

    return sync_detailed(
        session_id=session_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    session_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ExecuteCellRequest,
) -> Response[HTTPValidationError | NotebookCellOutput]:
    """Execute Cell

     Execute code in a notebook session.

    The code runs in the session's namespace, so variables from previous
    executions are available.

    Args:
        session_id (str):
        body (ExecuteCellRequest): Request to execute code in a session.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | NotebookCellOutput]
    """

    kwargs = _get_kwargs(
        session_id=session_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    session_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ExecuteCellRequest,
) -> HTTPValidationError | NotebookCellOutput | None:
    """Execute Cell

     Execute code in a notebook session.

    The code runs in the session's namespace, so variables from previous
    executions are available.

    Args:
        session_id (str):
        body (ExecuteCellRequest): Request to execute code in a session.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | NotebookCellOutput
    """

    return (
        await asyncio_detailed(
            session_id=session_id,
            client=client,
            body=body,
        )
    ).parsed
