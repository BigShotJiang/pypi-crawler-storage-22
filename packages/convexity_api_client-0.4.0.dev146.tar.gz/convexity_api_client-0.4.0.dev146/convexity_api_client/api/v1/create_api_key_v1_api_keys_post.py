from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_api_key_request import CreateApiKeyRequest
from ...models.create_api_key_response import CreateApiKeyResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    *,
    body: CreateApiKeyRequest,
    project_id: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/api-keys",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreateApiKeyResponse | HTTPValidationError | None:
    if response.status_code == 201:
        response_201 = CreateApiKeyResponse.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreateApiKeyResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateApiKeyRequest,
    project_id: str,
) -> Response[CreateApiKeyResponse | HTTPValidationError]:
    """Create Api Key

     Create a new API key for the project. Requires MEMBER role or above.

    Users can only grant permissions up to their own role level:
    - VIEWER can grant READ only
    - MEMBER can grant READ or WRITE
    - ADMIN/OWNER can grant READ, WRITE, or ADMIN

    Args:
        project_id (str):
        body (CreateApiKeyRequest): Request to create a new API key.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateApiKeyResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateApiKeyRequest,
    project_id: str,
) -> CreateApiKeyResponse | HTTPValidationError | None:
    """Create Api Key

     Create a new API key for the project. Requires MEMBER role or above.

    Users can only grant permissions up to their own role level:
    - VIEWER can grant READ only
    - MEMBER can grant READ or WRITE
    - ADMIN/OWNER can grant READ, WRITE, or ADMIN

    Args:
        project_id (str):
        body (CreateApiKeyRequest): Request to create a new API key.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateApiKeyResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateApiKeyRequest,
    project_id: str,
) -> Response[CreateApiKeyResponse | HTTPValidationError]:
    """Create Api Key

     Create a new API key for the project. Requires MEMBER role or above.

    Users can only grant permissions up to their own role level:
    - VIEWER can grant READ only
    - MEMBER can grant READ or WRITE
    - ADMIN/OWNER can grant READ, WRITE, or ADMIN

    Args:
        project_id (str):
        body (CreateApiKeyRequest): Request to create a new API key.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateApiKeyResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateApiKeyRequest,
    project_id: str,
) -> CreateApiKeyResponse | HTTPValidationError | None:
    """Create Api Key

     Create a new API key for the project. Requires MEMBER role or above.

    Users can only grant permissions up to their own role level:
    - VIEWER can grant READ only
    - MEMBER can grant READ or WRITE
    - ADMIN/OWNER can grant READ, WRITE, or ADMIN

    Args:
        project_id (str):
        body (CreateApiKeyRequest): Request to create a new API key.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateApiKeyResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            project_id=project_id,
        )
    ).parsed
