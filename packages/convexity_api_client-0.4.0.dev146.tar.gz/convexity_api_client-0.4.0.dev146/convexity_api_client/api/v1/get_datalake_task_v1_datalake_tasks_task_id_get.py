from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.worker_task_response import WorkerTaskResponse
from ...types import UNSET, Response


def _get_kwargs(
    task_id: str,
    *,
    project_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/datalake-tasks/{task_id}".format(
            task_id=quote(str(task_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | WorkerTaskResponse | None:
    if response.status_code == 200:
        response_200 = WorkerTaskResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | WorkerTaskResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    task_id: str,
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> Response[HTTPValidationError | WorkerTaskResponse]:
    """Get Datalake Task

     Get a single datalake-related worker task by ID.

    Requires viewer role.

    Args:
        task_id (str): Worker task ID
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkerTaskResponse]
    """

    kwargs = _get_kwargs(
        task_id=task_id,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    task_id: str,
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> HTTPValidationError | WorkerTaskResponse | None:
    """Get Datalake Task

     Get a single datalake-related worker task by ID.

    Requires viewer role.

    Args:
        task_id (str): Worker task ID
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkerTaskResponse
    """

    return sync_detailed(
        task_id=task_id,
        client=client,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    task_id: str,
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> Response[HTTPValidationError | WorkerTaskResponse]:
    """Get Datalake Task

     Get a single datalake-related worker task by ID.

    Requires viewer role.

    Args:
        task_id (str): Worker task ID
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkerTaskResponse]
    """

    kwargs = _get_kwargs(
        task_id=task_id,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    task_id: str,
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> HTTPValidationError | WorkerTaskResponse | None:
    """Get Datalake Task

     Get a single datalake-related worker task by ID.

    Requires viewer role.

    Args:
        task_id (str): Worker task ID
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkerTaskResponse
    """

    return (
        await asyncio_detailed(
            task_id=task_id,
            client=client,
            project_id=project_id,
        )
    ).parsed
