from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.chat_session_list_response import ChatSessionListResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    limit: int | Unset = 50,
    project_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/chat-sessions",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ChatSessionListResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ChatSessionListResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ChatSessionListResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    project_id: str,
) -> Response[ChatSessionListResponse | HTTPValidationError]:
    """List Chat Sessions

     List chat sessions for a project. Requires viewer role.

    Args:
        limit (int | Unset):  Default: 50.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ChatSessionListResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        limit=limit,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    project_id: str,
) -> ChatSessionListResponse | HTTPValidationError | None:
    """List Chat Sessions

     List chat sessions for a project. Requires viewer role.

    Args:
        limit (int | Unset):  Default: 50.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ChatSessionListResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        limit=limit,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    project_id: str,
) -> Response[ChatSessionListResponse | HTTPValidationError]:
    """List Chat Sessions

     List chat sessions for a project. Requires viewer role.

    Args:
        limit (int | Unset):  Default: 50.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ChatSessionListResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        limit=limit,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    project_id: str,
) -> ChatSessionListResponse | HTTPValidationError | None:
    """List Chat Sessions

     List chat sessions for a project. Requires viewer role.

    Args:
        limit (int | Unset):  Default: 50.
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ChatSessionListResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            project_id=project_id,
        )
    ).parsed
