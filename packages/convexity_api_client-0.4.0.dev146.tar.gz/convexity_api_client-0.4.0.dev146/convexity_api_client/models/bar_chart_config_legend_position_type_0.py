from enum import Enum


class BarChartConfigLegendPositionType0(str, Enum):
    BOTTOM = "bottom"
    LEFT = "left"
    RIGHT = "right"
    TOP = "top"

    def __str__(self) -> str:
        return str(self.value)
