from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.dashboard_chart_widget import DashboardChartWidget
    from ..models.dashboard_date_filter_widget import DashboardDateFilterWidget
    from ..models.dashboard_date_range_filter_widget import DashboardDateRangeFilterWidget
    from ..models.dashboard_definition_filter_values_type_0 import DashboardDefinitionFilterValuesType0
    from ..models.dashboard_definition_filters_type_0_item import DashboardDefinitionFiltersType0Item
    from ..models.dashboard_e_chart_widget import DashboardEChartWidget
    from ..models.dashboard_layout import DashboardLayout
    from ..models.dashboard_multi_select_filter_widget import DashboardMultiSelectFilterWidget
    from ..models.dashboard_number_filter_widget import DashboardNumberFilterWidget
    from ..models.dashboard_number_range_filter_widget import DashboardNumberRangeFilterWidget
    from ..models.dashboard_s3_object_widget import DashboardS3ObjectWidget
    from ..models.dashboard_select_filter_widget import DashboardSelectFilterWidget
    from ..models.dashboard_sql_chart_widget import DashboardSqlChartWidget
    from ..models.dashboard_table_widget import DashboardTableWidget
    from ..models.dashboard_task_widget import DashboardTaskWidget
    from ..models.dashboard_text_filter_widget import DashboardTextFilterWidget
    from ..models.dashboard_text_widget import DashboardTextWidget


T = TypeVar("T", bound="DashboardDefinition")


@_attrs_define
class DashboardDefinition:
    """Complete dashboard definition with server-side layout persistence.

    Attributes:
        id (str): Unique dashboard identifier
        name (str): Dashboard name
        user_id (str): Owner user ID
        project_id (str): Project ID
        description (None | str | Unset): Dashboard description
        tags (list[str] | None | Unset): Dashboard tags
        widgets (list[DashboardChartWidget | DashboardDateFilterWidget | DashboardDateRangeFilterWidget |
            DashboardEChartWidget | DashboardMultiSelectFilterWidget | DashboardNumberFilterWidget |
            DashboardNumberRangeFilterWidget | DashboardS3ObjectWidget | DashboardSelectFilterWidget |
            DashboardSqlChartWidget | DashboardTableWidget | DashboardTaskWidget | DashboardTextFilterWidget |
            DashboardTextWidget] | Unset): Dashboard widgets
        layout (DashboardLayout | None | Unset): Grid layout configuration
        filters (list[DashboardDefinitionFiltersType0Item] | None | Unset): Array of DashboardFilter definitions
        filter_values (DashboardDefinitionFilterValuesType0 | None | Unset): Current filter values
        last_refreshed_at (datetime.datetime | None | Unset): Last refresh timestamp
        created_at (datetime.datetime | None | Unset): Creation timestamp
        updated_at (datetime.datetime | None | Unset): Last update timestamp
    """

    id: str
    name: str
    user_id: str
    project_id: str
    description: None | str | Unset = UNSET
    tags: list[str] | None | Unset = UNSET
    widgets: (
        list[
            DashboardChartWidget
            | DashboardDateFilterWidget
            | DashboardDateRangeFilterWidget
            | DashboardEChartWidget
            | DashboardMultiSelectFilterWidget
            | DashboardNumberFilterWidget
            | DashboardNumberRangeFilterWidget
            | DashboardS3ObjectWidget
            | DashboardSelectFilterWidget
            | DashboardSqlChartWidget
            | DashboardTableWidget
            | DashboardTaskWidget
            | DashboardTextFilterWidget
            | DashboardTextWidget
        ]
        | Unset
    ) = UNSET
    layout: DashboardLayout | None | Unset = UNSET
    filters: list[DashboardDefinitionFiltersType0Item] | None | Unset = UNSET
    filter_values: DashboardDefinitionFilterValuesType0 | None | Unset = UNSET
    last_refreshed_at: datetime.datetime | None | Unset = UNSET
    created_at: datetime.datetime | None | Unset = UNSET
    updated_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.dashboard_chart_widget import DashboardChartWidget
        from ..models.dashboard_date_filter_widget import DashboardDateFilterWidget
        from ..models.dashboard_date_range_filter_widget import DashboardDateRangeFilterWidget
        from ..models.dashboard_definition_filter_values_type_0 import DashboardDefinitionFilterValuesType0
        from ..models.dashboard_e_chart_widget import DashboardEChartWidget
        from ..models.dashboard_layout import DashboardLayout
        from ..models.dashboard_multi_select_filter_widget import DashboardMultiSelectFilterWidget
        from ..models.dashboard_number_filter_widget import DashboardNumberFilterWidget
        from ..models.dashboard_s3_object_widget import DashboardS3ObjectWidget
        from ..models.dashboard_select_filter_widget import DashboardSelectFilterWidget
        from ..models.dashboard_sql_chart_widget import DashboardSqlChartWidget
        from ..models.dashboard_table_widget import DashboardTableWidget
        from ..models.dashboard_task_widget import DashboardTaskWidget
        from ..models.dashboard_text_filter_widget import DashboardTextFilterWidget
        from ..models.dashboard_text_widget import DashboardTextWidget

        id = self.id

        name = self.name

        user_id = self.user_id

        project_id = self.project_id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        tags: list[str] | None | Unset
        if isinstance(self.tags, Unset):
            tags = UNSET
        elif isinstance(self.tags, list):
            tags = self.tags

        else:
            tags = self.tags

        widgets: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.widgets, Unset):
            widgets = []
            for widgets_item_data in self.widgets:
                widgets_item: dict[str, Any]
                if isinstance(widgets_item_data, DashboardChartWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardSqlChartWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardTaskWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardS3ObjectWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardEChartWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardTableWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardTextWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardSelectFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardMultiSelectFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardDateFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardDateRangeFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardTextFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                elif isinstance(widgets_item_data, DashboardNumberFilterWidget):
                    widgets_item = widgets_item_data.to_dict()
                else:
                    widgets_item = widgets_item_data.to_dict()

                widgets.append(widgets_item)

        layout: dict[str, Any] | None | Unset
        if isinstance(self.layout, Unset):
            layout = UNSET
        elif isinstance(self.layout, DashboardLayout):
            layout = self.layout.to_dict()
        else:
            layout = self.layout

        filters: list[dict[str, Any]] | None | Unset
        if isinstance(self.filters, Unset):
            filters = UNSET
        elif isinstance(self.filters, list):
            filters = []
            for filters_type_0_item_data in self.filters:
                filters_type_0_item = filters_type_0_item_data.to_dict()
                filters.append(filters_type_0_item)

        else:
            filters = self.filters

        filter_values: dict[str, Any] | None | Unset
        if isinstance(self.filter_values, Unset):
            filter_values = UNSET
        elif isinstance(self.filter_values, DashboardDefinitionFilterValuesType0):
            filter_values = self.filter_values.to_dict()
        else:
            filter_values = self.filter_values

        last_refreshed_at: None | str | Unset
        if isinstance(self.last_refreshed_at, Unset):
            last_refreshed_at = UNSET
        elif isinstance(self.last_refreshed_at, datetime.datetime):
            last_refreshed_at = self.last_refreshed_at.isoformat()
        else:
            last_refreshed_at = self.last_refreshed_at

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        elif isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        elif isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "userId": user_id,
                "projectId": project_id,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if tags is not UNSET:
            field_dict["tags"] = tags
        if widgets is not UNSET:
            field_dict["widgets"] = widgets
        if layout is not UNSET:
            field_dict["layout"] = layout
        if filters is not UNSET:
            field_dict["filters"] = filters
        if filter_values is not UNSET:
            field_dict["filterValues"] = filter_values
        if last_refreshed_at is not UNSET:
            field_dict["lastRefreshedAt"] = last_refreshed_at
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dashboard_chart_widget import DashboardChartWidget
        from ..models.dashboard_date_filter_widget import DashboardDateFilterWidget
        from ..models.dashboard_date_range_filter_widget import DashboardDateRangeFilterWidget
        from ..models.dashboard_definition_filter_values_type_0 import DashboardDefinitionFilterValuesType0
        from ..models.dashboard_definition_filters_type_0_item import DashboardDefinitionFiltersType0Item
        from ..models.dashboard_e_chart_widget import DashboardEChartWidget
        from ..models.dashboard_layout import DashboardLayout
        from ..models.dashboard_multi_select_filter_widget import DashboardMultiSelectFilterWidget
        from ..models.dashboard_number_filter_widget import DashboardNumberFilterWidget
        from ..models.dashboard_number_range_filter_widget import DashboardNumberRangeFilterWidget
        from ..models.dashboard_s3_object_widget import DashboardS3ObjectWidget
        from ..models.dashboard_select_filter_widget import DashboardSelectFilterWidget
        from ..models.dashboard_sql_chart_widget import DashboardSqlChartWidget
        from ..models.dashboard_table_widget import DashboardTableWidget
        from ..models.dashboard_task_widget import DashboardTaskWidget
        from ..models.dashboard_text_filter_widget import DashboardTextFilterWidget
        from ..models.dashboard_text_widget import DashboardTextWidget

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        user_id = d.pop("userId")

        project_id = d.pop("projectId")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_tags(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tags_type_0 = cast(list[str], data)

                return tags_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        tags = _parse_tags(d.pop("tags", UNSET))

        _widgets = d.pop("widgets", UNSET)
        widgets: (
            list[
                DashboardChartWidget
                | DashboardDateFilterWidget
                | DashboardDateRangeFilterWidget
                | DashboardEChartWidget
                | DashboardMultiSelectFilterWidget
                | DashboardNumberFilterWidget
                | DashboardNumberRangeFilterWidget
                | DashboardS3ObjectWidget
                | DashboardSelectFilterWidget
                | DashboardSqlChartWidget
                | DashboardTableWidget
                | DashboardTaskWidget
                | DashboardTextFilterWidget
                | DashboardTextWidget
            ]
            | Unset
        ) = UNSET
        if _widgets is not UNSET:
            widgets = []
            for widgets_item_data in _widgets:

                def _parse_widgets_item(
                    data: object,
                ) -> (
                    DashboardChartWidget
                    | DashboardDateFilterWidget
                    | DashboardDateRangeFilterWidget
                    | DashboardEChartWidget
                    | DashboardMultiSelectFilterWidget
                    | DashboardNumberFilterWidget
                    | DashboardNumberRangeFilterWidget
                    | DashboardS3ObjectWidget
                    | DashboardSelectFilterWidget
                    | DashboardSqlChartWidget
                    | DashboardTableWidget
                    | DashboardTaskWidget
                    | DashboardTextFilterWidget
                    | DashboardTextWidget
                ):
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_0 = DashboardChartWidget.from_dict(data)

                        return widgets_item_type_0
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_1 = DashboardSqlChartWidget.from_dict(data)

                        return widgets_item_type_1
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_2 = DashboardTaskWidget.from_dict(data)

                        return widgets_item_type_2
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_3 = DashboardS3ObjectWidget.from_dict(data)

                        return widgets_item_type_3
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_4 = DashboardEChartWidget.from_dict(data)

                        return widgets_item_type_4
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_5 = DashboardTableWidget.from_dict(data)

                        return widgets_item_type_5
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_6 = DashboardTextWidget.from_dict(data)

                        return widgets_item_type_6
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_7 = DashboardSelectFilterWidget.from_dict(data)

                        return widgets_item_type_7
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_8 = DashboardMultiSelectFilterWidget.from_dict(data)

                        return widgets_item_type_8
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_9 = DashboardDateFilterWidget.from_dict(data)

                        return widgets_item_type_9
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_10 = DashboardDateRangeFilterWidget.from_dict(data)

                        return widgets_item_type_10
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_11 = DashboardTextFilterWidget.from_dict(data)

                        return widgets_item_type_11
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_item_type_12 = DashboardNumberFilterWidget.from_dict(data)

                        return widgets_item_type_12
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    if not isinstance(data, dict):
                        raise TypeError()
                    widgets_item_type_13 = DashboardNumberRangeFilterWidget.from_dict(data)

                    return widgets_item_type_13

                widgets_item = _parse_widgets_item(widgets_item_data)

                widgets.append(widgets_item)

        def _parse_layout(data: object) -> DashboardLayout | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                layout_type_0 = DashboardLayout.from_dict(data)

                return layout_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DashboardLayout | None | Unset, data)

        layout = _parse_layout(d.pop("layout", UNSET))

        def _parse_filters(data: object) -> list[DashboardDefinitionFiltersType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                filters_type_0 = []
                _filters_type_0 = data
                for filters_type_0_item_data in _filters_type_0:
                    filters_type_0_item = DashboardDefinitionFiltersType0Item.from_dict(filters_type_0_item_data)

                    filters_type_0.append(filters_type_0_item)

                return filters_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DashboardDefinitionFiltersType0Item] | None | Unset, data)

        filters = _parse_filters(d.pop("filters", UNSET))

        def _parse_filter_values(data: object) -> DashboardDefinitionFilterValuesType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                filter_values_type_0 = DashboardDefinitionFilterValuesType0.from_dict(data)

                return filter_values_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DashboardDefinitionFilterValuesType0 | None | Unset, data)

        filter_values = _parse_filter_values(d.pop("filterValues", UNSET))

        def _parse_last_refreshed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_refreshed_at_type_0 = isoparse(data)

                return last_refreshed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_refreshed_at = _parse_last_refreshed_at(d.pop("lastRefreshedAt", UNSET))

        def _parse_created_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = isoparse(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        created_at = _parse_created_at(d.pop("createdAt", UNSET))

        def _parse_updated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = isoparse(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        updated_at = _parse_updated_at(d.pop("updatedAt", UNSET))

        dashboard_definition = cls(
            id=id,
            name=name,
            user_id=user_id,
            project_id=project_id,
            description=description,
            tags=tags,
            widgets=widgets,
            layout=layout,
            filters=filters,
            filter_values=filter_values,
            last_refreshed_at=last_refreshed_at,
            created_at=created_at,
            updated_at=updated_at,
        )

        dashboard_definition.additional_properties = d
        return dashboard_definition

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
