from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.datalake_connection_info import DatalakeConnectionInfo


T = TypeVar("T", bound="DatalakeConnectionResponse")


@_attrs_define
class DatalakeConnectionResponse:
    """Response containing datalake connection info for direct DuckDB WASM access.

    Attributes:
        connection (DatalakeConnectionInfo | None | Unset): Datalake connection information
        available (bool | Unset): Whether the datalake connection is available Default: False.
        tables (list[str] | Unset): Available table names in the datalake
        message (None | str | Unset): Optional message when connection is not available
    """

    connection: DatalakeConnectionInfo | None | Unset = UNSET
    available: bool | Unset = False
    tables: list[str] | Unset = UNSET
    message: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.datalake_connection_info import DatalakeConnectionInfo

        connection: dict[str, Any] | None | Unset
        if isinstance(self.connection, Unset):
            connection = UNSET
        elif isinstance(self.connection, DatalakeConnectionInfo):
            connection = self.connection.to_dict()
        else:
            connection = self.connection

        available = self.available

        tables: list[str] | Unset = UNSET
        if not isinstance(self.tables, Unset):
            tables = self.tables

        message: None | str | Unset
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if connection is not UNSET:
            field_dict["connection"] = connection
        if available is not UNSET:
            field_dict["available"] = available
        if tables is not UNSET:
            field_dict["tables"] = tables
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.datalake_connection_info import DatalakeConnectionInfo

        d = dict(src_dict)

        def _parse_connection(data: object) -> DatalakeConnectionInfo | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                connection_type_0 = DatalakeConnectionInfo.from_dict(data)

                return connection_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DatalakeConnectionInfo | None | Unset, data)

        connection = _parse_connection(d.pop("connection", UNSET))

        available = d.pop("available", UNSET)

        tables = cast(list[str], d.pop("tables", UNSET))

        def _parse_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message = _parse_message(d.pop("message", UNSET))

        datalake_connection_response = cls(
            connection=connection,
            available=available,
            tables=tables,
            message=message,
        )

        datalake_connection_response.additional_properties = d
        return datalake_connection_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
