from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="GetFileUrlResponse")


@_attrs_define
class GetFileUrlResponse:
    """
    Attributes:
        url (str):
        file_path (str):
        workspace_id (str):
        expires_in (int):
    """

    url: str
    file_path: str
    workspace_id: str
    expires_in: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        url = self.url

        file_path = self.file_path

        workspace_id = self.workspace_id

        expires_in = self.expires_in

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "url": url,
                "file_path": file_path,
                "workspace_id": workspace_id,
                "expires_in": expires_in,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        url = d.pop("url")

        file_path = d.pop("file_path")

        workspace_id = d.pop("workspace_id")

        expires_in = d.pop("expires_in")

        get_file_url_response = cls(
            url=url,
            file_path=file_path,
            workspace_id=workspace_id,
            expires_in=expires_in,
        )

        get_file_url_response.additional_properties = d
        return get_file_url_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
