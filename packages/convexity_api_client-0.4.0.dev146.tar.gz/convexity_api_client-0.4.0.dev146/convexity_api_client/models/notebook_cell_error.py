from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="NotebookCellError")


@_attrs_define
class NotebookCellError:
    """Error information from cell execution.

    Attributes:
        ename (str):
        evalue (str):
        traceback (list[str]):
    """

    ename: str
    evalue: str
    traceback: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ename = self.ename

        evalue = self.evalue

        traceback = self.traceback

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ename": ename,
                "evalue": evalue,
                "traceback": traceback,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ename = d.pop("ename")

        evalue = d.pop("evalue")

        traceback = cast(list[str], d.pop("traceback"))

        notebook_cell_error = cls(
            ename=ename,
            evalue=evalue,
            traceback=traceback,
        )

        notebook_cell_error.additional_properties = d
        return notebook_cell_error

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
