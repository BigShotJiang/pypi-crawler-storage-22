from enum import Enum


class ObjectTypeDefStorageclass(str, Enum):
    DEEP_ARCHIVE = "DEEP_ARCHIVE"
    EXPRESS_ONEZONE = "EXPRESS_ONEZONE"
    FSX_ONTAP = "FSX_ONTAP"
    FSX_OPENZFS = "FSX_OPENZFS"
    GLACIER = "GLACIER"
    GLACIER_IR = "GLACIER_IR"
    INTELLIGENT_TIERING = "INTELLIGENT_TIERING"
    ONEZONE_IA = "ONEZONE_IA"
    OUTPOSTS = "OUTPOSTS"
    REDUCED_REDUNDANCY = "REDUCED_REDUNDANCY"
    SNOW = "SNOW"
    STANDARD = "STANDARD"
    STANDARD_IA = "STANDARD_IA"

    def __str__(self) -> str:
        return str(self.value)
