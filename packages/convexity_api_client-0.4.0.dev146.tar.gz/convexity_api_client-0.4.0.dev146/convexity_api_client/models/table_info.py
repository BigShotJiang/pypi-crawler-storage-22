from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.schema_field import SchemaField


T = TypeVar("T", bound="TableInfo")


@_attrs_define
class TableInfo:
    """Table information with optional schema.

    Attributes:
        name (str): Table name
        schema_fields (list[SchemaField] | None | Unset): Table column schema
    """

    name: str
    schema_fields: list[SchemaField] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        schema_fields: list[dict[str, Any]] | None | Unset
        if isinstance(self.schema_fields, Unset):
            schema_fields = UNSET
        elif isinstance(self.schema_fields, list):
            schema_fields = []
            for schema_fields_type_0_item_data in self.schema_fields:
                schema_fields_type_0_item = schema_fields_type_0_item_data.to_dict()
                schema_fields.append(schema_fields_type_0_item)

        else:
            schema_fields = self.schema_fields

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if schema_fields is not UNSET:
            field_dict["schemaFields"] = schema_fields

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.schema_field import SchemaField

        d = dict(src_dict)
        name = d.pop("name")

        def _parse_schema_fields(data: object) -> list[SchemaField] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                schema_fields_type_0 = []
                _schema_fields_type_0 = data
                for schema_fields_type_0_item_data in _schema_fields_type_0:
                    schema_fields_type_0_item = SchemaField.from_dict(schema_fields_type_0_item_data)

                    schema_fields_type_0.append(schema_fields_type_0_item)

                return schema_fields_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[SchemaField] | None | Unset, data)

        schema_fields = _parse_schema_fields(d.pop("schemaFields", UNSET))

        table_info = cls(
            name=name,
            schema_fields=schema_fields,
        )

        table_info.additional_properties = d
        return table_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
