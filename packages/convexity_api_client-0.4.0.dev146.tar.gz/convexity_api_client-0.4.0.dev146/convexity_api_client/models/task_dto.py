from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.task_scenario import TaskScenario
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.project import Project
    from ..models.run import Run
    from ..models.task_connection import TaskConnection


T = TypeVar("T", bound="TaskDTO")


@_attrs_define
class TaskDTO:
    """Represents a TaskDTO record

    Attributes:
        id (str):
        name (str):
        scenario (TaskScenario):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        user_id (str):
        project_id (str):
        description (None | str | Unset):
        version (None | str | Unset):
        notebook (None | str | Unset):
        parameter_schema (None | str | Unset):
        project (None | Project | Unset):
        runs (list[Run] | None | Unset):
        connections (list[TaskConnection] | None | Unset):
    """

    id: str
    name: str
    scenario: TaskScenario
    created_at: datetime.datetime
    updated_at: datetime.datetime
    user_id: str
    project_id: str
    description: None | str | Unset = UNSET
    version: None | str | Unset = UNSET
    notebook: None | str | Unset = UNSET
    parameter_schema: None | str | Unset = UNSET
    project: None | Project | Unset = UNSET
    runs: list[Run] | None | Unset = UNSET
    connections: list[TaskConnection] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.project import Project

        id = self.id

        name = self.name

        scenario = self.scenario.value

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        user_id = self.user_id

        project_id = self.project_id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        version: None | str | Unset
        if isinstance(self.version, Unset):
            version = UNSET
        else:
            version = self.version

        notebook: None | str | Unset
        if isinstance(self.notebook, Unset):
            notebook = UNSET
        else:
            notebook = self.notebook

        parameter_schema: None | str | Unset
        if isinstance(self.parameter_schema, Unset):
            parameter_schema = UNSET
        else:
            parameter_schema = self.parameter_schema

        project: dict[str, Any] | None | Unset
        if isinstance(self.project, Unset):
            project = UNSET
        elif isinstance(self.project, Project):
            project = self.project.to_dict()
        else:
            project = self.project

        runs: list[dict[str, Any]] | None | Unset
        if isinstance(self.runs, Unset):
            runs = UNSET
        elif isinstance(self.runs, list):
            runs = []
            for runs_type_0_item_data in self.runs:
                runs_type_0_item = runs_type_0_item_data.to_dict()
                runs.append(runs_type_0_item)

        else:
            runs = self.runs

        connections: list[dict[str, Any]] | None | Unset
        if isinstance(self.connections, Unset):
            connections = UNSET
        elif isinstance(self.connections, list):
            connections = []
            for connections_type_0_item_data in self.connections:
                connections_type_0_item = connections_type_0_item_data.to_dict()
                connections.append(connections_type_0_item)

        else:
            connections = self.connections

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "scenario": scenario,
                "created_at": created_at,
                "updated_at": updated_at,
                "user_id": user_id,
                "project_id": project_id,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if version is not UNSET:
            field_dict["version"] = version
        if notebook is not UNSET:
            field_dict["notebook"] = notebook
        if parameter_schema is not UNSET:
            field_dict["parameter_schema"] = parameter_schema
        if project is not UNSET:
            field_dict["project"] = project
        if runs is not UNSET:
            field_dict["runs"] = runs
        if connections is not UNSET:
            field_dict["connections"] = connections

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.project import Project
        from ..models.run import Run
        from ..models.task_connection import TaskConnection

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        scenario = TaskScenario(d.pop("scenario"))

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        user_id = d.pop("user_id")

        project_id = d.pop("project_id")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version = _parse_version(d.pop("version", UNSET))

        def _parse_notebook(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        notebook = _parse_notebook(d.pop("notebook", UNSET))

        def _parse_parameter_schema(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parameter_schema = _parse_parameter_schema(d.pop("parameter_schema", UNSET))

        def _parse_project(data: object) -> None | Project | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                project_type_0 = Project.from_dict(data)

                return project_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Project | Unset, data)

        project = _parse_project(d.pop("project", UNSET))

        def _parse_runs(data: object) -> list[Run] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                runs_type_0 = []
                _runs_type_0 = data
                for runs_type_0_item_data in _runs_type_0:
                    runs_type_0_item = Run.from_dict(runs_type_0_item_data)

                    runs_type_0.append(runs_type_0_item)

                return runs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Run] | None | Unset, data)

        runs = _parse_runs(d.pop("runs", UNSET))

        def _parse_connections(data: object) -> list[TaskConnection] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                connections_type_0 = []
                _connections_type_0 = data
                for connections_type_0_item_data in _connections_type_0:
                    connections_type_0_item = TaskConnection.from_dict(connections_type_0_item_data)

                    connections_type_0.append(connections_type_0_item)

                return connections_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TaskConnection] | None | Unset, data)

        connections = _parse_connections(d.pop("connections", UNSET))

        task_dto = cls(
            id=id,
            name=name,
            scenario=scenario,
            created_at=created_at,
            updated_at=updated_at,
            user_id=user_id,
            project_id=project_id,
            description=description,
            version=version,
            notebook=notebook,
            parameter_schema=parameter_schema,
            project=project,
            runs=runs,
            connections=connections,
        )

        task_dto.additional_properties = d
        return task_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
