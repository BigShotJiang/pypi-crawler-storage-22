from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="WorkspaceFile")


@_attrs_define
class WorkspaceFile:
    """Represents a file in the workspace.

    Attributes:
        name (str):
        path (str):
        size (int):
        is_directory (bool):
        extension (str):
        description (str):
    """

    name: str
    path: str
    size: int
    is_directory: bool
    extension: str
    description: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        path = self.path

        size = self.size

        is_directory = self.is_directory

        extension = self.extension

        description = self.description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "path": path,
                "size": size,
                "is_directory": is_directory,
                "extension": extension,
                "description": description,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        path = d.pop("path")

        size = d.pop("size")

        is_directory = d.pop("is_directory")

        extension = d.pop("extension")

        description = d.pop("description")

        workspace_file = cls(
            name=name,
            path=path,
            size=size,
            is_directory=is_directory,
            extension=extension,
            description=description,
        )

        workspace_file.additional_properties = d
        return workspace_file

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
