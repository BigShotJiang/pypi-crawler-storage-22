"""Tests for convexity_sdk – config, client, exceptions, and http transport."""

from __future__ import annotations

import os
from unittest.mock import patch

import httpx
import pytest

from convexity_sdk import (
    AsyncConvexityClient,
    AuthenticationError,
    ConflictError,
    ConvexityClient,
    ConvexityError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from convexity_sdk.config import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_BACKOFF,
    DEFAULT_TIMEOUT,
    resolve_config,
)
from convexity_sdk.http import SyncTransport

# ── Config tests ────────────────────────────────────────────────────────────


class TestResolveConfig:
    def test_defaults(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            cfg = resolve_config()
        assert cfg.api_key is None
        assert cfg.base_url == DEFAULT_BASE_URL
        assert cfg.timeout == DEFAULT_TIMEOUT
        assert cfg.max_retries == DEFAULT_MAX_RETRIES
        assert cfg.retry_backoff == DEFAULT_RETRY_BACKOFF

    def test_explicit_args_override_env(self) -> None:
        with patch.dict(os.environ, {"CONVEXITY_API_KEY": "env_key", "CONVEXITY_BASE_URL": "https://env.example.com"}):
            cfg = resolve_config(api_key="explicit_key", base_url="https://explicit.example.com")
        assert cfg.api_key == "explicit_key"
        assert cfg.base_url == "https://explicit.example.com"

    def test_env_vars(self) -> None:
        with patch.dict(os.environ, {"CONVEXITY_API_KEY": "cvx_test_key", "CONVEXITY_BASE_URL": "https://test.example.com/"}):
            cfg = resolve_config()
        assert cfg.api_key == "cvx_test_key"
        # Trailing slash is stripped
        assert cfg.base_url == "https://test.example.com"

    def test_custom_timeout_and_retries(self) -> None:
        cfg = resolve_config(timeout=60.0, max_retries=5, retry_backoff=2.0)
        assert cfg.timeout == 60.0
        assert cfg.max_retries == 5
        assert cfg.retry_backoff == 2.0


# ── Exception tests ─────────────────────────────────────────────────────────


class TestExceptions:
    def test_hierarchy(self) -> None:
        assert issubclass(AuthenticationError, ConvexityError)
        assert issubclass(PermissionError, ConvexityError)
        assert issubclass(NotFoundError, ConvexityError)
        assert issubclass(ConflictError, ConvexityError)
        assert issubclass(ValidationError, ConvexityError)
        assert issubclass(RateLimitError, ConvexityError)
        assert issubclass(ServerError, ConvexityError)

    def test_exception_attributes(self) -> None:
        err = NotFoundError("not found", status_code=404, method="GET", endpoint="/v1/foo")
        assert err.message == "not found"
        assert err.status_code == 404
        assert err.method == "GET"
        assert err.endpoint == "/v1/foo"
        assert "not found" in str(err)

    def test_rate_limit_retry_after(self) -> None:
        err = RateLimitError("slow down", retry_after=5.0)
        assert err.retry_after == 5.0
        assert err.status_code == 429

    def test_repr(self) -> None:
        err = ServerError("boom", status_code=503, method="POST", endpoint="/v1/bar")
        r = repr(err)
        assert "ServerError" in r
        assert "503" in r
        assert "POST" in r


# ── Client tests ─────────────────────────────────────────────────────────────


class TestConvexityClient:
    def test_default_base_url(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            client = ConvexityClient()
        assert client.base_url == DEFAULT_BASE_URL

    def test_explicit_base_url(self) -> None:
        client = ConvexityClient(base_url="https://custom.example.com")
        assert client.base_url == "https://custom.example.com"

    def test_repr(self) -> None:
        client = ConvexityClient(base_url="https://test.dev")
        assert "ConvexityClient" in repr(client)
        assert "test.dev" in repr(client)

    def test_context_manager(self) -> None:
        with ConvexityClient(base_url="https://test.dev") as client:
            assert client.base_url == "https://test.dev"

    def test_close(self) -> None:
        client = ConvexityClient()
        client.close()  # Should not raise


class TestAsyncConvexityClient:
    def test_default_base_url(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            client = AsyncConvexityClient()
        assert client.base_url == DEFAULT_BASE_URL

    def test_repr(self) -> None:
        client = AsyncConvexityClient(base_url="https://async.dev")
        assert "AsyncConvexityClient" in repr(client)

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        async with AsyncConvexityClient(base_url="https://async.dev") as client:
            assert client.base_url == "https://async.dev"


# ── HTTP Transport tests ────────────────────────────────────────────────────


class TestSyncTransport:
    def test_build_exception_404(self) -> None:
        response = httpx.Response(404, json={"detail": "Not found"}, request=httpx.Request("GET", "http://x/v1/foo"))
        exc = SyncTransport._build_exception(response, "GET", "/v1/foo")
        assert isinstance(exc, NotFoundError)
        assert exc.status_code == 404
        assert exc.method == "GET"
        assert exc.endpoint == "/v1/foo"

    def test_build_exception_401(self) -> None:
        response = httpx.Response(401, json={"detail": "Unauthorized"}, request=httpx.Request("GET", "http://x/v1/foo"))
        exc = SyncTransport._build_exception(response, "GET", "/v1/foo")
        assert isinstance(exc, AuthenticationError)

    def test_build_exception_429(self) -> None:
        response = httpx.Response(429, json={"detail": "Too many requests"}, headers={"Retry-After": "3"}, request=httpx.Request("GET", "http://x/v1/foo"))
        exc = SyncTransport._build_exception(response, "GET", "/v1/foo")
        assert isinstance(exc, RateLimitError)
        assert exc.retry_after == 3.0

    def test_build_exception_500(self) -> None:
        response = httpx.Response(500, json={"detail": "Internal error"}, request=httpx.Request("POST", "http://x/v1/bar"))
        exc = SyncTransport._build_exception(response, "POST", "/v1/bar")
        assert isinstance(exc, ServerError)
        assert exc.status_code == 500

    def test_build_exception_503(self) -> None:
        response = httpx.Response(503, text="Service Unavailable", request=httpx.Request("GET", "http://x/v1/baz"))
        exc = SyncTransport._build_exception(response, "GET", "/v1/baz")
        assert isinstance(exc, ServerError)

    def test_build_exception_422_list_detail(self) -> None:
        detail = [{"loc": ["body", "name"], "msg": "Field required", "type": "missing"}]
        response = httpx.Response(422, json={"detail": detail}, request=httpx.Request("POST", "http://x/v1/foo"))
        exc = SyncTransport._build_exception(response, "POST", "/v1/foo")
        assert isinstance(exc, ValidationError)

    def test_build_exception_unknown_status(self) -> None:
        response = httpx.Response(418, text="I'm a teapot", request=httpx.Request("GET", "http://x/brewing"))
        exc = SyncTransport._build_exception(response, "GET", "/brewing")
        assert isinstance(exc, ConvexityError)
        assert exc.status_code == 418


# ── Integration: transport + mock server ─────────────────────────────────────


class TestTransportIntegration:
    def test_successful_request(self) -> None:
        transport = SyncTransport(resolve_config(base_url="https://example.com", max_retries=1))
        mock_transport = httpx.MockTransport(lambda req: httpx.Response(200, json={"status": "ok"}))
        transport._client = httpx.Client(transport=mock_transport, base_url="https://example.com")

        response = transport.request("GET", "/v1/health")
        assert response.status_code == 200
        assert response.json() == {"status": "ok"}

    def test_non_retryable_error_raises_immediately(self) -> None:
        transport = SyncTransport(resolve_config(base_url="https://example.com", max_retries=3))
        mock_transport = httpx.MockTransport(lambda req: httpx.Response(404, json={"detail": "Not found"}))
        transport._client = httpx.Client(transport=mock_transport, base_url="https://example.com")

        with pytest.raises(NotFoundError) as exc_info:
            transport.request("GET", "/v1/things/123")
        assert exc_info.value.status_code == 404

    def test_retryable_error_retries_then_succeeds(self) -> None:
        call_count = 0

        def handler(req: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                return httpx.Response(503, text="Unavailable")
            return httpx.Response(200, json={"ok": True})

        transport = SyncTransport(resolve_config(base_url="https://example.com", max_retries=3, retry_backoff=0.01))
        mock_transport = httpx.MockTransport(handler)
        transport._client = httpx.Client(transport=mock_transport, base_url="https://example.com")

        response = transport.request("GET", "/v1/health")
        assert response.status_code == 200
        assert call_count == 3

    def test_retryable_error_exhausted_raises(self) -> None:
        transport = SyncTransport(resolve_config(base_url="https://example.com", max_retries=2, retry_backoff=0.01))
        mock_transport = httpx.MockTransport(lambda req: httpx.Response(502, text="Bad Gateway"))
        transport._client = httpx.Client(transport=mock_transport, base_url="https://example.com")

        with pytest.raises(ServerError):
            transport.request("GET", "/v1/health")
