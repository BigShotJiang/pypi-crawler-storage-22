"""Conviertlo - Media converter with Copilot AI (FFMPEG + ImageMagick)"""
__version__ = "0.1.0"
