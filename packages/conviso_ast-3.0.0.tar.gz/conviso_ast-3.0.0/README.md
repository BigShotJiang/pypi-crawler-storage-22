# AST

This is a command line tool to execute Conviso AST.

# Documentation
Please visit the [official documentation] for further information.

[official documentation]: <https://docs.convisoappsec.com/security-scans/conviso-ast/>
