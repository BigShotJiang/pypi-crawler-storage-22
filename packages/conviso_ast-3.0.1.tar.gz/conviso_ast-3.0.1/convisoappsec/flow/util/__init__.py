from .source_code_compressor import SourceCodeCompressor

__all__ = [
    'SourceCodeCompressor'
]
