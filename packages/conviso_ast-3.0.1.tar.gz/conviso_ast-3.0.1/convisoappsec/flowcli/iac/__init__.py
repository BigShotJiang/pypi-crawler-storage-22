from .entrypoint import iac

__all__ = ['iac']
