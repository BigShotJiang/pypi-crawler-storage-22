"""Model utilities."""
