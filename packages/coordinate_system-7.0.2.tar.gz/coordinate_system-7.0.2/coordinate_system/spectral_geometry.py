"""
Fourier Frame Field and Hilbert Space Spectral Geometry
=======================================================

A FourierFrame-based spectral geometry framework on Hilbert spaces.

Core ideas:
- Fourier frame = FourierFrame * e^{iθ} (phase rotation / Fourier transform)
- Conformal transform = FourierFrame * λ, λ ∈ ℝ⁺ (scaling)
- Intrinsic gradient operator G_μ = d/dx^μ log FourierFrame(x)
- Curvature R_{μν} = [G_μ, G_ν]
- Berry phase γ = ∮ G_μ dx^μ (geometric phase / parallel transport)
- Chern number c₁ = (1/2π) ∬ R_{μν} dS (topological invariant)

Mathematical framework:
- Hilbert space: Fourier analysis on L²(M)
- Spectral theory: Laplacian eigenvalue problems
- Fiber bundles: FourierFrame as a local section of the frame bundle
- Lie groups/algebras: intrinsic gradient operator forms a Lie algebra
- Heat kernel expansion: extraction of geometric invariants

Group correspondence:
- FourierFrame ↔ GL(1,ℂ) = ℂ× = U(1) × ℝ⁺
- Phase e^{iθ} ↔ U(1) (unit circle)
- Magnitude |Q| ↔ ℝ⁺ (positive scaling)

**Authors:** Pan Guojun
Date: 2025-12-04
Version: 6.0.3
**DOI:** https://doi.org/10.5281/zenodo.14435613
"""

__version__ = '6.0.3'

import numpy as np
from typing import List, Tuple, Dict, Optional, Union, Any, Callable
from dataclasses import dataclass
import warnings

# Import coordinate system types
try:
    from .coordinate_system import coord3, vec3, quat
except ImportError:
    try:
        from coordinate_system import coord3, vec3, quat
    except ImportError:
        # Lazy import for standalone usage
        coord3 = None
        vec3 = None
        quat = None

# Physical constants
HBAR = 1.0  # Reduced Planck constant (natural units)

# GPU availability check
try:
    import cupy as cp
    import cupyx.scipy.fft as cufft
    GPU_AVAILABLE = True
except ImportError:
    GPU_AVAILABLE = False
    cp = None
    cufft = None


# ============================================================
# Fourier Frame Algebra
# ============================================================

class FourierFrame:
    """
    FourierFrame: core spectral-geometry object on Hilbert space.

    Mathematical structure:
    FourierFrame ↔ GL(1,ℂ) = ℂ× = U(1) × ℝ⁺

    - Q ∈ ℂ× (nonzero complex)
    - Q = |Q| · e^{iθ}
      - Phase e^{iθ} ∈ U(1): Fourier transform (phase rotation)
      - Magnitude |Q| ∈ ℝ⁺: conformal scaling

    Key properties:
    - base_coord: underlying coord3 frame (optional)
    - Q: complex scale factor encoding phase and magnitude

    Key transforms:
    - FourierFrame * e^{iθ} = Fourier transform (θ = π/2 is the standard 90°)
    - FourierFrame * λ = conformal transform (λ ∈ ℝ⁺)
    - FourierFrame * FourierFrame = frame composition

    Hilbert-space meaning:
    - Fourier basis on L²(M)
    - Intrinsic gradient G_μ = d/dx^μ log Q(x)
    - Spectrum: Δφ_n = -λ_n φ_n
    - Heat kernel: K(x,y,t) = Σ_n e^{-λ_n t} φ_n(x) φ_n*(y)

    Geometric meaning:
    - Local section of the frame bundle F(M)
    - G_μ describes local rotation
    - Curvature R_{μν} = [G_μ, G_ν]
    - Berry phase γ = ∮ G_μ dx^μ (parallel transport)

    Relation to U3Frame:
    - FourierFrame: GL(1,ℂ), one complex DOF
    - U3Frame: U(3), nine real DOF
    - U(3) ⊃ U(1) as global phase subgroup
    """

    def __init__(self, base_coord=None, q_factor=1.0+0j):
        """
        Initialize a FourierFrame.

        Args:
            base_coord: base coordinate frame (coord3), or identity if None
            q_factor: complex scale factor Q ∈ ℂ× = GL(1,ℂ)
                      Q = |Q| · e^{iθ}
                      - phase e^{iθ}: Fourier transform
                      - magnitude |Q|: conformal scaling
        """
        if base_coord is None:
            if coord3 is not None:
                self.base = coord3.identity()
            else:
                self.base = None
        else:
            self.base = base_coord

        self.Q = complex(q_factor)  # Ensure complex
        self.dim = 3

    # -------------------- Complex frame properties --------------------

    @property
    def o(self):
        """Complex position vector."""
        if self.base is None:
            return None
        o_base = self.base.o
        # Complex extension: real part is position, imaginary part encodes phase
        return vec3(
            o_base.x * self.Q.real + 1j * o_base.x * self.Q.imag,
            o_base.y * self.Q.real + 1j * o_base.y * self.Q.imag,
            o_base.z * self.Q.real + 1j * o_base.z * self.Q.imag
        ) if vec3 else None

    @property
    def s(self):
        """Complex scale vector: s_Q = s_base · Q."""
        if self.base is None:
            return None
        s_base = self.base.s
        return vec3(
            s_base.x * self.Q.real + 1j * s_base.x * self.Q.imag,
            s_base.y * self.Q.real + 1j * s_base.y * self.Q.imag,
            s_base.z * self.Q.real + 1j * s_base.z * self.Q.imag
        ) if vec3 else None

    @property
    def phase(self):
        """Phase arg(Q)."""
        return np.angle(self.Q)

    @property
    def magnitude(self):
        """Magnitude |Q|."""
        return np.abs(self.Q)

    @property
    def det(self):
        """
        Determinant: Det(Frame).

        Used in the path-integral measure ∫ Dφ · Det[Frame] · exp(iS/ħ).
        """
        if self.base is None:
            return self.Q ** 3  # 3D frame
        s = self.base.s
        det_s = s.x * s.y * s.z
        return det_s * (self.Q ** 3)

    # -------------------- Frame operations --------------------

    def __mul__(self, other):
        """
        Frame multiplication: core transform operator.

        Supports:
        - Frame * complex: phase rotation / scaling (Fourier / conformal transform)
        - Frame * Frame: frame composition
        - Frame * vec3: vector transform
        """
        if isinstance(other, (int, float, complex)):
            # Scalar multiplication: Fourier / conformal transform
            new_Q = self.Q * other
            return FourierFrame(self.base, new_Q)

        elif isinstance(other, FourierFrame):
            # Frame composition
            if self.base is not None and other.base is not None:
                new_base = self.base * other.base
            else:
                new_base = self.base or other.base
            new_Q = self.Q * other.Q
            return FourierFrame(new_base, new_Q)

        elif vec3 is not None and isinstance(other, vec3):
            # Vector transform
            return vec3(
                other.x * self.Q.real,
                other.y * self.Q.real,
                other.z * self.Q.real
            )

        return NotImplemented

    def __rmul__(self, other):
        """Right multiplication."""
        return self.__mul__(other)

    def __truediv__(self, other):
        """Frame division (inverse transform)."""
        if isinstance(other, (int, float, complex)):
            return FourierFrame(self.base, self.Q / other)
        elif isinstance(other, FourierFrame):
            if self.base is not None and other.base is not None:
                new_base = self.base / other.base
            else:
                new_base = self.base
            return FourierFrame(new_base, self.Q / other.Q)
        return NotImplemented

    def __pow__(self, n):
        """Power operator for repeated transforms."""
        if isinstance(n, (int, float, complex)):
            return FourierFrame(self.base, self.Q ** n)
        return NotImplemented

    def __eq__(self, other):
        """Equality check."""
        if not isinstance(other, FourierFrame):
            return False
        return np.isclose(self.Q, other.Q)

    def __repr__(self):
        if self.base is not None:
            return f"FourierFrame(Q={self.Q:.4f}, o={self.base.o})"
        return f"FourierFrame(Q={self.Q:.4f})"

    # -------------------- Fourier transform --------------------

    def fourier_transform(self, theta: float = np.pi/2) -> 'FourierFrame':
        """
        Fourier transform: F_θ[FourierFrame] = FourierFrame · e^{iθ}.

        Args:
            theta: rotation angle, π/2 is the standard Fourier transform

        Returns:
            Transformed FourierFrame.

        Properties:
        - F^4 = I (four transforms return to identity)
        - F^2 = P (parity)
        """
        ft_factor = np.exp(1j * theta)
        return self * ft_factor

    def inverse_fourier_transform(self, theta: float = np.pi/2) -> 'FourierFrame':
        """Inverse Fourier transform: F^{-1} = F_{-θ}."""
        return self.fourier_transform(-theta)

    def conformal_transform(self, lambda_factor: float) -> 'FourierFrame':
        """
        Conformal transform: FourierFrame → FourierFrame · λ, λ ∈ ℝ⁺.

        Implements scaling while preserving angles.
        """
        return self * lambda_factor

    # -------------------- Classical geometric evolution --------------------

    def diffusion_evolution(self, t: float, kappa: float = 1.0) -> 'FourierFrame':
        """
        Diffusion evolution operator: e^{tΔ} FourierFrame.

        This is the solution operator of the classical heat equation ∂u/∂t = κΔu:
        - Δ is the Laplacian (geometric diffusion operator)
        - t is time (real time, not imaginary)
        - κ is the diffusion coefficient

        Form:
        FourierFrame(x, t) = e^{tκΔ} FourierFrame(x, 0)
                           = FourierFrame₀ · e^{-tκ|k|²} (momentum space)

        Notes:
        - Describes diffusion of geometric information over the manifold
        - Heat kernel K(x,y,t) = (4πκt)^{-d/2} e^{-|x-y|²/(4κt)}
        - Core tool in spectral geometry for extracting invariants

        This is a classical diffusion process (not quantum imaginary-time evolution).

        Args:
            t: diffusion time (must be > 0)
            kappa: diffusion coefficient (default 1.0)

        Returns:
            Diffused FourierFrame.

        Limitations:
        - Simplified: only the Q factor is diffused
        - Full implementation requires a Laplacian on the frame field
        - Numerical results depend on grid resolution
        """
        if t < 0:
            raise ValueError("Diffusion time t must be non-negative")

        # Simplified model: decay Q factor (high-frequency suppression)
        # Full implementation uses spectral representation of the frame field
        decay_factor = np.exp(-kappa * t * np.abs(self.Q)**2)
        evolved_Q = self.Q * decay_factor

        return FourierFrame(self.base, evolved_Q)

    @staticmethod
    def laplacian_from_field(frame_field: List[List['FourierFrame']],
                            i: int, j: int) -> complex:
        """
        Compute the Laplacian from a discrete frame field.

        Δ log FourierFrame ≈ (∇² log FourierFrame)
                           = ∂²/∂x² log Q + ∂²/∂y² log Q

        Args:
            frame_field: discrete frame field
            i, j: grid indices

        Returns:
            Laplacian result (complex).

        Numerical details:
        Use a 5-point stencil for second derivatives:
        Δf ≈ [f(i+1,j) + f(i-1,j) + f(i,j+1) + f(i,j-1) - 4f(i,j)] / h²
        """
        ny, nx = len(frame_field), len(frame_field[0])

        if i <= 0 or i >= ny - 1 or j <= 0 or j >= nx - 1:
            return 0.0 + 0j

        # Center point
        log_Q_center = np.log(frame_field[i][j].Q)

        # Four neighbors
        log_Q_xp = np.log(frame_field[i][j+1].Q)
        log_Q_xm = np.log(frame_field[i][j-1].Q)
        log_Q_yp = np.log(frame_field[i+1][j].Q)
        log_Q_ym = np.log(frame_field[i-1][j].Q)

        # 5-point Laplacian stencil (assume grid spacing h=1)
        laplacian = (log_Q_xp + log_Q_xm + log_Q_yp + log_Q_ym - 4*log_Q_center)

        return laplacian

    # -------------------- Spectral transform --------------------

    @staticmethod
    def spectral_transform_2d(field: np.ndarray, hbar: float = HBAR) -> np.ndarray:
        """
        2D spectral transform: position space → momentum space.

        Form:
        ψ̃(k) = ∫ e^{ikx/ħ} ψ(x) dx / √(2πħ)

        Args:
            field: input field, shape [ny, nx, ...] or [ny, nx]
            hbar: reduced Planck constant

        Returns:
            Momentum-space spectrum.
        """
        # FFT axes
        if field.ndim >= 2:
            axes = (0, 1)
        else:
            axes = None

        spectrum = np.fft.fft2(field, axes=axes)

        # Quantum normalization
        normalization = 1.0 / np.sqrt(2 * np.pi * hbar)
        return spectrum * normalization

    @staticmethod
    def inverse_spectral_transform_2d(spectrum: np.ndarray, hbar: float = HBAR) -> np.ndarray:
        """
        2D inverse spectral transform: momentum space → position space.

        Args:
            spectrum: momentum-space spectrum
            hbar: reduced Planck constant

        Returns:
            Position-space field.
        """
        if spectrum.ndim >= 2:
            axes = (0, 1)
        else:
            axes = None

        denormalization = np.sqrt(2 * np.pi * hbar)
        return np.fft.ifft2(spectrum * denormalization, axes=axes).real

    @staticmethod
    def spectral_transform_2d_gpu(field: np.ndarray, hbar: float = HBAR) -> np.ndarray:
        """GPU-accelerated 2D spectral transform."""
        if not GPU_AVAILABLE:
            raise RuntimeError("CuPy is unavailable; GPU acceleration not supported")

        field_gpu = cp.asarray(field)
        spectrum_gpu = cufft.fft2(field_gpu, axes=(0, 1))
        normalization = 1.0 / np.sqrt(2 * np.pi * hbar)
        spectrum_gpu *= normalization
        return cp.asnumpy(spectrum_gpu)

    @classmethod
    def from_coord_field(cls, coord_field: List[List], hbar: float = HBAR) -> 'FourierFrameSpectrum':
        """
        Create a spectral representation from a coordinate field.

        Applies spectral transforms to each component of the coordinate field.

        Args:
            coord_field: 2D coordinate field list [[coord3, ...], ...]
            hbar: reduced Planck constant

        Returns:
            FourierFrameSpectrum object.
        """
        ny = len(coord_field)
        nx = len(coord_field[0]) if ny > 0 else 0

        # Extract field components
        tensor_field = np.zeros((ny, nx, 12), dtype=np.float64)
        for i in range(ny):
            for j in range(nx):
                coord = coord_field[i][j]
                tensor_field[i, j, 0:3] = [coord.o.x, coord.o.y, coord.o.z]
                tensor_field[i, j, 3:6] = [coord.ux.x, coord.ux.y, coord.ux.z]
                tensor_field[i, j, 6:9] = [coord.uy.x, coord.uy.y, coord.uy.z]
                tensor_field[i, j, 9:12] = [coord.uz.x, coord.uz.y, coord.uz.z]

        # Spectral transform per component
        origin_spectrum = cls.spectral_transform_2d(tensor_field[..., 0:3], hbar)
        ux_spectrum = cls.spectral_transform_2d(tensor_field[..., 3:6], hbar)
        uy_spectrum = cls.spectral_transform_2d(tensor_field[..., 6:9], hbar)
        uz_spectrum = cls.spectral_transform_2d(tensor_field[..., 9:12], hbar)

        # Momentum grid
        kx = 2 * np.pi * np.fft.fftfreq(nx) / hbar
        ky = 2 * np.pi * np.fft.fftfreq(ny) / hbar

        return FourierFrameSpectrum(
            ux_spectrum=ux_spectrum,
            uy_spectrum=uy_spectrum,
            uz_spectrum=uz_spectrum,
            origin_spectrum=origin_spectrum,
            momentum_grid=(kx, ky),
            hbar=hbar
        )


# ============================================================
# Intrinsic Gradient Operator
# ============================================================

class IntrinsicGradient:
    """
    Intrinsic gradient operator G_μ = d/dx^μ log FourierFrame(x).

    Geometric meaning (classical spectral geometry):
    - Describes the local rotation rate of the frame (logarithmic covariant derivative)
    - Corresponds to the connection 1-form in Riemannian geometry
    - Non-commutativity [G_μ, G_ν] yields curvature

    Properties:
    - δFourierFrame = G_μ FourierFrame δx^μ (infinitesimal transform)
    - [G_μ, G_ν] = R_{μν} (curvature 2-form)
    - γ = ∮ G_μ dx^μ (geometric phase / parallel transport)
    - Δ = ∇² = ∂_μ ∂^μ (Laplacian)

    Relation to quantum theory:
    - Formally resembles a gauge connection, but here it is purely geometric
    - Berry phase here is a classical geometric phase, not a quantum effect
    - The framework stays within classical differential geometry
    """

    def __init__(self, frame_field: Union[Callable, List[List['FourierFrame']]]):
        """
        Initialize the intrinsic gradient operator.

        Args:
            frame_field: frame field, either a function or a discrete field
        """
        self.frame_field = frame_field
        self.is_discrete = isinstance(frame_field, list)

    def compute_at(self, position: Union[Tuple, int],
                   direction: int, delta: float = 1e-5) -> complex:
        """
        Compute the intrinsic gradient at a given position and direction.

        Args:
            position: coordinates (continuous) or indices (discrete)
            direction: direction index (0=x, 1=y, 2=z)
            delta: finite-difference step size

        Returns:
            Complex value of G_μ.
        """
        if self.is_discrete:
            return self._compute_discrete(position, direction)
        else:
            return self._compute_continuous(position, direction, delta)

    def _compute_discrete(self, idx: Tuple[int, int], direction: int) -> complex:
        """Intrinsic gradient for a discrete field."""
        i, j = idx
        ny, nx = len(self.frame_field), len(self.frame_field[0])

        # Central difference
        if direction == 0:  # x direction
            if j + 1 < nx and j - 1 >= 0:
                frame_forward = self.frame_field[i][j + 1]
                frame_backward = self.frame_field[i][j - 1]
                frame_center = self.frame_field[i][j]

                # G_x ≈ (log Q_{j+1} - log Q_{j-1}) / 2
                return (np.log(frame_forward.Q) - np.log(frame_backward.Q)) / 2.0

        elif direction == 1:  # y direction
            if i + 1 < ny and i - 1 >= 0:
                frame_forward = self.frame_field[i + 1][j]
                frame_backward = self.frame_field[i - 1][j]

                return (np.log(frame_forward.Q) - np.log(frame_backward.Q)) / 2.0

        return 0.0 + 0j

    def _compute_continuous(self, pos: Tuple, direction: int, delta: float) -> complex:
        """Intrinsic gradient for a continuous field."""
        pos_list = list(pos)

        # Forward and backward positions
        pos_forward = pos_list.copy()
        pos_backward = pos_list.copy()
        pos_forward[direction] += delta
        pos_backward[direction] -= delta

        frame_forward = self.frame_field(tuple(pos_forward))
        frame_backward = self.frame_field(tuple(pos_backward))

        # G_μ = d/dx^μ log Frame
        return (np.log(frame_forward.Q) - np.log(frame_backward.Q)) / (2 * delta)

    def commutator(self, pos: Union[Tuple, int],
                   dir1: int, dir2: int, delta: float = 1e-5) -> complex:
        """
        Compute the commutator [G_μ, G_ν] = curvature R_{μν}.

        Args:
            pos: position
            dir1, dir2: direction indices
            delta: finite-difference step

        Returns:
            Curvature component R_{μν}.
        """
        G_mu = self.compute_at(pos, dir1, delta)
        G_nu = self.compute_at(pos, dir2, delta)

        # Simplified: [G_μ, G_ν] ≈ G_μ G_ν - G_ν G_μ
        # For Abelian case (scalar Q), the commutator is zero
        # Full implementation must consider non-Abelian frame structure
        return G_mu * G_nu - G_nu * G_mu

    def laplacian(self, position: Union[Tuple[int, int], int]) -> complex:
        """
        Laplacian Δ = ∇² = ∂²/∂x² + ∂²/∂y².

        Applied to log FourierFrame:
        Δ log FourierFrame = ∂²/∂x² log Q + ∂²/∂y² log Q

        This is the core operator in spectral geometry, with eigenvalue problem:
        Δφ_n = -λ_n φ_n

        The spectrum encodes geometric information of the manifold.

        Args:
            position: grid indices (i, j) or index

        Returns:
            Laplacian result.

        Background:
        - The Laplacian is a natural differential operator on a Riemannian manifold
        - Its spectrum {λ_n} contains geometric invariants (Weyl law, heat kernel expansion)
        - "Can one hear the shape of a drum?" - Kac's question
        """
        if not self.is_discrete:
            raise NotImplementedError("Laplacian for continuous fields requires additional implementation")

        if isinstance(position, int):
            # 1D case (simplified)
            return 0.0 + 0j

        # Use FourierFrame static method
        return FourierFrame.laplacian_from_field(self.frame_field, position[0], position[1])


# ============================================================
# Curvature from Frames
# ============================================================

class CurvatureFromFrame:
    """
    Compute curvature from a frame field.

    Core formulas:
    - R_{μν} = [G_μ, G_ν] = ∂_μ G_ν - ∂_ν G_μ - [G_μ, G_ν]
    - Gaussian curvature K = -⟨[G_u, G_v] e_v, e_u⟩ / √det(g)
    - Mean curvature H = (1/2) Tr(R)
    """

    def __init__(self, frame_field: List[List['FourierFrame']]):
        """
        Initialize curvature calculator.

        Args:
            frame_field: discrete frame field
        """
        self.frame_field = frame_field
        self.gradient_op = IntrinsicGradient(frame_field)
        self.ny = len(frame_field)
        self.nx = len(frame_field[0]) if self.ny > 0 else 0

    def gaussian_curvature(self, i: int, j: int) -> float:
        """
        Compute Gaussian curvature.

        K = -⟨[G_u, G_v] e_v, e_u⟩ / √det(g)

        Args:
            i, j: grid indices

        Returns:
            Gaussian curvature value.
        """
        # Commutator [G_x, G_y]
        R_xy = self.gradient_op.commutator((i, j), 0, 1)

        # Simplified: K ≈ -Im(R_xy) for complex frames
        # Full implementation should compute the metric tensor
        return -R_xy.imag

    def mean_curvature(self, i: int, j: int) -> float:
        """
        Compute mean curvature.

        H = (1/2) Tr(R)

        Args:
            i, j: grid indices

        Returns:
            Mean curvature value.
        """
        # Simplified implementation
        R_xx = self.gradient_op.commutator((i, j), 0, 0)
        R_yy = self.gradient_op.commutator((i, j), 1, 1)

        return 0.5 * (R_xx.real + R_yy.real)

    def riemann_curvature_tensor(self, i: int, j: int) -> np.ndarray:
        """
        Compute the Riemann curvature tensor.

        R_{ijkl} = -√det(g) ⟨[G_i, G_j] e_l, e_k⟩

        Args:
            i, j: grid indices

        Returns:
            Curvature tensor (2×2 matrix, simplified 2D case).
        """
        R = np.zeros((2, 2), dtype=complex)

        R[0, 0] = self.gradient_op.commutator((i, j), 0, 0)
        R[0, 1] = self.gradient_op.commutator((i, j), 0, 1)
        R[1, 0] = self.gradient_op.commutator((i, j), 1, 0)
        R[1, 1] = self.gradient_op.commutator((i, j), 1, 1)

        return R


# ============================================================
# Geometric Phase
# ============================================================

class BerryPhase:
    """
    Berry phase computation.

    Geometric phase formula:
    γ = ∮_C G_μ dx^μ = ∮_C (∂_μ Frame · Frame^{-1}) dx^μ

    Properties:
    - Independent of path parametrization
    - Depends only on the geometry of the path
    - Equals surface integral of curvature (Stokes' theorem)
    """

    def __init__(self, gradient_operator: IntrinsicGradient):
        """
        Initialize the Berry phase calculator.

        Args:
            gradient_operator: intrinsic gradient operator
        """
        self.gradient_op = gradient_operator

    def compute_along_path(self, path: List[Tuple], closed: bool = True) -> complex:
        """
        Compute Berry phase along a path.

        γ = ∮_C G_μ dx^μ

        Args:
            path: list of path points [(i1, j1), (i2, j2), ...]
            closed: whether to close the path

        Returns:
            Geometric phase (complex).
        """
        if len(path) < 2:
            return 0.0 + 0j

        phase = 0.0 + 0j

        for k in range(len(path) - 1):
            pos_current = path[k]
            pos_next = path[k + 1]

            # Determine direction
            dx = pos_next[0] - pos_current[0]
            dy = pos_next[1] - pos_current[1]

            # Compute gradient component
            if abs(dx) > abs(dy):
                direction = 0  # x direction
                step = dx
            else:
                direction = 1  # y direction
                step = dy

            # G_μ dx^μ
            G_mu = self.gradient_op.compute_at(pos_current, direction)
            phase += G_mu * step

        # Close the path
        if closed and len(path) > 2:
            pos_last = path[-1]
            pos_first = path[0]

            dx = pos_first[0] - pos_last[0]
            dy = pos_first[1] - pos_last[1]

            if abs(dx) > abs(dy):
                direction = 0
                step = dx
            else:
                direction = 1
                step = dy

            G_mu = self.gradient_op.compute_at(pos_last, direction)
            phase += G_mu * step

        return phase


# ============================================================
# Chern Number
# ============================================================

class ChernNumber:
    """
    First Chern number computation.

    Topological invariant:
    c₁ = (1/2π) ∬_M R_{μν} dS^{μν}
       = (1/2π) ∬_M Tr([G_μ, G_ν]) dS^{μν}

    Physical meaning:
    - Characterizes the topology of the fiber bundle
    - Topological invariant in the quantum Hall effect
    - Related to Berry phase via Stokes' theorem
    """

    def __init__(self, curvature_calculator: CurvatureFromFrame):
        """
        Initialize the Chern number calculator.

        Args:
            curvature_calculator: curvature calculator
        """
        self.curvature = curvature_calculator

    def compute(self) -> float:
        """
        Compute the first Chern number.

        c₁ = (1/2π) Σ_{ij} R_{xy}(i,j) ΔS

        Returns:
            Chern number (real).
        """
        total = 0.0 + 0j

        ny, nx = self.curvature.ny, self.curvature.nx

        for i in range(1, ny - 1):
            for j in range(1, nx - 1):
                # Curvature R_{xy}
                R_xy = self.curvature.gradient_op.commutator((i, j), 0, 1)
                total += R_xy

        # Normalize
        c1 = total / (2 * np.pi)

        # Chern number should be an integer (topological invariant)
        return round(c1.real)


# ============================================================
# Spectral Decomposition
# ============================================================

class SpectralDecomposition:
    """
    Spectral decomposition of the Laplacian (classical spectral geometry).

    Framework:
    Laplacian eigenvalue problem:
        Δφ_n = -λ_n φ_n
        ∫ φ_m φ_n dV = δ_{mn}

    Spectral decomposition theorem:
        Δ = -Σ_n λ_n |φ_n⟩⟨φ_n|

    FourierFrame as eigenstate basis:
        FourierFrame(x) = Σ_n c_n φ_n(x) FourierFrame_n

    Where:
    - φ_n(x) are scalar Laplacian eigenfunctions
    - FourierFrame_n are frame eigenstates
    - c_n = ⟨φ_n | FourierFrame⟩ are expansion coefficients

    Geometric meaning:
    - {λ_n} encodes geometry (ShapeDNA)
    - low-frequency modes (small λ) capture large-scale features
    - high-frequency modes (large λ) capture local detail

    Weyl asymptotics:
        N(λ) ~ (ω_d / (2π)^d) Vol(M) λ^{d/2}

    Applications:
    - ShapeDNA: spectral signature for shape recognition
    - Spectral distance: geometric distance between manifolds
    - Multiscale analysis: geometry in different frequency bands
    - Heat kernel trace: Tr(e^{tΔ}) = Σ_n e^{-tλ_n}
    """

    def __init__(self, frame_field: Union[List[List['FourierFrame']], 'FourierFrameSpectrum']):
        """
        Initialize spectral decomposition.

        Args:
            frame_field: FourierFrame field or its spectral representation
        """
        if isinstance(frame_field, list):
            # Discrete frame field
            self.frame_field = frame_field
            self.gradient_op = IntrinsicGradient(frame_field)
            self.ny = len(frame_field)
            self.nx = len(frame_field[0]) if self.ny > 0 else 0
            self.spectrum = None
        else:
            # Spectral representation
            self.spectrum = frame_field
            self.frame_field = None
            self.gradient_op = None
            self.ny, self.nx = frame_field.shape

        self._eigenvalues = None
        self._eigenvectors = None

    def compute_eigenspectrum(self) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """
        Compute the Laplacian eigenspectrum.

        Returns:
            (eigenvalues, eigenvectors)
            - eigenvalues: λ_n array (descending)
            - eigenvectors: eigenfunctions φ_n (may be None in simplified mode)

        Numerical notes:
        - Spectral representation: eigenvalues correspond to k² = |k|²
        - Discrete field: requires Laplacian matrix and numerical solve
        """
        if self._eigenvalues is not None:
            return self._eigenvalues, self._eigenvectors

        if self.spectrum is not None:
            # Spectral representation: eigenvalues = k²
            kx, ky = self.spectrum.momentum_grid
            k2 = kx[:, None]**2 + ky[None, :]**2

            # Flatten and sort (descending)
            eigenvalues = np.sort(k2.flatten())[::-1]

            self._eigenvalues = eigenvalues
            self._eigenvectors = None

        elif self.frame_field is not None:
            # Discrete field: approximate eigenvalues
            # Full implementation needs Laplacian matrix and numerical solve
            eigenvalues_list = []

            for i in range(1, self.ny - 1):
                for j in range(1, self.nx - 1):
                    lap = self.gradient_op.laplacian((i, j))
                    eigenvalues_list.append(abs(lap))

            eigenvalues = np.sort(np.array(eigenvalues_list))[::-1]
            self._eigenvalues = eigenvalues
            self._eigenvectors = None

        return self._eigenvalues, self._eigenvectors

    def expand_frame_in_eigenbasis(self, frame: 'FourierFrame',
                                   n_modes: int = 10) -> np.ndarray:
        """
        Expand FourierFrame in the eigenbasis.

        FourierFrame = Σ_n c_n FourierFrame_n

        Args:
            frame: FourierFrame to expand
            n_modes: number of modes

        Returns:
            Expansion coefficients c_n.

        Notes:
        c_n = ∫ φ_n*(x) FourierFrame(x) dV

        Simplified implementation uses Fourier coefficients as an approximation.
        """
        eigenvalues, _ = self.compute_eigenspectrum()

        # Simplified: use FourierFrame Q factor
        coefficients = np.zeros(n_modes, dtype=complex)
        q_value = frame.Q

        for n in range(min(n_modes, len(eigenvalues))):
            # Simplified projection: c_n ∝ Q / √λ_n
            if eigenvalues[n] > 0:
                coefficients[n] = q_value / np.sqrt(eigenvalues[n])

        return coefficients

    def reconstruct_from_modes(self, coefficients: np.ndarray,
                               base_frame: 'FourierFrame') -> 'FourierFrame':
        """
        Reconstruct FourierFrame from eigenmodes.

        FourierFrame = Σ_n c_n FourierFrame_n

        Args:
            coefficients: expansion coefficients
            base_frame: base frame

        Returns:
            Reconstructed FourierFrame.
        """
        eigenvalues, _ = self.compute_eigenspectrum()

        reconstructed_Q = 0.0 + 0j
        for n in range(len(coefficients)):
            if n < len(eigenvalues) and eigenvalues[n] > 0:
                reconstructed_Q += coefficients[n] * np.sqrt(eigenvalues[n])

        return FourierFrame(base_frame.base, reconstructed_Q)

    def weyl_counting(self, lambda_threshold: float) -> int:
        """
        Weyl asymptotic counting function.

        N(λ) = #{n : λ_n < λ}  (number of eigenvalues below λ)

        Weyl law:
        N(λ) ~ (ω_d / (2π)^d) Vol(M) λ^{d/2}  (λ → ∞)

        For 2D manifolds: N(λ) ~ (1/4π) Area(M) λ

        Args:
            lambda_threshold: eigenvalue threshold λ

        Returns:
            N(λ) - eigenvalue count
        """
        eigenvalues, _ = self.compute_eigenspectrum()
        return int(np.sum(eigenvalues < lambda_threshold))

    def shape_dna(self, n_modes: int = 50) -> np.ndarray:
        """
        ShapeDNA: spectral signature of a manifold.

        The first n eigenvalues {λ_1, λ_2, ..., λ_n} encode geometric shape
        (up to isospectral non-isometries).

        Classic question in spectral geometry:
        "Can one hear the shape of a drum?" - Mark Kac (1966)

        For 2D manifolds, spectra often distinguish shapes, with known counterexamples
        (Gordon-Webb-Wolpert, 1992).

        Args:
            n_modes: number of modes (default 50)

        Returns:
            Spectral signature of the first n eigenvalues.

        Applications:
        - Shape recognition and retrieval
        - Geometric similarity metrics
        - Topological invariant extraction
        """
        eigenvalues, _ = self.compute_eigenspectrum()
        return eigenvalues[:n_modes]


# ============================================================
# Heat Kernel
# ============================================================

class HeatKernel:
    """
    Heat kernel: fundamental solution of the heat equation (classical spectral geometry).

    Definition:
    ∂u/∂t = Δu (heat equation)
    K(x, y, t) satisfies ∂K/∂t = Δ_x K, with K(x,y,0) = δ(x-y)

    Spectral expansion:
    K(x, y, t) = Σ_n e^{-λ_n t} φ_n(x) φ_n(y)

    where {λ_n, φ_n} are eigenpairs of the Laplacian Δφ_n = -λ_n φ_n.

    Heat trace asymptotics (Minakshisundaram-Pleijel):
    Tr(e^{tΔ}) ~ (4πt)^{-d/2} Σ_k a_k t^k

    Heat kernel coefficients {a_k} encode geometric invariants:
    - a₀ = Vol(M) (volume)
    - a₁ ∝ ∫ R dV (curvature integral)
    - a₂ ∝ ∫ (R² + other invariants) dV

    FourierFrame basis:
    FourierFrame(x, t) = ∫ K(x, y, t) FourierFrame(y, 0) dy
                       = e^{tΔ} FourierFrame(x, 0)

    Relation to quantum theory:
    - Formally analogous to imaginary-time propagators (Wick rotation)
    - Here it is purely geometric diffusion, not quantum evolution
    - No state vectors or operator expectations
    - Suitable for classical numerical computation

    Applications:
    - Shape recognition (ShapeDNA)
    - Geometric invariant extraction
    - Multiscale geometric analysis
    - Spectral distance between manifolds
    """

    def __init__(self, frame_field: Union[List[List['FourierFrame']], 'FourierFrameSpectrum']):
        """
        Initialize the heat kernel.

        Args:
            frame_field: discrete FourierFrame field or its spectral representation
        """
        if isinstance(frame_field, list):
            # Discrete frame field
            self.frame_field = frame_field
            self.gradient_op = IntrinsicGradient(frame_field)
            self.ny = len(frame_field)
            self.nx = len(frame_field[0]) if self.ny > 0 else 0
            self.spectrum = None
        else:
            # Spectral representation
            self.spectrum = frame_field
            self.frame_field = None
            self.gradient_op = None
            self.ny, self.nx = frame_field.shape

    def evolution_operator(self, t: float, kappa: float = 1.0) -> Union[np.ndarray, List[List['FourierFrame']]]:
        """
        Heat kernel evolution operator: e^{tκΔ} FourierFrame.

        Computes the diffused frame field at time t.

        Args:
            t: diffusion time (>0)
            kappa: diffusion coefficient (default 1.0)

        Returns:
            Evolved frame field.

        In frequency domain:
        FourierFrame(k, t) = e^{-κt|k|²} FourierFrame(k, 0)

        This suppresses high frequencies (low-pass filtering), i.e., spatial smoothing.
        """
        if t < 0:
            raise ValueError("Diffusion time must be non-negative")

        if self.frame_field is not None:
            # Discrete field: pointwise evolution
            evolved_field = []
            for i in range(self.ny):
                row = []
                for j in range(self.nx):
                    evolved_frame = self.frame_field[i][j].diffusion_evolution(t, kappa)
                    row.append(evolved_frame)
                evolved_field.append(row)
            return evolved_field

        elif self.spectrum is not None:
            # Spectral representation: frequency-domain decay
            kx, ky = self.spectrum.momentum_grid
            k2 = kx[:, None]**2 + ky[None, :]**2

            # e^{-κt k²} decay factor
            decay = np.exp(-kappa * t * k2)

            # Apply to each component
            evolved_spectrum = FourierFrameSpectrum(
                ux_spectrum=self.spectrum.ux_spectrum * decay[..., None],
                uy_spectrum=self.spectrum.uy_spectrum * decay[..., None],
                uz_spectrum=self.spectrum.uz_spectrum * decay[..., None],
                origin_spectrum=self.spectrum.origin_spectrum * decay[..., None],
                momentum_grid=self.spectrum.momentum_grid,
                hbar=self.spectrum.hbar
            )
            return evolved_spectrum

        else:
            raise ValueError("Provide a frame field or spectrum")

    def trace(self, t: float, kappa: float = 1.0) -> float:
        """
        Heat trace: Tr(e^{tκΔ}) = Σ_n e^{-κt λ_n}.

        This aggregates spectral information of the manifold.

        Args:
            t: diffusion time
            kappa: diffusion coefficient

        Returns:
            Heat trace value.
        """
        if self.spectrum is not None:
            # Use spectral representation
            density = self.spectrum.spectral_density()
            kx, ky = self.spectrum.momentum_grid
            k2 = kx[:, None]**2 + ky[None, :]**2

            # Tr(e^{-κt Δ}) = Σ e^{-κt k²}
            trace_val = np.sum(np.exp(-kappa * t * k2))
            return float(trace_val)

        elif self.frame_field is not None:
            # Simplified estimate: use frame-field "energy"
            total = 0.0
            for i in range(self.ny):
                for j in range(self.nx):
                    laplacian = self.gradient_op.laplacian((i, j))
                    # e^{-t λ} ≈ 1 - tλ (small-t approximation)
                    total += np.exp(-kappa * t * abs(laplacian))
            return total

        return 0.0

    def asymptotic_expansion(self, t: float, kappa: float = 1.0, order: int = 2) -> float:
        """
        Asymptotic expansion of heat trace (Minakshisundaram-Pleijel).

        Tr(e^{tκΔ}) ~ (4πκt)^{-d/2} [a₀ + a₁(κt) + a₂(κt)² + ...]

        Args:
            t: diffusion time (small-t asymptotic)
            kappa: diffusion coefficient
            order: expansion order (default 2)

        Returns:
            Asymptotic estimate.

        Geometric meaning:
        - a₀ = Vol(M) - manifold volume
        - a₁ ∝ ∫ R dV - scalar curvature integral
        - a₂ ∝ ∫ (R² - |Ric|² + ...) dV - higher-order invariants
        """
        d = 2  # 2D manifold
        prefactor = (4 * np.pi * kappa * t) ** (-d / 2)

        # Estimate heat kernel coefficients
        a0 = float(self.ny * self.nx)  # volume (grid points)

        # a₁ needs curvature information
        if self.gradient_op is not None:
            curvature_sum = 0.0
            for i in range(1, self.ny - 1):
                for j in range(1, self.nx - 1):
                    R_xy = self.gradient_op.commutator((i, j), 0, 1)
                    curvature_sum += abs(R_xy)
            a1 = curvature_sum / 6.0
        else:
            a1 = 0.0

        a2 = 0.0  # Simplified

        # Asymptotic series
        expansion = a0
        if order >= 1:
            expansion += a1 * (kappa * t)
        if order >= 2:
            expansion += a2 * (kappa * t)**2

        return prefactor * expansion


# ============================================================
# Frequency Projection
# ============================================================

class FrequencyProjection:
    """
    Geometric frequency projection operator.

    ω_n = √|κ_n| · sign(κ_n)
    P_Ω = Σ_{n: ω_n ∈ Ω} |Frame_n⟩⟨Frame_n|

    Applications:
    - Band filtering
    - Multiscale analysis
    - Frequency-domain wavefunctions
    """

    def __init__(self, spectral_decomposition: SpectralDecomposition):
        """
        Initialize frequency projection.

        Args:
            spectral_decomposition: spectral decomposition
        """
        self.spectral = spectral_decomposition

    def compute_frequencies(self) -> np.ndarray:
        """
        Compute geometric frequencies: ω_n = √|κ_n| · sign(κ_n).

        Returns:
            Frequency array.
        """
        eigenvalues, _ = self.spectral.compute_eigenspectrum()
        frequencies = np.sqrt(np.abs(eigenvalues)) * np.sign(eigenvalues)
        return frequencies

    def project_to_band(self, omega_min: float, omega_max: float) -> 'FrequencyBandState':
        """
        Project onto band [ω_min, ω_max].

        Args:
            omega_min, omega_max: band limits

        Returns:
            Band state.
        """
        frequencies = self.compute_frequencies()
        mask = (frequencies >= omega_min) & (frequencies <= omega_max)

        selected_indices = np.where(mask)[0]

        return FrequencyBandState(
            frequency_range=(omega_min, omega_max),
            mode_indices=selected_indices,
            projection_operator=self
        )


@dataclass
class FrequencyBandState:
    """Band-limited wavefunction."""
    frequency_range: Tuple[float, float]
    mode_indices: np.ndarray
    projection_operator: FrequencyProjection

    def wavefunction(self, amplitudes: np.ndarray, phases: np.ndarray) -> complex:
        """
        Ψ_Ω = Σ_{n ∈ Ω} a_n Frame_n e^{iθ_n}

        Args:
            amplitudes: amplitude array
            phases: phase array

        Returns:
            Wavefunction value.
        """
        psi = 0.0 + 0j
        for idx, amp, phase in zip(self.mode_indices, amplitudes, phases):
            psi += amp * np.exp(1j * phase)
        return psi


# ============================================================
# Spectral data structures
# ============================================================

@dataclass
class FourierFrameSpectrum:
    """
    FourierFrame spectrum: coordinate field in momentum space.

    Stores Fourier spectra of each coordinate component.
    """
    ux_spectrum: np.ndarray       # x-axis basis spectrum
    uy_spectrum: np.ndarray       # y-axis basis spectrum
    uz_spectrum: np.ndarray       # z-axis basis spectrum
    origin_spectrum: np.ndarray   # origin position spectrum
    momentum_grid: Tuple[np.ndarray, np.ndarray]  # (kx, ky)
    hbar: float = HBAR

    def __post_init__(self):
        """Validate dimension consistency."""
        shapes = [
            self.ux_spectrum.shape,
            self.uy_spectrum.shape,
            self.uz_spectrum.shape,
            self.origin_spectrum.shape
        ]
        if not all(s == shapes[0] for s in shapes):
            raise ValueError("All spectral components must have the same shape")

    @property
    def shape(self) -> Tuple[int, int]:
        """Spatial shape of the spectrum."""
        return self.ux_spectrum.shape[:2]

    def total_energy(self) -> float:
        """Total energy E = ∫ |ψ̃(k)|² dk."""
        return float(
            np.sum(np.abs(self.ux_spectrum)**2) +
            np.sum(np.abs(self.uy_spectrum)**2) +
            np.sum(np.abs(self.uz_spectrum)**2) +
            np.sum(np.abs(self.origin_spectrum)**2)
        )

    def spectral_density(self) -> np.ndarray:
        """Spectral density ρ(k) = Σ_μ |ψ̃_μ(k)|²."""
        density = (
            np.abs(self.ux_spectrum)**2 +
            np.abs(self.uy_spectrum)**2 +
            np.abs(self.uz_spectrum)**2 +
            np.abs(self.origin_spectrum)**2
        )
        return np.mean(density, axis=-1) if density.ndim > 2 else density

    def radial_average(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Radial average spectrum (ShapeDNA).

        Returns:
            (k_bins, radial_spectrum)
        """
        kx, ky = self.momentum_grid
        k_mag = np.sqrt(kx[:, None]**2 + ky[None, :]**2)

        density = self.spectral_density()

        k_max = np.max(k_mag)
        k_bins = np.linspace(0, k_max, 50)
        radial_avg = np.zeros(len(k_bins))

        for i in range(len(k_bins) - 1):
            mask = (k_mag >= k_bins[i]) & (k_mag < k_bins[i + 1])
            if np.any(mask):
                radial_avg[i] = np.mean(density[mask])

        return k_bins, radial_avg

    def to_coord_field(self) -> List[List]:
        """
        Inverse transform: spectrum → coordinate field.

        Returns:
            2D coordinate field list.
        """
        ny, nx = self.shape

        origin_field = Frame.inverse_spectral_transform_2d(self.origin_spectrum, self.hbar)
        ux_field = Frame.inverse_spectral_transform_2d(self.ux_spectrum, self.hbar)
        uy_field = Frame.inverse_spectral_transform_2d(self.uy_spectrum, self.hbar)
        uz_field = Frame.inverse_spectral_transform_2d(self.uz_spectrum, self.hbar)

        coord_field = []
        for i in range(ny):
            row = []
            for j in range(nx):
                o = vec3(origin_field[i, j, 0], origin_field[i, j, 1], origin_field[i, j, 2])
                ux = vec3(ux_field[i, j, 0], ux_field[i, j, 1], ux_field[i, j, 2])
                uy = vec3(uy_field[i, j, 0], uy_field[i, j, 1], uy_field[i, j, 2])
                uz = vec3(uz_field[i, j, 0], uz_field[i, j, 1], uz_field[i, j, 2])

                c = coord3(o, quat(1, 0, 0, 0), vec3(1, 1, 1))
                c.ux, c.uy, c.uz = ux, uy, uz
                row.append(c)
            coord_field.append(row)

        return coord_field


# ============================================================
# Convenience functions
# ============================================================

def spectral_transform(coord_field: List[List],
                       hbar: float = HBAR,
                       use_gpu: bool = False) -> FourierFrameSpectrum:
    """
    Coordinate field spectral transform.

    Args:
        coord_field: 2D coordinate field
        hbar: reduced Planck constant
        use_gpu: whether to use GPU acceleration

    Returns:
        FourierFrameSpectrum object.
    """
    return FourierFrame.from_coord_field(coord_field, hbar)


def inverse_spectral_transform(spectrum: FourierFrameSpectrum) -> List[List]:
    """
    Inverse spectral transform.

    Args:
        spectrum: FourierFrameSpectrum object

    Returns:
        Reconstructed coordinate field.
    """
    return spectrum.to_coord_field()


# ============================================================
# Demonstration
# ============================================================

def demonstrate():
    """Demonstrate FourierFrame algebra and spectral geometry."""
    print("=" * 70)
    print("FourierFrame Field & Spectral Geometry")
    print("=" * 70)

    # 1. Create base FourierFrame
    if coord3 is not None:
        base_frame = coord3.from_position(vec3(1, 0, 0))
        frame = FourierFrame(base_frame, q_factor=1.0+0.5j)
    else:
        frame = FourierFrame(q_factor=1.0+0.5j)

    print(f"\n1. Base FourierFrame: {frame}")
    print(f"   Phase: {frame.phase:.4f} rad")
    print(f"   Magnitude: {frame.magnitude:.4f}")
    print(f"   Determinant: {frame.det:.4f}")

    # 2. Fourier transform
    print("\n2. Fourier transform:")
    ft = frame.fourier_transform()
    print(f"   F[FourierFrame] = {ft}")
    print(f"   F^4[FourierFrame] ≈ FourierFrame: {frame.fourier_transform(2*np.pi)}")

    # 3. Conformal transform
    print("\n3. Conformal transform:")
    conf = frame.conformal_transform(2.0)
    print(f"   λ=2: {conf}")

    # 4. Frame composition
    print("\n4. Frame composition:")
    frame2 = FourierFrame(q_factor=0.5+0.5j)
    composed = frame * frame2
    print(f"   FourierFrame1 * FourierFrame2 = {composed}")

    # 5. Intrinsic gradient operator
    print("\n5. Intrinsic gradient operator:")
    # Create a simple frame field
    frame_field = [[FourierFrame(q_factor=1.0 + 0.1j*(i+j)) for j in range(5)] for i in range(5)]
    grad_op = IntrinsicGradient(frame_field)
    G_x = grad_op.compute_at((2, 2), 0)
    G_y = grad_op.compute_at((2, 2), 1)
    print(f"   G_x(2,2) = {G_x:.4f}")
    print(f"   G_y(2,2) = {G_y:.4f}")

    # 6. Curvature computation
    print("\n6. Curvature computation:")
    curvature_calc = CurvatureFromFrame(frame_field)
    K = curvature_calc.gaussian_curvature(2, 2)
    H = curvature_calc.mean_curvature(2, 2)
    print(f"   Gaussian curvature K = {K:.6f}")
    print(f"   Mean curvature H = {H:.6f}")

    # 7. Berry phase
    print("\n7. Berry phase:")
    berry = BerryPhase(grad_op)
    path = [(1, 1), (1, 3), (3, 3), (3, 1), (1, 1)]
    gamma = berry.compute_along_path(path, closed=True)
    print(f"   γ = ∮ G_μ dx^μ = {gamma:.4f}")

    # 8. Chern number
    print("\n8. Chern number:")
    chern = ChernNumber(curvature_calc)
    c1 = chern.compute()
    print(f"   First Chern number c₁ = {c1}")

    print("\n" + "=" * 70)
    print("Core formula summary:")
    print("  - G_μ = d/dx^μ log FourierFrame(x)  [intrinsic gradient]")
    print("  - R_{μν} = [G_μ, G_ν]  [curvature]")
    print("  - FourierFrame * e^{iθ} = Fourier transform")
    print("  - FourierFrame * λ = conformal transform")
    print("  - γ = ∮ G_μ dx^μ  [Berry phase]")
    print("  - c₁ = (1/2π) ∬ R_{μν} dS  [Chern number]")
    print("=" * 70)


# ============================================================
# Exports
# ============================================================

__all__ = [
    # Core classes
    'FourierFrame',
    'FourierFrameSpectrum',

    # Spectral geometry core
    'IntrinsicGradient',
    'CurvatureFromFrame',
    'BerryPhase',
    'ChernNumber',
    'SpectralDecomposition',
    'HeatKernel',
    'FrequencyProjection',
    'FrequencyBandState',

    # Convenience functions
    'spectral_transform',
    'inverse_spectral_transform',

    # Constants
    'HBAR',
    'GPU_AVAILABLE',
]


if __name__ == "__main__":
    demonstrate()
