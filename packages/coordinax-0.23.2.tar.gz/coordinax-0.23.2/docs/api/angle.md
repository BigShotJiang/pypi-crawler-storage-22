# `coordinax.angle`

```{eval-rst}

.. currentmodule:: coordinax.angle

.. automodule:: coordinax.angle
    :exclude-members: aval, default, materialise, enable_materialise, Parallax

.. autoclass:: Parallax
    :members:
    :exclude-members: aval, default, materialise, enable_materialise
    :undoc-members:
    :show-inheritance:
    :noindex:

```
