# `coordinax` library

```{eval-rst}

.. currentmodule:: coordinax

.. automodule:: coordinax
    :exclude-members: aval, default, materialise, enable_materialise
    :noindex:

```

```{toctree}
:maxdepth: 1
:titlesonly:
:hidden:
:caption: API submodules
:glob:

*
```
