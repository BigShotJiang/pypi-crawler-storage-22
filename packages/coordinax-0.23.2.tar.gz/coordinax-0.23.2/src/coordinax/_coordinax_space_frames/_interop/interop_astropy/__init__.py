"""Coordinax interop with Astropy package."""

__all__: tuple[str, ...] = ()

from . import frames  # noqa: F401
