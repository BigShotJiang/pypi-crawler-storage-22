"""Coordinax package."""

from . import promotion_rule  # noqa: F401
