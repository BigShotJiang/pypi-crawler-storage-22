"""Abstract Cartesian class."""

__all__ = ("AbstractCartesian",)


class AbstractCartesian:
    """ABC to indicate a Cartesian class."""
