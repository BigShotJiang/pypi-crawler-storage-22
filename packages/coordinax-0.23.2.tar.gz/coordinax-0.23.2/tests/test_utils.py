"""Test :mod:`coordinax.utils`."""
