"""Architecture module for CoordMCP."""
