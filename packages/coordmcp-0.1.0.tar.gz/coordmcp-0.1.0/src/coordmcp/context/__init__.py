"""Context module for CoordMCP."""
