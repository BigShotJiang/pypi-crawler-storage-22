"""Core module for CoordMCP."""
