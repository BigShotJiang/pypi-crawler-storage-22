"""Resources module for CoordMCP."""
