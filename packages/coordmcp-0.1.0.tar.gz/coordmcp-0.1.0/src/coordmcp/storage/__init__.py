"""Storage module for CoordMCP."""
