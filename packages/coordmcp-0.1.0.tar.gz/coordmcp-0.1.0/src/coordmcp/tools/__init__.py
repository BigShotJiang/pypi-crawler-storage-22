"""Tools module for CoordMCP."""
