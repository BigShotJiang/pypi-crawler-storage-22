"""Unit tests for CoordMCP"""
