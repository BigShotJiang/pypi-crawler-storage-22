"""
CoordMCP test suite.
"""
