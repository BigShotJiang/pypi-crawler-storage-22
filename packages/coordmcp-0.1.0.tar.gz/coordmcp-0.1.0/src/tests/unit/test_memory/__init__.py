"""
Tests for memory module.
"""
