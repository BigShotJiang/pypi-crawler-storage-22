"""Middleware for dynamic plan injection based on agent state.

This middleware allows agents to dynamically inject step-specific plan content
into the model's context without storing it in the message history. Plans are
injected transiently at model call time, keeping state.messages small.
"""

from collections.abc import Awaitable, Callable
from typing import Any

from langchain.agents.middleware.types import AgentMiddleware, ModelRequest, ModelResponse
from langchain_core.messages import HumanMessage


class DynamicPlanMiddleware(AgentMiddleware):
    """Middleware for dynamically injecting step plans based on agent state.

    This middleware intercepts model calls and uses a plan resolver function to
    determine what plan content should be injected for the current step. The plan
    is injected as a transient message that is NOT stored in state.messages.

    Args:
        plan_resolver: A callable that takes the current state and returns the
            plan content string for the current step, or None if no plan should
            be injected.

    Example:
        ```python
        from copilotagent.middleware.dynamic_plan import DynamicPlanMiddleware
        from copilotagent import create_deep_agent

        def resolve_plan_for_step(state: dict) -> str | None:
            \"\"\"Dynamically get plan content based on current step.\"\"\"
            current_step = state.get("current_step", "STEP_00")
            
            # Load step-specific plan content
            return load_plan_content(current_step)

        # Create agent with dynamic plan injection
        agent = create_deep_agent(
            model="claude-sonnet-4-5-20250929",
            tools=[...],
            plan_resolver=resolve_plan_for_step,  # Dynamic plan injection
            system_prompt="Your system prompt..."
        )
        ```

    Benefits:
        - Plans are NOT stored in state.messages (reduces state bloat)
        - Model still sees the current step's plan (injected transiently)
        - Backward compatible - if plan_resolver is None, no plan is injected
    """

    def __init__(
        self,
        *,
        plan_resolver: Callable[[dict[str, Any]], str | None] | None = None,
    ) -> None:
        """Initialize the DynamicPlanMiddleware.

        Args:
            plan_resolver: Callable that receives state and returns plan content string.
        """
        super().__init__()
        self.plan_resolver = plan_resolver

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        """Dynamically inject plan content before each model call.

        Args:
            request: The model request being processed.
            handler: The handler function to call with the modified request.

        Returns:
            The model response from the handler.
        """
        # If no plan resolver, pass through unchanged
        if self.plan_resolver is None:
            return handler(request)

        # Get current state from request
        state = getattr(request, "state", {})

        # Call the plan resolver to get plan content
        try:
            plan_content = self.plan_resolver(state)
            
            if plan_content:
                # Create a plan message to prepend
                plan_message = HumanMessage(
                    content=f"## Current Step Plan\n\n{plan_content}",
                    additional_kwargs={"lc_source": "dynamic_plan"},
                )
                
                # Prepend plan message to the existing messages
                modified_messages = [plan_message] + list(request.messages)
                request = request.override(messages=modified_messages)
                
                import logging
                logging.debug(f"[DynamicPlanMiddleware] Injected plan ({len(plan_content)} chars)")

        except Exception as e:
            # If plan resolution fails, log and continue without plan
            import logging
            logging.warning(f"Plan resolver failed: {e}. Continuing without plan.")

        return handler(request)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelResponse:
        """(async) Dynamically inject plan content before each model call.

        Args:
            request: The model request being processed.
            handler: The handler function to call with the modified request.

        Returns:
            The model response from the handler.
        """
        # If no plan resolver, pass through unchanged
        if self.plan_resolver is None:
            return await handler(request)

        # Get current state from request
        state = getattr(request, "state", {})

        # Call the plan resolver to get plan content
        try:
            plan_content = self.plan_resolver(state)
            
            if plan_content:
                # Create a plan message to prepend
                plan_message = HumanMessage(
                    content=f"## Current Step Plan\n\n{plan_content}",
                    additional_kwargs={"lc_source": "dynamic_plan"},
                )
                
                # Prepend plan message to the existing messages
                modified_messages = [plan_message] + list(request.messages)
                request = request.override(messages=modified_messages)
                
                import logging
                logging.debug(f"[DynamicPlanMiddleware] Injected plan ({len(plan_content)} chars)")

        except Exception as e:
            # If plan resolution fails, log and continue without plan
            import logging
            logging.warning(f"Plan resolver failed: {e}. Continuing without plan.")

        return await handler(request)
