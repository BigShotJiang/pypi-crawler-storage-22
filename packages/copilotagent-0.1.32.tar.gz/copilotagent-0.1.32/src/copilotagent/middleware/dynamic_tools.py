"""Middleware for dynamic tool binding based on agent state.

This middleware allows agents to dynamically select which tools to bind to the LLM
based on the current state, reducing context window usage by only passing relevant
tools per step.

Also BLOCKS tool execution for tools not in the resolved list, preventing the model
from calling tools it remembers from context but shouldn't have access to.
"""

import logging
from collections.abc import Awaitable, Callable, Sequence
from typing import Any

from langchain.agents.middleware.types import AgentMiddleware, ModelRequest, ModelResponse
from langchain.tools.tool_node import ToolCallRequest
from langchain_core.messages import ToolMessage
from langchain_core.tools import BaseTool

logger = logging.getLogger(__name__)


class DynamicToolMiddleware(AgentMiddleware):
    """Middleware for dynamically binding tools based on agent state.

    This middleware intercepts model calls and uses a tool resolver function to
    determine which subset of tools should be bound for each specific model call.
    This can significantly reduce context window usage when dealing with large
    tool sets.

    Args:
        tool_resolver: A callable that takes the current state and returns a list
            of tools to bind for this model call. If None, all tools are passed through.
        fallback_tools: Optional fallback tools to use if tool_resolver returns None
            or an empty list.

    Example:
        ```python
        from copilotagent.middleware.dynamic_tools import DynamicToolMiddleware
        from copilotagent import create_deep_agent

        def resolve_tools_for_step(state: dict) -> list[BaseTool]:
            \"\"\"Dynamically select tools based on current step in state.\"\"\"
            current_step = state.get("current_step", "STEP_00")
            
            # Return step-specific tools
            if current_step == "STEP_00":
                return [tool1, tool2, tool3]
            elif current_step == "STEP_01":
                return [tool2, tool4, tool5]
            else:
                return [tool1, tool2, tool3, tool4, tool5]

        # Create agent with dynamic tool binding
        agent = create_deep_agent(
            model="claude-sonnet-4-5-20250929",
            tools=[tool1, tool2, tool3, tool4, tool5],  # All available tools
            middleware=[
                DynamicToolMiddleware(tool_resolver=resolve_tools_for_step)
            ],
            system_prompt="Your system prompt..."
        )
        ```

    Benefits:
        - Reduces context window usage by only passing relevant tools
        - Improves model performance by reducing noise from irrelevant tools
        - Maintains flexibility to add/remove tools dynamically
        - Backward compatible - if tool_resolver is None, all tools pass through
    """

    def __init__(
        self,
        *,
        tool_resolver: Callable[[dict[str, Any]], Sequence[BaseTool | Callable | dict[str, Any]]] | None = None,
        fallback_tools: Sequence[BaseTool | Callable | dict[str, Any]] | None = None,
        block_unauthorized_calls: bool = True,
    ) -> None:
        """Initialize the DynamicToolMiddleware.

        Args:
            tool_resolver: Callable that receives state and returns filtered tools.
            fallback_tools: Optional fallback tools if resolver returns empty list.
            block_unauthorized_calls: If True, block execution of tools not in the
                resolved list. This prevents the model from calling tools it remembers
                from context but shouldn't have access to in the current step.
        """
        super().__init__()
        self.tool_resolver = tool_resolver
        self.fallback_tools = fallback_tools or []
        self.block_unauthorized_calls = block_unauthorized_calls
        # Track allowed tool names for the current step (updated in wrap_model_call)
        self._allowed_tool_names: set[str] = set()

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        """Dynamically filter tools before each model call.

        Args:
            request: The model request being processed.
            handler: The handler function to call with the modified request.

        Returns:
            The model response from the handler.
        """
        # If no tool resolver, pass through unchanged
        if self.tool_resolver is None:
            return handler(request)

        # Get current state from request
        state = getattr(request, "state", {})

        # Call the tool resolver to get filtered tools
        try:
            filtered_tools = self.tool_resolver(state)
            
            # If resolver returns None or empty list, use fallback
            if not filtered_tools:
                filtered_tools = self.fallback_tools

            # Store allowed tool names for blocking in wrap_tool_call
            self._allowed_tool_names = set()
            for tool in filtered_tools:
                name = getattr(tool, 'name', getattr(tool, '__name__', str(tool)))
                self._allowed_tool_names.add(name)

            # Use request.override() to properly modify the request - this is the correct pattern!
            logger.info(f"[DynamicToolMiddleware] Filtering tools: {len(filtered_tools)} tools -> {list(self._allowed_tool_names)}")
            modified_request = request.override(tools=filtered_tools)
            return handler(modified_request)

        except Exception as e:
            # If tool resolution fails, log and continue with original tools
            logger.warning(f"Tool resolver failed: {e}. Using all tools.")

        return handler(request)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelResponse:
        """(async) Dynamically filter tools before each model call.

        Args:
            request: The model request being processed.
            handler: The handler function to call with the modified request.

        Returns:
            The model response from the handler.
        """
        # If no tool resolver, pass through unchanged
        if self.tool_resolver is None:
            return await handler(request)

        # Get current state from request
        state = getattr(request, "state", {})

        # Call the tool resolver to get filtered tools
        try:
            filtered_tools = self.tool_resolver(state)
            
            # If resolver returns None or empty list, use fallback
            if not filtered_tools:
                filtered_tools = self.fallback_tools

            # Store allowed tool names for blocking in wrap_tool_call
            self._allowed_tool_names = set()
            for tool in filtered_tools:
                name = getattr(tool, 'name', getattr(tool, '__name__', str(tool)))
                self._allowed_tool_names.add(name)

            # Use request.override() to properly modify the request - this is the correct pattern!
            logger.info(f"[DynamicToolMiddleware] (async) Filtering tools: {len(filtered_tools)} tools -> {list(self._allowed_tool_names)}")
            modified_request = request.override(tools=filtered_tools)
            
            # DEBUG: Verify the override worked
            actual_tools_after = getattr(modified_request, 'tools', [])
            actual_tool_names = [getattr(t, 'name', getattr(t, '__name__', str(t))) for t in actual_tools_after]
            logger.debug(f"[DynamicToolMiddleware] After override: {len(actual_tool_names)} tools in request")
            if len(actual_tool_names) != len(self._allowed_tool_names):
                logger.error(f"[DynamicToolMiddleware] ⚠️ OVERRIDE FAILED! Expected {len(self._allowed_tool_names)} tools, got {len(actual_tool_names)}: {actual_tool_names[:5]}...")
            
            # Also check original request tools for comparison
            original_tools = getattr(request, 'tools', [])
            orig_count = len(list(original_tools)) if original_tools else 0
            logger.debug(f"[DynamicToolMiddleware] Original request had {orig_count} tools, modified has {len(actual_tool_names)}")
            
            return await handler(modified_request)

        except Exception as e:
            # If tool resolution fails, log and continue with original tools
            logger.warning(f"Tool resolver failed: {e}. Using all tools.")

        return await handler(request)

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage],
    ) -> ToolMessage:
        """Block execution of tools not in the resolved list.

        This is a safety net - if the model somehow calls a tool that wasn't
        in the filtered list, we block it here instead of executing.

        Args:
            request: The tool call request being processed.
            handler: The handler function to execute the tool.

        Returns:
            ToolMessage with result or error if tool is blocked.
        """
        if not self.block_unauthorized_calls:
            return handler(request)

        tool_name = request.tool_call.get("name", "")
        
        # If no allowed tools set (resolver not called yet), allow all
        if not self._allowed_tool_names:
            return handler(request)

        # Check if this tool is allowed
        if tool_name not in self._allowed_tool_names:
            logger.warning(f"[DynamicToolMiddleware] ❌ BLOCKED unauthorized tool call: {tool_name} (allowed: {self._allowed_tool_names})")
            return ToolMessage(
                content=f"Error: Tool '{tool_name}' is not available in the current step. Available tools: {list(self._allowed_tool_names)}",
                tool_call_id=request.tool_call.get("id", ""),
            )

        return handler(request)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage]],
    ) -> ToolMessage:
        """(async) Block execution of tools not in the resolved list.

        This is a safety net - if the model somehow calls a tool that wasn't
        in the filtered list, we block it here instead of executing.

        Args:
            request: The tool call request being processed.
            handler: The async handler function to execute the tool.

        Returns:
            ToolMessage with result or error if tool is blocked.
        """
        if not self.block_unauthorized_calls:
            return await handler(request)

        tool_name = request.tool_call.get("name", "")
        
        # If no allowed tools set (resolver not called yet), allow all
        if not self._allowed_tool_names:
            return await handler(request)

        # Check if this tool is allowed
        if tool_name not in self._allowed_tool_names:
            logger.warning(f"[DynamicToolMiddleware] ❌ BLOCKED unauthorized tool call: {tool_name} (allowed: {self._allowed_tool_names})")
            return ToolMessage(
                content=f"Error: Tool '{tool_name}' is not available in the current step. Available tools: {list(self._allowed_tool_names)}",
                tool_call_id=request.tool_call.get("id", ""),
            )

        return await handler(request)


