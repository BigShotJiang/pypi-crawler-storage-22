"""Step-Based Summarization Middleware.

This middleware implements step-based conversation summarization:
- Full message history is preserved in state.messages for auditing
- Only summary + current step messages are sent to the model
- Uses wrap_model_call for transient message filtering (doesn't modify state)
- Uses before_model to detect step boundaries via index comparison and
  trigger LLM summarization when new messages need summarizing
- write_todo sets step_start_message_index; middleware detects the gap
  and summarizes automatically (works for both real and skipped steps)

This is a drop-in replacement for langchain.agents.middleware.summarization.SummarizationMiddleware
"""

import json
import logging
from collections.abc import Awaitable, Callable
from typing import Any

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    AnyMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.messages.utils import count_tokens_approximately
from langchain.chat_models import init_chat_model
from langgraph.runtime import Runtime
from typing_extensions import override

from langchain.agents.middleware.types import (
    AgentMiddleware,
    AgentState,
    ModelCallResult,
    ModelRequest,
    ModelResponse,
)

logger = logging.getLogger(__name__)

# Default configuration
DEFAULT_MAX_SUMMARY_TOKENS = 5000  # Cap for conversation_summary field

# Prompt for LLM summarization - focused on WORKFLOW PROGRESS, not data
SUMMARY_PROMPT = """You are summarizing workflow progress for a loan document processing agent.

Create a BRIEF workflow status summary. Focus on:
- Steps completed and their outcome (success/issues)
- Any flags or issues raised (and their status: pending/resolved/escalated)
- Key decisions made (overrides, corrections, escalations)
- Current workflow position

DO NOT include:
- Detailed loan data (borrower info, amounts, addresses) - this is in state
- Document contents - this is in state  
- Field values - this is in state
- Conversational filler

Previous summary:
{existing_summary}

New step just completed - key events:
{step_messages}

Output a concise workflow status (max 500 words):"""


def _format_messages_for_summary(messages: list[AnyMessage]) -> str:
    """Format messages into a readable string for the summarization prompt.
    
    Focus on tool calls and results, not detailed content.
    """
    parts = []
    for msg in messages:
        if isinstance(msg, AIMessage):
            # Include tool calls if present
            if msg.tool_calls:
                tool_names = [tc.get("name", "unknown") for tc in msg.tool_calls]
                parts.append(f"- Called: {', '.join(tool_names)}")
        elif isinstance(msg, ToolMessage):
            # Very brief tool result summary
            name = getattr(msg, 'name', 'tool')
            try:
                content = msg.content if isinstance(msg.content, str) else str(msg.content)
                # Try to parse as JSON to extract key info
                if content.startswith('{'):
                    data = json.loads(content)
                    status = data.get('status', data.get('success', 'unknown'))
                    if 'error' in data:
                        parts.append(f"- {name}: ERROR - {data['error'][:100]}")
                    elif 'message' in data:
                        parts.append(f"- {name}: {data['message'][:150]}")
                    else:
                        parts.append(f"- {name}: {status}")
                else:
                    parts.append(f"- {name}: {content[:100]}...")
            except:
                parts.append(f"- {name}: completed")
    
    return "\n".join(parts) if parts else "(No significant actions)"


def _validate_message_sequence(messages: list[AnyMessage]) -> bool:
    """Validate that the message sequence is valid for Anthropic API.
    
    Rules:
    - ToolMessages (tool_result) must follow an AIMessage with tool_calls
    - Consecutive user-role messages (Human/Tool) will be merged
    - tool_result without tool_use in same user message → error
    """
    for i, msg in enumerate(messages):
        if isinstance(msg, ToolMessage):
            # Find the preceding non-ToolMessage
            found_ai_with_tools = False
            for j in range(i - 1, -1, -1):
                prev = messages[j]
                if isinstance(prev, ToolMessage):
                    continue  # Keep looking
                if isinstance(prev, AIMessage) and prev.tool_calls:
                    found_ai_with_tools = True
                break
            
            if not found_ai_with_tools:
                logger.error(
                    f"[Summarization] Invalid sequence: ToolMessage at index {i} "
                    f"has no preceding AIMessage with tool_calls"
                )
                return False
    
    return True


def _get_safe_message_slice(messages: list[AnyMessage], start_index: int) -> list[AnyMessage]:
    """Get messages from start_index, ensuring we don't break tool_use/tool_result pairs.
    
    CRITICAL: Anthropic API merges consecutive user-role messages. This means:
    - HumanMessage (user) + ToolMessage (user with tool_result) → merged into one message
    - If tool_result has no preceding tool_use, we get a 400 error
    
    To safely prepend a summary HumanMessage, the slice MUST start with either:
    1. An AIMessage (not a ToolMessage, not a HumanMessage)
    2. OR nothing (empty slice)
    
    If the slice would start with a ToolMessage, we MUST include its AIMessage with tool_calls.
    If the slice would start with a HumanMessage, we prepend an AIMessage separator if needed.
    """
    if start_index <= 0 or start_index >= len(messages):
        return list(messages)
    
    # Walk backwards from start_index to find a safe starting point
    # Safe = AIMessage (breaks the user-role chain, allows tool_result after it)
    actual_start = start_index
    
    while actual_start > 0:
        msg = messages[actual_start]
        
        if isinstance(msg, ToolMessage):
            # ToolMessage needs its AIMessage - keep going back
            actual_start -= 1
        elif isinstance(msg, AIMessage):
            # AIMessage is a safe starting point - it breaks the user-role chain
            # If it has tool_calls, its ToolMessages come after it, which is valid
            break
        elif isinstance(msg, HumanMessage):
            # HumanMessage would merge with our summary message, which is fine
            # But we should check if there's content we need before it
            break
        else:
            # SystemMessage or other - these are typically at the start
            break
    
    result_messages = list(messages[actual_start:])
    
    if not result_messages:
        return result_messages
    
    # Final validation: ensure first message is not a ToolMessage
    # (If we've done our job, this shouldn't happen, but let's be safe)
    first_msg = result_messages[0]
    if isinstance(first_msg, ToolMessage):
        # Emergency fallback: find AIMessage with tool_calls
        for i in range(actual_start - 1, -1, -1):
            prev_msg = messages[i]
            if isinstance(prev_msg, AIMessage) and prev_msg.tool_calls:
                result_messages.insert(0, prev_msg)
                logger.warning(f"[Summarization] Emergency fix: inserted AIMessage at index {i}")
                break
            elif isinstance(prev_msg, ToolMessage):
                result_messages.insert(0, prev_msg)
            else:
                break
    
    return result_messages


class SummarizationMiddleware(AgentMiddleware):
    """Step-based conversation summarization middleware.
    
    This middleware:
    
    1. **before_model** (before model call - LLM call when step boundary moved):
       - Compares `step_start_message_index` (set by write_todo) with
         `_summarized_up_to_index` (set by this middleware)
       - If step_start_message_index > _summarized_up_to_index: summarizes
         messages in the gap, updates conversation_summary, advances tracker
       - If no gap: does nothing (still within same step)
    
    2. **wrap_model_call** (every model call - NO LLM call):
       - Reads `conversation_summary` and `step_start_message_index` from state
       - If no summary: sends all messages (first step)
       - Else: sends `[summary_message] + messages[step_start_index:]`
       - Ensures tool_use/tool_result pairs are not broken
    
    Responsibilities:
    - write_todo sets `step_start_message_index` when a step completes and
      auto-starts the landing step (completion path). Only STEP_00 (first step)
      is set via the in_progress path since there's no preceding completion.
    - This middleware detects the boundary movement and summarizes automatically
    - Works for both real steps (many messages) and skipped steps (few messages)
    - No parsing of tool results, no flags — just index comparison
    
    This approach:
    - Saves tokens by sending only summary + current step to model
    - Preserves full audit trail in state.messages
    - Bounds LLM summarization to step boundaries only
    """

    def __init__(
        self,
        model: str | BaseChatModel,
        *,
        max_summary_tokens: int = DEFAULT_MAX_SUMMARY_TOKENS,
    ) -> None:
        """Initialize step-based summarization middleware.
        
        Args:
            model: The model to use for summarization (e.g., "claude-sonnet-4-20250514").
            max_summary_tokens: Maximum tokens for conversation_summary field.
        """
        super().__init__()
        
        if isinstance(model, str):
            self.model = init_chat_model(model)
        else:
            self.model = model
        
        self.max_summary_tokens = max_summary_tokens

    def _build_summary_message(self, summary: str) -> HumanMessage:
        """Build a message containing the conversation summary."""
        return HumanMessage(
            content=f"""<workflow_summary>
Previous steps summary:

{summary}
</workflow_summary>

Continue with the current step. Recent messages below show current step progress.""",
            additional_kwargs={"lc_source": "summarization"},
        )

    def _summarize_messages(
        self,
        existing_summary: str,
        step_messages: list[AnyMessage],
    ) -> str:
        """Call LLM to summarize the step's messages.
        
        This is called ONLY when a step completes (~17 times per workflow).
        """
        # Format messages for the prompt
        formatted_messages = _format_messages_for_summary(step_messages)
        
        # Build the summarization prompt
        prompt = SUMMARY_PROMPT.format(
            existing_summary=existing_summary if existing_summary else "(First step - no previous summary)",
            step_messages=formatted_messages,
        )
        
        try:
            # Call the model
            response = self.model.invoke([HumanMessage(content=prompt)])
            new_summary = response.content if isinstance(response.content, str) else str(response.content)
            
            # Trim if too long
            summary_tokens = count_tokens_approximately([HumanMessage(content=new_summary)])
            if summary_tokens > self.max_summary_tokens:
                # Rough trim - keep first ~80% of content
                char_limit = int(len(new_summary) * 0.8)
                new_summary = new_summary[:char_limit] + "\n\n[Summary truncated]"
            
            logger.info(f"[Summarization] Generated summary ({len(new_summary)} chars)")
            return new_summary
            
        except Exception as e:
            logger.error(f"[Summarization] LLM call failed: {e}")
            # Fallback: just append a note about the step
            if existing_summary:
                return f"{existing_summary}\n\n[Step completed - summarization failed]"
            return "[Step completed - summarization failed]"

    async def _asummarize_messages(
        self,
        existing_summary: str,
        step_messages: list[AnyMessage],
    ) -> str:
        """Async version of _summarize_messages."""
        formatted_messages = _format_messages_for_summary(step_messages)
        
        prompt = SUMMARY_PROMPT.format(
            existing_summary=existing_summary if existing_summary else "(First step - no previous summary)",
            step_messages=formatted_messages,
        )
        
        try:
            response = await self.model.ainvoke([HumanMessage(content=prompt)])
            new_summary = response.content if isinstance(response.content, str) else str(response.content)
            
            summary_tokens = count_tokens_approximately([HumanMessage(content=new_summary)])
            if summary_tokens > self.max_summary_tokens:
                char_limit = int(len(new_summary) * 0.8)
                new_summary = new_summary[:char_limit] + "\n\n[Summary truncated]"
            
            logger.info(f"[Summarization] Generated summary ({len(new_summary)} chars)")
            return new_summary
            
        except Exception as e:
            logger.error(f"[Summarization] LLM call failed: {e}")
            if existing_summary:
                return f"{existing_summary}\n\n[Step completed - summarization failed]"
            return "[Step completed - summarization failed]"

    @override
    def before_model(self, state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
        """Summarize messages when step boundary has moved.
        
        Compares step_start_message_index (set by write_todo) with
        _summarized_up_to_index (set by this middleware). If there's a gap,
        summarizes the messages in between.
        """
        messages = state.get("messages", [])
        if not messages:
            return None
        
        step_start_index = state.get("step_start_message_index", 0)
        summarized_up_to = state.get("_summarized_up_to_index", 0)
        
        # No gap = nothing to summarize (still within same step)
        if step_start_index <= summarized_up_to:
            return None
        
        existing_summary = state.get("conversation_summary", "")
        
        # First step transition (no prior summary) — just advance the tracker
        if summarized_up_to == 0 and not existing_summary:
            logger.info(f"[Summarization] First step boundary at {step_start_index}, advancing tracker")
            return {"_summarized_up_to_index": step_start_index}
        
        # Summarize messages from last summarization point to current step start
        step_messages = messages[summarized_up_to:step_start_index]
        state_update = {"_summarized_up_to_index": step_start_index}
        
        if step_messages:
            logger.info(f"[Summarization] Summarizing messages [{summarized_up_to}:{step_start_index}] ({len(step_messages)} msgs)")
            new_summary = self._summarize_messages(existing_summary, step_messages)
            state_update["conversation_summary"] = new_summary
        
        return state_update

    @override
    async def abefore_model(self, state: AgentState, runtime: Runtime) -> dict[str, Any] | None:
        """Async version of before_model."""
        messages = state.get("messages", [])
        if not messages:
            return None
        
        step_start_index = state.get("step_start_message_index", 0)
        summarized_up_to = state.get("_summarized_up_to_index", 0)
        
        if step_start_index <= summarized_up_to:
            return None
        
        existing_summary = state.get("conversation_summary", "")
        
        # First step transition — just advance the tracker
        if summarized_up_to == 0 and not existing_summary:
            logger.info(f"[Summarization] First step boundary at {step_start_index}, advancing tracker")
            return {"_summarized_up_to_index": step_start_index}
        
        step_messages = messages[summarized_up_to:step_start_index]
        state_update = {"_summarized_up_to_index": step_start_index}
        
        if step_messages:
            logger.info(f"[Summarization] Summarizing messages [{summarized_up_to}:{step_start_index}] ({len(step_messages)} msgs)")
            new_summary = await self._asummarize_messages(existing_summary, step_messages)
            state_update["conversation_summary"] = new_summary
        
        return state_update

    @override
    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelCallResult:
        """Filter messages sent to model - NO LLM call here.
        
        Runs on every model invocation. Only reads state and filters messages.
        Ensures tool_use/tool_result pairs are preserved.
        """
        state = request.state
        messages = request.messages
        
        # Get summary and step boundary from state
        conversation_summary = state.get("conversation_summary", "")
        step_start_index = state.get("step_start_message_index", 0)
        
        if not conversation_summary:
            # No summary yet - first step, send all messages
            logger.debug(f"[Summarization] No summary, sending all {len(messages)} messages")
            return handler(request)
        
        # Get current step messages, ensuring we don't break tool pairs
        current_step_messages = _get_safe_message_slice(messages, step_start_index)
        
        # Build filtered message list
        summary_message = self._build_summary_message(conversation_summary)
        filtered_messages = [summary_message] + current_step_messages
        
        # Validate the sequence before sending
        if not _validate_message_sequence(filtered_messages):
            # Fallback to sending all messages if filtering creates invalid sequence
            logger.warning(
                f"[Summarization] Filtered messages invalid, falling back to all {len(messages)} messages"
            )
            return handler(request)
        
        # Log the filtering
        original_tokens = count_tokens_approximately(messages)
        filtered_tokens = count_tokens_approximately(filtered_messages)
        
        logger.info(
            f"[Summarization] Filtered: {len(messages)} -> {len(filtered_messages)} msgs "
            f"(~{original_tokens:,} -> ~{filtered_tokens:,} tokens)"
        )
        
        # Send filtered messages to model
        modified_request = request.override(messages=filtered_messages)
        return handler(modified_request)

    @override
    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelCallResult:
        """Async version of wrap_model_call."""
        state = request.state
        messages = request.messages
        
        conversation_summary = state.get("conversation_summary", "")
        step_start_index = state.get("step_start_message_index", 0)
        
        if not conversation_summary:
            logger.debug(f"[Summarization] No summary, sending all {len(messages)} messages")
            return await handler(request)
        
        # Get current step messages, ensuring we don't break tool pairs
        current_step_messages = _get_safe_message_slice(messages, step_start_index)
        
        summary_message = self._build_summary_message(conversation_summary)
        filtered_messages = [summary_message] + current_step_messages
        
        # Validate the sequence before sending
        if not _validate_message_sequence(filtered_messages):
            logger.warning(
                f"[Summarization] Filtered messages invalid, falling back to all {len(messages)} messages"
            )
            return await handler(request)
        
        original_tokens = count_tokens_approximately(messages)
        filtered_tokens = count_tokens_approximately(filtered_messages)
        
        logger.info(
            f"[Summarization] Filtered: {len(messages)} -> {len(filtered_messages)} msgs "
            f"(~{original_tokens:,} -> ~{filtered_tokens:,} tokens)"
        )
        
        modified_request = request.override(messages=filtered_messages)
        return await handler(modified_request)
