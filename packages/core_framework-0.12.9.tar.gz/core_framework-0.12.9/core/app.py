"""
Bootstrap do Framework - Aplicação principal.

Características:
- Configuração centralizada via Settings
- Lifecycle management (startup/shutdown)
- Middleware integrado
- CORS configurável
- Documentação automática
- Auto-configuração de features enterprise:
  - Multi-tenancy
  - Read/Write replicas
  - Soft delete
"""

from __future__ import annotations

from typing import Any
from collections.abc import Callable, Sequence
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from core.config import Settings, get_settings
from core.models import init_database, create_tables, close_database
from core.routing import Router, AutoRouter, include_router


class CoreApp:
    """
    Aplicação principal do framework.
    
    Encapsula FastAPI com configurações e lifecycle management.
    
    Exemplo básico:
        app = CoreApp(
            title="My API",
            settings=MySettings(),
        )
        
        # Registra routers
        app.include_router(user_router, prefix="/users")
        
        # Obtém a aplicação FastAPI
        fastapi_app = app.app
    
    Exemplo com middlewares Django-style:
        app = CoreApp(
            title="My API",
            middleware=[
                "core.middleware.TimingMiddleware",
                "core.auth.AuthenticationMiddleware",
                ("core.middleware.LoggingMiddleware", {"log_headers": True}),
            ],
        )
    
    Shortcuts disponíveis:
        - "auth": AuthenticationMiddleware
        - "timing": TimingMiddleware
        - "request_id": RequestIDMiddleware
        - "logging": LoggingMiddleware
        - "security_headers": SecurityHeadersMiddleware
    """
    
    def __init__(
        self,
        title: str | None = None,
        description: str = "",
        version: str = "1.0.0",
        settings: Settings | None = None,
        routers: list[Router | AutoRouter] | None = None,
        on_startup: list[Callable] | None = None,
        on_shutdown: list[Callable] | None = None,
        middlewares: list[tuple[type, dict[str, Any]]] | None = None,
        middleware: list[str | type | tuple] | None = None,
        exception_handlers: dict[type, Callable] | None = None,
        auto_create_tables: bool = True,
        **fastapi_kwargs: Any,
    ) -> None:
        """
        Inicializa a aplicação.
        
        Args:
            title: Título da API
            description: Descrição da API
            version: Versão da API
            settings: Configurações (usa padrão se não fornecido)
            routers: Lista de routers a incluir
            on_startup: Callbacks de startup
            on_shutdown: Callbacks de shutdown
            middlewares: Lista de middlewares formato antigo (classe, kwargs)
            middleware: Lista de middlewares formato Django-style (strings/classes)
            exception_handlers: Handlers de exceção customizados
            auto_create_tables: Se True, cria tabelas automaticamente
            **fastapi_kwargs: Argumentos extras para FastAPI
        
        Middleware format (novo, Django-style):
            middleware=[
                "core.auth.AuthenticationMiddleware",  # String path
                "auth",  # Shortcut
                MyMiddleware,  # Classe direta
                ("logging", {"log_body": True}),  # Com kwargs
            ]
        """
        self.settings = settings or get_settings()
        self._on_startup = on_startup or []
        self._on_shutdown = on_shutdown or []
        self._auto_create_tables = auto_create_tables
        
        # Cria a aplicação FastAPI
        self.app = FastAPI(
            title=title or self.settings.app_name,
            description=description,
            version=version,
            docs_url=self.settings.docs_url,
            redoc_url=self.settings.redoc_url,
            lifespan=self._lifespan,
            **fastapi_kwargs,
        )
        
        # Configura CORS
        self._setup_cors()
        
        # Configura middleware de tenancy se habilitado
        if self.settings.tenancy_enabled:
            self._setup_tenancy_middleware()
        
        # Adiciona middlewares - formato novo Django-style (parâmetro ou settings)
        middleware_list = middleware or getattr(self.settings, "middleware", None)
        if middleware_list:
            self._setup_django_style_middleware(middleware_list)
        
        # Adiciona middlewares - formato antigo (tuple)
        if middlewares:
            for middleware_class, middleware_kwargs in middlewares:
                self.app.add_middleware(middleware_class, **middleware_kwargs)
        
        # Adiciona exception handlers
        self._setup_exception_handlers(exception_handlers)
        
        # Inclui routers
        if routers:
            for router in routers:
                self.include_router(router)
    
    @asynccontextmanager
    async def _lifespan(self, app: FastAPI):
        """Gerencia o ciclo de vida da aplicação."""
        # Startup
        await self._startup()
        
        yield
        
        # Shutdown
        await self._shutdown()
    
    async def _startup(self) -> None:
        """Executa tarefas de startup."""
        # Verifica se deve usar replicas
        if self.settings.has_read_replica:
            # Inicializa com read/write replicas
            from core.database import init_replicas
            
            await init_replicas(
                write_url=self.settings.database_url,
                read_url=self.settings.database_read_url,
                echo=self.settings.database_echo,
                pool_size=self.settings.database_pool_size,
                max_overflow=self.settings.database_max_overflow,
                pool_recycle=self.settings.database_pool_recycle,
            )
        else:
            # Inicializa banco de dados padrão
            await init_database(
                database_url=self.settings.database_url,
                echo=self.settings.database_echo,
                pool_size=self.settings.database_pool_size,
                max_overflow=self.settings.database_max_overflow,
            )
        
        # Cria tabelas se configurado
        if self._auto_create_tables:
            await create_tables()
        
        # Configura tenancy se habilitado
        if self.settings.tenancy_enabled:
            from core.tenancy import set_tenant_field
            set_tenant_field(self.settings.tenancy_field)
        
        # Executa callbacks customizados
        for callback in self._on_startup:
            result = callback()
            if hasattr(result, "__await__"):
                await result
    
    async def _shutdown(self) -> None:
        """Executa tarefas de shutdown."""
        # Executa callbacks customizados
        for callback in self._on_shutdown:
            result = callback()
            if hasattr(result, "__await__"):
                await result
        
        # Flush and close messaging producers
        try:
            from core.messaging.registry import stop_all_producers
            await stop_all_producers()
        except Exception:
            pass  # Messaging may not be configured
        
        # Fecha conexões
        if self.settings.has_read_replica:
            from core.database import close_replicas
            await close_replicas()
        else:
            await close_database()
    
    def _setup_cors(self) -> None:
        """Configura CORS."""
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=self.settings.cors_origins,
            allow_credentials=self.settings.cors_allow_credentials,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    
    def _setup_tenancy_middleware(self) -> None:
        """Configura middleware de multi-tenancy."""
        from core.tenancy import TenantMiddleware
        
        self.app.add_middleware(
            TenantMiddleware,
            user_tenant_attr=self.settings.tenancy_user_attribute,
            tenant_field=self.settings.tenancy_field,
            require_tenant=self.settings.tenancy_require,
        )
    
    def _setup_django_style_middleware(
        self,
        middleware_list: list[str | type | tuple],
    ) -> None:
        """
        Configura middlewares no estilo Django.
        
        Args:
            middleware_list: Lista de middlewares
                - String: path do middleware (ex: "core.auth.AuthenticationMiddleware")
                - String shortcut: nome curto (ex: "auth", "timing")
                - Classe: classe do middleware diretamente
                - Tuple: (middleware, kwargs) para passar configurações
        
        Example:
            middleware_list = [
                "core.middleware.TimingMiddleware",
                "auth",  # shortcut para AuthenticationMiddleware
                MyCustomMiddleware,
                ("logging", {"log_body": True}),
            ]
        """
        from core.middleware import configure_middleware, apply_middlewares
        
        # Configura no registry global
        configure_middleware(middleware_list, clear_existing=True)
        
        # Aplica ao app
        apply_middlewares(self.app)
    
    def _setup_exception_handlers(
        self,
        custom_handlers: dict[type, Callable] | None = None,
    ) -> None:
        """Configura handlers de exceção."""
        from pydantic import ValidationError
        from sqlalchemy.exc import IntegrityError, DataError, OperationalError
        from core.validators import (
            ValidationError as CoreValidationError,
            MultipleValidationErrors,
            UniqueValidationError,
        )
        
        # Handler para erros de validação Pydantic
        @self.app.exception_handler(ValidationError)
        async def pydantic_validation_handler(
            request: Request,
            exc: ValidationError,
        ) -> JSONResponse:
            # Converte erros para formato JSON serializável
            errors = []
            for error in exc.errors():
                err = {
                    "loc": list(error.get("loc", [])),
                    "msg": str(error.get("msg", "")),
                    "type": error.get("type", ""),
                }
                # Inclui input apenas se for serializável
                if "input" in error:
                    try:
                        import json
                        json.dumps(error["input"])
                        err["input"] = error["input"]
                    except (TypeError, ValueError):
                        err["input"] = str(error["input"])
                errors.append(err)
            
            return JSONResponse(
                status_code=422,
                content={
                    "detail": "Validation error",
                    "code": "validation_error",
                    "errors": errors,
                },
            )
        
        # Handler para erros de validação do Core
        @self.app.exception_handler(CoreValidationError)
        async def core_validation_handler(
            request: Request,
            exc: CoreValidationError,
        ) -> JSONResponse:
            return JSONResponse(
                status_code=422,
                content={
                    "detail": exc.message,
                    "code": exc.code,
                    "field": exc.field,
                    "errors": [exc.to_dict()],
                },
            )
        
        # Handler para múltiplos erros de validação
        @self.app.exception_handler(MultipleValidationErrors)
        async def multiple_validation_handler(
            request: Request,
            exc: MultipleValidationErrors,
        ) -> JSONResponse:
            return JSONResponse(
                status_code=422,
                content=exc.to_dict(),
            )
        
        # Handler para erros de unicidade
        @self.app.exception_handler(UniqueValidationError)
        async def unique_validation_handler(
            request: Request,
            exc: UniqueValidationError,
        ) -> JSONResponse:
            return JSONResponse(
                status_code=409,  # Conflict
                content={
                    "detail": exc.message,
                    "code": "unique_constraint",
                    "field": exc.field,
                    "value": exc.value,
                },
            )
        
        # Handler para IntegrityError do SQLAlchemy (UNIQUE, FK, etc.)
        @self.app.exception_handler(IntegrityError)
        async def integrity_error_handler(
            request: Request,
            exc: IntegrityError,
        ) -> JSONResponse:
            error_msg = str(exc.orig) if exc.orig else str(exc)
            
            # Detecta tipo de erro
            if "UNIQUE constraint failed" in error_msg:
                # Extrai nome do campo
                field_match = error_msg.split("UNIQUE constraint failed:")[-1].strip()
                field_name = field_match.split(".")[-1] if "." in field_match else field_match
                
                return JSONResponse(
                    status_code=409,
                    content={
                        "detail": f"A record with this {field_name} already exists.",
                        "code": "unique_constraint",
                        "field": field_name,
                    },
                )
            
            elif "FOREIGN KEY constraint failed" in error_msg:
                return JSONResponse(
                    status_code=400,
                    content={
                        "detail": "Referenced record does not exist.",
                        "code": "foreign_key_constraint",
                    },
                )
            
            elif "NOT NULL constraint failed" in error_msg:
                field_match = error_msg.split("NOT NULL constraint failed:")[-1].strip()
                field_name = field_match.split(".")[-1] if "." in field_match else field_match
                
                return JSONResponse(
                    status_code=422,
                    content={
                        "detail": f"Field '{field_name}' is required.",
                        "code": "required_field",
                        "field": field_name,
                    },
                )
            
            elif "duplicate key" in error_msg.lower():
                # PostgreSQL
                return JSONResponse(
                    status_code=409,
                    content={
                        "detail": "A record with this value already exists.",
                        "code": "unique_constraint",
                    },
                )
            
            # Erro genérico de integridade
            if self.settings.debug:
                return JSONResponse(
                    status_code=400,
                    content={
                        "detail": "Database integrity error.",
                        "code": "integrity_error",
                        "debug_info": error_msg,
                    },
                )
            return JSONResponse(
                status_code=400,
                content={
                    "detail": "Database integrity error. Please check your data.",
                    "code": "integrity_error",
                },
            )
        
        # Handler para DataError (dados inválidos para o tipo da coluna)
        @self.app.exception_handler(DataError)
        async def data_error_handler(
            request: Request,
            exc: DataError,
        ) -> JSONResponse:
            return JSONResponse(
                status_code=422,
                content={
                    "detail": "Invalid data format for database field.",
                    "code": "data_error",
                },
            )
        
        # Handler para OperationalError (conexão, timeout, etc.)
        @self.app.exception_handler(OperationalError)
        async def operational_error_handler(
            request: Request,
            exc: OperationalError,
        ) -> JSONResponse:
            if self.settings.debug:
                return JSONResponse(
                    status_code=503,
                    content={
                        "detail": "Database operation failed.",
                        "code": "database_error",
                        "debug_info": str(exc),
                    },
                )
            return JSONResponse(
                status_code=503,
                content={
                    "detail": "Service temporarily unavailable. Please try again.",
                    "code": "service_unavailable",
                },
            )
        
        # Handler padrão para exceções não tratadas
        @self.app.exception_handler(Exception)
        async def generic_exception_handler(
            request: Request,
            exc: Exception,
        ) -> JSONResponse:
            if self.settings.debug:
                import traceback
                return JSONResponse(
                    status_code=500,
                    content={
                        "detail": str(exc),
                        "code": "internal_error",
                        "type": type(exc).__name__,
                        "traceback": traceback.format_exc(),
                    },
                )
            return JSONResponse(
                status_code=500,
                content={
                    "detail": "Internal server error",
                    "code": "internal_error",
                },
            )
        
        # Handlers customizados
        if custom_handlers:
            for exc_class, handler in custom_handlers.items():
                self.app.add_exception_handler(exc_class, handler)
    
    def include_router(
        self,
        router: Router | AutoRouter,
        prefix: str = "",
        tags: list[str] | None = None,
    ) -> None:
        """
        Inclui um router na aplicação.
        
        Args:
            router: Router ou AutoRouter
            prefix: Prefixo adicional
            tags: Tags para OpenAPI
        """
        include_router(self.app, router, prefix=prefix, tags=tags)
    
    def on_startup(self, func: Callable) -> Callable:
        """
        Decorator para registrar callback de startup.
        
        Exemplo:
            @app.on_startup
            async def setup_cache():
                await cache.connect()
        """
        self._on_startup.append(func)
        return func
    
    def on_shutdown(self, func: Callable) -> Callable:
        """
        Decorator para registrar callback de shutdown.
        
        Exemplo:
            @app.on_shutdown
            async def cleanup():
                await cache.disconnect()
        """
        self._on_shutdown.append(func)
        return func
    
    def get(self, path: str, **kwargs: Any) -> Callable:
        """Decorator para rota GET."""
        return self.app.get(path, **kwargs)
    
    def post(self, path: str, **kwargs: Any) -> Callable:
        """Decorator para rota POST."""
        return self.app.post(path, **kwargs)
    
    def put(self, path: str, **kwargs: Any) -> Callable:
        """Decorator para rota PUT."""
        return self.app.put(path, **kwargs)
    
    def patch(self, path: str, **kwargs: Any) -> Callable:
        """Decorator para rota PATCH."""
        return self.app.patch(path, **kwargs)
    
    def delete(self, path: str, **kwargs: Any) -> Callable:
        """Decorator para rota DELETE."""
        return self.app.delete(path, **kwargs)
    
    def add_api_route(
        self,
        path: str,
        endpoint: Callable,
        methods: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """
        Add an API route directly.
        
        Useful for adding routes from APIView classes.
        
        Example:
            app.add_api_route("/health", HealthView.as_route("/health")[1], methods=["GET"])
        """
        self.app.add_api_route(path, endpoint, methods=methods, **kwargs)
    
    async def __call__(self, scope, receive, send):
        """
        Torna CoreApp callable como ASGI app.
        
        Permite usar diretamente com uvicorn:
            uvicorn main:app --reload
        
        Onde app é uma instância de CoreApp.
        """
        await self.app(scope, receive, send)


def create_app(
    title: str = "Core Framework API",
    settings: Settings | None = None,
    **kwargs: Any,
) -> CoreApp:
    """
    Factory function para criar aplicação.
    
    Exemplo:
        app = create_app(
            title="My API",
            description="API description",
        )
    """
    return CoreApp(title=title, settings=settings, **kwargs)
