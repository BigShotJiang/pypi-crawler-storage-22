from pydantic import BaseModel


class AuditLog(BaseModel):
    """Audit log entry."""

    pass
