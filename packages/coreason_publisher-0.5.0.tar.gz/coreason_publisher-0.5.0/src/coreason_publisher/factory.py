# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_publisher

from pathlib import Path
from typing import Optional

from coreason_publisher.config import PublisherConfig
from coreason_publisher.core.artifact_bundler import ArtifactBundler
from coreason_publisher.core.certificate_generator import CertificateGenerator
from coreason_publisher.core.council_snapshot import CouncilSnapshot
from coreason_publisher.core.electronic_signer import ElectronicSigner
from coreason_publisher.core.git_lfs import GitLFS
from coreason_publisher.core.git_local import GitLocal
from coreason_publisher.core.gitlab_provider import GitLabProvider
from coreason_publisher.core.http_assay_client import HttpAssayClient
from coreason_publisher.core.http_foundry_client import HttpFoundryClient
from coreason_publisher.core.orchestrator import PublisherOrchestrator
from coreason_publisher.core.remote_storage import MockStorageProvider
from coreason_publisher.core.version_manager import VersionManager
from coreason_publisher.utils.logger import logger


def get_orchestrator(
    workspace_path: Optional[Path] = None, config: Optional[PublisherConfig] = None
) -> PublisherOrchestrator:
    """Dependency Injection for the Orchestrator."""
    if workspace_path is None:
        workspace_path = Path.cwd()

    # PublisherConfig now reads from environment variables
    if config is None:
        config = PublisherConfig()

    # Infrastructure
    git_local = GitLocal(workspace_path)

    # Use gitlab_project_id from config or fallback/error
    gitlab_project_id = config.gitlab_project_id
    if not gitlab_project_id:
        logger.warning("GITLAB_PROJECT_ID not set. GitLab integration may fail.")
        gitlab_project_id = "0"  # Dummy if not set, will fail later if used

    git_provider = GitLabProvider(project_id=gitlab_project_id, config=config)

    assay_client = HttpAssayClient(config=config)
    foundry_client = HttpFoundryClient(config=config)

    # Components
    git_lfs = GitLFS()
    council_snapshot = CouncilSnapshot()
    # Storage provider configuration could be enhanced
    storage_provider = MockStorageProvider()
    certificate_generator = CertificateGenerator()

    artifact_bundler = ArtifactBundler(
        config=config,
        git_lfs=git_lfs,
        council_snapshot=council_snapshot,
        storage_provider=storage_provider,
        certificate_generator=certificate_generator,
    )

    electronic_signer = ElectronicSigner()
    version_manager = VersionManager(git_provider=git_provider)

    return PublisherOrchestrator(
        workspace_path=workspace_path,
        assay_client=assay_client,
        foundry_client=foundry_client,
        git_provider=git_provider,
        git_local=git_local,
        git_lfs=git_lfs,
        artifact_bundler=artifact_bundler,
        electronic_signer=electronic_signer,
        version_manager=version_manager,
    )
