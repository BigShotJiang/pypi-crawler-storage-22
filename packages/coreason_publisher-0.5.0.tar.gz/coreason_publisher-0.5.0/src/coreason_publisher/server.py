# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_publisher

from contextlib import asynccontextmanager
from typing import AsyncGenerator, Dict, List

from coreason_identity.models import UserContext
from fastapi import FastAPI, HTTPException, Request, status
from pydantic import BaseModel

from coreason_publisher.core.orchestrator import PublisherOrchestrator
from coreason_publisher.core.version_manager import BumpType
from coreason_publisher.factory import get_orchestrator
from coreason_publisher.utils.logger import logger


class ProposeRequest(BaseModel):
    project_id: str
    draft_id: str
    bump_type: BumpType
    user_id: str
    description: str


class ReleaseRequest(BaseModel):
    mr_id: int
    srb_signature: str
    srb_user_id: str


class RejectRequest(BaseModel):
    mr_id: int
    draft_id: str
    reason: str


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    logger.info("Initializing Publisher Orchestrator...")
    try:
        # We rely on defaults or env vars for workspace/config
        orchestrator = get_orchestrator()
        app.state.orchestrator = orchestrator
        logger.info("Publisher Orchestrator initialized.")
    except Exception as e:
        logger.error(f"Failed to initialize orchestrator: {e}")
        # Should we prevent startup? Yes.
        raise RuntimeError("Failed to initialize orchestrator") from e
    yield
    logger.info("Shutting down...")


app = FastAPI(lifespan=lifespan, title="Coreason Publisher Service")


def _get_orchestrator(request: Request) -> PublisherOrchestrator:
    return request.app.state.orchestrator  # type: ignore[no-any-return]


def _create_user_context(user_id: str, groups: List[str]) -> UserContext:
    """
    Creates a UserContext for the API request user.

    WARNING: This implementation currently relies on network-level security and trusted upstreams.
    It does not perform authentication verification (e.g. JWT validation).
    Permissions are scoped to the specific action being performed via the 'groups' argument.
    """
    return UserContext(
        user_id=user_id,
        email=f"{user_id}@coreason.ai",
        groups=groups,
        scopes=["*"],
        claims={"sub": user_id},
    )


@app.post("/propose", status_code=status.HTTP_202_ACCEPTED)
def propose(
    payload: ProposeRequest,
    request: Request,
) -> Dict[str, str]:
    """
    Triggers the proposal workflow.
    Defined as synchronous to run in threadpool (Git operations are blocking).
    """
    orchestrator = _get_orchestrator(request)
    # Propose is an SRE action
    user_context = _create_user_context(payload.user_id, groups=["SRE"])

    try:
        orchestrator.propose_release(
            project_id=payload.project_id,
            foundry_draft_id=payload.draft_id,
            bump_type=payload.bump_type,
            user_context=user_context,
            release_description=payload.description,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)) from e
    except RuntimeError as e:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(e)) from e
    except Exception as e:
        logger.exception("Propose failed")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)) from e

    return {"status": "accepted", "message": "Release proposal submitted"}


@app.post("/release", status_code=status.HTTP_200_OK)
def release(
    payload: ReleaseRequest,
    request: Request,
) -> Dict[str, str]:
    """
    Triggers the release finalization workflow.
    """
    orchestrator = _get_orchestrator(request)
    # Release is an SRB action
    user_context = _create_user_context(payload.srb_user_id, groups=["SRB"])

    try:
        orchestrator.finalize_release(
            mr_id=payload.mr_id,
            srb_signature=payload.srb_signature,
            user_context=user_context,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)) from e
    except RuntimeError as e:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(e)) from e
    except Exception as e:
        logger.exception("Release failed")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)) from e

    return {"status": "success", "message": "Release finalized"}


@app.post("/reject", status_code=status.HTTP_200_OK)
def reject(
    payload: RejectRequest,
    request: Request,
) -> Dict[str, str]:
    """
    Triggers the rejection workflow.
    """
    orchestrator = _get_orchestrator(request)
    # Reject is an SRB action (kickback)
    # Although reject_release doesn't explicitly take user_context in current signature (checked code),
    # the endpoint logic is consistent.

    try:
        orchestrator.reject_release(
            mr_id=payload.mr_id,
            draft_id=payload.draft_id,
            reason=payload.reason,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)) from e
    except RuntimeError as e:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(e)) from e
    except Exception as e:
        logger.exception("Reject failed")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)) from e

    return {"status": "success", "message": "Release rejected"}


@app.get("/health", status_code=status.HTTP_200_OK)
def health(request: Request) -> Dict[str, str]:
    """
    Health check.
    Verifies Git LFS and Git Provider connection.
    """
    orchestrator = _get_orchestrator(request)

    # Check LFS
    if not orchestrator.git_lfs.is_initialized(orchestrator.workspace_path):
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Git LFS not initialized")

    # Check Git Provider
    try:
        # Trigger lazy load or check connection
        # The base interface GitProvider might not expose 'project' (it's likely on GitLabProvider)
        # We should check if it has the attribute or use a generic check method if available.
        # Assuming GitProvider interface or specific implementation usage:
        if hasattr(orchestrator.git_provider, "project"):
            _ = orchestrator.git_provider.project
    except Exception as e:
        logger.error(f"Git Provider check failed: {e}")
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Git Provider unavailable") from e

    return {"status": "healthy"}
