"Corebridge - a bridge between Univia AICore platform and Wodan processor modules"

__version__ = "0.6.6"
__all__ = ["__version__"]