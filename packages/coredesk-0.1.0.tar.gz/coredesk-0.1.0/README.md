# CoreDesk

**CoreDesk** is an open-source, quant-dev–oriented Python library for **pricing, risk, and calibration** of vanilla derivatives.

It is designed to provide **clean, explicit, desk-grade building blocks** for quantitative finance, with a strong focus on **numerical robustness**, **readability**, and **testability**.

---

## 🧭 Philosophy

CoreDesk follows four core principles:

* **Explicit over implicit**
  No hidden globals, no silent conventions.

* **Separation of concerns**
  Products ≠ Models ≠ Market ≠ Engines.

* **Numerical robustness**
  Bracketing, tolerances, clear failure modes.

* **Desk-grade readability**
  Code written to be read, reviewed, and extended.

This makes CoreDesk suitable for:

* quantitative finance education
* research notebooks
* interview preparation
* prototyping pricing libraries
* model validation and experimentation

---

## 🧱 Architecture overview

```text
coredesk/
├─ core/           # numerical foundations
├─ market/         # conventions & market environment
├─ products/       # financial instruments (payoff only)
├─ models/         # model parameters (no pricing logic)
├─ engines/        # pricing engines
├─ risk/           # Greeks
├─ calibration/    # implied volatility
└─ api/            # user-facing helpers
```

### Module responsibilities

| Module        | Responsibility                                 |
| ------------- | ---------------------------------------------- |
| `core`        | math, stats, roots, interpolation, linalg, RNG |
| `market`      | day count, rate conventions, market inputs     |
| `products`    | contract definitions (payoff only)             |
| `models`      | model parameters (volatility, dynamics)        |
| `engines`     | pricing logic                                  |
| `risk`        | Greeks                                         |
| `calibration` | implied volatility                             |
| `api`         | simplified public interface                    |

---

## ✨ Features (v0.1)

* European vanilla options
* Black–Scholes–Merton (spot + dividend yield)
* Black 76 (options on forwards/futures)
* Closed-form pricing
* Analytic Greeks (Delta, Gamma, Vega)
* Implied volatility (Brent solver)
* Robust numerical core:

  * root finding (bisect / brent / newton)
  * interpolation (linear / log-linear)
  * Cholesky & correlation repair
  * reproducible RNG
* Fully tested (`pytest`)

---

## 📦 Installation

### From source (recommended)

```bash
git clone https://github.com/baptiste-dehay/coredesk.git
cd coredesk
pip install -e .[dev]
```

### Run tests

```bash
python -m pytest
```

---

## 🚀 Quick start (API)

### Black–Scholes price

```python
from coredesk.api.vanilla import bsm_price

price = bsm_price(
    spot=100.0,
    strike=110.0,
    maturity=1.0,
    option_type="call",
    sigma=0.30,
    r=0.02,
    q=0.01,
)

print(price)
```

### Greeks

```python
from coredesk.api.vanilla import bsm_greeks

greeks = bsm_greeks(
    spot=100.0,
    strike=110.0,
    maturity=1.0,
    option_type="call",
    sigma=0.30,
    r=0.02,
    q=0.01,
)

print(greeks.delta, greeks.gamma, greeks.vega)
```

### Implied volatility (BSM)

```python
from coredesk.api.vanilla import bsm_iv

iv = bsm_iv(
    price=price,
    spot=100.0,
    strike=110.0,
    maturity=1.0,
    option_type="call",
    r=0.02,
    q=0.01,
)

print(iv)
```

### Black 76 (options on forwards / futures)

```python
from coredesk.api.vanilla import black76_price, black76_iv

price = black76_price(
    forward=100.0,
    strike=95.0,
    maturity=2.0,
    option_type="put",
    sigma=0.25,
    r=0.01,
)

iv = black76_iv(
    price=price,
    forward=100.0,
    strike=95.0,
    maturity=2.0,
    option_type="put",
    r=0.01,
)

print(price, iv)
```

---

## 📚 Glossary of functions (Public API)

### Pricing

| Function        | Description                                        |
| --------------- | -------------------------------------------------- |
| `bsm_price`     | Black–Scholes–Merton price (spot + dividend yield) |
| `black76_price` | Black 76 price (options on forwards/futures)       |

### Greeks

| Function         | Description                  |
| ---------------- | ---------------------------- |
| `bsm_greeks`     | Delta, Gamma, Vega (spot)    |
| `black76_greeks` | Delta, Gamma, Vega (forward) |

### Calibration

| Function     | Description                       |
| ------------ | --------------------------------- |
| `bsm_iv`     | Implied volatility under BSM      |
| `black76_iv` | Implied volatility under Black 76 |

---

## 📐 Core numerical toolbox

### `core.stats`

* `normal_pdf`
* `normal_cdf`
* `normal_ppf`

### `core.roots`

* `bisect`
* `newton`
* `brent`

### `core.interpolation`

* `linear_interp`
* `log_linear_interp`
* `Interp1D`

### `core.linalg`

* `cholesky`
* `nearest_correlation`
* `check_correlation_matrix`

### `core.random`

* `RNG`
* standard normals
* antithetic sampling

---

## 🛣️ Roadmap (Applications)

### v0.2 — Curves & discounting

* Yield curves
* Discount factors
* Bootstrapping

### v0.3 — Volatility

* Volatility surfaces
* Smile calibration
* Surface interpolation / extrapolation

### v0.4 — Monte Carlo

* GBM path simulation
* Multi-asset correlation
* Greeks via Monte Carlo

### v0.5 — Advanced products

* American options (LSM)
* Barrier options
* Asian options

---

## 🧪 Testing & quality

* 100% pytest-based
* Finite-difference validation for Greeks
* Numerical tolerances explicit
* Designed to be CI-friendly

---

## 📄 License

Open-source (see `LICENSE`).

---

## 👤 Author

**Baptiste Dehay**
Quantitative Finance / Financial Engineering
"Baptiste is analyzing, the world is watching"