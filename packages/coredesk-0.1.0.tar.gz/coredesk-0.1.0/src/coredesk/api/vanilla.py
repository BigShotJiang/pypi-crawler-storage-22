"""
coredesk.api.vanilla

User-facing API for vanilla European options.
Keeps the internal architecture (product/model/market/engine) but offers
convenient functions for day-to-day usage.

Implemented:
- BSM (spot, with q): price, greeks, implied vol
- Black76 (forward/futures): price, greeks, implied vol
"""

from __future__ import annotations

from dataclasses import dataclass

from coredesk.calibration.implied_vol import implied_vol_black76, implied_vol_bsm
from coredesk.engines.analytic import AnalyticEngine
from coredesk.market.environment import MarketEnvironment
from coredesk.models.black_76 import Black76Model
from coredesk.models.black_scholes import BlackScholesModel
from coredesk.products.european_option import EuropeanOption
from coredesk.risk.greeks import (
    delta_black76_forward,
    delta_bsm,
    gamma_black76_forward,
    gamma_bsm,
    vega_black76,
    vega_bsm,
)


@dataclass(frozen=True)
class VanillaGreeks:
    delta: float
    gamma: float
    vega: float


_ENGINE = AnalyticEngine()


# ---------- BSM (spot) ----------

def bsm_price(
    *,
    spot: float,
    strike: float,
    maturity: float,
    option_type: str,
    sigma: float,
    r: float = 0.0,
    q: float = 0.0,
    engine: AnalyticEngine = _ENGINE,
) -> float:
    mkt = MarketEnvironment(r=r, q=q, sigma=sigma)
    opt = EuropeanOption(option_type, strike=strike, maturity=maturity)
    mdl = BlackScholesModel(sigma=sigma)
    return engine.price_bsm(spot, opt, mdl, mkt)


def bsm_greeks(
    *,
    spot: float,
    strike: float,
    maturity: float,
    option_type: str,
    sigma: float,
    r: float = 0.0,
    q: float = 0.0,
) -> VanillaGreeks:
    mkt = MarketEnvironment(r=r, q=q, sigma=sigma)
    opt = EuropeanOption(option_type, strike=strike, maturity=maturity)
    mdl = BlackScholesModel(sigma=sigma)
    return VanillaGreeks(
        delta=delta_bsm(spot, opt, mdl, mkt),
        gamma=gamma_bsm(spot, opt, mdl, mkt),
        vega=vega_bsm(spot, opt, mdl, mkt),
    )


def bsm_iv(
    *,
    price: float,
    spot: float,
    strike: float,
    maturity: float,
    option_type: str,
    r: float = 0.0,
    q: float = 0.0,
) -> float:
    mkt = MarketEnvironment(r=r, q=q, sigma=0.2)  # sigma placeholder; solver varies it
    opt = EuropeanOption(option_type, strike=strike, maturity=maturity)
    return implied_vol_bsm(price, spot, opt, mkt).iv


# ---------- Black76 (forward/futures) ----------

def black76_price(
    *,
    forward: float,
    strike: float,
    maturity: float,
    option_type: str,
    sigma: float,
    r: float = 0.0,
    engine: AnalyticEngine = _ENGINE,
) -> float:
    mkt = MarketEnvironment(r=r, q=0.0, sigma=sigma)
    opt = EuropeanOption(option_type, strike=strike, maturity=maturity)
    mdl = Black76Model(sigma=sigma)
    return engine.price_black76(forward, opt, mdl, mkt)


def black76_greeks(
    *,
    forward: float,
    strike: float,
    maturity: float,
    option_type: str,
    sigma: float,
    r: float = 0.0,
) -> VanillaGreeks:
    mkt = MarketEnvironment(r=r, q=0.0, sigma=sigma)
    opt = EuropeanOption(option_type, strike=strike, maturity=maturity)
    mdl = Black76Model(sigma=sigma)
    return VanillaGreeks(
        delta=delta_black76_forward(forward, opt, mdl, mkt),
        gamma=gamma_black76_forward(forward, opt, mdl, mkt),
        vega=vega_black76(forward, opt, mdl, mkt),
    )


def black76_iv(
    *,
    price: float,
    forward: float,
    strike: float,
    maturity: float,
    option_type: str,
    r: float = 0.0,
) -> float:
    mkt = MarketEnvironment(r=r, q=0.0, sigma=0.2)  # placeholder
    opt = EuropeanOption(option_type, strike=strike, maturity=maturity)
    return implied_vol_black76(price, forward, opt, mkt).iv
