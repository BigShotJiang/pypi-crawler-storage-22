"""
coredesk.calibration.implied_vol

Implied volatility solvers for vanilla European options.

v0.1:
- Black 76 implied vol (options on forwards/futures)
- Robust bracketing + Brent root solver
"""

from __future__ import annotations

from dataclasses import dataclass

from coredesk.core.constants import MAX_VOL, MIN_VOL
from coredesk.core.exceptions import InvalidDomainError, NonConvergenceError, RootNotBracketedError
from coredesk.core.roots import brent
from coredesk.engines.analytic import AnalyticEngine
from coredesk.market.environment import MarketEnvironment
from coredesk.models.black_76 import Black76Model
from coredesk.products.european_option import EuropeanOption

from coredesk.models.black_scholes import BlackScholesModel

@dataclass(frozen=True)
class ImpliedVolResult:
    iv: float
    iterations: int
    converged: bool


def implied_vol_black76(
    price: float,
    forward: float,
    product: EuropeanOption,
    market: MarketEnvironment,
    *,
    vol_lower: float = MIN_VOL,
    vol_upper: float = MAX_VOL,
    tol: float = 1e-12,
    max_iter: int = 200,
    engine: AnalyticEngine | None = None,
) -> ImpliedVolResult:
    """
    Implied volatility under Black 76 for a European option.

    Args:
        price: option price (present value)
        forward: forward/futures level F
        product: EuropeanOption
        market: MarketEnvironment (uses r and maturity via product.maturity)
        vol_lower, vol_upper: bracket for sigma
        tol, max_iter: root solver settings
        engine: optional pricer engine

    Returns:
        ImpliedVolResult

    Raises:
        InvalidDomainError: invalid inputs
        RootNotBracketedError: if price not bracketed by vol_lower/vol_upper
        NonConvergenceError: if solver fails
    """
    if price < 0.0:
        raise InvalidDomainError("implied_vol_black76: price must be >= 0.")
    if forward <= 0.0:
        raise InvalidDomainError("implied_vol_black76: forward must be > 0.")
    if product.strike <= 0.0:
        raise InvalidDomainError("implied_vol_black76: strike must be > 0.")
    if product.maturity < 0.0:
        raise InvalidDomainError("implied_vol_black76: maturity must be >= 0.")
    if vol_lower <= 0.0 or vol_upper <= 0.0 or vol_upper <= vol_lower:
        raise InvalidDomainError("implied_vol_black76: invalid vol bracket.")

    if engine is None:
        engine = AnalyticEngine()

    # Handle expiry explicitly
    if product.maturity == 0.0:
        # At expiry, implied vol is undefined; return 0 if price matches intrinsic, else error.
        intrinsic = product.payoff(forward)
        if abs(price - intrinsic) <= 1e-12:
            return ImpliedVolResult(iv=0.0, iterations=0, converged=True)
        raise InvalidDomainError("implied_vol_black76: maturity=0 but price != intrinsic.")

    def objective(sig: float) -> float:
        mdl = Black76Model(sigma=sig)
        return engine.price_black76(forward, product, mdl, market) - price

    # Quick arbitrage bounds check (soft): price must be between sigma->0 and sigma->upper
    f_lo = objective(vol_lower)
    f_hi = objective(vol_upper)

    # If already hits
    if abs(f_lo) <= tol:
        return ImpliedVolResult(iv=vol_lower, iterations=0, converged=True)
    if abs(f_hi) <= tol:
        return ImpliedVolResult(iv=vol_upper, iterations=0, converged=True)

    # Must bracket the root
    if f_lo * f_hi > 0.0:
        raise RootNotBracketedError(
            "implied_vol_black76: price not bracketed by [vol_lower, vol_upper]. "
            f"(f(lo)={f_lo:+.3e}, f(hi)={f_hi:+.3e})"
        )

    res = brent(objective, vol_lower, vol_upper, tol=tol, max_iter=max_iter)
    return ImpliedVolResult(iv=res.root, iterations=res.iterations, converged=res.converged)

def implied_vol_bsm(
    price: float,
    spot: float,
    product: EuropeanOption,
    market: MarketEnvironment,
    *,
    vol_lower: float = MIN_VOL,
    vol_upper: float = MAX_VOL,
    tol: float = 1e-12,
    max_iter: int = 200,
    engine: AnalyticEngine | None = None,
) -> ImpliedVolResult:
    """
    Implied volatility under Black–Scholes–Merton for a European option on spot.

    Args:
        price: option price (present value)
        spot: spot level S
        product: EuropeanOption
        market: MarketEnvironment (uses r and q)
        vol_lower, vol_upper: bracket for sigma
        tol, max_iter: root solver settings
        engine: optional pricer engine
    """
    if price < 0.0:
        raise InvalidDomainError("implied_vol_bsm: price must be >= 0.")
    if spot <= 0.0:
        raise InvalidDomainError("implied_vol_bsm: spot must be > 0.")
    if product.strike <= 0.0:
        raise InvalidDomainError("implied_vol_bsm: strike must be > 0.")
    if product.maturity < 0.0:
        raise InvalidDomainError("implied_vol_bsm: maturity must be >= 0.")
    if vol_lower <= 0.0 or vol_upper <= 0.0 or vol_upper <= vol_lower:
        raise InvalidDomainError("implied_vol_bsm: invalid vol bracket.")

    if engine is None:
        engine = AnalyticEngine()

    if product.maturity == 0.0:
        intrinsic = product.payoff(spot)
        if abs(price - intrinsic) <= 1e-12:
            return ImpliedVolResult(iv=0.0, iterations=0, converged=True)
        raise InvalidDomainError("implied_vol_bsm: maturity=0 but price != intrinsic.")

    def objective(sig: float) -> float:
        mdl = BlackScholesModel(sigma=sig)
        return engine.price_bsm(spot, product, mdl, market) - price

    f_lo = objective(vol_lower)
    f_hi = objective(vol_upper)

    if abs(f_lo) <= tol:
        return ImpliedVolResult(iv=vol_lower, iterations=0, converged=True)
    if abs(f_hi) <= tol:
        return ImpliedVolResult(iv=vol_upper, iterations=0, converged=True)

    if f_lo * f_hi > 0.0:
        raise RootNotBracketedError(
            "implied_vol_bsm: price not bracketed by [vol_lower, vol_upper]. "
            f"(f(lo)={f_lo:+.3e}, f(hi)={f_hi:+.3e})"
        )

    res = brent(objective, vol_lower, vol_upper, tol=tol, max_iter=max_iter)
    return ImpliedVolResult(iv=res.root, iterations=res.iterations, converged=res.converged)
