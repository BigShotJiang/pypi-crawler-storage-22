from __future__ import annotations

from . import constants
from .exceptions import (
    CoreDeskError,
    InvalidDomainError,
    NonConvergenceError,
    NumericalStabilityError,
    RootNotBracketedError,
)
from .stats import normal_cdf, normal_pdf, normal_ppf

__all__ = [
    "constants",
    "CoreDeskError",
    "InvalidDomainError",
    "NonConvergenceError",
    "NumericalStabilityError",
    "RootNotBracketedError",
    "normal_pdf",
    "normal_cdf",
    "normal_ppf",
]

from .roots import RootResult, bisect, brent, newton

__all__ += ["RootResult", "bisect", "newton", "brent"]

from .interpolation import Interp1D, linear_interp, log_linear_interp
__all__ += ["Interp1D", "linear_interp", "log_linear_interp"]

from .linalg import (
    check_correlation_matrix,
    cholesky,
    is_positive_definite,
    is_symmetric,
    nearest_correlation,
)

__all__ += [
    "is_symmetric",
    "is_positive_definite",
    "check_correlation_matrix",
    "cholesky",
    "nearest_correlation",
]

from .random import RNG, make_rng

__all__ += ["RNG", "make_rng"]
