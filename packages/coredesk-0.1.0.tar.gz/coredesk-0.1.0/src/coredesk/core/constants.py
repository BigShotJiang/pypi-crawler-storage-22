"""
coredesk.core.constants

Centralized numerical constants and defaults used across CoreDesk.
Keep this module dependency-free.
"""

from __future__ import annotations

# Generic numerical tolerances
EPS: float = 1e-12
RTOL: float = 1e-10
ATOL: float = 1e-12

# Iteration defaults
MAX_ITER: int = 100

# Practical bounds
MIN_VOL: float = 1e-8
MAX_VOL: float = 5.0

# Time guards
MIN_T: float = 0.0