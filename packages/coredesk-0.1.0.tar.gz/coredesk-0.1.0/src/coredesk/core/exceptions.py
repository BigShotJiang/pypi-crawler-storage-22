"""
coredesk.core.exceptions

Explicit exception hierarchy for numerical and domain errors.
"""

from __future__ import annotations


class CoreDeskError(Exception):
    """Base exception for CoreDesk."""


class InvalidDomainError(CoreDeskError, ValueError):
    """Raised when inputs are outside the mathematical/financial domain."""


class NonConvergenceError(CoreDeskError, RuntimeError):
    """Raised when a numerical method fails to converge."""


class RootNotBracketedError(CoreDeskError, ValueError):
    """Raised when a bracketing method is called with f(a) and f(b) of same sign."""


class NumericalStabilityError(CoreDeskError, RuntimeError):
    """Raised when a computation is deemed numerically unstable."""
