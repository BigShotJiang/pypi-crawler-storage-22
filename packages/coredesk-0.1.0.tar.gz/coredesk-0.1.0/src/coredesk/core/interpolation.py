"""
coredesk.core.interpolation

Interpolation utilities (1D), dependency-free (NumPy only).

Design goals:
- Explicit behavior
- Vectorized inputs
- Deterministic extrapolation rules (explicitly chosen by caller)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np

from coredesk.core.exceptions import InvalidDomainError

Extrap = Literal["error", "flat"]


@dataclass(frozen=True)
class Interp1D:
    xp: np.ndarray
    yp: np.ndarray
    kind: Literal["linear", "log_linear"]
    extrap: Extrap = "error"

    def __post_init__(self) -> None:
        xp = np.asarray(self.xp, dtype=float)
        yp = np.asarray(self.yp, dtype=float)

        if xp.ndim != 1 or yp.ndim != 1:
            raise InvalidDomainError("Interp1D: xp and yp must be 1D arrays.")
        if xp.size != yp.size or xp.size < 2:
            raise InvalidDomainError("Interp1D: xp and yp must have same size >= 2.")
        if np.any(~np.isfinite(xp)) or np.any(~np.isfinite(yp)):
            raise InvalidDomainError("Interp1D: xp/yp must be finite.")
        if np.any(np.diff(xp) <= 0.0):
            raise InvalidDomainError("Interp1D: xp must be strictly increasing.")

        if self.kind == "log_linear":
            if np.any(yp <= 0.0):
                raise InvalidDomainError("Interp1D(log_linear): yp must be > 0.")

        object.__setattr__(self, "xp", xp)
        object.__setattr__(self, "yp", yp)

    def __call__(self, x: float | np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=float)

        if np.any(~np.isfinite(x)):
            raise InvalidDomainError("Interp1D: x must be finite.")

        x_min = self.xp[0]
        x_max = self.xp[-1]

        if self.extrap == "error":
            if np.any(x < x_min) or np.any(x > x_max):
                raise InvalidDomainError("Interp1D: x outside grid and extrap='error'.")

        if self.extrap == "flat":
            x = np.clip(x, x_min, x_max)

        if self.kind == "linear":
            return np.interp(x, self.xp, self.yp)

        # log-linear interpolation on y
        logy = np.log(self.yp)
        out = np.interp(x, self.xp, logy)
        return np.exp(out)


def linear_interp(
    x: float | np.ndarray,
    xp: np.ndarray,
    yp: np.ndarray,
    *,
    extrap: Extrap = "error",
) -> np.ndarray:
    return Interp1D(xp=xp, yp=yp, kind="linear", extrap=extrap)(x)


def log_linear_interp(
    x: float | np.ndarray,
    xp: np.ndarray,
    yp: np.ndarray,
    *,
    extrap: Extrap = "error",
) -> np.ndarray:
    return Interp1D(xp=xp, yp=yp, kind="log_linear", extrap=extrap)(x)
