"""
coredesk.core.linalg

Lightweight linear algebra helpers (NumPy only), focused on desk needs:
- correlation matrix validation
- Cholesky factorization with explicit failures
- nearest correlation matrix (optional but very useful in practice)

Notes:
- We keep behavior explicit: invalid inputs raise exceptions.
"""

from __future__ import annotations

import numpy as np

from coredesk.core.constants import EPS
from coredesk.core.exceptions import InvalidDomainError, NumericalStabilityError

def is_symmetric(a: np.ndarray, *, atol: float = 1e-12) -> bool:
    a = np.asarray(a, dtype=float)
    if a.ndim != 2 or a.shape[0] != a.shape[1]:
        return False
    return np.allclose(a, a.T, atol=atol, rtol=0.0)


def is_positive_definite(a: np.ndarray) -> bool:
    """
    Returns True if a is (numerically) positive definite (Cholesky succeeds).
    """
    a = np.asarray(a, dtype=float)
    if a.ndim != 2 or a.shape[0] != a.shape[1]:
        return False
    try:
        _ = np.linalg.cholesky(a)
        return True
    except np.linalg.LinAlgError:
        return False


def check_correlation_matrix(corr: np.ndarray, *, atol: float = 1e-10) -> None:
    """
    Validates a correlation matrix:
    - square
    - symmetric
    - diagonal ~ 1
    - entries in [-1, 1] (within tolerance)
    """
    corr = np.asarray(corr, dtype=float)

    if corr.ndim != 2 or corr.shape[0] != corr.shape[1]:
        raise InvalidDomainError("Correlation matrix must be square.")

    if not is_symmetric(corr, atol=atol):
        raise InvalidDomainError("Correlation matrix must be symmetric.")

    diag = np.diag(corr)
    if not np.allclose(diag, 1.0, atol=atol, rtol=0.0):
        raise InvalidDomainError("Correlation matrix diagonal must be 1.")

    if np.any(corr < -1.0 - atol) or np.any(corr > 1.0 + atol):
        raise InvalidDomainError("Correlation entries must be in [-1, 1].")

    if np.any(~np.isfinite(corr)):
        raise InvalidDomainError("Correlation matrix must be finite.")


def cholesky(
    a: np.ndarray,
    *,
    jitter: float = 0.0,
    max_tries: int = 5,
) -> np.ndarray:
    """
    Cholesky factorization with optional diagonal jitter.

    Args:
        a: symmetric (semi-)PD matrix.
        jitter: initial diagonal bump added if decomposition fails.
        max_tries: number of increasing jitter attempts.

    Returns:
        Lower-triangular L such that L @ L.T ≈ a (+ jitter*I).

    Raises:
        InvalidDomainError: if a is not square/symmetric/finite
        NumericalStabilityError: if Cholesky fails even after jitter
    """
    a = np.asarray(a, dtype=float)
    if a.ndim != 2 or a.shape[0] != a.shape[1]:
        raise InvalidDomainError("cholesky: matrix must be square.")
    if np.any(~np.isfinite(a)):
        raise InvalidDomainError("cholesky: matrix must be finite.")
    if not is_symmetric(a, atol=1e-12):
        raise InvalidDomainError("cholesky: matrix must be symmetric.")

    n = a.shape[0]

    # Fast path
    try:
        return np.linalg.cholesky(a)
    except np.linalg.LinAlgError:
        pass

    if jitter <= 0.0:
        raise NumericalStabilityError("cholesky: matrix is not positive definite.")

    bump = float(jitter)
    for _ in range(max_tries):
        try:
            return np.linalg.cholesky(a + bump * np.eye(n))
        except np.linalg.LinAlgError:
            bump *= 10.0

    raise NumericalStabilityError("cholesky: failed even after jitter attempts.")


def nearest_correlation(
    a: np.ndarray,
    *,
    max_iter: int = 100,
    tol: float = 1e-10,
) -> np.ndarray:
    """
    Higham (2002)-style projection to the nearest correlation matrix.
    (Frobenius norm, iterative alternating projections.)

    Practical use: cleaning noisy/invalid correlation estimates.

    Returns:
        corr matrix with diag=1 and PSD.

    Raises:
        InvalidDomainError: if input is not square/finite.
    """
    a = np.asarray(a, dtype=float)
    if a.ndim != 2 or a.shape[0] != a.shape[1]:
        raise InvalidDomainError("nearest_correlation: matrix must be square.")
    if np.any(~np.isfinite(a)):
        raise InvalidDomainError("nearest_correlation: matrix must be finite.")

    n = a.shape[0]
    # Start from symmetrized matrix
    y = 0.5 * (a + a.T)
    delta_s = np.zeros_like(y)

    for _ in range(max_iter):
        # Projection onto PSD cone
        r = y - delta_s
        vals, vecs = np.linalg.eigh(r)
        vals = np.maximum(vals, 0.0)
        x = (vecs * vals) @ vecs.T  # vecs @ diag(vals) @ vecs.T

        # Update correction
        delta_s = x - r

        # Projection onto unit diagonal (correlation constraint)
        y_prev = y
        y = x.copy()
        np.fill_diagonal(y, 1.0)

        # Convergence check
        if np.linalg.norm(y - y_prev, ord="fro") <= tol * max(1.0, np.linalg.norm(y, ord="fro")):
            break

    # Final symmetrize and ensure diag=1
    y = 0.5 * (y + y.T)
    np.fill_diagonal(y, 1.0)

    # Tiny negative eigenvalues due to rounding -> clip
    vals, vecs = np.linalg.eigh(y)
    if np.min(vals) < -np.sqrt(EPS):
        # If it's meaningfully negative, signal
        raise NumericalStabilityError("nearest_correlation: failed to produce PSD matrix.")
    vals = np.maximum(vals, 0.0)
    y = (vecs * vals) @ vecs.T
    y = 0.5 * (y + y.T)
    np.fill_diagonal(y, 1.0)
    return y

def is_positive_semidefinite(a: np.ndarray, *, tol: float = 1e-10) -> bool:
    a = np.asarray(a, dtype=float)
    if a.ndim != 2 or a.shape[0] != a.shape[1]:
        return False
    if not is_symmetric(a, atol=tol):
        return False
    lam_min = float(np.min(np.linalg.eigvalsh(a)))
    return lam_min >= -tol
