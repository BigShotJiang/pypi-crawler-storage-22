"""
coredesk.core.random

Centralized random number generation utilities.

Goals:
- Reproducible simulations (explicit seeds)
- No hidden global RNG usage elsewhere in the library
- Easy variance reduction (antithetic sampling)

We rely on NumPy's Generator API (PCG64 by default).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from coredesk.core.exceptions import InvalidDomainError


@dataclass(frozen=True)
class RNG:
    """
    Small wrapper around numpy.random.Generator to standardize behavior.
    """
    generator: np.random.Generator

    @classmethod
    def from_seed(cls, seed: int | None) -> "RNG":
        if seed is None:
            return cls(np.random.default_rng())
        if not isinstance(seed, int):
            raise InvalidDomainError("RNG.from_seed: seed must be an int or None.")
        if seed < 0:
            raise InvalidDomainError("RNG.from_seed: seed must be >= 0.")
        return cls(np.random.default_rng(seed))

    def standard_normals(
        self,
        shape: int | tuple[int, ...],
        *,
        antithetic: bool = False,
        dtype: type = float,
    ) -> np.ndarray:
        """
        Generate standard normal samples.

        Args:
            shape: output shape
            antithetic: if True, returns concatenated [Z, -Z] along axis=0
                        Requires that shape[0] is the number of paths.
            dtype: float type

        Returns:
            ndarray of normals.

        Notes:
            If antithetic=True and shape is an int N, returns 2N samples.
            If shape is a tuple (n, ...), returns (2n, ...) samples.
        """
        if isinstance(shape, int):
            shp = (shape,)
        else:
            shp = tuple(shape)

        if len(shp) == 0 or shp[0] <= 0:
            raise InvalidDomainError("standard_normals: shape must be positive.")

        z = self.generator.standard_normal(size=shp).astype(dtype, copy=False)

        if not antithetic:
            return z

        z_ant = -z
        return np.concatenate([z, z_ant], axis=0)

    def uniforms(
        self,
        shape: int | tuple[int, ...],
        *,
        low: float = 0.0,
        high: float = 1.0,
        dtype: type = float,
    ) -> np.ndarray:
        """
        Uniform samples in [low, high).
        """
        if high <= low:
            raise InvalidDomainError("uniforms: require high > low.")
        if isinstance(shape, int):
            shp = (shape,)
        else:
            shp = tuple(shape)
        if len(shp) == 0 or shp[0] <= 0:
            raise InvalidDomainError("uniforms: shape must be positive.")
        u = self.generator.uniform(low=low, high=high, size=shp).astype(dtype, copy=False)
        return u


def make_rng(seed: int | None = None) -> RNG:
    """
    Convenience factory.
    """
    return RNG.from_seed(seed)
