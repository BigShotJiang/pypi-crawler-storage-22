"""
coredesk.core.roots

Scalar root-finding algorithms, dependency-free (NumPy only).

Design goals:
- Deterministic behavior
- Clear bracketing rules
- Explicit non-convergence errors
- Consistent return type (float)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

from coredesk.core.constants import EPS, MAX_ITER
from coredesk.core.exceptions import NonConvergenceError, RootNotBracketedError

Func = Callable[[float], float]
Deriv = Callable[[float], float]


@dataclass(frozen=True)
class RootResult:
    root: float
    iterations: int
    converged: bool
    f_root: float


def bisect(
    f: Func,
    a: float,
    b: float,
    *,
    tol: float = 1e-12,
    max_iter: int = MAX_ITER,
) -> RootResult:
    """
    Bisection method for f(x)=0 on [a,b] with f(a)*f(b) <= 0.

    Raises:
        RootNotBracketedError: if f(a) and f(b) have same sign
        NonConvergenceError: if it fails to converge within max_iter
    """
    a = float(a)
    b = float(b)
    if not np.isfinite(a) or not np.isfinite(b):
        raise ValueError("bisect: a and b must be finite.")
    if a == b:
        fa = float(f(a))
        return RootResult(root=a, iterations=0, converged=abs(fa) <= tol, f_root=fa)

    fa = float(f(a))
    fb = float(f(b))
    if not np.isfinite(fa) or not np.isfinite(fb):
        raise ValueError("bisect: f(a) and f(b) must be finite.")
    if fa == 0.0:
        return RootResult(root=a, iterations=0, converged=True, f_root=fa)
    if fb == 0.0:
        return RootResult(root=b, iterations=0, converged=True, f_root=fb)

    if fa * fb > 0.0:
        raise RootNotBracketedError(
            f"bisect: root not bracketed (f(a)={fa:+.3e}, f(b)={fb:+.3e})."
        )

    lo, hi = (a, b) if a < b else (b, a)
    flo = float(f(lo))
    fhi = float(f(hi))

    for it in range(1, max_iter + 1):
        mid = 0.5 * (lo + hi)
        fmid = float(f(mid))

        if abs(fmid) <= tol or (hi - lo) <= max(tol, EPS):
            return RootResult(root=mid, iterations=it, converged=True, f_root=fmid)

        # Keep the subinterval that brackets the root
        if flo * fmid <= 0.0:
            hi, fhi = mid, fmid
        else:
            lo, flo = mid, fmid

    raise NonConvergenceError("bisect: failed to converge within max_iter.")


def newton(
    f: Func,
    fprime: Deriv,
    x0: float,
    *,
    tol: float = 1e-12,
    max_iter: int = MAX_ITER,
    step_tol: float | None = None,
) -> RootResult:
    """
    Newton-Raphson method.

    Raises:
        NonConvergenceError: if it fails to converge
    """
    x = float(x0)
    if not np.isfinite(x):
        raise ValueError("newton: x0 must be finite.")

    if step_tol is None:
        step_tol = tol

    fx = float(f(x))
    for it in range(1, max_iter + 1):
        if abs(fx) <= tol:
            return RootResult(root=x, iterations=it - 1, converged=True, f_root=fx)

        dfx = float(fprime(x))
        if not np.isfinite(dfx) or dfx == 0.0:
            raise NonConvergenceError("newton: derivative is zero or non-finite.")

        step = fx / dfx
        x_new = x - step

        if not np.isfinite(x_new):
            raise NonConvergenceError("newton: produced non-finite iterate.")

        if abs(step) <= step_tol:
            fx_new = float(f(x_new))
            return RootResult(root=x_new, iterations=it, converged=True, f_root=fx_new)

        x = x_new
        fx = float(f(x))

    raise NonConvergenceError("newton: failed to converge within max_iter.")


def brent(
    f: Func,
    a: float,
    b: float,
    *,
    tol: float = 1e-12,
    max_iter: int = MAX_ITER,
) -> RootResult:
    """
    Brent's method (robust, fast) on [a,b], requiring a bracket.

    This implementation follows the classic Brent-Dekker approach.
    """
    a = float(a)
    b = float(b)

    fa = float(f(a))
    fb = float(f(b))
    if fa == 0.0:
        return RootResult(root=a, iterations=0, converged=True, f_root=fa)
    if fb == 0.0:
        return RootResult(root=b, iterations=0, converged=True, f_root=fb)

    if fa * fb > 0.0:
        raise RootNotBracketedError(
            f"brent: root not bracketed (f(a)={fa:+.3e}, f(b)={fb:+.3e})."
        )

    # Ensure |fa| >= |fb| so b is the best current estimate
    if abs(fa) < abs(fb):
        a, b = b, a
        fa, fb = fb, fa

    c = a
    fc = fa
    d = e = b - a

    for it in range(1, max_iter + 1):
        if abs(fb) <= tol:
            return RootResult(root=b, iterations=it - 1, converged=True, f_root=fb)

        if fa * fb > 0.0:
            a, fa = c, fc
            d = e = b - a

        if abs(fa) < abs(fb):
            c, fc = b, fb
            b, fb = a, fa
            a, fa = c, fc

        # Convergence check
        m = 0.5 * (a - b)
        tol_act = 2.0 * EPS * abs(b) + tol

        if abs(m) <= tol_act:
            return RootResult(root=b, iterations=it, converged=True, f_root=fb)

        # Choose interpolation or bisection
        if abs(e) >= tol_act and abs(fc) > abs(fb):
            # Attempt inverse quadratic interpolation / secant
            s = fb / fc
            if a == c:
                # Secant
                p = 2.0 * m * s
                q = 1.0 - s
            else:
                q_ = fc / fa
                r = fb / fa
                p = s * (2.0 * m * q_ * (q_ - r) - (b - c) * (r - 1.0))
                q = (q_ - 1.0) * (r - 1.0) * (s - 1.0)

            if p > 0:
                q = -q
            p = abs(p)

            # Accept interpolation only if it falls in range
            cond1 = 2.0 * p < min(3.0 * abs(m) * q - abs(tol_act * q), abs(e * q))
            if cond1 and q != 0.0:
                e = d
                d = p / q
            else:
                d = m
                e = m
        else:
            d = m
            e = m

        c, fc = b, fb
        if abs(d) > tol_act:
            b = b + d
        else:
            b = b + (tol_act if m > 0 else -tol_act)

        fb = float(f(b))

    raise NonConvergenceError("brent: failed to converge within max_iter.")
