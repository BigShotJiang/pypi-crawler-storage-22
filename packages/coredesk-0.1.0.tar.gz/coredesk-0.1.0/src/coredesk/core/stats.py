"""
coredesk.core.stats

Basic statistical functions with minimal dependencies (NumPy only).

Implemented:
- normal_pdf(x): standard normal density φ(x)
- normal_cdf(x): standard normal CDF N(x)
- normal_ppf(p): inverse CDF N^{-1}(p)

Notes:
- normal_cdf uses a fast erf approximation (Abramowitz-Stegun style).
- normal_ppf uses a well-known rational approximation (Acklam).
"""

from __future__ import annotations

import numpy as np
import math

from coredesk.core.constants import EPS
from coredesk.core.exceptions import InvalidDomainError

_SQRT_2 = np.sqrt(2.0)
_INV_SQRT_2PI = 1.0 / np.sqrt(2.0 * np.pi)


def normal_pdf(x: float | np.ndarray) -> np.ndarray:
    """
    Standard normal PDF φ(x).
    Returns a NumPy array (even for scalar input) for consistency.
    """
    x = np.asarray(x, dtype=float)
    return _INV_SQRT_2PI * np.exp(-0.5 * x * x)


def _erf_approx(z: np.ndarray) -> np.ndarray:
    """
    Fast approximation of erf(z), vectorized.

    Max absolute error ~1e-7 (sufficient for v0.1 vanilla pricing & implied vol).
    """
    # Abramowitz & Stegun 7.1.26-like approximation
    # erf(z) ≈ sign(z) * (1 - (((((a5*t + a4)*t + a3)*t + a2)*t + a1)*t) * exp(-z^2))
    # where t = 1 / (1 + p*|z|)
    a1 = 0.254829592
    a2 = -0.284496736
    a3 = 1.421413741
    a4 = -1.453152027
    a5 = 1.061405429
    p = 0.3275911

    sign = np.sign(z)
    x = np.abs(z)
    t = 1.0 / (1.0 + p * x)
    poly = (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t)
    y = 1.0 - poly * np.exp(-x * x)
    return sign * y


def normal_cdf(x: float | np.ndarray) -> np.ndarray:
    """
    Standard normal CDF N(x), using math.erf for accuracy.
    Returns a NumPy array (even for scalar input) for consistency.
    """
    x = np.asarray(x, dtype=float)

    erf_vec = np.vectorize(math.erf, otypes=[float])
    return 0.5 * (1.0 + erf_vec(x / _SQRT_2))


def normal_ppf(p: float | np.ndarray) -> np.ndarray:
    """
    Inverse standard normal CDF N^{-1}(p).

    Raises:
        InvalidDomainError: if any p <= 0 or p >= 1
    """
    p = np.asarray(p, dtype=float)

    if np.any(~np.isfinite(p)):
        raise InvalidDomainError("normal_ppf: p must be finite.")
    if np.any(p <= 0.0) or np.any(p >= 1.0):
        raise InvalidDomainError("normal_ppf: p must be in (0, 1).")

    # Acklam's inverse normal approximation
    # Coefficients for central region
    a = np.array(
        [
            -3.969683028665376e01,
            2.209460984245205e02,
            -2.759285104469687e02,
            1.383577518672690e02,
            -3.066479806614716e01,
            2.506628277459239e00,
        ]
    )
    b = np.array(
        [
            -5.447609879822406e01,
            1.615858368580409e02,
            -1.556989798598866e02,
            6.680131188771972e01,
            -1.328068155288572e01,
        ]
    )

    # Coefficients for tails
    c = np.array(
        [
            -7.784894002430293e-03,
            -3.223964580411365e-01,
            -2.400758277161838e00,
            -2.549732539343734e00,
            4.374664141464968e00,
            2.938163982698783e00,
        ]
    )
    d = np.array(
        [
            7.784695709041462e-03,
            3.224671290700398e-01,
            2.445134137142996e00,
            3.754408661907416e00,
        ]
    )

    # Breakpoints
    plow = 0.02425
    phigh = 1.0 - plow

    x = np.empty_like(p)

    # Lower tail
    mask_lo = p < plow
    if np.any(mask_lo):
        q = np.sqrt(-2.0 * np.log(p[mask_lo]))
        num = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5])
        den = ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0)
        x[mask_lo] = num / den 

    # Central region
    mask_mid = (p >= plow) & (p <= phigh)
    if np.any(mask_mid):
        q = p[mask_mid] - 0.5
        r = q * q
        num = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q
        den = (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1.0)
        x[mask_mid] = num / den

    # Upper tail
    mask_hi = p > phigh
    if np.any(mask_hi):
        q = np.sqrt(-2.0 * np.log(1.0 - p[mask_hi]))
        num = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5])
        den = ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0)
        x[mask_hi] = -(num / den)  # positive values

    # Small guardrail for extreme p near 0/1
    # but keeps behavior stable in case of float fuzz.
    x = np.where(p < EPS, -np.inf, x)
    x = np.where(p > 1.0 - EPS, np.inf, x)

    return x
