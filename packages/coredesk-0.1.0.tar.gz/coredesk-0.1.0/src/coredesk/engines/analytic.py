"""
coredesk.engines.analytic

Closed-form pricers for vanilla products.

Implemented (v0.1):
- EuropeanOption under:
  - Black–Scholes–Merton (spot with continuous dividend yield q)
  - Black 76 (options on forwards/futures)

Conventions:
- Rates r and q are taken from MarketEnvironment (typically continuous)
- sigma is taken from the model (BlackScholesModel / Black76Model)
"""

from __future__ import annotations

from dataclasses import dataclass
from math import exp, log, sqrt

from coredesk.core.exceptions import InvalidDomainError
from coredesk.core.stats import normal_cdf, normal_pdf
from coredesk.market.environment import MarketEnvironment
from coredesk.models.black_76 import Black76Model
from coredesk.models.black_scholes import BlackScholesModel
from coredesk.products.european_option import EuropeanOption


def _require_positive(x: float, name: str) -> None:
    if x <= 0.0:
        raise InvalidDomainError(f"{name} must be > 0.")


def _require_non_negative(x: float, name: str) -> None:
    if x < 0.0:
        raise InvalidDomainError(f"{name} must be >= 0.")


def _d1_d2(forward_or_spot: float, strike: float, sigma: float, t: float) -> tuple[float, float]:
    # Handles sigma=0 or t=0 upstream.
    vol_sqrt_t = sigma * sqrt(t)
    d1 = (log(forward_or_spot / strike) + 0.5 * sigma * sigma * t) / vol_sqrt_t
    d2 = d1 - vol_sqrt_t
    return d1, d2


@dataclass(frozen=True)
class AnalyticEngine:
    """
    Stateless analytic pricer.

    Usage:
        engine = AnalyticEngine()
        price = engine.price_bsm(spot, option, model, market)
        price = engine.price_black76(forward, option, model, market)
    """

    def price_bsm(
        self,
        spot: float,
        product: EuropeanOption,
        model: BlackScholesModel,
        market: MarketEnvironment,
    ) -> float:
        """
        Black–Scholes–Merton price for European option on spot.
        """
        _require_positive(spot, "spot")
        _require_positive(product.strike, "strike")
        _require_non_negative(product.maturity, "maturity")
        _require_non_negative(model.sigma, "sigma")

        t = float(product.maturity)
        k = float(product.strike)
        sigma = float(model.sigma)
        r = float(market.r)
        q = float(market.q)

        if t == 0.0:
            return product.payoff(spot)

        df_r = exp(-r * t)
        df_q = exp(-q * t)

        # Deterministic (sigma=0): discounted intrinsic under forward drift
        if sigma == 0.0:
            fwd = spot * df_q / df_r  # spot * exp((r-q)T)
            if product.is_call:
                return df_r * max(fwd - k, 0.0)
            return df_r * max(k - fwd, 0.0)

        fwd = spot * df_q / df_r
        d1, d2 = _d1_d2(fwd, k, sigma, t)

        if product.is_call:
            return df_r * (fwd * normal_cdf(d1).item() - k * normal_cdf(d2).item())
        return df_r * (k * normal_cdf(-d2).item() - fwd * normal_cdf(-d1).item())

    def price_black76(
        self,
        forward: float,
        product: EuropeanOption,
        model: Black76Model,
        market: MarketEnvironment,
    ) -> float:
        """
        Black 76 price for European option on forward/futures.
        """
        _require_positive(forward, "forward")
        _require_positive(product.strike, "strike")
        _require_non_negative(product.maturity, "maturity")
        _require_non_negative(model.sigma, "sigma")

        t = float(product.maturity)
        k = float(product.strike)
        sigma = float(model.sigma)
        r = float(market.r)

        if t == 0.0:
            # Payoff in terms of forward is a bit artificial at T=0;
            # but if caller passes forward=spot at expiry, it works.
            return product.payoff(forward)

        df = exp(-r * t)

        if sigma == 0.0:
            if product.is_call:
                return df * max(forward - k, 0.0)
            return df * max(k - forward, 0.0)

        d1, d2 = _d1_d2(forward, k, sigma, t)

        if product.is_call:
            return df * (forward * normal_cdf(d1).item() - k * normal_cdf(d2).item())
        return df * (k * normal_cdf(-d2).item() - forward * normal_cdf(-d1).item())

    def vega_black76(
        self,
        forward: float,
        product: EuropeanOption,
        model: Black76Model,
        market: MarketEnvironment,
    ) -> float:
        """
        Black 76 vega (∂Price/∂sigma).
        Useful for implied vol later.
        """
        _require_positive(forward, "forward")
        _require_positive(product.strike, "strike")
        _require_non_negative(product.maturity, "maturity")

        t = float(product.maturity)
        if t == 0.0:
            return 0.0

        sigma = float(model.sigma)
        if sigma == 0.0:
            # limit exists but is 0 in a strict numeric sense for our purposes
            return 0.0

        k = float(product.strike)
        r = float(market.r)
        df = exp(-r * t)

        d1, _ = _d1_d2(forward, k, sigma, t)
        return df * forward * normal_pdf(d1).item() * sqrt(t)
