"""
coredesk.market.daycount

Day count conventions for year fraction computations.

Implemented:
- ACT/360
- ACT/365F
- 30/360 (US / Bond Basis)  [most common desk default for 30/360]

Design:
- Explicit convention objects
- Deterministic and testable
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Literal

from coredesk.core.exceptions import InvalidDomainError

DayCountName = Literal["ACT/360", "ACT/365F", "30/360"]


def _days_between(start: date, end: date) -> int:
    if not isinstance(start, date) or not isinstance(end, date):
        raise InvalidDomainError("daycount: start and end must be datetime.date.")
    return (end - start).days


def _require_order(start: date, end: date) -> None:
    if end < start:
        raise InvalidDomainError("daycount: end date must be >= start date.")


def _year_fraction_act(start: date, end: date, basis: int) -> float:
    _require_order(start, end)
    return _days_between(start, end) / float(basis)


def _year_fraction_30_360_us(start: date, end: date) -> float:
    """
    30/360 US (Bond Basis) convention.

    Rules (common market implementation):
    - If start day is 31 -> set to 30
    - If end day is 31 and start day is 30 or 31 -> set end day to 30
    """
    _require_order(start, end)

    y1, m1, d1 = start.year, start.month, start.day
    y2, m2, d2 = end.year, end.month, end.day

    if d1 == 31:
        d1 = 30

    if d2 == 31 and d1 in (30, 31):
        d2 = 30

    days360 = 360 * (y2 - y1) + 30 * (m2 - m1) + (d2 - d1)
    return days360 / 360.0


@dataclass(frozen=True)
class DayCount:
    name: DayCountName

    def year_fraction(self, start: date, end: date) -> float:
        """
        Year fraction between start and end according to the convention.
        """
        if self.name == "ACT/360":
            return _year_fraction_act(start, end, 360)
        if self.name == "ACT/365F":
            return _year_fraction_act(start, end, 365)
        if self.name == "30/360":
            return _year_fraction_30_360_us(start, end)
        raise InvalidDomainError(f"Unknown day count convention: {self.name}")


# Convenience singletons
ACT_360 = DayCount("ACT/360")
ACT_365F = DayCount("ACT/365F")
THIRTY_360 = DayCount("30/360")
