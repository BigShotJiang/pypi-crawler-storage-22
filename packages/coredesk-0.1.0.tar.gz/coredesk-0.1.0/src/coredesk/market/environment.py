"""
coredesk.market.environment

MarketEnvironment centralizes explicit market inputs used by pricers:
- risk-free rate (r)
- dividend yield / carry (q)
- volatility (sigma)
- conventions (day count, rate convention)

Design goals:
- No implicit globals
- Simple, explicit, desk-friendly
- Validation upfront
"""

from __future__ import annotations

from dataclasses import dataclass

from coredesk.core.exceptions import InvalidDomainError
from coredesk.market.daycount import ACT_365F, DayCount
from coredesk.market.rates import CONTINUOUS, RateConvention


@dataclass(frozen=True)
class MarketEnvironment:
    """
    Minimal market environment for v0.1 vanilla equity/futures.

    Notes:
    - r and q are annualized rates (typically continuously compounded in equity desks)
    - sigma is annualized volatility
    """
    r: float = 0.0
    q: float = 0.0
    sigma: float = 0.2

    day_count: DayCount = ACT_365F
    rate_convention: RateConvention = CONTINUOUS

    def __post_init__(self) -> None:
        # Basic numerical sanity checks
        for name, x in (("r", self.r), ("q", self.q), ("sigma", self.sigma)):
            if x != x:  # NaN check without numpy
                raise InvalidDomainError(f"MarketEnvironment: {name} must be finite (not NaN).")

        if self.sigma < 0.0:
            raise InvalidDomainError("MarketEnvironment: sigma must be >= 0.")