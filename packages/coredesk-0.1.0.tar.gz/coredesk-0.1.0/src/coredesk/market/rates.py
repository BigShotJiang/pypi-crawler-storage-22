"""
coredesk.market.rates

Interest rate conventions and conversions.

We make compounding explicit:
- SIMPLE:  DF = 1 / (1 + r * tau)
- COMPOUNDED: DF = 1 / (1 + r/m)^(m*tau)
- CONTINUOUS: DF = exp(-r * tau)

Design goals:
- Explicit conventions
- Deterministic behavior
- Domain checks (tau >= 0, m >= 1, etc.)
"""

from __future__ import annotations

from dataclasses import dataclass
from math import exp, log
from typing import Literal

from coredesk.core.exceptions import InvalidDomainError

Compounding = Literal["simple", "compounded", "continuous"]


def _require_non_negative_tau(tau: float) -> None:
    if tau < 0.0:
        raise InvalidDomainError("RateConvention: tau must be >= 0.")


@dataclass(frozen=True)
class RateConvention:
    """
    Rate convention for converting between rate and discount factor.

    For compounded rates, freq is compounding frequency per year (e.g., 1, 2, 4, 12).
    """
    compounding: Compounding
    freq: int = 1

    def __post_init__(self) -> None:
        if self.compounding not in ("simple", "compounded", "continuous"):
            raise InvalidDomainError(f"Unknown compounding: {self.compounding}")

        if self.compounding == "compounded":
            if not isinstance(self.freq, int) or self.freq < 1:
                raise InvalidDomainError("RateConvention: freq must be an int >= 1 for compounded.")
        else:
            # Keep freq normalized to 1 for non-compounded conventions (avoids confusion)
            object.__setattr__(self, "freq", 1)

    def df(self, r: float, tau: float) -> float:
        """
        Discount factor for a constant annualized rate r over year fraction tau.
        """
        _require_non_negative_tau(tau)

        if self.compounding == "simple":
            return 1.0 / (1.0 + r * tau)

        if self.compounding == "compounded":
            m = self.freq
            return 1.0 / (1.0 + r / m) ** (m * tau)

        # continuous
        return exp(-r * tau)

    def rate_from_df(self, df: float, tau: float) -> float:
        """
        Annualized rate implied by discount factor df over year fraction tau.
        """
        _require_non_negative_tau(tau)
        if df <= 0.0:
            raise InvalidDomainError("RateConvention: df must be > 0.")
        if tau == 0.0:
            # Any df != 1 is inconsistent at tau=0.
            if abs(df - 1.0) > 1e-15:
                raise InvalidDomainError("RateConvention: df must be 1 when tau=0.")
            return 0.0

        if self.compounding == "simple":
            return (1.0 / df - 1.0) / tau

        if self.compounding == "compounded":
            m = self.freq
            return m * (df ** (-1.0 / (m * tau)) - 1.0)

        # continuous
        return -log(df) / tau


# Convenience singletons
SIMPLE = RateConvention("simple")
CONTINUOUS = RateConvention("continuous")

def COMPOUNDED(freq: int) -> RateConvention:
    return RateConvention("compounded", freq=freq)
