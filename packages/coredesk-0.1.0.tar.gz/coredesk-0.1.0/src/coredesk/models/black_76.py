"""
coredesk.models.black_76

Black 76 model inputs for options on forwards/futures.

Rule:
- Model contains parameters only (sigma).
- Pricing is done by an engine (analytic).
"""

from __future__ import annotations

from dataclasses import dataclass

from coredesk.core.exceptions import InvalidDomainError


@dataclass(frozen=True)
class Black76Model:
    """
    Parameters:
        sigma: annualized volatility (>= 0)

    Notes:
        Discounting lives in MarketEnvironment (r).
        Forward/futures level is the input to the engine (not stored here).
    """
    sigma: float

    def __post_init__(self) -> None:
        if self.sigma != self.sigma:  # NaN
            raise InvalidDomainError("Black76Model: sigma must be finite (not NaN).")
        if self.sigma < 0.0:
            raise InvalidDomainError("Black76Model: sigma must be >= 0.")
