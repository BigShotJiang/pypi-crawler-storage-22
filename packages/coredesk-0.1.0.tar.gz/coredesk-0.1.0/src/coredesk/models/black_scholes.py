"""
coredesk.models.black_scholes

Black–Scholes–Merton model inputs for an equity spot with continuous dividend yield.

Rule:
- A model defines a dynamic / parameters, NOT a pricing method.
- Pricing is done by an engine.
"""

from __future__ import annotations

from dataclasses import dataclass

from coredesk.core.exceptions import InvalidDomainError


@dataclass(frozen=True)
class BlackScholesModel:
    """
    Parameters:
        sigma: annualized volatility (>= 0)
    Notes:
        r and q live in MarketEnvironment (not duplicated here).
    """
    sigma: float

    def __post_init__(self) -> None:
        if self.sigma != self.sigma:  # NaN
            raise InvalidDomainError("BlackScholesModel: sigma must be finite (not NaN).")
        if self.sigma < 0.0:
            raise InvalidDomainError("BlackScholesModel: sigma must be >= 0.")
