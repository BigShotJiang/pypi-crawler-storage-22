"""
coredesk.products.european_option

Business object representing a European vanilla option.

Rule:
- Product contains NO pricing logic.
- It only defines contract terms and payoff.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from coredesk.core.exceptions import InvalidDomainError

OptionType = Literal["call", "put"]


@dataclass(frozen=True)
class EuropeanOption:
    option_type: OptionType
    strike: float
    maturity: float  # year fraction (T), computed using a DayCount upstream if needed

    def __post_init__(self) -> None:
        if self.option_type not in ("call", "put"):
            raise InvalidDomainError("EuropeanOption: option_type must be 'call' or 'put'.")
        if self.strike <= 0.0:
            raise InvalidDomainError("EuropeanOption: strike must be > 0.")
        if self.maturity < 0.0:
            raise InvalidDomainError("EuropeanOption: maturity must be >= 0.")

    def payoff(self, spot: float) -> float:
        if spot < 0.0:
            raise InvalidDomainError("EuropeanOption.payoff: spot must be >= 0.")
        if self.option_type == "call":
            return max(spot - self.strike, 0.0)
        return max(self.strike - spot, 0.0)

    @property
    def is_call(self) -> bool:
        return self.option_type == "call"

    @property
    def is_put(self) -> bool:
        return self.option_type == "put"
