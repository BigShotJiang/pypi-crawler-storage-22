"""
coredesk.risk.greeks

Analytic Greeks for vanilla European options under:
- Black–Scholes–Merton (spot with continuous dividend yield q)
- Black 76 (options on forwards/futures)

Greeks implemented:
- delta, gamma, vega for BSM
- delta_fwd, gamma_fwd, vega for Black76
"""

from __future__ import annotations

from math import exp, log, sqrt

from coredesk.core.exceptions import InvalidDomainError
from coredesk.core.stats import normal_cdf, normal_pdf
from coredesk.market.environment import MarketEnvironment
from coredesk.models.black_76 import Black76Model
from coredesk.models.black_scholes import BlackScholesModel
from coredesk.products.european_option import EuropeanOption


def _require_positive(x: float, name: str) -> None:
    if x <= 0.0:
        raise InvalidDomainError(f"{name} must be > 0.")


def _require_non_negative(x: float, name: str) -> None:
    if x < 0.0:
        raise InvalidDomainError(f"{name} must be >= 0.")


def _d1_d2(forward: float, strike: float, sigma: float, t: float) -> tuple[float, float]:
    vol_sqrt_t = sigma * sqrt(t)
    d1 = (log(forward / strike) + 0.5 * sigma * sigma * t) / vol_sqrt_t
    d2 = d1 - vol_sqrt_t
    return d1, d2


# ---------- BSM Greeks (spot) ----------

def delta_bsm(
    spot: float,
    product: EuropeanOption,
    model: BlackScholesModel,
    market: MarketEnvironment,
) -> float:
    _require_positive(spot, "spot")
    _require_positive(product.strike, "strike")
    _require_non_negative(product.maturity, "maturity")
    _require_non_negative(model.sigma, "sigma")

    t = float(product.maturity)
    k = float(product.strike)
    sigma = float(model.sigma)
    q = float(market.q)
    r = float(market.r)

    if t == 0.0:
        # derivative of payoff at expiry is undefined at spot=strike;
        # return a reasonable convention.
        if product.is_call:
            return 1.0 if spot > k else 0.0
        return -1.0 if spot < k else 0.0

    df_q = exp(-q * t)
    df_r = exp(-r * t)

    if sigma == 0.0:
        fwd = spot * df_q / df_r
        if product.is_call:
            return df_q if fwd > k else 0.0
        return -df_q if fwd < k else 0.0

    fwd = spot * df_q / df_r
    d1, _ = _d1_d2(fwd, k, sigma, t)

    if product.is_call:
        return df_q * normal_cdf(d1).item()
    return df_q * (normal_cdf(d1).item() - 1.0)


def gamma_bsm(
    spot: float,
    product: EuropeanOption,
    model: BlackScholesModel,
    market: MarketEnvironment,
) -> float:
    _require_positive(spot, "spot")
    _require_positive(product.strike, "strike")
    _require_non_negative(product.maturity, "maturity")
    _require_non_negative(model.sigma, "sigma")

    t = float(product.maturity)
    if t == 0.0:
        return 0.0

    sigma = float(model.sigma)
    if sigma == 0.0:
        return 0.0

    k = float(product.strike)
    q = float(market.q)
    r = float(market.r)

    df_q = exp(-q * t)
    df_r = exp(-r * t)
    fwd = spot * df_q / df_r

    d1, _ = _d1_d2(fwd, k, sigma, t)
    return df_q * normal_pdf(d1).item() / (spot * sigma * sqrt(t))


def vega_bsm(
    spot: float,
    product: EuropeanOption,
    model: BlackScholesModel,
    market: MarketEnvironment,
) -> float:
    _require_positive(spot, "spot")
    _require_positive(product.strike, "strike")
    _require_non_negative(product.maturity, "maturity")

    t = float(product.maturity)
    if t == 0.0:
        return 0.0

    sigma = float(model.sigma)
    if sigma == 0.0:
        return 0.0

    k = float(product.strike)
    q = float(market.q)
    r = float(market.r)

    df_q = exp(-q * t)
    df_r = exp(-r * t)
    fwd = spot * df_q / df_r

    d1, _ = _d1_d2(fwd, k, sigma, t)
    return df_q * spot * normal_pdf(d1).item() * sqrt(t)


# ---------- Black76 Greeks (forward) ----------

def delta_black76_forward(
    forward: float,
    product: EuropeanOption,
    model: Black76Model,
    market: MarketEnvironment,
) -> float:
    _require_positive(forward, "forward")
    _require_positive(product.strike, "strike")
    _require_non_negative(product.maturity, "maturity")
    _require_non_negative(model.sigma, "sigma")

    t = float(product.maturity)
    k = float(product.strike)
    sigma = float(model.sigma)
    r = float(market.r)

    if t == 0.0:
        if product.is_call:
            return 1.0 if forward > k else 0.0
        return -1.0 if forward < k else 0.0

    df = exp(-r * t)
    if sigma == 0.0:
        if product.is_call:
            return df if forward > k else 0.0
        return -df if forward < k else 0.0

    d1, _ = _d1_d2(forward, k, sigma, t)
    if product.is_call:
        return df * normal_cdf(d1).item()
    return df * (normal_cdf(d1).item() - 1.0)


def gamma_black76_forward(
    forward: float,
    product: EuropeanOption,
    model: Black76Model,
    market: MarketEnvironment,
) -> float:
    _require_positive(forward, "forward")
    _require_positive(product.strike, "strike")
    _require_non_negative(product.maturity, "maturity")
    _require_non_negative(model.sigma, "sigma")

    t = float(product.maturity)
    if t == 0.0:
        return 0.0

    sigma = float(model.sigma)
    if sigma == 0.0:
        return 0.0

    k = float(product.strike)
    r = float(market.r)
    df = exp(-r * t)

    d1, _ = _d1_d2(forward, k, sigma, t)
    return df * normal_pdf(d1).item() / (forward * sigma * sqrt(t))


def vega_black76(
    forward: float,
    product: EuropeanOption,
    model: Black76Model,
    market: MarketEnvironment,
) -> float:
    _require_positive(forward, "forward")
    _require_positive(product.strike, "strike")
    _require_non_negative(product.maturity, "maturity")

    t = float(product.maturity)
    if t == 0.0:
        return 0.0

    sigma = float(model.sigma)
    if sigma == 0.0:
        return 0.0

    k = float(product.strike)
    r = float(market.r)
    df = exp(-r * t)

    d1, _ = _d1_d2(forward, k, sigma, t)
    return df * forward * normal_pdf(d1).item() * sqrt(t)
