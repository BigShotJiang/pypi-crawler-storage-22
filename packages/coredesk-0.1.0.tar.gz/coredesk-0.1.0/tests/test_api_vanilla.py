from coredesk.api.vanilla import black76_iv, black76_price, bsm_iv, bsm_price


def test_api_bsm_roundtrip_iv():
    price = bsm_price(
        spot=100.0, strike=110.0, maturity=1.0, option_type="call", sigma=0.3, r=0.02, q=0.01
    )
    iv = bsm_iv(price=price, spot=100.0, strike=110.0, maturity=1.0, option_type="call", r=0.02, q=0.01)
    assert abs(iv - 0.3) < 1e-10


def test_api_black76_roundtrip_iv():
    price = black76_price(
        forward=100.0, strike=95.0, maturity=2.0, option_type="put", sigma=0.25, r=0.01
    )
    iv = black76_iv(price=price, forward=100.0, strike=95.0, maturity=2.0, option_type="put", r=0.01)
    assert abs(iv - 0.25) < 1e-10
