import math

import pytest

from coredesk.calibration.implied_vol import implied_vol_black76
from coredesk.core.exceptions import InvalidDomainError, RootNotBracketedError
from coredesk.engines.analytic import AnalyticEngine
from coredesk.market.environment import MarketEnvironment
from coredesk.models.black_76 import Black76Model
from coredesk.products.european_option import EuropeanOption


def test_implied_vol_black76_roundtrip():
    fwd = 100.0
    k = 110.0
    t = 1.5
    r = 0.02
    true_iv = 0.35

    mkt = MarketEnvironment(r=r, q=0.0, sigma=true_iv)
    opt = EuropeanOption("call", strike=k, maturity=t)
    eng = AnalyticEngine()

    price = eng.price_black76(fwd, opt, Black76Model(sigma=true_iv), mkt)
    res = implied_vol_black76(price, fwd, opt, mkt, tol=1e-12)

    assert res.converged
    assert abs(res.iv - true_iv) < 1e-10


def test_implied_vol_black76_rejects_negative_price():
    mkt = MarketEnvironment()
    opt = EuropeanOption("call", strike=100.0, maturity=1.0)
    with pytest.raises(InvalidDomainError):
        implied_vol_black76(-1.0, 100.0, opt, mkt)


def test_implied_vol_black76_not_bracketed():
    fwd = 100.0
    opt = EuropeanOption("call", strike=1.0, maturity=1.0)
    mkt = MarketEnvironment(r=0.0)

    # absurdly high price that cannot be reached
    with pytest.raises(RootNotBracketedError):
        implied_vol_black76(200.0, fwd, opt, mkt, vol_lower=1e-4, vol_upper=0.2)


def test_implied_vol_maturity_zero():
    fwd = 100.0
    opt = EuropeanOption("call", strike=90.0, maturity=0.0)
    mkt = MarketEnvironment(r=0.0)

    intrinsic = opt.payoff(fwd)
    res = implied_vol_black76(intrinsic, fwd, opt, mkt)
    assert res.converged
    assert res.iv == 0.0

    with pytest.raises(InvalidDomainError):
        implied_vol_black76(intrinsic + 1e-3, fwd, opt, mkt)
