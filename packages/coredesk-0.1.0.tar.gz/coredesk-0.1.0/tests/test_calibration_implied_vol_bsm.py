import pytest

from coredesk.calibration.implied_vol import implied_vol_bsm
from coredesk.core.exceptions import InvalidDomainError, RootNotBracketedError
from coredesk.engines.analytic import AnalyticEngine
from coredesk.market.environment import MarketEnvironment
from coredesk.models.black_scholes import BlackScholesModel
from coredesk.products.european_option import EuropeanOption


def test_implied_vol_bsm_roundtrip():
    spot = 100.0
    k = 95.0
    t = 2.0
    r = 0.03
    q = 0.01
    true_iv = 0.22

    mkt = MarketEnvironment(r=r, q=q, sigma=true_iv)
    opt = EuropeanOption("put", strike=k, maturity=t)
    eng = AnalyticEngine()

    price = eng.price_bsm(spot, opt, BlackScholesModel(sigma=true_iv), mkt)
    res = implied_vol_bsm(price, spot, opt, mkt, tol=1e-12)

    assert res.converged
    assert abs(res.iv - true_iv) < 1e-10


def test_implied_vol_bsm_rejects_negative_price():
    mkt = MarketEnvironment()
    opt = EuropeanOption("call", strike=100.0, maturity=1.0)
    with pytest.raises(InvalidDomainError):
        implied_vol_bsm(-1.0, 100.0, opt, mkt)


def test_implied_vol_bsm_not_bracketed():
    spot = 100.0
    opt = EuropeanOption("call", strike=1.0, maturity=1.0)
    mkt = MarketEnvironment(r=0.0, q=0.0)

    with pytest.raises(RootNotBracketedError):
        implied_vol_bsm(200.0, spot, opt, mkt, vol_lower=1e-4, vol_upper=0.2)


def test_implied_vol_bsm_maturity_zero():
    spot = 100.0
    opt = EuropeanOption("call", strike=90.0, maturity=0.0)
    mkt = MarketEnvironment(r=0.0, q=0.0)

    intrinsic = opt.payoff(spot)
    res = implied_vol_bsm(intrinsic, spot, opt, mkt)
    assert res.converged
    assert res.iv == 0.0

    with pytest.raises(InvalidDomainError):
        implied_vol_bsm(intrinsic + 1e-3, spot, opt, mkt)
