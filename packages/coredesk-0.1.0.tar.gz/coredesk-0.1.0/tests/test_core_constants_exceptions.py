from coredesk.core import constants
from coredesk.core.exceptions import (
    CoreDeskError,
    InvalidDomainError,
    NonConvergenceError,
    RootNotBracketedError,
)


def test_constants_exist():
    assert constants.EPS > 0
    assert constants.MAX_ITER >= 10
    assert 0 < constants.MIN_VOL < constants.MAX_VOL


def test_exceptions_inheritance():
    assert issubclass(InvalidDomainError, (CoreDeskError, ValueError))
    assert issubclass(NonConvergenceError, (CoreDeskError, RuntimeError))
    assert issubclass(RootNotBracketedError, (CoreDeskError, ValueError))
