import numpy as np
import pytest

from coredesk.core.exceptions import InvalidDomainError
from coredesk.core.interpolation import Interp1D, linear_interp, log_linear_interp


def test_linear_interp_midpoint():
    xp = np.array([0.0, 1.0, 2.0])
    yp = np.array([0.0, 10.0, 20.0])
    assert linear_interp(0.5, xp, yp).item() == 5.0


def test_linear_interp_vectorized():
    xp = np.array([0.0, 1.0, 2.0])
    yp = np.array([0.0, 10.0, 20.0])
    x = np.array([0.0, 0.5, 1.0, 1.5, 2.0])
    y = linear_interp(x, xp, yp)
    assert np.allclose(y, np.array([0.0, 5.0, 10.0, 15.0, 20.0]))


def test_extrap_error():
    f = Interp1D(xp=np.array([0.0, 1.0]), yp=np.array([0.0, 1.0]), kind="linear", extrap="error")
    with pytest.raises(InvalidDomainError):
        f(-0.1)


def test_extrap_flat():
    f = Interp1D(xp=np.array([0.0, 1.0]), yp=np.array([0.0, 1.0]), kind="linear", extrap="flat")
    assert f(-0.1).item() == 0.0
    assert f(1.1).item() == 1.0


def test_log_linear_interp_positive_required():
    xp = np.array([0.0, 1.0])
    yp = np.array([1.0, -2.0])
    with pytest.raises(InvalidDomainError):
        log_linear_interp(0.5, xp, yp)


def test_log_linear_interp_geometric_midpoint():
    xp = np.array([0.0, 1.0])
    yp = np.array([1.0, 4.0])
    # log-linear midpoint should be geometric mean = 2
    assert abs(log_linear_interp(0.5, xp, yp).item() - 2.0) < 1e-12
