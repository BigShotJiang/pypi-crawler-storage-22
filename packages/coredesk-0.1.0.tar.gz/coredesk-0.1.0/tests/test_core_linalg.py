import numpy as np
import pytest

from coredesk.core.exceptions import InvalidDomainError, NumericalStabilityError
from coredesk.core.linalg import (
    check_correlation_matrix,
    cholesky,
    is_symmetric,
    nearest_correlation,
    is_positive_semidefinite
)

def test_is_symmetric():
    a = np.array([[1.0, 0.2], [0.2, 1.0]])
    b = np.array([[1.0, 0.2], [0.3, 1.0]])
    assert is_symmetric(a)
    assert not is_symmetric(b)


def test_check_correlation_matrix_ok():
    corr = np.array([[1.0, 0.3], [0.3, 1.0]])
    check_correlation_matrix(corr)  # should not raise


def test_check_correlation_matrix_rejects_bad_diag():
    corr = np.array([[0.9, 0.0], [0.0, 1.0]])
    with pytest.raises(InvalidDomainError):
        check_correlation_matrix(corr)


def test_cholesky_ok():
    a = np.array([[2.0, 0.3], [0.3, 1.0]])
    L = cholesky(a)
    assert np.allclose(L @ L.T, a, atol=1e-12)


def test_cholesky_jitter_recovers_semidefinite():
    # Semi-definite matrix (rank 1)
    a = np.array([[1.0, 1.0], [1.0, 1.0]])
    with pytest.raises(NumericalStabilityError):
        cholesky(a)  # no jitter -> fail
    L = cholesky(a, jitter=1e-12)
    assert np.allclose((L @ L.T)[0, 0], 1.0, atol=1e-9)


def test_nearest_correlation_repairs():
    # Bad "correlation" (diagonal not 1, and not PSD)
    a = np.array([[1.0, 1.2], [1.2, 1.0]])
    corr = nearest_correlation(a)
    assert is_symmetric(corr)
    assert np.allclose(np.diag(corr), 1.0)
    assert is_positive_semidefinite(corr, tol=1e-9)

def test_nearest_correlation_invalid_input():
    with pytest.raises(InvalidDomainError):
        nearest_correlation(np.array([1.0, 2.0]))

