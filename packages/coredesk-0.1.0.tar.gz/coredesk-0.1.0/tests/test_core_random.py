import numpy as np
import pytest

from coredesk.core.exceptions import InvalidDomainError
from coredesk.core.random import RNG, make_rng


def test_rng_reproducibility():
    rng1 = make_rng(123)
    rng2 = make_rng(123)
    a = rng1.standard_normals((5, 3))
    b = rng2.standard_normals((5, 3))
    assert np.allclose(a, b)


def test_rng_seed_validation():
    with pytest.raises(InvalidDomainError):
        make_rng(-1)
    with pytest.raises(InvalidDomainError):
        RNG.from_seed("abc")  # type: ignore[arg-type]


def test_antithetic_shape_and_property():
    rng = make_rng(42)
    z = rng.standard_normals((10, 2), antithetic=True)
    assert z.shape == (20, 2)
    assert np.allclose(z[:10], -z[10:])


def test_uniforms_range():
    rng = make_rng(7)
    u = rng.uniforms((1000,), low=2.0, high=3.0)
    assert np.all(u >= 2.0)
    assert np.all(u < 3.0)


def test_invalid_shapes():
    rng = make_rng(1)
    with pytest.raises(InvalidDomainError):
        rng.standard_normals(0)
    with pytest.raises(InvalidDomainError):
        rng.uniforms((0,))
