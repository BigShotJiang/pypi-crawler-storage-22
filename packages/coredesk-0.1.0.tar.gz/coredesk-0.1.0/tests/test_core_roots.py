import math
import pytest

from coredesk.core.exceptions import NonConvergenceError, RootNotBracketedError
from coredesk.core.roots import bisect, brent, newton


def test_bisect_sqrt2():
    f = lambda x: x * x - 2.0
    res = bisect(f, 1.0, 2.0, tol=1e-12)
    assert res.converged
    assert abs(res.root - math.sqrt(2.0)) < 1e-10


def test_brent_sqrt2():
    f = lambda x: x * x - 2.0
    res = brent(f, 1.0, 2.0, tol=1e-12)
    assert res.converged
    assert abs(res.root - math.sqrt(2.0)) < 1e-12


def test_newton_sqrt2():
    f = lambda x: x * x - 2.0
    fp = lambda x: 2.0 * x
    res = newton(f, fp, 1.5, tol=1e-12)
    assert res.converged
    assert abs(res.root - math.sqrt(2.0)) < 1e-12


def test_root_not_bracketed():
    f = lambda x: x * x + 1.0
    with pytest.raises(RootNotBracketedError):
        bisect(f, -1.0, 1.0)
    with pytest.raises(RootNotBracketedError):
        brent(f, -1.0, 1.0)


def test_newton_nonconvergence_derivative_zero():
    f = lambda x: x * x
    fp = lambda x: 0.0
    with pytest.raises(NonConvergenceError):
        newton(f, fp, 1.0)
