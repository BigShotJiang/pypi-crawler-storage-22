import numpy as np
import pytest

from coredesk.core.exceptions import InvalidDomainError
from coredesk.core.stats import normal_cdf, normal_pdf, normal_ppf


def test_normal_pdf_at_zero():
    v = normal_pdf(0.0).item()
    assert abs(v - (1.0 / np.sqrt(2.0 * np.pi))) < 1e-12


def test_normal_cdf_basic_values():
    assert abs(normal_cdf(0.0).item() - 0.5) < 1e-8
    assert abs(normal_cdf(1.0).item() - 0.841344746) < 2e-7 


def test_normal_cdf_symmetry():
    x = np.array([0.0, 0.2, 1.0, 2.5])
    lhs = normal_cdf(-x)
    rhs = 1.0 - normal_cdf(x)
    assert np.max(np.abs(lhs - rhs)) < 2e-7


def test_normal_ppf_basic_values():
    assert abs(normal_ppf(0.5).item()) < 1e-12
    assert abs(normal_ppf(normal_cdf(1.0)).item() - 1.0) < 5e-6


def test_normal_ppf_roundtrip_grid():
    x = np.linspace(-3.0, 3.0, 61)
    p = normal_cdf(x)
    xr = normal_ppf(p)
    assert np.max(np.abs(xr - x)) < 5e-6


def test_normal_ppf_domain_errors():
    with pytest.raises(InvalidDomainError):
        normal_ppf(0.0)
    with pytest.raises(InvalidDomainError):
        normal_ppf(1.0)
    with pytest.raises(InvalidDomainError):
        normal_ppf(-1e-6)
    with pytest.raises(InvalidDomainError):
        normal_ppf(1.0 + 1e-6)
