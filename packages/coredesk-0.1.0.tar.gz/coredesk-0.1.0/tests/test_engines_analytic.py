import math

import pytest

from coredesk.core.exceptions import InvalidDomainError
from coredesk.engines.analytic import AnalyticEngine
from coredesk.market.environment import MarketEnvironment
from coredesk.models.black_76 import Black76Model
from coredesk.models.black_scholes import BlackScholesModel
from coredesk.products.european_option import EuropeanOption


def test_bsm_put_call_parity():
    # C - P = S e^{-qT} - K e^{-rT}
    spot = 100.0
    k = 100.0
    t = 1.0
    r = 0.03
    q = 0.01
    sigma = 0.2

    mkt = MarketEnvironment(r=r, q=q, sigma=sigma)
    model = BlackScholesModel(sigma=sigma)
    eng = AnalyticEngine()

    call = EuropeanOption("call", strike=k, maturity=t)
    put = EuropeanOption("put", strike=k, maturity=t)

    c = eng.price_bsm(spot, call, model, mkt)
    p = eng.price_bsm(spot, put, model, mkt)

    rhs = spot * math.exp(-q * t) - k * math.exp(-r * t)
    assert abs((c - p) - rhs) < 1e-10


def test_black76_put_call_parity():
    # C - P = df*(F - K)
    fwd = 100.0
    k = 110.0
    t = 2.0
    r = 0.02
    sigma = 0.25

    mkt = MarketEnvironment(r=r, q=0.0, sigma=sigma)
    model = Black76Model(sigma=sigma)
    eng = AnalyticEngine()

    call = EuropeanOption("call", strike=k, maturity=t)
    put = EuropeanOption("put", strike=k, maturity=t)

    c = eng.price_black76(fwd, call, model, mkt)
    p = eng.price_black76(fwd, put, model, mkt)

    rhs = math.exp(-r * t) * (fwd - k)
    assert abs((c - p) - rhs) < 1e-10


def test_bsm_sigma_zero_limit():
    spot = 100.0
    k = 90.0
    t = 1.0
    r = 0.0
    q = 0.0

    mkt = MarketEnvironment(r=r, q=q, sigma=0.0)
    model = BlackScholesModel(sigma=0.0)
    eng = AnalyticEngine()

    call = EuropeanOption("call", strike=k, maturity=t)
    price = eng.price_bsm(spot, call, model, mkt)
    assert abs(price - (spot - k)) < 1e-12


def test_invalid_inputs():
    eng = AnalyticEngine()
    mkt = MarketEnvironment()
    model = BlackScholesModel(sigma=0.2)
    opt = EuropeanOption("call", strike=100.0, maturity=1.0)

    with pytest.raises(InvalidDomainError):
        eng.price_bsm(0.0, opt, model, mkt)
