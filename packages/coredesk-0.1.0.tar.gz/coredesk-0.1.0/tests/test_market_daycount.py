from datetime import date

import pytest

from coredesk.core.exceptions import InvalidDomainError
from coredesk.market.daycount import ACT_360, ACT_365F, THIRTY_360, DayCount


def test_act_360_simple():
    start = date(2025, 1, 1)
    end = date(2025, 1, 31)  # 30 days later
    assert abs(ACT_360.year_fraction(start, end) - (30.0 / 360.0)) < 1e-12


def test_act_365f_simple():
    start = date(2025, 1, 1)
    end = date(2025, 1, 31)  # 30 days later
    assert abs(ACT_365F.year_fraction(start, end) - (30.0 / 365.0)) < 1e-12


def test_30_360_us_end_of_month_rule():
    # Classic check:
    # 30/360 US: Jan 31 -> Feb 28 counts as 28 days under rule (start day becomes 30)
    start = date(2025, 1, 31)
    end = date(2025, 2, 28)
    # d1 becomes 30, d2 stays 28 => 30*(2-1) + (28-30) = 28
    assert abs(THIRTY_360.year_fraction(start, end) - (28.0 / 360.0)) < 1e-12


def test_30_360_us_end_day_31_adjustment():
    start = date(2025, 4, 30)
    end = date(2025, 5, 31)
    # if end day is 31 and start day is 30 -> end day becomes 30
    # days360 = 30*(5-4) + (30-30) = 30
    assert abs(THIRTY_360.year_fraction(start, end) - (30.0 / 360.0)) < 1e-12


def test_invalid_order_raises():
    dc = DayCount("ACT/360")
    with pytest.raises(InvalidDomainError):
        dc.year_fraction(date(2025, 1, 2), date(2025, 1, 1))
