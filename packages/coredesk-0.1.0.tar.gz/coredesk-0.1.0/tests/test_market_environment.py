import pytest

from coredesk.core.exceptions import InvalidDomainError
from coredesk.market.environment import MarketEnvironment


def test_default_market_environment():
    mkt = MarketEnvironment()
    assert mkt.r == 0.0
    assert mkt.q == 0.0
    assert mkt.sigma == 0.2


def test_negative_sigma_rejected():
    with pytest.raises(InvalidDomainError):
        MarketEnvironment(sigma=-0.01)


def test_negative_rates_allowed():
    mkt = MarketEnvironment(r=-0.01, q=-0.02, sigma=0.3)
    assert mkt.r == -0.01
    assert mkt.q == -0.02
