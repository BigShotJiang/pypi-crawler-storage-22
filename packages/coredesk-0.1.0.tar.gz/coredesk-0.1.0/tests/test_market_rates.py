import math
import pytest

from coredesk.core.exceptions import InvalidDomainError
from coredesk.market.rates import COMPOUNDED, CONTINUOUS, SIMPLE, RateConvention


def test_simple_df_and_inverse():
    r = 0.05
    tau = 0.5
    df = SIMPLE.df(r, tau)
    r2 = SIMPLE.rate_from_df(df, tau)
    assert abs(r2 - r) < 1e-12


def test_compounded_df_and_inverse():
    r = 0.05
    tau = 2.0
    rc = COMPOUNDED(2)  # semi-annual
    df = rc.df(r, tau)
    r2 = rc.rate_from_df(df, tau)
    assert abs(r2 - r) < 1e-12


def test_continuous_df_and_inverse():
    r = 0.03
    tau = 3.0
    df = CONTINUOUS.df(r, tau)
    assert abs(df - math.exp(-r * tau)) < 1e-15
    r2 = CONTINUOUS.rate_from_df(df, tau)
    assert abs(r2 - r) < 1e-12


def test_tau_zero_rules():
    assert SIMPLE.rate_from_df(1.0, 0.0) == 0.0
    with pytest.raises(InvalidDomainError):
        SIMPLE.rate_from_df(0.999, 0.0)


def test_invalid_inputs():
    with pytest.raises(InvalidDomainError):
        RateConvention("compounded", freq=0)
    with pytest.raises(InvalidDomainError):
        SIMPLE.df(0.01, -0.1)
    with pytest.raises(InvalidDomainError):
        SIMPLE.rate_from_df(-1.0, 1.0)
