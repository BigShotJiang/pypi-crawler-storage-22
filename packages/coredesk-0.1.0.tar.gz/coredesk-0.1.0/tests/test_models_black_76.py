import pytest

from coredesk.core.exceptions import InvalidDomainError
from coredesk.models.black_76 import Black76Model


def test_black76_accepts_zero_vol():
    m = Black76Model(sigma=0.0)
    assert m.sigma == 0.0


def test_black76_rejects_negative_vol():
    with pytest.raises(InvalidDomainError):
        Black76Model(sigma=-1e-6)
