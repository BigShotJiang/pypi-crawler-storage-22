import pytest

from coredesk.core.exceptions import InvalidDomainError
from coredesk.models.black_scholes import BlackScholesModel


def test_model_accepts_zero_vol():
    m = BlackScholesModel(sigma=0.0)
    assert m.sigma == 0.0


def test_model_rejects_negative_vol():
    with pytest.raises(InvalidDomainError):
        BlackScholesModel(sigma=-0.1)
