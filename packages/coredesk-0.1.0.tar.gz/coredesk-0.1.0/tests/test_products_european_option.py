import pytest

from coredesk.core.exceptions import InvalidDomainError
from coredesk.products.european_option import EuropeanOption


def test_call_payoff():
    opt = EuropeanOption("call", strike=100.0, maturity=1.0)
    assert opt.payoff(90.0) == 0.0
    assert opt.payoff(100.0) == 0.0
    assert opt.payoff(120.0) == 20.0


def test_put_payoff():
    opt = EuropeanOption("put", strike=100.0, maturity=1.0)
    assert opt.payoff(120.0) == 0.0
    assert opt.payoff(100.0) == 0.0
    assert opt.payoff(80.0) == 20.0


def test_invalid_inputs():
    with pytest.raises(InvalidDomainError):
        EuropeanOption("CALL", strike=100.0, maturity=1.0)  # type: ignore[arg-type]
    with pytest.raises(InvalidDomainError):
        EuropeanOption("call", strike=0.0, maturity=1.0)
    with pytest.raises(InvalidDomainError):
        EuropeanOption("call", strike=100.0, maturity=-0.1)
    opt = EuropeanOption("call", strike=100.0, maturity=1.0)
    with pytest.raises(InvalidDomainError):
        opt.payoff(-1.0)
