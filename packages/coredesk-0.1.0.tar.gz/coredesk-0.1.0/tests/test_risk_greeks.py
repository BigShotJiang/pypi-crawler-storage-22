import numpy as np

from coredesk.engines.analytic import AnalyticEngine
from coredesk.market.environment import MarketEnvironment
from coredesk.models.black_76 import Black76Model
from coredesk.models.black_scholes import BlackScholesModel
from coredesk.products.european_option import EuropeanOption
from coredesk.risk.greeks import (
    delta_bsm,
    gamma_bsm,
    vega_bsm,
    delta_black76_forward,
    gamma_black76_forward,
    vega_black76,
)


def _fd_delta_price(fn, x, h):
    return (fn(x + h) - fn(x - h)) / (2.0 * h)


def _fd_gamma_price(fn, x, h):
    return (fn(x + h) - 2.0 * fn(x) + fn(x - h)) / (h * h)


def _fd_vega_price(fn_sigma, sigma, h):
    return (fn_sigma(sigma + h) - fn_sigma(sigma - h)) / (2.0 * h)


def test_bsm_greeks_match_fd():
    spot = 100.0
    k = 105.0
    t = 1.0
    r = 0.02
    q = 0.01
    sigma = 0.25

    mkt = MarketEnvironment(r=r, q=q, sigma=sigma)
    opt = EuropeanOption("call", strike=k, maturity=t)
    eng = AnalyticEngine()

    def price_s(s):
        return eng.price_bsm(s, opt, BlackScholesModel(sigma=sigma), mkt)

    def price_sigma(sig):
        return eng.price_bsm(spot, opt, BlackScholesModel(sigma=sig), mkt)

    h_s = 1e-4 * spot
    h_sig = 1e-5

    d_ana = delta_bsm(spot, opt, BlackScholesModel(sigma=sigma), mkt)
    g_ana = gamma_bsm(spot, opt, BlackScholesModel(sigma=sigma), mkt)
    v_ana = vega_bsm(spot, opt, BlackScholesModel(sigma=sigma), mkt)

    d_fd = _fd_delta_price(price_s, spot, h_s)
    g_fd = _fd_gamma_price(price_s, spot, h_s)
    v_fd = _fd_vega_price(price_sigma, sigma, h_sig)

    assert abs(d_ana - d_fd) < 1e-6
    assert abs(g_ana - g_fd) < 5e-6
    assert abs(v_ana - v_fd) < 1e-5


def test_black76_greeks_match_fd():
    fwd = 100.0
    k = 95.0
    t = 2.0
    r = 0.01
    sigma = 0.3

    mkt = MarketEnvironment(r=r, q=0.0, sigma=sigma)
    opt = EuropeanOption("put", strike=k, maturity=t)
    eng = AnalyticEngine()

    def price_f(f):
        return eng.price_black76(f, opt, Black76Model(sigma=sigma), mkt)

    def price_sigma(sig):
        return eng.price_black76(fwd, opt, Black76Model(sigma=sig), mkt)

    h_f = 1e-4 * fwd
    h_sig = 1e-5

    d_ana = delta_black76_forward(fwd, opt, Black76Model(sigma=sigma), mkt)
    g_ana = gamma_black76_forward(fwd, opt, Black76Model(sigma=sigma), mkt)
    v_ana = vega_black76(fwd, opt, Black76Model(sigma=sigma), mkt)

    d_fd = _fd_delta_price(price_f, fwd, h_f)
    g_fd = _fd_gamma_price(price_f, fwd, h_f)
    v_fd = _fd_vega_price(price_sigma, sigma, h_sig)

    assert abs(d_ana - d_fd) < 1e-6
    assert abs(g_ana - g_fd) < 5e-6
    assert abs(v_ana - v_fd) < 1e-5
