#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Author        : Lancelot PINCET
# GitHub        : https://github.com/LancelotPincet



# %% Libraries




# %% Function
def temp(**kwargs) :
    '''
    TODO
    '''

    print('Hello world!')