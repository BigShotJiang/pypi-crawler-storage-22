"""Tutorial doctests for coremusic.

Run with: pytest tests/tutorials/ --doctest-modules
"""
