# corp-entity-db

Entity database library and search engine for organizations, people, roles, and locations. Provides embedding-based semantic search over entities imported from GLEIF, SEC Edgar, Wikidata, and Companies House.

## Installation

```bash
pip install corp-entity-db
```

## Usage

```python
from corp_entity_db import OrganizationDatabase, get_database_path

db = OrganizationDatabase(get_database_path())
matches = db.search("Microsoft", limit=10)
for match in matches:
    print(f"{match.record.name} ({match.record.entity_type}) - score: {match.score:.3f}")
```

## CLI

```bash
corp-entity-db search "Microsoft"           # Search organizations
corp-entity-db search-people "Tim Cook"      # Search people
corp-entity-db status                        # Show database statistics
corp-entity-db serve                         # Start search server on :8222
```