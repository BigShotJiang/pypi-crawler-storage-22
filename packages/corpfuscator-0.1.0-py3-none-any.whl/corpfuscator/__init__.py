# from bidule.machine import Machine
# from bidule import Machine
# 
from .corpfuscator import Corpfuscator
from .corpfuscator import Dictionary
