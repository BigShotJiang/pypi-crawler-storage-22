"""
Cortex MCP - Cloud Sync Module
Google Drive 동기화 모듈

기능:
- Google Drive 업로드/다운로드
- 라이센스키 기반 E2E 암호화
- 환경 독립적 맥락 복구
"""

import io
import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

sys.path.append(str(Path(__file__).parent.parent))
from config import config

from .crypto_utils import CryptoUtils


class CloudSync:
    """클라우드 동기화 - Google Drive 연동"""

    def __init__(self, license_key: Optional[str] = None):
        self.memory_dir = config.memory_dir
        self.drive_folder = config.google_drive_folder
        self.license_key = license_key
        self.crypto = CryptoUtils(license_key) if license_key else None

        # Google API 클라이언트 (지연 초기화)
        self._drive_service = None

    def _init_drive_service(self):
        """Google Drive API 서비스 초기화"""
        if self._drive_service is None:
            from google.auth.transport.requests import Request
            from google.oauth2.credentials import Credentials
            from google_auth_oauthlib.flow import InstalledAppFlow
            from googleapiclient.discovery import build

            SCOPES = ["https://www.googleapis.com/auth/drive.file"]
            creds = None

            token_path = config.base_dir / "token.json"
            credentials_path = config.base_dir / "credentials.json"

            # 기존 토큰 확인
            if token_path.exists():
                creds = Credentials.from_authorized_user_file(str(token_path), SCOPES)

            # 토큰 갱신 또는 새로 인증
            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    creds.refresh(Request())
                else:
                    if not credentials_path.exists():
                        raise FileNotFoundError(
                            f"Google API 자격 증명 파일이 필요합니다: {credentials_path}"
                        )
                    flow = InstalledAppFlow.from_client_secrets_file(str(credentials_path), SCOPES)
                    creds = flow.run_local_server(port=0)

                # 토큰 저장
                token_path.write_text(creds.to_json())

            self._drive_service = build("drive", "v3", credentials=creds)

        return self._drive_service

    def _get_or_create_folder(self) -> str:
        """Cortex 전용 폴더 ID 가져오기 (없으면 생성)"""
        service = self._init_drive_service()

        # 폴더 검색
        query = f"name='{self.drive_folder}' and mimeType='application/vnd.google-apps.folder' and trashed=false"
        results = service.files().list(q=query, spaces="drive", fields="files(id, name)").execute()
        folders = results.get("files", [])

        if folders:
            return folders[0]["id"]

        # 폴더 생성
        file_metadata = {
            "name": self.drive_folder,
            "mimeType": "application/vnd.google-apps.folder",
        }
        folder = service.files().create(body=file_metadata, fields="id").execute()
        return folder.get("id")

    def sync_to_cloud(self, project_id: Optional[str] = None) -> Dict[str, Any]:
        """
        로컬 메모리를 Google Drive에 업로드

        Args:
            project_id: 특정 프로젝트만 동기화 (없으면 전체)

        Returns:
            동기화 결과
        """
        if not self.license_key:
            return {"success": False, "error": "라이센스 키가 필요합니다."}

        service = self._init_drive_service()
        folder_id = self._get_or_create_folder()

        # 동기화할 파일 목록
        if project_id:
            project_dirs = [self.memory_dir / project_id]
        else:
            project_dirs = [d for d in self.memory_dir.iterdir() if d.is_dir()]

        uploaded_files = []

        from googleapiclient.http import MediaIoBaseUpload
        import hashlib

        for project_dir in project_dirs:
            if not project_dir.exists():
                continue

            # 모든 동기화 대상 파일 수집 (하위 디렉토리 포함)
            sync_files = []
            for f in project_dir.rglob("*.md"):
                sync_files.append(f)
            for f in project_dir.rglob("*.json"):
                sync_files.append(f)

            for sync_file in sync_files:
                try:
                    # 파일 내용 읽기
                    content = sync_file.read_bytes()

                    # SHA-256 해시 생성 (무결성 검증용)
                    file_hash = hashlib.sha256(content).hexdigest()

                    # 암호화
                    encrypted_content = self.crypto.encrypt(content)

                    # 상대 경로 보존: project/subdir/file.md → project__subdir__file.md.enc
                    relative_path = sync_file.relative_to(project_dir)
                    backup_name = f"{project_dir.name}__{str(relative_path).replace('/', '__')}.enc"

                    # 기존 파일 확인
                    query = f"name='{backup_name}' and '{folder_id}' in parents and trashed=false"
                    existing = service.files().list(q=query, fields="files(id)").execute()

                    media = MediaIoBaseUpload(
                        io.BytesIO(encrypted_content),
                        mimetype="application/octet-stream",
                        resumable=True,
                    )

                    if existing.get("files"):
                        # 업데이트
                        file_id = existing["files"][0]["id"]
                        service.files().update(
                            fileId=file_id,
                            media_body=media,
                            body={"description": f"sha256:{file_hash}"}
                        ).execute()
                    else:
                        # 새로 업로드
                        file_metadata = {
                            "name": backup_name,
                            "parents": [folder_id],
                            "description": f"sha256:{file_hash}"
                        }
                        service.files().create(
                            body=file_metadata, media_body=media, fields="id"
                        ).execute()

                    uploaded_files.append(backup_name)
                except Exception as e:
                    logger.error(f"[CLOUD SYNC] Failed to upload {sync_file}: {e}")
                    continue  # 개별 파일 실패 시 다른 파일 계속 진행

        # Save sync status to local file for dashboard display
        sync_timestamp = datetime.now(timezone.utc).isoformat()
        status_file = config.base_dir / "cloud_sync_status.json"
        try:
            with open(status_file, 'w') as f:
                json.dump({
                    "last_sync": sync_timestamp,
                    "uploaded_count": len(uploaded_files),
                    "success": True
                }, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to save cloud sync status: {e}")

        return {
            "success": True,
            "uploaded_count": len(uploaded_files),
            "files": uploaded_files,
            "timestamp": sync_timestamp,
        }

    def sync_from_cloud(self, project_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Google Drive에서 로컬로 복원

        - 상대 경로 복원 (하위 디렉토리 구조 보존)
        - SHA-256 무결성 검증
        - Atomic write로 복원 안전성 보장

        Args:
            project_id: 특정 프로젝트만 복원 (없으면 전체)

        Returns:
            복원 결과
        """
        if not self.license_key:
            return {"success": False, "error": "라이센스 키가 필요합니다."}

        service = self._init_drive_service()
        folder_id = self._get_or_create_folder()

        # 클라우드의 파일 목록 (description 포함하여 해시 검증용)
        query = f"'{folder_id}' in parents and trashed=false"
        if project_id:
            query += f" and name contains '{project_id}__'"

        results = service.files().list(q=query, fields="files(id, name, description)").execute()

        files = results.get("files", [])
        restored_files = []
        integrity_failures = []

        from googleapiclient.http import MediaIoBaseDownload
        import hashlib
        import tempfile

        for file_info in files:
            if not file_info["name"].endswith(".enc"):
                continue

            try:
                # 파일 다운로드
                request = service.files().get_media(fileId=file_info["id"])
                fh = io.BytesIO()
                downloader = MediaIoBaseDownload(fh, request)

                done = False
                while not done:
                    _, done = downloader.next_chunk()

                # 복호화
                encrypted_content = fh.getvalue()
                try:
                    decrypted_content = self.crypto.decrypt(encrypted_content)
                except Exception as e:
                    logger.error(f"[CLOUD SYNC] Decryption failed for {file_info['name']}: {e}")
                    continue

                # A-3: SHA-256 무결성 검증
                expected_hash = ""
                description = file_info.get("description", "")
                if description and description.startswith("sha256:"):
                    expected_hash = description[7:]
                    actual_hash = hashlib.sha256(decrypted_content).hexdigest()
                    if actual_hash != expected_hash:
                        logger.error(
                            f"[CLOUD SYNC] Integrity check FAILED for {file_info['name']}: "
                            f"expected {expected_hash[:16]}..., got {actual_hash[:16]}..."
                        )
                        integrity_failures.append(file_info["name"])
                        continue

                # 파일명 파싱: project__subdir__file.md.enc → project/subdir/file.md
                backup_name = file_info["name"][:-4]  # .enc 제거
                parts = backup_name.split("__", 1)
                if len(parts) != 2:
                    # 구버전 호환: project_filename.md 형식
                    parts = backup_name.split("_", 1)
                    if len(parts) != 2:
                        continue
                    proj_id, filename = parts
                    relative_path = filename
                else:
                    proj_id = parts[0]
                    relative_path = parts[1].replace("__", "/")

                # 로컬에 저장
                project_dir = self.memory_dir / proj_id
                local_path = project_dir / relative_path
                local_path.parent.mkdir(parents=True, exist_ok=True)

                # 충돌 감지: 로컬 파일이 있으면 백업
                if local_path.exists():
                    backup_path = local_path.with_suffix(local_path.suffix + ".cloud_backup")
                    local_path.rename(backup_path)
                    logger.warning(
                        f"[CLOUD SYNC] Conflict: Local file backed up to {backup_path.name}"
                    )

                # A-2: Atomic write로 안전하게 저장 (에러 시 .tmp 정리)
                temp_path = local_path.with_suffix(local_path.suffix + ".tmp")
                try:
                    temp_path.write_bytes(decrypted_content)
                    os.replace(str(temp_path), str(local_path))
                except Exception as write_err:
                    if temp_path.exists():
                        temp_path.unlink()
                    raise write_err

                restored_files.append(str(local_path))
            except Exception as e:
                logger.error(f"[CLOUD SYNC] Failed to restore {file_info['name']}: {e}")
                continue

        # Save sync status to local file for dashboard display
        sync_timestamp = datetime.now(timezone.utc).isoformat()
        status_file = config.base_dir / "cloud_sync_status.json"
        try:
            from .atomic_write import atomic_write as atomic_write_fn
            status_data = json.dumps({
                "last_sync": sync_timestamp,
                "restored_count": len(restored_files),
                "integrity_failures": len(integrity_failures),
                "success": len(integrity_failures) == 0
            }, ensure_ascii=False, indent=2)
            atomic_write_fn(str(status_file), status_data)
        except Exception as e:
            logger.warning(f"Failed to save cloud sync status: {e}")

        return {
            "success": True,
            "restored_count": len(restored_files),
            "files": restored_files,
            "integrity_failures": integrity_failures,
            "timestamp": sync_timestamp,
        }

    def list_cloud_backups(self) -> List[Dict[str, Any]]:
        """클라우드 백업 목록 조회"""
        service = self._init_drive_service()
        folder_id = self._get_or_create_folder()

        query = f"'{folder_id}' in parents and trashed=false"
        results = (
            service.files().list(q=query, fields="files(id, name, modifiedTime, size)").execute()
        )

        return results.get("files", [])
