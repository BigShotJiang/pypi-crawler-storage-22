"""Backend communication for API key validation."""

from cortexhub.backend.client import BackendClient

__all__ = ["BackendClient"]
