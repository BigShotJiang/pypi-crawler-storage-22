"""COSMIC pipeline stages."""

from cosmic.pipeline.base import PipelineStage, StageResult

__all__ = [
    "PipelineStage",
    "StageResult",
]
