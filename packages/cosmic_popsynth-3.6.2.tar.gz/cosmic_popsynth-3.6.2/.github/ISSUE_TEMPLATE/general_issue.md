---
name: general issue
about: Way to systematically track weird evoltuionary behavior and things tried to
  resolve that behavior for better history tracking.
title: "[general issue]"
labels: general
---

# Describe your issue in as much detail as possible -- if your issue arises from a cosmic-pop command line call, please include the exact syntax of the command line call in your description.
