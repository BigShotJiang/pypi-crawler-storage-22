---
name: Unexpected Stellar Evolutionary Behavior
about: Way to systematically track weird evoltuionary behavior and things tried to
  resolve that behavior for better history tracking.
title: "[Unexpected Evolutionary Behavior]"
labels: Unexpected Evolutionary Behavior
assignees: ''

---

# CSV file with Initial Conditions and BSE flags creating this behavior

# Code that produces the BPP and BCM arrays

# Description of Weird Behavior

# Flags you have tried to turn on and off that you think relate to the evolutionary behavior

# Plot (if applicable)
