*********************
Creating new settings
*********************

.. note::

    The page is a stub and needs updating by a COSMIC developer - use the edit icon at the top of the page to make changes!