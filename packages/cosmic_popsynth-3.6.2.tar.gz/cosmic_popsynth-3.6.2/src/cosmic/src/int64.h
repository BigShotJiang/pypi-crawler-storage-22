      integer int64
      parameter (int64=8)
      COMMON/integers/ umax
      integer(kind=int64) umax
      SAVE /integers/

