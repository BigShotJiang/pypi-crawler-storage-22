# Copyright (C) - 2023 - 2025 - Cosmo Tech
# This document and all information contained herein is the exclusive property -
# including all intellectual property rights pertaining thereto - of Cosmo Tech.
# Any use, reproduction, translation, broadcasting, transmission, distribution,
# etc., to any person is prohibited unless it has been previously and
# specifically authorized by written means by Cosmo Tech.

"""
PostgreSQL store operations module.

This module provides functions for interacting with PostgreSQL databases
for store operations.
"""

from time import perf_counter

from cosmotech.orchestrator.utils.translate import T

from cosmotech.coal.postgresql.utils import PostgresUtils
from cosmotech.coal.store.store import Store
from cosmotech.coal.utils.configuration import Configuration
from cosmotech.coal.utils.logger import LOGGER


def dump_store_to_postgresql(
    store_folder: str,
    postgres_host: str,
    postgres_port: int,
    postgres_db: str,
    postgres_schema: str,
    postgres_user: str,
    postgres_password: str,
    table_prefix: str = "Cosmotech_",
    replace: bool = True,
    force_encode: bool = False,
    selected_tables: list[str] = [],
    fk_id: str = None,
) -> None:
    """
    Dump Store data to a PostgreSQL database.

    Args:
        store_folder: Folder containing the Store
        postgres_host: PostgreSQL host
        postgres_port: PostgreSQL port
        postgres_db: PostgreSQL database name
        postgres_schema: PostgreSQL schema
        postgres_user: PostgreSQL username
        postgres_password: PostgreSQL password
        table_prefix: Table prefix
        replace: Whether to replace existing tables
        force_encode: force password encoding to percent encoding
        selected_tables: list of tables to send
        fk_id: foreign key id to add to all table on all rows
    """
    _c = Configuration()
    _c.postgres.host = postgres_host
    _c.postgres.port = postgres_port
    _c.postgres.db_name = postgres_db
    _c.postgres.db_schema = postgres_schema
    _c.postgres.user_name = postgres_user
    _c.postgres.user_password = postgres_password
    _c.postgres.password_encoding = force_encode
    _c.postgres.table_prefix = table_prefix

    dump_store_to_postgresql_from_conf(
        configuration=_c, store_folder=store_folder, replace=replace, selected_tables=selected_tables, fk_id=fk_id
    )


def dump_store_to_postgresql_from_conf(
    configuration: Configuration,
    store_folder: str,
    replace: bool = True,
    selected_tables: list[str] = [],
    fk_id: str = None,
) -> None:
    """
    Dump Store data to a PostgreSQL database.

    Args:
        configuration: coal Configuration
        store_folder: Folder containing the Store
        replace: Whether to replace existing tables
        selected_tables: list of tables to send
        fk_id: foreign key id to add to all table on all rows
    """
    _psql = PostgresUtils(configuration)
    print(_psql.send_pyarrow_table_to_postgresql)
    _s = Store(store_location=store_folder)

    tables = list(_s.list_tables())
    if selected_tables:
        tables = [t for t in tables if t in selected_tables]
    if len(tables):
        LOGGER.info(T("coal.services.database.sending_data").format(table=f"{_psql.db_name}.{_psql.db_schema}"))
        total_rows = 0
        _process_start = perf_counter()
        for table_name in tables:
            _s_time = perf_counter()
            target_table_name = f"{_psql.table_prefix}{table_name}"
            LOGGER.info(T("coal.services.database.table_entry").format(table=target_table_name))
            if fk_id:
                _s.execute_query(
                    f"""
                    ALTER TABLE {_psql.table_prefix}{table_name}
                    ADD run_id TEXT NOT NULL
                    DEFAULT ({fk_id})
                    """
                )
            data = _s.get_table(table_name)
            if not len(data):
                LOGGER.info(T("coal.services.database.no_rows"))
                continue
            _dl_time = perf_counter()
            rows = _psql.send_pyarrow_table_to_postgresql(
                data,
                target_table_name,
                replace,
            )
            if fk_id and _psql.is_metadata_exists():
                metadata_table = f"{_psql.table_prefix}RunnerMetadata"
                _psql.add_fk_constraint(table_name, "run_id", metadata_table, "last_run_id")

            total_rows += rows
            _up_time = perf_counter()
            LOGGER.info(T("coal.services.database.row_count").format(count=rows))
            LOGGER.debug(
                T("coal.common.timing.operation_completed").format(
                    operation="Load from datastore", time=f"{_dl_time - _s_time:0.3}"
                )
            )
            LOGGER.debug(
                T("coal.common.timing.operation_completed").format(
                    operation="Send to postgresql", time=f"{_up_time - _dl_time:0.3}"
                )
            )
        _process_end = perf_counter()
        LOGGER.info(
            T("coal.services.database.rows_fetched").format(
                table="all tables",
                count=total_rows,
                time=f"{_process_end - _process_start:0.3}",
            )
        )
    else:
        LOGGER.info(T("coal.services.database.store_empty"))
