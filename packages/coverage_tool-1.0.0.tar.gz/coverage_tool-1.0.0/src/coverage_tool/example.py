#!/usr/bin/env python3
"""
使用示例 - 演示覆盖率工具的基本用法
"""

import os
import sys
import tempfile

from coverage_tool.main import CoverageTool, ToolConfig
from coverage_tool.core import Language, ReportFormat

def create_sample_python_project(project_dir):
    """创建一个示例Python项目"""
    # 创建主模块
    main_file = os.path.join(project_dir, "main.py")
    with open(main_file, 'w') as f:
        f.write("""
def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b
""")
    
    # 创建测试文件
    test_file = os.path.join(project_dir, "test_main.py")
    with open(test_file, 'w') as f:
        f.write("""
import pytest
from main import add, subtract, multiply

def test_add():
    assert add(2, 3) == 5
    assert add(-1, 1) == 0

def test_subtract():
    assert subtract(5, 3) == 2
    assert subtract(0, 5) == -5

def test_multiply():
    assert multiply(3, 4) == 12
    assert multiply(-2, 3) == -6

# 这个测试会失败
def test_fail():
    assert add(1, 1) == 3  # 错误的断言
""")
    
    print(f"✓ 创建示例Python项目: {project_dir}")
    return project_dir

def run_example():
    """运行示例"""
    print("=" * 60)
    print("覆盖率工具使用示例")
    print("=" * 60)
    
    # 创建临时项目
    with tempfile.TemporaryDirectory() as project_dir:
        create_sample_python_project(project_dir)
        
        print("\n配置工具...")
        config = ToolConfig(
            language=Language.PYTHON,
            target_dir=project_dir,
            output_file="coverage_report",
            report_format=ReportFormat.TEXT,
            max_compile_iterations=3,
            max_cleanup_iterations=3
        )
        
        print("运行覆盖率分析...")
        print("-" * 60)
        
        try:
            with CoverageTool(config) as tool:
                report = tool.run()
                
                print("\n" + "=" * 60)
                print("分析结果")
                print("=" * 60)
                
                if report.stats:
                    stat = report.stats[0]
                    print(f"语言: {stat.language}")
                    print(f"测试用例: {stat.total_tests}")
                    print(f"通过: {stat.passed_tests}")
                    print(f"失败: {stat.failed_tests}")
                    print(f"覆盖率: {stat.coverage_rate:.2f}%")
                    print(f"执行时间: {stat.duration:.2f}s")
        
        except Exception as e:
            print(f"\n错误: {e}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    run_example()
