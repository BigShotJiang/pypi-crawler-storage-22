#!/usr/bin/env python3
"""
智能编译失败处理器
支持渐进式删除策略和依赖分析
"""

import os
import re
import shutil
from typing import List, Tuple, Optional, Dict, Set
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum

from coverage_tool.utils import FileBackupManager, DependencyGraph, Logger, parse_error_locations, safe_delete_file


class FilePriority(Enum):
    """文件优先级"""
    LOW = 1      # 可以安全删除的文件（如测试文件、示例文件）
    MEDIUM = 2   # 普通源文件
    HIGH = 3     # 核心文件（如main文件、配置文件）
    CRITICAL = 4 # 绝对不能删除的文件


@dataclass
class FileInfo:
    """文件信息"""
    path: str
    priority: FilePriority
    error_count: int = 0
    is_test_file: bool = False
    is_source_file: bool = False
    dependents: List[str] = field(default_factory=list)


class SmartCompilationHandler:
    """智能编译失败处理器"""
    
    def __init__(self, target_dir: str, logger: Optional[Logger] = None):
        self.target_dir = target_dir
        self.logger = logger or Logger()
        self.backup_manager = FileBackupManager()
        self.dependency_graph = DependencyGraph()
        self.deleted_files: List[str] = []
        self.compilation_history: List[Dict] = []
        
        # 文件优先级模式
        self.priority_patterns = {
            FilePriority.LOW: [
                r'.*test.*\.(py|java|go|c|cpp|h|hpp)$',
                r'.*example.*\.(py|java|go|c|cpp)$',
                r'.*demo.*\.(py|java|go|c|cpp)$',
                r'.*mock.*\.(py|java|go|c|cpp)$',
                r'.*stub.*\.(py|java|go|c|cpp)$',
            ],
            FilePriority.HIGH: [
                r'^main\.(py|java|go|c|cpp)$',
                r'^index\.(py|java|go|c|cpp)$',
                r'^app\.(py|java|go|c|cpp)$',
                r'^setup\.py$',
                r'^[Rr]eadme\.md$',
                r'^go\.mod$',
                r'^pom\.xml$',
                r'^build\.gradle$',
                r'^Makefile$',
                r'^CMakeLists\.txt$',
            ],
            FilePriority.CRITICAL: [
                r'.*\.git.*',
                r'.*\.svn.*',
            ]
        }
    
    def analyze_compilation_errors(self, errors: List[str]) -> List[FileInfo]:
        """分析编译错误，提取问题文件"""
        error_locations = parse_error_locations(errors, self.target_dir)
        
        file_infos = []
        for file_path, line_nums in error_locations.items():
            if os.path.exists(file_path):
                info = FileInfo(
                    path=file_path,
                    priority=self._determine_priority(file_path),
                    error_count=len(line_nums),
                    is_test_file=self._is_test_file(file_path),
                    is_source_file=self._is_source_file(file_path)
                )
                file_infos.append(info)
        
        # 按优先级和错误数量排序（优先级低的先删除）
        file_infos.sort(key=lambda x: (x.priority.value, -x.error_count))
        
        return file_infos
    
    def _determine_priority(self, file_path: str) -> FilePriority:
        """确定文件优先级"""
        file_name = os.path.basename(file_path)
        
        # 检查CRITICAL模式
        for pattern in self.priority_patterns[FilePriority.CRITICAL]:
            if re.match(pattern, file_name, re.IGNORECASE):
                return FilePriority.CRITICAL
        
        # 检查HIGH模式
        for pattern in self.priority_patterns[FilePriority.HIGH]:
            if re.match(pattern, file_name, re.IGNORECASE):
                return FilePriority.HIGH
        
        # 检查LOW模式
        for pattern in self.priority_patterns[FilePriority.LOW]:
            if re.match(pattern, file_name, re.IGNORECASE):
                return FilePriority.LOW
        
        return FilePriority.MEDIUM
    
    def _is_test_file(self, file_path: str) -> bool:
        """检查是否是测试文件"""
        test_patterns = [
            r'.*test.*\.(py|java|go|c|cpp)$',
            r'.*_test\.(py|java|go|c|cpp)$',
            r'test_.*\.py$',
            r'.*Test\.java$',
        ]
        file_name = os.path.basename(file_path)
        for pattern in test_patterns:
            if re.match(pattern, file_name, re.IGNORECASE):
                return True
        return False
    
    def _is_source_file(self, file_path: str) -> bool:
        """检查是否是源文件"""
        source_extensions = ['.py', '.java', '.go', '.c', '.cpp', '.h', '.hpp']
        ext = os.path.splitext(file_path)[1].lower()
        return ext in source_extensions
    
    def handle_compilation_failure(
        self, 
        errors: List[str], 
        compile_func,
        max_iterations: int = 10
    ) -> Tuple[bool, List[str], List[str]]:
        """
        处理编译失败，使用渐进式删除策略
        
        Args:
            errors: 编译错误列表
            compile_func: 编译函数，接收target_dir，返回(success, errors)
            max_iterations: 最大尝试次数
            
        Returns:
            (编译是否成功, 被删除的文件列表, 剩余的编译错误)
        """
        self.logger.info(f"开始处理编译失败，共 {len(errors)} 个错误")
        
        iteration = 0
        current_errors = errors.copy()
        
        while iteration < max_iterations and current_errors:
            iteration += 1
            self.logger.info(f"编译修复迭代 {iteration}/{max_iterations}")
            
            # 分析错误
            file_infos = self.analyze_compilation_errors(current_errors)
            
            if not file_infos:
                self.logger.warning("无法从错误信息中识别问题文件")
                break
            
            # 过滤掉不能删除的文件
            deletable_files = [
                info for info in file_infos 
                if info.priority not in [FilePriority.CRITICAL, FilePriority.HIGH]
            ]
            
            if not deletable_files:
                self.logger.warning("没有可安全删除的文件")
                break
            
            # 选择要删除的文件（每次最多删除3个，避免过度删除）
            files_to_delete = deletable_files[:3]
            
            # 检查依赖关系
            for file_info in files_to_delete:
                impacted = self.dependency_graph.get_impact_files(file_info.path)
                if impacted:
                    self.logger.warning(
                        f"删除 {file_info.path} 会影响 {len(impacted)} 个文件"
                    )
            
            # 备份并删除文件
            deleted_in_iteration = []
            for file_info in files_to_delete:
                if safe_delete_file(file_info.path, self.backup_manager):
                    deleted_in_iteration.append(file_info.path)
                    self.deleted_files.append(file_info.path)
                    self.logger.info(f"已删除文件: {file_info.path}")
            
            if not deleted_in_iteration:
                self.logger.warning("本轮未能删除任何文件")
                break
            
            # 记录编译历史
            self.compilation_history.append({
                'iteration': iteration,
                'deleted_files': deleted_in_iteration,
                'error_count_before': len(current_errors)
            })
            
            # 尝试重新编译
            success, new_errors = compile_func(self.target_dir)
            
            if success:
                self.logger.info(f"编译成功！共进行了 {iteration} 轮修复")
                return True, self.deleted_files, []
            
            # 检查错误是否减少
            if len(new_errors) >= len(current_errors):
                self.logger.warning(
                    f"错误数量未减少 ({len(current_errors)} -> {len(new_errors)})，"
                    "可能需要更激进的删除策略"
                )
            
            current_errors = new_errors
        
        # 达到最大迭代次数仍未成功
        self.logger.error(f"编译修复失败，已达到最大迭代次数 {max_iterations}")
        return False, self.deleted_files, current_errors
    
    def restore_deleted_files(self) -> List[str]:
        """恢复所有已删除的文件"""
        restored = []
        for file_path in self.deleted_files:
            if self.backup_manager.restore_file(file_path):
                restored.append(file_path)
                self.logger.info(f"已恢复文件: {file_path}")
        self.deleted_files.clear()
        return restored
    
    def get_deleted_files(self) -> List[str]:
        """获取已删除的文件列表"""
        return self.deleted_files.copy()
    
    def get_compilation_history(self) -> List[Dict]:
        """获取编译历史记录"""
        return self.compilation_history.copy()
    
    def cleanup(self):
        """清理资源"""
        self.backup_manager.cleanup()


class CompilationErrorParser:
    """编译错误解析器"""
    
    # 各种语言的编译错误模式
    ERROR_PATTERNS = {
        'python': [
            (r'File "([^"]+\.py)", line (\d+)', 'file_and_line'),
            (r'SyntaxError.*in ([^\s]+\.py)', 'syntax_error'),
            (r'ImportError.*from ([^\s]+\.py)', 'import_error'),
        ],
        'java': [
            (r'([^\s]+\.java):(\d+):', 'file_and_line'),
            (r'error: cannot find symbol\s+Location: ([^\s]+\.java)', 'symbol_error'),
            (r'error: package ([^\s]+) does not exist', 'package_error'),
        ],
        'go': [
            (r'# ([^\s]+)', 'package_error'),
            (r'([^\s]+\.go):(\d+):(\d+):', 'file_and_line'),
            (r'([^\s]+\.go):(\d+):', 'file_and_line'),
            (r'undefined:\s+(\w+)', 'undefined_error'),
        ],
        'c': [
            (r'([^\s]+\.(c|h)):(\d+):(\d+):', 'file_and_line'),
            (r'([^\s]+\.(c|h)):(\d+):', 'file_and_line'),
            (r'undefined reference to', 'link_error'),
        ],
        'cpp': [
            (r'([^\s]+\.(cpp|hpp|cc|hh)):(\d+):(\d+):', 'file_and_line'),
            (r'([^\s]+\.(cpp|hpp|cc|hh)):(\d+):', 'file_and_line'),
            (r'undefined reference to', 'link_error'),
        ]
    }
    
    @staticmethod
    def parse_errors(errors: List[str], language: str, project_dir: str) -> Dict[str, List[Dict]]:
        """
        解析编译错误
        
        Returns:
            按文件分类的错误信息
        """
        patterns = CompilationErrorParser.ERROR_PATTERNS.get(language, [])
        file_errors: Dict[str, List[Dict]] = {}
        
        for error in errors:
            for pattern, error_type in patterns:
                matches = re.findall(pattern, error)
                for match in matches:
                    if isinstance(match, tuple):
                        file_path = match[0]
                        line_num = int(match[1]) if len(match) > 1 and match[1].isdigit() else 0
                    else:
                        file_path = match
                        line_num = 0
                    
                    # 规范化路径
                    if not os.path.isabs(file_path):
                        file_path = os.path.join(project_dir, file_path)
                    file_path = os.path.normpath(file_path)
                    
                    if file_path not in file_errors:
                        file_errors[file_path] = []
                    
                    file_errors[file_path].append({
                        'line': line_num,
                        'type': error_type,
                        'message': error
                    })
        
        return file_errors
