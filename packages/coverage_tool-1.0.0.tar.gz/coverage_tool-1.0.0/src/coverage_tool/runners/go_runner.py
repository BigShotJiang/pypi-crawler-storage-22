#!/usr/bin/env python3
"""
Go单测运行器
"""

import subprocess
import os
import shutil
from typing import List, Tuple, Optional

from coverage_tool.converters import JUnitReportConverter
from .base import BaseRunner, RunResult, CoverageExtractor


class GoRunner(BaseRunner):
    """Go单测运行器"""
    
    def _ensure_go_junit_report(self) -> bool:
        """确保 go-junit-report 工具已安装，未安装时自动安装"""
        # 检查是否已安装
        result = subprocess.run(
            ["which", "go-junit-report"],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            self.logger.debug("go-junit-report 已安装")
            return True
        
        # 未安装，尝试自动安装
        self.logger.info("[工具安装] go-junit-report 未安装，正在自动安装...")
        install_result = subprocess.run(
            ["go", "install", "github.com/jstemmer/go-junit-report/v2@latest"],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        if install_result.returncode == 0:
            # 获取 GOPATH 并添加到 PATH
            go_path_result = subprocess.run(
                ["go", "env", "GOPATH"],
                capture_output=True,
                text=True
            )
            if go_path_result.returncode == 0:
                go_path = go_path_result.stdout.strip()
                gopath_bin = os.path.join(go_path, "bin")
                current_path = os.environ.get('PATH', '')
                if gopath_bin not in current_path:
                    os.environ['PATH'] = f"{gopath_bin}:{current_path}"
            
            self.logger.info("[工具安装] ✓ go-junit-report 安装成功")
            return True
        else:
            self.logger.warning(f"[工具安装] ✗ go-junit-report 安装失败: {install_result.stderr}")
            return False
    
    def run_tests(self, target_dir: str, output_file: str) -> RunResult:
        """运行Go测试"""
        # 确保 go-junit-report 已安装（Go依赖由go test自动下载）
        has_junit_tool = self._ensure_go_junit_report()
        
        # 运行测试（标准输出格式，不是-json）
        cmd = "go test -v -cover -coverprofile=coverage.out ./... 2>&1"
        result = self._run_command(cmd, target_dir)
        
        # 使用 go-junit-report 生成 JUnit XML
        if result.stdout:
            junit_xml_generated = False
            
            if has_junit_tool:
                try:
                    # 使用 go-junit-report 转换
                    report_cmd = ["go-junit-report", "-set-exit-code"]
                    junit_result = subprocess.run(
                        report_cmd,
                        input=result.stdout,
                        capture_output=True,
                        text=True,
                        timeout=60
                    )
                    
                    if junit_result.returncode == 0 or junit_result.stdout:
                        with open(output_file, 'w') as f:
                            f.write(junit_result.stdout)
                        result.junit_xml_path = output_file
                        junit_xml_generated = True
                        self.logger.info("[报告生成] ✓ 使用 go-junit-report 生成 JUnit XML")
                    else:
                        self.logger.warning(f"[报告生成] go-junit-report 执行失败: {junit_result.stderr}")
                except Exception as e:
                    self.logger.warning(f"[报告生成] go-junit-report 执行错误: {e}")
            
            # 如果 go-junit-report 失败或未安装，使用内置转换作为备用
            if not junit_xml_generated:
                try:
                    xml_content = JUnitReportConverter.convert_go_test(result.stdout)
                    with open(output_file, 'w') as f:
                        f.write(xml_content)
                    result.junit_xml_path = output_file
                    self.logger.info("[报告生成] ✓ 使用内置转换器生成 JUnit XML")
                except Exception as e:
                    self.logger.error(f"转换Go测试输出失败: {e}")
        
        # 复制coverage.out到临时目录
        project_coverage = os.path.join(target_dir, "coverage.out")
        if os.path.exists(project_coverage):
            temp_dir = os.path.dirname(output_file)
            if temp_dir:
                temp_coverage = os.path.join(temp_dir, "coverage.out")
                shutil.copy2(project_coverage, temp_coverage)
        
        result.coverage_rate = self.get_coverage(output_file, target_dir)
        
        return result
    
    def get_coverage(self, output_file: str, target_dir: Optional[str] = None) -> float:
        """获取Go覆盖率"""
        # 尝试多个可能的 coverage.out 位置
        possible_paths = []
        
        # 1. 临时目录
        if output_file:
            temp_dir = os.path.dirname(output_file)
            if temp_dir:
                possible_paths.append(os.path.join(temp_dir, "coverage.out"))
        
        # 2. 目标项目目录（最重要）
        if target_dir:
            possible_paths.append(os.path.join(target_dir, "coverage.out"))
        
        # 3. 当前工作目录
        possible_paths.append(os.path.join(os.getcwd(), "coverage.out"))
        
        # 尝试每个路径
        for coverage_path in possible_paths:
            if os.path.exists(coverage_path):
                self.logger.debug(f"找到Go覆盖率文件: {coverage_path}")
                coverage = CoverageExtractor.extract_from_coverage_out(coverage_path, 'go')
                if coverage > 0:
                    return coverage
        
        self.logger.warning("未找到Go覆盖率文件 (coverage.out)")
        return 0.0
    
    def compile(self, target_dir: str) -> Tuple[bool, List[str]]:
        """编译Go项目"""
        cmd = "go build ./"
        result = self._run_command(cmd, target_dir)
        
        errors = []
        if not result.success:
            for line in result.stderr.split('\n'):
                if line.strip() and ('#' in line or 'error' in line.lower()):
                    errors.append(line.strip())
        
        return result.success, errors
