#!/usr/bin/env python3
"""
Java单测运行器
"""

import os
from typing import List, Tuple

from .base import BaseRunner, RunResult, CoverageExtractor


class JavaRunner(BaseRunner):
    """Java单测运行器"""
    
    def run_tests(self, target_dir: str, output_file: str) -> RunResult:
        """运行Java测试"""
        # 使用Maven运行测试
        cmd = f"mvn test -Dtest.output={output_file}"
        result = self._run_command(cmd, target_dir)
        
        # Maven通常生成surefire报告
        surefire_report = os.path.join(target_dir, "target", "surefire-reports")
        if os.path.exists(surefire_report):
            # 转换surefire报告为JUnit XML
            self._convert_surefire_reports(surefire_report, output_file)
        
        result.junit_xml_path = output_file if os.path.exists(output_file) else None
        result.coverage_rate = self.get_coverage(output_file)
        
        return result
    
    def _convert_surefire_reports(self, surefire_dir: str, output_file: str):
        """转换Surefire报告为JUnit XML"""
        # 这里简化处理，实际应该解析XML并合并
        pass
    
    def get_coverage(self, output_file: str) -> float:
        """获取Java覆盖率（JaCoCo）"""
        # JaCoCo报告通常在 target/site/jacoco/index.html
        jacoco_html = os.path.join("target", "site", "jacoco", "index.html")
        return CoverageExtractor.extract_from_jacoco(jacoco_html)
    
    def compile(self, target_dir: str) -> Tuple[bool, List[str]]:
        """编译Java项目"""
        cmd = "mvn compile"
        result = self._run_command(cmd, target_dir)
        
        errors = []
        if not result.success:
            for line in result.stderr.split('\n'):
                if 'error:' in line.lower() or 'cannot find symbol' in line.lower():
                    errors.append(line.strip())
        
        return result.success, errors
