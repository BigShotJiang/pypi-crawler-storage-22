# 多语言单测覆盖率统计工具

一个功能强大的多语言单测覆盖率统计工具，支持Python、Java、Go、C、C++等编程语言，自动执行测试、分析覆盖率、删除失败的测试用例，并生成详细的测试报告。

## 优化亮点

- **智能编译修复**: 采用渐进式删除策略，根据文件优先级和依赖关系智能删除问题文件
- **AST解析支持**: Python测试删除使用AST解析，更准确地识别和删除测试函数
- **统一覆盖率计算**: 所有语言使用统一的覆盖率提取器，结果更准确
- **完善的日志系统**: 详细的执行日志，便于问题排查
- **文件备份机制**: 删除前自动备份，支持恢复操作

## 功能特性

- **多语言支持**: 支持 Python、Java、Go、C、C++ 五种编程语言
- **自动测试执行**: 集成各语言的主流测试框架和覆盖率工具
- **智能环境检查**: 自动分析项目配置文件 (requirements.txt, pom.xml 等)，检查编译和测试环境是否满足要求，并提供安装建议
- **智能错误恢复**: 编译失败时自动删除问题文件，直到编译通过
- **失败测试清理**: 自动删除测试失败的函数，确保所有单测都通过
- **多种报告格式**: 支持 Text、JSON、CSV、HTML 四种报告格式
- **JUnit XML 解析**: 统一解析各语言生成的 JUnit XML 测试报告

## 安装

### 方式一：直接使用

```bash
# 克隆项目
git clone <repository-url>
cd coverage_tool

# 确保Python版本 >= 3.7
python3 --version
```

### 方式二：安装依赖（可选，仅用于开发测试）

```bash
pip install -r requirements.txt
```

**注意**：工具本身仅依赖Python标准库，无需安装额外Python包。但根据你需要分析的项目语言，可能需要安装对应的编译和测试工具：

| 语言 | 必需依赖 |
|------|----------|
| Python | Python 3.7+, pytest, coverage.py |
| Java | JDK 8+, Maven |
| Go | Go SDK 1.16+ |
| C/C++ | GCC/G++, Make |

工具启动时会自动检查这些环境依赖。

## 使用方法

### 基本语法

```bash
python main.py -l <language> -t <target_dir> [options]
```

### 参数说明

| 参数 | 短参数 | 说明 | 默认值 |
|------|--------|------|--------|
| --language | -l | 编程语言 (python/java/go/c/cpp) | 必填 |
| --target | -t | 目标目录路径 | 必填 |
| --output | -o | 输出报告文件名 | coverage_report |
| --format | -f | 报告格式 (text/json/csv/html) | text |
| --no-delete | - | 编译失败时不删除文件 | False |
| --compile-timeout | - | 编译超时时间（秒） | 60 |
| --test-timeout | - | 测试超时时间（秒） | 300 |

### 使用示例

#### Python 项目

```bash
# 基本使用
python main.py --language python --target ./src --output report

# 生成 JSON 格式报告
python main.py -l python -t ./project -f json

# 不自动删除编译失败的文件
python main.py -l python -t ./src --no-delete
```

#### Java 项目

```bash
# Maven 项目
python main.py --language java --target ./myproject

# 生成 HTML 格式报告
python main.py -l java -t ./project -f html
```

#### Go 项目

```bash
# Go 模块项目
python main.py --language go --target ./module

# 生成详细报告
python main.py -l go -t ./src -o go_coverage -f html
```

#### C/C++ 项目

```bash
# C 项目
python main.py --language c --target ./c_project

# C++ 项目
python main.py --language cpp --target ./cpp_project -f json
```

## 智能环境检查

工具会自动分析项目配置文件，检查编译和测试环境是否满足要求：

| 语言 | 检测的配置文件 |
|------|---------------|
| Python | `requirements.txt`, `setup.py`, `pyproject.toml` |
| Java | `pom.xml`, `build.gradle` |
| Go | `go.mod` |
| C/C++ | `Makefile`, `CMakeLists.txt` |

**示例输出：**
```
============================================================
环境检查报告: python
============================================================

📁 检测到的项目配置:
   • 构建系统: pip
   • 测试框架: pytest

✓ Python
   版本: Python 3.12.8

✗ pytest
   未安装
   安装: pip install pytest

============================================================
✗ 存在缺失的关键依赖
缺失项: pytest
============================================================
```

## 工作流程

```
1. 编译检查
   ↓
   ├── 编译成功 → 继续执行测试
   └── 编译失败 → 自动删除问题文件 → 重试 (最多10次)
               ↓
               无法恢复 → 报错退出
               ↓
2. 运行测试
   ↓
3. 解析 JUnit XML 报告
   ↓
4. 分析覆盖率
   ↓
5. 删除失败的测试函数
   ↓
6. 重新测试验证
   ↓
7. 生成最终报告
```

## 报告示例

### Text 格式

```
================================================================================
单测覆盖率报告
项目: myproject
生成时间: 2024-01-15 10:30:00
================================================================================

语言: python
----------------------------------------
  测试用例数: 100
  通过: 95
  失败: 3
  错误: 2
  跳过: 0
  通过率: 95.00%
  覆盖率: 85.50%
  执行时间: 12.34s
  测试文件数: 15
  源文件数: 50
  删除文件数: 2

================================================================================
总体统计
================================================================================
总执行时间: 12.34s
总体通过率: 95.00%
总体覆盖率: 85.50%
```

### JSON 格式

```json
{
  "project_name": "myproject",
  "generated_at": "2024-01-15T10:30:00",
  "total_duration": 12.34,
  "overall_pass_rate": 95.0,
  "overall_coverage": 85.5,
  "stats": [
    {
      "language": "python",
      "total_tests": 100,
      "passed_tests": 95,
      "failed_tests": 3,
      "error_tests": 2,
      "skipped_tests": 0,
      "pass_rate": 95.0,
      "coverage_rate": 85.5,
      "duration": 12.34
    }
  ]
}
```

## 各语言测试框架

### Python
- **测试框架**: pytest
- **覆盖率工具**: coverage.py
- **命令**: `python -m pytest --junitxml=report.xml`
- **JUnit XML**: pytest 原生支持

### Java
- **测试框架**: JUnit + Maven Surefire
- **覆盖率工具**: JaCoCo
- **命令**: `mvn test`, `mvn jacoco:report`
- **JUnit XML**: Maven Surefire 原生支持

### Go
- **测试框架**: testing
- **覆盖率工具**: go test -cover
- **命令**: `go test -v -coverprofile=coverage.out -json`
- **JUnit XML**: 使用 `go-junit-report` 或内置转换器

### C/C++
- **测试框架**: Google Test / CUnit
- **覆盖率工具**: gcov / lcov
- **命令**: `make test GTEST_XML_OUTPUT=1`
- **JUnit XML**: Google Test 原生支持 (`--gtest_output=xml:path`) 或内置转换器

## 完整工作流程

```
1. 环境检查
   └── 分析项目配置文件 (requirements.txt, pom.xml, go.mod 等)
   └── 检查编译和测试工具是否安装
   └── 提示缺失的依赖安装命令

2. 编译项目
   └── 尝试编译
   └── 失败 → 自动删除问题文件 → 重试 (最多10次)

3. 运行测试并生成 JUnit XML
   ├── Python: pytest --junitxml (原生支持)
   ├── Java: Maven Surefire (原生支持)
   ├── Go: go test -json → 转换为 JUnit XML
   └── C/C++: Google Test XML 或转换为 JUnit XML

4. 解析测试报告
   └── 提取失败和错误测试用例

5. 清理失败测试
   └── 删除失败的测试函数
   └── 重新运行测试验证
   └── 循环直到全部通过或达到最大迭代次数

6. 生成覆盖率报告
   └── Text / JSON / CSV / HTML 格式
```

## 统一错误处理

所有语言的测试输出都会转换为统一的 JUnit XML 格式：

```python
from junit_report_converter import JUnitReportConverter

# Go test JSON → JUnit XML
xml = JUnitReportConverter.convert_go_test(go_test_json)

# Google Test 文本 → JUnit XML
xml = JUnitReportConverter.convert_cpp_gtest(gtest_output, xml_path)

# 通用测试输出 → JUnit XML
xml = JUnitReportConverter.convert_generic_output(output, 'gtest')
```

## 配置文件

工具使用 `config.py` 中的配置，支持自定义各语言的测试命令：

```python
LANGUAGE_CONFIGS = {
    Language.PYTHON: CoverageConfig(
        language=Language.PYTHON,
        test_command="python -m pytest --junitxml={junit_output}",
        coverage_command="python -m coverage run --source={source} -m pytest",
        test_file_pattern="**/*test*.py",
        source_file_pattern="**/*.py"
    ),
    # ... 其他语言配置
}
```

## 高级用法

### 批量处理多个项目

```bash
#!/bin/bash
for lang in python java go cpp; do
    for dir in projects/*/; do
        python main.py -l $lang -t $dir -o ${dir}_report
    done
```

### CI/CD 集成

```yaml
# GitHub Actions 示例
name: Test Coverage

on: [push, pull_request]

jobs:
  coverage:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.9'
      - name: Run Coverage Tool
        run: |
          pip install -r requirements.txt
          python main.py -l python -t ./src -o coverage_report -f json
      - name: Upload Report
        uses: actions/upload-artifact@v2
        with:
          name: coverage-report
          path: coverage_report.json
```

## 故障排除

### 常见问题

**Q: 工具提示缺少依赖，但实际已安装?**
A: 工具会根据项目配置文件自动检测依赖，请检查项目的 requirements.txt 或 pom.xml 是否正确配置。

**Q: 编译失败但文件未被删除?**
A: 检查是否使用了 `--no-delete` 参数，或确认删除逻辑适用于你的文件类型。

**Q: 测试覆盖率显示为 0?**
A: 确保已安装对应的覆盖率工具（如 coverage.py、JaCoCo 等）。

**Q: 无法找到测试文件?**
A: 检查测试文件命名是否符合规范（`*test*.py`、`*Test.java` 等）。

**Q: 环境检查失败怎么办?**
A: 工具会显示缺失的依赖和安装命令，按提示安装即可。也可使用 `--no-delete` 跳过检查。

## 项目结构

```
coverage_tool/
├── main.py                    # 主入口
├── config.py                  # 语言配置
├── runners.py                 # 各语言运行器
├── junit_parser.py           # JUnit XML 解析器
├── junit_report_converter.py # JUnit XML 转换器
├── coverage_xml_parser.py    # 覆盖率XML解析器
├── dependency_analyzer.py    # 项目依赖分析器
├── env_checker.py            # 环境检查器
├── failed_test_remover.py    # 失败测试删除器（兼容层）
├── compilation_handler.py    # 编译失败处理器
├── reporter.py               # 报告生成器
├── test_removers/            # 测试删除器模块（重构后）
│   ├── __init__.py
│   ├── base.py               # 基类和通用逻辑
│   ├── factory.py            # 工厂类
│   ├── python_remover.py     # Python删除器
│   ├── java_remover.py       # Java删除器
│   ├── go_remover.py         # Go删除器
│   ├── c_remover.py          # C删除器
│   └── cpp_remover.py        # C++删除器
├── requirements.txt          # 依赖列表
└── __init__.py
```

### 架构说明

**v1.2.0 架构改进**：
- 将 `failed_test_remover.py`（1269行）重构为模块化结构
- 提取公共逻辑到 `base.py`，消除5处重复代码
- 各语言删除器现在继承基类，只实现特定逻辑
- 保持向后兼容，原有导入方式仍然有效

**推荐导入方式**（新）：
```python
from test_removers import SmartTestRemoverFactory
```

**向后兼容方式**（仍支持）：
```python
from failed_test_remover import SmartTestRemoverFactory
```

## 功能验证

所有模块已通过语法检查和导入测试：

```bash
# 检查所有Python文件语法
python3 -m py_compile *.py

# 测试各语言删除器（推荐新方式）
from test_removers import SmartTestRemoverFactory
for lang in SmartTestRemoverFactory.supported_languages():
    remover = SmartTestRemoverFactory.get_remover(lang, '/tmp')
    print(f'✓ {lang}: {type(remover).__name__}')

# 或保持向后兼容
from failed_test_remover import SmartTestRemoverFactory
```

## 版本历史

- **v1.2.0**: 重构架构，模块化测试删除器
  - 将 `failed_test_remover.py` 拆分为 `test_removers/` 包
  - 提取公共逻辑到基类，消除代码重复
  - 预编译正则表达式提升性能
  - 保持向后兼容
- **v1.1.0**: 添加智能环境检查和项目依赖分析
- **v1.0.0**: 初始版本，支持5种语言的基础功能

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！
