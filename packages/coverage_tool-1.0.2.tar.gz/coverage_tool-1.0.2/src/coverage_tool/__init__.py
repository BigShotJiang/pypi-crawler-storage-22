#!/usr/bin/env python3
"""
多语言单测覆盖率统计工具包
"""

__version__ = "1.0.0"
__author__ = "Coverage Tool"
