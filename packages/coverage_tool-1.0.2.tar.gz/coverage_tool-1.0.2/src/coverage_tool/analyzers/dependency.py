#!/usr/bin/env python3
"""
项目依赖分析器
根据项目配置文件智能分析所需的编译和测试环境
"""

import os
import re
import json
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import List, Dict, Set, Optional, Tuple
from pathlib import Path
from enum import Enum

class DependencyType(Enum):
    """依赖类型"""
    PYTHON_PACKAGE = "python_package"
    JAVA_PACKAGE = "java_package"
    GO_MODULE = "go_module"
    NODE_PACKAGE = "node_package"
    BUILD_TOOL = "build_tool"
    COMPILER = "compiler"
    TEST_FRAMEWORK = "test_framework"
    COVERAGE_TOOL = "coverage_tool"

@dataclass
class Dependency:
    """依赖项"""
    name: str
    type: DependencyType
    version: Optional[str] = None
    required: bool = True
    installed: bool = False
    installed_version: Optional[str] = None

@dataclass
class ProjectAnalysis:
    """项目分析结果"""
    project_dir: str
    language: str
    dependencies: List[Dependency] = field(default_factory=list)
    build_system: Optional[str] = None
    test_framework: Optional[str] = None
    coverage_tool: Optional[str] = None
    missing_dependencies: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

class DependencyAnalyzer:
    """依赖分析器"""

    # 各语言的配置文件映射
    CONFIG_PATTERNS = {
        'python': [
            ('requirements.txt', 'pip'),
            ('setup.py', 'pip'),
            ('pyproject.toml', 'pip'),
            ('Pipfile', 'pip'),
            ('setup.cfg', 'pip'),
        ],
        'java': [
            ('pom.xml', 'maven'),
            ('build.gradle', 'gradle'),
            ('build.gradle.kts', 'gradle'),
            ('pom.xml', 'java'),
        ],
        'go': [
            ('go.mod', 'go'),
            ('go.sum', 'go'),
        ],
        'c': [
            ('Makefile', 'make'),
            ('CMakeLists.txt', 'cmake'),
            ('*.mk', 'make'),
        ],
        'cpp': [
            ('Makefile', 'make'),
            ('CMakeLists.txt', 'cmake'),
            ('*.cmake', 'cmake'),
        ],
    }

    # 关键依赖检测 (只检查系统级工具，不检查库依赖)
    KEY_DEPENDENCIES = {
        'python': [
            ('python', DependencyType.COMPILER),
        ],
        'java': [
            ('java', DependencyType.COMPILER),
            ('maven', DependencyType.BUILD_TOOL),
        ],
        'go': [
            ('go', DependencyType.COMPILER),
        ],
        'c': [
            ('gcc', DependencyType.COMPILER),
            ('make', DependencyType.BUILD_TOOL),
        ],
        'cpp': [
            ('g++', DependencyType.COMPILER),
            ('make', DependencyType.BUILD_TOOL),
        ],
    }

    def __init__(self, project_dir: str):
        self.project_dir = project_dir
        self.analysis: Optional[ProjectAnalysis] = None

    def analyze(self, language: str) -> ProjectAnalysis:
        """分析项目依赖"""
        self.analysis = ProjectAnalysis(
            project_dir=self.project_dir,
            language=language
        )

        # 查找配置文件
        self._find_config_files(language)

        # 确保analysis不为None
        if self.analysis is None:
            self.analysis = ProjectAnalysis(
                project_dir=self.project_dir,
                language=language
            )

        # 分析具体配置文件
        self._parse_config_files(language)

        # 检查关键依赖
        self._check_key_dependencies(language)

        return self.analysis

    def _find_config_files(self, language: str):
        """查找配置文件"""
        if self.analysis is None:
            return
        patterns = self.CONFIG_PATTERNS.get(language, [])

        for pattern, build_system in patterns:
            if '*' in pattern:
                # 匹配通配符
                files = Path(self.project_dir).glob(pattern)
                for f in files:
                    self.analysis.build_system = build_system
            else:
                # 精确匹配
                config_path = os.path.join(self.project_dir, pattern)
                if os.path.exists(config_path):
                    self.analysis.build_system = build_system
                    break

    def _parse_config_files(self, language: str):
        """解析配置文件"""
        project_path = Path(self.project_dir)

        if language == 'python':
            self._parse_python_configs(project_path)
        elif language == 'java':
            self._parse_java_configs(project_path)
        elif language == 'go':
            self._parse_go_configs(project_path)
        elif language in ['c', 'cpp']:
            self._parse_c_cpp_configs(project_path)

    def _parse_python_configs(self, project_path: Path):
        """解析Python配置文件"""
        # requirements.txt
        req_file = project_path / 'requirements.txt'
        if req_file.exists():
            self._parse_requirements(req_file)

        # setup.py
        setup_file = project_path / 'setup.py'
        if setup_file.exists():
            self._parse_setup_py(setup_file)

        # pyproject.toml
        pyproject_file = project_path / 'pyproject.toml'
        if pyproject_file.exists():
            self._parse_pyproject_toml(pyproject_file)

    def _parse_requirements(self, file_path: Path):
        """解析requirements.txt"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        # 解析版本要求
                        name, version = self._parse_package_line(line)
                        dep = Dependency(
                            name=name,
                            type=DependencyType.PYTHON_PACKAGE,
                            version=version,
                            required=False
                        )
                        self.analysis.dependencies.append(dep)
        except Exception as e:
            self.analysis.warnings.append(f"无法解析 requirements.txt: {e}")

    def _parse_setup_py(self, file_path: Path):
        """解析setup.py"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 查找install_requires
            match = re.search(r'install_requires\s*=\s*\[(.*?)\]', content, re.DOTALL)
            if match:
                deps_str = match.group(1)
                for line in deps_str.split('\n'):
                    line = line.strip().strip("'\"")
                    if line and line.startswith('['):
                        line = line.strip('[]')
                    if line:
                        name, version = self._parse_package_line(line)
                        dep = Dependency(
                            name=name,
                            type=DependencyType.PYTHON_PACKAGE,
                            version=version,
                            required=False
                        )
                        self.analysis.dependencies.append(dep)

            # 查找test_requires
            match = re.search(r'test_requires\s*=\s*\[(.*?)\]', content, re.DOTALL)
            if match:
                deps_str = match.group(1)
                for line in deps_str.split('\n'):
                    line = line.strip().strip("'\"")
                    if line and line.startswith('['):
                        line = line.strip('[]')
                    if line:
                        name, version = self._parse_package_line(line)
                        dep = Dependency(
                            name=name,
                            type=DependencyType.TEST_FRAMEWORK,
                            version=version,
                            required=False
                        )
                        self.analysis.test_framework = name
                        self.analysis.dependencies.append(dep)
        except Exception as e:
            self.analysis.warnings.append(f"无法解析 setup.py: {e}")

    def _parse_pyproject_toml(self, file_path: Path):
        """解析pyproject.toml"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 查找测试依赖
            match = re.search(r'\[tool\.pytest\]', content)
            if match:
                self.analysis.test_framework = 'pytest'

            # 查找依赖
            match = re.search(r'dependencies\s*=\s*\[(.*?)\]', content, re.DOTALL)
            if match:
                deps_str = match.group(1)
                for line in deps_str.split('\n'):
                    line = line.strip().strip("'\"")
                    if line:
                        name, version = self._parse_package_line(line)
                        dep = Dependency(
                            name=name,
                            type=DependencyType.PYTHON_PACKAGE,
                            version=version,
                            required=False
                        )
                        self.analysis.dependencies.append(dep)
        except Exception as e:
            self.analysis.warnings.append(f"无法解析 pyproject.toml: {e}")

    def _parse_package_line(self, line: str) -> Tuple[str, Optional[str]]:
        """解析包名和版本"""
        line = line.strip()
        if '>=' in line:
            name, version = line.split('>=')
            return name.strip(), f">={version.strip()}"
        elif '<=' in line:
            name, version = line.split('<=')
            return name.strip(), f"<={version.strip()}"
        elif '==' in line:
            name, version = line.split('==')
            return name.strip(), version.strip()
        elif '>' in line:
            name, version = line.split('>')
            return name.strip(), f">{version.strip()}"
        elif '<' in line:
            name, version = line.split('<')
            return name.strip(), f"<{version.strip()}"
        else:
            return line, None

    def _parse_java_configs(self, project_path: Path):
        """解析Java配置文件"""
        pom_file = project_path / 'pom.xml'
        if pom_file.exists():
            try:
                tree = ET.parse(pom_file)
                root = tree.getroot()

                # 解析命名空间
                ns = {'m': 'http://maven.apache.org/POM/4.0.0'}

                # 获取坐标
                group_id = root.find('m:groupId', ns) or root.find('groupId')
                artifact_id = root.find('m:artifactId', ns) or root.find('artifactId')
                version = root.find('m:version', ns) or root.find('version')

                if artifact_id is not None:
                    self.analysis.build_system = 'maven'

                # 查找测试依赖
                for dep in root.findall('.//m:dependency', ns):
                    dep_group = dep.find('m:groupId', ns) or dep.find('groupId')
                    dep_artifact = dep.find('m:artifactId', ns) or dep.find('artifactId')
                    dep_version = dep.find('m:version', ns) or dep.find('version')

                    if dep_artifact is not None:
                        dep_name = dep_artifact.text or ""
                        is_test = False

                        # 检查是否是测试依赖
                        for scope in dep.findall('m:scope', ns) or dep.findall('scope'):
                            if scope.text == 'test':
                                is_test = True
                                break

                        # 检查测试框架
                        test_frameworks = ['junit', 'testng', 'mockito', 'assertj']
                        if any(tf in dep_name.lower() for tf in test_frameworks):
                            self.analysis.test_framework = dep_name

                        dep_type = DependencyType.TEST_FRAMEWORK if is_test else DependencyType.JAVA_PACKAGE
                        dep = Dependency(
                            name=dep_name,
                            type=dep_type,
                            version=dep_version.text if dep_version is not None else None,
                            required=False
                        )
                        self.analysis.dependencies.append(dep)

            except Exception as e:
                self.analysis.warnings.append(f"无法解析 pom.xml: {e}")

    def _parse_go_configs(self, project_path: Path):
        """解析Go配置文件"""
        go_mod_file = project_path / 'go.mod'
        if go_mod_file.exists():
            try:
                with open(go_mod_file, 'r', encoding='utf-8') as f:
                    content = f.read()

                # 查找go.mod版本
                match = re.search(r'go\s+(\d+\.\d+)', content)
                if match:
                    self.analysis.build_system = f"go {match.group(1)}"

                # 查找测试框架
                test_imports = ['testing', 'testify', 'goconvey', 'gocheck']
                for line in content.split('\n'):
                    if 'require' in line.lower():
                        for test_pkg in test_imports:
                            if test_pkg in line.lower():
                                self.analysis.test_framework = test_pkg
                                break

            except Exception as e:
                self.analysis.warnings.append(f"无法解析 go.mod: {e}")

    def _parse_c_cpp_configs(self, project_path: Path):
        """解析C/C++配置文件"""
        # 检查Makefile
        makefile = project_path / 'Makefile'
        if makefile.exists():
            self.analysis.build_system = 'make'
            with open(makefile, 'r', encoding='utf-8') as f:
                content = f.read()

                # 检查测试框架
                if 'gtest' in content.lower() or 'googletest' in content.lower():
                    self.analysis.test_framework = 'googletest'
                elif 'catch' in content.lower():
                    self.analysis.test_framework = 'catch2'
                elif 'unity' in content.lower():
                    self.analysis.test_framework = 'unity'

        # 检查CMakeLists.txt
        cmake_file = project_path / 'CMakeLists.txt'
        if cmake_file.exists() and not self.analysis.build_system:
            self.analysis.build_system = 'cmake'

            with open(cmake_file, 'r', encoding='utf-8') as f:
                content = f.read()

                # 检查测试框架
                if 'GoogleTest' in content or 'gtest' in content.lower():
                    self.analysis.test_framework = 'googletest'
                elif 'Catch' in content:
                    self.analysis.test_framework = 'catch2'

    def _check_key_dependencies(self, language: str):
        """检查关键依赖是否安装"""
        key_deps = self.KEY_DEPENDENCIES.get(language, [])

        for dep_name, dep_type in key_deps:
            dep = Dependency(
                name=dep_name,
                type=dep_type,
                required=True
            )

            # 检查是否已安装
            installed, version = self._check_dependency_installed(dep_name, language)
            dep.installed = installed
            dep.installed_version = version

            self.analysis.dependencies.append(dep)

            if not installed:
                self.analysis.missing_dependencies.append(dep_name)

    def _check_dependency_installed(self, dep_name: str, language: str) -> Tuple[bool, Optional[str]]:
        """检查依赖是否已安装"""
        import subprocess

        commands = {
            'python': f'python3 --version 2>&1',
            'java': f'java -version 2>&1',
            'go': f'go version',
            'gcc': f'gcc --version',
            'g++': f'g++ --version',
            'make': f'make --version',
            'maven': f'mvn -version',
        }

        cmd = commands.get(dep_name)
        if cmd:
            try:
                result = subprocess.run(
                    cmd,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=5
                )

                if result.returncode == 0:
                    # 尝试提取版本
                    output = result.stdout or result.stderr
                    version_match = re.search(r'(\d+\.\d+\.?\d*)', output)
                    version = version_match.group(1) if version_match else None
                    return True, version
            except:
                pass

        return False, None

    def get_installation_suggestions(self) -> List[str]:
        """获取安装建议"""
        suggestions = []

        if not self.analysis:
            return suggestions

        dep_mapping = {
            'pytest': {
                'command': 'pip install pytest',
                'description': 'Python测试框架'
            },
            'coverage': {
                'command': 'pip install coverage',
                'description': 'Python覆盖率工具'
            },
            'tox': {
                'command': 'pip install tox',
                'description': 'Python自动化测试工具'
            },
            'maven': {
                'command': 'apt install maven  # Ubuntu/Debian\nbrew install maven  # macOS',
                'description': 'Java构建工具'
            },
            'gcc': {
                'command': 'apt install gcc  # Ubuntu/Debian\nbrew install gcc  # macOS',
                'description': 'C/C++编译器'
            },
            'g++': {
                'command': 'apt install g++  # Ubuntu/Debian\nbrew install gcc  # macOS',
                'description': 'C++编译器'
            },
            'make': {
                'command': 'apt install make  # Ubuntu/Debian\nbrew install make  # macOS',
                'description': '构建工具'
            },
            'lcov': {
                'command': 'apt install lcov  # Ubuntu/Debian',
                'description': '代码覆盖率工具'
            },
            'googletest': {
                'command': 'apt install libgtest-dev cmake\ncd /usr/src/gtest && cmake . && make && cp *.a /usr/lib/',
                'description': 'C++测试框架'
            },
        }

        for dep_name in self.analysis.missing_dependencies:
            if dep_name in dep_mapping:
                info = dep_mapping[dep_name]
                suggestions.append(f"{dep_name}: {info['description']}\n  安装: {info['command']}")

        return suggestions
