#!/usr/bin/env python3
"""
JUnit XML 报告转换器包
将各种格式的测试输出转换为统一的 JUnit XML 格式
"""

from typing import List, Optional

from .base import TestCaseResult, TestSuiteResult, BaseConverter
from .go_converter import GoTestConverter, GoJUnitReportTool
from .gtest_converter import GTestConverter
from .cunit_converter import CUnitConverter
from .generic_converter import GenericConverter
from .factory import ConverterFactory


# 保持向后兼容的 JUnitReportConverter 类
class JUnitReportConverter(BaseConverter):
    """JUnit XML 报告转换器 (向后兼容)"""
    
    @staticmethod
    def convert_go_test(go_test_output: str, coverage_out: Optional[str] = None) -> str:
        """将 Go test JSON 输出转换为 JUnit XML"""
        return GoTestConverter.convert(go_test_output, coverage_out)

    @staticmethod
    def convert_cpp_gtest(gtest_output: str, xml_path: str) -> str:
        """转换 Google Test 输出为 JUnit XML"""
        return GTestConverter.convert(gtest_output, xml_path)

    @staticmethod
    def convert_cunit(cunit_output: str) -> str:
        """转换 CUnit 输出为 JUnit XML"""
        return CUnitConverter.convert(cunit_output)

    @staticmethod
    def convert_generic_output(output: str, test_framework: str) -> str:
        """通用测试输出转换"""
        return GenericConverter.convert(output, test_framework)


# 保持向后兼容的 GoJUnitReport 类
class GoJUnitReport(GoJUnitReportTool):
    """Go 测试 JUnit 报告生成器 (向后兼容)"""
    pass


__all__ = [
    'TestCaseResult',
    'TestSuiteResult',
    'BaseConverter',
    'GoTestConverter',
    'GoJUnitReportTool',
    'GTestConverter',
    'CUnitConverter',
    'GenericConverter',
    'ConverterFactory',
    'JUnitReportConverter',
    'GoJUnitReport',
]
