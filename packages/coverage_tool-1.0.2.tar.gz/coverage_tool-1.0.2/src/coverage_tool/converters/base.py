#!/usr/bin/env python3
"""
JUnit XML 报告转换器 - 基础模块
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class TestCaseResult:
    """测试用例结果"""
    name: str
    classname: str
    time: float
    passed: bool = True
    failed_message: Optional[str] = None
    failed_type: Optional[str] = None
    error_message: Optional[str] = None
    error_type: Optional[str] = None
    skipped: bool = False
    skipped_message: Optional[str] = None


@dataclass
class TestSuiteResult:
    """测试套件结果"""
    name: str
    tests: int = 0
    failures: int = 0
    errors: int = 0
    skipped: int = 0
    time: float = 0.0
    test_cases: List[TestCaseResult] = field(default_factory=list)


class BaseConverter:
    """报告转换器基类"""
    
    @staticmethod
    def _create_junit_xml(suite_name: str, test_cases: List[TestCaseResult],
                          total_time: float) -> str:
        """创建 JUnit XML"""
        tests = len(test_cases)
        failures = sum(1 for tc in test_cases if not tc.passed and not tc.skipped)
        errors = sum(1 for tc in test_cases if not tc.passed and tc.skipped)
        skipped = sum(1 for tc in test_cases if tc.skipped)

        lines = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            f'<testsuites name="Test Results" tests="{tests}" failures="{failures}" errors="{errors}" skipped="{skipped}">',
            f'  <testsuite name="{suite_name}" tests="{tests}" failures="{failures}" errors="{errors}" skipped="{skipped}" time="{total_time:.3f}">',
        ]

        for case in test_cases:
            status_attr = ''
            content = ''

            if case.skipped:
                status_attr = f' status="skipped"'
                content = f'    <skipped message="{case.skipped_message or ""}"/>'
            elif not case.passed:
                status_attr = f' status="failure"'
                if case.failed_message:
                    content = f'    <failure message="{case.failed_message}" type="{case.failed_type or "failure"}"/>'
                elif case.error_message:
                    content = f'    <error message="{case.error_message}" type="{case.error_type or "error"}"/>'

            lines.append(f'    <testcase name="{case.name}" classname="{case.classname}" time="{case.time:.3f}"{status_attr}>')
            lines.append(content)
            lines.append(f'    </testcase>')

        lines.extend([
            '  </testsuite>',
            '</testsuites>'
        ])

        return '\n'.join(lines)

    @staticmethod
    def _create_basic_junit_xml(suite_name: str, test_cases: List[TestCaseResult]) -> str:
        """创建基本的 JUnit XML (用于错误情况)"""
        return BaseConverter._create_junit_xml(suite_name, test_cases, 0.0)
