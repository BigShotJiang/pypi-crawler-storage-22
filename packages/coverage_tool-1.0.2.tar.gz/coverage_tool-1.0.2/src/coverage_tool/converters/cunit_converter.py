#!/usr/bin/env python3
"""
CUnit 测试输出转换器
"""

import re

from .base import BaseConverter, TestCaseResult


class CUnitConverter(BaseConverter):
    """CUnit 测试输出转换器"""

    @staticmethod
    def convert(cunit_output: str) -> str:
        """转换 CUnit 输出为 JUnit XML"""
        test_cases = []

        # CUnit 输出解析
        pattern = re.compile(
            r'(PASS|FAIL|SKIP):\s+(\w+)\s+\(([^)]+)\)',
            re.MULTILINE
        )

        for match in pattern.finditer(cunit_output):
            status, name, message = match.groups()

            case = TestCaseResult(
                name=name,
                classname="cunit",
                time=0.0,
                passed=status == 'PASS',
                skipped=status == 'SKIP'
            )

            if status == 'FAIL':
                case.passed = False
                case.failed_message = message
                case.failed_type = 'failure'

            test_cases.append(case)

        return CUnitConverter._create_junit_xml(
            "CUnit Tests",
            test_cases,
            0.0
        )
