#!/usr/bin/env python3
"""
转换器工厂
"""

from typing import Dict, Type

from .base import BaseConverter
from .go_converter import GoTestConverter
from .gtest_converter import GTestConverter
from .cunit_converter import CUnitConverter
from .generic_converter import GenericConverter


class ConverterFactory:
    """转换器工厂"""

    _converters: Dict[str, Type[BaseConverter]] = {
        'go': GoTestConverter,
        'gtest': GTestConverter,
        'google': GTestConverter,
        'cunit': CUnitConverter,
    }

    @classmethod
    def get_converter(cls, test_framework: str):
        """获取对应测试框架的转换器"""
        converter_class = cls._converters.get(test_framework)
        if converter_class is None:
            return GenericConverter
        return converter_class

    @classmethod
    def register_converter(cls, test_framework: str, converter_class: type):
        """注册新的转换器"""
        cls._converters[test_framework] = converter_class
