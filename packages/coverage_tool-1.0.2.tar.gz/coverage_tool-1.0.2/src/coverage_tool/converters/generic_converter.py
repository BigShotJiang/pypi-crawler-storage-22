#!/usr/bin/env python3
"""
通用测试输出转换器
"""

import re
from typing import List

from .base import BaseConverter, TestCaseResult
from .go_converter import GoTestConverter
from .gtest_converter import GTestConverter
from .cunit_converter import CUnitConverter


class GenericConverter(BaseConverter):
    """通用测试输出转换器"""

    @staticmethod
    def convert(output: str, test_framework: str) -> str:
        """通用测试输出转换"""
        test_cases: List[TestCaseResult] = []

        if test_framework == 'go':
            return GoTestConverter.convert(output)
        elif test_framework in ['gtest', 'google']:
            return GTestConverter.convert(output, '')
        elif test_framework == 'cunit':
            return CUnitConverter.convert(output)

        # 通用解析：查找 PASS/FAIL 模式
        patterns = {
            'PASS': r'PASS:\s+(\w+)',
            'FAIL': r'FAIL:\s+(\w+)',
            'OK': r'OK\s+-\s+(\w+)',
            'ERROR': r'ERROR\s+-\s+(\w+)',
        }

        passed_tests = []
        failed_tests = []

        for status, pattern in patterns.items():
            matches = re.findall(pattern, output)
            if 'PASS' in status:
                passed_tests.extend(matches)
            elif 'FAIL' in status or 'ERROR' in status:
                failed_tests.extend(matches)

        test_cases.extend([
            TestCaseResult(name=name, classname="test", time=0.0, passed=True)
            for name in passed_tests
        ])
        test_cases.extend([
            TestCaseResult(name=name, classname="test", time=0.0, passed=False,
                          failed_message="Test failed", failed_type='failure')
            for name in failed_tests
        ])

        return GenericConverter._create_junit_xml(
            f"{test_framework.title()} Tests",
            test_cases,
            0.0
        )
