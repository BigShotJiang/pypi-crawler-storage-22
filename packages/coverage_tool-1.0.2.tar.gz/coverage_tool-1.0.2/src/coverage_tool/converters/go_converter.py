#!/usr/bin/env python3
"""
Go 测试输出转换器
"""

import json
import subprocess
import os
from typing import Optional

from .base import BaseConverter, TestCaseResult


class GoTestConverter(BaseConverter):
    """Go 测试输出转换器"""

    @staticmethod
    def convert(go_test_output: str, coverage_out: Optional[str] = None) -> str:
        """将 Go test JSON 输出转换为 JUnit XML"""
        test_cases = []
        total_time = 0.0
        current_test = {}

        try:
            # Go test JSON 输出是 NDJSON 格式（每行一个JSON对象）
            for line in go_test_output.strip().split('\n'):
                if not line.strip():
                    continue
                data = json.loads(line)
                event = data.get('Action', '')  # Go test 使用 Action 字段

                # 处理测试开始/运行事件
                if event in ['start', 'run']:
                    test_name = data.get('Test', '')
                    if isinstance(test_name, dict):
                        test_name = test_name.get('Name', '')
                    if test_name:
                        current_test = {
                            'name': test_name,
                            'package': data.get('Package', 'main'),
                            'elapsed': data.get('Elapsed', 0),
                        }

                # 处理测试结果
                elif event == 'pass':
                    if current_test.get('name'):
                        case = TestCaseResult(
                            name=current_test['name'],
                            classname=current_test.get('package', 'main'),
                            time=float(current_test.get('elapsed', 0)),
                            passed=True
                        )
                        test_cases.append(case)
                        total_time += case.time
                    current_test = {}

                # 处理测试失败
                elif event == 'fail':
                    if current_test.get('name'):
                        case = TestCaseResult(
                            name=current_test['name'],
                            classname=current_test.get('package', 'main'),
                            time=float(current_test.get('elapsed', 0)),
                            passed=False,
                            failed_message=data.get('Output', 'Test failed'),
                            failed_type='failure'
                        )
                        test_cases.append(case)
                        total_time += case.time
                    current_test = {}

                # 处理测试跳过
                elif event == 'skip':
                    if current_test.get('name'):
                        case = TestCaseResult(
                            name=current_test['name'],
                            classname=current_test.get('package', 'main'),
                            time=float(current_test.get('elapsed', 0)),
                            skipped=True,
                            skipped_message=data.get('Skip', '')
                        )
                        test_cases.append(case)
                        total_time += case.time
                    current_test = {}

        except json.JSONDecodeError:
            return GoTestConverter._create_basic_junit_xml(
                "Go Test",
                [TestCaseResult(name="Parse Error", classname="go_test", time=0, passed=False,
                               failed_message="Failed to parse test output")]
            )

        return GoTestConverter._create_junit_xml(
            "Go Tests",
            test_cases,
            total_time
        )


class GoJUnitReportTool:
    """Go 测试 JUnit 报告工具"""

    @staticmethod
    def ensure_tool_installed() -> bool:
        """确保 go-junit-report 工具已安装"""
        # 检查是否已安装
        result = subprocess.run(
            ["which", "go-junit-report"],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            return True

        # 尝试安装
        print("正在安装 go-junit-report...")
        install_result = subprocess.run(
            ["go", "install", "github.com/jstemmer/go-junit-report@latest"],
            capture_output=True,
            text=True,
            timeout=120
        )

        if install_result.returncode == 0:
            # 添加到 PATH
            go_path = subprocess.run(
                ["go", "env", "GOPATH"],
                capture_output=True,
                text=True
            ).stdout.strip()

            gopath_bin = os.path.join(go_path, "bin")
            if gopath_bin not in os.environ.get('PATH', ''):
                os.environ['PATH'] = f"{gopath_bin}:{os.environ.get('PATH', '')}"

            print("✓ go-junit-report 安装成功")
            return True
        else:
            print(f"✗ go-junit-report 安装失败: {install_result.stderr}")
            return False

    @staticmethod
    def generate_report(go_test_output: str, xml_path: str) -> bool:
        """使用 go-junit-report 生成报告"""
        # 先确保工具已安装
        if not GoJUnitReportTool.ensure_tool_installed():
            return False

        try:
            report_cmd = [
                "go-junit-report",
                "-xmlout", xml_path
            ]

            result = subprocess.run(
                report_cmd,
                input=go_test_output,
                capture_output=True,
                text=True,
                timeout=60
            )

            if result.returncode == 0 and os.path.exists(xml_path):
                return True

            if result.returncode != 0:
                print(f"go-junit-report 错误: {result.stderr}")
        except FileNotFoundError:
            print("go-junit-report 未找到，尝试使用内置转换...")
        except Exception as e:
            print(f"go-junit-report 执行错误: {e}")

        return False

    @staticmethod
    def manual_convert(go_test_output: str, xml_path: str) -> str:
        """手动将 Go test 输出转换为 JUnit XML（备用方案）"""
        return GoTestConverter.convert(go_test_output)
