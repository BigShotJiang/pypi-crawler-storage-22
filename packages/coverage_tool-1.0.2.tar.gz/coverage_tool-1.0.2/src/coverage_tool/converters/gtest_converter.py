#!/usr/bin/env python3
"""
Google Test 输出转换器
"""

import os
import re

from .base import BaseConverter, TestCaseResult


class GTestConverter(BaseConverter):
    """Google Test 输出转换器"""

    @staticmethod
    def convert(gtest_output: str, xml_path: str) -> str:
        """转换 Google Test 输出为 JUnit XML"""
        # Google Test 支持直接输出 XML
        # 如果已经有 XML 文件，直接返回
        if os.path.exists(xml_path):
            with open(xml_path, 'r', encoding='utf-8') as f:
                return f.read()

        # 解析文本输出
        test_cases = []
        total_time = 0.0

        # Google Test 输出格式解析
        pattern = re.compile(
            r'\[(?:PASSED|FAILED|SKIPPED)\]\s+(?:\[.*?\]\s+)?(\w+)\s+\(([^)]+)\)',
            re.MULTILINE
        )

        for match in pattern.finditer(gtest_output):
            status = match.group(0)
            name = match.group(1)
            details = match.group(2)

            case = TestCaseResult(
                name=name,
                classname="gtest",
                time=0.0,
                passed="PASSED" in status,
                skipped="SKIPPED" in status
            )

            if "PASSED" in status:
                case.passed = True
            elif "FAILED" in status:
                case.passed = False
                case.failed_message = details
                case.failed_type = 'failure'
            elif "SKIPPED" in status:
                case.skipped = True
                case.skipped_message = details

            test_cases.append(case)

        return GTestConverter._create_junit_xml(
            "Google Tests",
            test_cases,
            total_time
        )
