#!/usr/bin/env python3
"""
多语言单测统计工具配置
支持 Python, Java, Go, C, C++
"""

from dataclasses import dataclass
from typing import List, Dict, Optional
from enum import Enum

class Language(Enum):
    PYTHON = "python"
    JAVA = "java"
    GO = "go"
    C = "c"
    CPP = "cpp"

@dataclass
class CoverageConfig:
    """单测覆盖率配置"""
    language: Language
    test_command: str
    coverage_command: str
    test_file_pattern: str
    source_file_pattern: str
    output_format: str = "junit"
    coverage_output: str = "coverage.xml"

# 各语言配置
LANGUAGE_CONFIGS: Dict[Language, CoverageConfig] = {
    Language.PYTHON: CoverageConfig(
        language=Language.PYTHON,
        test_command="python -m pytest --junitxml={junit_output}",
        coverage_command="python -m coverage run --source={source} -m pytest --junitxml={junit_output}",
        test_file_pattern="**/*test*.py",
        source_file_pattern="**/*.py"
    ),
    Language.JAVA: CoverageConfig(
        language=Language.JAVA,
        test_command="mvn test -Dreport=XML",
        coverage_command="mvn test jacoco:report -Dreport=XML",
        test_file_pattern="**/*Test.java",
        source_file_pattern="**/*.java"
    ),
    Language.GO: CoverageConfig(
        language=Language.GO,
        test_command="go test -v -cover -coverprofile=coverage.out {packages}",
        coverage_command="go test -v -cover -coverprofile=coverage.out {packages}",
        test_file_pattern="**/*_test.go",
        source_file_pattern="**/*.go"
    ),
    Language.C: CoverageConfig(
        language=Language.C,
        test_command="make test",
        coverage_command="make coverage",
        test_file_pattern="**/test_*.c,**/*_test.c,**/*test*.c,**/check_*.c,**/tests/*.c",
        source_file_pattern="**/*.c"
    ),
    Language.CPP: CoverageConfig(
        language=Language.CPP,
        test_command="make test",
        coverage_command="make coverage",
        test_file_pattern="**/test_*.cpp,**/*_test.cpp,**/*test*.cpp,**/Test*.cpp,**/*.test.cpp,**/*.cc",
        source_file_pattern="**/*.cpp,**/*.cc,**/*.hpp"
    )
}
