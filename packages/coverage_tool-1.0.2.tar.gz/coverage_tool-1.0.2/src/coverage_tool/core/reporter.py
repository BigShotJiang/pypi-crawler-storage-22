#!/usr/bin/env python3
"""
覆盖率统计报告生成器
生成格式化的测试覆盖率报告
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
from datetime import datetime
from enum import Enum
import json
import csv
import os

class ReportFormat(Enum):
    TEXT = "text"
    JSON = "json"
    CSV = "csv"
    HTML = "html"

@dataclass
class CoverageStats:
    """覆盖率统计"""
    language: str
    total_tests: int = 0
    passed_tests: int = 0
    failed_tests: int = 0
    error_tests: int = 0
    skipped_tests: int = 0
    pass_rate: float = 0.0
    coverage_rate: float = 0.0
    duration: float = 0.0
    test_files: int = 0
    source_files: int = 0
    deleted_files: int = 0

@dataclass
class CoverageReport:
    """完整覆盖率报告"""
    project_name: str
    generated_at: datetime = field(default_factory=datetime.now)
    stats: List[CoverageStats] = field(default_factory=list)
    total_duration: float = 0.0
    overall_pass_rate: float = 0.0
    overall_coverage: float = 0.0
    deleted_files: List[str] = field(default_factory=list)

    def calculate_overall_stats(self):
        """计算总体统计"""
        if not self.stats:
            return

        total_tests = sum(s.total_tests for s in self.stats)
        total_passed = sum(s.passed_tests for s in self.stats)
        total_failed = sum(s.failed_tests for s in self.stats)
        total_errors = sum(s.error_tests for s in self.stats)
        total_skipped = sum(s.skipped_tests for s in self.stats)
        total_coverage = sum(s.coverage_rate for s in self.stats)
        self.total_duration = sum(s.duration for s in self.stats)

        if total_tests > 0:
            self.overall_pass_rate = ((total_passed / total_tests) * 100) if total_tests > 0 else 0.0
        else:
            self.overall_pass_rate = 0.0

        self.overall_coverage = (total_coverage / len(self.stats)) if self.stats else 0.0

        for stat in self.stats:
            self.deleted_files.extend([stat.language] * stat.deleted_files)

class CoverageReporter:
    """覆盖率报告生成器"""

    def __init__(self, report: CoverageReport):
        self.report = report

    def generate(self, output_file: str, format: ReportFormat = ReportFormat.TEXT) -> str:
        """生成报告"""
        if format == ReportFormat.JSON:
            return self._generate_json(output_file)
        elif format == ReportFormat.CSV:
            return self._generate_csv(output_file)
        elif format == ReportFormat.HTML:
            return self._generate_html(output_file)
        else:
            return self._generate_text(output_file)

    def _generate_text(self, output_file: str) -> str:
        """生成文本报告"""
        lines = []
        lines.append("=" * 80)
        lines.append(f"单测覆盖率报告")
        lines.append(f"项目: {self.report.project_name}")
        lines.append(f"生成时间: {self.report.generated_at.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("=" * 80)
        lines.append("")

        for stat in self.report.stats:
            lines.append(f"语言: {stat.language}")
            lines.append("-" * 40)
            lines.append(f"  测试用例数: {stat.total_tests}")
            lines.append(f"  通过: {stat.passed_tests}")
            lines.append(f"  失败: {stat.failed_tests}")
            lines.append(f"  错误: {stat.error_tests}")
            lines.append(f"  跳过: {stat.skipped_tests}")
            lines.append(f"  通过率: {stat.pass_rate:.2f}%")
            lines.append(f"  覆盖率: {stat.coverage_rate:.2f}%")
            lines.append(f"  执行时间: {stat.duration:.2f}s")
            lines.append(f"  测试文件数: {stat.test_files}")
            lines.append(f"  源文件数: {stat.source_files}")
            lines.append(f"  删除文件数: {stat.deleted_files}")
            lines.append("")

        lines.append("=" * 80)
        lines.append("总体统计")
        lines.append("=" * 80)
        lines.append(f"总执行时间: {self.report.total_duration:.2f}s")
        lines.append(f"总体通过率: {self.report.overall_pass_rate:.2f}%")
        lines.append(f"总体覆盖率: {self.report.overall_coverage:.2f}%")
        lines.append("")

        if self.report.deleted_files:
            lines.append(f"已删除文件: {len(self.report.deleted_files)}个")

        report_content = '\n'.join(lines)

        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(report_content)

        return report_content

    def _generate_json(self, output_file: str) -> str:
        """生成JSON报告"""
        report_data = {
            "project_name": self.report.project_name,
            "generated_at": self.report.generated_at.isoformat(),
            "total_duration": self.report.total_duration,
            "overall_pass_rate": self.report.overall_pass_rate,
            "overall_coverage": self.report.overall_coverage,
            "stats": [
                {
                    "language": stat.language,
                    "total_tests": stat.total_tests,
                    "passed_tests": stat.passed_tests,
                    "failed_tests": stat.failed_tests,
                    "error_tests": stat.error_tests,
                    "skipped_tests": stat.skipped_tests,
                    "pass_rate": stat.pass_rate,
                    "coverage_rate": stat.coverage_rate,
                    "duration": stat.duration,
                    "test_files": stat.test_files,
                    "source_files": stat.source_files,
                    "deleted_files": stat.deleted_files
                }
                for stat in self.report.stats
            ]
        }

        report_content = json.dumps(report_data, ensure_ascii=False, indent=2)

        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(report_content)

        return report_content

    def _generate_csv(self, output_file: str) -> str:
        """生成CSV报告"""
        lines = []
        headers = [
            "语言", "测试用例数", "通过", "失败", "错误", "跳过",
            "通过率", "覆盖率", "执行时间", "测试文件数", "源文件数", "删除文件数"
        ]
        lines.append(','.join(headers))

        for stat in self.report.stats:
            row = [
                stat.language,
                str(stat.total_tests),
                str(stat.passed_tests),
                str(stat.failed_tests),
                str(stat.error_tests),
                str(stat.skipped_tests),
                f"{stat.pass_rate:.2f}",
                f"{stat.coverage_rate:.2f}",
                f"{stat.duration:.2f}",
                str(stat.test_files),
                str(stat.source_files),
                str(stat.deleted_files)
            ]
            lines.append(','.join(row))

        report_content = '\n'.join(lines)

        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(report_content)

        return report_content

    def _generate_html(self, output_file: str) -> str:
        """生成HTML报告"""
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>单测覆盖率报告 - {self.report.project_name}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        table {{ border-collapse: collapse; width: 100%; margin-bottom: 20px; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #4CAF50; color: white; }}
        tr:nth-child(even) {{ background-color: #f2f2f2; }}
        .summary {{ background-color: #f9f9f9; padding: 15px; border-radius: 5px; }}
        h1 {{ color: #333; }}
        h2 {{ color: #555; }}
    </style>
</head>
<body>
    <h1>单测覆盖率报告</h1>
    <p><strong>项目:</strong> {self.report.project_name}</p>
    <p><strong>生成时间:</strong> {self.report.generated_at.strftime('%Y-%m-%d %H:%M:%S')}</p>

    <h2>各语言统计</h2>
    <table>
        <tr>
            <th>语言</th>
            <th>测试用例</th>
            <th>通过</th>
            <th>失败</th>
            <th>错误</th>
            <th>跳过</th>
            <th>通过率</th>
            <th>覆盖率</th>
            <th>执行时间</th>
        </tr>
"""

        for stat in self.report.stats:
            html += f"""        <tr>
            <td>{stat.language}</td>
            <td>{stat.total_tests}</td>
            <td>{stat.passed_tests}</td>
            <td>{stat.failed_tests}</td>
            <td>{stat.error_tests}</td>
            <td>{stat.skipped_tests}</td>
            <td>{stat.pass_rate:.2f}%</td>
            <td>{stat.coverage_rate:.2f}%</td>
            <td>{stat.duration:.2f}s</td>
        </tr>
"""

        html += """    </table>

    <h2>总体统计</h2>
    <div class="summary">
        <p><strong>总执行时间:</strong> """ + f"{self.report.total_duration:.2f}s</p>"
        html += f"""        <p><strong>总体通过率:</strong> {self.report.overall_pass_rate:.2f}%</p>
        <p><strong>总体覆盖率:</strong> {self.report.overall_coverage:.2f}%</p>
    </div>
</body>
</html>"""

        report_content = html

        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(report_content)

        return report_content
