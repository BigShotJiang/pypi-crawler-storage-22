#!/usr/bin/env python3
"""
智能编译失败处理器
只处理单测文件的删除，业务代码错误直接告警用户
"""

import os
import re
import shutil
from typing import List, Tuple, Optional, Dict, Set
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum

from coverage_tool.utils import FileBackupManager, DependencyGraph, Logger, parse_error_locations, safe_delete_file


class SmartCompilationHandler:
    """智能编译失败处理器 - 只删除单测文件"""

    TEST_FILE_PATTERNS = {
        'python': [
            r'.*_test\.py$',
            r'.*test_.+\.py$',
            r'.*_tests\.py$',
            r'test_.+\.py$',
            r'.*/tests/.+\.py$',
            r'.*/test/.+\.py$',
        ],
        'java': [
            r'.*Test\.java$',
            r'.*Tests\.java$',
            r'.*TestCase\.java$',
        ],
        'go': [
            r'.*_test\.go$',
        ],
        'c': [
            r'.*_test\.c$',
            r'.*test_.+\.c$',
            r'.*/tests/.+\.c$',
            r'.*/test/.+\.c$',
        ],
        'cpp': [
            r'.*_test\.cpp$',
            r'.*test_.+\.cpp$',
            r'.*_test\.cc$',
            r'.*test_.+\.cc$',
            r'.*/tests/.+\.cpp$',
            r'.*/test/.+\.cpp$',
        ],
    }

    def __init__(self, target_dir: str, logger: Optional[Logger] = None):
        self.target_dir = target_dir
        self.logger = logger or Logger()
        self.backup_manager = FileBackupManager()
        self.deleted_test_files: List[str] = []

    def _is_test_file(self, file_path: str, language: str = 'python') -> bool:
        """检查是否是单测文件"""
        file_name = os.path.basename(file_path)
        patterns = self.TEST_FILE_PATTERNS.get(language, self.TEST_FILE_PATTERNS['python'])
        for pattern in patterns:
            if re.match(pattern, file_name, re.IGNORECASE):
                return True
        return False

    def _is_business_code_error(self, error: str) -> bool:
        """检查是否是业务代码错误（非单测代码错误）"""
        business_error_keywords = [
            'undefined reference',
            'undefined symbol',
            'cannot find symbol',
            'package does not exist',
            'class not found',
            'method not found',
            'variable not declared',
            'syntax error',
            'type error',
            'compile error',
        ]
        error_lower = error.lower()
        return any(keyword in error_lower for keyword in business_error_keywords)

    def _extract_error_directory(self, error: str) -> Optional[str]:
        """从错误信息中提取报错文件所在目录"""
        file_path = parse_error_locations([error], self.target_dir)
        if file_path:
            first_file = list(file_path.keys())[0]
            return os.path.dirname(first_file)
        return None

    def _find_test_files_in_directory(self, directory: str, language: str) -> List[str]:
        """查找指定目录下的所有单测文件"""
        if not os.path.exists(directory) or not os.path.isdir(directory):
            return []

        test_files = []
        for root, dirs, files in os.walk(directory):
            for file in files:
                file_path = os.path.join(root, file)
                if self._is_test_file(file_path, language):
                    test_files.append(file_path)
        return test_files

    def _has_source_code_error(self, errors: List[str]) -> bool:
        """检查错误中是否包含业务代码错误"""
        for error in errors:
            if self._is_business_code_error(error):
                return True
        return False

    def handle_compilation_failure(
        self,
        errors: List[str],
        compile_func,
        language: str = 'python',
        max_iterations: int = 1
    ) -> Tuple[bool, List[str], List[str]]:
        """
        处理编译失败 - 只删除单测文件，业务代码错误直接终止

        Args:
            errors: 编译错误列表
            compile_func: 编译函数，接收target_dir，返回(success, errors)
            language: 编程语言
            max_iterations: 最大尝试次数（建议设为1，因为只删单测文件）

        Returns:
            (编译是否成功, 被删除的单测文件列表, 剩余的编译错误)
        """
        self.logger.warning("=" * 60)
        self.logger.warning("检测到编译失败，开始分析错误...")
        self.logger.warning("=" * 60)

        iteration = 0

        while iteration < max_iterations:
            iteration += 1
            self.logger.info(f"编译修复迭代 {iteration}/{max_iterations}")

            error_locations = parse_error_locations(errors, self.target_dir)

            if not error_locations:
                self.logger.warning("无法从错误信息中识别问题文件位置")
                break

            error_dirs = set(os.path.dirname(path) for path in error_locations.keys())
            self.logger.info(f"检测到 {len(error_dirs)} 个报错目录")

            all_test_files = []
            for error_dir in error_dirs:
                test_files = self._find_test_files_in_directory(error_dir, language)
                if test_files:
                    self.logger.info(f"目录 {error_dir} 找到 {len(test_files)} 个单测文件")
                    all_test_files.extend(test_files)

            all_test_files = list(set(all_test_files))

            if not all_test_files:
                self.logger.warning("报错目录下未找到单测文件")
                self.logger.warning("=" * 60)
                self.logger.warning("编译错误来自业务代码，请手动修复以下问题后重试:")
                for i, error in enumerate(errors[:5], 1):
                    self.logger.warning(f"  [{i}] {error.strip()}")
                if len(errors) > 5:
                    self.logger.warning(f"  ... 共 {len(errors)} 个错误")
                self.logger.warning("=" * 60)
                return False, self.deleted_test_files, errors

            self.logger.info(f"准备删除 {len(all_test_files)} 个单测文件")

            deleted_in_iteration = []
            for test_file in all_test_files:
                if safe_delete_file(test_file, self.backup_manager):
                    deleted_in_iteration.append(test_file)
                    self.deleted_test_files.append(test_file)
                    self.logger.info(f"已删除单测文件: {test_file}")

            if not deleted_in_iteration:
                self.logger.warning("未能删除任何单测文件")
                break

            self.logger.info(f"已删除 {len(deleted_in_iteration)} 个单测文件，重新编译...")

            success, new_errors = compile_func(self.target_dir)

            if success:
                self.logger.info("编译成功！")
                return True, self.deleted_test_files, []

            errors = new_errors

            if iteration >= max_iterations:
                self.logger.warning("=" * 60)
                self.logger.warning("已删除所有相关单测文件，但编译仍未成功")
                self.logger.warning("编译错误来自业务代码，请手动修复以下问题后重试:")
                for i, error in enumerate(errors[:10], 1):
                    self.logger.warning(f"  [{i}] {error.strip()}")
                if len(errors) > 10:
                    self.logger.warning(f"  ... 共 {len(errors)} 个错误")
                self.logger.warning("=" * 60)
                return False, self.deleted_test_files, errors

        self.logger.error("编译修复失败")
        return False, self.deleted_test_files, errors

    def restore_deleted_files(self) -> List[str]:
        """恢复所有已删除的单测文件"""
        restored = []
        for file_path in self.deleted_test_files:
            if self.backup_manager.restore_file(file_path):
                restored.append(file_path)
                self.logger.info(f"已恢复文件: {file_path}")
        self.deleted_test_files.clear()
        return restored

    def get_deleted_files(self) -> List[str]:
        """获取已删除的文件列表"""
        return self.deleted_test_files.copy()

    def cleanup(self):
        """清理资源"""
        self.backup_manager.cleanup()


class CompilationErrorParser:
    """编译错误解析器"""

    ERROR_PATTERNS = {
        'python': [
            (r'File "([^"]+\.py)", line (\d+)', 'file_and_line'),
            (r'SyntaxError.*in ([^\s]+\.py)', 'syntax_error'),
            (r'ImportError.*from ([^\s]+\.py)', 'import_error'),
        ],
        'java': [
            (r'([^\s]+\.java):(\d+):', 'file_and_line'),
            (r'error: cannot find symbol\s+Location: ([^\s]+\.java)', 'symbol_error'),
            (r'error: package ([^\s]+) does not exist', 'package_error'),
        ],
        'go': [
            (r'# ([^\s]+)', 'package_error'),
            (r'([^\s]+\.go):(\d+):(\d+):', 'file_and_line'),
            (r'([^\s]+\.go):(\d+):', 'file_and_line'),
            (r'undefined:\s+(\w+)', 'undefined_error'),
        ],
        'c': [
            (r'([^\s]+\.(c|h)):(\d+):(\d+):', 'file_and_line'),
            (r'([^\s]+\.(c|h)):(\d+):', 'file_and_line'),
            (r'undefined reference to', 'link_error'),
        ],
        'cpp': [
            (r'([^\s]+\.(cpp|hpp|cc|hh)):(\d+):(\d+):', 'file_and_line'),
            (r'([^\s]+\.(cpp|hpp|cc|hh)):(\d+):', 'file_and_line'),
            (r'undefined reference to', 'link_error'),
        ]
    }

    @staticmethod
    def parse_errors(errors: List[str], language: str, project_dir: str) -> Dict[str, List[Dict]]:
        patterns = CompilationErrorParser.ERROR_PATTERNS.get(language, [])
        file_errors: Dict[str, List[Dict]] = {}

        for error in errors:
            for pattern, error_type in patterns:
                matches = re.findall(pattern, error)
                for match in matches:
                    if isinstance(match, tuple):
                        file_path = match[0]
                        line_num = int(match[1]) if len(match) > 1 and match[1].isdigit() else 0
                    else:
                        file_path = match
                        line_num = 0

                    if not os.path.isabs(file_path):
                        file_path = os.path.join(project_dir, file_path)
                    file_path = os.path.normpath(file_path)

                    if file_path not in file_errors:
                        file_errors[file_path] = []

                    file_errors[file_path].append({
                        'line': line_num,
                        'type': error_type,
                        'message': error
                    })

        return file_errors
