#!/usr/bin/env python3
"""
环境检查器
检查各语言编译和测试环境是否满足要求
支持根据项目配置文件智能分析依赖
"""

import subprocess
import shutil
import os
import re
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum
from pathlib import Path

class EnvironmentStatus(Enum):
    OK = "ok"
    MISSING = "missing"
    WARNING = "warning"
    OPTIONAL = "optional"

@dataclass
class EnvironmentCheck:
    """环境检查项"""
    name: str
    status: EnvironmentStatus
    version: Optional[str] = None
    message: str = ""
    suggestion: str = ""
    required_by_project: bool = False

@dataclass
class EnvironmentReport:
    """环境检查报告"""
    language: str
    checks: List[EnvironmentCheck] = field(default_factory=list)
    all_passed: bool = True
    critical_missing: List[str] = field(default_factory=list)
    installation_suggestions: List[str] = field(default_factory=list)
    project_config_detected: List[str] = field(default_factory=list)

    def add_check(self, check: EnvironmentCheck):
        self.checks.append(check)
        if check.status == EnvironmentStatus.MISSING and check.required_by_project:
            self.all_passed = False
            self.critical_missing.append(check.name)

class EnvironmentChecker:
    """环境检查器"""

    def __init__(self):
        self.check_results: Dict[str, EnvironmentReport] = {}

    def check_language_environment(self, language: str, project_dir: str = None) -> EnvironmentReport:
        """检查特定语言的环境"""
        report = EnvironmentReport(language=language)

        # 分析项目依赖
        if project_dir and os.path.exists(project_dir):
            self._analyze_project_dependencies(report, language, project_dir)

        if language == "python":
            self._check_python_env(report)
        elif language == "java":
            self._check_java_env(report)
        elif language == "go":
            self._check_go_env(report)
        elif language in ["c", "cpp"]:
            self._check_c_cpp_env(report)

        return report

    def _analyze_project_dependencies(self, report: EnvironmentReport, language: str, project_dir: str):
        """分析项目配置文件"""
        from coverage_tool.analyzers import DependencyAnalyzer

        analyzer = DependencyAnalyzer(project_dir)
        analysis = analyzer.analyze(language)

        if analysis is None:
            return

        # 记录检测到的配置文件
        if analysis.build_system:
            report.project_config_detected.append(f"构建系统: {analysis.build_system}")
        if analysis.test_framework:
            report.project_config_detected.append(f"测试框架: {analysis.test_framework}")
        if analysis.warnings:
            for warning in analysis.warnings:
                report.project_config_detected.append(f"⚠ {warning}")

        # 检查项目依赖是否已安装
        for dep in analysis.dependencies:
            if dep.required or dep.installed:
                check = EnvironmentCheck(
                    name=dep.name,
                    status=EnvironmentStatus.OK if dep.installed else EnvironmentStatus.MISSING,
                    version=dep.installed_version or dep.version or "",
                    message=f"{'已安装' if dep.installed else '未安装'}",
                    required_by_project=dep.required,
                    suggestion=self._get_suggestion(dep.name, language)
                )
                report.add_check(check)

    def _get_suggestion(self, dep_name: str, language: str) -> str:
        """获取安装建议"""
        suggestions = {
            'pytest': 'pip install pytest',
            'coverage': 'pip install coverage',
            'tox': 'pip install tox',
            'unittest': 'Python标准库，无需安装',
            'maven': 'apt install maven (Linux) / brew install maven (macOS)',
            'gradle': 'https://gradle.org/install/',
            'java': 'https://adoptium.net/ 或 https://www.oracle.com/java/',
            'go': 'https://go.dev/dl/',
            'gcc': 'apt install gcc (Linux) / brew install gcc (macOS)',
            'g++': 'apt install g++ (Linux) / brew install gcc (macOS)',
            'make': 'apt install make (Linux) / brew install make (macOS)',
            'cmake': 'https://cmake.org/download/',
            'gcov': '随GCC安装',
            'lcov': 'apt install lcov (Linux)',
            'googletest': 'apt install libgtest-dev cmake',
        }
        return suggestions.get(dep_name, f'请安装 {dep_name}')

    def _run_command(self, cmd: str) -> Tuple[bool, str, str]:
        """运行命令检查"""
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return False, "", "命令执行超时"
        except Exception as e:
            return False, "", str(e)

    def _check_python_env(self, report: EnvironmentReport):
        """检查Python环境"""
        check = EnvironmentCheck(
            name="Python",
            status=EnvironmentStatus.OK,
            version="",
            message="Python 环境正常",
            required_by_project=True
        )
        success, stdout, _ = self._run_command("python3 --version")
        if success:
            check.version = stdout.strip()
            check.message = f"Python 版本: {check.version}"
        else:
            check.status = EnvironmentStatus.MISSING
            check.message = "未找到 Python"
            check.suggestion = "请安装 Python 3.7+: https://www.python.org/downloads/"
        report.add_check(check)

        # 检查pytest
        success, stdout, _ = self._run_command("python3 -m pytest --version")
        check = EnvironmentCheck(
            name="pytest",
            status=EnvironmentStatus.OK if success else EnvironmentStatus.WARNING,
            message="pytest 未安装" if not success else f"pytest 版本: {stdout.strip().split(chr(10))[0] if stdout else '未知'}",
            suggestion="pip install pytest" if not success else "",
            required_by_project=True
        )
        if success:
            check.version = stdout.strip().split('\n')[0]
        report.add_check(check)

        # 检查coverage
        success, stdout, _ = self._run_command("python3 -m coverage --version")
        check = EnvironmentCheck(
            name="coverage.py",
            status=EnvironmentStatus.OK if success else EnvironmentStatus.WARNING,
            message="coverage.py 未安装" if not success else f"coverage.py 已安装",
            suggestion="pip install coverage" if not success else "",
            required_by_project=False
        )
        if success:
            check.version = stdout.strip().split('\n')[0]
        report.add_check(check)

    def _check_java_env(self, report: EnvironmentReport):
        """检查Java环境"""
        success, stdout, stderr = self._run_command("java -version 2>&1")
        check = EnvironmentCheck(
            name="Java JDK",
            status=EnvironmentStatus.OK if success else EnvironmentStatus.MISSING,
            version="",
            message="未找到 Java JDK" if not success else f"Java 版本: {(stdout or stderr).strip().split(chr(10))[0] if (stdout or stderr) else '未知'}",
            suggestion="请安装 JDK 8+: https://adoptium.net/" if not success else "",
            required_by_project=True
        )
        if success:
            check.version = (stdout or stderr).strip().split('\n')[0]
        report.add_check(check)

        success, stdout, _ = self._run_command("mvn -version")
        check = EnvironmentCheck(
            name="Maven",
            status=EnvironmentStatus.OK if success else EnvironmentStatus.WARNING,
            message="Maven 未安装" if not success else f"Maven 版本: {stdout.strip().split(chr(10))[0] if stdout else '未知'}",
            suggestion="apt install maven / brew install maven" if not success else "",
            required_by_project=False
        )
        if success:
            check.version = stdout.strip().split('\n')[0]
        report.add_check(check)

    def _check_go_env(self, report: EnvironmentReport):
        """检查Go环境"""
        success, stdout, _ = self._run_command("go version")
        check = EnvironmentCheck(
            name="Go SDK",
            status=EnvironmentStatus.OK if success else EnvironmentStatus.MISSING,
            version="",
            message="未找到 Go SDK" if not success else f"Go 版本: {stdout.strip() if stdout else '未知'}",
            suggestion="请安装 Go 1.16+: https://go.dev/dl/" if not success else "",
            required_by_project=True
        )
        if success:
            check.version = stdout.strip()
        report.add_check(check)

    def _check_c_cpp_env(self, report: EnvironmentReport):
        """检查C/C++环境"""
        success, stdout, _ = self._run_command("gcc --version")
        check = EnvironmentCheck(
            name="GCC",
            status=EnvironmentStatus.OK if success else EnvironmentStatus.MISSING,
            version="",
            message="GCC 未安装" if not success else f"GCC 版本: {stdout.strip().split(chr(10))[0] if stdout else '未知'}",
            suggestion="apt install gcc (Linux) / brew install gcc (macOS)" if not success else "",
            required_by_project=True
        )
        if success:
            check.version = stdout.strip().split('\n')[0]
        report.add_check(check)

        success, stdout, _ = self._run_command("g++ --version")
        check = EnvironmentCheck(
            name="G++",
            status=EnvironmentStatus.OK if success else EnvironmentStatus.MISSING,
            version="",
            message="G++ 未安装" if not success else f"G++ 版本: {stdout.strip().split(chr(10))[0] if stdout else '未知'}",
            suggestion="apt install g++ (Linux) / brew install gcc (macOS)" if not success else "",
            required_by_project=True
        )
        if success:
            check.version = stdout.strip().split('\n')[0]
        report.add_check(check)

        success, stdout, _ = self._run_command("make --version")
        check = EnvironmentCheck(
            name="Make",
            status=EnvironmentStatus.OK if success else EnvironmentStatus.MISSING,
            version="",
            message="Make 未安装" if not success else f"Make 版本: {stdout.strip().split(chr(10))[0] if stdout else '未知'}",
            suggestion="apt install make (Linux) / brew install make (macOS)" if not success else "",
            required_by_project=True
        )
        if success:
            check.version = stdout.strip().split('\n')[0]
        report.add_check(check)

    def print_report(self, report: EnvironmentReport):
        """打印环境检查报告"""
        print(f"\n{'='*60}")
        print(f"环境检查报告: {report.language}")
        print('='*60)

        # 显示检测到的项目配置
        if report.project_config_detected:
            print("\n📁 检测到的项目配置:")
            for config in report.project_config_detected:
                print(f"   • {config}")

        for check in report.checks:
            if check.status == EnvironmentStatus.OK:
                status_icon = "✓"
            elif check.status == EnvironmentStatus.WARNING:
                status_icon = "⚠"
            elif check.status == EnvironmentStatus.MISSING:
                status_icon = "✗"
            else:
                status_icon = "○"

            print(f"\n{status_icon} {check.name}")
            if check.version:
                print(f"   版本: {check.version}")
            print(f"   {check.message}")
            if check.suggestion:
                print(f"   安装: {check.suggestion}")

        print(f"\n{'='*60}")
        if report.all_passed:
            print("✓ 环境检查通过")
        else:
            print("✗ 存在缺失的关键依赖，请先安装")
            print(f"缺失项: {', '.join(report.critical_missing)}")
        print('='*60)

    def check_all_and_print(self, language: str, project_dir: str = None):
        """检查并打印所有环境信息"""
        report = self.check_language_environment(language, project_dir)
        self.print_report(report)
        return report
