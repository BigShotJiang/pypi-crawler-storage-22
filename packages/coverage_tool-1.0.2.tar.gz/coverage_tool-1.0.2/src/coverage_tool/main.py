#!/usr/bin/env python3
"""
多语言单测覆盖率统计工具
支持 Python, Java, Go, C, C++
"""

import argparse
import os
import sys
import tempfile
import shutil
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
from dataclasses import dataclass, field
from enum import Enum

from coverage_tool.core import Language, LANGUAGE_CONFIGS
from coverage_tool.core import CoverageReporter, CoverageReport, CoverageStats, ReportFormat
from coverage_tool.runners.factory import RunnerFactory
from coverage_tool.runners.base import RunResult
from coverage_tool.parsers import JunitXMLParser, TestReport
from coverage_tool.handlers import SmartCompilationHandler, EnvironmentChecker
from coverage_tool.test_removers import SmartTestRemoverFactory, BaseSmartTestRemover
from coverage_tool.utils import Logger, ProgressTracker, FileBackupManager


class ExecutionPhase(Enum):
    """执行阶段"""
    ENV_CHECK = "环境检查"
    COMPILATION = "编译"
    TEST_EXECUTION = "测试执行"
    TEST_CLEANUP = "测试清理"
    COVERAGE_CALCULATION = "覆盖率计算"
    REPORT_GENERATION = "报告生成"


@dataclass
class ExecutionResult:
    """执行结果"""
    success: bool
    phase: ExecutionPhase
    message: str
    details: Dict = field(default_factory=dict)


class CoverageTool:
    """覆盖率工具主类"""
    
    def __init__(self, config: 'ToolConfig'):
        self.config = config
        self.logger = Logger(verbose=True)
        self.backup_manager = FileBackupManager()
        self.execution_results: List[ExecutionResult] = []
        self.temp_dir = tempfile.mkdtemp(prefix="coverage_tool_")
        
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()
    
    def cleanup(self):
        """清理资源"""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir, ignore_errors=True)
        self.backup_manager.cleanup()
    
    def run(self) -> CoverageReport:
        """运行完整的覆盖率分析流程"""
        self.logger.info("=" * 80)
        self.logger.info(f"开始分析 {self.config.language.value} 项目: {self.config.target_dir}")
        self.logger.info("=" * 80)
        
        # 阶段1: 环境检查
        if not self._check_environment():
            return self._create_error_report("环境检查失败")
        
        # 阶段2: 编译（带失败处理）
        compile_success = self._compile_with_retry()
        if not compile_success:
            self.logger.warning("编译未完全成功，但继续尝试运行测试")
        
        # 阶段3: 运行测试
        test_result = self._run_tests()
        if not test_result.junit_xml_path:
            return self._create_error_report("测试执行失败或未生成报告")
        
        # 阶段4: 解析测试报告
        test_report = self._parse_test_report(test_result.junit_xml_path)
        if not test_report:
            return self._create_error_report("解析测试报告失败")
        
        # 阶段5: 清理失败的测试
        if test_report.total_failures > 0 or test_report.total_errors > 0:
            test_report = self._cleanup_failed_tests(test_report)
        
        # 阶段6: 生成报告
        report = self._generate_report(test_report, test_result)
        
        self.logger.info("=" * 80)
        self.logger.info("分析完成")
        self.logger.info("=" * 80)
        
        return report
    
    def _check_environment(self) -> bool:
        """检查环境"""
        self.logger.info(f"\n[{ExecutionPhase.ENV_CHECK.value}] 检查编译和测试环境...")
        
        checker = EnvironmentChecker()
        env_report = checker.check_language_environment(
            self.config.language.value, 
            self.config.target_dir
        )
        checker.print_report(env_report)
        
        if not env_report.all_passed:
            self.logger.error("环境检查未通过，请先安装缺失的依赖")
            self.execution_results.append(ExecutionResult(
                success=False,
                phase=ExecutionPhase.ENV_CHECK,
                message="环境检查未通过",
                details={'missing': env_report.critical_missing}
            ))
            return False
        
        self.execution_results.append(ExecutionResult(
            success=True,
            phase=ExecutionPhase.ENV_CHECK,
            message="环境检查通过"
        ))
        return True
    
    def _compile_with_retry(self) -> bool:
        """编译（支持失败重试）"""
        self.logger.info(f"\n[{ExecutionPhase.COMPILATION.value}] 编译项目...")
        
        runner = RunnerFactory.get_runner(self.config.language, self.logger)
        
        # 首次编译尝试
        success, errors = runner.compile(self.config.target_dir)
        
        if success:
            self.logger.info("✓ 编译成功")
            self.execution_results.append(ExecutionResult(
                success=True,
                phase=ExecutionPhase.COMPILATION,
                message="编译成功"
            ))
            return True
        
        # 编译失败，尝试修复
        if not self.config.delete_on_compile_failure:
            self.logger.error(f"编译失败（未启用自动删除）: {len(errors)} 个错误")
            self.execution_results.append(ExecutionResult(
                success=False,
                phase=ExecutionPhase.COMPILATION,
                message="编译失败",
                details={'errors': errors[:10]}
            ))
            return False
        
        self.logger.warning(f"编译失败，尝试自动修复... ({len(errors)} 个错误)")
        
        # 使用智能编译处理器
        handler = SmartCompilationHandler(self.config.target_dir, self.logger)
        
        def compile_func(target_dir):
            return runner.compile(target_dir)
        
        success, deleted_files, remaining_errors = handler.handle_compilation_failure(
            errors, 
            compile_func,
            language=self.config.language.value,
            max_iterations=self.config.max_compile_iterations
        )
        
        self.execution_results.append(ExecutionResult(
            success=success,
            phase=ExecutionPhase.COMPILATION,
            message="编译修复完成" if success else "编译修复失败",
            details={
                'deleted_files': deleted_files,
                'remaining_errors': remaining_errors[:10] if remaining_errors else []
            }
        ))
        
        if deleted_files:
            self.logger.info(f"删除了 {len(deleted_files)} 个问题文件以修复编译")
        
        return success
    
    def _run_tests(self) -> RunResult:
        """运行测试"""
        self.logger.info(f"\n[{ExecutionPhase.TEST_EXECUTION.value}] 运行测试...")
        
        runner = RunnerFactory.get_runner(self.config.language, self.logger)
        junit_output = os.path.join(self.temp_dir, "junit_report.xml")
        
        result = runner.run_tests(self.config.target_dir, junit_output)
        
        if result.success:
            self.logger.info(f"✓ 测试完成，耗时: {result.duration:.2f}s")
        else:
            self.logger.warning(f"测试返回非零状态: {result.return_code}")
        
        self.execution_results.append(ExecutionResult(
            success=result.success,
            phase=ExecutionPhase.TEST_EXECUTION,
            message="测试执行完成",
            details={
                'duration': result.duration,
                'return_code': result.return_code,
                'junit_xml': result.junit_xml_path
            }
        ))
        
        return result
    
    def _parse_test_report(self, junit_xml_path: str) -> Optional[TestReport]:
        """解析测试报告"""
        if not os.path.exists(junit_xml_path):
            self.logger.error(f"JUnit XML文件不存在: {junit_xml_path}")
            return None
        
        try:
            test_report = JunitXMLParser.parse(junit_xml_path)
            
            self.logger.info(f"\n测试用例统计:")
            self.logger.info(f"  总数: {test_report.total_tests}")
            self.logger.info(f"  通过: {test_report.total_tests - test_report.total_failures - test_report.total_errors - test_report.total_skipped}")
            self.logger.info(f"  失败: {test_report.total_failures}")
            self.logger.info(f"  错误: {test_report.total_errors}")
            self.logger.info(f"  跳过: {test_report.total_skipped}")
            self.logger.info(f"  通过率: {test_report.pass_rate:.2f}%")
            
            return test_report
            
        except Exception as e:
            self.logger.error(f"解析测试报告失败: {e}")
            return None
    
    def _cleanup_failed_tests(self, test_report: TestReport) -> TestReport:
        """清理失败的测试"""
        self.logger.info(f"\n[{ExecutionPhase.TEST_CLEANUP.value}] 清理失败的测试...")
        self.logger.info(f"发现 {test_report.total_failures} 个失败，{test_report.total_errors} 个错误")
        
        remover = SmartTestRemoverFactory.get_remover(
            self.config.language.value,
            self.config.target_dir,
            self.logger
        )
        
        max_iterations = self.config.max_cleanup_iterations
        current_report = test_report
        iteration = 0
        
        for i in range(max_iterations):
            iteration = i
            if current_report.total_failures == 0 and current_report.total_errors == 0:
                break
            
            self.logger.info(f"\n清理迭代 {iteration + 1}/{max_iterations}...")
            
            deleted_count, deleted_list = remover.remove_failed_tests(current_report)
            
            if deleted_count == 0:
                self.logger.warning("未能找到可清理的测试函数")
                break
            
            self.logger.info(f"已清理 {deleted_count} 个失败测试函数")
            
            # 重新运行测试
            runner = RunnerFactory.get_runner(self.config.language, self.logger)
            new_junit_output = os.path.join(self.temp_dir, f"junit_report_{iteration}.xml")
            test_result = runner.run_tests(self.config.target_dir, new_junit_output)
            
            if os.path.exists(new_junit_output):
                try:
                    current_report = JunitXMLParser.parse(new_junit_output)
                    self.logger.info(f"重新测试结果: 通过 {current_report.pass_rate:.2f}%")
                except Exception as e:
                    self.logger.error(f"解析新测试报告失败: {e}")
                    break
            else:
                self.logger.warning("未生成新的测试报告")
                break
        
        self.execution_results.append(ExecutionResult(
            success=True,
            phase=ExecutionPhase.TEST_CLEANUP,
            message="测试清理完成",
            details={
                'iterations': iteration + 1,
                'final_failures': current_report.total_failures,
                'final_errors': current_report.total_errors
            }
        ))
        
        return current_report
    
    def _generate_report(self, test_report: TestReport, test_result: RunResult) -> CoverageReport:
        """生成覆盖率报告"""
        self.logger.info(f"\n[{ExecutionPhase.REPORT_GENERATION.value}] 生成报告...")
        
        # 计算覆盖率
        coverage_rate = test_result.coverage_rate
        if coverage_rate == 0:
            # 尝试重新获取
            runner = RunnerFactory.get_runner(self.config.language, self.logger)
            junit_output = os.path.join(self.temp_dir, "junit_report.xml")
            coverage_rate = runner.get_coverage(junit_output)
        
        self.logger.info(f"代码覆盖率: {coverage_rate:.2f}%")
        
        # 统计文件数量
        runner = RunnerFactory.get_runner(self.config.language, self.logger)
        test_files = len(runner.find_files(
            self.config.target_dir, 
            LANGUAGE_CONFIGS[self.config.language].test_file_pattern
        ))
        source_files = len(runner.find_files(
            self.config.target_dir,
            LANGUAGE_CONFIGS[self.config.language].source_file_pattern
        ))
        
        # 创建统计
        stats = CoverageStats(
            language=self.config.language.value,
            total_tests=test_report.total_tests,
            passed_tests=test_report.total_tests - test_report.total_failures - test_report.total_errors - test_report.total_skipped,
            failed_tests=test_report.total_failures,
            error_tests=test_report.total_errors,
            skipped_tests=test_report.total_skipped,
            pass_rate=test_report.pass_rate,
            coverage_rate=coverage_rate,
            duration=test_result.duration,
            test_files=test_files,
            source_files=source_files,
            deleted_files=0  # 可以从execution_results计算
        )
        
        report = CoverageReport(
            project_name=os.path.basename(self.config.target_dir),
            stats=[stats],
            total_duration=test_result.duration,
            overall_pass_rate=stats.pass_rate,
            overall_coverage=coverage_rate
        )
        
        # 生成报告文件
        reporter = CoverageReporter(report)
        output_path = f"{self.config.output_file}.{self.config.report_format.value}"
        content = reporter.generate(output_path, self.config.report_format)
        
        self.logger.info(f"报告已生成: {output_path}")
        
        self.execution_results.append(ExecutionResult(
            success=True,
            phase=ExecutionPhase.REPORT_GENERATION,
            message="报告生成完成",
            details={'output_file': output_path}
        ))
        
        return report
    
    def _create_error_report(self, message: str) -> CoverageReport:
        """创建错误报告"""
        self.logger.error(f"\n错误: {message}")
        
        stats = CoverageStats(
            language=self.config.language.value,
            total_tests=0,
            passed_tests=0,
            failed_tests=0,
            error_tests=0,
            skipped_tests=0,
            pass_rate=0.0,
            coverage_rate=0.0,
            duration=0.0,
            test_files=0,
            source_files=0,
            deleted_files=0
        )
        
        return CoverageReport(
            project_name=os.path.basename(self.config.target_dir),
            stats=[stats],
            total_duration=0.0,
            overall_pass_rate=0.0,
            overall_coverage=0.0
        )


@dataclass
class ToolConfig:
    """工具配置"""
    language: Language
    target_dir: str
    output_file: str = "coverage_report"
    report_format: ReportFormat = ReportFormat.TEXT
    compile_timeout: int = 60
    test_timeout: int = 300
    delete_on_compile_failure: bool = True
    max_compile_iterations: int = 10
    max_cleanup_iterations: int = 10


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description="多语言单测覆盖率统计工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # Python项目
  coverage-tool --language python --target ./src --output report

  # Java项目
  coverage-tool --language java --target ./project --format json

  # Go项目
  coverage-tool --language go --target ./module --format html

  # C项目
  coverage-tool --language c --target ./src --format text

  # C++项目
  coverage-tool --language cpp --target ./src --format csv
        """
    )

    parser.add_argument(
        "-l", "--language",
        required=True,
        choices=["python", "java", "go", "c", "cpp"],
        help="编程语言"
    )

    parser.add_argument(
        "-t", "--target",
        required=True,
        help="目标目录路径"
    )

    parser.add_argument(
        "-o", "--output",
        default="coverage_report",
        help="输出报告文件名（默认: coverage_report）"
    )

    parser.add_argument(
        "-f", "--format",
        default="text",
        choices=["text", "json", "csv", "html"],
        help="报告格式（默认: text）"
    )

    parser.add_argument(
        "--no-delete",
        action="store_true",
        help="编译失败时不删除文件"
    )

    parser.add_argument(
        "--compile-timeout",
        type=int,
        default=60,
        help="编译超时时间（秒，默认: 60）"
    )

    parser.add_argument(
        "--test-timeout",
        type=int,
        default=300,
        help="测试超时时间（秒，默认: 300）"
    )

    parser.add_argument(
        "--max-compile-iterations",
        type=int,
        default=10,
        help="最大编译修复迭代次数（默认: 10）"
    )

    parser.add_argument(
        "--max-cleanup-iterations",
        type=int,
        default=10,
        help="最大测试清理迭代次数（默认: 10）"
    )

    return parser.parse_args()


def main():
    """主函数"""
    args = parse_args()
    
    # 转换参数
    config = ToolConfig(
        language=Language(args.language),
        target_dir=os.path.abspath(args.target),
        output_file=args.output,
        report_format=ReportFormat(args.format),
        compile_timeout=args.compile_timeout,
        test_timeout=args.test_timeout,
        delete_on_compile_failure=not args.no_delete,
        max_compile_iterations=args.max_compile_iterations,
        max_cleanup_iterations=args.max_cleanup_iterations
    )
    
    # 检查目标目录
    if not os.path.exists(config.target_dir):
        print(f"错误: 目标目录不存在: {config.target_dir}")
        sys.exit(1)
    
    # 运行工具
    try:
        with CoverageTool(config) as tool:
            report = tool.run()
            
            # 检查是否有问题
            has_errors = False
            error_messages = []
            
            if report.stats and len(report.stats) > 0:
                stat = report.stats[0]
                if stat.total_tests == 0:
                    error_messages.append("未找到测试用例")
                    has_errors = True
                if stat.coverage_rate == 0 and stat.total_tests > 0:
                    error_messages.append("覆盖率计算失败")
                    has_errors = True
            
            # 如果有错误，显示警告
            if has_errors:
                print("\n" + "=" * 80)
                print("⚠️ 执行完成，但存在以下问题:")
                for msg in error_messages:
                    print(f"  - {msg}")
                print("=" * 80)
                sys.exit(1)
            else:
                print("\n✓ 执行成功完成")
                sys.exit(0)
    
    except KeyboardInterrupt:
        print("\n\n用户中断执行")
        sys.exit(130)
    except Exception as e:
        print(f"\n错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
