#!/usr/bin/env python3
"""
JUnit XML 解析器
解析各语言生成的JUnit XML测试报告
"""

import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum
from pathlib import Path

class TestStatus(Enum):
    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"
    SKIPPED = "skipped"

@dataclass
class TestCase:
    """单个测试用例"""
    name: str
    classname: str
    time: float
    status: TestStatus
    failure_message: Optional[str] = None
    failure_type: Optional[str] = None
    error_message: Optional[str] = None
    error_type: Optional[str] = None
    skipped_message: Optional[str] = None

@dataclass
class TestSuite:
    """测试套件"""
    name: str
    tests: int
    failures: int
    errors: int
    skipped: int
    time: float
    test_cases: List[TestCase] = field(default_factory=list)

@dataclass
class TestReport:
    """完整测试报告"""
    suites: List[TestSuite]
    total_tests: int = 0
    total_failures: int = 0
    total_errors: int = 0
    total_skipped: int = 0
    total_time: float = 0.0

    def __post_init__(self):
        for suite in self.suites:
            self.total_tests += suite.tests
            self.total_failures += suite.failures
            self.total_errors += suite.errors
            self.total_skipped += suite.skipped
            self.total_time += suite.time

    @property
    def pass_rate(self) -> float:
        if self.total_tests == 0:
            return 0.0
        passed = self.total_tests - self.total_failures - self.total_errors - self.total_skipped
        return (passed / self.total_tests) * 100

class JunitXMLParser:
    """JUnit XML解析器"""

    @staticmethod
    def parse(xml_path: str) -> TestReport:
        """解析JUnit XML文件"""
        tree = ET.parse(xml_path)
        root = tree.getroot()

        # 兼容不同格式的根节点
        if root.tag == 'testsuites':
            return JunitXMLParser._parse_testsuites(root)
        elif root.tag == 'testsuite':
            return JunitXMLParser._parse_testsuite(root)
        else:
            raise ValueError(f"未知的XML根节点: {root.tag}")

    @staticmethod
    def _parse_testsuites(root: ET.Element) -> TestReport:
        """解析testsuites根节点"""
        suites = []
        for suite_elem in root.findall('testsuite'):
            suite = JunitXMLParser._parse_single_testsuite(suite_elem)
            suites.append(suite)
        return TestReport(suites=suites)

    @staticmethod
    def _parse_testsuite(root: ET.Element) -> TestReport:
        """解析testsuite根节点"""
        suite = JunitXMLParser._parse_single_testsuite(root)
        return TestReport(suites=[suite])

    @staticmethod
    def _parse_single_testsuite(suite_elem: ET.Element) -> TestSuite:
        """解析单个testsuite"""
        name = suite_elem.get('name', '')
        tests = int(suite_elem.get('tests', 0))
        failures = int(suite_elem.get('failures', 0))
        errors = int(suite_elem.get('errors', 0))
        skipped = int(suite_elem.get('skipped', 0))
        time = float(suite_elem.get('time', 0.0))

        test_cases = []
        for case_elem in suite_elem.findall('testcase'):
            test_case = JunitXMLParser._parse_testcase(case_elem)
            test_cases.append(test_case)

        return TestSuite(
            name=name,
            tests=tests,
            failures=failures,
            errors=errors,
            skipped=skipped,
            time=time,
            test_cases=test_cases
        )

    @staticmethod
    def _parse_testcase(case_elem: ET.Element) -> TestCase:
        """解析单个testcase"""
        name = case_elem.get('name', '')
        classname = case_elem.get('classname', '')
        time = float(case_elem.get('time', 0.0))

        # 检查状态
        failure_elem = case_elem.find('failure')
        error_elem = case_elem.find('error')
        skipped_elem = case_elem.find('skipped')

        if failure_elem is not None:
            status = TestStatus.FAILED
            failure_message = failure_elem.get('message', '')
            failure_type = failure_elem.get('type', '')
        elif error_elem is not None:
            status = TestStatus.ERROR
            error_message = error_elem.get('message', '')
            error_type = error_elem.get('type', '')
        elif skipped_elem is not None:
            status = TestStatus.SKIPPED
            skipped_message = skipped_elem.get('message', '')
        else:
            status = TestStatus.PASSED

        return TestCase(
            name=name,
            classname=classname,
            time=time,
            status=status,
            failure_message=failure_elem.get('message') if failure_elem else None,
            failure_type=failure_elem.get('type') if failure_elem else None,
            error_message=error_elem.get('message') if error_elem else None,
            error_type=error_elem.get('type') if error_elem else None,
            skipped_message=skipped_elem.get('message') if skipped_elem else None
        )

    @staticmethod
    def parse_string(xml_string: str) -> TestReport:
        """从字符串解析JUnit XML"""
        root = ET.fromstring(xml_string)
        if root.tag == 'testsuites':
            return JunitXMLParser._parse_testsuites(root)
        elif root.tag == 'testsuite':
            return JunitXMLParser._parse_testsuite(root)
        else:
            raise ValueError(f"未知的XML根节点: {root.tag}")
