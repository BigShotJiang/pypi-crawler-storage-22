#!/usr/bin/env python3
"""
C单测运行器
"""

import os
from typing import List

from coverage_tool.converters import JUnitReportConverter
from .base import BaseRunner, RunResult, CoverageExtractor


class CRunner(BaseRunner):
    """C单测运行器"""
    
    def run_tests(self, target_dir: str, output_file: str) -> RunResult:
        """运行C测试"""
        # 尝试使用make运行测试
        cmd = "make test"
        result = self._run_command(cmd, target_dir)
        
        # 尝试转换输出为JUnit XML
        if result.stdout or result.stderr:
            try:
                xml_content = JUnitReportConverter.convert_generic_output(
                    result.stdout + result.stderr, 'cunit'
                )
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(xml_content)
                result.junit_xml_path = output_file
            except Exception as e:
                self.logger.error(f"转换C测试输出失败: {e}")
        
        result.coverage_rate = self.get_coverage(output_file)
        
        return result
    
    def get_coverage(self, output_file: str) -> float:
        """获取C覆盖率（gcov）"""
        # 查找gcov输出文件
        temp_dir = os.path.dirname(output_file) if output_file else "."
        
        coverage_files = [
            os.path.join(temp_dir, "coverage.out"),
            os.path.join(temp_dir, "coverage.txt"),
            os.path.join(os.getcwd(), "coverage.out"),
        ]
        
        for cov_file in coverage_files:
            if os.path.exists(cov_file):
                return CoverageExtractor.extract_from_coverage_out(cov_file, 'c')
        
        return 0.0
    
    def compile(self, target_dir: str) -> tuple[bool, list[str]]:
        """编译C项目"""
        cmd = "make"
        result = self._run_command(cmd, target_dir)
        
        errors = []
        if not result.success:
            for line in result.stderr.split('\n'):
                if 'error:' in line.lower() or 'undefined reference' in line.lower():
                    errors.append(line.strip())
        
        return result.success, errors
