#!/usr/bin/env python3
"""
运行器工厂
"""

from typing import Optional

from coverage_tool.core import Language, LANGUAGE_CONFIGS
from coverage_tool.utils import Logger
from .base import BaseRunner
from .python_runner import PythonRunner
from .java_runner import JavaRunner
from .go_runner import GoRunner
from .c_runner import CRunner
from .cpp_runner import CPPRunner


class RunnerFactory:
    """运行器工厂"""
    
    _runners = {
        Language.PYTHON: PythonRunner,
        Language.JAVA: JavaRunner,
        Language.GO: GoRunner,
        Language.C: CRunner,
        Language.CPP: CPPRunner,
    }
    
    @classmethod
    def get_runner(cls, language: Language, logger: Optional[Logger] = None) -> BaseRunner:
        """获取对应语言的运行器"""
        config = LANGUAGE_CONFIGS[language]
        runner_class = cls._runners.get(language)
        if runner_class is None:
            raise ValueError(f"不支持的语言: {language}")
        return runner_class(config, logger)
    
    @classmethod
    def register_runner(cls, language: Language, runner_class: type):
        """注册新的运行器"""
        cls._runners[language] = runner_class
