#!/usr/bin/env python3
"""
Java单测运行器
"""

import os
import glob
import xml.etree.ElementTree as ET
from typing import List, Tuple

from .base import BaseRunner, RunResult, CoverageExtractor


class JavaRunner(BaseRunner):
    """Java单测运行器"""

    def run_tests(self, target_dir: str, output_file: str) -> RunResult:
        """运行Java测试"""
        cmd = "mvn test"
        result = self._run_command(cmd, target_dir)

        surefire_report = os.path.join(target_dir, "target", "surefire-reports")
        if os.path.exists(surefire_report):
            self._convert_surefire_reports(surefire_report, output_file)

        if not os.path.exists(output_file):
            junit_files = glob.glob(os.path.join(surefire_report, "*.xml"))
            if junit_files:
                self._merge_junit_reports(junit_files, output_file)

        result.junit_xml_path = output_file if os.path.exists(output_file) else None
        result.coverage_rate = self.get_coverage(target_dir)

        return result

    def _merge_junit_reports(self, junit_files: List[str], output_file: str):
        """合并多个JUnit XML报告为一个"""
        total_tests = 0
        total_failures = 0
        total_errors = 0
        total_skipped = 0
        test_suites = []

        for junit_file in junit_files:
            try:
                tree = ET.parse(junit_file)
                root = tree.getroot()

                if root.tag == 'testsuites':
                    for suite in root.findall('testsuite'):
                        test_suites.append(suite)
                elif root.tag == 'testsuite':
                    test_suites.append(root)
            except Exception as e:
                self.logger.warning(f"解析JUnit报告失败: {junit_file}: {e}")

        xml_declaration = '<?xml version="1.0" encoding="UTF-8"?>\n'
        testsuites_elem = ET.Element('testsuites')

        for suite in test_suites:
            testsuites_elem.append(suite)
            total_tests += int(suite.get('tests', 0))
            total_failures += int(suite.get('failures', 0))
            total_errors += int(suite.get('errors', 0))
            total_skipped += int(suite.get('skipped', 0))

        testsuites_elem.set('name', 'Merged Test Results')
        testsuites_elem.set('tests', str(total_tests))
        testsuites_elem.set('failures', str(total_failures))
        testsuites_elem.set('errors', str(total_errors))
        testsuites_elem.set('skipped', str(total_skipped))

        tree = ET.ElementTree(testsuites_elem)
        tree.write(output_file, encoding='UTF-8', xml_declaration=False)

        with open(output_file, 'r', encoding='utf-8') as f:
            content = f.read()
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(xml_declaration + content)

    def _convert_surefire_reports(self, surefire_dir: str, output_file: str):
        """转换Surefire报告为JUnit XML"""
        junit_files = glob.glob(os.path.join(surefire_dir, "TEST-*.xml"))
        if junit_files:
            self._merge_junit_reports(junit_files, output_file)

    def get_coverage(self, target_dir: str) -> float:
        """获取Java覆盖率（JaCoCo）"""
        jacoco_html = os.path.join(target_dir, "target", "site", "jacoco", "index.html")
        return CoverageExtractor.extract_from_jacoco(jacoco_html)

    def compile(self, target_dir: str) -> Tuple[bool, List[str]]:
        """编译Java项目"""
        cmd = "mvn compile"
        result = self._run_command(cmd, target_dir)

        errors = []
        if not result.success:
            for line in result.stderr.split('\n'):
                if 'error:' in line.lower() or 'cannot find symbol' in line.lower():
                    errors.append(line.strip())

        return result.success, errors
