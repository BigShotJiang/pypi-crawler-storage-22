#!/usr/bin/env python3
"""
Python单测运行器
"""

import subprocess
import os
import shutil
from typing import List, Tuple

from .base import BaseRunner, RunResult


class PythonRunner(BaseRunner):
    """Python单测运行器"""
    
    def run_tests(self, target_dir: str, output_file: str) -> RunResult:
        """运行Python测试"""
        output_dir = os.path.dirname(output_file) if output_file else target_dir
        
        # 使用 coverage 运行测试，同时生成 JUnit XML
        cmd = f"python3 -m coverage run --source={target_dir} -m pytest --junitxml={output_file} -v {target_dir}"
        result = self._run_command(cmd, target_dir)
        result.junit_xml_path = output_file if os.path.exists(output_file) else None
        
        # 复制 .coverage 文件到输出目录（如果需要）
        project_coverage = os.path.join(target_dir, ".coverage")
        if os.path.exists(project_coverage) and output_dir != target_dir:
            temp_coverage = os.path.join(output_dir, ".coverage")
            try:
                shutil.copy2(project_coverage, temp_coverage)
            except Exception as e:
                self.logger.debug(f"复制覆盖率文件失败: {e}")
        
        # 计算覆盖率
        result.coverage_rate = self.get_coverage(output_file)
        
        return result
    
    def get_coverage(self, output_file: str) -> float:
        """获取Python覆盖率"""
        output_dir = os.path.dirname(output_file) if output_file else "."
        
        try:
            # 检查是否存在 .coverage 数据文件
            coverage_file = os.path.join(output_dir, ".coverage")
            
            if not os.path.exists(coverage_file):
                # 如果没有覆盖率数据，尝试运行测试收集
                self.logger.debug("未找到覆盖率数据，尝试收集...")
                return 0.0
            
            # 生成覆盖率报告
            cmd = "python3 -m coverage report --omit='*test*'"
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                cwd=output_dir
            )
            
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if 'TOTAL' in line:
                        parts = line.split()
                        if len(parts) >= 2:
                            try:
                                coverage = float(parts[-1].replace('%', ''))
                                self.logger.info(f"从覆盖率报告读取: {coverage:.2f}%")
                                return coverage
                            except:
                                pass
            else:
                self.logger.warning(f"生成覆盖率报告失败: {result.stderr}")
        except Exception as e:
            self.logger.error(f"获取Python覆盖率失败: {e}")
        
        return 0.0
    
    def compile(self, target_dir: str) -> Tuple[bool, List[str]]:
        """Python语法检查"""
        errors = []
        py_files = self.find_files(target_dir, "*.py")
        
        for py_file in py_files:
            try:
                result = subprocess.run(
                    f"python3 -m py_compile {py_file}",
                    shell=True,
                    capture_output=True,
                    text=True
                )
                if result.returncode != 0:
                    errors.append(f"语法错误: {py_file} - {result.stderr}")
            except Exception as e:
                errors.append(f"检查失败: {py_file} - {str(e)}")
        
        return len(errors) == 0, errors
