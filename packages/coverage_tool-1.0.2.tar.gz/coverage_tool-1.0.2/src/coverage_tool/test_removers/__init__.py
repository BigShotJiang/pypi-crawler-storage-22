#!/usr/bin/env python3
"""
测试删除器包

重构后的模块化测试删除器，支持多种编程语言。

Usage:
    from test_removers import SmartTestRemoverFactory

    remover = SmartTestRemoverFactory.get_remover('python', '/path/to/project')
    test_functions = remover.find_test_functions('/path/to/test_file.py')
"""

from .base import (
    BaseSmartTestRemover,
    TestFunction,
    TestRemovalStrategy,
)

from .python_remover import PythonSmartTestRemover
from .java_remover import JavaSmartTestRemover
from .go_remover import GoSmartTestRemover
from .c_remover import CSmartTestRemover
from .cpp_remover import CPPSmartTestRemover

from .factory import SmartTestRemoverFactory

__all__ = [
    'BaseSmartTestRemover',
    'TestFunction',
    'TestRemovalStrategy',
    'PythonSmartTestRemover',
    'JavaSmartTestRemover',
    'GoSmartTestRemover',
    'CSmartTestRemover',
    'CPPSmartTestRemover',
    'SmartTestRemoverFactory',
]
