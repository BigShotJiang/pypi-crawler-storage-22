#!/usr/bin/env python3
"""
C测试删除器
使用正则表达式解析C测试文件
"""

import re
from typing import List, Optional, Tuple
from pathlib import Path

from coverage_tool.test_removers.base import BaseSmartTestRemover, TestFunction
from coverage_tool.parsers import TestCase


class CSmartTestRemover(BaseSmartTestRemover):
    """C智能测试删除器"""
    
    # C语言测试文件匹配模式
    C_TEST_PATTERNS = [
        "test_*.c",
        "*_test.c",
        "*test*.c",
        "check_*.c",
        "tests/*.c",
        "*_tests.c",
        "tests_*.c",
    ]
    
    # 预编译正则表达式
    TEST_FUNC_PATTERNS = [
        re.compile(r'^(void|int|bool)\s+(test_\w+)\s*\([^)]*\)\s*\{', re.MULTILINE),
        re.compile(r'^(void|int|bool)\s+(check_\w+)\s*\([^)]*\)\s*\{', re.MULTILINE),
        re.compile(r'^(void|int|bool)\s+(\w+_test)\s*\([^)]*\)\s*\{', re.MULTILINE),
    ]
    
    def _is_build_failure(self, test_name: str) -> bool:
        """检查是否是C构建失败的特殊测试名称"""
        build_failure_patterns = [
            '[build failed]',
            '[compilation failed]',
            'error:',
            'undefined reference',
            'linker error',
            'compilation error',
            'syntax error',
        ]
        return any(pattern in test_name for pattern in build_failure_patterns)
    
    def remove_all_tests_in_package(self, package_path: str) -> Tuple[int, List[str]]:
        """
        删除指定包/目录内的所有测试文件（C使用目录方式）
        用于处理目录级编译错误
        """
        return self.remove_all_tests_in_directory(package_path)
    
    def remove_all_tests_in_directory(self, directory_path: str) -> Tuple[int, List[str]]:
        """
        删除指定目录内的所有测试文件
        用于处理C/C++目录级编译错误
        """
        deleted_count = 0
        deleted_files = []
        
        # 按完整路径搜索
        dir_path = Path(self.project_dir) / directory_path
        
        if dir_path.exists() and dir_path.is_dir():
            test_files = []
            for pattern in self.C_TEST_PATTERNS:
                test_files.extend(dir_path.glob(pattern))
            # 去重
            test_files = list(set(test_files))
            
            if test_files:
                self.logger.info(f"[编译错误] 在目录 {dir_path} 发现 {len(test_files)} 个C测试文件")
                
                for test_file in test_files:
                    try:
                        # 备份文件
                        self.backup_manager.backup_file(str(test_file))
                        # 删除文件
                        test_file.unlink()
                        deleted_count += 1
                        deleted_files.append(str(test_file))
                        self.logger.info(f"[编译错误] ✓ 已删除C测试文件: {test_file}")
                    except Exception as e:
                        self.logger.error(f"[编译错误] 删除文件失败: {test_file}: {e}")
                
                return deleted_count, deleted_files
        
        # 如果没找到，尝试将classname作为子目录搜索
        parts = directory_path.replace('.', '/').split('/')
        for i in range(len(parts)):
            subdir = '/'.join(parts[i:])
            search_dir = Path(self.project_dir) / subdir
            if search_dir.exists() and search_dir.is_dir():
                test_files = []
                for pattern in self.C_TEST_PATTERNS:
                    test_files.extend(search_dir.glob(pattern))
                test_files = list(set(test_files))
                
                if test_files:
                    self.logger.info(f"[编译错误] 在目录 {search_dir} 发现 {len(test_files)} 个C测试文件")
                    
                    for test_file in test_files:
                        try:
                            self.backup_manager.backup_file(str(test_file))
                            test_file.unlink()
                            deleted_count += 1
                            deleted_files.append(str(test_file))
                            self.logger.info(f"[编译错误] ✓ 已删除C测试文件: {test_file}")
                        except Exception as e:
                            self.logger.error(f"[编译错误] 删除文件失败: {test_file}: {e}")
                    
                    return deleted_count, deleted_files
        
        return deleted_count, deleted_files
    
    def find_test_functions(self, file_path: str) -> List[TestFunction]:
        """查找C测试函数"""
        test_functions = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            for pattern in self.TEST_FUNC_PATTERNS:
                for match in pattern.finditer(content):
                    func_name = match.group(2)
                    start_pos = match.start()
                    start_line = content[:start_pos].count('\n') + 1
                    
                    # 找到函数结束
                    brace_count = 0
                    end_pos = match.end()
                    for i, char in enumerate(content[match.end():]):
                        if char == '{':
                            brace_count += 1
                        elif char == '}':
                            if brace_count == 0:
                                end_pos = match.end() + i + 1
                                break
                            brace_count -= 1
                    
                    end_line = content[:end_pos].count('\n') + 1
                    
                    test_func = TestFunction(
                        name=func_name,
                        file_path=file_path,
                        start_line=start_line,
                        end_line=end_line
                    )
                    test_functions.append(test_func)
        
        except Exception as e:
            self.logger.error(f"解析C文件失败 {file_path}: {e}")
        
        return test_functions
    
    def find_test_file(self, test_case: TestCase) -> Optional[str]:
        """查找C测试文件"""
        classname = test_case.classname
        test_name = test_case.name
        
        # 处理特殊的构建失败错误
        if self._is_build_failure(test_name):
            self.logger.info(f"[编译错误] 检测到C编译失败: {test_name}")
            # 尝试从classname推断目录
            search_dirs = [classname]
            
            # 也尝试将点分隔的包名转换为路径
            if '.' in classname:
                search_dirs.append(classname.replace('.', '/'))
            
            for search_dir in search_dirs:
                # 尝试不同的目录组合
                parts = search_dir.replace('.', '/').split('/')
                for i in range(len(parts)):
                    subdir = '/'.join(parts[i:])
                    test_dir = Path(self.project_dir) / subdir
                    
                    if test_dir.exists() and test_dir.is_dir():
                        # 查找该目录下的测试文件
                        for pattern in self.C_TEST_PATTERNS:
                            for test_file in test_dir.glob(pattern):
                                if test_file.exists():
                                    self.logger.info(f"[编译错误] 找到目录 {search_dir} 的C测试文件: {test_file}")
                                    return str(test_file)
        
        # 标准测试文件查找
        patterns = [
            f"{classname}_test.c",
            f"test_{classname}.c",
            f"tests/{classname}_test.c",
            f"check_{classname}.c",
        ]
        
        for pattern in patterns:
            file_path = Path(self.project_dir) / pattern
            if file_path.exists():
                return str(file_path)
        
        # 使用glob查找
        for pattern in self.C_TEST_PATTERNS:
            if '*' in pattern:
                for file_path in Path(self.project_dir).rglob(pattern):
                    if file_path.exists():
                        return str(file_path)
        
        return None
