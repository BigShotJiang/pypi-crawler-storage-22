#!/usr/bin/env python3
"""
C++测试删除器
支持Google Test和普通C++测试
"""

import re
from typing import List, Optional, Tuple
from pathlib import Path

from coverage_tool.test_removers.base import BaseSmartTestRemover, TestFunction
from coverage_tool.parsers import TestCase


class CPPSmartTestRemover(BaseSmartTestRemover):
    """C++智能测试删除器 - 支持Google Test"""
    
    # C++语言测试文件匹配模式
    CPP_TEST_PATTERNS = [
        "test_*.cpp",
        "*_test.cpp",
        "*test*.cpp",
        "Test*.cpp",
        "*.test.cpp",
        "test_*.cc",
        "*_test.cc",
        "*test*.cc",
        "Test*.cc",
        "*.test.cc",
        "tests/*.cpp",
        "tests/*.cc",
        "*_tests.cpp",
        "*_tests.cc",
        "tests_*.cpp",
        "tests_*.cc",
    ]
    
    # 预编译正则表达式
    GTEST_PATTERN = re.compile(
        r'TEST\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)\s*\{',
        re.MULTILINE
    )
    
    FUNC_PATTERN = re.compile(
        r'^(void|int|bool)\s+(test_\w+)\s*\([^)]*\)\s*\{',
        re.MULTILINE
    )
    
    def _is_build_failure(self, test_name: str) -> bool:
        """检查是否是C++构建失败的特殊测试名称"""
        build_failure_patterns = [
            '[build failed]',
            '[compilation failed]',
            'error:',
            'undefined reference',
            'linker error',
            'compilation error',
            'syntax error',
        ]
        return any(pattern in test_name for pattern in build_failure_patterns)
    
    def remove_all_tests_in_package(self, package_path: str) -> Tuple[int, List[str]]:
        """
        删除指定包/目录内的所有测试文件（C++使用目录方式）
        用于处理目录级编译错误
        """
        return self.remove_all_tests_in_directory(package_path)
    
    def remove_all_tests_in_directory(self, directory_path: str) -> Tuple[int, List[str]]:
        """
        删除指定目录内的所有测试文件
        用于处理C/C++目录级编译错误
        """
        deleted_count = 0
        deleted_files = []
        
        # 按完整路径搜索
        dir_path = Path(self.project_dir) / directory_path
        
        if dir_path.exists() and dir_path.is_dir():
            test_files = []
            for pattern in self.CPP_TEST_PATTERNS:
                test_files.extend(dir_path.glob(pattern))
            # 去重
            test_files = list(set(test_files))
            
            if test_files:
                self.logger.info(f"[编译错误] 在目录 {dir_path} 发现 {len(test_files)} 个C++测试文件")
                
                for test_file in test_files:
                    try:
                        # 备份文件
                        self.backup_manager.backup_file(str(test_file))
                        # 删除文件
                        test_file.unlink()
                        deleted_count += 1
                        deleted_files.append(str(test_file))
                        self.logger.info(f"[编译错误] ✓ 已删除C++测试文件: {test_file}")
                    except Exception as e:
                        self.logger.error(f"[编译错误] 删除文件失败: {test_file}: {e}")
                
                return deleted_count, deleted_files
        
        # 如果没找到，尝试将classname作为子目录搜索
        parts = directory_path.replace('.', '/').split('/')
        for i in range(len(parts)):
            subdir = '/'.join(parts[i:])
            search_dir = Path(self.project_dir) / subdir
            if search_dir.exists() and search_dir.is_dir():
                test_files = []
                for pattern in self.CPP_TEST_PATTERNS:
                    test_files.extend(search_dir.glob(pattern))
                test_files = list(set(test_files))
                
                if test_files:
                    self.logger.info(f"[编译错误] 在目录 {search_dir} 发现 {len(test_files)} 个C++测试文件")
                    
                    for test_file in test_files:
                        try:
                            self.backup_manager.backup_file(str(test_file))
                            test_file.unlink()
                            deleted_count += 1
                            deleted_files.append(str(test_file))
                            self.logger.info(f"[编译错误] ✓ 已删除C++测试文件: {test_file}")
                        except Exception as e:
                            self.logger.error(f"[编译错误] 删除文件失败: {test_file}: {e}")
                    
                    return deleted_count, deleted_files
        
        return deleted_count, deleted_files
    
    def find_test_functions(self, file_path: str) -> List[TestFunction]:
        """查找C++测试函数（Google Test格式）"""
        test_functions = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 匹配Google Test的TEST宏
            for match in self.GTEST_PATTERN.finditer(content):
                suite_name = match.group(1)
                test_name = match.group(2)
                full_name = f"{suite_name}.{test_name}"
                
                start_pos = match.start()
                start_line = content[:start_pos].count('\n') + 1
                
                # 找到测试结束
                brace_count = 0
                end_pos = match.end()
                for i, char in enumerate(content[match.end():]):
                    if char == '{':
                        brace_count += 1
                    elif char == '}':
                        if brace_count == 0:
                            end_pos = match.end() + i + 1
                            break
                        brace_count -= 1
                
                end_line = content[:end_pos].count('\n') + 1
                
                test_func = TestFunction(
                    name=full_name,
                    file_path=file_path,
                    start_line=start_line,
                    end_line=end_line
                )
                test_functions.append(test_func)
            
            # 也匹配普通测试函数
            for match in self.FUNC_PATTERN.finditer(content):
                func_name = match.group(2)
                start_pos = match.start()
                start_line = content[:start_pos].count('\n') + 1
                
                brace_count = 0
                end_pos = match.end()
                for i, char in enumerate(content[match.end():]):
                    if char == '{':
                        brace_count += 1
                    elif char == '}':
                        if brace_count == 0:
                            end_pos = match.end() + i + 1
                            break
                        brace_count -= 1
                
                end_line = content[:end_pos].count('\n') + 1
                
                test_func = TestFunction(
                    name=func_name,
                    file_path=file_path,
                    start_line=start_line,
                    end_line=end_line
                )
                test_functions.append(test_func)
        
        except Exception as e:
            self.logger.error(f"解析C++文件失败 {file_path}: {e}")
        
        return test_functions
    
    def find_test_file(self, test_case: TestCase) -> Optional[str]:
        """查找C++测试文件"""
        classname = test_case.classname
        test_name = test_case.name
        
        # 处理特殊的构建失败错误
        if self._is_build_failure(test_name):
            self.logger.info(f"[编译错误] 检测到C++编译失败: {test_name}")
            # 尝试从classname推断目录
            search_dirs = [classname]
            
            # 也尝试将点分隔的包名转换为路径
            if '.' in classname:
                search_dirs.append(classname.replace('.', '/'))
            
            for search_dir in search_dirs:
                # 尝试不同的目录组合
                parts = search_dir.replace('.', '/').split('/')
                for i in range(len(parts)):
                    subdir = '/'.join(parts[i:])
                    test_dir = Path(self.project_dir) / subdir
                    
                    if test_dir.exists() and test_dir.is_dir():
                        # 查找该目录下的测试文件
                        for pattern in self.CPP_TEST_PATTERNS:
                            for test_file in test_dir.glob(pattern):
                                if test_file.exists():
                                    self.logger.info(f"[编译错误] 找到目录 {search_dir} 的C++测试文件: {test_file}")
                                    return str(test_file)
        
        # 处理 Google Test 的 suite.name 格式
        if '.' in test_name:
            suite_name = test_name.split('.')[0]
            patterns = [
                f"{classname}_test.cpp",
                f"test_{classname}.cpp",
                f"tests/{classname}_test.cpp",
                f"Test{classname}.cpp",
                f"{classname}.test.cpp",
                f"{classname}_test.cc",
                f"test_{classname}.cc",
                f"Test{classname}.cc",
                f"{classname}.test.cc",
            ]
        else:
            patterns = [
                f"{classname}_test.cpp",
                f"test_{classname}.cpp",
                f"tests/{classname}_test.cpp",
                f"Test{classname}.cpp",
                f"{classname}.test.cpp",
                f"{classname}_test.cc",
                f"test_{classname}.cc",
                f"Test{classname}.cc",
                f"{classname}.test.cc",
            ]
        
        for pattern in patterns:
            file_path = Path(self.project_dir) / pattern
            if file_path.exists():
                return str(file_path)
        
        # 使用glob查找
        for pattern in self.CPP_TEST_PATTERNS:
            if '*' in pattern:
                for file_path in Path(self.project_dir).rglob(pattern):
                    if file_path.exists():
                        return str(file_path)
        
        return None
