#!/usr/bin/env python3
"""
测试删除器工厂
提供统一的接口来获取不同语言的测试删除器
"""

from typing import Optional

from coverage_tool.utils import Logger
from coverage_tool.test_removers.base import BaseSmartTestRemover, TestFunction, TestRemovalStrategy
from coverage_tool.test_removers.python_remover import PythonSmartTestRemover
from coverage_tool.test_removers.java_remover import JavaSmartTestRemover
from coverage_tool.test_removers.go_remover import GoSmartTestRemover
from coverage_tool.test_removers.c_remover import CSmartTestRemover
from coverage_tool.test_removers.cpp_remover import CPPSmartTestRemover


class SmartTestRemoverFactory:
    """智能测试删除器工厂"""
    
    _removers = {
        'python': PythonSmartTestRemover,
        'java': JavaSmartTestRemover,
        'go': GoSmartTestRemover,
        'c': CSmartTestRemover,
        'cpp': CPPSmartTestRemover,
    }
    
    @classmethod
    def get_remover(cls, language: str, project_dir: str, logger: Optional[Logger] = None) -> BaseSmartTestRemover:
        """获取对应语言的测试删除器"""
        remover_class = cls._removers.get(language.lower())
        if remover_class is None:
            raise ValueError(f"不支持的语言: {language}")
        return remover_class(project_dir, logger)
    
    @classmethod
    def register_remover(cls, language: str, remover_class: type):
        """注册新的测试删除器"""
        cls._removers[language.lower()] = remover_class
    
    @classmethod
    def supported_languages(cls) -> list:
        """返回支持的语言列表"""
        return list(cls._removers.keys())
