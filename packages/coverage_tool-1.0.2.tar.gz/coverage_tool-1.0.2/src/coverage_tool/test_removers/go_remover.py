#!/usr/bin/env python3
"""
Go测试删除器
使用正则表达式解析Go测试文件
"""

import re
from typing import List, Optional
from pathlib import Path

from coverage_tool.test_removers.base import BaseSmartTestRemover, TestFunction
from coverage_tool.parsers import TestCase


class GoSmartTestRemover(BaseSmartTestRemover):
    """Go智能测试删除器"""
    
    # 预编译正则表达式
    TEST_FUNC_PATTERN = re.compile(
        r'^func\s+(Test\w+)\s*\([^)]*\*testing\.T[^)]*\)\s*\{',
        re.MULTILINE
    )
    
    def find_test_functions(self, file_path: str) -> List[TestFunction]:
        """查找Go测试函数"""
        test_functions = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            for match in self.TEST_FUNC_PATTERN.finditer(content):
                func_name = match.group(1)
                start_pos = match.start()
                start_line = content[:start_pos].count('\n') + 1
                
                # 找到函数结束
                brace_count = 0
                end_pos = match.end()
                for i, char in enumerate(content[match.end():]):
                    if char == '{':
                        brace_count += 1
                    elif char == '}':
                        if brace_count == 0:
                            end_pos = match.end() + i + 1
                            break
                        brace_count -= 1
                
                end_line = content[:end_pos].count('\n') + 1
                
                test_func = TestFunction(
                    name=func_name,
                    file_path=file_path,
                    start_line=start_line,
                    end_line=end_line
                )
                test_functions.append(test_func)
        
        except Exception as e:
            self.logger.error(f"解析Go文件失败 {file_path}: {e}")
        
        return test_functions
    
    def find_test_file(self, test_case: TestCase) -> Optional[str]:
        """查找Go测试文件"""
        classname = test_case.classname
        test_name = test_case.name
        
        # 处理特殊的构建失败错误: [build failed]
        if '[build failed]' in test_name or '[no test files]' in test_name:
            # classname 包含包路径，如 "github.com/FishGoddess/logit/rotate"
            # 尝试从包名推断目录
            package_parts = classname.split('/')
            if len(package_parts) > 1:
                # 尝试不同的包目录组合
                for i in range(len(package_parts) - 1, 0, -1):
                    subdir = '/'.join(package_parts[i:])
                    # 查找该目录下的所有测试文件
                    for test_file in Path(self.project_dir).rglob(f"{subdir}/*_test.go"):
                        if test_file.exists():
                            self.logger.info(f"[编译错误] 找到包 {classname} 的测试文件: {test_file}")
                            return str(test_file)
                    # 也尝试子目录本身
                    dir_path = Path(self.project_dir) / subdir
                    if dir_path.exists() and dir_path.is_dir():
                        for test_file in dir_path.glob("*_test.go"):
                            if test_file.exists():
                                self.logger.info(f"[编译错误] 找到包 {classname} 的测试文件: {test_file}")
                                return str(test_file)
        
        # 从包名推断文件路径
        patterns = [
            f"{classname.replace('.', '/')}_test.go",
            f"{classname}_test.go",
        ]
        
        for pattern in patterns:
            file_path = Path(self.project_dir) / pattern
            if file_path.exists():
                return str(file_path)
        
        # 搜索包含测试函数的文件
        for test_file in Path(self.project_dir).rglob("*_test.go"):
            try:
                with open(test_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                if f"func {test_name}(" in content:
                    return str(test_file)
            except:
                continue
        
        return None
