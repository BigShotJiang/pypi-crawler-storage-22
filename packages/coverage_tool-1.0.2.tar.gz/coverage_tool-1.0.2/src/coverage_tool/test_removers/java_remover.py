#!/usr/bin/env python3
"""
Java测试删除器
使用正则表达式解析Java测试文件
"""

import re
from typing import List, Optional
from pathlib import Path

from coverage_tool.test_removers.base import BaseSmartTestRemover, TestFunction
from coverage_tool.parsers import TestCase


class JavaSmartTestRemover(BaseSmartTestRemover):
    """Java智能测试删除器"""
    
    # 预编译正则表达式提高性能
    TEST_METHOD_PATTERN = re.compile(
        r'(@Test(?:\([^)]*\))?\s*)?'  # @Test 注解（可选）
        r'(?:@\w+\s*)*'               # 其他注解
        r'(?:public\s+)?'             # 访问修饰符
        r'(?:void|static)?\s+'        # 返回类型
        r'(\w+)\s*'                   # 方法名
        r'\([^)]*\)\s*'              # 参数列表
        r'\{',                        # 方法开始
        re.MULTILINE | re.DOTALL
    )
    
    def _is_build_failure(self, test_name: str) -> bool:
        """检查是否是Java构建失败的特殊测试名称"""
        build_failure_patterns = [
            '[build failed]',
            '[compilation failed]',
            'Compilation failure',
            'cannot find symbol',
            'package does not exist',
            'class not found',
        ]
        return any(pattern in test_name for pattern in build_failure_patterns)
    
    def remove_all_tests_in_package(self, package_path: str) -> tuple:
        """
        删除指定Java包内的所有测试文件
        用于处理包级编译错误
        """
        deleted_count = 0
        deleted_files = []
        
        # Java包路径格式: com.example.test
        package_parts = package_path.split('.')
        
        if len(package_parts) > 0:
            # 将包路径转换为目录路径
            for i in range(len(package_parts)):
                subdir = '/'.join(package_parts[i:])
                
                # 搜索可能的目录结构
                search_paths = [
                    Path(self.project_dir) / subdir,
                    Path(self.project_dir) / 'src' / 'test' / 'java' / subdir,
                    Path(self.project_dir) / 'test' / subdir,
                    Path(self.project_dir) / 'tests' / subdir,
                ]
                
                for dir_path in search_paths:
                    if dir_path.exists() and dir_path.is_dir():
                        # 查找该目录下的所有测试文件
                        test_files = list(dir_path.glob("*Test.java")) + list(dir_path.glob("Test*.java"))
                        
                        if test_files:
                            self.logger.info(f"[编译错误] 在包 {package_path} 目录 {dir_path} 发现 {len(test_files)} 个测试文件")
                            
                            for test_file in test_files:
                                try:
                                    # 备份文件
                                    self.backup_manager.backup_file(str(test_file))
                                    # 删除文件
                                    test_file.unlink()
                                    deleted_count += 1
                                    deleted_files.append(str(test_file))
                                    self.logger.info(f"[编译错误] ✓ 已删除测试文件: {test_file}")
                                except Exception as e:
                                    self.logger.error(f"[编译错误] 删除文件失败: {test_file}: {e}")
                            
                            return deleted_count, deleted_files
        
        # 如果没找到，尝试递归搜索
        for search_pattern in ["**/*Test.java", "**/Test*.java"]:
            for test_file in Path(self.project_dir).rglob(search_pattern):
                try:
                    with open(test_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                    # 检查文件是否包含该包的导入或引用
                    if f"package {package_path}" in content or f"import {package_path}" in content:
                        self.backup_manager.backup_file(str(test_file))
                        test_file.unlink()
                        deleted_count += 1
                        deleted_files.append(str(test_file))
                        self.logger.info(f"[编译错误] ✓ 已删除测试文件: {test_file}")
                except:
                    continue
        
        return deleted_count, deleted_files
    
    def find_test_functions(self, file_path: str) -> List[TestFunction]:
        """查找Java测试方法"""
        test_methods = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            for match in self.TEST_METHOD_PATTERN.finditer(content):
                has_test_annotation = match.group(1) is not None
                method_name = match.group(2)
                
                # 如果方法名以 test 开头或有@Test注解
                if has_test_annotation or method_name.startswith('test'):
                    # 计算行号
                    start_pos = match.start()
                    line_num = content[:start_pos].count('\n') + 1
                    
                    # 找到方法结束位置
                    brace_count = 0
                    end_pos = match.end()
                    for i, char in enumerate(content[match.end():]):
                        if char == '{':
                            brace_count += 1
                        elif char == '}':
                            brace_count -= 1
                            if brace_count == 0:
                                end_pos = match.end() + i + 1
                                break
                    
                    end_line = content[:end_pos].count('\n') + 1
                    
                    test_func = TestFunction(
                        name=method_name,
                        file_path=file_path,
                        start_line=line_num,
                        end_line=end_line,
                        decorators=['Test'] if has_test_annotation else []
                    )
                    test_methods.append(test_func)
        
        except Exception as e:
            self.logger.error(f"解析Java文件失败 {file_path}: {e}")
        
        return test_methods
    
    def _get_deletion_range(self, test_func: TestFunction, lines: List[str]) -> tuple:
        """
        获取Java测试方法的删除范围
        考虑注解
        """
        start_idx = self._adjust_start_for_decorators(
            test_func, lines, comment_prefixes=['//']
        )
        end_idx = test_func.end_line
        return start_idx, end_idx
    
    def find_test_file(self, test_case: TestCase) -> Optional[str]:
        """查找Java测试文件"""
        classname = test_case.classname
        test_name = test_case.name
        
        # 处理特殊的构建失败错误
        if self._is_build_failure(test_name):
            self.logger.info(f"[编译错误] 检测到Java编译失败: {test_name}")
            # 如果是编译失败，classname通常包含包路径
            # 尝试从包名推断目录
            package_parts = classname.split('.')
            if len(package_parts) > 1:
                # 尝试不同的包目录组合
                for i in range(len(package_parts)):
                    subdir = '/'.join(package_parts[i:])
                    search_paths = [
                        Path(self.project_dir) / subdir,
                        Path(self.project_dir) / 'src' / 'test' / 'java' / subdir,
                        Path(self.project_dir) / 'test' / subdir,
                    ]
                    for dir_path in search_paths:
                        if dir_path.exists() and dir_path.is_dir():
                            # 查找该目录下的测试文件
                            for test_file in dir_path.glob("*Test.java"):
                                if test_file.exists():
                                    self.logger.info(f"[编译错误] 找到包 {classname} 的测试文件: {test_file}")
                                    return str(test_file)
        
        parts = classname.split('.')
        
        if len(parts) > 1:
            # 完整的包路径
            package_path = '/'.join(parts[:-1])
            class_name = parts[-1]
            patterns = [
                f"{package_path}/{class_name}Test.java",
                f"{package_path}/Test{class_name}.java",
                f"test/{package_path}/{class_name}Test.java",
                f"src/test/java/{package_path}/{class_name}Test.java",
            ]
        else:
            class_name = parts[0]
            patterns = [
                f"{class_name}Test.java",
                f"Test{class_name}.java",
                f"test/{class_name}Test.java",
            ]
        
        for pattern in patterns:
            file_path = Path(self.project_dir) / pattern
            if file_path.exists():
                return str(file_path)
        
        return None
