#!/usr/bin/env python3
"""
Python测试删除器
使用AST解析Python测试文件
"""

import ast
import os
from typing import List, Optional
from pathlib import Path

from coverage_tool.test_removers.base import BaseSmartTestRemover, TestFunction
from coverage_tool.parsers import TestCase


class PythonSmartTestRemover(BaseSmartTestRemover):
    """Python智能测试删除器 - 使用AST解析"""
    
    def find_test_functions(self, file_path: str) -> List[TestFunction]:
        """使用AST查找Python测试函数"""
        test_functions = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            tree = ast.parse(content)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    # 检查是否是测试函数
                    if self._is_test_function(node):
                        # 获取函数在文件中的位置
                        start_line = node.lineno
                        end_line = node.end_lineno if hasattr(node, 'end_lineno') else start_line
                        
                        # 获取装饰器
                        decorators = []
                        for decorator in node.decorator_list:
                            if isinstance(decorator, ast.Name):
                                decorators.append(decorator.id)
                            elif isinstance(decorator, ast.Call):
                                if isinstance(decorator.func, ast.Name):
                                    decorators.append(decorator.func.id)
                        
                        test_func = TestFunction(
                            name=node.name,
                            file_path=file_path,
                            start_line=start_line,
                            end_line=end_line or start_line,
                            decorators=decorators,
                            is_class_method=self._is_class_method(node, tree),
                            class_name=self._get_class_name(node, tree)
                        )
                        test_functions.append(test_func)
                
                elif isinstance(node, ast.ClassDef):
                    # 处理测试类中的方法
                    if self._is_test_class(node):
                        for item in node.body:
                            if isinstance(item, ast.FunctionDef) and self._is_test_method(item):
                                start_line = item.lineno
                                end_line = item.end_lineno if hasattr(item, 'end_lineno') else start_line
                                
                                test_func = TestFunction(
                                    name=item.name,
                                    file_path=file_path,
                                    start_line=start_line,
                                    end_line=end_line or start_line,
                                    is_class_method=True,
                                    class_name=node.name
                                )
                                test_functions.append(test_func)
        
        except SyntaxError as e:
            self.logger.error(f"Python语法错误 {file_path}: {e}")
        except Exception as e:
            self.logger.error(f"解析Python文件失败 {file_path}: {e}")
        
        return test_functions
    
    def _is_test_function(self, node: ast.FunctionDef) -> bool:
        """检查是否是测试函数"""
        # 函数名以 test_ 开头
        if node.name.startswith('test_'):
            return True
        
        # 检查是否有测试相关的装饰器
        test_decorators = {'pytest', 'fixture', 'parametrize'}
        for decorator in node.decorator_list:
            if isinstance(decorator, ast.Name):
                if decorator.id.lower() in test_decorators or decorator.id.startswith('pytest'):
                    return True
        
        return False
    
    def _is_test_class(self, node: ast.ClassDef) -> bool:
        """检查是否是测试类"""
        # 类名以 Test 开头
        if node.name.startswith('Test'):
            return True
        
        # 检查继承
        for base in node.bases:
            if isinstance(base, ast.Name):
                if 'test' in base.id.lower():
                    return True
        
        return False
    
    def _is_test_method(self, node: ast.FunctionDef) -> bool:
        """检查是否是测试方法"""
        return node.name.startswith('test_')
    
    def _is_class_method(self, node: ast.FunctionDef, tree: ast.AST) -> bool:
        """检查函数是否是类方法"""
        for parent in ast.walk(tree):
            if isinstance(parent, ast.ClassDef):
                for item in parent.body:
                    if isinstance(item, ast.FunctionDef) and item.name == node.name:
                        return True
        return False
    
    def _get_class_name(self, node: ast.FunctionDef, tree: ast.AST) -> Optional[str]:
        """获取函数所属的类名"""
        for parent in ast.walk(tree):
            if isinstance(parent, ast.ClassDef):
                for item in parent.body:
                    if isinstance(item, ast.FunctionDef) and item.name == node.name:
                        return parent.name
        return None
    
    def _get_deletion_range(self, test_func: TestFunction, lines: List[str]) -> tuple:
        """
        获取Python测试函数的删除范围
        考虑装饰器和空行
        """
        start_idx = self._adjust_start_for_decorators(
            test_func, lines, comment_prefixes=['#']
        )
        end_idx = test_func.end_line
        return start_idx, end_idx
    
    def find_test_file(self, test_case: TestCase) -> Optional[str]:
        """查找Python测试文件"""
        classname = test_case.classname
        
        # 可能的文件模式
        patterns = [
            f"{classname.replace('.', '/')}.py",
            f"test_{classname.replace('.', '_')}.py",
            f"{classname.replace('.', '_')}_test.py",
            f"tests/{classname.replace('.', '/')}.py",
            f"tests/test_{classname.replace('.', '_')}.py",
        ]
        
        for pattern in patterns:
            file_path = Path(self.project_dir) / pattern
            if file_path.exists():
                return str(file_path)
        
        # 搜索包含测试函数的文件
        for test_file in Path(self.project_dir).rglob("*test*.py"):
            try:
                with open(test_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                if f"def {test_case.name}(" in content:
                    return str(test_file)
            except:
                continue
        
        return None
