#!/usr/bin/env python3
"""
依赖关系图模块
"""

from typing import Dict, Set


class DependencyGraph:
    """依赖关系图"""
    
    def __init__(self):
        self.dependencies: Dict[str, Set[str]] = {}  # file -> set of files it depends on
        self.dependents: Dict[str, Set[str]] = {}    # file -> set of files that depend on it
    
    def add_dependency(self, file_path: str, depends_on: str):
        """添加依赖关系"""
        if file_path not in self.dependencies:
            self.dependencies[file_path] = set()
        self.dependencies[file_path].add(depends_on)
        
        if depends_on not in self.dependents:
            self.dependents[depends_on] = set()
        self.dependents[depends_on].add(file_path)
    
    def get_dependents(self, file_path: str) -> Set[str]:
        """获取依赖于该文件的文件列表"""
        return self.dependents.get(file_path, set())
    
    def get_dependencies(self, file_path: str) -> Set[str]:
        """获取该文件依赖的文件列表"""
        return self.dependencies.get(file_path, set())
    
    def get_impact_files(self, file_path: str) -> Set[str]:
        """获取删除该文件会影响的所有文件（递归）"""
        impacted = set()
        to_process = {file_path}
        processed = set()
        
        while to_process:
            current = to_process.pop()
            if current in processed:
                continue
            processed.add(current)
            
            dependents = self.get_dependents(current)
            for dependent in dependents:
                if dependent != file_path:
                    impacted.add(dependent)
                    to_process.add(dependent)
        
        return impacted
