#!/usr/bin/env python3
"""
文件备份管理模块
"""

import os
import shutil
import hashlib
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional


@dataclass
class FileBackup:
    """文件备份记录"""
    original_path: str
    backup_path: str
    checksum: str
    timestamp: datetime = field(default_factory=datetime.now)


class FileBackupManager:
    """文件备份管理器"""
    
    def __init__(self, backup_dir: Optional[str] = None):
        self.backup_dir = backup_dir or tempfile.mkdtemp(prefix="coverage_backup_")
        self.backups: Dict[str, FileBackup] = {}
        self._ensure_backup_dir()
    
    def _ensure_backup_dir(self):
        """确保备份目录存在"""
        if not os.path.exists(self.backup_dir):
            os.makedirs(self.backup_dir, exist_ok=True)
    
    def _calculate_checksum(self, file_path: str) -> str:
        """计算文件校验和"""
        try:
            with open(file_path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except:
            return ""
    
    def backup_file(self, file_path: str) -> Optional[FileBackup]:
        """备份单个文件"""
        if not os.path.exists(file_path):
            return None
        
        # 计算相对路径
        abs_path = os.path.abspath(file_path)
        backup_file_path = os.path.join(
            self.backup_dir,
            abs_path.replace(os.sep, '_').replace(':', '_')
        )
        
        # 确保备份目录存在
        os.makedirs(os.path.dirname(backup_file_path), exist_ok=True)
        
        # 复制文件
        shutil.copy2(abs_path, backup_file_path)
        
        # 创建备份记录
        backup = FileBackup(
            original_path=abs_path,
            backup_path=backup_file_path,
            checksum=self._calculate_checksum(abs_path)
        )
        
        self.backups[abs_path] = backup
        return backup
    
    def backup_files(self, file_paths: List[str]) -> List[FileBackup]:
        """批量备份文件"""
        backups = []
        for file_path in file_paths:
            backup = self.backup_file(file_path)
            if backup:
                backups.append(backup)
        return backups
    
    def restore_file(self, file_path: str) -> bool:
        """恢复单个文件"""
        abs_path = os.path.abspath(file_path)
        if abs_path not in self.backups:
            return False
        
        backup = self.backups[abs_path]
        if os.path.exists(backup.backup_path):
            shutil.copy2(backup.backup_path, abs_path)
            return True
        return False
    
    def restore_all(self) -> List[str]:
        """恢复所有备份的文件"""
        restored = []
        for file_path in self.backups:
            if self.restore_file(file_path):
                restored.append(file_path)
        return restored
    
    def cleanup(self):
        """清理备份目录"""
        if os.path.exists(self.backup_dir):
            shutil.rmtree(self.backup_dir, ignore_errors=True)
        self.backups.clear()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()
