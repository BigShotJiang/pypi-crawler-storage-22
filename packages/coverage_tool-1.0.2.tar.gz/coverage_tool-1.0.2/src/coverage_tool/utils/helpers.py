#!/usr/bin/env python3
"""
辅助函数模块
"""

import os
import shutil
import re
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import List, Dict, Optional

from .file_backup import FileBackupManager


@contextmanager
def temporary_directory():
    """临时目录上下文管理器"""
    temp_dir = tempfile.mkdtemp()
    try:
        yield temp_dir
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def safe_delete_file(file_path: str, backup_manager: Optional[FileBackupManager] = None) -> bool:
    """安全删除文件（先备份）"""
    if not os.path.exists(file_path):
        return False
    
    # 先备份
    if backup_manager:
        backup_manager.backup_file(file_path)
    
    try:
        os.remove(file_path)
        return True
    except Exception as e:
        print(f"删除文件失败 {file_path}: {e}")
        return False


def find_files_by_patterns(directory: str, patterns: List[str]) -> List[str]:
    """根据多个模式查找文件"""
    found_files = set()
    path = Path(directory)
    
    for pattern in patterns:
        for file_path in path.rglob(pattern):
            if file_path.is_file():
                found_files.add(str(file_path))
    
    return sorted(list(found_files))


def parse_error_locations(errors: List[str], project_dir: str) -> Dict[str, List[int]]:
    """从错误信息中解析出错的文件和行号"""
    error_locations: Dict[str, List[int]] = {}
    
    # 各种编译错误模式
    patterns = [
        r'([^\s]+\.\w+):(\d+):',  # file:line:col
        r'([^\s]+\.\w+)\((\d+)\)',  # file(line)
        r'File "([^"]+)", line (\d+)',  # Python style
        r'([^\s]+\.\w+):(\d+)',  # file:line
    ]
    
    for error in errors:
        for pattern in patterns:
            matches = re.findall(pattern, error)
            for match in matches:
                if isinstance(match, tuple):
                    file_path, line_str = match
                else:
                    continue
                
                # 规范化路径
                if not os.path.isabs(file_path):
                    file_path = os.path.join(project_dir, file_path)
                file_path = os.path.normpath(file_path)
                
                if os.path.exists(file_path):
                    line_num = int(line_str)
                    if file_path not in error_locations:
                        error_locations[file_path] = []
                    error_locations[file_path].append(line_num)
    
    return error_locations
