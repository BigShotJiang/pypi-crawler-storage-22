#!/usr/bin/env python3
"""
日志记录器模块
"""

import json
from datetime import datetime
from dataclasses import dataclass
from typing import List, Dict, Optional, Any


class Logger:
    """日志记录器"""
    
    def __init__(self, verbose: bool = True, log_file: Optional[str] = None):
        self.verbose = verbose
        self.log_file = log_file
        self.logs: List[Dict[str, Any]] = []
    
    def log(self, level: str, message: str, **kwargs):
        """记录日志"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'level': level,
            'message': message,
            **kwargs
        }
        self.logs.append(log_entry)
        
        if self.verbose:
            print(f"[{level}] {message}")
        
        if self.log_file:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(log_entry, ensure_ascii=False) + '\n')
    
    def info(self, message: str, **kwargs):
        self.log('INFO', message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        self.log('WARNING', message, **kwargs)
    
    def error(self, message: str, **kwargs):
        self.log('ERROR', message, **kwargs)
    
    def debug(self, message: str, **kwargs):
        if self.verbose:
            self.log('DEBUG', message, **kwargs)
    
    def get_logs(self, level: Optional[str] = None) -> List[Dict[str, Any]]:
        """获取日志记录"""
        if level:
            return [log for log in self.logs if log['level'] == level]
        return self.logs.copy()
