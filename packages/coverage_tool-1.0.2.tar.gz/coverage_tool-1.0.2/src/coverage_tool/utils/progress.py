#!/usr/bin/env python3
"""
进度追踪器模块
"""

from datetime import datetime


class ProgressTracker:
    """进度追踪器"""
    
    def __init__(self, total_steps: int, description: str = ""):
        self.total_steps = total_steps
        self.current_step = 0
        self.description = description
        self.start_time = datetime.now()
    
    def update(self, step: int = 1, message: str = ""):
        """更新进度"""
        self.current_step += step
        percentage = (self.current_step / self.total_steps) * 100
        
        elapsed = (datetime.now() - self.start_time).total_seconds()
        if self.current_step > 0:
            estimated_total = elapsed / self.current_step * self.total_steps
            remaining = estimated_total - elapsed
        else:
            remaining = 0
        
        progress_msg = f"[{self.current_step}/{self.total_steps}] {percentage:.1f}%"
        if message:
            progress_msg += f" - {message}"
        if remaining > 0:
            progress_msg += f" (预计剩余: {remaining:.0f}s)"
        
        print(progress_msg)
    
    def finish(self, message: str = "完成"):
        """完成追踪"""
        elapsed = (datetime.now() - self.start_time).total_seconds()
        print(f"✓ {message} (耗时: {elapsed:.2f}s)")
