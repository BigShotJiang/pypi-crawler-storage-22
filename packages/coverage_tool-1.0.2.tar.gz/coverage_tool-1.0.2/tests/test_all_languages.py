#!/usr/bin/env python3
"""
测试所有语言的完整流程
"""

import sys
import os
import tempfile
import shutil

# 添加父目录到路径（以便导入主项目模块）
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from runners import RunnerFactory
from utils import Logger
from config import Language

def create_python_project(project_dir):
    """创建Python测试项目"""
    os.makedirs(project_dir, exist_ok=True)
    
    # 创建主文件
    with open(os.path.join(project_dir, "main.py"), 'w') as f:
        f.write("""
def add(a, b):
    return a + b

def subtract(a, b):
    return a - b
""")
    
    # 创建测试文件
    with open(os.path.join(project_dir, "test_main.py"), 'w') as f:
        f.write("""
import pytest
from main import add, subtract

def test_add():
    assert add(2, 3) == 5

def test_subtract():
    assert subtract(5, 3) == 2
""")
    return project_dir

def create_go_project(project_dir):
    """创建Go测试项目"""
    os.makedirs(project_dir, exist_ok=True)
    
    # 创建 go.mod
    with open(os.path.join(project_dir, "go.mod"), 'w') as f:
        f.write("""module testproject

go 1.21
""")
    
    # 创建主文件
    with open(os.path.join(project_dir, "main.go"), 'w') as f:
        f.write("""package main

func Add(a, b int) int {
    return a + b
}

func Subtract(a, b int) int {
    return a - b
}
""")
    
    # 创建测试文件
    with open(os.path.join(project_dir, "main_test.go"), 'w') as f:
        f.write("""package main

import "testing"

func TestAdd(t *testing.T) {
    if Add(2, 3) != 5 {
        t.Error(\"Add failed\")
    }
}

func TestSubtract(t *testing.T) {
    if Subtract(5, 3) != 2 {
        t.Error(\"Subtract failed\")
    }
}
""")
    return project_dir

def create_c_project(project_dir):
    """创建C测试项目"""
    os.makedirs(project_dir, exist_ok=True)
    
    # 创建主文件
    with open(os.path.join(project_dir, "main.c"), 'w') as f:
        f.write("""#include <stdio.h>

int add(int a, int b) {
    return a + b;
}

int subtract(int a, int b) {
    return a - b;
}
""")
    
    # 创建 Makefile
    with open(os.path.join(project_dir, "Makefile"), 'w') as f:
        f.write("""all:
	gcc -o test main.c

test: all
	./test
""")
    return project_dir

def test_language(lang, project_dir):
    """测试指定语言"""
    logger = Logger(verbose=False)
    runner = RunnerFactory.get_runner(lang, logger)
    
    print(f"\n{'='*60}")
    print(f"测试 {lang.value}")
    print(f"{'='*60}")
    print(f"项目目录: {project_dir}")
    
    # 测试编译
    print("\n1. 测试编译...")
    success, errors = runner.compile(project_dir)
    print(f"   编译结果: {'✓ 成功' if success else '✗ 失败'}")
    if errors:
        print(f"   错误数: {len(errors)}")
        for e in errors[:3]:
            print(f"     - {e}")
    
    # 测试运行
    print("\n2. 测试运行...")
    with tempfile.TemporaryDirectory() as temp_dir:
        output_file = os.path.join(temp_dir, 'junit.xml')
        result = runner.run_tests(project_dir, output_file)
        
        print(f"   运行成功: {'✓ 是' if result.success else '✗ 否'}")
        print(f"   返回码: {result.return_code}")
        print(f"   耗时: {result.duration:.2f}s")
        print(f"   覆盖率: {result.coverage_rate:.2f}%")
        print(f"   JUnit XML: {'✓ 生成' if result.junit_xml_path else '✗ 未生成'}")
        
        if result.junit_xml_path and os.path.exists(result.junit_xml_path):
            with open(result.junit_xml_path, 'r') as f:
                content = f.read()
            print(f"   XML大小: {len(content)} 字符")
    
    return True

def main():
    print("="*60)
    print("多语言测试执行验证")
    print("="*60)
    
    with tempfile.TemporaryDirectory() as base_dir:
        # 测试 Python
        python_dir = os.path.join(base_dir, "python")
        create_python_project(python_dir)
        test_language(Language.PYTHON, python_dir)
        
        # 测试 Go
        go_dir = os.path.join(base_dir, "go")
        create_go_project(go_dir)
        test_language(Language.GO, go_dir)
        
        # 测试 C
        c_dir = os.path.join(base_dir, "c")
        create_c_project(c_dir)
        test_language(Language.C, c_dir)
    
    print("\n" + "="*60)
    print("测试完成")
    print("="*60)

if __name__ == "__main__":
    main()
