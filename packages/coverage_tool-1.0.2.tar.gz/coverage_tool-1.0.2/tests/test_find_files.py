#!/usr/bin/env python3
"""
快速测试 find_files 修复
"""

import sys
import os
import tempfile

# 添加父目录到路径（以便导入主项目模块）
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from runners import PythonRunner
from utils import Logger
from config import LANGUAGE_CONFIGS
from config import Language

def test_find_files():
    """测试 find_files 方法"""
    print("测试 find_files 方法...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 创建一些测试文件
        os.makedirs(os.path.join(tmpdir, "subdir"))
        
        with open(os.path.join(tmpdir, "test1.py"), 'w') as f:
            f.write("# test1")
        with open(os.path.join(tmpdir, "subdir", "test2.py"), 'w') as f:
            f.write("# test2")
        with open(os.path.join(tmpdir, "main.py"), 'w') as f:
            f.write("# main")
        
        # 测试 runner
        logger = Logger(verbose=False)
        runner = PythonRunner(LANGUAGE_CONFIGS[Language.PYTHON], logger)
        
        # 测试不同的模式
        patterns = [
            "**/*.py",
            "*.py",
            "**/*test*.py",
        ]
        
        for pattern in patterns:
            try:
                files = runner.find_files(tmpdir, pattern)
                print(f"  ✓ 模式 '{pattern}': 找到 {len(files)} 个文件")
            except Exception as e:
                print(f"  ✗ 模式 '{pattern}': 错误 - {e}")
                return False
    
    return True

if __name__ == "__main__":
    if test_find_files():
        print("\n✓ find_files 测试通过！")
        sys.exit(0)
    else:
        print("\n✗ find_files 测试失败！")
        sys.exit(1)
