#!/usr/bin/env python3
"""
测试脚本 - 验证覆盖率工具的基本功能
"""

import os
import sys
import tempfile
import shutil

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from coverage_tool.core import Language, LANGUAGE_CONFIGS
from coverage_tool.runners import RunnerFactory
from coverage_tool.handlers import SmartCompilationHandler
from coverage_tool.test_removers import SmartTestRemoverFactory
from coverage_tool.parsers import JunitXMLParser
from coverage_tool.utils import Logger

def test_imports():
    """测试所有模块可以正常导入"""
    print("测试模块导入...")
    try:
        import coverage_tool.main as main
        import coverage_tool.core
        import coverage_tool.runners
        import coverage_tool.handlers
        import coverage_tool.test_removers
        import coverage_tool.parsers
        import coverage_tool.converters
        import coverage_tool.utils
        import coverage_tool.analyzers
        print("✓ 所有模块导入成功")
        return True
    except Exception as e:
        print(f"✗ 模块导入失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_runner_factory():
    """测试RunnerFactory"""
    print("\n测试RunnerFactory...")
    try:
        logger = Logger(verbose=False)
        for lang in Language:
            runner = RunnerFactory.get_runner(lang, logger)
            print(f"  ✓ {lang.value}: {type(runner).__name__}")
        return True
    except Exception as e:
        print(f"  ✗ RunnerFactory测试失败: {e}")
        return False

def test_remover_factory():
    """测试TestRemoverFactory"""
    print("\n测试TestRemoverFactory...")
    try:
        logger = Logger(verbose=False)
        with tempfile.TemporaryDirectory() as tmpdir:
            for lang in ['python', 'java', 'go', 'c', 'cpp']:
                remover = SmartTestRemoverFactory.get_remover(lang, tmpdir, logger)
                print(f"  ✓ {lang}: {type(remover).__name__}")
        return True
    except Exception as e:
        print(f"  ✗ TestRemoverFactory测试失败: {e}")
        return False

def test_compilation_handler():
    """测试CompilationHandler"""
    print("\n测试SmartCompilationHandler...")
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            handler = SmartCompilationHandler(tmpdir, Logger(verbose=False))
            print(f"  ✓ SmartCompilationHandler创建成功")
            handler.cleanup()
        return True
    except Exception as e:
        print(f"  ✗ SmartCompilationHandler测试失败: {e}")
        return False

def test_utils():
    """测试工具类"""
    print("\n测试工具类...")
    try:
        from coverage_tool.utils import FileBackupManager, DependencyGraph, Logger, ProgressTracker
        
        # 测试Logger
        logger = Logger(verbose=False)
        logger.info("测试信息")
        print("  ✓ Logger")
        
        # 测试FileBackupManager
        with tempfile.TemporaryDirectory() as tmpdir:
            backup_mgr = FileBackupManager()
            test_file = os.path.join(tmpdir, "test.txt")
            with open(test_file, 'w') as f:
                f.write("test")
            backup_mgr.backup_file(test_file)
            print("  ✓ FileBackupManager")
            backup_mgr.cleanup()
        
        # 测试DependencyGraph
        graph = DependencyGraph()
        graph.add_dependency("a.py", "b.py")
        dependents = graph.get_dependents("b.py")
        print("  ✓ DependencyGraph")
        
        # 测试ProgressTracker
        tracker = ProgressTracker(10, "测试")
        tracker.update(5)
        tracker.finish()
        print("  ✓ ProgressTracker")
        
        return True
    except Exception as e:
        print(f"  ✗ 工具类测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_junit_parser():
    """测试JUnit XML解析器"""
    print("\n测试JUnit XML解析器...")
    try:
        # 创建一个简单的JUnit XML
        xml_content = """<?xml version="1.0" encoding="UTF-8"?>
<testsuites name="Test Results" tests="2" failures="1" errors="0" skipped="0">
  <testsuite name="Test Suite" tests="2" failures="1" errors="0" skipped="0" time="1.0">
    <testcase name="test_pass" classname="test_class" time="0.5"/>
    <testcase name="test_fail" classname="test_class" time="0.5">
      <failure message="Test failed" type="failure"/>
    </testcase>
  </testsuite>
</testsuites>"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.xml', delete=False) as f:
            f.write(xml_content)
            xml_path = f.name
        
        report = JunitXMLParser.parse(xml_path)
        os.unlink(xml_path)
        
        assert report.total_tests == 2
        assert report.total_failures == 1
        assert report.pass_rate == 50.0
        
        print("  ✓ JUnit XML解析成功")
        return True
    except Exception as e:
        print(f"  ✗ JUnit XML解析测试失败: {e}")
        return False

def main():
    """运行所有测试"""
    print("=" * 60)
    print("覆盖率工具功能测试")
    print("=" * 60)
    
    tests = [
        ("模块导入", test_imports),
        ("RunnerFactory", test_runner_factory),
        ("TestRemoverFactory", test_remover_factory),
        ("CompilationHandler", test_compilation_handler),
        ("工具类", test_utils),
        ("JUnit解析器", test_junit_parser),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n{name}测试异常: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, False))
    
    print("\n" + "=" * 60)
    print("测试结果汇总")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✓ 通过" if result else "✗ 失败"
        print(f"{status}: {name}")
    
    print(f"\n总计: {passed}/{total} 通过")
    
    if passed == total:
        print("\n✓ 所有测试通过！")
        return 0
    else:
        print(f"\n✗ {total - passed} 个测试失败")
        return 1

if __name__ == "__main__":
    sys.exit(main())
