#!/usr/bin/env python3
"""
Failed Test Remover 详细功能测试
测试各个语言的测试删除器功能
"""

import sys
import os
import tempfile
import ast

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from coverage_tool.test_removers import (
    SmartTestRemoverFactory,
    BaseSmartTestRemover,
    PythonSmartTestRemover,
    JavaSmartTestRemover,
    GoSmartTestRemover,
    CSmartTestRemover,
    CPPSmartTestRemover,
    TestFunction,
)
from coverage_tool.utils import Logger


def test_python_remover():
    """测试Python测试删除器"""
    print("\n测试 PythonSmartTestRemover...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 创建测试文件
        test_file = os.path.join(tmpdir, "test_example.py")
        original_content = '''
import pytest

def test_pass():
    assert True

def test_fail():
    assert False, "This test fails"

class TestClass:
    def test_method_pass(self):
        assert True
    
    def test_method_fail(self):
        assert False

def helper_function():
    return 42
'''
        with open(test_file, 'w') as f:
            f.write(original_content)
        
        logger = Logger(verbose=False)
        remover = PythonSmartTestRemover(tmpdir, logger)
        
        # 测试查找测试函数
        test_funcs = remover.find_test_functions(test_file)
        print(f"  找到 {len(test_funcs)} 个测试函数")
        
        # 应该找到 4 个测试函数
        expected_tests = ['test_pass', 'test_fail', 'test_method_pass', 'test_method_fail']
        found_tests = [tf.name for tf in test_funcs]
        
        for test in expected_tests:
            if test in found_tests:
                print(f"  ✓ 找到测试函数: {test}")
            else:
                print(f"  ✗ 未找到测试函数: {test}")
                return False
        
        # 确保 helper_function 不被识别为测试
        if 'helper_function' in found_tests:
            print(f"  ✗ 错误识别 helper_function 为测试")
            return False
        else:
            print(f"  ✓ helper_function 正确被排除")
        
        # 测试删除特定测试函数
        fail_test = [tf for tf in test_funcs if tf.name == 'test_fail'][0]
        success = remover.remove_test_function(fail_test)
        
        if success:
            print(f"  ✓ 成功删除 test_fail")
        else:
            print(f"  ✗ 删除 test_fail 失败")
            return False
        
        # 验证删除后的内容
        with open(test_file, 'r') as f:
            new_content = f.read()
        
        if 'def test_fail()' not in new_content:
            print(f"  ✓ test_fail 已从文件中移除")
        else:
            print(f"  ✗ test_fail 仍存在于文件中")
            return False
        
        # 确保其他测试函数还在
        if 'def test_pass()' in new_content and 'def test_method_pass' in new_content:
            print(f"  ✓ 其他测试函数保留完整")
        else:
            print(f"  ✗ 其他测试函数被意外删除")
            return False
        
        # 验证语法正确性
        try:
            ast.parse(new_content)
            print(f"  ✓ 删除后文件语法正确")
        except SyntaxError as e:
            print(f"  ✗ 删除后文件语法错误: {e}")
            return False
    
    return True


def test_java_remover():
    """测试Java测试删除器"""
    print("\n测试 JavaSmartTestRemover...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "TestExample.java")
        original_content = '''
import org.junit.Test;
import static org.junit.Assert.*;

public class TestExample {
    
    @Test
    public void testPass() {
        assertTrue(true);
    }
    
    @Test
    public void testFail() {
        fail("This test fails");
    }
    
    @Test
    public void testError() {
        throw new RuntimeException("Error");
    }
    
    // Not a test
    public void helperMethod() {
        System.out.println("Helper");
    }
}
'''
        with open(test_file, 'w') as f:
            f.write(original_content)
        
        logger = Logger(verbose=False)
        remover = JavaSmartTestRemover(tmpdir, logger)
        
        # 测试查找测试方法
        test_funcs = remover.find_test_functions(test_file)
        print(f"  找到 {len(test_funcs)} 个测试方法")
        
        expected_tests = ['testPass', 'testFail', 'testError']
        found_tests = [tf.name for tf in test_funcs]
        
        for test in expected_tests:
            if test in found_tests:
                print(f"  ✓ 找到测试方法: {test}")
            else:
                print(f"  ✗ 未找到测试方法: {test}")
                return False
        
        # 确保 helperMethod 不被识别
        if 'helperMethod' in found_tests:
            print(f"  ✗ 错误识别 helperMethod 为测试")
            return False
        
        # 测试删除
        fail_test = [tf for tf in test_funcs if tf.name == 'testFail'][0]
        success = remover.remove_test_function(fail_test)
        
        if success:
            print(f"  ✓ 成功删除 testFail")
        else:
            print(f"  ✗ 删除 testFail 失败")
            return False
        
        # 验证
        with open(test_file, 'r') as f:
            new_content = f.read()
        
        if 'testFail' not in new_content:
            print(f"  ✓ testFail 已移除")
        else:
            print(f"  ✗ testFail 仍存在")
            return False
    
    return True


def test_go_remover():
    """测试Go测试删除器"""
    print("\n测试 GoSmartTestRemover...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "example_test.go")
        original_content = '''package example

import "testing"

func TestPass(t *testing.T) {
    t.Log("Pass")
}

func TestFail(t *testing.T) {
    t.Error("Fail")
}

func TestSkip(t *testing.T) {
    t.Skip("Skip")
}

// Not a test
func helperFunc() int {
    return 42
}
'''
        with open(test_file, 'w') as f:
            f.write(original_content)
        
        logger = Logger(verbose=False)
        remover = GoSmartTestRemover(tmpdir, logger)
        
        # 测试查找
        test_funcs = remover.find_test_functions(test_file)
        print(f"  找到 {len(test_funcs)} 个测试函数")
        
        expected_tests = ['TestPass', 'TestFail', 'TestSkip']
        found_tests = [tf.name for tf in test_funcs]
        
        for test in expected_tests:
            if test in found_tests:
                print(f"  ✓ 找到测试函数: {test}")
            else:
                print(f"  ✗ 未找到测试函数: {test}")
                return False
        
        if 'helperFunc' in found_tests:
            print(f"  ✗ 错误识别 helperFunc")
            return False
        
        # 测试删除
        fail_test = [tf for tf in test_funcs if tf.name == 'TestFail'][0]
        success = remover.remove_test_function(fail_test)
        
        if success:
            print(f"  ✓ 成功删除 TestFail")
        else:
            print(f"  ✗ 删除 TestFail 失败")
            return False
        
        # 验证
        with open(test_file, 'r') as f:
            new_content = f.read()
        
        if 'TestFail' not in new_content:
            print(f"  ✓ TestFail 已移除")
        else:
            print(f"  ✗ TestFail 仍存在")
            return False
    
    return True


def test_c_remover():
    """测试C测试删除器"""
    print("\n测试 CSmartTestRemover...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test_example.c")
        original_content = '''
#include <stdio.h>
#include <assert.h>

void test_pass() {
    assert(1 == 1);
}

void test_fail() {
    assert(1 == 0);
}

void test_another() {
    printf("Another test\\n");
}

// Not a test
void helper_function() {
    printf("Helper\\n");
}

int main() {
    test_pass();
    test_fail();
    test_another();
    return 0;
}
'''
        with open(test_file, 'w') as f:
            f.write(original_content)
        
        logger = Logger(verbose=False)
        remover = CSmartTestRemover(tmpdir, logger)
        
        # 测试查找
        test_funcs = remover.find_test_functions(test_file)
        print(f"  找到 {len(test_funcs)} 个测试函数")
        
        expected_tests = ['test_pass', 'test_fail', 'test_another']
        found_tests = [tf.name for tf in test_funcs]
        
        for test in expected_tests:
            if test in found_tests:
                print(f"  ✓ 找到测试函数: {test}")
            else:
                print(f"  ✗ 未找到测试函数: {test}")
                return False
        
        # 确保 helper_function 和 main 不被识别为测试
        non_tests = ['helper_function', 'main']
        for non_test in non_tests:
            if non_test in found_tests:
                print(f"  ✗ 错误识别 {non_test} 为测试")
                return False
        
        print(f"  ✓ helper_function 和 main 正确被排除")
        
        # 测试删除
        fail_test = [tf for tf in test_funcs if tf.name == 'test_fail'][0]
        success = remover.remove_test_function(fail_test)
        
        if success:
            print(f"  ✓ 成功删除 test_fail")
        else:
            print(f"  ✗ 删除 test_fail 失败")
            return False
        
        # 验证
        with open(test_file, 'r') as f:
            new_content = f.read()
        
        if 'void test_fail()' not in new_content:
            print(f"  ✓ test_fail 已移除")
        else:
            print(f"  ✗ test_fail 仍存在")
            return False
    
    return True


def test_cpp_remover():
    """测试C++测试删除器"""
    print("\n测试 CPPSmartTestRemover...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test_example.cpp")
        original_content = '''
#include <gtest/gtest.h>

TEST(TestSuite, TestPass) {
    EXPECT_TRUE(true);
}

TEST(TestSuite, TestFail) {
    EXPECT_TRUE(false);
}

TEST(AnotherSuite, TestAnother) {
    EXPECT_EQ(1, 1);
}

// Not a test
void helperFunction() {
    printf("Helper\\n");
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
'''
        with open(test_file, 'w') as f:
            f.write(original_content)
        
        logger = Logger(verbose=False)
        remover = CPPSmartTestRemover(tmpdir, logger)
        
        # 测试查找
        test_funcs = remover.find_test_functions(test_file)
        print(f"  找到 {len(test_funcs)} 个测试函数")
        
        # C++测试名称格式为 "SuiteName.TestName" (Google Test格式)
        expected_tests = ['TestSuite.TestPass', 'TestSuite.TestFail', 'AnotherSuite.TestAnother']
        found_tests = [tf.name for tf in test_funcs]
        
        for test in expected_tests:
            if test in found_tests:
                print(f"  ✓ 找到测试函数: {test}")
            else:
                print(f"  ✗ 未找到测试函数: {test}")
                return False
        
        # 确保 main 和 helperFunction 不被识别
        if 'main' in found_tests or 'helperFunction' in found_tests:
            print(f"  ✗ 错误识别非测试函数")
            return False
        
        print(f"  ✓ main 和 helperFunction 正确被排除")
        
        # 测试删除
        fail_test = [tf for tf in test_funcs if tf.name == 'TestSuite.TestFail'][0]
        success = remover.remove_test_function(fail_test)
        
        if success:
            print(f"  ✓ 成功删除 TestSuite_TestFail")
        else:
            print(f"  ✗ 删除 TestSuite_TestFail 失败")
            return False
        
        # 验证
        with open(test_file, 'r') as f:
            new_content = f.read()
        
        if 'TestFail' not in new_content:
            print(f"  ✓ TestFail 已移除")
        else:
            print(f"  ✗ TestFail 仍存在")
            return False
    
    return True


def test_remove_failed_tests_integration():
    """测试完整的 remove_failed_tests 流程"""
    print("\n测试完整流程 remove_failed_tests...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 创建Python项目
        test_file = os.path.join(tmpdir, "test_example.py")
        original_content = '''
import pytest

def test_pass():
    assert True

def test_fail_1():
    assert False, "First failure"

def test_fail_2():
    assert False, "Second failure"

def test_error():
    raise ValueError("Test error")
'''
        with open(test_file, 'w') as f:
            f.write(original_content)
        
        # 模拟JUnit报告
        from parsers import TestReport, TestSuite, TestCase, TestStatus
        
        # 创建测试用例
        test_cases = [
            TestCase(name="test_pass", classname="test_example", time=0.1, status=TestStatus.PASSED),
            TestCase(name="test_fail_1", classname="test_example", time=0.1, status=TestStatus.FAILED, failure_message="First failure"),
            TestCase(name="test_fail_2", classname="test_example", time=0.1, status=TestStatus.FAILED, failure_message="Second failure"),
            TestCase(name="test_error", classname="test_example", time=0.1, status=TestStatus.ERROR, error_message="Test error"),
        ]
        
        # 创建测试套件
        suite = TestSuite(
            name="test_suite",
            tests=4,
            failures=2,
            errors=1,
            skipped=0,
            time=0.4,
            test_cases=test_cases
        )
        
        # 创建测试报告
        report = TestReport(suites=[suite])
        
        logger = Logger(verbose=False)
        remover = SmartTestRemoverFactory.get_remover('python', tmpdir, logger)
        
        # 执行删除
        deleted_count, deleted_list = remover.remove_failed_tests(report)
        
        print(f"  删除数量: {deleted_count}")
        print(f"  删除列表: {deleted_list}")
        
        if deleted_count >= 3:  # 应该至少删除3个（2个fail + 1个error）
            print(f"  ✓ 成功删除失败的测试")
        else:
            print(f"  ✗ 删除数量不足")
            return False
        
        # 验证文件内容
        with open(test_file, 'r') as f:
            new_content = f.read()
        
        # 确保失败的测试被删除，通过的测试保留
        if 'def test_pass()' in new_content:
            print(f"  ✓ test_pass 保留")
        else:
            print(f"  ✗ test_pass 被意外删除")
            return False
        
        if 'def test_fail_1()' not in new_content and 'def test_fail_2()' not in new_content:
            print(f"  ✓ 失败的测试已删除")
        else:
            print(f"  ✗ 失败的测试仍存在")
            return False
        
        # 验证语法
        try:
            ast.parse(new_content)
            print(f"  ✓ 最终文件语法正确")
        except SyntaxError as e:
            print(f"  ✗ 最终文件语法错误: {e}")
            return False
    
    return True


def test_factory():
    """测试工厂类"""
    print("\n测试 SmartTestRemoverFactory...")
    
    logger = Logger(verbose=False)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 测试所有语言
        languages = ['python', 'java', 'go', 'c', 'cpp']
        expected_classes = [
            PythonSmartTestRemover,
            JavaSmartTestRemover,
            GoSmartTestRemover,
            CSmartTestRemover,
            CPPSmartTestRemover,
        ]
        
        for lang, expected_class in zip(languages, expected_classes):
            remover = SmartTestRemoverFactory.get_remover(lang, tmpdir, logger)
            if isinstance(remover, expected_class):
                print(f"  ✓ {lang}: {type(remover).__name__}")
            else:
                print(f"  ✗ {lang}: 期望 {expected_class.__name__}, 实际 {type(remover).__name__}")
                return False
        
        # 测试无效语言
        try:
            remover = SmartTestRemoverFactory.get_remover('invalid', tmpdir, logger)
            print(f"  ✗ 无效语言应抛出异常")
            return False
        except ValueError:
            print(f"  ✓ 无效语言正确抛出异常")
    
    return True


def main():
    """运行所有测试"""
    print("=" * 70)
    print("Failed Test Remover 详细功能测试")
    print("=" * 70)
    
    tests = [
        ("Python删除器", test_python_remover),
        ("Java删除器", test_java_remover),
        ("Go删除器", test_go_remover),
        ("C删除器", test_c_remover),
        ("C++删除器", test_cpp_remover),
        ("完整流程", test_remove_failed_tests_integration),
        ("工厂类", test_factory),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n{name} 测试异常: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, False))
    
    # 汇总结果
    print("\n" + "=" * 70)
    print("测试结果汇总")
    print("=" * 70)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✓ 通过" if result else "✗ 失败"
        print(f"{status}: {name}")
    
    print(f"\n总计: {passed}/{total} 通过")
    
    if passed == total:
        print("\n✓ 所有测试通过！")
        return 0
    else:
        print(f"\n✗ {total - passed} 个测试失败")
        return 1


if __name__ == "__main__":
    sys.exit(main())
