#!/usr/bin/env python3
"""
处理器包
包含编译处理和环境检查等功能
"""

from .compilation import SmartCompilationHandler
from .env_checker import EnvironmentChecker
from .coverage_injector import CoverageInjector

__all__ = [
    'SmartCompilationHandler',
    'EnvironmentChecker',
    'CoverageInjector',
]
