#!/usr/bin/env python3
"""
Coverage工具自动注入器
支持各语言覆盖率工具的自动检测、安装和参数注入
"""

import os
import subprocess
import xml.etree.ElementTree as ET
import re
from typing import Dict, List, Optional, Tuple
from pathlib import Path


class CoverageInjector:
    """覆盖率工具自动注入器"""
    
    def __init__(self):
        self.coverage_tools = {
            'python': {
                'command': 'coverage',
                'install_cmd': 'pip install coverage',
                'check_cmd': 'python3 -m coverage --version'
            },
            'go': {
                'command': 'go',
                'install_cmd': None,
                'check_cmd': 'go version'
            },
            'c': {
                'commands': ['gcc', 'g++'],
                'coverage_flags': ['-fprofile-arcs', '-ftest-coverage'],
                'check_cmd': 'gcc --version'
            },
            'cpp': {
                'commands': ['g++', 'clang++'],
                'coverage_flags': ['-fprofile-arcs', '-ftest-coverage'],
                'check_cmd': 'g++ --version'
            },
            'java': {
                'agent': 'jacocoagent.jar',
                'plugin_check': 'jacoco',
                'install_url': 'https://www.eclemma.org/jacoco/',
                'check_cmd': 'mvn -version'
            }
        }
    
    def check_coverage_tool_available(self, language: str) -> Tuple[bool, str]:
        """检查指定语言的覆盖率工具是否可用"""
        if language not in self.coverage_tools:
            return False, f"不支持的语言: {language}"
        
        tool_info = self.coverage_tools[language]
        
        if language in ['python', 'go']:
            cmd = tool_info['check_cmd']
            success, stdout, _ = self._run_command(cmd)
            if success:
                return True, stdout.strip()
            return False, f"{tool_info['command']} 未安装"
        
        elif language in ['c', 'cpp']:
            for compiler in tool_info['commands']:
                cmd = f"{compiler} --version"
                success, stdout, _ = self._run_command(cmd)
                if success:
                    return True, f"{compiler}: {stdout.strip().split(chr(10))[0]}"
            return False, "未找到C/C++编译器"
        
        elif language == 'java':
            success, stdout, _ = self._run_command(tool_info['check_cmd'])
            if success:
                return True, stdout.strip().split(chr(10))[0]
            return False, "Maven未安装"
        
        return False, "未知错误"
    
    def inject_coverage_flags(self, language: str, compile_commands: List[str]) -> List[str]:
        """为编译命令注入覆盖率标志"""
        if language not in ['c', 'cpp']:
            return compile_commands
        
        coverage_flags = self.coverage_tools[language]['coverage_flags']
        modified_commands = []
        
        for cmd in compile_commands:
            # 检测编译器命令并添加覆盖率标志
            modified_cmd = self._add_coverage_flags_to_command(cmd, coverage_flags)
            modified_commands.append(modified_cmd)
        
        return modified_commands
    
    def _add_coverage_flags_to_command(self, cmd: str, flags: List[str]) -> str:
        """为单个编译命令添加覆盖率标志"""
        # 常见的编译命令模式
        compiler_patterns = [
            r'(gcc|g\+\+|clang\+\+|cc|c\+\+)',
            r'(make|cmake)'
        ]
        
        for pattern in compiler_patterns:
            if re.search(pattern, cmd):
                # 在命令末尾添加覆盖率标志
                return f"{cmd} {' '.join(flags)}"
        
        # 如果没有匹配到编译命令，直接附加标志
        return f"{cmd} {' '.join(flags)}"
    
    def ensure_java_coverage(self, project_dir: str) -> Tuple[bool, str]:
        """确保Java项目配置了JaCoCo覆盖率工具"""
        pom_path = os.path.join(project_dir, 'pom.xml')
        
        if not os.path.exists(pom_path):
            return False, "pom.xml 不存在"
        
        # 检查JaCoCo是否已配置
        jacoco_configured, jacoco_config = self._check_jacoco_in_pom(pom_path)
        
        if jacoco_configured:
            return True, "JaCoCo已配置"
        
        # 自动配置JaCoCo
        return self._add_jacoco_to_pom(pom_path)
    
    def _check_jacoco_in_pom(self, pom_path: str) -> Tuple[bool, Optional[str]]:
        """检查pom.xml中是否已配置JaCoCo"""
        try:
            ns = self._get_pom_namespaces(pom_path)

            # 使用命名空间查找plugins
            plugins_xpath = './/maven:plugin[maven:artifactId]' if ns else './/plugin'
            plugins = ET.parse(pom_path).getroot().findall(plugins_xpath)

            for plugin in plugins:
                if ns:
                    artifact_id = plugin.find('maven:artifactId', ns)
                else:
                    artifact_id = plugin.find('artifactId')
                if artifact_id is not None and artifact_id.text and 'jacoco' in artifact_id.text.lower():
                    return True, ET.tostring(plugin, encoding='unicode')

            return False, None

        except Exception:
            return False, None
    
    def _add_jacoco_to_pom(self, pom_path: str) -> Tuple[bool, str]:
        """自动添加JaCoCo配置到pom.xml"""
        backup_path = pom_path + '.bak'
        try:
            with open(pom_path, 'r', encoding='utf-8') as f:
                original_content = f.read()
            with open(backup_path, 'w', encoding='utf-8') as f:
                f.write(original_content)

            jacoco_str = self._get_jacoco_plugin_xml_string()

            plugins_match = re.search(r'<plugins>', original_content, re.IGNORECASE)

            if plugins_match:
                end_pos = plugins_match.end()
                jacoco_block = '\n            ' + jacoco_str.strip() + original_content[end_pos:]
                new_content = original_content[:end_pos] + jacoco_block
            elif '<build>' in original_content:
                match = re.search(r'<build>', original_content, re.IGNORECASE)
                if match:
                    end_pos = match.end()
                    jacoco_block = f'''
        <plugins>
            {jacoco_str}
        </plugins>
    ''' + original_content[end_pos:]
                    new_content = original_content[:end_pos] + jacoco_block
                else:
                    return False, "无法找到build标签"
            else:
                match = re.search(r'<project[^>]*>', original_content, re.IGNORECASE)
                if match:
                    end_pos = match.end()
                    jacoco_block = '''
    <build>
        <plugins>
            <plugin>
                <groupId>org.jacoco</groupId>
                <artifactId>jacoco-maven-plugin</artifactId>
                <version>0.8.11</version>
                <executions>
                    <execution>
                        <id>prepare-agent</id>
                        <goals>
                            <goal>prepare-agent</goal>
                        </goals>
                    </execution>
                    <execution>
                        <id>report</id>
                        <goals>
                            <goal>report</goal>
                        </goals>
                    </execution>
                    <execution>
                        <id>check</id>
                        <goals>
                            <goal>check</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
''' + original_content[end_pos:]
                    new_content = original_content[:end_pos] + jacoco_block
                else:
                    return False, "无法找到project标签"

            with open(pom_path, 'w', encoding='utf-8') as f:
                f.write(new_content)

            return True, "JaCoCo插件已自动添加到pom.xml（已备份原文件）"

        except Exception as e:
            if os.path.exists(backup_path):
                with open(backup_path, 'r', encoding='utf-8') as f:
                    original_content = f.read()
                with open(pom_path, 'w', encoding='utf-8') as f:
                    f.write(original_content)
            return False, f"添加JaCoCo配置失败: {str(e)}"

    def _get_pom_namespaces(self, pom_path: str) -> Dict[str, str]:
        """从pom.xml提取命名空间"""
        try:
            with open(pom_path, 'r', encoding='utf-8') as f:
                content = f.read()
            # 查找xmlns声明
            match = re.search(r'xmlns(?::\w+)?="([^"]+)"', content)
            if match:
                ns_uri = match.group(1)
                return {'maven': ns_uri}
        except Exception:
            pass
        return {}

    def _get_jacoco_plugin_xml(self) -> ET.Element:
        """生成JaCoCo插件配置XML（使用可配置的版本）"""
        plugin = ET.Element('plugin')

        groupId = ET.SubElement(plugin, 'groupId')
        groupId.text = 'org.jacoco'

        artifactId = ET.SubElement(plugin, 'artifactId')
        artifactId.text = 'jacoco-maven-plugin'

        version = ET.SubElement(plugin, 'version')
        version.text = self._get_jacoco_version()

        executions = ET.SubElement(plugin, 'executions')

        for goal_id, goal_name in [('prepare-agent', 'prepare-agent'), ('report', 'report'), ('check', 'check')]:
            execution = ET.SubElement(executions, 'execution')
            executionId = ET.SubElement(execution, 'id')
            executionId.text = goal_id
            goals = ET.SubElement(execution, 'goals')
            goal = ET.SubElement(goals, 'goal')
            goal.text = goal_name

        return plugin

    def _get_jacoco_plugin_xml_string(self) -> str:
        """生成JaCoCo插件配置XML字符串（避免命名空间问题）"""
        version = self._get_jacoco_version()
        return f'''<plugin>
                <groupId>org.jacoco</groupId>
                <artifactId>jacoco-maven-plugin</artifactId>
                <version>{version}</version>
                <executions>
                    <execution>
                        <id>prepare-agent</id>
                        <goals>
                            <goal>prepare-agent</goal>
                        </goals>
                    </execution>
                    <execution>
                        <id>report</id>
                        <goals>
                            <goal>report</goal>
                        </goals>
                    </execution>
                    <execution>
                        <id>check</id>
                        <goals>
                            <goal>check</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>'''

    def _get_jacoco_version(self) -> str:
        """获取JaCoCo版本，优先使用环境变量或默认版本"""
        import os
        return os.environ.get('JACOCO_VERSION', '0.8.11')
    
    def inject_javaagent(self, project_dir: str, output_dir: str) -> Tuple[bool, str, Optional[str]]:
        """为Java测试添加javaagent参数"""
        jacoco_agent_path = self._find_jacoco_agent()
        
        if not jacoco_agent_path:
            return False, "未找到JaCoCo agent", None
        
        # 检查Maven Surefire配置
        pom_path = os.path.join(project_dir, 'pom.xml')
        if os.path.exists(pom_path):
            success, message = self._configure_surefire_javaagent(pom_path, jacoco_agent_path)
            if success:
                return True, message, jacoco_agent_path
        
        # 返回agent路径，由调用方处理
        return True, f"JaCoCo agent路径: {jacoco_agent_path}", jacoco_agent_path
    
    def _find_jacoco_agent(self) -> Optional[str]:
        """查找JaCoCo agent.jar路径（支持多种策略）"""
        import urllib.request
        import tarfile
        import io

        # 1. 优先检查环境变量
        env_path = os.environ.get('JACOCO_AGENT_PATH')
        if env_path and os.path.exists(env_path):
            return env_path

        # 2. 常见路径
        possible_paths = [
            '~/.m2/repository/org/jacoco/jacoco/latest/jacocoagent.jar',
            '~/.m2/repository/org/jacoco/jacoco/0.8.11/jacocoagent.jar',
            '~/.m2/repository/org/jacoco/jacoco/0.8.10/jacocoagent.jar',
            '/usr/share/java/jacocoagent.jar',
        ]

        for path in possible_paths:
            expanded = os.path.expanduser(path)
            if os.path.exists(expanded):
                return expanded

        # 3. 递归查找Maven仓库
        m2_path = os.path.expanduser('~/.m2/repository/org/jacoco')
        if os.path.exists(m2_path):
            jacoco_versions = []
            for item in os.listdir(m2_path):
                item_path = os.path.join(m2_path, item)
                if os.path.isdir(item_path):
                    for version in os.listdir(item_path):
                        if version.startswith('0.8.'):
                            jacoco_versions.append(version)
            jacoco_versions.sort(key=lambda v: [int(x) for x in v.split('.')])
            for version in reversed(jacoco_versions):
                agent_path = os.path.join(m2_path, 'jacoco', version, 'jacocoagent.jar')
                if os.path.exists(agent_path):
                    return agent_path

        # 4. 下载JaCoCo（兜底策略）
        jacoco_version = os.environ.get('JACOCO_VERSION', '0.8.11')
        download_url = f"https://repo1.maven.org/maven2/org/jacoco/jacoco/{jacoco_version}/jacoco-{jacoco_version}.zip"
        m2_agent = os.path.expanduser(f'~/.m2/repository/org/jacoco/jacoco/{jacoco_version}/jacocoagent.jar')

        try:
            if not os.path.exists(m2_agent):
                os.makedirs(os.path.dirname(m2_agent), exist_ok=True)
                urllib.request.urlretrieve(download_url.replace('.zip', '.jar'), m2_agent)
            if os.path.exists(m2_agent):
                return m2_agent
        except Exception:
            pass

        return None
    
    def _configure_surefire_javaagent(self, pom_path: str, agent_path: str) -> Tuple[bool, str]:
        """在pom.xml中配置Surefire的javaagent"""
        try:
            tree = ET.parse(pom_path)
            root = tree.getroot()
            
            # 查找pluginManagement或plugins中的surefire配置
            surefire_configs = root.findall('.//maven:plugin[maven:artifactId="maven-surefire-plugin"]', 
                                           {'maven': 'http://maven.apache.org/POM/4.0.0'})
            
            if not surefire_configs:
                surefire_configs = root.findall('.//plugin[artifactId="maven-surefire-plugin"]')
            
            for surefire in surefire_configs:
                configuration = surefire.find('maven:configuration', {'maven': 'http://maven.apache.org/POM/4.0.0'})
                if configuration is None:
                    configuration = surefire.find('configuration')
                
                if configuration is None:
                    configuration = ET.SubElement(surefire, 'configuration')
                
                # 添加argLine元素
                argLine = configuration.find('argLine')
                if argLine is None:
                    argLine = ET.SubElement(configuration, 'argLine')
                    argLine.text = f'-javaagent:{agent_path}'
                else:
                    # 追加javaagent到现有argLine
                    argLine.text = f'{argLine.text} -javaagent:{agent_path}'
                
                tree.write(pom_path, encoding='UTF-8', xml_declaration=False)
                
                # 修复XML声明
                with open(pom_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                with open(pom_path, 'w', encoding='utf-8') as f:
                    f.write('<?xml version="1.0" encoding="UTF-8"?>\n' + content)
                
                return True, "已配置Surefire javaagent"
            
            return True, "未找到Surefire插件配置，请在pom.xml中手动添加javaagent参数"
            
        except Exception as e:
            return False, f"配置Surefire javaagent失败: {str(e)}"
    
    def _run_command(self, cmd: str) -> Tuple[bool, str, str]:
        """运行命令"""
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            return result.returncode == 0, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return False, "", "命令执行超时"
        except Exception as e:
            return False, "", str(e)
    
    def get_coverage_report_paths(self, language: str, project_dir: str) -> Dict[str, str]:
        """获取各语言覆盖率报告的可能路径"""
        reports = {}
        
        if language == 'python':
            reports = {
                'html': os.path.join(project_dir, 'htmlcov', 'index.html'),
                'xml': os.path.join(project_dir, 'coverage.xml'),
                'data': os.path.join(project_dir, '.coverage')
            }
        elif language == 'go':
            reports = {
                'profile': os.path.join(project_dir, 'coverage.out'),
                'html': os.path.join(project_dir, 'coverage.html')
            }
        elif language in ['c', 'cpp']:
            reports = {
                'gcov': os.path.join(project_dir, '*.gcov'),
                'lcov': os.path.join(project_dir, 'coverage.info'),
                'html': os.path.join(project_dir, 'lcov', 'index.html')
            }
        elif language == 'java':
            reports = {
                'jacoco': os.path.join(project_dir, 'target', 'site', 'jacoco', 'index.html'),
                'xml': os.path.join(project_dir, 'target', 'site', 'jacoco', 'jacoco.xml')
            }
        
        return reports
