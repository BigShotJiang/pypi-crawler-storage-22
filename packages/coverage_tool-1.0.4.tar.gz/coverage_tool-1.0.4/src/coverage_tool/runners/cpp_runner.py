#!/usr/bin/env python3
"""
C++单测运行器
"""

import os
import subprocess
import re
from typing import List

from coverage_tool.converters import JUnitReportConverter
from .base import BaseRunner, RunResult, CoverageExtractor
from coverage_tool.handlers.coverage_injector import CoverageInjector


class CPPRunner(BaseRunner):
    """C++单测运行器"""
    
    def __init__(self, config, logger=None):
        super().__init__(config=config, logger=logger)
        self.injector = CoverageInjector()
    
    def _inject_coverage_flags_to_makefile(self, target_dir: str) -> bool:
        """自动修改Makefile添加覆盖率编译标志"""
        makefile_paths = [
            os.path.join(target_dir, 'Makefile'),
            os.path.join(target_dir, 'makefile'),
            os.path.join(target_dir, 'GNUmakefile')
        ]
        
        coverage_flags = '-fprofile-arcs -ftest-coverage'
        
        for makefile_path in makefile_paths:
            if os.path.exists(makefile_path):
                try:
                    with open(makefile_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # 检查是否已添加覆盖率标志
                    if '-fprofile-arcs' in content:
                        return True
                    
                    # 修改CFLAGS和CXXFLAGS
                    modified_content = content
                    
                    # 替换或添加CXXFLAGS
                    if 'CXXFLAGS' in modified_content:
                        modified_content = re.sub(
                            r'(CXXFLAGS\s*[=:]\s*)(.*)',
                            r'\1\2 ' + coverage_flags,
                            modified_content
                        )
                    else:
                        modified_content = modified_content + f'\nCXXFLAGS += {coverage_flags}\n'
                    
                    # 也处理CFLAGS
                    if 'CFLAGS' in modified_content:
                        modified_content = re.sub(
                            r'(CFLAGS\s*[=:]\s*)(.*)',
                            r'\1\2 ' + coverage_flags,
                            modified_content
                        )
                    else:
                        modified_content = modified_content + f'\nCFLAGS += {coverage_flags}\n'
                    
                    # 替换或添加LDFLAGS
                    if 'LDFLAGS' in modified_content:
                        modified_content = re.sub(
                            r'(LDFLAGS\s*[=:]\s*)(.*)',
                            r'\1\2 -lgcov',
                            modified_content
                        )
                    else:
                        modified_content = modified_content + f'\nLDFLAGS += -lgcov\n'
                    
                    with open(makefile_path, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    
                    self.logger.info(f"[覆盖率] 已自动修改Makefile添加覆盖率标志")
                    return True
                    
                except Exception as e:
                    self.logger.warning(f"[覆盖率] 修改Makefile失败: {e}")
        
        return False
    
    def run_tests(self, target_dir: str, output_file: str) -> RunResult:
        """运行C++测试"""
        # 自动注入覆盖率编译标志
        self._inject_coverage_flags_to_makefile(target_dir)
        
        # 尝试使用make运行测试
        cmd = "make test"
        result = self._run_command(cmd, target_dir)
        
        # 尝试转换输出为JUnit XML
        if result.stdout or result.stderr:
            try:
                xml_content = JUnitReportConverter.convert_generic_output(
                    result.stdout + result.stderr, 'gtest'
                )
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(xml_content)
                result.junit_xml_path = output_file
            except Exception as e:
                self.logger.error(f"转换C++测试输出失败: {e}")
        
        result.coverage_rate = self.get_coverage(output_file)
        
        return result
    
    def get_coverage(self, output_file: str) -> float:
        """获取C++覆盖率（gcov/lcov）"""
        temp_dir = os.path.dirname(output_file) if output_file else "."
        
        coverage_files = [
            os.path.join(temp_dir, "coverage.out"),
            os.path.join(temp_dir, "coverage.txt"),
            os.path.join(os.getcwd(), "coverage.out"),
        ]
        
        for cov_file in coverage_files:
            if os.path.exists(cov_file):
                return CoverageExtractor.extract_from_coverage_out(cov_file, 'cpp')
        
        return 0.0
    
    def compile(self, target_dir: str) -> tuple[bool, list[str]]:
        """编译C++项目（带覆盖率）"""
        # 自动注入覆盖率编译标志
        self._inject_coverage_flags_to_makefile(target_dir)
        
        cmd = "make"
        result = self._run_command(cmd, target_dir)
        
        errors = []
        if not result.success:
            for line in result.stderr.split('\n'):
                if 'error:' in line.lower() or 'undefined reference' in line.lower():
                    errors.append(line.strip())
        
        return result.success, errors
