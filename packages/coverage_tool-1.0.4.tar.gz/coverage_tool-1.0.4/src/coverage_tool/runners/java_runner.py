#!/usr/bin/env python3
"""
Java单测运行器
"""

import os
import glob
import subprocess
import xml.etree.ElementTree as ET
from typing import List, Tuple, Optional

from .base import BaseRunner, RunResult, CoverageExtractor
from coverage_tool.handlers import CoverageInjector


class JavaRunner(BaseRunner):
    """Java单测运行器"""
    
    def __init__(self, config, logger=None):
        super().__init__(config=config, logger=logger)
        self.injector = CoverageInjector()

    def _ensure_jacoco(self, target_dir: str) -> Tuple[bool, str]:
        """确保JaCoCo已配置"""
        pom_path = os.path.join(target_dir, 'pom.xml')
        
        if not os.path.exists(pom_path):
            self.logger.warning("未找到pom.xml，无法自动配置JaCoCo")
            return False, "pom.xml 不存在"
        
        # 检查JaCoCo是否已配置
        jacoco_configured, jacoco_config = self.injector._check_jacoco_in_pom(pom_path)
        
        if jacoco_configured:
            self.logger.info("JaCoCo已配置")
            return True, "JaCoCo已配置"
        
        # 自动添加JaCoCo配置
        self.logger.info("未检测到JaCoCo配置，正在自动添加...")
        success, message = self.injector._add_jacoco_to_pom(pom_path)
        
        if success:
            self.logger.info(f"✓ {message}")
        else:
            self.logger.warning(f"✗ {message}")
        
        return success, message

    def _configure_javaagent(self, target_dir: str) -> Tuple[bool, str, Optional[str]]:
        """配置javaagent参数"""
        jacoco_agent_path = self.injector._find_jacoco_agent()
        
        if not jacoco_agent_path:
            self.logger.warning("未找到JaCoCo agent，将尝试使用mvn jacoco:report")
            return True, "将使用Maven插件", None
        
        pom_path = os.path.join(target_dir, 'pom.xml')
        if os.path.exists(pom_path):
            success, message = self.injector._configure_surefire_javaagent(pom_path, jacoco_agent_path)
            if success:
                self.logger.info(f"✓ {message}")
                return True, message, jacoco_agent_path
        
        return True, "javaagent配置跳过", jacoco_agent_path

    def run_tests(self, target_dir: str, output_file: str) -> RunResult:
        """运行Java测试（自动注入JaCoCo覆盖率）"""
        # 自动配置JaCoCo
        jacoco_success, jacoco_message = self._ensure_jacoco(target_dir)
        
        # 配置javaagent
        agent_success, agent_message, agent_path = self._configure_javaagent(target_dir)
        
        # 构建mvn命令
        mvn_cmd = "mvn clean test"
        
        # 如果JaCoCo已配置，添加jacoco:report目标
        if jacoco_success:
            mvn_cmd = "mvn clean test jacoco:report"
        
        self.logger.info(f"[测试命令] {mvn_cmd}")
        
        result = self._run_command(mvn_cmd, target_dir)

        surefire_report = os.path.join(target_dir, "target", "surefire-reports")
        if os.path.exists(surefire_report):
            self._convert_surefire_reports(surefire_report, output_file)

        if not os.path.exists(output_file):
            junit_files = glob.glob(os.path.join(surefire_report, "*.xml"))
            if junit_files:
                self._merge_junit_reports(junit_files, output_file)

        result.junit_xml_path = output_file if os.path.exists(output_file) else None
        result.coverage_rate = self.get_coverage(target_dir)

        return result

    def _merge_junit_reports(self, junit_files: List[str], output_file: str):
        """合并多个JUnit XML报告为一个"""
        total_tests = 0
        total_failures = 0
        total_errors = 0
        total_skipped = 0
        test_suites = []

        for junit_file in junit_files:
            try:
                tree = ET.parse(junit_file)
                root = tree.getroot()

                if root.tag == 'testsuites':
                    for suite in root.findall('testsuite'):
                        test_suites.append(suite)
                elif root.tag == 'testsuite':
                    test_suites.append(root)
            except Exception as e:
                self.logger.warning(f"解析JUnit报告失败: {junit_file}: {e}")

        xml_declaration = '<?xml version="1.0" encoding="UTF-8"?>\n'
        testsuites_elem = ET.Element('testsuites')

        for suite in test_suites:
            testsuites_elem.append(suite)
            total_tests += int(suite.get('tests', 0))
            total_failures += int(suite.get('failures', 0))
            total_errors += int(suite.get('errors', 0))
            total_skipped += int(suite.get('skipped', 0))

        testsuites_elem.set('name', 'Merged Test Results')
        testsuites_elem.set('tests', str(total_tests))
        testsuites_elem.set('failures', str(total_failures))
        testsuites_elem.set('errors', str(total_errors))
        testsuites_elem.set('skipped', str(total_skipped))

        tree = ET.ElementTree(testsuites_elem)
        tree.write(output_file, encoding='UTF-8', xml_declaration=False)

        with open(output_file, 'r', encoding='utf-8') as f:
            content = f.read()
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(xml_declaration + content)

    def _convert_surefire_reports(self, surefire_dir: str, output_file: str):
        """转换Surefire报告为JUnit XML"""
        junit_files = glob.glob(os.path.join(surefire_dir, "TEST-*.xml"))
        if junit_files:
            self._merge_junit_reports(junit_files, output_file)

    def get_coverage(self, output_file: str) -> float:
        """获取Java覆盖率（JaCoCo）"""
        target_dir = os.path.dirname(output_file) if output_file else "."
        jacoco_html = os.path.join(target_dir, "target", "site", "jacoco", "index.html")
        return CoverageExtractor.extract_from_jacoco(jacoco_html)

    def compile(self, target_dir: str) -> Tuple[bool, List[str]]:
        """编译Java项目"""
        cmd = "mvn compile"
        result = self._run_command(cmd, target_dir)

        errors = []
        if not result.success:
            for line in result.stderr.split('\n'):
                if 'error:' in line.lower() or 'cannot find symbol' in line.lower():
                    errors.append(line.strip())

        return result.success, errors
