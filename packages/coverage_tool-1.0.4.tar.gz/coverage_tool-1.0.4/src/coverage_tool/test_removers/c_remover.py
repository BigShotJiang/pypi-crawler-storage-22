#!/usr/bin/env python3
"""
C测试删除器
使用正则表达式解析C测试文件
"""

import re
from typing import List, Optional, Tuple
from pathlib import Path

from coverage_tool.test_removers.base import BaseSmartTestRemover, TestFunction
from coverage_tool.parsers import TestCase


class CSmartTestRemover(BaseSmartTestRemover):
    """C智能测试删除器"""
    
    # C语言测试文件匹配模式
    C_TEST_PATTERNS = [
        "test_*.c",
        "*_test.c",
        "*test*.c",
        "check_*.c",
        "tests/*.c",
        "*_tests.c",
        "tests_*.c",
    ]
    
    # 预编译正则表达式
    TEST_FUNC_PATTERNS = [
        re.compile(r'^(void|int|bool)\s+(test_\w+)\s*\([^)]*\)\s*\{', re.MULTILINE),
        re.compile(r'^(void|int|bool)\s+(check_\w+)\s*\([^)]*\)\s*\{', re.MULTILINE),
        re.compile(r'^(void|int|bool)\s+(\w+_test)\s*\([^)]*\)\s*\{', re.MULTILINE),
    ]
    
    def _is_build_failure(self, test_name: str) -> bool:
        """检查是否是C构建失败的特殊测试名称"""
        build_failure_patterns = [
            '[build failed]',
            '[compilation failed]',
            'error:',
            'undefined reference',
            'linker error',
            'compilation error',
            'syntax error',
        ]
        return any(pattern in test_name for pattern in build_failure_patterns)
    
    def remove_all_tests_in_package(self, package_path: str) -> Tuple[int, List[str]]:
        """
        删除指定包/目录内的所有测试文件（C使用目录方式）
        用于处理目录级编译错误
        """
        return self.remove_all_tests_in_directory(package_path)
    
    def remove_all_tests_in_directory(self, directory_path: str) -> Tuple[int, List[str]]:
        """
        删除指定目录内的所有测试文件
        用于处理C/C++目录级编译错误
        """
        deleted_count = 0
        deleted_files = []
        
        # 按完整路径搜索
        dir_path = Path(self.project_dir) / directory_path
        
        if dir_path.exists() and dir_path.is_dir():
            test_files = []
            for pattern in self.C_TEST_PATTERNS:
                test_files.extend(dir_path.glob(pattern))
            # 去重
            test_files = list(set(test_files))
            
            if test_files:
                self.logger.info(f"[编译错误] 在目录 {dir_path} 发现 {len(test_files)} 个C测试文件")
                
                for test_file in test_files:
                    try:
                        # 备份文件
                        self.backup_manager.backup_file(str(test_file))
                        # 删除文件
                        test_file.unlink()
                        deleted_count += 1
                        deleted_files.append(str(test_file))
                        self.logger.info(f"[编译错误] ✓ 已删除C测试文件: {test_file}")
                    except Exception as e:
                        self.logger.error(f"[编译错误] 删除文件失败: {test_file}: {e}")
                
                return deleted_count, deleted_files
        
        # 如果没找到，尝试将classname作为子目录搜索
        parts = directory_path.replace('.', '/').split('/')
        for i in range(len(parts)):
            subdir = '/'.join(parts[i:])
            search_dir = Path(self.project_dir) / subdir
            if search_dir.exists() and search_dir.is_dir():
                test_files = []
                for pattern in self.C_TEST_PATTERNS:
                    test_files.extend(search_dir.glob(pattern))
                test_files = list(set(test_files))
                
                if test_files:
                    self.logger.info(f"[编译错误] 在目录 {search_dir} 发现 {len(test_files)} 个C测试文件")
                    
                    for test_file in test_files:
                        try:
                            self.backup_manager.backup_file(str(test_file))
                            test_file.unlink()
                            deleted_count += 1
                            deleted_files.append(str(test_file))
                            self.logger.info(f"[编译错误] ✓ 已删除C测试文件: {test_file}")
                        except Exception as e:
                            self.logger.error(f"[编译错误] 删除文件失败: {test_file}: {e}")
                    
                    return deleted_count, deleted_files
        
        return deleted_count, deleted_files
    
    def find_test_functions(self, file_path: str) -> List[TestFunction]:
        """查找C测试函数"""
        test_functions = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            for pattern in self.TEST_FUNC_PATTERNS:
                for match in pattern.finditer(content):
                    func_name = match.group(2)
                    start_pos = match.start()
                    start_line = content[:start_pos].count('\n') + 1
                    
                    # 找到函数结束
                    brace_count = 0
                    end_pos = match.end()
                    for i, char in enumerate(content[match.end():]):
                        if char == '{':
                            brace_count += 1
                        elif char == '}':
                            if brace_count == 0:
                                end_pos = match.end() + i + 1
                                break
                            brace_count -= 1
                    
                    end_line = content[:end_pos].count('\n') + 1
                    
                    test_func = TestFunction(
                        name=func_name,
                        file_path=file_path,
                        start_line=start_line,
                        end_line=end_line
                    )
                    test_functions.append(test_func)
        
        except Exception as e:
            self.logger.error(f"解析C文件失败 {file_path}: {e}")
        
        return test_functions
    
    def find_test_file(self, test_case: TestCase) -> Optional[str]:
        """查找C测试文件（增强版）"""
        classname = test_case.classname
        test_name = test_case.name

        # 处理特殊的构建失败错误
        if self._is_build_failure(test_name):
            self.logger.info(f"[编译错误] 检测到C编译失败: {test_name}")
            return self._find_c_test_file_from_directory(classname)

        # 提取基础方法名
        base_name = test_name.split('[')[0]

        # 1. 尝试多种文件路径模式
        test_patterns = [
            f"{classname}_test.c",
            f"test_{classname}.c",
            f"tests/{classname}_test.c",
            f"check_{classname}.c",
            f"{classname}_test.h",
        ]

        for pattern in test_patterns:
            file_path = Path(self.project_dir) / pattern
            if file_path.exists():
                return str(file_path)

        # 2. 通过内容搜索测试函数
        result = self._search_test_file_by_content(base_name, classname)
        if result:
            return result

        return None

    def _find_c_test_file_from_directory(self, directory_path: str) -> Optional[str]:
        """从目录路径查找C测试文件"""
        search_dirs = [directory_path]
        
        if '.' in directory_path:
            search_dirs.append(directory_path.replace('.', '/'))
        
        for search_dir in search_dirs:
            parts = search_dir.replace('.', '/').split('/')
            for i in range(len(parts)):
                subdir = '/'.join(parts[i:])
                test_dir = Path(self.project_dir) / subdir
                
                if test_dir.exists() and test_dir.is_dir():
                    for pattern in self.C_TEST_PATTERNS:
                        for test_file in test_dir.glob(pattern):
                            if test_file.exists():
                                self.logger.info(f"[编译错误] 找到目录 {search_dir} 的测试文件: {test_file}")
                                return str(test_file)
        
        return None

    def _search_test_file_by_content(self, base_name: str, classname: str) -> Optional[str]:
        """通过测试方法内容搜索C测试文件"""
        for test_file in Path(self.project_dir).rglob("*test*.c"):
            try:
                with open(test_file, 'r', encoding='utf-8') as f:
                    content = f.read()

                # 匹配 C 测试函数（classname 是文件名，base_name 是函数名）
                patterns = [
                    rf'void\s+{re.escape(base_name)}\s*\(',
                    rf'void\s+(?:test_|check_){re.escape(base_name)}\s*\(',
                    rf'int\s+{re.escape(base_name)}_test\s*\(',
                    rf'void\s+test_{re.escape(base_name)}\s*\(',
                ]

                for pattern in patterns:
                    if re.search(pattern, content):
                        self.logger.info(f"通过内容搜索找到测试文件: {test_file}")
                        return str(test_file)

            except Exception:
                continue

        return None
