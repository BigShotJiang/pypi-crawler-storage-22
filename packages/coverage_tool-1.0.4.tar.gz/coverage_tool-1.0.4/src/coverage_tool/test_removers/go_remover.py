#!/usr/bin/env python3
"""
Go测试删除器
使用正则表达式解析Go测试文件
"""

import re
from typing import List, Optional
from pathlib import Path

from coverage_tool.test_removers.base import BaseSmartTestRemover, TestFunction
from coverage_tool.parsers import TestCase


class GoSmartTestRemover(BaseSmartTestRemover):
    """Go智能测试删除器"""
    
    # 预编译正则表达式
    TEST_FUNC_PATTERN = re.compile(
        r'^func\s+(Test\w+)\s*\([^)]*\*testing\.T[^)]*\)\s*\{',
        re.MULTILINE
    )
    
    def find_test_functions(self, file_path: str) -> List[TestFunction]:
        """查找Go测试函数"""
        test_functions = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            for match in self.TEST_FUNC_PATTERN.finditer(content):
                func_name = match.group(1)
                start_pos = match.start()
                start_line = content[:start_pos].count('\n') + 1
                
                # 找到函数结束
                brace_count = 0
                end_pos = match.end()
                for i, char in enumerate(content[match.end():]):
                    if char == '{':
                        brace_count += 1
                    elif char == '}':
                        if brace_count == 0:
                            end_pos = match.end() + i + 1
                            break
                        brace_count -= 1
                
                end_line = content[:end_pos].count('\n') + 1
                
                test_func = TestFunction(
                    name=func_name,
                    file_path=file_path,
                    start_line=start_line,
                    end_line=end_line
                )
                test_functions.append(test_func)
        
        except Exception as e:
            self.logger.error(f"解析Go文件失败 {file_path}: {e}")
        
        return test_functions
    
    def find_test_file(self, test_case: TestCase) -> Optional[str]:
        """查找Go测试文件（增强版，支持subtests）"""
        classname = test_case.classname
        test_name = test_case.name

        # 处理特殊的构建失败错误
        if '[build failed]' in test_name or '[no test files]' in test_name:
            return self._find_go_test_file_from_package(classname)

        # 提取基础方法名（处理 subtests 格式：TestFunc/subtest）
        base_name = test_name.split('/')[0]

        # 1. 尝试多种文件路径模式
        patterns = [
            f"{classname.replace('.', '/')}_test.go",
            f"{classname}_test.go",
            f"{classname.replace('.', '/')}.go",
        ]

        for pattern in patterns:
            file_path = Path(self.project_dir) / pattern
            if file_path.exists():
                return str(file_path)

        # 2. 通过内容搜索测试函数
        result = self._search_test_file_by_content(base_name, classname)
        if result:
            return result

        return None

    def _find_go_test_file_from_package(self, package_path: str) -> Optional[str]:
        """从包路径查找Go测试文件"""
        package_parts = package_path.split('/')
        
        for i in range(len(package_parts) - 1, 0, -1):
            subdir = '/'.join(package_parts[i:])
            
            for test_file in Path(self.project_dir).rglob(f"{subdir}/*_test.go"):
                if test_file.exists():
                    self.logger.info(f"[编译错误] 找到包 {package_path} 的测试文件: {test_file}")
                    return str(test_file)
            
            dir_path = Path(self.project_dir) / subdir
            if dir_path.exists() and dir_path.is_dir():
                for test_file in dir_path.glob("*_test.go"):
                    if test_file.exists():
                        self.logger.info(f"[编译错误] 找到包 {package_path} 的测试文件: {test_file}")
                        return str(test_file)
        
        return None

    def _search_test_file_by_content(self, base_name: str, classname: str) -> Optional[str]:
        """通过测试方法内容搜索测试文件"""
        for test_file in Path(self.project_dir).rglob("*_test.go"):
            try:
                with open(test_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # 匹配 Go 测试函数（更宽松的正则）
                patterns = [
                    rf'func\s+{re.escape(base_name)}\s*\([^)]*testing\.T[^)]*\)',
                    rf'func\s+{re.escape(base_name)}\s*\(\s*t\s*\*{re.escape("testing")}\.T[^)]*\)',
                ]
                
                for pattern in patterns:
                    if re.search(pattern, content, re.MULTILINE):
                        self.logger.info(f"通过内容搜索找到测试文件: {test_file}")
                        return str(test_file)
                
                # 简化匹配：只要找到函数定义就行
                simple_pattern = rf'func\s+{re.escape(base_name)}\s*\('
                if re.search(simple_pattern, content, re.MULTILINE):
                    self.logger.info(f"通过内容搜索找到测试文件: {test_file}")
                    return str(test_file)
                            
            except Exception:
                continue
        
        return None
