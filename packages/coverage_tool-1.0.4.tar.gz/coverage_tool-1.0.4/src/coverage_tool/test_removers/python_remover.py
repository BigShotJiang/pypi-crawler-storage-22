#!/usr/bin/env python3
"""
Python测试删除器
使用AST解析Python测试文件
"""

import ast
import re
import os
from typing import List, Optional
from pathlib import Path

from coverage_tool.test_removers.base import BaseSmartTestRemover, TestFunction
from coverage_tool.parsers import TestCase


class PythonSmartTestRemover(BaseSmartTestRemover):
    """Python智能测试删除器 - 使用AST解析"""
    
    def find_test_functions(self, file_path: str) -> List[TestFunction]:
        """使用AST查找Python测试函数"""
        test_functions = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            tree = ast.parse(content)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    # 检查是否是测试函数
                    if self._is_test_function(node):
                        # 获取函数在文件中的位置
                        start_line = node.lineno
                        end_line = node.end_lineno if hasattr(node, 'end_lineno') else start_line
                        
                        # 获取装饰器
                        decorators = []
                        for decorator in node.decorator_list:
                            if isinstance(decorator, ast.Name):
                                decorators.append(decorator.id)
                            elif isinstance(decorator, ast.Call):
                                if isinstance(decorator.func, ast.Name):
                                    decorators.append(decorator.func.id)
                        
                        test_func = TestFunction(
                            name=node.name,
                            file_path=file_path,
                            start_line=start_line,
                            end_line=end_line or start_line,
                            decorators=decorators,
                            is_class_method=self._is_class_method(node, tree),
                            class_name=self._get_class_name(node, tree)
                        )
                        test_functions.append(test_func)
                
                elif isinstance(node, ast.ClassDef):
                    # 处理测试类中的方法
                    if self._is_test_class(node):
                        for item in node.body:
                            if isinstance(item, ast.FunctionDef) and self._is_test_method(item):
                                start_line = item.lineno
                                end_line = item.end_lineno if hasattr(item, 'end_lineno') else start_line
                                
                                test_func = TestFunction(
                                    name=item.name,
                                    file_path=file_path,
                                    start_line=start_line,
                                    end_line=end_line or start_line,
                                    is_class_method=True,
                                    class_name=node.name
                                )
                                test_functions.append(test_func)
        
        except SyntaxError as e:
            self.logger.error(f"Python语法错误 {file_path}: {e}")
        except Exception as e:
            self.logger.error(f"解析Python文件失败 {file_path}: {e}")
        
        return test_functions
    
    def _is_test_function(self, node: ast.FunctionDef) -> bool:
        """检查是否是测试函数"""
        # 函数名以 test_ 开头
        if node.name.startswith('test_'):
            return True
        
        # 检查是否有测试相关的装饰器
        test_decorators = {'pytest', 'fixture', 'parametrize'}
        for decorator in node.decorator_list:
            if isinstance(decorator, ast.Name):
                if decorator.id.lower() in test_decorators or decorator.id.startswith('pytest'):
                    return True
        
        return False
    
    def _is_test_class(self, node: ast.ClassDef) -> bool:
        """检查是否是测试类"""
        # 类名以 Test 开头
        if node.name.startswith('Test'):
            return True
        
        # 检查继承
        for base in node.bases:
            if isinstance(base, ast.Name):
                if 'test' in base.id.lower():
                    return True
        
        return False
    
    def _is_test_method(self, node: ast.FunctionDef) -> bool:
        """检查是否是测试方法"""
        return node.name.startswith('test_')
    
    def _is_class_method(self, node: ast.FunctionDef, tree: ast.AST) -> bool:
        """检查函数是否是类方法"""
        for parent in ast.walk(tree):
            if isinstance(parent, ast.ClassDef):
                for item in parent.body:
                    if isinstance(item, ast.FunctionDef) and item.name == node.name:
                        return True
        return False
    
    def _get_class_name(self, node: ast.FunctionDef, tree: ast.AST) -> Optional[str]:
        """获取函数所属的类名"""
        for parent in ast.walk(tree):
            if isinstance(parent, ast.ClassDef):
                for item in parent.body:
                    if isinstance(item, ast.FunctionDef) and item.name == node.name:
                        return parent.name
        return None
    
    def _get_deletion_range(self, test_func: TestFunction, lines: List[str]) -> tuple:
        """
        获取Python测试函数的删除范围
        考虑装饰器和空行
        """
        start_idx = self._adjust_start_for_decorators(
            test_func, lines, comment_prefixes=['#']
        )
        end_idx = test_func.end_line
        return start_idx, end_idx
    
    def find_test_file(self, test_case: TestCase) -> Optional[str]:
        """查找Python测试文件（增强版）"""
        classname = test_case.classname
        test_name = test_case.name

        # 提取基础方法名（去掉参数化后缀）
        base_name = test_name.split('[')[0]

        # 1. 尝试多种文件路径模式
        patterns = [
            f"{classname.replace('.', '/')}.py",
            f"test_{classname.replace('.', '_')}.py",
            f"{classname.replace('.', '_')}_test.py",
            f"tests/{classname.replace('.', '/')}.py",
            f"tests/test_{classname.replace('.', '_')}.py",
            f"test_{classname.replace('.', '_')}.py",
        ]

        for pattern in patterns:
            file_path = Path(self.project_dir) / pattern
            if file_path.exists():
                return str(file_path)

        # 2. 通过内容搜索测试函数
        result = self._search_test_file_by_content(base_name, classname)
        if result:
            return result

        return None

    def _search_test_file_by_content(self, base_name: str, classname: str) -> Optional[str]:
        """通过测试方法内容搜索测试文件"""
        import ast
        
        for test_file in Path(self.project_dir).rglob("*test*.py"):
            try:
                with open(test_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # 尝试解析AST
                try:
                    tree = ast.parse(content)
                    
                    # 检查类中的测试方法
                    for node in ast.walk(tree):
                        if isinstance(node, ast.ClassDef):
                            if node.name.startswith('Test'):
                                for item in node.body:
                                    if isinstance(item, ast.FunctionDef):
                                        if item.name == base_name:
                                            self.logger.info(f"通过AST搜索找到测试文件: {test_file}")
                                            return str(test_file)
                        
                        # 检查独立的测试函数
                        if isinstance(node, ast.FunctionDef):
                            if node.name.startswith('test_') and node.name == base_name:
                                self.logger.info(f"通过AST搜索找到测试文件: {test_file}")
                                return str(test_file)
                                
                except SyntaxError:
                    # 如果AST解析失败，使用正则匹配
                    pass
                
                # 回退到正则匹配
                patterns = [
                    rf'def\s+{re.escape(base_name)}\s*\(',
                    rf'@pytest\.mark\.parametrize.*\n\s*def\s+{re.escape(base_name)}\s*\(',
                ]
                
                for pattern in patterns:
                    if re.search(pattern, content, re.MULTILINE):
                        self.logger.info(f"通过内容搜索找到测试文件: {test_file}")
                        return str(test_file)
                        
            except Exception:
                continue
        
        return None
