#!/usr/bin/env python3
"""
高级测试场景
测试参数化测试、复杂项目结构、多种框架格式
"""

import sys
import os
import tempfile
import shutil
from pathlib import Path

sys.path.insert(0, '/home/nlp/zhaoxingqian/coverage_tool/src')

from coverage_tool.test_removers.python_remover import PythonSmartTestRemover
from coverage_tool.test_removers.java_remover import JavaSmartTestRemover
from coverage_tool.test_removers.go_remover import GoSmartTestRemover
from coverage_tool.test_removers.cpp_remover import CPPSmartTestRemover
from coverage_tool.test_removers.c_remover import CSmartTestRemover


class MockLogger:
    def info(self, msg): pass
    def warning(self, msg): pass
    def error(self, msg): pass


def test_cpp_parameterized_tests():
    """测试C++ Google Test参数化测试"""
    print("\n" + "="*60)
    print("测试 C++ Google Test 参数化测试")
    print("="*60)

    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = Path(tmpdir) / "math_test.cpp"
        test_file.write_text('''#include <gtest/gtest.h>

TEST(MathSuite, AddTest) {
    EXPECT_EQ(3, 1 + 2);
}

TEST(MathSuite, SubtractTest) {
    EXPECT_EQ(1, 5 - 4);
}
''')

        remover = CPPSmartTestRemover(tmpdir, MockLogger())

        test_cases = [
            ("MathSuite.AddTest", True),
            ("MathSuite.SubtractTest", True),
        ]

        passed = 0
        for test_name, should_find in test_cases:
            base_name = test_name.split('.')[-1]
            result = remover._search_test_file_by_content(
                base_name,
                test_name.split('.')[0],
                test_name
            )
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {test_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1

        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_junit5_parameterized_tests():
    """测试Java JUnit 5参数化测试"""
    print("\n" + "="*60)
    print("测试 Java JUnit 5 参数化测试")
    print("="*60)

    with tempfile.TemporaryDirectory() as tmpdir:
        java_dir = Path(tmpdir) / "src" / "test" / "java" / "com" / "example"
        java_dir.mkdir(parents=True)

        test_file = java_dir / "CalculatorTest.java"
        test_file.write_text('''package com.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;

public class CalculatorTest {

    @ParameterizedTest
    @ValueSource(ints = {1, 2, 3, 4, 5})
    void testIsPositive(int number) {
        assertTrue(number > 0);
    }

    @Test
    void testAdd() {
        assertEquals(3, 1 + 2);
    }

    @Test
    void testMultiply() {
        assertEquals(6, 2 * 3);
    }
}
''')

        remover = JavaSmartTestRemover(tmpdir, MockLogger())

        test_cases = [
            ("CalculatorTest", "testIsPositive[1]", True),
            ("CalculatorTest", "testAdd", True),
            ("CalculatorTest", "testMultiply", True),
        ]

        passed = 0
        for classname, method_name, should_find in test_cases:
            base_name = method_name.split('[')[0]
            result = remover._search_test_file_by_content(base_name, classname)
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {classname}.{method_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1

        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_complex_java_structure():
    """测试复杂Java项目结构"""
    print("\n" + "="*60)
    print("测试复杂 Java 项目结构")
    print("="*60)

    with tempfile.TemporaryDirectory() as tmpdir:
        structure = {
            "src/main/java/com/example/App.java": "package com.example;",
            "src/test/java/com/example/AppTest.java": '''package com.example;

import org.junit.Test;
public class AppTest {
    @Test
    public void testMain() {
    }
}''',
            "src/test/java/com/example/util/StringUtilsTest.java": '''package com.example.util;

import org.junit.Test;
public class StringUtilsTest {
    @Test
    public void testReverse() {
    }
}''',
            "tests/IntegrationTest.java": '''import org.junit.Test;

public class IntegrationTest {
    @Test
    public void testFullFlow() {
    }
}''',
        }

        for path, content in structure.items():
            file_path = Path(tmpdir) / path
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content)

        remover = JavaSmartTestRemover(tmpdir, MockLogger())

        test_cases = [
            ("AppTest", "testMain", True),
            ("StringUtilsTest", "testReverse", True),
            ("IntegrationTest", "testFullFlow", True),
        ]

        passed = 0
        for classname, method_name, should_find in test_cases:
            result = remover._search_test_file_by_content(method_name, classname)
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {classname}.{method_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1

        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_complex_python_structure():
    """测试复杂Python项目结构"""
    print("\n" + "="*60)
    print("测试复杂 Python 项目结构")
    print("="*60)

    with tempfile.TemporaryDirectory() as tmpdir:
        structure = {
            "src/app.py": "# main app",
            "tests/test_app.py": '''import pytest

def test_main():
    pass''',
            "tests/utils/test_string.py": '''import pytest

def test_reverse():
    pass''',
            "tests/test_main.py": '''import pytest

def test_app():
    pass''',
        }

        for path, content in structure.items():
            file_path = Path(tmpdir) / path
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content)

        remover = PythonSmartTestRemover(tmpdir, MockLogger())

        test_cases = [
            ("test_app", "test_main", True),
            ("utils.test_string", "test_reverse", True),
            ("test_main", "test_app", True),
        ]

        passed = 0
        for classname, method_name, should_find in test_cases:
            base_name = method_name.split('[')[0]
            result = remover._search_test_file_by_content(base_name, classname)
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {classname}.{method_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1

        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_complex_go_structure():
    """测试复杂Go项目结构"""
    print("\n" + "="*60)
    print("测试复杂 Go 项目结构")
    print("="*60)

    with tempfile.TemporaryDirectory() as tmpdir:
        structure = {
            "pkg/math/math.go": "package math",
            "pkg/math/math_test.go": '''package math

import "testing"

func TestAdd(t *testing.T) {
}

func TestSubtract(t *testing.T) {
}''',
            "pkg/util/util.go": "package util",
            "pkg/util/util_test.go": '''package util

import "testing"

func TestToUpper(t *testing.T) {
}''',
        }

        for path, content in structure.items():
            file_path = Path(tmpdir) / path
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content)

        remover = GoSmartTestRemover(tmpdir, MockLogger())

        test_cases = [
            ("math", "TestAdd", True),
            ("math", "TestSubtract", True),
            ("util", "TestToUpper", True),
        ]

        passed = 0
        for package, method_name, should_find in test_cases:
            result = remover._search_test_file_by_content(method_name, package)
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {package}.{method_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1

        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_c_assertions():
    """测试C语言测试"""
    print("\n" + "="*60)
    print("测试 C 语言测试")
    print("="*60)

    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = Path(tmpdir) / "test_math.c"
        test_file.write_text('''#include <stdio.h>
#include <assert.h>

void test_add(void) {
    assert(1 + 2 == 3);
}

void test_multiply(void) {
    assert(2 * 3 == 6);
}
''')

        remover = CSmartTestRemover(tmpdir, MockLogger())

        # C: classname 是文件名(不含扩展名)，name 是函数名
        test_cases = [
            ("test_math", "test_add", True),
            ("test_math", "test_multiply", True),
        ]

        passed = 0
        for classname, method_name, should_find in test_cases:
            base_name = method_name.split('[')[0]
            result = remover._search_test_file_by_content(base_name, classname)
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {classname}.{method_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1

        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_cpp_multiple_frameworks():
    """测试C++多种测试框架"""
    print("\n" + "="*60)
    print("测试 C++ 多种测试框架")
    print("="*60)

    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = Path(tmpdir) / "all_tests.cpp"
        test_file.write_text('''#include <gtest/gtest.h>

TEST(GoogleTestSuite, GoogleTestCase) {
    EXPECT_EQ(1, 1);
}
''')

        remover = CPPSmartTestRemover(tmpdir, MockLogger())

        test_cases = [
            ("GoogleTestSuite.GoogleTestCase", True),
        ]

        passed = 0
        for test_name, should_find in test_cases:
            base_name = test_name.split('.')[-1]
            result = remover._search_test_file_by_content(
                base_name,
                test_name.split('.')[0],
                test_name
            )
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {test_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1

        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def main():
    print("="*60)
    print("高级测试场景验证")
    print("="*60)

    results = []

    results.append(("C++ Google Test", test_cpp_parameterized_tests()))
    results.append(("Java JUnit5", test_junit5_parameterized_tests()))
    results.append(("Java 复杂结构", test_complex_java_structure()))
    results.append(("Python 复杂结构", test_complex_python_structure()))
    results.append(("Go 复杂结构", test_complex_go_structure()))
    results.append(("C 测试", test_c_assertions()))
    results.append(("C++ 多种框架", test_cpp_multiple_frameworks()))

    print("\n" + "="*60)
    print("最终结果")
    print("="*60)

    total_passed = sum(1 for _, passed in results if passed)
    total_tests = len(results)

    for name, passed in results:
        status = "✓" if passed else "✗"
        print(f"   {status} {name}")

    print(f"\n总计: {total_passed}/{total_tests} 通过")

    if total_passed == total_tests:
        print("\n✅ 所有高级测试通过！")
        return 0
    else:
        print(f"\n❌ {total_tests - total_passed} 个测试失败")
        return 1


if __name__ == '__main__':
    exit(main())
