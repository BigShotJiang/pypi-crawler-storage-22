#!/usr/bin/env python3
"""
测试增强的测试文件搜索功能
验证参数化测试、subtests、classname解析等
"""

import sys
import os
import tempfile
import shutil
from pathlib import Path

sys.path.insert(0, '/home/nlp/zhaoxingqian/coverage_tool/src')

from coverage_tool.test_removers.python_remover import PythonSmartTestRemover
from coverage_tool.test_removers.java_remover import JavaSmartTestRemover
from coverage_tool.test_removers.go_remover import GoSmartTestRemover
from coverage_tool.test_removers.cpp_remover import CPPSmartTestRemover
from coverage_tool.test_removers.c_remover import CSmartTestRemover


class MockLogger:
    def info(self, msg): pass
    def warning(self, msg): pass
    def error(self, msg): pass


def test_python_parameterized_tests():
    """测试Python参数化测试匹配"""
    print("\n" + "="*60)
    print("测试 Python 参数化测试匹配")
    print("="*60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 创建Python参数化测试文件
        test_file = Path(tmpdir) / "test_math.py"
        test_file.write_text('''import pytest

@pytest.mark.parametrize("a,b,expected", [
    (1, 2, 3),
    (2, 3, 5),
    (10, 20, 30),
])
def test_add(a, b, expected):
    assert a + b == expected

def test_multiply():
    assert 2 * 3 == 6

class TestCalculator:
    def test_divide(self):
        assert 6 / 2 == 3
''')
        
        remover = PythonSmartTestRemover(tmpdir, MockLogger())
        
        # 测试参数化测试名提取
        test_cases = [
            ("test_add[1+2-3]", "test_math", True),
            ("test_add[2+3-5]", "test_math", True),
            ("test_multiply", "test_math", True),
            ("test_divide", "TestCalculator", True),
        ]
        
        passed = 0
        for test_name, classname, should_find in test_cases:
            base_name = test_name.split('[')[0]
            result = remover._search_test_file_by_content(base_name, classname)
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {test_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1
        
        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_java_classname_parsing():
    """测试Java classname解析"""
    print("\n" + "="*60)
    print("测试 Java classname 解析")
    print("="*60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 创建Java测试目录结构
        java_dir = Path(tmpdir) / "src" / "test" / "java" / "com" / "example"
        java_dir.mkdir(parents=True)
        
        test_file = java_dir / "CalculatorTest.java"
        test_file.write_text('''package com.example;

import org.junit.Test;

public class CalculatorTest {
    @Test
    public void testAdd() {
    }
    
    @Test
    public void testMultiply() {
    }
}
''')
        
        remover = JavaSmartTestRemover(tmpdir, MockLogger())
        
        # 测试多种classname格式
        test_cases = [
            ("com.example.CalculatorTest", "testAdd", True),
            ("CalculatorTest", "testAdd", True),
        ]
        
        passed = 0
        for classname, method_name, should_find in test_cases:
            result = remover._search_test_file_by_content(method_name, classname)
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {classname}.{method_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1
        
        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_go_subtests():
    """测试Go subtests匹配"""
    print("\n" + "="*60)
    print("测试 Go subtests 匹配")
    print("="*60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 创建Go测试文件
        test_file = Path(tmpdir) / "math_test.go"
        test_file.write_text('''package math

import "testing"

func TestAdd(t *testing.T) {
    t.Run("positive", func(t *testing.T) {
        if 1+2 != 3 {
            t.Error("failed")
        }
    })
}

func TestMultiply(t *testing.T) {
}
''')
        
        remover = GoSmartTestRemover(tmpdir, MockLogger())
        
        # 测试subtests格式
        test_cases = [
            ("TestAdd/positive", "math", True),
            ("TestAdd", "math", True),
            ("TestMultiply", "math", True),
        ]
        
        passed = 0
        for test_name, package, should_find in test_cases:
            base_name = test_name.split('/')[0]
            result = remover._search_test_file_by_content(base_name, package)
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {test_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1
        
        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_cpp_google_test():
    """测试C++ Google Test匹配"""
    print("\n" + "="*60)
    print("测试 C++ Google Test 匹配")
    print("="*60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 创建Google Test文件
        test_file = Path(tmpdir) / "math_test.cpp"
        test_file.write_text('''#include <gtest/gtest.h>

TEST(MathSuite, AddTest) {
    EXPECT_EQ(3, 1 + 2);
}

TEST(MathSuite, MultiplyTest) {
    EXPECT_EQ(6, 2 * 3);
}
''')
        
        remover = CPPSmartTestRemover(tmpdir, MockLogger())
        
        # 测试Google Test格式
        test_cases = [
            ("MathSuite.AddTest", True),
            ("MathSuite.MultiplyTest", True),
        ]
        
        passed = 0
        for test_name, should_find in test_cases:
            base_name = test_name.split('.')[-1]
            result = remover._search_test_file_by_content(base_name, test_name.split('.')[0], test_name)
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 搜索 {test_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1
        
        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_content_search_fallback():
    """测试内容搜索回退逻辑"""
    print("\n" + "="*60)
    print("测试内容搜索回退逻辑")
    print("="*60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 创建测试文件（非标准命名，但文件名包含test）
        test_file = Path(tmpdir) / "not_standard_test.py"
        test_file.write_text('''import pytest

def test_custom():
    assert True

class MyTestClass:
    def test_method(self):
        pass
''')
        
        remover = PythonSmartTestRemover(tmpdir, MockLogger())
        
        # 测试回退搜索
        test_cases = [
            ("test_custom", "not_standard_test", True),
            ("test_method", "MyTestClass", True),
        ]
        
        passed = 0
        for test_name, classname, should_find in test_cases:
            base_name = test_name.split('[')[0]
            result = remover._search_test_file_by_content(base_name, classname)
            found = result is not None
            status = "✓" if found == should_find else "✗"
            print(f"   {status} 回退搜索 {test_name}: {'找到' if found else '未找到'}")
            if found == should_find:
                passed += 1
        
        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def test_build_failure_handling():
    """测试构建失败处理"""
    print("\n" + "="*60)
    print("测试构建失败处理")
    print("="*60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # 创建Java构建失败场景
        java_dir = Path(tmpdir) / "src" / "test" / "java" / "com" / "example"
        java_dir.mkdir(parents=True)
        
        remover = JavaSmartTestRemover(tmpdir, MockLogger())
        
        # 测试构建失败检测
        test_cases = [
            ("[build failed]", True),
            ("testMethod[compilation failed]", True),
            ("normal_test", False),
        ]
        
        passed = 0
        for test_name, should_detect in test_cases:
            detected = remover._is_build_failure(test_name)
            status = "✓" if detected == should_detect else "✗"
            print(f"   {status} 检测 '{test_name}': {'构建失败' if detected else '正常'}")
            if detected == should_detect:
                passed += 1
        
        print(f"\n结果: {passed}/{len(test_cases)} 通过")
        return passed == len(test_cases)


def main():
    print("="*60)
    print("增强测试文件搜索功能验证")
    print("="*60)
    
    results = []
    
    results.append(("Python 参数化测试", test_python_parameterized_tests()))
    results.append(("Java classname 解析", test_java_classname_parsing()))
    results.append(("Go subtests 匹配", test_go_subtests()))
    results.append(("C++ Google Test", test_cpp_google_test()))
    results.append(("内容搜索回退", test_content_search_fallback()))
    results.append(("构建失败处理", test_build_failure_handling()))
    
    print("\n" + "="*60)
    print("最终结果")
    print("="*60)
    
    total_passed = sum(1 for _, passed in results if passed)
    total_tests = len(results)
    
    for name, passed in results:
        status = "✓" if passed else "✗"
        print(f"   {status} {name}")
    
    print(f"\n总计: {total_passed}/{total_tests} 通过")
    
    if total_passed == total_tests:
        print("\n✅ 所有测试通过！")
        return 0
    else:
        print(f"\n❌ {total_tests - total_passed} 个测试失败")
        return 1


if __name__ == '__main__':
    exit(main())
