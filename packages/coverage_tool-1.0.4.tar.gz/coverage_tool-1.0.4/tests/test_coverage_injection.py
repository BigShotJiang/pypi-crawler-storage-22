#!/usr/bin/env python3
"""
测试覆盖率工具自动注入功能
"""

import os
import sys
import tempfile
import shutil
import xml.etree.ElementTree as ET

# 添加项目路径
sys.path.insert(0, '/home/nlp/zhaoxingqian/coverage_tool/src')

from coverage_tool.handlers.coverage_injector import CoverageInjector


def test_coverage_injector():
    """测试覆盖率注入器"""
    print("="*60)
    print("测试覆盖率注入器")
    print("="*60)
    
    injector = CoverageInjector()
    
    # 测试1: 检查覆盖率工具可用性
    print("\n1. 测试覆盖率工具检查:")
    for lang in ['python', 'go', 'java', 'c', 'cpp']:
        available, message = injector.check_coverage_tool_available(lang)
        status = "✓" if available else "⚠"
        print(f"   {status} {lang}: {message}")
    
    # 测试2: 测试C编译命令注入
    print("\n2. 测试C编译命令注入:")
    test_cmds = [
        "gcc -c test.c",
        "g++ -o test test.cpp",
        "make all"
    ]
    for cmd in test_cmds:
        modified = injector._add_coverage_flags_to_command(cmd, ['-fprofile-arcs', '-ftest-coverage'])
        print(f"   原始: {cmd}")
        print(f"   修改: {modified}")
    
    # 测试3: 测试Java覆盖率配置
    print("\n3. 测试Java JaCoCo配置:")
    
    # 创建临时pom.xml
    with tempfile.TemporaryDirectory() as tmpdir:
        pom_content = '''<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.test</groupId>
    <artifactId>test-project</artifactId>
    <version>1.0-SNAPSHOT</version>
    
    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.8.1</version>
            </plugin>
        </plugins>
    </build>
</project>
'''
        pom_path = os.path.join(tmpdir, 'pom.xml')
        with open(pom_path, 'w', encoding='utf-8') as f:
            f.write(pom_content)
        
        # 检查JaCoCo是否已配置
        jacoco_configured, jacoco_config = injector._check_jacoco_in_pom(pom_path)
        print(f"   初始JaCoCo配置状态: {'已配置' if jacoco_configured else '未配置'}")
        
        # 自动添加JaCoCo
        if not jacoco_configured:
            success, message = injector._add_jacoco_to_pom(pom_path)
            print(f"   自动添加结果: {message}")
            
            # 验证添加结果
            jacoco_configured_after, _ = injector._check_jacoco_in_pom(pom_path)
            print(f"   添加后JaCoCo配置状态: {'已配置' if jacoco_configured_after else '未配置'}")
            
            # 检查生成的pom.xml
            if os.path.exists(pom_path):
                with open(pom_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                if 'jacoco' in content.lower():
                    print("   ✓ JaCoCo插件已成功添加到pom.xml")
    
    # 测试4: 测试报告路径获取
    print("\n4. 测试报告路径获取:")
    for lang in ['python', 'go', 'java', 'c', 'cpp']:
        reports = injector.get_coverage_report_paths(lang, '/tmp')
        print(f"   {lang}: {list(reports.keys())}")
    
    print("\n" + "="*60)
    print("测试完成")
    print("="*60)


def test_java_runner_integration():
    """测试Java Runner集成"""
    print("\n" + "="*60)
    print("测试Java Runner集成")
    print("="*60)
    
    from coverage_tool.runners.java_runner import JavaRunner
    from coverage_tool.core.config import LANGUAGE_CONFIGS, Language
    
    config = LANGUAGE_CONFIGS[Language.JAVA]
    runner = JavaRunner(config=config)
    
    print(f"✓ JavaRunner创建成功")
    print(f"✓ 注入器可用: {hasattr(runner, 'injector')}")
    
    # 测试ensure_jacoco
    with tempfile.TemporaryDirectory() as tmpdir:
        # 创建简单的pom.xml
        pom_content = '''<?xml version="1.0" encoding="UTF-8"?>
<project>
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.test</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>
</project>
'''
        pom_path = os.path.join(tmpdir, 'pom.xml')
        with open(pom_path, 'w', encoding='utf-8') as f:
            f.write(pom_content)
        
        success, message = runner._ensure_jacoco(tmpdir)
        print(f"✓ JaCoCo配置测试: {message}")
    
    print("="*60)


if __name__ == '__main__':
    test_coverage_injector()
    test_java_runner_integration()
