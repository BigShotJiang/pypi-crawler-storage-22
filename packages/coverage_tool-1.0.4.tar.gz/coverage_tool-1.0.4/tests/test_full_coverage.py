#!/usr/bin/env python3
"""
项目完整单元测试
测试所有核心功能和模块
"""

import sys
import os
import tempfile
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import pytest

sys.path.insert(0, '/home/nlp/zhaoxingqian/coverage_tool/src')

from coverage_tool.main import CoverageTool, ToolConfig, ExecutionPhase, ExecutionResult
from coverage_tool.core import Language, ReportFormat
from coverage_tool.runners.factory import RunnerFactory
from coverage_tool.runners.base import RunResult, CoverageExtractor
from coverage_tool.runners.python_runner import PythonRunner
from coverage_tool.runners.java_runner import JavaRunner
from coverage_tool.runners.go_runner import GoRunner
from coverage_tool.runners.c_runner import CRunner
from coverage_tool.runners.cpp_runner import CPPRunner
from coverage_tool.test_removers.factory import SmartTestRemoverFactory
from coverage_tool.test_removers.base import TestFunction, TestRemovalStrategy
from coverage_tool.parsers import JunitXMLParser, TestReport, TestSuite, TestCase, TestStatus
from coverage_tool.handlers import SmartCompilationHandler, EnvironmentChecker
from coverage_tool.handlers.coverage_injector import CoverageInjector
from coverage_tool.utils import Logger, FileBackupManager


class TestToolConfig:
    """测试 ToolConfig 数据类"""

    def test_default_config(self):
        """测试默认配置"""
        config = ToolConfig(
            language=Language.PYTHON,
            target_dir="/tmp/test"
        )
        assert config.language == Language.PYTHON
        assert config.target_dir == "/tmp/test"
        assert config.output_file == "coverage_report"
        assert config.report_format == ReportFormat.TEXT
        assert config.delete_on_compile_failure is True
        assert config.compile_timeout == 60
        assert config.test_timeout == 300

    def test_custom_config(self):
        """测试自定义配置"""
        config = ToolConfig(
            language=Language.JAVA,
            target_dir="/project",
            output_file="custom_report",
            report_format=ReportFormat.JSON,
            delete_on_compile_failure=False,
            compile_timeout=120,
            test_timeout=600
        )
        assert config.language == Language.JAVA
        assert config.output_file == "custom_report"
        assert config.report_format == ReportFormat.JSON
        assert config.delete_on_compile_failure is False


class TestCoverageTool:
    """测试 CoverageTool 主类"""

    def test_init(self):
        """测试初始化"""
        config = ToolConfig(
            language=Language.PYTHON,
            target_dir="/tmp/test"
        )
        tool = CoverageTool(config)
        assert tool.config == config
        assert tool.temp_dir.startswith("/tmp/coverage_tool_")
        assert tool._runner is None

    def test_context_manager(self):
        """测试上下文管理器"""
        config = ToolConfig(
            language=Language.PYTHON,
            target_dir="/tmp/test"
        )
        with CoverageTool(config) as tool:
            assert tool.temp_dir.startswith("/tmp/coverage_tool_")

    def test_cleanup(self):
        """测试清理方法"""
        config = ToolConfig(
            language=Language.PYTHON,
            target_dir="/tmp/test"
        )
        tool = CoverageTool(config)
        temp_dir = tool.temp_dir
        assert os.path.exists(temp_dir)
        tool.cleanup()
        assert not os.path.exists(temp_dir)


class TestRunners:
    """测试各语言 Runner"""

    def test_python_runner_init(self):
        """测试 Python Runner 初始化"""
        from coverage_tool.core.config import LANGUAGE_CONFIGS, Language
        config = LANGUAGE_CONFIGS[Language.PYTHON]
        runner = PythonRunner(config=config)
        assert runner.config == config

    def test_java_runner_init(self):
        """测试 Java Runner 初始化"""
        from coverage_tool.core.config import LANGUAGE_CONFIGS, Language
        config = LANGUAGE_CONFIGS[Language.JAVA]
        runner = JavaRunner(config=config)
        assert runner.config == config

    def test_go_runner_init(self):
        """测试 Go Runner 初始化"""
        from coverage_tool.core.config import LANGUAGE_CONFIGS, Language
        config = LANGUAGE_CONFIGS[Language.GO]
        runner = GoRunner(config=config)
        assert runner.config == config

    def test_c_runner_init(self):
        """测试 C Runner 初始化"""
        from coverage_tool.core.config import LANGUAGE_CONFIGS, Language
        config = LANGUAGE_CONFIGS[Language.C]
        runner = CRunner(config=config)
        assert runner.config == config

    def test_cpp_runner_init(self):
        """测试 C++ Runner 初始化"""
        from coverage_tool.core.config import LANGUAGE_CONFIGS, Language
        config = LANGUAGE_CONFIGS[Language.CPP]
        runner = CPPRunner(config=config)
        assert runner.config == config

    def test_runner_factory_python(self):
        """测试 RunnerFactory 创建 Python Runner"""
        runner = RunnerFactory.get_runner(Language.PYTHON, None)
        assert isinstance(runner, PythonRunner)

    def test_runner_factory_java(self):
        """测试 RunnerFactory 创建 Java Runner"""
        runner = RunnerFactory.get_runner(Language.JAVA, None)
        assert isinstance(runner, JavaRunner)

    def test_runner_factory_go(self):
        """测试 RunnerFactory 创建 Go Runner"""
        runner = RunnerFactory.get_runner(Language.GO, None)
        assert isinstance(runner, GoRunner)

    def test_runner_factory_c(self):
        """测试 RunnerFactory 创建 C Runner"""
        runner = RunnerFactory.get_runner(Language.C, None)
        assert isinstance(runner, CRunner)

    def test_runner_factory_cpp(self):
        """测试 RunnerFactory 创建 C++ Runner"""
        runner = RunnerFactory.get_runner(Language.CPP, None)
        assert isinstance(runner, CPPRunner)


class TestRunResult:
    """测试 RunResult 数据类"""

    def test_run_result_creation(self):
        """测试 RunResult 创建"""
        result = RunResult(
            success=True,
            return_code=0,
            stdout="All tests passed",
            stderr="",
            duration=10.5
        )
        assert result.success is True
        assert result.return_code == 0
        assert result.duration == 10.5
        assert result.junit_xml_path is None
        assert result.coverage_rate == 0.0

    def test_run_result_with_xml(self):
        """测试带 XML 路径的 RunResult"""
        result = RunResult(
            success=True,
            return_code=0,
            stdout="",
            stderr="",
            duration=5.0,
            junit_xml_path="/tmp/report.xml",
            coverage_rate=85.5
        )
        assert result.junit_xml_path == "/tmp/report.xml"
        assert result.coverage_rate == 85.5


class TestCoverageExtractor:
    """测试 CoverageExtractor"""

    def test_extract_from_coverage_out_not_exists(self):
        """测试提取不存在的 coverage.out 文件"""
        rate = CoverageExtractor.extract_from_coverage_out("/nonexistent/coverage.out", "go")
        assert rate == 0.0

    def test_extract_from_jacoco_not_exists(self):
        """测试提取不存在的 JaCoCo 报告"""
        rate = CoverageExtractor.extract_from_jacoco("/nonexistent/jacoco/index.html")
        assert rate == 0.0

    def test_extract_generic_coverage(self):
        """测试通用覆盖率提取"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("Total coverage: 75.5%")
            f.flush()
            rate = CoverageExtractor._extract_generic_coverage(f.name)
            os.unlink(f.name)
            assert rate == 75.5


class TestJunitXMLParser:
    """测试 JUnit XML 解析器"""

    def test_parse_valid_xml(self):
        """测试解析有效的 XML"""
        xml_content = '''<?xml version="1.0" encoding="UTF-8"?>
<testsuites>
    <testsuite name="TestSuite" tests="3" failures="1" errors="0" skipped="0">
        <testcase name="test1" classname="com.example.TestClass" time="0.1"/>
        <testcase name="test2" classname="com.example.TestClass" time="0.2">
            <failure message="Assertion failed">Failed</failure>
        </testcase>
        <testcase name="test3" classname="com.example.TestClass" time="0.3"/>
    </testsuite>
</testsuites>
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.xml', delete=False) as f:
            f.write(xml_content)
            f.flush()
            report = JunitXMLParser.parse(f.name)
            os.unlink(f.name)

        assert report.total_tests == 3
        assert report.total_failures == 1
        assert report.total_errors == 0
        assert abs(report.pass_rate - 66.67) < 1  # Allow small tolerance

    def test_parse_testcase_with_error(self):
        """测试解析包含错误的测试用例"""
        xml_content = '''<?xml version="1.0" encoding="UTF-8"?>
<testsuite name="ErrorSuite" tests="2" failures="0" errors="1" skipped="0">
    <testcase name="test1" classname="com.example.Test" time="0.1"/>
    <testcase name="test2" classname="com.example.Test" time="0.2">
        <error type="RuntimeException">Something went wrong</error>
    </testcase>
</testsuite>
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.xml', delete=False) as f:
            f.write(xml_content)
            f.flush()
            report = JunitXMLParser.parse(f.name)
            os.unlink(f.name)

        assert report.total_tests == 2
        assert report.total_errors == 1
        assert report.pass_rate == 50.0

    def test_parse_single_testsuite(self):
        """测试解析单个 testsuite"""
        xml_content = '''<?xml version="1.0" encoding="UTF-8"?>
<testsuite name="SingleSuite" tests="1" failures="0" errors="0" skipped="1">
    <testcase name="skipped_test" classname="com.example.Test" time="0.1">
        <skipped message="Skipped for demo"/>
    </testcase>
</testsuite>
'''
        with tempfile.NamedTemporaryFile(mode='w', suffix='.xml', delete=False) as f:
            f.write(xml_content)
            f.flush()
            report = JunitXMLParser.parse(f.name)
            os.unlink(f.name)

        assert report.total_tests == 1
        assert report.total_skipped == 1
        assert report.pass_rate == 0.0


class TestTestRemovers:
    """测试测试删除器"""

    def test_remover_factory_python(self):
        """测试创建 Python Remover"""
        remover = SmartTestRemoverFactory.get_remover(
            "python", "/tmp/project", None
        )
        from coverage_tool.test_removers.python_remover import PythonSmartTestRemover
        assert remover.__class__.__name__ == "PythonSmartTestRemover"

    def test_remover_factory_java(self):
        """测试创建 Java Remover"""
        remover = SmartTestRemoverFactory.get_remover(
            "java", "/tmp/project", None
        )
        from coverage_tool.test_removers.java_remover import JavaSmartTestRemover
        assert remover.__class__.__name__ == "JavaSmartTestRemover"

    def test_remover_factory_go(self):
        """测试创建 Go Remover"""
        remover = SmartTestRemoverFactory.get_remover(
            "go", "/tmp/project", None
        )
        from coverage_tool.test_removers.go_remover import GoSmartTestRemover
        assert remover.__class__.__name__ == "GoSmartTestRemover"

    def test_remover_factory_c(self):
        """测试创建 C Remover"""
        remover = SmartTestRemoverFactory.get_remover(
            "c", "/tmp/project", None
        )
        from coverage_tool.test_removers.c_remover import CSmartTestRemover
        assert remover.__class__.__name__ == "CSmartTestRemover"

    def test_remover_factory_cpp(self):
        """测试创建 C++ Remover"""
        remover = SmartTestRemoverFactory.get_remover(
            "cpp", "/tmp/project", None
        )
        from coverage_tool.test_removers.cpp_remover import CPPSmartTestRemover
        assert remover.__class__.__name__ == "CPPSmartTestRemover"


class TestTestFunction:
    """测试 TestFunction 数据类"""

    def test_test_function_creation(self):
        """测试创建 TestFunction"""
        test_func = TestFunction(
            name="test_example",
            file_path="/tmp/test.py",
            start_line=10,
            end_line=20,
            decorators=["pytest"],
            is_class_method=False,
            class_name=None
        )
        assert test_func.name == "test_example"
        assert test_func.start_line == 10
        assert test_func.end_line == 20


class TestCoverageInjector:
    """测试 CoverageInjector"""

    def test_injector_init(self):
        """测试注入器初始化"""
        injector = CoverageInjector()
        assert "python" in injector.coverage_tools
        assert "java" in injector.coverage_tools
        assert "go" in injector.coverage_tools
        assert "c" in injector.coverage_tools
        assert "cpp" in injector.coverage_tools

    def test_check_python_available(self):
        """测试检查 Python 覆盖率工具"""
        injector = CoverageInjector()
        available, message = injector.check_coverage_tool_available("python")
        assert isinstance(available, bool)

    def test_check_go_available(self):
        """测试检查 Go 覆盖率工具"""
        injector = CoverageInjector()
        available, message = injector.check_coverage_tool_available("go")
        assert isinstance(available, bool)

    def test_inject_c_coverage_flags(self):
        """测试 C 覆盖率标志注入"""
        injector = CoverageInjector()
        commands = ["gcc -c test.c", "gcc -o program test.o"]
        modified = injector.inject_coverage_flags("c", commands)
        assert len(modified) == 2
        assert "-fprofile-arcs" in modified[0]

    def test_inject_cpp_coverage_flags(self):
        """测试 C++ 覆盖率标志注入"""
        injector = CoverageInjector()
        commands = ["g++ -c test.cpp"]
        modified = injector.inject_coverage_flags("cpp", commands)
        assert len(modified) == 1
        assert "-fprofile-arcs" in modified[0]

    def test_java_jacoco_check_not_configured(self):
        """测试 JaCoCo 未配置检测"""
        injector = CoverageInjector()
        with tempfile.TemporaryDirectory() as tmpdir:
            pom_path = os.path.join(tmpdir, "pom.xml")
            with open(pom_path, 'w') as f:
                f.write('<?xml version="1.0"?><project><modelVersion>4.0.0</modelVersion></project>')
            configured, _ = injector._check_jacoco_in_pom(pom_path)
            assert configured is False

    def test_get_coverage_report_paths(self):
        """测试获取覆盖率报告路径"""
        injector = CoverageInjector()
        paths = injector.get_coverage_report_paths("python", "/tmp")
        assert "data" in paths
        assert "html" in paths

        paths = injector.get_coverage_report_paths("java", "/tmp")
        assert "jacoco" in paths


class TestSmartCompilationHandler:
    """测试 SmartCompilationHandler"""

    def test_handler_init(self):
        """测试处理器初始化"""
        handler = SmartCompilationHandler("/tmp/project", None)
        assert handler.target_dir == "/tmp/project"

    def test_is_test_file_python(self):
        """测试 Python 单测文件判断"""
        handler = SmartCompilationHandler("/tmp/project", None)
        assert handler._is_test_file("test_example.py") is True
        assert handler._is_test_file("example_test.py") is True
        assert handler._is_test_file("example.py") is False

    def test_is_test_file_java(self):
        """测试 Java 单测文件判断"""
        handler = SmartCompilationHandler("/tmp/project", None)
        # Test basic Java test file patterns
        assert handler._is_test_file("ExampleTest.java", "java") is True
        assert handler._is_test_file("ExampleTests.java", "java") is True
        assert handler._is_test_file("Example.java", "java") is False

    def test_is_business_code_error(self):
        """测试业务代码错误判断"""
        handler = SmartCompilationHandler("/tmp/project", None)
        assert handler._is_business_code_error("undefined reference to main") is True
        assert handler._is_business_code_error("syntax error in main.c") is True


class TestEnvironmentChecker:
    """测试环境检查器"""

    def test_checker_init(self):
        """测试检查器初始化"""
        checker = EnvironmentChecker()
        assert checker is not None

    def test_check_python_environment(self):
        """测试 Python 环境检查"""
        checker = EnvironmentChecker()
        report = checker.check_language_environment("python", "/tmp")
        assert hasattr(report, 'all_passed')

    def test_check_java_environment(self):
        """测试 Java 环境检查"""
        checker = EnvironmentChecker()
        report = checker.check_language_environment("java", "/tmp")
        assert hasattr(report, 'all_passed')


class TestFileBackupManager:
    """测试文件备份管理器"""

    def test_backup_manager_init(self):
        """测试备份管理器初始化"""
        manager = FileBackupManager()
        assert manager is not None

    def test_backup_file_returns_backup_object(self):
        """测试备份文件返回备份对象"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("test content")
            original_path = f.name

        backup_manager = FileBackupManager()
        backup_result = backup_manager.backup_file(original_path)
        assert backup_result is not None
        assert hasattr(backup_result, 'original_path')
        assert hasattr(backup_result, 'backup_path')

        # 验证备份内容
        with open(backup_result.backup_path, 'r') as f:
            content = f.read()
            assert content == "test content"

        # 清理
        backup_manager.cleanup()
        os.unlink(original_path)


class TestExecutionPhase:
    """测试执行阶段"""

    def test_all_phases_exist(self):
        """测试所有阶段都存在"""
        assert ExecutionPhase.ENV_CHECK.value == "环境检查"
        assert ExecutionPhase.COMPILATION.value == "编译"
        assert ExecutionPhase.TEST_EXECUTION.value == "测试执行"
        assert ExecutionPhase.TEST_CLEANUP.value == "测试清理"
        assert ExecutionPhase.COVERAGE_CALCULATION.value == "覆盖率计算"
        assert ExecutionPhase.REPORT_GENERATION.value == "报告生成"


class TestExecutionResult:
    """测试执行结果"""

    def test_execution_result_creation(self):
        """测试创建执行结果"""
        result = ExecutionResult(
            success=True,
            phase=ExecutionPhase.ENV_CHECK,
            message="Environment check passed"
        )
        assert result.success is True
        assert result.phase == ExecutionPhase.ENV_CHECK


class TestContentSearch:
    """测试增强的内容搜索功能"""

    def test_python_parameterized_test_name_extraction(self):
        """测试 Python 参数化测试名提取"""
        from coverage_tool.test_removers.python_remover import PythonSmartTestRemover
        remover = PythonSmartTestRemover("/tmp", None)
        base_name = "test_add[1+2-3]".split('[')[0]
        assert base_name == "test_add"

    def test_go_subtest_name_extraction(self):
        """测试 Go subtest 名提取"""
        from coverage_tool.test_removers.go_remover import GoSmartTestRemover
        remover = GoSmartTestRemover("/tmp", None)
        base_name = "TestMath/positive".split('/')[0]
        assert base_name == "TestMath"

    def test_java_parameterized_test_name_extraction(self):
        """测试 Java 参数化测试名提取"""
        from coverage_tool.test_removers.java_remover import JavaSmartTestRemover
        remover = JavaSmartTestRemover("/tmp", None)
        base_name = "testMethod[1]".split('[')[0]
        assert base_name == "testMethod"

    def test_cpp_google_test_name_extraction(self):
        """测试 C++ Google Test 名提取"""
        from coverage_tool.test_removers.cpp_remover import CPPSmartTestRemover
        remover = CPPSmartTestRemover("/tmp", None)
        base_name = "MathSuite.AddTest".split('.')[-1]
        assert base_name == "AddTest"


class TestIntegration:
    """集成测试"""

    def test_full_workflow_with_mock(self):
        """测试完整工作流（使用 Mock）"""
        config = ToolConfig(
            language=Language.PYTHON,
            target_dir="/tmp/test"
        )

        with patch.object(CoverageTool, '_check_environment', return_value=True):
            with patch.object(CoverageTool, '_compile_with_retry', return_value=True):
                with patch.object(CoverageTool, '_run_tests') as mock_run_tests:
                    mock_result = RunResult(
                        success=True,
                        return_code=0,
                        stdout="",
                        stderr="",
                        duration=5.0,
                        junit_xml_path="/tmp/report.xml",
                        coverage_rate=80.0
                    )
                    mock_run_tests.return_value = mock_result

                    with patch.object(CoverageTool, '_parse_test_report') as mock_parse:
                        mock_report = TestReport(
                            suites=[TestSuite(
                                name="test",
                                tests=10,
                                failures=0,
                                errors=0,
                                skipped=0,
                                time=1.0,
                                test_cases=[]
                            )]
                        )
                        mock_parse.return_value = mock_report

                        with patch.object(CoverageTool, '_generate_report') as mock_generate:
                            from coverage_tool.core import CoverageReport, CoverageStats
                            mock_generate.return_value = CoverageReport(
                                project_name="test",
                                stats=[CoverageStats(
                                    language="python",
                                    total_tests=10,
                                    passed_tests=10,
                                    failed_tests=0,
                                    error_tests=0,
                                    skipped_tests=0,
                                    pass_rate=100.0,
                                    coverage_rate=80.0,
                                    duration=5.0,
                                    test_files=5,
                                    source_files=10,
                                    deleted_files=0
                                )],
                                total_duration=5.0,
                                overall_pass_rate=100.0,
                                overall_coverage=80.0
                            )

                            tool = CoverageTool(config)
                            report = tool.run()
                            assert report is not None


def run_all_tests():
    """运行所有测试"""
    print("="*60)
    print("运行项目单元测试")
    print("="*60)

    test_classes = [
        TestToolConfig,
        TestCoverageTool,
        TestRunners,
        TestRunResult,
        TestCoverageExtractor,
        TestJunitXMLParser,
        TestTestRemovers,
        TestTestFunction,
        TestCoverageInjector,
        TestSmartCompilationHandler,
        TestEnvironmentChecker,
        TestFileBackupManager,
        TestExecutionPhase,
        TestExecutionResult,
        TestContentSearch,
        TestIntegration,
    ]

    total_tests = 0
    total_passed = 0

    for test_class in test_classes:
        instance = test_class()
        class_name = test_class.__name__
        print(f"\n{class_name}:")

        test_methods = [m for m in dir(instance) if m.startswith('test_')]
        passed = 0

        for method_name in test_methods:
            try:
                method = getattr(instance, method_name)
                method()
                print(f"  ✓ {method_name}")
                passed += 1
                total_passed += 1
            except Exception as e:
                print(f"  ✗ {method_name}: {e}")
            total_tests += 1

        print(f"  ({passed}/{len(test_methods)} 通过)")

    print("\n" + "="*60)
    print(f"总计: {total_passed}/{total_tests} 测试通过")
    print("="*60)

    return total_passed == total_tests


if __name__ == '__main__':
    success = run_all_tests()
    exit(0 if success else 1)
