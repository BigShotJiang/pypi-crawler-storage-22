#!/usr/bin/env python3
"""
运行器基类和共享组件
"""

import subprocess
import os
import time
import re
from abc import ABC, abstractmethod
from typing import List, Dict, Optional, Tuple, Any
from pathlib import Path
from dataclasses import dataclass

from coverage_tool.core import CoverageConfig
from coverage_tool.utils import Logger


@dataclass
class RunResult:
    """运行结果"""
    success: bool
    return_code: int
    stdout: str
    stderr: str
    duration: float
    junit_xml_path: Optional[str] = None
    coverage_rate: float = 0.0


class CoverageExtractor:
    """覆盖率提取器 - 统一处理不同语言的覆盖率"""
    
    @staticmethod
    def extract_from_coverage_out(coverage_out_path: str, language: str) -> float:
        """从coverage.out文件提取覆盖率"""
        if not os.path.exists(coverage_out_path):
            return 0.0
        
        try:
            if language == 'go':
                return CoverageExtractor._extract_go_coverage(coverage_out_path)
            elif language in ['c', 'cpp']:
                return CoverageExtractor._extract_gcov_coverage(coverage_out_path)
            else:
                return CoverageExtractor._extract_generic_coverage(coverage_out_path)
        except Exception as e:
            print(f"提取覆盖率失败: {e}")
            return 0.0
    
    @staticmethod
    def _extract_go_coverage(coverage_out_path: str) -> float:
        """提取Go覆盖率"""
        # 使用 go tool cover
        result = subprocess.run(
            f"go tool cover -func={coverage_out_path}",
            shell=True,
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            for line in result.stdout.split('\n'):
                if 'total:' in line.lower():
                    parts = line.split()
                    for part in reversed(parts):
                        if '%' in part:
                            try:
                                return float(part.replace('%', ''))
                            except:
                                pass
        
        # 备用方案：直接解析文件
        return CoverageExtractor._parse_go_coverage_file(coverage_out_path)
    
    @staticmethod
    def _parse_go_coverage_file(coverage_out_path: str) -> float:
        """直接解析Go coverage.out文件"""
        try:
            with open(coverage_out_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            if not lines or not lines[0].startswith('mode:'):
                return 0.0
            
            total_statements = 0
            executed_statements = 0
            
            for line in lines[1:]:
                parts = line.strip().split()
                if len(parts) >= 3:
                    try:
                        hits = int(parts[-1])
                        total_statements += 1
                        if hits > 0:
                            executed_statements += 1
                    except:
                        continue
            
            if total_statements > 0:
                return (executed_statements / total_statements) * 100
        except Exception as e:
            print(f"解析Go覆盖率文件失败: {e}")
        
        return 0.0
    
    @staticmethod
    def _extract_gcov_coverage(coverage_out_path: str) -> float:
        """提取gcov覆盖率"""
        try:
            with open(coverage_out_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 尝试多种模式匹配
            patterns = [
                r'lines[\s\w:]+(\d+\.?\d*)%',
                r'Total[\s\w:]+(\d+\.?\d*)%',
                r'(\d+\.?\d*)%',
            ]
            
            for pattern in patterns:
                match = re.search(pattern, content, re.IGNORECASE)
                if match:
                    try:
                        return float(match.group(1))
                    except:
                        continue
        except Exception as e:
            print(f"提取gcov覆盖率失败: {e}")
        
        return 0.0
    
    @staticmethod
    def _extract_generic_coverage(coverage_out_path: str) -> float:
        """通用覆盖率提取"""
        try:
            with open(coverage_out_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 查找百分比
            match = re.search(r'(\d+\.?\d*)%', content)
            if match:
                return float(match.group(1))
        except Exception as e:
            print(f"提取覆盖率失败: {e}")
        
        return 0.0
    
    @staticmethod
    def extract_from_jacoco(jacoco_html_path: str) -> float:
        """从JaCoCo HTML报告提取覆盖率"""
        if not os.path.exists(jacoco_html_path):
            return 0.0
        
        try:
            with open(jacoco_html_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 查找Total行中的覆盖率 (格式: <td class="ctr2">23%</td>)
            match = re.search(r'>Total.*?<td[^>]*class="ctr2"[^>]*>(\d+)%</td>', content, re.DOTALL)
            if match:
                return float(match.group(1))
            
            # 备用方案：查找任意ctr2列中的百分比
            match = re.search(r'class="ctr2"[^>]*>(\d+)%</td>', content)
            if match:
                return float(match.group(1))
        except Exception as e:
            print(f"提取JaCoCo覆盖率失败: {e}")
        
        return 0.0


class BaseRunner(ABC):
    """单测运行器基类"""
    
    def __init__(self, config: CoverageConfig, logger: Optional[Logger] = None):
        self.config = config
        self.logger = logger or Logger()
    
    @abstractmethod
    def run_tests(self, target_dir: str, output_file: str) -> RunResult:
        """运行测试"""
        pass
    
    @abstractmethod
    def get_coverage(self, output_file: str) -> float:
        """获取覆盖率"""
        pass
    
    @abstractmethod
    def compile(self, target_dir: str) -> Tuple[bool, List[str]]:
        """编译项目"""
        pass
    
    def find_files(self, target_dir: str, pattern: str) -> List[str]:
        """查找文件"""
        # 清理模式：移除开头的 **/ 或 **，确保是相对模式
        clean_pattern = pattern
        if clean_pattern.startswith("**/"):
            clean_pattern = clean_pattern[3:]
        elif clean_pattern.startswith("**"):
            clean_pattern = clean_pattern[2:]
        
        # 确保模式不为空且是相对路径
        if not clean_pattern or clean_pattern.startswith("/"):
            clean_pattern = "*" + clean_pattern if clean_pattern else "*"
        
        try:
            return [str(p) for p in Path(target_dir).rglob(clean_pattern) if p.is_file()]
        except Exception as e:
            self.logger.error(f"查找文件失败: {e}")
            return []
    
    def _run_command(self, cmd: str, cwd: str, timeout: int = 300) -> RunResult:
        """执行命令"""
        start_time = time.time()
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                cwd=cwd,
                timeout=timeout
            )
            duration = time.time() - start_time
            return RunResult(
                success=result.returncode == 0,
                return_code=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr,
                duration=duration
            )
        except subprocess.TimeoutExpired:
            duration = time.time() - start_time
            self.logger.error(f"命令执行超时: {cmd}")
            return RunResult(
                success=False,
                return_code=-1,
                stdout="",
                stderr=f"命令执行超时（{timeout}秒）",
                duration=duration
            )
        except Exception as e:
            duration = time.time() - start_time
            self.logger.error(f"命令执行异常: {e}")
            return RunResult(
                success=False,
                return_code=-1,
                stdout="",
                stderr=str(e),
                duration=duration
            )
