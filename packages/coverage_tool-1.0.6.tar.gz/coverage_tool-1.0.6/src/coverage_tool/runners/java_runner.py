#!/usr/bin/env python3
"""
Java单测运行器
"""

import os
import glob
import subprocess
import xml.etree.ElementTree as ET
from typing import List, Tuple, Optional

from .base import BaseRunner, RunResult, CoverageExtractor
from coverage_tool.handlers import CoverageInjector


class JavaRunner(BaseRunner):
    """Java单测运行器"""
    
    def __init__(self, config, logger=None):
        super().__init__(config=config, logger=logger)
        self.injector = CoverageInjector()

    def _ensure_jacoco(self, target_dir: str) -> Tuple[bool, str]:
        """确保JaCoCo已配置"""
        pom_path = os.path.join(target_dir, 'pom.xml')
        
        if not os.path.exists(pom_path):
            self.logger.warning("未找到pom.xml，无法自动配置JaCoCo")
            return False, "pom.xml 不存在"
        
        # 检查JaCoCo是否已配置
        jacoco_configured, jacoco_config = self.injector._check_jacoco_in_pom(pom_path)
        
        if jacoco_configured:
            self.logger.info("JaCoCo已配置")
            return True, "JaCoCo已配置"
        
        # 自动添加JaCoCo配置
        self.logger.info("未检测到JaCoCo配置，正在自动添加...")
        success, message = self.injector._add_jacoco_to_pom(pom_path)

        if success:
            self.logger.info(f"✓ {message} (Maven会自动下载插件)")
        else:
            self.logger.warning(f"✗ {message}")
        
        return success, message

    def _configure_javaagent(self, target_dir: str) -> Tuple[bool, str, Optional[str]]:
        """配置javaagent参数"""
        jacoco_agent_path = self.injector._find_jacoco_agent()

        if not jacoco_agent_path:
            self.logger.info("JaCoCo agent未找到，Maven会自动下载")
            return True, "Maven将自动下载agent", None

        pom_path = os.path.join(target_dir, 'pom.xml')
        if os.path.exists(pom_path):
            success, message = self.injector._configure_surefire_javaagent(pom_path, jacoco_agent_path)
            if success:
                self.logger.info(f"✓ {message}")
                return True, message, jacoco_agent_path

        return True, "javaagent配置跳过", jacoco_agent_path

    def run_tests(self, target_dir: str, output_file: str) -> RunResult:
        """运行Java测试（自动注入JaCoCo覆盖率）
        
        循环逻辑:
        1. 运行测试
        2. 如果编译失败，删除编译失败的测试文件
        3. 重复直到编译通过或没有更多文件可删
        """
        import re
        
        # 自动配置JaCoCo
        jacoco_success, jacoco_message = self._ensure_jacoco(target_dir)
        
        # 配置javaagent
        agent_success, agent_message, agent_path = self._configure_javaagent(target_dir)
        
        # 初始化result，避免linter警告
        result = self._run_command("echo 'init'", target_dir)
        result = RunResult(success=True, return_code=0, stdout="", stderr="", duration=0.0)
        
        # 循环删除编译失败的测试文件，直到编译通过
        max_iterations = 100
        iteration = 0
        
        while iteration < max_iterations:
            iteration += 1
            
            # 构建mvn命令
            mvn_cmd = "mvn clean test"
            self.logger.info(f"[测试命令] {mvn_cmd}")
            
            result = self._run_command(mvn_cmd, target_dir)
            
            # Maven输出可能包含错误信息在stdout或stderr中
            output = result.stdout + result.stderr
            
            # 检查是否有编译错误
            if not result.success or 'compilation failure' in output.lower() or 'compilation error' in output.lower():
                # 从错误信息中提取失败的文件
                file_pattern = r'(/[^:\s]+\.java):\[(\d+),(\d+)\]'
                matches = re.findall(file_pattern, output)
                
                if matches:
                    failed_file = matches[0][0]
                    self.logger.warning(f"[编译错误] 检测到测试文件编译失败: {failed_file}")
                    
                    # 删除编译失败的测试文件
                    if os.path.exists(failed_file):
                        try:
                            os.remove(failed_file)
                            self.logger.info(f"[编译错误] ✓ 已删除编译失败的测试文件: {failed_file}")
                            self.logger.info(f"[编译错误] 重新编译测试... ({iteration}/{max_iterations})")
                            continue  # 继续循环，重新编译
                        except Exception as e:
                            self.logger.error(f"[编译错误] 删除文件失败: {e}")
                            break
                    else:
                        self.logger.warning(f"[编译错误] 文件不存在或已被删除: {failed_file}")
                        break
                else:
                    # 有编译错误但无法提取文件
                    self.logger.error(f"[编译错误] 无法从错误信息中提取文件: {output[:500]}")
                    break
            else:
                # 编译成功，跳出循环
                self.logger.info("✓ 编译成功")
                break
        
        if iteration >= max_iterations:
            self.logger.warning(f"[编译警告] 达到最大迭代次数 {max_iterations}，停止删除")
        
        surefire_report = os.path.join(target_dir, "target", "surefire-reports")
        if os.path.exists(surefire_report):
            self._convert_surefire_reports(surefire_report, output_file)

        if not os.path.exists(output_file):
            junit_files = glob.glob(os.path.join(surefire_report, "*.xml"))
            if junit_files:
                self._merge_junit_reports(junit_files, output_file)
        
        # 生成JaCoCo报告
        self.logger.info("生成JaCoCo覆盖率报告...")
        jacoco_report_cmd = "mvn jacoco:report"
        self._run_command(jacoco_report_cmd, target_dir)
        
        # 同时尝试生成XML格式以便备用
        jacoco_xml_report = os.path.join(target_dir, "target", "site", "jacoco", "jacoco.xml")
        if not os.path.exists(jacoco_xml_report):
            exec_file = os.path.join(target_dir, "target", "jacoco.exec")
            if os.path.exists(exec_file):
                self.logger.info("尝试从jacoco.exec提取覆盖率...")
        
        result.junit_xml_path = output_file if os.path.exists(output_file) else None
        result.coverage_rate = self.get_coverage(target_dir)

        return result

    def _merge_junit_reports(self, junit_files: List[str], output_file: str):
        """合并多个JUnit XML报告为一个"""
        total_tests = 0
        total_failures = 0
        total_errors = 0
        total_skipped = 0
        test_suites = []

        for junit_file in junit_files:
            try:
                tree = ET.parse(junit_file)
                root = tree.getroot()

                if root.tag == 'testsuites':
                    for suite in root.findall('testsuite'):
                        test_suites.append(suite)
                elif root.tag == 'testsuite':
                    test_suites.append(root)
            except Exception as e:
                self.logger.warning(f"解析JUnit报告失败: {junit_file}: {e}")

        xml_declaration = '<?xml version="1.0" encoding="UTF-8"?>\n'
        testsuites_elem = ET.Element('testsuites')

        for suite in test_suites:
            testsuites_elem.append(suite)
            total_tests += int(suite.get('tests', 0))
            total_failures += int(suite.get('failures', 0))
            total_errors += int(suite.get('errors', 0))
            total_skipped += int(suite.get('skipped', 0))

        testsuites_elem.set('name', 'Merged Test Results')
        testsuites_elem.set('tests', str(total_tests))
        testsuites_elem.set('failures', str(total_failures))
        testsuites_elem.set('errors', str(total_errors))
        testsuites_elem.set('skipped', str(total_skipped))

        tree = ET.ElementTree(testsuites_elem)
        tree.write(output_file, encoding='UTF-8', xml_declaration=False)

        with open(output_file, 'r', encoding='utf-8') as f:
            content = f.read()
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(xml_declaration + content)

    def _convert_surefire_reports(self, surefire_dir: str, output_file: str):
        """转换Surefire报告为JUnit XML"""
        junit_files = glob.glob(os.path.join(surefire_dir, "TEST-*.xml"))
        if junit_files:
            self._merge_junit_reports(junit_files, output_file)

    def get_coverage(self, output_file: str) -> float:
        """获取Java覆盖率（JaCoCo）
        
        注意: 对于Java，这个方法使用 output_file 参数的父目录作为项目目录
        因为在 run_tests 中，我们传入的是 target_dir
        """
        # Java runner 在调用时传入 target_dir 作为 output_file 参数
        # JaCoCo 报告位置: {target_dir}/target/site/jacoco/index.html
        jacoco_html = os.path.join(output_file, "target", "site", "jacoco", "index.html")
        
        # 如果找不到，尝试从当前目录查找
        if not os.path.exists(jacoco_html):
            jacoco_html = "target/site/jacoco/index.html"
        
        return CoverageExtractor.extract_from_jacoco(jacoco_html)

    def compile(self, target_dir: str) -> Tuple[bool, List[str]]:
        """编译Java项目"""
        cmd = "mvn compile"
        result = self._run_command(cmd, target_dir)

        errors = []
        if not result.success:
            for line in result.stderr.split('\n'):
                if 'error:' in line.lower() or 'cannot find symbol' in line.lower():
                    errors.append(line.strip())

        return result.success, errors
