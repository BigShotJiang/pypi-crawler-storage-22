#!/usr/bin/env python3
"""
测试删除器基础模块
包含公共数据结构和基类
"""

import os
from abc import ABC, abstractmethod
from typing import List, Optional
from dataclasses import dataclass, field
from enum import Enum

from coverage_tool.utils import FileBackupManager, Logger
from coverage_tool.parsers import TestStatus, TestReport, TestCase


@dataclass
class TestFunction:
    """测试函数信息"""
    name: str
    file_path: str
    start_line: int
    end_line: int
    decorators: List[str] = field(default_factory=list)
    is_class_method: bool = False
    class_name: Optional[str] = None


class TestRemovalStrategy(Enum):
    """测试删除策略"""
    DELETE_FUNCTION = 1      # 仅删除测试函数
    DELETE_FILE = 2          # 删除整个测试文件
    COMMENT_OUT = 3          # 注释掉测试（保留代码）


class BaseSmartTestRemover(ABC):
    """智能测试删除器基类"""
    
    def __init__(self, project_dir: str, logger: Optional[Logger] = None):
        self.project_dir = project_dir
        self.logger = logger or Logger()
        self.backup_manager = FileBackupManager()
        self.deleted_tests: List[TestFunction] = []
        self.removal_strategy = TestRemovalStrategy.DELETE_FUNCTION
    
    @abstractmethod
    def find_test_functions(self, file_path: str) -> List[TestFunction]:
        """查找文件中的所有测试函数"""
        pass
    
    @abstractmethod
    def find_test_file(self, test_case: TestCase) -> Optional[str]:
        """根据测试用例找到对应的测试文件"""
        pass
    
    def _get_deletion_range(self, test_func: TestFunction, lines: List[str]) -> tuple:
        """
        获取要删除的行范围
        子类可以覆盖此方法以调整删除范围（例如考虑装饰器/注解）
        
        Returns:
            (start_idx, end_idx) - 行索引（0-based）
        """
        start_idx = test_func.start_line - 1
        end_idx = test_func.end_line
        return start_idx, end_idx
    
    def _adjust_start_for_decorators(self, test_func: TestFunction, lines: List[str], 
                                     comment_prefixes: Optional[List[str]] = None) -> int:
        """
        向上查找装饰器/注解，调整删除起始行
        
        Args:
            test_func: 测试函数信息
            lines: 文件行列表
            comment_prefixes: 注释前缀列表（如 ['#', '//']）
        
        Returns:
            调整后的起始行索引（0-based）
        """
        start_idx = test_func.start_line - 1
        
        while start_idx > 0:
            line = lines[start_idx - 1].strip()
            # 检查是否是装饰器/注解行
            if line.startswith('@'):
                start_idx -= 1
            # 检查是否是空行或注释行
            elif line == '':
                start_idx -= 1
            elif comment_prefixes:
                is_comment = any(line.startswith(prefix) for prefix in comment_prefixes)
                if is_comment:
                    start_idx -= 1
                else:
                    break
            else:
                break
        
        return start_idx
    
    def remove_test_function(self, test_func: TestFunction) -> bool:
        """
        删除单个测试函数 - 通用实现
        
        这是通用的文件行删除逻辑，适用于大多数语言。
        对于需要特殊处理的场景，子类可以覆盖 _get_deletion_range 方法。
        """
        try:
            with open(test_func.file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # 获取删除范围（可以由子类调整）
            start_idx, end_idx = self._get_deletion_range(test_func, lines)
            
            # 删除指定行范围
            new_lines = lines[:start_idx] + lines[end_idx:]
            
            # 写回文件
            with open(test_func.file_path, 'w', encoding='utf-8') as f:
                f.writelines(new_lines)
            
            return True
        
        except Exception as e:
            self.logger.error(f"删除测试函数失败 {test_func.file_path}:{test_func.name}: {e}")
            return False
    
    def remove_failed_tests(self, test_report: TestReport) -> tuple:
        """
        删除所有失败的测试
        
        修复：按文件分组 + 倒序删除，避免行号偏移问题
        
        Returns:
            (删除数量, 删除的测试列表)
        """
        from collections import defaultdict
        
        total_deleted = 0
        deleted_list = []
        
        # 按文件分组失败的测试用例
        failed_tests_by_file = defaultdict(list)  # {file_path: [(test_case, target_func), ...]}
        
        for suite in test_report.suites:
            for test_case in suite.test_cases:
                if test_case.status in [TestStatus.FAILED, TestStatus.ERROR]:
                    file_path = self.find_test_file(test_case)
                    
                    if not file_path or not os.path.exists(file_path):
                        self.logger.warning(f"找不到测试文件: {test_case.classname}.{test_case.name}")
                        continue
                    
                    # 处理特殊的构建失败
                    if self._is_build_failure(test_case.name):
                        self.logger.info(f"[编译错误] 包 {test_case.classname} 构建失败，准备删除该包的所有测试文件")
                        pkg_deleted_count, pkg_deleted_files = self.remove_all_tests_in_package(test_case.classname)
                        if pkg_deleted_count > 0:
                            total_deleted += pkg_deleted_count
                            for f in pkg_deleted_files:
                                deleted_list.append(f"{f}:BUILD_FAILURE_DELETED")
                            self.logger.info(f"[编译错误] ✓ 已删除 {pkg_deleted_count} 个测试文件解决包级编译错误")
                        else:
                            self.logger.warning(f"[编译错误] 未能找到包 {test_case.classname} 的测试文件")
                        continue
                    
                    # 查找测试函数
                    test_funcs = self.find_test_functions(file_path)
                    target_func = None
                    
                    for func in test_funcs:
                        if func.name == test_case.name or self._match_test_name(func.name, test_case.name):
                            target_func = func
                            break
                    
                    if target_func:
                        failed_tests_by_file[file_path].append((test_case, target_func))
                    else:
                        self.logger.warning(f"在文件 {file_path} 中找不到测试函数: {test_case.name}")
        
        # 按文件处理，每个文件内按行号倒序删除
        for file_path, test_list in failed_tests_by_file.items():
            if not test_list:
                continue
            
            # 备份文件（只备份一次）
            self.backup_manager.backup_file(file_path)
            
            # 按起始行号倒序排序（从最后一个开始删）
            test_list.sort(key=lambda x: x[1].start_line, reverse=True)
            
            # 依次删除每个测试函数
            for test_case, target_func in test_list:
                if self.remove_test_function(target_func):
                    total_deleted += 1
                    deleted_list.append(f"{file_path}:{target_func.name}")
                    self.deleted_tests.append(target_func)
                    self.logger.info(f"已删除测试函数: {file_path}:{target_func.name}")
                else:
                    self.logger.error(f"删除测试函数失败: {file_path}:{target_func.name}")
        
        return total_deleted, deleted_list
    
    def _is_build_failure(self, test_name: str) -> bool:
        """检查是否是构建失败的特殊测试名称"""
        build_failure_patterns = [
            '[build failed]',
            '[no test files]',
            '[setup failed]',
        ]
        return any(pattern in test_name for pattern in build_failure_patterns)
    
    def remove_all_tests_in_package(self, package_path: str) -> tuple:
        """
        删除指定包内的所有测试文件
        用于处理包级编译错误
        
        Returns:
            (删除数量, 删除的文件列表)
        """
        # 基类提供默认实现，子类应覆盖以提供语言特定的逻辑
        return 0, []
    
    def _match_test_name(self, func_name: str, test_name: str) -> bool:
        """匹配测试名称（处理不同的命名方式）"""
        # 完全匹配
        if func_name == test_name:
            return True
        
        # 忽略大小写匹配
        if func_name.lower() == test_name.lower():
            return True
        
        # 处理 Go 的测试名称（TestXxx/subtest 格式）
        if '/' in test_name:
            main_test = test_name.split('/')[0]
            if func_name == main_test:
                return True
        
        return False
    
    def restore_all(self) -> List[str]:
        """恢复所有修改"""
        restored = self.backup_manager.restore_all()
        self.deleted_tests.clear()
        return restored
    
    def cleanup(self):
        """清理资源"""
        self.backup_manager.cleanup()
