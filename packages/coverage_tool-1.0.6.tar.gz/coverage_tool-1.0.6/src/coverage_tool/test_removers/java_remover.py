#!/usr/bin/env python3
"""
Java测试删除器
使用正则表达式解析Java测试文件
"""

import re
import os
from typing import List, Optional
from pathlib import Path

from coverage_tool.test_removers.base import BaseSmartTestRemover, TestFunction
from coverage_tool.parsers import TestCase


class JavaSmartTestRemover(BaseSmartTestRemover):
    """Java智能测试删除器"""
    
    # 只匹配以 @Test 或 @ParameterizedTest 注解开头的测试方法
    TEST_METHOD_PATTERN = re.compile(
        r'^\s*@(?:Test|ParameterizedTest|org\.junit\.jupiter\.params\.ParameterizedTest)'
        r'(?:\([^)]*\))?\s*'                # @Test 注解（可能有参数）
        r'(?:@\w+(?:\([^)]*\))?\s*)*'       # 其他注解（支持带参数）
        r'(?:public\s+)?'                    # 访问修饰符
        r'(?:void|static|\w+)\s*'            # 返回类型
        r'(\w+)\s*'                          # 方法名
        r'\([^)]*\)\s*'                      # 参数列表
        r'(?:throws [\w,\s]+)?'              # throws 子句
        r'\s*\{',                            # 方法开始
        re.MULTILINE
    )

    # 也支持没有注解但以 test 开头的方法
    TEST_METHOD_PATTERN_SIMPLE = re.compile(
        r'^\s*(?:public\s+)?(?:void|static|\w+)\s*'  # 返回类型
        r'(test\w*)\s*'                               # 以 test 开头的方法名
        r'\([^)]*\)\s*'                               # 参数列表
        r'(?:throws [\w,\s]+)?'                       # throws 子句
        r'\s*\{',                                     # 方法开始
        re.MULTILINE
    )
    
    def _is_build_failure(self, test_name: str) -> bool:
        """检查是否是Java构建失败的特殊测试名称"""
        build_failure_patterns = [
            '[build failed]',
            '[compilation failed]',
            'Compilation failure',
            'cannot find symbol',
            'package does not exist',
            'class not found',
        ]
        return any(pattern in test_name for pattern in build_failure_patterns)
    
    def remove_all_tests_in_package(self, package_path: str) -> tuple:
        """
        删除指定Java包内的所有测试文件
        用于处理包级编译错误
        """
        deleted_count = 0
        deleted_files = []
        
        # Java包路径格式: com.example.test
        package_parts = package_path.split('.')
        
        if len(package_parts) > 0:
            # 将包路径转换为目录路径
            for i in range(len(package_parts)):
                subdir = '/'.join(package_parts[i:])
                
                # 搜索可能的目录结构
                search_paths = [
                    Path(self.project_dir) / subdir,
                    Path(self.project_dir) / 'src' / 'test' / 'java' / subdir,
                    Path(self.project_dir) / 'test' / subdir,
                    Path(self.project_dir) / 'tests' / subdir,
                ]
                
                for dir_path in search_paths:
                    if dir_path.exists() and dir_path.is_dir():
                        # 查找该目录下的所有测试文件
                        test_files = list(dir_path.glob("*Test.java")) + list(dir_path.glob("Test*.java"))
                        
                        if test_files:
                            self.logger.info(f"[编译错误] 在包 {package_path} 目录 {dir_path} 发现 {len(test_files)} 个测试文件")
                            
                            for test_file in test_files:
                                try:
                                    # 备份文件
                                    self.backup_manager.backup_file(str(test_file))
                                    # 删除文件
                                    test_file.unlink()
                                    deleted_count += 1
                                    deleted_files.append(str(test_file))
                                    self.logger.info(f"[编译错误] ✓ 已删除测试文件: {test_file}")
                                except Exception as e:
                                    self.logger.error(f"[编译错误] 删除文件失败: {test_file}: {e}")
                            
                            return deleted_count, deleted_files
        
        # 如果没找到，尝试递归搜索
        for search_pattern in ["**/*Test.java", "**/Test*.java"]:
            for test_file in Path(self.project_dir).rglob(search_pattern):
                try:
                    with open(test_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                    # 检查文件是否包含该包的导入或引用
                    if f"package {package_path}" in content or f"import {package_path}" in content:
                        self.backup_manager.backup_file(str(test_file))
                        test_file.unlink()
                        deleted_count += 1
                        deleted_files.append(str(test_file))
                        self.logger.info(f"[编译错误] ✓ 已删除测试文件: {test_file}")
                except:
                    continue
        
        return deleted_count, deleted_files
    
    def _find_method_end(self, content: str, start_pos: int) -> int:
        """找到方法的结束位置（正确处理嵌套括号和字符串）
        
        start_pos 是 '{' 之后的位置，brace_count 从 1 开始（因为已经看到函数体的开括号）
        """
        brace_count = 1
        in_string = False
        string_char = None  # ' 或 "
        
        for i, char in enumerate(content[start_pos:]):
            # 处理字符串
            if not in_string and char in ('"', "'"):
                in_string = True
                string_char = char
                continue
            
            if in_string and char == string_char:
                # 检查是否是转义的引号
                if i > 0 and content[start_pos + i - 1] != '\\':
                    in_string = False
                    string_char = None
                continue
            
            if in_string:
                continue  # 跳过字符串内的字符
            
            # 处理括号
            if char == '{':
                brace_count += 1
            elif char == '}':
                brace_count -= 1
                if brace_count == 0:
                    return start_pos + i + 1
        
        return start_pos  # 未找到匹配，返回开始位置

    def find_test_functions(self, file_path: str) -> List[TestFunction]:
        """查找Java测试方法"""
        test_methods_dict = {}  # {method_name: TestFunction} 保留起始行号最小的

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 查找 @Test 注解的测试方法
            for match in self.TEST_METHOD_PATTERN.finditer(content):
                method_name = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                end_pos = self._find_method_end(content, match.end())
                end_line = content[:end_pos].count('\n') + 1

                # 只保留起始行号最小的
                if method_name not in test_methods_dict or line_num < test_methods_dict[method_name].start_line:
                    test_methods_dict[method_name] = TestFunction(
                        name=method_name,
                        file_path=file_path,
                        start_line=line_num,
                        end_line=end_line,
                        decorators=['Test']
                    )

            # 查找以 test 开头的方法（无注解）- 只添加不存在的
            for match in self.TEST_METHOD_PATTERN_SIMPLE.finditer(content):
                method_name = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                end_pos = self._find_method_end(content, match.end())
                end_line = content[:end_pos].count('\n') + 1

                if method_name not in test_methods_dict:
                    test_methods_dict[method_name] = TestFunction(
                        name=method_name,
                        file_path=file_path,
                        start_line=line_num,
                        end_line=end_line,
                        decorators=[]
                    )

        except Exception as e:
            self.logger.error(f"解析Java文件失败 {file_path}: {e}")

        return list(test_methods_dict.values())
    
    def _get_deletion_range(self, test_func: TestFunction, lines: List[str]) -> tuple:
        """
        获取Java测试方法的删除范围
        考虑注解
        """
        start_idx = self._adjust_start_for_decorators(
            test_func, lines, comment_prefixes=['//']
        )
        end_idx = test_func.end_line
        return start_idx, end_idx
    
    def find_test_file(self, test_case: TestCase) -> Optional[str]:
        """查找Java测试文件（增强版）"""
        classname = test_case.classname
        test_name = test_case.name

        if self._is_build_failure(test_name):
            self.logger.info(f"[编译错误] 检测到Java编译失败: {test_name}")
            return self._find_java_test_file_from_package(classname)

        # 解析classname获取包名和类名
        parts = classname.split('.')
        package_path = ''
        class_name = ''

        if len(parts) >= 2:
            package_path = '/'.join(parts[:-1])
            class_name = parts[-1]
        elif len(parts) == 1:
            class_name = parts[0]

        # 1. 尝试多种类名变体
        search_class_names = set()
        search_class_names.add(class_name)
        if class_name.endswith('Test'):
            search_class_names.add(class_name[:-4])
        elif class_name.startswith('Test'):
            search_class_names.add(class_name[4:])

        # 2. 尝试多种路径组合
        test_patterns = []
        for cn in search_class_names:
            test_patterns.extend([
                f"{package_path}/{cn}Test.java" if package_path else f"{cn}Test.java",
                f"{package_path}/Test{cn}.java" if package_path else f"Test{cn}.java",
                f"test/{package_path}/{cn}Test.java" if package_path else f"test/{cn}Test.java",
                f"test/{package_path}/Test{cn}.java" if package_path else f"test/Test{cn}.java",
                f"tests/{package_path}/{cn}Test.java" if package_path else f"tests/{cn}Test.java",
                f"src/test/java/{package_path}/{cn}Test.java" if package_path else f"src/test/java/{cn}Test.java",
                f"src/test/java/{package_path}/Test{cn}.java" if package_path else f"src/test/java/Test{cn}.java",
                f"src/{package_path}/{cn}Test.java" if package_path else f"src/{cn}Test.java",
            ])

        for pattern in test_patterns:
            file_path = Path(self.project_dir) / pattern
            if file_path.exists():
                return str(file_path)

        # 3. 递归搜索所有测试文件进行内容匹配
        result = self._search_test_file_by_content(test_name, classname)
        if result:
            return result

        return None

    def _find_java_test_file_from_package(self, package_path: str) -> Optional[str]:
        """从包路径查找测试文件"""
        package_parts = package_path.split('.')
        
        for i in range(len(package_parts)):
            subdir = '/'.join(package_parts[i:])
            search_paths = [
                Path(self.project_dir) / subdir,
                Path(self.project_dir) / 'src' / 'test' / 'java' / subdir,
                Path(self.project_dir) / 'test' / subdir,
                Path(self.project_dir) / 'tests' / subdir,
            ]
            
            for dir_path in search_paths:
                if dir_path.exists() and dir_path.is_dir():
                    for test_file in dir_path.glob("*Test.java"):
                        if test_file.exists():
                            self.logger.info(f"[编译错误] 找到包 {package_path} 的测试文件: {test_file}")
                            return str(test_file)
        
        return None

    def _search_test_file_by_content(self, test_name: str, classname: str) -> Optional[str]:
        """通过测试方法内容搜索测试文件"""
        import fnmatch

        for search_pattern in ["**/*Test.java", "**/Test*.java"]:
            for test_file in Path(self.project_dir).rglob(search_pattern):
                try:
                    with open(test_file, 'r', encoding='utf-8') as f:
                        content = f.read()

                    # 提取基础方法名（去掉参数化后缀）
                    base_name = test_name.split('[')[0]

                    # 匹配 @Test 或 @ParameterizedTest 注解的方法（支持中间有其他注解）
                    patterns = [
                        rf'@(?:Test|ParameterizedTest|org\.junit\.jupiter\.params\.ParameterizedTest)(?:\s*\(?[^)]*\)?)?(?:\s*@\w+)*\s*(?:public\s+)?(?:static\s+)?(?:void|boolean|int)?\s+{re.escape(base_name)}\s*\(',
                        rf'public\s+(?:void|static\s+void)?\s+{re.escape(base_name)}\s*\(',
                    ]

                    for pattern in patterns:
                        if re.search(pattern, content, re.MULTILINE):
                            self.logger.info(f"通过内容搜索找到测试文件: {test_file}")
                            return str(test_file)
                except Exception:
                    continue

        return None
