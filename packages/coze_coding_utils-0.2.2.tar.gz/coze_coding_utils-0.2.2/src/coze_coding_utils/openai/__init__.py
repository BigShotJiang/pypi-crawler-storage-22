"""OpenAI Chat Completions API 兼容层"""

from coze_coding_utils.openai.handler import OpenAIChatHandler

__all__ = ["OpenAIChatHandler"]
