from .sql_model import sel_data, update_datas, del_data
from .config import set_db_config, get_db_config
