from CPpackage.db.sql_model import find_duplicate_records,delete_duplicate_records
import os

           
if __name__ == "__main__":
    # 配置你的参数
    TABLE_NAME = "pinlei_hgjk"  # 替换为实际表名
    DATABASE_NAME = "shengyicanmou_copy"  # 替换为实际数据库名
    # 你的唯一索引字段列表（必须是列表类型！）
    UNIQUE_FIELDS = ['begindate', 'enddate', 'value_l', 'sellerId', 'statDate', 'date_effect', 'store_id']
    PORT = 3306  # 可选，默认从配置获取
    
    # 第一步：查询重复记录
    dup_df = find_duplicate_records(TABLE_NAME, DATABASE_NAME, UNIQUE_FIELDS, PORT)
    
    # 第二步：确认有重复后删除
    if dup_df is not None and not dup_df.empty:
        delete_count = delete_duplicate_records(
            table_name=TABLE_NAME,
            database=DATABASE_NAME,
            unique_index_fields=UNIQUE_FIELDS,  # 必须传列表！
            port=PORT,
            keep_strategy="min_id"
        )