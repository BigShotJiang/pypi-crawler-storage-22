"""
Mock of cPyparsing as Python pyparsing for the sake of timing comparison.
"""

print("pyparsing -> cPyparsing mock loaded")

from cPyparsing import *
from cPyparsing import __version__, _trim_arity
from cPyparsing import pyparsing_test
