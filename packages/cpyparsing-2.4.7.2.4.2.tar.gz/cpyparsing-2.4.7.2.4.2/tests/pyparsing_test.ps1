$env:PYTHONPATH = "$PYTHONPATH;$HOME/Documents/GitHub/cpyparsing/tests/mock_py_as_c"
python ./cPyparsing_test.py
