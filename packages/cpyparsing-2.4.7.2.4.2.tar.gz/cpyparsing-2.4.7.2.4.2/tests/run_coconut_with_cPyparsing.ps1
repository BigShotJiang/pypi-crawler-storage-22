$env:PYTHONPATH = "$PYTHONPATH;$HOME/Documents/GitHub/cpyparsing/tests/mock_c_as_py"
python ./tests
