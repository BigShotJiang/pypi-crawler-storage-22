"""Base accessor class."""
from __future__ import annotations

from typing import Callable, TYPE_CHECKING

from cqla.exprs import base as exprs_base

if TYPE_CHECKING:
    from cqla.delegates import FieldDelegate
    from cqla.exprs.base import Expr


class Accessor:
    """Base class for type-specific accessors (.str, .list, .dt, .set)."""

    def __init__(self, expr: 'Expr | FieldDelegate') -> None:
        self._expr = expr

    def _expr_repr(self) -> str:
        raise NotImplementedError

    def apply(self, fn: Callable) -> 'Expr':
        # Use dynamic lookup so we get the combined Expr with accessors
        return exprs_base.Expr(
            lambda r: fn(self._expr(r)),
            f"{self._expr_repr()}.apply(<fn>)"
        )
