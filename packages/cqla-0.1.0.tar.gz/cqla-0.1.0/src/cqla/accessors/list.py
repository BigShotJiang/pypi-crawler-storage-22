"""List accessor for list operations."""
from __future__ import annotations

from typing import TYPE_CHECKING

from cqla.exprs import base as exprs_base
from cqla.accessors.base import Accessor

if TYPE_CHECKING:
    from cqla.exprs.base import Expr


class List(Accessor):
    """Accessor for list operations."""

    def _expr_repr(self) -> str:
        return f"{self._expr!r}.list"

    def any(self) -> Expr:
        return exprs_base.Expr(lambda r: any(self._expr(r)), f'{self._expr_repr()}.any()')

    def all(self) -> Expr:
        return exprs_base.Expr(lambda r: all(self._expr(r)), f'{self._expr_repr()}.all()')

    def len(self) -> Expr:
        return exprs_base.Expr(lambda r: len(self._expr(r)), f'{self._expr_repr()}.len()')

    def concat(self, other: list) -> Expr:
        return exprs_base.Expr(
            lambda r: self._expr(r) + list(other),
            f'{self._expr_repr()}.concat({other!r})'
        )

    def count_matches(self, element: object) -> Expr:
        return exprs_base.Expr(
            lambda r: self._expr(r).count(element),
            f'{self._expr_repr()}.count_matches({element!r})'
        )
