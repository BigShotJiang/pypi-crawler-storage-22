"""Expression types for cqla."""
from cqla.exprs import base as _base
from cqla.exprs.base import AliasMixin, AggExpr, AggPredicate, WindowExpr, ContextExpr
from cqla.exprs.mixins import AccessorMixin, AggMixin


class Expr(_base.Expr, AccessorMixin, AggMixin):
    """Expression with accessor and aggregation methods for chaining."""
    pass


# Replace Expr in base module so accessors return the combined version
_base.Expr = Expr


__all__ = ['Expr', 'AliasMixin', 'AggExpr', 'AggPredicate', 'WindowExpr', 'ContextExpr', 'AccessorMixin', 'AggMixin']
