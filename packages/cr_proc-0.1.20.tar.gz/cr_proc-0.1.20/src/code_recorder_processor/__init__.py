"""Code Recorder Processor - A tool for processing BYU CS code recording files."""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("cr_proc")
except PackageNotFoundError:
    __version__ = "unknown"
