class ConfigIntegrityError(Exception):
    pass
