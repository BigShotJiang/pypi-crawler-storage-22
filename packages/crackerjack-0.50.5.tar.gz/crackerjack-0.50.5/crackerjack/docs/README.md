> Crackerjack Docs: [Main](../../README.md) | [Crackerjack Package](../README.md) | [Docs](./README.md)

# Package Docs

Internal/generated documentation assets related to the package.

## Related

- [Crackerjack Package](../README.md) - Parent package
- [Documentation](../documentation/README.md) - Documentation helpers and build utilities
- [Data](../data/README.md) - Static data and assets
