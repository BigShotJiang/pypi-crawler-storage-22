import asyncio
import contextlib
import logging
import signal
import subprocess
import time
from dataclasses import dataclass
from enum import Enum

from rich.panel import Panel
from rich.table import Table

from crackerjack.services.connection_pool import get_http_pool
from crackerjack.services.security_logger import get_security_logger

from .console import CrackerjackConsole
from .timeout_manager import TimeoutStrategy, get_timeout_manager

logger = logging.getLogger("crackerjack.service_watchdog")


class ServiceState(Enum):
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    FAILED = "failed"
    TIMEOUT = "timeout"


@dataclass
class ServiceConfig:
    name: str
    command: list[str]
    health_check_url: str | None = None
    health_check_timeout: float = 5.0
    startup_timeout: float = 30.0
    shutdown_timeout: float = 10.0
    max_restarts: int = 5
    restart_delay: float = 5.0
    restart_backoff_multiplier: float = 2.0
    max_restart_delay: float = 300.0


@dataclass
class ServiceStatus:
    config: ServiceConfig
    state: ServiceState = ServiceState.STOPPED
    process: subprocess.Popen[bytes] | None = None
    last_start_time: float = 0.0
    last_health_check: float = 0.0
    restart_count: int = 0
    consecutive_failures: int = 0
    last_error: str = ""
    health_check_failures: int = 0

    @property
    def uptime(self) -> float:
        if self.state == ServiceState.RUNNING and self.last_start_time > 0:
            return time.time() - self.last_start_time
        return 0.0

    @property
    def is_healthy(self) -> bool:
        return (
            self.state == ServiceState.RUNNING
            and self.process is not None
            and self.process.poll() is None
            and self.health_check_failures < 3
        )


class ServiceWatchdog:
    def __init__(self, console: CrackerjackConsole | None = None) -> None:
        self.console = console or CrackerjackConsole()
        self.timeout_manager = get_timeout_manager()
        self.services: dict[str, ServiceStatus] = {}
        self.is_running = False
        self.monitor_task: asyncio.Task[None] | None = None

        self.default_configs = {
            "mcp_server": ServiceConfig(
                name="MCP Server",
                command=["python", "-m", "crackerjack", "--start-mcp-server"],
                startup_timeout=30.0,
                shutdown_timeout=15.0,
            ),
            "zuban_lsp": ServiceConfig(
                name="Zuban LSP Server",
                command=["uv", "run", "zuban", "server"],
                startup_timeout=15.0,
                shutdown_timeout=10.0,
                max_restarts=5,
                restart_delay=5.0,
                restart_backoff_multiplier=2.0,
                max_restart_delay=300.0,
            ),
        }

    def add_service(self, service_id: str, config: ServiceConfig) -> None:
        self.services[service_id] = ServiceStatus(config=config)
        logger.info(f"Added service {service_id} to watchdog")

    def remove_service(self, service_id: str) -> None:
        if service_id in self.services:
            from contextlib import suppress

            with suppress(RuntimeError):
                asyncio.create_task(self.stop_service(service_id))
            del self.services[service_id]
            logger.info(f"Removed service {service_id} from watchdog")

    async def start_watchdog(self) -> None:
        if self.is_running:
            return

        self.is_running = True

        await get_http_pool()

        for service_id, config in self.default_configs.items():
            self.add_service(service_id, config)

        self.monitor_task = asyncio.create_task(self._monitor_services())

        self._setup_signal_handlers()

        await self.console.aprint("[green]🐕 Service Watchdog started[/green]")
        logger.info("Service watchdog started")

    async def stop_watchdog(self) -> None:
        if not self.is_running:
            return

        self.is_running = False

        if self.monitor_task and not self.monitor_task.done():
            self.monitor_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.monitor_task

        stop_tasks = [self.stop_service(service_id) for service_id in self.services]
        if stop_tasks:
            await asyncio.gather(*stop_tasks, return_exceptions=True)

        await self.console.aprint("[yellow]🐕 Service Watchdog stopped[/yellow]")
        logger.info("Service watchdog stopped")

    async def start_service(self, service_id: str) -> bool:
        if not self._validate_service_start_request(service_id):
            return False

        service = self.services[service_id]

        try:
            return await self._execute_service_startup(service_id, service)
        except Exception as e:
            return await self._handle_service_start_failure(service, service_id, e)

    def _validate_service_start_request(self, service_id: str) -> bool:
        if service_id not in self.services:
            return False

        service = self.services[service_id]
        return service.state not in (ServiceState.RUNNING, ServiceState.STARTING)

    async def _execute_service_startup(
        self,
        service_id: str,
        service: ServiceStatus,
    ) -> bool:
        async with self.timeout_manager.timeout_context(
            f"start_service_{service_id}",
            timeout=service.config.startup_timeout,
            strategy=TimeoutStrategy.FAIL_FAST,
        ):
            self._prepare_service_startup(service)

            if not await self._start_service_process(service):
                return False

            if not await self._verify_service_health(service):
                return False

            await self._finalize_successful_startup(service, service_id)
            return True

    def _prepare_service_startup(self, service: ServiceStatus) -> None:
        service.state = ServiceState.STARTING
        service.last_start_time = time.time()

    async def _start_service_process(self, service: ServiceStatus) -> bool:
        security_logger = get_security_logger()
        security_logger.log_subprocess_execution(
            command=service.config.command,
            purpose="service_watchdog_start",
        )

        service.process = subprocess.Popen(
            service.config.command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True,
        )

        await asyncio.sleep(2)

        if service.process.poll() is not None:
            service.state = ServiceState.FAILED
            service.last_error = "Process exited immediately"
            return False

        return True

    async def _verify_service_health(self, service: ServiceStatus) -> bool:
        if not service.config.health_check_url:
            return True

        health_ok = await self._perform_health_check(service)
        if not health_ok:
            await self._terminate_process(service)
            service.state = ServiceState.FAILED
            service.last_error = "Health check failed"
            return False

        return True

    async def _finalize_successful_startup(
        self,
        service: ServiceStatus,
        service_id: str,
    ) -> None:
        service.state = ServiceState.RUNNING
        service.consecutive_failures = 0
        service.health_check_failures = 0

        await self.console.aprint(f"[green]✅ Started {service.config.name}[/green]")
        logger.info(f"Started service {service_id}")

    async def _handle_service_start_failure(
        self,
        service: ServiceStatus,
        service_id: str,
        error: Exception,
    ) -> bool:
        service.state = ServiceState.FAILED
        service.last_error = str(error)
        service.consecutive_failures += 1

        if service.process:
            asyncio.create_task(self._terminate_process(service))

        await self.console.aprint(
            f"[red]❌ Failed to start {service.config.name}: {error}[/red]",
        )
        logger.error(f"Failed to start service {service_id}: {error}")
        return False

    async def stop_service(self, service_id: str) -> bool:
        if service_id not in self.services:
            return False

        service = self.services[service_id]

        if service.state == ServiceState.STOPPED:
            return True

        try:
            async with self.timeout_manager.timeout_context(
                f"stop_service_{service_id}",
                timeout=service.config.shutdown_timeout,
                strategy=TimeoutStrategy.FAIL_FAST,
            ):
                service.state = ServiceState.STOPPING

                if service.process:
                    await self._terminate_process(service)

                service.state = ServiceState.STOPPED
                service.process = None

                await self.console.aprint(
                    f"[yellow]⏹️ Stopped {service.config.name}[/yellow]",
                )
                logger.info(f"Stopped service {service_id}")
                return True

        except Exception as e:
            service.state = ServiceState.FAILED
            service.last_error = str(e)

            await self.console.aprint(
                f"[red]❌ Failed to stop {service.config.name}: {e}[/red]",
            )
            logger.exception(f"Failed to stop service {service_id}: {e}")
            return False

    async def _monitor_services(self) -> None:
        while self.is_running:
            try:
                async with self.timeout_manager.timeout_context(
                    "monitor_services",
                    timeout=30.0,
                    strategy=TimeoutStrategy.GRACEFUL_DEGRADATION,
                ):
                    for service_id, service in self.services.items():
                        if not self.is_running:
                            break

                        try:
                            await self._check_service_health(service_id, service)
                        except Exception as e:
                            logger.exception(
                                f"Error checking service {service_id}: {e}"
                            )

                await asyncio.sleep(10)

            except Exception as e:
                logger.exception(f"Monitor services error: {e}")
                await asyncio.sleep(30)

    async def _check_service_health(
        self,
        service_id: str,
        service: ServiceStatus,
    ) -> None:
        if service.state == ServiceState.RUNNING:
            if service.process and service.process.poll() is not None:
                service.state = ServiceState.FAILED
                service.last_error = (
                    f"Process died with exit code {service.process.returncode}"
                )
                service.consecutive_failures += 1

                await self.console.aprint(
                    f"[red]💀 {service.config.name} process died[/red]",
                )
                return

    async def _perform_health_check(self, service: ServiceStatus) -> bool:
        if not service.config.health_check_url:
            return True

        try:
            pool = await get_http_pool()
            async with (
                self.timeout_manager.timeout_context(
                    "health_check",
                    timeout=service.config.health_check_timeout,
                    strategy=TimeoutStrategy.FAIL_FAST,
                ),
                pool.get_session_context() as session,
            ):
                async with session.get(service.config.health_check_url) as response:
                    return response.status == 200

        except Exception:
            return False

    async def _terminate_process(self, service: ServiceStatus) -> None:
        if not service.process:
            return

        try:
            service.process.terminate()

            try:
                await asyncio.wait_for(
                    self._wait_for_process_exit(service.process),
                    timeout=5.0,
                )
            except TimeoutError:
                service.process.kill()
                await asyncio.wait_for(
                    self._wait_for_process_exit(service.process),
                    timeout=2.0,
                )

        except Exception as e:
            logger.warning(f"Error terminating process: {e}")

            with contextlib.suppress(Exception):
                service.process.kill()

    async def _wait_for_process_exit(self, process: subprocess.Popen[bytes]) -> None:
        while process.poll() is None:
            await asyncio.sleep(0.1)

    def _setup_signal_handlers(self) -> None:
        def signal_handler(signum: int, frame: object) -> None:
            _ = frame
            logger.info(f"Received signal {signum}, stopping watchdog")
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self.stop_watchdog())
            except RuntimeError:
                try:
                    asyncio.run(self.stop_watchdog())
                except RuntimeError:
                    with contextlib.suppress(Exception):
                        loop = asyncio.new_event_loop()
                        try:
                            asyncio.set_event_loop(loop)
                            loop.run_until_complete(self.stop_watchdog())
                        finally:
                            loop.close()

        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

    def get_service_status(self, service_id: str) -> ServiceStatus | None:
        return self.services.get(service_id)

    def get_all_services_status(self) -> dict[str, ServiceStatus]:
        return self.services.copy()

    async def print_status_report(self) -> None:
        await self._print_report_header()

        if not self.services:
            await self.console.aprint("[dim]No services configured[/dim]")
            return

        table = self._create_status_table()
        await self.console.aprint(
            Panel(table, title="Service Status", border_style="blue"),
        )

    async def _print_report_header(self) -> None:
        await self.console.aprint("\n[bold blue]🐕 Service Watchdog Status[/bold blue]")
        await self.console.aprint("=" * 50)

    def _create_status_table(self) -> Table:
        table = Table()
        table.add_column("Service")
        table.add_column("Status")
        table.add_column("Uptime")

        for service in self.services.values():
            status_display = self._get_service_status_display(service)
            uptime_display = self._format_uptime(service.uptime)
            table.add_row(service.config.name, status_display, uptime_display)

        return table

    def _get_service_status_display(self, service: ServiceStatus) -> str:
        status_map = {
            (ServiceState.RUNNING, True): "[green]🟢 Running[/green]",
            (ServiceState.STARTING, None): "[yellow]🟡 Starting[/yellow]",
            (ServiceState.STOPPING, None): "[yellow]🟡 Stopping[/yellow]",
            (ServiceState.FAILED, None): "[red]🔴 Failed[/red]",
            (ServiceState.TIMEOUT, None): "[red]⏰ Timeout[/red]",
        }

        if service.state == ServiceState.RUNNING and service.is_healthy:
            return status_map[(ServiceState.RUNNING, True)]

        status_key = (service.state, None)
        return status_map.get(status_key, "[dim]⚫ Stopped[/dim]")

    def _format_uptime(self, uptime: float) -> str:
        if uptime > 3600:
            return f"{uptime / 3600:.1f}h"
        if uptime > 60:
            return f"{uptime / 60:.1f}m"
        if uptime > 0:
            return f"{uptime:.0f}s"
        return "-"


_global_watchdog: ServiceWatchdog | None = None


def get_service_watchdog(console: CrackerjackConsole | None = None) -> ServiceWatchdog:
    global _global_watchdog
    if _global_watchdog is None:
        _global_watchdog = ServiceWatchdog(console)
    return _global_watchdog


def uptime() -> dict[str, float]:
    watchdog = get_service_watchdog()
    result = {}
    for service_id, status in watchdog.get_all_services_status().items():
        result[service_id] = status.uptime
    return result


def is_healthy() -> dict[str, bool]:
    watchdog = get_service_watchdog()
    result = {}
    for service_id, status in watchdog.get_all_services_status().items():
        result[service_id] = status.is_healthy
    return result


def add_service(service_id: str, config: ServiceConfig) -> None:
    watchdog = get_service_watchdog()
    watchdog.add_service(service_id, config)


def remove_service(service_id: str) -> None:
    watchdog = get_service_watchdog()
    watchdog.remove_service(service_id)


def start_watchdog(console: CrackerjackConsole | None = None) -> None:
    watchdog = get_service_watchdog(console)
    try:
        loop = asyncio.get_running_loop()

        loop.create_task(watchdog.start_watchdog())
    except RuntimeError:
        asyncio.run(watchdog.start_watchdog())


def stop_watchdog() -> None:
    watchdog = get_service_watchdog()
    try:
        loop = asyncio.get_running_loop()

        loop.create_task(watchdog.stop_watchdog())
    except RuntimeError:
        asyncio.run(watchdog.stop_watchdog())


def start_service(service_id: str) -> bool:
    watchdog = get_service_watchdog()
    try:
        loop = asyncio.get_running_loop()

        loop.create_task(watchdog.start_service(service_id))

        return True
    except RuntimeError:
        return asyncio.run(watchdog.start_service(service_id))


def stop_service(service_id: str) -> bool:
    watchdog = get_service_watchdog()
    try:
        loop = asyncio.get_running_loop()

        loop.create_task(watchdog.stop_service(service_id))

        return True
    except RuntimeError:
        return asyncio.run(watchdog.stop_service(service_id))


def get_service_status(service_id: str) -> ServiceStatus | None:
    watchdog = get_service_watchdog()
    return watchdog.get_service_status(service_id)


def get_all_services_status() -> dict[str, ServiceStatus]:
    watchdog = get_service_watchdog()
    return watchdog.get_all_services_status()


def print_status_report() -> None:
    watchdog = get_service_watchdog()
    try:
        loop = asyncio.get_running_loop()

        loop.create_task(watchdog.print_status_report())
    except RuntimeError:
        asyncio.run(watchdog.print_status_report())


def signal_handler(signum: int, frame: object) -> None:
    pass
