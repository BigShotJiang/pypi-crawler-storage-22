import re
import shutil
import subprocess
import sys
import time
import typing as t
from pathlib import Path

from rich import box
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from crackerjack.config import get_console_width
from crackerjack.core.console import CrackerjackConsole
from crackerjack.models.protocols import (
    ConsoleInterface,
    CoverageBadgeServiceProtocol,
    CoverageRatchetProtocol,
    OptionsProtocol,
)
from crackerjack.services.lsp_client import LSPClient
from crackerjack.services.testing.coverage_manager import CoverageManager
from crackerjack.services.testing.test_result_parser import TestResultParser
from crackerjack.services.testing.test_result_renderer import TestResultRenderer

from .test_command_builder import TestCommandBuilder
from .test_executor import TestExecutor

if t.TYPE_CHECKING:
    from crackerjack.models.test_models import TestFailure

ANSI_ESCAPE_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
root_path = Path.cwd()

class TestManager:
    __test__ = False

    def __init__(
        self,
        console: ConsoleInterface | None = None,
        pkg_path: Path | None = None,
        coverage_ratchet: CoverageRatchetProtocol | None = None,
        coverage_badge: CoverageBadgeServiceProtocol | None = None,
        command_builder: TestCommandBuilder | None = None,
        lsp_client: LSPClient | None = None,
        result_parser: TestResultParser | None = None,
        result_renderer: TestResultRenderer | None = None,
        coverage_manager: CoverageManager | None = None,
    ) -> None:
        if console is None:
            console = CrackerjackConsole()

        if coverage_ratchet is None:
            coverage_ratchet = None

        if coverage_badge is None:
            coverage_badge = None

        if command_builder is None:
            command_builder = TestCommandBuilder()

        if result_parser is None:
            result_parser = TestResultParser()

        if result_renderer is None:
            result_renderer = TestResultRenderer(console)

        self.console = console


        resolved_path = pkg_path or root_path
        try:
            self.pkg_path = Path(str(resolved_path))
        except Exception:

            self.pkg_path = Path(resolved_path)


        self.executor = TestExecutor(console, self.pkg_path)
        self.command_builder = command_builder
        self.result_parser = result_parser
        self.renderer = result_renderer


        if coverage_manager is None:
            coverage_manager = CoverageManager(
                console,
                self.pkg_path,
                coverage_ratchet,
                coverage_badge,
            )

        self.coverage_manager = coverage_manager
        self.coverage_ratchet = coverage_ratchet
        self._coverage_badge_service = coverage_badge
        self._lsp_client = lsp_client

        self._last_test_failures: list[str] = []
        self._progress_callback: t.Callable[[dict[str, t.Any]], None] | None = None
        self.coverage_ratchet_enabled = coverage_ratchet is not None
        self.use_lsp_diagnostics = True
        self._service_initialized = False
        self._request_count = 0
        self._error_count = 0
        self._custom_metrics: dict[str, t.Any] = {}
        self._resources: list[t.Any] = []

    def set_progress_callback(
        self,
        callback: t.Callable[[dict[str, t.Any]], None] | None,
    ) -> None:
        self._progress_callback = callback

    def initialize(self) -> None:
        self._service_initialized = True

    def cleanup(self) -> None:
        for resource in self._resources.copy():
            self.cleanup_resource(resource)
        self._resources.clear()
        self._service_initialized = False

    def health_check(self) -> bool:
        return True

    def shutdown(self) -> None:
        self.cleanup()

    def metrics(self) -> dict[str, t.Any]:
        return {
            "initialized": self._service_initialized,
            "requests": self._request_count,
            "errors": self._error_count,
            "custom_metrics": self._custom_metrics.copy(),
        }

    def is_healthy(self) -> bool:
        return self.health_check()

    def register_resource(self, resource: t.Any) -> None:
        self._resources.append(resource)

    def cleanup_resource(self, resource: t.Any) -> None:
        cleanup = getattr(resource, "cleanup", None)
        close = getattr(resource, "close", None)
        if callable(cleanup):
            cleanup()
        elif callable(close):
            close()

    def record_error(self, error: Exception) -> None:
        self._error_count += 1

    def increment_requests(self) -> None:
        self._request_count += 1

    def get_custom_metric(self, name: str) -> t.Any:
        return self._custom_metrics.get(name)

    def set_custom_metric(self, name: str, value: t.Any) -> None:
        self._custom_metrics[name] = value

    def set_coverage_ratchet_enabled(self, enabled: bool) -> None:
        self.coverage_ratchet_enabled = enabled
        if enabled:
            self.console.print(
                "[cyan]📊[/cyan] Coverage ratchet enabled-targeting 100 % coverage",
            )
        else:
            self.console.print("[yellow]⚠️[/yellow] Coverage ratchet disabled")

    def run_tests(self, options: OptionsProtocol) -> bool:
        run_pytest = bool(getattr(options, "test", False) or getattr(options, "run_tests", False))
        run_xcode = bool(getattr(options, "xcode_tests", False))

        if not run_pytest and not run_xcode:
            return True

        start_time = time.time()

        try:
            pytest_ok = self._run_pytest_if_needed(run_pytest, options, start_time)
            xcode_ok = self._run_xcode_if_needed(run_xcode, options)

            return pytest_ok and xcode_ok
        except Exception as e:
            return self._handle_test_error(start_time, e)

    def _run_pytest_if_needed(
        self,
        run_pytest: bool,
        options: OptionsProtocol,
        start_time: float,
    ) -> bool:
        if not run_pytest:
            return True

        result = self._execute_test_workflow(options)
        duration = time.time() - start_time
        workers = self.command_builder.get_optimal_workers(options, print_info=False)

        if result.returncode == 0:
            return self._handle_test_success(result.stdout, duration, options, workers)
        return self._handle_test_failure(
            result.stderr if result else "",
            result.stdout if result else "",
            duration,
            options,
            workers,
        )

    def _run_xcode_if_needed(
        self,
        run_xcode: bool,
        options: OptionsProtocol,
    ) -> bool:
        if not run_xcode:
            return True
        return self._execute_xcode_tests(options)

    def run_specific_tests(self, test_pattern: str) -> bool:
        self.console.print(f"[cyan]🧪[/cyan] Running tests matching: {test_pattern}")

        cmd = self.command_builder.build_specific_test_command(test_pattern)
        result = self.executor.execute_with_progress(cmd)

        success = result.returncode == 0
        if success:
            self.console.print("[green]✅[/green] Specific tests passed")
        else:
            self.console.print("[red]❌[/red] Some specific tests failed")

        return success

    def validate_test_environment(self) -> bool:
        if not self.has_tests():
            self.console.print("[yellow]⚠️[/yellow] No tests found")
            return False

        from rich.live import Live
        from rich.spinner import Spinner

        cmd = self.command_builder.build_validation_command()

        spinner = Spinner("dots", text="[cyan]Validating test environment...[/cyan]")
        try:


            with Live(spinner, console=self.console, transient=True):
                result = subprocess.run(
                    cmd, check=False, cwd=self.pkg_path, capture_output=True, text=True,
                )
        except Exception:
            result = subprocess.run(
                cmd, check=False, cwd=self.pkg_path, capture_output=True, text=True,
            )

        if result.returncode != 0:
            self.console.print("[red]❌[/red] Test environment validation failed")
            self.console.print(result.stderr)
            return False

        self.console.print("[green]✅[/green] Test environment validated")
        return True

    def get_coverage_ratchet_status(self) -> dict[str, t.Any]:
        if self.coverage_ratchet is None:
            return {"status": "disabled", "message": "Coverage ratchet unavailable"}
        return self.coverage_ratchet.get_status_report()

    def get_test_stats(self) -> dict[str, t.Any]:
        return {
            "has_tests": self.has_tests(),
            "coverage_ratchet_enabled": self.coverage_ratchet_enabled,
            "last_failures_count": len(self._last_test_failures),
        }

    def get_test_failures(self) -> list[str]:
        return self._last_test_failures.copy()

    def get_test_command(self, options: OptionsProtocol) -> list[str]:
        return self.command_builder.build_command(options)

    def get_coverage_report(self) -> str | None:
        try:
            if self.coverage_ratchet is None:
                return None
            return self.coverage_ratchet.get_coverage_report()
        except Exception:
            return None

    def _get_coverage_from_file(self) -> float | None:
        import json

        coverage_json_path = self.pkg_path / "coverage.json"
        if not coverage_json_path.exists():
            return None

        try:
            with coverage_json_path.open() as f:
                coverage_data = json.load(f)


            totals = coverage_data.get("totals", {})
            percent_covered = totals.get("percent_covered", None)

            if percent_covered is not None:
                return float(percent_covered)


            if "percent_covered" in coverage_data:
                return float(coverage_data["percent_covered"])


            files = coverage_data.get("files", {})
            if files:
                total_lines = 0
                covered_lines = 0
                for file_data in files.values():
                    summary = file_data.get("summary", {})
                    total_lines += summary.get("num_statements", 0)
                    covered_lines += summary.get("covered_lines", 0)

                if total_lines > 0:
                    return (covered_lines / total_lines) * 100

            return None

        except (json.JSONDecodeError, ValueError, KeyError, TypeError):
            return None

    def _handle_no_ratchet_status(
        self, direct_coverage: float | None,
    ) -> dict[str, t.Any]:
        if direct_coverage is not None:
            return {
                "status": "coverage_available",
                "coverage_percent": direct_coverage,
                "message": "Coverage data available from coverage.json",
                "source": "coverage.json",
            }

        return {
            "status": "not_initialized",
            "coverage_percent": 0.0,
            "message": "Coverage ratchet not initialized",
        }

    def _get_final_coverage(
        self, ratchet_coverage: float, direct_coverage: float | None,
    ) -> float:
        return direct_coverage if direct_coverage is not None else ratchet_coverage

    def get_coverage(self) -> dict[str, t.Any]:
        try:
            if self.coverage_ratchet is None:
                direct_coverage = self._get_coverage_from_file()
                return self._handle_no_ratchet_status(direct_coverage)

            status = self.coverage_ratchet.get_status_report()


            direct_coverage = self._get_coverage_from_file()


            if (
                not status or status.get("status") == "not_initialized"
            ) and direct_coverage is not None:
                return self._handle_no_ratchet_status(direct_coverage)


            if not status or status.get("status") == "not_initialized":
                return self._handle_no_ratchet_status(None)


            ratchet_coverage = status.get("current_coverage", 0.0)
            final_coverage = self._get_final_coverage(ratchet_coverage, direct_coverage)

            return {
                "status": "active",
                "coverage_percent": final_coverage,
                "target_coverage": status.get("target_coverage", 100.0),
                "next_milestone": status.get("next_milestone"),
                "progress_percent": status.get("progress_percent", 0.0),
                "last_updated": status.get("last_updated"),
                "milestones_achieved": status.get("milestones_achieved", []),
                "source": "coverage.json" if direct_coverage is not None else "ratchet",
            }
        except Exception as e:
            return {
                "status": "error",
                "coverage_percent": 0.0,
                "error": str(e),
                "message": "Failed to get coverage information",
            }

    def has_tests(self) -> bool:
        test_directories = ["tests", "test"]
        test_files = ["test_*.py", "*_test.py"]

        for test_dir in test_directories:
            test_path = self.pkg_path / test_dir
            if test_path.exists() and test_path.is_dir():
                for test_file_pattern in test_files:
                    if list(test_path.glob(f"**/{test_file_pattern}")):
                        return True

        for test_file_pattern in test_files:
            if list(self.pkg_path.glob(test_file_pattern)):
                return True

        return False

    def _execute_test_workflow(
        self, options: OptionsProtocol,
    ) -> subprocess.CompletedProcess[str]:
        self._print_test_start_message(options)

        cmd = self.command_builder.build_command(options)

        if self._progress_callback:
            return self.executor.execute_with_ai_progress(
                cmd, self._progress_callback, self._get_timeout(options),
            )
        return self.executor.execute_with_progress(cmd, self._get_timeout(options))

    def _print_test_start_message(self, options: OptionsProtocol) -> None:
        workers = self.command_builder.get_optimal_workers(options, print_info=False)
        timeout = self.command_builder.get_test_timeout(options)

        self.console.print(
            f"[cyan]🧪[/cyan] Running tests (workers: {workers}, timeout: {timeout}s)",
        )

    def _execute_xcode_tests(self, options: OptionsProtocol) -> bool:
        if sys.platform != "darwin":
            self.console.print(
                "[yellow]⚠️[/yellow] Xcode tests require macOS (xcodebuild not available).",
            )
            return False
        if shutil.which("xcodebuild") is None:
            self.console.print(
                "[red]❌[/red] xcodebuild not found. Install Xcode or Xcode Command Line Tools.",
            )
            return False
        cmd = self.command_builder.build_xcode_command(options)
        self.console.print(
            "[cyan]🧪[/cyan] Running Xcode tests "
            f"({getattr(options, 'xcode_scheme', 'MdInjectApp')})",
        )
        result = self.executor.execute_with_progress(cmd, self._get_timeout(options))
        if result.returncode == 0:
            self.console.print("[green]✅[/green] Xcode tests passed")
            return True
        self.console.print("[red]❌[/red] Xcode tests failed")
        return False

    def _handle_test_success(
        self,
        output: str,
        duration: float,
        options: OptionsProtocol,
        workers: int | str,
    ) -> bool:
        self.console.print(f"[green]✅[/green] Tests passed in {duration:.1f}s")


        stats = self._parse_test_statistics(output)

        stats["duration"] = duration
        if self._should_render_test_panel(stats):
            self._render_test_results_panel(stats, workers, success=True)

        if self.coverage_ratchet_enabled:
            return self._process_coverage_ratchet()

        return True

    def _handle_test_failure(
        self,
        stderr: str,
        stdout: str,
        duration: float,
        options: OptionsProtocol,
        workers: int | str,
    ) -> bool:
        combined_output = stdout + "\n" + stderr
        clean_output = self._strip_ansi_codes(combined_output)
        stats = self._parse_test_statistics(clean_output, already_clean=True)

        stats["duration"] = duration
        if self._should_render_test_panel(stats):
            self._render_test_results_panel(stats, workers, success=False)

        if clean_output.strip():
            self._handle_failure_with_output(clean_output)
        else:
            self._handle_failure_without_output(options, duration, workers)

        if options.verbose or getattr(options, "ai_debug", False):
            self._render_formatted_output(clean_output, options, already_clean=True)

        return False

    def _handle_failure_with_output(self, clean_output: str) -> None:
        failure_lines = self._extract_failure_lines(clean_output)
        if failure_lines:
            self._last_test_failures = failure_lines
            self._render_banner("Key Test Failures", line_style="red")
            for _failure in failure_lines:
                self.console.print(f"  {_failure}")
        else:
            self._last_test_failures = []

    def _handle_failure_without_output(
        self, options: OptionsProtocol, duration: float, workers: int | str
    ) -> None:
        border_line = "-" * getattr(options, "column_width", 70)
        self.console.print("\n🧪 TESTS Failed test execution")
        self.console.print(border_line)
        self.console.print(
            " [yellow]This may indicate a timeout or critical error[/yellow]",
        )
        self.console.print(
            f" [yellow]Duration: {duration:.1f}s, Workers: {workers}[/yellow]",
        )

        timeout = self.command_builder.get_test_timeout(options)
        timeout_threshold = timeout * 0.9
        if duration > timeout_threshold:
            self.console.print(
                f" [yellow]⚠️ Execution time ({duration:.1f}s) was very close to timeout ({timeout}s), may have timed out[/yellow]",
            )

        self.console.print(
            " [red]Workflow failed: Test workflow execution failed[/red]",
        )
        self.console.print(border_line)
        self._last_test_failures = []

    def _handle_test_error(self, start_time: float, error: Exception) -> bool:
        duration = time.time() - start_time
        self.console.print(
            f"[red]💥[/red] Test execution error after {duration:.1f}s: {error}",
        )
        return False

    def _parse_test_statistics(
        self, output: str, *, already_clean: bool = False,
    ) -> dict[str, t.Any]:
        return self.result_parser.parse_statistics(output, already_clean=already_clean)

    def _should_render_test_panel(self, stats: dict[str, t.Any]) -> bool:
        return self.renderer.should_render_test_panel(stats)

    def _render_test_results_panel(
        self,
        stats: dict[str, t.Any],
        workers: int | str,
        success: bool,
    ) -> None:
        self.renderer.render_test_results_panel(stats, workers, success)

    def _render_banner(
        self,
        title: str,
        *,
        line_style: str = "red",
        title_style: str | None = None,
        char: str = "━",
        padding: bool = True,
    ) -> None:
        self.renderer.render_banner(
            title,
            line_style=line_style,
            title_style=title_style,
            char=char,
            padding=padding,
        )

    def _process_coverage_ratchet(self) -> bool:
        return self.coverage_manager.process_coverage_ratchet()

    def _extract_failure_lines(self, output: str) -> list[str]:
        import re

        lines = output.split("\n")


        failures = self._extract_from_short_summary(lines)


        if not failures:
            failures = self._extract_from_test_paths(lines)

        return failures[:10]

    def _extract_from_short_summary(self, lines: list[str]) -> list[str]:
        import re

        failures = []
        in_summary = False

        for line in lines:
            if "short test summary" in line.lower():
                in_summary = True
                continue

            if in_summary and line.strip().startswith("="):
                break

            if in_summary and line.strip().startswith("FAILED"):
                test_name = self._parse_summary_failed_line(line.strip())
                if test_name:
                    failures.append(test_name)

        return failures

    def _parse_summary_failed_line(self, line: str) -> str | None:
        import re


        match = re.search(r"FAILED\s+(.+?)\s+-", line)
        if match:
            return match.group(1).strip()


        if "FAILED" in line:
            parts = line.split("FAILED", 1)
            if len(parts) > 1:
                test_name = parts[1].strip().split(" - ")[0].strip()
                return test_name or None

        return None

    def _extract_from_test_paths(self, lines: list[str]) -> list[str]:
        failures = []

        for line in lines:
            test_name = self._try_extract_test_name(line)
            if test_name and test_name not in failures:
                failures.append(test_name)
                if len(failures) >= 10:
                    break

        return failures

    def _try_extract_test_name(self, line: str) -> str | None:
        import re

        if not ("::" in line and "FAILED" in line.upper()):
            return None

        test_match = re.search(r"([a-zA-Z_/]+::.*?)(?:\s+|$)", line)
        if test_match:
            return test_match.group(1).strip()

        return None

    @staticmethod
    def _strip_ansi_codes(text: str) -> str:
        return ANSI_ESCAPE_RE.sub("", text)

    def _split_output_sections(self, output: str) -> list[tuple[str, str]]:
        sections: list[tuple[str, str]] = []

        current_section: list[str] = []
        current_type = "header"

        lines = output.split("\n")
        for line in lines:
            current_type, current_section = self._process_line_for_section(
                line, current_type, current_section, sections,
            )


        if current_section:
            sections.append((current_type, "\n".join(current_section)))

        return sections

    def _process_line_for_section(
        self,
        line: str,
        current_type: str,
        current_section: list[str],
        sections: list[tuple[str, str]],
    ) -> tuple[str, list[str]]:
        if self._is_summary_boundary(line):
            return self._handle_section_transition(
                line, current_type, current_section, sections, "summary",
            )
        if self._is_failure_start(line):
            return self._handle_failure_section(
                line, current_type, current_section, sections,
            )
        if self._is_footer_start(line):
            return self._handle_section_transition(
                line, current_type, current_section, sections, "footer",
            )
        current_section.append(line)
        return current_type, current_section

    def _is_summary_boundary(self, line: str) -> bool:
        return "short test summary" in line.lower()

    def _is_failure_start(self, line: str) -> bool:
        return " FAILED " in line or " ERROR " in line

    def _is_footer_start(self, line: str) -> bool:
        return line.startswith("=") and ("passed" in line or "failed" in line)

    def _handle_section_transition(
        self,
        line: str,
        current_type: str,
        current_section: list[str],
        sections: list[tuple[str, str]],
        new_type: str,
    ) -> tuple[str, list[str]]:
        if current_section:
            sections.append((current_type, "\n".join(current_section)))
        return new_type, [line]

    def _handle_failure_section(
        self,
        line: str,
        current_type: str,
        current_section: list[str],
        sections: list[tuple[str, str]],
    ) -> tuple[str, list[str]]:
        if current_section and current_type != "failure":
            sections.append((current_type, "\n".join(current_section)))
            current_section = []
        current_type = "failure"
        current_section.append(line)
        return current_type, current_section

    def _render_formatted_output(
        self,
        output: str,
        options: OptionsProtocol,
        *,
        already_clean: bool = False,
    ) -> None:

        clean_output = output if already_clean else self._strip_ansi_codes(output)


        if self._try_structured_rendering(clean_output, options):
            return


        self._render_fallback_sections(clean_output, options)

    def _try_structured_rendering(self, clean_output: str, options: OptionsProtocol) -> bool:
        try:
            failures = self._extract_structured_failures(clean_output)


            if failures:
                self._render_structured_failures_with_summary(clean_output, failures, options)
                return True
            return False
        except Exception as e:
            logger.exception(
                "Structured parsing failed, falling back to standard formatting",
                extra={"output_length": len(clean_output)}
            )
            self._render_parsing_error_message(e)
            return False

    def _render_structured_failures_with_summary(
        self, clean_output: str, failures: list["TestFailure"], options: OptionsProtocol,
    ) -> None:

        failed_tests = [f for f in failures if f.status == "FAILED"]
        error_tests = [f for f in failures if f.status == "ERROR"]
        skipped_tests = [f for f in failures if f.status == "SKIPPED"]


        if failed_tests:
            self._render_structured_failure_panels(failed_tests)


        is_verbose = getattr(options, "verbose", False)
        is_debug = getattr(options, "ai_debug", False)
        if error_tests and (is_verbose or is_debug):
            self._render_structured_failure_panels(error_tests)


        if skipped_tests and is_debug:
            self._render_structured_failure_panels(skipped_tests)

    def _render_parsing_error_message(self, error: Exception) -> None:
        self.renderer.render_parsing_error_message(error)

    def _render_fallback_sections(
        self, clean_output: str, options: OptionsProtocol,
    ) -> None:
        from rich.panel import Panel

        sections = self._split_output_sections(clean_output)

        for section_type, section_content in sections:
            if not section_content.strip():
                continue

            if section_type == "failure":
                self._render_failure_section(section_content)
            elif section_type == "summary":
                panel = Panel(
                    section_content.strip(),
                    title="[bold yellow]📋 Test Summary[/bold yellow]",
                    border_style="yellow",
                    width=get_console_width(),
                )
                self.console.print(panel)
            elif section_type == "footer":
                self.console.print(f"\n[cyan]{section_content.strip()}[/cyan]\n")
            else:

                if options.verbose or getattr(options, "ai_debug", False):
                    self.console.print(f"[dim]{section_content}[/dim]")

    def _render_failure_section(self, section_content: str) -> None:
        from rich.panel import Panel
        from rich.syntax import Syntax


        syntax = Syntax(
            section_content,
            "python",
            theme="monokai",
            line_numbers=False,
            word_wrap=True,
            background_color="default",
        )

        panel = Panel(
            syntax,
            title="[bold red]❌ Test Failure[/bold red]",
            border_style="red",
            width=get_console_width(),
        )
        self.console.print(panel)

    def _parse_failure_header(
        self, line: str, current_failure: "TestFailure | None",
    ) -> tuple["TestFailure | None", bool]:
        import re

        from crackerjack.models.test_models import TestFailure


        failure_match = re.match(r"^(.+?)\s+(FAILED|ERROR|SKIPPED|SKIP)", line)
        if failure_match:
            test_path, status = failure_match.groups()

            test_path = re.sub(r"\s*\[[\s\d]+%\]$", "", test_path).strip()


            if not (
                "::" in test_path
                or ".py::" in test_path
                or ".py:" in test_path
                or "/" in test_path
                or "\\" in test_path
            ):


                return current_failure, False


            normalized_status = "SKIPPED" if status == "SKIP" else status

            new_failure = TestFailure(
                test_name=test_path,
                status=normalized_status,
                location=test_path,
            )
            return new_failure, True
        return current_failure, False

    def _parse_location_and_assertion(
        self, line: str, current_failure: "TestFailure", in_traceback: bool,
    ) -> bool:
        import re


        location_match = re.match(r"^(.+?\.py):(\d+):\s*(.*)$", line)
        if location_match and in_traceback:
            file_path, line_num, error_type = location_match.groups()
            current_failure.location = f"{file_path}:{line_num}"
            if error_type:
                current_failure.short_summary = error_type
            return True


        if "AssertionError:" in line or line.strip().startswith("E assert "):
            assertion_text = line.strip().lstrip("E").strip()
            if current_failure.assertion:
                current_failure.assertion += "\n" + assertion_text
            else:
                current_failure.assertion = assertion_text
            return True

        return False

    def _parse_captured_section_header(self, line: str) -> tuple[bool, str | None]:
        if "captured stdout" in line.lower():
            return True, "stdout"
        if "captured stderr" in line.lower():
            return True, "stderr"
        return False, None

    def _parse_traceback_line(
        self, line: str, lines: list[str], i: int, current_failure: "TestFailure",
    ) -> bool:
        if line.startswith((" ", "\t", "E ")):
            current_failure.traceback.append(line)
            return True
        return not (line.strip().startswith(("=", "FAILED")) or (i < len(lines) - 1 and "FAILED" in lines[i + 1]))

    def _parse_captured_output(
        self, line: str, capture_type: str | None, current_failure: "TestFailure",
    ) -> bool:
        if line.strip().startswith(("=", "_")):
            return False

        if capture_type == "stdout":
            if current_failure.captured_stdout:
                current_failure.captured_stdout += "\n" + line
            else:
                current_failure.captured_stdout = line
        elif capture_type == "stderr":
            if current_failure.captured_stderr:
                current_failure.captured_stderr += "\n" + line
            else:
                current_failure.captured_stderr = line
        return True

    def _extract_structured_failures(self, output: str) -> list["TestFailure"]:
        failures: list[TestFailure] = []
        lines = output.split("\n")

        parsing_state: dict[str, t.Any] = {
            "current_failure": None,
            "in_traceback": False,
            "in_captured": False,
            "capture_type": None,
        }

        for i, line in enumerate(lines):
            result = self._parse_failure_line(
                line,
                lines,
                i,
                t.cast("TestFailure | None", parsing_state["current_failure"]),
                t.cast(bool, parsing_state["in_traceback"]),
                t.cast(bool, parsing_state["in_captured"]),
                t.cast("str | None", parsing_state["capture_type"]),
            )

            if result.get("stop_parsing"):
                break

            parsing_state = self._update_parsing_state(result, parsing_state)
            if result.get("skip_line"):
                continue

            if result.get("new_failure"):
                current = t.cast("TestFailure | None", parsing_state["current_failure"])
                if current:
                    failures.append(current)
                parsing_state["current_failure"] = result["new_failure"]
                parsing_state["in_traceback"] = True
                parsing_state["in_captured"] = False
                parsing_state["capture_type"] = None

        current = t.cast("TestFailure | None", parsing_state["current_failure"])
        if current:
            failures.append(current)

        self._enrich_failures_from_short_summary(failures, output)
        return failures

    def _update_parsing_state(
        self, result: dict[str, t.Any], state: dict[str, t.Any]
    ) -> dict[str, t.Any]:
        if not result.get("new_failure") and not result.get("skip_line"):
            state["in_traceback"] = result.get("in_traceback", state["in_traceback"])
            state["in_captured"] = result.get("in_captured", state["in_captured"])
            state["capture_type"] = result.get("capture_type", state["capture_type"])
        return state

    def _enrich_failures_from_short_summary(
        self, failures: list["TestFailure"], output: str,
    ) -> None:
        from crackerjack.models.test_models import TestFailure

        summary_failures = self._parse_short_summary(output)


        if not failures and summary_failures:
            self._create_failures_from_summary(failures, summary_failures)
            return


        if summary_failures:
            self._enrich_existing_failures(failures, summary_failures)


        self._match_unnamed_failures(failures, summary_failures)

    def _parse_short_summary(self, output: str) -> list[dict[str, str]]:
        import re

        lines = output.split("\n")
        in_summary = False
        summary_failures: list[dict[str, str]] = []

        for line in lines:
            if "short test summary" in line.lower():
                in_summary = True
                continue

            if in_summary and line.startswith("="):
                break

            if in_summary and line.strip().startswith("FAILED"):
                failure_data = self._parse_summary_failure_line(line.strip())
                if failure_data:
                    summary_failures.append(failure_data)

        return summary_failures

    def _parse_summary_failure_line(self, line: str) -> dict[str, str] | None:
        import re


        match = re.match(r"^FAILED\s+(.+?)\s+-\s+(.+)$", line)
        if match:
            test_path, error_message = match.groups()
            error_message = re.sub(r"\.\.\.$", "", error_message).strip()
            return {"test_path": test_path, "error_message": error_message}


        match2 = re.search(r"FAILED\s+(.+?)\s+-", line)
        if match2:
            test_path = match2.group(1)
            return {
                "test_path": test_path,
                "error_message": "Error: see full output above",
            }

        return None

    def _determine_failure_status(self, error_message: str) -> str:
        error_types = (
            "TypeError",
            "KeyError",
            "AttributeError",
            "IndexError",
            "ValueError",
            "RuntimeError",
            "NameError",
            "ImportError",
            "FileNotFoundError",
            "UnboundLocalError",
        )

        if any(
            error_message.startswith(f"{error_type}:")
            for error_type in error_types
        ):
            return "ERROR"
        return "FAILED"

    def _create_failures_from_summary(
        self,
        failures: list["TestFailure"],
        summary_failures: list[dict[str, str]],
    ) -> None:
        from crackerjack.models.test_models import TestFailure

        for summary_failure in summary_failures:
            error_message = summary_failure["error_message"]
            status = self._determine_failure_status(error_message)

            failures.append(
                TestFailure(
                    test_name=summary_failure["test_path"],
                    status=status,
                    location=summary_failure["test_path"],
                    assertion=error_message,
                ),
            )

    def _enrich_existing_failures(
        self,
        failures: list["TestFailure"],
        summary_failures: list[dict[str, str]],
    ) -> None:
        for summary_failure in summary_failures:
            test_path = summary_failure["test_path"]
            error_message = summary_failure["error_message"]
            status = self._determine_failure_status(error_message)


            if self._try_enrich_named_failure(failures, test_path, error_message, status):
                continue


            self._try_enrich_unnamed_failure(failures, test_path, error_message, status)

    def _try_enrich_named_failure(
        self,
        failures: list["TestFailure"],
        test_path: str,
        error_message: str,
        status: str,
    ) -> bool:
        for failure in failures:
            if failure.test_name == test_path:
                if not failure.assertion:
                    failure.assertion = error_message
                failure.status = status
                return True
        return False

    def _try_enrich_unnamed_failure(
        self,
        failures: list["TestFailure"],
        test_path: str,
        error_message: str,
        status: str,
    ) -> bool:
        unnamed_values = ("", "unknown", "N/A")

        for failure in failures:
            if not failure.test_name or failure.test_name in unnamed_values:
                failure.test_name = test_path
                if not failure.assertion:
                    failure.assertion = error_message
                failure.status = status
                return True
        return False

    def _match_unnamed_failures(
        self,
        failures: list["TestFailure"],
        summary_failures: list[dict[str, str]],
    ) -> None:
        unnamed_values = ("", "unknown", "N/A")
        unnamed_failures = [
            f for f in failures
            if not f.test_name or f.test_name in unnamed_values
        ]

        if not unnamed_failures or len(unnamed_failures) > len(summary_failures):
            return

        for i, failure in enumerate(unnamed_failures):
            if i < len(summary_failures):
                failure.test_name = summary_failures[i]["test_path"]
                error_message = summary_failures[i]["error_message"]

                if not failure.assertion:
                    failure.assertion = error_message

                failure.status = self._determine_failure_status(error_message)

    def _parse_failure_line(
        self,
        line: str,
        lines: list[str],
        index: int,
        current_failure: "TestFailure | None",
        in_traceback: bool,
        in_captured: bool,
        capture_type: str | None,
    ) -> dict[str, t.Any]:
        result: dict[str, t.Any] = {}


        if "short test summary" in line.lower():
            result["stop_parsing"] = True
            return result


        new_failure, header_found = self._parse_failure_header(line, current_failure)
        if header_found:
            result["new_failure"] = new_failure
            return result

        if not current_failure:
            result["skip_line"] = True
            return result


        is_captured, new_capture_type = self._parse_captured_section_header(line)
        if is_captured:
            result["in_captured"] = True
            result["capture_type"] = new_capture_type
            result["in_traceback"] = False
            return result


        if in_captured and capture_type:
            in_captured = self._parse_captured_output(line, capture_type, current_failure)
            result["in_captured"] = in_captured
            if not in_captured:
                result["capture_type"] = None
            return result

        if in_traceback:
            in_traceback = self._parse_traceback_line(line, lines, index, current_failure)
            result["in_traceback"] = in_traceback
            return result


        if self._parse_location_and_assertion(line, current_failure, in_traceback):
            result["skip_line"] = True
            return result

        return result

    def _render_structured_failure_panels(self, failures: list["TestFailure"]) -> None:

        if not failures:
            return


        first_status = failures[0].status
        if first_status == "FAILED":
            title = f"❌ Failed Tests ({len(failures)} total)"
            style = "red"
        elif first_status == "ERROR":
            title = f"💥 Errored Tests ({len(failures)} total)"
            style = "bright_red"
        elif first_status == "SKIPPED":
            title = f"⏭ Skipped Tests ({len(failures)} total)"
            style = "yellow"
        else:
            title = f"❓ Test Issues ({len(failures)} total)"
            style = "white"


        console_width = get_console_width()
        self.console.print()
        self.console.print(f"[bold {style}]{'━' * console_width}[/bold {style}]")
        self.console.print(f"[bold {style}]{title}[/bold {style}]")
        self.console.print(f"[bold {style}]{'━' * console_width}[/bold {style}]")
        self.console.print()


        for i, failure in enumerate(failures, 1):
            self._render_single_failure(failure, i, len(failures), style)

    def _render_single_failure(
        self, failure: "TestFailure", index: int, total: int, style: str,
    ) -> None:
        self._print_failure_header(index, failure, style)
        self._print_failure_location(failure)
        self._print_failure_status(failure, style)
        self._print_failure_summary(failure)
        self._print_failure_traceback(failure)

    def _print_failure_header(
        self, index: int, failure: "TestFailure", style: str,
    ) -> None:
        self.console.print()
        self.console.print(
            f"[bold {style}]{index}.[/bold {style}] "
            f"[bold cyan]{failure.test_name}[/bold cyan]"
        )

    def _print_failure_location(self, failure: "TestFailure") -> None:
        if failure.location and failure.location != failure.test_name:
            self.console.print(
                f"   [dim]📍 Location:[/dim] [blue]{failure.location}[/blue]"
            )

    def _print_failure_status(self, failure: "TestFailure", style: str) -> None:
        self.console.print(
            f"   [dim]❌ Status:[/dim] [bold {style}]{failure.status}[/bold {style}]"
        )

    def _print_failure_summary(self, failure: "TestFailure") -> None:
        summary = self._get_failure_summary(failure)
        if summary:
            self.console.print(f"   [dim]📝[/dim] [yellow]{summary}[/yellow]")

    def _get_failure_summary(self, failure: "TestFailure") -> str | None:
        if failure.short_summary:
            return self._truncate_text(failure.short_summary, 200)
        if failure.assertion:
            first_line = failure.assertion.split("\n")[0].strip()
            return self._truncate_text(first_line, 200)
        return None

    def _truncate_text(self, text: str, max_length: int) -> str:
        if len(text) > max_length:
            return text[:max_length - 3] + "..."
        return text

    def _print_failure_traceback(self, failure: "TestFailure") -> None:
        preview = self._get_traceback_preview(failure)
        if preview:
            self.console.print(f"   [dim]💡 Traceback:[/dim] [dim]{preview}[/dim]")

    def _get_traceback_preview(self, failure: "TestFailure") -> str | None:
        if not failure.traceback:
            return None
        preview = failure.traceback[0]
        if not preview:
            return None
        return self._truncate_text(preview, 150)

    def _build_simple_failure_list(self, failures: list["TestFailure"]) -> str:
        lines = []

        for _i, failure in enumerate(failures, 1):

            lines.append(f"[bold cyan]• {failure.test_name}[/bold cyan]")
            if failure.location and failure.location != failure.test_name:
                lines.append(f"[dim] → {failure.location}[/dim]")


            lines.append(f"[red] Status: {failure.status}[/red]")


            if failure.short_summary:
                lines.append(f"[yellow] {failure.short_summary}[/yellow]")
            elif failure.assertion:

                first_line = failure.assertion.split("\n")[0]
                if len(first_line) > 100:
                    first_line = first_line[:97] + "..."
                lines.append(f"[yellow] {first_line}[/yellow]")

        return "\n".join(lines)

    def _group_failures_by_file(
        self, failures: list["TestFailure"],
    ) -> dict[str, list["TestFailure"]]:
        failures_by_file: dict[str, list[TestFailure]] = {}
        for failure in failures:
            file_path = failure.get_file_path()
            if file_path not in failures_by_file:
                failures_by_file[file_path] = []
            failures_by_file[file_path].append(failure)
        return failures_by_file

    def _render_file_failure_header(
        self, file_path: str, file_failures: list["TestFailure"],
    ) -> None:
        self.console.print(
            f"\n[bold red]📁 {file_path}[/bold red] ({len(file_failures)} failure(s))\n",
        )

    def _render_single_failure_panel(
        self, failure: "TestFailure", index: int, total: int,
    ) -> None:
        from rich.console import Group
        from rich.panel import Panel


        table = self._create_failure_details_table(failure)


        components = self._build_failure_components(failure, table)


        group = Group(*components)
        panel = Panel(
            group,
            title=f"[bold red]❌ Failure {index}/{total}[/bold red]",
            border_style="red",
            width=get_console_width(),
            padding=(1, 2),
        )
        self.console.print(panel)

    def _create_failure_details_table(self, failure: "TestFailure") -> "Table":
        from rich import box
        from rich.table import Table

        table = Table(
            show_header=False,
            box=box.SIMPLE,
            padding=(0, 1),
            border_style="red",
        )
        table.add_column("Key", style="cyan bold", width=12)
        table.add_column("Value", overflow="fold")


        table.add_row("Test", f"[yellow]{failure.test_name}[/yellow]")
        table.add_row(
            "Location", f"[blue underline]{failure.location}[/blue underline]",
        )
        table.add_row("Status", f"[red bold]{failure.status}[/red bold]")

        if failure.duration:
            table.add_row("Duration", f"{failure.duration:.3f}s")


        duration_note = self._get_duration_note(failure)
        if duration_note:
            table.add_row("Timing", duration_note)

        return table

    def _build_failure_components(
        self, failure: "TestFailure", table: "Table",
    ) -> list[t.Any]:
        from rich.syntax import Syntax

        components: list[t.Any] = [table]


        if failure.assertion:
            components.extend(("", "[bold red]Assertion Error:[/bold red]"))
            assertion_syntax = Syntax(
                failure.assertion,
                "python",
                theme="monokai",
                line_numbers=False,
                background_color="default",
            )
            components.append(assertion_syntax)


        relevant_traceback = failure.get_relevant_traceback(max_lines=15)
        if relevant_traceback:
            components.extend(("", "[bold red]Traceback:[/bold red]"))
            traceback_text = "\n".join(relevant_traceback)
            traceback_syntax = Syntax(
                traceback_text,
                "python",
                theme="monokai",
                line_numbers=False,
                word_wrap=True,
                background_color="default",
            )
            components.append(traceback_syntax)


        if failure.captured_stdout:
            components.extend(("", "[bold yellow]Captured stdout:[/bold yellow]"))
            components.append(f"[dim]{failure.captured_stdout}[/dim]")

        if failure.captured_stderr:
            components.extend(("", "[bold yellow]Captured stderr:[/bold yellow]"))
            components.append(f"[dim]{failure.captured_stderr}[/dim]")

        return components

    def _get_duration_note(self, failure: "TestFailure") -> str | None:
        if not failure.duration:
            return None

        if failure.duration > 5:
            return (
                f"[bold red]{failure.duration:.2f}s – investigate slow test[/bold red]"
            )
        if failure.duration > 2:
            return f"[yellow]{failure.duration:.2f}s – moderately slow[/yellow]"
        return None

    def _get_timeout(self, options: OptionsProtocol) -> int:
        return self.command_builder.get_test_timeout(options)

    async def run_pre_test_lsp_diagnostics(self) -> bool:
        if not self.use_lsp_diagnostics or self._lsp_client is None:
            return True

        try:

            lsp_client = self._lsp_client


            if not lsp_client.is_server_running():
                return True


            diagnostics, _summary = lsp_client.check_project_with_feedback(
                self.pkg_path,
                show_progress=False,
            )


            has_errors = any(diags for diags in diagnostics.values())

            if has_errors:
                self.console.print(
                    "[yellow]⚠️ LSP detected type errors before running tests[/yellow]",
                )

                error_count = sum(len(diags) for diags in diagnostics.values())
                self.console.print(f"[yellow]Found {error_count} type issues[/yellow]")

            return not has_errors

        except Exception as e:
            logger.exception(
                "LSP diagnostics failed",
                extra={
                    "lsp_client": str(self.lsp_client) if self.lsp_client else None,
                }
            )
            self.console.print(f"[dim]LSP diagnostics failed: {e}[/dim]")
            return True

    def configure_lsp_diagnostics(self, enable: bool) -> None:
        self.use_lsp_diagnostics = enable

        if enable:
            self.console.print(
                "[cyan]🔍 LSP diagnostics enabled for faster test feedback[/cyan]",
            )

TestManagementImpl = TestManager
