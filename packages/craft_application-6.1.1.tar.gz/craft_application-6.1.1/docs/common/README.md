This directory contains documentation files that are meant to be shared and reused by
applications using Craft Application.

When consuming these docs, be sure to substitute |star| and |Starcraft| with the
appropriate terms for your product. For example:

```
.. |star| replace:: charm
.. |app-command| replace:: charmcraft
.. |Starcraft| replace:: Charmcraft

.. include:: common/craft-application/how-to/build-remotely.rst
```
