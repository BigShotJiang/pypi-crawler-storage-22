
.. |star| replace:: package
.. |app-command| replace:: <craft-app>
.. |Starcraft| replace:: Craft Application

.. include:: ../common/craft-application/how-to-guides/build-remotely.rst
