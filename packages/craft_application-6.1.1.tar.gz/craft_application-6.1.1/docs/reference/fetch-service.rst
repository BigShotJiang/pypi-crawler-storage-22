
.. |app| replace:: Craft Application
.. |artifact| replace:: artifact
.. |artifact-indefinite| replace:: an artifact

.. include:: ../common/craft-application/reference/fetch-service.rst
