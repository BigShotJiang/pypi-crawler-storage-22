
.. |star| replace:: package
.. |app-command| replace:: <craft-app>
.. |Starcraft| replace:: Craft Application

.. include:: ../common/craft-application/reference/remote-builds.rst
