import pytest

from crawlerverse.actions import Move
from crawlerverse.async_client import AsyncCrawlerClient
from crawlerverse.models import InProgressOutcome
from crawlerverse.types import Direction

OBSERVATION_JSON = {
    "turn": 1,
    "floor": 1,
    "player": {
        "position": [5, 5],
        "hp": 20,
        "maxHp": 20,
        "attack": 5,
        "defense": 3,
        "equippedWeapon": None,
        "equippedArmor": None,
    },
    "inventory": [],
    "visibleTiles": [{"x": 5, "y": 5, "type": "floor", "items": []}],
    "messages": [],
}


@pytest.fixture
async def client(monkeypatch):
    monkeypatch.setenv("CRAWLERVERSE_API_KEY", "cra_test123")
    async with AsyncCrawlerClient(base_url="https://test.example.com/api/agent") as c:
        yield c


async def test_create_game(client, httpx_mock):
    httpx_mock.add_response(
        method="POST",
        url="https://test.example.com/api/agent/games",
        json={
            "gameId": "game-1",
            "observation": OBSERVATION_JSON,
            "spectatorUrl": "https://crawlerver.se/spectate/game-1",
        },
        status_code=201,
    )
    game = await client.games.create(model_id="test")
    assert game.game_id == "game-1"


async def test_submit_action(client, httpx_mock):
    httpx_mock.add_response(
        method="POST",
        url="https://test.example.com/api/agent/games/game-1/action",
        json={
            "observation": OBSERVATION_JSON,
            "outcome": {"status": "in_progress"},
        },
    )
    result = await client.games.action("game-1", Move(direction=Direction.NORTH))
    assert isinstance(result.outcome, InProgressOutcome)


async def test_list_games(client, httpx_mock):
    httpx_mock.add_response(
        method="GET",
        url="https://test.example.com/api/agent/games?limit=20&offset=0",
        json={"games": [], "hasMore": False},
    )
    result = await client.games.list()
    assert result.games == []


async def test_get_game(client, httpx_mock):
    httpx_mock.add_response(
        method="GET",
        url="https://test.example.com/api/agent/games/game-1",
        json={
            "observation": OBSERVATION_JSON,
            "outcome": {"status": "in_progress"},
        },
    )
    state = await client.games.get("game-1")
    assert state.observation.turn == 1


async def test_health(client, httpx_mock):
    httpx_mock.add_response(
        method="GET",
        url="https://test.example.com/api/agent/health",
        json={
            "status": "ok",
            "service": "crawler-agent-api",
            "timestamp": "2025-02-02T10:30:00Z",
        },
    )
    health = await client.health()
    assert health.status == "ok"
