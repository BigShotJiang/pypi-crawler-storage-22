"""
PyPI setup configuration for Crawlier.
"""

from setuptools import setup, find_packages

setup(
    name="crawlier",
    version="0.0.2",
    author="Pansilu Chethiya (yoohoo-dev)",
    author_email="pansiluco@gmail.com",
    description="A modern Crawling library built completely from Python",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/YooHoo-byte/Crawlier",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.10",
    install_requires=[
        "requests>=2.28.0",
        "beautifulsoup4>=4.11.0",
        "lxml>=4.9.0",
        "dnspython>=2.2.0",
        "tqdm>=4.64.0",
        "gradio>=3.20.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.2.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
            "mypy>=0.991",
        ],
    },
    entry_points={
        "console_scripts": [
            "crawlier=crawlier.crawler:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
