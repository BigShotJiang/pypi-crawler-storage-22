"""
Crawlier - A Python web crawler for desktop (PansiluBot) and mobile (MethmiBot) modes.
"""

__version__ = "0.0.0.1"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__license__ = "MIT"

from .crawler import Crawlier, run_crawl, main

__all__ = ["Crawlier", "run_crawl", "main"]
