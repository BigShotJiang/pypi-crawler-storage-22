"""
Test initialization file.
"""
