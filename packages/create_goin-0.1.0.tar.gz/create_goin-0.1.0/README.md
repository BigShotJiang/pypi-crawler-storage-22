# create-goin

<div align="center">

**🚀 Python 项目初始化工具 - 快速创建标准化的项目骨架**

[![Python Version](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

</div>

---

## ✨ 特性

- 🎯 **快速创建** - 一条命令快速搭建项目骨架
- 📦 **模板支持** - 支持从 Git 仓库克隆各类项目模板
- 🎨 **灵活配置** - YAML 配置文件管理模板，易于扩展
- 🤖 **智能替换** - 自动替换模板中的变量（项目名、作者等）
- 💬 **交互友好** - 支持交互式和非交互式两种模式
- 🔧 **开箱即用** - 创建后即可开始开发，无需额外配置

## 📦 安装

### 使用 pip 安装

```bash
pipx install create-goin
```

### 从源码安装

```bash
git clone XXXXX
cd create-goin
pip install -e .
```

## 🚀 快速开始

### 1. 交互式创建项目

```bash
create-goin
```

工具会引导你输入项目信息：
- 项目名称
- 项目描述
- 作者名称
- 选择模板类型

### 2. 直接指定项目名称

```bash
create-goin my-awesome-project
```


## 📚 命令行参数

```bash
Usage: create-goin [OPTIONS] [PROJECT_NAME]

Options:
  -t, --template TEXT          项目模板类型（可选值见 --list-templates）
  -o, --output-dir PATH        项目输出目录（默认为当前目录）
  -y, --non-interactive        非交互模式，使用默认值
  -l, --list-templates         列出所有可用的模板
  --version                    显示版本信息
  --help                       显示帮助信息
```

## 🎨 可用模板

查看所有可用模板：

```bash
create-goin --list-templates
```

### 内置模板

| 模板名称 | 描述 | 类型 |
|---------|------|------|
| `ml-model-service` | 机器学习模型服务项目模板 | Git 模板 |

## ⚙️ 配置模板

你可以通过修改 `templates_config.yaml` 来添加自定义模板：

```yaml
templates:
  # 你的自定义模板
  my-custom-template:
    name: my-custom-template
    display_name: 我的自定义模板
    description: 这是一个自定义项目模板
    type: git
    source: https://github.com/your-org/your-template.git
    branch: main  # 可选，默认为 main
    variables:
      - PROJECT_NAME
      - PROJECT_DESCRIPTION
      - AUTHOR_NAME

# 设置默认模板
default_template: my-custom-template

# Git 克隆配置
git_config:
  timeout: 60  # 克隆超时时间（秒）
  depth: 1     # 浅克隆深度（加快克隆速度）
```

### 模板变量

模板中可以使用以下变量，工具会自动替换：

- `PROJECT_NAME` - 项目名称
- `PROJECT_DESCRIPTION` - 项目描述
- `AUTHOR_NAME` - 作者名称

## 📖 使用示例

### 示例 1：创建 ML 模型服务项目

```bash
$ create-goin ml-service -t ml-model-service

🚀 欢迎使用 create-goin！

项目名称: ml-service
项目描述: 一个机器学习模型推理服务
作者名称: Your Name

✨ 确认创建项目？ [Y/n]: y

🔨 正在创建项目...
✅ 项目创建成功！

📝 下一步操作：
  1. 进入项目目录：cd ml-service
  2. 创建虚拟环境：python -m venv .venv
  3. 安装依赖：pip install -e ".[dev]"
  4. 开始开发！
```

