"""
create-goin: Python 项目初始化工具

快速创建标准化的 Python 项目骨架。
"""

__version__ = "0.1.0"
__author__ = "Goin Team"
__license__ = "MIT"

__all__ = ["__version__", "__author__", "__license__"]
