"""
支持通过 python -m create_goin 运行
"""

from create_goin.cli import main

if __name__ == "__main__":
    main()
