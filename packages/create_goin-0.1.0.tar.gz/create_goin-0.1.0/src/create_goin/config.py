"""
配置管理模块
"""

from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


class TemplateConfig:
    """模板配置管理"""

    def __init__(self, config_path: Optional[Path] = None):
        """
        初始化配置

        Args:
            config_path: 配置文件路径，如果为 None 则使用默认路径
        """
        if config_path is None:
            config_path = Path(__file__).parent / "templates_config.yaml"

        self.config_path = config_path
        self._config: Dict[str, Any] = {}
        self._load_config()

    def _load_config(self) -> None:
        """加载配置文件"""
        if not self.config_path.exists():
            raise FileNotFoundError(f"配置文件不存在: {self.config_path}")

        with open(self.config_path, "r", encoding="utf-8") as f:
            self._config = yaml.safe_load(f)

    def get_template(self, name: str) -> Optional[Dict[str, Any]]:
        """
        获取模板配置

        Args:
            name: 模板名称

        Returns:
            模板配置字典，如果不存在返回 None
        """
        templates = self._config.get("templates", {})
        return templates.get(name)

    def get_all_templates(self) -> Dict[str, Dict[str, Any]]:
        """
        获取所有模板配置

        Returns:
            所有模板的字典
        """
        return self._config.get("templates", {})

    def get_template_names(self) -> List[str]:
        """
        获取所有模板名称

        Returns:
            模板名称列表
        """
        return list(self.get_all_templates().keys())

    def get_default_template(self) -> str:
        """
        获取默认模板名称

        Returns:
            默认模板名称
        """
        return self._config.get("default_template", "ml-model-service")

    def get_git_config(self) -> Dict[str, Any]:
        """
        获取 Git 配置

        Returns:
            Git 配置字典
        """
        return self._config.get("git_config", {})

    def is_git_template(self, name: str) -> bool:
        """
        判断是否为 Git 模板

        Args:
            name: 模板名称

        Returns:
            是否为 Git 模板
        """
        template = self.get_template(name)
        if not template:
            return False
        return template.get("type") == "git"

    def is_builtin_template(self, name: str) -> bool:
        """
        判断是否为内置模板

        Args:
            name: 模板名称

        Returns:
            是否为内置模板
        """
        template = self.get_template(name)
        if not template:
            return False
        return template.get("type") == "builtin"


# 全局配置实例
template_config = TemplateConfig()
