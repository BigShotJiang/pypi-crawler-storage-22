"""
交互式问答逻辑
"""

from typing import Dict, Optional

import click

from create_goin.utils import validate_project_name


def prompt_project_info(initial_name: Optional[str] = None) -> Dict[str, str]:
    """
    交互式收集项目信息

    Args:
        initial_name: 初始项目名称（可选）

    Returns:
        包含项目信息的字典
    """
    project_info = {}

    # 1. 项目名称
    if initial_name:
        project_name = initial_name
        # 验证名称
        is_valid, error_msg = validate_project_name(project_name)
        if not is_valid:
            click.echo(click.style(f"❌ 项目名称无效：{error_msg}", fg="red"), err=True)
            click.echo(click.style("💡 重新输入项目名称：", fg="yellow"))
            project_name = None

    if not initial_name or not project_name:
        while True:
            project_name = click.prompt(
                click.style("📦 项目名称", fg="cyan"),
                type=str,
            )
            is_valid, error_msg = validate_project_name(project_name)
            if is_valid:
                break
            click.echo(click.style(f"❌ {error_msg}", fg="red"))

    project_info["name"] = project_name

    # 2. 项目描述（可选）
    description = click.prompt(
        click.style("📝 项目描述", fg="cyan"),
        type=str,
        default="",
        show_default=False,
    )
    project_info["description"] = description.strip()

    # 3. 作者名称（可选）
    author = click.prompt(
        click.style("👤 作者名称", fg="cyan"),
        type=str,
        default="",
        show_default=False,
    )
    project_info["author"] = author.strip()


    return project_info
