
class Confidence(dict):
   """
   This class encapsulates information about the Confidence we
   should have on a Critic.  It is an alias of class dict (Hashtable in Java).

   author Bill Manaris and Tim Hirzel
   version 0.2, July 30, 2004
   """
   pass
