
class Judgement(dict):
   """
   This class is an alias of class dict (Hashtable in Java).

   author Bill Manaris and Tim Hirzel
   version 0.2, J, 2004
   """
   pass
