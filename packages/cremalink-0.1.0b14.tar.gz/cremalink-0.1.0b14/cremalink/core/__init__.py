"""
This package contains core utilities and base functionalities that are used
across the cremalink library.
"""

__all__ = []
