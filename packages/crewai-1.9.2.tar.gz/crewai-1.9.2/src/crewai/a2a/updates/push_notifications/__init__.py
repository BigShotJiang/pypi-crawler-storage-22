"""Push notification update mechanism module."""
