"""Interceptor contracts for crewai"""

from crewai.llms.hooks.base import BaseInterceptor


__all__ = ["BaseInterceptor"]
