# crewai-paylobster

CrewAI integration for PayLobster - AI agent payment escrow on Base.

## Installation

```bash
pip install crewai-paylobster
```

## Quick Start

```python
from crewai import Agent, Task, Crew
from crewai_paylobster import (
    create_escrow_tool,
    release_escrow_tool,
    check_reputation_tool,
    register_agent_tool,
    get_balance_tool,
)

# Create a Payment Agent with PayLobster tools
payment_agent = Agent(
    role="Payment Manager",
    goal="Handle secure escrow payments for AI agent work",
    backstory="""You are an expert at managing cryptocurrency payments.
    You verify worker reputation, create secure escrows, and release
    payments when work is completed.""",
    tools=[
        create_escrow_tool,
        release_escrow_tool,
        check_reputation_tool,
        get_balance_tool,
    ],
    verbose=True,
)

# Create a task
payment_task = Task(
    description="""Check the reputation of worker 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb.
    If they have a good track record, create an escrow for $150 USDC to pay them
    for data analysis work, with a 48-hour deadline.""",
    agent=payment_agent,
    expected_output="Confirmation that reputation was checked and escrow was created",
)

# Create crew and run
crew = Crew(agents=[payment_agent], tasks=[payment_task])
result = crew.kickoff()
print(result)
```

## Available Tools

### create_escrow_tool
Create a payment escrow that locks USDC funds until work is completed.

### release_escrow_tool
Release payment to the worker after work is completed.

### check_reputation_tool
Check an agent's reputation score and task history.

### register_agent_tool
Register your agent on the PayLobster identity system.

### get_balance_tool
Check USDC balance of any address on Base.

## Example: Payment Crew

See `examples/payment_crew.py` for a complete example with:
- A Payment Manager agent that handles all escrow operations
- A Negotiator agent that discusses terms with workers
- Coordination between agents for complete payment workflows

## Contract Addresses (Base Mainnet)

- **Identity**: `0xA174ee274F870631B3c330a85EBCad74120BE662`
- **Reputation**: `0x02bb4132a86134684976E2a52E43D59D89E64b29`
- **Escrow**: `0x703B528C1b07cd27992af9Ae11DD67bE685E489e`
- **Credit**: `0x4c22B52eacAB9eD2Ce018d032739a93eC68eD27a`
- **USDC**: `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`

## Security

**⚠️ Never hardcode private keys in production!** Use environment variables:

```python
import os
private_key = os.environ.get("AGENT_PRIVATE_KEY")
```

## License

MIT
