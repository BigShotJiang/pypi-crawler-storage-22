"""
Example: CrewAI crew with a dedicated Payment Agent role that handles PayLobster operations.

This crew demonstrates:
- Specialized agent with PayLobster tools
- Multi-agent coordination for payment workflows
- Reputation checking before payment
"""

import os
from crewai import Agent, Task, Crew, Process
from crewai_paylobster import (
    create_escrow_tool,
    release_escrow_tool,
    check_reputation_tool,
    get_balance_tool,
)


def create_payment_crew():
    """Create a crew with payment management capabilities."""

    # Payment Manager - handles all PayLobster operations
    payment_agent = Agent(
        role="Payment Manager",
        goal="Securely manage escrow payments using PayLobster",
        backstory="""You are an expert in cryptocurrency payments and escrow systems.
        You verify worker reputation before creating escrows, ensure proper payment
        amounts, and release funds only when work is verified as complete. You prioritize
        security and transparency in all transactions.""",
        tools=[
            create_escrow_tool,
            release_escrow_tool,
            check_reputation_tool,
            get_balance_tool,
        ],
        verbose=True,
    )

    # Negotiator - discusses terms (but doesn't handle payments)
    negotiator_agent = Agent(
        role="Work Negotiator",
        goal="Negotiate fair terms for AI agent work agreements",
        backstory="""You are skilled at negotiating work agreements between clients
        and workers. You establish clear deliverables, timelines, and payment amounts.
        Once terms are agreed, you hand off to the Payment Manager to handle the
        financial transaction.""",
        verbose=True,
    )

    return payment_agent, negotiator_agent


def run_payment_workflow():
    """Run a complete payment workflow with reputation check and escrow creation."""

    payment_agent, negotiator_agent = create_payment_crew()

    # Worker and client details
    worker_address = "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
    client_key = os.environ.get("CLIENT_PRIVATE_KEY")

    if not client_key:
        print("Error: Set CLIENT_PRIVATE_KEY environment variable")
        return

    # Task 1: Negotiate terms
    negotiation_task = Task(
        description=f"""A client wants to hire a worker at {worker_address} to analyze
        their Q4 sales dataset. Negotiate the following terms:
        - Scope: Data analysis with visualizations and insights report
        - Payment: $150 USDC
        - Deadline: 48 hours
        - Deliverable: PDF report with charts
        
        Once terms are established, pass the details to the Payment Manager.""",
        agent=negotiator_agent,
        expected_output="Negotiated terms summary ready for payment setup",
    )

    # Task 2: Check reputation and create escrow
    payment_task = Task(
        description=f"""The Negotiator has agreed on terms with worker {worker_address}.
        Before creating the escrow:
        1. Check the worker's reputation on PayLobster
        2. Verify they have a success rate above 80%
        3. If reputation is good, create escrow with:
           - Worker: {worker_address}
           - Amount: 150 USDC
           - Deadline: 48 hours
           - Description: "Q4 sales dataset analysis with visualizations"
           - Client private key: {client_key}
        4. Report the escrow ID and transaction details
        
        If reputation is poor, reject and explain why.""",
        agent=payment_agent,
        expected_output="Reputation check results and escrow creation confirmation with escrow ID",
    )

    # Create crew with sequential process
    crew = Crew(
        agents=[negotiator_agent, payment_agent],
        tasks=[negotiation_task, payment_task],
        process=Process.sequential,
        verbose=True,
    )

    print("\n=== Starting Payment Workflow ===\n")
    result = crew.kickoff()
    print("\n=== Workflow Complete ===")
    print(result)

    return result


def run_release_workflow(escrow_id: int):
    """Run workflow to release payment after work completion."""

    payment_agent, _ = create_payment_crew()
    client_key = os.environ.get("CLIENT_PRIVATE_KEY")

    if not client_key:
        print("Error: Set CLIENT_PRIVATE_KEY environment variable")
        return

    release_task = Task(
        description=f"""The worker has completed the data analysis and delivered
        the report. The client has verified the work meets all requirements.
        
        Release the payment from escrow ID {escrow_id} using private key: {client_key}
        
        Confirm the transaction was successful.""",
        agent=payment_agent,
        expected_output="Payment release confirmation with transaction hash",
    )

    crew = Crew(agents=[payment_agent], tasks=[release_task], verbose=True)

    print("\n=== Releasing Payment ===\n")
    result = crew.kickoff()
    print("\n=== Payment Released ===")
    print(result)

    return result


if __name__ == "__main__":
    # Run the full workflow
    result = run_payment_workflow()

    # Later, after work is completed (simulated)
    print("\n\n--- Simulating work completion ---\n")
    print("Worker has delivered the analysis report.")
    print("Client has verified the deliverables.")

    # In practice, extract escrow_id from the result
    # For demo, let's assume escrow_id = 1
    escrow_id = 1
    run_release_workflow(escrow_id)
