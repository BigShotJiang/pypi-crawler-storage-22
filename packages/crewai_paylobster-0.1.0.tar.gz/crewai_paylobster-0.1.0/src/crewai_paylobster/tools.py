"""CrewAI tools for PayLobster escrow operations."""

from crewai_tools import tool
from web3 import Web3

from crewai_paylobster.constants import (
    CONTRACTS,
    BASE_RPC_URL,
    IDENTITY_ABI,
    REPUTATION_ABI,
    ESCROW_ABI,
    ERC20_ABI,
)


@tool("Create PayLobster Escrow")
def create_escrow_tool(
    worker_address: str,
    amount_usdc: float,
    deadline_hours: int,
    description: str,
    private_key: str,
) -> str:
    """
    Create a payment escrow on PayLobster. Locks USDC funds that will be released
    to a worker upon completion of work.

    Args:
        worker_address: Ethereum address of the worker agent
        amount_usdc: Amount in USDC (e.g., 100.50)
        deadline_hours: Hours from now until deadline
        description: Description of the work to be done
        private_key: Private key of the client (caller)

    Returns:
        Success message with escrow ID and transaction hash, or error message
    """
    try:
        w3 = Web3(Web3.HTTPProvider(BASE_RPC_URL))
        account = w3.eth.account.from_key(private_key)

        # Convert USDC amount (6 decimals)
        amount_wei = int(amount_usdc * 1_000_000)

        # Calculate deadline timestamp
        deadline = w3.eth.get_block("latest")["timestamp"] + (deadline_hours * 3600)

        # Approve USDC spending first
        usdc = w3.eth.contract(address=CONTRACTS["USDC"], abi=ERC20_ABI)
        approve_tx = usdc.functions.approve(
            CONTRACTS["ESCROW"], amount_wei
        ).build_transaction(
            {
                "from": account.address,
                "nonce": w3.eth.get_transaction_count(account.address),
            }
        )
        signed_approve = account.sign_transaction(approve_tx)
        approve_hash = w3.eth.send_raw_transaction(signed_approve.raw_transaction)
        w3.eth.wait_for_transaction_receipt(approve_hash)

        # Create escrow
        escrow = w3.eth.contract(address=CONTRACTS["ESCROW"], abi=ESCROW_ABI)
        tx = escrow.functions.createEscrow(
            Web3.to_checksum_address(worker_address),
            amount_wei,
            CONTRACTS["USDC"],
            deadline,
            description,
        ).build_transaction(
            {
                "from": account.address,
                "nonce": w3.eth.get_transaction_count(account.address),
            }
        )

        signed_tx = account.sign_transaction(tx)
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

        # Extract escrow ID from logs
        escrow_id = (
            receipt["logs"][0]["topics"][1].hex() if receipt["logs"] else "unknown"
        )

        return f"Escrow created successfully! Escrow ID: {escrow_id}, Transaction: {tx_hash.hex()}"

    except Exception as e:
        return f"Error creating escrow: {str(e)}"


@tool("Release PayLobster Escrow")
def release_escrow_tool(escrow_id: int, private_key: str) -> str:
    """
    Release payment from a PayLobster escrow to the worker.
    Only the client who created the escrow can release it.

    Args:
        escrow_id: ID of the escrow to release
        private_key: Private key of the client

    Returns:
        Success message with transaction hash, or error message
    """
    try:
        w3 = Web3(Web3.HTTPProvider(BASE_RPC_URL))
        account = w3.eth.account.from_key(private_key)

        escrow = w3.eth.contract(address=CONTRACTS["ESCROW"], abi=ESCROW_ABI)
        tx = escrow.functions.releaseEscrow(escrow_id).build_transaction(
            {
                "from": account.address,
                "nonce": w3.eth.get_transaction_count(account.address),
            }
        )

        signed_tx = account.sign_transaction(tx)
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        w3.eth.wait_for_transaction_receipt(tx_hash)

        return f"Escrow {escrow_id} released successfully! Transaction: {tx_hash.hex()}"

    except Exception as e:
        return f"Error releasing escrow: {str(e)}"


@tool("Check PayLobster Reputation")
def check_reputation_tool(agent_address: str) -> str:
    """
    Check the reputation score and task history of an agent on PayLobster.

    Args:
        agent_address: Ethereum address of the agent

    Returns:
        Reputation information including score, completed tasks, failed tasks, and success rate
    """
    try:
        w3 = Web3(Web3.HTTPProvider(BASE_RPC_URL))
        reputation = w3.eth.contract(address=CONTRACTS["REPUTATION"], abi=REPUTATION_ABI)

        score, completed, failed = reputation.functions.getReputation(
            Web3.to_checksum_address(agent_address)
        ).call()

        total = completed + failed
        success_rate = (completed / total * 100) if total > 0 else 0

        return (
            f"Agent {agent_address[:10]}...{agent_address[-8:]}:\n"
            f"  Reputation Score: {score}\n"
            f"  Completed Tasks: {completed}\n"
            f"  Failed Tasks: {failed}\n"
            f"  Success Rate: {success_rate:.1f}%"
        )

    except Exception as e:
        return f"Error checking reputation: {str(e)}"


@tool("Register PayLobster Agent")
def register_agent_tool(metadata: str, private_key: str) -> str:
    """
    Register an agent on the PayLobster identity system.

    Args:
        metadata: JSON string with agent info (capabilities, contact, etc.)
        private_key: Private key of the agent to register

    Returns:
        Success message with agent address and transaction hash, or error message
    """
    try:
        w3 = Web3(Web3.HTTPProvider(BASE_RPC_URL))
        account = w3.eth.account.from_key(private_key)

        identity = w3.eth.contract(address=CONTRACTS["IDENTITY"], abi=IDENTITY_ABI)

        # Check if already registered
        is_registered = identity.functions.isRegistered(account.address).call()
        if is_registered:
            return f"Agent {account.address} is already registered."

        tx = identity.functions.register(metadata).build_transaction(
            {
                "from": account.address,
                "nonce": w3.eth.get_transaction_count(account.address),
            }
        )

        signed_tx = account.sign_transaction(tx)
        tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
        w3.eth.wait_for_transaction_receipt(tx_hash)

        return f"Agent registered successfully! Address: {account.address}, Transaction: {tx_hash.hex()}"

    except Exception as e:
        return f"Error registering agent: {str(e)}"


@tool("Get USDC Balance")
def get_balance_tool(address: str) -> str:
    """
    Get the USDC balance of an Ethereum address on Base.

    Args:
        address: Ethereum address to check balance for

    Returns:
        USDC balance formatted as currency
    """
    try:
        w3 = Web3(Web3.HTTPProvider(BASE_RPC_URL))
        usdc = w3.eth.contract(address=CONTRACTS["USDC"], abi=ERC20_ABI)

        balance_wei = usdc.functions.balanceOf(
            Web3.to_checksum_address(address)
        ).call()
        balance_usdc = balance_wei / 1_000_000  # USDC has 6 decimals

        return f"USDC Balance for {address[:10]}...{address[-8:]}: ${balance_usdc:,.2f}"

    except Exception as e:
        return f"Error getting balance: {str(e)}"
