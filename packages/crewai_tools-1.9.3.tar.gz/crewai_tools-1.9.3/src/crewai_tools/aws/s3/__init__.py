from crewai_tools.aws.s3.reader_tool import S3ReaderTool as S3ReaderTool
from crewai_tools.aws.s3.writer_tool import S3WriterTool as S3WriterTool
