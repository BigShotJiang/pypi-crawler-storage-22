"""
Integration test for ClaudeChatModel with custom endpoint support.

This test verifies that the refactored ClaudeChatModel works correctly with:
1. Custom Anthropic API endpoints
2. Custom proxy endpoints (e.g., ModelGate)
3. Backward compatibility with Vertex AI

To run:
    pytest tests/test_claude_custom_endpoint_integration.py -v -s
"""

import os
import sys
import pytest
from crewplus.services.claude_chat_model import ClaudeChatModel
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage


# Pytest fixture for API key
@pytest.fixture(scope="module")
def api_key():
    """Get API key from hardcoded value or environment variable."""
    key = os.getenv("MODELGATE_API_KEY", "sk-0f7bfe7e-c9ff-461d-8813-b5d225385e88")
    if not key:
        pytest.skip("MODELGATE_API_KEY not set")
    return key


@pytest.fixture(scope="module")
def base_url_claude():
    """Base URL for Claude proxy endpoint."""
    return "https://mg.aid.pub/claude-proxy"


def test_custom_endpoint_basic_invoke(api_key, base_url_claude):
    """Test basic invoke with custom endpoint."""
    print("\n" + "=" * 80, flush=True)
    print("Test: Custom Endpoint - Basic Invoke", flush=True)
    print("=" * 80, flush=True)

    try:
        # Initialize model with custom endpoint
        model = ClaudeChatModel(
            model_name="claude-opus-4-5",
            use_custom_endpoint=True,
            api_key=api_key,
            base_url=base_url_claude,
            max_tokens=512
        )

        print(f"\n✓ Initialized ClaudeChatModel", flush=True)
        print(f"  LLM Type: {model._llm_type}", flush=True)
        print(f"  Identifying Params: {model._identifying_params}", flush=True)

        # Test invoke
        response = model.invoke("Say 'Hello' in one word.")

        print(f"\n✓ Response received", flush=True)
        print(f"  Content: {response.content}", flush=True)

        # Assertions
        assert response is not None, "Response is None"
        assert response.content is not None, "Response content is None"
        assert len(response.content) > 0, "Response content is empty"
        assert model._llm_type == "claude_custom_endpoint", "Wrong LLM type"

        print("\n✓ Test passed!", flush=True)

    except Exception as e:
        error_msg = f"Error: {e} (Type: {type(e).__name__})"
        print(error_msg, flush=True)
        sys.stderr.write(error_msg + "\n")
        pytest.fail(error_msg)


def test_custom_endpoint_with_messages(api_key, base_url_claude):
    """Test custom endpoint with structured messages."""
    print("\n" + "=" * 80, flush=True)
    print("Test: Custom Endpoint - Structured Messages", flush=True)
    print("=" * 80, flush=True)

    try:
        model = ClaudeChatModel(
            model_name="claude-opus-4-5",
            use_custom_endpoint=True,
            api_key=api_key,
            base_url=base_url_claude,
            max_tokens=512
        )

        # Test with system message and conversation
        messages = [
            SystemMessage(content="You are a helpful assistant that responds in one sentence."),
            HumanMessage(content="What is 2+2?")
        ]

        response = model.invoke(messages)

        print(f"\n✓ Response received", flush=True)
        print(f"  Content: {response.content}", flush=True)

        assert response is not None
        assert "4" in response.content

        print("\n✓ Test passed!", flush=True)

    except Exception as e:
        pytest.fail(f"Error: {e}")


def test_custom_endpoint_streaming(api_key, base_url_claude):
    """Test streaming with custom endpoint."""
    print("\n" + "=" * 80, flush=True)
    print("Test: Custom Endpoint - Streaming", flush=True)
    print("=" * 80, flush=True)

    try:
        model = ClaudeChatModel(
            model_name="claude-opus-4-5",
            use_custom_endpoint=True,
            api_key=api_key,
            base_url=base_url_claude,
            max_tokens=512
        )

        print("\nStreaming response:", flush=True)
        print("-" * 80, flush=True)

        full_response = ""
        chunk_count = 0

        for chunk in model.stream("Say hello in one sentence."):
            if chunk.content:
                full_response += chunk.content
                chunk_count += 1
                print(chunk.content, end='', flush=True)

        print("\n" + "-" * 80, flush=True)
        print(f"\n✓ Streaming completed", flush=True)
        print(f"  Chunks: {chunk_count}", flush=True)
        print(f"  Total length: {len(full_response)}", flush=True)

        assert chunk_count > 0, "No chunks received"
        assert len(full_response) > 0, "Empty response"

        print("\n✓ Test passed!", flush=True)

    except Exception as e:
        pytest.fail(f"Error in streaming: {e}")


def test_custom_endpoint_multi_turn_conversation(api_key, base_url_claude):
    """Test multi-turn conversation with custom endpoint."""
    print("\n" + "=" * 80, flush=True)
    print("Test: Custom Endpoint - Multi-turn Conversation", flush=True)
    print("=" * 80, flush=True)

    try:
        model = ClaudeChatModel(
            model_name="claude-opus-4-5",
            use_custom_endpoint=True,
            api_key=api_key,
            base_url=base_url_claude,
            max_tokens=512
        )

        # Multi-turn conversation
        messages = [
            HumanMessage(content="What is 5+3?"),
            AIMessage(content="5+3 equals 8."),
            HumanMessage(content="Now multiply that by 2.")
        ]

        response = model.invoke(messages)

        print(f"\n✓ Response received", flush=True)
        print(f"  Content: {response.content}", flush=True)

        assert response is not None
        assert "16" in response.content

        print("\n✓ Test passed!", flush=True)

    except Exception as e:
        pytest.fail(f"Error: {e}")


def test_custom_endpoint_different_models(api_key, base_url_claude):
    """Test different Claude models with custom endpoint."""
    print("\n" + "=" * 80, flush=True)
    print("Test: Custom Endpoint - Different Models", flush=True)
    print("=" * 80, flush=True)

    models_to_test = [
        "claude-opus-4-5",
        "claude-opus-4-6",
    ]

    results = {}

    for model_name in models_to_test:
        print(f"\nTesting model: {model_name}", flush=True)

        try:
            model = ClaudeChatModel(
                model_name=model_name,
                use_custom_endpoint=True,
                api_key=api_key,
                base_url=base_url_claude,
                max_tokens=100
            )

            response = model.invoke("Say 'OK' in one word.")

            results[model_name] = {
                "success": True,
                "content": response.content[:50]
            }
            print(f"  ✓ Success - Response: {response.content[:50]}", flush=True)

        except Exception as e:
            results[model_name] = {
                "success": False,
                "error": str(e)[:100]
            }
            print(f"  ✗ Failed - {str(e)[:100]}", flush=True)

    # At least one model should work
    successful = sum(1 for r in results.values() if r.get("success"))
    assert successful > 0, f"No models worked! Results: {results}"

    print(f"\n✓ {successful}/{len(models_to_test)} models passed", flush=True)


def test_identifying_params_custom_endpoint(api_key, base_url_claude):
    """Test that identifying params are correctly set for custom endpoint."""
    print("\n" + "=" * 80, flush=True)
    print("Test: Custom Endpoint - Identifying Params", flush=True)
    print("=" * 80, flush=True)

    model = ClaudeChatModel(
        model_name="claude-opus-4-5",
        use_custom_endpoint=True,
        api_key=api_key,
        base_url=base_url_claude,
        max_tokens=512,
        temperature=0.7
    )

    params = model._identifying_params

    print(f"\nIdentifying params: {params}", flush=True)

    assert params["model_name"] == "claude-opus-4-5"
    assert params["use_custom_endpoint"] is True
    assert params["base_url"] == base_url_claude
    assert params["temperature"] == 0.7
    assert params["max_tokens"] == 512
    assert "project_id" not in params, "project_id should not be in params for custom endpoint"
    assert "location" not in params, "location should not be in params for custom endpoint"

    print("\n✓ Test passed!", flush=True)


# Note: This test would require GCP credentials
@pytest.mark.skip(reason="Requires GCP Vertex AI credentials")
def test_backward_compatibility_vertex_ai():
    """Test that Vertex AI functionality still works (backward compatibility)."""
    print("\n" + "=" * 80, flush=True)
    print("Test: Backward Compatibility - Vertex AI", flush=True)
    print("=" * 80, flush=True)

    try:
        model = ClaudeChatModel(
            model_name="claude-opus-4-5",
            project_id="your-gcp-project-id",
            location="global",
            max_tokens=512
        )

        assert model._llm_type == "claude_vertex_ai"
        assert not model.use_custom_endpoint

        print("\n✓ Vertex AI initialization works", flush=True)

    except Exception as e:
        # Expected to fail without proper GCP setup in test environment
        print(f"\n⚠ Skipped (expected): {e}", flush=True)


# Note: This file is now a pytest test suite.
# Run with: pytest tests/test_claude_custom_endpoint_integration.py -v -s
#
# The -v flag enables verbose output
# The -s flag shows print statements during test execution
