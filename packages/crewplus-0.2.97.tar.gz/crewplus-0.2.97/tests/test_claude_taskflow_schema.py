"""
Tests for Claude Opus model's ability to generate proper TaskflowSchema.

This test suite validates:
1. Claude Opus generating TaskflowSchema WITH bind_tools (tool-calling mode)
2. Claude Opus generating TaskflowSchema WITHOUT bind_tools (JSON output mode)

The tests use TaskflowSchemaParser from crewplus_engine to parse LLM outputs.
Langfuse tracing is enabled for integration tests to track performance and usage.
"""

import os
import sys
import json
from pathlib import Path
import pytest
from typing import Optional
from pydantic import BaseModel, Field
from langchain_core.tools import BaseTool
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
from langchain_core.outputs import ChatGeneration
from langchain_core.prompts import ChatPromptTemplate

# Add project roots to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
CREWPLUS_ENGINE_ROOT = PROJECT_ROOT.parent / "crewplus-engine" / "src"
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(CREWPLUS_ENGINE_ROOT))

from crewplus.services import init_load_balancer, get_model_balancer
from crewplus_engine.parsers.taskflow_schema_parser import TaskflowSchemaParser
from crewplus_engine.task_schema import TaskflowSchema, TaskSchema


# =============================================================================
# Test Tools Definition
# =============================================================================

class FindPartNumberInput(BaseModel):
    """Input schema for find_part_number tool."""
    product_name: str = Field(description="The product name to search for")
    include_alternatives: bool = Field(default=False, description="Whether to include alternative part numbers")


class FindPartNumberTool(BaseTool):
    """A tool to find part numbers for products."""

    name: str = "find_part_number"
    description: str = (
        "Finds the part number for a given product name. "
        "Use this tool when you need to look up part numbers in the database."
    )
    args_schema: type[BaseModel] = FindPartNumberInput

    def _run(self, product_name: str, include_alternatives: bool = False) -> str:
        """Execute the part number lookup."""
        return f"Found part number P-12345 for product '{product_name}'"

    async def _arun(self, product_name: str, include_alternatives: bool = False) -> str:
        """Async version of _run."""
        return self._run(product_name, include_alternatives)


class CheckMaintenanceRecordsInput(BaseModel):
    """Input schema for check_maintenance_records tool."""
    part_number: str = Field(description="The part number to check records for")
    date_range: Optional[str] = Field(default=None, description="Date range for records (e.g., 'last_30_days')")


class CheckMaintenanceRecordsTool(BaseTool):
    """A tool to check maintenance records for a part."""

    name: str = "check_maintenance_records"
    description: str = (
        "Checks maintenance records for a given part number. "
        "Returns maintenance history and recommendations."
    )
    args_schema: type[BaseModel] = CheckMaintenanceRecordsInput

    def _run(self, part_number: str, date_range: Optional[str] = None) -> str:
        """Execute the maintenance records check."""
        return f"Found 5 maintenance records for part number '{part_number}'"

    async def _arun(self, part_number: str, date_range: Optional[str] = None) -> str:
        """Async version of _run."""
        return self._run(part_number, date_range)


class VectorSearchInput(BaseModel):
    """Input schema for vector_search tool."""
    query: str = Field(description="The search query")
    top_k: int = Field(default=5, description="Number of results to return")


class VectorSearchTool(BaseTool):
    """A tool to perform vector search in document collections."""

    name: str = "vector_search"
    description: str = (
        "Performs semantic vector search across document collections. "
        "Use this to find relevant documents, manuals, or knowledge base articles."
    )
    args_schema: type[BaseModel] = VectorSearchInput

    def _run(self, query: str, top_k: int = 5) -> str:
        """Execute the vector search."""
        return f"Found {top_k} relevant documents for query: '{query}'"

    async def _arun(self, query: str, top_k: int = 5) -> str:
        """Async version of _run."""
        return self._run(query, top_k)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture(scope="module")
def langfuse_config():
    """Configure Langfuse environment variables for tracing."""
    os.environ["LANGFUSE_PUBLIC_KEY"] = os.getenv(
        "LANGFUSE_PUBLIC_KEY",
        "pk-lf-874857f5-6bad-4141-96eb-cf36f70009e6"
    )
    os.environ["LANGFUSE_SECRET_KEY"] = os.getenv(
        "LANGFUSE_SECRET_KEY",
        "sk-lf-3fe02b88-be46-4394-8da0-9ec409660de1"
    )
    os.environ["LANGFUSE_HOST"] = os.getenv(
        "LANGFUSE_HOST",
        "https://langfuse-test.crewplus.ai"
    )

    yield {
        "public_key": os.environ["LANGFUSE_PUBLIC_KEY"],
        "secret_key": os.environ["LANGFUSE_SECRET_KEY"],
        "host": os.environ["LANGFUSE_HOST"]
    }


@pytest.fixture(scope="module")
def model_balancer(langfuse_config):
    """Initialize and return the model load balancer."""
    config_path = PROJECT_ROOT / "_config" / "models_config.json"
    if not config_path.exists():
        pytest.skip(f"Config file not found: {config_path}")

    init_load_balancer(str(config_path))
    return get_model_balancer()


@pytest.fixture(params=[
    "claude-opus-4-5@global",
])
def claude_model(request, model_balancer):
    """Create a ClaudeChatModel instance from model balancer for testing."""
    deployment_name = request.param

    try:
        model = model_balancer.get_model(deployment_name=deployment_name)

        # Enable tracing for integration tests
        if hasattr(model, 'enable_tracing'):
            if hasattr(request, 'node') and request.node.get_closest_marker('integration'):
                model.enable_tracing = True
            else:
                model.enable_tracing = False

        return model
    except Exception as e:
        pytest.skip(f"Could not get model '{deployment_name}': {e}")


@pytest.fixture
def find_part_tool():
    """Create a find_part_number tool instance."""
    return FindPartNumberTool()


@pytest.fixture
def maintenance_tool():
    """Create a check_maintenance_records tool instance."""
    return CheckMaintenanceRecordsTool()


@pytest.fixture
def vector_search_tool():
    """Create a vector_search tool instance."""
    return VectorSearchTool()


@pytest.fixture
def all_tools(find_part_tool, maintenance_tool, vector_search_tool):
    """Create a list of all tools."""
    return [find_part_tool, maintenance_tool, vector_search_tool]


@pytest.fixture
def taskflow_parser():
    """Create a TaskflowSchemaParser instance."""
    import logging
    logger = logging.getLogger(__name__)
    return TaskflowSchemaParser(logger=logger)


# =============================================================================
# System Prompt for JSON Mode (without tools)
# =============================================================================

ANALYZE_PROMPT_WITHOUT_TOOLS = """You are a workflow compiler. Your task is to analyze user requests and compile them into a structured TaskflowSchema.

Output your response as a valid JSON object with the following structure:
{format_instructions}

Available tools/actions you can use in your tasks:
{tool_schemas}

Rules:
1. Each task must have a unique 'key' field
2. The 'action' field should be 'tool_call' for tool-based actions or 'vector_search' for search actions
3. The 'target' field should be the tool name or search target
4. Use 'params' to pass arguments to the tool
5. You can reference previous task outputs using placeholders like '{{{{task_key.output.field_name}}}}'

Respond ONLY with the JSON object, no additional text.
"""


# =============================================================================
# Test TaskflowSchema Generation WITH bind_tools
# =============================================================================

@pytest.mark.integration
class TestTaskflowSchemaWithBindTools:
    """Tests for TaskflowSchema generation using bind_tools (tool-calling mode)."""

    def test_single_tool_taskflow(self, claude_model, find_part_tool, taskflow_parser):
        """Test generating a TaskflowSchema with a single tool call."""
        model_with_tools = claude_model.bind_tools([find_part_tool])

        query = "Find the part number for product 'Industrial Motor X-500'"
        response = model_with_tools.invoke(query)

        print(f"\n--- Single Tool TaskflowSchema Test ---")
        print(f"Query: {query}")
        print(f"Response type: {type(response)}")
        print(f"Response content: {response.content}")

        # Check response structure
        assert response is not None
        assert isinstance(response, AIMessage)

        # If tool was called, parse into TaskflowSchema
        if hasattr(response, 'tool_calls') and response.tool_calls:
            print(f"Tool calls: {response.tool_calls}")

            # Parse using TaskflowSchemaParser
            from langchain_core.outputs import ChatGeneration
            generation = ChatGeneration(message=response)
            taskflow_schema = taskflow_parser.parse_result([generation])

            print(f"Parsed TaskflowSchema: {taskflow_schema}")

            # Validate the TaskflowSchema
            assert isinstance(taskflow_schema, TaskflowSchema)
            assert taskflow_schema.name == "actions"
            assert len(taskflow_schema.tasks) >= 1

            # Validate task structure
            task = taskflow_schema.tasks[0]
            assert task.action == "tool_call"
            assert task.target == "find_part_number"
            assert "product_name" in task.params

            print("Test passed - Single tool TaskflowSchema generated correctly")
        else:
            print("Warning: Model did not use tool, provided direct answer")
            print(f"Content: {response.content}")

    def test_multiple_tools_taskflow(self, claude_model, all_tools, taskflow_parser):
        """Test generating a TaskflowSchema with multiple sequential tool calls."""
        model_with_tools = claude_model.bind_tools(all_tools)

        query = "First find the part number for 'Pump Assembly Model Y', then check its maintenance records"
        response = model_with_tools.invoke(query)

        print(f"\n--- Multiple Tools TaskflowSchema Test ---")
        print(f"Query: {query}")
        print(f"Response type: {type(response)}")
        print(f"Response content: {response.content}")

        assert response is not None
        assert isinstance(response, AIMessage)

        if hasattr(response, 'tool_calls') and response.tool_calls:
            print(f"Tool calls: {len(response.tool_calls)}")
            for i, tc in enumerate(response.tool_calls):
                print(f"  Tool {i+1}: {tc['name']} - args: {tc['args']}")

            # Parse using TaskflowSchemaParser
            from langchain_core.outputs import ChatGeneration
            generation = ChatGeneration(message=response)
            taskflow_schema = taskflow_parser.parse_result([generation])

            print(f"Parsed TaskflowSchema: {taskflow_schema}")

            # Validate the TaskflowSchema
            assert isinstance(taskflow_schema, TaskflowSchema)
            assert len(taskflow_schema.tasks) >= 1

            # Check that tool names are as expected
            tool_names = [task.target for task in taskflow_schema.tasks]
            print(f"Tool names in flow: {tool_names}")

            print("Test passed - Multiple tools TaskflowSchema generated correctly")
        else:
            print("Warning: Model did not use tools, provided direct answer")

    def test_vector_search_taskflow(self, claude_model, vector_search_tool, taskflow_parser):
        """Test generating a TaskflowSchema with vector search tool."""
        model_with_tools = claude_model.bind_tools([vector_search_tool])

        query = "Search for documents about safety procedures for electrical equipment"
        response = model_with_tools.invoke(query)

        print(f"\n--- Vector Search TaskflowSchema Test ---")
        print(f"Query: {query}")

        assert response is not None

        if hasattr(response, 'tool_calls') and response.tool_calls:
            print(f"Tool calls: {response.tool_calls}")

            from langchain_core.outputs import ChatGeneration
            generation = ChatGeneration(message=response)
            taskflow_schema = taskflow_parser.parse_result([generation])

            assert isinstance(taskflow_schema, TaskflowSchema)
            assert any(task.target == "vector_search" for task in taskflow_schema.tasks)

            print("Test passed - Vector search TaskflowSchema generated correctly")
        else:
            print("Warning: Model did not use vector_search tool")

    def test_tool_choice_forced(self, claude_model, find_part_tool, taskflow_parser):
        """Test forcing tool usage with tool_choice parameter."""
        model_with_tools = claude_model.bind_tools(
            [find_part_tool],
            tool_choice={"type": "tool", "name": "find_part_number"}
        )

        query = "What about product ABC-123?"
        response = model_with_tools.invoke(query)

        print(f"\n--- Forced Tool Choice Test ---")
        print(f"Query: {query}")

        assert response is not None
        assert hasattr(response, 'tool_calls') and response.tool_calls, "Tool should be called when forced"

        print(f"Tool calls: {response.tool_calls}")

        from langchain_core.outputs import ChatGeneration
        generation = ChatGeneration(message=response)
        taskflow_schema = taskflow_parser.parse_result([generation])

        assert isinstance(taskflow_schema, TaskflowSchema)
        assert taskflow_schema.tasks[0].target == "find_part_number"

        print("Test passed - Forced tool choice works correctly")


# =============================================================================
# Test TaskflowSchema Generation WITHOUT bind_tools (JSON Mode)
# =============================================================================

@pytest.mark.integration
class TestTaskflowSchemaWithoutBindTools:
    """Tests for TaskflowSchema generation without bind_tools (JSON output mode)."""

    def _build_tool_schemas(self, tools):
        """Build tool schema descriptions for the prompt."""
        schemas = []
        for tool in tools:
            schema = {
                "name": tool.name,
                "description": tool.description or "",
            }
            if tool.args_schema:
                schema["parameters"] = tool.args_schema.model_json_schema()
            schemas.append(schema)
        return json.dumps(schemas, indent=2)

    def test_json_mode_single_task(self, claude_model, all_tools, taskflow_parser):
        """Test generating TaskflowSchema in JSON mode with a single task."""
        tool_schemas = self._build_tool_schemas(all_tools)
        format_instructions = taskflow_parser.get_format_instructions()

        prompt = ChatPromptTemplate.from_messages([
            ("system", ANALYZE_PROMPT_WITHOUT_TOOLS),
            ("human", "{message}")
        ])

        prompt = prompt.partial(
            format_instructions=format_instructions,
            tool_schemas=tool_schemas
        )

        chain = prompt | claude_model | taskflow_parser

        query = "Find the part number for product 'Valve Controller Z-100'"
        print(f"\n--- JSON Mode Single Task Test ---")
        print(f"Query: {query}")

        try:
            taskflow_schema = chain.invoke({"message": query})

            print(f"Parsed TaskflowSchema: {taskflow_schema}")

            assert isinstance(taskflow_schema, TaskflowSchema)
            assert taskflow_schema.name is not None
            assert len(taskflow_schema.tasks) >= 1

            # Check that the task uses the correct tool
            task = taskflow_schema.tasks[0]
            assert task.key is not None
            assert task.action is not None

            print("Test passed - JSON mode single task works correctly")

        except Exception as e:
            print(f"Error during parsing: {e}")
            raise

    def test_json_mode_multi_step_flow(self, claude_model, all_tools, taskflow_parser):
        """Test generating a multi-step TaskflowSchema in JSON mode."""
        tool_schemas = self._build_tool_schemas(all_tools)
        format_instructions = taskflow_parser.get_format_instructions()

        prompt = ChatPromptTemplate.from_messages([
            ("system", ANALYZE_PROMPT_WITHOUT_TOOLS),
            ("human", "{message}")
        ])

        prompt = prompt.partial(
            format_instructions=format_instructions,
            tool_schemas=tool_schemas
        )

        chain = prompt | claude_model | taskflow_parser

        query = """Create a workflow that:
1. First finds the part number for 'Industrial Pump P-200'
2. Then checks the maintenance records for that part
3. Finally searches for relevant documentation"""

        print(f"\n--- JSON Mode Multi-Step Flow Test ---")
        print(f"Query: {query}")

        try:
            taskflow_schema = chain.invoke({"message": query})

            print(f"Parsed TaskflowSchema:")
            print(f"  Name: {taskflow_schema.name}")
            print(f"  Description: {taskflow_schema.description}")
            print(f"  Number of tasks: {len(taskflow_schema.tasks)}")

            for i, task in enumerate(taskflow_schema.tasks):
                print(f"  Task {i+1}:")
                print(f"    Key: {task.key}")
                print(f"    Action: {task.action}")
                print(f"    Target: {task.target}")
                print(f"    Params: {task.params}")

            assert isinstance(taskflow_schema, TaskflowSchema)
            assert len(taskflow_schema.tasks) >= 2, "Should have multiple tasks"

            print("Test passed - JSON mode multi-step flow works correctly")

        except Exception as e:
            print(f"Error during parsing: {e}")
            raise

    def test_json_mode_with_placeholders(self, claude_model, all_tools, taskflow_parser):
        """Test that JSON mode correctly handles output placeholders between tasks."""
        tool_schemas = self._build_tool_schemas(all_tools)
        format_instructions = taskflow_parser.get_format_instructions()

        prompt = ChatPromptTemplate.from_messages([
            ("system", ANALYZE_PROMPT_WITHOUT_TOOLS),
            ("human", "{message}")
        ])

        prompt = prompt.partial(
            format_instructions=format_instructions,
            tool_schemas=tool_schemas
        )

        chain = prompt | claude_model | taskflow_parser

        query = """Find the part number for 'Motor Assembly M-300', then use that part number to check maintenance records."""

        print(f"\n--- JSON Mode Placeholders Test ---")
        print(f"Query: {query}")

        try:
            taskflow_schema = chain.invoke({"message": query})

            print(f"Parsed TaskflowSchema: {taskflow_schema.model_dump_json(indent=2)}")

            assert isinstance(taskflow_schema, TaskflowSchema)

            # Check if there are placeholders in params
            has_placeholder = False
            for task in taskflow_schema.tasks:
                if task.params:
                    params_str = str(task.params)
                    if "{{" in params_str or "}}" in params_str:
                        has_placeholder = True
                        print(f"Found placeholder in task '{task.key}': {task.params}")

            print(f"Has placeholders: {has_placeholder}")
            print("Test passed - JSON mode with placeholders works correctly")

        except Exception as e:
            print(f"Error during parsing: {e}")
            raise


# =============================================================================
# Test Parser Edge Cases
# =============================================================================

@pytest.mark.integration
class TestParserEdgeCases:
    """Tests for parser edge cases and error handling."""

    def test_parser_handles_empty_content(self, taskflow_parser):
        """Test that parser handles empty or malformed content gracefully."""
        # Test with empty string - should return fallback
        result = taskflow_parser.parse("")
        assert isinstance(result, TaskflowSchema)
        assert result.name == "fallback-search-flow"

    def test_parser_handles_tool_calls_directly(self, taskflow_parser):
        """Test that parser can handle AIMessage with tool_calls directly."""
        # Create a mock AIMessage with tool_calls
        mock_message = AIMessage(
            content="",
            tool_calls=[
                {
                    "name": "find_part_number",
                    "args": {"product_name": "Test Product"},
                    "id": "call_123"
                },
                {
                    "name": "check_maintenance_records",
                    "args": {"part_number": "P-999"},
                    "id": "call_456"
                }
            ]
        )

        generation = ChatGeneration(message=mock_message)

        result = taskflow_parser.parse_result([generation])

        print(f"\n--- Parser Tool Calls Test ---")
        print(f"Parsed result: {result}")

        assert isinstance(result, TaskflowSchema)
        assert result.name == "actions"
        assert len(result.tasks) == 2
        assert result.tasks[0].target == "find_part_number"
        assert result.tasks[1].target == "check_maintenance_records"

        print("Test passed - Parser handles tool_calls correctly")

    def test_parser_handles_json_with_missing_fields(self, taskflow_parser):
        """Test that parser handles JSON with missing optional fields."""
        # JSON with only tasks, no name
        json_str = '''
        {
            "tasks": [
                {
                    "action": "tool_call",
                    "target": "find_part_number",
                    "params": {"product_name": "Test"}
                }
            ]
        }
        '''

        result = taskflow_parser.parse(json_str)

        print(f"\n--- Parser Missing Fields Test ---")
        print(f"Parsed result: {result}")

        assert isinstance(result, TaskflowSchema)
        assert result.name is not None  # Should have auto-generated name
        assert len(result.tasks) == 1
        assert result.tasks[0].key is not None  # Should have auto-generated key

        print("Test passed - Parser handles missing fields correctly")


# =============================================================================
# Test Complete Tool Execution Loop
# =============================================================================

@pytest.mark.integration
class TestCompleteToolLoop:
    """Tests for complete tool execution loops with TaskflowSchema."""

    def test_complete_tool_execution(self, claude_model, find_part_tool, taskflow_parser):
        """Test a complete tool execution loop: request -> tool call -> execution -> final answer."""
        model_with_tools = claude_model.bind_tools([find_part_tool])

        # Step 1: Initial query
        query = "Find the part number for 'Conveyor Belt CB-500'"
        print(f"\n--- Complete Tool Execution Loop Test ---")
        print(f"Step 1: Query = {query}")

        response = model_with_tools.invoke(query)
        print(f"  Response content: {response.content}")

        if hasattr(response, 'tool_calls') and response.tool_calls:
            print(f"  Tool calls: {response.tool_calls}")

            # Parse to TaskflowSchema
            from langchain_core.outputs import ChatGeneration
            generation = ChatGeneration(message=response)
            taskflow_schema = taskflow_parser.parse_result([generation])

            print(f"  TaskflowSchema: {taskflow_schema}")

            # Step 2: Execute tools and build message history
            messages = [
                HumanMessage(content=query),
                response
            ]

            for tool_call in response.tool_calls:
                tool_name = tool_call["name"]
                tool_args = tool_call["args"]
                tool_id = tool_call["id"]

                print(f"\nStep 2: Executing tool '{tool_name}'")
                print(f"  Arguments: {tool_args}")

                # Execute the tool
                if tool_name == "find_part_number":
                    tool_result = find_part_tool._run(**tool_args)
                    print(f"  Result: {tool_result}")

                    messages.append(
                        ToolMessage(
                            content=tool_result,
                            tool_call_id=tool_id
                        )
                    )

            # Step 3: Get final response
            print("\nStep 3: Getting final response...")
            final_response = model_with_tools.invoke(messages)

            print(f"  Final Answer: {final_response.content}")

            assert final_response is not None
            assert final_response.content is not None
            # The final answer should mention the part number
            assert "P-12345" in final_response.content or "part" in final_response.content.lower()

            print("\nTest passed - Complete tool execution loop works correctly")

        else:
            print("Warning: Model did not use tool, provided direct answer")
            print(f"Content: {response.content}")


# =============================================================================
# Run Tests
# =============================================================================

if __name__ == "__main__":
    # Run with: python test_claude_taskflow_schema.py
    # Or: pytest test_claude_taskflow_schema.py -v
    pytest.main([__file__, "-v", "--tb=short", "-m", "integration"])
