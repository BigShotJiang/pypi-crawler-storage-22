"""
Test script to verify Claude Opus 4.5 works with custom endpoint.

This script tests:
1. Listing available models from the custom endpoint
2. Sending a message to claude-opus-4-5 using the custom endpoint
3. Testing with different model aliases (claude-opus-4-5, claude-sonnet-4-5, etc.)
4. Testing streaming responses

Verified working configuration (from Postman):
    URL: https://mg.aid.pub/claude-proxy/v1/messages
    Model: "claude-opus-4-5"
    Stream: true/false
    Headers:
        - Content-Type: application/json
        - Authorization: Bearer <api-key>

To run:
    pytest tests/test_custom_claude_endpoint.py -v -s

    Options:
        -v : Verbose output
        -s : Show print statements (recommended to see Claude models list)
        -k : Run specific test, e.g., -k "streaming" or -k "chinese"
"""

import os
import sys
import json
from anthropic import Anthropic
import requests
import pytest


# Pytest fixture for API key
@pytest.fixture(scope="module")
def api_key():
    """Get API key from hardcoded value or environment variable."""
    # Hardcoded API key (can be overridden by environment variable)
    key = os.getenv("MODELGATE_API_KEY", "sk-0f7bfe7e-c9ff-461d-8813-b5d225385e88")
    if not key:
        pytest.skip("MODELGATE_API_KEY not set")
    return key


@pytest.fixture(scope="module")
def base_url_models():
    """Base URL for model listing endpoint."""
    return "https://mg.aid.pub"


@pytest.fixture(scope="module")
def base_url_claude():
    """Base URL for Claude proxy endpoint."""
    return "https://mg.aid.pub/claude-proxy"


def test_list_models(api_key, base_url_models):
    """
    List available models from the custom endpoint.

    Args:
        api_key: Your ModelGate API key
        base_url_models: The base URL for the API (from fixture)
    """
    print("\n" + "=" * 80, flush=True)
    print("Testing: List Available Models", flush=True)
    print("=" * 80, flush=True)

    try:
        response = requests.get(
            f'{base_url_models}/v1/models',
            headers={
                'Authorization': f'Bearer {api_key}'
            },
            timeout=30
        )

        response.raise_for_status()
        models = response.json()

        print(f"\n✓ Successfully retrieved models from {base_url_models}/v1/models", flush=True)
        print(f"\nTotal models available: {len(models.get('data', []))}\n", flush=True)

        # Collect and print Claude models specifically
        claude_models = []
        print("Claude Models:", flush=True)
        print("-" * 80, flush=True)
        for model in models.get('data', []):
            model_id = model.get('id', 'N/A')
            owner = model.get('owned_by', 'N/A')
            if 'claude' in model_id.lower() or 'opus' in model_id.lower() or 'sonnet' in model_id.lower():
                output_line = f"  • Model ID: {model_id:<30} Owner: {owner}"
                print(output_line, flush=True)
                # Also write to stderr to ensure visibility
                sys.stderr.write(output_line + "\n")
                claude_models.append(model_id)

        print(f"\nTotal Claude models found: {len(claude_models)}", flush=True)
        print("=" * 80 + "\n", flush=True)

        # Also log to stderr for visibility
        sys.stderr.write(f"\n✓ Found {len(claude_models)} Claude models\n")
        sys.stderr.flush()

        assert models is not None, "Models response is None"
        assert 'data' in models, "No 'data' key in models response"
        assert len(models['data']) > 0, "No models returned"

    except requests.exceptions.RequestException as e:
        error_msg = f"Error listing models: {e}"
        print(error_msg, flush=True)
        sys.stderr.write(error_msg + "\n")
        pytest.fail(error_msg)


def test_claude_message_chinese(api_key, base_url_claude):
    """
    Test sending a Chinese message to Claude using the custom endpoint.

    Args:
        api_key: Your ModelGate API key (from fixture)
        base_url_claude: The base URL for the Claude proxy (from fixture)
    """
    model = "claude-opus-4-5"
    message = "你好,请介绍一下你自己"

    print("\n" + "=" * 80, flush=True)
    print(f"Testing: Claude Message (Chinese) - Model: {model}", flush=True)
    print("=" * 80, flush=True)

    try:
        # Initialize Anthropic client with custom endpoint
        client = Anthropic(
            api_key=api_key,
            base_url=base_url_claude
        )

        print(f"\n✓ Initialized Anthropic client", flush=True)
        print(f"  Base URL: {base_url_claude}", flush=True)
        print(f"  Model: {model}", flush=True)
        print(f"  Message: {message}\n", flush=True)

        # Send message
        response = client.messages.create(
            model=model,
            max_tokens=1024,
            messages=[
                {"role": "user", "content": message}
            ]
        )

        print("✓ Response received successfully!\n", flush=True)
        print("Response Details:", flush=True)
        print("-" * 80, flush=True)
        print(f"  Model: {response.model}", flush=True)
        print(f"  Stop Reason: {response.stop_reason}", flush=True)
        print(f"  Usage:", flush=True)
        print(f"    - Input tokens: {response.usage.input_tokens}", flush=True)
        print(f"    - Output tokens: {response.usage.output_tokens}", flush=True)
        print("\nContent:", flush=True)
        print("-" * 80, flush=True)

        # Extract and print text content
        for block in response.content:
            if hasattr(block, 'text'):
                print(block.text, flush=True)

        # Assertions
        assert response is not None, "Response is None"
        assert response.content is not None, "Response content is None"
        assert len(response.content) > 0, "Response content is empty"
        assert response.usage.output_tokens > 0, "No output tokens generated"

    except Exception as e:
        error_msg = f"Error sending message: {e} (Type: {type(e).__name__})"
        print(error_msg, flush=True)
        sys.stderr.write(error_msg + "\n")
        pytest.fail(error_msg)


def test_claude_message_english(api_key, base_url_claude):
    """
    Test sending an English message to Claude using the custom endpoint.

    Args:
        api_key: Your ModelGate API key (from fixture)
        base_url_claude: The base URL for the Claude proxy (from fixture)
    """
    model = "claude-opus-4-5"
    message = "Hello, please introduce yourself briefly."

    print("\n" + "=" * 80, flush=True)
    print(f"Testing: Claude Message (English) - Model: {model}", flush=True)
    print("=" * 80, flush=True)

    try:
        # Initialize Anthropic client with custom endpoint
        client = Anthropic(
            api_key=api_key,
            base_url=base_url_claude
        )

        print(f"\n✓ Initialized Anthropic client", flush=True)
        print(f"  Base URL: {base_url_claude}", flush=True)
        print(f"  Model: {model}", flush=True)
        print(f"  Message: {message}\n", flush=True)

        # Send message
        response = client.messages.create(
            model=model,
            max_tokens=1024,
            messages=[
                {"role": "user", "content": message}
            ]
        )

        print("✓ Response received successfully!\n", flush=True)
        print("Response Details:", flush=True)
        print("-" * 80, flush=True)
        print(f"  Model: {response.model}", flush=True)
        print(f"  Stop Reason: {response.stop_reason}", flush=True)
        print(f"  Usage:", flush=True)
        print(f"    - Input tokens: {response.usage.input_tokens}", flush=True)
        print(f"    - Output tokens: {response.usage.output_tokens}", flush=True)
        print("\nContent:", flush=True)
        print("-" * 80, flush=True)

        # Extract and print text content
        for block in response.content:
            if hasattr(block, 'text'):
                print(block.text, flush=True)

        # Assertions
        assert response is not None, "Response is None"
        assert response.content is not None, "Response content is None"
        assert len(response.content) > 0, "Response content is empty"
        assert response.usage.output_tokens > 0, "No output tokens generated"

    except Exception as e:
        error_msg = f"Error sending message: {e} (Type: {type(e).__name__})"
        print(error_msg, flush=True)
        sys.stderr.write(error_msg + "\n")
        pytest.fail(error_msg)


def test_multiple_models(api_key, base_url_claude):
    """
    Test multiple model name variations.

    Args:
        api_key: Your ModelGate API key (from fixture)
        base_url_claude: The base URL for the Claude proxy (from fixture)
    """
    print("\n" + "=" * 80, flush=True)
    print("Testing Multiple Model Name Variations", flush=True)
    print("=" * 80, flush=True)

    # Different model name formats to try (based on working Postman config)
    model_names = [
        "claude-opus-4-5",
        "claude-opus-4-6"
    ]

    results = {}
    successful_tests = 0

    for model_name in model_names:
        print(f"\n\nTesting model: {model_name}", flush=True)
        print("-" * 80, flush=True)

        try:
            client = Anthropic(
                api_key=api_key,
                base_url=base_url_claude
            )

            response = client.messages.create(
                model=model_name,
                max_tokens=100,
                messages=[
                    {"role": "user", "content": "Say 'Hello' in one word."}
                ]
            )

            content = response.content[0].text if response.content else ""
            results[model_name] = {
                "success": True,
                "model_returned": response.model,
                "content": content[:50],  # First 50 chars
                "tokens": f"{response.usage.input_tokens}+{response.usage.output_tokens}"
            }
            successful_tests += 1
            success_msg = f"  ✓ Success - Actual model: {response.model}"
            print(success_msg, flush=True)
            sys.stderr.write(success_msg + "\n")

        except Exception as e:
            results[model_name] = {
                "success": False,
                "error": str(e)[:100]  # First 100 chars of error
            }
            error_msg = f"  ✗ Failed - {str(e)[:100]}"
            print(error_msg, flush=True)
            sys.stderr.write(error_msg + "\n")

    # Summary
    print("\n\n" + "=" * 80, flush=True)
    print("Summary of Model Tests", flush=True)
    print("=" * 80, flush=True)

    for model_name, result in results.items():
        status = "✓ PASS" if result.get("success") else "✗ FAIL"
        print(f"\n{status} - {model_name}", flush=True)
        if result.get("success"):
            print(f"       Actual model: {result.get('model_returned')}", flush=True)
            print(f"       Tokens: {result.get('tokens')}", flush=True)
        else:
            print(f"       Error: {result.get('error')}", flush=True)

    # Summary to stderr for visibility
    summary_msg = f"\n✓ {successful_tests}/{len(model_names)} models passed"
    print(summary_msg, flush=True)
    sys.stderr.write(summary_msg + "\n")
    sys.stderr.flush()

    # At least one model should work
    assert successful_tests > 0, f"No models worked! Results: {results}"


def test_claude_streaming(api_key, base_url_claude):
    """
    Test streaming response from Claude (matching Postman config with stream=true).

    Args:
        api_key: Your ModelGate API key (from fixture)
        base_url_claude: The base URL for the Claude proxy (from fixture)
    """
    model = "claude-opus-4-5"
    message = "Hello, please introduce yourself briefly."

    print("\n" + "=" * 80, flush=True)
    print(f"Testing: Claude Streaming - Model: {model}", flush=True)
    print("=" * 80, flush=True)

    try:
        # Initialize Anthropic client with custom endpoint
        client = Anthropic(
            api_key=api_key,
            base_url=base_url_claude
        )

        print(f"\n✓ Initialized Anthropic client", flush=True)
        print(f"  Base URL: {base_url_claude}", flush=True)
        print(f"  Model: {model}", flush=True)
        print(f"  Message: {message}", flush=True)
        print(f"  Stream: True\n", flush=True)

        print("Streaming response:", flush=True)
        print("-" * 80, flush=True)

        # Send streaming message
        full_response = ""
        chunk_count = 0

        with client.messages.stream(
            model=model,
            max_tokens=1024,
            messages=[
                {"role": "user", "content": message}
            ]
        ) as stream:
            for text in stream.text_stream:
                full_response += text
                chunk_count += 1
                print(text, end='', flush=True)

        print("\n" + "-" * 80, flush=True)
        print(f"\n✓ Streaming completed!", flush=True)
        print(f"  Total chunks received: {chunk_count}", flush=True)
        print(f"  Total characters: {len(full_response)}", flush=True)

        # Assertions
        assert chunk_count > 0, "No chunks received from stream"
        assert len(full_response) > 0, "Empty response from stream"

        sys.stderr.write(f"\n✓ Streaming test passed ({chunk_count} chunks, {len(full_response)} chars)\n")
        sys.stderr.flush()

    except Exception as e:
        error_msg = f"Error in streaming: {e} (Type: {type(e).__name__})"
        print(error_msg, flush=True)
        sys.stderr.write(error_msg + "\n")
        pytest.fail(error_msg)


# Note: This file is now a pytest test suite.
# Run with: pytest tests/test_custom_claude_endpoint.py -v -s
#
# The -v flag enables verbose output
# The -s flag shows print statements during test execution
