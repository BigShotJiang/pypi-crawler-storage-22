#!/bin/bash
rm -rf .claude/skills/
cp -r .github/skills/ .claude/skills/