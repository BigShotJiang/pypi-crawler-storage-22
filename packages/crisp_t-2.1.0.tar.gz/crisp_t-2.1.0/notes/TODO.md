# TODOs

## Time analysis

- [ ] Add timestamps to documents read from PDF files when adding to corpus
- [ ] Check how timestamp field can be added to documents in a corpus.
- [ ] When one is selected other should be selected automatically based on temporal proximity.

## Embedding linkage

- [ ] How to filter documents and dataframe rows based on embedding similarity scores?
- [ ] When one is selected other should be selected automatically based on similarity scores.