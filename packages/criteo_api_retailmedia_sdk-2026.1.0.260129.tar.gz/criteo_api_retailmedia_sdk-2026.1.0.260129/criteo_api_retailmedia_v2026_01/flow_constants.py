"""This file defines authentication flows constants."""

CLIENT_CREDENTIALS_FLOW = 'client_credentials'
AUTHORIZATION_CODE_FLOW = 'authorization_code'
REFRESH_TOKEN_FLOW = 'refresh_token'
