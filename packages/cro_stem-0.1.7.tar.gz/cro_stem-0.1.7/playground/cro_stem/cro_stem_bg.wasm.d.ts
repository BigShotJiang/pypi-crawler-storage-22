/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const normalize_wasm: (a: number, b: number) => [number, number];
export const stem_wasm: (a: number, b: number, c: number, d: number) => [number, number];
export const stem_debug_wasm: (a: number, b: number, c: number, d: number) => [number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __externref_drop_slice: (a: number, b: number) => void;
export const __wbindgen_start: () => void;
