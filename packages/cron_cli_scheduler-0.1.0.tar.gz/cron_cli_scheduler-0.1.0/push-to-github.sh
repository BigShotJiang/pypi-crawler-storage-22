#!/bin/bash
# Push script for cron-cli-scheduler to GitHub

echo "=== Pushing cron-cli-scheduler to GitHub ==="
echo ""

# Check if in the right directory
if [ ! -d ".git" ]; then
    echo "Error: Not a git repository. Please run this script from the cron-cli-scheduler directory."
    exit 1
fi

# Check GitHub authentication
echo "Checking GitHub authentication..."
if ! git ls-remote https://github.com/bonashen/cron-cli-scheduler.git &>/dev/null; then
    echo ""
    echo "⚠️  GitHub authentication required!"
    echo ""
    echo "Please choose one of the following methods:"
    echo ""
    echo "Method 1: Use GitHub CLI (recommended)"
    echo "  1. Install GitHub CLI: https://cli.github.com/"
    echo "  2. Run: gh auth login"
    echo "  3. Run: gh repo create cron-cli-scheduler --public --source=. --remote=origin --push"
    echo ""
    echo "Method 2: Use SSH (if you have SSH keys set up)"
    echo "  git remote set-url origin git@github.com:bonashen/cron-cli-scheduler.git"
    echo "  git push -u origin main"
    echo ""
    echo "Method 3: Use Personal Access Token"
    echo "  1. Create a token at: https://github.com/settings/tokens"
    echo "  2. Use: git push -u origin main"
    echo "  3. Enter your username and token as password"
    echo ""
    exit 1
fi

# Push to GitHub
echo "Pushing to GitHub..."
git push -u origin main

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Successfully pushed to GitHub!"
    echo ""
    echo "Repository URL: https://github.com/bonashen/cron-cli-scheduler"
    echo ""
else
    echo ""
    echo "❌ Push failed. Please check your authentication and try again."
    echo ""
fi
