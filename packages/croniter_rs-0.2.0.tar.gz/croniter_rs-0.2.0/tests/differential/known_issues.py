#!/usr/bin/env python3
"""
Known issues tracker for differential testing.
Documents expected failures and unimplemented features.
"""

KNOWN_ISSUES = {
    "python_prev_leap_feb29": {
        "description": "Python croniter bug: get_prev skips Feb 29 in leap years depending on start date",
        "expressions": [],
        "status": "python_bug",
        "priority": "info",
        "notes": "Python get_prev('0 0 29 * *', 2024-03-16) returns Jan 29, skipping Feb 29. "
                 "Rust correctly returns Feb 29. Bug is start-date dependent: from Mar 1 Python "
                 "finds Feb 29, from Mar 16 it doesn't. Affects day=29, day=29-31 ranges. "
                 "Accounts for ~1.6% of fuzz failures. Our implementation is correct."
    },
    "random_expressions": {
        "description": "Random (R) operator not implemented in Rust",
        "expressions": ["R R * * *", "R R R * *"],
        "status": "not_implemented",
        "priority": "low",
        "notes": "Random value generation within field range"
    }
}


def filter_known_issues(failures):
    """Filter out known issues from failure list."""
    unknown_failures = []
    known_failures = []

    for failure in failures:
        expr = failure['expr']
        is_known = False

        for issue_name, issue_data in KNOWN_ISSUES.items():
            if expr in issue_data['expressions']:
                known_failures.append({
                    'failure': failure,
                    'issue': issue_name,
                    'status': issue_data['status']
                })
                is_known = True
                break

            # Check for pattern matches
            if issue_name == "python_prev_leap_feb29" and failure.get('prev_result', {}).get('passed') == False:
                # Check if differences involve Feb 29 in a leap year
                diffs = failure.get('prev_result', {}).get('differences', [])
                if any('02-29' in d for d in diffs):
                    known_failures.append({
                        'failure': failure,
                        'issue': issue_name,
                        'status': issue_data['status']
                    })
                    is_known = True
                    break

        if not is_known:
            unknown_failures.append(failure)

    return unknown_failures, known_failures


def print_known_issues():
    """Print all known issues."""
    print("Known Issues in croniter-rs")
    print("="*80)
    print()

    for issue_name, issue_data in KNOWN_ISSUES.items():
        print(f"{issue_name}:")
        print(f"  Status: {issue_data['status']}")
        print(f"  Priority: {issue_data['priority']}")
        print(f"  Description: {issue_data['description']}")
        print(f"  Examples: {', '.join(issue_data['expressions'][:3])}")
        print(f"  Notes: {issue_data['notes']}")
        print()


if __name__ == '__main__':
    print_known_issues()
