#!/bin/bash
# Quick test runner script

set -e

cd /home/ubuntu-exp/cronproject/croniter-rs
source /home/ubuntu-exp/cronproject/.venv/bin/activate

echo "Croniter-rs Differential Testing Quick Runner"
echo "=============================================="
echo ""

case "${1:-smoke}" in
    smoke)
        echo "Running smoke tests (quick validation)..."
        python tests/differential/run_tests.py smoke
        ;;

    comprehensive)
        echo "Running comprehensive tests (full validation)..."
        python tests/differential/run_tests.py comprehensive
        ;;

    fuzz)
        COUNT=${2:-100}
        echo "Running quick fuzzing with $COUNT test cases..."
        python tests/differential/run_tests.py quick-fuzz --count $COUNT
        ;;

    coverage)
        echo "Running code coverage analysis..."
        ./tests/differential/run_coverage.sh
        ;;

    parallel-fuzz)
        HOURS=${2:-1}
        echo "Running parallel fuzzing for $HOURS hour(s)..."
        echo "WARNING: This will use multiple CPU cores"
        python tests/differential/parallel_fuzzer.py --duration $HOURS
        ;;

    *)
        echo "Usage: $0 {smoke|comprehensive|fuzz [count]|coverage|parallel-fuzz [hours]}"
        echo ""
        echo "Examples:"
        echo "  $0 smoke              # Quick smoke tests"
        echo "  $0 comprehensive      # Full test suite"
        echo "  $0 fuzz 500           # Fuzz with 500 random cases"
        echo "  $0 coverage           # Generate coverage report"
        echo "  $0 parallel-fuzz 24   # 24-hour parallel fuzzing"
        exit 1
        ;;
esac
