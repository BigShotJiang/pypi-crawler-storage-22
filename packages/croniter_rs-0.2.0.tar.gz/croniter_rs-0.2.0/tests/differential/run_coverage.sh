#!/bin/bash
# Coverage test runner using cargo-tarpaulin

set -e

cd /home/ubuntu-exp/cronproject/croniter-rs

echo "Running code coverage analysis with cargo-tarpaulin..."
echo "This will compile and run all tests with coverage instrumentation"
echo ""

# Run tarpaulin with HTML output
cargo tarpaulin \
    --out Html \
    --output-dir tests/differential/coverage \
    --exclude-files "target/*" \
    --timeout 300 \
    --verbose

echo ""
echo "Coverage report generated at: tests/differential/coverage/index.html"
echo ""

# Also generate JSON for programmatic access
cargo tarpaulin \
    --out Json \
    --output-dir tests/differential/coverage \
    --exclude-files "target/*" \
    --timeout 300 \
    --quiet

echo "JSON coverage data: tests/differential/coverage/tarpaulin-report.json"
