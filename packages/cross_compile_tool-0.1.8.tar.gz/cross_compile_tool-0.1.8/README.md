# cross-compile-tool

A blazing fast, generic cross-compilation utility for C++ and ROS 2. It uses Docker to generate an ARM64 sysroot and standard native tools (GCC/Ninja) for compilation.

## Prerequisites
- **Docker**: For building the sysroot & dev environments.
- **Cross Compiler**: `sudo apt install g++-aarch64-linux-gnu qemu-user-static` (Required for Host builds and Docker ARM64 emulation).

## Installation
```bash
# Recommended: Install in a virtual environment
pip install .
```

## Usage

The tool uses subcommands: `init`, `status`, `prep`, `build`, `clean`, `build-dev`, and `run-dev`.

### 1. Initialize (New Project)
Create a template `apt_packages.txt` for your dependencies.
```bash
cct init
```

### 2. Status check
Check the current environment and sysroot staleness.
```bash
cct status
```
### 3. Build (The Daily Driver)
Compiles your code. It automatically prepares the sysroot if it's missing.

```bash
# Basic usage (compiles current directory)
# Results go into build_arm64/ and install_arm64/
cct build

# Clean build
cct build --clean

# ROS 2 Specific: Build only selected packages
cct build --packages-select my_pkg1 my_pkg2
```

**Common Options:**
- `--packages-select`: Build specific packages only (colcon only).
- `--packages-up-to`: Build specified packages and their dependencies (colcon only).
- `--packages-ignore`: Skip specific packages during the build.
- `--clean`: Wipe build directory before compiling.
- `--build-tool [colcon|cmake]`: Force a specific tool (default: `auto`).

### 4. Docker-based Development
For a reproducible environment without installing cross-compilers on your host:

1. **Prepare Sysroot**: Run `cct prep` (e.g., `cct prep --base-image ros:humble-ros-base`) on your **Host** system.
2. **Build Dev Image**: Run `cct build-dev` to create the cross-compilation container.
3. **Enter Environment**: Run `cct run-dev` to start and enter the container.
4. **Compile**: Run `cct build` inside the container to compile your project.

*Note: Your project directory and sysroot are automatically mounted into the container.*

---

## 🛠 Advanced Features
- **Status Check**: `cct status` to verify environment and sysroot staleness.
- **Selective Build**: `cct build --packages-select pkg1` (colcon only).
- **Environment Variables**: Use `CCT_BASE_IMAGE` or `CCT_SYSROOT` to skip flags.
- **CI/CD**: Run `cct prep` on the runner host, then mount `sysroot_arm64` into your build.
- **Multi-Package Projects**: Put multiple packages in `src/` (for colcon) or use a root `CMakeLists.txt` with `add_subdirectory()` (for cmake).

## 🧹 Cleanup
```bash
cct clean          # Remove build/install artifacts
cct clean --all    # Also wipe the sysroot
```
