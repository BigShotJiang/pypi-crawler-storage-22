#!/usr/bin/env python3
import argparse
import os
import subprocess
import sys
import shutil
import hashlib
import tempfile
import logging
from importlib import metadata
from pathlib import Path

# Configuration
SCRIPT_DIR = Path(__file__).parent.absolute()
# When installed as a package, we need to handle where we run from
WORKSPACE_DIR = Path.cwd()
DEFAULT_SYSROOT_DIR = WORKSPACE_DIR / "sysroot_arm64"
DEFAULT_BUILD_DIR = WORKSPACE_DIR / "build_arm64"
DEFAULT_PACKAGES_FILE = WORKSPACE_DIR / "apt_packages.txt"

# Standard paths to sync into the sysroot
SYSROOT_PATHS = [
    "/lib",
    "/usr/include",
    "/usr/lib",
    "/usr/share",
    "/opt",
    "/etc",
    "/sysroot_manifest.txt",
]


# ANSI Colors
C_GREY = "\x1b[38;20m"
C_BLUE = "\x1b[34;20m"
C_YELLOW = "\x1b[33;20m"
C_RED = "\x1b[31;20m"
C_GREEN = "\x1b[32;20m"
C_BOLD = "\x1b[1m"
C_BOLD_RED = "\x1b[31;1m"
C_END = "\x1b[0m"


# --- Logging Setup ---
class ColoredFormatter(logging.Formatter):
    """Custom formatter to add colors to log levels."""

    # Format: [LEVEL] message
    FORMAT = "%(levelname)s: %(message)s"

    FORMATS = {
        logging.DEBUG: C_GREY + FORMAT + C_END,
        logging.INFO: C_BLUE + FORMAT + C_END,
        logging.WARNING: C_YELLOW + FORMAT + C_END,
        logging.ERROR: C_RED + FORMAT + C_END,
        logging.CRITICAL: C_BOLD_RED + FORMAT + C_END,
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


logger = logging.getLogger("cct")
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setFormatter(ColoredFormatter())
logger.addHandler(ch)


def set_verbose(enabled):
    if enabled:
        logger.setLevel(logging.DEBUG)
        logger.debug("Verbose logging enabled.")


def run_command(cmd, cwd=None, env=None):
    """Runs a shell command and streams output."""
    logger.info(f"Running: {' '.join(cmd)}")
    try:
        subprocess.check_call(cmd, cwd=cwd, env=env)
    except subprocess.CalledProcessError as e:
        logger.error(f"Command failed with exit code {e.returncode}")
        sys.exit(e.returncode)


def get_default_base_image():
    """Detects ROS distro on host to suggest a better default base image."""
    base_image = os.getenv("CCT_BASE_IMAGE")
    if base_image:
        return base_image
    ros_distro = os.getenv("ROS_DISTRO")
    if ros_distro:
        return f"ros:{ros_distro}-ros-base"
    return "ubuntu:22.04"


def get_file_hash(file_path):
    """Calculates MD5 hash of a file."""
    if not Path(file_path).exists():
        return None
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def build_sysroot(output_dir, packages_file, base_image=None, rebuild=False):
    """Builds and exports the sysroot using Docker."""
    if base_image is None:
        base_image = get_default_base_image()
    in_container = Path("/.dockerenv").exists()
    if in_container:
        logger.error("Sysroot generation is not supported inside the container.")
        logger.info("Please run 'cct prep' on your host system.")
        sys.exit(1)

    logger.info(f"Preparing Sysroot for arm64 from {base_image}...")

    # Ensure output directory exists
    output_dir = Path(output_dir).absolute()
    if output_dir.exists() and not rebuild:
        if (output_dir / "usr").exists():
            logger.info(f"Using existing sysroot at {output_dir}")
            return

    output_dir.mkdir(parents=True, exist_ok=True)

    # Prepare Package List
    src_deps = Path(packages_file).absolute()
    if not src_deps.exists():
        logger.warning(
            f"Packages file {src_deps} not found. Sysroot will only have base image contents."
        )
        packages_content = ""
    else:
        packages_content = src_deps.read_text()

    # 1. Build the Image
    # We use a hash of the packages file + base image to tag it uniquely if we wanted,
    # but for simplicity let's stick to a fixed tag per project context if possible,
    # or just "latest".
    image_tag = "cross-compile-sysroot:latest"

    # Use a temporary directory for build context to avoid writing to source tree
    with tempfile.TemporaryDirectory() as tmp_ctx:
        ctx_dir = Path(tmp_ctx)

        # Copy Dockerfile
        shutil.copy(SCRIPT_DIR / "Dockerfile", ctx_dir / "Dockerfile")

        # Create dependencies structure
        deps_dir = ctx_dir / "dependencies"
        deps_dir.mkdir()
        (deps_dir / "apt_packages_generated.txt").write_text(packages_content)

        cmd_build = [
            "docker",
            "build",
            "-t",
            image_tag,
            "--file",
            str(ctx_dir / "Dockerfile"),
            "--build-arg",
            f"BASE_IMAGE={base_image}",
            "--platform",
            "linux/arm64",
            str(ctx_dir),
        ]

        # Enable BuildKit
        env = os.environ.copy()
        env["DOCKER_BUILDKIT"] = "1"

        logger.info("Building Docker Image...")
        run_command(cmd_build, env=env)

    # 2. Sync Files
    logger.info(f"Syncing Sysroot to {output_dir}...")

    uid = os.getuid()
    gid = os.getgid()

    cmd_sync = (
        [
            "docker",
            "run",
            "--rm",
            "--platform",
            "linux/arm64",
            "-v",
            f"{output_dir}:/target",
            image_tag,
            "rsync",
            "-aR",
            "--info=progress2",
            "--delete",
            f"--chown={uid}:{gid}",
        ]
        + SYSROOT_PATHS
        + ["/target/"]
    )

    run_command(cmd_sync)
    logger.info("Sysroot sync complete.")

    fix_symlinks(output_dir)

    # 3. Store Hash
    if src_deps.exists():
        current_hash = get_file_hash(src_deps)
        with open(output_dir / "sysroot.hash", "w") as f:
            f.write(current_hash)


def fix_symlinks(sysroot_dir):
    """Converts absolute symlinks in the sysroot to relative ones."""
    logger.info("Fixing absolute symlinks in sysroot...")
    sysroot = Path(sysroot_dir)
    count = 0
    # Walk carefully
    for link in sysroot.rglob("*"):
        if link.is_symlink():
            try:
                target = os.readlink(link)
                if target.startswith("/"):
                    # relative logic
                    rel_target_from_root = Path(target.lstrip("/"))
                    link_dir = link.parent
                    relative_root = os.path.relpath(sysroot, link_dir)
                    new_target = Path(relative_root) / rel_target_from_root
                    link.unlink()
                    link.symlink_to(new_target)
                    count += 1
            except OSError:
                pass
    logger.info(f"Fixed {count} absolute symlinks.")


def find_python_paths(sysroot_path):
    """Automatically detects Python paths in the sysroot."""
    sysroot = Path(sysroot_path)
    # Generic generic search
    include_candidates = list(sysroot.glob("usr/include/python3*"))
    if not include_candidates:
        # Might not be installed, which is valid for generic C++
        logger.warning("No Python headers found in sysroot. Python support disabled.")
        return None, None, None

    py_include = sorted(include_candidates)[-1]
    py_version = py_include.name

    # Library
    lib_candidates = list(sysroot.glob(f"usr/lib/aarch64-linux-gnu/lib{py_version}.so"))
    if not lib_candidates:
        lib_candidates = list(sysroot.glob(f"usr/lib/lib{py_version}.so"))

    if not lib_candidates:
        logger.warning(f"Headers found but lib{py_version}.so not found.")
        return None, None, None

    py_library = lib_candidates[0]

    version_match = py_version.replace("python", "")
    version_nodot = version_match.replace(".", "")
    return py_library, version_match, version_nodot


def ensure_system_python_symlink(sysroot_lib):
    """Creates symlink to trick CMake into finding sysroot python as system python."""
    if not sysroot_lib:
        return
    try:
        parts = sysroot_lib.parts
        if "usr" in parts and "lib" in parts:
            idx = parts.index("lib")
            suffix = Path(*parts[idx + 1 :])
            system_path = Path("/usr/lib") / suffix

            if not system_path.exists():
                logger.info(f"Creating system symlink: {system_path}")
                try:
                    system_path.parent.mkdir(parents=True, exist_ok=True)
                    system_path.symlink_to(sysroot_lib)
                except PermissionError:
                    logger.warning(
                        f"Failed to create symlink {system_path}. Sudo required? ignoring."
                    )
    except Exception:
        pass


def check_environment(needs_docker=True):
    """Verifies that the necessary tools are installed."""
    in_container = Path("/.dockerenv").exists()
    status = (
        f"{C_BLUE}Docker Container{C_END}"
        if in_container
        else f"{C_GREEN}Host System{C_END}"
    )
    logger.info(f"Running on: {status}")

    # 1. Check for Cross Compiler (Crucial for the build step)
    if not needs_docker and not shutil.which("aarch64-linux-gnu-g++"):
        logger.error("Cross-compiler 'aarch64-linux-gnu-g++' not found.")
        logger.info(
            "Please install it: sudo apt install mold g++-aarch64-linux-gnu gcc-aarch64-linux-gnu qemu-user-static"
        )
        sys.exit(1)
    # 2. Check for Docker (Needed for sysroot generation)
    if needs_docker and not shutil.which("docker"):
        logger.error("'docker' command not found.")
        logger.info("Docker is required to build the sysroot.")
        sys.exit(1)


def handle_prep(args):
    """Handle the prep subcommand."""
    sysroot_path = Path(args.sysroot).absolute()

    # We always check environment if explicitly building sysroot
    check_environment(needs_docker=True)

    build_sysroot(
        sysroot_path, args.packages_file, args.base_image, rebuild=args.rebuild
    )


def check_sysroot_staleness(sysroot_dir, packages_file):
    """Checks if the packages file has changed since last sysroot build."""
    packages_path = Path(packages_file)
    sysroot_path = Path(sysroot_dir)
    hash_file = sysroot_path / "sysroot.hash"

    if not packages_path.exists():
        return False

    if not sysroot_path.exists() or not (sysroot_path / "usr").exists():
        return True

    current_hash = get_file_hash(packages_path)

    if not hash_file.exists():
        # Fallback to timestamp if no hash (migration path)
        try:
            if packages_path.stat().st_mtime > sysroot_path.stat().st_mtime:
                logger.warning(f"{packages_file} is newer than sysroot (timestamp).")
                return True
        except OSError:
            pass
        return False

    stored_hash = hash_file.read_text().strip()
    if current_hash != stored_hash:
        logger.warning(f"{packages_file} content has changed (hash mismatch).")
        logger.info(
            f"          Runtime: {stored_hash[:8]}... vs Current: {current_hash[:8]}..."
        )
        logger.info("          Run 'cct prep --rebuild' to update.")
        return True

    return False


def handle_build(args):
    """Handle the build subcommand."""
    sysroot_path = Path(args.sysroot).absolute()

    # 1. Lazy Sysroot Check
    logger.info("--- Step 1/2: Environment Preflight & Sysroot Check ---")
    if not (sysroot_path / "usr").exists():
        logger.info(f"Sysroot not found at {sysroot_path}. Preparing it now...")
        check_environment(needs_docker=True)
        build_sysroot(sysroot_path, args.packages_file, args.base_image, rebuild=False)
    else:
        check_sysroot_staleness(sysroot_path, args.packages_file)

    # Always check for the compiler if we are building
    check_environment(needs_docker=False)

    # 2. Python Setup (Dynamic)
    py_lib, py_ver, py_nodot = find_python_paths(sysroot_path)
    ensure_system_python_symlink(py_lib)

    # 3. Build Logic
    logger.info("--- Step 2/2: Starting Compilation ---")
    has_colcon = shutil.which("colcon") is not None
    tool = args.build_tool

    if tool == "auto":
        tool = "colcon" if has_colcon else "cmake"
        logger.info(f"Auto-detected build tool: {tool}")

    toolchain_file = SCRIPT_DIR / "toolchain.cmake"

    # Paths to ignore to prevent colcon from crawling into the sysroot or builds
    paths_ignore = [
        str(sysroot_path),
        str(args.build_dir),
        "install_arm64",
        "install",
        "build",
    ]

    env_vars = os.environ.copy()
    env_vars["TARGET_SYSROOT"] = str(sysroot_path)
    env_vars["LOCAL_INSTALL"] = str(Path(args.build_dir).parent / "install_arm64")
    if py_ver:
        env_vars["PYTHON_VERSION"] = py_ver
        env_vars["PYTHON_VERSION_NODOT"] = py_nodot

    # CLEAN
    if args.clean:
        if Path(args.build_dir).exists():
            shutil.rmtree(args.build_dir)
        # also clean install for colcon
        install_dir = Path(args.build_dir).parent / "install_arm64"
        if install_dir.exists():
            shutil.rmtree(install_dir)

    logger.info(f"Building with {tool}...")

    # Ensure directories we want to ignore have a COLCON_IGNORE file
    for p in paths_ignore:
        ignore_dir = WORKSPACE_DIR / p
        if ignore_dir.exists() and ignore_dir.is_dir():
            (ignore_dir / "COLCON_IGNORE").touch(exist_ok=True)

    if tool == "colcon":
        # Check if we have ros source in sysroot to determine cmake prefix path
        ros_prefixes = list(sysroot_path.glob("opt/ros/*"))
        cmake_prefix = f"{sysroot_path}/usr"
        if ros_prefixes:
            for p in ros_prefixes:
                cmake_prefix = f"{p};{cmake_prefix}"

        colcon_cmd = ["colcon", "build"]

        # Focus on 'src' if it exists, otherwise scan current dir
        if (WORKSPACE_DIR / "src").exists():
            colcon_cmd.extend(["--base-paths", "src"])

        colcon_cmd.extend(
            [
                "--build-base",
                str(args.build_dir),
                "--install-base",
                str(Path(args.build_dir).parent / "install_arm64"),
                "--merge-install",
                "--cmake-args",
                "-G",
                "Ninja",
                f"-DCMAKE_TOOLCHAIN_FILE={toolchain_file}",
                "-DCMAKE_BUILD_TYPE=Release",
                f"-DCMAKE_PREFIX_PATH={cmake_prefix}",
                "--event-handlers",
                "console_direct+",
            ]
        )
        if args.packages_select:
            colcon_cmd.extend(["--packages-select"] + args.packages_select)
        if args.packages_up_to:
            colcon_cmd.extend(["--packages-up-to"] + args.packages_up_to)
        if args.packages_ignore:
            colcon_cmd.extend(["--packages-ignore"] + args.packages_ignore)

        run_command(colcon_cmd, env=env_vars)

    elif tool == "cmake":
        if args.packages_select or args.packages_up_to or args.packages_ignore:
            logger.warning(
                "Package selection flags only work with colcon. Ignoring for cmake."
            )
        build_path = Path(args.build_dir)
        build_path.mkdir(parents=True, exist_ok=True)

        install_dir = Path(args.build_dir).parent / "install_arm64"
        cmake_config = [
            "cmake",
            "-S",
            str(WORKSPACE_DIR),
            "-B",
            str(build_path),
            "-G",
            "Ninja",
            f"-DCMAKE_TOOLCHAIN_FILE={toolchain_file}",
            "-DCMAKE_BUILD_TYPE=Release",
            f"-DCMAKE_INSTALL_PREFIX={install_dir}",
            f"-DCMAKE_PREFIX_PATH={sysroot_path}/usr",
        ]
        run_command(cmake_config, env=env_vars)
        run_command(["cmake", "--build", str(build_path)], env=env_vars)
        run_command(["cmake", "--install", str(build_path)], env=env_vars)


def handle_build_docker_dev(args):
    """Build the CI/Dev Docker image using the packaged Dockerfile."""
    check_environment(needs_docker=True)
    src_dockerfile = SCRIPT_DIR / "dev.Dockerfile"
    if not src_dockerfile.exists():
        logger.error("Could not find source dev.Dockerfile in package.")
        sys.exit(1)

    tag = args.tag
    base_image = args.base_image or get_default_base_image()
    logger.info(
        f"Building Dev Container '{tag}' from '{base_image}' using internal Dockerfile..."
    )

    # We can build directly referring to the file in site-packages
    cmd = [
        "docker",
        "build",
        "-t",
        tag,
        "-f",
        str(src_dockerfile),
        "--build-arg",
        f"BASE_IMAGE={base_image}",
        ".",
    ]
    run_command(cmd)

    logger.info(f"Successfully built '{tag}'.")
    logger.info("You can now enter the development environment with:")
    logger.info(f"  cct run-dev --tag {tag}")


def handle_init(args):
    """Creates a template apt_packages.txt file."""
    p = Path(args.packages_file)
    if p.exists():
        logger.info(f"'{p}' already exists. Skipping initialization.")
        return

    # Basic template for ROS 2 users
    template = (
        "# --- cct Dependencies File ---\n"
        "# List any apt packages you need in your sysroot here.\n"
        "# One package per line.\n"
        "\n"
        "# Example packages:\n"
        "# libfmt-dev\n"
        "# python3-numpy\n"
        "# ros-humble-ros-base\n"
    )

    p.write_text(template)
    logger.info(f"Successfully created template at {p}")

    # .gitignore check
    git_ignore = Path(".gitignore")
    patterns = ["sysroot_arm64/", "build_arm64/", "install_arm64/", "*.hash"]
    if git_ignore.exists():
        content = git_ignore.read_text()
        missing = [p for p in patterns if p not in content]
        if missing:
            logger.info("Tip: Consider adding these to your .gitignore:")
            for m in missing:
                logger.info(f"  {m}")
    else:
        logger.info(
            "Tip: You don't have a .gitignore yet. Remember to exclude your build and sysroot folders from git."
        )

    logger.info("Edit apt_packages.txt to add your dependencies, then run 'cct prep'.")


def handle_status(args):
    """Reports the current tool status and environment."""
    in_container = Path("/.dockerenv").exists()
    status_str = (
        f"{C_BLUE}Docker Container{C_END}"
        if in_container
        else f"{C_GREEN}Host System{C_END}"
    )

    # Sysroot info
    sysroot_path = Path(args.sysroot).absolute()

    logger.info("--- cct Tool Status ---")
    logger.info(f"Environment:   {status_str}")
    logger.info(f"Workspace:     {WORKSPACE_DIR}")

    # Status indicator
    if (sysroot_path / "usr").exists():
        is_stale = check_sysroot_staleness(sysroot_path, args.packages_file)
        status_label = (
            f"{C_YELLOW}STALE{C_END} (Update required)"
            if is_stale
            else f"{C_GREEN}READY{C_END}"
        )
    else:
        status_label = f"{C_RED}MISSING{C_END} (Run 'cct prep')"

    logger.info(f"Sysroot:       {sysroot_path} [{status_label}]")
    logger.info(f"Base Image:    {get_default_base_image()}")
    logger.info("-----------------------")


def handle_clean(args):
    """Wipes the build and install directories."""
    build_dir = Path(args.build_dir)
    install_dir = build_dir.parent / "install_arm64"

    if build_dir.exists():
        logger.info(f"Removing build directory: {build_dir}")
        shutil.rmtree(build_dir)

    if install_dir.exists():
        logger.info(f"Removing install directory: {install_dir}")
        shutil.rmtree(install_dir)

    if args.all:
        sysroot_dir = Path(args.sysroot)
        if sysroot_dir.exists():
            logger.info(f"Removing sysroot directory: {sysroot_dir}")
            shutil.rmtree(sysroot_dir)

    logger.info("Cleanup complete.")


def handle_run_dev(args):
    """Runs the Dev Container with correct mounts and environment."""
    if not shutil.which("docker"):
        logger.error("'docker' command not found.")
        sys.exit(1)

    tag, cwd = args.tag, Path.cwd().absolute()
    if Path("/.dockerenv").exists():
        logger.error("You are already inside a Docker container.")
        sys.exit(1)

    logger.info(f"Entering '{tag}'...")

    # Base command: Map current workspace to /ws
    cmd = ["docker", "run", "-it", "--rm", "-v", f"{cwd}:/ws"]

    def to_container_path(host_path):
        """Translates a host absolute path to a container path if inside workspace."""
        abs_host = Path(host_path).absolute()
        try:
            rel = abs_host.relative_to(cwd)
            return str(Path("/ws") / rel)
        except ValueError:
            return str(abs_host)

    sysroot_host = Path(args.sysroot).absolute()

    # Auto-mount sysroot if outside workspace
    if not str(sysroot_host).startswith(str(cwd)):
        logger.info(f"External sysroot detected, mounting: {sysroot_host}")
        cmd.extend(["-v", f"{sysroot_host}:{sysroot_host}"])

    # Forward CCT_* env vars with path translation
    for k, v in os.environ.items():
        if k.startswith("CCT_"):
            # If it looks like a path and is inside workspace, translate it
            if k in ["CCT_SYSROOT", "CCT_PACKAGES_FILE"] and os.path.isabs(v):
                v = to_container_path(v)
            cmd.extend(["-e", f"{k}={v}"])

    # Explicitly pass the resolved sysroot if not already in env
    if "CCT_SYSROOT" not in os.environ:
        cmd.extend(["-e", f"CCT_SYSROOT={to_container_path(sysroot_host)}"])

    cmd.append(tag)
    os.execvp("docker", cmd)


def main():
    parser = argparse.ArgumentParser(
        description=f"""{C_BOLD}Generic Fast Cross-Compile Tool (cct){C_END}
A high-performance ARM64 cross-compilation wrapper.
It syncs a target filesystem (sysroot) from Docker to your host, allowing
native-speed compilation with perfect dependency matching.""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
{C_BOLD}Workflow for New Projects:{C_END}
  1. {C_GREEN}cct init{C_END}             Create 'apt_packages.txt' for your dependencies.
  2. {C_GREEN}cct prep{C_END}             Build & sync the sysroot (requires Docker on Host).
  3. {C_GREEN}cct build{C_END}            Compile your code using the local sysroot.
  4. {C_GREEN}cct status{C_END}           Check environment and sysroot staleness.

{C_BOLD}Key Concepts:{C_END}
  - {C_BLUE}Sysroot:{C_END} A local copy of /lib, /usr/include, etc. from the target image.
  - {C_BLUE}Packages File:{C_END} List of apt packages to include in the sysroot.
  - {C_BLUE}Toolchain:{C_END} CMake settings that point the compiler to the sysroot.

{C_BOLD}Environment Variables:{C_END}
  CCT_SYSROOT        Path to sysroot (default: ./sysroot_arm64)
  CCT_BASE_IMAGE     Docker image for sysroot (default: detected from host)
  CCT_PACKAGES_FILE  Path to package list (default: ./apt_packages.txt)

{C_BOLD}Troubleshooting:{C_END}
  - Missing headers? Add package to 'apt_packages.txt' and run 'cct prep --rebuild'.
  - Linker errors? Ensure 'cct prep' finished successfully.
  - Runtime errors? Check if your base image matches the target robot's OS.

{C_YELLOW}Pro-tip:{C_END} 'cct' is a fast alias for 'cross-compile-tool'!
        """,
    )

    # Global options
    parser.add_argument(
        "--sysroot",
        default=os.getenv("CCT_SYSROOT", str(DEFAULT_SYSROOT_DIR)),
        help="Path to sysroot (override with CCT_SYSROOT env var)",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable verbose debug output"
    )
    parser.add_argument(
        "--version", action="store_true", help="Show tool version and exit"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Subcommand: init
    parser_init = subparsers.add_parser(
        "init", help="Initialize project with a template apt_packages.txt"
    )
    parser_init.add_argument(
        "--packages-file",
        default=str(DEFAULT_PACKAGES_FILE),
        help="Target packages file name",
    )
    parser_init.set_defaults(func=handle_init)

    # Subcommand: prep
    parser_prep = subparsers.add_parser(
        "prep",
        aliases=["sysroot"],
        help="Build & sync sysroot from Docker (Run on HOST only)",
    )
    parser_prep.add_argument(
        "--rebuild", action="store_true", help="Force rebuild/resync of sysroot"
    )
    parser_prep.add_argument(
        "--base-image",
        default=None,
        help=f"Docker base image (override with CCT_BASE_IMAGE env var, default: {get_default_base_image()})",
    )
    parser_prep.add_argument(
        "--packages-file",
        default=os.getenv("CCT_PACKAGES_FILE", str(DEFAULT_PACKAGES_FILE)),
        help="Apt packages list file (override with CCT_PACKAGES_FILE env var)",
    )
    parser_prep.set_defaults(func=handle_prep)

    # Subcommand: build
    parser_build = subparsers.add_parser(
        "build", help="Cross-compile the project (Native speed, Host or Container)"
    )
    parser_build.add_argument(
        "--build-dir", default=str(DEFAULT_BUILD_DIR), help="Build directory"
    )
    parser_build.add_argument(
        "--clean", action="store_true", help="Clean build directory"
    )
    parser_build.add_argument(
        "--build-tool",
        choices=["auto", "colcon", "cmake"],
        default="auto",
        help="Build tool to use",
    )
    parser_build.add_argument(
        "--packages-file",
        default=os.getenv("CCT_PACKAGES_FILE", str(DEFAULT_PACKAGES_FILE)),
        help="Apt packages list file (for staleness check only)",
    )
    # Allows build command to also accept base-image in case it needs to auto-build sysroot
    parser_build.add_argument(
        "--base-image",
        default=None,
        help=f"Docker base image (override with CCT_BASE_IMAGE env var, default: {get_default_base_image()})",
    )
    parser_build.add_argument(
        "--packages-select",
        nargs="+",
        help="List of specific packages to build (colcon only)",
    )
    parser_build.add_argument(
        "--packages-up-to",
        nargs="+",
        help="Build up to these packages, including dependencies (colcon only)",
    )
    parser_build.add_argument(
        "--packages-ignore",
        nargs="+",
        help="List of packages to ignore (colcon only)",
    )
    parser_build.set_defaults(func=handle_build)

    # Subcommand: build-dev
    parser_dev = subparsers.add_parser(
        "build-dev", help="Build the CI/Dev Docker image"
    )
    parser_dev.add_argument(
        "--tag", default="cross-compile-dev", help="Tag for the generated image"
    )
    parser_dev.add_argument(
        "--base-image",
        default=None,
        help=f"Docker base image (override with CCT_BASE_IMAGE env var, default: {get_default_base_image()})",
    )
    parser_dev.set_defaults(func=handle_build_docker_dev)

    # Subcommand: run-dev
    parser_run = subparsers.add_parser(
        "run-dev", help="Enter the CI/Dev Docker environment"
    )
    parser_run.add_argument(
        "--tag", default="cross-compile-dev", help="Tag of the image to run"
    )
    parser_run.set_defaults(func=handle_run_dev)

    # Subcommand: clean
    parser_clean = subparsers.add_parser(
        "clean", help="Clean build and install artifacts"
    )
    parser_clean.add_argument(
        "--build-dir", default=str(DEFAULT_BUILD_DIR), help="Build directory to clean"
    )
    parser_clean.add_argument(
        "--all", action="store_true", help="Also remove the sysroot directory"
    )
    parser_clean.set_defaults(func=handle_clean)

    # Subcommand: status
    parser_status = subparsers.add_parser(
        "status", help="Show current tool status and environment"
    )
    parser_status.add_argument(
        "--packages-file",
        default=os.getenv("CCT_PACKAGES_FILE", str(DEFAULT_PACKAGES_FILE)),
        help="Apt packages list file (override with CCT_PACKAGES_FILE env var)",
    )
    parser_status.set_defaults(func=handle_status)

    args = parser.parse_args()
    if args.version:
        try:
            print(f"cct version {metadata.version('cross-compile-tool')}")
        except metadata.PackageNotFoundError:
            # Fallback to a manual version if not installed as metadata
            print("cct version 0.1.8")
        sys.exit(0)

    if not args.command:
        parser.print_help()
        # Add a helpful footer about the current environment
        in_container = Path("/.dockerenv").exists()
        if in_container:
            logger.info(
                f"Note: You are in {C_BLUE}Docker{C_END}. Build commands are available, but 'prep' and 'run-dev' must be run from the Host."
            )
        else:
            logger.info(
                f"Note: You are on the {C_GREEN}Host{C_END}. You can use all commands, including 'prep' and 'run-dev'."
            )
        sys.exit(0)

    set_verbose(args.verbose)
    args.func(args)


if __name__ == "__main__":
    main()
