"""Cross-Docs: Documentation framework built on Cross-Inertia.

A complete solution for Python-backed documentation sites with
React frontends, SSR support, and Shiki syntax highlighting.
"""

from cross_docs.config import (
    APIPluginConfig,
    DocSet,
    DocsConfig,
    HomeConfig,
    load_config,
)
from cross_docs.markdown import load_markdown, load_raw_markdown, parse_frontmatter
from cross_docs.middleware import strip_trailing_slash_middleware, wants_markdown
from cross_docs.navigation import generate_nav
from cross_docs.routes import CrossDocs

__version__ = "0.13.0"

__all__ = [
    # Main class
    "CrossDocs",
    # Config
    "APIPluginConfig",
    "DocSet",
    "DocsConfig",
    "HomeConfig",
    "load_config",
    # Markdown utilities
    "parse_frontmatter",
    "load_markdown",
    "load_raw_markdown",
    # Navigation
    "generate_nav",
    # Middleware
    "strip_trailing_slash_middleware",
    "wants_markdown",
]


# Lazy imports for API module (requires optional dependencies)
def __getattr__(name: str):
    if name in ("api", "APIDocPlugin", "APIDocResult", "PythonAPIPlugin", "generate_api"):
        from cross_docs import api

        if name == "api":
            return api
        return getattr(api, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
