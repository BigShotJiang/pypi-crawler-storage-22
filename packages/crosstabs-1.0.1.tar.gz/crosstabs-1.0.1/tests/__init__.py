# Test suite for crosstabs-mcp
