"""crucible: Code review orchestration MCP server."""

__version__ = "0.4.0"
