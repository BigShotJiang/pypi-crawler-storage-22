"""Domain detection and routing."""

from crucible.domain.detection import detect_domain

__all__ = ["detect_domain"]
