"""Principles and knowledge loading."""
