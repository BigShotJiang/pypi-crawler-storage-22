main.py / app.py - example

from flask import Flask
from flask_cors import CORS
from crud_mysql import crud

app = Flask(__name__)

app.register_blueprint(crud)

if __name__ == "__main__":
	app.run(host="0.0.0.0", debug=True)

cred.json - example

{
    "user": {
        "allowd_methods": ["GET", "POST", "DELETE", "PUT"],
        "fetch_all": "true",
        "schema": {
            "name": "VARCHAR(100)",
            "email": "VARCHAR(100)",
            "encrypted_password": "VARCHAR(100)",
            "account_id": "INT",
            "is_active": "INT"
        }
    },
    "account": {
        "allowd_methods": ["GET", "POST", "DELETE"],
        "fetch_all": "false",
        "schema": {
            "name": "VARCHAR(100)",
            "subscription_type": "VARCHAR(100)",
            "root_user": "INT"
        }
    }
}

using tokens:

to protect endpoints by verifying tokens - add protected_methods to that object for example:

{
    "car": {
        "allowd_methods": ["GET", "POST", "DELETE", "PUT"],
        "protected_methods": ["GET"],
        "fetch_all": "true",
        "schema": {
            "owner": "VARCHAR(100)",
            "color": "VARCHAR(100)",
            "licence_plate": "INT"
        }
    }
}

here when using "GET" to get a car we will need to add a token.

important: also add to app.py the line: 
set_jwt_protection(app) 

in order for this to work a few things need to be set:
an environment varriable JWT_ALGORITHM should be set. 
the options are:
- RS256
- HS256
if none are set it will default to HS256.

if the algorithim being used is HS256 then a variable needs to be set for SECRET_KEY.
this has to be the same SECRET_KEY that was used for creating the jwt.

if the algorithim being used is RS256. a variable needs to be set for SECRET_KEYS_PATH.
and at that path there needs to be a public.pem
it has to be the same cert that was used to create the jwt.
