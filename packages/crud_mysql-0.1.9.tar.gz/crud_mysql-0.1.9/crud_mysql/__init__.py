from .endpoints import crud, create_object, get_object, delete_object, update_object
from .crud_object import CrudObject
from .protect import set_jwt_protection