from flask_jwt_extended import JWTManager, jwt_required, get_jwt
from flask import request
from functools import wraps
from crud_mysql.crud_object import CrudObject
import os

def protect():
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            method = request.method
            object_type = request.base_url.split("/")[-1]
            crud = CrudObject(object_type).get_crud()[object_type]
            if "protected_methods" in crud and method in crud["protected_methods"]:
                return jwt_required()(fn)(*args, **kwargs)
            else:
                return fn(*args, **kwargs)
        return wrapper
    return decorator

def set_jwt_protection(app):
    with open("crud.json", "r") as f:
        crud_file = f.read()
    if "protected_methods" in crud_file:
        algo = os.environ.get("JWT_ALGORITHM", "HS256")
        app.config['JWT_ALGORITHM'] = algo
        if algo == "RS256":
            SECRET_KEYS_PATH = os.environ.get("SECRET_KEYS_PATH", ".")
            with open(f'{SECRET_KEYS_PATH}/public.pem', 'r') as f:
                app.config['JWT_PUBLIC_KEY'] = f.read()
        elif algo == "HS256":
            if "SECRET_KEY" not in os.environ:
                raise Exception("missing secret key for verifying tokens")
            app.config['SECRET_KEY'] = os.environ.get("SECRET_KEY")
        jwt = JWTManager(app)