__all__ = [
    "VERSION_INFO",
    "__version__",
]

from crudlify.__version__ import (
    VERSION_INFO,
    __version__,
)
