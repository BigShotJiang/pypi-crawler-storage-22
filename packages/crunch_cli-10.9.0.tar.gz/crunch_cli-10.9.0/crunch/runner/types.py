from typing import Any, Dict, Tuple

ArgsLike = Tuple[Any, ...]
KwargsLike = Dict[str, Any]
