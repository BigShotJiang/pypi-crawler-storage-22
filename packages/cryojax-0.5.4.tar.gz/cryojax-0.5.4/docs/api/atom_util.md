# Atom manipulation

`cryojax.atom_util` is a submodule that contains functions for manipulating arrays of atoms and their properties.

## Chemistry

::: cryojax.atom_util.split_atoms_by_element

## Geometry

::: cryojax.atom_util.center_atom_positions
