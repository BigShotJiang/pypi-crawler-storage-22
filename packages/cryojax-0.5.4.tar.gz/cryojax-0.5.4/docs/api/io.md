# Basic loading of atoms, images, and volumes

`cryojax.io` implements reading/writing of basic cryo-EM data formats, such as MRC and PDB/PDBx formats.

## Loading atomic structures

::: cryojax.io.read_atoms_from_pdb

## Reading and writing MRC files
