# Detectors

???+ abstract "`cryojax.simulator.AbstractDetector`"
    ::: cryojax.simulator.AbstractDetector
        options:
            members:
                - sample_readout_from_expected_events

??? abstract "`cryojax.simulator.AbstractDQE`"
    ::: cryojax.simulator.AbstractDQE
        options:
            members:
                - __call__
