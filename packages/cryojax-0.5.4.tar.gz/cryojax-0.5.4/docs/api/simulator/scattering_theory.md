# Scattering approximations

??? abstract "`cryojax.simulator.AbstractScatteringTheory`"
    ::: cryojax.simulator.AbstractScatteringTheory
        options:
            members:
                - compute_contrast_spectrum
                - compute_intensity_spectrum
