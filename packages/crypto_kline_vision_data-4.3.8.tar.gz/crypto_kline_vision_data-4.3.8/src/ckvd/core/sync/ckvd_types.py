#!/usr/bin/env python
"""Crypto Kline Vision Data types and configuration.

This module contains the type definitions and configuration classes for the
CryptoKlineVisionData, extracted for better modularity.

# ADR: docs/adr/2026-01-30-claude-code-infrastructure.md
# Refactoring: Extract from ckvd.py (1182 lines) for modularity
"""

from __future__ import annotations

import os
from collections.abc import Sequence
from enum import Enum, auto
from pathlib import Path
from typing import TypeVar

import attr

from ckvd.utils.market_constraints import ChartType, DataProvider, MarketType

# Default HTTP timeout in seconds
DEFAULT_HTTP_TIMEOUT = 30.0

__all__ = [
    "CKVDConfig",
    "DataSource",
]


class DataSource(Enum):
    """Enum for data source selection.

    This enum defines the available data sources for the Failover Control Protocol.
    It is used to control the source selection behavior.

    Attributes:
        AUTO: Automatically select the best source based on the FCP strategy
        REST: Force use of the REST API only
        VISION: Force use of the Vision API only
        CACHE: Force use of the local cache only
    """

    AUTO = auto()  # Automatically select best source
    REST = auto()  # Force REST API
    VISION = auto()  # Force Vision API
    CACHE = auto()  # Force local cache


T = TypeVar("T")


@attr.define(slots=True, frozen=True)
class CKVDConfig:
    """Configuration for CryptoKlineVisionData.

    This immutable configuration class uses attrs to provide a strongly typed,
    validated configuration for the CryptoKlineVisionData with proper defaults.

    Attributes:
        market_type: Market type (SPOT, FUTURES_USDT, FUTURES_COIN).
            Mandatory parameter that determines which market data to retrieve.
        provider: Data provider (BINANCE, OKX).
            Mandatory parameter that determines which data provider to use.
        chart_type: Chart type (KLINES, FUNDING_RATE).
            Default is KLINES (candlestick data).
        cache_dir: Directory to store cache files.
            Default is None, which uses the platform-specific cache directory.
        use_cache: Whether to use caching.
            Default is True. Set to False to always fetch fresh data.
        retry_count: Number of retries for failed requests.
            Default is 5. Increase for less stable networks.
        log_level: Logging level for CKVD operations.
            Default is 'WARNING'. Can be 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'.
        suppress_http_debug: Whether to suppress HTTP debug logging.
            Default is True. Set to False to see detailed HTTP request/response logs.
        quiet_mode: Whether to suppress all non-error logging.
            Default is False. Set to True for completely silent operation except for errors.
        http_timeout: HTTP request timeout in seconds.
            Default is 30.0. Increase for slow networks or large requests.
        vision_enabled: Whether Vision API is enabled.
            Default is True. Set to False to skip Vision API (e.g., for OKX which has no Vision).
        fcp_priority: FCP data source priority order.
            Default is [CACHE, VISION, REST]. Customize for different fallback behavior.

    Example:
        >>> from ckvd import DataProvider, MarketType, ChartType
        >>> from pathlib import Path
        >>>
        >>> # Basic configuration for SPOT market
        >>> config = CKVDConfig(
        ...     market_type=MarketType.SPOT,
        ...     provider=DataProvider.BINANCE
        ... )
        >>>
        >>> # Configuration with custom logging settings
        >>> config = CKVDConfig(
        ...     market_type=MarketType.FUTURES_USDT,
        ...     provider=DataProvider.BINANCE,
        ...     chart_type=ChartType.FUNDING_RATE,
        ...     cache_dir=Path("./custom_cache"),
        ...     retry_count=10,
        ...     log_level='DEBUG',
        ...     suppress_http_debug=False  # Show detailed HTTP debugging
        ... )
        >>>
        >>> # Configuration for quiet operation
        >>> config = CKVDConfig(
        ...     market_type=MarketType.SPOT,
        ...     provider=DataProvider.BINANCE,
        ...     quiet_mode=True  # Only show errors
        ... )
    """

    # Mandatory parameters with validators
    market_type: MarketType = attr.field(validator=attr.validators.instance_of(MarketType))
    provider: DataProvider = attr.field(validator=attr.validators.instance_of(DataProvider))

    # Optional parameters with defaults and validators
    chart_type: ChartType = attr.field(default=ChartType.KLINES, validator=attr.validators.instance_of(ChartType))
    cache_dir: Path | None = attr.field(
        default=None,
        validator=attr.validators.optional(attr.validators.instance_of(Path)),
        converter=lambda p: Path(p) if p is not None and not isinstance(p, Path) else p,  # type: ignore[arg-type]
    )
    use_cache: bool = attr.field(default=True, validator=attr.validators.instance_of(bool))

    def __attrs_post_init__(self) -> None:
        """Apply CKVD_ENABLE_CACHE env var override after initialization."""
        if self.use_cache and os.environ.get("CKVD_ENABLE_CACHE", "").lower() in ("false", "0", "no"):
            object.__setattr__(self, "use_cache", False)
    retry_count: int = attr.field(default=5, validator=[attr.validators.instance_of(int), lambda _, __, value: value >= 0])

    # New logging control parameters
    log_level: str = attr.field(
        default="WARNING",
        validator=[attr.validators.instance_of(str), attr.validators.in_(["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"])],
        converter=str.upper,
    )
    suppress_http_debug: bool = attr.field(default=True, validator=attr.validators.instance_of(bool))
    quiet_mode: bool = attr.field(default=False, validator=attr.validators.instance_of(bool))

    # HTTP and FCP configuration parameters
    http_timeout: float = attr.field(
        default=DEFAULT_HTTP_TIMEOUT,
        validator=[attr.validators.instance_of((int, float)), lambda _, __, value: value > 0],
    )
    vision_enabled: bool = attr.field(default=True, validator=attr.validators.instance_of(bool))
    fcp_priority: Sequence[DataSource] = attr.field(
        factory=lambda: [DataSource.CACHE, DataSource.VISION, DataSource.REST],
    )

    @classmethod
    def create(cls: type[T], provider: DataProvider, market_type: MarketType, **kwargs) -> T:
        """Create a CKVDConfig with the given provider, market_type and optional overrides.

        This is a convenience builder method that allows for a more fluent interface.

        Args:
            provider: Data provider (BINANCE)
            market_type: Market type (SPOT, FUTURES_USDT, FUTURES_COIN)
            **kwargs: Optional parameter overrides

        Returns:
            Configured CKVDConfig instance

        Raises:
            TypeError: If market_type is not a MarketType enum or provider is not a DataProvider enum
            ValueError: If any parameter values are invalid

        Example:
            >>> from ckvd import DataProvider, MarketType
            >>> from pathlib import Path
            >>>
            >>> # Basic configuration for SPOT market
            >>> config = CKVDConfig(
            ...     market_type=MarketType.SPOT,
            ...     provider=DataProvider.BINANCE
            ... )
            >>>
            >>> # Configuration with custom settings
            >>> config = CKVDConfig(
            ...     market_type=MarketType.FUTURES_USDT,
            ...     provider=DataProvider.BINANCE,
            ...     chart_type=ChartType.FUNDING_RATE,
            ...     cache_dir=Path("./custom_cache"),
            ...     retry_count=10
            ... )
        """
        return cls(market_type=market_type, provider=provider, **kwargs)
