"""Tests for crypto-scanner."""
