from PIL import Image, ImageTk
import xml.etree.ElementTree as ET

class SpriteSheet:
    def __init__(self, image_path, xml_path):
        self.pil_image = Image.open(image_path).convert("RGBA")
        self.frames = {}

        tree = ET.parse(xml_path)
        root = tree.getroot()

        for sub in root.iter("SubTexture"):
            name = sub.attrib["name"]
            x = int(sub.attrib["x"])
            y = int(sub.attrib["y"])
            w = int(sub.attrib["width"])
            h = int(sub.attrib["height"])

            self.frames[name] = (x, y, w, h)

    def get_pil(self, name):
        x, y, w, h = self.frames[name]
        return self.pil_image.crop((x, y, x + w, y + h))

    def get_tk(self, name):
        return ImageTk.PhotoImage(self.get_pil(name))
