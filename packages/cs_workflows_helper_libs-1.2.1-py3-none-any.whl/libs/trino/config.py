"""Trino config."""

from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
)

from libs.service_account.config import ServiceAccountConfig


class TrinoConfig(BaseSettings):
    """A class for Trino related settings."""

    url: str
    port: int = 443
    http_scheme: str = "https"
    oidc: ServiceAccountConfig

    model_config = SettingsConfigDict(
        env_prefix="TRINO_",
        env_nested_delimiter="__",
    )
