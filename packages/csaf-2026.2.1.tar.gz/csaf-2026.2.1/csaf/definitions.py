"""CSAF Document general definitions."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime
from enum import Enum
from typing import Annotated, no_type_check

from pydantic import AnyUrl, BaseModel, Field, RootModel, field_validator, model_validator


class FlagCategory(Enum):
    """
    Defines the category of the machine readable label for flags.
    """

    component_not_present = 'component_not_present'
    inline_mitigations_already_exist = 'inline_mitigations_already_exist'
    vulnerable_code_cannot_be_controlled_by_adversary = 'vulnerable_code_cannot_be_controlled_by_adversary'
    vulnerable_code_not_in_execute_path = 'vulnerable_code_not_in_execute_path'
    vulnerable_code_not_present = 'vulnerable_code_not_present'


class Flag(BaseModel):
    """Contains product specific information in regard to this vulnerability as a single machine readable flag."""

    date: Annotated[
        datetime | None,
        Field(
            description='Contains the date when assessment was done or the flag was assigned.',
            title='Date of the flag',
        ),
    ] = None

    group_ids: Annotated[
        ProductGroupIds | None,
        Field(
            description='Specifies a list of product_group_ids to give context to the parent item.',
            title='List of product_group_ids',
        ),
    ] = None

    label: Annotated[
        FlagCategory,
        Field(
            description='Specifies the machine readable label.',
            title='Label of the flag',
        ),
    ]
    product_ids: Annotated[
        ListOfProductIds | None,
        Field(
            description='Specifies a list of product_ids to give context to the parent item.',
            title='List of product_ids',
        ),
    ] = None


class Flags(
    RootModel[
        Annotated[
            list[Flag],
            Field(
                description='Contains a list of machine readable flags.',
                min_length=1,
                # unique_items=True,
                title='List of flags',
            ),
        ]
    ]
):
    """Represents a list of unique labels or tracking IDs for the vulnerability (if such information exists)."""

    @classmethod
    @no_type_check
    @model_validator(mode='before')
    def check_len(cls, v):
        if not v:
            raise ValueError('optional element present but empty')
        return v


class Id(BaseModel):
    """Contains a single unique label or tracking ID for the vulnerability."""

    system_name: Annotated[
        str,
        Field(
            description='Indicates the name of the vulnerability tracking or numbering system.',
            examples=['Cisco Bug ID', 'GitHub Issue'],
            min_length=1,
            title='System name',
        ),
    ]
    text: Annotated[
        str,
        Field(
            description='Is unique label or tracking ID for the vulnerability (if such information exists).',
            examples=['CSCso66472', 'oasis-tcs/csaf#210'],
            min_length=1,
            title='Text',
        ),
    ]


class Ids(
    RootModel[
        Annotated[
            list[Id],
            Field(
                description=(
                    'Represents a list of unique labels or tracking IDs for the vulnerability'
                    ' (if such information exists).'
                ),
                min_length=1,
                title='List of IDs',
            ),
        ]
    ]
):
    """Represents a list of unique labels or tracking IDs for the vulnerability (if such information exists)."""

    @classmethod
    @no_type_check
    @model_validator(mode='before')
    def check_len(cls, v):
        if not v:
            raise ValueError('optional element present but empty')
        return v


class Name(
    RootModel[
        Annotated[
            str,
            Field(
                description='Contains the name of a single contributor being recognized.',
                examples=['Albert Einstein', 'Johann Sebastian Bach'],
                min_length=1,
                title='Name of the contributor',
            ),
        ]
    ]
):
    pass


class Acknowledgment(BaseModel):
    """
    Acknowledges contributions by describing those that contributed.
    """

    names: Annotated[
        list[Name] | None,
        Field(
            description='Contains the names of contributors being recognized.',
            min_length=1,
            title='List of acknowledged names',
        ),
    ] = None
    organization: Annotated[
        str | None,
        Field(
            description='Contains the name of a contributing organization being recognized.',
            examples=['CISA', 'Google Project Zero', 'Talos'],
            min_length=1,
            title='Contributing organization',
        ),
    ] = None
    summary: Annotated[
        str | None,
        Field(
            description='SHOULD represent any contextual details the document producers wish to make known about the'
            ' acknowledgment or acknowledged parties.',
            examples=['First analysis of Coordinated Multi-Stream Attack (CMSA)'],
            min_length=1,
            title='Summary of the acknowledgment',
        ),
    ] = None
    urls: Annotated[
        list[AnyUrl] | None,
        Field(
            description='Specifies a list of URLs or location of the reference to be acknowledged.',
            min_length=1,
            title='List of URLs',
        ),
    ] = None

    @classmethod
    @no_type_check
    @field_validator('names', 'organization', 'summary', 'urls')
    def check_len(cls, v):
        if not v:
            raise ValueError('optional element present but empty')
        return v


class Acknowledgments(
    RootModel[
        Annotated[
            list[Acknowledgment],
            Field(
                description='Contains a list of acknowledgment elements.',
                min_length=1,
                title='List of acknowledgments',
            ),
        ]
    ]
):
    """Contains a list of acknowledgment elements."""

    @classmethod
    @no_type_check
    @model_validator(mode='before')
    def check_len(cls, v):
        if not v:
            raise ValueError('optional element present but empty')
        return v


class ReferenceTokenForProductGroupInstance(
    RootModel[
        Annotated[
            str,
            Field(
                description=(
                    'Token required to identify a group of products so that it can be referred to from'
                    ' other parts in the document.'
                    ' There is no predefined or required format for the product_group_id'
                    ' as long as it uniquely identifies a group in the context of the current document.'
                ),
                examples=['CSAFGID-0001', 'CSAFGID-0002', 'CSAFGID-0020'],
                min_length=1,
                title='Reference token for product group instance',
            ),
        ]
    ]
):
    pass


class ProductGroupId(
    RootModel[
        Annotated[
            str,
            Field(
                description='Token required to identify a group of products so that it can be referred to from other'
                ' parts in the document. There is no predefined or required format for the product_group_id'
                ' as long as it uniquely identifies a group in the context of the current document.',
                examples=['CSAFGID-0001', 'CSAFGID-0002', 'CSAFGID-0020'],
                min_length=1,
                title='Reference token for product group instance',
            ),
        ]
    ]
):
    pass


class ProductGroupIds(
    RootModel[
        Annotated[
            list[ProductGroupId],
            Field(
                description='Specifies a list of product_group_ids to give context to the parent item.',
                min_length=1,
                title='List of product_group_ids',
            ),
        ]
    ]
):
    """Specifies a list of product_group_ids to give context to the parent item."""

    @classmethod
    @no_type_check
    @model_validator(mode='before')
    def check_len(cls, v):
        if not v:
            raise ValueError('mandatory element present but empty')
        return v


class ProductId(
    RootModel[
        Annotated[
            str,
            Field(
                description='Token required to identify a full_product_name so that it can be referred to from'
                ' other parts in the document.'
                ' There is no predefined or required format for the product_id as long as it'
                ' uniquely identifies a product in the context of the current document.',
                examples=['CSAFPID-0004', 'CSAFPID-0008'],
                min_length=1,
                title='Reference token for product instance',
            ),
        ]
    ]
):
    pass


class Products(
    RootModel[
        Annotated[
            list[ProductId],
            Field(
                description='Specifies a list of product_ids to give context to the parent item.',
                min_length=1,
                title='List of product_ids',
            ),
        ]
    ]
):
    """Specifies a list of product_ids to give context to the parent item."""

    pass


class ReferenceTokenForProductInstance(
    RootModel[
        Annotated[
            str,
            Field(
                description=(
                    'Token required to identify a full_product_name so that it can be referred to from other'
                    ' parts in the document.'
                    ' There is no predefined or required format for the product_id as long as it uniquely'
                    ' identifies a product in the context of the current document.'
                ),
                examples=['CSAFPID-0004', 'CSAFPID-0008'],
                min_length=1,
                title='Reference token for product instance',
            ),
        ]
    ]
):
    pass


class ListOfProductIds(
    RootModel[
        Annotated[
            Sequence[ReferenceTokenForProductInstance],
            Field(
                description=('Specifies a list of product_ids to give context to the parent item.'),
                min_length=1,
                title='List of product_ids',
            ),
        ]
    ]
):
    """Specifies a list of product_ids to give context to the parent item."""

    @classmethod
    @no_type_check
    @model_validator(mode='before')
    def check_len(cls, v):
        if not v:
            raise ValueError('mandatory element present but empty')
        return v


class Lang(
    RootModel[
        Annotated[
            str,
            Field(
                description='Identifies a language, corresponding to IETF BCP 47 / RFC 5646. See IETF language'
                ' registry: https://www.iana.org/assignments/language-subtag-registry/language-subtag-registry',
                examples=['de', 'en', 'fr', 'frc', 'jp'],
                pattern='^'
                '(([A-Za-z]{2,3}(-[A-Za-z]{3}(-[A-Za-z]{3}){0,2})?|[A-Za-z]{4,8})(-[A-Za-z]{4})?(-([A-Za-z]{2}|'
                '[0-9]{3}))?(-([A-Za-z0-9]{5,8}|[0-9][A-Za-z0-9]{3}))*(-[A-WY-Za-wy-z0-9](-[A-Za-z0-9]{2,8})+)*'
                '(-[Xx](-[A-Za-z0-9]{1,8})+)?|[Xx](-[A-Za-z0-9]{1,8})+|[Ii]-[Dd][Ee][Ff][Aa][Uu][Ll][Tt]|'
                '[Ii]-[Mm][Ii][Nn][Gg][Oo])$',
                title='Language type',
            ),
        ]
    ]
):
    pass


class NoteCategory(Enum):
    """Choice of what kind of note this is."""

    description = 'description'
    details = 'details'
    faq = 'faq'
    general = 'general'
    legal_disclaimer = 'legal_disclaimer'
    other = 'other'
    summary = 'summary'


class Note(BaseModel):
    """Is a place to put all manner of text blobs related to the current context."""

    audience: Annotated[
        str | None,
        Field(
            description='Indicates who is intended to read it.',
            examples=[
                'all',
                'executives',
                'operational management and system administrators',
                'safety engineers',
            ],
            min_length=1,
            title='Audience of note',
        ),
    ] = None
    category: Annotated[
        NoteCategory,
        Field(description='Contains the information of what kind of note this is.', title='Note category'),
    ]
    text: Annotated[
        str,
        Field(
            description='Holds the content of the note. Content varies depending on type.',
            min_length=1,
            title='Note content',
        ),
    ]
    title: Annotated[
        str | None,
        Field(
            description='Provides a concise description of what is contained in the text of the note.',
            examples=[
                'Details',
                'Executive summary',
                'Technical summary',
                'Impact on safety systems',
            ],
            min_length=1,
            title='Title of note',
        ),
    ] = None


class Notes(
    RootModel[
        Annotated[
            list[Note],
            Field(
                description='Contains notes which are specific to the current context.',
                min_length=1,
                title='List of notes',
            ),
        ]
    ]
):
    """Contains notes which are specific to the current context."""

    @classmethod
    @no_type_check
    @model_validator(mode='before')
    def check_len(cls, v):
        if not v:
            raise ValueError('mandatory element present but empty')
        return v


class ReferenceCategory(Enum):
    """Indicates whether the reference points to the same document or vulnerability in focus (depending on scope) or
    to an external resource."""

    external = 'external'
    self = 'self'


class Reference(BaseModel):
    """Holds any reference to conferences, papers, advisories, and other resources that are related and considered
    related to either a surrounding part of or the entire document and to be of value to the document consumer."""

    category: Annotated[
        ReferenceCategory | None,
        Field(
            description='Indicates whether the reference points to the same document or vulnerability in focus'
            ' (depending on scope) or to an external resource.',
            title='Category of reference',
        ),
    ] = ReferenceCategory.external
    summary: Annotated[
        str,
        Field(
            description='Indicates what this reference refers to.',
            min_length=1,
            title='Summary of the reference',
        ),
    ]
    url: Annotated[
        AnyUrl,
        Field(description='Provides the URL for the reference.', title='URL of reference'),
    ]


class References(
    RootModel[
        Annotated[
            list[Reference],
            Field(
                description='Holds a list of references.',
                min_length=1,
                title='List of references',
            ),
        ]
    ]
):
    """Holds a list of references."""

    @classmethod
    @no_type_check
    @model_validator(mode='before')
    def check_len(cls, v):
        if not v:
            raise ValueError('mandatory element present but empty')
        return v


class Version(
    RootModel[
        Annotated[
            str,
            Field(
                description=(
                    'Specifies a version string to denote clearly the evolution of the content of the document.'
                    ' Format must be either integer or semantic versioning.'
                ),
                examples=['1', '4', '0.9.0', '1.4.3', '2.40.0+21AF26D3'],
                pattern=(
                    '^(0|[1-9][0-9]*)$|^((0|[1-9]\\d*)\\.(0|[1-9]\\d*)\\.(0|[1-9]\\d*)'
                    '(?:-((?:0|[1-9]\\d*|\\d*[a-zA-Z-][0-9a-zA-Z-]*)'
                    '(?:\\.(?:0|[1-9]\\d*|\\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?'
                    '(?:\\+([0-9a-zA-Z-]+(?:\\.[0-9a-zA-Z-]+)*))?)$'
                ),
                title='Version',
            ),
        ]
    ]
):
    pass
