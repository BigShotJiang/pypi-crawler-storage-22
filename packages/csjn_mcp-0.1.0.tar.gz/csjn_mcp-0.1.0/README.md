# CSJN MCP Server

<!-- mcp-name: io.github.hernan-cc/csjn-mcp -->

Servidor MCP para buscar **sumarios de la Corte Suprema de Justicia de la Nación** (Argentina) desde sjconsulta.csjn.gov.ar.

Cobertura: sumarios desde 1994 hasta la actualidad. Sin autenticación requerida.

## Herramientas

| Herramienta | Descripción |
|-------------|-------------|
| `csjn_search` | Buscar sumarios por texto, carátula o rango de fechas |
| `csjn_get_analisis` | Análisis detallado: competencia, recurso, sentido, fallo destacado |
| `csjn_autocomplete_voces` | Autocompletar voces jurídicas del tesauro CSJN |

## Instalación

### Claude Code

```bash
claude mcp add csjn -- uvx csjn-mcp
```

### Claude Desktop

```json
{
  "mcpServers": {
    "csjn": {
      "command": "uvx",
      "args": ["csjn-mcp"]
    }
  }
}
```

### VS Code / Cursor

[<img src="https://img.shields.io/badge/VS_Code-Install-0098FF?style=for-the-badge&logo=visualstudiocode" alt="VS Code">](https://insiders.vscode.dev/redirect/mcp/install?name=csjn&config=%7B%22command%22%3A%22uvx%22%2C%22args%22%3A%5B%22csjn-mcp%22%5D%7D)

[<img src="https://img.shields.io/badge/Cursor-Install-F14A2D?style=for-the-badge&logo=cursor" alt="Cursor">](cursor://anysphere.cursor-deeplink/mcp/install?name=csjn&config=%7B%22command%22%3A%22uvx%22%2C%22args%22%3A%5B%22csjn-mcp%22%5D%7D)

## Ejemplos

- "Buscá jurisprudencia de la Corte sobre defensa del consumidor"
- "¿Qué dijo la CSJN sobre prescripción en materia laboral?"
- "Dame el análisis del sumario 175275"
- "¿Qué voces jurídicas hay sobre daños?"

## Datos por resultado

Cada sumario incluye:
- **voces**: descriptores temáticos del tesauro CSJN
- **texto**: contenido del sumario
- **autos**: carátula del caso
- **tomo/página**: referencia en Fallos de la CSJN
- **expediente**: número de expediente
- **fecha**: fecha del fallo
- **id_fallo**: ID para acceder al documento original

## Limitaciones

- Solo sumarios (resúmenes jurisprudenciales). Los fallos completos requieren reCAPTCHA Enterprise y no están disponibles vía API.
- Máximo ~50 resultados por búsqueda (paginación server-side de 10 en 10).
- Requiere conexión a sjconsulta.csjn.gov.ar.

## Licencia

MIT
