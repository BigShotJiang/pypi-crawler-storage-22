"""CSJN MCP Server — Argentine Supreme Court sumarios search."""

__version__ = "0.1.0"
