"""Lido CSM Operator Dashboard."""
