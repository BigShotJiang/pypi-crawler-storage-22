"""CSVPredict SDK - Analyze and visualize CSV data."""

from .client.models.color_palette import ColorPalette
from .client.models.font_family import FontFamily
from .client.models.language import Language
from .models import (
	CorrelationMatrix,
	InspectBatchResult,
	InspectResult,
	OverallStatistics,
	Statistics,
	SummaryStatistics,
)
from .sdk import CSVPredict, ExcelResult, GraphResult, PowerPointResult
from .server import display, set_download_context, show, stop_server

__all__ = [
	"CSVPredict",
	"GraphResult",
	"ExcelResult",
	"PowerPointResult",
	"InspectResult",
	"InspectBatchResult",
	"Statistics",
	"OverallStatistics",
	"SummaryStatistics",
	"CorrelationMatrix",
	"ColorPalette",
	"FontFamily",
	"Language",
	"show",
	"display",
	"set_download_context",
	"stop_server",
]
