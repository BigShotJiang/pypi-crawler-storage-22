from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_endpoint_generate_xlsx_api_v1_xlsx_post import (
	BodyEndpointGenerateXlsxApiV1XlsxPost,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
	*,
	body: BodyEndpointGenerateXlsxApiV1XlsxPost,
) -> dict[str, Any]:
	headers: dict[str, Any] = {}

	_kwargs: dict[str, Any] = {
		"method": "post",
		"url": "/api/v1/xlsx/",
	}

	_kwargs["files"] = body.to_multipart()

	_kwargs["headers"] = headers
	return _kwargs


def _parse_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
	if response.status_code == 200:
		response_200 = response.json()
		return response_200

	if response.status_code == 422:
		response_422 = HTTPValidationError.from_dict(response.json())

		return response_422

	if client.raise_on_unexpected_status:
		raise errors.UnexpectedStatus(response.status_code, response.content)
	else:
		return None


def _build_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
	return Response(
		status_code=HTTPStatus(response.status_code),
		content=response.content,
		headers=response.headers,
		parsed=_parse_response(client=client, response=response),
	)


def sync_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGenerateXlsxApiV1XlsxPost,
) -> Response[Any | HTTPValidationError]:
	"""Endpoint Generate Xlsx

	 Endpoint to generate and download Excel files for a single file as a ZIP.

	Args:
	        api_key (None): The API key dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        file (UploadFile): The data file to generate Excel files for.
	        ist[str] | None | None): The columns to partition the data by.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        language (Language): The language for chart titles.
	        palette (ColorPalette | None): The main color palette for the charts.
	        extra_palette (list[str] | None): The extra color palette for the charts.
	        use_python_charts (bool): If True, embed seaborn/matplotlib charts as Python
	                code using =PY() formula (requires Excel 365 with Python in Excel).

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of Excel files.

	Args:
	    body (BodyEndpointGenerateXlsxApiV1XlsxPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[Any | HTTPValidationError]
	"""

	kwargs = _get_kwargs(
		body=body,
	)

	response = client.get_httpx_client().request(
		**kwargs,
	)

	return _build_response(client=client, response=response)


def sync(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGenerateXlsxApiV1XlsxPost,
) -> Any | HTTPValidationError | None:
	"""Endpoint Generate Xlsx

	 Endpoint to generate and download Excel files for a single file as a ZIP.

	Args:
	        api_key (None): The API key dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        file (UploadFile): The data file to generate Excel files for.
	        ist[str] | None | None): The columns to partition the data by.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        language (Language): The language for chart titles.
	        palette (ColorPalette | None): The main color palette for the charts.
	        extra_palette (list[str] | None): The extra color palette for the charts.
	        use_python_charts (bool): If True, embed seaborn/matplotlib charts as Python
	                code using =PY() formula (requires Excel 365 with Python in Excel).

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of Excel files.

	Args:
	    body (BodyEndpointGenerateXlsxApiV1XlsxPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Any | HTTPValidationError
	"""

	return sync_detailed(
		client=client,
		body=body,
	).parsed


async def asyncio_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGenerateXlsxApiV1XlsxPost,
) -> Response[Any | HTTPValidationError]:
	"""Endpoint Generate Xlsx

	 Endpoint to generate and download Excel files for a single file as a ZIP.

	Args:
	        api_key (None): The API key dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        file (UploadFile): The data file to generate Excel files for.
	        ist[str] | None | None): The columns to partition the data by.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        language (Language): The language for chart titles.
	        palette (ColorPalette | None): The main color palette for the charts.
	        extra_palette (list[str] | None): The extra color palette for the charts.
	        use_python_charts (bool): If True, embed seaborn/matplotlib charts as Python
	                code using =PY() formula (requires Excel 365 with Python in Excel).

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of Excel files.

	Args:
	    body (BodyEndpointGenerateXlsxApiV1XlsxPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[Any | HTTPValidationError]
	"""

	kwargs = _get_kwargs(
		body=body,
	)

	response = await client.get_async_httpx_client().request(**kwargs)

	return _build_response(client=client, response=response)


async def asyncio(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGenerateXlsxApiV1XlsxPost,
) -> Any | HTTPValidationError | None:
	"""Endpoint Generate Xlsx

	 Endpoint to generate and download Excel files for a single file as a ZIP.

	Args:
	        api_key (None): The API key dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        file (UploadFile): The data file to generate Excel files for.
	        ist[str] | None | None): The columns to partition the data by.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        language (Language): The language for chart titles.
	        palette (ColorPalette | None): The main color palette for the charts.
	        extra_palette (list[str] | None): The extra color palette for the charts.
	        use_python_charts (bool): If True, embed seaborn/matplotlib charts as Python
	                code using =PY() formula (requires Excel 365 with Python in Excel).

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of Excel files.

	Args:
	    body (BodyEndpointGenerateXlsxApiV1XlsxPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Any | HTTPValidationError
	"""

	return (
		await asyncio_detailed(
			client=client,
			body=body,
		)
	).parsed
