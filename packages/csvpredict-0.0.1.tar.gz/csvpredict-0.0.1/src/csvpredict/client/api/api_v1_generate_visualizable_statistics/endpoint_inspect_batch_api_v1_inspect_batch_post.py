from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_endpoint_inspect_batch_api_v1_inspect_batch_post import (
	BodyEndpointInspectBatchApiV1InspectBatchPost,
)
from ...models.http_validation_error import HTTPValidationError
from ...models.inspect_batch_response import InspectBatchResponse
from ...types import Response


def _get_kwargs(
	*,
	body: BodyEndpointInspectBatchApiV1InspectBatchPost,
) -> dict[str, Any]:
	headers: dict[str, Any] = {}

	_kwargs: dict[str, Any] = {
		"method": "post",
		"url": "/api/v1/inspect/batch",
	}

	_kwargs["files"] = body.to_multipart()

	_kwargs["headers"] = headers
	return _kwargs


def _parse_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | InspectBatchResponse | None:
	if response.status_code == 200:
		response_200 = InspectBatchResponse.from_dict(response.json())

		return response_200

	if response.status_code == 422:
		response_422 = HTTPValidationError.from_dict(response.json())

		return response_422

	if client.raise_on_unexpected_status:
		raise errors.UnexpectedStatus(response.status_code, response.content)
	else:
		return None


def _build_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | InspectBatchResponse]:
	return Response(
		status_code=HTTPStatus(response.status_code),
		content=response.content,
		headers=response.headers,
		parsed=_parse_response(client=client, response=response),
	)


def sync_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointInspectBatchApiV1InspectBatchPost,
) -> Response[HTTPValidationError | InspectBatchResponse]:
	"""Endpoint Inspect Batch

	 Returns visualizable statistics and. time series.

	Args:
	        api_key (None): The API key dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        files (list[UploadFile]): The training data files.
	        partition_by (list[list[str] | None] | None): The columns to partition the data
	                by for each file.
	        window_size (int): Window size for rolling calculations.
	        round (int): Number of decimal places to round the results.
	        null_values (list[str] | None): List of strings to consider as null values.

	Returns:
	        InspectResponse: The predictions and score.

	Args:
	    body (BodyEndpointInspectBatchApiV1InspectBatchPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[HTTPValidationError | InspectBatchResponse]
	"""

	kwargs = _get_kwargs(
		body=body,
	)

	response = client.get_httpx_client().request(
		**kwargs,
	)

	return _build_response(client=client, response=response)


def sync(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointInspectBatchApiV1InspectBatchPost,
) -> HTTPValidationError | InspectBatchResponse | None:
	"""Endpoint Inspect Batch

	 Returns visualizable statistics and. time series.

	Args:
	        api_key (None): The API key dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        files (list[UploadFile]): The training data files.
	        partition_by (list[list[str] | None] | None): The columns to partition the data
	                by for each file.
	        window_size (int): Window size for rolling calculations.
	        round (int): Number of decimal places to round the results.
	        null_values (list[str] | None): List of strings to consider as null values.

	Returns:
	        InspectResponse: The predictions and score.

	Args:
	    body (BodyEndpointInspectBatchApiV1InspectBatchPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    HTTPValidationError | InspectBatchResponse
	"""

	return sync_detailed(
		client=client,
		body=body,
	).parsed


async def asyncio_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointInspectBatchApiV1InspectBatchPost,
) -> Response[HTTPValidationError | InspectBatchResponse]:
	"""Endpoint Inspect Batch

	 Returns visualizable statistics and. time series.

	Args:
	        api_key (None): The API key dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        files (list[UploadFile]): The training data files.
	        partition_by (list[list[str] | None] | None): The columns to partition the data
	                by for each file.
	        window_size (int): Window size for rolling calculations.
	        round (int): Number of decimal places to round the results.
	        null_values (list[str] | None): List of strings to consider as null values.

	Returns:
	        InspectResponse: The predictions and score.

	Args:
	    body (BodyEndpointInspectBatchApiV1InspectBatchPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[HTTPValidationError | InspectBatchResponse]
	"""

	kwargs = _get_kwargs(
		body=body,
	)

	response = await client.get_async_httpx_client().request(**kwargs)

	return _build_response(client=client, response=response)


async def asyncio(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointInspectBatchApiV1InspectBatchPost,
) -> HTTPValidationError | InspectBatchResponse | None:
	"""Endpoint Inspect Batch

	 Returns visualizable statistics and. time series.

	Args:
	        api_key (None): The API key dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        files (list[UploadFile]): The training data files.
	        partition_by (list[list[str] | None] | None): The columns to partition the data
	                by for each file.
	        window_size (int): Window size for rolling calculations.
	        round (int): Number of decimal places to round the results.
	        null_values (list[str] | None): List of strings to consider as null values.

	Returns:
	        InspectResponse: The predictions and score.

	Args:
	    body (BodyEndpointInspectBatchApiV1InspectBatchPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    HTTPValidationError | InspectBatchResponse
	"""

	return (
		await asyncio_detailed(
			client=client,
			body=body,
		)
	).parsed
