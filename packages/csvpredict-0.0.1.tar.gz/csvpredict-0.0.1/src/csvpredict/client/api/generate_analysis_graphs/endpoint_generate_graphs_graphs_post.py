from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_endpoint_generate_graphs_graphs_post import (
	BodyEndpointGenerateGraphsGraphsPost,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
	*,
	body: BodyEndpointGenerateGraphsGraphsPost,
	csvpredict_origin: str,
) -> dict[str, Any]:
	headers: dict[str, Any] = {}
	headers["csvpredict-origin"] = csvpredict_origin

	_kwargs: dict[str, Any] = {
		"method": "post",
		"url": "/_/graphs/",
	}

	_kwargs["files"] = body.to_multipart()

	_kwargs["headers"] = headers
	return _kwargs


def _parse_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
	if response.status_code == 200:
		response_200 = response.json()
		return response_200

	if response.status_code == 422:
		response_422 = HTTPValidationError.from_dict(response.json())

		return response_422

	if client.raise_on_unexpected_status:
		raise errors.UnexpectedStatus(response.status_code, response.content)
	else:
		return None


def _build_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
	return Response(
		status_code=HTTPStatus(response.status_code),
		content=response.content,
		headers=response.headers,
		parsed=_parse_response(client=client, response=response),
	)


def sync_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGenerateGraphsGraphsPost,
	csvpredict_origin: str,
) -> Response[Any | HTTPValidationError]:
	r"""Endpoint Generate Graphs

	 Endpoint to generate and download graphs for a single file as a ZIP.

	Args:
	        user (dict[str, Any]): The authenticated user.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        file (UploadFile): The data file to generate graphs for.
	        partition_by (list[str] | None): The columns to partition the data by.
	        extension (Literal[\".png\", \".jpg\", \".jpeg\", \".svg\"]): The file extension for
	                the graphs.
	        transparent (bool): Whether the graph background should be transparent.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        dpi (int): The resolution (dots per inch) for the generated graphs.
	        font (FontFamily): The font family to use in the graphs.
	        language (Language): The language for graph titles.
	        palette (ColorPalette | None): The main color palette for the graphs.
	        extra_palette (list[str] | None): The extra color palette for the graphs.

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of graphs.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointGenerateGraphsGraphsPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[Any | HTTPValidationError]
	"""

	kwargs = _get_kwargs(
		body=body,
		csvpredict_origin=csvpredict_origin,
	)

	response = client.get_httpx_client().request(
		**kwargs,
	)

	return _build_response(client=client, response=response)


def sync(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGenerateGraphsGraphsPost,
	csvpredict_origin: str,
) -> Any | HTTPValidationError | None:
	r"""Endpoint Generate Graphs

	 Endpoint to generate and download graphs for a single file as a ZIP.

	Args:
	        user (dict[str, Any]): The authenticated user.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        file (UploadFile): The data file to generate graphs for.
	        partition_by (list[str] | None): The columns to partition the data by.
	        extension (Literal[\".png\", \".jpg\", \".jpeg\", \".svg\"]): The file extension for
	                the graphs.
	        transparent (bool): Whether the graph background should be transparent.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        dpi (int): The resolution (dots per inch) for the generated graphs.
	        font (FontFamily): The font family to use in the graphs.
	        language (Language): The language for graph titles.
	        palette (ColorPalette | None): The main color palette for the graphs.
	        extra_palette (list[str] | None): The extra color palette for the graphs.

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of graphs.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointGenerateGraphsGraphsPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Any | HTTPValidationError
	"""

	return sync_detailed(
		client=client,
		body=body,
		csvpredict_origin=csvpredict_origin,
	).parsed


async def asyncio_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGenerateGraphsGraphsPost,
	csvpredict_origin: str,
) -> Response[Any | HTTPValidationError]:
	r"""Endpoint Generate Graphs

	 Endpoint to generate and download graphs for a single file as a ZIP.

	Args:
	        user (dict[str, Any]): The authenticated user.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        file (UploadFile): The data file to generate graphs for.
	        partition_by (list[str] | None): The columns to partition the data by.
	        extension (Literal[\".png\", \".jpg\", \".jpeg\", \".svg\"]): The file extension for
	                the graphs.
	        transparent (bool): Whether the graph background should be transparent.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        dpi (int): The resolution (dots per inch) for the generated graphs.
	        font (FontFamily): The font family to use in the graphs.
	        language (Language): The language for graph titles.
	        palette (ColorPalette | None): The main color palette for the graphs.
	        extra_palette (list[str] | None): The extra color palette for the graphs.

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of graphs.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointGenerateGraphsGraphsPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[Any | HTTPValidationError]
	"""

	kwargs = _get_kwargs(
		body=body,
		csvpredict_origin=csvpredict_origin,
	)

	response = await client.get_async_httpx_client().request(**kwargs)

	return _build_response(client=client, response=response)


async def asyncio(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGenerateGraphsGraphsPost,
	csvpredict_origin: str,
) -> Any | HTTPValidationError | None:
	r"""Endpoint Generate Graphs

	 Endpoint to generate and download graphs for a single file as a ZIP.

	Args:
	        user (dict[str, Any]): The authenticated user.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        file (UploadFile): The data file to generate graphs for.
	        partition_by (list[str] | None): The columns to partition the data by.
	        extension (Literal[\".png\", \".jpg\", \".jpeg\", \".svg\"]): The file extension for
	                the graphs.
	        transparent (bool): Whether the graph background should be transparent.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        dpi (int): The resolution (dots per inch) for the generated graphs.
	        font (FontFamily): The font family to use in the graphs.
	        language (Language): The language for graph titles.
	        palette (ColorPalette | None): The main color palette for the graphs.
	        extra_palette (list[str] | None): The extra color palette for the graphs.

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of graphs.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointGenerateGraphsGraphsPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Any | HTTPValidationError
	"""

	return (
		await asyncio_detailed(
			client=client,
			body=body,
			csvpredict_origin=csvpredict_origin,
		)
	).parsed
