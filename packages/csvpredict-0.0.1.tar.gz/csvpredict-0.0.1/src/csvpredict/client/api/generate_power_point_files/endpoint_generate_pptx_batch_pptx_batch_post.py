from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_endpoint_generate_pptx_batch_pptx_batch_post import (
	BodyEndpointGeneratePptxBatchPptxBatchPost,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
	*,
	body: BodyEndpointGeneratePptxBatchPptxBatchPost,
	csvpredict_origin: str,
) -> dict[str, Any]:
	headers: dict[str, Any] = {}
	headers["csvpredict-origin"] = csvpredict_origin

	_kwargs: dict[str, Any] = {
		"method": "post",
		"url": "/_/pptx/batch",
	}

	_kwargs["files"] = body.to_multipart()

	_kwargs["headers"] = headers
	return _kwargs


def _parse_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
	if response.status_code == 200:
		response_200 = response.json()
		return response_200

	if response.status_code == 422:
		response_422 = HTTPValidationError.from_dict(response.json())

		return response_422

	if client.raise_on_unexpected_status:
		raise errors.UnexpectedStatus(response.status_code, response.content)
	else:
		return None


def _build_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
	return Response(
		status_code=HTTPStatus(response.status_code),
		content=response.content,
		headers=response.headers,
		parsed=_parse_response(client=client, response=response),
	)


def sync_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGeneratePptxBatchPptxBatchPost,
	csvpredict_origin: str,
) -> Response[Any | HTTPValidationError]:
	"""Endpoint Generate Pptx Batch

	 Endpoint to generate and download PowerPoint files for multiple files as a ZIP.

	Args:
	        user (dict[str, Any]): The authenticated user.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        files (list[UploadFile]): The data files to generate PowerPoint files for.
	        partition_by (list[list[str] | None] | None): The columns to partition by.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        dpi (int): The resolution (dots per inch) for chart images.
	        font (FontFamily): The font family to use in the presentations.
	        language (Language): The language for chart titles.
	        palette (ColorPalette | None): The main color palette for the charts.
	        extra_palette (list[str] | None): The extra color palette for the charts.

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of PowerPoint
	                files.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointGeneratePptxBatchPptxBatchPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[Any | HTTPValidationError]
	"""

	kwargs = _get_kwargs(
		body=body,
		csvpredict_origin=csvpredict_origin,
	)

	response = client.get_httpx_client().request(
		**kwargs,
	)

	return _build_response(client=client, response=response)


def sync(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGeneratePptxBatchPptxBatchPost,
	csvpredict_origin: str,
) -> Any | HTTPValidationError | None:
	"""Endpoint Generate Pptx Batch

	 Endpoint to generate and download PowerPoint files for multiple files as a ZIP.

	Args:
	        user (dict[str, Any]): The authenticated user.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        files (list[UploadFile]): The data files to generate PowerPoint files for.
	        partition_by (list[list[str] | None] | None): The columns to partition by.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        dpi (int): The resolution (dots per inch) for chart images.
	        font (FontFamily): The font family to use in the presentations.
	        language (Language): The language for chart titles.
	        palette (ColorPalette | None): The main color palette for the charts.
	        extra_palette (list[str] | None): The extra color palette for the charts.

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of PowerPoint
	                files.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointGeneratePptxBatchPptxBatchPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Any | HTTPValidationError
	"""

	return sync_detailed(
		client=client,
		body=body,
		csvpredict_origin=csvpredict_origin,
	).parsed


async def asyncio_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGeneratePptxBatchPptxBatchPost,
	csvpredict_origin: str,
) -> Response[Any | HTTPValidationError]:
	"""Endpoint Generate Pptx Batch

	 Endpoint to generate and download PowerPoint files for multiple files as a ZIP.

	Args:
	        user (dict[str, Any]): The authenticated user.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        files (list[UploadFile]): The data files to generate PowerPoint files for.
	        partition_by (list[list[str] | None] | None): The columns to partition by.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        dpi (int): The resolution (dots per inch) for chart images.
	        font (FontFamily): The font family to use in the presentations.
	        language (Language): The language for chart titles.
	        palette (ColorPalette | None): The main color palette for the charts.
	        extra_palette (list[str] | None): The extra color palette for the charts.

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of PowerPoint
	                files.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointGeneratePptxBatchPptxBatchPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[Any | HTTPValidationError]
	"""

	kwargs = _get_kwargs(
		body=body,
		csvpredict_origin=csvpredict_origin,
	)

	response = await client.get_async_httpx_client().request(**kwargs)

	return _build_response(client=client, response=response)


async def asyncio(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointGeneratePptxBatchPptxBatchPost,
	csvpredict_origin: str,
) -> Any | HTTPValidationError | None:
	"""Endpoint Generate Pptx Batch

	 Endpoint to generate and download PowerPoint files for multiple files as a ZIP.

	Args:
	        user (dict[str, Any]): The authenticated user.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        files (list[UploadFile]): The data files to generate PowerPoint files for.
	        partition_by (list[list[str] | None] | None): The columns to partition by.
	        window_size (int): The window size for rolling statistics.
	        null_values (list[str] | None): List of strings to consider as null values.
	        dpi (int): The resolution (dots per inch) for chart images.
	        font (FontFamily): The font family to use in the presentations.
	        language (Language): The language for chart titles.
	        palette (ColorPalette | None): The main color palette for the charts.
	        extra_palette (list[str] | None): The extra color palette for the charts.

	Returns:
	        StreamingResponse: A streaming response containing the ZIP file of PowerPoint
	                files.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointGeneratePptxBatchPptxBatchPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Any | HTTPValidationError
	"""

	return (
		await asyncio_detailed(
			client=client,
			body=body,
			csvpredict_origin=csvpredict_origin,
		)
	).parsed
