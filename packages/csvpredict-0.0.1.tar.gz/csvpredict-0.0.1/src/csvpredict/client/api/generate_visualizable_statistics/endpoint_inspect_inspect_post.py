from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_endpoint_inspect_inspect_post import BodyEndpointInspectInspectPost
from ...models.http_validation_error import HTTPValidationError
from ...models.inspect_response import InspectResponse
from ...types import Response


def _get_kwargs(
	*,
	body: BodyEndpointInspectInspectPost,
	csvpredict_origin: str,
) -> dict[str, Any]:
	headers: dict[str, Any] = {}
	headers["csvpredict-origin"] = csvpredict_origin

	_kwargs: dict[str, Any] = {
		"method": "post",
		"url": "/_/inspect/",
	}

	_kwargs["files"] = body.to_multipart()

	_kwargs["headers"] = headers
	return _kwargs


def _parse_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | InspectResponse | None:
	if response.status_code == 200:
		response_200 = InspectResponse.from_dict(response.json())

		return response_200

	if response.status_code == 422:
		response_422 = HTTPValidationError.from_dict(response.json())

		return response_422

	if client.raise_on_unexpected_status:
		raise errors.UnexpectedStatus(response.status_code, response.content)
	else:
		return None


def _build_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | InspectResponse]:
	return Response(
		status_code=HTTPStatus(response.status_code),
		content=response.content,
		headers=response.headers,
		parsed=_parse_response(client=client, response=response),
	)


def sync_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointInspectInspectPost,
	csvpredict_origin: str,
) -> Response[HTTPValidationError | InspectResponse]:
	"""Endpoint Inspect

	 Returns visualizable statistics and. time series.

	Args:
	        user (dict[str, Any]): The Firebase connector dependency.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        file (UploadFile): The training data file.
	        partition_by (list[str] | None): The columns to partition the data by.
	        window_size (int): Window size for rolling calculations.
	        round (int): Number of decimal places to round the results.
	        null_values (list[str] | None): List of strings to consider as null values.

	Returns:
	        InspectResponse: The predictions and score.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointInspectInspectPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[HTTPValidationError | InspectResponse]
	"""

	kwargs = _get_kwargs(
		body=body,
		csvpredict_origin=csvpredict_origin,
	)

	response = client.get_httpx_client().request(
		**kwargs,
	)

	return _build_response(client=client, response=response)


def sync(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointInspectInspectPost,
	csvpredict_origin: str,
) -> HTTPValidationError | InspectResponse | None:
	"""Endpoint Inspect

	 Returns visualizable statistics and. time series.

	Args:
	        user (dict[str, Any]): The Firebase connector dependency.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        file (UploadFile): The training data file.
	        partition_by (list[str] | None): The columns to partition the data by.
	        window_size (int): Window size for rolling calculations.
	        round (int): Number of decimal places to round the results.
	        null_values (list[str] | None): List of strings to consider as null values.

	Returns:
	        InspectResponse: The predictions and score.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointInspectInspectPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    HTTPValidationError | InspectResponse
	"""

	return sync_detailed(
		client=client,
		body=body,
		csvpredict_origin=csvpredict_origin,
	).parsed


async def asyncio_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointInspectInspectPost,
	csvpredict_origin: str,
) -> Response[HTTPValidationError | InspectResponse]:
	"""Endpoint Inspect

	 Returns visualizable statistics and. time series.

	Args:
	        user (dict[str, Any]): The Firebase connector dependency.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        file (UploadFile): The training data file.
	        partition_by (list[str] | None): The columns to partition the data by.
	        window_size (int): Window size for rolling calculations.
	        round (int): Number of decimal places to round the results.
	        null_values (list[str] | None): List of strings to consider as null values.

	Returns:
	        InspectResponse: The predictions and score.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointInspectInspectPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[HTTPValidationError | InspectResponse]
	"""

	kwargs = _get_kwargs(
		body=body,
		csvpredict_origin=csvpredict_origin,
	)

	response = await client.get_async_httpx_client().request(**kwargs)

	return _build_response(client=client, response=response)


async def asyncio(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointInspectInspectPost,
	csvpredict_origin: str,
) -> HTTPValidationError | InspectResponse | None:
	"""Endpoint Inspect

	 Returns visualizable statistics and. time series.

	Args:
	        user (dict[str, Any]): The Firebase connector dependency.
	        tokens (UserTokenService): The user token service dependency.
	        request (Request): The FastAPI request object. Needed by slowapi limiter.
	        background_tasks (BackgroundTasks): The FastAPI background tasks.
	        file (UploadFile): The training data file.
	        partition_by (list[str] | None): The columns to partition the data by.
	        window_size (int): Window size for rolling calculations.
	        round (int): Number of decimal places to round the results.
	        null_values (list[str] | None): List of strings to consider as null values.

	Returns:
	        InspectResponse: The predictions and score.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointInspectInspectPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    HTTPValidationError | InspectResponse
	"""

	return (
		await asyncio_detailed(
			client=client,
			body=body,
			csvpredict_origin=csvpredict_origin,
		)
	).parsed
