from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_endpoint_predict_predict_post import BodyEndpointPredictPredictPost
from ...models.http_validation_error import HTTPValidationError
from ...models.predict_response import PredictResponse
from ...types import Response


def _get_kwargs(
	*,
	body: BodyEndpointPredictPredictPost,
	csvpredict_origin: str,
) -> dict[str, Any]:
	headers: dict[str, Any] = {}
	headers["csvpredict-origin"] = csvpredict_origin

	_kwargs: dict[str, Any] = {
		"method": "post",
		"url": "/_/predict/",
	}

	_kwargs["files"] = body.to_multipart()

	_kwargs["headers"] = headers
	return _kwargs


def _parse_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | PredictResponse | None:
	if response.status_code == 200:
		response_200 = PredictResponse.from_dict(response.json())

		return response_200

	if response.status_code == 422:
		response_422 = HTTPValidationError.from_dict(response.json())

		return response_422

	if client.raise_on_unexpected_status:
		raise errors.UnexpectedStatus(response.status_code, response.content)
	else:
		return None


def _build_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | PredictResponse]:
	return Response(
		status_code=HTTPStatus(response.status_code),
		content=response.content,
		headers=response.headers,
		parsed=_parse_response(client=client, response=response),
	)


def sync_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointPredictPredictPost,
	csvpredict_origin: str,
) -> Response[HTTPValidationError | PredictResponse]:
	"""Endpoint Predict

	 Makes predictions using a Prophet model fitted on the provided training data.

	Args:
	        file (UploadFile): The training data file.
	        num_periods (int): The number of periods to predict.
	        timestamp_col (str | None): The name of the timestamp column.
	        value_col (str | None): The name of the value column.
	        frequency (Frequency | None): The frequency of the data.
	        country (str | None): The country for holiday effects.
	        custom_seasonality (dict[str, str | float | int] | None): Custom seasonality
	                parameters.
	        use_frequency_as_regressor (bool): Whether to use frequency-based regressors.
	                Defaults to False.
	        window_size (int): The window size for rolling imputation and smoothing.
	                Defaults to 5.
	        max_zscore (float): The maximum z-score for outlier detection. Defaults to 3.0.

	Returns:
	        PredictResponse: The prediction response containing predictions, model
	                parameters, and score.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointPredictPredictPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[HTTPValidationError | PredictResponse]
	"""

	kwargs = _get_kwargs(
		body=body,
		csvpredict_origin=csvpredict_origin,
	)

	response = client.get_httpx_client().request(
		**kwargs,
	)

	return _build_response(client=client, response=response)


def sync(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointPredictPredictPost,
	csvpredict_origin: str,
) -> HTTPValidationError | PredictResponse | None:
	"""Endpoint Predict

	 Makes predictions using a Prophet model fitted on the provided training data.

	Args:
	        file (UploadFile): The training data file.
	        num_periods (int): The number of periods to predict.
	        timestamp_col (str | None): The name of the timestamp column.
	        value_col (str | None): The name of the value column.
	        frequency (Frequency | None): The frequency of the data.
	        country (str | None): The country for holiday effects.
	        custom_seasonality (dict[str, str | float | int] | None): Custom seasonality
	                parameters.
	        use_frequency_as_regressor (bool): Whether to use frequency-based regressors.
	                Defaults to False.
	        window_size (int): The window size for rolling imputation and smoothing.
	                Defaults to 5.
	        max_zscore (float): The maximum z-score for outlier detection. Defaults to 3.0.

	Returns:
	        PredictResponse: The prediction response containing predictions, model
	                parameters, and score.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointPredictPredictPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    HTTPValidationError | PredictResponse
	"""

	return sync_detailed(
		client=client,
		body=body,
		csvpredict_origin=csvpredict_origin,
	).parsed


async def asyncio_detailed(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointPredictPredictPost,
	csvpredict_origin: str,
) -> Response[HTTPValidationError | PredictResponse]:
	"""Endpoint Predict

	 Makes predictions using a Prophet model fitted on the provided training data.

	Args:
	        file (UploadFile): The training data file.
	        num_periods (int): The number of periods to predict.
	        timestamp_col (str | None): The name of the timestamp column.
	        value_col (str | None): The name of the value column.
	        frequency (Frequency | None): The frequency of the data.
	        country (str | None): The country for holiday effects.
	        custom_seasonality (dict[str, str | float | int] | None): Custom seasonality
	                parameters.
	        use_frequency_as_regressor (bool): Whether to use frequency-based regressors.
	                Defaults to False.
	        window_size (int): The window size for rolling imputation and smoothing.
	                Defaults to 5.
	        max_zscore (float): The maximum z-score for outlier detection. Defaults to 3.0.

	Returns:
	        PredictResponse: The prediction response containing predictions, model
	                parameters, and score.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointPredictPredictPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[HTTPValidationError | PredictResponse]
	"""

	kwargs = _get_kwargs(
		body=body,
		csvpredict_origin=csvpredict_origin,
	)

	response = await client.get_async_httpx_client().request(**kwargs)

	return _build_response(client=client, response=response)


async def asyncio(
	*,
	client: AuthenticatedClient,
	body: BodyEndpointPredictPredictPost,
	csvpredict_origin: str,
) -> HTTPValidationError | PredictResponse | None:
	"""Endpoint Predict

	 Makes predictions using a Prophet model fitted on the provided training data.

	Args:
	        file (UploadFile): The training data file.
	        num_periods (int): The number of periods to predict.
	        timestamp_col (str | None): The name of the timestamp column.
	        value_col (str | None): The name of the value column.
	        frequency (Frequency | None): The frequency of the data.
	        country (str | None): The country for holiday effects.
	        custom_seasonality (dict[str, str | float | int] | None): Custom seasonality
	                parameters.
	        use_frequency_as_regressor (bool): Whether to use frequency-based regressors.
	                Defaults to False.
	        window_size (int): The window size for rolling imputation and smoothing.
	                Defaults to 5.
	        max_zscore (float): The maximum z-score for outlier detection. Defaults to 3.0.

	Returns:
	        PredictResponse: The prediction response containing predictions, model
	                parameters, and score.

	Args:
	    csvpredict_origin (str):
	    body (BodyEndpointPredictPredictPost):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    HTTPValidationError | PredictResponse
	"""

	return (
		await asyncio_detailed(
			client=client,
			body=body,
			csvpredict_origin=csvpredict_origin,
		)
	).parsed
