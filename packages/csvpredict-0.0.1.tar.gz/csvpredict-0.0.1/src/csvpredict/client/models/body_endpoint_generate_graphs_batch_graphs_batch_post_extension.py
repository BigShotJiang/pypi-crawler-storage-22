from enum import Enum


class BodyEndpointGenerateGraphsBatchGraphsBatchPostExtension(str, Enum):
	VALUE_0 = ".png"
	VALUE_1 = ".jpg"
	VALUE_2 = ".jpeg"
	VALUE_3 = ".svg"

	def __str__(self) -> str:
		return str(self.value)
