from __future__ import annotations

import json
from collections.abc import Mapping
from io import BytesIO
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.body_endpoint_generate_graphs_graphs_post_extension import (
	BodyEndpointGenerateGraphsGraphsPostExtension,
)
from ..models.font_family import FontFamily
from ..models.language import Language
from ..types import UNSET, File, Unset

if TYPE_CHECKING:
	from ..models.color_palette import ColorPalette


T = TypeVar("T", bound="BodyEndpointGenerateGraphsGraphsPost")


@_attrs_define
class BodyEndpointGenerateGraphsGraphsPost:
	"""
	Attributes:
	    file (File):
	    partition_by (list[str] | None | Unset):
	    extension (BodyEndpointGenerateGraphsGraphsPostExtension | Unset):  Default:
	        BodyEndpointGenerateGraphsGraphsPostExtension.VALUE_3.
	    transparent (bool | Unset):  Default: False.
	    window_size (int | Unset):  Default: 5.
	    null_values (list[str] | None | Unset):
	    dpi (int | Unset):  Default: 1000.
	    font (FontFamily | Unset): Font family options for charts and presentations.
	    language (Language | Unset):
	    palette (ColorPalette | None | Unset):
	    extra_palette (list[str] | None | Unset):
	"""

	file: File
	partition_by: list[str] | None | Unset = UNSET
	extension: BodyEndpointGenerateGraphsGraphsPostExtension | Unset = (
		BodyEndpointGenerateGraphsGraphsPostExtension.VALUE_3
	)
	transparent: bool | Unset = False
	window_size: int | Unset = 5
	null_values: list[str] | None | Unset = UNSET
	dpi: int | Unset = 1000
	font: FontFamily | Unset = UNSET
	language: Language | Unset = UNSET
	palette: ColorPalette | None | Unset = UNSET
	extra_palette: list[str] | None | Unset = UNSET
	additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

	def to_dict(self) -> dict[str, Any]:
		from ..models.color_palette import ColorPalette

		file = self.file.to_tuple()

		partition_by: list[str] | None | Unset
		if isinstance(self.partition_by, Unset):
			partition_by = UNSET
		elif isinstance(self.partition_by, list):
			partition_by = self.partition_by

		else:
			partition_by = self.partition_by

		extension: str | Unset = UNSET
		if not isinstance(self.extension, Unset):
			extension = self.extension.value

		transparent = self.transparent

		window_size = self.window_size

		null_values: list[str] | None | Unset
		if isinstance(self.null_values, Unset):
			null_values = UNSET
		elif isinstance(self.null_values, list):
			null_values = self.null_values

		else:
			null_values = self.null_values

		dpi = self.dpi

		font: str | Unset = UNSET
		if not isinstance(self.font, Unset):
			font = self.font.value

		language: str | Unset = UNSET
		if not isinstance(self.language, Unset):
			language = self.language.value

		palette: dict[str, Any] | None | Unset
		if isinstance(self.palette, Unset):
			palette = UNSET
		elif isinstance(self.palette, ColorPalette):
			palette = self.palette.to_dict()
		else:
			palette = self.palette

		extra_palette: list[str] | None | Unset
		if isinstance(self.extra_palette, Unset):
			extra_palette = UNSET
		elif isinstance(self.extra_palette, list):
			extra_palette = self.extra_palette

		else:
			extra_palette = self.extra_palette

		field_dict: dict[str, Any] = {}
		field_dict.update(self.additional_properties)
		field_dict.update(
			{
				"file": file,
			}
		)
		if partition_by is not UNSET:
			field_dict["partition_by"] = partition_by
		if extension is not UNSET:
			field_dict["extension"] = extension
		if transparent is not UNSET:
			field_dict["transparent"] = transparent
		if window_size is not UNSET:
			field_dict["window_size"] = window_size
		if null_values is not UNSET:
			field_dict["null_values"] = null_values
		if dpi is not UNSET:
			field_dict["dpi"] = dpi
		if font is not UNSET:
			field_dict["font"] = font
		if language is not UNSET:
			field_dict["language"] = language
		if palette is not UNSET:
			field_dict["palette"] = palette
		if extra_palette is not UNSET:
			field_dict["extra_palette"] = extra_palette

		return field_dict

	def to_multipart(self) -> types.RequestFiles:
		from ..models.color_palette import ColorPalette

		files: types.RequestFiles = []

		files.append(("file", self.file.to_tuple()))

		if not isinstance(self.partition_by, Unset):
			if isinstance(self.partition_by, list):
				for partition_by_type_0_item_element in self.partition_by:
					files.append(
						(
							"partition_by",
							(
								None,
								str(partition_by_type_0_item_element).encode(),
								"text/plain",
							),
						)
					)
			else:
				files.append(
					(
						"partition_by",
						(None, str(self.partition_by).encode(), "text/plain"),
					)
				)

		if not isinstance(self.extension, Unset):
			files.append(
				("extension", (None, str(self.extension.value).encode(), "text/plain"))
			)

		if not isinstance(self.transparent, Unset):
			files.append(
				("transparent", (None, str(self.transparent).encode(), "text/plain"))
			)

		if not isinstance(self.window_size, Unset):
			files.append(
				("window_size", (None, str(self.window_size).encode(), "text/plain"))
			)

		if not isinstance(self.null_values, Unset):
			if isinstance(self.null_values, list):
				for null_values_type_0_item_element in self.null_values:
					files.append(
						(
							"null_values",
							(
								None,
								str(null_values_type_0_item_element).encode(),
								"text/plain",
							),
						)
					)
			else:
				files.append(
					(
						"null_values",
						(None, str(self.null_values).encode(), "text/plain"),
					)
				)

		if not isinstance(self.dpi, Unset):
			files.append(("dpi", (None, str(self.dpi).encode(), "text/plain")))

		if not isinstance(self.font, Unset):
			files.append(("font", (None, str(self.font.value).encode(), "text/plain")))

		if not isinstance(self.language, Unset):
			files.append(
				("language", (None, str(self.language.value).encode(), "text/plain"))
			)

		if not isinstance(self.palette, Unset):
			if isinstance(self.palette, ColorPalette):
				files.append(
					(
						"palette",
						(
							None,
							json.dumps(self.palette.to_dict()).encode(),
							"application/json",
						),
					)
				)
			else:
				files.append(
					("palette", (None, str(self.palette).encode(), "text/plain"))
				)

		if not isinstance(self.extra_palette, Unset):
			if isinstance(self.extra_palette, list):
				for extra_palette_type_0_item_element in self.extra_palette:
					files.append(
						(
							"extra_palette",
							(
								None,
								str(extra_palette_type_0_item_element).encode(),
								"text/plain",
							),
						)
					)
			else:
				files.append(
					(
						"extra_palette",
						(None, str(self.extra_palette).encode(), "text/plain"),
					)
				)

		for prop_name, prop in self.additional_properties.items():
			files.append((prop_name, (None, str(prop).encode(), "text/plain")))

		return files

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		from ..models.color_palette import ColorPalette

		d = dict(src_dict)
		file = File(payload=BytesIO(d.pop("file")))

		def _parse_partition_by(data: object) -> list[str] | None | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			try:
				if not isinstance(data, list):
					raise TypeError()
				partition_by_type_0 = cast(list[str], data)

				return partition_by_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(list[str] | None | Unset, data)

		partition_by = _parse_partition_by(d.pop("partition_by", UNSET))

		_extension = d.pop("extension", UNSET)
		extension: BodyEndpointGenerateGraphsGraphsPostExtension | Unset
		if isinstance(_extension, Unset):
			extension = UNSET
		else:
			extension = BodyEndpointGenerateGraphsGraphsPostExtension(_extension)

		transparent = d.pop("transparent", UNSET)

		window_size = d.pop("window_size", UNSET)

		def _parse_null_values(data: object) -> list[str] | None | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			try:
				if not isinstance(data, list):
					raise TypeError()
				null_values_type_0 = cast(list[str], data)

				return null_values_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(list[str] | None | Unset, data)

		null_values = _parse_null_values(d.pop("null_values", UNSET))

		dpi = d.pop("dpi", UNSET)

		_font = d.pop("font", UNSET)
		font: FontFamily | Unset
		if isinstance(_font, Unset):
			font = UNSET
		else:
			font = FontFamily(_font)

		_language = d.pop("language", UNSET)
		language: Language | Unset
		if isinstance(_language, Unset):
			language = UNSET
		else:
			language = Language(_language)

		def _parse_palette(data: object) -> ColorPalette | None | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			try:
				if not isinstance(data, dict):
					raise TypeError()
				palette_type_0 = ColorPalette.from_dict(data)

				return palette_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(ColorPalette | None | Unset, data)

		palette = _parse_palette(d.pop("palette", UNSET))

		def _parse_extra_palette(data: object) -> list[str] | None | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			try:
				if not isinstance(data, list):
					raise TypeError()
				extra_palette_type_0 = cast(list[str], data)

				return extra_palette_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(list[str] | None | Unset, data)

		extra_palette = _parse_extra_palette(d.pop("extra_palette", UNSET))

		body_endpoint_generate_graphs_graphs_post = cls(
			file=file,
			partition_by=partition_by,
			extension=extension,
			transparent=transparent,
			window_size=window_size,
			null_values=null_values,
			dpi=dpi,
			font=font,
			language=language,
			palette=palette,
			extra_palette=extra_palette,
		)

		body_endpoint_generate_graphs_graphs_post.additional_properties = d
		return body_endpoint_generate_graphs_graphs_post

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> Any:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: Any) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
