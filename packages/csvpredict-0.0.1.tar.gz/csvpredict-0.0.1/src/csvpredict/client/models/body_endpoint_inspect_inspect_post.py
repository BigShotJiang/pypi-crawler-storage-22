from __future__ import annotations

from collections.abc import Mapping
from io import BytesIO
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, File, Unset

T = TypeVar("T", bound="BodyEndpointInspectInspectPost")


@_attrs_define
class BodyEndpointInspectInspectPost:
	"""
	Attributes:
	    file (File):
	    partition_by (list[str] | None | Unset):
	    window_size (int | Unset):  Default: 5.
	    round_ (int | Unset):  Default: 2.
	    null_values (list[str] | None | Unset):
	"""

	file: File
	partition_by: list[str] | None | Unset = UNSET
	window_size: int | Unset = 5
	round_: int | Unset = 2
	null_values: list[str] | None | Unset = UNSET
	additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

	def to_dict(self) -> dict[str, Any]:
		file = self.file.to_tuple()

		partition_by: list[str] | None | Unset
		if isinstance(self.partition_by, Unset):
			partition_by = UNSET
		elif isinstance(self.partition_by, list):
			partition_by = self.partition_by

		else:
			partition_by = self.partition_by

		window_size = self.window_size

		round_ = self.round_

		null_values: list[str] | None | Unset
		if isinstance(self.null_values, Unset):
			null_values = UNSET
		elif isinstance(self.null_values, list):
			null_values = self.null_values

		else:
			null_values = self.null_values

		field_dict: dict[str, Any] = {}
		field_dict.update(self.additional_properties)
		field_dict.update(
			{
				"file": file,
			}
		)
		if partition_by is not UNSET:
			field_dict["partition_by"] = partition_by
		if window_size is not UNSET:
			field_dict["window_size"] = window_size
		if round_ is not UNSET:
			field_dict["round"] = round_
		if null_values is not UNSET:
			field_dict["null_values"] = null_values

		return field_dict

	def to_multipart(self) -> types.RequestFiles:
		files: types.RequestFiles = []

		files.append(("file", self.file.to_tuple()))

		if not isinstance(self.partition_by, Unset):
			if isinstance(self.partition_by, list):
				for partition_by_type_0_item_element in self.partition_by:
					files.append(
						(
							"partition_by",
							(
								None,
								str(partition_by_type_0_item_element).encode(),
								"text/plain",
							),
						)
					)
			else:
				files.append(
					(
						"partition_by",
						(None, str(self.partition_by).encode(), "text/plain"),
					)
				)

		if not isinstance(self.window_size, Unset):
			files.append(
				("window_size", (None, str(self.window_size).encode(), "text/plain"))
			)

		if not isinstance(self.round_, Unset):
			files.append(("round", (None, str(self.round_).encode(), "text/plain")))

		if not isinstance(self.null_values, Unset):
			if isinstance(self.null_values, list):
				for null_values_type_0_item_element in self.null_values:
					files.append(
						(
							"null_values",
							(
								None,
								str(null_values_type_0_item_element).encode(),
								"text/plain",
							),
						)
					)
			else:
				files.append(
					(
						"null_values",
						(None, str(self.null_values).encode(), "text/plain"),
					)
				)

		for prop_name, prop in self.additional_properties.items():
			files.append((prop_name, (None, str(prop).encode(), "text/plain")))

		return files

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		d = dict(src_dict)
		file = File(payload=BytesIO(d.pop("file")))

		def _parse_partition_by(data: object) -> list[str] | None | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			try:
				if not isinstance(data, list):
					raise TypeError()
				partition_by_type_0 = cast(list[str], data)

				return partition_by_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(list[str] | None | Unset, data)

		partition_by = _parse_partition_by(d.pop("partition_by", UNSET))

		window_size = d.pop("window_size", UNSET)

		round_ = d.pop("round", UNSET)

		def _parse_null_values(data: object) -> list[str] | None | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			try:
				if not isinstance(data, list):
					raise TypeError()
				null_values_type_0 = cast(list[str], data)

				return null_values_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(list[str] | None | Unset, data)

		null_values = _parse_null_values(d.pop("null_values", UNSET))

		body_endpoint_inspect_inspect_post = cls(
			file=file,
			partition_by=partition_by,
			window_size=window_size,
			round_=round_,
			null_values=null_values,
		)

		body_endpoint_inspect_inspect_post.additional_properties = d
		return body_endpoint_inspect_inspect_post

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> Any:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: Any) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
