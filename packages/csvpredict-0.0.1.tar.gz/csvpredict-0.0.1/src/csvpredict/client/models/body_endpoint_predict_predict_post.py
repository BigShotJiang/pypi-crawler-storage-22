from __future__ import annotations

import json
from collections.abc import Mapping
from io import BytesIO
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..models.frequency import Frequency
from ..types import UNSET, File, Unset

if TYPE_CHECKING:
	from ..models.body_endpoint_predict_predict_post_custom_seasonality_type_0 import (
		BodyEndpointPredictPredictPostCustomSeasonalityType0,
	)


T = TypeVar("T", bound="BodyEndpointPredictPredictPost")


@_attrs_define
class BodyEndpointPredictPredictPost:
	"""
	Attributes:
	    file (File):
	    num_periods (int):
	    timestamp_col (None | str | Unset):
	    value_col (None | str | Unset):
	    frequency (Frequency | None | Unset):
	    country (None | str | Unset):
	    custom_seasonality (BodyEndpointPredictPredictPostCustomSeasonalityType0 | None | Unset):
	    use_frequency_as_regressor (bool | Unset):  Default: False.
	    window_size (int | Unset):  Default: 5.
	    max_zscore (float | Unset):  Default: 3.0.
	"""

	file: File
	num_periods: int
	timestamp_col: None | str | Unset = UNSET
	value_col: None | str | Unset = UNSET
	frequency: Frequency | None | Unset = UNSET
	country: None | str | Unset = UNSET
	custom_seasonality: (
		BodyEndpointPredictPredictPostCustomSeasonalityType0 | None | Unset
	) = UNSET
	use_frequency_as_regressor: bool | Unset = False
	window_size: int | Unset = 5
	max_zscore: float | Unset = 3.0
	additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

	def to_dict(self) -> dict[str, Any]:
		from ..models.body_endpoint_predict_predict_post_custom_seasonality_type_0 import (
			BodyEndpointPredictPredictPostCustomSeasonalityType0,
		)

		file = self.file.to_tuple()

		num_periods = self.num_periods

		timestamp_col: None | str | Unset
		if isinstance(self.timestamp_col, Unset):
			timestamp_col = UNSET
		else:
			timestamp_col = self.timestamp_col

		value_col: None | str | Unset
		if isinstance(self.value_col, Unset):
			value_col = UNSET
		else:
			value_col = self.value_col

		frequency: None | str | Unset
		if isinstance(self.frequency, Unset):
			frequency = UNSET
		elif isinstance(self.frequency, Frequency):
			frequency = self.frequency.value
		else:
			frequency = self.frequency

		country: None | str | Unset
		if isinstance(self.country, Unset):
			country = UNSET
		else:
			country = self.country

		custom_seasonality: dict[str, Any] | None | Unset
		if isinstance(self.custom_seasonality, Unset):
			custom_seasonality = UNSET
		elif isinstance(
			self.custom_seasonality,
			BodyEndpointPredictPredictPostCustomSeasonalityType0,
		):
			custom_seasonality = self.custom_seasonality.to_dict()
		else:
			custom_seasonality = self.custom_seasonality

		use_frequency_as_regressor = self.use_frequency_as_regressor

		window_size = self.window_size

		max_zscore = self.max_zscore

		field_dict: dict[str, Any] = {}
		field_dict.update(self.additional_properties)
		field_dict.update(
			{
				"file": file,
				"num_periods": num_periods,
			}
		)
		if timestamp_col is not UNSET:
			field_dict["timestamp_col"] = timestamp_col
		if value_col is not UNSET:
			field_dict["value_col"] = value_col
		if frequency is not UNSET:
			field_dict["frequency"] = frequency
		if country is not UNSET:
			field_dict["country"] = country
		if custom_seasonality is not UNSET:
			field_dict["custom_seasonality"] = custom_seasonality
		if use_frequency_as_regressor is not UNSET:
			field_dict["use_frequency_as_regressor"] = use_frequency_as_regressor
		if window_size is not UNSET:
			field_dict["window_size"] = window_size
		if max_zscore is not UNSET:
			field_dict["max_zscore"] = max_zscore

		return field_dict

	def to_multipart(self) -> types.RequestFiles:
		from ..models.body_endpoint_predict_predict_post_custom_seasonality_type_0 import (
			BodyEndpointPredictPredictPostCustomSeasonalityType0,
		)

		files: types.RequestFiles = []

		files.append(("file", self.file.to_tuple()))

		files.append(
			("num_periods", (None, str(self.num_periods).encode(), "text/plain"))
		)

		if not isinstance(self.timestamp_col, Unset):
			if isinstance(self.timestamp_col, str):
				files.append(
					(
						"timestamp_col",
						(None, str(self.timestamp_col).encode(), "text/plain"),
					)
				)
			else:
				files.append(
					(
						"timestamp_col",
						(None, str(self.timestamp_col).encode(), "text/plain"),
					)
				)

		if not isinstance(self.value_col, Unset):
			if isinstance(self.value_col, str):
				files.append(
					("value_col", (None, str(self.value_col).encode(), "text/plain"))
				)
			else:
				files.append(
					("value_col", (None, str(self.value_col).encode(), "text/plain"))
				)

		if not isinstance(self.frequency, Unset):
			if isinstance(self.frequency, Frequency):
				files.append(
					(
						"frequency",
						(None, str(self.frequency.value).encode(), "text/plain"),
					)
				)
			else:
				files.append(
					("frequency", (None, str(self.frequency).encode(), "text/plain"))
				)

		if not isinstance(self.country, Unset):
			if isinstance(self.country, str):
				files.append(
					("country", (None, str(self.country).encode(), "text/plain"))
				)
			else:
				files.append(
					("country", (None, str(self.country).encode(), "text/plain"))
				)

		if not isinstance(self.custom_seasonality, Unset):
			if isinstance(
				self.custom_seasonality,
				BodyEndpointPredictPredictPostCustomSeasonalityType0,
			):
				files.append(
					(
						"custom_seasonality",
						(
							None,
							json.dumps(self.custom_seasonality.to_dict()).encode(),
							"application/json",
						),
					)
				)
			else:
				files.append(
					(
						"custom_seasonality",
						(None, str(self.custom_seasonality).encode(), "text/plain"),
					)
				)

		if not isinstance(self.use_frequency_as_regressor, Unset):
			files.append(
				(
					"use_frequency_as_regressor",
					(None, str(self.use_frequency_as_regressor).encode(), "text/plain"),
				)
			)

		if not isinstance(self.window_size, Unset):
			files.append(
				("window_size", (None, str(self.window_size).encode(), "text/plain"))
			)

		if not isinstance(self.max_zscore, Unset):
			files.append(
				("max_zscore", (None, str(self.max_zscore).encode(), "text/plain"))
			)

		for prop_name, prop in self.additional_properties.items():
			files.append((prop_name, (None, str(prop).encode(), "text/plain")))

		return files

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		from ..models.body_endpoint_predict_predict_post_custom_seasonality_type_0 import (
			BodyEndpointPredictPredictPostCustomSeasonalityType0,
		)

		d = dict(src_dict)
		file = File(payload=BytesIO(d.pop("file")))

		num_periods = d.pop("num_periods")

		def _parse_timestamp_col(data: object) -> None | str | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			return cast(None | str | Unset, data)

		timestamp_col = _parse_timestamp_col(d.pop("timestamp_col", UNSET))

		def _parse_value_col(data: object) -> None | str | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			return cast(None | str | Unset, data)

		value_col = _parse_value_col(d.pop("value_col", UNSET))

		def _parse_frequency(data: object) -> Frequency | None | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			try:
				if not isinstance(data, str):
					raise TypeError()
				frequency_type_0 = Frequency(data)

				return frequency_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(Frequency | None | Unset, data)

		frequency = _parse_frequency(d.pop("frequency", UNSET))

		def _parse_country(data: object) -> None | str | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			return cast(None | str | Unset, data)

		country = _parse_country(d.pop("country", UNSET))

		def _parse_custom_seasonality(
			data: object,
		) -> BodyEndpointPredictPredictPostCustomSeasonalityType0 | None | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			try:
				if not isinstance(data, dict):
					raise TypeError()
				custom_seasonality_type_0 = (
					BodyEndpointPredictPredictPostCustomSeasonalityType0.from_dict(data)
				)

				return custom_seasonality_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(
				BodyEndpointPredictPredictPostCustomSeasonalityType0 | None | Unset,
				data,
			)

		custom_seasonality = _parse_custom_seasonality(
			d.pop("custom_seasonality", UNSET)
		)

		use_frequency_as_regressor = d.pop("use_frequency_as_regressor", UNSET)

		window_size = d.pop("window_size", UNSET)

		max_zscore = d.pop("max_zscore", UNSET)

		body_endpoint_predict_predict_post = cls(
			file=file,
			num_periods=num_periods,
			timestamp_col=timestamp_col,
			value_col=value_col,
			frequency=frequency,
			country=country,
			custom_seasonality=custom_seasonality,
			use_frequency_as_regressor=use_frequency_as_regressor,
			window_size=window_size,
			max_zscore=max_zscore,
		)

		body_endpoint_predict_predict_post.additional_properties = d
		return body_endpoint_predict_predict_post

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> Any:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: Any) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
