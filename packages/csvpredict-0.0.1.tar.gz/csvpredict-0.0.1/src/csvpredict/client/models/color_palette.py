from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ColorPalette")


@_attrs_define
class ColorPalette:
	"""Color palette configuration for charts and reports.

	Args:
	        primary (str): Primary brand color.
	        secondary (str): Secondary color for contrast.
	        accent (str): Accent color for highlights.
	        background (str): Background color.
	        surface (str): Surface/card color.
	        text (str): Primary text color.
	        text_light (str): Secondary/muted text color.
	        border (str): Border color.
	        success (str): Success/positive indicator color.
	        warning (str): Warning indicator color.
	        error (str): Error/negative indicator color.
	        info (str): Info indicator color.

	    Attributes:
	        primary (str):
	        secondary (str):
	        accent (str):
	        background (str):
	        surface (str):
	        text (str):
	        text_light (str):
	        border (str):
	        success (str):
	        warning (str):
	        error (str):
	        info (str):
	"""

	primary: str
	secondary: str
	accent: str
	background: str
	surface: str
	text: str
	text_light: str
	border: str
	success: str
	warning: str
	error: str
	info: str
	additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

	def to_dict(self) -> dict[str, Any]:
		primary = self.primary

		secondary = self.secondary

		accent = self.accent

		background = self.background

		surface = self.surface

		text = self.text

		text_light = self.text_light

		border = self.border

		success = self.success

		warning = self.warning

		error = self.error

		info = self.info

		field_dict: dict[str, Any] = {}
		field_dict.update(self.additional_properties)
		field_dict.update(
			{
				"primary": primary,
				"secondary": secondary,
				"accent": accent,
				"background": background,
				"surface": surface,
				"text": text,
				"text_light": text_light,
				"border": border,
				"success": success,
				"warning": warning,
				"error": error,
				"info": info,
			}
		)

		return field_dict

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		d = dict(src_dict)
		primary = d.pop("primary")

		secondary = d.pop("secondary")

		accent = d.pop("accent")

		background = d.pop("background")

		surface = d.pop("surface")

		text = d.pop("text")

		text_light = d.pop("text_light")

		border = d.pop("border")

		success = d.pop("success")

		warning = d.pop("warning")

		error = d.pop("error")

		info = d.pop("info")

		color_palette = cls(
			primary=primary,
			secondary=secondary,
			accent=accent,
			background=background,
			surface=surface,
			text=text,
			text_light=text_light,
			border=border,
			success=success,
			warning=warning,
			error=error,
			info=info,
		)

		color_palette.additional_properties = d
		return color_palette

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> Any:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: Any) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
