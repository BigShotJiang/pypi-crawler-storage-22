from enum import Enum


class FontFamily(str, Enum):
	ARIAL = "arial"
	DEJAVU = "dejavu"
	GEORGIA = "georgia"
	HELVETICA = "helvetica"
	INTER = "inter"
	OPEN_SANS = "open-sans"
	ROBOTO = "roboto"
	TIMES = "times"
	TREBUCHET = "trebuchet"
	VERDANA = "verdana"

	def __str__(self) -> str:
		return str(self.value)
