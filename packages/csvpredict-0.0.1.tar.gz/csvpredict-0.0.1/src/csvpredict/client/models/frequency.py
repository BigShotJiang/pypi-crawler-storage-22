from enum import Enum


class Frequency(str, Enum):
	D = "D"
	H = "H"
	MS = "MS"
	UNKNOWN = "unknown"
	Y = "Y"

	def __str__(self) -> str:
		return str(self.value)
