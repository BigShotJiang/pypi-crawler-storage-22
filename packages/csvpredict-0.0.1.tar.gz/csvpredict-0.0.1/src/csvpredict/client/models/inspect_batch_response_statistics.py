from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
	from ..models.file_statistics import FileStatistics


T = TypeVar("T", bound="InspectBatchResponseStatistics")


@_attrs_define
class InspectBatchResponseStatistics:
	""" """

	additional_properties: dict[str, FileStatistics | None] = _attrs_field(
		init=False, factory=dict
	)

	def to_dict(self) -> dict[str, Any]:
		from ..models.file_statistics import FileStatistics

		field_dict: dict[str, Any] = {}
		for prop_name, prop in self.additional_properties.items():
			if isinstance(prop, FileStatistics):
				field_dict[prop_name] = prop.to_dict()
			else:
				field_dict[prop_name] = prop

		return field_dict

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		from ..models.file_statistics import FileStatistics

		d = dict(src_dict)
		inspect_batch_response_statistics = cls()

		additional_properties = {}
		for prop_name, prop_dict in d.items():

			def _parse_additional_property(data: object) -> FileStatistics | None:
				if data is None:
					return data
				try:
					if not isinstance(data, dict):
						raise TypeError()
					additional_property_type_0 = FileStatistics.from_dict(data)

					return additional_property_type_0
				except (TypeError, ValueError, AttributeError, KeyError):
					pass
				return cast(FileStatistics | None, data)

			additional_property = _parse_additional_property(prop_dict)

			additional_properties[prop_name] = additional_property

		inspect_batch_response_statistics.additional_properties = additional_properties
		return inspect_batch_response_statistics

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> FileStatistics | None:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: FileStatistics | None) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
