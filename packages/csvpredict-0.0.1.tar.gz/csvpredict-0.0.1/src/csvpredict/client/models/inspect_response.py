from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
	from ..models.inspect_response_partitioned_statistics_type_0 import (
		InspectResponsePartitionedStatisticsType0,
	)
	from ..models.statistics import Statistics


T = TypeVar("T", bound="InspectResponse")


@_attrs_define
class InspectResponse:
	"""
	Attributes:
	    partitioned_statistics (InspectResponsePartitionedStatisticsType0 | None | Unset):
	    non_partitioned_statistics (None | Statistics | Unset):
	"""

	partitioned_statistics: InspectResponsePartitionedStatisticsType0 | None | Unset = (
		UNSET
	)
	non_partitioned_statistics: None | Statistics | Unset = UNSET
	additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

	def to_dict(self) -> dict[str, Any]:
		from ..models.inspect_response_partitioned_statistics_type_0 import (
			InspectResponsePartitionedStatisticsType0,
		)
		from ..models.statistics import Statistics

		partitioned_statistics: dict[str, Any] | None | Unset
		if isinstance(self.partitioned_statistics, Unset):
			partitioned_statistics = UNSET
		elif isinstance(
			self.partitioned_statistics, InspectResponsePartitionedStatisticsType0
		):
			partitioned_statistics = self.partitioned_statistics.to_dict()
		else:
			partitioned_statistics = self.partitioned_statistics

		non_partitioned_statistics: dict[str, Any] | None | Unset
		if isinstance(self.non_partitioned_statistics, Unset):
			non_partitioned_statistics = UNSET
		elif isinstance(self.non_partitioned_statistics, Statistics):
			non_partitioned_statistics = self.non_partitioned_statistics.to_dict()
		else:
			non_partitioned_statistics = self.non_partitioned_statistics

		field_dict: dict[str, Any] = {}
		field_dict.update(self.additional_properties)
		field_dict.update({})
		if partitioned_statistics is not UNSET:
			field_dict["partitioned_statistics"] = partitioned_statistics
		if non_partitioned_statistics is not UNSET:
			field_dict["non_partitioned_statistics"] = non_partitioned_statistics

		return field_dict

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		from ..models.inspect_response_partitioned_statistics_type_0 import (
			InspectResponsePartitionedStatisticsType0,
		)
		from ..models.statistics import Statistics

		d = dict(src_dict)

		def _parse_partitioned_statistics(
			data: object,
		) -> InspectResponsePartitionedStatisticsType0 | None | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			try:
				if not isinstance(data, dict):
					raise TypeError()
				partitioned_statistics_type_0 = (
					InspectResponsePartitionedStatisticsType0.from_dict(data)
				)

				return partitioned_statistics_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(InspectResponsePartitionedStatisticsType0 | None | Unset, data)

		partitioned_statistics = _parse_partitioned_statistics(
			d.pop("partitioned_statistics", UNSET)
		)

		def _parse_non_partitioned_statistics(
			data: object,
		) -> None | Statistics | Unset:
			if data is None:
				return data
			if isinstance(data, Unset):
				return data
			try:
				if not isinstance(data, dict):
					raise TypeError()
				non_partitioned_statistics_type_0 = Statistics.from_dict(data)

				return non_partitioned_statistics_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(None | Statistics | Unset, data)

		non_partitioned_statistics = _parse_non_partitioned_statistics(
			d.pop("non_partitioned_statistics", UNSET)
		)

		inspect_response = cls(
			partitioned_statistics=partitioned_statistics,
			non_partitioned_statistics=non_partitioned_statistics,
		)

		inspect_response.additional_properties = d
		return inspect_response

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> Any:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: Any) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
