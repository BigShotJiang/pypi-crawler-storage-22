from enum import Enum


class Language(str, Enum):
	DE = "de"
	EN = "en"
	ES = "es"
	FR = "fr"
	JA = "ja"
	RU = "ru"
	ZH = "zh"

	def __str__(self) -> str:
		return str(self.value)
