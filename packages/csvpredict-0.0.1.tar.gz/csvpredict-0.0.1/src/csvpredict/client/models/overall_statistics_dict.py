from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="OverallStatisticsDict")


@_attrs_define
class OverallStatisticsDict:
	"""
	Attributes:
	    height (int | None):
	    width (int | None):
	    column_names (list[str] | None):
	    null_count (int | None):
	    duplicate_count (int | None):
	    unique_count (int | None):
	    timestamp_column (None | str):
	"""

	height: int | None
	width: int | None
	column_names: list[str] | None
	null_count: int | None
	duplicate_count: int | None
	unique_count: int | None
	timestamp_column: None | str
	additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

	def to_dict(self) -> dict[str, Any]:
		height: int | None
		height = self.height

		width: int | None
		width = self.width

		column_names: list[str] | None
		if isinstance(self.column_names, list):
			column_names = self.column_names

		else:
			column_names = self.column_names

		null_count: int | None
		null_count = self.null_count

		duplicate_count: int | None
		duplicate_count = self.duplicate_count

		unique_count: int | None
		unique_count = self.unique_count

		timestamp_column: None | str
		timestamp_column = self.timestamp_column

		field_dict: dict[str, Any] = {}
		field_dict.update(self.additional_properties)
		field_dict.update(
			{
				"height": height,
				"width": width,
				"column_names": column_names,
				"null_count": null_count,
				"duplicate_count": duplicate_count,
				"unique_count": unique_count,
				"timestamp_column": timestamp_column,
			}
		)

		return field_dict

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		d = dict(src_dict)

		def _parse_height(data: object) -> int | None:
			if data is None:
				return data
			return cast(int | None, data)

		height = _parse_height(d.pop("height"))

		def _parse_width(data: object) -> int | None:
			if data is None:
				return data
			return cast(int | None, data)

		width = _parse_width(d.pop("width"))

		def _parse_column_names(data: object) -> list[str] | None:
			if data is None:
				return data
			try:
				if not isinstance(data, list):
					raise TypeError()
				column_names_type_0 = cast(list[str], data)

				return column_names_type_0
			except (TypeError, ValueError, AttributeError, KeyError):
				pass
			return cast(list[str] | None, data)

		column_names = _parse_column_names(d.pop("column_names"))

		def _parse_null_count(data: object) -> int | None:
			if data is None:
				return data
			return cast(int | None, data)

		null_count = _parse_null_count(d.pop("null_count"))

		def _parse_duplicate_count(data: object) -> int | None:
			if data is None:
				return data
			return cast(int | None, data)

		duplicate_count = _parse_duplicate_count(d.pop("duplicate_count"))

		def _parse_unique_count(data: object) -> int | None:
			if data is None:
				return data
			return cast(int | None, data)

		unique_count = _parse_unique_count(d.pop("unique_count"))

		def _parse_timestamp_column(data: object) -> None | str:
			if data is None:
				return data
			return cast(None | str, data)

		timestamp_column = _parse_timestamp_column(d.pop("timestamp_column"))

		overall_statistics_dict = cls(
			height=height,
			width=width,
			column_names=column_names,
			null_count=null_count,
			duplicate_count=duplicate_count,
			unique_count=unique_count,
			timestamp_column=timestamp_column,
		)

		overall_statistics_dict.additional_properties = d
		return overall_statistics_dict

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> Any:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: Any) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
