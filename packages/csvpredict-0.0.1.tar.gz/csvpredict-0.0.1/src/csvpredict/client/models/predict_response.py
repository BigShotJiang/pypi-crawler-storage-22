from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
	from ..models.predict_response_historical_data_item import (
		PredictResponseHistoricalDataItem,
	)
	from ..models.predict_response_predictions_item import (
		PredictResponsePredictionsItem,
	)


T = TypeVar("T", bound="PredictResponse")


@_attrs_define
class PredictResponse:
	"""
	Attributes:
	    historical_data (list[PredictResponseHistoricalDataItem]):
	    predictions (list[PredictResponsePredictionsItem]):
	    score (float):
	"""

	historical_data: list[PredictResponseHistoricalDataItem]
	predictions: list[PredictResponsePredictionsItem]
	score: float
	additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

	def to_dict(self) -> dict[str, Any]:
		historical_data = []
		for historical_data_item_data in self.historical_data:
			historical_data_item = historical_data_item_data.to_dict()
			historical_data.append(historical_data_item)

		predictions = []
		for predictions_item_data in self.predictions:
			predictions_item = predictions_item_data.to_dict()
			predictions.append(predictions_item)

		score = self.score

		field_dict: dict[str, Any] = {}
		field_dict.update(self.additional_properties)
		field_dict.update(
			{
				"historical_data": historical_data,
				"predictions": predictions,
				"score": score,
			}
		)

		return field_dict

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		from ..models.predict_response_historical_data_item import (
			PredictResponseHistoricalDataItem,
		)
		from ..models.predict_response_predictions_item import (
			PredictResponsePredictionsItem,
		)

		d = dict(src_dict)
		historical_data = []
		_historical_data = d.pop("historical_data")
		for historical_data_item_data in _historical_data:
			historical_data_item = PredictResponseHistoricalDataItem.from_dict(
				historical_data_item_data
			)

			historical_data.append(historical_data_item)

		predictions = []
		_predictions = d.pop("predictions")
		for predictions_item_data in _predictions:
			predictions_item = PredictResponsePredictionsItem.from_dict(
				predictions_item_data
			)

			predictions.append(predictions_item)

		score = d.pop("score")

		predict_response = cls(
			historical_data=historical_data,
			predictions=predictions,
			score=score,
		)

		predict_response.additional_properties = d
		return predict_response

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> Any:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: Any) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
