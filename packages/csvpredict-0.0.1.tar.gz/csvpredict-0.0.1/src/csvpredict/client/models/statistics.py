from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
	from ..models.overall_statistics_dict import OverallStatisticsDict
	from ..models.statistics_correlation_statistics import (
		StatisticsCorrelationStatistics,
	)
	from ..models.summary_statistics_dict import SummaryStatisticsDict


T = TypeVar("T", bound="Statistics")


@_attrs_define
class Statistics:
	"""
	Attributes:
	    overall_statistics (OverallStatisticsDict):
	    statistics (SummaryStatisticsDict):
	    correlation_statistics (StatisticsCorrelationStatistics):
	"""

	overall_statistics: OverallStatisticsDict
	statistics: SummaryStatisticsDict
	correlation_statistics: StatisticsCorrelationStatistics
	additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

	def to_dict(self) -> dict[str, Any]:
		overall_statistics = self.overall_statistics.to_dict()

		statistics = self.statistics.to_dict()

		correlation_statistics = self.correlation_statistics.to_dict()

		field_dict: dict[str, Any] = {}
		field_dict.update(self.additional_properties)
		field_dict.update(
			{
				"overall_statistics": overall_statistics,
				"statistics": statistics,
				"correlation_statistics": correlation_statistics,
			}
		)

		return field_dict

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		from ..models.overall_statistics_dict import OverallStatisticsDict
		from ..models.statistics_correlation_statistics import (
			StatisticsCorrelationStatistics,
		)
		from ..models.summary_statistics_dict import SummaryStatisticsDict

		d = dict(src_dict)
		overall_statistics = OverallStatisticsDict.from_dict(
			d.pop("overall_statistics")
		)

		statistics = SummaryStatisticsDict.from_dict(d.pop("statistics"))

		correlation_statistics = StatisticsCorrelationStatistics.from_dict(
			d.pop("correlation_statistics")
		)

		statistics = cls(
			overall_statistics=overall_statistics,
			statistics=statistics,
			correlation_statistics=correlation_statistics,
		)

		statistics.additional_properties = d
		return statistics

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> Any:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: Any) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
