from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
	from ..models.summary_statistics_dict_boolean import SummaryStatisticsDictBoolean
	from ..models.summary_statistics_dict_boolean_count import (
		SummaryStatisticsDictBooleanCount,
	)
	from ..models.summary_statistics_dict_datetime import SummaryStatisticsDictDatetime
	from ..models.summary_statistics_dict_datetime_count import (
		SummaryStatisticsDictDatetimeCount,
	)
	from ..models.summary_statistics_dict_duration import SummaryStatisticsDictDuration
	from ..models.summary_statistics_dict_duration_count import (
		SummaryStatisticsDictDurationCount,
	)
	from ..models.summary_statistics_dict_numeric import SummaryStatisticsDictNumeric
	from ..models.summary_statistics_dict_numeric_count import (
		SummaryStatisticsDictNumericCount,
	)
	from ..models.summary_statistics_dict_numeric_rolling import (
		SummaryStatisticsDictNumericRolling,
	)
	from ..models.summary_statistics_dict_string import SummaryStatisticsDictString
	from ..models.summary_statistics_dict_string_count import (
		SummaryStatisticsDictStringCount,
	)


T = TypeVar("T", bound="SummaryStatisticsDict")


@_attrs_define
class SummaryStatisticsDict:
	"""
	Attributes:
	    datetime_ (SummaryStatisticsDictDatetime):
	    datetime_count (SummaryStatisticsDictDatetimeCount):
	    numeric (SummaryStatisticsDictNumeric):
	    numeric_count (SummaryStatisticsDictNumericCount):
	    numeric_rolling (SummaryStatisticsDictNumericRolling):
	    duration (SummaryStatisticsDictDuration):
	    duration_count (SummaryStatisticsDictDurationCount):
	    string (SummaryStatisticsDictString):
	    string_count (SummaryStatisticsDictStringCount):
	    boolean (SummaryStatisticsDictBoolean):
	    boolean_count (SummaryStatisticsDictBooleanCount):
	"""

	datetime_: SummaryStatisticsDictDatetime
	datetime_count: SummaryStatisticsDictDatetimeCount
	numeric: SummaryStatisticsDictNumeric
	numeric_count: SummaryStatisticsDictNumericCount
	numeric_rolling: SummaryStatisticsDictNumericRolling
	duration: SummaryStatisticsDictDuration
	duration_count: SummaryStatisticsDictDurationCount
	string: SummaryStatisticsDictString
	string_count: SummaryStatisticsDictStringCount
	boolean: SummaryStatisticsDictBoolean
	boolean_count: SummaryStatisticsDictBooleanCount
	additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

	def to_dict(self) -> dict[str, Any]:
		datetime_ = self.datetime_.to_dict()

		datetime_count = self.datetime_count.to_dict()

		numeric = self.numeric.to_dict()

		numeric_count = self.numeric_count.to_dict()

		numeric_rolling = self.numeric_rolling.to_dict()

		duration = self.duration.to_dict()

		duration_count = self.duration_count.to_dict()

		string = self.string.to_dict()

		string_count = self.string_count.to_dict()

		boolean = self.boolean.to_dict()

		boolean_count = self.boolean_count.to_dict()

		field_dict: dict[str, Any] = {}
		field_dict.update(self.additional_properties)
		field_dict.update(
			{
				"datetime": datetime_,
				"datetime_count": datetime_count,
				"numeric": numeric,
				"numeric_count": numeric_count,
				"numeric_rolling": numeric_rolling,
				"duration": duration,
				"duration_count": duration_count,
				"string": string,
				"string_count": string_count,
				"boolean": boolean,
				"boolean_count": boolean_count,
			}
		)

		return field_dict

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		from ..models.summary_statistics_dict_boolean import (
			SummaryStatisticsDictBoolean,
		)
		from ..models.summary_statistics_dict_boolean_count import (
			SummaryStatisticsDictBooleanCount,
		)
		from ..models.summary_statistics_dict_datetime import (
			SummaryStatisticsDictDatetime,
		)
		from ..models.summary_statistics_dict_datetime_count import (
			SummaryStatisticsDictDatetimeCount,
		)
		from ..models.summary_statistics_dict_duration import (
			SummaryStatisticsDictDuration,
		)
		from ..models.summary_statistics_dict_duration_count import (
			SummaryStatisticsDictDurationCount,
		)
		from ..models.summary_statistics_dict_numeric import (
			SummaryStatisticsDictNumeric,
		)
		from ..models.summary_statistics_dict_numeric_count import (
			SummaryStatisticsDictNumericCount,
		)
		from ..models.summary_statistics_dict_numeric_rolling import (
			SummaryStatisticsDictNumericRolling,
		)
		from ..models.summary_statistics_dict_string import SummaryStatisticsDictString
		from ..models.summary_statistics_dict_string_count import (
			SummaryStatisticsDictStringCount,
		)

		d = dict(src_dict)
		datetime_ = SummaryStatisticsDictDatetime.from_dict(d.pop("datetime"))

		datetime_count = SummaryStatisticsDictDatetimeCount.from_dict(
			d.pop("datetime_count")
		)

		numeric = SummaryStatisticsDictNumeric.from_dict(d.pop("numeric"))

		numeric_count = SummaryStatisticsDictNumericCount.from_dict(
			d.pop("numeric_count")
		)

		numeric_rolling = SummaryStatisticsDictNumericRolling.from_dict(
			d.pop("numeric_rolling")
		)

		duration = SummaryStatisticsDictDuration.from_dict(d.pop("duration"))

		duration_count = SummaryStatisticsDictDurationCount.from_dict(
			d.pop("duration_count")
		)

		string = SummaryStatisticsDictString.from_dict(d.pop("string"))

		string_count = SummaryStatisticsDictStringCount.from_dict(d.pop("string_count"))

		boolean = SummaryStatisticsDictBoolean.from_dict(d.pop("boolean"))

		boolean_count = SummaryStatisticsDictBooleanCount.from_dict(
			d.pop("boolean_count")
		)

		summary_statistics_dict = cls(
			datetime_=datetime_,
			datetime_count=datetime_count,
			numeric=numeric,
			numeric_count=numeric_count,
			numeric_rolling=numeric_rolling,
			duration=duration,
			duration_count=duration_count,
			string=string,
			string_count=string_count,
			boolean=boolean,
			boolean_count=boolean_count,
		)

		summary_statistics_dict.additional_properties = d
		return summary_statistics_dict

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> Any:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: Any) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
