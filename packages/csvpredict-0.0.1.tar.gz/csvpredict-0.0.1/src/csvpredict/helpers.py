from typing import Any

import polars as pl


def dict_list_to_dataframe_(data: list[dict[str, Any]]) -> pl.DataFrame:
	"""Convert a list of dictionaries to a Polars DataFrame."""
	if not data:
		return pl.DataFrame()
	return pl.DataFrame(data)


def nested_dict_to_dataframes_(
	data: dict[str, list[dict[str, Any]]],
) -> dict[str, pl.DataFrame]:
	"""Convert nested dict of lists to dict of DataFrames."""
	return {col: dict_list_to_dataframe_(rows) for col, rows in data.items()}
