# ruff: noqa: E501
import base64
import json
import re
from typing import Any

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>csvpredict - Data Inspection</title>
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg width='32' height='32' viewBox='0 0 32 32' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M4 26 L8 23 L12 24.5 L16 19 L20 16 L24 12.5 L28 6 L28 28 L4 28 Z' fill='%2300dc82' fill-opacity='0.15'/%3E%3Cpolyline points='4,26 8,23 12,24.5 16,19 20,16 24,12.5 28,6' stroke='%2300dc82' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round' fill='none'/%3E%3Ccircle cx='4' cy='26' r='1.5' fill='%2300dc82'/%3E%3Ccircle cx='8' cy='23' r='1.5' fill='%2300dc82'/%3E%3Ccircle cx='12' cy='24.5' r='1.5' fill='%2300dc82'/%3E%3Ccircle cx='16' cy='19' r='1.5' fill='%2300dc82'/%3E%3Ccircle cx='20' cy='16' r='1.5' fill='%2300dc82'/%3E%3Ccircle cx='24' cy='12.5' r='1.5' fill='%2300dc82'/%3E%3Ccircle cx='28' cy='6' r='1.5' fill='%2300dc82'/%3E%3C/svg%3E">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom@2.0.1/dist/chartjs-plugin-zoom.min.js"></script>
    <style>
        :root {
            --bg-primary: #ffffff;
            --bg-secondary: #f9fafb;
            --bg-card: #ffffff;
            --bg-card-inner: #f9fafb;
            --text-primary: #111827;
            --text-secondary: #6b7280;
            --text-muted: #9ca3af;
            --border-color: #e5e7eb;
            --border-color-strong: #d1d5db;
            --primary-50: #f0fdf4;
            --primary-100: #dcfce7;
            --primary-500: #22c55e;
            --primary-600: #16a34a;
            --primary-700: #15803d;
            --info-50: #eff6ff;
            --info-500: #3b82f6;
            --warning-50: #fffbeb;
            --warning-500: #f59e0b;
            --error-50: #fef2f2;
            --error-500: #ef4444;
            --chart-grid: #e5e7eb;
        }
        
        .dark {
            --bg-primary: #0a0a0a;
            --bg-secondary: #141414;
            --bg-card: #18181b;
            --bg-card-inner: #27272a;
            --text-primary: #fafafa;
            --text-secondary: #a1a1aa;
            --text-muted: #71717a;
            --border-color: #27272a;
            --border-color-strong: #3f3f46;
            --primary-50: #052e16;
            --primary-100: #14532d;
            --chart-grid: #27272a;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1280px;
            margin: 0 auto;
            padding: 1.5rem 1rem;
        }
        
        @media (min-width: 640px) {
            .container { padding: 1.5rem; }
        }
        
        @media (min-width: 1024px) {
            .container { padding: 2rem; }
        }
        
        header {
            background: var(--bg-card);
            border-bottom: 1px solid var(--border-color);
            padding: 0.75rem 1.5rem;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header-content {
            max-width: 1280px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            display: flex;
            align-items: center;
        }
        
        .header-controls {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.75rem;
            color: var(--text-secondary);
            background: var(--bg-card-inner);
            padding: 0.375rem 0.75rem;
            border-radius: 9999px;
        }
        
        .status-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--primary-500);
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        .theme-toggle {
            background: var(--bg-card-inner);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 0.5rem;
            color: var(--text-secondary);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        
        .theme-toggle:hover {
            background: var(--border-color);
        }
        
        .theme-toggle svg {
            width: 18px;
            height: 18px;
        }
        
        /* Cards */
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.25rem;
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }
        
        .card-header svg {
            width: 20px;
            height: 20px;
            color: var(--primary-500);
        }
        
        .card-title {
            font-size: 1rem;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .card-description {
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }
        
        /* Overview Stats Grid */
        .overview-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
        }
        
        @media (min-width: 768px) {
            .overview-grid { grid-template-columns: repeat(3, 1fr); }
        }
        
        @media (min-width: 1024px) {
            .overview-grid { grid-template-columns: repeat(6, 1fr); }
        }
        
        .stat-card {
            background: var(--bg-card-inner);
            border-radius: 8px;
            padding: 0.75rem;
            text-align: center;
        }
        
        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-500);
        }
        
        .stat-value.warning {
            color: var(--warning-500);
        }
        
        .stat-value.success {
            color: var(--primary-500);
        }
        
        .stat-value.error {
            color: var(--error-500);
        }
        
        .stat-label {
            font-size: 0.75rem;
            color: var(--text-secondary);
            margin-top: 0.25rem;
        }
        
        /* Download Buttons */
        .download-buttons {
            display: flex;
            gap: 0.75rem;
            justify-content: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }
        
        .download-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.625rem 1rem;
            border-radius: 8px;
            font-size: 0.875rem;
            font-weight: 500;
            background: var(--primary-500);
            color: white;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }
        
        .download-btn:hover:not(:disabled) {
            background: var(--primary-600);
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .download-btn:active:not(:disabled) {
            transform: translateY(0);
        }
        
        .download-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .download-btn svg {
            width: 16px;
            height: 16px;
            flex-shrink: 0;
        }
        
        .download-btn.loading .download-btn-text {
            display: none;
        }
        
        .download-btn.loading .download-spinner {
            display: block;
        }
        
        .download-spinner {
            display: none;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* View Tabs */
        .view-tabs {
            display: flex;
            gap: 0.5rem;
            justify-content: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }
        
        .view-tab {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-size: 0.875rem;
            font-weight: 500;
            border: 1px solid var(--border-color);
            background: transparent;
            color: var(--text-secondary);
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .view-tab:hover {
            background: var(--bg-card-inner);
            color: var(--text-primary);
        }
        
        .view-tab.active {
            background: var(--primary-500);
            border-color: var(--primary-500);
            color: white;
        }
        
        .view-tab svg {
            width: 16px;
            height: 16px;
        }
        
        /* Column Tabs */
        .column-tabs {
            display: flex;
            gap: 0.25rem;
            flex-wrap: wrap;
            margin-bottom: 1rem;
            overflow-x: auto;
            padding-bottom: 0.25rem;
        }
        
        .column-tab {
            padding: 0.375rem 0.75rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 500;
            border: 1px solid var(--border-color);
            background: transparent;
            color: var(--text-secondary);
            cursor: pointer;
            transition: all 0.15s;
            white-space: nowrap;
        }
        
        .column-tab:hover {
            border-color: var(--primary-500);
            color: var(--text-primary);
        }
        
        .column-tab.active {
            background: var(--primary-50);
            border-color: var(--primary-500);
            color: var(--primary-700);
        }
        
        .dark .column-tab.active {
            background: var(--primary-100);
            color: var(--primary-500);
        }
        
        /* Partition Selector */
        .partition-selector {
            display: flex;
            gap: 0.5rem;
            justify-content: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            align-items: center;
        }
        
        .partition-label {
            font-size: 0.75rem;
            font-weight: 500;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .partition-btn {
            padding: 0.375rem 0.625rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 500;
            border: none;
            background: var(--bg-card-inner);
            color: var(--text-secondary);
            cursor: pointer;
            transition: all 0.15s;
        }
        
        .partition-btn:hover {
            background: var(--border-color);
            color: var(--text-primary);
        }
        
        .partition-btn.active {
            background: var(--bg-card-inner);
            color: var(--text-primary);
            box-shadow: 0 0 0 2px var(--primary-500);
        }
        
        /* Section */
        .section {
            margin-bottom: 1.5rem;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .section-title {
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .section-title svg {
            width: 18px;
            height: 18px;
            color: var(--primary-500);
        }
        
        /* Charts */
        .charts-grid {
            display: grid;
            gap: 1rem;
        }
        
        @media (min-width: 768px) {
            .charts-grid.two-col {
                grid-template-columns: 1fr 3fr;
            }
        }
        
        .chart-panel {
            background: var(--bg-card-inner);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1rem;
            overflow: hidden;
        }
        
        .chart-panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 0.75rem;
        }
        
        .chart-panel-title {
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .chart-panel-title svg {
            width: 16px;
            height: 16px;
            color: var(--primary-500);
        }
        
        .chart-wrapper {
            position: relative;
            height: 250px;
        }
        
        .chart-wrapper.tall {
            height: 320px;
        }
        
        .chart-wrapper.short {
            height: 180px;
        }
        
        /* Box Plot Summary */
        .boxplot-summary {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 0.5rem;
            margin-top: 1rem;
        }
        
        @media (min-width: 768px) {
            .boxplot-summary {
                grid-template-columns: repeat(6, 1fr);
            }
        }
        
        .boxplot-stat {
            background: var(--bg-card);
            border-radius: 8px;
            padding: 0.5rem;
            text-align: center;
            border: 1px solid var(--border-color);
        }
        
        .boxplot-stat.min { border-color: #93c5fd; }
        .boxplot-stat.q1 { border-color: #67e8f9; }
        .boxplot-stat.median { border-color: #86efac; }
        .boxplot-stat.mean { border-color: #fcd34d; }
        .boxplot-stat.q3 { border-color: #fdba74; }
        .boxplot-stat.max { border-color: #fca5a5; }
        
        .boxplot-stat-label {
            font-size: 0.625rem;
            font-weight: 600;
            text-transform: uppercase;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.25rem;
            margin-bottom: 0.125rem;
        }
        
        .boxplot-stat.min .boxplot-stat-label { color: #3b82f6; }
        .boxplot-stat.q1 .boxplot-stat-label { color: #06b6d4; }
        .boxplot-stat.median .boxplot-stat-label { color: #22c55e; }
        .boxplot-stat.mean .boxplot-stat-label { color: #f59e0b; }
        .boxplot-stat.q3 .boxplot-stat-label { color: #f97316; }
        .boxplot-stat.max .boxplot-stat-label { color: #ef4444; }
        
        .boxplot-stat-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
        }
        
        .boxplot-stat.min .boxplot-stat-dot { background: #3b82f6; }
        .boxplot-stat.q1 .boxplot-stat-dot { background: #06b6d4; }
        .boxplot-stat.median .boxplot-stat-dot { background: #22c55e; }
        .boxplot-stat.mean .boxplot-stat-dot { background: #f59e0b; }
        .boxplot-stat.q3 .boxplot-stat-dot { background: #f97316; }
        .boxplot-stat.max .boxplot-stat-dot { background: #ef4444; }
        
        .boxplot-stat-value {
            font-size: 0.75rem;
            font-weight: 700;
        }
        
        .boxplot-stat.min .boxplot-stat-value { color: #2563eb; }
        .boxplot-stat.q1 .boxplot-stat-value { color: #0891b2; }
        .boxplot-stat.median .boxplot-stat-value { color: #16a34a; }
        .boxplot-stat.mean .boxplot-stat-value { color: #d97706; }
        .boxplot-stat.q3 .boxplot-stat-value { color: #ea580c; }
        .boxplot-stat.max .boxplot-stat-value { color: #dc2626; }
        
        .dark .boxplot-stat.min .boxplot-stat-value { color: #93c5fd; }
        .dark .boxplot-stat.q1 .boxplot-stat-value { color: #67e8f9; }
        .dark .boxplot-stat.median .boxplot-stat-value { color: #86efac; }
        .dark .boxplot-stat.mean .boxplot-stat-value { color: #fcd34d; }
        .dark .boxplot-stat.q3 .boxplot-stat-value { color: #fdba74; }
        .dark .boxplot-stat.max .boxplot-stat-value { color: #fca5a5; }
        
        /* Statistics Table */
        .stats-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.875rem;
        }
        
        .stats-table th,
        .stats-table td {
            padding: 0.625rem 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        .stats-table th {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            background: var(--bg-card-inner);
        }
        
        .stats-table td {
            color: var(--text-secondary);
        }
        
        .stats-table tr:hover td {
            background: var(--bg-card-inner);
        }
        
        /* Correlation Matrix */
        .correlation-matrix {
            overflow-x: auto;
            background: var(--bg-card-inner);
            border-radius: 8px;
            padding: 1rem;
        }
        
        .correlation-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.75rem;
        }
        
        .correlation-table th {
            padding: 0.5rem;
            font-weight: 500;
            color: var(--text-secondary);
        }
        
        .correlation-table td {
            padding: 0;
            text-align: center;
        }
        
        .correlation-cell {
            padding: 0.5rem;
            font-weight: 500;
            min-width: 50px;
        }
        
        .correlation-cell.strong-positive { background: rgba(34, 197, 94, 0.8); color: white; }
        .correlation-cell.moderate-positive { background: rgba(34, 197, 94, 0.4); }
        .correlation-cell.weak { background: var(--bg-card); }
        .correlation-cell.moderate-negative { background: rgba(239, 68, 68, 0.4); }
        .correlation-cell.strong-negative { background: rgba(239, 68, 68, 0.8); color: white; }
        
        .correlation-legend {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-top: 1rem;
            font-size: 0.75rem;
            color: var(--text-secondary);
        }
        
        .correlation-legend-item {
            display: flex;
            align-items: center;
            gap: 0.375rem;
        }
        
        .correlation-legend-box {
            width: 16px;
            height: 16px;
            border-radius: 4px;
        }
        
        /* Column Badges */
        .columns-grid {
            display: grid;
            grid-template-columns: repeat(1, 1fr);
            gap: 1rem;
        }
        
        @media (min-width: 640px) {
            .columns-grid { grid-template-columns: repeat(2, 1fr); }
        }
        
        @media (min-width: 1024px) {
            .columns-grid { grid-template-columns: repeat(4, 1fr); }
        }
        
        .column-group-title {
            font-size: 0.75rem;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.375rem;
        }
        
        .column-group-title svg {
            width: 14px;
            height: 14px;
        }
        
        .badges-container {
            display: flex;
            flex-wrap: wrap;
            gap: 0.375rem;
        }
        
        .badge {
            font-size: 0.75rem;
            font-weight: 500;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
        }
        
        .badge.numeric {
            background: var(--primary-50);
            color: var(--primary-700);
        }
        
        .badge.datetime {
            background: var(--info-50);
            color: #1d4ed8;
        }
        
        .badge.string {
            background: var(--warning-50);
            color: #b45309;
        }
        
        .badge.duration {
            background: #f0fdf4;
            color: #15803d;
        }
        
        .dark .badge.numeric {
            background: rgba(34, 197, 94, 0.15);
            color: #86efac;
        }
        
        .dark .badge.datetime {
            background: rgba(59, 130, 246, 0.15);
            color: #93c5fd;
        }
        
        .dark .badge.string {
            background: rgba(245, 158, 11, 0.15);
            color: #fcd34d;
        }
        
        .dark .badge.duration {
            background: rgba(34, 197, 94, 0.15);
            color: #86efac;
        }
        
        /* Info Footer */
        .info-footer {
            text-align: center;
            font-size: 0.75rem;
            color: var(--text-secondary);
            margin-top: 0.75rem;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--text-muted);
        }
        
        .empty-state svg {
            width: 48px;
            height: 48px;
            margin: 0 auto 1rem;
            opacity: 0.5;
        }
        
        .empty-state p {
            font-size: 0.875rem;
        }
        
        /* View Container */
        .view-container {
            display: none;
        }
        
        .view-container.active {
            display: block;
        }
        
        /* Hidden Elements */
        .hidden {
            display: none !important;
        }
        
        .logo-light, .logo-dark {
            height: 24px;
            width: auto;
        }
        
        .dark .logo-light {
            display: none;
        }
        
        .logo-dark {
            display: none;
        }
        
        .dark .logo-dark {
            display: block;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">
                <!-- Light mode logo -->
                <svg class="logo-light" width="140" height="20" viewBox="0 0 280 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <line x1="4" y1="4" x2="4" y2="36" stroke="black" stroke-width="0.5" opacity="0.12"/>
                    <line x1="12" y1="4" x2="12" y2="36" stroke="black" stroke-width="0.5" opacity="0.12"/>
                    <line x1="20" y1="4" x2="20" y2="36" stroke="black" stroke-width="0.5" opacity="0.12"/>
                    <line x1="28" y1="4" x2="28" y2="36" stroke="black" stroke-width="0.5" opacity="0.12"/>
                    <line x1="36" y1="4" x2="36" y2="36" stroke="black" stroke-width="0.5" opacity="0.12"/>
                    <line x1="4" y1="36" x2="36" y2="36" stroke="black" stroke-width="0.5" opacity="0.12"/>
                    <line x1="4" y1="28" x2="36" y2="28" stroke="black" stroke-width="0.5" opacity="0.12"/>
                    <line x1="4" y1="20" x2="36" y2="20" stroke="black" stroke-width="0.5" opacity="0.12"/>
                    <line x1="4" y1="12" x2="36" y2="12" stroke="black" stroke-width="0.5" opacity="0.12"/>
                    <path d="M4 32 L9 28 L15 30 L20 24 L26 20 L31 16 L36 7 L36 36 L4 36 Z" fill="url(#areaGradientWL)"/>
                    <polyline points="4,32 9,28 15,30 20,24 26,20 31,16 36,7" stroke="#00dc82" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                    <circle cx="4" cy="32" r="1.5" fill="#00dc82"/>
                    <circle cx="9" cy="28" r="1.5" fill="#00dc82"/>
                    <circle cx="15" cy="30" r="1.5" fill="#00dc82"/>
                    <circle cx="20" cy="24" r="1.5" fill="#00dc82"/>
                    <circle cx="26" cy="20" r="1.5" fill="#00dc82"/>
                    <circle cx="31" cy="16" r="1.5" fill="#00dc82"/>
                    <circle cx="36" cy="7" r="1.5" fill="#00dc82"/>
                    <text x="46" y="30" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="24" font-weight="700" fill="#111827" letter-spacing="-0.5">csvpredict</text>
                    <defs>
                        <linearGradient id="areaGradientWL" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="#00dc82" stop-opacity="0.25"/>
                            <stop offset="100%" stop-color="#00dc82" stop-opacity="0.02"/>
                        </linearGradient>
                    </defs>
                </svg>
                <!-- Dark mode logo -->
                <svg class="logo-dark" width="140" height="20" viewBox="0 0 280 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <line x1="4" y1="4" x2="4" y2="36" stroke="white" stroke-width="0.5" opacity="0.2"/>
                    <line x1="12" y1="4" x2="12" y2="36" stroke="white" stroke-width="0.5" opacity="0.2"/>
                    <line x1="20" y1="4" x2="20" y2="36" stroke="white" stroke-width="0.5" opacity="0.2"/>
                    <line x1="28" y1="4" x2="28" y2="36" stroke="white" stroke-width="0.5" opacity="0.2"/>
                    <line x1="36" y1="4" x2="36" y2="36" stroke="white" stroke-width="0.5" opacity="0.2"/>
                    <line x1="4" y1="36" x2="36" y2="36" stroke="white" stroke-width="0.5" opacity="0.2"/>
                    <line x1="4" y1="28" x2="36" y2="28" stroke="white" stroke-width="0.5" opacity="0.2"/>
                    <line x1="4" y1="20" x2="36" y2="20" stroke="white" stroke-width="0.5" opacity="0.2"/>
                    <line x1="4" y1="12" x2="36" y2="12" stroke="white" stroke-width="0.5" opacity="0.2"/>
                    <path d="M4 32 L9 28 L15 30 L20 24 L26 20 L31 16 L36 7 L36 36 L4 36 Z" fill="url(#areaGradientWD)"/>
                    <polyline points="4,32 9,28 15,30 20,24 26,20 31,16 36,7" stroke="#00dc82" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                    <circle cx="4" cy="32" r="1.5" fill="#00dc82"/>
                    <circle cx="9" cy="28" r="1.5" fill="#00dc82"/>
                    <circle cx="15" cy="30" r="1.5" fill="#00dc82"/>
                    <circle cx="20" cy="24" r="1.5" fill="#00dc82"/>
                    <circle cx="26" cy="20" r="1.5" fill="#00dc82"/>
                    <circle cx="31" cy="16" r="1.5" fill="#00dc82"/>
                    <circle cx="36" cy="7" r="1.5" fill="#00dc82"/>
                    <text x="46" y="30" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="24" font-weight="700" fill="white" letter-spacing="-0.5">csvpredict</text>
                    <defs>
                        <linearGradient id="areaGradientWD" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="#00dc82" stop-opacity="0.25"/>
                            <stop offset="100%" stop-color="#00dc82" stop-opacity="0.02"/>
                        </linearGradient>
                    </defs>
                </svg>
            </div>
            <div class="header-controls">
                <div class="status">
                    <div class="status-dot"></div>
                    <span>Live</span>
                </div>
                <button class="theme-toggle" onclick="toggleTheme()" title="Toggle theme">
                    <svg id="sun-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="4"/>
                        <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>
                    </svg>
                    <svg id="moon-icon" class="hidden" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                    </svg>
                </button>
            </div>
        </div>
    </header>
    
    <div class="container">
        <div id="app">
            <div class="empty-state" id="loading">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M12 6v6l4 2"/>
                </svg>
                <p>Waiting for data...</p>
            </div>
        </div>
    </div>
    
    <script>
        // Theme handling
        function toggleTheme() {
            document.body.classList.toggle('dark');
            updateThemeIcons();
            localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
            updateChartTheme();
        }
        
        function updateThemeIcons() {
            const isDark = document.body.classList.contains('dark');
            document.getElementById('sun-icon').classList.toggle('hidden', isDark);
            document.getElementById('moon-icon').classList.toggle('hidden', !isDark);
        }
        
        function initTheme() {
            const savedTheme = localStorage.getItem('theme');
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
                document.body.classList.add('dark');
            }
            updateThemeIcons();
        }
        
        function getChartColors() {
            const isDark = document.body.classList.contains('dark');
            return {
                text: isDark ? '#a1a1aa' : '#6b7280',
                grid: isDark ? '#27272a' : '#e5e7eb',
                primary: '#22c55e',
                info: '#3b82f6',
                warning: '#f59e0b',
                error: '#ef4444',
                cyan: '#06b6d4',
                orange: '#f97316',
                purple: '#8b5cf6',
            };
        }
        
        function updateChartTheme() {
            if (typeof Chart === 'undefined') return;
            const colors = getChartColors();
            Chart.defaults.color = colors.text;
            Chart.defaults.borderColor = colors.grid;
            // Re-render to apply theme
            if (currentData) {
                renderVisualization();
            }
        }
        
        // Initialize theme on load
        initTheme();
        
        // Chart.js defaults (set when Chart.js is available)
        const CHART_COLORS = [
            '#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6',
            '#ec4899', '#06b6d4', '#84cc16', '#f97316', '#6366f1'
        ];
        
        function initChartDefaults() {
            if (typeof Chart === 'undefined') return;
            const colors = getChartColors();
            Chart.defaults.color = colors.text;
            Chart.defaults.borderColor = colors.grid;
            Chart.defaults.font.family = "ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
        }
        
        // Initialize Chart.js defaults when ready
        if (typeof Chart !== 'undefined') {
            initChartDefaults();
        }
        
        let currentData = null;
        let currentVersion = -1;
        let charts = {};
        let selectedPartition = null;
        let selectedNumericColumn = null;
        let selectedStringColumn = null;
        let activeView = 'overview';
        
        // Polling for updates
        async function checkForUpdates() {
            try {
                const response = await fetch('/api/data');
                const data = await response.json();
                
                if (data.version !== currentVersion) {
                    currentVersion = data.version;
                    currentData = data.data;
                    renderVisualization();
                }
            } catch (e) {
                console.error('Failed to fetch data:', e);
            }
            
            setTimeout(checkForUpdates, 200);
        }
        
        function getActiveStats() {
            if (!currentData) return null;
            
            if (currentData.partitioned_statistics) {
                const partitions = Object.keys(currentData.partitioned_statistics);
                if (!selectedPartition || !partitions.includes(selectedPartition)) {
                    selectedPartition = partitions[0];
                }
                return currentData.partitioned_statistics[selectedPartition];
            }
            
            return currentData.non_partitioned_statistics;
        }
        
        function formatNumber(value) {
            if (value === null || value === undefined) return '-';
            if (typeof value === 'number') {
                if (Number.isNaN(value)) return '-';
                if (Math.abs(value) >= 1e9) return (value / 1e9).toFixed(2) + 'B';
                if (Math.abs(value) >= 1e6) return (value / 1e6).toFixed(2) + 'M';
                if (Math.abs(value) >= 1e3) return (value / 1e3).toFixed(2) + 'K';
                if (Number.isInteger(value)) return value.toLocaleString();
                return value.toFixed(2);
            }
            return String(value);
        }
        
        // Helper to get percentile values with multiple possible key names
        function getPercentile(row, percentile) {
            const keys = {
                25: ['25%', 'q1', 'q25', 'p25', 'percentile_25', '25'],
                50: ['50%', 'q2', 'q50', 'p50', 'percentile_50', 'median', '50'],
                75: ['75%', 'q3', 'q75', 'p75', 'percentile_75', '75']
            };
            for (const key of (keys[percentile] || [])) {
                if (row[key] !== undefined && row[key] !== null) {
                    return row[key];
                }
            }
            return null;
        }
        
        // Wait for Chart.js to be available and canvas to have dimensions
        function waitForChartReady(callback, maxAttempts = 50) {
            let attempts = 0;
            function check() {
                attempts++;
                if (typeof Chart !== 'undefined') {
                    // Ensure Chart.js defaults are set
                    initChartDefaults();
                    // Wait for canvas elements to have dimensions
                    requestAnimationFrame(() => {
                        requestAnimationFrame(() => {
                            callback();
                        });
                    });
                } else if (attempts < maxAttempts) {
                    setTimeout(check, 100);
                } else {
                    console.error('Chart.js failed to load');
                }
            }
            check();
        }
        
        function destroyAllCharts() {
            Object.values(charts).forEach(chart => {
                if (chart && typeof chart.destroy === 'function') {
                    chart.destroy();
                }
            });
            charts = {};
        }
        
        function renderVisualization() {
            destroyAllCharts();
            const app = document.getElementById('app');
            const stats = getActiveStats();
            
            if (!stats) {
                app.innerHTML = `
                    <div class="empty-state">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <path d="M12 6v6l4 2"/>
                        </svg>
                        <p>Waiting for data...</p>
                    </div>
                `;
                return;
            }
            
            // Set default selected columns (reset if column no longer exists in new data)
            const numericCols = Object.keys(stats.statistics?.numeric || {});
            const stringCols = Object.keys(stats.statistics?.string || {});
            if (!selectedNumericColumn || !numericCols.includes(selectedNumericColumn)) {
                selectedNumericColumn = numericCols.length > 0 ? numericCols[0] : null;
            }
            if (!selectedStringColumn || !stringCols.includes(selectedStringColumn)) {
                selectedStringColumn = stringCols.length > 0 ? stringCols[0] : null;
            }
            
            const overall = stats.overall_statistics || {};
            const hasRolling = Object.keys(stats.statistics?.numeric_rolling || {}).length > 0;
            const hasCorrelation = Object.keys(stats.correlation_statistics || {}).length > 1;
            
            let html = '';
            
            // Partition selector
            if (currentData.partitioned_statistics) {
                const partitions = Object.keys(currentData.partitioned_statistics);
                html += `
                    <div class="partition-selector">
                        <span class="partition-label">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px">
                                <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                                <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
                            </svg>
                            Partition:
                        </span>
                        ${partitions.map(p => `
                            <button class="partition-btn ${p === selectedPartition ? 'active' : ''}"
                                    onclick="selectPartition('${p.replace(/'/g, "\\'")}')">${p}</button>
                        `).join('')}
                    </div>
                `;
            }
            
            // Overview Card
            html += `
                <div class="card">
                    <div class="card-header">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>
                        </svg>
                        <h2 class="card-title">Dataset Overview</h2>
                    </div>
                    <div class="overview-grid">
                        <div class="stat-card">
                            <div class="stat-value">${formatNumber(overall.height)}</div>
                            <div class="stat-label">Rows</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">${overall.width || '-'}</div>
                            <div class="stat-label">Columns</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value ${(overall.null_count || 0) > 0 ? 'warning' : 'success'}">${formatNumber(overall.null_count ?? 0)}</div>
                            <div class="stat-label">Null Values</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">${formatNumber(overall.duplicate_count)}</div>
                            <div class="stat-label">Duplicates</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">${formatNumber(overall.unique_count)}</div>
                            <div class="stat-label">Unique Rows</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value" style="font-size: 1.5rem;">
                                ${overall.timestamp_column ? 
                                    '<svg viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2" style="width:32px;height:32px;margin:0 auto"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>' :
                                    '<svg viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" style="width:32px;height:32px;margin:0 auto"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>'
                                }
                            </div>
                            <div class="stat-label">Timestamp</div>
                        </div>
                    </div>
                </div>
            `;
            
            // Download buttons
            html += `
                <div class="download-buttons">
                    <button class="download-btn" onclick="downloadGraphs()" id="download-graphs-btn">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                            <polyline points="7 10 12 15 17 10"/>
                            <line x1="12" y1="15" x2="12" y2="3"/>
                        </svg>
                        <span class="download-btn-text">Download Graphs</span>
                        <span class="download-spinner"></span>
                    </button>
                    <button class="download-btn" onclick="downloadXlsx()" id="download-xlsx-btn">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                            <polyline points="14 2 14 8 20 8"/>
                            <line x1="16" y1="13" x2="8" y2="13"/>
                            <line x1="16" y1="17" x2="8" y2="17"/>
                            <polyline points="10 9 9 9 8 9"/>
                        </svg>
                        <span class="download-btn-text">Download XLSX</span>
                        <span class="download-spinner"></span>
                    </button>
                    <button class="download-btn" onclick="downloadPptx()" id="download-pptx-btn">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M2 3h20v14H2z"/>
                            <path d="M8 21h8"/>
                            <path d="M12 17v4"/>
                        </svg>
                        <span class="download-btn-text">Download PPTX</span>
                        <span class="download-spinner"></span>
                    </button>
                </div>
            `;
            
            // View Tabs
            html += `
                <div class="view-tabs">
                    <button class="view-tab ${activeView === 'overview' ? 'active' : ''}" onclick="switchView('overview')">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                            <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
                        </svg>
                        Overview
                    </button>
                    <button class="view-tab ${activeView === 'correlation' ? 'active' : ''} ${!hasCorrelation ? 'hidden' : ''}" onclick="switchView('correlation')">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="18" cy="18" r="3"/><circle cx="6" cy="6" r="3"/>
                            <path d="M6 21V9a9 9 0 0 0 9 9"/>
                        </svg>
                        Correlations
                    </button>
                    <button class="view-tab ${activeView === 'rolling' ? 'active' : ''} ${!hasRolling ? 'hidden' : ''}" onclick="switchView('rolling')">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
                        </svg>
                        Rolling Stats
                    </button>
                </div>
            `;
            
            // Overview View
            html += `<div id="view-overview" class="view-container ${activeView === 'overview' ? 'active' : ''}">`;
            html += renderOverviewView(stats);
            html += `</div>`;
            
            // Correlation View
            if (hasCorrelation) {
                html += `<div id="view-correlation" class="view-container ${activeView === 'correlation' ? 'active' : ''}">`;
                html += renderCorrelationView(stats);
                html += `</div>`;
            }
            
            // Rolling Stats View
            if (hasRolling) {
                html += `<div id="view-rolling" class="view-container ${activeView === 'rolling' ? 'active' : ''}">`;
                html += renderRollingView(stats);
                html += `</div>`;
            }
            
            app.innerHTML = html;
            
            // Render charts after Chart.js is ready and DOM is painted
            waitForChartReady(() => {
                if (activeView === 'overview') renderOverviewCharts(stats);
                else if (activeView === 'correlation') renderCorrelationCharts(stats);
                else if (activeView === 'rolling') renderRollingCharts(stats);
            });
        }
        
        function renderOverviewView(stats) {
            let html = '';
            const numericCols = Object.keys(stats.statistics?.numeric || {});
            const stringCols = Object.keys(stats.statistics?.string || {});
            
            // Detected Columns Card
            html += `
                <div class="card">
                    <div class="card-header">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7m0-18H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h7m0-18v18"/>
                        </svg>
                        <h2 class="card-title">Detected Columns</h2>
                    </div>
                    <div class="columns-grid">
            `;
            
            if (numericCols.length > 0) {
                html += `
                    <div>
                        <div class="column-group-title">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 7H2v10h3m6-10h-1a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h1m6-10h-1a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h1m6-10h-3v10h3"/></svg>
                            Numeric (${numericCols.length})
                        </div>
                        <div class="badges-container">
                            ${numericCols.map(c => `<span class="badge numeric">${c}</span>`).join('')}
                        </div>
                    </div>
                `;
            }
            
            if (stringCols.length > 0) {
                html += `
                    <div>
                        <div class="column-group-title">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></svg>
                            String (${stringCols.length})
                        </div>
                        <div class="badges-container">
                            ${stringCols.map(c => `<span class="badge string">${c}</span>`).join('')}
                        </div>
                    </div>
                `;
            }
            
            html += `</div></div>`;
            
            // Numeric Statistics
            if (numericCols.length > 0) {
                html += `
                    <div class="card">
                        <div class="card-header">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>
                            <h2 class="card-title">Numeric Statistics</h2>
                        </div>
                        <div class="column-tabs">
                            ${numericCols.map(col => `
                                <button class="column-tab ${col === selectedNumericColumn ? 'active' : ''}"
                                        onclick="selectNumericColumn('${col.replace(/'/g, "\\'")}')">${col}</button>
                            `).join('')}
                        </div>
                        <div class="charts-grid two-col">
                            <div class="chart-panel">
                                <div class="chart-panel-header">
                                    <div class="chart-panel-title">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>
                                        Data Completeness
                                    </div>
                                </div>
                                <div class="chart-wrapper">
                                    <canvas id="completenessChart"></canvas>
                                </div>
                            </div>
                            <div class="chart-panel">
                                <div class="chart-panel-header">
                                    <div class="chart-panel-title">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>
                                        Distribution (Box Plot)
                                    </div>
                                </div>
                                <div class="chart-wrapper short">
                                    <canvas id="boxplotChart"></canvas>
                                </div>
                                <div id="boxplotSummary" class="boxplot-summary"></div>
                            </div>
                        </div>
                        <div class="chart-panel" style="margin-top: 1rem;">
                            <div class="chart-panel-header">
                                <div class="chart-panel-title">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                                    Statistics Summary
                                </div>
                            </div>
                            <div id="numericStatsTable"></div>
                        </div>
                    </div>
                `;
            }
            
            // String Statistics
            if (stringCols.length > 0) {
                html += `
                    <div class="card">
                        <div class="card-header">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></svg>
                            <h2 class="card-title">String Statistics</h2>
                        </div>
                        <div class="column-tabs">
                            ${stringCols.map(col => `
                                <button class="column-tab ${col === selectedStringColumn ? 'active' : ''}"
                                        onclick="selectStringColumn('${col.replace(/'/g, "\\'")}')">${col}</button>
                            `).join('')}
                        </div>
                        <div class="charts-grid two-col">
                            <div class="chart-panel">
                                <div class="chart-panel-header">
                                    <div class="chart-panel-title">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>
                                        Top Values Distribution
                                    </div>
                                </div>
                                <div class="chart-wrapper tall">
                                    <canvas id="stringPieChart"></canvas>
                                </div>
                            </div>
                            <div class="chart-panel">
                                <div class="chart-panel-header">
                                    <div class="chart-panel-title">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                                        Value Counts
                                    </div>
                                </div>
                                <div class="chart-wrapper tall">
                                    <canvas id="stringBarChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }
            
            return html;
        }
        
        function renderCorrelationView(stats) {
            const correlation = stats.correlation_statistics || {};
            const cols = Object.keys(correlation);
            
            if (cols.length < 2) return '<div class="card"><p style="color:var(--text-secondary)">Not enough numeric columns for correlation analysis.</p></div>';
            
            let html = `
                <div class="card">
                    <div class="card-header">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="18" cy="18" r="3"/><circle cx="6" cy="6" r="3"/>
                            <path d="M6 21V9a9 9 0 0 0 9 9"/>
                        </svg>
                        <h2 class="card-title">Correlation Analysis</h2>
                    </div>
                    <p class="card-description">Pearson correlation coefficients between numeric columns.</p>
                    
                    <div class="correlation-matrix">
                        <table class="correlation-table">
                            <thead>
                                <tr>
                                    <th></th>
                                    ${cols.map(c => `<th>${c}</th>`).join('')}
                                </tr>
                            </thead>
                            <tbody>
            `;
            
            cols.forEach(row => {
                html += `<tr><th>${row}</th>`;
                cols.forEach(col => {
                    const val = correlation[row]?.[col];
                    const displayVal = val !== null && val !== undefined ? val.toFixed(2) : '-';
                    let colorClass = 'weak';
                    if (val !== null && val !== undefined) {
                        if (val > 0.7) colorClass = 'strong-positive';
                        else if (val > 0.3) colorClass = 'moderate-positive';
                        else if (val < -0.7) colorClass = 'strong-negative';
                        else if (val < -0.3) colorClass = 'moderate-negative';
                    }
                    html += `<td><div class="correlation-cell ${colorClass}">${displayVal}</div></td>`;
                });
                html += `</tr>`;
            });
            
            html += `
                            </tbody>
                        </table>
                        <div class="correlation-legend">
                            <div class="correlation-legend-item">
                                <div class="correlation-legend-box" style="background:rgba(239,68,68,0.8)"></div>
                                <span>Strong Negative</span>
                            </div>
                            <div class="correlation-legend-item">
                                <div class="correlation-legend-box" style="background:var(--bg-card)"></div>
                                <span>Weak</span>
                            </div>
                            <div class="correlation-legend-item">
                                <div class="correlation-legend-box" style="background:rgba(34,197,94,0.8)"></div>
                                <span>Strong Positive</span>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            return html;
        }
        
        function renderRollingView(stats) {
            const rolling = stats.statistics?.numeric_rolling || {};
            const rollingCols = Object.keys(rolling);
            
            if (rollingCols.length === 0) return '';
            
            return `
                <div class="card">
                    <div class="card-header">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
                        </svg>
                        <h2 class="card-title">Rolling Statistics</h2>
                    </div>
                    <p class="card-description">Time-series analysis with rolling mean and standard deviation.</p>
                    <div class="column-tabs">
                        ${rollingCols.map((col, i) => `
                            <button class="column-tab ${i === 0 || col === selectedNumericColumn ? 'active' : ''}"
                                    onclick="selectRollingColumn('${col.replace(/'/g, "\\'")}')" id="rolling-tab-${col}">${col}</button>
                        `).join('')}
                    </div>
                    <div class="chart-panel">
                        <div class="chart-wrapper tall">
                            <canvas id="rollingChart"></canvas>
                        </div>
                    </div>
                </div>
            `;
        }
        
        function renderOverviewCharts(stats) {
            const numericData = stats.statistics?.numeric?.[selectedNumericColumn];
            const chartColors = getChartColors();
            
            if (numericData && numericData.length > 0) {
                const row = numericData[0];
                
                // Completeness (Doughnut) Chart
                const ctx1 = document.getElementById('completenessChart')?.getContext('2d');
                if (ctx1) {
                    const validCount = row.count - (row.null_count || 0);
                    const nullCount = row.null_count || 0;
                    charts.completeness = new Chart(ctx1, {
                        type: 'doughnut',
                        data: {
                            labels: ['Valid', 'Null'],
                            datasets: [{
                                data: [validCount, nullCount],
                                backgroundColor: [chartColors.primary, chartColors.error],
                                borderWidth: 0
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            cutout: '60%',
                            plugins: {
                                legend: { position: 'bottom', labels: { padding: 15 } }
                            }
                        }
                    });
                }
                
                // Box Plot (Horizontal Bar simulation)
                const ctx2 = document.getElementById('boxplotChart')?.getContext('2d');
                if (ctx2) {
                    const q1 = getPercentile(row, 25) || 0;
                    const median = getPercentile(row, 50) || 0;
                    const q3 = getPercentile(row, 75) || 0;
                    charts.boxplot = new Chart(ctx2, {
                        type: 'bar',
                        data: {
                            labels: [selectedNumericColumn],
                            datasets: [
                                {
                                    label: 'Min to Q1',
                                    data: [q1 - (row.min || 0)],
                                    backgroundColor: 'rgba(59, 130, 246, 0.3)',
                                    borderWidth: 0
                                },
                                {
                                    label: 'Q1 to Median',
                                    data: [median - q1],
                                    backgroundColor: 'rgba(6, 182, 212, 0.5)',
                                    borderWidth: 0
                                },
                                {
                                    label: 'Median to Q3',
                                    data: [q3 - median],
                                    backgroundColor: 'rgba(245, 158, 11, 0.5)',
                                    borderWidth: 0
                                },
                                {
                                    label: 'Q3 to Max',
                                    data: [(row.max || 0) - q3],
                                    backgroundColor: 'rgba(239, 68, 68, 0.3)',
                                    borderWidth: 0
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            indexAxis: 'y',
                            plugins: { legend: { display: false } },
                            scales: {
                                x: { stacked: true, grid: { color: chartColors.grid } },
                                y: { stacked: true, display: false }
                            }
                        }
                    });
                }
                
                // Box Plot Summary
                const summaryEl = document.getElementById('boxplotSummary');
                if (summaryEl) {
                    summaryEl.innerHTML = `
                        <div class="boxplot-stat min">
                            <div class="boxplot-stat-label"><span class="boxplot-stat-dot"></span>MIN</div>
                            <div class="boxplot-stat-value">${formatNumber(row.min)}</div>
                        </div>
                        <div class="boxplot-stat q1">
                            <div class="boxplot-stat-label"><span class="boxplot-stat-dot"></span>Q1</div>
                            <div class="boxplot-stat-value">${formatNumber(getPercentile(row, 25))}</div>
                        </div>
                        <div class="boxplot-stat median">
                            <div class="boxplot-stat-label"><span class="boxplot-stat-dot"></span>MEDIAN</div>
                            <div class="boxplot-stat-value">${formatNumber(getPercentile(row, 50))}</div>
                        </div>
                        <div class="boxplot-stat mean">
                            <div class="boxplot-stat-label"><span class="boxplot-stat-dot"></span>MEAN</div>
                            <div class="boxplot-stat-value">${formatNumber(row.mean)}</div>
                        </div>
                        <div class="boxplot-stat q3">
                            <div class="boxplot-stat-label"><span class="boxplot-stat-dot"></span>Q3</div>
                            <div class="boxplot-stat-value">${formatNumber(getPercentile(row, 75))}</div>
                        </div>
                        <div class="boxplot-stat max">
                            <div class="boxplot-stat-label"><span class="boxplot-stat-dot"></span>MAX</div>
                            <div class="boxplot-stat-value">${formatNumber(row.max)}</div>
                        </div>
                    `;
                }
                
                // Statistics Table
                const tableEl = document.getElementById('numericStatsTable');
                if (tableEl) {
                    const displayStats = [
                        ['Count', row.count],
                        ['Mean', row.mean],
                        ['Std Dev', row.std],
                        ['Skewness', row.skewness],
                        ['Kurtosis', row.kurtosis],
                        ['Null Count', row.null_count]
                    ];
                    tableEl.innerHTML = `
                        <table class="stats-table">
                            <thead><tr><th>Statistic</th><th>Value</th></tr></thead>
                            <tbody>
                                ${displayStats.map(([label, value]) => `
                                    <tr><td>${label}</td><td>${formatNumber(value)}</td></tr>
                                `).join('')}
                            </tbody>
                        </table>
                    `;
                }
            }
            
            // String column charts
            const stringCount = stats.statistics?.string_count?.[selectedStringColumn];
            if (stringCount && stringCount.length > 0) {
                const topValues = stringCount.slice(0, 10);
                
                const ctx3 = document.getElementById('stringBarChart')?.getContext('2d');
                if (ctx3) {
                    charts.stringBar = new Chart(ctx3, {
                        type: 'bar',
                        data: {
                            labels: topValues.map(v => String(v.value).slice(0, 20)),
                            datasets: [{
                                label: 'Count',
                                data: topValues.map(v => v.count),
                                backgroundColor: chartColors.primary,
                                borderWidth: 0,
                                borderRadius: 4
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            indexAxis: 'y',
                            plugins: { legend: { display: false } },
                            scales: {
                                x: { grid: { color: chartColors.grid } },
                                y: { grid: { display: false } }
                            }
                        }
                    });
                }
                
                const ctx4 = document.getElementById('stringPieChart')?.getContext('2d');
                if (ctx4) {
                    const pieData = topValues.slice(0, 6);
                    charts.stringPie = new Chart(ctx4, {
                        type: 'doughnut',
                        data: {
                            labels: pieData.map(v => String(v.value).slice(0, 15)),
                            datasets: [{
                                data: pieData.map(v => v.count),
                                backgroundColor: CHART_COLORS.slice(0, pieData.length),
                                borderWidth: 2,
                                borderColor: getComputedStyle(document.body).getPropertyValue('--bg-card').trim()
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: { position: 'right', labels: { padding: 12 } }
                            }
                        }
                    });
                }
            }
        }
        
        function renderCorrelationCharts(stats) {
            // Correlation is rendered as HTML table, no canvas charts needed
        }
        
        function renderRollingCharts(stats) {
            const rolling = stats.statistics?.numeric_rolling;
            const rollingCol = selectedNumericColumn || Object.keys(rolling || {})[0];
            
            if (rolling && rollingCol && rolling[rollingCol]) {
                const rollingData = rolling[rollingCol];
                const ctx = document.getElementById('rollingChart')?.getContext('2d');
                const chartColors = getChartColors();
                
                if (ctx && rollingData.length > 0) {
                    const hasDate = rollingData[0].ds !== undefined;
                    const labels = rollingData.map((d, i) => hasDate ? d.ds : i);
                    
                    charts.rolling = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: labels,
                            datasets: [
                                {
                                    label: 'Rolling Mean',
                                    data: rollingData.map(d => d.rolling_mean),
                                    borderColor: chartColors.primary,
                                    backgroundColor: 'transparent',
                                    tension: 0.3,
                                    pointRadius: 0,
                                    borderWidth: 2
                                },
                                {
                                    label: 'Rolling Std',
                                    data: rollingData.map(d => d.rolling_std),
                                    borderColor: chartColors.info,
                                    backgroundColor: 'transparent',
                                    tension: 0.3,
                                    pointRadius: 0,
                                    borderWidth: 2
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: { legend: { position: 'top' } },
                            scales: {
                                x: { grid: { color: chartColors.grid }, ticks: { maxTicksLimit: 10 } },
                                y: { grid: { color: chartColors.grid } }
                            }
                        }
                    });
                }
            }
        }
        
        function switchView(view) {
            activeView = view;
            document.querySelectorAll('.view-tab').forEach(tab => {
                tab.classList.toggle('active', tab.textContent.toLowerCase().includes(view.split('-')[0]));
            });
            document.querySelectorAll('.view-container').forEach(container => {
                container.classList.toggle('active', container.id === 'view-' + view);
            });
            
            destroyAllCharts();
            const stats = getActiveStats();
            if (stats) {
                waitForChartReady(() => {
                    if (view === 'overview') renderOverviewCharts(stats);
                    else if (view === 'correlation') renderCorrelationCharts(stats);
                    else if (view === 'rolling') renderRollingCharts(stats);
                });
            }
        }
        
        function selectPartition(partition) {
            selectedPartition = partition;
            selectedNumericColumn = null;
            selectedStringColumn = null;
            renderVisualization();
        }
        
        function selectNumericColumn(col) {
            selectedNumericColumn = col;
            if (activeView === 'overview') {
                destroyAllCharts();
                renderVisualization();
            }
        }
        
        function selectStringColumn(col) {
            selectedStringColumn = col;
            if (activeView === 'overview') {
                destroyAllCharts();
                renderVisualization();
            }
        }
        
        function selectRollingColumn(col) {
            selectedNumericColumn = col;
            document.querySelectorAll('.column-tabs .column-tab').forEach(tab => {
                tab.classList.toggle('active', tab.textContent === col);
            });
            destroyAllCharts();
            renderRollingCharts(getActiveStats());
        }
        
        // Download functions
        async function downloadFile(endpoint, btnId) {
            const btn = document.getElementById(btnId);
            if (!btn || btn.disabled) return;
            
            btn.disabled = true;
            btn.classList.add('loading');
            
            try {
                const response = await fetch('/api/download/' + endpoint);
                if (!response.ok) {
                    const error = await response.json().catch(() => ({ error: 'Download failed' }));
                    throw new Error(error.error || 'Download failed');
                }
                
                const blob = await response.blob();
                const contentDisposition = response.headers.get('Content-Disposition');
                let filename = endpoint === 'graphs' ? 'graphs.zip' : 
                               endpoint === 'xlsx' ? 'analysis.xlsx' : 'presentation.pptx';
                
                if (contentDisposition) {
                    const match = contentDisposition.match(/filename="(.+)"/);
                    if (match) filename = match[1];
                }
                
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            } catch (error) {
                console.error('Download error:', error);
                alert('Download failed: ' + error.message);
            } finally {
                btn.disabled = false;
                btn.classList.remove('loading');
            }
        }
        
        function downloadGraphs() {
            downloadFile('graphs', 'download-graphs-btn');
        }
        
        function downloadXlsx() {
            downloadFile('xlsx', 'download-xlsx-btn');
        }
        
        function downloadPptx() {
            downloadFile('pptx', 'download-pptx-btn');
        }
        
        // Check download availability
        async function checkDownloadAvailability() {
            try {
                const response = await fetch('/api/download/status');
                const data = await response.json();
                const buttons = document.querySelectorAll('.download-btn');
                if (!data.available) {
                    buttons.forEach(btn => {
                        btn.disabled = true;
                        btn.title = 'Downloads not available in this mode';
                    });
                }
            } catch (e) {
                // Silently fail
            }
        }
        
        // Start polling
        checkDownloadAvailability();
        checkForUpdates();
    </script>
</body>
</html>
"""


def generate_notebook_html_(raw_json: dict[str, Any], height: int = 800) -> str:
	"""Generate standalone HTML for Jupyter notebook display.

	This creates an iframe with embedded data - no server needed.

	Args:
		raw_json: Raw JSON data from InspectResult.raw_json_.
		height: Height of the iframe in pixels.

	Returns:
		HTML string for IPython.display.HTML.
	"""
	data_json = json.dumps({"version": 1, "data": raw_json})

	new_init = f"""        // Embedded data (no server needed)
		const embeddedData = {data_json};
		currentVersion = embeddedData.version;
		currentData = embeddedData.data;

		// Hide download buttons in notebook mode (match actual selectors)
		document.querySelectorAll('.download-buttons, .download-btn').forEach(el => el.style.display = 'none');

		// Render immediately
		waitForChartReady(() => {{
			renderVisualization();
		}});"""

	html_content = re.sub(
		r"// Start polling[\s\S]*?checkForUpdates\(\);",
		new_init,
		HTML_TEMPLATE,
		flags=re.MULTILINE,
	)

	data_uri = "data:text/html;charset=utf-8;base64," + base64.b64encode(
		html_content.encode("utf-8")
	).decode("ascii")

	return f"""<iframe src="{data_uri}" style="width: 100%; height: {height}px; border: 1px solid #e5e7eb; border-radius: 8px;" sandbox="allow-scripts allow-same-origin"></iframe>"""
