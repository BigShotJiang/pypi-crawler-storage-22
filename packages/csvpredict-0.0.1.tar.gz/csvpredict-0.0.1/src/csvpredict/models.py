from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd
import polars as pl

from .helpers import nested_dict_to_dataframes_


@dataclass
class OverallStatistics:
	"""Overall statistics for a dataset.

	Attributes:
		height: Number of rows in the dataset.
		width: Number of columns in the dataset.
		column_names: List of column names.
		null_count: Total number of null values.
		duplicate_count: Number of duplicate rows.
		unique_count: Number of unique rows.
		timestamp_column: Name of the detected timestamp column, if any.
	"""

	height: int | None = None
	width: int | None = None
	column_names: list[str] | None = None
	null_count: int | None = None
	duplicate_count: int | None = None
	unique_count: int | None = None
	timestamp_column: str | None = None

	@classmethod
	def from_dict(cls, data: dict[str, Any]) -> OverallStatistics:
		"""Create from API response dictionary."""
		return cls(
			height=data.get("height"),
			width=data.get("width"),
			column_names=data.get("column_names"),
			null_count=data.get("null_count"),
			duplicate_count=data.get("duplicate_count"),
			unique_count=data.get("unique_count"),
			timestamp_column=data.get("timestamp_column"),
		)

	def to_dict(self) -> dict[str, Any]:
		"""Convert to dictionary."""
		return {
			"height": self.height,
			"width": self.width,
			"column_names": self.column_names,
			"null_count": self.null_count,
			"duplicate_count": self.duplicate_count,
			"unique_count": self.unique_count,
			"timestamp_column": self.timestamp_column,
		}

	def to_polars(self) -> pl.DataFrame:
		"""Convert to a single-row Polars DataFrame."""
		return pl.DataFrame([self.to_dict()])

	def to_polars_lazy(self) -> pl.LazyFrame:
		"""Convert to a single-row Polars LazyFrame."""
		return self.to_polars().lazy()

	def to_pandas(self) -> pd.DataFrame:
		"""Convert to a single-row pandas DataFrame."""
		return self.to_polars().to_pandas()

	def to_numpy(self) -> np.ndarray:
		"""Convert to a numpy array (single row of values)."""
		return self.to_polars().to_numpy()[0]


@dataclass
class SummaryStatistics:
	"""Summary statistics with Polars DataFrames for each data type.

	Each attribute is a dictionary mapping column names to DataFrames
	containing the statistics for that column.

	Attributes:
		datetime: Statistics for datetime columns.
		datetime_count: Value counts for datetime columns.
		numeric: Statistics for numeric columns.
		numeric_count: Value counts for numeric columns.
		numeric_rolling: Rolling statistics for numeric columns (time series).
		duration: Statistics for duration columns.
		duration_count: Value counts for duration columns.
		string: Statistics for string columns.
		string_count: Value counts for string columns.
		boolean: Statistics for boolean columns.
		boolean_count: Value counts for boolean columns.
	"""

	datetime: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)
	datetime_count: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)
	numeric: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)
	numeric_count: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)
	numeric_rolling: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)
	duration: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)
	duration_count: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)
	string: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)
	string_count: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)
	boolean: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)
	boolean_count: dict[str, pl.DataFrame] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)

	@classmethod
	def from_dict(cls, data: dict[str, Any]) -> SummaryStatistics:
		"""Create from API response dictionary."""
		return cls(
			datetime=nested_dict_to_dataframes_(data.get("datetime", {})),
			datetime_count=nested_dict_to_dataframes_(data.get("datetime_count", {})),
			numeric=nested_dict_to_dataframes_(data.get("numeric", {})),
			numeric_count=nested_dict_to_dataframes_(data.get("numeric_count", {})),
			numeric_rolling=nested_dict_to_dataframes_(data.get("numeric_rolling", {})),
			duration=nested_dict_to_dataframes_(data.get("duration", {})),
			duration_count=nested_dict_to_dataframes_(data.get("duration_count", {})),
			string=nested_dict_to_dataframes_(data.get("string", {})),
			string_count=nested_dict_to_dataframes_(data.get("string_count", {})),
			boolean=nested_dict_to_dataframes_(data.get("boolean", {})),
			boolean_count=nested_dict_to_dataframes_(data.get("boolean_count", {})),
		)

	@property
	def all_columns(self) -> list[str]:
		"""Get all column names across all data types."""
		columns: set[str] = set()
		for attr in [
			self.datetime,
			self.numeric,
			self.duration,
			self.string,
			self.boolean,
		]:
			columns.update(attr.keys())
		return sorted(columns)

	@property
	def all_datatypes(self) -> list[str]:
		"""Get list of available data type categories."""
		return [
			"datetime",
			"datetime_count",
			"numeric",
			"numeric_count",
			"numeric_rolling",
			"duration",
			"duration_count",
			"string",
			"string_count",
			"boolean",
			"boolean_count",
		]

	def __getitem__(self, key: str) -> dict[str, pl.DataFrame]:
		"""Get statistics dict by datatype name.

		Args:
			key: Datatype name (e.g., "numeric", "string_count").

		Returns:
			Dict mapping column names to DataFrames.

		Example:
			>>> stats.summary["numeric"]  # All numeric stats
			>>> stats.summary["string_count"]  # String value counts
		"""
		if not hasattr(self, key):
			raise KeyError(f"Unknown datatype '{key}'. Available: {self.all_datatypes}")
		return getattr(self, key)

	def filter(
		self,
		column: str | None = None,
		datatype: str | None = None,
	) -> dict[str, dict[str, pl.DataFrame]]:
		"""Filter statistics by column name and/or datatype (case-insensitive).

		Args:
			column: Substring to match column names (case-insensitive).
			datatype: Substring to match datatype names (case-insensitive).
				e.g., "numeric", "count", "string".

		Returns:
			Nested dict: {datatype: {column: DataFrame}}

		Example:
			>>> # Get all stats for columns containing "price"
			>>> stats.summary.filter(column="price")
			>>> # Get all numeric statistics
			>>> stats.summary.filter(datatype="numeric")
			>>> # Get count stats for "status" columns
			>>> stats.summary.filter(column="status", datatype="count")
		"""
		result: dict[str, dict[str, pl.DataFrame]] = {}

		for dtype in self.all_datatypes:
			if datatype and datatype.lower() not in dtype.lower():
				continue

			data = getattr(self, dtype)
			filtered: dict[str, pl.DataFrame] = {}

			for col_name, df in data.items():
				if column and column.lower() not in col_name.lower():
					continue
				filtered[col_name] = df

			if filtered:
				result[dtype] = filtered

		return result

	def get_stats_for_column(self, column: str) -> dict[str, pl.DataFrame]:
		"""Get statistics DataFrames for columns matching a pattern.

		Args:
			column: Substring to match column names (case-insensitive).

		Returns:
			Dict mapping matched column names to their statistics DataFrames.

		Example:
			>>> stats.summary.get_stats_for_column("price")
			{'price': DataFrame, 'unit_price': DataFrame}
		"""
		result: dict[str, pl.DataFrame] = {}
		for attr in [
			self.datetime,
			self.numeric,
			self.duration,
			self.string,
			self.boolean,
		]:
			for col_name, df in attr.items():
				if column.lower() in col_name.lower():
					result[col_name] = df
		return result

	def get_counts_for_column(self, column: str) -> dict[str, pl.DataFrame]:
		"""Get value counts DataFrames for columns matching a pattern.

		Args:
			column: Substring to match column names (case-insensitive).

		Returns:
			Dict mapping matched column names to their value counts DataFrames.

		Example:
			>>> stats.summary.get_counts_for_column("status")
			{'status': DataFrame, 'order_status': DataFrame}
		"""
		result: dict[str, pl.DataFrame] = {}
		for attr in [
			self.datetime_count,
			self.numeric_count,
			self.duration_count,
			self.string_count,
			self.boolean_count,
		]:
			for col_name, df in attr.items():
				if column.lower() in col_name.lower():
					result[col_name] = df
		return result

	def get_rolling_for_column(self, column: str) -> dict[str, pl.DataFrame]:
		"""Get rolling statistics DataFrames for numeric columns matching a pattern.

		Args:
			column: Substring to match column names (case-insensitive).

		Returns:
			Dict mapping matched column names to their rolling statistics DataFrames.

		Example:
			>>> stats.summary.get_rolling_for_column("price")
			{'price': DataFrame, 'unit_price': DataFrame}
		"""
		return {
			col_name: df
			for col_name, df in self.numeric_rolling.items()
			if column.lower() in col_name.lower()
		}

	def to_dict(self) -> dict[str, dict[str, list[dict[str, Any]]]]:
		"""Convert all statistics to nested dictionaries.

		Returns:
			Nested dict structure: {data_type: {column: [row_dicts]}}
		"""
		return {
			"datetime": {k: v.to_dicts() for k, v in self.datetime.items()},
			"datetime_count": {k: v.to_dicts() for k, v in self.datetime_count.items()},
			"numeric": {k: v.to_dicts() for k, v in self.numeric.items()},
			"numeric_count": {k: v.to_dicts() for k, v in self.numeric_count.items()},
			"numeric_rolling": {
				k: v.to_dicts() for k, v in self.numeric_rolling.items()
			},
			"duration": {k: v.to_dicts() for k, v in self.duration.items()},
			"duration_count": {k: v.to_dicts() for k, v in self.duration_count.items()},
			"string": {k: v.to_dicts() for k, v in self.string.items()},
			"string_count": {k: v.to_dicts() for k, v in self.string_count.items()},
			"boolean": {k: v.to_dicts() for k, v in self.boolean.items()},
			"boolean_count": {k: v.to_dicts() for k, v in self.boolean_count.items()},
		}

	def to_pandas(self) -> dict[str, dict[str, pd.DataFrame]]:
		"""Convert all statistics to pandas DataFrames.

		Returns:
			Nested dict structure: {data_type: {column: pandas.DataFrame}}
		"""
		return {
			"datetime": {k: v.to_pandas() for k, v in self.datetime.items()},
			"datetime_count": {
				k: v.to_pandas() for k, v in self.datetime_count.items()
			},
			"numeric": {k: v.to_pandas() for k, v in self.numeric.items()},
			"numeric_count": {k: v.to_pandas() for k, v in self.numeric_count.items()},
			"numeric_rolling": {
				k: v.to_pandas() for k, v in self.numeric_rolling.items()
			},
			"duration": {k: v.to_pandas() for k, v in self.duration.items()},
			"duration_count": {
				k: v.to_pandas() for k, v in self.duration_count.items()
			},
			"string": {k: v.to_pandas() for k, v in self.string.items()},
			"string_count": {k: v.to_pandas() for k, v in self.string_count.items()},
			"boolean": {k: v.to_pandas() for k, v in self.boolean.items()},
			"boolean_count": {k: v.to_pandas() for k, v in self.boolean_count.items()},
		}

	def get_stats_for_column_pandas(self, column: str) -> dict[str, pd.DataFrame]:
		"""Get statistics as pandas DataFrames for columns matching a pattern."""
		return {k: v.to_pandas() for k, v in self.get_stats_for_column(column).items()}

	def get_counts_for_column_pandas(self, column: str) -> dict[str, pd.DataFrame]:
		"""Get value counts as pandas DataFrames for columns matching a pattern."""
		return {k: v.to_pandas() for k, v in self.get_counts_for_column(column).items()}

	def get_rolling_for_column_pandas(self, column: str) -> dict[str, pd.DataFrame]:
		"""Get rolling stats as pandas DataFrames for columns matching a pattern."""
		return {
			k: v.to_pandas() for k, v in self.get_rolling_for_column(column).items()
		}

	def to_polars(self) -> dict[str, dict[str, pl.DataFrame]]:
		"""Get all statistics as Polars DataFrames (returns self structure).

		Returns:
			Nested dict structure: {data_type: {column: pl.DataFrame}}
		"""
		return {
			"datetime": self.datetime,
			"datetime_count": self.datetime_count,
			"numeric": self.numeric,
			"numeric_count": self.numeric_count,
			"numeric_rolling": self.numeric_rolling,
			"duration": self.duration,
			"duration_count": self.duration_count,
			"string": self.string,
			"string_count": self.string_count,
			"boolean": self.boolean,
			"boolean_count": self.boolean_count,
		}

	def to_polars_lazy(self) -> dict[str, dict[str, pl.LazyFrame]]:
		"""Convert all statistics to Polars LazyFrames.

		Returns:
			Nested dict structure: {data_type: {column: pl.LazyFrame}}
		"""
		return {
			"datetime": {k: v.lazy() for k, v in self.datetime.items()},
			"datetime_count": {k: v.lazy() for k, v in self.datetime_count.items()},
			"numeric": {k: v.lazy() for k, v in self.numeric.items()},
			"numeric_count": {k: v.lazy() for k, v in self.numeric_count.items()},
			"numeric_rolling": {k: v.lazy() for k, v in self.numeric_rolling.items()},
			"duration": {k: v.lazy() for k, v in self.duration.items()},
			"duration_count": {k: v.lazy() for k, v in self.duration_count.items()},
			"string": {k: v.lazy() for k, v in self.string.items()},
			"string_count": {k: v.lazy() for k, v in self.string_count.items()},
			"boolean": {k: v.lazy() for k, v in self.boolean.items()},
			"boolean_count": {k: v.lazy() for k, v in self.boolean_count.items()},
		}

	def to_numpy(self) -> dict[str, dict[str, np.ndarray]]:
		"""Convert all statistics to numpy arrays.

		Returns:
			Nested dict structure: {data_type: {column: np.ndarray}}
		"""
		return {
			"datetime": {k: v.to_numpy() for k, v in self.datetime.items()},
			"datetime_count": {k: v.to_numpy() for k, v in self.datetime_count.items()},
			"numeric": {k: v.to_numpy() for k, v in self.numeric.items()},
			"numeric_count": {k: v.to_numpy() for k, v in self.numeric_count.items()},
			"numeric_rolling": {
				k: v.to_numpy() for k, v in self.numeric_rolling.items()
			},
			"duration": {k: v.to_numpy() for k, v in self.duration.items()},
			"duration_count": {k: v.to_numpy() for k, v in self.duration_count.items()},
			"string": {k: v.to_numpy() for k, v in self.string.items()},
			"string_count": {k: v.to_numpy() for k, v in self.string_count.items()},
			"boolean": {k: v.to_numpy() for k, v in self.boolean.items()},
			"boolean_count": {k: v.to_numpy() for k, v in self.boolean_count.items()},
		}


@dataclass
class CorrelationMatrix:
	"""Correlation matrix as a Polars DataFrame.

	Attributes:
		matrix: The correlation matrix as a DataFrame with column names as
			both index (partner_col) and columns.
	"""

	matrix: pl.DataFrame = field(default_factory=pl.DataFrame)

	@classmethod
	def from_dict(cls, data: dict[str, dict[str, float | None]]) -> CorrelationMatrix:
		"""Create from API response dictionary.

		Args:
			data: Nested dict like {"col1": {"col2": 0.5, "col3": 0.3}, ...}

		Returns:
			CorrelationMatrix with the data as a DataFrame.
		"""
		if not data:
			return cls(matrix=pl.DataFrame())

		rows: list[dict[str, Any]] = []
		for partner_col, correlations in data.items():
			row: dict[str, Any] = {"partner_col": partner_col, **correlations}
			rows.append(row)

		return cls(matrix=pl.DataFrame(rows))

	def get_correlation(self, col1: str, col2: str) -> float | None:
		"""Get the correlation between two columns.

		Args:
			col1: First column name.
			col2: Second column name.

		Returns:
			The correlation value, or None if not found.
		"""
		if self.matrix.is_empty():
			return None

		try:
			row = self.matrix.filter(pl.col("partner_col") == col1)
			if row.is_empty() or col2 not in row.columns:
				return None
			return row.select(col2).item()
		except Exception:
			return None

	def to_numpy(self) -> Any:
		"""Convert correlation matrix to numpy array (excluding partner_col)."""
		if self.matrix.is_empty():
			return np.array([])
		return self.matrix.drop("partner_col").to_numpy()

	def to_polars(self) -> pl.DataFrame:
		"""Get the correlation matrix as a Polars DataFrame."""
		return self.matrix

	def to_polars_lazy(self) -> pl.LazyFrame:
		"""Get the correlation matrix as a Polars LazyFrame."""
		return self.matrix.lazy()

	def to_pandas(self) -> pd.DataFrame:
		"""Convert correlation matrix to pandas DataFrame."""
		if self.matrix.is_empty():
			return pd.DataFrame()
		return self.matrix.to_pandas()

	def to_pandas_indexed(self) -> pd.DataFrame:
		"""Convert to pandas DataFrame with partner_col as index."""
		if self.matrix.is_empty():
			return pd.DataFrame()
		pdf = self.matrix.to_pandas()
		return pdf.set_index("partner_col")

	def to_dict(self) -> dict[str, dict[str, float | None]]:
		"""Convert to nested dictionary format.

		Returns:
			Dict like {"col1": {"col2": 0.5, "col3": 0.3}, ...}
		"""
		if self.matrix.is_empty():
			return {}
		result: dict[str, dict[str, float | None]] = {}
		for row in self.matrix.to_dicts():
			partner = row.pop("partner_col")
			result[partner] = row
		return result

	@property
	def columns(self) -> list[str]:
		"""Get the column names in the correlation matrix."""
		if self.matrix.is_empty():
			return []
		return [c for c in self.matrix.columns if c != "partner_col"]


@dataclass
class Statistics:
	"""Complete statistics for a dataset or partition.

	Attributes:
		overall: Overall dataset statistics.
		summary: Summary statistics by column and data type.
		correlation: Correlation matrix for numeric columns.
	"""

	overall: OverallStatistics = field(default_factory=OverallStatistics)
	summary: SummaryStatistics = field(default_factory=SummaryStatistics)
	correlation: CorrelationMatrix = field(default_factory=CorrelationMatrix)

	@classmethod
	def from_dict(cls, data: dict[str, Any]) -> Statistics:
		"""Create from API response dictionary."""
		return cls(
			overall=OverallStatistics.from_dict(data.get("overall_statistics", {})),
			summary=SummaryStatistics.from_dict(data.get("statistics", {})),
			correlation=CorrelationMatrix.from_dict(
				data.get("correlation_statistics", {})
			),
		)

	def to_dict(self) -> dict[str, Any]:
		"""Convert all statistics to dictionaries."""
		return {
			"overall_statistics": self.overall.to_dict(),
			"statistics": self.summary.to_dict(),
			"correlation_statistics": self.correlation.to_dict(),
		}

	def to_pandas(self) -> dict[str, Any]:
		"""Convert all statistics to pandas format.

		Returns:
			Dict with 'overall' as DataFrame, 'summary' as nested dict of DataFrames,
			and 'correlation' as DataFrame.
		"""
		return {
			"overall_statistics": self.overall.to_pandas(),
			"statistics": self.summary.to_pandas(),
			"correlation_statistics": self.correlation.to_pandas(),
		}

	def to_polars(self) -> dict[str, Any]:
		"""Convert all statistics to Polars format.

		Returns:
			Dict with 'overall' as DataFrame, 'summary' as nested dict of DataFrames,
			and 'correlation' as DataFrame.
		"""
		return {
			"overall_statistics": self.overall.to_polars(),
			"statistics": self.summary.to_polars(),
			"correlation_statistics": self.correlation.to_polars(),
		}

	def to_polars_lazy(self) -> dict[str, Any]:
		"""Convert all statistics to Polars LazyFrame format.

		Returns:
			Dict with 'overall' as LazyFrame, 'summary' as nested dict of LazyFrames,
			and 'correlation' as LazyFrame.
		"""
		return {
			"overall_statistics": self.overall.to_polars_lazy(),
			"statistics": self.summary.to_polars_lazy(),
			"correlation_statistics": self.correlation.to_polars_lazy(),
		}

	def to_numpy(self) -> dict[str, Any]:
		"""Convert all statistics to numpy format.

		Returns:
			Dict with 'overall' as array, 'summary' as nested dict of arrays,
			and 'correlation' as array.
		"""
		return {
			"overall_statistics": self.overall.to_numpy(),
			"statistics": self.summary.to_numpy(),
			"correlation_statistics": self.correlation.to_numpy(),
		}


@dataclass
class InspectResult:
	"""Result from inspecting a dataset.

	Contains either partitioned statistics (if partition_by was used)
	or non-partitioned statistics for the whole dataset.

	Attributes:
		partitioned: Dictionary mapping partition keys to Statistics objects.
			None if data was not partitioned.
		non_partitioned: Statistics for the whole dataset.
			None if data was partitioned.

	Example:
		>>> result = sdk.inspect(df)
		>>> # Access non-partitioned stats
		>>> result.stats.overall.height
		1000
		>>> result.stats.summary.numeric["price"]
		shape: (1, 25)
		...

		>>> # Access partitioned stats
		>>> result = sdk.inspect(df, partition_by=["category"])
		>>> result.partitions
		['_electronics', '_clothing']
		>>> result["_electronics"].overall.height
		500
	"""

	partitioned: dict[str, Statistics] | None = None
	non_partitioned: Statistics | None = None
	raw_json_: dict[str, Any] = field(default_factory=dict, repr=False)

	@classmethod
	def from_dict(cls, data: dict[str, Any]) -> InspectResult:
		"""Create from API response dictionary."""
		partitioned_data = data.get("partitioned_statistics")
		non_partitioned_data = data.get("non_partitioned_statistics")

		partitioned = None
		if partitioned_data is not None:
			partitioned = {
				key: Statistics.from_dict(value)
				for key, value in partitioned_data.items()
			}

		non_partitioned = None
		if non_partitioned_data is not None:
			non_partitioned = Statistics.from_dict(non_partitioned_data)

		return cls(
			partitioned=partitioned,
			non_partitioned=non_partitioned,
			raw_json_=data,
		)

	@property
	def is_partitioned(self) -> bool:
		"""Whether the result contains partitioned statistics."""
		return self.partitioned is not None

	@property
	def partitions(self) -> list[str]:
		"""List of partition keys (empty if not partitioned)."""
		if self.partitioned is None:
			return []
		return list(self.partitioned.keys())

	@property
	def stats(self) -> Statistics:
		"""Get statistics (non-partitioned or first partition).

		For non-partitioned data, returns the statistics directly.
		For partitioned data, raises an error - use indexing instead.

		Raises:
			ValueError: If data is partitioned.
		"""
		if self.non_partitioned is not None:
			return self.non_partitioned
		if self.partitioned is not None:
			raise ValueError(
				"Data is partitioned. Use result[partition_key] to access "
				f"specific partitions. Available: {self.partitions}"
			)
		raise ValueError("No statistics available")

	def __getitem__(self, key: str) -> Statistics:
		"""Get statistics for a specific partition.

		Args:
			key: The partition key.

		Returns:
			Statistics for the specified partition.

		Raises:
			KeyError: If the partition key is not found.
		"""
		if self.partitioned is None:
			raise KeyError(
				"Data is not partitioned. Use result.stats to access statistics."
			)
		if key not in self.partitioned:
			raise KeyError(f"Partition '{key}' not found. Available: {self.partitions}")
		return self.partitioned[key]

	def __iter__(self):
		"""Iterate over partition keys (or single empty key for non-partitioned)."""
		if self.partitioned is not None:
			return iter(self.partitioned.keys())
		return iter([""])

	def items(self) -> list[tuple[str, Statistics]]:
		"""Iterate over (partition_key, Statistics) pairs."""
		if self.partitioned is not None:
			return list(self.partitioned.items())
		if self.non_partitioned is not None:
			return [("", self.non_partitioned)]
		return []

	def filter_partitions(self, pattern: str) -> dict[str, Statistics]:
		"""Filter partitions by name (case-insensitive substring match).

		Args:
			pattern: Substring to match partition names.

		Returns:
			Dict of matching partition names to Statistics.

		Example:
			>>> result.filter_partitions("electronics")
			{'_electronics': Statistics(...), '_electronics_sale': Statistics(...)}
		"""
		if self.partitioned is None:
			return {}
		return {
			k: v for k, v in self.partitioned.items() if pattern.lower() in k.lower()
		}

	def filter(
		self,
		partition: str | None = None,
		column: str | None = None,
		datatype: str | None = None,
	) -> dict[str, dict[str, dict[str, pl.DataFrame]]]:
		"""Filter statistics across partitions, columns, and datatypes.

		All filters are case-insensitive substring matches.

		Args:
			partition: Filter partition names (ignored for non-partitioned data).
			column: Filter column names in summary statistics.
			datatype: Filter datatype names (e.g., "numeric", "count").

		Returns:
			Nested dict: {partition: {datatype: {column: DataFrame}}}
			For non-partitioned data, partition key is empty string.

		Example:
			>>> # Get all numeric stats for "price" columns across all partitions
			>>> result.filter(column="price", datatype="numeric")
			>>> # Get all stats for a specific partition
			>>> result.filter(partition="electronics")
			>>> # Get string counts for "status" column
			>>> result.filter(column="status", datatype="string_count")
		"""
		result: dict[str, dict[str, dict[str, pl.DataFrame]]] = {}

		items_list: list[tuple[str, Statistics]] = []
		if self.partitioned is not None:
			for k, v in self.partitioned.items():
				if partition and partition.lower() not in k.lower():
					continue
				items_list.append((k, v))
		elif self.non_partitioned is not None:
			items_list.append(("", self.non_partitioned))

		for part_key, stats in items_list:
			filtered = stats.summary.filter(column=column, datatype=datatype)
			if filtered:
				result[part_key] = filtered

		return result

	def to_dict(self) -> dict[str, Any]:
		"""Convert to dictionary format matching API response structure."""
		result: dict[str, Any] = {
			"partitioned_statistics": None,
			"non_partitioned_statistics": None,
		}
		if self.partitioned is not None:
			result["partitioned_statistics"] = {
				k: v.to_dict() for k, v in self.partitioned.items()
			}
		if self.non_partitioned is not None:
			result["non_partitioned_statistics"] = self.non_partitioned.to_dict()
		return result

	def to_pandas(self) -> dict[str, Any]:
		"""Convert to pandas format.

		Returns:
			Dict with 'partitioned_statistics' or 'non_partitioned_statistics'
			containing pandas DataFrames.
		"""
		result: dict[str, Any] = {
			"partitioned_statistics": None,
			"non_partitioned_statistics": None,
		}
		if self.partitioned is not None:
			result["partitioned_statistics"] = {
				k: v.to_pandas() for k, v in self.partitioned.items()
			}
		if self.non_partitioned is not None:
			result["non_partitioned_statistics"] = self.non_partitioned.to_pandas()
		return result

	def to_polars(self) -> dict[str, Any]:
		"""Convert to Polars format.

		Returns:
			Dict with 'partitioned_statistics' or 'non_partitioned_statistics'
			containing Polars DataFrames.
		"""
		result: dict[str, Any] = {
			"partitioned_statistics": None,
			"non_partitioned_statistics": None,
		}
		if self.partitioned is not None:
			result["partitioned_statistics"] = {
				k: v.to_polars() for k, v in self.partitioned.items()
			}
		if self.non_partitioned is not None:
			result["non_partitioned_statistics"] = self.non_partitioned.to_polars()
		return result

	def to_polars_lazy(self) -> dict[str, Any]:
		"""Convert to Polars LazyFrame format.

		Returns:
			Dict with 'partitioned_statistics' or 'non_partitioned_statistics'
			containing Polars LazyFrames.
		"""
		result: dict[str, Any] = {
			"partitioned_statistics": None,
			"non_partitioned_statistics": None,
		}
		if self.partitioned is not None:
			result["partitioned_statistics"] = {
				k: v.to_polars_lazy() for k, v in self.partitioned.items()
			}
		if self.non_partitioned is not None:
			result["non_partitioned_statistics"] = self.non_partitioned.to_polars_lazy()
		return result

	def to_numpy(self) -> dict[str, Any]:
		"""Convert to numpy format.

		Returns:
			Dict with 'partitioned_statistics' or 'non_partitioned_statistics'
			containing numpy arrays.
		"""
		result: dict[str, Any] = {
			"partitioned_statistics": None,
			"non_partitioned_statistics": None,
		}
		if self.partitioned is not None:
			result["partitioned_statistics"] = {
				k: v.to_numpy() for k, v in self.partitioned.items()
			}
		if self.non_partitioned is not None:
			result["non_partitioned_statistics"] = self.non_partitioned.to_numpy()
		return result


@dataclass
class InspectBatchResult:
	"""Result from inspecting multiple files.

	Attributes:
		files: Dictionary mapping filenames to their InspectResult.
	"""

	files: dict[str, InspectResult] = field(
		default_factory=lambda: {}  # type: ignore[arg-type]
	)

	@classmethod
	def from_dict(cls, data: dict[str, Any]) -> InspectBatchResult:
		"""Create from API response dictionary."""
		statistics = data.get("statistics", {})
		files: dict[str, InspectResult] = {}

		for filename, file_stats in statistics.items():
			if file_stats is not None:
				files[filename] = InspectResult.from_dict(file_stats)

		return cls(files=files)

	@property
	def filenames(self) -> list[str]:
		"""List of filenames in the batch result."""
		return list(self.files.keys())

	def __getitem__(self, key: str) -> InspectResult:
		"""Get result for a specific file."""
		return self.files[key]

	def __iter__(self):
		"""Iterate over filenames."""
		return iter(self.files.keys())

	def items(self) -> list[tuple[str, InspectResult]]:
		"""Iterate over (filename, InspectResult) pairs."""
		return list(self.files.items())

	def count(self) -> int:
		"""Return the number of files in the batch result."""
		return len(self.files)

	def to_dict(self) -> dict[str, dict[str, Any]]:
		"""Convert all results to dictionaries."""
		return {filename: result.to_dict() for filename, result in self.files.items()}

	def to_pandas(self) -> dict[str, dict[str, Any]]:
		"""Convert all results to pandas format."""
		return {filename: result.to_pandas() for filename, result in self.files.items()}

	def to_polars(self) -> dict[str, dict[str, Any]]:
		"""Convert all results to Polars format."""
		return {filename: result.to_polars() for filename, result in self.files.items()}

	def to_polars_lazy(self) -> dict[str, dict[str, Any]]:
		"""Convert all results to Polars LazyFrame format."""
		return {
			filename: result.to_polars_lazy() for filename, result in self.files.items()
		}

	def to_numpy(self) -> dict[str, dict[str, Any]]:
		"""Convert all results to numpy format."""
		return {filename: result.to_numpy() for filename, result in self.files.items()}
