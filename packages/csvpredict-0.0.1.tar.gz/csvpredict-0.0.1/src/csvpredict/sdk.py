from __future__ import annotations

import base64
import io
import os
import webbrowser
import zipfile
from collections.abc import Iterator
from dataclasses import dataclass, field
from http import HTTPStatus
from pathlib import Path
from typing import Literal

import httpx
import pandas as pd
import polars as pl
from IPython.display import HTML, IFrame, display  # type: ignore
from PIL import Image as PILImage
from pyspark.sql import DataFrame as SparkDataFrame

from .client import Client
from .client.models.body_endpoint_generate_graphs_api_v1_graphs_post import (
	BodyEndpointGenerateGraphsApiV1GraphsPost,
)
from .client.models.body_endpoint_generate_graphs_api_v1_graphs_post_extension import (
	BodyEndpointGenerateGraphsApiV1GraphsPostExtension,
)
from .client.models.body_endpoint_generate_pptx_api_v1_pptx_post import (
	BodyEndpointGeneratePptxApiV1PptxPost,
)
from .client.models.body_endpoint_generate_xlsx_api_v1_xlsx_post import (
	BodyEndpointGenerateXlsxApiV1XlsxPost,
)
from .client.models.body_endpoint_inspect_api_v1_inspect_post import (
	BodyEndpointInspectApiV1InspectPost,
)
from .client.models.color_palette import ColorPalette
from .client.models.font_family import FontFamily
from .client.models.language import Language
from .client.types import UNSET, File
from .models import InspectResult
from .server import set_download_context, show_inspect

type DataFrameType = pl.DataFrame | pl.LazyFrame | pd.DataFrame | SparkDataFrame

ImageExtension = Literal[".png", ".jpg", ".jpeg", ".svg"]


def extension_to_enum_(
	ext: ImageExtension,
) -> BodyEndpointGenerateGraphsApiV1GraphsPostExtension:
	"""Convert string extension to enum value."""
	mapping = {
		".png": BodyEndpointGenerateGraphsApiV1GraphsPostExtension.VALUE_0,
		".jpg": BodyEndpointGenerateGraphsApiV1GraphsPostExtension.VALUE_1,
		".jpeg": BodyEndpointGenerateGraphsApiV1GraphsPostExtension.VALUE_2,
		".svg": BodyEndpointGenerateGraphsApiV1GraphsPostExtension.VALUE_3,
	}
	return mapping.get(ext, BodyEndpointGenerateGraphsApiV1GraphsPostExtension.VALUE_3)


def dataframe_to_bytes_(df: DataFrameType) -> bytes:
	"""
	Convert a pandas/polars/PySpark DataFrame or LazyFrame to Parquet bytes.

	Args:
		df: Input DataFrame or LazyFrame (Polars, pandas, or PySpark).

	Returns:
		Parquet data as bytes.

	Raises:
		TypeError: If df is not a supported DataFrame type.
	"""

	if isinstance(df, pl.LazyFrame):
		polars_df = df.collect()
	elif isinstance(df, pl.DataFrame):
		polars_df = df
	elif isinstance(df, pd.DataFrame):
		polars_df = pl.from_pandas(df)
	else:
		polars_df = pl.DataFrame(df.toArrow())

	buffer = io.BytesIO()
	polars_df.write_parquet(buffer)
	return buffer.getvalue()


def dataframe_to_polars_(df: DataFrameType) -> pl.DataFrame:
	"""
	Convert a pandas/polars/PySpark DataFrame or LazyFrame to Polars DataFrame.

	Args:
		df: Input DataFrame or LazyFrame (Polars, pandas, or PySpark).

	Returns:
		Polars DataFrame.
	"""

	if isinstance(df, pl.LazyFrame):
		return df.collect()
	elif isinstance(df, pl.DataFrame):
		return df
	elif isinstance(df, pd.DataFrame):
		return pl.from_pandas(df)
	else:
		return pl.DataFrame(df.toArrow())


def create_file_from_dataframe_(
	df: DataFrameType,
	filename: str = "data.parquet",
) -> File:
	"""Create a File object from a DataFrame."""
	bytes_data = dataframe_to_bytes_(df)
	return File(
		payload=io.BytesIO(bytes_data),
		file_name=filename,
		mime_type="application/vnd.apache.parquet",
	)


@dataclass
class GraphResult:
	"""Result from generating graphs - fully in-memory with Jupyter display support.

	All graph data is loaded into memory from the ZIP, so you never need to
	write files to disk unless you want to.

	Example:
		>>> result = sdk.generate_graphs(df)
		>>>
		>>> # Display all graphs in Jupyter
		>>> result.display()
		>>>
		>>> # Display only histograms
		>>> result.display("*histogram*")
		>>>
		>>> # Display specific graph
		>>> result.display("price_histogram.svg")
		>>>
		>>> # Get raw bytes for a specific graph
		>>> svg_bytes = result["price_histogram.svg"]
		>>>
		>>> # Get as PIL Image (for raster formats)
		>>> img = result.to_pil("price_histogram.png")
		>>>
		>>> # Iterate over all graphs
		>>> for name, data in result:
		...     print(f"{name}: {len(data)} bytes")
		>>>
		>>> # Filter and iterate
		>>> for name, data in result.filter("*correlation*"):
		...     print(name)
	"""

	zip_content: bytes
	"""Raw ZIP file content containing all generated graphs."""

	images_: dict[str, bytes] = field(default_factory=dict, repr=False)  # type: ignore
	"""Cached image data keyed by filename."""

	def __post_init__(self) -> None:
		"""Load all images into memory from the ZIP."""
		with zipfile.ZipFile(io.BytesIO(self.zip_content)) as zf:
			for name in zf.namelist():
				if not name.endswith("/"):  # Skip directories
					self.images_[name] = zf.read(name)

	def __getitem__(self, name: str) -> bytes:
		"""Get raw bytes for a specific graph by filename.

		Args:
			name: The filename of the graph.

		Returns:
			Raw bytes of the image file.

		Raises:
			KeyError: If the filename is not found.
		"""
		if name not in self.images_:
			raise KeyError(f"Graph '{name}' not found. Available: {self.names}")
		return self.images_[name]

	def __iter__(self) -> Iterator[tuple[str, bytes]]:
		"""Iterate over (filename, bytes) pairs."""
		return iter(self.images_.items())

	def count(self) -> int:
		"""Return the number of graphs in the result."""
		return len(self.images_)

	def contains(self, name: str) -> bool:
		"""Check if a graph exists by filename.

		Args:
			name: The filename to check.

		Returns:
			True if the graph exists, False otherwise.

		Example:
			>>> if graphs.contains("price_histogram.svg"):
			...     print("Found it!")
		"""
		return name in self.images_

	@property
	def images(self) -> dict[str, bytes]:
		"""Dictionary of all images keyed by filename."""
		return self.images_

	@property
	def names(self) -> list[str]:
		"""List of all graph filenames."""
		return list(self.images_.keys())

	@property
	def extension(self) -> str:
		"""Get the file extension of the graphs (e.g., '.svg', '.png')."""
		if self.images_:
			first_name = next(iter(self.images_.keys()))
			return Path(first_name).suffix
		return ""

	def filter(
		self,
		pattern: str | None = None,
		*,
		extension: str | None = None,
	) -> Iterator[tuple[str, bytes]]:
		"""Filter graphs by substring pattern or extension (case-insensitive).

		Args:
			pattern: Substring to match in filenames (case-insensitive).
				e.g., "histogram" matches "Price_Histogram.svg".
			extension: Filter by file extension (e.g., ".svg", ".png").

		Yields:
			Tuples of (filename, bytes) for matching graphs.

		Example:
			>>> # Get all histograms (case-insensitive)
			>>> list(result.filter("histogram"))
			>>> # Get all PNG files
			>>> list(result.filter(extension=".png"))
			>>> # Get all price-related graphs
			>>> list(result.filter("price"))
		"""
		for name, data in self.images_.items():
			if pattern and pattern.lower() not in name.lower():
				continue
			if extension and not name.lower().endswith(extension.lower()):
				continue
			yield name, data

	def get(self, name: str, default: bytes | None = None) -> bytes | None:
		"""Get raw bytes for a graph, or default if not found."""
		return self.images_.get(name, default)

	def to_pil(self, name: str) -> PILImage.Image:
		"""Convert a raster image to PIL Image.

		Only works for raster formats (PNG, JPG, JPEG). For SVG, use
		the raw bytes directly or convert with an SVG library.

		Args:
			name: The filename of the graph.

		Returns:
			PIL Image object.

		Raises:
			KeyError: If the filename is not found.
			ValueError: If the file is an SVG (not supported).
		"""
		if name.lower().endswith(".svg"):
			raise ValueError(
				"SVG cannot be converted to PIL Image. "
				"Use result[name] for raw SVG bytes."
			)
		return PILImage.open(io.BytesIO(self[name]))

	def display(
		self,
		pattern: str | None = None,
		*,
		extension: str | None = None,
		width: int = 400,
		height: int | None = None,
		columns: int = 2,
	) -> None:
		"""Display graphs in a Jupyter notebook.

		Args:
			pattern: Substring to filter graphs (case-insensitive).
				e.g., "histogram" matches "Price_Histogram.svg".
			extension: Filter by file extension.
			width: Display width in pixels (default 400).
			height: Display height in pixels (None for auto/preserve aspect ratio).
			columns: Number of columns for grid layout (default 2).

		Example:
			>>> result.display()  # Show all at default size
			>>> result.display(width=600)  # Larger
			>>> result.display("histogram", width=300, height=200)
		"""
		matching = list(self.filter(pattern, extension=extension))

		if not matching:
			print("No graphs match the filter criteria.")
			return

		if len(matching) > 1:
			col_width = f"{width}px"
			grid_style = (
				f"display: grid; "
				f"grid-template-columns: repeat({columns}, {col_width}); "
				f"gap: 10px;"
			)
			cell_style = (
				"border: 1px solid #ddd; padding: 10px; "
				"overflow: hidden; box-sizing: border-box;"
			)
			height_css = f"{height}px" if height else "auto"
			svg_inner = f"width: 100%; height: {height_css}; display: block;"
			html_parts = [f'<div style="{grid_style}">']

			for name, data in matching:
				if name.lower().endswith(".svg"):
					svg_str = data.decode("utf-8")
					if "<svg" in svg_str:
						svg_str = svg_str.replace(
							"<svg",
							f'<svg style="{svg_inner}"',
							1,
						)
					title_style = "font-weight: bold; margin-bottom: 5px;"
					title = f'<div style="{title_style}">{name}</div>'
					html_parts.append(
						f'<div style="{cell_style}">{title}{svg_str}</div>'
					)
				else:
					ext = Path(name).suffix.lower()
					mime = {
						".png": "image/png",
						".jpg": "image/jpeg",
						".jpeg": "image/jpeg",
					}.get(ext, "image/png")
					b64 = base64.b64encode(data).decode("utf-8")
					title_style = "font-weight: bold; margin-bottom: 5px;"
					title = f'<div style="{title_style}">{name}</div>'
					img_style = f"width: 100%; height: {height_css}; display: block;"
					img = f'<img src="data:{mime};base64,{b64}" style="{img_style}"/>'
					html_parts.append(f'<div style="{cell_style}">{title}{img}</div>')

			html_parts.append("</div>")
			display(HTML("".join(html_parts)))
		else:
			name, data = matching[0]
			print(f"📊 {name}")
			height_css = f"{height}px" if height else "auto"
			if name.lower().endswith(".svg"):
				svg_str = data.decode("utf-8")
				svg_inner = f"width: 100%; height: {height_css}; display: block;"
				if "<svg" in svg_str:
					svg_str = svg_str.replace("<svg", f'<svg style="{svg_inner}"', 1)
				style = f"width: {width}px; overflow: hidden;"
				display(HTML(f'<div style="{style}">{svg_str}</div>'))
			else:
				img_style = f"width: {width}px; height: {height_css};"
				b64 = base64.b64encode(data).decode("utf-8")
				ext = Path(name).suffix.lower()
				mime = {".png": "image/png", ".jpg": "image/jpeg"}.get(ext, "image/png")
				img_tag = f'<img src="data:{mime};base64,{b64}" style="{img_style}"/>'
				display(HTML(img_tag))

	def display_one(
		self, name: str, *, width: int = 400, height: int | None = None
	) -> None:
		"""Display a single graph by exact filename.

		Args:
			name: Exact filename of the graph.
			width: Display width in pixels (default 400).
			height: Display height in pixels (None for auto/preserve aspect ratio).
		"""
		data = self[name]
		print(f"📊 {name}")
		height_css = f"{height}px" if height else "auto"
		if name.lower().endswith(".svg"):
			svg_str = data.decode("utf-8")
			svg_inner = f"width: 100%; height: {height_css}; display: block;"
			if "<svg" in svg_str:
				svg_str = svg_str.replace("<svg", f'<svg style="{svg_inner}"', 1)
			style = f"width: {width}px; overflow: hidden;"
			display(HTML(f'<div style="{style}">{svg_str}</div>'))
		else:
			img_style = f"width: {width}px; height: {height_css};"
			b64 = base64.b64encode(data).decode("utf-8")
			ext = Path(name).suffix.lower()
			mime = {".png": "image/png", ".jpg": "image/jpeg"}.get(ext, "image/png")
			display(HTML(f'<img src="data:{mime};base64,{b64}" style="{img_style}"/>'))

	def save(self, path: str | Path) -> Path:
		"""Save the ZIP file to disk.

		Args:
			path: Destination path for the ZIP file.

		Returns:
			The path where the file was saved.
		"""
		path = Path(path)
		path.write_bytes(self.zip_content)
		return path

	def extract(self, directory: str | Path) -> list[Path]:
		"""Extract all graphs to a directory.

		Args:
			directory: Directory to extract graphs to.

		Returns:
			List of paths to extracted files.
		"""
		directory = Path(directory)
		directory.mkdir(parents=True, exist_ok=True)

		extracted_files: list[Path] = []
		with zipfile.ZipFile(io.BytesIO(self.zip_content)) as zf:
			for name in zf.namelist():
				zf.extract(name, directory)
				extracted_files.append(directory / name)

		return extracted_files

	def list_files(self) -> list[str]:
		"""List all files in the ZIP archive.

		Returns:
			List of filenames in the archive.
		"""
		with zipfile.ZipFile(io.BytesIO(self.zip_content)) as zf:
			return zf.namelist()


@dataclass
class ExcelResult:
	"""Result from generating Excel files - contains a ZIP with .xlsx files.

	Example:
		>>> result = sdk.generate_xlsx(df)
		>>>
		>>> # Save ZIP to disk
		>>> result.save("excel_output.zip")
		>>>
		>>> # Extract all files
		>>> result.extract("./excel_files/")
		>>>
		>>> # List all files
		>>> print(result.names)
		>>>
		>>> # Get raw bytes for a specific file
		>>> xlsx_bytes = result["data_statistics.xlsx"]
	"""

	zip_content: bytes
	"""Raw ZIP file content containing all generated Excel files."""

	files_: dict[str, bytes] = field(default_factory=dict, repr=False)  # type: ignore
	"""Cached file data keyed by filename."""

	def __post_init__(self) -> None:
		"""Load all files into memory from the ZIP."""
		with zipfile.ZipFile(io.BytesIO(self.zip_content)) as zf:
			for name in zf.namelist():
				if not name.endswith("/"):  # Skip directories
					self.files_[name] = zf.read(name)

	def __getitem__(self, name: str) -> bytes:
		"""Get raw bytes for a specific file by filename."""
		if name not in self.files_:
			raise KeyError(f"File '{name}' not found. Available: {self.names}")
		return self.files_[name]

	def __iter__(self) -> Iterator[tuple[str, bytes]]:
		"""Iterate over (filename, bytes) pairs."""
		return iter(self.files_.items())

	@property
	def files(self) -> dict[str, bytes]:
		"""Dictionary of all files keyed by filename."""
		return self.files_

	@property
	def names(self) -> list[str]:
		"""List of all filenames in the ZIP."""
		return list(self.files_.keys())

	def count(self) -> int:
		"""Return the number of files in the result."""
		return len(self.files_)

	def contains(self, name: str) -> bool:
		"""Check if a file exists by filename.

		Args:
			name: The filename to check.

		Returns:
			True if the file exists, False otherwise.
		"""
		return name in self.files_

	def save(self, path: str | Path) -> Path:
		"""Save the ZIP file to disk.

		Args:
			path: Destination path for the ZIP file.

		Returns:
			The path where the file was saved.
		"""
		path = Path(path)
		path.write_bytes(self.zip_content)
		return path

	def extract(self, directory: str | Path) -> list[Path]:
		"""Extract all files to a directory.

		Args:
			directory: Directory to extract files to.

		Returns:
			List of paths to extracted files.
		"""
		directory = Path(directory)
		directory.mkdir(parents=True, exist_ok=True)

		extracted_files: list[Path] = []
		with zipfile.ZipFile(io.BytesIO(self.zip_content)) as zf:
			for name in zf.namelist():
				zf.extract(name, directory)
				extracted_files.append(directory / name)

		return extracted_files


@dataclass
class PowerPointResult:
	"""Result from generating PowerPoint files - contains a ZIP with .pptx files.

	Example:
		>>> result = sdk.generate_pptx(df)
		>>>
		>>> # Save ZIP to disk
		>>> result.save("pptx_output.zip")
		>>>
		>>> # Extract all files
		>>> result.extract("./presentations/")
		>>>
		>>> # List all files
		>>> print(result.names)
		>>>
		>>> # Get raw bytes for a specific file
		>>> pptx_bytes = result["data_presentation.pptx"]
	"""

	zip_content: bytes
	"""Raw ZIP file content containing all generated PowerPoint files."""

	files_: dict[str, bytes] = field(default_factory=dict, repr=False)  # type: ignore
	"""Cached file data keyed by filename."""

	def __post_init__(self) -> None:
		"""Load all files into memory from the ZIP."""
		with zipfile.ZipFile(io.BytesIO(self.zip_content)) as zf:
			for name in zf.namelist():
				if not name.endswith("/"):
					self.files_[name] = zf.read(name)

	def __getitem__(self, name: str) -> bytes:
		"""Get raw bytes for a specific file by filename."""
		if name not in self.files_:
			raise KeyError(f"File '{name}' not found. Available: {self.names}")
		return self.files_[name]

	def __iter__(self) -> Iterator[tuple[str, bytes]]:
		"""Iterate over (filename, bytes) pairs."""
		return iter(self.files_.items())

	@property
	def files(self) -> dict[str, bytes]:
		"""Dictionary of all files keyed by filename."""
		return self.files_

	@property
	def names(self) -> list[str]:
		"""List of all filenames in the ZIP."""
		return list(self.files_.keys())

	def count(self) -> int:
		"""Return the number of files in the result."""
		return len(self.files_)

	def contains(self, name: str) -> bool:
		"""Check if a file exists by filename.

		Args:
			name: The filename to check.

		Returns:
			True if the file exists, False otherwise.
		"""
		return name in self.files_

	def save(self, path: str | Path) -> Path:
		"""Save the ZIP file to disk.

		Args:
			path: Destination path for the ZIP file.

		Returns:
			The path where the file was saved.
		"""
		path = Path(path)
		path.write_bytes(self.zip_content)
		return path

	def extract(self, directory: str | Path) -> list[Path]:
		"""Extract all files to a directory.

		Args:
			directory: Directory to extract files to.

		Returns:
			List of paths to extracted files.
		"""
		directory = Path(directory)
		directory.mkdir(parents=True, exist_ok=True)

		extracted_files: list[Path] = []
		with zipfile.ZipFile(io.BytesIO(self.zip_content)) as zf:
			for name in zf.namelist():
				zf.extract(name, directory)
				extracted_files.append(directory / name)

		return extracted_files


class CSVPredict:
	"""High-level SDK for the CSVPredict API.

	Example:
		>>> sdk = CSVPredict(base_url="http://localhost:8000")
		>>> graphs = sdk.generate_graphs(my_dataframe)
		>>> graphs.save("output.zip")

		>>> # Or open in browser
		>>> sdk.inspect_in_browser(my_dataframe)
	"""

	def __init__(
		self,
		*,
		api_key: str | None = None,
		base_url: str = "https://csvpredict.com/api/v1",
		timeout: float | None = 60.0,
	):
		"""Initialize the CSVPredict SDK.

		Args:
			base_url: Base URL of the CSVPredict API.
			frontend_url: Base URL of the CSVPredict frontend.
			timeout: Request timeout in seconds.
		"""

		if not ("localhost" in base_url or "127.0.0.1" in base_url):
			if not api_key:
				api_key = os.getenv("CSVPREDICT_API_KEY")
			if not api_key:
				raise ValueError(
					"API key must be provided either via parameter or "
					"CSVPREDICT_API_KEY environment variable."
				)
		else:
			api_key = ""

		self.api_key: str = api_key
		self.base_url: str = base_url
		self.timeout: float | None = timeout
		self.client_: Client = Client(
			base_url=self.base_url,
			timeout=httpx.Timeout(self.timeout) if self.timeout else None,
		)

	def generate_graphs(
		self,
		df: DataFrameType,
		*,
		partition_by: list[str] | None = None,
		extension: ImageExtension = ".svg",
		transparent: bool = False,
		window_size: int = 5,
		null_values: list[str] | None = None,
		dpi: int = 1000,
		font: FontFamily | None = None,
		language: Language | None = None,
	) -> GraphResult:
		"""Generate analysis graphs for the given data.

		Args:
			df: A pandas DataFrame, polars DataFrame, or polars LazyFrame.
			partition_by: Columns to partition the data by.
			extension: Image file extension (.png, .jpg, .jpeg, .svg).
			transparent: Whether graph backgrounds should be transparent.
			window_size: Window size for rolling statistics.
			null_values: Strings to treat as null values.
			dpi: Resolution (dots per inch) for generated graphs.
			font: Font family for graph text.
			language: Language for graph titles.

		Returns:
			GraphResult containing the ZIP file with all generated graphs.

		Raises:
			httpx.HTTPStatusError: If the API returns an error status.
			ValueError: If the API returns a validation error.
		"""
		file = create_file_from_dataframe_(df)

		body = BodyEndpointGenerateGraphsApiV1GraphsPost(
			file=file,
			partition_by=partition_by if partition_by is not None else UNSET,
			extension=extension_to_enum_(extension),
			transparent=transparent,
			window_size=window_size,
			null_values=null_values if null_values is not None else UNSET,
			dpi=dpi,
			font=font if font is not None else UNSET,
			language=language if language is not None else UNSET,
		)

		httpx_client = self.client_.get_httpx_client()
		response = httpx_client.post(
			url="/graphs/",
			headers={"X-API-Key": self.api_key},
			files=body.to_multipart(),
		)

		if response.status_code != HTTPStatus.OK:
			try:
				error_detail = response.json()
			except Exception:
				error_detail = response.text
			raise ValueError(f"API error {response.status_code}: {error_detail}")

		return GraphResult(zip_content=response.content)

	def inspect(
		self,
		df: DataFrameType,
		*,
		partition_by: list[str] | None = None,
		window_size: int = 5,
		round_digits: int = 2,
		null_values: list[str] | None = None,
	) -> InspectResult:
		"""Get visualizable statistics for the given data.

		Args:
			df: A pandas DataFrame, polars DataFrame, or polars LazyFrame.
			partition_by: Columns to partition the data by.
			window_size: Window size for rolling calculations.
			round_digits: Number of decimal places to round results.
			null_values: Strings to treat as null values.

		Returns:
			InspectResult containing statistics as Polars DataFrames.

		Raises:
			httpx.HTTPStatusError: If the API returns an error status.
			ValueError: If the API returns a validation error.

		Example:
			>>> result = sdk.inspect(df)
			>>> result.stats.overall.height
			1000
			>>> result.stats.summary.numeric["price"]
			shape: (1, 25)
			...
			>>> result.stats.correlation.matrix
			shape: (3, 4)
			...

			>>> # With partitioning
			>>> result = sdk.inspect(df, partition_by=["category"])
			>>> result.partitions
			['_electronics', '_clothing']
			>>> result["_electronics"].summary.numeric["price"]
		"""

		file = create_file_from_dataframe_(df)

		body = BodyEndpointInspectApiV1InspectPost(
			file=file,
			partition_by=partition_by if partition_by is not None else UNSET,
			window_size=window_size,
			round_=round_digits,
			null_values=null_values if null_values is not None else UNSET,
		)

		httpx_client = self.client_.get_httpx_client()
		response = httpx_client.post(
			url="/inspect/",
			headers={"X-API-Key": self.api_key},
			files=body.to_multipart(),
		)

		if response.status_code != HTTPStatus.OK:
			try:
				error_detail = response.json()
			except Exception:
				error_detail = response.text
			raise ValueError(f"API error {response.status_code}: {error_detail}")

		return InspectResult.from_dict(response.json())

	def inspect_in_browser(
		self,
		df: DataFrameType,
		*,
		partition_by: list[str] | None = None,
		window_size: int = 5,
		round_digits: int = 2,
		null_values: list[str] | None = None,
		reuse_tab: bool = True,
		port: int = 8765,
		show_in_ipynb: bool = False,
		height: int = 800,
	) -> None:
		"""Inspect data and open the results in a browser.

		This method sends the data to the API, gets the statistics,
		and opens an interactive visualization page in your browser.

		Args:
			df: A pandas DataFrame, polars DataFrame, or polars LazyFrame.
			partition_by: Columns to partition the data by.
			window_size: Window size for rolling calculations.
			round_digits: Number of decimal places to round results.
			null_values: Strings to treat as null values.
			reuse_tab: If True (default), reuse existing tab via live reload.
				If False, open a new tab each time (for side-by-side comparison).
			port: Port for the visualization server.

		Returns:
			None

		Raises:
			httpx.HTTPStatusError: If the API returns an error status.
			ValueError: If the API returns a validation error.

		Example:
			>>> sdk.inspect_in_browser(df)  # Opens browser
			>>> sdk.inspect_in_browser(df2)  # Reuses same tab
			>>>
			>>> # Open new tab for side-by-side comparison
			>>> sdk.inspect_in_browser(df3, reuse_tab=False)
		"""

		polars_df = dataframe_to_polars_(df)

		set_download_context(
			self,
			polars_df,
			partition_by=partition_by,
			window_size=window_size,
			null_values=null_values,
		)

		result = self.inspect(
			df,
			partition_by=partition_by,
			window_size=window_size,
			round_digits=round_digits,
			null_values=null_values,
		)
		url = show_inspect(result.raw_json_, reuse_tab=reuse_tab, port=port)

		if show_in_ipynb:
			display(IFrame(src=url, width="100%", height=height))
		else:
			webbrowser.open_new_tab(url)

	def generate_xlsx(
		self,
		df: DataFrameType,
		*,
		partition_by: list[str] | None = None,
		window_size: int = 5,
		null_values: list[str] | None = None,
		language: Language | None = None,
		palette: ColorPalette | None = None,
		extra_palette: list[str] | None = None,
		use_python_charts: bool = False,
	) -> ExcelResult:
		"""Generate Excel files with statistics and charts for the given data.

		Args:
			df: A pandas DataFrame, polars DataFrame, or polars LazyFrame.
			partition_by: Columns to partition the data by.
			window_size: Window size for rolling statistics.
			null_values: Strings to treat as null values.
			language: Language for chart titles.
			palette: Main color palette for the charts.
			extra_palette: Extra color palette for the charts (list of hex colors).
			use_python_charts: If True, embed seaborn/matplotlib charts as Python
				code using =PY() formula (requires Excel 365 with Python in Excel).

		Returns:
			ExcelResult containing the ZIP file with all generated Excel files.

		Raises:
			httpx.HTTPStatusError: If the API returns an error status.
			ValueError: If the API returns a validation error.

		Example:
			>>> result = sdk.generate_xlsx(df)
			>>> result.save("output.zip")
			>>>
			>>> # With Python charts (requires Excel 365)
			>>> result = sdk.generate_xlsx(df, use_python_charts=True)
			>>>
			>>> # With custom language and partitioning
			>>> result = sdk.generate_xlsx(
			...     df,
			...     partition_by=["category"],
			...     language=Language.DE,
			... )
		"""
		file = create_file_from_dataframe_(df)

		body = BodyEndpointGenerateXlsxApiV1XlsxPost(
			file=file,
			partition_by=partition_by if partition_by is not None else UNSET,
			window_size=window_size,
			null_values=null_values if null_values is not None else UNSET,
			language=language if language is not None else UNSET,
			palette=palette if palette is not None else UNSET,
			extra_palette=extra_palette if extra_palette is not None else UNSET,
			use_python_charts=use_python_charts,
		)

		httpx_client = self.client_.get_httpx_client()
		response = httpx_client.post(
			url="/xlsx/",
			headers={"X-API-Key": self.api_key},
			files=body.to_multipart(),
		)

		if response.status_code != HTTPStatus.OK:
			try:
				error_detail = response.json()
			except Exception:
				error_detail = response.text
			raise ValueError(f"API error {response.status_code}: {error_detail}")

		return ExcelResult(zip_content=response.content)

	def generate_pptx(
		self,
		df: DataFrameType,
		*,
		partition_by: list[str] | None = None,
		window_size: int = 5,
		null_values: list[str] | None = None,
		dpi: int = 1000,
		font: FontFamily | None = None,
		language: Language | None = None,
		palette: ColorPalette | None = None,
		extra_palette: list[str] | None = None,
	) -> PowerPointResult:
		"""Generate PowerPoint presentations with statistics and charts.

		Args:
			df: A pandas DataFrame, polars DataFrame, or polars LazyFrame.
			partition_by: Columns to partition the data by.
			window_size: Window size for rolling statistics.
			null_values: Strings to treat as null values.
			dpi: Resolution (dots per inch) for chart images.
			font: Font family for presentation text.
			language: Language for chart titles.
			palette: Main color palette for the charts.
			extra_palette: Extra color palette for the charts (list of hex colors).

		Returns:
			PowerPointResult containing the ZIP file with all generated presentations.

		Raises:
			httpx.HTTPStatusError: If the API returns an error status.
			ValueError: If the API returns a validation error.

		Example:
			>>> result = sdk.generate_pptx(df)
			>>> result.save("presentations.zip")
			>>>
			>>> # With custom settings
			>>> result = sdk.generate_pptx(
			...     df,
			...     partition_by=["category"],
			...     font=FontFamily.ROBOTO,
			...     language=Language.EN,
			...     dpi=300,
			... )
		"""
		file = create_file_from_dataframe_(df)

		body = BodyEndpointGeneratePptxApiV1PptxPost(
			file=file,
			partition_by=partition_by if partition_by is not None else UNSET,
			window_size=window_size,
			null_values=null_values if null_values is not None else UNSET,
			dpi=dpi,
			font=font if font is not None else UNSET,
			language=language if language is not None else UNSET,
			palette=palette if palette is not None else UNSET,
			extra_palette=extra_palette if extra_palette is not None else UNSET,
		)

		httpx_client = self.client_.get_httpx_client()
		response = httpx_client.post(
			url="/pptx/",
			headers={"X-API-Key": self.api_key},
			files=body.to_multipart(),
		)

		if response.status_code != HTTPStatus.OK:
			try:
				error_detail = response.json()
			except Exception:
				error_detail = response.text
			raise ValueError(f"API error {response.status_code}: {error_detail}")

		return PowerPointResult(zip_content=response.content)
