"""
Visualization server for displaying beautiful interactive charts in the browser.

This module provides a lightweight HTTP server that serves visualization pages
for inspect results and graphs, with live reload support.
"""

from __future__ import annotations

import io
import json
import socket
import threading
import warnings
import webbrowser
import zipfile
from dataclasses import dataclass, field
from http.server import HTTPServer, SimpleHTTPRequestHandler
from typing import TYPE_CHECKING, Any

import pandas as pd
import polars as pl

from .html import HTML_TEMPLATE, generate_notebook_html_

if TYPE_CHECKING:
	from .models import InspectResult
	from .sdk import CSVPredict


server_instance_: VisualizationServer | None = None
current_data_: dict[str, Any] = {}
data_version_: int = 0

download_context_: dict[str, Any] = {
	"sdk": None,
	"dataframe": None,
	"partition_by": None,
	"window_size": 5,
	"null_values": None,
}


class VisualizationHandler_(SimpleHTTPRequestHandler):
	"""Custom HTTP handler for serving visualization pages."""

	def log_message(self, format: str, *args: Any) -> None:
		"""Suppress default logging."""
		pass

	def do_GET(self) -> None:
		"""Handle GET requests."""
		if self.path == "/" or self.path == "/index.html":
			self.serve_html_()
		elif self.path == "/api/data":
			self.serve_data_()
		elif self.path == "/api/download/status":
			self.serve_download_status_()
		elif self.path.startswith("/api/download/"):
			self.handle_download_()
		else:
			self.send_error(404, "Not Found")

	def serve_download_status_(self) -> None:
		"""Serve download availability status."""
		global download_context_
		available = (
			download_context_.get("sdk") is not None
			and download_context_.get("dataframe") is not None
		)
		response = json.dumps({"available": available})
		content = response.encode("utf-8")
		self.send_response(200)
		self.send_header("Content-Type", "application/json")
		self.send_header("Content-Length", str(len(content)))
		self.send_header("Cache-Control", "no-cache")
		self.end_headers()
		self.wfile.write(content)

	def handle_download_(self) -> None:
		"""Handle download requests for graphs, xlsx, pptx."""
		global download_context_

		sdk = download_context_.get("sdk")
		df = download_context_.get("dataframe")

		if sdk is None or df is None:
			self.send_error(400, "Download not available - no data context")
			return

		partition_by = download_context_.get("partition_by")
		window_size = download_context_.get("window_size", 5)
		null_values = download_context_.get("null_values")

		try:
			if self.path == "/api/download/graphs":
				content, filename, content_type = self.generate_graphs_(
					sdk, df, partition_by, window_size, null_values
				)
			elif self.path == "/api/download/xlsx":
				content, filename, content_type = self.generate_xlsx_(
					sdk, df, partition_by, window_size, null_values
				)
			elif self.path == "/api/download/pptx":
				content, filename, content_type = self.generate_pptx_(
					sdk, df, partition_by, window_size, null_values
				)
			else:
				self.send_error(404, "Unknown download type")
				return

			self.send_response(200)
			self.send_header("Content-Type", content_type)
			self.send_header("Content-Length", str(len(content)))
			self.send_header(
				"Content-Disposition", f'attachment; filename="{filename}"'
			)
			self.end_headers()
			self.wfile.write(content)
		except Exception as e:
			error_msg = str(e)
			self.send_response(500)
			self.send_header("Content-Type", "application/json")
			content = json.dumps({"error": error_msg}).encode("utf-8")
			self.send_header("Content-Length", str(len(content)))
			self.end_headers()
			self.wfile.write(content)

	def generate_graphs_(
		self,
		sdk: CSVPredict,
		df: pl.DataFrame | pd.DataFrame,
		partition_by: list[str] | None,
		window_size: int,
		null_values: list[str] | None,
	) -> tuple[bytes, str, str]:
		"""Generate graphs ZIP."""

		result = sdk.generate_graphs(
			df,
			partition_by=partition_by,
			window_size=window_size,
			null_values=null_values,
		)

		zip_buffer = io.BytesIO()
		with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
			for name, img_bytes in result.images.items():
				zf.writestr(name, img_bytes)

		return zip_buffer.getvalue(), "graphs.zip", "application/zip"

	def generate_xlsx_(
		self,
		sdk: CSVPredict,
		df: pl.DataFrame | pd.DataFrame,
		partition_by: list[str] | None,
		window_size: int,
		null_values: list[str] | None,
	) -> tuple[bytes, str, str]:
		"""Generate XLSX files (returned as ZIP)."""
		result = sdk.generate_xlsx(
			df,
			partition_by=partition_by,
			window_size=window_size,
			null_values=null_values,
		)
		return (
			result.zip_content,
			"excel_files.zip",
			"application/zip",
		)

	def generate_pptx_(
		self,
		sdk: CSVPredict,
		df: pl.DataFrame | pd.DataFrame,
		partition_by: list[str] | None,
		window_size: int,
		null_values: list[str] | None,
	) -> tuple[bytes, str, str]:
		"""Generate PPTX files (returned as ZIP)."""
		result = sdk.generate_pptx(
			df,
			partition_by=partition_by,
			window_size=window_size,
			null_values=null_values,
		)
		return (
			result.zip_content,
			"powerpoint_files.zip",
			"application/zip",
		)

	def serve_html_(self) -> None:
		"""Serve the main HTML page."""
		content = HTML_TEMPLATE.encode("utf-8")
		self.send_response(200)
		self.send_header("Content-Type", "text/html; charset=utf-8")
		self.send_header("Content-Length", str(len(content)))
		self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
		self.end_headers()
		self.wfile.write(content)

	def serve_data_(self) -> None:
		"""Serve the current data as JSON."""
		global current_data_, data_version_
		response = json.dumps({"version": data_version_, "data": current_data_})
		content = response.encode("utf-8")
		self.send_response(200)
		self.send_header("Content-Type", "application/json")
		self.send_header("Content-Length", str(len(content)))
		self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
		self.send_header("Access-Control-Allow-Origin", "*")
		self.end_headers()
		self.wfile.write(content)


@dataclass
class VisualizationServer:
	"""A lightweight HTTP server for serving visualizations."""

	port: int = 8765
	host: str = "127.0.0.1"
	server_: HTTPServer | None = field(default=None, repr=False)
	thread_: threading.Thread | None = field(default=None, repr=False)

	def find_available_port_(self) -> int:
		"""Find an available port starting from self.port."""
		for port in range(self.port, self.port + 100):
			with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
				try:
					s.bind((self.host, port))
					return port
				except OSError:
					continue
		raise RuntimeError(f"Could not find available port near {self.port}")

	def start(self) -> str:
		"""Start the server and return the URL."""
		if self.server_ is not None:
			return f"http://{self.host}:{self.port}"

		self.port = self.find_available_port_()
		self.server_ = HTTPServer((self.host, self.port), VisualizationHandler_)
		self.thread_ = threading.Thread(target=self.server_.serve_forever, daemon=True)
		self.thread_.start()
		return f"http://{self.host}:{self.port}"

	def stop(self) -> None:
		"""Stop the server."""
		if self.server_ is not None:
			self.server_.shutdown()
			self.server_ = None
			self.thread_ = None

	@property
	def url(self) -> str:
		"""Get the server URL."""
		return f"http://{self.host}:{self.port}"

	@property
	def is_running(self) -> bool:
		"""Check if the server is running."""
		return self.server_ is not None


def get_server_() -> VisualizationServer:
	"""Get or create the global visualization server."""
	global server_instance_
	if server_instance_ is None:
		server_instance_ = VisualizationServer()
	return server_instance_


def show_inspect(
	raw_json: dict[str, Any],
	*,
	reuse_tab: bool = True,
	port: int = 8765,
) -> str:
	"""Display inspect results in an interactive browser visualization.

	To enable XLSX/PPTX downloads, call set_download_context() first.

	Args:
		raw_json: Raw JSON data from InspectResult.raw_json_.
		reuse_tab: If True (default), reuse existing tab via live reload.
			If False, open a new tab each time (for side-by-side comparison).
		port: Port to serve on (default 8765).

	Returns:
		The URL of the visualization server.
	"""
	global current_data_, data_version_

	server = get_server_()

	current_data_ = raw_json
	data_version_ += 1

	was_running = server.is_running
	if not was_running:
		server.port = port
	url = server.start()

	if not was_running or not reuse_tab:
		webbrowser.open_new_tab(url)

	return url


def show(
	result: InspectResult,
	*,
	reuse_tab: bool = True,
	port: int = 8765,
) -> str:
	"""Display inspect results in an interactive browser visualization.

	To enable XLSX/PPTX downloads, call set_download_context() first:

		>>> from csvpredict_sdk.server import set_download_context, show
		>>> set_download_context(sdk, df)
		>>> show(result)

	Args:
		result: InspectResult from sdk.inspect().
		reuse_tab: If True (default), reuse existing tab via live reload.
			If False, open a new tab each time (for side-by-side comparison).
		port: Port to serve on (default 8765).

	Returns:
		The URL of the visualization server.

	Example:
		>>> sdk = CSVPredict(base_url="http://localhost:8000")
		>>> result = sdk.inspect(df)
		>>> show(result)  # Opens browser
		>>>
		>>> result2 = sdk.inspect(df2)
		>>> show(result2)  # Reuses same tab
		>>>
		>>> # Compare dataframes side by side
		>>> show(result2, reuse_tab=False)  # Opens new tab
	"""
	return show_inspect(result.raw_json_, reuse_tab=reuse_tab, port=port)


def display(result: InspectResult, *, height: int = 800) -> None:
	"""Display inspect results inline in a Jupyter notebook.

	This renders the same interactive visualization as show(), but
	directly in the notebook output cell instead of opening a browser.

	Args:
		result: InspectResult from sdk.inspect().
		height: Height of the visualization in pixels (default 800).

	Example:
		>>> result = sdk.inspect(df)
		>>> display(result)  # Renders inline in notebook
		>>>
		>>> display(result, height=600)  # Shorter height
	"""
	from IPython.display import HTML
	from IPython.display import display as ipython_display

	html_content = generate_notebook_html_(result.raw_json_, height=height)

	with warnings.catch_warnings():
		warnings.filterwarnings(
			"ignore",
			message="Consider using IPython.display.IFrame instead",
		)
		ipython_display(HTML(html_content))


def set_download_context(
	sdk: CSVPredict,
	dataframe: pl.DataFrame | pd.DataFrame,
	*,
	partition_by: list[str] | None = None,
	window_size: int = 5,
	null_values: list[str] | None = None,
) -> None:
	"""Set the download context for generating graphs, xlsx, pptx.

	This should be called before show() to enable download buttons.

	Args:
		sdk: The CSVPredict SDK instance.
		dataframe: The original DataFrame being inspected.
		partition_by: Optional columns to partition by.
		window_size: Rolling window size.
		null_values: Optional null value strings.
	"""
	global download_context_
	download_context_["sdk"] = sdk
	download_context_["dataframe"] = dataframe
	download_context_["partition_by"] = partition_by
	download_context_["window_size"] = window_size
	download_context_["null_values"] = null_values


def stop_server() -> None:
	"""Stop the visualization server."""
	global server_instance_
	if server_instance_ is not None:
		server_instance_.stop()
		server_instance_ = None
