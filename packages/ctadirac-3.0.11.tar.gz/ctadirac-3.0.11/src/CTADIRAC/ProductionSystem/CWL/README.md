# Simulation workflow

https://view.commonwl.org/workflows/gitlab.cta-observatory.org/alice.faure/CTADIRAC.git/d8e63563ce1031568857603b69070ede764b74d7/src/CTADIRAC/ProductionSystem/CWL/simulation-run.cwl
