BDMS Server Setup Guide
=======================

.. toctree::
    :maxdepth: 1
    :caption: Contents:

    bdms_repos_interaction
    certificates
    rucio_configuration
    storage_elements
    fts
