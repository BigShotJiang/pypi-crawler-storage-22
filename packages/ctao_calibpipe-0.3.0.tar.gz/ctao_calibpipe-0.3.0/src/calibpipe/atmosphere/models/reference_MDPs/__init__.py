"""Reference molecular density profiles."""
