"""Reference Rayleigh scattering profiles."""
