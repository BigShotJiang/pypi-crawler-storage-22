"""SQL meta-data variable."""

import sqlalchemy as sa

sql_metadata = sa.MetaData()
""" Metadata variable used for `sqlalchemy` objects. """
