"""Tool for calculating of optical throughput and storing of the results in the DB."""

import numpy as np
from astropy.table import Table, join
from astropy.time import Time
from calibpipe.telescope.throughput.containers import OpticalThoughtputContainer
from ctapipe.core import QualityQuery, Tool, traits
from ctapipe.core.traits import (
    Bool,
    CInt,
    ComponentName,
    List,
    Path,
    Set,
    classes_with_traits,
)
from ctapipe.instrument import SubarrayDescription
from ctapipe.io import read_table, write_table
from ctapipe.io.hdf5dataformat import (
    DL1_TEL_CALIBRATION_GROUP,
    DL1_TEL_GROUP,
    DL1_TEL_TRIGGER_TABLE,
)
from ctapipe.monitoring.aggregator import StatisticsAggregator


class MuonQualityQuery(QualityQuery):
    """Quality criteria for muon parameters."""

    quality_criteria = List(
        default_value=[
            ("min impact parameter", "muonefficiency_impact >= 0.0"),
            ("max impact parameter", "muonefficiency_impact <= 10.0"),
            (
                "muon efficiency parameters are not at limit",
                "~muonefficiency_parameters_at_limit",
            ),
            ("throughput calculation is valid", "muonefficiency_is_valid"),
        ],
        allow_none=True,
        help=QualityQuery.quality_criteria.help,
    ).tag(config=True)


class CalculateThroughputWithMuons(Tool):
    """Perform throughput calibration using muons for each telescope allowed in the EventSource."""

    name = traits.Unicode("ThroughputCalibration")
    description = __doc__

    aliases = {
        ("i", "input"): "CalculateThroughputWithMuons.input_url",
    }

    classes = [MuonQualityQuery] + classes_with_traits(StatisticsAggregator)

    input_url = Path(
        help="CTAO HDF5 files for DL1 calibration (muons).",
        allow_none=False,
        exists=True,
        directory_ok=False,
        file_ok=True,
    ).tag(config=True)

    allowed_tels = Set(
        trait=CInt(),
        default_value=None,
        allow_none=True,
        help=(
            "List of allowed telescope IDs, others will be ignored. If None, all "
            "telescopes in the input stream will be included. Requires the "
            "telescope IDs to match between the groups of the monitoring file."
        ),
    ).tag(config=True)

    aggregator_type = ComponentName(
        StatisticsAggregator,
        default_value="SigmaClippingAggregator",
        help="The aggregation strategy to use for throughput calculation.",
    ).tag(config=True)

    append = Bool(
        default_value=False,
        help="If the throughput table already exists in the file, append to it.",
    ).tag(config=True)

    # Set the method name for throughput calculation
    METHOD = "Muon Rings"

    def setup(self):
        """Read from the .h5 file necessary info and save it for further processing."""
        # Load the subarray description from the input file
        self.subarray = SubarrayDescription.from_hdf(self.input_url)

        # Select a new subarray if the allowed_tels configuration is used
        if self.allowed_tels is not None:
            self.subarray = self.subarray.select_subarray(self.allowed_tels)

        # Initialize the quality query for muon selection
        self.quality_query = MuonQualityQuery(parent=self)

        # Initialize the aggregator based on configuration
        self.aggregator = StatisticsAggregator.from_name(
            self.aggregator_type,
            parent=self,
        )

        self.throughput_containers = {}

    def _process_tel(self, tel_id):
        """Process muon data for a single telescope ID."""
        muon_table = read_table(
            self.input_url,
            f"{DL1_TEL_GROUP}/muon/tel_{tel_id:03d}",
        )

        filtered_table = muon_table[self.quality_query.get_table_mask(muon_table)]

        # Read trigger table to get time information
        trigger_table = read_table(
            self.input_url,
            DL1_TEL_TRIGGER_TABLE,
        )

        # Join timing information from trigger table
        filtered_table = join(
            filtered_table,
            trigger_table[["obs_id", "event_id", "time"]],
            keys=["obs_id", "event_id"],
            join_type="left",  # keeps all muon events, even if no trigger match
        )

        # Ensure table is sorted by time
        filtered_table.sort("time")

        # Add time_mono column for aggregator (reusing original table)
        filtered_table["time_mono"] = filtered_table["time"]

        # Run aggregator with chunk processing - will raise ValueError if insufficient data
        chunk_stats = self.aggregator(
            table=filtered_table,
            col_name="muonefficiency_optical_efficiency",
        )

        # Convert aggregator results to throughput containers
        containers = []
        for i in range(len(chunk_stats)):
            # Create container with all parameters at once
            container = OpticalThoughtputContainer(
                obs_id=filtered_table["obs_id"],
                method=self.METHOD,
                mean=chunk_stats["mean"][i],
                median=chunk_stats["median"][i],
                std=chunk_stats["std"][i],
                sem=np.squeeze(
                    chunk_stats["std"][i] / (chunk_stats["n_events"][i] ** 0.5)
                ),
                time_start=Time(
                    chunk_stats["time_start"][i], format="mjd", scale="tai"
                ),
                time_end=Time(chunk_stats["time_end"][i], format="mjd", scale="tai"),
                n_events=np.squeeze(chunk_stats["n_events"][i]),
            )
            containers.append(container)
        return containers

    def start(self):
        """
        Apply the cuts on the muon data and process in chunks.

        Only the events that passed quality cuts provided by configuration are considered.
        Only events for which intensity fit converged, and parameters were not at the limit are considered.
        """
        for tel_id in self.subarray.tel_ids:
            try:
                containers = self._process_tel(tel_id)
                self.throughput_containers[tel_id] = containers
            except ValueError as e:
                self.log.warning("Skipping telescope %s: %s", tel_id, e)
                self.throughput_containers[tel_id] = {}
                continue

    def finish(self):
        """Write the chunk-based results to the output file using write_table."""
        for tel_id in self.subarray.tel_ids:
            containers_list = self.throughput_containers[tel_id]

            # Convert containers to table data using as_dict()
            table_data = []
            for container in containers_list:
                table_data.append(container.as_dict())

            if not table_data:
                self.log.info("No throughput data to write for telescope %s", tel_id)
                continue
            # Create astropy Table from container data
            throughput_table = Table(table_data)

            # Write table to HDF5 file
            if self.append:
                write_table(
                    throughput_table,
                    self.input_url,
                    f"{DL1_TEL_CALIBRATION_GROUP}/optical_throughput/tel_{tel_id:03d}",
                    append=True,
                )
            else:
                write_table(
                    throughput_table,
                    self.input_url,
                    f"{DL1_TEL_CALIBRATION_GROUP}/optical_throughput/tel_{tel_id:03d}",
                    overwrite=True,
                )


def main():
    """Run the app."""
    tool = CalculateThroughputWithMuons()
    tool.run()
