"""DataPipe: CTAO Data Processing Pipeline.

DataPipe is a pipeline subsustem of DPPS.
"""

from .version import __version__

__all__ = [
    "__version__",
]
