"""Backend plugin system for qualpipe webapp."""
