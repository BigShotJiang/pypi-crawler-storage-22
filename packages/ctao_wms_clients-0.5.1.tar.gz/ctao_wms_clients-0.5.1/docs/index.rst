Welcome to the WMS documentation!
==================================

**Version**: |version| **Date**: |today|

.. toctree::
    :maxdepth: 1
    :caption: Contents:

    introduction
    getting_started
    chart
    wms_legacy_instance
    install_ctadirac_server
    run_cwl_workflow_job
    reference
    changelog



Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
