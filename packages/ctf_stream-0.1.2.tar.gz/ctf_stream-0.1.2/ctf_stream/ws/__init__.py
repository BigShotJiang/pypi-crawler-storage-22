"""WebSocket module."""

from .client import WebSocketClient

__all__ = ["WebSocketClient"]
