# ctf-watch

A lightweight surveillance tool for CTFd competitions. Get desktop notifications when teams solve challenges or when challenges are added/updated.

## Installation

```bash
# Install dependencies
sudo apt install libnotify-bin  # Debian/Ubuntu
sudo dnf install libnotify       # Fedora
sudo pacman -S libnotify         # Arch

# Install ctf-watch
pip install -e .
```

## Usage

Start the setup wizard:

```bash
ctf-watch -w
```

Stop active watchers:

```bash
ctf-watch -s
```

## Features

- **Solve notifications**: Get notified when a team solves a challenge
- **Challenge tracking**: Monitor new, updated, or removed challenges (requires authentication)
- **Background daemon**: Runs silently in the background
- **Minimal overhead**: Configurable polling interval

## Authentication

Challenge notifications require a CTFd access token. Generate one from your user settings page and provide it during setup.

Without a token, you'll still get solve notifications for public teams.
