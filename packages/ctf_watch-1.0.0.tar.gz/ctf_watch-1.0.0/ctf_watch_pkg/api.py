import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class CTFdClient:
    def __init__(self, base_url, api_token=None):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "ctf-watch/1.0",
            "Content-Type": "application/json"
        })
        if api_token:
            self.session.headers.update({"Authorization": f"Token {api_token}"})

    def check_connection(self):
        try:
            r = self.session.get(f"{self.base_url}/api/v1/teams", verify=False, timeout=10)
            if r.status_code == 200:
                data = r.json()
                if "meta" in data and "pagination" in data["meta"]:
                    return data["meta"]["pagination"]["total"]
            return None
        except:
            return None

    def search_teams(self, name):
        try:
            params = {'field': 'name', 'q': name}
            r = self.session.get(f"{self.base_url}/api/v1/teams", params=params, verify=False)
            r.raise_for_status()
            return r.json().get('data', [])
        except:
            return []

    def get_team_info(self, team_id):
        try:
            r = self.session.get(f"{self.base_url}/api/v1/teams/{team_id}", verify=False)
            r.raise_for_status()
            return r.json().get('data', {})
        except:
            return {}

    def get_solves(self, team_id):
        try:
            r = self.session.get(f"{self.base_url}/api/v1/teams/{team_id}/solves", verify=False)
            if r.status_code == 200:
                return r.json().get('data', [])
        except:
            pass
        return None

    def get_challenges(self):
        try:
            r = self.session.get(f"{self.base_url}/api/v1/challenges", verify=False)
            if r.status_code == 200:
                return r.json().get('data', [])
        except:
            pass
        return None

    def get_challenge_details(self, challenge_id):
        try:
            r = self.session.get(f"{self.base_url}/api/v1/challenges/{challenge_id}", verify=False)
            if r.status_code == 200:
                return r.json().get('data', {})
        except:
            pass
        return None
