import argparse
import sys
import os
import signal
from .wizard import setup_wizard, input_prompt
from .monitor import Monitor
from .state import load_state, save_state, cleanup_stale_pids

def stop_watchers():
    state = load_state()
    state = cleanup_stale_pids(state)
    
    if not state:
        print("No active ctf-watch processes found.")
        return

    print("Active CTF Watchers:")
    pids = list(state.keys())
    for i, pid in enumerate(pids, 1):
        info = state[pid]
        print(f"{i}) Team: {info['team']} @ {info['url']} (PID: {pid})")

    choice = input_prompt("Enter number to stop (0 for all, Enter to cancel)")
        
    if not choice:
        return
    
    if not choice.isdigit():
        print("☻ Invalid input.")
        return
        
    idx = int(choice)
    
    to_kill = []
    if idx == 0:
        to_kill = pids
    elif 1 <= idx <= len(pids):
        to_kill = [pids[idx-1]]
    else:
        print("☻ Invalid selection.")
        return

    for pid_str in to_kill:
        try:
            pid = int(pid_str)
            os.kill(pid, signal.SIGTERM)
            print(f"✔ Stopped watcher for {state[pid_str]['team']}")
            del state[pid_str]
        except Exception as e:
            print(f"☻ Error stopping PID {pid_str}: {e}")

    save_state(state)

def main():
    parser = argparse.ArgumentParser(prog="ctf-watch", description="☻ CTF Team Surveillance Tool")
    parser.add_argument('-w', '--wizard', action='store_true', help="Start the setup wizard")
    parser.add_argument('-s', '--stop', action='store_true', help="Stop active watchers")
    args = parser.parse_args()

    try:
        if args.stop:
            stop_watchers()
        elif args.wizard:
            # Run interactive setup
            base_url, team_id, team_name, watch_challenges, interval, api_token = setup_wizard()
            
            print(f"\n✔ Good luck! Detaching process...")
            print(f"Interval set to {interval} seconds.")
            print(f"To stop this watcher later, run: {sys.argv[0]} --stop")
            
            # Initialize Monitor and Daemonize
            monitor = Monitor(
                base_url=base_url,
                team_id=team_id,
                team_name=team_name,
                interval=interval,
                watch_challenges=watch_challenges,
                api_token=api_token
            )
            monitor.run_daemon()
        else:
            parser.print_help()
    except KeyboardInterrupt:
        print("\n☻ Aborted.")
        sys.exit(0)

if __name__ == "__main__":
    main()
