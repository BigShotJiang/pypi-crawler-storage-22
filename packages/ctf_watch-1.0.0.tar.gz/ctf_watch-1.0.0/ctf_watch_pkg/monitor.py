import os
import sys
import time
from .api import CTFdClient
from .state import add_active_watcher
from .notifier import send_notification

class Monitor:
    def __init__(self, base_url, team_id, team_name, interval, watch_challenges, api_token=None):
        self.base_url = base_url
        self.team_id = team_id
        self.team_name = team_name
        self.interval = interval
        self.watch_challenges = watch_challenges
        self.api_token = api_token

    def run_daemon(self):
        """Detach from terminal and run in background"""
        try:
            pid = os.fork()
            if pid > 0:
                # Exit first parent
                sys.exit(0)
        except OSError as e:
            sys.stderr.write(f"☻ fork #1 failed: {e.errno} ({e.strerror})\n")
            sys.exit(1)

        # Decouple from parent environment
        os.chdir(os.getcwd())
        os.setsid()
        os.umask(0)

        # Do second fork
        try:
            pid = os.fork()
            if pid > 0:
                # Exit from second parent
                sys.exit(0)
        except OSError as e:
            sys.stderr.write(f"☻ fork #2 failed: {e.errno} ({e.strerror})\n")
            sys.exit(1)

        # Redirect standard file descriptors
        sys.stdout.flush()
        sys.stderr.flush()
        si = open(os.devnull, 'r')
        so = open(os.devnull, 'a+')
        se = open(os.devnull, 'a+')
        os.dup2(si.fileno(), sys.stdin.fileno())
        os.dup2(so.fileno(), sys.stdout.fileno())
        os.dup2(se.fileno(), sys.stderr.fileno())

        # Save state
        pid = os.getpid()
        add_active_watcher(pid, self.team_name, self.base_url, self.interval, self.watch_challenges)

        # Start Loop
        self.monitor_loop()

    def monitor_loop(self):
        client = CTFdClient(self.base_url, self.api_token)
        
        # Initial State
        known_solves = set()
        current_solves = client.get_solves(self.team_id)
        if current_solves:
            for s in current_solves:
                known_solves.add(s['challenge_id'])

        known_challenges = {}
        if self.watch_challenges:
            chals = client.get_challenges()
            if chals:
                for c in chals:
                    # Fetch full details to get description
                    details = client.get_challenge_details(c['id'])
                    if details:
                        known_challenges[c['id']] = {
                            'name': details.get('name'),
                            'description': details.get('description', '')
                        }

        while True:
            time.sleep(self.interval)

            # Check Solves
            new_solves_list = client.get_solves(self.team_id)
            if new_solves_list:
                for s in new_solves_list:
                    cid = s['challenge_id']
                    if cid not in known_solves:
                        chal_name = s.get('challenge', {}).get('name', 'Unknown Challenge')
                        if chal_name == 'Unknown Challenge' and cid in known_challenges:
                             chal_name = known_challenges[cid]['name']
                        
                        send_notification("CTF Watch", f"✔ Team {self.team_name} solved {chal_name}!")
                        known_solves.add(cid)

            # Check Challenges
            if self.watch_challenges:
                current_chals = client.get_challenges()
                
                if current_chals is not None:
                    current_chal_map = {}
                    for c in current_chals:
                        details = client.get_challenge_details(c['id'])
                        if details:
                            current_chal_map[c['id']] = {
                                'name': details.get('name'),
                                'description': details.get('description', '')
                            }
                    
                    current_ids = set(current_chal_map.keys())
                    known_ids = set(known_challenges.keys())

                    # New
                    for new_id in current_ids - known_ids:
                        chal = current_chal_map[new_id]
                        send_notification("CTF Watch", f"🚀 New Challenge Released: {chal['name']}!")
                    
                    # Deleted
                    for del_id in known_ids - current_ids:
                        chal = known_challenges[del_id]
                        send_notification("CTF Watch", f"🗑 Challenge Removed: {chal['name']}")

                    # Updated - check only name and description
                    for cid in current_ids & known_ids:
                        old = known_challenges[cid]
                        new = current_chal_map[cid]
                        
                        changes = []
                        if old.get('name') != new.get('name'):
                            changes.append(f"name: {old.get('name')} → {new.get('name')}")
                        if old.get('description') != new.get('description'):
                            changes.append("description changed")
                        
                        if changes:
                            change_str = ", ".join(changes)
                            send_notification("CTF Watch", f"⚡ Challenge Updated: {old.get('name')} ({change_str})")

                    known_challenges = current_chal_map
