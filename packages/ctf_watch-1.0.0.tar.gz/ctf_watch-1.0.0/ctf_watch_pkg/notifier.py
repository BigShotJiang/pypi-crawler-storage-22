import subprocess

def send_notification(title, message):
    try:
        subprocess.run(['notify-send', title, message], check=False)
    except Exception:
        pass 
