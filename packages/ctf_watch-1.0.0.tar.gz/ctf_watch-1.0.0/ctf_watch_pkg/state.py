import os
import json
import signal
import sys

STATE_FILE = os.path.expanduser("~/.ctf-watch.json")

def load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {}

def save_state(state):
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f, indent=4)
    except:
        pass

def cleanup_stale_pids(state):
    # Remove PIDs that are not running
    active_state = {}
    for pid_str, info in state.items():
        try:
            # Check if process exists.
            os.kill(int(pid_str), 0)
            active_state[pid_str] = info
        except OSError:
            continue # Process dead
    return active_state

def add_active_watcher(pid, team, url, interval, watch_challenges):
    state = load_state()
    state = cleanup_stale_pids(state)
    state[str(pid)] = {
        'team': team,
        'url': url,
        'interval': interval,
        'watch_challenges': watch_challenges
    }
    save_state(state)
