import sys
import shutil
from .api import CTFdClient

def input_prompt(prompt, default=None):
    if default:
        full_prompt = f"- {prompt} [{default}] ➝ "
    else:
        full_prompt = f"- {prompt} ➝ "
    
    try:
        val = input(full_prompt).strip()
    except (EOFError, KeyboardInterrupt):
        print("\n☻ Aborted.")
        sys.exit(0)
        
    if not val and default is not None:
        return default
    return val


def check_dependencies():
    if not shutil.which("notify-send"):
        print("\n☻ Warning: 'notify-send' not found!")
        print("  To get desktop notifications, please install it:")
        print("  - Debian/Ubuntu: sudo apt install libnotify-bin")
        print("  - Fedora: sudo dnf install libnotify")
        print("  - Arch: sudo pacman -S libnotify")
        print("  (You can continue, but notifications won't appear)\n")

def setup_wizard():
    check_dependencies()
    print("- - - - - - - - - - - - - - - - - - -")
    print("- CTF Watch - The Surveillance Tool -")
    print("- - - - - - - - - - - - - - - - - - -")

    # Step 1: Base URL
    client = None
    while True:
        url = input_prompt("CTFd Base URL")
        if not url.startswith("http"):
            print("☻ URL must start with http:// or https://")
            continue
        
        client = CTFdClient(url)
        total_teams = client.check_connection()
        if total_teams is not None:
            print(f"✔ Connected! Found {total_teams} teams playing.")
            base_url = url
            break
        else:
            print("☻ Connection failed or invalid CTFd instance. Try again.")

    # Step 2: Target Team
    team_id = None
    team_name = ""
    while True:
        target = input_prompt("Target Team Name")
        results = client.search_teams(target)
        
        if not results:
            print("☻ Team not found. Try again.")
            continue
        
        selected_team = None
        if len(results) == 1:
            team = results[0]
            print(f"✔ Found: {team['name']} (ID: {team['id']})")
            confirm = input_prompt("Is this correct?", default="y")
            if confirm.lower().startswith('y'):
                selected_team = team
        else:
            print(f"\n✔ Found {len(results)} teams matching '{target}':")
            for i, team in enumerate(results, 1):
                print(f"{i}) {team['name']} (ID: {team['id']})")
            
            choice = input_prompt(f"Select a team (1-{len(results)}) or '0' to search again")
            if choice.isdigit():
                idx = int(choice)
                if 1 <= idx <= len(results):
                    selected_team = results[idx-1]
                elif idx == 0:
                    continue

        if selected_team:
            team_id = selected_team['id']
            team_name = selected_team['name']
            break

    # Step 3: Status
    info = client.get_team_info(team_id)
    solves = client.get_solves(team_id)
    print(f"✔ Team {team_name} has {len(solves)} solves / {info.get('score', 0)} points.")

    # Step 4: Preferences
    pref = input_prompt("Do you want to get notified on new/updated/deleted challenges?", default="N")
    watch_challenges = pref.lower().startswith('y')
    
    api_token = None
    if watch_challenges:
        print("\n☻ Note: Challenge notifications require authentication.")
        print("  You can generate an access token from your CTFd user settings.")
        token_input = input_prompt("Access Token (leave empty to skip challenge notifications)", default="")
        if token_input:
            api_token = token_input
        else:
            print("☻ Skipping challenge notifications (no token provided).")
            watch_challenges = False

    # Step 5: Interval
    while True:
        interval_str = input_prompt("Polling interval in seconds", default="60")
        try:
            interval = int(interval_str)
            if interval > 0:
                break
            else:
                print("☻ Interval must be a positive number.")
        except ValueError:
            print("☻ Please enter a valid number.")

    return base_url, team_id, team_name, watch_challenges, interval, api_token
