markdown

# CTT Navier-Stokes Solver

A 3D Navier-Stokes solver based on Convergent Time Theory, demonstrating global regularity through exponential energy decay.

## Installation

```bash
pip install ctt-navier-stokes

Quick Start
python

from ctt_navier_stokes import solve

result = solve(resolution=32, steps_per_layer=10)
print(f"Energy decay: {result['final_energy_ratio']:.6f}")

Mathematical Foundation

The CTT formulation replaces continuous time with 33 fractal layers:
text

∂ω/∂d + α(ω·∇ₕ)ω = -∇ₕA + α∇ₕ²ω

Energy decays exponentially:
text

E(d) = E₀e^{-αd}

This prevents blow-up — solutions remain smooth for all time.
License

Proprietary — see LICENSE file. Academic use free with attribution.
text


---

## Step 7 — Build and Upload

```bash
# Build the package
python -m build

# Upload to PyPI
twine upload dist/*


