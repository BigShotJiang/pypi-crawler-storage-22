"""
CTT Navier-Stokes Solver
Convergent Time Theory formulation of 3D Navier-Stokes equations
"""

from .core import CTTNavierStokesSolver, ALPHA, LAYERS

__version__ = "1.0.0"
__author__ = "Américo Simões"
__email__ = "amexsimoes@gmail.com"

def solve(resolution=32, steps_per_layer=10):
    """Solve Navier-Stokes using CTT formulation"""
    solver = CTTNavierStokesSolver(resolution=resolution)
    return solver.solve(steps_per_layer=steps_per_layer)
