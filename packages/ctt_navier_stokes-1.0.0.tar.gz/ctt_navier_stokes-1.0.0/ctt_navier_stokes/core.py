"""
CTT Navier-Stokes Solver
Implements temporal resonance formulation of 3D Navier-Stokes equations
"""

import numpy as np
from scipy.fft import fftn, ifftn

# Fundamental constants
ALPHA = 0.0302011  # CTT dispersion coefficient
LAYERS = 33        # Fractal temporal layers

class CTTNavierStokesSolver:
    """Spectral solver for CTT formulation of Navier-Stokes"""
    
    def __init__(self, resolution=32, alpha=ALPHA, layers=LAYERS):
        self.res = resolution
        self.alpha = alpha
        self.layers = layers
        
        # Grid setup
        self.k = np.fft.fftfreq(resolution) * 2 * np.pi * resolution
        self.kx, self.ky, self.kz = np.meshgrid(self.k, self.k, self.k, indexing='ij')
        self.k2 = self.kx**2 + self.ky**2 + self.kz**2
        self.k2[0,0,0] = 1e-6  # Avoid division by zero
        
        # Dealias filter (2/3 rule)
        self.dealias = (np.abs(self.kx) < 2/3) & (np.abs(self.ky) < 2/3) & (np.abs(self.kz) < 2/3)
        
    def solve(self, steps_per_layer=10):
        """Solve across all temporal layers"""
        energy = np.zeros(self.layers)
        max_vorticity = np.zeros(self.layers)
        
        # Initialize with random field
        u = np.random.randn(3, self.res, self.res, self.res)
        u_hat = fftn(u, axes=(1,2,3))
        u_hat = self._project(u_hat)
        
        for d in range(self.layers):
            # CTT temporal evolution
            for _ in range(steps_per_layer):
                u_hat = self._step(u_hat, d)
            
            # Compute diagnostics
            u = ifftn(u_hat, axes=(1,2,3)).real
            vorticity = self._compute_vorticity(u)
            energy[d] = self._compute_energy(u_hat)
            max_vorticity[d] = np.max(np.abs(vorticity))
            
            # CTT energy bound check
            expected = energy[0] * np.exp(-self.alpha * (d+1))
            assert energy[d] <= expected * 1.01, f"Energy bound violated at layer {d+1}"
        
        return {
            'energy': energy,
            'max_vorticity': max_vorticity,
            'alpha': self.alpha,
            'layers': self.layers,
            'final_energy_ratio': energy[-1] / energy[0]
        }
    
    def _step(self, u_hat, layer):
        """Single time step in CTT formulation"""
        # Nonlinear term in physical space
        u = ifftn(u_hat, axes=(1,2,3))
        u_sq = np.sum(u**2, axis=0)
        nonlinear = -0.5 * ifftn(1j * self.kx * fftn(u_sq), axes=(1,2,3))
        
        # CTT temporal damping
        damping = -self.alpha * u_hat
        
        # Update
        u_hat_new = u_hat + (nonlinear + damping) * 0.1
        u_hat_new *= self.dealias
        u_hat_new = self._project(u_hat_new)
        
        return u_hat_new
    
    def _project(self, u_hat):
        """Project to divergence-free field"""
        k_dot_u = self.kx * u_hat[0] + self.ky * u_hat[1] + self.kz * u_hat[2]
        for i in range(3):
            u_hat[i] -= (self.k[i] / self.k2) * k_dot_u
        return u_hat
    
    def _compute_vorticity(self, u):
        """Compute vorticity field"""
        grad_u = np.gradient(u)
        vorticity = np.zeros_like(u)
        vorticity[0] = grad_u[2][1] - grad_u[1][2]
        vorticity[1] = grad_u[0][2] - grad_u[2][0]
        vorticity[2] = grad_u[1][0] - grad_u[0][1]
        return vorticity
    
    def _compute_energy(self, u_hat):
        """Compute total kinetic energy"""
        return 0.5 * np.sum(np.abs(u_hat)**2) / self.res**6
