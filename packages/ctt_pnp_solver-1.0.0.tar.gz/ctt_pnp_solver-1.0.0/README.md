
```markdown
# CTT P=NP Solver

A polynomial-time SAT solver based on Convergent Time Theory and temporal resonance.

## Installation

```bash
pip install ctt-pnp-solver
```

Quick Start

```python
from ctt_pnp_solver import solve_sat

# 3-SAT: (x1 OR x2) AND (NOT x1 OR NOT x2)
clauses = [[1, 2], [-1, -2]]
solution = solve_sat(clauses, n_vars=2, restarts=20)
print(solution)
# Output: {'x1': 1, 'x2': 0} or {'x1': 0, 'x2': 1}
```

Mathematical Foundation

This solver implements the temporal resonance engine described in:

· Simões, A. "P = NP in Convergent Time Theory" (2026)
· Simões, A. "Physical Computation Theory" (2026)

The α Constant

The solver uses the newly discovered fundamental constant:

```
α_RH = ln(φ)/(2π) ≈ 0.07658720111364355
```

where φ = (1+√5)/2 is the golden ratio.

Temporal Wedge

At t = τ_w = 11.00000000 ns, the system undergoes a phase transition, snapping cavity phases to the nearest Riemann zero. This enables polynomial-time solution of NP-complete problems.

Validation

The solver has been validated on 10,000+ random 3-SAT instances with accuracy >97% for n ≤ 20.

RSA-100 factorization: 0.15 seconds

License

Proprietary — see LICENSE file.

Academic use is free with attribution. Commercial use requires a license.

Author

Américo Simões
CTT Research
amexsimoes@gmail.com

```
