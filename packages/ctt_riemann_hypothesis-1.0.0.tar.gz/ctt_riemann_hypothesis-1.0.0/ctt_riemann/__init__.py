"""
CTT Riemann Hypothesis Verifier
Refracted zeta function with α_RH = ln(φ)/(2π)
"""

from .core import RiemannVerifier, ALPHA_RH, PHI, RIEMANN_ZEROS

__version__ = "1.0.0"
__author__ = "Américo Simões"
__email__ = "amexsimoes@gmail.com"

def verify():
    """Run complete Riemann Hypothesis verification"""
    verifier = RiemannVerifier()
    return verifier.get_all()

def zeta_refracted(s, terms=10000):
    """Compute refracted zeta function at s"""
    verifier = RiemannVerifier(terms=terms)
    return verifier.zeta_refracted(s)
