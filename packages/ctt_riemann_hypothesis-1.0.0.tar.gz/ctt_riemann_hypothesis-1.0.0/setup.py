from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ctt-riemann-hypothesis",
    version="1.0.0",
    author="Américo Simões",
    author_email="amexsimoes@gmail.com",
    description="Riemann Hypothesis verification via CTT refraction",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/SimoesCTT/ctt-riemann",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Topic :: Scientific/Engineering :: Physics",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
        "scipy>=1.7.0",
    ],
    extras_require={
        "dev": ["pytest>=6.0"],
    },
    include_package_data=True,
    zip_safe=False,
)
