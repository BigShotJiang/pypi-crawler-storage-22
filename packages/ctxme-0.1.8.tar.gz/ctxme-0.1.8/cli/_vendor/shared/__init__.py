"""Shared Context Platform client abstractions."""

from .client import BackendClient, HttpBackendClient, MockBackendClient
from .config import BackendConfig, normalize_api_base_url, validate_api_key_format
from .exceptions import (
    AuthenticationError,
    BackendRequestError,
    ConfigError,
    ConflictError,
    NotFoundError,
    PreconditionFailedError,
    SharedError,
    ValidationFailure,
)
from .models import (
    File,
    Item,
    ItemListResult,
    ItemMetadata,
    ItemSummary,
    Project,
    SearchResult,
)

__all__ = [
    "AuthenticationError",
    "BackendClient",
    "BackendConfig",
    "BackendRequestError",
    "ConfigError",
    "ConflictError",
    "File",
    "HttpBackendClient",
    "Item",
    "ItemListResult",
    "ItemMetadata",
    "ItemSummary",
    "MockBackendClient",
    "NotFoundError",
    "PreconditionFailedError",
    "Project",
    "SearchResult",
    "SharedError",
    "ValidationFailure",
    "normalize_api_base_url",
    "validate_api_key_format",
]
