"""Pydantic models used by shared clients."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class Project(BaseModel):
    """Project metadata."""

    model_config = ConfigDict(frozen=True)

    key: str
    name: str
    description: str | None = None


class Item(BaseModel):
    """Full item representation."""

    model_config = ConfigDict(frozen=True)

    id: str
    project_key: str
    key: str
    title: str
    data: str | None = None
    extracted_text: str | None = None
    mime_type: str = "text/plain"
    tags: list[str] = Field(default_factory=list)
    content_sha256: str | None = None
    content_type: str = "inline"
    processing_status: str | None = None  # "ready", "processing", or "failed"
    processing_error: str | None = None  # Error message if processing_status == "failed"
    created_via: str | None = None  # "ui", "cli", "mcp", or "unknown"
    created_at: datetime | None = None
    updated_at: datetime | None = None
    original_filename: str | None = None
    size: int | None = None
    storage_key: str | None = None


class ItemMetadata(BaseModel):
    """Item metadata without the data field - for efficient metadata-only reads."""

    model_config = ConfigDict(frozen=True)

    project_key: str
    key: str
    title: str
    mime_type: str = "text/plain"
    tags: list[str] = Field(default_factory=list)
    content_sha256: str | None = None
    etag: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class ItemSummary(BaseModel):
    """Lightweight item listing entry."""

    model_config = ConfigDict(frozen=True)

    project_key: str
    key: str
    title: str
    snippet: str | None = None
    tags: list[str] = Field(default_factory=list)
    processing_status: str | None = None  # "ready", "processing", or "failed"
    updated_at: datetime | None = None
    created_at: datetime | None = None


class ItemListResult(BaseModel):
    """Paginated item list response."""

    model_config = ConfigDict(frozen=True)

    items: list[ItemSummary]
    next_cursor: str | None = None
    has_more: bool = False


class SearchResult(BaseModel):
    """Search response entry."""

    model_config = ConfigDict(frozen=True)

    project_key: str
    source_type: str
    item_key: str | None = None
    file_id: str | None = None
    filename: str | None = None
    title: str | None = None
    score: float
    snippet: str | None = None
    highlight_positions: list[tuple[int, int]] | None = None
    tags: list[str] = Field(default_factory=list)
    updated_at: datetime | None = None
    processing_status: str | None = None  # "ready", "processing", or "failed"


class ContextSearchResult(BaseModel):
    """Unified search result from /search/v2 endpoint."""

    model_config = ConfigDict(frozen=True)

    project_key: str
    item_key: str
    title: str
    content_type: str  # "inline" or "file"
    processing_status: str  # "processing", "ready", or "failed"
    created_via: str = "unknown"  # "ui", "cli", "mcp", or "unknown"
    tags: list[str] = Field(default_factory=list)
    updated_at: datetime | None = None
    score: float
    snippet: str | None = None
    highlight_positions: list[tuple[int, int]] | None = None
    original_filename: str | None = None  # populated for file items
    size: int | None = None  # populated for file items


class File(BaseModel):
    """File metadata and optional content."""

    model_config = ConfigDict(frozen=True)

    project_key: str
    id: str
    filename: str
    size: int
    mime_type: str
    checksum: str
    storage_key: str
    created_at: datetime | None = None
    updated_at: datetime | None = None
    data: str | None = None
