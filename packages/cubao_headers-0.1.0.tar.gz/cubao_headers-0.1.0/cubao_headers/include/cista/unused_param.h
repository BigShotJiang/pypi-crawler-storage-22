#pragma once

#define CISTA_UNUSED_PARAM(param) (void)(param);