# cube-mcp

MCP server for EdgescaleAI Cube management and Apollo deployments.

## Install

```bash
npx cube-mcp
```

Requires [uv](https://docs.astral.sh/uv/) or [pipx](https://pipx.pypa.io/).

## Add to Claude Code

```bash
claude mcp add cube -- npx cube-mcp
```

## Tools

### Setup

| Tool | Description |
|------|-------------|
| `setup_check` | Check all prerequisites and show status |
| `setup_install_teleport` | Install Teleport CLI (tsh) |
| `setup_install_kubectl` | Install kubectl |
| `setup_install_helm` | Install Helm |
| `setup_install_docker` | Install Docker |
| `setup_install_apollo` | Guide for Apollo CLI installation |
| `setup_configure_credentials` | Configure Apollo credentials |

### Cube Management

| Tool | Description |
|------|-------------|
| `cube_login` | Login to a Cube (guided - shows SSO and password options) |
| `cube_login_password` | Login via username/password (guided) |
| `cube_list` | List available Cubes |
| `cube_status` | Get Cube node status |

### App Proxy

| Tool | Description |
|------|-------------|
| `app_list` | List available Teleport apps (HTTP/TCP) |
| `app_login` | Login to a Teleport app |
| `app_proxy` | Start local proxy for an app (MQTT, databases, etc.) |
| `app_proxy_stop` | Stop running app proxies |
| `app_proxy_status` | Show status of running proxies |

### Apollo Deployments

| Tool | Description |
|------|-------------|
| `build_and_publish_to_apollo` | Build and publish app to Apollo |
| `acr_login` | Login to Apollo Container Registry |
| `acr_get_token` | Get ACR OAuth token |

## Quick Start

```
You: "Check my setup"
You: "Install kubectl"
You: "Connect me to staging-int"
You: "What's the Cube status?"
You: "List available apps"
You: "Proxy mosquitto-dev so I can connect locally"
You: "Build and publish my app"
```

## Credentials

### Teleport

Login is guided - the tool will show you the commands to run:
- **Okta SSO**: `tsh login --proxy=edgescaleai.teleport.sh --auth=okta`
- **Username/Password**: `tsh login --proxy=edgescaleai.teleport.sh --user=<username>`

### Apollo

Configure Apollo CLI:

```bash
apollo-cli configure
```

Or set environment variables:

```bash
export APOLLO_CLIENT="<your-client-id>"
export APOLLO_SECRET="<your-client-secret>"
```

## Local Development

### First-time setup

```bash
# Clone the repo
git clone https://github.com/EdgescaleAI/cube-mcp.git
cd cube-mcp

# Create virtual environment and install
python3 -m venv .venv
source .venv/bin/activate
pip install -e .

# Add to Claude Code (use full path to venv python)
claude mcp add cube-local -- $(pwd)/.venv/bin/python -m cube_mcp.server
```

### Reload after code changes

In Claude Code, run:

```
/mcp
```

This reloads all MCP servers and picks up your latest code changes.

### Run server directly (for debugging)

```bash
source .venv/bin/activate
python -m cube_mcp.server
```

## Contributing

1. Create a branch
2. Make changes
3. Test locally with `/mcp` reload
4. Push and create PR
5. Merge to main → auto-publishes to PyPI and npm
