# Cube MCP Server - Update Guide

This guide explains how to update your Cube MCP server to a new version.

## Quick Update

If you followed the standard installation (venv at `~/.cube-mcp/`):

```bash
~/.cube-mcp/venv/bin/pip install --force-reinstall /path/to/cube_mcp-X.X.X-py3-none-any.whl
```

Replace `/path/to/cube_mcp-X.X.X-py3-none-any.whl` with the actual path to the new wheel file.

## Step-by-Step Instructions

### 1. Get the new wheel file

Download or copy the new `.whl` file to your machine.

### 2. Find your installation

If you're unsure where cube-mcp is installed:

```bash
which cube-mcp
```

Common locations:
- `~/.cube-mcp/venv/bin/cube-mcp` (recommended setup)
- `~/.pyenv/versions/X.X.X/bin/cube-mcp` (pyenv)
- `/usr/local/bin/cube-mcp` (global install)

### 3. Update the package

Use pip from the same environment where cube-mcp is installed:

```bash
# For ~/.cube-mcp/venv installation:
~/.cube-mcp/venv/bin/pip install --force-reinstall /path/to/cube_mcp-X.X.X-py3-none-any.whl

# For pyenv installation:
~/.pyenv/versions/X.X.X/bin/pip install --force-reinstall /path/to/cube_mcp-X.X.X-py3-none-any.whl
```

### 4. Verify the update

Check that the new version is installed:

```bash
~/.cube-mcp/venv/bin/pip show cube-mcp | grep Version
```

### 5. Restart Claude Code

Start a new conversation or restart Claude Code to use the updated version.

---

## Changelog

### v0.2.1
- Replaced AWS Lambda dependency with direct `apollo-cli` calls
- No longer requires AWS credentials for Apollo publishing
- Apollo publish now uses `apollo-cli product-release helm-chart init` and `apollo-cli publish manifest`

### v0.2.0
- Added Apollo Container Registry (ACR) deployment tools
- New tool: `helm_deploy` - Full deployment pipeline with smart auto-detection
- New tool: `acr_login` - Login to ACR (Docker + Helm)
- New tool: `acr_get_token` - Get OAuth2 token from ACR
- Requires `APOLLO_CLIENT` and `APOLLO_SECRET` environment variables for ACR tools

### v0.1.1
- Fixed TLS certificate errors when connecting to Cubes
- Added `--insecure-skip-tls-verify` flag to kubectl commands

### v0.1.0
- Initial release
- Tools: `cube_login`, `cube_list`, `cube_status`
