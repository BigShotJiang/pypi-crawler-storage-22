"""
Cube MCP Server

Tools:
Setup:
- setup_check: Check if all prerequisites are installed
- setup_install_teleport: Install Teleport CLI (tsh)
- setup_install_kubectl: Install kubectl
- setup_install_helm: Install Helm
- setup_install_apollo: Guide Apollo CLI installation
- setup_configure_credentials: Help configure Apollo credentials

Cube Management:
- cube_login: Authenticate to a Cube via Teleport
- cube_status: Get Cube node status via kubectl describe node
- cube_list: List available Cubes via Teleport

App Proxy:
- app_list: List available Teleport apps
- app_login: Login to a Teleport app (get certificate)
- app_proxy: Start local proxy for an app (TCP/HTTP)
- app_proxy_stop: Stop a running app proxy

Apollo/ACR:
- acr_get_token: Get OAuth2 access token from Apollo Container Registry
- acr_login: Login to Apollo Container Registry (Docker + Helm)
- build_and_publish_to_apollo: Build Docker image, package Helm chart, and publish to Apollo
"""

import subprocess
import os
import re
import json
import glob
import platform
import shutil
import signal
import atexit
from mcp.server import FastMCP

# EdgescaleAI Teleport proxy URL
DEFAULT_PROXY = "edgescaleai.teleport.sh"

# Apollo Container Registry (ACR) configuration
ACR_REGISTRY = "edgescaleai.palantirapollo.com"
ACR_DOCKER_PREFIX = f"{ACR_REGISTRY}/com.edgescaleai-cube"
ACR_HELM_PREFIX = f"oci://{ACR_REGISTRY}/charts/com.edgescaleai-cube"
ACR_TOKEN_URL = f"https://{ACR_REGISTRY}/multipass/api/oauth2/token"
APOLLO_URL = f"https://{ACR_REGISTRY}"
APOLLO_GROUP_ID = "com.edgescaleai-cube"

mcp = FastMCP("cube-mcp")

# Track running app proxy processes
_running_proxies: dict[str, subprocess.Popen] = {}


def _cleanup_proxies():
    """Clean up all running proxy processes on exit."""
    for app_name, proc in list(_running_proxies.items()):
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except:
            try:
                proc.kill()
            except:
                pass
    _running_proxies.clear()


# Register cleanup on exit
atexit.register(_cleanup_proxies)


# ============================================================================
# Helper Functions for ACR/Helm Operations
# ============================================================================

def _get_apollo_credentials():
    """Get Apollo client credentials from environment variables."""
    client_id = os.environ.get("APOLLO_CLIENT")
    client_secret = os.environ.get("APOLLO_SECRET")
    return client_id, client_secret


def _get_acr_token() -> tuple[str, str]:
    """
    Get OAuth2 token from Apollo. Returns (token, error_message).
    """
    client_id, client_secret = _get_apollo_credentials()

    if not client_id or not client_secret:
        return None, """Apollo credentials not found.

Set these environment variables in ~/.bashrc or ~/.zshrc:

  export APOLLO_CLIENT="<your-client-id>"
  export APOLLO_SECRET="<your-client-secret>"

Then restart your terminal or run: source ~/.bashrc"""

    try:
        result = subprocess.run(
            [
                "curl", "-s", ACR_TOKEN_URL,
                "-H", "content-type: application/x-www-form-urlencoded",
                "--data-urlencode", "grant_type=client_credentials",
                "--data-urlencode", f"client_id={client_id}",
                "--data-urlencode", f"client_secret={client_secret}"
            ],
            capture_output=True,
            text=True,
            timeout=30
        )

        if result.returncode != 0:
            return None, f"Failed to get token: {result.stderr}"

        response = json.loads(result.stdout)
        token = response.get("access_token")

        if not token:
            return None, f"No access_token in response: {result.stdout}"

        return token, None

    except subprocess.TimeoutExpired:
        return None, "Token request timed out"
    except json.JSONDecodeError as e:
        return None, f"Invalid JSON response: {e}"
    except FileNotFoundError:
        return None, "curl not found. Please install curl."


def _find_chart_yaml(path: str = None) -> tuple[str, str]:
    """
    Find Chart.yaml. Returns (chart_path, error_message).

    Search order:
    1. If path specified, use it directly
    2. ./Chart.yaml
    3. ./charts/*/Chart.yaml
    """
    if path:
        if os.path.isfile(path):
            return path, None
        chart_yaml = os.path.join(path, "Chart.yaml")
        if os.path.isfile(chart_yaml):
            return chart_yaml, None
        return None, f"Chart.yaml not found at: {path}"

    # Check current directory
    if os.path.isfile("Chart.yaml"):
        return "Chart.yaml", None

    # Check charts subdirectory
    charts = glob.glob("charts/*/Chart.yaml")
    if len(charts) == 1:
        return charts[0], None
    elif len(charts) > 1:
        chart_names = [os.path.dirname(c) for c in charts]
        return None, f"Multiple charts found: {', '.join(chart_names)}. Please specify which one."

    return None, "No Chart.yaml found. Run from a chart directory or specify the path."


def _parse_chart_yaml(chart_path: str) -> tuple[dict, str]:
    """
    Parse Chart.yaml and return dict with name, version, appVersion.
    Returns (chart_info, error_message).
    """
    try:
        with open(chart_path, 'r') as f:
            content = f.read()

        # Simple YAML parsing for the fields we need
        name_match = re.search(r'^name:\s*(.+)$', content, re.MULTILINE)
        version_match = re.search(r'^version:\s*(.+)$', content, re.MULTILINE)
        app_version_match = re.search(r'^appVersion:\s*["\']?([^"\']+)["\']?$', content, re.MULTILINE)

        if not name_match or not version_match:
            return None, f"Could not parse name/version from {chart_path}"

        return {
            "name": name_match.group(1).strip(),
            "version": version_match.group(1).strip(),
            "appVersion": app_version_match.group(1).strip() if app_version_match else None,
            "path": chart_path,
            "dir": os.path.dirname(chart_path) or "."
        }, None

    except Exception as e:
        return None, f"Error reading {chart_path}: {e}"


def _bump_version(version: str, bump_type: str = "patch") -> str:
    """Bump a semver version string."""
    parts = version.split(".")
    if len(parts) != 3:
        return version  # Can't bump non-semver

    major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2])

    if bump_type == "major":
        return f"{major + 1}.0.0"
    elif bump_type == "minor":
        return f"{major}.{minor + 1}.0"
    else:  # patch
        return f"{major}.{minor}.{patch + 1}"


def _update_chart_version(chart_path: str, new_version: str, new_app_version: str = None) -> tuple[bool, str]:
    """Update version (and optionally appVersion) in Chart.yaml."""
    try:
        with open(chart_path, 'r') as f:
            content = f.read()

        # Update version
        content = re.sub(
            r'^(version:\s*).+$',
            f'\\g<1>{new_version}',
            content,
            flags=re.MULTILINE
        )

        # Update appVersion if specified
        if new_app_version:
            content = re.sub(
                r'^(appVersion:\s*)["\']?[^"\']+["\']?$',
                f'\\g<1>"{new_app_version}"',
                content,
                flags=re.MULTILINE
            )

        with open(chart_path, 'w') as f:
            f.write(content)

        return True, None

    except Exception as e:
        return False, f"Error updating {chart_path}: {e}"


# ============================================================================
# Setup Tools - Help users install prerequisites
# ============================================================================

def _check_command(cmd: str) -> tuple[bool, str]:
    """Check if a command is available. Returns (installed, version_or_path)."""
    path = shutil.which(cmd)
    if not path:
        return False, ""

    # Try to get version
    version_flags = ["--version", "version", "-v"]
    for flag in version_flags:
        try:
            result = subprocess.run(
                [cmd, flag],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                # Get first line of output
                version = result.stdout.strip().split('\n')[0]
                return True, version
        except:
            pass

    return True, path


def _get_platform() -> tuple[str, str]:
    """Get OS and architecture. Returns (os, arch)."""
    system = platform.system().lower()  # darwin, linux, windows
    machine = platform.machine().lower()  # x86_64, arm64, aarch64

    # Normalize architecture names
    if machine in ["x86_64", "amd64"]:
        arch = "amd64"
    elif machine in ["arm64", "aarch64"]:
        arch = "arm64"
    else:
        arch = machine

    return system, arch


@mcp.tool()
def setup_check() -> str:
    """
    Check if all prerequisites for cube-mcp are installed.

    This checks for:
    - tsh (Teleport CLI) - Required for Cube authentication
    - kubectl - Required for Cube management
    - helm - Required for chart packaging
    - docker - Required for building images
    - apollo-cli - Required for publishing to Apollo
    - Apollo credentials (APOLLO_CLIENT, APOLLO_SECRET)
    """
    results = []
    all_good = True

    # Check CLI tools
    tools = [
        ("tsh", "Teleport CLI", "Required for Cube authentication"),
        ("kubectl", "Kubernetes CLI", "Required for Cube management"),
        ("helm", "Helm", "Required for chart packaging"),
        ("docker", "Docker", "Required for building images"),
        ("apollo-cli", "Apollo CLI", "Required for publishing to Apollo"),
    ]

    results.append("Prerequisites Status")
    results.append("=" * 50)

    for cmd, name, purpose in tools:
        installed, version = _check_command(cmd)
        if installed:
            results.append(f"✓ {name}: {version}")
        else:
            results.append(f"✗ {name}: NOT INSTALLED")
            results.append(f"  └─ {purpose}")
            all_good = False

    results.append("")
    results.append("Credentials Status")
    results.append("=" * 50)

    # Check Apollo credentials
    client_id, client_secret = _get_apollo_credentials()
    if client_id and client_secret:
        results.append(f"✓ APOLLO_CLIENT: {client_id[:8]}...")
        results.append(f"✓ APOLLO_SECRET: {'*' * 8}...")
    else:
        if not client_id:
            results.append("✗ APOLLO_CLIENT: NOT SET")
        if not client_secret:
            results.append("✗ APOLLO_SECRET: NOT SET")
        all_good = False

    # Check Teleport session
    results.append("")
    results.append("Session Status")
    results.append("=" * 50)

    try:
        tsh_status = subprocess.run(
            ["tsh", "status"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if tsh_status.returncode == 0 and "EXPIRED" not in tsh_status.stdout:
            results.append("✓ Teleport: Logged in")
        else:
            results.append("✗ Teleport: Not logged in or session expired")
    except FileNotFoundError:
        results.append("✗ Teleport: tsh not installed")
    except:
        results.append("? Teleport: Could not check status")

    # Summary
    results.append("")
    results.append("=" * 50)
    if all_good:
        results.append("All prerequisites installed!")
    else:
        results.append("Some prerequisites are missing.")
        results.append("Use setup_install_* tools to install them.")

    return "\n".join(results)


def _has_brew() -> bool:
    """Check if Homebrew is available."""
    return shutil.which("brew") is not None


def _run_install(cmd: list[str], description: str) -> tuple[bool, str]:
    """Run an installation command. Returns (success, output)."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300  # 5 min timeout for installs
        )
        if result.returncode == 0:
            return True, result.stdout
        else:
            return False, result.stderr
    except subprocess.TimeoutExpired:
        return False, "Installation timed out"
    except FileNotFoundError:
        return False, f"Command not found: {cmd[0]}"
    except Exception as e:
        return False, str(e)


@mcp.tool()
def setup_install_teleport() -> str:
    """
    Install Teleport CLI (tsh) for Cube authentication.

    Attempts to install via Homebrew (macOS) or official install script (Linux).
    """
    system, arch = _get_platform()

    # Check if already installed
    installed, version = _check_command("tsh")
    if installed:
        return f"Teleport (tsh) is already installed.\n\nVersion: {version}"

    if system == "darwin":
        # macOS - try Homebrew first
        if _has_brew():
            result = ["Installing Teleport via Homebrew..."]
            success, output = _run_install(["brew", "install", "teleport"], "Teleport")

            if success:
                installed, version = _check_command("tsh")
                result.append(f"✓ Teleport installed successfully!")
                result.append(f"  Version: {version}")
                return "\n".join(result)
            else:
                result.append(f"✗ Homebrew install failed: {output}")
                result.append("")
                result.append("Try manual installation:")
                result.append("  curl -O https://cdn.teleport.dev/teleport-v18.6.6.pkg")
                result.append("  sudo installer -pkg teleport-v18.6.6.pkg -target /")
                return "\n".join(result)
        else:
            return """Teleport CLI (tsh) Installation - macOS

Homebrew not found. Install manually:

1. Download the installer:
   curl -O https://cdn.teleport.dev/teleport-v18.6.6.pkg

2. Install (requires sudo):
   sudo installer -pkg teleport-v18.6.6.pkg -target /

3. Verify:
   tsh version

Or install Homebrew first:
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   brew install teleport
"""

    elif system == "linux":
        # Linux - try the official install script
        result = ["Installing Teleport via official script..."]
        success, output = _run_install(
            ["bash", "-c", "curl -fsSL https://goteleport.com/static/install.sh | bash -s 18.6.6"],
            "Teleport"
        )

        if success:
            installed, version = _check_command("tsh")
            if installed:
                result.append(f"✓ Teleport installed successfully!")
                result.append(f"  Version: {version}")
            else:
                result.append("✓ Install script completed. You may need to add tsh to your PATH.")
            return "\n".join(result)
        else:
            result.append(f"✗ Install failed: {output}")
            result.append("")
            result.append("Try manual installation:")
            result.append("  curl -O https://cdn.teleport.dev/teleport-v18.6.6-linux-amd64-bin.tar.gz")
            result.append("  tar -xzf teleport-v18.6.6-linux-amd64-bin.tar.gz")
            result.append("  sudo mv teleport/tsh /usr/local/bin/")
            return "\n".join(result)

    else:
        return f"""Teleport CLI (tsh) Installation

Your platform: {system} ({arch})

Please download from: https://goteleport.com/download/
"""


@mcp.tool()
def setup_install_kubectl() -> str:
    """
    Install kubectl for Kubernetes/Cube management.

    Attempts to install via Homebrew (macOS) or direct download.
    """
    system, arch = _get_platform()

    # Check if already installed
    installed, version = _check_command("kubectl")
    if installed:
        return f"kubectl is already installed.\n\nVersion: {version}"

    if system == "darwin":
        if _has_brew():
            result = ["Installing kubectl via Homebrew..."]
            success, output = _run_install(["brew", "install", "kubectl"], "kubectl")

            if success:
                installed, version = _check_command("kubectl")
                result.append(f"✓ kubectl installed successfully!")
                result.append(f"  Version: {version}")
                return "\n".join(result)
            else:
                result.append(f"✗ Homebrew install failed: {output}")
                return "\n".join(result)
        else:
            return """kubectl Installation - macOS

Homebrew not found. Install manually:

   curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/darwin/arm64/kubectl"
   chmod +x kubectl
   sudo mv kubectl /usr/local/bin/
   kubectl version --client
"""

    elif system == "linux":
        # Try direct download for Linux
        result = ["Installing kubectl..."]

        # Download kubectl
        download_cmd = [
            "bash", "-c",
            'curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl" && chmod +x kubectl && sudo mv kubectl /usr/local/bin/'
        ]
        success, output = _run_install(download_cmd, "kubectl")

        if success:
            installed, version = _check_command("kubectl")
            if installed:
                result.append(f"✓ kubectl installed successfully!")
                result.append(f"  Version: {version}")
            else:
                result.append("✓ Download completed. You may need to add kubectl to your PATH.")
            return "\n".join(result)
        else:
            result.append(f"✗ Install failed: {output}")
            result.append("")
            result.append("Try manual installation:")
            result.append('  curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"')
            result.append("  chmod +x kubectl")
            result.append("  sudo mv kubectl /usr/local/bin/")
            return "\n".join(result)

    else:
        return f"""kubectl Installation

Your platform: {system} ({arch})

Download from: https://kubernetes.io/docs/tasks/tools/
"""


@mcp.tool()
def setup_install_helm() -> str:
    """
    Install Helm for chart packaging and deployment.

    Attempts to install via Homebrew (macOS) or official install script.
    """
    system, arch = _get_platform()

    # Check if already installed
    installed, version = _check_command("helm")
    if installed:
        return f"Helm is already installed.\n\nVersion: {version}"

    if system == "darwin":
        if _has_brew():
            result = ["Installing Helm via Homebrew..."]
            success, output = _run_install(["brew", "install", "helm"], "Helm")

            if success:
                installed, version = _check_command("helm")
                result.append(f"✓ Helm installed successfully!")
                result.append(f"  Version: {version}")
                return "\n".join(result)
            else:
                result.append(f"✗ Homebrew install failed: {output}")
                return "\n".join(result)
        else:
            # Try the official install script
            result = ["Installing Helm via official script..."]
            success, output = _run_install(
                ["bash", "-c", "curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash"],
                "Helm"
            )
            if success:
                installed, version = _check_command("helm")
                result.append(f"✓ Helm installed successfully!")
                if installed:
                    result.append(f"  Version: {version}")
                return "\n".join(result)
            else:
                result.append(f"✗ Install failed: {output}")
                return "\n".join(result)

    elif system == "linux":
        # Try the official install script
        result = ["Installing Helm via official script..."]
        success, output = _run_install(
            ["bash", "-c", "curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash"],
            "Helm"
        )

        if success:
            installed, version = _check_command("helm")
            result.append(f"✓ Helm installed successfully!")
            if installed:
                result.append(f"  Version: {version}")
            return "\n".join(result)
        else:
            result.append(f"✗ Install failed: {output}")
            result.append("")
            result.append("Try manual installation:")
            result.append("  curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash")
            return "\n".join(result)

    else:
        return f"""Helm Installation

Your platform: {system} ({arch})

Download from: https://helm.sh/docs/intro/install/
"""


@mcp.tool()
def setup_install_docker() -> str:
    """
    Install Docker for building container images.

    On macOS, provides instructions for Docker Desktop.
    On Linux, attempts to install via the official script.
    """
    system, arch = _get_platform()

    # Check if already installed
    installed, version = _check_command("docker")
    if installed:
        return f"Docker is already installed.\n\nVersion: {version}"

    if system == "darwin":
        # macOS - Docker Desktop is required (can't be automated)
        # But we can try brew install --cask docker
        if _has_brew():
            result = ["Installing Docker Desktop via Homebrew..."]
            success, output = _run_install(["brew", "install", "--cask", "docker"], "Docker")

            if success:
                result.append("✓ Docker Desktop installed!")
                result.append("")
                result.append("IMPORTANT: You need to launch Docker Desktop from Applications")
                result.append("to complete setup. The docker CLI won't work until Docker Desktop is running.")
                return "\n".join(result)
            else:
                result.append(f"✗ Homebrew install failed: {output}")
                result.append("")
                result.append("Install manually from: https://www.docker.com/products/docker-desktop/")
                return "\n".join(result)
        else:
            return """Docker Installation - macOS

Docker Desktop is required on macOS.

1. Download Docker Desktop:
   https://www.docker.com/products/docker-desktop/

2. Install the .dmg file

3. Launch Docker Desktop from Applications

4. Verify installation:
   docker --version
"""

    elif system == "linux":
        # Linux - try the official install script
        result = ["Installing Docker via official script..."]
        success, output = _run_install(
            ["bash", "-c", "curl -fsSL https://get.docker.com | sh"],
            "Docker"
        )

        if success:
            installed, version = _check_command("docker")
            result.append("✓ Docker installed successfully!")
            if installed:
                result.append(f"  Version: {version}")
            result.append("")
            result.append("Note: You may need to run 'sudo usermod -aG docker $USER'")
            result.append("and log out/in for docker to work without sudo.")
            return "\n".join(result)
        else:
            result.append(f"✗ Install failed: {output}")
            result.append("")
            result.append("Try manual installation:")
            result.append("  curl -fsSL https://get.docker.com | sh")
            return "\n".join(result)

    else:
        return f"""Docker Installation

Your platform: {system} ({arch})

Download Docker Desktop from:
https://www.docker.com/products/docker-desktop/
"""


@mcp.tool()
def setup_install_apollo() -> str:
    """
    Provide instructions for installing Apollo CLI.

    Apollo CLI is a Palantir tool for publishing to Apollo.
    It must be downloaded from your organization's Apollo instance.
    """
    system, arch = _get_platform()

    # Check if already installed
    installed, version = _check_command("apollo-cli")
    if installed:
        return f"Apollo CLI is already installed.\n\nLocation: {version}\n\nRun 'apollo-cli --help' for usage."

    return f"""Apollo CLI Installation

Apollo CLI is a proprietary tool from Palantir and must be downloaded
from your organization's Apollo instance.

Platform: {system} ({arch})

Installation Steps:

1. Download the apollo-cli binary for your platform from your
   Apollo instance (ask your Apollo administrator for access)

2. Make it executable (macOS/Linux):
   chmod +x apollo-cli

3. Move to a directory in your PATH:
   # macOS/Linux
   mkdir -p ~/.local/bin
   mv apollo-cli ~/.local/bin/

   # Add to PATH if not already (add to ~/.bashrc or ~/.zshrc):
   export PATH="$HOME/.local/bin:$PATH"

4. Verify installation:
   apollo-cli --help

Contact your Apollo administrator if you need help obtaining
the apollo-cli binary.
"""


@mcp.tool()
def setup_configure_credentials() -> str:
    """
    Help configure Apollo credentials (APOLLO_CLIENT and APOLLO_SECRET).

    These are required for pushing to Apollo Container Registry.
    """
    client_id, client_secret = _get_apollo_credentials()

    if client_id and client_secret:
        return f"""Apollo Credentials Status

✓ APOLLO_CLIENT is set: {client_id[:8]}...
✓ APOLLO_SECRET is set: {'*' * 8}

Your credentials are configured! You can use:
- acr_login: Login to Apollo Container Registry
- build_and_publish_to_apollo: Build and publish your app
"""

    # Detect shell
    shell = os.environ.get("SHELL", "/bin/bash")
    if "zsh" in shell:
        rc_file = "~/.zshrc"
    else:
        rc_file = "~/.bashrc"

    return f"""Apollo Credentials Configuration

Run this command to configure Apollo CLI:

  apollo-cli configure

This will prompt you for your Apollo URL and credentials.

Alternatively, set environment variables manually in {rc_file}:

  export APOLLO_CLIENT="your-client-id"
  export APOLLO_SECRET="your-client-secret"

Then reload: source {rc_file}

Current Status:
{'✓' if client_id else '✗'} APOLLO_CLIENT: {'Set' if client_id else 'NOT SET'}
{'✓' if client_secret else '✗'} APOLLO_SECRET: {'Set' if client_secret else 'NOT SET'}
"""


# ============================================================================
# Cube Management Tools
# ============================================================================

@mcp.tool()
def cube_login(cluster: str, proxy: str = DEFAULT_PROXY) -> str:
    """
    Login to a Cube cluster via Teleport (proxy: edgescaleai.teleport.sh).
    This will authenticate you via SSO and set up kubectl access.

    Args:
        cluster: Cube cluster name to connect to (e.g., staging-int, staging-pre-prod, ironmountain-v4)
        proxy: Teleport proxy URL. Defaults to edgescaleai.teleport.sh
    """
    try:
        # Check if already logged into Teleport
        status_result = subprocess.run(
            ["tsh", "status"],
            capture_output=True,
            text=True,
            timeout=10
        )

        teleport_logged_in = (
            status_result.returncode == 0 and
            "EXPIRED" not in status_result.stdout and
            proxy in status_result.stdout
        )

        if not teleport_logged_in:
            # Guide user to login - show both options
            return f"""You need to login to Teleport first.

Choose one of these options:

**Option 1: Okta SSO** (opens browser)
  tsh login --proxy={proxy} --auth=okta

**Option 2: Username/Password**
  tsh login --proxy={proxy} --user=<your-username>

Run the command in your terminal, then ask me to connect to '{cluster}' again."""

        # Already logged in - connect to the Cube cluster
        kube_result = subprocess.run(
            ["tsh", "kube", "login", cluster],
            capture_output=True,
            text=True,
            timeout=30
        )

        if kube_result.returncode != 0:
            return f"Failed to connect to Cube '{cluster}':\n{kube_result.stderr}\n\nUse cube_list to see available Cubes."

        return f"""✓ Connected to Cube: {cluster}

You can now use:
- cube_status: Check node health
- cube_list: See other available Cubes"""

    except subprocess.TimeoutExpired:
        return "Connection timed out. Check your network."
    except FileNotFoundError:
        return "Teleport client (tsh) not found.\n\nUse setup_install_teleport to install it."


@mcp.tool()
def cube_login_password(cluster: str, username: str, proxy: str = DEFAULT_PROXY) -> str:
    """
    Login to a Cube cluster via Teleport using username/password.

    Args:
        cluster: Cube cluster name to connect to (e.g., staging-int, staging-pre-prod, ironmountain-v4)
        username: Your Teleport username
        proxy: Teleport proxy URL. Defaults to edgescaleai.teleport.sh
    """
    return f"""Run this command in your terminal:

  tsh login --proxy={proxy} --user={username} {cluster}

You will be prompted for your password.

Once complete, ask me to connect to '{cluster}' again."""


@mcp.tool()
def cube_list() -> str:
    """
    List all available Cube clusters accessible via Teleport.
    Requires being logged into Teleport first.
    """
    try:
        # Check if logged in first
        status_result = subprocess.run(
            ["tsh", "status"],
            capture_output=True,
            text=True,
            timeout=10
        )

        if status_result.returncode != 0 or "EXPIRED" in status_result.stdout:
            return f"Not logged into Teleport or session expired.\n\nRun cube_login first to authenticate, or manually:\n  tsh login --proxy={DEFAULT_PROXY}"

        # List available Kubernetes clusters
        list_result = subprocess.run(
            ["tsh", "kube", "ls"],
            capture_output=True,
            text=True,
            timeout=30
        )

        if list_result.returncode != 0:
            return f"Failed to list Cubes:\n{list_result.stderr}"

        return f"Available Cubes:\n\n{list_result.stdout}\n\nUse cube_login with a cluster name to connect."

    except subprocess.TimeoutExpired:
        return "Command timed out. Check your network connection."
    except FileNotFoundError:
        return "Teleport client (tsh) not found.\n\nInstall it from: https://goteleport.com/download/"


@mcp.tool()
def cube_status() -> str:
    """
    Get the status of the connected Cube node.
    Shows node conditions, capacity, and resource usage.
    """
    try:
        # First, get the node name
        get_nodes = subprocess.run(
            ["kubectl", "--insecure-skip-tls-verify", "get", "nodes", "-o", "jsonpath={.items[0].metadata.name}"],
            capture_output=True,
            text=True,
            timeout=30
        )

        if get_nodes.returncode != 0:
            return f"Failed to get node. Are you connected to a Cube?\n\nError: {get_nodes.stderr}\n\nUse cube_login first to connect."

        node_name = get_nodes.stdout.strip()
        if not node_name:
            return "No nodes found. The Cube may not be running or you may not be connected."

        # Get detailed node status
        describe_result = subprocess.run(
            ["kubectl", "--insecure-skip-tls-verify", "describe", "node", node_name],
            capture_output=True,
            text=True,
            timeout=30
        )

        if describe_result.returncode != 0:
            return f"Failed to describe node:\n{describe_result.stderr}"

        return f"Cube Node Status ({node_name}):\n\n{describe_result.stdout}"

    except subprocess.TimeoutExpired:
        return "Command timed out. The Cube may be unresponsive."
    except FileNotFoundError:
        return "kubectl not found. Ensure it's installed and in your PATH."


# ============================================================================
# App Proxy Tools - Access Teleport apps locally
# ============================================================================

@mcp.tool()
def app_list(company: str = None) -> str:
    """
    List available Teleport apps.

    Shows apps accessible via Teleport including HTTP and TCP apps
    like databases, MQTT brokers, web UIs, etc.

    Args:
        company: Optional filter by company label (e.g., "edgescaleai", "lear", "conagra")
    """
    try:
        # Check if logged in first
        status_result = subprocess.run(
            ["tsh", "status"],
            capture_output=True,
            text=True,
            timeout=10
        )

        if status_result.returncode != 0 or "EXPIRED" in status_result.stdout:
            return f"""Not logged into Teleport or session expired.

Run cube_login first to authenticate, or manually:
  tsh login --proxy={DEFAULT_PROXY} --auth=okta"""

        # List apps in JSON format
        list_result = subprocess.run(
            ["tsh", "apps", "ls", "--format=json"],
            capture_output=True,
            text=True,
            timeout=30
        )

        if list_result.returncode != 0:
            return f"Failed to list apps:\n{list_result.stderr}"

        apps = json.loads(list_result.stdout)

        # Filter by company if specified
        if company:
            apps = [
                app for app in apps
                if app.get("metadata", {}).get("labels", {}).get("company", "").lower() == company.lower()
            ]

        if not apps:
            if company:
                return f"No apps found for company '{company}'."
            return "No apps found."

        # Format output
        lines = ["Available Apps:", "=" * 60]

        # Group by company
        by_company = {}
        for app in apps:
            labels = app.get("metadata", {}).get("labels", {})
            comp = labels.get("company", "unknown")
            if comp not in by_company:
                by_company[comp] = []
            by_company[comp].append(app)

        for comp in sorted(by_company.keys()):
            lines.append(f"\n[{comp}]")
            for app in sorted(by_company[comp], key=lambda x: x["metadata"]["name"]):
                name = app["metadata"]["name"]
                spec = app.get("spec", {})
                public_addr = spec.get("public_addr", "")
                uri = spec.get("uri", "")

                # Determine type from URI
                app_type = "TCP" if uri.startswith("tcp://") else "HTTP"

                lines.append(f"  {name}")
                lines.append(f"    Type: {app_type}")
                if public_addr:
                    lines.append(f"    URL:  https://{public_addr}")

        lines.append("")
        lines.append("Use app_proxy to start a local proxy for any app.")

        return "\n".join(lines)

    except subprocess.TimeoutExpired:
        return "Command timed out. Check your network connection."
    except FileNotFoundError:
        return "Teleport client (tsh) not found.\n\nUse setup_install_teleport to install it."
    except json.JSONDecodeError as e:
        return f"Failed to parse app list: {e}"


@mcp.tool()
def app_login(app: str) -> str:
    """
    Login to a Teleport app to get a certificate.

    This retrieves a short-lived certificate for the app.
    Required before starting a proxy for some apps.

    Args:
        app: App name (from app_list)
    """
    try:
        # Check if logged into Teleport
        status_result = subprocess.run(
            ["tsh", "status"],
            capture_output=True,
            text=True,
            timeout=10
        )

        if status_result.returncode != 0 or "EXPIRED" in status_result.stdout:
            return f"""Not logged into Teleport or session expired.

Run cube_login first to authenticate, or manually:
  tsh login --proxy={DEFAULT_PROXY} --auth=okta"""

        # Login to the app
        login_result = subprocess.run(
            ["tsh", "app", "login", app],
            capture_output=True,
            text=True,
            timeout=30
        )

        if login_result.returncode != 0:
            return f"Failed to login to app '{app}':\n{login_result.stderr}\n\nUse app_list to see available apps."

        return f"""✓ Logged into app: {app}

You can now:
- Use app_proxy to start a local proxy
- Access HTTP apps directly via their public URL"""

    except subprocess.TimeoutExpired:
        return "Command timed out. Check your network connection."
    except FileNotFoundError:
        return "Teleport client (tsh) not found.\n\nUse setup_install_teleport to install it."


@mcp.tool()
def app_proxy(app: str, port: int = None) -> str:
    """
    Start a local proxy for a Teleport app.

    This creates a local endpoint that proxies to the remote app.
    Essential for TCP apps like MQTT/Mosquitto, databases, etc.

    For HTTP apps, you can also access them directly via their public URL
    after running app_login.

    Args:
        app: App name (from app_list)
        port: Local port to listen on (auto-assigned if not specified)
    """
    global _running_proxies

    try:
        # Check if already proxying this app
        if app in _running_proxies:
            proc = _running_proxies[app]
            if proc.poll() is None:  # Still running
                return f"Proxy for '{app}' is already running.\n\nUse app_proxy_stop to stop it first."
            else:
                # Process died, clean up
                del _running_proxies[app]

        # Check if logged into Teleport
        status_result = subprocess.run(
            ["tsh", "status"],
            capture_output=True,
            text=True,
            timeout=10
        )

        if status_result.returncode != 0 or "EXPIRED" in status_result.stdout:
            return f"""Not logged into Teleport or session expired.

Run cube_login first to authenticate, or manually:
  tsh login --proxy={DEFAULT_PROXY} --auth=okta"""

        # Login to the app first (required for proxy)
        login_result = subprocess.run(
            ["tsh", "app", "login", app],
            capture_output=True,
            text=True,
            timeout=30
        )

        if login_result.returncode != 0:
            return f"Failed to login to app '{app}':\n{login_result.stderr}\n\nUse app_list to see available apps."

        # Build proxy command
        cmd = ["tsh", "proxy", "app", app]
        if port:
            cmd.extend(["--port", str(port)])

        # Start proxy in background
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        # Wait briefly for startup and capture output
        import time
        time.sleep(2)

        # Check if it started successfully
        if proc.poll() is not None:
            # Process exited - get error
            _, stderr = proc.communicate(timeout=5)
            return f"Failed to start proxy for '{app}':\n{stderr}"

        # Store the running process
        _running_proxies[app] = proc

        # Try to get the local address from stderr (tsh prints it there)
        # Format: "Proxying connections to <app> on <host>:<port>"
        import select
        local_addr = None

        # Non-blocking read of stderr
        if proc.stderr:
            import fcntl
            fd = proc.stderr.fileno()
            fl = fcntl.fcntl(fd, fcntl.F_GETFL)
            fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
            try:
                output = proc.stderr.read()
                if output:
                    # Parse the address
                    match = re.search(r'(\d+\.\d+\.\d+\.\d+:\d+|localhost:\d+|127\.0\.0\.1:\d+)', output)
                    if match:
                        local_addr = match.group(1)
            except:
                pass

        # Build response
        result = [f"✓ Proxy started for: {app}"]

        if local_addr:
            result.append(f"\nLocal address: {local_addr}")
        else:
            result.append(f"\nLocal address: localhost:{port or '(check tsh output)'}")

        # Add usage hints based on app name
        app_lower = app.lower()
        if "mosquitto" in app_lower or "mqtt" in app_lower:
            result.append(f"""
MQTT Connection:
  Host: localhost
  Port: {port or '(see above)'}

Example (mosquitto_sub):
  mosquitto_sub -h localhost -p {port or '<port>'} -t '#'""")
        elif "rabbit" in app_lower:
            result.append(f"""
RabbitMQ Management UI:
  http://localhost:{port or '<port>'}""")
        elif "sql" in app_lower or "trino" in app_lower:
            result.append(f"""
Database connection:
  Host: localhost
  Port: {port or '<port>'}""")

        result.append("\nUse app_proxy_stop to stop the proxy when done.")

        return "\n".join(result)

    except subprocess.TimeoutExpired:
        return "Command timed out. Check your network connection."
    except FileNotFoundError:
        return "Teleport client (tsh) not found.\n\nUse setup_install_teleport to install it."
    except Exception as e:
        return f"Error starting proxy: {e}"


@mcp.tool()
def app_proxy_stop(app: str = None) -> str:
    """
    Stop a running app proxy.

    Args:
        app: App name to stop. If not specified, stops all proxies.
    """
    global _running_proxies

    if not _running_proxies:
        return "No proxies are currently running."

    stopped = []
    errors = []

    if app:
        # Stop specific app
        if app not in _running_proxies:
            return f"No proxy running for '{app}'.\n\nRunning proxies: {', '.join(_running_proxies.keys())}"

        proc = _running_proxies[app]
        try:
            proc.terminate()
            proc.wait(timeout=5)
            stopped.append(app)
        except subprocess.TimeoutExpired:
            proc.kill()
            stopped.append(f"{app} (killed)")
        except Exception as e:
            errors.append(f"{app}: {e}")
        finally:
            del _running_proxies[app]
    else:
        # Stop all
        for app_name, proc in list(_running_proxies.items()):
            try:
                proc.terminate()
                proc.wait(timeout=5)
                stopped.append(app_name)
            except subprocess.TimeoutExpired:
                proc.kill()
                stopped.append(f"{app_name} (killed)")
            except Exception as e:
                errors.append(f"{app_name}: {e}")
        _running_proxies.clear()

    result = []
    if stopped:
        result.append(f"✓ Stopped proxies: {', '.join(stopped)}")
    if errors:
        result.append(f"✗ Errors: {', '.join(errors)}")

    return "\n".join(result) or "No proxies were stopped."


@mcp.tool()
def app_proxy_status() -> str:
    """
    Show status of running app proxies.
    """
    global _running_proxies

    if not _running_proxies:
        return "No proxies are currently running.\n\nUse app_proxy to start one."

    lines = ["Running App Proxies:", "=" * 40]

    for app_name, proc in list(_running_proxies.items()):
        if proc.poll() is None:
            lines.append(f"  ✓ {app_name} (PID: {proc.pid})")
        else:
            lines.append(f"  ✗ {app_name} (stopped)")
            del _running_proxies[app_name]

    lines.append("")
    lines.append("Use app_proxy_stop to stop proxies.")

    return "\n".join(lines)


# ============================================================================
# ACR (Apollo Container Registry) Tools
# ============================================================================

@mcp.tool()
def acr_get_token() -> str:
    """
    Get an OAuth2 access token from Apollo Container Registry.

    Requires APOLLO_CLIENT and APOLLO_SECRET environment variables.
    Useful for debugging or manual operations.
    """
    token, error = _get_acr_token()
    if error:
        return error

    return f"Successfully retrieved ACR token.\n\nToken (first 20 chars): {token[:20]}...\n\nUse acr_login to authenticate Docker and Helm."


@mcp.tool()
def acr_login() -> str:
    """
    Login to Apollo Container Registry for both Docker and Helm.

    Requires APOLLO_CLIENT and APOLLO_SECRET environment variables.
    This authenticates you to push Docker images and Helm charts to ACR.
    """
    token, error = _get_acr_token()
    if error:
        return error

    results = []

    # Docker login
    try:
        docker_result = subprocess.run(
            ["docker", "login", ACR_REGISTRY, "--username", "apollo", "--password-stdin"],
            input=token,
            capture_output=True,
            text=True,
            timeout=30
        )
        if docker_result.returncode == 0:
            results.append(f"✓ Docker logged in to {ACR_REGISTRY}")
        else:
            results.append(f"✗ Docker login failed: {docker_result.stderr}")
    except FileNotFoundError:
        results.append("✗ Docker not found (skipping)")
    except Exception as e:
        results.append(f"✗ Docker login error: {e}")

    # Helm registry login
    try:
        helm_result = subprocess.run(
            ["helm", "registry", "login", ACR_REGISTRY, "--username", "apollo", "--password-stdin"],
            input=token,
            capture_output=True,
            text=True,
            timeout=30
        )
        if helm_result.returncode == 0:
            results.append(f"✓ Helm logged in to {ACR_REGISTRY}")
        else:
            results.append(f"✗ Helm login failed: {helm_result.stderr}")
    except FileNotFoundError:
        results.append("✗ Helm not found")
    except Exception as e:
        results.append(f"✗ Helm login error: {e}")

    return "ACR Login Results:\n\n" + "\n".join(results)


@mcp.tool()
def build_and_publish_to_apollo(
    chart_path: str = None,
    version: str = None,
    bump: str = "patch",
    app_version: str = None,
    skip_docker: bool = False,
    dry_run: bool = False
) -> str:
    """
    Build and publish an app to Apollo Container Registry.

    This builds your app and publishes it to Apollo, making it available
    for deployment to Cube environments. It does NOT deploy to a Cube -
    that's a separate step done from Apollo.

    Pipeline:
    1. Login to ACR (Docker + Helm registries)
    2. Build and push Docker image (if Dockerfile found, multi-arch)
    3. Bump Chart.yaml version
    4. Package Helm chart
    5. Push Helm chart to ACR (OCI registry)
    6. Publish manifest to Apollo (makes it available for deployment)

    Args:
        chart_path: Path to chart directory or Chart.yaml (auto-detected if not specified)
        version: Exact version to use (e.g., "1.0.0"). If not specified, bumps current version.
        bump: Version bump type: "patch" (default), "minor", or "major". Ignored if version is specified.
        app_version: New appVersion for Docker image tag. If not specified, uses chart version.
        skip_docker: Skip Docker build/push even if Dockerfile exists.
        dry_run: Show what would be done without actually doing it.
    """
    steps = []
    errors = []

    # Step 1: Find and parse Chart.yaml
    chart_yaml, error = _find_chart_yaml(chart_path)
    if error:
        return f"❌ {error}"

    chart_info, error = _parse_chart_yaml(chart_yaml)
    if error:
        return f"❌ {error}"

    chart_dir = chart_info["dir"]
    chart_name = chart_info["name"]
    current_version = chart_info["version"]

    # Calculate new version
    if version:
        new_version = version
    else:
        new_version = _bump_version(current_version, bump)

    # Calculate app version (for Docker tag)
    new_app_version = app_version or new_version

    # Check for Dockerfile
    dockerfile_path = os.path.join(chart_dir, "Dockerfile")
    if not os.path.isfile(dockerfile_path):
        dockerfile_path = os.path.join(os.path.dirname(chart_dir), "Dockerfile")
    has_dockerfile = os.path.isfile(dockerfile_path) and not skip_docker

    # Build summary
    summary = f"""
📦 Helm Deploy Summary
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Chart:        {chart_name}
Path:         {chart_yaml}
Version:      {current_version} → {new_version}
App Version:  {chart_info.get('appVersion', 'N/A')} → {new_app_version}
Docker Build: {'Yes' if has_dockerfile else 'No (no Dockerfile)'}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Pipeline:
1. Login to ACR
2. {'Build & push Docker image' if has_dockerfile else '(skip Docker - no Dockerfile)'}
3. Update Chart.yaml version
4. Package Helm chart
5. Push to ACR: {ACR_HELM_PREFIX}/{chart_name}
6. Publish to Apollo
"""

    if dry_run:
        return summary + "\n🔍 DRY RUN - No changes made."

    steps.append(summary)

    # Step 2: Login to ACR
    token, error = _get_acr_token()
    if error:
        return f"❌ ACR Login Failed:\n{error}"

    # Docker login
    try:
        docker_login = subprocess.run(
            ["docker", "login", ACR_REGISTRY, "--username", "apollo", "--password-stdin"],
            input=token,
            capture_output=True,
            text=True,
            timeout=30
        )
        if docker_login.returncode == 0:
            steps.append("✓ Docker logged in")
        else:
            steps.append(f"⚠ Docker login failed (continuing): {docker_login.stderr.strip()}")
    except Exception as e:
        steps.append(f"⚠ Docker login skipped: {e}")

    # Helm login
    try:
        helm_login = subprocess.run(
            ["helm", "registry", "login", ACR_REGISTRY, "--username", "apollo", "--password-stdin"],
            input=token,
            capture_output=True,
            text=True,
            timeout=30
        )
        if helm_login.returncode == 0:
            steps.append("✓ Helm logged in")
        else:
            return f"❌ Helm login failed: {helm_login.stderr}"
    except FileNotFoundError:
        return "❌ Helm not found. Please install Helm."

    # Step 3: Build and push Docker image (if applicable)
    if has_dockerfile:
        docker_tag = f"{ACR_DOCKER_PREFIX}/{chart_name}:{new_app_version}"
        steps.append(f"Building Docker image: {docker_tag}")

        try:
            # Build with buildx for multi-arch
            build_result = subprocess.run(
                [
                    "docker", "buildx", "build",
                    "--platform", "linux/amd64,linux/arm64",
                    "--tag", docker_tag,
                    "--output", "type=image,push=true",
                    os.path.dirname(dockerfile_path) or "."
                ],
                capture_output=True,
                text=True,
                timeout=600  # 10 min timeout for builds
            )
            if build_result.returncode == 0:
                steps.append(f"✓ Docker image pushed: {docker_tag}")
            else:
                errors.append(f"Docker build failed: {build_result.stderr}")
                steps.append(f"✗ Docker build failed (continuing with Helm only)")
        except subprocess.TimeoutExpired:
            errors.append("Docker build timed out")
            steps.append("✗ Docker build timed out (continuing with Helm only)")
        except Exception as e:
            errors.append(f"Docker error: {e}")
            steps.append(f"✗ Docker error: {e} (continuing with Helm only)")

    # Step 4: Update Chart.yaml version
    success, error = _update_chart_version(chart_yaml, new_version, new_app_version if has_dockerfile else None)
    if not success:
        return f"❌ Failed to update Chart.yaml: {error}"
    steps.append(f"✓ Updated Chart.yaml to version {new_version}")

    # Step 5: Package Helm chart
    try:
        # Run helm dependency update
        dep_result = subprocess.run(
            ["helm", "dependency", "update"],
            cwd=chart_dir,
            capture_output=True,
            text=True,
            timeout=120
        )
        if dep_result.returncode != 0:
            steps.append(f"⚠ helm dependency update warning: {dep_result.stderr.strip()}")

        # Package
        package_result = subprocess.run(
            ["helm", "package", "."],
            cwd=chart_dir,
            capture_output=True,
            text=True,
            timeout=60
        )
        if package_result.returncode != 0:
            return f"❌ Helm package failed: {package_result.stderr}"

        tgz_file = f"{chart_name}-{new_version}.tgz"
        tgz_path = os.path.join(chart_dir, tgz_file)
        steps.append(f"✓ Packaged: {tgz_file}")
    except Exception as e:
        return f"❌ Helm package error: {e}"

    # Step 6: Push to ACR
    try:
        push_result = subprocess.run(
            ["helm", "push", tgz_path, ACR_HELM_PREFIX],
            capture_output=True,
            text=True,
            timeout=120
        )
        if push_result.returncode != 0:
            return f"❌ Helm push failed: {push_result.stderr}"
        steps.append(f"✓ Pushed to {ACR_HELM_PREFIX}/{chart_name}")

        # Clean up .tgz file
        try:
            os.remove(tgz_path)
        except:
            pass
    except Exception as e:
        return f"❌ Helm push error: {e}"

    # Step 7: Publish to Apollo via apollo-cli
    client_id, client_secret = _get_apollo_credentials()
    oci_url = f"{ACR_HELM_PREFIX}/{chart_name}"
    maven_coordinate = f"{APOLLO_GROUP_ID}:{chart_name}:{new_version}"
    manifest_path = "/tmp/manifest.yml"

    try:
        # Generate manifest.yml using apollo-cli
        init_cmd = [
            "apollo-cli", "product-release", "helm-chart", "init",
            "--maven-coordinate", maven_coordinate,
            "--name", oci_url,
            "--pass-credentials",
            "--repository-url", oci_url,
            "--output-dir", "/tmp/",
            "--username", "apollo",
            "--password", token,
            "--version", new_version,
            "--apollo-client-id", client_id,
            "--apollo-client-secret", client_secret,
            "--apollo-url", APOLLO_URL,
        ]

        init_result = subprocess.run(
            init_cmd,
            capture_output=True,
            text=True,
            timeout=60
        )

        if init_result.returncode != 0:
            errors.append(f"apollo-cli init failed: {init_result.stderr}")
            steps.append(f"⚠ Apollo manifest generation failed: {init_result.stderr.strip()}")
        else:
            steps.append("✓ Generated Apollo manifest")

            # Publish manifest to Apollo
            publish_cmd = [
                "apollo-cli", "publish", "manifest",
                f"--manifest-file={manifest_path}",
                "--apollo-client-id", client_id,
                "--apollo-client-secret", client_secret,
                "--apollo-url", APOLLO_URL,
            ]

            publish_result = subprocess.run(
                publish_cmd,
                capture_output=True,
                text=True,
                timeout=60
            )

            if publish_result.returncode != 0:
                errors.append(f"apollo-cli publish failed: {publish_result.stderr}")
                steps.append(f"⚠ Apollo publish failed: {publish_result.stderr.strip()}")
            else:
                steps.append("✓ Published to Apollo")

    except FileNotFoundError:
        errors.append("apollo-cli not found")
        steps.append("⚠ apollo-cli not found - skipping Apollo publish. Install with: pip install apollo-cli")
    except Exception as e:
        errors.append(f"Apollo error: {e}")
        steps.append(f"⚠ Apollo publish error: {e}")

    # Final summary
    result = "\n".join(steps)
    result += f"\n\n{'🎉' if not errors else '⚠️'} Deployment {'complete' if not errors else 'completed with warnings'}!"
    result += f"\n\nChart: {chart_name}:{new_version}"
    result += f"\nHelm:  {ACR_HELM_PREFIX}/{chart_name}"

    if errors:
        result += f"\n\nWarnings:\n" + "\n".join(f"  - {e}" for e in errors)

    return result


def main():
    mcp.run()


if __name__ == "__main__":
    main()
