"""Cubesquare - Instant Semantic Memory

The semantic memory system built for production AI.
83M ops/sec. 0.04ms queries. 100% deterministic.

Quick Start:
    from cubesquare import CSTMemory

    memory = CSTMemory()
    memory.write("/src/auth.py")              # 5.97 nanoseconds
    results = memory.query("authentication")  # 0.04ms
    print(results[0].basin)                   # 42 - semantic cluster

Layers:
    memory.L1  # Geometric - file/folder hierarchy
    memory.L2  # Semantic - meaning and concept
    memory.L3  # Spatial - nearby content
    memory.L4  # Functional - abstraction level
    memory.L5  # Probabilistic - usage patterns
    memory.L6  # Emotional - sentiment mapping
    memory.L7  # Frequency - wavelength/energy
    memory.L8  # Electromagnetic - force dynamics
    memory.L9  # Membrane - coherence/healing

I-Logic (Algebraic State Composition):
    from cubesquare.i_logic import multiply, compose, predict_route

    # O(1) state multiplication
    result = multiply(SPIRAL, INVERSE)  # -> ANTI_SPIRAL

    # Predict routing outcome
    prediction = predict_route("gateway:DIRECT,firewall:INVERSE,sink:ABSORBED")

Primitives (Verified O(1) Operations):
    from cubesquare.primitives import morton, basin, srl, i_logic

    morton.encode(x, y, z)  # O(1), 21 ops
    basin.compute(x, y, z)  # O(1), 8 ops
    srl.sqrt(distance)      # O(1), <=25 iter
"""

__version__ = "1.0.0"
__author__ = "Cubesquare"

# Main API
from .memory import CSTMemory

# Token
from .layers import Token

# Core constants
from ._core import (
    PHI,
    K5,
    K11,
    PRIME_131,
    LIGHT_UNIT,
    srl_sqrt,
    morton_encode,
    morton_decode,
    compute_basin,
    native_is_loaded,
)

# New Tooling Enhancements
from .explain import explain, DeepExplainer
from .session import SessionHelper
from .ui import launch as launch_visualizer

# Basin Population, Agent Swarm, Learning Loop
from .population import BasinPopulator
from .swarm import Swarm
from .training import TrainingLoop

# Layer classes
from .layers import (
    L1_Geometric,
    L2_Semantic,
    L3_Spatial,
    L4_Functional,
    L5_Probabilistic,
    L6_Emotional,
    L7_Frequency,
    L8_Electromagnetic,
    L9_Membrane,
)

__all__ = [
    # Version
    "__version__",
    # Main API
    "CSTMemory",
    "Token",
    "status",
    # Constants
    "PHI",
    "K5",
    "K11",
    "PRIME_131",
    "LIGHT_UNIT",
    "srl_sqrt",
    "morton_encode",
    "morton_decode",
    "compute_basin",
    "native_is_loaded",
    # Tools
    "explain",
    "DeepExplainer",
    "SessionHelper",
    "launch_visualizer",
    # Population, Swarm, Learning
    "BasinPopulator",
    "Swarm",
    "TrainingLoop",
    # Layers
    "L1_Geometric",
    "L2_Semantic",
    "L3_Spatial",
    "L4_Functional",
    "L5_Probabilistic",
    "L6_Emotional",
    "L7_Frequency",
    "L8_Electromagnetic",
    "L9_Membrane",
]


def status():
    """Get current system status."""
    from ._core import native_is_loaded

    return {
        "version": __version__,
        "native_backend": native_is_loaded(),
        "layers_enabled": list(range(1, 10)),
        "basins_enabled": 131,
        "primitives": {
            "morton": "O(1), 21 ops",
            "basin": "O(1), 8 ops",
            "srl": "O(1), <=25 iter",
            "i_logic": "O(1) * N",
        },
    }
