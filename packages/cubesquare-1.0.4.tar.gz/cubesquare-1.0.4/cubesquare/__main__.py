"""Main entry point for python -m cubesquare"""
from .cli import main

if __name__ == "__main__":
    main()
