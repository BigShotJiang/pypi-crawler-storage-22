"""Cubesquare Constants

Mathematical constants that define the CST system.
"""

# Golden ratio
PHI = 1.618033988749895

# K5: Basin clustering constant
# K5 = 15 / (8 * PHI) = 1.158814...
# K5 * 113 = 131 (prime, number of basins)
# K5 * 36 = 41.72 Hz (bubble frequency at centroid)
K5 = 1.158814

# K11: Agent field constant
# K11 = 9.204026
# K11 * 11 = 101 (agent field size)
K11 = 9.204026

# Prime 131: Number of basins
# This is THE prime that defines the CST space
PRIME_131 = 131

# Light unit: Same as PRIME_131
LIGHT_UNIT = 131

# Matrix size: 48x48x48 = 110,592 cells
MATRIX_SIZE = 48

# Basin to layer mapping
LAYER_BASINS = {
    1: range(0, 15),     # L1 GEOMETRIC
    2: range(15, 30),    # L2 SEMANTIC
    3: range(30, 44),    # L3 SPATIAL
    4: range(44, 59),    # L4 FUNCTIONAL
    5: range(59, 73),    # L5 PROBABILISTIC
    6: range(73, 88),    # L6 EMOTIONAL
    7: range(88, 102),   # L7 FREQUENCY
    8: range(102, 117),  # L8 ELECTROMAGNETIC
    9: range(117, 131),  # L9 MEMBRANE
}

# Layer names
LAYER_NAMES = {
    1: "GEOMETRIC",
    2: "SEMANTIC",
    3: "SPATIAL",
    4: "FUNCTIONAL",
    5: "PROBABILISTIC",
    6: "EMOTIONAL",
    7: "FREQUENCY",
    8: "ELECTROMAGNETIC",
    9: "MEMBRANE",
}
