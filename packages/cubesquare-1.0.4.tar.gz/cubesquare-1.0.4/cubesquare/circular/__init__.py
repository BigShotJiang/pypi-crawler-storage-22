"""
Circular System - 3D Unit Sphere I-Logic
Standalone version for cubesquare package.

Provides circular relationship detection, I-Logic 4-state stabilization,
and SRL (Self-Referential Loop) pathfinding.

Core Principles:
- O(1) SRL computation: t = d/t -> t = sqrt(d)
- I-Logic 4-state machine: DIRECT/INVERSE/SPIRAL/ANTI_SPIRAL/ABSORBED
- Morton Z-order encoding
- BFS pathfinding with Python fallback
"""

__version__ = "1.0.0"
__hex_id__ = "0BF1DD00"

__all__ = [
    # Classes
    'CircularLoopDetector',
    'ILogicStateMachine',
    'CircularValidator',

    # Functions
    'srl_distance',
    'bounded_sqrt',

    # 3D Unit Sphere Intrinsic Functions
    'get_k11_level',
    'get_intrinsic_state_from_k11',
    'get_phi_norm_distance',
    'get_sphere_coords',
    'get_wave_particle_strength',
    'get_intrinsic_stability',
    'is_intrinsically_stable',
    'hex_to_coords',

    # Enums
    'ILogicState',
    'LoopStability',

    # Results
    'CircularRefResult',
    'ValidationResult',
]

# Lazy imports for performance
def __getattr__(name):
    """Lazy module loading."""
    if name == 'CircularLoopDetector' or name == 'CircularRefResult':
        from .loop_detector import CircularLoopDetector, CircularRefResult
        return CircularLoopDetector if name == 'CircularLoopDetector' else CircularRefResult

    elif name == 'ILogicStateMachine' or name == 'ILogicState':
        from .state_machine import ILogicStateMachine, ILogicState
        return ILogicStateMachine if name == 'ILogicStateMachine' else ILogicState

    elif name in ('srl_distance', 'bounded_sqrt'):
        from .srl_integration import srl_distance, bounded_sqrt
        return {'srl_distance': srl_distance, 'bounded_sqrt': bounded_sqrt}[name]

    elif name == 'CircularValidator' or name == 'ValidationResult':
        from .validation import CircularValidator, ValidationResult
        return CircularValidator if name == 'CircularValidator' else ValidationResult

    elif name == 'LoopStability':
        from .loop_detector import LoopStability
        return LoopStability

    elif name in ('get_k11_level', 'get_intrinsic_state_from_k11', 'get_phi_norm_distance',
                  'get_sphere_coords', 'get_wave_particle_strength', 'get_intrinsic_stability',
                  'is_intrinsically_stable', 'hex_to_coords'):
        from .state_machine import (
            get_k11_level, get_intrinsic_state_from_k11, get_phi_norm_distance,
            get_sphere_coords, get_wave_particle_strength, get_intrinsic_stability,
            is_intrinsically_stable, hex_to_coords
        )
        return {
            'get_k11_level': get_k11_level,
            'get_intrinsic_state_from_k11': get_intrinsic_state_from_k11,
            'get_phi_norm_distance': get_phi_norm_distance,
            'get_sphere_coords': get_sphere_coords,
            'get_wave_particle_strength': get_wave_particle_strength,
            'get_intrinsic_stability': get_intrinsic_stability,
            'is_intrinsically_stable': is_intrinsically_stable,
            'hex_to_coords': hex_to_coords,
        }[name]

    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


CIRCULAR_SYSTEM_INFO = {
    'name': 'Circular System',
    'hex_id': '0BF1DD00',
    'version': '1.0.0',
    'description': 'Self-referential loop handling via I-Logic 4-state',
    'key_principle': 'Loops are INSIDE the unit - self-referential, bounded',
}


def get_system_info():
    """Get circular system metadata."""
    return CIRCULAR_SYSTEM_INFO.copy()
