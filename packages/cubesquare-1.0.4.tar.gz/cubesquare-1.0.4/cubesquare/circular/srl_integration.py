"""
SRL Integration - Self-Referential Loop Pathfinding
Standalone version for cubesquare package.

SRL Formula: t = d/t -> t^2 = d -> t = sqrt(d)
O(1) computation via Python math.isqrt.
"""

import math
from typing import List


# Constants
PHI = 1.618033988749895
K5 = 5
K11 = 11
PRIME_131 = 131


def srl_distance(d: int) -> int:
    """
    Compute SRL distance: t = sqrt(d)

    Args:
        d: Distance value (must be >= 0)

    Returns:
        SRL time t where t^2 = d

    Performance: O(1) via math.isqrt

    Mathematical Proof:
    Given t = d/t (self-referential definition)
    Multiply both sides by t: t^2 = d
    Take square root: t = sqrt(d)
    """
    if d <= 0:
        return 0
    if d == 1:
        return 1
    return int(math.isqrt(d))


def bounded_sqrt(d: int, min_val: int = 1, max_val: int = 10000) -> int:
    """
    Compute bounded SRL distance with min/max clamps.

    Args:
        d: Distance value
        min_val: Minimum result (default: 1)
        max_val: Maximum result (default: 10000)

    Returns:
        SRL time t clamped to [min_val, max_val]
    """
    t = int(math.isqrt(d)) if d > 0 else 0
    return max(min_val, min(t, max_val))


def srl_pathfind(from_hex: str, to_hex: str, max_depth: int = 100) -> List[str]:
    """
    Find path between hex IDs using SRL formula.

    Note: Standalone version returns simple direct path.
    Full pathfinding requires relationship graph.

    Args:
        from_hex: Starting hex ID
        to_hex: Target hex ID
        max_depth: Maximum path length

    Returns:
        List of hex IDs in path
    """
    if from_hex == to_hex:
        return [from_hex]
    return [from_hex, to_hex]


def srl_div_zero_path(hex_id: str) -> int:
    """
    Handle division-by-zero case via SRL formula.

    Args:
        hex_id: Hex ID to analyze

    Returns:
        SRL distance (0 if ABSORBED, 1 if DIRECT, sqrt(d) otherwise)
    """
    area = int(hex_id[:2], 16) if len(hex_id) >= 2 and hex_id[:2].isalnum() else 0

    if area == 0:
        return 0

    return srl_distance(area)


def srl_phi_depth(depth: int) -> float:
    """
    Compute phi-scaled depth for SRL operations.

    Args:
        depth: Tree depth level

    Returns:
        Phi-scaled depth (depth / phi)
    """
    return depth / PHI


def srl_k5_boundary(distance: int) -> int:
    """
    Apply K5 boundary stabilization to SRL distance.

    Args:
        distance: Raw SRL distance

    Returns:
        K5-bounded distance
    """
    if distance <= K5:
        return distance
    return distance % K5


def srl_morton_encode(x: int, y: int, z: int) -> int:
    """
    Encode 3D coordinates to Morton Z-order code.

    Args:
        x, y, z: 3D coordinates

    Returns:
        Morton code (interleaved bits)
    """
    def part_by_3(n):
        """Expand bits for 3D Morton encoding."""
        n &= 0x1FFFFF
        n = (n | (n << 32)) & 0x1F00000000FFFF
        n = (n | (n << 16)) & 0x1F0000FF0000FF
        n = (n | (n << 8))  & 0x100F00F00F00F00F
        n = (n | (n << 4))  & 0x10C30C30C30C30C3
        n = (n | (n << 2))  & 0x1249249249249249
        return n
    return part_by_3(x) | (part_by_3(y) << 1) | (part_by_3(z) << 2)
