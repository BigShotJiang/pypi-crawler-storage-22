"""
Database Module - SQLite Adapter for Cubesquare
Standalone version with pure Python implementation.
"""

from .abstraction import (
    DatabaseBackend,
    DatabaseError,
    ConnectionError,
    QueryError,
    AbstractDatabaseAdapter,
    DatabaseAbstractionLayer,
    DatabaseTransaction,
)

from .adapter import (
    SQLiteAdapter,
    create_sqlite_adapter,
)

__all__ = [
    # Enums and Exceptions
    'DatabaseBackend',
    'DatabaseError',
    'ConnectionError',
    'QueryError',

    # Abstract classes
    'AbstractDatabaseAdapter',
    'DatabaseAbstractionLayer',
    'DatabaseTransaction',

    # SQLite implementation
    'SQLiteAdapter',
    'create_sqlite_adapter',
]
