"""I-Logic Module - Algebraic State Composition

5-state algebra for agent routing with O(1) multiplication.

States:
    DIRECT (1)       - Pass through unchanged
    INVERSE (-1)     - Reflect/negate
    SPIRAL (+i)      - Rotate 90 degrees
    ANTI_SPIRAL (-i) - Counter-rotate 90 degrees
    ABSORBED (0)     - Terminate/consume

Algebraic Properties:
    - Closure: Product of any two states is a state
    - Associativity: (a * b) * c = a * (b * c)
    - Identity: DIRECT (1) is the identity
    - Inverses: All non-zero states have inverses
    - Absorbing: Any state * ABSORBED = ABSORBED
"""

from .states import ILogicState
from .algebra import multiply, compose, detect_cycle, get_inverse
from .predict import predict_route, find_resolver

__all__ = [
    "ILogicState",
    "multiply",
    "compose",
    "detect_cycle",
    "get_inverse",
    "predict_route",
    "find_resolver",
]
