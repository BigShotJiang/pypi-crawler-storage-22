"""Cubesquare CST Layer System

9 layers for navigating semantic memory:

L1 GEOMETRIC      - Navigate by file and folder hierarchy
L2 SEMANTIC       - Query by meaning and concept
L3 SPATIAL        - Find nearby and related content
L4 FUNCTIONAL     - Filter by abstraction level
L5 PROBABILISTIC  - Match by usage patterns
L6 EMOTIONAL      - Map by frequency and sentiment
L7 FREQUENCY      - Attention and energy mapping
L8 ELECTROMAGNETIC - Force dynamics and polarity
L9 MEMBRANE       - Information flow and transmission
"""

from .base import Layer, LayerID, Token
from .geometric import L1_Geometric
from .semantic import L2_Semantic
from .spatial import L3_Spatial
from .functional import L4_Functional
from .probabilistic import L5_Probabilistic
from .emotional import L6_Emotional
from .frequency import L7_Frequency
from .electromagnetic import L8_Electromagnetic
from .membrane import L9_Membrane

__all__ = [
    # Base
    "Layer",
    "LayerID",
    "Token",
    # Layers
    "L1_Geometric",
    "L2_Semantic",
    "L3_Spatial",
    "L4_Functional",
    "L5_Probabilistic",
    "L6_Emotional",
    "L7_Frequency",
    "L8_Electromagnetic",
    "L9_Membrane",
]

# Layer registry for dynamic access
LAYERS = {
    1: L1_Geometric,
    2: L2_Semantic,
    3: L3_Spatial,
    4: L4_Functional,
    5: L5_Probabilistic,
    6: L6_Emotional,
    7: L7_Frequency,
    8: L8_Electromagnetic,
    9: L9_Membrane,
}

LAYER_NAMES = {
    1: "GEOMETRIC",
    2: "SEMANTIC",
    3: "SPATIAL",
    4: "FUNCTIONAL",
    5: "PROBABILISTIC",
    6: "EMOTIONAL",
    7: "FREQUENCY",
    8: "ELECTROMAGNETIC",
    9: "MEMBRANE",
}


def get_layer_class(layer_id: int):
    """Get layer class by ID (1-9)."""
    return LAYERS.get(layer_id)


def get_layer_name(layer_id: int) -> str:
    """Get layer name by ID."""
    return LAYER_NAMES.get(layer_id, f"L{layer_id}")
