"""Verified Primitives - Mathematical Guarantees

Four O(1) primitives that form the foundation of the system:

| Primitive | Operation | Bound | Status |
|-----------|-----------|-------|--------|
| Morton    | 3D -> Z-order | O(1), 21 ops | Verified |
| Basin     | Token -> cluster | O(1), 8 ops | Verified |
| SRL       | Distance -> path | O(1), <=25 iter | Verified |
| I-Logic   | State composition | O(1) * N | Verified |

Key distinction: Cost determined at algorithm design time, not query time.
"""

from .morton import encode, decode, distance
from .basin import compute, layer_from_basin
from .srl import sqrt, validate
from .i_logic import multiply, compose, detect_cycle

__all__ = [
    # Morton
    "encode", "decode", "distance",
    # Basin
    "compute", "layer_from_basin",
    # SRL
    "sqrt", "validate",
    # I-Logic
    "multiply", "compose", "detect_cycle",
]
