"""Basin Primitive - O(1) Fernandez Clustering

Verified: 131 basins, 0.82 uniformity, 8 operations.
"""
from .._core import compute_basin, classify_layer, PRIME_131


def compute(x: int, y: int, z: int) -> int:
    """O(1) basin computation. 8 operations."""
    return compute_basin(x, y, z)


def layer_from_basin(basin: int) -> int:
    """Get layer (1-9) from basin (0-130)."""
    # Basin ranges to layers
    if basin < 15:
        return 1  # GEOMETRIC
    elif basin < 30:
        return 2  # SEMANTIC
    elif basin < 44:
        return 3  # SPATIAL
    elif basin < 59:
        return 4  # FUNCTIONAL
    elif basin < 73:
        return 5  # PROBABILISTIC
    elif basin < 88:
        return 6  # EMOTIONAL
    elif basin < 102:
        return 7  # FREQUENCY
    elif basin < 117:
        return 8  # ELECTROMAGNETIC
    else:
        return 9  # MEMBRANE


def basin_count() -> int:
    """Number of basins (the prime 131)."""
    return PRIME_131


def basin_name(basin: int) -> str:
    """Get descriptive name for basin."""
    layer = layer_from_basin(basin)
    layer_names = {
        1: "GEOMETRIC",
        2: "SEMANTIC",
        3: "SPATIAL",
        4: "FUNCTIONAL",
        5: "PROBABILISTIC",
        6: "EMOTIONAL",
        7: "FREQUENCY",
        8: "ELECTROMAGNETIC",
        9: "MEMBRANE",
    }
    return f"L{layer}_{layer_names[layer]}_{basin}"
