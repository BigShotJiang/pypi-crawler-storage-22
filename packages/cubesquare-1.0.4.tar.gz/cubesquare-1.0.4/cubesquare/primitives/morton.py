"""Morton Primitive - O(1) Z-order Encoding

Verified: 100M entries, 100% correct, 21 operations.
"""
from .._core import morton_encode, morton_decode, morton_spatial_distance


def encode(x: int, y: int, z: int = 0) -> int:
    """O(1) Morton encode. 21 bit operations."""
    return morton_encode(x, y, z)


def decode(morton: int) -> tuple:
    """O(1) Morton decode."""
    return morton_decode(morton)


def distance(m1: int, m2: int) -> float:
    """Euclidean distance between Morton codes."""
    return morton_spatial_distance(m1, m2)
