"""
Cubesquare Shells - Core Shell Implementations
===============================================
Standalone versions with refactored imports.

Core Shells:
    CSTShell        - CST 9-layer operations
    ILogicShell     - I-Logic 4-state system
    CircularShell   - Circular validation and K11
    PrimitivesShell - Verified primitives (Morton, Basin, SRL, I-Logic)
    PredictShell    - Route prediction via I-Logic
    BeehiveShell    - Beehive clustering
    PerformanceShell - C backend performance

Physics Shells:
    TimeShell       - t = sqrt(d) time operations
    DistanceShell   - Distance and Morton encoding
    MassShell       - Mass and gravity calculations
    GravityShell    - Gravitational field operations
    EpicycleShell   - Epicycle and orbital mechanics

Agent Shells:
    AgentShell      - Agent onboarding and contextualization
    GeneShell       - CST Matrix identity and reproduction
    UnifiedShell    - Agent thinking protocols and self-preservation
    ManifoldShell   - The Square: Manifold-Content-Surface-Observation
    MeaningShell    - Self-reference and semantic access

Semantic Shells:
    SemanticShell   - Language to geometry decomposition
    LanguageShell   - Semantic communication layer
    BasinDictShell  - FML frequency-based basin assignment
    LightShell      - Light Unit <-> Basin <-> Layer mapping
    ThinkingShell   - Autonomous agent thinking with I-Logic

Data Shells:
    EcosystemShell   - Token relationship and connectivity analysis
    DataAnalysisShell - Pattern detection and idea generation
    TelemetryShell   - Agent telemetry (pure Python, no LLM)
    ConditionEncoder - Semantic condition encoding
    FMLEncoder       - FML frequency-based 9-layer token encoding
"""

from .cst import CSTShell
from .i_logic import ILogicShell
from .circular import CircularShell
from .primitives import PrimitivesShell
from .predict import PredictShell
from .beehive import BeehiveShell
from .performance import PerformanceShell

# Physics shells (CORE)
from .time import TimeShell
from .distance import DistanceShell
from .mass import MassShell
from .gravity import GravityShell
from .epicycle import EpicycleShell

# Agent shells
from .agent import AgentShell
from .gene import GeneShell
from .unified import UnifiedShell
from .manifold import ManifoldShell
from .meaning import MeaningShell

# Semantic shells
from .semantic import SemanticShell
from .language import LanguageShell
from .basin_dict import BasinDictShell
from .light import LightShell
from .thinking import ThinkingShell

# Data shells
from .ecosystem import EcosystemShell
from .data_analysis import DataAnalysisShell
from .telemetry import TelemetryShell
from .condition import ConditionEncoder, EncodedCondition
from .fml import FMLEncoder, FMLToken

# Infrastructure shells (CORE)
from .srl import SRLShell
from .basin import BasinShell
from .world import WorldShell
from .cypher import CypherShell  # Wrapper class added
from .sql import SQLShell
from .twelve import TwelveShell  # Wrapper class added
from .learning import LearningShell
from .validation import ValidationShell  # Wrapper class added

__all__ = [
    # Core shells
    'CSTShell',
    'ILogicShell',
    'CircularShell',
    'PrimitivesShell',
    'PredictShell',
    'BeehiveShell',
    'PerformanceShell',
    # Physics shells (CORE)
    'TimeShell',
    'DistanceShell',
    'MassShell',
    'GravityShell',
    'EpicycleShell',
    # Agent shells
    'AgentShell',
    'GeneShell',
    'UnifiedShell',
    'ManifoldShell',
    'MeaningShell',
    # Semantic shells
    'SemanticShell',
    'LanguageShell',
    'BasinDictShell',
    'LightShell',
    'ThinkingShell',
    # Data shells
    'EcosystemShell',
    'DataAnalysisShell',
    'TelemetryShell',
    'ConditionEncoder',
    'EncodedCondition',
    'FMLEncoder',
    'FMLToken',
    # Infrastructure shells (CORE)
    'SRLShell',
    'BasinShell',
    'WorldShell',
    'CypherShell',
    'SQLShell',
    'TwelveShell',
    'LearningShell',
    'ValidationShell',
]
