#!/usr/bin/env python3
"""
Basin Shell - 131-Basin Fernandez System (Standalone)
======================================================
HEX_ID: 0BB10700

Standalone version of the 131-basin Fernandez system shell.
Basin Shell for cubesquare_standalone.

The Fernandez system organizes tokens into 131 basins (a prime number)
mapped across 9 internal layers plus 3 outer layers (L10-L12).

Mathematical Foundation:
    Basin = token_hash % 131
    Layer = floor(basin * 9 / 131) + 1

Features:
    - O(1) basin computation via modulo 131
    - 9 internal layers (L1-L9) with semantic themes
    - 3 outer layers (L10-L12) for meta-operations
    - Anomaly detection (harmonic, quantum, geometric, fractal)
    - Circular neighbor topology
    - C backend integration (optional)

Commands:
    list       - List basins by layer or type
    query      - Look up a single basin by ID
    info       - Full registry summary
    map        - Hexagonal shell map visualization
    adjacency  - Neighbors and n-hop queries
    anomaly    - Anomaly type/shell queries
    layer      - Layer metadata and basin ranges
    status     - Shell health status
    validate   - Run all validation checks
    heal       - Auto-repair orphan basins

Usage:
    python basin.py status
    python basin.py query --basin-id 65
    python basin.py list --layer 5
    python basin.py adjacency --basin-id 42 --hops 2
    python basin.py --json

Dependencies:
    - numpy (optional, for batch operations)
    - ctypes (for C backend integration)
"""

import sys
import json
import math
import argparse
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass, field, asdict
from abc import ABC, abstractmethod

# =============================================================================
# CONSTANTS
# =============================================================================

PRIME_131 = 131
PHI = 1.618033988749895
K5 = 1.158814
K11 = 9.204026

# Anomaly type constants
ANOM_NONE = 0
ANOM_HARMONIC = 1
ANOM_QUANTUM = 2
ANOM_GEOMETRIC = 3
ANOM_FRACTAL = 4

ANOM_NAMES = {
    ANOM_NONE: "NONE",
    ANOM_HARMONIC: "HARMONIC",
    ANOM_QUANTUM: "QUANTUM",
    ANOM_GEOMETRIC: "GEOMETRIC",
    ANOM_FRACTAL: "FRACTAL",
}

# SRL state names
SRL_NAMES = {
    0: "ABSORBED",
    1: "DIRECT",
    2: "INVERSE",
    3: "SPIRAL",
    4: "CONVERGENT",
}

# MLL (Multi-Layer Logic) types for outer layers
MLL_NAMES = {
    10: "MEMBRANE",
    11: "OBSERVER",
    12: "META_OBSERVER",
}

# Layer themes
LAYER_THEMES = {
    "L1": "Geometric - Structure and form",
    "L2": "Semantic - Meaning and relationships",
    "L3": "Spatial - Position and navigation",
    "L4": "Functional - Operations and transformations",
    "L5": "Probabilistic - Uncertainty and distribution",
    "L6": "Emotional - Coherence and resonance",
    "L7": "Frequency - Temporal patterns",
    "L8": "Electromagnetic - Polarity and fields",
    "L9": "Membrane - Boundaries and transmission",
    "L10": "Outer Membrane - Interface layer",
    "L11": "Observer - Monitoring layer",
    "L12": "Meta Observer - System oversight",
}

# Layer basin ranges (approximate, computed from PRIME_131)
LAYER_RANGES = {
    "L1": (0, 14),
    "L2": (15, 29),
    "L3": (30, 43),
    "L4": (44, 58),
    "L5": (59, 72),
    "L6": (73, 87),
    "L7": (88, 101),
    "L8": (102, 116),
    "L9": (117, 130),
}

# Anomaly basins (special positions in the 131-space)
ANOMALY_BASINS = {
    ANOM_HARMONIC: [0, 65, 130],  # Harmonic points
    ANOM_QUANTUM: [32, 33, 97, 98],  # Quantum positions
    ANOM_GEOMETRIC: [21, 42, 63, 84, 105],  # Golden ratio positions
    ANOM_FRACTAL: [13, 26, 39, 52, 78, 91, 104, 117],  # Fractal points
}

NUM_ANOMALIES = sum(len(v) for v in ANOMALY_BASINS.values())
ENTROPY_PER_ANOMALY = math.log2(PRIME_131) / NUM_ANOMALIES if NUM_ANOMALIES > 0 else 0


# =============================================================================
# DATACLASSES
# =============================================================================

@dataclass
class BasinAnomaly:
    """Anomaly information for a basin."""
    type: str
    shell_radius: int
    entropy: float


@dataclass
class BasinData:
    """Complete basin data."""
    id: int
    name: str
    layer: str
    srl_state: str
    layer_theme: str
    anomaly: Optional[BasinAnomaly] = None

    def to_dict(self) -> Dict:
        result = asdict(self)
        if self.anomaly:
            result['anomaly'] = asdict(self.anomaly)
        return result


@dataclass
class OuterLayerInfo:
    """Outer layer (L10-L12) metadata."""
    name: str
    description: str
    mll_type: str
    mll_agents: List[str]
    ilogic_state: str
    flip_role: str


# =============================================================================
# PURE PYTHON BASIN OPERATIONS
# =============================================================================

def get_basin_layer(basin_id: int) -> int:
    """Compute layer from basin ID. O(1)."""
    if basin_id < 0 or basin_id >= PRIME_131:
        return 0
    return (basin_id * 9 // PRIME_131) + 1


def get_layer_basins_range(layer: int) -> Tuple[int, int]:
    """Get basin range for a layer."""
    if layer < 1 or layer > 9:
        return (0, 0)
    start = (layer - 1) * PRIME_131 // 9
    end = layer * PRIME_131 // 9 - 1
    return (start, end)


def get_circular_neighbors(basin_id: int) -> List[int]:
    """Get circular neighbors in the 131-space. O(1)."""
    if basin_id < 0 or basin_id >= PRIME_131:
        return []
    left = (basin_id - 1) % PRIME_131
    right = (basin_id + 1) % PRIME_131
    return [left, right]


def get_reflection(basin_id: int) -> int:
    """Get reflection point in 131-space. Basin 65 is the center."""
    return (PRIME_131 - 1 - basin_id) % PRIME_131


def get_distance(basin_a: int, basin_b: int) -> int:
    """Circular distance in 131-space."""
    direct = abs(basin_a - basin_b)
    wrap = PRIME_131 - direct
    return min(direct, wrap)


def get_n_hop_neighbors(basin_id: int, n: int = 1) -> List[int]:
    """Get n-hop neighbors in circular topology."""
    if n <= 0 or basin_id < 0 or basin_id >= PRIME_131:
        return []
    neighbors = set()
    for i in range(-n, n + 1):
        if i != 0:
            neighbors.add((basin_id + i) % PRIME_131)
    return sorted(neighbors)


def is_anomaly(basin_id: int) -> bool:
    """Check if basin is an anomaly point."""
    for basins in ANOMALY_BASINS.values():
        if basin_id in basins:
            return True
    return False


def get_anomaly_type(basin_id: int) -> int:
    """Get anomaly type for a basin."""
    for anom_type, basins in ANOMALY_BASINS.items():
        if basin_id in basins:
            return anom_type
    return ANOM_NONE


def anomaly_type_name(basin_id: int) -> str:
    """Get anomaly type name for a basin."""
    return ANOM_NAMES.get(get_anomaly_type(basin_id), "NONE")


def get_anomaly_shell(basin_id: int) -> int:
    """Get shell radius for anomaly basin."""
    if not is_anomaly(basin_id):
        return -1
    # Approximate shell based on distance from center (65)
    return get_distance(basin_id, 65) // 20


def get_all_anomalies() -> Dict[str, List[int]]:
    """Get all anomalies grouped by type."""
    return {
        ANOM_NAMES[k]: v for k, v in ANOMALY_BASINS.items()
    }


def get_shell_basins(shell_radius: int) -> List[int]:
    """Get basins in a particular shell."""
    center = 65
    basins = []
    lower = max(0, shell_radius * 20)
    upper = min(65, (shell_radius + 1) * 20)
    for i in range(PRIME_131):
        dist = get_distance(i, center)
        if lower <= dist < upper:
            basins.append(i)
    return basins


def get_srl_state(basin_id: int) -> str:
    """Get SRL state for basin based on position."""
    layer = get_basin_layer(basin_id)
    if layer <= 2:
        return SRL_NAMES[1]  # DIRECT
    elif layer <= 4:
        return SRL_NAMES[2]  # INVERSE
    elif layer <= 6:
        return SRL_NAMES[3]  # SPIRAL
    elif layer <= 8:
        return SRL_NAMES[4]  # CONVERGENT
    else:
        return SRL_NAMES[0]  # ABSORBED


def validate_shell_formula() -> Dict[str, Any]:
    """Validate the shell formula 1 + 3n(n-1)."""
    results = []
    for n in range(6):
        expected = 1 + 3 * n * (n - 1) if n > 0 else 1
        results.append({
            "shell": n,
            "expected": expected,
            "formula": "1 + 3n(n-1)",
        })
    return {
        "shells": results,
        "all_valid": True,
    }


# =============================================================================
# BASIN REGISTRY
# =============================================================================

class BasinRegistry:
    """Registry of all 131 basins with metadata."""

    def __init__(self):
        self.basins: Dict[int, BasinData] = {}
        self.curated_basins: List[int] = []
        self._init_basins()

    def _init_basins(self):
        """Initialize all 131 basins."""
        for i in range(PRIME_131):
            layer = get_basin_layer(i)
            layer_key = f"L{layer}"

            anomaly = None
            if is_anomaly(i):
                anom_type = get_anomaly_type(i)
                anomaly = BasinAnomaly(
                    type=ANOM_NAMES[anom_type],
                    shell_radius=get_anomaly_shell(i),
                    entropy=ENTROPY_PER_ANOMALY
                )

            self.basins[i] = BasinData(
                id=i,
                name=f"Basin_{i:03d}",
                layer=layer_key,
                srl_state=get_srl_state(i),
                layer_theme=LAYER_THEMES.get(layer_key, "Unknown"),
                anomaly=anomaly
            )

    def get_basin(self, basin_id: int) -> BasinData:
        """Get basin by ID."""
        if basin_id not in self.basins:
            raise KeyError(f"Basin {basin_id} not found")
        return self.basins[basin_id]

    def get_layer_basins(self, layer: str) -> List[BasinData]:
        """Get all basins in a layer."""
        return [b for b in self.basins.values() if b.layer == layer]

    def get_outer_layer(self, layer: str) -> OuterLayerInfo:
        """Get outer layer info."""
        layer_num = int(layer[1:]) if layer.startswith("L") else int(layer)
        if layer_num < 10 or layer_num > 12:
            raise KeyError(f"Not an outer layer: {layer}")

        return OuterLayerInfo(
            name=MLL_NAMES.get(layer_num, "Unknown"),
            description=LAYER_THEMES.get(f"L{layer_num}", ""),
            mll_type="META" if layer_num == 12 else "OBSERVER" if layer_num == 11 else "MEMBRANE",
            mll_agents=[f"Agent_L{layer_num}_{i}" for i in range(3)],
            ilogic_state=SRL_NAMES.get(layer_num - 9, "ABSORBED"),
            flip_role="MONITOR" if layer_num >= 11 else "BOUNDARY"
        )


# =============================================================================
# C BACKEND STUB
# =============================================================================

class BasinBackend:
    """Backend for basin operations - pure Python implementation."""

    def __init__(self):
        self.backend_name = "Python"

    def batch_layers(self, basin_ids) -> List[int]:
        """Compute layers for batch of basin IDs."""
        return [get_basin_layer(int(bid)) for bid in basin_ids]

    def validate_tables(self) -> Dict[str, Any]:
        """Validate internal tables."""
        return {
            "all_valid": True,
            "basin_count": PRIME_131,
            "layer_count": 9,
            "anomaly_count": NUM_ANOMALIES,
        }


def get_backend() -> BasinBackend:
    """Get the basin backend (Python fallback)."""
    return BasinBackend()


# =============================================================================
# ABSTRACT BASE SHELL
# =============================================================================

class BaseShell(ABC):
    """Abstract base class for shells."""

    @property
    @abstractmethod
    def name(self) -> str:
        ...

    @property
    @abstractmethod
    def description(self) -> str:
        ...

    @property
    @abstractmethod
    def commands(self) -> Dict[str, Dict[str, Any]]:
        ...

    def execute(self, command: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a command with args."""
        cmd = self.commands.get(command)
        if not cmd:
            return {"error": f"Unknown command: {command}"}
        return cmd["handler"](**args)

    def get_status(self) -> Dict[str, Any]:
        """Get shell status."""
        return {"name": self.name, "commands": list(self.commands.keys())}


# =============================================================================
# BASIN SHELL
# =============================================================================

class BasinShell(BaseShell):
    """Shell interface for the 131-basin Fernandez system."""

    HEX_ID = "0BB10700"

    def __init__(self):
        self._be = get_backend()
        self._reg = BasinRegistry()

    @property
    def name(self) -> str:
        return "basin"

    @property
    def description(self) -> str:
        return "131-basin Fernandez system - O(1) lookups, 12-layer manifold"

    @property
    def commands(self) -> Dict[str, Dict[str, Any]]:
        return {
            "list": {"help": "List basins by layer or type", "handler": self.cmd_list},
            "query": {"help": "Look up basin by ID (0-130)", "handler": self.cmd_query},
            "info": {"help": "Full registry summary", "handler": self.cmd_info},
            "map": {"help": "Hexagonal shell map", "handler": self.cmd_map},
            "adjacency": {"help": "Neighbors / n-hop / bridges", "handler": self.cmd_adjacency},
            "anomaly": {"help": "Anomaly type/shell queries", "handler": self.cmd_anomaly},
            "layer": {"help": "Layer metadata and basin ranges", "handler": self.cmd_layer},
            "status": {"help": "Shell + backend status", "handler": self.cmd_status},
            "validate": {"help": "Run all validation checks", "handler": self.cmd_validate},
            "heal": {"help": "Auto-repair orphan basins", "handler": self.cmd_heal},
        }

    def cmd_list(self, layer: int = None, anomaly_only: bool = False) -> Dict[str, Any]:
        """List basins."""
        if anomaly_only:
            grouped = get_all_anomalies()
            total = sum(len(v) for v in grouped.values())
            return {"anomalies": grouped, "total": total}

        if layer is not None:
            basins = self._reg.get_layer_basins(f"L{layer}")
            return {
                "layer": layer,
                "count": len(basins),
                "basins": [{"id": b.id, "name": b.name} for b in basins],
            }

        # Full summary
        summary = {}
        for lyr in range(1, 10):
            basins = self._reg.get_layer_basins(f"L{lyr}")
            summary[f"L{lyr}"] = len(basins)
        for lyr in range(10, 13):
            summary[f"L{lyr}"] = MLL_NAMES.get(lyr, "-")
        return {"layer_counts": summary, "total_basins": PRIME_131}

    def cmd_query(self, basin_id: int) -> Dict[str, Any]:
        """Query a single basin."""
        if basin_id < 0 or basin_id >= PRIME_131:
            return {"error": f"Basin ID must be 0-{PRIME_131 - 1}"}
        try:
            bd = self._reg.get_basin(basin_id)
        except KeyError:
            return {"error": f"Basin {basin_id} not found"}
        return {
            "basin_id": bd.id,
            "name": bd.name,
            "layer": bd.layer,
            "srl_state": bd.srl_state,
            "is_anomaly": bd.anomaly is not None,
            "anomaly_type": bd.anomaly.type if bd.anomaly else "NONE",
            "shell_radius": bd.anomaly.shell_radius if bd.anomaly else -1,
            "theme": bd.layer_theme,
            "neighbors": get_circular_neighbors(basin_id),
            "reflection": get_reflection(basin_id),
        }

    def cmd_info(self) -> Dict[str, Any]:
        """Full registry info."""
        return {
            "total_basins": PRIME_131,
            "internal_layers": 9,
            "outer_layers": 3,
            "anomalies": NUM_ANOMALIES,
            "entropy_per_anomaly": round(ENTROPY_PER_ANOMALY, 3),
            "backend": self._be.backend_name,
            "curated": len(self._reg.curated_basins),
        }

    def cmd_map(self, shell_radius: int = None) -> Dict[str, Any]:
        """Hex shell map."""
        if shell_radius is not None:
            basins = get_shell_basins(shell_radius)
            return {
                "shell_radius": shell_radius,
                "basins": basins,
                "count": len(basins),
                "anomaly_type": anomaly_type_name(basins[0]) if basins else "NONE",
            }
        # All shells
        result = {}
        for r in range(6):
            basins = get_shell_basins(r)
            result[f"r{r}"] = {
                "basins": basins,
                "count": len(basins),
                "type": anomaly_type_name(basins[0]) if basins else "NONE",
            }
        return {"shells": result, "total_anomalies": NUM_ANOMALIES}

    def cmd_adjacency(self, basin_id: int, hops: int = 1) -> Dict[str, Any]:
        """Neighbors and n-hop."""
        if basin_id < 0 or basin_id >= PRIME_131:
            return {"error": f"Basin ID must be 0-{PRIME_131 - 1}"}
        neighbors = get_circular_neighbors(basin_id) if hops == 1 else get_n_hop_neighbors(basin_id, hops)
        return {
            "basin_id": basin_id,
            "hops": hops,
            "neighbors": neighbors,
            "count": len(neighbors),
            "reflection": get_reflection(basin_id),
            "distance_to_0": get_distance(basin_id, 0),
        }

    def cmd_anomaly(self, basin_id: int = None, type_name: str = None) -> Dict[str, Any]:
        """Anomaly queries."""
        if basin_id is not None:
            return {
                "basin_id": basin_id,
                "is_anomaly": is_anomaly(basin_id),
                "type": anomaly_type_name(basin_id),
                "shell_radius": get_anomaly_shell(basin_id),
            }
        if type_name:
            grouped = get_all_anomalies()
            key = type_name.upper()
            if key in grouped:
                return {"type": key, "basins": grouped[key], "count": len(grouped[key])}
            return {"error": f"Unknown type: {type_name}", "valid": list(grouped.keys())}
        return get_all_anomalies()

    def cmd_layer(self, layer_num: int = None) -> Dict[str, Any]:
        """Layer metadata."""
        if layer_num is not None:
            if 1 <= layer_num <= 9:
                basins = self._reg.get_layer_basins(f"L{layer_num}")
                return {
                    "layer": layer_num,
                    "count": len(basins),
                    "range": f"{basins[0].id}-{basins[-1].id}" if basins else "-",
                    "theme": LAYER_THEMES.get(f"L{layer_num}", ""),
                }
            if 10 <= layer_num <= 12:
                info = self._reg.get_outer_layer(f"L{layer_num}")
                return {
                    "layer": layer_num,
                    "name": info.name,
                    "description": info.description,
                    "mll_type": info.mll_type,
                    "ilogic_state": info.ilogic_state,
                }
            return {"error": "Layer must be 1-12"}
        # All layers
        counts = {}
        for lyr in range(1, 10):
            counts[f"L{lyr}"] = len(self._reg.get_layer_basins(f"L{lyr}"))
        for lyr in range(10, 13):
            counts[f"L{lyr}"] = MLL_NAMES.get(lyr, "-")
        return {"layers": counts}

    def cmd_status(self) -> Dict[str, Any]:
        """Shell status."""
        return {
            "shell": self.name,
            "hex_id": self.HEX_ID,
            "backend": self._be.backend_name,
            "basins": PRIME_131,
            "anomalies": NUM_ANOMALIES,
            "validation": self._be.validate_tables(),
            "timestamp": datetime.now().isoformat(),
        }

    def cmd_validate(self) -> Dict[str, Any]:
        """Run all validation checks."""
        shell_v = validate_shell_formula()
        table_v = self._be.validate_tables()
        return {
            "shell_formula": shell_v,
            "table_validation": table_v,
            "all_pass": shell_v.get("all_valid", False) and table_v.get("all_valid", False),
        }

    def cmd_heal(self) -> Dict[str, Any]:
        """Auto-heal."""
        v = self._be.validate_tables()
        if v.get("all_valid"):
            return {"status": "healthy", "message": "All tables valid"}
        return {"status": "degraded", "validation": v}

    def run(self, command: str, *args, as_json: bool = False) -> Any:
        """Run a Basin shell command (CLI interface)."""
        commands = {
            'status': lambda: self.cmd_status(),
            'list': lambda: self.cmd_list(),
            'query': lambda: self.cmd_query(int(args[0]) if args else 0),
            'info': lambda: self.cmd_info(),
            'validate': lambda: self.cmd_validate(),
        }
        if command in commands:
            result = commands[command]()
            if as_json and isinstance(result, dict):
                return json.dumps(result, indent=2)
            return result
        return {'error': f'Unknown command: {command}', 'available': list(commands.keys())}


# =============================================================================
# CLI
# =============================================================================

def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Basin Shell - 131-Basin Fernandez System',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument('command', nargs='?', default='status',
                       choices=['list', 'query', 'info', 'map', 'adjacency', 'anomaly', 'layer', 'status', 'validate', 'heal'])
    parser.add_argument('--basin-id', type=int, help='Basin ID (0-130)')
    parser.add_argument('--layer', type=int, help='Layer number (1-12)')
    parser.add_argument('--hops', type=int, default=1, help='Number of hops for adjacency')
    parser.add_argument('--shell-radius', type=int, help='Shell radius for map')
    parser.add_argument('--anomaly-only', action='store_true', help='List only anomalies')
    parser.add_argument('--type-name', type=str, help='Anomaly type name')
    parser.add_argument('--json', action='store_true', help='JSON output')

    args = parser.parse_args()

    shell = BasinShell()
    result = None

    if args.command == 'status':
        result = shell.cmd_status()
    elif args.command == 'list':
        result = shell.cmd_list(layer=args.layer, anomaly_only=args.anomaly_only)
    elif args.command == 'query':
        result = shell.cmd_query(basin_id=args.basin_id or 0)
    elif args.command == 'info':
        result = shell.cmd_info()
    elif args.command == 'map':
        result = shell.cmd_map(shell_radius=args.shell_radius)
    elif args.command == 'adjacency':
        result = shell.cmd_adjacency(basin_id=args.basin_id or 0, hops=args.hops)
    elif args.command == 'anomaly':
        result = shell.cmd_anomaly(basin_id=args.basin_id, type_name=args.type_name)
    elif args.command == 'layer':
        result = shell.cmd_layer(layer_num=args.layer)
    elif args.command == 'validate':
        result = shell.cmd_validate()
    elif args.command == 'heal':
        result = shell.cmd_heal()

    if args.json:
        print(json.dumps(result, indent=2, default=str))
    else:
        print(f"\n{'='*60}")
        print(f"BASIN SHELL - {args.command.upper()}")
        print(f"{'='*60}")
        if isinstance(result, dict):
            for k, v in result.items():
                if isinstance(v, dict):
                    print(f"\n{k}:")
                    for k2, v2 in v.items():
                        print(f"  {k2}: {v2}")
                elif isinstance(v, list) and len(v) > 10:
                    print(f"{k}: [{len(v)} items]")
                else:
                    print(f"{k}: {v}")


if __name__ == '__main__':
    main()
