"""
FML Frequency Encoder Shell - Full 9-Layer Deterministic Token Generation
HEX_ID: 0BF1DD10

Standalone version for cubesquare.

Converts any text input into a deterministic 9-layer CST token.
Same input ALWAYS produces same token. This is the foundation of
learning without training: deterministic encoding + .cst persistence = lookup.

INPUTS:
    - Text string to encode
    - Optional membrane_id for session boundary

OUTPUTS:
    - FMLToken with all 9 layers:
        L1: Basin        - Fernandez attractor from frequency (0-130)
        L2: Semantic     - Relationship class (0-4)
        L3: Morton       - Position in 48^3 manifold from frequency components
        L4: K5xK11       - Intrinsic state product (5 x 23 = 115 states)
        L5: Energy       - Information entropy (0.0-1.0)
        L6: Emotion      - Behavioral physics (154 states from 3 axes)
        L7: Wavelength   - Direct frequency mapping (380-750nm)
        L8: Polarity     - DIRECT/INVERSE from grammatical structure
        L9: Membrane     - Session/context boundary identifier

L6 EMOTION PHYSICS (from groom strand analogy):
    - Commitment (stiffness): resistance to redirection (0-4)
    - Focus (attraction): directionality of attention (0-4)
    - Stability (inverse turbulence): predictability of propagation (0-4)
    3 axes x 5 levels = 125 base + 29 compound = 154 states

DETERMINISM GUARANTEE:
    All layers are computed from measurable text properties:
    - Zipf frequency ranks (from corpus vocabulary or hash)
    - Grammatical structure ratios
    - Information entropy
    - Article/noun specificity
    No randomness. No model inference. Same input -> same 9 layers.

Hex ID Format: BBMMSSEE
    BB = Basin (00-82)
    MM = Morton low 8 bits
    SS = L6 state (00-99)
    EE = Energy + polarity encoded
"""

import hashlib
import math
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Any

# Import from cubesquare core
from .._core.constants import PHI, K5, K11, PRIME_131, MATRIX_SIZE

# Import I-Logic
from ..i_logic.states import ILogicState


# ==============================================================================
# CONSTANTS
# ==============================================================================

# FML Wavelength bounds
LAMBDA_MIN = 380.0  # nm (violet)
LAMBDA_MAX = 750.0  # nm (red)
LAMBDA_RANGE = LAMBDA_MAX - LAMBDA_MIN

# Default vocabulary size
DEFAULT_VOCAB_SIZE = 10000

# L2 Semantic Classes
L2_GEOMETRIC = 0      # Spatial relationships ("near", "above")
L2_SEMANTIC = 1       # Definitions ("means", "is a")
L2_SPATIAL = 2        # Location ("at", "in")
L2_FUNCTIONAL = 3     # Operations ("does", "runs")
L2_PROBABILISTIC = 4  # Uncertainty ("might", "maybe")

L2_NAMES = ['GEOMETRIC', 'SEMANTIC', 'SPATIAL', 'FUNCTIONAL', 'PROBABILISTIC']

# L2 keyword triggers
L2_KEYWORDS = {
    L2_GEOMETRIC: {'near', 'above', 'below', 'beside', 'between', 'around', 'inside', 'outside', 'left', 'right'},
    L2_SEMANTIC: {'means', 'defines', 'represents', 'signifies', 'denotes', 'equals'},
    L2_SPATIAL: {'at', 'in', 'on', 'within', 'located', 'positioned', 'placed'},
    L2_FUNCTIONAL: {'does', 'runs', 'executes', 'performs', 'processes', 'handles', 'calls'},
    L2_PROBABILISTIC: {'might', 'maybe', 'perhaps', 'possibly', 'probably', 'could', 'should', 'would'},
}

# L6 Emotion: 3 axes x 5 levels = 125 base + 29 compound = 154 states
L6_AXIS_COMMITMENT = 0  # Stiffness: 0=open, 4=immovable
L6_AXIS_FOCUS = 1       # Attraction: 0=scattered, 4=laser-targeted
L6_AXIS_STABILITY = 2   # Inverse turbulence: 0=chaotic, 4=rigid

# Grammatical markers for L6 computation
DEFINITE_ARTICLES = {'the', 'this', 'that', 'these', 'those'}
INDEFINITE_ARTICLES = {'a', 'an', 'some', 'any', 'few', 'several'}
SPECIFIC_MARKERS = {'specifically', 'exactly', 'precisely', 'particular'}
GENERIC_MARKERS = {'something', 'anything', 'somewhere', 'somehow', 'whatever'}
DECLARATIVE_MARKERS = {'is', 'are', 'was', 'were', 'will', 'must', 'shall'}
INTERROGATIVE_MARKERS = {'?', 'might', 'maybe', 'perhaps', 'could', 'would', 'should'}

# L8 Polarity markers
NEGATION_MARKERS = {'not', "n't", 'no', 'never', 'none', 'neither', 'nor', 'without'}

# K5 and K11 for L4
K5_VAL = 5
K11_VAL = 23  # K11 range: -11 to +11


# ==============================================================================
# DATA STRUCTURES
# ==============================================================================

@dataclass
class FMLToken:
    """
    Complete 9-layer CST token from FML frequency encoding.

    Deterministic: same input text always produces same token.
    """
    # Input
    text: str

    # L1: Basin (Fernandez attractor)
    l1_basin: int = 0

    # L2: Semantic class
    l2_semantic: int = 0
    l2_semantic_name: str = ""

    # L3: Morton position in 48^3
    l3_x: int = 0
    l3_y: int = 0
    l3_z: int = 0
    l3_morton: int = 0

    # L4: K5xK11 product
    l4_k5: int = 0
    l4_k11: int = 0
    l4_state: str = ""

    # L5: Energy (information entropy)
    l5_energy: float = 0.0

    # L6: Emotion (154 states)
    l6_state: int = 0
    l6_commitment: int = 0  # 0-4
    l6_focus: int = 0       # 0-4
    l6_stability: int = 0   # 0-4

    # L7: Wavelength (nm)
    l7_wavelength: float = 0.0

    # L8: Polarity
    l8_polarity: str = "DIRECT"
    l8_ilogic: complex = field(default=ILogicState.DIRECT)

    # L9: Membrane (session boundary)
    l9_membrane: int = 0

    # Derived
    hex_id: str = ""

    def to_dict(self) -> Dict:
        return {
            'text': self.text,
            'hex_id': self.hex_id,
            'layers': {
                'L1_basin': self.l1_basin,
                'L2_semantic': {'class': self.l2_semantic, 'name': self.l2_semantic_name},
                'L3_morton': {'x': self.l3_x, 'y': self.l3_y, 'z': self.l3_z, 'morton': self.l3_morton},
                'L4_k5k11': {'k5': self.l4_k5, 'k11': self.l4_k11, 'state': self.l4_state},
                'L5_energy': round(self.l5_energy, 4),
                'L6_emotion': {
                    'state': self.l6_state,
                    'commitment': self.l6_commitment,
                    'focus': self.l6_focus,
                    'stability': self.l6_stability,
                },
                'L7_wavelength': round(self.l7_wavelength, 2),
                'L8_polarity': self.l8_polarity,
                'L9_membrane': self.l9_membrane,
            }
        }

    def to_compact(self) -> str:
        """Compact string representation for logging."""
        return (f"[{self.hex_id}] L1={self.l1_basin} L2={self.l2_semantic_name} "
                f"L3=({self.l3_x},{self.l3_y},{self.l3_z}) L4={self.l4_state} "
                f"L5={self.l5_energy:.2f} L6={self.l6_state} L7={self.l7_wavelength:.0f}nm "
                f"L8={self.l8_polarity} L9={self.l9_membrane}")


# ==============================================================================
# FML FREQUENCY ENCODER
# ==============================================================================

class FMLEncoder:
    """
    Encodes text into deterministic 9-layer CST tokens.

    Uses frequency decomposition for all layer computations:
    - Zipf ranks from corpus vocabulary or hash-based fallback
    - Grammatical structure ratios
    - Information entropy

    No randomness. Same input always produces same token.

    Usage:
        encoder = FMLEncoder()
        token = encoder.encode("the healer agent is stuck")
        print(token.hex_id)     # -> deterministic hex
        print(token.l1_basin)   # -> basin from average wavelength
        print(token.l8_polarity) # -> DIRECT or INVERSE
    """

    def __init__(self, vocab_size: int = DEFAULT_VOCAB_SIZE,
                 term_ranks: Dict[str, int] = None,
                 membrane_id: int = 0):
        """
        Initialize encoder.

        Args:
            vocab_size: Size of vocabulary for frequency normalization
            term_ranks: Optional dict mapping terms to frequency ranks
            membrane_id: L9 membrane identifier for this session
        """
        self.vocab_size = vocab_size
        self.term_ranks = term_ranks or {}
        self.membrane_id = membrane_id

    def _tokenize(self, text: str) -> List[str]:
        """Tokenize text into words."""
        return re.findall(r"[a-zA-Z]+(?:'[a-zA-Z]+)?|[?!.,;:]", text.lower())

    def _extract_terms(self, text: str) -> List[str]:
        """Extract meaningful terms (words only)."""
        return re.findall(r'[a-zA-Z]+', text.lower())

    def _get_term_rank(self, term: str) -> int:
        """Get Zipf rank for a term."""
        if term in self.term_ranks:
            return self.term_ranks[term]
        # Unknown term: hash to consistent pseudo-rank (treat as rare)
        hash_val = int(hashlib.md5(term.encode()).hexdigest()[:8], 16)
        return (hash_val % (self.vocab_size // 2)) + (self.vocab_size // 2)

    def _frequency_to_wavelength(self, rank: int) -> float:
        """Convert frequency rank to wavelength."""
        normalized_rank = min(1.0, max(0.0, rank / self.vocab_size))
        return LAMBDA_MIN + (normalized_rank * LAMBDA_RANGE)

    def _wavelength_to_basin(self, wavelength: float) -> int:
        """Convert wavelength to basin number."""
        wavelength = max(LAMBDA_MIN, min(LAMBDA_MAX, wavelength))
        normalized = (wavelength - LAMBDA_MIN) / LAMBDA_RANGE
        basin = int(normalized * (PRIME_131 - 1))
        return max(0, min(PRIME_131 - 1, basin))

    # ========================================================================
    # LAYER COMPUTATIONS
    # ========================================================================

    def _compute_l1_basin(self, terms: List[str]) -> Tuple[int, float]:
        """
        L1: Basin from frequency-derived wavelength.

        Returns (basin, avg_wavelength)
        """
        if not terms:
            return 65, (LAMBDA_MIN + LAMBDA_MAX) / 2  # Center basin

        wavelengths = []
        for term in terms:
            rank = self._get_term_rank(term)
            wl = self._frequency_to_wavelength(rank)
            wavelengths.append(wl)

        avg_wl = sum(wavelengths) / len(wavelengths)
        basin = self._wavelength_to_basin(avg_wl)
        return basin, avg_wl

    def _compute_l2_semantic(self, tokens: List[str]) -> int:
        """
        L2: Semantic class from grammatical structure.

        Returns class 0-4.
        """
        token_set = set(tokens)

        # Check each class's keywords
        scores = [0, 0, 0, 0, 0]
        for l2_class, keywords in L2_KEYWORDS.items():
            scores[l2_class] = len(token_set & keywords)

        # If tie or no matches, default to FUNCTIONAL (most common for commands)
        if max(scores) == 0:
            return L2_FUNCTIONAL

        return scores.index(max(scores))

    def _compute_l3_morton(self, terms: List[str], wavelength: float) -> Tuple[int, int, int, int]:
        """
        L3: Morton position from frequency components.

        X: Average wavelength position (spectral)
        Y: Term frequency variance (information spread)
        Z: Grammatical depth (sentence complexity)

        Returns (x, y, z, morton)
        """
        # X: Wavelength -> position in spectrum
        x_norm = (wavelength - LAMBDA_MIN) / LAMBDA_RANGE
        x = int(x_norm * (MATRIX_SIZE - 1))
        x = max(0, min(MATRIX_SIZE - 1, x))

        # Y: Frequency variance -> spread across vocabulary
        if len(terms) > 1:
            ranks = [self._get_term_rank(t) for t in terms]
            mean_rank = sum(ranks) / len(ranks)
            variance = sum((r - mean_rank) ** 2 for r in ranks) / len(ranks)
            y_norm = min(1.0, math.sqrt(variance) / (self.vocab_size / 4))
        else:
            y_norm = 0.5
        y = int(y_norm * (MATRIX_SIZE - 1))
        y = max(0, min(MATRIX_SIZE - 1, y))

        # Z: Term count as proxy for complexity
        z_norm = min(1.0, len(terms) / 20)  # Normalize: 20 terms = max depth
        z = int(z_norm * (MATRIX_SIZE - 1))
        z = max(0, min(MATRIX_SIZE - 1, z))

        # Morton encoding (interleaved bits)
        morton = self._morton_encode(x, y, z)

        return x, y, z, morton

    def _morton_encode(self, x: int, y: int, z: int) -> int:
        """Encode (x,y,z) to Morton/Z-order code."""
        def spread_bits(v):
            v = v & 0x3FF
            v = (v | (v << 16)) & 0x030000FF
            v = (v | (v << 8)) & 0x0300F00F
            v = (v | (v << 4)) & 0x030C30C3
            v = (v | (v << 2)) & 0x09249249
            return v
        return spread_bits(x) | (spread_bits(y) << 1) | (spread_bits(z) << 2)

    def _compute_l4_k5k11(self, x: int, y: int, z: int) -> Tuple[int, int, str]:
        """
        L4: K5xK11 from position.

        K5 = (x + y + z) % 5 -> [0, 4]
        K11 = (x + y + z) % 23 - 11 -> [-11, +11]
        State from K11 mod 4

        Returns (k5, k11, state_name)
        """
        total = x + y + z
        k5 = total % K5_VAL
        k11 = (total % K11_VAL) - 11

        # State from K11 mod 4
        k11_mod4 = ((k11 % 4) + 4) % 4
        states = ['ABSORBED', 'DIRECT', 'INVERSE', 'SPIRAL']
        state = states[k11_mod4]

        return k5, k11, state

    def _compute_l5_energy(self, text: str, terms: List[str]) -> float:
        """
        L5: Energy from information entropy.

        Higher entropy = more information = higher energy.
        """
        if not text:
            return 0.0

        # Shannon entropy of characters
        char_counts = Counter(text.lower())
        total = len(text)
        entropy = 0.0
        for count in char_counts.values():
            if count > 0:
                p = count / total
                entropy -= p * math.log2(p)

        # Normalize to 0-1 (max entropy for 26 chars ~ 4.7)
        max_entropy = math.log2(min(len(char_counts), 26))
        if max_entropy > 0:
            normalized = entropy / max_entropy
        else:
            normalized = 0.0

        # Boost for term specificity (rare terms = more information)
        if terms:
            avg_rank = sum(self._get_term_rank(t) for t in terms) / len(terms)
            rank_boost = avg_rank / self.vocab_size
            normalized = min(1.0, normalized * 0.7 + rank_boost * 0.3)

        return normalized

    def _compute_l6_emotion(self, tokens: List[str], text: str) -> Tuple[int, int, int, int]:
        """
        L6: Emotion as behavioral physics (154 states).

        Three axes measured from text structure:
        - Commitment: definite vs indefinite articles
        - Focus: specific vs generic nouns
        - Stability: declarative vs interrogative

        Returns (state, commitment, focus, stability)
        """
        token_set = set(tokens)

        # Axis 1: Commitment (stiffness)
        definite_count = len(token_set & DEFINITE_ARTICLES)
        indefinite_count = len(token_set & INDEFINITE_ARTICLES)
        if definite_count + indefinite_count > 0:
            commitment_ratio = definite_count / (definite_count + indefinite_count)
        else:
            commitment_ratio = 0.5  # Neutral
        commitment = int(commitment_ratio * 4)  # 0-4

        # Axis 2: Focus (attraction)
        specific_count = len(token_set & SPECIFIC_MARKERS)
        generic_count = len(token_set & GENERIC_MARKERS)
        # Also count hex IDs and numbers as specific
        hex_count = len(re.findall(r'[0-9a-fA-F]{6,}', text))
        specific_count += hex_count
        if specific_count + generic_count > 0:
            focus_ratio = specific_count / (specific_count + generic_count + 1)
        else:
            # Check for named entities (capitalized words)
            caps = len(re.findall(r'\b[A-Z][a-z]+\b', text))
            focus_ratio = min(1.0, caps / 5) if caps else 0.5
        focus = int(focus_ratio * 4)  # 0-4

        # Axis 3: Stability (inverse turbulence)
        declarative_count = len(token_set & DECLARATIVE_MARKERS)
        interrogative_count = len(token_set & INTERROGATIVE_MARKERS)
        if '?' in text:
            interrogative_count += 1
        if declarative_count + interrogative_count > 0:
            stability_ratio = declarative_count / (declarative_count + interrogative_count)
        else:
            stability_ratio = 0.5  # Neutral
        stability = int(stability_ratio * 4)  # 0-4

        # Encode to state 0-154
        # Base: commitment*25 + focus*5 + stability = 0-124
        # Compound states: 125-153 for extremes
        state = commitment * 25 + focus * 5 + stability

        # Detect compound states (multiple axes at extreme)
        extremes = (commitment in (0, 4)) + (focus in (0, 4)) + (stability in (0, 4))
        if extremes >= 2:
            # Shift to compound range
            state = 125 + (commitment // 2) * 9 + (focus // 2) * 3 + (stability // 2)
            state = min(153, state)

        return state, commitment, focus, stability

    def _compute_l7_wavelength(self, avg_wavelength: float) -> float:
        """L7: Direct wavelength from frequency."""
        return avg_wavelength

    def _compute_l8_polarity(self, tokens: List[str], text: str) -> Tuple[str, complex]:
        """
        L8: Polarity from grammatical structure.

        DIRECT: Affirmative assertion
        INVERSE: Negation or reversal
        """
        token_set = set(tokens)

        # Check for negation
        has_negation = bool(token_set & NEGATION_MARKERS)

        # Check for question
        is_question = '?' in text

        if has_negation:
            return 'INVERSE', ILogicState.INVERSE
        elif is_question:
            return 'INVERSE', ILogicState.INVERSE
        else:
            return 'DIRECT', ILogicState.DIRECT

    def _compute_l9_membrane(self) -> int:
        """L9: Session/context boundary."""
        return self.membrane_id

    def _generate_hex_id(self, token: FMLToken) -> str:
        """
        Generate deterministic hex ID from token layers.

        Format: BBMMSSEE
            BB = Basin (00-82)
            MM = Morton low 8 bits
            SS = L6 state (00-99)
            EE = Energy + polarity encoded
        """
        bb = token.l1_basin & 0xFF
        mm = token.l3_morton & 0xFF
        ss = token.l6_state & 0xFF

        # Encode energy (0-15) + polarity bit (0/1) into EE
        energy_nibble = int(token.l5_energy * 15) & 0x0F
        polarity_bit = 0 if token.l8_polarity == 'DIRECT' else 1
        ee = (energy_nibble << 4) | (polarity_bit << 3) | (token.l2_semantic & 0x07)

        return f"{bb:02X}{mm:02X}{ss:02X}{ee:02X}"

    # ========================================================================
    # MAIN ENCODE METHOD
    # ========================================================================

    def encode(self, text: str) -> FMLToken:
        """
        Encode text into a deterministic 9-layer token.

        Same input ALWAYS produces same output.

        Args:
            text: Input text to encode

        Returns:
            FMLToken with all 9 layers computed
        """
        # Tokenize
        tokens = self._tokenize(text)
        terms = self._extract_terms(text)

        # Create token
        token = FMLToken(text=text)

        # L1 + L7: Basin and wavelength (computed together)
        token.l1_basin, token.l7_wavelength = self._compute_l1_basin(terms)

        # L2: Semantic class
        token.l2_semantic = self._compute_l2_semantic(tokens)
        token.l2_semantic_name = L2_NAMES[token.l2_semantic]

        # L3: Morton position
        token.l3_x, token.l3_y, token.l3_z, token.l3_morton = self._compute_l3_morton(
            terms, token.l7_wavelength
        )

        # L4: K5xK11
        token.l4_k5, token.l4_k11, token.l4_state = self._compute_l4_k5k11(
            token.l3_x, token.l3_y, token.l3_z
        )

        # L5: Energy
        token.l5_energy = self._compute_l5_energy(text, terms)

        # L6: Emotion
        token.l6_state, token.l6_commitment, token.l6_focus, token.l6_stability = \
            self._compute_l6_emotion(tokens, text)

        # L8: Polarity
        token.l8_polarity, token.l8_ilogic = self._compute_l8_polarity(tokens, text)

        # L9: Membrane
        token.l9_membrane = self._compute_l9_membrane()

        # Generate hex ID
        token.hex_id = self._generate_hex_id(token)

        return token

    def encode_batch(self, texts: List[str]) -> List[FMLToken]:
        """Encode multiple texts."""
        return [self.encode(t) for t in texts]


# ==============================================================================
# CONVENIENCE FUNCTIONS
# ==============================================================================

_encoder: Optional[FMLEncoder] = None


def get_encoder(membrane_id: int = 0) -> FMLEncoder:
    """Get or create singleton encoder instance."""
    global _encoder
    if _encoder is None or _encoder.membrane_id != membrane_id:
        _encoder = FMLEncoder(membrane_id=membrane_id)
    return _encoder


def encode_text(text: str, membrane_id: int = 0) -> FMLToken:
    """Convenience function to encode text."""
    return get_encoder(membrane_id).encode(text)


def encode_to_dict(text: str, membrane_id: int = 0) -> Dict:
    """Encode and return as dict."""
    return encode_text(text, membrane_id).to_dict()


def get_basin_for_text(text: str) -> int:
    """Get basin for text (L1)."""
    return encode_text(text).l1_basin


def get_wavelength_for_text(text: str) -> float:
    """Get wavelength for text (L7)."""
    return encode_text(text).l7_wavelength


def get_polarity_for_text(text: str) -> str:
    """Get polarity for text (L8)."""
    return encode_text(text).l8_polarity


# Add run method to FMLEncoder
def _fml_encoder_run(self, command: str, *args, as_json: bool = False):
    """Run a shell command (CLI interface)."""
    import json
    commands = {
        'status': lambda: {
            'hex_id': '0BF1DD10',
            'vocab_size': self.vocab_size,
            'term_ranks_count': len(self.term_ranks),
            'membrane_id': self.membrane_id,
            'l2_classes': L2_NAMES,
        },
        'encode': lambda: self.encode(args[0] if args else '').to_dict(),
        'batch': lambda: [t.to_dict() for t in self.encode_batch(list(args))],
        'compact': lambda: self.encode(args[0] if args else '').to_compact(),
        'basin': lambda: get_basin_for_text(args[0] if args else ''),
        'wavelength': lambda: get_wavelength_for_text(args[0] if args else ''),
        'polarity': lambda: get_polarity_for_text(args[0] if args else ''),
    }
    if command in commands:
        result = commands[command]()
        if as_json and isinstance(result, (dict, list)):
            return json.dumps(result, indent=2, default=str)
        return result
    return {'error': f'Unknown command: {command}', 'available': list(commands.keys())}

# Attach to class
FMLEncoder.run = _fml_encoder_run
