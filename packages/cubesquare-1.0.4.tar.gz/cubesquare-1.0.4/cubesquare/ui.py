"""
Cubesquare UI Launcher

Launches the internal visualizer in the default web browser.
"""
import webbrowser
import sys
from pathlib import Path

def launch():
    """Launch the internal visualizer."""
    # Find the package root
    package_dir = Path(__file__).parent.parent
    visualizer_path = package_dir / "internal" / "visualizer.html"
    
    if not visualizer_path.exists():
        print(f"Error: Visualizer not found at {visualizer_path}")
        sys.exit(1)
        
    url = f"file://{visualizer_path.absolute()}"
    print(f"Opening visualizer: {url}")
    webbrowser.open(url)

if __name__ == "__main__":
    launch()
