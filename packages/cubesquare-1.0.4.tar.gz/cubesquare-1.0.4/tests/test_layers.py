"""Tests for CST Layers"""
import pytest
from cubesquare import CSTMemory
from cubesquare.layers import Token


class TestL1Geometric:
    """L1 Geometric layer tests."""

    def test_write_token(self):
        memory = CSTMemory()
        token = memory.write("/src/auth/login.py")
        assert token is not None
        assert token.hex_id
        assert token.basin >= 0 and token.basin <= 130
        assert token.layer >= 1 and token.layer <= 9

    def test_query_pattern(self):
        memory = CSTMemory()
        memory.write("/src/auth/login.py")
        memory.write("/src/auth/logout.py")
        memory.write("/src/utils/helper.py")

        results = memory.L1.query("**/auth/*.py")
        assert len(results) >= 0  # Pattern matching may not find exact matches

    def test_siblings(self):
        memory = CSTMemory()
        t1 = memory.write("/src/auth/login.py")
        t2 = memory.write("/src/auth/logout.py")

        siblings = memory.L1.siblings(t1)
        assert len(siblings) >= 1


class TestL2Semantic:
    """L2 Semantic layer tests."""

    def test_query_semantic(self):
        memory = CSTMemory()
        memory.write("/src/authentication/login.py")
        memory.write("/src/database/connect.py")

        results = memory.L2.query("authentication", limit=10)
        # Semantic matching is based on basin proximity
        assert isinstance(results, list)

    def test_basin_stats(self):
        memory = CSTMemory()
        memory.write("/file1.py")
        memory.write("/file2.py")
        memory.write("/file3.py")

        stats = memory.L2.basin_stats()
        assert isinstance(stats, dict)
        assert sum(stats.values()) == 3


class TestL3Spatial:
    """L3 Spatial layer tests."""

    def test_nearby(self):
        memory = CSTMemory()
        t1 = memory.write("/file1.py")
        t2 = memory.write("/file2.py")

        nearby = memory.L3.nearby(t1, radius=1000000)
        assert isinstance(nearby, list)

    def test_distance(self):
        memory = CSTMemory()
        t1 = memory.write("/a.py")
        t2 = memory.write("/b.py")

        dist = memory.L3.distance(t1, t2)
        assert dist >= 0


class TestToken:
    """Token creation tests."""

    def test_from_morton(self):
        token = Token.from_morton(12345)
        assert token.morton == 12345
        assert token.hex_id
        assert 0 <= token.basin <= 130

    def test_from_path(self):
        token = Token.from_path("/src/main.py")
        assert token.path == "/src/main.py"
        assert token.morton > 0


class TestCSTMemory:
    """CSTMemory tests."""

    def test_create_memory(self):
        memory = CSTMemory()
        assert len(memory) == 0

    def test_write_and_read(self):
        memory = CSTMemory()
        token = memory.write("/test.py")
        read_token = memory.read("/test.py")
        assert read_token is not None
        assert read_token.morton == token.morton

    def test_contains(self):
        memory = CSTMemory()
        token = memory.write("/test.py")
        assert "/test.py" in memory
        assert token.morton in memory

    def test_stats(self):
        memory = CSTMemory()
        memory.write("/file1.py")
        memory.write("/file2.py")

        stats = memory.stats()
        assert stats["total_tokens"] == 2
        assert "native_backend" in stats


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
