# Cucumber 🥒
Cucumber is a free and lightweight python library to detect nsfw, gore, scam, neutral from images. It utilizes machine learning vision model to do so.

# Installation
```py
pip install cucumberify
```

**NOTE FOR WINDOWS USER:**
This library uses a small compiled extension on Windows (sdist install).
So you must install Microsoft Visual C++ Build Tools first.

1. Download and install:
    https://visualstudio.microsoft.com/visual-cpp-build-tools/

2. During setup, select:
   "Desktop development with C++"

3. Then run:
```py
python -m pip install --upgrade pip setuptools wheel
pip install cucumberify
```

# Example usage (Local Image)
```py
from cucumberify import cucumber
print(cucumber("car.jpg"))
```

# Response example
```py
{'nsfw': 0.0, 'gore': 0.0, 'scam': 0.0, 'neutral': 1.0}
```

# Example usage (Image URL)
```py
from cucumberify import cucumber
print(cucumber('https://cdni.lamalinks.com/1280/1/171/32937397/32937397_001_8121.jpg'))
```

# Response example
```py
{'nsfw': 0.9, 'gore': 0.0, 'scam': 0.0, 'neutral': 0.0}
```

**Note that the values are floating points between 0 and 1**

# Made with ♥️ by [Blaze](https://discord.com/users/1238444724386533417)

# Feel free to DM me on discord if there's any issues :>
