# imports
import time
import threading
from collections import deque


# variables
lock = threading.Lock()
queue = deque()
lastcall = 0


# functions
def runqueued(task):
    global lastcall
    with lock:
        queue.append(task)

    while True:
        with lock:
            if queue[0] != task:
                pass
            else:
                now = time.time()
                wait = 7 - (now - lastcall)
                if wait > 0:
                    time.sleep(wait)

                lastcall = time.time()
                queue.popleft()
                return task()

        time.sleep(0.05)
