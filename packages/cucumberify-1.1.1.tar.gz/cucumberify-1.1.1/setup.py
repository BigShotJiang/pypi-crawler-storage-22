from setuptools import setup, Extension, find_packages

setup(
    name="cucumberify",
    version="1.1.1",
    packages=find_packages(),
    ext_modules=[
        Extension(
            "cucumberify.core",
            ["cucumberify/core.c"],
        )
    ],
    install_requires=["requests", "pillow"],
    author="Blaze",
    description="Cucumber is a free and lightweight vision classifier to detect nsfw, gore, scam, neutral from images",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
)
