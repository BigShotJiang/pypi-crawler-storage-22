# c_pt_deceased_count

**Basic Deceased Patient Demographics**

### Fields

- age
- administrative_gender
- status

### Notes on `age`

When possible, this tries to accurately determine age across birthday boundaries.
(e.g. if a birthday is in July, and they died in February, that year will not be counted)
