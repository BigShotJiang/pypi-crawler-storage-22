# t_valid_us_core_v6

This metric only exists for the benefit of unit testing.
You can safely ignore it.
