# US Core v4 Profile Support Code

This folder holds SQL for querying mandatory and must-support elements
for each US Core profile.

It also holds some basic Python code to support the metrics that rely on profiles.

See the
[full list of profiles](http://hl7.org/fhir/us/core/STU6.1/profiles-and-extensions.html)
for more spec-based information.
