This is my pull request comment. Just explaining some stuff I did here, but should not be in release notes.

# Critical Changes

* This will break everything!

# Changes

Here's something I did. It was really cool

Oh yeah I did something else too!


# Issues Closed

Fixed #2345 that was a real pain
Also resolved #6236 finally!
