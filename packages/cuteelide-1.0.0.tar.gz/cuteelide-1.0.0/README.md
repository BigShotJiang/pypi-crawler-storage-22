# CuteElide

[![License: GPL v3+](https://img.shields.io/badge/License-GPLv3%2B-blue.svg)](LICENSE) [![PyPI](https://img.shields.io/pypi/v/CuteElide.svg)](https://pypi.org/project/CuteElide/) [![Python](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/downloads/) [![PySide6](https://img.shields.io/badge/PySide6-6.5%2B-41CD52?logo=qt&logoColor=white)](https://pyside.org)

**CuteElide** is a tiny, robust text‑elision toolkit for PySide6 that **never gets stuck** after resize. It elides at **paint time**, so it always reflects the **current** width.

If you’ve ever had QLabel text that elides once and then refuses to reflow when the window shrinks, CuteElide is the end of that pain.

## Highlights
- **Paint‑Time Elision:** Always correct on expand and shrink — no timers, no resize hacks.
- **Widget‑Agnostic:** Works with any widget (custom or themed). Use the renderer in any `paintEvent`.
- **Left, Right, or Middle:** Pick the elide mode that fits your UX.
- **Tiny Surface Area:** One facade import with clear, expressive methods.

## Installation

```bash
pip install CuteElide
```

## Quick Start

### 1) Use the utility in any widget
```python
from PySide6.QtCore import Qt
from PySide6.QtGui import QPainter
from cuteelide import cuteelide

# Inside paintEvent:
cuteelide.paint(
    painter,
    rect=self.contentsRect(),
    text="Some stories are longer than the space they’re given",
    font=self.font(),
    palette=self.palette(),
    mode="middle",
)
```

### 2) Drop‑in label
```python
from PySide6.QtCore import Qt
from cuteelide import cuteelide

label = cuteelide.label(
    text="A very long string that should always elide correctly",
    mode="right",
)
```

## What is eliding?
Eliding is the art of saying “this sentence is too long” without cutting the sentence in half. When there isn’t enough space, we replace the overflowing part with a gentle “…” so the UI stays clean, and the reader still knows there’s more beneath the surface.

## Why Paint‑Time Elision
Resize‑driven elision is fragile because Qt layouts change geometry late in the event cycle. By eliding at draw time, CuteElide uses the **exact width** that will be painted — every frame.

## Demo
A small demo app is included to showcase all elision modes and a custom paint example.

```bash
python examples/demo.py
```

## API Overview
- `cuteelide.text(text, font, width, mode)`
- `cuteelide.paint(painter, rect=..., text=..., mode=..., align=..., padding=...)`
- `cuteelide.label(text=..., mode=..., align=..., padding=...)`

## License

CuteElide is **Free and Open Source Software (FOSS)**, distributed under the **GNU General Public License v3.0 or later**.

## From the Developer 💖

I hope CuteElide saves you the time I’ve lost to resize‑glitchy labels! If you’d like to support my work or see what else I’m up to, here are a few links:

- **Buy Me a Coffee**: You can help fuel more projects like this at my [Ko-fi page](https://ko-fi.com/artificial_sweetener).
- **My Website & Socials**: See my art, poetry, and other dev updates at [artificialsweetener.ai](https://artificialsweetener.ai).
- **If you like this project**, it would mean a lot to me if you gave me a star here on Github!! ⭐
