from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication

from cuteelide import cuteelide


def _app():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def test_elide_text_short_width():
    _app()
    font = QFont()
    text = "A very long string that will be elided"
    result = cuteelide.text(text, font=font, width=40, mode="right")
    assert result != text
    assert "…" in result


def test_elide_text_empty():
    _app()
    font = QFont()
    assert cuteelide.text("", font=font, width=40, mode="right") == ""
    assert cuteelide.text("test", font=font, width=0, mode="right") == ""
