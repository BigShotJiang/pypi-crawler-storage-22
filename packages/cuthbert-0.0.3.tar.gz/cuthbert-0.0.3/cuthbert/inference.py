"""Provides protocols and types for representing unified inference objects."""

from typing import NamedTuple, Protocol

from cuthbertlib.types import ArrayTree, ArrayTreeLike, KeyArray


class InitPrepare(Protocol):
    """Protocol for preparing the initial state for the inference."""

    def __call__(
        self,
        model_inputs: ArrayTreeLike,
        key: KeyArray | None = None,
    ) -> ArrayTree:
        """Prepare the initial state for the inference.

        The state at the first time point, prior to any observations.

        Args:
            model_inputs: The model inputs at the first time point.
            key: The key for the random number generator.
                Optional, as only used for stochastic inference methods

        Returns:
            The initial state, a NamedTuple with inference-specific fields.
        """
        ...


class FilterPrepare(Protocol):
    """Protocol for preparing the state for the filter at the next time point."""

    def __call__(
        self,
        model_inputs: ArrayTreeLike,
        key: KeyArray | None = None,
    ) -> ArrayTree:
        """Prepare the state for the filter at the next time point.

        Converts the model inputs (and any stochasticity) into a unified state
        object which can be combined with a state (of the same form) from the
        previous time point with FilterCombine.

        state = FilterCombine(prev_state, FilterPrepare(model_inputs, key))

        Args:
            model_inputs: The model inputs at the next time point.
            key: The key for the random number generator.
                Optional, as only used for stochastic inference methods

        Returns:
            The state prepared for FilterCombine,
                a NamedTuple with inference-specific fields.
        """
        ...


class FilterCombine(Protocol):
    """Protocol for combining the previous state with the state from FilterPrepare."""

    def __call__(
        self,
        state_1: ArrayTreeLike,
        state_2: ArrayTreeLike,
    ) -> ArrayTree:
        """Combine state from previous time point with state from FilterPrepare.

        ```python
        state = FilterCombine(prev_state, FilterPrepare(model_inputs, key))
        ```

        Args:
            state_1: The state from the previous time point.
            state_2: The state from FilterPrepare for the current time point.

        Returns:
            The combined filter state, a NamedTuple with inference-specific fields.
        """
        ...


class SmootherPrepare(Protocol):
    """Protocol for preparing the state for the smoother."""

    def __call__(
        self,
        filter_state: ArrayTreeLike,
        model_inputs: ArrayTreeLike,
        key: KeyArray | None = None,
    ) -> ArrayTree:
        """Prepare the state for the smoother at the next time point.

        Converts `filter_state` with `model_inputs` (and any stochasticity) into a
        unified state object which can be combined with a state (of the same form)
        from the next time point with `SmootherCombine`.

        Remember smoothing iterates backwards in time.

        ```python
        state = SmootherCombine(
            SmootherPrepare(filter_state, model_inputs, key), next_smoother_state
        )
        ```

        Note that the `model_inputs` here are different to `filter_state.model_inputs`.
        The `model_inputs` required here are for the transition from t to t+1.
        `filter_state.model_inputs` represents the transition from t-1 to t.

        Args:
            filter_state: The state from the filter at the previous time point.
            model_inputs: Model inputs for the transition from t to t+1.
            key: The key for the random number generator.
                Optional, as only used for stochastic inference methods

        Returns:
            The state prepared for `SmootherCombine`,
                a NamedTuple with inference-specific fields.
        """
        ...


class SmootherCombine(Protocol):
    """Protocol for combining the next smoother state with the state prepared with latest model inputs."""

    def __call__(
        self,
        state_1: ArrayTreeLike,
        state_2: ArrayTreeLike,
    ) -> ArrayTree:
        """Combine the state from the next time point with the state from `SmootherPrepare`.

        Remember smoothing iterates backwards in time.

        ```python
        state = SmootherCombine(
            SmootherPrepare(filter_state, model_inputs, key), next_smoother_state
        )
        ```

        Args:
            state_1: The state from `SmootherPrepare` for the current time point.
            state_2: The state from the next time point.

        Returns:
            The combined smoother state, a NamedTuple with inference-specific fields.
        """
        ...


class ConvertFilterToSmootherState(Protocol):
    """Protocol for converting a filter state to a smoother state."""

    def __call__(
        self,
        filter_state: ArrayTreeLike,
        model_inputs: ArrayTreeLike | None = None,
        key: KeyArray | None = None,
    ) -> ArrayTree:
        """Convert the filter state to a smoother state.

        Useful for offline smoothing where the final filter state is statistically
        equivalent to the final smoother state.
        This function converts the filter state to the smoother state data structure.

        Args:
            filter_state: The filter state.
            model_inputs: Only used to create an empty `model_inputs` tree
                (the values are ignored).
                Useful so that the final smoother state has the same structure as the rest.
                By default, `filter_state.model_inputs` is used. So this
                is only needed if the smoother `model_inputs` have a different tree
                structure to `filter_state.model_inputs`.
            key: The key for the random number generator.
                Optional, as only used for stochastic inference methods

        Returns:
            The smoother state.
        """
        ...


class Filter(NamedTuple):
    """Filter object.

    Typically passed to [cuthbert.filtering.filter][].

    Attributes:
        init_prepare: Function to prepare the initial state for the filter.
        filter_prepare: Function to prepare intermediate states for the filter.
        filter_combine: Function that combines two filter states to produce another.
        associative: Whether `filter_combine` is an associative operator. Temporally
            parallelized filters are guaranteed to produce correct results only if
            `associative=True`.
    """

    init_prepare: InitPrepare
    filter_prepare: FilterPrepare
    filter_combine: FilterCombine
    associative: bool = False


class Smoother(NamedTuple):
    """Smoother object.

    Typically passed to [cuthbert.smoothing.smoother][].

    Attributes:
        convert_filter_to_smoother_state: Function to convert the final filter state to a smoother state.
        smoother_prepare: Function to prepare intermediate states for the smoother.
        smoother_combine: Function that combines two smoother states to produce another.
        associative: Whether `smoother_combine` is an associative operator. Temporally
            parallelized smoothers are guaranteed to produce correct results only if
            `associative=True`.
    """

    convert_filter_to_smoother_state: ConvertFilterToSmootherState
    smoother_prepare: SmootherPrepare
    smoother_combine: SmootherCombine
    associative: bool = False
