"""
cuti - Production-ready claude code utils with command queuing, web interface, and monitoring.
"""

# This file is intentionally minimal - the main package is in src/cuti/
__version__ = "0.1.0"