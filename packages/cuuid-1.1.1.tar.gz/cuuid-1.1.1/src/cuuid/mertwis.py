"""
Copyright (c) 2026 Dubalu International LLC

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

# Mersenne Twister implementation

from random import Random


class MT19937:
    """Mersenne Twister MT19937 pseudo-random number generator."""

    random: Random

    def __init__(self, seed: int) -> None:
        """Initialize MT19937 with given seed.

        Args:
            seed: Integer seed for the random number generator.
        """
        mt = [0] * 624
        mt[0] = p = seed & 0xffffffff
        for mti in range(1, 624):
            mt[mti] = p = (1812433253 * (p ^ (p >> 30)) + mti) & 0xffffffff
        self.random = Random()
        # State format: (version, (state_tuple, index), gauss_next)
        self.random.setstate((3, (*tuple(mt), 624), None))

    def __call__(self) -> int:
        """Generate a 32-bit random number.

        Returns:
            A random 32-bit unsigned integer.
        """
        return self.random.getrandbits(32)
