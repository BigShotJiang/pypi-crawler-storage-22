from __future__ import annotations

import pytest

from cuuid import UUID, decode, encode, unserialise

# fmt: off
# (input_uuid_str, expected_unserialised, expected_encoded, expected_serialised)
UUIDS = [
    # Full:
    ('5759b016-10c0-4526-a981-47d6d19f6fb4', ['5759b016-10c0-4526-a981-47d6d19f6fb4'], '5759b016-10c0-4526-a981-47d6d19f6fb4', b'\x01WY\xb0\x16\x10\xc0E&\xa9\x81G\xd6\xd1\x9fo\xb4'),
    ('e8b13d1b-665f-4f4c-aa83-76fa782b030a', ['e8b13d1b-665f-4f4c-aa83-76fa782b030a'], 'e8b13d1b-665f-4f4c-aa83-76fa782b030a', b'\x01\xe8\xb1=\x1bf_OL\xaa\x83v\xfax+\x03\n'),
    # Condensed:
    ('00000000-0000-1000-8000-000000000000', ['00000000-0000-1000-8000-000000000000'], '00000000-0000-1000-8000-000000000000', b'\x1c\x00\x00\x00'),
    ('11111111-1111-1111-8111-111111111111', ['11111111-1111-1111-8111-111111111111'], '~GcL2nemYXfTUrDbsYYiTDNc', b'\x0f\x88\x88\x88\x88\x88\x88\x88\x82"""""""'),
    # Condensed + Compacted:
    ('230c0800-dc3c-11e7-b966-a3ab262e682b', ['230c0800-dc3c-11e7-b966-a3ab262e682b'], '~SsQg3rJrx3P', b'\x06,\x02[\x089fW'),
    ('f2238800-debf-11e7-bbf7-dffcee0c03ab', ['f2238800-debf-11e7-bbf7-dffcee0c03ab'], '~SlMSibYTT8c', b'\x06.\x86*\x1f\xbb\xf7W'),
    # Condensed + Expanded:
    ('60579016-dec5-11e7-b616-34363bc9ddd6', ['60579016-dec5-11e7-b616-34363bc9ddd6'], '60579016-dec5-11e7-b616-34363bc9ddd6', b'\xe1\x17E\xcc)\xc4\x0bl,hlw\x93\xbb\xac'),
    ('4ec97478-c3a9-11e6-bbd0-a46ba9ba5662', ['4ec97478-c3a9-11e6-bbd0-a46ba9ba5662'], '4ec97478-c3a9-11e6-bbd0-a46ba9ba5662', b'\x0e\x89\xb7\xc3b\xb6<w\xa1H\xd7St\xac\xc4'),
    # Other:
    ('00000000-0000-0000-0000-000000000000', ['00000000-0000-0000-0000-000000000000'], '00000000-0000-0000-0000-000000000000', b'\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'),
    ('00000000-0000-1000-8000-010000000000', ['00000000-0000-1000-8000-010000000000'], '~notmet', b'\x1c\x00\x00\x01'),
    ('11111111-1111-1111-8111-101111111111', ['11111111-1111-1111-8111-101111111111'], '11111111-1111-1111-8111-101111111111', b'\xf7\x95\xb0k\xa4\x86\x84\x88\x82" """""'),
    ('00000000-0000-1000-a000-000000000000', ['00000000-0000-1000-a000-000000000000'], '00000000-0000-1000-a000-000000000000', b'\n@\x00\x00\x00\x00\x00\x00\x00'),
    # Compound:
    ('5759b016-10c0-4526-a981-47d6d19f6fb4;e8b13d1b-665f-4f4c-aa83-76fa782b030a', ['5759b016-10c0-4526-a981-47d6d19f6fb4', 'e8b13d1b-665f-4f4c-aa83-76fa782b030a'], '5759b016-10c0-4526-a981-47d6d19f6fb4;e8b13d1b-665f-4f4c-aa83-76fa782b030a', b'\x01WY\xb0\x16\x10\xc0E&\xa9\x81G\xd6\xd1\x9fo\xb4\x01\xe8\xb1=\x1bf_OL\xaa\x83v\xfax+\x03\n'),
    ('00000000-0000-1000-8000-000000000000;11111111-1111-1111-8111-111111111111', ['00000000-0000-1000-8000-000000000000', '11111111-1111-1111-8111-111111111111'], '~WPQl2On7vMpv7TMQBPSquHXo4WWz', b'\x1c\x00\x00\x00\x0f\x88\x88\x88\x88\x88\x88\x88\x82"""""""'),
    ('230c0800-dc3c-11e7-b966-a3ab262e682b;f2238800-debf-11e7-bbf7-dffcee0c03ab', ['230c0800-dc3c-11e7-b966-a3ab262e682b', 'f2238800-debf-11e7-bbf7-dffcee0c03ab'], '~KY9OflmS8UZsL8Ug64UcVQ', b'\x06,\x02[\x089fW\x06.\x86*\x1f\xbb\xf7W'),
    ('60579016-dec5-11e7-b616-34363bc9ddd6;4ec97478-c3a9-11e6-bbd0-a46ba9ba5662', ['60579016-dec5-11e7-b616-34363bc9ddd6', '4ec97478-c3a9-11e6-bbd0-a46ba9ba5662'], '60579016-dec5-11e7-b616-34363bc9ddd6;4ec97478-c3a9-11e6-bbd0-a46ba9ba5662', b'\xe1\x17E\xcc)\xc4\x0bl,hlw\x93\xbb\xac\x0e\x89\xb7\xc3b\xb6<w\xa1H\xd7St\xac\xc4'),
    ('00000000-0000-1000-8000-010000000000;11111111-1111-1111-8111-101111111111', ['00000000-0000-1000-8000-010000000000', '11111111-1111-1111-8111-101111111111'], '00000000-0000-1000-8000-010000000000;11111111-1111-1111-8111-101111111111', b'\x1c\x00\x00\x01\xf7\x95\xb0k\xa4\x86\x84\x88\x82" """""'),
    # Compound + Encoded:
    ('~HAhyatqQHjUq9ztms7NrcPfd34a8PQ3pa3D2BxYrzN55QD', ['5759b016-10c0-4526-a981-47d6d19f6fb4', 'e8b13d1b-665f-4f4c-aa83-76fa782b030a'], '5759b016-10c0-4526-a981-47d6d19f6fb4;e8b13d1b-665f-4f4c-aa83-76fa782b030a', b'\x01WY\xb0\x16\x10\xc0E&\xa9\x81G\xd6\xd1\x9fo\xb4\x01\xe8\xb1=\x1bf_OL\xaa\x83v\xfax+\x03\n'),
    ('~WPQl2On7vMpv7TMQBPSquHXo4WWz', ['00000000-0000-1000-8000-000000000000', '11111111-1111-1111-8111-111111111111'], '~WPQl2On7vMpv7TMQBPSquHXo4WWz', b'\x1c\x00\x00\x00\x0f\x88\x88\x88\x88\x88\x88\x88\x82"""""""'),
    ('~KY9OflmS8UZsL8Ug64UcVQ', ['230c0800-dc3c-11e7-b966-a3ab262e682b', 'f2238800-debf-11e7-bbf7-dffcee0c03ab'], '~KY9OflmS8UZsL8Ug64UcVQ', b'\x06,\x02[\x089fW\x06.\x86*\x1f\xbb\xf7W'),
    ('~yoLaxhaywcbaBPzQQmZlCSFts6Sm9fCxD76ctNiw7q', ['60579016-dec5-11e7-b616-34363bc9ddd6', '4ec97478-c3a9-11e6-bbd0-a46ba9ba5662'], '60579016-dec5-11e7-b616-34363bc9ddd6;4ec97478-c3a9-11e6-bbd0-a46ba9ba5662', b'\xe1\x17E\xcc)\xc4\x0bl,hlw\x93\xbb\xac\x0e\x89\xb7\xc3b\xb6<w\xa1H\xd7St\xac\xc4'),
    ('~WPQlEPuOJZ3Y9TclmoaUhJFiUicy', ['00000000-0000-1000-8000-010000000000', '11111111-1111-1111-8111-101111111111'], '00000000-0000-1000-8000-010000000000;11111111-1111-1111-8111-101111111111', b'\x1c\x00\x00\x01\xf7\x95\xb0k\xa4\x86\x84\x88\x82" """""'),
]
# fmt: on


@pytest.mark.parametrize(
    ("str_uuid", "expected", "expected_encoded", "expected_serialised"),
    UUIDS,
)
class TestCuuid:
    def test_unserialise(self, str_uuid: str, expected: list[str], expected_encoded: str, expected_serialised: bytes) -> None:
        serialised = decode(str_uuid)
        result = [str(u) for u in unserialise(serialised)]
        assert result == expected

    def test_encode(self, str_uuid: str, expected: list[str], expected_encoded: str, expected_serialised: bytes) -> None:
        serialised = decode(str_uuid)
        result = encode(serialised)
        assert result == expected_encoded

    def test_serialise(self, str_uuid: str, expected: list[str], expected_encoded: str, expected_serialised: bytes) -> None:
        serialised = decode(str_uuid)
        assert serialised == expected_serialised


# fmt: off
DATA_BYTES = [
    (b"", b""),
    (b"x", b"x"),
    (b"foo", b"foo"),
    (b"hello", b"hello"),
    (b"\xff\xfe", b"\xff\xfe"),
    (b"\x01\x02\x03", b"\x01\x02\x03"),
    (b"a" * 15, b"a" * 15),
]
# fmt: on


class TestUUIDDataBytes:
    @pytest.mark.parametrize("data_bytes", [d[0] for d in DATA_BYTES])
    def test_roundtrip(self, data_bytes: bytes) -> None:
        u = UUID(data=data_bytes)
        assert u.data() == data_bytes

    @pytest.mark.parametrize("data_str", ["", "x", "foo", "hello", "a" * 15])
    def test_str_and_bytes_equivalent(self, data_str: str) -> None:
        u_str = UUID(data=data_str)
        u_bytes = UUID(data=data_str.encode("utf-8"))
        assert u_str == u_bytes

    def test_too_long_raises(self) -> None:
        with pytest.raises(ValueError, match="15 bytes"):
            UUID(data=b"a" * 16)

    def test_non_utf8_bytes_roundtrip(self) -> None:
        data = bytes(range(1, 16))
        u = UUID(data=data)
        assert u.data() == data
