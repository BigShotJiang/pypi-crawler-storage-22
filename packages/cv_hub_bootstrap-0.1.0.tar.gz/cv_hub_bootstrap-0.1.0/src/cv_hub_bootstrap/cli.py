"""Bootstrapper for installing and running locked cv-hub components.

This module installs exact versions of a small set of packages from a
Forgejo-based package index, with PyPI as a fallback extra index.

Environment variables:
    CVHUB_INDEX_URL: Overrides the primary (Forgejo) simple index URL.
    CVHUB_EXTRA_INDEX_URL: Overrides the extra (PyPI) simple index URL.
"""

from __future__ import annotations

import os
import subprocess
import sys

FORGEJO_SIMPLE_DEFAULT = "https://git.mystrotamer.com/api/packages/cv-hub/pypi/simple"
PYPI_SIMPLE_DEFAULT = "https://pypi.org/simple"

# Contract: lock versions here.
LOCKED = {
    "cv-hub": "0.1.0",
    "cv-hub-editor": "0.1.0",
    "cv-hub-api": "0.1.0",
}


def _indexes() -> tuple[str, str]:
    """Return the primary and extra package indexes.

    The returned values can be overridden via environment variables.

    Returns:
        tuple[str, str]: A pair of (index_url, extra_index_url).
    """

    forgejo = os.getenv("CVHUB_INDEX_URL", FORGEJO_SIMPLE_DEFAULT)
    pypi = os.getenv("CVHUB_EXTRA_INDEX_URL", PYPI_SIMPLE_DEFAULT)
    return forgejo, pypi


def _pip_install_exact(name: str) -> None:
    """Install an exact locked version of a package using pip.

    Args:
        name (str): The package name. Must exist in the LOCKED mapping.

    Returns:
        None

    Notes:
        This function raises a KeyError if the package is not present in LOCKED.
        It raises subprocess.CalledProcessError if pip fails.
    """

    ver = LOCKED[name]
    index_url, extra_index_url = _indexes()

    cmd = [
        sys.executable,
        "-m",
        "pip",
        "install",
        "--upgrade",
        "--index-url",
        index_url,
        "--extra-index-url",
        extra_index_url,
        f"{name}=={ver}",
    ]
    subprocess.check_call(cmd)


def setup() -> None:
    """Install all locked packages in a deterministic bootstrap order.

    Returns:
        None
    """

    _pip_install_exact("cv-hub")
    _pip_install_exact("cv-hub-editor")
    _pip_install_exact("cv-hub-api")


def run_api() -> None:
    """Run the cv-hub API CLI, installing dependencies if missing.

    This function attempts to import the API package. If import fails for any
    reason, it calls setup() to install the locked packages, then runs the
    ``cv-hub-api`` command, forwarding any extra CLI arguments.

    Returns:
        None

    Raises:
        SystemExit: Always exits with the return code from the subprocess.
    """

    try:
        import cv_hub_api  # noqa: F401
    except Exception:
        setup()

    raise SystemExit(subprocess.call(["cv-hub-api", *sys.argv[1:]]))
