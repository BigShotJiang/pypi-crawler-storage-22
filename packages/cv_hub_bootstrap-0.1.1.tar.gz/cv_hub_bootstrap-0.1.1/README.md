# cv-hub-bootstrap

Governed bootstrap installer for cv-hub toolchain.
This is a runner package, not a library.

## Install
pip install -U cv-hub-bootstrap

## Setup
cv-hub-setup

## Run
cv-hub-api
