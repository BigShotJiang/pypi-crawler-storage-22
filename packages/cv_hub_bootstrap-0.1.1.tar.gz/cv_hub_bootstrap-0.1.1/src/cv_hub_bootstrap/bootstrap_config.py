# -----------------------------
# Bootstrap configuration
# -----------------------------

INDEX_URL = "https://git.mystrotamer.com/api/packages/cv-hub/pypi/simple"

LOCKED_PACKAGES = {
    "cv-hub": "0.1.0",
    "cv-hub-editor": "0.1.0",
    "cv-hub-api": "0.1.0",
}
