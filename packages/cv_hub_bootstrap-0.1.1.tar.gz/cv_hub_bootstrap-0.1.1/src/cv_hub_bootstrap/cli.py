from __future__ import annotations

import subprocess
import sys

from cvhub_bootstrap_config import INDEX_URL, LOCKED_PACKAGES


def _pip_install_exact(name: str, version: str) -> None:
    subprocess.check_call(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--index-url",
            INDEX_URL,
            f"{name}=={version}",
        ]
    )


def setup() -> None:
    for name, version in LOCKED_PACKAGES.items():
        _pip_install_exact(name, version)


def run(entrypoint: str) -> None:
    raise SystemExit(
        subprocess.call([entrypoint])
    )
