"""Tests for CVEasy."""
