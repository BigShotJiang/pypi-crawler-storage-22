"""Tests for CLI utilities."""
