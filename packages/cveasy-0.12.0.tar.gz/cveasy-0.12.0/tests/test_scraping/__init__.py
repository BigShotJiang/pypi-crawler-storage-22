"""Tests for web scraping."""
