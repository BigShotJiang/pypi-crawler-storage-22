"""Tests for storage layer."""
