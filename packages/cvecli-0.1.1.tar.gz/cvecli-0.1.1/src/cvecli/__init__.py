"""cvecli - CLI tool for downloading, extracting, and searching CVE data."""

__version__ = "0.1.1"

# Manifest schema version - increment when parquet structure changes
# This must match the version in cvecli-db
MANIFEST_SCHEMA_VERSION = 1
