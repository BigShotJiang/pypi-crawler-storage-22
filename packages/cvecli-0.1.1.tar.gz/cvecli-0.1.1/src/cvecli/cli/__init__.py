"""CLI module for cvecli."""
