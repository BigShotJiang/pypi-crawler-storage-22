"""Tests for the CVE analyzer."""
