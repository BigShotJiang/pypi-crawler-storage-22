"""Unit tests package for CLI."""
