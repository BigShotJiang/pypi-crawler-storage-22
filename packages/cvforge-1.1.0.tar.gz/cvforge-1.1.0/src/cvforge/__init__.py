"""
CVForge - ATS-friendly CV/Resume generator using YAML and Typst.
"""

__version__ = "1.1.0"
