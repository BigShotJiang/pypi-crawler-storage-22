# SPDX-License-Identifier: LGPL-2.1-or-later

"""Tool which encrypts OS disk images and seals the key to the target TPM."""

import argparse
import sys
import secrets
import string
import json
import re
import os
import base64
import time
import shutil
import stat
import ctypes
import uuid
from cvmutils.efi import bootchains_from_shim_fallback
from cvmutils.partitions import Partitions
from cvmutils.pcr import PCR
from cvmutils.sb import SecureBoot
from cvmutils.tools import run_command

LUKSADD_PARAMS = ["-q", "--pbkdf", "pbkdf2", "--pbkdf-force-iterations", "1000"]

# pylint: disable=too-many-locals, too-many-branches, too-many-statements

def check_dependencies(binaries: list, is_hard_dependency: bool = True):
    """ Check if the given binaries are present in $PATH """
    for binary in binaries:
        if not shutil.which(binary):
            if is_hard_dependency:
                raise RuntimeError(f"The required '{binary}' binary is not preset in PATH")
            print(f"'{binary}' binary is not preset in PATH, continuing without it")

def is_sha265(value):
    """ Checks whether value is a valid sha256 hash """
    match = re.match(r'^(0x|)\w{64}$', str(value))
    return match is not None

def randpw(length):
    """ Generates a random password of a given length """
    return ''.join([secrets.choice(string.ascii_letters + string.digits) for k in range(length)])

def connect_nbd(args):
    """ Connects image file using qemu-nbd """
    run_command(["modprobe", "nbd"], canfail=True)
    if args.image.endswith(".qcow2"):
        imageformat = "qcow2"
    elif args.image.endswith(".vhd"):
        imageformat = "vpc"
    elif args.image.endswith(".raw"):
        imageformat = "raw"
    else:
        print("Unknown image format, assuming VHD")
        imageformat = "vpc"

    run_command(["qemu-nbd", "-f", imageformat, "-c", f"/dev/nbd{args.nbddev}", args.image], True)
    run_command(["udevadm", "settle"], True)
    time.sleep(1)
    return f"/dev/nbd{args.nbddev}"

def disconnect_nbd(args):
    """ Disconnects image file from qemu-nbd """
    run_command(["qemu-nbd", "-d", f"/dev/nbd{args.nbddev}"])

def connect_image(args):
    """ Connects image file """
    mode = os.stat(args.image).st_mode
    if not stat.S_ISBLK(mode):
        return connect_nbd(args)
    return args.image

def disconnect_image(args):
    """ Disconnects image file """
    mode = os.stat(args.image).st_mode
    if not stat.S_ISBLK(mode):
        disconnect_nbd(args)

def sdelete(path):
    """ Securely remove a file by wiping it first """
    with os.fdopen(os.open(path, os.O_RDWR), 'wb+') as fd:
        length = fd.seek(0, os.SEEK_END)
        fd.seek(0)
        fd.write(secrets.token_bytes(length))
        fd.flush()
        os.fsync(fd.fileno())

    os.remove(path)

def encrypt(args):
    """ Encrypt the given image """
    retval = 1
    imageblk = connect_image(args)
    tempdir = None
    try:
        check_dependencies(['mktemp', 'mkdir', 'mount', 'umount', 'rm', 'blkid', 'cryptsetup'])
        check_dependencies(['sfdisk', 'e2fsck', 'resize2fs'], False)

        res = run_command(["mktemp", "-d"])
        tempdir = res.stdout[:-1]

        print("Checking image partitions...")
        pt = Partitions(imageblk)

        print("Adjusting root file system size to accommodate for LUKS metadata...")
        pt.make_space_for_luks('root', args.growpart)

        # Use root partition UUID as a temporary cleartext password
        lukspw = pt.get_uuid('root')
        if args.verbose:
            print(f"Cleartext pw is: {lukspw}")

        # Create cloud-init root volume resize key
        if not args.no_cloud_init:
            cloudinitpw = randpw(32)
            if args.verbose:
                print(f"Cloud-init root volume resize key is: {cloudinitpw}")

            print("Creating cloud-init root volume resize key in /cc_growpart_keydata...")
            cc_slot_id = 1
            run_command(["mkdir", f"{tempdir}/root"])
            run_command(["mount", pt.get_path('root'), f"{tempdir}/root"])
            run_command(["mkdir", f"{tempdir}/esp"])
            run_command(["mount", pt.get_path('esp'), f"{tempdir}/esp"])
            # Cloud-init volume resize key needs to be placed to /cc_growpart_keydata
            with open(f"{tempdir}/root/cc_growpart_keydata", 'w', encoding='ascii') as fd:
                keydata = {"key": base64.b64encode(cloudinitpw.encode('ascii')).decode('ascii'),
                           "slot": cc_slot_id}
                if args.verbose:
                    print(f"cloud-init root volume resize /cc_growpart_keydata data: {keydata}")
                fd.write(json.dumps(keydata))

            with open(f"{tempdir}/esp/cc_growpart_keydata", 'w', encoding='ascii') as fd:
                keydata = {"key": base64.b64encode(cloudinitpw.encode('ascii')).decode('ascii'),
                           "slot": cc_slot_id}
                fd.write(json.dumps(keydata))
            os.chmod(f"{tempdir}/root/cc_growpart_keydata", stat.S_IRUSR | stat.S_IWUSR)
            run_command(["umount", f"{tempdir}/root"])

        progress_args = []
        if args.encrypt_progress_json:
            progress_args += ["--progress-json"]

        print("Running reencryption...")
        run_command(["cryptsetup", "reencrypt", "--encrypt", "-v", "-q", "--type", "luks2",
                     "--key-file", "-", "--luks2-metadata-size", "512k", "--luks2-keyslots-size",
                     "16384k", "--reduce-device-size", "32768k", "--uuid", pt.get_uuid('root')]
                    + progress_args + [pt.get_path('root')],
                    input=lukspw, output=args.encrypt_progress_json)

        print("Pre-encryption done!")
        retval = 0
    # pylint: disable=broad-exception-caught
    except Exception as e:
        print(e)
    finally:
        if tempdir:
            run_command(["umount", f"{tempdir}/root"], canfail=True)
            run_command(["umount", f"{tempdir}/esp"], canfail=True)
            run_command(["rm", "-r", "-f", tempdir], canfail=True)
        disconnect_image(args)
    return retval

def encrypt_resume(args):
    """ Resume encrypting the given image """
    retval = 1
    imageblk = connect_image(args)
    try:
        check_dependencies(['mktemp', 'mkdir', 'mount', 'umount', 'rm', 'blkid', 'cryptsetup'])

        print("Checking image partitions...")
        pt = Partitions(imageblk)

        # Root partition UUID is the temporary cleartext password
        lukspw = pt.get_uuid('root')
        if args.verbose:
            print(f"Cleartext pw is: {lukspw}")

        progress_args = []
        if args.encrypt_progress_json:
            progress_args += ["--progress-json"]

        print("Resuming reencryption...")
        run_command(["cryptsetup", "reencrypt", "--encrypt", "-v", "-q", "--resume-only"]
                    + progress_args + [pt.get_path('root')],
                    input=lukspw, output=args.encrypt_progress_json)

        print("Pre-encryption done!")
        retval = 0
    # pylint: disable=broad-exception-caught
    except Exception as e:
        print(e)
    finally:
        disconnect_image(args)
    return retval

def deploy(args):
    """ Seal the key to the given image to the target TPM """
    retval = 1
    tempdir = None
    imageblk = connect_image(args)
    try:
        check_dependencies(['mktemp', 'mkdir', 'mount', 'umount', 'rm', 'blkid', 'cryptsetup', 'systemd-cryptenroll', 'openssl'])

        print("Checking image partitions...")
        pt = Partitions(imageblk)

        # Root partition UUID is the temporary cleartext password
        lukspw = pt.get_uuid('root')
        if args.verbose:
            print(f"Cleartext pw is: {lukspw}")

        res = run_command(["mktemp", "-d"])
        tempdir = res.stdout[:-1]

        # Mount ESP
        run_command(["mkdir", f"{tempdir}/esp"])
        run_command(["mount", pt.get_path('esp'), f"{tempdir}/esp"])

        pcrs_list = []
        pcrs_list_unique = []
        if args.pcr4 == 'auto' or args.pcr7 == 'auto':

            sb = SecureBoot(args.nosecureboot)
            if args.efivars_profile:
                sb.load_uefi_from_efivars(args.efivars_profile, args.efivars_profile_no_attrs)
            elif args.uefi_profile:
                sb.load_uefi_from_uefi_profile(args.uefi_profile)
            elif args.az_disk_profile:
                sb.load_uefi_from_azdisk_profile(args.az_disk_profile)
            elif args.pcr7 == 'auto':
                raise RuntimeError("Efivars, UEFI, or Azure disk profile is required for PCR7 prediction")

            for bootchain in bootchains_from_shim_fallback(f"{tempdir}/esp"):
                pcrs = {'bank': 'sha256',
                        'pcrs': []}

                print("Boot chain:", f"shim: {bootchain['shim'].split('/')[-1]}",
                      f"bootloader: {bootchain['bootloader'].split('/')[-1] if bootchain['bootloader'] is not None else ''}",
                      f"uki: {bootchain['uki'].split('/')[-1] if bootchain['uki'] is not None else ''}")
                predictor = PCR(bootchain, sb, args.verbose)

                if args.pcr4:
                    pcrs['pcrs'].append(4)
                    if args.pcr4 != 'auto':
                        pcrs['4'] = args.pcr4
                    else:
                        pcrs['4'] = predictor.predicted_pcr4()
                        print(f"Predicted PCR4 value: {pcrs['4'][2:].lower()}")

                if args.pcr7:
                    pcrs['pcrs'].append(7)
                    if args.pcr7 != 'auto':
                        pcrs['7'] = args.pcr7
                    else:
                        pcrs['7'] = predictor.predicted_pcr7()
                        print(f"Predicted PCR7 value: {pcrs['7'][2:].lower()}")

                pcrs['pcrs'].sort()
                pcrs_list.append(pcrs)

                if args.verbose:
                    print(f"Expected PCR values: {pcrs}")
        else:
            # No prediction is needed, use static values is supplied
            pcrs = {'bank': 'sha256',
                    'pcrs': []}
            if args.pcr4:
                pcrs['pcrs'].append(4)
                pcrs['4'] = args.pcr4
            if args.pcr7:
                pcrs['pcrs'].append(7)
                pcrs['7'] = args.pcr7
            pcrs_list_unique.append(pcrs)

        for pcrs in pcrs_list:
            if not pcrs in pcrs_list_unique:
                pcrs_list_unique.append(pcrs)

        if len(pcrs_list_unique) > 16:
            print("WARNING: too many boot options detected, using the last 16!")
            pcrs_list_unique = pcrs_list_unique[-16:]

        # Check if efivars.json needs to be handled
        if pt.exists('efivars'):
            if os.path.exists(f"{tempdir}/esp/efivars.json"):
                with open(pt.get_path('efivars'), "wb") as f:
                    print(f"Writing EFI variables from efivars.json to {pt.get_path('efivars')}")
                    if args.verbose:
                        fstat = os.stat(f"{tempdir}/esp/efivars.json")
                        print(f"efivars.json size is {fstat.st_size}")
                    f.write(ctypes.c_uint32(os.stat(f"{tempdir}/esp/efivars.json").st_size))
                    with open(f"{tempdir}/esp/efivars.json", "rb") as efivars_f:
                        f.write(efivars_f.read())
            else:
                print(f"efivars.json not found in ESP, skipping writing EFI variables to {pt.get_path('efivars')}")
        else:
            if args.verbose:
                print("Can't find a partition to write EFI variables, skipping")

        # Create recovery keyslot
        if args.recovery_key:
            keylength = os.path.getsize(args.recovery_key)
            if keylength == 0:
                raise RuntimeError("Invalid zero-length keyfile")

            if args.recovery_key_type in ['binary', 'both']:
                print(f"Adding recovery keyslot from {args.recovery_key} (binary)")
                run_command(["cryptsetup", "luksAddKey"] + LUKSADD_PARAMS + ["--key-file", "-",
                            pt.get_path('root'), args.recovery_key], input=lukspw)
            if args.recovery_key_type in ['text', 'both']:
                if keylength % 2 != 0:
                    raise RuntimeError(f"Invalid keylength for text keytype: {keylength}")

                print(f"Adding text recovery keyslot from {args.recovery_key} (text)")
                textkey = ""
                with open(args.recovery_key, 'rb') as f:
                    while True:
                        byte2 = f.read(2)
                        if len(byte2) != 2:
                            break
                        textkey += f"{int.from_bytes(byte2, 'little'):05}-"
                textkey=textkey[:-1]
                if args.verbose:
                    print(f"Recovery text key {textkey}")
                with open(tempdir + '/recoverytext', 'w', encoding='ascii') as f:
                    f.write(textkey)
                run_command(["cryptsetup", "luksAddKey"] + LUKSADD_PARAMS + ["--key-file", "-",
                            pt.get_path('root'), tempdir + '/recoverytext'], input=lukspw)

        # Seal the key to the target TPM
        with open(tempdir + '/lukspw', 'w', encoding='ascii') as fd:
            fd.write(lukspw)

        if os.path.exists(f"{tempdir}/esp/cc_growpart_keydata"):
            with open(f"{tempdir}/esp/cc_growpart_keydata", encoding='ascii') as fd:
                keydata = json.loads(fd.read())
                print("Adding cloud-init root volume resize keyslot", keydata['slot'])
                with open(tempdir + '/cloudinitpw', 'w', encoding='ascii') as fdd:
                    print("keydata['key']", keydata['key'])
                    cloudinitkey = base64.b64decode(keydata['key']).decode('ascii')
                    if args.verbose:
                        print(f"Cloud-init key is {cloudinitkey}")
                    fdd.write(cloudinitkey)

                run_command(["cryptsetup", "luksAddKey"] + LUKSADD_PARAMS + ["--key-file", "-",
                            "--key-slot", str(keydata['slot']), pt.get_path('root'), tempdir + '/cloudinitpw'], input=lukspw)
            # Wipe and remove
            sdelete(f"{tempdir}/esp/cc_growpart_keydata")

        print("Sealing root volume key with systemd-cryptenroll")
        for pcrs in pcrs_list_unique:
            run_command(["systemd-cryptenroll", pt.get_path('root'), "--tpm2-device-key=" + args.srkpub,
                         "--tpm2-pcrs=" + '+'.join(str(key) + ':' + pcrs['bank'] + '=' + pcrs[str(key)] for key in pcrs['pcrs']),
                         "--unlock-key-file=" + tempdir + '/lukspw'])

        # Remove cleartext password
        run_command(["cryptsetup", "luksRemoveKey", "--key-file", "-", pt.get_path('root')], input=lukspw)

        print("Deployment done!")
        retval = 0

    # pylint: disable=broad-exception-caught
    except Exception as e:
        print(e)
    finally:
        if tempdir:
            run_command(["umount", f"{tempdir}/esp"], canfail=True)
            run_command(["rm", "-r", "-f", tempdir], canfail=True)
        disconnect_image(args)
    return retval

def makeverity(args):
    """ Protect the image with dm-verity """
    retval = 1
    imageblk = connect_image(args)
    tempdir = None
    try:
        check_dependencies(['mktemp', 'mkdir', 'mount', 'umount', 'rm', 'blkid', 'ukify', 'sfdisk', 'veritysetup'])

        res = run_command(["mktemp", "-d"])
        tempdir = res.stdout[:-1]

        print("Checking image partitions...")
        pt = Partitions(imageblk)

        if pt.exists('root-verity'):
            print("Verity partition for root already exists, skipping")
            return 2

        print("Creating verity partition...")
        verity_hash = pt.make_verity('root')

        print("Created verity hash is ", verity_hash)

        digest = bytearray.fromhex(verity_hash)
        uuid1 = uuid.UUID(bytes=bytes(digest[0:16]))
        uuid2 = uuid.UUID(bytes=bytes(digest[16:32]))
        pt.change_uuid('root', str(uuid1))
        pt.change_uuid('root-verity', str(uuid2))

        run_command(["mkdir", f"{tempdir}/esp"])
        run_command(["mount", pt.get_path('esp'), f"{tempdir}/esp"])
        run_command(["mkdir", f"{tempdir}/esp/loader/addons"], canfail=True)
        # Create UKI addon
        cmdline=f"roothash={verity_hash} systemd.verity_root_options=panic-on-corruption"
        if args.volatile_overlay:
            cmdline+=" systemd.volatile=overlay"

        run_command(["ukify", "build", f"--secureboot-private-key={args.secureboot_key}", f"--secureboot-certificate={args.secureboot_cert}",
                     "--cmdline", cmdline, f"--output={tempdir}/esp/loader/addons/roothash.addon.efi"])

        retval = 0
    # pylint: disable=broad-exception-caught
    except Exception as e:
        print(e)
    finally:
        if tempdir:
            run_command(["umount", f"{tempdir}/esp"], canfail=True)
            run_command(["rm", "-r", "-f", tempdir], canfail=True)
        disconnect_image(args)
    return retval


def main():
    """ Main runner """
    parser = argparse.ArgumentParser(description='Prepare OS Image for Confidential Environments')
    parser.add_argument('action', choices=['encrypt', 'encrypt-resume', 'deploy', 'makeverity'], help='Main action')
    parser.add_argument('image', help='image file (VHD, QCOW2) or a block device')
    parser.add_argument('-n', '--nbddev', type=int, default=0, help='NBD device number, defaults to 0')
    parser.add_argument('-v', '--verbose', help='Print additional info', action="store_true")
    parser.add_argument('--no-cloud-init', help='Do not create /cc_growpart_keydata and LUKS keyslot for root volume resize (encrypt only)', action="store_true")
    parser.add_argument('--encrypt-progress-json', help='Write encryption progress to a file or use "-" for stdout ("cryptsetup-reencrypt --progress-json", encrypt/encrypt-resume only)')
    parser.add_argument('-g', '--growpart', help='Grow root partition to the size of the volume (encrypt only)', action="store_true")
    parser.add_argument('-s', '--srkpub', help='SRK public part (\'systemd-analyze srk\', deploy only)')
    parser.add_argument('-u', '--srkunique', help='DEPRECATED')
    parser.add_argument('-r', '--recovery-key', help='Recovery key file (deploy only, adds an additional passphrase to root volume)')
    parser.add_argument('--recovery-key-type', choices=['binary', 'text', 'both'], default='binary', help='Recovery key type')
    parser.add_argument('--noswtpm', help='DEPRECATED', action="store_true")
    parser.add_argument('--pcr4',help='Expected PCR4 sha256 value for root volume key sealing (deploy only, sha256 or "auto")')
    parser.add_argument('--pcr7', help='Expected PCR7 sha256 value for root volume key sealing (deploy only, sha256 or "auto")')
    parser.add_argument('--nosecureboot', default=False, help='Do PCR prediction with SecureBoot disabled (deploy only)', action="store_true")
    parser.add_argument('--pcrs-json', help='DEPRECATED')
    profile_group = parser.add_mutually_exclusive_group()
    profile_group.add_argument('--efivars-profile', help='UEFI profile (PK, KEK, db, dbx) efivars-format dir (e.g. /sys/firmware/efi/efivars)) for "--pcr7 auto" (deploy only)')
    profile_group.add_argument('--uefi-profile', help='UEFI profile (PK, KEK, db, dbx) JSON for "--pcr7 auto" (deploy only)')
    profile_group.add_argument('--az-disk-profile', help='Azure disk profile JSON for "--pcr7 auto" (deploy only)')
    parser.add_argument('--efivars-profile-no-attrs', help='The UEFI profile efivars-format files do not include the 4-byte attribute header (--efivars-profile only)', action="store_true")
    parser.add_argument('--seal-type', default='systemd', help='DEPRECATED')
    # makeverity specific args
    parser.add_argument('--secureboot-cert', help='SecureBoot certificate (PEM) to sign UKI addon (makeverity only)')
    parser.add_argument('--secureboot-key', help='SecureBoot key (PEM) to sign UKI addon (makeverity only)')
    parser.add_argument('--volatile-overlay', default=False, help='Add systemd.volatile=overlay to the UKI cmdline for read-write experience (makeverity only)', action="store_true")
    args = parser.parse_args()

    start = time.time()

    if args.action == 'encrypt':
        retval = encrypt(args)
    elif args.action == 'encrypt-resume':
        retval = encrypt_resume(args)
    elif args.action == 'deploy':
        try:
            if not args.srkpub:
                raise RuntimeError("Error: -s/--srkpub argument is mandatory for deployment!")
            if args.pcr4 and args.pcr4 != 'auto' and not is_sha265(args.pcr4):
                raise RuntimeError("Error: PCR4 value must be a valid SHA256 or 'auto'")
            if args.pcr7 and args.pcr7 != 'auto' and not is_sha265(args.pcr7):
                raise RuntimeError("Error: PCR7 value must be a valid SHA256 or 'auto'")
            if args.pcr7 == 'auto' and not any((args.efivars_profile, args.uefi_profile, args.az_disk_profile)):
                raise RuntimeError("Error: '--efivars-profile'/'--uefi-profile'/'--az-disk-profile' must be specified for '--pcr7 auto'")
            if args.pcr7 != 'auto' and any((args.efivars_profile, args.uefi_profile, args.az_disk_profile)):
                raise RuntimeError("Error: '--efivars-profile'/'--uefi-profile'/'--az-disk-profile' can only be used with '--pcr7 auto'")

            if args.seal_type != 'systemd':
                print("WARNING: --seal-type argument is deprecated, only systemd-style sealing is done.")

        # pylint: disable=broad-exception-caught
        except Exception as e:
            print(e, file=sys.stderr)
            sys.exit(1)
        retval = deploy(args)
    elif args.action == 'makeverity':
        if not args.secureboot_key:
            raise RuntimeError("Error: --secureboot-key argument is mandatory for makeverity!")
        if not args.secureboot_cert:
            raise RuntimeError("Error: --secureboot-cert argument is mandatory for makeverity!")
        retval = makeverity(args)
    else:
        raise RuntimeError(f"Unknown action {args.action}")

    end = time.time()

    if retval == 0:
        print(f"{args.action} was successful and took {end-start:.6f} seconds")
    else:
        print(f"{args.action} failed, retval={retval}")

    sys.exit(retval)

if __name__ == '__main__':
    main()
