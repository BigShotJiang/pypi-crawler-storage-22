# SPDX-License-Identifier: LGPL-2.1-or-later

""" Work with partitions """

import json
import re
import shutil
from cvmutils.tools import run_command

def div_round_up(n, d):
    """ Divide and round up """
    return (n + d - 1) // d

def calculate_verity_hash_size(data_bytes, hash_block_size, data_block_size, digest_size):
    """
    Calculates the size of a dm-verity hash partition's contents.
    Stolen from: https://github.com/systemd/systemd/blob/main/src/repart/repart.c
    """

    data_blocks = div_round_up(data_bytes, data_block_size)

    # 2. Hashes that fit in one hash block (node in the merkle tree)
    hashes_per_hash_block = hash_block_size // digest_size

    # 3. Initialize with 2 blocks:
    # - 1 block for the root of the merkle tree
    # - 1 block for the dm-verity superblock
    hash_blocks = 2

    # 4. Iterate through the levels of the merkle tree bottom up
    remaining_blocks = data_blocks

    while remaining_blocks > hashes_per_hash_block:
        # Number of hash blocks required to reference the underlying blocks
        hash_blocks_for_level = div_round_up(remaining_blocks, hashes_per_hash_block)

        # Add current layer to the total number of hash blocks
        hash_blocks += hash_blocks_for_level

        # Hashes on this level serve as the blocks on which the next level is built
        remaining_blocks = hash_blocks_for_level

    # 5. Calculate total bytes
    total_bytes = hash_blocks * hash_block_size

    return total_bytes

def partition_exists(func):
    """ Decorator to check if the particular partition was discovered """
    def wrapper(self, part: str, *args, **kwargs):
        if not self.exists(part):
            raise RuntimeError(f"{part} partition was not discovered")
        return func(self, part, *args, **kwargs)
    return wrapper

def disk_exists(func):
    """ Decorator to check if 'disk' information was discovered """
    def wrapper(self, *args, **kwargs):
        if not self.exists('disk'):
            raise RuntimeError("Disk information was not discovered")
        return func(self, *args, **kwargs)
    return wrapper

class Partitions:
    """ Image partition information and actions """
    partitions = {}

    def __init__(self, device: str):
        self.__get_partitions(device)

    def exists(self, part: str) -> bool:
        """ Does the partition exist ? """
        return part in self.partitions

    @partition_exists
    def get_uuid(self, part: str) -> str:
        """ Get partition UUID """
        return self.partitions[part]['uuid']

    @partition_exists
    def get_parttype(self, part: str) -> str:
        """ Get partition type """
        return self.partitions[part]['parttype']

    @partition_exists
    def get_path(self, part: str) -> str:
        """ Get partition device path """
        return self.partitions[part]['path']

    # pylint: disable=too-many-branches
    def __get_partitions(self, device: str):
        """ Gets partitions information """
        partitions = {'disk': {}, 'esp': {}, 'root': {}}

        res = run_command(['sfdisk', '-J', device])
        sfdisk = json.loads(res.stdout)
        if not 'partitiontable' in sfdisk:
            raise RuntimeError("Unexpected 'sfdisk' output")
        pt = sfdisk['partitiontable']
        if pt['label'] != 'gpt':
            raise RuntimeError(f"{pt['label']} partitioning is unsupported")

        partitions['disk']['path'] = pt['device']
        partitions['disk']['uuid'] = pt['id']
        partitions['disk']['sectorsize'] = pt['sectorsize']
        partitions['disk']['uuid'] = pt['id']
        partitions['disk']['start'] = pt['firstlba']
        partitions['disk']['end'] = pt['lastlba']
        partitions['disk']['size'] = (pt['lastlba'] + 1) * pt['sectorsize']
        partitions['disk']['type'] = 'disk'

        partn = 1
        for part in pt['partitions']:
            newpart = {}
            newpart['path'] = part['node']
            newpart['start'] = part['start']
            newpart['end'] = part['start'] + part['size'] - 1
            newpart['size'] = part['size'] * partitions['disk']['sectorsize']
            newpart['parttype'] = part['type'].lower()
            newpart['uuid'] = part['uuid'].lower()
            newpart['type'] = 'part'
            match_pn = re.search(r'\d+$', part['node'])
            if match_pn:
                newpart['partn'] = int(match_pn.group(0))
                if newpart['partn'] != partn:
                    print(f"Partition {newpart['path']} does not have the expected number {partn}")
            else:
                print(f"Assuming partition {newpart['path']} has partition number {partn}")
                newpart['partn'] = partn

            if newpart['parttype'] == 'c12a7328-f81f-11d2-ba4b-00a0c93ec93b':
                partitions['esp'] = newpart
            elif newpart['parttype'] == '4f68bce3-e8cd-4db1-96e7-fbcaf984b709':
                partitions['root'] = newpart
            elif newpart['parttype'] == 'd13c5d3b-b5d1-422a-b29f-9454fdc89d76':
                partitions['root-verity'] = newpart
            elif newpart['parttype'] == '8da63339-0007-60c0-c436-083ac8230908':
                # 'Linux reserved' partition at 1M offset, used for uefi variables on Azure
                partitions['efivars'] = newpart
            else:
                partitions[newpart['uuid']] = newpart
            partn += 1

        if not partitions['esp']:
            raise RuntimeError("Image doesn't contain 'EFI System' partition")
        if not partitions['root']:
            raise RuntimeError("Image doesn't contain 'Linux root (x86-64)' partition")
        self.partitions = partitions

    @partition_exists
    def get_partnumber(self, part: str):
        """ Gets partition number """
        return self.partitions[part]['partn']

    @partition_exists
    def get_start(self, part: str) -> int:
        """ Get partition start secrot """
        return self.partitions[part]['start']

    @partition_exists
    def get_end(self, part: str) -> int:
        """ Get partition end sector """
        return self.partitions[part]['end']

    @partition_exists
    def get_size(self, part: str) -> int:
        """ Get partition size """
        return self.partitions[part]['size']

    @disk_exists
    def get_sec_size(self) -> int:
        """ Get logical sector size """
        return self.partitions['disk']['sectorsize']

    @disk_exists
    def get_free_space(self) -> int:
        """ Get free space on the disk """
        last_end = 0
        for part, pdesc in self.partitions.items():
            if pdesc['type'] == 'disk':
                continue
            if pdesc['type'] != 'part':
                print(f"Unknown partition type {pdesc['type']}, skipping")
            last_end = max(last_end, self.get_end(part))

        if last_end > self.get_end('disk'):
            print("Disk is smaller than the end of the last partition, this is weird")
            return 0

        return (self.get_end('disk') - last_end) * self.get_sec_size()

    @partition_exists
    def is_last(self, part: str) -> bool:
        """ Check if the partition is the last one on the disk """
        part_end = self.get_end(part)
        for pt, pdesc in self.partitions.items():
            if pt == part or pdesc['type'] == 'disk':
                continue
            if self.get_end(pt) > part_end:
                return False
        return True

    @partition_exists
    @disk_exists
    def grow(self, part: str, grow_by: int):
        """ Grow partition by grow_by bytes or to the size of the disk (grow_by=0) """
        if not self.is_last(part):
            print(f"Partition {part} is not the last one, refusing to grow.")
            return

        if not shutil.which('sfdisk'):
            print(f"'sfdisk' is not present, cannot grow {part}.")
            return

        pn = self.get_partnumber(part)
        if not pn:
            raise RuntimeError("Failed to find root partition number!")

        growsize = self.get_free_space()
        if growsize < self.get_sec_size():
            print(f"No free space to grow {part}, skipping.")
            return

        start = self.get_start(part)
        max_end = self.get_end('disk')
        if grow_by == 0:
            print(f"Growing {part} to the disk size")
            end = max_end
        else:
            print(f"Growing {part} by {grow_by} bytes")
            end = self.get_end(part) + div_round_up(grow_by, self.get_sec_size())
            if end > max_end:
                raise RuntimeError(f"Partition {part} can't be grown by {grow_by} bytes")

        cmd_grow = f"{start},{end - start + 1},{self.get_parttype(part)}"
        run_command(['sfdisk', self.get_path('disk'), '-N', str(self.get_partnumber(part))], input=cmd_grow)
        self.__get_partitions(self.get_path('disk'))

    @partition_exists
    @disk_exists
    def shrink(self, part: str, shrink_by: int):
        """ Shrink existing partition """
        if self.get_size(part) < shrink_by:
            raise RuntimeError(f"Partition {part} is too small to be shrinked by {shrink_by} bytes")

        start = self.get_start(part)

        print(f"Shrinking {part} by {shrink_by} bytes")
        end = self.get_end(part) - div_round_up(shrink_by, self.get_sec_size())

        cmd_shrink = f"{start},{end - start + 1},{self.get_parttype(part)}"
        run_command(['sfdisk', self.get_path('disk'), '-N', str(self.get_partnumber(part))], input=cmd_shrink)
        self.__get_partitions(self.get_path('disk'))

    @partition_exists
    def check_fs(self, part: str):
        """ Do fsck for a partition """
        res = run_command(['e2fsck', '-f', '-y', self.get_path(part)], canfail=True)
        if res.returncode not in [0, 1, 2]:
            raise RuntimeError(f"e2fsck failed with error code {res.returncode}")

    @partition_exists
    def resize_fs(self, part: str, size: int, shrink: bool):
        """ Shrink/grow filesystem to 'size' """
        res = run_command(['blkid', self.get_path(part)])
        match_type = re.search(r'TYPE="([^"]*)"', res.stdout)
        if not match_type:
            raise RuntimeError(f"Cannot determine the filesystem type for {part}")
        fstype = match_type.group(1)

        if fstype != 'ext4':
            if shrink:
                raise RuntimeError(f"Shrinking {fstype} is not supported.")

            print(f"Offline resize of {fstype} is not supported.")
            return

        if not shutil.which('e2fsck') or not shutil.which('resize2fs'):
            raise RuntimeError("Ext4 filesystemd resize is required but e2fsprogs are missing")

        if size <= 0:
            raise RuntimeError(f"Can't shrink {part} to {size} bytes")

        self.check_fs(part)
        run_command(['resize2fs', self.get_path(part), f"{int(size // 1024)}K"])

    @partition_exists
    def make_space_for_luks(self, part: str, grow: bool):
        """ Make space for LUKS header in the partition"""
        lukshsz = 32 * 1024 * 1024

        if self.is_last(part) and self.get_free_space() >= lukshsz and shutil.which('sfdisk'):
            # We have enough space in the disk, just resize the partition
            print(f"Volume has {self.get_free_space()} bytes after {part}, only need to grow the partition")
            self.grow(part, 0 if grow else lukshsz)
            self.resize_fs(part, self.get_size(part) - lukshsz, False)
        elif self.get_size(part) > lukshsz:
            # Not enough space on the disk, will need filesystem shrink
            print(f"Volume has only {self.get_free_space()} bytes after {part}, need to shrink the filesystem")
            if grow:
                self.grow(part, 0)

            self.resize_fs(part, self.get_size(part) - lukshsz, True)
        else:
            raise RuntimeError(f"Can't free up space for LUKS header in {part} partition")

    @partition_exists
    @disk_exists
    def make_verity(self, part: str) -> str:
        """ Create dm-verity partition for part and return the expected hash """
        data_bs = 4096
        hash_bs = 4096
        digest_sz = 32

        verity_sz = calculate_verity_hash_size(self.get_size(part), data_bs, hash_bs, digest_sz)
        # round up to 1M boundary
        verity_part_sz = div_round_up(verity_sz, 1024 * 1024) * 1024 * 1024

        if self.is_last(part) and self.get_free_space() >= verity_part_sz:
            # We have enough space in the disk, just resize the partition
            print(f"Volume has {self.get_free_space()} bytes after {part}, can be used for verity")
        elif self.get_size(part) > verity_part_sz:
            # Not enough space on the disk, will need filesystem shrink
            print(f"Volume has only {self.get_free_space()} bytes after {part}, need to shrink the filesystem")
            self.resize_fs(part, self.get_size(part) - verity_part_sz, True)
            self.shrink(part, verity_part_sz)
        else:
            raise RuntimeError(f"Can't find free space for verity partition for {part}")

        # Create Linux-verity-x86_64 (D13C5D3B-B5D1-422A-B29F-9454FDC89D76) partition
        cmd_add = f",{div_round_up(verity_sz, self.get_sec_size())},d13c5d3b-b5d1-422a-b29f-9454fdc89d76"
        run_command(['sfdisk', '-a', self.get_path('disk')], input=cmd_add)
        self.__get_partitions(self.get_path('disk'))

        res = run_command(['veritysetup', 'format', '--data-block-size', str(data_bs), '--hash-block-size', str(hash_bs), self.get_path('root'), self.get_path('root-verity')])
        m = re.search(r"Root hash:\s+([a-fA-F0-9]+)", res.stdout)
        if m:
            return m.group(1)

        raise RuntimeError("Failed to get the root hash from veritysetup")

    @partition_exists
    @disk_exists
    def change_uuid(self, part: str, uuid: str):
        """ Change partition's UUID """
        run_command(['sfdisk', '--part-uuid', self.get_path('disk'), str(self.get_partnumber(part)), uuid])
