"""Hook scripts for auto-swap functionality."""
