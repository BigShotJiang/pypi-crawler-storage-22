from sqlalchemy import String, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ._base import Base
from .club import Club
from .meet import Meet
from .meet_attendee import MeetAttendee


class User(Base):
    __tablename__ = "users"

    # Clerk external auth ID
    clerk_id: Mapped[str] = mapped_column(
        String,
        unique=True,
        nullable=False,
        index=True
    )

    club_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("clubs.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    club: Mapped["Club"] = relationship(
        "Club", back_populates="users"
    )

    meets: Mapped[list["Meet"]] = relationship(
        "Meet", back_populates="user"
    )

    meet_attendances: Mapped[list["MeetAttendee"]] = relationship(
        "MeetAttendee", back_populates="user"
    )
