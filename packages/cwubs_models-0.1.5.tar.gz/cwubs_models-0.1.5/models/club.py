from typing import List, TYPE_CHECKING

from sqlalchemy.orm import Mapped, relationship

from ._base import Base

if TYPE_CHECKING:
    from .user import User
    from .meet import Meet


class Club(Base):
    __tablename__ = "clubs"

    users: Mapped[List["User"]] = relationship(
        "User", back_populates="club", passive_deletes=True
    )

    meets: Mapped[List["Meet"]] = relationship(
        "Meet", back_populates="club"
    )
