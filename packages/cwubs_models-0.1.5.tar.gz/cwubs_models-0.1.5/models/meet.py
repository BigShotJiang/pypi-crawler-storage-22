from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ._base import Base

if TYPE_CHECKING:
    from .club import Club
    from .meet_attendee import MeetAttendee
    from .user import User


class Meet(Base):
    __tablename__ = "meets"

    user_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False,
        index=True,
    )

    club_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("clubs.id"),
        nullable=False,
        index=True,
    )

    user: Mapped["User"] = relationship(
        "User", back_populates="meets"
    )

    club: Mapped["Club"] = relationship(
        "Club", back_populates="meets"
    )

    attendees: Mapped[list["MeetAttendee"]] = relationship(
        "MeetAttendee", back_populates="meet"
    )
