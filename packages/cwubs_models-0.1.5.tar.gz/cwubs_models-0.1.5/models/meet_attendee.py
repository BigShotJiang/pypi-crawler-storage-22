from typing import TYPE_CHECKING

from sqlalchemy import ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ._base import Base

if TYPE_CHECKING:
    from .meet import Meet
    from .user import User


class MeetAttendee(Base):
    __tablename__ = "meet_attendees"

    meet_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("meets.id"),
        nullable=False,
        index=True,
    )

    user_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False,
        index=True,
    )

    meet: Mapped["Meet"] = relationship(
        "Meet", back_populates="attendees"
    )

    user: Mapped["User"] = relationship(
        "User", back_populates="meet_attendances"
    )
