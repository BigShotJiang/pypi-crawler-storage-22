# CX Linux

AI-powered package manager for Debian/Ubuntu that understands natural language.

## Installation

```bash
pip install cx-linux
```

## Quick Start

```bash
# Interactive demo
cx demo

# System status
cx status

# Install packages using natural language
cx install "set up a web server with nginx and php"

# Ask questions about your system
cx ask "how much disk space is left?"
```

## Features

- 🧠 **Natural Language** - No exact syntax needed
- 🔍 **Plan Before Install** - Shows you what it will do first
- 🔒 **Hardware Checks** - Prevents incompatible installs
- 📦 **Universal** - Works with apt, brew, npm, pip...
- 🔄 **Safe Rollback** - Undo any installation

## Configuration

Run the setup wizard:
```bash
cx wizard
```

## Documentation

- [Full Documentation](https://docs.cxlinux.com)
- [GitHub](https://github.com/cxlinux-ai/cx-core)

## License

Apache 2.0
