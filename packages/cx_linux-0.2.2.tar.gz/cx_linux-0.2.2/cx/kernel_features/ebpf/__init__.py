"""eBPF integration for CX Linux kernel features."""
