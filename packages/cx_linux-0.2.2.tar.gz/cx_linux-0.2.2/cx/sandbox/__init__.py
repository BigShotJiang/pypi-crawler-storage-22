"""
CX Sandbox Module

Provides sandboxed execution environments for safe package testing.

- SandboxExecutor: Firejail-based command sandboxing
- DockerSandbox: Docker-based package testing environments
"""

from cx.sandbox.docker_sandbox import (
    DockerNotFoundError,
    DockerSandbox,
    SandboxAlreadyExistsError,
    SandboxExecutionResult,
    SandboxInfo,
    SandboxNotFoundError,
    SandboxState,
    SandboxTestResult,
    SandboxTestStatus,
    docker_available,
)
from cx.sandbox.sandbox_executor import CommandBlocked, ExecutionResult, SandboxExecutor

__all__ = [
    # Firejail sandbox
    "CommandBlocked",
    "ExecutionResult",
    "SandboxExecutor",
    # Docker sandbox
    "DockerNotFoundError",
    "DockerSandbox",
    "SandboxAlreadyExistsError",
    "SandboxExecutionResult",
    "SandboxInfo",
    "SandboxNotFoundError",
    "SandboxState",
    "SandboxTestResult",
    "SandboxTestStatus",
    "docker_available",
]
