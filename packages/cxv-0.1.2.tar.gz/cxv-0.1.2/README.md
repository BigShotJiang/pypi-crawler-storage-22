# cxv

CLI for CXV.ONE.

## Install

```bash
pip install cxv
```

## Login

```bash
cxv login --email you@example.com --password "..."
```

Or use a CLI token from Settings → Security:

```bash
cxv login --token cxv_cli_...
```

## Usage

```bash
cxv whoami
cxv projects list
cxv projects create --name "My Bot"
cxv projects get --project-id <project-id>
cxv projects archive --project-id <project-id>
cxv projects unarchive --project-id <project-id>
cxv projects disable --project-id <project-id>
cxv projects enable --project-id <project-id>
cxv projects run --project-id <project-id>
cxv projects stop --project-id <project-id>
cxv projects export-zip --project-id <project-id> --out ./bot.zip
cxv projects api-keys list --project-id <project-id>
cxv projects api-keys create --project-id <project-id>
cxv projects api-keys revoke --project-id <project-id> --key-id <key-id>
cxv projects data get --project-id <project-id> --key balance
cxv projects data set --project-id <project-id> --key balance --value '{"value":100}'
cxv projects data increment --project-id <project-id> --key balance --amount 5
cxv projects data delete --project-id <project-id> --key balance
cxv projects data export --project-id <project-id>
cxv workflows list --project-id <project-id>
cxv workflows get --workflow-id <workflow-id>
cxv workflows publish --workflow-id <workflow-id>
cxv workflows deploy --workflow-id <workflow-id>
cxv workflows run --workflow-id <workflow-id>
cxv workflows deployments --workflow-id <workflow-id>
cxv workflows requirements --workflow-id <workflow-id>
cxv deployments runs --deployment-id <deployment-id>
cxv runs logs --run-id <run-id>
cxv templates list
cxv templates mine
cxv templates get --template-id <template-id>
cxv templates submit --workflow-id <workflow-id> --title "Hello Bot" --summary "Basic hello" --description "..."
cxv templates withdraw --template-id <template-id>
cxv templates duplicate --template-id <template-id>
cxv domains list
cxv domains add --domain example.com
cxv domains verify --request-id <request-id>
cxv domains delete --request-id <request-id>
cxv domains mailbox-request --request-id <request-id> --domain example.com --local-part support
cxv cli-tokens list
cxv cli-tokens create
cxv cli-tokens revoke --token-id <token-id>
```

## Notes
- CLI stores an auth cookie in `~/.cxv/config.json`.
- Use `cxv logout` to clear the session.
