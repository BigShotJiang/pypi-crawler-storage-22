# cxv-cli

CLI for CXV.ONE.

## Install (local)

This CLI is bundled in the CXV.ONE repo. Install it from the repo path:

```bash
pip install /opt/discord-bot-builder/packages/cxv-cli
```

Optional editable install for development:

```bash
pip install -e /opt/discord-bot-builder/packages/cxv-cli
```

## Login

```bash
cxv login --email you@example.com --password "..."
```

## Usage

```bash
cxv whoami
cxv projects list
cxv projects create --name "My Bot"
cxv workflows list --project-id <project-id>
cxv workflows publish --workflow-id <workflow-id>
cxv workflows deploy --workflow-id <workflow-id>
```

## Notes
- CLI stores an auth cookie in `~/.cxv/config.json`.
- Use `cxv logout` to clear the session.
