import argparse
import json
import os
from typing import Any, Dict
import requests

CONFIG_DIR = os.path.expanduser("~/.cxv")
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")
DEFAULT_BASE_URL = "https://api.cxvre.com"


def _load_config() -> Dict[str, Any]:
    if not os.path.exists(CONFIG_PATH):
        return {}
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_config(data: Dict[str, Any]) -> None:
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _session_from_config(cfg: Dict[str, Any]) -> requests.Session:
    sess = requests.Session()
    cookies = cfg.get("cookies", {})
    if isinstance(cookies, dict):
        sess.cookies.update(cookies)
    return sess


def _require_session(cfg: Dict[str, Any]) -> requests.Session:
    if not cfg.get("cookies"):
        raise SystemExit("Not logged in. Run: cxv login --email <email> --password <password>")
    return _session_from_config(cfg)


def cmd_login(args: argparse.Namespace) -> None:
    base_url = args.base_url or DEFAULT_BASE_URL
    sess = requests.Session()
    res = sess.post(
        f"{base_url}/auth/login",
        json={"email": args.email, "password": args.password},
        timeout=15,
    )
    if not res.ok:
        raise SystemExit(f"Login failed: {res.status_code} {res.text}")
    cfg = {
        "base_url": base_url,
        "cookies": requests.utils.dict_from_cookiejar(sess.cookies),
    }
    _save_config(cfg)
    print("Login OK")


def cmd_logout(_: argparse.Namespace) -> None:
    cfg = _load_config()
    if not cfg.get("cookies"):
        print("Already logged out")
        return
    sess = _session_from_config(cfg)
    base_url = cfg.get("base_url", DEFAULT_BASE_URL)
    try:
        sess.post(f"{base_url}/auth/logout", timeout=10)
    except Exception:
        pass
    _save_config({})
    print("Logged out")


def cmd_whoami(_: argparse.Namespace) -> None:
    cfg = _load_config()
    sess = _require_session(cfg)
    base_url = cfg.get("base_url", DEFAULT_BASE_URL)
    res = sess.get(f"{base_url}/auth/me", timeout=15)
    if not res.ok:
        raise SystemExit(f"Auth check failed: {res.status_code} {res.text}")
    print(json.dumps(res.json(), indent=2))


def cmd_projects_list(_: argparse.Namespace) -> None:
    cfg = _load_config()
    sess = _require_session(cfg)
    base_url = cfg.get("base_url", DEFAULT_BASE_URL)
    res = sess.get(f"{base_url}/projects", timeout=15)
    if not res.ok:
        raise SystemExit(f"Failed to list projects: {res.status_code} {res.text}")
    print(json.dumps(res.json(), indent=2))


def cmd_projects_create(args: argparse.Namespace) -> None:
    cfg = _load_config()
    sess = _require_session(cfg)
    base_url = cfg.get("base_url", DEFAULT_BASE_URL)
    res = sess.post(f"{base_url}/projects", json={"name": args.name}, timeout=15)
    if not res.ok:
        raise SystemExit(f"Failed to create project: {res.status_code} {res.text}")
    print(json.dumps(res.json(), indent=2))


def cmd_workflows_list(args: argparse.Namespace) -> None:
    cfg = _load_config()
    sess = _require_session(cfg)
    base_url = cfg.get("base_url", DEFAULT_BASE_URL)
    res = sess.get(f"{base_url}/projects/{args.project_id}/workflows", timeout=15)
    if not res.ok:
        raise SystemExit(f"Failed to list workflows: {res.status_code} {res.text}")
    print(json.dumps(res.json(), indent=2))


def cmd_workflows_publish(args: argparse.Namespace) -> None:
    cfg = _load_config()
    sess = _require_session(cfg)
    base_url = cfg.get("base_url", DEFAULT_BASE_URL)
    res = sess.post(f"{base_url}/workflows/{args.workflow_id}/publish", timeout=15)
    if not res.ok:
        raise SystemExit(f"Failed to publish workflow: {res.status_code} {res.text}")
    print(json.dumps(res.json(), indent=2))


def cmd_workflows_deploy(args: argparse.Namespace) -> None:
    cfg = _load_config()
    sess = _require_session(cfg)
    base_url = cfg.get("base_url", DEFAULT_BASE_URL)
    res = sess.post(f"{base_url}/workflows/{args.workflow_id}/deploy", timeout=15)
    if not res.ok:
        raise SystemExit(f"Failed to deploy workflow: {res.status_code} {res.text}")
    print(json.dumps(res.json(), indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cxv")
    sub = parser.add_subparsers(dest="cmd", required=True)

    login = sub.add_parser("login")
    login.add_argument("--email", required=True)
    login.add_argument("--password", required=True)
    login.add_argument("--base-url")
    login.set_defaults(func=cmd_login)

    logout = sub.add_parser("logout")
    logout.set_defaults(func=cmd_logout)

    whoami = sub.add_parser("whoami")
    whoami.set_defaults(func=cmd_whoami)

    projects = sub.add_parser("projects")
    proj_sub = projects.add_subparsers(dest="subcmd", required=True)
    proj_list = proj_sub.add_parser("list")
    proj_list.set_defaults(func=cmd_projects_list)
    proj_create = proj_sub.add_parser("create")
    proj_create.add_argument("--name", required=True)
    proj_create.set_defaults(func=cmd_projects_create)

    workflows = sub.add_parser("workflows")
    wf_sub = workflows.add_subparsers(dest="subcmd", required=True)
    wf_list = wf_sub.add_parser("list")
    wf_list.add_argument("--project-id", required=True)
    wf_list.set_defaults(func=cmd_workflows_list)
    wf_pub = wf_sub.add_parser("publish")
    wf_pub.add_argument("--workflow-id", required=True)
    wf_pub.set_defaults(func=cmd_workflows_publish)
    wf_dep = wf_sub.add_parser("deploy")
    wf_dep.add_argument("--workflow-id", required=True)
    wf_dep.set_defaults(func=cmd_workflows_deploy)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
