from .soilgrids import HOMOLOSINE
from .soilgrids import SOILGRIDS_LAYERS
from .soilgrids import SOILGRIDS_PROPERTIES
from .soilgrids import download_soilgrids_data
from .soilgrids import SoilGrids
