# CyProLib
The Unified Python Cybersecurity Framework.# 🛡️ CyProLib: The Unified Python Cybersecurity Framework

[![PyPI Version](https://img.shields.io/pypi/v/cyprolib.svg)](https://pypi.org/project/cyprolib/)
[![Python](https://img.shields.io/pypi/pyversions/cyprolib.svg)](https://pypi.org/project/cyprolib/)
[![License](https://img.shields.io/pypi/l/cyprolib.svg)](https://github.com/yourusername/cyprolib)

**CyProLib** is a professional-grade cybersecurity framework designed for Red Teamers, Blue Teamers, and Python developers. It unifies Network Scanning, Web Vulnerability Analysis, and Intrusion Detection (IDS) into a single, easy-to-use CLI.

---

## 🚀 Features

* **🔥 Network Scanner:** Multi-threaded port scanning with service fingerprinting.
* **🌐 Web Vulnerability Scanner:** Detects missing security headers and sensitive info leaks.
* **🧨 Active Fuzzer:** Tests for XSS and SQL Injection vulnerabilities.
* **🛡️ Blue Team IDS:** Real-time intrusion detection for SYN scans and ICMP floods.
* **🤖 AI Mentor:** Integrated with **Ollama (Llama3)** to explain risks and suggest fixes.
* **💾 Cyber-Lake:** Auto-saves all scan data to a local SQLite database.
* **📄 Reporting:** Generates professional Markdown and JSON audit reports.

---

## 📦 Installation

```bash
pip install cyprolib
```
Note: You must have Nmap (optional) and Ollama (for AI features) installed.

## ⚡ Usage

**1. Network Scan (Red Team)** 
Scan a target for open ports and get an AI risk assessment.
```bash
cypro scan 192.168.1.1 --ports 1-1000 --explain --model llama3
```
**2. Web Security Scan** 
Check a website for HTTP header vulnerabilities.
```bash
cypro web google.com
```
**3. Active Fuzzing (XSS/SQLi)** 
Aggressively test a URL parameter for bugs.
```bash
cypro fuzz "[http://testphp.vulnweb.com/listproducts.php?cat=1](http://testphp.vulnweb.com/listproducts.php?cat=1)"
```
**4. Intrusion Detection (Blue Team)**
Turn your computer into a defensive sentinel.
```bash
cypro ids
```
**5. Generate Report**
Export your findings to a professional report.
```bash
cypro report --format md --output audit_result
```
## 🤖 AI Integration
CyProLib uses Ollama to run local LLMs (like Llama3 or Phi3).

1. Install Ollama.

2. Run ollama serve.

3. Use the --explain flag in CyProLib scans.

**⚠️ Disclaimer**
CyProLib is for educational and authorized testing purposes only. Using this tool on networks or systems without permission is illegal. The authors are not responsible for misuse.

Created by Pugazhmani | Powered by Python & Typer.
