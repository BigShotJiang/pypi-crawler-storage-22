# 🛡️ CyProLib: The Unified Python Cybersecurity Framework

[![PyPI Version](https://img.shields.io/pypi/v/cyprolib-Pugazhmani.svg)](https://pypi.org/project/cyprolib-Pugazhmani/)
[![Python](https://img.shields.io/pypi/pyversions/cyprolib-Pugazhmani.svg)](https://pypi.org/project/cyprolib-Pugazhmani/)
[![License](https://img.shields.io/pypi/l/cyprolib-Pugazhmani.svg)](https://pypi.org/project/cyprolib-Pugazhmani/)

**CyProLib** is a professional-grade cybersecurity framework designed for Red Teamers, Blue Teamers, and Python developers. It unifies **Network Scanning**, **Web Vulnerability Analysis**, **Active Defense (IDS)**, and **API Automation** into a single, powerful library.

---

## 🚀 Features (v0.3.1)

### 🔴 Red Team (Offensive)
* **Port Scanner:** Fast, multi-threaded network scanning.
* **Web Analyzer:** Detects missing headers and information leaks.
* **Active Fuzzer:** Tests for XSS and SQL Injection vulnerabilities.
* **AI Integration:** Uses LLMs (Ollama) to explain vulnerabilities.

### 🔵 Blue Team (Defensive)
* **🍯 Honeypot Trap:** Deploys fake services (SSH, HTTP) to catch hackers.
* **🛡️ Active Defense:** Automatically blocks attacker IPs using the system firewall (UFW/Netsh).
* **🔔 Real-Time Alerts:** Sends instant notifications to **Discord** or **Email**.
* **🧠 Threat Intel:** Checks attacker IPs against **AbuseIPDB** automatically.

### 🌍 Automation & API
* **REST API:** A built-in FastAPI server to control scans remotely.
* **Python Library:** Import `cyprolib` into your own scripts.

---

## 📦 Installation

```bash
pip install cyprolib-Pugazhmani
```
## ⚙️ Configuration
To enable Alerts and Threat Intelligence, generate a configuration file:
**1.Initialize Config:**
```bash
cypro init
```
**2. Edit Config:**```bash .env``` file : Paste your Discord Webhook URL or API keys into the generated .env file .

## 📖 Usage Guide

**1.Network Scanning:**
Scan a target for open ports and identify services .
```bash
cypro scan 192.168.1.1 --ports 1-1000
```
Add --explain to get an AI breakdown of the results.
**2. 🍯 Deploy a Honeypot (Trap)**
Start a fake SSH server to trap hackers. If they connect, CyProLib will log their password, alert you on Discord, and block their IP.
```bash
cypro trap --port 2222 --type ssh
```
**3.🌍 Start the API Server**
Turn your terminal into a Web API
```bash
cypro serve
```
**4. 🌐 Web Vulnerability Scan**
```bash
cypro web [https://example.com](https://example.com)
```
# 🐍 For Developers (Python API)
You can use CyProLib inside your own Python projects:
```bash
from cyprolib.net.scanner import Scanner
from cyprolib.core.alert import AlertManager

# 1. Run a Scan
scanner = Scanner()
results = scanner.scan_target("192.168.1.1", ports=[80, 443])

# 2. Send an Alert
if results["open_ports"]:
    alerts = AlertManager()
    alerts.send_discord(f"Scan Finished! Found {len(results['open_ports'])} ports.")
```
## ⚠️ Disclaimer
CyProLib is for educational and authorized security testing purposes only.

* Do not scan targets you do not own.

* Do not use the Active Defense module on production servers without testing.

* The developers are not responsible for misuse.

Maintained by Pugazhmani | GitHub Repository