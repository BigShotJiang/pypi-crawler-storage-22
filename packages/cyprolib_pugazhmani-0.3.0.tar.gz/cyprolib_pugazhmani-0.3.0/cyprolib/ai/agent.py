import json
import requests
from rich.console import Console
from rich.markdown import Markdown

console = Console()

class CyberAgent:
    def __init__(self, model="llama3"):
        """
        Initialize the AI Agent.
        :param model: The Ollama model to use (e.g., 'llama3', 'phi3', 'mistral').
        """
        self.model = model
        # Default Ollama API endpoint
        self.api_url = "http://localhost:11434/api/generate"

    def is_active(self):
        """Check if Ollama is running locally."""
        try:
            requests.get("http://localhost:11434", timeout=1)
            return True
        except requests.ConnectionError:
            return False

    def explain_scan(self, scan_data):
        """
        Sends scan results to the AI and asks for a risk assessment + CODE FIX.
        """
        if not self.is_active():
            return "[bold red]❌ AI Error:[/bold red] Ollama is not running. Run 'ollama serve' first."

        # 1. Analyze the Data Source (Network vs Web)
        open_ports = scan_data.get("open_ports", [])
        missing_headers = scan_data.get("missing_headers", [])
        
        context = ""
        scan_type = ""

        if open_ports:
            scan_type = "Network Scan (Open Ports)"
            # Simplify data for AI to save tokens and speed up response
            simplified_ports = [{"port": p["port"], "service": p.get("service", "unknown")} for p in open_ports]
            context = f"Open Ports Found:\n{json.dumps(simplified_ports, indent=2)}"
            
        elif missing_headers:
            scan_type = "Web Security Scan (Missing HTTP Headers)"
            context = f"Missing Security Headers:\n{json.dumps(missing_headers, indent=2)}"
            
        else:
            return "✅ No critical vulnerabilities found to explain."

        # 2. Construct the "AI Fixer" Prompt
        prompt = f"""
        You are a Senior Cybersecurity Engineer. I have performed a {scan_type} and found the following issues:
        {context}

        Please provide a professional report with exactly these 3 sections:
        
        ### 1. 🚨 The Risk
        Briefly explain why this is dangerous (1-2 sentences max).

        ### 2. 🛡️ The Fix
        Explain the concept of how to secure it.

        ### 3. 💻 Code / Command Remediation
        Provide the exact command or code snippet to fix this immediately.
        - If it's a PORT (e.g., 445), give a command to block it (e.g., UFW for Linux or Netsh for Windows).
        - If it's a HEADER, give the Nginx/Apache config or Python/Node.js code to add it.
        
        Keep it concise and actionable. Do not chatter.
        """

        # 3. Call the Local LLM
        try:
            response = requests.post(
                self.api_url,
                json={
                    "model": self.model, 
                    "prompt": prompt, 
                    "stream": False
                },
                timeout=120  # Increased timeout to 120s for larger models
            )
            response.raise_for_status()
            response_json = response.json()
            
            # Return formatted Markdown
            return Markdown(response_json.get("response", "No response from AI."))
            
        except requests.exceptions.ReadTimeout:
            return f"[bold red]⏳ AI Timeout:[/bold red] The model '{self.model}' took too long to answer (>120s). Try a smaller model like 'phi3'."
        except Exception as e:
            return f"[bold red]AI Error:[/bold red] {str(e)}"