from fastapi import FastAPI, BackgroundTasks, HTTPException
from pydantic import BaseModel
import uvicorn

# --- Import CyProLib Core Modules ---
from cyprolib.net.scanner import Scanner
from cyprolib.vuln.headers import WebScanner
from cyprolib.core.alert import AlertManager

app = FastAPI(
    title="CyProLib API",
    description="The Autonomous Sentinel REST API",
    version="0.3.0"
)

# --- Data Models (What the user sends us) ---
class NetworkScanRequest(BaseModel):
    target: str
    ports: list[int] = [80, 443, 22, 21, 445]
    project: str = "api_scan"

class WebScanRequest(BaseModel):
    url: str
    project: str = "api_scan"

# --- API Endpoints ---

@app.get("/")
def home():
    return {"status": "online", "system": "CyProLib v0.3 Sentinel"}

@app.post("/scan/network")
def run_network_scan(request: NetworkScanRequest, background_tasks: BackgroundTasks):
    """
    Start a Network Port Scan in the background.
    """
    # We use background_tasks so the API returns "OK" immediately
    # while the scan runs in the background.
    background_tasks.add_task(task_network_scan, request.target, request.ports)
    return {"message": f"Scan started on {request.target}", "status": "running"}

@app.post("/scan/web")
def run_web_scan(request: WebScanRequest):
    """
    Run a Web Vulnerability Scan (Synchronous).
    """
    scanner = WebScanner()
    results = scanner.scan_site(request.url)
    return results

# --- Background Worker Functions ---

def task_network_scan(target, ports):
    """
    The actual heavy lifting for network scanning.
    """
    print(f"🚀 API: Starting scan on {target}...")
    scanner = Scanner()
    results = scanner.scan_target(target, ports)
    
    # Auto-Alert if critical ports are open
    if results["open_ports"]:
        alerter = AlertManager()
        alerter.send_discord(f"📡 **API Scan Finished:** Found {len(results['open_ports'])} open ports on {target}!")

# --- Entry Point ---
def start_api():
    """Function to start the server from CLI"""
    uvicorn.run(app, host="0.0.0.0", port=8000)

if __name__ == "__main__":
    start_api()