import typer
import os
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

# --- IMPORTS ---
from cyprolib.core.session import Session
from cyprolib.net.scanner import Scanner
from cyprolib.vuln.headers import WebScanner
from cyprolib.vuln.web import WebFuzzer
from cyprolib.ai.agent import CyberAgent
from cyprolib.ids.sniffer import IntrusionDetector
from cyprolib.ids.honeypot import Honeypot
from cyprolib.report.generator import ReportGenerator

# Import the API Server entry point (wrapped in try-except)
try:
    from cyprolib.api.server import start_api
except ImportError:
    start_api = None

app = typer.Typer(
    help="CyProLib: The Unified Python Cybersecurity Framework.",
    add_completion=False,
    no_args_is_help=True
)
console = Console()

# --- COMMAND 1: CONFIGURATION (NEW) ---
@app.command()
def init():
    """⚙️ Create a configuration file (.env) for API keys."""
    console.print(Panel(f"[bold yellow]Initializing Configuration[/]", title="⚙️ CyProLib Setup"))
    
    # Template content for the user's .env file
    env_content = """# CyProLib Configuration
# ---------------------------------------------------------
# 1. Discord Webhook (For Alerts)
#    Go to Server Settings -> Integrations -> Webhooks -> New Webhook
DISCORD_WEBHOOK_URL=

# 2. AbuseIPDB Key (For Threat Intelligence)
#    Get a free key here: https://www.abuseipdb.com/
ABUSEIPDB_API_KEY=

# 3. Email Settings (Optional - for Email Alerts)
#    If using Gmail, generate an 'App Password'
EMAIL_SENDER=
EMAIL_PASSWORD=
EMAIL_RECEIVER=
"""
    
    # Create the file in the current working directory
    file_path = os.path.join(os.getcwd(), ".env")
    
    if os.path.exists(file_path):
        console.print(f"[yellow]⚠️  A .env file already exists at:[/yellow] {file_path}")
        overwrite = typer.confirm("Do you want to overwrite it?")
        if not overwrite:
            console.print("[red]Aborted.[/red]")
            return

    try:
        with open(file_path, "w") as f:
            f.write(env_content)
        
        console.print(f"[green]✅ Created configuration file at:[/green] {file_path}")
        console.print("\n[bold cyan]Next Steps:[/bold cyan]")
        console.print("1. Open the [bold].env[/bold] file with any text editor.")
        console.print("2. Paste your API keys inside.")
        console.print("3. Run [green]cypro trap[/green] or [green]cypro scan[/green] to use the features!")
        
    except Exception as e:
        console.print(f"[bold red]❌ Error creating file:[/bold red] {e}")


# --- COMMAND 2: NETWORK SCAN ---
@app.command()
def scan(
    target: str = typer.Argument(..., help="Target IP or Domain (e.g., 127.0.0.1)"),
    ports: str = typer.Option("1-100", "--ports", "-p", help="Port range"),
    project: str = typer.Option("default", "--project", help="Project name"),
    explain: bool = typer.Option(False, "--explain", "-e", help="Ask AI to analyze results"),
    model: str = typer.Option("llama3", "--model", "-m", help="Ollama model to use")
):
    """🚀 Run a professional network port scan."""
    console.print(Panel(f"[bold green]Starting Network Scan[/] on [cyan]{target}[/]", title="🚀 CyProLib"))

    try:
        session = Session(project_name=project)
        session.set_target(target)
    except Exception as e:
        console.print(f"[bold red]❌ Session Error:[/bold red] {e}")
        return

    # Parse Ports
    try:
        if "," in ports:
            port_list = [int(p) for p in ports.split(",")]
        elif "-" in ports:
            start, end = map(int, ports.split("-"))
            port_list = range(start, end + 1)
        else:
            port_list = [int(ports)]
    except ValueError:
        console.print("[bold red]❌ Invalid port format![/] Use '1-100' or '80,443'.")
        return

    scanner = Scanner()
    results = {}
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True
    ) as progress:
        progress.add_task(description=f"Scanning {len(port_list)} ports...", total=None)
        results = scanner.scan_target(target, ports=port_list)

    scan_id = session.save_scan("port_scan", results)
    console.print(f"[dim]💾 Results saved to database (Scan ID: {scan_id})[/dim]")

    if results.get("open_ports"):
        table = Table(title=f"Open Ports on {target}", border_style="green")
        table.add_column("Port", style="cyan", justify="right")
        table.add_column("Service", style="magenta")
        table.add_column("Banner", style="yellow")

        for p in results["open_ports"]:
            banner = (p.get('banner') or "Unknown")[:30]
            table.add_row(str(p['port']), p.get('service', 'unknown'), banner)
        
        console.print(table)
        console.print(f"\n[bold red]⚠️  Found {len(results['open_ports'])} open ports![/]")
        
        # AI Analysis
        if explain:
            console.print(Panel(f"[bold magenta]🤖 AI Analysis ({model})[/]", title="The Mentor"))
            agent = CyberAgent(model=model)
            with console.status(f"Asking {model}...", spinner="dots"):
                analysis = agent.explain_scan(results)
            console.print(analysis)
    else:
        console.print("[bold yellow]No open ports found.[/]")


# --- COMMAND 3: WEB SCAN ---
@app.command()
def web(
    url: str = typer.Argument(..., help="Target URL (e.g., google.com)"),
    project: str = typer.Option("default", "--project"),
    explain: bool = typer.Option(False, "--explain", "-e", help="Ask AI to analyze headers"),
    model: str = typer.Option("llama3", "--model", "-m", help="Ollama model to use")
):
    """🌐 Run a web vulnerability scan (Headers & Info Leaks)."""
    console.print(Panel(f"[bold blue]Starting Web Scan[/] on [cyan]{url}[/]", title="🌐 CyProLib Web"))

    try:
        session = Session(project_name=project)
        target_name = url.replace("https://", "").replace("http://", "").split("/")[0]
        session.set_target(target_name)
    except Exception as e:
        console.print(f"[bold red]❌ Session Error:[/bold red] {e}")
        return

    scanner = WebScanner()
    with console.status("[bold blue]Analyzing HTTP Headers...[/]", spinner="earth"):
        results = scanner.scan_site(url)

    if results.get("error"):
        console.print(f"[bold red]❌ Scan Error:[/bold red] {results['error']}")
        return

    scan_id = session.save_scan("web_scan", results)
    console.print(f"[dim]💾 Saved to DB (ID: {scan_id})[/dim]")

    if results.get("info_leaks"):
        console.print("\n[bold red]🚨 Information Leaks Detected:[/bold red]")
        leak_table = Table(show_header=False, border_style="red")
        for k, v in results["info_leaks"].items():
            leak_table.add_row(k, v)
        console.print(leak_table)
    else:
        console.print("\n[bold green]✅ No Info Leaks Found.[/bold green]")

    if results.get("missing_headers"):
        console.print(f"\n[bold yellow]⚠️  Missing Security Headers ({len(results['missing_headers'])}):[/bold yellow]")
        for h in results["missing_headers"]:
            console.print(f" - {h}")
            
        # AI Analysis for Web
        if explain:
            console.print(Panel(f"[bold magenta]🤖 AI Analysis ({model})[/]", title="The Mentor"))
            agent = CyberAgent(model=model)
            with console.status(f"Asking {model} for fixes...", spinner="dots"):
                analysis = agent.explain_scan(results)
            console.print(analysis)
    else:
        console.print("\n[bold green]🛡️  All Secure Headers Present![/bold green]")


# --- COMMAND 4: ACTIVE FUZZER ---
@app.command()
def fuzz(
    url: str = typer.Argument(..., help="Target URL with params (e.g. http://site.com?id=1)"),
    project: str = typer.Option("default", "--project")
):
    """🧨 Active Fuzzing for XSS & SQLi (Warning: Noisy!)."""
    console.print(Panel(f"[bold red]Starting Active Fuzzer[/] on [cyan]{url}[/]", title="🧨 CyProLib Fuzz"))
    
    session = Session(project_name=project)
    fuzzer = WebFuzzer()
    
    with console.status("[bold red]Injecting payloads...[/]", spinner="grenade"):
        results = fuzzer.scan_url(url)
        
    if results["xss"]:
        console.print(f"\n[bold red]🔥 Found {len(results['xss'])} XSS Vulnerabilities:[/bold red]")
        for bug in results["xss"]:
            console.print(f" - Param: [yellow]{bug['param']}[/yellow] | Payload: {bug['payload']}")
    
    if results["sqli"]:
        console.print(f"\n[bold red]💉 Found {len(results['sqli'])} SQL Injection Vulnerabilities:[/bold red]")
        for bug in results["sqli"]:
            console.print(f" - Param: [yellow]{bug['param']}[/yellow] | Payload: {bug['payload']}")
            
    if not results["xss"] and not results["sqli"]:
        console.print("\n[bold green]✅ No obvious bugs found (Target seems secure).[/bold green]")
    
    session.save_scan("web_fuzz", results)


# --- COMMAND 5: IDS ---
@app.command()
def ids():
    """🛡️ Start Real-Time Intrusion Detection System."""
    console.print(Panel(f"[bold red]Initializing WolfShield IDS[/]", title="🛡️ CyProLib Defense"))
    detector = IntrusionDetector()
    detector.start()


# --- COMMAND 6: HONEYPOT (DEFENSE) ---
@app.command()
def trap(
    port: int = typer.Option(2222, "--port", "-p", help="Port to listen on (e.g. 2222 for fake SSH)"),
    type: str = typer.Option("ssh", "--type", "-t", help="Service type: 'ssh', 'http', or 'generic'")
):
    """🍯 Start a Honeypot to trap hackers."""
    console.print(Panel(f"[bold yellow]Initializing Honeypot Defense[/]", title="🍯 CyProLib Trap"))
    
    try:
        honey = Honeypot(port=port, service_type=type)
        honey.start()
    except Exception as e:
        console.print(f"[bold red]❌ Trap Error:[/bold red] {e}")


# --- COMMAND 7: REPORT ---
@app.command()
def report(
    project: str = typer.Option("default", "--project", help="Project to report on"),
    format: str = typer.Option("md", "--format", "-f", help="Format: 'md' or 'json'"),
    output: str = typer.Option("report", "--output", "-o", help="Output filename")
):
    """📄 Generate a professional report (Markdown/JSON)."""
    console.print(Panel(f"[bold yellow]Generating Report[/] for project [cyan]{project}[/]", title="📄 CyProLib Report"))
    
    try:
        generator = ReportGenerator(project_name=project)
        
        if format.lower() == "json":
            filename = f"{output}.json"
            generator.export_json(filename)
            console.print(f"[bold green]✅ JSON Report saved to:[/bold green] {filename}")
        else:
            filename = f"{output}.md"
            generator.export_markdown(filename)
            console.print(f"[bold green]✅ Markdown Report saved to:[/bold green] {filename}")
            
    except Exception as e:
        console.print(f"[bold red]❌ Reporting Error:[/bold red] {e}")


# --- COMMAND 8: HISTORY ---
@app.command()
def history(project: str = typer.Option("default")):
    """📜 View scan history."""
    try:
        session = Session(project_name=project)
        query = "SELECT id, timestamp, scan_type FROM scans ORDER BY id DESC LIMIT 10"
        with session.db.get_conn() as conn:
            rows = conn.execute(query).fetchall()
        
        if not rows:
            console.print("[yellow]No history found.[/yellow]")
            return

        table = Table(title=f"History: {project}")
        table.add_column("ID", style="dim")
        table.add_column("Type", style="cyan")
        table.add_column("Time", style="blue")
        
        for row in rows:
            table.add_row(str(row['id']), row['scan_type'], str(row['timestamp']))
        console.print(table)
        
    except Exception as e:
        console.print(f"[bold red]❌ Error:[/bold red] {e}")


# --- COMMAND 9: API SERVER (AUTOMATION) ---
@app.command()
def serve():
    """🌍 Start the CyProLib REST API Server."""
    if start_api is None:
        console.print("[bold red]❌ API Modules Missing![/bold red]")
        console.print("Please run: [green]pip install fastapi uvicorn[/green]")
        return

    console.print(Panel(f"[bold green]Starting API Server[/] on [cyan]http://0.0.0.0:8000[/]", title="🌍 CyProLib Sentinel"))
    console.print("[dim]Press Ctrl+C to stop.[/dim]")
    console.print("[dim]Docs available at: http://localhost:8000/docs[/dim]")
    
    start_api()


if __name__ == "__main__":
    app()