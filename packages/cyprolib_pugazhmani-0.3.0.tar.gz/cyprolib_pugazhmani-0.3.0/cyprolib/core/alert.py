import requests
import smtplib
from email.mime.text import MIMEText
from cyprolib.core.config import Config

class AlertManager:
    def check_reputation(self, ip):
        """Check AbuseIPDB for known hacker IPs."""
        if not Config.ABUSEIPDB_KEY:
            return "Unknown (No Key)"
        
        url = "https://api.abuseipdb.com/api/v2/check"
        headers = {"Key": Config.ABUSEIPDB_KEY, "Accept": "application/json"}
        params = {"ipAddress": ip, "maxAgeInDays": "90"}
        
        try:
            r = requests.get(url, headers=headers, params=params)
            data = r.json()
            if "data" in data:
                score = data["data"]["abuseConfidenceScore"]
                return f"Confidence: {score}%"
        except:
            return "Check Failed"
        return "Clean"

    def send_discord(self, message):
        """Send a notification to Discord."""
        if not Config.DISCORD_WEBHOOK:
            print("⚠️ Discord Webhook not set in .env")
            return False
            
        payload = {"content": f"🛡️ **CyProLib Alert:** {message}"}
        try:
            requests.post(Config.DISCORD_WEBHOOK, json=payload)
            return True
        except Exception as e:
            print(f"Discord Error: {e}")
            return False