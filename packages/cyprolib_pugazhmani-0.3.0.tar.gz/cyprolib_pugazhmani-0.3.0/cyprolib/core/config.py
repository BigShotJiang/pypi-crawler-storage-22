import os
from dotenv import load_dotenv

# Load .env from the current directory (where the user runs the command)
load_dotenv(os.path.join(os.getcwd(), ".env"))

class Config:
    DISCORD_WEBHOOK = os.getenv("DISCORD_WEBHOOK_URL")
    ABUSEIPDB_KEY = os.getenv("ABUSEIPDB_API_KEY")
    EMAIL_USER = os.getenv("EMAIL_SENDER")
    EMAIL_PASS = os.getenv("EMAIL_PASSWORD")
    EMAIL_TO = os.getenv("EMAIL_RECEIVER")