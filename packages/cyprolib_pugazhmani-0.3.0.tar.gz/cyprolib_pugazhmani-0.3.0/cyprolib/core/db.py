import sqlite3
import json
from datetime import datetime
from pathlib import Path

# The 'Cyber-Lake' Schema: Defines how we store data
SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS targets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER,
    ip TEXT NOT NULL,
    hostname TEXT,
    os_info TEXT,
    FOREIGN KEY(project_id) REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id INTEGER,
    scan_type TEXT,  -- e.g., 'port_scan', 'web_vuln', 'network_sentry'
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    raw_data JSON,   -- Stores the full flexible output
    FOREIGN KEY(target_id) REFERENCES targets(id)
);

CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER,
    severity TEXT,   -- 'INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'
    title TEXT,
    description TEXT,
    remediation TEXT,
    FOREIGN KEY(scan_id) REFERENCES scans(id)
);
"""

class CyberLake:
    def __init__(self, db_path="cypro.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """Initialize the database tables if they don't exist."""
        with sqlite3.connect(self.db_path) as conn:
            conn.executescript(SCHEMA)

    def get_conn(self):
        """Helper to get a database connection."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # Access columns by name
        return conn

    def create_project(self, name):
        """Create a new workspace or return existing one."""
        with self.get_conn() as conn:
            try:
                cur = conn.execute("INSERT INTO projects (name) VALUES (?)", (name,))
                conn.commit()
                return cur.lastrowid
            except sqlite3.IntegrityError:
                # If project exists, return its ID
                cur = conn.execute("SELECT id FROM projects WHERE name = ?", (name,))
                return cur.fetchone()['id']

    def add_target(self, project_id, ip, hostname=None):
        """Add a target (IP/Domain) to the project scope."""
        with self.get_conn() as conn:
            cur = conn.execute(
                "INSERT INTO targets (project_id, ip, hostname) VALUES (?, ?, ?)",
                (project_id, ip, hostname)
            )
            conn.commit()
            return cur.lastrowid

    def log_scan(self, target_id, scan_type, data):
        """Save raw scan results (The 'Save' button)."""
        json_data = json.dumps(data)
        with self.get_conn() as conn:
            cur = conn.execute(
                "INSERT INTO scans (target_id, scan_type, raw_data) VALUES (?, ?, ?)",
                (target_id, scan_type, json_data)
            )
            conn.commit()
            return cur.lastrowid

    def add_finding(self, scan_id, title, severity, description, fix):
        """Record a specific vulnerability."""
        with self.get_conn() as conn:
            conn.execute(
                """INSERT INTO findings 
                   (scan_id, title, severity, description, remediation) 
                   VALUES (?, ?, ?, ?, ?)""",
                (scan_id, title, severity, description, fix)
            )
            conn.commit()