from .db import CyberLake

class Session:
    def __init__(self, project_name="default_project"):
        self.db = CyberLake()  # Initialize the Cyber-Lake
        self.project_id = self.db.create_project(project_name)
        self.current_target_id = None
        print(f"[*] Session Active: Project '{project_name}' (ID: {self.project_id})")

    def set_target(self, ip, hostname=None):
        """Define who we are attacking/defending."""
        self.current_target_id = self.db.add_target(self.project_id, ip, hostname)
        return self.current_target_id

    def save_scan(self, scan_type, data):
        """Wrapper to save scan data for current target."""
        if not self.current_target_id:
            raise ValueError("No target set! Call set_target() first.")
        
        scan_id = self.db.log_scan(self.current_target_id, scan_type, data)
        return scan_id

    def report_vuln(self, scan_id, title, severity, desc, fix):
        """Wrapper to report a vulnerability."""
        self.db.add_finding(scan_id, title, severity, desc, fix)