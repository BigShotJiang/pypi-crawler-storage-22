import platform
import subprocess
from rich.console import Console

console = Console()

class FirewallManager:
    def __init__(self):
        self.os_type = platform.system()  # 'Windows' or 'Linux'

    def block_ip(self, ip_address):
        """
        Blocks an IP address using the system firewall.
        """
        if ip_address == "127.0.0.1" or ip_address == "localhost":
            console.print("[yellow]⚠️ Safety: Not blocking localhost![/yellow]")
            return False

        console.print(f"[bold red]🛡️ ACTIVATING SHIELD: Blocking {ip_address}...[/bold red]")
        
        try:
            if self.os_type == "Windows":
                # Windows Command: netsh advfirewall firewall add rule name="BLOCK_IP" dir=in action=block remoteip=IP
                cmd = f'netsh advfirewall firewall add rule name="CyPro_Block_{ip_address}" dir=in action=block remoteip={ip_address}'
                subprocess.run(cmd, shell=True, check=True)
                console.print(f"[green]✅ {ip_address} has been banned on Windows Firewall.[/green]")
                return True

            elif self.os_type == "Linux":
                # Linux Command: ufw deny from IP
                cmd = ["sudo", "ufw", "deny", "from", ip_address]
                subprocess.run(cmd, check=True)
                console.print(f"[green]✅ {ip_address} has been banned on UFW.[/green]")
                return True
            
            else:
                console.print("[red]❌ Unsupported OS for auto-blocking.[/red]")
                return False

        except subprocess.CalledProcessError as e:
            console.print(f"[red]❌ Firewall Error:[/red] {e}")
            return False
        except PermissionError:
            console.print("[bold red]❌ PERMISSION DENIED:[/bold red] You must run as Administrator/Root to block IPs.")
            return False