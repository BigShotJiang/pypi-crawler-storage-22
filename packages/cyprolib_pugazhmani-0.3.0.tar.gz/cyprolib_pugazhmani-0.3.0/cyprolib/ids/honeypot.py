import socket
import threading
from datetime import datetime
from rich.console import Console
from rich.panel import Panel

# --- Internal Imports ---
from cyprolib.core.alert import AlertManager
from cyprolib.ids.blocker import FirewallManager

console = Console()

class Honeypot:
    def __init__(self, bind_ip="0.0.0.0", port=2222, service_type="ssh"):
        """
        Initialize the Honeypot trap.
        :param bind_ip: IP to listen on (0.0.0.0 for all interfaces).
        :param port: Port to open (e.g., 2222 for fake SSH).
        :param service_type: Type of service to mimic ('ssh', 'http', 'generic').
        """
        self.bind_ip = bind_ip
        self.port = port
        self.service_type = service_type.lower()
        self.is_running = False
        
        # Initialize Defense Modules
        self.alerter = AlertManager()
        self.blocker = FirewallManager()

    def handle_client(self, client_socket, address):
        """
        Handle the intruder's connection in a separate thread.
        """
        ip, port = address
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 1. Console Log (Immediate Visual Feedback)
        console.print(f"\n[bold red]🚨 HONEYPOT TRIGGERED![/bold red] Connection from {ip}:{port}")
        
        # 2. Send Remote Alert (Discord/Email)
        alert_msg = (
            f"🍯 **TRAP TRIGGERED!**\n"
            f"**Time:** {timestamp}\n"
            f"**Attacker IP:** {ip}\n"
            f"**Target Port:** {self.port} ({self.service_type.upper()})\n"
        )
        self.alerter.send_discord(alert_msg, level="critical")

        # 3. ACTIVE DEFENSE: Block the IP
        # We block them immediately upon connection to the trap port.
        block_success = self.blocker.block_ip(ip)
        if block_success:
            self.alerter.send_discord(f"🛡️ **Defense Activated:** IP {ip} has been blocked by Firewall.", level="info")

        try:
            # 4. Mimic the Service (Deception)
            # Even if blocked, the socket might still be open for a split second,
            # or we might want to collect payload before the block takes full effect.
            if self.service_type == "ssh":
                # Fake OpenSSH banner to trick scanners like Nmap
                client_socket.send(b"SSH-2.0-OpenSSH_8.2p1 Ubuntu-4ubuntu0.5\r\n")
            elif self.service_type == "http":
                # Fake HTTP 401 Unauthorized or Login Page
                response = (
                    "HTTP/1.1 200 OK\r\n"
                    "Server: Apache/2.4.41 (Ubuntu)\r\n"
                    "Content-Type: text/html\r\n\r\n"
                    "<html><head><title>Login</title></head><body><h1>Admin Login Required</h1></body></html>"
                )
                client_socket.send(response.encode())
            else:
                client_socket.send(b"Ready.\r\n")

            # 5. Capture the Payload (What are they typing?)
            client_socket.settimeout(5)  # Short timeout to catch quick scripts
            data = client_socket.recv(1024)
            
            if data:
                payload = data.decode('utf-8', errors='ignore').strip()
                console.print(f"[yellow]📝 Intruder typed:[/yellow] {payload}")
                
                # Send the captured payload to Discord too
                self.alerter.send_discord(f"📝 **Intruder Payload:** `{payload}`", level="warning")

        except Exception as e:
            # Connection might be reset if firewall kicks in fast or client disconnects
            pass
        finally:
            client_socket.close()

    def start(self):
        """
        Start the Honeypot listener loop.
        """
        try:
            server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # Allow reusing the address so we can restart quickly
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server.bind((self.bind_ip, self.port))
            server.listen(5)
            self.is_running = True
            
            console.print(Panel(f"[bold green]🍯 Honeypot Active![/bold green]\n"
                                f"Type: [cyan]{self.service_type.upper()}[/cyan]\n"
                                f"Port: [cyan]{self.port}[/cyan]\n"
                                f"Status: Waiting for intruders...",
                                title="🛡️ CyProLib Trap"))

            while self.is_running:
                client, addr = server.accept()
                # Handle each hacker in a separate thread
                client_handler = threading.Thread(target=self.handle_client, args=(client, addr))
                client_handler.start()
                
        except PermissionError:
            console.print(f"\n[bold red]❌ Permission Denied:[/bold red] You need to run as Administrator/Root to bind port {self.port}.")
        except KeyboardInterrupt:
            console.print("\n[bold blue]🛑 Honeypot Stopped.[/bold blue]")
        except Exception as e:
            console.print(f"\n[bold red]❌ Trap Error:[/bold red] {e}")
        finally:
            try:
                server.close()
            except:
                pass