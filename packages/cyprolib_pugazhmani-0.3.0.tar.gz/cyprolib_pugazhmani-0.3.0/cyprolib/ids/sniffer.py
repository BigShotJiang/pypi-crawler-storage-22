from scapy.all import sniff, IP, TCP, ICMP
from rich.console import Console
from datetime import datetime

console = Console()

class IntrusionDetector:
    def __init__(self, interface=None):
        self.interface = interface
        self.packet_count = 0

    def _analyze_packet(self, packet):
        """Callback function that runs for EVERY packet captured."""
        self.packet_count += 1
        timestamp = datetime.now().strftime("%H:%M:%S")

        if IP in packet:
            src_ip = packet[IP].src
            dst_ip = packet[IP].dst

            # 1. Detect ICMP (Ping) - Often used for Recon
            if packet.haslayer(ICMP):
                type_code = packet[ICMP].type
                if type_code == 8: # Echo Request (Ping)
                    console.print(f"[bold red]🚨 [{timestamp}] ICMP PING DETECTED[/bold red] from {src_ip} -> {dst_ip}")

            # 2. Detect TCP SYN Scan (Stealth Scan)
            # A SYN packet without an ACK usually means someone is scanning ports
            if packet.haslayer(TCP):
                flags = packet[TCP].flags
                dst_port = packet[TCP].dport
                
                # 'S' is SYN flag. If it's JUST SYN (0x02), it's a connection attempt
                if flags == "S":
                    console.print(f"[bold yellow]⚠️  [{timestamp}] TCP SYN SCAN[/bold yellow] from {src_ip} -> Port {dst_port}")
                
                # Detect suspicious ports (e.g., Telnet 23, SMB 445)
                if dst_port in [23, 445, 3389] and flags == "S":
                    console.print(f"[bold red]🔥 [{timestamp}] CRITICAL: ATTACK ON SENSITIVE PORT {dst_port}[/bold red] from {src_ip}")

    def start(self, count=0):
        """
        Start sniffing.
        :param count: Number of packets to capture (0 = infinite)
        """
        console.print(f"[bold green]🛡️  IDS Started... Listening for threats...[/bold green]")
        try:
            # We use 'store=False' so we don't eat up all your RAM
            sniff(filter="ip", prn=self._analyze_packet, count=count, store=False)
        except KeyboardInterrupt:
            console.print("\n[bold blue]🛑 IDS Stopped.[/bold blue]")
        except Exception as e:
            console.print(f"[bold red]❌ Sniffer Error:[/bold red] {e}")
            console.print("[dim]Note: On Windows, ensure you have Npcap installed (from Wireshark).[/dim]")