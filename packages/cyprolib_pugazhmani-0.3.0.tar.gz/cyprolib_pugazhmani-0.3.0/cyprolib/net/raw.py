from scapy.all import IP, ICMP, TCP, sr1, conf

# Suppress Scapy verbose output (so it doesn't clutter your CLI)
conf.verb = 0

class PacketCrafter:
    def ping(self, target_ip):
        """
        Sends a custom ICMP Echo Request using Scapy.
        Returns a status string like "Alive (TTL=64)" or "Unreachable".
        """
        try:
            # Construct the packet: IP Header + ICMP Header
            packet = IP(dst=target_ip)/ICMP()
            
            # Send and wait for reply (timeout 2s)
            reply = sr1(packet, timeout=2)
            
            if reply:
                # If we get a reply, the host is up
                return f"Alive (TTL={reply.ttl})"
            return "Unreachable"
        except Exception as e:
            return f"Error: {e}"

    def check_firewall(self, target_ip, port):
        """
        Sends a TCP ACK packet to check if a firewall is filtering a port.
        - RST response = Unfiltered (Port is closed but reachable)
        - No response = Filtered (Firewall dropped the packet)
        """
        try:
            # Construct a TCP ACK packet (flag='A')
            packet = IP(dst=target_ip)/TCP(dport=port, flags="A")
            
            # Send and wait for reply
            reply = sr1(packet, timeout=2)
            
            if reply:
                if reply.haslayer(TCP) and reply[TCP].flags == "R":
                    return "Unfiltered (RST received)"
            return "Filtered (No response)"
        except Exception as e:
            return f"Error: {e}"