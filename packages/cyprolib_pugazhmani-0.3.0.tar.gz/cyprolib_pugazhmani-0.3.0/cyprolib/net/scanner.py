import socket
import concurrent.futures
from datetime import datetime

class Scanner:
    def __init__(self):
        # Common ports to scan if no range is provided
        self.common_ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 3306, 3389, 8080]

    def _grab_banner(self, ip, port):
        """Attempts to grab the service banner from an open port."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(2)
                s.connect((ip, port))
                # Send a generic request to trigger a response
                if port in [80, 8080, 443]:
                    s.send(b"HEAD / HTTP/1.0\r\n\r\n")
                
                banner = s.recv(1024).decode().strip()
                return banner
        except:
            return "Unknown Service"

    def _scan_port(self, ip, port):
        """Scans a single port. Returns dict if open, None if closed."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.5)  # Fast timeout
                result = s.connect_ex((ip, port))
                
                if result == 0:
                    # Port is Open! Get details.
                    service = socket.getservbyport(port, "tcp")
                    banner = self._grab_banner(ip, port)
                    return {
                        "port": port,
                        "state": "open",
                        "service": service,
                        "banner": banner
                    }
        except:
            pass
        return None

    def scan_target(self, ip, ports=None, threads=100):
        """
        Main entry point. Scans a target using multithreading.
        
        Args:
            ip (str): Target IP address.
            ports (list): List of ports to scan. Defaults to self.common_ports.
            threads (int): Number of concurrent threads.
            
        Returns:
            dict: Structured scan results compatible with Cyber-Lake DB.
        """
        if ports is None:
            ports = self.common_ports
        
        # Support range strings like "1-100"
        if isinstance(ports, str) and "-" in ports:
            start, end = map(int, ports.split("-"))
            ports = range(start, end + 1)

        print(f"[*] Starting scan on {ip} ({len(ports)} ports)...")
        start_time = datetime.now()
        open_ports = []

        # The 'ThreadPoolExecutor' is the engine of concurrency
        with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
            # Launch all scans simultaneously
            futures = {executor.submit(self._scan_port, ip, port): port for port in ports}
            
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result:
                    open_ports.append(result)
                    print(f"    [+] Found: Port {result['port']}/{result['service']}")

        duration = (datetime.now() - start_time).total_seconds()
        
        # Return structured data for the DB
        return {
            "target": ip,
            "timestamp": start_time.isoformat(),
            "duration": duration,
            "total_ports_scanned": len(ports),
            "open_ports": open_ports
        }