import socket
import ipaddress
import re

def is_valid_ip(ip_str):
    """
    Check if a string is a valid IPv4 address.
    Example: '192.168.1.1' -> True, '999.999.999.999' -> False
    """
    try:
        ipaddress.IPv4Address(ip_str)
        return True
    except ipaddress.AddressValueError:
        return False

def get_local_ip():
    """
    Get the local machine's IP address (useful for binding listeners).
    Uses a dummy connection to Google DNS (8.8.8.8) to find the route.
    """
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except Exception:
        return "127.0.0.1"

def resolve_domain(domain):
    """
    Convert domain (google.com) to IP (142.250...).
    Returns None if resolution fails.
    """
    try:
        return socket.gethostbyname(domain)
    except socket.gaierror:
        return None

def parse_cidr(cidr):
    """
    Convert CIDR notation '192.168.1.0/24' into a list of individual IPs.
    """
    try:
        net = ipaddress.ip_network(cidr, strict=False)
        return [str(ip) for ip in net.hosts()]
    except ValueError:
        return []