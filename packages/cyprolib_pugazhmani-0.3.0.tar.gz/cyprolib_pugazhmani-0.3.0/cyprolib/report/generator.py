import json
from datetime import datetime
from cyprolib.core.session import Session

class ReportGenerator:
    def __init__(self, project_name="default"):
        self.session = Session(project_name=project_name)
        self.project_name = project_name

    def export_json(self, output_file="report.json"):
        """Export all scan data to a raw JSON file."""
        query = """
            SELECT scans.id, scans.timestamp, scans.scan_type, targets.ip, scans.raw_data
            FROM scans
            JOIN targets ON scans.target_id = targets.id
        """
        with self.session.db.get_conn() as conn:
            rows = conn.execute(query).fetchall()
        
        data = []
        for row in rows:
            data.append({
                "scan_id": row["id"],
                "timestamp": row["timestamp"],
                "type": row["scan_type"],
                "target": row["ip"],
                "data": json.loads(row["raw_data"])
            })
        
        # FIX: Added encoding="utf-8" to support emojis on Windows
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
        return output_file

    def export_markdown(self, output_file="report.md"):
        """Generate a professional Markdown report."""
        query = """
            SELECT scans.id, scans.timestamp, scans.scan_type, targets.ip, scans.raw_data
            FROM scans
            JOIN targets ON scans.target_id = targets.id
            ORDER BY scans.timestamp DESC
        """
        with self.session.db.get_conn() as conn:
            rows = conn.execute(query).fetchall()

        md = f"# 🛡️ CyProLib Security Report\n"
        md += f"**Project:** {self.project_name}\n"
        md += f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
        md += "---\n\n"

        for row in rows:
            scan_data = json.loads(row["raw_data"])
            md += f"## 🔍 Scan {row['id']}: {row['scan_type'].upper()} ({row['ip']})\n"
            md += f"*Time: {row['timestamp']}*\n\n"

            if row['scan_type'] == "port_scan":
                open_ports = scan_data.get("open_ports", [])
                if open_ports:
                    md += "| Port | Service | Banner |\n"
                    md += "|------|---------|--------|\n"
                    for p in open_ports:
                        banner = (p.get('banner') or 'N/A').strip()[:20]
                        md += f"| {p['port']} | {p.get('service', 'unknown')} | {banner} |\n"
                else:
                    md += "✅ No open ports found.\n"

            elif row['scan_type'] == "web_scan":
                leaks = scan_data.get("info_leaks", {})
                missing = scan_data.get("missing_headers", [])
                
                if leaks:
                    md += "### 🚨 Information Leaks\n"
                    for k, v in leaks.items():
                        md += f"- **{k}**: `{v}`\n"
                
                if missing:
                    md += "\n### ⚠️ Missing Headers\n"
                    for h in missing:
                        md += f"- {h}\n"
                
                if not leaks and not missing:
                    md += "✅ No web vulnerabilities found.\n"
            
            md += "\n---\n"

        # FIX: Added encoding="utf-8" here as well
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(md)
        return output_file