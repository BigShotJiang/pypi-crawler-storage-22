import requests
import urllib3

# Suppress SSL warnings for self-signed certs
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WebScanner:
    def __init__(self):
        self.security_headers = [
            "Strict-Transport-Security",
            "Content-Security-Policy",
            "X-Frame-Options",
            "X-Content-Type-Options",
            "Referrer-Policy"
        ]
        self.risky_headers = [
            "Server",
            "X-Powered-By",
            "X-AspNet-Version"
        ]

    def scan_site(self, url):
        """
        Connects to a URL and analyzes its security posture.
        """
        # 1. FORCE HTTPS if missing (The Fix)
        url = url.strip() # Remove accidental spaces
        if not url.startswith("http"):
            url = f"https://{url}"
        
        results = {
            "target": url,
            "missing_headers": [],
            "present_headers": {},
            "info_leaks": {},
            "status": "error"
        }

        try:
            # 2. Make Request (Follow Redirects is True by default)
            response = requests.get(url, timeout=10, verify=False)
            
            results["status"] = "success"
            results["status_code"] = response.status_code
            headers = response.headers

            # 3. Check for Missing Security Headers (Case-Insensitive)
            # We convert all response headers to lowercase for easier matching
            lower_headers = {k.lower(): v for k, v in headers.items()}

            for h in self.security_headers:
                if h.lower() not in lower_headers:
                    results["missing_headers"].append(h)
                else:
                    results["present_headers"][h] = lower_headers[h.lower()]

            # 4. Check for Information Leaks
            for h in self.risky_headers:
                if h.lower() in lower_headers:
                    results["info_leaks"][h] = lower_headers[h.lower()]

        except Exception as e:
            results["error"] = str(e)

        return results