import requests
from urllib.parse import urlparse, parse_qs, urlencode

class WebFuzzer:
    def __init__(self):
        self.xss_payloads = [
            "<script>alert('CyPro')</script>",
            "\" onmouseover=\"alert(1)",
            "<img src=x onerror=alert(1)>"
        ]
        self.sqli_payloads = [
            "' OR '1'='1",
            "\" OR \"1\"=\"1",
            "' OR 1=1 --"
        ]

    def scan_url(self, url):
        """
        Scans URL parameters for vulnerabilities.
        Example: http://testphp.vulnweb.com/artists.php?artist=1
        """
        results = {
            "url": url,
            "xss": [],
            "sqli": []
        }
        
        # 1. Parse the URL to find parameters (e.g., ?id=1)
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        
        if not params:
            return results  # No parameters to fuzz

        # 2. Fuzz each parameter
        for param_name in params.keys():
            # -- Check XSS --
            for payload in self.xss_payloads:
                # Construct new URL with payload
                fuzzed_query = params.copy()
                fuzzed_query[param_name] = [payload]
                new_query_str = urlencode(fuzzed_query, doseq=True)
                target_url = parsed._replace(query=new_query_str).geturl()
                
                try:
                    resp = requests.get(target_url, timeout=3)
                    # Simple reflection check: If payload is in response, it MIGHT be XSS
                    if payload in resp.text:
                        results["xss"].append({
                            "param": param_name,
                            "payload": payload,
                            "confidence": "Medium (Reflected)"
                        })
                        break # Found one, move to next check
                except:
                    pass

            # -- Check SQLi --
            for payload in self.sqli_payloads:
                fuzzed_query = params.copy()
                fuzzed_query[param_name] = [payload]
                new_query_str = urlencode(fuzzed_query, doseq=True)
                target_url = parsed._replace(query=new_query_str).geturl()
                
                try:
                    resp = requests.get(target_url, timeout=3)
                    # Check for common SQL errors
                    errors = ["syntax error", "mysql_fetch", "ORA-", "SQLServer"]
                    if any(e in resp.text.lower() for e in errors):
                        results["sqli"].append({
                            "param": param_name,
                            "payload": payload,
                            "confidence": "High (Error-Based)"
                        })
                        break
                except:
                    pass

        return results