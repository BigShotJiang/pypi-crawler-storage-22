class SqliteError(Exception): pass
class Error(SqliteError): pass
class Warning(SqliteError): pass

class InterfaceError(Error): pass
class DatabaseError(Error): pass

class DataError(DatabaseError): pass
class OperationalError(DatabaseError): pass
class IntegrityError(DatabaseError): pass
class InternalError(DatabaseError): pass
class ProgrammingError(DatabaseError): pass
class NotSupportedError(DatabaseError): pass
