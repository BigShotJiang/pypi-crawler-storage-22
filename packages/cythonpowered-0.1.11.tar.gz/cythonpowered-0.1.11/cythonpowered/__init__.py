VERSION = "0.1.11"
MODULES = ["random"]
