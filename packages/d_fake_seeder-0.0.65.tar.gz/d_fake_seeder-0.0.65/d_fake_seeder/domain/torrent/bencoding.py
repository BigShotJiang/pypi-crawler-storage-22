"""Helper methods to encode and decode Bencoding data."""

from typing import Any


class bencode:  # pylint: disable=invalid-name
    """Bencodepy-compatible interface wrapper (lowercase for bencodepy API compatibility)."""

    @staticmethod
    def bdecode(data: Any) -> Any:
        """Decode bencode data (bencodepy-compatible name)."""
        return decode(data)

    @staticmethod
    def bencode(data: Any) -> Any:
        """Encode data to bencode (bencodepy-compatible name)."""
        return encode(data)


def _decode(raw_buffer: Any, elements: Any, index: Any = 0) -> Any:
    if len(raw_buffer) == 0:
        return None
    if raw_buffer[index] == ord("d"):
        index += 1
        obj = {}
        while raw_buffer[index] != ord("e"):
            key = []  # type: ignore[var-annotated]
            value = []  # type: ignore[var-annotated]
            index = _decode(raw_buffer, key, index)
            index = _decode(raw_buffer, value, index)
            obj[key[0]] = value[0]
        index += 1
        elements.append(obj)
    elif raw_buffer[index] == ord("l"):
        index += 1
        list_elements = []
        while raw_buffer[index] != ord("e"):
            value = []
            index = _decode(raw_buffer, value, index)
            list_elements.append(value[0])
        index += 1
        elements.append(list_elements)
    elif raw_buffer[index] == ord("i"):
        index += 1
        pos = index + raw_buffer[index:].find(ord("e"))
        number = int(raw_buffer[index:pos])
        index = pos + 1
        elements.append(number)
    else:
        try:
            pos = index + raw_buffer[index:].find(ord(":"))
            size = int(raw_buffer[index:pos])
            index = pos + 1
            data = raw_buffer[index: index + size]  # noqa: E203
            index += size
            elements.append(data)
        except BaseException:  # pylint: disable=broad-exception-caught
            pass
    return index


def decode(raw_buffer: Any) -> Any:
    """Decode a bytes string into its corresponding data via Bencoding."""
    elements = []  # type: ignore[var-annotated]
    _decode(raw_buffer, elements)
    if len(elements) == 0:
        return None
    return elements[0]


def encode(data: Any) -> Any:
    """Encode data into a bytes string via Bencoding."""
    if isinstance(data, bytes):
        return str(len(data)).encode("ascii") + b":" + data
    if isinstance(data, str):
        return encode(data.encode("ascii"))
    if isinstance(data, int):
        return b"i" + str(data).encode("ascii") + b"e"
    if isinstance(data, list):
        result = b"l"
        for d in data:
            result += encode(d)
        result += b"e"
        return result
    if isinstance(data, dict):
        result = b"d"
        for key, value in data.items():
            result += encode(key)
            result += encode(value)
        result += b"e"
        return result

    raise ValueError("Unexpected bencode_encode() data")
