"""
Torrent File Parser Module.

This module handles parsing and extracting metadata from .torrent files,
including info hash calculation, tracker extraction, and file list parsing.
"""

# fmt: off
import hashlib
import time
from datetime import datetime
from typing import Any

from d_fake_seeder.domain.torrent import bencoding
from d_fake_seeder.lib.logger import logger
from d_fake_seeder.lib.util import helpers

# fmt: on

MAX_FILE_PARSE_RETRIES = 5


class File:
    """Parser for .torrent files extracting metadata, hashes, and tracker info."""

    def __init__(self, filepath: Any) -> None:
        logger.trace("Startup", extra={"class_name": self.__class__.__name__})
        for attempt in range(MAX_FILE_PARSE_RETRIES):
            try:
                self.filepath = filepath
                with open(filepath, "rb") as f:
                    self.raw_torrent = f.read()
                self.torrent_header = bencoding.decode(self.raw_torrent)

                if b"announce" in self.torrent_header:
                    self.announce = self.torrent_header[b"announce"].decode("utf-8")

                if b"announce-list" in self.torrent_header:
                    announce_list = self.torrent_header[b"announce-list"]
                    if isinstance(announce_list, list):
                        # Extract announce URLs from the announce-list
                        announce_urls = [url.decode("utf-8") for sublist in announce_list for url in sublist]
                        self.announce_list = announce_urls

                torrent_info = self.torrent_header[b"info"]
                m = hashlib.sha1()
                m.update(bencoding.encode(torrent_info))
                self.file_hash = m.digest()
                break
            except Exception as e:  # pylint: disable=broad-exception-caught
                logger.info(
                    f"File read error (attempt {attempt + 1}/{MAX_FILE_PARSE_RETRIES}): {e}",
                    extra={"class_name": self.__class__.__name__},
                )
                if attempt < MAX_FILE_PARSE_RETRIES - 1:
                    time.sleep(min(2**attempt, 10))
                else:
                    raise

    @property
    def total_size(self) -> Any:
        """Get total size of all files in the torrent."""
        logger.trace("File size", extra={"class_name": self.__class__.__name__})
        size = 0
        torrent_info = self.torrent_header[b"info"]
        if b"files" in torrent_info:
            # Multiple File Mode
            for file_info in torrent_info[b"files"]:
                size += file_info[b"length"]
        else:
            # Single File Mode
            size = torrent_info[b"length"]

        return size

    @property
    def name(self) -> Any:
        """Get torrent name from info dict."""
        logger.trace("File name", extra={"class_name": self.__class__.__name__})
        torrent_info = self.torrent_header[b"info"]
        return torrent_info[b"name"].decode("utf-8")

    def __str__(self) -> str:
        logger.trace("File attribute", extra={"class_name": self.__class__.__name__})
        announce = self.torrent_header[b"announce"].decode("utf-8")
        result = f"Announce: {announce}\n"

        if b"creation date" in self.torrent_header:
            try:
                creation_date = self.torrent_header[b"creation date"]
                creation_date = datetime.fromtimestamp(creation_date)
                result += f"Date: {creation_date.strftime('%Y/%m/%d %H:%M:%S')}\n"
            except (TypeError, ValueError, OSError):
                # Invalid creation date, skip it
                pass

        if b"created by" in self.torrent_header:
            created_by = self.torrent_header[b"created by"].decode("utf-8")
            result += f"Created by: {created_by}\n"

        if b"encoding" in self.torrent_header:
            encoding = self.torrent_header[b"encoding"].decode("utf-8")
            result += f"Encoding:   {encoding}\n"

        torrent_info = self.torrent_header[b"info"]
        piece_len = torrent_info[b"piece length"]
        result += f"Piece len: {helpers.sizeof_fmt(piece_len)}\n"
        pieces = len(torrent_info[b"pieces"]) / 20
        result += f"Pieces: {int(pieces)}\n"

        torrent_name = torrent_info[b"name"].decode("utf-8")
        result += f"Name: {torrent_name}\n"
        piece_len = torrent_info[b"piece length"]

        if b"files" in torrent_info:
            # Multiple File Mode
            result += "Files:\n"
            for file_info in torrent_info[b"files"]:
                fullpath = "/".join([x.decode("utf-8") for x in file_info[b"path"]])
                result += f"  '{fullpath}' ({helpers.sizeof_fmt(file_info[b'length'])})\n"
        else:
            # Single File Mode
            result += f"Length: {helpers.sizeof_fmt(torrent_info[b'length'])}\n"
            if b"md5sum" in torrent_info:
                result += f"Md5: {torrent_info[b'md5sum']}\n"

        return result

    def get_announce(self) -> Any:
        """Get primary announce URL."""
        return self.torrent_header[b"announce"].decode("utf-8")

    def get_creation_date(self) -> Any:
        """Get torrent creation date as formatted string."""
        if b"creation date" in self.torrent_header:
            try:
                creation_date = self.torrent_header[b"creation date"]
                creation_date = datetime.fromtimestamp(creation_date)
                return creation_date.strftime("%Y/%m/%d %H:%M:%S")
            except (TypeError, ValueError, OSError):
                # Invalid creation date (wrong type, out of range, etc.)
                return None
        return None

    def get_created_by(self) -> Any:
        """Get creator software/client name."""
        if b"created by" in self.torrent_header:
            return self.torrent_header[b"created by"].decode("utf-8")
        return None

    def get_encoding(self) -> Any:
        """Get torrent file encoding."""
        if b"encoding" in self.torrent_header:
            return self.torrent_header[b"encoding"].decode("utf-8")
        return None

    def get_comment(self) -> Any:
        """Get torrent comment"""
        if b"comment" in self.torrent_header:
            return self.torrent_header[b"comment"].decode("utf-8", errors="ignore")
        return None

    def get_piece_length(self) -> Any:
        """Get piece length in bytes"""
        torrent_info = self.torrent_header[b"info"]
        return torrent_info.get(b"piece length", 0)

    def get_piece_count(self) -> Any:
        """Get total number of pieces"""
        torrent_info = self.torrent_header[b"info"]
        if b"pieces" in torrent_info:
            return len(torrent_info[b"pieces"]) // 20
        return 0

    def get_info_hash_hex(self) -> Any:
        """Get info hash as hexadecimal string"""
        return self.file_hash.hex()

    def is_private(self) -> Any:
        """Check if torrent is private"""
        torrent_info = self.torrent_header[b"info"]
        return torrent_info.get(b"private", 0) == 1

    def get_file_list(self) -> Any:
        """Get list of files in the torrent"""
        torrent_info = self.torrent_header[b"info"]
        files = []

        if b"files" in torrent_info:
            # Multi-file torrent
            for file_info in torrent_info[b"files"]:
                path_parts = [part.decode("utf-8", errors="ignore") for part in file_info[b"path"]]
                files.append(
                    {
                        "path": "/".join(path_parts),
                        "size": file_info[b"length"],
                        "size_formatted": helpers.sizeof_fmt(file_info[b"length"]),
                    }
                )
        else:
            # Single file torrent
            files.append(
                {
                    "path": torrent_info[b"name"].decode("utf-8", errors="ignore"),
                    "size": torrent_info[b"length"],
                    "size_formatted": helpers.sizeof_fmt(torrent_info[b"length"]),
                }
            )

        return files

    def get_trackers(self) -> Any:
        """Get all tracker URLs"""
        trackers = []

        # Primary announce
        if b"announce" in self.torrent_header:
            trackers.append(self.torrent_header[b"announce"].decode("utf-8", errors="ignore"))

        # Announce list
        if hasattr(self, "announce_list"):
            for url in self.announce_list:
                if url not in trackers:
                    trackers.append(url)

        return trackers

    def get_num_pieces(self) -> Any:
        """Get number of pieces in torrent."""
        return len(self.torrent_header[b"info"][b"pieces"]) / 20

    def get_torrent_name(self) -> Any:
        """Get torrent name from info dict."""
        return self.torrent_header[b"info"][b"name"].decode("utf-8")

    def get_files(self) -> Any:
        """Get list of files as (path, size) tuples."""
        files = []
        if b"files" in self.torrent_header[b"info"]:
            for file_info in self.torrent_header[b"info"][b"files"]:
                fullpath = "/".join([x.decode("utf-8") for x in file_info[b"path"]])
                # Return raw byte length for consistent formatting by UI components
                files.append((fullpath, file_info[b"length"]))
        return files

    def get_single_file_info(self) -> Any:
        """Get single file size for single-file torrents."""
        if b"files" not in self.torrent_header[b"info"]:
            # Return raw byte length for consistent formatting by UI components
            return self.torrent_header[b"info"][b"length"]
        return None

    def get_md5sum(self) -> Any:
        """Get MD5 checksum if present."""
        if b"md5sum" in self.torrent_header[b"info"]:
            return self.torrent_header[b"info"][b"md5sum"]
        return None
