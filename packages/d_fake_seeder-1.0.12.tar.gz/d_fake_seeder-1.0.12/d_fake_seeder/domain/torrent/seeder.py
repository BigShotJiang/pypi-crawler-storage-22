"""
RFC: https://wiki.theory.org/index.php/BitTorrentSpecification
"""

# isort: skip_file

# fmt: off
from typing import Any
from urllib.parse import urlparse

import gi

gi.require_version("GLib", "2.0")

from gi.repository import GLib  # noqa: E402

from d_fake_seeder.domain.app_settings import AppSettings  # noqa: E402
from d_fake_seeder.domain.torrent.seeders.http_seeder import HTTPSeeder  # noqa: E402
from d_fake_seeder.domain.torrent.seeders.udp_seeder import UDPSeeder  # noqa: E402
from d_fake_seeder.lib.logger import logger  # noqa: E402

# fmt: on


class Seeder:
    """Factory/wrapper for HTTP or UDP seeder based on tracker protocol."""

    def __init__(self, torrent: Any) -> None:
        logger.trace("Startup", extra={"class_name": self.__class__.__name__})
        self.ready = False
        self.seeder = None
        self.settings = AppSettings.get_instance()
        self.check_announce_attribute(torrent)

    def check_announce_attribute(self, torrent: Any, attempts: Any = 3) -> Any:
        """Check torrent announce URL and create appropriate seeder."""
        if hasattr(torrent, "announce"):
            self.ready = True
            parsed_url = urlparse(torrent.announce)
            if parsed_url.scheme in ("http", "https"):
                self.seeder = HTTPSeeder(torrent)  # type: ignore[assignment]
            elif parsed_url.scheme == "udp":
                self.seeder = UDPSeeder(torrent)  # type: ignore[assignment]
            else:
                logger.error(
                    f"Unsupported tracker scheme: {parsed_url.scheme}",
                    extra={"class_name": self.__class__.__name__},
                )
        else:
            if attempts > 0:
                # Use tickspeed-based retry interval (minimum 1 second)
                retry_interval = max(1, int(self.settings.tickspeed / 2))
                GLib.timeout_add_seconds(retry_interval, self.check_announce_attribute, torrent, attempts - 1)
            else:
                logger.error(
                    f"Problem with torrent after retries: {torrent.filepath}",
                    extra={"class_name": self.__class__.__name__},
                )

    def load_peers(self) -> None:
        """Load peers from tracker via the seeder."""
        if self.seeder:
            return self.seeder.load_peers()
        return False  # type: ignore[return-value]

    def upload(self, uploaded_bytes: Any, downloaded_bytes: Any, download_left: Any) -> Any:
        """Send upload stats to tracker."""
        if self.seeder:
            self.seeder.upload(uploaded_bytes, downloaded_bytes, download_left)
            return None
        return False

    @property
    def peers(self) -> Any:
        """Get peer list from underlying seeder."""
        return self.seeder.peers if self.seeder is not None else 0

    @property
    def clients(self) -> Any:
        """Get client count from underlying seeder."""
        return self.seeder.clients if self.seeder is not None else 0

    @property
    def seeders(self) -> Any:
        """Get seeder count from tracker."""
        return self.seeder.seeders if self.seeder is not None else 0

    @property
    def tracker(self) -> Any:
        """Get tracker URL."""
        return self.seeder.tracker if self.seeder is not None else ""

    @property
    def leechers(self) -> Any:
        """Get leecher count from tracker."""
        return self.seeder.leechers if self.seeder is not None else 0

    def get_peer_data(self, peer_address: Any) -> Any:
        """Get comprehensive peer data for a specific peer"""
        return self.seeder.get_peer_data(peer_address) if self.seeder is not None else {}

    def is_ready(self) -> bool:
        """Check if seeder is ready (use ready attribute for simpler checks)"""
        return self.ready and self.seeder is not None

    def request_shutdown(self) -> Any:
        """Request graceful shutdown of the seeder"""
        if self.seeder:
            self.seeder.request_shutdown()

    def handle_settings_changed(self, source: Any, key: Any, value: Any) -> None:
        """Propagate settings changes to underlying seeder."""
        self.seeder.handle_settings_changed(source, key, value)  # type: ignore[attr-defined]

    def __str__(self) -> str:
        return str(self.seeder)
