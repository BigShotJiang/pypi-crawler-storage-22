"""LLM-based paper ranking."""

import asyncio
import json
import logging
import re
from typing import Any

from .models import Paper

logger = logging.getLogger(__name__)

# Default relevance score when LLM parsing fails
DEFAULT_RELEVANCE_SCORE = 5.0

# Default model names for each provider
DEFAULT_ANTHROPIC_MODEL = "claude-3-haiku-20240307"
DEFAULT_OPENAI_MODEL = "gpt-3.5-turbo"
DEFAULT_GOOGLE_MODEL = "gemini-1.5-flash"


class PaperRanker:
    """Ranks papers by relevance using LLMs."""

    def __init__(
        self,
        llm: Any,
        batch_size: int = 5,
        batch_delay: float = 1.0,
    ):
        """Initialize ranker.

        Args:
            llm: LangChain LLM instance
            batch_size: Number of papers to rank concurrently
            batch_delay: Delay in seconds between batches
        """
        self.llm = llm
        self.batch_size = batch_size
        self.batch_delay = batch_delay

    async def rank_paper(self, paper: Paper, interests: str) -> Paper:
        """Rank a single paper.

        Args:
            paper: Paper to rank
            interests: Research interests description

        Returns:
            Paper with relevance_score and relevance_reason set
        """
        authors_str = ", ".join(paper.authors[:5])
        if len(paper.authors) > 5:
            authors_str += f" +{len(paper.authors) - 5} more"

        prompt = f"""Rate this paper's relevance to a researcher with these interests:
{interests}

Paper: {paper.title}
Authors: {authors_str}
Categories: {', '.join(paper.categories)}
Abstract: {paper.abstract[:1500]}

Score from 1-10 where:
- 1-3: Not relevant
- 4-6: Somewhat relevant
- 7-8: Relevant
- 9-10: Highly relevant (direct match to interests)

Respond with ONLY a JSON object:
{{"score": <1-10>, "reason": "<brief explanation>"}}"""

        try:
            response = await self.llm.ainvoke(prompt)
            content = response.content.strip()

            # Extract JSON from response (handle markdown code blocks)
            if "```" in content:
                match = re.search(r"```(?:json)?\s*(.*?)\s*```", content, re.DOTALL)
                content = match.group(1) if match else "{}"

            result = json.loads(content)
            paper.relevance_score = float(result.get("score", DEFAULT_RELEVANCE_SCORE))
            paper.relevance_reason = result.get("reason", "")

        except (json.JSONDecodeError, KeyError, ValueError, AttributeError) as e:
            logger.warning(f"Failed to parse ranking for {paper.arxiv_id}: {e}")
            paper.relevance_score = DEFAULT_RELEVANCE_SCORE
            paper.relevance_reason = "Unable to rank"

        return paper

    async def rank_papers(self, papers: list[Paper], interests: str) -> list[Paper]:
        """Rank all papers.

        Args:
            papers: List of papers to rank
            interests: Research interests description

        Returns:
            List of ranked papers sorted by relevance_score descending
        """
        ranked_papers: list[Paper] = []

        for i in range(0, len(papers), self.batch_size):
            batch = papers[i : i + self.batch_size]
            tasks = [self.rank_paper(paper, interests) for paper in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for result in results:
                if isinstance(result, Paper):
                    ranked_papers.append(result)
                elif isinstance(result, Exception):
                    logger.error(f"Ranking error: {result}")

            # Small delay between batches
            if i + self.batch_size < len(papers):
                await asyncio.sleep(self.batch_delay)

        # Sort by relevance score descending
        ranked_papers.sort(key=lambda p: p.relevance_score, reverse=True)
        return ranked_papers


def get_llm_for_provider(
    provider: str,
    anthropic_api_key: str | None = None,
    openai_api_key: str | None = None,
    google_api_key: str | None = None,
) -> Any:
    """Get LLM instance for the specified provider.

    Args:
        provider: One of "anthropic", "openai", or "google"
        anthropic_api_key: Anthropic API key (required for anthropic provider)
        openai_api_key: OpenAI API key (required for openai provider)
        google_api_key: Google API key (required for google provider)

    Returns:
        LangChain LLM instance

    Raises:
        ValueError: If provider is unknown or API key is missing
        ImportError: If required langchain package is not installed
    """
    if provider == "anthropic":
        if not anthropic_api_key:
            raise ValueError("anthropic_api_key is required for anthropic provider")
        try:
            from langchain_anthropic import ChatAnthropic  # type: ignore[import-not-found]

            return ChatAnthropic(
                model=DEFAULT_ANTHROPIC_MODEL,
                api_key=anthropic_api_key,
                max_tokens=256,
            )
        except ImportError as e:
            raise ImportError(
                "langchain-anthropic not installed. "
                "Install with: pip install daily-research-digest[anthropic]"
            ) from e

    elif provider == "openai":
        if not openai_api_key:
            raise ValueError("openai_api_key is required for openai provider")
        try:
            from langchain_openai import ChatOpenAI  # type: ignore[import-not-found]

            return ChatOpenAI(
                model=DEFAULT_OPENAI_MODEL,
                api_key=openai_api_key,
                max_tokens=256,
            )
        except ImportError as e:
            raise ImportError(
                "langchain-openai not installed. "
                "Install with: pip install daily-research-digest[openai]"
            ) from e

    elif provider == "google":
        if not google_api_key:
            raise ValueError("google_api_key is required for google provider")
        try:
            from langchain_google_genai import (
                ChatGoogleGenerativeAI,  # type: ignore[import-not-found]
            )

            return ChatGoogleGenerativeAI(
                model=DEFAULT_GOOGLE_MODEL,
                google_api_key=google_api_key,
                max_output_tokens=256,
            )
        except ImportError as e:
            raise ImportError(
                "langchain-google-genai not installed. "
                "Install with: pip install daily-research-digest[google]"
            ) from e

    else:
        raise ValueError(f"Unknown provider: {provider}. Use 'anthropic', 'openai', or 'google'")
