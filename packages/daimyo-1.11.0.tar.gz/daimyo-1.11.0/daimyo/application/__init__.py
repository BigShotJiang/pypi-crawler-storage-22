"""Application layer - business logic and use cases."""
