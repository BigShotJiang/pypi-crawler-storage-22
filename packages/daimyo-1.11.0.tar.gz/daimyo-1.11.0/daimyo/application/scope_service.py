"""Scope resolution service for handling inheritance and sharding.

DEPRECATED: This module is kept for backward compatibility.
Import from daimyo.application.scope_resolution instead.
"""

from daimyo.application.scope_resolution import ScopeResolutionService

__all__ = ["ScopeResolutionService"]
