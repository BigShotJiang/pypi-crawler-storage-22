"""Composite infrastructure components."""

from .composite_repository import CompositeScopeRepository

__all__ = ["CompositeScopeRepository"]
