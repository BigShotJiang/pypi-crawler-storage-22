This repository is a workspace which contain multiple projects.

This document talk about some of the workflows use for releasing
part of this projects.

# `daiquiri-ui` on `pypi`

`daiquiri-ui` can be packaged as a python project in `pypi`.

## Create git tag in gitlab

The creation of a git tag is the only manual thing to do.

I will trigger automatically the release, with the gitlab workflow.

The tag have to follow the following template:

`ui-YYYY.MM.MICRO`

- `YYYY` the year of the release, in 4 digits
- `MM` the month of the release, in 1 or 2 digits (`1` and not `01`)
- `MICRO`, a number from 0 to increment for every new fix
