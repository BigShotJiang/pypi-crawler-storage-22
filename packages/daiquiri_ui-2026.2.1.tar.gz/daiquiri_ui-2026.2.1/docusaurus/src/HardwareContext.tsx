import { PropsWithChildren, useState, useCallback, useContext } from 'react';
import { Hardware, HardwareTypes } from '@esrf/daiquiri-lib';
import { registerRuntimeHook } from '@esrf/daiquiri-lib';
import { createContext } from 'react';

interface HardwareContextType {
  hardwareStorage: { [name: string]: Hardware };
  hardwareActions: {
    [name: string]: HardwareTypes.HardwareChangeActions;
  };
  hardwareSchema: {
    [name: string]: HardwareTypes.HardwareSchemaDescription | null;
  };
  actions: {
    updateHardware: (name: string, hardware: Hardware) => void;
    updateHardwareChangeActions: (
      name: string,
      actions: HardwareTypes.HardwareChangeActions
    ) => void;
    updateHardwareSchema: (
      name: string,
      schema: HardwareTypes.HardwareSchemaDescription | null
    ) => void;
  };
}

interface Props {
  [name: string]: Hardware;
}

export const HardwareContext = createContext<HardwareContextType | null>(null);

export function useHardwareContext(): HardwareContextType {
  return useContext<HardwareContextType>(HardwareContext);
}

export function useHardware(id: string): Hardware | null {
  const ctx = useHardwareContext();
  return ctx.hardwareStorage[id] ?? null;
}

export function useHardwareChangeActions(
  id: string
): HardwareTypes.HardwareChangeActions {
  const ctx = useHardwareContext();
  return (
    ctx.hardwareActions[id] ?? {
      setProperty: (name: string, value: any) => {
        return Promise.resolve();
      },
      call: (name: string, value?: any) => {
        return Promise.resolve();
      },
    }
  );
}

export function useHardwareSchema(
  hardware: { id: string; type: string } | null
): HardwareTypes.HardwareSchemaDescription | null {
  const ctx = useHardwareContext();
  if ((hardware?.id ?? null) === null) {
    return null;
  }
  return ctx.hardwareSchema[hardware.id] ?? null;
}

function useOperator() {
  return true;
}

function useScanRunning() {
  return false;
}

registerRuntimeHook({
  useHardware,
  useHardwareChangeActions,
  useHardwareSchema,
  useOperator,
  useScanRunning,
});

/**
 * Setup some hardware in the database.
 */
export default function HardwareProvider(props: PropsWithChildren<Props>) {
  const { children, ...others } = props;
  const [hardwareStorage, setHardwareStorage] =
    useState<{ [name: string]: Hardware }>(others);
  const [hardwareActions, setHardwareActions] = useState<{
    [name: string]: HardwareTypes.HardwareChangeActions;
  }>({});
  const [hardwareSchema, setHardwareSchema] = useState<{
    [name: string]: HardwareTypes.HardwareSchemaDescription;
  }>({});

  const updateHardware = useCallback((name: string, hardware: Hardware) => {
    setHardwareStorage((p) => {
      return {
        ...p,
        [name]: hardware,
      };
    });
  }, []);

  const updateHardwareChangeActions = useCallback(
    (name: string, actions: HardwareTypes.HardwareChangeActions) => {
      setHardwareActions((p) => {
        return {
          ...p,
          [name]: actions,
        };
      });
    },
    []
  );

  const updateHardwareSchema = useCallback(
    (name: string, schema: HardwareTypes.HardwareSchemaDescription | null) => {
      setHardwareSchema((p) => {
        return {
          ...p,
          [name]: schema,
        };
      });
    },
    []
  );

  return (
    <HardwareContext.Provider
      value={{
        hardwareStorage,
        hardwareActions,
        hardwareSchema,
        actions: {
          updateHardware,
          updateHardwareChangeActions,
          updateHardwareSchema,
        },
      }}
    >
      {children}
    </HardwareContext.Provider>
  );
}
