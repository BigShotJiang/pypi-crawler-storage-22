import { Children, cloneElement, isValidElement, useState } from 'react';
import type { PropsWithChildren } from 'react';
import type { Hardware, HardwareTypes } from '@esrf/daiquiri-lib';
import { useHardware, useHardwareChangeActions } from './HardwareContext';
import { Button, ButtonGroup, Col, Row } from 'react-bootstrap';

interface Props {
  names: string[];
}

/**
 * Inject hardware to the children from a list of names.
 *
 * A selector is provided on the side to the user.
 */
export default function HardwareSelector(props: PropsWithChildren<Props>) {
  const { names } = props;

  const [name, setName] = useState(names[0] ?? '');

  const hardware: Hardware = useHardware(name);
  const actions: HardwareTypes.HardwareChangeActions =
    useHardwareChangeActions(name);

  const withSelector = names.length > 1;

  return (
    <Row style={{ width: '100%', flex: '1 0 50%' }}>
      <Col xs={withSelector ? 10 : 12}>
        {Children.map(props.children, (child) => {
          return isValidElement(child)
            ? cloneElement(child, {
                ...child.props,
                hardware: {
                  ...hardware,
                  actions,
                },
              })
            : undefined;
        })}
      </Col>
      {withSelector && (
        <Col xs={2}>
          <h5>Hardware</h5>
          <ButtonGroup vertical>
            {names.map((n) => {
              return (
                <Button
                  variant={n === name ? 'primary' : 'secondary'}
                  className="font-monospace"
                  key={n}
                  onClick={() => {
                    setName(n);
                  }}
                >
                  {n}
                </Button>
              );
            })}
          </ButtonGroup>
        </Col>
      )}
    </Row>
  );
}
