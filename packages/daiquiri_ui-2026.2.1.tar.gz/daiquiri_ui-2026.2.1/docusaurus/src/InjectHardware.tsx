import { Children, cloneElement, isValidElement } from 'react';
import type { PropsWithChildren } from 'react';
import type { Hardware, HardwareTypes } from '@esrf/daiquiri-lib';
import { useHardware, useHardwareChangeActions } from './HardwareContext';
import { Alert } from 'react-bootstrap';

interface Props {
  name: string;
}

/**
 * Inject hardware to the children from it's name.
 */
export default function InjectHardware(props: PropsWithChildren<Props>) {
  const { name } = props;

  const hardware: Hardware | null = useHardware(name);
  const actions: HardwareTypes.HardwareChangeActions =
    useHardwareChangeActions(name);

  return (
    <>
      {!hardware && <Alert variant="danger">Hardware not initialized</Alert>}
      {hardware &&
        Children.map(props.children, (child) => {
          return isValidElement(child)
            ? cloneElement(child, {
                ...child.props,
                hardware: {
                  ...hardware,
                  actions,
                },
              })
            : undefined;
        })}
    </>
  );
}
