import { Hardware, HardwareTypes } from '@esrf/daiquiri-lib';
import { isEqual } from 'lodash';
import { useEffect, useRef } from 'react';

export default function StaticHardware(props: {
  name?: string;
  alias?: string;
  hardware: Hardware;
  properties?: Record<string, any>;
  callables?: Record<string, any>;
  useHardwareContext?: () => {
    actions: {
      updateHardware: (name: string, hardware: Hardware) => void;
      updateHardwareChangeActions: (
        name: string,
        actions: HardwareTypes.HardwareChangeActions
      ) => void;
      updateHardwareSchema: (
        name: string,
        schema: HardwareTypes.HardwareComponentType
      ) => void;
    };
  };
}) {
  const {
    name,
    alias = null,
    hardware,
    properties,
    callables,
    useHardwareContext = () => {
      return null;
    },
  } = props;

  const finalName = name ?? hardware.name;
  const finalAlias = alias ?? hardware.alias ?? null;

  const finalHardware: Hardware = {
    ...hardware,
    name: finalName,
    id: finalName,
    alias: finalAlias,
  };

  const ctx = useHardwareContext();

  const previousHardware = useRef<Hardware | null>(null);

  useEffect(() => {
    if (
      previousHardware.current === null ||
      !isEqual(previousHardware.current, finalHardware)
    ) {
      previousHardware.current = finalHardware;
      ctx?.actions.updateHardware(name, finalHardware);
    }
  }, [name, finalHardware]);

  useEffect(() => {
    const schema =
      !!properties && !!callables ? { properties, callables } : null;
    console.log(finalName, schema);
    ctx?.actions.updateHardwareSchema(finalName, schema);
  }, [finalName, properties, callables]);

  return <></>;
}
