import { useState } from 'react';
import { Button, ButtonGroup, Col, Row } from 'react-bootstrap';
import { HardwareComponentType } from '@esrf/daiquiri-lib';
import { Hardware, HardwareTypes } from '@esrf/daiquiri-lib';

interface Props {
  options?: any;
  variants: {
    [name: string]: HardwareComponentType;
  };
  hardware: HardwareTypes.EditableHardware<Hardware>;
}

/**
 * Display and select a HardwareComponentType based on an
 * available list of variant mapping.
 */
export default function VariantSelector(props: Props) {
  const { variants, hardware, options = {} } = props;
  const [variant, setVariant] = useState('default');

  const Comp = variants[variant];

  return (
    <Row style={{ width: '100%', flex: '1 0 50%' }}>
      <Col xs={10}>
        {Comp && (
          <Comp
            hardware={hardware}
            options={options}
            operator={true}
            disabled={false}
            schema={undefined}
          />
        )}
      </Col>
      <Col xs={2}>
        <h5>Variants</h5>
        <ButtonGroup vertical>
          {Object.keys(variants).map((name) => {
            return (
              <Button
                variant={name === variant ? 'primary' : 'secondary'}
                className="font-monospace"
                key={name}
                onClick={() => {
                  setVariant(name);
                }}
              >
                {name}
              </Button>
            );
          })}
        </ButtonGroup>
      </Col>
    </Row>
  );
}
