import { Children, cloneElement, isValidElement, useState } from 'react';
import type { PropsWithChildren } from 'react';
import { ListGroup, Button } from 'react-bootstrap';
import type { HardwareTypes } from '@esrf/daiquiri-lib';

interface Event {
  kind: 'call' | 'setProperty';
  event: any;
}

interface Props {
  showActions: boolean;
}

/**
 * Wrap hardware widget passed as children with addToast and hardware
 * change actions triggering console log.
 */
export default function Wrapper(props: PropsWithChildren<Props>) {
  const { showActions = false } = props;

  const [actions, setActions] = useState<Event[]>([]);

  function call(name: string, value?: any) {
    const event = { type: 'call', name, value };
    if (showActions) {
      setActions([{ kind: 'call', event }, ...actions]);
    } else {
      console.log('Request change:', 'call', name, value);
    }
    return Promise.resolve();
  }

  function setProperty(name: string, value: any) {
    const event = { type: 'setProperty', name, value };
    if (showActions) {
      setActions([{ kind: 'setProperty', event }, ...actions]);
    } else {
      console.log('Request change:', event);
    }
    return Promise.resolve();
  }

  const hardwareActions: HardwareTypes.HardwareChangeActions = {
    setProperty,
    call,
  };

  return (
    <>
      {Children.map(props.children, (child) => {
        return isValidElement(child)
          ? cloneElement(child, {
              ...child.props,
              hardware: {
                actions: hardwareActions,
                ...child.props.hardware,
              },
            })
          : undefined;
      })}
      {actions.length > 0 && (
        <div>
          <Button
            onClick={() => {
              setActions([]);
            }}
          >
            Clear
          </Button>
          <ListGroup variant="flush">
            {actions.map((v, index) => {
              return (
                <ListGroup.Item
                  variant="secondary"
                  className="text-monospace"
                  key={index}
                >
                  {v.kind} {JSON.stringify(v.event)}
                </ListGroup.Item>
              );
            })}
          </ListGroup>
        </div>
      )}
    </>
  );
}
