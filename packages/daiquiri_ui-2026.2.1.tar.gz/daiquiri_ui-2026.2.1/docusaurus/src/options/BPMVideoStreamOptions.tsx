import { OptionsBPMVideoStream } from 'daiquiri-ui/src/components/general/BPMVideoStream';

export default function BPMVideoStreamOptions(props: OptionsBPMVideoStream) {
  return null;
}
