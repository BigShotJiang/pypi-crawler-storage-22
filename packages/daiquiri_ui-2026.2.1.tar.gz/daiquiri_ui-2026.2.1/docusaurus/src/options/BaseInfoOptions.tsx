import type { BaseInfoWidgetOptions as OptionsType } from '@esrf/daiquiri-lib';

export function BaseInfoOptions(props: OptionsType) {
  return null;
}
