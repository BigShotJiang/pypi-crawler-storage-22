import type { BaseNameWidgetOptions as OptionsType } from '@esrf/daiquiri-lib';

export function BaseNameOptions(props: OptionsType) {
  return null;
}
