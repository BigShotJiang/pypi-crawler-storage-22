import type { BasePropertyWidgetOptions as OptionsType } from '@esrf/daiquiri-lib';

export function BasePropertyOptions(props: OptionsType) {
  return null;
}
