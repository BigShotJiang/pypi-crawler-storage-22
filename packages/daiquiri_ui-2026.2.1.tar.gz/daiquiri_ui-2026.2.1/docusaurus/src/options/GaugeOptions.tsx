import type { GaugeWidgetOptions as OptionsType } from '@esrf/daiquiri-lib';

export function GaugeOptions(props: OptionsType) {
  return null;
}
