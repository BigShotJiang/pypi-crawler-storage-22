import type { Props } from 'daiquiri-ui/src/components/hardware/HardwareGroup';

export function HardwareGroupOptions(props: Props) {
  return null;
}
