import type { LaserHeatingWidgetOptions as OptionsType } from '@esrf/daiquiri-lib';

export function LaserHeatingOptions(props: OptionsType) {
  return null;
}
