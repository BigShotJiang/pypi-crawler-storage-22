import type { LaserWidgetOptions as OptionsType } from '@esrf/daiquiri-lib';

export function LaserOptions(props: OptionsType) {
  return null;
}
