import type { MotorDefaultOptions as MotorDefaultOptionsType } from '@esrf/daiquiri-lib';

export function MotorDefaultOptions(props: MotorDefaultOptionsType) {
  return null;
}
