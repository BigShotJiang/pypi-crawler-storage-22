import type { MotorTomoRotationOptions as MotorTomoRotationOptionsType } from 'daiquiri-ui/src/components/hardware/motor/MotorTomoRotation';

export function MotorTomoRotationOptions(props: MotorTomoRotationOptionsType) {
  return null;
}
