import type { OpticWidgetOptions as OptionsType } from '@esrf/daiquiri-lib';

export function OpticOptions(props: OptionsType) {
  return null;
}
