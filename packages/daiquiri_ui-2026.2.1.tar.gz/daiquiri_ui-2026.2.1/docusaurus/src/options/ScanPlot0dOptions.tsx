import { Options0d } from 'daiquiri-ui/src/components/scans/ScanPlot0d';

export default function ScanPlot0dOptions(props: Options0d) {
  return null;
}
