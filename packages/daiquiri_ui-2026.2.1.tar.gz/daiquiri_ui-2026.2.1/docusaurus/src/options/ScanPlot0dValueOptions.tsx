import type { ScanPlot0dValueOptions as ScanPlot0dValueOptionsType } from 'daiquiri-ui/src/components/scans/ScanPlot0dValue';

export default function ScanPlot0dValueOptions(
  props: ScanPlot0dValueOptionsType
) {
  return '';
}
