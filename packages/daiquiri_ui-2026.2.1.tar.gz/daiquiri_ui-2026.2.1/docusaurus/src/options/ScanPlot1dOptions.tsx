import { Options1d } from 'daiquiri-ui/src/components/scans/ScanPlot1d';

export default function ScanPlot1dOptions(props: Options1d) {
  return null;
}
