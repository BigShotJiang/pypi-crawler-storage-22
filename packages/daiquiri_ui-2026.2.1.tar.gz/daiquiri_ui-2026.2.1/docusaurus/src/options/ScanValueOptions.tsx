import type { ScanValueOptions as ScanValueOptionsType } from 'daiquiri-ui/src/components/scans/ScanValue';

export default function ScanValueOptions(props: ScanValueOptionsType) {
  return '';
}
