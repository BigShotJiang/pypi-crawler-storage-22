export interface OptionsType {
  /**
   * A path to an object from the environment on which to call a function.
   *
   * It's basically what you would type in the BLISS shell to get the object on which call the function.
   *
   * For example: `my_loaded_script.my_object.a_sub_object`
   */
  env_id?: string;

  /**
   * A name of a registered object
   *
   * For example: `$roby`
   */
  id?: string;

  /** The function to call */
  function: string;

  /**
   * A list of arguments, special types can be handled with jsonready
   */
  args: unknown[];

  /** A dictionary of kwargs, special types can be handled with jsonready
   */
  kwargs: Record<string, unknown>;

  /** If true, the call is executed inside the BLISS terminal.
   * If the terminal is busy an exception is raised.
   */
  in_terminal?: boolean;

  /** The label of the button */
  label?: string;

  /**
   * The icon of the button.
   *
   * A fontawsome icon name + more from our custom fontawsome library.
   *
   * For example: `fa-arrow-up` */
  icon?: string;

  /** If true, disable the object */
  readonly: boolean;

  /** A bootstrap variant, for the color of the button */
  variant?: string;
}

export function SessionButtonOptions(props: OptionsType) {
  return null;
}
