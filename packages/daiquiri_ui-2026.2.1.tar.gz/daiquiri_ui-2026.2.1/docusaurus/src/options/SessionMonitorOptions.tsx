export interface OptionsType {
  /** A path to an object from the environment on which to call a function */
  env_id?: string;
  /** A name of a registered object */
  id?: string;
  /** The function to call */
  function: string;
  /**
   * A list of arguments, special types can be handled with jsonready
   */
  args?: unknown[];
  /** A dictionary of kwargs, special types can be handled with jsonready
   */
  kwargs?: Record<string, unknown>;

  /** Formatter if the result is a float */
  digits?: number;

  /** Formating `None` as an empty string */
  none_as_empty?: boolean;

  /** Unit tailed, in the case of a number */
  unit?: string;

  /** Coeficient to apply to the result, in the case of a number */
  coef?: number;

  /** An icon like `fa-arrow-up` */
  icon?: string;

  /**
   * Allow to highlight the button with a set of colors
   *
   * Can be one of: 'primary', 'secondary', 'warning', 'danger', 'info'
   */
  variant?: string;

  /** Display a tooltip on the widget */
  tooltip?: string;

  /**
   * The function will be called every 'period' of time
   */
  polling_period: number;
}

export function SessionMonitorOptions(props: OptionsType) {
  return null;
}
