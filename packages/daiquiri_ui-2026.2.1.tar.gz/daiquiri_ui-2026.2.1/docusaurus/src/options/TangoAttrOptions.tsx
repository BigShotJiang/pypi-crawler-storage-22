import type { TangoAttrOptions as TangoAttrOptionsType } from 'daiquiri-ui/src/components/hardware/tangoattr/TangoAttr';

export function TangoAttrOptions(props: TangoAttrOptionsType) {
  return null;
}
