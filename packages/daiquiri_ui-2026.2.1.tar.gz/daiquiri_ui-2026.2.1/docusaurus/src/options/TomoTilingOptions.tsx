import { TomoTilingOptions as TomoTilingOptionsType } from 'daiquiri-ui/src/components/tomo/TomoTiling';

export default function TomoTilingOptions(props: TomoTilingOptionsType) {
  return null;
}
