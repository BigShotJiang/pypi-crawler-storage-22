import type { TypeIconOptions as TypeIconOptionsType } from '@esrf/daiquiri-lib';

export function TypeIconOptions(props: TypeIconOptionsType) {
  return null;
}
