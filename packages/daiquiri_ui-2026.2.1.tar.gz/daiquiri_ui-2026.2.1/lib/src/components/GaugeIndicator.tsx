import { useMemo } from 'react';
import { Knob, Pointer, Power, Value } from '@vallsv/rc-knob';

export default function Gauge(props: {
  size: number;
  value: number | null;
  min: number;
  max: number;
  lowWarning?: number;
  hiWarning?: number;
  lowDanger?: number;
  hiDanger?: number;
}) {
  const { size, value, min, max, lowWarning, hiWarning, lowDanger, hiDanger } =
    props;

  function toPercent(v: number | null): number | null {
    if (v === null) {
      return null;
    }
    return (v - min) / (max - min);
  }

  const geometry = useMemo(() => {
    const lowPercentDanger =
      lowDanger === undefined ? undefined : toPercent(lowDanger);
    const hiPercentDanger =
      hiDanger === undefined ? undefined : toPercent(hiDanger);
    const lowPercentWarning =
      lowWarning === undefined ? undefined : toPercent(lowWarning);
    const hiPercentWarning =
      hiWarning === undefined ? undefined : toPercent(hiWarning);
    return {
      lowPercentDanger,
      hiPercentDanger,
      lowPercentWarning,
      hiPercentWarning,
    };
  }, [min, max, lowWarning, hiWarning, lowDanger, hiDanger]);

  const valueClassName = useMemo(() => {
    if (value === null) {
      return 'value';
    }
    if (lowDanger !== undefined && value <= lowDanger) {
      return 'value value-danger';
    }
    if (hiDanger !== undefined && value >= hiDanger) {
      return 'value value-danger';
    }
    if (lowWarning !== undefined && value <= lowWarning) {
      return 'value value-warning';
    }
    if (hiWarning !== undefined && value >= hiWarning) {
      return 'value value-warning';
    }
    return 'value';
  }, [value, lowDanger, hiDanger, lowWarning, hiWarning]);

  const powerRadius = size / 2 - 15;
  const width0 = size / 10;
  const width100 = (size / 10) * 3;

  function getWidth(p: number): number {
    return width0 + (width100 - width0) * p;
  }

  return (
    <Knob
      size={size}
      angleOffset={240}
      angleRange={240}
      min={min}
      max={max}
      value={value}
      readOnly
      className="gauge"
    >
      {geometry.lowPercentDanger && (
        <Power
          radiusFrom={powerRadius}
          radiusTo={powerRadius}
          className="range range-danger"
          percentageFrom={0}
          percentageTo={geometry.lowPercentDanger}
          widthFrom={getWidth(0)}
          widthTo={getWidth(geometry.lowPercentDanger)}
        />
      )}
      {geometry.lowPercentWarning && (
        <Power
          radiusFrom={powerRadius}
          radiusTo={powerRadius}
          className="range range-warning"
          percentageFrom={geometry.lowPercentDanger ?? 0}
          percentageTo={geometry.lowPercentWarning}
          widthFrom={getWidth(geometry.lowPercentDanger ?? 0)}
          widthTo={getWidth(geometry.lowPercentWarning)}
        />
      )}
      <Power
        radiusFrom={powerRadius}
        radiusTo={powerRadius}
        className="range"
        percentageFrom={
          geometry.lowPercentWarning ?? geometry.lowPercentDanger ?? 0
        }
        percentageTo={
          geometry.hiPercentWarning ?? geometry.hiPercentDanger ?? 1
        }
        widthFrom={getWidth(
          geometry.lowPercentWarning ?? geometry.lowPercentDanger ?? 0
        )}
        widthTo={getWidth(
          geometry.hiPercentWarning ?? geometry.hiPercentDanger ?? 1
        )}
      />
      {geometry.hiPercentWarning && (
        <Power
          radiusFrom={powerRadius}
          radiusTo={powerRadius}
          className="range range-warning"
          percentageFrom={geometry.hiPercentWarning}
          percentageTo={geometry.hiPercentDanger ?? 1}
          widthFrom={getWidth(geometry.hiPercentWarning)}
          widthTo={getWidth(geometry.hiPercentDanger ?? 1)}
        />
      )}
      {geometry.hiPercentDanger && (
        <Power
          radiusFrom={powerRadius}
          radiusTo={powerRadius}
          className="range range-danger"
          percentageFrom={geometry.hiPercentDanger}
          percentageTo={1}
          widthFrom={getWidth(geometry.hiPercentDanger)}
          widthTo={getWidth(1)}
        />
      )}
      <circle r={size / 20} cx={size / 2} cy={size / 2} fill="black" />
      <Pointer
        percentage={toPercent(value)}
        width={10}
        height={size / 2 - 15}
        radius={2}
        type="triangle"
        color="black"
      />
      <Value className={valueClassName} value={value} />
    </Knob>
  );
}
