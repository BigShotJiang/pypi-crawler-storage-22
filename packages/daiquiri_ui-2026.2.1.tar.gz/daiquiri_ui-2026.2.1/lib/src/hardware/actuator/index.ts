import type { Hardware } from '../utils/types';

/**
 * Hardware as exposed by Redux
 */
export type ActuatorSchema = Hardware<{
  state: string;
}>;
