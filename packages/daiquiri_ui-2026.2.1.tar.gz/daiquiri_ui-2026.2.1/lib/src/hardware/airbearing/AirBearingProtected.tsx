import {
  Button,
  ButtonGroup,
  Col,
  Container,
  Dropdown,
  InputGroup,
  Row,
} from 'react-bootstrap';
import type {
  HardwareWidgetProps,
  HardwareWidgetOptions,
  EditableHardware,
} from '../utils/types';
import TypeIcon from '../utils/TypeIcon';
import HardwareTemplate from '../utils/HardwareTemplate';
import { AirBearingState } from './AirBearingState';
import type { AirBearingSchema } from '.';
import ReadOnlyTextInput from '../../components/ReadOnlyTextInput';
import type { PropsWithChildren } from 'react';

function ActionButton(
  props: PropsWithChildren<{
    icon: string;
    isActive?: boolean;
    wasActivated: boolean;
    disabled: boolean;
    onClick: () => void;
    title: string;
  }>
) {
  return (
    <Button
      variant={
        props.isActive
          ? 'primary'
          : props.wasActivated
          ? 'warning'
          : 'secondary'
      }
      onClick={props.onClick}
      disabled={props.disabled || props.wasActivated}
      title={props.title}
    >
      <Row className="gx-0">
        <i
          className={`col-sm-4 justify-content-center align-self-center ${props.icon}`}
        />
        <Col sm="8">{props.children}</Col>
      </Row>
    </Button>
  );
}

function DropdownAirBearing(props: {
  hardware: EditableHardware<AirBearingSchema>;
  options: HardwareWidgetOptions;
  disabled: boolean;
}) {
  const { hardware, options = {}, disabled } = props;
  function requestOn() {
    void hardware.actions.call('on');
  }

  function requestOff() {
    void hardware.actions.call('off');
  }

  const state = hardware.properties?.state ?? 'UNKNOWN';
  const hardwareDisabled = state === 'MOVING_ON' || state === 'MOVING_OFF';
  const isOn = state === 'ON';
  const isOff = state === 'OFF';
  const movingOn = state === 'MOVING_ON';
  const movingOff = state === 'MOVING_OFF';

  return (
    <Dropdown>
      <Dropdown.Toggle
        variant="secondary"
        disabled={disabled || hardwareDisabled}
      />
      <Dropdown.Menu popperConfig={{ strategy: 'fixed' }}>
        <Container>
          <Row>
            <Col className="text-center">Actions</Col>
          </Row>
          <Row>
            <Col>
              <ButtonGroup>
                <ActionButton
                  icon="fa fa-arrow-up"
                  wasActivated={movingOn}
                  onClick={() => {
                    requestOn();
                  }}
                  disabled={disabled || hardwareDisabled}
                  title="Turn on the air bearing"
                >
                  Turn
                  <br />
                  on
                </ActionButton>
                <ActionButton
                  icon="fa fa-arrow-down"
                  wasActivated={movingOff}
                  onClick={() => {
                    requestOff();
                  }}
                  disabled={disabled || hardwareDisabled}
                  title="Turn off the air bearing"
                >
                  Turn
                  <br />
                  off
                </ActionButton>
              </ButtonGroup>
            </Col>
          </Row>
        </Container>
      </Dropdown.Menu>
    </Dropdown>
  );
}

function RawAirBearing(props: {
  hardware: EditableHardware<AirBearingSchema>;
  options: HardwareWidgetOptions;
  disabled: boolean;
}) {
  const { hardware, options, disabled } = props;
  const { state } = hardware.properties ?? 'OFFLINE';

  const variants: { [state: string]: string } = {
    ON: 'success',
    OFF: 'danger',
    MOVING_ON: 'transiant',
    MOVING_OFF: 'transiant',
    UNKNOWN: 'fatal',
    OFFLINE: 'warning',
  };
  const variant = variants[state] ?? 'fatal';

  return (
    <InputGroup className="d-flex flex-nowrap">
      <ReadOnlyTextInput
        variant={variant}
        className="text-center"
        style={{ minWidth: '10em' }}
        value={state}
      />
      <DropdownAirBearing {...props} />
    </InputGroup>
  );
}

export default function AirBearingProtected(
  props: HardwareWidgetProps<AirBearingSchema, HardwareWidgetOptions>
) {
  const { hardware, options = {} } = props;
  const widgetIcon = (
    <TypeIcon
      name="Air bearing"
      icon="fa-hand-point-right"
      online={hardware.online}
    />
  );

  const widgetState = <AirBearingState hardware={hardware} />;

  function getWidgetContent() {
    return <RawAirBearing {...props} />;
  }

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={getWidgetContent()}
      headerMode={headerMode}
    />
  );
}
