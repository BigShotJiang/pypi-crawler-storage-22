import { HardwareState } from '../utils/State';
import type { AirBearingSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function AirBearingState(props: { hardware: AirBearingSchema }) {
  const { hardware } = props;
  const state = hardware.online ? hardware.properties.state : 'OFFLINE';
  const variants: { [state: string]: string } = {
    ON: 'success',
    OFF: 'danger',
    MOVING_ON: 'transiant',
    MOVING_OFF: 'transiant',
    UNKNOWN: 'fatal',
    OFFLINE: 'warning',
  };
  const variant = variants[state] || variants.UNKNOWN;
  return <HardwareState state={state} minWidth={6} variant={variant} />;
}

export default function DefaultState(
  props: HardwareWidgetProps<AirBearingSchema>
) {
  const { hardware } = props;
  return <AirBearingState hardware={hardware} />;
}
