import type { Hardware, HardwareVariant } from '../utils/types';
import AirBearing from './AirBearing';
import AirBearingProtected from './AirBearingProtected';
import AirBearingState from './AirBearingState';

/**
 * Hardware as exposed by Redux
 */
export type AirBearingSchema = Hardware<{
  state: string;
}>;

const Variants: HardwareVariant<AirBearingSchema> = {
  default: AirBearing,
  protected: AirBearingProtected,
  // Override base state
  state: AirBearingState,
};

export default Variants;
