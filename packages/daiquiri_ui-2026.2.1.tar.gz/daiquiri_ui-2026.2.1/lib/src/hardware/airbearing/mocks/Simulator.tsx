import { useState } from 'react';
import { Simulator, delay } from '../../base/mocks/Simulator';
import type { PropsWithSimulator } from '../../base/mocks/Simulator';

export default function AirBearingSimulator(props: PropsWithSimulator) {
  const { name, alias, useHardwareContext } = props;
  const [state, setState] = useState('ON');

  async function call(name: string, value?: any): Promise<void> {
    if (name === 'on') {
      setState('MOVING_ON');
      await delay(2000);
      setState('ON');
      return;
    }
    if (name === 'off') {
      setState('MOVING_OFF');
      await delay(2000);
      setState('OFF');
      return;
    }
    console.log('AirBearingSimulator: Unsupported call', name, value);
  }

  async function setProperty(name: string, value: any): Promise<void> {
    console.log('AirBearingSimulator: Unsupported setProperty', name, value);
  }

  const properties = {
    state,
  };

  return (
    <Simulator
      name={name}
      alias={alias}
      type="tomoflatmotion"
      call={call}
      setProperty={setProperty}
      properties={properties}
      useHardwareContext={useHardwareContext}
    />
  );
}
