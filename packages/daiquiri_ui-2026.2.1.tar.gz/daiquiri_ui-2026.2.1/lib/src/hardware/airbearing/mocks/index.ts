import defaultjson from './AirBearing.json';

export const Mocks = {
  default: defaultjson,
};
