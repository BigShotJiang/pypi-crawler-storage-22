import type {
  HardwareWidgetProps,
  HardwareWidgetOptions,
} from '../utils/types';
import type { AnySchema } from '../utils/schema';

export interface BaseInfoWidgetOptions extends HardwareWidgetOptions {
  /** The property */
  property?: string;
  /** Unit for the property */
  unit?: string;
}

export default function Info(
  props: HardwareWidgetProps<AnySchema, BaseInfoWidgetOptions>
) {
  const { hardware, options = {} } = props;
  function getValue() {
    const propertyName = options.property;
    if (propertyName === undefined) {
      return `property is not set`;
    }
    if (propertyName === null) {
      return `property is null`;
    }
    let result: any = hardware;
    for (const segment of propertyName.split('/')) {
      result = result[segment];
      if (result === undefined) {
        return `property '${propertyName}' not found`;
      }
    }
    return `${result}`;
  }

  return <>{getValue()}</>;
}
