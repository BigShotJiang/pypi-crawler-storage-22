import type { AnyHardware } from '../utils/types';
import type { HardwareWidgetProps } from '../utils/types';
import type { AnySchema } from '../utils/schema';
import { Badge } from 'react-bootstrap';

export function AnyHardwareState(props: { hardware: AnyHardware }) {
  const { hardware } = props;
  const { online, locked = null } = hardware;
  const state = online
    ? (locked !== null ? 'LOCKED' : hardware.properties?.state) || 'UNKNOWN'
    : 'OFFLINE';

  // Try to catch some common state name
  const variantMapping: { [name: string]: string } = {
    READY: 'success',
    OFFLINE: 'secondary',
    MOVING: 'transiant',
    DISABLED: 'secondary',
    UNKNOWN: 'danger',
    ERROR: 'danger',
    FAILED: 'danger',
    LOCKED: 'warning',
  };

  const variant = variantMapping[state] || 'success';

  return <Badge bg={variant}>{state}</Badge>;
}

export default function DefaultState(props: HardwareWidgetProps<AnySchema>) {
  const { hardware } = props;
  return <AnyHardwareState hardware={hardware} />;
}
