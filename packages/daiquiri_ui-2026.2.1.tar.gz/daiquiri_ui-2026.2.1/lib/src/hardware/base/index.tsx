import type { HardwareVariant } from '../utils/types';
import type { AnySchema } from '../utils/schema';
import BaseState from './BaseState';
import BaseName from './BaseName';
import BaseInfo from './BaseInfo';
import BaseProperty from './BaseProperty';

const Variants: HardwareVariant<AnySchema> = {
  state: BaseState,
  name: BaseName,
  info: BaseInfo,
  property: BaseProperty,
};

export default Variants;
