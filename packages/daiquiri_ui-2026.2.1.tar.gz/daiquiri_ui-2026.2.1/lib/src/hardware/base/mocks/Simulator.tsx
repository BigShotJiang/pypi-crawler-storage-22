import { useEffect, useMemo, useRef } from 'react';
import type {
  Hardware,
  EditableHardware,
  HardwareChangeActions,
} from '../../utils/types';
import { isEqual } from 'lodash';

export async function delay(ms: number) {
  await new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

export type PropsWithSimulator<P = Record<string, never>> = P & {
  name: string;
  alias?: string;
  useHardwareContext?: () => {
    actions: {
      updateHardware: (name: string, hardware: Hardware) => void;
      updateHardwareChangeActions: (
        name: string,
        actions: HardwareChangeActions
      ) => void;
    };
  };
};

export function Simulator(props: {
  name: string;
  alias?: string | null;
  type: string;
  call: (name: string, value?: any) => Promise<void>;
  setProperty: (name: string, value: any) => Promise<void>;
  properties: { [name: string]: any };
  useHardwareContext?: () => {
    actions: {
      updateHardware: (name: string, hardware: Hardware) => void;
      updateHardwareChangeActions: (
        name: string,
        actions: HardwareChangeActions
      ) => void;
    };
  };
}) {
  const {
    name,
    alias = null,
    type,
    setProperty,
    call,
    properties,
    useHardwareContext = () => {
      return null;
    },
  } = props;

  const ctx = useHardwareContext();

  const actions: HardwareChangeActions = useMemo(() => {
    const actions = {
      setProperty,
      call,
    };
    ctx?.actions.updateHardwareChangeActions?.(name, actions);
    return actions;
  }, []);

  const hardware: EditableHardware<Hardware> = {
    id: name,
    name,
    alias,
    online: true,
    properties,
    type,
    actions,
    user_tags: [],
    locked: null,
  };

  const previousHardware = useRef<EditableHardware<Hardware> | null>(null);

  useEffect(() => {
    if (
      previousHardware.current === null ||
      !isEqual(previousHardware.current, hardware)
    ) {
      previousHardware.current = hardware;
      ctx?.actions.updateHardware(name, hardware);
    }
  }, [name, hardware]);

  return <></>;
}
