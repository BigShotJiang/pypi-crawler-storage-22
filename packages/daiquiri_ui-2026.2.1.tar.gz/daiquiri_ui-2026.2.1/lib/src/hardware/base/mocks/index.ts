import defaultjson from './Default.json';

export const Mocks = {
  default: defaultjson,
};
