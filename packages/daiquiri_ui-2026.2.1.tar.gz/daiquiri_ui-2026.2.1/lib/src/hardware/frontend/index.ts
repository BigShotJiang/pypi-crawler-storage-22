import type { HardwareVariant } from '../utils/types';
import type { Hardware } from '../utils/types';
import Frontend from './Frontend';

export type FrontendSchema = Hardware<{
  state: string;
  status: string;
  automatic: boolean;
  frontend: string;
  // current intensity
  current: number;
  // number of seconds since the last refill
  refill: number;
  mode: string;
  message: string;
  feitlk: string;
  pssitlk: string;
  expitlk: string;
}>;

const Variants: HardwareVariant<FrontendSchema> = {
  default: Frontend,
};

export default Variants;
