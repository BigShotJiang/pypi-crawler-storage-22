import defaultjson from './FrontEnd.json';

export const Mocks = {
  default: defaultjson,
};
