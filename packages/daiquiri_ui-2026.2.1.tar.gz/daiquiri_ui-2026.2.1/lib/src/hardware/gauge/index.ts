import type { Hardware, HardwareVariant } from '../utils/types';
import Gauge from './Gauge';

/**
 * Hardware as exposed by Redux
 */
export type GaugeSchema = Hardware<{
  state: string;
  status: string;
  pressure: number;
  unit?: string; // FIXME: The server implementation is missing
}>;

const Variants: HardwareVariant<GaugeSchema> = {
  default: Gauge,
};

export default Variants;
