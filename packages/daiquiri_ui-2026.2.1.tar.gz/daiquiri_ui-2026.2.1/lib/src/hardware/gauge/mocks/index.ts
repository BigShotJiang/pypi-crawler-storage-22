import defaultjson from './Gauge.json';
import defaultjson2 from './Gauge2.json';

export const Mocks = {
  default: defaultjson,
  default2: defaultjson2,
};
