import type { Hardware, HardwareVariant } from '../utils/types';
import Laser from './Laser';

/**
 * Hardware as exposed by Redux
 */
export type LaserSchema = Hardware<{
  state: string;
  power: number;
}>;

const Variants: HardwareVariant<LaserSchema> = {
  default: Laser,
};

export default Variants;
