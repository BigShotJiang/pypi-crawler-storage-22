import defaultjson from './Laser.json';

export const Mocks = {
  default: defaultjson,
};
