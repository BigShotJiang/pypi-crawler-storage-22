import type { Hardware, HardwareVariant } from '../utils/types';
import LaserHeating from './LaserHeating';

/**
 * Hardware as exposed by Redux
 */
export type LaserHeatingSchema = Hardware<{
  state: string;
  exposure_time: number;
  background_mode: 'ON' | 'OFF' | 'ALWAYS';
  fit_wavelength: number[];
  current_calibration: string;
}>;

const Variants: HardwareVariant<LaserHeatingSchema> = {
  default: LaserHeating,
};

export default Variants;
