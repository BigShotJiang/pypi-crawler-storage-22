import defaultjson from './LaserHeating.json';

export const Mocks = {
  default: defaultjson,
};
