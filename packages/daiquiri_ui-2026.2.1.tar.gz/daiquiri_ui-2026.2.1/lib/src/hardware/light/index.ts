import type { Hardware, HardwareVariant } from '../utils/types';
import Light from './Light';

/**
 * Hardware as exposed by Redux
 */
export type LightSchema = Hardware<{
  state: string;
  temperature: number;
  intensity: number;
}>;

const Variants: HardwareVariant<LightSchema> = {
  default: Light,
};

export default Variants;
