import defaultjson from './Light.json';

export const Mocks = {
  default: defaultjson,
};
