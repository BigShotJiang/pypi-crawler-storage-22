import { InputGroup, Button, Dropdown, Badge } from 'react-bootstrap';
import type {
  HardwareWidgetProps,
  EditableHardwareWidgetOptions,
} from '../utils/types';
import TypeIcon from '../utils/TypeIcon';
import HardwareTemplate from '../utils/HardwareTemplate';
import { limaBinningModeSupported } from '.';
import type { LimaSchema } from '.';
import { LimaState } from './LimaState';
import ReadOnlyTextInput from '../../components/ReadOnlyTextInput';

/** Size of longest text mode, in order to not change the size of the widget */
const LONGEST_MODE_WIDTH = '4.2em';

function DropdownBinning(props: HardwareWidgetProps<LimaSchema>) {
  const { hardware } = props;
  const { properties } = hardware;
  const hardwareReady = properties.state === 'READY';
  const disabled = props.disabled || !hardware.online || !hardwareReady;
  const binningMode = properties.binning_mode ?? 'SUM';

  function SelectableItem(props: {
    binningMode: string;
    selectedMode: string;
    title: string;
  }) {
    const { binningMode, selectedMode, title } = props;
    const selected = binningMode === selectedMode;
    const icon = selected ? 'fa fa-fw fa-dot-circle-o' : 'fa fa-fw fa-circle-o';

    return (
      <Dropdown.Item
        key={binningMode}
        disabled={disabled}
        onClick={() => {
          void hardware.actions.setProperty('binning_mode', binningMode);
        }}
        title={title}
      >
        <i className={icon} />
        &nbsp;{' '}
        <Badge style={{ minWidth: LONGEST_MODE_WIDTH }}>{binningMode}</Badge>
      </Dropdown.Item>
    );
  }

  return (
    <Dropdown>
      <Dropdown.Toggle disabled={disabled} variant="secondary" />
      <Dropdown.Menu align="end" popperConfig={{ strategy: 'fixed' }}>
        <SelectableItem
          binningMode="SUM"
          selectedMode={binningMode}
          title="Merge binned pixel with SUM operation"
        />
        <SelectableItem
          binningMode="MEAN"
          selectedMode={binningMode}
          title="Merge binned pixel with MEAN operation"
        />
      </Dropdown.Menu>
    </Dropdown>
  );
}

function LimaBinningControl(
  props: HardwareWidgetProps<LimaSchema, EditableHardwareWidgetOptions>
) {
  const { hardware, options, disabled } = props;
  const { properties } = hardware;
  const [bh, bv] = properties.binning;
  const b = bh === bv ? bh : 0;
  const binningMode = properties.binning_mode ?? 'SUM';

  function setBinning(value: number) {
    void hardware.actions.setProperty('binning', [value, value]);
  }

  const supportedBinningMode = limaBinningModeSupported(hardware);
  const readOnly = options.readonly ?? false;

  return (
    <InputGroup className="flex-nowrap">
      <InputGroup.Text title="Binning applied to the detector">
        <i className="fa fa-fw fam-binning-2d fa-2x" />
      </InputGroup.Text>
      <ReadOnlyTextInput
        value={`${properties.binning[0]} × ${properties.binning[1]}`}
      />
      {!readOnly && (
        <>
          <Button
            variant={b === 1 ? 'primary' : 'secondary'}
            onClick={() => {
              setBinning(1);
            }}
            disabled={disabled}
          >
            1
          </Button>
          <Button
            variant={b === 2 ? 'primary' : 'secondary'}
            onClick={() => {
              setBinning(2);
            }}
            disabled={disabled}
          >
            2
          </Button>
          <Button
            variant={b === 3 ? 'primary' : 'secondary'}
            onClick={() => {
              setBinning(3);
            }}
            disabled={disabled}
          >
            3
          </Button>
          <Button
            variant={b === 4 ? 'primary' : 'secondary'}
            onClick={() => {
              setBinning(4);
            }}
            disabled={disabled}
          >
            4
          </Button>
        </>
      )}
      <InputGroup.Text title="Binning applied to the detector">
        <Badge
          style={{ fontSize: '130%', minWidth: LONGEST_MODE_WIDTH }}
          title={`Detector setup with binning ${binningMode}`}
        >
          {binningMode}
        </Badge>
      </InputGroup.Text>
      {!readOnly && supportedBinningMode && <DropdownBinning {...props} />}
    </InputGroup>
  );
}

export default function LimaBinning(
  props: HardwareWidgetProps<LimaSchema, EditableHardwareWidgetOptions>
) {
  const { hardware, options = {} } = props;
  const widgetIcon = (
    <TypeIcon name="Lima" icon="fam-hardware-camera" online={hardware.online} />
  );

  const widgetState = <LimaState hardware={hardware} />;

  const widgetContent = (
    <>
      <LimaBinningControl {...props} />
    </>
  );

  const headerMode = options.header ?? 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
