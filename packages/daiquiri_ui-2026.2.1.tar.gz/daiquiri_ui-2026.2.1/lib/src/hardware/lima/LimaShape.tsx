import { InputGroup, Form, Button, Dropdown, Badge } from 'react-bootstrap';
import type {
  HardwareWidgetProps,
  HardwareWidgetOptions,
} from '../utils/types';
import TypeIcon from '../utils/TypeIcon';
import HardwareTemplate from '../utils/HardwareTemplate';
import type { LimaSchema } from '.';
import { LimaState } from './LimaState';

function LimaRoiShapeWidget(
  props: HardwareWidgetProps<LimaSchema, HardwareWidgetOptions>
) {
  const { hardware, disabled } = props;
  const { properties } = hardware;
  const imageMaxDim = properties.static?.image_max_dim ?? [0, 0];
  const roi = properties.roi;
  const binning = properties.binning ?? [1, 1];

  const maxw = imageMaxDim[0] / binning[0];
  const maxh = imageMaxDim[1] / binning[1];

  function getPercentageCoef() {
    if (maxh > maxw) {
      return 1 / maxh;
    }
    return 1 / maxw;
  }

  const coef = getPercentageCoef();

  const [pdw, pdh] = [100 * maxw * coef, 100 * maxh * coef];

  function getPercentageRoi() {
    const [x, y, w, h] = roi;
    return [
      (100 * x) / maxw,
      (100 * y) / maxh,
      (100 * w) / maxw,
      (100 * h) / maxh,
    ];
  }

  function getPercentageText() {
    const [x, y, w, h] = roi;
    return [(100 * (x + w * 0.5)) / maxw, (100 * (y + h * 0.5)) / maxh];
  }

  const [px, py, pw, ph] = getPercentageRoi();
  const [tx, ty] = getPercentageText();

  return (
    <div style={{ backgroundColor: '#AAAAAA', width: '10em', height: '10em' }}>
      <div
        className="position-relative"
        title={`Detector ${hardware.id}`}
        style={{
          backgroundColor: '#FFFFFF',
          border: '2px solid black',
          width: `${pdw}%`,
          height: `${pdh}%`,
        }}
      >
        <div
          title="ROI location"
          className="position-absolute"
          style={{
            backgroundColor: '#FFFFFF',
            border: '2px dotted black',
            left: `${px}%`,
            top: `${py}%`,
            width: `${pw}%`,
            height: `${ph}%`,
          }}
        />
        <span
          className="position-absolute"
          style={{
            left: `${tx}%`,
            top: `${ty}%`,
            transform: 'translate(-50%, -50%)',
          }}
        >
          {roi[2]}×{roi[3]}
        </span>
      </div>
    </div>
  );
}

export default function LimaRoiShape(
  props: HardwareWidgetProps<LimaSchema, HardwareWidgetOptions>
) {
  const { hardware, options = {} } = props;
  const widgetIcon = (
    <TypeIcon name="Lima" icon="fam-hardware-camera" online={hardware.online} />
  );

  const widgetState = <LimaState hardware={hardware} />;

  const widgetContent = (
    <>
      <LimaRoiShapeWidget {...props} />
    </>
  );

  const headerMode = options.header ?? 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
