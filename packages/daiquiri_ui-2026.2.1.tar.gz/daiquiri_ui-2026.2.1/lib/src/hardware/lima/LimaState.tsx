import { HardwareState } from '../utils/State';
import type { LimaSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function LimaState(props: { hardware: LimaSchema }) {
  const { hardware } = props;
  const { online, locked = null } = hardware;
  const state = hardware.properties.state ?? 'UNKNOWN';
  const finalState = online
    ? (state === 'ACQUIRING' ? state : locked !== null ? 'LOCKED' : state) ||
      'UNKNOWN'
    : 'OFFLINE';

  const variants: { [state: string]: string } = {
    UNKNOWN: 'critical',
    ACQUIRING: 'transiant',
    READY: 'success',
    OFFLINE: 'secondary',
    LOCKED: 'warning',
  };
  const variant = variants[finalState] ?? variants.UNKNOWN;
  return <HardwareState state={finalState} minWidth={6} variant={variant} />;
}

export default function DefaultState(props: HardwareWidgetProps<LimaSchema>) {
  const { hardware } = props;
  return <LimaState hardware={hardware} />;
}
