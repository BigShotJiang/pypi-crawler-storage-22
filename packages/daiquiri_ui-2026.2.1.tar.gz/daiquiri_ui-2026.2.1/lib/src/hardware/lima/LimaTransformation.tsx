import {
  InputGroup,
  Badge,
  Container,
  Row,
  Col,
  ButtonGroup,
  Button,
  Dropdown,
} from 'react-bootstrap';
import type {
  HardwareWidgetProps,
  EditableHardwareWidgetOptions,
  EditableHardware,
} from '../utils/types';
import TypeIcon from '../utils/TypeIcon';
import HardwareTemplate from '../utils/HardwareTemplate';
import type { LimaSchema } from '.';
import { LimaState } from './LimaState';
import { useState } from 'react';
import type { PropsWithChildren } from 'react';

function ActionButton(
  props: PropsWithChildren<{
    icon?: string;
    isActive?: boolean;
    disabled: boolean;
    onAction: () => Promise<void>;
    title: string;
  }>
) {
  const [doingAction, setDoingAction] = useState(false);
  return (
    <Button
      variant={
        props.isActive ? 'primary' : doingAction ? 'warning' : 'secondary'
      }
      onClick={() => {
        setDoingAction(true);
        props.onAction().finally(() => {
          setDoingAction(false);
        });
      }}
      disabled={props.disabled || doingAction}
      title={props.title}
      className="text-nowrap"
    >
      {props.icon && (
        <i
          className={`col-sm-4 justify-content-center align-self-center ${props.icon}`}
        />
      )}
      {props.children}
    </Button>
  );
}

function DropdownLimaTransformation(props: {
  hardware: EditableHardware<LimaSchema>;
  options: EditableHardwareWidgetOptions;
  disabled: boolean;
}) {
  const { hardware, options = {}, disabled } = props;
  const { actions, properties } = hardware;
  const {
    rotation,
    flip: [flipX, flipY],
  } = properties;

  return (
    <Dropdown>
      <Dropdown.Toggle variant="secondary" disabled={disabled} />
      <Dropdown.Menu align="end" popperConfig={{ strategy: 'fixed' }}>
        <Container>
          <Row>
            <Col className="text-center">Rotation</Col>
          </Row>
          <Row>
            <Col>
              <ButtonGroup>
                <ActionButton
                  isActive={rotation === 0}
                  onAction={() => actions.setProperty('rotation', 0)}
                  disabled={disabled}
                  title="Disable rotation transformation"
                >
                  None
                </ActionButton>
                <ActionButton
                  isActive={rotation === 90}
                  onAction={() => actions.setProperty('rotation', 90)}
                  disabled={disabled}
                  title="Disable rotation transformation"
                >
                  90 <i className="fa fa-fw fa-arrow-rotate-right" />
                </ActionButton>
                <ActionButton
                  isActive={rotation === 180}
                  onAction={() => actions.setProperty('rotation', 180)}
                  disabled={disabled}
                  title="Disable rotation transformation"
                >
                  180 <i className="fa fa-fw fa-arrow-rotate-right" />
                </ActionButton>
                <ActionButton
                  isActive={rotation === 270}
                  onAction={() => actions.setProperty('rotation', 270)}
                  disabled={disabled}
                  title="Disable rotation transformation"
                >
                  270 <i className="fa fa-fw fa-arrow-rotate-right" />
                </ActionButton>
              </ButtonGroup>
            </Col>
          </Row>
          <Row>
            <Col className="text-center">Flip</Col>
          </Row>
          <Row className="gx-0">
            <Col xs={6}>
              <ButtonGroup>
                <ActionButton
                  isActive={flipX}
                  onAction={() => actions.setProperty('flip', [true, flipY])}
                  disabled={disabled}
                  title="Enable horizontal flip transformation"
                >
                  Horiz <i className="fa fa-fw fa-left-right" />
                </ActionButton>
                <ActionButton
                  isActive={!flipX}
                  onAction={() => actions.setProperty('flip', [false, flipY])}
                  disabled={disabled}
                  title="Disable horizontal flip transformation"
                >
                  No
                </ActionButton>
              </ButtonGroup>
            </Col>
            <Col xs={6}>
              <ButtonGroup>
                <ActionButton
                  isActive={flipY}
                  onAction={() => actions.setProperty('flip', [flipX, true])}
                  disabled={disabled}
                  title="Enable vertical flip transformation"
                >
                  Vert <i className="fa fa-fw fa-up-down" />
                </ActionButton>
                <ActionButton
                  isActive={!flipY}
                  onAction={() => actions.setProperty('flip', [flipX, false])}
                  disabled={disabled}
                  title="Disable vertical flip transformation"
                >
                  No
                </ActionButton>
              </ButtonGroup>
            </Col>
          </Row>
        </Container>
      </Dropdown.Menu>
    </Dropdown>
  );
}

function LimaTransformationFlags(
  props: HardwareWidgetProps<LimaSchema, EditableHardwareWidgetOptions>
) {
  const { hardware, options = {} } = props;
  const { properties } = hardware;

  const [flipH, flipV] = properties.flip;
  const rotation = properties.rotation ?? 0;
  const noTransformation = !flipH && !flipV && rotation === 0;
  return (
    <InputGroup className="flex-nowrap">
      <InputGroup.Text>
        {flipH && (
          <Badge style={{ fontSize: '130%' }} className="me-1">
            Flip
            <i className="fa fa-fw fa-left-right" />
          </Badge>
        )}
        {flipV && (
          <Badge style={{ fontSize: '130%' }} className="me-1">
            Flip
            <i className="fa fa-fw fa-up-down" />
          </Badge>
        )}
        {rotation !== 0 && (
          <Badge style={{ fontSize: '130%' }} className="me-1">
            Rot {rotation.toFixed(0)}
            <i className="fa fa-fw fa-arrow-rotate-right" />
          </Badge>
        )}
        {noTransformation && (
          <Badge
            bg="secondary"
            style={{ fontSize: '130%' }}
            title="No transformation"
          >
            None
          </Badge>
        )}
      </InputGroup.Text>
      {!options.readonly && <DropdownLimaTransformation {...props} />}
    </InputGroup>
  );
}

export default function LimaTransformation(
  props: HardwareWidgetProps<LimaSchema, EditableHardwareWidgetOptions>
) {
  const { hardware, options = {} } = props;
  const widgetIcon = (
    <TypeIcon name="Lima" icon="fam-hardware-camera" online={hardware.online} />
  );

  const widgetState = <LimaState hardware={hardware} />;

  const widgetContent = (
    <>
      <LimaTransformationFlags {...props} />
    </>
  );

  const headerMode = options.header ?? 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
