import { useState } from 'react';
import type { LimaProperties } from '..';
import { Simulator } from '../../base/mocks/Simulator';
import type { PropsWithSimulator } from '../../base/mocks/Simulator';

export default function LimaSimulator(props: PropsWithSimulator) {
  const { name, alias, useHardwareContext } = props;
  const imageMaxDim: [number, number] = [1920, 1920];
  const cameraPixelSize: [number, number] = [1.6e-5, 1.6e-5];
  const [properties, setProperties] = useState<LimaProperties>({
    static: {
      lima_version: '1.9.23',
      lima_type: 'Frelon',
      camera_type: 'Frelon',
      camera_model: 'SPB8x2 CcdFT2k-F16',
      camera_pixelsize: cameraPixelSize,
      image_max_dim: imageMaxDim,
    },
    acc_max_expo_time: 1,
    binning: [1, 1],
    flip: [false, false],
    pixel_size: cameraPixelSize,
    raw_roi: [0, 0, ...imageMaxDim],
    roi: [0, 0, ...imageMaxDim],
    rotation: 0,
    size: imageMaxDim,
    state: 'READY',
  });

  async function call(name: string, value?: any): Promise<void> {
    console.log('LimaSimulator: Unsupported call', name, value);
  }

  function changeBinning(
    props: LimaProperties,
    binning: [number, number]
  ): LimaProperties {
    const pixelSize: [number, number] = [
      Math.round(cameraPixelSize[0] * binning[0]),
      Math.round(cameraPixelSize[1] * binning[1]),
    ];
    const size: [number, number] = [
      Math.round(imageMaxDim[0] / binning[0]),
      Math.round(imageMaxDim[1] / binning[1]),
    ];
    return {
      ...props,
      binning,
      pixel_size: pixelSize,
      roi: [0, 0, ...size],
      size,
    };
  }

  function changeBinningMode(
    props: LimaProperties,
    binningMode: 'SUM' | 'MEAN'
  ): LimaProperties {
    return {
      ...props,
      binning_mode: binningMode,
    };
  }

  function changeRotation(
    props: LimaProperties,
    rotation: 0 | 90 | 180 | 270
  ): LimaProperties {
    return {
      ...props,
      rotation,
    };
  }

  function changeFlipX(props: LimaProperties, flip: boolean): LimaProperties {
    return {
      ...props,
      flip: [flip, props.flip[1]],
    };
  }
  function changeFlipY(props: LimaProperties, flip: boolean): LimaProperties {
    return {
      ...props,
      flip: [props.flip[0], flip],
    };
  }

  async function setProperty(name: string, value: any): Promise<void> {
    if (name === 'binning') {
      setProperties((p) => {
        return changeBinning(p, value);
      });
      return;
    }
    if (name === 'binning_mode') {
      setProperties((p) => {
        return changeBinningMode(p, value);
      });
      return;
    }
    if (name === 'rotation') {
      setProperties((p) => {
        return changeRotation(p, value);
      });
      return;
    }
    if (name === 'flip_x') {
      setProperties((p) => {
        return changeFlipX(p, value);
      });
      return;
    }
    if (name === 'flip_y') {
      setProperties((p) => {
        return changeFlipY(p, value);
      });
      return;
    }
    console.log('LimaSimulator: Unsupported setProperty', name, value);
  }

  return (
    <Simulator
      name={name}
      alias={alias}
      type="lima"
      call={call}
      setProperty={setProperty}
      properties={properties}
      useHardwareContext={useHardwareContext}
    />
  );
}
