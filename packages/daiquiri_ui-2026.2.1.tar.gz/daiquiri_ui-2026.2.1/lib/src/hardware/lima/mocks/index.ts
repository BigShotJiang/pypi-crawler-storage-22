import defaultjson from './Lima.json';
import flipjson from './LimaFlip.json';
import rotjson from './LimaRot.json';
import roicenter from './RoiCenter.json';
import squaredetector from './SquareDetector.json';

export const Mocks = {
  default: defaultjson,
  flip: flipjson,
  rot: rotjson,
  roicenter,
  squaredetector,
};
