import 'react-bootstrap-typeahead/css/Typeahead.css';
import 'react-bootstrap-typeahead/css/Typeahead.bs5.css';
import type { TypeaheadInputProps } from 'react-bootstrap-typeahead/types/types';

import { useRef } from 'react';
import {
  Alert,
  Button,
  Form,
  InputGroup,
  OverlayTrigger,
  Tooltip,
} from 'react-bootstrap';
import {
  Highlighter,
  Hint,
  Menu,
  MenuItem,
  Typeahead,
} from 'react-bootstrap-typeahead';
import type { MeasurementGroupSchema } from '.';
import TypeIcon from '../utils/TypeIcon';
import type { HardwareWidgetProps } from '../utils/types';
import HardwareTemplate from '../utils/HardwareTemplate';

interface CustomTypeaheadInputProps extends TypeaheadInputProps {
  [key: string]: any;
}

function RenderInput(inputProps: CustomTypeaheadInputProps, state: any) {
  const {
    inputRef,
    referenceElementRef,
    onAddSelection,
    onRemoveSelection,
    ...otherInputProps
  } = inputProps;
  const fieldRef = useRef<HTMLInputElement>();

  const clearInput = () => {
    setTimeout(() => {
      // @ts-expect-error
      const setValue = Object.getOwnPropertyDescriptor(
        window.HTMLInputElement.prototype,
        'value'
      ).set;
      if (setValue) {
        setValue.call(fieldRef.current, '');
      }
      if (fieldRef.current) {
        fieldRef.current.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }, 500);
  };

  const addSelection = () => {
    if (onAddSelection) {
      onAddSelection(state.results).then(() => {
        clearInput();
      });
    }
  };

  const removeSelection = () => {
    const selected = state.text
      ? [...state.selected].filter((option) => {
          return option.toLowerCase().indexOf(state.text.toLowerCase()) !== -1;
        })
      : [...state.selected];

    if (onRemoveSelection) {
      onRemoveSelection(selected).then(() => {
        clearInput();
      });
    }
  };

  return (
    <InputGroup>
      <Hint>
        {
          // @ts-expect-error
          <Form.Control
            style={{ width: '100%' }}
            {...otherInputProps}
            ref={(node: HTMLInputElement) => {
              fieldRef.current = node;
              inputRef(node);
              referenceElementRef(node);
            }}
            placeholder={`${state.selected.length} enabled`}
          />
        }
      </Hint>
      <Button
        disabled={inputProps.disabled || state.results.length === 0}
        onClick={addSelection}
      >
        <i className="fa fa-plus" />
      </Button>
      <Button disabled={inputProps.disabled} onClick={removeSelection}>
        <i className="fa fa-minus" />
      </Button>
    </InputGroup>
  );
}

function withExtraProps(extraProps: { [prop: string]: any }) {
  return function (wrappedComponent: any) {
    function WithExtraProps(props: any, props2: any, props3: any) {
      return wrappedComponent(props, props2, props3, extraProps);
    }

    WithExtraProps.displayName = `WithExtraProps(${
      wrappedComponent.displayName || wrappedComponent.name || 'Component'
    })`;

    return WithExtraProps;
  };
}

function RenderMenu(results: any, menuProps: any, state: any, extraProps: any) {
  const selected = [...state.selected] // eslint-disable-line @typescript-eslint/require-array-sort-compare
    .filter((option) => {
      return option.toLowerCase().indexOf(state.text.toLowerCase()) !== -1;
    })
    .sort();

  const selectedItems = selected.map((opt) => (
    /* eslint-disable-next-line jsx-a11y/anchor-is-valid */
    <a
      href="#"
      className="dropdown-item"
      key={opt}
      onClick={() => state.onRemove(opt)}
    >
      <Highlighter search={state.text}>{opt}</Highlighter>
    </a>
  ));
  const items = [...state.results].sort(); // eslint-disable-line @typescript-eslint/require-array-sort-compare
  const availableItems = items.map((opt, i) => (
    <MenuItem key={opt} option={opt} position={i}>
      <Highlighter search={state.text}>{opt}</Highlighter>
    </MenuItem>
  ));

  return (
    <Menu {...{ ...menuProps, style: { ...menuProps.style, width: 350 } }}>
      {extraProps.pending && <Menu.Header>Loading...</Menu.Header>}
      {!extraProps.pending && (
        <>
          <Menu.Header>Enabled</Menu.Header>
          {selectedItems}
          {selectedItems.length === 0 && (
            <span className="dropdown-item disabled">No items enabled</span>
          )}

          <Menu.Header>Available</Menu.Header>
          {availableItems}
          {availableItems.length === 0 && (
            <span className="dropdown-item disabled">No items available</span>
          )}
        </>
      )}
    </Menu>
  );
}

function WidgetContent(props: HardwareWidgetProps<MeasurementGroupSchema>) {
  const { hardware, disabled = false } = props;
  const { online } = hardware;

  if (!online) {
    return <Alert>Offline</Alert>;
  }

  const enabled = hardware.properties.available.filter(
    (x) => !hardware.properties.disabled.includes(x)
  );

  function setSelection(selected: any) {
    const added = selected.filter((x: string) => !enabled.includes(x));
    const removed = enabled.filter((x) => !selected.includes(x));

    if (added.length > 0) {
      added.forEach((counter: string) => {
        void hardware.actions.call('enable', counter);
      });
    }

    if (removed.length > 0) {
      removed.forEach((counter: string) => {
        void hardware.actions.call('disable', counter);
      });
    }
  }

  function onAddSelection(selection: any) {
    const promises: Promise<any>[] = [];
    selection.forEach((counter: string) => {
      const promise = hardware.actions.call('enable', counter);
      promises.push(promise);
    });
    return Promise.all(promises);
  }

  function onRemoveSelection(selection: any) {
    const promises: Promise<any>[] = [];
    selection.forEach((counter: string) => {
      const promise = hardware.actions.call('disable', counter);
      promises.push(promise);
    });

    return Promise.all(promises);
  }

  return (
    <Typeahead
      disabled={disabled}
      id={`typeahead_mg_${hardware.name}`}
      multiple
      flip
      positionFixed
      renderInput={RenderInput}
      renderMenu={withExtraProps({
        name: hardware.id,
      })(RenderMenu)}
      onChange={setSelection}
      inputProps={{
        // @ts-expect-error
        onAddSelection,
        onRemoveSelection,
      }}
      selected={enabled}
      options={hardware.properties.available}
      selectHint={(shouldSelect, e) => {
        return e.key === 'Enter' || shouldSelect;
      }}
    />
  );
}

export default function MeasurementGroup(
  props: HardwareWidgetProps<MeasurementGroupSchema>
) {
  const { hardware, options = {}, disabled = false } = props;

  function setActive() {
    return hardware.actions.call('set_active');
  }

  const active = false;

  const headerMode = options.header ?? 'top';

  const widgetIcon = (
    <TypeIcon name="Measurement Group" icon="fa-list-ol" online />
  );

  const widgetState = (
    <>
      {!active && (
        <OverlayTrigger
          placement="top"
          overlay={
            <Tooltip id="active">Activate this measurement group</Tooltip>
          }
        >
          <Button
            size="sm"
            disabled={disabled}
            onClick={() => void setActive()}
            className="float-right ml-1"
          >
            <i className="fa fa-power-off" />
          </Button>
        </OverlayTrigger>
      )}
    </>
  );

  const widgetContent = <WidgetContent {...props} />;

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
