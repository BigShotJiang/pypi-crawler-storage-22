import type { Hardware, HardwareVariant } from '../utils/types';
import MeasurementGroup from './MeasurementGroup';

export interface MeasurementGroupProperties extends Record<string, unknown> {
  /** List of available counters */
  available: string[];

  /** List of disabled counters.
   *
   * It is a subset of the `available` list.
   */
  disabled: string[];
}

/**
 * Hardware as exposed by Redux
 */
export type MeasurementGroupSchema = Hardware<MeasurementGroupProperties>;

const Variants: HardwareVariant<MeasurementGroupSchema> = {
  default: MeasurementGroup,
};

export default Variants;
