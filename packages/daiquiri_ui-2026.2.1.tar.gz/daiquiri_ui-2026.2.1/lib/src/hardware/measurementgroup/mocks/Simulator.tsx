import { useState } from 'react';
import { Simulator, delay } from '../../base/mocks/Simulator';
import type { PropsWithSimulator } from '../../base/mocks/Simulator';
import type { MeasurementGroupProperties } from '..';

export default function MeasurementGroupSimulator(props: PropsWithSimulator) {
  const { name, alias, useHardwareContext } = props;
  const [properties, setProperties] = useState<MeasurementGroupProperties>({
    available: [
      'lima:image',
      'diode1',
      'diode2',
      'machinfo:current',
      'machinfo:srcurrent',
    ],
    disabled: ['machinfo:current'],
  });

  async function enable(counter: string) {
    setProperties((p) => {
      const { disabled } = p;
      return { ...p, disabled: disabled.filter((c) => c !== counter) };
    });
  }

  async function disable(counter: string) {
    setProperties((p) => {
      const { disabled } = p;
      return {
        ...p,
        disabled: disabled.includes(counter)
          ? disabled
          : [...disabled, counter],
      };
    });
  }

  async function call(name: string, value?: any): Promise<void> {
    if (name === 'enable') {
      await enable(value as string);
      return;
    }
    if (name === 'disable') {
      await disable(value as string);
      return;
    }
    if (name === 'set_active') {
      return;
    }
    console.log('MeasurementGroupSimulator: Unsupported call', name, value);
  }

  async function setProperty(name: string, value: any): Promise<void> {
    console.log(
      'MeasurementGroupSimulator: Unsupported setProperty',
      name,
      value
    );
  }

  return (
    <Simulator
      name={name}
      alias={alias}
      type="measurementgroup"
      call={call}
      setProperty={setProperty}
      properties={properties}
      useHardwareContext={useHardwareContext}
    />
  );
}
