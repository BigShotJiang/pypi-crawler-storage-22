import defaultjson from './MG.json';

export const Mocks = {
  default: defaultjson,
};
