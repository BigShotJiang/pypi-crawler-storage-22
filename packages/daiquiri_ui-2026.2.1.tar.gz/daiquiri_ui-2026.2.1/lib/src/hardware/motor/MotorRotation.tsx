import { useDebouncedCallback } from '@react-hookz/web';

import TypeIcon from '../utils/TypeIcon';
import HardwareTemplate from '../utils/HardwareTemplate';
import type { MotorSchema } from '.';
import { isMotorClockWise, motorLimits, useMotorStates } from '.';
import { MotorState } from './MotorState';
import type { HardwareWidgetProps } from '../utils/types';
import type { MotorDefaultOptions } from './options';
import InfiniteKnob360 from '../../components/InfiniteKnob360';

export default function MotorRotation(
  props: HardwareWidgetProps<MotorSchema, MotorDefaultOptions>
) {
  const { hardware, options = {} } = props;

  // This have to be debounced as workaround cause it can be called twice
  const moveHardware = useDebouncedCallback(
    (value: number) => {
      hardware.actions.call('move', value);
    },
    [hardware.actions],
    100
  );

  const states = useMotorStates(hardware.properties.state, hardware.user_tags);
  const target = states.MOVING ? hardware.properties.target : undefined;
  const isClockWise = isMotorClockWise(hardware, options);

  const widgetIcon = (
    <TypeIcon
      name="Motor"
      icon="fam-hardware-motor-r"
      online={hardware.online}
    />
  );
  const limits = motorLimits(hardware);

  const widgetState = <MotorState hardware={hardware} />;

  const widgetContent = (
    <InfiniteKnob360
      className="mx-auto my-auto"
      size={100}
      value={hardware.properties.position}
      min={limits[0]}
      max={limits[1]}
      target={target}
      onChange={moveHardware}
      disabled={props.disabled}
      readOnly={options.readOnly || !states.READY}
      origin="down"
      direction={isClockWise ? 'clockwise' : 'anticlockwise'}
    />
  );

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
