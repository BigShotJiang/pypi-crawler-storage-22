import { useMemo } from 'react';
import { useHardware } from '../../registry/hooks';
import type { Hardware, HardwareVariant } from '../utils/types';
import MotorDefault from './MotorDefault';
import MotorText from './MotorText';
import MotorRotation from './MotorRotation';
import MotorState from './MotorState';

export type MotorSchema = Hardware<{
  position: number | null;
  /**
   * Target of the actual motion.
   *
   * If there is no motion, it is `null`.
   */
  target: number | null;
  tolerance: number;
  acceleration: number;
  velocity: number;
  limits: [number, number];
  state: string[];
  unit: string;
  offset: number;
  sign: number;
  display_digits: number | null;
}>;

/**
 * Exposes the standard supported motor states
 */
export interface MotorStates {
  // Axis is READY
  READY?: true;
  // Axis is MOVING
  MOVING?: true;
  // Error from controller
  FAULT?: true;
  // Hardware high limit active
  HIGHLIMIT?: true;
  // Hardware low limit active
  LOWLIMIT?: true;
  // Home signal active
  HOME?: true;
  // Axis power is off
  OFF?: true;
  // Axis cannot move
  DISABLED?: true;
  // The state of the motor is not handlable
  UNKNOWN?: true;
  // If none of the state are set, this flag is set, to simplify the logic
  NOT_READY?: true;
}

/**
 * Normalize the motor state exposed by the hardware.
 *
 * This does not exposes the custom states in a useful maner.
 *
 * Store states are changed depending of existing user tags
 *
 * - `auto_on`: This allow to move the motor even if `OFF` is enabled.
 *              When `OFF` is enabled `READY` is turned to true.
 * - `auto_ready`: This allow to move the motor even if `NOT_READY` is enabled.
 *
 * TODO: An improvement would be to normalize that when redux is populated.
 *       instead of storing a list.
 *
 * @param state: List of the controller state
 * @param userTags: List of the hardware user tags
 */
export function useMotorStates(
  state: string[] | undefined,
  userTags: string[] = []
): MotorStates {
  return useMemo(() => {
    const autoReady = userTags.includes('auto_ready');
    const autoOn = userTags.includes('auto_on');

    if (state === undefined) {
      return { UNKNOWN: true };
    }
    if (state?.length === 0) {
      if (autoReady) {
        return { READY: true };
      }
      return { NOT_READY: true };
    }
    const newState = state.reduce((reduced: Record<string, boolean>, s) => {
      reduced[s] = true;
      return reduced;
    }, {});
    if (newState.READY === undefined) {
      if (autoOn && newState.OFF) {
        newState.READY = true;
      }
    }
    return newState;
  }, [state, userTags]);
}

export function isMotorHardware(entity: Hardware): entity is MotorSchema {
  return entity.type === 'motor';
}

/**
 * Return a motor from it's hardware name.
 *
 * Return `null` if the name refers to nothing or a mismatching hardware.
 *
 * @param name: An hardware identifier
 */
export function useMotorHardware(name: string | null): MotorSchema | null {
  const hardware = useHardware(name);
  if (hardware === null || !isMotorHardware(hardware)) {
    return null;
  }
  return hardware;
}

const Variants: HardwareVariant<MotorSchema> = {
  default: MotorDefault,
  text: MotorText,
  // Override base state
  state: MotorState,
  rotation: MotorRotation,
};

/**
 * True if the motor positon is clock wise.
 *
 * This is based on dial metadata, and user sign.
 */
export function isMotorClockWise(
  hardware: MotorSchema,
  options?: { clockwise?: boolean }
): boolean {
  if (options?.clockwise !== undefined) {
    return options.clockwise;
  }
  const inverted = hardware.properties.sign < 0;
  const anticlockwiseTag = hardware.user_tags.includes('dial.anticlockwise');
  const clockwiseTag = hardware.user_tags.includes('dial.clockwise');
  if (clockwiseTag && anticlockwiseTag) {
    console.error(
      "Both tags 'dial.clockwise' and 'dial.anticlockwise' are defined"
    );
  }
  const clockwise = clockwiseTag || !anticlockwiseTag;
  return clockwise !== inverted;
}

/**
 * Normalize the limits as finite values or `undefined`.
 */
export function motorLimits(
  hardware: MotorSchema
): [number | undefined, number | undefined] {
  const limits = hardware.properties?.limits;
  if (limits === undefined || limits === null) {
    return [undefined, undefined];
  }
  const [min, max] = limits;

  return [
    Number.isFinite(min) ? min : undefined,
    Number.isFinite(max) ? max : undefined,
  ];
}

export default Variants;
