import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { MotorSchema } from '..';
import type {
  Hardware,
  EditableHardware,
  HardwareChangeActions,
} from '../../utils/types';
import { isEqual } from 'lodash';

interface Props {
  name?: string;
  minLimit?: number;
  maxLimit?: number;
  initialPosition?: number;
  initialVelocity?: number;
  useHardwareContext?: () => {
    actions: {
      updateHardware: (name: string, hardware: Hardware) => void;
      updateHardwareChangeActions: (
        name: string,
        actions: HardwareChangeActions
      ) => void;
    };
  };
}

export default function MotorSimulator(props: Props) {
  const {
    name = 'omega',
    minLimit = -999_999_999,
    maxLimit = 999_999_999,
    initialPosition = 0,
    initialVelocity = 1000,
    useHardwareContext = () => {
      return null;
    },
  } = props;
  const [position, setPosition] = useState(initialPosition);
  const [state, setState] = useState(['READY']);
  const [target, setTarget] = useState<number | null>(null);
  const internalTimeRef = useRef(Date.now());

  const ctx = useHardwareContext();

  const updatePosition = () => {
    const now = Date.now();
    const deltaTime = (now - internalTimeRef.current) / 1000;
    let newPosition;
    internalTimeRef.current = now;
    if (target !== null && target !== position) {
      let newState;
      let newTarget;
      const deltaPosition = deltaTime * initialVelocity;
      if (deltaPosition > Math.abs(position - target)) {
        newPosition = target;
        newState = ['READY'];
        newTarget = null;
      } else {
        const direction = target > position ? 1 : -1;
        newPosition = position + direction * deltaPosition;
        newState = ['MOVING'];
        newTarget = target;
      }
      setPosition(newPosition);
      setState(newState);
      setTarget(newTarget);
    }
  };

  const call = useCallback((name: string, value?: any) => {
    if (name === 'stop') {
      setTarget(null);
      setState(['READY']);
      return Promise.resolve();
    }
    if (name === 'move') {
      const pos = Number.parseFloat(value);
      setTarget(Number.isNaN(pos) ? null : pos);
      return Promise.resolve();
    }
    console.log('MotorSimulator: Unsupported call', name, value);
    return Promise.resolve();
  }, []);

  const setProperty = useCallback((name: string, value: any) => {
    console.log('MotorSimulator: Unsupported setProperty', name, value);
    return Promise.resolve();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      updatePosition();
    }, 500);
    return () => clearInterval(timer);
  });

  const actions: HardwareChangeActions = useMemo(() => {
    const actions = {
      setProperty,
      call,
    };
    ctx?.actions.updateHardwareChangeActions?.(name, actions);
    return actions;
  }, []);

  const rawHardware: EditableHardware<MotorSchema> = {
    id: name,
    name,
    alias: null,
    online: true,
    properties: {
      acceleration: 300,
      limits: [minLimit, maxLimit],
      position,
      offset: 0,
      sign: 1,
      state,
      tolerance: 0.0001,
      unit: 'mm',
      velocity: initialVelocity,
      target,
      display_digits: 3,
    },
    type: 'motor',
    actions,
    user_tags: [],
    locked: null,
  };

  const previousHardware = useRef<EditableHardware<MotorSchema> | null>(null);

  useEffect(() => {
    if (
      previousHardware.current !== null &&
      isEqual(previousHardware.current, rawHardware)
    ) {
      return;
    }
    previousHardware.current = rawHardware;
    ctx?.actions.updateHardware(name, rawHardware);
  }, [name, rawHardware]);

  return <></>;
}
