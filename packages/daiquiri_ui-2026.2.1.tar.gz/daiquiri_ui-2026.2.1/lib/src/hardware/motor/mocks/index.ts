import motor from './Motor.json';
import halfMotor from './HalfMotor.json';
import unknownMotor from './MotorUnknown.json';
import notReadyMotor from './MotorNotReady.json';
import disconnectedMotor from './MotorDisconnected.json';
import powerOffMotor from './MotorPowerOff.json';

export const Mocks = {
  default: motor,
  halfMotor,
  unknownMotor,
  notReadyMotor,
  disconnectedMotor,
  powerOffMotor,
};
