import { Button, InputGroup, Dropdown } from 'react-bootstrap';

import TypeIcon from '../utils/TypeIcon';
import type { MultipositionSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';
import classNames from 'classnames';
import ReadOnlyTextInput from '../../components/ReadOnlyTextInput';
import { HardwareTemplate } from '../..';
import MultipositionState from './MultipositionState';

function DropdownPositions(props: HardwareWidgetProps<MultipositionSchema>) {
  const { hardware } = props;
  const { properties } = hardware;
  const hardwareReady = properties.state === 'READY';
  const disabled = props.disabled || !hardware.online || !hardwareReady;
  const position = properties.position;

  function moveTo(positionId: string) {
    void hardware.actions.call('move', positionId);
  }

  function createSelectableItem(
    positionSchema: MultipositionSchema['properties']['positions'][0]
  ) {
    const positionId = positionSchema.position;
    const selected = positionId === position;
    const icon = selected ? 'fa fa-fw fa-dot-circle-o' : 'fa fa-fw fa-circle-o';

    return (
      <Dropdown.Item
        key={positionId}
        disabled={disabled}
        onClick={() => {
          moveTo(positionId);
        }}
        title={positionSchema.description}
      >
        <i className={icon} />
        &nbsp; {positionId}
      </Dropdown.Item>
    );
  }

  return (
    <Dropdown>
      <Dropdown.Toggle disabled={disabled} variant="secondary" />
      <Dropdown.Menu align="end" popperConfig={{ strategy: 'fixed' }}>
        {properties.positions.map((m) => createSelectableItem(m))}
      </Dropdown.Menu>
    </Dropdown>
  );
}

export default function Multiposition(
  props: HardwareWidgetProps<MultipositionSchema>
) {
  const { hardware, options = {} } = props;

  const hardwareIsMoving = hardware.properties?.state === 'MOVING';

  function stop(e: any) {
    void hardware.actions.call('stop');
  }

  const widgetIcon = (
    <TypeIcon
      name="Multiposition"
      icon="fam-hardware-multiposition"
      online={hardware.online}
    />
  );

  const widgetState = <MultipositionState hardware={hardware} />;

  // Actually we can't know when it goes
  const targetPosition = hardwareIsMoving ? 'Moving' : null;

  const position = hardware.properties?.position;

  function getWidgetContent() {
    return (
      <InputGroup className="flex-nowrap">
        <ReadOnlyTextInput
          className={classNames({
            'hw-moving': hardwareIsMoving,
          })}
          value={targetPosition ?? position ?? 'Unknown'}
        />
        {!hardwareIsMoving && !props.disabled && (
          <DropdownPositions {...props} />
        )}
        {hardwareIsMoving && !props.disabled && (
          <Button variant="danger" onClick={stop}>
            <i className="fa fa-fw fa-times" />
          </Button>
        )}
      </InputGroup>
    );
  }

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={getWidgetContent()}
      headerMode={headerMode}
    />
  );
}
