import type { HardwareWidgetProps } from '../utils/types';
import type { MultipositionSchema } from '.';
import { Badge } from 'react-bootstrap';

export default function MultipositionState(props: {
  hardware: MultipositionSchema;
}) {
  const { hardware } = props;
  const { online, locked = null } = hardware;
  const state = online
    ? (locked !== null ? 'LOCKED' : hardware.properties?.state) || 'UNKNOWN'
    : 'OFFLINE';

  // Try to catch some common state name
  const variantMapping: { [name: string]: string } = {
    OFFLINE: 'secondary',
    READY: 'success',
    MOVING: 'transiant',
    ERROR: 'danger',
    UNKNOWN: 'fatal',
    LOCKED: 'warning',
  };

  const variant = variantMapping[state] || 'success';

  return <Badge bg={variant}>{state}</Badge>;
}
