import type { Hardware, HardwareVariant } from '../utils/types';
import MultipositionDefault from './Multiposition';
import MultipositionDefault2 from './MultipositionDefault2';
import MultipositionState from './MultipositionState';

export type MultipositionSchema = Hardware<{
  position: string;
  positions: {
    position: string;
    description?: string;
    target: {
      object: string;
      destination: number | string;
      tolerance?: number;
    }[];
  }[];
  state: string;
}>;

const Variants: HardwareVariant<MultipositionSchema> = {
  state: MultipositionState,
  default: MultipositionDefault,
  default2: MultipositionDefault2,
};

export default Variants;
