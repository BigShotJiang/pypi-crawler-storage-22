import { useState } from 'react';
import { Simulator, delay } from '../../base/mocks/Simulator';
import type { PropsWithSimulator } from '../../base/mocks/Simulator';

export default function MultipositionSimulator(props: PropsWithSimulator) {
  const { name, alias, useHardwareContext } = props;
  const [position, setPosition] = useState('empty');
  const [state, setState] = useState('READY');

  async function call(name: string, value?: any): Promise<void> {
    if (name === 'move') {
      setState('MOVING');
      setPosition('unknown');
      await delay(2000);
      setState('READY');
      setPosition(value);
      return;
    }
    if (name === 'stop') {
      setPosition('unknown');
      await delay(2000);
      return;
    }
    console.log('MultipositionSimulator: Unsupported call', name, value);
  }

  async function setProperty(name: string, value: any): Promise<void> {
    console.log('MultipositionSimulator: Unsupported setProperty', name, value);
  }

  const properties = {
    position,
    state,
    positions: [
      { position: 'empty', description: 'No filter', target: [] },
      { position: 'gold2', description: 'Gold filter 2mm', target: [] },
      { position: 'silver3', description: 'Silver filter 3mm', target: [] },
    ],
  };

  return (
    <Simulator
      name={name}
      alias={alias}
      type="multiposition"
      call={call}
      setProperty={setProperty}
      properties={properties}
      useHardwareContext={useHardwareContext}
    />
  );
}
