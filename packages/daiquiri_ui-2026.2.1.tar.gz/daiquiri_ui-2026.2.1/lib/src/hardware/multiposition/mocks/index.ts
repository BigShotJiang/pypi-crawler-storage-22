import defaultjson from './Multiposition.json';

export const Mocks = {
  default: defaultjson,
};
