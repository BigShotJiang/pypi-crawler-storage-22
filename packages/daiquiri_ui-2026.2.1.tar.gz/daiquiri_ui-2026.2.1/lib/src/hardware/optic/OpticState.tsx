import { HardwareState } from '../utils/State';
import type { OpticSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function OpticState(props: { hardware: OpticSchema }) {
  const { hardware } = props;
  const state = hardware.online ? hardware.properties.state : 'OFFLINE';
  const variants: { [state: string]: string } = {
    READY: 'success',
    MOVING: 'transiant',
    INVALID: 'danger',
    UNKNOWN: 'danger',
    DISABLED: 'secondary',
    OFFLINE: 'warning',
  };
  const variant = variants[state] || variants.UNKNOWN;
  return <HardwareState state={state} minWidth={6} variant={variant} />;
}

export default function DefaultState(props: HardwareWidgetProps<OpticSchema>) {
  const { hardware } = props;
  return <OpticState hardware={hardware} />;
}
