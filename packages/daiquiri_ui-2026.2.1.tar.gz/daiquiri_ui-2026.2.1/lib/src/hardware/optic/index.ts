import type { Hardware, HardwareVariant } from '../utils/types';
import Optic from './Optic';
import OpticState from './OpticState';

export interface OpticProperties extends Record<string, unknown> {
  state: string;
  magnification: number;
  available_magnifications: number[] | null;
  /**
   * Target of the actual motion.
   *
   * If there is no motion, it is `null `.
   */
  target_magnification: number | null;
  magnification_range: [number, number] | null;
}

/**
 * Hardware as exposed by Redux
 */
export type OpticSchema = Hardware<OpticProperties>;

export function isOpticHardware(entity: Hardware): entity is OpticSchema {
  return entity.type === 'optic';
}

const Variants: HardwareVariant<OpticSchema> = {
  default: Optic,
  // Override base state
  state: OpticState,
};

export default Variants;
