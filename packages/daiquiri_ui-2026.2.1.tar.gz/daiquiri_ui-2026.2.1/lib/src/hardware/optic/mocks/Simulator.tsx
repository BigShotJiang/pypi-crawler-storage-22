/* eslint no-await-in-loop: "off" */
import { useState } from 'react';
import type { OpticProperties } from '..';
import { Simulator, delay } from '../../base/mocks/Simulator';
import type { PropsWithSimulator } from '../../base/mocks/Simulator';

interface Props {
  kind: 'fixed' | 'range' | 'multi';
}

export default function OpticSimulator(props: PropsWithSimulator<Props>) {
  const { name, alias, kind, useHardwareContext } = props;

  function getInitial() {
    if (kind === 'fixed') {
      return {
        available_magnifications: null,
        magnification_range: null,
      };
    }
    if (kind === 'range') {
      return {
        available_magnifications: null,
        magnification_range: [5, 10] as [number, number],
      };
    }
    if (kind === 'multi') {
      return {
        available_magnifications: [5, 7.5, 10],
        magnification_range: null,
      };
    }
    return { available_magnifications: null, magnification_range: null };
  }

  const [properties, setProperties] = useState<OpticProperties>({
    state: 'READY',
    magnification: 10,
    target_magnification: null,
    ...getInitial(),
  });

  async function move(magnification: number) {
    let pos = properties.magnification;
    setProperties((p) => {
      return {
        ...p,
        state: 'MOVING',
        target_magnification: magnification,
      };
    });
    await delay(100);
    const speed = 0.2 * (pos < magnification ? 1 : -1);

    function setMagnification(pos: number) {
      setProperties((p) => {
        return {
          ...p,
          magnification: pos,
        };
      });
    }

    while (Math.abs(magnification - pos) >= Math.abs(speed) * 1.01) {
      pos += speed;
      setMagnification(pos);
      await delay(100);
    }

    setProperties((p) => {
      return {
        ...p,
        state: 'READY',
        magnification,
        target_magnification: null,
      };
    });
  }

  async function call(name: string, value?: any): Promise<void> {
    if (name === 'move') {
      await move(value as number);
      return;
    }
    console.log('OpticSimulator: Unsupported call', name, value);
  }

  async function setProperty(name: string, value: any): Promise<void> {
    if (name === 'magnification') {
      setProperties((p) => {
        return {
          ...p,
          magnifications: value,
        };
      });
      return;
    }
    console.log('OpticSimulator: Unsupported setProperty', name, value);
  }

  return (
    <Simulator
      name={name}
      alias={alias}
      type="optic"
      call={call}
      setProperty={setProperty}
      properties={properties}
      useHardwareContext={useHardwareContext}
    />
  );
}
