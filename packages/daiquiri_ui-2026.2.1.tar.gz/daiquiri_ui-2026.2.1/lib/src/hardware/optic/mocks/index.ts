import defaultjson from './Optic.json';
import fixedjson from './Optic.json';
import offjson from './Optic.json';
import rangejson from './Optic.json';

export const Mocks = {
  default: defaultjson,
  fixed: fixedjson,
  off: offjson,
  range: rangejson,
};
