import type { MouseEvent } from 'react';
import type {
  HardwareWidgetProps,
  EditableHardware,
  HardwareWidgetOptions,
} from '../utils/types';
import HardwareTemplate from '../utils/HardwareTemplate';
import TypeIcon from '../utils/TypeIcon';
import { Button, ButtonGroup, Container } from 'react-bootstrap';
import { ProcedureState } from './ProcedureState';
import type { ProcedureSchema } from '.';

interface ProcedureOptions extends HardwareWidgetOptions {
  /**
   * If true, execute the procedure in the BLISS session foreground.
   *
   * As result, the terminal first have to be available to
   * start the procedure, else it fails.
   *
   * Also, as it takes the prompt, it is visible by the users,
   * so they have to kill or to wait for the end before doing
   * anything else.
   */
  foreground?: boolean;
}

function Actions(props: {
  hardware: EditableHardware<ProcedureSchema>;
  disabled: boolean;
  options: ProcedureOptions;
}) {
  const { hardware, options } = props;
  const disabled = props.disabled || !hardware.online;
  const waitingUserInput = hardware.properties.state === 'AWAITING_USER_INPUT';
  const aborting = hardware.properties.state === 'ABORTING';
  const isRunning =
    hardware.properties.state === 'RUNNING' || waitingUserInput || aborting;

  function doStart(event: MouseEvent) {
    if (options.foreground) {
      // FIXME: This function is a workaround, and only available in Daiquiri server
      void hardware.actions.call('run_foreground');
    } else {
      void hardware.actions.call('start');
    }
  }

  function doAbort(event: MouseEvent) {
    void hardware.actions.call('abort');
  }

  return (
    <ButtonGroup size="lg" className="w-100">
      <Button
        onClick={doStart}
        disabled={disabled || isRunning}
        variant="primary"
      >
        Start
      </Button>
      <Button
        onClick={doAbort}
        disabled={disabled || !isRunning}
        variant="primary"
      >
        Abort
      </Button>
    </ButtonGroup>
  );
}

export default function ProcedureManage(
  props: HardwareWidgetProps<ProcedureSchema, ProcedureOptions>
) {
  const { hardware, options = {} } = props;

  const widgetIcon = (
    <TypeIcon name="Procedure" icon="fa-cog" online={hardware.online} />
  );

  const widgetState = <ProcedureState hardware={hardware} />;

  const widgetContent = (
    <Container>
      <Actions
        hardware={hardware}
        disabled={!props.operator}
        options={options}
      />
    </Container>
  );

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
