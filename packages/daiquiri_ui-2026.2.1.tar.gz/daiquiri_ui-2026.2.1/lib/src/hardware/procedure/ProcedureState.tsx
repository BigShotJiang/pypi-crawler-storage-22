import { HardwareState } from '../utils/State';
import type { ProcedureSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function ProcedureState(props: { hardware: ProcedureSchema }) {
  const { hardware } = props;
  const state = hardware.online ? hardware.properties.state : 'OFFLINE';
  const variants: { [state: string]: string } = {
    STANDBY: 'success',
    DISABLED: 'secondary',
    OFFLINE: 'secondary',
    RUNNING: 'transiant',
    ABORTING: 'warning',
    AWAITING_USER_INPUT: 'warning',
    UNKNOWN: 'fatal',
  };
  const variant = variants[state] || variants.UNKNOWN;
  return <HardwareState state={state} minWidth={6} variant={variant} />;
}

export default function DefaultState(
  props: HardwareWidgetProps<ProcedureSchema>
) {
  const { hardware } = props;
  return <ProcedureState hardware={hardware} />;
}
