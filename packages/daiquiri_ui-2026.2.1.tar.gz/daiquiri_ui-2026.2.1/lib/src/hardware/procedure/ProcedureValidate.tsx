import type { MouseEvent } from 'react';
import type { HardwareWidgetProps, EditableHardware } from '../utils/types';
import HardwareTemplate from '../utils/HardwareTemplate';
import TypeIcon from '../utils/TypeIcon';
import { Button, ButtonGroup, Container, Badge } from 'react-bootstrap';
import { ProcedureState } from './ProcedureState';
import type { ProcedureSchema } from '.';

function Actions(props: {
  hardware: EditableHardware<ProcedureSchema>;
  disabled: boolean;
}) {
  const { hardware } = props;
  const disabled = props.disabled || !hardware.online;
  const waitingUserInput = hardware.properties.state === 'AWAITING_USER_INPUT';

  function doValidate(event: MouseEvent) {
    void hardware.actions.call('validate');
  }

  return (
    <ButtonGroup size="lg" className="w-100">
      <Button
        onClick={doValidate}
        disabled={disabled || !waitingUserInput}
        variant="primary"
      >
        Validate
      </Button>
    </ButtonGroup>
  );
}

export default function ProcedureValidate(
  props: HardwareWidgetProps<ProcedureSchema>
) {
  const { hardware, options = {} } = props;

  const widgetIcon = (
    <TypeIcon name="Procedure" icon="fa-cog" online={hardware.online} />
  );

  const widgetState = <ProcedureState hardware={hardware} />;

  const widgetContent = (
    <Container>
      <Actions hardware={hardware} disabled={!props.operator} />
    </Container>
  );

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
