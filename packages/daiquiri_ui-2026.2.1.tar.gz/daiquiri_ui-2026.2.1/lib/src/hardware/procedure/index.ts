import type { Hardware, HardwareVariant } from '../utils/types';
import ProcedureManage from './ProcedureManage';
import ProcedureExecution from './ProcedureExecution';
import ProcedureValidate from './ProcedureValidate';
import ProcedureState from './ProcedureState';
import { useHardware } from '../../registry/hooks';

export type ProcedureSchema = Hardware<{
  state: string;
  previous_run_state: string;
  previous_run_exception: string | null;
  parameters: Record<string, any>;
}>;

const Variants: HardwareVariant<ProcedureSchema> = {
  default: ProcedureManage,
  manage: ProcedureManage,
  execution: ProcedureExecution,
  validate: ProcedureValidate,
  // Override base state
  state: ProcedureState,
};

export default Variants;

export interface HardwareFromProcedure {
  __type__: 'hardware';
  name: string;
}

export interface ScanFromProcedure {
  __type__: 'scan';
  key?: string;
}

export interface ExceptionFromProcedure {
  __type__: 'exception';
  class: string;
  message: string;
  traceback: Record<string, any>;
}

export function isProcedureHardware(
  entity: Hardware
): entity is ProcedureSchema {
  return entity.type === 'procedure';
}

/**
 * Return a procedure from it's hardware name.
 *
 * Return `null` if the name refers to nothing or a mismatching hardware.
 *
 * @param name: An hardware identifier
 */
export function useProcedureHardware(
  name: string | null
): ProcedureSchema | null {
  const hardware = useHardware(name);
  if (hardware === null || !isProcedureHardware(hardware)) {
    return null;
  }
  return hardware;
}
