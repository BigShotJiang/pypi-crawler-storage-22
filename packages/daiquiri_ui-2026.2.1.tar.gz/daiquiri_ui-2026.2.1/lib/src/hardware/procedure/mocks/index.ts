import standby from './ProcedureStandBy.json';

export const Mocks = {
  standby,
};
