import type { Hardware, HardwareVariant } from '../utils/types';
import Pump from './Pump';

/**
 * Hardware as exposed by Redux
 */
export type PumpSchema = Hardware<{
  state: string;
  status: string;
  pressure: number;
  voltage: number;
  current: number;
  unit?: string; // FIXME: The server implementation is missing
}>;

const Variants: HardwareVariant<PumpSchema> = {
  default: Pump,
};

export default Variants;
