import defaultjson from './Pump.json';

export const Mocks = {
  default: defaultjson,
};
