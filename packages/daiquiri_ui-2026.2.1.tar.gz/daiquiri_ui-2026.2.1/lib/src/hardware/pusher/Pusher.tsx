import { Button, ButtonGroup } from 'react-bootstrap';
import type {
  HardwareWidgetProps,
  HardwareWidgetOptions,
  EditableHardware,
} from '../utils/types';
import TypeIcon from '../utils/TypeIcon';
import HardwareTemplate from '../utils/HardwareTemplate';
import { PusherState } from './PusherState';
import type { PusherSchema } from '.';
import { useState } from 'react';

function PusherBlock(props: {
  hardware: EditableHardware<PusherSchema>;
  options: HardwareWidgetOptions;
  disabled: boolean;
  className: string;
}) {
  const { className, hardware, options = {} } = props;
  const { state } = hardware.properties ?? 'OFFLINE';
  const isInTouch = state === 'IN_TOUCH';
  const disabled = !isInTouch || props.disabled;

  function ButtonPush(props: { distance: number }) {
    const { distance } = props;
    const [pushing, setPushing] = useState(false);
    return (
      <Button
        variant="secondary"
        onClick={() => {
          setPushing(true);
          hardware.actions.call('push', distance).finally(() => {
            setPushing(false);
          });
        }}
        disabled={disabled}
      >
        <span className="text-nowrap">
          <i
            className={
              pushing
                ? 'fa-solid fa-fw fa-cog fa-spin'
                : 'fa fa-fw fa-arrow-left'
            }
          />{' '}
          {distance}
        </span>
      </Button>
    );
  }
  return (
    <div
      className={className}
      style={{
        display: 'grid',
        gridTemplateRows: 'min-content min-content min-content',
        gridTemplateColumns: 'min-content min-content min-content',
        gridGap: '1px',
      }}
    >
      <ButtonPush distance={5} />
      <ButtonPush distance={0.5} />
      <ButtonPush distance={0.05} />
      <ButtonPush distance={2} />
      <ButtonPush distance={0.2} />
      <ButtonPush distance={0.02} />
      <ButtonPush distance={1} />
      <ButtonPush distance={0.1} />
      <ButtonPush distance={0.01} />
    </div>
  );
}

function RawPusher(props: {
  hardware: EditableHardware<PusherSchema>;
  options: HardwareWidgetOptions;
  disabled: boolean;
}) {
  const { hardware, options, disabled } = props;
  const { state } = hardware.properties ?? 'OFFLINE';
  const isRetracted = state === 'RETRACTED';
  const isInTouch = state === 'IN_TOUCH';
  const isLost = state === 'LOST';
  const [movingIn, setMovingIn] = useState(false);
  const [movingOut, setMovingOut] = useState(false);

  const location = isRetracted ? 'ms-auto' : isInTouch ? 'ms-0' : 'mx-auto';

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateRows: 'min-content min-content',
        gridTemplateColumns: 'min-content auto',
        gridGap: '1px',
      }}
    >
      <i
        className={`${
          isInTouch || isLost ? 'fas fa-dizzy' : 'fa fa-smile'
        } fa-3x my-auto`}
      />
      <PusherBlock className={location} {...props} />
      <span />
      <ButtonGroup className="mx-auto" style={{ width: '12em' }}>
        <Button
          onClick={() => {
            setMovingIn(true);
            hardware.actions.call('move_in').finally(() => {
              setMovingIn(false);
            });
          }}
          disabled={isInTouch || disabled || movingIn || movingOut}
          style={{ width: '5em' }}
        >
          <span className="text-nowrap">
            <i
              className={
                movingIn
                  ? 'fa-solid fa-fw fa-cog fa-spin'
                  : 'fa fa-fw fa-arrow-left'
              }
            />{' '}
            In
          </span>
        </Button>
        <Button
          onClick={() => {
            setMovingOut(true);
            hardware.actions.call('move_out').finally(() => {
              setMovingOut(false);
            });
          }}
          disabled={isRetracted || disabled || movingIn || movingOut}
          style={{ width: '5em' }}
        >
          <span className="text-nowrap">
            Out{' '}
            <i
              className={
                movingOut
                  ? 'fa-solid fa-fw fa-cog fa-spin'
                  : 'fa fa-fw fa-arrow-right'
              }
            />
          </span>
        </Button>
      </ButtonGroup>
    </div>
  );
}

export default function Pusher(
  props: HardwareWidgetProps<PusherSchema, HardwareWidgetOptions>
) {
  const { hardware, options = {} } = props;
  const widgetIcon = (
    <TypeIcon
      name="Pusher"
      icon="fa-hand-point-right"
      online={hardware.online}
    />
  );

  const widgetState = <PusherState hardware={hardware} />;

  function getWidgetContent() {
    return <RawPusher {...props} />;
  }

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={getWidgetContent()}
      headerMode={headerMode}
    />
  );
}
