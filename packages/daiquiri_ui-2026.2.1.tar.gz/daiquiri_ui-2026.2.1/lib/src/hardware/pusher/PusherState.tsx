import { HardwareState } from '../utils/State';
import type { PusherSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function PusherState(props: { hardware: PusherSchema }) {
  const { hardware } = props;
  const state = hardware.online ? hardware.properties.state : 'OFFLINE';
  const variants: { [state: string]: string } = {
    RETRACTED: 'success',
    IN_TOUCH: 'warning',
    LOST: 'warning',
    MOVING_IN: 'transiant',
    MOVING_OUT: 'transiant',
    UNKNOWN: 'danger',
    OFFLINE: 'warning',
  };
  const variant = variants[state] || variants.UNKNOWN;
  return <HardwareState state={state} minWidth={6} variant={variant} />;
}

export default function DefaultState(props: HardwareWidgetProps<PusherSchema>) {
  const { hardware } = props;
  return <PusherState hardware={hardware} />;
}
