import type { Hardware, HardwareVariant } from '../utils/types';
import Pusher from './Pusher';
import PusherState from './PusherState';

/**
 * Hardware as exposed by Redux
 */
export type PusherSchema = Hardware<{
  state: string;
}>;

const Variants: HardwareVariant<PusherSchema> = {
  default: Pusher,
  // Override base state
  state: PusherState,
};

export default Variants;
