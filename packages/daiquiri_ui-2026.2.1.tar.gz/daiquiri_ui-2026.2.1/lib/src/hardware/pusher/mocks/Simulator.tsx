import { useState } from 'react';
import { Simulator, delay } from '../../base/mocks/Simulator';
import type { PropsWithSimulator } from '../../base/mocks/Simulator';

export default function PusherSimulator(props: PropsWithSimulator) {
  const { name, alias, useHardwareContext } = props;
  const [state, setState] = useState('RETRACTED');

  async function call(name: string, value?: any): Promise<void> {
    if (name === 'move_in') {
      setState('MOVING_IN');
      await delay(2000);
      setState('IN_TOUCH');
      return;
    }
    if (name === 'move_out') {
      setState('MOVING_OUT');
      await delay(2000);
      setState('RETRACTED');
      return;
    }
    if (name === 'push') {
      await delay(100);
      return;
    }
    console.log('PusherSimulator: Unsupported call', name, value);
  }

  async function setProperty(name: string, value: any): Promise<void> {
    console.log('PusherSimulator: Unsupported setProperty', name, value);
  }

  const properties = { state };

  return (
    <Simulator
      name={name}
      alias={alias}
      type="pusher"
      call={call}
      setProperty={setProperty}
      properties={properties}
      useHardwareContext={useHardwareContext}
    />
  );
}
