import defaultjson from './Pusher.json';

export const Mocks = {
  default: defaultjson,
};
