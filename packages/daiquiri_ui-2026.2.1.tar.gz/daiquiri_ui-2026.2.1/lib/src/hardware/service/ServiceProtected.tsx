import {
  InputGroup,
  Button,
  Popover,
  Row,
  Col,
  OverlayTrigger,
} from 'react-bootstrap';
import type {
  HardwareWidgetProps,
  HardwareWidgetOptions,
} from '../utils/types';
import HardwareTemplate from '../utils/HardwareTemplate';
import TypeIcon from '../utils/TypeIcon';
import { ServiceState } from './ServiceState';
import type { ServiceSchema } from '.';
import ReadOnlyTextInput from '../../components/ReadOnlyTextInput';

export interface ServiceProectedOptions extends HardwareWidgetOptions {
  /** Direction to drop the menu */
  dropDirection?: string;
}

function DropdownService(
  props: HardwareWidgetProps<ServiceSchema, ServiceProectedOptions>
) {
  const { hardware, options = {} } = props;
  function requestStart() {
    void hardware.actions.call('start');
  }

  function requestRestart() {
    void hardware.actions.call('restart');
  }

  function requestStop() {
    void hardware.actions.call('stop');
  }

  const state = hardware.properties?.state ?? 'UNKNOWN';
  const hardwareDisabled = state === 'STOPPING' || state === 'STARTING';

  return (
    <OverlayTrigger
      trigger="click"
      rootClose
      placement={options.dropDirection === 'up' ? 'top' : 'bottom'}
      overlay={
        <Popover id="service-protected-overlay">
          <Popover.Body>
            <Row>
              <Col className="text-center">Actions</Col>
            </Row>
            <Row>
              <Col>
                {state === 'RUNNING' && (
                  <Button
                    className="me-1 text-success border-secondary"
                    variant="light"
                    onClick={() => {
                      requestRestart();
                    }}
                    disabled={props.disabled}
                    title="Restart the service"
                  >
                    <i className="fa fa-refresh fa-wp me-1" />
                    Restart
                  </Button>
                )}
                {state !== 'RUNNING' && (
                  <Button
                    className="me-1 text-success border-secondary"
                    variant="light"
                    onClick={() => {
                      requestStart();
                    }}
                    disabled={props.disabled}
                    title="Start the service"
                  >
                    <i className="fa fa-play fa-wp me-1" />
                    Start
                  </Button>
                )}
                <Button
                  className={`text-${
                    state !== 'STOPPED' ? 'danger' : 'primary'
                  } border-secondary`}
                  variant="light"
                  onClick={() => {
                    requestStop();
                  }}
                  disabled={props.disabled}
                  title="Stop the service"
                >
                  <i className="fa fa-stop fa-wp me-1" />
                  Stop
                </Button>
              </Col>
            </Row>
          </Popover.Body>
        </Popover>
      }
    >
      <Button disabled={props.disabled || hardwareDisabled}>
        <i
          className={`fa fa-caret-${
            options.dropDirection === 'up' ? 'up' : 'down'
          }`}
        />
      </Button>
    </OverlayTrigger>
  );
}

export default function ServiceProtected(
  props: HardwareWidgetProps<ServiceSchema, ServiceProectedOptions>
) {
  const { hardware, options = {} } = props;
  const widgetIcon = (
    <TypeIcon name="Shutter" icon="fa-cog" online={hardware.online} />
  );

  const widgetState = <ServiceState hardware={hardware} />;

  function getState() {
    if (!hardware.properties) {
      return 'UNKNOWN';
    }
    return hardware.properties.state;
  }

  function capitalize(s: string) {
    return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
  }

  const state = getState();
  const hardwareDisabled = state === 'STOPPING' || state === 'STARTING';

  const variants: { [name: string]: string } = {
    STOPPED: 'danger',
    STARTING: 'transiant',
    RUNNING: 'success',
    BACKOFF: 'warning',
    STOPPING: 'transiant',
    EXITED: 'secondary',
    FATAL: 'fatal',
    UNKNOWN: 'fatal',
    OFFLINE: 'secondary',
  };
  const variant = variants[state];
  const valueName = capitalize(state);

  const widgetContent = (
    <InputGroup className="d-flex flex-nowrap">
      <ReadOnlyTextInput
        variant={variant}
        style={{ minWidth: '10em' }}
        value={valueName}
        className="text-center"
      />
      <DropdownService {...props} />
    </InputGroup>
  );

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
