import { HardwareState } from '../utils/State';
import type { ServiceSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function ServiceState(props: { hardware: ServiceSchema }) {
  const { hardware } = props;
  const state = hardware.online ? hardware.properties.state : 'OFFLINE';
  const variants: { [state: string]: string } = {
    STOPPED: 'danger',
    STARTING: 'transiant',
    RUNNING: 'success',
    BACKOFF: 'warning',
    STOPPING: 'transiant',
    EXITED: 'secondary',
    FATAL: 'fatal',
    UNKNOWN: 'fatal',
    OFFLINE: 'secondary',
  };
  const variant = variants[state] || variants.UNKNOWN;
  return <HardwareState state={state} minWidth={6} variant={variant} />;
}

export default function DefaultState(
  props: HardwareWidgetProps<ServiceSchema>
) {
  const { hardware } = props;
  return <ServiceState hardware={hardware} />;
}
