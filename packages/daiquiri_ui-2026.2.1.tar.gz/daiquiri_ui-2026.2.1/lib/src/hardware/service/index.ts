import type { Hardware, HardwareVariant } from '../utils/types';
import ServiceDefault from './ServiceDefault';
import ServiceProtected from './ServiceProtected';
import ServiceState from './ServiceState';

/**
 * Hardware as exposed by Redux
 */
export type ServiceSchema = Hardware<{
  state:
    | 'STOPPED'
    | 'STARTING'
    | 'RUNNING'
    | 'BACKOFF'
    | 'STOPPING'
    | 'EXITED'
    | 'FATAL'
    | 'UNKNOWN';
}>;

const Variants: HardwareVariant<ServiceSchema> = {
  default: ServiceDefault,
  protected: ServiceProtected,
  // Override base state
  state: ServiceState,
};

export default Variants;
