import defaultjson from './Service.json';

export const Mocks = {
  default: defaultjson,
};
