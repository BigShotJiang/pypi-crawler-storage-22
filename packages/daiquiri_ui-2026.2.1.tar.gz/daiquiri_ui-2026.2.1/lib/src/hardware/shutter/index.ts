import type { Hardware, HardwareVariant } from '../utils/types';
import ShutterDefault from './ShutterDefault';
import ShutterProtected from './ShutterProtected';
import ShutterState from './ShutterState';

export type ShutterSchema = Hardware<{
  state: string;
  status: string;
  valid: boolean;
  open_text: string;
  closed_text: string;
}>;

const Variants: HardwareVariant<ShutterSchema> = {
  default: ShutterDefault,
  protected: ShutterProtected,
  // Override default state
  state: ShutterState,
};

export default Variants;
