import { useState } from 'react';
import { Simulator, delay } from '../../base/mocks/Simulator';
import type { PropsWithSimulator } from '../../base/mocks/Simulator';

export default function ShutterSimulator(props: PropsWithSimulator) {
  const { name, alias, useHardwareContext } = props;
  const [state, setState] = useState('OPEN');

  async function call(name: string, value?: any): Promise<void> {
    if (name === 'open') {
      setState('MOVING');
      await delay(2000);
      setState('OPEN');
      return;
    }
    if (name === 'close') {
      setState('MOVING');
      await delay(2000);
      setState('CLOSED');
      return;
    }
    console.log('ShutterSimulator: Unsupported call', name, value);
  }

  async function setProperty(name: string, value: any): Promise<void> {
    console.log('ShutterSimulator: Unsupported setProperty', name, value);
  }

  const properties = {
    state,
    closed_text: '',
    open_text: '',
    status: `Shutter is ${state}`,
    valid: true,
  };

  return (
    <Simulator
      name={name}
      alias={alias}
      type="shutter"
      call={call}
      setProperty={setProperty}
      properties={properties}
      useHardwareContext={useHardwareContext}
    />
  );
}
