import defaultjson from './BeamShutter.json';

export const Mocks = {
  default: defaultjson,
};
