import type {
  HardwareWidgetProps,
  EditableHardware,
  HardwareChangeActions,
} from '../utils/types';
import TypeIcon from '../utils/TypeIcon';
import HardwareTemplate from '../utils/HardwareTemplate';
import { Container, Row, Col, InputGroup, Dropdown } from 'react-bootstrap';
import type { SlitDefaultOptions, SlitSchema } from '.';
import { useMotorHardware } from '../motor';
import type { MotorSchema } from '../motor';
import { SlitState } from './SlitState';
import MotorDefault from '../motor/MotorDefault';
import { useHardwareChangeActions } from '../../registry/hooks';
import ReadOnlyTextInput from '../../components/ReadOnlyTextInput';
import { useMemo } from 'react';
import classNames from 'classnames';

interface ResolvedSlit {
  vgap: EditableHardware<MotorSchema> | null;
  voffset: EditableHardware<MotorSchema> | null;
  hgap: EditableHardware<MotorSchema> | null;
  hoffset: EditableHardware<MotorSchema> | null;
}

function useResolvedSlit(hardware: SlitSchema): ResolvedSlit {
  const { properties } = hardware;

  const vgapId = properties.vgap?.slice(9);
  const vgap = useMotorHardware(vgapId);
  const vgapActions = useHardwareChangeActions(vgapId);

  const hgapId = properties.hgap?.slice(9);
  const hgap = useMotorHardware(hgapId);
  const hgapActions = useHardwareChangeActions(hgapId);

  const voffsetId = properties.voffset?.slice(9);
  const voffset = useMotorHardware(voffsetId);
  const voffsetActions = useHardwareChangeActions(voffsetId);

  const hoffsetId = properties.hoffset?.slice(9);
  const hoffset = useMotorHardware(hoffsetId);
  const hoffsetActions = useHardwareChangeActions(hoffsetId);

  function merge(motor: MotorSchema | null, actions: HardwareChangeActions) {
    if (motor === null) {
      return null;
    }
    return { ...motor, actions };
  }

  return {
    vgap: merge(vgap, vgapActions),
    hgap: merge(hgap, hgapActions),
    voffset: merge(voffset, voffsetActions),
    hoffset: merge(hoffset, hoffsetActions),
  } as ResolvedSlit;
}

function DropdownSlit(
  props: HardwareWidgetProps<SlitSchema, SlitDefaultOptions> & {
    resolved: ResolvedSlit;
  }
) {
  const { hardware, operator, disabled, resolved } = props;

  return (
    <Dropdown>
      <Dropdown.Toggle variant="secondary" />
      <Dropdown.Menu align="end" popperConfig={{ strategy: 'fixed' }}>
        <Container>
          <Row className="flex-nowrap">
            <Col sm={1} className="d-flex">
              <i
                className="fa fa-fw fa-square"
                title="Gap"
                style={{ alignSelf: 'center' }}
              />
            </Col>
            <Col sm={5}>
              {resolved.hgap && (
                <MotorDefault
                  hardware={resolved.hgap}
                  options={{ header: 'none' }}
                  disabled={disabled}
                  operator={operator}
                />
              )}
            </Col>
            <Col sm={1} className="d-flex">
              <span style={{ alignSelf: 'center' }}>×</span>
            </Col>
            <Col sm={5}>
              {resolved.vgap && (
                <MotorDefault
                  hardware={resolved.vgap}
                  options={{ header: 'none' }}
                  disabled={disabled}
                  operator={operator}
                />
              )}
            </Col>
          </Row>
          <Row className="flex-nowrap">
            <Col sm={1} className="d-flex">
              <i
                className="fa fa-fw fa-arrows-up-down-left-right "
                title="Offset"
                style={{ alignSelf: 'center' }}
              />
            </Col>
            <Col sm={5}>
              {resolved.hoffset && (
                <MotorDefault
                  hardware={resolved.hoffset}
                  options={{ header: 'none' }}
                  disabled={disabled}
                  operator={operator}
                />
              )}
            </Col>
            <Col sm={1} className="d-flex">
              <span style={{ alignSelf: 'center' }}>;</span>
            </Col>
            <Col sm={5}>
              {resolved.voffset && (
                <MotorDefault
                  hardware={resolved.voffset}
                  options={{ header: 'none' }}
                  disabled={disabled}
                  operator={operator}
                />
              )}
            </Col>
          </Row>
        </Container>
      </Dropdown.Menu>
    </Dropdown>
  );
}

function Widget(props: HardwareWidgetProps<SlitSchema, SlitDefaultOptions>) {
  const { hardware, options = {} } = props;
  const resolved = useResolvedSlit(hardware);
  const { readonly: readOnly = false } = options;

  function normalizePosition(motor: MotorSchema | null): string {
    const position = motor?.properties?.position ?? null;
    if (position === null) {
      return '∅';
    }
    const digits =
      options.precision ?? motor?.properties?.display_digits ?? undefined;
    if (digits !== undefined) {
      return position.toFixed(digits);
    }
    return `${position}`;
  }

  const [gap, gapUnit, gapMoving, offset, offsetUnit, offsetMoving] =
    useMemo(() => {
      const gap = `${normalizePosition(resolved.hgap)} × ${normalizePosition(
        resolved.vgap
      )}`;

      const gapUnit =
        resolved.hgap?.properties.unit ?? resolved.vgap?.properties.unit ?? '?';

      const gapStates = new Set([
        ...(resolved.hgap?.properties.state ?? []),
        ...(resolved.vgap?.properties.state ?? []),
      ]);
      const gapMoving = gapStates.has('MOVING');

      const offset = `${normalizePosition(
        resolved.hoffset
      )} ; ${normalizePosition(resolved.voffset)}`;

      const offsetUnit =
        resolved.hoffset?.properties.unit ??
        resolved.voffset?.properties.unit ??
        '?';

      const offsetStates = new Set([
        ...(resolved.hoffset?.properties.state ?? []),
        ...(resolved.voffset?.properties.state ?? []),
      ]);
      const offsetMoving = offsetStates.has('MOVING');

      return [gap, gapUnit, gapMoving, offset, offsetUnit, offsetMoving];
    }, [resolved.hgap, resolved.hoffset, resolved.vgap, resolved.voffset]);

  return (
    <InputGroup className="w-100 flex-nowrap">
      <InputGroup.Text title="Gap (horizontal and vertical)">
        <i className="fa fa-fw fa-square fa-2x" />
      </InputGroup.Text>
      <ReadOnlyTextInput
        value={gap}
        title="Gap"
        className={classNames({ 'hw-moving': gapMoving })}
      />
      <InputGroup.Text>{gapUnit}</InputGroup.Text>
      <InputGroup.Text title="Offset (horizontal and vertical)">
        <i className="fa fa-fw fa-arrows-up-down-left-right fa-2x" />
      </InputGroup.Text>
      <ReadOnlyTextInput
        value={offset}
        title="Offset"
        className={classNames({ 'hw-moving': offsetMoving })}
      />
      <InputGroup.Text>{offsetUnit}</InputGroup.Text>
      {!readOnly && <DropdownSlit {...props} resolved={resolved} />}
    </InputGroup>
  );
}

export default function SlitDefault(
  props: HardwareWidgetProps<SlitSchema, SlitDefaultOptions>
) {
  const { hardware, options = {} } = props;
  const widgetIcon = (
    <TypeIcon name="Slit" icon="fam-hardware-motor" online={hardware.online} />
  );

  const widgetState = <SlitState hardware={hardware} />;

  const widgetContent = <Widget {...props} />;

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
