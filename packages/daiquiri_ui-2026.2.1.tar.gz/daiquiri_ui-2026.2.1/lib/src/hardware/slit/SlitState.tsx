import { useMemo } from 'react';
import { useMotorHardware } from '../motor';
import type { MotorSchema } from '../motor';
import type { SlitSchema } from '.';
import { HardwareState } from '../utils/State';
import type { HardwareWidgetProps } from '../utils/types';

interface ResolvedSlit {
  vgap: MotorSchema['properties']['state'] | null;
  voffset: MotorSchema['properties']['state'] | null;
  hgap: MotorSchema['properties']['state'] | null;
  hoffset: MotorSchema['properties']['state'] | null;
}

function useResolvedSlit(hardware: SlitSchema): ResolvedSlit {
  const { properties } = hardware;

  const vgapId = properties.vgap?.slice(9);
  const vgap = useMotorHardware(vgapId);

  const hgapId = properties.hgap?.slice(9);
  const hgap = useMotorHardware(hgapId);

  const voffsetId = properties.voffset?.slice(9);
  const voffset = useMotorHardware(voffsetId);

  const hoffsetId = properties.hoffset?.slice(9);
  const hoffset = useMotorHardware(hoffsetId);

  return useMemo(() => {
    return {
      vgap: vgap?.properties?.state ?? null,
      hgap: hgap?.properties?.state ?? null,
      voffset: voffset?.properties?.state ?? null,
      hoffset: hoffset?.properties?.state ?? null,
    };
  }, [vgap, hgap, voffset, hoffset]);
}

export function SlitState(props: { hardware: SlitSchema }) {
  const { hardware } = props;

  const info = useResolvedSlit(hardware);

  const [state, variant, description] = useMemo(() => {
    if (!hardware.online) {
      return ['OFFLINE', 'secondary', 'No motor online'];
    }

    if (
      info.vgap === null &&
      info.hgap === null &&
      info.voffset === null &&
      info.hoffset === null
    ) {
      return ['OFFLINE', 'secondary', 'No motor online'];
    }

    const states = new Set([
      ...(info.vgap ?? []),
      ...(info.hgap ?? []),
      ...(info.voffset ?? []),
      ...(info.hoffset ?? []),
    ]);

    if (states.has('MOVING')) {
      return ['MOVING', 'transiant', 'A motor is moving'];
    }
    if (states.has('OFF')) {
      return ['OFF', 'secondary', 'A motor is off'];
    }
    return ['READY', 'success', 'The slit is ready'];
  }, [hardware.online, info]);

  return (
    <HardwareState
      state={state}
      description={description}
      variant={variant}
      minWidth={6}
    />
  );
}

export default function DefaultState(props: HardwareWidgetProps<SlitSchema>) {
  const { hardware } = props;
  return <SlitState hardware={hardware} />;
}
