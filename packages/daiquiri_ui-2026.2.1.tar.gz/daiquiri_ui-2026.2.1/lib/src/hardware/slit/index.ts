import type {
  Hardware,
  HardwareVariant,
  HardwareWidgetOptions,
} from '../utils/types';
import SlitDefault from './SlitDefault';
import SlitState from './SlitState';

/**
 * Hardware as exposed by Redux
 */
export type SlitSchema = Hardware<{
  state: string;
  type: 'vertical' | 'horizontal' | 'both';
  hgap: string;
  vgap: string;
  hoffset: string;
  voffset: string;
}>;

export interface SlitDefaultOptions extends HardwareWidgetOptions {
  /** Number of decimals to show */
  precision?: number;
  /** Setup the widget to be read only */
  readonly?: boolean;
}

const Variants: HardwareVariant<SlitSchema> = {
  default: SlitDefault,
  // Override default state
  state: SlitState,
};

export default Variants;
