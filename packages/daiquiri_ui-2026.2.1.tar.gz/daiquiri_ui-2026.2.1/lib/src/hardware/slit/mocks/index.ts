import slit from './Slit.json';
import horizontal from './HSlit.json';
import vertical from './VSlit.json';

export const Mocks = {
  default: slit,
  horizontal,
  vertical,
};
