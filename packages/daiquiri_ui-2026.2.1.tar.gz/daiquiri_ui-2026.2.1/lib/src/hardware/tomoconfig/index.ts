import type { Hardware, HardwareVariant } from '../utils/types';
import TomoConfigLatencyTime from './LatencyTime';
import { useHardware } from '../../registry/hooks';

/**
 * Hardware as exposed by Redux
 */
export type TomoConfigSchema = Hardware<{
  sample_stage: string;
  sxbeam: string;
  detectors: string;
  holotomo: string;
  latency_time: number;
}>;

const Variants: HardwareVariant<TomoConfigSchema> = {
  latencytime: TomoConfigLatencyTime,
};

export default Variants;

export function isTomoConfigHardware(
  entity: Hardware
): entity is TomoConfigSchema {
  return entity.type === 'tomoconfig';
}

export function useTomoConfigHardware(
  name: string | null
): TomoConfigSchema | null {
  const hardware = useHardware(name);
  if (hardware === null || !isTomoConfigHardware(hardware)) {
    return null;
  }
  return hardware;
}
