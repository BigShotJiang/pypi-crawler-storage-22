import { HardwareState } from '../utils/State';
import type { TomoDetectorSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function TomoDetectorState(props: { hardware: TomoDetectorSchema }) {
  const { hardware } = props;
  const { online, locked = null } = hardware;
  const state = online
    ? (locked !== null ? 'LOCKED' : hardware.properties.state) || 'UNKNOWN'
    : 'OFFLINE';

  const variants: { [state: string]: string } = {
    UNKNOWN: 'danger',
    READY: 'success',
    OFFLINE: 'secondary',
    INVALID: 'danger',
    MOUNTING: 'transiant',
    UNMOUNTING: 'transiant',
    LOCKED: 'warning',
  };
  const variant = variants[state] || variants.UNKNOWN;
  return <HardwareState state={state} minWidth={6} variant={variant} />;
}

export default function DefaultState(
  props: HardwareWidgetProps<TomoDetectorSchema>
) {
  const { hardware } = props;
  return <TomoDetectorState hardware={hardware} />;
}
