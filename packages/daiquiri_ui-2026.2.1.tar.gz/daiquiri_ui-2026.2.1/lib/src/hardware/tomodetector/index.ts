import type { Hardware, HardwareVariant } from '../utils/types';
import TomoDetectorSamplePixelSize from './TomoDetectorSamplePixelSize';
import TomoDetectorAcquisitionMode from './TomoDetectorAcquisitionMode';
import TomoDetectorState from './TomoDetectorState';
import { useHardware } from '../../registry/hooks';

/**
 * Hardware as exposed by Redux
 */
export type TomoDetectorSchema = Hardware<{
  state: string;
  user_sample_pixel_size: number | null;
  sample_pixel_size_mode: string;
  sample_pixel_size: number | null;
  field_of_view: number;
  detector: string;
  optic: string;
  source_distance: number | null;
  acq_mode: 'MANUAL' | 'SINGLE' | 'ACCUMULATION';
}>;

const Variants: HardwareVariant<TomoDetectorSchema> = {
  samplepixelsize: TomoDetectorSamplePixelSize,
  acquisitionmode: TomoDetectorAcquisitionMode,
  // Override base state
  state: TomoDetectorState,
};

export default Variants;

export function isTomoDetectorHardware(
  entity: Hardware
): entity is TomoDetectorSchema {
  return entity.type === 'tomodetector';
}

export function useTomoDetectorHardware(
  name: string | null
): TomoDetectorSchema | null {
  const hardware = useHardware(name);
  if (hardware === null || !isTomoDetectorHardware(hardware)) {
    return null;
  }
  return hardware;
}
