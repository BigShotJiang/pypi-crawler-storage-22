import defaultjson from './TomoDetector.json';

export const Mocks = {
  default: defaultjson,
};
