import { HardwareState } from '../utils/State';
import type { TomoDetectorsSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function TomoDetectorsState(props: { hardware: TomoDetectorsSchema }) {
  const { hardware } = props;
  const state = hardware.online ? hardware.properties.state : 'OFFLINE';
  const variants: { [state: string]: string } = {
    READY: 'success',
    MOUNTING: 'transiant',
    UNMOUNTING: 'transiant',
    UNKNOWN: 'fatal',
    OFFLINE: 'warning',
  };
  const variant = variants[state] || variants.UNKNOWN;
  return <HardwareState state={state} minWidth={6} variant={variant} />;
}

export default function DefaultState(
  props: HardwareWidgetProps<TomoDetectorsSchema>
) {
  const { hardware } = props;
  return <TomoDetectorsState hardware={hardware} />;
}
