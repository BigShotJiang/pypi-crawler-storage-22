import type { Hardware, HardwareVariant } from '../utils/types';
import TomoDetectors from './TomoDetectors';
import TomoDetectorsState from './TomoDetectorsState';
import { useHardware } from '../../registry/hooks';

/**
 * Hardware as exposed by Redux
 */
export type TomoDetectorsSchema = Hardware<{
  state: string;
  detectors: string[];
  active_detector: string;
  target_detector?: string; // FIXME: The server implementation is missing
}>;

const Variants: HardwareVariant<TomoDetectorsSchema> = {
  default: TomoDetectors,
  // Override base state
  state: TomoDetectorsState,
};

export default Variants;

export function isTomoDetectorsHardware(
  entity: Hardware
): entity is TomoDetectorsSchema {
  return entity.type === 'tomodetectors';
}

export function useTomoDetectorsHardware(
  name: string | null
): TomoDetectorsSchema | null {
  const hardware = useHardware(name);
  if (hardware === null || !isTomoDetectorsHardware(hardware)) {
    return null;
  }
  return hardware;
}
