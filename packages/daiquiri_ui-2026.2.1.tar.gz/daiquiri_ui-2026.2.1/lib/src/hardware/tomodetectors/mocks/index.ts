import defaultjson from './TomoDetectors.json';

export const Mocks = {
  default: defaultjson,
};
