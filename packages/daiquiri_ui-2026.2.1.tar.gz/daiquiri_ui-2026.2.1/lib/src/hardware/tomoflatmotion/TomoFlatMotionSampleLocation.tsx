import type { HardwareWidgetProps } from '../utils/types';
import TypeIcon from '../utils/TypeIcon';
import HardwareTemplate from '../utils/HardwareTemplate';
import { TomoFlatMotionState } from './TomoFlatMotionState';
import type { TomoFlatMotionSchema } from '.';

export default function TomoFlatMotionSmall(
  props: HardwareWidgetProps<TomoFlatMotionSchema>
) {
  const { hardware, options = {}, disabled } = props;
  const { properties } = hardware;
  const { state = 'UNKNOWN' } = properties;

  const widgetIcon = (
    <TypeIcon
      name="TomoFlatMotion"
      icon="fam-hardware-camera"
      online={hardware.online}
    />
  );

  const widgetState = <TomoFlatMotionState hardware={hardware} />;
  const isMovingIn = state === 'MOVING_IN';
  const isMovingOut = state === 'MOVING_OUT';
  const isIn = state === 'IN';
  const isOut = state === 'OUT';

  function getLocation() {
    if (isIn) {
      return '1 / 3';
    }
    if (isOut) {
      return '3 / 5';
    }
    return '2 / 4';
  }
  const location = getLocation();

  const face = isIn ? 'fa-face-grin-beam-sweat' : 'fa-smile';
  const title = isIn
    ? 'The sample is in front of the beam'
    : isOut
    ? 'The sample is out of the beam'
    : '';

  const widgetContent = (
    <div
      style={{
        display: 'grid',
        gridGap: 0,
        gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr 1fr',
        gridTemplateRows: '1fr',
      }}
    >
      <i
        className={`fa ${face} fa-3x my-auto mx-auto`}
        style={{ gridColumn: location, gridRow: 1 }}
        title={title}
      />
    </div>
  );

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
