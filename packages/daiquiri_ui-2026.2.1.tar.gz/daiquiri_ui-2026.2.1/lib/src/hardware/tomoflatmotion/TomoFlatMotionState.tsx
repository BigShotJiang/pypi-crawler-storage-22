import { HardwareState } from '../utils/State';
import type { TomoFlatMotionSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function TomoFlatMotionState(props: { hardware: TomoFlatMotionSchema }) {
  const { hardware } = props;
  const state = hardware.online ? hardware.properties.state : 'OFFLINE';
  const variants: { [state: string]: [string, string] } = {
    // Deprecated in bliss-tomo 2.9
    READY: ['success', 'Ready to be used'],
    // Available since bliss-tomo 2.9
    IN: ['success', 'The sample is in the beam'],
    OUT: ['danger', 'The sample is out of the beam'],
    MOVING_IN: ['transiant', 'The sample moving in the beam'],
    MOVING_OUT: ['transiant', 'The sample moving out of the beam'],
    UNKNOWN: ['fatal', 'The device have an unknown state'],
  };
  const [variant, description] = variants[state] || variants.UNKNOWN;
  return (
    <HardwareState
      state={state}
      minWidth={6}
      variant={variant}
      description={description}
    />
  );
}

export default function DefaultState(
  props: HardwareWidgetProps<TomoFlatMotionSchema>
) {
  const { hardware } = props;
  return <TomoFlatMotionState hardware={hardware} />;
}
