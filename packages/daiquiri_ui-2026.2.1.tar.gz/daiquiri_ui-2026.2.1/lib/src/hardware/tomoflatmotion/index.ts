import TomoFlatMotionDefault from './TomoFlatMotionDefault';
import TomoFlatMotionSmall from './TomoFlatMotionSmall';
import TomoFlatMotionState from './TomoFlatMotionState';
import TomoFlatMotionSampleLocation from './TomoFlatMotionSampleLocation';
import type { Hardware, HardwareVariant } from '../utils/types';
import { useHardware } from '../../registry/hooks';

export interface TomoFlatMotionStep {
  /** Axis reference, following the pattern `hardware:my_axis` */
  axisRef: string;
  absolute_position: number | null;
  relative_position: number | null;
}

export interface TomoFlatMotionProperties extends Record<string, unknown> {
  state: 'READY' | 'IN' | 'OUT' | 'MOVING_IN' | 'MOVING_OUT' | 'UNKNOWN';
  available_axes: string[];
  motion: TomoFlatMotionStep[];
  move_in_parallel: boolean;
  power_onoff: boolean;
  settle_time: number;
}

/**
 * Hardware as exposed by Redux
 */
export type TomoFlatMotionSchema = Hardware<TomoFlatMotionProperties>;

const Variants: HardwareVariant<TomoFlatMotionSchema> = {
  default: TomoFlatMotionDefault,
  small: TomoFlatMotionSmall,
  // Override base state
  state: TomoFlatMotionState,
  sample_location: TomoFlatMotionSampleLocation,
};

export default Variants;

export function isTomoFlatMotionHardware(
  entity: Hardware
): entity is TomoFlatMotionSchema {
  return entity.type === 'tomoflatmotion';
}

export function useTomoFlatMotionHardware(
  name: string | null
): TomoFlatMotionSchema | null {
  const hardware = useHardware(name);
  if (hardware === null || !isTomoFlatMotionHardware(hardware)) {
    return null;
  }
  return hardware;
}

/**
 * True if the configuration of the object is editable.
 *
 * Actually trying to edit the flat motion if the sample
 * is not IN is not allowed.
 */
export function isTomoFlatMotionEditable(
  hardware: TomoFlatMotionSchema
): boolean {
  const { properties = {} } = hardware;
  const { state = 'UNKNOWN' } = properties;
  return [
    'IN',
    // Compatibility with bliss-tomo 2.9
    'READY',
  ].includes(state);
}
