import { useState } from 'react';
import type { TomoFlatMotionProperties } from '..';
import { Simulator } from '../../base/mocks/Simulator';
import type { PropsWithSimulator } from '../../base/mocks/Simulator';

export default function TomoFlatMotionSimulator(props: PropsWithSimulator) {
  const { name, alias, useHardwareContext } = props;

  const [properties, setProperties] = useState<TomoFlatMotionProperties>({
    state: 'READY',
    settle_time: 2,
    power_onoff: false,
    move_in_parallel: true,
    available_axes: ['hardware:sy', 'hardware:sy2'],
    motion: [
      {
        axisRef: 'hardware:sy',
        absolute_position: null,
        relative_position: 1,
      },
    ],
  });

  function updateAxes(
    props: TomoFlatMotionProperties,
    axis: {
      axis_ref: string;
      relative_position?: number;
      absolute_position?: number;
    }
  ): TomoFlatMotionProperties {
    const motion: TomoFlatMotionProperties['motion'] = [];
    let inList = false;
    props.motion.forEach((m) => {
      if (m.axisRef === axis.axis_ref) {
        inList = true;
        if (
          axis.relative_position === undefined &&
          axis.absolute_position === undefined
        ) {
          return;
        }
        motion.push({
          axisRef: axis.axis_ref,
          relative_position: axis.relative_position ?? null,
          absolute_position: axis.absolute_position ?? null,
        });
        return;
      }
      motion.push(m);
    });
    if (!inList) {
      motion.push({
        axisRef: axis.axis_ref,
        relative_position: axis.relative_position ?? null,
        absolute_position: axis.absolute_position ?? null,
      });
    }
    return {
      ...props,
      motion,
    };
  }

  async function call(name: string, value?: any): Promise<void> {
    if (name === 'update_axis') {
      setProperties((p) => {
        return updateAxes(p, value);
      });
      return;
    }
    console.log('TomoFlatMotionSimulator: Unsupported call', name, value);
  }

  async function setProperty(name: string, value: any): Promise<void> {
    console.log(
      'TomoFlatMotionSimulator: Unsupported setProperty',
      name,
      value
    );
  }

  return (
    <Simulator
      name={name}
      alias={alias}
      type="tomoflatmotion"
      call={call}
      setProperty={setProperty}
      properties={properties}
      useHardwareContext={useHardwareContext}
    />
  );
}
