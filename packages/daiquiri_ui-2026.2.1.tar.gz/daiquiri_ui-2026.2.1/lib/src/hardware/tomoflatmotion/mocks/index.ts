import defaultjson from './TomoFlatMotion.json';
import sy from './sy.json';
import sy2 from './sy2.json';

export const Mocks = {
  default: defaultjson,
  sy,
  sy2,
};
