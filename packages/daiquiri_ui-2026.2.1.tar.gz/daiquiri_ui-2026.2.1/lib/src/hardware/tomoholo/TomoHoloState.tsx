import { HardwareState } from '../utils/State';
import type { TomoHoloSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function TomoHoloState(props: { hardware: TomoHoloSchema }) {
  const { hardware } = props;
  const state = hardware.online ? hardware.properties.state : 'OFFLINE';
  const variants: { [state: string]: string } = {
    READY: 'success',
    MOVING: 'transiant',
    STABILIZING: 'transiant',
    INVALID: 'danger',
    INVALID_DETECTOR_BINNING_CHANGED: 'danger',
    INVALID_DETECTOR_DISTANCE_CHANGED: 'danger',
    INVALID_DETECTOR_CHANGED: 'danger',
  };
  const variant = variants[state] || variants.UNKNOWN;
  return <HardwareState state={state} minWidth={6} variant={variant} />;
}

export default function DefaultState(
  props: HardwareWidgetProps<TomoHoloSchema>
) {
  const { hardware } = props;
  return <TomoHoloState hardware={hardware} />;
}
