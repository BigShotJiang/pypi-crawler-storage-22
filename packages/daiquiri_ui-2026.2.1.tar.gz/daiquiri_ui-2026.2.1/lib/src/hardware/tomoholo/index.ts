import type { Hardware, HardwareVariant } from '../utils/types';
import { useHardware } from '../../registry/hooks';
import TomoHoloState from './TomoHoloState';

export interface TomoHoloDistance {
  z1: number;
  position: number;
  pixel_size: number;
}

/**
 * Hardware as exposed by Redux
 */
export type TomoHoloSchema = Hardware<{
  state: string;
  settle_time: number;
  pixel_size: number | null;
  nb_distances: number;
  distances: TomoHoloDistance[];
}>;

const Variants: HardwareVariant<TomoHoloSchema> = {
  // Override base state
  state: TomoHoloState,
};

export default Variants;

export function isTomoHoloHardware(entity: Hardware): entity is TomoHoloSchema {
  return entity.type === 'tomoholo';
}

export function useTomoHoloHardware(
  name: string | null
): TomoHoloSchema | null {
  const hardware = useHardware(name);
  if (hardware === null || !isTomoHoloHardware(hardware)) {
    return null;
  }
  return hardware;
}
