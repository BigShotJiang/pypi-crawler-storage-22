import { useState } from 'react';
import type { MouseEvent } from 'react';
import type { HardwareWidgetProps, EditableHardware } from '../utils/types';
import TypeIcon from '../utils/TypeIcon';
import HardwareTemplate from '../utils/HardwareTemplate';
import { Button, ButtonGroup } from 'react-bootstrap';
import { TomoImagingState } from './TomoImagingState';
import type { TomoImagingSchema } from '.';
import classNames from 'classnames';
import { useHardware } from '../../registry/hooks';
import { isLimaHardware } from '../lima';
import type { LimaSchema } from '../lima';
import type { HardwareWidgetOptions } from '../utils/types';

export interface TomoImagingActionsOptions extends HardwareWidgetOptions {
  /**
   * If true, the default, the sample location is restored after the action.
   */
  restore_sample?: boolean;
}

/**
 * Button with an active icon during a processing.
 *
 * The implementation aim to have a fixed width with or without
 * the processing.
 */
function ProcessingButton(props: {
  text: string;
  disabled: boolean;
  onAction: () => Promise<void>;
  onStarted?: () => void;
  onTerminated?: () => void;
  title?: string;
}) {
  const [processing, setProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | undefined>(undefined);

  const { text, disabled, onAction, onStarted, onTerminated, title } = props;

  function onClick(event: MouseEvent) {
    onStarted?.();
    setErrorMsg(undefined);
    setProcessing(true);
    onAction()
      .catch((error: any) => {
        setErrorMsg(`${error}`);
      })
      .finally(() => {
        setProcessing(false);
        onTerminated?.();
      });
  }

  return (
    <Button
      onClick={onClick}
      disabled={disabled || processing}
      variant={errorMsg === undefined ? 'primary' : 'danger'}
      className={classNames({ 'ps-4': !processing, 'pe-4': !processing })}
      title={title}
    >
      {errorMsg && (
        <i className="fa-solid fa-triangle-exclamation me-1" title={errorMsg} />
      )}
      {!errorMsg && processing && (
        <i className="fa-solid fa-cog fa-spin me-1" />
      )}
      {text}
    </Button>
  );
}

function useActiveLimaDetector(): LimaSchema | null {
  const hardware = useHardware(
    'ACTIVE_TOMOCONFIG.ref.detectors.active_detector.detector'
  );
  if (hardware === null) {
    return null;
  }
  if (!isLimaHardware(hardware)) {
    return null;
  }
  return hardware;
}

function TakeActions(props: {
  hardware: EditableHardware<TomoImagingSchema>;
  disabled: boolean;
  restoreSample: boolean;
}) {
  const { hardware, restoreSample } = props;
  const [processing, setProcessing] = useState(false);
  const disabled = props.disabled || !hardware.online || processing;

  const lima = useActiveLimaDetector();
  const limaOffline = !(lima?.properties.state !== 'OFFLINE');

  function onStarted() {
    setProcessing(true);
  }

  function onTerminated() {
    setProcessing(false);
  }

  function takeProj() {
    return hardware.actions.call('take_proj');
  }

  function takeDark() {
    return hardware.actions.call('take_dark');
  }

  function takeFlat() {
    return hardware.actions.call(
      restoreSample ? 'take_flat' : 'take_flat_and_stay'
    );
  }

  return (
    <ButtonGroup
      size="lg"
      className="w-100"
      title={
        limaOffline ? `The detector '${lima?.name}' is offline` : undefined
      }
    >
      <ProcessingButton
        onAction={takeProj}
        onStarted={onStarted}
        onTerminated={onTerminated}
        disabled={disabled || limaOffline}
        text="Proj"
        title="Take a projection"
      />
      <ProcessingButton
        onAction={takeFlat}
        onStarted={onStarted}
        onTerminated={onTerminated}
        disabled={disabled || limaOffline}
        text="Flat"
        title="Take a flat"
      />
      <ProcessingButton
        onAction={takeDark}
        onStarted={onStarted}
        onTerminated={onTerminated}
        disabled={disabled || limaOffline}
        text="Dark"
        title="Take a dark"
      />
    </ButtonGroup>
  );
}

export default function TomoImagingActions(
  props: HardwareWidgetProps<TomoImagingSchema, TomoImagingActionsOptions>
) {
  const { hardware, options = {} } = props;
  const { restore_sample: restoreSample = true } = options;

  const widgetIcon = (
    <TypeIcon
      name="TomoImaging"
      icon="fam-hardware-camera"
      online={hardware.online}
    />
  );

  const widgetState = <TomoImagingState hardware={hardware} />;

  const widgetContent = (
    <TakeActions
      hardware={hardware}
      disabled={props.disabled}
      restoreSample={restoreSample}
    />
  );

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
