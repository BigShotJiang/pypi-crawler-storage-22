import { HardwareState } from '../utils/State';
import type { TomoImagingSchema } from '.';
import type { HardwareWidgetProps } from '../utils/types';

export function TomoImagingState(props: { hardware: TomoImagingSchema }) {
  const { hardware } = props;
  const state = hardware.online ? hardware.properties.state : 'OFFLINE';
  const variants: { [state: string]: string } = {
    READY: 'success',
    BLOCKED: 'secondary',
    ACQUIRING: 'transiant',
    UNKNOWN: 'fatal',
  };
  const variant = variants[state] || variants.UNKNOWN;
  return <HardwareState state={state} minWidth={6} variant={variant} />;
}

export default function DefaultState(
  props: HardwareWidgetProps<TomoImagingSchema>
) {
  const { hardware } = props;
  return <TomoImagingState hardware={hardware} />;
}
