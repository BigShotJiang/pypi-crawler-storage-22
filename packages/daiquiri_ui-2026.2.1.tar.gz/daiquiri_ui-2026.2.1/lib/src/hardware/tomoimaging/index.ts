import type { Hardware, HardwareVariant } from '../utils/types';
import TomoImagingDefault from './TomoImagingDefault';
import TomoImagingExposureTime from './TomoImagingExposureTime';
import TomoImagingSettleTime from './TomoImagingSettleTime';
import TomoImagingActions from './TomoImagingActions';
import TomoImagingUpdateMode from './TomoImagingUpdateMode';
import TomoImagingState from './TomoImagingState';

/**
 * Hardware as exposed by Redux
 */
export type TomoImagingSchema = Hardware<{
  state: string;
  update_on_move: boolean;
  exposure_time: number;
  settle_time: number;
}>;

const Variants: HardwareVariant<TomoImagingSchema> = {
  default: TomoImagingDefault,
  exposuretime: TomoImagingExposureTime,
  settletime: TomoImagingSettleTime,
  actions: TomoImagingActions,
  updatemode: TomoImagingUpdateMode,
  // Override base state
  state: TomoImagingState,
};

export default Variants;
