import { useState } from 'react';
import { Simulator, delay } from '../../base/mocks/Simulator';
import type { PropsWithSimulator } from '../../base/mocks/Simulator';

export default function TomoImagingSimulator(props: PropsWithSimulator) {
  const { name, alias, useHardwareContext } = props;
  const [properties, setProperties] = useState({
    state: 'READY',
    update_on_move: true,
    exposure_time: 1,
    settle_time: 0,
  });

  function setState(state: string) {
    setProperties((p) => {
      return { ...p, state };
    });
  }

  async function call(name: string, value?: any): Promise<void> {
    if (name === 'take_dark') {
      setState('ACQUIRING');
      await delay(2000);
      setState('READY');
      return;
    }
    if (name === 'take_flat') {
      setState('ACQUIRING');
      await delay(2000);
      setState('READY');
      return;
    }
    if (name === 'take_proj') {
      setState('ACQUIRING');
      await delay(2000);
      setState('READY');
      return;
    }
    console.log('TomoImagingSimulator: Unsupported call', name, value);
  }

  async function setProperty(name: string, value: any): Promise<void> {
    setProperties((p) => {
      return { ...p, [name]: value };
    });
  }

  return (
    <Simulator
      name={name}
      alias={alias}
      type="tomoimaging"
      call={call}
      setProperty={setProperty}
      properties={properties}
      useHardwareContext={useHardwareContext}
    />
  );
}
