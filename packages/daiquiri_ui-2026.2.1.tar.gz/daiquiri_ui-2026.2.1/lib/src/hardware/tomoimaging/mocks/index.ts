import defaultjson from './TomoImaging.json';

export const Mocks = {
  default: defaultjson,
};
