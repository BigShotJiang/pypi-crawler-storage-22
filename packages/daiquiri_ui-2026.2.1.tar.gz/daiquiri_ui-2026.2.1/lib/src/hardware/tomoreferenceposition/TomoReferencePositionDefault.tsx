import { useState } from 'react';
import type { MouseEvent } from 'react';
import type {
  HardwareWidgetOptions,
  HardwareWidgetProps,
} from '../utils/types';
import TypeIcon from '../utils/TypeIcon';
import HardwareTemplate from '../utils/HardwareTemplate';
import { Button } from 'react-bootstrap';
import type { TomoReferencePositionSchema } from '.';

export interface TomoReferencePositionDefaultOptions
  extends HardwareWidgetOptions {
  /**
   * If defined, this label is displayed in the button.
   */
  label?: string;
}

export default function TomoReferencePositionDefault(
  props: HardwareWidgetProps<
    TomoReferencePositionSchema,
    TomoReferencePositionDefaultOptions
  >
) {
  const { hardware, options = {}, disabled } = props;
  const { actions } = hardware;
  const { label } = options;
  const [errorMsg, setErrorMsg] = useState<string | undefined>(undefined);
  const [processing, setProcessing] = useState(false);

  const widgetIcon = (
    <TypeIcon
      name="TomoReferencePositionSchema"
      icon="fam-hardware-motor"
      online={hardware.online}
    />
  );

  function onClickToReference(event: MouseEvent) {
    setErrorMsg(undefined);
    setProcessing(true);
    actions
      .call('move_to_reference')
      .catch((error: any) => {
        setErrorMsg(`${error}`);
      })
      .finally(() => {
        setProcessing(false);
      });
  }

  const widgetState = <></>;

  const widgetContent = (
    <Button
      onClick={onClickToReference}
      variant={errorMsg === undefined ? 'secondary' : 'danger'}
      disabled={disabled || processing}
      className="w-100"
    >
      {errorMsg && (
        <i className="fa-solid fa-triangle-exclamation me-1" title={errorMsg} />
      )}
      {!errorMsg && processing && (
        <i className="fa-solid fa-cog fa-spin me-1" />
      )}
      {label ?? 'Back to reference position'}
    </Button>
  );

  const headerMode = options.header || 'top';

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
