import type { Hardware, HardwareVariant } from '../utils/types';
import TomoReferencePositionDefault from './TomoReferencePositionDefault';

/**
 * Hardware as exposed by Redux
 */
export type TomoReferencePositionSchema = Hardware<Record<string, never>>;

export function isTomoReferencePositionHardware(
  entity: Hardware
): entity is TomoReferencePositionSchema {
  return entity.type === 'tomoreferenceposition';
}

const Variants: HardwareVariant<TomoReferencePositionSchema> = {
  default: TomoReferencePositionDefault,
};

export default Variants;
