import type { Hardware, HardwareVariant } from '../utils/types';
import { useHardware } from '../../registry/hooks';

/**
 * Hardware as exposed by Redux
 */
export type TomoSampleStageSchema = Hardware<{
  sx: string;
  sy: string;
  sz: string;
  somega: string;
  sampx: string;
  sampy: string;
  sampu: string;
  sampv: string;
  x_axis_focal_pos: number | null;
  detector_center: [number | null, number | null];
}>;

const Variants: HardwareVariant<TomoSampleStageSchema> = {};

export default Variants;

export function isTomoSampleStageHardware(
  entity: Hardware
): entity is TomoSampleStageSchema {
  return entity.type === 'tomosamplestage';
}

export function useTomoSampleStageHardware(
  name: string | null
): TomoSampleStageSchema | null {
  const hardware = useHardware(name);
  if (hardware === null || !isTomoSampleStageHardware(hardware)) {
    return null;
  }
  return hardware;
}
