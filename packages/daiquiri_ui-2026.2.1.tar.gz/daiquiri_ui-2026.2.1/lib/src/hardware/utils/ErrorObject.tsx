import TypeIcon from './TypeIcon';
import HardwareTemplate from './HardwareTemplate';
import type { Hardware } from './types';
import { Button, OverlayTrigger, Popover } from 'react-bootstrap';

interface NoObjectProps {
  id: string;
  name?: string;
  properties?: { message?: string };
  options: {
    header?: string;
  };
}

export default function ErrorObject(props: NoObjectProps) {
  const { properties = {} } = props;
  const { message = 'Unknown error' } = properties;
  const widgetIcon = (
    <TypeIcon name="NoObject" icon="fam-hardware-any" online={false} />
  );

  const widgetState = <></>;

  const widgetContent = (
    <OverlayTrigger
      trigger={['focus', 'hover']}
      placement="bottom"
      rootClose
      overlay={
        <Popover id="error" style={{ maxWidth: 500 }}>
          <Popover.Header>Error</Popover.Header>
          <Popover.Body>
            <ul>
              <li>{message}</li>
            </ul>
          </Popover.Body>
        </Popover>
      }
    >
      <Button variant="danger" size="sm" className="w-100">
        <i className="fa fa-exclamation-triangle" /> Error
      </Button>
    </OverlayTrigger>
  );

  <span title={`${message}`}>Error</span>;

  const headerMode = props.options ? props.options.header : 'top';

  const hardware: Hardware = {
    id: props.id,
    name: props.name ?? '',
    alias: null,
    user_tags: [],
    online: false,
    locked: null,
    properties: {},
    type: '',
  };

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
