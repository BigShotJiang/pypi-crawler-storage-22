import type { Hardware } from './types';

export interface HardwareObjectProps {
  id: string;
  options: {
    variant?: string;
    header?: string;
    width?: number;
    colWidth?: number;
    emptyifnone?: boolean;
  };
  propertiesSchema?: Record<string, unknown>;
  callablesSchema?: Record<string, unknown>;
}
