import debug from 'debug';

import TypeIcon from './TypeIcon';
import HardwareTemplate from './HardwareTemplate';
import type { Hardware } from './types';
import { Button, OverlayTrigger, Popover } from 'react-bootstrap';

const logger = debug('daiquiri.components.hardware.MissingComponentObject');

interface NoObjectProps {
  id: string;
  name?: string;
  type?: string;
  options: {
    variant?: string;
    header?: string;
    emptyifnone?: boolean;
  };
}

export default function MissingComponentObject(props: NoObjectProps) {
  const { options } = props;
  const { variant = 'default' } = options;
  if (options.emptyifnone) {
    logger(
      'Component id:"%s" name:"%s" not displayed cause setup with emptyifnone.',
      props.id,
      props.name
    );
    return <></>;
  }

  const widgetIcon = (
    <TypeIcon name="NoObject" icon="fam-hardware-any" online={false} />
  );

  const widgetState = <></>;

  const widgetContent = (
    <OverlayTrigger
      trigger={['focus', 'hover']}
      placement="bottom"
      rootClose
      overlay={
        <Popover id="error" style={{ maxWidth: 500 }}>
          <Popover.Header>Error</Popover.Header>
          <Popover.Body>
            <ul>
              <li>
                No component available for object id '{props.name}' (type '
                {props.type}' and/or variant '{variant}' are not registred)
              </li>
            </ul>
          </Popover.Body>
        </Popover>
      }
    >
      <Button variant="danger" size="sm" className="w-100">
        <i className="fa fa-exclamation-triangle" /> Error
      </Button>
    </OverlayTrigger>
  );

  const headerMode = options ? options.header : 'top';

  const hardware: Hardware = {
    id: props.id,
    name: props.name ?? '',
    alias: null,
    user_tags: [],
    online: false,
    locked: null,
    properties: {},
    type: '',
  };

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
