import TypeIcon from './TypeIcon';
import HardwareTemplate from './HardwareTemplate';
import type { Hardware } from './types';

interface NoObjectProps {
  id: string;
  name?: string;
  options: {
    header?: string;
    emptyifnone?: boolean;
  };
}

export default function NoObject(props: NoObjectProps) {
  if (props.options.emptyifnone) {
    return <></>;
  }

  const widgetIcon = (
    <TypeIcon name="NoObject" icon="fam-hardware-any" online={false} />
  );

  const widgetState = <></>;

  const widgetContent = <>No object</>;

  const headerMode = props.options ? props.options.header : 'top';

  const hardware: Hardware = {
    id: props.id,
    name: props.name ?? '',
    alias: null,
    user_tags: [],
    online: false,
    locked: null,
    properties: {},
    type: '',
  };

  return (
    <HardwareTemplate
      hardware={hardware}
      widgetIcon={widgetIcon}
      widgetState={widgetState}
      widgetContent={widgetContent}
      headerMode={headerMode}
    />
  );
}
