import type { AnyHardware, Hardware } from './types';

/**
 * Guess the hardware have a state
 *
 * FIXME: This should be dropped.
 */
export type GenericSchema = Hardware<{
  state: string;
}>;

export type AnySchema = AnyHardware;
