import type { JSONSchema7 } from 'json-schema';
import type { ComponentType } from 'react';

interface HardwareError {
  property: string;
  exception: string;
  traceback: string;
}

export interface HardwareSchemaDescription {
  properties: JSONSchema7;
  callables: JSONSchema7;
}

export interface LockDescription {
  /**
   * A unique key for identification purpose.
   *
   * It actually mangles BLISS object id, role,
   * and PID of the owner process.
   *
   * For example `srot_move,pid:26567`
   *
   * In the future this will be split into meaningful information.
   */
  reason: string;
}

export interface BaseHardware<
  O = boolean,
  P extends Record<string, any> = Record<string, never>
> {
  /** Object name */
  name: string;
  /** Object id */
  id: string;
  /** An optional object alias */
  alias: string | null;
  /** A list of user tags */
  user_tags: string[];
  /** The object properties as defined in the relevant schema */
  properties: P;
  /** Whether the device is available */
  online: O;
  /** The reason why the hardware is locked, else null */
  locked: LockDescription | null;
  /** The object type as defined by the REST API */
  type: string;
  /** Any potential errors initialising this object */
  errors?: HardwareError[];
}

export type OnlineHardware<
  P extends Record<string, any> = Record<string, never>
> = BaseHardware<true, P>;

export type OfflineHardware = BaseHardware<false, Record<string, never>>;

export type Hardware<P extends Record<string, unknown> = Record<string, any>> =
  | OnlineHardware<P>
  | OfflineHardware;

export type AnyHardware = Hardware<any>;

export interface HardwareChangeActions {
  setProperty: (name: string, value: any) => Promise<void>;
  call: (name: string, ...args: any[]) => Promise<void>;
}

/**
 * Common options exposed to user as yaml configuration for hardware widgets
 */
export interface HardwareWidgetOptions {
  /** Whether to show the extended popup */
  extended?: boolean;
  /** Kind of header displayed */
  header?: string;
}

/**
 * Common options exposed to user as yaml configuration for editable hardware widgets
 */
export interface EditableHardwareWidgetOptions extends HardwareWidgetOptions {
  /** Disable edition for an editable widget */
  readonly?: boolean;
}

export type EditableHardware<H extends Hardware = Hardware> = H & {
  /** Call the API to make a change on the hardware object */
  actions: HardwareChangeActions;
};

/**
 * Properties which are passed to the widgets
 */
export interface HardwareWidgetProps<
  H extends Hardware = Hardware,
  O extends HardwareWidgetOptions = HardwareWidgetOptions
> {
  /** Dynamic state of the hardware */
  hardware: EditableHardware<H>;
  /** Options passed to the widget by the yaml configuration */
  options: O;
  /** Global state of the widget (aggregating scan/operator/hardware states) */
  disabled: boolean;
  /** True if the session have the control */
  operator: boolean;
}

export type HardwareComponentType<H extends Hardware = Hardware> =
  ComponentType<HardwareWidgetProps<H, any>>;

export interface HardwareVariant<H extends Hardware = Hardware> {
  [name: string]: HardwareComponentType<H>;
}
