import type { Hardware, HardwareVariant } from '../utils/types';
import Valve from './Valve';

/**
 * Hardware as exposed by Redux
 */
export type ValveSchema = Hardware<{
  state: string;
  status: string;
}>;

const Variants: HardwareVariant<ValveSchema> = {
  default: Valve,
};

export default Variants;
