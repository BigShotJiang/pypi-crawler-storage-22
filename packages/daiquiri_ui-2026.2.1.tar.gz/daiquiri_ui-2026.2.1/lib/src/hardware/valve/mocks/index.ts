import defaultjson from './Valve.json';

export const Mocks = {
  default: defaultjson,
};
