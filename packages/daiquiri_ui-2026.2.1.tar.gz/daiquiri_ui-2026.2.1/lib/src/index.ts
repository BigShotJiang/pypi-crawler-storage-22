/* Hardware Objects */

// Base
export { default as BaseVariants } from './hardware/base';
export { Mocks as BaseMocks } from './hardware/base/mocks';
export { default as BaseState } from './hardware/base/BaseState';
export { default as BaseName } from './hardware/base/BaseName';
export type { BaseNameWidgetOptions } from './hardware/base/BaseName';
export { default as BaseProperty } from './hardware/base/BaseProperty';
export type { BasePropertyWidgetOptions } from './hardware/base/BaseProperty';
export { default as BaseInfo } from './hardware/base/BaseInfo';
export type { BaseInfoWidgetOptions } from './hardware/base/BaseInfo';

// Actuator
export type { ActuatorSchema } from './hardware/actuator';

// AirBearing
export { default as AirBearingVariants } from './hardware/airbearing';
export { default as AirBearing } from './hardware/airbearing/AirBearing';
export { default as AirBearingProtected } from './hardware/airbearing/AirBearingProtected';
export { AirBearingState } from './hardware/airbearing/AirBearingState';
export type { AirBearingSchema } from './hardware/airbearing';
export { Mocks as AirBearingMocks } from './hardware/airbearing/mocks';
export { default as AirBearingSimulator } from './hardware/airbearing/mocks/Simulator';

// FrontEnd
export { default as FrontendVariants } from './hardware/frontend';
export { default as Frontend } from './hardware/frontend/Frontend';
export type { FrontendSchema } from './hardware/frontend';
export { Mocks as FrontendMocks } from './hardware/frontend/mocks';

// Gauge
export { default as GaugeVariants } from './hardware/gauge';
export { default as Gauge } from './hardware/gauge/Gauge';
export type { GaugeSchema } from './hardware/gauge';
export type { GaugeWidgetOptions } from './hardware/gauge/Gauge';
export { Mocks as GaugeMocks } from './hardware/gauge/mocks';

// Laser
export { default as LaserVariants } from './hardware/laser';
export { default as Laser } from './hardware/laser/Laser';
export type { LaserSchema } from './hardware/laser';
export type { LaserWidgetOptions } from './hardware/laser/Laser';
export { Mocks as LaserMocks } from './hardware/laser/mocks';

// LaserHeating
export { default as LaserHeatingVariants } from './hardware/laserheating';
export { default as LaserHeating } from './hardware/laserheating/LaserHeating';
export type { LaserHeatingSchema } from './hardware/laserheating';
export type { LaserHeatingWidgetOptions } from './hardware/laserheating/LaserHeating';
export { Mocks as LaserHeatingMocks } from './hardware/laserheating/mocks';

// Light
export { default as LightVariants } from './hardware/light';
export { default as Light } from './hardware/light/Light';
export type { LightSchema } from './hardware/light';
export { Mocks as LightMocks } from './hardware/light/mocks';

// Lima
export {
  default as LimaVariants,
  isLimaHardware,
  useLimaHardware,
  limaGuessSubframes,
} from './hardware/lima';
export { default as LimaBinning } from './hardware/lima/LimaBinning';
export { default as LimaDefault } from './hardware/lima/LimaDefault';
export { default as LimaDescription } from './hardware/lima/LimaDescription';
export { default as LimaImageRoi } from './hardware/lima/LimaImageRoi';
export { default as LimaSize } from './hardware/lima/LimaSize';
export { default as LimaTransformation } from './hardware/lima/LimaTransformation';
export { default as LimaShape } from './hardware/lima/LimaShape';
export { LimaState } from './hardware/lima/LimaState';
export type { LimaSchema } from './hardware/lima';
export { Mocks as LimaMocks } from './hardware/lima/mocks';
export { default as LimaSimulator } from './hardware/lima/mocks/Simulator';

// MeasurementGroup
export { default as MeasurementGroupVariants } from './hardware/measurementgroup';
export { default as MeasurementGroupDefault } from './hardware/measurementgroup/MeasurementGroup';
export type { MeasurementGroupSchema } from './hardware/measurementgroup';
export { Mocks as MeasurementGroupMocks } from './hardware/measurementgroup/mocks';
export { default as MeasurementGroupSimulator } from './hardware/measurementgroup/mocks/Simulator';

// Motor
export {
  isMotorHardware,
  useMotorHardware,
  useMotorStates,
  isMotorClockWise,
  motorLimits,
} from './hardware/motor';
export { default as MotorVariants } from './hardware/motor';
export { default as MotorDefault } from './hardware/motor/MotorDefault';
export { default as MotorText } from './hardware/motor/MotorText';
export { default as MotorRotation } from './hardware/motor/MotorRotation';
export { MotorState } from './hardware/motor/MotorState';
export type { MotorDefaultOptions } from './hardware/motor/options';
export type { MotorSchema } from './hardware/motor';
export { Mocks as MotorMocks } from './hardware/motor/mocks';
export { createMotorMock } from './hardware/motor/mocks/utils';
export { default as MotorSimulator } from './hardware/motor/mocks/Simulator';

// Multiposition
export { default as MultipositionVariants } from './hardware/multiposition';
export { default as Multiposition } from './hardware/multiposition/Multiposition';
export type { MultipositionSchema } from './hardware/multiposition';
export { Mocks as MultipositionMocks } from './hardware/multiposition/mocks';
export { default as MultipositionSimulator } from './hardware/multiposition/mocks/Simulator';

// Optic
export { default as OpticVariants, isOpticHardware } from './hardware/optic';
export { default as OpticDefault } from './hardware/optic/Optic';
export { OpticState } from './hardware/optic/OpticState';
export type { OpticSchema } from './hardware/optic';
export type { OpticWidgetOptions } from './hardware/optic/Optic';
export { Mocks as OpticMocks } from './hardware/optic/mocks';
export { default as OpticSimulator } from './hardware/optic/mocks/Simulator';

// Procedure
export {
  isProcedureHardware,
  useProcedureHardware,
} from './hardware/procedure';
export { default as ProcedureVariants } from './hardware/procedure';
export { default as ProcedureExecution } from './hardware/procedure/ProcedureExecution';
export { default as ProcedureManage } from './hardware/procedure/ProcedureManage';
export { default as ProcedureValidate } from './hardware/procedure/ProcedureValidate';
export { ProcedureState } from './hardware/procedure/ProcedureState';
export type { ProcedureSchema } from './hardware/procedure';
export { Mocks as ProcedureMocks } from './hardware/procedure/mocks';
export type {
  ExceptionFromProcedure,
  HardwareFromProcedure,
  ScanFromProcedure,
} from './hardware/procedure';

// Shutter
export { default as ShutterVariants } from './hardware/shutter';
export { default as ShutterDefault } from './hardware/shutter/ShutterDefault';
export { default as ShutterProtected } from './hardware/shutter/ShutterProtected';
export { ShutterState } from './hardware/shutter/ShutterState';
export type { ShutterSchema } from './hardware/shutter';
export { Mocks as ShutterMocks } from './hardware/shutter/mocks';
export { default as ShutterSimulator } from './hardware/shutter/mocks/Simulator';

// Slit
export { default as SlitVariants } from './hardware/slit';
export { default as SlitDefault } from './hardware/slit/SlitDefault';
export { SlitState } from './hardware/slit/SlitState';
export type { SlitSchema } from './hardware/slit';
export { Mocks as SlitMocks } from './hardware/slit/mocks';

// Pump
export { default as PumpVariants } from './hardware/pump';
export { default as PumpDefault } from './hardware/pump/Pump';
export type { PumpSchema } from './hardware/pump';
export { Mocks as PumpMocks } from './hardware/pump/mocks';

// Pusher
export { default as PusherVariants } from './hardware/pusher';
export { default as PusherDefault } from './hardware/pusher/Pusher';
export { PusherState } from './hardware/pusher/PusherState';
export type { PusherSchema } from './hardware/pusher';
export { Mocks as PusherMocks } from './hardware/pusher/mocks';
export { default as PusherSimulator } from './hardware/pusher/mocks/Simulator';

// Service
export { default as ServiceVariants } from './hardware/service';
export { default as ServiceDefault } from './hardware/service/ServiceDefault';
export { default as ServiceProtected } from './hardware/service/ServiceProtected';
export { ServiceState } from './hardware/service/ServiceState';
export type { ServiceSchema } from './hardware/service';
export { Mocks as ServiceMocks } from './hardware/service/mocks';

// TomoFlatMotion
export {
  default as TomoFlatMotionVariants,
  isTomoFlatMotionHardware,
  useTomoFlatMotionHardware,
} from './hardware/tomoflatmotion';
export { default as TomoFlatMotionDefault } from './hardware/tomoflatmotion/TomoFlatMotionDefault';
export { default as TomoFlatMotionSmall } from './hardware/tomoflatmotion/TomoFlatMotionSmall';
export { TomoFlatMotionState } from './hardware/tomoflatmotion/TomoFlatMotionState';
export type {
  TomoFlatMotionSchema,
  TomoFlatMotionStep,
} from './hardware/tomoflatmotion';
export { Mocks as TomoFlatMotionMocks } from './hardware/tomoflatmotion/mocks';
export { default as TomoFlatMotionSimulator } from './hardware/tomoflatmotion/mocks/Simulator';

// TomoReferencePosition
export {
  default as TomoReferencePositionVariants,
  isTomoReferencePositionHardware,
} from './hardware/tomoreferenceposition';
export { default as TomoReferencePositionDefault } from './hardware/tomoreferenceposition/TomoReferencePositionDefault';
export type { TomoReferencePositionSchema } from './hardware/tomoreferenceposition';

// TomoDetector
export {
  default as TomoDetectorVariants,
  isTomoDetectorHardware,
  useTomoDetectorHardware,
} from './hardware/tomodetector';
export { default as TomoDetectorAcquisitionMode } from './hardware/tomodetector/TomoDetectorAcquisitionMode';
export { default as TomoDetectorSamplePixelSize } from './hardware/tomodetector/TomoDetectorSamplePixelSize';
export { TomoDetectorState } from './hardware/tomodetector/TomoDetectorState';
export type { TomoDetectorSchema } from './hardware/tomodetector';
export { Mocks as TomoDetectorMocks } from './hardware/tomodetector/mocks';

// TomoDetectors
export {
  default as TomoDetectorsVariants,
  isTomoDetectorsHardware,
  useTomoDetectorsHardware,
} from './hardware/tomodetectors';
export { default as TomoDetectorsDefault } from './hardware/tomodetectors/TomoDetectors';
export { TomoDetectorsState } from './hardware/tomodetectors/TomoDetectorsState';
export type { TomoDetectorsSchema } from './hardware/tomodetectors';
export { Mocks as TomoDetectorsMocks } from './hardware/tomodetectors/mocks';

// TomoImaging
export { default as TomoImagingVariants } from './hardware/tomoimaging';
export { default as TomoImagingActions } from './hardware/tomoimaging/TomoImagingActions';
export { default as TomoImagingDefault } from './hardware/tomoimaging/TomoImagingDefault';
export { default as TomoImagingExposureTime } from './hardware/tomoimaging/TomoImagingExposureTime';
export { default as TomoImagingSettleTime } from './hardware/tomoimaging/TomoImagingSettleTime';
export { default as TomoImagingUpdateMode } from './hardware/tomoimaging/TomoImagingUpdateMode';
export { TomoImagingState } from './hardware/tomoimaging/TomoImagingState';
export type { TomoImagingSchema } from './hardware/tomoimaging';
export { Mocks as TomoImagingMocks } from './hardware/tomoimaging/mocks';
export { default as TomoImagingSimulator } from './hardware/tomoimaging/mocks/Simulator';

// TomoSampleStage
export {
  default as TomoSampleStageVariants,
  isTomoSampleStageHardware,
  useTomoSampleStageHardware,
} from './hardware/tomosamplestage';
export type { TomoSampleStageSchema } from './hardware/tomosamplestage';

// TomoConfig
export {
  default as TomoConfigVariants,
  isTomoConfigHardware,
  useTomoConfigHardware,
} from './hardware/tomoconfig';
export { default as TomoConfigLatencyTime } from './hardware/tomoconfig/LatencyTime';
export type { TomoConfigSchema } from './hardware/tomoconfig';

// TomoHolo
export {
  default as TomoHoloVariants,
  isTomoHoloHardware,
  useTomoHoloHardware,
} from './hardware/tomoholo';
export { TomoHoloState } from './hardware/tomoholo/TomoHoloState';
export type { TomoHoloSchema, TomoHoloDistance } from './hardware/tomoholo';

// Valve
export { default as ValveVariants } from './hardware/valve';
export { default as ValveDefault } from './hardware/valve/Valve';
export type { ValveSchema } from './hardware/valve';
export { Mocks as ValveMocks } from './hardware/valve/mocks';

/* Hardware Object Options */
// TODO: Namespace Options into HardwareOptions

/* Helpers */
export { default as TypeIcon } from './hardware/utils/TypeIcon';
export type { Props as TypeIconOptions } from './hardware/utils/TypeIcon';
export { default as HardwareTemplate } from './hardware/utils/HardwareTemplate';
export { default as HardwareInputNumber } from './components/HardwareInputNumber';
export { default as HardwareNumericStep } from './components/HardwareNumericStep';
export * as HardwareState from './hardware/utils/State';
export * as Formatting from './utils/formatting';

/* Hardware components for special object  */
// Deprecated
export { default as NoObject } from './hardware/utils/NoObject';
export { default as LoadingObject } from './hardware/utils/LoadingObject';
export { default as MissingObject } from './hardware/utils/MissingObject';
export { default as ErrorObject } from './hardware/utils/ErrorObject';
export { default as MissingComponentObject } from './hardware/utils/MissingComponentObject';
export { default as NullObject } from './hardware/utils/NullObject';

/* Components */
export { default as FullSizer } from './components/FullSizer';
export { default as InfiniteKnob360 } from './components/InfiniteKnob360';
export { default as GaugeIndicator } from './components/GaugeIndicator';
export { default as NumericStep } from './components/NumericStep';
export { default as Panel } from './layout/Panel';
export { default as Todo } from './yaml-layout/components/Todo';
export { default as None } from './yaml-layout/components/None';

/* Types */
export * as HardwareTypes from './hardware/utils/types';
export * as HardwareSchema from './hardware/utils/schema';
export type {
  BaseHardware,
  Hardware,
  AnyHardware,
  HardwareVariant,
  HardwareComponentType,
} from './hardware/utils/types';

export type { AnySchema, GenericSchema } from './hardware/utils/schema';

/* Layout */
export {
  default as YAMLLayout,
  yamlMap,
  yamlContainers,
} from './yaml-layout/Main';
export { default as YAMLErrorBoundary } from './yaml-layout/ErrorBoundary';
export {
  renderYamlNode,
  registerYamlType,
  KeyError,
  MissingKeysError,
} from './yaml-layout/utils';
export type { YamlComponent, YamlNode } from './yaml-layout/model';
export * as YamlAsserts from './yaml-layout/components/asserts';
export {
  componentMap,
  registerComponent as registerYamlComponent,
  registerComponents as registerYamlComponents,
} from './yaml-layout/Component';

/* Hooks */
export {
  registerRuntimeHook,
  useHardware,
  useHardwareChangeActions,
  useHardwareSchema,
  useOperator,
  useScanRunning,
} from './registry/hooks';

/* HW Layout */
export * as HWObject from './hardware/utils/HardwareObject';
export { registerHardwareComponent } from './yaml-layout/components/HardwareGroup';

/* Monitor Panel */
export { MonitorHardware, dynamicOp } from './monitorpanel/MonitorHardware';
export {
  registerMonitorComponent,
  MonitorPanel,
  MonitorPanelItem,
} from './monitorpanel/MonitorPanel';
export type { MonitorPanelProps } from './monitorpanel/MonitorPanel';
export type { Monitor } from './monitorpanel/types';
