import type {
  AnyHardware,
  Hardware,
  HardwareChangeActions,
  HardwareSchemaDescription,
} from '../hardware/utils/types';

interface RuntimeHooks {
  useHardware?: (id: string | null) => AnyHardware | null;
  useHardwareChangeActions?: (name: string | null) => HardwareChangeActions;
  useHardwareSchema?: (
    hardware: { id: string; type: string } | null
  ) => HardwareSchemaDescription | null;
  useOperator?: () => boolean;
  useScanRunning?: () => boolean;
}

const runtimeHooks: RuntimeHooks = {};

export function registerRuntimeHook(hooks: Partial<RuntimeHooks>) {
  if (hooks.useHardware) {
    if (runtimeHooks.useHardware) {
      console.warn('useHardware hook was already registered');
    }
    runtimeHooks.useHardware = hooks.useHardware;
  }
  if (hooks.useHardwareChangeActions) {
    if (runtimeHooks.useHardwareChangeActions) {
      console.warn('useHardwareChangeActions hook was already registered');
    }
    runtimeHooks.useHardwareChangeActions = hooks.useHardwareChangeActions;
  }
  if (hooks.useHardwareSchema) {
    if (runtimeHooks.useHardwareSchema) {
      console.warn('useHardwareSchema hook was already registered');
    }
    runtimeHooks.useHardwareSchema = hooks.useHardwareSchema;
  }
  if (hooks.useOperator) {
    if (runtimeHooks.useOperator) {
      console.warn('useOperator hook was already registered');
    }
    runtimeHooks.useOperator = hooks.useOperator;
  }
  if (hooks.useScanRunning) {
    if (runtimeHooks.useScanRunning) {
      console.warn('useScanRunning hook was already registered');
    }
    runtimeHooks.useScanRunning = hooks.useScanRunning;
  }
}

/**
 * Return a hardware from it's hardware name.
 *
 * Return `null` if the name refers to nothing.
 *
 * @param name: An hardware identifier, or null
 */
export function useHardware(id: string | null): AnyHardware | null {
  if (!runtimeHooks.useHardware) {
    throw new Error('No `useHardware` hook registered');
  }
  return runtimeHooks.useHardware(id);
}

/**
 * Expose the generic actions provided by a specific hardware.
 *
 * If null is passed, dummy actions are exposed.
 *
 * @param name: Am hardware identifier, or null
 */
export function useHardwareChangeActions(
  name: string | null
): HardwareChangeActions {
  if (!runtimeHooks.useHardwareChangeActions) {
    throw new Error('No `useHardwareChangeActions` hook registered');
  }
  return runtimeHooks.useHardwareChangeActions(name);
}

/**
 * Expose the generic actions provided by a specific hardware.
 *
 * If null is passed, dummy actions are exposed.
 *
 * @param name: Am hardware identifier, or null
 */
export function useHardwareSchema(
  hardware: { id: string; type: string } | null
): HardwareSchemaDescription | null {
  if (!runtimeHooks.useHardwareSchema) {
    throw new Error('No `useHardwareSchema` hook registered');
  }
  return runtimeHooks.useHardwareSchema(hardware);
}

/**
 * True if the actual user can control the beamline (like moving motors)
 */
export function useOperator(): boolean {
  if (!runtimeHooks.useOperator) {
    throw new Error('No `useOperator` hook registered');
  }
  return runtimeHooks.useOperator();
}

/**
 * True if a scan is actually running
 */
export function useScanRunning(): boolean {
  if (!runtimeHooks.useScanRunning) {
    throw new Error('No `useScanRunning` hook registered');
  }
  return runtimeHooks.useScanRunning();
}
