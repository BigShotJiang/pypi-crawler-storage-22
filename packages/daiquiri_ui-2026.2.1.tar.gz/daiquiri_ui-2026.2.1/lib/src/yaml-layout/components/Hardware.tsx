import type { YamlComponent } from '@esrf/daiquiri-lib';
import { Alert } from 'react-bootstrap';
import {
  assertString,
  assertOptionalBoolean,
  assertOptionalString,
  assertOptionalNumber,
} from './asserts';
import { yamlHardwareComponent } from './HardwareGroup';

export default function Yaml(props: YamlComponent) {
  const {
    providers = {},
    yamlNode,
    id,
    variant,
    header,
    width,
    colWidth,
    emptyifnone,
    ...unknownOptions
  } = props;
  assertString(yamlNode, 'id', id);
  assertOptionalString(yamlNode, 'variant', variant);
  assertOptionalString(yamlNode, 'header', header);
  assertOptionalNumber(yamlNode, 'width', width);
  assertOptionalNumber(yamlNode, 'colWidth', colWidth);
  assertOptionalBoolean(yamlNode, 'emptyifnone', emptyifnone);
  // FIXME: Each hardware variant/kind have it's own options
  //        And the hardware kind can change dynamically
  //        We could try to normalize that in the future
  // assertNoUnknownKeys(yamlNode, unknownOptions);
  const options = {
    variant,
    header,
    width,
    colWidth,
    emptyifnone,
    ...unknownOptions,
  };

  if (!yamlHardwareComponent.Hardware) {
    return <Alert variant="warning">No `Hardware` component registered</Alert>;
  }

  const Hardware = yamlHardwareComponent.Hardware;

  return <Hardware providers={providers} id={id} options={options} />;
}
