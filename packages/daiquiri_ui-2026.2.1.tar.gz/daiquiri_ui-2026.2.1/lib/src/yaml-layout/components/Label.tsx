import type { YamlComponent } from '@esrf/daiquiri-lib';
import { assertNoUnknownKeys, assertString } from './asserts';

export default function YamlLabel(props: YamlComponent) {
  const { providers = {}, yamlNode, label, ...unknownOptions } = props;
  assertString(yamlNode, 'label', label);
  assertNoUnknownKeys(yamlNode, unknownOptions);
  return <div>{label}</div>;
}
