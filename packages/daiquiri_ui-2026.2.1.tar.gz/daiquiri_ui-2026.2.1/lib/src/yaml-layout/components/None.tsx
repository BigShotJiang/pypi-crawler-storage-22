import type { YamlComponent } from '@esrf/daiquiri-lib';

export default function Yaml(props: YamlComponent) {
  return <></>;
}
