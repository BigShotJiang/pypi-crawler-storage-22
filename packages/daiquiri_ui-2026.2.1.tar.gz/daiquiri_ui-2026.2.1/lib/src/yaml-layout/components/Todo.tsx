import type { YamlComponent } from '@esrf/daiquiri-lib';
import { Alert } from 'react-bootstrap';
import { assertOptionalString, assertNoUnknownKeys } from './asserts';

export default function Yaml(props: YamlComponent) {
  const { providers = {}, yamlNode, message, ...unknownOptions } = props;
  assertOptionalString(yamlNode, 'message', message);
  assertNoUnknownKeys(yamlNode, unknownOptions);

  return (
    <Alert variant="warning" className="mb-0">
      {message ?? 'TODO'}
    </Alert>
  );
}
