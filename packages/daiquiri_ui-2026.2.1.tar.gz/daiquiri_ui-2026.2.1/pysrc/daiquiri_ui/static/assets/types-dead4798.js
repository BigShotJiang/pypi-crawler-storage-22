import{P as e}from"./index-cb6f3145.js";const p=e.oneOf(["start","end"]),a=e.oneOfType([p,e.shape({sm:p}),e.shape({md:p}),e.shape({lg:p}),e.shape({xl:p}),e.shape({xxl:p}),e.object]);export{a};
