const fs = require('fs').promises;
const http = require('http');
const https = require('https');
const path = require('path');
const sc2t = require('json-schema-to-typescript');
const { parseArgs } = require('node:util');

const MODELS_LOCATION = path.join(
  __dirname,
  '..',
  'src',
  'resources',
  'models'
);
const NEW_MODELS_LOCATION = path.join(MODELS_LOCATION, 'new');

function getRemoteOpenAPI() {
  const url = process.env.OPENAPI_URL || 'https://localhost:8080/swagger/';
  console.log(`Retrieving openapi from:`, url);

  return new Promise((resolve) => {
    let data = '';
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    (url.startsWith('https') ? https : http).get(url, (res) => {
      console.log(`statusCode: ${res.statusCode}`);
      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('error', (error) => {
        console.error(error);
      });

      res.on('end', () => {
        resolve(data);
      });
    });
  });
}

async function getLocalFile(fileName) {
  // eslint-disable-next-line no-return-await
  return await fs.readFile(fileName, 'utf-8');
}

async function getExistingFiles() {
  const files = await fs.readdir(MODELS_LOCATION);
  return files.filter((file) => path.extname(file) === '.ts');
}

async function emptyNewModels() {
  const files = await fs.readdir(NEW_MODELS_LOCATION);
  const filteredFiles = files.filter((file) => path.extname(file) === '.ts');
  for (let fileId = 0; fileId < filteredFiles.length; fileId++) {
    const file = filteredFiles[fileId];
    // eslint-disable-next-line no-await-in-loop
    await fs.unlink(path.join(NEW_MODELS_LOCATION, file));
  }
}

async function parseOpenAPI(json, existingOnly = false) {
  try {
    const prettierrc = await getLocalFile(
      path.join(__dirname, '..', '.prettierrc')
    );
    await fs.mkdir(NEW_MODELS_LOCATION, { recursive: true });
    const schemaNames = Object.keys(json.definitions);
    const existingFiles = await getExistingFiles();
    if (existingOnly) {
      console.log('Replacing existing models only');
    }
    for (let index = 0; index < schemaNames.length; index++) {
      const schemaName = schemaNames[index];
      const fileName = `${schemaName}.ts`;

      if (existingOnly && !existingFiles.includes(fileName)) {
        continue;
      }

      if (schemaName.startsWith('Paginated')) continue;

      const schema = {
        definitions: json.definitions,
        ...json.definitions[schemaName],
      };

      try {
        // eslint-disable-next-line no-await-in-loop
        const rawTS = await sc2t.compile(schema, schemaName, {
          unknownAny: false,
          bannerComment:
            '/* eslint-disable @typescript-eslint/explicit-member-accessibility */',
          style: JSON.parse(prettierrc),
        });
        const interfaces = rawTS.split('export interface ');
        const classes = interfaces.slice(1);
        classes.forEach((cls, idx) => {
          const lines = cls.split('\n');
          const name = lines[0].replace(' {', '');
          // This is a nested class, skip it to avoid syntax errors
          if (lines[1].startsWith('  [k: string]:')) {
            console.log('Skipping nested class', name);
            classes[idx] = '';
            return;
          }
          classes[idx] = `export class ${name}Base {\n${lines
            .slice(1)
            .join('\n')}`;
        });

        // eslint-disable-next-line no-await-in-loop
        await fs.writeFile(
          path.join(
            existingOnly ? MODELS_LOCATION : NEW_MODELS_LOCATION,
            fileName
          ),
          `${rawTS}\n${classes.join('')}`
        );
      } catch (error) {
        console.log('Error parsing', schemaName, error);
      }
    }
  } catch (error) {
    console.error(error.message);
  }
}

async function main() {
  const { values, positionals } = parseArgs({
    allowPositionals: true,
    args: process.argv,
    options: {
      clean: { type: 'boolean' },
      existing: { type: 'boolean' },
    },
  });

  if (values.clean) {
    console.log('Cleaning `new` models directory');
    await emptyNewModels();
    // eslint-disable-next-line unicorn/no-process-exit
    process.exit();
  }

  const data =
    positionals.length > 2
      ? await getLocalFile(positionals[2])
      : await getRemoteOpenAPI();

  const jsonData = JSON.parse(data);
  await parseOpenAPI(jsonData, values.existing);
}

if (require.main === module) {
  // eslint-disable-next-line unicorn/prefer-top-level-await
  main();
}
