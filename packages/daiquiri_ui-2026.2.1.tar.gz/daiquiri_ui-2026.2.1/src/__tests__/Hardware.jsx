import { each } from 'lodash';
import { screen, userEvent, waitFor } from 'helpers/tests';
import { withControl } from 'helpers/tests/state';

import startApp from 'helpers/tests/startApp';
import { act } from '@testing-library/react';

// seems like there's a bug in the interaction between userEvent / vi.useFakeTimers
// TODO: see: https://github.com/testing-library/user-event/issues/1115
const getUserEventInstance = () =>
  userEvent.setup({
    advanceTimers: vi.advanceTimersByTime.bind(vi)
  });

describe('Hardware views', () => {
  test('load hardware objects, check label text is visible', async () => {
    const { resources } = await startApp({ layout: 'layout_hardware' });
    const res = resources.getHandler('hardware');

    await waitFor(() => expect(screen.getByText('omega 123')).toBeTruthy());

    const objs = res.getResponse({ method: 'get', url: '' });

    each(objs.rows, obj => {
      if (!obj.name.includes('objectref')) {
        expect(screen.getByText(obj.name)).toBeTruthy();
      }
    });
  });

  test('select motor, change value, submit', async () => {
    const { resources } = await startApp({
      layout: 'layout_hardware'
    });
    await waitFor(() => expect(screen.getByText('omega 123')).toBeTruthy());

    const omega = screen.getByLabelText('omega 123');
    expect(omega).toBeDisabled();

    withControl();
    await waitFor(() =>
      expect(screen.getByText(/session has control/)).toBeTruthy()
    );
    expect(omega).not.toBeDisabled();

    const spy = vi.spyOn(resources.client(), 'post');
    const newVal = 20;

    await userEvent.clear(omega);
    await userEvent.type(omega, `${newVal}{Enter}`);

    await waitFor(() =>
      expect(spy).toHaveBeenCalledWith(
        expect.stringMatching(/hardware\/omega$/),
        expect.objectContaining({
          function: 'move',
          value: newVal
        }),
        expect.anything(Object)
      )
    );
  }, 20_000_000);

  test('select motor, change value, dont submit', async () => {
    await startApp({ layout: 'layout_hardware' });
    await waitFor(() => expect(screen.getByText('omega 123')).toBeTruthy());

    const omega = screen.getByLabelText('omega 123');

    await act(async () => await withControl());
    await waitFor(() =>
      expect(screen.getByText(/session has control/)).toBeTruthy()
    );
    expect(omega).not.toBeDisabled();

    const lastVal = omega.value;
    const newVal = `${parseFloat(lastVal) + 20}`;

    const user = getUserEventInstance();

    vi.useFakeTimers();
    await user.clear(omega);
    await user.type(omega, newVal);
    expect(omega.value).toEqual(newVal);

    await user.tab();
    globalThis.IS_REACT_ACT_ENVIRONMENT = false;
    try {
      vi.advanceTimersByTime(3001);
    } finally {
      globalThis.IS_REACT_ACT_ENVIRONMENT = true;
    }

    expect(omega.value).toEqual(lastVal);
  }, 10_000);
});
