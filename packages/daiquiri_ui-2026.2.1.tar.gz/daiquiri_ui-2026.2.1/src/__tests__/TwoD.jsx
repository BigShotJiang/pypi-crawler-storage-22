import { each, keys } from 'lodash';
import { act } from '@testing-library/react';
import { screen, userEvent, waitFor, within } from 'helpers/tests';
import { withControl, withSubsample } from 'helpers/tests/state';
import startApp from 'helpers/tests/startApp';
import scans from 'providers/scans';

const waitSubsamples = async view => {
  await waitFor(() =>
    expect(
      view.container.querySelector('.table-subsamples')
    ).toBeInTheDocument()
  );
  const subsamples = view.container.querySelector('.table-subsamples');
  const withinSubsamples = within(subsamples);

  await waitFor(() =>
    expect(withinSubsamples.getAllByRole('row').length).toEqual(2)
  );

  return withinSubsamples;
};

const waitSelectSubsample = async (view, store) => {
  withSubsample(1, store);
  await waitFor(() =>
    expect(screen.getByTestId('objectview')).toBeInTheDocument()
  );
  const objSelector = within(view.getByTestId('objectview'));
  await waitFor(() =>
    expect(objSelector.getByText(/XRF map/i)).toBeInTheDocument()
  );

  return { objSelector };
};

describe('TwoD views', () => {
  test.skip('Load twod views, select subsample', async () => {
    const { view, store } = await startApp({ layout: 'layout_twod' });

    const { getAllByRole } = await waitSubsamples(view, store);

    const rows = getAllByRole('row');
    const cells = within(rows[1]).getAllByRole('cell');
    await userEvent.click(cells[0]);

    await waitFor(() =>
      expect(screen.queryByText(/no data collections/)).not.toBeInTheDocument()
    );

    await waitFor(() =>
      expect(screen.getByTestId('objectview')).toBeInTheDocument()
    );

    const objSelector = within(screen.getByTestId('objectview'));
    expect(objSelector.getByText(/XRF map/i)).toBeInTheDocument();
  });

  test.skip('Create scalar map', async () => {
    const { view, store } = await startApp({ layout: 'layout_twod' });

    await waitSubsamples(view);
    const { objSelector } = await waitSelectSubsample(view, store);

    const tables = objSelector.getAllByRole('table');

    const dcSelector = within(tables[0]);
    const buttons = dcSelector.getAllByRole('button');

    await userEvent.click(buttons[0]);

    await waitFor(() =>
      expect(
        screen.getByRole('button', { name: /Create Map/i })
      ).toBeInTheDocument()
    );

    const input = screen.getByTestId('scalar-selection');
    await userEvent.click(input);

    // Check scan counters match
    const scalarOptions = screen.getByRole('listbox');

    const data = scans.getNamespace('data').getInstance('mfs');
    const scanData = data.selector('results', store.getState());

    const optsSelector = within(scalarOptions);
    each(optsSelector.getAllByRole('option'), opt => {
      expect(opt.text in scanData[keys(scanData)[0]].data).toBeTruthy();
    });

    const modalSelector = within(
      screen.getByRole('dialog', { name: 'Create Map from Scalar' })
    );
    const close = modalSelector.getAllByRole('button', { name: /Close/ });
    await userEvent.click(close[0]);

    await waitFor(() =>
      expect(
        screen.queryByRole('button', { name: /Create Map/i })
      ).not.toBeInTheDocument()
    );
  });

  test.skip('Open ROI browser, add ROI from periodic table', async () => {
    const { view } = await startApp({ layout: 'layout_twod' });

    await act(async () => await waitSubsamples(view));
    const { objSelector } = await waitSelectSubsample(view);

    await act(async () => await withControl());
    await waitFor(() =>
      expect(screen.getByText(/session has control/)).toBeTruthy()
    );

    const roiBrowser = objSelector.getByRole('button', {
      name: /ROIs/
    });

    await userEvent.click(roiBrowser);

    await waitFor(() =>
      expect(
        screen.getByRole('dialog', { name: 'MCA ROIs' })
      ).toBeInTheDocument()
    );

    const dialogSelector = within(
      screen.getByRole('dialog', { name: 'MCA ROIs' })
    );
    await userEvent.click(dialogSelector.getByText('Mn'));

    // Add ROI
    await userEvent.click(screen.getByText('K-L3'));

    await userEvent.keyboard('{Escape}');

    await waitFor(() =>
      expect(dialogSelector.getByText('5835')).toBeInTheDocument()
    );

    await userEvent.click(
      dialogSelector.getAllByRole('button', { name: /Close/ })[0]
    );

    await waitFor(() =>
      expect(screen.queryByText('Mn')).not.toBeInTheDocument()
    );
  });
});
