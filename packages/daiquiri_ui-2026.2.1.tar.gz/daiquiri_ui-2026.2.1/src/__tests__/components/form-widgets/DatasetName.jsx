import { incrementTailNumber } from 'components/form-widgets/widgets/DatasetName';

describe('DatasetName', () => {
  test('check inc from 1', async () => {
    const result = incrementTailNumber('foo1');
    expect(result).toEqual('foo2');
  });
  test('check inc from 01', async () => {
    const result = incrementTailNumber('foo01');
    expect(result).toEqual('foo02');
  });
  test('check inc from foo', async () => {
    const result = incrementTailNumber('foo');
    expect(result).toEqual('foo2');
  });
  test('check inc with multiple numbers', async () => {
    const result = incrementTailNumber('foo200_10');
    expect(result).toEqual('foo200_11');
  });
  test('check inc with multiple numbers and space', async () => {
    const result = incrementTailNumber('foo  200 10');
    expect(result).toEqual('foo  200 11');
  });
});
