import { describe, expect, test } from 'vitest';
import { motorClosestModuloTrajectory } from 'components/hardware/motor/MotorTomoRotation';

const NO_LIMITS: [number | undefined, number | undefined] = [
  undefined,
  undefined,
];

const HALF_TURN_LIMITS: [number | undefined, number | undefined] = [-1, 181];

const ONE_TURN_LIMITS: [number | undefined, number | undefined] = [-1, 361];

describe('Check closest modulo trajectory', () => {
  test('0 to 90', () => {
    const result = motorClosestModuloTrajectory(90, 0, NO_LIMITS);
    expect(result).toBeCloseTo(90);
  });
  test('0 to 360', () => {
    const result = motorClosestModuloTrajectory(360, 0, NO_LIMITS);
    expect(result).toBeCloseTo(0);
  });
  test('0 to 180', () => {
    const result = motorClosestModuloTrajectory(180, 0, NO_LIMITS);
    expect(result).toBeCloseTo(180);
  });
  test('180 to 0 (stay closer to 0)', () => {
    const result = motorClosestModuloTrajectory(0, 180, NO_LIMITS);
    expect(result).toBeCloseTo(0);
  });
  test('180.1 to 0 (stay closer to 0)', () => {
    const result = motorClosestModuloTrajectory(0, 180.1, NO_LIMITS);
    expect(result).toBeCloseTo(0);
  });
  test('179.9 to 0 (stay closer to 0)', () => {
    const result = motorClosestModuloTrajectory(0, 179.9, NO_LIMITS);
    expect(result).toBeCloseTo(0);
  });
  test('90 to 270 (stay closer to 0)', () => {
    const result = motorClosestModuloTrajectory(270, 90, NO_LIMITS);
    expect(result).toBeCloseTo(-90);
  });
  test('0 to 180 (with half constaint)', () => {
    const result = motorClosestModuloTrajectory(180, 0, HALF_TURN_LIMITS);
    expect(result).toBeCloseTo(180);
  });
  test('180 to 0 (with half constaint)', () => {
    const result = motorClosestModuloTrajectory(0, 180, HALF_TURN_LIMITS);
    expect(result).toBeCloseTo(0);
  });
  test('90 to 270 (with half constaint)', () => {
    const result = motorClosestModuloTrajectory(270, 90, HALF_TURN_LIMITS);
    expect(result).toBe(null);
  });
  test('0 to 180 (with one turn constaint)', () => {
    const result = motorClosestModuloTrajectory(180, 0, ONE_TURN_LIMITS);
    expect(result).toBeCloseTo(180);
  });
  test('180 to 0 (with one turn constaint)', () => {
    const result = motorClosestModuloTrajectory(0, 180, ONE_TURN_LIMITS);
    expect(result).toBeCloseTo(0);
  });
  test('90 to 270 (with one turn constaint)', () => {
    const result = motorClosestModuloTrajectory(270, 90, ONE_TURN_LIMITS);
    expect(result).toBeCloseTo(270);
  });
  test('270 to 90 (with one turn constaint)', () => {
    const result = motorClosestModuloTrajectory(90, 270, ONE_TURN_LIMITS);
    expect(result).toBeCloseTo(90);
  });
  test('270 to 0 (with one turn constaint) -> 360 is closer', () => {
    // NOTE: In case of a single turn, 360 is maybe not the best choice
    //       Will see with people
    const result = motorClosestModuloTrajectory(0, 270, ONE_TURN_LIMITS);
    expect(result).toBeCloseTo(360);
  });
  test('0 to 270 (with one turn constaint)', () => {
    const result = motorClosestModuloTrajectory(270, 0, ONE_TURN_LIMITS);
    expect(result).toBeCloseTo(270);
  });
});
