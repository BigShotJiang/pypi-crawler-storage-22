import { act, renderHook } from '@testing-library/react';
import {
  setupProviders,
  mockClientSizing,
  createStore,
  waitFor,
  render as rtlRender,
  screen,
  userEvent,
  getAllByRole,
  within
} from 'helpers/tests';
import Resources from 'helpers/tests/resources';
import ConnectedObjectList from 'connect/2dview/ObjectList';
import app from 'providers/app';
import { useSuspense } from '@data-client/react';
import { SubSampleResource } from '../../../resources/SubSample';
import { renderDataHook } from '@data-client/test';
import { Provider } from 'react-redux';
import useSampleOptions, {
  useSubSampleOptions
} from 'components/samples/options';

describe('<ObjectList />', async () => {
  const resources = new Resources();
  const metadataHandler = resources.getHandler('metadata');
  resources.getHandler('schema');
  const schema = app.getNamespace('schema').getInstance('default');

  const store = createStore();
  setupProviders(store);

  const wrapper = ({ children }) => (
    <Provider store={store}>{children}</Provider>
  );

  const render = () => {
    mockClientSizing();
    return rtlRender(<ConnectedObjectList />, { store });
  };

  it('matches empty', () => {
    render();
    expect(screen.getByText(/No objects/)).toBeTruthy();
  });

  it('matches loaded subsamples', async () => {
    await schema.fetch();
    const { result } = renderHook(() => useSampleOptions(), { wrapper });
    act(() => result.current.addSampleSelection({ sampleid: 1 }));
    render();
    await waitFor(() => expect(screen.getByText(/ROI/)).toBeTruthy());
  });

  it.skip('select object', async () => {
    await schema.fetch();
    const { result } = renderHook(() => useSampleOptions(), { wrapper });
    const { result: resultSub } = renderHook(() => useSubSampleOptions(), {
      wrapper
    });
    act(() => result.current.addSampleSelection({ sampleid: 1 }));

    render();

    const rows = screen.getAllByRole('row');
    const cells = within(rows[1]).getAllByRole('cell');
    await userEvent.click(cells[0]);
    const selected = resultSub.current.subSampleSelection;

    expect(1).toEqual(selected[0]);
  });

  it.skip('delete object', async () => {
    await schema.fetch();
    const { result } = renderHook(() => useSampleOptions(), { wrapper });
    act(() => result.current.addSelection({ sampleid: 1 }));

    render();

    const rows = screen.getAllByRole('row');
    expect(rows.length - 1).toEqual(1);

    const cells = getAllByRole(rows[1], 'cell');
    const del = getAllByRole(cells[cells.length - 1], 'button')[1];
    expect(del.classList.contains('delete')).toBe(true);

    await userEvent.click(del);

    const button = screen.getByRole('button', { name: /OK/i, hidden: true });
    await userEvent.click(button);

    expect(screen.getByText(/No objects/)).toBeTruthy();
  });

  it.skip('modify object', async () => {
    await schema.fetch();
    const { result } = renderHook(() => useSampleOptions(), { wrapper });
    act(() => result.current.addSelection({ sampleid: 1 }));

    render();

    const rows = screen.getAllByRole('row');
    const cells = getAllByRole(rows[1], 'cell');
    const edit = getAllByRole(cells[cells.length - 1], 'button')[0];
    expect(edit.classList.contains('view')).toBe(true);

    await act(async () => await userEvent.click(edit));
    const spy = vi.spyOn(resources.client(), 'patch');

    const vals = {
      width: 300,
      height: 400
    };
    const keys = Object.keys(vals);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      const v = vals[k];

      const eregex = new RegExp(`edit-${k}`, 'i');
      const button = screen.getByLabelText(eregex);
      await userEvent.click(button);

      const regex = new RegExp(k, 'i');
      const input = screen.getByLabelText(regex);

      await userEvent.clear(input);
      await userEvent.type(input, v.toString());
      const save = screen.getByRole('button', { name: /Save/i });
      await userEvent.click(save);
    }

    await waitFor(() => expect(spy).toHaveBeenCalledTimes(2));

    const { results } = renderDataHook(() => {
      return useSuspense(SubSampleResource.getList);
    });
    const objects = results.rows;

    expect(objects[1].x2 - objects[1].x).toBeCloseTo(vals.width);
    expect(objects[1].y2 - objects[1].y).toBeCloseTo(vals.height);
  });
});
