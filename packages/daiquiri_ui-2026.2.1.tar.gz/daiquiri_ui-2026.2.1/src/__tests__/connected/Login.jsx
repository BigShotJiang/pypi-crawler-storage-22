import {
  setupProviders,
  mockClientSizing,
  createStore,
  render as rtlRender,
  screen,
  userEvent,
  waitFor
} from 'helpers/tests';

import Resources from 'helpers/tests/resources';

import Login from 'connect/Login';
import session from 'providers/session';
import app from 'providers/app';

describe('Login', () => {
  const resources = new Resources();
  const authHandler = resources.getHandler('authenticator');

  const store = createStore();
  setupProviders(store);
  app.getNamespace('config').fetch();

  const render = () => {
    mockClientSizing();
    const view = rtlRender(<Login />, { store });

    const user = screen.getByLabelText('Username');
    const pass = screen.getByLabelText('Password');
    const submit = screen.getByRole('button', { name: /Login/i });

    return { view, user, pass, submit };
  };

  test('login failed', async () => {
    const cfg = app.getNamespace('config').getInstance('default');
    await waitFor(() =>
      expect(cfg.selector('fetched', store.getState())).toBeTruthy()
    );
    const { user, pass, submit } = render();

    const method = {
      url: '/login',
      method: 'post'
    };
    const obj = authHandler.getObject(method);

    await userEvent.type(user, obj.invalidUser);
    await userEvent.type(pass, 'abcd');
    await userEvent.click(submit);

    await waitFor(() =>
      expect(session.selector('auth', store.getState())).toEqual(false)
    );

    const resp = authHandler.getResponse({
      ...method,
      payload: {
        username: obj.invalidUser
      }
    });

    expect(session.selector('error', store.getState())).toEqual(resp.error);
  });

  test('login success', async () => {
    const { user, pass, submit } = render();

    const method = {
      url: '/login',
      method: 'post'
    };
    const obj = authHandler.getObject(method);

    await userEvent.type(user, obj.validUser);
    await userEvent.type(pass, 'abcd');
    await userEvent.click(submit);

    await waitFor(() =>
      expect(session.selector('auth', store.getState())).toEqual(true)
    );
  });
});
