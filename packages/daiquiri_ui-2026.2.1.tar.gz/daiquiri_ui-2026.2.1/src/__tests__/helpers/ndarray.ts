import { describe, expect, test, expectTypeOf } from 'vitest';
import {
  toTypedArray,
  concateArrays,
  concateSharedArrays,
} from '../../helpers/ndarray';

function initArrayBuffer(data: number[]) {
  const array = new Uint8Array(data);
  return array.buffer;
}

describe('Check ndarray', () => {
  test('Create Uint8Array', () => {
    const buffer = initArrayBuffer([0, 1, 2, 3]);
    const a = toTypedArray(buffer, 'u1');
    expect(a).toBeInstanceOf(Uint8Array);
    expect([...a]).toEqual([0, 1, 2, 3]);
  });
  test('Create Uint16Array', () => {
    const buffer = initArrayBuffer([0, 1, 2, 3]);
    const a = toTypedArray(buffer, '<u2');
    expect(a).toBeInstanceOf(Uint16Array);
    expect([...a]).toEqual([1 * 256, 2 + 3 * 256]);
  });
});

describe('Check concate', () => {
  test('Concate Uint8Array+Uint8Array', () => {
    const bufferA = initArrayBuffer([0, 1]);
    const bufferB = initArrayBuffer([2, 3]);
    const a = toTypedArray(bufferA, 'u1');
    const b = toTypedArray(bufferB, 'u1');
    const c = concateArrays(a, b);
    expect(c).toBeInstanceOf(Uint8Array);
    expect([...c]).toEqual([0, 1, 2, 3]);
  });
  test('Concate undefined+Uint8Array', () => {
    const bufferB = initArrayBuffer([0, 1, 2, 3]);
    const b = toTypedArray(bufferB, 'u1');
    const c = concateArrays(undefined, b);
    expect(c).toBeInstanceOf(Uint8Array);
    expect([...c]).toEqual([0, 1, 2, 3]);
  });
  test('Concate Uint16Array+Uint16Array', () => {
    const bufferA = initArrayBuffer([0, 0, 1, 0]);
    const bufferB = initArrayBuffer([2, 0, 3, 0]);
    const a = toTypedArray(bufferA, '<u2');
    const b = toTypedArray(bufferB, '<u2');
    const c = concateArrays(a, b);
    expect(c).toBeInstanceOf(Uint16Array);
    expect([...c]).toEqual([0, 1, 2, 3]);
  });
  test('Concate Uint8Array+subarray', () => {
    const bufferA = initArrayBuffer([0, 1]);
    const bufferB = initArrayBuffer([2, 3]);
    const a = toTypedArray(bufferA, 'u1');
    const b = toTypedArray(bufferB, 'u1').subarray(1);
    const c = concateArrays(a, b);
    expect(c).toBeInstanceOf(Uint8Array);
    expect([...c]).toEqual([0, 1, 3]);
  });
});

describe('Check shared concate', () => {
  test('Concate Uint8Array+Uint8Array', () => {
    const bufferA = initArrayBuffer([0, 1]);
    const bufferB = initArrayBuffer([2, 3]);
    const a = toTypedArray(bufferA, 'u1');
    const b = toTypedArray(bufferB, 'u1');
    const c = concateSharedArrays(a, b);
    expect(c).toBeInstanceOf(Uint8Array);
    expect(c.buffer).toBeInstanceOf(SharedArrayBuffer);
    expect([...c]).toEqual([0, 1, 2, 3]);
  });
  test('Concate undefined+Uint8Array', () => {
    const bufferB = initArrayBuffer([0, 1, 2, 3]);
    const b = toTypedArray(bufferB, 'u1');
    const c = concateSharedArrays(undefined, b);
    expect(c).toBeInstanceOf(Uint8Array);
    expect(c.buffer).toBeInstanceOf(SharedArrayBuffer);
    expect([...c]).toEqual([0, 1, 2, 3]);
  });
  test('Concate Uint16Array+Uint16Array', () => {
    const bufferA = initArrayBuffer([0, 0, 1, 0]);
    const bufferB = initArrayBuffer([2, 0, 3, 0]);
    const a = toTypedArray(bufferA, '<u2');
    const b = toTypedArray(bufferB, '<u2');
    const c = concateSharedArrays(a, b);
    expect(c).toBeInstanceOf(Uint16Array);
    expect(c.buffer).toBeInstanceOf(SharedArrayBuffer);
    expect([...c]).toEqual([0, 1, 2, 3]);
  });
  test('Concate Uint8Array+subarray', () => {
    const bufferA = initArrayBuffer([0, 1]);
    const bufferB = initArrayBuffer([2, 3]);
    const a = toTypedArray(bufferA, 'u1');
    const b = toTypedArray(bufferB, 'u1').subarray(1);
    const c = concateSharedArrays(a, b);
    expect(c).toBeInstanceOf(Uint8Array);
    expect(c.buffer).toBeInstanceOf(SharedArrayBuffer);
    expect([...c]).toEqual([0, 1, 3]);
  });
});
