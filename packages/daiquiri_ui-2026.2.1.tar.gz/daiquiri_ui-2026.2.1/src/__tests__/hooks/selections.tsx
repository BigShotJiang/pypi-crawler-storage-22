import type { ReactElement } from 'react';
import { act, renderHook } from '@testing-library/react';
import { setupProviders, createStore } from 'helpers/tests';
import { Provider } from 'react-redux';
import useSampleOptions, {
  useSubSampleOptions,
} from 'components/samples/options';

describe('Selection Hooks', () => {
  const store = createStore();
  setupProviders(store);

  const wrapper = ({ children }: { children: any }) => (
    <Provider store={store}>{children}</Provider>
  );

  beforeEach(() => {
    const { result } = renderHook(() => useSampleOptions(), { wrapper });
    result.current.resetSampleSelection();
    const { result: resultSub } = renderHook(() => useSubSampleOptions(), {
      wrapper,
    });
    resultSub.current.resetSubSampleSelection();
  });

  it('Sample Selection', async () => {
    const { result } = renderHook(() => useSampleOptions(), { wrapper });
    act(() => result.current.addSampleSelection({ sampleid: 1 }));
    act(() => result.current.addSampleSelection({ sampleid: 2 }));
    expect([1, 2]).toEqual(result.current.sampleSelection);
  });

  it('Sub Sample Selection', async () => {
    const { result } = renderHook(() => useSubSampleOptions(), { wrapper });
    act(() => result.current.addSubSampleSelection({ subsampleid: 1 }));
    act(() => result.current.addSubSampleSelection({ subsampleid: 2 }));
    expect([1, 2]).toEqual(result.current.subSampleSelection);
  });

  it('Sub Sample Selection', async () => {
    const { result } = renderHook(() => useSampleOptions(), { wrapper });
    act(() => result.current.addSampleSelection({ sampleid: 1 }));
    act(() => result.current.addSampleSelection({ sampleid: 2 }));
    expect([1, 2]).toEqual(result.current.sampleSelection);

    const { result: resultSub } = renderHook(() => useSubSampleOptions(), {
      wrapper,
    });
    act(() => resultSub.current.addSubSampleSelection({ subsampleid: 3 }));
    act(() => resultSub.current.addSubSampleSelection({ subsampleid: 4 }));
    expect([3, 4]).toEqual(resultSub.current.subSampleSelection);
  });
});
