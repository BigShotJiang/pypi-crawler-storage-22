import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { keys, map } from 'lodash';
import { Button, Form, Container, Col, Row, Alert } from 'react-bootstrap';
import { useController } from '@data-client/react';

import ButtonTriggerModalStore from 'connect/layout/ButtonTriggerModalStore';
import type { XRFMap } from '../../resources/models/XRFMap';
import { CompositeMapResource } from '../../resources/CompositeMap';
import { MapResource } from '../../resources/Map';

interface ICompositeButton {
  maps: XRFMap[];
  selection?: Record<string, any>;
  subsampleid: number;
  disabled?: boolean;
}

type ColorKey = 'r' | 'g' | 'b';

function useColorForm(selection: string[]) {
  // Colors
  const [colors, setColors] = useState<Record<ColorKey, string>>({
    r: selection[0],
    g: selection[1],
    b: selection[2],
  });
  const updateColor = useCallback(
    (color: ColorKey, value: string) =>
      setColors((previousValue) => ({ ...previousValue, [color]: value })),
    []
  );

  useEffect(() => {
    const next = {
      r: selection[0],
      g: selection[1],
      b: selection[2],
    };

    // Only set the color state when there are changes
    setColors((prev) => {
      const hasChanged =
        prev.r !== next.r || prev.g !== next.g || prev.b !== next.b;
      return hasChanged ? next : prev;
    });
  }, [selection]);

  // Opacities
  const [opacities, setOpacities] = useState<Record<ColorKey, string>>({
    r: '100',
    g: '100',
    b: '100',
  });
  const updateOpacity = useCallback(
    (color: ColorKey, value: string) =>
      setOpacities((currentValue) => ({ ...currentValue, [color]: value })),
    []
  );

  return {
    colors,
    updateColor,
    opacities,
    updateOpacity,
  };
}

interface ModalHandler {
  showModal: () => void;
  close: () => void;
}

export default function CompositeButton({
  selection = {},
  disabled = false,
  ...props
}: ICompositeButton) {
  const { fetch, invalidateAll } = useController();
  const [adding, setAdding] = useState<boolean>(false);
  const [addingError, setAddingError] = useState<string>('');

  // Initialize references
  const modalRef = useRef<ModalHandler>(null);

  // Compute sorted selection only when `selection` changes
  const sortedSelection = useMemo(() => {
    const keys = Object.entries(selection)
      .sort(([, a], [, b]) => a - b)
      .map(([key]) => key);

    // Make sure we always have three selection
    return Array.from({ length: 3 }, (_, i) => keys[i] ?? undefined);
  }, [selection]);

  // Initialize color form
  const { colors, updateColor, opacities, updateOpacity } =
    useColorForm(sortedSelection);

  const onClick = () => {
    const config: Record<string, number> = {};
    for (const c of ['r', 'g', 'b'] as const) {
      config[c] = Number.parseInt(colors[c], 10);
      config[`${c}opacity`] = Number.parseFloat(opacities[c]) / 100;
    }

    setAdding(true);
    fetch(CompositeMapResource.getList.push, {
      subsampleid: props.subsampleid,
      ...config,
    })
      .then(() => {
        setAdding(false);
        modalRef.current?.close();
        invalidateAll(MapResource.getList);
        invalidateAll(CompositeMapResource.getList);
      })
      .catch((error) => {
        setAddingError(error);
      });
  };

  const opts = map(keys(selection), (o) => {
    const xmap = props.maps.find((map) => map.mapid === Number.parseInt(o));
    if (!xmap) return null;
    const key = xmap.scalar || `${xmap.element} - ${xmap.edge}`;
    return (
      <option key={o} value={o}>
        {o}:{key}
      </option>
    );
  });

  return (
    <ButtonTriggerModalStore
      id="composite"
      button={<i className="fa fa-picture-o" />}
      buttonProps={{
        className: 'me-1 float-end',
        disabled,
      }}
      title="Generate Composite Map"
      buttons={
        <Button disabled={adding} onClick={onClick}>
          {adding && (
            <>
              <i className="fa fa-spin fa-spinner" /> Creating
            </>
          )}
          {!adding && <>Create</>}
        </Button>
      }
      ref={modalRef}
    >
      <Container className="mt-3">
        {addingError && (
          <Alert variant="danger">
            Could not create composite map: {addingError}
          </Alert>
        )}

        <Form>
          <Form.Group as={Row}>
            <Col sm={3} />
            <Col>Map</Col>
            <Col>Opacity</Col>
          </Form.Group>
          <Form.Group as={Row}>
            <Form.Label column sm={3}>
              Red
            </Form.Label>
            <Col>
              <Form.Control
                as="select"
                value={colors.r}
                onChange={(e) => updateColor('r', e.target.value)}
              >
                {opts}
              </Form.Control>
            </Col>
            <Col>
              <Form.Control
                type="range"
                min="0"
                max="100"
                value={opacities.r}
                onChange={(e) => updateOpacity('r', e.target.value)}
              />
            </Col>
          </Form.Group>
          <Form.Group as={Row}>
            <Form.Label column sm={3}>
              Green
            </Form.Label>
            <Col>
              <Form.Control
                as="select"
                value={colors.g}
                onChange={(e) => updateColor('g', e.target.value)}
              >
                {opts}
              </Form.Control>
            </Col>
            <Col>
              <Form.Control
                type="range"
                min="0"
                max="100"
                value={opacities.g}
                onChange={(e) => updateOpacity('g', e.target.value)}
              />
            </Col>
          </Form.Group>
          <Form.Group as={Row}>
            <Form.Label column sm={3}>
              Blue
            </Form.Label>
            <Col>
              <Form.Control
                as="select"
                value={colors.b}
                onChange={(e) => updateColor('b', e.target.value)}
              >
                {opts}
              </Form.Control>
            </Col>
            <Col>
              <Form.Control
                type="range"
                min="0"
                max="100"
                value={opacities.b}
                onChange={(e) => updateOpacity('b', e.target.value)}
              />
            </Col>
          </Form.Group>
        </Form>
      </Container>
    </ButtonTriggerModalStore>
  );
}
