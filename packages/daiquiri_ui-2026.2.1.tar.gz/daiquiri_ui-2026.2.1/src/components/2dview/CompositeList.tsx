import type { RefObject } from 'react';
import { createRef, useEffect } from 'react';
import { each, debounce } from 'lodash';
import { Button, OverlayTrigger, Popover, Form } from 'react-bootstrap';
import { useController, useDLE } from '@data-client/react';

import Table from 'components/table';
import DeleteButton from 'components/common/DeleteButton';

import { CompositeMapResource } from '../../resources/CompositeMap';
import type { XRFCompositeMap } from '../../resources/models/XRFCompositeMap';
import { MapResource } from '../../resources/Map';

interface IEditButton {
  composite: XRFCompositeMap;
  onChange: (payload: any) => Promise<any>;
}

function HideShowButton(props: IEditButton) {
  const { composite, onChange } = props;
  function onClick() {
    onChange({
      compositeid: composite.compositeid,
      opacity: composite.opacity ? 0 : 1,
    });
  }

  return (
    <Button
      className="me-1"
      title={composite.opacity ? 'Hide' : 'Show'}
      size="sm"
      onClick={onClick}
      variant={composite.opacity ? 'primary' : 'secondary'}
    >
      <i className={`fa fa-${composite.opacity ? 'eye' : 'eye-slash'}`} />
    </Button>
  );
}

function EditButton(props: IEditButton) {
  const { composite, onChange } = props;
  const orefs: Record<string, RefObject<HTMLInputElement>> = {};
  each(['r', 'g', 'b'], (c) => {
    orefs[c] = createRef();
  });
  const debouncedOnChange = debounce(onChange, 1000);

  useEffect(() => {
    each(['r', 'g', 'b'], (c) => {
      if (orefs[c].current) {
        // @ts-expect-error
        orefs[c].current.value = composite[`${c}opacity`] * 100;
      }
    });
  }, [composite]);

  function doOnChange(e: React.ChangeEvent<HTMLInputElement>) {
    debouncedOnChange({
      compositeid: composite.compositeid,
      [`${e.target.name}opacity`]: Number.parseInt(e.target.value) / 100,
    });
  }

  return (
    <OverlayTrigger
      trigger="click"
      placement="left"
      rootClose
      overlay={
        <Popover>
          <Popover.Header>Composite Controls</Popover.Header>
          <Popover.Body>
            <Form.Group>
              <Form.Label>Red [{composite.rroi}]</Form.Label>
              <Form.Control
                type="range"
                min="0"
                max="100"
                defaultValue={composite.ropacity ?? 0 * 100}
                name="r"
                onChange={doOnChange}
                ref={orefs.r}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Green [{composite.groi}]</Form.Label>
              <Form.Control
                type="range"
                min="0"
                max="100"
                defaultValue={composite.gopacity ?? 0 * 100}
                name="g"
                onChange={doOnChange}
                ref={orefs.g}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Blue [{composite.broi}]</Form.Label>
              <Form.Control
                type="range"
                min="0"
                max="100"
                defaultValue={composite.bopacity ?? 0 * 100}
                name="b"
                onChange={doOnChange}
                ref={orefs.b}
              />
            </Form.Group>
          </Popover.Body>
        </Popover>
      }
    >
      <Button title="Composite Controls" size="sm">
        <i className="fa fa-sun-o" />
      </Button>
    </OverlayTrigger>
  );
}

function ActionCell(
  cell: string,
  row: XRFCompositeMap,
  rowIndex: number,
  formatExtraData: any
) {
  if (!row.compositeid) return null;
  return (
    <>
      <HideShowButton
        composite={row}
        onChange={formatExtraData.updateCompositeMap}
      />
      <EditButton
        composite={row}
        onChange={formatExtraData.updateCompositeMap}
      />
      <DeleteButton
        id={row.compositeid}
        onClick={formatExtraData.deleteCompositeMap}
        confirm
      />
    </>
  );
}

export default function CompositeList({
  subsampleid,
}: {
  subsampleid: number;
}) {
  const { fetch, invalidateAll } = useController();
  const { data: composites, loading } = useDLE(CompositeMapResource.getList, {
    subsampleid,
  });

  function deleteCompositeMap(compositeid: number) {
    fetch(CompositeMapResource.delete, { compositeid }).then(() => {
      invalidateAll(MapResource.getList);
    });
  }

  function updateCompositeMap(payload: any) {
    const { compositeid, ...rest } = payload;
    fetch(CompositeMapResource.partialUpdate, { compositeid }, rest);
  }

  const columns = [
    { dataField: 'compositeid', text: 'Id' },
    { dataField: 'r', text: 'Red' },
    { dataField: 'rroi', text: 'ROI', classes: 'text-break' },
    { dataField: 'g', text: 'Green' },
    { dataField: 'groi', text: 'ROI', classes: 'text-break' },
    { dataField: 'b', text: 'Blue' },
    { dataField: 'broi', text: 'ROI', classes: 'text-break' },
    {
      dataField: 'action',
      text: '',
      formatter: ActionCell,
      formatExtraData: {
        deleteCompositeMap,
        updateCompositeMap,
      },
      classes: 'text-end text-nowrap',
    },
  ];

  return (
    <Table
      loading={loading}
      keyField="compositeid"
      data={composites.rows || []}
      columns={columns}
      noDataIndication="No composite maps for this object"
    />
  );
}
