import { useEffect, useCallback, useRef, useState } from 'react';
import { map, find } from 'lodash';
import {
  Button,
  ButtonToolbar,
  Navbar,
  Form,
  DropdownButton,
  ToggleButtonGroup,
  ToggleButton,
  Container,
  Row,
  Col,
  InputGroup,
} from 'react-bootstrap';

import config from 'config/config';
import Tooltip from 'components/common/Tooltip';
import ImageSelection from 'connect/samples/ImageSelection';
import ButtonTriggerModalStore from 'connect/layout/ButtonTriggerModalStore';
import type { ButtonTriggerModalStoreRef } from 'components/layout/models';
import { Formatting } from '@esrf/daiquiri-lib';
import { useOperator, useScanRunning } from '@esrf/daiquiri-lib';
import useUserPreference from '../utils/UseUserPreference';
import use2dOptions from './options';
import useSampleOptions from '../samples/options';

interface ISetQuantizeModal {
  setQuantization: ([x, y]: [x: number, y: number]) => void;
}

function SetQuantizeModal(props: ISetQuantizeModal) {
  const sizeXRef = useRef<HTMLInputElement>(null);
  const sizeYRef = useRef<HTMLInputElement>(null);
  const modalRef = useRef<ButtonTriggerModalStoreRef>();
  const formRef = useRef<HTMLFormElement | null>(null);
  const [isValidated, setIsValidated] = useState(false);

  const onSetQuantization = useCallback(() => {
    setIsValidated(true);
    if (!formRef.current?.checkValidity()) return;
    if (!(sizeXRef.current && sizeYRef.current)) return;
    props.setQuantization([
      Number.parseFloat(sizeXRef.current?.value) * 1000, // in microns
      Number.parseFloat(sizeYRef.current?.value) * 1000,
    ]);
    modalRef.current?.close();
  }, []);

  const onFormRefLoaded = useCallback((element: HTMLFormElement) => {
    formRef.current = element;
    sizeXRef.current?.focus();
  }, []);

  return (
    <ButtonTriggerModalStore
      id="setQuantization"
      title="Set Quantization"
      ref={modalRef}
      buttonProps={{ className: 'me-1 d-inline', size: 'sm' }}
      buttons={<Button onClick={onSetQuantization}>Set Quantization</Button>}
      button={
        <>
          <i className="fa fa-plus" />
        </>
      }
    >
      <Form ref={onFormRefLoaded} validated={isValidated}>
        <Form.Group as={Row}>
          <Form.Label column sm={3}>
            Quantization
          </Form.Label>
          <Col>
            <InputGroup>
              <Form.Control
                ref={sizeXRef}
                type="number"
                step="0.001"
                required
                onKeyDown={(e) => e.key === 'Enter' && onSetQuantization()}
              />
              <InputGroup.Text>&micro;m</InputGroup.Text>
              <Form.Control.Feedback type="invalid">
                Please provide a quantization in X
              </Form.Control.Feedback>
            </InputGroup>
          </Col>
          <Col xs={1} className="text-center">
            x
          </Col>
          <Col>
            <InputGroup>
              <Form.Control
                ref={sizeYRef}
                type="number"
                step="0.001"
                required
                onKeyDown={(e) => e.key === 'Enter' && onSetQuantization()}
              />
              <InputGroup.Text>&micro;m</InputGroup.Text>
              <Form.Control.Feedback type="invalid">
                Please provide a quantization in Y
              </Form.Control.Feedback>
            </InputGroup>
          </Col>
        </Form.Group>
      </Form>
    </ButtonTriggerModalStore>
  );
}

interface AdditionalUrl {
  name: string;
}

interface IControls {
  originSettings: Record<string, any>;
  centreOnClick: boolean;
  drawSnap: boolean;
  multiROI: boolean;
  clampLOI: boolean;
  cursor: boolean;
  drawQuantize: number[];

  showStaff: boolean;
  pendingSaveImage: boolean;
  pendingSaveCanvas: boolean;
  config: Record<string, any>;
  sources: Record<string, any>[];
  selectedSampleActionId: number;

  actions: {
    fetchOriginSettings: () => Promise<any>;
    updateOriginSettings: (payload: any) => Promise<any>;
    toggleCentreOnClick: (payload: any) => void;
    toggleDrawSnap: (payload: any) => void;
    toggleMultiROI: (payload: any) => void;
    toggleClampLOI: (payload: any) => void;
    toggleCursor: (payload: any) => void;
    changeDrawQuantize: (payload: any) => void;
    saveImage: (payload: any) => Promise<any>;
    saveCanvas: () => Promise<any>;
    addToast: (payload: any) => void;
    autoFocusImage: () => Promise<any>;
    setSourceHover: (payload: any) => void;
  };
}

export default function Controls(props: IControls) {
  const { currentSampleId } = useSampleOptions();

  useEffect(() => {
    props.actions.fetchOriginSettings();
  }, []);

  const {
    currentAction,
    setAction,
    disableOrigin,
    setDisableOrigin,
    clampOrigin,
    setClampOrigin,
    clampTarget,
    setClampTarget,
    sourceUrl,
    setSourceUrl,
  } = use2dOptions();

  function doSetAction(type: string) {
    if (currentAction === type) setAction('');
    else {
      setAction(type);
      if (['roi', 'loi', 'poi', 'measure', 'move'].includes(type)) {
        props.actions.toggleCursor(false);
      }
    }
  }

  const operator = useOperator();
  const runningScan = useScanRunning();

  function saveImage() {
    props.actions.saveImage({ sampleid: currentSampleId }).catch((error) => {
      props.actions.addToast({
        type: 'error',
        title: 'Could not save image',
        text: error.response?.data?.error || error.message,
      });
    });
  }

  function toggleClampOrigin() {
    setClampOrigin(!clampOrigin);
  }

  function toggleDisableOrigin() {
    setDisableOrigin(!disableOrigin);
  }

  function toggleCentreOnClick() {
    props.actions.toggleCentreOnClick(!props.centreOnClick);
  }

  function changeDrawQuantize(e: any) {
    const value = Number.parseInt(e.target.value, 10);
    props.actions.changeDrawQuantize([value, value]);
  }

  function toggleDrawSnap() {
    props.actions.toggleDrawSnap(!props.drawSnap);
  }

  function toggleMultiROI() {
    props.actions.toggleMultiROI(!props.multiROI);
  }

  function toggleClampLOI() {
    props.actions.toggleClampLOI(!props.clampLOI);
  }

  function toggleCursor() {
    if (props.cursor) props.actions.setSourceHover({});
    props.actions.toggleCursor(!props.cursor);
  }

  function saveCanvas() {
    props.actions.saveCanvas();
  }

  function autoFocusImage() {
    props.actions.autoFocusImage();
  }

  function toggleOriginSetting(settingKey: string) {
    props.actions.updateOriginSettings({
      [settingKey]: !props.originSettings[settingKey],
    });
  }

  function selectSourceUrl(e: any) {
    setSourceUrl(e.target.value);
  }

  function doSetClampTarget(e: any) {
    setClampTarget(e.target.value);
  }

  const drawQuantizations = {
    50_000: '50µm',
    25_000: '25µm',
    20_000: '20µm',
    10_000: '10µm',
    5000: '5µm',
    1000: '1µm',
    500: '500nm',
    200: '200nm',
    ...Object.fromEntries(
      props.config?.options?.extra_quantizations?.map((customQuant: number) => {
        const engSize = Formatting.formatEng(customQuant * config.pixelSize);
        return [
          customQuant,
          `${Formatting.round(engSize.scalar, 12)}${engSize.prefix}m`,
        ];
      }) || []
    ),
  };

  useEffect(() => {
    if (!props.drawQuantize) {
      const value = props.config.options.default_quantization || 5000;
      props.actions.changeDrawQuantize([value, value]);
    }
  }, []);

  const isSquareQuantize = props.drawQuantize
    ? props.drawQuantize[0] === props.drawQuantize[1]
    : true;
  const isCustomQuantise = props.drawQuantize
    ? props.drawQuantize[0] !== props.drawQuantize[1] ||
      !Object.keys(drawQuantizations).includes(String(props.drawQuantize[0]))
    : false;

  const customQuantizeW = isCustomQuantise
    ? Formatting.formatEng(props.drawQuantize[0] * config.pixelSize)
    : null;

  const currentQuantization = isCustomQuantise
    ? 'custom'
    : props.drawQuantize
    ? props.drawQuantize[0]
    : undefined;

  const orig = find(props.sources, { origin: true });

  return (
    <Navbar bg="cyan" className="p-2">
      <Form className="text-nowrap">
        <InputGroup className="d-inline">
          <Tooltip tooltip="Enable draw quantisation">
            <Form.Control
              className="d-inline"
              style={{ width: 'auto' }}
              as="select"
              size="sm"
              value={currentQuantization}
              onChange={changeDrawQuantize}
            >
              {map(drawQuantizations, (name, value) => (
                <option value={value}>{name}</option>
              ))}
              {props.drawQuantize && isCustomQuantise && customQuantizeW && (
                <option value="custom">
                  {isSquareQuantize
                    ? Formatting.round(customQuantizeW.scalar, 12)
                    : `${customQuantizeW.scalar}x${Formatting.round(
                        props.drawQuantize[1] *
                          customQuantizeW.multiplier *
                          config.pixelSize,
                        12
                      )}`}
                  {customQuantizeW?.prefix}m
                </option>
              )}
            </Form.Control>
          </Tooltip>
          <SetQuantizeModal
            setQuantization={props.actions.changeDrawQuantize}
          />
        </InputGroup>

        <Tooltip tooltip="Snap to nearest object">
          <ToggleButtonGroup
            type="checkbox"
            value={props.drawSnap ? ['1'] : undefined}
            onChange={toggleDrawSnap}
          >
            <ToggleButton value="1" size="sm" className=" me-2" id="snap">
              <i className="fa fa-object-ungroup me-1" />
              Snap
            </ToggleButton>
          </ToggleButtonGroup>
        </Tooltip>
      </Form>

      <Form>
        <ButtonToolbar>
          <ToggleButtonGroup
            type="radio"
            name="action"
            value={currentAction}
            onChange={doSetAction}
            className="me-1"
          >
            <ToggleButton value="" size="sm" id="off">
              <i className="fa fa-power-off me-1" />
              Off
            </ToggleButton>
            <ToggleButton
              value="mosaic"
              id="mosaic"
              size="sm"
              disabled={!operator || runningScan || !currentSampleId}
            >
              <i className="fa fa-th me-1" />
              Mosaic
            </ToggleButton>
            {props.config.options.import_reference && (
              <ToggleButton
                value="reference"
                id="reference"
                size="sm"
                disabled={
                  !operator || runningScan || !props.selectedSampleActionId
                }
              >
                <i className="fa fa-map-marker me-1" />
                Ref
              </ToggleButton>
            )}
            <ToggleButton
              value="poi"
              size="sm"
              id="poi"
              disabled={!currentSampleId}
            >
              <i className="fa fa-map-pin me-1" />
              POI
            </ToggleButton>
            <ToggleButton
              value="roi"
              id="roi"
              size="sm"
              disabled={!currentSampleId}
            >
              <i className="fa fa-square-o me-1" />
              ROI
              <Tooltip tooltip="Draw multiple ROIs">
                <Form.Check
                  className="d-inline ms-1"
                  type="checkbox"
                  checked={props.multiROI}
                  value="1"
                  onChange={toggleMultiROI}
                />
              </Tooltip>
            </ToggleButton>
            <ToggleButton
              value="loi"
              id="loi"
              size="sm"
              disabled={!currentSampleId}
            >
              <i className="fa fa-long-arrow-right me-1" />
              LOI
              <Tooltip tooltip="Clamp LOIs">
                <Form.Check
                  className="d-inline ms-1"
                  type="checkbox"
                  checked={props.clampLOI}
                  value="1"
                  onChange={toggleClampLOI}
                />
              </Tooltip>
            </ToggleButton>
            <ToggleButton value="measure" id="measure" size="sm">
              <i className="fa fa-expand me-1" />
              Measure
            </ToggleButton>
            <ToggleButton value="pan" id="pan" size="sm">
              <i className="fa fa-arrows me-1" />
              Pan
            </ToggleButton>
            <ToggleButton
              value="move"
              id="move"
              size="sm"
              disabled={!operator || runningScan}
            >
              <i className="fa fa-map-marker me-1" />
              Move
              {(props.originSettings.fine_fixed ||
                props.originSettings.coarse_fixed) &&
                props.originSettings.config.allow_fixed_axes && (
                  <Tooltip tooltip="One axis is currently fixed">
                    <div className="bg-warning px-1 ml-1 rounded text-dark">
                      <i className="fa fa-warning" />
                    </div>
                  </Tooltip>
                )}
            </ToggleButton>
          </ToggleButtonGroup>

          {props.originSettings.has_fine &&
            props.originSettings.config.allow_fixed_axes && (
              <DropdownButton size="sm" title="">
                <Container className="pl-2 pr-2">
                  <Form.Check
                    type="switch"
                    id="fine-switch"
                    label="Fix Fine Axes"
                    checked={props.originSettings.fine_fixed}
                    onChange={() => toggleOriginSetting('fine_fixed')}
                  />
                  <Form.Check
                    type="switch"
                    id="coarse-switch"
                    label="Fix Coarse Axes"
                    className="text-nowrap"
                    checked={props.originSettings.coarse_fixed}
                    onChange={() => toggleOriginSetting('coarse_fixed')}
                  />
                </Container>
              </DropdownButton>
            )}

          {props.config.options.centre_selection && (
            <Tooltip tooltip="Centre object on selection">
              <ToggleButtonGroup
                className="me-1"
                type="checkbox"
                value={props.centreOnClick ? ['1'] : undefined}
                onChange={toggleCentreOnClick}
              >
                <ToggleButton id="center-selection" value="1" size="sm">
                  <i className="fa fa-align-center me-1" />
                  Centre
                </ToggleButton>
              </ToggleButtonGroup>
            </Tooltip>
          )}

          <Tooltip tooltip="Toggle showing cursor values and click to show">
            <ToggleButtonGroup
              type="checkbox"
              value={props.cursor ? ['1'] : undefined}
              onChange={toggleCursor}
              className="ms-1 me-1"
            >
              <ToggleButton
                value="1"
                id="cursor"
                size="sm"
                className="text-center"
              >
                <i className="fa fa-crosshairs me-1" />
                Cursor
              </ToggleButton>
            </ToggleButtonGroup>
          </Tooltip>

          <DropdownButton
            size="sm"
            title={
              <>
                <i className="fa fa-video-camera me-1" /> Video
              </>
            }
            className="me-1"
          >
            <Container className="pl-2 pr-2">
              <div className="d-grid gap-2 mb-1">
                {orig && Object.keys(orig.polylines).length > 0 && (
                  <div className="d-grid gap-2 mb-1 border bg-primary rounded p-1 text-light">
                    <Tooltip
                      tooltip={`${
                        clampOrigin ? 'Un-clamp' : 'Clamp'
                      } the viewport to the video source (unclamp to pan)`}
                    >
                      <ToggleButtonGroup
                        type="checkbox"
                        value={clampOrigin ? ['1'] : undefined}
                        onChange={toggleClampOrigin}
                      >
                        <ToggleButton
                          value="1"
                          size="sm"
                          className="text-start"
                          id="clamp-viewport"
                        >
                          <i
                            className={`fa fa-fw me-1 ${
                              clampOrigin ? 'fa-lock' : 'fa-unlock'
                            }`}
                          />
                          {clampOrigin ? 'Un-clamp' : 'Clamp'}
                        </ToggleButton>
                      </ToggleButtonGroup>
                    </Tooltip>
                    {props.originSettings.has_fine && (
                      <div
                        className="bg-light text-primary rounded p-1"
                        style={{ fontSize: '0.7875rem' }}
                      >
                        <Form.Check
                          name="clampTarget"
                          checked={clampTarget === ''}
                          type="radio"
                          value=""
                          label="video"
                          onChange={doSetClampTarget}
                          className="mb-0"
                        />
                        {Object.keys(orig.polylines)
                          .filter((polyline_key) => polyline_key !== 'limits')
                          .map((polyline_key) => {
                            return (
                              <Form.Check
                                name="clampTarget"
                                type="radio"
                                checked={clampTarget === polyline_key}
                                value={polyline_key}
                                label={polyline_key}
                                onChange={doSetClampTarget}
                                className="mb-0"
                              />
                            );
                          })}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {orig?.additional_urls?.length > 0 && (
                <div className="d-grid gap-2 mb-1 border bg-primary rounded p-1 text-light">
                  <div className="mx-1" style={{ fontSize: '0.7875rem' }}>
                    <i className="fa fa-fw me-1 fa-film" />
                    Stream
                  </div>
                  <div
                    className="bg-light text-primary rounded p-1"
                    style={{ fontSize: '0.7875rem' }}
                  >
                    <Form.Check
                      name="sourceUrl"
                      checked={sourceUrl === ''}
                      type="radio"
                      value=""
                      label="default"
                      onChange={selectSourceUrl}
                      className="mb-0"
                    />
                    {orig?.additional_urls.map(
                      (additional_url: AdditionalUrl) => {
                        return (
                          <>
                            <hr style={{ margin: '0.1rem' }} />
                            <Form.Check
                              name="sourceUrl"
                              type="radio"
                              checked={sourceUrl === additional_url.name}
                              value={additional_url.name}
                              label={additional_url.name}
                              onChange={selectSourceUrl}
                              className="mb-0"
                            />
                          </>
                        );
                      }
                    )}
                  </div>
                </div>
              )}

              {props.config.options.autofocus && (
                <div className="d-grid gap-2 mb-1">
                  <Tooltip tooltip="Autofocus the video source">
                    <Button
                      size="sm"
                      onClick={autoFocusImage}
                      disabled={!operator || runningScan}
                      className="text-start"
                    >
                      <i className="fa fa-fw fa-eye me-1" /> Autofocus
                    </Button>
                  </Tooltip>
                </div>
              )}

              <div className="d-grid gap-2 mb-1">
                <Tooltip
                  tooltip={`${
                    disableOrigin ? 'Enable' : 'Disable'
                  } the video source`}
                >
                  <ToggleButtonGroup
                    type="checkbox"
                    value={disableOrigin ? ['1'] : undefined}
                    onChange={toggleDisableOrigin}
                  >
                    <ToggleButton
                      value="1"
                      size="sm"
                      className="text-start"
                      id="disable-video"
                    >
                      <i className="fa fa-fw fa-power-off me-1" />
                      {disableOrigin ? 'Enable' : 'Disable'}
                    </ToggleButton>
                  </ToggleButtonGroup>
                </Tooltip>
              </div>
            </Container>
          </DropdownButton>

          <DropdownButton
            size="sm"
            title={
              <>
                <i className="fa fa-picture-o me-1" /> Images
              </>
            }
          >
            <Container className="pl-2 pr-2">
              <div className="d-grid gap-2 mb-1">
                <Tooltip tooltip="Save the current sample image">
                  <Button
                    size="sm"
                    onClick={saveImage}
                    disabled={!currentSampleId || props.pendingSaveImage}
                    className="text-start"
                  >
                    <i className="me-1 fa fa-camera" />
                    {props.pendingSaveImage && (
                      <>
                        Saving <i className="fa fa-spin fa-spinner" />
                      </>
                    )}
                    {!props.pendingSaveImage && <>Save</>}
                  </Button>
                </Tooltip>
              </div>

              <div className="d-grid gap-2 mb-1">
                <Tooltip tooltip="Save the current canvas">
                  <Button
                    size="sm"
                    onClick={saveCanvas}
                    disabled={!currentSampleId || props.pendingSaveCanvas}
                    className="text-start"
                  >
                    <i className="me-1 fa fa-picture-o" />
                    {props.pendingSaveCanvas && (
                      <>
                        Saving <i className="fa fa-spin fa-spinner" />
                      </>
                    )}
                    {!props.pendingSaveCanvas && <>Canvas</>}
                  </Button>
                </Tooltip>
              </div>

              <ImageSelection />
            </Container>
          </DropdownButton>
        </ButtonToolbar>
      </Form>
    </Navbar>
  );
}
