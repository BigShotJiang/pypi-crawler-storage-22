import { Button } from 'react-bootstrap';
import { MapResource, type MapEntity } from '../../resources/Map';
import { useController } from '@data-client/react';

interface IProps {
  maps: MapEntity[];
}

export default function HideAllMaps(props: IProps) {
  const { fetch } = useController();
  function hideMaps() {
    props.maps.forEach((map) => {
      if (map.mapid && map.opacity && map.opacity > 0) {
        fetch(MapResource.partialUpdate, { mapid: map.mapid }, { opacity: 0 });
      }
    });
  }

  return (
    <Button
      disabled={
        props.maps.length === 0 ||
        props.maps
          .map((map) => map.opacity || 0)
          .reduce((sum, x) => sum + x) === 0
      }
      className="float-end me-1"
      onClick={hideMaps}
      title="Hide All Maps"
    >
      <i className="fa fa-eye-slash" />
    </Button>
  );
}
