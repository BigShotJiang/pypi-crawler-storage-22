import { useRef, useEffect } from 'react';
import { map } from 'lodash';

import { Container, Row, Col, Alert } from 'react-bootstrap';

import ButtonTriggerModalStore from 'connect/layout/ButtonTriggerModalStore';
import ScanPlot1d from 'components/scans/ScanPlot1d';
import { useDLE } from '@data-client/react';
import { MapROIResource } from '../../resources/MapROI';
import type { ButtonTriggerModalStoreRef } from '../layout/models';
import type { SpectraContainer } from '../scans/models';
import useSampleOptions from '../samples/options';

interface Props {
  pointer: {
    scanid?: number;
    point?: number;
  };
  spectra: SpectraContainer;
  actions: {
    setMapPointer: () => void;
    fetchScanSpectra: (payload: any) => Promise<any>;
  };
  spectraError: string;
  spectraFetched: boolean;
  spectraFetching: boolean;
}

export default function MCAModal(props: Props) {
  const {
    pointer = {},
    actions,
    spectra,
    spectraFetching,
    spectraFetched,
    spectraError,
  } = props;
  const modalRef = useRef<ButtonTriggerModalStoreRef>();
  const { currentSampleId } = useSampleOptions();
  const { data: rois, loading } = useDLE(MapROIResource.getList, {
    sampleid: currentSampleId,
  });

  useEffect(() => {
    if (pointer.point !== undefined) {
      getSpectra();
      modalRef.current?.showModal();
    } else {
      actions.setMapPointer();
    }
  }, [pointer]);

  function getSpectra() {
    actions
      .fetchScanSpectra({
        scanid: pointer.scanid,
        point: pointer.point,
      })
      .catch(() => {
        console.log('Couldnt load spectra');
      });
  }

  const shapes = map(rois.rows, (r) => ({
    type: 'rect',
    xref: 'x',
    yref: 'paper',
    y0: 0,
    y1: 1,
    x0: r.start,
    x1: r.end,
    fillcolor: '#ccc',
    opacity: 0.5,
    line: {
      width: 0,
    },
  }));

  let i = 0;
  const annotations = map(rois.rows, (r) => ({
    xref: 'x',
    yref: 'paper',
    y: 0.8 - i++ * 0.06,
    x: r.start,
    text: `${r.element}-${r.edge}`,
    showarrow: false,
  }));

  return (
    <ButtonTriggerModalStore
      id="mca"
      ref={modalRef}
      showButton={false}
      title="MCA"
    >
      {spectraFetching && (
        <Alert variant="info">
          <i className="fa fa-spin fa-spinner me-1" />
          Fetching point {pointer.point} from scan {pointer.scanid}
        </Alert>
      )}

      {spectraError && (
        <Alert variant="warning">
          Scan number {pointer.scanid} is no longer available
        </Alert>
      )}

      {!spectraError && spectraFetched && !spectraFetching && (
        <Container>
          <Row>
            Point {pointer.point ?? 0 + 1}/{spectra.npoints}
          </Row>
          <Row style={{ height: '40vh' }}>
            <Col>
              <ScanPlot1d
                fetching={spectraFetching}
                options={{}}
                selectable={false}
                spectra={spectra}
                scans={[]}
                data={{}}
                layout={{
                  shapes,
                  annotations,
                  xaxis: {
                    title: 'Energy (eV)',
                  },
                  yaxis: {
                    title: 'Counts',
                  },
                }}
              />
            </Col>
          </Row>
        </Container>
      )}
    </ButtonTriggerModalStore>
  );
}
