import { Suspense, useEffect, useState } from 'react';
import { values, each, keys, keyBy } from 'lodash';
import {
  FullSizer,
  Formatting,
  useOperator,
  useScanRunning,
} from '@esrf/daiquiri-lib';

import RemountOnResize from 'components/utils/RemountOnResize';

import config from 'config/config';
import SelectableTable from 'components/table/Selectable';
import DeleteButton from 'components/common/DeleteButton';
import InlineEditable from 'components/common/InlineEditable';
import Tooltip from 'components/common/Tooltip';
import Confirm from 'helpers/Confirm';

import { Button, Badge, OverlayTrigger, Popover } from 'react-bootstrap';
import ImportReferenceButton from './ImportReferenceButton';
import ExtraMetadataButton from './ExtraMetadataButton';
import ExtraMetadata from 'connect/2dview/ExtraMetadata';
import type { IExtraMetadataData } from './ExtraMetadata';
import { useController, useDLE } from '@data-client/react';
import type { SubSampleEntity } from '../../resources/SubSample';
import { SubSampleResource } from '../../resources/SubSample';
import type { SubSample } from '../../resources/models/SubSample';
import useSampleOptions, {
  useCurrentSample,
  useSubSampleOptions,
} from '../samples/options';

interface IViewButton {
  id: number;
  subsample: SubSample;
  subSampleSchema: {
    definitions: {
      SubSampleSchema: Record<string, any>;
    };
  };
  updateObject: (payload: any) => Promise<any>;
  hasData: boolean;
}

function ViewButton(props: IViewButton) {
  function onChange({ field, value }: { field: string; value: any }) {
    const data: Record<string, any> = {};
    if (props.subsample.type === 'roi') {
      const w = (props.subsample.x2 ?? 0) - (props.subsample.x ?? 0);
      const engw = Formatting.formatEng(w * config.pixelSize);
      if (field === 'w') {
        data.x2 = Math.round(
          (props.subsample.x ?? 0) + value / engw.multiplier / config.pixelSize
        );
      }

      if (field === 'h') {
        data.y2 = Math.round(
          (props.subsample.y ?? 0) + value / engw.multiplier / config.pixelSize
        );
      }
    }

    each(props.subsample.positions, (v, k) => {
      if (k === field) {
        data.positions = { [k]: value };
      }
    });

    if (keys(data).length === 0) data[field] = value;

    return props.updateObject({
      subsampleid: props.subsample.subsampleid,
      ...data,
    });
  }

  const title = `${(props.subsample.type ?? '').toUpperCase()} ${
    props.subsample.subsampleid
  }`;

  const extraFormData: Record<string, any> = {};
  const extraFields: Record<string, any> = {};

  const editable = ['comments'];

  if (props.subsample.type === 'roi') {
    const w = (props.subsample.x2 ?? 0) - (props.subsample.x ?? 0);
    const h = (props.subsample.y2 ?? 0) - (props.subsample.y ?? 0);
    const engw = Formatting.formatEng(w * config.pixelSize);
    const engh = engw.multiplier * h * config.pixelSize;

    extraFields.w = {
      title: 'Width',
      type: 'number',
      unit: `${engw.prefix}m`,
    };
    extraFields.h = {
      title: 'Height',
      type: 'number',
      unit: `${engw.prefix}m`,
    };

    extraFormData.w = Formatting.round(engw.scalar, 12);
    extraFormData.h = Formatting.round(engh, 12);

    if (!props.hasData) {
      editable.push('w', 'h');
    }
  }

  each(props.subsample.positions, (v, k) => {
    extraFields[k] = { title: k, type: 'number' };
    extraFormData[k] = v;
    if (!props.hasData) editable.push(k);
  });

  const { properties } = props.subSampleSchema.definitions.SubSampleSchema;
  const schema = {
    comments: properties.comments,
    ...extraFields,
  };

  return (
    <>
      <OverlayTrigger
        trigger="click"
        placement="left"
        rootClose
        overlay={
          <Popover className="inline-editable">
            <Popover.Header>{title}</Popover.Header>
            <Popover.Body>
              <InlineEditable
                colWidth={4}
                editable={editable}
                schema={schema}
                formData={{
                  ...props.subsample,
                  ...extraFormData,
                }}
                onChange={onChange}
              />
              <ExtraMetadata
                subSamples
                onChange={onChange}
                extraMetadata={props.subsample.extrametadata}
              />
            </Popover.Body>
          </Popover>
        }
      >
        <Button variant="info" size="sm" className="view">
          <i className="fa fa-search" />
        </Button>
      </OverlayTrigger>
    </>
  );
}

interface IMoveButton {
  moveToSubSample: (payload: any) => Promise<any>;
  addToast: (payload: any) => void;
  id: number;
  disabled: boolean;
}

function MoveButton(props: IMoveButton) {
  function onClick() {
    props.moveToSubSample(props.id).catch((error) => {
      props.addToast({
        type: 'error',
        title: 'Could not move to subsample',
        text: error.response?.data?.error || error.message,
      });
    });
  }

  return (
    <Button
      className="me-1 move"
      size="sm"
      variant="secondary"
      title="Move to"
      onClick={onClick}
      disabled={props.disabled}
    >
      <i className="fa fa-map-pin" />
    </Button>
  );
}

interface IExportButton {
  selectedObjects: number[];
  pendingExportSubsamples: boolean;
  exportSubSamples: (payload: any) => Promise<any>;
  addToast: (payload: any) => void;
}

function ExportButton(props: IExportButton) {
  function onClick() {
    props
      .exportSubSamples({ subsampleids: props.selectedObjects })
      .then((resp) => {
        props.addToast({
          type: 'success',
          title: 'Exported sub samples',
          text: resp.data.message,
        });
      });
  }

  return (
    <Tooltip tooltip="Export selected sub samples">
      <Button
        onClick={onClick}
        className="float-end me-1"
        size="sm"
        disabled={
          (props.selectedObjects && props.selectedObjects.length === 0) ||
          !props.selectedObjects ||
          props.pendingExportSubsamples
        }
      >
        <i
          className={`fa fa-${
            props.pendingExportSubsamples ? 'spinner fa-spin' : 'save'
          }`}
        />
      </Button>
    </Tooltip>
  );
}

function MoveCell(
  cell: string,
  row: SubSample,
  rowIndex: number,
  formatExtraData: any
) {
  return (
    <MoveButton
      id={row.subsampleid ?? 0}
      moveToSubSample={formatExtraData.moveToSubSample}
      addToast={formatExtraData.addToast}
      disabled={!formatExtraData.operator || formatExtraData.runningScan}
    />
  );
}

function ActionCell(
  cell: string,
  row: SubSample,
  rowIndex: number,
  formatExtraData: any
) {
  return (
    <>
      <ViewButton
        id={row.subsampleid ?? 0}
        subsample={row}
        updateObject={formatExtraData.updateObject}
        hasData={row.datacollections !== 0}
        subSampleSchema={formatExtraData.subSampleSchema}
      />
      <DeleteButton
        id={row.subsampleid ?? 0}
        show={row.datacollections === 0}
        onClick={formatExtraData.removeObject}
        confirm
      />
    </>
  );
}

function TypeCell(cell: string, row: SubSample) {
  const types = {
    poi: ['POI', 'info'],
    roi: ['ROI', 'primary'],
    loi: ['LOI', 'secondary'],
  };
  const type = row.type ?? 'poi';

  return <Badge bg={types[type][1]}>{types[type][0]}</Badge>;
}

function DataCell(cell: string, row: SubSample) {
  const badges = [];

  if ((row.datacollections ?? 0) > 0) {
    badges.push(
      <Badge bg="success" className="me-1" key="b1">
        Data <Badge bg="light">{row.datacollections}</Badge>
      </Badge>
    );
  }

  if (row.queued) {
    badges.push(
      <Badge bg="warning" key="b2">
        Queued
      </Badge>
    );
  }

  return badges;
}

function SizeCell(cell: string, row: any) {
  if (row.type === 'roi') {
    const engw = Formatting.formatEng((row.x2 - row.x) * config.pixelSize);
    const engh = engw.multiplier * (row.y2 - row.y) * config.pixelSize;

    return `${Formatting.round(engw.scalar, 12)}x${Formatting.round(
      engh,
      12
    )} ${engw.prefix}m`;
  }

  if (row.type === 'loi') {
    const len = Math.sqrt((row.x2 - row.x) ** 2 + (row.y2 - row.y) ** 2);
    const eng = Formatting.formatEng(len * config.pixelSize);
    return `${Formatting.round(eng.scalar, 3)} ${eng.prefix}m`;
  }

  return '';
}

export function TagCell(cell: IExtraMetadataData) {
  return (
    <>
      {cell?.tags?.map((tag) => (
        <Badge className="me-1">{tag}</Badge>
      ))}
    </>
  );
}

function SampleName() {
  const sample = useCurrentSample();
  return sample?.name || 'No sample selected';
}

interface IObjectList {
  actions: {
    moveToSubSample: (subsampleid: any) => Promise<any>;
    exportSubSamples: (payload: any) => Promise<any>;
    addToast: (payload: any) => void;
  };
  pendingExportSubsamples: boolean;
  config: Record<string, any>;
  subSampleSchema: Record<string, any>;
}

export default function ObjectList(props: IObjectList) {
  const [deletingObjects, setDeletingObjects] = useState<boolean>(false);
  const { config = {} } = props;
  const { options = {} } = config;
  const { currentSampleId } = useSampleOptions();
  const {
    currentSubSampleId,
    subSampleSelection,
    addSubSampleSelection,
    removeSubSampleSelection,
    resetSubSampleSelection,
  } = useSubSampleOptions();

  const { fetch } = useController();
  const objectsDLE = useDLE(
    SubSampleResource.getList,
    currentSampleId ? { sampleid: currentSampleId } : null
  );
  const objects = keyBy(
    objectsDLE.data.rows ?? [],
    (o) => o.subsampleid
  ) as Record<string, SubSampleEntity>;

  useEffect(() => {
    if (
      objectsDLE.data?.rows &&
      objectsDLE.data.rows.length > 0 &&
      currentSubSampleId
    ) {
      const currentSubSample = objects[currentSubSampleId];
      if (!currentSubSample) {
        resetSubSampleSelection();
      }

      if (currentSubSample && currentSubSample.sampleid !== currentSampleId) {
        resetSubSampleSelection();
      }
    }
  }, [currentSampleId, objects]);

  const operator = useOperator();
  const runningScan = useScanRunning();

  function deleteMultiple() {
    setDeletingObjects(true);
    const promises: Promise<any>[] = [];
    each(subSampleSelection, (subsampleid) => {
      promises.push(fetch(SubSampleResource.delete, { subsampleid }));
    });

    Promise.all(promises).then(() => {
      setDeletingObjects(false);
      resetSubSampleSelection();
    });
  }

  function updateObject(payload: Record<string, any>) {
    const { subsampleid, ...rest } = payload;
    return fetch(SubSampleResource.partialUpdate, { subsampleid }, rest);
  }

  function removeObject(subsampleid: number) {
    if (subsampleid === currentSubSampleId) resetSubSampleSelection();
    return fetch(SubSampleResource.delete, { subsampleid });
  }

  const columns = [
    { dataField: 'subsampleid', text: '#' },
    { dataField: 'type', text: 'Type', formatter: TypeCell },
    { dataField: 'size', text: 'Size', formatter: SizeCell },
    { dataField: 'extrametadata', text: 'Tags', formatter: TagCell },
    { dataField: 'datacollections', text: '', formatter: DataCell },
    {
      dataField: 'move',
      text: '',
      formatter: MoveCell,
      classes: 'text-end',
      formatExtraData: {
        moveToSubSample: props.actions.moveToSubSample,
        addToast: props.actions.addToast,
        operator,
        runningScan,
      },
    },
    {
      dataField: 'action',
      text: '',
      formatter: ActionCell,
      classes: 'text-end text-nowrap',
      formatExtraData: {
        removeObject,
        updateObject,
        subSampleSchema: props.subSampleSchema,
      },
    },
  ];

  const caption = (
    <>
      <SampleName />
      <Confirm
        title="Confirm"
        message="Are you sure you want to delete these items?"
      >
        {(confirm) => (
          <Button
            onClick={confirm(deleteMultiple)}
            className="float-end"
            size="sm"
            variant="danger"
            disabled={
              (subSampleSelection && subSampleSelection.length < 2) ||
              !subSampleSelection ||
              deletingObjects
            }
          >
            <i
              className={`fa ${
                deletingObjects ? 'fa-spin fa-spinner' : 'fa-times'
              }`}
            />
          </Button>
        )}
      </Confirm>
      {options.export && (
        <ExportButton
          selectedObjects={subSampleSelection}
          pendingExportSubsamples={props.pendingExportSubsamples}
          exportSubSamples={props.actions.exportSubSamples}
          addToast={props.actions.addToast}
        />
      )}
      {options.import_reference && (
        <ImportReferenceButton sampleid={currentSampleId} />
      )}
      <ExtraMetadataButton
        objects={objects || []}
        selectedObjects={subSampleSelection}
        updateObject={updateObject}
      />
    </>
  );

  return (
    <RemountOnResize>
      <FullSizer>
        <SelectableTable
          caption={caption}
          classes="table-subsamples table-sticky-caption"
          keyField="subsampleid"
          data={values(objects)}
          loading={objectsDLE.loading}
          overlay
          columns={columns}
          noDataIndication="No objects defined"
          selectedItems={subSampleSelection}
          typeKey="type"
          multiple
          actions={{
            addSelection: addSubSampleSelection,
            removeSelection: removeSubSampleSelection,
            resetSelection: resetSubSampleSelection,
          }}
        />
      </FullSizer>
    </RemountOnResize>
  );
}
