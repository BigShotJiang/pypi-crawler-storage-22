import { Suspense, useEffect } from 'react';
import { filter, keys } from 'lodash';
import { Form } from 'react-bootstrap';
import { FullSizer } from '@esrf/daiquiri-lib';

import RemountOnResize from 'components/utils/RemountOnResize';
import DCList from 'components/dc/DCList';
import MapList from 'components/samples/MapList';
import CompositeList from 'components/2dview/CompositeList';
import CompositeButton from 'components/2dview/CompositeButton';
import NewScanButton from 'components/samples/NewScanButton';
import RoiManagerButton from 'components/2dview/ROIManagerButton';
import HideAllMapsButton from 'components/2dview/HideAllMapsButton';
import SavingButton from 'connect/2dview/SavingButton';
import RegenerateMapsButton from 'connect/2dview/RegenerateMapsButton';

import AutoScalarMaps from './AutoScalarMaps';
import { useLastNotification } from 'components/utils/hooks';
import { useController, useSuspense } from '@data-client/react';
import { SubSampleResource } from '../../resources/SubSample';
import { MapResource } from '../../resources/Map';
import useSampleOptions, {
  useCurrentSubSample,
  useSubSampleOptions,
} from '../samples/options';

interface IObjectView {
  config: { scantypes: Record<string, any>; options: Record<string, any> };
  mapSelection: Record<string, any>;
  mapSettings: {
    during_scan: boolean;
  };
  operator: boolean;
  actions: {
    selectMap: ({ mapid, index }: { mapid: number; index: number }) => void;
    unselectMap: (mapid: number) => void;
    resetMapSelection: () => void;
    fetchMapSettings: () => Promise<any>;
    updateMapSettings: (settings: Record<string, any>) => Promise<any>;
  };
}

function ObjectView(props: IObjectView) {
  const { invalidateAll } = useController();
  const { currentSubSampleId, subSampleSelection } = useSubSampleOptions();
  const { currentSampleId } = useSampleOptions();

  useEffect(() => {
    props.actions.fetchMapSettings();
  }, []);

  const subsamples = useSuspense(
    SubSampleResource.getList,
    currentSampleId
      ? {
          sampleid: currentSampleId,
        }
      : null
  );
  const subsampleParam = currentSubSampleId
    ? { subsampleid: currentSubSampleId }
    : null;
  const object = useCurrentSubSample();
  const maps = useSuspense(MapResource.getList, subsampleParam);

  useEffect(() => {
    props.actions.resetMapSelection();
  }, [object]);

  const event = useLastNotification(['xrf_map']);

  useEffect(() => {
    console.log('new event', event);
    if (event) invalidateAll(MapResource.getList);
  }, [event]);

  if (!object) return <div>No object selected</div>;

  const sel = keys(props.mapSelection);

  const objects = filter(subsamples.rows, (obj) =>
    subSampleSelection.includes(obj.subsampleid ?? 0)
  );

  return (
    <RemountOnResize>
      <FullSizer>
        <div className="object" data-testid="objectview">
          <h2>
            Data Collections
            <NewScanButton
              prefix="object"
              objects={objects}
              config={props.config}
              disabled={!props.operator}
              allowWhileScanRunning
            />
            <SavingButton />
          </h2>
          <DCList
            subsampleid={currentSubSampleId}
            scan={false}
            createScalarMap
            showFollow={false}
            pages={0}
            fetching={false}
            page={0}
            per_page={0}
            total={0}
          />
          {object.type === 'roi' && (
            <>
              <h2>
                Maps
                {!props.config.options.disable_mca_roi && <RoiManagerButton />}
                <RegenerateMapsButton
                  subsampleid={object.subsampleid ?? 0}
                  buttonProps={{ className: 'float-end me-1' }}
                />
                <CompositeButton
                  maps={maps.rows || []}
                  selection={props.mapSelection}
                  subsampleid={object.subsampleid ?? 0}
                  disabled={sel.length !== 3}
                />
                <HideAllMapsButton maps={maps.rows || []} />
                <AutoScalarMaps
                  mapSettings={props.mapSettings}
                  updateMapSettings={props.actions.updateMapSettings}
                />
                <span className="inline-toggle float-end me-1">
                  <Form.Switch
                    variant="secondary"
                    label="Update"
                    id="during-scan"
                    onClick={() =>
                      void props.actions.updateMapSettings({
                        during_scan: !props.mapSettings.during_scan,
                      })
                    }
                    defaultChecked={props.mapSettings.during_scan}
                  />
                </span>
              </h2>
              <MapList
                subsampleid={currentSubSampleId}
                actions={{
                  selectMap: props.actions.selectMap,
                  unselectMap: props.actions.unselectMap,
                }}
              />
              <CompositeList subsampleid={currentSubSampleId ?? 0} />
            </>
          )}
        </div>
      </FullSizer>
    </RemountOnResize>
  );
}

export default function ObjectViewWrap(props: IObjectView) {
  return (
    <Suspense fallback="Loading..">
      <ObjectView {...props} />
    </Suspense>
  );
}
