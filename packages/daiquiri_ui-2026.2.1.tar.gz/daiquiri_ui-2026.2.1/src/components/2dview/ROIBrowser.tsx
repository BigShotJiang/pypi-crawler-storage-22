import { useState, useRef, useEffect } from 'react';
import { map, each } from 'lodash';
import { Form, Col, Row } from 'react-bootstrap';
import { useDLE } from '@data-client/react';

import Table from 'components/table';
import { MapROIResource } from '../../resources/MapROI';
import { SampleResource } from '../../resources/Sample';
import type { XRFMapROI } from '../../resources/models/XRFMapROI';

interface IROIBrowser {
  onChange: (newROIs: XRFMapROI[]) => void;
}

export default function ROIBrowser(props: IROIBrowser) {
  const [selection, setSelection] = useState<Record<string, any>>({});
  const [sampleid, setSampleId] = useState<number>();
  const selectRef = useRef<HTMLSelectElement>(null);

  const { data: samples, loading: loadingSamples } = useDLE(
    SampleResource.getList
  );
  const { data: rois, loading: loadingROIs } = useDLE(
    MapROIResource.getList,
    sampleid ? { sampleid } : null
  );

  useEffect(() => {
    if (selectRef.current?.value) {
      setSampleId(Number.parseInt(selectRef.current?.value));
    }
  }, []);

  useEffect(() => {
    const newROIs: XRFMapROI[] = [];
    each(rois.rows, (r) => {
      const { maproiid, maps, ...roi } = r;
      if (maproiid && maproiid in selection && selection[maproiid]) {
        newROIs.push(roi);
      }
    });
    props.onChange(newROIs);
  }, [selection]);

  function onSelect(
    row: XRFMapROI,
    isSelect: boolean,
    rowIndex: number,
    e: any
  ) {
    if (row.maproiid) {
      setSelection({
        [row.maproiid]: isSelect,
        ...selection,
      });
    }
  }

  function onSelectAll(isSelect: boolean, rows: XRFMapROI[], e: any) {
    each(rows, (row, i) => {
      onSelect(row, isSelect, i, e);
    });
  }

  const columns = [
    { dataField: 'maproiid', text: 'Id' },
    { dataField: 'element', text: 'Element' },
    { dataField: 'edge', text: 'Edge' },
    { dataField: 'start', text: 'Start (eV)' },
    { dataField: 'end', text: 'End (eV)' },
  ];

  return (
    <>
      <Form.Group as={Row}>
        <Form.Label column sm={3}>
          Sample
          {loadingSamples && <i className="fa fa-loading" />}
        </Form.Label>
        <Col>
          <Form.Control
            className="me-1"
            ref={selectRef}
            as="select"
            size="sm"
            onChange={(e) => setSampleId(Number.parseInt(e.target.value))}
          >
            {map(samples.rows, (s) => (
              <option value={s.sampleid} key={s.sampleid}>
                {s.name}
              </option>
            ))}
          </Form.Control>
        </Col>
      </Form.Group>
      <Table
        keyField="maproiid"
        loading={loadingROIs}
        data={rois.rows || []}
        columns={columns}
        noDataIndication="No ROIs found"
        selectRow={{
          mode: 'checkbox',
          onSelect,
          onSelectAll,
        }}
      />
    </>
  );
}
