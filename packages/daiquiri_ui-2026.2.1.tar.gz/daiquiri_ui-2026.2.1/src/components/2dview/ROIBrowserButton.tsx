import { useRef, useState } from 'react';
import { each } from 'lodash';
import { Button } from 'react-bootstrap';

import ButtonTriggerModalStore from 'connect/layout/ButtonTriggerModalStore';
import type { ButtonTriggerModalStoreRef } from 'components/layout/models';
import ROIBrowser from 'connect/2dview/ROIBrowser';
import type { XRFMapROI } from '../../resources/models/XRFMapROI';

interface IROIBrowserButton {
  sampleid: number;
  operator: boolean;
  actions: {
    addMapROI: (payload: any) => Promise<any>;
  };
}

export default function ROIBrowserButton(props: IROIBrowserButton) {
  const { sampleid, operator, actions } = props;
  const modalRef = useRef<ButtonTriggerModalStoreRef>();
  const [rois, setROIs] = useState<XRFMapROI[]>([]);

  function onApply(e: any) {
    e.preventDefault();

    if (rois) {
      const ps: Promise<any>[] = [];
      each(rois, (roi) => {
        ps.push(
          actions.addMapROI({
            ...roi,
            sampleid,
          })
        );
      });
      Promise.all(ps).then(() => modalRef.current?.close());
    }
  }

  return (
    <ButtonTriggerModalStore
      id="roiBrowser"
      ref={modalRef}
      title="ROI Browser"
      buttonProps={{
        className: 'me-1',
        disabled: !operator,
      }}
      button={
        <>
          <i className="fa fa-search me-1" />
          History
        </>
      }
      buttons={<Button onClick={onApply}>Apply</Button>}
    >
      <ROIBrowser onChange={(newROIs: XRFMapROI[]) => setROIs(newROIs)} />
    </ButtonTriggerModalStore>
  );
}
