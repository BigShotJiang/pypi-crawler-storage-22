import { useState, useRef, useEffect } from 'react';
import { Button } from 'react-bootstrap';
import { useController, useDLE } from '@data-client/react';

import Table from 'components/table';
import DeleteButton from 'components/common/DeleteButton';
import ButtonTriggerModalStore from 'connect/layout/ButtonTriggerModalStore';
import type { ButtonTriggerModalStoreRef } from '../layout/models';
import PeriodicTable from 'components/common/PeriodicTable';
import LinesModal from 'components/common/LinesModal';

import SchemaForm from 'connect/SchemaForm';
import ROIBrowserButton from 'components/2dview/ROIBrowserButton';
import useSampleOptions from '../samples/options';

import { MapROIResource } from '../../resources/MapROI';
import type { XRFMapROI } from '../../resources/models/XRFMapROI';

interface IUpdateROIButton {
  roi: XRFMapROI;
  updateRoi: (payload: XRFMapROI) => Promise<any>;
  disabled: boolean;
}

function UpdateROIButton(props: IUpdateROIButton) {
  const { roi, updateRoi, disabled } = props;
  const modalRef = useRef<ButtonTriggerModalStoreRef>();
  const onSubmitRef = useRef(() => {});
  const disabledRef = useRef(false);
  const [render, forceRender] = useState<boolean>(true);

  function onSubmit(formData: XRFMapROI) {
    return updateRoi(formData).then(() => modalRef.current?.close());
  }
  return (
    <ButtonTriggerModalStore
      id={`updateMCAROI${roi.maproiid}`}
      ref={modalRef}
      title="Update MCA ROI"
      buttons={
        <Button
          onClick={() => onSubmitRef.current?.()}
          disabled={disabledRef.current}
        >
          Update ROI
        </Button>
      }
      button={<i className="fa fa-pencil" />}
      buttonProps={{ size: 'sm', disabled }}
    >
      <SchemaForm
        schema="XRFMapROISchema"
        onSubmit={onSubmit}
        formData={roi}
        requireOperator
        button={(d: boolean, os: () => void) => {
          disabledRef.current = d;
          onSubmitRef.current = os;
          forceRender(!render);
        }}
      />
    </ButtonTriggerModalStore>
  );
}

function ActionCell(
  cell: string,
  row: XRFMapROI,
  rowIndex: number,
  formatExtraData: Record<string, any>
) {
  return (
    <>
      <UpdateROIButton
        roi={row}
        updateRoi={formatExtraData.updateRoi}
        disabled={!formatExtraData.operator}
      />
      <DeleteButton
        id={row.maproiid ?? 0}
        onClick={formatExtraData.deleteRoi}
        confirm
        show={row.maps === 0}
        disabled={!formatExtraData.operator}
      />
    </>
  );
}

interface IROIManager {
  config: {
    mca: {
      sigma: number;
    };
  };
  operator: boolean;
  actions: {
    toggleModal: (id: string) => void;
  };
  modal: Record<string, any>;
}

export default function ROIManager(props: IROIManager) {
  const { actions, operator, config, modal } = props;
  const { currentSampleId = 0 } = useSampleOptions();
  const onSubmitRef = useRef(() => {});
  const disabledRef = useRef(false);
  const [render, forceRender] = useState<boolean>(true);
  const [currentElement, setCurrentElement] = useState<Record<string, any>>();
  const modalRef = useRef<ButtonTriggerModalStoreRef>();
  const linesModal = useRef<LinesModal>(null);
  const { fetch, invalidateAll } = useController();
  const { data: rois, loading } = useDLE(MapROIResource.getList, {
    sampleid: currentSampleId,
  });

  function selectElement(id: number, element: Record<string, any>) {
    setCurrentElement(element);
    linesModal.current?.show();
  }

  function addMapROI(payload: XRFMapROI) {
    return fetch(MapROIResource.getList.push, payload).then(() => {
      invalidateAll(MapROIResource.getList);
    });
  }

  function updateMapROI(payload: XRFMapROI) {
    const { maproiid = 0, ...rest } = payload;
    return fetch(MapROIResource.partialUpdate, { maproiid }, rest);
  }

  function deleteMapROI(maproiid: number) {
    return fetch(MapROIResource.delete, { maproiid });
  }

  function onSubmit(formData: XRFMapROI) {
    return addMapROI(formData).then(() => modalRef.current?.close());
  }

  const columns = [
    { dataField: 'maproiid', text: 'Id' },
    { dataField: 'element', text: 'Element' },
    { dataField: 'edge', text: 'Edge' },
    { dataField: 'start', text: 'Start (eV)' },
    { dataField: 'end', text: 'End (eV)' },
    {
      dataField: 'action',
      text: '',
      classes: 'text-end',
      formatter: ActionCell,
      formatExtraData: {
        deleteRoi: deleteMapROI,
        updateRoi: updateMapROI,
        operator,
      },
    },
  ];

  return (
    <>
      <LinesModal
        ref={linesModal}
        actions={{
          toggleModal: actions.toggleModal,
          addMapROI,
        }}
        modal={modal}
        operator={operator}
        element={currentElement}
        sampleid={currentSampleId}
        sigmaMca={config?.mca.sigma}
      />
      <PeriodicTable noEdges actions={{ onClick: selectElement }} />
      <div className="text-end mt-2 mb-1">
        <ROIBrowserButton
          operator={operator}
          sampleid={currentSampleId}
          actions={{
            addMapROI,
          }}
        />
        <ButtonTriggerModalStore
          id="newMCAROI"
          ref={modalRef}
          title="Add MCA ROI"
          buttons={
            <Button
              onClick={() => onSubmitRef.current()}
              disabled={disabledRef.current}
            >
              Add ROI
            </Button>
          }
          button={
            <>
              <i className="fa fa-plus" />
              Add
            </>
          }
          buttonProps={{
            disabled: !operator,
          }}
        >
          <SchemaForm
            schema="NewXRFMapROISchema"
            onSubmit={onSubmit}
            formData={{
              sampleid: currentSampleId,
            }}
            requireOperator
            button={(d: boolean, os: () => void) => {
              disabledRef.current = d;
              onSubmitRef.current = os;
              forceRender(!render);
            }}
          />
        </ButtonTriggerModalStore>
      </div>
      <Table
        keyField="maproiid"
        loading={loading}
        data={rois.rows || []}
        columns={columns}
        noDataIndication="No ROIs defined"
      />
    </>
  );
}
