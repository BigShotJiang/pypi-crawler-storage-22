import { Button } from 'react-bootstrap';

interface IRegenerateButton {
  subsampleid: number;
  datacollectiongroupid?: number | null;
  buttonProps: Record<string, any>;
  actions: {
    regenerateMaps: (props: Record<string, any>) => Promise<any>;
  };
}

export default function RegenerateButton({
  subsampleid,
  datacollectiongroupid,
  actions,
  buttonProps,
}: IRegenerateButton) {
  const onClick = () => {
    actions.regenerateMaps({
      subsampleid,
      ...(datacollectiongroupid ? { datacollectiongroupid } : null),
    });
  };
  return (
    <Button onClick={onClick} title="Regenerate Maps" {...buttonProps}>
      <i className="fa fa-refresh" />
    </Button>
  );
}
