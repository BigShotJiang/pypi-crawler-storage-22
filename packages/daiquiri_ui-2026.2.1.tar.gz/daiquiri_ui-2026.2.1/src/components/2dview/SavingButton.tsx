import { map } from 'lodash';
import { Form, Row, Col } from 'react-bootstrap';

import ButtonTriggerModalStore from 'connect/layout/ButtonTriggerModalStore';
import { useEffect } from 'react';
import useSampleOptions, { useSubSampleOptions } from '../samples/options';

interface ISavingButton {
  disabled?: boolean;
  saving: Record<string, any>;
  actions: {
    fetchSaving: (params: any) => Promise<any>;
  };
}

export default function SavingButton(props: ISavingButton) {
  const { currentSampleId } = useSampleOptions();
  const { currentSubSampleId } = useSubSampleOptions();
  useEffect(() => {
    props.actions.fetchSaving({
      sampleid: currentSampleId,
      subsampleid: currentSubSampleId,
    });
  }, [currentSampleId, currentSubSampleId]);
  return (
    <ButtonTriggerModalStore
      id="saving"
      button={<i className="fa fa-cog" />}
      buttonProps={{
        className: 'me-1 float-end',
        disabled: props.disabled,
      }}
      title="Saving Configuration"
    >
      <Form>
        {map(props.saving.arguments, (v, k) => (
          <Form.Group as={Row} key={k}>
            <Form.Label column sm={3}>
              {k}
            </Form.Label>
            <Col>{v}</Col>
          </Form.Group>
        ))}
      </Form>
    </ButtonTriggerModalStore>
  );
}
