import { useDLE } from '@data-client/react';
import { useEffect } from 'react';
import { MapValueResource } from '../../resources/MapValue';

interface IPointer {
  x: number;
  y: number;
  px: number;
  py: number;
  point: number;
  mapid: number;
}

interface IValueModal {
  pointer: IPointer;
  actions: {
    setMapHover: (payload?: number) => void;
  };
}

export default function ValueModal(props: IValueModal) {
  const { actions, pointer = {} as IPointer } = props;
  const { data: value, error } = useDLE(
    MapValueResource,
    pointer.x !== undefined && pointer.y !== undefined
      ? {
          mapid: pointer.mapid,
          x: pointer.x,
          y: pointer.y,
        }
      : null
  );

  useEffect(() => {
    if (pointer.x === undefined || pointer.y === undefined) {
      actions.setMapHover();
    }
  }, [pointer]);

  if (pointer.x === undefined || (!value && !error)) {
    return null;
  }
  return (
    <div
      className="tooltip-inner"
      style={{
        position: 'absolute',
        top: pointer.py + 30,
        left: pointer.px + 30,
        zIndex: 1070,
      }}
    >
      {error && (
        <span>
          x: {value?.x} y: {value?.y} p: {pointer.point + 1} | Could not fetch
          value
        </span>
      )}
      {!error && value && (
        <div className="value-modal">
          x: {value.x} y: {value.y} p: {pointer.point + 1} | v:{' '}
          {value.value?.toFixed(2)}
        </div>
      )}
    </div>
  );
}
