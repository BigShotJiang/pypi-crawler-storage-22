/* eslint-disable object-shorthand */
import { fabric } from 'fabric';
import { VideoRTC } from './video-rtc';

customElements.define('video-stream', VideoRTC);

const VideoImage = fabric.util.createClass(fabric.Image, {
  initialize: function (options) {
    this.callSuper('initialize', options);
    this.firstRender = true;
    this.readyCallback = options.readyCallback;

    this.videoStream = document.createElement('video-stream');
    this.videoStream.visibilityCheck = false;
    this.videoStream.oninit();
    this.videoStream.src = options.url;

    this.videoStream.video.addEventListener(
      'loadedmetadata',
      this.onVideoMetadata.bind(this)
    );
    if (options.autoplay) this.video.play();
  },

  onVideoMetadata: function () {
    const video = this.videoStream.video;
    video.width = video.videoWidth;
    video.height = video.videoHeight;
    this.width = video.videoWidth;
    this.height = video.videoHeight;
    this.setElement(video);
    this.setCoords();

    if (this.readyCallback) this.readyCallback();
  },

  play: function () {
    this.video.play();
  },

  stop: function () {
    this.video.stop();
  }
});

export default VideoImage;
