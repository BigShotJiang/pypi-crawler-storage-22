import useUserPreference from '../utils/UseUserPreference';

interface Viewport {
  x?: number;
  y?: number;
}

export default function use2dOptions() {
  const [currentAction, setAction] = useUserPreference(
    '2dview/currentAction',
    'pan'
  );
  const [disableOrigin, setDisableOrigin] = useUserPreference(
    '2dview/disableOrigin',
    false
  );
  const [clampOrigin, setClampOrigin] = useUserPreference(
    '2dview/clampOrigin',
    true
  );
  const [clampTarget, setClampTarget] = useUserPreference(
    '2dview/clampTarget',
    ''
  );
  const [sourceUrl, setSourceUrl] = useUserPreference('2dview/sourceUrl', '');
  const [viewport, setViewport] = useUserPreference<Viewport>(
    '2dview/viewport',
    {}
  );
  const [zoom, setZoom] = useUserPreference('2dview/zoom', 1);

  return {
    currentAction,
    setAction,
    disableOrigin,
    setDisableOrigin,
    clampOrigin,
    setClampOrigin,
    clampTarget,
    setClampTarget,
    sourceUrl,
    setSourceUrl,
    viewport,
    setViewport,
    zoom,
    setZoom,
  };
}
