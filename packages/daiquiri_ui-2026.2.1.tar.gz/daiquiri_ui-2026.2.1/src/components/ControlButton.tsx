import { Button } from 'react-bootstrap';
import Tooltip from 'components/common/Tooltip';

export default function ControlButton(props: {
  operator: boolean;
  actions: {
    requestControl: () => void;
    yieldControl: () => void;
  };
}) {
  const { operator, actions } = props;
  const icon = operator ? 'unlock' : 'lock';
  return (
    <Tooltip
      tooltip={`This session ${
        operator ? 'has' : 'does not have'
      } control. Click to ${operator ? 'yield' : 'request'}`}
      bottom
    >
      <Button
        size="sm"
        className="me-2 btn-fw"
        variant={operator ? 'success' : 'warning'}
        onClick={operator ? actions.yieldControl : actions.requestControl}
      >
        <i className={`fa fa-${icon}`} />
      </Button>
    </Tooltip>
  );
}
