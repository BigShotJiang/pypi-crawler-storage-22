import type { PropsWithChildren } from 'react';

import Alerts from 'connect/Alerts';

import { Container } from 'react-bootstrap';

export default function Loader(props: PropsWithChildren<Record<string, any>>) {
  const { children } = props;
  return (
    <Container className="loader">
      <Alerts inline />
      <div className="mx-auto mt-4">
        <div className="loader-wrap shadow">
          <div className="mx-auto mb-3 logo logo-150" />
          <p className="text-center">Daiquiri UI</p>
        </div>

        <p className="text-center mt-5">
          {children && <>{children}</>}
          {!children && (
            <>
              <i className="fa fa-spinner fa-pulse fa-2x" />
              <br />
              Starting Up
            </>
          )}
        </p>
      </div>
    </Container>
  );
}
