import { useCallback, useState } from 'react';
import { trim, throttle } from 'lodash';
import { Button } from 'react-bootstrap';

interface Props {
  log?: string;
  noLines?: number;
}

export default function LogViewer(props: Props) {
  const { log = '', noLines = 5 } = props;

  const [offset, setOffset] = useState(0);
  const lines = trim(log).split('\n');

  const onScroll = useCallback(
    throttle((dir) => {
      setOffset((currentOffset) => {
        if (dir > 0) {
          if (currentOffset < lines.length - noLines) {
            return currentOffset + 1;
          }
        } else if (currentOffset > 0) {
          return currentOffset - 1;
        }

        return currentOffset;
      });
    }, 50),
    [lines.length]
  );

  const canScrollUp = offset < lines.length - noLines;
  const canScrollDown = offset > 0;

  const outputLines = lines.slice(
    lines.length - noLines - offset,
    lines.length - offset
  );
  if (outputLines[outputLines.length - 1] === '') {
    outputLines[outputLines.length - 1] = '\n';
  }

  return (
    <div className="log-viewer-wrap" onWheel={(e) => onScroll(-e.deltaY)}>
      <div className="log-viewer">{outputLines.join('\n')}</div>
      <div className="log-viewer-scroll">
        <Button
          className="scroll-up"
          size="sm"
          onClick={() => onScroll(1)}
          disabled={!canScrollUp}
        >
          <i className="fa fa-caret-up" />
        </Button>
        <Button
          className="scroll-down"
          size="sm"
          onClick={() => onScroll(-1)}
          disabled={!canScrollDown}
        >
          <i className="fa fa-caret-down" />
        </Button>
      </div>
    </div>
  );
}
