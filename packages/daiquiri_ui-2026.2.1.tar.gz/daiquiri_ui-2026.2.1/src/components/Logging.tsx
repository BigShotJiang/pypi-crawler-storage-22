import { Suspense, useEffect, useRef } from 'react';
import moment from 'moment';
import { map, values, keys } from 'lodash';

import Badge from 'react-bootstrap/Badge';
import { useSuspense } from '@data-client/react';
import { UserResource } from '../resources/User';

function LogEntry(props: {
  type: string;
  timestamp: string;
  level: string;
  message: string;
  stack_trace?: string;
  you?: boolean;
}) {
  const {
    type,
    timestamp,
    level,
    message,
    stack_trace = '',
    you = false,
  } = props;

  return (
    <div className="log">
      <div className="log-left">
        <div className={`type type-${type}`} title={type} />
      </div>
      <div className="log-right">
        <div className="title">
          <span title={moment(timestamp).format('DD-MM-YYYY HH:mm:ss')}>
            {moment(timestamp).fromNow()}
          </span>
          {you && <Badge bg="secondary">You</Badge>}
        </div>
        <div className="message">
          <span className={`level level-${level}`} title={level} />
          <p>{message}</p>
          {stack_trace && <span className="stack-trace">{stack_trace}</span>}
        </div>
      </div>
    </div>
  );
}

interface Props {
  current: {
    sessionid: string;
  };
  logging: Record<string, any>;
  actions: {
    fetchLogs: (props?: { offset: number }) => void;
  };
}

function Logging(props: Props) {
  const { current, logging, actions } = props;
  const user = useSuspense(UserResource);

  const bottomRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  function loadNext() {
    if (user?.is_staff) {
      actions.fetchLogs({
        offset: values(logging).length,
      });
    }
  }

  useEffect(() => {
    if (user?.is_staff) {
      actions.fetchLogs();
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(() => {
        loadNext();
      });
    });
    if (bottomRef.current) {
      observer.observe(bottomRef.current);
    }
    return () => {
      observer.disconnect();
    };
  }, []);

  const sortedKeys = keys(logging).sort(
    (a, b) => Number.parseFloat(b) - Number.parseFloat(a)
  );

  return (
    <div className="logging" ref={containerRef}>
      {map(sortedKeys, (k, id) => (
        <LogEntry
          {...logging[k]}
          key={id}
          you={logging[k].sessionid === current.sessionid}
        />
      ))}
      <div ref={bottomRef} className="logging-bottom" />
    </div>
  );
}

export default function LoggingWrap(props: Props) {
  return (
    <Suspense fallback="Loading...">
      <Logging {...props} />
    </Suspense>
  );
}
