import type { FormEvent } from 'react';
import { useRef, useEffect, useState, useCallback } from 'react';
import { Form, Button, Container, Col, Row, Alert } from 'react-bootstrap';
import Keycloak from 'keycloak-js';
import { useController } from '@data-client/react';
import { UserResource } from '../resources/User';

function Oauth2ProxyAutoLogin(props: LoginProps) {
  const { actions } = props;
  useEffect(() => {
    actions.login({});
  }, [props.actions]);

  return (
    <Container className="login">
      <Row>
        <Col md="4" sm="12" />
        <Col md="4" sm="12">
          <Container className="mt-3 shadow rounded pb-1 pt-3">
            <div className="mx-auto mb-3 logo logo-150" />
            <Alert show={!!props.error} variant="danger">
              {typeof props.error === 'object' && props.error !== null
                ? props.error.messages
                : props.error}
            </Alert>
            <p className="text-center bg-light border rounded p-2">
              Logging in with OAuth2 Proxy...
            </p>
          </Container>
        </Col>
        <Col md="4" sm="12" />
      </Row>
    </Container>
  );
}
interface KeycloakOptions {
  keycloak_server_url: string;
  keycloak_realm_name: string;
  keycloak_client_id: string;
}
interface KeycloakSSOLoginProps extends Omit<LoginProps, 'config'> {
  config: {
    options: KeycloakOptions;
    plugin: string;
    type: string;
  };
}
function KeycloakSSOLogin(props: KeycloakSSOLoginProps) {
  const { config, actions } = props;
  const { options } = config;
  const keycloak = new Keycloak({
    url: options.keycloak_server_url,
    realm: options.keycloak_realm_name,
    clientId: options.keycloak_client_id,
  });

  keycloak.init({});

  keycloak.onAuthSuccess = () => {
    actions.login({ token: keycloak.token });
    keycloak.onAuthSuccess = undefined;
    keycloak.onAuthError = undefined;
  };

  return (
    <Container className="login">
      <Row>
        <Col md="4" sm="12" />
        <Col md="4" sm="12">
          <Container className="mt-3 shadow rounded pb-1 pt-3">
            <div className="mx-auto mb-3 logo logo-150" />
            <Button
              onClick={() => void keycloak.login()}
              className="mb-3 w-100 "
              variant="secondary"
            >
              Login with SSO
            </Button>
          </Container>
        </Col>
        <Col md="4" sm="12" />
      </Row>
    </Container>
  );
}

interface AllOptions extends KeycloakOptions {
  [key: string]: any;
}

interface LoginProps {
  actions: {
    login: (payload: any) => Promise<any>;
  };
  error: string | Record<string, any>;
  config: {
    options: AllOptions;
    plugin: string;
    type: string;
  };
}
export default function Login(props: LoginProps) {
  if (props.config.plugin === 'KeycloakAuthenticator') {
    return <KeycloakSSOLogin {...props} />;
  }

  if (props.config.plugin === 'Oauth2ProxyAuthenticator') {
    return <Oauth2ProxyAutoLogin {...props} />;
  }

  return <LoginUserPass {...props} />;
}

function LoginUserPass(props: LoginProps) {
  const userRef = useRef<HTMLInputElement>(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [validated, setValidated] = useState(false);
  const [pending, setPending] = useState(false);
  const [userError, setUserError] = useState('');
  const { fetch } = useController();

  useEffect(() => {
    userRef.current?.focus();
  }, []);

  const login = useCallback(
    (e: FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      setValidated(true);

      const form = e.currentTarget;
      if (!form.checkValidity()) {
        e.stopPropagation();
        return;
      }

      setPending(true);
      props.actions
        .login({ username, password })
        .then(() => {
          // eslint-disable-next-line promise/no-nesting
          fetch(UserResource).catch((error) => {
            // eslint-disable-next-line promise/no-nesting
            error.response?.json().then((json: Record<string, any>) => {
              setUserError(json.error);
              setPending(false);
            });
          });
        })
        .catch(() => {
          console.log('could not log user in');
          setTimeout(() => {
            setPending(false);
          }, 1000);
        });
    },
    [username, password, props.actions.login, setValidated, setPending]
  );

  return (
    <Container className="login">
      <Row>
        <Col md="4" sm="12" />
        <Col md="4" sm="12">
          <Container className="mt-3 shadow rounded pb-1 pt-3">
            <div className="mx-auto mb-3 logo logo-150" />

            <>
              <Alert show={!!props.error} variant="danger">
                {typeof props.error === 'object' && props.error !== null
                  ? props.error.messages
                  : props.error}
              </Alert>
              <Alert show={!!userError} variant="danger">
                {userError}
              </Alert>
            </>

            <Form noValidate validated={validated} onSubmit={login}>
              <Container>
                <Form.Group as={Row} controlId="username" className="mb-3">
                  <Form.Label column sm={3}>
                    Username
                  </Form.Label>
                  <Col>
                    <Form.Control
                      ref={userRef}
                      type="text"
                      placeholder="Username"
                      onChange={(e) => setUsername(e.target.value)}
                      value={username}
                      name="username"
                      required
                    />
                    <Form.Control.Feedback type="invalid">
                      Please provide a username
                    </Form.Control.Feedback>
                  </Col>
                </Form.Group>

                <Form.Group as={Row} controlId="password" className="mb-3">
                  <Form.Label column sm={3}>
                    Password
                  </Form.Label>
                  <Col>
                    <Form.Control
                      type="password"
                      placeholder="Password"
                      onChange={(e) => setPassword(e.target.value)}
                      value={password}
                      name="password"
                      required
                    />
                    <Form.Control.Feedback type="invalid">
                      Please provide a password
                    </Form.Control.Feedback>
                  </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3">
                  <Button variant="primary" type="submit" disabled={pending}>
                    {pending && <i className="fa fa-spinner fa-spin me-2" />}
                    Login
                  </Button>
                </Form.Group>
              </Container>
            </Form>
          </Container>
        </Col>
        <Col md="4" sm="12" />
      </Row>
    </Container>
  );
}
