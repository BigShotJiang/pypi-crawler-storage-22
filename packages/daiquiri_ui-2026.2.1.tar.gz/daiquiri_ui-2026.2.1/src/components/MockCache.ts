class MockCache {
  protected cache: Record<string, any> = {};

  public load(props: {
    mock: any;
    keyid: string;
    key: any;
    resolve: (param: any) => void;
  }) {
    if (!(props.mock in this.cache)) {
      fetch(props.mock).then((resp) => {
        // eslint-disable-next-line promise/no-nesting
        resp.json().then((obj) => {
          obj[props.keyid] = props.key;
          this.cache[props.mock] = obj;
          props.resolve(obj);
        });
      });
    } else {
      props.resolve(this.cache[props.mock]);
    }
  }
}

export default new MockCache();
