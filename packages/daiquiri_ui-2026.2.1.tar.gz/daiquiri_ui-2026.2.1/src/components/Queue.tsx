import type { RefObject } from 'react';
import { createRef, Component } from 'react';
import { map, sum, find } from 'lodash';
import moment from 'moment';

import {
  Badge,
  Button,
  Row,
  Col,
  Container,
  OverlayTrigger,
  Form,
  Tooltip,
} from 'react-bootstrap';
import { Formatting } from '@esrf/daiquiri-lib';

import Confirm from 'helpers/Confirm';
import Table from 'components/table';
import momentCell from 'components/table/cells/momentCell';
import hrsMinsCell from 'components/table/cells/hrsMinsCell';
import ButtonTriggerModalStore from 'connect/layout/ButtonTriggerModalStore';
import CopyScan from 'connect/samples/CopyScan';
import LogViewer from 'components/LogViewer';
import SelectableTable from './table/Selectable';

interface QueueItem {
  name: string;
  uid: string;
  created: number;
  estimate?: number;
  args: {
    sample: number;
    sampleid: number;
    subsampleid: number;
  };
  status: string;
  stdout?: string;
}

function argFormatter(cell: any) {
  if (typeof cell === 'object') {
    const columns = [
      { dataField: 'key', text: 'Key' },
      {
        dataField: 'value',
        text: 'Value',
        formatter: argFormatter,
        classes: 'queue-item-args',
      },
    ];

    const args = map(cell, (v, k) => ({ key: k, value: v }));

    return (
      <Table
        keyField="key"
        data={args}
        columns={columns}
        bordered={false}
        classes="table-sm"
        striped
        noDataIndication="No arguments"
      />
    );
  }
  return <span>{cell}</span>;
}

function QueueItemDetail(props: QueueItem) {
  return (
    <Container>
      <Row>
        <Col xs={2}>Type</Col>
        <Col>{props.name}</Col>
      </Row>
      <Row>
        <Col xs={2}>UUID</Col>
        <Col>{props.uid}</Col>
      </Row>
      <Row>
        <Col xs={2}>Created</Col>
        <Col>{moment.unix(props.created).format('DD-MM-YYYY HH:mm:ss')}</Col>
      </Row>
      <Row>
        <Col xs={2}>Sample</Col>
        <Col>{props.args.sampleid}</Col>
      </Row>
      {props.args.subsampleid && (
        <Row>
          <Col xs={2}>Subsample</Col>
          <Col>{props.args.subsampleid}</Col>
        </Row>
      )}
      <Row>
        <Col xs={2}>Arguments</Col>
        <Col>{argFormatter(props.args)}</Col>
      </Row>
      <Row>
        <Col xs={2}>Output</Col>
        <Col>
          <div className="log-viewer-wrap">
            <div className="log-viewer">{props.stdout}</div>
          </div>
        </Col>
      </Row>
    </Container>
  );
}

function QueueItemButton(props: {
  item: QueueItem;
  inset?: boolean;
  prefix?: string;
}) {
  const { item } = props;
  return (
    <ButtonTriggerModalStore
      id={`queueItemDetail${item.uid}${props.prefix ?? ''}`}
      button={<i className="fa fa-search" />}
      buttonProps={{
        className: `me-1${props.inset ? ' float-end mb-3' : ''}`,
        variant: 'info',
        size: props.inset ? '' : 'sm',
      }}
      title="Queue Item Details"
    >
      <QueueItemDetail {...item} />
    </ButtonTriggerModalStore>
  );
}

function statusCell(cell: any, row: QueueItem) {
  const variants: Record<string, { bg: string; title: string; icon: string }> =
    {
      finished: { bg: 'success', title: 'Finished', icon: 'check' },
      failed: {
        bg: 'danger',
        title: 'Failed',
        icon: 'exclamation-triangle',
      },
      running: { bg: 'info', title: 'Running', icon: 'cog fa-spin' },
      queued: { bg: 'warning', title: 'Queued', icon: 'pause' },
    };

  const v = variants[row.status] || variants.queued;
  return (
    <>
      <Badge className="me-1" bg={v.bg}>
        {v.title}
      </Badge>
      <QueueItemButton item={row} />
    </>
  );
}

function sampleCell(cell: any, row: QueueItem | undefined) {
  if (!row) {
    return <></>;
  }
  return (
    <span>
      {row.args.sample && <>{row.args.sample} [</>}
      {row.args.sampleid}
      {row.args.subsampleid && <>-{row.args.subsampleid}</>}
      {row.args.sample && <>]</>}
    </span>
  );
}

function QueueItemButtons(props: {
  selectedItems?: string[];
  selectedItem?: string;
  operator: boolean;
  stack: QueueItem[];
  all: QueueItem[];
  actions: {
    moveItem: (prop: { uid: string; position: number }) => Promise<any>;
    removeItem: (uid: string) => Promise<any>;
  };
}) {
  const { all, operator, selectedItem, selectedItems, stack } = props;
  const item = find(all, { uid: selectedItem });
  const itemsInStack = stack
    .filter((item) => selectedItems?.includes(item.uid))
    .map((item) => {
      return {
        uid: item.uid,
        idx: find(stack, { uid: item.uid }) ? stack.indexOf(item) : -1,
      };
    });
  const minIdx = Math.min(...itemsInStack.map((item) => item.idx));
  const maxIdx = Math.max(...itemsInStack.map((item) => item.idx));

  return (
    <div className="text-nowrap">
      <OverlayTrigger
        placement="top"
        overlay={<Tooltip>Create a new scan from this one</Tooltip>}
      >
        <CopyScan
          sampleid={item?.args.sampleid}
          subsampleid={item?.args.subsampleid}
          args={item?.args}
          type={item?.name}
          inset
          disabled={!item || !operator || (selectedItems?.length ?? 0) > 1}
        />
      </OverlayTrigger>
      <OverlayTrigger
        placement="top"
        overlay={<Tooltip>Move item to top</Tooltip>}
      >
        <Button
          size="sm"
          className="me-1"
          onClick={() => {
            async function moveToTop() {
              if (itemsInStack) {
                for (let i = 0; i < itemsInStack.length; i++) {
                  const item = itemsInStack[i];
                  // eslint-disable-next-line no-await-in-loop
                  await props.actions.moveItem({
                    uid: item.uid,
                    position: i,
                  });
                }
              }
            }
            moveToTop();
          }}
          disabled={itemsInStack.length === 0 || minIdx === 0 || !operator}
        >
          <i className="fa fa-arrow-circle-up" />
        </Button>
      </OverlayTrigger>
      <OverlayTrigger placement="top" overlay={<Tooltip>Move item up</Tooltip>}>
        <Button
          size="sm"
          className="me-1"
          onClick={() => {
            async function moveUp() {
              if (itemsInStack) {
                for (const item of itemsInStack) {
                  // eslint-disable-next-line no-await-in-loop
                  await props.actions.moveItem({
                    uid: item.uid,
                    position: item.idx - 1,
                  });
                }
              }
            }
            moveUp();
          }}
          disabled={itemsInStack.length === 0 || minIdx === 0 || !operator}
        >
          <i className="fa fa-arrow-up" />
        </Button>
      </OverlayTrigger>

      <OverlayTrigger
        placement="top"
        overlay={<Tooltip>Move item down</Tooltip>}
      >
        <Button
          size="sm"
          className="me-1"
          onClick={() => {
            async function moveDown() {
              if (itemsInStack) {
                for (let i = itemsInStack.length - 1; i >= 0; i--) {
                  const item = itemsInStack[i];
                  // eslint-disable-next-line no-await-in-loop
                  await props.actions.moveItem({
                    uid: item.uid,
                    position: item.idx + 1,
                  });
                }
              }
            }
            moveDown();
          }}
          disabled={
            itemsInStack.length === 0 ||
            maxIdx === stack.length - 1 ||
            !operator
          }
        >
          <i className="fa fa-arrow-down" />
        </Button>
      </OverlayTrigger>

      <OverlayTrigger placement="top" overlay={<Tooltip>Delete item</Tooltip>}>
        <Confirm
          title="Delete Queue Item(s)"
          message={`Are you sure you want to delete these ${itemsInStack.length} items?  This operation cannot be undone`}
        >
          {(confirm) => (
            <Button
              variant="danger"
              size="sm"
              onClick={confirm(() => {
                if (itemsInStack) {
                  itemsInStack.forEach((item) => {
                    props.actions.removeItem(item.uid);
                  });
                }
              })}
              disabled={
                (item && item.status !== 'queued') || !selectedItem || !operator
              }
            >
              <i className="fa fa-times" />
            </Button>
          )}
        </Confirm>
      </OverlayTrigger>
    </div>
  );
}

interface Props {
  actions: {
    fetchQueue: () => void;
    setQueueStatus: (status: boolean) => void;
    updateQueue: (property: { setting: string; value: boolean }) => void;
    removeItem: (uid: string) => Promise<any>;
    moveItem: (props: { uid: string; position: number }) => Promise<any>;
    addPause: () => void;
    addSleep: (props: { time: number }) => void;
    clear: () => void;
    kill: () => void;
    setParams: (prop: { status: string }, value: any) => void;
    addSelection: (payload: any) => void;
    removeSelection: (payload: any) => void;
    resetSelection: () => void;
  };
  actorLog: Record<string, string>;
  running: boolean;
  ready: boolean;
  queue?: {
    stack: QueueItem[];
    all: QueueItem[];
    current?: QueueItem;
    pause_on_fail: boolean;
  };
  selectedItems?: string[];
  selectedItem?: string;
  params: {
    status: string;
  };
  fetched: boolean;
  operator: boolean;
}

export default class Queue extends Component<Props> {
  private readonly sleepRef: RefObject<HTMLSelectElement>;

  public constructor(props: Props) {
    super(props);

    this.sleepRef = createRef();
  }

  public componentDidMount() {
    this.props.actions.fetchQueue();
  }

  protected toggle() {
    this.props.actions.setQueueStatus(!this.props.running);
  }

  protected togglePauseOnFail(e: React.MouseEvent<HTMLInputElement>) {
    this.props.actions.updateQueue({
      setting: 'pause_on_fail',
      // @ts-expect-error
      value: e.target.checked,
    });
  }

  protected removeItem(queueid: string) {
    return this.props.actions.removeItem(queueid);
  }

  protected moveItem(props: { uid: string; position: number }) {
    return this.props.actions.moveItem(props);
  }

  protected addPause() {
    this.props.actions.addPause();
  }

  protected addSleep() {
    if (this.sleepRef.current) {
      const value = this.sleepRef.current.value;
      this.props.actions.addSleep({
        time: Number.parseFloat(value),
      });
    }
  }

  protected clearQueue() {
    this.props.actions.clear();
  }

  protected killQueue() {
    this.props.actions.kill();
  }

  protected filter(value: any) {
    const v = this.props.params.status === value ? null : value;
    this.props.actions.setParams(
      {
        status: v,
      },
      true
    );
  }

  public render() {
    const columns = [
      { dataField: 'name', text: 'Type' },
      { dataField: 'args.subsampleid', text: 'Sample', formatter: sampleCell },
      {
        dataField: 'created',
        text: 'Created',
        formatter: momentCell,
        formatExtraData: { format: 'DD-MM HH:mm:ss' },
      },
      { dataField: 'estimate', text: 'Estimated', formatter: hrsMinsCell },
      {
        dataField: '',
        text: '',
        formatter: statusCell,
        classes: 'text-end text-nowrap',
      },
    ];

    const {
      queue = {
        stack: [],
        all: [],
        current: undefined,
        pause_on_fail: false,
      },
    } = this.props;

    const timeEst = Formatting.toHoursMins(
      sum(map(queue.stack, (qi: any) => qi.estimate))
    );

    return (
      <>
        {this.props.fetched && (
          <div className="queue">
            <Container className="collapse-margins">
              <Row>
                <Col>
                  State is currently:{' '}
                  <Badge
                    bg={this.props.running ? 'success' : 'warning'}
                    className="me-1"
                  >
                    {this.props.running ? 'Running' : 'Paused'}
                  </Badge>
                  <Badge bg={this.props.ready ? 'success' : 'warning'}>
                    {this.props.ready ? 'Ready' : 'Waiting'}
                  </Badge>
                  <Form.Switch
                    disabled={!this.props.operator}
                    label="Pause on Error"
                    id="error-pause"
                    onClick={this.togglePauseOnFail.bind(this)}
                    defaultChecked={queue.pause_on_fail}
                  />
                </Col>
                <Col xs={3} className="text-end">
                  <Button
                    variant={this.props.running ? 'warning' : 'success'}
                    onClick={this.toggle.bind(this)}
                    className="me-1"
                    disabled={!this.props.operator}
                    title={
                      this.props.running
                        ? 'Pause the queue after the current item'
                        : 'Start the queue'
                    }
                  >
                    <i
                      className={`fa fa-${
                        this.props.running ? 'pause' : 'play'
                      }`}
                    />
                  </Button>
                  <Confirm
                    title="Empty Queue"
                    message="Are you sure you want to empty the queue? This will delete all queued items and cannot be undone"
                  >
                    {(confirm) => (
                      <Button
                        variant="danger"
                        onClick={confirm(this.clearQueue.bind(this))}
                        disabled={!this.props.operator}
                        title="Clear Queue"
                      >
                        <i className="fa fa-trash" />
                      </Button>
                    )}
                  </Confirm>
                </Col>
              </Row>
            </Container>

            <div>
              <h4>Current Item</h4>
              <Container className="collapse-margins">
                {queue.current && (
                  <>
                    <Confirm
                      title="Kill Running Queue Item"
                      message="Are you sure you want to kill the currently running queue item? This could result in loss of data"
                    >
                      {(confirm) => (
                        <Button
                          variant="danger"
                          onClick={confirm(this.killQueue.bind(this))}
                          className="float-end"
                          disabled={
                            !this.props.operator ||
                            (!this.props.running && !queue.current)
                          }
                          title="Kill current queue item"
                        >
                          <i className="fa fa-stop" />
                        </Button>
                      )}
                    </Confirm>
                    <QueueItemButton
                      prefix="running"
                      item={queue.current}
                      inset
                    />
                    <Row>
                      <Col>Name</Col>
                      <Col>{queue.current?.name}</Col>
                    </Row>
                    <Row>
                      <Col>Sample</Col>
                      <Col>{sampleCell(null, queue.current)}</Col>
                    </Row>
                    <Row>
                      <Col>Estimated</Col>
                      <Col>
                        {Formatting.toHoursMins(queue.current?.estimate ?? 0)}
                      </Col>
                    </Row>
                    {this.props.actorLog[queue.current?.uid] && (
                      <>
                        <Row>
                          <Col>
                            <LogViewer
                              log={this.props.actorLog[queue.current.uid]}
                            />
                          </Col>
                        </Row>
                      </>
                    )}
                  </>
                )}
              </Container>
              {queue.current === null && <span>No queue item running</span>}
            </div>

            <h4 className="mt-2">Queue Items</h4>
            <div className="clearfix">
              <OverlayTrigger
                placement="top"
                overlay={<Tooltip>Add a pause to the queue</Tooltip>}
              >
                <Button
                  size="sm"
                  onClick={this.addPause.bind(this)}
                  className="float-end mb-1"
                  disabled={!this.props.operator}
                >
                  <i className="fa fa-plus me-1" />
                  <i className="fa fa-pause" />
                </Button>
              </OverlayTrigger>

              <OverlayTrigger
                placement="top"
                overlay={<Tooltip>Add a sleep to the queue</Tooltip>}
              >
                <Button
                  size="sm"
                  onClick={this.addSleep.bind(this)}
                  className="float-end mb-1 me-1"
                  disabled={!this.props.operator}
                >
                  <i className="fa fa-plus me-1" />
                  <i className="fa fa-hourglass-half" />
                </Button>
              </OverlayTrigger>

              <Form className="float-end me-1">
                <Form.Control as="select" size="sm" ref={this.sleepRef}>
                  {map([5, 10, 20, 30, 60, 120, 300], (t) => (
                    <option value={t} key={t}>
                      {t}
                    </option>
                  ))}
                </Form.Control>
              </Form>

              <span>
                Estimated time:
                {timeEst}
              </span>
            </div>

            <Container className="collapse-margins">
              <Row>
                <Col>
                  <Button
                    className="mb-1"
                    size="sm"
                    variant={
                      this.props.params.status === 'Finished'
                        ? 'primary'
                        : 'secondary'
                    }
                    onClick={() => {
                      this.filter('Finished');
                    }}
                  >
                    Finished
                  </Button>
                </Col>
                <Col className="text-end">
                  <QueueItemButtons
                    actions={{
                      moveItem: this.moveItem.bind(this),
                      removeItem: this.removeItem.bind(this),
                    }}
                    selectedItems={this.props.selectedItems}
                    selectedItem={this.props.selectedItem}
                    all={queue.all}
                    stack={queue.stack}
                    operator={this.props.operator}
                  />
                </Col>
              </Row>
            </Container>

            <SelectableTable
              multiple
              localPerPage={15}
              keyField="uid"
              data={queue?.all}
              columns={columns}
              bordered={false}
              classes="table-sm queue"
              striped
              noDataIndication="No items in queue"
              selectedItems={this.props.selectedItems}
              actions={{
                addSelection: this.props.actions.addSelection,
                removeSelection: this.props.actions.removeSelection,
                resetSelection: this.props.actions.resetSelection,
              }}
            />
          </div>
        )}
      </>
    );
  }
}
