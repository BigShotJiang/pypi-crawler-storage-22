import { values } from 'lodash';
import { Container, Row, Col, Badge } from 'react-bootstrap';
import Table from 'components/table';
import type { SyntheticEvent } from 'react';
import { useDLE } from '@data-client/react';
import { SessionResource } from '../resources/Session';
import type { Session } from '../resources/models/Session';

function ActiveCell(cell: any) {
  if (cell) {
    return <Badge bg="success">Active</Badge>;
  }
}

export default function SelectSession(props: {
  actions: {
    selectSession: (session: string) => void;
  };
}) {
  const { actions } = props;
  const { data: sessions, loading } = useDLE(SessionResource.getList);

  function onRowClick(e: SyntheticEvent<any>, row: Session, rowIndex: number) {
    if (row.session) actions.selectSession(row.session);
  }

  function rowClasses(row: Session, rowIndex: number) {
    return 'pointer';
  }

  const columns = [
    { dataField: 'session', text: 'Session' },
    { dataField: 'startdate', text: 'Start' },
    { dataField: 'enddate', text: 'End' },
    {
      dataField: 'active',
      text: '',
      formatter: ActiveCell,
      classes: 'text-end',
    },
  ];

  return (
    <Container className="select-session mt-3">
      <h1>Select a session</h1>
      <Row>
        <Col>
          <Table
            keyField="session"
            data={sessions.rows || []}
            loading={loading}
            overlay={false}
            hover
            columns={columns}
            rowClasses={rowClasses}
            rowEvents={{ onClick: onRowClick }}
            noDataIndication="No sessions found"
          />
        </Col>
      </Row>
    </Container>
  );
}
