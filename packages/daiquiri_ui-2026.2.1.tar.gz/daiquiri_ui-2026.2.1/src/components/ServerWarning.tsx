import Alert from 'react-bootstrap/Alert';

export default function ServerWarning(props: {
  show: boolean;
  className?: string;
}) {
  const { show, className } = props;
  return (
    <div>
      {show && (
        <Alert variant="danger" className={`center ${className}`}>
          Cant connect to the server, is it running?
        </Alert>
      )}
    </div>
  );
}
