import { useEffect, useRef } from 'react';
import { Badge, Button, Alert } from 'react-bootstrap';

import ModalDialog from 'components/layout/ModalDialog';
import Table from 'components/table';
import momentCell from 'components/table/cells/momentCell';
import type { ColumnDescription } from 'react-bootstrap-table-next';

interface SessionDesc {
  sessionid: string;
  operator: boolean;
  operator_pending: boolean;
}

function StatusCell(
  cell: any,
  row: SessionDesc,
  rowIndex: number,
  formatExtraData: Record<string, any>
) {
  const text = [];
  if (row.sessionid === formatExtraData.sessionid) {
    text.push(
      <Badge key="current" bg="primary" className="me-1">
        You
      </Badge>
    );
  }
  if (row.operator) {
    text.push(
      <Badge key="operator" bg="secondary" className="me-1">
        Operator
      </Badge>
    );
  }
  if (row.operator_pending) {
    text.push(
      <Badge key="pending" bg="warning" className="me-1">
        Pending
      </Badge>
    );
  }

  return text;
}

export default function Sessions(props: {
  actions: {
    fetchSessions: () => void;
    requestControl: () => Promise<void>;
    respondControlRequest: (grant: boolean) => void;
    yieldControl: () => Promise<void>;
  };
  sessions: SessionDesc[];
  operator: boolean;
  sessionid: string;
  controlRequest?: string;
  toggleParent: () => void;
}) {
  const {
    actions,
    sessions = [],
    operator,
    sessionid,
    controlRequest = null,
    toggleParent,
  } = props;

  const targetRef = useRef<HTMLElement>(null);

  useEffect(() => {
    actions.fetchSessions();
  }, []);

  function respondControlRequest(grant: boolean) {
    actions.respondControlRequest(grant);
  }

  function requestControl() {
    actions.requestControl().then(() => {
      toggleParent();
    });
  }

  function yieldControl() {
    actions.yieldControl().then(() => {
      toggleParent();
    });
  }

  function onCloseRequest() {}

  const columns: ColumnDescription[] = [
    { dataField: 'data.username', text: 'User' },
    { dataField: 'data.client', text: 'Client' },
    {
      dataField: 'last_access',
      text: 'Last Access',
      formatter: momentCell,
      formatExtraData: { format: 'DD-MM-YYYY HH:mm:ss' },
      classes: 'text-nowrap',
    },
    {
      dataField: 'status',
      text: '',
      formatter: StatusCell,
      formatExtraData: { sessionid },
    },
  ];

  return (
    <>
      <ModalDialog
        target={targetRef}
        show={controlRequest !== null && operator}
        actions={{ onClose: onCloseRequest }}
        title="Control Requested"
        showClose={false}
        buttons={
          <>
            <Button onClick={() => respondControlRequest(true)}>Grant</Button>
            <Button onClick={() => respondControlRequest(false)}>Deny</Button>
          </>
        }
      >
        Another session &quot;
        {controlRequest ?? '???'}
        &quot; is requesting control. Without a response the other session will
        automatically be granted control
      </ModalDialog>

      {!operator && (
        <div className="d-grid gap-2 mb-2">
          <Button size="sm" onClick={requestControl}>
            Request Control
          </Button>
        </div>
      )}

      <Alert variant={operator ? 'success' : 'warning'} className="d-flex">
        <div className="flex-grow-1 m-auto">
          This session
          {operator ? ' has ' : ' does not have '}
          control
        </div>
        {operator && (
          <Button
            size="sm"
            className="d-block flex-grow-0"
            variant="warning"
            onClick={yieldControl}
          >
            Yield
          </Button>
        )}
      </Alert>

      <Table
        keyField="sessionid"
        data={sessions}
        columns={columns}
        bordered={false}
        classes="table-sm"
        striped
      />
    </>
  );
}
