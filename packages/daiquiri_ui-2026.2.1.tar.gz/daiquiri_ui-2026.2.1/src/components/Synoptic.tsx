import type { RefObject } from 'react';
import { createRef, useRef, useEffect, useState } from 'react';
import { SvgLoader, SvgProxy } from 'react-svgmt';

import { map, filter } from 'lodash';

import { Alert } from 'react-bootstrap';

import HardwareGroup from 'components/hardware/HardwareGroup';
import DraggablePopup from 'components/layout/DraggablePopup';
import ButtonTriggerModalStore from 'connect/layout/ButtonTriggerModalStore';
import { useHardwareStore } from '../store/HardwareStore';

interface Props {
  actions: {
    fetchHardwareGroups: () => void;
    fetchSVG: (sid: number) => Promise<{ data: any }>;
  };
  synoptic: {
    synoptics: {
      elements: {
        name: string;
        value: string;
        group?: string;
      }[];
      synoptic?: string;
    }[];
  };
  hardwareGroups: Record<string, any>;

  /** The synoptic id to show */
  sid?: number;
}

interface State {
  svg: any;
}

export default function Synoptic(props: Props) {
  const buttonRefs = useRef<
    Record<string, RefObject<typeof ButtonTriggerModalStore>>
  >({});
  const rectRefs = useRef<Record<string, RefObject<typeof SvgProxy>>>({});
  const [svg, setSvg] = useState<string | undefined>(undefined);

  const { sid = 0, synoptic, hardwareGroups } = props;

  // FIXME: This is wake up far too much
  const hardwareObjects = useHardwareStore((state) => {
    return state.hardware;
  });

  function validSynoptic() {
    return sid < synoptic.synoptics.length && sid > -1;
  }

  useEffect(() => {
    if (validSynoptic()) {
      props.actions.fetchSVG(props.sid ?? 0).then((resp) => {
        setSvg(resp.data);
      });
    }
  }, [synoptic.synoptics, props.sid]);

  useEffect(() => {
    props.actions.fetchHardwareGroups();
  }, []);

  function onClick(name: string, group: string) {
    if (group in buttonRefs) {
      // @ts-expect-error
      buttonRefs[group].current?.showModal();
    }
  }

  if (!validSynoptic()) {
    return (
      <Alert variant="warning">Could not find synoptic &quot;{sid}&quot;</Alert>
    );
  }

  const selectedSynoptic = synoptic.synoptics[sid];

  const groups = map(selectedSynoptic.elements, (el) => {
    const group = el.group ? hardwareGroups[el.group] : null;

    let value = null;
    if (el.value) {
      const path = el.value.split('.');
      const obj = hardwareObjects[path[0]];
      if (obj) {
        value = `${obj.properties[path[1]]} ${obj.properties.unit || ''}`;
      }
    }

    const cls = el.name.toLowerCase();
    const rectRef: RefObject<typeof SvgProxy> = createRef<typeof SvgProxy>();
    rectRefs.current[el.group ?? 'undefined'] = rectRef;

    return [
      <SvgProxy
        key={`${el.group}state`}
        selector={`.${cls} .status`}
        class={`$ORIGINAL ${group && (group.state ? 'ok' : 'error')}`}
      />,
      <SvgProxy key={`${el.group}value`} selector={`.${cls} .value`}>
        {value}
      </SvgProxy>,
      <SvgProxy
        key={`${el.group}handler`}
        selector={`.${cls} > rect`}
        onClick={() => onClick(cls, el.group ?? 'undefined')}
        /* @ts-expect-error */
        ref={rectRef}
      />,
      <SvgProxy
        key={`${el.group}comp`}
        class={`$ORIGINAL ${group ? 'active' : ''}`}
        selector={`.${cls}`}
      />,
    ];
  });

  const hwgroups = filter(
    selectedSynoptic.elements,
    (e) => e.group !== undefined
  );
  const popups = map(hwgroups, (g) => {
    if (!g.group) {
      return <></>;
    }
    const buttonRef = createRef<typeof ButtonTriggerModalStore>();
    buttonRefs.current[g.group] = buttonRef;

    function popperInterface() {
      if (!rectRefs.current[g.group ?? 'undefined']?.current) {
        return undefined;
      }
      const rectRef = rectRefs.current[g.group ?? 'undefined'];
      // @ts-expect-error
      return rectRef?.current?.elemRefs?.[0];
    }

    return (
      <ButtonTriggerModalStore
        id={`${g.group}pop`}
        key={`${g.group}pop`}
        ref={buttonRef}
        target={popperInterface}
        showButton={false}
        modalClass={DraggablePopup}
        popoverid={g.group}
        title={hardwareGroups[g.group]?.name ?? ''}
        button={
          <>
            <i className="fa fa-plus" />
            show
          </>
        }
      >
        <HardwareGroup
          even
          objects={
            hardwareGroups[g.group] &&
            map(hardwareGroups[g.group].objects, (id) => ({ id }))
          }
        />
      </ButtonTriggerModalStore>
    );
  });

  return (
    <div>
      <SvgLoader width="100%" svgXML={svg} className="synoptic">
        {groups}
      </SvgLoader>
      {popups}
    </div>
  );
}
