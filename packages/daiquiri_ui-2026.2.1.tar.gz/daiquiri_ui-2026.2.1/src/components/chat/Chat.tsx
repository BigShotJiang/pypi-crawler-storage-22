import type { RefObject } from 'react';
import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';

import {
  useDebouncedCallback,
  useFirstMountState,
  useSyncedRef,
} from '@react-hookz/web';
import { map, values } from 'lodash';
import { Form } from 'react-bootstrap';

import type { MessageElement } from './Message';
import Message from './Message';
import { useIntersectionObserver } from './useIntersectionObserver';
import type { MessageInfo, ScrollContainer, Sessions } from './types';

// ----------------------------------------------------------------------------
// Hook: Use chat cursor

function useChatCursor({
  onCursorChanged,
  delay = 200,
}: {
  onCursorChanged: (lastCursor: number) => void;
  delay?: number;
}) {
  const lastCursor = useRef(0);
  const reset = useDebouncedCallback(
    () => {
      onCursorChanged(lastCursor.current);
    },
    [onCursorChanged],
    delay
  );

  const setCursor = useCallback(
    (messageid: number) => {
      if (messageid > lastCursor.current) {
        lastCursor.current = messageid;
      }
      reset();
    },
    [reset]
  );

  return { setChatCursor: setCursor };
}

// ----------------------------------------------------------------------------
// Hook: Use new message sound

interface UseNewMessageSoundOptions {
  enable: boolean;
  unread: number;
}

function useNewMessageSound({ enable, unread }: UseNewMessageSoundOptions) {
  const unreadRef = useRef(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const isFirstMounted = useFirstMountState();

  // Create audio file only once
  useEffect(() => {
    if (!audioRef.current) {
      const audio = new Audio('/droplet.mp3');
      audio.preload = 'auto';
      audioRef.current = audio;
    }
  });

  useEffect(() => {
    const hasNewMessage = unread > (unreadRef.current ?? 0) && unread > 0;
    if (hasNewMessage && enable && !isFirstMounted) {
      audioRef.current?.play().catch(() => {
        // Catch any error and do nothing.
        // (typically happens on playing audio before user gesture)
      });
    }
    unreadRef.current = unread;
  }, [unread]);
}

// ----------------------------------------------------------------------------
// Component: Top anchor

function TopAnchor({ onView }: { onView: () => void }) {
  const localRef = useRef<HTMLDivElement>(null);
  const topEntry = useIntersectionObserver(localRef);

  useEffect(() => {
    if (topEntry?.isIntersecting) {
      onView();
    }
  }, [topEntry?.isIntersecting, onView]);

  return <div ref={localRef} />;
}

// ----------------------------------------------------------------------------
// Component: Bottom anchor

interface BottomAnchorHandle {
  getInView: () => boolean;
  scrollIntoView: () => void;
}

const BottomAnchor = forwardRef<BottomAnchorHandle>((_, forwardedRed) => {
  const localRef = useRef<HTMLDivElement>(null);
  const entry = useIntersectionObserver(localRef, {
    threshold: [1],
    debounceDelay: 100,
  });

  useImperativeHandle(
    forwardedRed,
    () => ({
      getInView: () => entry?.isIntersecting ?? false,
      scrollIntoView: () => {
        localRef.current?.scrollIntoView({ behavior: 'smooth' });
      },
    }),
    [entry?.isIntersecting]
  );

  return <div ref={localRef} style={{ height: 5 }} />;
});

// ----------------------------------------------------------------------------
// Component: Chat input

function ChatInput({
  onSubmit,
}: {
  onSubmit: React.FormEventHandler<HTMLFormElement>;
}) {
  return (
    <Form className="message-input" onSubmit={onSubmit}>
      <Form.Control type="text" name="chat-input" placeholder="Message" />
    </Form>
  );
}

// ----------------------------------------------------------------------------
// Component: Chat

interface ChatProps {
  actions: {
    fetchMessages: (params?: { offset: number }) => Promise<void>;
    sendMessage: (params: { message: string }) => Promise<void>;
    markRead: () => void;
    updateCache: (params: { cache: any }) => void;
  };
  messages: Record<string, MessageInfo>;
  scroll: ScrollContainer;
  sessions: Sessions[];
  sessionid: string;
  cache: {
    chatCursor?: number;
  };
  unread: number;
  loadCursor?: number;
}

function Chat(props: ChatProps) {
  // State: If chat panel is actually open
  const [inView, setInView] = useState(false);
  const nowInView = useRef(false);

  // Derive references from props
  const numMessagesRef = useSyncedRef(values(props.messages).length);
  const lastMessageidRef = useSyncedRef(values(props.messages)[0]?.messageid);
  const cacheRef = useSyncedRef(props.cache);

  // Initialize references
  const messageRefs = useRef<Record<number, RefObject<MessageElement>>>({});
  const registerMessageRef = useCallback(
    (messageid: number, ref: RefObject<MessageElement>) => {
      messageRefs.current[messageid] = ref;
    },
    []
  );

  // Initialize cursor
  const updateCache = useCallback(
    (lastCursor: number) => {
      const chatCursor = cacheRef.current.chatCursor;
      if (chatCursor === undefined || lastCursor > chatCursor) {
        props.actions.updateCache({
          cache: { ...cacheRef.current, chatCursor: lastCursor },
        });
      }
    },
    [props.actions.updateCache]
  );
  const { setChatCursor } = useChatCursor({
    onCursorChanged: updateCache,
  });
  useEffect(() => {
    if (typeof props.loadCursor === 'number') {
      setChatCursor(props.loadCursor);
    }
  }, [props.loadCursor]);

  // Top anchor
  const loadPreviousMessages = useDebouncedCallback(
    () => {
      if (inView && nowInView.current) {
        return;
      }

      const lastId = lastMessageidRef.current;
      props.actions
        .fetchMessages({
          offset: numMessagesRef.current,
        })
        .then(() => {
          messageRefs.current[lastId]?.current?.scrollIntoView();
        });
    },
    [inView, props.actions.fetchMessages],
    100
  );

  // Bottom anchor
  const bottomRef = useRef<BottomAnchorHandle>(null);
  const atBottom = useCallback(
    () => bottomRef.current?.getInView() ?? false,
    []
  );

  // Messages intersection
  const messagesRef = useRef<HTMLDivElement>(null);
  const messagesEntry = useIntersectionObserver(messagesRef);
  useEffect(() => {
    setInView(messagesEntry?.isIntersecting ?? false);
  }, [messagesEntry?.isIntersecting]);

  // Message event: Play a sound on new message
  useNewMessageSound({ enable: !atBottom(), unread: props.unread });

  // Message event: Scroll to current message if chat window is in view
  const scrollToCurrent = useCallback(() => {
    const cursor = cacheRef.current.chatCursor;
    const element =
      cursor !== undefined
        ? messageRefs.current[cursor]?.current ?? null
        : null;

    if (element) {
      element.scrollIntoView();
    } else {
      bottomRef.current?.scrollIntoView();
    }
  }, []);

  // On chat view: Scroll to the current message
  const resetNowInView = useDebouncedCallback(
    () => {
      nowInView.current = false;
    },
    [],
    200
  );
  useEffect(() => {
    if (inView) {
      scrollToCurrent();
      nowInView.current = true;
      resetNowInView();
    }
  }, [inView]);

  // On new messages: Scroll to the bottom automatically if already at the bottom
  useEffect(() => {
    if (atBottom()) {
      bottomRef.current?.scrollIntoView();
    }
  }, [props.messages, atBottom]);

  // On mount: Fetch recent messages
  useEffect(() => {
    props.actions.fetchMessages();
  }, []);

  // On chat input
  const handleChatInput = useCallback(
    (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const form = event.currentTarget;
      const data = new FormData(form);
      const message = data.get('chat-input');
      if (message) {
        props.actions.sendMessage({ message: message as string }).then(() => {
          setTimeout(() => {
            bottomRef.current?.scrollIntoView();
          }, 200);
        });

        form.reset();
      }
    },
    [props.actions.sendMessage]
  );

  return (
    <div className="chat">
      {props.unread > 0 && !atBottom() && (
        <div className="messages-unread">{props.unread} unread message(s)</div>
      )}
      <TopAnchor onView={loadPreviousMessages} />
      <div className="messages" ref={messagesRef}>
        {numMessagesRef.current === 0 && (
          <div className="messages-empty">No messages yet</div>
        )}
        {map(props.messages, (m) => (
          <Message
            key={m.messageid}
            register={registerMessageRef}
            message={m}
            sessions={props.sessions}
            sessionid={props.sessionid}
            scroll={props.scroll}
            messagesInView={inView}
            markRead={props.actions.markRead}
            setCursor={setChatCursor}
            chatCursor={props.cache.chatCursor}
            atBottom={atBottom}
            unread={props.unread}
          />
        ))}
      </div>
      <BottomAnchor ref={bottomRef} />
      <ChatInput onSubmit={handleChatInput} />
    </div>
  );
}

export default Chat;
