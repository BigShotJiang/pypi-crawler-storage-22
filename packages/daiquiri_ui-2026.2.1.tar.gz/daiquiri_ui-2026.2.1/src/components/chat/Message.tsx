import type { RefObject } from 'react';
import { useCallback, useEffect, useRef } from 'react';

import classNames from 'classnames';
import { each } from 'lodash';
import moment from 'moment';
import { OverlayTrigger, Tooltip } from 'react-bootstrap';
import { useIntersectionObserver } from './useIntersectionObserver';

import type { MessageInfo, ScrollContainer, Sessions } from './types';

export type MessageElement = HTMLDivElement;

interface MessageProps {
  messagesInView: boolean;
  scroll: ScrollContainer;
  message: MessageInfo;
  sessionid: string;
  sessions: Sessions;
  markRead: (messageid: number) => void;
  setCursor: (messageid: number) => void;
  chatCursor?: number;
  unread: number;
  atBottom: () => boolean;
  register: (messageid: number, ref: RefObject<MessageElement>) => void;
}

function Message({ message, ...props }: MessageProps) {
  // Initialize references
  const messageRef = useRef<MessageElement>(null);

  // Helper function: setRead
  const isUnread = !message.read.includes(props.sessionid);
  const setRead = useCallback(() => {
    if (props.messagesInView && isUnread) {
      props.markRead(message.messageid);
      props.setCursor(message.messageid);
    }
  }, [props.messagesInView, isUnread]);

  // Initialize observer
  const entry = useIntersectionObserver(messageRef, {
    threshold: [1],
    root: props.scroll.ref.current,
    once: true,
  });
  useEffect(() => {
    if (entry?.isIntersecting) {
      setRead();
    }
  }, [entry?.isIntersecting, setRead]);

  // Register reference to the parent component
  useEffect(() => {
    props.register(message.messageid, messageRef);
  }, []);

  let read = true;
  const readBy: string[] = [];

  each(props.sessions, (s) => {
    if (!message.read.includes(s.sessionid)) {
      read = false;
    } else if (s.sessionid !== props.sessionid) {
      readBy.push(s.data.username);
    }
  });

  return (
    <div
      className={classNames('message', {
        'message-author': props.sessionid === message.sessionid,
        'message-lastread':
          props.chatCursor === message.messageid &&
          props.unread &&
          !props.atBottom(),
      })}
      ref={messageRef}
    >
      <div className="message-title">
        <span className="message-user">{message.user}</span>
        <span className="message-time">
          {moment.unix(message.timestamp).format('HH:mm')}
        </span>
        <OverlayTrigger
          placement="left"
          overlay={
            <Tooltip>
              {readBy.length === 0 && <p>Not yet read</p>}
              {readBy.length > 0 && (
                <p>
                  Read by {read && 'everyone'}: {readBy.join(', ')}
                </p>
              )}
            </Tooltip>
          }
        >
          <span className="message-read">
            {readBy.length > 0 && !read && (
              <i className="fa fa-check fa-fixed partial" />
            )}
            {read && <i className="fa fa-check fa-fixed read" />}
            {!read && readBy.length === 0 && (
              <i className="fa fa-clock-o fa-fixed waiting" />
            )}
          </span>
        </OverlayTrigger>
      </div>
      <div className="message-body">{message.message}</div>
    </div>
  );
}

export default Message;
