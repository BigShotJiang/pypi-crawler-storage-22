import type { RefObject } from 'react';

export interface ScrollContainer {
  ref: RefObject<Element>;
}

export type Sessions = Record<string, any>[];

export interface MessageInfo {
  messageid: number;
  timestamp: number;
  message: string;
  user: string;
  read: string[];
  sessionid: string;
}
