import { each } from 'lodash';

import StringField from './StringField';

import SimpleSchemaForm from 'components/SimpleSchemaForm';

interface Props {
  schema: Record<string, any>;
  editable?: string[];
  formData: Record<string, any>;
  onChange: (props: { field: string; value: any }) => Promise<any>;
  colWidth?: number;
  staticValues?: Record<string, any>;
  extraComponents?: Record<string, any>;
  className?: string;
  uiSchema?: any;
}

function InlineEditable(props: Props) {
  const {
    editable = [],
    colWidth = 5,
    staticValues = {},
    extraComponents = {},
    className = '',
    onChange,
    formData,
    schema,
    uiSchema,
  } = props;

  function onSave(e: { field: string; value: any }) {
    return onChange(e);
  }

  // Convert null to undefined so rjsf doesnt validate empty fields
  const undefedFormData: Record<string, any> = {};
  each(formData, (fd, key) => {
    undefedFormData[key] = fd === null ? undefined : fd;
  });

  return (
    <SimpleSchemaForm
      colField
      colWidth={colWidth}
      className={`editable-form ${className}`}
      fields={{ StringField }}
      schema={schema}
      formData={undefedFormData}
      uiSchema={uiSchema}
      button={false}
      formContext={{
        editable,
        staticValues,
        extraComponents,
        onSave,
      }}
    />
  );
}

export default InlineEditable;
