import { useRef, useState } from 'react';
import { Form } from 'react-bootstrap';

/**
 * Slider widget which move back to the middle after interaction.
 *
 * It can be used to tune values.
 */
export function RelativeRange(props: {
  value?: number;
  range: number;
  step?: number;
  onChange?: (value: number) => void;
  onIntermediateChange?: (value: number) => void;
  title?: string;
}) {
  const { value, range, step, title } = props;
  const draggingState = useRef<{
    value: number;
    dragging: boolean;
    initialValue?: number;
  }>({
    value: 0,
    dragging: false,
  });

  const [initialValue, setInitialValue] = useState<number | undefined>(
    undefined
  );
  const v = initialValue ?? value;

  return (
    <Form.Range
      min={v === undefined ? v : v - range * 0.5}
      max={v === undefined ? v : v + range * 0.5}
      value={value}
      title={title}
      step={step}
      onChange={(e) => {
        if (initialValue === undefined) {
          return;
        }
        const value = Number.parseFloat(e.target.value);
        draggingState.current.value = value;
        if (draggingState.current.dragging) {
          props.onIntermediateChange?.(value);
        } else {
          props.onChange?.(value);
        }
      }}
      onMouseDown={(e) => {
        setInitialValue(value);
        draggingState.current.dragging = true;
      }}
      onMouseUp={(e) => {
        setInitialValue(undefined);
        draggingState.current.dragging = false;
        props.onChange?.(draggingState.current.value);
      }}
    />
  );
}
