import { useState } from 'react';
import { Button, OverlayTrigger, Popover } from 'react-bootstrap';
import { useDLE } from '@data-client/react';

import Table from 'components/table';
import LogView from '../common/LogView';
import DownloadButton from '../common/DownloadButton';
import H5ViewerButton from '../h5viewer/H5ViewerButton';
import { AutoProcessingAttachmentResource } from '../../resources/AutoProcessingAttachment';

interface RowType {
  filetype: string;
  filepath: string;
  filename: string;
  autoprocprogramattachmentid: number;
  size: number;
}

function FileNameButton({ filename }: { filename: string }) {
  const popover = (
    <Popover id="popover-filename">
      <Popover.Header as="h3">File Name</Popover.Header>
      <Popover.Body>{filename}</Popover.Body>
    </Popover>
  );
  return (
    <OverlayTrigger
      trigger="click"
      placement="left"
      overlay={popover}
      rootClose
    >
      <Button size="sm" className="me-1">
        <i className="fa fa-file" />
      </Button>
    </OverlayTrigger>
  );
}

function ViewCell(cell: string, row: RowType) {
  const Comp = row.filetype === 'Log' ? LogView : DownloadButton;
  return (
    <>
      <FileNameButton filename={`${row.filepath}/${row.filename}`} />
      {(row.filename ?? '').endsWith('.h5') && (
        <H5ViewerButton
          buttonProps={{ className: 'me-1' }}
          autoprocprogramattachmentid={row.autoprocprogramattachmentid}
          fileName={row.filename ?? ''}
        />
      )}

      <Comp
        filename={row.filename}
        url={`/metadata/autoprocs/attachments/${row.autoprocprogramattachmentid}`}
      />
    </>
  );
}

interface Props {
  autoprocprogramid: number;
}

function APPAttachments(props: Props) {
  const { autoprocprogramid } = props;
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);

  const { data: attachments, loading } = useDLE(
    AutoProcessingAttachmentResource.getList,
    autoprocprogramid ? { autoprocprogramid, page, per_page: pageSize } : null
  );
  const columns = [
    { dataField: 'filename', text: 'File' },
    { dataField: 'filetype', text: 'Type' },
    { dataField: 'size', text: 'Size' },
    {
      dataField: 'item',
      text: '',
      formatter: ViewCell,
      classes: 'text-end text-nowrap',
    },
  ];

  const pages = {
    page,
    per_page: pageSize,
    total: attachments.total,
    setPage,
    setPageSize,
  };

  return (
    <Table
      keyField="autoprocprogramattachmentid"
      data={attachments.rows || []}
      columns={columns}
      noDataIndication="No auto processing attachments found"
      pages={pages}
      overlay
      loading={loading}
    />
  );
}

export default APPAttachments;
