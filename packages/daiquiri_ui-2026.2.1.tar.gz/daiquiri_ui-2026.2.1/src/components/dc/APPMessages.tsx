import { useState } from 'react';
import Table from 'components/table';
import { useDLE } from '@data-client/react';
import ExpandableCellComponent from './ExpandableCellComponent';
import { AutoProcessingMessageResource } from '../../resources/AutoProcessingMessage';

interface RowType {
  description: string;
  severity: string;
  timestamp: number;
}

export function ExpandableCell(cell: string, row: RowType) {
  return (
    <ExpandableCellComponent message={cell} description={row.description} />
  );
}

export function SeverityCell(cell: string) {
  const severities: Record<string, JSX.Element> = {
    INFO: (
      <div className="btn btn-sm border border-success">
        <i className="fa fa-info text-success" />
      </div>
    ),
    WARNING: (
      <div className="btn btn-sm border border-warning">
        <i className="fa fa-exclamation-triangle text-warning" />
      </div>
    ),
    ERROR: (
      <div className="btn btn-sm border border-danger">
        <i className="fa fa-exclamation-circle text-danger" />
      </div>
    ),
  };

  return severities[cell];
}

interface Props {
  autoprocprogramid: number;
}

export default function APPMessages(props: Props) {
  const { autoprocprogramid } = props;
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);

  const { data: messages, loading } = useDLE(
    AutoProcessingMessageResource.getList,
    autoprocprogramid ? { autoprocprogramid, page, per_page: pageSize } : null
  );

  const columns = [
    { dataField: 'severity', text: '', formatter: SeverityCell },
    { dataField: 'timestamp', text: 'Time' },
    { dataField: 'message', text: 'Message', formatter: ExpandableCell },
  ];

  const pages = {
    page,
    per_page: pageSize,
    total: messages.total,
    setPage,
    setPageSize,
  };

  return (
    <Table
      keyField="autoprocprogrammessageid"
      data={messages.rows || []}
      columns={columns}
      noDataIndication="No auto processing messages found"
      pages={pages}
      overlay
      loading={loading}
    />
  );
}
