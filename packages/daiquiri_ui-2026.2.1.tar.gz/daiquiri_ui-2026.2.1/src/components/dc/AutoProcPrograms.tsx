import { useState } from 'react';
import { useDLE, useSubscription } from '@data-client/react';

import Tooltip from 'components/common/Tooltip';
import Table from 'components/table';

import ButtonTriggerModalStore from 'connect/layout/ButtonTriggerModalStore';
import APPAttachments from 'connect/dc/APPAttachments';
import APPMessages from 'connect/dc/APPMessages';
import { AutoProcessingResource } from '../../resources/AutoProcessing';
import type { AutoProcProgram } from '../../resources/models/AutoProcProgram';

function ActionCell(cell: number | null) {
  return (
    <>
      <ButtonTriggerModalStore
        id={`autoProcProgramMessages${cell}`}
        button={<i className="fa fa-comments-o" />}
        buttonProps={{
          variant: 'info',
          size: 'sm',
        }}
        title="Messages"
      >
        <APPMessages autoprocprogramid={cell} />
      </ButtonTriggerModalStore>
      <ButtonTriggerModalStore
        id={`autoProcProgramAttachments${cell}`}
        button={<i className="fa fa-files-o" />}
        buttonProps={{
          variant: 'info',
          size: 'sm',
          className: 'ms-1',
        }}
        title="Files"
      >
        <APPAttachments autoprocprogramid={cell} />
      </ButtonTriggerModalStore>
    </>
  );
}

function StatusCell(cell: number | null, row: AutoProcProgram) {
  const statuses = [
    <i className="fa fa-times text-danger" title="Failed" />,
    <i className="fa fa-check text-success" title="Success" />,
  ];

  return (
    <>
      {row.warnings && row.warnings > 0 && (
        <Tooltip tooltip="Processed with warnings">
          <div className="btn btn-sm border border-warning">
            <i className="fa fa-exclamation-triangle text-warning" />
          </div>
        </Tooltip>
      )}
      {row.errors && row.errors > 0 && (
        <Tooltip tooltip="Processed with errors">
          <div className="btn btn-sm border border-danger ms-1">
            <i className="fa fa-exclamation-circle text-danger" />
          </div>
        </Tooltip>
      )}
      {row.automatic === 0 && (
        <Tooltip tooltip="Reprocessing job">
          <div className="btn btn-sm border ms-1">
            <i className="fa fa-refresh" />
          </div>
        </Tooltip>
      )}
      <div className="btn btn-sm border ms-1">
        {cell !== null ? (
          statuses[cell]
        ) : (
          <i className="fa fa-cog fa-spin text-muted" title="Running" />
        )}
      </div>
    </>
  );
}

interface Props {
  datacollectionid: number;
  className?: string;
}

export default function AutoProcPrograms({
  datacollectionid,
  className,
}: Props) {
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);

  const params = {
    datacollectionid,
    page,
    per_page: pageSize,
  };
  const { data: autoprocprograms, loading } = useDLE(
    AutoProcessingResource.getList,
    params
  );
  useSubscription(AutoProcessingResource.getList, params);

  const columns = [
    { dataField: 'programs', text: 'Program' },
    { dataField: 'starttime', text: 'Started' },
    { dataField: 'duration', text: 'Took' },
    { dataField: 'message', text: 'Message' },
    {
      dataField: 'status',
      text: '',
      formatter: StatusCell,
      classes: 'text-center text-nowrap',
    },
    {
      dataField: 'autoprocprogramid',
      text: '',
      formatter: ActionCell,
      classes: 'text-end text-nowrap',
    },
  ];

  const pages = {
    page,
    per_page: pageSize,
    total: autoprocprograms.total,
    setPage,
    setPageSize,
  };
  return (
    <div className={className}>
      <Table
        keyField="autoprocprogramid"
        data={autoprocprograms.rows || []}
        loading={loading}
        columns={columns}
        noDataIndication="No auto processing results found"
        pages={pages}
      />
    </div>
  );
}
