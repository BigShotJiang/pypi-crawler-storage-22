import StackedNameState from 'components/common/StackedNameState';
import type { AutoProcProgram } from '../../resources/models/AutoProcProgram';
import { AutoProcessingResource } from '../../resources/AutoProcessing';
import { useDLE, useSubscription } from '@data-client/react';

function getStyleFromAutoProc(
  autoproc: AutoProcProgram | undefined
): [string, string] {
  if (!autoproc) {
    return ['NONE', 'secondary'];
  }
  if (autoproc.status === null) {
    return ['PROCESSING', 'warning'];
  }
  if (autoproc.status === 0) {
    return ['FAILED', 'danger'];
  }
  if (autoproc.status === 1) {
    return ['DONE', 'success'];
  }
  return ['UNKNOWN', 'fatal'];
}

/**
 * Autoprocessing widget to be integrated inside toolbars
 */
export default function AutoProcessingState(props: {
  className?: string;
  datacollectionid: number | undefined;
  programs: string | undefined;
  name: string;
  description: string;
}) {
  const params =
    props.datacollectionid !== undefined && props.programs !== undefined
      ? {
          datacollectionid: props.datacollectionid,
          programs: props.programs,
          per_page: 1,
          order: 'desc',
        }
      : null;
  const { data: autoprocprograms } = useDLE(
    AutoProcessingResource.getList,
    params
  );
  useSubscription(AutoProcessingResource.getList, params);

  const autoprocprogram = autoprocprograms.rows?.[0];
  const [label, variant] = getStyleFromAutoProc(autoprocprogram);
  return (
    <StackedNameState
      className={props.className}
      name={`${props.name}`}
      state={label}
      stateVariant={variant}
      description={`${props.description}`}
      minWidth={5}
    />
  );
}
