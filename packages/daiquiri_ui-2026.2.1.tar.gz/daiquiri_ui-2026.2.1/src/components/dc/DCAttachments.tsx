import { useState } from 'react';
import { useDLE } from '@data-client/react';

import LogView from 'components/common/LogView';
import DownloadButton from 'components/common/DownloadButton';
import Table from 'components/table';
import { DataCollectionAttachmentResource } from '../../resources/DataCollectionAttachments';

interface RowType {
  datacollectionfileattachmentid: string;
  filename: string;
  filetype: string;
}

function ViewCell(cell: number, row: RowType) {
  const Comp = row.filetype === 'log' ? LogView : DownloadButton;
  return (
    <Comp
      filename={row.filename}
      url={`/metadata/datacollections/attachments/${row.datacollectionfileattachmentid}`}
    />
  );
}

interface Props {
  datacollectionid: number;
  className?: string;
}

export default function DCAttachments(props: Props) {
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(15);

  const { data: attachments, loading } = useDLE(
    DataCollectionAttachmentResource.getList,
    {
      ...(props.datacollectionid
        ? { datacollectionid: props.datacollectionid }
        : null),
      page,
      ...(pageSize ? { per_page: pageSize } : null),
    }
  );

  const columns = [
    { dataField: 'filename', text: 'File' },
    { dataField: 'filetype', text: 'Type' },
    {
      dataField: 'item',
      text: '',
      formatter: ViewCell,
      classes: 'text-end text-nowrap',
    },
  ];

  const pages = {
    page,
    per_page: pageSize,
    total: attachments.total,
    setPage: (page: number) => setPage(page),
    setPageSize: (pageSize: number) => setPageSize(pageSize),
  };

  return (
    <Table
      classes={props.className}
      keyField="datacollectionfileattachmentid"
      data={attachments.rows || []}
      columns={columns}
      noDataIndication="No datacollection attachments found"
      pages={pages}
      overlay
      loading={loading}
    />
  );
}
