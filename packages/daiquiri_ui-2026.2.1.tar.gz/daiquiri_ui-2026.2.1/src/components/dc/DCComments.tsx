import { useController } from '@data-client/react';
import InlineEditable from 'components/common/InlineEditable';
import { DataCollectionResource } from '../../resources/DataCollection';

interface Props {
  schema: { properties: { comments: object } };
  datacollectionid: number;
  comments: string;
}

function DCComments(props: Props) {
  const { properties } = props.schema;
  const schema = {
    comments: properties.comments,
  };
  const { fetch } = useController();

  function onChange(e: { field: string; value: any }) {
    return fetch(
      DataCollectionResource.partialUpdate,
      { datacollectionid: props.datacollectionid },
      // This is a bug in the backend, shouldnt need datacollectionid here too
      { datacollectionid: props.datacollectionid, comments: e.value }
    );
  }

  return (
    <InlineEditable
      className="collapse-margins"
      colWidth={4}
      editable={['comments']}
      schema={schema}
      formData={{
        comments: props.comments,
      }}
      onChange={onChange}
    />
  );
}

export default DCComments;
