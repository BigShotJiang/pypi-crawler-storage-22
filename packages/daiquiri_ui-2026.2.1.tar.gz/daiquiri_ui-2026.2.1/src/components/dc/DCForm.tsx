import { Suspense, useMemo, useState } from 'react';
import type { DataCollection } from '../../resources/models/DataCollection';
import DCItem from './DCItem';
import { useSuspense } from '@data-client/react';
import { DataCollectionResource } from '../../resources/DataCollection';

interface IDCForm {
  dataCollectionId: number;
  dataCollectionGroupId: number;
}

function DCForm(props: IDCForm) {
  const [selectedDcId, setSelectedDcId] = useState(props.dataCollectionId);

  const group = useSuspense(
    DataCollectionResource.getList,
    props.dataCollectionGroupId
      ? {
          datacollectiongroupid: props.dataCollectionGroupId,
          per_page: 999,
        }
      : null
  );

  const dataCollection = useMemo(() => {
    if (!group.rows) return null;
    const l = group.rows.filter((d) => d.datacollectionid === selectedDcId);
    if (l.length === 0) {
      return null;
    }
    return l[0];
  }, [selectedDcId, group.rows]);

  function showDataCollection(dc: DataCollection) {
    setSelectedDcId(dc.datacollectionid);
  }

  const patchedDataCollection = useMemo(() => {
    // When the request is "ungroup", the "datacollections" field is wrong, but we can patch it
    if (!dataCollection) {
      return null;
    }
    return {
      ...dataCollection,
      datacollections: group?.total ?? 1,
    };
  }, [dataCollection]);

  return (
    <>
      {patchedDataCollection && (
        <DCItem
          dataCollection={patchedDataCollection}
          showDataCollection={showDataCollection}
        />
      )}
    </>
  );
}

export default function DCWrap(props: IDCForm) {
  return (
    <Suspense fallback="Loading...">
      <DCForm {...props} />
    </Suspense>
  );
}
