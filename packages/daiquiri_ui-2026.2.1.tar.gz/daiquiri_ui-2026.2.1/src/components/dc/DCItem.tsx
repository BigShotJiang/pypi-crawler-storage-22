import { Suspense } from 'react';
import { getDCView } from './utils';
import type { DataCollection } from '../../resources/models/DataCollection';

export default function DCItem(props: {
  dataCollection: DataCollection;
  showDataCollection?: (dc: DataCollection) => void;
}) {
  const { dataCollection } = props;
  const DCView = getDCView(dataCollection.experimenttype ?? 'experiment');

  return (
    <Suspense fallback={<p>Loading...</p>}>
      <DCView
        dataCollection={dataCollection}
        showDataCollection={props.showDataCollection}
      />
    </Suspense>
  );
}
