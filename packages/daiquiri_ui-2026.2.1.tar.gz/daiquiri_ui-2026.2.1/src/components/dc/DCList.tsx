import { useState } from 'react';
import { Button, ButtonGroup } from 'react-bootstrap';
import { Formatting } from '@esrf/daiquiri-lib';

import Table from 'components/table';
import SelectableTable from 'components/table/Selectable';
import ButtonTriggerModalStore from 'connect/layout/ButtonTriggerModalStore';

import StatusBadge from 'components/dc/StatusBadge';
import MapFromScalar from 'connect/dc/MapFromScalar';
import RegenerateMapsButton from 'connect/2dview/RegenerateMapsButton';
import type {
  PagedType,
  SelectableActions,
  TableColumn,
} from 'components/table/models';
import type { DataCollection } from '../../resources/models/DataCollection';
import DCDialogButton from './DCDialogButton';
import { useDLE } from '@data-client/react';
import { DataCollectionResource } from '../../resources/DataCollection';

function DCStatusCell(cell: string) {
  return <StatusBadge status={cell} />;
}

function DCItemButton(
  cell: string,
  row: DataCollection,
  rowIndex: number,
  formatExtraData: {
    namespace: string;
    createScalarMap: boolean;
    showViewButton?: boolean;
  }
) {
  return (
    <>
      {formatExtraData.createScalarMap && (
        <ButtonTriggerModalStore
          id={`createScalarMap${row.datacollectionid}${formatExtraData.namespace}`}
          button={<i className="fa fa-map" />}
          buttonProps={{
            size: 'sm',
            className: 'me-1',
          }}
          title="Create Map from Scalar"
        >
          <MapFromScalar
            datacollectionid={row.datacollectionid}
            datacollectiongroupid={row.datacollectiongroupid}
            scanid={row.datacollectionnumber}
            providers={{
              scans: { list: { namespace: 'mfs' }, data: { namespace: 'mfs' } },
            }}
          />
        </ButtonTriggerModalStore>
      )}
      {formatExtraData.createScalarMap && (
        <RegenerateMapsButton
          subsampleid={row.subsampleid ?? 0}
          datacollectiongroupid={row.datacollectiongroupid}
          buttonProps={{
            size: 'sm',
            className: 'me-1',
          }}
        />
      )}
      {formatExtraData.showViewButton && (
        <DCDialogButton dataCollection={row} />
      )}
    </>
  );
}

function DurationCell(cell: string) {
  return cell ? Formatting.toHoursMins(Number.parseFloat(cell)) : '';
}

function SampleCell(cell: string, row: DataCollection) {
  if (!row) {
    return '';
  }

  if (row.subsampleid) {
    return (
      <span>
        {row.sampleid}-{row.subsampleid}
        {row.sample && (
          <>
            <br />[{row.sample}]
          </>
        )}
      </span>
    );
  }

  return <span>{row.sampleid}</span>;
}

interface Actions extends Partial<SelectableActions> {}

interface Props extends PagedType {
  actions?: Actions;
  /** Filters */
  datacollectiongroupid?: number;
  subsampleid?: number;
  sampleid?: number;
  className?: string;
  /** Show CreateScalarMap button */
  createScalarMap?: boolean;
  /** Show data collection count (for groups) */
  dccount?: boolean;
  /** Show filters */
  filter?: boolean;
  /** Show sample name */
  sample?: boolean;
  /** Show control system scan id */
  scan?: boolean;
  params?: {
    /** Filter by status */
    status: string;
    /** Allow ungrouping of data collection groups */
    ungroup: number;
  };
  columns?: TableColumn[];
  selected?: number[];
  /** Whether to allow selection of a datacollection */
  selectable?: boolean;
  showFollow?: boolean;
  showViewButton?: boolean;
}

export default function DCList(props: Props) {
  const {
    createScalarMap = false,
    dccount = true,
    scan = true,
    actions = {},
    columns: inputColumns = [],
    showFollow = true,
    showViewButton = true,
  } = props;

  const [showStatus, setShowStatus] = useState('');
  const [showChild, setShowChild] = useState(false);
  const [page, setPage] = useState<number>(props.page || 1);
  const [pageSize, setPageSize] = useState<number>(props.per_page);
  const [params, setParams] = useState<Record<string, any>>({});

  const {
    data: datacollections,
    loading,
    error,
  } = useDLE(DataCollectionResource.getList, {
    ...(props.datacollectiongroupid
      ? { datacollectiongroupid: props.datacollectiongroupid }
      : null),
    ...(props.sampleid ? { sampleid: props.sampleid } : null),
    ...(props.subsampleid ? { subsampleid: props.subsampleid } : null),
    ...(showStatus !== '' ? { status: showStatus } : null),
    ...(showChild ? { ungroup: 1 } : null),
    ...params,
    page,
    ...(pageSize ? { per_page: pageSize } : null),
  });

  const columns = [
    { dataField: 'datacollectionid', text: 'Id' },
    { dataField: 'starttime', text: 'Start', sort: true },
    {
      dataField: 'duration',
      text: 'Took',
      formatter: DurationCell,
      sort: true,
    },
    {
      dataField: 'runstatus',
      text: 'Status',
      formatter: DCStatusCell,
      sort: true,
    },
    {
      dataField: 'experimenttype',
      text: 'Type',
      sort: true,
      classes: 'text-break',
    },
    ...inputColumns,
    {
      dataField: 'item',
      text: '',
      formatter: DCItemButton,
      classes: 'text-end text-nowrap',
      formatExtraData: {
        createScalarMap,
        showViewButton,
      },
    },
  ];

  if (dccount) {
    columns.splice(4, 0, { dataField: 'datacollections', text: '#DC' });
  }

  if (scan) {
    columns.splice(4, 0, { dataField: 'datacollectionnumber', text: 'Scan' });
  }

  if (props.sample) {
    columns.splice(1, 0, {
      dataField: 'sampledetails',
      text: 'Sample',
      formatter: SampleCell,
    });
  }

  const pages = props.pages
    ? {
        page,
        per_page: pageSize,
        total: datacollections.total,
        setPage: (page: number) => setPage(page),
        setPageSize: (pageSize: number) => setPageSize(pageSize),
        setParams: (params: Record<string, any>) => setParams(params),
      }
    : undefined;

  const { addSelection, removeSelection, resetSelection } = actions;
  const selectableActions = addSelection &&
    removeSelection &&
    resetSelection && {
      addSelection,
      removeSelection,
      resetSelection,
    };

  const tableProps = {
    keyField: 'datacollectionid',
    data: datacollections.rows || [],
    columns,
    noDataIndication: 'No data collections',
    pages,
    loading,
    overlay: true,
    // page,
  };

  return (
    <div className={`dc-list ${props.className ?? ''}`}>
      <div className="filter">
        {props.selectable && showFollow && (
          <Button
            className="mb-1 me-2"
            size="sm"
            onClick={() => resetSelection?.()}
            disabled={props.selected === null}
          >
            Follow
          </Button>
        )}

        {props.filter && (
          <>
            <ButtonGroup size="sm" className="ms-1 mb-1">
              <Button
                variant={showStatus === 'Successful' ? 'primary' : 'secondary'}
                onClick={() =>
                  setShowStatus((s) => (s === 'Successful' ? '' : 'Successful'))
                }
                title="Only display successful collections"
              >
                Success
              </Button>
              <Button
                variant={showStatus === 'Failed' ? 'primary' : 'secondary'}
                onClick={() =>
                  setShowStatus((s) => (s === 'Failed' ? '' : 'Failed'))
                }
                title="Only display failed collections"
              >
                Failed
              </Button>
            </ButtonGroup>
            <Button
              variant={showChild ? 'primary' : 'secondary'}
              className="ms-1 mb-1"
              size="sm"
              onClick={() => setShowChild((s) => !s)}
              title="Display child data collections"
            >
              Children
            </Button>
          </>
        )}
      </div>
      {props.selectable && selectableActions && (
        <SelectableTable
          selectedItems={props.selected}
          actions={selectableActions}
          {...tableProps}
        />
      )}
      {!props.selectable && <Table {...tableProps} />}
    </div>
  );
}
