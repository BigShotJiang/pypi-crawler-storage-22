import {
  Suspense,
  useCallback,
  useEffect,
  useRef,
  useState,
  useMemo,
} from 'react';
import { useSuspense } from '@data-client/react';

import config from 'config/config';
import { MapResource } from 'resources/Map';
import XHRImage from 'helpers/XHRImage';
import Holder from 'helpers/Holder';

interface Props {
  mapid: number;
  maproiid?: number;
  datacollectiongroupid: number;
}

function Map({ mapid, maproiid, datacollectiongroupid }: Props) {
  const [progress, setProgress] = useState(0);
  const imgRef = useRef<HTMLImageElement>(null);
  const maps = useSuspense(
    MapResource.getList,
    maproiid
      ? {
          datacollectiongroupid,
          maproiid,
        }
      : null
  );
  const xhr = useMemo(() => new XHRImage(), []);
  const onLoad = useCallback(() => {
    setProgress(100);
    if (imgRef.current) {
      imgRef.current.src = xhr.src;
    }
  }, [setProgress]);
  const onProgress = useCallback(
    (progress: number) => setProgress(progress),
    [setProgress]
  );
  xhr.onload = onLoad;
  xhr.onprogress = onProgress;

  useEffect(() => {
    if (!maps.rows) return;
    if (mapid < maps.rows.length) {
      const map = maps.rows[mapid];
      xhr.load(config.baseUrl + map.url);
    }
  }, [mapid, maproiid, maps]);

  return (
    <div
      className="map"
      style={{
        flex: 1,
      }}
    >
      {progress === 100 ? (
        <img
          ref={imgRef}
          alt="map"
          style={{ width: '100%', imageRendering: 'pixelated' }}
        />
      ) : (
        <figure>
          <Holder width="100p" height="250" text="No snapshot" />
          {progress > 0 && <figcaption>Loading {progress}%</figcaption>}
        </figure>
      )}
    </div>
  );
}

export default function MapMain(props: Props) {
  return (
    <Suspense fallback="Loading...">
      <Map {...props} />
    </Suspense>
  );
}
