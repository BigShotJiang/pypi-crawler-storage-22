import type { RefObject } from 'react';
import { useRef, useState, useEffect } from 'react';
import { map, filter } from 'lodash';
import { Container, Form, Row, Col, Button, Alert } from 'react-bootstrap';
import { Typeahead } from 'react-bootstrap-typeahead';
import { useDLE } from '@data-client/react';
import { MapResource } from '../../resources/Map';
import type { XRFMap } from '../../resources/models/XRFMap';

interface Props {
  datacollectionid: number;
  datacollectiongroupid: number;
  scanid: number;
  actions: {
    fetchScan: (scanid: number) => void;
    fetchScanData: (props: { scanid: number }) => void;
    addToast?: (props: { type: string; title: string; text: string }) => void;
    createMap: (props: {
      datacollectionid: number;
      scalars: string[];
    }) => Promise<void>;
    updateMapSettings: (props: Record<string, any>) => Promise<void>;
  };
  error?: string;
  scanError?: string;
  fetching: boolean;
  fetched: boolean;
  mapSettings: Record<string, any>;
  data?: Record<
    number,
    {
      axes: {
        ys: {
          scalars: string[];
        };
      };
    }
  >;
  scan: Record<string, any>;
  creatingAdditional?: boolean;
}

export default function MapFromScalar(props: Props) {
  const { scan, datacollectiongroupid } = props;
  // @ts-expect-error
  const typeaheadRef: RefObject<Typeahead> = useRef(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [pendingAutoList, setPendingAutoList] = useState<boolean>(false);

  const { data: maps, loading } = useDLE(MapResource.getList, {
    datacollectiongroupid,
  });

  useEffect(() => {
    if (props.scanid) {
      props.actions?.fetchScan(props.scanid);
    }
  }, [props.scanid]);

  useEffect(() => {
    if (scan?.group) {
      props.actions.fetchScanData({
        scanid: scan.children[0].scanid,
      });
    } else {
      props.actions.fetchScanData({ scanid: props.scanid });
    }
  }, [scan]);

  function createMap() {
    props.actions
      .createMap({
        datacollectionid: props.datacollectionid,
        scalars: selected,
      })
      .catch((error) => {
        props.actions.addToast?.({
          type: 'error',
          title: 'Could not create scalar map',
          text: error.message,
        });
      })
      .then(() => {
        typeaheadRef.current?.clear();
      });
  }

  function addToAutoScalarMaps() {
    const newScalarMaps = [...props.mapSettings.scalar_maps];
    selected.forEach((selectedScalarName) => {
      if (!newScalarMaps.includes(selectedScalarName)) {
        newScalarMaps.push(selectedScalarName);
      }
    });

    setPendingAutoList(true);
    props.actions.updateMapSettings({ scalar_maps: newScalarMaps }).then(() => {
      setTimeout(() => {
        setPendingAutoList(false);
      }, 500);
    });
  }

  function setSelection(newSelected: string[]) {
    setSelected(newSelected);
  }

  const created = map(
    filter(
      maps.rows,
      (m) => (m.datacollectionid ?? 0) === props.datacollectionid && m.scalar
    ) as XRFMap[],
    (m) => m.scalar
  );

  const scanid = props.scan?.group
    ? props.scan.children[0].scanid
    : props.scanid;
  const data = props.data?.[scanid];
  const opts = data?.axes
    ? data.axes.ys.scalars.filter((s) => !created.includes(s))
    : [];

  return (
    <Container className="mt-3">
      {props.scan?.group && (
        <Alert variant="success">Scan is a group, loading child scalars</Alert>
      )}

      {!props.scanid && <Alert variant="warning">No scan id available</Alert>}

      {(props.error || props.scanError) && (
        <Alert variant="warning">
          Scan number {props.scanid} is no longer available
        </Alert>
      )}

      {props.fetching ||
        (loading && (
          <Alert variant="info">
            <i className="fa fa-spin fa-spinner me-1" />
            Fetching available scalars
          </Alert>
        ))}

      {!(props.error || props.scanError) &&
        props.fetched &&
        !props.fetching &&
        props.scanid && (
          <Form>
            <Form.Group as={Row} controlId="scalar-selection" className="mb-2">
              <Form.Label column sm={3}>
                Scalar
              </Form.Label>
              <Col>
                <Typeahead
                  autoFocus
                  ref={typeaheadRef}
                  id="scalar-selection"
                  // @ts-expect-error
                  inputProps={{ 'data-testid': 'scalar-selection' }}
                  multiple
                  onChange={(selection) => setSelection(selection as string[])}
                  options={[...opts]}
                />
              </Col>
            </Form.Group>
            <Button
              onClick={() => createMap()}
              disabled={props.creatingAdditional || selected.length === 0}
            >
              {!props.creatingAdditional && <>Create Map</>}

              {props.creatingAdditional && (
                <>
                  Creating Map <i className="fa fa-spin fa-spinner" />
                </>
              )}
            </Button>
            <Button
              onClick={() => addToAutoScalarMaps()}
              className="ms-1"
              disabled={pendingAutoList || selected.length === 0}
            >
              {!pendingAutoList && <>Add to Auto List</>}

              {pendingAutoList && (
                <>
                  Adding to Auto List <i className="fa fa-spin fa-spinner" />
                </>
              )}
            </Button>
          </Form>
        )}
    </Container>
  );
}
