import { useSuspense } from '@data-client/react';
import { range } from 'lodash';
import { useState, useMemo, useEffect, Suspense } from 'react';
import { Form } from 'react-bootstrap';

import PlotEnhancer from 'components/PlotEnhancer';
import RemountOnResize from 'components/utils/RemountOnResize';
import { MapSumResource } from 'resources/MapSum';
import { MapResource } from 'resources/Map';
import type { XRFMap as MapType } from 'resources/models/XRFMap';

function getROIName(map: MapType) {
  return map.scalar || `${map.element}-${map.edge}`;
}

interface Props {
  datacollectiongroupid: number;
  x?: number;
  y?: number;
  actions?: {
    setMapROIId: (maproidid: number) => void;
    setMapId: (mapid: number) => void;
  };
}

function MapSum({ datacollectiongroupid, x, y, actions }: Props) {
  const maps = useSuspense(MapResource.getList, {
    datacollectiongroupid,
  });
  const mapROIs = useMemo(
    () =>
      maps?.rows
        .map((map) => ({
          roiid: map.maproiid,
          roiname: getROIName(map),
        }))
        .filter(
          (obj, i, arr) =>
            arr.findIndex((obj2) => obj2.roiid === obj.roiid) === i
        ),
    [maps]
  );
  const [selectedMapROI, setSelectedMapROI] = useState<number>(
    maps.rows?.[0]?.maproiid ?? 0
  );
  const mapSum = useSuspense(
    MapSumResource,
    selectedMapROI
      ? {
          datacollectiongroupid,
          maproiid: selectedMapROI,
        }
      : null
  );

  useEffect(() => {
    actions?.setMapROIId(selectedMapROI);
  }, [selectedMapROI]);

  useEffect(() => {
    actions?.setMapROIId(selectedMapROI);
  }, [selectedMapROI]);

  if (!mapSum) {
    return (
      <>
        <h5>{x !== undefined && y !== undefined ? 'Pixel' : 'Map Sum'}</h5>
        <p>No maps available</p>
      </>
    );
  }

  return (
    <>
      <h5>{x !== undefined && y !== undefined ? 'Pixel' : 'Map Sum'}</h5>
      <Form.Control
        as="select"
        onChange={(e) => setSelectedMapROI(Number.parseInt(e.target.value))}
        value={selectedMapROI}
      >
        {mapROIs.map((maproi) => (
          <option key={maproi.roiid} value={maproi.roiid}>
            {maproi.roiname}
          </option>
        ))}
      </Form.Control>
      <div className="sqi-plot">
        <RemountOnResize>
          <PlotEnhancer
            data={[
              {
                x: range(mapSum.values?.length ?? 0),
                y: mapSum.values,
                type: 'scatter',
              },
            ]}
            layout={{
              xaxis: { title: 'Map' },
              yaxis: {
                title: 'Count',
              },
            }}
            onClick={(e) => {
              if (e.points.length <= 0) {
                return;
              }
              const point = e.points[0].pointNumber;
              actions?.setMapId(point);
            }}
          />
        </RemountOnResize>
      </div>
    </>
  );
}

export default function MapSumMain(props: Props) {
  return (
    <Suspense fallback="Loading...">
      <MapSum {...props} />
    </Suspense>
  );
}
