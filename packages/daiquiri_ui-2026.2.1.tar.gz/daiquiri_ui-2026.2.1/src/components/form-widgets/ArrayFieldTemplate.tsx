import { Button, Container, Row, Col } from 'react-bootstrap';
import type { ArrayFieldTemplateProps } from '@rjsf/core';
import type { IdSchema } from '@rjsf/core';

interface ArrayFieldDescriptionProps {
  DescriptionField: any;
  idSchema: IdSchema;
  description: string;
}

function ArrayFieldDescription({
  DescriptionField,
  idSchema,
  description,
}: ArrayFieldDescriptionProps) {
  if (!description) {
    return null;
  }

  const id = `${idSchema.$id}__description`;
  return <DescriptionField id={id} description={description} />;
}

function DefaultArrayItem(props: any) {
  return (
    <Row key={props.key}>
      <Col sm={10}>{props.children}</Col>
      {props.hasToolbar && (
        <>
          {props.hasRemove && (
            <Col sm={2} className="text-end p-0 d-grid">
              <Button
                variant="danger"
                disabled={props.disabled || props.readonly}
                onClick={props.onDropIndexClick(props.index)}
                className="array-item-remove btn-block"
                style={{ border: '0' }}
              >
                <i className="fa fa-times" />
              </Button>
            </Col>
          )}
        </>
      )}
    </Row>
  );
}

function ArrayFieldTemplate(props: ArrayFieldTemplateProps) {
  return (
    <div className="nested-list" style={{ flex: 1 }}>
      <div>{props.title}</div>
      <fieldset id={props.idSchema.$id}>
        {(props.uiSchema['ui:description'] || props.schema.description) && (
          <ArrayFieldDescription
            key={`array-field-description-${props.idSchema.$id}`}
            DescriptionField={props.DescriptionField}
            idSchema={props.idSchema}
            description={
              props.uiSchema['ui:description'] || props.schema.description
            }
          />
        )}
        <Container>{props?.items.map((p) => DefaultArrayItem(p))}</Container>
        {props.canAdd && (
          <div className="d-grid">
            <Button
              variant="info"
              size="sm"
              className="array-item-add"
              onClick={props.onAddClick}
              disabled={props.disabled || props.readonly}
            >
              Add
            </Button>
          </div>
        )}
      </fieldset>
    </div>
  );
}

export default ArrayFieldTemplate;
