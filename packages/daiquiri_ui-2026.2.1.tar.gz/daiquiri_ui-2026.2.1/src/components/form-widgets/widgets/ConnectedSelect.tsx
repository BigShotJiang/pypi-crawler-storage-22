import type { RefObject } from 'react';
import { createRef, Component } from 'react';
import { Form } from 'react-bootstrap';
import { map } from 'lodash';
import type { Widget, WidgetProps } from '@rjsf/core';
import { useDLE } from '@data-client/react';

import { ComponentResource } from '../../../resources/Component';
import { SampleResource } from '../../../resources/Sample';

type Resources = 'components' | 'samples';

export function withDataClient(WrappedComponent: typeof Select) {
  return (props: any) => {
    const resources = {
      components: ComponentResource,
      samples: SampleResource,
    };
    const selector: Resources = props.options.selector;

    const options = useDLE(resources[selector].getList);
    const selectOptions = options.data?.rows?.map((option) => ({
      // @ts-expect-error
      key: option[props.options.key],
      // @ts-expect-error
      value: option[props.options.value],
    }));

    return <WrappedComponent {...props} selectOptions={selectOptions} />;
  };
}

interface Props extends WidgetProps {
  options: {
    value: string;
    key: string;
    selector: Resources;
  };
  selectOptions?: Record<string, any>;
}

class Select extends Component<Props> {
  private readonly ref: RefObject<HTMLSelectElement>;
  public constructor(props: Props) {
    super(props);
    this.ref = createRef<HTMLSelectElement>();
  }

  public setValue() {
    setTimeout(() => {
      if (this.ref.current) this.props.onChange(this.ref.current.value);
    }, 1000);
  }

  public componentDidUpdate(prevProps: Props) {
    if (this.props.value !== prevProps.value) {
      if (this.props.value === undefined) {
        this.setValue();
      }
    }
  }

  public componentDidMount() {
    this.setValue();
  }

  public render() {
    const {
      id,
      value,
      disabled,
      readonly,
      autofocus,
      onBlur,
      onFocus,
      onChange,
      selectOptions,
    } = this.props;

    return (
      <Form.Control
        ref={this.ref}
        as="select"
        className="connected-select"
        value={value}
        id={id}
        disabled={disabled || readonly}
        autoFocus={autofocus}
        onChange={(event: any) => onChange(event.target.value)}
        onBlur={onBlur && ((event: any) => onBlur(id, event.target.value))}
        onFocus={onFocus && ((event: any) => onFocus(id, event.target.value))}
      >
        {map(selectOptions, (c) => (
          <option key={c.value} value={c.value}>
            {c.key}
          </option>
        ))}
      </Form.Control>
    );
  }
}

const ConnSelect = withDataClient(Select);

// rjsf does not like connected component as a custom widget
function ConnectedSelect(props: Props) {
  return <ConnSelect {...props} />;
}

export default ConnectedSelect as Widget;
