import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert } from 'react-bootstrap';
import axios from 'axios';
import RestService from 'services/RestService';

import ZoomPanCanvas from 'components/utils/ZoomPanCanvas';
import RemountOnResize from 'components/utils/RemountOnResize';

export interface MarkingType {
  /** Marking x position */
  x: number;
  /** Marking y position */
  y: number;
}

export interface OptionsBPMVideoStream {
  /** Url to the bpm video image  */
  url: string;
  /** Refresh interval (default 500ms) */
  interval?: number;
  /** If proxying the url, add the authentication token */
  proxy?: boolean;
  /** A list of markings to draw on the video */
  markings?: MarkingType[];
  /** A title for this camera */
  title?: string;
}

export default function BPMVideoStream(props: OptionsBPMVideoStream) {
  const [zoom, setZoom] = useState<number>(0);
  const [error, setError] = useState<string>('');
  const [image, setImage] = useState<string>('');
  const refreshTask = useRef<NodeJS.Timeout>();

  const ax = axios.create({
    ...(props.proxy ? RestService.getOptions() : null),
  });

  const loadImage = useCallback(() => {
    ax.get(props.url)
      .then((res) => {
        setImage(res.data.jpegData);
        if (refreshTask.current) clearTimeout(refreshTask.current);
        refreshTask.current = setTimeout(() => {
          loadImage();
        }, props.interval ?? 500);
      })
      .catch((error) => {
        console.log('Couldnt load image');
        setError(error.response.data?.error);
      });
  }, [props.url, setImage]);

  useEffect(() => {
    loadImage();

    return () => {
      if (refreshTask.current) clearTimeout(refreshTask.current);
    };
  }, [loadImage]);

  return (
    <div className="plot2d-container">
      <div>
        {props.title && <h3>{props.title}</h3>}
        <div className="message" />
        <div className="zoom">
          Zoom:
          {(zoom * 100).toFixed(0)}%
        </div>
      </div>
      <RemountOnResize>
        <ZoomPanCanvas
          className="scanimage"
          url={image && `data:image/jpg;base64,${image}`}
          onZoomChange={(zoom: number) => setZoom(zoom)}
          onLoadProgress={(progress: number) => {}}
          onError={(status: unknown, event: unknown, message: string) =>
            setError(message)
          }
          maxZoom={4}
          markings={props.markings}
        >
          <div className="plot-error">
            {error && (
              <Alert variant="danger">Error loading image: {error}</Alert>
            )}
          </div>
        </ZoomPanCanvas>
      </RemountOnResize>
    </div>
  );
}
