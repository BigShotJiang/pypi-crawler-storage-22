import React from 'react';
import { Button, ButtonGroup } from 'react-bootstrap';
import { AutoscaleMode } from '../colormap';

export function AutoScaleButton(props: {
  autoScale: AutoscaleMode;
  setAutoScale: (mode: AutoscaleMode) => void;
}) {
  const { autoScale, setAutoScale } = props;
  return (
    <ButtonGroup>
      <Button
        variant={autoScale === AutoscaleMode.None ? 'primary' : 'secondary'}
        onClick={() => {
          setAutoScale(AutoscaleMode.None);
        }}
      >
        None
      </Button>
      <Button
        variant={autoScale === AutoscaleMode.Minmax ? 'primary' : 'secondary'}
        onClick={() => {
          setAutoScale(AutoscaleMode.Minmax);
        }}
      >
        Min/max
      </Button>
      <Button
        variant={autoScale === AutoscaleMode.StdDev3 ? 'primary' : 'secondary'}
        onClick={() => {
          setAutoScale(AutoscaleMode.StdDev3);
        }}
      >
        3×std
      </Button>
    </ButtonGroup>
  );
}
