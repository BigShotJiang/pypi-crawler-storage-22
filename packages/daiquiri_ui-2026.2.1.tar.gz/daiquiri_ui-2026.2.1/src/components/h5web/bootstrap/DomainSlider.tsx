import type { ArrayHistogram, ArrayStatistics } from '../colormap';
import type { Dispatch, SetStateAction } from 'react';
import { useMemo } from 'react';
import {
  DomainSlider as H5webDomainSlider,
  getSafeDomain,
  getVisDomain,
  ScaleType,
  useDomain,
  useVisDomain,
  useSafeDomain,
} from '@h5web/lib';
import type {
  CustomDomain,
  Domain,
  VisScaleType,
  ColorMap,
  ColorScaleType,
} from '@h5web/lib';
import { useEffect, useState } from 'react';

import { useStrippedHistogram } from '../hooks';
import { toScaleType } from '../utils';
import type { Histogram } from 'services/tiling/fetch';

const DEFAULT_DOMAIN: Domain = [0.1, 1];

function DomainWidget(props: {
  dataDomain: Domain;
  customDomain: CustomDomain;
  scaleType: ColorScaleType;
  disabled?: boolean;
  onCustomDomainChange: (domain: CustomDomain) => void;
}) {
  const { dataDomain, customDomain, scaleType, disabled = false } = props;
  const { onCustomDomainChange } = props;

  const visDomain = useVisDomain(customDomain, dataDomain);
  const [safeDomain, errors] = useSafeDomain(visDomain, dataDomain, scaleType);

  const [sliderDomain, setSliderDomain] = useState(visDomain);
  useEffect(() => {
    setSliderDomain(visDomain);
  }, [visDomain]);

  const isAutoMin = customDomain[0] === null;
  const isAutoMax = customDomain[1] === null;

  return (
    <div
      style={{
        width: '1fr',
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '1em',
      }}
    >
      <div
        style={{
          display: 'flex',
          flex: 1,
          padding: '0 0.375rem',
          marginRight: '-0.375rem',
        }}
      >
        <H5webDomainSlider
          value={sliderDomain}
          safeVisDomain={safeDomain}
          dataDomain={dataDomain}
          scaleType={scaleType}
          errors={errors}
          isAutoMin={isAutoMin}
          isAutoMax={isAutoMax}
          disabled={disabled}
          onChange={(newValue) => {
            setSliderDomain(newValue);
          }}
          onAfterChange={(hasMinChanged, hasMaxChanged) => {
            onCustomDomainChange([
              hasMinChanged ? sliderDomain[0] : customDomain[0],
              hasMaxChanged ? sliderDomain[1] : customDomain[1],
            ]);
          }}
        />
      </div>
    </div>
  );
}

interface Props {
  histogram: Histogram;
  scaleType: VisScaleType;
  onDomainChange: (domain: Domain) => void;
  domain?: Domain;
  dataMin?: number;
  dataMax?: number;
}

function HistogramDomainSlider2(props: Props) {
  const { histogram, scaleType, onDomainChange, domain = [0, 1] } = props;
  const strippedHistogram = useStrippedHistogram(histogram);
  const { bins } = strippedHistogram;

  const scale = toScaleType(scaleType);

  const [customDomain, setCustomDomain] = useState<CustomDomain>([null, null]);
  const histoDomain = useDomain(bins, scale);
  const dataDomain = useMemo<Domain>(() => {
    if (histoDomain) {
      return histoDomain;
    }
    if (props.dataMin !== undefined && props.dataMax !== undefined) {
      if (scale === ScaleType.Log) {
        if (props.dataMin <= 0 || props.dataMax <= 0) {
          return DEFAULT_DOMAIN;
        }
      }
      return [props.dataMin, props.dataMax];
    }
    return DEFAULT_DOMAIN;
  }, [histoDomain, props.dataMin, props.dataMax, scale]);

  useEffect(() => {
    setCustomDomain(domain);
  }, [domain[0], domain[1]]);

  // TODO add input for gamma factor
  return (
    <DomainWidget
      dataDomain={dataDomain}
      customDomain={customDomain}
      scaleType={scale}
      onCustomDomainChange={(customDomain) => {
        const visDomain = getVisDomain(customDomain, dataDomain);
        const [safeDomain] = getSafeDomain(visDomain, dataDomain, scale);
        onDomainChange(safeDomain);
      }}
    />
  );
}

const EMPTY_ARRAY = new Float64Array([]);

export default function DomainSlider(props: {
  histogram?: ArrayHistogram;
  statistics?: ArrayStatistics;
  disabled?: boolean;
  setAutoscale: Dispatch<SetStateAction<boolean>>;
  autoscale: boolean;
  scaleType: VisScaleType;
  setScaleDomain: Dispatch<SetStateAction<[number, number]>>;
  scaleDomain: [number, number];
  colorMap?: ColorMap;
  invertColorMap?: boolean;
}) {
  // FIXME: disabled state not yet supported by the sub component
  return (
    <HistogramDomainSlider2
      histogram={{
        values: props.histogram?.values.data ?? EMPTY_ARRAY,
        bins: props.histogram?.bins.data ?? EMPTY_ARRAY,
        colorMap: props.colorMap,
        invertColorMap: props.invertColorMap,
      }}
      dataMin={props.statistics?.min ?? undefined}
      dataMax={props.statistics?.max ?? undefined}
      scaleType={props.scaleType}
      domain={props.scaleDomain}
      onDomainChange={(domain) => {
        if (props.autoscale) {
          props.setAutoscale(false);
        }
        props.setScaleDomain(domain);
      }}
    />
  );
}
