import type { ArrayHistogram, ArrayStatistics } from '../colormap';
import type { Dispatch, SetStateAction } from 'react';
import { useMemo } from 'react';
import {
  getSafeDomain,
  getVisDomain,
  Histogram,
  ScaleType,
  useDomain,
} from '@h5web/lib';
import type { CustomDomain, Domain, VisScaleType, ColorMap } from '@h5web/lib';
import { useEffect, useState } from 'react';

import { useStrippedHistogram } from '../hooks';
import { toScaleType } from '../utils';
import type { Histogram as HistogramType } from 'services/tiling/fetch';

const DEFAULT_DOMAIN: Domain = [0.1, 1];

interface Props {
  histogram: HistogramType;
  scaleType: VisScaleType;
  onDomainChange: (domain: Domain) => void;
  domain?: Domain;
  dataMin?: number;
  dataMax?: number;
  colorMap?: ColorMap;
  invertColorMap?: boolean;
}

function HistogramDomainSlider2(props: Props) {
  const { histogram, scaleType, onDomainChange, domain = [0, 1] } = props;
  const strippedHistogram = useStrippedHistogram(histogram);
  const { bins, values } = strippedHistogram;

  const scale = toScaleType(scaleType);

  const histoDomain = useDomain(bins, scale);
  const dataDomain = useMemo<Domain>(() => {
    if (histoDomain) {
      return histoDomain;
    }
    if (props.dataMin !== undefined && props.dataMax !== undefined) {
      if (scale === ScaleType.Log) {
        if (props.dataMin <= 0 || props.dataMax <= 0) {
          return DEFAULT_DOMAIN;
        }
      }
      return [props.dataMin, props.dataMax];
    }
    return DEFAULT_DOMAIN;
  }, [histoDomain, props.dataMin, props.dataMax, scale]);
  const [customDomain, setCustomDomain] = useState<CustomDomain>([null, null]);

  useEffect(() => {
    setCustomDomain(domain);
  }, [domain[0], domain[1]]);

  if (customDomain[0] === null || customDomain[1] === null) {
    return <></>;
  }

  // TODO add input for gamma factor
  return (
    <Histogram
      dataDomain={dataDomain}
      scaleType={scale}
      // @ts-expect-error: null was filtered out
      value={customDomain}
      onChangeMin={(minValue) => {
        const visDomain = getVisDomain([minValue, customDomain[1]], dataDomain);
        const [safeDomain] = getSafeDomain(visDomain, dataDomain, scale);
        onDomainChange(safeDomain);
      }}
      onChangeMax={(maxValue) => {
        const visDomain = getVisDomain([customDomain[0], maxValue], dataDomain);
        const [safeDomain] = getSafeDomain(visDomain, dataDomain, scale);
        onDomainChange(safeDomain);
      }}
      bins={bins}
      values={values}
    />
  );
}

const EMPTY_ARRAY = new Float64Array([]);

export default function HistogramDomain(props: {
  histogram?: ArrayHistogram;
  statistics?: ArrayStatistics;
  disabled?: boolean;
  setAutoscale: Dispatch<SetStateAction<boolean>>;
  autoscale: boolean;
  scaleType: VisScaleType;
  setScaleDomain: Dispatch<SetStateAction<[number, number]>>;
  scaleDomain: [number, number];
  colorMap?: ColorMap;
  invertColorMap?: boolean;
}) {
  // FIXME: disabled state not yet supported by the sub component
  return (
    <HistogramDomainSlider2
      histogram={{
        values: props.histogram?.values.data ?? EMPTY_ARRAY,
        bins: props.histogram?.bins.data ?? EMPTY_ARRAY,
      }}
      colorMap={props.colorMap}
      invertColorMap={props.invertColorMap}
      dataMin={props.statistics?.min ?? undefined}
      dataMax={props.statistics?.max ?? undefined}
      scaleType={props.scaleType}
      domain={props.scaleDomain}
      onDomainChange={(domain) => {
        if (props.autoscale) {
          props.setAutoscale(false);
        }
        props.setScaleDomain(domain);
      }}
    />
  );
}
