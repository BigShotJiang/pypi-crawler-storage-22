import type { PropsWithChildren } from 'react';
import { useEffect, useState } from 'react';
import { Dropdown, SplitButton } from 'react-bootstrap';
import type { MouseModeInteraction } from '../UseMouseModeInteraction';

type MeasureMouseMode = 'measure-distance' | 'measure-ortho' | 'measure-angle';

export function RulerButton<T extends string>(
  props: PropsWithChildren<{
    mouseModeInteraction: MouseModeInteraction<T | MeasureMouseMode>;
    disabled?: boolean;
    dropDirection?: 'up' | 'down';
    extraMouseModes?: Record<string, string>;
    onClear?: () => void;
  }>
) {
  const {
    mouseModeInteraction,
    disabled = false,
    dropDirection,
    extraMouseModes = {},
    onClear,
    children,
  } = props;
  const { mouseMode, setOrResetMouseMode, setMouseMode, resetMouseMode } =
    mouseModeInteraction;
  const [selectedMode, setSelectedMode] =
    useState<MeasureMouseMode>('measure-distance');
  const selectedIcons: Record<MeasureMouseMode, string> = {
    'measure-distance': 'fa-ruler',
    'measure-ortho': 'fa-ruler-combined',
    'measure-angle': 'fam-protractor',
  };

  useEffect(() => {
    if (mouseMode in extraMouseModes) {
      // @ts-expect-error
      setSelectedMode(mouseMode);
    }
  }, [extraMouseModes, mouseMode]);

  const selectedIcon =
    extraMouseModes[selectedMode] ?? selectedIcons[selectedMode] ?? '';
  const selected =
    mouseMode === 'measure-distance' ||
    mouseMode === 'measure-ortho' ||
    mouseMode === 'measure-angle' ||
    mouseMode in extraMouseModes;

  return (
    <SplitButton
      title={<i className={`fa ${selectedIcon} fa-lg"`} />}
      variant={selected ? 'primary' : 'secondary'}
      align={{ lg: 'start' }}
      className={dropDirection === 'up' ? 'dropup' : undefined}
      autoClose
      onClick={() => {
        if (selected) {
          resetMouseMode();
        } else {
          setOrResetMouseMode(selectedMode);
        }
      }}
      disabled={disabled}
    >
      <Dropdown.Item
        active={mouseMode === 'measure-distance'}
        onClick={() => {
          setSelectedMode('measure-distance');
          setMouseMode('measure-distance');
        }}
        title="Measure the distance between 2 points"
      >
        <i className="fa fa-fw fa-ruler fa-lg" /> Measure distance
      </Dropdown.Item>
      <Dropdown.Item
        active={mouseMode === 'measure-ortho'}
        onClick={() => {
          setSelectedMode('measure-ortho');
          setMouseMode('measure-ortho');
        }}
        title="Measure the orthogonal distance between 2 points"
      >
        <i className="fa fa-fw fa-ruler-combined fa-lg" /> Measure orthogonal
      </Dropdown.Item>
      <Dropdown.Item
        active={mouseMode === 'measure-angle'}
        onClick={() => {
          setSelectedMode('measure-angle');
          setMouseMode('measure-angle');
        }}
        title="Measure an angle"
      >
        <i className="fa fa-fw fam-protractor fa-lg" /> Measure angle
      </Dropdown.Item>
      {children}
      <Dropdown.Divider />
      <Dropdown.Item
        onClick={() => {
          onClear?.();
          resetMouseMode();
        }}
        title="Clear measure indicators, if some"
      >
        <i className="fa fa-fw fa-xmark" /> Clear indicators
      </Dropdown.Item>
    </SplitButton>
  );
}
