import { useThree } from '@react-three/fiber';
import { useEffect } from 'react';

/**
 * R3F component to custom the mouse cursor used by the opengl canvas.
 */
export function CanvasCursorSetter(props: { cursor: string }) {
  const { cursor } = props;
  const canvasElem = useThree((state) => state.gl.domElement);

  useEffect(() => {
    canvasElem.style.cursor = cursor;
  }, [canvasElem, cursor]);

  return <></>;
}
