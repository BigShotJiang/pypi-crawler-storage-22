import React, { useCallback, useMemo } from 'react';
import { useState, useEffect, useRef } from 'react';
import { cutGlslHeader, useDataTexture } from '../shaderUtils';
import { FilterMode, FilterDefinitions } from '../filters/conv2d';
import type { NdArray } from 'ndarray';
import type { Vector3 } from 'three';
import { ShaderMaterial } from 'three';
import type { CanvasEvent, Domain } from '@h5web/lib';
import { useCanvasEvent } from '@h5web/lib';
import { extend, invalidate } from '@react-three/fiber';
import type { NdFloat16Array } from '../NdFloat16Array';
import { NdNormalizedUint8Array } from '../NdNormalizedUint8Array';
import { AutoscaleMode, domainFromStatistics } from '../colormap';
import type { ArrayStatistics } from '../colormap';
import debug from 'debug';
import rawFragmentShaderWithHeader from '../shaders/compare.frag.glsl?raw';
import vertexShaderWithHeader from '../shaders/compare.vert.glsl?raw';

const rawFragmentShader = cutGlslHeader(rawFragmentShaderWithHeader);
const vertexShader = cutGlslHeader(vertexShaderWithHeader);

const logger = debug('daiquiri.components.h5web.items.CompareMesh');

export enum DisplayMode {
  // Render nothing
  EMPTY = 0,
  // Render the image A
  IMAGE_A = 1,
  // Render the image B
  IMAGE_B = 2,
  // Render mixed result as intensity
  DIFF = 100,
  ERROR = 101,
  MAX = 102,
  MIN = 103,
  MUL = 104,
  HSPLITTER = 105,
  // Render mixed result as channel conbination
  DIFF_COLOR = 200,
  ERROR_COLOR = 201,
  MAX_COLOR = 202,
  MIN_COLOR = 203,
  MUL_COLOR = 204,
  HSPLITTER_COLOR = 205,
  // Render a custom inhected shader function
  CUSTOM = 300,
}

class CompareMaterial extends ShaderMaterial {
  public constructor() {
    super({
      uniforms: {
        textureA: { value: null },
        normA: { value: { min: 0, max: 0, mode: 0 } },
        textureB: { value: null },
        normB: { value: { min: 0, max: 0, mode: 0 } },
        mode: { value: 0 },
        sizeCoef: { value: 1 },
        imageARotation: { value: 0 },
        imageATranslationX: { value: 0 },
        imageBRotation: { value: 0 },
        imageBTranslationX: { value: 0 },
        imageBFlipX: { value: 0 },
        domain: { value: { min: 0, max: 1 } },
        verticalSeparator: { value: 0 },
        kernelCoefs: { value: Float32Array.from([0, 0, 0, 0, 0, 0, 0, 0, 0]) },
        kernelSize: { value: 0 },
      },
    });
  }
}

extend({ CompareMaterial });

function directionFromMode(
  dataPt: Vector3,
  displayMode: DisplayMode,
  verticalSeparator: number
): number {
  if (displayMode === DisplayMode.IMAGE_A) {
    return -1;
  }
  if (
    displayMode === DisplayMode.HSPLITTER ||
    displayMode === DisplayMode.HSPLITTER_COLOR
  ) {
    if (dataPt.y < verticalSeparator) {
      return -1;
    }
  }
  return 1;
}

/**
 * Provide callback on mouse motion, in data unit
 */
export function DragLateral(props: {
  threshold?: number;
  translationA: number;
  translationB: number;
  verticalSeparator: number;
  displayMode: DisplayMode;
  onChanged: (translationA: number, translationB: number) => void;
  onIntermediateChanged: (translationA: number, translationB: number) => void;
  disabled?: boolean;
}) {
  const {
    translationA,
    translationB,
    threshold = 4,
    displayMode,
    verticalSeparator,
    disabled,
  } = props;
  const gestureRef = useRef<
    | {
        translationA: number;
        translationB: number;
        startData: Vector3;
        startScreen: Vector3;
        gestureStarted: boolean;
        coef: number;
      }
    | undefined
  >(undefined);

  const onPointerDown = useCallback(
    (event: CanvasEvent<PointerEvent>) => {
      const coef = directionFromMode(
        event.dataPt,
        displayMode,
        verticalSeparator
      );
      gestureRef.current = {
        translationA,
        translationB,
        startData: event.dataPt,
        startScreen: event.htmlPt,
        gestureStarted: false,
        coef,
      };
    },
    [translationA, translationB, displayMode, verticalSeparator]
  );

  const isCloseToStart = useCallback(
    (evt: CanvasEvent<PointerEvent>) => {
      const gesture = gestureRef.current;
      if (gesture === undefined) {
        return false;
      }
      const { htmlPt } = evt;
      const dist = Math.max(
        Math.abs(htmlPt.x - gesture.startScreen.x),
        Math.abs(htmlPt.y - gesture.startScreen.y)
      );
      return dist <= threshold;
    },
    [threshold]
  );

  const onPointerMove = useCallback(
    (evt: CanvasEvent<PointerEvent>) => {
      const gesture = gestureRef.current;
      if (gesture === undefined) {
        return;
      }
      if (!gesture.gestureStarted) {
        if (isCloseToStart(evt)) {
          return;
        }
        gestureRef.current = { ...gesture, gestureStarted: true };
      }
      const delta = evt.dataPt.x - gesture.startData.x;
      props.onIntermediateChanged(
        gesture.translationA + delta * gesture.coef,
        gesture.translationB + delta * gesture.coef
      );
    },
    [isCloseToStart, props.onIntermediateChanged]
  );

  const onPointerUp = useCallback(
    (evt: CanvasEvent<PointerEvent>) => {
      const gesture = gestureRef.current;
      if (gesture) {
        const delta = evt.dataPt.x - gesture.startData.x;
        props.onChanged(
          gesture.translationA + delta * gesture.coef,
          gesture.translationB + delta * gesture.coef
        );
      }
      gestureRef.current = undefined;
    },
    [isCloseToStart, props.onChanged]
  );

  // Hold the hook inside a component to  be able to drop it
  function Foo() {
    useCanvasEvent('pointerdown', onPointerDown);
    useCanvasEvent('pointermove', onPointerMove);
    useCanvasEvent('pointerup', onPointerUp);
    return <></>;
  }

  return <>{!disabled && <Foo />}</>;
}

/**
 * Appoximative domain from 2 statistics.
 */
function approxDomainFrom2Statistics(
  autoScale: AutoscaleMode,
  stateA: ArrayStatistics,
  stateB: ArrayStatistics
): Domain {
  switch (autoScale) {
    case AutoscaleMode.None:
      return [0, 1];
    case AutoscaleMode.Minmax:
      return [
        Math.min(stateA.min ?? 0, stateB.min ?? 0),
        Math.max(stateA.max ?? 1, stateB.max ?? 1),
      ];
    case AutoscaleMode.StdDev3: {
      const min = Math.min(stateA.min ?? 0, stateB.min ?? 0);
      const max = Math.max(stateA.max ?? 1, stateB.max ?? 1);
      const mean = ((stateA.mean ?? 0.5) + (stateB.mean ?? 0.5)) * 0.5;
      const std = ((stateA.std ?? 0.5) + (stateB.std ?? 0.5)) * 0.5;
      return [Math.max(min, mean - 3 * std), Math.min(max, mean + 3 * std)];
    }
    default:
      console.warn(`Unsupported norm ${autoScale}`);
  }
  return [0, 1];
}

export function CompareMesh(props: {
  imageA:
    | NdArray<Float32Array<ArrayBuffer>>
    | NdFloat16Array<ArrayBuffer>
    | NdNormalizedUint8Array<ArrayBuffer>
    | undefined;
  imageB:
    | NdArray<Float32Array<ArrayBuffer>>
    | NdFloat16Array<ArrayBuffer>
    | NdNormalizedUint8Array<ArrayBuffer>
    | undefined;
  stateA: ArrayStatistics | undefined;
  stateB: ArrayStatistics | undefined;
  displayMode?: DisplayMode;
  zoom?: number;
  /**
   * Callback during the interactive translation, in pixel
   */
  onTranslationXChanged?: (valueA: number, valueB: number) => void;
  /**
   * Callback at the end of the interactive translation, in pixel
   */
  onTranslationXIntermediateChanged?: (valueA: number, valueB: number) => void;
  imageARotation?: number;
  /**
   * Translation in pixel
   */
  imageATranslationX?: number;
  imageBRotation?: number;
  /**
   * Translation in pixel
   */
  imageBTranslationX?: number;
  imageBFlipX?: boolean;
  autoScale?: AutoscaleMode;
  verticalSeparator?: number;
  customFunc?: string;
  filterMode?: FilterMode;
  translationXInteration?: boolean;
  /**
   * Pixel size of the image, in data space
   */
  pixelSize?: number;
}) {
  const materialRef = useRef<CompareMaterial>(null);
  const {
    displayMode = 1,
    imageARotation = 0,
    imageATranslationX = 0,
    imageBRotation = 0,
    imageBTranslationX = 0,
    imageBFlipX = true,
    autoScale = AutoscaleMode.None,
    stateA,
    stateB,
    verticalSeparator = 0,
    customFunc,
    filterMode = FilterMode.NONE,
    translationXInteration = false,
    pixelSize,
  } = props;
  const [version, setVersion] = useState(0);

  const sizeCoef = useMemo(() => {
    if (pixelSize === undefined) {
      return 1;
    }
    return pixelSize;
  }, [props.pixelSize]);

  const fragmentShader = useMemo(() => {
    if (customFunc === undefined) {
      return rawFragmentShader;
    }
    return rawFragmentShader.replace('// CUSTOM FUNC INJECTION //', customFunc);
  }, [rawFragmentShader, customFunc]);

  const textureA = useDataTexture(props.imageA, { magNearest: true });
  const textureB = useDataTexture(props.imageB, { magNearest: true });

  const [kernelSize, kernelCoefs] = useMemo(() => {
    if (filterMode in FilterDefinitions) {
      const { size, coefs } = FilterDefinitions[filterMode];
      return [size, coefs];
    }
    console.log(`Unsupported ${filterMode}`);
    const { size, coefs } = FilterDefinitions[FilterMode.NONE];
    return [size, coefs];
  }, [filterMode]);

  // Track the version of the shader programs in order to invalidate the object
  // TODO: This looks to be not needed anymore
  useEffect(() => {
    setVersion((v) => v + 1);
  }, [fragmentShader]);

  const domain = useMemo(() => {
    if (stateA === undefined || stateB === undefined) {
      if (stateA !== undefined) {
        return domainFromStatistics(autoScale, stateA);
      }
      if (stateB !== undefined) {
        return domainFromStatistics(autoScale, stateB);
      }
      // fallback with something
      return [0, 1];
    }
    return approxDomainFrom2Statistics(autoScale, stateA, stateB);
  }, [stateA, stateB, autoScale]);

  const finalDisplayMode = useMemo(() => {
    if (textureA === undefined || textureB === undefined) {
      if (displayMode < 10) {
        // It's already a mono display
        return displayMode;
      }
      if (textureA !== undefined) {
        return DisplayMode.IMAGE_A;
      }
      if (textureB !== undefined) {
        return DisplayMode.IMAGE_B;
      }
      return DisplayMode.EMPTY;
    }
    return displayMode;
  }, [displayMode, textureA === undefined, textureB === undefined]);

  useEffect(() => {
    if (materialRef.current) {
      const uniforms = materialRef.current.uniforms;
      uniforms.mode.value = finalDisplayMode;
      uniforms.sizeCoef.value = sizeCoef;
      uniforms.imageARotation.value = imageARotation;
      uniforms.imageATranslationX.value = imageATranslationX;
      uniforms.imageBRotation.value = imageBRotation;
      uniforms.imageBTranslationX.value = imageBTranslationX;
      uniforms.imageBFlipX.value = imageBFlipX ? 1 : 0;
      uniforms.domain.value = { min: domain[0], max: domain[1] };
      uniforms.verticalSeparator.value = verticalSeparator;
      uniforms.kernelCoefs.value = kernelCoefs;
      uniforms.kernelSize.value = kernelSize;
      invalidate();
    }
  }, [
    materialRef.current,
    finalDisplayMode,
    sizeCoef,
    imageARotation,
    imageATranslationX,
    imageBRotation,
    imageBTranslationX,
    imageBFlipX,
    stateA,
    stateB,
    domain,
    verticalSeparator,
    kernelCoefs,
    kernelSize,
    version,
  ]);

  function getNorm(image: any) {
    if (image instanceof NdNormalizedUint8Array) {
      return {
        min: image.transfer.min,
        max: image.transfer.max,
        mode: 1,
      };
    }
    return { min: 0, max: 0, mode: 0 };
  }

  useEffect(() => {
    if (materialRef.current) {
      const uniforms = materialRef.current.uniforms;
      uniforms.textureA.value = textureA;
      uniforms.normA.value = getNorm(props.imageA);
      invalidate();
    }
  }, [version, textureA, materialRef.current]);

  useEffect(() => {
    if (materialRef.current) {
      const uniforms = materialRef.current.uniforms;
      uniforms.textureB.value = textureB;
      uniforms.normB.value = getNorm(props.imageB);
      invalidate();
    }
  }, [version, textureB, materialRef.current]);

  const [height, width] = props.imageA?.shape ?? [1024, 1024];

  if (finalDisplayMode === DisplayMode.EMPTY) {
    return <></>;
  }

  return (
    <mesh>
      <planeGeometry
        attach="geometry"
        args={[width * sizeCoef * 2, height * sizeCoef * 2, 1, 1]}
      />
      <DragLateral
        translationA={imageATranslationX * sizeCoef}
        translationB={imageBTranslationX * sizeCoef}
        onChanged={(a, b) => {
          props.onTranslationXChanged?.(
            (0.5 * a) / sizeCoef,
            (0.5 * b) / sizeCoef
          );
        }}
        onIntermediateChanged={(a, b) => {
          props.onTranslationXIntermediateChanged?.(
            (0.5 * a) / sizeCoef,
            (0.5 * b) / sizeCoef
          );
        }}
        threshold={0}
        displayMode={displayMode}
        verticalSeparator={verticalSeparator}
        disabled={!translationXInteration}
      />
      {/* @ts-expect-error */}
      <compareMaterial
        key={version}
        attach="material"
        ref={materialRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
      />
    </mesh>
  );
}
