import React from 'react';
import type { HGapRoiGeometry } from './geometries';
import { VLineRoi } from './VLineRoi';
import { useVisCanvasContext } from '@h5web/lib';
import { useFrame } from '@react-three/fiber';
import { ArrowHeadMarker } from '../shapes/ArrowHeadMarker';
import { HSegment } from '../shapes/HSegment';
import Label from '../Label';
import { ARROW_SIZE } from './const';

export function HGapRoi(props: {
  geometry: HGapRoiGeometry;
  zIndex?: number;
  lineWidth?: number;
  color?: string;
  opacity?: number;
  readOnly?: boolean;
  visible?: boolean;
  onGeometryChanged?: (geometry: HGapRoiGeometry, dragging: boolean) => void;
  unit?: string;
}) {
  const {
    geometry,
    lineWidth = 2,
    color = 'blue',
    opacity = 1,
    zIndex = 1,
    visible = true,
    readOnly = props.onGeometryChanged === undefined,
  } = props;

  const unit = props.unit === undefined ? '' : ` ${props.unit}`;

  const visCanvasContext = useVisCanvasContext();
  const [y0, setY0] = React.useState<number | undefined>(undefined);

  useFrame(({ camera }) => {
    const visibleDomain = visCanvasContext.getVisibleDomains(camera);
    const coef = 0.9;
    setY0(
      visibleDomain.yVisibleDomain[0] * coef +
        visibleDomain.yVisibleDomain[1] * (1 - coef)
    );
  });

  if (!visible) {
    return <></>;
  }

  const halfGap = geometry.gap * 0.5;
  const xMin = geometry.x - Math.abs(halfGap);
  const xMax = geometry.x + Math.abs(halfGap);

  function x0Changed(localPos: { x: number }, dragging: boolean) {
    const { x } = localPos;
    props.onGeometryChanged?.({ ...geometry, x }, dragging);
  }

  function x1Changed(localPos: { x: number }, dragging: boolean) {
    const { x: newPos } = localPos;
    const x = (geometry.x + halfGap + newPos) * 0.5;
    const gap = geometry.x + halfGap - newPos;
    props.onGeometryChanged?.(
      { gap: dragging ? gap : Math.abs(gap), x },
      dragging
    );
  }

  function x2Changed(localPos: { x: number }, dragging: boolean) {
    const { x: newPos } = localPos;
    const x = (geometry.x - halfGap + newPos) * 0.5;
    const gap = newPos - (geometry.x - halfGap);
    props.onGeometryChanged?.(
      { gap: dragging ? gap : Math.abs(gap), x },
      dragging
    );
  }

  const text = `${geometry.gap.toFixed(2)}${unit}`;

  return (
    <>
      <VLineRoi
        geometry={{ x: geometry.x }}
        zIndex={zIndex}
        color={color}
        opacity={opacity * 0.5}
        readOnly={readOnly}
        lineWidth={lineWidth}
        onGeometryChanged={x0Changed}
      />
      <VLineRoi
        geometry={{ x: geometry.x - halfGap }}
        zIndex={zIndex}
        color={color}
        opacity={opacity}
        readOnly={readOnly}
        lineWidth={lineWidth}
        onGeometryChanged={x1Changed}
      />
      <VLineRoi
        geometry={{ x: geometry.x + halfGap }}
        zIndex={zIndex}
        color={color}
        opacity={opacity}
        readOnly={readOnly}
        lineWidth={lineWidth}
        onGeometryChanged={x2Changed}
      />
      {y0 !== undefined && (
        <>
          <HSegment
            zIndex={zIndex + 0.01}
            x1={xMin}
            x2={xMax}
            y={y0}
            lineWidth={2}
            color="red"
          />
          <ArrowHeadMarker
            zIndex={zIndex + 0.01}
            x={xMin}
            y={y0}
            sizeInScreen={ARROW_SIZE}
            angle={180}
            color="red"
            lineWidth={2}
          />
          <ArrowHeadMarker
            zIndex={zIndex + 0.01}
            x={xMax}
            y={y0}
            sizeInScreen={ARROW_SIZE}
            angle={0}
            color="red"
            lineWidth={2}
          />
          <Label
            text={text}
            datapos={[geometry.x, y0]}
            anchor="top"
            hmargin={15}
            outline="#FFFFFF80"
          />
        </>
      )}
    </>
  );
}
