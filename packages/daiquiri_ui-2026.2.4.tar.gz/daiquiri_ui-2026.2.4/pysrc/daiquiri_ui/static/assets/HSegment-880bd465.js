import{aV as W,r as x,aK as j,aY as M,b6 as R,j as o,aW as X,aX as C}from"./index-7224831e.js";import{k as Y}from"./hooks-19d045e5.js";import{c as S}from"./Label-096c3a2f.js";class V extends X{constructor(){super({uniforms:{color:{value:new C},gapColor:{value:new C},dashSize:{value:0},gapSize:{value:0},scaleX:{value:0},scaleY:{value:0},size:{value:0},lineWidth:{value:0}},vertexShader:`
uniform float scaleX;
uniform float scaleY;
uniform float size;
out vec2 pixelCoord;

void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    vec2 pixelScale = vec2(scaleX, scaleY);
    pixelCoord = vec2(position.x + size * 0.5, position.y) / pixelScale;
}
      `,fragmentShader:`
uniform vec4 color;
uniform vec4 gapColor;
uniform float gapSize;
uniform float dashSize;
uniform float lineWidth;

in vec2 pixelCoord;

void main() {
    float alpha;
    if (lineWidth >= 1.0) {
        alpha = smoothstep(lineWidth * 0.5 + 0.01, lineWidth * 0.5 - 0.1, abs(pixelCoord.y));
    } else {
        // simulate line thiner than 1px with alpha
        alpha = lineWidth;
    }

    if (dashSize == 0.0) {
        gl_FragColor = vec4(color.r, color.g, color.b, alpha * color.a);
        return;
    }

    float dist = abs(pixelCoord.x);
    dist = mod(dist, (dashSize + gapSize));
    if (dist <= dashSize) {
        gl_FragColor = vec4(color.r, color.g, color.b, alpha * color.a);
    } else {
        gl_FragColor = vec4(gapColor.r, gapColor.g, gapColor.b, alpha * gapColor.a);
    }
}
      `})}}W({HDashMaterial:V});function _(u){const{y:z,x1:p,x2:h,lineWidth:r=1,color:f="black",gapColor:d,dashSize:i=0,gapSize:m=i,opacity:s=1,zIndex:b=0}=u,a=x.useRef(null),t=h-p,y=(p+h)*.5,n=j.useRef(null),v=Y();return x.useEffect(()=>{const l=S(f,s),c=S(d??"transparent",s);if(a.current){const e=a.current.uniforms;e.color.value=l,e.gapColor.value=c,e.dashSize.value=i,e.gapSize.value=m,e.size.value=t,e.lineWidth.value=r,M()}},[f,d,i,m,s,t,r]),R(({camera:l})=>{if(n.current===null||a.current===null)return;const c=l.scale.x/v.sx,e=l.scale.y/v.sy;n.current.scale.y=e;const g=a.current.uniforms;g.scaleX.value=c,g.scaleY.value=1}),o.jsx("group",{ref:n,position:[y,z,b],children:o.jsxs("mesh",{children:[o.jsx("ambientLight",{}),o.jsx("planeGeometry",{attach:"geometry",args:[Math.abs(t),r+1,1,1]}),o.jsx("hDashMaterial",{attach:"material",transparent:!0,ref:a})]})})}export{_ as H};
