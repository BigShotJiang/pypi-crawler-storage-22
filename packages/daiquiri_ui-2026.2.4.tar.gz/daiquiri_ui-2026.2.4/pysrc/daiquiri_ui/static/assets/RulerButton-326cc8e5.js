import{P as S,r as b,j as e,aH as j,as as Z,B as ee,aV as H,ag as z,b_ as ae,aY as N,b6 as O,aW as $,aX as _,b$ as L,aG as te,aL as V}from"./index-7224831e.js";import{O as X,h as T,b as U,Q}from"./index-987a0137.js";import{t as q}from"./QtyHelper-8429914f.js";import{k as J}from"./hooks-19d045e5.js";import{c as Y}from"./Label-096c3a2f.js";import{A as E}from"./Anchor-424669fc.js";import{u as oe}from"./UseMouseModeInteraction-97b5a13c.js";import{a as ne}from"./types-4f696de0.js";const se={id:S.string,toggleLabel:S.string,href:S.string,target:S.string,onClick:S.func,title:S.node.isRequired,type:S.string,disabled:S.bool,align:ne,menuRole:S.string,renderMenuOnMount:S.bool,rootCloseEvent:S.string,flip:S.bool,bsPrefix:S.string,variant:S.string,size:S.string},B=b.forwardRef(({id:u,bsPrefix:a,size:t,variant:n,title:h,type:l="button",toggleLabel:x="Toggle dropdown",children:o,onClick:s,href:i,target:r,menuRole:v,renderMenuOnMount:g,rootCloseEvent:c,flip:f,...p},m)=>e.jsxs(j,{ref:m,...p,as:Z,children:[e.jsx(ee,{size:t,variant:n,disabled:p.disabled,bsPrefix:a,href:i,target:r,onClick:s,type:l,children:h}),e.jsx(j.Toggle,{split:!0,id:u,size:t,variant:n,disabled:p.disabled,childBsPrefix:a,children:e.jsx("span",{className:"visually-hidden",children:x})}),e.jsx(j.Menu,{role:v,renderOnMount:g,rootCloseEvent:c,flip:f,children:o})]}));B.propTypes=se;B.displayName="SplitButton";const re=B;class ie extends ${constructor(){super({uniforms:{color:{value:new _},gapColor:{value:new _},dashSize:{value:0},gapSize:{value:0},scaleX:{value:0},scaleY:{value:0},origin:{value:new z},direction:{value:new z},lineWidth:{value:0}},vertexShader:`
uniform float scaleX;  // signed scale
uniform float scaleY;  // signed scale
uniform vec2 origin;
uniform vec2 direction;
out vec2 pixelCoord;

void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    vec2 p = vec2(position.x, position.y) - origin;
    float l = dot(p, direction);
    float d = dot(p, vec2(-direction.y, direction.x));
    float scale = (abs(scaleX) + abs(scaleY)) * 0.5;
    pixelCoord = vec2(l, d / scale);
}
      `,fragmentShader:`
uniform vec4 color;
uniform vec4 gapColor;
uniform float gapSize;
uniform float dashSize;
uniform float lineWidth;

in vec2 pixelCoord;

void main() {
    float alpha;
    if (lineWidth >= 1.0) {
        alpha = smoothstep(0.5, 0.0, abs(pixelCoord.y) - lineWidth * 0.5);
    } else {
        // simulate line thiner than 1px with alpha
        alpha = lineWidth;
    }

    if (dashSize == 0.0) {
        gl_FragColor = vec4(color.r, color.g, color.b, alpha * color.a);
        return;
    }

    float dist = abs(pixelCoord.x);
    dist = mod(dist, (dashSize + gapSize));
    if (dist <= dashSize) {
        gl_FragColor = vec4(color.r, color.g, color.b, alpha * color.a);
    } else {
        gl_FragColor = vec4(gapColor.r, gapColor.g, gapColor.b, alpha * gapColor.a);
    }
}
      `})}}H({LineWithDataDashMaterial:ie});function W(u){const{p1:a,p2:t,lineWidth:n=1,color:h="black",gapColor:l,dashSize:x=0,gapSize:o=x,opacity:s=1,zIndex:i=0}=u,r=b.useRef(null),v=J(),[g,c,f]=b.useMemo(()=>{const p=new z(t[0]-a[0],t[1]-a[1]).normalize(),d=new z(-p.y,p.x).multiplyScalar(n+1),y=new ae;return y.moveTo(a[0]-d.x,a[1]-d.y),y.lineTo(a[0]+d.x,a[1]+d.y),y.lineTo(t[0]+d.x,t[1]+d.y),y.lineTo(t[0]-d.x,t[1]-d.y),y.closePath(),[y,new z(a[0],a[1]),p]},[a,t,n]);return b.useEffect(()=>{const p=Y(h,s),m=Y(l??"transparent",s);if(r.current){const d=r.current.uniforms;d.color.value=p,d.gapColor.value=m,d.dashSize.value=x,d.gapSize.value=o,d.origin.value=c,d.direction.value=f,d.lineWidth.value=n,N()}},[h,l,x,o,s,c,f,n]),O(({camera:p})=>{if(r.current===null)return;const m=p.scale.x/v.sx,d=p.scale.y/v.sy,y=r.current.uniforms;y.scaleX.value=m,y.scaleY.value=d,N()}),e.jsx("group",{"position-z":i,children:e.jsxs("mesh",{children:[e.jsx("ambientLight",{}),e.jsx("shapeGeometry",{attach:"geometry",args:[g]}),e.jsx("lineWithDataDashMaterial",{attach:"material",transparent:!0,ref:r})]})})}class le extends ${constructor(){super({uniforms:{color:{value:new _},gapColor:{value:new _},radius:{value:0},startAngle:{value:0},angleRange:{value:0},dashSize:{value:0},gapSize:{value:0},scaleX:{value:0},scaleY:{value:0},lineWidth:{value:0}},vertexShader:`
uniform float scaleX; // signed scale
uniform float scaleY; // signed scale
out vec2 pixelCoord;
// out vec2 dataCoord;

void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    vec2 pixelScale = abs(vec2(scaleX, scaleY));
    // dataCoord = vec2(position.x, position.y);
    pixelCoord = vec2(position.x, position.y) / pixelScale;
}
      `,fragmentShader:`
uniform vec4 color;
uniform vec4 gapColor;
uniform float gapSize;
uniform float dashSize;
uniform float lineWidth;
uniform float scaleX; // signed scale
uniform float scaleY; // signed scale
uniform float radius;
uniform float startAngle;
uniform float angleRange;
in vec2 pixelCoord;

const float M_PI = 3.1415926535897932384626433832795;
const float AA_DASH = 0.5;

/**
 * Antialiasing following the line of dash and gap.
 *
 * The distances have to be in pixel.
 */
vec4 aa_dash_gap(float dist, float alpha, float dashSize, float gapSize) {
  dist = mod(dist, (gapSize + dashSize));
  float sd1 = (dist < dashSize) ? dist : dist - (dashSize + gapSize);
  float sd2 = -(dist - dashSize);
  if (abs(sd1) <= AA_DASH || abs(sd2) <= AA_DASH) {
    if (abs(sd1) < abs(sd2)) {
      float c = (sd1 + AA_DASH) * (0.5 / AA_DASH);
      return (
        vec4(color.r, color.g, color.b, alpha * color.a) * c
        + vec4(gapColor.r, gapColor.g, gapColor.b, alpha * gapColor.a) * (1.0 - c)
      );
    } else {
      float c = (sd2 + AA_DASH) * (0.5 / AA_DASH);
      return (
        vec4(color.r, color.g, color.b, alpha * color.a) * c
        + vec4(gapColor.r, gapColor.g, gapColor.b, alpha * gapColor.a) * (1.0 - c)
      );
    }
  }
  if (dist <= dashSize) {
    return vec4(color.r, color.g, color.b, alpha * color.a);
  }
  return vec4(gapColor.r, gapColor.g, gapColor.b, alpha * gapColor.a);
}

void main() {
    float r = length(pixelCoord);
    float s = (abs(scaleX) + abs(scaleY)) * 0.5;
    float ss = 1.0 / s;
    float d = abs(r - radius * ss) - lineWidth * 0.5;
    if (d > 1.5) {
      discard;
    }

    float sAngleRange = sign(angleRange);
    float nAngleRange = abs(angleRange);
    float rawA = atan(pixelCoord.x, pixelCoord.y);
    float aa = mod(sAngleRange * (rawA - startAngle) + 8.0 * M_PI, 2.0 * M_PI);

    if (nAngleRange < 2.0 * M_PI && aa < 0.0 || aa > nAngleRange) {
      discard;
    }

    float alpha;
    if (lineWidth >= 1.0) {
      alpha = smoothstep(0.25, 0.0, d);
    } else {
      // simulate line thiner than 1px with alpha
      alpha = lineWidth;
    }

    if (dashSize == 0.0) {
      gl_FragColor = vec4(color.r, color.g, color.b, alpha * color.a);
      return;
    }

    float dist = aa * radius;
    gl_FragColor = aa_dash_gap(dist * ss, alpha, dashSize * ss, gapSize * ss);
}
      `})}}H({ArcDashMaterial:le});function ce(u){const{center:a,radius:t,startAngle:n,angleRange:h,lineWidth:l=1,color:x="black",gapColor:o,dashSize:s=0,gapSize:i=s,opacity:r=1,zIndex:v=0}=u,g=b.useRef(null),c=J();return b.useEffect(()=>{const f=Y(x,r),p=Y(o??"transparent",r);if(g.current){const m=g.current.uniforms;m.color.value=f,m.radius.value=t,m.startAngle.value=((n+180)%360-180)*Math.PI/180,m.angleRange.value=h*Math.PI/180,m.gapColor.value=p,m.dashSize.value=s,m.gapSize.value=i,m.lineWidth.value=l,N()}},[x,t,n,h,o,s,i,r,l]),O(({camera:f})=>{if(g.current===null)return;const p=f.scale.x/c.sx,m=f.scale.y/c.sy,d=g.current.uniforms;d.scaleX.value=p,d.scaleY.value=m}),e.jsx("group",{position:[a[0],a[1],v],children:e.jsxs("mesh",{children:[e.jsx("ambientLight",{}),e.jsx("planeGeometry",{attach:"geometry",args:[(t+l)*2,(t+l)*2,1,1]}),e.jsx("arcDashMaterial",{attach:"material",transparent:!0,ref:g})]})})}function de(u){const{geometry:a,onGeometryChanged:t,zIndex:n,lineWidth:h=1,color:l="blue",opacity:x=1,readOnly:o=!1,visible:s=!0}=u,{x:i,y:r,angle:v,angleRange:g,radius:c}=a,f=v*Math.PI/180,p=(v-g*.5)*Math.PI/180,m=(v+g*.5)*Math.PI/180,d={x:i+Math.sin(p)*c,y:r+Math.cos(p)*c},y={x:i+Math.sin(m)*c,y:r+Math.cos(m)*c},D={x:i+Math.sin(f)*c*.5,y:r+Math.cos(f)*c*.5},P=`${g.toFixed(2)} deg`,R=10*c/(Math.PI*18),A=b.useCallback((M,w)=>{const I=new z(M.x-a.x,M.y-a.y),k=Math.atan2(I.x,I.y)*180/Math.PI,F=L(a.angle-a.angleRange*.5,k);t==null||t({...a,radius:I.length(),angle:a.angle+F*.5,angleRange:a.angleRange-F},w)},[a,t]),C=b.useCallback((M,w)=>{const I=new z(M.x-a.x,M.y-a.y),k=Math.atan2(I.x,I.y)*180/Math.PI,F=L(a.angle+a.angleRange*.5,k);t==null||t({...a,radius:I.length(),angle:a.angle+F*.5,angleRange:a.angleRange+F},w)},[a,t]);return s?e.jsxs(e.Fragment,{children:[e.jsx(ce,{center:[i,r],radius:c,startAngle:v-g*.5,angleRange:g,lineWidth:h,color:l,opacity:x,gapColor:"#F0F0F0",dashSize:R,gapSize:R,zIndex:n}),e.jsx(W,{p1:[i,r],p2:[d.x,d.y],lineWidth:h,color:l,opacity:x,zIndex:n}),e.jsx(W,{p1:[i,r],p2:[y.x,y.y],lineWidth:h,color:l,opacity:x,zIndex:n}),e.jsx(E,{geometry:{x:i,y:r},onGeometryChanged:(M,w)=>{t==null||t({...u.geometry,x:M.x,y:M.y},w)},color:l,readOnly:o,opacity:x,zIndex:n}),e.jsx(E,{geometry:d,onGeometryChanged:A,color:l,readOnly:o,opacity:x,zIndex:n}),e.jsx(E,{geometry:y,onGeometryChanged:C,color:l,readOnly:o,opacity:x,zIndex:n}),e.jsx(X,{x:D.x,y:D.y,style:{zIndex:100},center:!0,children:e.jsx("div",{className:"text-light p-1 rounded",style:{backgroundColor:"#000000A0"},children:P})})]}):e.jsx(e.Fragment,{})}function K(u){const t=10**Math.ceil(Math.log10(u)),n=u/t;return n>=1?Number(t):n>=.5?.5*t:n>=.25?.25*t:n>=.1?.1*t:u}function ue(u){const{data:a,plotUnit:t}=u,[n,h]=a,l=U(),{width:x}=l.canvasSize,o=Q(c=>{const f=l.getVisibleDomains(c),p=f.xVisibleDomain[1]-f.xVisibleDomain[0];return Math.abs(p)},[x]),s=b.useMemo(()=>K(o/15),[o]),i=n.distanceTo(h),r=n.clone().add(h).multiplyScalar(.5);function v(c,f){return f?f==="px"?`${c.toFixed(2)} px`:q(new V(c,f)).toPrec(.01).toString():c.toFixed(2)}const g=v(i,t);return e.jsxs(e.Fragment,{children:[e.jsx(W,{p1:[n.x,n.y],p2:[h.x,h.y],color:"red",gapColor:"#F0F0F0",dashSize:s,gapSize:s,lineWidth:2,zIndex:3,opacity:.75}),e.jsx(X,{x:r.x,y:r.y,style:{zIndex:100},center:!0,children:e.jsx("div",{className:"bg-dark text-light p-1 rounded",children:g})})]})}function ge(u){const{data:a,plotUnit:t}=u,[n,h]=a,l=U(),{width:x}=l.canvasSize,o=Q(A=>{const C=l.getVisibleDomains(A),M=C.xVisibleDomain[1]-C.xVisibleDomain[0];return Math.abs(M)},[x]),s=b.useMemo(()=>K(o/15),[o]),i=n,r=new te(h.x,n.y),v=r,g=h,c=Math.abs(i.x-r.x),f=Math.abs(v.y-g.y),p=i.clone().add(r).multiplyScalar(.5),m=v.clone().add(g).multiplyScalar(.5);function d(A,C){return C?C==="px"?`${A.toFixed(2)} px`:q(new V(A,C)).toPrec(.01).toString():A.toFixed(2)}const y=d(c,t),D=d(f,t),P=c>f*.05,R=f>c*.05;return e.jsxs(e.Fragment,{children:[P&&e.jsx(W,{p1:[i.x,i.y],p2:[r.x,r.y],color:"red",gapColor:"#F0F0F0",dashSize:s,gapSize:s,lineWidth:2,zIndex:3,opacity:.75}),R&&e.jsx(W,{p1:[v.x,v.y],p2:[g.x,g.y],color:"red",gapColor:"#F0F0F0",dashSize:s,gapSize:s,lineWidth:2,zIndex:3,opacity:.75}),P&&e.jsx(X,{x:p.x,y:p.y,style:{zIndex:100},center:!0,children:e.jsx("div",{className:"bg-dark text-light p-1 rounded",children:y})}),R&&e.jsx(X,{x:m.x,y:m.y,style:{zIndex:100},center:!0,children:e.jsx("div",{className:"bg-dark text-light p-1 rounded",children:D})})]})}function G(u,a){const t=new z(a.x-u.x,a.y-u.y),n=Math.atan2(t.x,t.y)*180/Math.PI;return{x:u.x,y:u.y,radius:t.length(),angle:n,angleRange:30}}function be(u){const{mouseMode:a,disabled:t=!1,plotUnit:n}=u,h=a==="measure-angle",[l,x]=b.useState({x:0,y:0,radius:0,angle:0,angleRange:0}),o=oe();return e.jsxs(e.Fragment,{children:[e.jsx(T,{id:"ruler3-selection-tool",disabled:a!=="measure-angle"||t,onSelectionChange:s=>{if(s===void 0)return;const i=G(s.data[0],s.data[1]);x(i)},onSelectionStart:()=>{o==null||o.actions.captureMouseInteraction()},onSelectionEnd:()=>{o==null||o.actions.releaseMouseInteraction()},onValidSelection:s=>{const i=G(s.data[0],s.data[1]);x(i)},children:s=>e.jsx(e.Fragment,{})}),h&&e.jsx(de,{geometry:l,onGeometryChanged:s=>{x(s)},color:"red",lineWidth:2,zIndex:2,opacity:.75}),e.jsx(T,{id:"ruler-selection-tool",disabled:a!=="measure-distance"||t,onSelectionStart:()=>{o==null||o.actions.captureMouseInteraction()},onSelectionEnd:()=>{o==null||o.actions.releaseMouseInteraction()},children:s=>e.jsx(ue,{...s,plotUnit:n})}),e.jsx(T,{id:"ruler2-selection-tool",disabled:a!=="measure-ortho"||t,onSelectionStart:()=>{o==null||o.actions.captureMouseInteraction()},onSelectionEnd:()=>{o==null||o.actions.releaseMouseInteraction()},children:s=>e.jsx(ge,{...s,plotUnit:n})})]})}function Me(u){const{mouseModeInteraction:a,disabled:t=!1,dropDirection:n,extraMouseModes:h={},onClear:l,children:x}=u,{mouseMode:o,setOrResetMouseMode:s,setMouseMode:i,resetMouseMode:r}=a,[v,g]=b.useState("measure-distance"),c={"measure-distance":"fa-ruler","measure-ortho":"fa-ruler-combined","measure-angle":"fam-protractor"};b.useEffect(()=>{o in h&&g(o)},[h,o]);const f=h[v]??c[v]??"",p=o==="measure-distance"||o==="measure-ortho"||o==="measure-angle"||o in h;return e.jsxs(re,{title:e.jsx("i",{className:`fa ${f} fa-lg"`}),variant:p?"primary":"secondary",align:{lg:"start"},className:n==="up"?"dropup":void 0,autoClose:!0,onClick:()=>{p?r():s(v)},disabled:t,children:[e.jsxs(j.Item,{active:o==="measure-distance",onClick:()=>{g("measure-distance"),i("measure-distance")},title:"Measure the distance between 2 points",children:[e.jsx("i",{className:"fa fa-fw fa-ruler fa-lg"})," Measure distance"]}),e.jsxs(j.Item,{active:o==="measure-ortho",onClick:()=>{g("measure-ortho"),i("measure-ortho")},title:"Measure the orthogonal distance between 2 points",children:[e.jsx("i",{className:"fa fa-fw fa-ruler-combined fa-lg"})," Measure orthogonal"]}),e.jsxs(j.Item,{active:o==="measure-angle",onClick:()=>{g("measure-angle"),i("measure-angle")},title:"Measure an angle",children:[e.jsx("i",{className:"fa fa-fw fam-protractor fa-lg"})," Measure angle"]}),x,e.jsx(j.Divider,{}),e.jsxs(j.Item,{onClick:()=>{l==null||l(),r()},title:"Clear measure indicators, if some",children:[e.jsx("i",{className:"fa fa-fw fa-xmark"})," Clear indicators"]})]})}export{W as L,Me as R,re as S,be as a};
