import{P as e}from"./index-7224831e.js";const p=e.oneOf(["start","end"]),a=e.oneOfType([p,e.shape({sm:p}),e.shape({md:p}),e.shape({lg:p}),e.shape({xl:p}),e.shape({xxl:p}),e.object]);export{a};
