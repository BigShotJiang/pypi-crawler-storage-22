import {
  describe,
  expect,
  test,
  beforeAll,
  beforeEach,
  afterAll,
  afterEach,
} from 'vitest';
import { useScanData } from '../../services/ScanDataService';
import { renderHook, waitFor } from '@testing-library/react';
import Resources from '../../helpers/tests/resources';
import ResourceHandler from '../../helpers/tests/resources/ResourceHandler';
import type { AxiosRequestConfig } from 'axios';
import { vi } from 'vitest';
import { sleep } from '../../helpers/time';

const SCAN_DATA = {
  data: {
    foo: {
      dtype: '<u1',
      data: [],
      name: 'foo',
      shape: [],
    },
    foo2: {
      dtype: '<u2',
      data: [],
      name: 'foo2',
      shape: [],
    },
    image1: {
      dtype: '<u1',
      data: [],
      name: 'image1',
      shape: [2, 2],
    },
  },
  scanid: 10,
};

class Scans extends ResourceHandler {
  public baseUrl = '/scans';

  public resources = {
    '/status': {
      get: {
        status: 200,
        response: () => ({ progress: 50, scanid: null }),
      },
    },

    '/data/10': {
      get: {
        status: 200,
        response: () => SCAN_DATA,
      },
    },

    '/data/binary/10': {
      get: {
        status: 200,
        response: (payload: unknown, request: AxiosRequestConfig) => {
          const { channel, selection } = request?.params;
          if (channel === 'foo') {
            if (selection === '0:4') {
              return Uint8Array.from([1, 2, 3, 4]).buffer;
            }
            if (selection === '4:8') {
              return Uint8Array.from([5, 6, 7, 8]).buffer;
            }
            if (selection === '0:8') {
              return Uint8Array.from([1, 2, 3, 4, 5, 6, 7, 8]).buffer;
            }
          }
          if (channel === 'foo2') {
            if (selection === '0:4') {
              return Uint8Array.from([1, 0, 2, 0, 3, 0, 4, 0]).buffer;
            }
            if (selection === '4:8') {
              return Uint8Array.from([5, 0, 6, 0, 7, 0, 8, 0]).buffer;
            }
          }
          if (channel === 'image1') {
            if (selection === '0:1') {
              return Uint8Array.from([0, 1, 2, 3]).buffer;
            }
          }
          return Uint8Array.from([]).buffer;
        },
      },
    },
  };
}

let RESOURCES: Resources | undefined;

describe('Check useScanData', () => {
  beforeAll(() => {
    RESOURCES = new Resources({
      handlers: {
        scans: Scans,
      },
    });
  });
  afterAll(() => {
    RESOURCES = undefined;
  });

  beforeEach(() => {
    vi.spyOn(global.console, 'warn');
    vi.spyOn(global.console, 'error');
  });
  afterEach(() => {
    expect(console.warn).toBeCalledTimes(0);
    expect(console.error).toBeCalledTimes(0);
    // @ts-expect-error
    console.warn.mockRestore();
    // @ts-expect-error
    console.error.mockRestore();
  });
  test('No scan', () => {
    const { result } = renderHook(() => {
      return useScanData({
        scanId: undefined,
        channelNames: ['foo'],
        start: 0,
        stop: 4,
      });
    });
    expect(result.current).toStrictEqual({
      loading: false,
      data: {},
    });
  });
  test('Read single', async () => {
    const { result } = renderHook(() => {
      return useScanData({
        scanId: 10,
        channelNames: ['foo'],
        start: 0,
        stop: 4,
      });
    });
    await waitFor(() => expect(result.current.loading).toBe(false), {
      timeout: 5000,
    });
    expect(result.current.data.foo?.data).toStrictEqual(
      Uint8Array.from([1, 2, 3, 4])
    );
  });
  test('Overrun', async () => {
    const initialProps = {
      scanId: 10,
      channelNames: ['foo'],
      start: 0,
      stop: 0,
    };
    const { result, rerender } = renderHook(
      (props) => {
        return useScanData(props);
      },
      {
        initialProps,
      }
    );
    await sleep(1000);
    rerender({ ...initialProps, start: 0, stop: 4 });
    rerender({ ...initialProps, start: 0, stop: 8 });
    await waitFor(() => expect(result.current.loading).toBe(false), {
      timeout: 2000,
    });
    expect(result.current.data.foo?.data).toStrictEqual(
      Uint8Array.from([1, 2, 3, 4, 5, 6, 7, 8])
    );
  });
  test('Update to bigger', async () => {
    const initialProps = {
      scanId: 10,
      channelNames: ['foo'],
      start: 0,
      stop: 4,
    };
    const { result, rerender } = renderHook(
      (props) => {
        return useScanData(props);
      },
      {
        initialProps,
      }
    );
    await waitFor(() => expect(result.current?.data?.foo).toBeDefined(), {
      timeout: 5000,
    });
    rerender({ ...initialProps, stop: 8 });
    await waitFor(() => expect(result.current?.data?.foo).toBeDefined(), {
      timeout: 5000,
    });
    expect(result.current.data.foo?.data).toStrictEqual(
      Uint8Array.from([1, 2, 3, 4, 5, 6, 7, 8])
    );
  });
  test('Update to smaller', async () => {
    const initialProps = {
      scanId: 10,
      channelNames: ['foo'],
      start: 0,
      stop: 4,
    };
    const { result, rerender } = renderHook(
      (props) => {
        return useScanData(props);
      },
      {
        initialProps,
      }
    );
    await waitFor(() => expect(result.current?.data?.foo).toBeDefined(), {
      timeout: 5000,
    });
    rerender({ ...initialProps, start: 1, stop: 3 });
    await waitFor(() => expect(result.current?.data?.foo).toBeDefined(), {
      timeout: 5000,
    });
    expect(result.current.data.foo?.data).toStrictEqual(
      Uint8Array.from([2, 3])
    );
  });
  test('Uint16 channel', async () => {
    const initialProps = {
      scanId: 10,
      channelNames: ['foo2'],
      start: 0,
      stop: 4,
    };
    const { result, rerender } = renderHook(
      (props) => {
        return useScanData(props);
      },
      {
        initialProps,
      }
    );
    await waitFor(() => expect(result.current?.data?.foo2).toBeDefined(), {
      timeout: 5000,
    });
    rerender({ ...initialProps, stop: 8 });
    await waitFor(() => expect(result.current?.data?.foo2).toBeDefined(), {
      timeout: 5000,
    });
    expect(result.current.data.foo2?.data).toStrictEqual(
      Uint16Array.from([1, 2, 3, 4, 5, 6, 7, 8])
    );
  });
  test('Image channel', async () => {
    const initialProps = {
      scanId: 10,
      channelNames: ['image1'],
      start: 0,
      stop: 1,
    };
    const { result } = renderHook(
      (props) => {
        return useScanData(props);
      },
      {
        initialProps,
      }
    );
    await waitFor(() => expect(result.current?.data?.image1).toBeDefined(), {
      timeout: 5000,
    });
    expect(result.current.data.image1?.shape).toStrictEqual([1, 2, 2]);
    expect(result.current.data.image1?.data?.buffer).toStrictEqual(
      Uint8Array.from([0, 1, 2, 3]).buffer
    );
  });
});
