import React, { useMemo } from 'react';
import { Anchor } from './Anchor';
import type { Angle2LineRoiGeometry } from './geometries';
import { Annotation } from '@h5web/lib';
import { ArrowedLine } from '../shapes/ArrowedLine';

export function Angle2LineRoi(props: {
  geometry: Angle2LineRoiGeometry;
  zIndex?: number;
  lineWidth?: number;
  color?: string;
  color1?: string;
  color2?: string;
  opacity?: number;
  readOnly?: boolean;
  readOnly1?: boolean;
  readOnly2?: boolean;
  visible?: boolean;
  visible1?: boolean;
  visible2?: boolean;
  onGeometryChanged?: (
    geometry: Angle2LineRoiGeometry,
    dragging: boolean
  ) => void;
}) {
  const {
    geometry: pos,
    lineWidth = 2,
    color = 'blue',
    color1 = color,
    color2 = color,
    opacity = 1,
    zIndex = 1,
    visible = true,
    visible1 = visible,
    visible2 = visible,
    readOnly = props.onGeometryChanged === undefined,
    readOnly1 = readOnly,
    readOnly2 = readOnly,
  } = props;

  const angle = useMemo(() => {
    if (!visible1 && !visible2) {
      return 0;
    }
    const dy1 = pos.y11 - pos.y12;
    const dy2 = pos.y21 - pos.y22;
    const m1 = dy1 === 0 ? 0 : (pos.x11 - pos.x12) / dy1;
    const m2 = dy2 === 0 ? 0 : (pos.x21 - pos.x22) / dy2;
    const rad = Math.atan((m2 - m1) / (1 + m1 * m2));
    return (rad * 180) / Math.PI;
  }, [pos, visible1, visible2]);

  const text = useMemo(() => {
    if (!visible1 && !visible2) {
      return '';
    }
    const posAngle = Math.abs(angle);
    if (posAngle < 0.001) {
      return `${(posAngle * 1_000_000).toFixed(2)} µdeg`;
    }
    if (posAngle < 1) {
      return `${(posAngle * 1000).toFixed(2)} mdeg`;
    }
    return `${posAngle.toFixed(2)} deg`;
  }, [angle, visible1, visible2]);

  if (!visible1 && !visible2) {
    return <></>;
  }

  function xy11Changed(localPos: { x: number; y: number }, dragging: boolean) {
    const { x, y } = localPos;
    props.onGeometryChanged?.({ ...pos, x11: x, y11: y }, dragging);
  }

  function xy12Changed(localPos: { x: number; y: number }, dragging: boolean) {
    const { x, y } = localPos;
    props.onGeometryChanged?.({ ...pos, x12: x, y12: y }, dragging);
  }

  function xy21Changed(localPos: { x: number; y: number }, dragging: boolean) {
    const { x, y } = localPos;
    props.onGeometryChanged?.({ ...pos, x21: x, y21: y }, dragging);
  }

  function xy22Changed(localPos: { x: number; y: number }, dragging: boolean) {
    const { x, y } = localPos;
    props.onGeometryChanged?.({ ...pos, x22: x, y22: y }, dragging);
  }

  const x0 = (pos.x11 + pos.x12 + pos.x21 + pos.x22) * 0.25;
  const y0 = (pos.y11 + pos.y12 + pos.y21 + pos.y22) * 0.25;

  return (
    <>
      {visible1 && (
        <ArrowedLine
          tail={[pos.x11, pos.y11]}
          head={[pos.x12, pos.y12]}
          lineWidth={lineWidth}
          color={color1}
          opacity={opacity}
          zIndex={zIndex}
          arrowHead
        />
      )}
      {visible2 && (
        <ArrowedLine
          tail={[pos.x21, pos.y21]}
          head={[pos.x22, pos.y22]}
          lineWidth={lineWidth}
          color={color2}
          opacity={opacity}
          zIndex={zIndex}
          arrowHead
        />
      )}
      {!readOnly && (
        <>
          <Anchor
            geometry={{ x: pos.x11, y: pos.y11 }}
            zIndex={zIndex}
            color={color1}
            opacity={opacity}
            visible={readOnly1}
            onGeometryChanged={xy11Changed}
          />
          <Anchor
            geometry={{ x: pos.x12, y: pos.y12 }}
            zIndex={zIndex}
            color={color1}
            opacity={opacity}
            visible={readOnly1}
            onGeometryChanged={xy12Changed}
          />
          <Anchor
            geometry={{ x: pos.x21, y: pos.y21 }}
            zIndex={zIndex}
            color={color2}
            opacity={opacity}
            visible={readOnly2}
            onGeometryChanged={xy21Changed}
          />
          <Anchor
            geometry={{ x: pos.x22, y: pos.y22 }}
            zIndex={zIndex}
            color={color2}
            opacity={opacity}
            visible={readOnly2}
            onGeometryChanged={xy22Changed}
          />
        </>
      )}
      <Annotation x={x0} y={y0} style={{ zIndex: 100 }} center>
        <div
          className="text-light p-1 rounded"
          style={{ backgroundColor: '#000000A0' }}
        >
          {text}
        </div>
      </Annotation>
    </>
  );
}
