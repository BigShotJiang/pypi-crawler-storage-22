import{r as m,b6 as se,b7 as ue,b8 as fe,b9 as de,ba as me,bb as q,bc as xe,bd as ve,be as Q,bf as ge,bg as he,aQ as be,aU as ae,aX as H,j as i,aV as re,I as Y,F as oe,aL as ye,aH as Ce,aW as Se}from"./index-b3c0133a.js";import{o as W,h as ze}from"./index-a9bb7636.js";import{N as _e}from"./hooks-171c0765.js";import{A as U,d as Z}from"./colormap-6e43299c.js";import{S as $}from"./ScreenScale-b2417934.js";import{D as ie,S as Ne,Z as Ae,a as Re,A as M}from"./DraggableRect-25d91c7d.js";import{D as Ie}from"./DropdownButton-29cc265b.js";import{u as Oe}from"./UseMouseModeInteraction-51c6269c.js";import{A as k}from"./Anchor-0b4a3d33.js";import{H as J,V as K}from"./VSegmentRoi-d5e035cc.js";import{c as Te,L as p}from"./Label-9d8979b3.js";function X(e){const n=m.useRef();return m.useEffect(()=>{n.current=e}),n.current}var O=(e=>(e[e.NONE=0]="NONE",e[e.LAPLACIAN_3x3=1]="LAPLACIAN_3x3",e[e.LAPLACIAN_9x9=2]="LAPLACIAN_9x9",e[e.SHARPENING_3x3=3]="SHARPENING_3x3",e[e.UNSHARPENING_3x3=4]="UNSHARPENING_3x3",e[e.UNSHARPENING_5x5=5]="UNSHARPENING_5x5",e[e.SMOOTH_3x3=6]="SMOOTH_3x3",e[e.SMOOTH_5x5=7]="SMOOTH_5x5",e[e.SMOOTH_7x7=8]="SMOOTH_7x7",e))(O||{});const P={0:{name:"No filter",size:0,coefs:Float32Array.from([0,0,0,0,0,0,0,0,0])},1:{name:"Laplacian 3×3",size:3,coefs:Float32Array.from([0,-1,0,-1,4,-1,0,-1,0])},2:{name:"Laplacian 9×9",size:9,coefs:Float32Array.from([0,1,1,2,2,2,1,1,0,1,2,4,5,5,5,4,2,1,1,4,5,3,0,3,5,4,1,2,5,3,-12,-24,-12,3,5,2,2,5,0,-24,-40,-24,0,5,2,2,5,3,-12,-24,-12,3,5,2,1,4,5,3,0,3,5,4,1,1,2,4,5,5,5,4,2,1,0,1,1,2,2,2,1,1,0])},3:{name:"Sharpening 3×3",size:3,coefs:Float32Array.from([-1,-1,-1,-1,9,-1,-1,-1,-1])},4:{name:"Unsharpening 3×3",size:3,coefs:Float32Array.from([0,-1,0,-1,5,-1,0,-1,0])},5:{name:"Unsharpening 5×5",size:5,coefs:Float32Array.from([1/256,4/256,6/256,4/256,1/256,4/256,16/256,24/256,16/256,4/256,6/256,24/256,-476/256,24/256,6/256,4/256,16/256,24/256,16/256,4/256,1/256,4/256,6/256,4/256,1/256])},6:{name:"Gaussian 3×3",size:3,coefs:Float32Array.from([1/16,2/16,1/16,2/16,4/16,2/16,1/16,2/16,1/16])},7:{name:"Gaussian 5×5",size:5,coefs:Float32Array.from([1/273,4/273,7/273,4/273,1/273,4/273,16/273,26/273,16/273,4/273,7/273,26/273,41/273,26/273,7/273,4/273,16/273,26/273,16/273,4/273,1/273,4/273,7/273,4/273,1/273])},8:{name:"Gaussian 7×7",size:7,coefs:Float32Array.from([1/4096,6/4096,15/4096,20/4096,15/4096,6/4096,1/4096,6/4096,36/4096,90/4096,120/4096,90/4096,36/4096,6/4096,15/4096,90/4096,225/4096,300/4096,225/4096,90/4096,15/4096,20/4096,120/4096,300/4096,400/4096,300/4096,120/4096,20/4096,15/4096,90/4096,225/4096,300/4096,225/4096,90/4096,15/4096,6/4096,36/4096,90/4096,120/4096,90/4096,36/4096,6/4096,1/4096,6/4096,15/4096,20/4096,15/4096,6/4096,1/4096])}},Fe={float32:xe,float16:ve,uint8:Q,uint16:ge,uint32:he,uint8_clamped:Q};function Ee(e,n){if(e===void 0)return;const[r,c]=e.shape,t=n!=null&&n.magNearest?se:ue,a=new fe(e.data,c,r,de,Fe[e.dtype],me,q,q,t);return a.needsUpdate=!0,a}function ee(e,n){return m.useMemo(()=>Ee(e,n),[e,n])}const ne="#### END OF HEADER ####";function ce(e){const n=e.indexOf(ne);return n===-1?e:e.slice(n+ne.length)}const je=`#version 400

// Shader used in threefiber context
// This code is concatenaed with threefiber headers
// So we specify this header for validation purpose
// But it is dropped before it is used by threefiber

// #### END OF HEADER ####
// Only the following code is passed to threefiber

struct Normalization {
    // data min
    float min;
    // data max
    float max;
    // 0: no normalization, 1: project 0..1 to min..max
    int mode;
};

struct Domain {
    float min;
    float max;
};

uniform sampler2D textureA;
uniform Normalization normA;
uniform sampler2D textureB;
uniform Normalization normB;

uniform int mode;
uniform float imageATranslationX;
uniform float imageARotation;
uniform float imageBTranslationX;
uniform float imageBRotation;
uniform float imageBFlipX;
uniform float sizeCoef;
uniform Domain domain;
uniform float verticalSeparator;
uniform int kernelSize;
uniform float kernelCoefs[9];

in vec2 texCoord;

vec2 rotatedVec2(vec2 uv, vec2 axis, float angle)
{
	mat2 m = mat2(
        vec2(cos(angle), -sin(angle)),
		vec2(sin(angle), cos(angle))
    );
    return (uv - axis) * m + axis;
}

/**
 * Convert a normalized texture into final data.
 */
float denormalize(float p, Normalization norm) {
    if (norm.mode == 0) {
        return p;
    }
    if (norm.mode == 1) {
        return norm.min + p * (norm.max - norm.min);
    }
    return -1.0;
}

float getPixel(
    vec2 coord,
    sampler2D textureN,
    Normalization normN,
    float rotation
) {
    ivec2 itexSize = textureSize(textureN, 0);
    vec2 texSize = vec2(itexSize) * 0.5;
    coord = (coord - vec2(0.5, 0.5)) * texSize;
    coord = rotatedVec2(coord, vec2(0.0, 0.0), rotation);
    coord = (coord / texSize) + vec2(0.5, 0.5);

    if (coord.x < 0.0) { return -1.0; }
    if (coord.x > 1.0) { return -1.0; }
    if (coord.y < 0.0) { return -1.0; }
    if (coord.y > 1.0) { return -1.0; }
    float p = texture2D(textureN, coord).r;
    p = denormalize(p, normN);
    p = (p - domain.min) / (domain.max - domain.min);
    p = clamp(p, 0.0, 1.0);
    return p;
}

float getFilteredPixel(
    vec2 coord,
    sampler2D textureN,
    Normalization normN,
    float rotation
) {
    ivec2 itexSize = textureSize(textureN, 0);
    vec2 texSize = vec2(itexSize) * 0.5;
    coord = (coord - vec2(0.5, 0.5)) * texSize;

    float cum_p = 0.0;
    int cum_coef = 0;
    int i = 0;

    for (int x = 0; x < kernelSize; x++) {
        for (int y = 0; y < kernelSize; y++) {
            vec2 xy = vec2(x - (kernelSize - 1) / 2, y - (kernelSize - 1) / 2);
            vec2 coord2 = rotatedVec2(coord + xy * 1.0, vec2(0.0, 0.0), rotation);
            coord2 = (coord2 / texSize) + vec2(0.5, 0.5);

            float coef = kernelCoefs[i];
            i++;

            if (coord2.x < 0.0) { continue; }
            if (coord2.x > 1.0) { continue; }
            if (coord2.y < 0.0) { continue; }
            if (coord2.y > 1.0) { continue; }

            float p = texture2D(textureN, coord2).r;
            p = denormalize(p, normN);
            p = (p - domain.min) / (domain.max - domain.min);
            p = clamp(p, 0.0, 1.0);
            cum_p += p * coef;
            cum_coef++;
        }
    }
    if (cum_coef == 0) {
        return -1.0;
    }
    return clamp(cum_p, 0.0, 1.0);
}

vec4 colorize_a(float a, float b) {
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    return vec4(a, a, a, 1.0);
}

vec4 colorize_b(float a, float b) {
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }
    return vec4(b, b, b, 1.0);
}

vec4 colorize_mul(float a, float b) {
    // multiply
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }
    float m = a * b;
    return vec4(m, m, m, 1.0);
}

vec4 colorize_mul_color(float a, float b) {
    // multiply
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }
    float m = a * b;
    return vec4(m, (b + a ) * 0.5,  b, 1.0);
}

vec4 colorize_diff(float a, float b) {
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }
    float i = 0.5 + (a - b);
    return vec4(i, i, i, 1.0);
}

vec4 colorize_diff_color(float a, float b) {
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }

    float i = (a - b) * 10.0;
    if (i > 1.0) {
        i = 1.0;
    }

    float da = (i > 0.0) ? i : 0.0;
    float db = (i < 0.0) ? -i : 0.0;
    return vec4(1.0 - da - db * 0.5, 1.0, 1.0 - db * 0.5, 1.0);
}

vec4 colorize_min(float a, float b) {
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }
    float m = min(a, b);
    return vec4(m, m, m, 1.0);
}

vec4 colorize_min_color(float a, float b) {
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }
    float m = min(a, b);
    return vec4(m, (b + a ) * 0.5,  b, 1.0);
}

vec4 colorize_max(float a, float b) {
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }
    float m = max(a, b);
    return vec4(m, m, m, 1.0);
}

vec4 colorize_max_color(float a, float b) {
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }
    float m = max(a, b);
    return vec4(min(a, b), m, a, 1.0);
}

vec4 colorize_error(float a, float b) {
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }
    float error = sqrt(abs(a - b));
    float i = 1.0 - error;
    return vec4(i, i, i, 1.0);
}

vec4 colorize_error_color(float a, float b) {
    if (a < 0.0) {
        return vec4(0.0, b, 0.0, 0.75);
    }
    if (b < 0.0) {
        return vec4(0.0, a, a, 0.75);
    }
    float d = a - b;
    float s = sign(d);

    float i = 1.0 - abs(d);
    i = i * i * i;
    float da = (s > 0.0) ? i : 0.0;
    float db = (s < 0.0) ? i : 0.0;
    return vec4(1.0 - da - db * 0.6, 1.0, 1.0 - db * 0.6, 1.0);
}

vec4 colorize_hspliter(float a, float b) {
    ivec2 itexSize = textureSize(textureA, 0);
    vec2 texSize = vec2(itexSize);
    if (-((texCoord.y - 0.5) * texSize.y * sizeCoef) < verticalSeparator) {
        if (a < 0.0) {
            discard;
        }
        return vec4(a, a, a, 1.0);
    } else {
        if (b < 0.0) {
            discard;
        }
        return vec4(b, b, b, 1.0);
    }
}

vec4 colorize_hspliter_color(float a, float b) {
    ivec2 itexSize = textureSize(textureA, 0);
    vec2 texSize = vec2(itexSize);
    if (-((texCoord.y - 0.5) * texSize.y * sizeCoef) < verticalSeparator) {
        if (a < 0.0) {
            discard;
        }
        return vec4(0.0, a, a, 1.0);
    } else {
        if (b < 0.0) {
            discard;
        }
        return vec4(0.0, b, 0.0, 1.0);
    }
}

vec4 colorize_custom_func(float a, float b) {
    // CUSTOM FUNC INJECTION //;
    return vec4(0.0, 0.0, 0.0, 1.0);
}


/*
// error without killing the content
    float error = sqrt(abs(a - b));
    float i = 1.0 - error;
    float m = 1.0 - max(a,b);
    return vec4(i, 1.0 - a, 1.0 - b, 1.0);


*/


float pixelToTexture(float pixel, sampler2D textureN) {
    ivec2 itexSize = textureSize(textureN, 0);
    vec2 texSize = vec2(itexSize);
    float size = max(texSize.x, texSize.y);
    return pixel / size;
}

void main() {
    float transTexA = pixelToTexture(imageATranslationX, textureA);
    vec2 texCoordA = vec2(texCoord.x + transTexA, texCoord.y);

    float coefB;
    float transTexB = pixelToTexture(-imageBTranslationX, textureB);
    vec2 texCoordB;
    if (imageBFlipX > 0.0) {
        // mirrored
        coefB = -1.0;
        texCoordB = vec2(1.0 - texCoord.x + transTexB, texCoord.y);
    } else {
        coefB = 1.0;
        texCoordB = vec2(texCoord.x + transTexB, texCoord.y);
    }

    float a;
    float b;
    if (kernelSize == 0) {
        a = getPixel(texCoordA, textureA, normA, imageARotation);
        b = getPixel(texCoordB, textureB, normB, coefB * imageBRotation);
    } else {
        a = getFilteredPixel(texCoordA, textureA, normA, imageARotation);
        b = getFilteredPixel(texCoordB, textureB, normB, coefB * imageBRotation);
    }

    if (a < 0.0 && b < 0.0) {
        discard;
    }

    vec4 c;
    switch (mode) {
        case 0:
            discard;
        case 1:
            c = colorize_a(a, b);
            break;
        case 2:
            c = colorize_b(a, b);
            break;

        case 100:
            c = colorize_diff(a, b);
            break;
        case 101:
            c = colorize_error(a, b);
            break;
        case 102:
            c = colorize_max(a, b);
            break;
        case 103:
            c = colorize_min(a, b);
            break;
        case 104:
            c = colorize_mul(a, b);
            break;
        case 105:
            c = colorize_hspliter(a, b);
            break;

        case 200:
            c = colorize_diff_color(a, b);
            break;
        case 201:
            c = colorize_error_color(a, b);
            break;
        case 202:
            c = colorize_max_color(a, b);
            break;
        case 203:
            c = colorize_min_color(a, b);
            break;
        case 204:
            c = colorize_mul_color(a, b);
            break;
        case 205:
            c = colorize_hspliter_color(a, b);
            break;

        case 300:
            c = colorize_custom_func(a, b);
            break;
        default:
            c = vec4(1.0, 0.0, 0.0, 1.0);
    }
    gl_FragColor = c;
}
`,we=`#version 400

// Shader used in threefiber context
// This code is concatenaed with threefiber headers
// So we specify this header for validation purpose
// But it is dropped before it is used by threefiber

in vec4 projectionMatrix;  // declared by threefiber
in vec4 modelViewMatrix;  // declared by threefiber
in vec3 position;  // declared by threefiber

// #### END OF HEADER ####
// Only the following code is passed to threefiber

uniform sampler2D proj0Map;
uniform float sizeCoef;
out vec2 texCoord;

void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    // texCoord = ((gl_Position.xy - vec2(-2.5)) / 5.0);
    ivec2 itexSize = textureSize(proj0Map, 0);
    vec2 texSize = vec2(itexSize);
    texCoord = (vec2(position.x, -position.y) / (texSize*sizeCoef)) + 0.5;
}
`,V=ce(je),Be=ce(we);be("daiquiri.components.h5web.items.CompareMesh");var Le=(e=>(e[e.EMPTY=0]="EMPTY",e[e.IMAGE_A=1]="IMAGE_A",e[e.IMAGE_B=2]="IMAGE_B",e[e.DIFF=100]="DIFF",e[e.ERROR=101]="ERROR",e[e.MAX=102]="MAX",e[e.MIN=103]="MIN",e[e.MUL=104]="MUL",e[e.HSPLITTER=105]="HSPLITTER",e[e.DIFF_COLOR=200]="DIFF_COLOR",e[e.ERROR_COLOR=201]="ERROR_COLOR",e[e.MAX_COLOR=202]="MAX_COLOR",e[e.MIN_COLOR=203]="MIN_COLOR",e[e.MUL_COLOR=204]="MUL_COLOR",e[e.HSPLITTER_COLOR=205]="HSPLITTER_COLOR",e[e.CUSTOM=300]="CUSTOM",e))(Le||{});class Pe extends re{constructor(){super({uniforms:{textureA:{value:null},normA:{value:{min:0,max:0,mode:0}},textureB:{value:null},normB:{value:{min:0,max:0,mode:0}},mode:{value:0},sizeCoef:{value:1},imageARotation:{value:0},imageATranslationX:{value:0},imageBRotation:{value:0},imageBTranslationX:{value:0},imageBFlipX:{value:0},domain:{value:{min:0,max:1}},verticalSeparator:{value:0},kernelCoefs:{value:Float32Array.from([0,0,0,0,0,0,0,0,0])},kernelSize:{value:0}}})}}ae({CompareMaterial:Pe});function Me(e,n,r){return n===1||(n===105||n===205)&&e.y<r?-1:1}function ke(e){const{translationA:n,translationB:r,threshold:c=4,displayMode:t,verticalSeparator:a,disabled:f}=e,l=m.useRef(void 0),u=m.useCallback(o=>{const s=Me(o.dataPt,t,a);l.current={translationA:n,translationB:r,startData:o.dataPt,startScreen:o.htmlPt,gestureStarted:!1,coef:s}},[n,r,t,a]),d=m.useCallback(o=>{const s=l.current;if(s===void 0)return!1;const{htmlPt:S}=o;return Math.max(Math.abs(S.x-s.startScreen.x),Math.abs(S.y-s.startScreen.y))<=c},[c]),v=m.useCallback(o=>{const s=l.current;if(s===void 0)return;if(!s.gestureStarted){if(d(o))return;l.current={...s,gestureStarted:!0}}const S=o.dataPt.x-s.startData.x;e.onIntermediateChanged(s.translationA+S*s.coef,s.translationB+S*s.coef)},[d,e.onIntermediateChanged]),b=m.useCallback(o=>{const s=l.current;if(s){const S=o.dataPt.x-s.startData.x;e.onChanged(s.translationA+S*s.coef,s.translationB+S*s.coef)}l.current=void 0},[d,e.onChanged]);function _(){return W("pointerdown",u),W("pointermove",v),W("pointerup",b),i.jsx(i.Fragment,{})}return i.jsx(i.Fragment,{children:!f&&i.jsx(_,{})})}function Ge(e,n,r){switch(e){case U.None:return[0,1];case U.Minmax:return[Math.min(n.min??0,r.min??0),Math.max(n.max??1,r.max??1)];case U.StdDev3:{const c=Math.min(n.min??0,r.min??0),t=Math.max(n.max??1,r.max??1),a=((n.mean??.5)+(r.mean??.5))*.5,f=((n.std??.5)+(r.std??.5))*.5;return[Math.max(c,a-3*f),Math.min(t,a+3*f)]}default:console.warn(`Unsupported norm ${e}`)}return[0,1]}function pe(e){var N;const n=m.useRef(null),{displayMode:r=1,imageARotation:c=0,imageATranslationX:t=0,imageBRotation:a=0,imageBTranslationX:f=0,imageBFlipX:l=!0,autoScale:u=U.None,stateA:d,stateB:v,verticalSeparator:b=0,customFunc:_,filterMode:o=O.NONE,translationXInteration:s=!1,pixelSize:S}=e,[F,B]=m.useState(0),A=m.useMemo(()=>S===void 0?1:S,[e.pixelSize]),L=m.useMemo(()=>_===void 0?V:V.replace("// CUSTOM FUNC INJECTION //",_),[V,_]),E=ee(e.imageA,{magNearest:!0}),R=ee(e.imageB,{magNearest:!0}),[T,I]=m.useMemo(()=>{if(o in P){const{size:w,coefs:le}=P[o];return[w,le]}console.log(`Unsupported ${o}`);const{size:x,coefs:j}=P[O.NONE];return[x,j]},[o]);m.useEffect(()=>{B(x=>x+1)},[L]);const y=m.useMemo(()=>d===void 0||v===void 0?d!==void 0?Z(u,d):v!==void 0?Z(u,v):[0,1]:Ge(u,d,v),[d,v,u]),g=m.useMemo(()=>E===void 0||R===void 0?r<10?r:E!==void 0?1:R!==void 0?2:0:r,[r,E===void 0,R===void 0]);m.useEffect(()=>{if(n.current){const x=n.current.uniforms;x.mode.value=g,x.sizeCoef.value=A,x.imageARotation.value=c,x.imageATranslationX.value=t,x.imageBRotation.value=a,x.imageBTranslationX.value=f,x.imageBFlipX.value=l?1:0,x.domain.value={min:y[0],max:y[1]},x.verticalSeparator.value=b,x.kernelCoefs.value=I,x.kernelSize.value=T,H()}},[n.current,g,A,c,t,a,f,l,d,v,y,b,I,T,F]);function C(x){return x instanceof _e?{min:x.transfer.min,max:x.transfer.max,mode:1}:{min:0,max:0,mode:0}}m.useEffect(()=>{if(n.current){const x=n.current.uniforms;x.textureA.value=E,x.normA.value=C(e.imageA),H()}},[F,E,n.current]),m.useEffect(()=>{if(n.current){const x=n.current.uniforms;x.textureB.value=R,x.normB.value=C(e.imageB),H()}},[F,R,n.current]);const[z,h]=((N=e.imageA)==null?void 0:N.shape)??[1024,1024];return g===0?i.jsx(i.Fragment,{}):i.jsxs("mesh",{children:[i.jsx("planeGeometry",{attach:"geometry",args:[h*A*2,z*A*2,1,1]}),i.jsx(ke,{translationA:t*A,translationB:f*A,onChanged:(x,j)=>{var w;(w=e.onTranslationXChanged)==null||w.call(e,.5*x/A,.5*j/A)},onIntermediateChanged:(x,j)=>{var w;(w=e.onTranslationXIntermediateChanged)==null||w.call(e,.5*x/A,.5*j/A)},threshold:0,displayMode:r,verticalSeparator:b,disabled:!s}),i.jsx("compareMaterial",{attach:"material",ref:n,vertexShader:Be,fragmentShader:L},F)]})}function D(e,n,r,c){if(n===r)return e;if(n==="rad"&&r==="deg")return 180*e/Math.PI;if(n==="deg"&&r==="rad")return Math.PI*e/180;if(n==="px"){if(c!==void 0){const t=c.to("mm").scalar;return D(e*t,"mm",r,void 0)}return Number.NaN}if(r==="px"){if(c!==void 0){const t=D(e,n,"mm",void 0),a=c.to("mm").scalar;return t/a}return Number.NaN}try{return ye(e,n).to(r).scalar}catch{return console.error(`Convertion ${n}->${r} is not provided`),Number.NaN}}function He(e){return e==="um"?"μm":e}function en(e){const{style:n,className:r,decimals:c=2}=e,t=m.useRef(null),a=m.useRef(void 0),[f,l]=m.useState(!1),u=m.useMemo(()=>e.preferedDisplayUnit!==void 0&&(e.pixelSize===void 0||e.unit==="px"||e.preferedDisplayUnit==="px")?e.preferedDisplayUnit:e.displayUnit??e.unit,[e.displayUnit,e.unit,e.preferedDisplayUnit,e.pixelSize]),d=m.useCallback(o=>{if(!(o===void 0||u===void 0))return D(o,u,e.unit,e.pixelSize)},[e.unit,u,e.pixelSize]),v=m.useCallback(o=>{if(!(o===void 0||u===void 0))return D(o,e.unit,u,e.pixelSize)},[e.unit,u,e.pixelSize]);function b(){var S;if(a.current===void 0)return;const o=a.current,s=d(o);a.current=void 0,t.current&&(t.current.value=o.toFixed(c)),s!==void 0&&((S=e.onChange)==null||S.call(e,s)),l(!1)}function _(){var o;a.current!==void 0&&(a.current=void 0,t.current&&(t.current.value=((o=v(e.value))==null?void 0:o.toFixed(c))??""),l(!1))}return m.useEffect(()=>{var o;a.current||t.current&&(t.current.value=((o=v(e.value))==null?void 0:o.toFixed(c))??"")},[e.value]),i.jsxs(Y,{className:r,style:n,children:[i.jsx(oe.Control,{ref:t,step:e.step,type:"number",style:{backgroundColor:f?"#FFFF80":"transparent"},onChange:o=>{l(!0),a.current=Number.parseFloat(o.target.value)},onBlur:()=>{_()},onKeyDown:o=>/^[ a-z]$/i.test(o.key)?(o.preventDefault(),!1):(o.stopPropagation(),o.key==="Enter"&&b(),!0)}),i.jsx(Y.Text,{children:He(u)})]})}function nn(e){const{geometry:n,lineWidth:r=2,color:c="blue",opacity:t=1,zIndex:a=1,visible:f=!0,readOnly:l=e.onGeometryChanged===void 0}=e,[u,d]=m.useState(!1);return f?i.jsxs("group",{position:[0,n.y,a],children:[i.jsx($,{children:i.jsx(ie,{pos:[0,n.y],size:[999999,Ne],pointer:"ns-resize",zIndex:a+Ae,enabled:!l,onPositionChanged:(v,b)=>{var _;(_=e.onGeometryChanged)==null||_.call(e,{y:v[1]},b)},onEnter:()=>{d(!0)},onLeave:()=>{d(!1)}})}),i.jsx("group",{children:i.jsx($,{children:i.jsxs("mesh",{children:[i.jsx("ambientLight",{}),i.jsx("planeGeometry",{attach:"geometry",args:[999999,u?Re:r,1,1]}),i.jsx("meshBasicMaterial",{attach:"material",transparent:!0,color:c,opacity:t})]})})})]}):i.jsx(i.Fragment,{})}function tn(e){const{as:n,onSelect:r,value:c}=e;function t(l){const{name:u}=P[l],d=l===O.NONE?"fa fa-fw fa-xmark":c===l?"fa fa-fw fa-circle-dot":"fa fa-fw fa-circle";return i.jsxs(Ce.Item,{eventKey:l,onClick:()=>{r(l)},children:[i.jsx("i",{className:d}),"  ",u]})}const{name:a}=P[c],f=c===O.NONE?"Apply a convolution filter":`Filter ${a} enabled`;return i.jsxs(Ie,{variant:c!==O.NONE?"primary":"secondary",as:n,title:i.jsx("i",{title:f,className:"fa fa-filter fa-fw fa-lg"}),id:"bg-vertical-dropdown-6",children:[t(O.NONE),t(O.LAPLACIAN_3x3),t(O.LAPLACIAN_9x9),t(O.SHARPENING_3x3),t(O.UNSHARPENING_3x3),t(O.UNSHARPENING_5x5),t(O.SMOOTH_3x3),t(O.SMOOTH_5x5),t(O.SMOOTH_7x7)]})}function an(e){const{value:n,range:r,step:c,title:t}=e,a=m.useRef({value:0,dragging:!1}),[f,l]=m.useState(void 0),u=f??n;return i.jsx(oe.Range,{min:u===void 0?u:u-r*.5,max:u===void 0?u:u+r*.5,value:n,title:t,step:c,onChange:d=>{var b,_;if(f===void 0)return;const v=Number.parseFloat(d.target.value);a.current.value=v,a.current.dragging?(b=e.onIntermediateChange)==null||b.call(e,v):(_=e.onChange)==null||_.call(e,v)},onMouseDown:d=>{l(n),a.current.dragging=!0},onMouseUp:d=>{var v;l(void 0),a.current.dragging=!1,(v=e.onChange)==null||v.call(e,a.current.value)}})}function rn(e){const{updateRoi:n,tiltRad:r,lateralMM:c,pixelSize:t}=e,a=X(r),f=(t==null?void 0:t.scalar)??1,l=c,u=X(l),d=X(f);function v(o,s,S){if(o===void 0)return;const{x11:F,y11:B,x12:A,y12:L,x21:E,y21:R,x22:T,y22:I}=o,y=S/s;return{x11:F*y,y11:B*y,x12:A*y,y12:L*y,x21:E*y,y21:R*y,x22:T*y,y22:I*y}}function b(o,s){if(o===void 0)return;const{x11:S,y11:F,x12:B,y12:A,x21:L,y21:E,x22:R,y22:T}=o;function I(h,N,x){const j=Math.cos(x),w=Math.sin(x);return[h*j-N*w,h*w+N*j]}const y=I(S,F,s),g=I(B,A,s),C=I(L,E,-s),z=I(R,T,-s);return{x11:y[0],y11:y[1],x12:g[0],y12:g[1],x21:C[0],y21:C[1],x22:z[0],y22:z[1]}}function _(o,s){if(o===void 0)return;const{x11:S,x12:F,x21:B,x22:A}=o;return{...o,x11:S-s,x12:F-s,x21:B+s,x22:A+s}}m.useMemo(()=>{a!==void 0&&r!==a&&n(o=>b(o,r-a))},[r,a,n]),m.useMemo(()=>{u!==void 0&&l!==u&&n(o=>_(o,l-u))},[l,u,n]),m.useMemo(()=>{d!==void 0&&f!==d&&n(o=>v(o,d,f))},[f,d,n])}function on(e){const{updateRoi:n,pixelSize:r}=e,c=(r==null?void 0:r.scalar)??1,t=X(c);function a(f,l,u){if(f===void 0)return;const{x1:d,y1:v,x2:b,y2:_}=f,o=u/l;return{x1:d*o,y1:v*o,x2:b*o,y2:_*o}}m.useMemo(()=>{t!==void 0&&c!==t&&n(f=>a(f,t,c))},[c,t,n])}class Ue extends re{constructor(){super({uniforms:{color:{value:new Se},lineWidth:{value:0},sizeInScreen:{value:0},angle:{value:0}},vertexShader:`
out vec2 pixelCoord;

void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    pixelCoord = vec2(position.x, position.y);
}
      `,fragmentShader:`
// Based on antialiased arrow fields
// Nicolas P. Rougier (http://www.loria.fr/~rougier)
// https://www.shadertoy.com/view/ldlSWj
// Released under BSD license.

uniform vec4 color;
uniform float lineWidth;
uniform float sizeInScreen;
uniform float angle;
in vec2 pixelCoord;

// Computes the signed distance from a line
float sdf_line(vec2 p, vec2 p1, vec2 p2) {
    vec2 center = (p1 + p2) * 0.5;
    float len = length(p2 - p1);
    vec2 dir = (p2 - p1) / len;
    vec2 rel_p = p - center;
    return dot(rel_p, vec2(dir.y, -dir.x));
}

// Computes the signed distance from a line segment
float sdf_segment(vec2 p, vec2 p1, vec2 p2) {
    vec2 center = (p1 + p2) * 0.5;
    float len = length(p2 - p1);
    vec2 dir = (p2 - p1) / len;
    vec2 rel_p = p - center;
    float dist1 = abs(dot(rel_p, vec2(dir.y, -dir.x)));
    float dist2 = abs(dot(rel_p, dir)) - 0.5*len;
    return max(dist1, dist2);
}

float sdf_arrow(vec2 texcoord,
  float body, float head, float height,
  float linewidth, float antialias
) {
  float d;
  float w = linewidth/2.0 + antialias;
  vec2 start = -vec2(body, 0.0);
  vec2 end   = +vec2(0.0, 0.0);

  // Arrow tip (beyond segment end)
  if( texcoord.x > body / 2.0) {
    // Head : 2 segments
    float d1 = sdf_line(texcoord, end, end - head*vec2(+1.0, -height));
    float d2 = sdf_line(texcoord, end - head*vec2(+1.0, +height), end);
    d = max(d1, d2);
  } else {
    // Head : 2 segments
    float d1 = sdf_segment(texcoord, end - head * vec2(+1.0, -height), end);
    float d2 = sdf_segment(texcoord, end - head * vec2(+1.0, +height), end);
    d = min(d1, d2);
  }
  return d;
}

vec4 filled(float distance, float linewidth, float antialias, vec4 fill)
{
    vec4 frag_color;
    float t = linewidth / 2.0 - antialias;
    float signed_distance = distance;
    float border_distance = abs(signed_distance) - t;
    float alpha = border_distance / antialias;
    alpha = exp(-alpha * alpha);

    // Within linestroke
    if (border_distance < 0.0) {
        return fill;
    }
    // Within shape
    if (signed_distance < 0.0) {
      return fill;
    }
    // Outside shape
    if (border_distance > (linewidth / 2.0 + antialias)) {
        discard;
    }
    // Line stroke exterior border
    return vec4(fill.rgb, alpha);
}

void main() {
    const float M_PI = 3.1415926535897932384626433832795;

    float theta = angle * M_PI / 180.0;
    float cos_theta = cos(theta);
    float sin_theta = sin(theta);
    vec2 pixelCoord2 = vec2(
      cos_theta * pixelCoord.x - sin_theta * pixelCoord.y,
      sin_theta * pixelCoord.x + cos_theta * pixelCoord.y
    );

    const float antialias = 1.0;
    float body = sizeInScreen;
    float d = sdf_arrow(pixelCoord2, body, 0.3 * body, 0.8, lineWidth, antialias);
    gl_FragColor = filled(d, lineWidth, antialias, color);
}
    `})}}ae({ArrowHeadMarkerMaterial:Ue});function G(e){const{x:n,y:r,color:c="black",opacity:t,sizeInScreen:a,angle:f,lineWidth:l=1,zIndex:u=0}=e,d=m.useRef(null);return m.useEffect(()=>{const v=Te(c,t);if(d.current){const b=d.current.uniforms;b.color.value=v,b.lineWidth.value=l,b.sizeInScreen.value=a,b.angle.value=f,H()}},[c,t,l,a,f]),i.jsx("group",{position:[n,r,u],children:i.jsx($,{screenDirection:!1,children:i.jsxs("mesh",{children:[i.jsx("ambientLight",{}),i.jsx("planeGeometry",{attach:"geometry",args:[a+l,a+l,1,1]}),i.jsx("arrowHeadMarkerMaterial",{attach:"material",transparent:!0,ref:d})]})})})}function te(e,n){return{x1:e.x,y1:e.y,x2:n.x,y2:n.y}}function cn(e){const{enabled:n=!0,setIntermediateRoi:r,setRoi:c}=e,t=Oe();return i.jsx(ze,{id:"selection-tool-rect",disabled:!n,onSelectionChange:a=>{if(a===void 0)return;const f=te(a.data[0],a.data[1]);r==null||r(f)},onSelectionStart:()=>{t==null||t.actions.captureMouseInteraction()},onSelectionEnd:()=>{t==null||t.actions.releaseMouseInteraction()},onValidSelection:a=>{const f=te(a.data[0],a.data[1]);c(f)},children:a=>i.jsx(i.Fragment,{})})}function ln(e){const{geometry:n,lineWidth:r=2,color:c="blue",opacity:t=1,zIndex:a=1,visible:f=!0,readOnly:l=e.onGeometryChanged===void 0}=e,u=e.unit===void 0?"":` ${e.unit}`;if(!f)return i.jsx(i.Fragment,{});const d=n.x1<n.x2==n.y1<n.y2,v=d?"nesw-resize":"nwse-resize",b=d?"nwse-resize":"nesw-resize";function _(g,C){var N;const{x:z,y:h}=g;(N=e.onGeometryChanged)==null||N.call(e,{...n,x1:z,y1:h},C)}function o(g,C){var N;const{x:z,y:h}=g;(N=e.onGeometryChanged)==null||N.call(e,{...n,x1:z,y2:h},C)}function s(g,C){var N;const{x:z,y:h}=g;(N=e.onGeometryChanged)==null||N.call(e,{...n,x2:z,y1:h},C)}function S(g,C){var N;const{x:z,y:h}=g;(N=e.onGeometryChanged)==null||N.call(e,{...n,x2:z,y2:h},C)}function F(g,C){var h;const{x:z}=g;(h=e.onGeometryChanged)==null||h.call(e,{...n,x1:z},C)}function B(g,C){var h;const{x:z}=g;(h=e.onGeometryChanged)==null||h.call(e,{...n,x2:z},C)}function A(g,C){var h;const{y:z}=g;(h=e.onGeometryChanged)==null||h.call(e,{...n,y1:z},C)}function L(g,C){var h;const{y:z}=g;(h=e.onGeometryChanged)==null||h.call(e,{...n,y2:z},C)}function E(g,C){var j;const{x1:z,x2:h,y1:N,y2:x}=n;(j=e.onGeometryChanged)==null||j.call(e,{x1:g[0],y1:g[1],x2:g[0]+(h-z),y2:g[1]+(x-N)},C)}const R=(n.x1+n.x2)*.5,T=(n.y1+n.y2)*.5,I=Math.abs(n.x1-n.x2),y=Math.abs(n.y1-n.y2);return i.jsxs(i.Fragment,{children:[i.jsx(ie,{pos:[n.x1,n.y1],displayPos:[R,T],size:[I,y],pointer:"move",zIndex:a,enabled:!l,onPositionChanged:E}),i.jsx(J,{geometry:{y:n.y1,x1:n.x1,x2:n.x2},zIndex:a,color:c,opacity:t,readOnly:l,lineWidth:r,onGeometryChanged:A}),i.jsx(G,{zIndex:a,sizeInScreen:M,lineWidth:r,x:R-I*.5,y:T-y*.5,angle:180,color:c,opacity:t}),i.jsx(G,{zIndex:a,sizeInScreen:M,lineWidth:r,x:R+I*.5,y:T-y*.5,angle:0,color:c,opacity:t}),i.jsx(G,{zIndex:a,sizeInScreen:M,lineWidth:r,x:R-I*.5,y:T-y*.5,angle:90,color:c,opacity:t}),i.jsx(G,{zIndex:a,sizeInScreen:M,lineWidth:r,x:R-I*.5,y:T+y*.5,angle:270,color:c,opacity:t}),i.jsx(J,{geometry:{y:n.y2,x1:n.x1,x2:n.x2},zIndex:a,color:c,opacity:t,readOnly:l,lineWidth:r,onGeometryChanged:L}),i.jsx(K,{geometry:{x:n.x1,y1:n.y1,y2:n.y2},zIndex:a,color:c,opacity:t,readOnly:l,lineWidth:r,onGeometryChanged:F}),i.jsx(K,{geometry:{x:n.x2,y1:n.y1,y2:n.y2},zIndex:a,color:c,opacity:t,readOnly:l,lineWidth:r,onGeometryChanged:B}),i.jsx(p,{text:`${I.toFixed(2)}${u}`,datapos:[R,T-y*.5],anchor:"top",vmargin:5,outline:"#FFFFFF80"}),i.jsx(p,{text:`${y.toFixed(2)}${u}`,datapos:[R-I*.5,T],anchor:"right",hmargin:5,outline:"#FFFFFF80"}),!l&&i.jsxs(i.Fragment,{children:[i.jsx(k,{geometry:{x:n.x1,y:n.y1},pointer:v,zIndex:a,color:c,opacity:t,readOnly:l,onGeometryChanged:_}),i.jsx(k,{geometry:{x:n.x1,y:n.y2},pointer:b,zIndex:a,color:c,opacity:t,readOnly:l,onGeometryChanged:o}),i.jsx(k,{geometry:{x:n.x2,y:n.y1},pointer:b,zIndex:a,color:c,opacity:t,readOnly:l,onGeometryChanged:s}),i.jsx(k,{geometry:{x:n.x2,y:n.y2},pointer:v,zIndex:a,color:c,opacity:t,readOnly:l,onGeometryChanged:S})]})]})}export{G as A,pe as C,Le as D,O as F,nn as H,en as I,ln as R,on as a,tn as b,cn as c,an as d,X as e,rn as u};
