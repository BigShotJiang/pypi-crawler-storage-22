"""
Daisi SDK - Python gRPC Wrapper

A modern Python wrapper for the Daisi SDK using gRPC.

Sync usage:
    >>> from daisi import DaisiClient
    >>> with DaisiClient(client_key="your-key") as client:
    ...     session_id, host, _ = client.session.create(model_name="llama-3")
    ...     for response in client.inference.send("Hello"):
    ...         print(response.Content, end="")

Async usage:
    >>> from daisi.aio import AsyncDaisiClient
    >>> async with AsyncDaisiClient(client_key="your-key") as client:
    ...     session_id, host, _ = await client.session.create(model_name="llama-3")
    ...     async for response in client.inference.send("Hello"):
    ...         print(response.Content, end="")

With secret key (similar to .NET's UseDaisi):
    >>> from daisi import DaisiClient
    >>> client = DaisiClient(secret_key="your-secret").use_daisi()

With custom key provider:
    >>> from daisi import DaisiClient
    >>> from daisi.providers import CallableClientKeyProvider
    >>> provider = CallableClientKeyProvider(lambda: get_key_from_vault())
    >>> client = DaisiClient(client_key_provider=provider)
"""

__version__ = "0.1.0"
__author__ = "Daisi Contributors"
__license__ = "MIT"

from .client import DaisiClient
from .config import DaisiConfig, ORC_DEV_ADDRESS, ORC_LIVE_ADDRESS
from .exceptions import AuthenticationError, DaisiError, ValidationError
from .providers import (
    CallableClientKeyProvider,
    ClientKeyProvider,
    DefaultClientKeyProvider,
    EnvironmentClientKeyProvider,
)
from .session_manager import (
    InferenceSessionManager,
    PeerSessionManager,
    SessionManager,
    SettingsSessionManager,
)

__all__ = [
    # Main client
    "DaisiClient",
    # Configuration
    "DaisiConfig",
    "ORC_DEV_ADDRESS",
    "ORC_LIVE_ADDRESS",
    # Exceptions
    "DaisiError",
    "AuthenticationError",
    "ValidationError",
    # Providers
    "ClientKeyProvider",
    "DefaultClientKeyProvider",
    "EnvironmentClientKeyProvider",
    "CallableClientKeyProvider",
    # Session managers
    "SessionManager",
    "InferenceSessionManager",
    "SettingsSessionManager",
    "PeerSessionManager",
]
