"""
Async clients for Daisi SDK.

This module provides async/await compatible clients using grpc.aio.

Example:
    >>> from daisi.aio import AsyncDaisiClient
    >>>
    >>> async with AsyncDaisiClient(client_key="your-key") as client:
    ...     session_id, host, _ = await client.session.create(model_name="llama-3")
    ...     _, inference_id = await client.inference.create(session_id=session_id)
    ...     async for response in client.inference.send("Hello", session_id=session_id):
    ...         print(response.Content, end="")
"""

from .base_client import AsyncBaseClient
from .client import AsyncDaisiClient
from .clients import (
    AsyncAppCommandsClient,
    AsyncAuthClient,
    AsyncHostClient,
    AsyncHostCommandsClient,
    AsyncInferenceClient,
    AsyncModelsClient,
    AsyncPeerClient,
    AsyncSessionClient,
    AsyncSettingsClient,
)

__all__ = [
    "AsyncDaisiClient",
    "AsyncBaseClient",
    "AsyncAuthClient",
    "AsyncSessionClient",
    "AsyncInferenceClient",
    "AsyncModelsClient",
    "AsyncHostClient",
    "AsyncPeerClient",
    "AsyncSettingsClient",
    "AsyncHostCommandsClient",
    "AsyncAppCommandsClient",
]
