"""
Async models client for Daisi SDK.
"""

from typing import Optional

import grpc

from protos.v1 import Models_pb2_grpc
from protos.v1.models import ModelModels_pb2

from ...config import DaisiConfig
from ...exceptions import DaisiError
from ..base_client import AsyncBaseClient


class AsyncModelsClient(AsyncBaseClient):
    """Async client for model operations."""

    def __init__(self, config: Optional[DaisiConfig] = None) -> None:
        """Initialize async models client.

        Args:
            config: Daisi configuration.
        """
        super().__init__(config)
        self._stub: Optional[Models_pb2_grpc.ModelsProtoStub] = None

    @property
    def stub(self) -> Models_pb2_grpc.ModelsProtoStub:
        """Get or create the gRPC stub."""
        if self._stub is None:
            self._stub = Models_pb2_grpc.ModelsProtoStub(self._get_channel())
        return self._stub

    async def get_required_models(self) -> ModelModels_pb2.GetRequiredModelsResponse:
        """Get list of required models.

        Returns:
            Response containing required models information.

        Raises:
            DaisiError: If request fails.
        """
        request = ModelModels_pb2.GetRequiredModelsRequest()

        try:
            return await self.stub.GetRequiredModels(
                request, metadata=self._get_metadata()
            )
        except grpc.RpcError as e:
            raise DaisiError(f"Failed to get required models: {e.details()}") from e
