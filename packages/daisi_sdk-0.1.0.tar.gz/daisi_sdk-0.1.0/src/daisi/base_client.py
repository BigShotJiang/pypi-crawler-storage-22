"""
Base client for gRPC communication with Daisi services.
"""

from typing import Any, Optional, Tuple

import grpc

from .config import DaisiConfig
from .exceptions import DaisiError


class BaseClient:
    """Base client providing common gRPC functionality."""

    def __init__(self, config: Optional[DaisiConfig] = None) -> None:
        """Initialize base client.

        Args:
            config: Daisi configuration. Creates default if not provided.
        """
        self.config = config or DaisiConfig()
        self._channel: Optional[grpc.Channel] = None

    def _get_channel(self, address: Optional[str] = None) -> grpc.Channel:
        """Get or create gRPC channel.

        Args:
            address: Optional custom address. Uses config orc_url if not provided.

        Returns:
            gRPC channel.
        """
        if self._channel is None:
            target = address or f"{self.config.orc_address}:{self.config.orc_port}"

            if self.config.use_ssl:
                credentials = grpc.ssl_channel_credentials()
                options = [
                    ("grpc.ssl_target_name_override", self.config.orc_address),
                ]
                self._channel = grpc.secure_channel(target, credentials, options)
            else:
                self._channel = grpc.insecure_channel(target)

        return self._channel

    def _get_metadata(
        self, additional_metadata: Optional[list[Tuple[str, str]]] = None
    ) -> list[Tuple[str, str]]:
        """Get gRPC metadata including auth header and network name.

        Args:
            additional_metadata: Optional additional metadata to include.

        Returns:
            List of metadata tuples.
        """
        metadata = [
            (self.config.client_key_header, self.config.client_key),
            ("x-daisi-network-name", self.config.network_name),
        ]

        if additional_metadata:
            metadata.extend(additional_metadata)

        return metadata

    def close(self) -> None:
        """Close the gRPC channel."""
        if self._channel:
            self._channel.close()
            self._channel = None

    def __enter__(self) -> "BaseClient":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit."""
        self.close()
