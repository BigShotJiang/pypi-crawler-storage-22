"""
Custom exceptions for Daisi SDK.
"""


class DaisiError(Exception):
    """Base exception for all Daisi SDK errors."""

    pass


class AuthenticationError(DaisiError):
    """Raised when authentication fails."""

    pass


class ValidationError(DaisiError):
    """Raised when request validation fails."""

    pass
