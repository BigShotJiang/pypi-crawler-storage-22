"""
Tests for DaisiConfig.
"""

import os
from unittest.mock import patch

import pytest

from daisi.config import DaisiConfig


class TestDaisiConfig:
    """Test DaisiConfig."""

    def test_init_with_explicit_values(self) -> None:
        """Test initialization with explicit values."""
        config = DaisiConfig(
            client_key="test-key",
            orc_address="test.daisi.net",
            orc_port=8443,
            use_ssl=True,
        )
        assert config.client_key == "test-key"
        assert config.orc_address == "test.daisi.net"
        assert config.orc_port == 8443
        assert config.use_ssl is True

    def test_init_with_env_variables(self) -> None:
        """Test initialization with environment variables."""
        with patch.dict(
            os.environ,
            {
                "DAISI_CLIENT_KEY": "env-key",
                "DAISI_ORC_ADDRESS": "env.daisi.net",
                "DAISI_ORC_PORT": "9443",
            },
        ):
            config = DaisiConfig()
            assert config.client_key == "env-key"
            assert config.orc_address == "env.daisi.net"
            assert config.orc_port == 9443

    def test_init_with_defaults(self) -> None:
        """Test initialization with default values."""
        with patch.dict(os.environ, {}, clear=True):
            config = DaisiConfig()
            assert config.client_key == ""
            assert config.orc_address == "orc.daisinet.com"
            assert config.orc_port == 443
            assert config.use_ssl is True
            assert config.network_name == "devnet"

    def test_orc_url_https(self) -> None:
        """Test orc_url property with SSL."""
        config = DaisiConfig(
            client_key="test-key",
            orc_address="test.daisi.net",
            orc_port=443,
            use_ssl=True,
        )
        assert config.orc_url == "https://test.daisi.net:443"

    def test_orc_url_http(self) -> None:
        """Test orc_url property without SSL."""
        config = DaisiConfig(
            client_key="test-key",
            orc_address="localhost",
            orc_port=8080,
            use_ssl=False,
        )
        assert config.orc_url == "http://localhost:8080"

    def test_validate_success(self) -> None:
        """Test validate with valid configuration."""
        config = DaisiConfig(
            client_key="test-key", orc_address="test.daisi.net", orc_port=443
        )
        config.validate()  # Should not raise

    def test_validate_missing_client_key(self) -> None:
        """Test validate with missing client key."""
        config = DaisiConfig(client_key="", orc_address="test.daisi.net")
        with pytest.raises(ValueError, match="Client key not provided"):
            config.validate()

    def test_validate_missing_orc_address(self) -> None:
        """Test validate with missing orc address."""
        config = DaisiConfig(client_key="test-key")
        # Manually clear orc_address after construction since it has a default
        config.orc_address = ""
        with pytest.raises(ValueError, match="Orchestrator address not provided"):
            config.validate()

    def test_client_key_header(self) -> None:
        """Test client_key_header constant."""
        config = DaisiConfig(client_key="test-key")
        assert config.client_key_header == "x-daisi-client-key"
