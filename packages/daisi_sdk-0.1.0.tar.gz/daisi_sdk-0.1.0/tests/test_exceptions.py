"""
Tests for exceptions.
"""

import pytest

from daisi.exceptions import AuthenticationError, DaisiError, ValidationError


class TestExceptions:
    """Test custom exceptions."""

    def test_daisi_error(self) -> None:
        """Test DaisiError."""
        with pytest.raises(DaisiError):
            raise DaisiError("Test error")

    def test_authentication_error(self) -> None:
        """Test AuthenticationError."""
        with pytest.raises(AuthenticationError):
            raise AuthenticationError("Auth failed")

    def test_authentication_error_inherits_daisi_error(self) -> None:
        """Test AuthenticationError inherits from DaisiError."""
        error = AuthenticationError("Auth failed")
        assert isinstance(error, DaisiError)
        assert isinstance(error, Exception)

    def test_validation_error(self) -> None:
        """Test ValidationError."""
        with pytest.raises(ValidationError):
            raise ValidationError("Invalid input")

    def test_validation_error_inherits_daisi_error(self) -> None:
        """Test ValidationError inherits from DaisiError."""
        error = ValidationError("Invalid input")
        assert isinstance(error, DaisiError)
        assert isinstance(error, Exception)

    def test_exception_messages(self) -> None:
        """Test exception messages are preserved."""
        error = DaisiError("Custom message")
        assert str(error) == "Custom message"

        auth_error = AuthenticationError("Auth message")
        assert str(auth_error) == "Auth message"

        val_error = ValidationError("Validation message")
        assert str(val_error) == "Validation message"
