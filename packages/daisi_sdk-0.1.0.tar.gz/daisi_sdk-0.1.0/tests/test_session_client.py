"""
Tests for SessionClient.
"""

from unittest.mock import MagicMock, patch

import grpc
import pytest

from daisi.clients.session import SessionClient
from daisi.config import DaisiConfig
from daisi.exceptions import DaisiError


def create_grpc_error(details: str = "Test error") -> grpc.RpcError:
    """Create a mock gRPC error with details method."""
    error = grpc.RpcError()
    error.details = MagicMock(return_value=details)
    return error


class TestSessionClientInitialization:
    """Test SessionClient initialization."""

    def test_init_with_config(self) -> None:
        """Test initialization with config."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)
        assert client.config == config
        assert client._stub is None
        assert client.session_id is None

    def test_stub_lazy_initialization(self) -> None:
        """Test stub is lazily initialized."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        with patch.object(client, "_get_channel") as mock_get_channel:
            mock_channel = MagicMock()
            mock_get_channel.return_value = mock_channel

            stub = client.stub
            assert stub is not None
            mock_get_channel.assert_called_once()


class TestSessionClientCreate:
    """Test SessionClient create method."""

    def test_create_session_minimal(self) -> None:
        """Test creating session with minimal parameters."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_response = MagicMock()
        mock_response.Id = "session-123"
        mock_response.Host = MagicMock()
        mock_response.HasField = MagicMock(side_effect=lambda f: f == "Host")
        mock_stub.Create.return_value = mock_response

        client._stub = mock_stub
        session_id, host, move_to_orc = client.create()

        assert session_id == "session-123"
        assert client.session_id == "session-123"
        assert move_to_orc is None
        mock_stub.Create.assert_called_once()

    def test_create_session_with_model(self) -> None:
        """Test creating session with model name."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_response = MagicMock()
        mock_response.Id = "session-123"
        mock_response.Host = MagicMock()
        mock_response.HasField = MagicMock(side_effect=lambda f: f == "Host")
        mock_stub.Create.return_value = mock_response

        client._stub = mock_stub
        session_id, host, move_to_orc = client.create(model_name="llama-3")

        call_args = mock_stub.Create.call_args
        request = call_args[0][0]
        assert request.ModelName == "llama-3"

    def test_create_session_with_preferences(self) -> None:
        """Test creating session with preferences."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_response = MagicMock()
        mock_response.Id = "session-123"
        mock_response.Host = MagicMock()
        mock_response.HasField = MagicMock(side_effect=lambda f: f == "Host")
        mock_stub.Create.return_value = mock_response

        client._stub = mock_stub
        session_id, host, move_to_orc = client.create(
            model_name="llama-3",
            direct_connect_required=True,
            preferred_host_names=["host1", "host2"],
            preferred_region="us-west",
            host_id="host-123",
        )

        call_args = mock_stub.Create.call_args
        request = call_args[0][0]
        assert request.DirectConnectRequired is True
        assert len(request.PreferredHostNames) == 2

    def test_create_session_grpc_error(self) -> None:
        """Test create session with gRPC error."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_stub.Create.side_effect = create_grpc_error()

        client._stub = mock_stub
        with pytest.raises(DaisiError, match="Failed to create session"):
            client.create()


class TestSessionClientClaim:
    """Test SessionClient claim method."""

    def test_claim_session_success(self) -> None:
        """Test successful session claim."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_response = MagicMock()
        mock_response.Success = True
        mock_response.ModelName.value = "llama-3"
        mock_stub.Claim.return_value = mock_response

        client._stub = mock_stub
        success, model_name = client.claim("session-123")

        assert success is True
        assert model_name == "llama-3"

    def test_claim_session_no_model(self) -> None:
        """Test claiming session with no model name."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_response = MagicMock()
        mock_response.Success = True
        mock_response.ModelName.value = ""
        mock_stub.Claim.return_value = mock_response

        client._stub = mock_stub
        success, model_name = client.claim("session-123")

        assert success is True
        assert model_name is None

    def test_claim_session_grpc_error(self) -> None:
        """Test claim session with gRPC error."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_stub.Claim.side_effect = create_grpc_error()

        client._stub = mock_stub
        with pytest.raises(DaisiError, match="Failed to claim session"):
            client.claim("session-123")


class TestSessionClientClose:
    """Test SessionClient close_session method."""

    def test_close_session_with_id(self) -> None:
        """Test closing session with explicit ID."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_response = MagicMock()
        mock_response.Success = True
        mock_stub.Close.return_value = mock_response

        client._stub = mock_stub
        result = client.close_session("session-123")

        assert result is True
        mock_stub.Close.assert_called_once()

    def test_close_session_stored_id(self) -> None:
        """Test closing session with stored ID."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)
        client.session_id = "session-123"

        mock_stub = MagicMock()
        mock_response = MagicMock()
        mock_response.Success = True
        mock_stub.Close.return_value = mock_response

        client._stub = mock_stub
        result = client.close_session()

        assert result is True
        assert client.session_id is None

    def test_close_session_no_id(self) -> None:
        """Test closing session without ID raises error."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        with pytest.raises(DaisiError, match="No session ID provided or available"):
            client.close_session()

    def test_close_session_grpc_error(self) -> None:
        """Test close session with gRPC error."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_stub.Close.side_effect = create_grpc_error()

        client._stub = mock_stub
        with pytest.raises(DaisiError, match="Failed to close session"):
            client.close_session("session-123")


class TestSessionClientConnect:
    """Test SessionClient connect method."""

    def test_connect_session_success(self) -> None:
        """Test successful session connection."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_response = MagicMock()
        mock_response.Id = "session-123"
        mock_response.HasCapacity = True
        mock_response.AlreadyConnected = False
        mock_stub.Connect.return_value = mock_response

        client._stub = mock_stub
        session_id, has_capacity, already_connected = client.connect("session-123")

        assert session_id == "session-123"
        assert has_capacity is True
        assert already_connected is False

    def test_connect_session_stored_id(self) -> None:
        """Test connecting with stored session ID."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)
        client.session_id = "session-123"

        mock_stub = MagicMock()
        mock_response = MagicMock()
        mock_response.Id = "session-123"
        mock_response.HasCapacity = True
        mock_response.AlreadyConnected = True
        mock_stub.Connect.return_value = mock_response

        client._stub = mock_stub
        session_id, has_capacity, already_connected = client.connect()

        assert already_connected is True

    def test_connect_session_no_id(self) -> None:
        """Test connecting without session ID raises error."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        with pytest.raises(DaisiError, match="No session ID provided or available"):
            client.connect()

    def test_connect_session_grpc_error(self) -> None:
        """Test connect session with gRPC error."""
        config = DaisiConfig(client_key="test-key")
        client = SessionClient(config)

        mock_stub = MagicMock()
        mock_stub.Connect.side_effect = create_grpc_error()

        client._stub = mock_stub
        with pytest.raises(DaisiError, match="Failed to connect to session"):
            client.connect("session-123")
