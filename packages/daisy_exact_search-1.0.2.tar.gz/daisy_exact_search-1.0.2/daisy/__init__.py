"""
daisy: High-performance similarity search library for time series data

This library provides multiple algorithms for nearest neighbor search on time series data:
- Brute Force search
- Lower Bound Brute Force search  
- MESSI - Advanced indexing algorithm for DTW searches
- Odyssey - MPI-based distributed search
- PARIS - Parallel indexing for disk-based datasets
- SING - CUDA-accelerated search
"""

__version__ = "1.0.0"
__author__ = ""

try:
    from ._core import *
except ImportError:
    import warnings
    warnings.warn(
        "daisy._core extension not found. "
        "The library may not have been compiled properly. "
        "Please check the installation instructions.",
        ImportWarning
    )
