from django.apps import AppConfig


class DalfConfig(AppConfig):
    name = 'dalf'
