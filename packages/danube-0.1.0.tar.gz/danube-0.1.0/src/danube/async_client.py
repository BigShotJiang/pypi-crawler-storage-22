"""Async client for the Danube SDK."""

import logging
from typing import Any, Dict, List, Optional

from danube._http import HTTPClient
from danube._utils import clean_id, is_valid_uuid
from danube.config import DanubeConfig
from danube.exceptions import (
    ConfigurationRequiredError,
    ExecutionError,
    NotFoundError,
    ValidationError,
)
from danube.models import (
    Contact,
    Identity,
    Service,
    ServiceToolsResult,
    Skill,
    SkillContent,
    Tool,
    ToolResult,
)

logger = logging.getLogger("danube")


class ServicesResource:
    """Operations on services."""

    def __init__(self, client: "AsyncDanubeClient"):
        self._client = client

    async def list(
        self,
        query: str = "",
        limit: int = 10,
    ) -> List[Service]:
        """List or search available services.

        Args:
            query: Optional search query to filter by name/description.
            limit: Maximum number of results (default 10).

        Returns:
            List of matching Service objects.
        """
        params = {"num_results": limit}
        if query:
            params["query"] = query

        data = await self._client._http.get("/v1/services", params=params)

        # Handle both list and dict responses
        services_data = data if isinstance(data, list) else data.get("services", [])

        return [Service.from_api_response(s) for s in services_data]

    async def get(self, service_id: str) -> Service:
        """Get a service by ID.

        Args:
            service_id: The service UUID.

        Returns:
            Service details.

        Raises:
            NotFoundError: If service doesn't exist.
        """
        data = await self._client._http.get(f"/v1/services/{service_id}")
        return Service.from_api_response(data)

    async def get_tools(
        self,
        service_id: str,
        limit: int = 50,
    ) -> ServiceToolsResult:
        """Get all tools for a service.

        Args:
            service_id: The service UUID.
            limit: Maximum tools to return (default 50).

        Returns:
            ServiceToolsResult with tools and configuration status.
        """
        data = await self._client._http.get(
            f"/v1/services/{service_id}/tools",
            params={"limit": limit},
        )

        # Handle extended response format
        if isinstance(data, dict):
            if data.get("needs_configuration"):
                config_info = data.get("configuration_info", {})
                return ServiceToolsResult(
                    tools=[],
                    needs_configuration=True,
                    skipped=False,
                    configuration_required={
                        "service_id": service_id,
                        "service_name": config_info.get("service_name", ""),
                        "message": config_info.get("message", ""),
                        "configuration_url": config_info.get(
                            "configuration_url",
                            f"https://app.danube.ai/dashboard/services/{service_id}",
                        ),
                        "credential_schema": config_info.get("credential_schema"),
                    },
                )
            elif data.get("skipped"):
                return ServiceToolsResult(
                    tools=[],
                    needs_configuration=False,
                    skipped=True,
                    configuration_required=None,
                )
            elif "tools" in data:
                tools_data = data.get("tools", [])
            else:
                tools_data = data if isinstance(data, list) else []
        else:
            tools_data = data if isinstance(data, list) else []

        tools = [Tool.from_api_response(t) for t in tools_data[:limit]]
        return ServiceToolsResult(
            tools=tools,
            needs_configuration=False,
            skipped=False,
            configuration_required=None,
        )


class ToolsResource:
    """Operations on tools."""

    def __init__(self, client: "AsyncDanubeClient"):
        self._client = client

    async def search(
        self,
        query: str,
        service_id: Optional[str] = None,
        limit: int = 10,
    ) -> List[Tool]:
        """Search for tools by name or description.

        Uses semantic search to find the most relevant tools.

        Args:
            query: Search query (semantic search).
            service_id: Optional filter by service.
            limit: Maximum results (default 10).

        Returns:
            List of matching Tool objects.
        """
        params: Dict[str, Any] = {"query": query, "num_results": limit}
        if service_id:
            params["service_id"] = service_id

        data = await self._client._http.get("/v1/tools/search", params=params)

        # Handle both list and dict responses
        tools_data = data if isinstance(data, list) else data.get("tools", [])

        return [Tool.from_api_response(t) for t in tools_data[:limit]]

    async def get(self, tool_id: str) -> Tool:
        """Get a tool by ID.

        Args:
            tool_id: The tool UUID.

        Returns:
            Tool details.

        Raises:
            NotFoundError: If tool doesn't exist.
        """
        data = await self._client._http.get(f"/v1/tools/{tool_id}")
        return Tool.from_api_response(data)

    async def execute(
        self,
        tool_id: Optional[str] = None,
        tool_name: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> ToolResult:
        """Execute a tool by ID or name.

        Args:
            tool_id: Tool UUID (preferred, faster).
            tool_name: Tool name (will search for match).
            parameters: Parameters to pass to the tool.

        Returns:
            ToolResult with execution result or error.

        Raises:
            ValidationError: If neither tool_id nor tool_name provided.
            NotFoundError: If tool cannot be found.
            ExecutionError: If tool execution fails.
        """
        if not tool_id and not tool_name:
            raise ValidationError("Either tool_id or tool_name must be provided")

        resolved_tool_id = None
        resolved_tool_name = tool_name

        # If tool_id is provided and is a valid UUID, use it directly
        if tool_id:
            cleaned_id = clean_id(tool_id)
            if cleaned_id and is_valid_uuid(cleaned_id):
                resolved_tool_id = cleaned_id
                logger.debug(f"Executing tool by ID: {resolved_tool_id}")
            else:
                # tool_id is not a valid UUID, treat it as a tool name
                logger.debug(f"'{cleaned_id}' is not a valid UUID, treating as name")
                tool_name = cleaned_id
                resolved_tool_name = cleaned_id

        # If we don't have a resolved ID, search by name
        if not resolved_tool_id:
            logger.debug(f"Searching for tool by name: '{tool_name}'")
            tools = await self.search(query=tool_name or "", limit=5)

            if not tools:
                raise NotFoundError("Tool", tool_name or "")

            # Find exact match or use first result
            tool = None
            for t in tools:
                if t.name == tool_name:
                    tool = t
                    break

            if not tool:
                tool = tools[0]
                logger.debug(
                    f"No exact match for '{tool_name}', using: '{tool.name}'"
                )

            resolved_tool_id = tool.id
            resolved_tool_name = tool.name

        if not resolved_tool_id:
            raise NotFoundError("Tool", tool_id or tool_name or "")

        # Execute the tool
        logger.debug(f"Calling tool: {resolved_tool_id} ({resolved_tool_name})")

        try:
            data = await self._client._http.post(
                f"/v1/tools/call/{resolved_tool_id}",
                json=parameters or {},
            )

            # Handle response
            if data.get("status") == "success":
                result_value = data.get("result", "")
                return ToolResult(
                    success=True,
                    result=result_value,
                    tool_id=resolved_tool_id,
                    tool_name=resolved_tool_name,
                )
            else:
                error_msg = data.get("error", "Tool execution failed")
                return ToolResult(
                    success=False,
                    error=error_msg,
                    tool_id=resolved_tool_id,
                    tool_name=resolved_tool_name,
                )

        except Exception as e:
            logger.error(f"Tool execution error: {e}")
            raise ExecutionError(str(e), tool_id=resolved_tool_id)


class SkillsResource:
    """Operations on skills."""

    def __init__(self, client: "AsyncDanubeClient"):
        self._client = client

    async def search(
        self,
        query: str,
        limit: int = 10,
    ) -> List[Skill]:
        """Search for skills using semantic search.

        Skills are reusable instructions that teach AI agents
        how to perform specific tasks.

        Args:
            query: Search query.
            limit: Maximum results (default 10).

        Returns:
            List of matching Skill objects (summaries).
        """
        data = await self._client._http.get(
            "/v1/skills/search",
            params={"query": query, "limit": limit},
        )

        # Handle both list and dict responses
        skills_data = data if isinstance(data, list) else data.get("skills", [])

        return [Skill.from_api_response(s) for s in skills_data[:limit]]

    async def get(
        self,
        skill_id: Optional[str] = None,
        skill_name: Optional[str] = None,
    ) -> SkillContent:
        """Get a skill with full content.

        Args:
            skill_id: Skill UUID (preferred).
            skill_name: Skill name.

        Returns:
            Full SkillContent including SKILL.md, scripts, etc.

        Raises:
            ValidationError: If neither skill_id nor skill_name provided.
            NotFoundError: If skill cannot be found.
        """
        if not skill_id and not skill_name:
            raise ValidationError("Either skill_id or skill_name must be provided")

        resolved_skill_id = skill_id

        # If no ID, search by name
        if not resolved_skill_id and skill_name:
            skills = await self.search(query=skill_name, limit=5)

            if not skills:
                raise NotFoundError("Skill", skill_name)

            # Find exact match or use first result
            skill = None
            for s in skills:
                if s.name == skill_name:
                    skill = s
                    break

            if not skill:
                skill = skills[0]

            resolved_skill_id = skill.id

        if not resolved_skill_id:
            raise NotFoundError("Skill", skill_id or skill_name or "")

        data = await self._client._http.get(f"/v1/skills/{resolved_skill_id}")
        return SkillContent.from_api_response(data)


class IdentityResource:
    """Operations on user identity."""

    def __init__(self, client: "AsyncDanubeClient"):
        self._client = client
        self._cached_identity: Optional[Identity] = None

    async def get(self) -> Identity:
        """Get the current user's identity.

        Returns:
            User identity with profile, contacts, preferences.
        """
        data = await self._client._http.get("/v1/identity/api")
        self._cached_identity = Identity.from_api_response(data)
        return self._cached_identity

    async def search_contacts(
        self,
        query: str,
        limit: int = 5,
    ) -> List[Contact]:
        """Search user's contacts.

        Searches both key_people and contacts lists.

        Args:
            query: Search query for name, email, etc.
            limit: Maximum results (default 5).

        Returns:
            Matching Contact objects.
        """
        # Fetch identity if not cached
        if self._cached_identity is None:
            await self.get()

        if self._cached_identity is None:
            return []

        return self._cached_identity.search_contacts(query, limit)


class AsyncDanubeClient:
    """Async client for the Danube AI API.

    Example:
        async with AsyncDanubeClient(api_key="dk_...") as client:
            services = await client.services.list()
            result = await client.tools.execute("tool-id", parameters={"key": "value"})
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        """Initialize the Danube async client.

        Args:
            api_key: Danube API key. Falls back to DANUBE_API_KEY env var.
            base_url: API base URL. Defaults to https://api.danubeai.com
            timeout: Request timeout in seconds.
            max_retries: Number of retries for failed requests.
        """
        # Build config with overrides
        config = DanubeConfig()
        if api_key:
            config.api_key = api_key
        if base_url:
            config.base_url = base_url.rstrip("/")
        config.timeout = timeout
        config.max_retries = max_retries

        # Validate configuration
        config.validate()

        self._config = config
        self._http = HTTPClient(config)

        # Initialize resource handlers (lazy)
        self._services: Optional[ServicesResource] = None
        self._tools: Optional[ToolsResource] = None
        self._skills: Optional[SkillsResource] = None
        self._identity: Optional[IdentityResource] = None

    @property
    def services(self) -> ServicesResource:
        """Access services resource."""
        if self._services is None:
            self._services = ServicesResource(self)
        return self._services

    @property
    def tools(self) -> ToolsResource:
        """Access tools resource."""
        if self._tools is None:
            self._tools = ToolsResource(self)
        return self._tools

    @property
    def skills(self) -> SkillsResource:
        """Access skills resource."""
        if self._skills is None:
            self._skills = SkillsResource(self)
        return self._skills

    @property
    def identity(self) -> IdentityResource:
        """Access identity resource."""
        if self._identity is None:
            self._identity = IdentityResource(self)
        return self._identity

    async def verify_connection(self) -> bool:
        """Verify the connection to the Danube API.

        Returns:
            True if connection is successful and API key is valid.
        """
        try:
            await self._http.get("/v1/services/public")
            return True
        except Exception as e:
            logger.warning(f"Connection verification failed: {e}")
            return False

    async def close(self) -> None:
        """Close the client and release resources."""
        await self._http.close()

    async def __aenter__(self) -> "AsyncDanubeClient":
        """Async context manager entry."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        await self.close()
