"""Synchronous client for the Danube SDK."""

import asyncio
from typing import Any, Dict, List, Optional

from danube.async_client import AsyncDanubeClient
from danube.models import (
    Contact,
    Identity,
    Service,
    ServiceToolsResult,
    Skill,
    SkillContent,
    Tool,
    ToolResult,
)


class SyncServicesResource:
    """Synchronous operations on services."""

    def __init__(self, client: "DanubeClient"):
        self._client = client

    def list(
        self,
        query: str = "",
        limit: int = 10,
    ) -> List[Service]:
        """List or search available services.

        Args:
            query: Optional search query to filter by name/description.
            limit: Maximum number of results (default 10).

        Returns:
            List of matching Service objects.
        """
        return self._client._run(
            self._client._async_client.services.list(query=query, limit=limit)
        )

    def get(self, service_id: str) -> Service:
        """Get a service by ID.

        Args:
            service_id: The service UUID.

        Returns:
            Service details.

        Raises:
            NotFoundError: If service doesn't exist.
        """
        return self._client._run(self._client._async_client.services.get(service_id))

    def get_tools(
        self,
        service_id: str,
        limit: int = 50,
    ) -> ServiceToolsResult:
        """Get all tools for a service.

        Args:
            service_id: The service UUID.
            limit: Maximum tools to return (default 50).

        Returns:
            ServiceToolsResult with tools and configuration status.
        """
        return self._client._run(
            self._client._async_client.services.get_tools(
                service_id=service_id, limit=limit
            )
        )


class SyncToolsResource:
    """Synchronous operations on tools."""

    def __init__(self, client: "DanubeClient"):
        self._client = client

    def search(
        self,
        query: str,
        service_id: Optional[str] = None,
        limit: int = 10,
    ) -> List[Tool]:
        """Search for tools by name or description.

        Uses semantic search to find the most relevant tools.

        Args:
            query: Search query (semantic search).
            service_id: Optional filter by service.
            limit: Maximum results (default 10).

        Returns:
            List of matching Tool objects.
        """
        return self._client._run(
            self._client._async_client.tools.search(
                query=query, service_id=service_id, limit=limit
            )
        )

    def get(self, tool_id: str) -> Tool:
        """Get a tool by ID.

        Args:
            tool_id: The tool UUID.

        Returns:
            Tool details.

        Raises:
            NotFoundError: If tool doesn't exist.
        """
        return self._client._run(self._client._async_client.tools.get(tool_id))

    def execute(
        self,
        tool_id: Optional[str] = None,
        tool_name: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> ToolResult:
        """Execute a tool by ID or name.

        Args:
            tool_id: Tool UUID (preferred, faster).
            tool_name: Tool name (will search for match).
            parameters: Parameters to pass to the tool.

        Returns:
            ToolResult with execution result or error.

        Raises:
            ValidationError: If neither tool_id nor tool_name provided.
            NotFoundError: If tool cannot be found.
            ExecutionError: If tool execution fails.
        """
        return self._client._run(
            self._client._async_client.tools.execute(
                tool_id=tool_id, tool_name=tool_name, parameters=parameters
            )
        )


class SyncSkillsResource:
    """Synchronous operations on skills."""

    def __init__(self, client: "DanubeClient"):
        self._client = client

    def search(
        self,
        query: str,
        limit: int = 10,
    ) -> List[Skill]:
        """Search for skills using semantic search.

        Skills are reusable instructions that teach AI agents
        how to perform specific tasks.

        Args:
            query: Search query.
            limit: Maximum results (default 10).

        Returns:
            List of matching Skill objects (summaries).
        """
        return self._client._run(
            self._client._async_client.skills.search(query=query, limit=limit)
        )

    def get(
        self,
        skill_id: Optional[str] = None,
        skill_name: Optional[str] = None,
    ) -> SkillContent:
        """Get a skill with full content.

        Args:
            skill_id: Skill UUID (preferred).
            skill_name: Skill name.

        Returns:
            Full SkillContent including SKILL.md, scripts, etc.

        Raises:
            ValidationError: If neither skill_id nor skill_name provided.
            NotFoundError: If skill cannot be found.
        """
        return self._client._run(
            self._client._async_client.skills.get(
                skill_id=skill_id, skill_name=skill_name
            )
        )


class SyncIdentityResource:
    """Synchronous operations on user identity."""

    def __init__(self, client: "DanubeClient"):
        self._client = client

    def get(self) -> Identity:
        """Get the current user's identity.

        Returns:
            User identity with profile, contacts, preferences.
        """
        return self._client._run(self._client._async_client.identity.get())

    def search_contacts(
        self,
        query: str,
        limit: int = 5,
    ) -> List[Contact]:
        """Search user's contacts.

        Searches both key_people and contacts lists.

        Args:
            query: Search query for name, email, etc.
            limit: Maximum results (default 5).

        Returns:
            Matching Contact objects.
        """
        return self._client._run(
            self._client._async_client.identity.search_contacts(query=query, limit=limit)
        )


class DanubeClient:
    """Synchronous client for the Danube AI API.

    This is a convenience wrapper around AsyncDanubeClient for use
    in synchronous code. For better performance in async applications,
    use AsyncDanubeClient directly.

    Example:
        with DanubeClient(api_key="dk_...") as client:
            services = client.services.list()
            result = client.tools.execute("tool-id", parameters={"key": "value"})
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        """Initialize the Danube synchronous client.

        Args:
            api_key: Danube API key. Falls back to DANUBE_API_KEY env var.
            base_url: API base URL. Defaults to https://api.danubeai.com
            timeout: Request timeout in seconds.
            max_retries: Number of retries for failed requests.
        """
        self._async_client = AsyncDanubeClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        # Initialize resource handlers (lazy)
        self._services: Optional[SyncServicesResource] = None
        self._tools: Optional[SyncToolsResource] = None
        self._skills: Optional[SyncSkillsResource] = None
        self._identity: Optional[SyncIdentityResource] = None

    def _get_loop(self) -> asyncio.AbstractEventLoop:
        """Get or create an event loop.

        Returns:
            An asyncio event loop.
        """
        if self._loop is None or self._loop.is_closed():
            try:
                self._loop = asyncio.get_event_loop()
                if self._loop.is_closed():
                    raise RuntimeError("Event loop is closed")
            except RuntimeError:
                self._loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self._loop)
        return self._loop

    def _run(self, coro: Any) -> Any:
        """Run a coroutine synchronously.

        Args:
            coro: The coroutine to run.

        Returns:
            The result of the coroutine.
        """
        return self._get_loop().run_until_complete(coro)

    @property
    def services(self) -> SyncServicesResource:
        """Access services resource."""
        if self._services is None:
            self._services = SyncServicesResource(self)
        return self._services

    @property
    def tools(self) -> SyncToolsResource:
        """Access tools resource."""
        if self._tools is None:
            self._tools = SyncToolsResource(self)
        return self._tools

    @property
    def skills(self) -> SyncSkillsResource:
        """Access skills resource."""
        if self._skills is None:
            self._skills = SyncSkillsResource(self)
        return self._skills

    @property
    def identity(self) -> SyncIdentityResource:
        """Access identity resource."""
        if self._identity is None:
            self._identity = SyncIdentityResource(self)
        return self._identity

    def verify_connection(self) -> bool:
        """Verify the connection to the Danube API.

        Returns:
            True if connection is successful and API key is valid.
        """
        return self._run(self._async_client.verify_connection())

    def close(self) -> None:
        """Close the client and release resources."""
        self._run(self._async_client.close())

    def __enter__(self) -> "DanubeClient":
        """Context manager entry."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit."""
        self.close()
