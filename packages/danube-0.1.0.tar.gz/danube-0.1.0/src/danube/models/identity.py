"""Identity models for the Danube SDK."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class Contact(BaseModel):
    """A contact from the user's identity.

    Contacts can come from either the key_people list (important contacts)
    or the general contacts list.
    """

    name: str = ""
    email: str = ""
    phone: Optional[str] = None
    relationship: Optional[str] = None
    company: Optional[str] = None
    notes: Optional[str] = None
    nickname: Optional[str] = None
    source: str = "contacts"  # "key_people" or "contacts"

    model_config = {"extra": "ignore"}

    @classmethod
    def from_api_response(
        cls, data: Dict[str, Any], source: str = "contacts"
    ) -> "Contact":
        """Create a Contact from API response data.

        Args:
            data: Raw API response dictionary.
            source: Where this contact came from ("key_people" or "contacts").

        Returns:
            Contact instance.
        """
        return cls(
            name=data.get("name", ""),
            email=data.get("email", ""),
            phone=data.get("phone"),
            relationship=data.get("relationship"),
            company=data.get("company"),
            notes=data.get("notes"),
            nickname=data.get("nickname"),
            source=source,
        )

    def matches_query(self, query: str) -> bool:
        """Check if this contact matches a search query.

        Args:
            query: Search query string.

        Returns:
            True if any searchable field contains the query.
        """
        query_lower = query.lower()
        searchable_fields = [
            self.name,
            self.email,
            self.relationship or "",
            self.notes or "",
            self.nickname or "",
            self.phone or "",
            self.company or "",
        ]
        return any(query_lower in field.lower() for field in searchable_fields if field)


class Identity(BaseModel):
    """User identity and profile information.

    Contains the user's profile data, important contacts (key_people),
    general contacts, and preferences.
    """

    profile: Dict[str, Any] = Field(default_factory=dict)
    key_people: List[Contact] = Field(default_factory=list)
    contacts: List[Contact] = Field(default_factory=list)
    preferences: Dict[str, Any] = Field(default_factory=dict)

    # Raw data access for advanced use cases
    raw: Dict[str, Any] = Field(default_factory=dict)

    model_config = {"extra": "ignore"}

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "Identity":
        """Create an Identity from API response data.

        Args:
            data: Raw API response dictionary.

        Returns:
            Identity instance.
        """
        # Parse key_people
        key_people = [
            Contact.from_api_response(p, source="key_people")
            for p in data.get("key_people", [])
        ]

        # Parse contacts
        contacts = [
            Contact.from_api_response(c, source="contacts")
            for c in data.get("contacts", [])
        ]

        # Extract profile (attributes)
        profile = data.get("attributes", data.get("profile", {}))

        return cls(
            profile=profile,
            key_people=key_people,
            contacts=contacts,
            preferences=data.get("preferences", {}),
            raw=data,
        )

    def search_contacts(self, query: str, limit: int = 10) -> List[Contact]:
        """Search contacts by query.

        Searches both key_people and contacts lists, with key_people
        appearing first in results.

        Args:
            query: Search query string.
            limit: Maximum number of results to return.

        Returns:
            List of matching Contact objects.
        """
        results = []

        # Search key_people first (they're more important)
        for person in self.key_people:
            if person.matches_query(query):
                results.append(person)
                if len(results) >= limit:
                    return results

        # Then search general contacts
        for contact in self.contacts:
            if contact.matches_query(query):
                results.append(contact)
                if len(results) >= limit:
                    return results

        return results

    def get_all_contacts(self) -> List[Contact]:
        """Get all contacts from both key_people and contacts lists.

        Returns:
            Combined list with key_people first.
        """
        return self.key_people + self.contacts

    @property
    def name(self) -> Optional[str]:
        """Get the user's name from profile."""
        return self.profile.get("name") or self.profile.get("full_name")

    @property
    def email(self) -> Optional[str]:
        """Get the user's email from profile."""
        return self.profile.get("email")
