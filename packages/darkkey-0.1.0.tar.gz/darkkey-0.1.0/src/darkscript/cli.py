# src/darkscript/cli.py
import sys
import os
from darkscript import encode, decode

def usage():
    print("استخدام:")
    print("  darkkey encryption <ملف.py>")
    print("  darkkey decryption <ملف_مشفر.py>")
    sys.exit(1)

def get_seed():
    while True:
        try:
            return int(input("أدخل المفتاح (seed) [رقم صحيح]: ").strip())
        except ValueError:
            print("المفتاح لازم رقم صحيح، جرب تاني.")

def main():
    if len(sys.argv) != 3:
        usage()

    cmd = sys.argv[1].lower()
    file_path = sys.argv[2]

    if not os.path.isfile(file_path):
        print(f"الملف غير موجود: {file_path}")
        sys.exit(1)

    with open(file_path, encoding="utf-8") as f:
        content = f.read()

    if cmd == "encryption":
        seed = get_seed()
        encrypted = encode(content, seed=seed)

        base, ext = os.path.splitext(file_path)
        out = f"{base}_encrypted{ext}"

        with open(out, "w", encoding="utf-8") as f:
            f.write(f'''# -*- coding: utf-8 -*-
import darkscript

encoded_tool = """{encrypted}"""
seed = {seed}

exec(darkscript.decode(encoded_tool, seed=seed))
''')

        print(f"تم التشفير وحفظ الملف في: {out}")

    elif cmd == "decryption":
        seed = get_seed()

        # نفترض إن الملف المشفر فيه encoded_tool و seed
        try:
            lines = content.splitlines()
            enc_line = next(l for l in lines if l.strip().startswith("encoded_tool = "))
            seed_line = next(l for l in lines if l.strip().startswith("seed = "))

            enc = enc_line.split('"""', 2)[1]
            file_seed = int(seed_line.split("=")[1].strip())

            if seed != file_seed:
                print("المفتاح غلط!")
                sys.exit(1)

            original = decode(enc, seed=seed)

            base, ext = os.path.splitext(file_path)
            out = f"{base}_decoded{ext}"

            with open(out, "w", encoding="utf-8") as f:
                f.write(original)

            print(f"تم الفك وحفظ الكود الأصلي في: {out}")

        except Exception as e:
            print("مشكلة في الفك:", e)

    else:
        usage()

if __name__ == "__main__":
    main()
