# core.py
import zlib
import base64
import types


def _pack(source: str) -> bytes:
    """
    يحول كود بايثون لناتج ثنائي (bytes)
    """
    if not isinstance(source, str):
        raise TypeError("source must be str")

    raw = source.encode("utf-8")
    compressed = zlib.compress(raw, level=9)
    encoded = base64.b85encode(compressed)
    return encoded


def _unpack(blob: bytes) -> str:
    """
    يفك الناتج الثنائي داخل الذاكرة
    """
    if not isinstance(blob, (bytes, bytearray)):
        raise TypeError("blob must be bytes")

    compressed = base64.b85decode(blob)
    raw = zlib.decompress(compressed)
    return raw.decode("utf-8")


def run_blob(blob: bytes, globals_dict=None):
    """
    يفك وينفذ الكود في الذاكرة فقط
    """
    source = _unpack(blob)

    if globals_dict is None:
        globals_dict = {
            "__name__": "__main__",
            "__builtins__": __builtins__,
        }

    code = compile(source, "<darkscript>", "exec")
    exec(code, globals_dict)


def protect_file(path: str) -> bytes:
    """
    يقرأ ملف بايثون ويرجّع BLOB
    """
    with open(path, "r", encoding="utf-8") as f:
        source = f.read()

    return _pack(source)