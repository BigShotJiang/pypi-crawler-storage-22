import warnings

def run(code: str) -> None:
    warnings.warn(
        "DARKOP PyPI: Runtime-only package\n"
        "Full toolkit required for execution",
        RuntimeWarning
    )
    print(f"[DARKOP] Placeholder - Code length: {len(code)}")

__version__ = '1.0.8'
__all__ = ['run']
