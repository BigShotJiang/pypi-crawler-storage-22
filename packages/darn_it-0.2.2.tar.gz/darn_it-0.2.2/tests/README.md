# Testing Strategy

Since the users will only experience the tool via the python interface, I think I may make the somewhat controversial decision to exclusively test the python methods? This will lock the interface that actually matters into place nicely.

this means we will need to know that interface ahead of time...

