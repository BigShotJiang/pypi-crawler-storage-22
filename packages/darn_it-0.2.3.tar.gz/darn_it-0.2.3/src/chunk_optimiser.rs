mod dynamic_programing;
mod chunk_optimiser;

use dynamic_programing::cheapest_path_indices;
pub use chunk_optimiser::{ChunkOptimiser, Granularity};