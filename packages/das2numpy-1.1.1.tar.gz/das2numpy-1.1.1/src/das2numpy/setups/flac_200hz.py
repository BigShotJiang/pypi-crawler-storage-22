""" Univsersal setup file for silixa, that detects sampling rate and number of channels by itself. 
The root directory shall be supplied by the user via an argument
"""

import sys as SYS
import ast as AST
from os import path as P
import datetime as DT
import numpy as NP
import ffmpeg as FFMPEG
from ..filefinder import FileFinder, to_posix_timestamp_ms
from ..chunk import Chunk
from ..utils import bin

CALIBRATE = True



sample_rate = 200


def init(root_path, num_worker_threads):
    assert P.isdir(root_path)
    file_finder = FileFinder(root_path, ".flac", filename_to_posix_timestamp)
    assert num_worker_threads >= 1
    multithreaded = num_worker_threads > 1
    return Chunk(
                file_finder,
                sample_rate,
                multithreaded,
                num_worker_threads,
                False,
                load_file
            )


def filename_to_posix_timestamp(file_name:str) -> int:
    timestamp_str = file_name.split(".flac")[0]
    timestamp_dt = DT.datetime.strptime(timestamp_str, "%Y%m%dT%H%M%S")
    timestamp_ms = to_posix_timestamp_ms(timestamp_dt)
    return timestamp_ms



def load_file(file_path, file_timestamp, t_start, t_end, t_step, channel_start, channel_end, channel_step) -> NP.ndarray:
    """ Loads a single file, trims it. And returns the trimmed data as a numpy array. Downsampling (t_step, channel_step) is also possible!
    """

    try:
        probe = FFMPEG.probe(file_path, v='error', select_streams='a:0', show_entries='stream=channels,sample_rate', of='json')
        shape = AST.literal_eval(probe['format']['tags']['shape'])
        calibration_factor = float(probe['format']['tags']['calibration_factor'])
        info = probe['streams'][0]


        idx_start = 0
        if t_start > file_timestamp: # Check if beginning should be trimmed.
            rel_t_start = t_start - file_timestamp
            idx_start = int(rel_t_start * sample_rate / 1000.0)
        idx_end = shape[0] 
        if t_end < file_timestamp + (shape[0] * 1000 / sample_rate): # Check if end should be trimmed
            rel_t_end = t_end - file_timestamp
            idx_end = int(rel_t_end * sample_rate / 1000.0) 
        if idx_start == idx_end:
            return NP.zeros(shape=[0, 0]) # No data should be loaded. Do nothing
        if file_timestamp + (shape[0] * 1000 / sample_rate) <= t_start:
            print("Warning: File does not contain any parts of the requested data.",
                    "This can happen if there are leaks in the data or if there are no files for the requested time in the given directory.",
                    "The corresponding output will be left filled with zeros.\n",
                    f"    Requested range (Posixtimestamps in ms): [{t_start}, {t_end}[\n",
                    f"    Filepath: {file_path}.")
            return NP.zeros(shape=[0, 0])
        assert idx_end == shape[0] or idx_end > idx_start, f"idx_start={idx_start}, idx_end={idx_end}."
        assert idx_start < idx_end
 
        out, err = (
            FFMPEG
            .input(file_path)
            .filter('atrim', start_sample=idx_start*shape[1], end_sample=idx_end*shape[1])
            .output('pipe:', format='s16le', acodec='pcm_s16le', ac=int(info['channels']), ar=int(info['sample_rate']))
            .run(capture_stdout=True, capture_stderr=True)
        )
        data = NP.frombuffer(out, dtype=NP.int16)
        data = data.reshape([-1, shape[1]])
    except FFMPEG.Error as e:
        raise Exception(e.stderr.decode("utf-8"))
    except FileNotFoundError as e:
        raise Exception("ffmpeg not found. Please install ffmpeg."
		+ "If you are working on desys maxwell cluster, "
                + "execute 'module load maxwell ffmpeg'")
    
    # Trim data
    data = data[:, channel_start:channel_end]

    data = data.astype(NP.float32) #This needs to hapen before the binning step!

    # Downsample data
    if t_step != 1 or channel_step != 1:
        data = bin(data, (t_step, channel_step))
    #if t_step != 1:
    #    data = data[::t_step]
    #if channel_step != 1:
    #    data = data[:, ::channel_step]
    assert len(data) > 0

    if CALIBRATE:
        data *= calibration_factor

    return data

