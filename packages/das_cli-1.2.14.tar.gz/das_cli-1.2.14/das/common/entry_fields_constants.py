# Constants for Entry Fields - Input Types
SELECT_COMBO_INPUT = 4
DIGITAL_OBJECT_INPUT = 13
GROUP_BOX_INPUT = 34
