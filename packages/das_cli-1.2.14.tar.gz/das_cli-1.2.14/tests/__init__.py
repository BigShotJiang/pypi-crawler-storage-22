"""
Unit tests for the DAS CLI application
"""
