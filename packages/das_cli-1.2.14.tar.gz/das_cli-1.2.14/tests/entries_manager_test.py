import code
from dotenv import load_dotenv
import unittest
import os

from das.app import Das
from das.common.config import save_api_url
from das.managers.entries_manager import EntryManager

# Load environment variables from .env file
load_dotenv()

class TestEntriesManager(unittest.TestCase):
    def setUp(self):
        """Set up test fixtures before each test method"""        
        self.das_client = Das(base_url=os.getenv("API_URL"))
        self.das_client.authenticate(username=os.getenv("USER_NAME"), password=os.getenv("USER_PASSWORD"))
        self.entry_manager = EntryManager()

    def test_create_entry(self):
        """Test creating an entry"""
        
        entry_data = {
            "Alias": "test.entry.001",
            "Event": "64PE428-02PC",
            "Number": 1,
            "Number Alias": "001",
            "Start Depth": 576,
            "End Depth": 600,
            "Length": 24,
            "Diameter": 12,
            "Storage location":  "OCS-refrigerator4 (core-lab)",
            "Availability": "pc.b.b",
            "Comment": "This is a test entry created by unit test."
        }

        created_entry_id = self.entry_manager.create(attribute="Cores", entry=entry_data)

        self.assertIsNotNone(created_entry_id)
        # assert createrd entry id is an guid
        self.assertRegex(created_entry_id[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')

    def test_delete_entry(self):
        """Test deleting an entry"""

        entry_data = {
            "Alias": "test.entry.001",
            "Event": "64PE428-02PC",
            "Number": 1,
            "Number Alias": "001",
            "Start Depth": 576,
            "End Depth": 600,
            "Length": 24,
            "Diameter": 12,
            "Storage location":  "OCS-refrigerator4 (core-lab)",
            "Availability": "pc.b.b",
            "Comment": "This is a test entry created by unit test."
        }

        response = self.entry_manager.create(attribute="Cores", entry=entry_data)  

        self.assertTrue(self.entry_manager.delete(id=response[0]['id']))

    def test_delete_entry_by_code(self):
        """Test deleting an entry by code"""

        entry_data = {
            "Alias": "test.entry.001",
            "Event": "64PE428-02PC",
            "Number": 1,
            "Number Alias": "001",
            "Start Depth": 576,
            "End Depth": 600,
            "Length": 24,
            "Diameter": 12,
            "Storage location":  "OCS-refrigerator4 (core-lab)",
            "Availability": "pc.b.b",
            "Comment": "This is a test entry created by unit test."
        }

        response = self.entry_manager.create(attribute="Cores", entry=entry_data)  

        entry = self.entry_manager.get(id=response[0]['id'])    

        self.assertIsNotNone(entry)

        self.assertTrue(self.entry_manager.delete(code=entry['Code']))        

    def test_update_entry(self):
        """Test updating an entry"""
        
        updated_entry_data = {
            "Availability": "pc.b.c",
            "Number" : 2,
            "diameterincm": 15,
            "27": "ca9ab414-31e1-4aa7-98b9-b69744ffee92"
        }

        updated_entry_id = self.entry_manager.update(id="9b826efc-36f3-471c-ad18-9c1e00abe4fa", entry=updated_entry_data)
        self.assertIsNotNone(updated_entry_id)
        self.assertRegex(updated_entry_id[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')

    def test_update_entry_by_code(self):
        """Test updating an entry"""
        
        updated_entry_data = {
            "Availability": "pc.b.c",
            "Number" : 2,
            "diameterincm": 15,
            "27": "#2319-03_03HM"
        }

        updated_entry_id = self.entry_manager.update(code="zb.b.0", entry=updated_entry_data)
        self.assertIsNotNone(updated_entry_id)
        self.assertRegex(updated_entry_id[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')        


    def test_create_entry_with_json_file(self):
        """Test creating an entry from a JSON file"""
        file_path = os.path.join(os.path.dirname(__file__), 'test_data', 'entry_data.json')
        self.entry_manager.create_from_file(attribute="Cores", file_path=file_path)
        # If no exception is raised, the test is considered passed for this example

    def test_create_entry_with_csv_file(self):
        """Test creating an entry from a CSV file"""
        file_path = os.path.join(os.path.dirname(__file__), 'test_data', 'sample_entry.csv')
        self.entry_manager.create_from_file(attribute="Cores", file_path=file_path)
        # If no exception is raised, the test is considered passed for this example

    # def test_create_entry_with_excel_file(self):
    #     """Test creating an entry from an Excel file"""
    #     file_path = os.path.join(os.path.dirname(__file__), 'test_data', 'entry_data.xlsx')
    #     self.entry_manager.create_from_file(attribute="Cores", file_path=file_path)
    #     # If no exception is raised, the test is considered passed for this example

    def test_update_entry_with_column_names(self):
            """Test updating an entry with column names"""
            updated_entry_data = {
                'displayname': 'Eveline Garritsen-van Arnhem', 
                'personid': 100015, 
                'name': 'Eveline', 
                'surname': 'Garritsen-van Arnhem', 
                'phonenumber': '+31222369559', 
                'emailaddress': 'eveline.garritsen@nioz.nl', 
                'jobtitle': 'Research Assistant', 
                'DutchJobTitle': 'Onderzoekmedewerker', 
                'contractenddate': '2034-12-01', 
                'showuntildate': '2034-12-01', 
                'educationaltitle': 'ing.', 
                'educationaldegree': None, 
                'location': 'T', 
                'taborder': 3, 
                'IsDefaultProfileOnWebsite': False, 
                'isPrivate': True, 
                '128': [{'id': 'd080b26e-2db0-4d68-acae-44c3a7399c51', 'attributeid': 128}]
                }

            updated_entry_id = self.entry_manager.update(id="994a9fa5-5ccb-11f0-aafa-a84a63c8db73", entry=updated_entry_data)
            self.assertIsNotNone(updated_entry_id[0]['id'])
            self.assertRegex(updated_entry_id[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')

    def test_create_entry_with_column_names(self):
        """Test creating an entry with column names"""
        created_entry_data = {
            'displayname': 'Maximilian Garritsen-van Arnhem', 
            'personid': 100099, 
            'name': 'Maximilian', 
            'surname': 'Garritsen-van Arnhem', 
        }
        created_entry_id = self.entry_manager.create(attribute="Person", entry=created_entry_data)
        self.assertIsNotNone(created_entry_id[0]['id'])
        self.assertRegex(created_entry_id[0]['id'], r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')    