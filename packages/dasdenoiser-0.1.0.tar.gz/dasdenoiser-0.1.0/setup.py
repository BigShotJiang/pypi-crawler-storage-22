from setuptools import setup

setup(
    name="dasdenoiser",
    version="0.1.0",
    long_description="dasdenoiser",
    long_description_content_type="text/markdown",
    packages=["dasdenoiser"],
    install_requires=["numpy",  "h5py", "matplotlib", "pandas"],
)
