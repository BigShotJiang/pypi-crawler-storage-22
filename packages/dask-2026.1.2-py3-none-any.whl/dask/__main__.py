from __future__ import annotations

from dask.cli import run_cli


def main():
    run_cli()


if __name__ == "__main__":
    main()
