from __future__ import annotations

from dask.dataframe.io.parquet.core import create_metadata_file, read_parquet_part
