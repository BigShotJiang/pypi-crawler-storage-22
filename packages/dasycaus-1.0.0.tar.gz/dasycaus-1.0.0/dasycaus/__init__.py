"""
Dynamic Asymmetric Causality Tests (DASYCAUS)

A Python library for Dynamic Asymmetric and Symmetric Causality Tests
based on Hatemi-J (2012, 2021) methodology.

Author: Dr. Merwan Roudane
Email: merwanroudane920@gmail.com
GitHub: https://github.com/merwanroudane/dasycaus

Based on:
- Hatemi-J, A. (2021). Dynamic Asymmetric Causality Tests with an Application. 
  Papers 2106.07612, arXiv.org.
- Hatemi-J, A. (2012). Asymmetric Causality Tests with an Application. 
  Empirical Economics, 43, 447-456.
- Hacker, S. and Hatemi-J, A. (2006). Tests for causality between integrated 
  variables using asymptotic and bootstrap distributions: theory and application. 
  Applied Economics, 38(13), 1489-1500.
- Hacker, S. and Hatemi-J, A. (2012). A bootstrap test for causality with 
  endogenous lag length choice: theory and application in finance. 
  Journal of Economic Studies, 39(2), 144-160.
"""

__version__ = "1.0.0"
__author__ = "Dr. Merwan Roudane"
__email__ = "merwanroudane920@gmail.com"

from .core import (
    dynamic_asymmetric_causality_test,
    dynamic_symmetric_causality_test,
    asymmetric_causality_test,
    symmetric_causality_test
)

from .data_transform import (
    transform_to_cumulative_components,
    compute_positive_negative_shocks
)

from .bootstrap import (
    bootstrap_critical_values,
    leveraged_bootstrap
)

from .lag_selection import (
    select_optimal_lag,
    information_criteria
)

from .utils import (
    generate_subsamples,
    compute_test_ratio,
    plot_dynamic_causality
)

__all__ = [
    'dynamic_asymmetric_causality_test',
    'dynamic_symmetric_causality_test',
    'asymmetric_causality_test',
    'symmetric_causality_test',
    'transform_to_cumulative_components',
    'compute_positive_negative_shocks',
    'bootstrap_critical_values',
    'leveraged_bootstrap',
    'select_optimal_lag',
    'information_criteria',
    'generate_subsamples',
    'compute_test_ratio',
    'plot_dynamic_causality'
]
