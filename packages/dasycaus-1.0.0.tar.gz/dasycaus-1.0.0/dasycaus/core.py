"""
Core module for Dynamic Asymmetric Causality Tests

This module contains the main functions for conducting static and dynamic
asymmetric and symmetric causality tests.
"""

import numpy as np
from typing import Dict, List, Tuple, Optional, Union
from .data_transform import transform_to_cumulative_components
from .lag_selection import select_optimal_lag
from .bootstrap import bootstrap_critical_values
from .utils import generate_subsamples, compute_test_ratio
import warnings


def symmetric_causality_test(
    data: np.ndarray,
    maxlags: int,
    integration_order: int = 1,
    info_criterion: str = 'hjc',
    bootstrap_sims: int = 1000,
    significance_levels: List[float] = [0.05, 0.10],
    random_seed: Optional[int] = 30540
) -> Dict:
    """
    Conduct static symmetric Granger causality test.
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n) where T is the number of observations
        and n is the number of variables. First column is the dependent variable.
    maxlags : int
        Maximum lag order to consider.
    integration_order : int, default=1
        Integration order of the variables (0=stationary, 1=I(1), 2=I(2)).
    info_criterion : str, default='hjc'
        Information criterion for lag selection: 'aic', 'aicc', 'sbc', 'hqc', 'hjc'.
    bootstrap_sims : int, default=1000
        Number of bootstrap simulations for critical values.
    significance_levels : list, default=[0.05, 0.10]
        List of significance levels for testing.
    random_seed : int, optional
        Random seed for reproducibility.
        
    Returns
    -------
    dict
        Dictionary containing test results with keys:
        - 'test_statistic': Wald test statistic
        - 'optimal_lag': Selected optimal lag order
        - 'critical_values': Dict of critical values for each significance level
        - 'p_values': Approximate p-values
        - 'reject_null': Dict indicating rejection at each significance level
    """
    if random_seed is not None:
        np.random.seed(random_seed)
    
    T, n = data.shape
    
    # Select optimal lag order
    lag_info = select_optimal_lag(
        data, 
        maxlags, 
        info_criterion=info_criterion,
        integration_order=integration_order
    )
    optimal_lag = lag_info['optimal_lag']
    
    # Estimate VAR model and compute Wald test statistic
    test_stat = _compute_wald_statistic(
        data, 
        optimal_lag, 
        integration_order
    )
    
    # Bootstrap critical values
    critical_vals = {}
    for alpha in significance_levels:
        cv = bootstrap_critical_values(
            data,
            optimal_lag,
            integration_order,
            bootstrap_sims,
            alpha,
            random_seed
        )
        critical_vals[alpha] = cv
    
    # Determine rejection decisions
    reject_null = {alpha: test_stat > critical_vals[alpha] 
                   for alpha in significance_levels}
    
    # Approximate p-value using chi-square distribution
    from scipy.stats import chi2
    df = optimal_lag * (n - 1)  # Degrees of freedom
    p_value = 1 - chi2.cdf(test_stat, df)
    
    return {
        'test_statistic': test_stat,
        'optimal_lag': optimal_lag,
        'critical_values': critical_vals,
        'p_value': p_value,
        'reject_null': reject_null,
        'degrees_of_freedom': df
    }


def asymmetric_causality_test(
    data: np.ndarray,
    maxlags: int,
    component: str = 'positive',
    integration_order: int = 1,
    info_criterion: str = 'hjc',
    bootstrap_sims: int = 1000,
    significance_levels: List[float] = [0.05, 0.10],
    random_seed: Optional[int] = 30540,
    include_trend: bool = True
) -> Dict:
    """
    Conduct static asymmetric Granger causality test.
    
    Parameters
    ----------
    data : np.ndarray
        Original data matrix with shape (T, n).
    maxlags : int
        Maximum lag order to consider.
    component : str, default='positive'
        Which component to test: 'positive' or 'negative'.
    integration_order : int, default=1
        Integration order of the original variables.
    info_criterion : str, default='hjc'
        Information criterion for lag selection.
    bootstrap_sims : int, default=1000
        Number of bootstrap simulations.
    significance_levels : list, default=[0.05, 0.10]
        List of significance levels.
    random_seed : int, optional
        Random seed for reproducibility.
    include_trend : bool, default=True
        Whether to include deterministic trend in transformation.
        
    Returns
    -------
    dict
        Dictionary containing test results.
    """
    if random_seed is not None:
        np.random.seed(random_seed)
    
    # Transform data to cumulative positive/negative components
    transformed_data = transform_to_cumulative_components(
        data,
        component=component,
        include_trend=include_trend
    )
    
    # Conduct symmetric causality test on transformed data
    # The transformed data is I(1) if original data is I(1)
    result = symmetric_causality_test(
        transformed_data,
        maxlags,
        integration_order=1,  # Cumulative components are I(1)
        info_criterion=info_criterion,
        bootstrap_sims=bootstrap_sims,
        significance_levels=significance_levels,
        random_seed=random_seed
    )
    
    result['component'] = component
    result['original_integration_order'] = integration_order
    
    return result


def dynamic_symmetric_causality_test(
    data: np.ndarray,
    maxlags: int,
    integration_order: int = 1,
    info_criterion: str = 'hjc',
    bootstrap_sims: int = 1000,
    significance_levels: List[float] = [0.05, 0.10],
    subsample_method: str = 'recursive',
    random_seed: Optional[int] = 30540
) -> Dict:
    """
    Conduct dynamic symmetric Granger causality tests using subsamples.
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n).
    maxlags : int
        Maximum lag order to consider.
    integration_order : int, default=1
        Integration order of the variables.
    info_criterion : str, default='hjc'
        Information criterion for lag selection.
    bootstrap_sims : int, default=1000
        Number of bootstrap simulations.
    significance_levels : list, default=[0.05, 0.10]
        List of significance levels.
    subsample_method : str, default='recursive'
        Method for creating subsamples: 'recursive' or 'rolling'.
    random_seed : int, optional
        Random seed for reproducibility.
        
    Returns
    -------
    dict
        Dictionary containing:
        - 'subsamples': List of subsample results
        - 'test_ratios': Array of test statistic / critical value ratios
        - 'subsample_sizes': Array of subsample sizes
        - 'rejection_pattern': Pattern of null hypothesis rejections
    """
    if random_seed is not None:
        np.random.seed(random_seed)
    
    T = data.shape[0]
    
    # Generate subsamples
    subsamples = generate_subsamples(T, method=subsample_method)
    
    results = []
    test_ratios = {alpha: [] for alpha in significance_levels}
    
    for i, (start_idx, end_idx) in enumerate(subsamples):
        subsample_data = data[start_idx:end_idx, :]
        
        # Conduct causality test on subsample
        try:
            result = symmetric_causality_test(
                subsample_data,
                maxlags,
                integration_order,
                info_criterion,
                bootstrap_sims,
                significance_levels,
                random_seed=random_seed + i if random_seed else None
            )
            
            results.append(result)
            
            # Compute test ratio for each significance level
            for alpha in significance_levels:
                ratio = compute_test_ratio(
                    result['test_statistic'],
                    result['critical_values'][alpha]
                )
                test_ratios[alpha].append(ratio)
                
        except Exception as e:
            warnings.warn(f"Error in subsample {i}: {str(e)}")
            results.append(None)
            for alpha in significance_levels:
                test_ratios[alpha].append(np.nan)
    
    # Convert to arrays
    for alpha in significance_levels:
        test_ratios[alpha] = np.array(test_ratios[alpha])
    
    subsample_sizes = np.array([end - start for start, end in subsamples])
    
    return {
        'subsamples': results,
        'test_ratios': test_ratios,
        'subsample_indices': subsamples,
        'subsample_sizes': subsample_sizes,
        'method': subsample_method,
        'significance_levels': significance_levels
    }


def dynamic_asymmetric_causality_test(
    data: np.ndarray,
    maxlags: int,
    component: str = 'positive',
    integration_order: int = 1,
    info_criterion: str = 'hjc',
    bootstrap_sims: int = 1000,
    significance_levels: List[float] = [0.05, 0.10],
    subsample_method: str = 'recursive',
    random_seed: Optional[int] = 30540,
    include_trend: bool = True
) -> Dict:
    """
    Conduct dynamic asymmetric Granger causality tests using subsamples.
    
    Parameters
    ----------
    data : np.ndarray
        Original data matrix with shape (T, n).
    maxlags : int
        Maximum lag order to consider.
    component : str, default='positive'
        Which component to test: 'positive' or 'negative'.
    integration_order : int, default=1
        Integration order of the original variables.
    info_criterion : str, default='hjc'
        Information criterion for lag selection.
    bootstrap_sims : int, default=1000
        Number of bootstrap simulations.
    significance_levels : list, default=[0.05, 0.10]
        List of significance levels.
    subsample_method : str, default='recursive'
        Method for creating subsamples: 'recursive' or 'rolling'.
    random_seed : int, optional
        Random seed for reproducibility.
    include_trend : bool, default=True
        Whether to include deterministic trend in transformation.
        
    Returns
    -------
    dict
        Dictionary containing dynamic test results.
    """
    if random_seed is not None:
        np.random.seed(random_seed)
    
    # Transform data to cumulative components
    transformed_data = transform_to_cumulative_components(
        data,
        component=component,
        include_trend=include_trend
    )
    
    # Conduct dynamic symmetric test on transformed data
    result = dynamic_symmetric_causality_test(
        transformed_data,
        maxlags,
        integration_order=1,  # Cumulative components are I(1)
        info_criterion=info_criterion,
        bootstrap_sims=bootstrap_sims,
        significance_levels=significance_levels,
        subsample_method=subsample_method,
        random_seed=random_seed
    )
    
    result['component'] = component
    result['original_integration_order'] = integration_order
    
    return result


def _compute_wald_statistic(
    data: np.ndarray,
    lag_order: int,
    integration_order: int
) -> float:
    """
    Compute Wald test statistic for Granger causality.
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n).
    lag_order : int
        Lag order for VAR model.
    integration_order : int
        Integration order (for adding extra lags as per Toda-Yamamoto).
        
    Returns
    -------
    float
        Wald test statistic.
    """
    T, n = data.shape
    
    # Add extra lags for unit roots (Toda-Yamamoto approach)
    total_lags = lag_order + integration_order
    
    # Create lagged matrix
    Y, X = _create_var_matrices(data, total_lags)
    
    # Estimate unrestricted VAR
    A_hat = np.linalg.lstsq(X, Y, rcond=None)[0]
    residuals = Y - X @ A_hat
    Sigma_u = (residuals.T @ residuals) / (T - total_lags - 1)
    
    # Create restriction matrix C
    # We test if variable 2 does not cause variable 1
    # This means testing if coefficients of variable 2 in equation 1 are zero
    C = _create_restriction_matrix(n, lag_order, integration_order)
    
    # Compute Wald statistic
    beta = A_hat.flatten('F')  # Fortran-style (column-major) flattening
    
    # Compute (Z'Z)^-1 ⊗ Sigma_u
    XTX_inv = np.linalg.inv(X.T @ X)
    bread = np.kron(XTX_inv, Sigma_u)
    
    C_beta = C @ beta
    variance = C @ bread @ C.T
    
    # Wald test statistic
    wald_stat = C_beta.T @ np.linalg.inv(variance) @ C_beta
    
    return float(wald_stat)


def _create_var_matrices(
    data: np.ndarray,
    lags: int
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Create Y and X matrices for VAR estimation.
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n).
    lags : int
        Number of lags.
        
    Returns
    -------
    tuple
        (Y, X) where Y is dependent variable matrix and X is regressor matrix.
    """
    T, n = data.shape
    
    # Create lagged data
    Y = data[lags:, :]
    
    # Create X matrix with intercept and lags
    X_list = [np.ones((T - lags, 1))]
    
    for lag in range(1, lags + 1):
        X_list.append(data[lags - lag : T - lag, :])
    
    X = np.hstack(X_list)
    
    return Y, X


def _create_restriction_matrix(
    n: int,
    lag_order: int,
    integration_order: int
) -> np.ndarray:
    """
    Create restriction matrix C for testing causality from variable 2 to variable 1.
    
    Parameters
    ----------
    n : int
        Number of variables.
    lag_order : int
        Lag order for testing.
    integration_order : int
        Integration order (extra lags not tested).
        
    Returns
    -------
    np.ndarray
        Restriction matrix C.
    """
    # Total parameters per equation: 1 (intercept) + n * (lag_order + integration_order)
    total_lags = lag_order + integration_order
    params_per_eq = 1 + n * total_lags
    
    # We test if variable 2 causes variable 1
    # Restrictions: coefficients of variable 2 in equation 1 for lags 1 to lag_order
    num_restrictions = lag_order
    C = np.zeros((num_restrictions, n * params_per_eq))
    
    # Equation 1 starts at column 0
    # Intercept is at position 0
    # Variable 1, lag 1 is at position 1
    # Variable 2, lag 1 is at position 2
    # Variable 1, lag 2 is at position 3
    # Variable 2, lag 2 is at position 4
    # etc.
    
    for i in range(lag_order):
        # Position of variable 2 at lag i+1 in equation 1
        pos = 1 + i * n + 1  # 1 for intercept, i*n for previous lags, +1 for variable 2
        C[i, pos] = 1
    
    return C
