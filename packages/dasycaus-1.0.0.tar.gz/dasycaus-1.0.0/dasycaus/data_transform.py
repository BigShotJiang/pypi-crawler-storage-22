"""
Data transformation module for asymmetric causality tests.

This module handles the transformation of integrated variables into
cumulative positive and negative components.

CORRECTED VERSION - Matches GAUSS code exactly (lines 127-152)
"""

import numpy as np
from typing import Tuple, Optional


def transform_to_cumulative_components(
    data: np.ndarray,
    component: str = 'positive',
    include_trend: bool = False
) -> np.ndarray:
    """
    Transform integrated variables into cumulative positive or negative components.
    
    **CORRECTED to match GAUSS implementation (lines 127-152)**
    
    GAUSS Code:
        dYZ = YZlevel[2:Levnumobs,.] - YZlevel[1:(Levnumobs-1),.];
        DYZpc = recode(DYZ, notpositive, 0);  # positive changes
        DYZnc = recode(DYZ, notnegative, 0);  # negative changes
        CumDYZpc = cumsumc(DYZpc);
        CumDYZnc = cumsumc(DYZnc);
    
    NOTE: GAUSS does NOT include deterministic trend adjustment!
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n) where T is number of observations
        and n is number of variables. Data should be I(1).
    component : str, default='positive'
        Component to extract: 'positive' or 'negative'.
    include_trend : bool, default=False
        Whether to include deterministic trend (default False to match GAUSS).
        Set to True only if you want paper equations (5)-(8) with trend.
        
    Returns
    -------
    np.ndarray
        Transformed data with cumulative positive or negative components.
        Shape: (T-1, n)
        
    Notes
    -----
    Default behavior (include_trend=False) matches GAUSS code:
    1. Take first differences: dY = Y[t] - Y[t-1]
    2. Extract positive or negative parts
    3. Cumulative sum
    
    With include_trend=True, uses paper formulas (5)-(8):
    x_t^+ = at + [t(t+1)/2]b + x_0/2 + sum(epsilon_i^+)
    x_t^- = at + [t(t+1)/2]b + x_0/2 + sum(epsilon_i^-)
    """
    if component not in ['positive', 'negative']:
        raise ValueError("component must be 'positive' or 'negative'")
    
    T, n = data.shape
    
    if not include_trend:
        # GAUSS implementation (DEFAULT)
        # Take first differences
        dY = np.diff(data, axis=0)
        
        # Extract positive or negative components
        if component == 'positive':
            dY_component = np.maximum(dY, 0)
        else:  # negative
            dY_component = np.minimum(dY, 0)
        
        # Cumulative sum
        cumulative_components = np.cumsum(dY_component, axis=0)
        
    else:
        # Paper implementation with deterministic trend
        cumulative_components = np.zeros((T, n))
        
        for col in range(n):
            x = data[:, col]
            dx = np.diff(x)
            t_trend = np.arange(1, T)
            X_reg = np.column_stack([np.ones(T - 1), t_trend])
            params = np.linalg.lstsq(X_reg, dx, rcond=None)[0]
            a_hat, b_hat = params[0], params[1]
            epsilon = dx - (a_hat + b_hat * t_trend)
            
            if component == 'positive':
                epsilon_component = np.maximum(epsilon, 0)
            else:
                epsilon_component = np.minimum(epsilon, 0)
            
            x0 = x[0]
            cumulative_components[0, col] = x0 / 2
            
            for t in range(1, T):
                trend_part = a_hat * t + (t * (t + 1) / 2) * b_hat
                cumsum_shocks = np.sum(epsilon_component[:t])
                cumulative_components[t, col] = x0 / 2 + trend_part + cumsum_shocks
        
    return cumulative_components


def compute_positive_negative_shocks(
    data: np.ndarray,
    include_trend: bool = False
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute positive and negative shocks from data.
    
    **CORRECTED to match GAUSS by default**
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n).
    include_trend : bool, default=False
        Whether to include deterministic trend (default False matches GAUSS).
        
    Returns
    -------
    tuple
        (positive_shocks, negative_shocks) each with shape (T-1, n).
    """
    T, n = data.shape
    
    if not include_trend:
        dx = np.diff(data, axis=0)
        positive_shocks = np.maximum(dx, 0)
        negative_shocks = np.minimum(dx, 0)
    else:
        positive_shocks = np.zeros((T - 1, n))
        negative_shocks = np.zeros((T - 1, n))
        
        for col in range(n):
            x = data[:, col]
            dx = np.diff(x)
            t_trend = np.arange(1, T)
            X_reg = np.column_stack([np.ones(T - 1), t_trend])
            params = np.linalg.lstsq(X_reg, dx, rcond=None)[0]
            epsilon = dx - (params[0] + params[1] * t_trend)
            
            positive_shocks[:, col] = np.maximum(epsilon, 0)
            negative_shocks[:, col] = np.minimum(epsilon, 0)
    
    return positive_shocks, negative_shocks


def verify_transformation(
    original_data: np.ndarray,
    positive_components: np.ndarray,
    negative_components: np.ndarray,
    tolerance: float = 1e-10
) -> bool:
    """Verify that x_t = x_t^+ + x_t^- holds."""
    min_len = min(original_data.shape[0], positive_components.shape[0])
    reconstructed = positive_components[:min_len] + negative_components[:min_len]
    max_diff = np.max(np.abs(original_data[:min_len] - reconstructed))
    
    if max_diff > tolerance:
        print(f"Warning: Maximum difference = {max_diff}")
        return False
    return True


def transform_differences_to_components(
    data: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """Transform differenced data directly into positive and negative components."""
    positive_changes = np.maximum(data, 0)
    negative_changes = np.minimum(data, 0)
    cumulative_positive = np.cumsum(positive_changes, axis=0)
    cumulative_negative = np.cumsum(negative_changes, axis=0)
    return cumulative_positive, cumulative_negative
