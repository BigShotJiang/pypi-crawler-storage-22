"""
Lag selection module using information criteria.

CORRECTED VERSION - Matches GAUSS code exactly (lines 830-944)
"""

import numpy as np
from typing import Dict, Optional, Tuple
import warnings


def select_optimal_lag(
    data: np.ndarray,
    maxlags: int,
    info_criterion: str = 'hjc',
    integration_order: int = 1,
    minlags: int = 1
) -> Dict:
    """
    Select optimal lag order using information criteria.
    
    **CORRECTED to match GAUSS implementation**
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n).
    maxlags : int
        Maximum lag order to consider.
    info_criterion : str, default='hjc'
        Information criterion: 'aic', 'aicc', 'sbc', 'hqc', or 'hjc'.
    integration_order : int, default=1
        Integration order of variables (not used in criterion calculation).
    minlags : int, default=1
        Minimum lag order to consider.
        
    Returns
    -------
    dict
        Dictionary containing optimal lag and related information.
    """
    if info_criterion not in ['aic', 'aicc', 'sbc', 'hqc', 'hjc']:
        raise ValueError(f"Unknown information criterion: {info_criterion}")
    
    T, n = data.shape
    
    if maxlags >= T - 1:
        warnings.warn(f"maxlags ({maxlags}) too large for sample size ({T}). "
                     f"Setting maxlags to {T - 2}")
        maxlags = T - 2
    
    # Compute information criteria for all lags
    criteria_values = {}
    coefficient_matrices = {}
    
    for lag in range(minlags, maxlags + 1):
        try:
            ic_value, coef_matrix = _compute_information_criterion(
                data, lag, info_criterion
            )
            criteria_values[lag] = ic_value
            coefficient_matrices[lag] = coef_matrix
        except Exception as e:
            warnings.warn(f"Could not compute criterion for lag {lag}: {str(e)}")
            criteria_values[lag] = np.inf
            coefficient_matrices[lag] = None
    
    # Select optimal lag (minimum criterion value)
    optimal_lag = min(criteria_values.keys(), key=lambda k: criteria_values[k])
    
    return {
        'optimal_lag': optimal_lag,
        'criterion_value': criteria_values[optimal_lag],
        'all_criteria': criteria_values,
        'coefficient_matrix': coefficient_matrices[optimal_lag],
        'criterion_name': info_criterion
    }


def _compute_information_criterion(
    data: np.ndarray,
    lag_order: int,
    criterion: str
) -> Tuple[float, np.ndarray]:
    """
    Compute information criterion value.
    
    **CORRECTED to match GAUSS code (lines 867-871)**
    
    GAUSS Code:
        aic = ln(det(VARCOV)) + (2/T)*(M*M*lag_guess +M)+ M*(1+ln(2*pi));
        aicc = ln(det(VARCOV)) + ((T + (1+lag_guess*M))*M)/(T - (1+lag_guess*M) - M -1);
        sbc = ln(det(VARCOV)) + (1/T)*(M*M*lag_guess+M)*ln(T)+ M*(1+ln(2*pi));
        hqc = ln(det(VARCOV)) + (2/T)*(M*M*lag_guess+M)*ln(ln(T))+ M*(1+ln(2*pi));
        hjc = (sbc + hqc)/2;
    
    Where M = number of variables, T = effective sample size
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n).
    lag_order : int
        Lag order (p).
    criterion : str
        Name of criterion.
        
    Returns
    -------
    tuple
        (criterion_value, coefficient_matrix)
    """
    T, n = data.shape
    
    # Create VAR matrices
    Y, X = _create_var_matrices(data, lag_order)
    T_eff = Y.shape[0]
    
    # Estimate VAR model
    A_hat = np.linalg.lstsq(X, Y, rcond=None)[0]
    residuals = Y - X @ A_hat
    
    # Variance-covariance matrix (GAUSS uses T_eff, not T_eff - k)
    Sigma = (residuals.T @ residuals) / T_eff
    
    # Log determinant of covariance matrix
    log_det_sigma = np.log(np.linalg.det(Sigma))
    
    # Constant term (GAUSS includes this)
    const = n * (1 + np.log(2 * np.pi))
    
    # Compute criterion (MATCHING GAUSS EXACTLY)
    if criterion == 'aic':
        # GAUSS: ln(det(VARCOV)) + (2/T)*(M*M*lag_guess + M) + M*(1+ln(2*pi))
        ic_value = (log_det_sigma + 
                   (2 / T_eff) * (n * n * lag_order + n) + 
                   const)
        
    elif criterion == 'aicc':
        # GAUSS: ln(det(VARCOV)) + ((T + (1+lag_guess*M))*M)/(T - (1+lag_guess*M) - M -1)
        ic_value = (log_det_sigma + 
                   ((T_eff + (1 + lag_order * n)) * n) / 
                   (T_eff - (1 + lag_order * n) - n - 1))
        
    elif criterion == 'sbc':
        # GAUSS: ln(det(VARCOV)) + (1/T)*(M*M*lag_guess+M)*ln(T) + M*(1+ln(2*pi))
        ic_value = (log_det_sigma + 
                   (1 / T_eff) * (n * n * lag_order + n) * np.log(T_eff) + 
                   const)
        
    elif criterion == 'hqc':
        # GAUSS: ln(det(VARCOV)) + (2/T)*(M*M*lag_guess+M)*ln(ln(T)) + M*(1+ln(2*pi))
        ic_value = (log_det_sigma + 
                   (2 / T_eff) * (n * n * lag_order + n) * np.log(np.log(T_eff)) + 
                   const)
        
    elif criterion == 'hjc':
        # GAUSS: hjc = (sbc + hqc)/2
        sbc_val = (log_det_sigma + 
                  (1 / T_eff) * (n * n * lag_order + n) * np.log(T_eff) + 
                  const)
        hqc_val = (log_det_sigma + 
                  (2 / T_eff) * (n * n * lag_order + n) * np.log(np.log(T_eff)) + 
                  const)
        ic_value = (sbc_val + hqc_val) / 2
    
    return float(ic_value), A_hat


def _create_var_matrices(
    data: np.ndarray,
    lags: int
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Create Y and X matrices for VAR estimation.
    
    Matches GAUSS varlags procedure.
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n).
    lags : int
        Number of lags.
        
    Returns
    -------
    tuple
        (Y, X) matrices where:
        - Y: dependent variables (T-lags, n)
        - X: regressors with intercept and lags (T-lags, 1+n*lags)
    """
    T, n = data.shape
    
    # Dependent variables
    Y = data[lags:, :]
    
    # Create X matrix: constant + lagged values
    X_list = [np.ones((T - lags, 1))]
    
    for lag in range(1, lags + 1):
        X_list.append(data[lags - lag : T - lag, :])
    
    X = np.hstack(X_list)
    
    return Y, X


def information_criteria(
    data: np.ndarray,
    lag_order: int
) -> Dict[str, float]:
    """
    Compute all information criteria for a given lag order.
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n).
    lag_order : int
        Lag order for VAR model.
        
    Returns
    -------
    dict
        Dictionary with keys 'aic', 'aicc', 'sbc', 'hqc', 'hjc' and their values.
    """
    criteria = {}
    
    for criterion_name in ['aic', 'aicc', 'sbc', 'hqc', 'hjc']:
        value, _ = _compute_information_criterion(data, lag_order, criterion_name)
        criteria[criterion_name] = value
    
    return criteria


def compare_criteria(
    data: np.ndarray,
    maxlags: int,
    minlags: int = 1
) -> Dict:
    """
    Compare all information criteria across lag orders.
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix with shape (T, n).
    maxlags : int
        Maximum lag order.
    minlags : int, default=1
        Minimum lag order.
        
    Returns
    -------
    dict
        Dictionary with optimal lags for each criterion and all values.
    """
    criteria_names = ['aic', 'aicc', 'sbc', 'hqc', 'hjc']
    
    results = {name: {'lags': [], 'values': []} for name in criteria_names}
    optimal_lags = {}
    
    for lag in range(minlags, maxlags + 1):
        criteria = information_criteria(data, lag)
        
        for name in criteria_names:
            results[name]['lags'].append(lag)
            results[name]['values'].append(criteria[name])
    
    # Find optimal lag for each criterion
    for name in criteria_names:
        values = results[name]['values']
        optimal_idx = np.argmin(values)
        optimal_lags[name] = results[name]['lags'][optimal_idx]
    
    return {
        'optimal_lags': optimal_lags,
        'criteria_values': results
    }
