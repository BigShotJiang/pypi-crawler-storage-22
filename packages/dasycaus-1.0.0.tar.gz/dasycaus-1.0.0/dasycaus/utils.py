"""
Utility functions for dynamic causality testing.

This module provides helper functions for subsample generation, test ratio computation,
and visualization of results.
"""

import numpy as np
from typing import List, Tuple, Optional
import warnings


def generate_subsamples(
    T: int,
    method: str = 'recursive',
    min_sample_size: Optional[int] = None
) -> List[Tuple[int, int]]:
    """
    Generate subsamples for dynamic causality testing.
    
    Parameters
    ----------
    T : int
        Full sample size.
    method : str, default='recursive'
        Method for generating subsamples:
        - 'recursive': Start with min size, add one observation each time
        - 'rolling': Fixed window size, roll forward one observation each time
    min_sample_size : int, optional
        Minimum subsample size. If None, computed using Phillips et al. (2015) formula.
        
    Returns
    -------
    list
        List of (start_index, end_index) tuples for each subsample.
        
    Notes
    -----
    The minimum subsample size formula from Phillips et al. (2015):
    S = [T * (0.01 + 1.8 / sqrt(T))]
    """
    # Compute minimum subsample size if not provided
    if min_sample_size is None:
        S = int(np.ceil(T * (0.01 + 1.8 / np.sqrt(T))))
    else:
        S = min_sample_size
    
    # Ensure minimum size is reasonable
    if S < 10:
        S = 10
        warnings.warn(f"Minimum subsample size set to 10 (originally computed as {S})")
    
    if S >= T:
        raise ValueError(f"Minimum subsample size ({S}) must be less than full sample size ({T})")
    
    subsamples = []
    
    if method == 'recursive':
        # Recursive: start with S, add one observation each time
        for end_idx in range(S, T + 1):
            subsamples.append((0, end_idx))
            
    elif method == 'rolling':
        # Rolling: fixed window of size S, move forward
        for start_idx in range(T - S + 1):
            subsamples.append((start_idx, start_idx + S))
    else:
        raise ValueError(f"Unknown subsample method: {method}")
    
    return subsamples


def compute_test_ratio(
    test_statistic: float,
    critical_value: float
) -> float:
    """
    Compute ratio of test statistic to critical value.
    
    Parameters
    ----------
    test_statistic : float
        Computed test statistic.
    critical_value : float
        Bootstrap critical value.
        
    Returns
    -------
    float
        Ratio of test statistic to critical value.
        If ratio > 1, null hypothesis is rejected.
    """
    if critical_value == 0:
        return np.inf if test_statistic > 0 else 0
    
    return test_statistic / critical_value


def compute_minimum_subsample_size(T: int) -> int:
    """
    Compute minimum subsample size using Phillips et al. (2015) formula.
    
    Parameters
    ----------
    T : int
        Full sample size.
        
    Returns
    -------
    int
        Minimum subsample size.
    """
    S = int(np.ceil(T * (0.01 + 1.8 / np.sqrt(T))))
    return max(S, 10)  # Ensure at least 10 observations


def plot_dynamic_causality(
    results: dict,
    significance_level: float = 0.05,
    title: Optional[str] = None,
    save_path: Optional[str] = None,
    figsize: Tuple[int, int] = (12, 6)
):
    """
    Plot dynamic causality test results.
    
    Parameters
    ----------
    results : dict
        Results dictionary from dynamic_*_causality_test functions.
    significance_level : float, default=0.05
        Significance level to plot.
    title : str, optional
        Plot title.
    save_path : str, optional
        Path to save the figure. If None, displays instead.
    figsize : tuple, default=(12, 6)
        Figure size (width, height).
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError("matplotlib is required for plotting. Install with: pip install matplotlib")
    
    test_ratios = results['test_ratios'][significance_level]
    subsample_sizes = results['subsample_sizes']
    
    # Create figure
    fig, ax = plt.subplots(figsize=figsize)
    
    # Plot test ratio
    ax.plot(range(len(test_ratios)), test_ratios, 'b-', linewidth=2, label='Test Ratio (TVpCV)')
    
    # Plot threshold line at 1
    ax.axhline(y=1, color='r', linestyle='--', linewidth=2, label='Threshold (Reject if TVpCV > 1)')
    
    # Shading for rejection region
    ax.fill_between(range(len(test_ratios)), 1, ax.get_ylim()[1], 
                     alpha=0.2, color='red', label='Rejection Region')
    
    # Labels and title
    ax.set_xlabel('Subsample Index', fontsize=12)
    ax.set_ylabel('Test Value per Critical Value (TVpCV)', fontsize=12)
    
    if title is None:
        component = results.get('component', 'symmetric')
        method = results.get('method', 'recursive')
        title = f'Dynamic Causality Test ({component.capitalize()}, {method.capitalize()}, α={significance_level})'
    
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)
    
    # Add subsample size as secondary x-axis
    ax2 = ax.twiny()
    ax2.set_xlim(ax.get_xlim())
    tick_positions = np.linspace(0, len(test_ratios) - 1, min(10, len(test_ratios)))
    tick_labels = [str(subsample_sizes[int(pos)]) for pos in tick_positions]
    ax2.set_xticks(tick_positions)
    ax2.set_xticklabels(tick_labels)
    ax2.set_xlabel('Subsample Size', fontsize=12)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Figure saved to {save_path}")
    else:
        plt.show()
    
    plt.close()


def plot_information_criteria(
    criteria_results: dict,
    title: str = "Information Criteria Comparison",
    save_path: Optional[str] = None,
    figsize: Tuple[int, int] = (10, 6)
):
    """
    Plot comparison of information criteria across lag orders.
    
    Parameters
    ----------
    criteria_results : dict
        Results from compare_criteria function.
    title : str
        Plot title.
    save_path : str, optional
        Path to save figure.
    figsize : tuple
        Figure size.
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError("matplotlib is required for plotting")
    
    fig, ax = plt.subplots(figsize=figsize)
    
    criteria_values = criteria_results['criteria_values']
    optimal_lags = criteria_results['optimal_lags']
    
    colors = ['b', 'g', 'r', 'c', 'm']
    markers = ['o', 's', '^', 'd', 'v']
    
    for i, (name, color, marker) in enumerate(zip(
        ['aic', 'aicc', 'sbc', 'hqc', 'hjc'], colors, markers
    )):
        lags = criteria_values[name]['lags']
        values = criteria_values[name]['values']
        
        ax.plot(lags, values, color=color, marker=marker, 
                label=f'{name.upper()} (optimal: {optimal_lags[name]})',
                linewidth=2, markersize=6)
        
        # Mark optimal lag
        opt_lag = optimal_lags[name]
        opt_idx = lags.index(opt_lag)
        ax.scatter([opt_lag], [values[opt_idx]], 
                  color=color, s=200, marker='*', 
                  edgecolors='black', linewidths=2, zorder=10)
    
    ax.set_xlabel('Lag Order', fontsize=12)
    ax.set_ylabel('Criterion Value', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Figure saved to {save_path}")
    else:
        plt.show()
    
    plt.close()


def format_test_results(
    results: dict,
    decimals: int = 4
) -> str:
    """
    Format test results as a readable string.
    
    Parameters
    ----------
    results : dict
        Results dictionary from causality test.
    decimals : int, default=4
        Number of decimal places.
        
    Returns
    -------
    str
        Formatted results string.
    """
    output = []
    output.append("=" * 60)
    output.append("CAUSALITY TEST RESULTS")
    output.append("=" * 60)
    
    if 'component' in results:
        output.append(f"Component: {results['component']}")
    
    output.append(f"Test Statistic: {results['test_statistic']:.{decimals}f}")
    output.append(f"Optimal Lag: {results['optimal_lag']}")
    
    if 'p_value' in results:
        output.append(f"P-value: {results['p_value']:.{decimals}f}")
    
    output.append("\nCritical Values:")
    for alpha, cv in results['critical_values'].items():
        reject = "Yes" if results['reject_null'][alpha] else "No"
        output.append(f"  α = {alpha}: {cv:.{decimals}f} (Reject H0: {reject})")
    
    output.append("=" * 60)
    
    return "\n".join(output)


def export_results_to_csv(
    results: dict,
    filename: str,
    significance_level: float = 0.05
):
    """
    Export dynamic test results to CSV file.
    
    Parameters
    ----------
    results : dict
        Results from dynamic causality test.
    filename : str
        Output CSV filename.
    significance_level : float
        Significance level to export.
    """
    try:
        import pandas as pd
    except ImportError:
        raise ImportError("pandas is required for CSV export. Install with: pip install pandas")
    
    # Prepare data
    test_ratios = results['test_ratios'][significance_level]
    subsample_sizes = results['subsample_sizes']
    subsample_indices = results['subsample_indices']
    
    data = {
        'Subsample_Index': range(len(test_ratios)),
        'Start_Index': [idx[0] for idx in subsample_indices],
        'End_Index': [idx[1] for idx in subsample_indices],
        'Subsample_Size': subsample_sizes,
        'Test_Ratio': test_ratios,
        'Reject_Null': test_ratios > 1
    }
    
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    print(f"Results exported to {filename}")


def create_summary_table(
    results: dict,
    significance_levels: List[float] = [0.05, 0.10]
) -> str:
    """
    Create a summary table of dynamic test results.
    
    Parameters
    ----------
    results : dict
        Results from dynamic causality test.
    significance_levels : list
        Significance levels to include.
        
    Returns
    -------
    str
        Formatted summary table.
    """
    lines = []
    lines.append("\n" + "=" * 80)
    lines.append("DYNAMIC CAUSALITY TEST SUMMARY")
    lines.append("=" * 80)
    
    for alpha in significance_levels:
        test_ratios = results['test_ratios'][alpha]
        num_rejections = np.sum(test_ratios > 1)
        num_subsamples = len(test_ratios)
        rejection_rate = num_rejections / num_subsamples * 100
        
        lines.append(f"\nSignificance Level: {alpha}")
        lines.append(f"  Number of Subsamples: {num_subsamples}")
        lines.append(f"  Number of Rejections: {num_rejections}")
        lines.append(f"  Rejection Rate: {rejection_rate:.2f}%")
        
        if num_rejections > 0:
            rejection_indices = np.where(test_ratios > 1)[0]
            lines.append(f"  Rejection at subsamples: {list(rejection_indices)}")
    
    lines.append("=" * 80)
    
    return "\n".join(lines)
