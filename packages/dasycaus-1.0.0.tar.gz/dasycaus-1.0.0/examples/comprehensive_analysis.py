"""
Example: Loading and analyzing real data with DASYCAUS.

This script demonstrates how to load data from files and conduct
comprehensive causality analysis.
"""

import numpy as np
from dasycaus import (
    dynamic_asymmetric_causality_test,
    dynamic_symmetric_causality_test
)
from dasycaus.utils import (
    plot_dynamic_causality,
    create_summary_table,
    export_results_to_csv
)


def load_data_from_file(filename, delimiter=None, skiprows=0):
    """
    Load data from text file.
    
    Parameters
    ----------
    filename : str
        Path to data file.
    delimiter : str, optional
        Delimiter for columns (default: whitespace).
    skiprows : int, default=0
        Number of rows to skip at the beginning.
        
    Returns
    -------
    np.ndarray
        Data matrix (T x n).
    """
    try:
        data = np.loadtxt(filename, delimiter=delimiter, skiprows=skiprows)
        print(f"Data loaded successfully from {filename}")
        print(f"Shape: {data.shape} (T={data.shape[0]}, n={data.shape[1]})")
        return data
    except Exception as e:
        print(f"Error loading data: {e}")
        return None


def analyze_causality_comprehensive(data, var_names=None, maxlags=8, bootstrap_sims=1000):
    """
    Comprehensive causality analysis of data.
    
    Parameters
    ----------
    data : np.ndarray
        Data matrix (T x 2).
    var_names : list, optional
        Names of variables [var1, var2].
    maxlags : int, default=8
        Maximum lag order.
    bootstrap_sims : int, default=1000
        Number of bootstrap simulations.
    """
    if var_names is None:
        var_names = ['Variable 1', 'Variable 2']
    
    print("\n" + "=" * 80)
    print(f"COMPREHENSIVE CAUSALITY ANALYSIS")
    print(f"{var_names[0]} → {var_names[1]}")
    print("=" * 80)
    
    # 1. Dynamic Symmetric Test
    print("\n[1/4] Running Dynamic Symmetric Causality Test...")
    results_sym = dynamic_symmetric_causality_test(
        data=data,
        maxlags=maxlags,
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=bootstrap_sims,
        subsample_method='recursive',
        random_seed=42
    )
    
    print(create_summary_table(results_sym))
    
    # Save results
    export_results_to_csv(results_sym, 'symmetric_results.csv', significance_level=0.05)
    plot_dynamic_causality(
        results_sym,
        significance_level=0.05,
        title=f"Dynamic Symmetric: {var_names[1]} ← {var_names[0]}",
        save_path='symmetric_causality.png'
    )
    
    # 2. Dynamic Asymmetric Test - Positive
    print("\n[2/4] Running Dynamic Asymmetric Causality Test (Positive)...")
    results_pos = dynamic_asymmetric_causality_test(
        data=data,
        maxlags=maxlags,
        component='positive',
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=bootstrap_sims,
        subsample_method='recursive',
        random_seed=42
    )
    
    print(create_summary_table(results_pos))
    
    export_results_to_csv(results_pos, 'asymmetric_positive_results.csv', significance_level=0.05)
    plot_dynamic_causality(
        results_pos,
        significance_level=0.10,
        title=f"Dynamic Asymmetric (Positive): {var_names[1]}⁺ ← {var_names[0]}⁺",
        save_path='asymmetric_positive.png'
    )
    
    # 3. Dynamic Asymmetric Test - Negative
    print("\n[3/4] Running Dynamic Asymmetric Causality Test (Negative)...")
    results_neg = dynamic_asymmetric_causality_test(
        data=data,
        maxlags=maxlags,
        component='negative',
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=bootstrap_sims,
        subsample_method='recursive',
        random_seed=42
    )
    
    print(create_summary_table(results_neg))
    
    export_results_to_csv(results_neg, 'asymmetric_negative_results.csv', significance_level=0.05)
    plot_dynamic_causality(
        results_neg,
        significance_level=0.10,
        title=f"Dynamic Asymmetric (Negative): {var_names[1]}⁻ ← {var_names[0]}⁻",
        save_path='asymmetric_negative.png'
    )
    
    # 4. Summary Comparison
    print("\n[4/4] Generating Summary Comparison...")
    generate_comparison_summary(results_sym, results_pos, results_neg, var_names)
    
    print("\n" + "=" * 80)
    print("Analysis Complete!")
    print("=" * 80)
    print("\nGenerated files:")
    print("  - symmetric_results.csv")
    print("  - asymmetric_positive_results.csv")
    print("  - asymmetric_negative_results.csv")
    print("  - symmetric_causality.png")
    print("  - asymmetric_positive.png")
    print("  - asymmetric_negative.png")


def generate_comparison_summary(results_sym, results_pos, results_neg, var_names):
    """Generate comparison summary of all tests."""
    print("\n" + "=" * 80)
    print("COMPARISON SUMMARY")
    print("=" * 80)
    
    for alpha in [0.05, 0.10]:
        print(f"\nAt α = {alpha}:")
        
        # Symmetric
        sym_rejections = np.sum(results_sym['test_ratios'][alpha] > 1)
        sym_rate = sym_rejections / len(results_sym['test_ratios'][alpha]) * 100
        
        # Positive
        pos_rejections = np.sum(results_pos['test_ratios'][alpha] > 1)
        pos_rate = pos_rejections / len(results_pos['test_ratios'][alpha]) * 100
        
        # Negative
        neg_rejections = np.sum(results_neg['test_ratios'][alpha] > 1)
        neg_rate = neg_rejections / len(results_neg['test_ratios'][alpha]) * 100
        
        print(f"  Symmetric:           {sym_rejections:2d} rejections ({sym_rate:5.1f}%)")
        print(f"  Asymmetric Positive: {pos_rejections:2d} rejections ({pos_rate:5.1f}%)")
        print(f"  Asymmetric Negative: {neg_rejections:2d} rejections ({neg_rate:5.1f}%)")
        
        if pos_rate > sym_rate:
            print(f"  → Stronger positive asymmetric effect detected")
        elif neg_rate > sym_rate:
            print(f"  → Stronger negative asymmetric effect detected")
        elif sym_rate > max(pos_rate, neg_rate):
            print(f"  → Symmetric effect dominates")
        else:
            print(f"  → No clear asymmetric pattern")


def example_with_sample_data():
    """Run example with generated sample data."""
    print("\nExample with generated data:")
    print("-" * 80)
    
    # Generate sample data with known relationships
    np.random.seed(2024)
    T = 100
    
    # Create oil price proxy with volatility
    oil_returns = np.random.normal(0.05, 0.3, T)
    ln_oil = np.cumsum(oil_returns)
    
    # Create stock market with asymmetric response
    # Positive oil shocks have stronger effect
    oil_pos = np.maximum(oil_returns, 0)
    oil_neg = np.minimum(oil_returns, 0)
    
    stock_returns = np.random.normal(0.08, 0.2, T) + 0.5 * oil_pos + 0.1 * oil_neg
    ln_stock = np.cumsum(stock_returns)
    
    data = np.column_stack([ln_stock, ln_oil])
    
    # Analyze
    analyze_causality_comprehensive(
        data,
        var_names=['Stock Market', 'Oil Price'],
        maxlags=6,
        bootstrap_sims=500  # Reduced for speed in example
    )


def example_with_your_data():
    """
    Template for analyzing your own data.
    
    Modify this function to load and analyze your data.
    """
    print("\nExample with your data:")
    print("-" * 80)
    
    # STEP 1: Load your data
    # Replace 'your_data.txt' with your actual filename
    # Data should be (T x 2) matrix: [variable1, variable2]
    
    filename = 'your_data.txt'
    
    # Try loading with different formats:
    # Option 1: Space-delimited
    data = load_data_from_file(filename)
    
    # Option 2: Comma-delimited (CSV)
    # data = load_data_from_file(filename, delimiter=',')
    
    # Option 3: Tab-delimited
    # data = load_data_from_file(filename, delimiter='\t')
    
    # Option 4: Skip header rows
    # data = load_data_from_file(filename, skiprows=1)
    
    if data is None:
        print("Could not load data. Using sample data instead.")
        example_with_sample_data()
        return
    
    # STEP 2: Check data shape
    if data.ndim != 2 or data.shape[1] != 2:
        print(f"Warning: Expected (T x 2) data, got {data.shape}")
        print("Using first two columns...")
        data = data[:, :2]
    
    # STEP 3: Analyze
    var_names = ['Variable X', 'Variable Y']  # Modify these names
    
    analyze_causality_comprehensive(
        data,
        var_names=var_names,
        maxlags=8,
        bootstrap_sims=1000
    )


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("DASYCAUS: Comprehensive Data Analysis Example")
    print("=" * 80)
    
    # Run example with generated data
    example_with_sample_data()
    
    # Uncomment to analyze your own data:
    # example_with_your_data()
