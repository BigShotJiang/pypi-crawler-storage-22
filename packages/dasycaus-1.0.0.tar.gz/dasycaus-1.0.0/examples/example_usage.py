"""
Example script demonstrating the usage of dasycaus library.

This example replicates the application in Hatemi-J (2021) paper
analyzing the causal relationship between oil prices and US stock market.
"""

import numpy as np
from dasycaus import (
    dynamic_asymmetric_causality_test,
    dynamic_symmetric_causality_test,
    asymmetric_causality_test,
    symmetric_causality_test
)
from dasycaus.utils import (
    plot_dynamic_causality,
    format_test_results,
    create_summary_table
)


def example_1_static_symmetric():
    """Example 1: Static symmetric causality test."""
    print("\n" + "=" * 70)
    print("EXAMPLE 1: Static Symmetric Causality Test")
    print("=" * 70)
    
    # Generate example data (replace with real data)
    np.random.seed(42)
    T = 100
    
    # Simulate two I(1) variables
    e1 = np.random.normal(0, 1, T)
    e2 = np.random.normal(0, 1, T)
    
    x1 = np.cumsum(e1)
    x2 = np.cumsum(e2 + 0.3 * e1)  # x2 is caused by x1
    
    data = np.column_stack([x1, x2])
    
    # Conduct test
    results = symmetric_causality_test(
        data=data,
        maxlags=8,
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=1000,
        significance_levels=[0.05, 0.10]
    )
    
    print(format_test_results(results))


def example_2_static_asymmetric():
    """Example 2: Static asymmetric causality test."""
    print("\n" + "=" * 70)
    print("EXAMPLE 2: Static Asymmetric Causality Test (Positive Components)")
    print("=" * 70)
    
    # Generate example data
    np.random.seed(42)
    T = 100
    
    # Simulate data with asymmetric effects
    e1 = np.random.normal(0, 1, T)
    e2 = np.random.normal(0, 1, T)
    
    # Positive shocks have stronger effect
    e1_pos = np.maximum(e1, 0)
    e1_neg = np.minimum(e1, 0)
    
    x1 = np.cumsum(e1)
    x2 = np.cumsum(e2 + 0.5 * e1_pos + 0.1 * e1_neg)
    
    data = np.column_stack([x1, x2])
    
    # Test positive components
    results_pos = asymmetric_causality_test(
        data=data,
        maxlags=8,
        component='positive',
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=1000
    )
    
    print("\n--- Positive Components ---")
    print(format_test_results(results_pos))
    
    # Test negative components
    results_neg = asymmetric_causality_test(
        data=data,
        maxlags=8,
        component='negative',
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=1000
    )
    
    print("\n--- Negative Components ---")
    print(format_test_results(results_neg))


def example_3_dynamic_symmetric():
    """Example 3: Dynamic symmetric causality test."""
    print("\n" + "=" * 70)
    print("EXAMPLE 3: Dynamic Symmetric Causality Test")
    print("=" * 70)
    
    # Generate example data
    np.random.seed(42)
    T = 50
    
    # Create structural break in middle
    e1 = np.random.normal(0, 1, T)
    e2_1 = np.random.normal(0, 1, T // 2)
    e2_2 = np.random.normal(0, 1, T - T // 2) + 0.5 * e1[T // 2:]
    
    e2 = np.concatenate([e2_1, e2_2])
    
    x1 = np.cumsum(e1)
    x2 = np.cumsum(e2)
    
    data = np.column_stack([x1, x2])
    
    # Conduct dynamic test with recursive method
    results = dynamic_symmetric_causality_test(
        data=data,
        maxlags=4,
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=500,
        subsample_method='recursive'
    )
    
    print(create_summary_table(results))
    
    # Plot results
    try:
        plot_dynamic_causality(
            results,
            significance_level=0.05,
            title="Dynamic Symmetric Causality Test (Recursive)",
            save_path="dynamic_symmetric_example.png"
        )
    except ImportError:
        print("\nNote: Install matplotlib to generate plots")


def example_4_dynamic_asymmetric():
    """Example 4: Dynamic asymmetric causality test."""
    print("\n" + "=" * 70)
    print("EXAMPLE 4: Dynamic Asymmetric Causality Test (Positive Components)")
    print("=" * 70)
    
    # Generate example data
    np.random.seed(42)
    T = 50
    
    # Create time-varying asymmetric relationship
    e1 = np.random.normal(0, 1, T)
    e2 = np.random.normal(0, 1, T)
    
    e1_pos = np.maximum(e1, 0)
    
    # Relationship strengthens over time
    weights = np.linspace(0.1, 0.8, T)
    e2_adj = e2 + weights * e1_pos
    
    x1 = np.cumsum(e1)
    x2 = np.cumsum(e2_adj)
    
    data = np.column_stack([x1, x2])
    
    # Conduct dynamic asymmetric test
    results = dynamic_asymmetric_causality_test(
        data=data,
        maxlags=4,
        component='positive',
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=500,
        subsample_method='recursive'
    )
    
    print(create_summary_table(results))
    
    # Plot results
    try:
        plot_dynamic_causality(
            results,
            significance_level=0.10,
            title="Dynamic Asymmetric Causality Test (Positive, Recursive)",
            save_path="dynamic_asymmetric_positive_example.png"
        )
    except ImportError:
        print("\nNote: Install matplotlib to generate plots")


def example_5_oil_stock_replication():
    """
    Example 5: Replication of oil-stock market analysis from Hatemi-J (2021).
    
    Note: This requires the actual data from the paper.
    Replace the data loading section with your actual data.
    """
    print("\n" + "=" * 70)
    print("EXAMPLE 5: Oil Price and Stock Market Analysis")
    print("(Replication of Hatemi-J 2021 Application)")
    print("=" * 70)
    
    # TODO: Load actual data
    # data = np.loadtxt('oil_stock_data.txt')
    # lnS = data[:, 0]  # Log of stock price index
    # lnO = data[:, 1]  # Log of oil price index
    
    # For demonstration, generate synthetic data
    np.random.seed(2021)
    T = 31  # 1990-2020
    
    lnO = np.cumsum(np.random.normal(0.05, 0.2, T))
    lnS = np.cumsum(np.random.normal(0.08, 0.15, T) + 0.3 * np.diff(lnO, prepend=lnO[0]))
    
    data = np.column_stack([lnS, lnO])
    
    print("\nData shape:", data.shape)
    print("Sample period: 1990-2020 (31 observations)")
    
    # 1. Dynamic Symmetric Test
    print("\n--- Dynamic Symmetric Causality Test ---")
    results_sym = dynamic_symmetric_causality_test(
        data=data,
        maxlags=4,
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=1000,
        subsample_method='recursive'
    )
    print(create_summary_table(results_sym, significance_levels=[0.05, 0.10]))
    
    # 2. Dynamic Asymmetric Test - Positive Components
    print("\n--- Dynamic Asymmetric Causality Test (Positive) ---")
    results_pos = dynamic_asymmetric_causality_test(
        data=data,
        maxlags=4,
        component='positive',
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=1000,
        subsample_method='recursive'
    )
    print(create_summary_table(results_pos, significance_levels=[0.05, 0.10]))
    
    # 3. Dynamic Asymmetric Test - Negative Components
    print("\n--- Dynamic Asymmetric Causality Test (Negative) ---")
    results_neg = dynamic_asymmetric_causality_test(
        data=data,
        maxlags=4,
        component='negative',
        integration_order=1,
        info_criterion='hjc',
        bootstrap_sims=1000,
        subsample_method='recursive'
    )
    print(create_summary_table(results_neg, significance_levels=[0.05, 0.10]))
    
    # Generate plots
    try:
        plot_dynamic_causality(
            results_pos,
            significance_level=0.10,
            title="H0: Oil Price Increase Does Not Cause Stock Market Increase",
            save_path="oil_stock_positive.png"
        )
        print("\nPlot saved: oil_stock_positive.png")
    except ImportError:
        print("\nNote: Install matplotlib to generate plots")


if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("DASYCAUS: Dynamic Asymmetric Causality Tests - Examples")
    print("=" * 70)
    
    # Run examples
    example_1_static_symmetric()
    example_2_static_asymmetric()
    example_3_dynamic_symmetric()
    example_4_dynamic_asymmetric()
    example_5_oil_stock_replication()
    
    print("\n" + "=" * 70)
    print("All examples completed!")
    print("=" * 70)
