"""
Setup script for dasycaus package.

This file exists for backward compatibility.
The package is configured using pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
