"""Test suite for dasycaus package."""
