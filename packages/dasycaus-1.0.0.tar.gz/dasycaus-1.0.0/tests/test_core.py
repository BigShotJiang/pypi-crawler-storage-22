"""
Test suite for core causality test functions.
"""

import numpy as np
import pytest
from dasycaus.core import (
    symmetric_causality_test,
    asymmetric_causality_test,
    dynamic_symmetric_causality_test,
    dynamic_asymmetric_causality_test,
    _compute_wald_statistic,
    _create_var_matrices
)


class TestSymmetricCausalityTest:
    """Tests for symmetric causality test."""
    
    def test_basic_functionality(self):
        """Test basic functionality with simple data."""
        np.random.seed(42)
        T = 100
        
        # Generate I(1) data
        e1 = np.random.normal(0, 1, T)
        e2 = np.random.normal(0, 1, T)
        
        x1 = np.cumsum(e1)
        x2 = np.cumsum(e2)
        
        data = np.column_stack([x1, x2])
        
        results = symmetric_causality_test(
            data=data,
            maxlags=4,
            integration_order=1,
            bootstrap_sims=100,
            random_seed=42
        )
        
        assert 'test_statistic' in results
        assert 'optimal_lag' in results
        assert 'critical_values' in results
        assert isinstance(results['test_statistic'], float)
        assert results['test_statistic'] >= 0
    
    def test_causality_detection(self):
        """Test if causality is detected when it exists."""
        np.random.seed(42)
        T = 100
        
        # Generate data with causality
        e1 = np.random.normal(0, 1, T)
        e2 = np.random.normal(0, 1, T) + 0.5 * e1
        
        x1 = np.cumsum(e1)
        x2 = np.cumsum(e2)
        
        data = np.column_stack([x1, x2])
        
        results = symmetric_causality_test(
            data=data,
            maxlags=4,
            integration_order=1,
            bootstrap_sims=100,
            random_seed=42
        )
        
        # With strong causality, we expect rejection at some level
        assert results['test_statistic'] > 0
    
    def test_different_info_criteria(self):
        """Test with different information criteria."""
        np.random.seed(42)
        T = 100
        x1 = np.cumsum(np.random.normal(0, 1, T))
        x2 = np.cumsum(np.random.normal(0, 1, T))
        data = np.column_stack([x1, x2])
        
        for criterion in ['aic', 'aicc', 'sbc', 'hqc', 'hjc']:
            results = symmetric_causality_test(
                data=data,
                maxlags=4,
                info_criterion=criterion,
                bootstrap_sims=50,
                random_seed=42
            )
            assert results['optimal_lag'] > 0


class TestAsymmetricCausalityTest:
    """Tests for asymmetric causality test."""
    
    def test_positive_components(self):
        """Test with positive components."""
        np.random.seed(42)
        T = 100
        
        e1 = np.random.normal(0, 1, T)
        e2 = np.random.normal(0, 1, T)
        
        x1 = np.cumsum(e1)
        x2 = np.cumsum(e2)
        
        data = np.column_stack([x1, x2])
        
        results = asymmetric_causality_test(
            data=data,
            maxlags=4,
            component='positive',
            bootstrap_sims=100,
            random_seed=42
        )
        
        assert results['component'] == 'positive'
        assert 'test_statistic' in results
    
    def test_negative_components(self):
        """Test with negative components."""
        np.random.seed(42)
        T = 100
        
        e1 = np.random.normal(0, 1, T)
        e2 = np.random.normal(0, 1, T)
        
        x1 = np.cumsum(e1)
        x2 = np.cumsum(e2)
        
        data = np.column_stack([x1, x2])
        
        results = asymmetric_causality_test(
            data=data,
            maxlags=4,
            component='negative',
            bootstrap_sims=100,
            random_seed=42
        )
        
        assert results['component'] == 'negative'
        assert 'test_statistic' in results
    
    def test_asymmetric_effects(self):
        """Test detection of asymmetric effects."""
        np.random.seed(42)
        T = 100
        
        # Create asymmetric relationship
        e1 = np.random.normal(0, 1, T)
        e1_pos = np.maximum(e1, 0)
        e1_neg = np.minimum(e1, 0)
        
        e2 = np.random.normal(0, 1, T) + 0.7 * e1_pos + 0.1 * e1_neg
        
        x1 = np.cumsum(e1)
        x2 = np.cumsum(e2)
        
        data = np.column_stack([x1, x2])
        
        results_pos = asymmetric_causality_test(
            data=data,
            maxlags=4,
            component='positive',
            bootstrap_sims=100,
            random_seed=42
        )
        
        results_neg = asymmetric_causality_test(
            data=data,
            maxlags=4,
            component='negative',
            bootstrap_sims=100,
            random_seed=42
        )
        
        # Positive should have stronger effect
        assert results_pos['test_statistic'] >= 0
        assert results_neg['test_statistic'] >= 0


class TestDynamicCausalityTest:
    """Tests for dynamic causality tests."""
    
    def test_dynamic_symmetric_recursive(self):
        """Test dynamic symmetric test with recursive method."""
        np.random.seed(42)
        T = 50
        
        e1 = np.random.normal(0, 1, T)
        e2 = np.random.normal(0, 1, T)
        
        x1 = np.cumsum(e1)
        x2 = np.cumsum(e2)
        
        data = np.column_stack([x1, x2])
        
        results = dynamic_symmetric_causality_test(
            data=data,
            maxlags=3,
            bootstrap_sims=50,
            subsample_method='recursive',
            random_seed=42
        )
        
        assert 'subsamples' in results
        assert 'test_ratios' in results
        assert len(results['subsamples']) > 0
    
    def test_dynamic_symmetric_rolling(self):
        """Test dynamic symmetric test with rolling method."""
        np.random.seed(42)
        T = 50
        
        e1 = np.random.normal(0, 1, T)
        e2 = np.random.normal(0, 1, T)
        
        x1 = np.cumsum(e1)
        x2 = np.cumsum(e2)
        
        data = np.column_stack([x1, x2])
        
        results = dynamic_symmetric_causality_test(
            data=data,
            maxlags=3,
            bootstrap_sims=50,
            subsample_method='rolling',
            random_seed=42
        )
        
        assert 'subsamples' in results
        assert results['method'] == 'rolling'
    
    def test_dynamic_asymmetric(self):
        """Test dynamic asymmetric test."""
        np.random.seed(42)
        T = 50
        
        e1 = np.random.normal(0, 1, T)
        e2 = np.random.normal(0, 1, T)
        
        x1 = np.cumsum(e1)
        x2 = np.cumsum(e2)
        
        data = np.column_stack([x1, x2])
        
        results = dynamic_asymmetric_causality_test(
            data=data,
            maxlags=3,
            component='positive',
            bootstrap_sims=50,
            subsample_method='recursive',
            random_seed=42
        )
        
        assert 'component' in results
        assert results['component'] == 'positive'
        assert 'test_ratios' in results


class TestHelperFunctions:
    """Tests for helper functions."""
    
    def test_create_var_matrices(self):
        """Test VAR matrix creation."""
        np.random.seed(42)
        data = np.random.normal(0, 1, (100, 2))
        
        Y, X = _create_var_matrices(data, lags=3)
        
        assert Y.shape[0] == 97
        assert Y.shape[1] == 2
        assert X.shape[0] == 97
        assert X.shape[1] == 7  # 1 intercept + 3 lags * 2 variables
    
    def test_compute_wald_statistic(self):
        """Test Wald statistic computation."""
        np.random.seed(42)
        T = 100
        
        e1 = np.random.normal(0, 1, T)
        e2 = np.random.normal(0, 1, T)
        
        x1 = np.cumsum(e1)
        x2 = np.cumsum(e2)
        
        data = np.column_stack([x1, x2])
        
        wald_stat = _compute_wald_statistic(data, lag_order=3, integration_order=1)
        
        assert isinstance(wald_stat, float)
        assert wald_stat >= 0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
