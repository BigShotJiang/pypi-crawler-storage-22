"""
Test suite for data transformation functions.
"""

import numpy as np
import pytest
from dasycaus.data_transform import (
    transform_to_cumulative_components,
    compute_positive_negative_shocks,
    verify_transformation,
    transform_differences_to_components
)


class TestDataTransformation:
    """Tests for data transformation functions."""
    
    def test_transform_positive_components(self):
        """Test transformation to positive components."""
        np.random.seed(42)
        T = 100
        
        # Generate I(1) data
        e = np.random.normal(0, 1, T)
        x = np.cumsum(e)
        data = x.reshape(-1, 1)
        
        positive = transform_to_cumulative_components(
            data,
            component='positive',
            include_trend=True
        )
        
        assert positive.shape == data.shape
        assert np.all(np.isfinite(positive))
    
    def test_transform_negative_components(self):
        """Test transformation to negative components."""
        np.random.seed(42)
        T = 100
        
        e = np.random.normal(0, 1, T)
        x = np.cumsum(e)
        data = x.reshape(-1, 1)
        
        negative = transform_to_cumulative_components(
            data,
            component='negative',
            include_trend=True
        )
        
        assert negative.shape == data.shape
        assert np.all(np.isfinite(negative))
    
    def test_transformation_consistency(self):
        """Test that x_t = x_t^+ + x_t^-."""
        np.random.seed(42)
        T = 100
        
        e = np.random.normal(0, 1, T)
        x = np.cumsum(e)
        data = x.reshape(-1, 1)
        
        positive = transform_to_cumulative_components(
            data,
            component='positive',
            include_trend=True
        )
        
        negative = transform_to_cumulative_components(
            data,
            component='negative',
            include_trend=True
        )
        
        # Check if transformation is valid
        is_valid = verify_transformation(data, positive, negative, tolerance=1e-8)
        assert is_valid, "Transformation should satisfy x_t = x_t^+ + x_t^-"
    
    def test_multivariate_transformation(self):
        """Test transformation with multiple variables."""
        np.random.seed(42)
        T = 100
        n = 3
        
        data = np.random.normal(0, 1, (T, n))
        data = np.cumsum(data, axis=0)
        
        positive = transform_to_cumulative_components(
            data,
            component='positive'
        )
        
        negative = transform_to_cumulative_components(
            data,
            component='negative'
        )
        
        assert positive.shape == data.shape
        assert negative.shape == data.shape
        
        # Verify for each variable
        is_valid = verify_transformation(data, positive, negative)
        assert is_valid
    
    def test_without_trend(self):
        """Test transformation without deterministic trend."""
        np.random.seed(42)
        T = 100
        
        e = np.random.normal(0, 1, T)
        x = np.cumsum(e)
        data = x.reshape(-1, 1)
        
        positive = transform_to_cumulative_components(
            data,
            component='positive',
            include_trend=False
        )
        
        assert positive.shape == data.shape
        assert np.all(np.isfinite(positive))


class TestShockComputation:
    """Tests for shock computation functions."""
    
    def test_compute_shocks(self):
        """Test positive and negative shock computation."""
        np.random.seed(42)
        T = 100
        
        e = np.random.normal(0, 1, T)
        x = np.cumsum(e)
        data = x.reshape(-1, 1)
        
        pos_shocks, neg_shocks = compute_positive_negative_shocks(data)
        
        assert pos_shocks.shape == (T - 1, 1)
        assert neg_shocks.shape == (T - 1, 1)
        assert np.all(pos_shocks >= 0)
        assert np.all(neg_shocks <= 0)
    
    def test_shocks_sum_to_total(self):
        """Test that positive + negative shocks = total shocks."""
        np.random.seed(42)
        T = 100
        
        e = np.random.normal(0, 1, T)
        x = np.cumsum(e)
        data = x.reshape(-1, 1)
        
        pos_shocks, neg_shocks = compute_positive_negative_shocks(
            data,
            include_trend=False
        )
        
        # Total shocks (after removing mean)
        dx = np.diff(data, axis=0)
        total_shocks = dx - np.mean(dx, axis=0)
        
        reconstructed = pos_shocks + neg_shocks
        
        # Check if they match
        np.testing.assert_array_almost_equal(reconstructed, total_shocks, decimal=10)


class TestDifferenceTransformation:
    """Tests for difference-based transformation."""
    
    def test_transform_differences(self):
        """Test transformation of differenced data."""
        np.random.seed(42)
        T = 100
        
        # Create differenced data
        diff_data = np.random.normal(0, 1, (T, 2))
        
        cum_pos, cum_neg = transform_differences_to_components(diff_data)
        
        assert cum_pos.shape == diff_data.shape
        assert cum_neg.shape == diff_data.shape
        assert np.all(cum_pos >= 0)
        assert np.all(cum_neg <= 0)
    
    def test_cumulative_property(self):
        """Test cumulative sum property."""
        np.random.seed(42)
        T = 50
        
        diff_data = np.random.normal(0, 1, (T, 1))
        
        cum_pos, cum_neg = transform_differences_to_components(diff_data)
        
        # Check if positive cumulative sum is non-decreasing
        assert np.all(np.diff(cum_pos, axis=0) >= 0)
        
        # Check if negative cumulative sum is non-increasing
        assert np.all(np.diff(cum_neg, axis=0) <= 0)


class TestEdgeCases:
    """Tests for edge cases."""
    
    def test_all_positive_shocks(self):
        """Test with all positive shocks."""
        T = 50
        
        # Only positive shocks
        data = np.cumsum(np.abs(np.random.normal(0, 1, T))).reshape(-1, 1)
        
        positive = transform_to_cumulative_components(data, component='positive')
        negative = transform_to_cumulative_components(data, component='negative')
        
        assert np.all(np.isfinite(positive))
        assert np.all(np.isfinite(negative))
    
    def test_all_negative_shocks(self):
        """Test with all negative shocks."""
        T = 50
        
        # Only negative shocks
        data = np.cumsum(-np.abs(np.random.normal(0, 1, T))).reshape(-1, 1)
        
        positive = transform_to_cumulative_components(data, component='positive')
        negative = transform_to_cumulative_components(data, component='negative')
        
        assert np.all(np.isfinite(positive))
        assert np.all(np.isfinite(negative))
    
    def test_constant_data(self):
        """Test with constant data."""
        T = 50
        
        data = np.ones((T, 1)) * 5.0
        
        positive = transform_to_cumulative_components(data, component='positive')
        negative = transform_to_cumulative_components(data, component='negative')
        
        # With constant data, shocks should be minimal
        assert np.all(np.isfinite(positive))
        assert np.all(np.isfinite(negative))


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
