"""
Dataset for reading tokenized samples with auxiliary data.

This module provides TokensWithAuxDataset which reads samples containing
both tokens and auxiliary data (e.g., loss masks) using the schema stored
in the sample index.
"""

from typing import Dict, Optional

import numpy as np

from data_forager.sample_index import SampleIndex
from data_forager.datasets.common import Dataset


class TokensWithAuxDataset(Dataset):
    """
    Dataset that returns tokens with auxiliary data.

    Reads samples containing multiple arrays (tokens + auxiliary data) using
    the schema from the sample index to parse the concatenated bytes.

    Requires sample_schema in the SampleIndex. Use TokensDataset for indexes
    without auxiliary data.
    """

    @classmethod
    def create_from_index_on_filesystem(
        cls,
        base_path: str,
        name: Optional[str] = None,
    ) -> "TokensWithAuxDataset":
        """
        Create a TokensWithAuxDataset from an index stored on the filesystem.

        :param base_path: Base path where the index is stored.
        :param name: Optional name for logging.

        :return: TokensWithAuxDataset instance.
        """
        from data_forager.index_stores.fs_based import IndexStore

        index_store = IndexStore(base_path=base_path)
        sample_index = index_store.load()

        return cls(sample_index=sample_index, name=name)

    def __init__(
        self,
        sample_index: SampleIndex,
        name: Optional[str] = None,
        **kwargs,
    ):
        """
        Initialize the dataset.

        :param sample_index: SampleIndex with sample_schema describing the
            structure of samples.
        :param name: Optional name for logging.

        :raises ValueError: If sample_index has no sample_schema.
        """
        super().__init__(sample_index, name=name, **kwargs)

        if sample_index.sample_schema is None:
            raise ValueError(
                "SampleIndex has no sample_schema. "
                "Use TokensDataset for indexes without auxiliary data."
            )

        self._schema = sample_index.sample_schema

    def _process_sample(self, sample_bytes: bytes) -> Dict[str, np.ndarray]:
        """
        Parse concatenated bytes into named arrays.

        :param sample_bytes: Raw bytes containing all arrays concatenated.

        :return: Dict mapping array names to numpy arrays.
        """
        result = {}
        for array_spec in self._schema.arrays:
            dtype = np.dtype(array_spec.dtype)
            start = array_spec.offset
            length = self._schema.sample_size * dtype.itemsize
            result[array_spec.name] = np.frombuffer(
                sample_bytes[start:start + length],
                dtype=dtype,
            )
        return result
