"""
File text lines indexer for building sample indexes.

This module provides FileTextLinesIndexer which scans text files line by line,
uses a sample generator to transform lines into samples, and builds an index
for random access.
"""

from typing import Optional, List

import os
import sys

from basics.base import Base
from tqdm import tqdm

from data_forager.index_stores.common import IndexStoreInterface
from data_forager.sample_generators.common import (
    SampleGeneratorInterface,
    NOOPSampleGenerator,
)


class FileTextLinesIndexer(Base):
    """
    Indexes text files by scanning lines and building a sample index.

    Uses a sample generator to transform text lines into samples, then records
    byte offsets in an index store for O(1) random access during training.
    """

    def __init__(
        self,
        input_file_paths: List[str],
        index_store: IndexStoreInterface,
        sample_generator: Optional[SampleGeneratorInterface] = None,
        description: Optional[str] = None,
        name: Optional[str] = None
    ):
        super().__init__(pybase_logger_name=name)

        if sample_generator is None:
            sample_generator = NOOPSampleGenerator()

        if description is None:
            description = "Indexing"

        self._input_file_paths = input_file_paths
        self._index_store = index_store

        self._sample_generator = sample_generator
        self._description = description

    def __call__(self):
        """
        Run the indexing process.

        IMPORTANT: Input files are always read in binary mode; applying a text
        encoding is up to the user, e.g., through process_sample_func and/or
        when processing the data in Dataset._process_sample().
        """
        self._index_store.init_store()

        # Set schema if the sample generator provides one
        sample_schema = self._sample_generator.get_sample_schema()
        if sample_schema is not None:
            self._index_store.set_sample_schema(sample_schema)

        byte_offset_map = {}

        for input_file_path in self._input_file_paths:
            sys.stdout.write(
                f"{self._description}: \n"
                f"{input_file_path}\n"
            )
            sys.stdout.flush()

            self._sample_generator.prepare(input_file_path)

            with open(input_file_path, "rb") as f:
                file_size = os.fstat(f.fileno()).st_size
                pbar = tqdm(unit="bytes", total=file_size, file=sys.stdout)

                while text_line := f.readline():

                    num_text_line_bytes = len(text_line)

                    sample_data_list = self._sample_generator.create_samples(text_line)

                    for sample_data in sample_data_list:
                        file_location = sample_data.file_path
                        byte_offset = byte_offset_map.get(file_location, 0)
                        num_bytes = len(sample_data.sample_bytes)

                        self._index_store.add_sample(
                            file_location=file_location,
                            byte_offset=byte_offset,
                            num_bytes=num_bytes
                        )

                        byte_offset_map[file_location] = byte_offset + num_bytes

                    pbar.update(num_text_line_bytes)
                    sys.stdout.flush()

                pbar.close()

            is_last_file = input_file_path == self._input_file_paths[-1]
            self._sample_generator.finish(is_last_file=is_last_file)

            sys.stdout.write('\n\n')
            sys.stdout.flush()

        self._index_store.close()
