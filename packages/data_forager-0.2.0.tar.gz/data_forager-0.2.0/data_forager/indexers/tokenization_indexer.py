"""
Factory function for creating tokenization and indexing pipelines.

This module provides a convenience function for setting up the complete pipeline
to tokenize JSONL text files and create an index for random access.
"""

from typing import Callable, Dict, List, Optional

import json
import logging
import os

from basics.logging import get_logger

from data_forager.index_stores.common import IndexStoreInterface
from data_forager.index_stores.fs_based import IndexStore as FSBasedIndexStore
from data_forager.indexers.text_lines import FileTextLinesIndexer
from data_forager.sample_generators.tokenization import (
    TokenizedSampleGenerator,
    TokenizerFunc,
    ProcessTextLineFunc,
)
from data_forager.sample_generators.aux.common import Part, AuxDataGenerator
from data_forager.utils import find_files_recursive, natural_sort


ProcessPartsFunc = Callable[[bytes], List[Part]]


module_logger = get_logger(os.path.basename(__file__))


def get_text_from_jsonl(jsonl_bytes: bytes, text_key: str = "text", text_encoding: str = "utf-8") -> str:
    """
    Extract text from a JSONL line.

    :param jsonl_bytes: Raw bytes of the JSONL line.
    :param text_key: Key in the JSON object containing the text.
    :param text_encoding: Text encoding to use for decoding.

    :return: The extracted text string.
    """
    jsonl_text = jsonl_bytes.decode(text_encoding)
    data = json.loads(jsonl_text)
    return data[text_key]


def create_tokenize_and_index_jsonl_text_func(
    tokenizer_func: TokenizerFunc,
    eos_idx: int,
    input_base_path: Optional[str] = None,
    input_file_paths: Optional[List[str]] = None,
    output_base_path: Optional[str] = None,
    index_store: Optional[IndexStoreInterface] = None,
    process_text_line_func: Optional[ProcessTextLineFunc] = None,
    logger: Optional[logging.Logger] = None,
    name: Optional[str] = None,
    **sample_generator_kwargs,
) -> FileTextLinesIndexer:
    """
    Create a pipeline to tokenize text from JSONL files and create an index for random access.

    The pipeline:
    * Tokenizes text from input JSONL objects
    * Stores the token data in bin files under "tokenized-samples" folder
    * Stores index data under "index" folder

    Usage:
    ```python
    import tiktoken

    enc = tiktoken.get_encoding("gpt2")
    def tokenize_text(text: str) -> List[int]:
        return enc.encode_ordinary(text)

    # Option 1: Scan directory for JSONL files, output to same directory
    indexer = create_tokenize_and_index_jsonl_text_func(
        tokenizer_func=tokenize_text,
        eos_idx=enc.eot_token,
        input_base_path='./data',
        sample_size=1024,
    )

    # Option 2: Explicit input files and output path
    indexer = create_tokenize_and_index_jsonl_text_func(
        tokenizer_func=tokenize_text,
        eos_idx=enc.eot_token,
        input_file_paths=['./data/train.jsonl'],
        output_base_path='./output',
        sample_size=1024,
    )

    # Run tokenization and indexing
    indexer()
    ```

    :param tokenizer_func: Function used to tokenize text.
    :param eos_idx: EOS token index, known by the used Tokenizer.
    :param input_base_path: Path to directory containing JSONL files (searched recursively).
        Used as fallback for output if `output_base_path` is not provided.
    :param input_file_paths: List of file paths to process. If provided, these are used
        instead of scanning `input_base_path` for JSONL files.
    :param output_base_path: Base path for output (index and tokenized samples).
        If not provided, `input_base_path` is used.
    :param index_store: Index store to use. If provided, this is used instead of
        creating a new FSBasedIndexStore.
    :param process_text_line_func: Function used to process text lines.
        By default, this converts input JSON lines to dicts and returns the "text" field.
        See function get_text_from_jsonl().
    :param logger: Logger to use. If not provided, uses module logger.
    :param name: Name of the indexer, used for logging purposes.
    :param sample_generator_kwargs: Other kwargs passed to TokenizedSampleGenerator
        (e.g., sample_size, token_dtype, base_output_path).

    :raises ValueError: If both `input_base_path` and `input_file_paths` are None.
    :raises ValueError: If `index_store` is None and both `output_base_path` and
        `input_base_path` are None.

    :return: FileTextLinesIndexer instance that can be called to run tokenization
        and indexing.
    """
    if logger is None:
        logger = module_logger

    # Validate input source
    if input_base_path is None and input_file_paths is None:
        raise ValueError(
            "Either input_base_path or input_file_paths must be provided"
        )

    # Determine output base path
    effective_output_base_path = output_base_path or input_base_path

    # Validate output destination
    if index_store is None and effective_output_base_path is None:
        raise ValueError(
            "Either index_store, output_base_path, or input_base_path must be provided "
            "to determine where to store the index"
        )

    logger.info(f"Output base path: {effective_output_base_path}")

    if process_text_line_func is None:
        process_text_line_func = get_text_from_jsonl

    if index_store is None:
        index_store = FSBasedIndexStore(
            base_path=effective_output_base_path,
        )

    if input_file_paths is None:
        logger.info(f"Scanning for JSONL files in: {input_base_path}")
        input_file_paths = find_files_recursive(
            input_base_path,
            extension_patterns=['*.jsonl', '*.JSONL']
        )
        # Assuming numbered files
        input_file_paths = natural_sort(input_file_paths)
        logger.info(f"Found {len(input_file_paths)} JSONL file(s)")

    # Set default base_output_path for tokenized samples if not provided in kwargs
    if 'base_output_path' not in sample_generator_kwargs:
        default_base_output_path = os.path.join(
            effective_output_base_path, "tokenized-samples"
        )
        logger.info(f"Tokenized samples output path: {default_base_output_path}")
        sample_generator_kwargs['base_output_path'] = default_base_output_path

    sample_generator = TokenizedSampleGenerator(
        process_text_line_func=process_text_line_func,
        tokenizer_func=tokenizer_func,
        eos_idx=eos_idx,
        **sample_generator_kwargs
    )

    return FileTextLinesIndexer(
        input_file_paths=input_file_paths,
        index_store=index_store,
        sample_generator=sample_generator,
        description="Tokenizing and indexing",
        name=name,
    )


def create_tokenize_and_index_with_aux_func(
    process_parts_func: ProcessPartsFunc,
    tokenizer_func: TokenizerFunc,
    eos_idx: int,
    aux_generators: Dict[str, AuxDataGenerator],
    input_base_path: Optional[str] = None,
    input_file_paths: Optional[List[str]] = None,
    output_base_path: Optional[str] = None,
    index_store: Optional[IndexStoreInterface] = None,
    logger: Optional[logging.Logger] = None,
    name: Optional[str] = None,
    **sample_generator_kwargs,
) -> FileTextLinesIndexer:
    """
    Create a pipeline to tokenize structured samples with auxiliary data.

    This function creates a pipeline that:
    * Processes structured input (parts with types) from JSONL files
    * Tokenizes each part and generates auxiliary data (e.g., loss masks)
    * Stores concatenated token + aux data in bin files
    * Creates an index with schema for random access

    Usage:
    ```python
    from data_forager.sample_generators.aux import Part, LossMaskGenerator

    def parse_parts(line_bytes: bytes) -> List[Part]:
        data = json.loads(line_bytes.decode('utf-8'))
        return [Part(type=p['type'], text=p['text']) for p in data['parts']]

    indexer = create_tokenize_and_index_with_aux_func(
        process_parts_func=parse_parts,
        tokenizer_func=tokenizer.encode,
        eos_idx=tokenizer.eos_token_id,
        aux_generators={'loss_mask': LossMaskGenerator()},
        input_base_path='./data',
        sample_size=4096,
    )

    indexer()
    ```

    :param process_parts_func: Function to extract typed parts from input bytes.
        Takes JSONL bytes and returns List[Part].
    :param tokenizer_func: Function used to tokenize text.
    :param eos_idx: EOS token index, known by the used Tokenizer.
    :param aux_generators: Dict mapping names to AuxDataGenerator instances.
        Example: {'loss_mask': LossMaskGenerator()}
    :param input_base_path: Path to directory containing JSONL files.
    :param input_file_paths: List of file paths to process.
    :param output_base_path: Base path for output (index and tokenized samples).
    :param index_store: Index store to use. Must support set_sample_schema().
    :param logger: Logger to use.
    :param name: Name of the indexer for logging.
    :param sample_generator_kwargs: Other kwargs passed to TokenizedSampleWithAuxGenerator
        (e.g., sample_size, token_dtype).

    :raises ValueError: If both input_base_path and input_file_paths are None.
    :raises ValueError: If output destination cannot be determined.

    :return: FileTextLinesIndexer instance that can be called to run the pipeline.
    """
    # Import here to avoid circular dependency
    from data_forager.sample_generators.tokenization_with_aux import (
        TokenizedSampleWithAuxGenerator,
    )

    if logger is None:
        logger = module_logger

    # Validate input source
    if input_base_path is None and input_file_paths is None:
        raise ValueError(
            "Either input_base_path or input_file_paths must be provided"
        )

    # Determine output base path
    effective_output_base_path = output_base_path or input_base_path

    # Validate output destination
    if index_store is None and effective_output_base_path is None:
        raise ValueError(
            "Either index_store, output_base_path, or input_base_path must be provided "
            "to determine where to store the index"
        )

    logger.info(f"Output base path: {effective_output_base_path}")

    if index_store is None:
        index_store = FSBasedIndexStore(
            base_path=effective_output_base_path,
        )

    if input_file_paths is None:
        logger.info(f"Scanning for JSONL files in: {input_base_path}")
        input_file_paths = find_files_recursive(
            input_base_path,
            extension_patterns=['*.jsonl', '*.JSONL']
        )
        input_file_paths = natural_sort(input_file_paths)
        logger.info(f"Found {len(input_file_paths)} JSONL file(s)")

    # Set default base_output_path for tokenized samples if not provided
    if 'base_output_path' not in sample_generator_kwargs:
        default_base_output_path = os.path.join(
            effective_output_base_path, "tokenized-samples"
        )
        logger.info(f"Tokenized samples output path: {default_base_output_path}")
        sample_generator_kwargs['base_output_path'] = default_base_output_path

    sample_generator = TokenizedSampleWithAuxGenerator(
        process_parts_func=process_parts_func,
        tokenizer_func=tokenizer_func,
        eos_idx=eos_idx,
        aux_generators=aux_generators,
        **sample_generator_kwargs
    )

    return FileTextLinesIndexer(
        input_file_paths=input_file_paths,
        index_store=index_store,
        sample_generator=sample_generator,
        description="Tokenizing with aux data and indexing",
        name=name,
    )
