"""
Sample generators for transforming input data into samples.

This package contains:
- SampleGeneratorInterface: Protocol for sample generators
- SampleData: Data class for sample information
- SampleSchema, ArraySpec: Schema classes for structured samples
- TokenizedSampleGenerator: Tokenizes text into fixed-length samples
- TokenizedSampleWithAuxGenerator: Tokenizes with auxiliary data (loss masks, etc.)
"""

from data_forager.sample_generators.common import (
    SampleData,
    SampleGeneratorInterface,
    NOOPSampleGenerator,
    noop_sample_processing,
)
from data_forager.sample_generators.schema import (
    ArraySpec,
    SampleSchema,
)

__all__ = [
    "ArraySpec",
    "NOOPSampleGenerator",
    "SampleData",
    "SampleGeneratorInterface",
    "SampleSchema",
    "noop_sample_processing",
]
