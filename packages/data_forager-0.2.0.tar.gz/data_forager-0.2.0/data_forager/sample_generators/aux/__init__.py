"""
Auxiliary data generators for sample generators.

This subpackage provides generators for auxiliary data that accompanies
tokenized samples, such as loss masks for selective training.
"""

from data_forager.sample_generators.aux.common import (
    AuxDataGenerator,
    Part,
)
from data_forager.sample_generators.aux.loss_mask import LossMaskGenerator

__all__ = [
    "AuxDataGenerator",
    "LossMaskGenerator",
    "Part",
]
