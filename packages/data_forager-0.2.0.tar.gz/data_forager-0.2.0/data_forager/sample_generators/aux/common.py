"""
Common interfaces for auxiliary data generators.

This module provides the protocol and data structures for generating auxiliary
data (e.g., loss masks) alongside tokenized samples.
"""

from typing import List, Protocol

from dataclasses import dataclass

import numpy as np


@dataclass
class Part:
    """
    A typed part of a structured sample.

    Used to represent segments of text with semantic types (e.g., prompt,
    response, system) that determine how auxiliary data is generated.

    :param type: Semantic type of this part (e.g., "system", "prompt",
        "response", "thinking", "text").
    :param text: The text content of this part.
    """

    type: str
    text: str


class AuxDataGenerator(Protocol):
    """
    Protocol for generating auxiliary data for tokenized samples.

    Auxiliary data generators produce per-token data (e.g., loss masks)
    based on the semantic type of each part in a structured sample.
    """

    @property
    def dtype(self) -> np.dtype:
        """
        Return the NumPy dtype for this auxiliary data.

        :return: NumPy dtype (e.g., np.uint8 for loss masks).
        """
        ...

    def generate(
        self,
        part_type: str,
        num_tokens: int,
        *,
        part_tokens: List[int] | None = None,
    ) -> List[int]:
        """
        Generate auxiliary data values for a tokenized part.

        :param part_type: Semantic type of the part (e.g., "prompt", "response").
        :param num_tokens: Number of tokens in this part.
        :param part_tokens: Optional list of actual token IDs, for generators
            that need token-level information.

        :return: List of auxiliary data values, one per token.
        """
        ...

    def generate_for_eos(self) -> int:
        """
        Generate the auxiliary data value for an EOS token.

        EOS tokens are inserted between documents. This method returns the
        value to use for these boundary tokens.

        :return: Single auxiliary data value for the EOS token.
        """
        ...
