"""
Loss mask generator for selective training.

This module provides LossMaskGenerator which creates loss masks based on
part types, enabling selective training on specific parts of samples
(e.g., train on responses but not prompts).
"""

from typing import List, Set

import numpy as np

from data_forager.sample_generators.aux.common import AuxDataGenerator


class LossMaskGenerator(AuxDataGenerator):
    """
    Generates loss masks based on part types.

    Loss mask semantics:
    - mask=1: Excluded from loss (masked out, don't train)
    - mask=0: Included in loss (train on these tokens)

    Default masked types: "system", "prompt"
    Default unmasked types: "text", "response", "thinking"

    :param masked_types: Set of part types to mask (exclude from loss).
    :param mask_eos: Whether to mask EOS tokens. Default False (train on EOS).
    """

    def __init__(
        self,
        masked_types: Set[str] | None = None,
        mask_eos: bool = False,
    ):
        """
        Initialize the loss mask generator.

        :param masked_types: Set of part types to mask. Defaults to {"system", "prompt"}.
        :param mask_eos: Whether to mask EOS tokens. Default False.
        """
        if masked_types is None:
            masked_types = {"system", "prompt"}

        self._masked_types = masked_types
        self._mask_eos = mask_eos

    @property
    def dtype(self) -> np.dtype:
        """Return uint8 dtype for loss masks."""
        return np.dtype(np.uint8)

    def generate(
        self,
        part_type: str,
        num_tokens: int,
        *,
        part_tokens: List[int] | None = None,
    ) -> List[int]:
        """
        Generate loss mask values for a tokenized part.

        :param part_type: Semantic type of the part.
        :param num_tokens: Number of tokens in this part.
        :param part_tokens: Unused, accepted for protocol compatibility.

        :return: List of mask values (1=masked, 0=train).
        """
        mask_value = 1 if part_type in self._masked_types else 0
        return [mask_value] * num_tokens

    def generate_for_eos(self) -> int:
        """
        Generate the loss mask value for an EOS token.

        :return: 1 if mask_eos is True, 0 otherwise.
        """
        return 1 if self._mask_eos else 0
