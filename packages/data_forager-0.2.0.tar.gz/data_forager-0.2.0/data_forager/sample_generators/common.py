"""
Common interfaces and utilities for sample generators.

This module provides the base protocol and data structures used by all sample generators.
"""

from typing import List, Protocol, TYPE_CHECKING

from dataclasses import dataclass

if TYPE_CHECKING:
    from data_forager.sample_generators.schema import SampleSchema


@dataclass
class SampleData:
    """
    Data class containing sample bytes and file location.

    :param sample_bytes: The sample data as bytes.
    :param file_path: Path to the file where the sample is stored.
    """

    sample_bytes: bytes
    file_path: str


class SampleGeneratorInterface(Protocol):
    """
    Protocol defining the interface for sample generators.

    Sample generators transform input data (e.g., text lines) into samples
    that can be indexed and stored for random access during training.
    """

    def prepare(self, text_file_path: str):
        """
        Prepare sample generation from a new input text file.

        :param text_file_path: Path to the input text file.
        """
        ...

    def create_samples(self, text_line: bytes) -> List[SampleData]:
        """
        Create one or more samples from the given text_line and store them.

        IMPORTANT: It is assumed that each sample returned is stored in a file
        sequentially in the same order. This must also hold over multiple function
        calls. This is important because the byte offset of a sample is derived
        from the order the samples are returned.

        :param text_line: Text line in bytes from text_file_path, provided in the
            prepare phase. The function needs to choose a text encoding itself.

        :return: List of SampleData objects. For each created sample:
            - Its representation in bytes, as used to store the sample
            - The file path to where the sample is stored
        """
        ...

    def finish(self, is_last_file: bool):
        """
        Finish generation of samples from the current input file.

        Called after all text lines from the input file have been processed.

        :param is_last_file: Indicates if the input text file was the last file
            to be processed.
        """
        ...

    def get_sample_schema(self) -> "SampleSchema | None":
        """
        Return schema describing sample structure, or None for unstructured samples.

        The schema describes how sample bytes should be interpreted (e.g., array
        names, dtypes, and offsets for multi-array samples).

        :return: SampleSchema if samples have structured format, None otherwise.
        """
        ...


class NOOPSampleGenerator:
    """
    A no-operation sample generator that returns input lines unchanged.

    Used as the default generator when no transformation is needed.
    """

    def __init__(self):
        self._current_text_file = None

    def prepare(self, text_file_path: str):
        self._current_text_file = text_file_path

    def create_samples(self, text_line: bytes) -> List[SampleData]:
        return [SampleData(text_line, self._current_text_file)]

    def finish(self, is_last_file: bool):
        self._current_text_file = None

    def get_sample_schema(self) -> "SampleSchema | None":
        return None


def noop_sample_processing(text_line: bytes, text_file_path: str) -> List[SampleData]:
    """
    Simple function that wraps a text line as a sample without transformation.

    :param text_line: The input text line as bytes.
    :param text_file_path: The file path to associate with the sample.

    :return: List containing a single SampleData with the unchanged text line.
    """
    return [SampleData(text_line, text_file_path)]
