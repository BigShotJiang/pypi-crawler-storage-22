"""
Schema definitions for describing sample structure.

This module contains dataclasses that describe how sample bytes should be
interpreted, particularly for samples containing multiple arrays (e.g., tokens
and loss masks).
"""

from typing import List, Optional

from dataclasses import dataclass, field


@dataclass
class ArraySpec:
    """
    Specification for a single array within a sample.

    :param name: Name of the array (e.g., "tokens", "loss_mask").
    :param dtype: NumPy dtype string (e.g., "uint32", "uint8").
    :param offset: Byte offset within the sample where this array starts.
    """

    name: str
    dtype: str
    offset: int


@dataclass
class SampleSchema:
    """
    Schema describing the structure of samples.

    Used when samples contain multiple arrays (e.g., tokens + auxiliary data).
    Each array has a name, dtype, and byte offset within the sample.

    :param sample_size: Number of elements per array (e.g., context length).
    :param arrays: List of ArraySpec describing each array in the sample.
    :param total_bytes_per_sample: Total size of each sample in bytes.
        If None, computed automatically from arrays.
    """

    sample_size: int
    arrays: List[ArraySpec] = field(default_factory=list)
    total_bytes_per_sample: Optional[int] = None

    def __post_init__(self):
        """Compute total_bytes_per_sample if not provided."""
        if self.total_bytes_per_sample is None and self.arrays:
            import numpy as np
            total = 0
            for arr in self.arrays:
                total += self.sample_size * np.dtype(arr.dtype).itemsize
            self.total_bytes_per_sample = total
