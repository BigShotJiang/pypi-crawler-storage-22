"""
Tokenized sample generator for converting text into fixed-length token samples.

This module provides TokenizedSampleGenerator which tokenizes text and produces
samples of a fixed context length, suitable for language model training.
"""

from typing import Callable, List, Optional

import os
from pathlib import Path

import numpy as np

from basics.base import Base

from data_forager.sample_generators.common import SampleData, SampleGeneratorInterface


TokenizerFunc = Callable[[str], List[int]]
ProcessTextLineFunc = Callable[[bytes], str]


class TokenizedSampleGenerator(Base, SampleGeneratorInterface):
    """
    Tokenizes text into fixed-length samples for language model training.

    This generator:
    1. Processes input text lines using a configurable function
    2. Tokenizes the text using a provided tokenizer
    3. Splits tokens into fixed-length samples
    4. Handles document boundaries with EOS tokens
    5. Carries over remainder tokens across documents
    """

    def __init__(
        self,
        process_text_line_func: ProcessTextLineFunc,
        tokenizer_func: TokenizerFunc,
        eos_idx: int,
        token_dtype: np.dtype = np.uint16,
        sample_size: Optional[int] = None,
        base_output_path: str = None,
        file_name_postfix: str = "tokenized-samples",
        name: Optional[str] = None
    ):
        """
        Initialize the tokenized sample generator.

        Tokenizes and indexes text into fixed length (`sample_size` not None) samples or
        samples of variable size, depending on the text (`sample_size` is None).

        This callable performs the following steps:

        ## prepare ##
        * In the preparation step, create file to store tokenized samples, based on the
          input `text_file_path` and the given `base_output_path` and `file_name_postfix`
        * If the `base_output_path` is not given the `text_file_path` will be used +
          "/tokenized-samples"

        ## create_samples ##
        * To create tokenized text samples, processes incoming text line using
          `process_text_line_func`, e.g. convert JSONL into dict and retrieve the sample
          text from it.
        * The resulting text is tokenized using `tokenizer_func`.
        * If a `sample_size` is given:
          The tokenized text is split into samples of length `sample_size` and stored in
          the file opened in the prepare step. Here `token_dtype` is used.
          - Trailing tokens will be combined with samples of a next text line
          - Tokens from different text samples will be separated by `eos_idx`
        * If a `sample_size` is not given:
          The tokenized text is immediately stored as is, in the file opened in the
          prepare step. Here `token_dtype` is used.

        ## finish ##
        * After all text lines are processed, the file holding the tokenized text samples
          is closed. When `sample_size` is not None: Any final trailing tokens will be
          discarded, but only when the last input text file was processed.

        :param process_text_line_func: Function to extract text from input bytes.
        :param tokenizer_func: Function to tokenize text into token IDs.
        :param eos_idx: End-of-sequence token ID for document boundaries.
        :param token_dtype: NumPy dtype for storing tokens (default: uint16).
        :param sample_size: Fixed sample length, or None for variable-length samples.
        :param base_output_path: Base path for output files.
        :param file_name_postfix: Postfix for output file names.
        :param name: Name for logging purposes.
        """
        super().__init__(pybase_logger_name=name)

        if sample_size is None:
            self._log.info("Tokenized text will NOT be broken into samples of fixed length.")

        self._process_text_line_func = process_text_line_func
        self._tokenizer_func = tokenizer_func
        self._eos_idx = eos_idx
        self._token_dtype = token_dtype
        self._sample_size = sample_size
        self._base_output_path = base_output_path
        self._file_name_postfix = file_name_postfix

        self._current_samples_path = None
        self._current_samples_file = None

        self._rest_tokens = None

    def prepare(self, text_file_path: str):
        """
        Prepare for processing a new input file.

        Creates the output file for storing tokenized samples based on the input
        `text_file_path` and the configured `base_output_path` and `file_name_postfix`.

        :param text_file_path: Path to the input text file.
        """
        input_file_path = os.path.dirname(text_file_path)
        input_file_name = Path(text_file_path).stem
        output_file_name = f"{input_file_name}-{self._file_name_postfix}.bin"

        output_path = self._base_output_path
        if self._base_output_path is None:
            output_path = os.path.join(input_file_path, "tokenized-samples")

        os.makedirs(output_path, exist_ok=True)

        output_file_path = os.path.join(output_path, output_file_name)
        if os.path.exists(output_file_path):
            raise FileExistsError(f"Tokenized samples file already exists: \n{output_file_path}")

        self._current_samples_path = output_file_path
        self._current_samples_file = open(output_file_path, "wb")

        self._log.debug(f"Tokenized samples file opened: \n{output_file_path}")

    def create_samples(self, text_line: bytes) -> List[SampleData]:
        """
        Create tokenized samples from a text line.

        Processes the input text line, tokenizes it, and splits into fixed-length
        samples (if sample_size is set). Handles document boundaries with EOS tokens
        and carries over remainder tokens.

        :param text_line: JSONL text line as bytes.

        :return: List of SampleData objects containing the tokenized samples.
        """
        input_text = self._process_text_line_func(text_line)
        tokenized_text = self._tokenizer_func(input_text)

        if self._sample_size is not None:
            # Always append EOS after each document to mark document boundary
            tokenized_text = tokenized_text + [self._eos_idx]

            # Prepend any leftover tokens from previous document
            if self._rest_tokens is not None:
                tokenized_text = self._rest_tokens + tokenized_text
                self._rest_tokens = None

            num_tokens = len(tokenized_text)
            num_samples = num_tokens // self._sample_size
            num_rest_tokens = num_tokens % self._sample_size

            if num_rest_tokens > 0:
                # Store remainder tokens (includes EOS from this document)
                self._rest_tokens = tokenized_text[-num_rest_tokens:]
                tokenized_text = tokenized_text[:num_samples * self._sample_size]

            tokenized_samples = np.array(tokenized_text, dtype=self._token_dtype)
            tokenized_samples = tokenized_samples.reshape(-1, self._sample_size)
        else:
            tokenized_samples = np.array([tokenized_text], dtype=self._token_dtype)

        # Store tokenized_samples
        sample_data = []
        for sample_idx in range(tokenized_samples.shape[0]):
            sample_bytes = tokenized_samples[sample_idx, :].tobytes()
            sample_data.append(SampleData(
                sample_bytes, self._current_samples_path,
            ))

            self._current_samples_file.write(sample_bytes)

        return sample_data

    def finish(self, is_last_file: bool):
        """
        Finish processing the current input file.

        Closes the current samples file. When `sample_size` is not None, any final
        trailing tokens will be discarded only when the last input file was processed.

        :param is_last_file: Whether this is the last input file.
        """
        self._close_current_samples_file()

        if is_last_file and self._rest_tokens is not None:
            self._log.debug(f"Cut off {len(self._rest_tokens)} unused tokens")

    def get_sample_schema(self):
        """Return None as this generator produces simple token arrays."""
        return None

    def _close_current_samples_file(self):
        if self._current_samples_file:
            self._log.debug(f"Closing tokenized samples file: \n{self._current_samples_path}")
            self._current_samples_file.close()
            self._current_samples_file = None

    def __del__(self):
        self._close_current_samples_file()
