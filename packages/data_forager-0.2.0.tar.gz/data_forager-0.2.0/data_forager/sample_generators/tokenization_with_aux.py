"""
Tokenized sample generator with auxiliary data support.

This module provides TokenizedSampleWithAuxGenerator which tokenizes structured
samples (with typed parts) and generates auxiliary data (e.g., loss masks)
alongside the tokens.
"""

from typing import Callable, Dict, List, Optional

import os
from pathlib import Path

import numpy as np

from basics.base import Base

from data_forager.sample_generators.common import SampleData, SampleGeneratorInterface
from data_forager.sample_generators.schema import SampleSchema, ArraySpec
from data_forager.sample_generators.aux.common import AuxDataGenerator, Part


ProcessPartsFunc = Callable[[bytes], List[Part]]
TokenizerFunc = Callable[[str], List[int]]


class TokenizedSampleWithAuxGenerator(Base, SampleGeneratorInterface):
    """
    Tokenizes structured samples and generates auxiliary data.

    This generator handles samples with typed parts (e.g., prompt, response)
    and produces both tokens and auxiliary data (e.g., loss masks) in a single
    concatenated output.

    Input format: JSONL with {"parts": [{"type": "...", "text": "..."}, ...]}
    Output format: Concatenated bytes [tokens][aux1][aux2]...
    """

    def __init__(
        self,
        process_parts_func: ProcessPartsFunc,
        tokenizer_func: TokenizerFunc,
        eos_idx: int,
        aux_generators: Dict[str, AuxDataGenerator],
        token_dtype: np.dtype = np.uint32,
        sample_size: int = 4096,
        base_output_path: Optional[str] = None,
        file_name_postfix: str = "tokenized-samples",
        name: Optional[str] = None,
    ):
        """
        Initialize the tokenized sample generator with auxiliary data support.

        :param process_parts_func: Function to extract typed parts from input bytes.
            Takes JSONL bytes and returns List[Part].
        :param tokenizer_func: Function to tokenize text into token IDs.
        :param eos_idx: End-of-sequence token ID for document boundaries.
        :param aux_generators: Dict mapping names to AuxDataGenerator instances.
            Example: {"loss_mask": LossMaskGenerator()}
        :param token_dtype: NumPy dtype for storing tokens (default: uint32).
        :param sample_size: Fixed sample length in tokens.
        :param base_output_path: Base path for output files.
        :param file_name_postfix: Postfix for output file names.
        :param name: Name for logging purposes.
        """
        super().__init__(pybase_logger_name=name)

        if not aux_generators:
            raise ValueError("aux_generators must not be empty")

        self._process_parts_func = process_parts_func
        self._tokenizer_func = tokenizer_func
        self._eos_idx = eos_idx
        self._aux_generators = aux_generators
        self._token_dtype = np.dtype(token_dtype)
        self._sample_size = sample_size
        self._base_output_path = base_output_path
        self._file_name_postfix = file_name_postfix

        # Build schema
        self._sample_schema = self._build_schema()

        # Current output state
        self._current_samples_path: Optional[str] = None
        self._current_samples_file = None

        # Remainder from previous document
        self._rest_tokens: Optional[List[int]] = None
        self._rest_aux: Optional[Dict[str, List[int]]] = None

    def _build_schema(self) -> SampleSchema:
        """Build the sample schema from token dtype and aux generators."""
        arrays = []
        offset = 0

        # Tokens array first
        token_bytes = self._sample_size * self._token_dtype.itemsize
        arrays.append(ArraySpec(name="tokens", dtype=str(self._token_dtype), offset=offset))
        offset += token_bytes

        # Auxiliary arrays in sorted order (for deterministic output)
        for name in sorted(self._aux_generators.keys()):
            gen = self._aux_generators[name]
            aux_bytes = self._sample_size * gen.dtype.itemsize
            arrays.append(ArraySpec(name=name, dtype=str(gen.dtype), offset=offset))
            offset += aux_bytes

        return SampleSchema(
            sample_size=self._sample_size,
            arrays=arrays,
            total_bytes_per_sample=offset,
        )

    def get_sample_schema(self) -> SampleSchema:
        """Return the sample schema describing the output structure."""
        return self._sample_schema

    def prepare(self, text_file_path: str):
        """
        Prepare for processing a new input file.

        Creates the output file for storing tokenized samples with aux data.

        :param text_file_path: Path to the input text file.
        """
        input_file_path = os.path.dirname(text_file_path)
        input_file_name = Path(text_file_path).stem
        output_file_name = f"{input_file_name}-{self._file_name_postfix}.bin"

        output_path = self._base_output_path
        if self._base_output_path is None:
            output_path = os.path.join(input_file_path, "tokenized-samples")

        os.makedirs(output_path, exist_ok=True)

        output_file_path = os.path.join(output_path, output_file_name)
        if os.path.exists(output_file_path):
            raise FileExistsError(f"Tokenized samples file already exists: \n{output_file_path}")

        self._current_samples_path = output_file_path
        self._current_samples_file = open(output_file_path, "wb")

        self._log.debug(f"Tokenized samples file opened: \n{output_file_path}")

    def create_samples(self, text_line: bytes) -> List[SampleData]:
        """
        Create tokenized samples with auxiliary data from a structured input.

        Processes the input parts, tokenizes each part, generates auxiliary data,
        and splits into fixed-length samples.

        :param text_line: JSONL line as bytes containing structured parts.

        :return: List of SampleData objects containing the tokenized samples.
        """
        parts = self._process_parts_func(text_line)

        # Tokenize all parts and generate aux data
        doc_tokens: List[int] = []
        doc_aux: Dict[str, List[int]] = {name: [] for name in self._aux_generators}

        for part in parts:
            part_tokens = self._tokenizer_func(part.text)
            doc_tokens.extend(part_tokens)

            for name, gen in self._aux_generators.items():
                aux_values = gen.generate(
                    part_type=part.type,
                    num_tokens=len(part_tokens),
                    part_tokens=part_tokens,
                )
                doc_aux[name].extend(aux_values)

        # Add EOS token and aux values
        doc_tokens.append(self._eos_idx)
        for name, gen in self._aux_generators.items():
            doc_aux[name].append(gen.generate_for_eos())

        # Prepend any leftover from previous document
        # Invariant: rest_tokens and all rest_aux[*] have the same length
        if self._rest_tokens is not None:
            assert all(
                len(self._rest_aux[name]) == len(self._rest_tokens)
                for name in self._aux_generators
            ), "Invariant violated: rest_tokens and rest_aux must have same length"

            doc_tokens = self._rest_tokens + doc_tokens
            for name in self._aux_generators:
                doc_aux[name] = self._rest_aux[name] + doc_aux[name]
            self._rest_tokens = None
            self._rest_aux = None

        # Split into samples
        num_tokens = len(doc_tokens)
        num_samples = num_tokens // self._sample_size
        num_rest_tokens = num_tokens % self._sample_size

        if num_rest_tokens > 0:
            # Store remainder
            self._rest_tokens = doc_tokens[-num_rest_tokens:]
            self._rest_aux = {name: doc_aux[name][-num_rest_tokens:] for name in self._aux_generators}
            doc_tokens = doc_tokens[:num_samples * self._sample_size]
            for name in self._aux_generators:
                doc_aux[name] = doc_aux[name][:num_samples * self._sample_size]

        # Write samples
        sample_data = []
        for i in range(num_samples):
            start = i * self._sample_size
            end = start + self._sample_size

            # Build concatenated sample bytes
            sample_tokens = doc_tokens[start:end]
            sample_bytes = np.array(sample_tokens, dtype=self._token_dtype).tobytes()

            # Add aux data in sorted order
            for name in sorted(self._aux_generators.keys()):
                gen = self._aux_generators[name]
                aux_values = doc_aux[name][start:end]
                sample_bytes += np.array(aux_values, dtype=gen.dtype).tobytes()

            sample_data.append(SampleData(sample_bytes, self._current_samples_path))
            self._current_samples_file.write(sample_bytes)

        return sample_data

    def finish(self, is_last_file: bool):
        """
        Finish processing the current input file.

        Closes the current samples file. When is_last_file is True, any
        remaining tokens are discarded.

        :param is_last_file: Whether this is the last input file.
        """
        self._close_current_samples_file()

        if is_last_file and self._rest_tokens is not None:
            self._log.debug(f"Cut off {len(self._rest_tokens)} unused tokens")
            self._rest_tokens = None
            self._rest_aux = None

    def _close_current_samples_file(self):
        if self._current_samples_file:
            self._log.debug(f"Closing tokenized samples file: \n{self._current_samples_path}")
            self._current_samples_file.close()
            self._current_samples_file = None

    def __del__(self):
        self._close_current_samples_file()
