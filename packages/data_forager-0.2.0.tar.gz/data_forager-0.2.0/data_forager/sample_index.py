"""
Sample index data structures for random access to samples.

This module provides the core data structures for indexing samples:
- SampleLocation: Location of a single sample (file path, byte offset, size)
- SampleIndex: Index containing all sample locations and optional schema
"""

from typing import List, Optional

from dataclasses import dataclass, field

import numpy as np

from data_forager.sample_generators.schema import SampleSchema


@dataclass
class SampleLocation:
    """
    Location information for a single sample.

    :param file_path: Path to the file containing the sample.
    :param byte_offset: Byte offset within the file where the sample starts.
    :param num_bytes: Size of the sample in bytes.
    """

    file_path: str
    byte_offset: int
    num_bytes: int

    def __str__(self):
        return (f"file_path  : {self.file_path}\n"
                f"byte_offset: {self.byte_offset}\n"
                f"num_bytes  : {self.num_bytes}")


@dataclass
class SampleIndex:
    """
    Index for random access to samples stored on disk.

    Contains file locations and byte offsets for all samples, enabling O(1)
    random access via seek operations.

    :param file_locations: List of file paths containing samples.
    :param sample_locations: 2D numpy array of shape (num_samples, 3) where
        each row contains (file_index, byte_offset, num_bytes).
    :param sample_schema: Optional schema describing sample structure for
        samples with auxiliary data (e.g., tokens + loss_mask).
    """

    file_locations: List[str]

    # 2D array <num_samples, 3>
    # The three elements in a row:
    #     file_index : uint64
    #     byte_offset: uint64
    #     num_bytes  : uint64
    sample_locations: np.ndarray

    # Optional schema for structured samples (e.g., tokens + auxiliary data)
    sample_schema: Optional[SampleSchema] = field(default=None)

    def __len__(self) -> int:
        return self.sample_locations.shape[0]

    def __getitem__(self, idx: int) -> SampleLocation:
        sample_location = self.sample_locations[idx, :]
        return SampleLocation(
            file_path=self.file_locations[sample_location[0]],
            byte_offset=int(sample_location[1]),
            num_bytes=int(sample_location[2])
        )
