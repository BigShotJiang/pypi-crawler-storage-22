"""
Tests for TokenizedSampleWithAuxGenerator and TokensWithAuxDataset.

Tests cover:
- Correct generation of tokens and loss masks from structured parts
- Proper handling of remainder tokens across documents
- Schema generation and persistence
- Round-trip through dataset reading
"""

from typing import List

import json
import os
import shutil
import tempfile
import unittest

import numpy as np

from data_forager.sample_generators.aux import Part, LossMaskGenerator
from data_forager.sample_generators.tokenization_with_aux import TokenizedSampleWithAuxGenerator
from data_forager.datasets.tokens_with_aux import TokensWithAuxDataset
from data_forager.index_stores.fs_based import IndexStore
from data_forager.sample_index import SampleIndex


class SimpleTokenizer:
    """Simple character-based tokenizer for testing. Each character = 1 token."""

    def __init__(self):
        # Reserve 0 for EOS
        self.eos_token = 0

    def encode(self, text: str) -> List[int]:
        # Map each character to its ordinal + 1 (to avoid 0 which is EOS)
        return [ord(c) + 1 for c in text]

    def decode(self, tokens: List[int], show_eos: bool = False) -> str:
        """Decode tokens back to text.

        :param tokens: List of token IDs.
        :param show_eos: If True, show EOS as '<EOS>' marker. If False, EOS becomes empty string.
        """
        eos_repr = '<EOS>' if show_eos else ''
        return ''.join(chr(t - 1) if t != self.eos_token else eos_repr for t in tokens)


def parse_parts(line_bytes: bytes) -> List[Part]:
    """Parse JSONL line into list of Part objects."""
    data = json.loads(line_bytes.decode('utf-8'))
    return [Part(type=p['type'], text=p['text']) for p in data['parts']]


class TestTokenizedSampleWithAuxGenerator(unittest.TestCase):

    def setUp(self):
        """Create a temporary directory for test data."""
        self.temp_dir = tempfile.mkdtemp()
        self.tokenizer = SimpleTokenizer()

    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _create_generator(self, sample_size: int = 10) -> TokenizedSampleWithAuxGenerator:
        """Create a generator with default settings."""
        return TokenizedSampleWithAuxGenerator(
            process_parts_func=parse_parts,
            tokenizer_func=self.tokenizer.encode,
            eos_idx=self.tokenizer.eos_token,
            aux_generators={'loss_mask': LossMaskGenerator()},
            token_dtype=np.uint32,
            sample_size=sample_size,
            base_output_path=self.temp_dir,
        )

    def _make_input(self, parts: List[dict]) -> bytes:
        """Create JSONL input bytes from parts."""
        return json.dumps({'parts': parts}).encode('utf-8')

    def test_schema_generation(self):
        """Test that schema is correctly generated from configuration."""
        generator = self._create_generator(sample_size=10)
        schema = generator.get_sample_schema()

        self.assertEqual(schema.sample_size, 10)
        self.assertEqual(len(schema.arrays), 2)  # tokens + loss_mask

        # Check tokens array
        tokens_spec = schema.arrays[0]
        self.assertEqual(tokens_spec.name, 'tokens')
        self.assertEqual(tokens_spec.dtype, 'uint32')
        self.assertEqual(tokens_spec.offset, 0)

        # Check loss_mask array (comes after tokens in sorted order)
        mask_spec = schema.arrays[1]
        self.assertEqual(mask_spec.name, 'loss_mask')
        self.assertEqual(mask_spec.dtype, 'uint8')
        self.assertEqual(mask_spec.offset, 10 * 4)  # sample_size * uint32 size

        # Check total bytes
        expected_total = 10 * 4 + 10 * 1  # tokens (uint32) + loss_mask (uint8)
        self.assertEqual(schema.total_bytes_per_sample, expected_total)

    def test_basic_sample_creation(self):
        """Test basic creation of samples with tokens and loss mask."""
        sample_size = 10
        generator = self._create_generator(sample_size=sample_size)
        generator.prepare(os.path.join(self.temp_dir, 'test.jsonl'))

        # Create input: prompt (masked) + response (not masked)
        # "Hello" = 5 tokens, "World" = 5 tokens, + EOS = 11 tokens total
        input_data = self._make_input([
            {'type': 'prompt', 'text': 'Hello'},
            {'type': 'response', 'text': 'World'},
        ])

        samples = generator.create_samples(input_data)
        generator.finish(is_last_file=True)

        # Should create 1 sample (11 tokens, sample_size=10, 1 rest token)
        self.assertEqual(len(samples), 1)

        # Parse the sample bytes
        sample_bytes = samples[0].sample_bytes
        schema = generator.get_sample_schema()

        tokens = np.frombuffer(sample_bytes[:sample_size * 4], dtype=np.uint32)
        loss_mask = np.frombuffer(sample_bytes[sample_size * 4:], dtype=np.uint8)

        # Verify tokens: "HelloWorld" (first 10 chars)
        decoded = self.tokenizer.decode(tokens.tolist())
        self.assertEqual(decoded, 'HelloWorld')

        # Verify loss mask: first 5 tokens masked (prompt), next 5 not masked (response)
        expected_mask = [1, 1, 1, 1, 1, 0, 0, 0, 0, 0]
        np.testing.assert_array_equal(loss_mask, expected_mask)

    def test_eos_token_handling(self):
        """Test that EOS tokens are correctly placed and masked."""
        sample_size = 8
        generator = self._create_generator(sample_size=sample_size)
        generator.prepare(os.path.join(self.temp_dir, 'test.jsonl'))

        # "ABC" = 3 tokens + EOS = 4 tokens (first doc)
        input1 = self._make_input([{'type': 'response', 'text': 'ABC'}])
        samples1 = generator.create_samples(input1)

        # "DEFG" = 4 tokens + EOS = 5 tokens (second doc)
        # Total with first: 4 + 5 = 9 tokens -> 1 sample of 8, 1 rest
        input2 = self._make_input([{'type': 'response', 'text': 'DEFG'}])
        samples2 = generator.create_samples(input2)

        generator.finish(is_last_file=True)

        # Should have 1 sample total
        self.assertEqual(len(samples1), 0)  # First doc too short
        self.assertEqual(len(samples2), 1)  # Combined creates 1 sample

        # Parse the sample
        sample_bytes = samples2[0].sample_bytes
        tokens = np.frombuffer(sample_bytes[:sample_size * 4], dtype=np.uint32)
        loss_mask = np.frombuffer(sample_bytes[sample_size * 4:], dtype=np.uint8)

        # Expected tokens: ABC + EOS + DEFG (first 8)
        # A=66, B=67, C=68, EOS=0, D=69, E=70, F=71, G=72
        expected_tokens = self.tokenizer.encode('ABC') + [0] + self.tokenizer.encode('DEFG')
        np.testing.assert_array_equal(tokens, expected_tokens[:8])

        # EOS at position 3 should NOT be masked (default mask_eos=False)
        # All response tokens: not masked (0)
        expected_mask = [0, 0, 0, 0, 0, 0, 0, 0]
        np.testing.assert_array_equal(loss_mask, expected_mask)

    def test_eos_masked_when_configured(self):
        """Test that EOS tokens can be masked when mask_eos=True."""
        sample_size = 6
        generator = TokenizedSampleWithAuxGenerator(
            process_parts_func=parse_parts,
            tokenizer_func=self.tokenizer.encode,
            eos_idx=self.tokenizer.eos_token,
            aux_generators={'loss_mask': LossMaskGenerator(mask_eos=True)},
            token_dtype=np.uint32,
            sample_size=sample_size,
            base_output_path=self.temp_dir,
        )
        generator.prepare(os.path.join(self.temp_dir, 'test.jsonl'))

        # "ABCDE" = 5 tokens + EOS = 6 tokens (exactly sample_size)
        input_data = self._make_input([{'type': 'response', 'text': 'ABCDE'}])
        samples = generator.create_samples(input_data)
        generator.finish(is_last_file=True)

        self.assertEqual(len(samples), 1)

        sample_bytes = samples[0].sample_bytes
        loss_mask = np.frombuffer(sample_bytes[sample_size * 4:], dtype=np.uint8)

        # EOS at position 5 should be masked (mask_eos=True)
        expected_mask = [0, 0, 0, 0, 0, 1]
        np.testing.assert_array_equal(loss_mask, expected_mask)

    def test_mixed_part_types(self):
        """Test samples with multiple part types."""
        sample_size = 15
        generator = self._create_generator(sample_size=sample_size)
        generator.prepare(os.path.join(self.temp_dir, 'test.jsonl'))

        # system (masked) + prompt (masked) + response (not masked) + EOS
        # 3 + 4 + 5 + 1 = 13 tokens
        input_data = self._make_input([
            {'type': 'system', 'text': 'SYS'},
            {'type': 'prompt', 'text': 'USER'},
            {'type': 'response', 'text': 'REPLY'},
        ])
        samples = generator.create_samples(input_data)

        # Add another doc to get a complete sample
        # "AB" + EOS = 3 tokens -> total 16 tokens -> 1 sample + 1 rest
        input_data2 = self._make_input([{'type': 'text', 'text': 'AB'}])
        samples2 = generator.create_samples(input_data2)
        generator.finish(is_last_file=True)

        self.assertEqual(len(samples), 0)
        self.assertEqual(len(samples2), 1)

        sample_bytes = samples2[0].sample_bytes
        loss_mask = np.frombuffer(sample_bytes[sample_size * 4:], dtype=np.uint8)

        # SYS (3, masked) + USER (4, masked) + REPLY (5, not masked) + EOS (not masked) + AB (2, not masked)
        expected_mask = [1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0]
        np.testing.assert_array_equal(loss_mask, expected_mask)

    def test_thinking_type_not_masked(self):
        """Test that 'thinking' type is not masked by default."""
        sample_size = 10
        generator = self._create_generator(sample_size=sample_size)
        generator.prepare(os.path.join(self.temp_dir, 'test.jsonl'))

        # thinking tokens should NOT be masked
        input_data = self._make_input([
            {'type': 'prompt', 'text': 'Q'},
            {'type': 'thinking', 'text': 'THINK'},
            {'type': 'response', 'text': 'ANS'},
        ])
        # Q(1) + THINK(5) + ANS(3) + EOS(1) = 10 tokens exactly
        samples = generator.create_samples(input_data)
        generator.finish(is_last_file=True)

        self.assertEqual(len(samples), 1)

        sample_bytes = samples[0].sample_bytes
        loss_mask = np.frombuffer(sample_bytes[sample_size * 4:], dtype=np.uint8)

        # Q (masked) + THINK (not masked) + ANS (not masked) + EOS (not masked)
        expected_mask = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        np.testing.assert_array_equal(loss_mask, expected_mask)

    def test_rest_tokens_aux_invariant(self):
        """Test that rest_tokens and rest_aux maintain same length across documents."""
        sample_size = 10
        generator = self._create_generator(sample_size=sample_size)
        generator.prepare(os.path.join(self.temp_dir, 'test.jsonl'))

        # Create several documents that leave remainders
        docs = [
            self._make_input([{'type': 'prompt', 'text': 'AAA'}]),  # 3 + 1 = 4
            self._make_input([{'type': 'response', 'text': 'BBBBB'}]),  # 5 + 1 = 6 -> total 10, 0 rest
            self._make_input([{'type': 'prompt', 'text': 'CC'}]),  # 2 + 1 = 3
            self._make_input([{'type': 'response', 'text': 'DDDDDDD'}]),  # 7 + 1 = 8 -> total 11, 1 rest
        ]

        all_samples = []
        for doc in docs:
            samples = generator.create_samples(doc)
            all_samples.extend(samples)

        generator.finish(is_last_file=True)

        # Should have 2 complete samples
        self.assertEqual(len(all_samples), 2)

        # Verify each sample has consistent tokens and loss_mask
        for sample in all_samples:
            sample_bytes = sample.sample_bytes
            tokens = np.frombuffer(sample_bytes[:sample_size * 4], dtype=np.uint32)
            loss_mask = np.frombuffer(sample_bytes[sample_size * 4:], dtype=np.uint8)

            self.assertEqual(len(tokens), sample_size)
            self.assertEqual(len(loss_mask), sample_size)


class TestTokensWithAuxDataset(unittest.TestCase):

    def setUp(self):
        """Create a temporary directory for test data."""
        self.temp_dir = tempfile.mkdtemp()
        self.tokenizer = SimpleTokenizer()

    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _create_and_index_samples(self, documents: List[List[dict]], sample_size: int = 10):
        """Create samples and index them using the full pipeline."""
        generator = TokenizedSampleWithAuxGenerator(
            process_parts_func=parse_parts,
            tokenizer_func=self.tokenizer.encode,
            eos_idx=self.tokenizer.eos_token,
            aux_generators={'loss_mask': LossMaskGenerator()},
            token_dtype=np.uint32,
            sample_size=sample_size,
            base_output_path=os.path.join(self.temp_dir, 'tokenized-samples'),
        )

        # Create index store
        index_store = IndexStore(base_path=self.temp_dir)
        index_store.init_store()

        # Process documents
        generator.prepare(os.path.join(self.temp_dir, 'input.jsonl'))

        all_sample_data = []
        for doc_parts in documents:
            input_bytes = json.dumps({'parts': doc_parts}).encode('utf-8')
            samples = generator.create_samples(input_bytes)
            all_sample_data.extend(samples)

        generator.finish(is_last_file=True)

        # Build and save index
        if all_sample_data:
            bytes_per_sample = generator.get_sample_schema().total_bytes_per_sample
            offset = 0

            for sample in all_sample_data:
                index_store.add_sample(sample.file_path, offset, bytes_per_sample)
                offset += bytes_per_sample

            # Set schema before closing
            index_store.set_sample_schema(generator.get_sample_schema())

        index_store.close()

        return generator.get_sample_schema()

    def test_round_trip_basic(self):
        """Test that samples can be written and read back correctly."""
        sample_size = 10
        documents = [
            [{'type': 'prompt', 'text': 'Hello'}, {'type': 'response', 'text': 'World'}],
        ]
        # HelloWorld + EOS = 11 tokens -> 1 sample + 1 rest

        self._create_and_index_samples(documents, sample_size=sample_size)

        # Load via dataset
        dataset = TokensWithAuxDataset.create_from_index_on_filesystem(self.temp_dir)

        self.assertEqual(len(dataset), 1)

        sample = dataset[0]
        self.assertIn('tokens', sample)
        self.assertIn('loss_mask', sample)

        # Verify tokens
        decoded = self.tokenizer.decode(sample['tokens'].tolist())
        self.assertEqual(decoded, 'HelloWorld')

        # Verify loss mask
        expected_mask = [1, 1, 1, 1, 1, 0, 0, 0, 0, 0]
        np.testing.assert_array_equal(sample['loss_mask'], expected_mask)

    def test_round_trip_multiple_samples(self):
        """Test round-trip with multiple samples."""
        sample_size = 8
        documents = [
            [{'type': 'response', 'text': 'ABCDEFG'}],  # 7 + 1 = 8
            [{'type': 'prompt', 'text': 'HI'}, {'type': 'response', 'text': 'JKLMN'}],  # 2 + 5 + 1 = 8
        ]
        # Total: 16 tokens -> 2 samples

        self._create_and_index_samples(documents, sample_size=sample_size)

        dataset = TokensWithAuxDataset.create_from_index_on_filesystem(self.temp_dir)

        self.assertEqual(len(dataset), 2)

        # First sample: ABCDEFG + EOS
        sample0 = dataset[0]
        decoded0 = self.tokenizer.decode(sample0['tokens'].tolist())
        self.assertEqual(decoded0, 'ABCDEFG')
        expected_mask0 = [0, 0, 0, 0, 0, 0, 0, 0]  # All response + EOS (not masked)
        np.testing.assert_array_equal(sample0['loss_mask'], expected_mask0)

        # Second sample: HI (prompt) + JKLMN (response) + EOS
        sample1 = dataset[1]
        decoded1 = self.tokenizer.decode(sample1['tokens'].tolist())
        self.assertEqual(decoded1, 'HIJKLMN')
        expected_mask1 = [1, 1, 0, 0, 0, 0, 0, 0]  # HI masked, rest not
        np.testing.assert_array_equal(sample1['loss_mask'], expected_mask1)

    def test_dataset_requires_schema(self):
        """Test that TokensWithAuxDataset raises error without schema."""
        # Create a sample index without schema
        sample_index = SampleIndex(
            file_locations=['/fake/path.bin'],
            sample_locations=np.array([[0, 0, 100]], dtype=np.int64),
            sample_schema=None,
        )

        with self.assertRaises(ValueError) as context:
            TokensWithAuxDataset(sample_index=sample_index)

        self.assertIn('sample_schema', str(context.exception))

    def test_schema_persisted_and_loaded(self):
        """Test that schema is correctly persisted and loaded."""
        sample_size = 10
        documents = [
            [{'type': 'response', 'text': 'ABCDEFGHIJ'}],  # 10 + 1 = 11 -> 1 sample
        ]

        original_schema = self._create_and_index_samples(documents, sample_size=sample_size)

        # Load index and verify schema
        index_store = IndexStore(base_path=self.temp_dir)
        loaded_index = index_store.load()

        self.assertIsNotNone(loaded_index.sample_schema)
        loaded_schema = loaded_index.sample_schema

        self.assertEqual(loaded_schema.sample_size, original_schema.sample_size)
        self.assertEqual(loaded_schema.total_bytes_per_sample, original_schema.total_bytes_per_sample)
        self.assertEqual(len(loaded_schema.arrays), len(original_schema.arrays))

        for orig, loaded in zip(original_schema.arrays, loaded_schema.arrays):
            self.assertEqual(orig.name, loaded.name)
            self.assertEqual(orig.dtype, loaded.dtype)
            self.assertEqual(orig.offset, loaded.offset)


class TestLossMaskGenerator(unittest.TestCase):

    def test_default_masked_types(self):
        """Test default masked types are system and prompt."""
        gen = LossMaskGenerator()

        # system and prompt should be masked (1)
        self.assertEqual(gen.generate('system', 3), [1, 1, 1])
        self.assertEqual(gen.generate('prompt', 4), [1, 1, 1, 1])

        # response, thinking, text should not be masked (0)
        self.assertEqual(gen.generate('response', 2), [0, 0])
        self.assertEqual(gen.generate('thinking', 5), [0, 0, 0, 0, 0])
        self.assertEqual(gen.generate('text', 3), [0, 0, 0])

    def test_custom_masked_types(self):
        """Test custom masked types."""
        gen = LossMaskGenerator(masked_types={'custom_type'})

        self.assertEqual(gen.generate('custom_type', 3), [1, 1, 1])
        self.assertEqual(gen.generate('system', 2), [0, 0])  # Not in custom set
        self.assertEqual(gen.generate('prompt', 2), [0, 0])  # Not in custom set

    def test_eos_masking(self):
        """Test EOS token masking configuration."""
        gen_default = LossMaskGenerator()
        gen_masked = LossMaskGenerator(mask_eos=True)

        self.assertEqual(gen_default.generate_for_eos(), 0)
        self.assertEqual(gen_masked.generate_for_eos(), 1)

    def test_dtype(self):
        """Test that dtype is uint8."""
        gen = LossMaskGenerator()
        self.assertEqual(gen.dtype, np.dtype(np.uint8))


class TestFactoryFunction(unittest.TestCase):
    """Tests for create_tokenize_and_index_with_aux_func factory function."""

    def setUp(self):
        """Create a temporary directory for test data."""
        self.temp_dir = tempfile.mkdtemp()
        self.tokenizer = SimpleTokenizer()

    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _create_jsonl_file(self, documents: List[List[dict]], filename: str = "test.jsonl"):
        """Create a JSONL file from structured documents."""
        filepath = os.path.join(self.temp_dir, filename)
        with open(filepath, 'w') as f:
            for doc_parts in documents:
                f.write(json.dumps({'parts': doc_parts}) + '\n')
        return filepath

    def test_factory_function_end_to_end(self):
        """Test the full pipeline using the factory function with multiple samples.

        Creates documents using all part types (system, prompt, response, thinking, text)
        and verifies each generated sample has correct tokens and loss masks.
        """
        from data_forager.indexers.tokenization_indexer import (
            create_tokenize_and_index_with_aux_func,
        )

        sample_size = 8

        # Design documents to create 8+ samples with all part types
        # Loss mask: system=1, prompt=1, response=0, thinking=0, text=0
        # Each char = 1 token, EOS = token 0
        #
        # Document layout (chars + EOS):
        # Doc 0: system(3) + prompt(4) + response(5) = 12 + EOS = 13
        # Doc 1: text(10) = 10 + EOS = 11
        # Doc 2: prompt(2) + thinking(6) + response(4) = 12 + EOS = 13
        # Doc 3: system(2) + prompt(3) + thinking(4) + response(3) = 12 + EOS = 13
        # Doc 4: text(15) = 15 + EOS = 16
        # Total: 66 tokens = 8 samples + 2 rest (discarded)

        documents = [
            # Doc 0: SYS + USER + REPLY = 13 tokens with EOS
            [
                {'type': 'system', 'text': 'SYS'},
                {'type': 'prompt', 'text': 'USER'},
                {'type': 'response', 'text': 'REPLY'},
            ],
            # Doc 1: plain text = 11 tokens with EOS
            [
                {'type': 'text', 'text': 'ABCDEFGHIJ'},
            ],
            # Doc 2: prompt + thinking + response = 13 tokens with EOS
            [
                {'type': 'prompt', 'text': 'QQ'},
                {'type': 'thinking', 'text': 'REASON'},
                {'type': 'response', 'text': 'ANSW'},
            ],
            # Doc 3: all four part types = 13 tokens with EOS
            [
                {'type': 'system', 'text': 'OK'},
                {'type': 'prompt', 'text': 'ASK'},
                {'type': 'thinking', 'text': 'HMHM'},
                {'type': 'response', 'text': 'YES'},
            ],
            # Doc 4: long text = 16 tokens with EOS
            [
                {'type': 'text', 'text': 'KLMNOPQRSTUVWXY'},
            ],
        ]

        self._create_jsonl_file(documents)

        # Run the factory function
        indexer = create_tokenize_and_index_with_aux_func(
            process_parts_func=parse_parts,
            tokenizer_func=self.tokenizer.encode,
            eos_idx=self.tokenizer.eos_token,
            aux_generators={'loss_mask': LossMaskGenerator()},
            input_base_path=self.temp_dir,
            sample_size=sample_size,
        )
        indexer()

        # Load the dataset
        dataset = TokensWithAuxDataset.create_from_index_on_filesystem(self.temp_dir)

        self.assertEqual(len(dataset), 8, "Should have 8 complete samples")

        # Build the complete token stream with loss masks for verification
        # Each entry: (token_id, mask_value)
        # EOS token = 0, character tokens = ord(char) + 1
        token_stream = []
        mask_stream = []
        for doc in documents:
            for part in doc:
                mask = 1 if part['type'] in {'system', 'prompt'} else 0
                for char in part['text']:
                    token_stream.append(ord(char) + 1)  # SimpleTokenizer encoding
                    mask_stream.append(mask)
            # EOS after each document (not masked by default)
            token_stream.append(self.tokenizer.eos_token)
            mask_stream.append(0)

        # Split into expected samples
        num_complete_samples = len(token_stream) // sample_size
        self.assertEqual(num_complete_samples, 8)

        for i in range(num_complete_samples):
            start = i * sample_size
            end = start + sample_size

            expected_tokens = token_stream[start:end]
            expected_mask = mask_stream[start:end]

            # Load actual sample
            sample = dataset[i]

            self.assertIn('tokens', sample)
            self.assertIn('loss_mask', sample)

            # Verify tokens
            actual_tokens = sample['tokens'].tolist()
            self.assertEqual(
                actual_tokens, expected_tokens,
                f"Sample {i}: token mismatch\n"
                f"  Expected: {expected_tokens}\n"
                f"  Actual:   {actual_tokens}\n"
                f"  Decoded expected: {self.tokenizer.decode(expected_tokens, show_eos=True)}\n"
                f"  Decoded actual:   {self.tokenizer.decode(actual_tokens, show_eos=True)}"
            )

            # Verify loss mask
            actual_mask = sample['loss_mask'].tolist()
            self.assertEqual(
                actual_mask, expected_mask,
                f"Sample {i}: loss mask mismatch\n"
                f"  Expected: {expected_mask}\n"
                f"  Actual:   {actual_mask}\n"
                f"  Tokens:   {self.tokenizer.decode(actual_tokens, show_eos=True)}"
            )

            # Verify EOS positions explicitly
            eos_positions = [j for j, t in enumerate(actual_tokens) if t == self.tokenizer.eos_token]
            expected_eos_positions = [j for j, t in enumerate(expected_tokens) if t == self.tokenizer.eos_token]
            self.assertEqual(
                eos_positions, expected_eos_positions,
                f"Sample {i}: EOS position mismatch"
            )

    def test_factory_function_with_explicit_paths(self):
        """Test factory function with explicit input file paths."""
        from data_forager.indexers.tokenization_indexer import (
            create_tokenize_and_index_with_aux_func,
        )

        sample_size = 8

        # Create test file
        documents = [[{'type': 'text', 'text': 'ABCDEFGH'}]]  # 8 + EOS = 9 -> 1 sample
        filepath = self._create_jsonl_file(documents, 'explicit.jsonl')

        output_dir = os.path.join(self.temp_dir, 'output')
        os.makedirs(output_dir)

        indexer = create_tokenize_and_index_with_aux_func(
            process_parts_func=parse_parts,
            tokenizer_func=self.tokenizer.encode,
            eos_idx=self.tokenizer.eos_token,
            aux_generators={'loss_mask': LossMaskGenerator()},
            input_file_paths=[filepath],
            output_base_path=output_dir,
            sample_size=sample_size,
        )
        indexer()

        dataset = TokensWithAuxDataset.create_from_index_on_filesystem(output_dir)
        self.assertEqual(len(dataset), 1)

        # All 'text' type tokens should not be masked
        sample = dataset[0]
        expected_mask = [0, 0, 0, 0, 0, 0, 0, 0]
        np.testing.assert_array_equal(sample['loss_mask'], expected_mask)


if __name__ == '__main__':
    unittest.main()
