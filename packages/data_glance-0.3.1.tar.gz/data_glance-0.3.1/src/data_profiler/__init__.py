"""Quick data profiling CLI for parquet and CSV files."""

__version__ = "0.1.0"
