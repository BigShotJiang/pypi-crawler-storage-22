"""CLI for data profiling. Powered by ydata-profiling and Polars."""

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Annotated

import polars as pl
import typer
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn
from rich.table import Table

# Global console and state
console = Console()
err_console = Console(stderr=True)


# Global verbosity state
class OutputLevel:
    quiet: bool = False
    verbose: bool = False


output_level = OutputLevel()


def log(message: str, style: str = "") -> None:
    """Print message unless in quiet mode."""
    if not output_level.quiet:
        console.print(message, style=style)


def log_verbose(message: str, style: str = "dim") -> None:
    """Print message only in verbose mode."""
    if output_level.verbose and not output_level.quiet:
        console.print(f"  [dim]▸[/dim] {message}", style=style)


def log_error(message: str) -> None:
    """Print error message (always shown)."""
    err_console.print(f"[red]✗[/red] {message}")


def log_warning(message: str) -> None:
    """Print warning message unless in quiet mode."""
    if not output_level.quiet:
        err_console.print(f"[yellow]⚠[/yellow] {message}")


def log_success(message: str) -> None:
    """Print success message unless in quiet mode."""
    if not output_level.quiet:
        console.print(f"[green]✓[/green] {message}")


app = typer.Typer(
    name="data-glance",
    help="Fast data profiling for parquet and CSV files.",
    add_completion=False,
    rich_markup_mode="rich",
    no_args_is_help=True,
)


class NullStrategy(str, Enum):
    """Strategy for handling null values."""

    keep = "keep"
    drop_cols = "drop-cols"
    drop_rows = "drop-rows"
    fill_zero = "fill-zero"
    fill_empty = "fill-empty"


class Preset(str, Enum):
    """Profiling presets for different use cases."""

    quick = "quick"  # Minimal, fast profile
    default = "default"  # Standard profile
    full = "full"  # Explorative, detailed profile


@dataclass
class DataQualityReport:
    """Report on data quality issues."""

    total_rows: int
    total_cols: int
    completely_null_cols: list[str]
    high_null_cols: list[tuple[str, float]]
    constant_cols: list[str]
    duplicate_cols: list[tuple[str, str]]
    empty_col_names: list[int]
    high_cardinality_cols: list[tuple[str, int]]
    empty_dataset: bool

    def has_issues(self) -> bool:
        return (
            bool(self.completely_null_cols)
            or bool(self.high_null_cols)
            or bool(self.constant_cols)
            or bool(self.empty_col_names)
            or self.empty_dataset
        )

    def print_report(self) -> None:
        """Print the data quality report using rich."""
        if self.empty_dataset:
            log_error("Dataset is empty (0 rows)")
            return

        issues = []

        if self.completely_null_cols:
            issues.append(
                f"[red]●[/red] {len(self.completely_null_cols)} completely NULL column(s): {', '.join(self.completely_null_cols[:5])}"
            )
            if len(self.completely_null_cols) > 5:
                issues[-1] += f" (+{len(self.completely_null_cols) - 5} more)"

        if self.high_null_cols:
            cols_str = ", ".join(f"{c} ({p:.0%})" for c, p in self.high_null_cols[:3])
            issues.append(f"[yellow]●[/yellow] {len(self.high_null_cols)} high NULL column(s): {cols_str}")

        if self.constant_cols:
            issues.append(
                f"[yellow]●[/yellow] {len(self.constant_cols)} constant column(s): {', '.join(self.constant_cols[:5])}"
            )

        if self.high_cardinality_cols:
            cols_str = ", ".join(f"{c} ({n:,})" for c, n in self.high_cardinality_cols[:3])
            issues.append(f"[blue]●[/blue] {len(self.high_cardinality_cols)} high cardinality column(s): {cols_str}")

        if issues:
            panel = Panel(
                "\n".join(issues),
                title="[bold]Data Quality Issues[/bold]",
                border_style="yellow",
                box=box.ROUNDED,
            )
            console.print(panel)


def analyze_data_quality(df: pl.DataFrame, null_threshold: float = 0.5) -> DataQualityReport:
    """Analyze a DataFrame for data quality issues."""
    n_rows = df.shape[0]
    n_cols = df.shape[1]

    if n_rows == 0:
        return DataQualityReport(
            total_rows=0,
            total_cols=n_cols,
            completely_null_cols=[],
            high_null_cols=[],
            constant_cols=[],
            duplicate_cols=[],
            empty_col_names=[],
            high_cardinality_cols=[],
            empty_dataset=True,
        )

    null_counts = df.null_count()
    completely_null_cols = []
    high_null_cols = []

    for col in df.columns:
        null_count = null_counts[col][0]
        null_pct = null_count / n_rows
        if null_pct == 1.0:
            completely_null_cols.append(col)
        elif null_pct > null_threshold:
            high_null_cols.append((col, null_pct))

    constant_cols = []
    for col in df.columns:
        if col not in completely_null_cols:
            n_unique = df[col].drop_nulls().n_unique()
            if n_unique <= 1:
                constant_cols.append(col)

    empty_col_names = [i for i, col in enumerate(df.columns) if not col or col.strip() == ""]

    high_cardinality_cols = []
    cardinality_threshold = max(1000, n_rows * 0.9)
    for col in df.columns:
        if df[col].dtype in (pl.String, pl.Utf8):
            n_unique = df[col].n_unique()
            if n_unique > cardinality_threshold:
                high_cardinality_cols.append((col, n_unique))

    duplicate_cols = []
    if n_cols <= 100:
        cols = df.columns
        for i, col1 in enumerate(cols[:-1]):
            for col2 in cols[i + 1 :]:
                if df[col1].dtype == df[col2].dtype:
                    try:
                        if df[col1].equals(df[col2]):
                            duplicate_cols.append((col1, col2))
                    except Exception:
                        pass

    return DataQualityReport(
        total_rows=n_rows,
        total_cols=n_cols,
        completely_null_cols=completely_null_cols,
        high_null_cols=high_null_cols,
        constant_cols=constant_cols,
        duplicate_cols=duplicate_cols,
        empty_col_names=empty_col_names,
        high_cardinality_cols=high_cardinality_cols,
        empty_dataset=False,
    )


def is_gcs_path(file_path: Path) -> bool:
    """Check if a path is a Google Cloud Storage URI.

    Note: Path() collapses 'gs://' to 'gs:/', so we check for the collapsed form.
    """
    return str(file_path).startswith("gs:/")


def gcs_uri(file_path: Path) -> str:
    """Reconstruct the original gs:// URI from a Path object.

    Path() collapses the double slash in 'gs://bucket/path' to 'gs:/bucket/path'.
    This restores the proper URI scheme.
    """
    s = str(file_path)
    if s.startswith("gs://"):
        return s
    return "gs://" + s[4:]


def get_file_type(file_path: Path) -> str:
    """Determine file type from extension."""
    suffix = file_path.suffix.lower()
    if suffix == ".parquet":
        return "parquet"
    elif suffix in (".csv", ".tsv", ".txt"):
        return "csv"
    elif suffix in (".gz", ".gzip"):
        stem_suffix = Path(file_path.stem).suffix.lower()
        if stem_suffix == ".csv":
            return "csv"
        elif stem_suffix == ".parquet":
            return "parquet"
        return "csv"
    else:
        raise typer.BadParameter(f"Unsupported file type: {suffix}. Supported: .parquet, .csv, .tsv, .txt, .csv.gz")


def read_csv_with_options(
    file_path: Path,
    delimiter: str | None = None,
    encoding: str = "utf-8",
    has_header: bool = True,
    skip_rows: int = 0,
    n_rows: int | None = None,
    infer_schema_length: int = 10000,
    ignore_errors: bool = False,
    truncate_ragged_lines: bool = False,
) -> pl.DataFrame:
    """Read CSV with configurable options and fallbacks."""
    delimiters_to_try = [delimiter] if delimiter else [",", "\t", ";", "|"]
    encodings_to_try = list(dict.fromkeys([encoding, "utf-8", "latin-1", "cp1252"]))
    source = gcs_uri(file_path) if is_gcs_path(file_path) else file_path

    last_error = None

    for enc in encodings_to_try:
        for delim in delimiters_to_try:
            try:
                log_verbose(f"Trying delimiter='{delim}' encoding={enc}")
                df = pl.read_csv(
                    source,
                    separator=delim,
                    encoding=enc,
                    has_header=has_header,
                    skip_rows=skip_rows,
                    n_rows=n_rows,
                    infer_schema_length=infer_schema_length,
                    ignore_errors=ignore_errors,
                    truncate_ragged_lines=truncate_ragged_lines,
                )
                if len(df.columns) == 1 and delim != delimiter:
                    sample = str(df.head(1).to_dict())
                    for alt_delim in [",", "\t", ";", "|"]:
                        if alt_delim != delim and alt_delim in sample:
                            continue
                log_verbose(f"Successfully parsed with delimiter='{delim}' encoding={enc}")
                return df
            except Exception as e:
                last_error = e
                continue

    display = gcs_uri(file_path) if is_gcs_path(file_path) else file_path
    raise typer.BadParameter(
        f"Failed to read CSV: {display}\nError: {last_error}\nTry: --delimiter, --encoding, or --ignore-errors"
    )


def read_file(
    file_path: Path,
    delimiter: str | None = None,
    encoding: str = "utf-8",
    has_header: bool = True,
    skip_rows: int = 0,
    n_rows: int | None = None,
    ignore_errors: bool = False,
    truncate_ragged_lines: bool = False,
) -> pl.DataFrame:
    """Read a single file into a Polars DataFrame."""
    file_type = get_file_type(file_path)
    gcs = is_gcs_path(file_path)

    if not gcs and not file_path.exists():
        raise typer.BadParameter(f"File not found: {file_path}")

    if not gcs:
        file_size_mb = file_path.stat().st_size / (1024 * 1024)
        if file_size_mb > 1000:
            log_warning(f"Large file ({file_size_mb:.0f} MB). Consider using --sample")

    if file_type == "parquet":
        try:
            source = gcs_uri(file_path) if gcs else file_path
            if n_rows:
                return pl.scan_parquet(source).head(n_rows).collect()
            return pl.scan_parquet(source).collect()
        except Exception as e:
            raise typer.BadParameter(f"Failed to read parquet: {e}") from e
    else:
        return read_csv_with_options(
            file_path,
            delimiter=delimiter,
            encoding=encoding,
            has_header=has_header,
            skip_rows=skip_rows,
            n_rows=n_rows,
            ignore_errors=ignore_errors,
            truncate_ragged_lines=truncate_ragged_lines,
        )


def filter_columns(df: pl.DataFrame, include: str | None, exclude: str | None) -> pl.DataFrame:
    """Filter columns based on include/exclude patterns."""
    import fnmatch

    cols = df.columns

    if include:
        patterns = [p.strip() for p in include.split(",")]
        cols = [c for c in cols if any(fnmatch.fnmatch(c, p) for p in patterns)]
        log_verbose(f"Including columns matching: {include} → {len(cols)} columns")

    if exclude:
        patterns = [p.strip() for p in exclude.split(",")]
        cols = [c for c in cols if not any(fnmatch.fnmatch(c, p) for p in patterns)]
        log_verbose(f"Excluding columns matching: {exclude} → {len(cols)} columns")

    if not cols:
        raise typer.BadParameter("No columns remaining after filtering")

    return df.select(cols)


def apply_null_strategy(df: pl.DataFrame, strategy: NullStrategy, report: DataQualityReport) -> pl.DataFrame:
    """Apply null handling strategy to DataFrame."""
    if strategy == NullStrategy.keep:
        return df

    if strategy == NullStrategy.drop_cols:
        cols_to_drop = report.completely_null_cols
        if cols_to_drop:
            log(f"Dropping {len(cols_to_drop)} completely null column(s)")
            df = df.drop(cols_to_drop)
        return df

    if strategy == NullStrategy.drop_rows:
        original_rows = df.shape[0]
        df = df.drop_nulls()
        dropped = original_rows - df.shape[0]
        if dropped:
            log(f"Dropped {dropped:,} rows with nulls ({dropped / original_rows:.1%})")
        return df

    if strategy == NullStrategy.fill_zero:
        numeric_cols = [col for col in df.columns if df[col].dtype.is_numeric()]
        if numeric_cols:
            df = df.with_columns([pl.col(c).fill_null(0) for c in numeric_cols])
            log(f"Filled nulls with 0 in {len(numeric_cols)} numeric column(s)")
        return df

    if strategy == NullStrategy.fill_empty:
        string_cols = [col for col in df.columns if df[col].dtype in (pl.String, pl.Utf8)]
        if string_cols:
            df = df.with_columns([pl.col(c).fill_null("") for c in string_cols])
            log(f"Filled nulls with '' in {len(string_cols)} string column(s)")
        return df

    return df


def validate_and_concat(dfs: list[pl.DataFrame], file_paths: list[Path]) -> pl.DataFrame:
    """Validate schemas match and concatenate DataFrames."""
    if len(dfs) == 1:
        return dfs[0]

    base_schema = dfs[0].schema

    for df, path in zip(dfs[1:], file_paths[1:]):
        if df.schema != base_schema:
            log_error(f"Schema mismatch: {file_paths[0].name} vs {path.name}")

            base_cols = set(base_schema.keys())
            other_cols = set(df.schema.keys())
            missing = base_cols - other_cols
            extra = other_cols - base_cols

            if missing:
                log_error(f"Missing columns: {missing}")
            if extra:
                log_error(f"Extra columns: {extra}")

            common = base_cols & other_cols
            type_mismatches = [(c, base_schema[c], df.schema[c]) for c in common if base_schema[c] != df.schema[c]]
            if type_mismatches:
                for col, t1, t2 in type_mismatches[:5]:
                    log_error(f"Type mismatch: {col} ({t1} vs {t2})")

            raise typer.Exit(1)

    return pl.concat(dfs)


def print_schema_table(df: pl.DataFrame, title: str = "Schema") -> None:
    """Print schema as a rich table."""
    table = Table(title=title, box=box.SIMPLE, show_header=True)
    table.add_column("Column", style="cyan")
    table.add_column("Type", style="green")
    table.add_column("Nulls", justify="right")

    n_rows = df.shape[0]
    null_counts = df.null_count()

    for col, dtype in df.schema.items():
        null_count = null_counts[col][0]
        null_pct = null_count / n_rows if n_rows > 0 else 0
        null_str = f"{null_pct:.1%}" if null_pct > 0 else "-"
        null_style = "red" if null_pct > 0.5 else ("yellow" if null_pct > 0 else "dim")
        table.add_row(col, str(dtype), f"[{null_style}]{null_str}[/{null_style}]")

    console.print(table)


# Callback for global options
@app.callback()
def main(
    quiet: Annotated[
        bool,
        typer.Option("--quiet", "-q", help="Suppress all output except errors"),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Show detailed progress information"),
    ] = False,
) -> None:
    """
    [bold]data-glance[/bold] - Fast data profiling for CSV and Parquet files.

    Generate comprehensive data quality reports with a single command.
    """
    output_level.quiet = quiet
    output_level.verbose = verbose


@app.command()
def profile(
    files: Annotated[
        list[Path],
        typer.Argument(help="Files to profile (.parquet, .csv, .tsv)"),
    ],
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Output HTML file path"),
    ] = None,
    title: Annotated[
        str | None,
        typer.Option("--title", "-t", help="Report title"),
    ] = None,
    preset: Annotated[
        Preset,
        typer.Option("--preset", "-p", help="Profiling preset: quick, default, or full"),
    ] = Preset.default,
    sample: Annotated[
        int | None,
        typer.Option("--sample", "-s", help="Sample N rows before profiling"),
    ] = None,
    include_columns: Annotated[
        str | None,
        typer.Option(
            "--include", "-i", help="Only include columns matching pattern (comma-separated, supports wildcards)"
        ),
    ] = None,
    exclude_columns: Annotated[
        str | None,
        typer.Option("--exclude", "-x", help="Exclude columns matching pattern (comma-separated, supports wildcards)"),
    ] = None,
    json_output: Annotated[
        Path | None,
        typer.Option("--json", help="Also export as JSON"),
    ] = None,
    no_browser: Annotated[
        bool,
        typer.Option("--no-browser", help="Don't open in browser"),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Analyze without generating report"),
    ] = False,
    # Null handling
    null_strategy: Annotated[
        NullStrategy,
        typer.Option("--nulls", help="Null handling: keep, drop-cols, drop-rows, fill-zero, fill-empty"),
    ] = NullStrategy.keep,
    drop_null_threshold: Annotated[
        float | None,
        typer.Option("--drop-null-threshold", help="Drop columns above this null percentage (0.0-1.0)"),
    ] = None,
    drop_constant: Annotated[
        bool,
        typer.Option("--drop-constant", help="Drop constant columns"),
    ] = False,
    # CSV options
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter ('tab' for tab)"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
    no_header: Annotated[
        bool,
        typer.Option("--no-header", help="CSV has no header row"),
    ] = False,
    skip_rows: Annotated[
        int,
        typer.Option("--skip-rows", help="Skip N rows at start"),
    ] = 0,
    ignore_errors: Annotated[
        bool,
        typer.Option("--ignore-errors", help="Skip malformed lines"),
    ] = False,
) -> None:
    """
    Generate a data profile report.

    [bold]Examples:[/bold]

        data-glance profile data.parquet

        data-glance profile data.csv --preset quick --sample 10000

        data-glance profile *.csv --include "user_*,order_*" --exclude "*_id"
    """
    from ydata_profiling import ProfileReport

    if delimiter == "tab":
        delimiter = "\t"

    # Validate files exist
    for f in files:
        if not is_gcs_path(f) and not f.exists():
            log_error(f"File not found: {f}")
            raise typer.Exit(1)

    # Read files with progress
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
        disable=output_level.quiet,
    ) as progress:
        task = progress.add_task("Reading files...", total=len(files))
        dfs = []
        for file_path in files:
            progress.update(task, description=f"Reading {file_path.name}...")
            df = read_file(
                file_path,
                delimiter=delimiter,
                encoding=encoding,
                has_header=not no_header,
                skip_rows=skip_rows,
                ignore_errors=ignore_errors,
            )
            dfs.append(df)
            progress.advance(task)

    # Concatenate
    if len(dfs) > 1:
        log("Validating schemas...")
    combined_df = validate_and_concat(dfs, files)

    # Filter columns
    if include_columns or exclude_columns:
        combined_df = filter_columns(combined_df, include_columns, exclude_columns)

    log(f"Dataset: [bold]{combined_df.shape[0]:,}[/bold] rows × [bold]{combined_df.shape[1]}[/bold] columns")

    # Analyze quality
    quality_report = analyze_data_quality(combined_df)

    if quality_report.empty_dataset:
        log_error("Dataset is empty. Nothing to profile.")
        raise typer.Exit(1)

    if quality_report.has_issues():
        quality_report.print_report()

    # Apply transformations
    combined_df = apply_null_strategy(combined_df, null_strategy, quality_report)

    if drop_null_threshold is not None:
        null_counts = combined_df.null_count()
        n_rows = combined_df.shape[0]
        cols_to_drop = [col for col in combined_df.columns if null_counts[col][0] / n_rows > drop_null_threshold]
        if cols_to_drop:
            log(f"Dropping {len(cols_to_drop)} column(s) above {drop_null_threshold:.0%} null threshold")
            combined_df = combined_df.drop(cols_to_drop)

    if drop_constant and quality_report.constant_cols:
        constant_cols = [c for c in quality_report.constant_cols if c in combined_df.columns]
        if constant_cols:
            log(f"Dropping {len(constant_cols)} constant column(s)")
            combined_df = combined_df.drop(constant_cols)

    if combined_df.shape[1] == 0:
        log_error("No columns remaining after filtering.")
        raise typer.Exit(1)

    # Sample
    if sample and sample < combined_df.shape[0]:
        log(f"Sampling {sample:,} rows...")
        combined_df = combined_df.sample(n=sample, seed=42)

    # Dry run - just show what would happen
    if dry_run:
        log_success("Dry run complete. Would profile:")
        print_schema_table(combined_df, f"Columns to Profile ({combined_df.shape[1]})")
        console.print(f"\n[dim]Preset: {preset.value}, Rows: {combined_df.shape[0]:,}[/dim]")
        return

    # Convert to pandas
    log("Converting to pandas...")
    pandas_df = combined_df.to_pandas()

    # Title
    if title is None:
        if len(files) == 1:
            title = f"Profile: {files[0].name}"
        else:
            title = f"Profile: {len(files)} files"

    # Output path
    if output is None:
        output = Path("profile_report.html")

    # Profile kwargs based on preset
    profile_kwargs = {"title": title}
    if preset == Preset.quick:
        profile_kwargs["minimal"] = True
    elif preset == Preset.full:
        profile_kwargs["explorative"] = True

    # Generate report
    preset_name = {"quick": "minimal", "default": "standard", "full": "explorative"}[preset.value]
    log(f"Generating {preset_name} profile...")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        disable=output_level.quiet,
    ) as progress:
        progress.add_task("Analyzing data...", total=None)
        report = ProfileReport(pandas_df, **profile_kwargs)
        report.to_file(output)

    if json_output:
        log(f"Saving JSON to {json_output}...")
        report.to_file(json_output)

    log_success(f"Report saved to [bold]{output}[/bold]")

    if not no_browser:
        import webbrowser

        webbrowser.open(f"file://{output.resolve()}")


@app.command()
def head(
    files: Annotated[
        list[Path],
        typer.Argument(help="Files to preview"),
    ],
    rows: Annotated[
        int,
        typer.Option("--rows", "-n", help="Number of rows to show"),
    ] = 10,
    columns: Annotated[
        int | None,
        typer.Option("--columns", "-c", help="Max columns to show"),
    ] = None,
    # CSV options
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
) -> None:
    """
    Preview first N rows of data files.

    [bold]Examples:[/bold]

        data-glance head data.parquet

        data-glance head data.csv --rows 20 --columns 5
    """
    if delimiter == "tab":
        delimiter = "\t"

    for file_path in files:
        if not is_gcs_path(file_path) and not file_path.exists():
            log_error(f"File not found: {file_path}")
            continue

        df = read_file(file_path, delimiter=delimiter, encoding=encoding, n_rows=rows)

        if columns and columns < len(df.columns):
            df = df.select(df.columns[:columns])
            log(f"[dim](showing {columns} of {len(df.columns)} columns)[/dim]")

        display = gcs_uri(file_path) if is_gcs_path(file_path) else file_path
        console.print(f"\n[bold]{display}[/bold] ({df.shape[0]} rows × {df.shape[1]} columns)")
        console.print(df)


@app.command()
def diagnose(
    files: Annotated[
        list[Path],
        typer.Argument(help="Files to diagnose"),
    ],
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
    no_header: Annotated[
        bool,
        typer.Option("--no-header", help="CSV has no header"),
    ] = False,
    ignore_errors: Annotated[
        bool,
        typer.Option("--ignore-errors", help="Skip malformed lines"),
    ] = False,
) -> None:
    """
    Diagnose data quality issues without generating a report.

    [bold]Examples:[/bold]

        data-glance diagnose data.csv

        data-glance diagnose messy.csv --ignore-errors
    """
    if delimiter == "tab":
        delimiter = "\t"

    dfs = []
    for file_path in files:
        if not is_gcs_path(file_path) and not file_path.exists():
            log_error(f"File not found: {file_path}")
            raise typer.Exit(1)
        log(f"Reading {file_path.name}...")
        df = read_file(
            file_path,
            delimiter=delimiter,
            encoding=encoding,
            has_header=not no_header,
            ignore_errors=ignore_errors,
        )
        dfs.append(df)

    combined_df = validate_and_concat(dfs, files) if len(dfs) > 1 else dfs[0]

    log(f"\nDataset: [bold]{combined_df.shape[0]:,}[/bold] rows × [bold]{combined_df.shape[1]}[/bold] columns")

    report = analyze_data_quality(combined_df)

    print_schema_table(combined_df)

    if report.has_issues():
        console.print()
        report.print_report()

        console.print("\n[bold]Suggested fixes:[/bold]")
        if report.completely_null_cols:
            console.print("  • [cyan]--nulls drop-cols[/cyan] to remove null columns")
        if report.high_null_cols:
            console.print("  • [cyan]--drop-null-threshold 0.5[/cyan] to drop >50% null columns")
        if report.constant_cols:
            console.print("  • [cyan]--drop-constant[/cyan] to remove constant columns")
        if report.high_cardinality_cols:
            console.print("  • [cyan]--preset quick[/cyan] for faster profiling")
    else:
        log_success("No data quality issues detected")

    memory_mb = combined_df.estimated_size() / (1024 * 1024)
    console.print(f"\n[dim]Estimated memory: {memory_mb:.1f} MB[/dim]")


@app.command()
def schema(
    files: Annotated[
        list[Path],
        typer.Argument(help="Files to inspect"),
    ],
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
) -> None:
    """
    Display file schema (column names and types).

    [bold]Examples:[/bold]

        data-glance schema data.parquet

        data-glance schema *.csv
    """
    if delimiter == "tab":
        delimiter = "\t"

    for file_path in files:
        if not is_gcs_path(file_path) and not file_path.exists():
            log_error(f"File not found: {file_path}")
            continue

        df = read_file(file_path, delimiter=delimiter, encoding=encoding, n_rows=100)

        if is_gcs_path(file_path):
            console.print(f"\n[bold]{gcs_uri(file_path)}[/bold]")
        else:
            file_size = file_path.stat().st_size
            size_str = f"{file_size / 1024 / 1024:.1f} MB" if file_size > 1024 * 1024 else f"{file_size / 1024:.1f} KB"
            console.print(f"\n[bold]{file_path}[/bold] [dim]({size_str})[/dim]")
        print_schema_table(df, f"{df.shape[1]} columns")


@app.command()
def stats(
    files: Annotated[
        list[Path],
        typer.Argument(help="Files to analyze"),
    ],
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
) -> None:
    """
    Show quick statistics using Polars describe().

    [bold]Examples:[/bold]

        data-glance stats data.parquet
    """
    if delimiter == "tab":
        delimiter = "\t"

    dfs = []
    for f in files:
        if not is_gcs_path(f) and not f.exists():
            log_error(f"File not found: {f}")
            raise typer.Exit(1)
        df = read_file(f, delimiter=delimiter, encoding=encoding)
        dfs.append(df)

    combined_df = validate_and_concat(dfs, files) if len(dfs) > 1 else dfs[0]

    log(f"\nDataset: [bold]{combined_df.shape[0]:,}[/bold] rows × [bold]{combined_df.shape[1]}[/bold] columns\n")
    console.print(combined_df.describe())


@app.command()
def generate(
    output: Annotated[
        Path,
        typer.Argument(help="Output file (.parquet or .csv)"),
    ],
    rows: Annotated[
        int,
        typer.Option("--rows", "-n", help="Number of rows"),
    ] = 1000,
    seed: Annotated[
        int,
        typer.Option("--seed", help="Random seed"),
    ] = 42,
    nulls: Annotated[
        float,
        typer.Option("--nulls", help="Null fraction (0.0-1.0)"),
    ] = 0.05,
    edge_cases: Annotated[
        bool,
        typer.Option("--edge-cases", help="Add edge case columns"),
    ] = False,
) -> None:
    """
    Generate synthetic test data.

    [bold]Examples:[/bold]

        data-glance generate test.parquet --rows 5000

        data-glance generate test.csv --edge-cases --nulls 0.1
    """
    import random
    from datetime import date, datetime, timedelta

    random.seed(seed)

    log(f"Generating {rows:,} rows...")

    base_date = date(2020, 1, 1)
    base_datetime = datetime(2020, 1, 1, 0, 0, 0)

    data = {
        "id": list(range(rows)),
        "int_small": [random.randint(-100, 100) for _ in range(rows)],
        "int_large": [random.randint(-1_000_000, 1_000_000) for _ in range(rows)],
        "float_normal": [random.gauss(0, 1) for _ in range(rows)],
        "float_price": [round(random.uniform(0.99, 999.99), 2) for _ in range(rows)],
        "name": [random.choice(["Alice", "Bob", "Charlie", "Diana", "Eve"]) for _ in range(rows)],
        "category": [random.choice(["A", "B", "C", "D"]) for _ in range(rows)],
        "status": [random.choice(["pending", "active", "completed"]) for _ in range(rows)],
        "is_active": [random.choice([True, False]) for _ in range(rows)],
        "date_created": [base_date + timedelta(days=random.randint(0, 1000)) for _ in range(rows)],
        "datetime_event": [
            base_datetime + timedelta(days=random.randint(0, 1000), hours=random.randint(0, 23)) for _ in range(rows)
        ],
        "age": [random.randint(18, 85) for _ in range(rows)],
        "score": [min(100, max(0, int(random.gauss(75, 15)))) for _ in range(rows)],
        "income": [int(random.lognormvariate(10, 1)) for _ in range(rows)],
        "user_id": [f"user_{random.randint(1, rows // 2):06d}" for _ in range(rows)],
    }

    if edge_cases:
        log_verbose("Adding edge case columns")
        data.update(
            {
                "all_null": [None] * rows,
                "constant": ["SAME"] * rows,
                "unique_id": [f"unique_{i:010d}" for i in range(rows)],
                "maybe_empty": [random.choice(["value", "", None]) for _ in range(rows)],
                "numeric_string": [str(random.randint(1, 100)) for _ in range(rows)],
            }
        )

    df = pl.DataFrame(data)

    if nulls > 0:
        log_verbose(f"Introducing ~{nulls:.0%} nulls")
        skip_cols = {"id", "all_null", "constant"}
        for col in df.columns:
            if col not in skip_cols:
                null_mask = [random.random() < nulls for _ in range(rows)]
                if any(null_mask):
                    df = df.with_columns(pl.when(pl.Series(null_mask)).then(None).otherwise(pl.col(col)).alias(col))

    suffix = output.suffix.lower()
    if suffix == ".parquet":
        df.write_parquet(output)
    elif suffix in (".csv", ".tsv"):
        df.write_csv(output)
    else:
        output = output.with_suffix(".parquet")
        df.write_parquet(output)

    log_success(f"Generated [bold]{output}[/bold]: {df.shape[0]:,} rows × {df.shape[1]} columns")


@app.command()
def count(
    files: Annotated[
        list[Path],
        typer.Argument(help="Files to count rows in"),
    ],
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
    total: Annotated[
        bool,
        typer.Option("--total", "-t", help="Show only total count"),
    ] = False,
) -> None:
    """
    Count rows in files (fast, minimal memory).

    [bold]Examples:[/bold]

        data-glance count data.parquet

        data-glance count *.csv --total
    """
    if delimiter == "tab":
        delimiter = "\t"

    total_rows = 0
    for file_path in files:
        if not is_gcs_path(file_path) and not file_path.exists():
            log_error(f"File not found: {file_path}")
            continue

        file_type = get_file_type(file_path)
        source = gcs_uri(file_path) if is_gcs_path(file_path) else file_path
        if file_type == "parquet":
            # Fast parquet row count without loading data
            df = pl.scan_parquet(source)
            row_count = df.select(pl.len()).collect().item()
        else:
            # For CSV, use lazy scanning
            try:
                sep = delimiter if delimiter else ","
                df = pl.scan_csv(source, separator=sep, encoding=encoding)
                row_count = df.select(pl.len()).collect().item()
            except Exception:
                # Fallback to reading
                df = read_file(file_path, delimiter=delimiter, encoding=encoding)
                row_count = df.shape[0]

        total_rows += row_count
        if not total:
            display = gcs_uri(file_path) if is_gcs_path(file_path) else file_path
            console.print(f"{display}: [bold]{row_count:,}[/bold] rows")

    if len(files) > 1 or total:
        if total:
            console.print(total_rows)
        else:
            console.print(f"[dim]Total: [bold]{total_rows:,}[/bold] rows[/dim]")


@app.command()
def columns(
    file: Annotated[
        Path,
        typer.Argument(help="File to list columns from"),
    ],
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
    one_per_line: Annotated[
        bool,
        typer.Option("--one", "-1", help="One column per line (for scripting)"),
    ] = False,
    with_types: Annotated[
        bool,
        typer.Option("--types", "-t", help="Include data types"),
    ] = False,
) -> None:
    """
    List column names (useful for scripting).

    [bold]Examples:[/bold]

        data-glance columns data.parquet

        data-glance columns data.csv --one | grep user

        data-glance columns data.parquet --types
    """
    if delimiter == "tab":
        delimiter = "\t"

    if not is_gcs_path(file) and not file.exists():
        log_error(f"File not found: {file}")
        raise typer.Exit(1)

    df = read_file(file, delimiter=delimiter, encoding=encoding, n_rows=1)

    if one_per_line:
        for col in df.columns:
            if with_types:
                console.print(f"{col}\t{df.schema[col]}")
            else:
                console.print(col)
    else:
        if with_types:
            for col, dtype in df.schema.items():
                console.print(f"[cyan]{col}[/cyan]: [green]{dtype}[/green]")
        else:
            console.print(", ".join(df.columns))


@app.command()
def sample(
    file: Annotated[
        Path,
        typer.Argument(help="Input file"),
    ],
    output: Annotated[
        Path,
        typer.Argument(help="Output file"),
    ],
    n: Annotated[
        int,
        typer.Option("--rows", "-n", help="Number of rows to sample"),
    ] = 1000,
    fraction: Annotated[
        float | None,
        typer.Option("--fraction", "-f", help="Fraction of rows to sample (0.0-1.0)"),
    ] = None,
    seed: Annotated[
        int,
        typer.Option("--seed", help="Random seed for reproducibility"),
    ] = 42,
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
) -> None:
    """
    Extract a random sample to a new file.

    [bold]Examples:[/bold]

        data-glance sample data.parquet sample.parquet -n 1000

        data-glance sample big.csv small.csv --fraction 0.1

        data-glance sample data.parquet sample.csv  # Convert while sampling
    """
    if delimiter == "tab":
        delimiter = "\t"

    if not is_gcs_path(file) and not file.exists():
        log_error(f"File not found: {file}")
        raise typer.Exit(1)

    log(f"Reading {file.name}...")
    df = read_file(file, delimiter=delimiter, encoding=encoding)

    original_rows = df.shape[0]

    if fraction is not None:
        n = int(original_rows * fraction)

    n = min(n, original_rows)

    log(f"Sampling {n:,} of {original_rows:,} rows ({n / original_rows:.1%})...")
    sampled = df.sample(n=n, seed=seed)

    suffix = output.suffix.lower()
    if suffix == ".parquet":
        sampled.write_parquet(output)
    elif suffix in (".csv", ".tsv"):
        sampled.write_csv(output)
    else:
        output = output.with_suffix(".parquet")
        sampled.write_parquet(output)

    log_success(f"Saved {n:,} rows to [bold]{output}[/bold]")


@app.command()
def convert(
    input_file: Annotated[
        Path,
        typer.Argument(help="Input file"),
    ],
    output_file: Annotated[
        Path,
        typer.Argument(help="Output file"),
    ],
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter for input"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding for input"),
    ] = "utf-8",
    output_delimiter: Annotated[
        str,
        typer.Option("--output-delimiter", help="CSV delimiter for output"),
    ] = ",",
    compression: Annotated[
        str | None,
        typer.Option("--compression", help="Parquet compression (snappy, gzip, lz4, zstd)"),
    ] = None,
) -> None:
    """
    Convert between file formats.

    [bold]Examples:[/bold]

        data-glance convert data.csv data.parquet

        data-glance convert data.parquet data.csv

        data-glance convert data.csv data.parquet --compression zstd

        data-glance convert data.csv data.tsv --output-delimiter tab
    """
    if delimiter == "tab":
        delimiter = "\t"
    if output_delimiter == "tab":
        output_delimiter = "\t"

    if not is_gcs_path(input_file) and not input_file.exists():
        log_error(f"File not found: {input_file}")
        raise typer.Exit(1)

    log(f"Reading {input_file.name}...")
    df = read_file(input_file, delimiter=delimiter, encoding=encoding)

    suffix = output_file.suffix.lower()
    if suffix == ".parquet":
        log("Writing parquet...")
        df.write_parquet(output_file, compression=compression or "snappy")
    elif suffix in (".csv", ".tsv"):
        log("Writing CSV...")
        df.write_csv(output_file, separator=output_delimiter)
    else:
        log_error(f"Unsupported output format: {suffix}")
        raise typer.Exit(1)

    input_display = gcs_uri(input_file) if is_gcs_path(input_file) else input_file
    log_success(f"Converted [bold]{input_display}[/bold] → [bold]{output_file}[/bold]")

    if not is_gcs_path(input_file):
        input_size = input_file.stat().st_size
        output_size = output_file.stat().st_size
        ratio = output_size / input_size if input_size > 0 else 0
        console.print(
            f"[dim]Size: {input_size / 1024 / 1024:.1f} MB → {output_size / 1024 / 1024:.1f} MB ({ratio:.1%})[/dim]"
        )


@app.command()
def unique(
    file: Annotated[
        Path,
        typer.Argument(help="Input file"),
    ],
    column: Annotated[
        str,
        typer.Argument(help="Column to inspect"),
    ],
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="Max values to show"),
    ] = 20,
    counts: Annotated[
        bool,
        typer.Option("--counts", "-c", help="Show value counts"),
    ] = False,
    sort_by_count: Annotated[
        bool,
        typer.Option("--sort", "-s", help="Sort by count (descending)"),
    ] = False,
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
) -> None:
    """
    Show unique values in a column.

    [bold]Examples:[/bold]

        data-glance unique data.csv status

        data-glance unique data.parquet category --counts --sort

        data-glance unique data.csv user_id --limit 50
    """
    if delimiter == "tab":
        delimiter = "\t"

    if not is_gcs_path(file) and not file.exists():
        log_error(f"File not found: {file}")
        raise typer.Exit(1)

    df = read_file(file, delimiter=delimiter, encoding=encoding)

    if column not in df.columns:
        log_error(f"Column not found: {column}")
        log(f"Available columns: {', '.join(df.columns)}")
        raise typer.Exit(1)

    n_unique = df[column].n_unique()
    n_nulls = df[column].null_count()

    console.print(f"\n[bold]{column}[/bold]: {n_unique:,} unique values", end="")
    if n_nulls > 0:
        console.print(f" [dim]({n_nulls:,} nulls)[/dim]")
    else:
        console.print()

    if counts:
        value_counts = df.group_by(column).agg(pl.len().alias("count"))
        if sort_by_count:
            value_counts = value_counts.sort("count", descending=True)
        else:
            value_counts = value_counts.sort(column)

        table = Table(box=box.SIMPLE)
        table.add_column("Value", style="cyan")
        table.add_column("Count", justify="right")
        table.add_column("%", justify="right")

        total = df.shape[0]
        for row in value_counts.head(limit).iter_rows():
            val, cnt = row
            pct = cnt / total * 100
            val_str = str(val) if val is not None else "[dim]null[/dim]"
            table.add_row(val_str, f"{cnt:,}", f"{pct:.1f}%")

        console.print(table)

        if n_unique > limit:
            console.print(f"[dim]... and {n_unique - limit:,} more values[/dim]")
    else:
        values = df[column].unique().sort().head(limit).to_list()
        for val in values:
            console.print(f"  {val}" if val is not None else "  [dim]null[/dim]")

        if n_unique > limit:
            console.print(f"[dim]... and {n_unique - limit:,} more values[/dim]")


@app.command()
def tail(
    files: Annotated[
        list[Path],
        typer.Argument(help="Files to preview"),
    ],
    rows: Annotated[
        int,
        typer.Option("--rows", "-n", help="Number of rows to show"),
    ] = 10,
    columns: Annotated[
        int | None,
        typer.Option("--columns", "-c", help="Max columns to show"),
    ] = None,
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
) -> None:
    """
    Preview last N rows of data files.

    [bold]Examples:[/bold]

        data-glance tail data.parquet

        data-glance tail data.csv --rows 20
    """
    if delimiter == "tab":
        delimiter = "\t"

    for file_path in files:
        if not is_gcs_path(file_path) and not file_path.exists():
            log_error(f"File not found: {file_path}")
            continue

        df = read_file(file_path, delimiter=delimiter, encoding=encoding)

        if columns and columns < len(df.columns):
            df = df.select(df.columns[:columns])

        display = gcs_uri(file_path) if is_gcs_path(file_path) else file_path
        console.print(f"\n[bold]{display}[/bold] (last {min(rows, df.shape[0])} of {df.shape[0]:,} rows)")
        console.print(df.tail(rows))


@app.command()
def filter(
    file: Annotated[
        Path,
        typer.Argument(help="Input file"),
    ],
    expr: Annotated[
        str,
        typer.Argument(help="Filter expression (Polars SQL-like syntax)"),
    ],
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Output file (prints to stdout if not specified)"),
    ] = None,
    limit: Annotated[
        int | None,
        typer.Option("--limit", "-n", help="Limit output rows"),
    ] = None,
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
) -> None:
    """
    Filter data using expressions.

    Uses Polars expression syntax. Common patterns:
    - col('name') == 'value'
    - col('age') > 30
    - col('status').is_in(['active', 'pending'])
    - col('name').str.contains('test')
    - col('value').is_null()

    [bold]Examples:[/bold]

        data-glance filter data.csv "col('status') == 'active'"

        data-glance filter data.parquet "col('age') > 30" -o filtered.parquet

        data-glance filter data.csv "col('name').str.contains('test')" --limit 100
    """
    if delimiter == "tab":
        delimiter = "\t"

    if not is_gcs_path(file) and not file.exists():
        log_error(f"File not found: {file}")
        raise typer.Exit(1)

    df = read_file(file, delimiter=delimiter, encoding=encoding)
    original_rows = df.shape[0]

    try:
        # Evaluate the filter expression
        filter_expr = eval(expr, {"col": pl.col, "pl": pl, "lit": pl.lit})
        filtered = df.filter(filter_expr)
    except Exception as e:
        log_error(f"Invalid filter expression: {e}")
        console.print("\n[bold]Expression help:[/bold]")
        console.print("  col('column_name') == 'value'")
        console.print("  col('column_name') > 100")
        console.print("  col('column_name').is_in(['a', 'b'])")
        console.print("  col('column_name').is_null()")
        console.print("  col('column_name').str.contains('pattern')")
        raise typer.Exit(1) from None

    if limit:
        filtered = filtered.head(limit)

    matched_rows = filtered.shape[0]
    log(f"Matched {matched_rows:,} of {original_rows:,} rows ({matched_rows / original_rows:.1%})")

    if output:
        suffix = output.suffix.lower()
        if suffix == ".parquet":
            filtered.write_parquet(output)
        else:
            filtered.write_csv(output)
        log_success(f"Saved to [bold]{output}[/bold]")
    else:
        console.print(filtered)


@app.command()
def compare(
    file1: Annotated[
        Path,
        typer.Argument(help="First file"),
    ],
    file2: Annotated[
        Path,
        typer.Argument(help="Second file"),
    ],
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
) -> None:
    """
    Compare two data files.

    Shows differences in schema, row counts, and data statistics.

    [bold]Examples:[/bold]

        data-glance compare data_v1.parquet data_v2.parquet

        data-glance compare old.csv new.csv
    """
    if delimiter == "tab":
        delimiter = "\t"

    if not is_gcs_path(file1) and not file1.exists():
        log_error(f"File not found: {file1}")
        raise typer.Exit(1)
    if not is_gcs_path(file2) and not file2.exists():
        log_error(f"File not found: {file2}")
        raise typer.Exit(1)

    log(f"Reading {file1.name}...")
    df1 = read_file(file1, delimiter=delimiter, encoding=encoding)
    log(f"Reading {file2.name}...")
    df2 = read_file(file2, delimiter=delimiter, encoding=encoding)

    console.print(f"\n[bold]Comparison: {file1.name} vs {file2.name}[/bold]\n")

    # Row counts
    table = Table(title="Overview", box=box.SIMPLE)
    table.add_column("Metric")
    table.add_column(file1.name, justify="right")
    table.add_column(file2.name, justify="right")
    table.add_column("Diff", justify="right")

    row_diff = df2.shape[0] - df1.shape[0]
    row_diff_str = f"+{row_diff:,}" if row_diff > 0 else f"{row_diff:,}"
    row_style = "green" if row_diff > 0 else ("red" if row_diff < 0 else "dim")

    col_diff = df2.shape[1] - df1.shape[1]
    col_diff_str = f"+{col_diff}" if col_diff > 0 else f"{col_diff}"
    col_style = "green" if col_diff > 0 else ("red" if col_diff < 0 else "dim")

    table.add_row("Rows", f"{df1.shape[0]:,}", f"{df2.shape[0]:,}", f"[{row_style}]{row_diff_str}[/{row_style}]")
    table.add_row("Columns", str(df1.shape[1]), str(df2.shape[1]), f"[{col_style}]{col_diff_str}[/{col_style}]")

    if not is_gcs_path(file1) and not is_gcs_path(file2):
        size1 = file1.stat().st_size / 1024 / 1024
        size2 = file2.stat().st_size / 1024 / 1024
        size_diff = size2 - size1
        size_diff_str = f"+{size_diff:.1f}" if size_diff > 0 else f"{size_diff:.1f}"
        size_style = "yellow" if abs(size_diff) > 1 else "dim"
        table.add_row("Size (MB)", f"{size1:.1f}", f"{size2:.1f}", f"[{size_style}]{size_diff_str}[/{size_style}]")

    console.print(table)

    # Schema comparison
    cols1 = set(df1.columns)
    cols2 = set(df2.columns)

    added = cols2 - cols1
    removed = cols1 - cols2
    common = cols1 & cols2

    if added or removed:
        console.print("\n[bold]Schema Changes[/bold]")
        if added:
            console.print(f"  [green]+ Added:[/green] {', '.join(sorted(added))}")
        if removed:
            console.print(f"  [red]- Removed:[/red] {', '.join(sorted(removed))}")

    # Type changes
    type_changes = []
    for col in common:
        if df1.schema[col] != df2.schema[col]:
            type_changes.append((col, df1.schema[col], df2.schema[col]))

    if type_changes:
        console.print("\n[bold]Type Changes[/bold]")
        for col, old_type, new_type in type_changes:
            console.print(f"  {col}: [red]{old_type}[/red] → [green]{new_type}[/green]")

    # Null changes for common columns
    null_changes = []
    for col in common:
        null1 = df1[col].null_count() / df1.shape[0] if df1.shape[0] > 0 else 0
        null2 = df2[col].null_count() / df2.shape[0] if df2.shape[0] > 0 else 0
        if abs(null2 - null1) > 0.05:  # More than 5% change
            null_changes.append((col, null1, null2))

    if null_changes:
        console.print("\n[bold]Significant Null Changes (>5%)[/bold]")
        for col, old_pct, new_pct in null_changes[:10]:
            diff = new_pct - old_pct
            style = "red" if diff > 0 else "green"
            console.print(f"  {col}: {old_pct:.1%} → {new_pct:.1%} ([{style}]{diff:+.1%}[/{style}])")

    if not added and not removed and not type_changes and not null_changes:
        log_success("No significant differences found")


@app.command()
def validate(
    file: Annotated[
        Path,
        typer.Argument(help="File to validate"),
    ],
    no_nulls: Annotated[
        str | None,
        typer.Option("--no-nulls", help="Columns that must not have nulls (comma-separated)"),
    ] = None,
    unique: Annotated[
        str | None,
        typer.Option("--unique", help="Columns that must be unique (comma-separated)"),
    ] = None,
    min_rows: Annotated[
        int | None,
        typer.Option("--min-rows", help="Minimum required rows"),
    ] = None,
    max_nulls: Annotated[
        float | None,
        typer.Option("--max-null-pct", help="Max null percentage allowed (0.0-1.0)"),
    ] = None,
    required_columns: Annotated[
        str | None,
        typer.Option("--required-cols", help="Columns that must exist (comma-separated)"),
    ] = None,
    delimiter: Annotated[
        str | None,
        typer.Option("--delimiter", "-d", help="CSV delimiter"),
    ] = None,
    encoding: Annotated[
        str,
        typer.Option("--encoding", help="File encoding"),
    ] = "utf-8",
) -> None:
    """
    Validate data against rules.

    Returns exit code 1 if validation fails.

    [bold]Examples:[/bold]

        data-glance validate data.csv --no-nulls "id,email"

        data-glance validate data.parquet --unique "id" --min-rows 1000

        data-glance validate data.csv --required-cols "id,name,email" --max-null-pct 0.1
    """
    if delimiter == "tab":
        delimiter = "\t"

    if not is_gcs_path(file) and not file.exists():
        log_error(f"File not found: {file}")
        raise typer.Exit(1)

    df = read_file(file, delimiter=delimiter, encoding=encoding)
    n_rows = df.shape[0]

    errors = []
    warnings = []

    # Check minimum rows
    if min_rows and n_rows < min_rows:
        errors.append(f"Row count {n_rows:,} is below minimum {min_rows:,}")

    # Check required columns
    if required_columns:
        required = [c.strip() for c in required_columns.split(",")]
        missing = [c for c in required if c not in df.columns]
        if missing:
            errors.append(f"Missing required columns: {', '.join(missing)}")

    # Check no nulls
    if no_nulls:
        cols = [c.strip() for c in no_nulls.split(",")]
        for col in cols:
            if col not in df.columns:
                warnings.append(f"Column '{col}' not found (--no-nulls check skipped)")
                continue
            null_count = df[col].null_count()
            if null_count > 0:
                errors.append(f"Column '{col}' has {null_count:,} null values")

    # Check unique
    if unique:
        cols = [c.strip() for c in unique.split(",")]
        for col in cols:
            if col not in df.columns:
                warnings.append(f"Column '{col}' not found (--unique check skipped)")
                continue
            n_unique = df[col].n_unique()
            if n_unique != n_rows:
                duplicates = n_rows - n_unique
                errors.append(f"Column '{col}' has {duplicates:,} duplicate values")

    # Check max null percentage
    if max_nulls is not None:
        for col in df.columns:
            null_pct = df[col].null_count() / n_rows if n_rows > 0 else 0
            if null_pct > max_nulls:
                errors.append(f"Column '{col}' has {null_pct:.1%} nulls (max: {max_nulls:.1%})")

    # Report results
    console.print(f"\n[bold]Validating {file.name}[/bold]")
    console.print(f"  Rows: {n_rows:,}")
    console.print(f"  Columns: {df.shape[1]}")

    if warnings:
        console.print(f"\n[yellow]Warnings ({len(warnings)}):[/yellow]")
        for w in warnings:
            console.print(f"  [yellow]⚠[/yellow] {w}")

    if errors:
        console.print(f"\n[red]Errors ({len(errors)}):[/red]")
        for e in errors:
            console.print(f"  [red]✗[/red] {e}")
        log_error(f"Validation failed with {len(errors)} error(s)")
        raise typer.Exit(1)
    else:
        log_success("Validation passed")


@app.command()
def info(
    files: Annotated[
        list[Path],
        typer.Argument(help="Files to inspect"),
    ],
) -> None:
    """
    Show file metadata without reading data.

    [bold]Examples:[/bold]

        data-glance info data.parquet

        data-glance info *.csv
    """
    for file_path in files:
        if not is_gcs_path(file_path) and not file_path.exists():
            log_error(f"File not found: {file_path}")
            continue

        file_type = get_file_type(file_path)
        gcs = is_gcs_path(file_path)

        display = gcs_uri(file_path) if gcs else file_path
        console.print(f"\n[bold]{display}[/bold]")
        console.print(f"  Type: {file_type}")

        if not gcs:
            stat = file_path.stat()
            size_mb = stat.st_size / 1024 / 1024

            from datetime import datetime

            modified = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")

            console.print(f"  Size: {size_mb:.2f} MB ({stat.st_size:,} bytes)")
            console.print(f"  Modified: {modified}")

        # For parquet, we can get row count without reading all data
        if file_type == "parquet":
            try:
                if gcs:
                    lf = pl.scan_parquet(gcs_uri(file_path))
                    row_count = lf.select(pl.len()).collect().item()
                    schema = lf.collect_schema()
                    console.print(f"  Rows: {row_count:,}")
                    console.print(f"  Columns: {len(schema)}")
                else:
                    import pyarrow.parquet as pq

                    parquet_file = pq.ParquetFile(file_path)
                    console.print(f"  Rows: {parquet_file.metadata.num_rows:,}")
                    console.print(f"  Columns: {parquet_file.metadata.num_columns}")
                    console.print(f"  Row groups: {parquet_file.metadata.num_row_groups}")
            except Exception:
                pass


if __name__ == "__main__":
    app()
