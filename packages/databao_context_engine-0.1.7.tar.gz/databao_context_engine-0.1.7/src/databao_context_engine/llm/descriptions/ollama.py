from databao_context_engine.llm.descriptions.provider import DescriptionProvider
from databao_context_engine.llm.service import OllamaService


class OllamaDescriptionProvider(DescriptionProvider):
    def __init__(self, *, service: OllamaService, model_id: str):
        self._service = service
        self._model_id = model_id

    @property
    def describer(self) -> str:
        return "ollama"

    @property
    def model_id(self) -> str:
        return self._model_id

    def describe(self, text: str, context: str) -> str:
        return self._service.describe(model=self._model_id, text=text, context=context)
