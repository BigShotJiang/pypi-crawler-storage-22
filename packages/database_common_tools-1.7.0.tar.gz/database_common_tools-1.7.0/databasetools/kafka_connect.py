# -*- coding: utf-8 -*-
"""Kafka consumer and producer utilities."""

import json
import traceback
from typing import Any, List, Optional, Union
from kafka import KafkaConsumer, KafkaProducer, TopicPartition


def kafka_consumer(
    topic: str, group: str, servers: List[str], offset: str = 'latest'
) -> KafkaConsumer:
    """
    Create a Kafka consumer.

    Args:
        topic: Kafka topic name
        group: Consumer group ID
        servers: List of Kafka broker addresses
        offset: Offset reset policy ('earliest' or 'latest')

    Returns:
        KafkaConsumer instance
    """
    return KafkaConsumer(
        topic, group_id=group, bootstrap_servers=servers, auto_offset_reset=offset
    )


def kafka_consumer_extend(
    topic: str,
    group: str,
    servers: List[str],
    offset: str = 'latest',
    enable_auto_commit: bool = False,
    auto_commit_interval_ms: int = 5000,
    max_poll_records: int = 500,
    max_poll_interval_ms: int = 15 * 60 * 1000,  # 15 minutes
    session_timeout_ms: int = 30000,
    heartbeat_interval_ms: int = 10000,
) -> KafkaConsumer:
    """
    Create a Kafka consumer with extended configuration options.

    Args:
        topic: Kafka topic name
        group: Consumer group ID
        servers: List of Kafka broker addresses
        offset: Offset reset policy ('earliest' or 'latest')
        enable_auto_commit: Whether to enable auto commit
        auto_commit_interval_ms: Auto commit interval in milliseconds
        max_poll_records: Maximum number of records per poll
        max_poll_interval_ms: Maximum poll interval in milliseconds
        session_timeout_ms: Session timeout in milliseconds
        heartbeat_interval_ms: Heartbeat interval in milliseconds

    Returns:
        KafkaConsumer instance
    """
    consumer = KafkaConsumer(
        topic,
        group_id=group,
        bootstrap_servers=servers,
        auto_offset_reset=offset,
        enable_auto_commit=enable_auto_commit,
        auto_commit_interval_ms=auto_commit_interval_ms,
        max_poll_records=max_poll_records,
        max_poll_interval_ms=max_poll_interval_ms,
        session_timeout_ms=session_timeout_ms,
        heartbeat_interval_ms=heartbeat_interval_ms,
    )
    return consumer


def kafka_consumer_no_offset_topic(
    group: str, servers: List[str]
) -> KafkaConsumer:
    """
    Create a Kafka consumer without specifying topic (for dynamic subscription).

    Args:
        group: Consumer group ID
        servers: List of Kafka broker addresses

    Returns:
        KafkaConsumer instance
    """
    return KafkaConsumer(group_id=group, bootstrap_servers=servers)


def appoint_offset(
    csr: KafkaConsumer, topic: str, offset: int, partition: int
) -> None:
    """
    Set consumer offset to a specific position.

    Args:
        csr: KafkaConsumer instance
        topic: Topic name
        offset: Offset value
        partition: Partition number
    """
    partitions = csr.partitions_for_topic(topic)
    tp = TopicPartition(topic, partition)
    csr.assign([tp])
    csr.seek(tp, offset)


def kafka_producer_simplest(bootstrap_servers: List[str]) -> KafkaProducer:
    """
    Create a simple Kafka producer.

    Args:
        bootstrap_servers: List of Kafka broker addresses

    Returns:
        KafkaProducer instance
    """
    return KafkaProducer(bootstrap_servers=bootstrap_servers)


def kafka_producer(bootstrap_servers: List[str]) -> KafkaProducer:
    """
    Create a Kafka producer with JSON serialization.

    Args:
        bootstrap_servers: List of Kafka broker addresses

    Returns:
        KafkaProducer instance with JSON serializers
    """
    return KafkaProducer(
        bootstrap_servers=bootstrap_servers,
        key_serializer=lambda k: k.encode('utf-8') if k is not None else None,
        value_serializer=lambda v: json.dumps(v).encode('utf-8'),
    )


def send_message(
    producer: KafkaProducer, topic: str, key: str, message: Any, log: Any
) -> None:
    """
    Send a message to a Kafka topic.

    Args:
        producer: KafkaProducer instance
        topic: Topic name
        key: Message key
        message: Message value
        log: Logger instance
    """
    try:
        producer.send(topic=topic, key=key, value=message)
    except Exception as e:
        log.error(f'Failed to send message: {e}, message:{message}')


def send_message_strongest(
    producer: KafkaProducer, topic: str, key: Any, message: Any, log: Any
) -> None:
    """
    Send a message to Kafka with automatic serialization and error handling.

    Args:
        producer: KafkaProducer instance
        topic: Topic name
        key: Message key (str, bytes, or None)
        message: Message body (dict, list, str, int, float)
        log: Logger instance
    """
    try:
        if isinstance(key, str):
            key_bytes = key.encode('utf-8')
        elif not isinstance(key, (bytes, type(None))):
            key_bytes = str(key).encode('utf-8')
        else:
            key_bytes = key

        if isinstance(message, (dict, list)):
            value = json.dumps(message).encode('utf-8')
        elif isinstance(message, str):
            value = message.encode('utf-8')
        elif isinstance(message, (int, float)):
            value = str(message).encode('utf-8')
        else:
            raise TypeError(f'Unsupported message type: {type(message)}')

        producer.send(topic=topic, key=key_bytes, value=value)

    except Exception as e:
        log.error(
            f"Failed to send message to topic '{topic}' with key '{key}': {e}\n"
            f"Message: {message}\n"
            f"Traceback:\n{traceback.format_exc()}"
        )
