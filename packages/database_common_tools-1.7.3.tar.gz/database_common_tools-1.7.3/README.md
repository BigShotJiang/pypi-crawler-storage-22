# Database Common Tools

A Python library that makes it easier to work with message middleware and databases. This library provides convenient utilities for connecting to and working with Redis, MongoDB, MySQL, Kafka, and OpenSearch.

## Features

- **Redis**: Easy connection and data manipulation utilities
- **MongoDB**: Simplified connection and query operations
- **MySQL**: Database connection and query helpers
- **Kafka**: Consumer utilities for message processing
- **OpenSearch/Elasticsearch**: Search and indexing utilities
- **JSON Analysis**: Tools for parsing and analyzing JSON documents
- **Data Analysis**: Field analysis and data processing utilities

## Installation

```bash
pip install database-common-tools
```

Or install from source:

```bash
git clone https://github.com/yangming9/database-common-tools.git
cd database-common-tools
pip install -e .
```

## Requirements

- Python >= 3.6
- See `requirements.txt` for full dependency list

## Quick Start

### Redis

```python
from databasetools import rd_connect, rd_set, rd_get

# Connect to Redis
rd = rd_connect(host='localhost', port=6379, password='')

# Set and get values
rd_set(rd, 'key', 'value')
value = rd_get(rd, 'key', log)
```

### MongoDB

```python
from databasetools import mongo_conn, mongo_find_all

# Connect to MongoDB
mongo = mongo_conn(host='localhost', port=27017, database='mydb', log=log)

# Query documents
docs = mongo_find_all(mongo, 'collection_name')
```

### MySQL

```python
from databasetools.mysql_connect_v2 import MySQLConnector

# Create connector
connector = MySQLConnector(
    host='localhost',
    port=3306,
    user='root',
    password='password',
    database='mydb',
    log=log
)

# Connect and query
connector.connect()
results = connector.execute_query("SELECT * FROM users")
connector.disconnect()
```

### Kafka

```python
from databasetools import kafka_consumer

# Consume messages
for message in kafka_consumer(bootstrap_servers=['localhost:9092'], topic='my_topic'):
    print(message.value)
```

## Project Structure

```
database-common-tools/
├── databasetools/          # Main package
│   ├── __init__.py        # Package initialization and exports
│   ├── redis_connect.py   # Redis utilities
│   ├── mongo_connect.py   # MongoDB utilities
│   ├── mysql_connect.py   # MySQL utilities
│   ├── kafka_connect.py   # Kafka utilities
│   ├── opensearch_connect.py  # OpenSearch utilities
│   ├── analysis_json.py   # JSON analysis tools
│   └── ...                # Other utilities
├── examples/              # Example files
├── test/                  # Test files
├── setup.py              # Package setup
├── pyproject.toml        # Modern Python project configuration
├── requirements.txt      # Runtime dependencies
├── requirements-dev.txt  # Development dependencies
└── README.md            # This file
```

## Development

### Setup Development Environment

```bash
# Clone the repository
git clone https://github.com/yangming9/database-common-tools.git
cd database-common-tools

# Install in development mode
pip install -e .

# Install development dependencies
pip install -r requirements-dev.txt
```

### Running Tests

```bash
pytest
```

### Code Formatting

```bash
black databasetools/
```

### Linting

```bash
flake8 databasetools/
```

## Version History

See the [releases page](https://github.com/yangming9/database-common-tools/releases) for version history.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Author

**Coder Yang**

- Email: yma91412@gmail.com
- GitHub: [@yangming9](https://github.com/yangming9)

## Support

If you encounter any issues or have questions, please open an issue on [GitHub](https://github.com/yangming9/database-common-tools/issues).
