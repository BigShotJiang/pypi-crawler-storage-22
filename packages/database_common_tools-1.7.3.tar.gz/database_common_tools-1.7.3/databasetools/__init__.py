"""
Database Common Tools

A Python library that makes it easier to work with message middleware and databases.
Supports Redis, MongoDB, MySQL, Kafka, and OpenSearch.
"""

__version__ = "1.6.9"
__author__ = "Coder Yang"
__email__ = "yma91412@gmail.com"

# Redis utilities
from .redis_connect import (
    rd_connect,
    rd_del,
    rd_expire,
    rd_set,
    rd_set_list,
    rd_get_zset,
    rd_get_list_len,
    rd_get_zset_len,
    dump_docs_redis_set,
    dump_data_redis_set_list,
    dump_data_redis_set_zset,
)

# MongoDB utilities
from .mongo_connect import (
    mongo_conn,
    mongo_conn_try,
    mongo_find_gt,
    mongo_find_gte,
    mongo_find_in,
    mongo_find_all,
    mongo_find_query,
)

# Kafka utilities
from .kafka_connect import kafka_consumer

# JSON analysis utilities
from .analysis_json_v2 import (
    dump_doc_field_str,
    dump_doc_field_array,
    dump_doc_field_object,
)

# Data analysis utilities
from .data_analysis_v2 import doc_fields_analysis

# Field mapping utilities (new, recommended)
from .field_mapper import FieldMapper, extract_fields

# Message utilities
from .mt_wx_message import sendErrorMessage

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__email__",
    # Redis functions
    "rd_connect",
    "rd_del",
    "rd_expire",
    "rd_set",
    "rd_set_list",
    "rd_get_zset",
    "rd_get_list_len",
    "rd_get_zset_len",
    "dump_docs_redis_set",
    "dump_data_redis_set_list",
    "dump_data_redis_set_zset",
    # MongoDB functions
    "mongo_conn",
    "mongo_conn_try",
    "mongo_find_gt",
    "mongo_find_gte",
    "mongo_find_in",
    "mongo_find_all",
    "mongo_find_query",
    # Kafka functions
    "kafka_consumer",
    # JSON analysis functions
    "dump_doc_field_str",
    "dump_doc_field_array",
    "dump_doc_field_object",
    # Data analysis functions
    "doc_fields_analysis",
    # Field mapping functions (new, recommended)
    "FieldMapper",
    "extract_fields",
    # Message functions
    "sendErrorMessage",
]
