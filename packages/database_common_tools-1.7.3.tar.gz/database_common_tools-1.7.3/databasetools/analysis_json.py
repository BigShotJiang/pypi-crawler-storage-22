# -*- coding: utf-8 -*-
"""JSON field extraction and analysis utilities (legacy version)."""

import json
from typing import Any, Tuple, List, Set
import jsonpath


def dump_doc_field_array(doc: dict, path: str, value: Any) -> Tuple[bool, Any]:
    """
    Extract array field from document using JSONPath.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    status = False
    if isinstance(values, list):
        _values: Set[str] = set()
        for _value in values:
            if isinstance(_value, (int, str, dict)):
                _values.add(str(_value))
        status = len(_values) > 0
        return status, json.dumps(list(_values), ensure_ascii=False)
    return status, value


def dump_doc_field_value_max(doc: dict, path: str, value: Any) -> Any:
    """
    Extract maximum value from array field using JSONPath.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails

    Returns:
        Maximum value as string, or default value
    """
    values = jsonpath.jsonpath(doc, path)
    if isinstance(values, list):
        _max = 0
        for _value in values:
            if isinstance(_value, (float, int)):
                _max = _value if _max < _value else _max
        return str(_max)
    return value


def dump_doc_field_str(doc: dict, path: str, value: Any) -> Tuple[bool, Any]:
    """
    Extract string field from document using JSONPath.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    status = False
    if isinstance(values, list) and len(values) == 1:
        if isinstance(values[0], (float, int, str)):
            status = len(values) > 0
            return status, str(values[0])
    return status, value


def dump_doc_field_object_to_list(
    doc: dict, path: str, value: Any, key: str
) -> Tuple[bool, Any]:
    """
    Extract object field from document and convert to list.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails
        key: Key to add to each object in the list

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    status = False
    if isinstance(values, list) and len(values) > 0:
        if isinstance(values[0], dict):
            _values: List[dict] = []
            for _key, doc_item in values[0].items():
                doc_item[key] = _key
                _values.append(doc_item)
            status = len(_values) > 0
            return status, json.dumps(list(_values), ensure_ascii=False)
    return status, value
