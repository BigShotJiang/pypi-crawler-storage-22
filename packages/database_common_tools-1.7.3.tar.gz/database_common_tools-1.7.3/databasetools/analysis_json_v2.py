# -*- coding: utf-8 -*-
"""JSON field extraction and analysis utilities."""

import json
import jsonpath
from typing import Any, Tuple, List, Union


def dump_doc_field_array(doc: dict, path: str, value: Any) -> Tuple[bool, Union[str, Any]]:
    """
    Extract array field from document using JSONPath.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    if isinstance(values, list):
        values = json.dumps(list(values), ensure_ascii=False)
        return True, values
    return False, value


def dump_doc_field_object(doc: dict, path: str, value: Any) -> Tuple[bool, Union[dict, Any]]:
    """
    Extract object field from document using JSONPath.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    if isinstance(values, list) and len(values) > 0:
        first_value = values[0]
        if isinstance(first_value, dict):
            return True, first_value
    return False, value


def dump_doc_field_str(doc: dict, path: str, value: Any) -> Tuple[bool, Union[str, Any]]:
    """
    Extract string field from document using JSONPath.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    if isinstance(values, list) and len(values) == 1:
        first_value = values[0]
        if isinstance(first_value, (float, int, str)):
            return True, str(first_value)
    return False, value


def dump_doc_field_type(
    doc: dict, path: str, value: Any, to_type: type
) -> Tuple[bool, Union[Any, Any]]:
    """
    Extract field from document and convert to specified type.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails
        to_type: Type to convert the extracted value to

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    if isinstance(values, list) and len(values) == 1:
        first_value = values[0]
        if isinstance(first_value, (float, int, str)):
            return True, to_type(first_value)
    return False, value


def dump_doc_field_type2array(
    doc: dict, path: str, value: Any, to_type: type
) -> Tuple[bool, Union[List[Any], Any]]:
    """
    Extract field from document, split by comma, and convert to array of specified type.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails
        to_type: Type to convert each element to

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    if isinstance(values, list) and len(values) == 1:
        first_value = values[0]
        if isinstance(first_value, (float, int, str)):
            array = [to_type(x) for x in str(first_value).split(',')]
            return True, array
    return False, value
