# -*- coding: utf-8 -*-
"""JSON field extraction and analysis utilities (v3 with boolean support)."""

import json
from typing import Any, Tuple, List, Optional
import jsonpath


def dump_doc_field_array(doc: dict, path: str, value: Any) -> Tuple[bool, Any]:
    """
    Extract array field from document using JSONPath.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    status = False
    if isinstance(values, list):
        status = len(values) > 0
        return status, values
    return status, value


def dump_doc_field_object(doc: dict, path: str, value: Any) -> Tuple[bool, Any]:
    """
    Extract object field from document using JSONPath.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    status = False
    if isinstance(values, list) and len(values) > 0:
        first_value = values[0]
        if isinstance(first_value, dict):
            status = True
            return status, first_value
    return status, value


def dump_doc_field_str(doc: dict, path: str, value: Any) -> Tuple[bool, Any]:
    """
    Extract string field from document using JSONPath.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    status = False
    if isinstance(values, list) and len(values) == 1:
        if isinstance(values[0], (float, int, str, dict, list, bool)):
            status = len(values) > 0
            return status, str(values[0])
    return status, value


def dump_doc_field_type(
    doc: dict, path: str, value: Any, to_type: type
) -> Tuple[bool, Any]:
    """
    Extract field from document and convert to specified type.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails
        to_type: Type to convert the extracted value to

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    status = False
    if isinstance(values, list) and len(values) == 1:
        if isinstance(values[0], (float, int, str, dict, list, bool)):
            status = len(values) > 0
            try:
                return status, to_type(values[0])
            except Exception:
                return status, value
    return status, value


def dump_doc_field_type2array(
    doc: dict, path: str, value: Any, to_type: type
) -> Tuple[bool, Any]:
    """
    Extract field from document, split by comma, and convert to array of specified type.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        value: Default value to return if extraction fails
        to_type: Type to convert each element to

    Returns:
        Tuple of (success_status, extracted_value_or_default)
    """
    values = jsonpath.jsonpath(doc, path)
    status = False
    if isinstance(values, list) and len(values) == 1:
        if isinstance(values[0], (float, int, str, dict, list, bool)):
            array = [to_type(x) for x in str(values[0]).split(',') if x.strip()]
            status = len(values) > 0
            return status, array
    return status, value


def dump_doc_field_bool(
    doc: dict,
    path: str,
    default: bool,
    true_values: Optional[List[Any]] = None,
) -> Tuple[bool, bool]:
    """
    Extract boolean field from document using JSONPath.

    Args:
        doc: Document dictionary to extract from
        path: JSONPath expression
        default: Default value to return if extraction fails
        true_values: List of values to consider as True. Defaults to [True, "true", "1", "yes", 1]

    Returns:
        Tuple of (success_status, extracted_boolean_value_or_default)
    """
    if true_values is None:
        true_values = [True, "true", "1", "yes", 1]

    values = jsonpath.jsonpath(doc, path)
    if isinstance(values, list) and len(values) == 1:
        field_value = values[0]
        is_true = field_value in true_values
        return True, is_true
    return False, default
