# -*- coding: utf-8 -*-
"""Common utility functions (legacy version)."""

import hashlib
import json
import logging
from datetime import datetime
from logging import handlers
from typing import Any, Dict, List
import bson.json_util
import requests


class CommonUtils:
    """Common utility functions for file operations, time conversion, and HTTP requests."""

    @staticmethod
    def dump_load(fn: str, log: Any) -> Dict[str, Any]:
        """
        Load JSON data from a file.

        Args:
            fn: File path
            log: Logger instance

        Returns:
            Dictionary containing loaded JSON data
        """
        with open(fn, 'r') as f:
            try:
                jmap = json.loads(f.read())
                return dict(jmap)
            except Exception as e:
                log.error('exception ... {}\tfile={}'.format(e, fn))
                return {}

    @staticmethod
    def dump_loads(value: str, log: Any) -> Dict[str, Any]:
        """
        Load BSON JSON data from a string.

        Args:
            value: JSON string
            log: Logger instance

        Returns:
            Dictionary containing loaded data
        """
        try:
            return bson.json_util.loads(value)
        except Exception as e:
            log.error('exception ... {}\tvalue={}'.format(e, value))
            return {}

    @staticmethod
    def unix_to_formatted_time(unix_timestamp: float) -> str:
        """
        Convert Unix timestamp to formatted time string.

        Args:
            unix_timestamp: Unix timestamp in seconds

        Returns:
            Formatted time string in format '%Y-%m-%d %H:%M:%S'
        """
        dt_object = datetime.fromtimestamp(unix_timestamp)
        formatted_time = dt_object.strftime('%Y-%m-%d %H:%M:%S')
        return formatted_time

    @staticmethod
    def get_unix_time(time_str: str) -> int:
        """
        Convert formatted time string to Unix timestamp.

        Args:
            time_str: Formatted time string in format '%Y-%m-%d %H:%M:%S' or '%Y-%m-%d'

        Returns:
            Unix timestamp in seconds, or 0 if conversion fails
        """
        if time_str:
            try:
                dt_obj = datetime.strptime(str(time_str), "%Y-%m-%d %H:%M:%S")
                unix_timestamp = int(dt_obj.timestamp())
                return unix_timestamp
            except ValueError:
                try:
                    dt_obj = datetime.strptime(str(time_str), "%Y-%m-%d")
                    unix_timestamp = int(dt_obj.timestamp())
                    return unix_timestamp
                except ValueError:
                    return 0
        else:
            return 0

    @staticmethod
    def image_exists_get(url: str, log: Any, timeout: int = 10, max_retries: int = 3) -> bool:
        """
        Check if an image exists at the given URL using GET request.

        Args:
            url: Image URL
            log: Logger instance
            timeout: Timeout for the request in seconds
            max_retries: Maximum number of retries

        Returns:
            True if image exists, False otherwise
        """
        attempt = 0
        while attempt < max_retries:
            try:
                response = requests.get(url, timeout=timeout)
                if response.status_code == 200:
                    return True
                else:
                    return False
            except requests.RequestException as e:
                log.error('Check image exist error: {}'.format(e))
            attempt += 1
        return False

    @staticmethod
    def image_exists_head(url: str, log: Any, timeout: int = 10, max_retries: int = 3) -> bool:
        """
        Check if an image exists at the given URL using HEAD request.

        Args:
            url: Image URL
            log: Logger instance
            timeout: Timeout for the request in seconds
            max_retries: Maximum number of retries

        Returns:
            True if image exists, False otherwise
        """
        attempt = 0
        while attempt < max_retries:
            try:
                response = requests.head(url, timeout=timeout)
                if response.status_code == 200:
                    return True
                else:
                    return False
            except requests.RequestException as e:
                log.error('Check image exist error: {}'.format(e))
            attempt += 1
        return False

    @staticmethod
    def parse_sql_result(cursor: Any) -> List[Dict[str, Any]]:
        """
        Parse SQL result from a cursor object and return as list of dictionaries.

        Args:
            cursor: SQL cursor object

        Returns:
            List of dictionaries with column names as keys
        """
        columns = [col[0] for col in cursor.description]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]

    @staticmethod
    def setup_logging(
        log_file: str,
        time_unit: str = 'D',
        backup_count: int = 3,
        encoding: str = 'utf-8',
    ) -> logging.Logger:
        """
        Setup logging configuration.

        Args:
            log_file: Path to the log file
            time_unit: Time unit for rotation
            backup_count: Number of backup files to keep
            encoding: File encoding

        Returns:
            Logger instance
        """
        log_format = logging.Formatter('%(asctime)s - %(levelname)s: %(message)s')
        handler = handlers.TimedRotatingFileHandler(
            filename=log_file,
            when=time_unit,
            backupCount=backup_count,
            encoding=encoding,
        )
        handler.setFormatter(log_format)
        logger = logging.getLogger(log_file)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        return logger

    @staticmethod
    def calculate_md5(input_str: str, log: Any) -> str:
        """
        Calculate MD5 hash value of input string.

        Args:
            input_str: Input string
            log: Logger instance

        Returns:
            32-character MD5 hexadecimal string
        """
        if isinstance(input_str, str):
            md5 = hashlib.md5()
            md5.update(input_str.encode())
            md5_hex = md5.hexdigest()
            md5_cleaned = ''.join(c for c in md5_hex if c.isalnum())
            return md5_cleaned[:32]
        else:
            log.error('input not str,please input type str!')
            return ''
