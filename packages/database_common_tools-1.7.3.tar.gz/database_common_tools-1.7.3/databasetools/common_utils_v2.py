# -*- coding: utf-8 -*-
"""Common utility functions with date manipulation and formatting."""

import hashlib
import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Union
import bson.json_util
import requests


class CommonUtils:
    """Common utility functions with date formatting constants."""
    FORMAT_ISO = "%Y-%m-%d"  # 2024-11-25
    FORMAT_ISO_DATETIME = "%Y-%m-%d %H:%M:%S"  # 2024-11-25 15:30:00
    FORMAT_SLASH = "%Y/%m/%d"  # 2024/11/25
    FORMAT_COMPACT = "%Y%m%d"  # 20241125
    FORMAT_CHINESE = "%Y年%m月%d日"  # 2024年11月25日
    FORMAT_US = "%m/%d/%Y"  # 11/25/2024
    FORMAT_MONTH_DAY = "%m-%d"  # 11-25
    FORMAT_YEAR_MONTH = "%Y-%m"  # 2024-11

    # Date format constants
    FORMAT_ISO = "%Y-%m-%d"  # 2024-11-25
    FORMAT_ISO_DATETIME = "%Y-%m-%d %H:%M:%S"  # 2024-11-25 15:30:00
    FORMAT_SLASH = "%Y/%m/%d"  # 2024/11/25
    FORMAT_COMPACT = "%Y%m%d"  # 20241125
    FORMAT_CHINESE = "%Y年%m月%d日"  # 2024年11月25日
    FORMAT_US = "%m/%d/%Y"  # 11/25/2024
    FORMAT_MONTH_DAY = "%m-%d"  # 11-25
    FORMAT_YEAR_MONTH = "%Y-%m"  # 2024-11

    def __init__(self, log: Any):
        """
        Initialize CommonUtils instance.

        Args:
            log: Logger instance
        """
        self.log = log

    def dump_load(self, fn: str) -> Dict[str, Any]:
        """
        Load JSON data from a file.

        Args:
            fn: File path

        Returns:
            Dictionary containing loaded JSON data
        """
        with open(fn, 'r') as f:
            try:
                jmap = json.loads(f.read())
                return dict(jmap)
            except Exception as e:
                self.log.error('exception ... {}\tfile={}'.format(e, fn))
                return {}

    def dump_loads(self, value: str) -> Dict[str, Any]:
        """
        Load BSON JSON data from a string.

        Args:
            value: JSON string

        Returns:
            Dictionary containing loaded data
        """
        try:
            return bson.json_util.loads(value)
        except Exception as e:
            self.log.error('exception ... {}\tvalue={}'.format(e, value))
            return {}

    def unix_to_formatted_time(self, unix_timestamp: float) -> str:
        """
        Convert Unix timestamp to formatted time string.

        Args:
            unix_timestamp: Unix timestamp in seconds

        Returns:
            Formatted time string in format '%Y-%m-%d %H:%M:%S'
        """
        dt_object = datetime.fromtimestamp(unix_timestamp)
        formatted_time = dt_object.strftime('%Y-%m-%d %H:%M:%S')
        return formatted_time
    
    def unix_to_formatted_datetime(
        self, unix_timestamp: float, tz: timezone = timezone.utc
    ) -> datetime:
        """
        Convert Unix timestamp to datetime object without microseconds.

        Args:
            unix_timestamp: Unix timestamp in seconds
            tz: Timezone (default: UTC)

        Returns:
            Datetime object without microseconds
        """
        dt_object_utc = datetime.fromtimestamp(unix_timestamp, tz=tz).replace(microsecond=0)
        return dt_object_utc
    
    def unix_to_formatted_datetime_hours(
        self,
        unix_timestamp: float,
        tz: timezone = timezone.utc,
        hours_to_add: int = 0,
    ) -> datetime:
        """
        Convert Unix timestamp to datetime object without microseconds, with optional hour offset.

        Args:
            unix_timestamp: Unix timestamp in seconds
            tz: Timezone (default: UTC)
            hours_to_add: Hours to add to the datetime

        Returns:
            Datetime object without microseconds
        """
        dt_object_utc = datetime.fromtimestamp(unix_timestamp, tz=tz).replace(microsecond=0)
        if hours_to_add != 0:
            dt_object_utc += timedelta(hours=hours_to_add)
        return dt_object_utc
    
    def get_unix_time(self, time_str: str) -> int:
        """
        Convert formatted time string to Unix timestamp.

        Args:
            time_str: Formatted time string in format '%Y-%m-%d %H:%M:%S' or '%Y-%m-%d'

        Returns:
            Unix timestamp in seconds, or 0 if conversion fails
        """
        if time_str:
            try:
                dt_obj = datetime.strptime(str(time_str), "%Y-%m-%d %H:%M:%S")
                unix_timestamp = int(dt_obj.timestamp())
                return unix_timestamp
            except ValueError as e:
                try:
                    dt_obj = datetime.strptime(str(time_str), "%Y-%m-%d")
                    unix_timestamp = int(dt_obj.timestamp())
                    return unix_timestamp
                except ValueError as e:
                    return 0
        else:
            return 0
    
    def image_exists_get(self, url: str, timeout: int = 10, max_retries: int = 3) -> bool:
        """
        Check if an image exists at the given URL using GET request.

        Args:
            url: Image URL
            timeout: Timeout for the request in seconds
            max_retries: Maximum number of retries

        Returns:
            True if image exists, False otherwise
        """
        attempt = 0
        while attempt < max_retries:
            try:
                response = requests.get(url, timeout=timeout)
                if response.status_code == 200:
                    return True
                else:
                    return False
            except requests.RequestException as e:
                self.log.error('Check image exist error: '.format(e))
            attempt += 1
        return False

    def image_exists_head(self, url: str, timeout: int = 10, max_retries: int = 3) -> bool:
        """
        Check if an image exists at the given URL using HEAD request.

        Args:
            url: Image URL
            timeout: Timeout for the request in seconds
            max_retries: Maximum number of retries

        Returns:
            True if image exists, False otherwise
        """
        attempt = 0
        while attempt < max_retries:
            try:
                response = requests.head(url, timeout=timeout)
                if response.status_code == 200:
                    return True
                else:
                    return False
            except requests.RequestException as e:
                self.log.error('Check image exist error: '.format(e))
            attempt += 1
        return False

    def parse_sql_result(self, cursor: Any) -> List[Dict[str, Any]]:
        """
        Parse SQL result from a cursor object and return as list of dictionaries.

        Args:
            cursor: SQL cursor object

        Returns:
            List of dictionaries with column names as keys
        """
        columns = [col[0] for col in cursor.description]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]
    
    def calculate_md5(self, input_str: Any) -> Optional[str]:
        """
        Calculate MD5 hash value of input string.

        Args:
            input_str: Input string (non-str will cause None return and log error)

        Returns:
            32-character MD5 hexadecimal string, or None if input is not a string
        """
        if isinstance(input_str, str):
            md5 = hashlib.md5()
            md5.update(input_str.encode())
            md5_hex = md5.hexdigest()
            md5_cleaned = ''.join(c for c in md5_hex if c.isalnum())
            return md5_cleaned[:32]
        else:
            self.log.error('input not str,please input type str!')
            return None

    def get_time_threshold(self, time_unit: str, interval: int) -> Optional[datetime]:
        """
        Calculate time threshold based on time unit and interval.

        Args:
            time_unit: Time unit ('minutes', 'hours', 'days')
            interval: Time interval

        Returns:
            Calculated datetime threshold, or None if invalid time unit
        """
        current_time = datetime.now(timezone.utc).replace(microsecond=0)

        if time_unit == 'minutes':
            time_threshold = current_time - timedelta(minutes=interval)
        elif time_unit == 'hours':
            time_threshold = current_time - timedelta(hours=interval)
        elif time_unit == 'days':
            time_threshold = current_time - timedelta(days=interval)
        else:
            self.log.error("Unsupported time unit. Use 'minutes', 'hours' or 'days'.")
            return None

        return time_threshold

    @staticmethod
    def get_envs_from_file(file_path: str = "/etc/environment") -> Dict[str, str]:
        """
        Read environment variables from a file.

        Args:
            file_path: Path to environment file

        Returns:
            Dictionary of environment variables
        """
        envs = {}
        with open(file_path) as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    envs[k] = v
        return envs

    def get_env(self, env_name: str, file_path: str = "/etc/environment") -> Optional[str]:
        """
        Get a specific environment variable from a file.

        Args:
            env_name: Environment variable name
            file_path: Path to environment file

        Returns:
            Environment variable value, or None if not found
        """
        envs = self.get_envs_from_file(file_path)
        return envs.get(env_name)

    def get_days_ago(
        self,
        n: int,
        date_format: str = "%Y-%m-%d",
        from_date: Any = None,
        from_date_format: Optional[str] = None,
    ) -> str:
        """
        Get date n days ago (or in the future if n is negative).

        Args:
            n: Number of days (positive for past, negative for future)
            date_format: Return date format (default: "%Y-%m-%d")
            from_date: Start date (string or datetime), defaults to today
            from_date_format: Format of from_date if it's a string

        Returns:
            Formatted date string

        Examples:
            >>> get_days_ago(7)  # 7 days ago
            '2024-11-18'
            >>> get_days_ago(7, "%Y/%m/%d")  # Custom format
            '2024/11/18'
            >>> get_days_ago(-3)  # 3 days in future
            '2024-11-28'
        """
        if from_date is None:
            base_date = datetime.now()
        elif isinstance(from_date, datetime):
            base_date = from_date
        elif isinstance(from_date, str):
            if from_date_format is None:
                for fmt in ["%Y-%m-%d", "%Y/%m/%d", "%Y%m%d", "%Y-%m-%d %H:%M:%S"]:
                    try:
                        base_date = datetime.strptime(from_date, fmt)
                        break
                    except ValueError:
                        continue
                else:
                    raise ValueError(
                        f"Cannot parse date '{from_date}', please specify from_date_format"
                    )
            else:
                base_date = datetime.strptime(from_date, from_date_format)
        else:
            raise TypeError("from_date must be str or datetime object")

        target_date = base_date - timedelta(days=n)
        return target_date.strftime(date_format)

    def get_date_range(
        self,
        start_days_ago: int,
        end_days_ago: int = 0,
        date_format: str = "%Y-%m-%d",
        from_date: Optional[Union[str, datetime]] = None,
    ) -> List[str]:
        """
        Get a range of dates.

        Args:
            start_days_ago: Start days ago (from today)
            end_days_ago: End days ago (from today), default 0 (today)
            date_format: Date format
            from_date: Start date

        Returns:
            List of date strings

        Examples:
            >>> get_date_range(7)  # Last 7 days
            ['2024-11-18', '2024-11-19', ..., '2024-11-25']
        """
        dates = []
        for i in range(start_days_ago, end_days_ago - 1, -1):
            dates.append(self.get_days_ago(i, date_format, from_date))
        return dates

    def get_multiple_dates(
        self,
        days_list: List[int],
        date_format: str = "%Y-%m-%d",
        from_date: Optional[Union[str, datetime]] = None,
    ) -> Dict[int, str]:
        """
        Get multiple dates in batch.

        Args:
            days_list: List of days
            date_format: Date format
            from_date: Start date

        Returns:
            Dictionary mapping days to date strings

        Examples:
            >>> get_multiple_dates([1, 7, 30])
            {1: '2024-11-24', 7: '2024-11-18', 30: '2024-10-26'}
        """
        return {
            days: self.get_days_ago(days, date_format, from_date) for days in days_list
        }

    def yesterday(self, date_format: str = None) -> str:
        """
        Get yesterday's date.

        Args:
            date_format: Date format

        Returns:
            Yesterday's date string
        """
        if date_format is None:
            date_format = self.FORMAT_ISO
        return self.get_days_ago(1, date_format)

    def last_week(self, date_format: str = None) -> str:
        """
        Get last week's same day date.

        Args:
            date_format: Date format

        Returns:
            Last week's date string
        """
        if date_format is None:
            date_format = self.FORMAT_ISO
        return self.get_days_ago(7, date_format)

    def last_month(self, date_format: str = None) -> str:
        """
        Get last month's same day date (approximately 30 days).

        Args:
            date_format: Date format

        Returns:
            Last month's date string
        """
        if date_format is None:
            date_format = self.FORMAT_ISO
        return self.get_days_ago(30, date_format)

    def tomorrow(self, date_format: str = None) -> str:
        """
        Get tomorrow's date.

        Args:
            date_format: Date format

        Returns:
            Tomorrow's date string
        """
        if date_format is None:
            date_format = self.FORMAT_ISO
        return self.get_days_ago(-1, date_format)

    def last_n_days(self, n: int, date_format: str = None) -> List[str]:
        """
        Get list of last n days (including today).

        Args:
            n: Number of days
            date_format: Date format

        Returns:
            List of date strings
        """
        if date_format is None:
            date_format = self.FORMAT_ISO
        return self.get_date_range(n - 1, 0, date_format)

    def is_video_content_type(self, url: str, timeout: int = 3) -> bool:
        """
        Check if URL returns a video Content-Type header.

        Args:
            url: URL to check
            timeout: Request timeout in seconds

        Returns:
            True if Content-Type starts with "video/", else False
        """
        try:
            resp = requests.head(url, allow_redirects=True, timeout=timeout)
            ct = resp.headers.get("Content-Type", "").lower()
            return ct.startswith("video/")
        except Exception:
            return False

    def is_mp4_magic(self, url: str, timeout: int = 3) -> bool:
        """
        Check if URL content has MP4 ftyp box (magic bytes).

        Args:
            url: URL to check
            timeout: Request timeout in seconds

        Returns:
            True if response contains ftyp box, else False
        """
        try:
            headers = {"Range": "bytes=0-31"}
            resp = requests.get(url, headers=headers, timeout=timeout)
            # MP4 必须包含 ftyp box
            return b"ftyp" in resp.content
        except Exception:
            return False

    def can_ingest_mp4(self, url: str) -> bool:
        """
        Check if URL can be ingested as MP4 (Content-Type video + ftyp magic).

        Args:
            url: URL to check

        Returns:
            True if both video content type and MP4 magic pass
        """
        if not self.is_video_content_type(url):
            return False
        if not self.is_mp4_magic(url):
            return False
        return True

# if __name__ == '__main__':
#     print("=" * 70)
#     print("CommonUtils 类使用示例")
#     print("=" * 70)
#
#     # 创建实例
#     utils = CommonUtils()
#     print(f"\n当前实例: {utils}")
#
#     # 示例1: 基础用法
#     print("\n" + "=" * 70)
#     print("1. 基础用法")
#     print("=" * 70)
#     print(f"今天:             {utils.today()}")
#     print(f"昨天:             {utils.yesterday()}")
#     print(f"7天前:            {utils.get_days_ago(7)}")
#     print(f"3天后:            {utils.get_days_ago(-3)}")
#     print(f"上周今日:         {utils.last_week()}")
#     print(f"上月今日:         {utils.last_month()}")
#
#     # 示例2: 不同格式
#     print("\n" + "=" * 70)
#     print("2. 不同的日期格式")
#     print("=" * 70)
#     date = utils.get_days_ago(7)
#     print(f"ISO格式:          {utils.get_days_ago(7, CommonUtils.FORMAT_ISO)}")
#     print(f"斜杠格式:         {utils.get_days_ago(7, CommonUtils.FORMAT_SLASH)}")
#     print(f"紧凑格式:         {utils.get_days_ago(7, CommonUtils.FORMAT_COMPACT)}")
#     print(f"中文格式:         {utils.get_days_ago(7, CommonUtils.FORMAT_CHINESE)}")
#     print(f"美式格式:         {utils.get_days_ago(7, CommonUtils.FORMAT_US)}")
#
#     # 示例3: 日期范围
#     print("\n" + "=" * 70)
#     print("3. 获取日期范围")
#     print("=" * 70)
#     last_7 = utils.last_n_days(7)
#     print(f"最近7天: {last_7[0]} 至 {last_7[-1]}")
#     print(f"详细列表: {last_7}")
#
#     next_3 = utils.next_n_days(3)
#     print(f"\n未来3天: {next_3[0]} 至 {next_3[-1]}")
#
#     # 示例4: 批量获取
#     print("\n" + "=" * 70)
#     print("4. 批量获取多个日期")
#     print("=" * 70)
#     dates_dict = utils.get_multiple_dates([1, 7, 30, 90])
#     for days, date in dates_dict.items():
#         print(f"{days:3d}天前: {date}")
#
#     # 示例5: 自定义起始日期
#     print("\n" + "=" * 70)
#     print("5. 从指定日期开始计算")
#     print("=" * 70)
#     custom_base = "2024-01-15"
#     print(f"基准日期: {custom_base}")
#     print(f"往前7天:  {utils.get_days_ago(7, from_date=custom_base)}")
#     print(f"往后7天:  {utils.get_days_ago(-7, from_date=custom_base)}")
#
#     # 示例6: 日期格式转换
#     print("\n" + "=" * 70)
#     print("6. 日期格式转换")
#     print("=" * 70)
#     original = "2024-11-25"
#     print(f"原始格式:         {original}")
#     print(f"转为中文:         {utils.format_date(original, DateUtils.FORMAT_CHINESE)}")
#     print(f"转为紧凑:         {utils.format_date(original, DateUtils.FORMAT_COMPACT)}")
#     print(f"转为美式:         {utils.format_date(original, DateUtils.FORMAT_US)}")
#
#     # 示例7: 日期计算
#     print("\n" + "=" * 70)
#     print("7. 日期差值计算")
#     print("=" * 70)
#     date1 = "2024-11-25"
#     date2 = "2024-11-18"
#     diff = utils.date_diff(date1, date2)
#     print(f"{date1} 和 {date2} 相差 {diff} 天")
#
#     # 示例8: 星期判断
#     print("\n" + "=" * 70)
#     print("8. 星期相关功能")
#     print("=" * 70)
#     print(f"今天是:           {utils.get_weekday_name(chinese=True)}")
#     print(f"今天是周末吗:     {utils.is_weekend()}")
#     print(f"2024-11-23 是:    {utils.get_weekday_name('2024-11-23', chinese=True)}")
#     print(f"2024-11-23 周末:  {utils.is_weekend('2024-11-23')}")
#
#     # 示例9: 时间戳操作
#     print("\n" + "=" * 70)
#     print("9. 时间戳相关操作（类方法）")
#     print("=" * 70)
#     print(f"当前时间:         {DateUtils.now()}")
#     print(f"当前时间戳(秒):   {DateUtils.now_timestamp()}")
#     print(f"当前时间戳(毫秒): {DateUtils.now_timestamp_ms()}")
#
#     timestamp = 1700000000
#     print(f"\n时间戳 {timestamp} 转日期: {DateUtils.from_timestamp(timestamp)}")
#
#     date_str = "2024-11-25"
#     print(f"日期 {date_str} 转时间戳: {DateUtils.to_timestamp(date_str)}")
#
#     # 示例10: 实际业务场景
#     print("\n" + "=" * 70)
#     print("10. 实际业务场景示例")
#     print("=" * 70)
#
#     # 场景1: 生成日志文件名
#     print("\n场景1: 生成日志文件名")
#     log_file = f"app_{utils.today(DateUtils.FORMAT_COMPACT)}.log"
#     print(f"  {log_file}")
#
#     # 场景2: 数据库查询条件
#     print("\n场景2: 构建数据库查询条件")
#     start_date = utils.get_days_ago(30)
#     end_date = utils.today()
#     print(f"  WHERE date BETWEEN '{start_date}' AND '{end_date}'")
#
#     # 场景3: 生成报表
#     print("\n场景3: 生成报表标题")
#     report_date = utils.yesterday(DateUtils.FORMAT_CHINESE)
#     weekday = utils.get_weekday_name(utils.yesterday(), chinese=True)
#     print(f"  《{report_date}（{weekday}）销售日报》")
#
#     # 场景4: API参数
#     print("\n场景4: 构建API查询参数")
#     params = {
#         'start_date': utils.get_days_ago(7),
#         'end_date': utils.today(),
#         'date_list': utils.last_n_days(3)
#     }
#     print(f"  {params}")
#
#     # 场景5: 批量处理文件
#     print("\n场景5: 批量处理最近7天的数据文件")
#     for date in utils.last_n_days(7):
#         filename = f"data_{date.replace('-', '')}.csv"
#         print(f"  处理文件: {filename}")
#
#     # 场景6: 使用自定义默认格式的实例
#     print("\n场景6: 创建使用中文格式的实例")
#     cn_utils = DateUtils(default_format=DateUtils.FORMAT_CHINESE)
#     print(f"  实例: {cn_utils}")
#     print(f"  今天: {cn_utils.today()}")
#     print(f"  昨天: {cn_utils.yesterday()}")
#
#     print("\n" + "=" * 70)
#     print("所有示例运行完成！")
#     print("=" * 70)
