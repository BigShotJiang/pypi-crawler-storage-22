# -*- coding: utf-8 -*-
"""Document field analysis utilities (legacy version)."""

from typing import Any, Dict, List, Tuple
import databasetools.analysis_json as analysis_json

# Field configuration constants
FLD = {
    'names': ['necessity', 'path', 'type', 'default', 'func', 'key', 'filter'],
    'types': ['string', 'array', 'object'],
    'value': [''],
    'funcs': ['object_to_list'],
}


def doc_fields_analysis(
    src_doc: Dict[str, Any],
    dest_doc: Dict[str, Any],
    mapping: Dict[str, Any],
) -> Tuple[bool, bool, List[str], bool, Dict[str, Any]]:
    """
    Analyze and map fields from source document to destination document.

    Args:
        src_doc: Source document dictionary
        dest_doc: Destination document dictionary (will be modified)
        mapping: Field mapping configuration

    Returns:
        Tuple of:
        - map_config_flag: True if mapping configuration is valid
        - field_error: True if required field is missing
        - error_keys: List of fields with errors
        - field_filter: True if field value doesn't match filter
        - dest_doc: Modified destination document
    """
    error_keys = []
    field_error = False
    field_filter = False
    for field, field_map in mapping.items():
        map_config_flag = True
        key_error = False
        necessity = field_map.get(FLD['names'][0], False)
        if isinstance(field_map, dict):
            path = field_map.get(FLD['names'][1], None)
            field_type = field_map.get(FLD['names'][2], FLD['types'][0])
            default_value = field_map.get(FLD['names'][3], FLD['value'][0])
            func = field_map.get(FLD['names'][4], FLD['value'][0])
            key = field_map.get(FLD['names'][5], FLD['value'][0])
            filter_value = field_map.get(FLD['names'][6], FLD['value'][0])
            if path:
                if FLD['types'][0] == field_type:
                    # init string
                    status, field_value = analysis_json.dump_doc_field_str(
                        src_doc, path, default_value
                    )
                    dest_doc[field] = field_value
                    if filter_value:
                        if field_value not in filter_value:
                            field_filter = True
                            break
                    if not status:
                        key_error = True
                elif FLD['types'][1] == field_type:
                    # init field array
                    status, field_value = analysis_json.dump_doc_field_array(
                        src_doc, path, default_value
                    )
                    dest_doc[field] = field_value
                    if not status:
                        key_error = True
                elif FLD['types'][2] == field_type:
                    if FLD['funcs'][0] == func:
                        # init field array
                        status, field_value = analysis_json.dump_doc_field_object_to_list(
                            src_doc, path, default_value, key
                        )
                        dest_doc[field] = field_value
                        if not status:
                            key_error = True
            else:
                map_config_flag = False
        if not necessity and key_error:
            error_keys.append(field)
        if necessity and key_error:
            field_error = key_error
            break
    return map_config_flag, field_error, error_keys, field_filter, dest_doc
