# -*- coding: utf-8 -*-
"""Document field analysis utilities (v3 with boolean and type conversion)."""

from typing import Any, Dict, List, Optional, Tuple, Type, Union
import databasetools.analysis_json_v3 as analysis_json_v3

# Field configuration constants
FLD = {
    'names': ['necessity', 'path', 'type', 'default', 'toType', 'true_values'],
    'types': ['string', 'array', 'object', 'type2array', 'toType', 'bool'],
    'value': ['', [], {}, False],
    'data_type': [int, float, str, list, bool],
}


def get_data_type(field_type: Union[str, Type]) -> Type:
    """
    Convert string type name to Python type.

    Args:
        field_type: Type name as string or Python type

    Returns:
        Python type
    """
    if isinstance(field_type, str):
        type_map = {
            'int': FLD['data_type'][0],
            'float': FLD['data_type'][1],
            'str': FLD['data_type'][2],
            'list': FLD['data_type'][3],
            'bool': FLD['data_type'][4],
        }
        return type_map.get(field_type, FLD['data_type'][2])
    return field_type


def doc_fields_analysis(
    src_doc: Dict[str, Any],
    dest_doc: Dict[str, Any],
    mapping: Dict[str, Any],
) -> Tuple[bool, bool, List[str], Dict[str, Any]]:
    """
    Analyze and map fields from source document to destination document.

    Args:
        src_doc: Source document dictionary
        dest_doc: Destination document dictionary (will be modified)
        mapping: Field mapping configuration

    Returns:
        Tuple of:
        - map_config_flag: True if mapping configuration is valid
        - field_error: True if required field is missing
        - error_keys: List of fields with errors
        - dest_doc: Modified destination document
    """
    map_config_flag = False
    error_keys = []
    field_error = False
    for field, field_map in mapping.items():
        map_config_flag = True
        key_error = False
        necessity = field_map.get(FLD['names'][0], False)
        if isinstance(field_map, dict):
            path = field_map.get(FLD['names'][1], None)
            field_type = field_map.get(FLD['names'][2], FLD['types'][0])
            to_type = field_map.get(FLD['names'][4], FLD['data_type'][2])
            to_type = get_data_type(to_type)
            true_values = field_map.get(FLD['names'][5], None)
            if path:
                if FLD['types'][0] == field_type:
                    # init string
                    default_value = field_map.get(FLD['names'][3], FLD['value'][0])
                    status, field_value = analysis_json_v3.dump_doc_field_str(
                        src_doc, path, default_value
                    )
                    dest_doc[field] = field_value
                    if not status:
                        key_error = True
                elif FLD['types'][1] == field_type:
                    # init field array
                    default_value = field_map.get(FLD['names'][3], FLD['value'][1])
                    status, field_value = analysis_json_v3.dump_doc_field_array(
                        src_doc, path, default_value
                    )
                    dest_doc[field] = field_value
                    if not status:
                        key_error = True
                elif FLD['types'][2] == field_type:
                    # init field object
                    default_value = field_map.get(FLD['names'][3], FLD['value'][2])
                    status, field_value = analysis_json_v3.dump_doc_field_object(
                        src_doc, path, default_value
                    )
                    dest_doc[field] = field_value
                    if not status:
                        key_error = True
                elif FLD['types'][3] == field_type:
                    # init field type2array
                    default_value = field_map.get(FLD['names'][3], FLD['value'][1])
                    status, field_value = analysis_json_v3.dump_doc_field_type2array(
                        src_doc, path, default_value, to_type
                    )
                    dest_doc[field] = field_value
                    if not status:
                        key_error = True
                elif FLD['types'][4] == field_type:
                    # init field toType
                    default_value = field_map.get(FLD['names'][3], FLD['value'][0])
                    status, field_value = analysis_json_v3.dump_doc_field_type(
                        src_doc, path, default_value, to_type
                    )
                    dest_doc[field] = field_value
                    if not status:
                        key_error = True
                elif FLD['types'][5] == field_type:
                    # init field bool
                    default_value = field_map.get(FLD['names'][3], FLD['value'][3])
                    status, field_value = analysis_json_v3.dump_doc_field_bool(
                        src_doc, path, default_value, true_values
                    )
                    dest_doc[field] = field_value
                    if not status:
                        key_error = True
            else:
                map_config_flag = False
        if not necessity and key_error:
            error_keys.append(field)
        if necessity and key_error:
            field_error = key_error
            break
    return map_config_flag, field_error, error_keys, dest_doc
