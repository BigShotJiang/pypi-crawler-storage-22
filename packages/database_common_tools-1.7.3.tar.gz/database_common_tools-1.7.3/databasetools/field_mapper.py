# -*- coding: utf-8 -*-
"""Field mapping utilities for JSONPath-based data extraction."""

from typing import Any, Dict, List, Optional, Tuple, Type, Union
from . import analysis_json_v3


class FieldMapper:
    """
    Field mapper for extracting and transforming data using JSONPath.

    This class provides a more user-friendly interface for field mapping
    compared to the low-level functions in data_analysis_v3.
    """

    # Supported field types
    TYPE_STRING = 'string'
    TYPE_ARRAY = 'array'
    TYPE_OBJECT = 'object'
    TYPE_TYPE2ARRAY = 'type2array'
    TYPE_TOTYPE = 'toType'
    TYPE_BOOL = 'bool'

    # Type mapping
    TYPE_MAP = {
        'int': int,
        'float': float,
        'str': str,
        'list': list,
        'bool': bool,
    }

    def __init__(self, mapping: Dict[str, Dict[str, Any]]):
        """
        Initialize field mapper with mapping configuration.

        Args:
            mapping: Field mapping configuration dictionary
                   Format: {
                       'field_name': {
                           'path': '$.jsonpath.expression',
                           'type': 'string',  # optional, default 'string'
                           'necessity': False,  # optional, default False
                           'default': '',  # optional
                           'toType': 'int',  # optional, for type conversion
                           'true_values': [True, "true", "1"],  # optional, for bool type
                       }
                   }
        """
        self.mapping = mapping
        self._validate_mapping()

    def _validate_mapping(self) -> None:
        """Validate mapping configuration."""
        for field_name, field_config in self.mapping.items():
            if not isinstance(field_config, dict):
                raise ValueError(f"Field '{field_name}' config must be a dictionary")
            if 'path' not in field_config:
                raise ValueError(f"Field '{field_name}' must have a 'path' key")

    def extract(
        self, source_doc: Dict[str, Any], strict: bool = False
    ) -> Tuple[bool, Dict[str, Any], List[str]]:
        """
        Extract fields from source document according to mapping configuration.

        Args:
            source_doc: Source document dictionary
            strict: If True, stop on first required field error

        Returns:
            Tuple of:
            - success: True if extraction successful (or non-strict mode)
            - result: Extracted document dictionary
            - errors: List of field names with errors
        """
        result = {}
        errors = []
        success = True

        for field_name, field_config in self.mapping.items():
            try:
                value = self._extract_field(source_doc, field_config)
                result[field_name] = value

                # Check if required field is missing
                if field_config.get('necessity', False) and value is None:
                    errors.append(field_name)
                    if strict:
                        success = False
                        break
            except Exception as e:
                errors.append(f"{field_name}: {str(e)}")
                if strict:
                    success = False
                    break

        return success, result, errors

    def _extract_field(
        self, source_doc: Dict[str, Any], field_config: Dict[str, Any]
    ) -> Any:
        """
        Extract a single field from source document.

        Args:
            source_doc: Source document dictionary
            field_config: Field configuration dictionary

        Returns:
            Extracted field value
        """
        path = field_config['path']
        field_type = field_config.get('type', self.TYPE_STRING)
        default_value = field_config.get('default', self._get_default_value(field_type))
        to_type = field_config.get('toType', None)
        true_values = field_config.get('true_values', None)

        # Convert string type name to Python type
        if to_type and isinstance(to_type, str):
            to_type = self.TYPE_MAP.get(to_type, str)

        # Extract based on field type
        if field_type == self.TYPE_STRING:
            status, value = analysis_json_v3.dump_doc_field_str(
                source_doc, path, default_value
            )
            return value if status else default_value

        elif field_type == self.TYPE_ARRAY:
            status, value = analysis_json_v3.dump_doc_field_array(
                source_doc, path, default_value
            )
            return value if status else default_value

        elif field_type == self.TYPE_OBJECT:
            status, value = analysis_json_v3.dump_doc_field_object(
                source_doc, path, default_value
            )
            return value if status else default_value

        elif field_type == self.TYPE_TYPE2ARRAY:
            if to_type is None:
                to_type = str
            status, value = analysis_json_v3.dump_doc_field_type2array(
                source_doc, path, default_value, to_type
            )
            return value if status else default_value

        elif field_type == self.TYPE_TOTYPE:
            if to_type is None:
                to_type = str
            status, value = analysis_json_v3.dump_doc_field_type(
                source_doc, path, default_value, to_type
            )
            return value if status else default_value

        elif field_type == self.TYPE_BOOL:
            status, value = analysis_json_v3.dump_doc_field_bool(
                source_doc, path, default_value, true_values
            )
            return value if status else default_value

        else:
            raise ValueError(f"Unsupported field type: {field_type}")

    def _get_default_value(self, field_type: str) -> Any:
        """Get default value based on field type."""
        defaults = {
            self.TYPE_STRING: '',
            self.TYPE_ARRAY: [],
            self.TYPE_OBJECT: {},
            self.TYPE_TYPE2ARRAY: [],
            self.TYPE_TOTYPE: '',
            self.TYPE_BOOL: False,
        }
        return defaults.get(field_type, '')

    @classmethod
    def from_config_file(cls, config_path: str, template_name: str = None) -> 'FieldMapper':
        """
        Create FieldMapper from configuration file.

        Args:
            config_path: Path to JSON configuration file
            template_name: Template name in config (if config has multiple templates)

        Returns:
            FieldMapper instance
        """
        import json
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

        if template_name:
            if template_name not in config:
                raise ValueError(f"Template '{template_name}' not found in config")
            mapping = config[template_name]['mapping']
        else:
            # Use first template if no name specified
            first_key = next(iter(config))
            mapping = config[first_key]['mapping']

        return cls(mapping)


def extract_fields(
    source_doc: Dict[str, Any],
    mapping: Dict[str, Dict[str, Any]],
    strict: bool = False,
) -> Tuple[bool, Dict[str, Any], List[str]]:
    """
    Convenience function for extracting fields from a document.

    Args:
        source_doc: Source document dictionary
        mapping: Field mapping configuration
        strict: If True, stop on first required field error

    Returns:
        Tuple of (success, result, errors)
    """
    mapper = FieldMapper(mapping)
    return mapper.extract(source_doc, strict)
