# -*- coding: utf-8 -*-
"""Logging utilities for single and multiprocessing environments."""

import logging
import sys
from logging import handlers
from multiprocessing import Process, Queue
from queue import Empty
from typing import Any, Tuple


class MultiprocessingLogHandler(logging.Handler):
    """Log handler that works across multiple processes using a queue."""

    def __init__(
        self,
        filename: str,
        mode: str = 'a',
        time_unit: str = 'D',
        backup_count: int = 3,
        encoding: str = 'utf-8',
    ):
        """
        Initialize multiprocessing log handler.

        Args:
            filename: Log file path
            mode: File open mode
            time_unit: Time unit for rotation ('D', 'H', 'M', etc.)
            backup_count: Number of backup files to keep
            encoding: File encoding
        """
        logging.Handler.__init__(self)
        self.queue = Queue(-1)
        self.handler = handlers.TimedRotatingFileHandler(
            filename,
            when=time_unit,
            backupCount=backup_count,
            encoding=encoding,
            delay=True,
        )
        self.handler.mode = mode
        self.handler.setFormatter(
            logging.Formatter('%(asctime)s - %(process)d - %(levelname)s: %(message)s')
        )
        self.listener = Process(target=self.listen)
        self.listener.start()

    def listen(self) -> None:
        """Listen for log records from the queue."""
        while True:
            try:
                record = self.queue.get(timeout=1)
                if record is None:
                    break
                self.handler.emit(record)
            except Empty:
                continue
            except Exception:
                print(sys.exc_info(), file=sys.stderr)

    def emit(self, record: logging.LogRecord) -> None:
        """
        Emit a log record to the queue.

        Args:
            record: Log record to emit
        """
        try:
            self.queue.put(record)
        except Exception:
            print(sys.exc_info(), file=sys.stderr)

    def close(self) -> None:
        """Close the handler and stop the listener process."""
        self.queue.put(None)
        self.listener.join()
        self.handler.close()
        logging.Handler.close(self)


def setup_logging(
    log_file: str,
    time_unit: str = 'D',
    backup_count: int = 3,
    encoding: str = 'utf-8',
) -> logging.Logger:
    """
    Setup logging configuration for single process.

    Args:
        log_file: Path to the log file
        time_unit: Time unit for rotation ('D', 'H', 'M', etc.)
        backup_count: Number of backup files to keep
        encoding: File encoding

    Returns:
        Logger instance
    """
    log_format = logging.Formatter('%(asctime)s - %(process)d - %(levelname)s: %(message)s')
    handler = handlers.TimedRotatingFileHandler(
        filename=log_file,
        when=time_unit,
        backupCount=backup_count,
        encoding=encoding,
        delay=True,
    )
    handler.setFormatter(log_format)
    logger = logging.getLogger(log_file)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    return logger


def setup_multiprocess_logging(
    log_file: str,
    mode: str = 'a',
    time_unit: str = 'D',
    backup_count: int = 3,
    encoding: str = 'utf-8',
) -> Tuple[logging.Logger, MultiprocessingLogHandler]:
    """
    Setup logging configuration for multiprocessing environment.

    Args:
        log_file: Path to the log file
        mode: File open mode
        time_unit: Time unit for rotation ('D', 'H', 'M', etc.)
        backup_count: Number of backup files to keep
        encoding: File encoding

    Returns:
        Tuple of (logger instance, handler instance)
    """
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    handler = MultiprocessingLogHandler(log_file, mode, time_unit, backup_count, encoding)
    logger.addHandler(handler)
    return logger, handler
