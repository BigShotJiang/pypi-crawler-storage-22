# -*- coding: utf-8 -*-
"""MongoDB connection and query utilities."""

import time
from typing import Any, Dict, List, Optional, Generator
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError
from pymongo import MongoClient, UpdateOne
from pymongo.collection import Collection
from pymongo.database import Database
from pymongo.cursor import Cursor


def mongo_bulk(collection: Collection, docs: Dict[str, Any]) -> Any:
    """
    Perform bulk write operations on a MongoDB collection.

    Args:
        collection: MongoDB collection object
        docs: Dictionary of documents to upsert (key is _id)

    Returns:
        BulkWriteResult object
    """
    datas = []
    for key, doc in docs.items():
        query = {'_id': key}
        bson = {'$set': doc}
        datas.append(UpdateOne(query, bson, upsert=True))
    return collection.bulk_write(datas)


def mongo_collection(database: Database, collection: str) -> Collection:
    """
    Get a MongoDB collection.

    Args:
        database: MongoDB database object
        collection: Collection name

    Returns:
        Collection object
    """
    return database[collection]


def mongo_collection_try(
    database: Database, collection: str, indexes: List[Any]
) -> Collection:
    """
    Get a MongoDB collection, creating it with indexes if it doesn't exist.

    Args:
        database: MongoDB database object
        collection: Collection name
        indexes: List of index specifications

    Returns:
        Collection object
    """
    if collection not in database.list_collection_names():
        for index in indexes:
            database[collection].create_index(index)
    return database[collection]


def mongo_connect(url: str) -> MongoClient:
    """
    Create a MongoDB client connection.

    Args:
        url: MongoDB connection URL

    Returns:
        MongoClient object
    """
    return MongoClient(url)


def mongo_database(connect: MongoClient, database: str) -> Database:
    """
    Get a MongoDB database.

    Args:
        connect: MongoDB client connection
        database: Database name

    Returns:
        Database object
    """
    return connect[database]


def mongo_find_gt(collection: Collection, key: str, value: Any) -> Cursor:
    """
    Find documents where field is greater than value.

    Args:
        collection: MongoDB collection object
        key: Field name
        value: Comparison value

    Returns:
        Cursor object
    """
    return collection.find({key: {'$gt': value}})


def mongo_find_gte(collection: Collection, key: str, value: Any) -> Cursor:
    """
    Find documents where field is greater than or equal to value.

    Args:
        collection: MongoDB collection object
        key: Field name
        value: Comparison value

    Returns:
        Cursor object
    """
    return collection.find({key: {'$gte': value}})


def mongo_find_in(collection: Collection, key: str, values: List[Any]) -> Cursor:
    """
    Find documents where field value is in the provided list.

    Args:
        collection: MongoDB collection object
        key: Field name
        values: List of values to match

    Returns:
        Cursor object
    """
    return collection.find({key: {'$in': values}})


def mongo_find_all(collection: Collection) -> Cursor:
    """
    Find all documents in a collection.

    Args:
        collection: MongoDB collection object

    Returns:
        Cursor object
    """
    return collection.find()


def mongo_find_query(collection: Collection, query: Dict[str, Any]) -> Cursor:
    """
    Find documents matching a query.

    Args:
        collection: MongoDB collection object
        query: Query dictionary

    Returns:
        Cursor object
    """
    return collection.find(query)


def mongo_find_query_v2(
    collection: Collection,
    query: Dict[str, Any],
    sort_field: Optional[str] = None,
    sort_order: int = 1,
    projection: Optional[Dict[str, Any]] = None,
    limit: Optional[int] = None,
) -> Cursor:
    """
    Find documents with optional sorting, projection, and limit.

    Args:
        collection: MongoDB collection object
        query: Query dictionary
        sort_field: Field name to sort by (optional)
        sort_order: Sort order (1 for ascending, -1 for descending)
        projection: Field projection dictionary (optional)
        limit: Maximum number of documents to return (optional)

    Returns:
        Cursor object
    """
    cursor = collection.find(query, projection)
    if sort_field:
        cursor = cursor.sort(sort_field, sort_order)
    if limit:
        cursor = cursor.limit(limit)
    return cursor


def mongo_find_query_v3(
    collection: Collection,
    query: Dict[str, Any],
    sort_field: Optional[str] = None,
    sort_order: int = 1,
    projection: Optional[Dict[str, Any]] = None,
    limit: Optional[int] = None,
    filter_query: Optional[Dict[str, Any]] = None,
) -> Cursor:
    """
    Find documents with optional sorting, projection, limit, and filter query.

    Args:
        collection: MongoDB collection object
        query: Query dictionary
        sort_field: Field name to sort by (optional)
        sort_order: Sort order (1 for ascending, -1 for descending)
        projection: Field projection dictionary (optional)
        limit: Maximum number of documents to return (optional)
        filter_query: Additional filter query to merge (optional)

    Returns:
        Cursor object
    """
    if filter_query:
        query.update(filter_query)
    cursor = collection.find(query, projection)
    if sort_field:
        cursor = cursor.sort(sort_field, sort_order)
    if limit:
        cursor = cursor.limit(limit)
    return cursor


def mongo_find_query_show(
    collection: Collection,
    query: Dict[str, Any] = None,
    show: Dict[str, Any] = None,
) -> Cursor:
    """
    Find documents with field projection.

    Args:
        collection: MongoDB collection object
        query: Query dictionary
        show: Projection dictionary

    Returns:
        Cursor object
    """
    if query is None:
        query = {}
    if show is None:
        show = {}
    return collection.find(query, show)


def mongo_find_page(collection: Collection, page: int, size: int) -> Cursor:
    """
    Find documents with pagination.

    Args:
        collection: MongoDB collection object
        page: Page number (1-indexed)
        size: Number of documents per page

    Returns:
        Cursor object
    """
    skip = (page - 1) * size
    return collection.find().skip(skip).limit(size)


def mongo_count_total(collection: Collection) -> int:
    """
    Count total documents in a collection.

    Args:
        collection: MongoDB collection object

    Returns:
        Total document count
    """
    return collection.count_documents({})


def mongo_count_total_query(
    collection: Collection, query: Dict[str, Any] = None
) -> int:
    """
    Count documents matching a query.

    Args:
        collection: MongoDB collection object
        query: Query dictionary

    Returns:
        Document count
    """
    if query is None:
        query = {}
    return collection.count_documents(query)


def mongo_find_start(collection: Collection, start: int, size: int) -> Cursor:
    """
    Find documents starting from a specific position.

    Args:
        collection: MongoDB collection object
        start: Starting position (skip value)
        size: Number of documents to return

    Returns:
        Cursor object
    """
    return collection.find().skip(start).limit(size)


def mongo_find_query_start(
    collection: Collection, query: Dict[str, Any], start: int, size: int
) -> Cursor:
    """
    Find documents matching a query starting from a specific position.

    Args:
        collection: MongoDB collection object
        query: Query dictionary
        start: Starting position (skip value)
        size: Number of documents to return

    Returns:
        Cursor object
    """
    return collection.find(query).skip(start).limit(size)


def mongo_find_query_filter_start(
    collection: Collection,
    query: Dict[str, Any],
    filter_dict: Dict[str, Any],
    start: int,
    size: int,
) -> Cursor:
    """
    Find documents with query and filter, starting from a specific position.

    Args:
        collection: MongoDB collection object
        query: Query dictionary
        filter_dict: Projection/filter dictionary
        start: Starting position (skip value)
        size: Number of documents to return

    Returns:
        Cursor object
    """
    return collection.find(query, filter_dict).skip(start).limit(size)


def future_query_collection(
    url: str, db: str, tb: str, query: Dict[str, Any], log: Any
) -> List[Dict[str, Any]]:
    """
    Query a MongoDB collection and return results as a list.

    Args:
        url: MongoDB connection URL
        db: Database name
        tb: Collection name
        query: Query dictionary
        log: Logger instance

    Returns:
        List of documents
    """
    start_time = time.time()
    con = mongo_conn(url, db, tb)
    result = list(mongo_find_query(con, query))
    end_time = time.time()
    elapsed_time = end_time - start_time
    log.info('Collection: {}, Query Time: {:.2f} seconds'.format(tb, elapsed_time))
    return result


def future_query_collection_v2(
    url: str,
    db: str,
    tb: str,
    query: Dict[str, Any],
    log: Any,
    sort_field: Optional[str] = None,
    sort_order: int = 1,
    projection: Optional[Dict[str, Any]] = None,
    limit: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """
    Query a MongoDB collection with advanced options and return results as a list.

    Args:
        url: MongoDB connection URL
        db: Database name
        tb: Collection name
        query: Query dictionary
        log: Logger instance
        sort_field: Field name to sort by (optional)
        sort_order: Sort order (1 for ascending, -1 for descending)
        projection: Field projection dictionary (optional)
        limit: Maximum number of documents to return (optional)

    Returns:
        List of documents
    """
    start_time = time.time()
    con = mongo_conn(url, db, tb)
    result = list(
        mongo_find_query_v2(con, query, sort_field, sort_order, projection, limit)
    )
    end_time = time.time()
    elapsed_time = end_time - start_time
    log.info('Collection: {}, Query Time: {:.2f} seconds'.format(tb, elapsed_time))
    return result


def parallel_query(
    url: str,
    db: str,
    query: Dict[str, Any],
    collection_names: List[str],
    log: Any,
    timeout: int = 3,
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Execute parallel queries across multiple MongoDB collections.

    Args:
        url: MongoDB connection URL
        db: Database name
        query: Query dictionary
        collection_names: List of collection names to query
        log: Logger instance
        timeout: Query timeout in seconds

    Returns:
        Dictionary mapping collection names to query results
    """
    results = {}
    with ThreadPoolExecutor(max_workers=10) as executor:
        future_to_collection = {
            executor.submit(future_query_collection, url, db, name, query, log): name
            for name in collection_names
        }
        for future in as_completed(future_to_collection):
            collection_name = future_to_collection[future]
            try:
                data = future.result(timeout=timeout)
                results[collection_name] = data
            except TimeoutError:
                log.error(
                    '{} query timed out after {} seconds'.format(
                        collection_name, timeout
                    )
                )
            except Exception as exc:
                log.error('{} generated an exception: {}'.format(collection_name, exc))
    return results


def parallel_query_v2(
    url: str,
    db: str,
    query: Dict[str, Any],
    collection_names: List[str],
    log: Any,
    sort_field: Optional[str] = None,
    sort_order: int = 1,
    projection: Optional[Dict[str, Any]] = None,
    limit: Optional[int] = None,
    timeout: int = 3,
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Execute parallel queries across multiple MongoDB collections with advanced options.

    Args:
        url: MongoDB connection URL
        db: Database name
        query: Query dictionary
        collection_names: List of collection names to query
        log: Logger instance
        sort_field: Field name to sort by (optional)
        sort_order: Sort order (1 for ascending, -1 for descending)
        projection: Field projection dictionary (optional)
        limit: Maximum number of documents to return (optional)
        timeout: Query timeout in seconds

    Returns:
        Dictionary mapping collection names to query results
    """
    results = {}
    with ThreadPoolExecutor(max_workers=10) as executor:
        future_to_collection = {
            executor.submit(
                future_query_collection_v2,
                url,
                db,
                name,
                query,
                log,
                sort_field,
                sort_order,
                projection,
                limit,
            ): name
            for name in collection_names
        }
        for future in as_completed(future_to_collection):
            collection_name = future_to_collection[future]
            try:
                data = future.result(timeout=timeout)
                results[collection_name] = data
            except TimeoutError:
                log.error(
                    '{} query timed out after {} seconds'.format(
                        collection_name, timeout
                    )
                )
            except Exception as exc:
                log.error('{} generated an exception: {}'.format(collection_name, exc))
    return results


def paginated_query(
    collection: Collection,
    query: Dict[str, Any] = None,
    field_show: Dict[str, Any] = None,
    page_size: int = 10,
) -> Generator[Dict[str, Any], None, None]:
    """
    High-performance paginated query using cursor-based pagination.

    Args:
        collection: MongoDB collection object
        query: Query dictionary (default: empty dict)
        field_show: Field projection dictionary (optional)
        page_size: Number of documents per page

    Yields:
        Documents one by one
    """
    if query is None:
        query = {}
    if field_show is None:
        field_show = {}

    if field_show:
        cursor = collection.find(query, field_show).limit(page_size)
    else:
        cursor = collection.find(query).limit(page_size)
    last_doc_id = None

    while True:
        if cursor.count() == 0:
            break

        for doc in cursor:
            yield doc

        if cursor.count() < page_size:
            break

        try:
            last_doc = list(cursor)[page_size - 1]
            last_doc_id = last_doc['_id']
            if field_show:
                cursor = (
                    collection.find({'_id': {'$gt': last_doc_id}}, field_show)
                    .limit(page_size)
                )
            else:
                cursor = collection.find({'_id': {'$gt': last_doc_id}}).limit(
                    page_size
                )
        except (IndexError, KeyError):
            break


def mongo_conn(url: str, db: str, tb: str) -> Collection:
    """
    Connect to a MongoDB collection.

    Args:
        url: MongoDB connection URL
        db: Database name
        tb: Collection name

    Returns:
        Collection object
    """
    return mongo_collection(mongo_database(mongo_connect(url), db), tb)


def mongo_conn_try(url: str, db: str, tb: str, ti: List[Any]) -> Collection:
    """
    Connect to a MongoDB collection, creating it with indexes if needed.

    Args:
        url: MongoDB connection URL
        db: Database name
        tb: Collection name
        ti: List of index specifications

    Returns:
        Collection object
    """
    return mongo_collection_try(mongo_database(mongo_connect(url), db), tb, ti)
