# -*- coding: utf-8 -*-
"""Process monitoring and management utilities."""

import time
from typing import List
from multiprocessing import Process


class ProcessWrapper:
    """Wrapper class for managing process creation and execution."""

    def __init__(self, target_func: callable, name: str, *args):
        """
        Initialize process wrapper.

        Args:
            target_func: Function to execute in the process
            name: Process name
            *args: Arguments to pass to the target function
        """
        self.target_func = target_func
        self.args = args
        self.name = name

    def create_process(self) -> Process:
        """
        Create a new process instance.

        Returns:
            Process instance
        """
        return Process(target=self.run, name=self.name)

    def run(self) -> None:
        """Execute the target function with provided arguments."""
        self.target_func(*self.args)


def monitor_processes(
    log: Any,
    process_wrapper_list: List[ProcessWrapper],
    process_list: List[Process],
    monitor_time_interval: int = 10,
) -> None:
    """
    Monitor and restart processes if they are not alive.

    Args:
        log: Logger instance
        process_wrapper_list: List of ProcessWrapper objects to monitor
        process_list: List of Process objects being monitored
        monitor_time_interval: Time interval between checks in seconds
    """
    while True:
        index = 0
        for process in process_list:
            if not process.is_alive():
                log.error(
                    'Process:{} with args:{} is not alive. Restarting...'.format(
                        process_wrapper_list[index].name,
                        process_wrapper_list[index].args,
                    )
                )
                new_process = process_wrapper_list[index].create_process()
                new_process.start()
                log.info(
                    'Started new process {} with PID {}'.format(
                        process_wrapper_list[index].name, new_process.pid
                    )
                )
                process_list[index] = new_process
            index = index + 1
        time.sleep(monitor_time_interval)
