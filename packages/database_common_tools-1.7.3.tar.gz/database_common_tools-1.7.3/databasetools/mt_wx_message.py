# -*- coding: utf-8 -*-
"""WeChat message sending utilities."""

import logging
from typing import Any, List, Union
import requests

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
LOG_FT = logging.Formatter('%(asctime)s - %(levelname)s: %(message)s')
CONSOLE_HANDLER = logging.StreamHandler()
CONSOLE_HANDLER.setFormatter(LOG_FT)


def send_error_message(
    receivers: Union[str, List[str]], subject: str, content: Any, url: str
) -> None:
    """
    Send error message via HTTP POST request.

    Args:
        receivers: Receiver email addresses (string or list)
        subject: Message subject
        content: Message content
        url: API endpoint URL
    """
    datas = {
        'receiver': receivers,
        'subject': subject,
        'content': str(content),
    }
    try:
        requests.post(url=url, data=datas)
    except Exception as e:
        LOG.error('{} exception ... {}\tvalue={}'.format(subject, e, datas))
