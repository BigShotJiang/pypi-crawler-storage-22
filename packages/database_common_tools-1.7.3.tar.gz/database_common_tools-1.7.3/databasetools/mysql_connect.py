# -*- coding: utf-8 -*-
"""MySQL database connection and query utilities (legacy version)."""

from typing import List, Dict, Any, Optional, Tuple
import pymysql


class MySQLConnector:
    """MySQL database connector with query utilities."""

    def __init__(
        self, host: str, port: int, user: str, password: str, database: str
    ):
        """
        Initialize MySQL connector.

        Args:
            host: MySQL server host
            port: MySQL server port
            user: MySQL username
            password: MySQL password
            database: Database name
        """
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        self.connection: Optional[pymysql.Connection] = None
        self.cursor: Optional[pymysql.cursors.Cursor] = None

    def connect(self) -> None:
        """Establish connection to MySQL database."""
        try:
            self.connection = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                port=self.port,
            )
            self.cursor = self.connection.cursor()
            print("Connected to MySQL database")
        except Exception as e:
            print("Error connecting to MySQL database:", e)
            raise

    def disconnect(self) -> None:
        """Close connection to MySQL database."""
        if self.connection and self.connection.open:
            if self.cursor:
                self.cursor.close()
            self.connection.close()
            print("Disconnected from MySQL database")

    def execute_query(self, query: str) -> List[Tuple]:
        """
        Execute a query and return results as tuples.

        Args:
            query: SQL query string

        Returns:
            List of tuples containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query)
            return self.cursor.fetchall()
        except Exception as e:
            print("Error executing query:", e)
            raise

    def execute_query_result_dict(self, query: str) -> List[Dict[str, Any]]:
        """
        Execute a query and return results as dictionaries.

        Args:
            query: SQL query string

        Returns:
            List of dictionaries containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query)
            column_names = [desc[0] for desc in self.cursor.description]
            rows = self.cursor.fetchall()
            return [dict(zip(column_names, row)) for row in rows]
        except Exception as e:
            print("Error executing query:", e)
            raise

    def execute_query_args(self, query: str, args: Tuple) -> List[Tuple]:
        """
        Execute a parameterized query and return results as tuples.

        Args:
            query: SQL query string with placeholders
            args: Tuple of arguments for the query

        Returns:
            List of tuples containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query, args)
            return self.cursor.fetchall()
        except Exception as e:
            print("Error executing query:", e)
            raise

    def execute_query_args_result_dict(
        self, query: str, args: Tuple
    ) -> List[Dict[str, Any]]:
        """
        Execute a parameterized query and return results as dictionaries.

        Args:
            query: SQL query string with placeholders
            args: Tuple of arguments for the query

        Returns:
            List of dictionaries containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query, args)
            column_names = [desc[0] for desc in self.cursor.description]
            rows = self.cursor.fetchall()
            return [dict(zip(column_names, row)) for row in rows]
        except Exception as e:
            print("Error executing query:", e)
            raise

    def execute_query_by_id_list(self, query: str, id_list: List) -> List[Tuple]:
        """
        Execute a query with a list of IDs and return results as tuples.

        Args:
            query: SQL query string
            id_list: List of IDs to use in the query

        Returns:
            List of tuples containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query, id_list)
            return self.cursor.fetchall()
        except Exception as e:
            print("Error executing query:", e)
            raise

    def execute_query_by_id_list_result_dict(
        self, query: str, id_list: List
    ) -> List[Dict[str, Any]]:
        """
        Execute a query with a list of IDs and return results as dictionaries.

        Args:
            query: SQL query string
            id_list: List of IDs to use in the query

        Returns:
            List of dictionaries containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query, id_list)
            column_names = [desc[0] for desc in self.cursor.description]
            rows = self.cursor.fetchall()
            return [dict(zip(column_names, row)) for row in rows]
        except Exception as e:
            print("Error executing query:", e)
            raise
