"""MySQL database connection and query utilities."""

import logging
from typing import List, Dict, Any, Optional, Tuple
import pymysql

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
LOG_FT = logging.Formatter('%(asctime)s - %(levelname)s: %(message)s')
CONSOLE_HANDLER = logging.StreamHandler()
CONSOLE_HANDLER.setFormatter(LOG_FT)


class MySQLConnector:
    """MySQL database connector with query utilities."""
    def __init__(
        self,
        host: str,
        port: int,
        user: str,
        password: str,
        database: str,
        log: logging.Logger,
    ):
        """
        Initialize MySQL connector.

        Args:
            host: MySQL server host
            port: MySQL server port
            user: MySQL username
            password: MySQL password
            database: Database name
            log: Logger instance
        """
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        self.log = log
        self.connection: Optional[pymysql.Connection] = None
        self.cursor: Optional[pymysql.cursors.Cursor] = None

    def connect(self) -> None:
        """Establish connection to MySQL database."""
        try:
            self.connection = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                port=self.port,
            )
            self.cursor = self.connection.cursor()
            self.log.info("Connected to MySQL database")
        except Exception as e:
            self.log.error("Error connecting to MySQL database: %s", e)
            raise

    def disconnect(self) -> None:
        """Close connection to MySQL database."""
        if self.connection and self.connection.open:
            if self.cursor:
                self.cursor.close()
            self.connection.close()
            self.log.info("Disconnected from MySQL database")

    def execute_query(self, query: str) -> List[Tuple]:
        """
        Execute a query and return results as tuples.

        Args:
            query: SQL query string

        Returns:
            List of tuples containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query)
            return self.cursor.fetchall()
        except Exception as e:
            self.log.error("Error executing query: %s", e)
            raise

    def execute_query_result_dict(self, query: str) -> List[Dict[str, Any]]:
        """
        Execute a query and return results as dictionaries.

        Args:
            query: SQL query string

        Returns:
            List of dictionaries containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query)
            column_names = [desc[0] for desc in self.cursor.description]
            rows = self.cursor.fetchall()
            return [dict(zip(column_names, row)) for row in rows]
        except Exception as e:
            self.log.error("Error executing query: %s", e)
            raise

    def execute_query_args(self, query: str, args: Tuple) -> List[Tuple]:
        """
        Execute a parameterized query and return results as tuples.

        Args:
            query: SQL query string with placeholders
            args: Tuple of arguments for the query

        Returns:
            List of tuples containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query, args)
            return self.cursor.fetchall()
        except Exception as e:
            self.log.error("Error executing query: %s", e)
            raise

    def execute_query_args_result_dict(
        self, query: str, args: Tuple
    ) -> List[Dict[str, Any]]:
        """
        Execute a parameterized query and return results as dictionaries.

        Args:
            query: SQL query string with placeholders
            args: Tuple of arguments for the query

        Returns:
            List of dictionaries containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query, args)
            column_names = [desc[0] for desc in self.cursor.description]
            rows = self.cursor.fetchall()
            return [dict(zip(column_names, row)) for row in rows]
        except Exception as e:
            self.log.error("Error executing query: %s", e)
            raise

    def execute_query_by_id_list(self, query: str, id_list: List) -> List[Tuple]:
        """
        Execute a query with a list of IDs and return results as tuples.

        Args:
            query: SQL query string
            id_list: List of IDs to use in the query

        Returns:
            List of tuples containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query, id_list)
            return self.cursor.fetchall()
        except Exception as e:
            self.log.error("Error executing query: %s", e)
            raise

    def execute_query_by_id_list_result_dict(
        self, query: str, id_list: List
    ) -> List[Dict[str, Any]]:
        """
        Execute a query with a list of IDs and return results as dictionaries.

        Args:
            query: SQL query string
            id_list: List of IDs to use in the query

        Returns:
            List of dictionaries containing query results
        """
        if not self.cursor:
            raise RuntimeError("Not connected to database. Call connect() first.")
        try:
            self.cursor.execute(query, id_list)
            column_names = [desc[0] for desc in self.cursor.description]
            rows = self.cursor.fetchall()
            return [dict(zip(column_names, row)) for row in rows]
        except Exception as e:
            self.log.error("Error executing query: %s", e)
            raise

# Example usage:
if __name__ == "__main__":
    # Initialize MySQLConnector object
    connector = MySQLConnector(
        host="localhost",
        port=3306,
        user="root",
        password="password",
        database="mydatabase",
        log=LOG,
    )

    # Connect to MySQL database
    connector.connect()

    # Example query
    query = "SELECT * FROM mytable LIMIT 10"

    # Execute query and print results
    result = connector.execute_query(query)
    print(result)

    # Disconnect from MySQL database
    connector.disconnect()
