# -*- coding: utf-8 -*-
"""OpenSearch/Elasticsearch connection and utility functions."""

import time
from typing import Any, Dict, List, Optional, Generator
from concurrent.futures import ThreadPoolExecutor, wait
from elasticsearch import Elasticsearch
from elasticsearch import helpers


def create_client(hosts: List[str], port: int) -> Elasticsearch:
    """
    Create an Elasticsearch client.

    Args:
        hosts: List of host addresses
        port: Port number

    Returns:
        Elasticsearch client instance
    """
    addrs = []
    for host in hosts:
        addr = {'host': host, 'port': port}
        addrs.append(addr)
    return Elasticsearch(addrs)


def create_client_auth(
    hosts: List[str],
    port: int,
    username: str,
    password: str,
    use_ssl: bool = False,
) -> Elasticsearch:
    """
    Create an Elasticsearch client with authentication.

    Args:
        hosts: List of host addresses
        port: Port number
        username: Username for authentication
        password: Password for authentication
        use_ssl: Whether to use HTTPS (default: False)

    Returns:
        Elasticsearch client instance with authentication
    """
    addrs = []
    scheme = "https" if use_ssl else "http"
    for host in hosts:
        addr = {'host': host, 'port': port, 'scheme': scheme}
        addrs.append(addr)

    return Elasticsearch(hosts=addrs, http_auth=(username, password), use_ssl=use_ssl)


def index_exists(es: Elasticsearch, index_name: str) -> bool:
    """
    Check if an index exists.

    Args:
        es: Elasticsearch client instance
        index_name: Name of the index

    Returns:
        True if index exists, False otherwise
    """
    return es.indices.exists(index=index_name)


def create_index(
    es: Elasticsearch, index_name: str, mapping: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Create an Elasticsearch index with mapping.

    Args:
        es: Elasticsearch client instance
        index_name: Name of the index
        mapping: Index mapping configuration

    Returns:
        Response dictionary
    """
    res = es.indices.create(index=index_name, ignore=400, body=mapping)
    return res


def delete_index(es: Elasticsearch, index_name: str) -> Dict[str, Any]:
    """
    Delete an Elasticsearch index.

    Args:
        es: Elasticsearch client instance
        index_name: Name of the index

    Returns:
        Response dictionary
    """
    res = es.indices.delete(index=index_name)
    return res


def write_bulk(es: Elasticsearch, vecs: List[Dict[str, Any]], timeout: int = 3600) -> None:
    """
    Bulk write documents to Elasticsearch.

    Args:
        es: Elasticsearch client instance
        vecs: List of document dictionaries
        timeout: Request timeout in seconds
    """
    helpers.bulk(es, vecs, request_timeout=timeout)


def write_index_bulk(es: Elasticsearch, vec_datas: List[List[Dict[str, Any]]]) -> None:
    """
    Write documents to Elasticsearch using multiple threads.

    Args:
        es: Elasticsearch client instance
        vec_datas: List of document batches
    """
    pool = ThreadPoolExecutor(max_workers=8)
    tasks = []
    for vecs in vec_datas:
        tasks.append(pool.submit(write_bulk, es, vecs))
    wait(tasks)


def bulk_update_with_retry(
    es: Elasticsearch,
    actions: List[Dict[str, Any]],
    log: Any,
    timeout: int = 3600,
    retries: int = 3,
) -> None:
    """
    Bulk update documents with retry mechanism for version conflicts.

    Args:
        es: Elasticsearch client instance
        actions: List of update actions
        log: Logger instance
        timeout: Request timeout in seconds
        retries: Number of retry attempts
    """
    for attempt in range(retries):
        try:
            helpers.bulk(es, actions, request_timeout=timeout)
            break
        except helpers.BulkIndexError as e:
            version_conflict_errors = [
                error for error in e.errors if error['update']['status'] == 409
            ]
            if version_conflict_errors:
                log.error(
                    f"{len(version_conflict_errors)} version conflicts encountered. Retrying..."
                )
            else:
                log.error(f"Bulk indexing error: {e}")
                break
            if attempt < retries - 1:
                time.sleep(1)
            else:
                log.error("Max retries reached. Some documents could not be indexed.")
                break


def search_index(
    es: Elasticsearch, index_name: str, query: Dict[str, Any], size: int = 10
) -> Dict[str, Any]:
    """
    Search documents in an index.

    Args:
        es: Elasticsearch client instance
        index_name: Name of the index
        query: Search query dictionary
        size: Maximum number of results to return

    Returns:
        Search results dictionary
    """
    res = es.search(index=index_name, body=query, size=size)
    return res


def scroll_search(
    es: Elasticsearch,
    index_name: str,
    query: Dict[str, Any],
    scroll: str = '2m',
    size: int = 1000,
) -> Generator[List[Dict[str, Any]], None, None]:
    """
    Search documents using scroll API for large result sets.

    Args:
        es: Elasticsearch client instance
        index_name: Name of the index
        query: Search query dictionary
        scroll: Scroll timeout (e.g., '2m')
        size: Number of documents per scroll

    Yields:
        Batches of search results
    """
    page = es.search(index=index_name, body=query, scroll=scroll, size=size)
    sid = page['_scroll_id']
    scroll_size = page['hits']['total']['value']
    while scroll_size > 0:
        yield page['hits']['hits']
        page = es.scroll(scroll_id=sid, scroll=scroll)
        sid = page['_scroll_id']
        scroll_size = len(page['hits']['hits'])
    es.clear_scroll(scroll_id=sid)
