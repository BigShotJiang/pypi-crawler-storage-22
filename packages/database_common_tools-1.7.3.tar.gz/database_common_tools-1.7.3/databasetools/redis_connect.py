# -*- coding: utf-8 -*-
"""Redis connection and utility functions (legacy version)."""

import json
import logging
from typing import Optional, List, Any, Union
from redis import Redis

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
LOG_FT = logging.Formatter('%(asctime)s - %(levelname)s: %(message)s')
CONSOLE_HANDLER = logging.StreamHandler()
CONSOLE_HANDLER.setFormatter(LOG_FT)


def rd_connect(host: str, port: Union[str, int], password: Optional[str] = None) -> Redis:
    """
    Create a Redis connection.

    Args:
        host: Redis server host
        port: Redis server port (can be string or int)
        password: Redis server password (optional)

    Returns:
        Redis connection object
    """
    port_int = int(port) if isinstance(port, str) else port
    return Redis(host=host, port=port_int, password=password)


def rd_del(connect: Redis, key: str) -> bool:
    """
    Delete a key from Redis.

    Args:
        connect: Redis connection object
        key: Key to delete

    Returns:
        True if successful, False otherwise
    """
    try:
        res = connect.delete(key)
        return bool(res)
    except Exception as e:
        LOG.error('exception ... {}'.format(e))
        return False


def rd_expire(connect: Redis, key: str, seconds: int) -> None:
    """
    Set expiration time for a Redis key.

    Args:
        connect: Redis connection object
        key: Key to set expiration for
        seconds: Expiration time in seconds
    """
    connect.expire(key, seconds)


def rd_set(connect: Redis, key: str, value: Any) -> None:
    """
    Set a value in Redis.

    Args:
        connect: Redis connection object
        key: Key to set
        value: Value to set
    """
    connect.set(key, value)


def rd_set_list(connect: Redis, key: str, value: Any) -> None:
    """
    Append a value to a Redis list.

    Args:
        connect: Redis connection object
        key: List key
        value: Value to append
    """
    connect.rpush(key, value)


def rd_set_zset(connect: Redis, key: str, value: Any, score: float) -> None:
    """
    Add a member to a Redis sorted set.

    Args:
        connect: Redis connection object
        key: Sorted set key
        value: Member value
        score: Member score
    """
    connect.zadd(key, {value: score})


def rd_get(connect: Redis, key: str, code: str = 'utf-8') -> Optional[str]:
    """
    Get a value from Redis.

    Args:
        connect: Redis connection object
        key: Key to get
        code: Encoding to use for decoding (default: 'utf-8')

    Returns:
        Decoded string value, or None if error
    """
    try:
        res = connect.get(key)
        if res is None:
            return None
        return res.decode(code)
    except Exception as e:
        LOG.error('exception ... {}'.format(e))
        return None


def rd_get_zset(connect: Redis, key: str, start: int, end: int) -> List[bytes]:
    """
    Get members from a Redis sorted set by range.

    Args:
        connect: Redis connection object
        key: Sorted set key
        start: Start index
        end: End index

    Returns:
        List of member values
    """
    return connect.zrange(key, start, end)


def rd_get_list_len(connect: Redis, key: str) -> int:
    """
    Get the length of a Redis list.

    Args:
        connect: Redis connection object
        key: List key

    Returns:
        Length of the list
    """
    return connect.llen(key)


def rd_get_zset_len(connect: Redis, key: str) -> int:
    """
    Get the length of a Redis sorted set.

    Args:
        connect: Redis connection object
        key: Sorted set key

    Returns:
        Length of the sorted set
    """
    return connect.zcard(key)


def dump_docs_redis_set(
    con: Redis, key: str, timeout: int, docs: Any
) -> str:
    """
    Store documents in Redis as JSON string with optional expiration.

    Args:
        con: Redis connection object
        key: Key to store under
        timeout: Expiration time in seconds (0 = no expiration)
        docs: Documents to store (will be JSON serialized)

    Returns:
        The key used
    """
    LOG.info('key:{},timeout:{},docs:{}'.format(key, timeout, docs))
    rd_set(con, key, json.dumps(docs, ensure_ascii=False))
    if timeout > 0:
        rd_expire(con, key, timeout)
    return key


def dump_data_redis_set_list(
    con: Redis, key: str, timeout: int, data: List[Any]
) -> str:
    """
    Store data list in Redis with optional expiration.

    Args:
        con: Redis connection object
        key: List key
        timeout: Expiration time in seconds (0 = no expiration)
        data: List of items to store

    Returns:
        The key used
    """
    LOG.info('key:{},timeout:{},docs:{}'.format(key, timeout, data))
    for item in data:
        rd_set_list(con, key, item)
    if timeout > 0:
        rd_expire(con, key, timeout)
    return key


def dump_data_redis_set_zset(
    con: Redis, key: str, timeout: int, data: List[Any]
) -> str:
    """
    Store data in Redis sorted set with optional expiration.

    Args:
        con: Redis connection object
        key: Sorted set key
        timeout: Expiration time in seconds (0 = no expiration)
        data: List of items to store (index used as score)

    Returns:
        The key used
    """
    LOG.info('key:{},timeout:{},docs:{}'.format(key, timeout, data))
    for index, item in enumerate(data):
        rd_set_zset(con, key, item, index)
    if timeout > 0:
        rd_expire(con, key, timeout)
    return key
