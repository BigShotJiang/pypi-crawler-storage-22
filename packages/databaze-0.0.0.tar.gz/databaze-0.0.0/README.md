# databaze

[![PyPI version](https://badge.fury.io/py/databaze.svg)](https://badge.fury.io/py/databaze)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyPI Downloads](https://static.pepy.tech/personalized-badge/databaze?period=total&units=INTERNATIONAL_SYSTEM&left_color=GRAY&right_color=BRIGHTGREEN&left_text=downloads)](https://pepy.tech/projects/databaze)

loading...

## Installation

You can install `databaze` via pip:

```bash
pip install databaze
```

## License

This project is licensed under the MIT LICENSE - see the [LICENSE](https://opensource.org/licenses/MIT) for more details.
