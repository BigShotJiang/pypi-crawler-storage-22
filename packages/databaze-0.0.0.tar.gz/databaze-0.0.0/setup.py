from setuptools import setup, find_packages

setup(
    name="databaze",
    version="0.0.0",
    author="Khiat Mohammed Abderrezzak",
    author_email="khiat.dev@gmail.com",
    license="MIT",
    description="SELECT needle FROM haystack;",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://pypi.org/project/databaze/",
    packages=find_packages(),
    keywords=["database"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires=">=3.6",
)
