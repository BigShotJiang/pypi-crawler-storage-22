import os
import shutil
import subprocess
import sys
import sysconfig

from ..debug import logger
from ..version import __pyspark_version__, __dbconnect_version__, __delta_version__


def _custom_pyspark_version():
    """Construct a version string with a local identifier including Databricks Connect
    version following PEP 440 standard.
    """
    return f"{__pyspark_version__}+databricks.connect.{__dbconnect_version__}"


def _custom_delta_version():
    """Construct a version string with a local identifier including Databricks Connect
    version following PEP 440 standard.
    """
    return f"{__delta_version__}+databricks.connect.{__dbconnect_version__}"


PYSPARK_METADATA = f"""
Metadata-Version: 2.4
Name: pyspark
Version: {_custom_pyspark_version()}
Summary: Custom version of Apache Spark Python API bundled with Databricks Connect.
""".lstrip()

DELTA_METADATA = f"""
Metadata-Version: 2.4
Name: delta-spark
Version: {_custom_delta_version()}
Summary: Custom version of Delta Lake Python API bundled with Databricks Connect.
""".lstrip()

PYSPARK_TOP_LEVEL_TXT = "pyspark\n"
DELTA_TOP_LEVEL_TXT = "delta\n"

WHEEL = """
Wheel-Version: 1.0
Generator: databricks-connect
Root-Is-Purelib: true
Tag: py3-none-any
""".lstrip()

INSTALLER = "databricks-connect\n"
RECORD = ""


def _get_pyspark_dist_info_dir() -> str:
    site_packages_path = sysconfig.get_path('purelib')
    pyspark_dist_info_dir_name = f"pyspark-{_custom_pyspark_version()}.dist-info"
    return os.path.join(site_packages_path, pyspark_dist_info_dir_name)


def _get_delta_spark_dist_info_dir() -> str:
    site_packages_path = sysconfig.get_path('purelib')
    delta_spark_dist_info_dir_name = f"delta_spark-{_custom_delta_version()}.dist-info"
    return os.path.join(site_packages_path, delta_spark_dist_info_dir_name)


def _create_pyspark_dist_info():
    try:
        dist_info_dir = _get_pyspark_dist_info_dir()
        logger.debug(f"Creating .dist-info directory for pyspark at: {dist_info_dir}")
        os.makedirs(dist_info_dir, exist_ok=True)
        with open(os.path.join(dist_info_dir, "METADATA"), "w") as f:
            f.write(PYSPARK_METADATA)
        with open(os.path.join(dist_info_dir, "WHEEL"), "w") as f:
            f.write(WHEEL)
        with open(os.path.join(dist_info_dir, "top_level.txt"), "w") as f:
            f.write(PYSPARK_TOP_LEVEL_TXT)
        with open(os.path.join(dist_info_dir, "RECORD"), "w") as f:
            f.write(RECORD)
        with open(os.path.join(dist_info_dir, "INSTALLER"), "w") as f:
            f.write(INSTALLER)
        logger.debug(f"Created and populated .dist-info directory for pyspark at: {dist_info_dir}")
    except Exception as e:
        raise RuntimeError(f"Failed to create .dist-info directory.") from e


def _delete_pyspark_dist_info():
    dist_info_dir = _get_pyspark_dist_info_dir()
    if os.path.exists(dist_info_dir):
        shutil.rmtree(dist_info_dir)
        logger.debug(f"Deleted existing .dist-info directory for pyspark at: {dist_info_dir}")
    else:
        logger.debug(f"Directory .dist-info for pyspark at '{dist_info_dir}' does not exist")


def _create_delta_dist_info():
    try:
        dist_info_dir = _get_delta_spark_dist_info_dir()
        logger.debug(f"Creating .dist-info directory for delta-spark at: {dist_info_dir}")
        os.makedirs(dist_info_dir, exist_ok=True)
        with open(os.path.join(dist_info_dir, "METADATA"), "w") as f:
            f.write(DELTA_METADATA)
        with open(os.path.join(dist_info_dir, "WHEEL"), "w") as f:
            f.write(WHEEL)
        with open(os.path.join(dist_info_dir, "top_level.txt"), "w") as f:
            f.write(DELTA_TOP_LEVEL_TXT)
        with open(os.path.join(dist_info_dir, "RECORD"), "w") as f:
            f.write(RECORD)
        with open(os.path.join(dist_info_dir, "INSTALLER"), "w") as f:
            f.write(INSTALLER)
        logger.debug(f"Created and populated .dist-info directory for delta-spark at: {dist_info_dir}")
    except Exception as e:
        raise RuntimeError(f"Failed to create .dist-info directory for delta-spark.") from e


def _delete_delta_dist_info():
    dist_info_dir = _get_delta_spark_dist_info_dir()
    if os.path.exists(dist_info_dir):
        shutil.rmtree(dist_info_dir)
        logger.debug(f"Deleted existing .dist-info directory for delta-spark at: {dist_info_dir}")
    else:
        logger.debug(f"Directory .dist-info for delta-spark at '{dist_info_dir}' does not exist")


def _verify_pip_show(package_name: str, expected_version: str):
    """Verify that pip recognizes the package."""
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'show', package_name],
        capture_output=True,
        text=True,
        timeout=10
    )
    if result.returncode == 0 and f"Version: {expected_version}" in result.stdout:
        logger.debug(f"✓ pip show recognizes {package_name}")
        # Show name and version line
        for line in result.stdout.split('\n'):
            if line.startswith('Name:') or line.startswith('Version:'):
                logger.debug(f"  {line}")
    else:
        raise RuntimeError(f"✗ pip show does not recognize {package_name}. Something went wrong during registration.")


def _verify_pip_install(package_name: str):
    """Verify that `pip install` recognizes the package as installed."""
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'install', package_name, '--dry-run'],
        capture_output=True,
        text=True,
        timeout=10
    )
    if result.returncode == 0 and "Requirement already satisfied" in result.stdout:
        logger.debug(f"✓ pip install recognizes {package_name} as already installed")
    else:
        raise RuntimeError(f"✗ pip install does not recognize {package_name} as installed. "
                           "Something went wrong during registration.")


def _verify_pyspark_registration():
    logger.debug("Running verification for pyspark.")
    _verify_pip_show('pyspark', _custom_pyspark_version())
    _verify_pip_install('pyspark')
    logger.debug("Verification succeeded. pyspark is now registered with pip.")
    logger.debug("You can verify with: pip list | grep pyspark")


def _verify_delta_registration():
    logger.debug("Running verification for delta-spark.")
    _verify_pip_show('delta-spark', _custom_delta_version())
    _verify_pip_install('delta-spark')
    logger.debug("Verification succeeded. delta-spark is now registered with pip.")
    logger.debug("You can verify with: pip list | grep delta-spark")


def main():
    try:
        _create_pyspark_dist_info()
        _verify_pyspark_registration()

        _create_delta_dist_info()
        _verify_delta_registration()

    except Exception as e:
        logger.error("Registration was not successful. Running cleanup.")
        _delete_pyspark_dist_info()
        _delete_delta_dist_info()
        raise e


if __name__ == "__main__":
    main()
