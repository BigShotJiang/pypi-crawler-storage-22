"""DataCheck - Lightweight data quality validation CLI tool."""

from datacheck.engine import ValidationEngine
from datacheck.exceptions import (
    ColumnNotFoundError,
    ConfigurationError,
    DataCheckError,
    DataLoadError,
    EmptyDatasetError,
    RuleDefinitionError,
    UnsupportedFormatError,
    ValidationError,
)
from datacheck.loader import (
    AvroLoader,
    CSVLoader,
    DataLoader,
    DeltaLakeLoader,
    DuckDBLoader,
    LoaderFactory,
    ParquetLoader,
)
from datacheck.output import JSONExporter, OutputFormatter
from datacheck.schema import (
    BaselineManager,
    SchemaComparator,
    SchemaDetector,
)
from datacheck.profiling import DataProfiler
from datacheck.profiling.models import ColumnProfile, DatasetProfile
from datacheck.profiling.outliers import OutlierDetector, OutlierMethod
from datacheck.profiling.quality import QualityScorer
from datacheck.profiling.suggestions import RuleSuggester
from datacheck.profiling.formatters import (
    JsonFormatter,
    MarkdownFormatter,
    TerminalFormatter,
)

__version__ = "2.0.1"
__author__ = "Squrtech"
__email__ = "contact@squrtech.com"

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    # Exceptions
    "DataCheckError",
    "ConfigurationError",
    "ValidationError",
    "DataLoadError",
    "RuleDefinitionError",
    "UnsupportedFormatError",
    "ColumnNotFoundError",
    "EmptyDatasetError",
    # Loaders
    "DataLoader",
    "CSVLoader",
    "ParquetLoader",
    "DuckDBLoader",
    "DeltaLakeLoader",
    "AvroLoader",
    "LoaderFactory",
    # Engine
    "ValidationEngine",
    # Output
    "OutputFormatter",
    "JSONExporter",
    # Schema
    "SchemaDetector",
    "SchemaComparator",
    "BaselineManager",
    # Profiling
    "DataProfiler",
    "ColumnProfile",
    "DatasetProfile",
    "OutlierDetector",
    "OutlierMethod",
    "QualityScorer",
    "RuleSuggester",
    "JsonFormatter",
    "MarkdownFormatter",
    "TerminalFormatter",
]
