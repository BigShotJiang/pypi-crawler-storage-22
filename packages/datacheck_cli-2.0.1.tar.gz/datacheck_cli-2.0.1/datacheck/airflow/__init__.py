"""Airflow integration for DataCheck.

Provides two operators for integrating DataCheck data quality
validation into Airflow pipelines:

- DataCheckOperator: Validate data against configured rules
- DataCheckSchemaOperator: Detect schema changes against baselines

For complex workflows, you can also use the CLI via BashOperator.
"""

from datacheck.airflow.operators import (
    DataCheckOperator,
    DataCheckSchemaOperator,
)

__all__ = [
    "DataCheckOperator",
    "DataCheckSchemaOperator",
]
