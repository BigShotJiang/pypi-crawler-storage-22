"""CLI interface for DataCheck."""

import typer
from rich.console import Console

from datacheck import __version__

app = typer.Typer(
    name="datacheck",
    help="Lightweight data quality validation CLI tool",
    add_completion=False,
)

console = Console()


@app.command()
def version() -> None:
    """Display version information."""
    console.print(f"DataCheck v{__version__}")


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """DataCheck - Lightweight data quality validation CLI tool.

    Run 'datacheck validate <file>' to validate a data file.
    Run 'datacheck --help' for more information.
    """
    if ctx.invoked_subcommand is None:
        console.print("[bold]DataCheck[/bold] - Data Quality Validation")
        console.print(f"Version: {__version__}")
        console.print()
        console.print("Usage: datacheck [COMMAND] [OPTIONS]")
        console.print()
        console.print("Commands:")
        console.print("  validate  Validate data file against configured rules")
        console.print("  profile   Generate data quality profile for a dataset")
        console.print("  config    Configuration management commands")
        console.print("  schema    Schema evolution detection commands")
        console.print("  version   Display version information")
        console.print()
        console.print("Run 'datacheck [COMMAND] --help' for more information on a command.")


# Import submodules to register commands on app.
# These must come AFTER app and console are defined to avoid circular imports.
import datacheck.cli.validate  # noqa: E402, F401
import datacheck.cli.profile  # noqa: E402, F401

# Register sub-apps (also triggers module-level command registration)
from datacheck.cli.schema import schema_app  # noqa: E402
from datacheck.cli.config import config_app  # noqa: E402

app.add_typer(schema_app, name="schema")
app.add_typer(config_app, name="config")


if __name__ == "__main__":
    app()
