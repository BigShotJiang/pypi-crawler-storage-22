"""Profile command for DataCheck CLI."""

from pathlib import Path

import typer

from datacheck.cli import app, console
from datacheck.exceptions import DataCheckError, DataLoadError
from datacheck.logging import configure_logging, get_logger, set_trace_id, generate_trace_id


@app.command()
def profile(
    data_source: str | None = typer.Argument(
        None,
        help="Data source: file path, connection string, or omit when using config/sources"
    ),
    config: str | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to config file with data_source defined",
    ),
    source: str | None = typer.Option(
        None,
        "--source",
        help="Named source from sources.yaml",
    ),
    sources_file: str | None = typer.Option(
        None,
        "--sources-file",
        help="Path to sources YAML file",
    ),
    table: str | None = typer.Option(
        None,
        "--table",
        "-t",
        help="Database table name (for database sources)",
    ),
    query: str | None = typer.Option(
        None,
        "--query",
        "-q",
        help="Custom SQL query (alternative to --table)",
    ),
    delta_version: int | None = typer.Option(
        None,
        "--delta-version",
        help="Delta Lake version to load (time travel)",
    ),
    delta_timestamp: str | None = typer.Option(
        None,
        "--delta-timestamp",
        help="Delta Lake timestamp (ISO 8601) to load data as of (time travel)",
    ),
    storage_options: str | None = typer.Option(
        None,
        "--storage-options",
        help="JSON string of storage options for Delta Lake cloud access",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Path to write profile report",
    ),
    output_format: str = typer.Option(
        "terminal",
        "--format",
        "-f",
        help="Output format: 'terminal', 'json', or 'markdown'",
    ),
    outlier_method: str = typer.Option(
        "zscore",
        "--outlier-method",
        help="Outlier detection method: 'zscore' or 'iqr'",
    ),
    show_suggestions: bool = typer.Option(
        True,
        "--suggestions/--no-suggestions",
        help="Show rule suggestions based on data profile",
    ),
    show_correlations: bool = typer.Option(
        True,
        "--correlations/--no-correlations",
        help="Show correlation matrix for numeric columns",
    ),
    log_level: str = typer.Option(
        "WARNING",
        "--log-level",
        help="Log level: DEBUG, INFO, WARNING, ERROR, CRITICAL",
    ),
    log_format: str = typer.Option(
        "console",
        "--log-format",
        help="Log format: 'console' (human-readable) or 'json' (machine-parseable)",
    ),
    log_file: str | None = typer.Option(
        None,
        "--log-file",
        help="Path to log file (enables file logging with rotation)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable verbose logging (sets log level to DEBUG)",
    ),
) -> None:
    """Generate data quality profile for a dataset.

    Analyzes data to provide statistical summaries, missing value analysis,
    cardinality, outlier detection, quality scoring, and rule suggestions.

    Examples:
        datacheck profile data.csv
        datacheck profile data.csv --format json --output profile.json
        datacheck profile data.csv --format markdown --output PROFILE.md

    Exit codes:
      0 - Profile generated successfully
      3 - Data loading error
      4 - Unexpected error
    """
    # Configure logging
    effective_log_level = "DEBUG" if verbose else log_level
    configure_logging(
        level=effective_log_level,
        format_type=log_format,
        log_file=log_file,
        mask_sensitive=True,
    )

    # Generate trace ID for this profiling run
    trace_id = generate_trace_id()
    set_trace_id(trace_id)

    logger = get_logger(__name__)
    logger.info(
        "profiling_started",
        extra={
            "trace_id": trace_id,
            "data_source": data_source,
        }
    )

    try:
        # Load data - resolve source from config/sources/argument
        from datacheck.loader import LoaderFactory
        from datacheck.config import ConfigLoader
        from datacheck.config.source import load_sources
        from datacheck.connectors.factory import load_source_data

        # Parse storage options if provided
        parsed_storage_options = None
        if storage_options:
            import json as json_module
            try:
                parsed_storage_options = json_module.loads(storage_options)
            except json_module.JSONDecodeError as e:
                console.print(f"[red]Error:[/red] Invalid --storage-options JSON: {e}", style="red")
                raise typer.Exit(code=2) from e

        _status = console.status("[bold blue]Loading data...", spinner="dots")
        _status.start()

        try:
            df = None
            resolved_source_name = None

            # Option 1: Named source from sources file
            if source:
                # Load sources file
                if sources_file:
                    sources_path = Path(sources_file)
                else:
                    # Try to find sources from config
                    if config:
                        config_data = ConfigLoader.load(config)
                        if config_data.sources_file:
                            sources_path = Path(config).parent / config_data.sources_file
                        else:
                            console.print(
                                "[red]Error:[/red] --source requires --sources-file or sources_file in config",
                                style="red",
                            )
                            raise typer.Exit(code=2)
                    else:
                        console.print(
                            "[red]Error:[/red] --source requires --sources-file",
                            style="red",
                        )
                        raise typer.Exit(code=2)

                sources = load_sources(sources_path)
                if source not in sources:
                    console.print(
                        f"[red]Error:[/red] Source '{source}' not found. "
                        f"Available: {', '.join(sorted(sources.keys()))}",
                        style="red",
                    )
                    raise typer.Exit(code=2)

                source_config = sources[source]
                df = load_source_data(source_config, table=table, query=query)
                resolved_source_name = source
                logger.info("data_loaded", extra={"source_type": "named_source", "source": source})

            # Option 2: Inline data_source from config
            elif data_source is None and config:
                config_data = ConfigLoader.load(config)
                config_dir = Path(config).parent
                if config_data.data_source:
                    source_path = config_dir / config_data.data_source.path
                    df = LoaderFactory.load(
                        str(source_path),
                        table=table,
                        query=query,
                        version=delta_version,
                        timestamp=delta_timestamp,
                        storage_options=parsed_storage_options,
                    )
                    resolved_source_name = str(source_path)
                    logger.info("data_loaded", extra={"source_type": "inline", "path": str(source_path)})
                elif config_data.sources_file and config_data.source:
                    # Use default source from config
                    sources_path = config_dir / config_data.sources_file
                    sources = load_sources(sources_path)
                    if config_data.source not in sources:
                        console.print(
                            f"[red]Error:[/red] Default source '{config_data.source}' not found",
                            style="red",
                        )
                        raise typer.Exit(code=2)
                    source_config = sources[config_data.source]
                    df = load_source_data(source_config, table=table, query=query)
                    resolved_source_name = config_data.source
                    logger.info("data_loaded", extra={"source_type": "config_source", "source": config_data.source})
                else:
                    console.print(
                        "[red]Error:[/red] Config file has no data_source or sources_file defined",
                        style="red",
                    )
                    raise typer.Exit(code=2)

            # Option 3: Auto-discover config file
            elif data_source is None:
                found_config = ConfigLoader.find_config()
                if found_config:
                    config_data = ConfigLoader.load(found_config)
                    config_dir = found_config.parent
                    if config_data.data_source:
                        source_path = config_dir / config_data.data_source.path
                        df = LoaderFactory.load(
                            str(source_path),
                            table=table,
                            query=query,
                            version=delta_version,
                            timestamp=delta_timestamp,
                            storage_options=parsed_storage_options,
                        )
                        resolved_source_name = str(source_path)
                        logger.info("data_loaded", extra={"source_type": "auto_config", "path": str(source_path)})
                    elif config_data.sources_file and config_data.source:
                        sources_path = config_dir / config_data.sources_file
                        sources = load_sources(sources_path)
                        if config_data.source in sources:
                            source_config = sources[config_data.source]
                            df = load_source_data(source_config, table=table, query=query)
                            resolved_source_name = config_data.source
                            logger.info("data_loaded", extra={"source_type": "auto_source", "source": config_data.source})
                        else:
                            console.print(
                                f"[red]Error:[/red] Source '{config_data.source}' not found",
                                style="red",
                            )
                            raise typer.Exit(code=2)
                    else:
                        console.print(
                            "[red]Error:[/red] No data source specified. "
                            "Provide a file path as argument, use --config with data_source, "
                            "or use --source with --sources-file.",
                            style="red",
                        )
                        raise typer.Exit(code=2)
                else:
                    console.print(
                        "[red]Error:[/red] No data source specified. "
                        "Provide a file path as argument, use --config, or use --source.",
                        style="red",
                    )
                    raise typer.Exit(code=2)

            # Option 4: Direct data source argument
            else:
                logger.debug("loading_data", extra={"data_source": data_source})
                df = LoaderFactory.load(
                    data_source,
                    table=table,
                    query=query,
                    version=delta_version,
                    timestamp=delta_timestamp,
                    storage_options=parsed_storage_options,
                )
                resolved_source_name = data_source
                logger.info("data_loaded", extra={"row_count": len(df), "column_count": len(df.columns)})

        except DataLoadError as e:
            _status.stop()
            logger.error("data_load_failed", extra={"error": str(e)})
            console.print(f"[red]Data Load Error:[/red] {e}", style="red")
            raise typer.Exit(code=3) from e

        _status.update("[bold blue]Profiling data...")

        # Generate profile
        from datacheck.profiling import DataProfiler
        from datacheck.profiling.outliers import OutlierMethod

        logger.debug("generating_profile")

        # Determine outlier method
        method = OutlierMethod.IQR if outlier_method.lower() == "iqr" else OutlierMethod.ZSCORE

        profiler = DataProfiler(outlier_method=method)

        # Generate profile
        if resolved_source_name and not resolved_source_name.startswith(("http", "s3", "gs", "az")):
            dataset_name = Path(resolved_source_name).stem
        else:
            dataset_name = resolved_source_name or "dataset"
        profile_result = profiler.profile(df, name=dataset_name)
        _status.stop()
        logger.info("profile_generated", extra={
            "columns_analyzed": len(profile_result.columns),
            "quality_score": profile_result.overall_quality_score,
        })

        # Output based on format
        if output_format == "json":
            from datacheck.profiling.formatters import JsonFormatter
            json_fmt = JsonFormatter(
                pretty=True,
                include_suggestions=show_suggestions,
                include_correlations=show_correlations,
            )
            if output:
                json_fmt.save(profile_result, output)
                console.print(f"[green]OK[/green] Profile written to {output}")
            else:
                console.print(json_fmt.format(profile_result))

        elif output_format == "markdown":
            from datacheck.profiling.formatters import MarkdownFormatter
            md_fmt = MarkdownFormatter(
                include_suggestions=show_suggestions,
                include_correlations=show_correlations,
            )
            if output:
                md_fmt.save(profile_result, output)
                console.print(f"[green]OK[/green] Profile written to {output}")
            else:
                console.print(md_fmt.format(profile_result))

        else:  # terminal
            from datacheck.profiling.formatters import TerminalFormatter
            term_fmt = TerminalFormatter(
                console=console,
                include_suggestions=show_suggestions,
                include_correlations=show_correlations,
            )
            term_fmt.format(profile_result)

        logger.info("profiling_completed", extra={"trace_id": trace_id, "exit_code": 0})
        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except DataLoadError as e:
        logger.error("profiling_error", extra={"error_type": "DataLoadError", "error": str(e)})
        console.print(f"[red]Data Load Error:[/red] {e}", style="red")
        raise typer.Exit(code=3) from e
    except DataCheckError as e:
        logger.error("profiling_error", extra={"error_type": "DataCheckError", "error": str(e)})
        console.print(f"[red]DataCheck Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e
    except Exception as e:
        logger.exception("unexpected_error", extra={"error_type": type(e).__name__, "error": str(e)})
        console.print(f"[red]Unexpected Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e
