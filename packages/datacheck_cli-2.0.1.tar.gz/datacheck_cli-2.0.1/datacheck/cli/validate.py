"""Validate command for DataCheck CLI."""

from pathlib import Path
from typing import Any

import typer

import pandas as pd

from datacheck.cli import app, console
from datacheck.engine import ValidationEngine
from datacheck.exceptions import ConfigurationError, DataCheckError, DataLoadError, ValidationError
from datacheck.logging import configure_logging, get_logger, set_trace_id, generate_trace_id
from datacheck.output import JSONExporter


def _load_from_warehouse(
    connection_string: str,
    table: str | None = None,
    query: str | None = None,
    where: str | None = None,
    schema: str | None = None,
    warehouse: str | None = None,
    credentials: str | None = None,
    region: str | None = None,
    cluster: str | None = None,
    iam_auth: bool = False,
    sample_rate: float | None = None,
) -> pd.DataFrame:
    """Load data from a cloud data warehouse.

    Args:
        connection_string: Warehouse connection URI
        table: Table name
        query: Custom SQL query
        where: WHERE clause
        schema: Schema/dataset name
        warehouse: Snowflake warehouse name
        credentials: Path to credentials file
        region: Cloud region
        cluster: Cluster identifier
        iam_auth: Use IAM authentication
        sample_rate: Sample fraction

    Returns:
        DataFrame with loaded data

    Raises:
        DataLoadError: If loading fails
    """
    from datacheck.utils.connection_parser import parse_connection_string

    conn_info = parse_connection_string(connection_string)

    # Type hint for connector - imported types in each branch
    connector: Any  # Union of connector types

    if conn_info.type == "snowflake":
        from datacheck.connectors.snowflake import SnowflakeConnector

        connector = SnowflakeConnector(
            account=conn_info.host or "",
            user=conn_info.username or "",
            password=conn_info.password,
            database=conn_info.database,
            schema=schema or conn_info.schema,
            warehouse=warehouse or conn_info.params.get("warehouse"),
            role=conn_info.params.get("role"),
        )

    elif conn_info.type == "bigquery":
        from datacheck.connectors.bigquery import BigQueryConnector

        connector = BigQueryConnector(
            project_id=conn_info.host or "",
            dataset_id=schema or conn_info.database,
            credentials_path=credentials,
            location=conn_info.params.get("location", "US"),
        )

    elif conn_info.type == "redshift":
        from datacheck.connectors.redshift import RedshiftConnector

        connector = RedshiftConnector(
            host=conn_info.host or "",
            port=conn_info.port or 5439,
            database=conn_info.database or "",
            user=conn_info.username or "",
            password=conn_info.password,
            schema=schema or conn_info.schema,
            cluster_identifier=cluster or conn_info.params.get("cluster_identifier"),
            region=region or conn_info.params.get("region"),
            iam_auth=iam_auth or conn_info.params.get("iam_auth", False),
        )

    else:
        raise DataLoadError(f"Unsupported warehouse type: {conn_info.type}")

    # Load data
    with connector:
        if query:
            result: pd.DataFrame = connector.execute_query(query)
            return result
        elif table:
            result = connector.load_table(
                table_name=table,
                where=where,
                schema=schema,
                sample_rate=sample_rate,
            )
            return result
        else:
            raise DataLoadError(
                "Either --table or --query must be specified for warehouse sources"
            )


def _generate_markdown_report(summary: Any) -> str:
    """Generate a markdown report from validation summary.

    Args:
        summary: ValidationSummary object

    Returns:
        Markdown formatted string
    """
    lines = []
    lines.append("# DataCheck Validation Report\n")

    # Overall status
    if summary.all_passed:
        lines.append("**Status:** PASSED\n")
    elif summary.has_errors:
        lines.append("**Status:** ERRORS\n")
    else:
        lines.append("**Status:** FAILED\n")

    # Summary statistics
    lines.append("## Summary\n")
    lines.append("| Metric | Value |")
    lines.append("|--------|-------|")
    lines.append(f"| Total Rules | {summary.total_rules} |")
    lines.append(f"| Passed | {summary.passed_rules} |")
    lines.append(f"| Failed | {summary.failed_rules} |")
    if summary.failed_errors > 0:
        lines.append(f"| - Errors | {summary.failed_errors} |")
    if summary.failed_warnings > 0:
        lines.append(f"| - Warnings | {summary.failed_warnings} |")
    if summary.failed_info > 0:
        lines.append(f"| - Info | {summary.failed_info} |")
    lines.append(f"| Execution Errors | {summary.error_rules} |")
    lines.append("")

    # Failed rules details
    failed_results = summary.get_failed_results()
    if failed_results:
        lines.append("## Failed Rules\n")
        for result in failed_results:
            check_name = result.check_name or result.rule_name
            rule_type = result.rule_type or "unknown"
            failure_rate = (result.failed_rows / result.total_rows * 100) if result.total_rows > 0 else 0.0

            lines.append(f"### {check_name}")
            lines.append(f"- **Column:** {result.column}")
            lines.append(f"- **Rule Type:** {rule_type}")
            lines.append(f"- **Severity:** {result.severity}")
            lines.append(f"- **Failed Rows:** {result.failed_rows}/{result.total_rows} ({failure_rate:.1f}%)")

            if result.failure_details and result.failure_details.sample_failures:
                lines.append("\n**Sample Failures:**\n")
                lines.append("| Row | Value | Reason |")
                lines.append("|-----|-------|--------|")
                details = result.failure_details
                for i, row_idx in enumerate(details.sample_failures[:5]):
                    value = details.sample_values[i] if i < len(details.sample_values) else "N/A"
                    reason = details.sample_reasons[i] if i < len(details.sample_reasons) else "N/A"
                    # Escape pipes in values
                    value_str = str(value).replace("|", "\\|")[:40]
                    reason_str = str(reason).replace("|", "\\|")[:60]
                    lines.append(f"| {row_idx} | {value_str} | {reason_str} |")
            lines.append("")

    # Error rules details
    error_results = summary.get_error_results()
    if error_results:
        lines.append("## Rules with Errors\n")
        for result in error_results:
            check_name = result.check_name or result.rule_name
            lines.append(f"### {check_name}")
            lines.append(f"- **Column:** {result.column}")
            lines.append(f"- **Error:** {result.error}")
            lines.append("")

    return "\n".join(lines)


@app.command()
def validate(
    data_source: str | None = typer.Argument(
        None,
        help="Data source: file path, connection string, or omit when using --source",
    ),
    config: str | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to validation config file (auto-discovered if not provided)",
    ),
    source: str | None = typer.Option(
        None,
        "--source",
        help="Named source from sources.yaml (uses source-based validation)",
    ),
    sources_file: str | None = typer.Option(
        None,
        "--sources-file",
        help="Path to sources YAML file (overrides config sources_file)",
    ),
    table: str | None = typer.Option(
        None,
        "--table",
        "-t",
        help="Database table name (for database sources)",
    ),
    where: str | None = typer.Option(
        None,
        "--where",
        "-w",
        help="WHERE clause for filtering (for database sources)",
    ),
    query: str | None = typer.Option(
        None,
        "--query",
        "-q",
        help="Custom SQL query (alternative to --table)",
    ),
    schema: str | None = typer.Option(
        None,
        "--schema",
        "-s",
        help="Schema/dataset name (for database/warehouse sources)",
    ),
    warehouse: str | None = typer.Option(
        None,
        "--warehouse",
        help="Snowflake warehouse name",
    ),
    credentials: str | None = typer.Option(
        None,
        "--credentials",
        help="Path to credentials file (e.g., BigQuery service account JSON)",
    ),
    region: str | None = typer.Option(
        None,
        "--region",
        help="Cloud region (for Redshift IAM auth)",
    ),
    cluster: str | None = typer.Option(
        None,
        "--cluster",
        help="Cluster identifier (for Redshift IAM auth)",
    ),
    iam_auth: bool = typer.Option(
        False,
        "--iam-auth",
        help="Use IAM authentication (for Redshift)",
    ),
    sample_rate: float | None = typer.Option(
        None,
        "--sample-rate",
        help="Random sample rate (0.0 to 1.0)",
    ),
    sample_count: int | None = typer.Option(
        None,
        "--sample-count",
        help="Number of rows to sample",
    ),
    top: int | None = typer.Option(
        None,
        "--top",
        help="Validate only first N rows",
    ),
    stratify: str | None = typer.Option(
        None,
        "--stratify",
        help="Column name for stratified sampling (requires --sample-count)",
    ),
    seed: int | None = typer.Option(
        None,
        "--seed",
        help="Random seed for reproducible sampling",
    ),
    sample_strategy: str | None = typer.Option(
        None,
        "--sample-strategy",
        help="Sampling strategy: random, stratified, time_based, error_focused, adaptive, reservoir",
    ),
    time_column: str | None = typer.Option(
        None,
        "--time-column",
        help="Column for time-based sampling",
    ),
    start_date: str | None = typer.Option(
        None,
        "--start-date",
        help="Start date for time-based sampling (ISO format)",
    ),
    end_date: str | None = typer.Option(
        None,
        "--end-date",
        help="End date for time-based sampling (ISO format)",
    ),
    error_indicators: str | None = typer.Option(
        None,
        "--error-indicators",
        help="Comma-separated conditions for error-focused sampling (e.g., 'age<0,price>10000')",
    ),
    delta_version: int | None = typer.Option(
        None,
        "--delta-version",
        help="Delta Lake version to load (time travel)",
    ),
    delta_timestamp: str | None = typer.Option(
        None,
        "--delta-timestamp",
        help="Delta Lake timestamp (ISO 8601) to load data as of (time travel)",
    ),
    storage_options: str | None = typer.Option(
        None,
        "--storage-options",
        help="JSON string of storage options for Delta Lake cloud access (e.g., '{\"AWS_ACCESS_KEY_ID\": \"...\", \"AWS_SECRET_ACCESS_KEY\": \"...\"}')",
    ),
    parallel: bool = typer.Option(
        False,
        "--parallel",
        help="Enable parallel execution for faster validation",
    ),
    workers: int | None = typer.Option(
        None,
        "--workers",
        help="Number of worker processes (default: CPU count)",
    ),
    chunk_size: int | None = typer.Option(
        None,
        "--chunk-size",
        help="Rows per chunk for parallel processing (default: 100000)",
    ),
    show_progress: bool = typer.Option(
        True,
        "--progress/--no-progress",
        help="Show progress indicators during validation (default: enabled)",
    ),
    slack_webhook: str | None = typer.Option(
        None,
        "--slack-webhook",
        help="Slack webhook URL for sending validation results notifications",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Save results to a JSON file (terminal output is always shown)",
    ),
    csv_export: str | None = typer.Option(
        None,
        "--csv-export",
        help="Path to export failure details as CSV",
    ),
    suggestions: bool = typer.Option(
        True,
        "--suggestions/--no-suggestions",
        help="Show actionable suggestions for failures (default: enabled)",
    ),
    log_level: str = typer.Option(
        "WARNING",
        "--log-level",
        help="Log level: DEBUG, INFO, WARNING, ERROR, CRITICAL",
    ),
    log_format: str = typer.Option(
        "console",
        "--log-format",
        help="Log format: 'console' (human-readable) or 'json' (machine-parseable)",
    ),
    log_file: str | None = typer.Option(
        None,
        "--log-file",
        help="Path to log file (enables file logging with rotation)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable verbose logging (sets log level to DEBUG)",
    ),
) -> None:
    """Validate data using specified rules.

    Supports both file-based and database sources.

    Exit codes:
      0 - All validation rules passed
      1 - Some validation rules failed
      2 - Configuration error
      3 - Data loading error
      4 - Unexpected error
    """
    # Configure logging
    effective_log_level = "DEBUG" if verbose else log_level
    configure_logging(
        level=effective_log_level,
        format_type=log_format,
        log_file=log_file,
        mask_sensitive=True,
    )

    # Generate trace ID for this validation run
    trace_id = generate_trace_id()
    set_trace_id(trace_id)

    logger = get_logger(__name__)
    logger.info(
        "validation_started",
        extra={
            "trace_id": trace_id,
            "data_source": data_source,
            "config": config,
        }
    )

    try:
        # Initialize Slack notifier if webhook provided
        notifier = None
        if slack_webhook:
            from datacheck.notifications import SlackNotifier
            try:
                notifier = SlackNotifier(slack_webhook)
            except Exception as e:
                console.print(f"[red]Slack Configuration Error:[/red] {e}", style="red")
                raise typer.Exit(code=2) from e

        # Initialize validation engine
        try:
            if config:
                config_path = Path(config)
                engine = ValidationEngine(
                    config_path=config_path,
                    parallel=parallel,
                    workers=workers,
                    chunk_size=chunk_size,
                    show_progress=show_progress,
                    notifier=notifier,
                    sources_file=sources_file,
                )
            else:
                engine = ValidationEngine(
                    parallel=parallel,
                    workers=workers,
                    chunk_size=chunk_size,
                    show_progress=show_progress,
                    notifier=notifier,
                    sources_file=sources_file,
                )
        except ConfigurationError as e:
            console.print(f"[red]Configuration Error:[/red] {e}", style="red")
            raise typer.Exit(code=2) from e

        # Progress spinner — gives user feedback during load + validation
        num_checks = len(engine.config.checks)
        _status = (
            console.status(
                f"[bold blue]Validating {num_checks} checks...",
                spinner="dots",
            )
            if show_progress
            else None
        )
        if _status:
            _status.start()

        # Load and validate data
        try:
            # Source-based validation mode
            if source or engine.sources:
                logger.debug(
                    "loading_from_source",
                    extra={"source": source or engine.config.source},
                )
                # Parse error indicators if provided
                parsed_error_indicators = None
                if error_indicators:
                    parsed_error_indicators = [ind.strip() for ind in error_indicators.split(",")]

                summary = engine.validate_sources(
                    source_name=source,
                    table=table,
                    where=where,
                    query=query,
                    sample_rate=sample_rate,
                    sample_count=sample_count,
                    stratify=stratify,
                    seed=seed,
                    sample_strategy=sample_strategy,
                    time_column=time_column,
                    start_date=start_date,
                    end_date=end_date,
                    error_indicators=parsed_error_indicators,
                )
                logger.info(
                    "data_loaded",
                    extra={"source_type": "named_source", "source": source},
                )

            elif data_source is None and engine.config.data_source is not None:
                # Use inline data_source from config
                inline_source = engine.config.data_source
                # Resolve path relative to config file directory
                if config:
                    config_dir = Path(config).parent
                    source_path = config_dir / inline_source.path
                else:
                    source_path = Path(inline_source.path)

                logger.debug(
                    "loading_inline_data_source",
                    extra={"type": inline_source.type, "path": str(source_path)},
                )
                summary = engine.validate_file(str(source_path), **inline_source.options)
                logger.info(
                    "data_loaded",
                    extra={"source_type": "inline", "path": str(source_path)},
                )

            elif data_source is None:
                console.print(
                    "[red]Error:[/red] No data source specified. "
                    "Provide a file path/connection string as argument, "
                    "define 'data_source' in config, or use --source with --sources-file.",
                    style="red",
                )
                raise typer.Exit(code=2)

            # Warehouse connection string mode
            elif data_source.startswith(("snowflake://", "bigquery://", "redshift://")):
                logger.debug("loading_data", extra={"data_source": data_source})
                df = _load_from_warehouse(
                    data_source,
                    table=table,
                    query=query,
                    where=where,
                    schema=schema,
                    warehouse=warehouse,
                    credentials=credentials,
                    region=region,
                    cluster=cluster,
                    iam_auth=iam_auth,
                    sample_rate=sample_rate,
                )
                logger.info("data_loaded", extra={"source_type": "warehouse", "row_count": len(df)})
                summary = engine.validate_dataframe(df)

            # File/connection string mode
            else:
                logger.debug("loading_data", extra={"data_source": data_source})
                # Parse storage options if provided
                parsed_storage_options = None
                if storage_options:
                    import json as json_module
                    try:
                        parsed_storage_options = json_module.loads(storage_options)
                    except json_module.JSONDecodeError as e:
                        console.print(f"[red]Error:[/red] Invalid --storage-options JSON: {e}", style="red")
                        raise typer.Exit(code=2) from e

                # Parse error indicators if provided
                parsed_error_indicators = None
                if error_indicators:
                    parsed_error_indicators = [ind.strip() for ind in error_indicators.split(",")]

                summary = engine.validate_file(
                    data_source,
                    table=table,
                    where=where,
                    query=query,
                    sample_rate=sample_rate,
                    sample_count=sample_count,
                    top=top,
                    stratify=stratify,
                    seed=seed,
                    sample_strategy=sample_strategy,
                    time_column=time_column,
                    start_date=start_date,
                    end_date=end_date,
                    error_indicators=parsed_error_indicators,
                    version=delta_version,
                    timestamp=delta_timestamp,
                    storage_options=parsed_storage_options,
                )
                logger.info("data_loaded", extra={"source_type": "file", "data_source": data_source})
        except DataLoadError as e:
            logger.error("data_load_failed", extra={"error": str(e)})
            console.print(f"[red]Data Load Error:[/red] {e}", style="red")
            raise typer.Exit(code=3) from e
        finally:
            if _status:
                _status.stop()

        # Log validation results
        logger.info(
            "validation_completed",
            extra={
                "trace_id": trace_id,
                "total_rules": summary.total_rules,
                "passed_rules": summary.passed_rules,
                "failed_rules": summary.failed_rules,
                "all_passed": summary.all_passed,
                "has_errors": summary.has_errors,
            }
        )

        # Determine effective output file path from config if not specified via CLI
        effective_output = output
        if not output and engine.config.reporting and engine.config.reporting.output_path:
            effective_output = f"{engine.config.reporting.output_path}/results.json"

        # Terminal output — always shown
        from datacheck.reporting import TerminalReporter

        terminal_reporter = TerminalReporter(
            console=console,
            show_suggestions=suggestions,
        )
        terminal_reporter.report(summary)

        # JSON output — save to file if --output specified
        if effective_output:
            from pathlib import Path as OutputPath
            OutputPath(effective_output).parent.mkdir(parents=True, exist_ok=True)
            JSONExporter.export_summary(summary, output_path=effective_output, pretty=True)
            console.print(f"[green]OK:[/green] Results saved to {effective_output}")

        # Export CSV if requested via CLI option
        if csv_export:
            from datacheck.reporting import CsvExporter

            CsvExporter.export_failures(
                summary,
                output_path=csv_export,
                include_suggestions=suggestions,
            )
            console.print(f"[green]OK:[/green] Failures exported to {csv_export}")

        # Export CSV if configured in config file (and not already exported via CLI)
        elif not csv_export and engine.config.reporting and engine.config.reporting.export_failures:
            from datacheck.reporting import CsvExporter
            from pathlib import Path as ExportPath

            # Determine export path
            reporting_config = engine.config.reporting
            if reporting_config.failures_file:
                export_path = reporting_config.failures_file
            elif reporting_config.output_path:
                # Use output_path as directory, create failures.csv inside
                export_dir = ExportPath(reporting_config.output_path)
                export_dir.mkdir(parents=True, exist_ok=True)
                export_path = str(export_dir / "failures.csv")
            else:
                export_path = "validation_failures.csv"

            # Only export if there are failures
            if not summary.all_passed:
                CsvExporter.export_failures(
                    summary,
                    output_path=export_path,
                    include_suggestions=suggestions,
                )
                console.print(f"[green]OK:[/green] Failures exported to {export_path}")

        # Determine exit code
        if summary.has_errors:
            # Validation errors occurred (configuration/execution issues)
            logger.warning("validation_finished_with_errors", extra={"exit_code": 4})
            raise typer.Exit(code=4)
        elif not summary.all_passed:
            # Validation rules failed
            logger.info("validation_finished_with_failures", extra={"exit_code": 1})
            raise typer.Exit(code=1)
        else:
            # All rules passed
            logger.info("validation_finished_success", extra={"exit_code": 0})
            raise typer.Exit(code=0)

    except typer.Exit:
        # Re-raise typer Exit exceptions (for proper exit codes)
        raise
    except (ConfigurationError, DataLoadError, ValidationError) as e:
        # These should have been handled above, but catch just in case
        logger.error("validation_error", extra={"error_type": type(e).__name__, "error": str(e)})
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e
    except DataCheckError as e:
        # Generic DataCheck error
        logger.error("datacheck_error", extra={"error_type": type(e).__name__, "error": str(e)})
        console.print(f"[red]DataCheck Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e
    except Exception as e:
        # Unexpected error
        logger.exception("unexpected_error", extra={"error_type": type(e).__name__, "error": str(e)})
        console.print(f"[red]Unexpected Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e
