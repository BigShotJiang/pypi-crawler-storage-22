"""Auto-generate configuration from data profile."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

import pandas as pd

from datacheck.exceptions import ConfigurationError
from datacheck.profiling import DataProfiler
from datacheck.profiling.models import ColumnProfile, DatasetProfile


class ConfigGenerator:
    """Generate validation config from data profile.

    Analyzes data to suggest validation rules based on
    detected patterns and statistics.

    Example:
        >>> generator = ConfigGenerator()
        >>> config = generator.generate_from_dataframe(df)
        >>> generator.save_config(config, "datacheck.yaml")
    """

    # Confidence levels for filtering suggestions
    CONFIDENCE_LEVELS = {"low": 1, "medium": 2, "high": 3}

    def __init__(self) -> None:
        """Initialize generator."""
        self.profiler = DataProfiler()

    def generate_from_dataframe(
        self,
        df: pd.DataFrame,
        name: str = "dataset",
        confidence_threshold: str = "medium",
        include_metadata: bool = True,
    ) -> dict[str, Any]:
        """
        Generate config from DataFrame.

        Args:
            df: DataFrame to analyze
            name: Name for the dataset
            confidence_threshold: Minimum confidence ("low", "medium", "high")
            include_metadata: Include metadata section

        Returns:
            Config dictionary
        """
        # Validate confidence threshold
        if confidence_threshold not in self.CONFIDENCE_LEVELS:
            raise ConfigurationError(
                f"Invalid confidence_threshold '{confidence_threshold}'. "
                f"Must be one of: {', '.join(self.CONFIDENCE_LEVELS.keys())}"
            )

        # Profile data
        profile = self.profiler.profile(df, name=name)

        # Generate config from profile
        return self.generate_from_profile(
            profile,
            confidence_threshold=confidence_threshold,
            include_metadata=include_metadata,
        )

    def generate_from_profile(
        self,
        profile: DatasetProfile,
        confidence_threshold: str = "medium",
        include_metadata: bool = True,
    ) -> dict[str, Any]:
        """
        Generate config from existing profile.

        Args:
            profile: DatasetProfile from profiler
            confidence_threshold: Minimum confidence level
            include_metadata: Include metadata section

        Returns:
            Config dictionary
        """
        min_confidence = self.CONFIDENCE_LEVELS[confidence_threshold]

        # Generate single-column checks
        checks = []
        for _col_name, col_profile in profile.columns.items():
            check = self._generate_check(col_profile, min_confidence)
            if check and check.get("rules"):
                checks.append(check)

        # Generate cross-column checks
        for cc_rule in getattr(profile, "cross_column_rules", []):
            cc_confidence = self.CONFIDENCE_LEVELS.get(
                cc_rule.get("confidence", "low"), 1
            )
            if cc_confidence >= min_confidence:
                col_names = cc_rule["columns"]
                cc_check: dict[str, Any] = {
                    "name": f"cross_{'_'.join(col_names[:2])}_{cc_rule['rule']}",
                    "column": col_names[0],
                    "rules": {cc_rule["rule"]: cc_rule["params"]},
                    "description": cc_rule.get("reason", "Cross-column rule"),
                }
                reason = cc_rule.get("reason")
                if reason:
                    cc_check["_rule_reasons"] = {cc_rule["rule"]: reason}
                checks.append(cc_check)

        # Build config
        config: dict[str, Any] = {"version": "1.0"}

        if include_metadata:
            config["metadata"] = {
                "description": f"Auto-generated config for {profile.name}",
                "created": datetime.now().isoformat(),
                "generated_by": "datacheck",
                "source_rows": profile.row_count,
                "source_columns": profile.column_count,
                "quality_score": profile.overall_quality_score,
            }

        config["checks"] = checks

        config["reporting"] = {
            "output_path": "./output",
            "export_failures": True,
        }

        return config

    def _generate_check(
        self, col_profile: ColumnProfile, min_confidence: int
    ) -> dict[str, Any] | None:
        """
        Generate check for a column.

        Args:
            col_profile: ColumnProfile
            min_confidence: Minimum confidence level (1-3)

        Returns:
            Check dictionary or None if no rules
        """
        rules: dict[str, Any] = {}
        rule_reasons: dict[str, str] = {}
        excluded_rules: dict[str, Any] = {}
        excluded_reasons: dict[str, str] = {}

        # Process suggestions from profiler
        for suggestion in col_profile.suggestions:
            sugg_confidence = self.CONFIDENCE_LEVELS.get(
                suggestion.get("confidence", "low"), 1
            )

            rule_name = suggestion["rule"]
            params = suggestion.get("params")
            reason = suggestion.get("reason", "")

            if sugg_confidence >= min_confidence:
                if params is not None:
                    rules[rule_name] = params
                else:
                    rules[rule_name] = True

                if reason:
                    rule_reasons[rule_name] = reason
            else:
                if params is not None:
                    excluded_rules[rule_name] = params
                else:
                    excluded_rules[rule_name] = True
                if reason:
                    excluded_reasons[rule_name] = reason

        if not rules:
            return None

        # Create check with description
        check: dict[str, Any] = {
            "name": f"{col_profile.name}_check",
            "column": col_profile.name,
            "rules": rules,
        }

        if rule_reasons:
            check["_rule_reasons"] = rule_reasons

        if excluded_rules:
            check["_excluded_rules"] = excluded_rules
            check["_excluded_reasons"] = excluded_reasons

        # Build description from column characteristics
        desc_parts: list[str] = []

        if col_profile.null_percentage == 0:
            desc_parts.append("Required field")

        if col_profile.unique_percentage >= 99:
            desc_parts.append("unique identifier")
        elif col_profile.unique_count <= 10 and col_profile.unique_count > 0:
            desc_parts.append(f"{col_profile.unique_count} distinct values")

        inferred = getattr(col_profile, "inferred_type", None)
        if inferred:
            desc_parts.append(inferred)

        if desc_parts:
            check["description"] = ", ".join(desc_parts)

        return check

    def generate_from_file(
        self,
        data_path: str | Path,
        confidence_threshold: str = "medium",
        return_profile: bool = False,
        **load_kwargs: Any,
    ) -> dict[str, Any] | tuple[dict[str, Any], DatasetProfile]:
        """
        Generate config from data file.

        Args:
            data_path: Path to data file (CSV, Parquet, etc.)
            confidence_threshold: Minimum confidence level
            return_profile: If True, also return the DatasetProfile
            **load_kwargs: Additional kwargs for data loading

        Returns:
            Config dictionary, or (config, profile) tuple if return_profile=True
        """
        from datacheck.loader import LoaderFactory

        data_path = Path(data_path)
        df = LoaderFactory.load(str(data_path), **load_kwargs)
        name = data_path.stem

        # Determine source type from file extension
        ext = data_path.suffix.lower().lstrip(".")
        source_type_map = {
            "csv": "csv",
            "parquet": "parquet",
            "pq": "parquet",
            "json": "json",
            "avro": "avro",
        }
        source_type = source_type_map.get(ext, "csv")

        if return_profile:
            if confidence_threshold not in self.CONFIDENCE_LEVELS:
                raise ConfigurationError(
                    f"Invalid confidence_threshold '{confidence_threshold}'. "
                    f"Must be one of: {', '.join(self.CONFIDENCE_LEVELS.keys())}"
                )
            profile = self.profiler.profile(df, name=name)
            config = self.generate_from_profile(
                profile, confidence_threshold=confidence_threshold
            )
            config["data_source"] = {
                "type": source_type,
                "path": f"./{data_path.name}",
            }
            return config, profile

        config = self.generate_from_dataframe(
            df, name=name, confidence_threshold=confidence_threshold
        )
        config["data_source"] = {
            "type": source_type,
            "path": f"./{data_path.name}",
        }
        return config

    def save_config(
        self,
        config: dict[str, Any],
        output_path: str | Path,
        add_comments: bool = True,
    ) -> None:
        """
        Save config to YAML file.

        Args:
            config: Config dictionary
            output_path: Output file path
            add_comments: Add helpful comments to YAML
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if add_comments:
            yaml_content = self._generate_yaml_with_comments(config)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(yaml_content)
        else:
            with open(output_path, "w", encoding="utf-8") as f:
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    def _generate_yaml_with_comments(self, config: dict[str, Any]) -> str:
        """
        Generate YAML with helpful comments.

        Args:
            config: Config dictionary

        Returns:
            YAML string with comments
        """
        lines = [
            "# DataCheck Configuration",
            "# Auto-generated - review and adjust as needed",
            "#",
            "# Documentation: https://github.com/Squrtech/datacheck",
            "",
        ]

        # Version
        if "version" in config:
            lines.append(f"version: '{config['version']}'")
            lines.append("")

        # Metadata
        if "metadata" in config:
            lines.append("# Configuration metadata")
            lines.append("metadata:")
            for key, value in config["metadata"].items():
                if isinstance(value, str):
                    lines.append(f"  {key}: '{value}'")
                else:
                    lines.append(f"  {key}: {value}")
            lines.append("")

        # Data source
        if "data_source" in config:
            ds = config["data_source"]
            lines.append("# Data source configuration")
            lines.append("data_source:")
            lines.append(f"  type: {ds['type']}")
            lines.append(f"  path: '{ds['path']}'")
            if "options" in ds and ds["options"]:
                lines.append("  options:")
                for key, value in ds["options"].items():
                    if isinstance(value, str):
                        lines.append(f"    {key}: '{value}'")
                    else:
                        lines.append(f"    {key}: {value}")
            lines.append("")

        # Checks
        lines.append("# Validation checks")
        lines.append("# Each check validates a single column with one or more rules")
        lines.append("checks:")

        for check in config.get("checks", []):
            lines.append(f"  - name: {check['name']}")

            # Support both single-column and multi-column checks
            if "columns" in check:
                col_list = check["columns"]
                lines.append("    columns:")
                for c in col_list:
                    lines.append(f"      - {c}")
            elif "column" in check:
                lines.append(f"    column: {check['column']}")

            if "description" in check:
                lines.append(f"    description: '{check['description']}'")

            lines.append("    rules:")
            rule_reasons = check.get("_rule_reasons", {})
            for rule_name, rule_value in check.get("rules", {}).items():
                reason = rule_reasons.get(rule_name, "")
                comment = f"  # {reason}" if reason else ""
                self._render_rule_line(lines, rule_name, rule_value, comment)

            # Commented-out excluded rules (below confidence threshold)
            excluded = check.get("_excluded_rules", {})
            excluded_reasons = check.get("_excluded_reasons", {})
            if excluded:
                lines.append("      # --- Below confidence threshold ---")
                for rule_name, rule_value in excluded.items():
                    reason = excluded_reasons.get(rule_name, "")
                    comment = f"  # {reason}" if reason else ""
                    self._render_rule_line(
                        lines, rule_name, rule_value, comment, commented=True
                    )

            lines.append("")

        # Reporting
        if "reporting" in config:
            lines.append("# Output configuration")
            lines.append("reporting:")
            for key, value in config["reporting"].items():
                if isinstance(value, bool):
                    lines.append(f"  {key}: {str(value).lower()}")
                elif isinstance(value, str):
                    lines.append(f"  {key}: {value}")
                else:
                    lines.append(f"  {key}: {value}")

        return "\n".join(lines)

    @staticmethod
    def _render_rule_line(
        lines: list[str],
        rule_name: str,
        rule_value: object,
        comment: str = "",
        commented: bool = False,
    ) -> None:
        """Render a single rule as YAML line(s).

        Args:
            lines: Output list to append to
            rule_name: Rule name
            rule_value: Rule value (bool, dict, list, str, or number)
            comment: Inline comment string (e.g. "  # reason text")
            commented: If True, prefix all lines with "# " (excluded rules)
        """
        prefix = "      # " if commented else "      "
        sub_prefix = "        # " if commented else "        "

        if isinstance(rule_value, bool):
            lines.append(
                f"{prefix}{rule_name}: {str(rule_value).lower()}{comment}"
            )
        elif isinstance(rule_value, dict):
            if comment:
                lines.append(f"{prefix}{rule_name}:{comment}")
            else:
                lines.append(f"{prefix}{rule_name}:")
            for k, v in rule_value.items():
                if isinstance(v, str):
                    lines.append(f"{sub_prefix}{k}: '{v}'")
                elif isinstance(v, list):
                    lines.append(f"{sub_prefix}{k}:")
                    item_prefix = "          # " if commented else "          "
                    for item in v:
                        if isinstance(item, str):
                            lines.append(f"{item_prefix}- '{item}'")
                        else:
                            lines.append(f"{item_prefix}- {item}")
                else:
                    lines.append(f"{sub_prefix}{k}: {v}")
        elif isinstance(rule_value, list):
            if comment:
                lines.append(f"{prefix}{rule_name}:{comment}")
            else:
                lines.append(f"{prefix}{rule_name}:")
            for item in rule_value:
                if isinstance(item, str):
                    lines.append(f"{sub_prefix}- '{item}'")
                else:
                    lines.append(f"{sub_prefix}- {item}")
        elif isinstance(rule_value, str):
            lines.append(f"{prefix}{rule_name}: '{rule_value}'{comment}")
        else:
            lines.append(f"{prefix}{rule_name}: {rule_value}{comment}")

    def suggest_improvements(
        self, profile: DatasetProfile
    ) -> list[dict[str, Any]]:
        """
        Suggest data quality improvements based on profile.

        Args:
            profile: DatasetProfile

        Returns:
            List of improvement suggestions
        """
        suggestions = []

        for col_name, col_profile in profile.columns.items():
            # High null percentage
            if col_profile.null_percentage > 20:
                suggestions.append({
                    "column": col_name,
                    "issue": "High null percentage",
                    "detail": f"{col_profile.null_percentage:.1f}% null values",
                    "recommendation": "Consider adding not_null rule or investigate data quality",
                })

            # Potential duplicates for ID columns
            if "id" in col_name.lower() and col_profile.unique_percentage < 100:
                suggestions.append({
                    "column": col_name,
                    "issue": "Non-unique ID column",
                    "detail": f"{100 - col_profile.unique_percentage:.1f}% duplicates",
                    "recommendation": "Add unique rule if column should be unique",
                })

            # Outliers detected
            if col_profile.outlier_count > 0 and col_profile.outlier_percentage > 5:
                suggestions.append({
                    "column": col_name,
                    "issue": "High outlier percentage",
                    "detail": f"{col_profile.outlier_percentage:.1f}% outliers",
                    "recommendation": "Review outliers and consider adding range validation",
                })

        return suggestions


__all__ = ["ConfigGenerator"]
