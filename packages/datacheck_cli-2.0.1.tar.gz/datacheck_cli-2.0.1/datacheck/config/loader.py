"""Configuration parsing and validation (original config module)."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from datacheck.exceptions import ConfigurationError


@dataclass
class RuleConfig:
    """Configuration for a single validation rule.

    Attributes:
        name: Unique name for this rule
        column: Name of the column to validate
        rules: Dictionary of rule types and their parameters
        source: Optional source name override (references a named source)
        table: Optional table name override (for database sources)
        severity: Severity level (error, warning, info). Default is error.
        enabled: Whether this check is enabled. Default is True.
    """

    name: str
    column: str
    rules: dict[str, Any]
    source: str | None = None
    table: str | None = None
    severity: str = "error"  # error, warning, info
    enabled: bool = True

    def __post_init__(self) -> None:
        """Validate rule configuration after initialization."""
        if not self.name:
            raise ConfigurationError("Rule name cannot be empty")
        if not self.column:
            raise ConfigurationError(f"Column name cannot be empty for rule '{self.name}'")
        if not self.rules:
            raise ConfigurationError(f"Rules cannot be empty for rule '{self.name}'")

        # Validate severity
        valid_severities = ["error", "warning", "info"]
        if self.severity not in valid_severities:
            raise ConfigurationError(
                f"Invalid severity '{self.severity}' for rule '{self.name}'. "
                f"Must be one of: {', '.join(valid_severities)}"
            )

        # Validate rule types
        valid_rule_types = {
            # Basic rules
            "not_null", "min", "max", "unique", "regex",
            "allowed_values", "type", "length", "custom",
            # Statistical rules
            "mean_between", "std_dev_less_than", "percentile_range",
            "z_score_outliers", "distribution_type",
            # Freshness rules
            "max_age", "timestamp_range", "no_future_timestamps",
            "date_format_valid", "business_days_only",
            # Format rules
            "email_valid", "phone_valid", "url_valid", "json_valid",
            # Relationship rules
            "foreign_key_exists", "sum_equals", "unique_combination",
            # Additional rules
            "min_length", "max_length", "date_format", "date_range",
        }
        invalid_rules = set(self.rules.keys()) - valid_rule_types
        if invalid_rules:
            raise ConfigurationError(
                f"Invalid rule types in '{self.name}': {', '.join(invalid_rules)}. "
                f"Valid types: {', '.join(sorted(valid_rule_types))}"
            )


@dataclass
class DataSourceConfig:
    """Configuration for inline data source.

    Attributes:
        type: Source type (csv, parquet, json, excel, delta)
        path: Path to the data file (relative to config file or absolute)
        options: Loader-specific options (e.g. encoding, delimiter for CSV)
    """

    type: str
    path: str
    options: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate data source configuration."""
        valid_types = ["csv", "parquet", "delta", "avro", "duckdb", "sqlite"]
        if self.type not in valid_types:
            raise ConfigurationError(
                f"Invalid data source type '{self.type}'. "
                f"Must be one of: {', '.join(valid_types)}. "
                f"For databases, use sources_file with named sources."
            )
        if not self.path:
            raise ConfigurationError("Data source path cannot be empty")


@dataclass
class ReportingConfig:
    """Configuration for validation output and reporting.

    Attributes:
        output_path: Directory or file path for output files
        export_failures: Whether to export failures to CSV
        failures_file: Optional specific path for failures CSV
    """

    output_path: str | None = None
    export_failures: bool = False
    failures_file: str | None = None


@dataclass
class SamplingConfig:
    """Configuration for data sampling.

    Supports both basic and advanced sampling strategies:

    Basic methods:
        - none: No sampling (default)
        - random: Random sample by rate or count
        - stratified: Proportional sample per group
        - top: First N rows
        - systematic: Every Nth row

    Advanced methods:
        - time_based: Filter by date range
        - error_focused: Oversample rows likely to fail
        - adaptive: Dynamically adjust sampling based on error rate
        - reservoir: Memory-efficient streaming sample

    Example YAML:
        sampling:
          method: stratified
          stratify_by: region
          count: 1000
          seed: 42
    """

    # Basic fields
    method: str = "none"
    rate: float | None = None  # For random sampling (0.0-1.0)
    count: int | None = None  # For random/stratified/top/reservoir
    stratify_by: str | None = None  # For stratified sampling
    seed: int | None = None  # For reproducibility

    # Time-based sampling fields
    time_column: str | None = None  # Column containing timestamps
    start_date: str | None = None  # ISO format date string
    end_date: str | None = None  # ISO format date string

    # Error-focused/adaptive sampling fields
    error_indicators: list[str] | None = None  # e.g., ["age < 0", "price > 100000"]

    # Systematic sampling fields
    interval: int | None = None  # For systematic: sample every Nth row
    start: int = 0  # Starting index for systematic sampling

    def __post_init__(self) -> None:
        """Validate sampling configuration."""
        valid_methods = [
            "none", "random", "stratified", "top", "systematic",
            "time_based", "error_focused", "adaptive", "reservoir"
        ]
        if self.method not in valid_methods:
            raise ConfigurationError(
                f"Invalid sampling method '{self.method}'. "
                f"Must be one of: {', '.join(valid_methods)}"
            )

        if self.method == "random":
            if self.rate is None and self.count is None:
                raise ConfigurationError(
                    "Random sampling requires either 'rate' or 'count'"
                )

        if self.method == "stratified":
            if self.stratify_by is None:
                raise ConfigurationError(
                    "Stratified sampling requires 'stratify_by' column"
                )
            if self.count is None:
                raise ConfigurationError(
                    "Stratified sampling requires 'count'"
                )

        if self.method == "top":
            if self.count is None:
                raise ConfigurationError("Top-N sampling requires 'count'")

        if self.method == "time_based":
            if self.time_column is None:
                raise ConfigurationError(
                    "Time-based sampling requires 'time_column'"
                )

        if self.method == "error_focused":
            if self.error_indicators is None:
                raise ConfigurationError(
                    "Error-focused sampling requires 'error_indicators' list"
                )

        if self.method == "reservoir":
            if self.count is None:
                raise ConfigurationError(
                    "Reservoir sampling requires 'count' (reservoir size)"
                )


@dataclass
class ValidationConfig:
    """Complete validation configuration.

    Attributes:
        checks: List of rule configurations
        plugins: List of plugin file paths
        sampling: Optional sampling configuration
        sources_file: Path to external sources YAML file
        source: Default source name for all checks
        table: Default table name for all checks
        data_source: Inline data source configuration (for single-source validation)
        reporting: Output and reporting configuration
    """

    checks: list[RuleConfig]
    plugins: list[str] | None = None
    sampling: SamplingConfig | None = None
    sources_file: str | None = None
    source: str | None = None
    table: str | None = None
    data_source: DataSourceConfig | None = None
    reporting: ReportingConfig | None = None

    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        if not self.checks:
            raise ConfigurationError("Configuration must contain at least one check")

        # Check for duplicate rule names
        names = [check.name for check in self.checks]
        duplicates = [name for name in names if names.count(name) > 1]
        if duplicates:
            raise ConfigurationError(
                f"Duplicate rule names found: {', '.join(set(duplicates))}"
            )

        # Initialize plugins list if None
        if self.plugins is None:
            self.plugins = []


class ConfigLoader:
    """Loader for YAML configuration files."""

    @staticmethod
    def load(config_path: str | Path) -> ValidationConfig:
        """Load and parse a YAML configuration file.

        Args:
            config_path: Path to the YAML configuration file

        Returns:
            ValidationConfig object

        Raises:
            ConfigurationError: If file not found, invalid YAML, or invalid schema
        """
        path = Path(config_path)

        # Check if file exists
        if not path.exists():
            raise ConfigurationError(f"Configuration file not found: {config_path}")

        if not path.is_file():
            raise ConfigurationError(f"Configuration path is not a file: {config_path}")

        # Read and parse YAML (with env-var substitution and extends resolution)
        try:
            from datacheck.config.parser import ConfigParser

            parser = ConfigParser()
            data = parser.load(path, resolve_env=True, resolve_extends=True)
        except ConfigurationError:
            raise
        except yaml.YAMLError as e:
            raise ConfigurationError(f"Invalid YAML in {config_path}: {e}") from e
        except Exception as e:
            raise ConfigurationError(f"Error reading {config_path}: {e}") from e

        # Validate schema
        if data is None:
            raise ConfigurationError(f"Configuration file is empty: {config_path}")

        if not isinstance(data, dict):
            raise ConfigurationError(
                f"Configuration must be a dictionary, got {type(data).__name__}"
            )

        if "checks" not in data:
            raise ConfigurationError("Configuration must contain 'checks' key")

        if not isinstance(data["checks"], list):
            raise ConfigurationError(
                f"'checks' must be a list, got {type(data['checks']).__name__}"
            )

        # Parse checks — collect all errors before raising
        checks = []
        check_errors: list[str] = []
        for idx, check_data in enumerate(data["checks"]):
            if not isinstance(check_data, dict):
                check_errors.append(
                    f"Check at index {idx} must be a dictionary, "
                    f"got {type(check_data).__name__}"
                )
                continue

            # Validate required fields
            missing = False
            if "name" not in check_data:
                check_errors.append(f"Check at index {idx} missing 'name' field")
                missing = True
            if "column" not in check_data:
                name = check_data.get("name", f"index {idx}")
                check_errors.append(f"Check '{name}' missing 'column' field")
                missing = True
            if "rules" not in check_data:
                name = check_data.get("name", f"index {idx}")
                check_errors.append(f"Check '{name}' missing 'rules' field")
                missing = True

            if missing:
                continue

            try:
                rule_config = RuleConfig(
                    name=check_data["name"],
                    column=check_data["column"],
                    rules=check_data["rules"],
                    source=check_data.get("source"),
                    table=check_data.get("table"),
                    severity=check_data.get("severity", "error"),
                    enabled=check_data.get("enabled", True),
                )
                # Only add enabled checks
                if rule_config.enabled:
                    checks.append(rule_config)
            except ConfigurationError as e:
                check_errors.append(str(e))
            except Exception as e:
                check_errors.append(
                    f"Error parsing check '{check_data.get('name', idx)}': {e}"
                )

        if check_errors:
            raise ConfigurationError(
                "Configuration has errors:\n  - " + "\n  - ".join(check_errors)
            )

        # Parse plugins (optional)
        plugins = data.get("plugins", [])
        if not isinstance(plugins, list):
            raise ConfigurationError("'plugins' must be a list of file paths")

        # Parse sampling (optional)
        sampling = None
        if "sampling" in data:
            sampling_data = data["sampling"]
            if not isinstance(sampling_data, dict):
                raise ConfigurationError("'sampling' must be a dictionary")

            # Parse error_indicators - can be list or comma-separated string
            error_indicators = sampling_data.get("error_indicators")
            if isinstance(error_indicators, str):
                error_indicators = [i.strip() for i in error_indicators.split(",")]

            try:
                sampling = SamplingConfig(
                    method=sampling_data.get("method", "none"),
                    rate=sampling_data.get("rate"),
                    count=sampling_data.get("count"),
                    stratify_by=sampling_data.get("stratify_by"),
                    seed=sampling_data.get("seed"),
                    # Advanced fields
                    time_column=sampling_data.get("time_column"),
                    start_date=sampling_data.get("start_date"),
                    end_date=sampling_data.get("end_date"),
                    error_indicators=error_indicators,
                    interval=sampling_data.get("interval"),
                    start=sampling_data.get("start", 0),
                )
            except ConfigurationError:
                raise
            except Exception as e:
                raise ConfigurationError(f"Error parsing sampling config: {e}") from e

        # Parse source settings (optional)
        sources_file = data.get("sources_file")
        default_source = data.get("source")
        default_table = data.get("table")

        # Parse inline data_source (optional)
        data_source = None
        if "data_source" in data:
            ds_data = data["data_source"]
            if not isinstance(ds_data, dict):
                raise ConfigurationError("'data_source' must be a dictionary")

            if "type" not in ds_data:
                raise ConfigurationError("'data_source' missing 'type' field")
            if "path" not in ds_data:
                raise ConfigurationError("'data_source' missing 'path' field")

            try:
                options = ds_data.get("options", {})
                if not isinstance(options, dict):
                    raise ConfigurationError("'data_source.options' must be a dictionary")
                data_source = DataSourceConfig(
                    type=ds_data["type"],
                    path=ds_data["path"],
                    options=options,
                )
            except ConfigurationError:
                raise
            except Exception as e:
                raise ConfigurationError(f"Error parsing data_source: {e}") from e

        # Parse reporting (optional)
        reporting = None
        if "reporting" in data:
            reporting_data = data["reporting"]
            if not isinstance(reporting_data, dict):
                raise ConfigurationError("'reporting' must be a dictionary")

            try:
                reporting = ReportingConfig(
                    output_path=reporting_data.get("output_path"),
                    export_failures=reporting_data.get("export_failures", False),
                    failures_file=reporting_data.get("failures_file"),
                )
            except ConfigurationError:
                raise
            except Exception as e:
                raise ConfigurationError(f"Error parsing reporting config: {e}") from e

        return ValidationConfig(
            checks=checks,
            plugins=plugins,
            sampling=sampling,
            sources_file=sources_file,
            source=default_source,
            table=default_table,
            data_source=data_source,
            reporting=reporting,
        )

    @staticmethod
    def find_config() -> Path | None:
        """Find configuration file in common locations.

        Searches for configuration files in the following order:
        1. .datacheck.yaml
        2. .datacheck.yml
        3. datacheck.yaml
        4. datacheck.yml

        Returns:
            Path to configuration file if found, None otherwise
        """
        search_names = [
            ".datacheck.yaml",
            ".datacheck.yml",
            "datacheck.yaml",
            "datacheck.yml",
        ]

        for name in search_names:
            path = Path(name)
            if path.exists() and path.is_file():
                return path

        return None


__all__ = [
    "DataSourceConfig",
    "ReportingConfig",
    "RuleConfig",
    "SamplingConfig",
    "ValidationConfig",
    "ConfigLoader",
]
