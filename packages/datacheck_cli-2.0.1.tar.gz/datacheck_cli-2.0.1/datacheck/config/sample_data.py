"""Sample data generators for DataCheck templates.

This module generates sample CSV data files that match the validation rules
defined in each configuration template.
"""

import csv
import random
import string
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any


def _random_string(length: int = 8, chars: str = string.ascii_uppercase + string.digits) -> str:
    """Generate a random string."""
    return "".join(random.choice(chars) for _ in range(length))


def _random_email(domain: str = "example.com") -> str:
    """Generate a random email address."""
    username = _random_string(8, string.ascii_lowercase)
    return f"{username}@{domain}"


def _random_date(start_year: int = 2020, end_year: int = 2025) -> str:
    """Generate a random date in YYYY-MM-DD format."""
    start = datetime(start_year, 1, 1)
    end = datetime(end_year, 12, 31)
    delta = end - start
    random_days = random.randint(0, delta.days)
    date = start + timedelta(days=random_days)
    return date.strftime("%Y-%m-%d")


def _random_datetime(start_year: int = 2020, end_year: int = 2025) -> str:
    """Generate a random datetime in YYYY-MM-DD HH:MM:SS format."""
    start = datetime(start_year, 1, 1)
    end = datetime(end_year, 12, 31)
    delta = end - start
    random_seconds = random.randint(0, int(delta.total_seconds()))
    dt = start + timedelta(seconds=random_seconds)
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _random_iso_datetime(start_year: int = 2020, end_year: int = 2025) -> str:
    """Generate a random ISO 8601 datetime."""
    start = datetime(start_year, 1, 1)
    end = datetime(end_year, 12, 31)
    delta = end - start
    random_seconds = random.randint(0, int(delta.total_seconds()))
    dt = start + timedelta(seconds=random_seconds)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _random_uuid() -> str:
    """Generate a random UUID-like string."""
    return f"{_random_string(8, '0123456789abcdef')}-{_random_string(4, '0123456789abcdef')}-{_random_string(4, '0123456789abcdef')}-{_random_string(4, '0123456789abcdef')}-{_random_string(12, '0123456789abcdef')}"


def _random_phone() -> str:
    """Generate a random phone number."""
    return f"+1{random.randint(2000000000, 9999999999)}"


def _random_postal_code() -> str:
    """Generate a random US postal code."""
    return f"{random.randint(10000, 99999)}"


def generate_basic_data(num_rows: int = 100) -> list[dict[str, Any]]:
    """Generate sample data for the basic template."""
    statuses = ["active", "inactive", "pending"]
    data = []

    for i in range(1, num_rows + 1):
        data.append({
            "id": i,
            "name": f"User {_random_string(6)}",
            "email": _random_email(),
            "created_at": _random_date(),
            "status": random.choice(statuses),
        })

    return data


def generate_ecommerce_data(num_rows: int = 100) -> list[dict[str, Any]]:
    """Generate sample data for the ecommerce template."""
    order_statuses = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "refunded", "returned"]
    payment_methods = ["credit_card", "debit_card", "paypal", "bank_transfer", "cash_on_delivery", "gift_card"]
    currencies = ["USD", "EUR", "GBP", "CAD", "AUD"]

    data = []

    for _ in range(1, num_rows + 1):
        quantity = random.randint(1, 10)
        unit_price = round(random.uniform(9.99, 499.99), 2)
        discount = random.randint(0, 25)
        total_price = round(quantity * unit_price * (1 - discount / 100), 2)

        data.append({
            "order_id": f"ORD-{_random_string(12)}",
            "customer_id": f"CUST-{random.randint(10000, 99999)}",
            "product_sku": f"{_random_string(3, string.ascii_uppercase)}-{random.randint(10000, 99999999)}",
            "product_name": f"Product {_random_string(8)}",
            "quantity": quantity,
            "unit_price": unit_price,
            "total_price": total_price,
            "discount": discount,
            "order_status": random.choice(order_statuses),
            "payment_method": random.choice(payment_methods),
            "shipping_address": f"{random.randint(100, 9999)} {_random_string(8)} Street, {_random_string(6)} City",
            "postal_code": _random_postal_code(),
            "order_date": _random_datetime(),
            "customer_email": _random_email(),
            "phone": _random_phone(),
            "currency": random.choice(currencies),
        })

    return data


def generate_healthcare_data(num_rows: int = 100) -> list[dict[str, Any]]:
    """Generate sample data for the healthcare template."""
    genders = ["M", "F", "Other"]
    blood_types = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]

    # Common ICD-10 codes
    diagnosis_codes = ["J06.9", "I10", "E11.9", "M54.5", "F32.9", "J45.909", "K21.0", "N39.0"]
    procedure_codes = ["99213", "99214", "99215", "99203", "99204"]

    data = []

    for _ in range(1, num_rows + 1):
        # Generate admission and discharge dates
        admission_date = _random_date(2023, 2025)
        admission_dt = datetime.strptime(admission_date, "%Y-%m-%d")
        discharge_dt = admission_dt + timedelta(days=random.randint(1, 14))
        discharge_date = discharge_dt.strftime("%Y-%m-%d")

        # Generate DOB (patients aged 18-90)
        birth_year = random.randint(1935, 2006)
        dob = f"{birth_year}-{random.randint(1, 12):02d}-{random.randint(1, 28):02d}"

        data.append({
            "patient_id": f"MRN-{random.randint(10000000, 999999999999)}",
            "ssn": f"{random.randint(100, 999)}-{random.randint(10, 99)}-{random.randint(1000, 9999)}",
            "date_of_birth": dob,
            "gender": random.choice(genders),
            "provider_npi": f"{random.randint(1000000000, 9999999999)}",
            "diagnosis_code": random.choice(diagnosis_codes),
            "secondary_diagnosis": random.choice(diagnosis_codes) if random.random() > 0.5 else "",
            "procedure_code": random.choice(procedure_codes),
            "admission_date": admission_date,
            "discharge_date": discharge_date,
            "facility_code": f"FAC-{_random_string(6, string.ascii_uppercase + string.digits)}",
            "insurance_id": f"{_random_string(3, string.ascii_uppercase)}{random.randint(10000000, 999999999999999)}",
            "blood_type": random.choice(blood_types),
            "bp_systolic": random.randint(90, 180),
            "bp_diastolic": random.randint(60, 110),
            "heart_rate": random.randint(50, 120),
            "temperature": round(random.uniform(97.0, 101.0), 1),
            "medication_dosage": round(random.uniform(5, 500), 1),
            "allergies": random.choice(["None", "Penicillin", "Sulfa", "Latex", "Peanuts", ""]),
            "emergency_phone": _random_phone(),
        })

    return data


def generate_finance_data(num_rows: int = 100) -> list[dict[str, Any]]:
    """Generate sample data for the finance template."""
    transaction_types = ["credit", "debit", "transfer", "payment", "refund", "withdrawal", "deposit", "fee"]
    statuses = ["pending", "processing", "completed", "failed", "cancelled", "reversed"]
    currencies = ["USD", "EUR", "GBP", "JPY", "CAD"]

    data = []

    for _ in range(1, num_rows + 1):
        tx_type = random.choice(transaction_types)
        amount = round(random.uniform(-10000, 50000), 2)
        if tx_type in ["credit", "deposit", "refund"]:
            amount = abs(amount)
        elif tx_type in ["debit", "withdrawal", "fee", "payment"]:
            amount = -abs(amount)

        tx_date = _random_datetime(2023, 2025)
        tx_dt = datetime.strptime(tx_date, "%Y-%m-%d %H:%M:%S")
        settlement_dt = tx_dt + timedelta(days=random.randint(1, 5))

        data.append({
            "transaction_id": f"TXN{_random_string(14, string.ascii_uppercase + string.digits)}",
            "account_number": f"{random.randint(10000000, 99999999999999999)}",
            "routing_number": f"{random.randint(100000000, 999999999)}",
            "iban": f"DE{random.randint(10, 99)}{_random_string(4, string.ascii_uppercase)}{random.randint(1000000, 9999999)}",
            "swift_code": f"{_random_string(4, string.ascii_uppercase)}{_random_string(2, string.ascii_uppercase)}{_random_string(2, string.ascii_uppercase + string.digits)}",
            "amount": amount,
            "currency": random.choice(currencies),
            "exchange_rate": round(random.uniform(0.5, 2.0), 4),
            "transaction_type": tx_type,
            "status": random.choice(statuses),
            "transaction_date": tx_date,
            "settlement_date": settlement_dt.strftime("%Y-%m-%d"),
            "customer_id": f"{_random_string(12, string.ascii_uppercase + string.digits)}",
            "merchant_category_code": f"{random.randint(1000, 9999)}",
            "card_last4": f"{random.randint(1000, 9999)}",
            "balance": round(random.uniform(100, 100000), 2),
            "interest_rate": round(random.uniform(0, 25), 2),
            "risk_score": random.randint(0, 1000),
            "is_fraud": random.choice([0, 0, 0, 0, 0, 0, 0, 0, 0, 1]),  # 10% fraud
            "reference_number": _random_string(20, string.ascii_uppercase + string.digits),
            "batch_id": f"BATCH-{datetime.now().strftime('%Y%m%d')}-{random.randint(1000, 9999)}",
        })

    return data


def generate_saas_data(num_rows: int = 100) -> list[dict[str, Any]]:
    """Generate sample data for the saas template."""
    plans = ["free", "starter", "professional", "business", "enterprise"]
    subscription_statuses = ["active", "trialing", "past_due", "cancelled", "paused", "expired"]
    roles = ["owner", "admin", "member", "viewer", "guest"]
    account_statuses = ["active", "inactive", "suspended", "pending_verification"]
    billing_cycles = ["monthly", "quarterly", "annual"]
    timezones = ["America/New_York", "America/Los_Angeles", "Europe/London", "Asia/Tokyo", "Australia/Sydney"]
    locales = ["en-US", "en-GB", "de-DE", "fr-FR", "ja-JP", "es-ES"]
    event_types = ["page_view", "button_click", "form_submit", "api_call", "login", "logout"]

    data = []

    for _ in range(1, num_rows + 1):
        plan = random.choice(plans)
        mrr = 0 if plan == "free" else random.randint(10, 5000)
        seats = 1 if plan in ["free", "starter"] else random.randint(1, 100)

        created_at = _random_iso_datetime(2020, 2024)
        created_dt = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%SZ")
        last_login_dt = created_dt + timedelta(days=random.randint(1, 365))
        trial_end_dt = created_dt + timedelta(days=14)

        data.append({
            "user_id": _random_uuid(),
            "organization_id": _random_uuid(),
            "email": _random_email(),
            "username": f"user_{_random_string(8, string.ascii_lowercase + string.digits)}",
            "subscription_plan": plan,
            "subscription_status": random.choice(subscription_statuses),
            "role": random.choice(roles),
            "account_status": random.choice(account_statuses),
            "created_at": created_at,
            "last_login_at": last_login_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "billing_cycle": random.choice(billing_cycles),
            "mrr": mrr,
            "seat_count": seats,
            "enabled_features": '["feature_a", "feature_b"]',
            "api_key": _random_string(40, string.ascii_letters + string.digits),
            "webhook_url": f"https://webhook.{_random_string(8, string.ascii_lowercase)}.com/callback",
            "timezone": random.choice(timezones),
            "locale": random.choice(locales),
            "event_type": random.choice(event_types),
            "session_id": _random_uuid(),
            "ip_address": f"{random.randint(1, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 255)}",
            "user_agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/{random.randint(90, 120)}.0.0.0",
            "referral_code": _random_string(8, string.ascii_uppercase + string.digits),
            "trial_ends_at": trial_end_dt.strftime("%Y-%m-%d"),
            "storage_used_bytes": random.randint(0, 10737418240),  # Up to 10GB
            "api_calls_count": random.randint(0, 1000000),
        })

    return data


def generate_iot_data(num_rows: int = 100) -> list[dict[str, Any]]:
    """Generate sample data for the iot template."""
    device_statuses = ["online", "offline", "standby", "error", "maintenance"]
    sensor_types = ["temperature", "humidity", "pressure", "motion", "light", "gas"]
    quality_flags = ["good", "warning", "error"]
    protocols = ["mqtt", "http", "https", "coap", "websocket"]

    data = []

    for i in range(1, num_rows + 1):
        timestamp = _random_iso_datetime(2024, 2025).replace("Z", "")
        unix_ts = int(datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S").timestamp())

        sensor_type = random.choice(sensor_types)

        # Generate realistic sensor values based on type
        temp = round(random.uniform(15, 35), 2) if sensor_type == "temperature" else round(random.uniform(-10, 50), 2)
        humidity = round(random.uniform(30, 80), 2)
        pressure = round(random.uniform(980, 1050), 2)

        data.append({
            "device_id": f"{_random_string(3, string.ascii_uppercase)}-{_random_string(12, '0123456789ABCDEF')}",
            "sensor_id": f"SENS-{random.randint(1000, 99999999)}",
            "mac_address": ":".join([f"{random.randint(0, 255):02X}" for _ in range(6)]),
            "ip_address": f"{random.randint(10, 192)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}",
            "firmware_version": f"{random.randint(1, 5)}.{random.randint(0, 15)}.{random.randint(0, 99)}",
            "timestamp": timestamp,
            "unix_timestamp": unix_ts,
            "temperature": temp,
            "humidity": humidity,
            "pressure": pressure,
            "battery_level": random.randint(10, 100),
            "rssi": random.randint(-90, -30),
            "latitude": round(random.uniform(25, 48), 6),
            "longitude": round(random.uniform(-125, -70), 6),
            "altitude": round(random.uniform(0, 3000), 2),
            "speed": round(random.uniform(0, 30), 2),
            "acceleration": round(random.uniform(-5, 5), 2),
            "voltage": round(random.uniform(3.0, 5.0), 2),
            "current": round(random.uniform(0.01, 2.0), 3),
            "power": round(random.uniform(0.1, 10), 2),
            "energy_kwh": round(random.uniform(0, 1000), 3),
            "device_status": random.choice(device_statuses),
            "sensor_type": sensor_type,
            "quality_flag": random.choice(quality_flags),
            "error_code": random.choice(["OK", "OK", "OK", "OK", "ERR-001", "ERR-002", "ERR-100"]),
            "sequence_number": i,
            "message_size_bytes": random.randint(50, 2048),
            "gateway_id": f"GW-{_random_string(10, string.ascii_uppercase + string.digits)}",
            "protocol": random.choice(protocols),
        })

    return data


# Mapping of template names to generator functions
GENERATORS = {
    "basic": generate_basic_data,
    "ecommerce": generate_ecommerce_data,
    "healthcare": generate_healthcare_data,
    "finance": generate_finance_data,
    "saas": generate_saas_data,
    "iot": generate_iot_data,
}

# Default filenames for each template
DEFAULT_FILENAMES = {
    "basic": "data.csv",
    "ecommerce": "orders.csv",
    "healthcare": "patients.csv",
    "finance": "transactions.csv",
    "saas": "users.csv",
    "iot": "sensor_data.csv",
}


def generate_sample_data(
    template: str,
    output_path: Path | str,
    num_rows: int = 100,
) -> Path:
    """Generate sample data for a template and save to CSV.

    Args:
        template: Template name (basic, ecommerce, healthcare, finance, saas, iot)
        output_path: Path where the CSV file will be saved
        num_rows: Number of sample rows to generate

    Returns:
        Path to the generated CSV file

    Raises:
        ValueError: If template is not recognized
    """
    if template not in GENERATORS:
        raise ValueError(f"Unknown template: {template}. Available: {', '.join(GENERATORS.keys())}")

    generator = GENERATORS[template]
    data = generator(num_rows)

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if data:
        fieldnames = list(data[0].keys())
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(data)

    return output_path


def get_default_filename(template: str) -> str:
    """Get the default data filename for a template."""
    return DEFAULT_FILENAMES.get(template, "data.csv")
