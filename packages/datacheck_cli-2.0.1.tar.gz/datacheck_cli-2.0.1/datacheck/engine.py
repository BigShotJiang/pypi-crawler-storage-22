"""Validation engine orchestration."""

from pathlib import Path
from typing import Any

import pandas as pd

import warnings

from datacheck.config import ConfigLoader, ValidationConfig
from datacheck.exceptions import ConfigurationError, DataLoadError, ValidationError
from datacheck.loader import LoaderFactory
from datacheck.results import RuleResult, ValidationSummary
from datacheck.rules import RuleFactory, UniqueRule
from datacheck.sampling import DataSampler


class ValidationEngine:
    """Engine for orchestrating data validation.

    The ValidationEngine coordinates the entire validation process:
    1. Loads data from various sources (CSV, Parquet, databases)
    2. Loads and parses validation configuration
    3. Creates rule instances from configuration
    4. Executes all rules against the data
    5. Aggregates results into a summary
    """

    def __init__(
        self,
        config: ValidationConfig | None = None,
        config_path: str | Path | None = None,
        parallel: bool = False,
        workers: int | None = None,
        chunk_size: int | None = None,
        show_progress: bool = True,
        notifier: Any = None,
        sources_file: str | Path | None = None,
    ) -> None:
        """Initialize validation engine.

        Args:
            config: Pre-loaded validation configuration (optional)
            config_path: Path to configuration file (optional)
            parallel: Enable parallel execution (default: False)
            workers: Number of worker processes (default: CPU count)
            chunk_size: Rows per chunk for parallel processing (default: 100000)
            show_progress: Show progress bar during parallel execution (default: True)
            notifier: Optional notifier instance (e.g., SlackNotifier) to send results
            sources_file: Path to sources YAML file (overrides config sources_file)

        Raises:
            ConfigurationError: If neither config nor config_path provided, or both provided
        """
        if config is not None and config_path is not None:
            raise ConfigurationError("Cannot provide both config and config_path")

        if config is None and config_path is None:
            # Try to auto-discover config file
            found_config = ConfigLoader.find_config()
            if found_config is None:
                raise ConfigurationError(
                    "No configuration provided and no config file found. "
                    "Searched for: .datacheck.yaml, .datacheck.yml, datacheck.yaml, datacheck.yml"
                )
            config_path = found_config

        if config_path is not None:
            self.config = ConfigLoader.load(config_path)
            self._config_dir = Path(config_path).parent
        else:
            self.config = config  # type: ignore
            self._config_dir = Path.cwd()

        # Store parallel execution settings
        self.parallel = parallel
        self.workers = workers
        self.chunk_size = chunk_size or 100000
        self.show_progress = show_progress

        # Store notifier for sending results
        self.notifier = notifier

        # Load sources if configured
        self._sources: dict[str, Any] | None = None
        effective_sources_file = sources_file or self.config.sources_file
        if effective_sources_file:
            self._load_sources(effective_sources_file)

        # Load plugins if specified
        if self.config.plugins:
            from datacheck.plugins.loader import PluginLoader

            loader = PluginLoader()

            for plugin_path in self.config.plugins:
                try:
                    loader.load_from_file(plugin_path)
                except Exception as e:
                    raise ConfigurationError(f"Failed to load plugin {plugin_path}: {e}") from e

    def _load_sources(self, sources_file: str | Path) -> None:
        """Load named sources from a YAML file.

        Args:
            sources_file: Path to the sources YAML file (absolute or relative to config dir)
        """
        from datacheck.config.source import load_sources

        sources_path = Path(sources_file)
        if not sources_path.is_absolute():
            sources_path = self._config_dir / sources_path

        self._sources = load_sources(sources_path)

    @property
    def sources(self) -> dict[str, Any] | None:
        """Get loaded source configurations."""
        return self._sources

    def validate_file(
        self,
        file_path: str | Path,
        **loader_kwargs: Any,
    ) -> ValidationSummary:
        """Validate a data file against configured rules.

        Args:
            file_path: Path to the data file to validate
            **loader_kwargs: Additional arguments passed to the data loader
                            May include sampling parameters:
                            - sample_rate: Random sample rate (0.0 to 1.0)
                            - sample_count: Number of rows to sample
                            - top: Validate only first N rows
                            - stratify: Column name for stratified sampling
                            - seed: Random seed for reproducibility

        Returns:
            ValidationSummary with aggregated results

        Raises:
            DataLoadError: If data cannot be loaded
            ValidationError: If validation fails unexpectedly
        """
        # Extract sampling parameters from loader_kwargs
        sample_rate = loader_kwargs.pop("sample_rate", None)
        sample_count = loader_kwargs.pop("sample_count", None)
        top = loader_kwargs.pop("top", None)
        stratify = loader_kwargs.pop("stratify", None)
        seed = loader_kwargs.pop("seed", None)
        # Advanced sampling parameters
        sample_strategy = loader_kwargs.pop("sample_strategy", None)
        time_column = loader_kwargs.pop("time_column", None)
        start_date = loader_kwargs.pop("start_date", None)
        end_date = loader_kwargs.pop("end_date", None)
        error_indicators = loader_kwargs.pop("error_indicators", None)

        # Collect columns referenced by rules for Parquet column pruning
        file_str = str(file_path)
        if file_str.endswith((".parquet", ".pq")) and "columns" not in loader_kwargs:
            columns_needed = {
                check.column for check in self.config.checks if check.column
            }
            if columns_needed:
                loader_kwargs["columns"] = sorted(columns_needed)

        # Load data
        try:
            df = LoaderFactory.load(file_path, **loader_kwargs)
        except DataLoadError:
            raise
        except Exception as e:
            raise DataLoadError(f"Unexpected error loading data: {e}") from e

        # Apply sampling (CLI arguments override config)
        df = self._apply_sampling(
            df,
            sample_rate=sample_rate,
            sample_count=sample_count,
            top=top,
            stratify=stratify,
            seed=seed,
            sample_strategy=sample_strategy,
            time_column=time_column,
            start_date=start_date,
            end_date=end_date,
            error_indicators=error_indicators,
        )

        # Validate the loaded data
        summary = self.validate_dataframe(df)

        # Send notification if notifier configured
        if self.notifier:
            try:
                self.notifier.send_summary(summary)
            except Exception as e:
                # Log error but don't fail validation
                warnings.warn(f"Failed to send notification: {e}", RuntimeWarning, stacklevel=2)

        return summary

    def validate_dataframe(self, df: pd.DataFrame) -> ValidationSummary:
        """Validate a DataFrame against configured rules.

        Args:
            df: DataFrame to validate

        Returns:
            ValidationSummary with aggregated results

        Raises:
            ValidationError: If validation fails unexpectedly
        """
        # Build mapping from check name to severity
        severity_map: dict[str, str] = {}
        for check_config in self.config.checks:
            severity_map[check_config.name] = check_config.severity

        # Collect all rules first
        all_rules = []
        for check_config in self.config.checks:
            try:
                rules = RuleFactory.create_rules(check_config)
                all_rules.extend(rules)
            except Exception as e:
                # If rule creation fails, create error result directly
                error_result = RuleResult(
                    rule_name=check_config.name,
                    column=check_config.column,
                    passed=False,
                    total_rows=len(df),
                    error=f"Error creating rules: {e}",
                    severity=check_config.severity,
                )
                # Return early with error if rule creation fails
                return ValidationSummary(results=[error_result])

        # Check for UniqueRule - must disable parallel to ensure correctness
        has_unique_rule = any(isinstance(rule, UniqueRule) for rule in all_rules)
        use_parallel = self.parallel and len(df) > 10000 and not has_unique_rule

        if self.parallel and len(df) > 10000 and has_unique_rule:
            warnings.warn(
                "Parallel execution disabled for unique rule to ensure correctness.",
                UserWarning,
                stacklevel=2,
            )

        # Execute rules (parallel or sequential)
        if use_parallel:
            from datacheck.parallel import ParallelExecutor

            executor = ParallelExecutor(
                workers=self.workers,
                chunk_size=self.chunk_size,
                show_progress=self.show_progress,
            )
            results = executor.validate_parallel(df, all_rules)
        else:
            # Sequential execution
            results = []
            for rule in all_rules:
                try:
                    result = rule.validate(df)
                    results.append(result)
                except Exception as e:
                    error_result = RuleResult(
                        rule_name=rule.name,
                        column=rule.column,
                        passed=False,
                        total_rows=len(df),
                        error=f"Unexpected error executing rule: {e}",
                    )
                    results.append(error_result)

        # Apply severity from check config to results
        for result in results:
            # check_name contains the original check name
            check_name = result.check_name or result.rule_name
            # Remove suffixes like _min, _max that factory may add
            base_name = check_name.replace("_min", "").replace("_max", "")
            if base_name in severity_map:
                result.severity = severity_map[base_name]
            elif check_name in severity_map:
                result.severity = severity_map[check_name]

        return ValidationSummary(
            results=results,
            total_rows=len(df),
            total_columns=len(df.columns),
        )

    def validate_sources(
        self,
        source_name: str | None = None,
        table: str | None = None,
        where: str | None = None,
        query: str | None = None,
        sample_rate: float | None = None,
        sample_count: int | None = None,
        stratify: str | None = None,
        seed: int | None = None,
        sample_strategy: str | None = None,
        time_column: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        error_indicators: list[str] | None = None,
    ) -> ValidationSummary:
        """Validate data using named source definitions.

        Groups checks by their source, loads data per source, and runs
        the appropriate checks against each dataset.

        Args:
            source_name: Source name override (overrides config source)
            table: Table name override (overrides config table)
            where: WHERE clause for database sources
            query: Custom SQL query for database sources
            sample_rate: Sample rate for database sources
            sample_count: Number of rows to sample
            stratify: Column for stratified sampling
            seed: Random seed for reproducibility
            sample_strategy: Advanced sampling strategy
            time_column: Column for time-based sampling
            start_date: Start date for time-based sampling
            end_date: End date for time-based sampling
            error_indicators: List of error indicator conditions

        Returns:
            ValidationSummary with aggregated results

        Raises:
            ConfigurationError: If sources not loaded or source not found
            DataLoadError: If data loading fails
        """
        from datacheck.config.source import SourceConfig
        from datacheck.connectors.factory import load_source_data

        if self._sources is None:
            raise ConfigurationError(
                "No sources loaded. Specify 'sources_file' in config or via --sources-file"
            )

        # Resolve default source/table from config
        default_source = source_name or self.config.source
        default_table = table or self.config.table

        # Group checks by their effective source
        source_checks: dict[str, list[Any]] = {}
        for check in self.config.checks:
            effective_source = check.source or default_source
            if not effective_source:
                raise ConfigurationError(
                    f"Check '{check.name}' has no source defined. "
                    "Set a top-level 'source' or per-check 'source' in config."
                )
            source_checks.setdefault(effective_source, []).append(check)

        # Pre-validate: verify all sources exist and connections work
        # before running any checks.  This gives a single clear error
        # instead of repeating "connection failed" for every check.
        connection_errors: list[str] = []
        for src_name in source_checks:
            if src_name not in self._sources:
                connection_errors.append(
                    f"Source '{src_name}' not found in sources file. "
                    f"Available sources: {', '.join(sorted(self._sources.keys()))}"
                )
                continue

            source_config: SourceConfig = self._sources[src_name]

            if source_config.is_database:
                # Test database connectivity
                try:
                    from datacheck.connectors.factory import create_connector

                    connector = create_connector(source_config)
                    connector.connect()
                    connector.disconnect()
                except Exception as e:
                    connection_errors.append(
                        f"Source '{src_name}' ({source_config.type}): "
                        f"Connection failed — {e}"
                    )
            elif source_config.is_file:
                # Test file accessibility
                from pathlib import Path as _Path

                file_path = source_config.connection.get("path", "")
                if file_path and not _Path(file_path).exists():
                    connection_errors.append(
                        f"Source '{src_name}' ({source_config.type}): "
                        f"File not found — {file_path}"
                    )

        if connection_errors:
            raise ConfigurationError(
                "Source connectivity check failed:\n  - "
                + "\n  - ".join(connection_errors)
            )

        # Validate each source's checks
        all_results: list[RuleResult] = []
        _total_rows = 0
        _total_columns = 0
        for src_name, checks in source_checks.items():

            source_config = self._sources[src_name]

            # Determine table for this group of checks
            # All checks in this group share the same source, but may have different tables
            # We need to sub-group by table for database sources
            if source_config.is_database:
                table_checks: dict[str | None, list[Any]] = {}
                for check in checks:
                    effective_table = check.table or default_table
                    table_checks.setdefault(effective_table, []).append(check)

                for tbl, tbl_checks in table_checks.items():
                    try:
                        df = load_source_data(
                            source_config,
                            table=tbl,
                            where=where,
                            query=query,
                            sample_rate=sample_rate,
                        )
                    except Exception as e:
                        # Create error results for all checks in this group
                        for check in tbl_checks:
                            all_results.append(RuleResult(
                                rule_name=check.name,
                                column=check.column,
                                passed=False,
                                total_rows=0,
                                error=f"Failed to load data from source '{src_name}': {e}",
                            ))
                        continue

                    # Apply sampling and validate
                    df = self._apply_sampling(
                        df,
                        sample_rate=sample_rate,
                        sample_count=sample_count,
                        stratify=stratify,
                        seed=seed,
                        sample_strategy=sample_strategy,
                        time_column=time_column,
                        start_date=start_date,
                        end_date=end_date,
                        error_indicators=error_indicators,
                    )
                    _total_rows += len(df)
                    _total_columns = max(_total_columns, len(df.columns))
                    results = self._run_checks(df, tbl_checks)
                    all_results.extend(results)
            else:
                # File/cloud sources — load once, run all checks
                try:
                    df = load_source_data(source_config)
                except Exception as e:
                    for check in checks:
                        all_results.append(RuleResult(
                            rule_name=check.name,
                            column=check.column,
                            passed=False,
                            total_rows=0,
                            error=f"Failed to load data from source '{src_name}': {e}",
                        ))
                    continue

                df = self._apply_sampling(
                    df,
                    sample_rate=sample_rate,
                    sample_count=sample_count,
                    stratify=stratify,
                    seed=seed,
                    sample_strategy=sample_strategy,
                    time_column=time_column,
                    start_date=start_date,
                    end_date=end_date,
                    error_indicators=error_indicators,
                )
                _total_rows += len(df)
                _total_columns = max(_total_columns, len(df.columns))
                results = self._run_checks(df, checks)
                all_results.extend(results)

        summary = ValidationSummary(
            results=all_results,
            total_rows=_total_rows,
            total_columns=_total_columns,
        )

        # Send notification if notifier configured
        if self.notifier:
            try:
                self.notifier.send_summary(summary)
            except Exception as e:
                warnings.warn(
                    f"Failed to send notification: {e}", RuntimeWarning, stacklevel=2
                )

        return summary

    def _run_checks(
        self, df: pd.DataFrame, checks: list[Any]
    ) -> list[RuleResult]:
        """Run a set of checks against a DataFrame.

        Args:
            df: DataFrame to validate
            checks: List of RuleConfig objects

        Returns:
            List of RuleResult objects
        """
        results: list[RuleResult] = []
        for check_config in checks:
            try:
                rules = RuleFactory.create_rules(check_config)
                for rule in rules:
                    try:
                        result = rule.validate(df)
                        results.append(result)
                    except Exception as e:
                        results.append(RuleResult(
                            rule_name=rule.name,
                            column=rule.column,
                            passed=False,
                            total_rows=len(df),
                            error=f"Unexpected error executing rule: {e}",
                        ))
            except Exception as e:
                results.append(RuleResult(
                    rule_name=check_config.name,
                    column=check_config.column,
                    passed=False,
                    total_rows=len(df),
                    error=f"Error creating rules: {e}",
                ))
        return results

    def validate(
        self,
        file_path: str | Path | None = None,
        df: pd.DataFrame | None = None,
        **loader_kwargs: Any,
    ) -> ValidationSummary:
        """Validate data from either a file or DataFrame.

        Args:
            file_path: Path to the data file (optional)
            df: DataFrame to validate (optional)
            **loader_kwargs: Additional arguments passed to the data loader

        Returns:
            ValidationSummary with aggregated results

        Raises:
            ValidationError: If neither file_path nor df provided, or both provided
            DataLoadError: If data cannot be loaded from file
        """
        if file_path is not None and df is not None:
            raise ValidationError("Cannot provide both file_path and df")

        if file_path is None and df is None:
            raise ValidationError("Must provide either file_path or df")

        if file_path is not None:
            return self.validate_file(file_path, **loader_kwargs)
        else:
            assert df is not None
            return self.validate_dataframe(df)

    def _apply_sampling(
        self,
        df: pd.DataFrame,
        sample_rate: float | None = None,
        sample_count: int | None = None,
        top: int | None = None,
        stratify: str | None = None,
        seed: int | None = None,
        sample_strategy: str | None = None,
        time_column: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        error_indicators: list[str] | None = None,
    ) -> pd.DataFrame:
        """Apply sampling to DataFrame.

        CLI arguments take precedence over config file settings.

        Args:
            df: DataFrame to sample
            sample_rate: Random sample rate (CLI argument)
            sample_count: Number of rows to sample (CLI argument)
            top: First N rows (CLI argument)
            stratify: Column for stratified sampling (CLI argument)
            seed: Random seed (CLI argument)
            sample_strategy: Advanced sampling strategy (CLI argument)
            time_column: Column for time-based sampling (CLI argument)
            start_date: Start date for time-based sampling (CLI argument)
            end_date: End date for time-based sampling (CLI argument)
            error_indicators: List of error indicator conditions (CLI argument)

        Returns:
            Sampled DataFrame (or original if no sampling configured)

        Raises:
            DataLoadError: If sampling configuration is invalid
        """
        # Check if advanced sampling strategy specified
        if sample_strategy is not None:
            return self._apply_advanced_sampling(
                df,
                sample_strategy=sample_strategy,
                sample_count=sample_count,
                stratify=stratify,
                time_column=time_column,
                start_date=start_date,
                end_date=end_date,
                error_indicators=error_indicators,
                seed=seed,
            )

        # Check if any CLI sampling arguments provided
        has_cli_sampling = any([
            sample_rate is not None,
            sample_count is not None,
            top is not None,
            stratify is not None,
        ])

        # If CLI arguments provided, use them (override config)
        if has_cli_sampling:
            # Top-N sampling
            if top is not None:
                return DataSampler.top_n(df, top)

            # Stratified sampling
            if stratify is not None:
                if sample_count is None:
                    raise DataLoadError("--stratify requires --sample-count")
                return DataSampler.stratified_sample(df, stratify, sample_count, seed=seed)

            # Random sampling
            if sample_rate is not None or sample_count is not None:
                return DataSampler.random_sample(df, rate=sample_rate, count=sample_count, seed=seed)

        # Otherwise, use config file sampling
        return self._apply_config_sampling(df)

    def _apply_advanced_sampling(
        self,
        df: pd.DataFrame,
        sample_strategy: str,
        sample_count: int | None = None,
        stratify: str | None = None,
        time_column: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        error_indicators: list[str] | None = None,
        seed: int | None = None,
    ) -> pd.DataFrame:
        """Apply advanced sampling strategy.

        Args:
            df: DataFrame to sample
            sample_strategy: Strategy name (random, stratified, time_based, error_focused, adaptive, reservoir)
            sample_count: Number of rows to sample
            stratify: Column for stratified sampling
            time_column: Column for time-based sampling
            start_date: Start date for time-based sampling
            end_date: End date for time-based sampling
            error_indicators: List of error indicator conditions
            seed: Random seed for reproducibility

        Returns:
            Sampled DataFrame

        Raises:
            DataLoadError: If required parameters are missing
        """
        from datacheck.sampling import SamplerFactory, SamplingStrategy

        try:
            strategy = SamplingStrategy(sample_strategy.lower())
        except ValueError:
            valid_strategies = [s.value for s in SamplingStrategy]
            raise DataLoadError(
                f"Invalid sampling strategy: '{sample_strategy}'. "
                f"Valid options: {', '.join(valid_strategies)}"
            )

        # Create sampler using factory
        sampler = SamplerFactory.create(strategy)

        # Configure and sample based on strategy
        if strategy == SamplingStrategy.RANDOM:
            if sample_count is None:
                sample_count = min(10000, len(df))
            return sampler.sample(df, n=sample_count, seed=seed)

        elif strategy == SamplingStrategy.STRATIFIED:
            if stratify is None:
                raise DataLoadError("--stratify column required for stratified sampling")
            if sample_count is None:
                sample_count = min(10000, len(df))
            return sampler.sample(df, n=sample_count, stratify_column=stratify, seed=seed)

        elif strategy == SamplingStrategy.TIME_BASED:
            if time_column is None:
                raise DataLoadError("--time-column required for time_based sampling")
            return sampler.sample(
                df,
                time_column=time_column,
                start_date=start_date,
                end_date=end_date,
                n=sample_count,
                seed=seed,
            )

        elif strategy == SamplingStrategy.ERROR_FOCUSED:
            if error_indicators is None:
                raise DataLoadError(
                    "--error-indicators required for error_focused sampling. "
                    "Example: 'age<0,price>10000'"
                )
            if sample_count is None:
                sample_count = min(10000, len(df))
            return sampler.sample(
                df,
                n=sample_count,
                error_indicators=error_indicators,
                seed=seed,
            )

        elif strategy == SamplingStrategy.ADAPTIVE:
            if sample_count is None:
                sample_count = min(10000, len(df))
            return sampler.sample(
                df,
                n=sample_count,
                error_indicators=error_indicators,
                seed=seed,
            )

        elif strategy == SamplingStrategy.RESERVOIR:
            if sample_count is None:
                sample_count = min(10000, len(df))
            return sampler.sample(df, k=sample_count, seed=seed)

        return df

    def _apply_config_sampling(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply sampling from config file.

        Supports all sampling methods: none, random, stratified, top, systematic,
        time_based, error_focused, adaptive, reservoir.

        Args:
            df: DataFrame to sample

        Returns:
            Sampled DataFrame (or original if no sampling configured)

        Raises:
            DataLoadError: If sampling configuration is invalid
        """
        if self.config.sampling is None:
            return df

        sampling_config = self.config.sampling

        # No sampling
        if sampling_config.method == "none":
            return df

        # Top-N sampling
        if sampling_config.method == "top":
            if sampling_config.count is None:
                raise DataLoadError("Top-N sampling requires 'count' in config")
            return DataSampler.top_n(df, sampling_config.count)

        # Stratified sampling
        if sampling_config.method == "stratified":
            if sampling_config.stratify_by is None:
                raise DataLoadError("Stratified sampling requires 'stratify_by' in config")
            if sampling_config.count is None:
                raise DataLoadError("Stratified sampling requires 'count' in config")
            return DataSampler.stratified_sample(
                df,
                sampling_config.stratify_by,
                sampling_config.count,
                seed=sampling_config.seed
            )

        # Random sampling
        if sampling_config.method == "random":
            return DataSampler.random_sample(
                df,
                rate=sampling_config.rate,
                count=sampling_config.count,
                seed=sampling_config.seed
            )

        # Systematic sampling
        if sampling_config.method == "systematic":
            # Use interval if provided, otherwise calculate from rate or use default
            if sampling_config.interval is not None:
                interval = sampling_config.interval
            elif sampling_config.rate is not None and sampling_config.rate > 0:
                interval = int(1.0 / sampling_config.rate)
            else:
                # Default to every 10th row
                interval = 10
            return DataSampler.systematic_sample(
                df, interval=interval, start=sampling_config.start
            )

        # Advanced sampling methods - use SamplerFactory
        from datacheck.sampling import SamplerFactory, SamplingStrategy

        # Time-based sampling
        if sampling_config.method == "time_based":
            if sampling_config.time_column is None:
                raise DataLoadError("Time-based sampling requires 'time_column' in config")
            sampler = SamplerFactory.create(SamplingStrategy.TIME_BASED)
            return sampler.sample(
                df,
                time_column=sampling_config.time_column,
                start_date=sampling_config.start_date,
                end_date=sampling_config.end_date,
                n=sampling_config.count,
                seed=sampling_config.seed,
            )

        # Error-focused sampling
        if sampling_config.method == "error_focused":
            if sampling_config.error_indicators is None:
                raise DataLoadError(
                    "Error-focused sampling requires 'error_indicators' in config"
                )
            sampler = SamplerFactory.create(SamplingStrategy.ERROR_FOCUSED)
            sample_count = sampling_config.count or min(10000, len(df))
            return sampler.sample(
                df,
                n=sample_count,
                error_indicators=sampling_config.error_indicators,
                seed=sampling_config.seed,
            )

        # Adaptive sampling
        if sampling_config.method == "adaptive":
            sampler = SamplerFactory.create(SamplingStrategy.ADAPTIVE)
            sample_count = sampling_config.count or min(10000, len(df))
            return sampler.sample(
                df,
                n=sample_count,
                error_indicators=sampling_config.error_indicators,
                seed=sampling_config.seed,
            )

        # Reservoir sampling
        if sampling_config.method == "reservoir":
            if sampling_config.count is None:
                raise DataLoadError("Reservoir sampling requires 'count' in config")
            sampler = SamplerFactory.create(SamplingStrategy.RESERVOIR)
            return sampler.sample(df, k=sampling_config.count, seed=sampling_config.seed)

        return df


__all__ = [
    "ValidationEngine",
]
