"""Data loaders for various formats."""

import re
import sqlite3
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pandas as pd

from datacheck.exceptions import DataLoadError, EmptyDatasetError, UnsupportedFormatError

if TYPE_CHECKING:
    from datacheck.connectors.base import DatabaseConnector

# Optional DuckDB import
try:
    import duckdb

    HAS_DUCKDB = True
except ImportError:
    HAS_DUCKDB = False

# Optional Delta Lake import
try:
    import deltalake

    HAS_DELTALAKE = True
except ImportError:
    HAS_DELTALAKE = False

# Optional Avro import
try:
    import fastavro

    HAS_FASTAVRO = True
except ImportError:
    HAS_FASTAVRO = False


class DataLoader(ABC):
    """Abstract base class for data loaders.

    Attributes:
        file_path: Path to the data file
    """

    def __init__(self, file_path: str | Path) -> None:
        """Initialize data loader.

        Args:
            file_path: Path to the data file

        Raises:
            DataLoadError: If file does not exist
        """
        self.file_path = Path(file_path)
        if not self.file_path.exists():
            raise DataLoadError(f"File not found: {file_path}")
        if not self.file_path.is_file():
            raise DataLoadError(f"Path is not a file: {file_path}")

    @abstractmethod
    def load(self) -> pd.DataFrame:
        """Load data from file into a pandas DataFrame.

        Returns:
            DataFrame containing the loaded data

        Raises:
            DataLoadError: If data cannot be loaded
            EmptyDatasetError: If loaded data is empty
        """
        pass

    def _validate_dataframe(self, df: pd.DataFrame) -> None:
        """Validate that DataFrame is not empty.

        Args:
            df: DataFrame to validate

        Raises:
            EmptyDatasetError: If DataFrame is empty
        """
        if df.empty:
            raise EmptyDatasetError(f"Dataset is empty: {self.file_path}")


class CSVLoader(DataLoader):
    """Loader for CSV files with automatic encoding detection."""

    def __init__(
        self,
        file_path: str | Path,
        encoding: str | None = None,
        delimiter: str = ",",
        **kwargs: Any,
    ) -> None:
        """Initialize CSV loader.

        Args:
            file_path: Path to the CSV file
            encoding: File encoding (auto-detected if None)
            delimiter: CSV delimiter character
            **kwargs: Additional arguments passed to pandas.read_csv
        """
        super().__init__(file_path)
        self.encoding = encoding
        self.delimiter = delimiter
        self.kwargs = kwargs

    def _detect_encoding(self) -> str:
        """Detect file encoding.

        Returns:
            Detected encoding (defaults to utf-8 if detection fails)
        """
        if self.encoding:
            return self.encoding

        # Try common encodings
        encodings = ["utf-8", "utf-8-sig", "latin-1", "iso-8859-1", "cp1252"]

        for encoding in encodings:
            try:
                with open(self.file_path, encoding=encoding) as f:
                    f.read(1024)  # Try to read first 1KB
                return encoding
            except (UnicodeDecodeError, LookupError):
                continue

        # Default to utf-8 if all fail
        return "utf-8"

    def load(self) -> pd.DataFrame:
        """Load CSV file into DataFrame.

        Returns:
            DataFrame containing CSV data

        Raises:
            DataLoadError: If CSV cannot be loaded
            EmptyDatasetError: If CSV is empty
        """
        try:
            encoding = self._detect_encoding()
            try:
                # Use PyArrow engine for faster CSV parsing + Arrow-backed dtypes
                df: pd.DataFrame = pd.read_csv(
                    self.file_path,
                    encoding=encoding,
                    delimiter=self.delimiter,
                    dtype_backend="pyarrow",
                    engine="pyarrow",
                    **self.kwargs,
                )
            except Exception:
                # Fallback to default engine for exotic encodings or edge cases
                df = pd.read_csv(
                    self.file_path,
                    encoding=encoding,
                    delimiter=self.delimiter,
                    dtype_backend="pyarrow",
                    **self.kwargs,
                )
            self._validate_dataframe(df)
            return df
        except EmptyDatasetError:
            raise
        except Exception as e:
            raise DataLoadError(f"Error loading CSV file {self.file_path}: {e}") from e


class ParquetLoader(DataLoader):
    """Loader for Parquet files."""

    def __init__(
        self,
        file_path: str | Path,
        columns: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize Parquet loader.

        Args:
            file_path: Path to the Parquet file
            columns: Optional list of columns to read (None for all)
            **kwargs: Additional arguments passed to pandas.read_parquet
        """
        super().__init__(file_path)
        self.columns = columns
        self.kwargs = kwargs

    def load(self) -> pd.DataFrame:
        """Load Parquet file into DataFrame.

        Returns:
            DataFrame containing Parquet data

        Raises:
            DataLoadError: If Parquet cannot be loaded
            EmptyDatasetError: If Parquet is empty
        """
        try:
            df = pd.read_parquet(
                self.file_path,
                columns=self.columns,
                dtype_backend="pyarrow",
                **self.kwargs,
            )
            self._validate_dataframe(df)
            return df
        except EmptyDatasetError:
            raise
        except Exception as e:
            raise DataLoadError(f"Error loading Parquet file {self.file_path}: {e}") from e


class DuckDBLoader(DataLoader):
    """Loader for DuckDB and SQLite database files."""

    # Valid pattern for table names (alphanumeric, underscore, dot for schema.table)
    _TABLE_NAME_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*(\.[a-zA-Z_][a-zA-Z0-9_]*)?$")

    def __init__(
        self, file_path: str | Path, table_name: str | None = None, query: str | None = None
    ) -> None:
        """Initialize DuckDB/SQLite loader.

        Args:
            file_path: Path to the database file
            table_name: Name of table to load (if query not provided)
            query: SQL query to execute (takes precedence over table_name)

        Raises:
            DataLoadError: If neither table_name nor query is provided
            DataLoadError: If table_name contains invalid characters
        """
        super().__init__(file_path)
        if not table_name and not query:
            raise DataLoadError("Either table_name or query must be provided")
        # Validate table_name to prevent SQL injection
        if table_name and not self._TABLE_NAME_PATTERN.match(table_name):
            raise DataLoadError(
                f"Invalid table name: {table_name}. "
                "Table names must be alphanumeric with underscores, optionally with schema prefix."
            )
        self.table_name = table_name
        self.query = query

    def _is_sqlite(self) -> bool:
        """Check if file is SQLite database.

        Returns:
            True if file is SQLite, False otherwise
        """
        try:
            with open(self.file_path, "rb") as f:
                header = f.read(16)
            return header[:6] == b"SQLite"
        except Exception:
            return False

    def _build_query(self) -> str:
        """Build SQL query from table name or use provided query.

        Returns:
            SQL query string
        """
        if self.query:
            return self.query
        return f'SELECT * FROM "{self.table_name}"'  # nosec B608

    def load(self) -> pd.DataFrame:
        """Load data from database into DataFrame.

        Returns:
            DataFrame containing database data

        Raises:
            DataLoadError: If database cannot be loaded or DuckDB is not installed
            EmptyDatasetError: If query returns no data
        """
        query = self._build_query()

        try:
            if self._is_sqlite():
                # Use sqlite3 for SQLite files
                sqlite_conn = sqlite3.connect(str(self.file_path))
                try:
                    df = pd.read_sql_query(query, sqlite_conn, dtype_backend="pyarrow")
                finally:
                    sqlite_conn.close()
            else:
                # Use DuckDB for DuckDB files
                if not HAS_DUCKDB:
                    raise DataLoadError(
                        "DuckDB is not installed. Install it with: pip install 'datacheck[duckdb]'"
                    )
                duckdb_conn = duckdb.connect(str(self.file_path), read_only=True)
                try:
                    df = duckdb_conn.execute(query).fetchdf()
                finally:
                    duckdb_conn.close()

            self._validate_dataframe(df)
            return df

        except EmptyDatasetError:
            raise
        except Exception as e:
            raise DataLoadError(
                f"Error loading database file {self.file_path}: {e}"
            ) from e


class DeltaLakeLoader:
    """Loader for Delta Lake tables with time travel and cloud storage support.

    Delta Lake is a directory-based format, so this loader works with table paths
    rather than individual files. Supports reading from local filesystem, S3, GCS,
    and Azure Blob Storage.

    Features:
        - Time travel: Load specific versions or timestamps
        - Cloud storage: S3, GCS, Azure with authentication
        - Column selection: Load only specified columns
        - Partitioning: Efficient reads with partition pruning

    Example:
        >>> loader = DeltaLakeLoader("s3://bucket/delta-table", version=5)
        >>> df = loader.load()
    """

    def __init__(
        self,
        table_path: str | Path,
        version: int | None = None,
        timestamp: str | None = None,
        columns: list[str] | None = None,
        storage_options: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize Delta Lake loader.

        Args:
            table_path: Path to Delta table (local path or cloud URI like s3://, gs://, az://)
            version: Specific version to load (time travel)
            timestamp: ISO 8601 timestamp to load data as of (time travel)
            columns: List of columns to load (None for all)
            storage_options: Cloud storage authentication options:
                - S3: {"AWS_ACCESS_KEY_ID": "...", "AWS_SECRET_ACCESS_KEY": "...", "AWS_REGION": "..."}
                - GCS: {"GOOGLE_SERVICE_ACCOUNT_KEY": "..."} or {"GOOGLE_SERVICE_ACCOUNT": "..."}
                - Azure: {"AZURE_STORAGE_ACCOUNT_NAME": "...", "AZURE_STORAGE_ACCOUNT_KEY": "..."}
            **kwargs: Additional arguments passed to DeltaTable

        Raises:
            DataLoadError: If Delta Lake is not installed
            DataLoadError: If both version and timestamp are specified
        """
        if not HAS_DELTALAKE:
            raise DataLoadError(
                "Delta Lake is not installed. Install it with: pip install 'datacheck[deltalake]'"
            )

        if version is not None and timestamp is not None:
            raise DataLoadError("Cannot specify both 'version' and 'timestamp' for time travel")

        self.table_path = str(table_path)
        self.version = version
        self.timestamp = timestamp
        self.columns = columns
        self.storage_options = storage_options or {}
        self.kwargs = kwargs

    def _is_cloud_path(self) -> bool:
        """Check if table path is a cloud URI.

        Returns:
            True if path is S3, GCS, or Azure URI
        """
        cloud_prefixes = ("s3://", "s3a://", "gs://", "az://", "abfs://", "abfss://")
        return self.table_path.startswith(cloud_prefixes)

    def _validate_path(self) -> None:
        """Validate that the Delta table path exists.

        Raises:
            DataLoadError: If local path doesn't exist
        """
        if not self._is_cloud_path():
            path = Path(self.table_path)
            if not path.exists():
                raise DataLoadError(f"Delta table not found: {self.table_path}")
            if not path.is_dir():
                raise DataLoadError(f"Delta table must be a directory: {self.table_path}")
            # Check for _delta_log directory
            if not (path / "_delta_log").exists():
                raise DataLoadError(
                    f"Invalid Delta table (missing _delta_log): {self.table_path}"
                )

    def load(self) -> pd.DataFrame:
        """Load Delta table into DataFrame.

        Returns:
            DataFrame containing Delta table data

        Raises:
            DataLoadError: If table cannot be loaded
            EmptyDatasetError: If table is empty
        """
        self._validate_path()

        try:
            # Build DeltaTable kwargs
            dt_kwargs: dict[str, Any] = {}
            if self.version is not None:
                dt_kwargs["version"] = self.version
            if self.storage_options:
                dt_kwargs["storage_options"] = self.storage_options

            # Load the Delta table
            dt = deltalake.DeltaTable(self.table_path, **dt_kwargs, **self.kwargs)

            # Handle timestamp-based time travel
            if self.timestamp is not None:
                dt.load_as_version(self.timestamp)

            # Convert to pandas DataFrame via Arrow for better performance
            try:
                arrow_table = dt.to_pyarrow_table(columns=self.columns) if self.columns else dt.to_pyarrow_table()
                df = arrow_table.to_pandas(types_mapper=pd.ArrowDtype)
            except Exception:
                # Fallback to direct conversion
                if self.columns:
                    df = dt.to_pandas(columns=self.columns)
                else:
                    df = dt.to_pandas()

            # Validate not empty
            if df.empty:
                raise EmptyDatasetError(f"Delta table is empty: {self.table_path}")

            result: pd.DataFrame = df
            return result

        except EmptyDatasetError:
            raise
        except DataLoadError:
            raise
        except Exception as e:
            raise DataLoadError(f"Error loading Delta table {self.table_path}: {e}") from e

    def load_metadata(self) -> dict[str, Any]:
        """Load Delta table metadata.

        Returns:
            Dictionary containing table metadata (version, created_time, etc.)

        Raises:
            DataLoadError: If metadata cannot be retrieved
        """
        self._validate_path()

        try:
            dt_kwargs: dict[str, Any] = {}
            if self.version is not None:
                dt_kwargs["version"] = self.version
            if self.storage_options:
                dt_kwargs["storage_options"] = self.storage_options

            dt = deltalake.DeltaTable(self.table_path, **dt_kwargs)

            return {
                "version": dt.version(),
                "file_uris": dt.file_uris(),
                "schema": str(dt.schema().to_arrow()),
                "metadata": dt.metadata(),
                "protocol": dt.protocol(),
            }
        except Exception as e:
            raise DataLoadError(f"Error getting Delta metadata {self.table_path}: {e}") from e

    def history(self, limit: int | None = None) -> list[dict[str, Any]]:
        """Get Delta table history.

        Args:
            limit: Maximum number of history entries to return

        Returns:
            List of history entries (version, timestamp, operation, etc.)

        Raises:
            DataLoadError: If history cannot be retrieved
        """
        self._validate_path()

        try:
            dt_kwargs: dict[str, Any] = {}
            if self.storage_options:
                dt_kwargs["storage_options"] = self.storage_options

            dt = deltalake.DeltaTable(self.table_path, **dt_kwargs)
            history: list[dict[str, Any]] = dt.history(limit=limit)

            return history
        except Exception as e:
            raise DataLoadError(f"Error getting Delta history {self.table_path}: {e}") from e


class AvroLoader(DataLoader):
    """Loader for Apache Avro files.

    Supports reading Avro files with optional schema validation and handles
    compressed files (deflate, snappy, etc.) automatically.

    Example:
        >>> loader = AvroLoader("data.avro")
        >>> df = loader.load()
    """

    def __init__(
        self,
        file_path: str | Path,
        reader_schema: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize Avro loader.

        Args:
            file_path: Path to the Avro file
            reader_schema: Optional Avro schema for schema evolution/projection
            **kwargs: Additional arguments passed to fastavro.reader

        Raises:
            DataLoadError: If fastavro is not installed
        """
        if not HAS_FASTAVRO:
            raise DataLoadError(
                "fastavro is not installed. Install it with: pip install 'datacheck[avro]'"
            )

        super().__init__(file_path)
        self.reader_schema = reader_schema
        self.kwargs = kwargs

    def load(self) -> pd.DataFrame:
        """Load Avro file into DataFrame.

        Returns:
            DataFrame containing Avro data

        Raises:
            DataLoadError: If Avro file cannot be loaded
            EmptyDatasetError: If Avro file is empty
        """
        try:
            records = []
            with open(self.file_path, "rb") as f:
                reader = fastavro.reader(f, reader_schema=self.reader_schema, **self.kwargs)
                for record in reader:
                    records.append(record)

            if not records:
                raise EmptyDatasetError(f"Avro file is empty: {self.file_path}")

            df = pd.DataFrame(records).convert_dtypes(dtype_backend="pyarrow")
            self._validate_dataframe(df)
            return df

        except EmptyDatasetError:
            raise
        except Exception as e:
            raise DataLoadError(f"Error loading Avro file {self.file_path}: {e}") from e

    def load_schema(self) -> dict[str, Any]:
        """Load the Avro file's schema.

        Returns:
            Dictionary containing the Avro schema

        Raises:
            DataLoadError: If schema cannot be read
        """
        try:
            with open(self.file_path, "rb") as f:
                reader = fastavro.reader(f)
                schema = reader.writer_schema
                if isinstance(schema, dict):
                    return dict(schema)
                raise DataLoadError(f"Unexpected schema type: {type(schema)}")
        except DataLoadError:
            raise
        except Exception as e:
            raise DataLoadError(f"Error reading Avro schema {self.file_path}: {e}") from e

    def validate_schema(self, expected_schema: dict[str, Any]) -> bool:
        """Validate file schema against expected schema.

        Args:
            expected_schema: The expected Avro schema to validate against

        Returns:
            True if schemas match (field names and types)

        Raises:
            DataLoadError: If schema validation fails
        """
        try:
            actual_schema = self.load_schema()

            # Extract field info for comparison
            actual_fields = {
                f["name"]: f["type"] for f in actual_schema.get("fields", [])
            }
            expected_fields = {
                f["name"]: f["type"] for f in expected_schema.get("fields", [])
            }

            return actual_fields == expected_fields
        except Exception as e:
            raise DataLoadError(f"Error validating Avro schema: {e}") from e


class DatabaseLoader(DataLoader):
    """Loader for database sources."""

    connector: "DatabaseConnector"

    def __init__(
        self,
        source: str,
        table: str | None = None,
        where: str | None = None,
        query: str | None = None
    ) -> None:
        """Initialize database loader.

        Args:
            source: Database connection string
            table: Table name to load (if not using custom query)
            where: Optional WHERE clause
            query: Optional custom SQL query
        """
        # Skip parent __init__ file-path checks; databases don't use file paths.
        # Call ABC.__init__ directly to satisfy the MRO.
        ABC.__init__(self)
        self.source = source
        self.table = table
        self.where = where
        self.query = query

        # Detect database type from connection string
        from datacheck.connectors.base import DatabaseConnector
        connector: DatabaseConnector
        if source.startswith("postgresql://") or source.startswith("postgres://"):
            from datacheck.connectors.postgresql import PostgreSQLConnector
            connector = PostgreSQLConnector(source)
        elif source.startswith("mysql://"):
            from datacheck.connectors.mysql import MySQLConnector
            connector = MySQLConnector(source)
        elif source.startswith("mssql://"):
            from datacheck.connectors.mssql import SQLServerConnector
            connector = SQLServerConnector(source)
        else:
            raise DataLoadError(f"Unsupported database type in: {source}")
        self.connector = connector

    def load(self) -> pd.DataFrame:
        """Load data from database.

        Returns:
            DataFrame containing database data

        Raises:
            DataLoadError: If loading fails
        """
        if not self.connector:
            raise DataLoadError("Database connector not initialized")

        with self.connector:
            if self.query:
                return self.connector.execute_query(self.query)
            if self.table:
                return self.connector.load_table(self.table, where=self.where)

        raise DataLoadError("Either 'table' or 'query' must be specified")


class LoaderFactory:
    """Factory for creating appropriate data loaders based on file format."""

    @staticmethod
    def create_loader(source: str | Path, **kwargs: Any) -> DataLoader | DeltaLakeLoader:
        """Create appropriate loader based on source type.

        Args:
            source: Data source (file path, connection string, or cloud URI)
            **kwargs: Additional arguments for specific loaders

        Returns:
            DataLoader instance

        Raises:
            DataLoadError: If source type cannot be determined
        """
        source_str = str(source)

        # Check if it's a database connection string
        if source_str.startswith(("postgresql://", "postgres://", "mysql://", "mssql://")):
            return DatabaseLoader(
                source_str,
                table=kwargs.get("table"),
                where=kwargs.get("where"),
                query=kwargs.get("query")
            )

        # Check if it's a Delta Lake source (delta:// protocol or cloud storage)
        delta_prefixes = ("delta://", "s3://", "s3a://", "gs://", "az://", "abfs://", "abfss://")
        if source_str.startswith(delta_prefixes):
            # Strip delta:// prefix if present, cloud paths remain as-is
            if source_str.startswith("delta://"):
                table_path = source_str[8:]  # Remove "delta://"
            else:
                table_path = source_str

            # Extract Delta-specific kwargs
            delta_kwargs = {
                k: v for k, v in kwargs.items()
                if k in ["version", "timestamp", "columns", "storage_options"]
            }
            return DeltaLakeLoader(table_path, **delta_kwargs)

        # Existing file-based logic
        source_path = Path(source)

        if not source_path.exists():
            raise DataLoadError(f"File not found: {source}")

        # Check if it's a Delta table directory
        if source_path.is_dir() and (source_path / "_delta_log").exists():
            delta_kwargs = {
                k: v for k, v in kwargs.items()
                if k in ["version", "timestamp", "columns", "storage_options"]
            }
            return DeltaLakeLoader(source_path, **delta_kwargs)

        # Must be a file for remaining loaders
        if not source_path.is_file():
            raise DataLoadError(f"Path is not a file: {source}")

        ext = source_path.suffix.lower()

        # Filter out database-specific and delta-specific kwargs for file loaders
        file_kwargs = {k: v for k, v in kwargs.items()
                      if k not in ["table", "where", "query", "version", "timestamp",
                                   "columns", "storage_options", "reader_schema"]}

        if ext == ".csv":
            return CSVLoader(source_path, **file_kwargs)
        elif ext in [".parquet", ".pq"]:
            # Pass columns for column pruning if provided
            parquet_columns = kwargs.get("columns")
            return ParquetLoader(source_path, columns=parquet_columns, **file_kwargs)
        elif ext in [".db", ".sqlite", ".sqlite3", ".duckdb"]:
            return DuckDBLoader(source_path, **file_kwargs)
        elif ext == ".avro":
            avro_kwargs = {k: v for k, v in kwargs.items()
                         if k in ["reader_schema"]}
            return AvroLoader(source_path, **avro_kwargs)
        else:
            raise UnsupportedFormatError(
                f"Unsupported file format: {ext}. "
                f"Supported formats: .csv, .parquet, .pq, .db, .duckdb, .sqlite, .sqlite3, .avro"
            )

    @staticmethod
    def load(file_path: str | Path, **kwargs: Any) -> pd.DataFrame:
        """Load data from file using appropriate loader.

        Args:
            file_path: Path to the data file
            **kwargs: Additional arguments passed to the loader

        Returns:
            DataFrame containing the loaded data

        Raises:
            UnsupportedFormatError: If file format is not supported
            DataLoadError: If data cannot be loaded
            EmptyDatasetError: If loaded data is empty
        """
        loader = LoaderFactory.create_loader(file_path, **kwargs)
        return loader.load()


__all__ = [
    "DataLoader",
    "CSVLoader",
    "ParquetLoader",
    "DuckDBLoader",
    "DeltaLakeLoader",
    "AvroLoader",
    "DatabaseLoader",
    "LoaderFactory",
]
