"""JSON formatting for profiles."""

import json
from pathlib import Path
from typing import Any

from datacheck.profiling.models import DatasetProfile


class JsonFormatter:
    """Format profile results as JSON."""

    def __init__(
        self,
        pretty: bool = True,
        indent: int = 2,
        include_suggestions: bool = True,
        include_correlations: bool = True,
    ):
        """
        Initialize formatter.

        Args:
            pretty: Whether to format with indentation
            indent: Indentation level for pretty printing
            include_suggestions: Include rule suggestions in output
            include_correlations: Include correlation matrix in output
        """
        self.pretty = pretty
        self.indent = indent if pretty else None
        self.include_suggestions = include_suggestions
        self.include_correlations = include_correlations

    def format(self, profile: DatasetProfile) -> str:
        """
        Format profile as JSON string.

        Args:
            profile: DatasetProfile to format

        Returns:
            JSON string
        """
        data = self._profile_to_dict(profile)
        return json.dumps(data, indent=self.indent, default=str)

    def save(self, profile: DatasetProfile, path: str | Path) -> None:
        """
        Save profile to JSON file.

        Args:
            profile: DatasetProfile to save
            path: Path to output file
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "w") as f:
            f.write(self.format(profile))

    def _profile_to_dict(self, profile: DatasetProfile) -> dict[str, Any]:
        """
        Convert profile to dictionary.

        Args:
            profile: DatasetProfile to convert

        Returns:
            Dictionary representation
        """
        result = {
            "name": profile.name,
            "created_at": profile.created_at.isoformat(),
            "summary": {
                "row_count": profile.row_count,
                "column_count": profile.column_count,
                "overall_quality_score": profile.overall_quality_score,
                "completeness_percentage": profile.completeness_percentage,
                "total_nulls": profile.total_nulls,
                "total_duplicates": profile.total_duplicates,
                "memory_usage_mb": profile.memory_usage_mb,
            },
            "columns": {
                name: self._column_to_dict(col)
                for name, col in profile.columns.items()
            },
        }

        if self.include_correlations:
            result["correlations"] = profile.correlations

        return result

    def _column_to_dict(self, col: Any) -> dict[str, Any]:
        """Convert column profile to dictionary."""
        result = {
            "name": col.name,
            "dtype": col.dtype,
            "total_count": col.total_count,
            "null_count": col.null_count,
            "unique_count": col.unique_count,
            "duplicate_count": col.duplicate_count,
            "null_percentage": col.null_percentage,
            "unique_percentage": col.unique_percentage,
            "completeness": col.completeness,
            "quality_score": col.quality_score,
            "issues": col.issues,
        }

        if self.include_suggestions:
            result["suggestions"] = col.suggestions

        # Add numeric stats if present
        if col.min_value is not None:
            result.update({
                "min_value": col.min_value,
                "max_value": col.max_value,
                "mean": col.mean,
                "median": col.median,
                "std_dev": col.std_dev,
                "percentile_25": col.percentile_25,
                "percentile_75": col.percentile_75,
                "outlier_count": col.outlier_count,
                "outlier_percentage": col.outlier_percentage,
            })

        # Add datetime stats if present
        if col.min_date is not None:
            result.update({
                "inferred_type": col.inferred_type,
                "min_date": col.min_date,
                "max_date": col.max_date,
            })

        # Add top values
        if col.top_values:
            result["top_values"] = [
                {"value": str(v), "count": c} for v, c in col.top_values
            ]

        return result
