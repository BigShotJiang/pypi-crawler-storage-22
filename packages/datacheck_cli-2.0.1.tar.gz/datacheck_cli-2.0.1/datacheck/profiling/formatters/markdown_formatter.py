"""Markdown formatting for profiles."""

from pathlib import Path

from datacheck.profiling.models import ColumnProfile, DatasetProfile
from datacheck.profiling.quality import QualityScorer


class MarkdownFormatter:
    """Format profile results as Markdown."""

    def __init__(
        self,
        include_suggestions: bool = True,
        include_correlations: bool = True,
    ):
        """
        Initialize formatter.

        Args:
            include_suggestions: Include rule suggestions in output
            include_correlations: Include correlation matrix in output
        """
        self.include_suggestions = include_suggestions
        self.include_correlations = include_correlations

    def format(self, profile: DatasetProfile) -> str:
        """
        Format profile as Markdown string.

        Args:
            profile: DatasetProfile to format

        Returns:
            Markdown string
        """
        lines = []

        # Title
        lines.append(f"# Data Profile: {profile.name}")
        lines.append("")
        lines.append(f"*Generated: {profile.created_at.strftime('%Y-%m-%d %H:%M:%S')}*")
        lines.append("")

        # Summary
        lines.extend(self._format_summary(profile))

        # Quality Overview
        lines.extend(self._format_quality_overview(profile))

        # Column Overview table
        lines.extend(self._format_column_overview(profile))

        # Column Profiles
        lines.extend(self._format_columns(profile))

        # Correlations
        if self.include_correlations and profile.correlations:
            lines.extend(self._format_correlations(profile))

        # Suggestions
        if self.include_suggestions:
            lines.extend(self._format_suggestions(profile))

        # Recommendations
        lines.extend(self._format_recommendations(profile))

        return "\n".join(lines)

    def save(self, profile: DatasetProfile, path: str | Path) -> None:
        """
        Save profile to Markdown file.

        Args:
            profile: DatasetProfile to save
            path: Path to output file
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "w", encoding="utf-8") as f:
            f.write(self.format(profile))

    def _format_summary(self, profile: DatasetProfile) -> list[str]:
        """Format summary section."""
        grade = QualityScorer.get_quality_grade(profile.overall_quality_score)

        lines = [
            "## Summary",
            "",
            "| Metric | Value |",
            "|--------|-------|",
            f"| Rows | {profile.row_count:,} |",
            f"| Columns | {profile.column_count} |",
            f"| Overall Quality | {profile.overall_quality_score:.1f}/100 ({grade}) |",
            f"| Completeness | {profile.completeness_percentage:.1f}% |",
            f"| Total Nulls | {profile.total_nulls:,} |",
            f"| Duplicate Rows | {profile.total_duplicates:,} |",
            f"| Memory Usage | {profile.memory_usage_mb:.2f} MB |",
            "",
        ]
        return lines

    def _format_quality_overview(self, profile: DatasetProfile) -> list[str]:
        """Format quality overview section."""
        grade = QualityScorer.get_quality_grade(profile.overall_quality_score)

        lines = [
            "## Quality Overview",
            "",
            f"**Overall Grade: {grade}** ({profile.overall_quality_score:.1f}/100)",
            "",
        ]

        # Grade distribution
        grade_counts: dict[str, int] = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0}
        for col in profile.columns.values():
            g = QualityScorer.get_quality_grade(col.quality_score)
            grade_counts[g] = grade_counts.get(g, 0) + 1

        dist_parts = []
        for g in ("A", "B", "C", "D", "F"):
            if grade_counts[g] > 0:
                dist_parts.append(f"{grade_counts[g]} {g}")
        if dist_parts:
            lines.append(f"**Grade distribution:** {', '.join(dist_parts)}")
            lines.append("")

        # Issues summary
        all_issues = []
        for col in profile.columns.values():
            for issue in col.issues:
                all_issues.append(f"- **{col.name}**: {issue}")

        if all_issues:
            lines.append("### Issues Detected")
            lines.append("")
            lines.extend(all_issues[:20])
            if len(all_issues) > 20:
                lines.append(f"- *... and {len(all_issues) - 20} more*")
            lines.append("")
        else:
            lines.append("*No significant quality issues detected.*")
            lines.append("")

        return lines

    def _format_column_overview(self, profile: DatasetProfile) -> list[str]:
        """Format column overview summary table."""
        lines = [
            "## Column Overview",
            "",
            "| Column | Type | Dtype | Quality | Completeness | Nulls | Unique |",
            "|--------|------|-------|---------|--------------|-------|--------|",
        ]

        for col in profile.columns.values():
            grade = QualityScorer.get_quality_grade(col.quality_score)
            lines.append(
                f"| {col.name} "
                f"| {col.column_type} "
                f"| {col.dtype} "
                f"| {col.quality_score:.0f} [{grade}] "
                f"| {col.completeness:.0f}% "
                f"| {col.null_count:,} ({col.null_percentage:.0f}%) "
                f"| {col.unique_count:,} ({col.unique_percentage:.0f}%) |"
            )

        lines.append("")
        return lines

    def _format_columns(self, profile: DatasetProfile) -> list[str]:
        """Format columns section."""
        lines = [
            "## Column Details",
            "",
        ]

        for col in profile.columns.values():
            lines.extend(self._format_column(col))

        return lines

    def _format_column(self, col: ColumnProfile) -> list[str]:
        """Format single column."""
        grade = QualityScorer.get_quality_grade(col.quality_score)

        lines = [
            f"### {col.name}",
            "",
            "| Metric | Value |",
            "|--------|-------|",
            f"| Type | {col.column_type} (`{col.dtype}`) |",
            f"| Quality | {col.quality_score:.1f}/100 ({grade}) |",
            f"| Total Count | {col.total_count:,} |",
            f"| Null Count | {col.null_count:,} ({col.null_percentage:.1f}%) |",
            f"| Unique Count | {col.unique_count:,} ({col.unique_percentage:.1f}%) |",
            f"| Completeness | {col.completeness:.1f}% |",
        ]

        # Numeric stats
        if col.min_value is not None:
            lines.extend([
                f"| Min | {col.min_value:.4f} |",
                f"| Max | {col.max_value:.4f} |",
                f"| Mean | {col.mean:.4f} |",
                f"| Median | {col.median:.4f} |",
                f"| Std Dev | {col.std_dev:.4f} |",
                f"| Q1 (25th) | {col.percentile_25:.4f} |",
                f"| Q3 (75th) | {col.percentile_75:.4f} |",
                f"| Outliers | {col.outlier_count} ({col.outlier_percentage:.1f}%) |",
            ])

        # Datetime stats
        if col.min_date is not None:
            lines.extend([
                f"| Min Date | {col.min_date} |",
                f"| Max Date | {col.max_date} |",
            ])

        # String length stats
        if col.str_length_min is not None:
            lines.append(
                f"| String Lengths | {col.str_length_min}-{col.str_length_max} "
                f"(avg {col.str_length_mean}) |"
            )

        # Date format
        if col.detected_date_format is not None:
            lines.append(f"| Date Format | `{col.detected_date_format}` |")

        # Weekday only
        if col.weekday_only is True:
            lines.append("| Weekdays Only | Yes |")

        lines.append("")

        # Top values
        if col.top_values:
            lines.append("**Top Values:**")
            for val, count in col.top_values[:5]:
                lines.append(f"- `{val}`: {count:,}")
            lines.append("")

        # Issues
        if col.issues:
            for issue in col.issues:
                lines.append(f"> Warning: {issue}")
            lines.append("")

        return lines

    def _format_correlations(self, profile: DatasetProfile) -> list[str]:
        """Format correlations section."""
        lines = [
            "## Correlations",
            "",
        ]

        cols = list(profile.correlations.keys())
        if not cols:
            lines.append("*No numeric columns for correlation analysis.*")
            lines.append("")
            return lines

        # Create markdown table
        header = "| |" + "|".join(f" {c} " for c in cols) + "|"
        separator = "|---|" + "|".join(["---:" for _ in cols]) + "|"

        lines.append(header)
        lines.append(separator)

        for col1 in cols:
            row = f"| **{col1}** |"
            for col2 in cols:
                if col1 == col2:
                    row += " 1.000 |"
                else:
                    corr = profile.correlations.get(col1, {}).get(col2, 0)
                    if abs(corr) >= 0.7:
                        row += f" **{corr:.3f}** |"
                    else:
                        row += f" {corr:.3f} |"
            lines.append(row)

        lines.append("")
        return lines

    def _format_suggestions(self, profile: DatasetProfile) -> list[str]:
        """Format suggestions section grouped by confidence."""
        lines = [
            "## Suggested Validation Rules",
            "",
        ]

        has_suggestions = False
        for col in profile.columns.values():
            if not col.suggestions:
                continue

            has_suggestions = True
            lines.append(f"### {col.name}")
            lines.append("")

            by_conf: dict[str, list] = {"high": [], "medium": [], "low": []}
            for s in col.suggestions:
                conf = s.get("confidence", "low")
                by_conf.setdefault(conf, []).append(s)

            conf_labels = {
                "high": "High Confidence",
                "medium": "Medium Confidence",
                "low": "Low Confidence",
            }
            for conf_level in ("high", "medium", "low"):
                suggs = by_conf.get(conf_level, [])
                if not suggs:
                    continue
                lines.append(f"#### {conf_labels[conf_level]}")
                lines.append("")
                for sugg in suggs:
                    rule = sugg["rule"]
                    reason = sugg.get("reason", "")
                    params = sugg.get("params")
                    if params is not None and not isinstance(params, (dict, list)):
                        lines.append(f"- `{rule}`: {params} — *{reason}*")
                    elif params is not None:
                        lines.append(f"- `{rule}`: {params} — *{reason}*")
                    else:
                        lines.append(f"- `{rule}` — *{reason}*")
                lines.append("")

        if not has_suggestions:
            lines.append("*No rule suggestions.*")
            lines.append("")

        return lines

    def _format_recommendations(self, profile: DatasetProfile) -> list[str]:
        """Format recommendations section."""
        recommendations = QualityScorer.recommend(profile)
        if not recommendations:
            return []

        lines = [
            "## Recommendations",
            "",
            "| Priority | Column | Issue | Action |",
            "|----------|--------|-------|--------|",
        ]

        for rec in recommendations[:15]:
            lines.append(
                f"| {rec['priority'].upper()} "
                f"| {rec['column']} "
                f"| {rec['issue']} "
                f"| {rec['action']} |"
            )

        lines.append("")
        return lines
