"""Rich terminal formatting for profiles."""

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from datacheck.profiling.models import ColumnProfile, DatasetProfile
from datacheck.profiling.quality import QualityScorer


class TerminalFormatter:
    """Format profile results for terminal display using Rich."""

    GRADE_COLORS = {"A": "green", "B": "green", "C": "yellow", "D": "red", "F": "red"}

    def __init__(
        self,
        console: Console | None = None,
        include_suggestions: bool = True,
        include_correlations: bool = True,
    ):
        """
        Initialize formatter.

        Args:
            console: Rich console instance
            include_suggestions: Include rule suggestions in output
            include_correlations: Include correlation matrix in output
        """
        self.console = console or Console()
        self.include_suggestions = include_suggestions
        self.include_correlations = include_correlations

    def format(self, profile: DatasetProfile) -> None:
        """
        Display profile in terminal.

        Args:
            profile: DatasetProfile to display
        """
        self.console.print()

        # Header panel
        self.console.print(
            Panel.fit(
                f"[bold]Data Profile: {profile.name}[/bold]",
                border_style="blue",
            )
        )
        self.console.print()

        # Dataset summary
        self._print_summary(profile)

        # Column overview table
        self._print_column_overview(profile)

        # Detailed column profiles
        self._print_column_profiles(profile)

        # Correlations
        if self.include_correlations and profile.correlations:
            self._print_correlations(profile)

        # Quality summary
        self._print_quality_summary(profile)

    def _print_summary(self, profile: DatasetProfile) -> None:
        """Print dataset summary."""
        grade = QualityScorer.get_quality_grade(profile.overall_quality_score)
        grade_color = self.GRADE_COLORS.get(grade, "white")

        table = Table(
            title="Dataset Summary",
            show_header=False,
            title_style="bold",
            padding=(0, 2),
        )
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="white")

        table.add_row("Rows", f"{profile.row_count:,}")
        table.add_row("Columns", str(profile.column_count))
        quality_str = self._format_quality_score(profile.overall_quality_score)
        table.add_row("Overall Quality", f"{quality_str} [{grade_color}]{grade}[/{grade_color}]")
        table.add_row("Completeness", self._progress_bar(profile.completeness_percentage))
        table.add_row("Total Nulls", f"{profile.total_nulls:,}")
        table.add_row("Duplicate Rows", f"{profile.total_duplicates:,}")
        table.add_row("Memory Usage", f"{profile.memory_usage_mb:.2f} MB")

        self.console.print(table)
        self.console.print()

    def _print_column_overview(self, profile: DatasetProfile) -> None:
        """Print compact column overview table."""
        table = Table(
            title="Column Overview",
            title_style="bold",
            padding=(0, 1),
        )
        table.add_column("Column", style="bold white")
        table.add_column("Type", style="cyan")
        table.add_column("Quality", justify="right")
        table.add_column("Completeness", justify="right")
        table.add_column("Nulls", justify="right")
        table.add_column("Unique", justify="right")
        table.add_column("Issues", justify="center")

        for col in profile.columns.values():
            grade = QualityScorer.get_quality_grade(col.quality_score)
            grade_color = self.GRADE_COLORS.get(grade, "white")
            quality_str = f"[{grade_color}]{col.quality_score:.0f} [{grade}][/{grade_color}]"

            completeness_str = f"{col.completeness:.0f}%"
            if col.completeness >= 95:
                completeness_str = f"[green]{completeness_str}[/green]"
            elif col.completeness >= 70:
                completeness_str = f"[yellow]{completeness_str}[/yellow]"
            else:
                completeness_str = f"[red]{completeness_str}[/red]"

            null_str = f"{col.null_count:,} ({col.null_percentage:.0f}%)"
            unique_str = f"{col.unique_count:,} ({col.unique_percentage:.0f}%)"

            issue_count = len(col.issues)
            issue_str = f"[yellow]{issue_count}[/yellow]" if issue_count > 0 else "[dim]-[/dim]"

            table.add_row(
                col.name,
                col.column_type,
                quality_str,
                completeness_str,
                null_str,
                unique_str,
                issue_str,
            )

        self.console.print(table)
        self.console.print()

    def _print_column_profiles(self, profile: DatasetProfile) -> None:
        """Print detailed column profiles."""
        self.console.print("[bold]Column Details[/bold]\n")

        for col_profile in profile.columns.values():
            self._print_column_profile(col_profile)

    def _print_column_profile(self, col: ColumnProfile) -> None:
        """Print single column profile."""
        grade = QualityScorer.get_quality_grade(col.quality_score)
        grade_color = self.GRADE_COLORS.get(grade, "white")
        quality_str = self._format_quality_score(col.quality_score)

        # Simple heading line
        self.console.print(
            f"  [bold]{col.name}[/bold] [dim]({col.column_type}, {col.dtype})[/dim] "
            f"- {quality_str} [{grade_color}]{grade}[/{grade_color}]"
        )

        # Basic stats
        self.console.print(f"    Nulls: {col.null_count:,} ({col.null_percentage:.1f}%)  "
                           f"Unique: {col.unique_count:,} ({col.unique_percentage:.1f}%)  "
                           f"Completeness: {col.completeness:.1f}%")

        # Numeric stats
        if col.min_value is not None:
            self.console.print(
                f"    Range: [{col.min_value:.2f}, {col.max_value:.2f}]  "
                f"Mean: {col.mean:.2f}  Median: {col.median:.2f}  "
                f"Std: {col.std_dev:.2f}  "
                f"Q1/Q3: {col.percentile_25:.2f}/{col.percentile_75:.2f}"
            )
            if col.outlier_count > 0:
                self.console.print(
                    f"    [yellow]Outliers: {col.outlier_count} ({col.outlier_percentage:.1f}%)[/yellow]"
                )

        # Datetime stats
        if col.min_date is not None:
            self.console.print(f"    Date range: {col.min_date} to {col.max_date}")

        # String length stats
        if col.str_length_min is not None:
            self.console.print(
                f"    Lengths: {col.str_length_min}-{col.str_length_max} "
                f"(avg {col.str_length_mean})"
            )

        # Detected date format
        if col.detected_date_format is not None:
            self.console.print(f"    Format: {col.detected_date_format}")

        # Weekday only flag
        if col.weekday_only is True:
            self.console.print("    [dim]Weekdays only[/dim]")

        # Top values
        if col.top_values:
            top_str = ", ".join(
                f"'{val}' ({count})" for val, count in col.top_values[:5]
            )
            self.console.print(f"    [dim]Top: {top_str}[/dim]")

        # Issues
        if col.issues:
            for issue in col.issues:
                self.console.print(f"    [yellow]! {issue}[/yellow]")

        # Suggestions — show all grouped by confidence
        if self.include_suggestions and col.suggestions:
            by_conf: dict[str, list] = {"high": [], "medium": [], "low": []}
            for s in col.suggestions:
                conf = s.get("confidence", "low")
                by_conf.setdefault(conf, []).append(s)

            has_any = any(by_conf.values())
            if has_any:
                self.console.print("    [bold]Suggested rules:[/bold]")
                conf_styles = {
                    "high": ("[green]HIGH[/green]", " "),
                    "medium": ("[yellow]MED[/yellow]", "  "),
                    "low": ("[dim]LOW[/dim]", "  "),
                }
                for conf_level in ("high", "medium", "low"):
                    style, pad = conf_styles[conf_level]
                    for s in by_conf.get(conf_level, []):
                        params = s.get("params")
                        reason = s.get("reason", "")
                        if params is not None and not isinstance(params, (dict, list)):
                            rule_str = f"{s['rule']}: {params}"
                        else:
                            rule_str = s["rule"]
                        reason_str = f" [dim]— {reason}[/dim]" if reason else ""
                        self.console.print(
                            f"      {style}{pad}{rule_str}{reason_str}"
                        )

        self.console.print()

    def _print_correlations(self, profile: DatasetProfile) -> None:
        """Print correlation matrix."""
        self.console.print("\n[bold]Correlations[/bold]\n")

        cols = list(profile.correlations.keys())
        if not cols:
            return

        table = Table(title="Correlation Matrix", title_style="bold")
        table.add_column("", style="cyan")

        for col in cols:
            table.add_column(col[:15], style="white", justify="right")

        for col1 in cols:
            row = [col1[:15]]
            for col2 in cols:
                if col1 == col2:
                    row.append("[dim]1.000[/dim]")
                else:
                    corr = profile.correlations.get(col1, {}).get(col2, 0)
                    if abs(corr) >= 0.7:
                        row.append(f"[red]{corr:.3f}[/red]")
                    elif abs(corr) >= 0.5:
                        row.append(f"[yellow]{corr:.3f}[/yellow]")
                    else:
                        row.append(f"{corr:.3f}")
            table.add_row(*row)

        self.console.print(table)

    def _print_quality_summary(self, profile: DatasetProfile) -> None:
        """Print quality summary."""
        self.console.print("\n[bold]Quality Summary[/bold]\n")

        # Grade distribution
        grade_counts: dict[str, int] = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0}
        for col in profile.columns.values():
            g = QualityScorer.get_quality_grade(col.quality_score)
            grade_counts[g] = grade_counts.get(g, 0) + 1

        grade_parts = []
        for g in ("A", "B", "C", "D", "F"):
            if grade_counts[g] > 0:
                color = self.GRADE_COLORS.get(g, "white")
                grade_parts.append(f"[{color}]{grade_counts[g]} {g}[/{color}]")
        if grade_parts:
            self.console.print(f"Grade distribution: {', '.join(grade_parts)}")
            self.console.print()

        # Collect issues with column names
        all_issues: list[tuple[str, str]] = []
        for col in profile.columns.values():
            for issue in col.issues:
                all_issues.append((col.name, issue))

        if all_issues:
            self.console.print(f"[yellow]Issues detected: {len(all_issues)}[/yellow]")
            for col_name, issue in all_issues[:10]:
                self.console.print(f"  [cyan]{col_name}:[/cyan] {issue}")
            if len(all_issues) > 10:
                self.console.print(f"  [dim]... and {len(all_issues) - 10} more[/dim]")
        else:
            self.console.print("[green]No significant quality issues detected.[/green]")

        # Low quality columns with score breakdown
        sorted_cols = sorted(profile.columns.values(), key=lambda c: c.quality_score)
        low_quality = [c for c in sorted_cols if c.quality_score < 80]

        if low_quality:
            self.console.print("\n[bold]Columns needing attention:[/bold]")
            for col in low_quality[:5]:
                grade = QualityScorer.get_quality_grade(col.quality_score)
                grade_color = self.GRADE_COLORS.get(grade, "white")
                self.console.print(
                    f"  {col.name}: "
                    f"{self._format_quality_score(col.quality_score)} "
                    f"[{grade_color}]{grade}[/{grade_color}]"
                )
                breakdown = QualityScorer.score_breakdown(col)
                for component, info in breakdown.items():
                    score = info["score"]
                    max_score = info["max"]
                    detail = info["detail"]
                    if score < max_score:
                        self.console.print(
                            f"    [dim]{component}: {score}/{max_score} — {detail}[/dim]"
                        )

        # Recommendations
        recommendations = QualityScorer.recommend(profile)
        if recommendations:
            self.console.print("\n[bold]Recommendations:[/bold]")
            priority_styles = {
                "high": "[red]HIGH[/red]",
                "medium": "[yellow]MED[/yellow]",
                "low": "[dim]LOW[/dim]",
            }
            for rec in recommendations[:10]:
                pstyle = priority_styles.get(rec["priority"], rec["priority"])
                self.console.print(
                    f"  {pstyle} {rec['column']}: {rec['action']} "
                    f"[dim]— {rec['issue']}[/dim]"
                )

        self.console.print()

    def _format_quality_score(self, score: float) -> str:
        """Format quality score with color."""
        if score >= 90:
            return f"[green]{score:.1f}/100[/green]"
        elif score >= 70:
            return f"[yellow]{score:.1f}/100[/yellow]"
        else:
            return f"[red]{score:.1f}/100[/red]"

    @staticmethod
    def _progress_bar(percentage: float, width: int = 15) -> str:
        """Create a progress bar string."""
        pct = max(0.0, min(100.0, percentage))
        filled = int((pct / 100) * width)
        empty = width - filled

        if pct >= 90:
            color = "green"
        elif pct >= 70:
            color = "yellow"
        else:
            color = "red"

        bar = "#" * filled + "-" * empty
        return f"[{color}]{bar}[/{color}] {pct:.1f}%"
