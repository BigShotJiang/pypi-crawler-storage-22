"""Data models for profiling results."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class ColumnProfile:
    """Profile for a single column."""

    name: str
    dtype: str

    # Counts
    total_count: int = 0
    null_count: int = 0
    unique_count: int = 0
    duplicate_count: int = 0

    # Percentages
    null_percentage: float = 0.0
    unique_percentage: float = 0.0
    completeness: float = 100.0

    # Statistics (for numeric columns)
    min_value: float | None = None
    max_value: float | None = None
    mean: float | None = None
    median: float | None = None
    std_dev: float | None = None
    percentile_25: float | None = None
    percentile_75: float | None = None

    # Distribution
    top_values: list[tuple[Any, int]] = field(default_factory=list)
    value_distribution: dict[str, int] = field(default_factory=dict)

    # Outliers
    outlier_count: int = 0
    outlier_percentage: float = 0.0
    outliers: list[Any] = field(default_factory=list)

    # Datetime stats
    inferred_type: str | None = None
    min_date: str | None = None
    max_date: str | None = None

    # String length stats (for string/object columns)
    str_length_min: int | None = None
    str_length_max: int | None = None
    str_length_mean: float | None = None

    # Datetime extras
    detected_date_format: str | None = None
    weekday_only: bool | None = None

    # Sample non-null values (for value-based rule detection)
    sample_values: list[Any] = field(default_factory=list)

    # Quality
    quality_score: float = 100.0
    issues: list[str] = field(default_factory=list)
    suggestions: list[dict[str, Any]] = field(default_factory=list)

    @property
    def column_type(self) -> str:
        """Display-friendly column type derived from inferred_type."""
        return self.inferred_type or self.dtype

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "dtype": self.dtype,
            "column_type": self.column_type,
            "total_count": self.total_count,
            "null_count": self.null_count,
            "unique_count": self.unique_count,
            "duplicate_count": self.duplicate_count,
            "null_percentage": self.null_percentage,
            "unique_percentage": self.unique_percentage,
            "completeness": self.completeness,
            "min_value": self.min_value,
            "max_value": self.max_value,
            "mean": self.mean,
            "median": self.median,
            "std_dev": self.std_dev,
            "percentile_25": self.percentile_25,
            "percentile_75": self.percentile_75,
            "top_values": [(str(v), c) for v, c in self.top_values],
            "outlier_count": self.outlier_count,
            "outlier_percentage": self.outlier_percentage,
            "inferred_type": self.inferred_type,
            "min_date": self.min_date,
            "max_date": self.max_date,
            "str_length_min": self.str_length_min,
            "str_length_max": self.str_length_max,
            "str_length_mean": self.str_length_mean,
            "detected_date_format": self.detected_date_format,
            "weekday_only": self.weekday_only,
            "quality_score": self.quality_score,
            "issues": self.issues,
            "suggestions": self.suggestions,
        }


@dataclass
class DatasetProfile:
    """Profile for entire dataset."""

    name: str
    row_count: int
    column_count: int
    created_at: datetime = field(default_factory=datetime.now)

    # Column profiles
    columns: dict[str, ColumnProfile] = field(default_factory=dict)

    # Overall quality
    overall_quality_score: float = 100.0

    # Correlations (for numeric columns)
    correlations: dict[str, dict[str, float]] = field(default_factory=dict)

    # Cross-column rules (sum_equals, unique_combination, etc.)
    cross_column_rules: list[dict[str, Any]] = field(default_factory=list)

    # Summary
    total_nulls: int = 0
    total_duplicates: int = 0
    completeness_percentage: float = 100.0
    memory_usage_mb: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "row_count": self.row_count,
            "column_count": self.column_count,
            "created_at": self.created_at.isoformat(),
            "columns": {k: v.to_dict() for k, v in self.columns.items()},
            "overall_quality_score": self.overall_quality_score,
            "correlations": self.correlations,
            "cross_column_rules": self.cross_column_rules,
            "total_nulls": self.total_nulls,
            "total_duplicates": self.total_duplicates,
            "completeness_percentage": self.completeness_percentage,
            "memory_usage_mb": self.memory_usage_mb,
        }

    @property
    def column_names(self) -> list[str]:
        """Get list of column names."""
        return list(self.columns.keys())
