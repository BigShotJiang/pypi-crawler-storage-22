"""Outlier detection methods."""

from enum import Enum
from typing import Any

import numpy as np
import pandas as pd


class OutlierMethod(Enum):
    """Outlier detection methods."""

    ZSCORE = "zscore"
    IQR = "iqr"


class OutlierDetector:
    """Detect outliers in data."""

    @staticmethod
    def detect_zscore(
        series: pd.Series,
        threshold: float = 3.0,
    ) -> tuple[list[Any], int, float]:
        """
        Detect outliers using Z-score method.

        Args:
            series: Numeric pandas Series
            threshold: Z-score threshold (default: 3.0)

        Returns:
            Tuple of (outlier_values, outlier_count, outlier_percentage)
        """
        total_count = len(series)
        non_null_count = int(series.notna().sum())

        if non_null_count == 0:
            return [], 0, 0.0

        clean_series = series.dropna()
        std = clean_series.std()
        if pd.isna(std) or float(std) == 0:
            return [], 0, 0.0

        mean = clean_series.mean()

        # Calculate Z-scores
        z_scores = np.abs((clean_series - mean) / std)

        # Find outliers
        outlier_mask = z_scores > threshold
        outliers = clean_series[outlier_mask].tolist()
        outlier_count = len(outliers)
        outlier_percentage = (outlier_count / total_count * 100) if total_count > 0 else 0.0

        # Limit to 100 examples
        return outliers[:100], outlier_count, round(outlier_percentage, 2)

    @staticmethod
    def detect_iqr(
        series: pd.Series,
        multiplier: float = 1.5,
    ) -> tuple[list[Any], int, float]:
        """
        Detect outliers using IQR (Interquartile Range) method.

        Args:
            series: Numeric pandas Series
            multiplier: IQR multiplier (default: 1.5)

        Returns:
            Tuple of (outlier_values, outlier_count, outlier_percentage)
        """
        total_count = len(series)
        non_null_count = int(series.notna().sum())

        if non_null_count == 0:
            return [], 0, 0.0

        clean_series = series.dropna()
        q1 = clean_series.quantile(0.25)
        q3 = clean_series.quantile(0.75)
        iqr = q3 - q1

        if pd.isna(iqr) or float(iqr) == 0:
            return [], 0, 0.0

        lower_bound = q1 - (multiplier * iqr)
        upper_bound = q3 + (multiplier * iqr)

        # Find outliers
        outlier_mask = (clean_series < lower_bound) | (clean_series > upper_bound)
        outliers = clean_series[outlier_mask].tolist()
        outlier_count = len(outliers)
        outlier_percentage = (outlier_count / total_count * 100) if total_count > 0 else 0.0

        # Limit to 100 examples
        return outliers[:100], outlier_count, round(outlier_percentage, 2)

    @staticmethod
    def detect(
        series: pd.Series,
        method: OutlierMethod = OutlierMethod.ZSCORE,
        threshold: float = 3.0,
        iqr_multiplier: float = 1.5,
    ) -> tuple[list[Any], int, float]:
        """
        Detect outliers using specified method.

        Args:
            series: Numeric pandas Series
            method: Detection method (ZSCORE or IQR)
            threshold: Z-score threshold
            iqr_multiplier: IQR multiplier

        Returns:
            Tuple of (outlier_values, outlier_count, outlier_percentage)
        """
        if method == OutlierMethod.ZSCORE:
            return OutlierDetector.detect_zscore(series, threshold)
        else:
            return OutlierDetector.detect_iqr(series, iqr_multiplier)
