"""Data profiling and quality analysis."""

import logging
import re
from datetime import datetime as dt

import pandas as pd

logger = logging.getLogger(__name__)

from datacheck.profiling.models import ColumnProfile, DatasetProfile
from datacheck.profiling.outliers import OutlierDetector, OutlierMethod
from datacheck.profiling.quality import QualityScorer
from datacheck.profiling.statistics import StatisticsCalculator
from datacheck.profiling.suggestions import RuleSuggester


class DataProfiler:
    """Generate comprehensive data quality profiles.

    Analyzes DataFrames to provide:
    - Column types and data types
    - Statistical summaries (numeric columns)
    - Missing value analysis
    - Cardinality and uniqueness
    - Outlier detection
    - Quality scoring
    - Rule suggestions
    - Correlation analysis

    Example:
        >>> profiler = DataProfiler()
        >>> profile = profiler.profile(df, name="my_data")
        >>> print(profile.overall_quality_score)
        >>> for col in profile.columns.values():
        ...     print(f"{col.name}: {col.inferred_type}, score={col.quality_score}")
    """

    def __init__(
        self,
        outlier_method: OutlierMethod = OutlierMethod.ZSCORE,
        outlier_threshold: float = 3.0,
        iqr_multiplier: float = 1.5,
    ):
        """
        Initialize profiler.

        Args:
            outlier_method: Method for outlier detection (ZSCORE or IQR)
            outlier_threshold: Threshold for Z-score outlier detection
            iqr_multiplier: Multiplier for IQR outlier detection
        """
        self.outlier_method = outlier_method
        self.outlier_threshold = outlier_threshold
        self.iqr_multiplier = iqr_multiplier
        self.stats_calc = StatisticsCalculator()
        self.outlier_detector = OutlierDetector()
        self.quality_scorer = QualityScorer()
        self.rule_suggester = RuleSuggester()

    def profile(self, df: pd.DataFrame, name: str = "dataset") -> DatasetProfile:
        """
        Generate comprehensive profile for DataFrame.

        Args:
            df: DataFrame to profile
            name: Name for the dataset

        Returns:
            DatasetProfile with complete analysis
        """
        # Compute memory usage once (deep=True is expensive)
        memory_bytes = df.memory_usage(deep=True).sum()

        # Initialize profile
        dataset_profile = DatasetProfile(
            name=name,
            row_count=len(df),
            column_count=len(df.columns),
            memory_usage_mb=round(memory_bytes / 1024 / 1024, 2),
        )

        # Profile each column
        for col_name in df.columns:
            col_profile = self._profile_column(df[col_name], col_name)
            dataset_profile.columns[col_name] = col_profile

        # Calculate correlations for numeric columns
        dataset_profile.correlations = self.stats_calc.calculate_correlation_matrix(df)

        # Calculate totals
        dataset_profile.total_nulls = sum(
            col.null_count for col in dataset_profile.columns.values()
        )
        dataset_profile.total_duplicates = int(df.duplicated().sum())

        total_cells = len(df) * len(df.columns)
        if total_cells > 0:
            dataset_profile.completeness_percentage = round(
                ((total_cells - dataset_profile.total_nulls) / total_cells) * 100, 2
            )
        else:
            dataset_profile.completeness_percentage = 100.0

        # Detect cross-column rules
        dataset_profile.cross_column_rules = self._detect_cross_column_rules(
            df, dataset_profile
        )

        # Calculate overall quality score
        dataset_profile.overall_quality_score = self.quality_scorer.score_dataset(
            dataset_profile
        )

        return dataset_profile

    def _profile_column(self, series: pd.Series, col_name: str) -> ColumnProfile:
        """
        Profile a single column.

        Args:
            series: Column data
            col_name: Column name

        Returns:
            ColumnProfile with complete analysis
        """
        # Initialize profile with basic counts
        counts = self.stats_calc.calculate_basic_counts(series)

        profile = ColumnProfile(
            name=col_name,
            dtype=str(series.dtype),
            total_count=int(counts["total_count"]),
            null_count=int(counts["null_count"]),
            unique_count=int(counts["unique_count"]),
            duplicate_count=int(counts["duplicate_count"]),
            null_percentage=counts["null_percentage"],
            unique_percentage=counts["unique_percentage"],
            completeness=counts["completeness"],
        )

        # Value distribution
        profile.top_values, profile.value_distribution = (
            self.stats_calc.calculate_value_counts(series)
        )

        # Type-specific analysis
        if pd.api.types.is_bool_dtype(series):
            profile.inferred_type = "boolean"

        elif pd.api.types.is_numeric_dtype(series):
            # Distinguish integer vs float types
            if pd.api.types.is_integer_dtype(series):
                profile.inferred_type = "integer"
            elif pd.api.types.is_float_dtype(series):
                # Check if all non-null values are whole numbers
                # (common when nulls force int->float promotion)
                non_null = series.dropna()
                if len(non_null) > 0 and (non_null == non_null.astype(int)).all():
                    profile.inferred_type = "integer"
                else:
                    profile.inferred_type = "numeric"
            else:
                profile.inferred_type = "numeric"
            stats = self.stats_calc.calculate_numeric_stats(series)
            profile.min_value = stats["min"]
            profile.max_value = stats["max"]
            profile.mean = stats["mean"]
            profile.median = stats["median"]
            profile.std_dev = stats["std_dev"]
            profile.percentile_25 = stats["percentile_25"]
            profile.percentile_75 = stats["percentile_75"]

            # Detect outliers
            outliers, count, percentage = self.outlier_detector.detect(
                series,
                method=self.outlier_method,
                threshold=self.outlier_threshold,
                iqr_multiplier=self.iqr_multiplier,
            )
            profile.outliers = outliers
            profile.outlier_count = count
            profile.outlier_percentage = percentage

        elif (
            pd.api.types.is_datetime64_any_dtype(series)
            or str(series.dtype).startswith("timestamp")
        ):
            profile.inferred_type = "datetime"
            non_null = series.dropna()
            if len(non_null) > 0:
                profile.min_date = str(non_null.min())
                profile.max_date = str(non_null.max())

                # Detect date format from string representation of the
                # native timestamps so that date_format rules can be suggested
                str_samples = [str(v) for v in non_null.head(20).tolist()]
                profile.detected_date_format = self._detect_date_format(
                    str_samples
                )

        elif self._is_datetime_string_column(series):
            profile.inferred_type = "datetime"
            parsed = pd.to_datetime(series, errors="coerce", format="mixed").dropna()
            if len(parsed) > 0:
                profile.min_date = str(parsed.min())
                profile.max_date = str(parsed.max())

            # Detect date format from sample values
            non_null_vals = series.dropna().head(20).tolist()
            profile.detected_date_format = self._detect_date_format(non_null_vals)

        else:
            profile.inferred_type = "categorical"

        # String length analysis (for string/object columns)
        dtype_str = str(series.dtype).lower()
        if dtype_str in ("object", "str") or dtype_str.startswith("string"):
            non_null_str = series.dropna()
            if len(non_null_str) > 0:
                lengths = non_null_str.astype(str).str.len()
                profile.str_length_min = int(lengths.min())
                profile.str_length_max = int(lengths.max())
                profile.str_length_mean = round(float(lengths.mean()), 2)

        # Weekday analysis (for datetime columns)
        if profile.inferred_type == "datetime":
            try:
                if (
                    pd.api.types.is_datetime64_any_dtype(series)
                    or str(series.dtype).startswith("timestamp")
                ):
                    dt_values = series.dropna()
                else:
                    dt_values = pd.to_datetime(
                        series, errors="coerce", format="mixed"
                    ).dropna()
                if len(dt_values) > 0:
                    profile.weekday_only = bool((dt_values.dt.dayofweek < 5).all())
            except Exception:
                logger.debug("Weekday analysis failed for column '%s'", series.name)

        # Sample values (for value-based rule detection)
        non_null_sample = series.dropna()
        if len(non_null_sample) > 0:
            profile.sample_values = non_null_sample.head(50).tolist()

        # Quality scoring
        profile.quality_score = self.quality_scorer.score_column(profile)
        profile.issues = self.quality_scorer.identify_issues(profile)

        # Rule suggestions
        profile.suggestions = self.rule_suggester.suggest_rules(profile)

        return profile

    def _detect_cross_column_rules(
        self, df: pd.DataFrame, profile: DatasetProfile
    ) -> list[dict]:
        """Detect cross-column relationships (sum_equals, unique_combination).

        Args:
            df: Original DataFrame
            profile: DatasetProfile with column profiles already computed

        Returns:
            List of cross-column rule dicts.
        """
        rules: list[dict] = []
        if len(df) < 2:
            return rules

        # --- sum_equals detection ---
        numeric_cols = [
            name for name, cp in profile.columns.items()
            if cp.inferred_type in ("numeric", "integer")
        ]
        # Only check if manageable number of columns (<=15 numeric)
        if 3 <= len(numeric_cols) <= 15:
            # Prioritize columns whose names suggest totals
            total_keywords = {"total", "sum", "amount", "gross", "net"}
            candidate_targets = [
                c for c in numeric_cols
                if any(kw in c.lower() for kw in total_keywords)
            ]
            # If no name-based candidates, try all if <=10 numeric cols
            if not candidate_targets and len(numeric_cols) <= 10:
                candidate_targets = numeric_cols

            for target in candidate_targets:
                others = [c for c in numeric_cols if c != target]
                for i, col_a in enumerate(others):
                    for col_b in others[i + 1:]:
                        try:
                            mask = (
                                df[col_a].notna()
                                & df[col_b].notna()
                                & df[target].notna()
                            )
                            valid = mask.sum()
                            if valid < 5:
                                continue
                            sum_ab = df.loc[mask, col_a] + df.loc[mask, col_b]
                            target_vals = df.loc[mask, target]
                            # Check within 1% tolerance
                            denom = target_vals.abs().replace(0, 1)
                            close = ((sum_ab - target_vals).abs() / denom) < 0.01
                            if close.sum() / valid >= 0.95:
                                rules.append({
                                    "rule": "sum_equals",
                                    "columns": [target, col_a, col_b],
                                    "params": {
                                        "column_a": col_a,
                                        "column_b": col_b,
                                    },
                                    "confidence": "high",
                                    "reason": (
                                        f"{col_a} + {col_b} = {target} "
                                        f"(verified on {valid} rows)"
                                    ),
                                })
                        except Exception:
                            logger.debug("sum_equals check failed for %s + %s = %s", col_a, col_b, target)

        # --- unique_combination detection ---
        cat_cols = [
            name for name, cp in profile.columns.items()
            if cp.inferred_type == "categorical"
            and cp.unique_count < 50
            and cp.unique_count > 1
        ]
        if 2 <= len(cat_cols) <= 10:
            for i, col_a in enumerate(cat_cols):
                for col_b in cat_cols[i + 1:]:
                    try:
                        combo = df[[col_a, col_b]].dropna()
                        if len(combo) < 5:
                            continue
                        if not combo.duplicated().any():
                            rules.append({
                                "rule": "unique_combination",
                                "columns": [col_a, col_b],
                                "params": [col_a, col_b],
                                "confidence": "medium",
                                "reason": (
                                    f"Combination of {col_a} and {col_b} "
                                    f"is unique across {len(combo)} rows"
                                ),
                            })
                    except Exception:
                        logger.debug("unique_combination check failed for %s, %s", col_a, col_b)

        return rules

    COMMON_DATE_FORMATS = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%d",
        "%m/%d/%Y",
        "%d/%m/%Y",
        "%m-%d-%Y",
        "%d-%m-%Y",
        "%Y/%m/%d",
        "%d %b %Y",
        "%d %B %Y",
        "%b %d, %Y",
        "%B %d, %Y",
        "%m/%d/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y%m%d",
        "%m/%d/%y",
        "%d/%m/%y",
    ]

    @staticmethod
    def _detect_date_format(
        sample_values: list, threshold: float = 0.8
    ) -> str | None:
        """Detect the most likely date format from sample string values.

        Args:
            sample_values: List of string date values to analyze
            threshold: Minimum fraction of values that must match (0-1)

        Returns:
            Detected format string or None
        """
        if not sample_values:
            return None

        str_values = [
            str(v).strip()
            for v in sample_values
            if v is not None and str(v).strip()
        ]
        if not str_values:
            return None

        best_format = None
        best_count = 0

        for fmt in DataProfiler.COMMON_DATE_FORMATS:
            count = 0
            for val in str_values:
                try:
                    dt.strptime(val, fmt)
                    count += 1
                except (ValueError, TypeError):
                    continue  # Value doesn't match this format
            if count > best_count:
                best_count = count
                best_format = fmt

        if best_format and best_count >= len(str_values) * threshold:
            return best_format
        return None

    @staticmethod
    def _is_datetime_string_column(
        series: pd.Series,
        sample_size: int = 20,
        threshold: float = 0.8,
    ) -> bool:
        """Check if an object-dtype column contains datetime strings.

        Samples non-null values and attempts to parse them as datetimes.

        Args:
            series: Column data (expected to be object dtype)
            sample_size: Number of non-null values to sample
            threshold: Minimum fraction of successfully parsed values (0-1)

        Returns:
            True if column likely contains datetime strings
        """
        if series.dtype != "object" and not pd.api.types.is_string_dtype(series):
            return False

        non_null = series.dropna()
        if len(non_null) < 2:
            return False

        sample = non_null.head(sample_size)

        # Reject version-like patterns (e.g., "5.0.48", "3.12.13")
        version_pattern = re.compile(r"^\d{1,4}\.\d{1,4}\.\d{1,4}$")
        version_matches = sum(1 for v in sample if version_pattern.match(str(v)))
        if version_matches / len(sample) > 0.5:
            return False

        try:
            parsed = pd.to_datetime(sample, errors="coerce", format="mixed")
            success_rate = parsed.notna().sum() / len(sample)
            return bool(success_rate >= threshold)
        except Exception:
            return False


__all__ = ["DataProfiler"]
