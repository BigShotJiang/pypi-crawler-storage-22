"""Data quality scoring."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from datacheck.profiling.models import ColumnProfile, DatasetProfile


class QualityScorer:
    """Calculate data quality scores."""

    @staticmethod
    def score_column(profile: ColumnProfile) -> float:
        """
        Calculate quality score for a column (0-100).

        Scoring criteria:
        - Completeness (no nulls): 0-40 points
        - No outliers: 0-20 points
        - Data validity: 0-20 points
        - Consistency: 0-20 points

        Args:
            profile: ColumnProfile to score

        Returns:
            Quality score 0-100
        """
        score = 100.0

        # Penalize for null values (up to -40 points)
        # 0% nulls = 0 penalty, 100% nulls = -40 penalty
        null_penalty = profile.null_percentage * 0.4
        score -= null_penalty

        # Penalize for outliers (up to -20 points)
        # 0% outliers = 0 penalty, 10%+ outliers = -20 penalty
        outlier_penalty = min(profile.outlier_percentage * 2, 20)
        score -= outlier_penalty

        # Penalize for constant values (all same value)
        if profile.unique_count == 1 and profile.total_count > 1:
            score -= 10

        # Bonus for high uniqueness in ID-like columns
        if "id" in profile.name.lower():
            if profile.unique_percentage >= 99:
                score = min(score + 5, 100)
            elif profile.unique_percentage < 95:
                score -= 10  # IDs should be mostly unique

        return max(0.0, round(score, 1))

    @staticmethod
    def score_dataset(profile: DatasetProfile) -> float:
        """
        Calculate overall dataset quality score.

        Args:
            profile: DatasetProfile to score

        Returns:
            Overall quality score 0-100
        """
        if not profile.columns:
            return 100.0

        column_scores = [col.quality_score for col in profile.columns.values()]
        avg_score = sum(column_scores) / len(column_scores)

        # Additional dataset-level penalties
        dataset_penalty = 0.0

        # Penalize for high duplicate rows
        if profile.row_count > 0:
            dup_percentage = (profile.total_duplicates / profile.row_count) * 100
            if dup_percentage > 10:
                dataset_penalty += min(dup_percentage * 0.5, 15)

        # Penalize for very low completeness
        if profile.completeness_percentage < 50:
            dataset_penalty += 10

        final_score = avg_score - dataset_penalty
        return max(0.0, round(final_score, 1))

    @staticmethod
    def identify_issues(profile: ColumnProfile) -> list[str]:
        """
        Identify data quality issues.

        Args:
            profile: ColumnProfile to analyze

        Returns:
            List of issue descriptions
        """
        issues = []

        # High null percentage
        if profile.null_percentage > 50:
            issues.append(f"Very high null percentage: {profile.null_percentage:.1f}%")
        elif profile.null_percentage > 20:
            issues.append(f"High null percentage: {profile.null_percentage:.1f}%")
        elif profile.null_percentage > 5:
            issues.append(f"Moderate null percentage: {profile.null_percentage:.1f}%")

        # Outliers
        if profile.outlier_percentage > 5:
            issues.append(f"High outlier percentage: {profile.outlier_percentage:.1f}%")
        elif profile.outlier_percentage > 1:
            issues.append(f"Contains outliers: {profile.outlier_percentage:.1f}%")

        # Constant values
        if profile.unique_count == 1 and profile.total_count > 1:
            issues.append("All values are identical (constant column)")

        # Low uniqueness for ID columns
        if "id" in profile.name.lower() and profile.unique_percentage < 95:
            issues.append(f"Low uniqueness for ID column: {profile.unique_percentage:.1f}%")

        # Very high cardinality for categorical
        if profile.unique_percentage > 95 and profile.unique_count > 100:
            if profile.dtype == "object" or "str" in profile.dtype.lower():
                issues.append(f"Very high cardinality: {profile.unique_count:,} unique values")

        return issues

    @staticmethod
    def score_breakdown(profile: ColumnProfile) -> dict[str, dict[str, Any]]:
        """
        Get component-level quality score breakdown.

        Args:
            profile: ColumnProfile to analyze

        Returns:
            Dict with component scores, max points, and detail text.
        """
        # Completeness component (max 40)
        null_penalty = profile.null_percentage * 0.4
        completeness_score = round(40 - null_penalty, 1)
        if profile.null_percentage == 0:
            completeness_detail = "No null values"
        else:
            completeness_detail = (
                f"{profile.null_percentage:.1f}% nulls"
            )

        # Outlier component (max 20)
        outlier_penalty = min(profile.outlier_percentage * 2, 20)
        outlier_score = round(20 - outlier_penalty, 1)
        if profile.outlier_percentage == 0:
            outlier_detail = "No outliers"
        else:
            outlier_detail = (
                f"{profile.outlier_percentage:.1f}% outliers"
            )

        # Consistency component (max 20)
        consistency_score = 20.0
        consistency_detail = "No issues"
        if profile.unique_count == 1 and profile.total_count > 1:
            consistency_score = 10.0
            consistency_detail = "Constant column (all values identical)"

        # Validity component (max 20)
        validity_score = 20.0
        validity_detail = "No issues"
        if "id" in profile.name.lower():
            if profile.unique_percentage >= 99:
                validity_detail = "ID column with high uniqueness"
            elif profile.unique_percentage < 95:
                validity_score = 10.0
                validity_detail = (
                    f"ID column with low uniqueness "
                    f"({profile.unique_percentage:.1f}%)"
                )

        return {
            "completeness": {
                "score": max(0, completeness_score),
                "max": 40,
                "detail": completeness_detail,
            },
            "outliers": {
                "score": max(0, outlier_score),
                "max": 20,
                "detail": outlier_detail,
            },
            "consistency": {
                "score": consistency_score,
                "max": 20,
                "detail": consistency_detail,
            },
            "validity": {
                "score": validity_score,
                "max": 20,
                "detail": validity_detail,
            },
        }

    @staticmethod
    def recommend(profile: DatasetProfile) -> list[dict[str, str]]:
        """
        Generate prioritized data quality recommendations.

        Args:
            profile: DatasetProfile to analyze

        Returns:
            List of recommendations sorted by priority (high first).
            Each dict has: priority, column, issue, action.
        """
        priority_order = {"high": 0, "medium": 1, "low": 2}
        recommendations: list[dict[str, str]] = []

        for col_name, col in profile.columns.items():
            # Null percentage checks
            if col.null_percentage > 20:
                recommendations.append({
                    "priority": "high",
                    "column": col_name,
                    "issue": f"{col.null_percentage:.1f}% null values",
                    "action": "Investigate missing data or add not_null rule",
                })
            elif col.null_percentage > 5:
                recommendations.append({
                    "priority": "medium",
                    "column": col_name,
                    "issue": f"{col.null_percentage:.1f}% null values",
                    "action": "Review missing data patterns",
                })

            # Outlier checks
            if col.outlier_percentage > 5:
                recommendations.append({
                    "priority": "medium",
                    "column": col_name,
                    "issue": f"{col.outlier_percentage:.1f}% outliers",
                    "action": "Review outliers; consider range validation",
                })

            # Constant column
            if col.unique_count == 1 and col.total_count > 1:
                recommendations.append({
                    "priority": "low",
                    "column": col_name,
                    "issue": "All values are identical",
                    "action": "Consider removing constant column",
                })

            # ID column uniqueness
            if "id" in col_name.lower() and col.unique_percentage < 95:
                recommendations.append({
                    "priority": "high",
                    "column": col_name,
                    "issue": (
                        f"ID column with {col.unique_percentage:.1f}% uniqueness"
                    ),
                    "action": "Investigate duplicate IDs",
                })

        recommendations.sort(key=lambda r: priority_order.get(r["priority"], 9))
        return recommendations

    @staticmethod
    def get_quality_grade(score: float) -> str:
        """
        Get letter grade for quality score.

        Args:
            score: Quality score 0-100

        Returns:
            Letter grade (A, B, C, D, F)
        """
        if score >= 90:
            return "A"
        elif score >= 80:
            return "B"
        elif score >= 70:
            return "C"
        elif score >= 60:
            return "D"
        else:
            return "F"
