"""Statistical calculations for profiling."""

from typing import Any

import pandas as pd


class StatisticsCalculator:
    """Calculate statistics for data profiling."""

    @staticmethod
    def calculate_numeric_stats(series: pd.Series) -> dict[str, Any]:
        """
        Calculate statistics for numeric column.

        Args:
            series: Pandas Series (numeric)

        Returns:
            Dict with statistics
        """
        clean_series = series.dropna()

        if len(clean_series) == 0:
            return {
                "min": None,
                "max": None,
                "mean": None,
                "median": None,
                "std_dev": None,
                "percentile_25": None,
                "percentile_50": None,
                "percentile_75": None,
            }

        # Single-pass computation via describe()
        desc = clean_series.describe(percentiles=[0.25, 0.5, 0.75])
        return {
            "min": float(desc["min"]),
            "max": float(desc["max"]),
            "mean": round(float(desc["mean"]), 4),
            "median": float(desc["50%"]),
            "std_dev": round(float(desc["std"]), 4) if len(clean_series) > 1 else 0.0,
            "percentile_25": float(desc["25%"]),
            "percentile_50": float(desc["50%"]),
            "percentile_75": float(desc["75%"]),
        }

    @staticmethod
    def calculate_value_counts(
        series: pd.Series,
        top_n: int = 10,
    ) -> tuple[list[tuple[Any, int]], dict[str, int]]:
        """
        Calculate value frequencies.

        Args:
            series: Pandas Series
            top_n: Number of top values to return

        Returns:
            Tuple of (top_values_list, full_distribution_dict)
        """
        value_counts = series.value_counts()

        # Top N values as list of tuples
        top_values = [(val, int(count)) for val, count in value_counts.head(top_n).items()]

        # Distribution as dict (limit to top 100 for memory)
        distribution = {str(k): int(v) for k, v in value_counts.head(100).items()}

        return top_values, distribution

    @staticmethod
    def calculate_correlation_matrix(df: pd.DataFrame) -> dict[str, dict[str, float]]:
        """
        Calculate correlation matrix for numeric columns.

        Args:
            df: DataFrame with numeric columns

        Returns:
            Nested dict: {col1: {col2: correlation, ...}, ...}
        """
        # Use "number" string selector to capture both NumPy and Arrow numeric types
        numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()

        if len(numeric_cols) < 2:
            return {}

        corr_matrix = df[numeric_cols].corr()

        # Convert to nested dict
        result: dict[str, dict[str, float]] = {}
        for col1 in corr_matrix.index:
            result[col1] = {}
            for col2 in corr_matrix.columns:
                if col1 != col2:  # Don't include self-correlation
                    corr_val = corr_matrix.loc[col1, col2]
                    # Handle NaN correlations
                    if pd.notna(corr_val):
                        result[col1][col2] = round(float(corr_val), 3)

        return result

    @staticmethod
    def calculate_basic_counts(series: pd.Series) -> dict[str, int | float]:
        """
        Calculate basic counts for a series.

        Args:
            series: Pandas Series

        Returns:
            Dict with counts
        """
        total_count = len(series)
        null_count = int(series.isnull().sum())
        unique_count = int(series.nunique())
        duplicate_count = total_count - unique_count

        null_percentage = (null_count / total_count * 100) if total_count > 0 else 0.0
        unique_percentage = (unique_count / total_count * 100) if total_count > 0 else 0.0
        completeness = 100.0 - null_percentage

        return {
            "total_count": total_count,
            "null_count": null_count,
            "unique_count": unique_count,
            "duplicate_count": duplicate_count,
            "null_percentage": round(null_percentage, 2),
            "unique_percentage": round(unique_percentage, 2),
            "completeness": round(completeness, 2),
        }
