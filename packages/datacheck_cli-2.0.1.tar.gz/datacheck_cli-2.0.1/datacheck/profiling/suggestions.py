"""Auto-suggest validation rules based on profile."""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timedelta
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from datacheck.profiling.models import ColumnProfile


# Column-name keyword rules for semantic type detection.
# Each entry maps column name keywords to a validation rule.
_NAME_BASED_RULES: list[dict[str, Any]] = [
    {
        "rule": "email_valid",
        "keywords": ["email", "mail", "e_mail"],
        "confidence": "high",
        "reason": "Column name suggests email addresses",
    },
    {
        "rule": "phone_valid",
        "keywords": ["phone", "tel", "mobile", "cell"],
        "confidence": "high",
        "reason": "Column name suggests phone numbers",
    },
    {
        "rule": "url_valid",
        "keywords": ["url", "link", "website", "href"],
        "confidence": "high",
        "reason": "Column name suggests URLs",
    },
]


class RuleSuggester:
    """Suggest validation rules based on data profile.

    Analyzes column profiles to suggest applicable validation rules
    with confidence levels and reasoning. Suggestions use parameter
    formats compatible with the RuleFactory.
    """

    @staticmethod
    def suggest_rules(profile: ColumnProfile) -> list[dict[str, Any]]:
        """
        Suggest validation rules for a column.

        Args:
            profile: ColumnProfile to analyze

        Returns:
            List of suggested rules with confidence and reasoning.
            Each dict has keys: rule, confidence, reason, and optionally params.
        """
        suggestions: list[dict[str, Any]] = []

        # --- Null analysis ---
        if profile.null_percentage < 1:
            suggestions.append({
                "rule": "not_null",
                "confidence": "high",
                "reason": f"No null values detected ({profile.null_percentage:.1f}%)",
            })
        elif profile.null_percentage < 5:
            suggestions.append({
                "rule": "not_null",
                "confidence": "medium",
                "reason": f"Very few null values ({profile.null_percentage:.1f}%)",
            })

        # --- Uniqueness ---
        if profile.unique_percentage >= 99.9:
            suggestions.append({
                "rule": "unique",
                "confidence": "high",
                "reason": f"All values are unique ({profile.unique_percentage:.1f}%)",
            })
        elif profile.unique_percentage >= 95:
            suggestions.append({
                "rule": "unique",
                "confidence": "medium",
                "reason": f"Most values are unique ({profile.unique_percentage:.1f}%)",
            })

        # --- Type inference ---
        inferred = getattr(profile, "inferred_type", None)
        if inferred:
            type_map = {
                "integer": "int",
                "numeric": "numeric",
                "boolean": "bool",
                "datetime": "date",
            }
            if inferred in type_map:
                suggestions.append({
                    "rule": "type",
                    "params": type_map[inferred],
                    "confidence": "high",
                    "reason": f"Column detected as {inferred}",
                })

        # --- Numeric rules ---
        if profile.min_value is not None and profile.max_value is not None:
            # Use IQR-based Tukey fences when outliers push raw bounds too wide
            use_iqr = (
                profile.outlier_percentage > 5
                and profile.percentile_25 is not None
                and profile.percentile_75 is not None
            )

            if use_iqr:
                assert profile.percentile_75 is not None and profile.percentile_25 is not None
                iqr = profile.percentile_75 - profile.percentile_25
                lower_fence = round(profile.percentile_25 - 1.5 * iqr, 2)
                upper_fence = round(profile.percentile_75 + 1.5 * iqr, 2)
                suggestions.append({
                    "rule": "min",
                    "params": lower_fence,
                    "confidence": "high",
                    "reason": (
                        f"Outlier-resistant lower bound (IQR method, "
                        f"{profile.outlier_percentage:.1f}% outliers excluded)"
                    ),
                })
                suggestions.append({
                    "rule": "max",
                    "params": upper_fence,
                    "confidence": "high",
                    "reason": (
                        f"Outlier-resistant upper bound (IQR method, "
                        f"{profile.outlier_percentage:.1f}% outliers excluded)"
                    ),
                })
            else:
                # min
                if profile.min_value >= 0:
                    suggestions.append({
                        "rule": "min",
                        "params": 0,
                        "confidence": "high",
                        "reason": f"All values are non-negative (min: {profile.min_value})",
                    })
                else:
                    suggestions.append({
                        "rule": "min",
                        "params": profile.min_value,
                        "confidence": "medium",
                        "reason": f"Observed minimum: {profile.min_value}",
                    })

                # max
                suggestions.append({
                    "rule": "max",
                    "params": profile.max_value,
                    "confidence": "medium",
                    "reason": f"Observed maximum: {profile.max_value}",
                })

        # mean_between (numeric with sufficient data)
        if (
            profile.mean is not None
            and profile.std_dev is not None
            and profile.std_dev > 0
        ):
            margin = profile.std_dev * 2
            suggestions.append({
                "rule": "mean_between",
                "params": {
                    "min": round(profile.mean - margin, 2),
                    "max": round(profile.mean + margin, 2),
                },
                "confidence": "medium",
                "reason": (
                    f"Mean {profile.mean:.2f} ± 2 std devs "
                    f"({profile.std_dev:.2f})"
                ),
            })

        # std_dev_less_than (numeric with variation)
        if profile.std_dev is not None and profile.std_dev > 0:
            threshold = round(profile.std_dev * 1.5, 2)
            suggestions.append({
                "rule": "std_dev_less_than",
                "params": threshold,
                "confidence": "low",
                "reason": f"Observed std dev: {profile.std_dev:.2f}, threshold at 1.5x",
            })

        # z_score_outliers (when outliers detected)
        if profile.outlier_count > 0 and profile.outlier_percentage > 0:
            suggestions.append({
                "rule": "z_score_outliers",
                "params": 3.0,
                "confidence": "medium",
                "reason": (
                    f"{profile.outlier_count} outliers detected "
                    f"({profile.outlier_percentage:.1f}%)"
                ),
            })

        # percentile_range (numeric with percentiles)
        if profile.percentile_25 is not None and profile.percentile_75 is not None:
            iqr = profile.percentile_75 - profile.percentile_25
            if iqr > 0:
                margin = iqr * 0.5
                suggestions.append({
                    "rule": "percentile_range",
                    "params": {
                        "p25_min": round(profile.percentile_25 - margin, 2),
                        "p25_max": round(profile.percentile_25 + margin, 2),
                        "p75_min": round(profile.percentile_75 - margin, 2),
                        "p75_max": round(profile.percentile_75 + margin, 2),
                    },
                    "confidence": "low",
                    "reason": (
                        f"P25={profile.percentile_25:.2f}, "
                        f"P75={profile.percentile_75:.2f}, IQR={iqr:.2f}"
                    ),
                })

        # --- Categorical / allowed_values ---
        if 2 <= profile.unique_count <= 10 and profile.top_values:
            allowed_values = [val for val, _ in profile.top_values]
            suggestions.append({
                "rule": "allowed_values",
                "params": allowed_values,
                "confidence": "high" if profile.unique_count <= 5 else "medium",
                "reason": f"Only {profile.unique_count} unique values",
            })

        # --- String length rules ---
        str_min = getattr(profile, "str_length_min", None)
        str_max = getattr(profile, "str_length_max", None)
        if str_min is not None and str_max is not None and str_min != str_max:
            # Suggest length bounds with margin
            margin = max(1, int((str_max - str_min) * 0.2))
            suggested_max = str_max + margin
            suggestions.append({
                "rule": "length",
                "params": {"min": max(1, str_min), "max": suggested_max},
                "confidence": "medium",
                "reason": (
                    f"String lengths range from {str_min} to {str_max}"
                ),
            })
        elif str_min is not None and str_min == str_max and str_min > 0:
            # Fixed-length strings (codes, IDs)
            suggestions.append({
                "rule": "length",
                "params": {"min": str_min, "max": str_min},
                "confidence": "high",
                "reason": f"All strings are exactly {str_min} characters",
            })

        # --- Date format (with detected pattern) ---
        detected_fmt = getattr(profile, "detected_date_format", None)
        is_string_dtype = (
            profile.dtype in ("object", "str")
            or profile.dtype.startswith("string")
        )
        if detected_fmt:
            # Format detected from values — works for both string columns
            # and native datetime/PyArrow timestamp columns
            suggestions.append({
                "rule": "date_format",
                "params": detected_fmt,
                "confidence": "high",
                "reason": f"Detected date format: {detected_fmt}",
            })
        elif (
            "date" in profile.name.lower() or "time" in profile.name.lower()
        ) and is_string_dtype:
            suggestions.append({
                "rule": "date_format",
                "confidence": "medium",
                "reason": "Column name suggests date/time values",
            })
        elif (
            inferred == "datetime"
            and is_string_dtype
            and not detected_fmt
        ):
            suggestions.append({
                "rule": "date_format",
                "confidence": "high",
                "reason": "Column values detected as datetime strings",
            })

        # --- Temporal rules ---
        if profile.min_date is not None and profile.max_date is not None:
            # timestamp_range — add 1-day margin on each side so edge
            # values don't fail due to profiling-time rounding
            min_date_str = profile.min_date.split(" ")[0]
            max_date_str = profile.max_date.split(" ")[0]
            try:
                min_dt = datetime.fromisoformat(min_date_str)
                max_dt = datetime.fromisoformat(max_date_str)
                min_date_str = (min_dt - timedelta(days=1)).strftime("%Y-%m-%d")
                max_date_str = (max_dt + timedelta(days=1)).strftime("%Y-%m-%d")
            except (ValueError, TypeError):
                pass  # Keep original strings if parsing fails
            suggestions.append({
                "rule": "timestamp_range",
                "params": {
                    "min": min_date_str,
                    "max": max_date_str,
                },
                "confidence": "medium",
                "reason": f"Dates range from {profile.min_date} to {profile.max_date}",
            })

            # no_future_timestamps
            try:
                max_dt = datetime.fromisoformat(
                    str(profile.max_date).replace("Z", "+00:00")
                )
                if max_dt <= datetime.now(max_dt.tzinfo):
                    suggestions.append({
                        "rule": "no_future_timestamps",
                        "confidence": "high",
                        "reason": "No future dates detected in data",
                    })
            except (ValueError, TypeError):
                logger.debug("Failed to parse max_date for no_future_timestamps check")

        # business_days_only
        weekday_only = getattr(profile, "weekday_only", None)
        if weekday_only is True and profile.inferred_type == "datetime":
            suggestions.append({
                "rule": "business_days_only",
                "confidence": "medium",
                "reason": "All dates fall on weekdays (Mon-Fri)",
            })

        # --- Name-based semantic rules ---
        col_lower = profile.name.lower()
        existing_rules = {s["rule"] for s in suggestions}

        for rule_def in _NAME_BASED_RULES:
            if rule_def["rule"] in existing_rules:
                continue
            if any(kw in col_lower for kw in rule_def["keywords"]):
                suggestions.append({
                    "rule": rule_def["rule"],
                    "confidence": rule_def["confidence"],
                    "reason": rule_def["reason"],
                })
                existing_rules.add(rule_def["rule"])

        # --- Regex pattern detection (before value-based, so phone/email
        #     detection can skip when a regex pattern is already matched) ---
        sample = getattr(profile, "sample_values", [])
        if sample and inferred == "categorical":
            _suggest_regex_patterns(suggestions, sample)

        # --- Value-based semantic detection ---
        if sample and inferred == "categorical":
            _suggest_from_values(suggestions, sample)

        # --- JSON detection ---
        if sample and inferred == "categorical":
            json_count = 0
            for v in sample[:20]:
                s = str(v).strip()
                if s.startswith("{") or s.startswith("["):
                    try:
                        json.loads(s)
                        json_count += 1
                    except (json.JSONDecodeError, TypeError):
                        continue  # Not valid JSON
            if len(sample[:20]) > 0 and json_count >= len(sample[:20]) * 0.8:
                suggestions.append({
                    "rule": "json_valid",
                    "confidence": "high",
                    "reason": (
                        f"Values are valid JSON "
                        f"({json_count}/{len(sample[:20])} samples)"
                    ),
                })

        return suggestions

    @staticmethod
    def suggest_config(profile: ColumnProfile) -> dict[str, Any]:
        """
        Generate suggested validation config for a column.

        Args:
            profile: ColumnProfile to analyze

        Returns:
            Suggested validation config dict
        """
        suggestions = RuleSuggester.suggest_rules(profile)

        # Only include high-confidence suggestions
        high_conf = [s for s in suggestions if s.get("confidence") == "high"]

        config: dict[str, Any] = {
            "column": profile.name,
            "rules": {},
        }

        for sugg in high_conf:
            rule = sugg["rule"]
            if "params" in sugg:
                config["rules"][rule] = sugg["params"]
            else:
                config["rules"][rule] = True

        return config


# Value-based semantic detectors.
# Each entry defines a rule to suggest when sample values match a regex.
# ``skip_if_rules``: suppress this detector when any of these rules are
# already present (prevents e.g. IPv4 addresses triggering phone_valid).
_VALUE_DETECTORS: list[dict[str, Any]] = [
    {
        "rule": "email_valid",
        "pattern": r"^[^@\s]+@[^@\s]+\.[^@\s]+$",
        "confidence": "high",
        "reason_template": "Values match email format ({matches}/{total} samples)",
        "skip_if_rules": {"email_valid"},
    },
    {
        "rule": "url_valid",
        "pattern": r"^https?://[^\s]+",
        "confidence": "high",
        "reason_template": "Values match URL format ({matches}/{total} samples)",
        "skip_if_rules": {"url_valid"},
    },
    {
        "rule": "phone_valid",
        "pattern": r"^[+0-9][0-9\s\-().]{6,}$",
        "confidence": "medium",
        "reason_template": "Values match phone format ({matches}/{total} samples)",
        "skip_if_rules": {"phone_valid", "regex"},
    },
]


def _suggest_from_values(
    suggestions: list[dict[str, Any]], sample: list
) -> None:
    """Detect email/phone/URL from actual sample values.

    Iterates over ``_VALUE_DETECTORS`` and suggests a rule when >=80% of
    sample values match the detector's regex.  Skips detectors whose rule
    (or a conflicting rule) is already present in *suggestions*.
    """
    if not sample:
        return

    str_values = [str(v) for v in sample[:20] if v is not None]
    if not str_values:
        return

    total = len(str_values)
    threshold = 0.8
    existing_rules = {s["rule"] for s in suggestions}

    for detector in _VALUE_DETECTORS:
        if detector["skip_if_rules"] & existing_rules:
            continue

        compiled = re.compile(detector["pattern"])
        matches = sum(1 for v in str_values if compiled.match(v))
        if matches >= total * threshold:
            suggestions.append({
                "rule": detector["rule"],
                "confidence": detector["confidence"],
                "reason": detector["reason_template"].format(
                    matches=matches, total=total
                ),
            })
            existing_rules.add(detector["rule"])


# Known regex patterns to detect from sample values
_KNOWN_PATTERNS: list[tuple[str, str, str, str]] = [
    # (name, regex_pattern, confidence, description)
    (
        "UUID",
        r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",
        "high",
        "UUID format",
    ),
    (
        "IPv4",
        r"^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$",
        "high",
        "IPv4 address format",
    ),
    (
        "Hex color",
        r"^#[0-9a-fA-F]{6}$",
        "high",
        "Hex color code format",
    ),
    (
        "US zip code",
        r"^[0-9]{5}(-[0-9]{4})?$",
        "medium",
        "US zip code format",
    ),
    (
        "Credit card",
        r"^[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{4}$",
        "medium",
        "Credit card number format",
    ),
    (
        "SSN-like",
        r"^[0-9]{3}-[0-9]{2}-[0-9]{4}$",
        "medium",
        "SSN-like format (XXX-XX-XXXX)",
    ),
    (
        "MAC address",
        r"^[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}$",
        "high",
        "MAC address format",
    ),
]


def _suggest_regex_patterns(
    suggestions: list[dict[str, Any]], sample: list
) -> None:
    """Detect known regex patterns from sample values.

    Tests sample values against common patterns (UUID, IPv4, zip code, etc.)
    and suggests a regex rule if >=80% of values match.
    """
    if not sample:
        return

    # Skip if regex rule already suggested
    if any(s["rule"] == "regex" for s in suggestions):
        return

    str_values = [str(v).strip() for v in sample[:20] if v is not None]
    if not str_values:
        return

    total = len(str_values)
    threshold = 0.8

    for _name, pattern, confidence, description in _KNOWN_PATTERNS:
        compiled = re.compile(pattern)
        matches = sum(1 for v in str_values if compiled.match(v))
        if matches >= total * threshold:
            suggestions.append({
                "rule": "regex",
                "params": pattern,
                "confidence": confidence,
                "reason": (
                    f"Values match {description} "
                    f"({matches}/{total} samples)"
                ),
            })
            return  # Only suggest one regex pattern per column

    # No known pattern matched — try auto-inference from value structure
    result = _infer_custom_pattern(str_values)
    if result is not None:
        pattern, description = result
        # Verify match count for the reason string
        compiled = re.compile(pattern)
        matches = sum(1 for v in str_values if compiled.match(v))
        suggestions.append({
            "rule": "regex",
            "params": pattern,
            "confidence": "medium",
            "reason": (
                f"Values match {description} "
                f"({matches}/{total} samples)"
            ),
        })


# --- Separator token regex for splitting structured values ---
_SEP_RE = re.compile(r"([-:_./])")


def _infer_custom_pattern(
    str_values: list[str],
) -> tuple[str, str] | None:
    """Infer a regex pattern from structured string values.

    Splits values by common separators (-, :, _, ., /) and classifies
    each segment to build a regex pattern.  Works well for ID-like values
    such as ``SENS-12345678`` or ``7F:42:7D:4B:C3:D6``.

    Returns ``(pattern, description)`` or ``None``.
    """
    if len(str_values) < 5:
        return None

    all_tokenized = [_SEP_RE.split(v) for v in str_values]

    # Need >=80% of values to have the same token count
    token_counts: dict[int, int] = {}
    for tokens in all_tokenized:
        n = len(tokens)
        token_counts[n] = token_counts.get(n, 0) + 1

    most_common_count = max(token_counts, key=token_counts.get)  # type: ignore[arg-type]
    if token_counts[most_common_count] < len(str_values) * 0.8:
        return None

    # Must have at least one separator (3+ tokens: seg-sep-seg)
    if most_common_count < 3:
        return None

    matching = [t for t in all_tokenized if len(t) == most_common_count]

    # Build pattern for each token position
    pattern_parts: list[str] = []
    desc_parts: list[str] = []
    for pos in range(most_common_count):
        segment_values = [t[pos] for t in matching]

        if pos % 2 == 1:
            # Separator position — must be the same literal char
            if len(set(segment_values)) == 1:
                pattern_parts.append(re.escape(segment_values[0]))
            else:
                return None
        else:
            seg_pattern = _classify_segment(segment_values)
            if seg_pattern is None:
                return None
            pattern_parts.append(seg_pattern)

            # Description helper: note literal prefixes
            if len(set(segment_values)) == 1:
                desc_parts.append(f"'{segment_values[0]}'")

    pattern = "^" + "".join(pattern_parts) + "$"

    # Verify against ALL original values
    compiled = re.compile(pattern)
    matches = sum(1 for v in str_values if compiled.match(v))
    if matches < len(str_values) * 0.8:
        return None

    # Build human-readable description
    if desc_parts:
        description = f"{' + '.join(desc_parts)} prefix pattern"
    else:
        sep_char = matching[0][1]
        n_segments = (most_common_count + 1) // 2
        description = f"structured pattern ({n_segments} segments, '{sep_char}' separator)"

    return pattern, description


# Character class definitions for segment classification.
# Each entry: (per-char test function, regex class string).
# Checked in priority order — first match wins.
_CHAR_CLASSES: list[tuple[Callable[[str], bool], str]] = [
    (str.isdigit, "[0-9]"),
    (str.isupper, "[A-Z]"),
    (str.islower, "[a-z]"),
    (lambda c: c in "0123456789ABCDEF", "[0-9A-F]"),
    (lambda c: c in "0123456789abcdefABCDEF", "[0-9a-fA-F]"),
    (lambda c: c.isupper() or c.isdigit(), "[A-Z0-9]"),
    (lambda c: c.islower() or c.isdigit(), "[a-z0-9]"),
    (str.isalnum, "[A-Za-z0-9]"),
]


def _classify_segment(values: list[str]) -> str | None:
    """Classify a content segment (between separators) as a regex fragment.

    Uses the ``_CHAR_CLASSES`` table to find the most specific character
    class that covers every character across all segment values.

    Returns a regex fragment like ``\\d{8}``, ``[A-Z]{3}``, ``[0-9A-F]{12}``,
    or ``None`` if the segment cannot be classified.
    """
    if not values:
        return None

    # Literal — all values are identical
    if len(set(values)) == 1:
        return re.escape(values[0])

    # Length analysis
    lengths = [len(v) for v in values]
    min_len, max_len = min(lengths), max(lengths)

    all_chars = "".join(values)
    if not all_chars:
        return None

    # Build quantifier
    if min_len == max_len:
        quant = f"{{{min_len}}}" if min_len > 1 else ""
    else:
        quant = f"{{{min_len},{max_len}}}"

    # Walk the priority table — first class that covers all chars wins
    for test_fn, regex_class in _CHAR_CLASSES:
        if all(test_fn(c) for c in all_chars):
            return f"{regex_class}{quant}"

    return None
