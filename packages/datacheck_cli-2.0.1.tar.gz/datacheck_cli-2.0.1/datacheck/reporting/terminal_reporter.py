"""Enhanced terminal reporter with Rich formatting and suggestions.

Provides production-grade terminal output for validation results including:
- Color-coded status display
- Actionable suggestions for failures
- Summary statistics with progress bars
"""

import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from datacheck.reporting.suggestion_engine import Suggestion, SuggestionEngine
from datacheck.results import RuleResult, ValidationSummary


def _safe_encoding() -> bool:
    """Check if stdout can handle Unicode symbols."""
    encoding = getattr(sys.stdout, "encoding", None) or ""
    return encoding.lower().replace("-", "") in ("utf8", "utf16", "utf32", "utf16le", "utf16be")


# Symbols that degrade gracefully on non-UTF-8 terminals (e.g. Windows cp1252)
_TICK = "✓" if _safe_encoding() else "v"
_CROSS = "✗" if _safe_encoding() else "x"
_WARN = "⚠" if _safe_encoding() else "!"
_BAR_FILLED = "█" if _safe_encoding() else "#"
_BAR_EMPTY = "░" if _safe_encoding() else "-"
_HLINE = "─" if _safe_encoding() else "-"
_ARROW = "→" if _safe_encoding() else "->"
_BULLET = "•" if _safe_encoding() else "*"


class TerminalReporter:
    """Enhanced terminal reporter with Rich formatting.

    Provides rich, informative terminal output including:
    - Color-coded validation status
    - Detailed failure statistics
    - Actionable suggestions for fixing issues
    """

    def __init__(
        self,
        console: Console | None = None,
        show_suggestions: bool = True,
    ) -> None:
        """Initialize terminal reporter.

        Args:
            console: Rich Console instance (creates new one if None)
            show_suggestions: Whether to show fix suggestions (default: True)
        """
        self.console = console or Console()
        self.show_suggestions = show_suggestions

        # Initialize analyzers
        self._suggestion_engine = SuggestionEngine()

    def report(self, summary: ValidationSummary) -> None:
        """Generate and print comprehensive validation report.

        Args:
            summary: ValidationSummary to report
        """
        # Print header
        self._print_header()

        # Print overall status
        self._print_status(summary)

        # Print statistics
        self._print_statistics(summary)

        # Print detailed failures
        if summary.has_failures or summary.has_errors:
            self._print_failures(summary)

        # Print suggestions if enabled
        if self.show_suggestions and (summary.has_failures or summary.has_errors):
            suggestions = self._suggestion_engine.analyze(summary)
            if suggestions:
                self._print_suggestions(suggestions)

        # Print summary footer
        self._print_footer(summary)

    def _print_header(self) -> None:
        """Print report header."""
        self.console.print()
        self.console.print(
            Panel.fit(
                "[bold]DataCheck Validation Report[/bold]",
                border_style="blue",
            )
        )
        self.console.print()

    def _print_status(self, summary: ValidationSummary) -> None:
        """Print overall validation status.

        Args:
            summary: ValidationSummary containing status
        """
        if summary.all_passed:
            status = Text("ALL CHECKS PASSED", style="bold green")
            icon = f"[green]{_TICK}[/green]"
        elif summary.error_rules > 0 and summary.failed_rules == 0:
            status = Text("VALIDATION ERRORS", style="bold yellow")
            icon = f"[yellow]{_WARN}[/yellow]"
        else:
            status = Text("VALIDATION FAILED", style="bold red")
            icon = f"[red]{_CROSS}[/red]"

        self.console.print(f"{icon} {status}")
        self.console.print()

    def _print_statistics(self, summary: ValidationSummary) -> None:
        """Print summary statistics table.

        Args:
            summary: ValidationSummary containing statistics
        """
        table = Table(
            show_header=True,
            header_style="bold cyan",
            box=None,
            padding=(0, 2),
        )
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right")
        table.add_column("", width=20)

        # Dataset size
        if summary.total_rows > 0:
            table.add_row("Records", f"{summary.total_rows:,}", "")
        if summary.total_columns > 0:
            table.add_row("Columns", f"{summary.total_columns:,}", "")

        # Total rules
        table.add_row("Total Rules", str(summary.total_rules), "")

        # Passed rules with bar
        pass_pct = (summary.passed_rules / summary.total_rules * 100) if summary.total_rules > 0 else 0
        pass_bar = self._create_progress_bar(pass_pct, "green")
        table.add_row(
            "Passed",
            f"[green]{summary.passed_rules}[/green]",
            pass_bar,
        )

        # Failed rules with bar
        fail_pct = (summary.failed_rules / summary.total_rules * 100) if summary.total_rules > 0 else 0
        fail_bar = self._create_progress_bar(fail_pct, "red")
        table.add_row(
            "Failed",
            f"[red]{summary.failed_rules}[/red]" if summary.failed_rules > 0 else "0",
            fail_bar if summary.failed_rules > 0 else "",
        )

        # Error rules with bar
        error_pct = (summary.error_rules / summary.total_rules * 100) if summary.total_rules > 0 else 0
        error_bar = self._create_progress_bar(error_pct, "yellow")
        table.add_row(
            "Errors",
            f"[yellow]{summary.error_rules}[/yellow]" if summary.error_rules > 0 else "0",
            error_bar if summary.error_rules > 0 else "",
        )

        self.console.print(table)
        self.console.print()

    def _create_progress_bar(self, percentage: float, color: str, width: int = 15) -> str:
        """Create a simple progress bar string.

        Args:
            percentage: Percentage (0-100)
            color: Color name for the bar
            width: Width of the bar in characters

        Returns:
            Formatted progress bar string
        """
        filled = int((percentage / 100) * width)
        empty = width - filled
        bar = _BAR_FILLED * filled + _BAR_EMPTY * empty
        return f"[{color}]{bar}[/{color}] {percentage:.0f}%"

    def _print_failures(self, summary: ValidationSummary) -> None:
        """Print detailed failure information.

        Args:
            summary: ValidationSummary containing failures
        """
        # Print failed rules
        failed_results = summary.get_failed_results()
        if failed_results:
            self.console.print("[bold red]Failed Rules:[/bold red]")
            self.console.print()

            for result in failed_results:
                self._print_rule_failure(result)

        # Print error rules
        error_results = summary.get_error_results()
        if error_results:
            self.console.print("[bold yellow]Rules with Errors:[/bold yellow]")
            self.console.print()

            for result in error_results:
                self._print_rule_error(result)

    def _print_rule_failure(self, result: RuleResult) -> None:
        """Print detailed failure information for a single rule.

        Args:
            result: Failed RuleResult
        """
        # Rule header
        check_name = result.check_name if result.check_name else result.rule_name
        rule_type = result.rule_type if result.rule_type else "unknown"

        self.console.print(
            f"[red]{_CROSS}[/red] [bold]{check_name}[/bold] "
            f"([cyan]{result.column}[/cyan] · {rule_type})"
        )

        # Failure statistics
        failure_rate = (result.failed_rows / result.total_rows * 100) if result.total_rows > 0 else 0
        self.console.print(
            f"  Failed: {result.failed_rows:,}/{result.total_rows:,} rows ({failure_rate:.1f}%)"
        )

        self.console.print()

    def _print_rule_error(self, result: RuleResult) -> None:
        """Print error information for a rule that failed to execute.

        Args:
            result: Error RuleResult
        """
        check_name = result.check_name if result.check_name else result.rule_name

        self.console.print(
            f"[yellow]{_WARN}[/yellow] [bold]{check_name}[/bold] "
            f"([cyan]{result.column}[/cyan])"
        )
        self.console.print(f"  Error: {result.error}", style="yellow")
        self.console.print()

    def _print_suggestions(self, suggestions: list[Suggestion]) -> None:
        """Print actionable suggestions for fixing failures.

        Args:
            suggestions: List of Suggestion objects
        """
        self.console.print()
        self.console.print(
            Panel.fit(
                "[bold]Suggestions for Fixing Data Quality Issues[/bold]",
                border_style="cyan",
            )
        )
        self.console.print()

        for i, suggestion in enumerate(suggestions, 1):
            # Severity indicator
            severity_styles = {
                "high": "[red]HIGH[/red]",
                "medium": "[yellow]MEDIUM[/yellow]",
                "low": "[blue]LOW[/blue]",
            }
            severity = severity_styles.get(suggestion.severity, suggestion.severity)

            self.console.print(
                f"{i}. {severity} - [bold]{suggestion.rule_name}[/bold] "
                f"([cyan]{suggestion.column}[/cyan])"
            )
            self.console.print(f"   [dim]Issue:[/dim] {suggestion.message}")
            self.console.print(f"   [dim]Action:[/dim] {suggestion.action}")

            if suggestion.impact:
                self.console.print(f"   [dim]Impact:[/dim] {suggestion.impact}")

            # Show sample fixes
            if suggestion.sample_fixes:
                self.console.print("   [dim]Sample Fixes:[/dim]")
                for fix in suggestion.sample_fixes[:3]:
                    self.console.print(
                        f"     {_BULLET} {fix['original_value']} {_ARROW} {fix['suggested_fix']}"
                    )

            self.console.print()

    def _print_footer(self, summary: ValidationSummary) -> None:
        """Print report footer with summary.

        Args:
            summary: ValidationSummary for footer
        """
        self.console.print(_HLINE * 60)

        if summary.all_passed:
            self.console.print(
                f"[green]{_TICK} All validation rules passed successfully.[/green]"
            )
        else:
            issues = []
            if summary.failed_rules > 0:
                issues.append(f"{summary.failed_rules} failed")
            if summary.error_rules > 0:
                issues.append(f"{summary.error_rules} errors")
            issue_str = ", ".join(issues)
            self.console.print(
                f"[yellow]{_WARN} Validation complete with issues: {issue_str}[/yellow]"
            )

        self.console.print()


__all__ = [
    "TerminalReporter",
]
