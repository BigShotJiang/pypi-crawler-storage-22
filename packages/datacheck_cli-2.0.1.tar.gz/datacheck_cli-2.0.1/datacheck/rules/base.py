"""Base rule classes."""

from abc import ABC, abstractmethod
from typing import Any

import pandas as pd

from datacheck.exceptions import ColumnNotFoundError, RuleDefinitionError
from datacheck.results import FailureDetail, RuleResult


class Rule(ABC):
    """Abstract base class for validation rules.

    Attributes:
        name: Name of the rule
        column: Column to validate
    """

    def __init__(self, name: str, column: str) -> None:
        """Initialize rule.

        Args:
            name: Name of the rule
            column: Column to validate
        """
        self.name = name
        self.column = column

    @abstractmethod
    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate data against this rule.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome

        Raises:
            ColumnNotFoundError: If column not found in DataFrame
        """
        pass

    def _check_column_exists(self, df: pd.DataFrame) -> None:
        """Check if column exists in DataFrame.

        Args:
            df: DataFrame to check

        Raises:
            ColumnNotFoundError: If column not found
        """
        if self.column not in df.columns:
            raise ColumnNotFoundError(self.column, list(df.columns))

    def _create_failure_detail(
        self,
        failed_indices: pd.Index,
        total_count: int,
        failed_values: pd.Series | None = None,
        reasons: list[str] | None = None,
    ) -> FailureDetail:
        """Create failure detail from failed indices.

        Args:
            failed_indices: Indices of failed rows
            total_count: Total number of rows
            failed_values: Series containing failed values (optional)
            reasons: List of failure reasons for each failed value (optional)

        Returns:
            FailureDetail with failure information
        """
        failed_count = len(failed_indices)
        failure_rate = (failed_count / total_count * 100) if total_count > 0 else 0.0

        # Limit sample failures to 100 for memory efficiency
        sample_failures = failed_indices.tolist()[:100]

        # Extract sample values if provided
        sample_values: list[Any] = []
        if failed_values is not None:
            sample_values = failed_values.iloc[:100].tolist()

        # Extract sample reasons if provided
        sample_reasons: list[str] = []
        if reasons is not None:
            sample_reasons = reasons[:100]

        return FailureDetail(
            rule_name=self.name,
            column=self.column,
            failed_count=failed_count,
            total_count=total_count,
            failure_rate=failure_rate,
            sample_failures=sample_failures,
            sample_values=sample_values,
            sample_reasons=sample_reasons,
        )


class CustomRule(Rule):
    """Custom validation rule defined by user.

    Executes user-defined validation functions loaded from plugins.

    Example:
        >>> rule = CustomRule("email", "is_business_email",
        ...                  params={"allowed_domains": ["company.com"]})
        >>> result = rule.validate(df)
    """

    def __init__(
        self,
        column: str,
        rule_func_name: str,
        params: dict[str, Any] | None = None,
        rule_name: str | None = None
    ) -> None:
        """Initialize custom rule.

        Args:
            column: Column to validate
            rule_func_name: Name of the custom rule function
            params: Parameters to pass to the rule function
            rule_name: Optional custom name for the rule
        """
        super().__init__(rule_name or f"custom_{rule_func_name}", column)
        self.rule_func_name = rule_func_name
        self.params = params or {}

        # Get rule function from registry
        from datacheck.plugins.registry import get_global_registry
        self.registry = get_global_registry()

        if not self.registry.has_rule(rule_func_name):
            raise RuleDefinitionError(f"Custom rule '{rule_func_name}' not found. Did you load the plugin?")

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Execute custom validation rule.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        self._check_column_exists(df)

        try:
            # Execute custom rule
            validation_result = self.registry.execute_rule(
                self.rule_func_name,
                df[self.column],
                self.params
            )

            # Check result is boolean series
            if not isinstance(validation_result, pd.Series):
                raise RuleDefinitionError(
                    f"Custom rule '{self.rule_func_name}' must return a pandas Series"
                )

            # Find failures
            failed_mask = ~validation_result
            failed_indices = df[failed_mask].index

            passed = not failed_mask.any()
            total_rows = len(df)

            if passed:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="custom",
                    check_name=self.name,
                )

            # Create failure detail with failed values
            failed_values = df.loc[failed_mask, self.column]
            reasons = [f"Custom rule '{self.rule_func_name}' failed"] * len(failed_indices)

            failure_detail = self._create_failure_detail(
                failed_indices,
                total_rows,
                failed_values,
                reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(failed_indices),
                failure_details=failure_detail,
                rule_type="custom",
                check_name=self.name,
            )

        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Custom rule execution failed: {e}",
                rule_type="custom",
                check_name=self.name,
            )
