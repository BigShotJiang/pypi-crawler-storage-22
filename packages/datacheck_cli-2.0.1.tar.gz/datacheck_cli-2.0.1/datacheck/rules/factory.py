"""Rule factory for creating rule instances from configuration."""

from datacheck.config import RuleConfig
from datacheck.exceptions import RuleDefinitionError


class RuleFactory:
    """Factory for creating rule instances from configuration."""

    @staticmethod
    def create_rules(rule_config: RuleConfig) -> list:
        """Create rule instances from configuration.

        Args:
            rule_config: Rule configuration

        Returns:
            List of Rule instances

        Raises:
            RuleDefinitionError: If rule configuration is invalid
        """
        # Lazy imports to avoid circular imports
        from datacheck.rules.base import CustomRule
        from datacheck.rules.null_rules import NotNullRule
        from datacheck.rules.numeric_rules import (
            DistributionTypeRule, MeanBetweenRule, MinMaxRule,
            PercentileRangeRule, StdDevLessThanRule, ZScoreOutliersRule,
        )
        from datacheck.rules.string_rules import AllowedValuesRule, LengthRule, RegexRule
        from datacheck.rules.temporal_rules import (
            BusinessDaysOnlyRule, DateFormatValidRule, MaxAgeRule,
            NoFutureTimestampsRule, TimestampRangeRule,
        )
        from datacheck.rules.semantic_rules import (
            EmailValidRule, JsonValidRule, PhoneValidRule, UrlValidRule,
        )
        from datacheck.rules.composite_rules import (
            DataTypeRule, ForeignKeyExistsRule, SumEqualsRule,
            UniqueCombinationRule, UniqueRule,
        )

        rules: list = []

        # Check for custom rules first
        if "custom" in rule_config.rules:
            custom_config = rule_config.rules["custom"]
            if not isinstance(custom_config, dict):
                raise RuleDefinitionError("Custom rule must be a dictionary with 'rule' and optional 'params'")

            rule_func_name = custom_config.get("rule")
            params = custom_config.get("params", {})

            if not rule_func_name:
                raise RuleDefinitionError("Custom rule must specify 'rule' parameter")

            rules.append(CustomRule(rule_config.column, rule_func_name, params, rule_config.name))
            return rules  # Custom rules are exclusive

        for rule_type, rule_params in rule_config.rules.items():
            try:
                if rule_type == "not_null":
                    if rule_params:
                        rules.append(NotNullRule(rule_config.name, rule_config.column))

                elif rule_type == "min":
                    rules.append(
                        MinMaxRule(
                            f"{rule_config.name}_min",
                            rule_config.column,
                            min_value=rule_params,
                        )
                    )

                elif rule_type == "max":
                    rules.append(
                        MinMaxRule(
                            f"{rule_config.name}_max",
                            rule_config.column,
                            max_value=rule_params,
                        )
                    )

                elif rule_type == "unique":
                    if rule_params:
                        rules.append(UniqueRule(rule_config.name, rule_config.column))

                elif rule_type == "regex":
                    rules.append(
                        RegexRule(rule_config.name, rule_config.column, pattern=rule_params)
                    )

                elif rule_type == "allowed_values":
                    rules.append(
                        AllowedValuesRule(
                            rule_config.name, rule_config.column, allowed_values=rule_params
                        )
                    )

                elif rule_type == "type":
                    rules.append(
                        DataTypeRule(
                            rule_config.name, rule_config.column, expected_type=rule_params
                        )
                    )

                elif rule_type == "length":
                    if not isinstance(rule_params, dict):
                        raise RuleDefinitionError(
                            "length rule must be a dictionary with 'min' and/or 'max'"
                        )
                    rules.append(
                        LengthRule(
                            rule_config.name,
                            rule_config.column,
                            min_length=rule_params.get("min"),
                            max_length=rule_params.get("max"),
                        )
                    )

                elif rule_type == "min_length":
                    rules.append(
                        LengthRule(
                            rule_config.name,
                            rule_config.column,
                            min_length=rule_params,
                        )
                    )

                elif rule_type == "max_length":
                    rules.append(
                        LengthRule(
                            rule_config.name,
                            rule_config.column,
                            max_length=rule_params,
                        )
                    )

                # Statistical rules
                elif rule_type == "mean_between":
                    if not isinstance(rule_params, dict):
                        raise RuleDefinitionError(
                            "mean_between rule must be a dictionary with 'min' and 'max'"
                        )
                    rules.append(
                        MeanBetweenRule(
                            rule_config.name,
                            rule_config.column,
                            min_value=rule_params["min"],
                            max_value=rule_params["max"],
                        )
                    )

                elif rule_type == "std_dev_less_than":
                    rules.append(
                        StdDevLessThanRule(
                            rule_config.name,
                            rule_config.column,
                            threshold=rule_params,
                        )
                    )

                elif rule_type == "percentile_range":
                    if not isinstance(rule_params, dict):
                        raise RuleDefinitionError(
                            "percentile_range rule must be a dictionary"
                        )
                    rules.append(
                        PercentileRangeRule(
                            rule_config.name,
                            rule_config.column,
                            p25_min=rule_params["p25_min"],
                            p25_max=rule_params["p25_max"],
                            p75_min=rule_params["p75_min"],
                            p75_max=rule_params["p75_max"],
                        )
                    )

                elif rule_type == "z_score_outliers":
                    threshold = rule_params if isinstance(rule_params, (int, float)) and not isinstance(rule_params, bool) else 3.0
                    rules.append(
                        ZScoreOutliersRule(
                            rule_config.name,
                            rule_config.column,
                            threshold=threshold,
                        )
                    )

                elif rule_type == "distribution_type":
                    rules.append(
                        DistributionTypeRule(
                            rule_config.name,
                            rule_config.column,
                            expected_type=rule_params,
                        )
                    )

                # Freshness rules
                elif rule_type == "max_age":
                    rules.append(
                        MaxAgeRule(
                            rule_config.name,
                            rule_config.column,
                            duration=rule_params,
                        )
                    )

                elif rule_type == "timestamp_range" or rule_type == "date_range":
                    if not isinstance(rule_params, dict):
                        raise RuleDefinitionError(
                            "timestamp_range/date_range rule must be a dictionary with 'min' and 'max'"
                        )
                    rules.append(
                        TimestampRangeRule(
                            rule_config.name,
                            rule_config.column,
                            min_timestamp=rule_params["min"],
                            max_timestamp=rule_params["max"],
                        )
                    )

                elif rule_type == "no_future_timestamps":
                    if rule_params:
                        rules.append(
                            NoFutureTimestampsRule(rule_config.name, rule_config.column)
                        )

                elif rule_type == "date_format_valid":
                    rules.append(
                        DateFormatValidRule(
                            rule_config.name,
                            rule_config.column,
                            format_string=rule_params,
                        )
                    )

                elif rule_type == "date_format":
                    # Handle both dict format {"format": "%Y-%m-%d"} and string format
                    if isinstance(rule_params, dict):
                        fmt = rule_params.get("format", "%Y-%m-%d")
                    else:
                        fmt = rule_params or "%Y-%m-%d"
                    rules.append(
                        DateFormatValidRule(
                            rule_config.name,
                            rule_config.column,
                            format_string=fmt,
                        )
                    )

                elif rule_type == "business_days_only":
                    if isinstance(rule_params, dict):
                        country_code = rule_params.get("country_code", "US")
                    elif isinstance(rule_params, str):
                        country_code = rule_params
                    else:
                        country_code = "US"
                    rules.append(
                        BusinessDaysOnlyRule(
                            rule_config.name,
                            rule_config.column,
                            country_code=country_code,
                        )
                    )

                # Format rules
                elif rule_type == "email_valid":
                    if rule_params:
                        rules.append(
                            EmailValidRule(rule_config.name, rule_config.column)
                        )

                elif rule_type == "phone_valid":
                    if isinstance(rule_params, dict):
                        country_code = rule_params.get("country_code")
                    elif isinstance(rule_params, str):
                        country_code = rule_params
                    else:
                        country_code = None
                    rules.append(
                        PhoneValidRule(
                            rule_config.name,
                            rule_config.column,
                            country_code=country_code,
                        )
                    )

                elif rule_type == "url_valid":
                    if isinstance(rule_params, dict):
                        schemes = rule_params.get("schemes", ["http", "https"])
                    elif isinstance(rule_params, list):
                        schemes = rule_params
                    else:
                        schemes = ["http", "https"]
                    rules.append(
                        UrlValidRule(
                            rule_config.name,
                            rule_config.column,
                            schemes=schemes,
                        )
                    )

                elif rule_type == "json_valid":
                    if rule_params:
                        rules.append(
                            JsonValidRule(rule_config.name, rule_config.column)
                        )

                # Relationship rules
                elif rule_type == "unique_combination":
                    if not isinstance(rule_params, list):
                        raise RuleDefinitionError(
                            "unique_combination rule must be a list of column names"
                        )
                    rules.append(
                        UniqueCombinationRule(
                            rule_config.name,
                            rule_config.column,
                            columns=rule_params,
                        )
                    )

                elif rule_type == "foreign_key_exists":
                    if not isinstance(rule_params, dict):
                        raise RuleDefinitionError(
                            "foreign_key_exists rule must be a dictionary with "
                            "'reference_data' (list of dicts) and 'reference_column'"
                        )
                    import pandas as _pd
                    ref_data = rule_params.get("reference_data")
                    ref_column = rule_params.get("reference_column")
                    if ref_data is None or ref_column is None:
                        raise RuleDefinitionError(
                            "foreign_key_exists requires 'reference_data' and 'reference_column'"
                        )
                    reference_df = _pd.DataFrame(ref_data)
                    rules.append(
                        ForeignKeyExistsRule(
                            rule_config.name,
                            rule_config.column,
                            reference_df=reference_df,
                            reference_column=ref_column,
                        )
                    )

                elif rule_type == "sum_equals":
                    if not isinstance(rule_params, dict):
                        raise RuleDefinitionError(
                            "sum_equals rule must be a dictionary with "
                            "'column_a', 'column_b', and optional 'tolerance'"
                        )
                    col_a = rule_params.get("column_a")
                    col_b = rule_params.get("column_b")
                    if not col_a or not col_b:
                        raise RuleDefinitionError(
                            "sum_equals requires 'column_a' and 'column_b'"
                        )
                    rules.append(
                        SumEqualsRule(
                            rule_config.name,
                            rule_config.column,
                            column_a=col_a,
                            column_b=col_b,
                            tolerance=rule_params.get("tolerance", 0.01),
                        )
                    )

            except (RuleDefinitionError, TypeError, ValueError) as e:
                raise RuleDefinitionError(
                    f"Error creating {rule_type} rule for '{rule_config.name}': {e}"
                ) from e

        if not rules:
            raise RuleDefinitionError(
                f"No valid rules created for check '{rule_config.name}'"
            )

        return rules
