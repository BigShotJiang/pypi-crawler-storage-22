"""Numeric validation rules."""

import numpy as np
import pandas as pd

from datacheck.exceptions import ColumnNotFoundError, RuleDefinitionError
from datacheck.results import FailureDetail, RuleResult
from datacheck.rules.base import Rule


class MinMaxRule(Rule):
    """Rule to check numeric values are within min/max bounds."""

    def __init__(
        self, name: str, column: str, min_value: float | None = None, max_value: float | None = None
    ) -> None:
        """Initialize MinMaxRule.

        Args:
            name: Name of the rule
            column: Column to validate
            min_value: Minimum allowed value (inclusive)
            max_value: Maximum allowed value (inclusive)

        Raises:
            RuleDefinitionError: If neither min nor max is specified
        """
        super().__init__(name, column)
        if min_value is None and max_value is None:
            raise RuleDefinitionError("MinMaxRule requires at least min or max value")
        self.min_value = min_value
        self.max_value = max_value

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that numeric values are within bounds.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            # Determine rule type and check name
            rule_type = "min_max"
            check_name = self.name.replace("_min", "").replace("_max", "")
            if self.name.endswith("_min"):
                rule_type = "min"
            elif self.name.endswith("_max"):
                rule_type = "max"

            # Filter out null values (they should be caught by not_null rule)
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            # Check if data is numeric
            if not pd.api.types.is_numeric_dtype(data):
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=False,
                    total_rows=total_rows,
                    error=f"Column '{self.column}' is not numeric",
                    rule_type=rule_type,
                    check_name=check_name,
                )

            # Build condition for violations (direct vectorized comparison)
            if self.min_value is not None and self.max_value is not None:
                violations_mask = (data < self.min_value) | (data > self.max_value)
            elif self.min_value is not None:
                violations_mask = data < self.min_value
            else:
                violations_mask = data > self.max_value

            violation_indices = data.index[violations_mask]

            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type=rule_type,
                    check_name=check_name,
                )

            # Get failed values and create reasons (capped at 100 for memory)
            failed_values = data.loc[violation_indices]
            sample_vals = failed_values.iloc[:100]
            if self.min_value is not None and self.max_value is not None:
                reasons = [
                    f"Below minimum: {self.min_value}" if v < self.min_value
                    else f"Exceeds maximum: {self.max_value}"
                    for v in sample_vals
                ]
            elif self.min_value is not None:
                reasons = [f"Below minimum: {self.min_value}"] * len(sample_vals)
            else:
                reasons = [f"Exceeds maximum: {self.max_value}"] * len(sample_vals)

            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(violation_indices),
                failure_details=failure_detail,
                rule_type=rule_type,
                check_name=check_name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            # Determine rule type and check name for error case
            rule_type = "min_max"
            check_name = self.name.replace("_min", "").replace("_max", "")
            if self.name.endswith("_min"):
                rule_type = "min"
            elif self.name.endswith("_max"):
                rule_type = "max"

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing min/max rule: {e}",
                rule_type=rule_type,
                check_name=check_name,
            )


class MeanBetweenRule(Rule):
    """Rule to validate that column mean is within a specified range.

    This rule calculates the mean of numeric values in a column and validates
    that it falls within the specified min/max bounds (inclusive).
    """

    def __init__(self, name: str, column: str, min_value: float, max_value: float) -> None:
        """Initialize MeanBetweenRule.

        Args:
            name: Name of the rule
            column: Column to validate
            min_value: Minimum acceptable mean (inclusive)
            max_value: Maximum acceptable mean (inclusive)

        Raises:
            RuleDefinitionError: If min_value > max_value
        """
        super().__init__(name, column)
        if min_value > max_value:
            raise RuleDefinitionError(
                f"min_value ({min_value}) cannot be greater than max_value ({max_value})"
            )
        self.min_value = min_value
        self.max_value = max_value

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that column mean is within the specified range.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="mean_between",
                    check_name=self.name,
                )

            # Filter out null values and convert to numeric
            non_null_mask = df[self.column].notna()
            data = pd.to_numeric(df[self.column][non_null_mask], errors="coerce")
            data = data.dropna()

            if len(data) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=False,
                    total_rows=total_rows,
                    error="No numeric values found in column",
                    rule_type="mean_between",
                    check_name=self.name,
                )

            actual_mean = float(np.mean(data))

            if self.min_value <= actual_mean <= self.max_value:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="mean_between",
                    check_name=self.name,
                )

            # Mean is out of range - all rows are considered part of the failure
            reason = (
                f"Mean {actual_mean:.4f} is below minimum {self.min_value}"
                if actual_mean < self.min_value
                else f"Mean {actual_mean:.4f} exceeds maximum {self.max_value}"
            )

            failure_detail = FailureDetail(
                rule_name=self.name,
                column=self.column,
                failed_count=total_rows,
                total_count=total_rows,
                failure_rate=100.0,
                sample_failures=[],
                sample_values=[actual_mean],
                sample_reasons=[reason],
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=total_rows,
                failure_details=failure_detail,
                rule_type="mean_between",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing mean_between rule: {e}",
                rule_type="mean_between",
                check_name=self.name,
            )


class StdDevLessThanRule(Rule):
    """Rule to validate that column standard deviation is below a threshold.

    This rule calculates the standard deviation of numeric values in a column
    and validates that it is less than the specified threshold.
    """

    def __init__(self, name: str, column: str, threshold: float) -> None:
        """Initialize StdDevLessThanRule.

        Args:
            name: Name of the rule
            column: Column to validate
            threshold: Maximum acceptable standard deviation (exclusive)

        Raises:
            RuleDefinitionError: If threshold is negative
        """
        super().__init__(name, column)
        if threshold < 0:
            raise RuleDefinitionError("threshold cannot be negative")
        self.threshold = threshold

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that column standard deviation is below threshold.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="std_dev_less_than",
                    check_name=self.name,
                )

            # Filter out null values and convert to numeric
            non_null_mask = df[self.column].notna()
            data = pd.to_numeric(df[self.column][non_null_mask], errors="coerce")
            data = data.dropna()

            if len(data) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=False,
                    total_rows=total_rows,
                    error="No numeric values found in column",
                    rule_type="std_dev_less_than",
                    check_name=self.name,
                )

            actual_std = float(np.std(data, ddof=0))

            if actual_std < self.threshold:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="std_dev_less_than",
                    check_name=self.name,
                )

            failure_detail = FailureDetail(
                rule_name=self.name,
                column=self.column,
                failed_count=total_rows,
                total_count=total_rows,
                failure_rate=100.0,
                sample_failures=[],
                sample_values=[actual_std],
                sample_reasons=[
                    f"Standard deviation {actual_std:.4f} >= threshold {self.threshold}"
                ],
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=total_rows,
                failure_details=failure_detail,
                rule_type="std_dev_less_than",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing std_dev_less_than rule: {e}",
                rule_type="std_dev_less_than",
                check_name=self.name,
            )


class PercentileRangeRule(Rule):
    """Rule to validate that 25th and 75th percentiles fall within ranges.

    This rule calculates the 25th and 75th percentiles of numeric values
    and validates they fall within their respective specified ranges.
    """

    def __init__(
        self,
        name: str,
        column: str,
        p25_min: float,
        p25_max: float,
        p75_min: float,
        p75_max: float,
    ) -> None:
        """Initialize PercentileRangeRule.

        Args:
            name: Name of the rule
            column: Column to validate
            p25_min: Minimum acceptable 25th percentile (inclusive)
            p25_max: Maximum acceptable 25th percentile (inclusive)
            p75_min: Minimum acceptable 75th percentile (inclusive)
            p75_max: Maximum acceptable 75th percentile (inclusive)

        Raises:
            RuleDefinitionError: If min > max for either percentile range
        """
        super().__init__(name, column)
        if p25_min > p25_max:
            raise RuleDefinitionError(
                f"p25_min ({p25_min}) cannot be greater than p25_max ({p25_max})"
            )
        if p75_min > p75_max:
            raise RuleDefinitionError(
                f"p75_min ({p75_min}) cannot be greater than p75_max ({p75_max})"
            )
        self.p25_min = p25_min
        self.p25_max = p25_max
        self.p75_min = p75_min
        self.p75_max = p75_max

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that percentiles fall within specified ranges.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="percentile_range",
                    check_name=self.name,
                )

            # Filter out null values and convert to numeric
            non_null_mask = df[self.column].notna()
            data = pd.to_numeric(df[self.column][non_null_mask], errors="coerce")
            data = data.dropna()

            if len(data) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=False,
                    total_rows=total_rows,
                    error="No numeric values found in column",
                    rule_type="percentile_range",
                    check_name=self.name,
                )

            p25 = float(np.percentile(data, 25))
            p75 = float(np.percentile(data, 75))

            p25_valid = self.p25_min <= p25 <= self.p25_max
            p75_valid = self.p75_min <= p75 <= self.p75_max

            if p25_valid and p75_valid:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="percentile_range",
                    check_name=self.name,
                )

            reasons = []
            if not p25_valid:
                reasons.append(
                    f"25th percentile {p25:.4f} not in range [{self.p25_min}, {self.p25_max}]"
                )
            if not p75_valid:
                reasons.append(
                    f"75th percentile {p75:.4f} not in range [{self.p75_min}, {self.p75_max}]"
                )

            failure_detail = FailureDetail(
                rule_name=self.name,
                column=self.column,
                failed_count=total_rows,
                total_count=total_rows,
                failure_rate=100.0,
                sample_failures=[],
                sample_values=[p25, p75],
                sample_reasons=reasons,
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=total_rows,
                failure_details=failure_detail,
                rule_type="percentile_range",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing percentile_range rule: {e}",
                rule_type="percentile_range",
                check_name=self.name,
            )


class ZScoreOutliersRule(Rule):
    """Rule to detect outliers based on Z-score threshold.

    This rule calculates the Z-score for each value and fails if any value
    has an absolute Z-score greater than the specified threshold.
    """

    def __init__(self, name: str, column: str, threshold: float = 3.0) -> None:
        """Initialize ZScoreOutliersRule.

        Args:
            name: Name of the rule
            column: Column to validate
            threshold: Maximum acceptable absolute Z-score (default: 3.0)

        Raises:
            RuleDefinitionError: If threshold is not positive
        """
        super().__init__(name, column)
        if threshold <= 0:
            raise RuleDefinitionError("threshold must be positive")
        self.threshold = threshold

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that no values have Z-score above threshold.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="z_score_outliers",
                    check_name=self.name,
                )

            # Filter out null values and convert to numeric
            non_null_mask = df[self.column].notna()
            data = pd.to_numeric(df[self.column][non_null_mask], errors="coerce")
            data = data.dropna()

            if len(data) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=False,
                    total_rows=total_rows,
                    error="No numeric values found in column",
                    rule_type="z_score_outliers",
                    check_name=self.name,
                )

            mean = float(np.mean(data))
            std = float(np.std(data, ddof=0))

            if std == 0:
                # All values are the same, no outliers possible
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="z_score_outliers",
                    check_name=self.name,
                )

            # Calculate Z-scores
            z_scores = np.abs((data - mean) / std)
            outlier_mask = z_scores > self.threshold
            outlier_indices = data.index[outlier_mask]

            if len(outlier_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="z_score_outliers",
                    check_name=self.name,
                )

            failed_values = data.loc[outlier_indices]
            failed_z_scores = z_scores.loc[outlier_indices]
            reasons = [
                f"Z-score {z:.4f} exceeds threshold {self.threshold}"
                for z in failed_z_scores.iloc[:100]
            ]

            failure_detail = self._create_failure_detail(
                outlier_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(outlier_indices),
                failure_details=failure_detail,
                rule_type="z_score_outliers",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing z_score_outliers rule: {e}",
                rule_type="z_score_outliers",
                check_name=self.name,
            )


class DistributionTypeRule(Rule):
    """Rule to validate that data follows an expected distribution type.

    Uses the Kolmogorov-Smirnov test to check if data follows
    a normal or uniform distribution.

    Note: Requires scipy to be installed for full functionality.
    """

    VALID_TYPES = {"normal", "uniform"}

    def __init__(self, name: str, column: str, expected_type: str) -> None:
        """Initialize DistributionTypeRule.

        Args:
            name: Name of the rule
            column: Column to validate
            expected_type: Expected distribution type ("normal" or "uniform")

        Raises:
            RuleDefinitionError: If expected_type is not valid
        """
        super().__init__(name, column)
        expected_type_lower = expected_type.lower()
        if expected_type_lower not in self.VALID_TYPES:
            raise RuleDefinitionError(
                f"Invalid distribution_type '{expected_type}'. "
                f"Must be one of: {', '.join(sorted(self.VALID_TYPES))}"
            )
        self.expected_type = expected_type_lower

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that data follows the expected distribution.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="distribution_type",
                    check_name=self.name,
                )

            # Filter out null values and convert to numeric
            non_null_mask = df[self.column].notna()
            data = pd.to_numeric(df[self.column][non_null_mask], errors="coerce")
            data = data.dropna()

            if len(data) < 8:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=False,
                    total_rows=total_rows,
                    error="Need at least 8 numeric values for distribution test",
                    rule_type="distribution_type",
                    check_name=self.name,
                )

            # Try to import scipy for KS test
            try:
                from scipy import stats as scipy_stats

                if self.expected_type == "normal":
                    # Normalize data for test
                    mean = float(np.mean(data))
                    std = float(np.std(data, ddof=0))
                    if std == 0:
                        # All values same - not normal unless single value
                        passed = False
                        p_value = 0.0
                    else:
                        normalized = (data - mean) / std
                        statistic, p_value = scipy_stats.kstest(normalized, "norm")
                        passed = p_value > 0.05
                else:  # uniform
                    min_val = float(data.min())
                    max_val = float(data.max())
                    if min_val == max_val:
                        passed = True
                        p_value = 1.0
                    else:
                        normalized = (data - min_val) / (max_val - min_val)
                        statistic, p_value = scipy_stats.kstest(normalized, "uniform")
                        passed = p_value > 0.05

            except ImportError:
                # Fallback: use simple heuristics without scipy
                if self.expected_type == "normal":
                    # Check skewness and kurtosis using simple estimates
                    mean = float(np.mean(data))
                    std = float(np.std(data, ddof=0))
                    if std == 0:
                        passed = False
                        p_value = 0.0
                    else:
                        normalized = (data - mean) / std
                        skewness = float(np.mean(normalized**3))
                        kurtosis = float(np.mean(normalized**4) - 3)
                        # Normal: skewness ~0, excess kurtosis ~0
                        passed = abs(skewness) < 1.0 and abs(kurtosis) < 2.0
                        p_value = 0.1 if passed else 0.01
                else:  # uniform
                    # For uniform, check if values are spread evenly
                    min_val = float(data.min())
                    max_val = float(data.max())
                    if min_val == max_val:
                        passed = True
                        p_value = 1.0
                    else:
                        # Check coefficient of variation (uniform has ~0.58 for [0,1])
                        cv = float(np.std(data, ddof=0) / np.mean(data)) if np.mean(data) != 0 else 0
                        passed = 0.3 < cv < 0.8
                        p_value = 0.1 if passed else 0.01

            if passed:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="distribution_type",
                    check_name=self.name,
                )

            failure_detail = FailureDetail(
                rule_name=self.name,
                column=self.column,
                failed_count=total_rows,
                total_count=total_rows,
                failure_rate=100.0,
                sample_failures=[],
                sample_values=[p_value],
                sample_reasons=[
                    f"Data does not follow {self.expected_type} distribution (p-value: {p_value:.4f})"
                ],
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=total_rows,
                failure_details=failure_detail,
                rule_type="distribution_type",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing distribution_type rule: {e}",
                rule_type="distribution_type",
                check_name=self.name,
            )


# Convenience classes for clearer API
class MinRule(MinMaxRule):
    """Rule to check numeric values are above a minimum."""

    def __init__(self, name: str, column: str, min_value: float) -> None:
        """Initialize MinRule.

        Args:
            name: Name of the rule
            column: Column to validate
            min_value: Minimum allowed value (inclusive)
        """
        super().__init__(name, column, min_value=min_value, max_value=None)


class MaxRule(MinMaxRule):
    """Rule to check numeric values are below a maximum."""

    def __init__(self, name: str, column: str, max_value: float) -> None:
        """Initialize MaxRule.

        Args:
            name: Name of the rule
            column: Column to validate
            max_value: Maximum allowed value (inclusive)
        """
        super().__init__(name, column, min_value=None, max_value=max_value)


class RangeRule(MinMaxRule):
    """Rule to check numeric values are within a range."""

    def __init__(self, name: str, column: str, min_value: float, max_value: float) -> None:
        """Initialize RangeRule.

        Args:
            name: Name of the rule
            column: Column to validate
            min_value: Minimum allowed value (inclusive)
            max_value: Maximum allowed value (inclusive)
        """
        super().__init__(name, column, min_value=min_value, max_value=max_value)
