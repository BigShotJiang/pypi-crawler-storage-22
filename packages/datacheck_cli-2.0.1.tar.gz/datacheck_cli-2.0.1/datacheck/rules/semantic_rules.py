"""Semantic validation rules."""

import json
from typing import Any
from urllib.parse import urlparse

import pandas as pd
from email_validator import EmailNotValidError, validate_email
import phonenumbers

from datacheck.exceptions import ColumnNotFoundError
from datacheck.results import RuleResult
from datacheck.rules.base import Rule


class EmailValidRule(Rule):
    """Rule to validate that values are valid email addresses.

    Uses the email-validator library for RFC 5322 compliance checking.
    """

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that all values are valid email addresses.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="email_valid",
                    check_name=self.name,
                )

            # Filter out null values
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            if len(data) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="email_valid",
                    check_name=self.name,
                )

            # Vectorized regex pre-filter: fast-reject values without basic email structure
            data_str = data.astype(str)
            pre_filter = data_str.str.match(
                r"^[^@\s]+@[^@\s]+\.[^@\s]+$", na=False
            )

            # Only run expensive email-validator on candidates that pass pre-filter
            candidates = data[pre_filter]
            if len(candidates) > 0:
                def is_valid_email(value: Any) -> bool:
                    """Check whether a single value is a valid email address."""
                    try:
                        validate_email(str(value), check_deliverability=False)
                        return True
                    except EmailNotValidError:
                        return False

                detailed_mask = candidates.apply(is_valid_email)
                valid_mask = pre_filter.copy()
                valid_mask.loc[candidates.index] = detailed_mask
            else:
                valid_mask = pre_filter

            invalid_indices = data.index[~valid_mask]

            if len(invalid_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="email_valid",
                    check_name=self.name,
                )

            failed_values = data.loc[invalid_indices]
            reasons = [f"'{v}' is not a valid email address" for v in failed_values.iloc[:100]]

            failure_detail = self._create_failure_detail(
                invalid_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(invalid_indices),
                failure_details=failure_detail,
                rule_type="email_valid",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing email_valid rule: {e}",
                rule_type="email_valid",
                check_name=self.name,
            )


class PhoneValidRule(Rule):
    """Rule to validate that values are valid phone numbers.

    Uses the phonenumbers library for international phone number validation.
    """

    def __init__(self, name: str, column: str, country_code: str | None = None) -> None:
        """Initialize PhoneValidRule.

        Args:
            name: Name of the rule
            column: Column to validate
            country_code: Default country code (e.g., "US", "GB", "IN")
        """
        super().__init__(name, column)
        self.country_code = country_code

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that all values are valid phone numbers.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="phone_valid",
                    check_name=self.name,
                )

            # Filter out null values
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            if len(data) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="phone_valid",
                    check_name=self.name,
                )

            # When pandas/PyArrow loads purely numeric phone numbers, the
            # column ends up as int64 or float64.  Converting with plain
            # .astype(str) produces values like "1234567890.0" which break
            # phone-number parsing.  Detect numeric dtypes and convert via
            # integer casting first so the trailing ".0" is stripped.
            _is_numeric_col = pd.api.types.is_numeric_dtype(data)
            if _is_numeric_col:
                data_str = data.astype("Int64").astype(str)
            else:
                data_str = data.astype(str)

            # Vectorized regex pre-filter: fast-reject values without phone-like characters
            # Valid phones contain digits and may have +, -, (, ), spaces, dots
            pre_filter = data_str.str.match(
                r"^[+0-9][0-9\s\-().]{4,}$", na=False
            )

            # Only run expensive phonenumbers parsing on candidates
            candidates = data_str[pre_filter]
            if len(candidates) > 0:
                def is_valid_phone(value: Any) -> bool:
                    """Check whether a single value is a valid phone number."""
                    str_val = str(value)
                    try:
                        parsed = phonenumbers.parse(str_val, self.country_code)
                        if phonenumbers.is_valid_number(parsed):
                            return True
                    except phonenumbers.NumberParseException:
                        pass
                    # When CSV loaders (PyArrow) parse "+1234..." as a number,
                    # the "+" is lost.  Retry with "+" prefix for digit-only
                    # values that could be international numbers (country code
                    # 1-3 digits + national number, minimum ~8 digits total).
                    if _is_numeric_col and str_val.isdigit() and len(str_val) >= 8:
                        try:
                            parsed = phonenumbers.parse(
                                "+" + str_val, self.country_code
                            )
                            return bool(phonenumbers.is_valid_number(parsed))
                        except phonenumbers.NumberParseException:
                            pass
                    return False

                detailed_mask = candidates.apply(is_valid_phone)
                valid_mask = pre_filter.copy()
                valid_mask.loc[candidates.index] = detailed_mask
            else:
                valid_mask = pre_filter

            invalid_indices = data.index[~valid_mask]

            if len(invalid_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="phone_valid",
                    check_name=self.name,
                )

            failed_values = data_str.loc[invalid_indices]
            reasons = [f"'{v}' is not a valid phone number" for v in failed_values.iloc[:100]]

            failure_detail = self._create_failure_detail(
                invalid_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(invalid_indices),
                failure_details=failure_detail,
                rule_type="phone_valid",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing phone_valid rule: {e}",
                rule_type="phone_valid",
                check_name=self.name,
            )


class UrlValidRule(Rule):
    """Rule to validate that values are valid URLs.

    Validates URL format and scheme using urllib.parse.
    """

    def __init__(
        self, name: str, column: str, schemes: list[str] | None = None
    ) -> None:
        """Initialize UrlValidRule.

        Args:
            name: Name of the rule
            column: Column to validate
            schemes: Allowed URL schemes (default: ["http", "https"])
        """
        super().__init__(name, column)
        self.schemes = schemes or ["http", "https"]

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that all values are valid URLs.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="url_valid",
                    check_name=self.name,
                )

            # Filter out null values
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            if len(data) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="url_valid",
                    check_name=self.name,
                )

            # Vectorized regex pre-filter: fast-reject values that clearly aren't URLs
            schemes_pattern = "|".join(self.schemes)
            pre_filter = data.astype(str).str.match(
                rf"^({schemes_pattern})://[^\s]+", na=False
            )

            # For values that pass the pre-filter, do full urlparse validation
            candidates = data[pre_filter]
            if len(candidates) > 0:
                def is_valid_url(value: Any) -> bool:
                    """Check whether a single value is a valid URL with an allowed scheme."""
                    try:
                        result = urlparse(str(value))
                        return result.scheme in self.schemes and bool(result.netloc)
                    except Exception:
                        return False

                detailed_mask = candidates.apply(is_valid_url)
                # Combine: values that failed pre-filter are invalid,
                # values that passed pre-filter use detailed result
                valid_mask = pre_filter.copy()
                valid_mask.loc[candidates.index] = detailed_mask
            else:
                valid_mask = pre_filter

            invalid_indices = data.index[~valid_mask]

            if len(invalid_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="url_valid",
                    check_name=self.name,
                )

            failed_values = data.loc[invalid_indices]
            schemes_str = ", ".join(self.schemes)
            reasons = [
                f"'{v}' is not a valid URL (allowed schemes: {schemes_str})"
                for v in failed_values.iloc[:100]
            ]

            failure_detail = self._create_failure_detail(
                invalid_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(invalid_indices),
                failure_details=failure_detail,
                rule_type="url_valid",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing url_valid rule: {e}",
                rule_type="url_valid",
                check_name=self.name,
            )


class JsonValidRule(Rule):
    """Rule to validate that values are valid JSON strings."""

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that all values are valid JSON.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="json_valid",
                    check_name=self.name,
                )

            # Filter out null values
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            if len(data) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="json_valid",
                    check_name=self.name,
                )

            # Vectorized pre-filter: valid JSON must start with {, [, ", digit, true, false, or null
            data_str = data.astype(str).str.strip()
            pre_filter = data_str.str.match(
                r'^[\[{"tfn\d\-]', na=False
            )

            # Only run expensive json.loads on candidates that pass pre-filter
            candidates = data[pre_filter]
            if len(candidates) > 0:
                def is_valid_json(value: Any) -> bool:
                    """Check whether a single value is valid JSON."""
                    try:
                        json.loads(str(value))
                        return True
                    except (json.JSONDecodeError, TypeError):
                        return False

                detailed_mask = candidates.apply(is_valid_json)
                valid_mask = pre_filter.copy()
                valid_mask.loc[candidates.index] = detailed_mask
            else:
                valid_mask = pre_filter

            invalid_indices = data.index[~valid_mask]

            if len(invalid_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="json_valid",
                    check_name=self.name,
                )

            failed_values = data.loc[invalid_indices]
            reasons = [f"'{v}' is not valid JSON" for v in failed_values.iloc[:100]]

            failure_detail = self._create_failure_detail(
                invalid_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(invalid_indices),
                failure_details=failure_detail,
                rule_type="json_valid",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing json_valid rule: {e}",
                rule_type="json_valid",
                check_name=self.name,
            )
