"""Temporal validation rules."""

from datetime import timedelta

import pandas as pd

from datacheck.exceptions import ColumnNotFoundError, RuleDefinitionError
from datacheck.results import FailureDetail, RuleResult
from datacheck.rules.base import Rule


def _parse_duration(duration: str) -> timedelta:
    """Parse a duration string into a timedelta.

    Supported formats:
        - "24h" -> 24 hours
        - "7d" -> 7 days
        - "1w" -> 1 week
        - "30m" -> 30 minutes

    Args:
        duration: Duration string

    Returns:
        timedelta object

    Raises:
        ValueError: If format is invalid
    """
    duration = duration.strip().lower()
    if not duration:
        raise ValueError("Duration string cannot be empty")

    unit = duration[-1]
    try:
        value = int(duration[:-1])
    except ValueError:
        raise ValueError(f"Invalid duration format: {duration}")

    if unit == "h":
        return timedelta(hours=value)
    elif unit == "d":
        return timedelta(days=value)
    elif unit == "w":
        return timedelta(weeks=value)
    elif unit == "m":
        return timedelta(minutes=value)
    else:
        raise ValueError(f"Unknown duration unit '{unit}'. Use h, d, w, or m.")


class MaxAgeRule(Rule):
    """Rule to validate that data is not older than a specified duration.

    Checks that the maximum timestamp in a column is within the specified
    duration from the current time.
    """

    def __init__(self, name: str, column: str, duration: str) -> None:
        """Initialize MaxAgeRule.

        Args:
            name: Name of the rule
            column: Column to validate
            duration: Maximum age (e.g., "24h", "7d", "1w")

        Raises:
            RuleDefinitionError: If duration format is invalid
        """
        super().__init__(name, column)
        try:
            self.duration = _parse_duration(duration)
        except ValueError as e:
            raise RuleDefinitionError(str(e)) from e
        self.duration_str = duration

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that data is not older than the specified duration.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="max_age",
                    check_name=self.name,
                )

            # Convert column to datetime
            timestamps = pd.to_datetime(df[self.column], errors="coerce")
            valid_timestamps = timestamps.dropna()

            if len(valid_timestamps) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=False,
                    total_rows=total_rows,
                    error="No valid timestamps found in column",
                    rule_type="max_age",
                    check_name=self.name,
                )

            max_timestamp = valid_timestamps.max()
            now = pd.Timestamp.now()
            cutoff = now - self.duration

            if max_timestamp >= cutoff:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="max_age",
                    check_name=self.name,
                )

            age = now - max_timestamp
            failure_detail = FailureDetail(
                rule_name=self.name,
                column=self.column,
                failed_count=total_rows,
                total_count=total_rows,
                failure_rate=100.0,
                sample_failures=[],
                sample_values=[str(max_timestamp)],
                sample_reasons=[
                    f"Most recent data ({max_timestamp}) is older than {self.duration_str} (age: {age})"
                ],
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=total_rows,
                failure_details=failure_detail,
                rule_type="max_age",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing max_age rule: {e}",
                rule_type="max_age",
                check_name=self.name,
            )


class TimestampRangeRule(Rule):
    """Rule to validate that all timestamps fall within a specified range.

    All non-null values must be between min_timestamp and max_timestamp (inclusive).
    """

    def __init__(
        self, name: str, column: str, min_timestamp: str, max_timestamp: str
    ) -> None:
        """Initialize TimestampRangeRule.

        Args:
            name: Name of the rule
            column: Column to validate
            min_timestamp: Minimum timestamp (ISO format or parseable string)
            max_timestamp: Maximum timestamp (ISO format or parseable string)

        Raises:
            RuleDefinitionError: If timestamps are invalid or min > max
        """
        super().__init__(name, column)
        try:
            self.min_timestamp = pd.to_datetime(min_timestamp)
            self.max_timestamp = pd.to_datetime(max_timestamp)
        except Exception as e:
            raise RuleDefinitionError(f"Invalid timestamp format: {e}") from e

        if self.min_timestamp > self.max_timestamp:
            raise RuleDefinitionError(
                f"min_timestamp ({min_timestamp}) cannot be after max_timestamp ({max_timestamp})"
            )

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that all timestamps are within the specified range.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="timestamp_range",
                    check_name=self.name,
                )

            # Convert column to datetime
            timestamps = pd.to_datetime(df[self.column], errors="coerce")
            non_null_mask = timestamps.notna()
            valid_timestamps = timestamps[non_null_mask]

            if len(valid_timestamps) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="timestamp_range",
                    check_name=self.name,
                )

            # Find values outside range
            below_min = valid_timestamps < self.min_timestamp
            above_max = valid_timestamps > self.max_timestamp
            violation_mask = below_min | above_max
            violation_indices = valid_timestamps.index[violation_mask]

            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="timestamp_range",
                    check_name=self.name,
                )

            failed_values = valid_timestamps.loc[violation_indices]
            reasons = []
            for ts in failed_values.iloc[:100]:
                if ts < self.min_timestamp:
                    reasons.append(f"Timestamp {ts} is before {self.min_timestamp}")
                else:
                    reasons.append(f"Timestamp {ts} is after {self.max_timestamp}")

            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values.astype(str), reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(violation_indices),
                failure_details=failure_detail,
                rule_type="timestamp_range",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing timestamp_range rule: {e}",
                rule_type="timestamp_range",
                check_name=self.name,
            )


class NoFutureTimestampsRule(Rule):
    """Rule to validate that no timestamps are in the future.

    All non-null values must be less than or equal to the current time.
    """

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that no timestamps are in the future.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="no_future_timestamps",
                    check_name=self.name,
                )

            # Convert column to datetime
            timestamps = pd.to_datetime(df[self.column], errors="coerce")
            non_null_mask = timestamps.notna()
            valid_timestamps = timestamps[non_null_mask]

            if len(valid_timestamps) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="no_future_timestamps",
                    check_name=self.name,
                )

            now = pd.Timestamp.now()
            future_mask = valid_timestamps > now
            future_indices = valid_timestamps.index[future_mask]

            if len(future_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="no_future_timestamps",
                    check_name=self.name,
                )

            failed_values = valid_timestamps.loc[future_indices]
            reasons = [
                f"Timestamp {ts} is in the future (now: {now})"
                for ts in failed_values.iloc[:100]
            ]

            failure_detail = self._create_failure_detail(
                future_indices, total_rows, failed_values.astype(str), reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(future_indices),
                failure_details=failure_detail,
                rule_type="no_future_timestamps",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing no_future_timestamps rule: {e}",
                rule_type="no_future_timestamps",
                check_name=self.name,
            )


class DateFormatValidRule(Rule):
    """Rule to validate that all values parse successfully with a given format.

    All non-null values must be parseable as dates using the specified format string.
    """

    def __init__(self, name: str, column: str, format_string: str) -> None:
        """Initialize DateFormatValidRule.

        Args:
            name: Name of the rule
            column: Column to validate
            format_string: Expected date format (e.g., "%Y-%m-%d")
        """
        super().__init__(name, column)
        self.format_string = format_string

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that all values match the expected date format.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="date_format_valid",
                    check_name=self.name,
                )

            # Filter out null values
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            if len(data) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="date_format_valid",
                    check_name=self.name,
                )

            # If the column is already datetime (numpy datetime64 or
            # PyArrow timestamp), format it using the expected format
            # string so the round-trip check works correctly regardless
            # of the target format.
            _is_datetime = pd.api.types.is_datetime64_any_dtype(data) or (
                isinstance(data.dtype, pd.ArrowDtype)
                and hasattr(data, "dt")
            )
            if _is_datetime:
                dt_series = data.astype("datetime64[ns]")
                str_data = dt_series.dt.strftime(self.format_string)
            else:
                str_data = data.astype(str)

            # Vectorized date format validation via pd.to_datetime
            parsed = pd.to_datetime(
                str_data, format=self.format_string, errors="coerce"
            )
            valid_mask = parsed.notna()
            invalid_indices = data.index[~valid_mask]

            if len(invalid_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="date_format_valid",
                    check_name=self.name,
                )

            failed_values = data.loc[invalid_indices]
            reasons = [
                f"Value '{v}' does not match format '{self.format_string}'"
                for v in failed_values.iloc[:100]
            ]

            failure_detail = self._create_failure_detail(
                invalid_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(invalid_indices),
                failure_details=failure_detail,
                rule_type="date_format_valid",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing date_format_valid rule: {e}",
                rule_type="date_format_valid",
                check_name=self.name,
            )


class BusinessDaysOnlyRule(Rule):
    """Rule to validate that all dates fall on business days (weekdays).

    All non-null dates must be Monday through Friday (not Saturday or Sunday).
    Holiday checking is not implemented in the MVP version.
    """

    def __init__(self, name: str, column: str, country_code: str = "US") -> None:
        """Initialize BusinessDaysOnlyRule.

        Args:
            name: Name of the rule
            column: Column to validate
            country_code: Country code for holidays (not used in MVP)
        """
        super().__init__(name, column)
        self.country_code = country_code

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that all dates are business days.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="business_days_only",
                    check_name=self.name,
                )

            # Convert column to datetime
            timestamps = pd.to_datetime(df[self.column], errors="coerce")
            non_null_mask = timestamps.notna()
            valid_timestamps = timestamps[non_null_mask]

            if len(valid_timestamps) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="business_days_only",
                    check_name=self.name,
                )

            # Check for weekends (5 = Saturday, 6 = Sunday)
            day_of_week = valid_timestamps.dt.dayofweek
            weekend_mask = day_of_week >= 5
            weekend_indices = valid_timestamps.index[weekend_mask]

            if len(weekend_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="business_days_only",
                    check_name=self.name,
                )

            failed_values = valid_timestamps.loc[weekend_indices]
            day_names = failed_values.dt.day_name()
            reasons = [
                f"Date {ts.date()} falls on {day_name} (weekend)"
                for ts, day_name in zip(
                    failed_values.iloc[:100], day_names.iloc[:100], strict=False
                )
            ]

            failure_detail = self._create_failure_detail(
                weekend_indices, total_rows, failed_values.astype(str), reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(weekend_indices),
                failure_details=failure_detail,
                rule_type="business_days_only",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing business_days_only rule: {e}",
                rule_type="business_days_only",
                check_name=self.name,
            )
