"""Advanced sampling strategies for large dataset validation."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any

import numpy as np
import pandas as pd

from datacheck.exceptions import DataLoadError

logger = logging.getLogger(__name__)


class SamplingStrategy(Enum):
    """Available sampling strategies."""

    RANDOM = "random"
    STRATIFIED = "stratified"
    TIME_BASED = "time_based"
    ERROR_FOCUSED = "error_focused"
    ADAPTIVE = "adaptive"
    RESERVOIR = "reservoir"
    SYSTEMATIC = "systematic"
    TOP_N = "top_n"


class BaseSampler(ABC):
    """Base class for sampling strategies."""

    @abstractmethod
    def sample(self, df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame:
        """Sample DataFrame.

        Args:
            df: DataFrame to sample
            **kwargs: Strategy-specific options

        Returns:
            Sampled DataFrame
        """
        pass

    @property
    @abstractmethod
    def strategy(self) -> SamplingStrategy:
        """Return the sampling strategy type."""
        pass


class RandomSampler(BaseSampler):
    """Simple random sampling."""

    @property
    def strategy(self) -> SamplingStrategy:
        """Return the random sampling strategy type."""
        return SamplingStrategy.RANDOM

    def sample(
        self,
        df: pd.DataFrame,
        n: int | None = None,
        sample_rate: float | None = None,
        sample_count: int | None = None,
        random_state: int | None = None,
        seed: int | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Random sample of DataFrame.

        Args:
            df: DataFrame to sample
            n: Alias for sample_count
            sample_rate: Fraction to sample (0.0-1.0)
            sample_count: Exact number of rows to sample
            random_state: Random seed
            seed: Alias for random_state

        Returns:
            Sampled DataFrame

        Raises:
            DataLoadError: If neither rate nor count specified
        """
        # Handle aliases
        effective_count = n if n is not None else sample_count
        effective_seed = random_state if random_state is not None else seed
        if effective_seed is None:
            effective_seed = 42

        # If count >= total rows, return all
        if effective_count is not None and effective_count >= len(df):
            return df

        if sample_rate is None and effective_count is None:
            raise DataLoadError("Must specify either 'sample_rate', 'sample_count', or 'n'")

        if sample_rate is not None:
            if not 0.0 < sample_rate <= 1.0:
                raise DataLoadError(
                    f"Sample rate must be between 0 and 1, got {sample_rate}"
                )
            return df.sample(frac=sample_rate, random_state=effective_seed)

        # effective_count is guaranteed non-None here
        actual_count = min(effective_count, len(df))  # type: ignore[type-var]
        return df.sample(n=actual_count, random_state=effective_seed)


class StratifiedSampler(BaseSampler):
    """Stratified sampling to preserve distributions."""

    @property
    def strategy(self) -> SamplingStrategy:
        """Return the stratified sampling strategy type."""
        return SamplingStrategy.STRATIFIED

    def sample(
        self,
        df: pd.DataFrame,
        stratify_column: str | None = None,
        n: int | None = None,
        sample_rate: float | None = None,
        min_per_stratum: int = 1,
        random_state: int | None = None,
        seed: int | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Stratified sampling based on a column.

        Preserves the distribution of values in stratify_column.

        Args:
            df: DataFrame to sample
            stratify_column: Column to stratify on
            n: Target number of rows to sample (if >= total rows, returns all)
            sample_rate: Fraction to sample from each stratum (used if n not provided)
            min_per_stratum: Minimum rows to sample from each stratum
            random_state: Random seed
            seed: Alias for random_state

        Returns:
            Stratified sample

        Raises:
            DataLoadError: If column doesn't exist

        Example:
            >>> sampler = StratifiedSampler()
            >>> sample = sampler.sample(df, stratify_column='category', n=1000)
        """
        if stratify_column is None:
            raise DataLoadError("stratify_column is required for stratified sampling")
        if stratify_column not in df.columns:
            raise DataLoadError(f"Column '{stratify_column}' not found in DataFrame")

        # Handle seed alias
        effective_seed = random_state if random_state is not None else seed
        if effective_seed is None:
            effective_seed = 42

        # If n >= total rows, return all rows
        if n is not None and n >= len(df):
            return df

        # Calculate effective sample rate from n if provided
        if n is not None:
            effective_rate = n / len(df)
        elif sample_rate is not None:
            effective_rate = sample_rate
        else:
            effective_rate = 0.1

        def sample_group(group: pd.DataFrame) -> pd.DataFrame:
            """Sample a single stratum group respecting minimum and rate constraints."""
            n_sample = max(min_per_stratum, int(len(group) * effective_rate))
            n_sample = min(n_sample, len(group))
            return group.sample(n=n_sample, random_state=effective_seed)

        samples = []
        for _, group in df.groupby(stratify_column):
            samples.append(sample_group(group))
        sampled = pd.concat(samples, ignore_index=True)
        return sampled

    def sample_proportional(
        self,
        df: pd.DataFrame,
        stratify_column: str,
        total_sample_size: int,
        random_state: int = 42,
    ) -> pd.DataFrame:
        """Sample proportionally based on stratum sizes.

        Args:
            df: DataFrame to sample
            stratify_column: Column to stratify on
            total_sample_size: Total number of rows to sample
            random_state: Random seed

        Returns:
            Proportionally stratified sample
        """
        if stratify_column not in df.columns:
            raise DataLoadError(f"Column '{stratify_column}' not found in DataFrame")

        # Calculate proportions
        value_counts = df[stratify_column].value_counts()
        proportions = value_counts / len(df)

        samples = []
        np.random.seed(random_state)

        for value, proportion in proportions.items():
            stratum = df[df[stratify_column] == value]
            n_sample = max(1, int(total_sample_size * proportion))
            n_sample = min(n_sample, len(stratum))
            samples.append(stratum.sample(n=n_sample, random_state=random_state))

        return pd.concat(samples, ignore_index=True)


class TimeBasedSampler(BaseSampler):
    """Time-based sampling for temporal data."""

    @property
    def strategy(self) -> SamplingStrategy:
        """Return the time-based sampling strategy type."""
        return SamplingStrategy.TIME_BASED

    def sample(
        self,
        df: pd.DataFrame,
        time_column: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        n: int | None = None,
        sample_rate: float | None = None,
        random_state: int | None = None,
        seed: int | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Sample based on time range.

        Args:
            df: DataFrame to sample
            time_column: Column with datetime values
            start_date: Start date (ISO format, e.g., '2024-01-01')
            end_date: End date (ISO format)
            n: Target number of rows to sample
            sample_rate: Fraction to sample from filtered range
            random_state: Random seed
            seed: Alias for random_state

        Returns:
            Time-filtered and sampled DataFrame

        Raises:
            DataLoadError: If time_column doesn't exist
        """
        # Handle seed alias
        effective_seed = random_state if random_state is not None else seed
        if effective_seed is None:
            effective_seed = 42

        if time_column is None:
            raise DataLoadError("time_column is required for time-based sampling")
        if time_column not in df.columns:
            raise DataLoadError(f"Column '{time_column}' not found in DataFrame")

        df_work = df.assign(**{time_column: pd.to_datetime(df[time_column], errors="coerce")})

        # Filter by date range
        if start_date:
            df_work = df_work[df_work[time_column] >= pd.to_datetime(start_date)]
        if end_date:
            df_work = df_work[df_work[time_column] <= pd.to_datetime(end_date)]

        if len(df_work) == 0:
            return df_work

        # If n >= filtered rows, return all filtered data
        if n is not None and n >= len(df_work):
            return df_work

        # Sample from filtered data
        if n is not None:
            actual_count = min(n, len(df_work))
            return df_work.sample(n=actual_count, random_state=effective_seed)
        elif sample_rate is not None:
            return df_work.sample(frac=sample_rate, random_state=effective_seed)
        else:
            # Default to 10% if neither specified
            return df_work.sample(frac=0.1, random_state=effective_seed)

    def sample_recent(
        self,
        df: pd.DataFrame,
        time_column: str,
        days: int = 30,
        sample_rate: float = 1.0,
        random_state: int = 42,
    ) -> pd.DataFrame:
        """Sample from recent time period.

        Args:
            df: DataFrame to sample
            time_column: Column with datetime values
            days: Number of recent days to include
            sample_rate: Fraction to sample
            random_state: Random seed

        Returns:
            Sample from recent data
        """
        if time_column not in df.columns:
            raise DataLoadError(f"Column '{time_column}' not found in DataFrame")

        df_work = df.assign(**{time_column: pd.to_datetime(df[time_column], errors="coerce")})

        cutoff = pd.Timestamp.now() - pd.Timedelta(days=days)
        recent = df_work[df_work[time_column] >= cutoff]

        if len(recent) == 0:
            return recent

        if sample_rate < 1.0:
            return recent.sample(frac=sample_rate, random_state=random_state)
        return recent

    def sample_by_period(
        self,
        df: pd.DataFrame,
        time_column: str,
        period: str = "M",
        samples_per_period: int = 100,
        random_state: int = 42,
    ) -> pd.DataFrame:
        """Sample evenly across time periods.

        Args:
            df: DataFrame to sample
            time_column: Column with datetime values
            period: Period frequency ('D', 'W', 'M', 'Q', 'Y')
            samples_per_period: Rows to sample from each period
            random_state: Random seed

        Returns:
            Sample distributed across time periods
        """
        if time_column not in df.columns:
            raise DataLoadError(f"Column '{time_column}' not found in DataFrame")

        parsed_col = pd.to_datetime(df[time_column], errors="coerce")
        assign_kwargs: dict[str, pd.Series] = {
            time_column: parsed_col,
            "_period": parsed_col.dt.to_period(period),
        }
        df_work = df.assign(**assign_kwargs)

        def sample_period(group: pd.DataFrame) -> pd.DataFrame:
            """Sample rows from a single time period group."""
            n = min(samples_per_period, len(group))
            return group.sample(n=n, random_state=random_state)

        samples = []
        for _, group in df_work.groupby("_period"):
            samples.append(sample_period(group))
        sampled = pd.concat(samples, ignore_index=True)
        return sampled.drop(columns=["_period"], errors="ignore")


class ErrorFocusedSampler(BaseSampler):
    """Sample with bias toward rows likely to have errors."""

    @property
    def strategy(self) -> SamplingStrategy:
        """Return the error-focused sampling strategy type."""
        return SamplingStrategy.ERROR_FOCUSED

    def sample(
        self,
        df: pd.DataFrame,
        n: int | None = None,
        error_indicators: list[str] | None = None,
        null_columns: list[str] | None = None,
        sample_rate: float | None = None,
        error_oversample: float = 3.0,
        random_state: int | None = None,
        seed: int | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Oversample rows with potential errors.

        Args:
            df: DataFrame to sample
            n: Target number of rows to sample (if >= total rows, returns all)
            error_indicators: List of pandas query conditions
                             e.g., ["age < 0", "price > 10000"]
            null_columns: Columns where nulls indicate potential errors
            sample_rate: Base sample rate for normal rows (used if n not provided)
            error_oversample: Multiplier for error rows (3.0 = sample 3x more)
            random_state: Random seed
            seed: Alias for random_state

        Returns:
            Sample with oversampled error rows
        """
        # Handle seed alias
        effective_seed = random_state if random_state is not None else seed
        if effective_seed is None:
            effective_seed = 42

        np.random.seed(effective_seed)

        # Validate error indicators reference existing columns
        if error_indicators:
            invalid_columns = self._validate_indicator_columns(df, error_indicators)
            if invalid_columns:
                raise DataLoadError(
                    f"Error indicator(s) reference non-existent column(s): {', '.join(sorted(invalid_columns))}. "
                    f"Available columns: {', '.join(sorted(df.columns))}"
                )

        # If n >= total rows, return all rows
        if n is not None and n >= len(df):
            return df

        # Build error mask
        error_mask = pd.Series(False, index=df.index)
        valid_indicators_count = 0

        # Check error indicator conditions
        if error_indicators:
            for condition in error_indicators:
                try:
                    mask = df.eval(condition)
                    if isinstance(mask, pd.Series):
                        error_mask = error_mask | mask.astype(bool)
                    else:
                        # Handle scalar or array results
                        error_mask = error_mask | pd.Series(mask, index=df.index).astype(bool)
                    valid_indicators_count += 1
                except Exception as exc:
                    logger.warning("Skipping invalid error indicator condition %r: %s", condition, exc)

        # Check null columns
        valid_null_columns = False
        if null_columns:
            for col in null_columns:
                if col in df.columns:
                    error_mask |= df[col].isna()
                    valid_null_columns = True

        # Auto-detect potential errors if no valid indicators/columns provided
        # This also triggers if ALL provided indicators were invalid
        if (not error_indicators and not null_columns) or \
           (error_indicators and valid_indicators_count == 0 and not valid_null_columns):
            logger.info("No valid error indicators found, using auto-detection")
            error_mask = self._auto_detect_errors(df)

        # Separate error and normal rows
        error_rows = df[error_mask]
        normal_rows = df[~error_mask]

        # Calculate effective sample rate from n if provided
        if n is not None:
            effective_rate = n / len(df)
        elif sample_rate is not None:
            effective_rate = sample_rate
        else:
            effective_rate = 0.1

        samples = []

        # Sample error rows at higher rate (always include at least 1 if any exist)
        if len(error_rows) > 0:
            error_rate = min(effective_rate * error_oversample, 1.0)
            n_error = max(1, int(len(error_rows) * error_rate))
            n_error = min(n_error, len(error_rows))
            error_sample = error_rows.sample(n=n_error, random_state=effective_seed)
            samples.append(error_sample)

        # Sample normal rows at base rate
        if len(normal_rows) > 0:
            n_normal = max(1, int(len(normal_rows) * effective_rate))
            n_normal = min(n_normal, len(normal_rows))
            normal_sample = normal_rows.sample(n=n_normal, random_state=effective_seed)
            samples.append(normal_sample)

        if not samples:
            return df.head(0)  # Empty DataFrame with same schema

        # Combine and shuffle
        combined = pd.concat(samples, ignore_index=True)
        return combined.sample(frac=1.0, random_state=effective_seed)

    def _validate_indicator_columns(
        self, df: pd.DataFrame, indicators: list[str]
    ) -> set[str]:
        """Validate that error indicator conditions reference existing columns.

        Args:
            df: DataFrame to validate against
            indicators: List of condition strings like "age < 0", "price > 10000"

        Returns:
            Set of column names that don't exist in the DataFrame
        """
        import re

        # Extract potential column names from conditions
        # Matches word characters that could be column names (excludes operators and numbers)
        invalid_columns = set()
        available_columns = set(df.columns)

        for condition in indicators:
            # Extract identifiers (potential column names)
            # This regex finds word tokens that aren't pure numbers
            tokens = re.findall(r'\b([a-zA-Z_][a-zA-Z0-9_]*)\b', condition)
            for token in tokens:
                # Skip common keywords/operators
                if token.lower() in {'and', 'or', 'not', 'in', 'is', 'true', 'false', 'none', 'null', 'nan'}:
                    continue
                # Check if token is a column name
                if token not in available_columns:
                    invalid_columns.add(token)

        return invalid_columns

    def _auto_detect_errors(self, df: pd.DataFrame) -> pd.Series:
        """Auto-detect rows with potential errors.

        Looks for:
        - Null values in typically non-null columns
        - Extreme outliers in numeric columns
        - Empty strings in string columns

        Args:
            df: DataFrame to analyze

        Returns:
            Boolean mask of potentially erroneous rows
        """
        error_mask = pd.Series(False, index=df.index)

        for col in df.columns:
            if df[col].dtype in ["int64", "float64"]:
                # Detect outliers using IQR
                q1 = df[col].quantile(0.25)
                q3 = df[col].quantile(0.75)
                iqr = q3 - q1
                lower = q1 - 3 * iqr  # 3x IQR for extreme outliers
                upper = q3 + 3 * iqr
                error_mask |= (df[col] < lower) | (df[col] > upper)

            elif df[col].dtype == "object":
                # Check for empty strings
                error_mask |= df[col].fillna("").str.strip() == ""

            # Check for nulls if column is mostly non-null
            null_rate = df[col].isna().mean()
            if null_rate < 0.05:  # Less than 5% nulls expected
                error_mask |= df[col].isna()

        return error_mask


class AdaptiveSampler(BaseSampler):
    """Automatically determine optimal sample size."""

    @property
    def strategy(self) -> SamplingStrategy:
        """Return the adaptive sampling strategy type."""
        return SamplingStrategy.ADAPTIVE

    def sample(
        self,
        df: pd.DataFrame,
        n: int | None = None,
        target_rows: int = 100000,
        min_sample_rate: float = 0.01,
        max_sample_rate: float = 1.0,
        confidence_level: float = 0.95,
        margin_of_error: float = 0.01,
        random_state: int | None = None,
        seed: int | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Adaptively sample based on dataset size.

        Args:
            df: DataFrame to sample
            n: Alias for target_rows
            target_rows: Target number of rows (if possible)
            min_sample_rate: Minimum sample rate
            max_sample_rate: Maximum sample rate
            confidence_level: Statistical confidence level (for statistical sizing)
            margin_of_error: Acceptable margin of error
            random_state: Random seed
            seed: Alias for random_state

        Returns:
            Adaptively sampled DataFrame
        """
        # Handle aliases
        effective_target = n if n is not None else target_rows
        effective_seed = random_state if random_state is not None else seed
        if effective_seed is None:
            effective_seed = 42

        total_rows = len(df)

        if total_rows == 0:
            return df

        if total_rows <= effective_target:
            # Dataset is small enough, use it all
            return df

        # Calculate statistically optimal sample size
        statistical_size = self._calculate_sample_size(
            total_rows, confidence_level, margin_of_error
        )

        # Choose between target and statistical size
        optimal_size = min(effective_target, statistical_size)

        # Convert to rate and bound it
        sample_rate = optimal_size / total_rows
        sample_rate = max(min_sample_rate, min(sample_rate, max_sample_rate))

        return df.sample(frac=sample_rate, random_state=effective_seed)

    def _calculate_sample_size(
        self,
        population: int,
        confidence: float = 0.95,
        margin: float = 0.01,
    ) -> int:
        """Calculate statistically valid sample size.

        Uses the formula for sample size with finite population correction.

        Args:
            population: Population size
            confidence: Confidence level
            margin: Margin of error

        Returns:
            Required sample size
        """
        # Z-scores for common confidence levels
        z_scores = {
            0.90: 1.645,
            0.95: 1.96,
            0.99: 2.576,
        }
        z = z_scores.get(confidence, 1.96)

        if population <= 0:
            return 0

        if margin <= 0:
            return population

        # Assume p=0.5 (maximum variability)
        p = 0.5

        # Sample size for infinite population
        n_0 = (z**2 * p * (1 - p)) / (margin**2)

        # Finite population correction
        n = n_0 / (1 + (n_0 - 1) / population)

        return int(np.ceil(n))

    def sample_for_validation(
        self,
        df: pd.DataFrame,
        expected_error_rate: float = 0.01,
        min_errors_to_detect: int = 100,
        random_state: int = 42,
    ) -> pd.DataFrame:
        """Sample size sufficient to detect expected errors.

        Args:
            df: DataFrame to sample
            expected_error_rate: Expected rate of errors
            min_errors_to_detect: Minimum errors we want in sample
            random_state: Random seed

        Returns:
            Sample sized to detect expected errors
        """
        if expected_error_rate <= 0:
            expected_error_rate = 0.01

        # Calculate required sample to get min_errors_to_detect
        required_sample = int(min_errors_to_detect / expected_error_rate)
        required_sample = min(required_sample, len(df))

        if required_sample >= len(df):
            return df

        return df.sample(n=required_sample, random_state=random_state)


class ReservoirSampler(BaseSampler):
    """Reservoir sampling for streaming large files."""

    @property
    def strategy(self) -> SamplingStrategy:
        """Return the reservoir sampling strategy type."""
        return SamplingStrategy.RESERVOIR

    def sample(
        self,
        df: pd.DataFrame,
        k: int | None = None,
        sample_size: int = 10000,
        random_state: int | None = None,
        seed: int | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Reservoir sampling (Algorithm R).

        This algorithm is particularly useful for streaming data where
        the total size is unknown. For DataFrames, it's equivalent to
        random sampling but uses the reservoir algorithm.

        Args:
            df: DataFrame to sample
            k: Alias for sample_size
            sample_size: Number of rows to sample
            random_state: Random seed
            seed: Alias for random_state

        Returns:
            Sample of specified size
        """
        # Handle aliases
        effective_size = k if k is not None else sample_size
        effective_seed = random_state if random_state is not None else seed
        if effective_seed is None:
            effective_seed = 42

        np.random.seed(effective_seed)

        total_rows = len(df)
        if total_rows <= effective_size:
            return df

        # Initialize reservoir with first k elements
        reservoir_indices = list(range(effective_size))

        # Replace elements with decreasing probability
        for i in range(effective_size, total_rows):
            j = np.random.randint(0, i + 1)
            if j < effective_size:
                reservoir_indices[j] = i

        return df.iloc[sorted(reservoir_indices)].reset_index(drop=True)

    def sample_weighted(
        self,
        df: pd.DataFrame,
        sample_size: int,
        weight_column: str,
        random_state: int = 42,
    ) -> pd.DataFrame:
        """Weighted reservoir sampling (Algorithm A-Res).

        Args:
            df: DataFrame to sample
            sample_size: Number of rows to sample
            weight_column: Column with sampling weights
            random_state: Random seed

        Returns:
            Weighted sample
        """
        if weight_column not in df.columns:
            raise DataLoadError(f"Column '{weight_column}' not found in DataFrame")

        np.random.seed(random_state)

        n = len(df)
        if n <= sample_size:
            return df

        weights = np.asarray(df[weight_column].fillna(1).values, dtype=np.float64)

        # Calculate keys for weighted reservoir sampling
        # Key = random^(1/weight) for each element
        random_values = np.random.random(n)
        keys = np.power(random_values, 1.0 / np.maximum(weights, 1e-10))

        # Select top k by key
        top_indices = np.argpartition(keys, -sample_size)[-sample_size:]
        top_indices = top_indices[np.argsort(keys[top_indices])]

        return df.iloc[top_indices].reset_index(drop=True)


class SamplerFactory:
    """Factory for creating samplers."""

    _samplers: dict[SamplingStrategy, type[BaseSampler]] = {
        SamplingStrategy.RANDOM: RandomSampler,
        SamplingStrategy.STRATIFIED: StratifiedSampler,
        SamplingStrategy.TIME_BASED: TimeBasedSampler,
        SamplingStrategy.ERROR_FOCUSED: ErrorFocusedSampler,
        SamplingStrategy.ADAPTIVE: AdaptiveSampler,
        SamplingStrategy.RESERVOIR: ReservoirSampler,
    }

    @classmethod
    def create(cls, strategy: SamplingStrategy | str) -> BaseSampler:
        """Create sampler instance.

        Args:
            strategy: Sampling strategy (enum or string)

        Returns:
            Sampler instance

        Raises:
            DataLoadError: If strategy is unknown
        """
        if isinstance(strategy, str):
            try:
                strategy = SamplingStrategy(strategy.lower())
            except ValueError:
                valid = [s.value for s in SamplingStrategy]
                raise DataLoadError(
                    f"Unknown sampling strategy '{strategy}'. "
                    f"Valid strategies: {', '.join(valid)}"
                )

        if strategy not in cls._samplers:
            raise DataLoadError(f"No sampler for strategy: {strategy}")

        return cls._samplers[strategy]()

    @classmethod
    def list_strategies(cls) -> list[str]:
        """List available sampling strategies."""
        return [s.value for s in SamplingStrategy]


def smart_sample(
    df: pd.DataFrame,
    target_rows: int = 100000,
    stratify_column: str | None = None,
    time_column: str | None = None,
    error_indicators: list[str] | None = None,
    random_state: int = 42,
) -> pd.DataFrame:
    """Smart sampling that auto-selects the best strategy.

    Args:
        df: DataFrame to sample
        target_rows: Target sample size
        stratify_column: Column for stratified sampling
        time_column: Column for time-based sampling
        error_indicators: Conditions for error-focused sampling
        random_state: Random seed

    Returns:
        Sampled DataFrame using most appropriate strategy
    """
    n = len(df)

    # Small dataset - no sampling needed
    if n <= target_rows:
        return df

    # Error-focused if indicators provided
    if error_indicators:
        error_sampler = ErrorFocusedSampler()
        return error_sampler.sample(
            df,
            error_indicators=error_indicators,
            sample_rate=target_rows / n,
            random_state=random_state,
        )

    # Stratified if column provided
    if stratify_column and stratify_column in df.columns:
        strat_sampler = StratifiedSampler()
        result: pd.DataFrame = strat_sampler.sample_proportional(
            df,
            stratify_column=stratify_column,
            total_sample_size=target_rows,
            random_state=random_state,
        )
        return result

    # Time-based for temporal data
    if time_column and time_column in df.columns:
        time_sampler = TimeBasedSampler()
        result = time_sampler.sample_by_period(
            df,
            time_column=time_column,
            samples_per_period=target_rows // 12,  # Assume monthly
            random_state=random_state,
        )
        return result

    # Default to adaptive sampling
    adaptive_sampler = AdaptiveSampler()
    return adaptive_sampler.sample(df, target_rows=target_rows, random_state=random_state)


__all__ = [
    "SamplingStrategy",
    "BaseSampler",
    "RandomSampler",
    "StratifiedSampler",
    "TimeBasedSampler",
    "ErrorFocusedSampler",
    "AdaptiveSampler",
    "ReservoirSampler",
    "SamplerFactory",
    "smart_sample",
]
