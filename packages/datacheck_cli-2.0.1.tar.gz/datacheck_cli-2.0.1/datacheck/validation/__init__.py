"""Programmatic Python API for DataCheck validation.

This module provides a multi-column, severity-aware API for use in Python
scripts, notebooks, and integrations.

All validation logic is shared with the CLI engine (``datacheck.rules``).
The Python API wraps engine rules with multi-column support and severity levels,
ensuring consistent behavior between ``datacheck validate`` (CLI) and
``Validator(...).validate(df)`` (Python API).

Key features of the Python API:
- Rules accept ``columns: list[str]`` (multiple columns) vs ``column: str``
- ``validate()`` returns ``list[RuleResult]`` vs a single ``RuleResult``
- Has ``Severity`` enum (ERROR, WARNING, INFO) for fine-grained control
- Provides ``Validator`` class with builder-pattern API
- All 27+ engine rules available through the Python API
"""

from datacheck.validation.rules import (
    # Base
    Rule,
    Severity,
    RuleResult,
    # Null / Uniqueness
    NotNullRule,
    UniqueRule,
    # Numeric
    RangeRule,
    MeanBetweenRule,
    StdDevLessThanRule,
    PercentileRangeRule,
    ZScoreOutliersRule,
    DistributionTypeRule,
    # String / Pattern
    RegexRule,
    EnumRule,
    LengthRule,
    # Type
    TypeRule,
    # Temporal
    MaxAgeRule,
    TimestampRangeRule,
    NoFutureTimestampsRule,
    DateFormatValidRule,
    BusinessDaysOnlyRule,
    # Semantic
    EmailValidRule,
    PhoneValidRule,
    UrlValidRule,
    JsonValidRule,
    # Relationship / Composite
    ForeignKeyExistsRule,
    SumEqualsRule,
    UniqueCombinationRule,
    # Custom
    CustomRule,
)
from datacheck.validation.validator import Validator, ValidationReport
from datacheck.validation.config import load_config, RuleConfig

__all__ = [
    # Base classes
    "Rule",
    "Severity",
    "RuleResult",
    "Validator",
    "ValidationReport",
    # Null / Uniqueness
    "NotNullRule",
    "UniqueRule",
    # Numeric
    "RangeRule",
    "MeanBetweenRule",
    "StdDevLessThanRule",
    "PercentileRangeRule",
    "ZScoreOutliersRule",
    "DistributionTypeRule",
    # String / Pattern
    "RegexRule",
    "EnumRule",
    "LengthRule",
    # Type
    "TypeRule",
    # Temporal
    "MaxAgeRule",
    "TimestampRangeRule",
    "NoFutureTimestampsRule",
    "DateFormatValidRule",
    "BusinessDaysOnlyRule",
    # Semantic
    "EmailValidRule",
    "PhoneValidRule",
    "UrlValidRule",
    "JsonValidRule",
    # Relationship / Composite
    "ForeignKeyExistsRule",
    "SumEqualsRule",
    "UniqueCombinationRule",
    # Custom
    "CustomRule",
    # Config
    "load_config",
    "RuleConfig",
]
