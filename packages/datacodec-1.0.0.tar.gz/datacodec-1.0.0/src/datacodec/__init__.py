"""
datacodec - A Python library for binary data encoding/decoding.

This module provides binary serialization/deserialization with support for
cross-platform compatibility, automatic codec generation from dataclasses,
and a fluent API for codec composition.
"""

from .codecs import (
    # Primitive codecs
    int8_codec,
    uint8_codec,
    int16_codec,
    uint16_codec,
    int32_codec,
    uint32_codec,
    int64_codec,
    uint64_codec,
    float_codec,
    double_codec,
    bool_codec,
    # Composite codecs
    tuple_codec,
    array_codec,
    vector_codec,
    optional_codec,
    variant_codec,
)

from .size_codec import size_codec, SizeCodec

from .advanced_codecs import (
    # Advanced codecs
    TransformCodec,
    ConstrainedCodec,
    DefaultCodec,
    ApplyCodec,
    StringCodec,
    VarintCodec,
    ConstantCodec,
    PairCodec,
    # Predefined instances
    string_codec,
    u16string_codec,
    u32string_codec,
    wstring_codec,
    unsigned_varint_codec,
    signed_varint_codec,
    # Factory functions
    pair_codec,
    constant_codec,
)

from .delimited_codec import (
    DelimitedCodec,
    delimited_codec,
)

from .range_codec import (
    RangeCodec,
    range_codec,
)

from .monostate_codec import (
    MonostateCodec,
    Monostate,
    monostate,
    monostate_codec,
)

from .member_codec import (
    MemberCodec,
    member_codec,
)

from .binary_format import BinaryFormat

from .platform import (
    PlatformConfig,
    ARM32_CONFIG,
    ARM32_COMPAT_CONFIG,
    ARM64_CONFIG,
    X86_32_CONFIG,
    X86_64_CONFIG,
    NATIVE_CONFIG,
    DEFAULT_CONFIG,
    get_platform_config,
)

from .python_codecs import (
    dataclass_codec,
    codec,
    dict_codec,
)

# Optional NumPy support
try:
    from .numpy_codecs import numpy_array_codec, HAS_NUMPY
    _has_numpy_support = True
except ImportError:
    _has_numpy_support = False
    HAS_NUMPY = False

__version__ = "1.0.0"

__all__ = [
    # Primitive codecs
    "int8_codec",
    "uint8_codec",
    "int16_codec",
    "uint16_codec",
    "int32_codec",
    "uint32_codec",
    "int64_codec",
    "uint64_codec",
    "float_codec",
    "double_codec",
    "bool_codec",
    "size_codec",
    "SizeCodec",
    # Composite codecs
    "tuple_codec",
    "array_codec",
    "vector_codec",
    "optional_codec",
    "variant_codec",
    # Advanced codecs
    "TransformCodec",
    "ConstrainedCodec",
    "DefaultCodec",
    "ApplyCodec",
    "StringCodec",
    "VarintCodec",
    "ConstantCodec",
    "PairCodec",
    "DelimitedCodec",
    "RangeCodec",
    "MonostateCodec",
    "Monostate",
    "monostate",
    "monostate_codec",
    "string_codec",
    "u16string_codec",
    "u32string_codec",
    "wstring_codec",
    "unsigned_varint_codec",
    "signed_varint_codec",
    "pair_codec",
    "constant_codec",
    "delimited_codec",
    "range_codec",
    # Member codec
    "MemberCodec",
    "member_codec",
    # Format
    "BinaryFormat",
    # Platform configs
    "PlatformConfig",
    "ARM32_CONFIG",
    "ARM32_COMPAT_CONFIG",
    "ARM64_CONFIG",
    "X86_32_CONFIG",
    "X86_64_CONFIG",
    "NATIVE_CONFIG",
    "DEFAULT_CONFIG",
    "get_platform_config",
    # Dataclass support
    "dataclass_codec",
    "codec",
    "dict_codec",
]

# Add NumPy support if available
if _has_numpy_support:
    __all__.append("numpy_array_codec")
    __all__.append("HAS_NUMPY")

