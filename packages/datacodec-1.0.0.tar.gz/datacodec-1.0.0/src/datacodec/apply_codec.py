"""
Apply codec for constructing instances from decoded values.
"""

from typing import Any
from .codec_base import Codec


class ApplyCodec(Codec):
    """
    Codec that constructs instances of a type from decoded values.

    Useful for converting tuples to dataclasses or named tuples.
    """

    def __init__(self, inner_codec: Codec, type_class: type):
        """
        Initialize an apply codec.

        Args:
            inner_codec: The underlying codec (typically tuple_codec)
            type_class: Type to construct from decoded values
        """
        self.inner_codec = inner_codec
        self.type_class = type_class

    def encode(self, value: Any) -> Any:
        """
        Convert instance to tuple-like, then encode.

        If the inner codec is a TupleCodec with codecs that have .project() methods
        (e.g., MemberCodec), use those to extract values from the object and encode
        with the inner codecs.
        """
        # Check if inner codec is a TupleCodec with projectable codecs (e.g., MemberCodec)
        from .tuple_codec import TupleCodec
        from .member_codec import MemberCodec

        if isinstance(self.inner_codec, TupleCodec):
            # Check if all codecs have .project() method
            if all(hasattr(codec, 'project') for codec in self.inner_codec.codecs):
                # Use project() to extract values, then encode with inner codecs
                # Create a new TupleCodec with the inner codecs (unwrapped from MemberCodec)
                inner_codecs = []
                projected_values = []

                for codec in self.inner_codec.codecs:
                    # Extract value using project()
                    projected_val = codec.project(value)
                    projected_values.append(projected_val)

                    # Get the actual codec (unwrap MemberCodec)
                    if isinstance(codec, MemberCodec):
                        inner_codecs.append(codec.inner_codec)
                    else:
                        inner_codecs.append(codec)

                # Create tuple codec with inner codecs and encode the projected values
                tuple_val = tuple(projected_values)
                inner_tuple_codec = TupleCodec(*inner_codecs)
                return inner_tuple_codec.encode(tuple_val)

        # Fallback: convert object to tuple
        if hasattr(value, '__iter__') and not isinstance(value, (str, bytes)):
            tuple_val = tuple(value) if not isinstance(value, tuple) else value
        else:
            if hasattr(value, '_asdict'):  # namedtuple
                tuple_val = tuple(value._asdict().values())
            elif hasattr(value, '__dict__'):  # dataclass or regular class
                tuple_val = tuple(value.__dict__.values())
            else:
                tuple_val = (value,)

        return self.inner_codec.encode(tuple_val)

    def decode(self, value: Any) -> Any:
        """Decode to tuple, then construct instance."""
        if value is None:
            return None
        decoded = self.inner_codec.decode(value)
        if decoded is None:
            return None
        if isinstance(decoded, tuple):
            return self.type_class(*decoded)
        else:
            return self.type_class(decoded)

    def next_codec(self) -> Codec:
        """Return the inner codec's next codec."""
        return self.inner_codec.next_codec()

