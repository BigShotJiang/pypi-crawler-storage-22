"""
Array codec for fixed-size arrays.

Encodes/decodes fixed-size arrays via RangeCodec with known bounds.
"""

from typing import Any, List, Iterable
from .codec_base import Codec


class ArrayCodec(Codec):
    """Codec for encoding/decoding fixed-size arrays."""

    def __init__(self, element_codec: Codec, size: int):
        """
        Initialize an array codec.

        Args:
            element_codec: The codec for array elements
            size: The fixed size of the array
        """
        self.element_codec = element_codec
        self.size = size

    def encode(self, value: List) -> Iterable[Any]:
        """
        Encode an array to an iterable of encoded elements.

        Returns an iterable that RangeCodec will consume.
        """
        if len(value) != self.size:
            raise ValueError(f"Expected array of length {self.size}, got {len(value)}")
        # Return iterable - RangeCodec will encode each element
        return value

    def decode(self, value: Iterable[Any]) -> List:
        """
        Decode an array from an iterable of encoded elements.

        Consumes exactly self.size elements from the iterable (generator from RangeCodec).
        """
        # Consume exactly self.size elements from the generator
        elements = []
        iterator = iter(value)
        for _ in range(self.size):
            try:
                elements.append(next(iterator))
            except StopIteration:
                raise ValueError(f"Expected {self.size} elements, got {len(elements)}")
        return elements

    def next_codec(self) -> 'Codec':
        """Return a range codec for the elements."""
        from .range_codec import RangeCodec
        return RangeCodec(self.element_codec)


def array_codec(element_codec: Codec, size: int) -> ArrayCodec:
    """Create an array codec for fixed-size arrays."""
    return ArrayCodec(element_codec, size)

