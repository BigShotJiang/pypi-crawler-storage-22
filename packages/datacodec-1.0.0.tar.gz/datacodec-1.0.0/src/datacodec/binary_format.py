"""
Binary format for serialization/deserialization.

Following muesli's binary_format pattern:
- Codecs decompose to primitives via encode() and next_codec()
- Format layer only handles primitive types
- Primitives: IdentityCodec, SizeCodec, TupleCodec, RangeCodec, VariantCodec, MonostateCodec
"""

import struct
import io
from typing import Any, Optional, BinaryIO, Union
from .codecs import Codec, IdentityCodec, TupleCodec, VariantCodec
from .array_codec import ArrayCodec
from .vector_codec import VectorCodec
from .range_codec import RangeCodec
from .delimited_codec import DelimitedCodec
from .monostate_codec import MonostateCodec, Monostate
from .size_codec import SizeCodec
from .platform import PlatformConfig, DEFAULT_CONFIG, get_platform_config

class BinaryFormat:
    """
    Binary serialization format.

    This format handles encoding/decoding of values to/from binary streams
    with proper alignment and byte ordering.
    Supports cross-platform compatibility through configurable platform settings.
    """

    def __init__(self, codec: Codec, byte_order: str = '=',
                 platform: Union[PlatformConfig, str, None] = None):
        """
        Initialize a binary format.

        Args:
            codec: The codec to use for encoding/decoding
            byte_order: Struct byte order ('<' = little-endian, '>' = big-endian, '=' = native)
            platform: Platform configuration (PlatformConfig object, platform name string, or None for native)
                     Examples: 'arm32', 'x86-64', PlatformConfig(...), None
        """
        self.codec = codec
        self.byte_order = byte_order

        if platform is None:
            self.platform = DEFAULT_CONFIG
        elif isinstance(platform, str):
            self.platform = get_platform_config(platform)
        elif isinstance(platform, PlatformConfig):
            self.platform = platform
        else:
            raise TypeError(f"platform must be PlatformConfig, str, or None, got {type(platform)}")

    def serialize(self, value: Any, output: BinaryIO) -> None:
        """
        Serialize a value to binary output.

        Args:
            value: The value to serialize
            output: Binary output stream

        Raises:
            Exception: If serialization fails
        """
        if self._is_primitive_codec(self.codec):
            self._serialize_primitive(value, output, self.codec)
        else:
            encoded = self.codec.encode(value)
            next_codec = self.codec.next_codec()
            next_format = BinaryFormat(next_codec, self.byte_order, self.platform)
            next_format.serialize(encoded, output)


    def _is_primitive_codec(self, codec: Codec) -> bool:
        """
        Check if codec is a primitive type.

        True primitives (handled directly by format layer):
        - IdentityCodec: fundamental types (int, float, bool)
        - SizeCodec: platform-specific size type (adapts based on platform config)
        - TupleCodec: fixed tuples (elements recursively serialized)
        - RangeCodec: iterables/generators (reads/writes on-demand)
        - VariantCodec: sum types (index + active alternative)
        - MonostateCodec: empty/unit type (nothing to serialize)

        NOT primitives (decompose via next_codec):
        - ArrayCodec -> next_codec() returns RangeCodec
        - VectorCodec -> next_codec() returns TupleCodec(size_codec, RangeCodec)
        - DelimitedCodec -> next_codec() returns RangeCodec (decode consumes until delimiter)
        - OptionalCodec -> next_codec() returns VariantCodec
        - PairCodec -> next_codec() returns TupleCodec
        - StringCodec -> next_codec() returns DelimitedCodec
        - VarintCodec -> next_codec() returns DelimitedCodec
        - ConstantCodec -> next_codec() returns inner_codec.next_codec()
        """
        return isinstance(codec, (
            IdentityCodec,
            SizeCodec,
            TupleCodec,
            RangeCodec,
            VariantCodec,
            MonostateCodec
        ))

    def deserialize(self, input: BinaryIO) -> Any:
        """
        Deserialize a value from binary input.

        Args:
            input: Binary input stream

        Returns:
            The deserialized value

        Raises:
            Exception: If deserialization fails
        """
        if self._is_primitive_codec(self.codec):
            return self._deserialize_primitive(input, self.codec)
        else:
            next_codec = self.codec.next_codec()
            next_format = BinaryFormat(next_codec, self.byte_order, self.platform)
            encoded = next_format.deserialize(input)
            return self.codec.decode(encoded)

    @staticmethod
    def _align_output(output: BinaryIO, alignment: int):
        """Add padding bytes to align output to the specified boundary."""
        if alignment <= 1:
            return

        current_pos = output.tell()
        padding = (alignment - (current_pos % alignment)) % alignment
        if padding > 0:
            output.write(b'\x00' * padding)

    @staticmethod
    def _align_input(input: BinaryIO, alignment: int):
        """Skip padding bytes to align input to the specified boundary."""
        if alignment <= 1:
            return

        current_pos = input.tell()
        padding = (alignment - (current_pos % alignment)) % alignment
        if padding > 0:
            input.seek(current_pos + padding)

    def _serialize_primitive(self, value: Any, output: BinaryIO, codec: Codec):
        """
        Serialize a primitive value.

        Only handles true primitives. Everything else should go through codec chain recursion.
        """
        if isinstance(codec, MonostateCodec):
            return

        if isinstance(codec, IdentityCodec):
            self._align_output(output, codec.alignment())
            packed = struct.pack(f'{self.byte_order}{codec.format_char}', value)
            output.write(packed)
            return

        if isinstance(codec, SizeCodec):
            if self.platform.pointer_size == 8:
                self._align_output(output, 8)
                packed = struct.pack(f'{self.byte_order}Q', value)
            else:
                self._align_output(output, 4)
                packed = struct.pack(f'{self.byte_order}I', value)
            output.write(packed)
            return

        if isinstance(codec, TupleCodec):
            if not isinstance(value, tuple):
                raise ValueError(f"Expected tuple, got {type(value)}")
            for elem, elem_codec in zip(value, codec.codecs):
                elem_format = BinaryFormat(elem_codec, self.byte_order, self.platform)
                elem_format.serialize(elem, output)
            return

        if isinstance(codec, RangeCodec):
            for elem in value:
                elem_format = BinaryFormat(codec.element_codec, self.byte_order, self.platform)
                elem_format.serialize(elem, output)
            return

        if isinstance(codec, VariantCodec):
            if not isinstance(value, tuple) or len(value) != 2:
                raise ValueError(f"Expected (index, value) tuple, got {value}")

            index, val = value

            num_alternatives = len(codec.alternative_codecs)
            if num_alternatives <= 256:
                index_codec = IdentityCodec(int, 'B', 1)
            elif num_alternatives <= 65536:
                index_codec = IdentityCodec(int, 'H', 2)
            elif num_alternatives <= 4294967296:
                index_codec = IdentityCodec(int, 'I', 4)
            else:
                index_codec = IdentityCodec(int, 'Q', 8)

            index_format = BinaryFormat(index_codec, self.byte_order, self.platform)
            index_format.serialize(index, output)

            alt_format = BinaryFormat(codec.alternative_codecs[index], self.byte_order, self.platform)
            alt_format.serialize(val, output)
            return

        raise ValueError(f"Unsupported primitive codec type: {type(codec)}")


    def _deserialize_primitive(self, input: BinaryIO, codec: Codec) -> Any:
        """
        Deserialize a primitive value.

        Only handles true primitives. Everything else should go through codec chain recursion.
        """
        if isinstance(codec, MonostateCodec):
            from .monostate_codec import monostate
            return monostate

        if isinstance(codec, IdentityCodec):
            self._align_input(input, codec.alignment())
            packed = input.read(codec.size)
            if len(packed) < codec.size:
                raise EOFError(f"Expected {codec.size} bytes, got {len(packed)}")
            value = struct.unpack(f'{self.byte_order}{codec.format_char}', packed)[0]
            return value

        if isinstance(codec, SizeCodec):
            if self.platform.pointer_size == 8:
                self._align_input(input, 8)
                packed = input.read(8)
                if len(packed) < 8:
                    raise EOFError(f"Expected 8 bytes for size_codec, got {len(packed)}")
                value = struct.unpack(f'{self.byte_order}Q', packed)[0]
            else:
                self._align_input(input, 4)
                packed = input.read(4)
                if len(packed) < 4:
                    raise EOFError(f"Expected 4 bytes for size_codec, got {len(packed)}")
                value = struct.unpack(f'{self.byte_order}I', packed)[0]
            return value

        if isinstance(codec, TupleCodec):
            elements = []
            for elem_codec in codec.codecs:
                elem_format = BinaryFormat(elem_codec, self.byte_order, self.platform)
                elem = elem_format.deserialize(input)
                elements.append(elem)
            return tuple(elements)

        if isinstance(codec, RangeCodec):
            def read_elements():
                """Generator that reads elements from input on-demand."""
                elem_format = BinaryFormat(codec.element_codec, self.byte_order, self.platform)
                while True:
                    start_pos = input.tell()

                    try:
                        elem = elem_format.deserialize(input)
                        yield elem
                    except EOFError:
                        end_pos = input.tell()
                        if end_pos == start_pos:
                            return
                        raise

            return read_elements()

        if isinstance(codec, VariantCodec):
            num_alternatives = len(codec.alternative_codecs)
            if num_alternatives <= 256:
                index_codec = IdentityCodec(int, 'B', 1)
            elif num_alternatives <= 65536:
                index_codec = IdentityCodec(int, 'H', 2)
            elif num_alternatives <= 4294967296:
                index_codec = IdentityCodec(int, 'I', 4)
            else:
                index_codec = IdentityCodec(int, 'Q', 8)

            index_format = BinaryFormat(index_codec, self.byte_order, self.platform)
            index = index_format.deserialize(input)
            if index is None or index >= num_alternatives:
                return None

            alt_format = BinaryFormat(codec.alternative_codecs[index], self.byte_order, self.platform)
            val = alt_format.deserialize(input)
            if val is None:
                return None

            return (index, val)

        raise ValueError(f"Unsupported primitive codec type: {type(codec)}")



