"""
Base codec class and abstract interface.

All codecs must inherit from this base class and implement the required methods.
"""

from abc import ABC, abstractmethod
from typing import Any
from .fluent import FluentCodecMixin


class Codec(ABC, FluentCodecMixin):
    """Base class for all codecs."""

    @abstractmethod
    def encode(self, value: Any) -> Any:
        """Encode a value."""
        pass

    @abstractmethod
    def decode(self, value: Any) -> Any:
        """Decode a value."""
        pass

    @abstractmethod
    def next_codec(self) -> 'Codec':
        """
        Return the next codec in the encoding chain.

        This method must be implemented by all codecs to support
        the codec decomposition pattern.
        """
        pass

