"""
Binary codecs for primitive and composite types.
This module imports and re-exports all codec types from their individual files.
"""
# Base codec class
from .codec_base import Codec
# Identity codec and predefined instances
from .identity_codec import (
    IdentityCodec,
    int8_codec, uint8_codec,
    int16_codec, uint16_codec,
    int32_codec, uint32_codec,
    int64_codec, uint64_codec,
    float_codec, double_codec,
    bool_codec
)
# Composite codecs
from .tuple_codec import TupleCodec, tuple_codec
from .array_codec import ArrayCodec, array_codec
from .vector_codec import VectorCodec, vector_codec
from .optional_codec import OptionalCodec, optional_codec
from .variant_codec import VariantCodec, variant_codec
__all__ = [
    "Codec",
    "IdentityCodec",
    "TupleCodec",
    "ArrayCodec",
    "VectorCodec",
    "OptionalCodec",
    "VariantCodec",
    "int8_codec", "uint8_codec",
    "int16_codec", "uint16_codec",
    "int32_codec", "uint32_codec",
    "int64_codec", "uint64_codec",
    "float_codec", "double_codec",
    "bool_codec",
    "tuple_codec",
    "array_codec",
    "vector_codec",
    "optional_codec",
    "variant_codec",
]
