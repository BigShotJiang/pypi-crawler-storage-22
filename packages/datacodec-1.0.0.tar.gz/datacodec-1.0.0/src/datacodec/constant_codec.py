"""
Constant codec for constant values with validation.
"""

from typing import Any
from .codec_base import Codec


class ConstantCodec(Codec):
    """
    Codec for constant values.

    Always encodes the constant value (validating input matches).
    Always validates decoded value matches the constant.
    """

    def __init__(self, inner_codec: Codec, constant_value: Any):
        """
        Initialize a constant codec.

        Args:
            inner_codec: Codec used to serialize the constant
            constant_value: The constant value to encode/validate
        """
        self.inner_codec = inner_codec
        self.constant_value = constant_value

    def encode(self, value: Any) -> Any:
        """Validate value matches constant, then encode the constant."""
        if value != self.constant_value:
            raise ValueError(f"Expected constant {self.constant_value}, got {value}")
        return self.inner_codec.encode(self.constant_value)

    def decode(self, value: Any) -> Any:
        """Decode value and validate it matches the constant."""
        decoded = self.inner_codec.decode(value)
        if decoded != self.constant_value:
            raise ValueError(f"Expected constant {self.constant_value}, got {decoded}")
        return self.constant_value

    def next_codec(self) -> Codec:
        """Return the inner codec's next codec."""
        return self.inner_codec.next_codec()


def constant_codec(inner_codec: Codec, value: Any) -> ConstantCodec:
    """Create a codec for a constant value."""
    return ConstantCodec(inner_codec, value)

