"""
Constrained codec for validating values against predicates.
"""

from typing import Any, Callable
from .codec_base import Codec


class ConstrainedCodec(Codec):
    """
    Codec that validates values against a predicate.

    Raises ValueError if encoded/decoded value doesn't satisfy the constraint.
    """

    def __init__(self, inner_codec: Codec, predicate: Callable[[Any], bool]):
        """
        Initialize a constrained codec.

        Args:
            inner_codec: The underlying codec
            predicate: Function that returns True if value is valid
        """
        self.inner_codec = inner_codec
        self.predicate = predicate

    def encode(self, value: Any) -> Any:
        """Validate and encode value."""
        if not self.predicate(value):
            raise ValueError(f"Value {value} failed constraint validation")
        return self.inner_codec.encode(value)

    def decode(self, value: Any) -> Any:
        """Decode and validate value."""
        decoded = self.inner_codec.decode(value)
        if not self.predicate(decoded):
            raise ValueError(f"Decoded value {decoded} failed constraint validation")
        return decoded

    def next_codec(self) -> Codec:
        """Return the inner codec's next codec."""
        return self.inner_codec.next_codec()

