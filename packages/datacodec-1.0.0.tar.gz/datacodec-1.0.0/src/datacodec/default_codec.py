"""
Default codec for providing default values for None inputs.
"""

from typing import Any
from .codec_base import Codec


class DefaultCodec(Codec):
    """
    Codec that provides a default value for None inputs.
    """

    def __init__(self, inner_codec: Codec, default_value: Any):
        """
        Initialize a default codec.

        Args:
            inner_codec: The underlying codec
            default_value: Value to use when input is None
        """
        self.inner_codec = inner_codec
        self.default_value = default_value

    def encode(self, value: Any) -> Any:
        """Use default if value is None, otherwise encode normally."""
        if value is None:
            value = self.default_value
        return self.inner_codec.encode(value)

    def decode(self, value: Any) -> Any:
        """Decode normally."""
        return self.inner_codec.decode(value)

    def next_codec(self) -> Codec:
        """Return the inner codec's next codec."""
        return self.inner_codec.next_codec()

