"""
Delimited codec for delimiter-terminated sequences.
"""

from typing import Any, Callable, List
from .codecs import Codec
from .fluent import FluentCodecMixin


class DelimitedCodec(Codec, FluentCodecMixin):
    """
    Codec for delimiter-terminated sequences (like null-terminated strings).

    Reads/writes elements until a delimiter is encountered.

    Args:
        element_codec: Codec for individual elements
        delimiter_predicate: Function that returns True when delimiter is found

    Example:
        # Null-terminated string
        null_term_codec = DelimitedCodec(
            uint8_codec,  # char codec
            lambda c: c == 0  # null terminator predicate
        )
    """

    def __init__(self, element_codec: Codec, delimiter_predicate: Callable[[Any], bool]):
        """
        Initialize a delimited codec.

        Args:
            element_codec: Codec for individual elements
            delimiter_predicate: Predicate returning True for delimiter elements
        """
        self.element_codec = element_codec
        self.delimiter_predicate = delimiter_predicate

    def encode(self, value: List[Any]) -> Any:
        """
        Encode a sequence as an iterable (generator will be created by RangeCodec).

        Args:
            value: List of elements to encode (must include delimiter)

        Returns:
            Iterable that RangeCodec will consume
        """
        # Just return the value - RangeCodec will encode each element
        # The delimiter must already be in the value
        return value

    def decode(self, value: Any) -> List[Any]:
        """
        Decode a sequence from a generator, consuming until delimiter.

        Args:
            value: Generator of decoded elements from RangeCodec

        Returns:
            List of decoded elements (including delimiter at end)
        """
        result = []
        for elem in value:
            result.append(elem)
            # Check if this is the delimiter - stop consuming from generator
            if self.delimiter_predicate(elem):
                break
        return result

    def next_codec(self) -> Codec:
        """Return a range codec for the element sequence."""
        from .range_codec import RangeCodec
        return RangeCodec(self.element_codec)  # Pass element_codec, not next_codec()


def delimited_codec(element_codec: Codec, delimiter_predicate: Callable[[Any], bool]) -> DelimitedCodec:
    """
    Create a codec for delimiter-terminated sequences.

    Args:
        element_codec: Codec for individual elements
        delimiter_predicate: Function that returns True for delimiter

    Returns:
        DelimitedCodec instance

    Example:
        # Null-terminated byte sequence
        null_term = delimited_codec(uint8_codec, lambda c: c == 0)
    """
    return DelimitedCodec(element_codec, delimiter_predicate)

