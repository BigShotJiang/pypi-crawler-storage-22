"""
Fluent API mixins for codecs.

Provides chainable methods for transforming, constraining, and composing codecs.
"""

from typing import Any, Callable, Optional, TypeVar, Generic
from abc import ABC

T = TypeVar('T')
U = TypeVar('U')


class FluentCodecMixin:
    """
    Base mixin providing fluent API methods for codecs.

    This allows method chaining like:
        codec.transform(...).constrain(...).optional()
    """

    def transform(self, encode_fn: Callable[[Any], Any],
                  decode_fn: Callable[[Any], Any]) -> 'TransformCodec':
        """
        Apply bidirectional transformation to encode and decode.

        Args:
            encode_fn: Function to apply during encoding
            decode_fn: Function to apply during decoding

        Returns:
            TransformCodec wrapping this codec

        Example:
            >>> # Double values on encode, halve on decode
            >>> doubled = int32_codec.transform(
            ...     lambda x: x * 2,
            ...     lambda x: x // 2
            ... )
        """
        from .advanced_codecs import TransformCodec
        return TransformCodec(self, encode_fn, decode_fn)

    def transform_input(self, decode_fn: Callable[[Any], Any]) -> 'TransformCodec':
        """
        Transform only during deserialization (decode).

        Args:
            decode_fn: Function to apply during decoding

        Returns:
            TransformCodec that only transforms on decode

        Example:
            >>> # Convert to uppercase on decode
            >>> uppercase = string_codec.transform_input(str.upper)
        """
        return self.transform(lambda x: x, decode_fn)

    def transform_output(self, encode_fn: Callable[[Any], Any]) -> 'TransformCodec':
        """
        Transform only during serialization (encode).

        Args:
            encode_fn: Function to apply during encoding

        Returns:
            TransformCodec that only transforms on encode

        Example:
            >>> # Convert to lowercase on encode
            >>> lowercase = string_codec.transform_output(str.lower)
        """
        return self.transform(encode_fn, lambda x: x)

    def constrain(self, predicate: Callable[[Any], bool]) -> 'ConstrainedCodec':
        """
        Add a validation constraint to the codec.

        Args:
            predicate: Function that returns True if value is valid

        Returns:
            ConstrainedCodec that validates values

        Example:
            >>> # Only allow positive integers
            >>> positive = int32_codec.constrain(lambda x: x > 0)
        """
        from .advanced_codecs import ConstrainedCodec
        return ConstrainedCodec(self, predicate)

    def optional(self) -> 'OptionalCodec':
        """
        Wrap codec to handle optional (nullable) values.

        Returns:
            OptionalCodec for encoding/decoding Optional[T]

        Example:
            >>> opt_int = int32_codec.optional()
            >>> opt_int.encode(None)  # Encodes as (False, None)
            >>> opt_int.encode(42)    # Encodes as (True, 42)
        """
        from .codecs import OptionalCodec
        return OptionalCodec(self)

    def default(self, default_value: Any) -> 'DefaultCodec':
        """
        Provide a default value for missing/None values.

        Args:
            default_value: Value to use when input is None

        Returns:
            DefaultCodec that substitutes default on None

        Example:
            >>> # Use 0 for None values
            >>> with_default = int32_codec.default(0)
        """
        from .advanced_codecs import DefaultCodec
        return DefaultCodec(self, default_value)

    def apply(self, type_class: type) -> 'ApplyCodec':
        """
        Apply codec result to construct an instance of type_class.

        Args:
            type_class: Type to construct from decoded value

        Returns:
            ApplyCodec that constructs instances

        Example:
            >>> from dataclasses import dataclass
            >>> @dataclass
            ... class Point:
            ...     x: int
            ...     y: int
            >>> point_codec = tuple_codec(int32_codec, int32_codec).apply(Point)
        """
        from .advanced_codecs import ApplyCodec
        return ApplyCodec(self, type_class)

    def member(self, getter: Callable[[Any], Any]) -> 'MemberCodec':
        """
        Extract a member from an object using a getter function.

        Enables fluent object serialization similar to muesli's .member<>().
        When used with tuple_codec().apply(), the apply codec automatically
        uses the .project() method to extract members from the object.

        Args:
            getter: Function or attribute name to extract member

        Returns:
            MemberCodec that extracts and encodes the member

        Example:
            >>> from dataclasses import dataclass
            >>> @dataclass
            ... class Person:
            ...     name: str
            ...     age: int
            >>>
            >>> # Fluent API with .member() and .apply()
            >>> person_codec = tuple_codec(
            ...     string_codec.member('name'),
            ...     int32_codec.member('age')
            ... ).apply(Person)
            >>>
            >>> # Or with lambda getters
            >>> person_codec = tuple_codec(
            ...     string_codec.member(lambda p: p.name),
            ...     int32_codec.member(lambda p: p.age)
            ... ).apply(Person)
        """
        from .member_codec import MemberCodec

        # If getter is a string, convert to attribute getter
        if isinstance(getter, str):
            attr_name = getter
            getter = lambda obj: getattr(obj, attr_name)

        return MemberCodec(self, getter)

