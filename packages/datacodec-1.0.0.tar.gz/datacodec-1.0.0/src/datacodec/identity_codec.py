"""
Identity codec for primitive types.

Passes values through unchanged, used for fundamental types like int, float, bool.
"""

import struct
from typing import Any
from .codec_base import Codec


class IdentityCodec(Codec):
    """Identity codec that passes values through unchanged."""

    def __init__(self, value_type: type, format_char: str = None, size: int = None):
        """
        Initialize an identity codec.

        Args:
            value_type: The Python type this codec handles
            format_char: The struct format character (e.g., 'b', 'h', 'i', 'f')
            size: Size in bytes (for alignment purposes)
        """
        self.value_type = value_type
        self.format_char = format_char
        self.size = size if size is not None else (struct.calcsize(format_char) if format_char else 1)

    def encode(self, value: Any) -> Any:
        """Return value unchanged."""
        return value

    def decode(self, value: Any) -> Any:
        """Return value unchanged."""
        return value

    def alignment(self) -> int:
        """Return the alignment requirement for this type."""
        return self.size

    def next_codec(self) -> 'Codec':
        """Identity codec is primitive - returns self."""
        return self


# Predefined codec instances for common types

# Fixed-width integer codecs
int8_codec = IdentityCodec(int, 'b', 1)
uint8_codec = IdentityCodec(int, 'B', 1)
int16_codec = IdentityCodec(int, 'h', 2)
uint16_codec = IdentityCodec(int, 'H', 2)
int32_codec = IdentityCodec(int, 'i', 4)
uint32_codec = IdentityCodec(int, 'I', 4)
int64_codec = IdentityCodec(int, 'q', 8)
uint64_codec = IdentityCodec(int, 'Q', 8)

# Floating-point codecs
float_codec = IdentityCodec(float, 'f', 4)
double_codec = IdentityCodec(float, 'd', 8)

# Boolean codec
bool_codec = IdentityCodec(bool, '?', 1)

