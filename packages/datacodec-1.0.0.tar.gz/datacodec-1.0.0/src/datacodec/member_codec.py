"""
Member codec - extract values using getter functions instead of direct access.

Useful for properties, computed values, or encapsulated data.
"""

from typing import Any, Callable
from .codecs import Codec
from .fluent import FluentCodecMixin


class MemberCodec(Codec, FluentCodecMixin):
    """
    Codec that extracts/injects values using getter/setter functions.

    Allows encoding objects using accessor functions rather than direct member access.
    Useful for properties, methods, or computed values.

    Args:
        inner_codec: Codec for the extracted value
        getter: Function to extract value from object

    Example:
        # Extract using property
        class Person:
            def __init__(self, first, last):
                self._first = first
                self._last = last

            def get_full_name(self):
                return f"{self._first} {self._last}"

        # Create codec manually with tuple_codec and apply
        person_codec = tuple_codec(
            member_codec(string_codec, lambda p: p._first),
            member_codec(string_codec, lambda p: p._last),
        ).apply(Person)
    """

    def __init__(self, inner_codec: Codec, getter: Callable[[Any], Any]):
        """
        Initialize member codec.

        Args:
            inner_codec: Codec for the member value
            getter: Function to extract value from object
        """
        self.inner_codec = inner_codec
        self.getter = getter

    def encode(self, value: Any) -> Any:
        """
        Encode by extracting member value and encoding it.

        Args:
            value: Object to extract from

        Returns:
            Encoded member value
        """
        member_value = self.getter(value)
        return self.inner_codec.encode(member_value)

    def decode(self, value: Any) -> Any:
        """
        Decode member value.

        Note: MemberCodec.decode returns just the decoded member value.
        Use with tuple_codec and apply to reconstruct objects.

        Args:
            value: Encoded member value

        Returns:
            Decoded member value
        """
        return self.inner_codec.decode(value)

    def next_codec(self) -> Codec:
        """Return the inner codec's next codec."""
        return self.inner_codec.next_codec()

    def project(self, value: Any) -> Any:
        """
        Project/extract value from owner object.

        This is called by ApplyCodec when encoding objects with member codecs.

        Args:
            value: Owner object to extract from

        Returns:
            Extracted member value
        """
        return self.getter(value)


def member_codec(inner_codec: Codec, getter: Callable[[Any], Any]) -> MemberCodec:
    """
    Create a codec that extracts values using a getter function.

    Args:
        inner_codec: Codec for the extracted value
        getter: Function to extract value from object

    Returns:
        MemberCodec instance

    Example:
        # Simple getter
        age_codec = member_codec(uint8_codec, lambda p: p.age)

        # Method getter
        name_codec = member_codec(string_codec, lambda p: p.get_name())

        # Build complete codec using fluent .member() API
        person_codec = tuple_codec(
            string_codec.member(lambda p: p.name),
            uint8_codec.member(lambda p: p.age),
        ).apply(PersonClass)
    """
    return MemberCodec(inner_codec, getter)



