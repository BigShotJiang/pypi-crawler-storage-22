"""
Monostate codec - represents empty/unit type.

This is a true primitive that serializes to nothing and deserializes to a singleton value.
Used for empty variants, unit types, and as placeholder in unions.
"""

from typing import Any
from .codecs import Codec
from .fluent import FluentCodecMixin


class Monostate:
    """
    Singleton monostate/unit type.

    Represents an empty value, similar to C++'s std::monostate or Rust's ().
    Used in variants to represent "no value" alternatives.
    """
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self):
        return "Monostate()"

    def __eq__(self, other):
        return isinstance(other, Monostate)

    def __hash__(self):
        return hash(Monostate)


# Singleton instance
monostate = Monostate()


class MonostateCodec(Codec, FluentCodecMixin):
    """
    Codec for monostate/empty values.

    This is a true primitive:
    - encode() returns monostate (singleton)
    - decode() returns monostate (singleton)
    - Serializes to nothing (0 bytes)
    - Deserializes to monostate

    This is the actual primitive that format.py handles.
    ConstantCodec uses this internally via next_codec().
    """

    def encode(self, value: Any) -> Monostate:
        """Encode any value to monostate."""
        return monostate

    def decode(self, value: Any) -> Monostate:
        """Decode to monostate."""
        return monostate

    def next_codec(self) -> 'MonostateCodec':
        """Monostate is primitive, returns self."""
        return self


# Singleton codec instance
monostate_codec = MonostateCodec()

