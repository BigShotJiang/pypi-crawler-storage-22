"""
NumPy codec support.

Provides codecs for NumPy array types and automatic codec generation
for NumPy-aware dataclasses.
"""

from typing import Any, Type, Optional

# Check if NumPy is available
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    np = None


def numpy_array_codec(dtype, shape=None):
    """
    Create a codec for NumPy arrays.

    Args:
        dtype: NumPy dtype (e.g., np.float32, np.int32)
        shape: Optional fixed shape. If None, encodes as vector with dynamic size.
               If tuple, encodes as fixed-size array.

    Returns:
        Codec for NumPy arrays

    Example:
        # Dynamic size float32 array
        float_array_codec = numpy_array_codec(np.float32)

        # Fixed size 3D vector
        vec3_codec = numpy_array_codec(np.float32, shape=(3,))

        # Fixed 4x4 matrix
        mat4_codec = numpy_array_codec(np.float32, shape=(4, 4))
    """
    if not HAS_NUMPY:
        raise ImportError("NumPy is not installed. Install with: pip install numpy")

    from . import (
        int8_codec, int16_codec, int32_codec, int64_codec,
        uint8_codec, uint16_codec, uint32_codec, uint64_codec,
        float_codec, double_codec,
        array_codec, vector_codec
    )

    # Map NumPy dtype to codec
    dtype_map = {
        np.int8: int8_codec,
        np.int16: int16_codec,
        np.int32: int32_codec,
        np.int64: int64_codec,
        np.uint8: uint8_codec,
        np.uint16: uint16_codec,
        np.uint32: uint32_codec,
        np.uint64: uint64_codec,
        np.float32: float_codec,
        np.float64: double_codec,
    }

    # Normalize dtype
    np_dtype = np.dtype(dtype)
    element_codec = dtype_map.get(np_dtype.type)

    if element_codec is None:
        raise ValueError(f"Unsupported NumPy dtype: {np_dtype}")

    if shape is None:
        # Dynamic size - use vector codec with transform to/from numpy
        return vector_codec(element_codec).transform(
            lambda arr: arr.tolist() if isinstance(arr, np.ndarray) else arr,
            lambda lst: np.array(lst, dtype=np_dtype)
        )
    elif len(shape) == 1:
        # 1D fixed size - use array codec
        return array_codec(element_codec, shape[0]).transform(
            lambda arr: arr.tolist() if isinstance(arr, np.ndarray) else arr,
            lambda lst: np.array(lst, dtype=np_dtype)
        )
    else:
        # Multi-dimensional - flatten to 1D array
        total_size = int(np.prod(shape))
        return array_codec(element_codec, total_size).transform(
            lambda arr: arr.flatten().tolist() if isinstance(arr, np.ndarray) else arr,
            lambda lst: np.array(lst, dtype=np_dtype).reshape(shape)
        )


def get_numpy_codec(numpy_type: Type) -> Optional[Any]:
    """
    Get codec for a NumPy type.

    Args:
        numpy_type: NumPy dtype type

    Returns:
        Appropriate codec, or None if not a known NumPy type
    """
    if not HAS_NUMPY:
        return None

    from . import (
        int8_codec, int16_codec, int32_codec, int64_codec,
        uint8_codec, uint16_codec, uint32_codec, uint64_codec,
        float_codec, double_codec, bool_codec
    )

    numpy_type_map = {
        np.int8: int8_codec,
        np.int16: int16_codec,
        np.int32: int32_codec,
        np.int64: int64_codec,
        np.uint8: uint8_codec,
        np.uint16: uint16_codec,
        np.uint32: uint32_codec,
        np.uint64: uint64_codec,
        np.float32: float_codec,
        np.float64: double_codec,
        np.bool_: bool_codec,
    }

    return numpy_type_map.get(numpy_type)


# Export HAS_NUMPY for other modules to check
__all__ = ['numpy_array_codec', 'get_numpy_codec', 'HAS_NUMPY']

