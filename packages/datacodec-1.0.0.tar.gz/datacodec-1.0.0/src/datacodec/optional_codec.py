"""
Optional codec for nullable values.

Encodes/decodes optional values to VariantCodec(MonostateCodec, value_codec).
"""

from typing import Any, Optional, Tuple
from .codec_base import Codec


class OptionalCodec(Codec):
    """Codec for encoding/decoding optional values."""

    def __init__(self, value_codec: Codec):
        """
        Initialize an optional codec.

        Args:
            value_codec: The codec for the contained value
        """
        self.value_codec = value_codec

    def encode(self, value: Optional[Any]) -> Tuple[int, Any]:
        """Encode optional as variant: index 0 = None (monostate), index 1 = value."""
        if value is None:
            from .monostate_codec import monostate
            return (0, monostate)
        return (1, self.value_codec.encode(value))

    def decode(self, value: Tuple[int, Any]) -> Optional[Any]:
        """Decode from variant representation."""
        index, val = value
        if index == 0:
            return None
        return self.value_codec.decode(val)

    def next_codec(self) -> 'Codec':
        """Return a variant codec of [Monostate, value]."""
        from .monostate_codec import monostate_codec
        from .variant_codec import VariantCodec
        return VariantCodec(
            monostate_codec,  # Alternative 0: monostate (represents None)
            self.value_codec.next_codec()  # Alternative 1: value
        )


def optional_codec(value_codec: Codec) -> OptionalCodec:
    """Create an optional codec for nullable values."""
    return OptionalCodec(value_codec)

