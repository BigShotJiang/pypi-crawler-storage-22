"""
Pair codec for 2-tuples.
"""

from typing import Any, Tuple
from .codec_base import Codec


class PairCodec(Codec):
    """
    Codec for pairs/2-tuples.

    Convenience codec for encoding pairs of values.
    """

    def __init__(self, first_codec: Codec, second_codec: Codec):
        """
        Initialize a pair codec.

        Args:
            first_codec: Codec for first element
            second_codec: Codec for second element
        """
        self.first_codec = first_codec
        self.second_codec = second_codec

    def encode(self, value: Tuple[Any, Any]) -> Tuple[Any, Any]:
        """Encode a pair."""
        if not isinstance(value, tuple) or len(value) != 2:
            raise ValueError(f"Expected 2-tuple, got {value}")
        return (self.first_codec.encode(value[0]),
                self.second_codec.encode(value[1]))

    def decode(self, value: Tuple[Any, Any]) -> Tuple[Any, Any]:
        """Decode a pair."""
        if not isinstance(value, tuple) or len(value) != 2:
            raise ValueError(f"Expected 2-tuple, got {value}")
        return (self.first_codec.decode(value[0]),
                self.second_codec.decode(value[1]))

    def next_codec(self) -> Codec:
        """Return a TupleCodec for the encoded pair."""
        from .tuple_codec import TupleCodec
        return TupleCodec(
            self.first_codec.next_codec(),
            self.second_codec.next_codec()
        )


def pair_codec(first_codec: Codec, second_codec: Codec) -> PairCodec:
    """Create a codec for pairs."""
    return PairCodec(first_codec, second_codec)

