"""
Platform-specific configuration for binary codec compatibility.

This module defines platform characteristics (type sizes, alignment) to ensure
cross-platform binary compatibility on different targets.
"""

from dataclasses import dataclass
from typing import Dict
import struct


@dataclass(frozen=True)
class PlatformConfig:
    """
    Configuration for platform-specific binary layout.

    Attributes:
        pointer_size: Size of void* in bytes (4 for 32-bit, 8 for 64-bit)
        int_size: Size of int in bytes
        long_size: Size of long in bytes
        long_long_size: Size of long long in bytes
        long_long_alignment: Alignment of long long in bytes
        name: Human-readable platform name
    """
    pointer_size: int
    int_size: int
    long_size: int
    long_long_size: int
    long_long_alignment: int
    name: str

    def __post_init__(self):
        """Validate platform configuration."""
        if self.pointer_size not in (4, 8):
            raise ValueError(f"Invalid pointer_size: {self.pointer_size} (must be 4 or 8)")
        if self.int_size not in (2, 4, 8):
            raise ValueError(f"Invalid int_size: {self.int_size}")
        if self.long_size not in (4, 8):
            raise ValueError(f"Invalid long_size: {self.long_size}")
        if self.long_long_size not in (8,):
            raise ValueError(f"Invalid long_long_size: {self.long_long_size}")
        if self.long_long_alignment not in (4, 8):
            raise ValueError(f"Invalid long_long_alignment: {self.long_long_alignment}")


# Predefined platform configurations

# 32-bit ARM (common embedded target)
ARM32_CONFIG = PlatformConfig(
    pointer_size=4,
    int_size=4,
    long_size=4,
    long_long_size=8,
    long_long_alignment=8,
    name="ARM32"
)

# 32-bit ARM with 4-byte aligned long long (some older compilers)
ARM32_COMPAT_CONFIG = PlatformConfig(
    pointer_size=4,
    int_size=4,
    long_size=4,
    long_long_size=8,
    long_long_alignment=4,
    name="ARM32-Compat"
)

# 64-bit ARM (aarch64)
ARM64_CONFIG = PlatformConfig(
    pointer_size=8,
    int_size=4,
    long_size=8,
    long_long_size=8,
    long_long_alignment=8,
    name="ARM64"
)

# 32-bit x86
X86_32_CONFIG = PlatformConfig(
    pointer_size=4,
    int_size=4,
    long_size=4,
    long_long_size=8,
    long_long_alignment=4,  # x86-32 typically uses 4-byte alignment
    name="x86-32"
)

# 64-bit x86-64
X86_64_CONFIG = PlatformConfig(
    pointer_size=8,
    int_size=4,
    long_size=8,
    long_long_size=8,
    long_long_alignment=8,
    name="x86-64"
)

# Native platform (auto-detected)
_native_pointer_size = struct.calcsize('P')
_native_int_size = struct.calcsize('i')
_native_long_size = struct.calcsize('l')
_native_long_long_size = struct.calcsize('q')

NATIVE_CONFIG = PlatformConfig(
    pointer_size=_native_pointer_size,
    int_size=_native_int_size,
    long_size=_native_long_size,
    long_long_size=_native_long_long_size,
    long_long_alignment=8,  # Conservative default
    name="Native"
)

# Default configuration (native platform)
DEFAULT_CONFIG = NATIVE_CONFIG

# Registry of named configurations
PLATFORM_CONFIGS: Dict[str, PlatformConfig] = {
    'native': NATIVE_CONFIG,
    'arm32': ARM32_CONFIG,
    'arm32-compat': ARM32_COMPAT_CONFIG,
    'arm64': ARM64_CONFIG,
    'x86-32': X86_32_CONFIG,
    'x86-64': X86_64_CONFIG,
}


def get_platform_config(name: str) -> PlatformConfig:
    """
    Get a predefined platform configuration by name.

    Args:
        name: Platform name (case-insensitive)

    Returns:
        PlatformConfig for the specified platform

    Raises:
        KeyError: If platform name is not recognized

    Example:
        >>> config = get_platform_config('arm32')
        >>> config.pointer_size
        4
    """
    name_lower = name.lower()
    if name_lower not in PLATFORM_CONFIGS:
        available = ', '.join(sorted(PLATFORM_CONFIGS.keys()))
        raise KeyError(f"Unknown platform '{name}'. Available: {available}")
    return PLATFORM_CONFIGS[name_lower]

