"""
Python-specific codec support.

Provides codecs for fundamental Python types and automatic codec generation
from dataclasses.
"""

from typing import Any, Type, get_type_hints
from dataclasses import is_dataclass, fields, Field
import sys

# Python 3.8+ compatibility
try:
    from typing import get_origin, get_args
except ImportError:
    # Python < 3.8
    def get_origin(tp):
        return getattr(tp, '__origin__', None)

    def get_args(tp):
        return getattr(tp, '__args__', ())

# Marker for custom codec annotations
_CODEC_ATTR = '__datacodec_codec__'

# Import codec instances from their source modules (not from __init__ to avoid circular import)
from .codecs import (
    int8_codec, int16_codec, int32_codec, int64_codec,
    uint8_codec, uint16_codec, uint32_codec, uint64_codec,
    float_codec, double_codec, bool_codec, tuple_codec
)
from .advanced_codecs import string_codec, signed_varint_codec

_codec_map = {
    'int8': int8_codec,
    'int16': int16_codec,
    'int32': int32_codec,
    'int64': int64_codec,
    'uint8': uint8_codec,
    'uint16': uint16_codec,
    'uint32': uint32_codec,
    'uint64': uint64_codec,
    'float': float_codec,
    'double': double_codec,
    'bool': bool_codec,
    'string': string_codec,
    'signed_varint': signed_varint_codec,
    'tuple': tuple_codec,
}
_codecs_imported = True

def codec(codec_instance):
    """
    Mark a codec for use with a dataclass field.

    Three Pythonic syntax options (in order of preference):

    1. Annotated (RECOMMENDED - Python 3.9+):
        Most explicit, best type checker support.

        from typing import Annotated

        @dataclass
        class Person:
            age: Annotated[int, codec(uint8_codec)]  # Type checkers see 'int'
            health: Annotated[int, codec(uint8_codec)]

    2. Direct codec as type (CLEANEST - trade-off with type safety):
        Minimal syntax, but type checkers see codec type not Python type.

        @dataclass
        class Person:
            age: uint8_codec = None  # Cleanest syntax
            health: uint8_codec = None

    3. Field metadata (BACKWARDS COMPATIBLE - Python 3.8+):
        More verbose, but works on older Python versions.

        from dataclasses import field

        @dataclass
        class Person:
            age: int = field(default_factory=codec(uint8_codec))

    Args:
        codec_instance: The codec to use for this field

    Returns:
        A marker object that works in multiple contexts

    Recommendation:
        Use Annotated for production code (option 1).
        Use direct codec for quick scripts (option 2).
    """
    class CodecMarker:
        """Marker class that holds codec and works as factory."""
        def __init__(self, codec_inst):
            setattr(self, _CODEC_ATTR, codec_inst)

        def __call__(self):
            """When used as default_factory, return None."""
            return None

        def __repr__(self):
            return f"codec({codec_instance})"

    return CodecMarker(codec_instance)


def dataclass_codec(dataclass_type: Type, **field_codecs) -> 'ApplyCodec':
    """
    Automatically generate a codec from a dataclass.

    Uses type hints to determine appropriate codecs for each field.
    Python types map to codecs as follows:
    - int -> signed_varint_codec (Python ints are arbitrary precision)
    - float -> double_codec (Python floats are double precision)
    - bool -> bool_codec
    - str -> string_codec

    For fixed-size integer types, use @codec decorator or explicit field_codecs:
        @dataclass
        class Data:
            id: int = codec(uint8_codec)  # Force uint8
            count: int  # Uses varint (default)

    Args:
        dataclass_type: The dataclass type to generate codec for
        **field_codecs: Optional explicit codecs for specific fields

    Returns:
        ApplyCodec that serializes/deserializes the dataclass

    Example:
        @dataclass
        class Person:
            name: str
            age: int
            height: float

        person_codec = dataclass_codec(Person)

        # Or with explicit field codecs:
        person_codec = dataclass_codec(Person, age=uint8_codec)
    """
    if not is_dataclass(dataclass_type):
        raise TypeError(f"{dataclass_type} is not a dataclass")


    # Get type hints (with include_extras=True to preserve Annotated metadata)
    try:
        hints = get_type_hints(dataclass_type, include_extras=True)
    except Exception:
        hints = get_type_hints(dataclass_type)

    dc_fields = fields(dataclass_type)

    # Build list of codecs for each field
    field_codec_list = []

    for field in dc_fields:
        field_name = field.name

        # Check if explicit codec provided via parameter
        if field_name in field_codecs:
            field_codec_list.append(field_codecs[field_name])
            continue

        # Check if field has @codec decorator via default_factory
        if hasattr(field.default_factory, _CODEC_ATTR):
            field_codec_list.append(getattr(field.default_factory, _CODEC_ATTR))
            continue

        # Get the type hint for this field
        field_type = hints.get(field_name, type(None))

        # Check if type hint IS a codec directly (most Pythonic)
        from .codec_base import Codec
        if isinstance(field_type, type) and issubclass(field_type, Codec):
            # Direct codec class as type annotation
            field_codec_list.append(field_type())
            continue
        elif isinstance(field_type, Codec):
            # Codec instance as type annotation
            field_codec_list.append(field_type)
            continue

        # Check for Annotated type hint with codec metadata
        codec_from_annotation = _extract_codec_from_annotation(field_type)
        if codec_from_annotation is not None:
            field_codec_list.append(codec_from_annotation)
            continue

        # Infer from type hint
        field_codec = _infer_codec_from_type(field_type)

        if field_codec is None:
            raise ValueError(
                f"Cannot infer codec for field '{field_name}' of type {field_type}. "
                f"Please provide explicit codec using field_codecs parameter or Annotated type hint."
            )

        field_codec_list.append(field_codec)

    # Create tuple codec and apply to dataclass
    composite_codec = _codec_map['tuple'](*field_codec_list)
    return composite_codec.apply(dataclass_type)


def _extract_codec_from_annotation(type_hint: Type) -> Any:
    """
    Extract codec from Annotated type hint.

    Example:
        Annotated[int, codec(uint8_codec)] -> uint8_codec

    Returns:
        Codec instance if found in annotation, None otherwise
    """
    # Check if this is an Annotated type
    try:
        from typing import get_origin, get_args

        if get_origin(type_hint) is not None:
            origin = get_origin(type_hint)
            # Check for Annotated (Python 3.9+)
            if hasattr(origin, '__name__') and origin.__name__ == 'Annotated':
                args = get_args(type_hint)
                # args[0] is the actual type, args[1:] are metadata
                for metadata in args[1:]:
                    # Check if metadata has codec attribute (from codec() function)
                    if hasattr(metadata, _CODEC_ATTR):
                        return getattr(metadata, _CODEC_ATTR)
                    # Or if metadata is directly a Codec instance
                    from .codec_base import Codec
                    if isinstance(metadata, Codec):
                        return metadata
    except (ImportError, AttributeError):
        pass

    return None


def _infer_codec_from_type(type_hint: Type) -> Any:
    """
    Infer appropriate codec from a type hint.

    Python type mappings:
    - int -> signed_varint_codec (Python ints are arbitrary precision)
    - float -> double_codec (Python floats are double precision)
    - bool -> bool_codec
    - str -> string_codec

    NumPy types (when numpy is available):
    - np.int8/int16/int32/int64 -> corresponding codec
    - np.uint8/uint16/uint32/uint64 -> corresponding codec
    - np.float32 -> float_codec
    - np.float64 -> double_codec

    Args:
        type_hint: The type to infer codec for

    Returns:
        Appropriate codec instance, or None if cannot infer
    """

    # Check for NumPy types first
    try:
        import numpy as np
        numpy_type_map = {
            np.int8: _codec_map['int8'],
            np.int16: _codec_map['int16'],
            np.int32: _codec_map['int32'],
            np.int64: _codec_map['int64'],
            np.uint8: _codec_map['uint8'],
            np.uint16: _codec_map['uint16'],
            np.uint32: _codec_map['uint32'],
            np.uint64: _codec_map['uint64'],
            np.float32: _codec_map['float'],
            np.float64: _codec_map['double'],
            np.bool_: _codec_map['bool'],
        }

        # Direct type check
        if type_hint in numpy_type_map:
            return numpy_type_map[type_hint]

        # Check if it's a NumPy dtype or scalar type
        if hasattr(type_hint, 'dtype'):
            # It's an instance, get the dtype
            dtype_type = type_hint.dtype.type
            if dtype_type in numpy_type_map:
                return numpy_type_map[dtype_type]

        # Check by string name (fallback for edge cases)
        type_name = getattr(type_hint, '__name__', '')
        if type_name == 'float32':
            return _codec_map['float']
        elif type_name == 'float64':
            return _codec_map['double']
        elif type_name in ('int8', 'int16', 'int32', 'int64'):
            return _codec_map.get(type_name)
        elif type_name in ('uint8', 'uint16', 'uint32', 'uint64'):
            return _codec_map.get(type_name)
    except ImportError:
        pass

    # Handle Optional types
    origin = get_origin(type_hint)
    if origin is not None:
        args = get_args(type_hint)

        # Check if it's a Union type (Optional[T] is Union[T, None])
        import typing
        union_types = [typing.Union]
        # Python 3.10+ has types.UnionType
        try:
            import types
            if hasattr(types, 'UnionType'):
                union_types.append(types.UnionType)
        except ImportError:
            pass

        if origin in union_types or str(origin).startswith('typing.Union'):
            if len(args) == 2 and type(None) in args:
                # It's Optional[T]
                inner_type = args[0] if args[1] is type(None) else args[1]
                inner_codec = _infer_codec_from_type(inner_type)
                if inner_codec:
                    return inner_codec.optional()

        # Could handle List, Dict, etc. here in the future

    # Python type mappings - must check _codec_map each time since module init order varies
    # int -> varint (Python ints are arbitrary precision)
    # float -> double (Python floats are double precision)
    if type_hint == int:
        return _codec_map.get('signed_varint')
    elif type_hint == float:
        return _codec_map.get('double')
    elif type_hint == bool:
        return _codec_map.get('bool')
    elif type_hint == str:
        return _codec_map.get('string')
    else:
        return None


def dict_codec(key_codec, value_codec):
    """
    Create a codec for Python dicts.

    Demonstrates codec composition - no special dict codec needed,
    just combine vector and pair codecs with transforms.

    Args:
        key_codec: Codec for dict keys
        value_codec: Codec for dict values

    Returns:
        Codec that handles dict serialization

    Example:
        my_dict_codec = dict_codec(string_codec, int32_codec)
        data = {"a": 1, "b": 2, "c": 3}
    """
    from .codecs import vector_codec
    from .advanced_codecs import pair_codec

    return vector_codec(pair_codec(key_codec, value_codec)).transform(
        lambda d: list(d.items()),
        lambda items: dict(items)
    )



