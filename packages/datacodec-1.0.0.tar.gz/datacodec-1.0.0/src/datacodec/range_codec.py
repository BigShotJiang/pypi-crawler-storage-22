"""
Range codec for iterable sequences.

Represents sequences/iterables in binary format, similar to muesli's range_holder.
This is a primitive type that format.py knows how to serialize.
"""

from typing import Any, Iterable, Callable, Optional
from .codecs import Codec
from .fluent import FluentCodecMixin


class RangeCodec(Codec, FluentCodecMixin):
    """
    Codec for iterable sequences.

    This represents an iterable sequence of elements, each encoded with element_codec.
    The format layer treats this as a primitive and iterates to serialize each element.

    Args:
        element_codec: Codec for individual elements in the sequence
    """

    def __init__(self, element_codec: Codec):
        """
        Initialize a range codec.

        Args:
            element_codec: Codec for sequence elements
        """
        self.element_codec = element_codec

    def encode(self, value: Iterable[Any]) -> Iterable[Any]:
        """
        Encode a sequence by encoding each element.

        Returns a generator that yields encoded elements.
        The parent codec (ArrayCodec, VectorCodec, etc.) knows when to stop consuming.

        Args:
            value: Iterable sequence

        Returns:
            Generator of encoded elements
        """
        return (self.element_codec.encode(elem) for elem in value)

    def decode(self, value: Iterable[Any]) -> Iterable[Any]:
        """
        Decode a sequence by passing through each element.

        The elements from the format layer's generator are already fully decoded,
        so we just pass them through (return the iterable as-is).

        Args:
            value: Iterable of decoded elements (generator from format layer)

        Returns:
            The iterable passed through (elements are already decoded)
        """
        return value

    def next_codec(self) -> 'RangeCodec':
        """
        Return a range codec with the element codec's next codec.

        This allows the format layer to recursively handle element serialization.
        """
        return RangeCodec(self.element_codec.next_codec())


def range_codec(element_codec: Codec) -> RangeCodec:
    """
    Create a codec for iterable sequences.

    Args:
        element_codec: Codec for sequence elements

    Returns:
        RangeCodec instance

    Example:
        # Sequence of integers
        int_seq = range_codec(int32_codec)

        # Used internally by vector_codec, array_codec, etc.
    """
    return RangeCodec(element_codec)

