"""
Size codec - platform-specific size type.

This is a primitive codec that adapts to the target platform's pointer size,
similar to std::size_t in C++. The format layer handles the actual encoding/decoding
based on the platform configuration.
"""

from .codec_base import Codec
from typing import Any


class SizeCodec(Codec):
    """
    Platform-specific size codec (equivalent to std::size_t).

    This is a special primitive codec that the format layer handles based on
    the target platform's configuration. It doesn't contain platform information
    itself - that comes from BinaryFormat's platform setting.

    The format layer will serialize as:
    - uint64 (8 bytes) on 64-bit platforms
    - uint32 (4 bytes) on 32-bit platforms

    This ensures proper cross-platform binary compatibility for sizes/lengths.
    """

    def encode(self, value: int) -> int:
        """Size values pass through unchanged."""
        if not isinstance(value, int):
            raise TypeError(f"Expected int, got {type(value)}")
        if value < 0:
            raise ValueError(f"Size cannot be negative: {value}")
        return value

    def decode(self, value: int) -> int:
        """Size values pass through unchanged."""
        return value

    def next_codec(self) -> 'SizeCodec':
        """SizeCodec is a primitive - returns self."""
        return self


# Singleton instance - use this for all size/length prefixes
size_codec = SizeCodec()
