"""
String codec for null-terminated strings.
"""

from .codec_base import Codec


class StringCodec(Codec):
    """
    Codec for null-terminated strings.

    Encodes strings as byte sequences followed by a null terminator.
    """

    def __init__(self, encoding: str = 'utf-8'):
        """
        Initialize a string codec.

        Args:
            encoding: Character encoding to use (default: utf-8)
        """
        self.encoding = encoding

    def encode(self, value: str) -> list:
        """Encode string to list of byte values with null terminator."""
        if not isinstance(value, str):
            raise TypeError(f"Expected str, got {type(value)}")
        return list(value.encode(self.encoding)) + [0]

    def decode(self, value: list) -> str:
        """Decode list of byte values to string, removing null terminator."""
        if not isinstance(value, list):
            raise TypeError(f"Expected list, got {type(value)}")
        if value and value[-1] == 0:
            value = value[:-1]
        return bytes(value).decode(self.encoding)

    def next_codec(self) -> 'Codec':
        """Return a delimited codec for the null-terminated byte sequence."""
        from .delimited_codec import DelimitedCodec
        from .identity_codec import IdentityCodec
        return DelimitedCodec(
            IdentityCodec(int, 'B', 1),
            lambda b: b == 0
        )


# Predefined string codec instances
string_codec = StringCodec()
u16string_codec = StringCodec('utf-16-le')
u32string_codec = StringCodec('utf-32-le')

import sys
if sys.platform == 'win32':
    wstring_codec = u16string_codec
else:
    wstring_codec = u32string_codec

