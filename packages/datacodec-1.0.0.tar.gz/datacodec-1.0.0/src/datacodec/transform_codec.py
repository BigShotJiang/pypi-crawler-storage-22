"""
Transform codec for applying transformations during encode/decode.
"""

from typing import Any, Callable
from .codec_base import Codec


class TransformCodec(Codec):
    """
    Codec that applies transformations during encode/decode.

    Allows arbitrary conversion between the value type and the underlying codec's type.
    """

    def __init__(self, inner_codec: Codec, encode_fn: Callable, decode_fn: Callable):
        """
        Initialize a transform codec.

        Args:
            inner_codec: The underlying codec
            encode_fn: Function to transform value before encoding
            decode_fn: Function to transform value after decoding
        """
        self.inner_codec = inner_codec
        self.encode_fn = encode_fn
        self.decode_fn = decode_fn

    def encode(self, value: Any) -> Any:
        """Transform value, then encode with inner codec."""
        transformed = self.encode_fn(value)
        return self.inner_codec.encode(transformed)

    def decode(self, value: Any) -> Any:
        """Decode with inner codec, then transform."""
        decoded = self.inner_codec.decode(value)
        return self.decode_fn(decoded)

    def next_codec(self) -> Codec:
        """Return the inner codec's next codec."""
        return self.inner_codec.next_codec()

