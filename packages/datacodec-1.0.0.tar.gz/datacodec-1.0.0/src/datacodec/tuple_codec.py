"""
Tuple codec for fixed-size tuples.

Encodes/decodes tuples by applying element codecs to each element.
"""

from typing import Any, Tuple
from .codec_base import Codec


class TupleCodec(Codec):
    """
    Codec for encoding/decoding tuples of values.

    Supports fluent API for transformation and composition.
    """

    def __init__(self, *codecs: Codec):
        """
        Initialize a tuple codec.

        Args:
            *codecs: The codecs for each element of the tuple
        """
        self.codecs = codecs

    def encode(self, value: Tuple) -> Tuple:
        """Encode a tuple by encoding each element."""
        if len(value) != len(self.codecs):
            raise ValueError(f"Expected tuple of length {len(self.codecs)}, got {len(value)}")
        return tuple(codec.encode(v) for codec, v in zip(self.codecs, value))

    def decode(self, value: Tuple) -> Tuple:
        """Decode a tuple by decoding each element."""
        if len(value) != len(self.codecs):
            raise ValueError(f"Expected tuple of length {len(self.codecs)}, got {len(value)}")
        return tuple(codec.decode(v) for codec, v in zip(self.codecs, value))

    def next_codec(self) -> 'TupleCodec':
        """Return a tuple codec with next codecs."""
        return TupleCodec(*(c.next_codec() for c in self.codecs))


def tuple_codec(*codecs: Codec) -> TupleCodec:
    """Create a tuple codec from the given element codecs."""
    return TupleCodec(*codecs)

