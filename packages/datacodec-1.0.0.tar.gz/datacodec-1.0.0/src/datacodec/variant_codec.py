"""
Variant codec for union/sum types.

Encodes/decodes variant (union) types as (index, value) pairs.
"""

from typing import Any, Tuple
from .codec_base import Codec


class VariantCodec(Codec):
    """Codec for encoding/decoding variant (union) types."""

    def __init__(self, *alternative_codecs: Codec):
        """
        Initialize a variant codec.

        Args:
            *alternative_codecs: The codecs for each variant alternative
        """
        self.alternative_codecs = alternative_codecs

    def encode(self, value: Tuple[int, Any]) -> Tuple[int, Any]:
        """
        Encode a variant value.

        Args:
            value: A tuple of (index, value) where index identifies the active alternative
        """
        index, val = value
        if index < 0 or index >= len(self.alternative_codecs):
            raise ValueError(f"Variant index {index} out of range [0, {len(self.alternative_codecs)})")
        return (index, self.alternative_codecs[index].encode(val))

    def decode(self, value: Tuple[int, Any]) -> Tuple[int, Any]:
        """
        Decode a variant value.

        Returns:
            A tuple of (index, value) where index identifies the active alternative
        """
        index, val = value
        if index < 0 or index >= len(self.alternative_codecs):
            raise ValueError(f"Variant index {index} out of range [0, {len(self.alternative_codecs)})")
        return (index, self.alternative_codecs[index].decode(val))

    def next_codec(self) -> 'Codec':
        """Return a variant codec with next codecs for each alternative."""
        return VariantCodec(*[alt.next_codec() for alt in self.alternative_codecs])


def variant_codec(*alternative_codecs: Codec) -> VariantCodec:
    """Create a variant codec for union types."""
    return VariantCodec(*alternative_codecs)

