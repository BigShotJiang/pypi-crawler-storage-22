"""
Varint codec for variable-length integer encoding.
"""

from .codec_base import Codec


class VarintCodec(Codec):
    """
    Codec for variable-length integer encoding (varint).

    Encodes integers using fewer bytes for smaller values.
    Uses continuation bit in each byte.
    """

    def __init__(self, signed: bool = False):
        """
        Initialize a varint codec.

        Args:
            signed: If True, use zigzag encoding for signed integers
        """
        self.signed = signed

    def encode(self, value: int) -> list:
        """Encode integer as list of varint bytes."""
        if not isinstance(value, int):
            raise TypeError(f"Expected int, got {type(value)}")

        if self.signed:
            value = (value << 1) ^ (value >> 63) if value < 0 else (value << 1)
        elif value < 0:
            raise ValueError("Negative value for unsigned varint")

        result = []
        while True:
            byte = value & 0x7F
            value >>= 7
            if value == 0:
                result.append(byte)
                break
            else:
                result.append(byte | 0x80)

        return result

    def decode(self, value: list) -> int:
        """Decode list of varint bytes to integer."""
        if not isinstance(value, list):
            raise TypeError(f"Expected list, got {type(value)}")

        result = 0
        shift = 0

        for byte in value:
            result |= (byte & 0x7F) << shift
            shift += 7
            if (byte & 0x80) == 0:
                break

        if self.signed:
            result = (result >> 1) ^ -(result & 1)

        return result

    def next_codec(self) -> 'Codec':
        """Return a delimited codec for varint byte sequence."""
        from .delimited_codec import DelimitedCodec
        from .identity_codec import IdentityCodec
        return DelimitedCodec(
            IdentityCodec(int, 'B', 1),
            lambda b: (b & 0x80) == 0
        )


# Predefined varint codec instances
unsigned_varint_codec = VarintCodec(signed=False)
signed_varint_codec = VarintCodec(signed=True)

