"""
Vector codec for variable-length sequences.

Encodes/decodes vectors with length prefix to TupleCodec(size_codec, RangeCodec).
"""

from typing import Any, List, Tuple
from .codec_base import Codec


class VectorCodec(Codec):
    """Codec for encoding/decoding variable-length vectors."""

    def __init__(self, element_codec: Codec):
        """
        Initialize a vector codec.

        Args:
            element_codec: The codec for vector elements
        """
        self.element_codec = element_codec

    def encode(self, value: List) -> Tuple[int, Any]:
        """
        Encode a vector as (length, iterable).

        Returns a tuple of (length, iterable) that next_codec (TupleCodec) will handle.
        """
        return (len(value), value)

    def decode(self, value: Tuple[int, Any]) -> List:
        """
        Decode a vector from (length, iterable).

        Consumes exactly length elements from the iterable (generator from RangeCodec).
        """
        length, iterable = value
        # Consume exactly length elements from the generator
        elements = []
        iterator = iter(iterable)
        for _ in range(length):
            try:
                elements.append(next(iterator))
            except StopIteration:
                raise ValueError(f"Expected {length} elements, got {len(elements)}")
        return elements

    def next_codec(self) -> 'Codec':
        """Return a tuple codec of (size_codec, range_codec)."""
        from .range_codec import RangeCodec
        from .tuple_codec import TupleCodec
        from .size_codec import size_codec

        return TupleCodec(
            size_codec,
            RangeCodec(self.element_codec)
        )


def vector_codec(element_codec: Codec) -> VectorCodec:
    """Create a vector codec for variable-length sequences."""
    return VectorCodec(element_codec)
