"""Tests for datacodec library."""

