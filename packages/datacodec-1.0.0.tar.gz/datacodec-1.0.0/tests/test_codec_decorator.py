"""
Tests for codec annotation with dataclass_codec.
"""
import unittest
import io
import sys
from datacodec import *
from dataclasses import dataclass

# Check Python version for Annotated support
if sys.version_info >= (3, 9):
    from typing import Annotated
    HAS_ANNOTATED = True
else:
    HAS_ANNOTATED = False


class TestCodecAnnotation(unittest.TestCase):
    """Test codec annotation functionality."""

    @unittest.skipIf(not HAS_ANNOTATED, "Requires Python 3.9+ for Annotated")
    def test_basic_codec_annotation(self):
        """Test basic codec annotation usage."""
        @dataclass
        class Simple:
            value: Annotated[int, codec(uint8_codec)]

        codec_instance = dataclass_codec(Simple)
        format = BinaryFormat(codec_instance)

        obj = Simple(value=42)
        output = io.BytesIO()
        format.serialize(obj, output)

        # Should be 1 byte for uint8
        self.assertEqual(len(output.getvalue()), 1)
        self.assertEqual(output.getvalue()[0], 42)

        output.seek(0)
        result = format.deserialize(output)
        self.assertEqual(result.value, 42)

    @unittest.skipIf(not HAS_ANNOTATED, "Requires Python 3.9+ for Annotated")
    def test_multiple_codec_annotations(self):
        """Test multiple fields with codec annotations."""
        @dataclass
        class GameEntity:
            name: str
            health: Annotated[int, codec(uint8_codec)]
            damage: Annotated[int, codec(uint16_codec)]

        codec_instance = dataclass_codec(GameEntity)
        format = BinaryFormat(codec_instance)

        entity = GameEntity("Player", health=85, damage=1000)
        output = io.BytesIO()
        format.serialize(entity, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result.name, "Player")
        self.assertEqual(result.health, 85)
        self.assertEqual(result.damage, 1000)

    @unittest.skipIf(not HAS_ANNOTATED, "Requires Python 3.9+ for Annotated")
    def test_mixed_annotated_and_automatic(self):
        """Test mixing codec annotations with automatic inference."""
        @dataclass
        class Mixed:
            auto_int: int
            auto_float: float
            explicit_uint8: Annotated[int, codec(uint8_codec)]
            explicit_float32: Annotated[float, codec(float_codec)]

        codec_instance = dataclass_codec(Mixed)
        format = BinaryFormat(codec_instance)

        obj = Mixed(auto_int=100, auto_float=3.14, explicit_uint8=50, explicit_float32=2.5)
        output = io.BytesIO()
        format.serialize(obj, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result.auto_int, 100)
        self.assertAlmostEqual(result.auto_float, 3.14, places=5)
        self.assertEqual(result.explicit_uint8, 50)
        self.assertAlmostEqual(result.explicit_float32, 2.5, places=5)

    @unittest.skipIf(not HAS_ANNOTATED, "Requires Python 3.9+ for Annotated")
    def test_codec_with_optional(self):
        """Test codec annotation with optional codec."""
        @dataclass
        class WithOptional:
            opt_value: Annotated[int, codec(optional_codec(uint16_codec))]

        codec_instance = dataclass_codec(WithOptional)
        format = BinaryFormat(codec_instance)

        # Test with value
        obj1 = WithOptional(opt_value=500)
        output1 = io.BytesIO()
        format.serialize(obj1, output1)
        output1.seek(0)
        result1 = format.deserialize(output1)
        self.assertEqual(result1.opt_value, 500)

        # Test with None
        obj2 = WithOptional(opt_value=None)
        output2 = io.BytesIO()
        format.serialize(obj2, output2)
        output2.seek(0)
        result2 = format.deserialize(output2)
        self.assertIsNone(result2.opt_value)

    @unittest.skipIf(not HAS_ANNOTATED, "Requires Python 3.9+ for Annotated")
    def test_codec_with_vector(self):
        """Test codec annotation with vector codec."""
        @dataclass
        class WithVector:
            numbers: Annotated[list, codec(vector_codec(int32_codec))]

        codec_instance = dataclass_codec(WithVector)
        format = BinaryFormat(codec_instance)

        obj = WithVector(numbers=[1, 2, 3, 4, 5])
        output = io.BytesIO()
        format.serialize(obj, output)

        output.seek(0)
        result = format.deserialize(output)
        self.assertEqual(result.numbers, [1, 2, 3, 4, 5])

    @unittest.skipIf(not HAS_ANNOTATED, "Requires Python 3.9+ for Annotated")
    def test_codec_size_optimization(self):
        """Test that codec annotation actually uses specified codec for size."""
        @dataclass
        class SizeTest:
            uint8_val: Annotated[int, codec(uint8_codec)]
            uint16_val: Annotated[int, codec(uint16_codec)]
            uint32_val: Annotated[int, codec(uint32_codec)]

        codec_instance = dataclass_codec(SizeTest)
        format = BinaryFormat(codec_instance)

        obj = SizeTest(uint8_val=1, uint16_val=2, uint32_val=3)
        output = io.BytesIO()
        format.serialize(obj, output)

        # uint8 (1) + align_padding (1) + uint16 (2) + uint32 (4) = 8 bytes
        # Alignment is applied before uint16
        self.assertEqual(len(output.getvalue()), 8)

    def test_direct_codec_as_type(self):
        """Test using codec directly as type annotation (most Pythonic)."""
        @dataclass
        class DirectCodec:
            value: type(uint8_codec)  # Use the codec class directly

        # This should work with codec instances too
        @dataclass
        class DirectInstance:
            byte_val: uint8_codec = None  # Note: need default due to dataclass rules
            word_val: uint16_codec = None

        codec_inst = dataclass_codec(DirectInstance)
        format = BinaryFormat(codec_inst)

        obj = DirectInstance(byte_val=42, word_val=1000)
        output = io.BytesIO()
        format.serialize(obj, output)

        # uint8 (1) + align (1) + uint16 (2) = 4 bytes
        self.assertEqual(len(output.getvalue()), 4)

        output.seek(0)
        result = format.deserialize(output)
        self.assertEqual(result.byte_val, 42)
        self.assertEqual(result.word_val, 1000)


if __name__ == '__main__':
    unittest.main()



