"""
Tests for composite codecs (tuple, array, vector).
"""
import unittest
import io
from datacodec import *


class TestTupleCodec(unittest.TestCase):
    """Test tuple codec with various configurations."""

    def test_homogeneous_tuple(self):
        """Test tuple of same type elements."""
        codec = tuple_codec(int32_codec, int32_codec, int32_codec)
        format = BinaryFormat(codec)

        value = (1, 2, 3)
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_heterogeneous_tuple(self):
        """Test tuple of different type elements."""
        codec = tuple_codec(int32_codec, float_codec, bool_codec, string_codec)
        format = BinaryFormat(codec)

        value = (42, 3.14, True, "hello")
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result[0], 42)
        self.assertAlmostEqual(result[1], 3.14, places=5)
        self.assertEqual(result[2], True)
        self.assertEqual(result[3], "hello")

    def test_empty_tuple(self):
        """Test empty tuple."""
        codec = tuple_codec()
        format = BinaryFormat(codec)

        value = ()
        output = io.BytesIO()
        format.serialize(value, output)

        # Empty tuple should produce no bytes
        self.assertEqual(len(output.getvalue()), 0)

        output.seek(0)
        result = format.deserialize(output)
        self.assertEqual(result, ())

    def test_single_element_tuple(self):
        """Test single element tuple."""
        codec = tuple_codec(uint64_codec)
        format = BinaryFormat(codec)

        value = (12345678901234,)
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_nested_tuples(self):
        """Test tuples containing tuples."""
        inner_codec = tuple_codec(int32_codec, int32_codec)
        outer_codec = tuple_codec(inner_codec, bool_codec)
        format = BinaryFormat(outer_codec)

        value = ((10, 20), True)
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_large_tuple(self):
        """Test tuple with many elements."""
        codecs = [int32_codec] * 20
        codec = tuple_codec(*codecs)
        format = BinaryFormat(codec)

        value = tuple(range(20))
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)


class TestArrayCodec(unittest.TestCase):
    """Test fixed-size array codec."""

    def test_basic_array(self):
        """Test basic fixed-size array."""
        codec = array_codec(int32_codec, 5)
        format = BinaryFormat(codec)

        value = [1, 2, 3, 4, 5]
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_array_size_validation(self):
        """Test that array size is validated."""
        codec = array_codec(int32_codec, 3)

        # Correct size
        encoded = codec.encode([1, 2, 3])
        decoded = codec.decode(encoded)
        self.assertEqual(decoded, [1, 2, 3])

        # Wrong size should raise
        with self.assertRaises(ValueError):
            codec.encode([1, 2])

        with self.assertRaises(ValueError):
            codec.encode([1, 2, 3, 4])

    def test_array_of_floats(self):
        """Test array of floating point values."""
        codec = array_codec(double_codec, 4)
        format = BinaryFormat(codec)

        value = [1.1, 2.2, 3.3, 4.4]
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        for i in range(4):
            self.assertAlmostEqual(result[i], value[i], places=10)

    def test_array_of_strings(self):
        """Test array of strings."""
        codec = array_codec(string_codec, 3)
        format = BinaryFormat(codec)

        value = ["one", "two", "three"]
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_single_element_array(self):
        """Test array with single element."""
        codec = array_codec(uint64_codec, 1)
        format = BinaryFormat(codec)

        value = [999999999999]
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_large_array(self):
        """Test large fixed-size array."""
        codec = array_codec(uint8_codec, 1000)
        format = BinaryFormat(codec)

        value = list(range(256)) * 3 + list(range(232))
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)


class TestVectorCodec(unittest.TestCase):
    """Test variable-size vector codec."""

    def test_basic_vector(self):
        """Test basic vector encoding."""
        codec = vector_codec(int32_codec)
        format = BinaryFormat(codec)

        value = [1, 2, 3, 4, 5]
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_empty_vector(self):
        """Test empty vector."""
        codec = vector_codec(int32_codec)
        format = BinaryFormat(codec)

        value = []
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, [])

    def test_single_element_vector(self):
        """Test vector with one element."""
        codec = vector_codec(string_codec)
        format = BinaryFormat(codec)

        value = ["only"]
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_large_vector(self):
        """Test large vector."""
        codec = vector_codec(uint16_codec)
        format = BinaryFormat(codec)

        value = list(range(10000))
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_vector_of_strings(self):
        """Test vector of variable-length strings."""
        codec = vector_codec(string_codec)
        format = BinaryFormat(codec)

        value = ["short", "a bit longer", "x", "medium length string"]
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_vector_of_vectors(self):
        """Test nested vectors."""
        inner_codec = vector_codec(int32_codec)
        outer_codec = vector_codec(inner_codec)
        format = BinaryFormat(outer_codec)

        value = [[1, 2, 3], [], [4, 5], [6]]
        output = io.BytesIO()
        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)


if __name__ == '__main__':
    unittest.main()

