"""
Comprehensive test suite for full coverage of datacodec library.
Tests edge cases, error conditions, and all codec combinations.
"""

import unittest
import io
import struct
from datacodec import *
from dataclasses import dataclass, field


class TestAlignment(unittest.TestCase):
    """Test alignment behavior across platforms."""

    def test_arm32_alignment(self):
        """Test ARM32 alignment (8-byte for int64)."""
        codec = tuple_codec(uint8_codec, int64_codec)
        format_arm32 = BinaryFormat(codec, platform='arm32')

        output = io.BytesIO()
        format_arm32.serialize((1, 100), output)

        # Should have 7 bytes of padding after uint8 before int64
        self.assertEqual(len(output.getvalue()), 1 + 7 + 8)  # uint8 + padding + int64

    def test_x86_64_alignment(self):
        """Test x86-64 alignment."""
        codec = tuple_codec(uint8_codec, int64_codec)
        format_x64 = BinaryFormat(codec, platform='x86-64')

        output = io.BytesIO()
        format_x64.serialize((1, 100), output)

        # x86-64 typically has 8-byte alignment for int64
        data = output.getvalue()
        self.assertGreater(len(data), 9)  # At least uint8 + int64

    def test_cross_platform_compatibility(self):
        """Test data generated on one platform can be read on another."""
        codec = tuple_codec(uint32_codec, float_codec)

        # Serialize with ARM32
        format_arm32 = BinaryFormat(codec, platform='arm32')
        output = io.BytesIO()
        format_arm32.serialize((42, 3.14), output)

        # Deserialize with x86-64 should work (same alignment for these types)
        format_x64 = BinaryFormat(codec, platform='x86-64')
        output.seek(0)
        result = format_x64.deserialize(output)

        self.assertEqual(result[0], 42)
        self.assertAlmostEqual(result[1], 3.14, places=5)


class TestByteOrder(unittest.TestCase):
    """Test byte order (endianness) handling."""

    def test_little_endian(self):
        """Test little-endian byte order."""
        codec = uint32_codec
        format_le = BinaryFormat(codec, byte_order='<')

        output = io.BytesIO()
        format_le.serialize(0x12345678, output)

        # Little endian: least significant byte first
        self.assertEqual(output.getvalue(), b'\x78\x56\x34\x12')

    def test_big_endian(self):
        """Test big-endian byte order."""
        codec = uint32_codec
        format_be = BinaryFormat(codec, byte_order='>')

        output = io.BytesIO()
        format_be.serialize(0x12345678, output)

        # Big endian: most significant byte first
        self.assertEqual(output.getvalue(), b'\x12\x34\x56\x78')

    def test_byte_order_round_trip(self):
        """Test round-trip with different byte orders."""
        value = 0xDEADBEEF

        for byte_order in ['<', '>', '=', '@']:
            codec = uint32_codec
            format = BinaryFormat(codec, byte_order=byte_order)

            output = io.BytesIO()
            format.serialize(value, output)
            output.seek(0)
            result = format.deserialize(output)

            self.assertEqual(result, value, f"Failed for byte order {byte_order}")


class TestErrorConditions(unittest.TestCase):
    """Test error handling and edge cases."""

    def test_constrain_validation_failure(self):
        """Test that constrain raises ValueError on invalid value."""
        codec = int32_codec.constrain(lambda x: 0 <= x <= 100)

        # Valid value should work
        encoded = codec.encode(50)
        self.assertIsNotNone(encoded)

        # Invalid value should raise
        with self.assertRaises(ValueError):
            codec.encode(101)

        with self.assertRaises(ValueError):
            codec.encode(-1)

    def test_array_size_mismatch(self):
        """Test that array codec validates size."""
        codec = array_codec(int32_codec, 3)

        # Correct size should work
        encoded = codec.encode([1, 2, 3])
        self.assertIsNotNone(encoded)

        # Wrong size should raise
        with self.assertRaises(ValueError):
            codec.encode([1, 2])

        with self.assertRaises(ValueError):
            codec.encode([1, 2, 3, 4])

    def test_variant_index_out_of_range(self):
        """Test that variant codec validates index."""
        codec = variant_codec(int32_codec, float_codec)

        # Valid indices
        encoded = codec.encode((0, 42))
        self.assertIsNotNone(encoded)

        encoded = codec.encode((1, 3.14))
        self.assertIsNotNone(encoded)

        # Invalid index should raise
        with self.assertRaises(ValueError):
            codec.encode((2, "invalid"))

        with self.assertRaises(ValueError):
            codec.encode((-1, 42))

    def test_truncated_data(self):
        """Test deserialization with truncated data raises exception."""
        codec = tuple_codec(int32_codec, int32_codec, int32_codec)
        format = BinaryFormat(codec)

        # Serialize full data
        output = io.BytesIO()
        format.serialize((1, 2, 3), output)

        # Try to deserialize truncated data - should raise EOFError
        truncated = io.BytesIO(output.getvalue()[:8])  # Only 2 ints worth
        with self.assertRaises(EOFError):
            format.deserialize(truncated)

    def test_constant_codec_validation(self):
        """Test constant codec validates the constant value."""
        codec = constant_codec(uint16_codec, 0xCAFE)

        # Correct constant should work
        encoded = codec.encode(0xCAFE)
        self.assertEqual(encoded, 0xCAFE)  # Constant encodes the value

        decoded = codec.decode(0xCAFE)
        self.assertEqual(decoded, 0xCAFE)

        # Wrong value should raise
        with self.assertRaises(ValueError):
            codec.encode(0xBEEF)


class TestTransformCodec(unittest.TestCase):
    """Test TransformCodec transformations."""

    def test_bidirectional_transform(self):
        """Test encode and decode transformations."""
        # Transform that doubles on encode, halves on decode
        codec = int32_codec.transform(
            lambda x: x * 2,
            lambda x: x // 2
        )

        value = 21
        format = BinaryFormat(codec)
        output = io.BytesIO()

        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)

    def test_type_conversion_transform(self):
        """Test transform for type conversion."""
        # Store bool as int
        codec = int32_codec.transform(
            lambda b: 1 if b else 0,
            lambda i: bool(i)
        )

        format = BinaryFormat(codec)

        for value in [True, False]:
            output = io.BytesIO()
            format.serialize(value, output)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, value)

    def test_nested_transforms(self):
        """Test chaining multiple transforms."""
        codec = int32_codec \
            .transform(lambda x: x + 10, lambda x: x - 10) \
            .transform(lambda x: x * 2, lambda x: x // 2)

        value = 5
        format = BinaryFormat(codec)
        output = io.BytesIO()

        format.serialize(value, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, value)


class TestOptionalCodec(unittest.TestCase):
    """Test optional codec with various inner codecs."""

    def test_optional_string(self):
        """Test optional string codec."""
        codec = string_codec.optional()
        format = BinaryFormat(codec)

        # Test with value
        output = io.BytesIO()
        format.serialize("hello", output)
        output.seek(0)
        result = format.deserialize(output)
        self.assertEqual(result, "hello")

        # Test with None
        output = io.BytesIO()
        format.serialize(None, output)
        output.seek(0)
        result = format.deserialize(output)
        self.assertIsNone(result)

    def test_optional_composite(self):
        """Test optional with composite codec."""
        codec = tuple_codec(int32_codec, float_codec).optional()
        format = BinaryFormat(codec)

        # With value
        output = io.BytesIO()
        format.serialize((42, 3.14), output)
        output.seek(0)
        result = format.deserialize(output)
        self.assertEqual(result[0], 42)
        self.assertAlmostEqual(result[1], 3.14, places=5)

        # Without value
        output = io.BytesIO()
        format.serialize(None, output)
        output.seek(0)
        result = format.deserialize(output)
        self.assertIsNone(result)


class TestVarintCodec(unittest.TestCase):
    """Test varint codec with various values."""

    def test_unsigned_varint_sizes(self):
        """Test that unsigned varint uses minimal bytes."""
        codec = unsigned_varint_codec

        # 1 byte for values < 128
        self.assertEqual(len(codec.encode(0)), 1)
        self.assertEqual(len(codec.encode(127)), 1)

        # 2 bytes for values >= 128
        self.assertEqual(len(codec.encode(128)), 2)
        self.assertEqual(len(codec.encode(16383)), 2)

        # 3 bytes for larger values
        self.assertEqual(len(codec.encode(16384)), 3)

    def test_signed_varint_zigzag(self):
        """Test that signed varint uses zigzag encoding."""
        codec = signed_varint_codec

        # Small positive and negative should both use 1 byte
        self.assertEqual(len(codec.encode(0)), 1)
        self.assertEqual(len(codec.encode(1)), 1)
        self.assertEqual(len(codec.encode(-1)), 1)
        self.assertEqual(len(codec.encode(63)), 1)
        self.assertEqual(len(codec.encode(-64)), 1)

    def test_varint_large_values(self):
        """Test varint with large values."""
        test_values = [
            0,
            127,
            128,
            16383,
            16384,
            2097151,
            2097152,
            268435455,
            268435456,
        ]

        for value in test_values:
            # Unsigned
            encoded = unsigned_varint_codec.encode(value)
            decoded = unsigned_varint_codec.decode(encoded)
            self.assertEqual(decoded, value)

            # Signed
            for sign in [1, -1]:
                signed_value = value * sign
                encoded = signed_varint_codec.encode(signed_value)
                decoded = signed_varint_codec.decode(encoded)
                self.assertEqual(decoded, signed_value)


class TestApplyCodec(unittest.TestCase):
    """Test apply codec with custom types."""

    def test_apply_to_dataclass(self):
        """Test applying codec to dataclass."""
        @dataclass
        class Point:
            x: int
            y: int

        codec = tuple_codec(int32_codec, int32_codec).apply(Point)
        format = BinaryFormat(codec)

        point = Point(10, 20)
        output = io.BytesIO()
        format.serialize(point, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, Point)
        self.assertEqual(result.x, 10)
        self.assertEqual(result.y, 20)

    def test_apply_to_named_tuple(self):
        """Test applying codec to namedtuple."""
        from collections import namedtuple
        Vec2 = namedtuple('Vec2', ['x', 'y'])

        codec = tuple_codec(float_codec, float_codec).apply(Vec2)
        format = BinaryFormat(codec)

        vec = Vec2(1.5, 2.5)
        output = io.BytesIO()
        format.serialize(vec, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, Vec2)
        self.assertAlmostEqual(result.x, 1.5, places=5)
        self.assertAlmostEqual(result.y, 2.5, places=5)


class TestDefaultCodec(unittest.TestCase):
    """Test default codec."""

    def test_default_value(self):
        """Test that None becomes default value."""
        codec = int32_codec.default(999)

        # None should become 999
        encoded_none = codec.encode(None)
        encoded_999 = codec.encode(999)
        self.assertEqual(encoded_none, encoded_999)

        # Other values pass through
        encoded_42 = codec.encode(42)
        self.assertNotEqual(encoded_42, encoded_999)


class TestPairCodec(unittest.TestCase):
    """Test pair codec."""

    def test_heterogeneous_pairs(self):
        """Test pairs with different types."""
        test_pairs = [
            (pair_codec(string_codec, int32_codec), ("key", 123)),
            (pair_codec(float_codec, bool_codec), (3.14, True)),
            (pair_codec(uint64_codec, string_codec), (999, "value")),
        ]

        for codec, value in test_pairs:
            format = BinaryFormat(codec)
            output = io.BytesIO()

            format.serialize(value, output)
            output.seek(0)
            result = format.deserialize(output)

            if isinstance(value[0], float) or isinstance(value[1], float):
                # Compare floats with tolerance
                if isinstance(value[0], float):
                    self.assertAlmostEqual(result[0], value[0], places=5)
                else:
                    self.assertEqual(result[0], value[0])
                if isinstance(value[1], float):
                    self.assertAlmostEqual(result[1], value[1], places=5)
                else:
                    self.assertEqual(result[1], value[1])
            else:
                self.assertEqual(result, value)


class TestComplexNesting(unittest.TestCase):
    """Test complex nested codec structures."""

    def test_vector_of_tuples(self):
        """Test vector containing tuple elements."""
        codec = vector_codec(tuple_codec(int32_codec, string_codec))
        format = BinaryFormat(codec)

        data = [(1, "one"), (2, "two"), (3, "three")]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(len(result), 3)
        self.assertEqual(result, data)

    def test_optional_vector(self):
        """Test optional vector."""
        codec = vector_codec(int32_codec).optional()
        format = BinaryFormat(codec)

        # With vector
        output = io.BytesIO()
        format.serialize([1, 2, 3], output)
        output.seek(0)
        result = format.deserialize(output)
        self.assertEqual(result, [1, 2, 3])

        # With None
        output = io.BytesIO()
        format.serialize(None, output)
        output.seek(0)
        result = format.deserialize(output)
        self.assertIsNone(result)

    def test_triple_nested(self):
        """Test triple-nested structures."""
        # Vector of optional pairs
        codec = vector_codec(
            optional_codec(
                pair_codec(string_codec, int32_codec)
            )
        )
        format = BinaryFormat(codec)

        data = [("a", 1), None, ("b", 2), ("c", 3), None]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(len(result), 5)
        self.assertEqual(result[0], ("a", 1))
        self.assertIsNone(result[1])
        self.assertEqual(result[2], ("b", 2))
        self.assertEqual(result[3], ("c", 3))
        self.assertIsNone(result[4])


class TestDataclassCodecAdvanced(unittest.TestCase):
    """Test advanced dataclass_codec features."""

    def test_nested_dataclasses(self):
        """Test dataclass containing another dataclass."""
        @dataclass
        class Address:
            street: str
            city: str

        @dataclass
        class Person:
            name: str
            age: int

        # Manual codec for nested dataclasses
        address_codec = dataclass_codec(Address)
        person_codec = dataclass_codec(Person)

        address = Address("123 Main St", "Boston")
        person = Person("Alice", 30)

        # Test address
        format = BinaryFormat(address_codec)
        output = io.BytesIO()
        format.serialize(address, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, Address)
        self.assertEqual(result.street, "123 Main St")
        self.assertEqual(result.city, "Boston")

    def test_explicit_field_codec_override(self):
        """Test overriding inferred codec with explicit one."""
        @dataclass
        class Data:
            small_int: int  # Would normally be varint
            large_int: int  # Would normally be varint

        # Override small_int to use uint8
        codec = dataclass_codec(Data, small_int=uint8_codec)
        format = BinaryFormat(codec)

        data = Data(42, 1000000)
        output = io.BytesIO()
        format.serialize(data, output)

        # small_int should use 1 byte, large_int uses varint
        bytes_data = output.getvalue()
        # First byte is small_int (uint8), rest is large_int (varint)
        self.assertEqual(bytes_data[0], 42)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result.small_int, 42)
        self.assertEqual(result.large_int, 1000000)


class TestDictCodec(unittest.TestCase):
    """Test dict_codec comprehensively."""

    def test_empty_dict(self):
        """Test empty dictionary."""
        codec = dict_codec(string_codec, int32_codec)
        format = BinaryFormat(codec)

        output = io.BytesIO()
        format.serialize({}, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, {})

    def test_large_dict(self):
        """Test dictionary with many entries."""
        codec = dict_codec(string_codec, int32_codec)
        format = BinaryFormat(codec)

        data = {f"key{i}": i * 10 for i in range(100)}
        output = io.BytesIO()
        format.serialize(data, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, data)

    def test_dict_value_types(self):
        """Test dict with various value types."""
        # Dict with float values
        codec = dict_codec(string_codec, float_codec)
        format = BinaryFormat(codec)

        data = {"pi": 3.14159, "e": 2.71828, "phi": 1.61803}
        output = io.BytesIO()
        format.serialize(data, output)
        output.seek(0)
        result = format.deserialize(output)

        for key in data:
            self.assertAlmostEqual(result[key], data[key], places=5)


if __name__ == '__main__':
    unittest.main()


