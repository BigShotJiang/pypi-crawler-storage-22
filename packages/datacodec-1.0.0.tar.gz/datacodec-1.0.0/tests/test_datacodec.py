"""
Comprehensive tests for datacodec core functionality.
"""

import unittest
import io
from datacodec import *
from dataclasses import dataclass


class TestPrimitiveCodecs(unittest.TestCase):
    """Test all primitive codec types."""

    def test_int_codecs(self):
        """Test signed integer codecs."""
        codecs_and_values = [
            (int8_codec, -128, 127),
            (int16_codec, -32768, 32767),
            (int32_codec, -2147483648, 2147483647),
            (int64_codec, -9223372036854775808, 9223372036854775807),
        ]

        for codec, min_val, max_val in codecs_and_values:
            # Test min
            self.assertEqual(codec.decode(codec.encode(min_val)), min_val)
            # Test max
            self.assertEqual(codec.decode(codec.encode(max_val)), max_val)
            # Test zero
            self.assertEqual(codec.decode(codec.encode(0)), 0)

    def test_uint_codecs(self):
        """Test unsigned integer codecs."""
        codecs_and_max = [
            (uint8_codec, 255),
            (uint16_codec, 65535),
            (uint32_codec, 4294967295),
            (uint64_codec, 18446744073709551615),
        ]

        for codec, max_val in codecs_and_max:
            # Test zero
            self.assertEqual(codec.decode(codec.encode(0)), 0)
            # Test max
            self.assertEqual(codec.decode(codec.encode(max_val)), max_val)

    def test_float_codecs(self):
        """Test floating point codecs."""
        test_values = [0.0, 1.5, -2.5, 3.14159, 1e10, -1e-10]

        for value in test_values:
            # Float codec
            result = float_codec.decode(float_codec.encode(value))
            self.assertAlmostEqual(result, value, places=6)

            # Double codec
            result = double_codec.decode(double_codec.encode(value))
            self.assertAlmostEqual(result, value, places=10)

    def test_bool_codec(self):
        """Test boolean codec."""
        self.assertEqual(bool_codec.decode(bool_codec.encode(True)), True)
        self.assertEqual(bool_codec.decode(bool_codec.encode(False)), False)


class TestCompositeCodecs(unittest.TestCase):
    """Test composite codec types."""

    def test_tuple_codec(self):
        """Test tuple codec."""
        codec = tuple_codec(int32_codec, float_codec, bool_codec)
        value = (42, 3.14, True)

        encoded = codec.encode(value)
        decoded = codec.decode(encoded)

        self.assertEqual(decoded[0], 42)
        self.assertAlmostEqual(decoded[1], 3.14, places=3)
        self.assertEqual(decoded[2], True)

    def test_array_codec(self):
        """Test fixed-size array codec."""
        codec = array_codec(int32_codec, 3)
        value = [10, 20, 30]

        encoded = codec.encode(value)
        decoded = codec.decode(encoded)

        self.assertEqual(decoded, [10, 20, 30])

    def test_vector_codec(self):
        """Test variable-length vector codec."""
        codec = vector_codec(uint32_codec)
        value = [1, 2, 3, 4, 5]

        encoded = codec.encode(value)
        decoded = codec.decode(encoded)

        self.assertEqual(decoded, value)

    def test_optional_codec(self):
        """Test optional codec."""
        codec = optional_codec(int32_codec)

        # With value
        encoded = codec.encode(42)
        decoded = codec.decode(encoded)
        self.assertEqual(decoded, 42)

        # Without value
        encoded = codec.encode(None)
        decoded = codec.decode(encoded)
        self.assertIsNone(decoded)

    def test_variant_codec(self):
        """Test variant codec."""
        codec = variant_codec(int32_codec, float_codec, bool_codec)

        # Test each alternative (variant expects (index, value) tuples)
        test_cases = [
            (0, 42),      # int32
            (1, 3.14),    # float
            (2, True),    # bool
        ]

        for index, value in test_cases:
            encoded = codec.encode((index, value))
            decoded_index, decoded_value = codec.decode(encoded)

            self.assertEqual(decoded_index, index)
            if isinstance(value, bool):
                self.assertEqual(decoded_value, value)
            elif isinstance(value, float):
                self.assertAlmostEqual(decoded_value, value, places=3)
            else:
                self.assertEqual(decoded_value, value)


class TestStringCodec(unittest.TestCase):
    """Test string codec."""

    def test_basic_strings(self):
        """Test basic string encoding/decoding."""
        test_strings = ["Hello", "World", "Test123", ""]

        for s in test_strings:
            encoded = string_codec.encode(s)
            decoded = string_codec.decode(encoded)
            self.assertEqual(decoded, s)

    def test_unicode_strings(self):
        """Test Unicode string handling."""
        test_strings = ["Hello 世界", "Émojis 🎉🎊", "Кириллица"]

        for s in test_strings:
            encoded = string_codec.encode(s)
            decoded = string_codec.decode(encoded)
            self.assertEqual(decoded, s)


class TestVarintCodec(unittest.TestCase):
    """Test variable-length integer codec."""

    def test_unsigned_varint(self):
        """Test unsigned varint encoding."""
        test_values = [0, 1, 127, 128, 255, 256, 65535, 16777215]

        for value in test_values:
            encoded = unsigned_varint_codec.encode(value)
            decoded = unsigned_varint_codec.decode(encoded)
            self.assertEqual(decoded, value)
            # Smaller values should use fewer bytes
            if value < 128:
                self.assertEqual(len(encoded), 1)

    def test_signed_varint(self):
        """Test signed varint with zigzag encoding."""
        test_values = [-1000, -1, 0, 1, 1000]

        for value in test_values:
            encoded = signed_varint_codec.encode(value)
            decoded = signed_varint_codec.decode(encoded)
            self.assertEqual(decoded, value)


class TestPairCodec(unittest.TestCase):
    """Test pair codec."""

    def test_pair(self):
        """Test pair encoding/decoding."""
        codec = pair_codec(string_codec, int32_codec)
        value = ("key", 123)

        encoded = codec.encode(value)
        decoded = codec.decode(encoded)

        self.assertEqual(decoded, value)


class TestConstantCodec(unittest.TestCase):
    """Test constant codec."""

    def test_constant(self):
        """Test constant value validation."""
        codec = constant_codec(uint16_codec, 0xCAFE)

        # Valid encode - should encode the constant value
        result = codec.encode(0xCAFE)
        self.assertEqual(result, 0xCAFE)

        # Decode validates and returns constant
        self.assertEqual(codec.decode(0xCAFE), 0xCAFE)

        # Invalid encode raises
        with self.assertRaises(ValueError):
            codec.encode(0xBEEF)


class TestFluentAPI(unittest.TestCase):
    """Test fluent API methods."""

    def test_transform(self):
        """Test transform method."""
        codec = int32_codec.transform(
            lambda x: x * 2,
            lambda x: x // 2
        )

        self.assertEqual(codec.decode(codec.encode(21)), 21)

    def test_constrain(self):
        """Test constrain method."""
        codec = int32_codec.constrain(lambda x: x > 0)

        # Valid value
        self.assertEqual(codec.decode(codec.encode(42)), 42)

        # Invalid value raises
        with self.assertRaises(ValueError):
            codec.encode(-1)

    def test_optional_fluent(self):
        """Test optional fluent method."""
        codec = int32_codec.optional()

        self.assertEqual(codec.decode(codec.encode(42)), 42)
        self.assertIsNone(codec.decode(codec.encode(None)))

    def test_default(self):
        """Test default method."""
        codec = int32_codec.default(999)

        # None becomes default
        self.assertEqual(codec.encode(None), codec.encode(999))

    def test_apply(self):
        """Test apply method."""
        @dataclass
        class Point:
            x: int
            y: int

        codec = tuple_codec(int32_codec, int32_codec).apply(Point)

        point = Point(10, 20)
        encoded = codec.encode(point)
        decoded = codec.decode(encoded)

        self.assertIsInstance(decoded, Point)
        self.assertEqual(decoded.x, 10)
        self.assertEqual(decoded.y, 20)

    def test_method_chaining(self):
        """Test chaining multiple fluent methods."""
        codec = int32_codec \
            .constrain(lambda x: x >= 0) \
            .transform(lambda x: x + 1, lambda x: x - 1) \
            .optional()

        self.assertEqual(codec.decode(codec.encode(10)), 10)
        self.assertIsNone(codec.decode(codec.encode(None)))


class TestBinaryFormat(unittest.TestCase):
    """Test BinaryFormat serialization."""

    def test_serialize_deserialize(self):
        """Test basic serialize/deserialize."""
        codec = tuple_codec(int32_codec, float_codec)
        format = BinaryFormat(codec)

        output = io.BytesIO()
        value = (42, 3.14)

        format.serialize(value, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result[0], 42)
        self.assertAlmostEqual(result[1], 3.14, places=3)

    def test_multiple_values(self):
        """Test serializing multiple values."""
        codec = uint32_codec
        format = BinaryFormat(codec)

        values = [1, 2, 3, 4, 5]
        output = io.BytesIO()

        for v in values:
            format.serialize(v, output)

        output.seek(0)
        results = []
        for _ in range(len(values)):
            results.append(format.deserialize(output))

        self.assertEqual(results, values)


class TestPlatformConfig(unittest.TestCase):
    """Test cross-platform configuration."""

    def test_platform_configs(self):
        """Test predefined platform configs."""
        self.assertEqual(ARM32_CONFIG.pointer_size, 4)
        self.assertEqual(ARM64_CONFIG.pointer_size, 8)
        self.assertEqual(X86_64_CONFIG.pointer_size, 8)

    def test_platform_selection(self):
        """Test platform parameter."""
        codec = uint32_codec

        format_arm32 = BinaryFormat(codec, platform='arm32')
        format_x64 = BinaryFormat(codec, platform='x86-64')

        # Both should serialize same for simple uint32
        output1 = io.BytesIO()
        output2 = io.BytesIO()

        format_arm32.serialize(12345, output1)
        format_x64.serialize(12345, output2)

        self.assertEqual(len(output1.getvalue()), 4)
        self.assertEqual(len(output2.getvalue()), 4)


class TestDictCodec(unittest.TestCase):
    """Test dict codec."""

    def test_dict_basic(self):
        """Test basic dict encoding/decoding."""
        codec = dict_codec(string_codec, int32_codec)
        data = {"a": 1, "b": 2, "c": 3}

        format = BinaryFormat(codec)
        output = io.BytesIO()

        format.serialize(data, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, data)

    def test_empty_dict(self):
        """Test empty dict."""
        codec = dict_codec(string_codec, int32_codec)
        data = {}

        format = BinaryFormat(codec)
        output = io.BytesIO()

        format.serialize(data, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, data)


class TestDataclassCodec(unittest.TestCase):
    """Test automatic dataclass codec generation."""

    def test_simple_dataclass(self):
        """Test codec generation for simple dataclass."""
        @dataclass
        class Person:
            name: str
            age: int  # Maps to signed_varint_codec
            height: float  # Maps to double_codec

        codec = dataclass_codec(Person)
        person = Person("Alice", 30, 165.5)

        format = BinaryFormat(codec)
        output = io.BytesIO()

        format.serialize(person, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, Person)
        self.assertEqual(result.name, "Alice")
        self.assertEqual(result.age, 30)
        self.assertAlmostEqual(result.height, 165.5, places=5)

    def test_explicit_field_codecs(self):
        """Test dataclass with explicit field codecs."""
        @dataclass
        class Config:
            id: int  # Default would be varint
            value: int

        # Use uint8 for id instead of default varint
        codec = dataclass_codec(Config, id=uint8_codec)
        config = Config(42, 1000)

        format = BinaryFormat(codec)
        output = io.BytesIO()

        format.serialize(config, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result.id, 42)
        self.assertEqual(result.value, 1000)

    def test_negative_int_with_varint(self):
        """Test that negative ints work with varint default."""
        @dataclass
        class Data:
            value: int

        codec = dataclass_codec(Data)

        # Test negative value (uses signed varint)
        data = Data(-100)

        format = BinaryFormat(codec)
        output = io.BytesIO()

        format.serialize(data, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result.value, -100)


class TestNumpyCodecs(unittest.TestCase):
    """Test NumPy codec support (if NumPy is available)."""

    def test_numpy_available(self):
        """Check if NumPy support is detected."""
        try:
            from datacodec import HAS_NUMPY
            # Just verify the flag exists
            self.assertIsInstance(HAS_NUMPY, bool)
        except ImportError:
            self.skipTest("NumPy support not available")

    def test_numpy_array_codec(self):
        """Test NumPy array codec."""
        try:
            import numpy as np
            from datacodec import numpy_array_codec
        except ImportError:
            self.skipTest("NumPy not installed")

        # Dynamic size array
        codec = numpy_array_codec(np.float32)
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)

        format = BinaryFormat(codec)
        output = io.BytesIO()

        format.serialize(arr, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, np.ndarray)
        self.assertEqual(result.dtype, np.float32)
        self.assertTrue(np.allclose(result, arr))

    def test_numpy_fixed_array(self):
        """Test fixed-size NumPy array."""
        try:
            import numpy as np
            from datacodec import numpy_array_codec
        except ImportError:
            self.skipTest("NumPy not installed")

        # Fixed size 3D vector
        codec = numpy_array_codec(np.float64, shape=(3,))
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float64)

        format = BinaryFormat(codec)
        output = io.BytesIO()

        format.serialize(arr, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, np.ndarray)
        self.assertEqual(result.shape, (3,))
        self.assertTrue(np.allclose(result, arr))

    def test_numpy_dataclass(self):
        """Test dataclass with NumPy types."""
        try:
            import numpy as np
        except ImportError:
            self.skipTest("NumPy not installed")

        @dataclass
        class Vector:
            x: np.float32
            y: np.float32
            z: np.float32

        codec = dataclass_codec(Vector)
        vec = Vector(np.float32(1.0), np.float32(2.0), np.float32(3.0))

        format = BinaryFormat(codec)
        output = io.BytesIO()

        format.serialize(vec, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, Vector)
        self.assertTrue(np.isclose(result.x, 1.0))
        self.assertTrue(np.isclose(result.y, 2.0))
        self.assertTrue(np.isclose(result.z, 3.0))


class TestEdgeCases(unittest.TestCase):
    """Test edge cases and error handling."""

    def test_empty_vector(self):
        """Test empty vector."""
        codec = vector_codec(int32_codec)
        value = []

        encoded = codec.encode(value)
        decoded = codec.decode(encoded)

        self.assertEqual(decoded, [])

    def test_nested_tuples(self):
        """Test nested tuple codecs."""
        inner_codec = tuple_codec(int32_codec, float_codec)
        outer_codec = tuple_codec(inner_codec, bool_codec)

        value = ((42, 3.14), True)
        encoded = outer_codec.encode(value)
        decoded = outer_codec.decode(encoded)

        self.assertEqual(decoded[0][0], 42)
        self.assertAlmostEqual(decoded[0][1], 3.14, places=3)
        self.assertEqual(decoded[1], True)

    def test_serialization_failure(self):
        """Test serialize raises exception on error."""
        codec = int32_codec.constrain(lambda x: x > 0)
        format = BinaryFormat(codec)

        output = io.BytesIO()
        with self.assertRaises(ValueError):
            format.serialize(-1, output)

    def test_byte_order_configuration(self):
        """Test byte order parameter."""
        codec = uint32_codec

        format_le = BinaryFormat(codec, byte_order='<')
        format_be = BinaryFormat(codec, byte_order='>')

        value = 0x12345678

        output_le = io.BytesIO()
        output_be = io.BytesIO()

        format_le.serialize(value, output_le)
        format_be.serialize(value, output_be)

        # Different byte orders produce different bytes
        self.assertNotEqual(output_le.getvalue(), output_be.getvalue())

        # But deserialize correctly
        output_le.seek(0)
        output_be.seek(0)
        self.assertEqual(format_le.deserialize(output_le), value)
        self.assertEqual(format_be.deserialize(output_be), value)


if __name__ == '__main__':
    unittest.main()


