"""
Test delimited_codec functionality.
"""
import unittest
from datacodec import *


class TestDelimitedCodec(unittest.TestCase):
    """Test delimited codec."""

    def test_null_terminated_bytes(self):
        """Test null-terminated byte sequence."""
        codec = delimited_codec(uint8_codec, lambda c: c == 0)

        # Encode sequence with null terminator
        data = [ord('h'), ord('e'), ord('l'), ord('l'), ord('o'), 0]
        encoded = codec.encode(data)

        self.assertEqual(len(encoded), 6)

        # Decode includes delimiter
        decoded = codec.decode(encoded)
        self.assertEqual(decoded, [ord('h'), ord('e'), ord('l'), ord('l'), ord('o'), 0])

    def test_custom_delimiter(self):
        """Test custom delimiter."""
        # Comma-delimited integers
        codec = delimited_codec(int32_codec, lambda x: x == -1)

        data = [1, 2, 3, -1]
        encoded = codec.encode(data)
        decoded = codec.decode(encoded)

        # Delimiter is included in decoded result
        self.assertEqual(decoded, [1, 2, 3, -1])

    def test_early_delimiter(self):
        """Test delimiter appears early."""
        codec = delimited_codec(uint8_codec, lambda c: c == 0)

        # Delimiter at position 2
        data = [1, 0, 99, 99]
        encoded = codec.encode(data)

        # Should only encode up to and including delimiter
        self.assertEqual(encoded, [1, 0, 99, 99])

        decoded = codec.decode(encoded)
        # Delimiter is included
        self.assertEqual(decoded, [1, 0])


if __name__ == '__main__':
    unittest.main()

