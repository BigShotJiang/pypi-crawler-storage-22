"""
Tests for member_codec and build_codec for manual codec construction.
"""
import unittest
import io
from datacodec import *


# Test classes defined at module level for proper deserialization

class SimplePoint:
    def __init__(self, x, y):
        self.x = x
        self.y = y


class SimplePerson:
    def __init__(self, first_name, last_name, age):
        self._first = first_name
        self._last = last_name
        self._age = age

    def get_first_name(self):
        return self._first

    def get_last_name(self):
        return self._last

    def get_age(self):
        return self._age


class Temperature:
    def __init__(self, celsius):
        self._celsius = celsius

    @property
    def celsius(self):
        return self._celsius

    @property
    def fahrenheit(self):
        return self._celsius * 9/5 + 32


class Vector3D:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    @classmethod
    def from_tuple(cls, values):
        return cls(values[0], values[1], values[2])


class SimpleAccount:
    def __init__(self, id, balance, name):
        self.id = id
        self._balance = balance
        self._name = name

    def get_balance(self):
        return self._balance

    def get_name(self):
        return self._name


class TestMemberCodec(unittest.TestCase):
    """Test member codec for getter-based extraction."""

    def test_simple_getter(self):
        """Test member codec with simple attribute getter."""
        name_codec = member_codec(string_codec, lambda p: p._first)

        person = SimplePerson("Alice", "Smith", 30)
        encoded = name_codec.encode(person)

        # Encoded should be just the name
        decoded_name = string_codec.decode(encoded)
        self.assertEqual(decoded_name, "Alice")

    def test_method_getter(self):
        """Test member codec with method getter."""
        balance_codec = member_codec(int32_codec, lambda a: a.get_balance())

        account = SimpleAccount(12345, 1000, "Savings")
        encoded = balance_codec.encode(account)
        decoded = int32_codec.decode(encoded)

        self.assertEqual(decoded, 1000)


class TestBuildCodec(unittest.TestCase):
    """Test manual codec construction with member_codec."""

    def test_simple_class(self):
        """Test codec with tuple_codec and .member() fluent API."""
        point_codec = tuple_codec(
            int32_codec.member(lambda p: p.x),
            int32_codec.member(lambda p: p.y),
        ).apply(SimplePoint)

        format = BinaryFormat(point_codec)
        point = SimplePoint(10, 20)

        output = io.BytesIO()
        format.serialize(point, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, SimplePoint)
        self.assertEqual(result.x, 10)
        self.assertEqual(result.y, 20)

    def test_class_with_methods(self):
        """Test codec with getter methods."""
        person_codec = tuple_codec(
            string_codec.member(lambda p: p.get_first_name()),
            string_codec.member(lambda p: p.get_last_name()),
            uint8_codec.member(lambda p: p.get_age()),
        ).apply(SimplePerson)

        format = BinaryFormat(person_codec)
        person = SimplePerson("John", "Doe", 42)

        output = io.BytesIO()
        format.serialize(person, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, SimplePerson)
        self.assertEqual(result.get_first_name(), "John")
        self.assertEqual(result.get_last_name(), "Doe")
        self.assertEqual(result.get_age(), 42)


class TestStringBasedMemberLookup(unittest.TestCase):
    """Test string-based member lookup using .member('field_name')."""

    def test_string_field_lookup(self):
        """Test .member() with string field names."""
        point_codec = tuple_codec(
            int32_codec.member('x'),
            int32_codec.member('y'),
        ).apply(SimplePoint)

        format = BinaryFormat(point_codec)
        point = SimplePoint(100, 200)

        output = io.BytesIO()
        format.serialize(point, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, SimplePoint)
        self.assertEqual(result.x, 100)
        self.assertEqual(result.y, 200)

    def test_string_method_lookup(self):
        """Test .member() with string method names (properties)."""
        # Using properties (which are methods)
        temp_codec = float_codec.member('celsius')

        temp = Temperature(25.0)
        encoded = temp_codec.encode(temp)
        decoded = float_codec.decode(encoded)

        self.assertAlmostEqual(decoded, 25.0, places=5)

    def test_mixed_string_and_lambda(self):
        """Test mixing string-based and lambda-based member extraction."""
        account_codec = tuple_codec(
            uint32_codec.member('id'),  # String-based field lookup
            int32_codec.member(lambda a: a.get_balance()),  # Lambda-based method call
            string_codec.member(lambda a: a.get_name()),  # Lambda-based method call
        ).apply(SimpleAccount)

        format = BinaryFormat(account_codec)
        account = SimpleAccount(54321, 5000, "Checking")

        output = io.BytesIO()
        format.serialize(account, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, SimpleAccount)
        self.assertEqual(result.id, 54321)
        self.assertEqual(result.get_balance(), 5000)
        self.assertEqual(result.get_name(), "Checking")

    def test_string_property_lookup(self):
        """Test .member() with property decorators."""
        # Celsius property
        celsius_codec = float_codec.member('celsius')

        temp = Temperature(100.0)
        encoded = celsius_codec.encode(temp)
        decoded = float_codec.decode(encoded)

        self.assertAlmostEqual(decoded, 100.0, places=5)

    def test_string_private_field(self):
        """Test .member() can access private fields (Python convention)."""
        codec = tuple_codec(
            string_codec.member('_first'),
            string_codec.member('_last'),
            uint8_codec.member('_age'),
        ).apply(SimplePerson)

        format = BinaryFormat(codec)
        person = SimplePerson("Jane", "Smith", 35)

        output = io.BytesIO()
        format.serialize(person, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertIsInstance(result, SimplePerson)
        self.assertEqual(result._first, "Jane")
        self.assertEqual(result._last, "Smith")
        self.assertEqual(result._age, 35)


if __name__ == '__main__':
    unittest.main()



