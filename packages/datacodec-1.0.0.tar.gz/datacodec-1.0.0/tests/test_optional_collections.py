"""
Tests for vector of optional/nullable complex types.

These tests cover the edge case where optional codecs (which use VariantCodec)
are used as elements within vectors, ensuring None is properly handled as a
valid decoded value rather than being confused with deserialization failure.
"""
import unittest
import io
from datacodec import *


class TestVectorOfOptionals(unittest.TestCase):
    """Test vectors containing optional/nullable elements."""

    def test_vector_of_optional_ints(self):
        """Test vector of optional integers."""
        codec = vector_codec(optional_codec(int32_codec))
        format = BinaryFormat(codec)

        data = [42, None, 99, None, -5]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, data)
        self.assertEqual(len(result), 5)
        self.assertEqual(result[0], 42)
        self.assertIsNone(result[1])
        self.assertEqual(result[2], 99)
        self.assertIsNone(result[3])
        self.assertEqual(result[4], -5)

    def test_vector_of_optional_strings(self):
        """Test vector of optional strings."""
        codec = vector_codec(optional_codec(string_codec))
        format = BinaryFormat(codec)

        data = ["hello", None, "world", None]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, data)

    def test_vector_of_optional_pairs(self):
        """Test vector of optional pairs (tuples)."""
        codec = vector_codec(optional_codec(pair_codec(string_codec, int32_codec)))
        format = BinaryFormat(codec)

        data = [("a", 1), None, ("b", 2), ("c", 3), None]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(len(result), 5)
        self.assertEqual(result[0], ("a", 1))
        self.assertIsNone(result[1])
        self.assertEqual(result[2], ("b", 2))
        self.assertEqual(result[3], ("c", 3))
        self.assertIsNone(result[4])

    def test_vector_of_optional_tuples(self):
        """Test vector of optional tuples with multiple elements."""
        codec = vector_codec(
            optional_codec(tuple_codec(string_codec, int32_codec, float_codec))
        )
        format = BinaryFormat(codec)

        data = [
            ("first", 1, 1.5),
            None,
            ("second", 2, 2.5),
            None,
            ("third", 3, 3.5)
        ]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(len(result), 5)
        self.assertEqual(result[0], ("first", 1, 1.5))
        self.assertIsNone(result[1])
        self.assertEqual(result[2], ("second", 2, 2.5))
        self.assertIsNone(result[3])
        self.assertEqual(result[4], ("third", 3, 3.5))

    def test_all_none_vector(self):
        """Test vector where all elements are None."""
        codec = vector_codec(optional_codec(int32_codec))
        format = BinaryFormat(codec)

        data = [None, None, None]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, data)
        self.assertTrue(all(x is None for x in result))

    def test_all_values_vector(self):
        """Test vector where no elements are None."""
        codec = vector_codec(optional_codec(int32_codec))
        format = BinaryFormat(codec)

        data = [1, 2, 3, 4, 5]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, data)

    def test_empty_vector_of_optionals(self):
        """Test empty vector of optional elements."""
        codec = vector_codec(optional_codec(int32_codec))
        format = BinaryFormat(codec)

        data = []
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, [])

    def test_single_none_vector(self):
        """Test vector with single None element."""
        codec = vector_codec(optional_codec(string_codec))
        format = BinaryFormat(codec)

        data = [None]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(len(result), 1)
        self.assertIsNone(result[0])

    def test_nested_vector_of_optionals(self):
        """Test vector of vectors where inner vectors can be None."""
        codec = vector_codec(optional_codec(vector_codec(int32_codec)))
        format = BinaryFormat(codec)

        data = [
            [1, 2, 3],
            None,
            [4, 5],
            [],
            None,
            [6]
        ]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(len(result), 6)
        self.assertEqual(result[0], [1, 2, 3])
        self.assertIsNone(result[1])
        self.assertEqual(result[2], [4, 5])
        self.assertEqual(result[3], [])
        self.assertIsNone(result[4])
        self.assertEqual(result[5], [6])


class TestArrayOfOptionals(unittest.TestCase):
    """Test arrays containing optional/nullable elements."""

    def test_array_of_optional_ints(self):
        """Test fixed-size array of optional integers."""
        codec = array_codec(optional_codec(int32_codec), 4)
        format = BinaryFormat(codec)

        data = [10, None, 30, None]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(len(result), 4)
        self.assertEqual(result[0], 10)
        self.assertIsNone(result[1])
        self.assertEqual(result[2], 30)
        self.assertIsNone(result[3])

    def test_array_of_optional_strings(self):
        """Test fixed-size array of optional strings."""
        codec = array_codec(optional_codec(string_codec), 3)
        format = BinaryFormat(codec)

        data = ["first", None, "third"]
        output = io.BytesIO()
        format.serialize(data, output)

        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, data)


if __name__ == '__main__':
    unittest.main()

