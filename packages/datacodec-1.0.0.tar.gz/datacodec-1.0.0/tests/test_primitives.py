"""
Tests for primitive codecs (integers, floats, booleans).
"""
import unittest
import io
from datacodec import *


class TestIntegerCodecs(unittest.TestCase):
    """Test all integer codec types."""

    def test_int8_codec(self):
        """Test int8 codec with full range."""
        codec = int8_codec
        format = BinaryFormat(codec)

        test_values = [-128, -1, 0, 1, 127]
        for value in test_values:
            output = io.BytesIO()
            format.serialize(value, output)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, value)

    def test_uint8_codec(self):
        """Test uint8 codec with full range."""
        codec = uint8_codec
        format = BinaryFormat(codec)

        test_values = [0, 1, 127, 128, 255]
        for value in test_values:
            output = io.BytesIO()
            format.serialize(value, output)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, value)

    def test_int16_boundaries(self):
        """Test int16 at boundaries."""
        codec = int16_codec
        format = BinaryFormat(codec)

        for value in [-32768, -32767, 0, 32766, 32767]:
            output = io.BytesIO()
            format.serialize(value, output)
            self.assertEqual(len(output.getvalue()), 2)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, value)

    def test_uint16_boundaries(self):
        """Test uint16 at boundaries."""
        codec = uint16_codec
        format = BinaryFormat(codec)

        for value in [0, 1, 32767, 32768, 65535]:
            output = io.BytesIO()
            format.serialize(value, output)
            self.assertEqual(len(output.getvalue()), 2)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, value)

    def test_int32_boundaries(self):
        """Test int32 at boundaries."""
        codec = int32_codec
        format = BinaryFormat(codec)

        test_values = [-2147483648, -2147483647, 0, 2147483646, 2147483647]
        for value in test_values:
            output = io.BytesIO()
            format.serialize(value, output)
            self.assertEqual(len(output.getvalue()), 4)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, value)

    def test_uint32_boundaries(self):
        """Test uint32 at boundaries."""
        codec = uint32_codec
        format = BinaryFormat(codec)

        test_values = [0, 1, 2147483647, 2147483648, 4294967295]
        for value in test_values:
            output = io.BytesIO()
            format.serialize(value, output)
            self.assertEqual(len(output.getvalue()), 4)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, value)

    def test_int64_large_values(self):
        """Test int64 with large values."""
        codec = int64_codec
        format = BinaryFormat(codec)

        test_values = [
            -9223372036854775808,
            -1000000000000,
            0,
            1000000000000,
            9223372036854775807
        ]

        for value in test_values:
            output = io.BytesIO()
            format.serialize(value, output)
            self.assertEqual(len(output.getvalue()), 8)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, value)

    def test_uint64_large_values(self):
        """Test uint64 with large values."""
        codec = uint64_codec
        format = BinaryFormat(codec)

        test_values = [
            0,
            1,
            9223372036854775807,
            9223372036854775808,
            18446744073709551615
        ]

        for value in test_values:
            output = io.BytesIO()
            format.serialize(value, output)
            self.assertEqual(len(output.getvalue()), 8)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, value)


class TestFloatCodecs(unittest.TestCase):
    """Test floating point codecs."""

    def test_float_codec_precision(self):
        """Test float codec precision."""
        codec = float_codec
        format = BinaryFormat(codec)

        test_values = [0.0, 1.0, -1.0, 3.14159, -2.71828, 1e10, 1e-10]

        for value in test_values:
            output = io.BytesIO()
            format.serialize(value, output)
            self.assertEqual(len(output.getvalue()), 4)
            output.seek(0)
            result = format.deserialize(output)
            self.assertAlmostEqual(result, value, places=6)

    def test_float_special_values(self):
        """Test float with special values."""
        import math
        codec = float_codec
        format = BinaryFormat(codec)

        # Test infinity
        output = io.BytesIO()
        format.serialize(float('inf'), output)
        output.seek(0)
        result = format.deserialize(output)
        self.assertTrue(math.isinf(result) and result > 0)

        # Test negative infinity
        output = io.BytesIO()
        format.serialize(float('-inf'), output)
        output.seek(0)
        result = format.deserialize(output)
        self.assertTrue(math.isinf(result) and result < 0)

        # Test NaN
        output = io.BytesIO()
        format.serialize(float('nan'), output)
        output.seek(0)
        result = format.deserialize(output)
        self.assertTrue(math.isnan(result))

    def test_double_codec_precision(self):
        """Test double codec precision."""
        codec = double_codec
        format = BinaryFormat(codec)

        test_values = [
            0.0, 1.0, -1.0,
            3.141592653589793,
            2.718281828459045,
            1e100, 1e-100,
            1.7976931348623157e+308  # Near max double
        ]

        for value in test_values:
            output = io.BytesIO()
            format.serialize(value, output)
            self.assertEqual(len(output.getvalue()), 8)
            output.seek(0)
            result = format.deserialize(output)
            self.assertAlmostEqual(result, value, places=14)

    def test_double_special_values(self):
        """Test double with special values."""
        import math
        codec = double_codec
        format = BinaryFormat(codec)

        for value in [float('inf'), float('-inf'), float('nan')]:
            output = io.BytesIO()
            format.serialize(value, output)
            output.seek(0)
            result = format.deserialize(output)

            if math.isnan(value):
                self.assertTrue(math.isnan(result))
            elif math.isinf(value):
                self.assertTrue(math.isinf(result))
                self.assertEqual(result > 0, value > 0)


class TestBoolCodec(unittest.TestCase):
    """Test boolean codec."""

    def test_bool_true(self):
        """Test encoding True."""
        codec = bool_codec
        format = BinaryFormat(codec)

        output = io.BytesIO()
        format.serialize(True, output)
        self.assertEqual(len(output.getvalue()), 1)

        output.seek(0)
        result = format.deserialize(output)
        self.assertTrue(result)

    def test_bool_false(self):
        """Test encoding False."""
        codec = bool_codec
        format = BinaryFormat(codec)

        output = io.BytesIO()
        format.serialize(False, output)
        self.assertEqual(len(output.getvalue()), 1)

        output.seek(0)
        result = format.deserialize(output)
        self.assertFalse(result)

    def test_bool_multiple(self):
        """Test multiple booleans in sequence."""
        codec = bool_codec
        format = BinaryFormat(codec)

        values = [True, False, True, True, False]
        output = io.BytesIO()

        for value in values:
            format.serialize(value, output)

        output.seek(0)
        results = []
        for _ in range(len(values)):
            results.append(format.deserialize(output))

        self.assertEqual(results, values)


if __name__ == '__main__':
    unittest.main()

