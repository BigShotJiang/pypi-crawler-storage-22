"""
Tests for string codecs and varint codecs.
"""
import unittest
import io
from datacodec import *


class TestStringCodec(unittest.TestCase):
    """Test string codec with various inputs."""

    def test_basic_ascii(self):
        """Test basic ASCII strings."""
        codec = string_codec
        format = BinaryFormat(codec)

        test_strings = ["", "a", "hello", "Hello, World!", "12345"]

        for string in test_strings:
            output = io.BytesIO()
            format.serialize(string, output)

            # Check null terminator is present
            data = output.getvalue()
            self.assertEqual(data[-1], 0, f"Missing null terminator for '{string}'")

            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, string)

    def test_unicode_strings(self):
        """Test Unicode string encoding."""
        codec = string_codec
        format = BinaryFormat(codec)

        test_strings = [
            "Hello, 世界",
            "Привет мир",
            "🎉🎊🎈",
            "Émojis and àccénts",
            "Ελληνικά",
            "עברית",
            "العربية"
        ]

        for string in test_strings:
            output = io.BytesIO()
            format.serialize(string, output)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, string)

    def test_empty_string(self):
        """Test empty string serialization."""
        codec = string_codec
        format = BinaryFormat(codec)

        output = io.BytesIO()
        format.serialize("", output)

        # Empty string should be just null terminator
        self.assertEqual(output.getvalue(), b'\x00')

        output.seek(0)
        result = format.deserialize(output)
        self.assertEqual(result, "")

    def test_long_string(self):
        """Test long string handling."""
        codec = string_codec
        format = BinaryFormat(codec)

        # Create a long string
        long_string = "a" * 10000

        output = io.BytesIO()
        format.serialize(long_string, output)
        output.seek(0)
        result = format.deserialize(output)

        self.assertEqual(result, long_string)

    def test_string_with_special_chars(self):
        """Test strings with special characters."""
        codec = string_codec
        format = BinaryFormat(codec)

        special_strings = [
            "line1\nline2",
            "tab\tseparated",
            "quote\"test",
            "backslash\\test",
            "multiple\n\t\r\nspecial"
        ]

        for string in special_strings:
            output = io.BytesIO()
            format.serialize(string, output)
            output.seek(0)
            result = format.deserialize(output)
            self.assertEqual(result, string)


class TestUnsignedVarintCodec(unittest.TestCase):
    """Test unsigned varint codec."""

    def test_single_byte_values(self):
        """Test values that fit in one byte."""
        codec = unsigned_varint_codec

        for value in range(128):
            encoded = codec.encode(value)
            self.assertEqual(len(encoded), 1, f"Value {value} should use 1 byte")
            decoded = codec.decode(encoded)
            self.assertEqual(decoded, value)

    def test_two_byte_values(self):
        """Test values that require two bytes."""
        codec = unsigned_varint_codec

        test_values = [128, 129, 255, 256, 16383]

        for value in test_values:
            encoded = codec.encode(value)
            self.assertEqual(len(encoded), 2, f"Value {value} should use 2 bytes")
            decoded = codec.decode(encoded)
            self.assertEqual(decoded, value)

    def test_three_byte_values(self):
        """Test values that require three bytes."""
        codec = unsigned_varint_codec

        test_values = [16384, 16385, 2097151]

        for value in test_values:
            encoded = codec.encode(value)
            self.assertEqual(len(encoded), 3, f"Value {value} should use 3 bytes")
            decoded = codec.decode(encoded)
            self.assertEqual(decoded, value)

    def test_large_values(self):
        """Test large values."""
        codec = unsigned_varint_codec

        test_values = [
            0,
            127,
            128,
            16383,
            16384,
            2097151,
            2097152,
            268435455,
            268435456,
            4294967295,  # 32-bit max
            4294967296,  # Beyond 32-bit
        ]

        for value in test_values:
            encoded = codec.encode(value)
            decoded = codec.decode(encoded)
            self.assertEqual(decoded, value)

    def test_max_64bit(self):
        """Test maximum 64-bit value."""
        codec = unsigned_varint_codec

        max_value = 18446744073709551615  # 2^64 - 1
        encoded = codec.encode(max_value)
        self.assertLessEqual(len(encoded), 10)  # Varint uses max 10 bytes for 64-bit
        decoded = codec.decode(encoded)
        self.assertEqual(decoded, max_value)


class TestSignedVarintCodec(unittest.TestCase):
    """Test signed varint codec with zigzag encoding."""

    def test_zero(self):
        """Test zero encoding."""
        codec = signed_varint_codec

        encoded = codec.encode(0)
        self.assertEqual(len(encoded), 1)
        decoded = codec.decode(encoded)
        self.assertEqual(decoded, 0)

    def test_small_positive(self):
        """Test small positive values."""
        codec = signed_varint_codec

        for value in range(1, 64):
            encoded = codec.encode(value)
            self.assertEqual(len(encoded), 1, f"Value {value} should use 1 byte")
            decoded = codec.decode(encoded)
            self.assertEqual(decoded, value)

    def test_small_negative(self):
        """Test small negative values."""
        codec = signed_varint_codec

        for value in range(-64, 0):
            encoded = codec.encode(value)
            self.assertEqual(len(encoded), 1, f"Value {value} should use 1 byte")
            decoded = codec.decode(encoded)
            self.assertEqual(decoded, value)

    def test_positive_negative_symmetry(self):
        """Test that positive and negative values are handled symmetrically."""
        codec = signed_varint_codec

        test_values = [1, 10, 100, 1000, 10000, 100000]

        for value in test_values:
            encoded_pos = codec.encode(value)
            encoded_neg = codec.encode(-value)

            # Zigzag encoding should make pos/neg similar sizes
            self.assertEqual(len(encoded_pos), len(encoded_neg))

            decoded_pos = codec.decode(encoded_pos)
            decoded_neg = codec.decode(encoded_neg)

            self.assertEqual(decoded_pos, value)
            self.assertEqual(decoded_neg, -value)

    def test_large_values(self):
        """Test large positive and negative values."""
        codec = signed_varint_codec

        test_values = [
            -1000000, -10000, -1000, -100, -10, -1,
            0,
            1, 10, 100, 1000, 10000, 1000000
        ]

        for value in test_values:
            encoded = codec.encode(value)
            decoded = codec.decode(encoded)
            self.assertEqual(decoded, value)

    def test_extreme_values(self):
        """Test extreme 64-bit values."""
        codec = signed_varint_codec

        test_values = [
            -9223372036854775808,  # -2^63 (min int64)
            -2147483648,           # -2^31 (min int32)
            2147483647,            # 2^31-1 (max int32)
            9223372036854775807    # 2^63-1 (max int64)
        ]

        for value in test_values:
            encoded = codec.encode(value)
            decoded = codec.decode(encoded)
            self.assertEqual(decoded, value)


if __name__ == '__main__':
    unittest.main()

