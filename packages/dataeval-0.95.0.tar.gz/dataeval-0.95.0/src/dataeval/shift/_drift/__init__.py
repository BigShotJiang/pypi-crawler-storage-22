"""
:term:`Drift` detectors identify if the statistical properties of the data has changed.
"""
