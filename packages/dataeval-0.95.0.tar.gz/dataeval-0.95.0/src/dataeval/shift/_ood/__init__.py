"""
Out-of-distribution (OOD) detectors identify data that is different from the data used to train a particular model.
"""
