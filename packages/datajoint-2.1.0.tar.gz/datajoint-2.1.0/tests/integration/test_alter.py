import re

import pytest


from tests import schema as schema_any_module
from tests.schema_alter import LOCALS_ALTER, Experiment, Parent

COMBINED_CONTEXT = {
    **schema_any_module.LOCALS_ANY,
    **LOCALS_ALTER,
}


@pytest.fixture
def schema_alter(connection_test, schema_any_fresh):
    # Overwrite Experiment and Parent nodes using fresh schema
    schema_any_fresh(Experiment, context=LOCALS_ALTER)
    schema_any_fresh(Parent, context=LOCALS_ALTER)
    yield schema_any_fresh
    schema_any_fresh.drop()


class TestAlter:
    def verify_alter(self, schema_alter, table, attribute_sql):
        definition_original = schema_alter.connection.query(f"SHOW CREATE TABLE {table.full_table_name}").fetchone()[1]
        table.definition = table.definition_new
        table.alter(prompt=False)
        definition_new = schema_alter.connection.query(f"SHOW CREATE TABLE {table.full_table_name}").fetchone()[1]
        assert re.sub(f"{attribute_sql},\n  ", "", definition_new) == definition_original

    def test_alter(self, schema_alter):
        original = schema_alter.connection.query("SHOW CREATE TABLE " + Experiment.full_table_name).fetchone()[1]
        Experiment.definition = Experiment.definition1
        Experiment.alter(prompt=False, context=COMBINED_CONTEXT)
        altered = schema_alter.connection.query("SHOW CREATE TABLE " + Experiment.full_table_name).fetchone()[1]
        assert original != altered
        Experiment.definition = Experiment.original_definition
        Experiment().alter(prompt=False, context=COMBINED_CONTEXT)
        restored = schema_alter.connection.query("SHOW CREATE TABLE " + Experiment.full_table_name).fetchone()[1]
        assert altered != restored
        assert original == restored

    def test_alter_part(self, schema_alter):
        """
        https://github.com/datajoint/datajoint-python/issues/936
        """
        # Regex includes optional COMMENT for type annotations
        self.verify_alter(schema_alter, table=Parent.Child, attribute_sql=r"`child_id` .* DEFAULT NULL[^,]*")
        self.verify_alter(
            schema_alter,
            table=Parent.Grandchild,
            attribute_sql=r"`grandchild_id` .* DEFAULT NULL[^,]*",
        )
