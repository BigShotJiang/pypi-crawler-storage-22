"""Tests for MCP server"""
