"""Unit tests for artifact module."""
