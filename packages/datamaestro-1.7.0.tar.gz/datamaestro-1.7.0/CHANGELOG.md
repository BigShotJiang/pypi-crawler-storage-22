# 0.8.0

- Integration with other repositories: abstracting away the notion of dataset
- Repository prefix
- Set sub-datasets IDs automatically

# 0.7.3

- Updates for new experimaestro (0.8.5)
- Search types with "type:..."

# 0.6.17

- Allow remote access through rpyc

# 0.6.9

`version` command
