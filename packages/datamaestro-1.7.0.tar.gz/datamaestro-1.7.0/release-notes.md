## [1.7.0] - 2026-01-29

### Features
- Redesign Resource interface with DAG pipelines, two-path downloads, and state tracking ([dae5e06](https://github.com/experimaestro/experimaestro-python/commit/dae5e06a6de38e7ce02c2c406a305993157b1fdb))

