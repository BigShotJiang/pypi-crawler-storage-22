## [1.7.2] - 2026-01-29

### Bug Fixes
- Guard _resolve_reference with isinstance check for class types ([0e9f2bb](https://github.com/experimaestro/experimaestro-python/commit/0e9f2bbcce5beb5d09aaa4f2eff017b559178620))

