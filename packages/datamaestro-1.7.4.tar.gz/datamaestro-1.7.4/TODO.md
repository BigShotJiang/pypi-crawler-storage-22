# Recommendation

- [Jester Online Joke Recommender System](http://eigentaste.berkeley.edu/dataset/)
- [Cite-u-like dataset](http://www.wanghao.in/publication.html)
