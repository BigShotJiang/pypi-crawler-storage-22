## [1.7.4] - 2026-01-29

### Features
- Support class-based datasets in prepare_dataset and add test deps ([0e4d6b1](https://github.com/experimaestro/experimaestro-python/commit/0e4d6b13b76a43f2d03d62b91ff17d7cacc2e040))

