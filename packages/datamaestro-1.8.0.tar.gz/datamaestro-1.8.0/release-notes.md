## [1.8.0] - 2026-02-03

### Bug Fixes
- Handle dot-prefixed dataset IDs correctly and improve docs ([84f70dd](https://github.com/experimaestro/experimaestro-python/commit/84f70dd799e9a0081dbb47f6a8c09cb864f45599))

