#
# Copyright 2026 DataRobot, Inc. and its affiliates.
#
# All rights reserved.
#
# DataRobot, Inc.
#
# This is proprietary source code of DataRobot, Inc. and its
# affiliates.
#
# Released under the terms of DataRobot Tool and Utility Agreement.
from __future__ import annotations

from collections import defaultdict
from contextlib import contextmanager
from datetime import datetime
from glob import has_magic
from http import HTTPStatus
import os
from typing import Any, Dict, Generator, Iterable, List, Literal, Optional, Set, Tuple, TypedDict, Union, overload

from fsspec import AbstractFileSystem
from fsspec.utils import glob_translate, stringify_path

from datarobot._experimental.models.files_experimental import FilesExperimental
from datarobot.enums import DEFAULT_MAX_WAIT, FilesOverwriteStrategy
from datarobot.errors import ClientError
from datarobot.models.files import File, FilesCatalogSearch


class FileInfo(TypedDict):
    """
    Information about a file or directory in DataRobot File System.

    Attributes
    ----------
    name:
        The path of the file or directory. Does not include the protocol prefix.
    size:
        The size of the file in bytes. For directories, this is 0.
    type:
        The type of the item, either 'file' or 'directory'.
    format:
        The file format (e.g., 'csv', 'pdf') if the item is a file; None for directories.
    """

    name: str
    size: int
    type: Literal['file', 'directory']
    format: Optional[str]


class DataRobotFileSystem(AbstractFileSystem):  # type: ignore[misc]
    """
    fsspec implementation for DataRobot's file system.

    File paths are of the form:
        dr://<catalog_id>/path/to/file.txt
    """

    protocol = "dr"
    root_marker = ""  # Root does not need leading slash (/)

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)

    @classmethod
    def _strip_protocol(cls, path: str) -> str:
        """
        Turn path from fully-qualified to DR file system specific.

        Parameters
        ----------
        path:
            File path in the DataRobot file system.

        Returns
        -------
        str:
            Validated file path without the protocol prefix.

        Examples
        --------
        .. code-block:: python

            >>> from datarobot._experimental.fs import DataRobotFileSystem
            >>> DataRobotFileSystem._strip_protocol("dr://12345/path/to/file.txt")
            '12345/path/to/file.txt'
            >>> DataRobotFileSystem._strip_protocol("dr://12345/path/")
            '12345/path/'
            >>> DataRobotFileSystem._strip_protocol("dr:///12345/")
            '12345/'
            >>> DataRobotFileSystem._strip_protocol("dr://")
            ''
        """
        path = stringify_path(path)
        protos = (cls.protocol,) if isinstance(cls.protocol, str) else cls.protocol
        for protocol in protos:
            if path.startswith(protocol + "://"):
                path = path[len(protocol) + 3 :]
            elif path.startswith(protocol + "::"):
                path = path[len(protocol) + 2 :]
        if path.endswith("/"):
            path = path.rstrip("/") + "/"  # Normalize trailing slashes (/) to max 1
        path = path.lstrip("/")  # No leading slashes
        # use of root_marker to make minimum required path
        return path or cls.root_marker

    def _split_path(self, path: str) -> Tuple[str, str]:
        """
        Split the given path into catalog ID and internal file path.
        Internal paths can be empty.

        Parameters
        ----------
        path:
            File path in the DataRobot file system.

        Returns
        -------
        Tuple[str, str]:
            A tuple of catalog ID and the internal file path.

        Raises
        ------
        ValueError:
            If the path format is invalid.

        Examples
        --------
        .. code-block:: python

            >>> fs = DataRobotFileSystem()
            >>> fs._split_path("dr://12345/path/to/file.txt")
            ('12345', 'path/to/file.txt')
            >>> fs._split_path("dr:///12345/")
            ('12345', '')
            >>> fs._split_path("12345/folder/")
            ('12345', 'folder/')
        """
        path_without_protocol = self._strip_protocol(path)
        if not path_without_protocol:
            raise ValueError(
                f"Invalid path '{path}'. Expected format: '{self.protocol}://<catalog_id>/path/to/file.txt'"
            )
        parts = path_without_protocol.split("/", 1)
        catalog_id = parts[0]
        internal_path = parts[1] if len(parts) > 1 else ""
        return catalog_id, internal_path

    @contextmanager
    def _try_convert_to_fsspec_exception(self) -> Generator[None, None, None]:
        """Convert exceptions from DataRobot client to fsspec exceptions where possible."""
        try:
            yield
        except ClientError as exc:
            if exc.status_code in {HTTPStatus.NOT_FOUND, HTTPStatus.GONE}:
                raise FileNotFoundError(str(exc.json.get('message', exc.json))) from exc
            elif exc.status_code == HTTPStatus.FORBIDDEN:
                raise PermissionError(str(exc.json.get('message', exc.json))) from exc
            elif exc.status_code == HTTPStatus.CONFLICT:
                raise FileExistsError(str(exc.json.get('message', exc.json))) from exc
            elif exc.status_code in {HTTPStatus.BAD_REQUEST, HTTPStatus.UNPROCESSABLE_ENTITY}:
                message = str(exc.json.get('message', exc.json))
                if 'errors' in exc.json:
                    message += f" {exc.json.get('errors', '')}"
                raise ValueError(message) from exc
            raise

    @contextmanager
    def _swallow_not_found_errors(self) -> Generator[None, None, None]:
        """Silently ignore file not found and already deleted errors."""
        try:
            yield
        except ClientError as exc:
            if exc.status_code not in {HTTPStatus.NOT_FOUND, HTTPStatus.GONE}:
                raise
        except FileNotFoundError:
            pass

    def _format_path_details_for_files(
        self, catalog_id: str, files: List[File], show_details: bool
    ) -> Union[List[FileInfo], List[str]]:
        """Format path details for a list of files. Files can represent both files and directories."""
        if show_details:
            return [
                FileInfo(
                    name=f"{catalog_id}/{file.name}",
                    size=file.size,
                    type="directory" if file.type == "folder" else "file",
                    format=file.type if file.type != "folder" else None,
                )
                for file in files
            ]

        return [f"{catalog_id}/{file.name}" for file in files]

    def _format_path_details_for_catalog_items(
        self, catalog_items: List[FilesCatalogSearch], show_details: bool
    ) -> Union[List[FileInfo], List[str]]:
        """Format path details for a list of catalog items. Catalog items are treated as top-level directories."""
        if show_details:
            return [FileInfo(name=f"{item.id}/", size=0, type="directory", format=None) for item in catalog_items]
        return [f"{item.id}/" for item in catalog_items]

    def _get_files_wrapper_for_folder_id(self, catalog_id: str) -> FilesExperimental:
        return FilesExperimental(catalog_id, "", "", [], datetime.now(), "")

    @overload
    def ls(self, path: str, detail: Literal[False], **kwargs: Dict[str, Any]) -> List[str]: ...

    @overload
    def ls(self, path: str, detail: Literal[True], **kwargs: Dict[str, Any]) -> List[FileInfo]: ...

    def ls(self, path: str, detail: bool = True, **kwargs: Dict[str, Any]) -> Union[List[FileInfo], List[str]]:
        """
        List files and folders at the given directory path. Use
        :meth:`info() <datarobot._experimental.fs.file_system.DataRobotFileSystem.info>` for information about
        a specific file.

        If `detail` is True, returns a list of dictionaries with file details including name (path), size and type.
        If `detail` is False, returns a list of file and folder paths as strings.

        Parameters
        ----------
        path:
            Path in the DataRobot file system to list.
        detail:
            Whether to return detailed information.
        kwargs:
            Additional keyword arguments for future proofing.

        Returns
        -------
        paths: Union[List[Dict[str, Any]], List[str]]
            List of dicts with file and folder details if `detail` is True, otherwise list of paths.

        Raises
        ------
        FileNotFoundError:
            If the specified path does not exist.

        Examples
        --------
        .. code-block:: python

            >>> from datarobot._experimental.fs import DataRobotFileSystem
            >>> fs = DataRobotFileSystem()
            >>> fs.ls("dr://", detail=False)
            ['696935d6d5a04a752419cf6d/', 'abcdef1234567890abcdef12/']
            >>> fs.ls("dr://696935d6d5a04a752419cf6d/finance/")
            [
                {
                    'name': '696935d6d5a04a752419cf6d/finance/fy-2024/',
                    'size': 0,
                    'type': 'directory',
                    'format': None
                },
                {
                    'name': '696935d6d5a04a752419cf6d/finance/employee-list.csv',
                    'size': 2048,
                    'type': 'file',
                    'format': 'csv'
                },
            ]

        See also
        --------
        :meth:`info() <datarobot._experimental.fs.file_system.DataRobotFileSystem
        :meth:`exists() <datarobot._experimental.fs.file_system.DataRobotFileSystem.exists>`
        """
        if self.unstrip_protocol(path) == f"{self.protocol}://":
            with self._try_convert_to_fsspec_exception():
                catalog_items = FilesExperimental.search_catalog(limit=0)
            return self._format_path_details_for_catalog_items(catalog_items, detail)

        catalog_id, internal_path = self._split_path(path)
        prefix = f"{internal_path.rstrip('/')}/" if internal_path else None
        with self._try_convert_to_fsspec_exception():
            files = self._get_files_wrapper_for_folder_id(catalog_id)._list_contained_files(
                limit=0,
                recursive=False,
                prefix=prefix,
            )
        path_details = self._format_path_details_for_files(catalog_id, files, detail)

        if internal_path and path_details == []:
            raise FileNotFoundError(f"No directory found at {path}")
        return path_details

    def info(self, path: str, **kwargs: Dict[str, Any]) -> FileInfo:
        """
        Get details about a file or directory.

        For info about a directory path append a forward slash (/) at the end of the path.
        Paths without a trailing slash can return info about files or directories. If both
        a file and directory share the same path, the file info is returned.

        Parameters
        ----------
        path:
            Path in the DataRobot file system to get information about.
        kwargs:
            Additional keyword arguments passed to
            :meth:`ls() <datarobot._experimental.fs.file_system.DataRobotFileSystem.ls>`.

        Returns
        -------
        info: Dict[str, Any]
            A dictionary with file or directory details including name (path), size and type.

        Raises
        ------
        FileNotFoundError:
            If the specified path does not exist.
        ValueError:
            If the path is invalid. Root path is not allowed.

        Examples
        --------
        .. code-block:: python

            >>> from datarobot._experimental.fs import DataRobotFileSystem
            >>> fs = DataRobotFileSystem()
            >>> fs.info("dr://696935d6d5a04a752419cf6d/finance/employee-list.csv")
            {
                'name': '696935d6d5a04a752419cf6d/finance/employee-list.csv',
                'size': 2048,
                'type': 'file',
                'format': 'csv'
            }
            >>> fs.info("dr://696935d6d5a04a752419cf6d/finance/")
            {
                'name': '696935d6d5a04a752419cf6d/finance/',
                'size': 0,
                'type': 'directory',
                'format': None
            }
            >>> fs.info("dr://696935d6d5a04a752419cf6d/my_folder")
            {
                'name': '696935d6d5a04a752419cf6d/my_folder/',
                'size': 0,
                'type': 'directory',
                'format': None
            }
        """
        self._split_path(path)  # Disallow info at root
        path_without_protocol = self._strip_protocol(path)
        out = self.ls(self._parent(path.rstrip("/")), detail=True, **kwargs)

        if path.endswith("/"):
            targets = [item for item in out if item["name"] == path_without_protocol and item["type"] == "directory"]
        else:
            targets = [item for item in out if item["name"].rstrip("/") == path_without_protocol.rstrip("/")]
            if len(targets) > 1:  # This should only ever be 2
                # Prefer files over directories for paths not ending with /
                targets = [item for item in targets if item["type"] == "file"]

        if targets:
            return targets[0]
        raise FileNotFoundError(f"No file or directory found at {path}")

    @overload
    def find(
        self,
        path: str,
        maxdepth: Optional[int] = None,
        withdirs: bool = False,
        detail: Literal[False] = ...,
        **kwargs: Dict[str, Any],
    ) -> List[str]: ...

    @overload
    def find(
        self,
        path: str,
        maxdepth: Optional[int] = None,
        withdirs: bool = False,
        detail: Literal[True] = ...,
        **kwargs: Dict[str, Any],
    ) -> Dict[str, FileInfo]: ...

    def find(
        self,
        path: str,
        maxdepth: Optional[int] = None,
        withdirs: bool = False,
        detail: bool = False,
        **kwargs: Dict[str, Any],
    ) -> Union[List[str], Dict[str, FileInfo]]:
        """List all files below path. If `withdirs` is True, include directories as well.

        Like posix ``find`` command without conditions

        Parameters
        ----------
        path:
            The path to search from.
        maxdepth:
            If not None, the maximum number of levels to descend
        withdirs:
            Whether to include directory paths in the output. This is True
            when used by glob, but users usually only want files.
        kwargs:
            Passed to :meth:`ls <datarobot._experimental.fs.file_system.DataRobotFileSystem.walk>`

        Returns
        -------
        List[str] or Dict[str, Dict[str, FileInfo]]
            If `detail` is False, a list of file (and optionally directory) paths.
            If `detail` is True, a dictionary mapping paths to their info dictionaries.

        Examples
        --------
        .. code-block:: python

            >>> from datarobot._experimental.fs import DataRobotFileSystem
            >>> fs = DataRobotFileSystem()
            >>> fs.find("dr://696935d6d5a04a752419cf6d/", withdirs=True)
            [
                '696935d6d5a04a752419cf6d/',
                '696935d6d5a04a752419cf6d/finance/',
                '696935d6d5a04a752419cf6d/finance/budgets/',
                '696935d6d5a04a752419cf6d/finance/budgets/Q2_budget_2024.pdf',
                '696935d6d5a04a752419cf6d/finance/employee-list.csv'
            ]

            >>> fs.find("dr://696935d6d5a04a752419cf6d/finance/", maxdepth=1)
            ['696935d6d5a04a752419cf6d/finance/employee-list.csv']

            >>> fs.find("dr://696935d6d5a04a752419cf6d/finance", maxdepth=1, withdirs=True, detail=True)
            {
                '696935d6d5a04a752419cf6d/finance/': {
                    'name': '696935d6d5a04a752419cf6d/finance/',
                    'size': 0,
                    'type': 'directory',
                    'format': None
                },
                '696935d6d5a04a752419cf6d/finance/employee-list.csv': {
                    'name': '696935d6d5a04a752419cf6d/finance/employee-list.csv',
                    'size': 2048,
                    'type': 'file',
                    'format': 'csv'
                },
                '696935d6d5a04a752419cf6d/finance/budgets/': {
                    'name': '696935d6d5a04a752419cf6d/finance/budgets/',
                    'size': 0,
                    'type': 'directory',
                    'format': None
                },
            }
        """
        # This is a copy of of AbstractFileSystem.find() method with slight modification
        path = self._strip_protocol(path)
        out: Dict[str, Any] = {}

        # Add the root directory if withdirs is requested
        # This is needed for posix glob compliance
        if withdirs and path != "" and self.isdir(path):
            path_info = self.info(path)
            out[path_info["name"]] = path_info

        for _, dirs, files in self.walk(path, maxdepth, detail=True, **kwargs):
            if withdirs:
                out.update({info["name"]: info for _, info in dirs.items()})
            out.update({info["name"]: info for _, info in files.items()})
        if not out and self.isfile(path):
            # walk works on directories, but find should also return [path]
            # when path happens to be a file
            if detail:
                out[path] = self.info(path)
            else:
                out[path] = {}
        names = sorted(out)
        if not detail:
            return names
        else:
            return {name: out[name] for name in names}

    @overload
    def glob(
        self, path: str, maxdepth: Optional[int] = None, detail: Literal[False] = ..., **kwargs: Dict[str, Any]
    ) -> List[str]: ...

    @overload
    def glob(
        self, path: str, maxdepth: Optional[int] = None, detail: Literal[True] = ..., **kwargs: Dict[str, Any]
    ) -> Dict[str, FileInfo]: ...

    def glob(
        self, path: str, maxdepth: Optional[int] = None, detail: bool = False, **kwargs: Dict[str, Any]
    ) -> Union[List[str], Dict[str, FileInfo]]:
        """
        Find files by glob-matching.

        Pattern matching capabilities for finding files that match the given pattern.

        Parameters
        ----------
        path:
            The glob pattern to match against.
        maxdepth:
            Maximum depth for '**' patterns. Applied on the first '**' found.
            Must be at least 1 if provided.
        detail:
            Whether to return detailed information.
        kwargs:
            Additional arguments passed to ``find``.

        Returns
        -------
        List[str] or Dict[str, FileInfo]
            If `detail` is False, a list of file and directory paths.
            If `detail` is True, a dictionary mapping paths to their info dictionaries.

        Notes
        -----
        Supported patterns:
        - '*': Matches any sequence of characters within a single directory level
        - '**': Matches any number of directory levels (must be an entire path component)
        - '?': Matches exactly one character
        - '[abc]': Matches any character in the set
        - '[a-z]': Matches any character in the range
        - '[!abc]': Matches any character NOT in the set

        Special behaviors:
        - If the path ends with '/', only folders are returned
        - Consecutive '*' characters are compressed into a single '*'
        - Empty brackets '[]' never match anything
        - Negated empty brackets '[!]' match any single character
        - Special characters in character classes are escaped properly

        Limitations:
        - '**' must be a complete path component (e.g., 'a/**/b', not 'a**b')
        - No brace expansion ('{a,b}.txt')
        - No extended glob patterns ('+(pattern)', '!(pattern)')

        See Also
        --------
        :meth:`find() <datarobot._experimental.fs.file_system.DataRobotFileSystem.find>`

        Examples
        --------
        Find all files and directories directly under the specified path.

        .. code-block:: python

            >>> from datarobot._experimental.fs import DataRobotFileSystem
            >>> fs = DataRobotFileSystem()
            >>> fs.glob("dr://696935d6d5a04a752419cf6d/finance/*", detail=False)
            [
                '696935d6d5a04a752419cf6d/finance/budgets/',
                '696935d6d5a04a752419cf6d/finance/employee-list.csv'
            ]

        Find only directories directly under the specified path.

        .. code-block:: python

            >>> fs.glob("dr://696935d6d5a04a752419cf6d/finance/*/", detail=False)
            ['696935d6d5a04a752419cf6d/finance/budgets/']

        Find any budget directories with a 4-digit year in their name.

        .. code-block:: python

            >>> fs.glob("dr://696935d6d5a04a752419cf6d/finance/budgets/*-202[0-9]/", detail=False)
            [
                '696935d6d5a04a752419cf6d/finance/budgets/fy-2024/',
                '696935d6d5a04a752419cf6d/finance/budgets/fy-2023/'
            ]

        Find all .csv files at a maximum depth of 2 levels.

        .. code-block:: python

            >>> fs.glob("dr://696935d6d5a04a752419cf6d/**/*.csv", maxdepth=2, detail=False)
            [
                '696935d6d5a04a752419cf6d/finance/employee-list.csv',
                '696935d6d5a04a752419cf6d/sales/data.csv'
            ]
        """
        # This is a copy of AbstractFileSystem.glob() method with slight modification
        if maxdepth is not None and maxdepth < 1:
            raise ValueError("maxdepth must be at least 1")

        import re

        seps = (os.path.sep, os.path.altsep) if os.path.altsep else (os.path.sep,)
        ends_with_sep = path.endswith(seps)
        path = self._strip_protocol(path)
        append_slash_to_dirname = ends_with_sep or path.endswith(tuple(sep + "**" for sep in seps))
        idx_star = path.find("*") if path.find("*") >= 0 else len(path)
        idx_qmark = path.find("?") if path.find("?") >= 0 else len(path)
        idx_brace = path.find("[") if path.find("[") >= 0 else len(path)

        min_idx = min(idx_star, idx_qmark, idx_brace)

        if not has_magic(path):
            if self.exists(path, **kwargs):
                if not detail:
                    return [path]
                else:
                    return {path: self.info(path, **kwargs)}
            elif not detail:
                return []  # glob of non-existent returns empty
            else:
                return {}
        elif "/" in path[:min_idx]:
            min_idx = path[:min_idx].rindex("/")
            root = path[: min_idx + 1]
            depth = path[min_idx + 1 :].count("/") + 1
        else:
            root = ""
            depth = path[min_idx + 1 :].count("/") + 1

        if "**" in path:
            if maxdepth is not None:
                idx_double_stars = path.find("**")
                depth_double_stars = path[idx_double_stars:].count("/") + 1
                depth = depth - depth_double_stars + maxdepth
            else:
                depth = None  # type: ignore[assignment]

        allpaths = self.find(root, maxdepth=depth, withdirs=True, detail=True, **kwargs)

        pattern = glob_translate(path + ("/" if ends_with_sep else ""))
        pattern = re.compile(pattern)

        def _has_pattern_match(path: str, info: FileInfo) -> Optional[re.Match[str]]:
            """
            Check whether the given path matches the glob pattern.
            Accounts for directory paths modifications required.
            """
            if info["type"] != "directory":
                return pattern.match(path)
            if append_slash_to_dirname:
                return pattern.match(path + "/")
            return pattern.match(path.rstrip("/"))

        out = {p: info for p, info in sorted(allpaths.items()) if _has_pattern_match(p, info)}
        if detail:
            return out
        else:
            return list(out)

    def tree(
        self,
        path: str = "",
        recursion_limit: int = 2,
        max_display: int = 25,
        display_size: bool = False,
        prefix: str = "",
        is_last: bool = True,
        first: bool = True,
        indent_size: int = 4,
    ) -> str:
        """
        Return a tree-like structure string of the DataRobot file system from the given path.
        Parameters
        ----------
        path:
            Path in the DataRobot file system to display the tree from.
        recursion_limit:
            Maximum depth of directory traversal.
        max_display:
            Maximum number of items to display per directory.
        display_size:
            Whether to display file sizes.
        prefix:
            Current line prefix for visual tree structure.
        is_last:
            Whether the current item is last in its level.
        first:
            Whether this is the first call (displays root path).
        indent_size:
            Number of spaces by ident.
        Returns
        -------
        tree_str: str
            A string representing the tree structure of the file system.
        Examples
        --------
        .. code-block:: python
            >>> from datarobot._experimental.fs import DataRobotFileSystem
            >>> fs = DataRobotFileSystem()
            >>> print(fs.tree("dr://696935d6d5a04a752419cf6d/", recursion_limit=5))
            696935d6d5a04a752419cf6d/
            └── finance/
                ├── fy-2024/
                │   └── budgets/
                │       └── Q2_budget_2024.pdf
                └── employee-list.csv
        See also
        --------
        :meth:`walk() <datarobot._experimental.fs.file_system.DataRobotFileSystem.walk>`
        """

        # This is a copy of AbstractFileSystem.tree() with slight modification
        def format_bytes(n: int) -> str:
            """Format bytes as text."""
            for pref, k in (
                ("P", 2**50),
                ("T", 2**40),
                ("G", 2**30),
                ("M", 2**20),
                ("k", 2**10),
            ):
                if n >= 0.9 * k:
                    return f"{n / k:.2f} {pref}b"
            return f"{n}B"

        result = []

        if first:
            if self.unstrip_protocol(path) == f"{self.protocol}://":
                result.append("")
            else:
                path_info = self.info(path)
                result.append(path_info["name"])  # Tweak top-level to use info name

        if recursion_limit:
            indent = " " * indent_size
            contents = self.ls(path, detail=True)
            contents.sort(key=lambda x: (x.get("type") != "directory", x.get("name", "")))

            if max_display is not None and len(contents) > max_display:
                displayed_contents = contents[:max_display]
                remaining_count = len(contents) - max_display
            else:
                displayed_contents = contents
                remaining_count = 0

            for i, item in enumerate(displayed_contents):
                is_last_item = (i == len(displayed_contents) - 1) and (remaining_count == 0)

                branch = "└" + ("─" * (indent_size - 2)) if is_last_item else "├" + ("─" * (indent_size - 2))
                branch += " "
                new_prefix = prefix + (indent if is_last_item else "│" + " " * (indent_size - 1))

                # Tweak name to handle trailing slashes for directories
                if item["type"] == "directory":
                    name = os.path.basename(item.get("name", "").rstrip("/")) + "/"
                else:
                    name = os.path.basename(item.get("name", ""))

                if display_size and item.get("type") == "directory":
                    sub_contents = self.ls(item.get("name", ""), detail=True)
                    num_files = sum(1 for sub_item in sub_contents if sub_item.get("type") == "file")
                    num_folders = sum(1 for sub_item in sub_contents if sub_item.get("type") == "directory")

                    if num_files == 0 and num_folders == 0:
                        size = " (empty folder)"
                    elif num_files == 0:
                        size = f" ({num_folders} subfolder{'s' if num_folders > 1 else ''})"
                    elif num_folders == 0:
                        size = f" ({num_files} file{'s' if num_files > 1 else ''})"
                    else:
                        suffix = 's' if num_folders > 1 else ''
                        size = f" ({num_files} file{'s' if num_files > 1 else ''}, {num_folders} subfolder{suffix})"
                elif display_size and item.get("type") == "file":
                    size = f" ({format_bytes(item.get('size', 0))})"
                else:
                    size = ""

                result.append(f"{prefix}{branch}{name}{size}")

                if item.get("type") == "directory" and recursion_limit > 0:
                    result.append(
                        self.tree(
                            path=item.get("name", ""),
                            recursion_limit=recursion_limit - 1,
                            max_display=max_display,
                            display_size=display_size,
                            prefix=new_prefix,
                            is_last=is_last_item,
                            first=False,
                            indent_size=indent_size,
                        )
                    )

            if remaining_count > 0:
                more_message = f"{remaining_count} more item(s) not displayed."
                result.append(f"{prefix}{'└' + ('─' * (indent_size - 2))} {more_message}")

        return "\n".join(_ for _ in result if _)

    def cp_file(
        self,
        path1: str,
        path2: str,
        overwrite_strategy: FilesOverwriteStrategy = FilesOverwriteStrategy.RENAME,
        max_wait: int = DEFAULT_MAX_WAIT,
        wait_for_completion: bool = True,
        **kwargs: Dict[str, Any],
    ) -> None:
        """
        Copy a file or directory from `path1` to `path2`.

        Copies directories recursively. Specify an overwrite strategy to handle file naming conflicts
        at the target location. Note that copying between catalog item directories is an asynchronous operation.
        Cannot create a new catalog item directory by copying files into a non-existent catalog item directory.

        Parameters
        ----------
        path1:
            Source file or directory path. Directory paths should end with a forward slash (/).
        path2:
            Target file or directory path. Directory paths should end with a forward slash (/).
        overwrite_strategy:
            Strategy to handle naming conflicts at the target location.
        max_wait:
            Maximum time in seconds to wait for the copy operation to complete when copying between
            catalog items.
        wait_for_completion:
            Whether to wait for the copy operation to complete before returning when copying between
            catalog items.
        kwargs:
            Additional keyword arguments for future proofing.

        Raises
        ------
        FileNotFoundError:
            If the source path does not exist or either catalog item directory does not exist.
        ValueError:
            If attempting to copy a directory to a file path.
        FileExistsError:
            If the target file or directory already exists and overwrite strategy is set to ERROR.

        Examples
        --------
        Copy a file to a new file path:

        .. code-block:: python

            >>> from datarobot._experimental.fs import DataRobotFileSystem
            >>> from datarobot.enums import FilesOverwriteStrategy
            >>> fs = DataRobotFileSystem()
            >>> fs.cp_file(
            ...     "dr://696935d6d5a04a752419cf6d/fy-2024/budgets/Q2_budget_2024.pdf",
            ...     "dr://69691fc3d5a04a752419cf5/fy-2024/budgets-copy.pdf",
            ... )

        Copy file into a directory, replace existing file if present:

        .. code-block:: python

            >>> fs.cp_file(
            ...     "dr://696935d6d5a04a752419cf6d/fy-2024/budgets/Q2_budget_2024.pdf",
            ...     "dr://69691fc3d5a04a752419cf5/fy-2024/budgets/",
            ...     overwrite_strategy=FilesOverwriteStrategy.OVERWRITE,
            ... )

        Copy the contents of a directory into another directory:

        .. code-block:: python

            >>> fs.cp_file(
            ...     "dr://696935d6d5a04a752419cf6d/fy-2024/budgets/",
            ...     "dr://69691fc3d5a04a752419cf5/archive/budgets-2024/",
            ... )

        See also
        --------
        :meth:`copy() <datarobot._experimental.fs.file_system.DataRobotFileSystem.copy>`
        """
        source_catalog_id, source_internal_path = self._split_path(path1)
        target_catalog_id, target_internal_path = self._split_path(path2)

        if not source_internal_path and not target_internal_path:
            raise ValueError("Cannot copy catalog item folder to another catalog item folder. Use clone() instead.")
        elif source_internal_path and not target_internal_path:
            # Handle edge case to copy file or folder into root of target catalog item
            target_internal_path = os.path.basename(source_internal_path.rstrip("/")) + (
                "/" if source_internal_path.endswith("/") else ""
            )

        with self._try_convert_to_fsspec_exception():
            if source_catalog_id == target_catalog_id:
                self._get_files_wrapper_for_folder_id(catalog_id=source_catalog_id).copy_within_container(
                    source_path=source_internal_path,
                    target_path=target_internal_path,
                    overwrite=overwrite_strategy,
                )
            else:
                self._get_files_wrapper_for_folder_id(catalog_id=source_catalog_id)._copy(
                    source_path=source_internal_path,
                    target=target_internal_path,
                    target_file=self._get_files_wrapper_for_folder_id(catalog_id=target_catalog_id),
                    overwrite=overwrite_strategy,
                    max_wait=max_wait,
                    wait_for_completion=wait_for_completion,
                )

    def cp_directory(
        self,
        path1: str,
        path2: str,
        overwrite_strategy: FilesOverwriteStrategy = FilesOverwriteStrategy.RENAME,
        max_wait: int = DEFAULT_MAX_WAIT,
        wait_for_completion: bool = True,
        **kwargs: Dict[str, Any],
    ) -> None:
        """
        Copy a directory recursively from `path1` to `path2`.

        Validates that both paths are directories by checking for trailing slashes (/).
        Calls :meth:`cp_file() <datarobot._experimental.fs.file_system.DataRobotFileSystem.cp_file>` internally.

        Parameters
        ----------
        path1:
            Source directory path. Must end with a forward slash (/).
        path2:
            Target directory path. Must end with a forward slash (/).
        overwrite_strategy:
            Strategy to handle naming conflicts at the target location.
        max_wait:
            Maximum time in seconds to wait for the copy operation to complete when copying between
            catalog items.
        wait_for_completion:
            Whether to wait for the copy operation to complete before returning when copying between
            catalog items.
        kwargs:
            Additional keyword arguments passed to
            :meth:`cp_file() <datarobot._experimental.fs.file_system.DataRobotFileSystem.cp_file>`.

        See also
        --------
        :meth:`cp_file() <datarobot._experimental.fs.file_system.DataRobotFileSystem.cp_file>`
        """
        if not path1.endswith("/") or not path2.endswith("/"):
            raise ValueError("To copy a directory, source and target paths must end with '/'.")
        self.cp_file(
            path1,
            path2,
            overwrite_strategy=overwrite_strategy,
            max_wait=max_wait,
            wait_for_completion=wait_for_completion,
            **kwargs,
        )

    def _rm(self, path: Union[str, List[str]], **kwargs: Dict[str, Any]) -> None:
        """
        Prefer use :meth:`rm_file() <datarobot._experimental.fs.file_system.DataRobotFileSystem.rm_file>`.
        Implemented for backwards compatibility.

        Splits paths to target files/folders within catalog items or entire catalog items for deletion.
        All paths are deleted recursively.

        Parameters
        ----------
        path:
            Path(s) of the file(s) or folder(s) to delete.
        kwargs:
            Additional keyword arguments for future proofing.
        """
        paths = [path] if isinstance(path, str) else path

        paths_to_delete_per_catalog_id: Dict[str, Set[str]] = defaultdict(set)
        catalog_items_to_delete: Set[str] = set()
        for catalog_id, internal_path in (self._split_path(p) for p in paths):
            if internal_path:
                paths_to_delete_per_catalog_id[catalog_id].add(internal_path)
            else:
                catalog_items_to_delete.add(catalog_id)

        with self._try_convert_to_fsspec_exception():
            for catalog_id in catalog_items_to_delete:
                with self._swallow_not_found_errors():
                    FilesExperimental.delete(catalog_id)
            for catalog_id, internal_paths in paths_to_delete_per_catalog_id.items():
                if catalog_id in catalog_items_to_delete:
                    continue  # Already deleted entire catalog item
                with self._swallow_not_found_errors():
                    self._get_files_wrapper_for_folder_id(catalog_id).delete_files(list(internal_paths))

    def rm_file(self, path: Union[str, List[str]], **kwargs: Dict[str, Any]) -> None:
        """
        Delete a file or directory at the given path(s). Completes silently if the file does not exist.

        Parameters
        ----------
        path:
            Path(s) of the file(s) to delete. Paths ending with a forward slash (/) are treated
            as directories and deleted recursively.
        kwargs:
            Additional keyword arguments for future proofing.

        Examples
        --------
        .. code-block:: python

            >>> from datarobot._experimental.fs import DataRobotFileSystem
            >>> fs = DataRobotFileSystem()
            >>> fs.rm_file("dr://696935d6d5a04a752419cf6d/finance/employee-list.csv")

            >>> fs.rm_file([
            ...     "dr://696935d6d5a04a752419cf6d/finance/employee-list.csv",
            ...     "dr://696935d6d5a04a752419cf6d/finance/fy-2024/budgets/Q2_budget_2024.pdf"
            ... ])
        """
        self._rm(path, **kwargs)

    def rm_directory(self, path: Union[str, List[str]], **kwargs: Dict[str, Any]) -> None:
        """
        Recursively delete a directory at the given path(s). Completes silently if the directory does not exist.
        Uses :meth:`rm_file() <datarobot._experimental.fs.file_system.DataRobotFileSystem.rm_file>` internally.

        Soft-deletes catalog item directory when requested. Use :meth:`Files.un_delete()
        <datarobot.models.files.Files.un_delete>` if you need to restore a deleted catalog item.

        Parameters
        ----------
        path:
            One or more directory paths to delete recursively. Paths must end with a forward slash (/) to be treated
            as directories and deleted recursively.
        kwargs:
            Additional keyword arguments for future proofing.

        Raises
        ------
        ValueError:
            If any of the provided paths do not end with a forward slash (/).

        Examples
        --------
        .. code-block:: python

            >>> from datarobot._experimental.fs import DataRobotFileSystem
            >>> fs = DataRobotFileSystem()
            >>> fs.rm_directory("dr://696935d6d5a04a752419cf6d/finance/fy-2024/")

            >>> fs.rm_directory([
            ...     "dr://696935d6d5a04a752419cf6d/finance/fy-2024/",
            ...     "dr://696935d6d5a04a752419cf6d/"
            ... ])
        """
        path = [path] if isinstance(path, str) else path
        if not all(p.endswith("/") for p in path):
            raise ValueError("Paths must end with a forward slash '/' to recursively delete directories.")

        self.rm_file(path, **kwargs)

    def rm(
        self,
        path: Union[str, List[str]],
        recursive: bool = False,
        maxdepth: Optional[int] = None,
        **kwargs: Dict[str, Any],
    ) -> None:
        """
        Delete files or directories. Completes silently if the file or directory does not exist.

        Soft-deletes catalog item directory when requested. Use :meth:`Files.un_delete()
        <datarobot.models.files.Files.un_delete>` if you need to restore a deleted catalog item.
        If all files in a directory are deleted, the directory itself is also deleted implicitly
        as DataRobot file system does not support empty directories.

        Parameters
        ----------
        path:
            One or more file or directory paths to delete. Paths ending with a forward slash (/)
            are treated as directories.
        recursive:
            Whether to recurse into directories when targeting files to delete. If `False` only deletes files
            targeted.
        maxdepth:
            Depth to pass to :meth:`find() <datarobot._experimental.fs.file_system.DataRobotFileSystem.find>`
            and :meth:`glob() <datarobot._experimental.fs.file_system.DataRobotFileSystem.glob>` when targeting
            files for deletion. Used to limit recursion in directories when finding files to delete.
            If `None`, no limit is applied.
        kwargs:
            Additional keyword arguments for future proofing. Passed to :meth:`rm_file()
            <datarobot._experimental.fs.file_system.DataRobotFileSystem.rm_file>`.

        Examples
        --------
        Delete file:

        .. code-block:: python

            >>> from datarobot._experimental.fs import DataRobotFileSystem
            >>> fs = DataRobotFileSystem()
            >>> fs.rm("dr://696935d6d5a04a752419cf6d/finance/employee-list.csv")

        Delete directory recursively:

        .. code-block:: python

            >>> fs.rm("dr://696935d6d5a04a752419cf6d/finance/fy-2024/", recursive=True)

        Delete contents of catalog item folder recursively up to a maximum depth of 2:

        .. code-block:: python

            >>> fs.rm("dr://696935d6d5a04a752419cf6d/", recursive=True, maxdepth=2)

        Delete catalog item folder:

        .. code-block:: python

            >>> fs.rm("dr://696935d6d5a04a752419cf6d/")

        Delete .csv files in a directory and its subdirectories up to a maximum depth of 3:

        .. code-block:: python

            >>> fs.rm("dr://696935d6d5a04a752419cf6d/finance/**/*.csv", recursive=True, maxdepth=3)

        """
        path = [path] if isinstance(path, (str, os.PathLike)) else path

        out: List[FileInfo] = []
        for p in path:
            with self._swallow_not_found_errors():
                if has_magic(p):
                    out += self.glob(p, maxdepth=maxdepth, detail=True, **kwargs).values()
                elif recursive and maxdepth is not None:
                    out += self.find(p, maxdepth=maxdepth, withdirs=False, detail=True, **kwargs).values()
                else:
                    out.append(self.info(p, **kwargs))

        # Filter to just files if non recursive or maxdepth is set (prevents glob from targeting directories)
        if not recursive or maxdepth is not None:
            out = [item for item in out if item["type"] == "file"]

        self.rm_file([item["name"] for item in out], **kwargs)

    def mkdir(self, *args: Iterable[Any], **kwargs: Dict[str, Any]) -> None:
        """Not supported as DataRobotFileSystem does not support empty directories."""
        raise NotImplementedError("mkdir is not supported for DataRobotFileSystem.")

    def makedirs(self, *args: Iterable[Any], **kwargs: Dict[str, Any]) -> None:
        """Not supported as DataRobotFileSystem does not support empty directories."""
        raise NotImplementedError("makedirs is not supported for DataRobotFileSystem.")

    def rmdir(self, *args: Iterable[Any], **kwargs: Dict[str, Any]) -> None:
        """Not supported as DataRobotFileSystem does not support empty directories."""
        raise NotImplementedError("rmdir is not supported for DataRobotFileSystem.")

    def created(self, *args: Iterable[Any], **kwargs: Dict[str, Any]) -> datetime:
        """DataRobotFileSystem does not currently expose file creation timestamp."""
        raise NotImplementedError("created is not supported for DataRobotFileSystem.")

    def modified(self, *args: Iterable[Any], **kwargs: Dict[str, Any]) -> datetime:
        """DataRobotFileSystem does not currently expose file modification timestamp."""
        raise NotImplementedError("modified is not supported for DataRobotFileSystem.")
