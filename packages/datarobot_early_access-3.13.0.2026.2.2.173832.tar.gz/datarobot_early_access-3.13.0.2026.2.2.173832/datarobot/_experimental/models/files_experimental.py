#  Copyright 2025 DataRobot, Inc. and its affiliates.
#
#  All rights reserved.
#
#  DataRobot, Inc. Confidential.
#
#  This is unpublished proprietary source code of DataRobot, Inc.
#  and its affiliates.
#
#  The copyright notice above does not evidence any actual or intended
#  publication of such source code.


"""That's a non-public extension of GA Files model."""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple, TypedDict, Union

from datarobot.enums import DEFAULT_MAX_WAIT, FilesOverwriteStrategy
from datarobot.models.files import File, Files
from datarobot.utils.pagination import unpaginate


class DeletionResult(TypedDict):
    path: str
    numFilesDeleted: int


class FilesExperimental(Files):
    """A not yet documented extension for an existing `Files` entity."""

    def _list_contained_files(
        self,
        file_type: str = "",
        recursive: bool = True,
        prefix: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
        version_id: Optional[str] = None,
    ) -> List[File]:
        """
        Copy of `list_contained_files` to add `prefix` and `recursive` experimental parameters.

        List all individual files within a Files container.

        This method retrieves information about all individual files contained within
        a Files object. This is useful for Files objects that contain multiple files
        or are archives.

        Parameters
        ----------
        file_type:
            Filter results by file type (e.g., 'txt', 'pdf').
        recursive:
            If True, list files recursively within all subdirectories.
        prefix:
            If provided, only list files whose paths start with this prefix.
        limit:
            Maximum number of files to return. Set to 0 for no limit.
        offset:
            Number of files to skip before returning results.
        version_id:
            If provided, retrieve from the specified version instead of the latest version.

        Returns
        -------
        List[File]
            A list of File objects representing individual files within the Files container.
        """
        endpoint = (
            f"{self._path}{self.id}/versions/{version_id}/allFiles/"
            if version_id
            else f"{self._path}{self.id}/allFiles/"
        )
        params: Dict[str, Union[int, str]] = {"offset": offset, "recursive": str(recursive).lower()}

        if file_type:
            params["file_type"] = file_type
        if limit > 0:
            params["limit"] = limit
        if prefix:
            params["prefix"] = prefix

        fetch_all_data = limit == 0
        files_data = (
            list(unpaginate(endpoint, params, self._client))
            if fetch_all_data
            else self._client.get(endpoint, params=params).json()["data"]
        )
        return [File.from_server_data(file_data) for file_data in files_data]

    def _copy(
        self,
        source_path: str | Iterable[str],
        *,
        target: str | None = None,
        target_file: Optional["Files"] = None,
        overwrite: FilesOverwriteStrategy = FilesOverwriteStrategy.RENAME,
        max_wait: int = DEFAULT_MAX_WAIT,
        wait_for_completion: bool = True,
    ) -> "Files":
        """
        Copy of `copy` to add `overwrite` parameter. Copy file(s) and/or folder(s) within
        the same or into another files container.

        Parameters
        ----------
        source_path:
            file(s) and/or folder(s) to copy.
        target:
            Either a folder to copy file(s) into
            or a new file name if only one file is being copied.
        target_file:
            Files collection to copy files into.
        overwrite:
            Strategy to handle naming conflicts at the target location.
        max_wait:
             Raise TimeoutError if the operation took more than this number of seconds to complete.
        wait_for_completion:
            Whether to wait for the copy operation to complete before returning.
        """
        if isinstance(source_path, str):
            sources = [source_path]
        elif isinstance(source_path, Iterable):
            sources = list(source_path)
        else:
            raise ValueError(source_path)

        url = f"files/{self.id}/copyBatch/"
        response = self._client.post(
            url,
            json={
                "sources": sources,
                "target": target,
                "targetCatalogId": target_file and target_file.id,
                "overwrite": overwrite.value,
            },
        )
        return self._get_files_from_async(response, max_wait=max_wait, wait_for_completion=wait_for_completion)

    def copy_within_container(
        self,
        source_path: str,
        target_path: str,
        overwrite: FilesOverwriteStrategy = FilesOverwriteStrategy.RENAME,
    ) -> FilesExperimental:
        """
        Copy a file or folder to another path within the same container.

        Parameters
        ----------
        source_path:
            The path of the source file or folder to copy.
        target_path:
            The destination path where the file or folder should be copied.
        overwrite:
            Strategy to handle naming conflicts at the target location.
        """
        url = f"files/{self.id}/copy/"
        response = self._client.post(
            url,
            json={
                "source": source_path,
                "target": target_path,
                "overwrite": overwrite.value,
            },
        )
        return self.from_location(f"catalogItems/{response.json()['catalogId']}/")

    def delete_files(self, paths: List[str]) -> Tuple[FilesExperimental, List[DeletionResult]]:
        """
        Recursively delete files or folders at the given paths. Silently ignore paths that do not exist.

        Parameters
        ----------
        paths:
            List of file or folder paths to delete. Folders are deleted recursively.

        Returns
        -------
        Tuple[FilesExperimental, List[DeletionResult]]
            The updated FilesExperimental object and a list of results for each path indicating the number of
            files deleted that path was responsible for.
        """
        url = f"files/{self.id}/allFiles/"
        response = self._client.delete(url, json={"paths": paths})
        resp_body = response.json()
        return self.from_location(f"catalogItems/{resp_body['catalogId']}/"), resp_body["results"]
