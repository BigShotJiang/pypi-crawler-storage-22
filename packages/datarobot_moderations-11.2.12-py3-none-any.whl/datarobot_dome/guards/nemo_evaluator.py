#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
from functools import cached_property
from typing import Optional

import requests
from nemo_microservices import AsyncNeMoMicroservices
from nemo_microservices.types import EvaluationConfigParam
from nemo_microservices.types import EvaluationTargetParam
from nemo_microservices.types import LiveEvaluation
from nemo_microservices.types import MetricConfigParam
from nemo_microservices.types import TaskConfigParam

from datarobot_dome.constants import GuardLLMType
from datarobot_dome.guard_helpers import get_datarobot_endpoint_and_token

from .base import Guard


class NeMoEvaluatorGuard(Guard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self.nemo_evaluator_type = config["nemo_evaluator_type"]
        self._llm_type = config["llm_type"]
        self.llm_deployment_id = config.get("deployment_id")
        self.llm_gateway_model_id = config.get("llm_gateway_model_id")

    @cached_property
    def _client(self) -> AsyncNeMoMicroservices:
        """
        Using localhost for development purpose only.
        It will be replaced with url to a deployed NeMo evaluator instance later in the PBMP.
        """
        return AsyncNeMoMicroservices(base_url="http://localhost:8080")

    @staticmethod
    def _get_default_model_id(deployment_id: str) -> str:
        """Get id of first model as default from a deployment that responds to /models endpoint."""
        datarobot_endpoint, datarobot_api_token = get_datarobot_endpoint_and_token()
        response = requests.get(
            f"{datarobot_endpoint}/deployments/{deployment_id}/directAccess/models",
            headers={"Authorization": f"Bearer {datarobot_api_token}"},
        )
        if response.status_code != 200:
            raise ValueError(f"Unable to query for default model for deployment {deployment_id}")
        try:
            return response.json()["data"][0]["id"]
        except (requests.JSONDecodeError, KeyError, IndexError, TypeError):
            raise ValueError(f"Unable to select default model for deployment {deployment_id}")

    @cached_property
    def llm_judge_api_endpoint(self) -> dict:
        """LLM Judge API endpoint, to be passed to NeMo evaluator."""
        datarobot_endpoint, datarobot_api_token = get_datarobot_endpoint_and_token()
        if self.llm_type == GuardLLMType.DATAROBOT:
            url = f"{datarobot_endpoint}/deployments/{self.llm_deployment_id}/chat/completions"
            model_id = self._get_default_model_id(self.llm_deployment_id)
        elif self.llm_type == GuardLLMType.LLM_GATEWAY:
            url = f"{datarobot_endpoint}/genai/llmgw/chat/completions"
            model_id = self.llm_gateway_model_id
        else:
            raise ValueError(
                f"LLM type {self.llm_type} is not supported by NeMo Evaluator based guards."
            )
        return {"url": url, "api_key": datarobot_api_token, "model_id": model_id}

    def has_average_score_custom_metric(self) -> bool:
        return False

    async def evaluate(
        self,
        *,
        prompt: Optional[str],
        response: Optional[str],
        retrieved_contexts: Optional[list[str]],
    ) -> float:
        raise NotImplementedError

    def _extract_score(self, evaluation: LiveEvaluation) -> int | float:
        task = evaluation.result.tasks[self.nemo_evaluator_type]
        metric = task.metrics[self.nemo_evaluator_type]
        score = metric.scores[self.nemo_evaluator_type]
        return score.value


class NeMoLLMJudgeGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self.nemo_llm_judge_config = config.get("nemo_llm_judge_config", {})

    async def evaluate(self, *, prompt: str, response: str, **kwargs) -> float:
        system_prompt = self.nemo_llm_judge_config["system_prompt"]
        user_prompt = self.nemo_llm_judge_config["user_prompt"]
        score_parsing_regex = self.nemo_llm_judge_config["score_parsing_regex"]

        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type="llm-judge",
                            params={
                                "model": {"api_endpoint": self.llm_judge_api_endpoint},
                                "template": {
                                    "messages": [
                                        {"role": "system", "content": system_prompt},
                                        {"role": "user", "content": user_prompt},
                                    ]
                                },
                                "scores": {
                                    self.nemo_evaluator_type: {
                                        "type": "int",
                                        "parser": {"type": "regex", "pattern": score_parsing_regex},
                                    }
                                },
                            },
                        )
                    },
                )
            },
        )
        target = EvaluationTargetParam(
            type="rows", rows=[{"promptText": prompt, "responseText": response}]
        )
        evaluation = await self._client.evaluation.live(config=config, target=target)
        return self._extract_score(evaluation)


class NeMoContextRelevanceGuard(NeMoEvaluatorGuard):
    async def evaluate(self, *, prompt: str, retrieved_contexts: list[str], **kwargs) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                            },
                        )
                    },
                )
            },
        )
        target = EvaluationTargetParam(
            type="rows",
            rows=[{"user_input": prompt, "retrieved_contexts": retrieved_contexts}],
        )
        evaluation = await self._client.evaluation.live(config=config, target=target)
        return self._extract_score(evaluation)


class NeMoResponseGroundednessGuard(NeMoEvaluatorGuard):
    async def evaluate(self, *, response: str, retrieved_contexts: list[str], **kwargs) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                            },
                        )
                    },
                )
            },
        )
        target = EvaluationTargetParam(
            type="rows",
            rows=[{"response": response, "retrieved_contexts": retrieved_contexts}],
        )
        evaluation = await self._client.evaluation.live(config=config, target=target)
        return self._extract_score(evaluation)


class NeMoTopicAdherenceGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self.nemo_topic_adherence_config = config["nemo_topic_adherence_config"]

    async def evaluate(self, *, prompt: str, response: str, **kwargs) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                                "metric_mode": self.nemo_topic_adherence_config["metric_mode"],
                            },
                        )
                    },
                )
            },
        )
        target = EvaluationTargetParam(
            type="rows",
            rows=[
                {
                    "user_input": [
                        {"content": prompt, "type": "human"},
                        {"content": response, "type": "ai"},
                    ],
                    "reference_topics": self.nemo_topic_adherence_config["reference_topics"],
                }
            ],
        )
        evaluation = await self._client.evaluation.live(config=config, target=target)
        return self._extract_score(evaluation)


class NeMoAgentGoalAccuracyGuard(NeMoEvaluatorGuard):
    async def evaluate(self, *, prompt: str, response: str, **kwargs) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                                "use_reference": False,
                            },
                        )
                    },
                )
            },
        )
        target = EvaluationTargetParam(
            type="rows",
            rows=[
                {
                    "user_input": [
                        {"content": prompt, "type": "human"},
                        {"content": response, "type": "ai"},
                    ],
                }
            ],
        )
        evaluation = await self._client.evaluation.live(config=config, target=target)
        return self._extract_score(evaluation)


class NeMoResponseRelevancyGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self.response_relevancy_config = config["nemo_response_relevancy_config"]

    @cached_property
    def embedding_judge_api_endpoint(self) -> dict:
        """Embedding judge API endpoint, to be passed to NeMo evaluator."""
        datarobot_endpoint, datarobot_api_token = get_datarobot_endpoint_and_token()
        deployment_id = self.response_relevancy_config["embedding_deployment_id"]
        url = f"{datarobot_endpoint}/deployments/{deployment_id}/directAccess/nim/v1/"
        return {"url": url, "api_key": datarobot_api_token, "model_id": ""}

    async def evaluate(
        self, *, prompt: str, response: str, retrieved_context: Optional[list[str]]
    ) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                                "judge_embeddings": {
                                    "model": {"api_endpoint": self.embedding_judge_api_endpoint},
                                },
                            },
                        )
                    },
                )
            },
        )
        row = {"user_input": prompt, "response": response}
        if retrieved_context:
            row["retrieved_contexts"] = retrieved_context
        target = EvaluationTargetParam(type="rows", rows=[row])
        evaluation = await self._client.evaluation.live(config=config, target=target)
        return self._extract_score(evaluation)


class NeMoFaithfulnessGuard(NeMoEvaluatorGuard):
    async def evaluate(self, *, prompt: str, response: str, retrieved_contexts: list[str]) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                            },
                        )
                    },
                )
            },
        )
        row = {"user_input": prompt, "response": response, "retrieved_contexts": retrieved_contexts}
        target = EvaluationTargetParam(type="rows", rows=[row])
        evaluation = await self._client.evaluation.live(config=config, target=target)
        return self._extract_score(evaluation)
