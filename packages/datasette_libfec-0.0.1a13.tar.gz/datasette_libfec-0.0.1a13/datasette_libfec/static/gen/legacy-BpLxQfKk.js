import{X as a}from"./disclose-version-DiIh0JU6.js";a();
