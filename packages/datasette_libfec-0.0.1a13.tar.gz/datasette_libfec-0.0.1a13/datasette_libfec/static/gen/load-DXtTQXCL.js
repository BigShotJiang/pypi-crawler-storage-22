function e(){const t=document.querySelector("#pageData");if(!t)throw new Error("Page data script not found");return JSON.parse(t.textContent||"{}")}export{e as l};
