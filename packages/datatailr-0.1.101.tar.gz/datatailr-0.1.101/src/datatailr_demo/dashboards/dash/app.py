# *************************************************************************
#  *
#  * Copyright (c) 2026 - Datatailr Inc.
#  * All Rights Reserved.
#  *
#  * This file is part of Datatailr and subject to the terms and conditions
#  * defined in 'LICENSE.txt'. Unauthorized copying and/or distribution
#  * of this file, in parts or full, via any medium is strictly prohibited.
#  *************************************************************************

"""
Minimal Dash app used to verify that datatailr_run_app.py can start a
WSGI application via gunicorn.
"""

from dash import Dash, html


app = Dash(__name__)
app.layout = html.Div("Hello from Dash app runner test")

# Expose the underlying WSGI callable for gunicorn.
server = app.server

if __name__ == "__main__":
    app.run(debug=True)
