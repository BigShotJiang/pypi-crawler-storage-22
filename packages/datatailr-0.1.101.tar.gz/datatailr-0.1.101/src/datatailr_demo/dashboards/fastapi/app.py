# *************************************************************************
#  *
#  * Copyright (c) 2026 - Datatailr Inc.
#  * All Rights Reserved.
#  *
#  * This file is part of Datatailr and subject to the terms and conditions
#  * defined in 'LICENSE.txt'. Unauthorized copying and/or distribution
#  * of this file, in parts or full, via any medium is strictly prohibited.
#  *************************************************************************

"""
Minimal FastAPI app used to verify that datatailr_run_app.py can start
an ASGI application via uvicorn.
"""

from fastapi import FastAPI


app = FastAPI()


@app.get("/")  # pragma: no cover - manual test
def read_root() -> dict[str, str]:
    return {"framework": "fastapi"}
