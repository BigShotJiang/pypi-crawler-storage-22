# *************************************************************************
#  *
#  * Copyright (c) 2026 - Datatailr Inc.
#  * All Rights Reserved.
#  *
#  * This file is part of Datatailr and subject to the terms and conditions
#  * defined in 'LICENSE.txt'. Unauthorized copying and/or distribution
#  * of this file, in parts or full, via any medium is strictly prohibited.
#  *************************************************************************

"""
Minimal Flask app used to verify that datatailr_run_app.py can start a
WSGI application via gunicorn.
"""

from flask import Flask


app = Flask(__name__)


@app.route("/")
def index() -> str:  # pragma: no cover - manual test
    return "Hello from Flask app runner test"
