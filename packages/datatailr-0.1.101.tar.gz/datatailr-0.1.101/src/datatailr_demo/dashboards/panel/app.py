# *************************************************************************
#  *
#  * Copyright (c) 2026 - Datatailr Inc.
#  * All Rights Reserved.
#  *
#  * This file is part of Datatailr and subject to the terms and conditions
#  * defined in 'LICENSE.txt'. Unauthorized copying and/or distribution
#  * of this file, in parts or full, via any medium is strictly prohibited.
#  *************************************************************************

"""
Minimal Panel app used to verify that datatailr_run_app.py can start a
Panel application via the `panel serve` CLI.
"""

import panel as pn
import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta


pn.extension("perspective")
df_stream = pd.DataFrame(np.random.randn(400, 4), columns=list("ABCD")).cumsum()

stream_perspective = pn.pane.Perspective(
    df_stream,
    plugin="d3_y_line",
    columns=["A", "B", "C", "D"],
    theme="material-dark",
    sizing_mode="stretch_width",
    height=500,
    margin=0,
)

stream_perspective.servable()
rollover = pn.widgets.IntInput(name="Rollover", value=500)


def stream():
    data = df_stream.iloc[-1] + np.random.randn(4)
    stream_perspective.stream(data, rollover.value)


cb = pn.state.add_periodic_callback(stream, 50)

pn.Row(cb.param.period, rollover)

N = 9_000

data_1 = {
    "int": [random.randint(-10, 10) for _ in range(N)],
    "float": [random.uniform(-10, 10) for _ in range(N)],
    "date": [(datetime.now() + timedelta(days=i)).date() for i in range(N)],
    "datetime": [(datetime.now() + timedelta(hours=i)) for i in range(N)],
    "category": [
        "Category A",
        "Category B",
        "Category C",
        "Category A",
        "Category B",
        "Category C",
        "Category A",
        "Category B",
        "Category C",
    ]
    * 1_000,
    "link": [
        "https://panel.holoviz.org/",
        "https://discourse.holoviz.org/",
        "https://github.com/holoviz/panel",
    ]
    * 3_000,
}
df_1 = pd.DataFrame(data_1)

pane = pn.pane.Perspective(df_1, width=1200, height=800)
pane.servable()
