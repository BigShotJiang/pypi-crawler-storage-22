from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="datatypical",
    version="0.7.3",
    author="Amanda S. Barnard",
    description="Explainable instance significance discovery for scientific datasets",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/amaxiom/DataTypical",
    project_urls={
        "Bug Tracker": "https://github.com/amaxiom/DataTypical/issues",
        "Documentation": "https://github.com/amaxiom/DataTypical/tree/main/docs",
        "Source Code": "https://github.com/amaxiom/DataTypical",
    },
    py_modules=["datatypical", "datatypical_viz"],  # Changed from packages
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
        "Topic :: Scientific/Engineering :: Chemistry",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20.0",
        "pandas>=1.3.0",
        "scipy>=1.7.0",
        "scikit-learn>=1.0.0",
        "matplotlib>=3.3.0",
        "seaborn>=0.11.0",
        "numba>=0.55.0",
        "networkx>=2.6.0",
        "threadpoolctl>=2.0.0",
        "joblib>=1.0.0",
    ],
    keywords="machine-learning explainable-ai shapley-values data-science biotech nanotechnology",
)