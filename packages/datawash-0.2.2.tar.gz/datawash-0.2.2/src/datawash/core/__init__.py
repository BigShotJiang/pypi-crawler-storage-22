"""Core functionality for datawash."""
