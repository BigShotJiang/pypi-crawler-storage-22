"""Version information for datasnap."""

__version__ = "1.0.0"
