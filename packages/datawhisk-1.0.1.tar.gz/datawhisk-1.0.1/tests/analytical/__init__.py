"""Tests for analytical helpers module."""
