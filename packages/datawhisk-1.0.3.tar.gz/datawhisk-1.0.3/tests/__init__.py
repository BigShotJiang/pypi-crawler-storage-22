"""Test suite for datawhisk library."""

__version__ = "1.0.0"
