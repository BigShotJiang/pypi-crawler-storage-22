import calendar
import re
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import List

import pytz
from dateutil.relativedelta import relativedelta

_utc = pytz.timezone("utc")

# Pre-compiled regexes for performance (avoid recompilation on every call)
_RE_MONTH = re.compile(
    r"([+-])?(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)$", re.IGNORECASE
)
_RE_WEEKDAY = re.compile(r"([+-])?(su|mo|tu|we|th|fr|sa)$", re.IGNORECASE)
_RE_PERIOD = re.compile(
    r"([+-])?P([0-9]+Y)?([0-9]+Q)?([0-9]+M)?([0-9]+W)?([0-9]+D)?(T([0-9]+H)?([0-9]+M)?([0-9]+S|[0-9]+\.[0-9]+S)?)?$"
)
_RE_DATETIME = re.compile(
    r"^([1-9][0-9]{3})(-([0-1][0-9])(-([0-3][0-9])?)?)([T|\s]([0-2][0-9])((:([0-5][0-9])(:([0-5][0-9])(\.[0-9]+)?)?)?)?\s?([+|\-|Z]?)(([0-1][0-9]):?([0-9][0-9]))?)?$"
)


class DateRange:
    """
    Represents a time span with a start and end datetime.

    The start is inclusive and the end is exclusive, following the standard
    convention for date ranges (half-open interval).
    """

    def __init__(self, start: date | datetime, end: date | datetime):
        """
        Creates a DateRange from start and end dates or datetimes.

        Args:
            start: Start date or datetime (inclusive).
            end: End date or datetime (exclusive).

        If date objects are passed, they are converted to datetimes at midnight.
        Note: datetime is a subclass of date, so we check for datetime first.
        """
        # Check datetime first since datetime is a subclass of date
        if isinstance(start, datetime):
            self.__start = start
        else:
            self.__start = datetime.combine(start, datetime.min.time())

        if isinstance(end, datetime):
            self.__end = end
        else:
            self.__end = datetime.combine(end, datetime.min.time())

    def start_utc(self) -> datetime:
        """Returns the start datetime converted to UTC."""
        return self.__start.astimezone(_utc)

    def end_utc(self) -> datetime:
        """Returns the end datetime converted to UTC."""
        return self.__end.astimezone(_utc)

    def start(self, tz: pytz = None) -> datetime:
        """
        Returns the start datetime, optionally converted to a specific timezone.

        Args:
            tz: Optional timezone to convert to. If None, returns in original timezone.
        """
        return self.__start.astimezone(tz=tz) if tz else self.__start

    def end(self, tz: pytz = None) -> datetime:
        """
        Returns the end datetime, optionally converted to a specific timezone.

        Args:
            tz: Optional timezone to convert to. If None, returns in original timezone.
        """
        return self.__end.astimezone(tz=tz) if tz else self.__end

    def start_date(self, tz: pytz = None) -> date:
        """
        Returns the start as a date (without time), optionally in a specific timezone.

        Args:
            tz: Optional timezone to convert to before extracting date.
        """
        return (self.__start.astimezone(tz=tz) if tz else self.__start).date()

    def end_date(self, tz: pytz = None) -> date:
        """
        Returns the end as a date (without time), optionally in a specific timezone.

        Args:
            tz: Optional timezone to convert to before extracting date.
        """
        return (self.__end.astimezone(tz=tz) if tz else self.__end).date()

    def end_date_inclusive(self, tz: pytz = None) -> date:
        """
        Returns the last date that is fully contained within the range.

        Since the end is exclusive, this returns end_date minus one day.
        Useful for displaying date ranges to users in an inclusive format.

        Args:
            tz: Optional timezone to convert to before extracting date.
        """
        return DateExpr(self.end_date(tz=tz)).advanced("-P1D").date()

    def start_iso8601(self) -> str:
        """Returns the start datetime as an ISO8601 formatted string."""
        return self.__start.strftime("%Y-%m-%dT%H:%M:%S%z")

    def end_iso8601(self) -> str:
        """Returns the end datetime as an ISO8601 formatted string."""
        return self.__end.strftime("%Y-%m-%dT%H:%M:%S%z")

    def duration(self) -> str:
        """
        Returns the duration of the range as an ISO8601 period string.

        Example: "+P1M2D" for 1 month and 2 days.
        """
        return DateExpr(self.__start).duration_to(self.__end)

    def duration_seconds(self) -> float:
        """Returns the duration of the range in seconds."""
        return DateExpr(self.__start).duration_seconds(self.__end)

    def duration_minutes(self) -> float:
        """Returns the duration of the range in minutes."""
        return DateExpr(self.__start).duration_minutes(self.__end)

    def duration_hours(self) -> float:
        """Returns the duration of the range in hours."""
        return DateExpr(self.__start).duration_hours(self.__end)

    def __repr__(self):
        return f"{self.start()} to {self.end()}"


class DateExpr:
    """
    A date expression calculator supporting ISO8601 periods and fluent chaining.

    DateExpr allows calculating dates using period expressions (like P1M, P1Y),
    predefined aliases (@today, @monthly), and chained operations. It correctly
    handles variable-duration periods (months, years) and preserves month-end
    dates when adding months.

    Examples:
        DateExpr("2024-01-15")                    # From ISO8601 date string
        DateExpr("2024-01-15", tz=pytz.UTC)       # With timezone
        DateExpr("@today")                         # Using predefined alias
        DateExpr("2024-01-31").advanced("+P1M")     # Jan 31 + 1 month = Feb 29
        DateExpr("P0M,+P1M,-P1D")                 # End of current month

    Args:
        expression: Date string, datetime, period expression, or alias.
        frequency: Default frequency for advance() and split() operations.
        tz: Timezone for the expression (default: UTC).
        quarters: Custom quarter start months (default: [1, 4, 7, 10]).
    """

    class __month(Enum):
        jan = 1
        feb = 2
        mar = 3
        apr = 4
        may = 5
        jun = 6
        jul = 7
        aug = 8
        sep = 9
        oct = 10
        nov = 11
        dec = 12

    class __weekday(Enum):
        mo = 0
        tu = 1
        we = 2
        th = 3
        fr = 4
        sa = 5
        su = 6

    YEAR = 1
    QUARTER = 2
    MONTH = 3
    WEEK = 4
    DAY = 5
    HOUR = 7
    MINUTE = 8
    SECOND = 9

    # Predefined aliases - keys are lowercase for faster lookup (no .lower() needed)
    _PREDEFINED = {
        # offsets
        "@this_year": "P0Y",
        "@last_year": "P1Y",
        "@next_year": "P0Y,+P1Y",
        "@this_quarter": "P0Q",
        "@last_quarter": "P1Q",
        "@next_quarter": "P0Q,+P1Q",
        "@this_month": "P0M",
        "@last_month": "P1M",
        "@next_month": "P0M,+P1M",
        "@this_date": "P0D",
        "@next_date": "P0D,+P1D",
        "@today": "P0D",
        "@tomorrow": "P0D,+P1D",
        "@yesterday": "P1D",
        # frequencies
        "@daily": "+P1D",
        "@weekly": "+P1W",
        "@bi-weekly": "+P2W",
        "@monthly": "+P1M",
        "@quarterly": "+P3M",
        "@month-end": "P0M,+P1M,-P1D",
        "@month-mid": "P0M,+P1M,+P14D",
        "@semi-annually": "+P6M",
        "@annually": "+P1Y",
        # Week aliases (use P0W for truncation to week start)
        "@this_week": "P0W",
        "@last_week": "P0W,-P1W",
        "@next_week": "P0W,+P1W",
    }

    # No class-level defaults - all instance attributes initialized in __init__
    __slots__ = (
        "_DateExpr__base",
        "_DateExpr__frequency",
        "_DateExpr__is_month_end",
        "_DateExpr__next_segment",
        "_DateExpr__tz",
        "_DateExpr__quarters",
        "_DateExpr__week_start",
    )

    def __init__(
        self,
        expression: str | datetime = None,
        frequency: str = None,
        tz: pytz = None,
        quarters: List[int] = None,
        week_start: int = 0,
        _other: "DateExpr" = None,
    ):
        """
        Creates a DateExpr from an expression string, datetime, or alias.

        Args:
            expression: Date string, datetime, period expression, or alias.
            frequency: Default frequency for advance() and split() operations.
            tz: Timezone for the expression (default: UTC).
            quarters: Custom quarter start months (default: [1, 4, 7, 10]).
            week_start: First day of week (0=Monday, 6=Sunday). Default: 0 (Monday, ISO 8601).
                        Use 6 for Sunday-based weeks (US convention).
            _other: Internal parameter for copy().
        """
        # Initialize all instance attributes explicitly
        self.__tz = tz if tz else _utc
        self.__frequency = frequency if frequency else "@daily"
        self.__is_month_end = False
        self.__next_segment = 0
        self.__quarters = quarters if quarters and len(quarters) > 0 else [1, 4, 7, 10]
        self.__week_start = week_start % 7  # Normalize to 0-6
        self.__base = datetime.now().astimezone(self.__tz)

        if _other:
            # Copy all state from other instance
            self.__base = _other.__base
            self.__frequency = _other.__frequency
            self.__tz = _other.__tz
            self.__is_month_end = _other.__is_month_end
            self.__quarters = _other.__quarters
            self.__week_start = _other.__week_start
            self.__next_segment = _other.__next_segment
        elif expression is None:
            # No expression provided, use current time (already set above)
            pass
        else:
            self.__set__(expression)

    def copy(self) -> "DateExpr":
        """
        Creates an independent copy of this DateExpr.

        The copy has the same date, timezone, frequency, and other settings,
        but can be modified without affecting the original.

        Returns:
            A new DateExpr with identical state.
        """
        return DateExpr(_other=self)

    def advance(self, spec: str = None) -> "DateExpr":
        """
        Advances the date in-place by the specified period or the default frequency.

        This method MUTATES the current DateExpr. Use offset() for immutable operations.

        If spec contains semicolons (e.g., "@month-end,-we;@month-end,-fr"), it cycles
        through the options on each call, enabling alternating schedules.

        Args:
            spec: Period expression to advance by. If None, uses the default frequency.

        Returns:
            Self, for method chaining.

        Example:
            expr = DateExpr("2024-01-01", frequency="@monthly")
            expr.advance()  # Now 2024-02-01
            expr.advance()  # Now 2024-03-01
        """
        opt = spec if spec is not None else self.__frequency
        opts = opt.split(";")
        seg = self.__next_segment % len(opts)
        self.__next_segment = (self.__next_segment + 1) % len(opts)
        # self.__next_segment = self.__next_segment % len(opts)
        if opts[seg].startswith("P"):
            return self.__set__("+" + opts[seg])
        else:
            return self.__set__(opts[seg])

    def advanced(self, spec: str) -> "DateExpr":
        """
        Returns a new DateExpr with the specified offset applied.

        This method is IMMUTABLE - it does not modify the current DateExpr.
        Use advance() if you want to modify in-place.

        Args:
            spec: Period expression, date string, or alias to apply.
                  Examples: "+P1M", "-P1D", "@next_month", "2024-06-15"

        Returns:
            A new DateExpr with the offset applied.

        Example:
            today = DateExpr("@today")
            tomorrow = today.advanced("+P1D")  # today is unchanged
            next_month = today.advanced("@next_month")
        """
        p = self.copy().__set__(spec)
        return p

    def truncate_microseconds(self) -> "DateExpr":
        """
        Removes microseconds from the datetime in-place, setting them to zero.

        This method MUTATES the current DateExpr. Use truncated_microseconds()
        for an immutable version.

        Returns:
            Self, for method chaining.
        """
        self.__base = self.__base.replace(microsecond=0)
        return self

    def truncated_microseconds(self) -> "DateExpr":
        """
        Returns a new DateExpr with microseconds set to zero.

        This method is IMMUTABLE - it does not modify the current DateExpr.
        Use truncate_microseconds() if you want to modify in-place.

        Returns:
            A new DateExpr with microseconds removed.
        """
        return self.copy().truncate_microseconds()

    def period(self) -> DateRange:
        """
        Returns a DateRange from the current date to the next frequency interval.

        Uses the default frequency set during construction.

        Returns:
            A DateRange spanning one frequency interval.

        Example:
            expr = DateExpr("2024-01-01", frequency="@monthly")
            rng = expr.period()  # 2024-01-01 to 2024-02-01
        """
        freq = self.__frequency
        if freq.startswith("P"):
            freq = "+" + freq
        return DateRange(self.__base, self.advanced(freq).to_datetime())

    def split(
        self,
        frequency: str = None,
        end: str | datetime | date = "+P3M",
        duration: str = None,
    ) -> List[DateRange]:
        """
        Splits a time span into a list of DateRanges.

        Generates ranges from the current date until the end date.
        Each range has an inclusive start and exclusive end.

        Args:
            frequency: How often to start a new range. Can be:
                       - ISO8601 period: "P1M", "+P1W", "P1D"
                       - Rate format: "2/month", "4/year", "1/day"
                       - None to use the default frequency
            end: When to stop generating ranges. Can be:
                 - Period expression: "+P1Y" (1 year from current date)
                 - Date string: "2024-12-31"
                 - datetime or date object
            duration: Optional duration for each range. When provided, ranges
                      may have gaps between them. Can be:
                      - ISO8601 period: "P1M", "P1W", "P1D"
                      - None for consecutive ranges (default, no gaps)

        Returns:
            List of DateRange objects covering the time span.

        Examples:
            # Consecutive monthly ranges (default)
            expr = DateExpr("2024-01-01")
            ranges = expr.split(frequency="P1M", end="+P3M")
            # Returns 3 monthly ranges: Jan, Feb, Mar

            # 1-month ranges every quarter (with gaps)
            expr = DateExpr("2024-01-01")
            ranges = expr.split(frequency="+P3M", duration="P1M", end="+P1Y")
            # Returns 4 ranges: Jan 1-Feb 1, Apr 1-May 1, Jul 1-Aug 1, Oct 1-Nov 1
        """
        ranges: List[DateRange] = []
        start = self.copy()
        if isinstance(end, str):
            end = self.advanced(end).to_datetime()
        elif isinstance(end, date):
            end = self.__tz.localize(datetime(end.year, end.month, end.day, 0, 0, 0))
        if not frequency or frequency.startswith("+P") or frequency.startswith("P"):
            if frequency:
                start.__frequency = frequency
            while start.to_datetime() < end:
                range_start = start.to_datetime()
                if duration:
                    # Use explicit duration for range length, frequency for interval
                    # Ensure duration has + prefix for addition (not truncation)
                    dur = duration if duration.startswith("+") else "+" + duration
                    range_end = start.advanced(dur).to_datetime()
                    if range_end > end:
                        range_end = end
                    ranges.append(DateRange(range_start, range_end))
                    start.advance()  # Move to next interval start
                else:
                    # Default: consecutive ranges (range ends where next begins)
                    range_end = start.advance().to_datetime()
                    if range_end > end:
                        range_end = end
                    ranges.append(DateRange(range_start, range_end))
        else:
            freq_num = int(frequency.split("/")[0])
            freq_unit = frequency.lower().split("/")[1]
            unit_duration = "+P1M"
            match freq_unit:
                case "day":
                    unit_duration = "+P1D"
                    if freq_num % 4 == 0:
                        freq_num = freq_num // 4
                        unit_duration = "+PT6H"
                    elif freq_num % 3 == 0:
                        freq_num = freq_num // 3
                        unit_duration = "+PT8H"
                    elif freq_num % 2 == 0:
                        freq_num = freq_num // 2
                        unit_duration = "+PT12H"
                case "week":
                    unit_duration = "+P7D"
                case "month":
                    unit_duration = "+P1M"
                case "quarter":
                    unit_duration = "+P3M"
                case "year":
                    unit_duration = "+P1Y"
                    if freq_num % 6 == 0:
                        freq_num = freq_num // 6
                        unit_duration = "+P2M"
                    elif freq_num % 4 == 0:
                        freq_num = freq_num // 4
                        unit_duration = "+P3M"
                    elif freq_num % 3 == 0:
                        freq_num = freq_num // 3
                        unit_duration = "+P4M"
                    elif freq_num % 2 == 0:
                        freq_num = freq_num // 2
                        unit_duration = "+P6M"
            start = start.copy()
            while start.to_datetime() < end:
                interval_start = start.copy()
                interval_end = interval_start.advanced(unit_duration)
                period_days = int(
                    (interval_end.to_datetime() - interval_start.to_datetime()).days
                    / freq_num
                )
                for i in range(freq_num):
                    range_start = interval_start.advanced(
                        f"+P{period_days * i}D"
                    ).to_datetime()
                    range_end = (
                        interval_end.to_datetime()
                        if i == freq_num - 1
                        else interval_start.advanced(
                            f"+P{period_days * (i + 1)}D"
                        ).to_datetime()
                    )
                    if range_start < end:
                        ranges.append(DateRange(range_start, range_end))
                start = start.advance(unit_duration)
        return ranges

    # side-effect!, updates self.__base value
    def __set__(self, spec: str | datetime, in_place: bool = False) -> "DateExpr":
        if isinstance(spec, datetime):
            self.__base = spec
            nextDay = self.__base + relativedelta(days=1)
            self.__is_month_end = nextDay.month != self.__base.month
        elif isinstance(spec, date):
            self.__base = self.__tz.localize(
                datetime(spec.year, spec.month, spec.day, 0, 0, 0)
            )
            nextDay = self.__base + relativedelta(days=1)
            self.__is_month_end = nextDay.month != self.__base.month
        else:
            if not isinstance(spec, str):
                spec = f"{spec}"
            items = spec.split(",")
            parts = []
            for item in items:
                item_lower = item.lower()  # Cache lowercase conversion
                if item_lower == "@now":
                    self.__base = datetime.now().astimezone(self.__tz)
                    parts = []
                elif item_lower in DateExpr._PREDEFINED:
                    parts.extend(DateExpr._PREDEFINED[item_lower].split(","))
                else:
                    if item.startswith("++") or item.startswith("--"):
                        parts.append(item[1:])
                    else:
                        parts.append(item)

            for part in parts:
                self.__base = self.__offset__(part)
                nextDay = self.__base + relativedelta(days=1)
                self.__is_month_end = nextDay.month != self.__base.month
                # print(f"Partial: {self.__base.strftime('%Y-%m-%d %H:%M:%S (%a)')}")

        return self

    def __offset__(self, spec: str) -> datetime:
        newDT = self.__base

        # check for month names (using pre-compiled regex)
        d = _RE_MONTH.search(spec)
        groups = d.groups() if d else None
        if groups and groups[1]:
            mode = groups[0]
            month = DateExpr._DateExpr__month[groups[1].lower()]
            backOffset = (newDT.month + 12 - month.value) % 12
            forwardOffset = (month.value + 12 - newDT.month) % 12
            # When offset is 0 (already in target month), + means next year, - means previous year
            if forwardOffset == 0 and mode == "+":
                forwardOffset = 12
            if backOffset == 0 and mode == "-":
                backOffset = 12
            # Determine direction: explicit mode takes precedence, otherwise use nearest
            if mode == "+":
                newDT = newDT + relativedelta(months=forwardOffset)
            elif mode == "-":
                newDT = newDT + relativedelta(months=-backOffset)
            else:
                # Nearest: use whichever offset is smaller
                newDT = newDT + relativedelta(
                    months=-backOffset if backOffset < forwardOffset else forwardOffset
                )
            return newDT

        # check for day of week names (using pre-compiled regex)
        d = _RE_WEEKDAY.search(spec)
        groups = d.groups() if d else None
        if groups and groups[1]:
            mode = groups[0]
            weekday = DateExpr._DateExpr__weekday[groups[1].lower()]
            backOffset = (newDT.weekday() + 7 - weekday.value) % 7
            forwardOffset = (weekday.value + 7 - newDT.weekday()) % 7
            match mode:
                case "+":
                    newDT = newDT + relativedelta(days=forwardOffset)
                case "-":
                    newDT = newDT + relativedelta(days=-backOffset)
                case _:
                    newDT = newDT + relativedelta(
                        days=-backOffset
                        if backOffset < forwardOffset
                        else forwardOffset
                    )
            return newDT

        # check for P#Y#Q#M#W#DT#H#M#S string (using pre-compiled regex)
        d = _RE_PERIOD.search(spec)
        groups = d.groups() if d else None
        if groups:
            mode = groups[0]
            if groups[DateExpr.YEAR]:
                if mode is None:
                    newDT = newDT.replace(
                        month=1, day=1, hour=0, minute=0, second=0, microsecond=0
                    )
                diff = int(groups[DateExpr.YEAR][:-1])
                newDT = newDT + relativedelta(years=(diff if mode == "+" else -diff))

            group_months = groups[DateExpr.MONTH]
            if groups[DateExpr.QUARTER]:
                diff = int(groups[DateExpr.QUARTER][:-1])
                months = 0
                month = self.__base.month
                while month not in self.__quarters:
                    months += 1
                    month = (month + (1 if mode == "+" else -1) + 12) % 12
                group_months = f"{months + (diff * 3)}M"

            if group_months:
                if mode is None:
                    newDT = newDT.replace(
                        day=1, hour=0, minute=0, second=0, microsecond=0
                    )
                diff = int(group_months[:-1])
                if diff != 0:
                    # cache day of month in case it is incorrect for the new month
                    initDay = newDT.day
                    if initDay > 28:
                        newDT = newDT.replace(day=28)

                    for i in range(diff):
                        newMonth = newDT.month + (1 if mode == "+" else -1)
                        if newMonth < 1:
                            newDT = newDT.replace(year=newDT.year - 1, month=12)
                        elif newMonth > 12:
                            newDT = newDT.replace(year=newDT.year + 1, month=1)
                        else:
                            newDT = newDT.replace(month=newMonth)

                    if self.__is_month_end:
                        # Use calendar.monthrange for O(1) month-end lookup
                        _, last_day = calendar.monthrange(newDT.year, newDT.month)
                        newDT = newDT.replace(day=last_day)
                    else:
                        # Clamp initDay to valid range for the new month
                        _, last_day = calendar.monthrange(newDT.year, newDT.month)
                        newDT = newDT.replace(day=min(initDay, last_day))

            if groups[DateExpr.WEEK]:
                if mode is None:
                    # Truncate to start of week based on week_start setting
                    # Calculate days back to the configured first day of week
                    days_since_week_start = (newDT.weekday() - self.__week_start) % 7
                    newDT = newDT + relativedelta(days=-days_since_week_start)
                    newDT = newDT.replace(hour=0, minute=0, second=0, microsecond=0)
                diff = int(groups[DateExpr.WEEK][:-1]) * 7
                newDT = newDT + relativedelta(days=(diff if mode == "+" else -diff))
            if groups[DateExpr.DAY]:
                if mode is None:
                    newDT = newDT.replace(hour=0, minute=0, second=0, microsecond=0)
                diff = int(groups[DateExpr.DAY][:-1])
                newDT = newDT + relativedelta(days=(diff if mode == "+" else -diff))
            if groups[DateExpr.HOUR]:
                if mode is None:
                    newDT = newDT.replace(minute=0, second=0, microsecond=0)
                diff = int(groups[DateExpr.HOUR][:-1])
                newDT = newDT + relativedelta(hours=(diff if mode == "+" else -diff))
            if groups[DateExpr.MINUTE]:
                if mode is None:
                    newDT = newDT.replace(second=0, microsecond=0)
                diff = int(groups[DateExpr.MINUTE][:-1])
                newDT = newDT + relativedelta(minutes=(diff if mode == "+" else -diff))
            if groups[DateExpr.SECOND]:
                if mode is None:
                    newDT = newDT.replace(second=0, microsecond=0)
                diff = int(Decimal(groups[DateExpr.SECOND][:-1]))
                newDT = newDT + relativedelta(seconds=(diff if mode == "+" else -diff))
                micros = (
                    int(
                        Decimal(groups[DateExpr.SECOND][:-1]) * Decimal(1000000.0)
                        + Decimal(0.05)
                    )
                    % 1000000
                )
                newDT = newDT + relativedelta(
                    microseconds=(micros if mode == "+" else -micros)
                )
        else:
            try:
                # Use pre-compiled datetime regex
                d = _RE_DATETIME.search(spec)
                groups = d.groups() if d else None
                year = int(groups[0])
                month = int(groups[2]) if groups[2] else 1
                day = int(groups[4]) if groups[4] else 1
                hour = int(groups[6]) if groups[6] else 0
                minute = int(groups[9]) if groups[9] else 0
                second = int(groups[11]) if groups[11] else 0
                microsecond = int(
                    (float(f"0{groups[12]}") if groups[12] else 0) * 1000000
                )
                # multiplier = 7 - len(groups[7])
                # microsecond = microsecond * 10**multiplier
                newDT = self.__tz.localize(
                    datetime(year, month, day, hour, minute, second, microsecond)
                )
            except Exception:
                print(
                    f"spec ({spec}) could not be parsed with ([0-9][0-9][0-9][0-9])(-([0-9][0-9])(-([0-9][0-9])?)?)(T([0-9][0-9])(:([0-9][0-9])(:([0-9][0-9])(\\.[0-9]+)?)?)?)?(.*)$"
                )
                try:
                    newDT = datetime.strptime(f"{spec}Z", "%Y-%m-%dT%H:%M:%S%z")
                except Exception as error:
                    print(f"spec ({spec}) could not be parsed: {error}")
        return newDT

    def __repr__(self):
        if self.__base:
            format = (
                "%Y-%m-%d %H:%M:%S.%f %z (%a)"
                if self.__base.microsecond != 0
                else (
                    "%Y-%m-%d (%a)"
                    if self.__base.hour == 0
                    and self.__base.minute == 0
                    and self.__base.second == 0
                    else "%Y-%m-%d %H:%M:%S %z (%a)"
                )
            )
            return self.__base.strftime(format)
        else:
            return None

    def to_datetime(self) -> datetime:
        """
        Returns the internal datetime value.

        This returns the raw datetime without any timezone conversion.
        Use datetime() for timezone-aware output.

        Returns:
            The datetime value in its current timezone.
        """
        return self.__base

    def date(self) -> date:
        """
        Returns the date portion (without time) of the datetime.

        Returns:
            A date object, or None if no date is set.
        """
        if self.__base:
            return self.__base.date()
        else:
            return None

    def datetime(self, tz: pytz = None) -> datetime:
        """
        Returns the datetime converted to the specified timezone.

        Args:
            tz: Timezone to convert to. If None, uses the DateExpr's timezone.

        Returns:
            A timezone-aware datetime in the specified timezone.
        """
        if tz:
            return self.to_datetime().astimezone(tz=tz)
        else:
            return self.to_datetime().astimezone(tz=self.__tz)

    def to_utc(self) -> datetime:
        """
        Returns the datetime converted to UTC.

        Returns:
            A timezone-aware datetime in UTC.
        """
        return self.to_datetime().astimezone(tz=_utc)

    def iso8601(self, tz: pytz = None, with_tzname: bool = False):
        """
        Returns the datetime as an ISO8601 formatted string.

        Args:
            tz: Timezone to convert to before formatting. If None, uses current timezone.
            with_tzname: If True, appends timezone name in brackets (e.g., "[MST]").

        Returns:
            ISO8601 string like "2024-01-15T08:30:00-0700" or
            "2024-01-15T08:30:00-0700[MST]" if with_tzname is True.
        """
        format = (
            "%Y-%m-%dT%H:%M:%S.%f%z" + ("[%Z]" if with_tzname else "")
            if self.__base.microsecond > 0
            else "%Y-%m-%dT%H:%M:%S%z" + ("[%Z]" if with_tzname else "")
        )
        if tz:
            return self.to_datetime().astimezone(tz=tz).strftime(format)
        else:
            return self.to_datetime().strftime(format)

    def to_date_str(self):
        """
        Returns the date as a simple YYYY-MM-DD string.

        Returns:
            Date string like "2024-01-15".
        """
        return self.__base.strftime("%Y-%m-%d")

    def is_month_end(self):
        """
        Checks and updates whether the current date is the last day of its month.

        This method updates internal state used by month arithmetic to preserve
        month-end dates when adding/subtracting months.

        Returns:
            None (updates internal state).
        """
        nextDay = self.__base + relativedelta(days=1)
        self.__is_month_end = nextDay.month != self.__base.month

    def days_in_month(self):
        """
        Returns the number of days in the current month.

        Returns:
            Integer from 28-31.

        Example:
            DateExpr("2024-02-15").days_in_month()  # Returns 29 (leap year)
            DateExpr("2023-02-15").days_in_month()  # Returns 28
        """
        return self.copy().__set__("P0M,+P1M,-P1D").date().day

    def duration_to(self, other=None) -> str:
        """
        Calculates the duration from this date to another as an ISO8601 period string.

        Correctly handles variable-length periods (months, years) by calculating
        the actual calendar difference rather than simple day/second arithmetic.

        Args:
            other: Target date. Can be:
                   - None: uses the default frequency
                   - Period string: "+P1M", "P1Y"
                   - datetime or date object
                   - DateExpr

        Returns:
            ISO8601 duration string like "+P1Y2M3DT4H5M6S".
            Positive if other is after self, negative if before.

        Example:
            DateExpr("2024-01-15").duration_to("2024-03-20")  # "+P2M5D"
        """
        if other is None:
            other = self.advanced(self.__frequency)
        elif isinstance(other, str):
            other = self.advanced(other)
        elif isinstance(other, datetime):
            other = DateExpr(other.strftime("%Y-%m-%dT%H:%M:%S%z"))
        elif isinstance(other, date):
            other = DateExpr(other.strftime("%Y-%m-%d"))
        else:
            other = self.advanced(f"{other}")

        swap = other.datetime() < self.datetime()
        dt0 = other.datetime() if swap else self.datetime()
        dt1 = self.datetime() if swap else other.datetime()

        result = "P"

        # Calculate years directly using relativedelta
        rd = relativedelta(dt1, dt0)
        years = rd.years
        months = rd.months
        days = rd.days

        if years > 0:
            result += f"{years}Y"
        if months > 0:
            result += f"{months}M"
        if days > 0:
            result += f"{days}D"

        # Time components from the relativedelta
        hours = rd.hours
        minutes = rd.minutes
        seconds = rd.seconds
        microseconds = rd.microseconds

        if hours != 0 or minutes != 0 or seconds != 0 or microseconds != 0:
            result += "T"
            if hours != 0:
                result += f"{hours}H"
            if minutes != 0:
                result += f"{minutes}M"
            if seconds != 0 and microseconds == 0:
                result += f"{seconds}S"
            elif microseconds != 0:
                result += f"{seconds}.{microseconds:06d}S"
        elif result == "P":
            result += "T0S"

        return ("-" if swap else "+") + result

    def duration_seconds(self, other=None) -> float:
        """
        Calculates the duration from this date to another in seconds.

        Args:
            other: Target date. Can be:
                   - None: uses the default frequency
                   - Period string: "+P1M", "P1Y"
                   - datetime or date object

        Returns:
            Duration in seconds. Positive if other is after self.

        Example:
            DateExpr("2024-01-01T00:00:00").duration_seconds("+PT1H")  # 3600.0
        """
        if other is None:
            other = self.advanced(self.__frequency)
        elif isinstance(other, str):
            other = self.advanced(other)
        elif isinstance(other, datetime):
            other = DateExpr(other.strftime("%Y-%m-%dT%H:%M:%S%z"))
        elif isinstance(other, date):
            other = DateExpr(other.strftime("%Y-%m-%d"))
        else:
            other = self.advanced(f"{other}")

        return other.datetime().timestamp() - self.datetime().timestamp()

    def duration_minutes(self, other=None) -> float:
        """
        Calculates the duration from this date to another in minutes.

        Args:
            other: Target date (see duration_seconds for accepted types).

        Returns:
            Duration in minutes. Positive if other is after self.
        """
        return self.duration_seconds(other) / 60

    def duration_hours(self, other=None) -> float:
        """
        Calculates the duration from this date to another in hours.

        Args:
            other: Target date (see duration_seconds for accepted types).

        Returns:
            Duration in hours. Positive if other is after self.
        """
        return self.duration_seconds(other) / 3600


# DateExpr.update_forward_refs()
