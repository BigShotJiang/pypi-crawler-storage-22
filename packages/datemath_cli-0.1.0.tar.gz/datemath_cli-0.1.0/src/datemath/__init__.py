"""datemath - Natural language date calculations and formatting."""

__version__ = "0.1.0"
