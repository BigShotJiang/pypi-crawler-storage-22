"""datemath CLI - Natural language date calculations."""

import json
import re
from datetime import datetime, timedelta
from typing import Optional

import click
from dateutil import parser as dateparser
from dateutil.relativedelta import relativedelta
import pytz


def parse_duration(text: str) -> relativedelta:
    """Parse natural language duration into relativedelta."""
    text = text.lower().strip()
    
    # Patterns for durations
    patterns = [
        (r"(\d+)\s*y(?:ear)?s?", lambda m: relativedelta(years=int(m.group(1)))),
        (r"(\d+)\s*mo(?:nth)?s?", lambda m: relativedelta(months=int(m.group(1)))),
        (r"(\d+)\s*w(?:eek)?s?", lambda m: relativedelta(weeks=int(m.group(1)))),
        (r"(\d+)\s*d(?:ay)?s?", lambda m: relativedelta(days=int(m.group(1)))),
        (r"(\d+)\s*h(?:our)?s?", lambda m: relativedelta(hours=int(m.group(1)))),
        (r"(\d+)\s*m(?:in(?:ute)?)?s?", lambda m: relativedelta(minutes=int(m.group(1)))),
        (r"(\d+)\s*s(?:ec(?:ond)?)?s?", lambda m: relativedelta(seconds=int(m.group(1)))),
    ]
    
    result = relativedelta()
    for pattern, factory in patterns:
        for match in re.finditer(pattern, text):
            result += factory(match)
    
    if result == relativedelta():
        raise ValueError(f"Could not parse duration: {text}")
    
    return result


def parse_natural_date(text: str, base: Optional[datetime] = None) -> datetime:
    """Parse natural language date expressions."""
    if base is None:
        base = datetime.now()
    
    text = text.lower().strip()
    
    # Handle special keywords
    if text in ("now", "today"):
        return base
    elif text == "yesterday":
        return base - timedelta(days=1)
    elif text == "tomorrow":
        return base + timedelta(days=1)
    
    # Handle "in X" pattern
    in_match = re.match(r"in\s+(.+)", text)
    if in_match:
        delta = parse_duration(in_match.group(1))
        return base + delta
    
    # Handle "X ago" pattern  
    ago_match = re.match(r"(.+)\s+ago", text)
    if ago_match:
        delta = parse_duration(ago_match.group(1))
        return base - delta
    
    # Handle "next/last weekday"
    weekdays = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    for direction in ["next", "last", "this"]:
        for i, day in enumerate(weekdays):
            if text == f"{direction} {day}":
                current_weekday = base.weekday()
                target_weekday = i
                if direction == "next":
                    days_ahead = target_weekday - current_weekday
                    if days_ahead <= 0:
                        days_ahead += 7
                elif direction == "last":
                    days_behind = current_weekday - target_weekday
                    if days_behind <= 0:
                        days_behind += 7
                    return base - timedelta(days=days_behind)
                else:  # this
                    days_ahead = target_weekday - current_weekday
                return base + timedelta(days=days_ahead)
    
    # Fall back to dateutil parser
    try:
        return dateparser.parse(text, fuzzy=True)
    except (ValueError, TypeError):
        raise ValueError(f"Could not parse date: {text}")


def format_output(data: dict, as_json: bool) -> str:
    """Format output as JSON or human-readable."""
    if as_json:
        return json.dumps(data, indent=2, default=str)
    
    lines = []
    for key, value in data.items():
        lines.append(f"{key}: {value}")
    return "\n".join(lines)


@click.group()
@click.version_option()
def main():
    """datemath - Natural language date calculations and formatting."""
    pass


@main.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--tz", "timezone", default=None, help="Timezone (default: local)")
def now(as_json: bool, timezone: Optional[str]):
    """Show current date/time in various formats."""
    if timezone:
        tz = pytz.timezone(timezone)
        dt = datetime.now(tz)
    else:
        dt = datetime.now()
        tz = None
    
    data = {
        "iso": dt.isoformat(),
        "unix": int(dt.timestamp()),
        "date": dt.strftime("%Y-%m-%d"),
        "time": dt.strftime("%H:%M:%S"),
        "human": dt.strftime("%B %d, %Y at %I:%M %p"),
        "weekday": dt.strftime("%A"),
        "timezone": str(tz) if tz else "local",
    }
    click.echo(format_output(data, as_json))


@main.command()
@click.argument("duration")
@click.option("--from", "from_date", default="now", help="Base date (default: now)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def add(duration: str, from_date: str, as_json: bool):
    """Add duration to a date. Example: datemath add "3 weeks" """
    base = parse_natural_date(from_date)
    delta = parse_duration(duration)
    result = base + delta
    
    data = {
        "base": base.isoformat(),
        "duration": duration,
        "result": result.isoformat(),
        "result_human": result.strftime("%A, %B %d, %Y at %I:%M %p"),
    }
    click.echo(format_output(data, as_json))


@main.command()
@click.argument("duration")
@click.option("--from", "from_date", default="now", help="Base date (default: now)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def sub(duration: str, from_date: str, as_json: bool):
    """Subtract duration from a date. Example: datemath sub "2 months" """
    base = parse_natural_date(from_date)
    delta = parse_duration(duration)
    result = base - delta
    
    data = {
        "base": base.isoformat(),
        "duration": duration,
        "result": result.isoformat(),
        "result_human": result.strftime("%A, %B %d, %Y at %I:%M %p"),
    }
    click.echo(format_output(data, as_json))


@main.command()
@click.argument("date1")
@click.argument("date2")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def between(date1: str, date2: str, as_json: bool):
    """Calculate duration between two dates."""
    dt1 = parse_natural_date(date1)
    dt2 = parse_natural_date(date2)
    
    delta = dt2 - dt1
    total_seconds = abs(delta.total_seconds())
    
    days = abs(delta.days)
    weeks = days // 7
    months = days // 30  # Approximate
    years = days // 365  # Approximate
    
    data = {
        "from": dt1.isoformat(),
        "to": dt2.isoformat(),
        "days": days,
        "weeks": round(days / 7, 1),
        "months": round(days / 30.44, 1),
        "years": round(days / 365.25, 2),
        "hours": int(total_seconds // 3600),
        "minutes": int(total_seconds // 60),
        "seconds": int(total_seconds),
        "direction": "future" if delta.days >= 0 else "past",
    }
    click.echo(format_output(data, as_json))


@main.command()
@click.argument("text")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def parse(text: str, as_json: bool):
    """Parse natural language date. Example: datemath parse "next tuesday" """
    result = parse_natural_date(text)
    
    data = {
        "input": text,
        "iso": result.isoformat(),
        "date": result.strftime("%Y-%m-%d"),
        "time": result.strftime("%H:%M:%S"),
        "human": result.strftime("%A, %B %d, %Y at %I:%M %p"),
        "weekday": result.strftime("%A"),
        "unix": int(result.timestamp()),
    }
    click.echo(format_output(data, as_json))


@main.command("format")
@click.argument("date")
@click.option("--fmt", default="%Y-%m-%d", help="strftime format string")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def format_cmd(date: str, fmt: str, as_json: bool):
    """Format a date with custom strftime format."""
    dt = parse_natural_date(date)
    formatted = dt.strftime(fmt)
    
    data = {
        "input": date,
        "format": fmt,
        "result": formatted,
        "iso": dt.isoformat(),
    }
    click.echo(format_output(data, as_json))


@main.command()
@click.argument("date")
@click.option("--from", "from_tz", required=True, help="Source timezone")
@click.option("--to", "to_tz", required=True, help="Target timezone")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def tz(date: str, from_tz: str, to_tz: str, as_json: bool):
    """Convert between timezones."""
    # Parse the date
    dt = parse_natural_date(date)
    
    # Localize to source timezone
    source_tz = pytz.timezone(from_tz)
    target_tz = pytz.timezone(to_tz)
    
    # If naive, assume source timezone
    if dt.tzinfo is None:
        dt = source_tz.localize(dt)
    
    # Convert to target
    result = dt.astimezone(target_tz)
    
    data = {
        "input": date,
        "from_tz": from_tz,
        "to_tz": to_tz,
        "original": dt.isoformat(),
        "converted": result.isoformat(),
        "human": result.strftime("%A, %B %d, %Y at %I:%M %p %Z"),
    }
    click.echo(format_output(data, as_json))


@main.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def zones(as_json: bool):
    """List common timezones."""
    common = [
        "UTC",
        "America/New_York",
        "America/Chicago", 
        "America/Denver",
        "America/Los_Angeles",
        "America/Sao_Paulo",
        "Europe/London",
        "Europe/Paris",
        "Europe/Berlin",
        "Asia/Tokyo",
        "Asia/Shanghai",
        "Asia/Singapore",
        "Asia/Dubai",
        "Australia/Sydney",
        "Pacific/Auckland",
    ]
    
    now = datetime.now(pytz.UTC)
    
    data = {}
    for zone in common:
        tz = pytz.timezone(zone)
        local = now.astimezone(tz)
        data[zone] = local.strftime("%Y-%m-%d %H:%M %Z")
    
    if as_json:
        click.echo(json.dumps(data, indent=2))
    else:
        for zone, time in data.items():
            click.echo(f"{zone:25} {time}")


if __name__ == "__main__":
    main()
