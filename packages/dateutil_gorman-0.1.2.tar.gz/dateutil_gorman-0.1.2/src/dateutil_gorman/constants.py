"""Constants for the Gorman calendar."""

GORMAN_MONTHS = (
    "March",
    "April",
    "May",
    "June",
    "Quintilis",
    "Sextilis",
    "September",
    "October",
    "November",
    "December",
    "January",
    "February",
    "Gormanuary",
)
