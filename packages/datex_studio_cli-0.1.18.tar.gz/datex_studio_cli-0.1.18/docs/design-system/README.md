---
title: Datex Design System
source: https://design.datexuniversity.com
---

# Datex Design System

Local mirror of the [Datex Design System](https://design.datexuniversity.com) documentation.

## Top-Level

- [Design Principles](design-principles.md)
- [Contribute](contribute.md)
- [Getting Started with the Stylesheets](getting-started.md)
- [Release Notes](release-notes.md)
- [Resources](resources.md)
- [Roadmap](roadmap.md)

## Guidelines

- [Our Design Language](guidelines/design-language.md)
- [Voice and Tone](guidelines/voice-and-tone.md)
- [Common UI Text and Microcopy](guidelines/common-ui-text.md)
- [Accessibility](guidelines/accessibility.md)
- [Error Messages](guidelines/error-messages.md)
- [Print Reports](guidelines/print-reports.md)

## Patterns

- [Patterns Overview](patterns/overview.md)
- [Create a New Item](patterns/create-a-new-item.md)
- [Confirm an Action](patterns/confirm-an-action.md)

## Components

- [Components Overview](components/overview.md)
- [Shell](components/shell.md)
- [Blade](components/blade.md)
- [Flyouts](components/flyouts.md)
- [Modal Pop-up](components/modal.md)
- [Forms](components/forms.md)
- [Editor](components/editor.md)
- [Hubs](components/hubs.md)
- [Messages](components/messages.md)
- [Tabs](components/tabs.md)
- [Toolbars](components/toolbars.md)
- [Fieldsets](components/fieldsets.md)
- [Fields](components/fields.md)
- [Dataviews](components/dataviews.md)
- [Grids](components/grids.md)
- [Controls](components/controls.md)
- [Buttons](components/buttons.md)
- [Check Box](components/check-box.md)
- [Toggle](components/toggle.md)
- [Selector Check Box Group](components/selector-check-box-group.md)
- [Selector Radio Button Group](components/selector-radio-button-group.md)
- [Chips Selector](components/chips-selector.md)
- [Select Box](components/select-box.md)
- [Date Box](components/date-box.md)
- [Label](components/label.md)
- [Number Box](components/number-box.md)
- [Text Box](components/text-box.md)
- [Toast Notifications](components/toast-notifications.md)
- [Widgets](components/widgets.md)
