---
title: Blade
source: https://design.datexuniversity.com/Content/Components/Windows/Blade.htm
---

# Blade

## Overview

Blades function as the main workspace of applications to display content like hubs and editors. Multiple blades can be open at once, each with its own breadcrumb along the top of the blade. The design pattern is compared to browser tabs in functionality.

## Usage

Blades should be implemented for:

- **Hubs** -- exposing data and app navigation
- **Editors** -- complex entities requiring multiple fields and tabs
- **Forms** -- creating complex entities

---

*Last Updated: 07/24/2025*
