---
title: Buttons
source: https://design.datexuniversity.com/Content/Components/Controls/Buttons.htm
---

# Buttons

## Overview

Buttons serve as the clear and familiar mechanism for users to initiate actions. They appear frequently in toolbars and query grids, functioning as clickable controls that trigger workflow processes. Buttons can open or close blades and flyouts, modify entity states, or execute any programmed flow action. Contextually, they may be disabled to signal potential future availability or hidden when unnecessary for the current user stage.

## Guidelines and Best Practices

### Layout

- Right-align buttons in dialog boxes and sequential panel workflows
- Left-align buttons for single-page forms and focused tasks
- Position primary buttons leftmost with secondary buttons immediately to the right
- Display only one primary button with inherited theme color at rest; use neutral backgrounds when multiple buttons share equal priority
- Reserve buttons for actions, not navigation (links are appropriate for redirecting); exceptions include wizard "Back" and "Next" buttons
- Avoid default focus on data-destructive buttons; instead emphasize "safe" actions like "Save" or "Cancel"

### Content

- Apply sentence-style capitalization (first word only)
- Ensure clarity about resulting actions; prefer single verbs, adding nouns only when ambiguous
- Examples include "Delete folder" or "Create account"
- Use imperative active voice to minimize word count and enhance scannability

## Custom Style Classes

| Style Class | Purpose | Examples |
|---|---|---|
| Primary | Main call-to-action button representing the most likely user path, displayed in theme color | Process, OK, Yes |
| Secondary | Complementary action providing passive alternatives or path alternatives | Cancel, No, Close |
| Tertiary | Additional positive-action option appearing only alongside existing primary button | Process and Load |
| Destructive | Warning-styled button for irreversible actions; positioned rightmost in flyouts | Delete, Remove |
| Creation | Lighter-styled button indicating new content addition | Add new, Create |
| Link | Minimal-emphasis clickable text suitable for fieldsets | Select shipping address |

---

*Last Updated: 07/24/2025*
