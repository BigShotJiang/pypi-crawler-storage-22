---
title: Check Box
source: https://design.datexuniversity.com/Content/Components/Controls/Check_box.htm
---

# Check Box

## Overview

A check box serves to select or deselect an action item or setting.

### Key Distinction

For binary choices, check boxes differ from toggle switches in purpose: the check box is for status and the toggle switch is for action. The timing also varies -- check box interactions can be delayed (such as within form submissions), whereas toggle switches should activate immediately.

### Usage

Single check boxes work best for binary yes/no scenarios, such as "Remember me?" prompts or terms of service confirmations.

## Guidelines and Best Practices

- Position the label as the "Value" rather than the "Field label"
- Ensure the check box's purpose and current state remain transparent
- Restrict check box text to maximum two lines
- Frame labels as statements where checked equals true and unchecked equals false
- Account for resizing if text content is dynamic
- Avoid placing two check box groups adjacent; use group labels for separation
- Don't employ check boxes as on/off controls or command triggers; use toggle switches instead
- Avoid negative statement labels, which create confusion; use affirmative phrasing

## Resources

- [Microsoft Design Documentation](https://learn.microsoft.com/en-us/windows/apps/design/controls/checkbox)

## Related Components

- **Toggle** -- Similar functionality with different appearance and application

---

*Last Updated: 07/23/2025*
