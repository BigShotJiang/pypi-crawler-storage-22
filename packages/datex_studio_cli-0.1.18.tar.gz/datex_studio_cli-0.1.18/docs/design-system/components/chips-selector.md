---
title: Chips Selector
source: https://design.datexuniversity.com/Content/Components/Controls/Chips_selector.htm
---

# Chips Selector

Chip selectors provide a highly visual way of selecting options.

## Overview

Chip selectors are used to select or deselect one or more filter items from a list of multiple items that a user can choose from.

The default state is all items are selected; the user can deselect items from here.

## Usage

- Chips allow the user to toggle on and off options from a short dynamic list of user-configured items.
- Use when it is important for the user to see all available options.
- If there are more than eight options, use a dropdown.
- Compare with a checkbox: chips give a sense of inclusion / exclusion of a group of similar items; checkboxes give a sense of turning on or off related settings or options.

## Guidelines and Best Practices

- Limit the chip text content to a word or two.
- If the text content is dynamic, consider how the control will resize and what will happen to visuals around it.

## Related Components

- **Check box group** -- multiple selections
- **Radio button group** -- single selection
- **Multi-select box** -- handles 7+ options

---

*Last Updated: 07/23/2025*
