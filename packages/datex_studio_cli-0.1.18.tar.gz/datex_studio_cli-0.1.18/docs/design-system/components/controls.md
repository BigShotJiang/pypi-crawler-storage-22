---
title: Controls
source: https://design.datexuniversity.com/Content/Components/Controls/Controls.htm
---

# Controls

Controls are a collection of simple interaction Components that allow users to make changes to their data.
