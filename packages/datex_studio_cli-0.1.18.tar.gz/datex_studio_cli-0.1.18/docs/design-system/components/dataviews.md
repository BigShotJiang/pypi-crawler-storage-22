---
title: Dataviews
source: https://design.datexuniversity.com/Content/Components/Data_views/Data_view.htm
---

# Dataviews

Dataviews use queries to retrieve and expose entities and their properties through various visualization methods.
