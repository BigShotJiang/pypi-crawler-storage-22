---
title: Date Box
source: https://design.datexuniversity.com/Content/Components/Controls/Date_box.htm
---

# Date Box

Input control to easily enter a date.

---

*Last Updated: 07/24/2025*
