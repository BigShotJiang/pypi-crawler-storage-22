---
title: Editor
source: https://design.datexuniversity.com/Content/Components/Content/Editor.htm
---

# Editor

## Overview

Editors function as Screen views providing users with an enhanced perspective on individual entities while enabling them to manipulate and transform related data.

The component comprises three primary sections: the editor Form, Widgets, and Tabs. Its core function is facilitating entity interaction -- allowing users to explore and modify properties, states, and create or manage related entities.

## Deployment Context

Editors are typically exposed through a Blade Window, but also can be leveraged as Flyouts.

## Design Guidelines

### General Principles

- Use editors when primary intent focuses on editing the main entity; employ hubs alternatively if emphasizing related entity work
- The main entity typically maintains parent/child relationships with tab Dataview entities
- Limit fields, fieldsets, and tabs to maintain focused experiences

### Toolbar Specifications

- Buttons to perform actions on or related to the editor entity should live in the blade toolbar
- Primary actions may receive button style emphasis as the first toolbar element
- Expose common actions for consistency across editors
- Avoid toolbar buttons in flyouts/modals; use modal controls instead

### Form Best Practices

- The first fieldset should be high level data pertaining to the entity being edited such as name / entity code and type
- First fieldset remains unlabeled
- Required fields should appear first or in expanded fieldsets
- Minimize button usage to avoid distraction
- Use field styling conservatively
- Consider title-field/subtitle-field classes for established entities with infrequently-edited identifiers

### Widget Guidance

- Maximum three widgets recommended (two preferred)
- Widgets must demonstrate direct relevance to the editor entity
- Interactive widgets justify inclusion only when adding significant value
- Avoid complexity when editor usage is brief or related entities remain straightforward

### Tabs and Dataviews

- Display only entities related to the primary entity
- Simplify dataviews in flyout editors -- limit columns/fields for proper spacing
- Avoid reports in tabs
- Prioritize concrete entities over conceptual representations
