---
title: Fields
source: https://design.datexuniversity.com/Content/Components/Containers/Fields.htm
---

# Fields

## Overview

Fields offer users a **simple** way to enter data that relies on popular conventions to be **recognizable** to users.

Each field includes a Label indicating its purpose and a Component for user interaction. Fields typically appear within Fieldsets, which group multiple fields together. The system supports various field types depending on the data being collected.

## Usage Contexts

Fields appear in these situations:

- Forms
- Editors
- Hubs
- Messages
- Query grids

## Available Component Types

Fields can utilize these component types:

- Text box
- Number box
- Date box
- Check box
- Option box
- Select box
- Multi-select box

## Field States

Fields can be configured as:

- **Read-only** -- displays data without editing capability
- **Disabled** -- displays data while suggesting editing is possible elsewhere
- **Required** -- shows an asterisk in the label to signal mandatory input

## Additional Styling

Fields receive additional styling from parent elements through Field width styles, Decorative field styles, and Form field styles.

## Related Components

- **Fieldsets** -- contain fields
- **Controls** -- checkboxes, date boxes, labels, multi-select boxes, number boxes, select boxes, and text boxes

---

*Last Updated: 07/23/2025*
