---
title: Fieldsets
source: https://design.datexuniversity.com/Content/Components/Containers/Fieldsets.htm
---

# Fieldsets

## Overview

Fieldsets serve to convey relationships and help organize and declutter forms. All fields within a form are contained in fieldsets. The first fieldset typically appears without a header, though fieldsets can include headers to clarify their purpose and may be configured as collapsible.

## Usage

### Field Width Styles

Field width is applied at the fieldset level to determine column span:

- **double** CSS class: Fields span two columns
- **full** CSS class: Fields span full width

### Decorative Field Styles

- **title-field** CSS class: Top level identification of entity (ex. order class + lookup code)
- **subtitle-field** CSS class: Expand on information from title field

## Guidelines and Best Practices

**General Principles:**
- Related content belongs together in fieldsets
- Use additional fieldsets when containing more than 6 fields
- Collapsible fieldsets maintain visual clarity
- Collapsible fieldsets indicate secondary field nature

**Identifying Information:**
- The first thing you should see on any page is identifying information
- Display entity type and code together (example: "Order 12345")
- Keep identifying information above fieldset titles
- Use title style class for visual hierarchy
- Required empty fields must remain visible in expanded fieldsets
- Maintain fieldset consistency when transitioning from creator to editor forms

**Edit Buttons:**
Buttons for additional content should be always visible or placed within similar content fieldsets.

## Field Info

Field info summarizes collapsed fieldset content with less prominence than fieldset labels. Use sparingly to avoid visual clutter.

Example: "Shipping details > Appointment scheduled 5/6/2025 / Door 5"

## Notes

- Display notes as a single field in its own collapsible fieldset
- Omit label on notes field
- Show notes content as fieldset info when populated to prevent important notes from being overlooked

## Hub Filters

Use fieldset info to indicate applied filters when collapsed, such as "Filters applied: Projects (3), Status (1)"

## Related Components

- **Fields** -- contained within fieldsets
- **Forms** -- contain fieldsets

---

*Last Updated: 07/23/2025*
