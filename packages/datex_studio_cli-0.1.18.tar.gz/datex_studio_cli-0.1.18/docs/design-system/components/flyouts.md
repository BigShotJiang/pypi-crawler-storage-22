---
title: Flyouts
source: https://design.datexuniversity.com/Content/Components/Windows/Flyouts.htm
---

# Flyouts

Temporary view for accomplishing a task within the context of a screen.

## Overview

Flyouts enable users to complete work quickly while remaining contextually connected to their primary task.

The flyout is a temporary content panel triggered from an open blade, overlapping and sharing the same space with it; this allows the user to complete a task or tasks related to or expose additional information about the blade, without ever having to move away from the blade of origin.

**Key Benefits:**
- Provides visual context for flyout content
- Reduces cognitive load by hiding additional content unless required
- Supports left-to-right workflow with a definitive content endpoint (prevents excessive drilling down)

## Usage

Flyouts serve these primary purposes:

- Creating entries on-the-fly while maintaining connection to primary task
- Editing entities and displaying additional information (options configuration, entity details)
- Performing short, single-screen tasks (option configuration, detail specification)
- Quick information access

## Guidelines and Best Practices

### General

User should be in and out -- bottom toolbar actions should close the flyout in addition to performing the associated action (ex. create, save).

### Title

- Explain panel content clearly, concisely, and specifically
- Titles often include the selected element's name
- Keep to one line when possible
- Use sentence-style capitalization (first word only)
- Omit periods from title endings

### Content

- Organize inputs, content, and configuration requirements into sections
- Use fieldsets for grouping related fields
- Avoid paging when possible; consider using a full blade if content exceeds single scrollable view

### Buttons

Flyout toolbars should be limited to a **maximum** of four items (ideally just two), one of each type.

Supported button types:
- Primary
- Secondary
- Tertiary
- Destructive

**Required Button Order:**
1. Primary
2. Tertiary
3. Secondary
4. Destructive (must always be last)

### Sub-level Flyout

Having a sub-level flyout appear on top of a parent flyout is a useful design pattern for displaying nested or contextual information without navigating away from the current view or losing their current context.

**Constraints:**
- Maximum 1 sub-level flyout per task flow
- Back arrow navigation closes sublevel, returns to parent flyout
- Primary action button (typically save/create) closes panel and returns to parent

**Note:** Sub-level flyouts are not currently built-in functionality, but opening a flyout on top of a flyout replicates this functionality sufficiently well for now.

## Resources

- [Fluent UI Panel Documentation](https://developer.microsoft.com/en-us/fluentui#/controls/web/panel#PanelType)

## Related Components

- **Modal** -- uses similar configuration to the flyout

---

*Last Updated: 07/24/2025*
