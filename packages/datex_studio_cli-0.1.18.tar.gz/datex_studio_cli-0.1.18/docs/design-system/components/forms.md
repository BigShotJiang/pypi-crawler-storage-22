---
title: Forms
source: https://design.datexuniversity.com/Content/Components/Content/Forms.htm
---

# Forms

Forms provide a **simple and familiar** way of entering or modifying data with **flexible** formatting.

## Overview

Forms consist of interconnected Fields organized within Fieldsets. Users can designate fields as required to signal mandatory completion. Fields adapt across columns based on viewport dimensions, with options to expand fields across two columns or full width through styling.

## Guidelines and Best Practices

- When a form precedes an editor (such as for new orders), structure fields identically to ensure smooth transitions between creation and editing modes
- Reference both form and fieldset best practices guidance
- Position high-level entity data (name, code, type) in the initial fieldset without a label
- Place required fields primarily in the first fieldset; if logically grouped elsewhere, that fieldset must default to expanded state
- Minimize button usage since buttons disrupt standard field navigation and may become hidden
  - Valid button applications include "Additional options" or "Custom fields" to collapse secondary controls
- Apply field styling conservatively, reserving it for important user information like entity status

## Related Components

- **Fieldsets** -- organize fields into grouped sections
- **Fields** -- form content elements

---

*Last Updated: 07/22/2025*
