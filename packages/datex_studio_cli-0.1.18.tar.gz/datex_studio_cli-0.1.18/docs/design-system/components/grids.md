---
title: Grids
source: https://design.datexuniversity.com/Content/Components/Data_views/Query_grids.htm
---

# Grids

Grids expose query data in the most basic format as rows and columns of text.

## Guidelines and Best Practices

### Data Considerations

Users should not be overwhelmed; excessive columns diminish individual column importance.

**Context-Specific Guidance:**
- Hub grids should display sufficient information for bulk actions or navigation
- Editor grids must show data necessary for identifying and editing rows
- Horizontal scrolling reduces visibility; prioritize immediately visible data
- Modal/flyout displays require limited real estate

**Data Consolidation Examples:**
- Combine weight measurements into single column
- Merge material code with description
- Show actual quantities alongside expected quantities

**Formatting Requirements:**
- Apply text formatting (numeric separators, localized dates)
- Never use system IDs! Use entity names or codes rather than IDs.
- Provide user-friendly data names when database delivery is unclear

### Editable Rows

Complex data should use flyouts or blades rather than inline editing. Hub grids should rarely allow direct row editing; bulk actions occur in modals. Editor grids permit editing when entities are direct children; related entities should use flyouts to maintain hierarchy.

### Adding New Rows

Complex data requires flyouts or blades. Hubs restrict new item creation to flyouts, blades, or modal bulk entry. Editors use modal selectors for existing items or flyouts for new items.

## Column Widths

### Width Options

**Default Styling:**
Table stretches with wider windows, scrolls when smaller. Column headers remain visible at minimum width.

**Set Width Table Styling:**
Fixed table width that scrolls regardless of window size. Ideal for few columns (wave priorities, freight terms) and provides rigidity. Requires width assignment to each column.

**No Scroll Table Styling:**
Columns stretch/shrink to fill 100% of container. Equal width sharing except where specified.

**Fit Content Table Styling:**
Minimum column width matches widest cell content; table scrolls with horizontal overflow.

### Setting Column Widths

Explicit width specification prevents important information cutoff. Notes should allow more space; three-column or fewer grids benefit from set widths at few hundred pixels to reduce visual weight.

## Paging

- Maximum 15 rows per page recommended for user comprehension
- Horizontal scrollbars appear at grid bottom; users scrolling for pagination may miss off-screen columns
- Performance testing (10 vs. 50 results) is essential
- Filters become necessary when results exceed 10 pages
- Aggregation or grouping may reduce result volumes

## Toolbar

Follow toolbar best practices guidance. Grid-related action buttons belong in toolbar, organized logically. Primary buttons should rarely appear; never use multiple primary buttons on same screen. Bulk actions require multi-selection capability with button disabling until selection occurs. Single-item actions can use row options instead.

## Filters

**Acceptable Filter Types:**
- Date boxes (created on, date ranges)
- Slide toggles (error items only)
- Dropdown selectors (status, project)

**Unacceptable Filter Types:**
Text boxes, number boxes, standard checkboxes, labels, text, images, chips, radio buttons.

**DO NOT PUT A BUTTON IN THE FILTERS!**

Limit filters to four most useful options. Labels should be brief (one-two words), contextual, and contextually descriptive. Toggle labels must be short, succinct, and unmistakably clear.

## Rows

### Row Actions

Intended for single-item actions. Hidden until user clicks ellipsis button, so never use for primary actions. Avoid repeating toolbar actions. Labels should start with verbs: "Split pick task," "Duplicate row."

### Errors/Row Icons

Icons (future native support) should be first column with fixed width and no header label. Warning icons use "attention" style; critical issues use "CriticalErrorSolid" icon with "important" style.

## Columns

### Column Styling

Conditional and contextual styling aids user comprehension. Generally style only one column per grid, with entity status as primary example. Exceptions include related columns (log status/message) and planned/inactive rows.

### Buttons

Buttons should rarely, if ever, be used in a grid column. Use text links for navigation, row actions for single-row actions, toolbar buttons with selection for multi-row actions.

### Checkboxes

Read-only grids may use disabled checkboxes. Better alternative: green checkmark icon when true, empty cell when false. Editable grids use active checkboxes. Toggles only in editable grids.

### Labels

Labels should never be used inside a grid column -- use text.

### Selectors

Dropdowns permitted; chips prohibited; radio buttons and checkboxes never used.

## New and Editable Row Controls

- **Text/Number Boxes:** Additional formatting in read-only mode acceptable.
- **Date Box:** Always format read-only text.
- **Checkbox:** Consider immediate action implications versus checkboxes.
- **Button:** Should not be used.
- **Label:** Never inside grid.
- **Text:** For read-only content.
- **Selector:** Dropdowns permitted; chips prohibited; radio buttons/checkboxes never used.
- **Image:** Can persist to show row images.

## Add Row Button

Appears visually where new row appears. Useful when grids contain many rows (toolbar not visible) or few columns with set width. Future enhancement will allow changeable labels ("Add line," "Add order class").

## Expanding Rows/Child Rows

Show related child entities using parent/child relationships. Use rarely and intentionally -- adds significant visual clutter. Primary item rows accommodate many columns; secondary item rows should have few. Preview final grid to ensure usability.

## Custom Style Classes

| Style Class | Purpose | Examples |
|---|---|---|
| Creation | Indicate newly created cell content | New LP, New Lot |
| Attention | Indicate unexpected content or non-breaking issues; pair with Warning icon | Not expected value, Non-breaking issue |
| Important | Indicate significant, dangerous, breaking issues requiring immediate attention; pair with bold error icon | Failure, Error, Offline |
| Status Created | Content in "created" status, unprocessed; lighter grey indicates non-active state | Order created status |
| Status A | First of five consecutive progress styles (red/orange to green); includes progress bar visualization | Processed |
| Status B | Second of five progress styles; includes progress bar visualization | Picked |
| Status C | Third of five progress styles; includes progress bar visualization | Packed, Received |
| Status D | Fourth of five progress styles; includes progress bar visualization | Loaded, Put away |
| Status Complete | Fifth of five progress styles (completion); includes progress bar visualization | Complete, Finished |
| Status Canceled | Content has been canceled | Canceled, Removed, Deleted |
| Planned | Planned/tentative/incomplete content; italics and light grey reduce visual weight | Planned, Expected, Unconfirmed, Notes |
| Edit Item Link | Shows edit icon on hover; clarifies link opens simple editor flyout | Edit configurations/master files, Open editor flyout |

---

*Last Updated: 07/24/2025*
