---
title: Hubs
source: https://design.datexuniversity.com/Content/Components/Content/Hubs.htm
---

# Hubs

## Overview

Hubs function as a **powerful** Screen view that serve as a **jumping-off point** for users to do their job. The component comprises three sections: hub details, Widgets, and Tabs. They leverage Dataviews to expose database information, enabling users to take action or explore data further.

## Guidelines and Best Practices

### General Principles

Hubs should address entities that are related in some way, whether conceptually or directly.

- Maintain a clean interface with maximal 3 widgets (2 recommended)
- Exclude action buttons linking to other modules accessible via main navigation
- Prioritize content based on user needs with minimal scrolling required
- Include search functionality with filters below the hub name, featuring color-highlighted results across all tabs
- Provide concise descriptions beginning with action verbs

### Hub Actions

Action buttons should be removed from hub panels and relocated to blade toolbars to prevent interface clutter.

### Hub Filters

Filters must filter all content of the hub -- that is, the filters apply to all tabs and their Dataview content. Limit filters to approximately 2 maximum for clarity.

### Tabs

Tabs should organize related content at equivalent hierarchy levels. They should:

- Relate directly to the hub title concept
- Display similar content types with different filter applications
- Remain mutually exclusive (one active at a time)
- Avoid forcing users to alternate between views unnecessarily

## Related Resources

- **Editors** -- complement hubs in complementary roles

---

*Last Updated: 07/23/2025*
