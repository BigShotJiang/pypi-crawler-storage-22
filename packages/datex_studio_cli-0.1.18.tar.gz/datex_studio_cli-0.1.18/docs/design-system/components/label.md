---
title: Label
source: https://design.datexuniversity.com/Content/Components/Controls/Label.htm
---

# Label

Short identifier for fields.

---

*Last Updated: 07/23/2025*
