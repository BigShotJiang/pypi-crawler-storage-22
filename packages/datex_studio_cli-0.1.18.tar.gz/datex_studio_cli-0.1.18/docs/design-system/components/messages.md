---
title: Messages
source: https://design.datexuniversity.com/Content/Components/Content/Messages.htm
---

# Messages

## Overview

Messages function as transient and flexible components primarily used within modal pop-ups to convey content. These screen visual components can carry technical details and item lists to Windows, particularly Modal pop-ups and Flyouts, making them suitable for brief or technical information delivery.

Messages may incorporate Fieldsets to request additional user information.

## Usage

- **Error messages** -- Information regarding errors with accompanying technical details
- **Confirmation messages** -- Brief notices informing users of action consequences
- **Informative messages** -- Explanatory content for non-obvious information (example: explaining why an action cannot be performed)

## Guidelines and Best Practices

Messages should appear following significant user actions, verifying intention and consequence awareness. They work best for scenarios requiring user decisions or critical action confirmations. The more critical and less reversible the action, the more attention you should give to the explanation element.

Modal dialogs should be used sparingly -- only when choices or information entry is critical before proceeding. They apply to irreversible or potentially destructive tasks.

### Key Recommendations

- Keep messages brief with plain language; reserve technical details for designated areas
- Limit user input requests to one or two controls; otherwise consider alternative screen types
- Use confirmation modals for critical actions, especially irreversible ones like deletions
- Employ confirmation modals when users attempt leaving pages with unsaved changes
- Verify intentions when users provide input triggering potentially irreversible actions
- Reduce user errors through confirmation modals, but avoid overuse to prevent workflow interruption

## Message Title

Titles should address one primary action for reconfirmation, using simple, clear, unambiguous language. Phrase as binary dichotomous questions with distinguishable options: Yes/No, Stay/Leave, Continue/Go back.

Avoid generic headlines like "Warning," "You are about to," "Do you want to," "The action will," or "Are you sure." Be specific regarding the action.

## Message Description (Optional)

- Omit explanations if the headline suffices
- Add descriptions when actions trigger secondary actions users should understand
- Don't repeat the title in body text
- Use ending punctuation
- Employ actionable language with important information first

**Example scenarios for descriptions:**
- Deleting linked items -- when deletion affects associated items
- Exiting/closing without saving -- clarifying that in-progress work will be lost
- Contradicting actions -- when modifications affect other settings

## Message Buttons

Avoid "Cancel" -- it creates ambiguity about what's being cancelled. Better alternatives include Back, Stay, No, Leave, or Quit.

### Button Placement and Design

- Include two prominent buttons: one confirming action (primary/"Decision") and one dismissing (secondary/"Way out")
- Position primary button left, secondary right
- Make decision buttons visually distinct using primary color; use destructive color for critical/irreversible actions
- Use distinguishable, action-oriented labels showing clearly different options

### Button Labeling

- Add full context, especially on primary buttons
- Match verbs between headline and buttons
- Primary button examples: "Yes," "Confirm," "Accept," "Process," "Proceed"
- Secondary button examples: "No," "Cancel," "Close," "Discard"
- For yes/no questions, add "Yes" before verbs ("Yes, process") or "Anyway" after ("Process anyway")

## Resources

- https://coyleandrew.medium.com/designing-confirmation-278d159723e
- https://polaris.shopify.com/content/actionable-language#confirmations
- https://www.nngroup.com/articles/confirmation-dialog/
- https://www.nngroup.com/articles/modal-nonmodal-dialog/
- https://blog.logrocket.com/ux-design/how-to-design-nondestructive-cancel-buttons/

## Related Components

- **Modal pop-ups** -- Primary window displaying messages
- **Fieldsets** -- Available component within messages

---

*Last Updated: 07/23/2025*
