---
title: Modal Pop-up
source: https://design.datexuniversity.com/Content/Components/Windows/Modal.htm
---

# Modal Pop-up

## Overview

Modal pop-ups demand immediate user attention by blocking forward progress and requiring confirmation to dismiss. They serve two primary purposes: **user confirmation** and **actions**. Confirmation modals convey important information, while action modals provide temporary interfaces for activities within a larger context.

## Usage Categories

### Confirmations

Modal confirmations handle four scenarios:

- **Additional user instruction** -- Requesting supplementary information or guidance about desired actions
- **Confirmation** -- Verifying user intent before committing to requested actions, alerting them to potential consequences
- **Warning** -- Notifying users of possible issues
- **Error** -- Informing users of problems (system or user-caused) with relevant technical details

### Actions

Action modals accommodate transformations, processing, bulk edits, and complex selections performed within parent screen context. They directly relate to displayed data and entities.

**Wizards** also appear in modal pop-ups, enabling complicated multi-step actions.

## Guidelines and Best Practices

### Confirmation Modals

**Content Standards:**
- Keep modals brief and to the point
- Use human-readable language containing details sufficient for understanding if user left and returned hours later
- Identify all affected entities in message text
- Detail action consequences

**Navigation Requirements:**
- Users must always be able to back out of a modal without applying any changes
- Include a secondary button for exit without changes

**Button Organization:**

Buttons follow strict order:
1. Primary (yes, confirm, accept, process, proceed)
2. Tertiary (less common actions; e.g., Plan move, Save and transfer later)
3. Secondary (no, cancel, close)
4. Destructive (always last)

**Button Constraints:**
- Maximum four buttons (one per type)
- Use clear, unconfusable labels (e.g., "Yes"/"No" rather than "Confirm"/"Cancel" for cancellation scenarios)

### Action Modals

**Design Principles:**
- Actions should be transitional, collecting information before changes apply
- Create new actions should not be in a modal pop-up; use flyouts or blades instead
- Avoid extended user engagement -- prohibit complicated hubs, editors, or forms
- No excessive tabs or scrolling required
- Cannot nest modals on modals; use blades instead
- Users must always be able to back out of a modal without applying any changes

## Related Components

- **Flyout** -- uses similar configuration
- **Blade** -- alternative for complex actions

---

*Last Updated: 07/24/2025*
