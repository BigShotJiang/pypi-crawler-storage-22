---
title: Number Box
source: https://design.datexuniversity.com/Content/Components/Controls/Number_box.htm
---

# Number Box

Simple numeric input field.

---

*Last Updated: 07/23/2025*
