---
title: Components
source: https://design.datexuniversity.com/Content/Components/Components.htm
---

# Components

Visual Components are a collection of graphical user interface elements that can be reused across Datex software.
