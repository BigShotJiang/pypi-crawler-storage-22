---
title: Select Box
source: https://design.datexuniversity.com/Content/Components/Controls/Select_box.htm
---

# Select Box

Dropdown for selecting a single option from a list, or multiple options at once.

## Overview

A dropdown selector presents a list of items enabling users to select one or multiple items. The component starts in a compact state and expands to display selectable items. When closed, it either shows the current selection or remains empty if nothing is selected. Upon expansion, the full list of selectable items becomes visible.

## Usage

**When to use:**
- Dynamic situations with unknown, high result counts (greater than eight items)
- Allowing users to select one or more values from a set of single-line text items
- When selection items hold secondary importance in your app's workflow
- When the default option suits most users in typical scenarios, using a dropdown prevents unnecessary attention to options

**Alternative considerations:**
When there are fewer than five items, consider using radio buttons for single selections or check boxes for multiple selections.

## Guidelines and Best Practices

- Restrict dropdown item text to single lines; excessively long strings reduce readability
- Sort items logically: group related options, place common options first, alphabetize names, order numbers numerically, arrange dates chronologically

## Resources

- [Microsoft Windows Apps Design: Combo Box](https://learn.microsoft.com/en-us/windows/apps/design/controls/combo-box)

## Related Components

- **Check box group** -- enables multiple simultaneous selections
- **Radio button group** -- restricts users to single selection
- **Chips selector** -- configurable selection method

---

*Last Updated: 07/23/2025*
