---
title: Selector Check Box Group
source: https://design.datexuniversity.com/Content/Components/Controls/Selector_check_box_group.htm
---

# Selector Check Box Group

A check box enables users to select or deselect action items from a list containing multiple choices.

## Overview

Check box groups represent a selector type that presents multiple options consolidated within a single field.

## Usage

The key distinction between check boxes and radio buttons lies in selection capacity:

- Check boxes allow users to select multiple options simultaneously
- Radio buttons restrict selection to one option from mutually exclusive choices
- Radio buttons are appropriate when multiple options exist but only one selection is permitted

## Guidelines and Best Practices

- Ensure the checkbox's purpose and current state remain transparent to users
- Maintain checkbox text labels on a single line
- Frame labels as statements where a checkmark indicates truth and absence indicates falsehood
- Account for dynamic text content and resulting layout changes
- Limit checkbox groups to seven options. If you have more than seven, consider splitting them into separate groups or explore alternative controls
- Avoid negatively-worded labels that may create confusion
- Arrange options logically (smallest to largest, simplest to complex, or safest to riskiest when data protection is relevant)

## Resources

- [Microsoft Windows Apps Design Documentation](https://learn.microsoft.com/en-us/windows/apps/design/controls/checkbox)

## Related Components

- **Radio button group** -- single selection control
- **Chips selector** -- customizable selection method
- **Multi-select box** -- alternative format for handling more than seven options

---

*Last Updated: 07/23/2025*
