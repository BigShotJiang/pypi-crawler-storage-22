---
title: Selector Radio Button Group
source: https://design.datexuniversity.com/Content/Components/Controls/Selector_radio_button_group.htm
---

# Selector Radio Button Group

## Overview

Radio button groups enable users to choose a single option from multiple mutually exclusive selections. Radio buttons let users select one option from a collection of two or more mutually exclusive, but related, options.

## Key Usage Recommendations

Radio buttons are appropriate when:

- Selecting from two or more mutually exclusive options
- Users benefit from seeing all available choices simultaneously
- Equal attention to all options is desired

## When NOT to Use Radio Buttons

- Binary choices (on/off, yes/no) should use a single checkbox or toggle switch instead
- Never employ two radio buttons for a single binary choice; use a checkbox
- When multiple selections are needed, checkboxes are the better choice
- If there are more than five options available, consider using a dropdown menu

## Guidelines and Best Practices

- Ensure the purpose and current state remain explicit and clear
- Keep text labels to a single line
- Consider how dynamic labels affect button resizing
- Don't put two radio button groups side by side to prevent user confusion about grouping

## Related Components

- **Check box group** -- multiple selections
- **Chips selector** -- configurable selection method
- **Multi-select box** -- handles seven or more options

---

*Last Updated: 07/23/2025*
