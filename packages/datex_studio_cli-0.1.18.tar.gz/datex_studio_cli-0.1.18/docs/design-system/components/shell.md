---
title: Shell
source: https://design.datexuniversity.com/Content/Components/AppShell.htm
---

# Shell

The Shell serves as the top level application container for the interface.

## Components Included

The application shell encompasses two primary elements:

- The app toolbar
- The app navigation

---

*Last Updated: 07/24/2025*
