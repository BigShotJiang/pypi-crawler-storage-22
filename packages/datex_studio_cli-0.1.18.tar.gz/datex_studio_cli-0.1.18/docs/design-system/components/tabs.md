---
title: Tabs
source: https://design.datexuniversity.com/Content/Components/Containers/Tabs.htm
---

# Tabs

Compact collections of queries and their Dataviews.

## Overview

Tabs serve to expose and organize data related to the current screen through Dataviews.

When a tab contains a **query selector**, multiple related Dataviews can be displayed in the same space under a single tab.

### Usage

Tabs are required to show Dataviews, which group information in a visual way. Multiple tabs serve different contexts:

- **Editor context:** Display Dataviews returning information and entities related to the editor entity (example: order lines within an order)
- **Hub context:** Return information relevant to the hub's subject (example: inbound orders in the inbound hub)

Query selectors enable multiple ways to break down tab data, showing two or more similar but distinct Dataviews.

## Guidelines and Best Practices

**Data Requirements:**
- Data exposed through tabs **must be related** to the context of the screen

**Naming Conventions:**
- Tab names should be concise and clear, using full words

**Volume Limitations:**
- Five tabs should be the maximum; additional data belongs on other screens

**Query Selector Guidance:**
- Related Dataviews grouped by query selector typically show different approaches to the same information (example: "Inventory" tab with "By material," "By lot," and "By LP" queries)

**Do's:**
- **Do use a query selector** when your Dataviews are the same content, even when there are no other tabs needed

**Don'ts:**
- **Do not use a query selector** when your Dataviews are unrelated or in an attempt to conserve space

**Prioritization:**
- The first tab should feature the most important and commonly accessed data

**Content Type:**
- Tabs should generally be used to expose tangible related entities, rather than ethereal concepts (ex. LPs and orders rather than tasks or activities)
- Things like forms, editors, hubs, and reports **do not belong in a tab**

## Related Components

- **Dataviews** -- tabs are designed to expose information through Dataviews

---

*Last Updated: 07/23/2025*
