---
title: Text Box
source: https://design.datexuniversity.com/Content/Components/Controls/Text_box.htm
---

# Text Box

Simple text input field.

---

*Last Updated: 07/24/2025*
