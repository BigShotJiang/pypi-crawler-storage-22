---
title: Toast Notifications
source: https://design.datexuniversity.com/Content/Components/Toast_notifications.htm
---

# Toast Notifications

## Overview

Toast notifications serve as a passive communication method to inform users of system feedback without interrupting their workflow. These notifications are typically used to reassure the user that their action had an effect in the system and can convey warnings, errors, or contextual information.

## Usage Decision Framework

**Use toasts when:**
- Issues don't block user progress
- Errors lack criticality to the task
- Urgency is low and immediate action isn't required

**Use pop-ups when:**
- Issues require immediate attention
- User progress is blocked
- High urgency or risk of data loss exists

The core principle: Blocking errors = pop-up. Non-blocking or informative errors = toast.

## Key Guidelines

**Content Requirements:**
- Restrict messages to one or two sentences maximum
- Use minimal wording without punctuation
- Ensure messages are glanceable and immediately comprehensible

**Design Standards:**
- Position in bottom right corner
- Include a close button
- Auto-dismiss timing: 5 seconds plus 1 extra second for every 120 words, rounding up (minimum of 6 seconds)

**Special Consideration:**
Informational toasts may omit auto-dismiss functionality if they provide substantial value users won't encounter routinely throughout their workday.
