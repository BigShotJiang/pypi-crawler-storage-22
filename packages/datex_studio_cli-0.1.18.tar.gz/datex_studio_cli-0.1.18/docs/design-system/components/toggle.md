---
title: Toggle
source: https://design.datexuniversity.com/Content/Components/Controls/Toggle.htm
---

# Toggle

## Overview

The toggle switch functions as a digital representation of a physical on/off switch. Use toggle switch controls to present users with two mutually exclusive options (such as on/off), where choosing an option provides immediate results.

## Core Usage Principles

1. **Immediate System Changes** -- Modifications take effect instantly in the backend or database
2. **Immediate UI Changes** -- The toggle reveals or hides additional interface options
3. **Physical Switch Metaphor** -- Users conceptually "flip" the control to enable/disable functionality

## Labeling Recommendations

Labels should consist of one or two words, preferably nouns, that describe the functionality it controls (e.g., "WiFi" or "Kitchen lights").

Two labeling approaches are supported:
- Setting the label as the control's "Value" field
- Using "Field label" with dynamic "On/Off" or similar state indicators

## Toggle vs. Checkbox Decision Framework

| Scenario | Recommended Control |
|----------|-------------------|
| Binary settings with immediate effect | Toggle |
| Optional/supplementary items | Checkbox |
| Changes requiring additional steps (submit/next button) | Checkbox |
| Multiple related selections | Checkbox |

## Best Practices

- Preserve default "On" and "Off" labels when possible
- Replace labels only when necessary for the toggle switch to make sense
- Avoid custom labels unless the context demands them
