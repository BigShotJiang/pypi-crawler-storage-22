---
title: Toolbars
source: https://design.datexuniversity.com/Content/Components/Containers/Toolbars.htm
---

# Toolbars

## Overview

Toolbars are collections of buttons that provide relevant actions for the current context. They should expose functionality **relevant** to the current context while empowering users without overwhelming them.

These toolbars typically appear above (occasionally below) content like Query grids and expose data-related actions through buttons. They can affect the data itself or how content displays, such as column options or data view switching.

Button visibility follows this pattern: buttons should remain visible but disabled when actions aren't currently available, or be hidden entirely if unsuitable for the current data state.

## Toolbar Types

- **Blade Toolbar** -- appears at blade top for blade-affecting actions
- **Data view Toolbar** -- sits atop data views for data-specific actions
- **Modal Toolbar** -- provides primary modal controls (OK, Cancel)
- **Flyout Toolbar** -- provides primary flyout controls (Confirm, Cancel)

## Key Guidelines

**Button Composition:** Only buttons should be used in toolbars, with the only exception being the Basic filter.

**Safety Practices:** Distance between expected and destructive actions matters; separators should segregate risky operations.

**Quantity Management:** Seven buttons represents an optimal threshold; additional actions should group under overflow menus.

## Button Ordering Structure

Left-to-right positioning follows this hierarchy:

1. **Main actions** -- Primary button first (if exists), then common actions, potentially in chronological sequence
2. **Destructive actions** -- Revert status, Cancel, Delete
3. **Common actions** -- Attachments, Discussions, History, Print, overflow menu
4. **UI configuration** -- Refresh, Column options

## Button Styling

- **Primary:** Only one visible; represents main screen purpose
- **Destructive:** For consequential actions, ideally with confirmation dialogs
- **Creation:** Currently not recommended pending better use cases

## Button States and Separators

Buttons requiring input should remain disabled until conditions met. Separators organize logical button groups and always separate regular from destructive buttons.
