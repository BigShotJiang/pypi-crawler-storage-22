---
title: Widgets
source: https://design.datexuniversity.com/Content/Components/Widgets.htm
---

# Widgets

Widgets provide high-level insight into complex data.

## Overview

Widgets serve several key functions:

- Quickly consumable and actionable components
- Must be glanceable -- users gain maximum value from brief inspection, accessing deeper details only when needed
- Require personalization -- customers control widget content and layout, with expectation that clients review and adjust widgets to display only meaningful information
- Elevate the most useful and relevant information
- Provide top-level overview of information
- Update in real-time with dynamic content refresh based on available context
- Consolidate and concentrate data while linking to richer detail within the screen

## Guidelines and Best Practices

- Maximum of two widgets per screen recommended; three widgets represents the absolute limit
- Widget interaction should filter grid data
- Provide visual feedback during user interaction via hover states

---

*Last Updated: 07/24/2025*
