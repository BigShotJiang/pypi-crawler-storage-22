---
title: Contribute
source: https://design.datexuniversity.com/Content/Contribute.htm
---

# Contribute

Interested in contributing to the Datex Design System? We're just getting started and will need plenty of help!

## Development Contributions

Technical collaborators can enhance the design system's practicality. Contribute code for reusable Component snippets and let us know exactly what you need as a developer.

**Contact:** UXDesign@datexcorp.com (subject: Development contribution to Datex Design System)

## Design Contributions

Ideas, recommendations, or feedback on the design system are more than welcome!

**Contact:** UXDesign@datexcorp.com (subject: Design suggestion for Datex Design System)

---

*Last Updated: 04/21/2025*
