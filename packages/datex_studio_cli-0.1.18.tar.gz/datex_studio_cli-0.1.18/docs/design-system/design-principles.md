---
title: Design Principles
source: https://design.datexuniversity.com/Content/Design_Principles.htm
---

# Design Principles

## Consistency

### Visual consistency

- Shapes, colors, typography, icons
- Follow Microsoft Fluent 2 standards

### Consistency of layout and interactions

- User should know what to expect on a subconscious level
- Improve onboarding and adoption of new screens

## Simplicity / Predictability

- Visual simplicity and lack of clutter
- Foolproof
- Easy to remember flows
- Easy to work as possible
- Progressive disclosure

## Clear Intentions and Outcomes

- Users must always know where they are in the system

## Feedback to the User

- Users should always know if they're doing the right thing, and if it's working
- Users should always be able to understand the error messages they see
