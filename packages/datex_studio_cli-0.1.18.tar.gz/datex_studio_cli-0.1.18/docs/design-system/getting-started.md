---
title: Getting Started with the Stylesheets
source: https://design.datexuniversity.com/Content/Getting_Started.htm
---

# Getting Started with the Stylesheets

## Overview

The Datex Design System is housed in Azure DevOps as a repository within the Datex Development project. Creating a build output generates a distribution folder containing all necessary stylesheets and assets for styling Datex applications.

> **Note:** The component styling generally assumes you are either using the Datex Engine or the Angular Material library; you will need one, both, or a very similar component library to make use of these styles.

## Setup Instructions

### Step 1: Install Dependencies

```
npm run setup
```

### Step 2: Build Production Version

```
npm run build
```

This command creates a `dist` folder containing the generated CSS files.

## What's Included

The design system provides comprehensive styling resources, including:

- General application styling
- Official Datex colors and themes
- Typography/fonts
- Icon assets
- Component styles

All resources align the application with the official Datex user experience standards.
