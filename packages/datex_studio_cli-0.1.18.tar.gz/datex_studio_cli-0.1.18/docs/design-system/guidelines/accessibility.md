---
title: Accessibility
source: https://design.datexuniversity.com/Content/Guidelines/Accessibility.htm
---

# Accessibility

## What does it mean for a product to be accessible?

Accessible products:

- Give every user the same benefits, regardless of ability
- Can adapt to any user in any context

## Who to Include in Our Design Thinking

### Blind Users

#### How they experience an interface

- May use a screen reader to experience interfaces
- May rely on Braille output
- Cannot be expected to use a pointer or mouse for input

#### What designers should think about

- Is visual information translated effectively into text? Can the image be understood through its metadata alone?
- When possible, test all designs through a screen reader.

#### How this applies to everyone

- As audio-only interfaces gain popularity through devices like AI assistants, users are expecting more from audio representations of experiences.

### Low-Vision Users

Low vision can include partial sight in one or both eyes, and range from mild to severe. It affects 246 million people, or about 4% of the world's population.

#### How they experience an interface

- May use screen readers, screen magnifiers, high contrast modes, and/or monochrome displays
- May have their browser font size adjusted to a larger setting
- May not use adaptive technology at all

#### What designers should think about

- Maximize the readability and visual clarity of content.
- Consider how relative proximity of information changes when a page is magnified.
- Follow keyboard guidelines and test with a screen reader to ensure logical reading order.
- The NoCoffee Chrome plugin helps preview websites for various low-vision conditions.

#### How this applies to everyone

- Users without disabilities sometimes need to view screens in poor lighting (e.g., outdoors on bright days).
- Vision declines gradually starting around age 40; improved contrast benefits this demographic.

### Color-Blind Users

Color-blindness affects 8% of all men and 0.4% of women.

#### How they experience an interface

- Will not be able to differentiate between some colors on an interface
- Rely on non-color information to use an interface

#### What designers should think about

- Run your design through a color-blind simulator. If the design doesn't work, try alternatives.
- The Stark plugin (for Sketch) is recommended for testing.
- Review Data Vis color page for data visualization best practices.

#### How this applies to everyone

- All users benefit from thoughtful color application beyond accessibility requirements.

### Deaf and Hard-of-Hearing Users

#### How they experience an interface

- May rely on captioning and other alternative audio representations

#### What designers should think about

- Find alternatives to conveying information exclusively with sound
- Transcribe and caption all videos and animations with meaningful audio

#### How this applies to everyone

- All users benefit from closed captioning in loud environments or when sound is inappropriate.

### Physical Disabilities

#### How users with physical disabilities experience an interface

- May rely on keyboards, track balls, voice recognition, and other assistive technologies
- May not be able to use a mouse or other pointer

#### What designers should think about

- Design for good keyboard interaction; ensure all actions are keyboard accessible and efficient
- Spend one day navigating using only keyboard controls

#### How this applies to everyone

- Many users prefer keyboard navigation for efficiency; good design improves productivity.

### Users with Cognitive Disabilities

Functional cognitive disabilities can include difficulty with:

- Memory
- Problem solving
- Attention
- Reading, linguistic, and verbal comprehension
- Math comprehension
- Visual comprehension

#### How they experience an interface

- May have limited working memory requiring information remain visible throughout task completion
- May experience seizures when exposed to flashing content (epilepsy)

#### What designers should think about

- Understand risks of complex language, animations, and cognitive usability heuristics
- Design linearly, focusing on cognitive load and memory considerations

#### How this applies to everyone

- Cognitive disability best practices benefit all users; reduces mistakes and improves effectiveness.

---

*Last Updated: 07/24/2025*
