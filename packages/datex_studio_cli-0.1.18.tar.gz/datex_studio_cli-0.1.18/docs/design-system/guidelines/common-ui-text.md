---
title: Common UI Text and Microcopy
source: https://design.datexuniversity.com/Content/Guidelines/Common_UI_text.htm
---

# Common UI Text and Microcopy

## General Button Labels / Text

### Create / New / Add

#### New

Opens a creation form in a flyout or another blade.

Examples: "New material" "New customer" "New project"

#### Add

Creates a new child item in a dataview without opening a new flyout/modal/blade, such as adding a new row to a grid or inserting a card into a list.

Examples: "Add line"

#### Create

Confirms and submits the creation of a new item in a flyout or modal view, typically closing the view.

Create / edit forms will replace the "Create" button with a "Save" button once the entity has been created.

Be concise; usually a single verb is best. Include a noun if there is any room for interpretation about what the verb means.

Examples: "Create" -- create a new material, create a new customer

#### Save

Updates the item information with all changed fields, typically closing the view if a flyout.

Create / edit forms will replace the "Create" button with a "Save" button once the entity has been created.

See additional guidance on auto-save.

### Cancel / Discard / Close / Delete / Archive

#### Cancel

1. **Performs "cancel" action on an entity**, typically in a toolbar
   - Destructive button
   - Should include a noun to ensure the action is clear
   - Examples: "Cancel order" "Cancel transfer"

2. **Aborts a process before it takes place**, or cancels a form that might be submitted; typically a command button on a flyout or modal
   - Cannot use "cancel" button to abort a cancellation process (ex. cancel order)
   - Secondary button
   - Examples: "Process order / Cancel"; "Save / Cancel"; "Create / Cancel"

3. **Confirms a cancel action in a confirmation modal pop-up**
   - Essentially same as case 1, but needs to be explicit and the secondary button needs to be clear as well
   - Destructive button
   - Should include a noun to ensure the action is clear
   - Examples: "Cancel order / Don't cancel order" "Cancel transfer / Don't cancel transfer"

#### Close

Closes a flyout or modal view.

Secondary styled button with no other buttons.

Examples: "Close" -- close accessorials, close attachments

#### Delete

Deletes current or selected item(s); no need to include "selected".

Destructive style.

Should prompt a confirmation pop-up.

Examples: "Delete" -- delete account(s), delete form content before creation

#### Archive

Archives current or selected item(s) -- a soft delete.

Destructive style.

Should prompt a confirmation pop-up.

Examples: "Archive" -- archive material, archive customer

### Date Format

Standard/suggested date format:

[written month] [day], [year]

Example: "July 7, 2023"

## FootPrint Terms

### Lookup Code

Lookup code has been revised to [entity] code.

Examples: "Order code" "Account code" "Location code" "Material code"

### Material Concatenation

When referencing a material outside of a material configuration screen, material code and description can be combined:

[material code] - [description]

Examples: "38411154 - RASP Cables Kcl"; "FLPSTK15 - Flapsticks"

### Address Concatenation

[First name] [Last name], [Line 1], [Line 2], [City], [State] [Postal code], [Country]

Omit empty fields and any commas and spaces following them.

Examples: "Rusty Gillespie, 123 Fake Street, Apt. 2, Tampa, FL 33666, USA"; "Rusty Gillespie, 123 Fake Street, Tampa, FL 33666, USA"

### Measurements Concatenation

[length]x[width]x[height] [distance UOM]; [gross weight] [weight UOM]

Should truncate/round to one decimal place to avoid extremely long content.

Examples: "12x12x8 inches; 2 pounds"

### Revert

"Revert status" for clarity.

### UOM

#### Distance/Weight

Ideally auto-populate a default (inches and pounds, for example), keep on same line as the associated data entry, and leave the label blank.

#### Packaging

Use the word "Packaging", not UOM.

## Patterns

Blade and dataview toolbar buttons should not require repeated mention of the entity being affected by the action UNLESS it is not the specific entity being edited/returned.

- "Edit order" "Process order" "Receive order" is redundant

IF a different entity is being affected, review the inclusion of the button (does it belong here?); if it really does, include the noun here.

- Example: "Add inventory" in a list of LPs

IF multiple variations on the same action are available, group them as a sub-menu from the same button.

- Example: "Move" > "Move license plate" / "Move inventory"; "New order" > "New purchase order" / "New sales order"

## Modals / Flyouts / Blades

### Confirmation Modals

#### Title

Poses the situation as a question. Includes context if a single entity is involved.

Examples:
- "Complete purchase order 12345?"
- "Add inventory to an existing outbound order?"
- "Move license plate RG-16854?" / "Move license plates?"

#### Description

Provides clarification of consequences and additional details for the action proposed by the title. Include list of affected entities if more than one is involved.

Examples:
- "Once completed, the order can no longer be changed."
- "The following inventory will be added to the chosen outbound order:
  - 10 box of 38411154 - RASP Cables Kcl
  - 15 each of 56346131 - RASP Tech LCD 22
  - 200 crate of 61546866 - RASP Defibrillator"
- "Move license plate to location R1-Slot 1?" / "Move license plates RG-16854, RG-16855, and RG-16856 to location R1-Slot 1?"

#### Buttons

**Primary** -- Ideally restates the action to be performed. Examples: "Complete order" "Add to order" "Move LP" "Move LPs" "Move inventory" "Change status"

**Tertiary** -- Not common, offers a less frequently used path forward. Examples: "Plan move"

**Secondary** -- Aborts process. Examples: "Cancel" "Don't cancel order"

### Action/Process Modals

#### Title

For simple actions requiring one or two inputs -- poses the situation as a question. For more complex actions/processes, describe the action/process (ex. "Verify container 1234"). Includes context if a single entity is involved.

Examples:
- "Adjust inventory quantity for 38411154 - RASP Cables Kcl?" / "Adjust inventory?"
- "Change status for lot 12347?" / "Change status for selected lots?"

#### Description

Provides clarification of consequences and additional details for the action proposed by the title. Include list of affected entities if more than one is involved (could be listed in a grid if additional input is necessary).

Examples:
- "There are currently 25 cases of 38411154 - RASP Cables Kcl for lot 12345 on license plate RG-16854." / "The following inventory will be adjusted to the updated quantities."
- "All inventory for the lot will be put on hold." / "Lots 12345, 12346, 12347, and 12348 will be changed to the new status, and all inventory for these lots will be put on hold."

#### Buttons

**Primary** -- Ideally restates the action to be performed. Examples: "Adjust quantity" "Change status"

**Tertiary** -- Not common, offers a less frequently used path forward. Examples: "Save and new"

**Secondary** -- Aborts process. Examples: "Cancel"

### Wizard Modals

#### Wizard Title

Describe the action/process. Includes context if a single entity is involved.

#### Wizard Steps

Verb and noun to describe the step. Examples: "Scan items" "Add accessorials" "Print labels"

#### Wizard Control Buttons

- **Back** -- Secondary style
- **Next** -- Primary style
- **Complete / Finish** -- Replaces next on last step, Primary style
- **Cancel** -- Aborts process, should be confirmed by additional pop-up, Secondary style

### Flyouts

#### Flyout Title

Should let the user know what they're doing, optionally giving additional context when available.

Entity creation: New [entity type] for [parent entit(ies) descriptor]

Examples:
- "New material for Medical Supplies LTD. - Default Project"
- "New inventory location for Clearwater"

### Blades

#### Blade Title

[entity] [identifier]

Examples: "LP 123"; "Purchase order 156654"; "Lot 12354"; "Customer Cornelius Cold Storage"

## Resources

- https://uxmovement.com/buttons/5-rules-for-choosing-the-right-words-on-button-labels/
- https://uxplanet.org/primary-secondary-action-buttons-c16df9b36150
- https://ux.stackexchange.com/questions/35753/what-to-call-cancel-when-cancel-is-already-the-default-action
- https://ux.stackexchange.com/questions/9946/should-i-use-yes-no-or-ok-cancel-on-my-message-box
- https://learn.microsoft.com/en-us/windows/win32/uxguide/win-dialog-box
- https://learn.microsoft.com/en-us/windows/win32/uxguide/ctrl-command-buttons#labels
- https://learn.microsoft.com/en-us/windows/win32/uxguide/text-ui
- https://learn.microsoft.com/en-us/windows/apps/design/controls/buttons
- https://uxmovement.com/buttons/when-cancel-buttons-should-not-say-cancel/
- https://ux.stackexchange.com/questions/101406/button-text-for-are-you-sure-you-want-to-cancel-this-order-alert
- https://learn.microsoft.com/en-us/windows/apps/design/style/writing-style
- https://learn.microsoft.com/en-us/style-guide/welcome/

---

*Last Updated: 07/24/2025*
