---
title: Our Design Language
source: https://design.datexuniversity.com/Content/Guidelines/Guidelines.htm
---

# Our Design Language

Guidelines describe the general look, feel, personality, and framework of Datex software.
