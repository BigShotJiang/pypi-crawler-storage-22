---
title: Error Messages
source: https://design.datexuniversity.com/Content/Guidelines/Errors.htm
---

# Error Messages

Succinct, human readable messages that let the user know what is going on, why, and provides them with their next steps.

When something goes wrong in your app, users pay attention. Because users might be confused or frustrated when they encounter an error message, they're an area where good voice and tone can have a particularly significant impact.

More than anything else, it's important that your error message doesn't blame the user. But it's also important not to overwhelm them with information that they don't understand. Most of the time a user who encounters an error just wants to get back to what they were doing as quickly and as easily as they can. Therefore, any error message you write should:

- Be warm and relaxed by using a conversational tone and avoiding unfamiliar terms and technical jargon.
- Be ready to lend a hand by telling the user what went wrong to the best of your ability, by telling them what will happen next, and by providing a realistic solution they can accomplish.
- Be crisp and clear by eliminating extraneous information.

## General Guidelines

### 1. Clarity and Context

- **Explain the Problem Clearly:** Use straightforward language to describe the issue; avoid technical jargon unless absolutely necessary.
- **Actionable Guidance:** Provide clear steps to help users resolve the issue (e.g., "Please fill in the required field.").
- **Professional Tone:** Avoid excessive apologies; maintain a tone that reassures and retains user trust.

### 2. Structure of Error Messages

Follow the following structure for clarity and actionability:

1. **What happened?** State the problem clearly.
2. **Why did it happen?** Offer context (if helpful).
3. **How can it be fixed?** Provide actionable solutions.
4. **What to do next?** Suggest follow-up steps or contact points.

### 3. Tone and Empathy

- **Human and Friendly:** Keep the tone approachable but professional -- avoid robotic or overly formal phrasing.
- **Empathy:** Consider user stress, especially for critical errors; aim for supportive, not accusatory, messaging.

### 4. Design and Accessibility

- **Visual Hierarchy:** Emphasize key information, such as the error type, with font sizes or weights. Ensure secondary details (e.g., code references) are less prominent.
- **Accessibility:** Use high-contrast text, screen reader-friendly formats, and avoid relying solely on color for error indicators.
- **Minimal Interruptions:** Use modals only for critical issues requiring immediate attention. For non-critical errors, prefer inline messages or banners.

### 5. Consistency Across the System

- Maintain uniformity in style, tone, and terminology across all error messages to avoid user confusion.

### 6. Placement and Design Choices

- **Error Placement:** Position inline error messages near the relevant input fields to reduce user effort.
- **Actionable Errors Only:** Suppress messages for non-actionable issues or minor problems that don't require user intervention.
- **Propose Likely Solutions:** Offer realistic and effective solutions, avoiding vague or improbable suggestions.
- **Be Specific:** Avoid vague wording like "syntax error". Include names, locations, or values for clarity.

### 7. Language and Terminology

- **Avoid Blame:** Use passive voice when the issue could be interpreted as the user's fault. Avoid words like "you" and "your" to prevent a blaming tone.
- **Reconsider Common Words:**
  - Replace "error" and "failure" with "problem".
  - Use "unable to" instead of "failed to".
  - Avoid words like "illegal", "invalid", "bad"; instead, use "incorrect" or "not valid".
  - Replace "abort", "kill", "terminate" with "stop".
  - Avoid dramatic terms like "catastrophic" or "fatal"; opt for "serious".

### 8. Other Considerations

- **Action Labels:** Avoid using "OK" for dismissing errors; use more appropriate terms like "Close".
- **Avoid Sounds:** Sound effects accompanying error messages are unnecessary and can irritate users.

## Control Validation Errors

When a user enters information in a control that cannot be validated and removes focus from a control, the following will occur:

- The control border becomes 2px Error Red
- The Error icon is displayed within the control near the right side
- A brief explanation of what has occurred is displayed underneath the control, in small text in Error Red

The control will remain this way until the user corrects the information.

## Local Errors

Local errors occur under expected circumstances but are not limited to validation of any one control, such as attempting to run an invalid query, or entering the incorrect login credentials.

The error appears at the top of the screen, in a wide Error Red box, showing a large Error icon, with an easy to understand explanation of what occurred (including suggested actions when applicable), and any relevant or useful links.

The user can still interact with the API Explorer while an error is displayed.

The error message will remain on the screen until the user closes it using the X button. If there are multiple errors, new errors appear at the top of the screen and push the original error downwards.

## Global Errors

Global errors occur under unexpected circumstances that halt the user's progress. The goal is to provide the user with general information on what occurred and ways to try to solve the issue (typically through contacting us or reporting the problem).

The error appears as a modal pop-up in the middle of the screen, in large box with Error Red borders and accent color, showing a large Status Error Full icon. The text should include a relevant title and, if at all possible, an easy to understand message pertaining to what might have occurred, and any relevant or useful links. A drop-down will reveal full technical details. Buttons at the bottom of the message allow the user to submit a report to us (which includes the details of the error), submit a ticket with support, or to dismiss the error with no further action.

The user is prevented from taking further action within the API Explorer while the error is displayed. The error message will remain on the screen until the user clicks one of the available buttons.

---

*Last Updated: 07/24/2025*
