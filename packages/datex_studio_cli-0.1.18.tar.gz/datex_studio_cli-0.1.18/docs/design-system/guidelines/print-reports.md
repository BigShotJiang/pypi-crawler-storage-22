---
title: Print Reports
source: https://design.datexuniversity.com/Content/Guidelines/Print_reports.htm
---

# Print Reports

## Report Types

The guidelines identify four primary report categories:

**Labels** (e.g., LP label)
- Prioritize high visibility and scannable information
- Feature large, bold text and barcodes
- Maintain consistent, repeatable layout

**Official Documentation** (e.g., invoices, bills of lading)
- Branded, external-facing materials with potential legal implications

**Work Detail** (e.g., pick slips)
- Physical warehouse documents emphasizing essential task information while minimizing distractions

**Inventory/Operations Information** (e.g., receiving reports)
- Broad data compilations suitable for analysis and comparison

## Key Design Principles

### General Standards

- Avoid unnecessary graphics that may interfere with scanning
- Limit color usage without justification
- Implement `.5` inch page margins
- Use `2pt` padding on text elements

### Layout Specifications

- Maintain `.25` inch grid alignment
- Space elements proportionally based on logical relationships
- Use light borders sparingly (`.25pt` in light gray for grouped data)
- Apply borderless tables for layout assistance only

### Typography

- **Heading 1:** Arial, bold, 18pt, sentence case, black
- **Heading 2:** Arial, normal, 14pt, sentence case, dim gray
- **Body:** Arial, normal, 10pt, sentence case, black
- **Numbers:** Courier New, bold
- **Barcodes:** Courier New font

### Field Labels

Position labels above values in 8pt dim gray, without colons. Values appear below in 10pt black.

### Table Standards

- Headers: 1.5pt datex purple bottom border (`#5B08B2`)
- Rows: `.375` inch height with `.25pt` light gray bottom borders
- Maximum seven columns per table
- Left-align text; right-align numeric values when comparison aids analysis
- Related columns positioned adjacently
- Horizontal lines between rows rather than zebra striping

### Footer Elements

Include page counts, execution dates (without seconds), and optional logos in gray text.
