---
title: Confirm an Action
source: https://design.datexuniversity.com/Content/Patterns/Confirm_an_action.htm
---

# Confirm an Action

Ensure the system is doing what the user wants.

## When to Display a Confirmation Dialog

- When the cost of a mistake could be very high
- When there are serious or possibly unintended consequences
- When you need the user to interact before continuing

## When NOT to Use a Confirmation Dialog

- Don't use for routine actions
- Don't use so often that the user stops caring about them
- Try not to use for clarification -- it's better to design actions without ambiguous consequences and assume the most likely desired result

## Design of a Dialog

### General Principles

- A modal pop-up centered on screen, positioned over an overlaid background (white at 75% opacity)
- Indicates to users they must confirm the action to continue
- User actions are restricted to options available in the pop-up
- Divided into four distinct areas: summary, explanation, buttons, and icon
- A clear and concise assertion of what is about to take place
- All information should be valuable and relevant
- Users should understand choices based on title and button text alone
- Remove redundant text
- Don't use "warning" or "caution" in text; use a warning icon instead
- Should only occupy a small portion of the screen
- Avoid using "Learn more" actions for help documentation

### Summary Section

- A clear question or statement in larger font than the explanation
- Use only a single, complete sentence
- Strip the main instruction to essential information
- Be specific with object names; give their full names
- Use positive phrasing, which is easier for users to understand

**Correct example:** "Do you want to enable file and printer sharing?"

**Incorrect example:** "Do you want to disable file and printer sharing?"

**Note:** Phrasing must match the associated command, even if negatively phrased; use "disable" to confirm a Disable command.

### Explanation Section

- Explain the outcome of the action
- Include information useful for users (e.g., list items being deleted)
- Optional; include only if additional details would be helpful
- Should not restate the summary

### Buttons

- Restate the action in the confirmation button
- Default action should be in theme color on the leftmost side
- Secondary action should be on the right side in grey
- Use response options that summarize what will happen for each response, rather than Yes/No
- Encourage users to think about their response with careful phrasing
- Example: "Uninstall anyway" indicates there's reason not to continue
- Ideally include no more than two actions

### Icon

An icon can indicate risk involved, following specific usage standards.

## Additional Guidelines

- Don't use warning icons for routine questions; this makes using the program feel hazardous
- Assume users understand consequences of canceling a task before completion
- Avoid dialogs launching dialogs
- Consider ability to bypass future routine confirmations

## Icon Usage Standards

| Pattern | Icon |
|---------|------|
| Routine confirmations | No icon |
| Risky action confirmations | Warning icon |
| Unintended consequence confirmations | Warning icon if there is risk, otherwise feature icon or no icon |
| Clarifications | Document thumbnail if involved; otherwise feature icon or no icon |
| Security confirmations | Warning icon |
| Ulterior motive confirmations | No icon |

## Default Responses

| Pattern | Default Response |
|---------|------------------|
| Routine confirmations | Proceed |
| Risky action confirmations | Don't proceed if significant consequences; otherwise proceed |
| Unintended consequence confirmations | Confirming a side effect of a user request |
| Clarifications | The most likely response |
| Security confirmations | Don't proceed |
| Ulterior motive confirmations | Proceed |

## Common Summary Phrasing

| Phrase | Connotation |
|--------|-------------|
| Are you sure you want to [perform an action]? | Confirming the direct result of a user request |
| Do you want to [perform an action]? | Confirming a side effect of a user request |
| Would you like to [select a result]? | Need a clarification |
| [Perform an action]? | No connotation |

## Bulk Operations

For confirmations applying to bulk operations, provide an option to apply the confirmation to the entire operation.

## Resources

- [5 Essential UX Rules for Dialog Design - UX Planet](https://uxplanet.org/5-essential-ux-rules-for-dialog-design-4de258c22116)
- [Confirmation Dialogs Can Prevent User Errors -- If Not Overused - Nielsen Norman Group](https://www.nngroup.com/articles/confirmation-dialog/)
- [Confirmations - Windows Design Guidelines](https://docs.microsoft.com/en-us/windows/desktop/uxguide/mess-confirm)

---

*Last Updated: 07/24/2025*
