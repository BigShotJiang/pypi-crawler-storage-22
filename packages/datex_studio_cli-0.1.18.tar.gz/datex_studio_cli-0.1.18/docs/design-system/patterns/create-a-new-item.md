---
title: Create a New Item
source: https://design.datexuniversity.com/Content/Patterns/Create_a_new_item.htm
---

# Create a New Item

Add a new instance of an entity to the database.

## Pattern 1: Quickly Create a Simple Item

**Use Case:** For straightforward items requiring minimal configuration and few fields.

This approach keeps users focused on their primary task by avoiding navigation away from their current context. It's suitable when:

- The new item needs only a few fields
- Multiple configuration tabs aren't required
- Maintaining the user's current position matters

**Typical scenarios include:**
- Creating a new material
- Adding a shipment to an order
- Creating a new warehouse location

**Flow:**

1. User clicks a "New [item]" button (toolbar, dropdown, etc.)
2. A flyout panel opens with the creation form
3. Form includes "Create" and "Cancel" buttons
4. User completes all required fields
5. Clicking "Create" closes the flyout and saves the item
6. Related displayed data refreshes automatically

## Pattern 2: Create a Complicated Item

**Use Case:** For complex items with extensive fields or multiple related data sections.

This pattern dedicates a focused screen to the creation task. Appropriate for items requiring:

- Numerous fields
- Multiple configuration tabs

**Common examples:**
- Creating a new order
- Creating a billing contract
- Setting up an auto-emailing rule

**Flow:**

1. User clicks a "New [item]" button (typically a hub toolbar button)
2. A new blade opens with the creation form
3. Form includes "Cancel"/"Discard" button, optionally "Create"
4. Item either auto-creates when required fields complete or awaits manual creation
5. Creation form blade transitions to an editor blade with consistent layout

---

*Last Updated: 01/15/2026*
