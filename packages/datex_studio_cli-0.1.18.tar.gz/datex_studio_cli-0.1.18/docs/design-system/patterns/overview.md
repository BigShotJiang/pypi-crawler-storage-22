---
title: Patterns
source: https://design.datexuniversity.com/Content/Patterns/Patterns.htm
---

# Patterns

Patterns are the building instructions that allow us to use Components in a logical and consistent way, across all Datex products.
