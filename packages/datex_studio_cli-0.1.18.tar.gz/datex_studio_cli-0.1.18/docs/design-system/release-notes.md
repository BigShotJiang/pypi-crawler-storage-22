---
title: Release Notes
source: https://design.datexuniversity.com/Content/Release_Notes.htm
---

# Release Notes

This list outlines the major features as they are added to the Datex Design System.

## Version 2.0

- Application content updated for 2025
- Print report guidelines
- Updated branding and web design

## Version 1.1

- Application Studio styling
- Monaco editor Component styling

## Version 1.0

- Basic styling
- Desktop application styling
- All main Component-specific styling
- Icon libraries
- Color theming
- Form field styles (standard, filled, underlined)
