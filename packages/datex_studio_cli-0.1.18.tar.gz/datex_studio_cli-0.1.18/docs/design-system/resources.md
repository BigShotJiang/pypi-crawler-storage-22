---
title: Resources
source: https://design.datexuniversity.com/Content/Resources.htm
---

# Resources

## Microsoft's Fluent 2 Design System

**URL:** [fluent2.microsoft.design](https://fluent2.microsoft.design/)

This organization bases its designs on Microsoft's standards to ensure familiarity for users. Design standards and best practices are largely pulled directly from Fluent 2.
