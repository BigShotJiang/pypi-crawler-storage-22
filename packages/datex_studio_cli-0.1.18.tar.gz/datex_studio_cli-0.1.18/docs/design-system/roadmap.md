---
title: Roadmap
source: https://design.datexuniversity.com/Content/Roadmap.htm
---

# Roadmap

This roadmap outlines items both delivered and those yet to come to the Datex Design System. This list is subject to change.

## Core Documentation

- Getting Started guide (explanation of the design system and how to use it)
- Datex Design Principles (ranked principles to guide design and development of Datex software)

## Guidelines

- Colors
- Fonts
- Spacing
- Voice and Tone (how we communicate)
- Terminology
- Icons
- Accessibility
- Internationalization
- Images
- Sounds
- Animation
- Layouts
- Responsiveness
- Error Handling

## Patterns

- Flyouts
- Forms
- Errors
- Tours
- Toolbars
- Filtering
- Searching

## Additional Resources

- Components
- Resources
- Release Notes
- Contribute
- Usable CSS for developers
- Component code snippets
- Icon libraries
  - Segoe MDL2 icons
  - Custom WMS icons

---

*Last Updated: 04/21/2025*
