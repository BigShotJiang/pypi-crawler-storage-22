"""Datex Studio CLI - Command-line interface for Datex Studio platform."""

__version__ = "0.1.19"
__app_name__ = "dxs"
