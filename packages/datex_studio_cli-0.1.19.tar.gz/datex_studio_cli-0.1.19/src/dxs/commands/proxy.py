"""Proxy command: dxs proxy — launch local HTTP proxy for API access."""

import secrets
from pathlib import Path

import click

from dxs.cli import DxsContext, pass_context


@click.command()
@click.option("--port", "-p", type=int, default=5052, help="Port to run the proxy on")
@click.option("--org", required=True, help="Organization name or ID")
@click.option("--env", required=True, help="Environment name (e.g., Prod, Dev)")
@click.option("--app", required=True, help="Application name (e.g., Footprint)")
@click.option(
    "--api-key",
    default=None,
    help="API key for proxy authentication (generated if not provided, ignored in --login mode)",
)
@click.option(
    "--login",
    "login_mode",
    is_flag=True,
    default=False,
    help="Login mode: proxy the app and capture tokens when user logs in via browser",
)
@click.option(
    "--ngrok",
    "use_ngrok",
    is_flag=True,
    default=False,
    help="Create an ngrok tunnel for external access (requires ngrok installed)",
)
@pass_context
def proxy(
    ctx: DxsContext,
    port: int,
    org: str,
    env: str,
    app: str,
    api_key: str | None,
    login_mode: bool,
    use_ngrok: bool,
) -> None:
    """Launch a local HTTP proxy for simplified API access.

    This proxy allows AI tools and prototypes to access Datex Studio apps
    without managing OAuth tokens. The proxy injects the proper credentials
    for each request.

    \b
    Modes:
      Default mode: Requires API key authentication. Uses previously captured
                    tokens from ~/.datex/proxy_tokens.json for upstream auth.
                    Run with --login first to capture tokens.

      --login mode: No API key required. Opens the app for browser login and
                    captures OAuth tokens. Tokens are persisted for future use.

    \b
    Examples:
        # First time: authenticate via browser (tokens are saved)
        dxs proxy --org Datex --env Prod --app Footprint --login

        # Subsequent runs: use saved tokens with API key protection
        dxs proxy --org Datex --env Prod --app Footprint
        dxs proxy --org Datex --env Prod --app Footprint --api-key mySecretKey

        # Expose via ngrok for external access
        dxs proxy --org Datex --env Prod --app Footprint --ngrok
    """
    try:
        import uvicorn  # noqa: F401
    except ImportError as e:
        raise click.ClickException(
            "Proxy requires extra dependencies. Install with:\n\n"
            "  uv pip install 'datex-studio-cli[studio]'\n\n"
            "Or if developing locally:\n\n"
            "  uv sync --extra studio"
        ) from e

    from dxs.utils.errors import DxsError
    from dxs.utils.paths import get_proxy_tokens_path
    from dxs.web.proxy_app import load_persisted_tokens

    tokens_path = get_proxy_tokens_path()

    # In default mode, check for persisted tokens
    if not login_mode:
        tokens = load_persisted_tokens(tokens_path)
        if not tokens.get("access_token"):
            raise click.ClickException(
                "No saved tokens found. Run with --login first to authenticate:\n\n"
                f"  dxs proxy --org {org} --env {env} --app {app} --login"
            )

    # Resolve org, env, and app to get target URL
    # Need CLI auth for this resolution step
    from dxs.core.auth.token_cache import MultiIdentityTokenCache

    cache = MultiIdentityTokenCache()
    if cache.get_valid_token() is None and cache.try_refresh() is None:
        raise click.ClickException(
            "CLI authentication required to resolve organization/environment.\n"
            "Run 'dxs auth login' first."
        )

    try:
        from dxs.core.api import ApiClient
        from dxs.utils.resolvers import EntityResolver

        client = ApiClient()
        resolver = EntityResolver(client)

        # Resolve organization
        org_id = resolver.resolve_org(org)

        # Get org name for display
        from dxs.core.api.endpoints import OrganizationEndpoints

        org_data = client.get(OrganizationEndpoints.get(org_id))
        org_name = (
            org_data.get("name", str(org_id)) if isinstance(org_data, dict) else str(org_id)
        )

        # Resolve environment
        env_id = resolver.resolve_environment(env, org_id)

        # Get env name for display
        from dxs.core.api.endpoints import EnvironmentEndpoints

        env_data = client.get(EnvironmentEndpoints.get(env_id))
        env_name = (
            env_data.get("name", str(env_id)) if isinstance(env_data, dict) else str(env_id)
        )

        # Resolve app URL
        target_url, component = resolver.resolve_app_url(org_id, env_id, app)
        app_name = component.get("name", app) if isinstance(component, dict) else app

    except DxsError as e:
        raise click.ClickException(str(e)) from e

    # Generate API key for non-login mode if not provided
    if not login_mode and api_key is None:
        api_key = secrets.token_urlsafe(32)

    _run_transparent_mode(
        port=port,
        org_name=org_name,
        org_id=org_id,
        env_name=env_name,
        env_id=env_id,
        app_name=app_name,
        target_url=target_url,
        tokens_path=tokens_path,
        login_mode=login_mode,
        api_key=api_key,
        use_ngrok=use_ngrok,
    )


def _run_transparent_mode(
    port: int,
    org_name: str,
    org_id: int,
    env_name: str,
    env_id: int,
    app_name: str,
    target_url: str,
    tokens_path: Path,
    login_mode: bool,
    api_key: str | None,
    use_ngrok: bool,
) -> None:
    """Run proxy with transparent token handling."""
    import atexit
    import shutil
    import signal
    import subprocess
    import time

    import httpx
    import uvicorn

    from dxs.web.proxy_app import create_transparent_proxy_app

    ngrok_process: subprocess.Popen[bytes] | None = None
    ngrok_url: str | None = None

    def cleanup_ngrok() -> None:
        """Terminate ngrok process if running."""
        nonlocal ngrok_process
        if ngrok_process is not None:
            click.echo("\nShutting down ngrok tunnel...", err=True)
            ngrok_process.terminate()
            try:
                ngrok_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                ngrok_process.kill()
            ngrok_process = None

    # Start ngrok if requested
    if use_ngrok:
        # Check if ngrok is available
        if shutil.which("ngrok") is None:
            raise click.ClickException(
                "ngrok executable not found. Install from https://ngrok.com/download"
            )

        click.echo("Starting ngrok tunnel...", err=True)
        ngrok_process = subprocess.Popen(
            ["ngrok", "http", str(port), "--log", "stderr"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        # Register cleanup handlers
        atexit.register(cleanup_ngrok)
        signal.signal(signal.SIGINT, lambda s, f: None)  # Let uvicorn handle Ctrl+C
        signal.signal(signal.SIGTERM, lambda s, f: cleanup_ngrok())

        # Wait for ngrok to start and get the public URL
        time.sleep(2)  # Give ngrok time to start

        # Get the public URL from ngrok's local API
        for _ in range(10):
            try:
                response = httpx.get("http://localhost:4040/api/tunnels", timeout=2.0)
                if response.status_code == 200:
                    tunnels = response.json().get("tunnels", [])
                    for tunnel in tunnels:
                        if tunnel.get("proto") == "https":
                            ngrok_url = tunnel.get("public_url")
                            break
                    if ngrok_url:
                        break
            except httpx.RequestError:
                pass
            time.sleep(0.5)

        if not ngrok_url:
            cleanup_ngrok()
            raise click.ClickException(
                "Failed to get ngrok tunnel URL. Check ngrok configuration."
            )

    if login_mode:
        click.echo("Datex Proxy starting in LOGIN mode...", err=True)
    else:
        click.echo("Datex Proxy starting...", err=True)

    click.echo(f"  Organization: {org_name} (ID: {org_id})", err=True)
    click.echo(f"  Environment: {env_name} (ID: {env_id})", err=True)
    click.echo(f"  Application: {app_name}", err=True)
    click.echo(f"  Target URL: {target_url}", err=True)
    click.echo(f"  Tokens: {tokens_path}", err=True)
    click.echo("", err=True)

    if login_mode:
        click.echo("Instructions:", err=True)
        click.echo(f"  1. Browser will open to http://localhost:{port}", err=True)
        click.echo("  2. Log in with your credentials", err=True)
        click.echo("  3. The proxy will capture and save your tokens", err=True)
        click.echo("  4. Future runs without --login will use saved tokens", err=True)
        click.echo("", err=True)

        # Auto-open browser for login
        import webbrowser
        webbrowser.open(f"http://localhost:{port}")
    else:
        click.echo(f"API Key: {api_key}", err=True)
        click.echo(f"  Use header: X-API-Key: {api_key}", err=True)
        click.echo(f"  Or bearer:  Authorization: Bearer {api_key}", err=True)
        click.echo("", err=True)

    if ngrok_url:
        click.echo(f"ngrok URL: {ngrok_url}", err=True)
        click.echo(f"  External access: {ngrok_url}/api/...", err=True)
        click.echo("", err=True)

    click.echo("Status endpoints:", err=True)
    click.echo(f"  GET  http://localhost:{port}/_proxy/status - Check token status", err=True)
    click.echo(f"  POST http://localhost:{port}/_proxy/clear  - Clear captured tokens", err=True)
    click.echo("", err=True)
    click.echo(f"Proxy listening on http://localhost:{port}", err=True)
    click.echo("Press Ctrl+C to stop.", err=True)

    proxy_app = create_transparent_proxy_app(
        target_url=target_url,
        tokens_path=tokens_path,
        api_key=api_key,
    )

    try:
        uvicorn.run(proxy_app, host="localhost", port=port, log_level="warning")
    finally:
        cleanup_ngrok()
