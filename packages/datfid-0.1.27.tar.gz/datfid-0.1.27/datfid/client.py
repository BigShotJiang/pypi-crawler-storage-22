import time as _time
import requests
import pandas as pd
from typing import Dict, Any, Optional, Union
import json
from types import SimpleNamespace
import tempfile
import os
import gc
import psutil
import logging

# for nice output
class FitResult(SimpleNamespace):
    _ROW4  = ["Estimate", "Standard Error", "T statistic", "P value"]
    _PERF5 = ["R2 within", "R2 between", "R2 overall", "MSE", "MAE"]
    
    @property
    def id(self):
        import pandas as pd
        if hasattr(self, "df") and isinstance(self.df, pd.DataFrame) and "ID" in self.df.columns:
            return pd.DataFrame(self.df["ID"].astype(str).unique())
        return pd.DataFrame([])
    
    @property
    def ID(self):
        import pandas as pd
        if hasattr(self, "df") and isinstance(self.df, pd.DataFrame) and "ID" in self.df.columns:
            return pd.DataFrame(self.df["ID"].astype(str).unique())
        return pd.DataFrame([])
    
    @property
    def Id(self):
        import pandas as pd
        if hasattr(self, "df") and isinstance(self.df, pd.DataFrame) and "ID" in self.df.columns:
            return pd.DataFrame(self.df["ID"].astype(str).unique())
        return pd.DataFrame([])

    @staticmethod
    def _df4(rows_list):
        if not isinstance(rows_list, list):
            return rows_list
        return pd.DataFrame(rows_list, index=FitResult._ROW4[:len(rows_list)])

    @staticmethod
    def _df_perf(rows_list):
        if not isinstance(rows_list, list):
            return rows_list
        return pd.DataFrame(rows_list, index=FitResult._PERF5[:len(rows_list)])

    def __init__(self, **kwargs):
        # Convert list→DataFrame for table-like fields
        if "alpha" in kwargs:
            kwargs["alpha"] = self._df4(kwargs["alpha"])
        if "beta" in kwargs:
            kwargs["beta"] = self._df4(kwargs["beta"])
        if "Performance" in kwargs:
            kwargs["Performance"] = self._df_perf(kwargs["Performance"])
        if "df" in kwargs and isinstance(kwargs["df"], list):
            kwargs["df"] = pd.DataFrame(kwargs["df"])
        super().__init__(**kwargs)

class FitResultDict(dict):
    @property
    def id(self):
        return pd.DataFrame({"ID": list(self.keys())})
    
    @property
    def ID(self):
        return pd.DataFrame({"ID": list(self.keys())})
    
    @property
    def Id(self):
        return pd.DataFrame({"ID": list(self.keys())})


HF_LOGS_API = "https://huggingface.co/api/spaces"
DEFAULT_LOGS_ORG = "DATFID-org"  # if repo_id has no "/", use {org}/{repo_id}

# After this many seconds without answer, SDK stops and raises (fit/forecast calls)
DEFAULT_REQUEST_TIMEOUT = 1200  # 20 minutes
TIMEOUT_MESSAGE = (
    "Response taking too long. Please send the data in smaller parts, "
    "or contact admin for individual settings/solution: admin@datfid.com"
)


class DATFIDClient:
    def __init__(self, token: str, admin_pass: Optional[str] = None):
        """
        Args:
            token: DATFID API token (Bearer dt+...) for normal API calls.
            admin_pass: Optional. Same as Admin_pass in datfid_master (and HF token for direct logs); required for get_admin_logs.
        """
        self.api_url = "https://datfid-org-datfid-master.hf.space/"
        self.headers = {"Authorization": f"Bearer {token}"}
        self.admin_pass = admin_pass
        self.request_timeout = DEFAULT_REQUEST_TIMEOUT
        self.logger = logging.getLogger(__name__)

    def _cleanup_memory(self):
        """Clean up memory after operations"""
        gc.collect()
        if hasattr(psutil, 'Process'):
            process = psutil.Process()
            try:
                process.memory_info().rss  # Force memory info update
            except:
                pass

    def ping(self):
        try:
            response = requests.get(self.api_url, headers=self.headers).json()
            self._cleanup_memory()
            return response
        except Exception as e:
            self.logger.error(f"Ping failed: {str(e)}")
            raise

    def secure_ping(self):
        try:
            response = requests.get(f"{self.api_url}secure-ping/", headers=self.headers).json()
            self._cleanup_memory()
            return response
        except Exception as e:
            self.logger.error(f"Secure ping failed: {str(e)}")
            raise

    def _admin_headers(self, admin_pass_override: Optional[str] = None) -> dict:
        token = admin_pass_override or self.admin_pass
        if not token:
            raise ValueError(
                "Admin_pass required for logs. Pass admin_pass=... in __init__ or to get_admin_logs."
            )
        return {**self.headers, "X-Admin-Pass": token}

    def get_admin_logs(
        self,
        repo_id: str,
        log_type: str = "run",
        admin_pass: Optional[str] = None,
        timeout: int = 400,
        stream: bool = False,
        to_file: bool = False,
        path: str = "logs.txt",
        max_wait: Optional[int] = 30,
    ):
        """
        Get Space run or build logs: first verify token and admin_pass with datfid-master, then call the HF logs API directly using admin_pass as Bearer.
        Requires admin_pass in __init__ or pass here (Admin_pass).
        By default max_wait=30 so the call returns after at most 30 seconds with whatever was received (partial log). Pass max_wait=None to wait for the full response.

        Args:
            repo_id: Full repo id "org/space" (e.g. "DATFID-org/datfid-master") or short space name (e.g. "datfid-master"). If no "/", uses DEFAULT_LOGS_ORG (DATFID-org).
            log_type: "run" or "build"
            admin_pass: Override; if None, uses admin_pass from __init__
            timeout: HTTP client timeout in seconds (default 400): max time for connection and for the server to send the first byte. Does not limit how long we read the stream.
            stream: If True, use streaming (when to_file=False return response for r.iter_lines(); when to_file=True write line-by-line as data arrives). Only used when max_wait is None.
            to_file: If True, write logs to a file and return the file path. If False, return log text (str) or requests.Response when max_wait is None.
            path: Output file path when to_file=True (default "logs.txt"). Ignored when to_file=False.
            max_wait: Max seconds to read from the stream (default 30). After this we stop and return/save partial content. Unlike timeout, this caps how long the call runs. Use max_wait=None to wait for the full stream (may take several minutes for run logs).

        Returns:
            str (partial log text) when to_file=False and max_wait is set (default). str (file path) when to_file=True. requests.Response only when to_file=False and max_wait=None.
        """
        if log_type not in ("run", "build"):
            raise ValueError("log_type must be 'run' or 'build'")
        pass_val = admin_pass or self.admin_pass
        if not pass_val:
            raise ValueError("admin_pass required. Pass admin_pass=... in __init__ or to get_admin_logs.")
        # Resolve repo_id: short name like "datfid-api" -> "DATFID-org/datfid-api"
        full_repo = f"{DEFAULT_LOGS_ORG}/{repo_id}" if "/" not in repo_id else repo_id
        # 1) Verify token (Bearer) and admin_pass (X-Admin-Pass) with datfid-master
        verify = requests.get(
            f"{self.api_url}admin/verify",
            headers={**self.headers, "X-Admin-Pass": pass_val},
            timeout=15,
        )
        verify.raise_for_status()
        url = f"{HF_LOGS_API}/{full_repo}/logs/{log_type}"
        use_stream = stream or to_file or (max_wait is not None)
        r = requests.get(
            url,
            headers={"Authorization": f"Bearer {pass_val}"},
            timeout=timeout,
            stream=use_stream,
        )
        r.raise_for_status()

        if max_wait is not None:
            # Read stream for at most max_wait seconds, then stop and return/save partial
            start = _time.perf_counter()
            lines = []
            try:
                if to_file:
                    with open(path, "w", encoding="utf-8") as f:
                        for line in r.iter_lines(decode_unicode=True):
                            if _time.perf_counter() - start >= max_wait:
                                break
                            if line is not None:
                                f.write(line + "\n")
                else:
                    for line in r.iter_lines(decode_unicode=True):
                        if _time.perf_counter() - start >= max_wait:
                            break
                        if line is not None:
                            lines.append(line)
            finally:
                r.close()
            if to_file:
                return path
            return "\n".join(lines)

        if not to_file:
            return r
        with open(path, "w", encoding="utf-8") as f:
            try:
                if use_stream:
                    for line in r.iter_lines(decode_unicode=True):
                        if line is not None:
                            f.write(line + "\n")
                else:
                    f.write(r.text)
            except requests.exceptions.ChunkedEncodingError as e:
                # Server closed the connection early (e.g. HF timeout). Partial log may be saved.
                raise requests.exceptions.ChunkedEncodingError(
                    f"Response ended prematurely. Partial log may have been saved to {path!r}. {e}"
                ) from e
        return path

    def fit_model(
        self,
        df: pd.DataFrame,
        id_col: str,
        time_col: str,
        y: str,
        lag_y: Optional[Union[int, str, list[int]]] = None,
        lagged_features: Optional[Dict[str, int]] = None,
        current_features: Optional[list] = None,
        filter_by_significance: bool = False,
        meanvar_test: bool = False,
        signif: float = 0.05
    ) -> FitResult:
        """
        Fit a model using the DATFID API.
        
        Args:
            df: DataFrame containing the data
            id_col: Name of the ID column
            time_col: Name of the time column
            y: Name of the target variable
            lagged_features: Dictionary of features and their lag values
            current_features: List of current features to use
            filter_by_significance: Whether to filter features by significance
            meanvar_test: Whether to perform mean-variance test
            signif: Significance level (default 0.05), used when filter_by_significance is True
            
        Returns:
            SimpleNamespace containing the model fit results
        """

        df = df.copy()
        for col in df.columns:
            if pd.api.types.is_datetime64_any_dtype(df[col]):
                df[col] = df[col].astype(str)

        data = {
            "df": df.to_dict(orient="records"),
            "id_col": id_col,
            "time_col": time_col,
            "y": y,
            "lag_y": lag_y,
            "lagged_features": lagged_features or {},
            "current_features": current_features or [],
            "filter_by_significance": filter_by_significance,
            "meanvar_test": meanvar_test,
            "signif": signif
        }
        
        try:
            response = requests.post(
                f"{self.api_url}modelfit/",
                json=data,
                headers=self.headers,
                timeout=self.request_timeout,
            )
        except requests.exceptions.Timeout:
            raise Exception(TIMEOUT_MESSAGE)
        
        if response.status_code != 200:
            raise Exception(f"Model fit failed: {response.text}")
            
        result_dict = response.json()
        return FitResult(**result_dict)
    
    def forecast_model(
        self,
        df_forecast: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Generate forecasts using the fitted model.
        
        Args:
            df_forecast: DataFrame containing the forecast data
            
        Returns:
            DataFrame containing the forecast results
        """

        try:
            df_forecast = df_forecast.copy()
            for col in df_forecast.columns:
                if pd.api.types.is_datetime64_any_dtype(df_forecast[col]):
                    df_forecast[col] = df_forecast[col].astype(str)

            # Convert DataFrame to list of records
            data = df_forecast.to_dict(orient="records")
            
            try:
                response = requests.post(
                    f"{self.api_url}modelforecast/",
                    json=data,
                    headers=self.headers,
                    timeout=self.request_timeout,
                )
            except requests.exceptions.Timeout:
                raise Exception(TIMEOUT_MESSAGE)
            
            if response.status_code != 200:
                raise Exception(f"Forecast generation failed: {response.text}")
            
            result = pd.DataFrame(response.json())
            
            # Clean up memory after operation
            del df_forecast
            del data
            self._cleanup_memory()
            
            return result
        except Exception as e:
            self.logger.error(f"Forecast generation failed: {str(e)}")
            raise

    def fit_model_ind(
        self,
        df: pd.DataFrame,
        id_col: str,
        time_col: str,
        y: str,
        lag_y: Optional[Union[int, str, list[int]]] = None,
        lagged_features: Optional[Dict[str, int]] = None,
        current_features: Optional[list] = None,
        filter_by_significance: bool = False,
        meanvar_test: bool = False,
        signif: float = 0.05
    ) -> FitResultDict:
        """
        Fit a model individual by individual using the DATFID API.
        
        Args:
            df: DataFrame containing the data
            id_col: Name of the ID column
            time_col: Name of the time column
            y: Name of the target variable
            lagged_features: Dictionary of features and their lag values
            current_features: List of current features to use
            filter_by_significance: Whether to filter features by significance
            meanvar_test: Whether to perform mean-variance test
            signif: Significance level (default 0.05), used when filter_by_significance is True
            
        Returns:
            SimpleNamespace containing the model fit results
        """

        df = df.copy()
        for col in df.columns:
            if pd.api.types.is_datetime64_any_dtype(df[col]):
                df[col] = df[col].astype(str)

        data = {
            "df": df.to_dict(orient="records"),
            "id_col": id_col,
            "time_col": time_col,
            "y": y,
            "lag_y": lag_y,
            "lagged_features": lagged_features or {},
            "current_features": current_features or [],
            "filter_by_significance": filter_by_significance,
            "meanvar_test": meanvar_test,
            "signif": signif
        }
        
        try:
            response = requests.post(
                f"{self.api_url}modelfit_ind/",
                json=data,
                headers=self.headers,
                timeout=self.request_timeout,
            )
        except requests.exceptions.Timeout:
            raise Exception(TIMEOUT_MESSAGE)
        
        if response.status_code != 200:
            raise Exception(f"Model fit failed: {response.text}")
            
        raw = response.json() 
        # Wrap each per-id result into a SimpleNamespace for dot access:
        result_per_id = FitResultDict({str(k): FitResult(**v) for k, v in raw.items()})
        return result_per_id  # FitResultDict[str, SimpleNamespace]

    def forecast_model_ind(
        self,
        df_forecast: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Generate forecasts using the fitted individual by individual model.
        
        Args:
            df_forecast: DataFrame containing the forecast data
            
        Returns:
            DataFrame containing the forecast results
        """

        try:
            df_forecast = df_forecast.copy()
            for col in df_forecast.columns:
                if pd.api.types.is_datetime64_any_dtype(df_forecast[col]):
                    df_forecast[col] = df_forecast[col].astype(str)

            # Convert DataFrame to list of records
            data = df_forecast.to_dict(orient="records")
            
            try:
                response = requests.post(
                    f"{self.api_url}modelforecast_ind/",
                    json=data,
                    headers=self.headers,
                    timeout=self.request_timeout,
                )
            except requests.exceptions.Timeout:
                raise Exception(TIMEOUT_MESSAGE)
            
            if response.status_code != 200:
                raise Exception(f"Forecast generation failed: {response.text}")
            
            result = pd.DataFrame(response.json())
            
            # Clean up memory after operation
            del df_forecast
            del data
            self._cleanup_memory()
            
            return result
        except Exception as e:
            self.logger.error(f"Forecast generation failed: {str(e)}")
            raise