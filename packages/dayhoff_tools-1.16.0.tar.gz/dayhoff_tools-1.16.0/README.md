# dayhoff-tools (legacy)

> **Note**: Active development has moved to `dh-cli` (developer CLI) and `dh-workers` (batch worker code), hosted on CodeArtifact. This package remains on PyPI for backward compatibility with existing notebooks and pipelines that import data utilities (`dayhoff_tools.warehouse`, `dayhoff_tools.file_ops`, `dayhoff_tools.sqlite`, etc.).

## Installation

```bash
pip install dayhoff-tools
```

### Optional Dependencies

Available extras: `full`, `embedders`, `boltz`, `batch`.

```bash
pip install 'dayhoff-tools[full]'
```