"""Pitch deck generators."""
