# db2_hj3415/analysis/domain.py
from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import TypedDict

from db2_hj3415.common.hash_utils import stable_sha256
from db2_hj3415.common.types import ContentsMap

LATEST_COL = "analysis_latest"
SNAPSHOTS_COL = "analysis_snapshots"


class AnalysisServiceEnum(StrEnum):
    FEATURES = "features"
    RED = "red"


class EndpointEnum(StrEnum):
    C103 = "C103"
    C104 = "C104"


class AnalysisLatestDoc(TypedDict):
    _id: str
    code: str
    asof: datetime
    service: AnalysisServiceEnum
    endpoint: EndpointEnum | None
    contents: ContentsMap
    contents_hash: str


class AnalysisSnapshotDoc(TypedDict):
    code: str
    asof: datetime
    service: AnalysisServiceEnum
    endpoint: EndpointEnum | None
    contents: ContentsMap
    contents_hash: str


def clean_code(code: str) -> str:
    """종목코드 공백 제거."""
    return str(code).strip()


def latest_id(service: AnalysisServiceEnum, code: str) -> str:
    """latest _id 규칙: '{service}:{code}'"""
    return f"{service.value}:{clean_code(code)}"


def compute_contents_hash(contents: ContentsMap) -> str:
    """payload 변경 감지용 안정 해시."""
    return stable_sha256(contents)


def build_latest_doc(
    *,
    code: str,
    asof: datetime,
    service: AnalysisServiceEnum,
    endpoint: EndpointEnum | None = None,
    contents: ContentsMap,
) -> AnalysisLatestDoc:
    """AnalysisLatestDoc 빌더(_id/payload_hash 포함)."""
    code_s = clean_code(code)
    if not code_s:
        raise ValueError("code must be non-empty")

    return {
        "_id": latest_id(service, code_s),
        "code": code_s,
        "asof": asof,
        "service": service,
        "endpoint": endpoint,
        "contents": contents,
        "contents_hash": compute_contents_hash(contents),
    }


def build_snapshot_doc(
    *,
    code: str,
    asof: datetime,
    service: AnalysisServiceEnum,
    endpoint: EndpointEnum | None = None,
    contents: ContentsMap,
) -> AnalysisSnapshotDoc:
    """AnalysisSnapshotDoc 빌더(payload_hash 포함)."""
    code_s = clean_code(code)
    if not code_s:
        raise ValueError("code must be non-empty")

    return {
        "code": code_s,
        "asof": asof,
        "service": service,
        "endpoint": endpoint,
        "contents": contents,
        "contents_hash": compute_contents_hash(contents),
    }
