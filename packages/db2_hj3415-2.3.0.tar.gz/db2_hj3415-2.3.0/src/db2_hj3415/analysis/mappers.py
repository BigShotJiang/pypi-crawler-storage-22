from __future__ import annotations

from typing import cast

from contracts_hj3415.analysis.payloads import AnalysisPayloadDTO
from contracts_hj3415.common import make_analysis_envelope, make_empty_envelope_meta
from contracts_hj3415.common.envelope import EnvelopeDTO
from db2_hj3415.analysis.domain import (
    AnalysisLatestDoc,
    AnalysisServiceEnum,
    AnalysisSnapshotDoc,
    EndpointEnum,
    build_latest_doc,
    build_snapshot_doc,
)


def envelope_to_latest_doc(env: EnvelopeDTO) -> AnalysisLatestDoc:
    analysis_payload = cast(AnalysisPayloadDTO, cast(object, env["payload"]))
    meta = analysis_payload["meta"]
    contents = analysis_payload["contents"]

    service = meta.get("service")
    endpoint = meta.get("endpoint")

    return build_latest_doc(
        code=env["key"],
        asof=env["asof"],
        service=AnalysisServiceEnum(service),
        endpoint=EndpointEnum(endpoint) if endpoint is not None else None,
        contents=contents,
    )


def envelope_to_snapshot_doc(env: EnvelopeDTO) -> AnalysisSnapshotDoc:
    analysis_payload = cast(AnalysisPayloadDTO, cast(object, env["payload"]))
    meta = analysis_payload["meta"]
    contents = analysis_payload["contents"]

    service = meta.get("service")
    endpoint = meta.get("endpoint")

    return build_snapshot_doc(
        code=env["key"],
        asof=env["asof"],
        service=AnalysisServiceEnum(service),
        endpoint=EndpointEnum(endpoint) if endpoint is not None else None,
        contents=contents,
    )


def latest_doc_to_envelope_dto(doc: AnalysisLatestDoc) -> EnvelopeDTO:
    ep = "" if doc["endpoint"] is None else doc["endpoint"].value

    return make_analysis_envelope(
        code=doc["code"],
        asof=doc["asof"],
        service=doc["service"].value,
        endpoint=ep,
        contents=doc["contents"],
        meta=make_empty_envelope_meta(source="analyser2"),
    )
