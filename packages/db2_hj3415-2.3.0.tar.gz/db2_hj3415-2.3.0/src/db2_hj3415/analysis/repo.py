# db2_hj3415/analysis/repo.py
from __future__ import annotations

from typing import cast

from db2_hj3415.common.types import MongoDoc
from pymongo import ASCENDING, DESCENDING
from pymongo.asynchronous.database import AsyncDatabase
from pymongo.errors import DuplicateKeyError

from .domain import (
    LATEST_COL,
    SNAPSHOTS_COL,
    AnalysisLatestDoc,
    AnalysisServiceEnum,
    AnalysisSnapshotDoc,
    latest_id,
)


async def ensure_indexes(
    db: AsyncDatabase[MongoDoc],
    *,
    snapshot_ttl_days: int | None,
) -> None:
    """analysis latest/snapshots 인덱스와 TTL/유니크 인덱스를 보장한다."""
    latest = db.get_collection(LATEST_COL)
    snaps = db.get_collection(SNAPSHOTS_COL)

    # latest 조회/정리용
    _ = await latest.create_index([("payload.service", ASCENDING), ("code", ASCENDING)])
    _ = await latest.create_index([("code", ASCENDING)])
    _ = await latest.create_index([("asof", DESCENDING)])

    # snapshots 타임라인 조회
    _ = await snaps.create_index(
        [("payload.service", ASCENDING), ("code", ASCENDING), ("asof", DESCENDING)]
    )
    _ = await snaps.create_index([("code", ASCENDING)])

    # snapshot 멱등(동일 asof+payload_hash 중복 방지)
    _ = await snaps.create_index(
        [
            ("payload.service", ASCENDING),
            ("code", ASCENDING),
            ("asof", ASCENDING),
            ("payload_hash", ASCENDING),
        ],
        unique=True,
        name="uq_analysis_snapshot_identity",
    )

    # TTL (asof 기준)
    if snapshot_ttl_days is not None and int(snapshot_ttl_days) > 0:
        expire_seconds = int(snapshot_ttl_days) * 24 * 60 * 60
        _ = await snaps.create_index(
            [("asof", ASCENDING)],
            expireAfterSeconds=expire_seconds,
            name="ttl_asof",
        )


# -----------------------------------------------------------------------------
# Writes (doc-only)
# -----------------------------------------------------------------------------


async def upsert_latest_doc(
    db: AsyncDatabase[MongoDoc],
    *,
    doc: AnalysisLatestDoc,
) -> AnalysisLatestDoc:
    """latest 문서를 _id 기준으로 upsert하고 doc을 반환한다."""
    col = db.get_collection(LATEST_COL)
    _ = await col.replace_one({"_id": doc["_id"]}, doc, upsert=True)
    return doc


async def insert_snapshot_doc(
    db: AsyncDatabase[MongoDoc],
    *,
    doc: AnalysisSnapshotDoc,
) -> AnalysisSnapshotDoc:
    """
    snapshot 문서를 멱등하게 저장한다.
    (service, code, asof, payload_hash 유니크 인덱스 전제)
    """
    col = db.get_collection(SNAPSHOTS_COL)
    flt = {
        "code": doc["code"],
        "asof": doc["asof"],
        "contents_hash": doc["contents_hash"],
    }
    try:
        _ = await col.update_one(flt, {"$setOnInsert": doc}, upsert=True)
    except DuplicateKeyError:
        pass
    return doc


# -----------------------------------------------------------------------------
# Reads
# -----------------------------------------------------------------------------


async def get_latest(
    db: AsyncDatabase[MongoDoc],
    *,
    service: str,
    code: str,
) -> AnalysisLatestDoc | None:
    """service+code의 latest 문서를 조회한다."""
    col = db.get_collection(LATEST_COL)
    _id = latest_id(AnalysisServiceEnum(service), code)
    doc = await col.find_one({"_id": _id})
    if not doc:
        return None
    return cast(AnalysisLatestDoc, doc)


async def list_latest_by_service(
    db: AsyncDatabase[MongoDoc],
    *,
    service: str,
    limit: int = 1000,
) -> list[AnalysisLatestDoc]:
    """특정 서비스의 latest 문서들을 조회한다."""
    sv = AnalysisServiceEnum(service)
    col = db.get_collection(LATEST_COL)
    cur = col.find({"payload.service": sv.value}).sort("code", ASCENDING).limit(limit)
    return [cast(AnalysisLatestDoc, d) async for d in cur]


async def list_snapshots(
    db: AsyncDatabase[MongoDoc],
    *,
    service: str,
    code: str,
    limit: int = 50,
    desc: bool = True,
) -> list[AnalysisSnapshotDoc]:
    """특정 service+code의 snapshot 이력을 조회한다."""
    sv = AnalysisServiceEnum(service)
    order = DESCENDING if desc else ASCENDING
    col = db.get_collection(SNAPSHOTS_COL)
    cur = (
        col.find({"payload.service": sv.value, "code": str(code).strip()})
        .sort("asof", order)
        .limit(limit)
    )
    return [cast(AnalysisSnapshotDoc, d) async for d in cur]
