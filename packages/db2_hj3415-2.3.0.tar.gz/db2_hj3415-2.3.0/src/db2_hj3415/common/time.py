# db2_hj3415/common/time.py
from __future__ import annotations

from datetime import datetime, timezone


def utcnow() -> datetime:
    """UTC now (tz-aware)."""
    return datetime.now(timezone.utc)
