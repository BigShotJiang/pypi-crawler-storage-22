from collections.abc import Mapping
from typing import Any, Sequence, TypeAlias

MongoDoc: TypeAlias = Mapping[str, Any]  # pyright: ignore[reportExplicitAny]

Payload: TypeAlias = Mapping[str, Any]  # pyright: ignore[reportExplicitAny]

ContentsMap: TypeAlias = Mapping[str, Any]  # pyright: ignore[reportExplicitAny]

ContentsItems: TypeAlias = Sequence[Any]  # pyright: ignore[reportExplicitAny]

LabelsMap: TypeAlias = Mapping[str, str]
