# db2_hj3415/mongo.py
from __future__ import annotations

from pymongo.asynchronous.mongo_client import AsyncMongoClient
from pymongo.asynchronous.database import AsyncDatabase
from datetime import timezone

from db2_hj3415.settings import Settings, get_settings
from db2_hj3415.common.types import MongoDoc


class Mongo:
    settings: Settings
    client: AsyncMongoClient[MongoDoc]

    def __init__(self, settings: Settings | None = None):
        self.settings = settings or get_settings()
        self.client = AsyncMongoClient(
            host=self.settings.MONGO_URI,
            connectTimeoutMS=self.settings.MONGO_CONNECT_TIMEOUT_MS,
            serverSelectionTimeoutMS=self.settings.MONGO_SERVER_SELECTION_TIMEOUT_MS,
            tz_aware=True,
            tzinfo=timezone.utc,
        )

    def get_db(self) -> AsyncDatabase[MongoDoc]:
        return self.client[self.settings.DB_NAME]

    async def close(self) -> None:
        await self.client.close()


def mongo_from_env() -> Mongo:
    return Mongo(get_settings())
