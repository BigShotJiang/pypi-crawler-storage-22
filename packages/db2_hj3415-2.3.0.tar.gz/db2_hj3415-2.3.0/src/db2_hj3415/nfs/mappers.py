from __future__ import annotations

from typing import cast

from contracts_hj3415.common import make_empty_envelope_meta, make_nfs_envelope
from contracts_hj3415.common.envelope import EnvelopeDTO
from contracts_hj3415.nfs.payloads import NfsPayloadDTO
from db2_hj3415.nfs.domain import (
    EndpointEnum,
    NfsLatestDoc,
    NfsSnapshotDoc,
    build_latest_doc,
    build_snapshot_doc,
)


def envelope_to_latest_doc(env: EnvelopeDTO) -> NfsLatestDoc:
    nfs_payload = cast(NfsPayloadDTO, cast(object, env["payload"]))
    meta = nfs_payload["meta"]
    contents = nfs_payload["contents"]

    endpoint = meta.get("endpoint")
    labels = meta.get("labels")

    return build_latest_doc(
        code=env["key"],
        asof=env["asof"],
        endpoint=EndpointEnum(endpoint),
        contents=contents,
        labels={} if labels is None else labels,
    )


def envelope_to_snapshot_doc(env: EnvelopeDTO) -> NfsSnapshotDoc:
    nfs_payload = cast(NfsPayloadDTO, cast(object, env["payload"]))
    meta = nfs_payload["meta"]
    contents = nfs_payload["contents"]

    endpoint = meta.get("endpoint")
    labels = meta.get("labels")

    return build_snapshot_doc(
        code=env["key"],
        asof=env["asof"],
        endpoint=EndpointEnum(endpoint),
        contents=contents,
        labels={} if labels is None else labels,
    )


def latest_doc_to_envelope(doc: NfsLatestDoc) -> EnvelopeDTO:
    return make_nfs_envelope(
        code=doc["code"],
        asof=doc["asof"],
        labels=doc["labels"],
        endpoint=doc["endpoint"].value,
        contents=doc["contents"],
        meta=make_empty_envelope_meta(source="scraper2"),
    )
