# db2_hj3415/nfs/repo.py
from __future__ import annotations

from collections.abc import Sequence
from typing import Any, cast

from db2_hj3415.common.types import MongoDoc
from pymongo import ASCENDING, DESCENDING, ReplaceOne, UpdateOne
from pymongo.asynchronous.collection import AsyncCollection
from pymongo.asynchronous.database import AsyncDatabase
from pymongo.errors import DuplicateKeyError

from .domain import (
    LATEST_COL,
    SNAPSHOTS_COL,
    EndpointEnum,
    NfsLatestDoc,
    NfsSnapshotDoc,
    latest_id,
)


async def ensure_indexes(
    db: AsyncDatabase[MongoDoc],
    *,
    snapshot_ttl_days: int | None,
) -> None:
    """nfs latest/snapshots 인덱스와 TTL/유니크 인덱스를 보장한다."""
    latest = db.get_collection(LATEST_COL)
    snaps = db.get_collection(SNAPSHOTS_COL)

    # latest 조회/정리용
    _ = await latest.create_index(
        [("payload.endpoint", ASCENDING), ("code", ASCENDING)]
    )
    _ = await latest.create_index([("code", ASCENDING)])

    # snapshots 타임라인
    _ = await snaps.create_index(
        [("payload.endpoint", ASCENDING), ("code", ASCENDING), ("asof", DESCENDING)]
    )
    _ = await snaps.create_index([("code", ASCENDING)])

    # snapshot 멱등(동일 배치/동일 payload 재삽입 방지)
    _ = await snaps.create_index(
        [
            ("payload.endpoint", ASCENDING),
            ("code", ASCENDING),
            ("asof", ASCENDING),
            ("payload_hash", ASCENDING),
        ],
        unique=True,
        name="uq_snapshot_identity",
    )

    # TTL (asof 기준)
    if snapshot_ttl_days is not None and int(snapshot_ttl_days) > 0:
        expire_seconds = int(snapshot_ttl_days) * 24 * 60 * 60
        _ = await snaps.create_index(
            [("asof", ASCENDING)],
            expireAfterSeconds=expire_seconds,
            name="ttl_asof",
        )


# -----------------------------------------------------------------------------
# Writes (doc-only)
# -----------------------------------------------------------------------------


async def upsert_latest_doc(
    db: AsyncDatabase[MongoDoc],
    *,
    doc: NfsLatestDoc,
) -> NfsLatestDoc:
    """latest 문서를 _id 기준으로 upsert하고 doc을 반환한다."""
    col = db.get_collection(LATEST_COL)
    _ = await col.replace_one({"_id": doc["_id"]}, doc, upsert=True)
    return doc


async def upsert_latest_docs(
    db: AsyncDatabase[MongoDoc],
    *,
    docs: list[NfsLatestDoc],
    ordered: bool = False,
) -> dict[str, int]:
    """latest 문서들을 bulk upsert한다. (ReplaceOne upsert)"""
    if not docs:
        return {"matched": 0, "modified": 0, "upserted": 0}

    col = cast(AsyncCollection[NfsLatestDoc], db.get_collection(LATEST_COL))
    ops = [ReplaceOne({"_id": d["_id"]}, d, upsert=True) for d in docs]
    res = await col.bulk_write(ops, ordered=ordered)

    return {
        "matched": int(res.matched_count),
        "modified": int(res.modified_count),
        "upserted": int(len(res.upserted_ids or {})),
    }


async def insert_snapshot_doc(
    db: AsyncDatabase[MongoDoc],
    *,
    doc: NfsSnapshotDoc,
) -> NfsSnapshotDoc:
    """
    snapshot 문서를 멱등하게 저장한다.
    (endpoint, code, asof, payload_hash 유니크 인덱스 전제)
    """
    col = db.get_collection(SNAPSHOTS_COL)
    flt = {
        "code": doc["code"],
        "asof": doc["asof"],
        "contents_hash": doc["contents_hash"],
    }
    try:
        _ = await col.update_one(flt, {"$setOnInsert": doc}, upsert=True)
    except DuplicateKeyError:
        pass
    return doc


async def insert_snapshot_docs(
    db: AsyncDatabase[MongoDoc],
    *,
    docs: list[NfsSnapshotDoc],
    ordered: bool = False,
) -> dict[str, int]:
    """snapshot 문서들을 bulk 멱등 저장한다. (UpdateOne $setOnInsert upsert)"""
    if not docs:
        return {"inserted": 0}

    col = cast(AsyncCollection[NfsLatestDoc], db.get_collection(LATEST_COL))
    ops: list[UpdateOne] = []
    for d in docs:
        flt = {
            "code": d["code"],
            "asof": d["asof"],
            "contents_hash": d["contents_hash"],
        }
        ops.append(UpdateOne(flt, {"$setOnInsert": d}, upsert=True))

    try:
        res = await col.bulk_write(ops, ordered=ordered)
        inserted = int(len(res.upserted_ids or {}))
        return {"inserted": inserted}
    except DuplicateKeyError:
        # ordered=False면 대부분 흡수되지만, 레이스 상황에선 날 수 있음 → 보수적으로 0
        return {"inserted": 0}


# -----------------------------------------------------------------------------
# Reads (doc 반환: 런타임은 dict, 타입은 Doc로 캐스팅)
# -----------------------------------------------------------------------------


async def get_latest(
    db: AsyncDatabase[MongoDoc],
    *,
    endpoint: str,
    code: str,
) -> NfsLatestDoc | None:
    """endpoint+code의 latest 문서를 조회한다."""
    col = db.get_collection(LATEST_COL)
    _id = latest_id(EndpointEnum(endpoint), code)
    doc = await col.find_one({"_id": _id})
    if not doc:
        return None
    return cast(NfsLatestDoc, doc)


async def list_latest_by_endpoint(
    db: AsyncDatabase[MongoDoc],
    *,
    endpoint: str,
    limit: int = 1000,
) -> list[NfsLatestDoc]:
    """특정 엔드포인트의 latest 문서들을 조회한다."""
    ep = EndpointEnum(endpoint)
    col = db.get_collection(LATEST_COL)
    cur = col.find({"payload.endpoint": ep.value}).sort("code", ASCENDING).limit(limit)
    return [cast(NfsLatestDoc, d) async for d in cur]


async def list_snapshots(
    db: AsyncDatabase[MongoDoc],
    *,
    endpoint: str,
    code: str,
    limit: int = 50,
    desc: bool = True,
) -> list[NfsSnapshotDoc]:
    """endpoint+code의 snapshot 이력을 조회한다."""
    ep = EndpointEnum(endpoint)
    order = DESCENDING if desc else ASCENDING
    col = db.get_collection(SNAPSHOTS_COL)
    cur = (
        col.find({"payload.endpoint": ep.value, "code": str(code).strip()})
        .sort("asof", order)
        .limit(limit)
    )
    return [cast(NfsSnapshotDoc, d) async for d in cur]


# -----------------------------------------------------------------------------
# Delete helpers
# -----------------------------------------------------------------------------


def _clean_codes(codes: Sequence[str]) -> list[str]:
    """
    코드 리스트를 정규화하여 공백 제거·빈값 제거·중복 제거(순서 유지)한다.

    입력: "005930", " 005930 ", None, "", "035420" 같은 지저분한 코드 리스트
    출력: ["005930", "035420"] 같은 안전한 코드 리스트
    """
    out: list[str] = []
    for c in codes:
        s = str(c).strip()
        if s:
            out.append(s)

    seen: set[str] = set()
    uniq: list[str] = []
    for c in out:
        if c in seen:
            continue
        seen.add(c)
        uniq.append(c)
    return uniq


async def delete_codes_from_nfs(
    db: AsyncDatabase[MongoDoc],
    *,
    codes: Sequence[str],
    endpoint: str | None = None,
) -> dict[str, int]:
    """
    여러 종목 코드(codes)를 NFS 컬렉션에서 삭제한다.

    - endpoint가 None이면: 모든 endpoint의 latest/snapshots에서 해당 코드 문서를 모두 삭제한다.
    - endpoint가 지정되면: 해당 endpoint의 latest/snapshots에서만 삭제한다.

    반환값은 latest/snapshots에서 삭제된 문서 수를 담은 dict이다.
    """
    codes_ = _clean_codes(codes)
    if not codes_:
        return {"latest_deleted": 0, "snapshots_deleted": 0}

    latest_filter: dict[str, Any] = {  # pyright: ignore[reportExplicitAny]
        "code": {"$in": codes_}
    }
    snaps_filter: dict[str, Any] = {  # pyright: ignore[reportExplicitAny]
        "code": {"$in": codes_}
    }
    if endpoint is not None:
        latest_filter["endpoint"] = endpoint
        snaps_filter["endpoint"] = endpoint

    r1 = await db[LATEST_COL].delete_many(latest_filter)
    r2 = await db[SNAPSHOTS_COL].delete_many(snaps_filter)

    return {
        "latest_deleted": int(r1.deleted_count),
        "snapshots_deleted": int(r2.deleted_count),
    }
