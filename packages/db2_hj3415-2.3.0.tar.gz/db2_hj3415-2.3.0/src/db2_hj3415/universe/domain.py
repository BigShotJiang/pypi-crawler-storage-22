# db2_hj3415/universe/domain.py
from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime
from enum import StrEnum
from typing import Any, TypedDict

from db2_hj3415.common.types import ContentsMap

LATEST_COL = "universe_latest"
SNAPSHOTS_COL = "universe_snapshots"

Blocks = Sequence[Any]  # pyright: ignore[reportExplicitAny]


class SourceEnum(StrEnum):
    SAMSUNGFUND = "samsungfund"


class UniverseEnum(StrEnum):
    KRX300 = "krx300"


class UniverseItem(TypedDict, total=False):
    """
    최소 확장 대비:
    - code: 식별자(필수)
    - name: 표시명(옵션)
    - market: KRX/US 등 (옵션)
    - meta: 기타(옵션)
    """

    code: str
    name: str
    market: str
    meta: dict[str, Any]  # pyright: ignore[reportExplicitAny]


class UniverseLatestDoc(TypedDict):
    _id: str
    universe: UniverseEnum
    asof: datetime
    source: SourceEnum
    contents: ContentsMap


class UniverseSnapshotDoc(TypedDict):
    universe: UniverseEnum
    asof: datetime
    source: SourceEnum
    contents: ContentsMap


def latest_id(universe: UniverseEnum) -> str:
    """latest _id 규칙: universe_name 자체."""
    return universe.value


def build_latest_doc(
    *,
    universe: UniverseEnum,
    asof: datetime,
    source: SourceEnum,
    contents: ContentsMap,
) -> UniverseLatestDoc:
    """UniverseLatestDoc 빌더(_id 포함)."""
    return {
        "_id": latest_id(universe),
        "universe": universe,
        "asof": asof,
        "source": source,
        "contents": contents,
    }


def build_snapshot_doc(
    *,
    universe: UniverseEnum,
    asof: datetime,
    source: SourceEnum,
    contents: ContentsMap,
) -> UniverseSnapshotDoc:
    """UniverseSnapshotDoc 빌더."""
    return {
        "universe": universe,
        "asof": asof,
        "source": source,
        "contents": contents,
    }
