from __future__ import annotations

from typing import cast

from contracts_hj3415.common import make_empty_envelope_meta, make_universe_envelope
from contracts_hj3415.common.envelope import EnvelopeDTO
from contracts_hj3415.universe.payloads import UniversePayloadDTO
from db2_hj3415.universe.domain import (
    SourceEnum,
    UniverseEnum,
    UniverseLatestDoc,
    UniverseSnapshotDoc,
    build_latest_doc,
    build_snapshot_doc,
)


def envelope_to_latest_doc(env: EnvelopeDTO) -> UniverseLatestDoc:
    universe_payload = cast(UniversePayloadDTO, cast(object, env["payload"]))
    meta = universe_payload["meta"]
    contents = universe_payload["contents"]

    source: str = meta.get("source")

    return build_latest_doc(
        universe=UniverseEnum(env["key"]),
        asof=env["asof"],
        source=SourceEnum(source),
        contents=contents,
    )


def envelope_to_snapshot_doc(env: EnvelopeDTO) -> UniverseSnapshotDoc:
    universe_payload = cast(UniversePayloadDTO, cast(object, env["payload"]))
    meta = universe_payload["meta"]
    contents = universe_payload["contents"]

    source: str = meta.get("source")

    return build_snapshot_doc(
        universe=UniverseEnum(env["key"]),
        asof=env["asof"],
        source=SourceEnum(source),
        contents=contents,
    )


def latest_doc_to_envelope(doc: UniverseLatestDoc) -> EnvelopeDTO:
    return make_universe_envelope(
        universe=doc["universe"].value,
        asof=doc["asof"],
        source=doc["source"].value,
        contents=doc["contents"],
        meta=make_empty_envelope_meta(source="krx"),
    )
