# noqa: D104

from importlib.metadata import version


__version__ = version("dbrownell_BrythonWebviewTest")
