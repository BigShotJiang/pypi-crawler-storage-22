def version() -> str:
    """Get the version of `dbt-bouncer`.

    Returns:
        str: The version of `dbt-bouncer`.

    """
    return "2.4.0"
