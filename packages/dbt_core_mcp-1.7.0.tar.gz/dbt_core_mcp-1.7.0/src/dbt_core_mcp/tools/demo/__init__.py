"""Demo tools for MCP UI experiments."""
