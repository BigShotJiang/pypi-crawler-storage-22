"""
dbt-cube-sync: Synchronization tool for dbt models to Cube.js schemas and BI tools
"""

__version__ = "0.1.0"