# DC Path Folder

**Credit:** Original development by **Dai Chao Online**

DC Path Folder is a lightweight Python package for managing device file paths and videos.  
It’s designed for developers who want fast setup, simple APIs, and clean folder handling for Android automation and media tasks.

## Features

- Save and retrieve device-specific paths  
- Count and scan video files in folders  
- Pick random videos and rename them for upload  
- Push files to Android devices via ADB  
- Move and organize videos into target folders  
- Scan and open media on devices  
- Delete local or device files safely  
- Supports Python 3.10+  

## Installation

Install using pip:

```bash
pip install dc-path-folder
