"""
DC VideoManager Toolkit
Original development by Dai Chao Online

A Python utility for managing device video paths, picking random videos,
pushing to Android devices, and handling local video organization.
"""

from dataclasses import dataclass
import os
import json
import glob
import subprocess
import random
import re
import shutil

@dataclass
class DevicePath:
    deviceID: str
    path: str = None
    BASE_DIR = "DevicePaths"
    VIDEO_EXTENSIONS = ('.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.m4v')

    @classmethod
    def _ensure_dir(cls):
        os.makedirs(cls.BASE_DIR, exist_ok=True)

    @classmethod
    def _device_file(cls, deviceID: str):
        return os.path.join(cls.BASE_DIR, f"{deviceID}.json")

    def save_data(self):
        self._ensure_dir()
        file_path = self._device_file(self.deviceID)
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data["path"] == self.path:
                return False

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump({"path": self.path}, f, indent=4)

        return True
    
    def get_paths(self):
        file_path = self._device_file(self.deviceID)
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data["path"]
        return None
    
    def video_count(self):
        path = self.get_paths()
        if not path or not os.path.exists(path):
            return 0

        return sum(
            1
            for root, _, files in os.walk(path)
            for f in files
            if f.lower().endswith(self.VIDEO_EXTENSIONS)
        )
@dataclass        
class VideoManager:
    video_extensions = (
        '.mp4', '.avi', '.mkv',
        '.mov', '.wmv', '.flv',
        '.webm', '.m4v'
    )

    def count_videos_in_folder(self, folder_path):
        matched_videos = []
        for pattern in self.video_extensions:
            matched_videos.extend(glob.glob(os.path.join(folder_path, pattern)))

        return len(matched_videos)

    def pick_and_rename_random_video(self, folder_path):
        try:
            all_files = os.listdir(folder_path)
        except FileNotFoundError:
            return None, None

        video_list = [
            f for f in all_files
            if f.lower().endswith((".mp4", ".avi", ".mkv", ".mov", ".flv"))
        ]

        if not video_list:
            return None, None

        chosen_file = random.choice(video_list)
        old_path = os.path.join(folder_path, chosen_file)
        new_path = os.path.join(folder_path, "upload.mp4")

        try:
            os.rename(old_path, new_path)
        except Exception as err:
            return f"Error: {err}"

        video_path = new_path
        title = os.path.splitext(chosen_file)[0]

        try:
            title = title.split("_", 1)[1]
        except IndexError:
            title = title

        title = re.sub(r"[^a-zA-Z0-9 .\-_]", "", title)
        return video_path, title
    
    def push_file_to_device(self, device_id, local_file_path):
        subprocess.check_call(
            f'adb -s {device_id} push "{local_file_path}" /sdcard/',
            shell=True
        )
        return f"Pushed file to device: {local_file_path}"

    def move_video_to_folder(self, video_path, title):
        base_name = os.path.splitext(video_path)[0]
        target_folder = f"{base_name}ed"
        if not os.path.exists(target_folder):
            os.makedirs(target_folder)
            return f"Created folder: {target_folder}"

        destination_path = os.path.join(target_folder, f"{title}.mp4")
        shutil.move(video_path, destination_path)
        return f"Moved video to: {destination_path}"

    def scan_and_open_media(self, device_id, file_path):
        subprocess.check_output(
            f'adb -s {device_id} shell am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d "file://{file_path}"',
            shell=True
        )
        subprocess.check_output(
            f'adb -s {device_id} shell am start -a android.intent.action.VIEW -d "file://{file_path}" -t "image/*"',
            shell=True
        )
        return f"Scanned and opened file: {file_path}"

    def delete_device_file(self, device_id, remote_file="/sdcard/upload.mp4"):
        subprocess.check_output(
            f'adb -s {device_id} shell rm {remote_file}',
            shell=True
        )
        return f"Deleted file: {remote_file}"
    
    def delete_local_file(self, file_path):
        if os.path.exists(file_path):
            os.remove(file_path)
            return f"Deleted file: {file_path}"
        return f"File not found: {file_path}"