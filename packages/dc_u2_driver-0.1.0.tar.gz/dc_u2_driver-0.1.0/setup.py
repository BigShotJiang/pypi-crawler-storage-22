from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="dc-u2-driver",
    version="0.1.0",
    packages=find_packages(),
    author="Dai Chao Online",
    description="A lightweight Khmer greeting utility for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
)