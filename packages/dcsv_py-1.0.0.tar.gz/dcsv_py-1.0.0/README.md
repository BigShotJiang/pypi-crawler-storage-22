# dcsv.py (Termux Edition)

![Python](https://img.shields.io/badge/Python-3.8%2B-blue)
![Platform](https://img.shields.io/badge/Platform-Termux%20%7C%20Mobile-green)
![Status](https://img.shields.io/badge/Status-Beta-orange)

## 🇹🇷 Hikayem ve Proje Hakkında (Turkish)

**Bu proje sadece bir kod kütüphanesi değil, imkansızlıklar içinde teknolojinin gücüyle nelerin başarılabileceğinin bir kanıtıdır.**

Merhaba. Ben bir engelli bireyim. Herhangi bir yazılım bilgim yok, bir bilgisayarım yok ve fiziksel olarak rahatça çalışabileceğim uygun bir ortamda değilim.

Bu kütüphanenin her bir satırı, sadece bir **cep telefonu** kullanılarak, **Termux** terminali içerisinde ve **Yapay Zeka** desteği ile oluşturulmuştur.

Amacım, benim gibi kısıtlı imkanlara (düşük RAM, sadece mobil cihaz) sahip olanların da Discord botu geliştirebilmesini sağlamaktır. Bu kütüphane, popüler `dcsv.js` kütüphanesinin Python'a uyarlanmış halidir ve "Stackless" (Önbelleksiz) yapısı sayesinde neredeyse hiç RAM tüketmez.

---

## 🇬🇧 About the Author & Project (English)

**This project is not just a code library; it is a testament to perseverance and the power of technology against all odds.**

Hello. I am a disabled individual. I have absolutely no background in programming, I do not own a computer, and I am currently in an environment physically unsuitable for traditional development.

Every single line of this library was created using only a **mobile phone**, running inside the **Termux** terminal, with the assistance of **Artificial Intelligence**.

My goal is to enable others who, like me, have limited resources (low RAM, mobile-only devices) to develop Discord bots. This library is a Python port of the popular `dcsv.js`, and thanks to its "Stackless" architecture, it consumes almost zero RAM.

---

## 🔥 Özellikler / Features

*   **Ultra Hafif:** Sunucuları veya üyeleri hafızada tutmaz (Stackless).
*   **Termux Dostu:** Mobil cihazlarda ve IoT cihazlarında (Raspberry Pi vb.) çalışmak için optimize edildi.
*   **Saf Python:** `aiohttp` dışında ağır bağımlılıklar içermez.
*   **Kolay Kurulum:** `pip` ile hemen kurulabilir.

## 📦 Kurulum / Installation

Termux veya herhangi bir terminal üzerinden:

```bash
pip install dcsv-termux
```

*(Not: Paket ismi yayınlandığında kesinleşecektir, bu bir örnektir)*

## 🚀 Kullanım Örneği / Usage Example

```python
import dcsv 

# Tokeninizi buraya girin / Enter your token here
TOKEN = "YOUR_BOT_TOKEN"

# İstemciyi başlat / Initialize Client
client = dcsv.Client(TOKEN, intents=33280)

@client.on("READY")
async def on_ready(data):
    print(f"✅ Giriş Yapıldı / Logged in: {data['user']['username']}")
    print("📱 Cihaz / Device: Mobile (Termux)")

@client.on("MESSAGE_CREATE")
async def on_message(msg):
    # Botun kendi mesajını yoksay / Ignore bot's own messages
    if msg.get("author", {}).get("bot"):
        return

    content = msg.get("content", "")
    channel_id = msg["channel_id"]

    if content == "!ping":
        # Hızlı cevap / Fast reply
        await client.send_message(channel_id, "🏓 Pong! (Running on Phone via Python)")

client.run()
```

## 🙏 Teşekkür / Credits

*   Orijinal Proje: [dcsv.js](https://github.com/DiscordSunucu/dcsv.js)
*   Geliştirici / Developer: (Yapay Zeka Destekli Termux Kullanıcısı)

---
*Created with ❤️ on a Mobile Phone.*
```
