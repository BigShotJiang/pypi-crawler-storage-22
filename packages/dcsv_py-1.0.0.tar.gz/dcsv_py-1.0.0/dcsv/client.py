import asyncio
import aiohttp
import json
import platform
import time
from .rest import RESTHandler
from .constants import GATEWAY_URL, OpCodes

class Client:
    def __init__(self, token, intents=0):
        self.token = token
        self.intents = intents
        self.rest = RESTHandler(token)
        self.ws = None
        self.listeners = {}
        self.alive = False
        self.sequence = None
        self.session_id = None

    # Node.js: client.on('event', func)
    def on(self, event_name):
        def decorator(func):
            if event_name not in self.listeners:
                self.listeners[event_name] = []
            self.listeners[event_name].append(func)
            return func
        return decorator

    # Event tetikleyici
    async def emit(self, event_name, data):
        if event_name in self.listeners:
            for func in self.listeners[event_name]:
                asyncio.create_task(func(data))

    # API Metodları (Helper Functions)
    async def send_message(self, channel_id, content):
        return await self.rest.request("POST", f"/channels/{channel_id}/messages", {"content": content})

    # WebSocket Bağlantısı (Node.js Logic Portu)
    async def connect(self):
        self.alive = True
        async with aiohttp.ClientSession() as session:
            self.ws = await session.ws_connect(GATEWAY_URL)
            
            while self.alive:
                msg = await self.ws.receive()
                
                if msg.type == aiohttp.WSMsgType.TEXT:
                    payload = json.loads(msg.data)
                    op = payload['op']
                    d = payload['d']
                    t = payload['t']
                    s = payload['s']

                    if s: self.sequence = s

                    if op == OpCodes.HELLO:
                        interval = d['heartbeat_interval'] / 1000
                        asyncio.create_task(self.heartbeat(interval))
                        await self.identify()

                    elif op == OpCodes.DISPATCH:
                        # Event ismini Python stiline çevir (MESSAGE_CREATE -> message_create vb. isteğe bağlı)
                        await self.emit(t, d)

                elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                    print("Bağlantı koptu, yeniden bağlanılıyor...")
                    break

    async def identify(self):
        payload = {
            "op": OpCodes.IDENTIFY,
            "d": {
                "token": self.token,
                "intents": self.intents,
                "properties": {
                    "$os": platform.system(),
                    "$browser": "dcsv",
                    "$device": "dcsv"
                }
            }
        }
        await self.ws.send_json(payload)

    async def heartbeat(self, interval):
        while self.alive:
            await asyncio.sleep(interval)
            payload = {"op": OpCodes.HEARTBEAT, "d": self.sequence}
            await self.ws.send_json(payload)

    def run(self):
        loop = asyncio.get_event_loop()
        try:
            loop.run_until_complete(self.connect())
        except KeyboardInterrupt:
            self.alive = False
