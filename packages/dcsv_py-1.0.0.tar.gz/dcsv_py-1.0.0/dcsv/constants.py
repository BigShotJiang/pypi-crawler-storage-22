GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"
API_URL = "https://discord.com/api/v10"
USER_AGENT = "DiscordBot (dcsv.py, 1.0.0)"

class OpCodes:
    DISPATCH = 0
    HEARTBEAT = 1
    IDENTIFY = 2
    HELLO = 10
    HEARTBEAT_ACK = 11
