import aiohttp
import asyncio
import json
from .constants import API_URL, USER_AGENT

class RESTHandler:
    def __init__(self, token):
        self.token = token
        self.headers = {
            "Authorization": f"Bot {token}",
            "User-Agent": USER_AGENT,
            "Content-Type": "application/json"
        }

    async def request(self, method, endpoint, data=None):
        url = API_URL + endpoint
        async with aiohttp.ClientSession() as session:
            while True:
                async with session.request(method, url, headers=self.headers, json=data) as response:
                    # Rate Limit Kontrolü (Node.js'teki logic ile aynı)
                    if response.status == 429:
                        resp_data = await response.json()
                        retry_after = resp_data.get("retry_after", 1)
                        print(f"Rate limit! Bekleniyor: {retry_after}s")
                        await asyncio.sleep(retry_after)
                        continue
                    
                    if 200 <= response.status < 300:
                        try:
                            return await response.json()
                        except:
                            return None
                    else:
                        print(f"API Hatası: {response.status} - {await response.text()}")
                        return None
