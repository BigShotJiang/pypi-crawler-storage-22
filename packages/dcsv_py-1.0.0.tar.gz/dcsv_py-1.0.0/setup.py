from setuptools import setup, find_packages

# README dosyasını okuyup açıklama olarak ekler
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='dcsv_py',
    version='1.0.0',
    
    # Kısa açıklama
    description='A stackless Discord library ported from Node.js on Termux by a disabled developer using AI.',
    
    # Uzun açıklama (README.md dosyasından çekilir)
    long_description=long_description,
    long_description_content_type="text/markdown",
    
    # Proje Linki
    url='https://github.com/DiscordSunucu/dcsv.js',
    
    # Yazar
    author='Miraç Birben',
    
    # Klasörleri otomatik bulur
    packages=find_packages(),
    
    # Gerekli bağımlılıklar
    install_requires=[
        'aiohttp>=3.8.0',
    ],
    
    # Kategoriler
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Communications :: Chat",
    ],
    
    python_requires='>=3.8',
)
