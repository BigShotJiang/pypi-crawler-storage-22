# dcTrackClient [![GitHub Workflow Status](https://img.shields.io/github/actions/workflow/status/nicfv/dcTrackClient/publish.yml?logo=github)](https://github.com/nicfv/dcTrackClient) [![PyPI](https://img.shields.io/pypi/v/dcTrackClient)](https://pypi.org/project/dcTrackClient/) [![PyPI - Downloads](https://img.shields.io/pypi/dm/dcTrackClient?logo=pypi)](https://pypi.org/project/dcTrackClient/) [![npm](https://img.shields.io/npm/v/dctrackclient)](https://www.npmjs.com/package/dctrackclient) [![npm](https://img.shields.io/npm/dt/dctrackclient?logo=npm)](https://www.npmjs.com/package/dctrackclient)
Sunbird [dcTrack](https://www.sunbirddcim.com/) API clients in Python and JavaScript

## Installation
> dcTrackClient can be installed from the package manager of your choice.

### Python
```shell
pip install dcTrackClient==1.5.1
```

### JavaScript
```shell
npm i dctrackclient@1.5.1
```

## Initialize a connection to the dcTrack API
> Authentication is by using a base URL (the same URL to access the GUI) and a username and password, or a base URL and an API token.

### Python
```py
from dcTrackClient import Client
## Using a username and password ##
api = Client('https://dctrack.example.com/', username='user', password='pass')
## Using an API token ##
api = Client('https://dctrack.example.com/', apiToken='token')
```

### JavaScript
```js
import { Client } from 'dctrackclient';
// Using a username and password // 
const api = new Client('https://dctrack.example.com/', { username: 'user', password: 'pass' });
// Using an API token //
const api = new Client('https://dctrack.example.com/', { apiToken: 'token' });
```

## Advanced: Initialize a connection with a proxy
> Proxies can be used for either authentication method (username/password or API token) for both libraries. For the Python library, specify an HTTP or HTTPS proxy, or both. These can also be SOCKS proxies. For the JavaScript library, only 1 proxy is required and `https` proxies can either be HTTP or HTTPS. HTTPS will automatically upgraded to TLS.

### Python
```py
api = Client('https://dctrack.example.com/', username='user', password='pass', httpProxy='http://proxy:port', httpsProxy='https://proxy:port')
```

### JavaScript
```js
const api = new Client('https://dctrack.example.com/', { username: 'user', password: 'pass' }, { https: 'http://proxy:port', socks: 'socks://proxy:port' });
```

In Python, you can use the `sslVerify=True/False` argument to toggle whether SSL/TLS certificates are verified on the server. For JavaScript, toggle off this environment variable `export NODE_TLS_REJECT_UNAUTHORIZED=0` before executing the script.

## Obtain an API Token
> Obtain an API token using the `Client.generateToken()` function provided. Re-authentication is not necessary, as the API token will automatically be used in subsequent API calls. The function returns the token's value in case the user wants to store the token for the next initialization of the API.

### Python
```py
token = api.generateToken()
```

### JavaScript
Notice the `await` keyword before the function call. This is because the JavaScript library is asynchronous and returns a `Promise` to the return value. All the API calls in this library require that keyword.
```js
const token = await api.generateToken();
```

# Usage Example
This section demonstrates item manipulation with the API client.

## Create an item
> This example shows the minimum attributes required to create an item using the [`createItem`](#createitemreturndetails-payload) function. View the comprehensive list of item attributes in the [official documentation](#official-dctrack-documentation). Make sure to capture the return value of this function to see the created item details, such as the unique numeric item ID, or to determine if an error occurred while creating an item.

### Python
```py
# Set `returnDetails = True` to return the complete item field list.
response = api.createItem(False, {
    'cmbLocation': 'item location',
    'tiName': 'item name',
    'cmbMake': 'item make',
    'cmbModel': 'item model'
})
print(response)
```

### JavaScript
See the JavaScript section on [obtaining an API token](#obtain-an-api-token) why the `await` keyword is required.
```js
// Set `returnDetails = true` to return the complete item field list.
let response = await api.createItem(false, {
    'cmbLocation': 'item location',
    'tiName': 'item name',
    'cmbMake': 'item make',
    'cmbModel': 'item model'
});
console.log(response);
```

### On Success
This function returns the JSON object for the newly created item. This is an example response if `returnDetails` was set to false.
```json
{ "item": { "id": 1234, "tiName": "item name" } }
```

### On Failure
This function returns a JSON object containing the error message.

## Retrieve item details
> This example shows the usage of the [`getItem`](#getitemid) function. This function requires the unique item's ID, shown in the [create item](#create-an-item) example. It returns the full list of item attributes.

### Python
```py
response = api.getItem(1234)
```

### JavaScript
```js
let response = await api.getItem(1234);
```

### Returns
```json
{
    "item": {
        "cmbLocation": "item location",
        "tiName": "item name",
        ...
    }
}
```

## Modify an existing item
> This example shows the usage of the [`updateItem`](#updateitemid-returndetails-payload) function. Any number of attributes can be included in the payload to be modified. The `returnDetails` parameter behaves in the same way as in the [create item](#create-an-item) example.

### Python
```py
response = api.updateItem(1234, False, {'tiSerialNumber': 12345})
```

### JavaScript
```js
let response = await api.updateItem(1234, false, { 'tiSerialNumber': 12345 });
```

## Search for an item
> This example demonstrates usage of the [`searchItems`](#searchitemspagenumber-pagesize-payload) function. Follow [this guide](https://www.sunbirddcim.com/help/dcTrack/v900/API/en/Default.htm#APIGuide/v2_Advanced_Search_API.htm) for details on creating the request payload. In this example, the API searches for an item based on the `tiName` field.

### Python
```py
response = api.searchItems(0, 0, {
    'columns': [
        {'name': 'tiName', 'filter': {'eq': 'item name'}}
    ],
    'selectedColumns': [
        {'name': 'id'},
        {'name': 'tiName'},
    ]
})
```

### JavaScript
```js
let response = await api.searchItems(0, 0, {
    'columns': [
        { 'name': 'tiName', 'filter': { 'eq': 'item name' } }
    ],
    'selectedColumns': [
        { 'name': 'id' },
        { 'name': 'tiName' },
    ]
});
```

### Returns
```json
{
    "selectedColumns": [],
    "totalRows": 1,
    "pageNumber": 0,
    "pageSize": 0,
    "searchResults": {
        "items": [
            {"id": "1234", "tiName": "item name"}
        ]
    }
}
```

## Delete an item
> This example demonstrates usage of the [`deleteItem`](#deleteitemid) function.

### Python
```py
api.deleteItem(1234)
```

### JavaScript
```js
await api.deleteItem(1234);
```

### Returns
```json
{ "itemId": 1234 }
```

# Official DcTrack Documentation

Visit this link for the official documentation on request bodies and attrribute names.

https://www.sunbirddcim.com/help/dcTrack/v930/API/en/Default.htm

# Package Documentation

The section below shows all the functions contained within this client along with basic usage.

## getItem(id)
> Get item details using the item ID. Returns an Item JSON object.
```
GET api/v2/dcimoperations/items/{id}
```
|Parameter|Type|
|---|---|
|id|number|

## createItem(returnDetails, proceedOnWarning, payload)
> Create a new item. When returnDetails is set to true, the API call will return the full json payload. If set to false, the call returns only the "id" and "tiName". Returns the newly created item JSON object.
```
POST api/v2/dcimoperations/items payload
```
|Parameter|Type|
|---|---|
|returnDetails|boolean|
|proceedOnWarning|boolean|
|payload|object|

## updateItem(id, returnDetails, proceedOnWarning, payload)
> Update an existing item. When returnDetails is set to true, the API call will return the full json payload. If set to false, the call returns only the "id" and "tiName".
```
PUT api/v2/dcimoperations/items/{id} payload
```
|Parameter|Type|
|---|---|
|id|number|
|returnDetails|boolean|
|proceedOnWarning|boolean|
|payload|object|

## deleteItem(id, proceedOnWarning)
> Delete an item using the item ID.
```
DELETE api/v2/dcimoperations/items/{id}
```
|Parameter|Type|
|---|---|
|id|number|
|proceedOnWarning|boolean|

## searchItems(pageNumber, pageSize, payload)
> Search for items using criteria JSON object. Search criteria can be any of the fields applicable to items, including custom fields. Specify the fields to be included in the response. This API supports pagination. Returns a list of items with the specified information.
```
POST api/v2/quicksearch/items payload
```
|Parameter|Type|
|---|---|
|pageNumber|number|
|pageSize|number|
|payload|object|

## getCabinetItems(CabinetId)
> Returns a list of Items contained in a Cabinet using the ItemID of the Cabinet. The returned list includes all of the Cabinet's Items including Passive Items.
```
GET api/v2/items/cabinetItems/{CabinetId}
```
|Parameter|Type|
|---|---|
|CabinetId|number|

## createItemsBulk(payload)
> Add/Update/Delete Items.
```
POST api/v2/dcimoperations/items/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## getMakes()
> Returns a list of makes with basic information.
```
GET api/v2/makes
```
*No parameters.*

## getMake(makeName)
> Search for one or more makes using a single make name.
```
GET api/v2/makes
```
|Parameter|Type|
|---|---|
|makeName|string|

## createMake(payload)
> Add a new Make. Returns JSON entity containing Make information that was passed in from the Request payload.
```
POST api/v2/makes payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updateMake(makeId, payload)
> Modify a Make. Returns JSON entity containing Make information that was passed in from the Request payload.
```
PUT api/v2/makes/{makeId} payload
```
|Parameter|Type|
|---|---|
|makeId|number|
|payload|object|

## deleteMake(makeId)
> Delete a Make.
```
DELETE api/v2/makes/{makeId}
```
|Parameter|Type|
|---|---|
|makeId|number|

## searchMakes(payload)
> Search for a make using the make name and special characters.
```
POST api/v2/dcimoperations/search/list/makes payload
```
|Parameter|Type|
|---|---|
|payload|object|

## getModel(modelId, usedCounts)
> Get Model fields for the specified Model ID. usedCounts is an optional parameter that determines if the count of Items for the specified model is returned in the response. If set to "true" the counts will be included in the response, if omitted or set to "false" the item count will not be included in the response.
```
GET api/v2/models/{modelId}
```
|Parameter|Type|
|---|---|
|modelId|number|
|usedCounts|boolean|

## createModel(returnDetails, proceedOnWarning, payload)
> Add a new Model. Returns JSON entity containing Make information that was passed in from the Request payload. "proceedOnWarning" relates to the warning messages that are thrown in dcTrack when you try to delete custom fields that are in use. The "proceedOnWarning" value can equal either "true" or "false." If "proceedOnWarning" equals "true," business warnings will be ignored. If "proceedOnWarning" equals "false," business warnings will not be ignored. Fields that are not in the payload will remain unchanged.
```
POST api/v2/models payload
```
|Parameter|Type|
|---|---|
|returnDetails|boolean|
|proceedOnWarning|boolean|
|payload|object|

## updateModel(id, returnDetails, proceedOnWarning, payload)
> Modify an existing Model. Fields that are not in the payload will remain unchanged. Returns a JSON entity containing Make information that was passed in from the Request payload. This API performs as a PUT and not a PATCH. For example, the Request includes the dataPorts list but nothing inside it, the data ports will be removed, or you include a new port in the list , but not the current port on the device, it will remove the port that already exists and create a new port.
```
PUT api/v2/models/{id} payload
```
|Parameter|Type|
|---|---|
|id|number|
|returnDetails|boolean|
|proceedOnWarning|boolean|
|payload|object|

## modifyModel(id, returnDetails, proceedOnWarning, payload)
> Modify an existing Model. This is currently being released as a Beta version for early release and is subject to change.
```
PATCH api/v2/models/{id} payload
```
|Parameter|Type|
|---|---|
|id|number|
|returnDetails|boolean|
|proceedOnWarning|boolean|
|payload|object|

## deleteModel(id)
> Delete a Model using the Model ID.
```
DELETE api/v2/models/{id}
```
|Parameter|Type|
|---|---|
|id|number|

## searchModels(pageNumber, pageSize, payload)
> Search for models by user supplied search criteria. Returns a list of models with the "selectedColumns" returned in the payload. Search by Alias is not supported.
```
POST api/v2/quicksearch/models payload
```
|Parameter|Type|
|---|---|
|pageNumber|number|
|pageSize|number|
|payload|object|

## deleteModelImage(id, orientation)
> Delete a Mode Image using the Model ID and the Image Orientation, where id is the Model Id and orientation is either front or back
```
DELETE api/v2/models/images/{id}/{orientation}
```
|Parameter|Type|
|---|---|
|id|number|
|orientation|string|

## getConnector(connectorId, usedCount)
> Get a Connector record by ID. Returns a Connector with all information including Compatible Connectors. The usedCount parameter is optional. If usedCount is true, the response will include the number of times the connector is in use by Models and Items. If false, no counts are returned. If omitted the default is false.
```
GET api/v2/settings/connectors/{connectorId}
```
|Parameter|Type|
|---|---|
|connectorId|number|
|usedCount|boolean|

## createConnector(payload)
> Add a new Connector. Returns JSON entity containing Connector information that was passed in from the Request payload.
```
POST api/v2/settings/connectors payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updateConnector(connectorId, payload)
> Update an existing Connector. Returns JSON entity containing Connector information that was passed in from the Request payload.
```
PUT api/v2/settings/connectors/{connectorId} payload
```
|Parameter|Type|
|---|---|
|connectorId|number|
|payload|object|

## removeConnector(payload)
> Delete one or more Connector records.
```
POST api/v2/settings/connectors/delete payload
```
|Parameter|Type|
|---|---|
|payload|object|

## searchConnectors(pageNumber, pageSize, payload)
> Search for Connectors using criteria JSON object. Search criteria can be any of the fields applicable to Connector, including custom fields. Specify the fields to be included in the response. This API supports pagination. Returns a list of Connectors with the specified information.
```
POST api/v2/quicksearch/connectors payload
```
|Parameter|Type|
|---|---|
|pageNumber|number|
|pageSize|number|
|payload|object|

## deleteConnectorImage(connectorId)
> Delete a Connector Image using the Connector ID.
```
DELETE api/v2/settings/connectors/{connectorId}/images
```
|Parameter|Type|
|---|---|
|connectorId|number|

## getDataPorts(itemId)
> Use the REST API to retrieve details from all data ports on an item. If the operation was successful, a status code 200 is displayed, and the body contains the item's data port details. If the operation failed, an error code is returned.
```
GET api/v2/dcimoperations/items/{itemId}/dataports
```
|Parameter|Type|
|---|---|
|itemId|number|

## getDataPort(itemId, portId)
> Use the REST API to read the details of an item's data port. To do this, specify the item and item data port ID. If the operation was successful, a status code 200 is displayed, and the body contains the item's data port details. If the operation failed, an error code is returned.
```
GET api/v2/dcimoperations/items/{itemId}/dataports/{portId}
```
|Parameter|Type|
|---|---|
|itemId|number|
|portId|number|

## createDataPorts(itemId, payload)
> Use the REST API to create data ports for an existing item. If ports are already defined for the item because it is included in the Item Models Library, you can use the REST API to create additional ports for the item. Payload contains data port parameter details in json format. All required fields must be included.
```
POST api/v2/dcimoperations/items/{itemId}/dataports payload
```
|Parameter|Type|
|---|---|
|itemId|number|
|payload|object|

## updateDataPort(itemId, portId, payload)
> Update an item's data port details using the REST API. To do this, specify the item and data port ID, and provide the updated parameter value(s). Payload contains data port parameter details in json format. All required fields must be included.
```
PUT api/v2/dcimoperations/items/{itemId}/dataports/{portId} payload
```
|Parameter|Type|
|---|---|
|itemId|number|
|portId|number|
|payload|object|

## deleteDataPort(itemId, portId)
> Delete an item's data port using the REST API by specifying the item ID and data port ID. If the operation is successful, a status code 200 is displayed. If the operation failed, an error code is returned.
```
DELETE api/v2/dcimoperations/items/{itemId}/dataports/{portId}
```
|Parameter|Type|
|---|---|
|itemId|number|
|portId|number|

## getPowerPorts(itemId)
> Use the REST API to retrieve details from all power ports on an item.
```
GET api/v1/items/{itemId}/powerports
```
|Parameter|Type|
|---|---|
|itemId|number|

## getPowerPort(itemId, portId)
> Use the REST API to retrieve details from one power port on an item.
```
GET api/v1/items/{itemId}/powerports/{portId}
```
|Parameter|Type|
|---|---|
|itemId|number|
|portId|number|

## updatePowerPort(itemId, portId, proceedOnWarning, payload)
> Use the REST API to create power ports for an existing item. If ports are already defined for the item because it is included in the Item Models Library, you can use the REST API to create additional ports for the item.
```
PUT api/v1/items/{itemId}/powerports/{portId} payload
```
|Parameter|Type|
|---|---|
|itemId|number|
|portId|number|
|proceedOnWarning|boolean|
|payload|object|

## getCompatibleConnector(itemId, portId, connectorId)
> Use the REST API to determine if a Connector is compatible with a specific Power Port.
```
GET api/v1/items/{itemId}/powerports/{portId}/connectors/{connectorId}/isCompatible
```
|Parameter|Type|
|---|---|
|itemId|number|
|portId|number|
|connectorId|number|

## getBreakers(panelItemId)
> Get a list of all Breakers for a given Panel Item. Returns JSON entity containing an array of all the Breakers for the specified Panel Item.
```
GET api/v2/dcimoperations/items/{panelItemId}/breakers
```
|Parameter|Type|
|---|---|
|panelItemId|number|

## getBreaker(panelItemId, breakerPortId)
> Get a list of all Breakers for a given Panel Item. Returns JSON entity containing information for a single Panel Item Breaker.
```
GET api/v2/dcimoperations/items/{panelItemId}/breakers/{breakerPortId}
```
|Parameter|Type|
|---|---|
|panelItemId|number|
|breakerPortId|number|

## updateBreaker(panelItemId, breakerPortId, payload)
> Update a single Breaker for a given Panel Item. Returns JSON entity containing information for the updated Panel Item Breaker. Note: This API performs as a true PUT and not a PATCH. Unlike with a PATCH, you must specify all attributes even if you want to change only one. Attributes that are not included in the Request will be considered as removed.
```
PUT api/v2/dcimoperations/items/{panelItemId}/breakers/{breakerPortId} payload
```
|Parameter|Type|
|---|---|
|panelItemId|number|
|breakerPortId|number|
|payload|object|

## createBreaker(panelItemId, payload)
> Create a single Breaker for a given Panel Item. Returns JSON entity containing information for the created Panel Item Breaker. Note: Breaker State is set based on the connection status of the Breaker. If the breaker is connected it will always be set to "Closed", even if "Open" is specified in the Request.
```
POST api/v2/dcimoperations/items/{panelItemId}/breakers payload
```
|Parameter|Type|
|---|---|
|panelItemId|number|
|payload|object|

## deleteBreaker(panelItemId, breakerPortId)
> Delete a Breaker for a given Panel Item. Returns empty JSON.
```
DELETE api/v2/dcimoperations/items/{panelItemId}/breakers/{breakerPortId}
```
|Parameter|Type|
|---|---|
|panelItemId|number|
|breakerPortId|number|

## createBreakersBulk(panelItemId, payload)
> Add/Update/Delete Breakers for a given Panel Item.
```
POST api/v2/dcimoperations/items/{panelItemId}/breakers/bulk payload
```
|Parameter|Type|
|---|---|
|panelItemId|number|
|payload|object|

## getLocations()
> Returns a list for all Locations.
```
GET api/v1/locations
```
*No parameters.*

## getLocation(locationId)
> Get a single Location. Returns json containing location data for the specified ID.
```
GET api/v1/locations{locationId}
```
|Parameter|Type|
|---|---|
|locationId|number|

## createLocation(proceedOnWarning, payload)
> Add a Location. Returns the JSON entity containing location info that was passed in. Note: "proceedOnWarning" relates to the warning messages that are thrown in dcTrack when you try to delete custom fields that are in use. The "proceedOnWarning" value can equal either "true" or "false." If "proceedOnWarning" equals "true," business warnings will be ignored. If "proceedOnWarning" equals "false," business warnings will not be ignored.
```
POST api/v1/locations payload
```
|Parameter|Type|
|---|---|
|proceedOnWarning|boolean|
|payload|object|

## updateLocation(locationId, proceedOnWarning, payload)
> Modify Location details for a single Location. Payload contains new location details. You do not have have to provide all details, but only those that you want to modify. Returns JSON entity containing Location information that was passed in from the Request payload.
```
PUT api/v1/locations/{locationId} payload
```
|Parameter|Type|
|---|---|
|locationId|number|
|proceedOnWarning|boolean|
|payload|object|

## deleteLocation(locationId)
> Delete a Location.
```
DELETE api/v1/locations/{locationId}
```
|Parameter|Type|
|---|---|
|locationId|number|

## searchLocations(pageNumber, pageSize, payload)
> Search for Locations by user supplied search criteria. Returns a list of Locations with the "selectedColumns" returned in the payload.
```
POST api/v2/quicksearch/locations payload
```
|Parameter|Type|
|---|---|
|pageNumber|number|
|pageSize|number|
|payload|object|

## getLocationFieldList()
> Returns a list of all Location fields.
```
GET api/v2/quicksearch/locations/locationListFields
```
*No parameters.*

## getSublocations(locationId)
> Get all sub-locations for a given location in the hierarchy. The locationId is the ID of the location to get the sub-locations for.
```
GET api/v2/subLocations/list/{locationId}
```
|Parameter|Type|
|---|---|
|locationId|number|

## getSublocationsOfType(locationId, typeCode)
> Get all sub-locations of given type for a given location in the hierarchy. The locationId is the id of the location you are querying the sub-location types for. The type is one of either 5016 and 5017 for rows and aisles respectively.
```
GET api/v2/subLocations/{locationId}/type/{typeCode}
```
|Parameter|Type|
|---|---|
|locationId|number|
|typeCode|string|

## getChildSublocations(subLocationId)
> Get all child sub-locations for a given sub-location in the hierarchy. The locationId is the ID of the location to fetch the sub-locations for. The subLocationId is the ID of the parent sub-location that you are querying the children of.
```
GET api/v2/subLocations/{subLocationId}/children
```
|Parameter|Type|
|---|---|
|subLocationId|number|

## getSublocation(subLocationId)
> Get details for a given sub-location. The subLocationId is the id of the sub-location you are querying for.
```
GET api/v2/subLocations/{subLocationId}
```
|Parameter|Type|
|---|---|
|subLocationId|number|

## createSublocation(payload)
> Add a new sub-location to the given location. Returns a list from the Sub-Location Hash.
```
POST api/v2/subLocations payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updateSublocation(subLocationId, payload)
> Update a sub-location. Returns a list from the Sub-Location Hash.
```
PUT api/v2/subLocations/{subLocationId} payload
```
|Parameter|Type|
|---|---|
|subLocationId|number|
|payload|object|

## deleteSublocation(subLocationId)
> Deletes the given sub-location. The locationId is the ID of the location that the sub-location belongs to and the subLocationId is the ID of the location you are querying. Returns a success message upon success.
```
DELETE api/v2/subLocations/{subLocationId}
```
|Parameter|Type|
|---|---|
|subLocationId|number|

## getLocationFavorites(username)
> Retrieve a List of Location Favorites for a specific User.
```
GET api/v2/users/{username}/favorites/LOCATION
```
|Parameter|Type|
|---|---|
|username|string|

## getLocationFavoritesAllUsers()
> Retrieve a List of Location Favorites for all Users. Returns JSON entity containing Location Favorite information for all users.
```
GET api/v2/users/favorites/LOCATION
```
*No parameters.*

## updateLocationFavorites(username, payload)
> Assign Location Favorites to a user where username is a valid dcTrack user and "favorite" is either true or false to indicate whether you are assigning or unassigning. JSON entity containing all Location Favorites for the specified user.
```
PUT api/v2/users/{username}/favorites payload
```
|Parameter|Type|
|---|---|
|username|string|
|payload|object|

## updateLocationFavoritesAllUsers(payload)
> Assign Location Favorites to a user. To Assign favorites the "favorite" column should be set to true. To Unassign favorites the "favorite" column should be set to false. Returns JSON entity containing all Location Favorites for the specified users.
```
PUT api/v2/users/favorites payload
```
|Parameter|Type|
|---|---|
|payload|object|

## searchCabinetSpace(payload)
> Find Cabinets with available space based on RUs within the specified Locations.
```
POST api/v2/capacity/cabinets/list/search payload
```
|Parameter|Type|
|---|---|
|payload|object|

## searchAvailableRUs(payload)
> Find the starting RUs within a Cabinet with the specified number of contiguous RUs.
```
POST api/v2/items/uposition/available payload
```
|Parameter|Type|
|---|---|
|payload|object|

## getPermission(permissionId)
> Get explicit permission by ID. Returns JSON entity containing Permission information for the specified Permission Id.
```
GET api/v2/permissions/explicit/{permissionId}
```
|Parameter|Type|
|---|---|
|permissionId|number|

## createPermission(payload)
> Add explicit permission. Returns JSON entity containing Permission information for the added Permission.
```
POST api/v2/permissions/explicit payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updatePermission(permissionId, payload)
> Update explicit permission. Returns JSON entity containing Permission information for the updated Permission.
```
PUT api/v2/permissions/explicit/{permissionId} payload
```
|Parameter|Type|
|---|---|
|permissionId|number|
|payload|object|

## deletePermission(permissionId)
> Delete explicit permission.
```
DELETE api/v2/permissions/explicit/{permissionId}
```
|Parameter|Type|
|---|---|
|permissionId|number|

## createPermissionsBulk(payload)
> Add/Update/Delete explicit permissions.
```
POST api/v2/permissions/explicit/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## getPermissions()
> Get all explicit permissions. Returns JSON entity containing Permission information.
```
GET api/v2/permissions/explicit
```
*No parameters.*

## getPermissionsByEntityType(entityType)
> Get explicit permissions by Entity Type. Returns JSON entity containing Permission information.
```
GET api/v2/permissions/explicit/entityType/{entityType}
```
|Parameter|Type|
|---|---|
|entityType|string|

## getPermissionsByEntityId(entityType, entityId)
> Get explicit permissions by Entity Type and Entity ID. Returns JSON entity containing Permission information.
```
GET api/v2/permissions/explicit/{entityType}/{entityId}
```
|Parameter|Type|
|---|---|
|entityType|string|
|entityId|number|

## getRecords(listType, id)
> Get a list of records (options) for use in drop-down lists by indicating a list type and an ID. ID is optional for some list types. Returns a list of records for a given list type.
```
GET api/v2/dcimoperations/lookups/{listType}/{id}
```
|Parameter|Type|
|---|---|
|listType|string|
|id|number|

## getPicklistOptions(listType)
> Get a list of records (options) for use in drop-down lists for dcTrack standard fields by list type. Returns a list of records for a given list type.
```
GET api/v2/dcimoperations/picklists/{listType}
```
|Parameter|Type|
|---|---|
|listType|string|

## updatePicklistOptions(listType, payload)
> Update a list of records (options) for use in drop-down lists for dcTrack standard fields by list type. Returns a list of records for a given list type.
```
PUT api/v2/dcimoperations/picklists/{listType} payload
```
|Parameter|Type|
|---|---|
|listType|string|
|payload|object|

## updateDefaultValue(payload)
> Update the default value for a picklist field.
```
PUT api/v2/settings/lists/defaultValue payload
```
|Parameter|Type|
|---|---|
|payload|object|

## getFieldProperties(entity)
> Get the properties for all fields applicable to the Entity.
```
GET api/v2/settings/lists/fieldProperties
```
|Parameter|Type|
|---|---|
|entity|string|

## createRequest(payload)
> Create a request.
```
POST api/v2/dcimoperations/requests payload
```
|Parameter|Type|
|---|---|
|payload|object|

## deleteRequest(requestId)
> Cancel a request. Returns Returns request ID canceled.
```
DELETE api/v2/dcimoperations/requests/{requestId}
```
|Parameter|Type|
|---|---|
|requestId|number|

## createRequestBulk(payload)
> Add/Update/Delete Requests in Bulk. The body of the Request should contain the required fields required to perform the specified Method. Returns JSON entity containing data for the Requests.
```
POST api/v2/dcimoperations/requests/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## completeRequest(requestId, payload)
> Change request status/stage to Complete using the request ID. Optionally, pass a request body with additional information. Returns request status information.
```
PUT api/v2/dcimoperations/requests/complete/{requestId} payload
```
|Parameter|Type|
|---|---|
|requestId|number|
|payload|object|

## completeWorkOrder(workOrderId, payload)
> Complete work order and change work order status/stage to Complete. Optionally, pass a request body with additional information. Returns work order status information.
```
PUT api/v2/dcimoperations/workorders/complete/{workOrderId} payload
```
|Parameter|Type|
|---|---|
|workOrderId|number|
|payload|object|

## getRequestStatusByItem(itemId)
> Get a list of pending request status information for a given item ID. Returns list of request status.
```
GET api/v2/dcimoperations/requests/pending/{itemId}
```
|Parameter|Type|
|---|---|
|itemId|number|

## getRequest(requestId)
> Get request status information for a given request ID. Returns full request status information.
```
GET api/v2/dcimoperations/requests/status/{requestId}
```
|Parameter|Type|
|---|---|
|requestId|number|

## searchRequests(payload)
> Get request status information for a given request ID. Returns full request status information.
```
POST api/v2/dcimoperations/search/list/requests payload
```
|Parameter|Type|
|---|---|
|payload|object|

## createDataConnection(payload)
> Create a data connection. Returns the newly created data connection.
```
POST api/v2/connections/dataconnections payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updateDataConnection(connectionId, payload)
> Edit a data connection. Returns the newly edited data connection.
```
PUT api/v2/connections/dataconnections/{connectionId} payload
```
|Parameter|Type|
|---|---|
|connectionId|number|
|payload|object|

## getDataConnection(connectionId)
> Get a data connection and associated details. Requires the ID of the connection you want to retrieve. Returns the requested data connection and associated details.
```
GET api/v2/connections/dataconnections/{connectionId}
```
|Parameter|Type|
|---|---|
|connectionId|number|

## getDataConnectionByNode(location, itemName, portName)
> Get data connection details based on the specified location, item name, and port name. The itemName specified in the URL must be either the starting or ending Item in the connection. This API does not support Data Panel Ports. Returns the JSON payload with the requested data connection details.
```
GET api/v2/connections/dataconnections
```
|Parameter|Type|
|---|---|
|location|string|
|itemName|string|
|portName|string|

## deleteDataConnection(connectionId)
> Deletes the specified data connection.
```
DELETE api/v2/connections/dataconnections/{connectionId}
```
|Parameter|Type|
|---|---|
|connectionId|number|

## createPowerConnection(payload)
> Create a power connection. Returns the newly created power connection.
```
POST api/v2/connections/powerconnections payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updatePowerConnection(connectionId, payload)
> Edit a power connection. Returns the newly edited power connection.
```
PUT api/v2/connections/powerconnections/{connectionId} payload
```
|Parameter|Type|
|---|---|
|connectionId|number|
|payload|object|

## getPowerConnection(connectionId)
> Get a power connection and associated details. Requires the ID of the connection you want to retrieve. Returns the requested power connection and associated details.
```
GET api/v2/connections/powerconnections/{connectionId}
```
|Parameter|Type|
|---|---|
|connectionId|number|

## getPowerConnectionByNode(location, itemName, portName)
> Get power connection details based on the specified location, item name, and port name. Returns the JSON payload with the requested power connection details.
```
GET api/v2/connections/powerconnections
```
|Parameter|Type|
|---|---|
|location|string|
|itemName|string|
|portName|string|

## deletePowerConnection(connectionId)
> Deletes the specified power connection. Deletes the power connection.
```
DELETE api/v2/connections/powerconnections/{connectionId}
```
|Parameter|Type|
|---|---|
|connectionId|number|

## getCircuit(circuitType, location, itemName, portName)
> Get power or data circuit details based on the specified circuit type location, item name, and port name. Returns the JSON payload with the requested power or data connection details.
```
GET api/v2/dcimoperations/circuits/{circuitType}
```
|Parameter|Type|
|---|---|
|circuitType|string|
|location|string|
|itemName|string|
|portName|string|

## retrievePowerChain(locationId, payload)
> Get links and nodes of entire power chain with customizable node details for a specific location. JSON entity containing data for the entire Power Chain for a given Location. The example below illustrates returning all fields by leaving the "selectedColumn" array empty. To limit the columns in the response, list the specific columns.
```
POST api/v2/powerChain/{locationId} payload
```
|Parameter|Type|
|---|---|
|locationId|number|
|payload|object|

## retrievePowerSumForPorts(payload)
> Get power sum for power ports with port ID list.
```
POST api/v2/powerChain/powerSum/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## retrievePowerSumForItems(payload)
> Get power sum for power ports using item ID list.
```
POST api/v2/items/powerSum/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## getActualReadingsByItem(itemId)
> Update Actual Readings for Power Ports for an Item.
```
GET api/v2/powerChain/items/actualReadings/{itemId}
```
|Parameter|Type|
|---|---|
|itemId|number|

## retrieveActualReadingsByItems(payload)
> Retrieve Actual Readings for Power Ports for multiple Items.
```
POST api/v2/powerChain/items/actualReadings/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## retrieveActualReadingsByPorts(payload)
> Update Actual Readings for Power Ports on one or more items.
```
POST api/v2/powerChain/ports/actualReadings/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updateActualReadingsByPort(portId, payload)
> Update Actual Readings By Port.
```
PUT api/v2/powerChain/ports/actualReadings/{portId} payload
```
|Parameter|Type|
|---|---|
|portId|number|
|payload|object|

## getActualReadingsByPort(portId)
> Get Actual Readings By Port.
```
GET api/v2/powerChain/ports/actualReadings/{portId}
```
|Parameter|Type|
|---|---|
|portId|number|

## getTicket(ticketId)
> Get Ticket by Ticket ID.
```
GET api/v2/tickets/{ticketId}
```
|Parameter|Type|
|---|---|
|ticketId|number|

## createTicket(payload)
> Create a Ticket.
```
POST api/v2/tickets payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updateTicket(ticketId, payload)
> Update a Ticket.
```
PUT api/v2/tickets/{ticketId} payload
```
|Parameter|Type|
|---|---|
|ticketId|number|
|payload|object|

## deleteTicket(ticketId, proceedOnWarning)
> Delete Ticket by Ticket ID.
```
DELETE api/v2/tickets/{ticketId}
```
|Parameter|Type|
|---|---|
|ticketId|number|
|proceedOnWarning|boolean|

## searchTickets(pageNumber, pageSize, payload)
> Search for Tickets using criteria JSON object. Search criteria can be any of the fields applicable to Tickets, including custom fields. Specify the fields to be included in the response. This API supports pagination. Returns a list of Tickets with the specified information.
```
POST api/v2/quicksearch/tickets payload
```
|Parameter|Type|
|---|---|
|pageNumber|number|
|pageSize|number|
|payload|object|

## getTicketFieldList()
> Returns a list of all Ticket fields.
```
GET api/v2/quicksearch/tickets/ticketListFields
```
*No parameters.*

## createTicketsBulk(payload)
> Add/Update/Delete Tickets in Bulk. The body of the Request should contain the required fields required to perform the specified Method.
```
POST api/v2/tickets/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## createTicketAssignment(entityType, payload)
> Assign Item to Ticket. The entity Ids provided in the Request should be the ID of the entity to be assigned to the Ticket.
```
POST api/v2/tickets/assignment/{entityType}/assign payload
```
|Parameter|Type|
|---|---|
|entityType|string|
|payload|object|

## removeTicketAssignment(entityType, payload)
> Unassign Item from Ticket. This API will disassociate multiple Items or Circuits from a Ticket. The Ids provided in the Request should be the IDs of the assignment records.
```
POST api/v2/tickets/assignment/{entityType}/unassign payload
```
|Parameter|Type|
|---|---|
|entityType|string|
|payload|object|

## createCustomField(payload)
> Creates a custom field. Returns the newly created custom field.
```
POST api/v2/settings/lists/customFields payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updateCustomField(customFieldId, payload)
> Update the definitions of the specified custom fields. Returns the updated custom field definitions.
```
PUT api/v2/settings/lists/customFields/{customFieldId} payload
```
|Parameter|Type|
|---|---|
|customFieldId|number|
|payload|object|

## getCustomFields(orderPickListsBy)
> Get a list of custom fields. Returns a list of all custom fields.
```
GET api/v2/settings/lists/customFields
```
|Parameter|Type|
|---|---|
|orderPickListsBy|string|

## getCustomField(customFieldId, orderPickListsBy)
> Get the custom field details for a given customFieldId. Passing a -1 value will return all the labels with null values. Returns a list of custom field details for the specified custom field.
```
GET api/v2/settings/lists/customFields/{customFieldId}
```
|Parameter|Type|
|---|---|
|customFieldId|number|
|orderPickListsBy|string|

## deleteCustomField(customFieldId, proceedOnWarning)
> Deletes the specified custom field and associated pick lists.
```
DELETE api/v2/settings/lists/customFields/{customFieldId}
```
|Parameter|Type|
|---|---|
|customFieldId|number|
|proceedOnWarning|boolean|

## getWebhook()
> Returns the current Webhook configuration information.
```
GET api/v2/notifications/config
```
*No parameters.*

## updateWebhook(payload)
> Update the Webhook configuration information.
```
PUT api/v2/notifications/config payload
```
|Parameter|Type|
|---|---|
|payload|object|

## deleteWebhook()
> Deletes the Webhook configuration.
```
DELETE api/v2/notifications/config
```
*No parameters.*

## getRelationship(id)
> Get Relationship details using the Relationship ID.
```
GET api/v2/relationship/{id}
```
|Parameter|Type|
|---|---|
|id|number|

## createRelationship(payload)
> Create a new entity link. Returns the newly created item JSON object. Note: Supported entity Types are "PROJECT", "TICKET", "ITEM".
```
POST api/v2/relationship payload
```
|Parameter|Type|
|---|---|
|payload|object|

## getRelationshipByEntity(entityType, entityId)
> Search for Entity Links BY Entity Type and Entity ID. Entity Types are "PROJECT", "ITEM". Returns a Project JSON object.
```
GET api/v2/relationship/{entityType}/{entityId}
```
|Parameter|Type|
|---|---|
|entityType|string|
|entityId|number|

## searchRelationships(payload)
> Search for Entity Links. Returns an array of Relationship links for the entity type.
```
POST api/v2/relationship/search payload
```
|Parameter|Type|
|---|---|
|payload|object|

## deleteRelationship(id)
> Delete an Entity Link using the Relationship ID.
```
DELETE api/v2/relationship/{id}
```
|Parameter|Type|
|---|---|
|id|number|

## getFloormapConfig(locationId)
> Get floormap configuration for specific location.
```
GET api/v2/visualization/floormaps/configuration/{locationId}
```
|Parameter|Type|
|---|---|
|locationId|number|

## getFloormapConfigs()
> Get floormap configuration for all locations.
```
GET api/v2/visualization/floormaps/configuration
```
*No parameters.*

## updateFloormapConfig(locationId, payload)
> Modify floormap configuration for specific location.
```
PUT api/v2/visualization/floormaps/configuration/{locationId} payload
```
|Parameter|Type|
|---|---|
|locationId|number|
|payload|object|

## createFloormapConfigsBulk(payload)
> Modify floormap configurations for multiple locations.
```
POST api/v2/visualization/floormaps/configuration/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## createProject(payload)
> Add a new Project. JSON entity containing Project information that was passed in from the Request payload.
```
POST api/v2/dcimoperations/projects payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updateProject(id, payload)
> Modify a Project. JSON entity containing Project information that was passed in from the Request payload.
```
PUT api/v2/dcimoperations/projects/{id} payload
```
|Parameter|Type|
|---|---|
|id|number|
|payload|object|

## deleteProject(id)
> Delete a Project using the Project ID.
```
DELETE api/v2/dcimoperations/projects/{id}
```
|Parameter|Type|
|---|---|
|id|number|

## getProject(id)
> Get Project details using the Project ID. Returns a Project JSON object.
```
GET api/v2/dcimoperations/projects/{id}
```
|Parameter|Type|
|---|---|
|id|number|

## createPartClass(payload)
> Create Part Classes. Returns JSON entity containing data for the created Part Class.
```
POST api/v2/parts/classes payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updatePartClass(classId, payload)
> Update Part Classes. Returns JSON entity containing data for the updated Part Class.
```
PUT api/v2/parts/classes/{classId} payload
```
|Parameter|Type|
|---|---|
|classId|number|
|payload|object|

## deletePartClass(classId)
> Delete Part Class by Class ID.
```
DELETE api/v2/parts/classes/{classId}
```
|Parameter|Type|
|---|---|
|classId|number|

## getPartClasses()
> Returns a list of Part Classes with basic information.
```
GET api/v2/parts/classes
```
*No parameters.*

## createPartClassesBulk(payload)
> Create, Update, Delete Part Classes in Bulk. Returns JSON entity containing a list of response codes.
```
POST api/v2/parts/classes/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## createPartModel(payload)
> Create Part Model. Returns JSON entity containing data for the created Part Model.
```
POST api/v2/partModels payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updatePartModel(modelId, payload)
> Update a Part Model. Returns JSON entity containing data for the Updated Part Model.
```
PUT api/v2/partModels/{modelId} payload
```
|Parameter|Type|
|---|---|
|modelId|number|
|payload|object|

## deletePartModel(modelId)
> Delete Part Model by Model ID.
```
DELETE api/v2/partModels/{modelId}
```
|Parameter|Type|
|---|---|
|modelId|number|

## getPartModel(modelId)
> Get Model by Model ID. Returns JSON entity containing data for a single Model.
```
GET api/v2/partModels/{modelId}
```
|Parameter|Type|
|---|---|
|modelId|number|

## searchPartModels(pageNumber, pageSize, payload)
> Search for Part Models using criteria JSON object. Search criteria can be any of the fields applicable to Part Models, including custom fields. Specify the field to be included in the response. This API supports pagination. Returns a list of Part Models with the specified information.
```
POST api/v2/quicksearch/parts/models payload
```
|Parameter|Type|
|---|---|
|pageNumber|number|
|pageSize|number|
|payload|object|

## deletePartModelImage(modelId)
> Delete a Part Model Image using the Part Model ID.
```
DELETE api/v2/partModels/images/{modelId}
```
|Parameter|Type|
|---|---|
|modelId|number|

## createPartModelsBulk(payload)
> Create, Update, Delete Part Models in Bulk. Returns JSON entity containing a list of response codes.
```
POST api/v2/partModels/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## getPartModelFieldList()
> Returns a list of all Part Model fields.
```
GET api/v2/quicksearch/parts/partModelListFields
```
*No parameters.*

## createPart(payload)
> Create Part Instance. Returns JSON entity containing data for the created Part Instance.
```
POST api/v2/parts payload
```
|Parameter|Type|
|---|---|
|payload|object|

## getPart(partId)
> Get Part Instance by Part ID. Returns JSON entity containing data for a single Part Instance.
```
GET api/v2/parts/{partId}
```
|Parameter|Type|
|---|---|
|partId|number|

## updatePart(partId, payload)
> Update Part Instance. Returns JSON entity containing data for a single Part Instance.
```
PUT api/v2/parts/{partId} payload
```
|Parameter|Type|
|---|---|
|partId|number|
|payload|object|

## deletePart(partId)
> Delete Part Instance. JSON entity containing errors and warnings.
```
DELETE api/v2/parts/{partId}
```
|Parameter|Type|
|---|---|
|partId|number|

## createPartsBulk(payload)
> Create, Update, Delete Part Instances in Bulk. Returns JSON entity containing a list of response codes.
```
POST api/v2/parts/bulk payload
```
|Parameter|Type|
|---|---|
|payload|object|

## updateStock(partId, activity, payload)
> Adjust or Transfer Stock where "activity" can be "adjust" or "transfer". Returns JSON entity containing data for the transaction performed.
```
PUT api/v2/parts/{partId}/stock/{activity} payload
```
|Parameter|Type|
|---|---|
|partId|number|
|activity|string|
|payload|object|

## createPartAssignment(assignmentType, payload)
> Assign Parts to Items or Item Ports where "assignmentType" can be "ITEMS" or "PORTS". Returns JSON entity containing data for the assignment.
```
POST api/v2/parts/assignments/{assignmentType} payload
```
|Parameter|Type|
|---|---|
|assignmentType|string|
|payload|object|

## getPartFieldList()
> Returns a list of all Part fields.
```
GET api/v2/quicksearch/parts/partListFields
```
*No parameters.*

## searchParts(pageNumber, pageSize, payload)
> Search for Parts using criteria JSON object. Search criteria can be any of the fields applicable to Parts, including custom fields. Specify the field to be included in the response. This API supports pagination. Returns a list of Parts with the specified information.
```
POST api/v2/quicksearch/parts payload
```
|Parameter|Type|
|---|---|
|pageNumber|number|
|pageSize|number|
|payload|object|

## getPartTransactionFieldList()
> Returns a list of all Part Transaction fields.
```
GET api/v2/quicksearch/parts/partTransactionListFields
```
*No parameters.*

## searchPartTransactions(pageNumber, pageSize, payload)
> Search for Part Transactions using criteria JSON object. Search criteria can be any of the fields applicable to Part Transactions, including custom fields. Specify the field to be included in the response. This API supports pagination. Returns a list of Part Transactions with the specified information.
```
POST api/v2/quicksearch/parts/transactions payload
```
|Parameter|Type|
|---|---|
|pageNumber|number|
|pageSize|number|
|payload|object|

## searchAuditTrail(pageNumber, pageSize, payload)
> Search for one or more Audit Trail records by user supplied search criteria using the REST API v2. Returns a list of models with the "selectedColumns" returned in the payload.
```
POST api/v2/quicksearch/auditTrail payload
```
|Parameter|Type|
|---|---|
|pageNumber|number|
|pageSize|number|
|payload|object|

## getAuditTrailFieldList()
> Returns a list of all Audit Trail fields.
```
GET api/v2/quicksearch/auditTrail/auditTrailListFields
```
*No parameters.*

## getCharts()
> Get a list of all available chart widgets in the system.
```
GET api/v2/reports/charts
```
*No parameters.*

## getChart(id)
> Get chart details by ID.
```
GET api/v2/reports/charts/{id}
```
|Parameter|Type|
|---|---|
|id|number|

## retrieveChartData(id, payload)
> Get chart data by ID.
```
POST api/v2/reports/charts/{id}/data payload
```
|Parameter|Type|
|---|---|
|id|number|
|payload|object|

## retrieveChartDetails(id, payload)
> Get a widget's details including a list of parameters.
```
POST api/v2/reports/charts/{id}/details payload
```
|Parameter|Type|
|---|---|
|id|number|
|payload|object|

## retrieveChartParameters(id, payload)
> Get a listing of parameter pick-list choices. ID is the record id of the widget. Request is a map containing a key with a value containing an array of ids. 404 not found will be returned when parameter is missing or incorrect.
```
POST api/v2/reports/charts/parameters/{id} payload
```
|Parameter|Type|
|---|---|
|id|number|
|payload|object|
