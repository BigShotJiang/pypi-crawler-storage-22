import logging
from .core.base import BaseConnection, ConnectionTester
from .core.configs import (
    BaseConnectionConfig,
    BaseOperationRetryConfig,
    BasePoolConfig,
    BaseRetryConfig,
    BaseSessionConfig,
)
from .core.settings import get_mssql_settings
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass
from sqlalchemy.engine import URL, Engine, create_engine
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, create_async_engine
from sqlalchemy.orm import Session
from typing import AsyncGenerator, Generator

_logger = logging.getLogger(__name__)
_logger.addHandler(logging.NullHandler())


@dataclass(frozen=True, slots=True)
class MSSQLConnectionConfig(BaseConnectionConfig):
    database: str | None = None
    schema: str | None = None
    odbcdriver_version: int | None = None


@dataclass(frozen=True, slots=True)
class MSSQLSSLConfig:
    ssl_encrypt: bool | None = None
    ssl_trust_server_certificate: bool | None = None
    ssl_ca_cert_path: str | None = None


@dataclass(frozen=True, slots=True)
class MSSQLPoolConfig(BasePoolConfig):
    pass


@dataclass(frozen=True, slots=True)
class MSSQLSessionConfig(BaseSessionConfig):
    pass


@dataclass(frozen=True, slots=True)
class MSSQLConnRetryConfig(BaseRetryConfig):
    pass


@dataclass(frozen=True, slots=True)
class MSSQLOpRetryConfig(BaseOperationRetryConfig):
    pass


class MSSQL(BaseConnection):
    """
    Class to handle MSSQL connections.
    """

    def __init__(
        self,
        host: str | None = None,
        port: int | None = None,
        user: str | None = None,
        password: str | None = None,
        database: str | None = None,
        schema: str | None = None,
        pool_config: MSSQLPoolConfig | None = None,
        session_config: MSSQLSessionConfig | None = None,
        conn_retry_config: MSSQLConnRetryConfig | None = None,
        op_retry_config: MSSQLOpRetryConfig | None = None,
        ssl_config: MSSQLSSLConfig | None = None,
        extra_engine_args: dict | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        _settings = get_mssql_settings()

        self._connection_config = MSSQLConnectionConfig(
            host=host or _settings.host,
            port=int(port or _settings.port),
            user=user or _settings.user,
            password=password or _settings.password,
            database=database or _settings.database,
            schema=schema or _settings.schema,
            odbcdriver_version=int(_settings.odbcdriver_version),
        )

        _pc = pool_config or MSSQLPoolConfig()
        self._pool_config = MSSQLPoolConfig(
            pool_size=_pc.pool_size if _pc.pool_size is not None else int(_settings.pool_size),
            max_overflow=_pc.max_overflow if _pc.max_overflow is not None else int(_settings.max_overflow),
            pool_recycle=_pc.pool_recycle if _pc.pool_recycle is not None else _settings.pool_recycle,
            connection_timeout=(
                _pc.connection_timeout if _pc.connection_timeout is not None else _settings.connection_timeout
            ),
        )

        _sc = session_config or MSSQLSessionConfig()
        self._session_config = MSSQLSessionConfig(
            echo=_sc.echo if _sc.echo is not None else _settings.echo,
            autoflush=_sc.autoflush if _sc.autoflush is not None else _settings.autoflush,
            expire_on_commit=_sc.expire_on_commit if _sc.expire_on_commit is not None else _settings.expire_on_commit,
            autocommit=_sc.autocommit if _sc.autocommit is not None else _settings.autocommit,
        )

        _ssl = ssl_config or MSSQLSSLConfig()
        self._ssl_config = MSSQLSSLConfig(
            ssl_encrypt=_ssl.ssl_encrypt if _ssl.ssl_encrypt is not None else _settings.ssl_encrypt,
            ssl_trust_server_certificate=(
                _ssl.ssl_trust_server_certificate
                if _ssl.ssl_trust_server_certificate is not None
                else _settings.ssl_trust_server_certificate
            ),
            ssl_ca_cert_path=_ssl.ssl_ca_cert_path,
        )

        self.sync_driver = _settings.sync_driver
        self.async_driver = _settings.async_driver

        self.connection_url = {
            "host": self._connection_config.host,
            "port": self._connection_config.port,
            "database": self._connection_config.database,
            "username": self._connection_config.user,
            "password": self._connection_config.password,
            "query": {
                "driver": f"ODBC Driver {self._connection_config.odbcdriver_version} for SQL Server",
                "Encrypt": "yes" if self._ssl_config.ssl_encrypt else "no",
                "TrustServerCertificate": "yes" if self._ssl_config.ssl_trust_server_certificate else "no",
            },
        }

        self.extra_engine_args = extra_engine_args or {}
        self.engine_args = {
            "pool_size": self._pool_config.pool_size,
            "max_overflow": self._pool_config.max_overflow,
            "echo": self._session_config.echo,
            "pool_pre_ping": True,
            "pool_recycle": self._pool_config.pool_recycle,
            "connect_args": {
                "timeout": self._pool_config.connection_timeout,
                "login_timeout": self._pool_config.connection_timeout,
                "autocommit": self._session_config.autocommit,
            },
            **self.extra_engine_args,
        }

        # Create connection retry configuration
        _crc = conn_retry_config or MSSQLConnRetryConfig()
        self._conn_retry_config = MSSQLConnRetryConfig(
            enable_retry=_crc.enable_retry if _crc.enable_retry is not None else _settings.conn_enable_retry,
            max_retries=_crc.max_retries if _crc.max_retries is not None else _settings.conn_max_retries,
            initial_retry_delay=(
                _crc.initial_retry_delay if _crc.initial_retry_delay is not None else _settings.conn_initial_retry_delay
            ),
            max_retry_delay=(
                _crc.max_retry_delay if _crc.max_retry_delay is not None else _settings.conn_max_retry_delay
            ),
        )

        # Create operation retry configuration
        _orc = op_retry_config or MSSQLOpRetryConfig()
        self._op_retry_config = MSSQLOpRetryConfig(
            enable_retry=_orc.enable_retry if _orc.enable_retry is not None else _settings.op_enable_retry,
            max_retries=_orc.max_retries if _orc.max_retries is not None else _settings.op_max_retries,
            initial_retry_delay=(
                _orc.initial_retry_delay if _orc.initial_retry_delay is not None else _settings.op_initial_retry_delay
            ),
            max_retry_delay=_orc.max_retry_delay if _orc.max_retry_delay is not None else _settings.op_max_retry_delay,
            jitter=_orc.jitter if _orc.jitter is not None else _settings.op_jitter,
        )

        self.logger = logger if logger is not None else _logger

        super().__init__(
            connection_url=self.connection_url,
            engine_args=self.engine_args,
            autoflush=self._session_config.autoflush,
            expire_on_commit=self._session_config.expire_on_commit,
            sync_driver=self.sync_driver,
            async_driver=self.async_driver,
            conn_retry_config=self._conn_retry_config,
            op_retry_config=self._op_retry_config,
            logger=self.logger,
        )

        self.logger.debug(
            f"Initializing MSSQL(host={self._connection_config.host}, "
            f"port={self._connection_config.port}, "
            f"database={self._connection_config.database})"
        )

    def __repr__(self) -> str:
        return (
            "MSSQL("
            f"host={self._connection_config.host!r}, "
            f"port={self._connection_config.port}, "
            f"database={self._connection_config.database!r}, "
            f"pool_size={self._pool_config.pool_size}, "
            f"echo={self._session_config.echo}"
            ")"
        )

    def get_connection_info(self) -> MSSQLConnectionConfig:
        return self._connection_config

    def get_pool_info(self) -> MSSQLPoolConfig:
        return self._pool_config

    def get_session_info(self) -> MSSQLSessionConfig:
        return self._session_config

    def get_conn_retry_info(self) -> MSSQLConnRetryConfig:
        return self._conn_retry_config

    def get_op_retry_info(self) -> MSSQLOpRetryConfig:
        return self._op_retry_config

    def get_ssl_info(self) -> MSSQLSSLConfig:
        return self._ssl_config

    @contextmanager
    def _get_engine(self) -> Generator[Engine, None, None]:
        _connection_url = URL.create(
            drivername=self.sync_driver,
            **self.connection_url,
        )
        _engine = create_engine(url=_connection_url, **self.engine_args)
        yield _engine
        _engine.dispose()

    @asynccontextmanager
    async def _get_async_engine(self) -> AsyncGenerator[AsyncEngine, None]:
        _connection_url = URL.create(
            drivername=self.async_driver,
            **self.connection_url,
        )
        _engine = create_async_engine(url=_connection_url, **self.engine_args)
        yield _engine
        await _engine.dispose()

    def _test_connection_sync(self, session: Session) -> None:
        _connection_url_copy = self.connection_url.copy()
        _connection_url_copy.pop("password", None)
        _connection_url = URL.create(
            **_connection_url_copy,
            drivername=self.sync_driver,
        )
        test_connection = ConnectionTester(
            sync_session=session,
            host_url=_connection_url,
            logger=self.logger,
        )
        test_connection.test_connection_sync()

    async def _test_connection_async(self, session: AsyncSession) -> None:
        _connection_url_copy = self.connection_url.copy()
        _connection_url_copy.pop("password", None)
        _connection_url = URL.create(
            **_connection_url_copy,
            drivername=self.async_driver,
        )
        test_connection = ConnectionTester(
            async_session=session,
            host_url=_connection_url,
            logger=self.logger,
        )
        await test_connection.test_connection_async()
