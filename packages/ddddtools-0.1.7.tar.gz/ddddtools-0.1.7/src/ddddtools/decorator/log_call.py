"""日志装饰器 - 记录函数调用详情"""
import time
import inspect
from ..logging import get_logger

logger = get_logger("Dtools.decorator")


def _format_arg(arg, limit: int = 1000) -> str:
    """格式化参数，支持限制长度"""
    s = repr(arg)
    if len(s) > limit:
        return s[:limit] + "..."
    return s


def _format_kwargs(kwargs, limit: int = 1000) -> str:
    """格式化关键字参数"""
    if not kwargs:
        return ""
    parts = [f"{k}={_format_arg(v, limit)}" for k, v in kwargs.items()]
    return ", ".join(parts)


def log_call(name: str = None, arg_limit: int = 1000, return_limit: int = 1000):
    """
    函数调用日志装饰器
    
    Args:
        name: 日志名称，默认使用函数名
        arg_limit: 参数字符串截断长度，默认1000
        return_limit: 返回值字符串截断长度，默认1000
    
    Example:
        @log_call()
        def my_func(a, b): ...
        
        @log_call(name="自定义名", arg_limit=500)
        def my_func(x): ...
    """
    def decorator(func):
        log_name = name or func.__name__
        
        def wrapper(*args, **kwargs):
            # 格式化参数
            sig = inspect.signature(func)
            bound = sig.bind(*args, **kwargs)
            bound.apply_defaults()
            
            # 构建参数字符串
            all_args = ", ".join(
                f"{k}={_format_arg(v, arg_limit)}" 
                for k, v in bound.arguments.items()
            )
            
            logger.info(f"[{log_name}] 传入: ({all_args})")
            
            # 执行并计时
            start = time.perf_counter()
            result = func(*args, **kwargs)
            elapsed = (time.perf_counter() - start) * 1000
            
            # 格式化返回值
            result_str = _format_arg(result, return_limit)
            logger.info(f"[{log_name}] 返回: {result_str} | 耗时: {elapsed:.2f}ms")
            
            return result
        return wrapper
    return decorator
