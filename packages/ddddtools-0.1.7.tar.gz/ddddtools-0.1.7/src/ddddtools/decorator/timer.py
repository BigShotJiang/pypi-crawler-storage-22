"""耗时装饰器 - 记录函数执行时间"""
import time
from ..logging import get_logger

logger = get_logger("Dtools.decorator")


def timer(func):
    """记录函数执行时间的装饰器"""
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        end = time.perf_counter()
        elapsed = (end - start) * 1000  # 毫秒
        logger.info(f"[{func.__name__}] 耗时: {elapsed:.2f}ms")
        return result
    return wrapper
