"""AES加密/解密工具"""
import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from typing import Union


class AESEncrypt:
    """AES加密工具类"""
    
    def __init__(self, key: str, mode: int = AES.MODE_CBC, iv: bytes = None):
        """
        Args:
            key: 密钥字符串（16/24/32字节对应AES-128/192/256）
            mode: 加密模式（MODE_CBC, MODE_ECB, MODE_CTR等）
            iv: 初始向量，ECB模式不需要
        """
        self.key = self._prepare_key(key)
        self.mode = mode
        self.iv = iv or self._generate_iv()
    
    def _prepare_key(self, key: str) -> bytes:
        """将字符串密钥转换为字节，自动截断或补齐"""
        key_bytes = key.encode('utf-8')
        if len(key_bytes) in (16, 24, 32):
            return key_bytes
        # 补齐或截断到16字节
        return key_bytes[:16].ljust(16, b'\0')[:16]
    
    def _generate_iv(self) -> bytes:
        """生成随机初始向量（16字节）"""
        import os
        return os.urandom(16)
    
    def encrypt(self, data: Union[str, bytes]) -> str:
        """加密数据，返回Base64编码的字符串"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        if self.mode == AES.MODE_ECB:
            cipher = AES.new(self.key, self.mode)
        else:
            cipher = AES.new(self.key, self.mode, iv=self.iv)
        
        padded_data = pad(data, AES.block_size)
        encrypted = cipher.encrypt(padded_data)
        
        if self.mode == AES.MODE_ECB:
            return base64.b64encode(encrypted).decode('ascii')
        # CBC模式需要把IV和密文拼接
        return base64.b64encode(self.iv + encrypted).decode('ascii')
    
    def decrypt(self, encrypted_data: Union[str, bytes]) -> str:
        """解密Base64编码的加密数据，返回原始字符串"""
        if isinstance(encrypted_data, str):
            encrypted_data = base64.b64decode(encrypted_data)
        
        if self.mode == AES.MODE_ECB:
            cipher = AES.new(self.key, self.mode)
        else:
            # 分离IV和密文
            iv = encrypted_data[:16]
            encrypted = encrypted_data[16:]
            cipher = AES.new(self.key, self.mode, iv=iv)
        
        decrypted = cipher.decrypt(encrypted)
        unpadded = unpad(decrypted, AES.block_size)
        return unpadded.decode('utf-8')


def encrypt_aes(data: str, key: str) -> str:
    """快速AES加密（CBC模式，自动生成IV）"""
    return AESEncrypt(key).encrypt(data)


def decrypt_aes(encrypted_data: str, key: str) -> str:
    """快速AES解密"""
    return AESEncrypt(key).decrypt(encrypted_data)


def encrypt_aes_ecb(data: str, key: str) -> str:
    """AES ECB模式加密，返回十六进制"""
    return AESEncrypt(key, mode=AES.MODE_ECB).encrypt(data)


def decrypt_aes_ecb(encrypted_data: str, key: str) -> str:
    """AES ECB模式解密，支持十六进制或Base64输入"""
    # 自动识别十六进制（包含字母且长度为偶数）
    if all(c in '0123456789abcdefABCDEF' for c in encrypted_data) and len(encrypted_data) % 2 == 0:
        import binascii
        encrypted_data = binascii.unhexlify(encrypted_data)
    return AESEncrypt(key, mode=AES.MODE_ECB).decrypt(encrypted_data)
