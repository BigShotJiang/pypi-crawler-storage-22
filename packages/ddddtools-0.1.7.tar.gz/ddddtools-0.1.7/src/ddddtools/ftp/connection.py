"""FTP连接管理"""
from ftplib import FTP
from contextlib import contextmanager


class FTPClient:
    """FTP客户端"""
    
    def __init__(self, host: str, port: int = 21, username: str = "", password: str = "", 
                 timeout: int = 30):
        self.host = host
        self.port = port
        self.username = username or "anonymous"
        self.password = password
        self.timeout = timeout
        self._ftp = None
    
    def connect(self):
        """建立连接"""
        self._ftp = FTP()
        self._ftp.connect(self.host, self.port, self.timeout)
        self._ftp.login(self.username, self.password)
        self._ftp.set_pasv(True)
    
    def close(self):
        """关闭连接"""
        if self._ftp:
            self._ftp.quit()
            self._ftp = None
    
    @contextmanager
    def session(self):
        """上下文管理器方式使用"""
        self.connect()
        try:
            yield self._ftp
        finally:
            self.close()
    
    def __enter__(self):
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


def connect(host: str, port: int = 21, username: str = "", password: str = "", 
            timeout: int = 30) -> "FTPClient":
    """
    创建FTP连接
    
    Args:
        host: FTP服务器地址
        port: 端口，默认21
        username: 用户名，默认匿名
        password: 密码
        timeout: 超时时间，默认30秒
    
    Returns:
        FTPClient 实例
    
    Example:
        with ftp.connect("ftp.example.com", username="user", password="pass") as conn:
            files = conn.list_files("/")
    """
    return FTPClient(host, port, username, password, timeout)
