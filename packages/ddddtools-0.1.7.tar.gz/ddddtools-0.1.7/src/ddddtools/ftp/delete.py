"""FTP删除操作"""
from ftplib import FTP
from ..decorator import log_call


@log_call(arg_limit=500)
def delete_file(ftp: FTP, remote_path: str):
    """
    删除远程文件
    
    Args:
        ftp: FTP连接实例
        remote_path: 远程文件路径
    
    Example:
        with ftp.connect("ftp.example.com") as conn:
            conn.delete_file("/pub/file.txt")
    """
    ftp.delete(remote_path)


@log_call(arg_limit=500)
def delete_folder(ftp: FTP, remote_path: str):
    """
    删除远程文件夹（必须为空）
    
    Args:
        ftp: FTP连接实例
        remote_path: 远程文件夹路径
    
    Example:
        conn.delete_folder("/pub/empty_folder")
    """
    ftp.rmd(remote_path)


@log_call(arg_limit=500)
def delete_recursive(ftp: FTP, remote_path: str):
    """
    递归删除文件夹及其内容
    
    Args:
        ftp: FTP连接实例
        remote_path: 远程路径
    
    Example:
        conn.delete_recursive("/pub/folder_to_remove")
    """
    try:
        ftp.cwd(remote_path)
    except Exception:
        delete_file(ftp, remote_path)
        return
    
    files = []
    
    def callback(line):
        parts = line.split(None, 8)
        if len(parts) >= 9:
            name = parts[-1]
            if name not in (".", ".."):
                files.append(name)
    
    ftp.retrlines("LIST", callback)
    
    for name in files:
        item_path = f"{remote_path}/{name}".replace("//", "/")
        try:
            ftp.cwd(item_path)
            delete_recursive(ftp, item_path)
            ftp.cwd("..")
        except Exception:
            delete_file(ftp, item_path)
    
    ftp.cwd("..")
    ftp.rmd(remote_path)
