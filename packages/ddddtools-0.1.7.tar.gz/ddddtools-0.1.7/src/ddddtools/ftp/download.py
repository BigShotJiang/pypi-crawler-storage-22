"""FTP下载操作"""
from ftplib import FTP
import os
from ..decorator import log_call


@log_call(arg_limit=500)
def download_file(ftp: FTP, remote_path: str, local_path: str, 
                  overwrite: bool = True):
    """
    下载单个文件
    
    Args:
        ftp: FTP连接实例
        remote_path: 远程文件路径
        local_path: 本地保存路径
        overwrite: 是否覆盖本地文件，默认 True
    
    Example:
        with ftp.connect("ftp.example.com") as conn:
            conn.download_file("/pub/file.txt", "./downloads/file.txt")
    """
    if not overwrite and os.path.exists(local_path):
        return
    
    os.makedirs(os.path.dirname(local_path), exist_ok=True)
    
    with open(local_path, "wb") as f:
        ftp.retrbinary(f"RETR {remote_path}", f.write)


@log_call(arg_limit=500)
def download_folder(ftp: FTP, remote_folder: str, local_folder: str,
                    overwrite: bool = True):
    """
    下载整个文件夹
    
    Args:
        ftp: FTP连接实例
        remote_folder: 远程文件夹路径
        local_folder: 本地保存路径
        overwrite: 是否覆盖
    
    Example:
        with ftp.connect("ftp.example.com") as conn:
            conn.download_folder("/pub/folder", "./downloads")
    """
    os.makedirs(local_folder, exist_ok=True)
    
    try:
        ftp.cwd(remote_folder)
    except Exception:
        return
    
    files = []
    
    def callback(line):
        parts = line.split(None, 8)
        if len(parts) >= 9:
            name = parts[-1]
            if name not in (".", ".."):
                files.append(name)
    
    ftp.retrlines("LIST", callback)
    
    for name in files:
        remote_path = f"{remote_folder}/{name}".replace("//", "/")
        local_path = os.path.join(local_folder, name)
        
        try:
            ftp.cwd(remote_path)
            download_folder(ftp, remote_path, local_path, overwrite)
            ftp.cwd("..")
        except Exception:
            download_file(ftp, remote_path, local_path, overwrite)
