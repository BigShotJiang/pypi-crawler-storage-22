"""FTP文件列表操作"""
from ftplib import FTP
from typing import List
from dataclasses import dataclass
from ..decorator import log_call


@dataclass
class FTPFile:
    """FTP文件信息"""
    name: str
    size: int
    is_dir: bool
    modify_time: str = ""
    
    @property
    def path(self) -> str:
        return self.name


def parse_ftp_line(line: str) -> tuple:
    """解析FTP LIST行"""
    parts = line.split(None, 8)
    if len(parts) < 9:
        return None, None, None, None
    
    perms = parts[0]
    name = parts[-1]
    size = int(parts[4]) if len(parts) > 4 else 0
    is_dir = perms[0] == 'd'
    mtime = " ".join(parts[5:8]) if len(parts) > 7 else ""
    
    return name, size, is_dir, mtime


@log_call(arg_limit=500)
def list_files(ftp: FTP, path: str = ".") -> List[FTPFile]:
    """
    获取FTP目录文件列表
    
    Args:
        ftp: FTP连接实例
        path: 远程路径，默认当前目录
    
    Returns:
        文件信息列表
    
    Example:
        with ftp.connect("ftp.example.com") as conn:
            for f in conn.list_files("/public"):
                print(f.name, f.size, f.is_dir)
    """
    files = []
    
    def callback(line):
        parsed = parse_ftp_line(line)
        if parsed[0]:
            name, size, is_dir, mtime = parsed
            if name not in (".", ".."):
                files.append(FTPFile(name=name, size=size, is_dir=is_dir, modify_time=mtime))
    
    ftp.cwd(path)
    ftp.retrlines("LIST", callback)
    
    return files


@log_call(arg_limit=500)
def list_all(ftp: FTP, path: str = ".", recursive: bool = False) -> List[FTPFile]:
    """
    获取目录下的所有文件和文件夹
    
    Args:
        ftp: FTP连接实例
        path: 远程路径
        recursive: 是否递归获取子目录
    
    Returns:
        文件信息列表
    """
    result = []
    stack = [path]
    
    while stack:
        current = stack.pop()
        files = list_files(ftp, current)
        
        for f in files:
            full_path = f"{current}/{f.name}".replace("//", "/")
            result.append(FTPFile(
                name=full_path,
                size=f.size,
                is_dir=f.is_dir,
                modify_time=f.modify_time
            ))
            
            if recursive and f.is_dir:
                stack.append(full_path)
    
    return result
