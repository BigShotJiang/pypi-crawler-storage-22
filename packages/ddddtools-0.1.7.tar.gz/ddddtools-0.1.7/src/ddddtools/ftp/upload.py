"""FTP上传操作"""
from ftplib import FTP
import os
from ..decorator import log_call


@log_call(arg_limit=500)
def upload_file(ftp: FTP, local_path: str, remote_path: str,
               overwrite: bool = True):
    """
    上传单个文件
    
    Args:
        ftp: FTP连接实例
        local_path: 本地文件路径
        remote_path: 远程保存路径
        overwrite: 是否覆盖远程文件，默认 True
    
    Example:
        with ftp.connect("ftp.example.com") as conn:
            conn.upload_file("./local.txt", "/pub/remote.txt")
    """
    if not os.path.exists(local_path):
        raise FileNotFoundError(f"本地文件不存在: {local_path}")
    
    try:
        ftp.size(remote_path)
        exists = True
    except Exception:
        exists = False
    
    if exists and not overwrite:
        return
    
    remote_dir = remote_path.rsplit("/", 1)[0] if "/" in remote_path else "."
    _ensure_dir(ftp, remote_dir)
    
    with open(local_path, "rb") as f:
        ftp.storbinary(f"STOR {remote_path}", f)


def _ensure_dir(ftp: FTP, path: str):
    """确保远程目录存在"""
    dirs = path.strip("/").split("/")
    current = ""
    
    for d in dirs:
        if not d:
            continue
        current = f"{current}/{d}".replace("//", "/")
        try:
            ftp.cwd(current)
        except Exception:
            ftp.mkd(current)
            ftp.cwd(current)


@log_call(arg_limit=500)
def upload_folder(ftp: FTP, local_folder: str, remote_folder: str,
                  overwrite: bool = True):
    """
    上传整个文件夹
    
    Args:
        ftp: FTP连接实例
        local_folder: 本地文件夹路径
        remote_folder: 远程保存路径
        overwrite: 是否覆盖
    
    Example:
        with ftp.connect("ftp.example.com") as conn:
            conn.upload_folder("./local_folder", "/pub/remote_folder")
    """
    if not os.path.isdir(local_folder):
        raise NotADirectoryError(f"不是文件夹: {local_folder}")
    
    _ensure_dir(ftp, remote_folder)
    
    for item in os.listdir(local_folder):
        local_path = os.path.join(local_folder, item)
        remote_path = f"{remote_folder}/{item}".replace("//", "/")
        
        if os.path.isdir(local_path):
            upload_folder(ftp, local_path, remote_path, overwrite)
        else:
            upload_file(ftp, local_path, remote_path, overwrite)
