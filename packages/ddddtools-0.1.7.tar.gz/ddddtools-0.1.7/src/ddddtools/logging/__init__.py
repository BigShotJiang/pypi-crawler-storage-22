"""日志模块 - 自动创建logs目录，按日期存储，自动清理7天前的日志"""
import os
import logging
from datetime import datetime, timedelta
from logging.handlers import TimedRotatingFileHandler

_loggers = {}


def _cleanup_old_logs(log_dir: str, days: int = 7):
    """清理旧日志"""
    if not os.path.exists(log_dir):
        return
    
    cutoff = datetime.now() - timedelta(days=days)
    for filename in os.listdir(log_dir):
        if filename.endswith(".log"):
            filepath = os.path.join(log_dir, filename)
            try:
                file_time = datetime.fromtimestamp(os.path.getmtime(filepath))
                if file_time < cutoff:
                    os.remove(filepath)
            except Exception:
                pass


def _setup_logger(logger: logging.Logger, log_dir: str, days: int = 7):
    """配置日志器"""
    os.makedirs(log_dir, exist_ok=True)
    _cleanup_old_logs(log_dir, days)
    
    logger.setLevel(logging.INFO)
    
    if not logger.handlers:
        log_file = os.path.join(log_dir, f"{datetime.now().strftime('%Y-%m-%d')}.log")
        handler = TimedRotatingFileHandler(
            log_file,
            when="midnight",
            interval=1,
            backupCount=days,
            encoding="utf-8"
        )
        handler.suffix = "%Y-%m-%d.log"
        handler.extMatch = r"^\d{4}-\d{2}-\d{2}.log$"
        
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        # 同时输出到控制台
        console = logging.StreamHandler()
        console.setFormatter(formatter)
        logger.addHandler(console)


def get_logger(name: str = None, log_dir: str = None, days: int = 7) -> logging.Logger:
    """
    获取日志器
    
    Args:
        name: 日志器名称，默认 'Dtools'
        log_dir: 日志目录，默认使用当前工作目录下的 logs 文件夹
        days: 日志保留天数，默认 7
    
    Returns:
        logging.Logger
    """
    logger_name = name or "Dtools"
    
    if logger_name in _loggers:
        return _loggers[logger_name]
    
    # 确定日志目录
    if log_dir is None:
        log_dir = os.path.join(os.getcwd(), "logs")
    
    _logger = logging.getLogger(logger_name)
    _setup_logger(_logger, log_dir, days)
    
    _loggers[logger_name] = _logger
    return _logger


# 初始化默认日志器（延迟初始化）
_default_logger = None


def _get_default_logger():
    """获取默认日志器（首次使用时初始化）"""
    global _default_logger
    if _default_logger is None:
        log_dir = os.path.join(os.getcwd(), "logs")
        _default_logger = logging.getLogger("Dtools")
        _setup_logger(_default_logger, log_dir)
    return _default_logger


class _LoggerProxy:
    """日志器代理，支持延迟初始化"""
    def __getattr__(self, name):
        return getattr(_get_default_logger(), name)
    
    def __setattr__(self, name, value):
        return setattr(_get_default_logger(), name, value)


logger = _LoggerProxy()
