"""邮件发送模块 - 支持QQ邮箱"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import List
import os
from ..decorator import log_call


class MailClient:
    """邮件客户端"""
    
    def __init__(self, smtp_host: str, smtp_port: int, username: str, password: str):
        """
        初始化邮件客户端
        
        Args:
            smtp_host: SMTP服务器地址
            smtp_port: SMTP端口（25普通，465 SSL，587 STARTTLS）
            username: 发件人邮箱
            password: 授权码（不是密码）
        """
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
    
    def _create_server(self):
        """根据端口创建对应的 SMTP 服务器"""
        if self.smtp_port == 465:
            # 465 端口使用 SSL
            return smtplib.SMTP_SSL(self.smtp_host, self.smtp_port, timeout=30)
        else:
            # 其他端口使用普通 SMTP
            server = smtplib.SMTP(self.smtp_host, self.smtp_port, timeout=30)
            if self.smtp_port == 587:
                server.starttls()
            return server
    
    @log_call(arg_limit=300)
    def send(self, to_addrs: List[str], subject: str, content: str,
             is_html: bool = False, attachments: List[str] = None):
        """
        发送邮件
        
        Args:
            to_addrs: 收件人列表
            subject: 邮件主题
            content: 邮件内容
            is_html: 是否为HTML格式，默认False
            attachments: 附件路径列表
        """
        msg = MIMEMultipart()
        msg["From"] = self.username
        msg["To"] = ", ".join(to_addrs)
        msg["Subject"] = subject
        
        content_type = "html" if is_html else "plain"
        msg.attach(MIMEText(content, content_type, "utf-8"))
        
        if attachments:
            for filepath in attachments:
                if os.path.exists(filepath):
                    with open(filepath, "rb") as f:
                        part = MIMEBase("application", "octet-stream")
                        part.set_payload(f.read())
                    encoders.encode_base64(part)
                    filename = os.path.basename(filepath)
                    part.add_header(
                        "Content-Disposition",
                        f"attachment; filename={filename}"
                    )
                    msg.attach(part)
        
        server = self._create_server()
        try:
            server.login(self.username, self.password)
            server.sendmail(self.username, to_addrs, msg.as_string())
        finally:
            server.quit()


@log_call(arg_limit=300)
def create_client(username: str, password: str, 
                  smtp_host: str = "smtp.qq.com", 
                  smtp_port: int = 465) -> MailClient:
    """
    创建QQ邮箱客户端
    
    Args:
        username: QQ邮箱账号
        password: 授权码（邮箱设置->账户->开启服务后生成）
        smtp_host: SMTP服务器，默认 smtp.qq.com
        smtp_port: SMTP端口，默认 465
    
    Returns:
        MailClient 实例
    
    Example:
        client = create_client("123456@qq.com", "xxxxxxxx")
        client.send(["to@example.com"], "主题", "内容")
    """
    return MailClient(smtp_host, smtp_port, username, password)


@log_call(arg_limit=300)
def send_simple(to_addrs: List[str], subject: str, content: str,
                username: str = None, password: str = None,
                smtp_host: str = "smtp.qq.com", smtp_port: int = 465):
    """
    快速发送普通邮件
    
    Args:
        to_addrs: 收件人列表
        subject: 邮件主题
        content: 邮件内容
        username: 发件人邮箱
        password: 授权码
        smtp_host: SMTP服务器
        smtp_port: SMTP端口
    """
    client = create_client(username, password, smtp_host, smtp_port)
    client.send(to_addrs, subject, content)


@log_call(arg_limit=300)
def send_html(to_addrs: List[str], subject: str, html_content: str,
              username: str = None, password: str = None,
              smtp_host: str = "smtp.qq.com", smtp_port: int = 465):
    """
    发送HTML邮件
    
    Args:
        to_addrs: 收件人列表
        subject: 邮件主题
        html_content: HTML内容
        username: 发件人邮箱
        password: 授权码
        smtp_host: SMTP服务器
        smtp_port: SMTP端口
    """
    client = create_client(username, password, smtp_host, smtp_port)
    client.send(to_addrs, subject, html_content, is_html=True)


@log_call(arg_limit=300)
def send_with_attachment(to_addrs: List[str], subject: str, content: str,
                         attachments: List[str],
                         username: str = None, password: str = None,
                         smtp_host: str = "smtp.qq.com", smtp_port: int = 465):
    """
    发送带附件的邮件
    
    Args:
        to_addrs: 收件人列表
        subject: 邮件主题
        content: 邮件内容
        attachments: 附件路径列表
        username: 发件人邮箱
        password: 授权码
        smtp_host: SMTP服务器
        smtp_port: SMTP端口
    """
    client = create_client(username, password, smtp_host, smtp_port)
    client.send(to_addrs, subject, content, attachments=attachments)
