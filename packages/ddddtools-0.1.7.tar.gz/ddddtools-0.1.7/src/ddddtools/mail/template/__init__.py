"""HTML邮件模板集合"""
from datetime import datetime

TEMPLATES = {}


def register(name: str, html: str):
    """注册模板"""
    TEMPLATES[name] = html


def get(name: str) -> str:
    """获取模板"""
    return TEMPLATES.get(name, "")


def render(template_name: str, **kwargs) -> str:
    """渲染模板"""
    html = get(template_name)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    html = html.replace("{{now}}", now)
    for key, value in kwargs.items():
        html = html.replace(f"{{{{{key}}}}}", str(value))
    return html


# ========== 基础模板 ==========

register("simple", """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background: #f5f5f5; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .content { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .footer { text-align: center; padding: 20px; color: #888; font-size: 12px; }
        a { color: #007bff; }
    </style>
</head>
<body>
    <div class="container">
        <div class="content">
            {{content}}
        </div>
        <div class="footer">
            <p>此邮件由 Dtools 自动发送</p>
            <p>{{now}}</p>
        </div>
    </div>
</body>
</html>
""")


# ========== 通知模板 ==========

register("notification", """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background: #f0f2f5; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
        .header h1 { margin: 0; font-size: 24px; }
        .content { background: #fff; padding: 30px; border-radius: 0 0 8px 8px; }
        .highlight { background: #f8f9fa; padding: 15px; border-left: 4px solid #667eea; margin: 20px 0; border-radius: 4px; }
        .btn { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { text-align: center; padding: 20px; color: #888; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{{title}}</h1>
        </div>
        <div class="content">
            {{content}}
            {{button_html}}
        </div>
        <div class="footer">
            <p>此邮件由 Dtools 自动发送</p>
            <p>{{now}}</p>
        </div>
    </div>
</body>
</html>
""")


# ========== 验证码模板 ==========

register("verification", """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background: #f5f5f5; }
        .container { max-width: 500px; margin: 0 auto; padding: 20px; }
        .content { background: #fff; padding: 40px; border-radius: 8px; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .code { font-size: 36px; font-weight: bold; letter-spacing: 8px; color: #667eea; margin: 30px 0; font-family: monospace; }
        .tip { color: #888; font-size: 14px; margin-top: 20px; }
        .footer { text-align: center; padding: 20px; color: #888; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="content">
            <h2>{{title}}</h2>
            <p>{{description}}</p>
            <div class="code">{{code}}</div>
            <p class="tip">如果这不是您的请求，请忽略此邮件</p>
        </div>
        <div class="footer">{{now}}</div>
    </div>
</body>
</html>
""")


# ========== 欢迎邮件模板 ==========

register("welcome", """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
        .card { background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 40px rgba(0,0,0,0.2); }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px; text-align: center; }
        .header h1 { margin: 0; font-size: 28px; }
        .content { padding: 40px; }
        .feature { display: flex; align-items: center; margin: 15px 0; }
        .feature-icon { width: 40px; height: 40px; background: #f0f2f5; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 18px; }
        .footer { text-align: center; padding: 20px; color: #888; font-size: 12px; background: #f8f9fa; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <h1>欢迎加入{{site_name}}</h1>
            </div>
            <div class="content">
                <p>您好，<strong>{{username}}</strong>！</p>
                <p>{{message}}</p>
                <div class="feature">
                    <div class="feature-icon">✨</div>
                    <span>{{feature1}}</span>
                </div>
                <div class="feature">
                    <div class="feature-icon">🚀</div>
                    <span>{{feature2}}</span>
                </div>
                <div class="feature">
                    <div class="feature-icon">🔒</div>
                    <span>{{feature3}}</span>
                </div>
            </div>
            <div class="footer">{{now}}</div>
        </div>
    </div>
</body>
</html>
""")


# ========== 表格数据模板 ==========

register("data_table", """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .card { background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .header { background: #343a40; color: white; padding: 20px; }
        .header h2 { margin: 0; }
        .content { padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #dee2e6; }
        th { background: #f8f9fa; font-weight: 600; }
        tr:hover { background: #f8f9fa; }
        .summary { background: #e7f3ff; padding: 15px; border-radius: 8px; margin-top: 20px; }
        .footer { text-align: center; padding: 20px; color: #888; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <h2>{{title}}</h2>
            </div>
            <div class="content">
                {{description}}
                {{table_html}}
                {{#summary_html}}
                <div class="summary">
                    <strong>汇总：</strong>{{summary_html}}
                </div>
                {{/summary_html}}
            </div>
            <div class="footer">{{now}}</div>
        </div>
    </div>
</body>
</html>
""")


# ========== 订单通知模板 ==========

register("order", """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background: #f5f5f5; }
        .container { max-width: 700px; margin: 0 auto; padding: 20px; }
        .card { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.1); }
        .header { padding: 30px; text-align: center; }
        .header-success { background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: white; }
        .header-pending { background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%); color: white; }
        .header-info { background: linear-gradient(135deg, #007bff 0%, #6610f2 100%); color: white; }
        .header h1 { margin: 0; font-size: 24px; }
        .content { padding: 30px; }
        .order-info { background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .row { display: flex; justify-content: space-between; margin: 10px 0; }
        .label { color: #666; }
        .value { font-weight: 600; }
        .total { font-size: 24px; color: #dc3545; font-weight: bold; text-align: right; margin-top: 20px; }
        .btn { display: block; width: 200px; margin: 30px auto 0; padding: 15px; background: #007bff; color: white; text-align: center; text-decoration: none; border-radius: 8px; font-weight: 600; }
        .footer { text-align: center; padding: 20px; color: #888; font-size: 12px; background: #f8f9fa; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header header-{{status_class}}">
                <h1>{{status_icon}} {{status_text}}</h1>
            </div>
            <div class="content">
                <p>尊敬的 <strong>{{username}}</strong>，您的订单状态已更新：</p>
                
                <div class="order-info">
                    <div class="row">
                        <span class="label">订单号：</span>
                        <span class="value">{{order_no}}</span>
                    </div>
                    <div class="row">
                        <span class="label">下单时间：</span>
                        <span class="value">{{order_time}}</span>
                    </div>
                    <div class="row">
                        <span class="label">订单状态：</span>
                        <span class="value">{{status}}</span>
                    </div>
                    {{#tracking_html}}
                    <div class="row">
                        <span class="label">物流单号：</span>
                        <span class="value">{{tracking_html}}</span>
                    </div>
                    {{/tracking_html}}
                </div>
                
                {{order_details}}
                
                <div class="total">合计：¥{{total_amount}}</div>
                
                {{#button_html}}
                <a href="{{button_url}}" class="btn">{{button_text}}</a>
                {{/button_html}}
            </div>
            <div class="footer">{{now}}</div>
        </div>
    </div>
</body>
</html>
""")


# ========== 密码重置模板 ==========

register("password_reset", """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background: #f5f5f5; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .card { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white; padding: 30px; text-align: center; }
        .header h1 { margin: 0; font-size: 22px; }
        .content { padding: 40px 30px; }
        .warning { background: #fff3cd; border: 1px solid #ffc107; padding: 15px; border-radius: 8px; margin: 20px 0; }
        .btn { display: inline-block; padding: 15px 40px; background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white; text-decoration: none; border-radius: 8px; font-weight: 600; margin: 20px 0; }
        .footer { text-align: center; padding: 20px; color: #888; font-size: 12px; background: #f8f9fa; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <h1>🔐 密码重置请求</h1>
            </div>
            <div class="content">
                <p>您好，<strong>{{username}}</strong>！</p>
                <p>我们收到了您的密码重置请求，请点击下方按钮重置密码：</p>
                
                <center>
                    <a href="{{reset_url}}" class="btn">重置密码</a>
                </center>
                
                <div class="warning">
                    <strong>⚠️ 安全提示：</strong>
                    <ul style="margin: 10px 0 0 0; padding-left: 20px;">
                        <li>此链接{{expire_time}}内有效</li>
                        <li>如果这不是您的请求，请忽略此邮件</li>
                        <li>不要向任何人透露您的验证码</li>
                    </ul>
                </div>
            </div>
            <div class="footer">{{now}}</div>
        </div>
    </div>
</body>
</html>
""")


# ========== 周报/月报模板 ==========

register("report", """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background: #f0f2f5; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .card { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.1); }
        .header { background: #343a40; color: white; padding: 25px 30px; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { margin: 0; font-size: 22px; }
        .period { background: rgba(255,255,255,0.2); padding: 8px 16px; border-radius: 20px; font-size: 14px; }
        .content { padding: 30px; }
        .section { margin-bottom: 30px; }
        .section-title { font-size: 18px; font-weight: 600; color: #495057; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #007bff; }
        .metric { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f0f0f0; }
        .metric:last-child { border-bottom: none; }
        .metric-name { color: #666; }
        .metric-value { font-weight: 600; }
        .metric-up { color: #28a745; }
        .metric-down { color: #dc3545; }
        .highlights ul { padding-left: 20px; }
        .highlights li { margin: 8px 0; }
        .footer { text-align: center; padding: 20px; color: #888; font-size: 12px; background: #f8f9fa; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <h1>📊 {{report_title}}</h1>
                <span class="period">{{period}}</span>
            </div>
            <div class="content">
                <div class="section">
                    <div class="section-title">📈 数据概览</div>
                    {{metrics_html}}
                </div>
                
                <div class="section">
                    <div class="section-title">💡 亮点</div>
                    <div class="highlights">
                        {{highlights_html}}
                    </div>
                </div>
                
                <div class="section">
                    <div class="section-title">📝 备注</div>
                    {{notes}}
                </div>
            </div>
            <div class="footer">{{now}}</div>
        </div>
    </div>
</body>
</html>
""")


# ========== 辅助函数 ==========

def make_table_html(headers: list, rows: list) -> str:
    """生成表格HTML"""
    html = '<table><thead><tr>'
    for h in headers:
        html += f'<th>{h}</th>'
    html += '</tr></thead><tbody>'
    for row in rows:
        html += '<tr>'
        for cell in row:
            html += f'<td>{cell}</td>'
        html += '</tr>'
    html += '</tbody></table>'
    return html


def make_metrics_html(metrics: dict) -> str:
    """生成指标HTML"""
    html = ''
    for name, data in metrics.items():
        value = data.get('value', '')
        change = data.get('change', '')
        change_type = data.get('type', 'neutral')  # up, down, neutral
        css_class = f'metric-{change_type}' if change and change_type != 'neutral' else ''
        html += f'<div class="metric"><span class="metric-name">{name}</span>'
        html += f'<span class="metric-value {css_class}">{value}'
        if change:
            html += f' ({change})'
        html += '</span></div>'
    return html


def make_highlights_html(items: list) -> str:
    """生成亮点HTML"""
    html = '<ul>'
    for item in items:
        html += f'<li>{item}</li>'
    html += '</ul>'
    return html


def make_button_html(url: str, text: str = "立即查看") -> str:
    """生成按钮HTML"""
    return f'<center><a href="{url}" class="btn">{text}</a></center>'


def make_notification_html(title: str, content: str, button_url: str = "", button_text: str = "立即查看") -> str:
    """生成通知HTML"""
    return f'<h1>{title}</h1><p>{content}</p>' + (make_button_html(button_url, button_text) if button_url else '')
