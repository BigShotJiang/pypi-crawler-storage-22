"""MongoDB连接管理"""
from typing import Optional
from pymongo import MongoClient
from pymongo.database import Database
from pymongo.collection import Collection


class MongoDB:
    """MongoDB客户端"""
    
    def __init__(self, connection_string: str = "mongodb://localhost:27017", 
                 db_name: str = None):
        """
        Args:
            connection_string: MongoDB连接字符串
            db_name: 数据库名称
        """
        self.client: MongoClient = MongoClient(connection_string)
        self.db: Optional[Database] = None
        if db_name:
            self.db = self.client[db_name]
    
    def set_db(self, db_name: str) -> Database:
        """切换数据库"""
        self.db = self.client[db_name]
        return self.db
    
    def get_collection(self, name: str) -> Collection:
        """获取集合"""
        if not self.db:
            raise ValueError("请先设置数据库：set_db(db_name)")
        return self.db[name]
    
    def close(self):
        """关闭连接"""
        self.client.close()
    
    def ping(self) -> bool:
        """测试连接"""
        try:
            self.client.admin.command('ping')
            return True
        except Exception:
            return False


def connect(connection_string: str = "mongodb://localhost:27017", 
            db_name: str = None) -> MongoDB:
    """快速连接MongoDB"""
    return MongoDB(connection_string, db_name)
