"""MongoDB集合操作"""
from typing import Any, Dict, List, Optional
from pymongo.collection import Collection
from pymongo.results import DeleteResult, UpdateResult


class MongoCollection:
    """MongoDB集合操作类"""
    
    def __init__(self, collection: Collection):
        self.collection = collection
    
    # ========== 插入 ==========
    
    def insert_one(self, document: Dict) -> str:
        """插入单个文档"""
        result = self.collection.insert_one(document)
        return str(result.inserted_id)
    
    def insert_many(self, documents: List[Dict]) -> List[str]:
        """插入多个文档"""
        result = self.collection.insert_many(documents)
        return [str(id) for id in result.inserted_ids]
    
    # ========== 查询 ==========
    
    def find_one(self, query: Dict = None, projection: Dict = None) -> Optional[Dict]:
        """查询单个文档"""
        return self.collection.find_one(query, projection)
    
    def find_by_id(self, doc_id: str) -> Optional[Dict]:
        """根据ID查询"""
        from bson import ObjectId
        return self.collection.find_one({"_id": ObjectId(doc_id)})
    
    def find_all(self, query: Dict = None, projection: Dict = None, 
                 sort: List = None, limit: int = 0) -> List[Dict]:
        """查询多个文档"""
        cursor = self.collection.find(query or {}, projection)
        if sort:
            cursor.sort(sort)
        if limit:
            cursor.limit(limit)
        return list(cursor)
    
    def count(self, query: Dict = None) -> int:
        """统计数量"""
        return self.collection.count_documents(query or {})
    
    def exists(self, query: Dict) -> bool:
        """判断是否存在"""
        return self.collection.count_documents(query) > 0
    
    # ========== 更新 ==========
    
    def update_one(self, query: Dict, update: Dict) -> UpdateResult:
        """更新单个文档"""
        return self.collection.update_one(query, {"$set": update})
    
    def update_by_id(self, doc_id: str, update: Dict) -> UpdateResult:
        """根据ID更新"""
        from bson import ObjectId
        return self.collection.update_one(
            {"_id": ObjectId(doc_id)}, {"$set": update}
        )
    
    def update_many(self, query: Dict, update: Dict) -> UpdateResult:
        """更新多个文档"""
        return self.collection.update_many(query, {"$set": update})
    
    def increment(self, query: Dict, field: str, amount: int = 1) -> UpdateResult:
        """字段自增"""
        return self.collection.update_one(query, {"$inc": {field: amount}})
    
    # ========== 删除 ==========
    
    def delete_one(self, query: Dict) -> DeleteResult:
        """删除单个文档"""
        return self.collection.delete_one(query)
    
    def delete_by_id(self, doc_id: str) -> DeleteResult:
        """根据ID删除"""
        from bson import ObjectId
        return self.collection.delete_one({"_id": ObjectId(doc_id)})
    
    def delete_many(self, query: Dict) -> DeleteResult:
        """删除多个文档"""
        return self.collection.delete_many(query)
    
    # ========== 聚合 ==========
    
    def aggregate(self, pipeline: List[Dict]) -> List[Dict]:
        """聚合查询"""
        return list(self.collection.aggregate(pipeline))
    
    # ========== 索引 ==========
    
    def create_index(self, keys: List[str], **kwargs) -> str:
        """创建索引"""
        return self.collection.create_index(keys, **kwargs)
    
    def create_unique_index(self, field: str) -> str:
        """创建唯一索引"""
        return self.collection.create_index(field, unique=True)
