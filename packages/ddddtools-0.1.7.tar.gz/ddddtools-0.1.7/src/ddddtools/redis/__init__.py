"""Redis 缓存客户端"""
from typing import Any, Optional, Union
import redis

__all__ = ["RedisClient", "connect"]


class RedisClient:
    """Redis 缓存管理客户端"""

    _instance = None
    _client: Optional[redis.Redis] = None

    def __new__(cls, host: str = "localhost", port: int = 6379, db: int = 0,
                password: Optional[str] = None, decode_responses: bool = True):
        """单例模式获取 RedisClient 实例"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._client = None
        cls._instance._init_client(host, port, db, password, decode_responses)
        return cls._instance

    def _init_client(self, host: str, port: int, db: int,
                     password: Optional[str], decode_responses: bool):
        """初始化或重新连接 Redis 客户端"""
        self._client = redis.Redis(
            host=host,
            port=port,
            db=db,
            password=password,
            decode_responses=decode_responses,
            socket_timeout=5,
            socket_connect_timeout=5,
            retry_on_timeout=True
        )

    @property
    def client(self) -> redis.Redis:
        """获取原生 Redis 客户端"""
        return self._client

    # ==================== 基础操作 ====================

    def get(self, key: str) -> Optional[str]:
        """获取缓存值"""
        return self._client.get(key)

    def set(self, key: str, value: Any, ex: Optional[int] = None,
            px: Optional[int] = None, nx: bool = False, xx: bool = False) -> bool:
        """设置缓存值
        
        Args:
            key: 键
            value: 值
            ex: 过期时间（秒）
            px: 过期时间（毫秒）
            nx: 仅当键不存在时设置
            xx: 仅当键存在时设置
        """
        return self._client.set(key, value, ex=ex, px=px, nx=nx, xx=xx)

    def delete(self, *keys: str) -> int:
        """删除缓存"""
        return self._client.delete(*keys)

    def exists(self, *keys: str) -> int:
        """检查键是否存在"""
        return self._client.exists(*keys)

    def expire(self, key: str, seconds: int) -> bool:
        """设置过期时间"""
        return self._client.expire(key, seconds)

    def ttl(self, key: str) -> int:
        """获取剩余过期时间（秒）"""
        return self._client.ttl(key)

    # ==================== Hash 操作 ====================

    def hget(self, name: str, key: str) -> Optional[str]:
        """获取 Hash 中的字段值"""
        return self._client.hget(name, key)

    def hset(self, name: str, key: str, value: Any) -> int:
        """设置 Hash 中的字段值"""
        return self._client.hset(name, key, value)

    def hgetall(self, name: str) -> dict:
        """获取 Hash 所有字段"""
        return self._client.hgetall(name)

    def hdel(self, name: str, *keys: str) -> int:
        """删除 Hash 中的字段"""
        return self._client.hdel(name, *keys)

    # ==================== List 操作 ====================

    def lpush(self, name: str, *values: Any) -> int:
        """左侧插入"""
        return self._client.lpush(name, *values)

    def rpush(self, name: str, *values: Any) -> int:
        """右侧插入"""
        return self._client.rpush(name, *values)

    def lpop(self, name: str) -> Optional[str]:
        """左侧弹出"""
        return self._client.lpop(name)

    def rpop(self, name: str) -> Optional[str]:
        """右侧弹出"""
        return self._client.rpop(name)

    def lrange(self, name: str, start: int, end: int) -> list:
        """获取列表范围"""
        return self._client.lrange(name, start, end)

    def llen(self, name: str) -> int:
        """获取列表长度"""
        return self._client.llen(name)

    # ==================== 工具方法 ====================

    def ping(self) -> bool:
        """测试连接"""
        try:
            return self._client.ping()
        except redis.ConnectionError:
            return False

    def flushdb(self) -> bool:
        """清空当前数据库（谨慎使用）"""
        return self._client.flushdb()

    def close(self):
        """关闭连接"""
        if self._client:
            self._client.close()
            self._client = None


def connect(host: str = "localhost", port: int = 6379, db: int = 0,
            password: Optional[str] = None) -> RedisClient:
    """创建 Redis 连接
    
    Args:
        host: Redis 服务器地址
        port: 端口
        db: 数据库编号
        password: 密码
    
    Returns:
        RedisClient 实例
    """
    return RedisClient(
        host=host,
        port=port,
        db=db,
        password=password,
        decode_responses=True
    )
