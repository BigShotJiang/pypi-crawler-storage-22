"""缓存装饰器"""
from typing import Any, Callable, Optional
import redis as redis_lib


def cache(key: str, expire: int = 300, prefix: str = "cache"):
    """缓存装饰器 - 将函数结果缓存到 Redis
    
    Args:
        key: 缓存键（支持格式化为 {prefix}:{func_name}:{key}）
        expire: 缓存过期时间（秒），默认 5 分钟
        prefix: 缓存前缀，默认 "cache"
    
    Usage:
        @cache(key="user:{user_id}", expire=600)
        def get_user(user_id: int):
            # 首次调用查询数据库
            return db.query_user(user_id)
        
        # 后续调用直接从 Redis 获取
        user = get_user(123)
    
    Example with dynamic key:
        @cache(key="{args[0]}", expire=300)
        def get_data(id: int):
            return api.fetch(id)
    
    Args in key format:
        - {func.__name__} - 函数名
        - {args[i]} - 位置参数
        - {kwargs[key]} - 关键字参数
    """
    def decorator(func: Callable) -> Callable:
        def wrapper(*args, **kwargs) -> Any:
            # 获取 Redis 客户端
            client = redis_lib.Redis(decode_responses=True)
            if not client.ping():
                # Redis 不可用，直接调用函数
                return func(*args, **kwargs)
            
            # 构建缓存键
            cache_key = _build_cache_key(key, func, args, kwargs, prefix)
            
            # 尝试从缓存获取
            cached = client.get(cache_key)
            if cached is not None:
                return cached
            
            # 缓存未命中，执行函数
            result = func(*args, **kwargs)
            
            # 存储缓存
            if result is not None:
                client.set(cache_key, result, ex=expire)
            
            return result
        return wrapper
    return decorator


def _build_cache_key(key_format: str, func: Callable, args: tuple,
                     kwargs: dict, prefix: str) -> str:
    """构建缓存键"""
    import inspect
    
    # 默认格式: prefix:func_name:key
    if not key_format:
        key_format = ""
    
    # 替换函数名
    key = key_format.format(func.__name__)
    
    # 替换位置参数
    sig = inspect.signature(func)
    params = list(sig.parameters.keys())
    
    for i, arg in enumerate(args):
        placeholder = f"{{{params[i]}}}" if i < len(params) else f"{{arg{i}}}"
        key = key.replace(placeholder, str(arg))
    
    # 替换关键字参数
    for k, v in kwargs.items():
        placeholder = f"{{{k}}}"
        key = key.replace(placeholder, str(v))
    
    # 完整键: prefix:func_name:dynamic_key
    full_key = f"{prefix}:{func.__name__}"
    if key and key != func.__name__:
        full_key = f"{prefix}:{key}"
    
    return full_key


def clear_cache(key: str, prefix: str = "cache"):
    """清除指定缓存
    
    Args:
        key: 缓存键
        prefix: 缓存前缀
    """
    client = redis_lib.Redis(decode_responses=True)
    full_key = f"{prefix}:{key}"
    client.delete(full_key)


def clear_prefix(prefix: str):
    """清除指定前缀的所有缓存（谨慎使用）
    
    Args:
        prefix: 缓存前缀
    """
    client = redis_lib.Redis(decode_responses=True)
    pattern = f"{prefix}:*"
    
    for key in client.scan_iter(match=pattern):
        client.delete(key)
