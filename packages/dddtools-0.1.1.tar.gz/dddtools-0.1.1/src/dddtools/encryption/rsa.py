"""RSA加密/解密、签名/验签工具"""
import base64
import hashlib
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
from Crypto.Signature import pkcs1_15
from typing import Tuple, Optional


class RSAEncrypt:
    """RSA加密工具类"""
    
    def __init__(self, private_key: str = None, public_key: str = None):
        """
        Args:
            private_key: PEM格式私钥字符串
            public_key: PEM格式公钥字符串
        """
        self.private_key = None
        self.public_key = None
        
        if private_key:
            self.private_key = RSA.import_key(private_key)
        if public_key:
            self.public_key = RSA.import_key(public_key)
    
    @classmethod
    def generate_keys(cls, key_size: int = 2048) -> Tuple[str, str]:
        """
        生成RSA密钥对
        
        Args:
            key_size: 密钥长度（1024, 2048, 4096）
        
        Returns:
            (private_key, public_key) PEM格式字符串元组
        """
        key = RSA.generate(key_size)
        private_pem = key.export_key().decode('utf-8')
        public_pem = key.publickey().export_key().decode('utf-8')
        return private_pem, public_pem
    
    def encrypt(self, data: str) -> str:
        """使用公钥加密，返回Base64编码"""
        if not self.public_key:
            raise ValueError("未设置公钥")
        
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        cipher = PKCS1_v1_5.new(self.public_key)
        encrypted = cipher.encrypt(data)
        return base64.b64encode(encrypted).decode('ascii')
    
    def decrypt(self, encrypted_data: str) -> str:
        """使用私钥解密Base64编码的数据"""
        if not self.private_key:
            raise ValueError("未设置私钥")
        
        encrypted = base64.b64decode(encrypted_data)
        cipher = PKCS1_v1_5.new(self.private_key)
        decrypted = cipher.decrypt(encrypted, sentinel=None)
        return decrypted.decode('utf-8')
    
    def sign(self, data: str, hash_method: str = "sha256") -> str:
        """使用私钥签名"""
        if not self.private_key:
            raise ValueError("未设置私钥")
        
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        # 使用正确的签名方式
        if hash_method == "sha256":
            from Crypto.Hash import SHA256
            h = SHA256.new(data)
        elif hash_method == "sha1":
            from Crypto.Hash import SHA1
            h = SHA1.new(data)
        elif hash_method == "md5":
            from Crypto.Hash import MD5
            h = MD5.new(data)
        else:
            h = hashlib.new(hash_method, data)
        
        signature = pkcs1_15.new(self.private_key).sign(h)
        return base64.b64encode(signature).decode('ascii')
    
    def verify(self, data: str, signature: str, hash_method: str = "sha256") -> bool:
        """使用公钥验证签名"""
        if not self.public_key:
            raise ValueError("未设置公钥")
        
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        try:
            signature_bytes = base64.b64decode(signature)
            # 使用正确的哈希方式
            if hash_method == "sha256":
                from Crypto.Hash import SHA256
                h = SHA256.new(data)
            elif hash_method == "sha1":
                from Crypto.Hash import SHA1
                h = SHA1.new(data)
            elif hash_method == "md5":
                from Crypto.Hash import MD5
                h = MD5.new(data)
            else:
                h = hashlib.new(hash_method, data)
            
            pkcs1_15.new(self.public_key).verify(h, signature_bytes)
            return True
        except (ValueError, TypeError):
            return False
    
    def get_public_key(self) -> str:
        """导出公钥（PEM格式）"""
        if not self.public_key:
            raise ValueError("未设置公钥")
        return self.public_key.export_key().decode('utf-8')
    
    def get_private_key(self) -> str:
        """导出私钥（PEM格式）"""
        if not self.private_key:
            raise ValueError("未设置私钥")
        return self.private_key.export_key().decode('utf-8')


def generate_rsa_keys(key_size: int = 2048) -> Tuple[str, str]:
    """快速生成RSA密钥对"""
    return RSAEncrypt.generate_keys(key_size)


def encrypt_rsa(data: str, public_key: str) -> str:
    """快速RSA加密"""
    return RSAEncrypt(public_key=public_key).encrypt(data)


def decrypt_rsa(encrypted_data: str, private_key: str) -> str:
    """快速RSA解密"""
    return RSAEncrypt(private_key=private_key).decrypt(encrypted_data)


def sign_data(data: str, private_key: str, hash_method: str = "sha256") -> str:
    """快速数据签名"""
    return RSAEncrypt(private_key=private_key).sign(data, hash_method)


def verify_signature(data: str, signature: str, public_key: str, 
                     hash_method: str = "sha256") -> bool:
    """快速验签"""
    return RSAEncrypt(public_key=public_key).verify(data, signature, hash_method)
