"""微信服务号 - Access Token 管理"""
import requests
import time
from typing import Optional, Dict, Any
from ..redis import RedisClient, connect


WECHAT_API_BASE = "https://api.weixin.qq.com"


class WeChatClient:
    """微信服务号客户端"""

    _instance = None

    def __new__(cls, appid: str, appsecret: str,
                redis_client: Optional[RedisClient] = None):
        """单例模式"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        cls._instance._init(appid, appsecret, redis_client)
        return cls._instance

    def _init(self, appid: str, appsecret: str,
              redis_client: Optional[RedisClient]):
        """初始化"""
        self._appid = appid
        self._appsecret = appsecret
        self._redis = redis_client
        self._token: Optional[str] = None
        self._expires_at: int = 0
        self._token_key = "wechat:access_token"

    @classmethod
    def init(cls, appid: str, appsecret: str,
             redis_host: str = "localhost", redis_port: int = 6379,
             redis_db: int = 1, redis_password: str = None):
        """便捷初始化 - 同时创建 Redis 连接"""
        redis = connect(
            host=redis_host,
            port=redis_port,
            db=redis_db,
            password=redis_password
        )
        return cls(appid, appsecret, redis)

    @property
    def token(self) -> str:
        """获取 access_token（自动刷新）"""
        # 1. 先从 Redis 获取
        if self._redis and self._redis.ping():
            cached = self._redis.get(self._token_key)
            if cached:
                return cached

        # 2. Redis 没有，从微信服务器获取
        if not self._token or time.time() > self._expires_at:
            self._refresh()

        # 3. 存入 Redis
        if self._redis and self._redis.ping() and self._token:
            cache_seconds = max(600, 7000 - 60)
            self._redis.set(self._token_key, self._token, ex=cache_seconds)

        return self._token

    def _refresh(self):
        """从微信服务器刷新 token"""
        url = f"{WECHAT_API_BASE}/cgi-bin/token"
        params = {
            "grant_type": "client_credential",
            "appid": self._appid,
            "secret": self._appsecret
        }

        try:
            resp = requests.get(url, params=params, timeout=10)
            data = resp.json()

            if "access_token" in data:
                self._token = data["access_token"]
                self._expires_at = time.time() + data.get("expires_in", 7200)
            else:
                raise Exception(f"获取 token 失败: {data.get('errmsg', '未知错误')}")

        except Exception as e:
            raise Exception(f"微信 API 请求失败: {e}")

    def clear_cache(self):
        """清除 Redis 缓存（强制下次从服务器获取）"""
        if self._redis:
            self._redis.delete(self._token_key)

    def send_template(self, template_id: str, touser: str,
                     data: Dict[str, Any], 
                     url: Optional[str] = None) -> Dict:
        """发送模板消息
        
        Args:
            template_id: 模板 ID
            touser: 接收用户 OpenID
            data: 模板数据，key 为模板中的占位符（不含 .DATA）
            url: 跳转链接（可选）
        
        Example:
            wechat.send_template(
                template_id="fPfCdbW0rOEWhJmfFGewIADyPrImk00eGhTbweeR3Yw",
                touser="openid123",
                data={
                    "thing4": "XX项目",
                    "character_string47": "DD20260207001",
                    "const53": "待审核"
                },
                url="https://xxx.com/order/DD20260207001"
            )
        """
        url = f"{WECHAT_API_BASE}/cgi-bin/message/template/send"
        params = {"access_token": self.token}

        payload = {
            "touser": touser,
            "template_id": template_id,
            "data": {k: {"value": v} for k, v in data.items()}
        }

        if url:
            payload["url"] = url

        resp = requests.post(url, params=params, json=payload, timeout=10)
        return resp.json()

    # ==================== 便捷方法 ====================

    def send_workorder_reminder(
        self,
        touser: str,
        project_name: str,
        order_no: str,
        current_node: str,
        url: Optional[str] = None
    ) -> Dict:
        """发送工单催办提醒
        
        模板: 工单催办提醒 (fPfCdbW0rOEWhJmfFGewIADyPrImk00eGhTbweeR3Yw)
        
        Args:
            touser: 接收用户 OpenID
            project_name: 项目名称 (thing4)
            order_no: 订单编号 (character_string47)
            current_node: 当前节点 (const53)
            url: 跳转链接
        """
        template_id = "fPfCdbW0rOEWhJmfFGewIADyPrImk00eGhTbweeR3Yw"
        return self.send_template(
            template_id=template_id,
            touser=touser,
            data={
                "thing4": project_name,
                "character_string47": order_no,
                "const53": current_node
            },
            url=url
        )

    def get_user_info(self, openid: str, lang: str = "zh_CN") -> Dict:
        """获取用户基本信息
        
        Args:
            openid: 用户 OpenID
            lang: 语言版本，默认 zh_CN
        
        Returns:
            用户信息 dict，包含 unionid, nickname, headimgurl 等
        """
        url = f"{WECHAT_API_BASE}/cgi-bin/user/info"
        params = {
            "access_token": self.token,
            "openid": openid,
            "lang": lang
        }
        resp = requests.get(url, params=params, timeout=10)
        return resp.json()

    def get_user_list(self, next_openid: str = "") -> Dict:
        """获取用户列表
        
        Args:
            next_openid: 上一页最后一个 OpenID，第一次传空
        
        Returns:
            {'total': 1000, 'count': 100, 'data': {'openid': [...]}, 'next_openid': '...'}
        """
        url = f"{WECHAT_API_BASE}/cgi-bin/user/get"
        params = {"access_token": self.token}
        if next_openid:
            params["next_openid"] = next_openid
        resp = requests.get(url, params=params, timeout=10)
        return resp.json()

    def find_openid_by_unionid(self, unionid: str) -> Optional[str]:
        """通过 UnionID 查找 OpenID（用户需已关注公众号）
        
        Args:
            unionid: 用户 UnionID
        
        Returns:
            OpenID 或 None（未找到或未关注）
        """
        # 1. 获取用户列表
        resp = self.get_user_list()
        openids = resp.get("data", {}).get("openid", [])
        
        # 2. 批量获取用户信息（最多 100 个）
        while openids:
            batch = openids[:100]
            openids = openids[100:]
            
            url = f"{WECHAT_API_BASE}/cgi-bin/user/info/batchget"
            params = {"access_token": self.token}
            payload = {
                "user_list": [{"openid": oid, "lang": "zh_CN"} for oid in batch]
            }
            
            resp = requests.post(url, params=params, json=payload, timeout=10)
            data = resp.json()
            
            for user in data.get("user_info_list", []):
                if user.get("unionid") == unionid:
                    return user["openid"]
            
            # 每次最多查 100 个，需要先获取所有再遍历
            # 如果列表超过 100，需要循环获取完整列表
            pass
        
        # 获取完整列表（超过 100 时）
        all_openids = []
        next_openid = ""
        while True:
            resp = self.get_user_list(next_openid)
            openid_list = resp.get("data", {}).get("openid", [])
            all_openids.extend(openid_list)
            
            next_openid = resp.get("next_openid", "")
            if not next_openid:
                break
        
        # 批量查询（每批 100）
        for i in range(0, len(all_openids), 100):
            batch = all_openids[i:i+100]
            
            url = f"{WECHAT_API_BASE}/cgi-bin/user/info/batchget"
            params = {"access_token": self.token}
            payload = {
                "user_list": [{"openid": oid, "lang": "zh_CN"} for oid in batch]
            }
            
            resp = requests.post(url, params=params, json=payload, timeout=10)
            data = resp.json()
            
            for user in data.get("user_info_list", []):
                if user.get("unionid") == unionid:
                    return user["openid"]
        
        return None
