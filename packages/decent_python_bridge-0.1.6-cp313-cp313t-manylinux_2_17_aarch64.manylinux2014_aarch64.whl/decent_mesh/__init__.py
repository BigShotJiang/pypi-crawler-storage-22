from .decent_mesh import *

__doc__ = decent_mesh.__doc__
if hasattr(decent_mesh, "__all__"):
    __all__ = decent_mesh.__all__