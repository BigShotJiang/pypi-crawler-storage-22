"""
CLI entry point for running ShareBoard as a module.

Usage: python -m shareboard
"""

from shareboard import main

if __name__ == "__main__":
    main()
