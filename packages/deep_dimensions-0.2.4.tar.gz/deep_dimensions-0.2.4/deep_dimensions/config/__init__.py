"""Configuration module for deep_dimensions."""

from deep_dimensions.config.settings import ScalingConfig

__all__ = ["ScalingConfig"]
