"""Allow running the CLI as: python -m deepagents.cli."""

from deepagents_cli.main import cli_main

if __name__ == "__main__":
    cli_main()
