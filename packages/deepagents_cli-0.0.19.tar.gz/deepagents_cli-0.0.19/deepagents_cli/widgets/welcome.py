"""Welcome banner widget for deepagents-cli."""

from __future__ import annotations

import asyncio
import os
from typing import Any

from rich.style import Style
from rich.text import Text
from textual.widgets import Static

from deepagents_cli.config import _is_editable_install, get_banner, get_glyphs, settings


def _fetch_project_url(project_name: str) -> str | None:
    """Fetch the LangSmith project URL (blocking, run in a thread).

    Returns:
        Project URL string if found, None otherwise.
    """
    try:
        # Optional dep
        from langsmith import Client  # noqa: PLC0415

        project = Client().read_project(project_name=project_name)
    except (OSError, ValueError, RuntimeError):
        return None
    else:
        return project.url or None


class WelcomeBanner(Static):
    """Welcome banner displayed at startup."""

    DEFAULT_CSS = """
    WelcomeBanner {
        height: auto;
        padding: 1;
        margin-bottom: 1;
    }
    """

    def __init__(self, thread_id: str | None = None, **kwargs: Any) -> None:
        """Initialize the welcome banner.

        Args:
            thread_id: Optional thread ID to display in the banner.
            **kwargs: Additional arguments passed to parent.
        """
        # Avoid collision with Widget._thread_id (Textual internal int)
        self._cli_thread_id: str | None = thread_id
        self._project_name: str | None = None

        langsmith_key = os.environ.get("LANGSMITH_API_KEY") or os.environ.get(
            "LANGCHAIN_API_KEY"
        )
        langsmith_tracing = os.environ.get("LANGSMITH_TRACING") or os.environ.get(
            "LANGCHAIN_TRACING_V2"
        )

        if langsmith_key and langsmith_tracing:
            self._project_name = (
                settings.deepagents_langchain_project
                or os.environ.get("LANGSMITH_PROJECT")
                or "default"
            )

        super().__init__(self._build_banner(), **kwargs)

    def on_mount(self) -> None:
        """Kick off background fetch for LangSmith project URL."""
        if self._project_name:
            self.run_worker(self._fetch_and_update, exclusive=True)

    async def _fetch_and_update(self) -> None:
        """Fetch the LangSmith URL in a thread and update the banner."""
        if not self._project_name:
            return
        try:
            project_url = await asyncio.wait_for(
                asyncio.to_thread(_fetch_project_url, self._project_name),
                timeout=2.0,
            )
        except (TimeoutError, OSError):
            project_url = None
        if project_url:
            self.update(self._build_banner(project_url))

    def _build_banner(self, project_url: str | None = None) -> Text:
        """Build the banner rich text.

        When a `project_url` is provided and a thread ID is set, the thread ID
        is rendered as a clickable hyperlink to the LangSmith thread view.

        Args:
            project_url: LangSmith project URL used for linking the project
                name and thread ID. When `None`, text is rendered without links.

        Returns:
            Rich Text object containing the formatted banner.
        """
        banner = Text()
        # Use orange for local, green for production
        banner_color = "#f97316" if _is_editable_install() else "#10b981"
        banner.append(get_banner() + "\n", style=Style(bold=True, color=banner_color))

        if self._project_name:
            banner.append(f"{get_glyphs().checkmark} ", style="green")
            banner.append("LangSmith tracing: ")
            if project_url:
                banner.append(
                    f"'{self._project_name}'",
                    style=Style(color="cyan", link=project_url),
                )
            else:
                banner.append(f"'{self._project_name}'", style="cyan")
            banner.append("\n")

        if self._cli_thread_id:
            if project_url:
                thread_url = f"{project_url.rstrip('/')}/t/{self._cli_thread_id}"
                thread_line = Text.assemble(
                    ("Thread: ", "dim"),
                    (self._cli_thread_id, Style(dim=True, link=thread_url)),
                    ("\n", "dim"),
                )
                banner.append_text(thread_line)
            else:
                banner.append(f"Thread: {self._cli_thread_id}\n", style="dim")

        banner.append("Ready to code! What would you like to build?\n", style="#10b981")
        bullet = get_glyphs().bullet
        banner.append(
            f"Enter send {bullet} Ctrl+J newline {bullet} @ files {bullet} / commands",
            style="dim",
        )
        return banner
