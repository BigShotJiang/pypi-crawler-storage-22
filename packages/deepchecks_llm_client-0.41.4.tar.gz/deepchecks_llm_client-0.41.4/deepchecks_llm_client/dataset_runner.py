"""Module for running datasets on deployments with parallel execution."""
import asyncio
import time
import typing as t

import httpx

from deepchecks_llm_client.data_types import Dataset, DatasetRunResult, DatasetRunSampleResult, DatasetSample, Deployment


class DatasetRunner:
    """Runner for executing dataset samples against a deployment with parallel processing."""

    def __init__(
        self,
        deployment: Deployment,
        app_name: str,
        version_name: t.Optional[str] = None,
        env_type: t.Optional[str] = None,
        additional_headers: t.Optional[t.Dict[str, str]] = None,
        verify_ssl: bool = True,
    ):
        """Initialize the dataset runner.

        Parameters
        ----------
        deployment : Deployment
            The deployment configuration to use for running the dataset
        app_name : str
            Application name for dc_fields
        version_name : str, optional
            Version name for dc_fields
        env_type : str, optional
            Environment type for dc_fields
        additional_headers : dict, optional
            Additional headers to include in requests (beyond those in deployment config)
        verify_ssl : bool, default=True
            Whether to verify SSL certificates for HTTPS requests
        """
        self.deployment = deployment
        self.app_name = app_name
        self.version_name = version_name
        self.env_type = env_type
        self.additional_headers = additional_headers or {}
        self.verify_ssl = verify_ssl

    def _build_headers(self) -> t.Dict[str, str]:
        """Build the complete headers dictionary from deployment and additional headers."""
        headers = {h.name: h.value for h in self.deployment.headers}
        headers.update(self.additional_headers)
        return headers

    def _create_error_result(
        self,
        sample: DatasetSample,
        error_msg: str,
        error_type: str,
        duration: float,
        attempt: int,
        status_code: t.Optional[int] = None,
    ) -> DatasetRunSampleResult:
        """Create an error result object."""
        return DatasetRunSampleResult(
            sample_id=sample.id,
            sample_input=sample.input,
            sample_output=sample.output,
            sample_metadata=sample.sample_metadata,
            success=False,
            error_message=error_msg,
            error_type=error_type,
            duration_seconds=duration,
            retries=attempt,
            status_code=status_code,
        )

    def _notify_widget_failure(
        self,
        live_widget_update: t.Optional[t.Callable],
        sample_id: int,
        sample_input: t.Dict,
        error_msg: str,
        duration: float,
        attempt: int,
        status_code: t.Optional[int] = None,
        sample_metadata: t.Optional[t.Dict[str, t.Any]] = None,
    ) -> None:
        """Notify widget of failure."""
        if live_widget_update:
            live_widget_update(
                sample_id,
                status='failed',
                input=sample_input,
                error=error_msg,
                duration=duration,
                retries=attempt,
                status_code=status_code,
                sample_metadata=sample_metadata,
            )

    async def _run_single_sample(
        self,
        client: httpx.AsyncClient,
        sample: DatasetSample,
        semaphore: asyncio.Semaphore,
        live_widget_update: t.Optional[t.Callable] = None,
    ) -> DatasetRunSampleResult:
        """Run a single dataset sample against the deployment.

        Parameters
        ----------
        client : httpx.AsyncClient
            The async HTTP client to use
        sample : DatasetSample
            The dataset sample to run
        semaphore : asyncio.Semaphore
            Semaphore to limit concurrent requests
        live_widget_update : callable, optional
            Callback for live widget updates

        Returns
        -------
        DatasetRunSampleResult
            The result of running the sample
        """
        async with semaphore:
            if live_widget_update:
                live_widget_update(sample.id, status='in_progress', input=sample.input)

            # Build request body once with dc_fields and content
            request_body = {
                "dc_fields": {"app_name": self.app_name},
                "content": sample.input,
            }
            if self.version_name:
                request_body["dc_fields"]["version_name"] = self.version_name
            if self.env_type:
                request_body["dc_fields"]["env_type"] = self.env_type

            start_time = time.time()

            for attempt in range(self.deployment.max_retries + 1):
                try:
                    response = await client.post(
                        self.deployment.deployment_url,
                        json=request_body,
                        timeout=self.deployment.timeout,
                    )
                    response.raise_for_status()

                    duration = time.time() - start_time

                    try:
                        response_data = response.json()
                    except (ValueError, TypeError):
                        response_data = {"text": response.text}

                    result = DatasetRunSampleResult(
                        sample_id=sample.id,
                        sample_input=sample.input,
                        sample_output=sample.output,
                        sample_metadata=sample.sample_metadata,
                        success=True,
                        deployment_response=response_data,
                        duration_seconds=duration,
                        retries=attempt,
                        status_code=response.status_code,
                    )

                    if live_widget_update:
                        live_widget_update(
                            sample.id,
                            status='completed',
                            input=sample.input,
                            output=response_data,
                            duration=duration,
                            retries=attempt,
                            status_code=response.status_code,
                            sample_metadata=sample.sample_metadata,
                        )

                    return result

                except httpx.HTTPStatusError as e:
                    if attempt == self.deployment.max_retries:
                        duration = time.time() - start_time
                        error_msg = f"HTTP {e.response.status_code}: {e.response.text}"
                        result = self._create_error_result(
                            sample, error_msg, "HTTPStatusError", duration, attempt, e.response.status_code
                        )
                        self._notify_widget_failure(
                            live_widget_update, sample.id, sample.input, error_msg, duration, attempt,
                            status_code=e.response.status_code, sample_metadata=sample.sample_metadata
                        )
                        return result

                except httpx.TimeoutException:
                    if attempt == self.deployment.max_retries:
                        duration = time.time() - start_time
                        error_msg = f"Request timed out after {self.deployment.timeout}s"
                        result = self._create_error_result(sample, error_msg, "TimeoutException", duration, attempt)
                        self._notify_widget_failure(
                            live_widget_update, sample.id, sample.input, error_msg, duration, attempt,
                            sample_metadata=sample.sample_metadata
                        )
                        return result

                except Exception as e:  # pylint: disable=broad-exception-caught
                    if attempt == self.deployment.max_retries:
                        duration = time.time() - start_time
                        error_msg = str(e)
                        result = self._create_error_result(sample, error_msg, type(e).__name__, duration, attempt)
                        self._notify_widget_failure(
                            live_widget_update, sample.id, sample.input, error_msg, duration, attempt,
                            sample_metadata=sample.sample_metadata
                        )
                        return result

        # Fallback for unexpected control flow
        duration = time.time() - start_time
        error_msg = "Unknown error"
        result = self._create_error_result(sample, error_msg, "Unknown", duration, self.deployment.max_retries)
        self._notify_widget_failure(
            live_widget_update, sample.id, sample.input, error_msg, duration, self.deployment.max_retries,
            sample_metadata=sample.sample_metadata
        )
        return result

    async def execute_app(
        self,
        dataset: Dataset,
        samples: t.List[DatasetSample],
        progress_callback: t.Optional[t.Callable[[int, int], None]] = None,
        live_widget_update: t.Optional[t.Callable] = None,
    ) -> DatasetRunResult:
        """Run the dataset asynchronously with parallel processing.

        Parameters
        ----------
        dataset : Dataset
            The dataset being run
        samples : list of DatasetSample
            The samples to run
        progress_callback : callable, optional
            Callback function to report progress, receives (completed, total) as arguments

        Returns
        -------
        DatasetRunResult
            The aggregated results of running all samples
        """
        start_time = time.time()

        # Create semaphore to limit concurrent requests
        semaphore = asyncio.Semaphore(self.deployment.max_concurrent)

        # Build headers
        headers = self._build_headers()

        # Create async HTTP client
        async with httpx.AsyncClient(
            headers=headers,
            verify=self.verify_ssl,
            follow_redirects=True,
        ) as client:
            # Create coroutines for all samples (awaited in as_completed loop below)
            coroutines = [
                self._run_single_sample(client, sample, semaphore, live_widget_update)  # pylint: disable=non-awaited-async
                for sample in samples
            ]

            # Run with progress tracking
            results: list[DatasetRunSampleResult] = []
            for coro in asyncio.as_completed(coroutines):
                result = await coro
                results.append(result)

                if progress_callback:
                    progress_callback(len(results), len(samples))

        # Calculate statistics
        duration = time.time() - start_time
        successful = sum(1 for r in results if r.success)
        failed = len(results) - successful

        return DatasetRunResult(
            dataset_name=dataset.dataset_name,
            deployment_name=self.deployment.deployment_name,
            total_samples=len(samples),
            successful_samples=successful,
            failed_samples=failed,
            duration_seconds=duration,
            results=results,
            app_name=self.app_name,
            version_name=self.version_name,
            env_type=self.env_type,
            additional_headers=self.additional_headers,
            verify_ssl=self.verify_ssl,
            _deployment=self.deployment,
        )
