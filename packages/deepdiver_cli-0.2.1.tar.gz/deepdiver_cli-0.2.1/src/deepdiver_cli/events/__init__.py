"""事件系统模块

提供事件驱动架构支持，解耦 Agent/LLM 业务逻辑和 UI 渲染层。
"""

# 事件总线
from .bus import EventBus

# 事件类型枚举（用于订阅）
from .types import AgentEventType

# 具体事件数据类（用于发布）
from .types import (
    StepStartEvent,
    StepEndEvent,
    ThinkingDeltaEvent,
    KeyFindingEvent,
    ToolCallEvent,
    ToolResultEvent,
    CompleteEvent,
    ErrorEvent,
)

__all__ = [
    # EventBus
    "EventBus",
    # 事件类型枚举
    "AgentEventType",
    # 事件数据类
    "StepStartEvent",
    "StepEndEvent",
    "ThinkingDeltaEvent",
    "KeyFindingEvent",
    "ToolCallEvent",
    "ToolResultEvent",
    "CompleteEvent",
    "ErrorEvent",
]
