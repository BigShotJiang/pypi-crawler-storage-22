"""事件总线

实现发布-订阅模式的事件总线，解耦业务逻辑和UI渲染层。
"""

from collections import defaultdict
from typing import Callable, Awaitable, Any

from .types import (
    AgentEventType,
    StepStartEvent,
    StepEndEvent,
    ThinkingDeltaEvent,
    KeyFindingEvent,
    ToolCallEvent,
    ToolResultEvent,
    CompleteEvent,
    ErrorEvent,
)


class EventBus:
    """事件总线 - 解耦Agent/LLM和UI层

    实现发布-订阅模式，Agent/LLM 发布强类型事件，UI 层订阅事件并渲染。

    示例:
        ```python
        # 创建事件总线
        event_bus = EventBus()

        # 订阅事件
        async def on_step_start(step: int, max_steps: int):
            print(f"Step {step}/{max_steps}")

        event_bus.subscribe(AgentEventType.STEP_START, on_step_start)

        # 发布事件
        await event_bus.emit(StepStartEvent(step=1, max_steps=10))
        ```
    """

    def __init__(self):
        """初始化事件总线"""
        self._subscribers: dict[AgentEventType, list[Callable]] = defaultdict(list)

    def subscribe(
        self, event_type: AgentEventType, callback: Callable[..., Awaitable[None]]
    ):
        """订阅事件

        Args:
            event_type: 要订阅的事件类型
            callback: 异步回调函数，参数与事件数据类字段匹配

        示例:
            ```python
            # 订阅步骤开始事件
            async def on_step_start(step: int, max_steps: int):
                print(f"Starting step {step}/{max_steps}")

            event_bus.subscribe(AgentEventType.STEP_START, on_step_start)
            ```
        """
        self._subscribers[event_type].append(callback)

    def unsubscribe(
        self, event_type: AgentEventType, callback: Callable[..., Awaitable[None]]
    ):
        """取消订阅事件

        Args:
            event_type: 要取消订阅的事件类型
            callback: 要取消的回调函数
        """
        if callback in self._subscribers[event_type]:
            self._subscribers[event_type].remove(callback)

    async def emit(self, event: Any):
        """发布事件（异步通知所有订阅者）

        Args:
            event: 事件数据类实例（如 StepStartEvent）

        示例:
            ```python
            await event_bus.emit(StepStartEvent(step=1, max_steps=10))
            await event_bus.emit(KeyFindingEvent(finding="发现异常"))
            ```
        """
        # 根据事件类型确定事件类型枚举
        event_type_map = {
            StepStartEvent: AgentEventType.STEP_START,
            StepEndEvent: AgentEventType.STEP_END,
            ThinkingDeltaEvent: AgentEventType.THINKING_DELTA,
            KeyFindingEvent: AgentEventType.KEY_FINDING,
            ToolCallEvent: AgentEventType.TOOL_CALL,
            ToolResultEvent: AgentEventType.TOOL_RESULT,
            CompleteEvent: AgentEventType.COMPLETE,
            ErrorEvent: AgentEventType.ERROR,
        }

        event_type = event_type_map.get(type(event))
        if not event_type:
            return

        # 将数据类转换为字典传递给订阅者
        event_dict = event.__dict__

        for callback in self._subscribers[event_type]:
            try:
                await callback(**event_dict)
            except Exception as e:
                # 订阅者异常不应该影响其他订阅者
                print(f"Error in event subscriber: {e}")

    def clear(self):
        """清除所有订阅者（主要用于测试）"""
        self._subscribers.clear()
