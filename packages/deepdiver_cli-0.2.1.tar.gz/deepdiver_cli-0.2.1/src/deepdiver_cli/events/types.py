"""事件类型定义

定义 Agent 执行过程中的所有事件类型。
每种事件都有对应的数据类，提供类型安全。
"""

from enum import Enum
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


# ============================================================================
# 步骤事件
# ============================================================================


@dataclass
class StepStartEvent:
    """步骤开始事件"""

    step: int
    max_steps: int


@dataclass
class StepEndEvent:
    """步骤结束事件"""

    step: int
    max_steps: int


# ============================================================================
# LLM 推理事件
# ============================================================================


@dataclass
class ThinkingDeltaEvent:
    """思考增量事件

    LLM 思考过程中的增量内容。
    """

    content: str


@dataclass
class KeyFindingEvent:
    """关键发现事件

    LLM 在思考过程中识别出的关键信息。
    """

    finding: str


# ============================================================================
# 工具调用事件
# ============================================================================


@dataclass
class ToolCallEvent:
    """工具调用事件"""

    tool_name: str
    arguments: str


# 为了避免循环导入，这里使用 forward reference
@dataclass
class ToolResultEvent:
    """工具结果事件"""

    tool_name: str
    success: bool
    summary: str
    data: Optional[Any] = None
    error: Optional[dict] = None
    metadata: Optional[Dict] = None
    suggestions: Optional[List[str]] = None


# ============================================================================
# 任务事件
# ============================================================================


@dataclass
class CompleteEvent:
    """任务完成事件"""

    final_answer: str


@dataclass
class ErrorEvent:
    """错误事件"""

    error_message: str
    error_type: str
    context: Optional[dict] = None


# ============================================================================
# 事件联合类型
# ============================================================================

AgentEvent = (
    StepStartEvent
    | StepEndEvent
    | ThinkingDeltaEvent
    | KeyFindingEvent
    | ToolCallEvent
    | ToolResultEvent
    | CompleteEvent
    | ErrorEvent
)


class AgentEventType(Enum):
    """Agent事件类型（用于订阅匹配）

    定义 Agent 执行过程中的所有事件类型，用于事件驱动架构。
    UI 层可以订阅这些事件来实现渲染。

    注意：实际事件使用具体的数据类（如 StepStartEvent），
    这个 Enum 仅用于订阅时的类型匹配。
    """

    # 步骤事件
    STEP_START = "step_start"
    STEP_END = "step_end"

    # LLM 推理事件
    THINKING_DELTA = "thinking_delta"
    KEY_FINDING = "key_finding"

    # 工具调用事件
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"

    # 任务事件
    COMPLETE = "complete"
    ERROR = "error"
