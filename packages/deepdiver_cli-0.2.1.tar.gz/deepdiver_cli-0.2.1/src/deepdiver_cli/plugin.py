import importlib
from typing import Optional


class PluginException(Exception):
    pass

class PluginLoadException(PluginException):
    pass

class PluginConfigException(PluginException):
    pass

def create_plugin(path: Optional[str] = None):
    if not path:
        return None
    obj = _import_plugin(path)
    return obj() if callable(obj) else obj


def _import_plugin(path: str):
    # path like "pkg.module:Obj"
    mod, _, attr = path.partition(":")
    if not mod or not attr:
        raise PluginLoadException("Invalid path, expected 'pkg.module:Obj'")
    try:
        m = importlib.import_module(mod)
        return getattr(m, attr)
    except Exception as ex:
        raise PluginLoadException() from ex
