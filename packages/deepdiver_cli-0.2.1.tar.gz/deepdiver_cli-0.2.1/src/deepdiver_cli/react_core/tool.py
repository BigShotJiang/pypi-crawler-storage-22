from __future__ import annotations

from abc import ABC
import json
from typing import Any, Dict, List, Optional, Tuple
from pydantic import BaseModel, Field, ValidationError
import structlog

from deepdiver_cli.chat.chat_model import LLMToolSchema
from deepdiver_cli.config import LLMConfig
from deepdiver_cli.utils.pydantic_util import pydantic_function_parameters

logger = structlog.get_logger(__name__)


class ToolCallInput(BaseModel):
    """Base class for tool inputs; extend per tool."""


class ToolCallOutput(BaseModel):
    success: bool
    data: Any = None
    error: Optional[Dict] = None
    summary: Optional[str] = None
    metadata: Optional[Dict] = Field(default=None, exclude=True)
    suggestions: Optional[List[str]] = None


class ToolCallError(Exception):
    pass


class BaseTool[Params: ToolCallInput](ABC):
    """
    Base tool interface for ReAct.
    Each tool provides:
      - name: unique tool name
      - description: when to use this tool
      - input_model: a Pydantic model for input validation
      - __call__: async execution
    """

    name: str
    description: str
    params: type[Params]
    timeout_s: float = 15.0
    max_retries: int = 1

    def __init__(self) -> None:
        if not hasattr(self, "name") or not hasattr(self, "description"):
            raise ValueError("Tool must define name and description")

    async def call(self, json_args: Any) -> ToolCallOutput:
        function_args = {}
        try:
            function_args = json.loads(json_args)
        except json.JSONDecodeError as e:
            logger.error(
                "tool_call.arg_error",
                action=self.name,
                arguments=json_args,
            )
            raise ToolCallError(
                f"Tool arguments error: {e!r}, invalid json format"
            ) from e

        try:
            params = self.params.model_validate(function_args)
            return await self(params)
        except ValidationError as e:
            logger.error(
                "tool_call.arg_error",
                action=self.name,
                arguments=json_args,
            )
            raise ToolCallError(f"Invalid input for tool {self.name}: {e}")

    async def __call__(self, params: Params) -> ToolCallOutput:
        raise NotImplementedError

    @classmethod
    def schema(cls, llm_config: LLMConfig) -> LLMToolSchema:
        return LLMToolSchema(
            name=cls.name,
            description=cls.description,
            parameters=pydantic_function_parameters(cls.params, llm_config),
        )


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: Dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Duplicate tool name: {tool.name}")
        self._tools[tool.name] = tool

    def get(self, name: str) -> BaseTool:
        if name not in self._tools:
            raise ToolCallError(f"Unknown tool: {name}")
        return self._tools[name]

    def as_llm_tools(self, llm_config: LLMConfig) -> List[LLMToolSchema]:
        return [tool.schema(llm_config) for tool in self._tools.values()]

    def list_names(self) -> Tuple[str, ...]:
        return tuple(self._tools.keys())
