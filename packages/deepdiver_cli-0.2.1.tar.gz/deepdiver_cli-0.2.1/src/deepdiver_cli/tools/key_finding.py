from typing import TYPE_CHECKING, override

from pydantic import Field

from deepdiver_cli.react_core.tool import BaseTool, ToolCallInput, ToolCallOutput

if TYPE_CHECKING:
    from deepdiver_cli.events import EventBus


class KeyFindingInput(ToolCallInput):
    finding: str = Field(
        description="关键发现内容，简洁明了地描述重要线索或结论"
    )


class KeyFindingTool(BaseTool[KeyFindingInput]):
    """记录关键发现工具

    用于在分析过程中主动记录重要发现，让用户实时了解分析进展。

    使用场景：
    - 发现明确的异常、错误代码
    - 定位到具体的代码行或配置项
    - 识别出问题的根因或强相关因素
    - 排除某个假设

    示例：
        RecordKeyFinding(finding="发现异常：NullPointerException at UserService.java:42")
        RecordKeyFinding(finding="定位问题：登录超时原因为数据库连接池满")
        RecordKeyFinding(finding="排除网络问题：ping延迟正常")
    """

    name = "RecordKeyFinding"
    description = (
        "记录关键发现，让用户实时了解分析进展。\n\n"
        "## 为什么必须调用此工具？\n"
        "软件工程问题诊断通常需要数分钟甚至更长时间。如果你不在分析过程中实时推送发现，"
        "用户会产生焦虑感，不知道Agent是否卡住。通过此工具实时推送关键发现，用户能看到持续进展，"
        "建立信任感。\n\n"
        "## 何时必须调用？\n"
        "**记住：宁可多记录，不要少记录！** 在以下时刻立即调用：\n"
        "1. **发现任何异常**：错误堆栈、异常码、失败状态\n"
        "2. **定位到具体位置**：代码行、配置项、日志时间点\n"
        "3. **发现时间轴关键点**：状态变化、事件顺序、因果关系\n"
        "4. **识别根因或强相关因素**：即使不是100%确定，也要及时汇报\n"
        "5. **排除假设**：告诉用户你否定了某个方向\n\n"
        "## 使用要求\n"
        "- 简洁：每条发现一句话，不超过30字\n"
        "- 具体：包含文件名、行号、时间戳等关键信息\n"
        "- 实时：在思考/推理过程中立即调用，不要等到最终结论\n"
        "- 适度：建议每个step记录2-5条，但宁滥勿缺\n\n"
        "## 使用示例\n"
        'RecordKeyFinding(finding="发现异常：NullPointerException at UserService.java:42")\n'
        'RecordKeyFinding(finding="定位问题：LoginController.java:135 未校验 password 参数")\n'
        'RecordKeyFinding(finding="发现时序问题：激活请求(22:15:05)早于登录成功通知(22:15:33)")\n'
        'RecordKeyFinding(finding="排除网络问题：ping延迟正常(2ms)，无丢包")'
    )
    params = KeyFindingInput
    timeout_s = 1.0  # 快速返回，不应阻塞

    def __init__(self, event_bus: "EventBus"):
        super().__init__()
        self.event_bus = event_bus

    @override
    async def __call__(self, params) -> ToolCallOutput:
        """记录关键发现

        Args:
            params: 包含finding字段的参数

        Returns:
            ToolRet: 成功结果，包含关键发现内容
        """
        finding = params.finding.strip()

        # 限制长度，避免过长
        if len(finding) > 200:
            finding = finding[:200] + "..."

        # 发布关键发现事件，触发UI显示
        if self.event_bus:
            from deepdiver_cli.events import KeyFindingEvent
            await self.event_bus.emit(KeyFindingEvent(finding=finding))

        return ToolCallOutput(
            success=True,
            summary="Success",
        )
