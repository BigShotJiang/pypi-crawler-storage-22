import os
import asyncio
from typing import override
from pathlib import Path
from pydantic import Field

from deepdiver_cli.react_core.tool import BaseTool, ToolCallInput, ToolCallOutput
from deepdiver_cli.config import config


class LoadKnowledgeInput(ToolCallInput):
    knowledge_key: str = Field(
        description="知识库类型标识，例如：Login",
        min_length=1,
        max_length=50,
        pattern=r"^[A-Za-z0-9_]+$",  # 只允许字母数字下划线
    )


class LoadKnowledgeTool(BaseTool[LoadKnowledgeInput]):
    name = "LoadKnowledge"
    description = "加载与问题相关的诊断知识库。"
    params = LoadKnowledgeInput
    timeout_s = 2.0

    def _validate_path_safety(self, knowledge_key: str) -> Path:
        """
        防止路径遍历攻击，确保文件在KNOWLEDGE_DIR内
        """
        # 构建安全文件名：只能包含允许的字符
        safe_filename = f"{knowledge_key}.md"

        # 规范化路径并检查是否在知识库目录内
        try:
            # 使用commonpath检查防止目录遍历
            target_path = (self.knowledge_dir / safe_filename).resolve()
            if os.path.commonpath([target_path, self.knowledge_dir]) != str(
                self.knowledge_dir
            ):
                raise ValueError(f"非法路径访问: {knowledge_key}")

            return target_path
        except Exception as e:
            raise ValueError(f"路径验证失败: {e}")

    def __init__(self):
        super().__init__()
        self.knowledge_dir = config.knowledge_dir

    @override
    async def __call__(self, params) -> ToolCallOutput:
        """异步加载知识文件，返回原始Markdown内容"""
        knowledge_key = params.knowledge_key.strip()

        try:
            # 1. 路径安全检查
            knowledge_file = self._validate_path_safety(knowledge_key)

            # 2. 异步读取文件（避免阻塞事件循环）
            loop = asyncio.get_running_loop()

            # 使用run_in_executor避免阻塞
            result = await asyncio.wait_for(
                loop.run_in_executor(
                    None, self._load_knowledge, knowledge_file, knowledge_key
                ),
                timeout=self.timeout_s,
            )

            return result

        except asyncio.TimeoutError:
            return ToolCallOutput(
                success=False,
                summary=f"Knowledge '{knowledge_key}' loading timed out",
                error={
                    "status": "timeout",
                    "knowledge_key": knowledge_key,
                    "error_message": f"Knowledge loading timed out after {self.timeout_s}s",
                },
            )
        except ValueError as e:
            # 路径验证失败
            return ToolCallOutput(
                success=False,
                summary=f"Path check failed for '{knowledge_key}'",
                error={
                    "status": "security_error",
                    "knowledge_key": knowledge_key,
                    "msg": f"{e!r}",
                },
            )
        except Exception as e:
            # 其他意外错误
            return ToolCallOutput(
                success=False,
                summary=f"Failed to load knowledge '{knowledge_key}'",
                error={
                    "status": "unexpected_error",
                    "knowledge_key": knowledge_key,
                    "msg": f"{e!r}",
                },
            )

    def _load_knowledge(self, knowledge_file: Path, knowledge_key: str) -> ToolCallOutput:
        if not knowledge_file.exists():
            return ToolCallOutput(
                success=False,
                summary=f"Knowledge file not found: '{knowledge_key}'",
                error={
                    "status": "file_not_exists",
                    "knowledge_key": knowledge_key,
                    "msg": f"Knowledge file not found: {knowledge_file.name}",
                },
            )

        # 正常读取文件
        content = knowledge_file.read_text(encoding="utf-8")
        content_length = len(content)
       
        return ToolCallOutput(
            success=True,
            summary=f"Knowledge Loaded ({content_length} chars)",
            data={
                "knowledge_key": knowledge_key,
                "content": content,
                "file_path": str(knowledge_file),
            }
        )
