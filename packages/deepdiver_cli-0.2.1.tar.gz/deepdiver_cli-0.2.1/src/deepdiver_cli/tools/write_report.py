"""WriteReport tool for parsing and writing diagnostic reports."""

from pathlib import Path
from typing import override, Optional, TYPE_CHECKING
from pydantic import Field
import structlog
import json
import re
from datetime import datetime, timezone

from deepdiver_cli.react_core.tool import BaseTool, ToolCallInput, ToolCallOutput
from deepdiver_cli.utils.file_util import read_text
from deepdiver_cli.utils.xml import extract_tag_content

# Avoid circular imports
if TYPE_CHECKING:
    from deepdiver_cli.session import Session

logger = structlog.get_logger(__name__)


class WriteReportInput(ToolCallInput):
    """Input parameters for WriteReport tool."""

    report_content: str = Field(
        description="""XML-tagged Markdown report content.
        Ensure the format is correct. If the content contains characters such as `{` or `}`, they need to be escaped to avoid JSON parsing errors.
        """
    )


class WriteReportTool(BaseTool[WriteReportInput]):
    """
    WriteReport tool for parsing XML-tagged Markdown reports and generating
    structured JSON and multiple Markdown files.

    Features:
    - Parses XML tags from Markdown content
    - Builds structured JSON matching report schema
    - Writes multiple output files to session reports directory
    - Handles optional fields gracefully
    - Supports multiple diagnosis entries (P1, P2, etc.)
    """

    name = "WriteReport"
    description = read_text(Path(__file__).parent / "write_report.md")
    params = WriteReportInput
    timeout_s = 30.0

    def __init__(self, session: Optional["Session"] = None) -> None:
        """
        Initialize WriteReport tool with session context.

        Args:
            session: Session object for writing reports. If None, tool will fail when called.
        """
        super().__init__()
        self.session = session

        if not self.session:
            logger.warning("WriteReportTool initialized without session")

    @override
    async def __call__(self, params: WriteReportInput) -> ToolCallOutput:
        """
        Parse report content and generate output files.

        Args:
            params: Input containing report_content (XML-tagged Markdown)

        Returns:
            ToolRet with success status, list of written files, and summary
        """
        try:
            # Validate session is available
            if not self.session:
                return ToolCallOutput(
                    success=False,
                    summary="WriteReport error: No session available for writing reports",
                )

            # Parse report content
            report_data = self._parse_report(params.report_content)

            # Validate required fields
            validation_error = self._validate_report_data(report_data)
            if validation_error:
                return ToolCallOutput(
                    success=False,
                    summary=f"Report validation failed: {validation_error}",
                )

            # Write output files
            written_files = self._write_report_files(report_data)

            # Return success with absolute paths
            return ToolCallOutput(
                success=True,
                summary=f"Successfully wrote {len(written_files)} report files",
                data={
                    "written_files": written_files,
                    "diagnosis_count": len(report_data.get("diagnosis", [])),
                },
            )

        except Exception as e:
            logger.error("WriteReport error", error=str(e), exc_info=True)
            return ToolCallOutput(success=False, summary=f"WriteReport error: {str(e)}")

    def _parse_report(self, content: str) -> dict:
        """
        Parse XML-tagged Markdown content into structured data.

        Args:
            content: Raw report content with XML tags

        Returns:
            Dictionary with parsed report data matching JSON schema
        """
        report_data = {}

        # Extract summary (required)
        summaries = extract_tag_content(content, "summary")
        if summaries:
            report_data["summary"] = summaries[0]

        # Extract timeline (optional)
        timelines = extract_tag_content(content, "timeline")
        if timelines:
            # Use the first timeline if there are multiple
            # This might be the top-level timeline
            report_data["timeline"] = timelines[0]

        # Extract diagnosis list
        diagnosis_blocks = extract_tag_content(content, "diagnosis")
        report_data["diagnosis"] = []

        for diagnosis_block in diagnosis_blocks:
            diagnosis_entry = self._parse_diagnosis_block(diagnosis_block)
            report_data["diagnosis"].append(diagnosis_entry)

        # Extract cross_analysis (optional)
        cross_analyses = extract_tag_content(content, "cross_analysis")
        if cross_analyses:
            report_data["cross_analysis"] = cross_analyses[0]

        # Extract recommendations (optional)
        recommendations = extract_tag_content(content, "recommendations")
        if recommendations:
            report_data["recommendations"] = recommendations[0]

        # Extract metadata (optional)
        metadata_blocks = extract_tag_content(content, "metadata")
        if metadata_blocks:
            report_data["metadata"] = self._parse_metadata_block(metadata_blocks[0])

        return report_data

    def _parse_diagnosis_block(self, block: str) -> dict:
        """
        Parse a single diagnosis block.

        Args:
            block: XML content within <diagnosis> tags

        Returns:
            Dictionary with diagnosis data
        """
        diagnosis = {}

        # Extract title
        titles = extract_tag_content(block, "title")
        if titles:
            diagnosis["title"] = titles[0]

        # Extract conclusion
        conclusions = extract_tag_content(block, "conclusion")
        if conclusions:
            diagnosis["conclusion"] = conclusions[0]

        # Extract confidence
        confidences = extract_tag_content(block, "confidence")
        if confidences:
            diagnosis["confidence"] = confidences[0]

        # Extract confidence_score
        confidence_scores = extract_tag_content(block, "confidence_score")
        if confidence_scores:
            try:
                diagnosis["confidence_score"] = float(confidence_scores[0])
            except ValueError:
                diagnosis["confidence_score"] = 0.0

        # Extract root_cause_level
        root_cause_levels = extract_tag_content(block, "root_cause_level")
        if root_cause_levels:
            diagnosis["root_cause_level"] = root_cause_levels[0]

        # Extract root_cause_score
        root_cause_scores = extract_tag_content(block, "root_cause_score")
        if root_cause_scores:
            try:
                diagnosis["root_cause_score"] = float(root_cause_scores[0])
            except ValueError:
                diagnosis["root_cause_score"] = 0

        # Extract reproduction_path
        reproduction_paths = extract_tag_content(block, "reproduction_path")
        if reproduction_paths:
            diagnosis["reproduction_path"] = reproduction_paths[0]

        # Extract timeline (diagnosis-level)
        timelines = extract_tag_content(block, "timeline")
        if timelines:
            diagnosis["timeline"] = timelines[0]

        # Extract evidence_chain
        evidence_chains = extract_tag_content(block, "evidence_chain")
        if evidence_chains:
            diagnosis["evidence_chain"] = evidence_chains[0]

        # Extract alternative_causes
        alternative_causes_blocks = extract_tag_content(block, "alternative_causes")
        if alternative_causes_blocks:
            diagnosis["alternative_causes"] = self._parse_alternative_causes(
                alternative_causes_blocks[0]
            )
        else:
            diagnosis["alternative_causes"] = []

        return diagnosis

    def _parse_alternative_causes(self, block: str) -> list:
        """
        Parse alternative causes block.

        Args:
            block: XML content within <alternative_causes> tags

        Returns:
            List of alternative cause dictionaries
        """
        causes = []
        cause_blocks = extract_tag_content(block, "alternative_cause")

        for cause_block in cause_blocks:
            cause = {}

            # Extract hypothesis
            hypotheses = extract_tag_content(cause_block, "hypothesis")
            if hypotheses:
                cause["hypothesis"] = hypotheses[0]

            # Extract confidence
            confidences = extract_tag_content(cause_block, "confidence")
            if confidences:
                cause["confidence"] = confidences[0]

            # Extract confidence_score
            confidence_scores = extract_tag_content(cause_block, "confidence_score")
            if confidence_scores:
                try:
                    cause["confidence_score"] = float(confidence_scores[0])
                except ValueError:
                    cause["confidence_score"] = 0.0

            # Extract root_cause_level
            root_cause_levels = extract_tag_content(cause_block, "root_cause_level")
            if root_cause_levels:
                cause["root_cause_level"] = root_cause_levels[0]

            # Extract root_cause_score
            root_cause_scores = extract_tag_content(cause_block, "root_cause_score")
            if root_cause_scores:
                try:
                    cause["root_cause_score"] = float(root_cause_scores[0])
                except ValueError:
                    cause["root_cause_score"] = 0

            # Extract exclusion_reason
            exclusion_reasons = extract_tag_content(cause_block, "exclusion_reason")
            if exclusion_reasons:
                cause["exclusion_reason"] = exclusion_reasons[0]

            causes.append(cause)

        return causes

    def _parse_metadata_block(self, block: str) -> dict:
        """
        Parse metadata block.

        Args:
            block: XML content within <metadata> tags

        Returns:
            Dictionary with metadata
        """
        metadata = {}

        # Extract diagnosis_date
        dates = extract_tag_content(block, "diagnosis_date")
        if dates:
            metadata["diagnosis_date"] = dates[0]

        # Extract review_count
        review_counts = extract_tag_content(block, "review_count")
        if review_counts:
            try:
                metadata["review_count"] = int(review_counts[0])
            except ValueError:
                metadata["review_count"] = 0

        # Extract review_result
        review_results = extract_tag_content(block, "review_result")
        if review_results:
            metadata["review_result"] = review_results[0]

        # Extract review_summary
        review_summaries = extract_tag_content(block, "review_summary")
        if review_summaries:
            metadata["review_summary"] = review_summaries[0]

        # Extract knowledge_keys
        knowledge_keys_blocks = extract_tag_content(block, "knowledge_keys")
        if knowledge_keys_blocks:
            keys = extract_tag_content(knowledge_keys_blocks[0], "key")
            metadata["knowledge_keys"] = keys
        else:
            metadata["knowledge_keys"] = []

        # Extract attachment_paths
        attachment_paths_blocks = extract_tag_content(block, "attachment_paths")
        if attachment_paths_blocks:
            paths = extract_tag_content(attachment_paths_blocks[0], "path")
            metadata["attachment_paths"] = paths
        else:
            metadata["attachment_paths"] = []

        # Extract code_paths
        code_paths_blocks = extract_tag_content(block, "code_paths")
        if code_paths_blocks:
            paths = extract_tag_content(code_paths_blocks[0], "path")
            metadata["code_paths"] = paths
        else:
            metadata["code_paths"] = []

        return metadata

    def _validate_report_data(self, data: dict) -> Optional[str]:
        """
        Validate required fields in parsed report data.

        Args:
            data: Parsed report data dictionary

        Returns:
            None if valid, error message string if invalid
        """
        # Check for required summary
        if "summary" not in data or not data["summary"]:
            return "Missing required field: summary"

        # Check for at least one diagnosis
        if "diagnosis" not in data or not data["diagnosis"]:
            return "Missing required field: diagnosis (at least one diagnosis required)"

        # Validate each diagnosis has required fields
        for idx, diagnosis in enumerate(data["diagnosis"]):
            if "title" not in diagnosis or not diagnosis["title"]:
                return f"Diagnosis {idx + 1}: Missing required field: title"
            if "conclusion" not in diagnosis or not diagnosis["conclusion"]:
                return f"Diagnosis {idx + 1}: Missing required field: conclusion"

        return None

    def _extract_problem_number(self, title: str) -> Optional[str]:
        """
        Extract problem number (P1, P2, etc.) from title.

        Args:
            title: Diagnosis title (e.g., "### 2.1 P1: Problem Name")

        Returns:
            Problem number string (e.g., "P1") or None if not found
        """
        # Try to match patterns like "P1:", "P2:", "P1：", "P1 ", etc.
        match = re.search(r"P(\d+)[：:\s]", title)
        if match:
            return f"P{match.group(1)}"
        return None

    def _write_report_files(self, data: dict) -> list[str]:
        """
        Write all report files to session reports directory.

        Args:
            data: Parsed and validated report data

        Returns:
            List of written file paths as absolute path strings
        """
        written_files: list[str] = []

        # 1. Write report.json
        json_content = json.dumps(data, indent=2, ensure_ascii=False)
        report_json_path = self.session.write_report("report.json", json_content)
        written_files.append(str(report_json_path))

        # 2. Write summary.md with core conclusions and timeline events
        if "summary" in data:
            summary_md = self._build_summary_markdown(data)
            summary_md_path = self.session.write_summary_md(summary_md)
            written_files.append(str(summary_md_path))

        # 3. Write individual diagnosis files (merged with evidence chain)
        for idx, diagnosis in enumerate(data.get("diagnosis", [])):
            # Extract problem number
            problem_num = self._extract_problem_number(diagnosis.get("title", ""))
            if not problem_num:
                problem_num = f"P{idx + 1}"

            # Write diagnosis file with evidence chain merged
            diagnosis_md = self._build_diagnosis_markdown_with_evidence(
                diagnosis, problem_num
            )
            diagnosis_filename = f"diagnosis_{problem_num}.md"
            diagnosis_md_path = self.session.write_report(
                diagnosis_filename, diagnosis_md
            )
            written_files.append(str(diagnosis_md_path))

        # 4. Generate HTML report
        html_content = self._generate_html_report(data)
        if html_content:
            html_path = self.session.write_report("report.html", html_content)
            written_files.append(str(html_path))
            logger.info(f"Generated HTML report: {html_path}")

        return written_files

    def _build_summary_markdown(self, data: dict) -> str:
        """
        Build summary markdown with core conclusions and timeline events.

        Args:
            data: Parsed report data dictionary

        Returns:
            Markdown content string
        """
        lines = []

        # Add summary section
        if "summary" in data:
            lines.append("# Summary")
            lines.append("")
            lines.append(data["summary"])
            lines.append("")

        # Add core conclusions from all diagnoses
        if "diagnosis" in data and data["diagnosis"]:
            lines.append("# Core Conclusions")
            lines.append("")
            for idx, diagnosis in enumerate(data["diagnosis"]):
                problem_num = self._extract_problem_number(diagnosis.get("title", ""))
                if not problem_num:
                    problem_num = f"P{idx + 1}"

                # Add problem title
                if "title" in diagnosis:
                    lines.append(f"## {diagnosis['title']}")
                    lines.append("")

                # Add conclusion
                if "conclusion" in diagnosis:
                    lines.append(diagnosis["conclusion"])
                    lines.append("")

                # Add confidence info
                if "confidence" in diagnosis:
                    lines.append(f"**Confidence:** {diagnosis['confidence']}")
                if "root_cause_level" in diagnosis:
                    lines.append(
                        f"**Root Cause Level:** {diagnosis['root_cause_level']}"
                    )
                lines.append("")

        # Add timeline section
        if "timeline" in data and data["timeline"]:
            lines.append("# Timeline")
            lines.append("")
            lines.append(data["timeline"])
            lines.append("")

        # Add recommendations if present
        if "recommendations" in data and data["recommendations"]:
            lines.append("# Recommendations")
            lines.append("")
            lines.append(data["recommendations"])
            lines.append("")

        return "\n".join(lines)

    def _build_diagnosis_markdown_with_evidence(
        self, diagnosis: dict, problem_num: str
    ) -> str:
        """
        Build detailed diagnosis markdown with evidence chain merged.

        Args:
            diagnosis: Diagnosis data dictionary
            problem_num: Problem number (e.g., "P1")

        Returns:
            Markdown content string
        """
        lines = []

        # Title
        if "title" in diagnosis:
            lines.append(f"# {diagnosis['title']}")
            lines.append("")

        # Conclusion
        if "conclusion" in diagnosis:
            lines.append("## Conclusion")
            lines.append(diagnosis["conclusion"])
            lines.append("")

        # Confidence info
        if any(
            key in diagnosis
            for key in [
                "confidence",
                "confidence_score",
                "root_cause_level",
                "root_cause_score",
            ]
        ):
            lines.append("## Diagnosis Metrics")
            if "confidence" in diagnosis:
                lines.append(f"**Confidence:** {diagnosis['confidence']}")
            if "confidence_score" in diagnosis:
                lines.append(f"**Confidence Score:** {diagnosis['confidence_score']}")
            if "root_cause_level" in diagnosis:
                lines.append(f"**Root Cause Level:** {diagnosis['root_cause_level']}")
            if "root_cause_score" in diagnosis:
                lines.append(f"**Root Cause Score:** {diagnosis['root_cause_score']}")
            lines.append("")

        # Reproduction path
        if "reproduction_path" in diagnosis:
            lines.append("## Reproduction Path")
            lines.append(diagnosis["reproduction_path"])
            lines.append("")

        # Timeline (diagnosis-level)
        if "timeline" in diagnosis:
            lines.append("## Timeline")
            lines.append(diagnosis["timeline"])
            lines.append("")

        # Evidence Chain (merged into diagnosis file)
        if "evidence_chain" in diagnosis and diagnosis["evidence_chain"]:
            lines.append("## Evidence Chain")
            lines.append(diagnosis["evidence_chain"])
            lines.append("")

        # Alternative causes
        if "alternative_causes" in diagnosis and diagnosis["alternative_causes"]:
            lines.append("## Alternative Causes Analyzed")
            lines.append("")
            for cause in diagnosis["alternative_causes"]:
                lines.append(f"### {cause.get('hypothesis', 'Unknown Hypothesis')}")
                lines.append("")
                if "confidence" in cause:
                    lines.append(f"**Confidence:** {cause['confidence']}")
                if "confidence_score" in cause:
                    lines.append(f"**Confidence Score:** {cause['confidence_score']}")
                if "root_cause_level" in cause:
                    lines.append(f"**Root Cause Level:** {cause['root_cause_level']}")
                if "exclusion_reason" in cause:
                    lines.append(f"**Exclusion Reason:** {cause['exclusion_reason']}")
                lines.append("")

        return "\n".join(lines)

    def _prepare_html_data(self, data: dict) -> dict:
        """
        Prepare data for HTML rendering.

        Args:
            data: Parsed report data dictionary

        Returns:
            Enhanced data dictionary with session information
        """
        # Convert UTC time to local time for display
        created_at = self.session.metadata.created_at
        if created_at.tzinfo is None:
            # If naive datetime, assume it's UTC
            created_at = created_at.replace(tzinfo=timezone.utc)
        # Convert to local time
        local_time = created_at.astimezone().strftime("%Y-%m-%d %H:%M:%S")

        html_data = {
            "session_id": self.session.session_id,
            "created_at": local_time,
            "status": self.session.metadata.status.value,
            "summary": data.get("summary", ""),
            "timeline": data.get("timeline", ""),
            "diagnosis": [],
            "cross_analysis": data.get("cross_analysis", ""),
            "recommendations": data.get("recommendations", ""),
            "metadata": data.get("metadata", {}),
        }

        # Process diagnosis list
        for idx, diagnosis in enumerate(data.get("diagnosis", [])):
            problem_num = self._extract_problem_number(
                diagnosis.get("title", f"P{idx + 1}")
            )
            html_data["diagnosis"].append(
                {
                    "id": problem_num,
                    "title": diagnosis.get("title", ""),
                    "conclusion": diagnosis.get("conclusion", ""),
                    "confidence": diagnosis.get("confidence", ""),
                    "confidence_score": diagnosis.get("confidence_score", 0),
                    "root_cause_level": diagnosis.get("root_cause_level", ""),
                    "root_cause_score": diagnosis.get("root_cause_score", 0),
                    "reproduction_path": diagnosis.get("reproduction_path", ""),
                    "timeline": diagnosis.get("timeline", ""),
                    "evidence_chain": diagnosis.get("evidence_chain", ""),
                    "alternative_causes": diagnosis.get("alternative_causes", []),
                }
            )

        return html_data

    def _generate_html_report(self, data: dict) -> str:
        """
        Generate HTML report content.

        Args:
            data: Parsed report data dictionary

        Returns:
            HTML content string (self-contained)
        """
        # Prepare data
        html_data = self._prepare_html_data(data)

        # Read HTML template
        template_path = (
            Path(__file__).parent.parent / "templates" / "report_template.html"
        )

        if not template_path.exists():
            logger.warning(f"HTML template not found at {template_path}")
            return ""

        template_content = template_path.read_text(encoding="utf-8")

        # Inject session information
        template_content = template_content.replace(
            "{{session_id}}", html_data["session_id"]
        )
        template_content = template_content.replace("{{date}}", html_data["created_at"])

        # Inject report data (JSON format)
        report_json = json.dumps(html_data, ensure_ascii=False, indent=2)
        template_content = template_content.replace("{{report_data_json}}", report_json)

        return template_content
