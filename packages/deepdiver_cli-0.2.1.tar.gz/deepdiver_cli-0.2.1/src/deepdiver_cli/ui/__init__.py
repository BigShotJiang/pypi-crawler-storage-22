"""UI渲染模块

提供基于 Rich 的终端 UI 渲染功能，通过事件订阅与 Agent/LLM 解耦。
"""

from .console import get_console
from .renderer import UIRenderer

__all__ = ["get_console", "UIRenderer"]
