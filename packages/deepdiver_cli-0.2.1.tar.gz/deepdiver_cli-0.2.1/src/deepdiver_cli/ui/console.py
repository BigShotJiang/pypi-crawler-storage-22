"""Rich Console 初始化和配置

提供统一的主题和 Console 实例。
"""

from rich.console import Console
from rich.theme import Theme

# 自定义主题
DEEPDIVER_THEME = Theme(
    {
        "progress": "cyan",
        "progress.remaining": "dim",
        "thinking": "yellow",
        "key_finding": "bold yellow",
        "tool_summary": "cyan",
        "verbose": "dim",
        "success": "green",
        "error": "red",
        "info": "blue",
    }
)


def get_console(force_terminal: bool | None = None) -> Console:
    """获取配置好的 Rich Console 实例

    Args:
        force_terminal: 是否强制终端模式（None 表示自动检测）

    Returns:
        配置了自定义主题的 Console 实例
    """
    return Console(theme=DEEPDIVER_THEME, force_terminal=force_terminal)
