"""键盘监听器

支持运行时切换详细程度模式。
"""

import sys
import threading
import time


class InputListener:
    """键盘监听器 - 运行时切换详细程度

    监听键盘输入，允许用户在运行时切换 UI 渲染模式。
    当前支持按 'v' 键切换简洁/详细模式。

    注意：
        - 使用 pynput 库（跨平台，macOS 友好）
        - 在 CI/CD 或非交互环境中会自动禁用
    """

    def __init__(self, renderer: "UIRenderer"):
        """初始化键盘监听器

        Args:
            renderer: UIRenderer 实例，用于切换详细模式
        """
        self.renderer = renderer
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._enabled = False

    def start(self):
        """启动后台监听线程

        如果当前不是交互环境（非 TTY），则不启动监听。
        """
        if not self._is_interactive():
            return

        try:
            self._enabled = True
            self._thread = threading.Thread(target=self._listen, daemon=True)
            self._thread.start()
        except Exception as e:
            # 启动失败（如权限问题）
            print(f"Warning: Could not start keyboard listener: {e}")
            print(f"💡 Tip: Use --verbose flag at startup instead")

    def _is_interactive(self) -> bool:
        """检查是否在交互式终端中运行

        Returns:
            True 如果在 TTY 环境中
        """
        return sys.stdin.isatty() and sys.stdout.isatty()

    def _listen(self):
        """监听 'v' 键（在后台线程中运行）"""
        try:
            from pynput import keyboard  # type: ignore

            def on_press(key):
                """键盘按下事件处理"""
                try:
                    # 检测 'v' 键
                    if key.char == 'v':
                        self.renderer.set_verbose(not self.renderer.verbose)
                        mode = "详细" if self.renderer.verbose else "简洁"
                        print(f"\n[Mode: {mode}]")
                except AttributeError:
                    pass  # 某些键没有 char 属性

            # 启动监听（非阻塞模式）
            listener = keyboard.Listener(on_press=on_press)
            listener.start()

            # 等待停止信号
            while not self._stop_event.is_set():
                time.sleep(0.1)

            # 停止监听
            listener.stop()
            listener.join()

        except Exception as e:
            # 监听过程中的错误不应该影响主程序
            print(f"Warning: Keyboard listener error: {e}")
            print(f"💡 Tip: Use --verbose flag at startup instead")

    def stop(self):
        """停止监听"""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=1.0)
            self._thread = None
        self._enabled = False

    @property
    def is_enabled(self) -> bool:
        """检查监听器是否已启用

        Returns:
            True 如果监听器正在运行
        """
        return self._enabled
