"""UI渲染器

订阅 Agent 事件并渲染到终端。
"""

from ast import arg
import json
from typing import Dict, List, Optional
from rich.console import Console
from rich.panel import Panel

from deepdiver_cli.utils.file_util import format_path_display

from ..events import (
    EventBus,
    AgentEventType,
)


class UIRenderer:
    """UI渲染器 - 订阅事件并渲染

    通过订阅 EventBus 的事件来渲染 Agent 执行过程，
    与 Agent/LLM 业务逻辑完全解耦。

    Attributes:
        console: Rich Console 实例
        verbose: 是否显示详细输出（思考过程、工具详细输出）
        show_progress: 是否显示进度信息
        thinking_buffer: 思考内容缓冲区
        current_step: 当前步骤
    """

    def __init__(
        self,
        console: Console,
        verbose: bool = False,
        show_progress: bool = True,
    ):
        """初始化UI渲染器

        Args:
            console: Rich Console 实例
            verbose: 是否显示详细输出（默认 False）
            show_progress: 是否显示进度信息（默认 True）
        """
        self.console = console
        self.verbose = verbose
        self.show_progress = show_progress
        self.thinking_buffer: list[str] = []
        self.current_step = 0
        self.max_steps = 0
        self._is_thinking = False  # 跟踪当前是否在思考中

    async def on_step_start(self, step: int, max_steps: int):
        """处理步骤开始事件

        Args:
            step: 当前步骤编号
            max_steps: 最大步骤数
        """
        self.current_step = step
        self.max_steps = max_steps
        self._is_thinking = False  # 新步骤开始，重置思考状态

        # if self.show_progress:
        # self._update_progress("Step Start")

    async def on_thinking_delta(self, content: str):
        """处理思考增量事件

        Args:
            content: 思考内容增量
        """
        if self.verbose:
            self.thinking_buffer.append(content)

        # 只在状态改变时更新进度（避免重复输出）
        if self.show_progress and not self._is_thinking:
            self._is_thinking = True
            self._update_progress("Thinking...")

    async def on_key_finding(self, finding: str):
        """处理关键发现事件（推送显示）

        Args:
            finding: 关键发现内容
        """
        # 使用简单的打印，确保在所有终端上都能显示
        # 使用 Rich 的 emoji 支持和样式
        self.console.print(f"[bold yellow]💡[/bold yellow] {finding}")

    async def on_tool_call(self, tool_name: str, arguments: str):
        """处理工具调用事件

        Args:
            tool_name: 工具名称
            arguments: 工具参数
        """
        # 工具调用开始，退出思考状态
        self._is_thinking = False
        if tool_name == "RecordKeyFinding":
            return

        args = ""
        try:
            dict_args = json.loads(arguments)

            # 根据工具类型提取关键参数
            if tool_name == "Grep":
                # Grep: paths, pattern, time_range(可选)
                parts = []
                if dict_args.get("paths"):
                    paths = ", ".join(
                        [format_path_display(p) for p in dict_args["paths"][:2]]
                    )  # 最多显示2个路径
                    if len(dict_args["paths"]) > 2:
                        paths += f" (+{len(dict_args['paths']) - 2} more)"
                    parts.append(paths)
                if dict_args.get("pattern"):
                    pattern = dict_args["pattern"]
                    if len(pattern) > 30:
                        pattern = pattern[:30] + "..."
                    parts.append(f'"{pattern}"')
                if dict_args.get("time_range"):
                    parts.append(dict_args["time_range"])
                args = ", ".join(parts)

            elif tool_name == "LoadKnowledge":
                # LoadKnowledge: knowledge_key
                args = dict_args.get("knowledge_key", "")

            elif tool_name == "Glob":
                # Glob: root_dir, patterns
                parts = []
                if dict_args.get("root_dir"):
                    parts.append(format_path_display(dict_args["root_dir"]))
                if dict_args.get("patterns"):
                    patterns = ", ".join(dict_args["patterns"][:2])
                    if len(dict_args["patterns"]) > 2:
                        patterns += "..."
                    parts.append(patterns)
                args = ", ".join(parts)

            elif tool_name == "ProcessFile":
                # ProcessFile: path
                if dict_args.get("path"):
                    args = format_path_display(dict_args["path"])

            elif tool_name == "Read":
                # Read: file_path
                if dict_args.get("file_path"):
                    args = format_path_display(dict_args["file_path"])

            elif tool_name == "Inspect":
                # Inspect: path, pattern(可选), time_range(可选)
                parts = []
                if dict_args.get("path"):
                    parts.append(format_path_display(dict_args["path"]))
                if dict_args.get("pattern"):
                    pattern = dict_args["pattern"]
                    if len(pattern) > 20:
                        pattern = pattern[:20] + "..."
                    parts.append(f'"{pattern}"')
                if dict_args.get("time_range"):
                    parts.append(dict_args["time_range"])
                args = ", ".join(parts)

            elif tool_name == "Review":
                # Review: conclusion (当前结论)
                if dict_args.get("conclusion"):
                    conclusion = dict_args["conclusion"]
                    if len(conclusion) > 50:
                        conclusion = conclusion[:50] + "..."
                    args = f'"{conclusion}"'

            elif tool_name == "AskHuman":
                # AskHuman: question
                if dict_args.get("question"):
                    question = dict_args["question"]
                    if len(question) > 50:
                        question = question[:50] + "..."
                    args = f'"{question}"'

            elif tool_name == "AnalyzeCode":
                # AnalyzeCode: code_path
                if dict_args.get("code_path"):
                    args = format_path_display(dict_args["code_path"])

            elif tool_name == "WriteReport":
                # WriteReport: 不显示参数（内容太长）
                args = "<report content>"

            elif tool_name == "KeyFinding":
                # KeyFinding: finding
                if dict_args.get("finding"):
                    finding = dict_args["finding"]
                    if len(finding) > 50:
                        finding = finding[:50] + "..."
                    args = f'"{finding}"'

            elif tool_name == "Finish":
                # Finish: status
                args = dict_args.get("status", "")

        except json.JSONDecodeError:
            pass

        if self.show_progress:
            self._update_progress(f"{tool_name}({args})")

    async def on_tool_result(
        self,
        tool_name: str,
        success: bool,
        summary: str,
        data=None,
        error=None,
        metadata: Optional[Dict] = None,
        suggestions: Optional[List[str]] = None,
    ):
        """处理工具结果事件

        Args:
            tool_name: 工具名称
            success: 是否成功
            summary: 结果摘要
            data: 结果数据
            error: 错误信息
            metadata: 元数据
            suggestions: 建议
        """

        summary = summary
        verbose_content = None  # 用于详细模式下的内容展示

        if tool_name == "RecordKeyFinding":
            return

        # 根据工具类型处理结果
        if tool_name == "Grep" and success:
            # Grep 工具：显示搜索结果内容
            if data and data.get("content"):
                verbose_content = data["content"]
            # 限制显示的搜索结果长度
            if verbose_content and len(verbose_content) > 1000:
                verbose_content = verbose_content[:1000] + f"\n... ({len(verbose_content) - 1000} more chars)"

        elif tool_name == "LoadKnowledge" and success:
            # LoadKnowledge 工具：显示知识库内容
            if data and data.get("content"):
                content_length = len(data.get("content", ""))
                summary = f"Knowledge Loaded ({content_length} chars) from '{data.get('knowledge_key', '')}'"
                verbose_content = data["content"]
                # 限制显示长度
                if len(verbose_content) > 1000:
                    verbose_content = verbose_content[:1000] + f"\n... ({len(verbose_content) - 1000} more chars)"

        elif tool_name == "ProcessFile" and success:
            # ProcessFile 工具：显示处理结果
            if data:
                processed_path = data if isinstance(data, str) else str(data)
                summary = f"File processed: {format_path_display(processed_path)}"
                verbose_content = f"Original file processed and saved to:\n{processed_path}"

        elif tool_name == "Read" and success:
            # Read 工具：显示读取内容
            if data:
                line_count = data.get("line_count", 0)
                file_size = data.get("file_size", "")
                result = data.get("result", "")
                offset = metadata.get("offset", 0) if metadata else 0
                limit = metadata.get("limit", 100) if metadata else 100
                file_path = metadata.get("file_path", "") if metadata else ""

                summary = f"Read {line_count} lines ({file_size})"
                if file_path:
                    summary += f" from {format_path_display(file_path)}"

                verbose_content = result
                # 限制显示长度
                if verbose_content and len(verbose_content) > 500:
                    verbose_content = verbose_content[:500] + f"\n... ({len(verbose_content) - 500} more chars)"

        elif tool_name == "Glob" and success:
            # Glob 工具：显示找到的路径
            MAX_DISPLAY = 5
            paths = data["paths"] if data else []
            paths_display = ""
            if len(paths) > MAX_DISPLAY:
                display_paths = list(paths)[:MAX_DISPLAY]
                paths_display = "\n".join(display_paths)
                paths_display += f"\n... (and {len(paths) - MAX_DISPLAY} more)"
            else:
                paths_display = "\n".join(paths)
            summary = f"Found {len(paths)} path(s):\n  {paths_display}"

        elif tool_name == "WriteReport" and success:
            # WriteReport 工具：显示生成的报告文件
            written_files = data["written_files"] if data else []
            file_list = "\n".join(f"  - {f}" for f in written_files)
            summary = f"Generated report files:  \n{file_list}"
            diagnosis_count = data.get("diagnosis_count", 0) if data else 0
            if diagnosis_count > 0:
                summary += f"\n  Diagnoses: {diagnosis_count}"

        elif tool_name == "Inspect" and success:
            # Inspect 工具：显示日志检查结果
            if data and data.get("result"):
                inspect_result = data["result"]
                verbose_content = inspect_result
                # 限制显示长度
                if verbose_content and len(verbose_content) > 1000:
                    verbose_content = verbose_content[:1000] + f"\n... ({len(verbose_content) - 1000} more chars)"

        elif tool_name == "Review" and success:
            # Review 工具：显示专家评审结果
            # 从 metadata 中提取 header 和 conclusion，添加到 summary（非 verbose 模式显示）
            if metadata:
                header = metadata.get("header", "")
                conclusion = metadata.get("conclusion", "")
                if header or conclusion:
                    # 覆盖 summary，显示 header 和 conclusion
                    summary = f"{header}\n{conclusion}".strip()

            # verbose 模式显示完整结果
            if data and data.get("result"):
                verbose_content = data.get("result")
                # 限制显示长度
                if verbose_content and len(verbose_content) > 1000:
                    verbose_content = verbose_content[:1000] + f"\n... ({len(verbose_content) - 1000} more chars)"

        elif tool_name == "AskHuman" and success:
            # AskHuman 工具：显示用户回复
            if data and data.get("response"):
                user_response = data["response"]
                summary = f"User replied: {user_response[:100]}{'...' if len(user_response) > 100 else ''}"
                verbose_content = f"User response:\n{user_response}"

        elif tool_name == "AnalyzeCode" and success:
            # AnalyzeCode 工具：显示代码分析结果
            if data:
                conclusion = data.get("conclusion", "")
                summary = "Code analysis completed"
                if conclusion:
                    summary += f": {conclusion[:100]}{'...' if len(conclusion) > 100 else ''}"
                if data.get("result"):
                    verbose_content = data["result"]
                    # 限制显示长度
                    if verbose_content and len(verbose_content) > 1000:
                        verbose_content = verbose_content[:1000] + f"\n... ({len(verbose_content) - 1000} more chars)"

        self.console.print(f"[tool_summary]⎿ [/tool_summary]{summary}")

        # 详细模式下显示完整内容
        if self.verbose and verbose_content:
            panel = Panel(
                verbose_content,
                title=f"[bold]{tool_name} 输出[/bold]",
                border_style="dim",
                padding=(0, 1),
            )
            self.console.print(panel)

    def subscribe(self, event_bus: EventBus):
        """订阅所有相关事件

        Args:
            event_bus: 事件总线实例
        """
        event_bus.subscribe(AgentEventType.STEP_START, self.on_step_start)
        event_bus.subscribe(AgentEventType.THINKING_DELTA, self.on_thinking_delta)
        event_bus.subscribe(AgentEventType.KEY_FINDING, self.on_key_finding)
        event_bus.subscribe(AgentEventType.TOOL_CALL, self.on_tool_call)
        event_bus.subscribe(AgentEventType.TOOL_RESULT, self.on_tool_result)

    def _update_progress(self, operation: str):
        """更新进度显示

        Args:
            operation: 当前操作描述
        """
        if not self.show_progress:
            return

        # 简洁的进度显示
        self.console.print(
            f"[dim]Step {self.current_step}[/dim]: [progress]{operation}[/progress]"
        )

    def set_verbose(self, verbose: bool):
        """设置详细模式

        Args:
            verbose: 是否启用详细模式
        """
        self.verbose = verbose
