from pathlib import Path
from typing import Set, Union


def read_text(path: Path) -> str:
    """
    read text content from the path
    """
    if path.exists():
        return path.read_text(encoding="utf-8")
    raise ValueError(f"File not exists: {str(path)}")


def is_within_dirs(p: str, dirs: Set[str]) -> bool:
    try:
        rp = Path(p).expanduser().resolve()
        for dir in dirs:
            if rp.is_relative_to(Path(dir).expanduser().resolve()):
                return True
        return False
    except Exception:
        return False


def format_path_display(path: Union[str, Path], max_length: int = 50) -> str:
    """格式化路径用于显示

    优先显示完整路径，如果路径太长则缩短为只显示最后两级目录。

    Args:
        path: 要格式化的路径（可以是 str 或 Path 对象）
        max_length: 最大显示长度，默认50字符

    Returns:
        格式化后的路径字符串

    Examples:
        >>> format_path_display("/Users/steve/Projects/app/src/main.py")
        "/Users/steve/Projects/app/src/main.py"

        >>> format_path_display("/very/long/path/that/exceeds/50/characters/app/src/main.py")
        ".../src/main.py"
    """
    path_str = str(path)

    # 如果路径较短，直接返回完整路径
    if len(path_str) <= max_length:
        return path_str

    # 路径太长，只显示最后两级目录
    path_obj = Path(path_str)

    # 如果有父目录名，显示 "父目录/文件名"
    if path_obj.parent.name:
        return f".../{path_obj.parent.name}/{path_obj.name}"

    # 如果没有父目录（只有文件名），直接返回文件名
    return f".../{path_obj.name}"
