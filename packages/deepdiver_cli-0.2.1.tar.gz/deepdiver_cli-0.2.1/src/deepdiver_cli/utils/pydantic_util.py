from typing import Any, Dict

from openai import pydantic_function_tool

from deepdiver_cli.config import LLMConfig

models_need_simple_parameters = {"qwen3-max-thinking","qwen3-max-2026-01-23"}


def pydantic_function_parameters(cls, llm_config: LLMConfig) -> Dict[str, Any]:
    """根据 pydantic model 生成 LLM tool 的 parameters 声明。"""
    parameters = _get_fun_parameters(cls)
    if llm_config.model in models_need_simple_parameters:
        return _simple_pydantic_function_parameters(parameters)
    return parameters


def _simple_pydantic_function_parameters(parameters) -> Dict[str, Any]:
    """获取简化的 parameters 声明。"""
    simplified = _simplify_anyof_for_llm(parameters)

    return {
        "type": "object",
        "properties": simplified["properties"],
        "required": simplified["required"],
    }


def _get_fun_parameters(cls) -> Dict[str, Any]:
    return pydantic_function_tool(cls)["function"]["parameters"]  # type: ignore


def _simplify_anyof_for_llm(schema: Dict[str, Any]) -> Dict[str, Any]:
    """
    简化 JSON schema 中的 anyOf 结构，提高 LLM 兼容性。
    只保留 description、type、items（数组类型）三个字段。
    """
    properties = schema.get("properties", {}).copy()
    required = schema.get("required", []).copy()

    for field_name, field_schema in properties.items():
        # 只保留 description（如果存在）
        simplified = {}
        if "description" in field_schema:
            simplified["description"] = field_schema["description"]

        if "anyOf" in field_schema:
            # 提取非 null 的类型定义
            non_null_types = [
                t for t in field_schema["anyOf"] if t.get("type") != "null"
            ]
        else:
            non_null_types = []

        # 是Optional字段，且只有一个非 null 类型，则简化
        if len(non_null_types) == 1:
            type_def = non_null_types[0]
            simplified["type"] = type_def.get("type")

            # 如果是数组类型，保留 items
            if type_def.get("type") == "array" and "items" in type_def:
                simplified["items"] = type_def["items"]

            properties[field_name] = simplified

        # 不是Optional字段
        if "anyOf" not in field_schema:
            type_def = field_schema
            simplified["type"] = type_def.get("type")

            # 如果是数组类型，保留 items
            if type_def.get("type") == "array" and "items" in type_def:
                simplified["items"] = type_def["items"]
            properties[field_name] = simplified
    return {"properties": properties, "required": required}
