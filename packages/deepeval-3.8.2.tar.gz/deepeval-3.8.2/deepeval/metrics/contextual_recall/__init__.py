from .template import ContextualRecallTemplate
