"""Main entry point for deepfabric CLI."""

from deepfabric.cli import cli

if __name__ == "__main__":
    cli()
