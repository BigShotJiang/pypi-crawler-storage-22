"""
DeepLatent - High-performance Arabic-first tokenizer

A proprietary tokenizer with morphology awareness, designed for Arabic
and other Semitic languages. Combines Rust performance with Python ease of use.

Example:
    >>> from deeplatent import SARFTokenizer
    >>> tok = SARFTokenizer.from_pretrained("SARF-65k-v2-fixed")
    >>> ids = tok.encode("مرحبا بالعالم")
    >>> text = tok.decode(ids)

    # Add special tokens
    >>> tok.add(["<user>", "<assistant>"])
"""

from .sarf_tokenizer import SARFTokenizer, AddedToken
from .tokenizer import SuhailTokenizer
from .config import NormalizationConfig

# Try to import Rust bindings (internal classes not exported for IP protection)
try:
    from ._deeplatent import (
        # Internal - not exported
        SuhailTokenizer as _RustTokenizer,
        NormalizationConfig as _RustNormConfig,
        # Utility functions (safe to export)
        normalize,
        is_arabic,
        is_pua,
        decode_bytes,
        encrypt_morf_map,  # Legacy .enc format
        encrypt_morf_map_binary,  # New .bin format (recommended)
        is_binary_morf_map,  # Check if file is binary format
        convert_enc_to_bin,  # Convert .enc to .bin
        version,
        get_machine_id,
        __version__,
    )
    RUST_AVAILABLE = True
except ImportError:
    # Rust bindings not built yet
    RUST_AVAILABLE = False
    __version__ = "0.1.0"
    _RustTokenizer = None
    _RustNormConfig = None
    normalize = None
    is_arabic = None
    is_pua = None
    decode_bytes = None
    encrypt_morf_map = None
    encrypt_morf_map_binary = None
    is_binary_morf_map = None
    convert_enc_to_bin = None

    def version():
        return __version__

    def get_machine_id():
        raise NotImplementedError("Rust bindings not built. Run: maturin develop")

# Try to import HuggingFace wrapper (requires transformers)
try:
    from .hf_tokenizer import SuhailTokenizerFast
    HAS_HF_TOKENIZER = True
except ImportError:
    HAS_HF_TOKENIZER = False
    SuhailTokenizerFast = None

__all__ = [
    # Primary exports
    "SARFTokenizer",
    "AddedToken",
    # Legacy classes
    "SuhailTokenizer",
    "NormalizationConfig",
    "SuhailTokenizerFast",
    # Utility functions
    "normalize",
    "is_arabic",
    "is_pua",
    "decode_bytes",
    # Encryption functions
    "encrypt_morf_map",  # Legacy .enc format
    "encrypt_morf_map_binary",  # New .bin format (recommended)
    "is_binary_morf_map",  # Check file format
    "convert_enc_to_bin",  # Convert .enc to .bin
    "version",
    "get_machine_id",
    # Version info
    "__version__",
    "RUST_AVAILABLE",
    "HAS_HF_TOKENIZER",
]
