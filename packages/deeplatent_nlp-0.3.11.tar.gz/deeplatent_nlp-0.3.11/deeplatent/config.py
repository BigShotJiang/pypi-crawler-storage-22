"""
Configuration classes for DeepLatent tokenizer.

Extended with edge-case hardening options for:
- Unicode NFC/NFKC normalization
- Zero-width character handling
- Unicode whitespace normalization
- Grapheme cluster preservation
- Apostrophe/dash normalization
- URL/email/path protection
- Control character handling
- Input validation
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Literal


class UnicodeNormalizationForm(str, Enum):
    """Unicode normalization form."""
    NONE = "none"
    NFC = "nfc"
    NFKC = "nfkc"


class WhitespaceNormalization(str, Enum):
    """Whitespace normalization strategy."""
    NONE = "none"
    COLLAPSE = "collapse"
    UNICODE = "unicode"


class ControlCharStrategy(str, Enum):
    """Control character handling strategy."""
    PRESERVE = "preserve"
    REMOVE = "remove"
    REPLACE = "replace"


class ZeroWidthStrategy(str, Enum):
    """Zero-width character handling strategy."""
    REMOVE_ALL = "remove_all"
    PRESERVE_ZWJ = "preserve_zwj"
    PRESERVE_ALL = "preserve_all"


@dataclass
class NormalizationConfig:
    """
    Configuration for Arabic text normalization.

    Attributes:
        # Arabic-specific normalization
        normalize_alef: Normalize alef variants (أ, إ, آ) to bare alef (ا).
        normalize_taa_marbouta: Normalize taa marbouta (ة) to haa (ه).
        normalize_alef_maqsura: Normalize alef maqsura (ى) to yaa (ي).
        strip_diacritics: Remove all diacritics (harakat).
        remove_tatweel: Remove tatweel/kashida character (ـ).
        normalize_digits: Convert Arabic-Indic digits (٠-٩) to Western (0-9).

        # Edge-case hardening (new)
        unicode_normalize: Unicode normalization form (NFC/NFKC).
        whitespace_normalize: Whitespace normalization strategy.
        zero_width_strategy: How to handle zero-width characters.
        preserve_grapheme_clusters: Preserve emoji sequences, flags, skin tones.
        normalize_apostrophes: Normalize curly apostrophes to ASCII.
        normalize_dashes: Normalize en-dash, em-dash, minus to hyphen.
        preserve_urls: Preserve URLs during normalization.
        preserve_emails: Preserve email addresses during normalization.
        preserve_file_paths: Preserve file paths during normalization.
        handle_control_chars: How to handle control characters.
        max_input_length: Maximum input length (None = unlimited).
        normalize_decimal_separators: Normalize locale-specific decimal separators.
    """

    # Arabic-specific normalization (existing)
    normalize_alef: bool = False
    normalize_taa_marbouta: bool = False
    normalize_alef_maqsura: bool = False
    strip_diacritics: bool = False
    remove_tatweel: bool = True
    normalize_digits: bool = False

    # Edge-case hardening (new)
    unicode_normalize: UnicodeNormalizationForm = UnicodeNormalizationForm.NONE
    whitespace_normalize: WhitespaceNormalization = WhitespaceNormalization.NONE
    zero_width_strategy: ZeroWidthStrategy = ZeroWidthStrategy.REMOVE_ALL
    preserve_grapheme_clusters: bool = False
    normalize_apostrophes: bool = False
    normalize_dashes: bool = False
    preserve_urls: bool = False
    preserve_emails: bool = False
    preserve_file_paths: bool = False
    handle_control_chars: ControlCharStrategy = ControlCharStrategy.REMOVE
    max_input_length: Optional[int] = None
    normalize_decimal_separators: bool = False

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            # Arabic-specific
            "normalize_alef": self.normalize_alef,
            "normalize_taa_marbouta": self.normalize_taa_marbouta,
            "normalize_alef_maqsura": self.normalize_alef_maqsura,
            "strip_diacritics": self.strip_diacritics,
            "remove_tatweel": self.remove_tatweel,
            "normalize_digits": self.normalize_digits,
            # Edge-case hardening
            "unicode_normalize": self.unicode_normalize.value,
            "whitespace_normalize": self.whitespace_normalize.value,
            "zero_width_strategy": self.zero_width_strategy.value,
            "preserve_grapheme_clusters": self.preserve_grapheme_clusters,
            "normalize_apostrophes": self.normalize_apostrophes,
            "normalize_dashes": self.normalize_dashes,
            "preserve_urls": self.preserve_urls,
            "preserve_emails": self.preserve_emails,
            "preserve_file_paths": self.preserve_file_paths,
            "handle_control_chars": self.handle_control_chars.value,
            "max_input_length": self.max_input_length,
            "normalize_decimal_separators": self.normalize_decimal_separators,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "NormalizationConfig":
        """Create from dictionary."""
        # Handle enum conversions
        if "unicode_normalize" in d and isinstance(d["unicode_normalize"], str):
            d = d.copy()
            d["unicode_normalize"] = UnicodeNormalizationForm(d["unicode_normalize"])
        if "whitespace_normalize" in d and isinstance(d["whitespace_normalize"], str):
            d = d.copy()
            d["whitespace_normalize"] = WhitespaceNormalization(d["whitespace_normalize"])
        if "zero_width_strategy" in d and isinstance(d["zero_width_strategy"], str):
            d = d.copy()
            d["zero_width_strategy"] = ZeroWidthStrategy(d["zero_width_strategy"])
        if "handle_control_chars" in d and isinstance(d["handle_control_chars"], str):
            d = d.copy()
            d["handle_control_chars"] = ControlCharStrategy(d["handle_control_chars"])

        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    @classmethod
    def nfc_only(cls) -> "NormalizationConfig":
        """Create a config that only applies NFC normalization."""
        return cls(
            unicode_normalize=UnicodeNormalizationForm.NFC,
            remove_tatweel=False,
        )

    @classmethod
    def for_training(cls) -> "NormalizationConfig":
        """Create a config suitable for tokenizer training."""
        return cls(
            normalize_alef=True,
            normalize_alef_maqsura=True,
            strip_diacritics=True,
            remove_tatweel=True,
            normalize_digits=True,
            unicode_normalize=UnicodeNormalizationForm.NFC,
            whitespace_normalize=WhitespaceNormalization.COLLAPSE,
            zero_width_strategy=ZeroWidthStrategy.REMOVE_ALL,
            handle_control_chars=ControlCharStrategy.REMOVE,
        )

    @classmethod
    def preserve_all(cls) -> "NormalizationConfig":
        """Create a config that preserves as much as possible."""
        return cls(
            normalize_alef=False,
            normalize_taa_marbouta=False,
            normalize_alef_maqsura=False,
            strip_diacritics=False,
            remove_tatweel=False,
            normalize_digits=False,
            unicode_normalize=UnicodeNormalizationForm.NONE,
            whitespace_normalize=WhitespaceNormalization.NONE,
            zero_width_strategy=ZeroWidthStrategy.PRESERVE_ALL,
            preserve_grapheme_clusters=True,
            preserve_urls=True,
            preserve_emails=True,
            preserve_file_paths=True,
            handle_control_chars=ControlCharStrategy.PRESERVE,
        )

    @classmethod
    def robust(cls) -> "NormalizationConfig":
        """Create a robust config with pattern protection."""
        return cls(
            remove_tatweel=True,
            unicode_normalize=UnicodeNormalizationForm.NFC,
            whitespace_normalize=WhitespaceNormalization.COLLAPSE,
            zero_width_strategy=ZeroWidthStrategy.PRESERVE_ZWJ,
            preserve_grapheme_clusters=True,
            normalize_apostrophes=True,
            normalize_dashes=True,
            preserve_urls=True,
            preserve_emails=True,
            preserve_file_paths=True,
            handle_control_chars=ControlCharStrategy.REMOVE,
            max_input_length=1_000_000,
        )


@dataclass
class TokenizerConfig:
    """
    Full tokenizer configuration.

    Attributes:
        vocab_size: Target vocabulary size.
        model_type: Type of tokenizer model ("bpe", "myte").
        normalization: Normalization configuration.
        special_tokens: Special token definitions.
    """

    vocab_size: int = 65536
    model_type: str = "myte"
    normalization: NormalizationConfig = field(default_factory=NormalizationConfig)
    special_tokens: dict = field(
        default_factory=lambda: {
            "pad_token": "<pad>",
            "unk_token": "<unk>",
            "bos_token": "<s>",
            "eos_token": "</s>",
        }
    )

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "vocab_size": self.vocab_size,
            "model_type": self.model_type,
            "normalization": self.normalization.to_dict(),
            "special_tokens": self.special_tokens,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "TokenizerConfig":
        """Create from dictionary."""
        norm_dict = d.pop("normalization", {})
        normalization = NormalizationConfig.from_dict(norm_dict)
        return cls(normalization=normalization, **d)


@dataclass
class LicenseConfig:
    """
    License configuration.

    Attributes:
        key: License key string.
        tier: License tier (free, standard, pro, enterprise).
        offline_mode: Whether to allow offline usage.
    """

    key: Optional[str] = None
    tier: str = "free"
    offline_mode: bool = False

    def is_valid(self) -> bool:
        """Check if license is valid."""
        if self.tier == "free":
            return True
        return self.key is not None and self.key.startswith("SUHAIL-")
