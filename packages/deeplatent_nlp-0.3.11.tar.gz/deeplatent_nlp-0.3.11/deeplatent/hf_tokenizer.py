"""
HuggingFace-compatible wrapper for SARF tokenizer.

This module provides SuhailTokenizerFast, a wrapper that integrates the
SARF tokenizer with HuggingFace's transformers library for seamless
use with Trainer and other HF components.

Example:
    >>> from deeplatent import SuhailTokenizerFast
    >>> tok = SuhailTokenizerFast.from_pretrained("/path/to/tokenizer")
    >>> encoded = tok(["مرحبا بالعالم"], padding=True, return_tensors="pt")
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import List, Optional, Union

try:
    from transformers import PreTrainedTokenizerFast
    HAS_TRANSFORMERS = True
except ImportError:
    HAS_TRANSFORMERS = False
    PreTrainedTokenizerFast = object  # Placeholder for type hints

# Import SarfCodec (internal use only - not exported)
try:
    from ._deeplatent import SarfCodec as _SarfCodec
    _HAS_SARF = True
except ImportError:
    _HAS_SARF = False
    _SarfCodec = None


class SuhailTokenizerFast(PreTrainedTokenizerFast if HAS_TRANSFORMERS else object):
    """
    HuggingFace-compatible wrapper for SARF tokenizer.

    This class wraps a HuggingFace tokenizers.Tokenizer (tokenizer.json) and
    adds internal preprocessing before BPE tokenization.

    Example:
        >>> tok = SuhailTokenizerFast.from_pretrained(
        ...     "/root/.cache/DeepLatent/SARFTokenizer/SARF-65k-v2-fixed"
        ... )
        >>> encoded = tok(["مرحبا", "Hello"], padding=True, return_tensors="pt")
        >>> print(encoded["input_ids"].shape)
    """

    # Class attributes for HF compatibility
    model_input_names = ["input_ids", "attention_mask"]

    def __init__(
        self,
        tokenizer_file: Optional[str] = None,
        morf_map_path: Optional[str] = None,
        num_threads: int = 8,
        bos_token: str = "<|endoftext|>",
        eos_token: str = "<|endoftext|>",
        unk_token: str = "<|endoftext|>",
        pad_token: str = "<|padding|>",
        **kwargs,
    ):
        """
        Initialize the tokenizer.

        Args:
            tokenizer_file: Path to tokenizer.json file
            morf_map_path: Path to encrypted morf_map.enc file
            num_threads: Number of threads for parallel batch processing
            bos_token: Beginning of sequence token
            eos_token: End of sequence token
            unk_token: Unknown token
            pad_token: Padding token
            **kwargs: Additional arguments passed to PreTrainedTokenizerFast

        Raises:
            ValueError: If morf_map_path is not an encrypted .enc file
        """
        if not HAS_TRANSFORMERS:
            raise ImportError(
                "transformers is required for SuhailTokenizerFast. "
                "Install with: pip install transformers"
            )

        if not _HAS_SARF:
            raise ImportError(
                "Rust bindings not available. "
                "Build with: maturin develop --release"
            )

        # Initialize parent class
        super().__init__(
            tokenizer_file=tokenizer_file,
            bos_token=bos_token,
            eos_token=eos_token,
            unk_token=unk_token,
            pad_token=pad_token,
            **kwargs,
        )

        self._num_threads = num_threads
        self.__morf_map_path = None

        # Load codec for preprocessing (encrypted only for IP protection)
        self.__codec = None
        if morf_map_path is not None:
            # Only allow encrypted files for IP protection (.bin or .enc)
            if not (morf_map_path.endswith('.enc') or morf_map_path.endswith('.bin')):
                raise ValueError(
                    "Only encrypted morf_map files (.bin or .enc) are supported. "
                    "Use encrypt_morf_map_binary() to create a .bin file."
                )
            # from_encrypted auto-detects format based on magic bytes
            self.__codec = _SarfCodec.from_encrypted(morf_map_path)
            self.__morf_map_path = morf_map_path

    def __preprocess_text(self, text: str) -> str:
        """Apply internal preprocessing."""
        if self.__codec is not None:
            return self.__codec.encode(text)
        return text

    def __preprocess_batch(self, texts: List[str]) -> List[str]:
        """Apply internal preprocessing to batch."""
        if self.__codec is not None:
            return self.__codec.encode_batch(texts, num_threads=self._num_threads)
        return texts

    def encode(
        self,
        text: str,
        text_pair: Optional[str] = None,
        add_special_tokens: bool = True,
        **kwargs,
    ) -> List[int]:
        """
        Encode text to token IDs.

        Args:
            text: Text to encode
            text_pair: Optional second text for sequence pairs
            add_special_tokens: Whether to add special tokens
            **kwargs: Additional arguments

        Returns:
            List of token IDs
        """
        preprocessed = self.__preprocess_text(text)
        preprocessed_pair = self.__preprocess_text(text_pair) if text_pair else None

        return super().encode(
            preprocessed,
            text_pair=preprocessed_pair,
            add_special_tokens=add_special_tokens,
            **kwargs,
        )

    def _batch_encode_plus(
        self,
        batch_text_or_text_pairs,
        add_special_tokens: bool = True,
        padding_strategy=None,
        truncation_strategy=None,
        max_length: Optional[int] = None,
        stride: int = 0,
        is_split_into_words: bool = False,
        pad_to_multiple_of: Optional[int] = None,
        return_tensors=None,
        return_token_type_ids: Optional[bool] = None,
        return_attention_mask: Optional[bool] = None,
        return_overflowing_tokens: bool = False,
        return_special_tokens_mask: bool = False,
        return_offsets_mapping: bool = False,
        return_length: bool = False,
        verbose: bool = True,
        **kwargs,
    ):
        """
        Internal batch encoding with preprocessing.
        """
        # Handle both plain texts and text pairs
        if isinstance(batch_text_or_text_pairs[0], tuple):
            # Text pairs: [(text1, pair1), (text2, pair2), ...]
            texts = [t[0] for t in batch_text_or_text_pairs]
            pairs = [t[1] for t in batch_text_or_text_pairs]
            preprocessed_texts = self.__preprocess_batch(texts)
            preprocessed_pairs = self.__preprocess_batch(pairs)
            preprocessed = list(zip(preprocessed_texts, preprocessed_pairs))
        else:
            # Plain texts: [text1, text2, ...]
            preprocessed = self.__preprocess_batch(list(batch_text_or_text_pairs))

        return super()._batch_encode_plus(
            preprocessed,
            add_special_tokens=add_special_tokens,
            padding_strategy=padding_strategy,
            truncation_strategy=truncation_strategy,
            max_length=max_length,
            stride=stride,
            is_split_into_words=is_split_into_words,
            pad_to_multiple_of=pad_to_multiple_of,
            return_tensors=return_tensors,
            return_token_type_ids=return_token_type_ids,
            return_attention_mask=return_attention_mask,
            return_overflowing_tokens=return_overflowing_tokens,
            return_special_tokens_mask=return_special_tokens_mask,
            return_offsets_mapping=return_offsets_mapping,
            return_length=return_length,
            verbose=verbose,
            **kwargs,
        )

    def _encode_plus(
        self,
        text,
        text_pair=None,
        add_special_tokens: bool = True,
        **kwargs,
    ):
        """
        Internal single encoding with preprocessing.
        """
        preprocessed = self.__preprocess_text(text)
        preprocessed_pair = self.__preprocess_text(text_pair) if text_pair else None

        return super()._encode_plus(
            preprocessed,
            text_pair=preprocessed_pair,
            add_special_tokens=add_special_tokens,
            **kwargs,
        )

    @classmethod
    def from_pretrained(
        cls,
        pretrained_model_name_or_path: Union[str, os.PathLike],
        *init_inputs,
        cache_dir: Optional[Union[str, os.PathLike]] = None,
        force_download: bool = False,
        local_files_only: bool = False,
        token: Optional[Union[str, bool]] = None,
        revision: str = "main",
        num_threads: int = 8,
        **kwargs,
    ) -> "SuhailTokenizerFast":
        """
        Load tokenizer from a local directory.

        Args:
            pretrained_model_name_or_path: Path to local directory
            cache_dir: Cache directory for downloads
            force_download: Force re-download
            local_files_only: Only use local files
            token: HuggingFace auth token
            revision: Model revision
            num_threads: Number of threads for batch processing
            **kwargs: Additional arguments

        Returns:
            Loaded SuhailTokenizerFast instance

        Example:
            >>> tok = SuhailTokenizerFast.from_pretrained(
            ...     "/root/.cache/DeepLatent/SARFTokenizer/SARF-65k-v2-fixed"
            ... )
        """
        path = Path(pretrained_model_name_or_path)

        # Find tokenizer.json
        tokenizer_file = path / "tokenizer.json"
        if not tokenizer_file.exists():
            raise FileNotFoundError(f"tokenizer.json not found in {path}")

        # Find morf_map (prefer .bin over .enc for better IP protection)
        morf_map_path = None
        bin_path = path / "morf_map.bin"
        enc_path = path / "morf_map.enc"
        if bin_path.exists():
            morf_map_path = str(bin_path)
        elif enc_path.exists():
            morf_map_path = str(enc_path)

        return cls(
            tokenizer_file=str(tokenizer_file),
            morf_map_path=morf_map_path,
            num_threads=num_threads,
            **kwargs,
        )

    def save_pretrained(
        self,
        save_directory: Union[str, os.PathLike],
        legacy_format: Optional[bool] = None,
        filename_prefix: Optional[str] = None,
        push_to_hub: bool = False,
        **kwargs,
    ):
        """
        Save tokenizer to directory.

        Args:
            save_directory: Directory to save to
            legacy_format: Whether to use legacy format
            filename_prefix: Prefix for filenames
            push_to_hub: Whether to push to HF Hub
            **kwargs: Additional arguments
        """
        save_dir = Path(save_directory)
        save_dir.mkdir(parents=True, exist_ok=True)

        # Save HuggingFace tokenizer files
        super().save_pretrained(
            save_directory,
            legacy_format=legacy_format,
            filename_prefix=filename_prefix,
            push_to_hub=push_to_hub,
            **kwargs,
        )

        # Copy encrypted morf_map (convert to .bin for better IP protection)
        if self.__morf_map_path is not None:
            src_path = Path(self.__morf_map_path)
            if src_path.exists():
                if self.__morf_map_path.endswith('.bin'):
                    # Already binary format, just copy
                    shutil.copy2(src_path, save_dir / "morf_map.bin")
                elif self.__morf_map_path.endswith('.enc'):
                    # Convert .enc to .bin for better IP protection
                    try:
                        from . import convert_enc_to_bin
                        convert_enc_to_bin(str(src_path), str(save_dir / "morf_map.bin"))
                    except Exception:
                        # Fallback: just copy the .enc file
                        shutil.copy2(src_path, save_dir / "morf_map.enc")

    @property
    def num_threads(self) -> int:
        """Get number of threads for batch processing."""
        return self._num_threads

    @num_threads.setter
    def num_threads(self, value: int):
        """Set number of threads for batch processing."""
        self._num_threads = value
