"""
SARF Tokenizer - Main tokenizer interface for DeepLatent.

This module provides the SARFTokenizer class, a clean API for Arabic-first
tokenization with built-in preprocessing.

Example:
    >>> from deeplatent import SARFTokenizer
    >>> tok = SARFTokenizer.from_pretrained("SARF-65k-v2-fixed")
    >>> ids = tok.encode("مرحبا بالعالم")
    >>> text = tok.decode(ids)
"""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Union, Any

# Try to import HuggingFace tokenizers
try:
    from tokenizers import Tokenizer as HFTokenizer
    HAS_TOKENIZERS = True
except ImportError:
    HAS_TOKENIZERS = False

# Try to import huggingface_hub for downloading
try:
    from huggingface_hub import snapshot_download
    HAS_HF_HUB = True
except ImportError:
    HAS_HF_HUB = False
    HFTokenizer = None

# Try to import Rust bindings (internal use only)
try:
    from ._deeplatent import SarfCodec as _SarfCodec
    _HAS_RUST = True
except ImportError:
    _HAS_RUST = False
    _SarfCodec = None


@dataclass
class AddedToken:
    """
    Represents a token added to the tokenizer vocabulary.

    Mirrors HuggingFace's AddedToken for compatibility.

    Attributes:
        content: The token string (e.g., "<user>")
        id: Assigned token ID (e.g., 64030)
        special: Whether this is a special token (not split by tokenizer)
        single_word: Whether the token should only match whole words
        lstrip: Strip whitespace on left before matching
        rstrip: Strip whitespace on right before matching
        normalized: Whether to apply normalization to this token

    Example:
        >>> token = AddedToken("<user>", id=64030, special=True)
        >>> token.content
        '<user>'
        >>> token.to_dict()
        {'content': '<user>', 'id': 64030, 'special': True, ...}
    """
    content: str
    id: Optional[int] = None
    special: bool = True
    single_word: bool = True
    lstrip: bool = False
    rstrip: bool = False
    normalized: bool = False

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "AddedToken":
        """Create from dictionary."""
        return cls(**data)

    def __repr__(self) -> str:
        return f"AddedToken({self.content!r}, id={self.id}, special={self.special})"


class SARFTokenizer:
    """
    Main tokenizer interface for DeepLatent.

    Provides encode/decode functionality with built-in Arabic text processing.

    Roundtrip guarantee:
        decode(encode(text)) should return normalized text.

    Example:
        >>> from deeplatent import SARFTokenizer
        >>> tok = SARFTokenizer.from_pretrained("SARF-65k-v2-fixed")
        >>> ids = tok.encode("مرحبا بالعالم")  # Returns List[int]
        >>> text = tok.decode(ids)
        >>> tok.add(["<user>", "<assistant>"])
        >>> tok.save("./my_tokenizer")
    """

    # Use name mangling to protect internal codec
    __slots__ = (
        '_SARFTokenizer__tokenizer',
        '_SARFTokenizer__codec',
        '_SARFTokenizer__vocab_size',
        '_SARFTokenizer__morf_map_path',
        '_added_tokens',
        '_next_id',
    )

    def __init__(
        self,
        tokenizer_path: str,
        morf_map_path: Optional[str] = None,
    ):
        """
        Load tokenizer from path.

        Args:
            tokenizer_path: Path to tokenizer.json file
            morf_map_path: Path to encrypted morf_map.enc file (required for Arabic)

        Raises:
            ValueError: If morf_map_path is not an encrypted .enc file
        """
        if not HAS_TOKENIZERS:
            raise ImportError(
                "tokenizers is required for SARFTokenizer. "
                "Install with: pip install tokenizers"
            )

        # Load HuggingFace tokenizer
        self.__tokenizer = HFTokenizer.from_file(tokenizer_path)
        self.__vocab_size = self.__tokenizer.get_vocab_size()

        # Load codec for preprocessing (encrypted only for IP protection)
        self.__codec = None
        self.__morf_map_path = None

        if morf_map_path is not None:
            if not _HAS_RUST:
                raise ImportError(
                    "Rust bindings not available. "
                    "Build with: maturin develop --release"
                )

            # Only allow encrypted files for IP protection (.bin or .enc)
            if not (morf_map_path.endswith('.enc') or morf_map_path.endswith('.bin')):
                raise ValueError(
                    "Only encrypted morf_map files (.bin or .enc) are supported. "
                    "Use encrypt_morf_map_binary() to create a .bin file."
                )

            # from_encrypted auto-detects format based on magic bytes
            self.__codec = _SarfCodec.from_encrypted(morf_map_path)
            self.__morf_map_path = morf_map_path

        # Track added tokens
        self._added_tokens: Dict[str, AddedToken] = {}
        self._next_id = self.__vocab_size

    @classmethod
    def from_pretrained(
        cls,
        name_or_path: str,
        cache_dir: Optional[str] = None,
    ) -> "SARFTokenizer":
        """
        Load from name or local path.

        Args:
            name_or_path: Local path to tokenizer directory
            cache_dir: Optional cache directory (for future HF Hub support)

        Returns:
            Loaded SARFTokenizer instance

        Example:
            >>> tok = SARFTokenizer.from_pretrained("./my_tokenizer")
            >>> tok = SARFTokenizer.from_pretrained("/path/to/SARF-65k-v2-fixed")
        """
        path = Path(name_or_path)

        if not path.exists():
            # Try standard cache locations
            cache_locations = [
                Path.home() / ".cache" / "DeepLatent" / "SARFTokenizer" / name_or_path,
                Path.home() / ".cache" / "deeplatent" / name_or_path,
            ]
            for cache_path in cache_locations:
                if cache_path.exists():
                    path = cache_path
                    break
            else:
                # Try downloading from HuggingFace Hub
                if HAS_HF_HUB:
                    hf_repo = f"almaghrabima/{name_or_path}"
                    download_dir = cache_locations[0]
                    try:
                        print(f"Downloading tokenizer from HuggingFace: {hf_repo}")
                        snapshot_download(
                            repo_id=hf_repo,
                            local_dir=str(download_dir),
                            allow_patterns=["tokenizer.json", "morf_map.bin",
                                            "morf_map.enc", "added_tokens.json",
                                            "special_tokens_map.json",
                                            "tokenizer_config.json"],
                        )
                        path = download_dir
                        print(f"Downloaded tokenizer to {download_dir}")
                    except Exception as e:
                        raise FileNotFoundError(
                            f"Tokenizer not found locally or on HuggingFace: {name_or_path}. "
                            f"Tried local: {[str(p) for p in cache_locations]}, "
                            f"HuggingFace: {hf_repo}. Error: {e}"
                        )
                else:
                    raise FileNotFoundError(
                        f"Tokenizer not found: {name_or_path}. "
                        f"Tried: {[str(p) for p in cache_locations]}. "
                        f"Install huggingface_hub to enable automatic download."
                    )

        # Find tokenizer.json
        tokenizer_file = path / "tokenizer.json"
        if not tokenizer_file.exists():
            raise FileNotFoundError(f"tokenizer.json not found in {path}")

        # Find morf_map (prefer .bin over .enc for better IP protection)
        morf_map_path = None
        bin_path = path / "morf_map.bin"
        enc_path = path / "morf_map.enc"
        if bin_path.exists():
            morf_map_path = str(bin_path)
        elif enc_path.exists():
            morf_map_path = str(enc_path)

        # Create instance
        instance = cls(
            tokenizer_path=str(tokenizer_file),
            morf_map_path=morf_map_path,
        )

        # Load added tokens if available
        added_tokens_file = path / "added_tokens.json"
        if added_tokens_file.exists():
            with open(added_tokens_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            for token_data in data.get("added_tokens", []):
                token = AddedToken.from_dict(token_data)
                instance._added_tokens[token.content] = token
            instance._next_id = data.get("next_id", instance.__vocab_size)

        return instance

    @property
    def vocab_size(self) -> int:
        """Total vocabulary size including added tokens."""
        return self.__vocab_size + len(self._added_tokens)

    def __preprocess(self, text: str) -> str:
        """Apply internal preprocessing."""
        if self.__codec is not None:
            return self.__codec.encode(text)
        return text

    def __postprocess(self, text: str) -> str:
        """Apply internal postprocessing."""
        if self.__codec is not None:
            return self.__codec.decode(text)
        return text

    def __preprocess_batch(self, texts: List[str]) -> List[str]:
        """Apply internal preprocessing to batch."""
        if self.__codec is not None:
            return self.__codec.encode_batch(texts)
        return texts

    def __postprocess_batch(self, texts: List[str]) -> List[str]:
        """Apply internal postprocessing to batch."""
        if self.__codec is not None:
            return self.__codec.decode_batch(texts)
        return texts

    def encode(
        self,
        text: str,
        add_special_tokens: bool = True,
    ) -> List[int]:
        """
        Encode text to token IDs.

        Args:
            text: Input text
            add_special_tokens: Whether to add BOS/EOS tokens

        Returns:
            List[int]: Token IDs

        Example:
            >>> tok.encode("مرحبا بالعالم")
            [1234, 5678, 9012]
        """
        # Internal preprocessing + BPE tokenization
        preprocessed = self.__preprocess(text)
        encoding = self.__tokenizer.encode(preprocessed, add_special_tokens=add_special_tokens)
        return encoding.ids

    def encode_batch(
        self,
        texts: List[str],
        add_special_tokens: bool = True,
    ) -> List[List[int]]:
        """
        Encode multiple texts in parallel.

        Args:
            texts: List of texts to encode
            add_special_tokens: Whether to add special tokens

        Returns:
            List[List[int]]: List of token ID lists
        """
        # Internal preprocessing + BPE tokenization
        preprocessed = self.__preprocess_batch(texts)
        encodings = self.__tokenizer.encode_batch(preprocessed, add_special_tokens=add_special_tokens)
        return [enc.ids for enc in encodings]

    def decode(
        self,
        ids: List[int],
        skip_special_tokens: bool = True,
    ) -> str:
        """
        Decode token IDs to text.

        Args:
            ids: Token IDs to decode
            skip_special_tokens: Whether to skip special tokens in output

        Returns:
            str: Decoded text

        Example:
            >>> tok.decode([1234, 5678, 9012])
            'مرحبا بالعالم'
        """
        # BPE detokenization + internal postprocessing
        text = self.__tokenizer.decode(ids, skip_special_tokens=skip_special_tokens)
        return self.__postprocess(text)

    def decode_batch(
        self,
        batch_ids: List[List[int]],
        skip_special_tokens: bool = True,
    ) -> List[str]:
        """
        Decode multiple sequences in parallel.

        Args:
            batch_ids: List of token ID lists
            skip_special_tokens: Whether to skip special tokens

        Returns:
            List[str]: List of decoded texts
        """
        # BPE detokenization + internal postprocessing
        texts = self.__tokenizer.decode_batch(batch_ids, skip_special_tokens=skip_special_tokens)
        return self.__postprocess_batch(texts)

    def add(
        self,
        tokens: Union[str, List[str], AddedToken, List[AddedToken]],
        special: bool = True,
    ) -> Dict[str, int]:
        """
        Add new tokens to vocabulary.

        Args:
            tokens: Token(s) to add. Can be:
                - str: Single token like "<user>"
                - List[str]: Multiple tokens like ["<user>", "<assistant>"]
                - AddedToken: Single AddedToken object with custom settings
                - List[AddedToken]: Multiple AddedToken objects
            special: Whether tokens are special (only used for str input)

        Returns:
            Dict mapping token string to assigned ID

        Examples:
            >>> tok.add("<user>")
            {"<user>": 64030}

            >>> tok.add(["<user>", "<assistant>"])
            {"<user>": 64030, "<assistant>": 64031}

            >>> tok.add(AddedToken("<pad>", special=True, rstrip=True))
            {"<pad>": 64032}
        """
        # Normalize input to list of AddedToken
        if isinstance(tokens, str):
            tokens = [AddedToken(tokens, special=special)]
        elif isinstance(tokens, AddedToken):
            tokens = [tokens]
        elif isinstance(tokens, list):
            normalized = []
            for t in tokens:
                if isinstance(t, str):
                    normalized.append(AddedToken(t, special=special))
                elif isinstance(t, AddedToken):
                    normalized.append(t)
                else:
                    raise TypeError(f"Expected str or AddedToken, got {type(t)}")
            tokens = normalized

        result = {}
        for token in tokens:
            # Skip if already added
            if token.content in self._added_tokens:
                result[token.content] = self._added_tokens[token.content].id
                continue

            # Assign ID
            token.id = self._next_id
            self._next_id += 1

            # Add to HuggingFace tokenizer
            from tokenizers import AddedToken as HFAddedToken
            hf_token = HFAddedToken(
                content=token.content,
                single_word=token.single_word,
                lstrip=token.lstrip,
                rstrip=token.rstrip,
                normalized=token.normalized,
                special=token.special,
            )
            if token.special:
                self.__tokenizer.add_special_tokens([hf_token])
            else:
                self.__tokenizer.add_tokens([hf_token])

            # Track
            self._added_tokens[token.content] = token
            result[token.content] = token.id

        return result

    def save(self, path: str) -> None:
        """
        Save tokenizer to directory.

        Creates the following files:
        - tokenizer.json: Base BPE model with added tokens embedded
        - tokenizer_config.json: Tokenizer configuration
        - special_tokens_map.json: Special token definitions
        - added_tokens.json: User-added tokens (for tracking/reloading)
        - morf_map.enc: Encrypted morpheme mapping (if available)

        Args:
            path: Directory to save to

        Example:
            >>> tok.add(["<user>", "<assistant>"])
            >>> tok.save("./my_tokenizer")
        """
        save_dir = Path(path)
        save_dir.mkdir(parents=True, exist_ok=True)

        # Save HuggingFace tokenizer (includes added tokens)
        self.__tokenizer.save(str(save_dir / "tokenizer.json"))

        # Collect special tokens info for config
        special_tokens_info = {}
        additional_special = []
        for token in self._added_tokens.values():
            if token.special:
                content_lower = token.content.lower()
                if "pad" in content_lower:
                    special_tokens_info["pad_token"] = token.content
                elif "bos" in content_lower or "start" in content_lower:
                    special_tokens_info["bos_token"] = token.content
                elif "eos" in content_lower or "end" in content_lower:
                    special_tokens_info["eos_token"] = token.content
                elif "unk" in content_lower:
                    special_tokens_info["unk_token"] = token.content
                elif "sep" in content_lower:
                    special_tokens_info["sep_token"] = token.content
                elif "cls" in content_lower:
                    special_tokens_info["cls_token"] = token.content
                elif "mask" in content_lower:
                    special_tokens_info["mask_token"] = token.content
                else:
                    additional_special.append(token.content)

        # Save tokenizer config
        config = {
            "tokenizer_class": "SARFTokenizer",
            "vocab_size": self.vocab_size,
            "model_type": "bpe",
            **special_tokens_info,
        }
        if additional_special:
            config["additional_special_tokens"] = additional_special

        with open(save_dir / "tokenizer_config.json", 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

        # Save special tokens map (HuggingFace compatible format)
        special_tokens_map = {}
        additional_special_tokens = []

        for token in self._added_tokens.values():
            if token.special:
                content_lower = token.content.lower()
                # Map to standard HuggingFace token roles
                if "pad" in content_lower:
                    special_tokens_map["pad_token"] = token.content
                elif "bos" in content_lower or "start" in content_lower:
                    special_tokens_map["bos_token"] = token.content
                elif "eos" in content_lower or "end" in content_lower:
                    special_tokens_map["eos_token"] = token.content
                elif "unk" in content_lower:
                    special_tokens_map["unk_token"] = token.content
                elif "sep" in content_lower:
                    special_tokens_map["sep_token"] = token.content
                elif "cls" in content_lower:
                    special_tokens_map["cls_token"] = token.content
                elif "mask" in content_lower:
                    special_tokens_map["mask_token"] = token.content
                else:
                    # Other special tokens go to additional_special_tokens
                    additional_special_tokens.append(token.content)

        # Add additional_special_tokens if any
        if additional_special_tokens:
            special_tokens_map["additional_special_tokens"] = additional_special_tokens

        if special_tokens_map:
            with open(save_dir / "special_tokens_map.json", 'w', encoding='utf-8') as f:
                json.dump(special_tokens_map, f, indent=2, ensure_ascii=False)

        # Save added tokens
        if self._added_tokens:
            added_tokens_data = {
                "version": "1.0",
                "added_tokens": [token.to_dict() for token in self._added_tokens.values()],
                "next_id": self._next_id,
            }
            with open(save_dir / "added_tokens.json", 'w', encoding='utf-8') as f:
                json.dump(added_tokens_data, f, indent=2, ensure_ascii=False)

        # Copy encrypted morf_map (convert to .bin for better IP protection)
        if self.__morf_map_path is not None:
            src_path = Path(self.__morf_map_path)
            if src_path.exists():
                if self.__morf_map_path.endswith('.bin'):
                    # Already binary format, just copy
                    shutil.copy2(src_path, save_dir / "morf_map.bin")
                elif self.__morf_map_path.endswith('.enc'):
                    # Convert .enc to .bin for better IP protection
                    try:
                        from . import convert_enc_to_bin
                        convert_enc_to_bin(str(src_path), str(save_dir / "morf_map.bin"))
                    except Exception:
                        # Fallback: just copy the .enc file
                        shutil.copy2(src_path, save_dir / "morf_map.enc")

    def get_vocab(self) -> Dict[str, int]:
        """Get full vocabulary including added tokens."""
        return self.__tokenizer.get_vocab()

    def token_to_id(self, token: str) -> Optional[int]:
        """Convert token string to ID."""
        return self.__tokenizer.token_to_id(token)

    def id_to_token(self, id: int) -> Optional[str]:
        """Convert ID to token string."""
        return self.__tokenizer.id_to_token(id)

    def __repr__(self) -> str:
        return f"SARFTokenizer(vocab_size={self.vocab_size})"

    def __call__(
        self,
        text: Union[str, List[str]],
        add_special_tokens: bool = True,
        padding: bool = False,
        max_length: Optional[int] = None,
        truncation: bool = False,
        return_tensors: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Callable interface for HuggingFace compatibility.

        Args:
            text: Input text or list of texts
            add_special_tokens: Whether to add special tokens
            padding: Whether to pad sequences
            max_length: Maximum sequence length
            truncation: Whether to truncate
            return_tensors: "pt" for PyTorch, "np" for NumPy, None for lists

        Returns:
            Dictionary with "input_ids" and "attention_mask"
        """
        if isinstance(text, str):
            texts = [text]
        else:
            texts = text

        input_ids = self.encode_batch(texts, add_special_tokens=add_special_tokens)

        # Apply truncation
        if truncation and max_length is not None:
            input_ids = [ids[:max_length] for ids in input_ids]

        # Apply padding
        if padding:
            pad_length = max_length or max(len(ids) for ids in input_ids)
            input_ids = [
                ids + [0] * (pad_length - len(ids)) for ids in input_ids
            ]

        # Create attention mask
        attention_mask = [[1 if id != 0 else 0 for id in ids] for ids in input_ids]

        result = {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
        }

        # Convert to tensors if requested
        if return_tensors == "pt":
            import torch
            result["input_ids"] = torch.tensor(result["input_ids"])
            result["attention_mask"] = torch.tensor(result["attention_mask"])
        elif return_tensors == "np":
            import numpy as np
            result["input_ids"] = np.array(result["input_ids"])
            result["attention_mask"] = np.array(result["attention_mask"])

        return result

    # Prevent attribute access to protected internals
    def __getattribute__(self, name: str):
        # Block direct access to mangled names from outside
        if name.startswith('_SARFTokenizer__') and not name.startswith('_SARFTokenizer__'):
            raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")
        return super().__getattribute__(name)
