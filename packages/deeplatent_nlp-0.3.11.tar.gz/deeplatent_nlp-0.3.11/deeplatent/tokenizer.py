"""
High-level tokenizer API for DeepLatent.

This module provides the SuhailTokenizer class that wraps the Rust
implementation with a Pythonic interface.

Note: For new code, prefer using SARFTokenizer from deeplatent.sarf_tokenizer.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Iterator, List, Optional, Union, Dict, Any, Iterable

from .config import NormalizationConfig

# Try to import Rust bindings
try:
    from ._deeplatent import SuhailTokenizer as _RustTokenizer
    HAS_RUST = True
except ImportError:
    HAS_RUST = False
    _RustTokenizer = None


class SuhailTokenizer:
    """
    High-performance Arabic-first tokenizer.

    This tokenizer implements MYTE (Morphologically-Yielding Tokenizer Encoding)
    with BPE, optimized for Arabic and other morphologically-rich languages.

    Attributes:
        vocab_size: Number of tokens in the vocabulary.

    Example:
        >>> tok = SuhailTokenizer.from_pretrained("sarf-65k")
        >>> ids = tok.encode("مرحبا بالعالم")
        >>> print(tok.decode(ids))
        مرحبا بالعالم
    """

    def __init__(
        self,
        model: str = "sarf-65k",
        license_key: Optional[str] = None,
        normalize: bool = True,
        normalize_config: Optional[NormalizationConfig] = None,
    ):
        """
        Initialize the tokenizer.

        Args:
            model: Model name or path to model directory.
            license_key: License key for commercial features.
            normalize: Whether to apply text normalization.
            normalize_config: Custom normalization configuration.
        """
        self._model = model
        self._license_key = license_key
        self._normalize = normalize
        self._normalize_config = normalize_config or NormalizationConfig()
        self._tokenizer = None

        # Try to load model
        if HAS_RUST:
            self._load_rust_tokenizer(model, license_key)
        else:
            self._load_python_fallback(model)

    def _load_rust_tokenizer(self, model: str, license_key: Optional[str]):
        """Load tokenizer using Rust bindings."""
        if os.path.isdir(model):
            self._tokenizer = _RustTokenizer.from_pretrained(model, license_key)
        else:
            # Try standard model paths
            model_paths = [
                Path(__file__).parent.parent / "models" / model,
                Path.home() / ".cache" / "deeplatent" / model,
            ]
            for path in model_paths:
                if path.exists():
                    self._tokenizer = _RustTokenizer.from_pretrained(
                        str(path), license_key
                    )
                    return

            raise FileNotFoundError(f"Model not found: {model}")

    def _load_python_fallback(self, model: str):
        """Load tokenizer using pure Python (limited functionality)."""
        # This is a fallback when Rust bindings aren't available
        self._vocab = {}
        self._merges = []
        self._morpheme_map = {}

        if os.path.isdir(model):
            model_dir = Path(model)
        else:
            model_dir = Path(__file__).parent.parent / "models" / model

        if model_dir.exists():
            vocab_path = model_dir / "vocab.json"
            if vocab_path.exists():
                with open(vocab_path, "r", encoding="utf-8") as f:
                    self._vocab = json.load(f)

            merges_path = model_dir / "merges.json"
            if merges_path.exists():
                with open(merges_path, "r", encoding="utf-8") as f:
                    self._merges = json.load(f)

            morf_path = model_dir / "morphemes.json"
            if morf_path.exists():
                with open(morf_path, "r", encoding="utf-8") as f:
                    self._morpheme_map = json.load(f)

    @property
    def vocab_size(self) -> int:
        """Get vocabulary size."""
        if self._tokenizer is not None:
            return self._tokenizer.vocab_size
        return len(self._vocab)

    def encode(
        self,
        text: str,
        add_special_tokens: bool = True,
        max_length: Optional[int] = None,
        padding: bool = False,
        truncation: bool = False,
    ) -> List[int]:
        """
        Encode text to token IDs.

        Args:
            text: Input text to encode.
            add_special_tokens: Whether to add BOS/EOS tokens.
            max_length: Maximum sequence length (requires truncation=True).
            padding: Whether to pad to max_length.
            truncation: Whether to truncate to max_length.

        Returns:
            List of token IDs.

        Example:
            >>> tok.encode("مرحبا")
            [2, 1234, 5678, 3]
        """
        if self._tokenizer is not None:
            ids = self._tokenizer.encode(text, add_special_tokens)
        else:
            # Python fallback (basic)
            ids = self._encode_python(text, add_special_tokens)

        # Apply truncation
        if truncation and max_length is not None:
            ids = ids[:max_length]

        # Apply padding
        if padding and max_length is not None:
            while len(ids) < max_length:
                ids.append(0)  # PAD token

        return ids

    def _encode_python(self, text: str, add_special_tokens: bool) -> List[int]:
        """Pure Python encoding (fallback)."""
        # Very basic byte-level fallback
        ids = []
        for byte in text.encode("utf-8"):
            token = str(byte)
            if token in self._vocab:
                ids.append(self._vocab[token])
            else:
                ids.append(1)  # UNK

        if add_special_tokens:
            ids = [2] + ids + [3]  # BOS, EOS

        return ids

    def encode_batch(
        self,
        texts: List[str],
        add_special_tokens: bool = True,
        padding: bool = False,
        max_length: Optional[int] = None,
    ) -> List[List[int]]:
        """
        Encode batch of texts.

        Args:
            texts: List of texts to encode.
            add_special_tokens: Whether to add special tokens.
            padding: Whether to pad all sequences to same length.
            max_length: Maximum sequence length.

        Returns:
            List of token ID lists.
        """
        if self._tokenizer is not None:
            return self._tokenizer.encode_batch(texts, add_special_tokens, padding)

        # Python fallback
        results = [self.encode(t, add_special_tokens) for t in texts]

        if padding:
            max_len = max_length or max(len(r) for r in results)
            results = [r + [0] * (max_len - len(r)) for r in results]

        return results

    def decode(
        self,
        token_ids: List[int],
        skip_special_tokens: bool = True,
        clean_up_tokenization_spaces: bool = True,
    ) -> str:
        """
        Decode token IDs to text.

        Args:
            token_ids: List of token IDs to decode.
            skip_special_tokens: Whether to skip BOS/EOS/PAD tokens.
            clean_up_tokenization_spaces: Whether to clean up spaces.

        Returns:
            Decoded text string.

        Example:
            >>> tok.decode([2, 1234, 5678, 3])
            "مرحبا"
        """
        if self._tokenizer is not None:
            return self._tokenizer.decode(token_ids, skip_special_tokens)

        # Python fallback (basic)
        return self._decode_python(token_ids, skip_special_tokens)

    def _decode_python(self, token_ids: List[int], skip_special_tokens: bool) -> str:
        """Pure Python decoding (fallback)."""
        # Build reverse vocab
        reverse_vocab = {v: k for k, v in self._vocab.items()}

        tokens = []
        for id in token_ids:
            if skip_special_tokens and id in (0, 1, 2, 3):
                continue
            if id in reverse_vocab:
                tokens.append(reverse_vocab[id])

        # Try to reconstruct text
        try:
            byte_values = [int(t) for t in tokens if t.isdigit()]
            return bytes(byte_values).decode("utf-8", errors="replace")
        except (ValueError, UnicodeDecodeError):
            return " ".join(tokens)

    def decode_batch(
        self,
        batch_ids: List[List[int]],
        skip_special_tokens: bool = True,
    ) -> List[str]:
        """
        Decode batch of token IDs.

        Args:
            batch_ids: List of token ID lists.
            skip_special_tokens: Whether to skip special tokens.

        Returns:
            List of decoded strings.
        """
        if self._tokenizer is not None:
            return self._tokenizer.decode_batch(batch_ids, skip_special_tokens)

        return [self.decode(ids, skip_special_tokens) for ids in batch_ids]

    # =========================================================================
    # Streaming API for memory-efficient processing
    # =========================================================================

    def encode_iter(
        self,
        text_iter: Iterable[str],
        batch_size: int = 128,
        add_special_tokens: bool = True,
        max_length: Optional[int] = None,
        truncation: bool = False,
    ) -> Iterator[List[int]]:
        """
        Generator for streaming tokenization of large datasets.

        This method processes texts in batches and yields token IDs one by one,
        enabling memory-efficient processing of datasets that don't fit in memory.

        Args:
            text_iter: Iterator or iterable of texts to encode.
            batch_size: Number of texts to process per batch (for parallelism).
            add_special_tokens: Whether to add BOS/EOS tokens.
            max_length: Maximum sequence length (requires truncation=True).
            truncation: Whether to truncate to max_length.

        Yields:
            Token ID lists, one per input text.

        Example:
            >>> def read_lines(path):
            ...     with open(path) as f:
            ...         for line in f:
            ...             yield line.strip()
            >>> for ids in tok.encode_iter(read_lines("corpus.txt"), batch_size=256):
            ...     process(ids)
        """
        batch = []

        for text in text_iter:
            batch.append(text)

            if len(batch) >= batch_size:
                # Process batch
                results = self.encode_batch(
                    batch,
                    add_special_tokens=add_special_tokens,
                    padding=False,
                    max_length=max_length,
                )

                # Apply truncation if needed
                for ids in results:
                    if truncation and max_length is not None:
                        yield ids[:max_length]
                    else:
                        yield ids

                batch = []

        # Process remaining texts
        if batch:
            results = self.encode_batch(
                batch,
                add_special_tokens=add_special_tokens,
                padding=False,
                max_length=max_length,
            )

            for ids in results:
                if truncation and max_length is not None:
                    yield ids[:max_length]
                else:
                    yield ids

    def decode_iter(
        self,
        ids_iter: Iterable[List[int]],
        batch_size: int = 128,
        skip_special_tokens: bool = True,
    ) -> Iterator[str]:
        """
        Generator for streaming decoding of token ID batches.

        Args:
            ids_iter: Iterator or iterable of token ID lists.
            batch_size: Number of sequences to process per batch.
            skip_special_tokens: Whether to skip special tokens.

        Yields:
            Decoded strings, one per input token list.

        Example:
            >>> for text in tok.decode_iter(token_ids_generator()):
            ...     print(text)
        """
        batch = []

        for ids in ids_iter:
            batch.append(ids)

            if len(batch) >= batch_size:
                results = self.decode_batch(batch, skip_special_tokens=skip_special_tokens)
                for text in results:
                    yield text
                batch = []

        if batch:
            results = self.decode_batch(batch, skip_special_tokens=skip_special_tokens)
            for text in results:
                yield text

    def encode_file(
        self,
        input_path: str,
        batch_size: int = 256,
        add_special_tokens: bool = True,
        max_length: Optional[int] = None,
        truncation: bool = False,
        encoding: str = "utf-8",
    ) -> Iterator[List[int]]:
        """
        Stream-encode a text file line by line.

        Memory-efficient encoding of large text files without loading
        the entire file into memory.

        Args:
            input_path: Path to input text file (one text per line).
            batch_size: Batch size for parallel processing.
            add_special_tokens: Whether to add special tokens.
            max_length: Maximum sequence length.
            truncation: Whether to truncate.
            encoding: File encoding.

        Yields:
            Token ID lists, one per line.

        Example:
            >>> for ids in tok.encode_file("large_corpus.txt", batch_size=512):
            ...     yield ids
        """
        def line_reader():
            with open(input_path, "r", encoding=encoding) as f:
                for line in f:
                    yield line.rstrip("\n\r")

        yield from self.encode_iter(
            line_reader(),
            batch_size=batch_size,
            add_special_tokens=add_special_tokens,
            max_length=max_length,
            truncation=truncation,
        )

    def tokenize(self, text: str) -> List[str]:
        """
        Tokenize text to subword strings.

        Args:
            text: Input text.

        Returns:
            List of subword strings.
        """
        if self._tokenizer is not None:
            return self._tokenizer.tokenize(text)

        # Fallback
        ids = self.encode(text, add_special_tokens=False)
        reverse_vocab = {v: k for k, v in self._vocab.items()}
        return [reverse_vocab.get(id, "<unk>") for id in ids]

    def save_pretrained(self, path: str, encrypt: bool = False):
        """
        Save tokenizer to directory.

        Args:
            path: Directory path to save to.
            encrypt: Whether to encrypt model files.
        """
        if self._tokenizer is not None:
            self._tokenizer.save_pretrained(path, encrypt)
        else:
            # Python fallback
            os.makedirs(path, exist_ok=True)

            with open(os.path.join(path, "vocab.json"), "w", encoding="utf-8") as f:
                json.dump(self._vocab, f, ensure_ascii=False, indent=2)

            with open(os.path.join(path, "merges.json"), "w", encoding="utf-8") as f:
                json.dump(self._merges, f, ensure_ascii=False, indent=2)

            with open(os.path.join(path, "morphemes.json"), "w", encoding="utf-8") as f:
                json.dump(self._morpheme_map, f, ensure_ascii=False, indent=2)

    @classmethod
    def from_pretrained(
        cls,
        path: str,
        license_key: Optional[str] = None,
        **kwargs,
    ) -> "SuhailTokenizer":
        """
        Load tokenizer from pretrained model.

        Args:
            path: Path to model directory or model name.
            license_key: License key for commercial features.
            **kwargs: Additional arguments passed to __init__.

        Returns:
            Loaded tokenizer instance.
        """
        return cls(model=path, license_key=license_key, **kwargs)

    def __repr__(self) -> str:
        return f"SuhailTokenizer(model='{self._model}', vocab_size={self.vocab_size})"

    def __call__(
        self,
        text: Union[str, List[str]],
        add_special_tokens: bool = True,
        padding: bool = False,
        max_length: Optional[int] = None,
        truncation: bool = False,
        return_tensors: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Callable interface for HuggingFace compatibility.

        Args:
            text: Input text or list of texts.
            add_special_tokens: Whether to add special tokens.
            padding: Whether to pad sequences.
            max_length: Maximum sequence length.
            truncation: Whether to truncate.
            return_tensors: "pt" for PyTorch, "np" for NumPy, None for lists.

        Returns:
            Dictionary with "input_ids" and "attention_mask".
        """
        if isinstance(text, str):
            texts = [text]
        else:
            texts = text

        input_ids = self.encode_batch(
            texts,
            add_special_tokens=add_special_tokens,
            padding=padding,
            max_length=max_length,
        )

        # Create attention mask
        attention_mask = [[1 if id != 0 else 0 for id in ids] for ids in input_ids]

        result = {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
        }

        # Convert to tensors if requested
        if return_tensors == "pt":
            import torch
            result["input_ids"] = torch.tensor(result["input_ids"])
            result["attention_mask"] = torch.tensor(result["attention_mask"])
        elif return_tensors == "np":
            import numpy as np
            result["input_ids"] = np.array(result["input_ids"])
            result["attention_mask"] = np.array(result["attention_mask"])

        return result
