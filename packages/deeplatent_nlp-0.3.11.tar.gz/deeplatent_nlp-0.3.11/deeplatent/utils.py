"""
Utility functions for DeepLatent tokenizer.

Extended with edge-case handling utilities for:
- Unicode normalization
- Grapheme cluster handling
- Pattern detection (URLs, emails, paths)
- Zero-width character handling
- Whitespace normalization
"""

import re
import unicodedata
from typing import List, Tuple, Optional, Iterator

# =============================================================================
# Arabic Unicode ranges
# =============================================================================

ARABIC_RANGES = [
    (0x0600, 0x06FF),  # Arabic
    (0x0750, 0x077F),  # Arabic Supplement
    (0x08A0, 0x08FF),  # Arabic Extended-A
    (0xFB50, 0xFDFF),  # Arabic Presentation Forms-A
    (0xFE70, 0xFEFF),  # Arabic Presentation Forms-B
]

# Arabic diacritics (harakat)
ARABIC_DIACRITICS = [
    '\u064B',  # fathatan
    '\u064C',  # dammatan
    '\u064D',  # kasratan
    '\u064E',  # fatha
    '\u064F',  # damma
    '\u0650',  # kasra
    '\u0651',  # shadda
    '\u0652',  # sukun
    '\u0653',  # maddah above
    '\u0654',  # hamza above
    '\u0655',  # hamza below
    '\u0656',  # subscript alef
    '\u0670',  # superscript alef
]

# Arabic-Indic digits
ARABIC_INDIC_DIGITS = '٠١٢٣٤٥٦٧٨٩'
WESTERN_DIGITS = '0123456789'

# =============================================================================
# Zero-width characters
# =============================================================================

ZERO_WIDTH_CHARS = {
    '\u200B',  # Zero Width Space
    '\u200C',  # Zero Width Non-Joiner
    '\u200D',  # Zero Width Joiner (ZWJ)
    '\u200E',  # Left-to-Right Mark
    '\u200F',  # Right-to-Left Mark
    '\u2060',  # Word Joiner
    '\u2061',  # Function Application
    '\u2062',  # Invisible Times
    '\u2063',  # Invisible Separator
    '\u2064',  # Invisible Plus
    '\uFEFF',  # Byte Order Mark
}

ZWJ = '\u200D'  # Zero Width Joiner

# =============================================================================
# Unicode whitespace
# =============================================================================

UNICODE_WHITESPACE = {
    '\u00A0',  # No-Break Space
    '\u1680',  # Ogham Space Mark
    '\u2000',  # En Quad
    '\u2001',  # Em Quad
    '\u2002',  # En Space
    '\u2003',  # Em Space
    '\u2004',  # Three-Per-Em Space
    '\u2005',  # Four-Per-Em Space
    '\u2006',  # Six-Per-Em Space
    '\u2007',  # Figure Space
    '\u2008',  # Punctuation Space
    '\u2009',  # Thin Space
    '\u200A',  # Hair Space
    '\u202F',  # Narrow No-Break Space
    '\u205F',  # Medium Mathematical Space
    '\u3000',  # Ideographic Space
}

# =============================================================================
# Apostrophe and dash normalization maps
# =============================================================================

APOSTROPHE_MAP = {
    '\u2019': "'",  # Right Single Quotation Mark
    '\u2018': "'",  # Left Single Quotation Mark
    '\u201B': "'",  # Single High-Reversed-9 Quotation Mark
    '\u02BC': "'",  # Modifier Letter Apostrophe
    '\u02BB': "'",  # Modifier Letter Turned Comma
    '\uFF07': "'",  # Fullwidth Apostrophe
}

DASH_MAP = {
    '\u2010': '-',  # Hyphen
    '\u2011': '-',  # Non-Breaking Hyphen
    '\u2012': '-',  # Figure Dash
    '\u2013': '-',  # En Dash
    '\u2014': '-',  # Em Dash
    '\u2015': '-',  # Horizontal Bar
    '\u2212': '-',  # Minus Sign
    '\uFE58': '-',  # Small Em Dash
    '\uFE63': '-',  # Small Hyphen-Minus
    '\uFF0D': '-',  # Fullwidth Hyphen-Minus
}

# =============================================================================
# Pattern regex
# =============================================================================

URL_PATTERN = re.compile(
    r'(?i)(https?|ftp|file)://[^\s<>\[\]{}|\\^`\x00-\x1F\x7F]+'
)

EMAIL_PATTERN = re.compile(
    r'(?i)[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}'
)

WINDOWS_PATH_PATTERN = re.compile(
    r'(?i)(?:[A-Z]:|\\\\[a-zA-Z0-9._\-]+)(?:\\[^\s\\:*?"<>|]+)+'
)

UNIX_PATH_PATTERN = re.compile(
    r'(?:/[a-zA-Z0-9._\-]+)+(?:/[a-zA-Z0-9._\-]*)?'
)


def is_arabic(char: str) -> bool:
    """Check if a character is Arabic."""
    code = ord(char)
    return any(start <= code <= end for start, end in ARABIC_RANGES)


def is_arabic_diacritic(char: str) -> bool:
    """Check if a character is an Arabic diacritic."""
    return char in ARABIC_DIACRITICS


def is_pua(char: str) -> bool:
    """Check if a character is in Private Use Area."""
    code = ord(char)
    return (
        (0xE000 <= code <= 0xF8FF) or      # Basic PUA
        (0xF0000 <= code <= 0xFFFFD) or    # Supplementary PUA-A
        (0x100000 <= code <= 0x10FFFD)     # Supplementary PUA-B
    )


def strip_diacritics(text: str) -> str:
    """Remove all Arabic diacritics from text."""
    return ''.join(c for c in text if c not in ARABIC_DIACRITICS)


def normalize_arabic_digits(text: str) -> str:
    """Convert Arabic-Indic digits to Western digits."""
    trans = str.maketrans(ARABIC_INDIC_DIGITS, WESTERN_DIGITS)
    return text.translate(trans)


def normalize_alef(text: str) -> str:
    """Normalize alef variants to bare alef."""
    # أ إ آ ٱ -> ا
    return re.sub(r'[أإآٱ]', 'ا', text)


def normalize_taa_marbouta(text: str) -> str:
    """Normalize taa marbouta to haa."""
    return text.replace('ة', 'ه')


def normalize_alef_maqsura(text: str) -> str:
    """Normalize alef maqsura to yaa."""
    return text.replace('ى', 'ي')


def remove_tatweel(text: str) -> str:
    """Remove tatweel (kashida) character."""
    return text.replace('\u0640', '')


def remove_zero_width(text: str) -> str:
    """Remove zero-width characters."""
    zero_width = '\u200B\u200C\u200D\u200E\u200F\uFEFF'
    return ''.join(c for c in text if c not in zero_width)


def normalize_whitespace(text: str) -> str:
    """Collapse multiple whitespace to single space."""
    return re.sub(r'\s+', ' ', text).strip()


def full_normalize(
    text: str,
    normalize_alef_variants: bool = False,
    normalize_taa: bool = False,
    normalize_alef_maq: bool = False,
    strip_harakat: bool = False,
    remove_kashida: bool = True,
    normalize_digits_: bool = False,
) -> str:
    """
    Apply full normalization pipeline.

    Args:
        text: Input text.
        normalize_alef_variants: Normalize alef variants.
        normalize_taa: Normalize taa marbouta.
        normalize_alef_maq: Normalize alef maqsura.
        strip_harakat: Strip diacritics.
        remove_kashida: Remove tatweel.
        normalize_digits_: Convert Arabic-Indic to Western digits.

    Returns:
        Normalized text.
    """
    text = remove_zero_width(text)

    if remove_kashida:
        text = remove_tatweel(text)

    if strip_harakat:
        text = strip_diacritics(text)

    if normalize_alef_variants:
        text = normalize_alef(text)

    if normalize_taa:
        text = normalize_taa_marbouta(text)

    if normalize_alef_maq:
        text = normalize_alef_maqsura(text)

    if normalize_digits_:
        text = normalize_arabic_digits(text)

    text = normalize_whitespace(text)

    return text


def split_into_words(text: str) -> List[str]:
    """Split text into words, preserving Arabic word boundaries."""
    # Split on whitespace but keep track of Arabic word structure
    return text.split()


def extract_arabic_tokens(text: str) -> List[Tuple[str, int, int]]:
    """
    Extract Arabic tokens with their positions.

    Returns:
        List of (token, start, end) tuples.
    """
    tokens = []
    pattern = re.compile(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]+')

    for match in pattern.finditer(text):
        tokens.append((match.group(), match.start(), match.end()))

    return tokens


def count_arabic_chars(text: str) -> int:
    """Count number of Arabic characters in text."""
    return sum(1 for c in text if is_arabic(c))


def arabic_ratio(text: str) -> float:
    """Calculate ratio of Arabic characters to total characters."""
    total = len(text.replace(' ', ''))
    if total == 0:
        return 0.0
    return count_arabic_chars(text) / total


def format_pua_code(char: str) -> str:
    """Format PUA character as Unicode code point string."""
    return f"U+{ord(char):05X}"


def decode_pua_code(code: str) -> Optional[str]:
    """Decode Unicode code point string to character."""
    try:
        if code.startswith("U+"):
            code = code[2:]
        return chr(int(code, 16))
    except (ValueError, OverflowError):
        return None


# =============================================================================
# Unicode normalization
# =============================================================================

def normalize_nfc(text: str) -> str:
    """Apply NFC Unicode normalization."""
    return unicodedata.normalize('NFC', text)


def normalize_nfkc(text: str) -> str:
    """Apply NFKC Unicode normalization."""
    return unicodedata.normalize('NFKC', text)


def is_nfc_normalized(text: str) -> bool:
    """Check if text is NFC normalized."""
    return unicodedata.is_normalized('NFC', text)


# =============================================================================
# Zero-width character handling
# =============================================================================

def is_zero_width(char: str) -> bool:
    """Check if a character is a zero-width character."""
    return char in ZERO_WIDTH_CHARS


def remove_zero_width_all(text: str) -> str:
    """Remove all zero-width characters."""
    return ''.join(c for c in text if c not in ZERO_WIDTH_CHARS)


def remove_zero_width_preserve_zwj(text: str) -> str:
    """Remove zero-width characters but preserve ZWJ for emoji sequences."""
    return ''.join(c for c in text if c not in ZERO_WIDTH_CHARS or c == ZWJ)


# =============================================================================
# Whitespace normalization
# =============================================================================

def is_unicode_whitespace(char: str) -> bool:
    """Check if a character is a Unicode whitespace character."""
    return char in UNICODE_WHITESPACE or char.isspace()


def normalize_unicode_whitespace(text: str) -> str:
    """Normalize all Unicode whitespace to ASCII space and collapse."""
    result = []
    prev_space = False

    for c in text:
        is_ws = c.isspace() or c in UNICODE_WHITESPACE
        if is_ws:
            if not prev_space:
                result.append(' ')
                prev_space = True
        else:
            result.append(c)
            prev_space = False

    # Normalize CRLF to LF
    text = ''.join(result)
    text = text.replace('\r\n', '\n')
    return text.strip()


# =============================================================================
# Apostrophe and dash normalization
# =============================================================================

def normalize_apostrophes(text: str) -> str:
    """Normalize curly apostrophes to ASCII apostrophe."""
    for curly, ascii_apos in APOSTROPHE_MAP.items():
        text = text.replace(curly, ascii_apos)
    return text


def normalize_dashes(text: str) -> str:
    """Normalize various dash characters to ASCII hyphen."""
    for dash, hyphen in DASH_MAP.items():
        text = text.replace(dash, hyphen)
    return text


# =============================================================================
# Pattern detection
# =============================================================================

def contains_url(text: str) -> bool:
    """Check if text contains a URL."""
    return bool(URL_PATTERN.search(text))


def contains_email(text: str) -> bool:
    """Check if text contains an email address."""
    return bool(EMAIL_PATTERN.search(text))


def contains_path(text: str) -> bool:
    """Check if text contains a file path."""
    return bool(WINDOWS_PATH_PATTERN.search(text) or UNIX_PATH_PATTERN.search(text))


def extract_urls(text: str) -> List[str]:
    """Extract all URLs from text."""
    return URL_PATTERN.findall(text)


def extract_emails(text: str) -> List[str]:
    """Extract all email addresses from text."""
    return EMAIL_PATTERN.findall(text)


def extract_paths(text: str) -> List[str]:
    """Extract all file paths from text."""
    paths = WINDOWS_PATH_PATTERN.findall(text)
    paths.extend(UNIX_PATH_PATTERN.findall(text))
    return paths


def is_valid_url(text: str) -> bool:
    """Check if entire text is a valid URL."""
    match = URL_PATTERN.match(text)
    return match is not None and match.group() == text


def is_valid_email(text: str) -> bool:
    """Check if entire text is a valid email address."""
    match = EMAIL_PATTERN.match(text)
    return match is not None and match.group() == text


# =============================================================================
# Grapheme cluster handling
# =============================================================================

def grapheme_iter(text: str) -> Iterator[str]:
    """
    Iterate over grapheme clusters in text.

    Uses the grapheme library if available, falls back to char-by-char iteration.
    """
    try:
        import grapheme
        return grapheme.graphemes(text)
    except ImportError:
        # Fallback: simple char iteration (doesn't handle complex graphemes)
        return iter(text)


def grapheme_count(text: str) -> int:
    """Count grapheme clusters in text."""
    try:
        import grapheme
        return grapheme.length(text)
    except ImportError:
        # Fallback: count characters
        return len(text)


def grapheme_slice(text: str, start: int, end: Optional[int] = None) -> str:
    """Slice text by grapheme cluster indices."""
    try:
        import grapheme
        return grapheme.slice(text, start, end)
    except ImportError:
        # Fallback: use regular slicing
        return text[start:end]


def is_emoji(char: str) -> bool:
    """Check if a character is an emoji."""
    cp = ord(char) if len(char) == 1 else ord(char[0])
    return (
        (0x1F300 <= cp <= 0x1F5FF) or  # Misc Symbols and Pictographs
        (0x1F600 <= cp <= 0x1F64F) or  # Emoticons
        (0x1F680 <= cp <= 0x1F6FF) or  # Transport and Map
        (0x1F900 <= cp <= 0x1F9FF) or  # Supplemental Symbols
        (0x1FA00 <= cp <= 0x1FAFF) or  # Extended-A/B
        (0x2600 <= cp <= 0x26FF) or    # Misc symbols
        (0x2700 <= cp <= 0x27BF)       # Dingbats
    )


def is_emoji_sequence(text: str) -> bool:
    """Check if text is an emoji sequence (including ZWJ sequences)."""
    if not text:
        return False

    # Contains ZWJ (family emoji, profession emoji, etc.)
    if ZWJ in text:
        return True

    # Check first character
    if len(text) >= 1 and is_emoji(text[0]):
        return True

    # Check for flag sequences (regional indicators)
    if len(text) == 2:
        cp1 = ord(text[0])
        cp2 = ord(text[1])
        if 0x1F1E6 <= cp1 <= 0x1F1FF and 0x1F1E6 <= cp2 <= 0x1F1FF:
            return True

    return False


def is_skin_tone_modifier(char: str) -> bool:
    """Check if character is a Fitzpatrick skin tone modifier."""
    if len(char) != 1:
        return False
    cp = ord(char)
    return 0x1F3FB <= cp <= 0x1F3FF


def is_regional_indicator(char: str) -> bool:
    """Check if character is a Regional Indicator."""
    if len(char) != 1:
        return False
    cp = ord(char)
    return 0x1F1E6 <= cp <= 0x1F1FF


# =============================================================================
# Control character handling
# =============================================================================

def is_control_char(char: str) -> bool:
    """Check if character is a control character (excluding space, tab, newline)."""
    if len(char) != 1:
        return False
    cp = ord(char)
    # Allow tab, newline, carriage return
    if char in '\t\n\r':
        return False
    # C0 controls
    if cp < 0x20:
        return True
    # DEL
    if cp == 0x7F:
        return True
    # C1 controls
    if 0x80 <= cp <= 0x9F:
        return True
    # Bidirectional controls
    if 0x202A <= cp <= 0x202E or 0x2066 <= cp <= 0x2069:
        return True
    return False


def remove_control_chars(text: str) -> str:
    """Remove control characters from text (preserving newline/tab)."""
    return ''.join(c for c in text if not is_control_char(c))


def replace_control_chars(text: str, replacement: str = ' ') -> str:
    """Replace control characters with a replacement string."""
    return ''.join(replacement if is_control_char(c) else c for c in text)


# =============================================================================
# Input validation
# =============================================================================

def validate_input(
    text: str,
    max_length: Optional[int] = None,
    allow_empty: bool = True,
) -> Tuple[bool, Optional[str]]:
    """
    Validate input text.

    Returns:
        Tuple of (is_valid, error_message).
    """
    if not allow_empty and not text:
        return False, "Empty input not allowed"

    if max_length is not None and len(text) > max_length:
        return False, f"Input length {len(text)} exceeds maximum {max_length}"

    return True, None


# =============================================================================
# Full normalization pipeline
# =============================================================================

def full_normalize_extended(
    text: str,
    # Arabic-specific
    normalize_alef_variants: bool = False,
    normalize_taa: bool = False,
    normalize_alef_maq: bool = False,
    strip_harakat: bool = False,
    remove_kashida: bool = True,
    normalize_digits_: bool = False,
    # Edge-case hardening
    unicode_normalize: str = 'none',  # 'none', 'nfc', 'nfkc'
    collapse_whitespace: bool = True,
    normalize_unicode_ws: bool = False,
    remove_zero_width_chars: bool = True,
    preserve_zwj: bool = False,
    normalize_apos: bool = False,
    normalize_dash: bool = False,
    remove_ctrl_chars: bool = True,
) -> str:
    """
    Apply full extended normalization pipeline.

    Args:
        text: Input text.
        normalize_alef_variants: Normalize alef variants.
        normalize_taa: Normalize taa marbouta.
        normalize_alef_maq: Normalize alef maqsura.
        strip_harakat: Strip diacritics.
        remove_kashida: Remove tatweel.
        normalize_digits_: Convert Arabic-Indic to Western digits.
        unicode_normalize: Unicode normalization form ('none', 'nfc', 'nfkc').
        collapse_whitespace: Collapse multiple whitespace.
        normalize_unicode_ws: Normalize Unicode whitespace to ASCII.
        remove_zero_width_chars: Remove zero-width characters.
        preserve_zwj: Preserve ZWJ when removing zero-width chars.
        normalize_apos: Normalize apostrophes.
        normalize_dash: Normalize dashes.
        remove_ctrl_chars: Remove control characters.

    Returns:
        Normalized text.
    """
    # Step 1: Unicode normalization
    if unicode_normalize == 'nfc':
        text = normalize_nfc(text)
    elif unicode_normalize == 'nfkc':
        text = normalize_nfkc(text)

    # Step 2: Control character handling
    if remove_ctrl_chars:
        text = remove_control_chars(text)

    # Step 3: Zero-width character handling
    if remove_zero_width_chars:
        if preserve_zwj:
            text = remove_zero_width_preserve_zwj(text)
        else:
            text = remove_zero_width_all(text)

    # Step 4: Arabic-specific normalization
    if remove_kashida:
        text = remove_tatweel(text)

    if strip_harakat:
        text = strip_diacritics(text)

    if normalize_alef_variants:
        text = normalize_alef(text)

    if normalize_taa:
        text = normalize_taa_marbouta(text)

    if normalize_alef_maq:
        text = normalize_alef_maqsura(text)

    if normalize_digits_:
        text = normalize_arabic_digits(text)

    # Step 5: Apostrophe/dash normalization
    if normalize_apos:
        text = normalize_apostrophes(text)

    if normalize_dash:
        text = normalize_dashes(text)

    # Step 6: Whitespace normalization
    if normalize_unicode_ws:
        text = normalize_unicode_whitespace(text)
    elif collapse_whitespace:
        text = normalize_whitespace(text)

    return text
