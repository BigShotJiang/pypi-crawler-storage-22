//! Python bindings for DeepLatent tokenizer
//!
//! Provides PyO3 bindings to expose the Rust core to Python.

use pyo3::prelude::*;
use pyo3::exceptions::PyValueError;
use pyo3::types::PyDict;
use pyo3::Bound;
use rayon::ThreadPoolBuilder;
use suhail_core::{
    crypto::License,
    normalizer::NormalizationConfig,
    tokenizer::SuhailTokenizer as RustTokenizer,
    SarfCodec as RustSarfCodec,
    NormalizationLevel,
};
use std::collections::HashMap;

// =============================================================================
// SarfCodec - New v2 API (encode/decode only)
// =============================================================================

/// Python wrapper for SarfCodec - the main encode/decode interface
#[pyclass(name = "SarfCodec")]
pub struct PySarfCodec {
    inner: RustSarfCodec,
}

#[pymethods]
impl PySarfCodec {
    /// Create a new codec from morpheme map dictionary
    #[new]
    #[pyo3(signature = (morf_map, normalization="medium"))]
    fn new(morf_map: &Bound<'_, PyDict>, normalization: &str) -> PyResult<Self> {
        let mut map: HashMap<String, String> = HashMap::new();

        for (key, value) in morf_map.iter() {
            let k: String = key.extract()?;
            let v: String = value.extract()?;
            map.insert(k, v);
        }

        let level = match normalization {
            "light" => NormalizationLevel::Light,
            "aggressive" => NormalizationLevel::Aggressive,
            _ => NormalizationLevel::Medium,
        };

        let inner = RustSarfCodec::with_normalization(map, level);
        Ok(Self { inner })
    }

    /// Load codec from encrypted file (.enc or .bin)
    /// Auto-detects format based on magic bytes
    /// No license key required - decryption key is embedded in the library
    ///
    /// Args:
    ///     path: Path to encrypted morf_map file (.enc or .bin)
    ///     normalization: Normalization level ("light", "medium", "aggressive")
    ///
    /// Example:
    ///     >>> codec = SarfCodec.from_encrypted("morf_map.bin")
    ///     >>> codec = SarfCodec.from_encrypted("morf_map.enc", "aggressive")
    #[staticmethod]
    #[pyo3(signature = (path, normalization="medium"))]
    fn from_encrypted(path: &str, normalization: &str) -> PyResult<Self> {
        let level = match normalization {
            "light" => NormalizationLevel::Light,
            "aggressive" => NormalizationLevel::Aggressive,
            _ => NormalizationLevel::Medium,
        };

        // Auto-detects format (binary vs JSON) based on magic bytes
        let inner = RustSarfCodec::from_encrypted_file_with_normalization(path, level)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;
        Ok(Self { inner })
    }

    /// Load codec from binary morf_map file (.bin)
    /// Explicit method for binary format
    #[staticmethod]
    #[pyo3(signature = (path, normalization="medium"))]
    fn from_binary(path: &str, normalization: &str) -> PyResult<Self> {
        let level = match normalization {
            "light" => NormalizationLevel::Light,
            "aggressive" => NormalizationLevel::Aggressive,
            _ => NormalizationLevel::Medium,
        };

        let inner = RustSarfCodec::from_binary_file_with_normalization(path, level)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;
        Ok(Self { inner })
    }

    /// Encrypt and save morf_map to .enc file (legacy JSON format)
    /// Creates a .enc file that can only be read by this library
    fn encrypt_to_file(&self, path: &str) -> PyResult<()> {
        self.inner
            .encrypt_to_file(path)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))
    }

    /// Encrypt and save morf_map to .bin file (recommended binary format)
    /// Creates a .bin file with strongest IP protection
    fn encrypt_to_binary_file(&self, path: &str) -> PyResult<()> {
        self.inner
            .encrypt_to_binary_file(path)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))
    }

    /// Encode text (normalize + morpheme -> PUA)
    fn encode(&self, text: &str) -> String {
        self.inner.encode(text)
    }

    /// Decode text (byte decode + PUA -> morpheme + post-process)
    fn decode(&self, text: &str) -> String {
        self.inner.decode(text)
    }

    /// Normalize text only
    fn normalize(&self, text: &str) -> String {
        self.inner.normalize(text)
    }

    /// Roundtrip test
    fn roundtrip(&self, text: &str) -> (String, String, bool) {
        self.inner.roundtrip(text)
    }

    /// Get number of morphemes
    #[getter]
    fn num_morphemes(&self) -> usize {
        self.inner.num_morphemes()
    }

    /// Get statistics as dict
    fn stats(&self, py: Python<'_>) -> PyResult<PyObject> {
        let stats = self.inner.stats();
        let dict = PyDict::new_bound(py);
        dict.set_item("total_morphemes", stats.total_morphemes)?;
        dict.set_item("basic_pua_codes", stats.basic_pua_codes)?;
        dict.set_item("supplementary_pua_codes", stats.supplementary_pua_codes)?;
        Ok(dict.into())
    }

    fn __repr__(&self) -> String {
        format!("SarfCodec(morphemes={})", self.inner.num_morphemes())
    }

    // =========================================================================
    // Parallel Batch Processing (releases GIL for true parallelism)
    // =========================================================================

    /// Encode a batch of texts in parallel (releases GIL)
    ///
    /// This method processes multiple texts concurrently using Rayon,
    /// providing 3-5x throughput improvement on multi-core systems.
    ///
    /// Args:
    ///     texts: List of texts to encode
    ///     num_threads: Number of threads to use (default: CPU count)
    ///
    /// Returns:
    ///     List of encoded strings in the same order as input
    ///
    /// Example:
    ///     >>> encoded = codec.encode_batch(["الكتاب", "المعلم"], num_threads=8)
    #[pyo3(signature = (texts, num_threads=None))]
    fn encode_batch(
        &self,
        py: Python<'_>,
        texts: Vec<String>,
        num_threads: Option<usize>,
    ) -> Vec<String> {
        // Release the GIL to allow true parallel processing
        py.allow_threads(|| {
            if let Some(n) = num_threads {
                let pool = ThreadPoolBuilder::new()
                    .num_threads(n)
                    .build()
                    .unwrap_or_else(|_| ThreadPoolBuilder::new().build().unwrap());
                pool.install(|| self.inner.encode_batch(&texts))
            } else {
                self.inner.encode_batch(&texts)
            }
        })
    }

    /// Decode a batch of texts in parallel (releases GIL)
    ///
    /// This method processes multiple texts concurrently using Rayon,
    /// providing 3-5x throughput improvement on multi-core systems.
    ///
    /// Args:
    ///     texts: List of encoded texts to decode
    ///     num_threads: Number of threads to use (default: CPU count)
    ///
    /// Returns:
    ///     List of decoded strings in the same order as input
    ///
    /// Example:
    ///     >>> decoded = codec.decode_batch(encoded_texts, num_threads=8)
    #[pyo3(signature = (texts, num_threads=None))]
    fn decode_batch(
        &self,
        py: Python<'_>,
        texts: Vec<String>,
        num_threads: Option<usize>,
    ) -> Vec<String> {
        // Release the GIL to allow true parallel processing
        py.allow_threads(|| {
            if let Some(n) = num_threads {
                let pool = ThreadPoolBuilder::new()
                    .num_threads(n)
                    .build()
                    .unwrap_or_else(|_| ThreadPoolBuilder::new().build().unwrap());
                pool.install(|| self.inner.decode_batch(&texts))
            } else {
                self.inner.decode_batch(&texts)
            }
        })
    }

    /// Roundtrip test a batch of texts in parallel (releases GIL)
    ///
    /// Args:
    ///     texts: List of texts to roundtrip test
    ///     num_threads: Number of threads to use (default: CPU count)
    ///
    /// Returns:
    ///     List of (normalized, decoded, is_consistent) tuples
    #[pyo3(signature = (texts, num_threads=None))]
    fn roundtrip_batch(
        &self,
        py: Python<'_>,
        texts: Vec<String>,
        num_threads: Option<usize>,
    ) -> Vec<(String, String, bool)> {
        py.allow_threads(|| {
            if let Some(n) = num_threads {
                let pool = ThreadPoolBuilder::new()
                    .num_threads(n)
                    .build()
                    .unwrap_or_else(|_| ThreadPoolBuilder::new().build().unwrap());
                pool.install(|| self.inner.roundtrip_batch(&texts))
            } else {
                self.inner.roundtrip_batch(&texts)
            }
        })
    }
}

// =============================================================================
// SuhailTokenizer - Full tokenizer API (backward compatible)
// =============================================================================

/// Python-facing tokenizer class
#[pyclass(name = "SuhailTokenizer")]
pub struct PySuhailTokenizer {
    inner: RustTokenizer,
}

#[pymethods]
impl PySuhailTokenizer {
    /// Create a new tokenizer
    #[new]
    #[pyo3(signature = (vocab=None, merges=None, morpheme_map=None))]
    fn new(
        vocab: Option<HashMap<String, u32>>,
        merges: Option<Vec<(Vec<u8>, Vec<u8>, Vec<u8>)>>,
        morpheme_map: Option<HashMap<String, char>>,
    ) -> PyResult<Self> {
        let vocab = vocab.unwrap_or_default();
        let vocab: HashMap<Vec<u8>, u32> = vocab
            .into_iter()
            .map(|(k, v)| (k.into_bytes(), v))
            .collect();

        let merges = merges
            .unwrap_or_default()
            .into_iter()
            .enumerate()
            .map(|(i, (a, b, r))| suhail_core::tokenizer::MergeRule {
                pair: (a, b),
                result: r,
                rank: i as u32,
            })
            .collect();

        let morpheme_map = morpheme_map.unwrap_or_default();

        let inner = RustTokenizer::new(vocab, merges, morpheme_map)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;

        Ok(Self { inner })
    }

    /// Load tokenizer from directory
    #[staticmethod]
    #[pyo3(signature = (path, license_key=None))]
    fn from_pretrained(path: &str, license_key: Option<&str>) -> PyResult<Self> {
        let inner = RustTokenizer::from_dir(path, license_key)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;

        Ok(Self { inner })
    }

    /// Get vocabulary size
    #[getter]
    fn vocab_size(&self) -> usize {
        self.inner.vocab_size()
    }

    /// Encode text to token IDs
    #[pyo3(signature = (text, add_special_tokens=true))]
    fn encode(&self, text: &str, add_special_tokens: bool) -> PyResult<Vec<u32>> {
        self.inner
            .encode(text, add_special_tokens)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    /// Encode batch of texts
    #[pyo3(signature = (texts, add_special_tokens=true, padding=false))]
    fn encode_batch(
        &self,
        texts: Vec<String>,
        add_special_tokens: bool,
        padding: bool,
    ) -> PyResult<Vec<Vec<u32>>> {
        let mut results: Vec<Vec<u32>> = texts
            .iter()
            .map(|t| self.inner.encode(t, add_special_tokens))
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| PyValueError::new_err(e.to_string()))?;

        // Apply padding if requested
        if padding && !results.is_empty() {
            let max_len = results.iter().map(|r| r.len()).max().unwrap_or(0);
            for result in &mut results {
                while result.len() < max_len {
                    result.push(0); // PAD token
                }
            }
        }

        Ok(results)
    }

    /// Decode token IDs to text
    #[pyo3(signature = (ids, skip_special_tokens=true))]
    fn decode(&self, ids: Vec<u32>, skip_special_tokens: bool) -> PyResult<String> {
        self.inner
            .decode(&ids, skip_special_tokens)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    /// Decode batch of token IDs
    #[pyo3(signature = (batch_ids, skip_special_tokens=true))]
    fn decode_batch(
        &self,
        batch_ids: Vec<Vec<u32>>,
        skip_special_tokens: bool,
    ) -> PyResult<Vec<String>> {
        batch_ids
            .iter()
            .map(|ids| self.inner.decode(ids, skip_special_tokens))
            .collect::<Result<Vec<_>, _>>()
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    /// Tokenize text to subwords
    fn tokenize(&self, text: &str) -> PyResult<Vec<String>> {
        self.inner
            .tokenize(text)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    /// Save tokenizer to directory
    #[pyo3(signature = (path, encrypt=false))]
    fn save_pretrained(&self, path: &str, encrypt: bool) -> PyResult<()> {
        self.inner
            .save(path, encrypt)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    /// Set license key
    fn set_license(&self, key: &str) -> PyResult<()> {
        let license = License::from_key(key)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        self.inner
            .set_license(license)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    /// String representation
    fn __repr__(&self) -> String {
        format!("SuhailTokenizer(vocab_size={})", self.inner.vocab_size())
    }
}

// =============================================================================
// NormalizationConfig
// =============================================================================

/// Python-facing normalization config
#[pyclass(name = "NormalizationConfig")]
#[derive(Clone)]
pub struct PyNormalizationConfig {
    #[pyo3(get, set)]
    normalize_alef: bool,
    #[pyo3(get, set)]
    normalize_taa_marbouta: bool,
    #[pyo3(get, set)]
    normalize_alef_maqsura: bool,
    #[pyo3(get, set)]
    strip_diacritics: bool,
    #[pyo3(get, set)]
    remove_tatweel: bool,
    #[pyo3(get, set)]
    normalize_digits: bool,
}

#[pymethods]
impl PyNormalizationConfig {
    #[new]
    #[pyo3(signature = (
        normalize_alef=false,
        normalize_taa_marbouta=false,
        normalize_alef_maqsura=false,
        strip_diacritics=false,
        remove_tatweel=true,
        normalize_digits=false
    ))]
    fn new(
        normalize_alef: bool,
        normalize_taa_marbouta: bool,
        normalize_alef_maqsura: bool,
        strip_diacritics: bool,
        remove_tatweel: bool,
        normalize_digits: bool,
    ) -> Self {
        Self {
            normalize_alef,
            normalize_taa_marbouta,
            normalize_alef_maqsura,
            strip_diacritics,
            remove_tatweel,
            normalize_digits,
        }
    }
}

impl From<PyNormalizationConfig> for NormalizationConfig {
    fn from(config: PyNormalizationConfig) -> Self {
        Self {
            // Arabic-specific (from Python config)
            normalize_alef: config.normalize_alef,
            normalize_taa_marbouta: config.normalize_taa_marbouta,
            normalize_alef_maqsura: config.normalize_alef_maqsura,
            strip_diacritics: config.strip_diacritics,
            remove_tatweel: config.remove_tatweel,
            normalize_digits: config.normalize_digits,
            // Edge-case hardening (use defaults)
            ..Default::default()
        }
    }
}

// =============================================================================
// Standalone functions
// =============================================================================

/// Encode text with a morpheme map (v2 API)
#[pyfunction]
#[pyo3(signature = (text, morf_map))]
fn encode(text: &str, morf_map: &Bound<'_, PyDict>) -> PyResult<String> {
    let mut map: HashMap<String, String> = HashMap::new();
    for (key, value) in morf_map.iter() {
        let k: String = key.extract()?;
        let v: String = value.extract()?;
        map.insert(k, v);
    }
    Ok(suhail_core::encode(text, &map))
}

/// Decode text with a morpheme map (v2 API)
#[pyfunction]
#[pyo3(signature = (text, morf_map))]
fn decode(text: &str, morf_map: &Bound<'_, PyDict>) -> PyResult<String> {
    let mut map: HashMap<String, String> = HashMap::new();
    for (key, value) in morf_map.iter() {
        let k: String = key.extract()?;
        let v: String = value.extract()?;
        map.insert(k, v);
    }
    Ok(suhail_core::decode(text, &map))
}

/// Normalize Arabic text
#[pyfunction]
#[pyo3(signature = (text, level="medium"))]
fn normalize(text: &str, level: &str) -> String {
    let norm_level = match level {
        "light" => NormalizationLevel::Light,
        "aggressive" => NormalizationLevel::Aggressive,
        _ => NormalizationLevel::Medium,
    };
    suhail_core::normalize_arabic(text, norm_level)
}

/// Check if character is Arabic
#[pyfunction]
fn is_arabic(ch: char) -> bool {
    suhail_core::is_arabic_char(ch)
}

/// Check if character is PUA
#[pyfunction]
fn is_pua(ch: char) -> bool {
    suhail_core::is_pua_char(ch)
}

/// Get version
#[pyfunction]
fn version() -> &'static str {
    suhail_core::VERSION
}

/// Generate machine ID for licensing
#[pyfunction]
fn get_machine_id() -> String {
    License::generate_machine_id()
}

/// Decode GPT-2 style byte-encoded text
#[pyfunction]
fn decode_bytes(text: &str) -> String {
    suhail_core::decode_bytes(text)
}

/// Encrypt a morf_map JSON file to an encrypted .enc file (legacy format)
/// The encrypted file can only be read by this library (no license key needed)
#[pyfunction]
fn encrypt_morf_map(input_json: &str, output_enc: &str) -> PyResult<usize> {
    // Load JSON
    let content = std::fs::read_to_string(input_json)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;

    let morf_map: std::collections::HashMap<String, String> = serde_json::from_str(&content)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid JSON: {}", e)))?;

    let num_morphemes = morf_map.len();

    // Encrypt and save
    let encrypted = suhail_core::EncryptedMorfMap::encrypt(&morf_map)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;

    encrypted.save_to_file(output_enc)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;

    Ok(num_morphemes)
}

/// Encrypt a morf_map JSON file to binary format (.bin)
/// This is the recommended format for strongest IP protection:
/// - No recognizable JSON structure
/// - Raw binary data (33% smaller than base64)
/// - Magic bytes "SARF" only identify file type
///
/// Args:
///     input_json: Path to input JSON file with morpheme map
///     output_bin: Path to output .bin file
///
/// Returns:
///     Number of morphemes in the map
///
/// Example:
///     >>> encrypt_morf_map_binary("morf_map.json", "morf_map.bin")
///     12345
#[pyfunction]
fn encrypt_morf_map_binary(input_json: &str, output_bin: &str) -> PyResult<usize> {
    // Load JSON
    let content = std::fs::read_to_string(input_json)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;

    let morf_map: std::collections::HashMap<String, String> = serde_json::from_str(&content)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid JSON: {}", e)))?;

    let num_morphemes = morf_map.len();

    // Encrypt and save as binary
    let binary = suhail_core::BinaryMorfMap::encrypt(&morf_map)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;

    binary.save_to_file(output_bin)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;

    Ok(num_morphemes)
}

/// Check if a file is a valid binary morf_map (.bin format)
///
/// Args:
///     path: Path to file to check
///
/// Returns:
///     True if file has SARF magic bytes, False otherwise
///
/// Example:
///     >>> is_binary_morf_map("morf_map.bin")
///     True
///     >>> is_binary_morf_map("morf_map.enc")
///     False
#[pyfunction]
fn is_binary_morf_map(path: &str) -> bool {
    suhail_core::is_binary_morf_map(path)
}

/// Convert a .enc file to .bin format
///
/// Args:
///     input_enc: Path to input .enc file
///     output_bin: Path to output .bin file
///
/// Returns:
///     Number of morphemes in the map
#[pyfunction]
fn convert_enc_to_bin(input_enc: &str, output_bin: &str) -> PyResult<usize> {
    // Load .enc file
    let encrypted = suhail_core::EncryptedMorfMap::load_from_file(input_enc)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;

    // Decrypt
    let morf_map = encrypted.decrypt()
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;

    let num_morphemes = morf_map.len();

    // Re-encrypt as binary
    let binary = suhail_core::BinaryMorfMap::encrypt(&morf_map)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(e.to_string()))?;

    binary.save_to_file(output_bin)
        .map_err(|e| PyErr::new::<pyo3::exceptions::PyIOError, _>(e.to_string()))?;

    Ok(num_morphemes)
}

// =============================================================================
// Module definition
// =============================================================================

/// deeplatent._deeplatent - Rust bindings for high-performance Arabic tokenization
#[pymodule]
fn _deeplatent(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Classes
    m.add_class::<PySarfCodec>()?;
    m.add_class::<PySuhailTokenizer>()?;
    m.add_class::<PyNormalizationConfig>()?;

    // Functions
    m.add_function(wrap_pyfunction!(encode, m)?)?;
    m.add_function(wrap_pyfunction!(decode, m)?)?;
    m.add_function(wrap_pyfunction!(normalize, m)?)?;
    m.add_function(wrap_pyfunction!(is_arabic, m)?)?;
    m.add_function(wrap_pyfunction!(is_pua, m)?)?;
    m.add_function(wrap_pyfunction!(version, m)?)?;
    m.add_function(wrap_pyfunction!(get_machine_id, m)?)?;
    m.add_function(wrap_pyfunction!(decode_bytes, m)?)?;
    m.add_function(wrap_pyfunction!(encrypt_morf_map, m)?)?;
    m.add_function(wrap_pyfunction!(encrypt_morf_map_binary, m)?)?;
    m.add_function(wrap_pyfunction!(is_binary_morf_map, m)?)?;
    m.add_function(wrap_pyfunction!(convert_enc_to_bin, m)?)?;

    // Constants
    m.add("__version__", suhail_core::VERSION)?;

    Ok(())
}
