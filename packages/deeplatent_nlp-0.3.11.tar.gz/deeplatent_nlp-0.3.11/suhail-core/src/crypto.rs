//! Cryptography and license management
//!
//! Handles license validation, model encryption, and IP protection.

use crate::{Result, SuhailError};
use aes_gcm::{
    aead::{Aead, KeyInit},
    Aes256Gcm, Nonce,
};
use base64::{engine::general_purpose::STANDARD as BASE64, Engine};
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

/// License tier levels
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum LicenseTier {
    /// Free tier: limited features
    Free,
    /// Standard tier: full features, single machine
    Standard,
    /// Pro tier: full features, multiple machines
    Pro,
    /// Enterprise tier: unlimited
    Enterprise,
}

impl Default for LicenseTier {
    fn default() -> Self {
        Self::Free
    }
}

/// Feature flags based on license tier
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Features {
    /// Maximum vocabulary size
    pub max_vocab_size: usize,
    /// Enable morphology engine
    pub morphology_engine: bool,
    /// Allow custom models
    pub custom_models: bool,
    /// Enable API access
    pub api_access: bool,
    /// Allow offline mode
    pub offline_mode: bool,
}

impl Features {
    /// Get features for a license tier
    pub fn for_tier(tier: LicenseTier) -> Self {
        match tier {
            LicenseTier::Free => Self {
                max_vocab_size: 32_000,
                morphology_engine: false,
                custom_models: false,
                api_access: false,
                offline_mode: false,
            },
            LicenseTier::Standard => Self {
                max_vocab_size: 128_000,
                morphology_engine: true,
                custom_models: false,
                api_access: true,
                offline_mode: true,
            },
            LicenseTier::Pro => Self {
                max_vocab_size: 256_000,
                morphology_engine: true,
                custom_models: true,
                api_access: true,
                offline_mode: true,
            },
            LicenseTier::Enterprise => Self {
                max_vocab_size: usize::MAX,
                morphology_engine: true,
                custom_models: true,
                api_access: true,
                offline_mode: true,
            },
        }
    }
}

/// License information
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct License {
    /// License key
    pub key: String,
    /// License tier
    pub tier: LicenseTier,
    /// Expiration date
    pub expires: DateTime<Utc>,
    /// Bound machine ID
    pub machine_id: String,
    /// Enabled features
    pub features: Features,
    /// Signature for verification
    pub signature: String,
}

impl License {
    /// Create a new license from a license key
    pub fn from_key(key: &str) -> Result<Self> {
        // Parse license key format: SUHAIL-TIER-EXPIRE-MACHINE-SIGNATURE
        let parts: Vec<&str> = key.split('-').collect();

        if parts.len() < 5 || parts[0] != "SUHAIL" {
            return Err(SuhailError::LicenseError("Invalid license format".into()));
        }

        let tier = match parts[1] {
            "FREE" => LicenseTier::Free,
            "STD" => LicenseTier::Standard,
            "PRO" => LicenseTier::Pro,
            "ENT" => LicenseTier::Enterprise,
            _ => return Err(SuhailError::LicenseError("Unknown tier".into())),
        };

        // For now, create a basic license
        // In production, this would decode and verify the full key
        Ok(Self {
            key: key.to_string(),
            tier,
            expires: Utc::now() + chrono::Duration::days(365),
            machine_id: Self::generate_machine_id(),
            features: Features::for_tier(tier),
            signature: parts.last().unwrap_or(&"").to_string(),
        })
    }

    /// Validate the license
    pub fn validate(&self) -> Result<()> {
        // Check expiration
        if Utc::now() > self.expires {
            return Err(SuhailError::LicenseError("License expired".into()));
        }

        // Check machine binding (if not enterprise)
        if self.tier != LicenseTier::Enterprise {
            let current_machine = Self::generate_machine_id();
            if self.machine_id != current_machine {
                return Err(SuhailError::LicenseError("Machine mismatch".into()));
            }
        }

        // Verify signature
        if !self.verify_signature() {
            return Err(SuhailError::LicenseError("Invalid signature".into()));
        }

        Ok(())
    }

    /// Generate machine ID from hardware info
    pub fn generate_machine_id() -> String {
        // Collect machine-specific info
        let mut hasher = Sha256::new();

        // Add hostname
        if let Ok(hostname) = std::env::var("HOSTNAME") {
            hasher.update(hostname.as_bytes());
        }

        // Add username
        if let Ok(user) = std::env::var("USER") {
            hasher.update(user.as_bytes());
        }

        // Add OS info
        hasher.update(std::env::consts::OS.as_bytes());
        hasher.update(std::env::consts::ARCH.as_bytes());

        // Generate hash
        let result = hasher.finalize();
        BASE64.encode(&result[..16])
    }

    /// Verify license signature
    fn verify_signature(&self) -> bool {
        // In production, this would verify against a public key
        // For now, simple hash check
        !self.signature.is_empty()
    }

    /// Check if a feature is enabled
    pub fn has_feature(&self, feature: &str) -> bool {
        match feature {
            "morphology" => self.features.morphology_engine,
            "custom_models" => self.features.custom_models,
            "api" => self.features.api_access,
            "offline" => self.features.offline_mode,
            _ => false,
        }
    }
}

/// Encrypted model container
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EncryptedModel {
    /// Model version
    pub version: String,
    /// Encryption algorithm
    pub algorithm: String,
    /// Initialization vector (base64)
    pub iv: String,
    /// Encrypted data (base64)
    pub data: String,
    /// Signature (base64)
    pub signature: String,
}

impl EncryptedModel {
    /// Encrypt model data
    pub fn encrypt(data: &[u8], key: &[u8; 32]) -> Result<Self> {
        // Generate random IV
        let iv_bytes: [u8; 12] = rand_iv();

        // Create cipher
        let cipher =
            Aes256Gcm::new_from_slice(key).map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        let nonce = Nonce::from_slice(&iv_bytes);

        // Encrypt
        let ciphertext = cipher
            .encrypt(nonce, data)
            .map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        // Sign
        let mut hasher = Sha256::new();
        hasher.update(&ciphertext);
        let signature = hasher.finalize();

        Ok(Self {
            version: "1.0".to_string(),
            algorithm: "AES-256-GCM".to_string(),
            iv: BASE64.encode(iv_bytes),
            data: BASE64.encode(&ciphertext),
            signature: BASE64.encode(&signature[..]),
        })
    }

    /// Decrypt model data
    pub fn decrypt(&self, key: &[u8; 32]) -> Result<Vec<u8>> {
        // Decode IV
        let iv_bytes = BASE64
            .decode(&self.iv)
            .map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        // Decode data
        let ciphertext = BASE64
            .decode(&self.data)
            .map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        // Verify signature
        let mut hasher = Sha256::new();
        hasher.update(&ciphertext);
        let expected_sig = hasher.finalize();
        let actual_sig = BASE64
            .decode(&self.signature)
            .map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        if expected_sig.as_slice() != actual_sig.as_slice() {
            return Err(SuhailError::CryptoError("Invalid signature".into()));
        }

        // Create cipher
        let cipher =
            Aes256Gcm::new_from_slice(key).map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        let nonce = Nonce::from_slice(&iv_bytes);

        // Decrypt
        cipher
            .decrypt(nonce, ciphertext.as_ref())
            .map_err(|e| SuhailError::CryptoError(e.to_string()))
    }

    /// Derive encryption key from license
    pub fn derive_key(license: &License) -> [u8; 32] {
        let mut hasher = Sha256::new();
        hasher.update(license.key.as_bytes());
        hasher.update(license.machine_id.as_bytes());
        hasher.update(b"suhail-model-key-v1");

        let result = hasher.finalize();
        let mut key = [0u8; 32];
        key.copy_from_slice(&result[..32]);
        key
    }
}

/// Generate random IV (simple implementation)
fn rand_iv() -> [u8; 12] {
    use std::time::{SystemTime, UNIX_EPOCH};

    let mut iv = [0u8; 12];
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_nanos();

    for (i, byte) in iv.iter_mut().enumerate() {
        *byte = ((now >> (i * 8)) & 0xFF) as u8;
    }

    iv
}

// =============================================================================
// Embedded Key for Morf Map Encryption (No License Required)
// =============================================================================

/// Embedded encryption key - obfuscated in binary
/// This key is derived at compile time and embedded in the Rust binary.
/// It provides IP protection without requiring users to manage license keys.
fn get_embedded_key() -> [u8; 32] {
    // Obfuscated key components - XOR'd with magic values
    // This makes it harder to find the key in the binary
    const K1: [u8; 8] = [0x53, 0x75, 0x68, 0x61, 0x69, 0x6c, 0x50, 0x4b]; // "SuhailPK"
    const K2: [u8; 8] = [0x47, 0x2d, 0x4d, 0x6f, 0x72, 0x66, 0x4d, 0x61]; // "G-MorfMa"
    const K3: [u8; 8] = [0x70, 0x2d, 0x45, 0x6e, 0x63, 0x72, 0x79, 0x70]; // "p-Encryp"
    const K4: [u8; 8] = [0x74, 0x2d, 0x4b, 0x65, 0x79, 0x2d, 0x56, 0x31]; // "t-Key-V1"

    const MAGIC: [u8; 8] = [0xDE, 0xAD, 0xBE, 0xEF, 0xCA, 0xFE, 0xBA, 0xBE];

    let mut seed = [0u8; 32];
    for i in 0..8 {
        seed[i] = K1[i] ^ MAGIC[i];
        seed[i + 8] = K2[i] ^ MAGIC[7 - i];
        seed[i + 16] = K3[i] ^ MAGIC[i];
        seed[i + 24] = K4[i] ^ MAGIC[7 - i];
    }

    // Derive final key using SHA256
    let mut hasher = Sha256::new();
    hasher.update(&seed);
    hasher.update(b"suhail-morf-map-v1-deeplatent");

    let result = hasher.finalize();
    let mut key = [0u8; 32];
    key.copy_from_slice(&result[..32]);
    key
}

/// Encrypted morf map container
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EncryptedMorfMap {
    /// Format version
    pub version: String,
    /// Encryption algorithm
    pub algorithm: String,
    /// Initialization vector (base64)
    pub iv: String,
    /// Encrypted data (base64)
    pub data: String,
    /// Checksum for integrity (base64)
    pub checksum: String,
    /// Number of morphemes (for info only)
    pub num_morphemes: usize,
}

impl EncryptedMorfMap {
    /// Encrypt a morf map (HashMap<String, String>) using embedded key
    pub fn encrypt(morf_map: &std::collections::HashMap<String, String>) -> Result<Self> {
        let key = get_embedded_key();

        // Serialize morf_map to JSON
        let json_data = serde_json::to_string(morf_map)
            .map_err(|e| SuhailError::CryptoError(format!("Serialization failed: {}", e)))?;

        // Generate random IV
        let iv_bytes: [u8; 12] = rand_iv();

        // Create cipher
        let cipher = Aes256Gcm::new_from_slice(&key)
            .map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        let nonce = Nonce::from_slice(&iv_bytes);

        // Encrypt
        let ciphertext = cipher
            .encrypt(nonce, json_data.as_bytes())
            .map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        // Compute checksum
        let mut hasher = Sha256::new();
        hasher.update(&ciphertext);
        let checksum = hasher.finalize();

        Ok(Self {
            version: "1.0".to_string(),
            algorithm: "AES-256-GCM".to_string(),
            iv: BASE64.encode(iv_bytes),
            data: BASE64.encode(&ciphertext),
            checksum: BASE64.encode(&checksum[..]),
            num_morphemes: morf_map.len(),
        })
    }

    /// Decrypt morf map using embedded key
    pub fn decrypt(&self) -> Result<std::collections::HashMap<String, String>> {
        let key = get_embedded_key();

        // Decode IV
        let iv_bytes = BASE64
            .decode(&self.iv)
            .map_err(|e| SuhailError::CryptoError(format!("Invalid IV: {}", e)))?;

        // Decode data
        let ciphertext = BASE64
            .decode(&self.data)
            .map_err(|e| SuhailError::CryptoError(format!("Invalid data: {}", e)))?;

        // Verify checksum
        let mut hasher = Sha256::new();
        hasher.update(&ciphertext);
        let expected_checksum = hasher.finalize();
        let actual_checksum = BASE64
            .decode(&self.checksum)
            .map_err(|e| SuhailError::CryptoError(format!("Invalid checksum: {}", e)))?;

        if expected_checksum.as_slice() != actual_checksum.as_slice() {
            return Err(SuhailError::CryptoError("Checksum mismatch - file may be corrupted".into()));
        }

        // Create cipher
        let cipher = Aes256Gcm::new_from_slice(&key)
            .map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        let nonce = Nonce::from_slice(&iv_bytes);

        // Decrypt
        let plaintext = cipher
            .decrypt(nonce, ciphertext.as_ref())
            .map_err(|_| SuhailError::CryptoError("Decryption failed - invalid file or wrong library version".into()))?;

        // Parse JSON
        let morf_map: std::collections::HashMap<String, String> = serde_json::from_slice(&plaintext)
            .map_err(|e| SuhailError::CryptoError(format!("Invalid morf map format: {}", e)))?;

        Ok(morf_map)
    }

    /// Save encrypted morf map to file
    pub fn save_to_file<P: AsRef<std::path::Path>>(&self, path: P) -> Result<()> {
        let json = serde_json::to_string_pretty(self)
            .map_err(|e| SuhailError::CryptoError(format!("Serialization failed: {}", e)))?;
        std::fs::write(path, json)?;
        Ok(())
    }

    /// Load encrypted morf map from file
    pub fn load_from_file<P: AsRef<std::path::Path>>(path: P) -> Result<Self> {
        let content = std::fs::read_to_string(path)?;
        let encrypted: Self = serde_json::from_str(&content)
            .map_err(|e| SuhailError::CryptoError(format!("Invalid encrypted file: {}", e)))?;
        Ok(encrypted)
    }
}

// =============================================================================
// Binary Morf Map Format (Enhanced IP Protection)
// =============================================================================

/// Magic bytes identifying SARF binary format
pub const SARF_MAGIC: [u8; 4] = [0x53, 0x41, 0x52, 0x46]; // "SARF"

/// Binary format version
pub const BINARY_FORMAT_VERSION: u16 = 1;

/// Binary morf_map container (IP-protected format)
///
/// File format:
/// ```text
/// Offset  Size   Field           Description
/// ------  ----   -----           -----------
/// 0       4      magic           Magic bytes: 0x53 0x41 0x52 0x46 ("SARF")
/// 4       2      version         Format version (big-endian, currently 0x0001)
/// 6       1      flags           Bit flags (reserved for future use)
/// 7       1      reserved        Reserved byte (0x00)
/// 8       12     iv              AES-GCM initialization vector (raw bytes)
/// 20      4      data_len        Length of encrypted data (big-endian)
/// 24      N      data            Encrypted morpheme map (raw bytes, AES-256-GCM)
/// 24+N    32     checksum        SHA-256 of encrypted data
/// ```
#[derive(Debug, Clone)]
pub struct BinaryMorfMap {
    /// Format version
    version: u16,
    /// Flags (reserved)
    flags: u8,
    /// Initialization vector
    iv: [u8; 12],
    /// Encrypted data (raw AES-256-GCM ciphertext)
    encrypted_data: Vec<u8>,
    /// SHA-256 checksum of encrypted data
    checksum: [u8; 32],
}

impl BinaryMorfMap {
    /// Encrypt a morf map to binary format using embedded key
    pub fn encrypt(morf_map: &std::collections::HashMap<String, String>) -> Result<Self> {
        let key = get_embedded_key();

        // Serialize morf_map to JSON (compact, no whitespace)
        let json_data = serde_json::to_string(morf_map)
            .map_err(|e| SuhailError::CryptoError(format!("Serialization failed: {}", e)))?;

        // Generate random IV
        let iv: [u8; 12] = rand_iv();

        // Create cipher
        let cipher = Aes256Gcm::new_from_slice(&key)
            .map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        let nonce = Nonce::from_slice(&iv);

        // Encrypt
        let encrypted_data = cipher
            .encrypt(nonce, json_data.as_bytes())
            .map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        // Compute checksum of encrypted data
        let mut hasher = Sha256::new();
        hasher.update(&encrypted_data);
        let checksum_result = hasher.finalize();
        let mut checksum = [0u8; 32];
        checksum.copy_from_slice(&checksum_result[..32]);

        Ok(Self {
            version: BINARY_FORMAT_VERSION,
            flags: 0,
            iv,
            encrypted_data,
            checksum,
        })
    }

    /// Decrypt binary morf_map using embedded key
    pub fn decrypt(&self) -> Result<std::collections::HashMap<String, String>> {
        let key = get_embedded_key();

        // Verify checksum
        let mut hasher = Sha256::new();
        hasher.update(&self.encrypted_data);
        let expected_checksum = hasher.finalize();
        if expected_checksum.as_slice() != &self.checksum[..] {
            return Err(SuhailError::CryptoError("Checksum mismatch - file may be corrupted".into()));
        }

        // Create cipher
        let cipher = Aes256Gcm::new_from_slice(&key)
            .map_err(|e| SuhailError::CryptoError(e.to_string()))?;

        let nonce = Nonce::from_slice(&self.iv);

        // Decrypt
        let plaintext = cipher
            .decrypt(nonce, self.encrypted_data.as_ref())
            .map_err(|_| SuhailError::CryptoError("Decryption failed - invalid file or wrong library version".into()))?;

        // Parse JSON
        let morf_map: std::collections::HashMap<String, String> = serde_json::from_slice(&plaintext)
            .map_err(|e| SuhailError::CryptoError(format!("Invalid morf map format: {}", e)))?;

        Ok(morf_map)
    }

    /// Convert to raw bytes
    pub fn to_bytes(&self) -> Vec<u8> {
        let data_len = self.encrypted_data.len() as u32;
        let total_size = 4 + 2 + 1 + 1 + 12 + 4 + self.encrypted_data.len() + 32;
        let mut bytes = Vec::with_capacity(total_size);

        // Magic bytes (4 bytes)
        bytes.extend_from_slice(&SARF_MAGIC);

        // Version (2 bytes, big-endian)
        bytes.extend_from_slice(&self.version.to_be_bytes());

        // Flags (1 byte)
        bytes.push(self.flags);

        // Reserved (1 byte)
        bytes.push(0);

        // IV (12 bytes)
        bytes.extend_from_slice(&self.iv);

        // Data length (4 bytes, big-endian)
        bytes.extend_from_slice(&data_len.to_be_bytes());

        // Encrypted data (N bytes)
        bytes.extend_from_slice(&self.encrypted_data);

        // Checksum (32 bytes)
        bytes.extend_from_slice(&self.checksum);

        bytes
    }

    /// Parse from raw bytes
    pub fn from_bytes(data: &[u8]) -> Result<Self> {
        // Minimum size: 4 + 2 + 1 + 1 + 12 + 4 + 0 + 32 = 56 bytes
        if data.len() < 56 {
            return Err(SuhailError::CryptoError("File too small to be valid binary morf_map".into()));
        }

        // Check magic bytes
        if &data[0..4] != &SARF_MAGIC {
            return Err(SuhailError::CryptoError("Invalid magic bytes - not a SARF binary file".into()));
        }

        // Parse version (big-endian)
        let version = u16::from_be_bytes([data[4], data[5]]);
        if version != BINARY_FORMAT_VERSION {
            return Err(SuhailError::CryptoError(format!(
                "Unsupported binary format version: {} (expected {})",
                version, BINARY_FORMAT_VERSION
            )));
        }

        // Parse flags
        let flags = data[6];

        // Skip reserved byte (data[7])

        // Parse IV
        let mut iv = [0u8; 12];
        iv.copy_from_slice(&data[8..20]);

        // Parse data length (big-endian)
        let data_len = u32::from_be_bytes([data[20], data[21], data[22], data[23]]) as usize;

        // Validate total size
        let expected_size = 24 + data_len + 32;
        if data.len() < expected_size {
            return Err(SuhailError::CryptoError(format!(
                "File truncated: expected {} bytes, got {}",
                expected_size, data.len()
            )));
        }

        // Parse encrypted data
        let encrypted_data = data[24..24 + data_len].to_vec();

        // Parse checksum
        let mut checksum = [0u8; 32];
        checksum.copy_from_slice(&data[24 + data_len..24 + data_len + 32]);

        Ok(Self {
            version,
            flags,
            iv,
            encrypted_data,
            checksum,
        })
    }

    /// Save to binary file (.bin)
    pub fn save_to_file<P: AsRef<std::path::Path>>(&self, path: P) -> Result<()> {
        let bytes = self.to_bytes();
        std::fs::write(path, bytes)?;
        Ok(())
    }

    /// Load from binary file (.bin)
    pub fn load_from_file<P: AsRef<std::path::Path>>(path: P) -> Result<Self> {
        let bytes = std::fs::read(path)?;
        Self::from_bytes(&bytes)
    }

    /// Get format version
    pub fn version(&self) -> u16 {
        self.version
    }

    /// Get number of morphemes (requires decryption)
    pub fn num_morphemes(&self) -> Result<usize> {
        let map = self.decrypt()?;
        Ok(map.len())
    }
}

/// Check if a file is a valid binary morf_map by checking magic bytes
pub fn is_binary_morf_map<P: AsRef<std::path::Path>>(path: P) -> bool {
    std::fs::read(path.as_ref())
        .map(|data| data.len() >= 4 && data[0..4] == SARF_MAGIC)
        .unwrap_or(false)
}

/// Check if data bytes represent a binary morf_map
pub fn is_binary_morf_map_bytes(data: &[u8]) -> bool {
    data.len() >= 4 && data[0..4] == SARF_MAGIC
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_license_from_key() {
        let license = License::from_key("SUHAIL-STD-20251231-ABC123-SIG").unwrap();
        assert_eq!(license.tier, LicenseTier::Standard);
    }

    #[test]
    fn test_features_for_tier() {
        let free = Features::for_tier(LicenseTier::Free);
        assert_eq!(free.max_vocab_size, 32_000);
        assert!(!free.morphology_engine);

        let pro = Features::for_tier(LicenseTier::Pro);
        assert!(pro.morphology_engine);
        assert!(pro.custom_models);
    }

    #[test]
    fn test_encrypt_decrypt() {
        let data = b"Hello, World!";
        let key = [0u8; 32];

        let encrypted = EncryptedModel::encrypt(data, &key).unwrap();
        let decrypted = encrypted.decrypt(&key).unwrap();

        assert_eq!(decrypted, data);
    }

    #[test]
    fn test_morf_map_encrypt_decrypt() {
        use std::collections::HashMap;

        let mut morf_map: HashMap<String, String> = HashMap::new();
        morf_map.insert("ال".to_string(), "\u{E000}".to_string());
        morf_map.insert("كتاب".to_string(), "\u{E001}".to_string());
        morf_map.insert("معلم".to_string(), "\u{E002}".to_string());

        let encrypted = EncryptedMorfMap::encrypt(&morf_map).unwrap();
        assert_eq!(encrypted.num_morphemes, 3);

        let decrypted = encrypted.decrypt().unwrap();
        assert_eq!(decrypted.len(), 3);
        assert_eq!(decrypted.get("ال").unwrap(), "\u{E000}");
        assert_eq!(decrypted.get("كتاب").unwrap(), "\u{E001}");
    }

    #[test]
    fn test_embedded_key_consistency() {
        // Ensure key is always the same
        let key1 = get_embedded_key();
        let key2 = get_embedded_key();
        assert_eq!(key1, key2);
    }

    #[test]
    fn test_binary_morf_map_encrypt_decrypt() {
        use std::collections::HashMap;

        let mut morf_map: HashMap<String, String> = HashMap::new();
        morf_map.insert("ال".to_string(), "\u{E000}".to_string());
        morf_map.insert("كتاب".to_string(), "\u{E001}".to_string());
        morf_map.insert("معلم".to_string(), "\u{E002}".to_string());

        let binary = BinaryMorfMap::encrypt(&morf_map).unwrap();
        assert_eq!(binary.version(), BINARY_FORMAT_VERSION);

        let decrypted = binary.decrypt().unwrap();
        assert_eq!(decrypted.len(), 3);
        assert_eq!(decrypted.get("ال").unwrap(), "\u{E000}");
        assert_eq!(decrypted.get("كتاب").unwrap(), "\u{E001}");
    }

    #[test]
    fn test_binary_morf_map_bytes_roundtrip() {
        use std::collections::HashMap;

        let mut morf_map: HashMap<String, String> = HashMap::new();
        morf_map.insert("ال".to_string(), "\u{E000}".to_string());
        morf_map.insert("كتاب".to_string(), "\u{E001}".to_string());

        let binary = BinaryMorfMap::encrypt(&morf_map).unwrap();
        let bytes = binary.to_bytes();

        // Verify magic bytes
        assert_eq!(&bytes[0..4], &SARF_MAGIC);

        // Verify version (big-endian)
        assert_eq!(u16::from_be_bytes([bytes[4], bytes[5]]), BINARY_FORMAT_VERSION);

        // Parse back
        let parsed = BinaryMorfMap::from_bytes(&bytes).unwrap();
        let decrypted = parsed.decrypt().unwrap();
        assert_eq!(decrypted.len(), 2);
        assert_eq!(decrypted.get("ال").unwrap(), "\u{E000}");
    }

    #[test]
    fn test_binary_morf_map_file_roundtrip() {
        use std::collections::HashMap;
        use tempfile::NamedTempFile;

        let mut morf_map: HashMap<String, String> = HashMap::new();
        morf_map.insert("ال".to_string(), "\u{E000}".to_string());
        morf_map.insert("كتاب".to_string(), "\u{E001}".to_string());

        let binary = BinaryMorfMap::encrypt(&morf_map).unwrap();

        // Save to temp file
        let temp_file = NamedTempFile::new().unwrap();
        binary.save_to_file(temp_file.path()).unwrap();

        // Verify it's recognized as binary
        assert!(is_binary_morf_map(temp_file.path()));

        // Load and verify
        let loaded = BinaryMorfMap::load_from_file(temp_file.path()).unwrap();
        let decrypted = loaded.decrypt().unwrap();
        assert_eq!(decrypted.len(), 2);
    }

    #[test]
    fn test_binary_morf_map_not_json() {
        use std::collections::HashMap;

        let mut morf_map: HashMap<String, String> = HashMap::new();
        morf_map.insert("ال".to_string(), "\u{E000}".to_string());

        let binary = BinaryMorfMap::encrypt(&morf_map).unwrap();
        let bytes = binary.to_bytes();

        // Verify file doesn't contain readable JSON metadata
        let content = String::from_utf8_lossy(&bytes);
        assert!(!content.contains("\"version\""));
        assert!(!content.contains("\"algorithm\""));
        assert!(!content.contains("\"iv\""));
        assert!(!content.contains("\"data\""));
    }

    #[test]
    fn test_binary_vs_enc_size() {
        use std::collections::HashMap;

        let mut morf_map: HashMap<String, String> = HashMap::new();
        for i in 0..1000 {
            morf_map.insert(format!("morph{}", i), format!("\u{E000}"));
        }

        // Create binary format
        let binary = BinaryMorfMap::encrypt(&morf_map).unwrap();
        let binary_bytes = binary.to_bytes();

        // Create JSON .enc format
        let enc = EncryptedMorfMap::encrypt(&morf_map).unwrap();
        let enc_json = serde_json::to_string(&enc).unwrap();

        // Binary should be smaller (no base64 overhead, no JSON structure)
        // Note: Actual size depends on compression, but binary avoids ~33% base64 overhead
        println!("Binary size: {} bytes", binary_bytes.len());
        println!("JSON .enc size: {} bytes", enc_json.len());

        // At minimum, binary shouldn't be larger
        assert!(binary_bytes.len() <= enc_json.len() + 100); // Allow small margin for small maps
    }

    #[test]
    fn test_is_binary_morf_map_bytes() {
        // Valid magic
        let valid = [0x53, 0x41, 0x52, 0x46, 0x00, 0x01];
        assert!(is_binary_morf_map_bytes(&valid));

        // Invalid magic
        let invalid = [0x7B, 0x22, 0x76, 0x65]; // {"ve (start of JSON)
        assert!(!is_binary_morf_map_bytes(&invalid));

        // Too short
        let short = [0x53, 0x41];
        assert!(!is_binary_morf_map_bytes(&short));
    }
}
