//! Smart decoder with all edge case handling
//!
//! Implements the complete SARF decoder pipeline:
//! 1. Byte decoding (GPT-2 style)
//! 2. PUA reversal (PUA -> morphemes)
//! 3. Post-processing (9-step Arabic text cleanup)
//! 4. Pattern restoration (URLs, emails, paths)

use crate::grapheme::is_emoji_sequence;
use crate::trie::ByteTrie;
use lazy_static::lazy_static;
use regex::Regex;
use std::collections::{HashMap, HashSet};
use unicode_segmentation::UnicodeSegmentation;

// =============================================================================
// Constants
// =============================================================================

/// Arabic diacritics (harakat)
pub const DIACRITICS: &[char] = &[
    '\u{064B}', // fathatan
    '\u{064C}', // dammatan
    '\u{064D}', // kasratan
    '\u{064E}', // fatha
    '\u{064F}', // damma
    '\u{0650}', // kasra
    '\u{0651}', // shadda
    '\u{0652}', // sukun
    '\u{0653}', // maddah above
    '\u{0654}', // hamza above
    '\u{0655}', // hamza below
    '\u{0670}', // superscript alef
];

/// Two-character Arabic suffixes (pronominal and grammatical)
pub const SUFFIX_PAIRS: &[&str] = &[
    // Pronominal suffixes
    "ها", // ha (her/it f.)
    "هم", // hum (their m.)
    "هن", // hunna (their f.)
    "كم", // kum (your m.pl.)
    "كن", // kunna (your f.pl.)
    "نا", // na (our)
    "ني", // ni (me - accusative)
    "ته", // tahu (you did to him)
    "تك", // tuka (you did to you)
    // Grammatical suffixes
    "ون", // una (m.pl. nominative)
    "ين", // ina (m.pl. accusative/genitive)
    "ات", // at (f.pl.)
    "وا", // u (past tense m.pl.)
    "تم", // tum (you m.pl. past)
    "تن", // tunna (you f.pl. past)
    "يم", // im (plural marker)
    "ية", // iyya (nisba feminine)
    "ان", // an (dual nominative)
    "تا", // ta (dual feminine)
    "وه", // uhu (imperative + him)
    "اه", // ahu (accusative + him)
];

/// Single-character suffix letters
pub const SUFFIX_SINGLES: &[char] = &[
    'ك', // ka (your m.s.)
    'ه', // hu (his)
    'ي', // i (my)
    'ن', // n (feminine plural marker)
    'م', // m (plural marker)
    'ت', // t (feminine/2nd person marker)
    'ة', // ta marbuta (feminine marker)
];

/// Arabic prefixes (for reference - used in post-processing)
pub const ARABIC_PREFIXES: &[&str] = &[
    "ال",   // al - definite article (the)
    "و",    // wa - conjunction (and)
    "ف",    // fa - conjunction (so/then)
    "ب",    // bi - preposition (with/by/at)
    "ل",    // li - preposition (for/to)
    "ك",    // ka - preposition (like/as)
    "س",    // sa - future tense marker
    "سوف",  // sawfa - future tense particle (long form)
    "لل",   // lil - for the (li + al)
    "وال",  // wal - and the (wa + al)
    "فال",  // fal - so the (fa + al)
    "بال",  // bal - with the (bi + al)
    "كال",  // kal - like the (ka + al)
];

// =============================================================================
// Lazy static regex patterns
// =============================================================================

lazy_static! {
    /// Diacritics set for fast lookup
    static ref DIACRITICS_SET: HashSet<char> = DIACRITICS.iter().cloned().collect();

    /// Suffix pairs set
    static ref SUFFIX_PAIRS_SET: HashSet<&'static str> = SUFFIX_PAIRS.iter().cloned().collect();

    // Regex patterns for post-processing

    /// Multiple spaces
    static ref RE_MULTI_SPACE: Regex = Regex::new(r"  +").unwrap();

    /// Step 2: letter + space + diacritic
    static ref RE_LETTER_SPACE_DIAC: Regex =
        Regex::new(r"([\u{0621}-\u{064A}\u{066E}-\u{06D3}]) ([\u{064B}-\u{0655}\u{0670}])").unwrap();

    /// Step 3: diacritic + space + diacritic
    static ref RE_DIAC_SPACE_DIAC: Regex =
        Regex::new(r"([\u{064B}-\u{0655}\u{0670}]) ([\u{064B}-\u{0655}\u{0670}])").unwrap();

    /// Step 4: diacritic + space + letters + diacritic
    static ref RE_DIAC_SPACE_LETTERS_DIAC: Regex =
        Regex::new(r"([\u{064B}-\u{0655}\u{0670}]) ([\u{0621}-\u{064A}\u{066E}-\u{06D3}]+)([\u{064B}-\u{0655}\u{0670}])").unwrap();

    /// Step 5: diacritic + space + letters at word end (not starting with alef)
    /// Note: Rust regex doesn't support lookahead, so we match and preserve trailing space
    static ref RE_DIAC_SPACE_LETTERS_END: Regex =
        Regex::new(r"([\u{064B}-\u{0655}\u{0670}]) ([^\u{0627}\s][\u{0621}-\u{064A}\u{066E}-\u{06D3}]*)(\s|$)").unwrap();

    /// Step 6: STANDALONE definite article "ال" + space + letter
    /// Only matches when "ال" is at start of string or preceded by space/non-Arabic
    static ref RE_AL_SPACE_LETTER: Regex =
        Regex::new(r"(^|[\s\x00-\x7F])(ال) ([\u{0621}-\u{064A}\u{066E}-\u{06D3}])").unwrap();

    /// Step 6b: Common STANDALONE single-letter prefixes + space + word
    /// Only matches when prefix is preceded by start/space/non-Arabic AND followed by ال or Arabic letter
    /// This is very conservative - only join "و ال" -> "وال", etc.
    static ref RE_PREFIX_SPACE_AL: Regex =
        Regex::new(r"(^|[\s\x00-\x7F])([وفبلكس]) (ال[\u{0621}-\u{064A}\u{066E}-\u{06D3}])").unwrap();

    /// Step 6c: Combined prefixes + ال + space + word
    /// Handles STANDALONE وال فال بال لل كال
    static ref RE_COMBO_PREFIX_AL: Regex =
        Regex::new(r"(^|[\s\x00-\x7F])(وال|فال|بال|لل|كال) ([\u{0621}-\u{064A}\u{066E}-\u{06D3}])").unwrap();

    /// Step 9a: space before period/question mark only
    /// Note: We preserve spaces before other punctuation (commas, exclamation marks)
    /// as some typographic styles and languages use space before these
    static ref RE_SPACE_PUNCT: Regex = Regex::new(r" ([.?؟])").unwrap();

    /// Step 9b: digit + space + digit
    static ref RE_DIGIT_SPACE_DIGIT: Regex = Regex::new(r"([0-9٠-٩]) ([0-9٠-٩])").unwrap();

    /// Step 9c: email @ handling
    static ref RE_EMAIL_AT: Regex = Regex::new(r" ?@ ?").unwrap();

    /// Step 9d: URL protocol
    static ref RE_URL_PROTO: Regex = Regex::new(r" ?: ?// ?").unwrap();

    /// Step 9e: domain extension
    static ref RE_DOMAIN_EXT: Regex = Regex::new(r" ?\. ?([a-zA-Z]{2,})(\s|$)").unwrap();
}

// =============================================================================
// Byte Decoder (GPT-2 style)
// =============================================================================

/// Build the GPT-2 style byte decoder mapping
fn build_byte_decoder() -> HashMap<char, u8> {
    let mut bs: Vec<u8> = Vec::new();

    // Printable ASCII
    bs.extend(b'!'..=b'~');
    // Latin-1 supplement (printable part)
    bs.extend(0xA1u8..=0xACu8);
    bs.extend(0xAEu8..=0xFFu8);

    let mut cs: Vec<u32> = bs.iter().map(|&b| b as u32).collect();

    let mut n = 0u32;
    for b in 0u8..=255u8 {
        if !bs.contains(&b) {
            bs.push(b);
            cs.push(256 + n);
            n += 1;
        }
    }

    // Create decoder: char -> byte
    let mut decoder = HashMap::new();
    for (b, c) in bs.iter().zip(cs.iter()) {
        if let Some(ch) = char::from_u32(*c) {
            decoder.insert(ch, *b);
        }
    }

    decoder
}

/// Decode GPT-2 style byte-encoded text
///
/// GPT-2 uses a byte-level encoding where some bytes are represented as
/// special Unicode characters (U+0100+). This function reverses that encoding.
///
/// For characters that are already in their natural form (like « » and other
/// Latin-1 characters), we preserve them as-is.
pub fn decode_bytes(text: &str) -> String {
    lazy_static! {
        static ref BYTE_DECODER: HashMap<char, u8> = build_byte_decoder();
    }

    let mut result = String::with_capacity(text.len());

    for ch in text.chars() {
        // Check if this is a GPT-2 special byte character (U+0100+)
        // These are the characters that need to be decoded back to bytes
        let cp = ch as u32;
        if cp >= 256 {
            // This might be a GPT-2 special character
            if let Some(&byte) = BYTE_DECODER.get(&ch) {
                // Decode the byte back to its character representation
                if byte < 0x80 {
                    // ASCII - safe to push directly
                    result.push(byte as char);
                } else {
                    // Non-ASCII byte - need to decode as Latin-1
                    result.push(char::from_u32(byte as u32).unwrap_or(ch));
                }
            } else {
                // Not in byte decoder - keep as-is
                result.push(ch);
            }
        } else {
            // Regular character (ASCII or Latin-1) - keep as-is
            result.push(ch);
        }
    }

    result
}

// =============================================================================
// Decoder Configuration
// =============================================================================

/// Configuration for the robust decoder
#[derive(Debug, Clone)]
pub struct DecoderConfig {
    /// Whether to apply byte decoding (GPT-2 style)
    pub apply_byte_decoding: bool,

    /// Whether to apply post-processing
    pub apply_post_processing: bool,

    /// Whether to normalize URLs in output
    pub normalize_urls: bool,

    /// Whether to normalize emails in output
    pub normalize_emails: bool,

    /// Whether to preserve grapheme clusters (emoji, flags)
    pub preserve_grapheme_clusters: bool,

    /// Whether to clean up whitespace around patterns
    pub clean_pattern_whitespace: bool,
}

impl Default for DecoderConfig {
    fn default() -> Self {
        Self {
            apply_byte_decoding: true,
            apply_post_processing: true,
            normalize_urls: true,
            normalize_emails: true,
            preserve_grapheme_clusters: false,
            clean_pattern_whitespace: true,
        }
    }
}

impl DecoderConfig {
    /// Create a minimal config (just PUA reversal)
    pub fn minimal() -> Self {
        Self {
            apply_byte_decoding: false,
            apply_post_processing: false,
            normalize_urls: false,
            normalize_emails: false,
            preserve_grapheme_clusters: false,
            clean_pattern_whitespace: false,
        }
    }

    /// Create a robust config with all features
    pub fn robust() -> Self {
        Self {
            apply_byte_decoding: true,
            apply_post_processing: true,
            normalize_urls: true,
            normalize_emails: true,
            preserve_grapheme_clusters: true,
            clean_pattern_whitespace: true,
        }
    }
}

// =============================================================================
// Smart Decoder
// =============================================================================

/// Complete SARF decoder with all edge case handling
#[derive(Debug, Clone)]
pub struct SmartDecoder {
    /// Trie for efficient PUA replacement
    reverse_trie: ByteTrie,
    /// Decoder configuration
    config: DecoderConfig,
}

impl SmartDecoder {
    /// Create a new decoder from reverse morpheme map (PUA char -> morpheme string)
    /// Used by SuhailTokenizer
    pub fn new(reverse_map: HashMap<char, String>) -> Self {
        let string_map: HashMap<String, String> = reverse_map
            .into_iter()
            .map(|(k, v)| (k.to_string(), v))
            .collect();
        let reverse_trie = ByteTrie::from_map(&string_map);
        Self {
            reverse_trie,
            config: DecoderConfig::default(),
        }
    }

    /// Create from string-keyed reverse map (PUA string -> morpheme string)
    pub fn from_string_map(reverse_map: HashMap<String, String>) -> Self {
        let reverse_trie = ByteTrie::from_map(&reverse_map);
        Self {
            reverse_trie,
            config: DecoderConfig::default(),
        }
    }

    /// Create from forward morpheme map (morpheme -> PUA)
    pub fn from_forward_map(morf_map: &HashMap<String, String>) -> Self {
        let reverse_map: HashMap<String, String> =
            morf_map.iter().map(|(k, v)| (v.clone(), k.clone())).collect();
        Self::from_string_map(reverse_map)
    }

    /// Create with custom configuration
    pub fn with_config(reverse_map: HashMap<String, String>, config: DecoderConfig) -> Self {
        let reverse_trie = ByteTrie::from_map(&reverse_map);
        Self {
            reverse_trie,
            config,
        }
    }

    /// Get the decoder configuration
    pub fn config(&self) -> &DecoderConfig {
        &self.config
    }

    /// Set the decoder configuration
    pub fn set_config(&mut self, config: DecoderConfig) {
        self.config = config;
    }

    /// Complete decode pipeline
    pub fn decode(&self, raw_output: &str) -> String {
        // Step 1: Decode bytes (GPT-2 style)
        let text = if self.config.apply_byte_decoding {
            decode_bytes(raw_output)
        } else {
            raw_output.to_string()
        };

        // Step 2: Reverse PUA codes to morphemes
        let text = if self.config.preserve_grapheme_clusters {
            self.reverse_pua_preserve_graphemes(&text)
        } else {
            self.reverse_pua(&text)
        };

        // Step 3: Post-process Arabic text
        if self.config.apply_post_processing {
            self.post_process(&text)
        } else {
            text
        }
    }

    /// Decode with robust pattern handling
    pub fn decode_robust(&self, raw_output: &str) -> String {
        // Step 1: Decode bytes (GPT-2 style)
        let text = if self.config.apply_byte_decoding {
            decode_bytes(raw_output)
        } else {
            raw_output.to_string()
        };

        // Step 2: Reverse PUA codes to morphemes (preserving emoji)
        let text = if self.config.preserve_grapheme_clusters {
            self.reverse_pua_preserve_graphemes(&text)
        } else {
            self.reverse_pua(&text)
        };

        // Step 3: Post-process Arabic text
        let text = if self.config.apply_post_processing {
            self.post_process(&text)
        } else {
            text
        };

        // Step 4: Additional pattern cleanup
        self.cleanup_patterns(&text)
    }

    /// Replace PUA characters with morphemes using trie
    fn reverse_pua(&self, text: &str) -> String {
        if self.reverse_trie.is_empty() {
            return text.to_string();
        }
        self.reverse_trie.rewrite_text(text)
    }

    /// Replace PUA characters while preserving emoji grapheme clusters
    fn reverse_pua_preserve_graphemes(&self, text: &str) -> String {
        if self.reverse_trie.is_empty() {
            return text.to_string();
        }

        let mut result = String::with_capacity(text.len());
        let mut current_segment = String::new();

        for grapheme in text.graphemes(true) {
            if is_emoji_sequence(grapheme) {
                // Flush current segment through PUA reversal
                if !current_segment.is_empty() {
                    result.push_str(&self.reverse_trie.rewrite_text(&current_segment));
                    current_segment.clear();
                }
                // Append emoji directly
                result.push_str(grapheme);
            } else {
                current_segment.push_str(grapheme);
            }
        }

        // Flush remaining segment
        if !current_segment.is_empty() {
            result.push_str(&self.reverse_trie.rewrite_text(&current_segment));
        }

        result
    }

    /// Clean up patterns (URLs, emails) after decoding
    fn cleanup_patterns(&self, text: &str) -> String {
        let mut result = text.to_string();

        if self.config.normalize_urls {
            // Fix common URL tokenization artifacts
            result = result.replace(" : // ", "://");
            result = result.replace(": //", "://");
            result = result.replace(" ://", "://");
            result = result.replace(":// ", "://");
        }

        if self.config.normalize_emails {
            // Fix common email tokenization artifacts
            result = result.replace(" @ ", "@");
            result = result.replace("@ ", "@");
            result = result.replace(" @", "@");
        }

        if self.config.clean_pattern_whitespace {
            // Clean up spaces around dots in domain names
            // But be careful not to break Arabic text
            let domain_ext_fix = Regex::new(r"\s*\.\s*(com|org|net|edu|gov|io|co|uk|de|fr|sa|ae|eg)(\s|$)").unwrap();
            result = domain_ext_fix.replace_all(&result, ".$1$2").to_string();
        }

        result
    }

    /// Smart post-processing preserving word boundaries
    /// Implements all 9 steps from SARF decoder
    fn post_process(&self, text: &str) -> String {
        // Step 1: Collapse multiple spaces
        let mut text = RE_MULTI_SPACE.replace_all(text, " ").to_string();
        text = text.trim().to_string();

        if text.is_empty() {
            return text;
        }

        // Step 2: Join letter + space + diacritic (always safe)
        for _ in 0..15 {
            let prev = text.clone();
            text = RE_LETTER_SPACE_DIAC.replace_all(&text, "$1$2").to_string();
            if text == prev {
                break;
            }
        }

        // Step 3: Join diacritic + space + diacritic (always safe)
        for _ in 0..10 {
            let prev = text.clone();
            text = RE_DIAC_SPACE_DIAC.replace_all(&text, "$1$2").to_string();
            if text == prev {
                break;
            }
        }

        // NOTE: Steps 4-8 (prefix/suffix joining) are DISABLED for SarfCodec
        // These rules were designed for BPE tokenizer output reconstruction where:
        // - BPE might split "الكتاب" into "ال" + " " + "كتاب"
        // - The decoder would then need to rejoin: "ال كتاب" → "الكتاب"
        //
        // However, for general PUA encode/decode (SarfCodec), these rules are too
        // aggressive and incorrectly join separate words. For example:
        // - "إل شآحفو" normalizes to "ال شاحفو" (two separate fragments)
        // - Without disabling, decoder would join: "ال شاحفو" → "الشاحفو" (wrong!)
        //
        // The safe rules that remain are:
        // - Steps 2-3: diacritic joining (always safe within same word)
        // - Step 9: punctuation/digit/URL cleanup (standard text normalization)

        // Step 9: Standard cleanup

        // 9a: Remove space before punctuation
        text = RE_SPACE_PUNCT.replace_all(&text, "$1").to_string();

        // 9b: Join digits
        for _ in 0..5 {
            let prev = text.clone();
            text = RE_DIGIT_SPACE_DIGIT.replace_all(&text, "$1$2").to_string();
            if text == prev {
                break;
            }
        }

        // 9c: Email @ handling
        text = RE_EMAIL_AT.replace_all(&text, "@").to_string();

        // 9d: URL protocol
        text = RE_URL_PROTO.replace_all(&text, "://").to_string();

        // 9e: Domain extension
        text = RE_DOMAIN_EXT.replace_all(&text, ".$1$2").to_string();

        // Final cleanup
        text = RE_MULTI_SPACE.replace_all(&text, " ").to_string();
        text.trim().to_string()
    }
}

impl Default for SmartDecoder {
    fn default() -> Self {
        Self::new(HashMap::new())
    }
}

// =============================================================================
// Greedy Decoder (alternative simpler decoder)
// =============================================================================

/// Simple greedy decoder without post-processing
pub struct GreedyDecoder {
    reverse_trie: ByteTrie,
}

impl GreedyDecoder {
    pub fn new(reverse_map: HashMap<String, String>) -> Self {
        Self {
            reverse_trie: ByteTrie::from_map(&reverse_map),
        }
    }

    pub fn decode(&self, text: &str) -> String {
        let decoded = decode_bytes(text);
        self.reverse_trie.rewrite_text(&decoded)
    }
}

// =============================================================================
// Tests
// =============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    // =========================================================================
    // Existing tests (backward compatibility)
    // =========================================================================

    #[test]
    fn test_byte_decoder() {
        let text = "hello";
        let decoded = decode_bytes(text);
        assert_eq!(decoded, "hello");
    }

    #[test]
    fn test_multi_space_collapse() {
        let decoder = SmartDecoder::default();
        let result = decoder.post_process("hello   world");
        assert_eq!(result, "hello world");
    }

    #[test]
    fn test_letter_diacritic_join() {
        let decoder = SmartDecoder::default();
        // Letter + space + diacritic should join
        let result = decoder.post_process("ب \u{064E}"); // ba + fatha
        assert_eq!(result, "ب\u{064E}");
    }

    #[test]
    fn test_definite_article_no_aggressive_join() {
        let decoder = SmartDecoder::default();
        // Definite article joining is disabled to prevent incorrect merges
        // "ال كتاب" should NOT be auto-joined (could be separate words)
        let result = decoder.post_process("ال كتاب");
        assert_eq!(result, "ال كتاب");
    }

    #[test]
    fn test_suffix_no_aggressive_join() {
        let decoder = SmartDecoder::default();
        // Word + space + suffix should NOT be joined automatically
        // (too aggressive - would merge separate words incorrectly)
        // Suffix joining is disabled to preserve word boundaries
        let result = decoder.post_process("كتاب ها");
        assert_eq!(result, "كتاب ها");
    }

    #[test]
    fn test_punctuation() {
        let decoder = SmartDecoder::default();
        let result = decoder.post_process("hello .");
        assert_eq!(result, "hello.");
    }

    #[test]
    fn test_email_preservation() {
        let decoder = SmartDecoder::default();
        let result = decoder.post_process("email @ example . com");
        assert_eq!(result, "email@example.com");
    }

    #[test]
    fn test_url_preservation() {
        let decoder = SmartDecoder::default();
        let result = decoder.post_process("https : // example . com");
        assert_eq!(result, "https://example.com");
    }

    #[test]
    fn test_pua_reversal() {
        let mut reverse_map = HashMap::new();
        reverse_map.insert("\u{E000}".to_string(), "ال".to_string());
        reverse_map.insert("\u{E001}".to_string(), "كتاب".to_string());

        let decoder = SmartDecoder::from_string_map(reverse_map);
        let result = decoder.decode("\u{E000}\u{E001}");
        assert_eq!(result, "الكتاب");
    }

    #[test]
    fn test_digit_joining() {
        let decoder = SmartDecoder::default();
        let result = decoder.post_process("1 2 3 4 5");
        assert_eq!(result, "12345");
    }

    #[test]
    fn test_arabic_indic_digits() {
        let decoder = SmartDecoder::default();
        let result = decoder.post_process("٠ ١ ٢ ٣ ٤");
        assert_eq!(result, "٠١٢٣٤");
    }

    // =========================================================================
    // New edge case tests
    // =========================================================================

    #[test]
    fn test_decoder_config_default() {
        let config = DecoderConfig::default();
        assert!(config.apply_byte_decoding);
        assert!(config.apply_post_processing);
        assert!(config.normalize_urls);
        assert!(config.normalize_emails);
    }

    #[test]
    fn test_decoder_config_minimal() {
        let config = DecoderConfig::minimal();
        assert!(!config.apply_byte_decoding);
        assert!(!config.apply_post_processing);
    }

    #[test]
    fn test_decoder_config_robust() {
        let config = DecoderConfig::robust();
        assert!(config.preserve_grapheme_clusters);
        assert!(config.clean_pattern_whitespace);
    }

    #[test]
    fn test_decode_with_config() {
        let mut reverse_map = HashMap::new();
        reverse_map.insert("\u{E000}".to_string(), "ال".to_string());

        let config = DecoderConfig {
            apply_post_processing: false,
            ..Default::default()
        };
        let decoder = SmartDecoder::with_config(reverse_map, config);

        // Without post-processing, spaces should be preserved
        let result = decoder.decode("\u{E000}   ");
        assert!(result.ends_with("   ")); // Trailing spaces preserved
    }

    #[test]
    fn test_decode_robust_url_cleanup() {
        let config = DecoderConfig::robust();
        let decoder = SmartDecoder::with_config(HashMap::new(), config);

        // Simulate tokenized URL
        let result = decoder.decode_robust("Visit https : // example . com");
        assert!(result.contains("https://example.com"));
    }

    #[test]
    fn test_decode_robust_email_cleanup() {
        let config = DecoderConfig::robust();
        let decoder = SmartDecoder::with_config(HashMap::new(), config);

        // Simulate tokenized email
        let result = decoder.decode_robust("Contact user @ example . com");
        assert!(result.contains("user@example.com"));
    }

    #[test]
    fn test_decode_preserve_emoji() {
        let mut reverse_map = HashMap::new();
        reverse_map.insert("\u{E000}".to_string(), "مرحبا".to_string());

        let config = DecoderConfig {
            preserve_grapheme_clusters: true,
            ..Default::default()
        };
        let decoder = SmartDecoder::with_config(reverse_map, config);

        // Decode text with emoji
        let result = decoder.decode("\u{E000} 👨‍👩‍👧‍👦");
        assert!(result.contains("مرحبا"));
        assert!(result.contains("👨‍👩‍👧‍👦"));
    }

    #[test]
    fn test_decode_empty_string() {
        let decoder = SmartDecoder::default();
        assert_eq!(decoder.decode(""), "");
        assert_eq!(decoder.decode_robust(""), "");
    }

    #[test]
    fn test_decode_whitespace_only() {
        let decoder = SmartDecoder::default();
        // Whitespace-only input should collapse to empty
        let result = decoder.decode("   ");
        assert_eq!(result, "");
    }

    #[test]
    fn test_cleanup_patterns_domain_extensions() {
        let config = DecoderConfig::robust();
        let decoder = SmartDecoder::with_config(HashMap::new(), config);

        // Test various domain extensions
        let result = decoder.cleanup_patterns("example . com");
        assert_eq!(result, "example.com");

        let result = decoder.cleanup_patterns("site . org");
        assert_eq!(result, "site.org");

        let result = decoder.cleanup_patterns("موقع . sa");
        assert_eq!(result, "موقع.sa");
    }

    #[test]
    fn test_pua_reversal_with_emoji() {
        let mut reverse_map = HashMap::new();
        reverse_map.insert("\u{E000}".to_string(), "ال".to_string());
        reverse_map.insert("\u{E001}".to_string(), "كتاب".to_string());

        let config = DecoderConfig {
            preserve_grapheme_clusters: true,
            ..Default::default()
        };
        let decoder = SmartDecoder::with_config(reverse_map, config);

        // PUA codes with emoji
        let result = decoder.decode("\u{E000}\u{E001} 📚");
        assert_eq!(result, "الكتاب 📚");
    }

    #[test]
    fn test_decode_mixed_content() {
        let mut reverse_map = HashMap::new();
        reverse_map.insert("\u{E000}".to_string(), "زر".to_string());

        let decoder = SmartDecoder::from_string_map(reverse_map);

        // Mixed Arabic + URL
        let result = decoder.decode("\u{E000} https : // example . com");
        assert!(result.starts_with("زر"));
        assert!(result.contains("https://example.com"));
    }
}
