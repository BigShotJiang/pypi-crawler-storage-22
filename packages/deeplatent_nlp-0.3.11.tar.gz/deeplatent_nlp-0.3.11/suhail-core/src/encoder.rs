//! Greedy encoder with Arabic normalization and edge-case handling
//!
//! Implements the complete SARF encoding pipeline:
//! 1. Input validation (max length, control chars)
//! 2. Pattern protection (URLs, emails, paths)
//! 3. Unicode normalization (NFC/NFKC)
//! 4. Arabic text normalization
//! 5. Greedy longest-match morpheme replacement (morpheme -> PUA)
//! 6. Pattern restoration

use crate::grapheme::is_emoji_sequence;
use crate::normalizer::{ArabicNormalizer, NormalizationConfig, ZeroWidthStrategy};
use crate::patterns::PatternProtector;
use crate::trie::ByteTrie;
use lazy_static::lazy_static;
use regex::Regex;
use std::collections::HashMap;
use unicode_segmentation::UnicodeSegmentation;

// =============================================================================
// PUA Range Constants
// =============================================================================

/// Basic PUA start (U+E000)
pub const BASIC_PUA_START: u32 = 0xE000;
/// Basic PUA end (U+F8FF)
pub const BASIC_PUA_END: u32 = 0xF8FF;
/// Supplementary PUA-A start (U+F0000)
pub const SUPP_PUA_A_START: u32 = 0xF0000;
/// Supplementary PUA-A end (U+FFFFD)
pub const SUPP_PUA_A_END: u32 = 0xFFFFD;

// =============================================================================
// Normalization
// =============================================================================

lazy_static! {
    /// Tashkeel (diacritics) pattern
    static ref RE_TASHKEEL: Regex = Regex::new(r"[\u{064B}-\u{0652}\u{0670}]").unwrap();

    /// Zero-width characters pattern
    static ref RE_ZERO_WIDTH: Regex = Regex::new(r"[\u{200B}-\u{200D}\u{FEFF}\u{200C}\u{200D}\u{202A}-\u{202E}\u{2066}-\u{2069}]").unwrap();
}

/// Arabic normalization levels
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NormalizationLevel {
    /// Light: Remove diacritics, tatweel, zero-width chars, unify alef, normalize ya
    Light,
    /// Medium: Light + normalize hamza forms, alef wasla
    Medium,
    /// Aggressive: Medium + normalize ta marbuta (loses feminine marker)
    Aggressive,
}

impl Default for NormalizationLevel {
    fn default() -> Self {
        Self::Medium
    }
}

/// Normalize Arabic text consistently with morpheme map construction
pub fn normalize_arabic(text: &str, level: NormalizationLevel) -> String {
    if text.is_empty() {
        return text.to_string();
    }

    let mut result = text.to_string();

    // Level 1: Light (always applied)

    // Remove diacritics (Tashkeel)
    result = RE_TASHKEEL.replace_all(&result, "").to_string();

    // Remove Tatweel
    result = result.replace('\u{0640}', "");

    // Remove zero-width characters
    result = RE_ZERO_WIDTH.replace_all(&result, "").to_string();

    // Unify Alef variants
    result = result.replace('\u{0623}', "\u{0627}"); // ALEF WITH HAMZA ABOVE -> ALEF
    result = result.replace('\u{0625}', "\u{0627}"); // ALEF WITH HAMZA BELOW -> ALEF
    result = result.replace('\u{0622}', "\u{0627}"); // ALEF WITH MADDA ABOVE -> ALEF

    // Normalize Ya
    result = result.replace('\u{0649}', "\u{064A}"); // ALEF MAKSURA -> YEH

    // Normalize Indic digits to ASCII
    let indic_to_ascii = [
        ('\u{0660}', '0'),
        ('\u{0661}', '1'),
        ('\u{0662}', '2'),
        ('\u{0663}', '3'),
        ('\u{0664}', '4'),
        ('\u{0665}', '5'),
        ('\u{0666}', '6'),
        ('\u{0667}', '7'),
        ('\u{0668}', '8'),
        ('\u{0669}', '9'),
    ];
    for (indic, ascii) in indic_to_ascii {
        result = result.replace(indic, &ascii.to_string());
    }

    // Level 2: Medium
    if level == NormalizationLevel::Medium || level == NormalizationLevel::Aggressive {
        // Normalize Hamza forms
        result = result.replace('\u{0624}', "\u{0648}"); // WAW WITH HAMZA -> WAW
        result = result.replace('\u{0626}', "\u{064A}"); // YEH WITH HAMZA -> YEH

        // Normalize Alef Wasla
        result = result.replace('\u{0671}', "\u{0627}"); // ALEF WASLA -> ALEF
    }

    // Level 3: Aggressive
    if level == NormalizationLevel::Aggressive {
        // Normalize Ta Marbuta (WARNING: loses feminine marker)
        result = result.replace('\u{0629}', "\u{0647}"); // TEH MARBUTA -> HEH
    }

    result
}

/// Check if character is Arabic
pub fn is_arabic_char(ch: char) -> bool {
    let cp = ch as u32;
    (0x0600..=0x06FF).contains(&cp)
        || (0x0750..=0x077F).contains(&cp)
        || (0x08A0..=0x08FF).contains(&cp)
        || (0xFB50..=0xFDFF).contains(&cp)
        || (0xFE70..=0xFEFF).contains(&cp)
}

/// Check if character is in PUA range
pub fn is_pua_char(ch: char) -> bool {
    let cp = ch as u32;
    (BASIC_PUA_START..=BASIC_PUA_END).contains(&cp)
        || (SUPP_PUA_A_START..=SUPP_PUA_A_END).contains(&cp)
}

/// Allocate PUA code point for index
pub fn allocate_pua(index: u32) -> Option<char> {
    let basic_capacity = BASIC_PUA_END - BASIC_PUA_START + 1;

    let code_point = if index < basic_capacity {
        BASIC_PUA_START + index
    } else {
        let supp_index = index - basic_capacity;
        let supp_capacity = SUPP_PUA_A_END - SUPP_PUA_A_START + 1;
        if supp_index < supp_capacity {
            SUPP_PUA_A_START + supp_index
        } else {
            return None; // Exceeded capacity
        }
    };

    char::from_u32(code_point)
}

// =============================================================================
// Extended Encoder Configuration
// =============================================================================

/// Configuration for the robust encoder
#[derive(Debug, Clone)]
pub struct EncoderConfig {
    /// Normalization level for Arabic text
    pub normalization_level: NormalizationLevel,

    /// Full normalization config (overrides normalization_level if set)
    pub normalization_config: Option<NormalizationConfig>,

    /// Whether to preserve grapheme clusters (emoji, flags)
    pub preserve_grapheme_clusters: bool,

    /// Whether to protect URLs during encoding
    pub protect_urls: bool,

    /// Whether to protect email addresses during encoding
    pub protect_emails: bool,

    /// Whether to protect file paths during encoding
    pub protect_file_paths: bool,

    /// Maximum input length (None = unlimited)
    pub max_input_length: Option<usize>,

    /// Whether to strip NULL bytes and other dangerous control chars
    pub sanitize_control_chars: bool,
}

impl Default for EncoderConfig {
    fn default() -> Self {
        Self {
            normalization_level: NormalizationLevel::Medium,
            normalization_config: None,
            preserve_grapheme_clusters: false,
            protect_urls: false,
            protect_emails: false,
            protect_file_paths: false,
            max_input_length: None,
            sanitize_control_chars: true,
        }
    }
}

impl EncoderConfig {
    /// Create a robust config with pattern protection
    pub fn robust() -> Self {
        Self {
            normalization_level: NormalizationLevel::Medium,
            normalization_config: Some(NormalizationConfig::robust()),
            preserve_grapheme_clusters: true,
            protect_urls: true,
            protect_emails: true,
            protect_file_paths: true,
            max_input_length: Some(1_000_000),
            sanitize_control_chars: true,
        }
    }

    /// Create a minimal config for training
    pub fn for_training() -> Self {
        Self {
            normalization_level: NormalizationLevel::Medium,
            normalization_config: Some(NormalizationConfig::for_training()),
            preserve_grapheme_clusters: false,
            protect_urls: false,
            protect_emails: false,
            protect_file_paths: false,
            max_input_length: None,
            sanitize_control_chars: true,
        }
    }
}

// =============================================================================
// Greedy Encoder
// =============================================================================

/// Complete SARF encoder with normalization and greedy morpheme matching
#[derive(Debug, Clone)]
pub struct GreedyEncoder {
    /// Morpheme to PUA mapping
    morf_map: HashMap<String, String>,
    /// Trie for efficient morpheme matching
    encode_trie: ByteTrie,
    /// Normalization level (backward compatibility)
    normalization_level: NormalizationLevel,
    /// Extended encoder configuration
    config: EncoderConfig,
    /// Arabic normalizer (for extended config)
    normalizer: Option<ArabicNormalizer>,
}

impl GreedyEncoder {
    /// Create encoder from morpheme map
    pub fn new(morf_map: HashMap<String, String>, normalization_level: NormalizationLevel) -> Self {
        let encode_trie = ByteTrie::from_map(&morf_map);
        Self {
            morf_map,
            encode_trie,
            normalization_level,
            config: EncoderConfig::default(),
            normalizer: None,
        }
    }

    /// Create with default normalization (Medium)
    pub fn with_default_normalization(morf_map: HashMap<String, String>) -> Self {
        Self::new(morf_map, NormalizationLevel::Medium)
    }

    /// Create with extended configuration
    pub fn with_config(morf_map: HashMap<String, String>, config: EncoderConfig) -> Self {
        let encode_trie = ByteTrie::from_map(&morf_map);

        // Create normalizer: use provided config, or create one that preserves ZWJ if grapheme preservation is enabled
        let normalizer = if let Some(ref norm_config) = config.normalization_config {
            Some(ArabicNormalizer::with_config(norm_config.clone()))
        } else if config.preserve_grapheme_clusters {
            // When preserving grapheme clusters, we need to preserve ZWJ for emoji sequences
            let norm_config = NormalizationConfig {
                zero_width_strategy: ZeroWidthStrategy::PreserveZwj,
                ..Default::default()
            };
            Some(ArabicNormalizer::with_config(norm_config))
        } else {
            None
        };

        Self {
            morf_map,
            encode_trie,
            normalization_level: config.normalization_level,
            config,
            normalizer,
        }
    }

    /// Validate input text
    pub fn validate_input(&self, text: &str) -> Result<(), String> {
        // Check max length
        if let Some(max_len) = self.config.max_input_length {
            if text.len() > max_len {
                return Err(format!(
                    "Input length {} exceeds maximum {}",
                    text.len(),
                    max_len
                ));
            }
        }
        Ok(())
    }

    /// Sanitize control characters from input
    fn sanitize_control_chars(&self, text: &str) -> String {
        if !self.config.sanitize_control_chars {
            return text.to_string();
        }

        text.chars()
            .filter(|&c| {
                let cp = c as u32;
                // Allow newline, tab, carriage return
                c == '\n' || c == '\t' || c == '\r'
                // Allow regular printable chars
                || (cp >= 0x20 && cp != 0x7F && !(0x80..=0x9F).contains(&cp))
            })
            .collect()
    }

    /// Encode text with full edge-case handling
    pub fn encode_robust(&self, text: &str) -> Result<String, String> {
        // Step 0: Validate input
        self.validate_input(text)?;

        if text.is_empty() {
            return Ok(text.to_string());
        }

        // Step 1: Sanitize control characters
        let text = self.sanitize_control_chars(text);

        // Step 2: Protect patterns (URLs, emails, paths)
        let mut protector = PatternProtector::with_options(
            self.config.protect_urls,
            self.config.protect_emails,
            self.config.protect_file_paths,
        );
        let text = protector.protect(&text);

        // Step 3: Apply normalization
        let normalized = if let Some(ref normalizer) = self.normalizer {
            normalizer.full_normalize(&text)
        } else {
            normalize_arabic(&text, self.normalization_level)
        };

        // Step 4: Greedy morpheme replacement using trie
        let encoded = if self.encode_trie.is_empty() {
            normalized
        } else if self.config.preserve_grapheme_clusters {
            self.encode_preserving_graphemes(&normalized)
        } else {
            self.encode_trie.rewrite_text(&normalized)
        };

        // Step 5: Restore protected patterns
        let result = protector.restore(&encoded);

        Ok(result)
    }

    /// Encode while preserving grapheme cluster boundaries
    fn encode_preserving_graphemes(&self, text: &str) -> String {
        let mut result = String::with_capacity(text.len());
        let mut current_segment = String::new();

        for grapheme in text.graphemes(true) {
            if is_emoji_sequence(grapheme) {
                // Flush current segment through encoder
                if !current_segment.is_empty() {
                    result.push_str(&self.encode_trie.rewrite_text(&current_segment));
                    current_segment.clear();
                }
                // Append emoji directly (don't encode)
                result.push_str(grapheme);
            } else {
                current_segment.push_str(grapheme);
            }
        }

        // Flush remaining segment
        if !current_segment.is_empty() {
            result.push_str(&self.encode_trie.rewrite_text(&current_segment));
        }

        result
    }

    /// Encode text: normalize + greedy morpheme replacement (backward compatible)
    pub fn encode(&self, text: &str) -> String {
        if text.is_empty() {
            return text.to_string();
        }

        // If using extended config with pattern protection, use robust encoding
        if self.config.protect_urls || self.config.protect_emails || self.config.protect_file_paths {
            return self.encode_robust(text).unwrap_or_else(|_| text.to_string());
        }

        // Step 1: Normalize
        let normalized = if let Some(ref normalizer) = self.normalizer {
            normalizer.full_normalize(text)
        } else {
            normalize_arabic(text, self.normalization_level)
        };

        // Step 2: Greedy morpheme replacement using trie
        if self.encode_trie.is_empty() {
            return normalized;
        }

        self.encode_trie.rewrite_text(&normalized)
    }

    /// Normalize text only (without morpheme replacement)
    pub fn normalize(&self, text: &str) -> String {
        if let Some(ref normalizer) = self.normalizer {
            normalizer.full_normalize(text)
        } else {
            normalize_arabic(text, self.normalization_level)
        }
    }

    /// Get number of morphemes
    pub fn num_morphemes(&self) -> usize {
        self.morf_map.len()
    }

    /// Get the morpheme map
    pub fn get_morf_map(&self) -> &HashMap<String, String> {
        &self.morf_map
    }

    /// Get the encoder configuration
    pub fn get_config(&self) -> &EncoderConfig {
        &self.config
    }

    /// Build morpheme map from list of morphemes
    pub fn build_morf_map(morphemes: &[String]) -> HashMap<String, String> {
        let mut map = HashMap::new();
        for (i, morpheme) in morphemes.iter().enumerate() {
            if let Some(pua) = allocate_pua(i as u32) {
                map.insert(morpheme.clone(), pua.to_string());
            }
        }
        map
    }
}

impl Default for GreedyEncoder {
    fn default() -> Self {
        Self::new(HashMap::new(), NormalizationLevel::Medium)
    }
}

// =============================================================================
// Tests
// =============================================================================

// =============================================================================
// PuaEncoder (for backward compatibility with SuhailTokenizer)
// =============================================================================

/// PUA encoder for morpheme substitution (used by SuhailTokenizer)
#[derive(Debug, Clone)]
pub struct PuaEncoder {
    /// Morpheme to PUA mapping
    morf_map: HashMap<String, String>,
    /// Trie for efficient morpheme matching
    encode_trie: ByteTrie,
}

impl PuaEncoder {
    /// Create encoder from morpheme map (char values)
    pub fn new(morf_map: HashMap<String, char>) -> Self {
        let string_map: HashMap<String, String> = morf_map
            .into_iter()
            .map(|(k, v)| (k, v.to_string()))
            .collect();
        let encode_trie = ByteTrie::from_map(&string_map);
        Self {
            morf_map: string_map,
            encode_trie,
        }
    }

    /// Encode text by replacing morphemes with PUA codes
    pub fn encode(&self, text: &str) -> String {
        if self.encode_trie.is_empty() {
            return text.to_string();
        }
        self.encode_trie.rewrite_text(text)
    }

    /// Get number of morphemes
    pub fn num_morphemes(&self) -> usize {
        self.morf_map.len()
    }
}

impl Default for PuaEncoder {
    fn default() -> Self {
        Self::new(HashMap::new())
    }
}

// =============================================================================
// Tests
// =============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    // =========================================================================
    // Existing tests (backward compatibility)
    // =========================================================================

    #[test]
    fn test_normalize_diacritics() {
        let text = "بِسْمِ";
        let normalized = normalize_arabic(text, NormalizationLevel::Light);
        assert_eq!(normalized, "بسم");
    }

    #[test]
    fn test_normalize_alef() {
        let text = "أحمد";
        let normalized = normalize_arabic(text, NormalizationLevel::Light);
        assert_eq!(normalized, "احمد");
    }

    #[test]
    fn test_normalize_indic_digits() {
        let text = "٠١٢٣٤٥٦٧٨٩";
        let normalized = normalize_arabic(text, NormalizationLevel::Light);
        assert_eq!(normalized, "0123456789");
    }

    #[test]
    fn test_normalize_tatweel() {
        let text = "مـــرحـــبا";
        let normalized = normalize_arabic(text, NormalizationLevel::Light);
        assert_eq!(normalized, "مرحبا");
    }

    #[test]
    fn test_is_arabic() {
        assert!(is_arabic_char('ا'));
        assert!(is_arabic_char('ب'));
        assert!(!is_arabic_char('a'));
    }

    #[test]
    fn test_is_pua() {
        assert!(is_pua_char('\u{E000}'));
        assert!(is_pua_char('\u{F0000}'));
        assert!(!is_pua_char('a'));
    }

    #[test]
    fn test_allocate_pua() {
        assert_eq!(allocate_pua(0), Some('\u{E000}'));
        assert_eq!(allocate_pua(6399), Some('\u{F8FF}'));
        assert_eq!(allocate_pua(6400), Some('\u{F0000}'));
    }

    #[test]
    fn test_greedy_encode() {
        let mut morf_map = HashMap::new();
        morf_map.insert("ال".to_string(), "\u{E000}".to_string());
        morf_map.insert("كتاب".to_string(), "\u{E001}".to_string());

        let encoder = GreedyEncoder::with_default_normalization(morf_map);
        let encoded = encoder.encode("الكتاب");

        assert_eq!(encoded, "\u{E000}\u{E001}");
    }

    #[test]
    fn test_encode_with_normalization() {
        let mut morf_map = HashMap::new();
        morf_map.insert("احمد".to_string(), "\u{E000}".to_string());

        let encoder = GreedyEncoder::with_default_normalization(morf_map);
        // Input has hamza, but normalization converts أ -> ا
        let encoded = encoder.encode("أحمد");

        assert_eq!(encoded, "\u{E000}");
    }

    #[test]
    fn test_mixed_text() {
        let mut morf_map = HashMap::new();
        morf_map.insert("مرحبا".to_string(), "\u{E000}".to_string());

        let encoder = GreedyEncoder::with_default_normalization(morf_map);
        let encoded = encoder.encode("مرحبا hello");

        assert_eq!(encoded, "\u{E000} hello");
    }

    // =========================================================================
    // New edge case tests
    // =========================================================================

    #[test]
    fn test_robust_encode_url_protection() {
        let mut morf_map = HashMap::new();
        morf_map.insert("مرحبا".to_string(), "\u{E000}".to_string());

        let config = EncoderConfig {
            protect_urls: true,
            ..Default::default()
        };
        let encoder = GreedyEncoder::with_config(morf_map, config);

        let text = "مرحبا https://example.com/path?x=1&y=2";
        let encoded = encoder.encode_robust(text).unwrap();

        // Arabic should be encoded
        assert!(encoded.contains("\u{E000}"));
        // URL should be preserved
        assert!(encoded.contains("https://example.com/path?x=1&y=2"));
    }

    #[test]
    fn test_robust_encode_email_protection() {
        let mut morf_map = HashMap::new();
        morf_map.insert("البريد".to_string(), "\u{E000}".to_string());

        let config = EncoderConfig {
            protect_emails: true,
            ..Default::default()
        };
        let encoder = GreedyEncoder::with_config(morf_map, config);

        let text = "البريد first.last+tag@domain.co.uk";
        let encoded = encoder.encode_robust(text).unwrap();

        // Arabic should be encoded
        assert!(encoded.contains("\u{E000}"));
        // Email should be preserved
        assert!(encoded.contains("first.last+tag@domain.co.uk"));
    }

    #[test]
    fn test_robust_encode_path_protection() {
        let config = EncoderConfig {
            protect_file_paths: true,
            ..Default::default()
        };
        let encoder = GreedyEncoder::with_config(HashMap::new(), config);

        let text = "Windows: C:\\Windows\\System32 Unix: /home/user/file.txt";
        let encoded = encoder.encode_robust(text).unwrap();

        // Paths should be preserved
        assert!(encoded.contains("C:\\Windows\\System32") || encoded.contains(r"C:\Windows\System32"));
        assert!(encoded.contains("/home/user/file.txt"));
    }

    #[test]
    fn test_robust_encode_input_validation() {
        let config = EncoderConfig {
            max_input_length: Some(10),
            ..Default::default()
        };
        let encoder = GreedyEncoder::with_config(HashMap::new(), config);

        // Short input should pass
        assert!(encoder.encode_robust("hello").is_ok());

        // Long input should fail
        assert!(encoder.encode_robust("this is too long").is_err());
    }

    #[test]
    fn test_robust_encode_control_char_sanitization() {
        let config = EncoderConfig {
            sanitize_control_chars: true,
            ..Default::default()
        };
        let encoder = GreedyEncoder::with_config(HashMap::new(), config);

        let text = "a\x00\x1Fb"; // NULL and Unit Separator
        let encoded = encoder.encode_robust(text).unwrap();
        assert_eq!(encoded, "ab");

        // Newlines and tabs should be preserved
        let text_ws = "a\tb\nc";
        let encoded_ws = encoder.encode_robust(text_ws).unwrap();
        assert_eq!(encoded_ws, "a\tb\nc");
    }

    #[test]
    fn test_robust_encode_emoji_preservation() {
        let mut morf_map = HashMap::new();
        morf_map.insert("مرحبا".to_string(), "\u{E000}".to_string());

        let config = EncoderConfig {
            preserve_grapheme_clusters: true,
            ..Default::default()
        };
        let encoder = GreedyEncoder::with_config(morf_map, config);

        let text = "مرحبا 👨‍👩‍👧‍👦 🇸🇦";
        let encoded = encoder.encode_robust(text).unwrap();

        // Arabic should be encoded
        assert!(encoded.contains("\u{E000}"));
        // Emoji should be preserved as-is
        assert!(encoded.contains("👨‍👩‍👧‍👦"));
        assert!(encoded.contains("🇸🇦"));
    }

    #[test]
    fn test_robust_config_preset() {
        let config = EncoderConfig::robust();
        assert!(config.protect_urls);
        assert!(config.protect_emails);
        assert!(config.protect_file_paths);
        assert!(config.preserve_grapheme_clusters);
        assert!(config.max_input_length.is_some());
    }

    #[test]
    fn test_encode_empty_string() {
        let encoder = GreedyEncoder::default();
        assert_eq!(encoder.encode(""), "");
        assert_eq!(encoder.encode_robust("").unwrap(), "");
    }

    #[test]
    fn test_encode_whitespace_only() {
        let encoder = GreedyEncoder::default();
        // Whitespace-only input should be handled
        let result = encoder.encode("   ");
        assert!(!result.is_empty() || result == "   ");
    }
}
