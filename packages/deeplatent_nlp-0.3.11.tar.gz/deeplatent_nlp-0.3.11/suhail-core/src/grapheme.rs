//! Grapheme cluster handling for emoji and complex scripts
//!
//! This module provides utilities for handling grapheme clusters,
//! which are user-perceived characters that may consist of multiple
//! Unicode code points.
//!
//! Key use cases:
//! - Emoji with ZWJ (Zero Width Joiner) sequences (e.g., family emoji)
//! - Emoji with skin tone modifiers
//! - Flag sequences (Regional Indicator pairs)
//! - Complex script clusters (e.g., Indic scripts)

use std::collections::HashSet;
use unicode_segmentation::UnicodeSegmentation;

// =============================================================================
// Constants
// =============================================================================

/// Fitzpatrick skin tone modifiers (U+1F3FB to U+1F3FF)
const SKIN_TONE_MODIFIERS: std::ops::RangeInclusive<u32> = 0x1F3FB..=0x1F3FF;

/// Regional Indicator range (U+1F1E6 to U+1F1FF)
const REGIONAL_INDICATOR_RANGE: std::ops::RangeInclusive<u32> = 0x1F1E6..=0x1F1FF;

/// Zero Width Joiner
const ZWJ: char = '\u{200D}';

/// Variation Selector 16 (emoji presentation)
const VS16: char = '\u{FE0F}';

/// Variation Selector 15 (text presentation)
const VS15: char = '\u{FE0E}';

// =============================================================================
// Grapheme utilities
// =============================================================================

/// Check if a character is an emoji base character
pub fn is_emoji_base(c: char) -> bool {
    let cp = c as u32;
    // Miscellaneous Symbols and Pictographs
    (0x1F300..=0x1F5FF).contains(&cp)
    // Emoticons
    || (0x1F600..=0x1F64F).contains(&cp)
    // Transport and Map Symbols
    || (0x1F680..=0x1F6FF).contains(&cp)
    // Supplemental Symbols and Pictographs
    || (0x1F900..=0x1F9FF).contains(&cp)
    // Symbols and Pictographs Extended-A
    || (0x1FA00..=0x1FA6F).contains(&cp)
    // Symbols and Pictographs Extended-B
    || (0x1FA70..=0x1FAFF).contains(&cp)
    // Dingbats
    || (0x2700..=0x27BF).contains(&cp)
    // Miscellaneous Symbols
    || (0x2600..=0x26FF).contains(&cp)
}

/// Check if a character is a skin tone modifier
pub fn is_skin_tone_modifier(c: char) -> bool {
    SKIN_TONE_MODIFIERS.contains(&(c as u32))
}

/// Check if a character is a Regional Indicator
pub fn is_regional_indicator(c: char) -> bool {
    REGIONAL_INDICATOR_RANGE.contains(&(c as u32))
}

/// Check if a character is a variation selector
pub fn is_variation_selector(c: char) -> bool {
    c == VS15 || c == VS16
}

/// Check if a grapheme cluster is an emoji sequence
pub fn is_emoji_sequence(grapheme: &str) -> bool {
    let chars: Vec<char> = grapheme.chars().collect();

    if chars.is_empty() {
        return false;
    }

    // Single emoji
    if chars.len() == 1 && is_emoji_base(chars[0]) {
        return true;
    }

    // Contains ZWJ (family emoji, profession emoji, etc.)
    if chars.contains(&ZWJ) {
        return true;
    }

    // Contains skin tone modifier
    if chars.iter().any(|&c| is_skin_tone_modifier(c)) {
        return true;
    }

    // Flag sequence (two regional indicators)
    if chars.len() == 2 && chars.iter().all(|&c| is_regional_indicator(c)) {
        return true;
    }

    // Emoji with variation selector
    if chars.len() >= 2 && is_emoji_base(chars[0]) && is_variation_selector(chars[1]) {
        return true;
    }

    false
}

/// Check if a grapheme cluster is a flag emoji
pub fn is_flag_emoji(grapheme: &str) -> bool {
    let chars: Vec<char> = grapheme.chars().collect();
    chars.len() == 2 && chars.iter().all(|&c| is_regional_indicator(c))
}

/// Get the country code from a flag emoji (e.g., "US" from U.S. flag)
pub fn flag_to_country_code(grapheme: &str) -> Option<String> {
    let chars: Vec<char> = grapheme.chars().collect();
    if chars.len() != 2 || !chars.iter().all(|&c| is_regional_indicator(c)) {
        return None;
    }

    // Convert Regional Indicators to ASCII letters
    // U+1F1E6 (A) to U+1F1FF (Z) -> 'A' to 'Z'
    let letter1 = char::from_u32((chars[0] as u32 - 0x1F1E6) + 'A' as u32)?;
    let letter2 = char::from_u32((chars[1] as u32 - 0x1F1E6) + 'A' as u32)?;

    Some(format!("{}{}", letter1, letter2))
}

/// Create a flag emoji from a country code
pub fn country_code_to_flag(code: &str) -> Option<String> {
    let code = code.to_uppercase();
    if code.len() != 2 {
        return None;
    }

    let chars: Vec<char> = code.chars().collect();
    if !chars.iter().all(|c| c.is_ascii_uppercase()) {
        return None;
    }

    // Convert ASCII letters to Regional Indicators
    let ri1 = char::from_u32((chars[0] as u32 - 'A' as u32) + 0x1F1E6)?;
    let ri2 = char::from_u32((chars[1] as u32 - 'A' as u32) + 0x1F1E6)?;

    Some(format!("{}{}", ri1, ri2))
}

// =============================================================================
// GraphemeIterator
// =============================================================================

/// Iterator over grapheme clusters with metadata
pub struct GraphemeInfo<'a> {
    /// The grapheme cluster string
    pub grapheme: &'a str,
    /// Starting byte offset in original string
    pub byte_start: usize,
    /// Ending byte offset (exclusive) in original string
    pub byte_end: usize,
    /// Whether this is an emoji sequence
    pub is_emoji: bool,
    /// Whether this is a flag emoji
    pub is_flag: bool,
    /// Number of code points in this grapheme
    pub codepoint_count: usize,
}

/// Iterate over grapheme clusters with metadata
pub fn grapheme_info_iter(text: &str) -> impl Iterator<Item = GraphemeInfo<'_>> {
    let mut byte_offset = 0;

    text.graphemes(true).map(move |grapheme| {
        let byte_start = byte_offset;
        let byte_end = byte_start + grapheme.len();
        byte_offset = byte_end;

        let is_emoji = is_emoji_sequence(grapheme);
        let is_flag = is_flag_emoji(grapheme);
        let codepoint_count = grapheme.chars().count();

        GraphemeInfo {
            grapheme,
            byte_start,
            byte_end,
            is_emoji,
            is_flag,
            codepoint_count,
        }
    })
}

/// Count grapheme clusters in a string
pub fn grapheme_count(text: &str) -> usize {
    text.graphemes(true).count()
}

/// Get the nth grapheme cluster (0-indexed)
pub fn nth_grapheme(text: &str, n: usize) -> Option<&str> {
    text.graphemes(true).nth(n)
}

/// Truncate string to n grapheme clusters
pub fn truncate_graphemes(text: &str, n: usize) -> &str {
    let byte_end = text
        .graphemes(true)
        .take(n)
        .map(|g| g.len())
        .sum();
    &text[..byte_end]
}

// =============================================================================
// GraphemePreserver
// =============================================================================

/// Preserves grapheme cluster boundaries during text transformations
#[derive(Debug, Clone)]
pub struct GraphemePreserver {
    /// Grapheme cluster boundaries (byte offsets)
    boundaries: Vec<(usize, usize)>,
    /// Set of byte offsets that start emoji sequences
    emoji_starts: HashSet<usize>,
}

impl GraphemePreserver {
    /// Create a new preserver from input text
    pub fn new(text: &str) -> Self {
        let mut boundaries = Vec::new();
        let mut emoji_starts = HashSet::new();
        let mut byte_offset = 0;

        for grapheme in text.graphemes(true) {
            let start = byte_offset;
            let end = start + grapheme.len();
            boundaries.push((start, end));

            if is_emoji_sequence(grapheme) {
                emoji_starts.insert(start);
            }

            byte_offset = end;
        }

        Self {
            boundaries,
            emoji_starts,
        }
    }

    /// Check if a byte offset is at a grapheme boundary
    pub fn is_boundary(&self, byte_offset: usize) -> bool {
        self.boundaries.iter().any(|(start, end)| byte_offset == *start || byte_offset == *end)
    }

    /// Check if a byte offset starts an emoji sequence
    pub fn is_emoji_start(&self, byte_offset: usize) -> bool {
        self.emoji_starts.contains(&byte_offset)
    }

    /// Get the grapheme cluster containing a byte offset
    pub fn grapheme_at(&self, byte_offset: usize) -> Option<(usize, usize)> {
        self.boundaries.iter().find(|(start, end)| byte_offset >= *start && byte_offset < *end).copied()
    }

    /// Get the number of grapheme clusters
    pub fn len(&self) -> usize {
        self.boundaries.len()
    }

    /// Check if empty
    pub fn is_empty(&self) -> bool {
        self.boundaries.is_empty()
    }

    /// Get all boundaries
    pub fn boundaries(&self) -> &[(usize, usize)] {
        &self.boundaries
    }
}

// =============================================================================
// Tests
// =============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_emoji_base() {
        assert!(is_emoji_base('😀'));
        assert!(is_emoji_base('🚀'));
        assert!(!is_emoji_base('a'));
        assert!(!is_emoji_base('أ'));
    }

    #[test]
    fn test_is_skin_tone_modifier() {
        assert!(is_skin_tone_modifier('\u{1F3FB}')); // Light skin tone
        assert!(is_skin_tone_modifier('\u{1F3FF}')); // Dark skin tone
        assert!(!is_skin_tone_modifier('a'));
    }

    #[test]
    fn test_is_regional_indicator() {
        assert!(is_regional_indicator('\u{1F1FA}')); // Regional Indicator U
        assert!(is_regional_indicator('\u{1F1F8}')); // Regional Indicator S
        assert!(!is_regional_indicator('U'));
    }

    #[test]
    fn test_is_emoji_sequence() {
        // Simple emoji
        assert!(is_emoji_sequence("😀"));

        // Emoji with skin tone
        assert!(is_emoji_sequence("👋🏽"));

        // Flag
        assert!(is_emoji_sequence("🇸🇦"));

        // Family emoji with ZWJ
        assert!(is_emoji_sequence("👨‍👩‍👧‍👦"));

        // Not emoji
        assert!(!is_emoji_sequence("a"));
        assert!(!is_emoji_sequence("مرحبا"));
    }

    #[test]
    fn test_flag_detection() {
        assert!(is_flag_emoji("🇸🇦")); // Saudi Arabia
        assert!(is_flag_emoji("🇺🇸")); // USA
        assert!(!is_flag_emoji("😀"));
        assert!(!is_flag_emoji("SA"));
    }

    #[test]
    fn test_flag_country_code() {
        assert_eq!(flag_to_country_code("🇸🇦"), Some("SA".to_string()));
        assert_eq!(flag_to_country_code("🇺🇸"), Some("US".to_string()));
        assert_eq!(flag_to_country_code("invalid"), None);
    }

    #[test]
    fn test_country_code_to_flag() {
        assert_eq!(country_code_to_flag("SA"), Some("🇸🇦".to_string()));
        assert_eq!(country_code_to_flag("US"), Some("🇺🇸".to_string()));
        assert_eq!(country_code_to_flag("X"), None); // Too short
    }

    #[test]
    fn test_grapheme_count() {
        // Simple text
        assert_eq!(grapheme_count("hello"), 5);

        // Emoji sequence counts as 1
        assert_eq!(grapheme_count("👨‍👩‍👧‍👦"), 1);

        // Flag counts as 1
        assert_eq!(grapheme_count("🇸🇦"), 1);

        // Mixed
        assert_eq!(grapheme_count("Hi 👋🏽!"), 5); // H, i, space, wave+skin, !
    }

    #[test]
    fn test_grapheme_info_iter() {
        let text = "a👨‍👩‍👧‍👦b";
        let infos: Vec<_> = grapheme_info_iter(text).collect();

        assert_eq!(infos.len(), 3);
        assert_eq!(infos[0].grapheme, "a");
        assert!(!infos[0].is_emoji);
        assert!(infos[1].is_emoji);
        assert_eq!(infos[2].grapheme, "b");
    }

    #[test]
    fn test_truncate_graphemes() {
        let text = "👨‍👩‍👧‍👦hello";
        let truncated = truncate_graphemes(text, 3);
        assert_eq!(grapheme_count(truncated), 3);
        assert!(truncated.starts_with("👨‍👩‍👧‍👦"));
    }

    #[test]
    fn test_grapheme_preserver() {
        let text = "a👋🏽b";
        let preserver = GraphemePreserver::new(text);

        assert_eq!(preserver.len(), 3);
        assert!(preserver.is_boundary(0)); // Start of 'a'
        assert!(preserver.is_emoji_start(1)); // Start of emoji
    }

    #[test]
    fn test_nth_grapheme() {
        let text = "🇸🇦مرحبا👋";
        assert_eq!(nth_grapheme(text, 0), Some("🇸🇦"));
        assert_eq!(nth_grapheme(text, 1), Some("م"));
        assert_eq!(nth_grapheme(text, 6), Some("👋"));
        assert_eq!(nth_grapheme(text, 10), None);
    }
}
