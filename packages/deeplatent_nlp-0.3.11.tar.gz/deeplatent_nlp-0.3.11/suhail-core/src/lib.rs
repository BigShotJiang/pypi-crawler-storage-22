//! Suhail Core - High-performance Arabic tokenizer
//!
//! This crate provides the core tokenization logic with:
//! - Greedy longest-match encoding (morpheme -> PUA)
//! - Smart decoding with 9-step Arabic post-processing
//! - Trie-based efficient matching
//! - Complete edge case handling
//! - BPE tokenization with morphology awareness
//! - Extended Unicode support (NFC/NFKC, grapheme clusters)
//! - Pattern protection (URLs, emails, file paths)

pub mod crypto;
pub mod decoder;
pub mod encoder;
pub mod grapheme;
pub mod morphology;
pub mod normalizer;
pub mod patterns;
pub mod tokenizer;
pub mod trie;

use rayon::prelude::*;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::Path;
use thiserror::Error;

// Re-exports for backward compatibility
pub use crypto::{
    BinaryMorfMap, EncryptedModel, EncryptedMorfMap, Features, License, LicenseTier,
    is_binary_morf_map, is_binary_morf_map_bytes, SARF_MAGIC, BINARY_FORMAT_VERSION,
};
pub use decoder::{decode_bytes, DecoderConfig, GreedyDecoder, SmartDecoder, DIACRITICS, SUFFIX_PAIRS};
pub use encoder::{
    allocate_pua, is_arabic_char, is_pua_char, normalize_arabic, EncoderConfig, GreedyEncoder,
    NormalizationLevel, PuaEncoder, BASIC_PUA_END, BASIC_PUA_START, SUPP_PUA_A_END, SUPP_PUA_A_START,
};
pub use grapheme::{
    grapheme_count, grapheme_info_iter, is_emoji_sequence, is_flag_emoji, is_skin_tone_modifier,
    nth_grapheme, truncate_graphemes, GraphemeInfo, GraphemePreserver,
};
pub use morphology::{MorphologyEngine, RootPattern, ARABIC_DIACRITICS, ARABIC_PREFIXES, ARABIC_SUFFIXES};
pub use normalizer::{
    ArabicNormalizer, ControlCharStrategy, NormalizationConfig, UnicodeNormalizationForm,
    WhitespaceNormalization, ZeroWidthStrategy,
};
pub use patterns::{
    contains_email, contains_path, contains_url, extract_emails, extract_paths, extract_urls,
    is_valid_email, is_valid_url, PatternMatch, PatternProtector, PatternType,
};
pub use tokenizer::{MergeRule, SuhailTokenizer, SpecialTokens, TokenId};
pub use trie::ByteTrie;

// =============================================================================
// Error Types
// =============================================================================

#[derive(Error, Debug)]
pub enum SuhailError {
    #[error("IO error: {0}")]
    IoError(#[from] std::io::Error),

    #[error("JSON error: {0}")]
    JsonError(#[from] serde_json::Error),

    #[error("Invalid morpheme map")]
    InvalidMorfMap,

    #[error("Encoding error: {0}")]
    EncodingError(String),

    #[error("Decoding error: {0}")]
    DecodingError(String),

    #[error("License error: {0}")]
    LicenseError(String),

    #[error("Crypto error: {0}")]
    CryptoError(String),

    #[error("Tokenizer error: {0}")]
    TokenizerError(String),
}

pub type Result<T> = std::result::Result<T, SuhailError>;

// =============================================================================
// SarfCodec - Main encode/decode interface (v2 API)
// =============================================================================

/// Complete SARF codec for encode/decode operations
///
/// This is the main interface for the suhail-pkg tokenizer v2.
/// It handles all edge cases for Arabic text processing.
#[derive(Debug, Clone)]
pub struct SarfCodec {
    /// Greedy encoder (morpheme -> PUA)
    encoder: GreedyEncoder,
    /// Smart decoder (PUA -> morpheme + post-processing)
    decoder: SmartDecoder,
    /// Morpheme map for reference
    morf_map: HashMap<String, String>,
}

impl SarfCodec {
    /// Create a new codec from morpheme map
    pub fn new(morf_map: HashMap<String, String>) -> Self {
        let encoder = GreedyEncoder::with_default_normalization(morf_map.clone());
        let decoder = SmartDecoder::from_forward_map(&morf_map);

        Self {
            encoder,
            decoder,
            morf_map,
        }
    }

    /// Create codec with custom normalization level
    pub fn with_normalization(
        morf_map: HashMap<String, String>,
        level: NormalizationLevel,
    ) -> Self {
        let encoder = GreedyEncoder::new(morf_map.clone(), level);
        let decoder = SmartDecoder::from_forward_map(&morf_map);

        Self {
            encoder,
            decoder,
            morf_map,
        }
    }

    /// Load codec from encrypted file (.enc or .bin)
    /// Auto-detects format based on magic bytes
    /// No license key required - uses embedded key in library
    pub fn from_encrypted_file<P: AsRef<Path>>(path: P) -> Result<Self> {
        let path_ref = path.as_ref();

        // Auto-detect format: check magic bytes first
        if is_binary_morf_map(path_ref) {
            let binary = BinaryMorfMap::load_from_file(path_ref)?;
            let morf_map = binary.decrypt()?;
            return Ok(Self::new(morf_map));
        }

        // Fall back to JSON .enc format
        let encrypted = EncryptedMorfMap::load_from_file(path_ref)?;
        let morf_map = encrypted.decrypt()?;
        Ok(Self::new(morf_map))
    }

    /// Load codec from encrypted file with custom normalization
    /// Auto-detects format based on magic bytes
    pub fn from_encrypted_file_with_normalization<P: AsRef<Path>>(
        path: P,
        level: NormalizationLevel,
    ) -> Result<Self> {
        let path_ref = path.as_ref();

        // Auto-detect format: check magic bytes first
        if is_binary_morf_map(path_ref) {
            let binary = BinaryMorfMap::load_from_file(path_ref)?;
            let morf_map = binary.decrypt()?;
            return Ok(Self::with_normalization(morf_map, level));
        }

        // Fall back to JSON .enc format
        let encrypted = EncryptedMorfMap::load_from_file(path_ref)?;
        let morf_map = encrypted.decrypt()?;
        Ok(Self::with_normalization(morf_map, level))
    }

    /// Load codec from binary morf_map file (.bin)
    /// Strongest IP protection format
    pub fn from_binary_file<P: AsRef<Path>>(path: P) -> Result<Self> {
        let binary = BinaryMorfMap::load_from_file(path)?;
        let morf_map = binary.decrypt()?;
        Ok(Self::new(morf_map))
    }

    /// Load codec from binary file with custom normalization
    pub fn from_binary_file_with_normalization<P: AsRef<Path>>(
        path: P,
        level: NormalizationLevel,
    ) -> Result<Self> {
        let binary = BinaryMorfMap::load_from_file(path)?;
        let morf_map = binary.decrypt()?;
        Ok(Self::with_normalization(morf_map, level))
    }

    /// Encrypt and save morf_map to JSON .enc file (legacy format)
    /// Creates a .enc file that can only be read by this library
    pub fn encrypt_to_file<P: AsRef<Path>>(&self, path: P) -> Result<()> {
        let encrypted = EncryptedMorfMap::encrypt(&self.morf_map)?;
        encrypted.save_to_file(path)?;
        Ok(())
    }

    /// Encrypt and save morf_map to binary .bin file (recommended)
    /// Creates a .bin file with strongest IP protection
    pub fn encrypt_to_binary_file<P: AsRef<Path>>(&self, path: P) -> Result<()> {
        let binary = BinaryMorfMap::encrypt(&self.morf_map)?;
        binary.save_to_file(path)?;
        Ok(())
    }

    /// Encrypt a morf_map and return the encrypted container
    pub fn encrypt_morf_map(morf_map: &HashMap<String, String>) -> Result<EncryptedMorfMap> {
        EncryptedMorfMap::encrypt(morf_map)
    }

    /// Encode text (normalize + morpheme -> PUA)
    pub fn encode(&self, text: &str) -> String {
        self.encoder.encode(text)
    }

    /// Decode text (byte decode + PUA -> morpheme + post-process)
    pub fn decode(&self, text: &str) -> String {
        self.decoder.decode(text)
    }

    /// Normalize text only
    pub fn normalize(&self, text: &str) -> String {
        self.encoder.normalize(text)
    }

    /// Roundtrip test: encode then decode
    pub fn roundtrip(&self, text: &str) -> (String, String, bool) {
        let normalized = self.normalize(text);
        let encoded = self.encode(text);
        let decoded = self.decode(&encoded);
        let is_consistent = normalized == decoded;
        (normalized, decoded, is_consistent)
    }

    /// Get number of morphemes
    pub fn num_morphemes(&self) -> usize {
        self.morf_map.len()
    }

    /// Get the morpheme map
    pub fn get_morf_map(&self) -> &HashMap<String, String> {
        &self.morf_map
    }

    /// Get codec statistics
    pub fn stats(&self) -> CodecStats {
        let mut basic_pua = 0;
        let mut supp_pua = 0;

        for code in self.morf_map.values() {
            for ch in code.chars() {
                let cp = ch as u32;
                if (BASIC_PUA_START..=BASIC_PUA_END).contains(&cp) {
                    basic_pua += 1;
                } else if (SUPP_PUA_A_START..=SUPP_PUA_A_END).contains(&cp) {
                    supp_pua += 1;
                }
            }
        }

        CodecStats {
            total_morphemes: self.morf_map.len(),
            basic_pua_codes: basic_pua,
            supplementary_pua_codes: supp_pua,
        }
    }

    // =========================================================================
    // Parallel Batch Processing (Rayon)
    // =========================================================================

    /// Encode a batch of texts in parallel using Rayon
    ///
    /// This method uses parallel iterators to encode multiple texts concurrently,
    /// providing 3-5x throughput improvement on multi-core systems.
    ///
    /// # Arguments
    /// * `texts` - Slice of texts to encode
    ///
    /// # Returns
    /// Vector of encoded strings in the same order as input
    ///
    /// # Example
    /// ```ignore
    /// let texts = vec!["الكتاب".to_string(), "المعلم".to_string()];
    /// let encoded = codec.encode_batch(&texts);
    /// ```
    pub fn encode_batch(&self, texts: &[String]) -> Vec<String> {
        texts.par_iter().map(|text| self.encode(text)).collect()
    }

    /// Decode a batch of texts in parallel using Rayon
    ///
    /// This method uses parallel iterators to decode multiple texts concurrently,
    /// providing 3-5x throughput improvement on multi-core systems.
    ///
    /// # Arguments
    /// * `texts` - Slice of encoded texts to decode
    ///
    /// # Returns
    /// Vector of decoded strings in the same order as input
    ///
    /// # Example
    /// ```ignore
    /// let encoded = vec!["\u{E000}\u{E001}".to_string()];
    /// let decoded = codec.decode_batch(&encoded);
    /// ```
    pub fn decode_batch(&self, texts: &[String]) -> Vec<String> {
        texts.par_iter().map(|text| self.decode(text)).collect()
    }

    /// Encode a batch with a custom thread pool size
    ///
    /// # Arguments
    /// * `texts` - Slice of texts to encode
    /// * `num_threads` - Number of threads to use (if None, uses Rayon default)
    pub fn encode_batch_with_threads(&self, texts: &[String], num_threads: Option<usize>) -> Vec<String> {
        if let Some(n) = num_threads {
            let pool = rayon::ThreadPoolBuilder::new()
                .num_threads(n)
                .build()
                .unwrap_or_else(|_| rayon::ThreadPoolBuilder::new().build().unwrap());
            pool.install(|| self.encode_batch(texts))
        } else {
            self.encode_batch(texts)
        }
    }

    /// Decode a batch with a custom thread pool size
    ///
    /// # Arguments
    /// * `texts` - Slice of encoded texts to decode
    /// * `num_threads` - Number of threads to use (if None, uses Rayon default)
    pub fn decode_batch_with_threads(&self, texts: &[String], num_threads: Option<usize>) -> Vec<String> {
        if let Some(n) = num_threads {
            let pool = rayon::ThreadPoolBuilder::new()
                .num_threads(n)
                .build()
                .unwrap_or_else(|_| rayon::ThreadPoolBuilder::new().build().unwrap());
            pool.install(|| self.decode_batch(texts))
        } else {
            self.decode_batch(texts)
        }
    }

    /// Roundtrip test a batch of texts in parallel
    ///
    /// # Returns
    /// Vector of (normalized, decoded, is_consistent) tuples
    pub fn roundtrip_batch(&self, texts: &[String]) -> Vec<(String, String, bool)> {
        texts.par_iter().map(|text| self.roundtrip(text)).collect()
    }
}

/// Codec statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodecStats {
    pub total_morphemes: usize,
    pub basic_pua_codes: usize,
    pub supplementary_pua_codes: usize,
}

// =============================================================================
// Convenience functions
// =============================================================================

/// Quick encode with a morpheme map
pub fn encode(text: &str, morf_map: &HashMap<String, String>) -> String {
    let encoder = GreedyEncoder::with_default_normalization(morf_map.clone());
    encoder.encode(text)
}

/// Quick decode with a morpheme map
pub fn decode(text: &str, morf_map: &HashMap<String, String>) -> String {
    let decoder = SmartDecoder::from_forward_map(morf_map);
    decoder.decode(text)
}

// =============================================================================
// Version info
// =============================================================================

/// Crate version
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Get version string
pub fn version() -> &'static str {
    VERSION
}

// =============================================================================
// Tests
// =============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    fn test_morf_map() -> HashMap<String, String> {
        let mut map = HashMap::new();
        map.insert("ال".to_string(), "\u{E000}".to_string());
        map.insert("كتاب".to_string(), "\u{E001}".to_string());
        map.insert("معلم".to_string(), "\u{E002}".to_string());
        map.insert("و".to_string(), "\u{E003}".to_string());
        map
    }

    #[test]
    fn test_codec_encode() {
        let codec = SarfCodec::new(test_morf_map());
        let encoded = codec.encode("الكتاب");
        assert_eq!(encoded, "\u{E000}\u{E001}");
    }

    #[test]
    fn test_codec_decode() {
        let codec = SarfCodec::new(test_morf_map());
        let decoded = codec.decode("\u{E000}\u{E001}");
        assert_eq!(decoded, "الكتاب");
    }

    #[test]
    fn test_codec_roundtrip() {
        let codec = SarfCodec::new(test_morf_map());
        let (normalized, decoded, is_consistent) = codec.roundtrip("الكتاب");
        assert!(is_consistent);
        assert_eq!(normalized, decoded);
    }

    #[test]
    fn test_mixed_text_roundtrip() {
        let codec = SarfCodec::new(test_morf_map());
        let (_normalized, decoded, is_consistent) = codec.roundtrip("hello الكتاب world");
        assert!(is_consistent);
        assert_eq!(decoded, "hello الكتاب world");
    }

    #[test]
    fn test_stats() {
        let codec = SarfCodec::new(test_morf_map());
        let stats = codec.stats();
        assert_eq!(stats.total_morphemes, 4);
        assert_eq!(stats.basic_pua_codes, 4);
    }

    #[test]
    fn test_convenience_encode() {
        let morf_map = test_morf_map();
        let encoded = encode("الكتاب", &morf_map);
        assert_eq!(encoded, "\u{E000}\u{E001}");
    }

    #[test]
    fn test_convenience_decode() {
        let morf_map = test_morf_map();
        let decoded = decode("\u{E000}\u{E001}", &morf_map);
        assert_eq!(decoded, "الكتاب");
    }

    #[test]
    fn test_encode_batch() {
        let codec = SarfCodec::new(test_morf_map());
        let texts = vec![
            "الكتاب".to_string(),
            "والمعلم".to_string(),
        ];
        let encoded = codec.encode_batch(&texts);
        assert_eq!(encoded.len(), 2);
        assert_eq!(encoded[0], "\u{E000}\u{E001}");
        assert_eq!(encoded[1], "\u{E003}\u{E000}\u{E002}");
    }

    #[test]
    fn test_decode_batch() {
        let codec = SarfCodec::new(test_morf_map());
        let texts = vec![
            "\u{E000}\u{E001}".to_string(),
            "\u{E003}\u{E000}\u{E002}".to_string(),
        ];
        let decoded = codec.decode_batch(&texts);
        assert_eq!(decoded.len(), 2);
        assert_eq!(decoded[0], "الكتاب");
        assert_eq!(decoded[1], "والمعلم");
    }

    #[test]
    fn test_roundtrip_batch() {
        let codec = SarfCodec::new(test_morf_map());
        let texts = vec![
            "الكتاب".to_string(),
            "hello world".to_string(),
        ];
        let results = codec.roundtrip_batch(&texts);
        assert_eq!(results.len(), 2);
        assert!(results[0].2); // is_consistent
        assert!(results[1].2);
    }

    #[test]
    fn test_batch_with_threads() {
        let codec = SarfCodec::new(test_morf_map());
        let texts = vec![
            "الكتاب".to_string(),
            "والمعلم".to_string(),
        ];
        let encoded = codec.encode_batch_with_threads(&texts, Some(2));
        assert_eq!(encoded.len(), 2);
        assert_eq!(encoded[0], "\u{E000}\u{E001}");
    }
}
