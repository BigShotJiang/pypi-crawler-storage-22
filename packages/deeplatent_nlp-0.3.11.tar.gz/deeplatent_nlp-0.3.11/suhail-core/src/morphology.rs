//! Arabic morphology engine
//!
//! Handles morpheme detection, root extraction, and pattern matching
//! for Arabic text processing.

use crate::Result;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};

/// Arabic prefix patterns
pub const ARABIC_PREFIXES: &[&str] = &[
    "و",    // wa (and)
    "ف",    // fa (so)
    "ب",    // bi (with)
    "ل",    // li (for)
    "ك",    // ka (like)
    "س",    // sa (will)
    "لل",   // lil (for the)
    "وال",  // wal (and the)
    "فال",  // fal (so the)
    "بال",  // bal (with the)
    "ال",   // al (the)
];

/// Arabic suffix patterns
pub const ARABIC_SUFFIXES: &[&str] = &[
    "ك",   // ka (your m.s.)
    "ه",   // hu (his)
    "ها",  // ha (her)
    "هم",  // hum (their m.)
    "هن",  // hunna (their f.)
    "كم",  // kum (your m.p.)
    "كن",  // kunna (your f.p.)
    "نا",  // na (our)
    "ي",   // i (my)
    "ون",  // una (m.p. nominative)
    "ين",  // ina (m.p. accusative/genitive)
    "ات",  // at (f.p.)
    "ة",   // ta marbuta
    "ان",  // an (dual nominative)
];

/// Arabic diacritics (harakat)
pub const ARABIC_DIACRITICS: &[char] = &[
    '\u{064B}', // fathatan
    '\u{064C}', // dammatan
    '\u{064D}', // kasratan
    '\u{064E}', // fatha
    '\u{064F}', // damma
    '\u{0650}', // kasra
    '\u{0651}', // shadda
    '\u{0652}', // sukun
    '\u{0653}', // maddah
    '\u{0654}', // hamza above
    '\u{0655}', // hamza below
    '\u{0656}', // subscript alef
    '\u{0670}', // superscript alef
];

/// Morphology engine for Arabic text
#[derive(Debug, Clone)]
pub struct MorphologyEngine {
    /// Morpheme to PUA character mapping
    morpheme_map: HashMap<String, char>,

    /// Reverse mapping: PUA to morpheme
    reverse_map: HashMap<char, String>,

    /// Set of known prefixes
    prefixes: HashSet<String>,

    /// Set of known suffixes
    suffixes: HashSet<String>,

    /// Root patterns for Arabic verbs (for future morphological analysis)
    #[allow(dead_code)]
    root_patterns: Vec<RootPattern>,
}

/// Arabic root pattern (فعل templates)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RootPattern {
    pub pattern: String,
    pub template: String,
    pub form: u8, // Verb form I-X
}

impl MorphologyEngine {
    /// Create a new morphology engine with the given morpheme map
    pub fn new(morpheme_map: HashMap<String, char>) -> Result<Self> {
        let reverse_map: HashMap<char, String> = morpheme_map
            .iter()
            .map(|(k, v)| (*v, k.clone()))
            .collect();

        let prefixes: HashSet<String> = ARABIC_PREFIXES.iter().map(|s| s.to_string()).collect();
        let suffixes: HashSet<String> = ARABIC_SUFFIXES.iter().map(|s| s.to_string()).collect();

        Ok(Self {
            morpheme_map,
            reverse_map,
            prefixes,
            suffixes,
            root_patterns: Self::default_root_patterns(),
        })
    }

    /// Get the morpheme map
    pub fn get_morpheme_map(&self) -> &HashMap<String, char> {
        &self.morpheme_map
    }

    /// Get the reverse map
    pub fn get_reverse_map(&self) -> &HashMap<char, String> {
        &self.reverse_map
    }

    /// Check if a character is an Arabic diacritic
    pub fn is_diacritic(c: char) -> bool {
        ARABIC_DIACRITICS.contains(&c)
    }

    /// Check if a string is an Arabic prefix
    pub fn is_prefix(&self, s: &str) -> bool {
        self.prefixes.contains(s)
    }

    /// Check if a string is an Arabic suffix
    pub fn is_suffix(&self, s: &str) -> bool {
        self.suffixes.contains(s)
    }

    /// Check if a character is Arabic
    pub fn is_arabic(c: char) -> bool {
        matches!(c,
            '\u{0600}'..='\u{06FF}' |  // Arabic
            '\u{0750}'..='\u{077F}' |  // Arabic Supplement
            '\u{08A0}'..='\u{08FF}' |  // Arabic Extended-A
            '\u{FB50}'..='\u{FDFF}' |  // Arabic Presentation Forms-A
            '\u{FE70}'..='\u{FEFF}'    // Arabic Presentation Forms-B
        )
    }

    /// Check if a character is in PUA range
    pub fn is_pua(c: char) -> bool {
        matches!(c,
            '\u{E000}'..='\u{F8FF}' |      // Basic PUA
            '\u{F0000}'..='\u{FFFFD}' |    // Supplementary PUA-A
            '\u{100000}'..='\u{10FFFD}'    // Supplementary PUA-B
        )
    }

    /// Extract morphemes from Arabic word
    pub fn extract_morphemes(&self, word: &str) -> Vec<String> {
        let mut morphemes = Vec::new();
        let mut remaining = word.to_string();

        // Extract prefixes
        for prefix in ARABIC_PREFIXES.iter().rev() {
            // Longer prefixes first
            if remaining.starts_with(prefix) && remaining.len() > prefix.len() {
                morphemes.push(prefix.to_string());
                remaining = remaining[prefix.len()..].to_string();
                break;
            }
        }

        // Extract suffixes
        for suffix in ARABIC_SUFFIXES.iter().rev() {
            if remaining.ends_with(suffix) && remaining.len() > suffix.len() {
                let stem_end = remaining.len() - suffix.len();
                morphemes.push(remaining[..stem_end].to_string());
                morphemes.push(suffix.to_string());
                return morphemes;
            }
        }

        // No suffix found, add remaining as stem
        if !remaining.is_empty() {
            morphemes.push(remaining);
        }

        morphemes
    }

    /// Get PUA character for morpheme
    pub fn get_pua(&self, morpheme: &str) -> Option<char> {
        self.morpheme_map.get(morpheme).copied()
    }

    /// Get morpheme for PUA character
    pub fn get_morpheme(&self, pua: char) -> Option<&str> {
        self.reverse_map.get(&pua).map(|s| s.as_str())
    }

    /// Default root patterns for Arabic verbs
    fn default_root_patterns() -> Vec<RootPattern> {
        vec![
            RootPattern {
                pattern: "فَعَلَ".to_string(),
                template: "CaCaCa".to_string(),
                form: 1,
            },
            RootPattern {
                pattern: "فَعَّلَ".to_string(),
                template: "CaCCaCa".to_string(),
                form: 2,
            },
            RootPattern {
                pattern: "فَاعَلَ".to_string(),
                template: "CaaCaCa".to_string(),
                form: 3,
            },
            RootPattern {
                pattern: "أَفْعَلَ".to_string(),
                template: "'aCCaCa".to_string(),
                form: 4,
            },
            RootPattern {
                pattern: "تَفَعَّلَ".to_string(),
                template: "taCaCCaCa".to_string(),
                form: 5,
            },
            RootPattern {
                pattern: "تَفَاعَلَ".to_string(),
                template: "taCaaCaCa".to_string(),
                form: 6,
            },
            RootPattern {
                pattern: "اِنْفَعَلَ".to_string(),
                template: "inCaCaCa".to_string(),
                form: 7,
            },
            RootPattern {
                pattern: "اِفْتَعَلَ".to_string(),
                template: "iCtaCaCa".to_string(),
                form: 8,
            },
            RootPattern {
                pattern: "اِفْعَلَّ".to_string(),
                template: "iCCaCCa".to_string(),
                form: 9,
            },
            RootPattern {
                pattern: "اِسْتَفْعَلَ".to_string(),
                template: "istaCCaCa".to_string(),
                form: 10,
            },
        ]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_diacritic() {
        assert!(MorphologyEngine::is_diacritic('\u{064E}')); // fatha
        assert!(MorphologyEngine::is_diacritic('\u{0651}')); // shadda
        assert!(!MorphologyEngine::is_diacritic('ا'));
    }

    #[test]
    fn test_is_arabic() {
        assert!(MorphologyEngine::is_arabic('ا'));
        assert!(MorphologyEngine::is_arabic('ب'));
        assert!(!MorphologyEngine::is_arabic('a'));
    }

    #[test]
    fn test_is_pua() {
        assert!(MorphologyEngine::is_pua('\u{E000}'));
        assert!(MorphologyEngine::is_pua('\u{F0000}'));
        assert!(!MorphologyEngine::is_pua('a'));
    }
}
