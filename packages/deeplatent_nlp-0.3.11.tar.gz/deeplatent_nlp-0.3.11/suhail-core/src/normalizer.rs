//! Arabic text normalizer
//!
//! Handles normalization of Arabic text including diacritics,
//! character variants, and special forms.
//!
//! Extended with edge-case hardening for:
//! - Unicode NFC/NFKC normalization
//! - Zero-width character handling
//! - Unicode whitespace normalization
//! - Grapheme cluster preservation
//! - Apostrophe/dash normalization
//! - URL/email/path protection
//! - Control character handling
//! - Input validation

use crate::morphology::MorphologyEngine;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use unicode_normalization::UnicodeNormalization;

// =============================================================================
// Enums for normalization strategies
// =============================================================================

/// Unicode normalization form
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub enum UnicodeNormalizationForm {
    /// No Unicode normalization
    #[default]
    None,
    /// Canonical Decomposition, followed by Canonical Composition (NFC)
    NFC,
    /// Compatibility Decomposition, followed by Canonical Composition (NFKC)
    NFKC,
}

/// Whitespace normalization strategy
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub enum WhitespaceNormalization {
    /// No whitespace normalization
    #[default]
    None,
    /// Collapse multiple spaces to single space
    Collapse,
    /// Normalize all Unicode whitespace to ASCII space and collapse
    Unicode,
}

/// Control character handling strategy
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub enum ControlCharStrategy {
    /// Keep control characters as-is
    Preserve,
    /// Remove control characters (except newline/tab)
    #[default]
    Remove,
    /// Replace control characters with space
    Replace,
}

/// Zero-width character handling strategy
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub enum ZeroWidthStrategy {
    /// Remove all zero-width characters
    #[default]
    RemoveAll,
    /// Preserve ZWJ for emoji sequences
    PreserveZwj,
    /// Keep all zero-width characters
    PreserveAll,
}

// =============================================================================
// Normalization configuration
// =============================================================================

/// Normalization configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NormalizationConfig {
    // =========================================================================
    // Arabic-specific normalization (existing)
    // =========================================================================

    /// Normalize alef variants to bare alef
    pub normalize_alef: bool,

    /// Normalize taa marbouta to haa
    pub normalize_taa_marbouta: bool,

    /// Normalize alef maqsura to yaa
    pub normalize_alef_maqsura: bool,

    /// Strip diacritics (harakat)
    pub strip_diacritics: bool,

    /// Remove tatweel (kashida)
    pub remove_tatweel: bool,

    /// Normalize Arabic-Indic digits to Western
    pub normalize_digits: bool,

    // =========================================================================
    // Edge-case hardening (new)
    // =========================================================================

    /// Unicode normalization form (NFC/NFKC)
    #[serde(default)]
    pub unicode_normalize: UnicodeNormalizationForm,

    /// Whitespace normalization strategy
    #[serde(default)]
    pub whitespace_normalize: WhitespaceNormalization,

    /// Zero-width character handling
    #[serde(default)]
    pub zero_width_strategy: ZeroWidthStrategy,

    /// Preserve grapheme clusters (emoji sequences, flags, skin tones)
    #[serde(default)]
    pub preserve_grapheme_clusters: bool,

    /// Normalize curly apostrophes to ASCII
    #[serde(default)]
    pub normalize_apostrophes: bool,

    /// Normalize dashes (en-dash, em-dash, minus) to hyphen
    #[serde(default)]
    pub normalize_dashes: bool,

    /// Preserve URLs during normalization
    #[serde(default)]
    pub preserve_urls: bool,

    /// Preserve email addresses during normalization
    #[serde(default)]
    pub preserve_emails: bool,

    /// Preserve file paths during normalization
    #[serde(default)]
    pub preserve_file_paths: bool,

    /// Control character handling strategy
    #[serde(default)]
    pub handle_control_chars: ControlCharStrategy,

    /// Maximum input length (None = unlimited)
    #[serde(default)]
    pub max_input_length: Option<usize>,

    /// Normalize decimal separators (locale-aware number formats)
    #[serde(default)]
    pub normalize_decimal_separators: bool,
}

impl Default for NormalizationConfig {
    fn default() -> Self {
        Self {
            // Arabic-specific (existing defaults)
            normalize_alef: false,
            normalize_taa_marbouta: false,
            normalize_alef_maqsura: false,
            strip_diacritics: false,
            remove_tatweel: true,
            normalize_digits: false,
            // Edge-case hardening (new defaults)
            unicode_normalize: UnicodeNormalizationForm::None,
            whitespace_normalize: WhitespaceNormalization::None,
            zero_width_strategy: ZeroWidthStrategy::RemoveAll,
            preserve_grapheme_clusters: false,
            normalize_apostrophes: false,
            normalize_dashes: false,
            preserve_urls: false,
            preserve_emails: false,
            preserve_file_paths: false,
            handle_control_chars: ControlCharStrategy::Remove,
            max_input_length: None,
            normalize_decimal_separators: false,
        }
    }
}

impl NormalizationConfig {
    /// Create a minimal config that only applies Unicode NFC normalization
    pub fn nfc_only() -> Self {
        Self {
            unicode_normalize: UnicodeNormalizationForm::NFC,
            remove_tatweel: false,
            ..Default::default()
        }
    }

    /// Create a config suitable for tokenizer training
    /// Applies normalization that should be consistent between train and inference
    pub fn for_training() -> Self {
        Self {
            normalize_alef: true,
            normalize_alef_maqsura: true,
            strip_diacritics: true,
            remove_tatweel: true,
            normalize_digits: true,
            unicode_normalize: UnicodeNormalizationForm::NFC,
            whitespace_normalize: WhitespaceNormalization::Collapse,
            zero_width_strategy: ZeroWidthStrategy::RemoveAll,
            handle_control_chars: ControlCharStrategy::Remove,
            ..Default::default()
        }
    }

    /// Create a config that preserves as much as possible
    /// Suitable for round-trip testing
    pub fn preserve_all() -> Self {
        Self {
            normalize_alef: false,
            normalize_taa_marbouta: false,
            normalize_alef_maqsura: false,
            strip_diacritics: false,
            remove_tatweel: false,
            normalize_digits: false,
            unicode_normalize: UnicodeNormalizationForm::None,
            whitespace_normalize: WhitespaceNormalization::None,
            zero_width_strategy: ZeroWidthStrategy::PreserveAll,
            preserve_grapheme_clusters: true,
            normalize_apostrophes: false,
            normalize_dashes: false,
            preserve_urls: true,
            preserve_emails: true,
            preserve_file_paths: true,
            handle_control_chars: ControlCharStrategy::Preserve,
            max_input_length: None,
            normalize_decimal_separators: false,
        }
    }

    /// Create a robust config with URL/email/path protection
    pub fn robust() -> Self {
        Self {
            remove_tatweel: true,
            unicode_normalize: UnicodeNormalizationForm::NFC,
            whitespace_normalize: WhitespaceNormalization::Collapse,
            zero_width_strategy: ZeroWidthStrategy::PreserveZwj,
            preserve_grapheme_clusters: true,
            normalize_apostrophes: true,
            normalize_dashes: true,
            preserve_urls: true,
            preserve_emails: true,
            preserve_file_paths: true,
            handle_control_chars: ControlCharStrategy::Remove,
            max_input_length: Some(1_000_000), // 1MB default
            ..Default::default()
        }
    }
}

// =============================================================================
// Character classification constants
// =============================================================================

/// Zero-width characters
const ZERO_WIDTH_CHARS: &[char] = &[
    '\u{200B}', // Zero Width Space
    '\u{200C}', // Zero Width Non-Joiner
    '\u{200D}', // Zero Width Joiner (ZWJ)
    '\u{200E}', // Left-to-Right Mark
    '\u{200F}', // Right-to-Left Mark
    '\u{2060}', // Word Joiner
    '\u{2061}', // Function Application
    '\u{2062}', // Invisible Times
    '\u{2063}', // Invisible Separator
    '\u{2064}', // Invisible Plus
    '\u{FEFF}', // Byte Order Mark / Zero Width No-Break Space
];

/// Zero Width Joiner (for emoji sequences)
const ZWJ: char = '\u{200D}';

/// Unicode whitespace characters (beyond ASCII space)
const UNICODE_WHITESPACE: &[char] = &[
    '\u{00A0}', // No-Break Space
    '\u{1680}', // Ogham Space Mark
    '\u{2000}', // En Quad
    '\u{2001}', // Em Quad
    '\u{2002}', // En Space
    '\u{2003}', // Em Space
    '\u{2004}', // Three-Per-Em Space
    '\u{2005}', // Four-Per-Em Space
    '\u{2006}', // Six-Per-Em Space
    '\u{2007}', // Figure Space
    '\u{2008}', // Punctuation Space
    '\u{2009}', // Thin Space
    '\u{200A}', // Hair Space
    '\u{202F}', // Narrow No-Break Space
    '\u{205F}', // Medium Mathematical Space
    '\u{3000}', // Ideographic Space
];

/// Curly apostrophes and similar quote marks
const APOSTROPHE_CHARS: &[(char, char)] = &[
    ('\u{2019}', '\''), // Right Single Quotation Mark
    ('\u{2018}', '\''), // Left Single Quotation Mark
    ('\u{201B}', '\''), // Single High-Reversed-9 Quotation Mark
    ('\u{02BC}', '\''), // Modifier Letter Apostrophe
    ('\u{02BB}', '\''), // Modifier Letter Turned Comma
    ('\u{FF07}', '\''), // Fullwidth Apostrophe
];

/// Dash-like characters
const DASH_CHARS: &[(char, char)] = &[
    ('\u{2010}', '-'), // Hyphen
    ('\u{2011}', '-'), // Non-Breaking Hyphen
    ('\u{2012}', '-'), // Figure Dash
    ('\u{2013}', '-'), // En Dash
    ('\u{2014}', '-'), // Em Dash
    ('\u{2015}', '-'), // Horizontal Bar
    ('\u{2212}', '-'), // Minus Sign
    ('\u{FE58}', '-'), // Small Em Dash
    ('\u{FE63}', '-'), // Small Hyphen-Minus
    ('\u{FF0D}', '-'), // Fullwidth Hyphen-Minus
];

/// Arabic decimal separator (U+066B) to period
const ARABIC_DECIMAL_SEPARATOR: char = '\u{066B}';

// =============================================================================
// ArabicNormalizer
// =============================================================================

/// Arabic text normalizer with comprehensive edge case handling
#[derive(Debug, Clone)]
pub struct ArabicNormalizer {
    config: NormalizationConfig,
    alef_variants: HashMap<char, char>,
    digit_map: HashMap<char, char>,
    apostrophe_map: HashMap<char, char>,
    dash_map: HashMap<char, char>,
}

impl ArabicNormalizer {
    /// Create a new normalizer with default config
    pub fn new() -> Self {
        Self::with_config(NormalizationConfig::default())
    }

    /// Create a normalizer with custom config
    pub fn with_config(config: NormalizationConfig) -> Self {
        // Alef variants mapping
        let alef_variants: HashMap<char, char> = [
            ('أ', 'ا'), // alef with hamza above
            ('إ', 'ا'), // alef with hamza below
            ('آ', 'ا'), // alef with madda
            ('ٱ', 'ا'), // alef wasla
        ]
        .into_iter()
        .collect();

        // Arabic-Indic to Western digits
        let digit_map: HashMap<char, char> = [
            ('٠', '0'),
            ('١', '1'),
            ('٢', '2'),
            ('٣', '3'),
            ('٤', '4'),
            ('٥', '5'),
            ('٦', '6'),
            ('٧', '7'),
            ('٨', '8'),
            ('٩', '9'),
        ]
        .into_iter()
        .collect();

        // Apostrophe normalization map
        let apostrophe_map: HashMap<char, char> = APOSTROPHE_CHARS.iter().cloned().collect();

        // Dash normalization map
        let dash_map: HashMap<char, char> = DASH_CHARS.iter().cloned().collect();

        Self {
            config,
            alef_variants,
            digit_map,
            apostrophe_map,
            dash_map,
        }
    }

    /// Get the current configuration
    pub fn config(&self) -> &NormalizationConfig {
        &self.config
    }

    /// Update configuration
    pub fn set_config(&mut self, config: NormalizationConfig) {
        self.config = config;
    }

    /// Apply Unicode normalization (NFC/NFKC)
    pub fn apply_unicode_normalization(&self, text: &str) -> String {
        match self.config.unicode_normalize {
            UnicodeNormalizationForm::None => text.to_string(),
            UnicodeNormalizationForm::NFC => text.nfc().collect(),
            UnicodeNormalizationForm::NFKC => text.nfkc().collect(),
        }
    }

    /// Check if a character is a zero-width character
    fn is_zero_width(c: char) -> bool {
        ZERO_WIDTH_CHARS.contains(&c)
    }

    /// Check if a character should be preserved based on zero-width strategy
    fn should_preserve_zero_width(&self, c: char) -> bool {
        match self.config.zero_width_strategy {
            ZeroWidthStrategy::PreserveAll => true,
            ZeroWidthStrategy::PreserveZwj => c == ZWJ,
            ZeroWidthStrategy::RemoveAll => false,
        }
    }

    /// Check if a character is a control character (excluding space, tab, newline)
    fn is_control_char(c: char) -> bool {
        let cp = c as u32;
        // C0 controls (except tab, newline, carriage return)
        (cp < 0x20 && c != '\t' && c != '\n' && c != '\r')
        // DEL
        || cp == 0x7F
        // C1 controls
        || (0x80..=0x9F).contains(&cp)
        // Bidirectional controls
        || matches!(c, '\u{202A}'..='\u{202E}' | '\u{2066}'..='\u{2069}')
    }

    /// Handle a control character according to config
    fn handle_control_char(&self, c: char) -> Option<char> {
        match self.config.handle_control_chars {
            ControlCharStrategy::Preserve => Some(c),
            ControlCharStrategy::Remove => None,
            ControlCharStrategy::Replace => Some(' '),
        }
    }

    /// Normalize a single character (Arabic-specific)
    fn normalize_char(&self, c: char) -> Option<char> {
        // Skip tatweel if configured
        if self.config.remove_tatweel && c == '\u{0640}' {
            return None;
        }

        // Skip diacritics if configured
        if self.config.strip_diacritics && MorphologyEngine::is_diacritic(c) {
            return None;
        }

        // Normalize alef variants
        if self.config.normalize_alef {
            if let Some(&normalized) = self.alef_variants.get(&c) {
                return Some(normalized);
            }
        }

        // Normalize taa marbouta
        if self.config.normalize_taa_marbouta && c == 'ة' {
            return Some('ه');
        }

        // Normalize alef maqsura
        if self.config.normalize_alef_maqsura && c == 'ى' {
            return Some('ي');
        }

        // Normalize digits
        if self.config.normalize_digits {
            if let Some(&western) = self.digit_map.get(&c) {
                return Some(western);
            }
        }

        // Normalize apostrophes
        if self.config.normalize_apostrophes {
            if let Some(&ascii) = self.apostrophe_map.get(&c) {
                return Some(ascii);
            }
        }

        // Normalize dashes
        if self.config.normalize_dashes {
            if let Some(&ascii) = self.dash_map.get(&c) {
                return Some(ascii);
            }
        }

        // Normalize Arabic decimal separator
        if self.config.normalize_decimal_separators && c == ARABIC_DECIMAL_SEPARATOR {
            return Some('.');
        }

        Some(c)
    }

    /// Normalize Arabic text (core normalization without whitespace handling)
    pub fn normalize(&self, text: &str) -> String {
        let mut result = String::with_capacity(text.len());

        for c in text.chars() {
            // Handle zero-width characters
            if Self::is_zero_width(c) {
                if self.should_preserve_zero_width(c) {
                    result.push(c);
                }
                continue;
            }

            // Handle control characters
            if Self::is_control_char(c) {
                if let Some(replacement) = self.handle_control_char(c) {
                    result.push(replacement);
                }
                continue;
            }

            // Apply character normalization
            if let Some(normalized) = self.normalize_char(c) {
                result.push(normalized);
            }
        }

        result
    }

    /// Apply whitespace normalization according to config
    pub fn normalize_whitespace_with_config(&self, text: &str) -> String {
        match self.config.whitespace_normalize {
            WhitespaceNormalization::None => text.to_string(),
            WhitespaceNormalization::Collapse => Self::collapse_whitespace(text),
            WhitespaceNormalization::Unicode => Self::normalize_unicode_whitespace(text),
        }
    }

    /// Collapse multiple whitespace to single space (preserves Unicode whitespace identity)
    pub fn collapse_whitespace(text: &str) -> String {
        let mut result = String::with_capacity(text.len());
        let mut prev_space = false;

        for c in text.chars() {
            if c.is_whitespace() {
                if !prev_space {
                    result.push(' ');
                    prev_space = true;
                }
            } else {
                result.push(c);
                prev_space = false;
            }
        }

        result.trim().to_string()
    }

    /// Normalize all Unicode whitespace to ASCII space and collapse
    /// Preserves newlines (\n) but normalizes CRLF to LF and converts other whitespace to space
    pub fn normalize_unicode_whitespace(text: &str) -> String {
        // Step 1: Normalize CRLF to LF first (before individual char processing)
        let text = text.replace("\r\n", "\n");

        let mut result = String::with_capacity(text.len());
        let mut prev_space = false;

        for c in text.chars() {
            // Preserve newlines
            if c == '\n' {
                result.push(c);
                prev_space = false;
                continue;
            }

            // Check if it's whitespace (tab, space, Unicode whitespace, etc.)
            let is_ws = c.is_whitespace() || UNICODE_WHITESPACE.contains(&c);
            if is_ws {
                if !prev_space {
                    result.push(' ');
                    prev_space = true;
                }
            } else {
                result.push(c);
                prev_space = false;
            }
        }

        result.trim().to_string()
    }

    /// Simple whitespace collapse (backward compatibility)
    pub fn normalize_whitespace(text: &str) -> String {
        Self::collapse_whitespace(text)
    }

    /// Remove zero-width characters (backward compatibility)
    pub fn remove_zero_width(text: &str) -> String {
        text.chars()
            .filter(|c| !Self::is_zero_width(*c))
            .collect()
    }

    /// Remove zero-width characters but preserve ZWJ for emoji
    pub fn remove_zero_width_preserve_zwj(text: &str) -> String {
        text.chars()
            .filter(|&c| !Self::is_zero_width(c) || c == ZWJ)
            .collect()
    }

    /// Full normalization pipeline (backward compatibility)
    pub fn full_normalize(&self, text: &str) -> String {
        // Step 1: Apply Unicode normalization (NFC/NFKC)
        let text = self.apply_unicode_normalization(text);

        // Step 2: Apply character-level normalization (includes zero-width handling)
        let text = self.normalize(&text);

        // Step 3: Apply whitespace normalization
        self.normalize_whitespace_with_config(&text)
    }

    /// Validate input length
    pub fn validate_input(&self, text: &str) -> Result<(), String> {
        if let Some(max_len) = self.config.max_input_length {
            if text.len() > max_len {
                return Err(format!(
                    "Input length {} exceeds maximum {}",
                    text.len(),
                    max_len
                ));
            }
        }
        Ok(())
    }

    /// Safe normalize with input validation
    pub fn safe_normalize(&self, text: &str) -> Result<String, String> {
        self.validate_input(text)?;
        Ok(self.full_normalize(text))
    }
}

impl Default for ArabicNormalizer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // =========================================================================
    // Existing tests (backward compatibility)
    // =========================================================================

    #[test]
    fn test_remove_tatweel() {
        let normalizer = ArabicNormalizer::new();
        assert_eq!(normalizer.normalize("مـــرحـــبا"), "مرحبا");
    }

    #[test]
    fn test_normalize_whitespace() {
        assert_eq!(
            ArabicNormalizer::normalize_whitespace("hello   world"),
            "hello world"
        );
    }

    #[test]
    fn test_normalize_alef() {
        let config = NormalizationConfig {
            normalize_alef: true,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);
        assert_eq!(normalizer.normalize("أحمد"), "احمد");
        assert_eq!(normalizer.normalize("إسلام"), "اسلام");
    }

    #[test]
    fn test_strip_diacritics() {
        let config = NormalizationConfig {
            strip_diacritics: true,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);
        assert_eq!(normalizer.normalize("بِسْمِ"), "بسم");
    }

    // =========================================================================
    // New edge case tests
    // =========================================================================

    #[test]
    fn test_unicode_nfc_normalization() {
        // café with combining acute accent vs precomposed
        let decomposed = "cafe\u{0301}"; // e + combining acute
        let precomposed = "café";

        let config = NormalizationConfig {
            unicode_normalize: UnicodeNormalizationForm::NFC,
            remove_tatweel: false,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);

        let result = normalizer.apply_unicode_normalization(decomposed);
        assert_eq!(result, precomposed);
    }

    #[test]
    fn test_unicode_nfkc_normalization() {
        // NFKC normalizes compatibility characters
        let input = "ﬁ"; // fi ligature (U+FB01)
        let config = NormalizationConfig {
            unicode_normalize: UnicodeNormalizationForm::NFKC,
            remove_tatweel: false,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);

        let result = normalizer.apply_unicode_normalization(input);
        assert_eq!(result, "fi");
    }

    #[test]
    fn test_zero_width_removal() {
        let text = "a\u{200B}b"; // a + ZWSP + b
        let normalizer = ArabicNormalizer::new();
        assert_eq!(normalizer.normalize(text), "ab");
    }

    #[test]
    fn test_zero_width_preserve_zwj() {
        // ZWJ should be preserved for emoji sequences
        let config = NormalizationConfig {
            zero_width_strategy: ZeroWidthStrategy::PreserveZwj,
            remove_tatweel: false,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);

        // Family emoji: man + ZWJ + woman + ZWJ + girl + ZWJ + boy
        let emoji = "👨\u{200D}👩\u{200D}👧\u{200D}👦";
        let result = normalizer.normalize(emoji);
        assert!(result.contains('\u{200D}'));

        // But ZWSP should still be removed
        let text = "a\u{200B}b";
        assert_eq!(normalizer.normalize(text), "ab");
    }

    #[test]
    fn test_unicode_whitespace_normalization() {
        // NBSP should be normalized to regular space
        let text = "a\u{00A0}b\tc\r\nd";
        let result = ArabicNormalizer::normalize_unicode_whitespace(text);
        assert_eq!(result, "a b c\nd");
    }

    #[test]
    fn test_apostrophe_normalization() {
        let config = NormalizationConfig {
            normalize_apostrophes: true,
            remove_tatweel: false,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);

        // Curly apostrophe should become ASCII
        assert_eq!(normalizer.normalize("don\u{2019}t"), "don't");
    }

    #[test]
    fn test_dash_normalization() {
        let config = NormalizationConfig {
            normalize_dashes: true,
            remove_tatweel: false,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);

        // En-dash
        assert_eq!(normalizer.normalize("10\u{2013}12"), "10-12");
        // Em-dash
        assert_eq!(normalizer.normalize("word\u{2014}word"), "word-word");
        // Minus sign
        assert_eq!(normalizer.normalize("\u{2212}5"), "-5");
    }

    #[test]
    fn test_control_char_removal() {
        let config = NormalizationConfig {
            handle_control_chars: ControlCharStrategy::Remove,
            remove_tatweel: false,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);

        let text = "a\x00\x1Fb"; // NULL and Unit Separator
        assert_eq!(normalizer.normalize(text), "ab");

        // But newline and tab should be preserved
        let text_with_whitespace = "a\tb\nc";
        assert_eq!(normalizer.normalize(text_with_whitespace), "a\tb\nc");
    }

    #[test]
    fn test_control_char_replace() {
        let config = NormalizationConfig {
            handle_control_chars: ControlCharStrategy::Replace,
            remove_tatweel: false,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);

        let text = "a\x00b";
        assert_eq!(normalizer.normalize(text), "a b");
    }

    #[test]
    fn test_input_validation() {
        let config = NormalizationConfig {
            max_input_length: Some(10),
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);

        assert!(normalizer.validate_input("short").is_ok());
        assert!(normalizer.validate_input("this is too long").is_err());
    }

    #[test]
    fn test_config_presets() {
        // Test NFC only config
        let nfc_config = NormalizationConfig::nfc_only();
        assert_eq!(nfc_config.unicode_normalize, UnicodeNormalizationForm::NFC);
        assert!(!nfc_config.remove_tatweel);

        // Test training config
        let train_config = NormalizationConfig::for_training();
        assert!(train_config.normalize_alef);
        assert!(train_config.strip_diacritics);

        // Test preserve all config
        let preserve_config = NormalizationConfig::preserve_all();
        assert!(!preserve_config.normalize_alef);
        assert!(preserve_config.preserve_urls);

        // Test robust config
        let robust_config = NormalizationConfig::robust();
        assert!(robust_config.preserve_urls);
        assert!(robust_config.preserve_emails);
        assert!(robust_config.max_input_length.is_some());
    }

    #[test]
    fn test_full_normalize_pipeline() {
        let config = NormalizationConfig {
            unicode_normalize: UnicodeNormalizationForm::NFC,
            whitespace_normalize: WhitespaceNormalization::Collapse,
            normalize_apostrophes: true,
            remove_tatweel: true,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);

        // Input with multiple issues
        let input = "cafe\u{0301}  don\u{2019}t   مـرحبا";
        let result = normalizer.full_normalize(input);
        assert_eq!(result, "café don't مرحبا");
    }

    #[test]
    fn test_arabic_decimal_separator() {
        let config = NormalizationConfig {
            normalize_decimal_separators: true,
            remove_tatweel: false,
            ..Default::default()
        };
        let normalizer = ArabicNormalizer::with_config(config);

        // Arabic decimal separator U+066B
        assert_eq!(normalizer.normalize("٢٣\u{066B}٥"), "٢٣.٥");
    }
}
