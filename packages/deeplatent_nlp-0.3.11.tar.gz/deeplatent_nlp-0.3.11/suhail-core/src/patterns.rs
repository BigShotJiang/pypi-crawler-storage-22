//! Pattern protection for URLs, emails, and file paths
//!
//! This module provides utilities for detecting and protecting special patterns
//! during text normalization. Protected patterns are temporarily replaced with
//! placeholders, allowing normalization to proceed without destroying them,
//! and then restored afterward.
//!
//! Supported patterns:
//! - URLs (http, https, ftp, file protocols)
//! - Email addresses
//! - Windows file paths (C:\, D:\, etc.)
//! - Unix file paths (absolute paths starting with /)

use lazy_static::lazy_static;
use regex::Regex;
use std::collections::HashMap;

// =============================================================================
// Pattern regex definitions
// =============================================================================

lazy_static! {
    /// URL pattern
    /// Matches: http://, https://, ftp://, file:// URLs
    /// Captures query strings, fragments, and encoded characters
    static ref URL_REGEX: Regex = Regex::new(
        r"(?i)(https?|ftp|file)://[^\s<>\[\]{}|\\^`\x00-\x1F\x7F]+"
    ).unwrap();

    /// Email pattern
    /// Matches standard email addresses with various TLDs
    static ref EMAIL_REGEX: Regex = Regex::new(
        r"(?i)[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
    ).unwrap();

    /// Windows file path pattern
    /// Matches: C:\, D:\, etc. and UNC paths \\server\share
    static ref WINDOWS_PATH_REGEX: Regex = Regex::new(
        r"(?i)(?:[A-Z]:|\\\\[a-zA-Z0-9._-]+)(?:\\[^\s\\:*?<>|]+)+"
    ).unwrap();

    /// Unix file path pattern
    /// Matches absolute paths starting with / and containing valid path characters
    /// Requires at least one / after the initial one to avoid matching single /
    static ref UNIX_PATH_REGEX: Regex = Regex::new(
        r"(?:/[a-zA-Z0-9._-]+)+(?:/[a-zA-Z0-9._-]*)?"
    ).unwrap();

    /// Combined path pattern (either Windows or Unix)
    static ref PATH_REGEX: Regex = Regex::new(
        r"(?:(?:[A-Z]:|\\\\[a-zA-Z0-9._-]+)(?:\\[^\s\\:*?<>|]+)+)|(?:(?:/[a-zA-Z0-9._-]+)+(?:/[a-zA-Z0-9._-]*)?)"
    ).unwrap();
}

// =============================================================================
// PatternMatch
// =============================================================================

/// Represents a matched pattern in text
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PatternMatch {
    /// The matched text
    pub text: String,
    /// Starting byte offset
    pub start: usize,
    /// Ending byte offset (exclusive)
    pub end: usize,
    /// Type of pattern
    pub pattern_type: PatternType,
}

/// Types of protected patterns
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PatternType {
    Url,
    Email,
    WindowsPath,
    UnixPath,
}

impl PatternType {
    /// Get the placeholder prefix for this pattern type
    fn placeholder_prefix(&self) -> &'static str {
        match self {
            PatternType::Url => "\u{E800}URL",
            PatternType::Email => "\u{E801}EMAIL",
            PatternType::WindowsPath => "\u{E802}WINPATH",
            PatternType::UnixPath => "\u{E803}UNIXPATH",
        }
    }
}

// =============================================================================
// PatternProtector
// =============================================================================

/// Protects patterns during text transformation
///
/// Usage:
/// 1. Create protector and call protect() on input text
/// 2. Apply your transformations to the protected text
/// 3. Call restore() to put the patterns back
#[derive(Debug, Clone)]
pub struct PatternProtector {
    /// Protected patterns, keyed by placeholder
    protected: HashMap<String, String>,
    /// Counter for generating unique placeholders
    counter: usize,
    /// Which pattern types to protect
    protect_urls: bool,
    protect_emails: bool,
    protect_paths: bool,
}

impl PatternProtector {
    /// Create a new protector with default settings (protect all)
    pub fn new() -> Self {
        Self {
            protected: HashMap::new(),
            counter: 0,
            protect_urls: true,
            protect_emails: true,
            protect_paths: true,
        }
    }

    /// Create a protector with specific pattern types enabled
    pub fn with_options(protect_urls: bool, protect_emails: bool, protect_paths: bool) -> Self {
        Self {
            protected: HashMap::new(),
            counter: 0,
            protect_urls,
            protect_emails,
            protect_paths,
        }
    }

    /// Generate a unique placeholder
    fn make_placeholder(&mut self, pattern_type: PatternType) -> String {
        let placeholder = format!("{}{}\u{E8FF}", pattern_type.placeholder_prefix(), self.counter);
        self.counter += 1;
        placeholder
    }

    /// Find all matches of a pattern type in text
    fn find_matches(&self, text: &str, regex: &Regex, pattern_type: PatternType) -> Vec<PatternMatch> {
        regex
            .find_iter(text)
            .map(|m| PatternMatch {
                text: m.as_str().to_string(),
                start: m.start(),
                end: m.end(),
                pattern_type,
            })
            .collect()
    }

    /// Protect patterns in text, replacing them with placeholders
    pub fn protect(&mut self, text: &str) -> String {
        let mut result = text.to_string();
        let mut all_matches: Vec<PatternMatch> = Vec::new();

        // Collect all matches (order matters - URLs should be checked before paths
        // to avoid paths inside URLs being matched separately)
        if self.protect_urls {
            all_matches.extend(self.find_matches(&result, &URL_REGEX, PatternType::Url));
        }
        if self.protect_emails {
            all_matches.extend(self.find_matches(&result, &EMAIL_REGEX, PatternType::Email));
        }
        if self.protect_paths {
            all_matches.extend(self.find_matches(&result, &WINDOWS_PATH_REGEX, PatternType::WindowsPath));
            // Only match Unix paths that don't overlap with already matched patterns
            let unix_matches = self.find_matches(&result, &UNIX_PATH_REGEX, PatternType::UnixPath);
            for unix_match in unix_matches {
                // Check if this path overlaps with any already matched URL
                let overlaps = all_matches.iter().any(|m| {
                    unix_match.start < m.end && unix_match.end > m.start
                });
                if !overlaps {
                    all_matches.push(unix_match);
                }
            }
        }

        // Sort by position (descending) so we can replace from end to start
        // This keeps byte offsets valid as we make replacements
        all_matches.sort_by(|a, b| b.start.cmp(&a.start));

        // Replace each match with a placeholder
        for pattern_match in all_matches {
            let placeholder = self.make_placeholder(pattern_match.pattern_type);
            self.protected.insert(placeholder.clone(), pattern_match.text.clone());
            result = format!(
                "{}{}{}",
                &result[..pattern_match.start],
                placeholder,
                &result[pattern_match.end..]
            );
        }

        result
    }

    /// Restore protected patterns from placeholders
    pub fn restore(&self, text: &str) -> String {
        let mut result = text.to_string();

        // Replace placeholders with original patterns
        for (placeholder, original) in &self.protected {
            result = result.replace(placeholder, original);
        }

        result
    }

    /// Get the number of protected patterns
    pub fn protected_count(&self) -> usize {
        self.protected.len()
    }

    /// Get all protected patterns
    pub fn protected_patterns(&self) -> &HashMap<String, String> {
        &self.protected
    }

    /// Clear all protected patterns (for reuse)
    pub fn clear(&mut self) {
        self.protected.clear();
        self.counter = 0;
    }
}

impl Default for PatternProtector {
    fn default() -> Self {
        Self::new()
    }
}

// =============================================================================
// Standalone detection functions
// =============================================================================

/// Check if text contains a URL
pub fn contains_url(text: &str) -> bool {
    URL_REGEX.is_match(text)
}

/// Check if text contains an email address
pub fn contains_email(text: &str) -> bool {
    EMAIL_REGEX.is_match(text)
}

/// Check if text contains a file path
pub fn contains_path(text: &str) -> bool {
    WINDOWS_PATH_REGEX.is_match(text) || UNIX_PATH_REGEX.is_match(text)
}

/// Extract all URLs from text
pub fn extract_urls(text: &str) -> Vec<&str> {
    URL_REGEX.find_iter(text).map(|m| m.as_str()).collect()
}

/// Extract all email addresses from text
pub fn extract_emails(text: &str) -> Vec<&str> {
    EMAIL_REGEX.find_iter(text).map(|m| m.as_str()).collect()
}

/// Extract all file paths from text
pub fn extract_paths(text: &str) -> Vec<&str> {
    let mut paths: Vec<&str> = Vec::new();
    paths.extend(WINDOWS_PATH_REGEX.find_iter(text).map(|m| m.as_str()));
    paths.extend(UNIX_PATH_REGEX.find_iter(text).map(|m| m.as_str()));
    paths
}

/// Validate URL format
pub fn is_valid_url(text: &str) -> bool {
    URL_REGEX.is_match(text) && URL_REGEX.find(text).map_or(false, |m| m.as_str() == text)
}

/// Validate email format
pub fn is_valid_email(text: &str) -> bool {
    EMAIL_REGEX.is_match(text) && EMAIL_REGEX.find(text).map_or(false, |m| m.as_str() == text)
}

// =============================================================================
// Tests
// =============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    // URL tests
    #[test]
    fn test_url_detection() {
        assert!(contains_url("Visit https://example.com for more"));
        assert!(contains_url("http://example.com"));
        assert!(contains_url("ftp://files.example.com/path"));
        assert!(!contains_url("not a url"));
        assert!(!contains_url("example.com")); // No protocol
    }

    #[test]
    fn test_url_extraction() {
        let text = "Visit https://example.com and http://test.org/path";
        let urls = extract_urls(text);
        assert_eq!(urls.len(), 2);
        assert!(urls.contains(&"https://example.com"));
        assert!(urls.contains(&"http://test.org/path"));
    }

    #[test]
    fn test_url_with_query() {
        let text = "https://example.com/path?x=1&y=two#section";
        assert!(contains_url(text));
        let urls = extract_urls(text);
        assert_eq!(urls[0], text);
    }

    #[test]
    fn test_url_validation() {
        assert!(is_valid_url("https://example.com"));
        assert!(!is_valid_url("Visit https://example.com")); // Has prefix
    }

    // Email tests
    #[test]
    fn test_email_detection() {
        assert!(contains_email("Contact: user@example.com"));
        assert!(contains_email("first.last+tag@domain.co.uk"));
        assert!(!contains_email("not an email"));
        assert!(!contains_email("user@")); // Incomplete
    }

    #[test]
    fn test_email_extraction() {
        let text = "Email a@b.com or c@d.org";
        let emails = extract_emails(text);
        assert_eq!(emails.len(), 2);
    }

    #[test]
    fn test_email_validation() {
        assert!(is_valid_email("user@example.com"));
        assert!(!is_valid_email("Contact: user@example.com")); // Has prefix
    }

    // Path tests
    #[test]
    fn test_windows_path_detection() {
        assert!(contains_path(r"C:\Windows\System32"));
        assert!(contains_path(r"D:\Users\name\file.txt"));
    }

    #[test]
    fn test_unix_path_detection() {
        assert!(contains_path("/home/user/file.txt"));
        assert!(contains_path("/etc/hosts"));
    }

    #[test]
    fn test_path_extraction() {
        let text = r"Windows: C:\Windows\System32 Unix: /home/user/file";
        let paths = extract_paths(text);
        assert_eq!(paths.len(), 2);
    }

    // PatternProtector tests
    #[test]
    fn test_protect_and_restore_url() {
        let mut protector = PatternProtector::new();
        let text = "Visit https://example.com for info";

        let protected = protector.protect(text);
        assert!(!protected.contains("https://"));
        assert!(protected.contains("\u{E800}URL")); // Placeholder

        let restored = protector.restore(&protected);
        assert_eq!(restored, text);
    }

    #[test]
    fn test_protect_and_restore_email() {
        let mut protector = PatternProtector::new();
        let text = "Contact user@example.com today";

        let protected = protector.protect(text);
        assert!(!protected.contains("@"));

        let restored = protector.restore(&protected);
        assert_eq!(restored, text);
    }

    #[test]
    fn test_protect_multiple_patterns() {
        let mut protector = PatternProtector::new();
        let text = "URL: https://a.com Email: b@c.com Path: /d/e/f";

        let protected = protector.protect(text);
        assert_eq!(protector.protected_count(), 3);

        let restored = protector.restore(&protected);
        assert_eq!(restored, text);
    }

    #[test]
    fn test_protect_with_normalization() {
        let mut protector = PatternProtector::new();
        let text = "URL: https://example.com?x=1&y=2";

        let protected = protector.protect(text);

        // Simulate normalization that would break URLs
        let normalized = protected.to_uppercase();

        let restored = protector.restore(&normalized);
        // URL should be preserved even after uppercase normalization
        assert!(restored.contains("https://example.com?x=1&y=2"));
    }

    #[test]
    fn test_selective_protection() {
        let mut protector = PatternProtector::with_options(true, false, false);
        let text = "https://a.com user@b.com";

        let protected = protector.protect(text);
        assert!(!protected.contains("https://"));
        assert!(protected.contains("@")); // Email not protected

        assert_eq!(protector.protected_count(), 1);
    }

    #[test]
    fn test_url_path_overlap() {
        // Path inside URL should not be matched separately
        let mut protector = PatternProtector::new();
        let text = "https://example.com/home/user/file.txt";

        let protected = protector.protect(text);
        // Should be protected as a single URL, not URL + Unix path
        assert_eq!(protector.protected_count(), 1);

        let restored = protector.restore(&protected);
        assert_eq!(restored, text);
    }

    #[test]
    fn test_arabic_text_with_url() {
        let mut protector = PatternProtector::new();
        let text = "زر الموقع https://example.com للمزيد";

        let protected = protector.protect(text);
        let restored = protector.restore(&protected);
        assert_eq!(restored, text);
    }

    #[test]
    fn test_clear_protector() {
        let mut protector = PatternProtector::new();
        protector.protect("https://a.com user@b.com");
        assert!(protector.protected_count() > 0);

        protector.clear();
        assert_eq!(protector.protected_count(), 0);
    }
}
