//! BPE Tokenizer implementation with Arabic morphology awareness

use crate::{
    crypto::License,
    decoder::SmartDecoder,
    encoder::PuaEncoder,
    morphology::MorphologyEngine,
    normalizer::ArabicNormalizer,
    Result,
};
use parking_lot::RwLock;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Arc;

/// Token ID type
pub type TokenId = u32;

/// Special tokens
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpecialTokens {
    pub pad: TokenId,
    pub unk: TokenId,
    pub bos: TokenId,
    pub eos: TokenId,
}

impl Default for SpecialTokens {
    fn default() -> Self {
        Self {
            pad: 0,
            unk: 1,
            bos: 2,
            eos: 3,
        }
    }
}

/// BPE merge rule
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MergeRule {
    pub pair: (Vec<u8>, Vec<u8>),
    pub result: Vec<u8>,
    pub rank: u32,
}

/// Core tokenizer with morphology awareness
#[derive(Clone)]
pub struct SuhailTokenizer {
    /// Vocabulary: token bytes -> token ID
    vocab: Arc<HashMap<Vec<u8>, TokenId>>,

    /// Reverse vocabulary: token ID -> token bytes
    reverse_vocab: Arc<HashMap<TokenId, Vec<u8>>>,

    /// BPE merge rules sorted by rank
    merges: Arc<Vec<MergeRule>>,

    /// Merge lookup for O(1) pair checking
    merge_lookup: Arc<HashMap<(Vec<u8>, Vec<u8>), Vec<u8>>>,

    /// Special tokens
    special_tokens: SpecialTokens,

    /// Morphology engine for Arabic
    morphology: Arc<MorphologyEngine>,

    /// Text normalizer
    normalizer: Arc<ArabicNormalizer>,

    /// PUA encoder
    encoder: Arc<PuaEncoder>,

    /// Smart decoder
    decoder: Arc<SmartDecoder>,

    /// License validator (optional)
    license: Arc<RwLock<Option<License>>>,
}

impl SuhailTokenizer {
    /// Create a new tokenizer with vocabulary and merges
    pub fn new(
        vocab: HashMap<Vec<u8>, TokenId>,
        merges: Vec<MergeRule>,
        morpheme_map: HashMap<String, char>,
    ) -> Result<Self> {
        let reverse_vocab: HashMap<TokenId, Vec<u8>> =
            vocab.iter().map(|(k, v)| (*v, k.clone())).collect();

        let merge_lookup: HashMap<(Vec<u8>, Vec<u8>), Vec<u8>> = merges
            .iter()
            .map(|m| (m.pair.clone(), m.result.clone()))
            .collect();

        let morphology = MorphologyEngine::new(morpheme_map)?;
        let normalizer = ArabicNormalizer::new();
        let encoder = PuaEncoder::new(morphology.get_morpheme_map().clone());
        let decoder = SmartDecoder::new(morphology.get_reverse_map().clone());

        Ok(Self {
            vocab: Arc::new(vocab),
            reverse_vocab: Arc::new(reverse_vocab),
            merges: Arc::new(merges),
            merge_lookup: Arc::new(merge_lookup),
            special_tokens: SpecialTokens::default(),
            morphology: Arc::new(morphology),
            normalizer: Arc::new(normalizer),
            encoder: Arc::new(encoder),
            decoder: Arc::new(decoder),
            license: Arc::new(RwLock::new(None)),
        })
    }

    /// Set license for validation
    pub fn set_license(&self, license: License) -> Result<()> {
        license.validate()?;
        *self.license.write() = Some(license);
        Ok(())
    }

    /// Get vocabulary size
    pub fn vocab_size(&self) -> usize {
        self.vocab.len()
    }

    /// Encode text to token IDs
    pub fn encode(&self, text: &str, add_special_tokens: bool) -> Result<Vec<TokenId>> {
        // Normalize text
        let normalized = self.normalizer.normalize(text);

        // Apply morphological encoding (PUA substitution)
        let encoded = self.encoder.encode(&normalized);

        // Convert to bytes
        let bytes = encoded.as_bytes().to_vec();

        // Apply BPE
        let tokens = self.bpe_encode(bytes)?;

        // Convert to token IDs
        let mut ids: Vec<TokenId> = tokens
            .into_iter()
            .map(|t| *self.vocab.get(&t).unwrap_or(&self.special_tokens.unk))
            .collect();

        // Add special tokens if requested
        if add_special_tokens {
            ids.insert(0, self.special_tokens.bos);
            ids.push(self.special_tokens.eos);
        }

        Ok(ids)
    }

    /// Decode token IDs to text
    pub fn decode(&self, ids: &[TokenId], skip_special_tokens: bool) -> Result<String> {
        let mut bytes = Vec::new();

        for &id in ids {
            // Skip special tokens if requested
            if skip_special_tokens {
                if id == self.special_tokens.pad
                    || id == self.special_tokens.bos
                    || id == self.special_tokens.eos
                {
                    continue;
                }
            }

            if let Some(token_bytes) = self.reverse_vocab.get(&id) {
                bytes.extend_from_slice(token_bytes);
            } else if id != self.special_tokens.unk {
                // Unknown token, skip or handle
                continue;
            }
        }

        // Convert bytes to string
        let raw_text = String::from_utf8_lossy(&bytes).to_string();

        // Apply smart decoding (PUA -> morphemes, fix boundaries)
        let decoded = self.decoder.decode(&raw_text);

        Ok(decoded)
    }

    /// Tokenize to subword strings
    pub fn tokenize(&self, text: &str) -> Result<Vec<String>> {
        let ids = self.encode(text, false)?;
        let mut tokens = Vec::new();

        for id in ids {
            if let Some(bytes) = self.reverse_vocab.get(&id) {
                tokens.push(String::from_utf8_lossy(bytes).to_string());
            }
        }

        Ok(tokens)
    }

    /// Internal BPE encoding
    fn bpe_encode(&self, bytes: Vec<u8>) -> Result<Vec<Vec<u8>>> {
        if bytes.is_empty() {
            return Ok(vec![]);
        }

        // Start with individual bytes as tokens
        let mut tokens: Vec<Vec<u8>> = bytes.iter().map(|&b| vec![b]).collect();

        // Iteratively apply merges
        loop {
            let mut best_merge: Option<(usize, Vec<u8>)> = None;
            let mut best_rank = u32::MAX;

            // Find the best (lowest rank) applicable merge
            for i in 0..tokens.len().saturating_sub(1) {
                let pair = (tokens[i].clone(), tokens[i + 1].clone());
                if let Some(result) = self.merge_lookup.get(&pair) {
                    // Find the rank of this merge
                    if let Some(merge) = self.merges.iter().find(|m| m.pair == pair) {
                        if merge.rank < best_rank {
                            best_rank = merge.rank;
                            best_merge = Some((i, result.clone()));
                        }
                    }
                }
            }

            // Apply the best merge or stop if none found
            match best_merge {
                Some((idx, result)) => {
                    tokens[idx] = result;
                    tokens.remove(idx + 1);
                }
                None => break,
            }
        }

        Ok(tokens)
    }

    /// Load from directory
    pub fn from_dir(path: &str, license_key: Option<&str>) -> Result<Self> {
        use std::fs;
        use std::path::Path;

        let base = Path::new(path);

        // Load vocab
        let vocab_path = base.join("vocab.json");
        let vocab_data = fs::read_to_string(&vocab_path)?;
        let vocab: HashMap<String, TokenId> = serde_json::from_str(&vocab_data)?;
        let vocab: HashMap<Vec<u8>, TokenId> =
            vocab.into_iter().map(|(k, v)| (k.into_bytes(), v)).collect();

        // Load merges
        let merges_path = base.join("merges.json");
        let merges_data = fs::read_to_string(&merges_path)?;
        let merges: Vec<MergeRule> = serde_json::from_str(&merges_data)?;

        // Load morpheme map
        let morf_path = base.join("morphemes.json");
        let morf_data = fs::read_to_string(&morf_path)?;
        let morpheme_map: HashMap<String, char> = serde_json::from_str(&morf_data)?;

        let tokenizer = Self::new(vocab, merges, morpheme_map)?;

        // Validate license if provided
        if let Some(key) = license_key {
            let license = License::from_key(key)?;
            tokenizer.set_license(license)?;
        }

        Ok(tokenizer)
    }

    /// Save to directory
    pub fn save(&self, path: &str, _encrypt: bool) -> Result<()> {
        use std::fs;
        use std::path::Path;

        let base = Path::new(path);
        fs::create_dir_all(base)?;

        // Save vocab
        let vocab: HashMap<String, TokenId> = self
            .vocab
            .iter()
            .map(|(k, v)| (String::from_utf8_lossy(k).to_string(), *v))
            .collect();
        let vocab_json = serde_json::to_string_pretty(&vocab)?;
        fs::write(base.join("vocab.json"), vocab_json)?;

        // Save merges
        let merges_json = serde_json::to_string_pretty(&*self.merges)?;
        fs::write(base.join("merges.json"), merges_json)?;

        // Save morpheme map
        let morf_json = serde_json::to_string_pretty(self.morphology.get_morpheme_map())?;
        fs::write(base.join("morphemes.json"), morf_json)?;

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_basic_tokenization() {
        let vocab: HashMap<Vec<u8>, TokenId> = vec![
            (vec![b'h', b'e', b'l', b'l', b'o'], 100),
            (vec![b' '], 101),
            (vec![b'w', b'o', b'r', b'l', b'd'], 102),
        ]
        .into_iter()
        .collect();

        let merges = vec![];
        let morpheme_map = HashMap::new();

        let tokenizer = SuhailTokenizer::new(vocab, merges, morpheme_map).unwrap();
        assert!(tokenizer.vocab_size() >= 3);
    }
}
