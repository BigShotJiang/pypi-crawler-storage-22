//! Trie (prefix tree) for efficient greedy longest-match encoding
//!
//! This implements a byte-level trie that finds the longest matching
//! morpheme prefix, enabling O(n) encoding complexity.

use ahash::AHashMap;
use std::collections::HashMap;

/// Trie node for byte-level matching
#[derive(Debug, Clone, Default)]
pub struct TrieNode {
    /// Children indexed by byte value
    children: AHashMap<u8, TrieNode>,
    /// Value at this node (if this is end of a pattern)
    value: Option<String>,
}

impl TrieNode {
    pub fn new() -> Self {
        Self {
            children: AHashMap::new(),
            value: None,
        }
    }
}

/// Byte-level trie for greedy longest-match encoding
#[derive(Debug, Clone)]
pub struct ByteTrie {
    root: TrieNode,
    num_patterns: usize,
}

impl ByteTrie {
    /// Create a new empty trie
    pub fn new() -> Self {
        Self {
            root: TrieNode::new(),
            num_patterns: 0,
        }
    }

    /// Build trie from a mapping of patterns to replacements
    pub fn from_map(map: &HashMap<String, String>) -> Self {
        let mut trie = Self::new();
        for (pattern, replacement) in map {
            trie.insert(pattern, replacement);
        }
        trie
    }

    /// Insert a pattern with its replacement value
    pub fn insert(&mut self, pattern: &str, value: &str) {
        let bytes = pattern.as_bytes();
        let mut current = &mut self.root;

        for &byte in bytes {
            current = current.children.entry(byte).or_insert_with(TrieNode::new);
        }

        current.value = Some(value.to_string());
        self.num_patterns += 1;
    }

    /// Find the longest matching prefix starting at position in input bytes
    /// Returns (match_length, replacement_value) or None if no match
    pub fn find_longest_match(&self, bytes: &[u8], start: usize) -> Option<(usize, &str)> {
        let mut current = &self.root;
        let mut last_match: Option<(usize, &str)> = None;
        let mut pos = start;

        while pos < bytes.len() {
            let byte = bytes[pos];

            match current.children.get(&byte) {
                Some(child) => {
                    current = child;
                    pos += 1;

                    // Check if this is a complete match
                    if let Some(ref value) = current.value {
                        last_match = Some((pos - start, value.as_str()));
                    }
                }
                None => break,
            }
        }

        last_match
    }

    /// Rewrite bytes using greedy longest-match algorithm
    pub fn rewrite(&self, input: &[u8]) -> Vec<u8> {
        if self.num_patterns == 0 {
            return input.to_vec();
        }

        let mut result = Vec::with_capacity(input.len());
        let mut i = 0;

        while i < input.len() {
            match self.find_longest_match(input, i) {
                Some((match_len, replacement)) => {
                    result.extend_from_slice(replacement.as_bytes());
                    i += match_len;
                }
                None => {
                    result.push(input[i]);
                    i += 1;
                }
            }
        }

        result
    }

    /// Rewrite text string
    pub fn rewrite_text(&self, text: &str) -> String {
        let rewritten = self.rewrite(text.as_bytes());
        String::from_utf8_lossy(&rewritten).into_owned()
    }

    /// Number of patterns in the trie
    pub fn len(&self) -> usize {
        self.num_patterns
    }

    /// Check if trie is empty
    pub fn is_empty(&self) -> bool {
        self.num_patterns == 0
    }
}

impl Default for ByteTrie {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_basic_insert_and_match() {
        let mut trie = ByteTrie::new();
        trie.insert("hello", "H");
        trie.insert("hell", "h");

        let input = b"hello world";
        let result = trie.find_longest_match(input, 0);
        assert_eq!(result, Some((5, "H"))); // "hello" is longer
    }

    #[test]
    fn test_greedy_rewrite() {
        let mut map = HashMap::new();
        map.insert("ال".to_string(), "\u{E000}".to_string());
        map.insert("كتاب".to_string(), "\u{E001}".to_string());

        let trie = ByteTrie::from_map(&map);
        let result = trie.rewrite_text("الكتاب");

        assert_eq!(result, "\u{E000}\u{E001}");
    }

    #[test]
    fn test_no_match_passthrough() {
        let mut map = HashMap::new();
        map.insert("foo".to_string(), "F".to_string());

        let trie = ByteTrie::from_map(&map);
        let result = trie.rewrite_text("bar");

        assert_eq!(result, "bar");
    }

    #[test]
    fn test_arabic_morphemes() {
        let mut map = HashMap::new();
        map.insert("و".to_string(), "\u{E000}".to_string());
        map.insert("ال".to_string(), "\u{E001}".to_string());
        map.insert("معلم".to_string(), "\u{E002}".to_string());

        let trie = ByteTrie::from_map(&map);
        let result = trie.rewrite_text("والمعلم");

        // Should match: و + ال + معلم
        assert_eq!(result, "\u{E000}\u{E001}\u{E002}");
    }
}
