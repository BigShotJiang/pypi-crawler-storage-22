"""Version file for deepnote-toolkit."""

__version__ = "2.1.1"
