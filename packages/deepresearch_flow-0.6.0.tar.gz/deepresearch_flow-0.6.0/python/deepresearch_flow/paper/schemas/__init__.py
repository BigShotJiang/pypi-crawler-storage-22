"""Built-in JSON schemas."""
