"""Built-in prompt templates."""
