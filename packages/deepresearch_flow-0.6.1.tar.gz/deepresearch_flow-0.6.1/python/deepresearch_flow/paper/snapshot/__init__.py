"""Snapshot build + API utilities for production deployments."""

from __future__ import annotations

