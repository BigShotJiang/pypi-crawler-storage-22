"""Unit tests for snapshot build + API helpers."""

