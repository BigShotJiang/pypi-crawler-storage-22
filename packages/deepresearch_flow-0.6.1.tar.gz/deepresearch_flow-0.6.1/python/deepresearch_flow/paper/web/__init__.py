"""Web viewer for paper databases."""

