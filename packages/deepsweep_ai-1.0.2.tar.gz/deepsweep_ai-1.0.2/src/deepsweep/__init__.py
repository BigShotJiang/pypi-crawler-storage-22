"""
DeepSweep - Security validation for AI coding assistants.

You don't need to understand the code to secure it.

Validate configurations for Cursor, Copilot, Claude Code, Windsurf,
and MCP servers before they execute.
"""

from deepsweep.exceptions import DeepSweepError, PatternError, ValidationError
from deepsweep.models import Finding, Severity, ValidationResult
from deepsweep.validator import validate_content, validate_path

__version__ = "1.0.2"
__all__ = [
    "DeepSweepError",
    "Finding",
    "PatternError",
    "Severity",
    "ValidationError",
    "ValidationResult",
    "__version__",
    "validate_content",
    "validate_path",
]
