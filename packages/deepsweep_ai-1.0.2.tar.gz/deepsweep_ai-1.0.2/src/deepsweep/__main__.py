"""Entry point for python -m deepsweep."""

from deepsweep.cli import main

if __name__ == "__main__":
    main()
