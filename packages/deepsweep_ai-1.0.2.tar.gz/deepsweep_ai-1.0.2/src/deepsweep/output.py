"""
CLI output formatting for DeepSweep.

Design Standards:
- NO EMOJIS - ASCII symbols only
- Optimistic messaging (Wiz approach)
- NO_COLOR support (per no-color.org)
- Collaborative, enabling tone
"""

import os
import sys
from dataclasses import dataclass

from deepsweep.constants import (
    DOCS_URL,
    PRODUCT_NAME,
    SYMBOL_FAIL,
    SYMBOL_INFO,
    SYMBOL_PASS,
    SYMBOL_SKIP,
    SYMBOL_WARN,
    TAGLINE,
    Colors,
)
from deepsweep.models import Finding, Severity, ValidationResult


def supports_color() -> bool:
    """
    Check if terminal supports color output.

    Respects NO_COLOR spec: https://no-color.org/
    """
    # NO_COLOR takes absolute precedence
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("DEEPSWEEP_NO_COLOR"):
        return False

    # Check if stdout is a TTY
    if not hasattr(sys.stdout, "isatty"):
        return False
    if not sys.stdout.isatty():
        return False

    # Dumb terminals don't support color
    return os.environ.get("TERM") != "dumb"


@dataclass
class OutputConfig:
    """Configuration for output formatting."""

    use_color: bool = True
    verbose: bool = False

    def __post_init__(self) -> None:
        """Auto-detect color support if enabled."""
        if self.use_color:
            self.use_color = supports_color()


class OutputFormatter:
    """
    Format CLI output with optimistic messaging.

    Design principles:
    - NO EMOJIS - ASCII symbols only
    - Collaborative tone ("let's" not "you must")
    - Focus on path forward, not doom
    - Celebrate success, don't just confirm
    """

    def __init__(self, config: OutputConfig | None = None) -> None:
        self.config = config or OutputConfig()

    def _colorize(self, text: str, severity: Severity) -> str:
        """Apply color to text if supported."""
        if not self.config.use_color:
            return text

        color_map = {
            Severity.CRITICAL: Colors.CRITICAL,
            Severity.HIGH: Colors.HIGH,
            Severity.MEDIUM: Colors.MEDIUM,
            Severity.LOW: Colors.LOW,
            Severity.INFO: Colors.INFO,
        }

        color = color_map.get(severity, "")
        return f"{color}{text}{Colors.RESET}"

    def _colorize_pass(self, text: str) -> str:
        """Apply pass (green) color."""
        if not self.config.use_color:
            return text
        return f"{Colors.PASS}{text}{Colors.RESET}"

    def format_header(self, version: str) -> str:
        """
        Format CLI header with PMF-validated messaging.

        This is the first thing users see - set the encouraging tone.
        """
        return f"""
{PRODUCT_NAME} v{version}
{TAGLINE}
"""

    def format_validation_start(self, path: str, pattern_count: int) -> str:
        """Format validation initialization message."""
        return f"""Checking {path}...
  {SYMBOL_INFO} Loaded {pattern_count} security rules
  {SYMBOL_INFO} Reviewing AI assistant configurations
"""

    def format_file_pass(self, file_path: str) -> str:
        """Format a passing file check."""
        text = f"{SYMBOL_PASS} {file_path}"
        return self._colorize_pass(text)

    def format_file_skip(self, file_path: str, reason: str) -> str:
        """Format a skipped file."""
        return f"{SYMBOL_SKIP} {file_path} ({reason})"

    def format_finding(self, finding: Finding) -> str:
        """
        Format a single finding.

        Default mode: Plain English (vibe coder friendly)
        Verbose mode: Technical details (CWE, CVSS, Pattern IDs)
        """
        from deepsweep import plain_english

        symbol = (
            SYMBOL_FAIL if finding.severity in (Severity.CRITICAL, Severity.HIGH) else SYMBOL_WARN
        )

        # PLAIN ENGLISH MODE (Default)
        if not self.config.verbose:
            severity_label = finding.severity.value.upper()
            header = f"[{severity_label}] {finding.file_path}:{finding.line}"
            header = self._colorize(header, finding.severity)

            lines = [header]

            # Get Plain English explanation
            pe_mapping = plain_english.get_plain_english(finding.pattern_id)
            if pe_mapping:
                lines.append(f"   {pe_mapping['plain_english']}")
                lines.append("")
                lines.append(f"   Why it matters: {pe_mapping['why_it_matters']}")
                lines.append("")
                lines.append(f"   Fix: {pe_mapping['fix_template'].format(file=finding.file_path, line=finding.line)}")
                lines.append("")
                # Add copy-paste prompt
                lines.append("   [Copy this to fix it with your AI assistant:]")
                fix_prompt = plain_english.format_fix_prompt(
                    finding.pattern_id, finding.file_path, finding.line
                )
                if fix_prompt:
                    lines.append(f'   "{fix_prompt}"')
            else:
                # Fallback if no Plain English mapping
                lines.append(f"   {finding.message}")
                if finding.remediation:
                    lines.append(f"   Fix: {finding.remediation}")

            return "\n".join(lines)

        # VERBOSE MODE (Technical details)
        header = f"{symbol} {finding.file_path}:{finding.line}"
        header = self._colorize(header, finding.severity)

        lines = [header]
        lines.append(f"  Pattern: {finding.pattern_id}")
        lines.append(f"  Severity: {finding.severity.value.upper()}")
        lines.append(f"  Message: {finding.message}")

        if finding.cve:
            lines.append(f"  CVE: {finding.cve}")

        if finding.owasp:
            lines.append(f"  OWASP: {finding.owasp}")

        if finding.remediation:
            lines.append(f"  Remediation: {finding.remediation}")

        # Include Plain English in verbose mode too
        pe_mapping = plain_english.get_plain_english(finding.pattern_id)
        if pe_mapping:
            lines.append(f"  Plain English: {pe_mapping['plain_english']}")

        return "\n".join(lines)

    def format_summary(self, result: ValidationResult, reputation=None) -> str:
        """
        Format summary with Plain English messaging and reputation information.

        Uses grade-based contextual messages that are encouraging and actionable.
        Includes reputation score, tier, and streak if available.
        """
        from deepsweep import plain_english

        score = result.score
        grade = result.grade_letter
        total = result.finding_count

        # Get contextual message based on grade
        status_message = plain_english.get_severity_message(grade, score, total)

        # Determine severity for coloring
        if score >= 90:
            severity = Severity.INFO
        elif score >= 70:
            severity = Severity.MEDIUM
        else:
            severity = Severity.HIGH

        # Build grade line with score
        grade_text = f"Grade: {grade} ({score}/100)"
        if score >= 90:
            grade_line = self._colorize_pass(grade_text)
        else:
            grade_line = self._colorize(grade_text, severity)

        # Add reputation information if available
        reputation_lines = []
        if reputation:
            tier_emoji = {
                "diamond": "💎",
                "platinum": "🏆",
                "gold": "🥇",
                "silver": "🥈",
                "bronze": "🥉",
                "unverified": "🔰",
            }.get(reputation.tier, "")

            reputation_lines.append(f"Tier: {tier_emoji} {reputation.tier.title()}")

            if reputation.streak_days > 0:
                streak_emoji = "🔥" if reputation.streak_days >= 7 else "⚡"
                reputation_lines.append(f"Streak: {streak_emoji} {reputation.streak_days} day{'s' if reputation.streak_days != 1 else ''}")

            if reputation.percentile:
                reputation_lines.append(f"Better than {reputation.percentile}% of users")

        summary_parts = [
            "─────────────────────────────────────────────────────",
            grade_line,
            status_message,
        ]

        if reputation_lines:
            summary_parts.append("")
            summary_parts.extend(reputation_lines)

        summary_parts.append("─────────────────────────────────────────────────────")

        return "\n".join(summary_parts)

    def format_next_steps(self, result: ValidationResult) -> str:
        """
        Format next steps with encouraging, actionable guidance.

        Plain English mode: Focus on what to do next
        Verbose mode: Include technical resources
        """
        if not result.has_findings:
            return f"""
{result.finding_count} files checked • No issues found • Ship with confidence

Next steps:
  • Add to CI/CD: deepsweep validate . --fail-on high
  • Generate badge: deepsweep badge
"""

        # Contextual guidance based on findings
        total = result.finding_count
        return f"""
{len(result.files)} files checked • {total} {'issue' if total == 1 else 'issues'} found

Fix these issues to reach Grade A
"""

    def format_json_output(self, result: ValidationResult) -> str:
        """Format result as JSON with Plain English fields."""
        import json

        from deepsweep import plain_english

        findings_data = []
        for f in result.all_findings:
            pe_mapping = plain_english.get_plain_english(f.pattern_id)
            finding_dict = {
                "severity": f.severity.value,
                "file": f.file_path,
                "line": f.line,
                "message": f.message,
                "pattern_id": f.pattern_id,
                "cve": f.cve,
                "owasp": f.owasp,
                "remediation": f.remediation,
            }

            # Add Plain English fields
            if pe_mapping:
                finding_dict["plain_english"] = pe_mapping["plain_english"]
                finding_dict["why_it_matters"] = pe_mapping["why_it_matters"]
                finding_dict["fix_prompt"] = plain_english.format_fix_prompt(
                    f.pattern_id, f.file_path, f.line
                )

            findings_data.append(finding_dict)

        data = {
            "version": "1.0.2",
            "score": result.score,
            "grade": result.grade_letter,
            "summary": plain_english.get_severity_message(
                result.grade_letter, result.score, result.finding_count
            ),
            "findings_count": result.finding_count,
            "pattern_count": result.pattern_count,
            "findings": findings_data,
        }

        return json.dumps(data, indent=2)

    def format_sarif_output(self, result: ValidationResult) -> str:
        """Format result as SARIF 2.1.0 for GitHub Security tab."""
        import json

        sarif = {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": PRODUCT_NAME,
                            "version": "1.0.2",
                            "informationUri": DOCS_URL,
                            "rules": [
                                {
                                    "id": f.pattern_id,
                                    "name": f.pattern_id,
                                    "shortDescription": {"text": f.message.split(":")[0]},
                                    "defaultConfiguration": {
                                        "level": self._sarif_level(f.severity)
                                    },
                                }
                                for f in result.all_findings
                            ],
                        }
                    },
                    "results": [
                        {
                            "ruleId": f.pattern_id,
                            "level": self._sarif_level(f.severity),
                            "message": {"text": f.message},
                            "locations": [
                                {
                                    "physicalLocation": {
                                        "artifactLocation": {"uri": f.file_path},
                                        "region": {"startLine": f.line},
                                    }
                                }
                            ],
                        }
                        for f in result.all_findings
                    ],
                }
            ],
        }

        return json.dumps(sarif, indent=2)

    def _sarif_level(self, severity: Severity) -> str:
        """Convert severity to SARIF level."""
        if severity in (Severity.CRITICAL, Severity.HIGH):
            return "error"
        elif severity == Severity.MEDIUM:
            return "warning"
        else:
            return "note"


# Additional utility functions for simplified CLI output

SEVERITY_STYLES = {
    "critical": {"fg": "red", "bold": True},
    "high": {"fg": "yellow", "bold": True},
    "medium": {"fg": "cyan", "bold": False},
    "low": {"fg": "white", "bold": False},
}

GRADE_COLORS = {"A": "green", "B": "green", "C": "yellow", "D": "red", "F": "red"}


def score_bar(score: int, width: int = 30) -> str:
    """Create a visual score bar."""
    try:
        import click
        filled = int((score / 100) * width)
        empty = width - filled
        color = "green" if score >= 80 else ("yellow" if score >= 60 else "red")
        bar = click.style("█" * filled, fg=color) + click.style("░" * empty, dim=True)
        return f"{bar} {score}/100"
    except ImportError:
        # Fallback if click is not available
        filled = int((score / 100) * width)
        empty = width - filled
        bar = "█" * filled + "░" * empty
        return f"{bar} {score}/100"


def format_grade(grade: str) -> str:
    """Format grade with color."""
    try:
        import click
        color = GRADE_COLORS.get(grade, "white")
        return click.style(grade, fg=color, bold=True)
    except ImportError:
        return grade


def format_finding(
    pattern_id: str,
    severity: str,
    message: str,
    file: str | None = None,
    line: int | None = None,
    fix_suggestion: str | None = None,
    show_fix: bool = False,
) -> list[str]:
    """Format a finding for display."""
    try:
        import click
        style = SEVERITY_STYLES.get(severity, SEVERITY_STYLES["medium"])
        lines = []

        severity_text = click.style(f"[{severity.upper()}]", fg=style["fg"], bold=style["bold"])
        location = f" ({file}:{line})" if file and line else (f" ({file})" if file else "")
        lines.append(f"  {severity_text} {pattern_id}: {message}{location}")

        if show_fix and fix_suggestion:
            lines.append(click.style(f"    > {fix_suggestion}", fg="green"))

        return lines
    except ImportError:
        lines = []
        severity_text = f"[{severity.upper()}]"
        location = f" ({file}:{line})" if file and line else (f" ({file})" if file else "")
        lines.append(f"  {severity_text} {pattern_id}: {message}{location}")
        if show_fix and fix_suggestion:
            lines.append(f"    > {fix_suggestion}")
        return lines


def print_summary(score: int, grade: str, finding_count: int, **_kwargs):
    """Print validation summary."""
    try:
        import click
        click.echo()
        click.echo(click.style("DEEPSWEEP Security Report", bold=True))
        click.echo("-" * 50)
        click.echo()
        click.echo(f"Score: {score_bar(score)}")
        click.echo(f"Grade: {format_grade(grade)}")
        click.echo()

        if finding_count == 0:
            click.echo(click.style("No security issues found", fg="green", bold=True))
        else:
            click.echo(f"Found {finding_count} issue(s)")
    except ImportError:
        print()
        print("DEEPSWEEP Security Report")
        print("-" * 50)
        print()
        print(f"Score: {score_bar(score)}")
        print(f"Grade: {format_grade(grade)}")
        print()
        if finding_count == 0:
            print("No security issues found")
        else:
            print(f"Found {finding_count} issue(s)")


def print_next_steps(score: int, has_fix_flag: bool = False):
    """Print next steps based on score."""
    try:
        import click
        click.echo()
        click.echo("-" * 50)

        if score == 100:
            click.echo(click.style("Your AI assistant configuration is secure.", fg="green"))
        elif score >= 80:
            click.echo("Good security posture. Address remaining issues when possible.")
        elif score >= 60:
            click.echo("Some issues need attention. Run with --fix for suggestions.")
        else:
            click.echo(click.style("Critical issues found. Address immediately.", fg="red"))

        if not has_fix_flag and score < 100:
            click.echo()
            click.echo("Run with " + click.style("--fix", bold=True) + " for remediation suggestions")
        click.echo()
    except ImportError:
        print()
        print("-" * 50)
        if score == 100:
            print("Your AI assistant configuration is secure.")
        elif score >= 80:
            print("Good security posture. Address remaining issues when possible.")
        elif score >= 60:
            print("Some issues need attention. Run with --fix for suggestions.")
        else:
            print("Critical issues found. Address immediately.")
        if not has_fix_flag and score < 100:
            print()
            print("Run with --fix for remediation suggestions")
        print()
