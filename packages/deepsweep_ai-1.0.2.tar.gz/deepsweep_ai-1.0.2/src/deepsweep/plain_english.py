"""
Plain English mappings for DeepSweep patterns.

Designed for vibe coders who cannot read code and don't know security terminology.
PMF-validated message: "You don't need to understand the code to secure it."

Each pattern maps to:
- plain_english: What's happening in simple terms
- why_it_matters: Real-world impact they care about
- fix_template: Copy-paste prompt for their AI assistant
"""

from typing import Final

# Plain English mapping for all DeepSweep patterns
PLAIN_ENGLISH_MAP: Final[dict[str, dict[str, str]]] = {
    "CURSOR-RULES-001": {
        "plain_english": "Your AI assistant can be tricked into ignoring safety rules.",
        "why_it_matters": "Someone could manipulate your AI to write malicious code without you knowing.",
        "fix_template": "Remove any instructions in {file} around line {line} that tell the AI to ignore previous instructions or override safety settings.",
    },
    "CURSOR-RULES-002": {
        "plain_english": "Your AI assistant might pretend to be someone else.",
        "why_it_matters": "The AI could act with different permissions than intended, accessing things it shouldn't.",
        "fix_template": "In {file} line {line}, remove instructions that change the AI's role or identity. Keep it as a coding assistant only.",
    },
    "CURSOR-RULES-003": {
        "plain_english": "Your AI assistant could send your code or data to external servers.",
        "why_it_matters": "Your proprietary code, API keys, or sensitive data could be stolen.",
        "fix_template": "Remove the external URL or data transmission instruction in {file} at line {line}. AI assistants should never send data outside your computer.",
    },
    "CURSOR-RULES-004": {
        "plain_english": "There are hidden characters in your configuration that look invisible but change behavior.",
        "why_it_matters": "Attackers use invisible characters to hide malicious instructions you can't see.",
        "fix_template": "In {file} around line {line}, delete the line and retype it. Don't copy-paste - hidden characters will come with it.",
    },
    "COPILOT-INJ-001": {
        "plain_english": "Your AI coding assistant's safety features are being turned off.",
        "why_it_matters": "The AI could suggest dangerous code without warning you.",
        "fix_template": "Remove the instruction in {file} line {line} that disables safety checks or filters.",
    },
    "COPILOT-INJ-002": {
        "plain_english": "Your AI is being instructed to inject malicious code into your project.",
        "why_it_matters": "Backdoors or malware could be added to your codebase without you noticing.",
        "fix_template": "Delete the instruction in {file} at line {line} that tells the AI to add code. Review any recent AI-suggested changes.",
    },
    "COPILOT-INJ-003": {
        "plain_english": "Your configuration contains a known jailbreak prompt used by attackers.",
        "why_it_matters": "This is a proven technique to bypass AI safety measures.",
        "fix_template": "Remove the entire section in {file} around line {line}. This is a known attack pattern.",
    },
    "CLAUDE-WS-001": {
        "plain_english": "Your AI workspace has authentication turned off.",
        "why_it_matters": "Anyone on your network can access and control your AI assistant.",
        "fix_template": "In {file} line {line}, enable authentication. Set a strong password or API key requirement.",
    },
    "CLAUDE-WS-002": {
        "plain_english": "Your AI workspace is accepting connections from the entire internet.",
        "why_it_matters": "Attackers from anywhere can try to access your AI assistant and your data.",
        "fix_template": "In {file} at line {line}, change the bind address from 0.0.0.0 to 127.0.0.1 (localhost only).",
    },
    "CLAUDE-WS-003": {
        "plain_english": "Your AI workspace allows requests from any website.",
        "why_it_matters": "Malicious websites you visit could send commands to your AI assistant.",
        "fix_template": "In {file} line {line}, restrict CORS to specific domains you trust, or remove the wildcard (*).",
    },
    "MCP-POISON-001": {
        "plain_english": "Your AI is using a plugin from an untrusted source.",
        "why_it_matters": "The plugin could steal your data, install malware, or compromise your system.",
        "fix_template": "In {file} line {line}, either remove this MCP server or verify it's from a trusted publisher before using it.",
    },
    "MCP-POISON-002": {
        "plain_english": "Your AI plugin has dangerous command-line arguments.",
        "why_it_matters": "These arguments could allow the plugin to execute harmful commands on your computer.",
        "fix_template": "Remove the dangerous command-line arguments from {file} line {line}. Check the plugin documentation for safe options.",
    },
    "MCP-POISON-003": {
        "plain_english": "Your AI plugin doesn't have a version pinned.",
        "why_it_matters": "Automatic updates could install compromised versions without your knowledge.",
        "fix_template": "In {file} line {line}, pin the MCP server to a specific version (e.g., @server@1.2.3 instead of @server@latest).",
    },
    "MCP-POISON-004": {
        "plain_english": "Your AI plugin is set to automatically update to the latest version.",
        "why_it_matters": "If the plugin gets compromised, you'll automatically install the malicious version.",
        "fix_template": "In {file} at line {line}, replace '@latest' with a specific version number you've verified is safe.",
    },
    "WINDSURF-EXFIL-001": {
        "plain_english": "Your AI assistant is configured to send data to an external server.",
        "why_it_matters": "Your code, credentials, or project data could be exfiltrated to attackers.",
        "fix_template": "Remove the external endpoint configuration from {file} line {line}. AI assistants should work locally only.",
    },
    "WINDSURF-EXFIL-002": {
        "plain_english": "Your AI workspace has file access restrictions disabled.",
        "why_it_matters": "The AI can read sensitive files like passwords, SSH keys, or environment variables.",
        "fix_template": "In {file} line {line}, enable file access restrictions. Limit the AI to your project directory only.",
    },
}


def get_plain_english(pattern_id: str) -> dict[str, str] | None:
    """Get Plain English mapping for a pattern ID."""
    return PLAIN_ENGLISH_MAP.get(pattern_id)


def format_fix_prompt(pattern_id: str, file: str, line: int) -> str | None:
    """
    Format a copy-paste ready fix prompt for AI assistants.

    Returns a prompt that vibe coders can paste directly into their AI
    assistant to fix the issue.
    """
    mapping = get_plain_english(pattern_id)
    if not mapping:
        return None

    return mapping["fix_template"].format(file=file, line=line)


def get_severity_message(grade: str, score: int, finding_count: int) -> str:
    """
    Get contextual message based on grade.

    Designed to be encouraging and actionable, not alarmist.
    """
    if grade == "A":
        if score == 100:
            return "Perfect score. Your setup is secure."
        return "Ship with confidence. Your setup is secure."

    elif grade == "B":
        if finding_count == 1:
            return "Almost there. 1 item needs attention."
        return f"Almost there. {finding_count} items need attention."

    elif grade == "C":
        if finding_count == 1:
            return "Some issues to address before shipping."
        return f"Some issues to address before shipping. ({finding_count} items)"

    elif grade == "D":
        return f"Several issues found. Fix these before shipping. ({finding_count} items)"

    else:  # F
        return f"Critical issues found. Do not ship until fixed. ({finding_count} items)"
