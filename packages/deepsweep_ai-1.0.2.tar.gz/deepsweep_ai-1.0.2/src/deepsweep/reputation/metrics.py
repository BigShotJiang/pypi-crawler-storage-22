"""PostHog metrics integration for reputation system."""

import contextlib
from enum import Enum
from typing import Any


class ReputationEvent(Enum):
    """Reputation-related events for viral growth tracking."""

    SCORE_UPDATED = "score_updated"
    TIER_PROMOTED = "tier_promoted"
    STREAK_EXTENDED = "streak_extended"
    STREAK_BROKEN = "streak_broken"
    SHARE_PROMPT_SHOWN = "share_prompt_shown"
    SHARE_CREATED = "share_created"
    SHARE_ACTION_TAKEN = "share_action_taken"


def track_score_update(
    previous_score: int,
    new_score: int,
    delta: int,
    tier: str,
    trigger: str = "validation",
) -> None:
    """
    Track score update event.

    Args:
        previous_score: Score before update
        new_score: Score after update
        delta: Change in score
        tier: Current tier
        trigger: What triggered the update (validation, referral_bonus, etc.)
    """
    with contextlib.suppress(Exception):
        from deepsweep.telemetry import track

        track(
            ReputationEvent.SCORE_UPDATED.value,
            {
                "previous_score": previous_score,
                "new_score": new_score,
                "delta": delta,
                "tier": tier,
                "trigger": trigger,
            },
        )


def track_tier_promotion(
    previous_tier: str,
    new_tier: str,
    score: int,
) -> None:
    """
    Track tier promotion event.

    Args:
        previous_tier: Tier before promotion
        new_tier: Tier after promotion
        score: Score at time of promotion
    """
    with contextlib.suppress(Exception):
        from deepsweep.telemetry import track

        track(
            ReputationEvent.TIER_PROMOTED.value,
            {
                "previous_tier": previous_tier,
                "new_tier": new_tier,
                "score": score,
            },
        )


def track_streak(
    event_type: str,
    streak_days: int,
    previous_streak: int | None = None,
) -> None:
    """
    Track streak events.

    Args:
        event_type: "extended" or "broken"
        streak_days: Current streak count
        previous_streak: Previous streak count (for broken streaks)
    """
    with contextlib.suppress(Exception):
        from deepsweep.telemetry import track

        event = (
            ReputationEvent.STREAK_EXTENDED
            if event_type == "extended"
            else ReputationEvent.STREAK_BROKEN
        )

        properties: dict[str, Any] = {"streak_days": streak_days}
        if previous_streak is not None:
            properties["previous_streak"] = previous_streak

        track(event.value, properties)


def track_share_prompt(
    score: int,
    tier: str,
    context: str = "post_validation",
) -> None:
    """
    Track when share prompt is shown.

    Args:
        score: Current score
        tier: Current tier
        context: Where prompt was shown (post_validation, dashboard, cli)
    """
    with contextlib.suppress(Exception):
        from deepsweep.telemetry import track

        track(
            ReputationEvent.SHARE_PROMPT_SHOWN.value,
            {
                "score": score,
                "tier": tier,
                "context": context,
            },
        )


def track_share_action(
    action: str,
    platform: str,
    score: int,
    tier: str,
) -> None:
    """
    Track when user takes share action.

    Args:
        action: Action taken (create, copy, open)
        platform: Platform (twitter, linkedin, github, copy)
        score: Current score
        tier: Current tier
    """
    with contextlib.suppress(Exception):
        from deepsweep.telemetry import track

        track(
            ReputationEvent.SHARE_ACTION_TAKEN.value,
            {
                "action": action,
                "platform": platform,
                "score": score,
                "tier": tier,
            },
        )
