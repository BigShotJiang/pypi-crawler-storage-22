"""
Dynamic badge generation for README sharing.

Generates shields.io badge URLs and markdown for embedding
in README files. Uses correct deepsweep-ai publisher and URLs.
"""

import re
from urllib.parse import quote

from .constants import BADGE_LANDING_URL, EXTENSION_URL, GRADE_COLORS

MAX_PROJECT_NAME_LENGTH = 50


def sanitize_project_name(name: str) -> str:
    """Sanitize project name for URLs."""
    if not name:
        return "project"

    # Keep only alphanumeric, hyphens, underscores
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", name)

    # Collapse multiple hyphens
    safe = re.sub(r"-+", "-", safe)

    # Strip leading/trailing hyphens
    safe = safe.strip("-")

    # Truncate
    if len(safe) > MAX_PROJECT_NAME_LENGTH:
        safe = safe[:MAX_PROJECT_NAME_LENGTH].rstrip("-")

    return safe or "project"


def generate_badge_url(
    grade: str,
    score: int,
    style: str = "flat-square",
) -> str:
    """
    Generate shields.io badge URL.

    Args:
        grade: Letter grade (A+, A, B, etc.).
        score: Numeric score 0-100.
        style: Badge style (flat-square, flat, etc.).

    Returns:
        A shields.io badge URL string.
    """
    color = GRADE_COLORS.get(grade, "6366F1")
    label = "DeepSweep"
    message = quote(f"{grade} ({score})")

    return f"https://img.shields.io/badge/{label}-{message}-{color}?style={style}"


def generate_badge_markdown(
    grade: str,
    score: int,
    project_name: str = "my-project",
) -> str:
    """
    Generate markdown for a README badge.

    Links to DeepSweep badge landing page for conversion.

    Args:
        grade: Letter grade.
        score: Numeric score 0-100.
        project_name: Project name for the profile URL.

    Returns:
        Markdown string like ``[![DeepSweep Security Grade](url)](profile)``.
    """
    safe_name = sanitize_project_name(project_name)
    badge_url = generate_badge_url(grade, score)
    profile_url = f"{BADGE_LANDING_URL}/{quote(safe_name)}"

    return f"[![DeepSweep Security Grade]({badge_url})]({profile_url})"


def generate_badge_html(
    grade: str,
    score: int,
    project_name: str = "my-project",
) -> str:
    """Generate HTML embed for badge."""
    safe_name = sanitize_project_name(project_name)
    badge_url = generate_badge_url(grade, score)
    profile_url = f"{BADGE_LANDING_URL}/{quote(safe_name)}"

    return (
        f'<a href="{profile_url}">'
        f'<img src="{badge_url}" alt="DeepSweep Security Grade" />'
        f"</a>"
    )


def generate_extension_badge() -> str:
    """
    Generate badge linking to OpenVSX extension page.
    For promoting the extension itself.
    """
    return (
        f"[![DeepSweep](https://img.shields.io/badge/"
        f"Validated_with-DeepSweep-6366F1?style=flat-square)]({EXTENSION_URL})"
    )
