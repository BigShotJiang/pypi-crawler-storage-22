"""
Centralized URL constants for share functionality.
CORRECTED: deepsweep-ai publisher, OpenVSX primary.
"""

# Extension identifiers
PUBLISHER = "deepsweep-ai"
EXTENSION_NAME = "deepsweep"
EXTENSION_ID = f"{PUBLISHER}.{EXTENSION_NAME}"

# Extension URLs - OpenVSX is PRIMARY for Cursor/Windsurf users
OPENVSX_URL = "https://open-vsx.org/extension/deepsweep-ai/deepsweep"
VSCODE_MARKETPLACE_URL = (
    "https://marketplace.visualstudio.com/items?itemName=deepsweep-ai.deepsweep"
)

# Use OpenVSX as the primary share URL
EXTENSION_URL = OPENVSX_URL

# Website URLs
WEBSITE_URL = "https://deepsweep.ai"
BADGE_LANDING_URL = "https://deepsweep.ai/badge"

# Grade colors (hex without #)
GRADE_COLORS = {
    "A+": "10B981",
    "A": "22C55E",
    "A-": "34D399",
    "B+": "6366F1",
    "B": "818CF8",
    "B-": "A5B4FC",
    "C+": "F59E0B",
    "C": "FBBF24",
    "C-": "FCD34D",
    "D": "EF4444",
    "F": "DC2626",
}

# Share text templates (no emojis, optimistic tone)
SHARE_TEMPLATES = {
    "high": (
        "Just validated my AI-generated code with DeepSweep "
        "-- Grade {grade}. Ready to ship."
    ),
    "medium": (
        "Validated my code with DeepSweep "
        "-- Grade {grade} ({score}/100). Shipping with confidence."
    ),
    "improving": (
        "Using DeepSweep to validate my AI-generated code. "
        "Grade {grade} and improving."
    ),
    "starting": (
        "Started validating my AI code with DeepSweep. "
        "Building better habits."
    ),
}
