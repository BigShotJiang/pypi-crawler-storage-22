"""
Social media share URL generators.
CORRECTED: OpenVSX primary, deepsweep-ai namespace.
"""

from urllib.parse import quote

from .badge import sanitize_project_name
from .constants import EXTENSION_URL, SHARE_TEMPLATES, WEBSITE_URL


def get_share_text(grade: str, score: int) -> str:
    """
    Generate share text based on grade.
    Optimistic tone, no fear language, no emojis.
    """
    if grade in ("A+", "A"):
        template = SHARE_TEMPLATES["high"]
    elif grade in ("A-", "B+", "B"):
        template = SHARE_TEMPLATES["medium"]
    elif grade in ("B-", "C+", "C"):
        template = SHARE_TEMPLATES["improving"]
    else:
        template = SHARE_TEMPLATES["starting"]

    return template.format(grade=grade, score=score)


# Keep backward-compatible alias
get_share_text_for_grade = get_share_text


def get_share_url(project_name: str) -> str:
    """Get the badge landing page URL for a project."""
    safe_name = sanitize_project_name(project_name)
    return f"{WEBSITE_URL}/badge/{quote(safe_name)}"


def get_twitter_url(text: str, url: str) -> str:
    """Generate Twitter/X share intent URL."""
    # Ensure text fits (280 chars minus URL ~23 chars)
    max_text = 250
    if len(text) > max_text:
        text = text[: max_text - 3] + "..."

    encoded_text = quote(text)
    encoded_url = quote(url)
    return f"https://twitter.com/intent/tweet?text={encoded_text}&url={encoded_url}"


def get_linkedin_url(url: str) -> str:
    """Generate LinkedIn share URL."""
    encoded_url = quote(url)
    return f"https://www.linkedin.com/sharing/share-offsite/?url={encoded_url}"


def get_extension_url() -> str:
    """Get the primary extension URL (OpenVSX)."""
    return EXTENSION_URL
