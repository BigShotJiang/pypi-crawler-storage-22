"""
Post-validation share trigger.

Captures the 1.5-second window after grade reveal when users are most
likely to share. This is the single highest-leverage feature for
viral growth.
"""

import contextlib
import time
import webbrowser
from typing import Any

import click

from deepsweep.constants import SYMBOL_PASS

from .badge import generate_badge_markdown
from .constants import EXTENSION_URL
from .social import get_linkedin_url, get_share_text, get_share_url, get_twitter_url

# Share prompt delay (seconds)
SHARE_DELAY = 1.5


def _copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard (cross-platform, no external deps)."""
    import subprocess

    try:
        if (
            subprocess.run(
                ["which", "pbcopy"],
                capture_output=True,
                check=False,
            ).returncode
            == 0
        ):
            subprocess.run(
                ["pbcopy"],
                input=text.encode(),
                check=True,
                capture_output=True,
            )
            return True

        if (
            subprocess.run(
                ["which", "xclip"],
                capture_output=True,
                check=False,
            ).returncode
            == 0
        ):
            subprocess.run(
                ["xclip", "-selection", "clipboard"],
                input=text.encode(),
                check=True,
                capture_output=True,
            )
            return True

        if (
            subprocess.run(
                ["which", "xsel"],
                capture_output=True,
                check=False,
            ).returncode
            == 0
        ):
            subprocess.run(
                ["xsel", "--clipboard", "--input"],
                input=text.encode(),
                check=True,
                capture_output=True,
            )
            return True

    except (subprocess.CalledProcessError, OSError):
        pass

    return False


def _track_posthog(event_name: str, properties: dict[str, Any] | None = None) -> None:
    """Track event via PostHog (optional tier, never breaks flow)."""
    with contextlib.suppress(Exception):
        from deepsweep.telemetry.events import track

        track(event_name, properties or {})


def show_share_trigger(
    grade: str,
    score: int,
    passed_count: int,
    total_count: int,
    project_name: str = "my-project",
    skip_delay: bool = False,
) -> str | None:
    """
    Show share prompt after validation completes.

    Displays a brief interactive prompt allowing the user to share
    on social media, copy a README badge, or skip.

    Args:
        grade: Letter grade (A, B, C, D, F).
        score: Numeric score 0-100.
        passed_count: Number of checks that passed.
        total_count: Total number of checks run.
        project_name: Name of the project being validated.
        skip_delay: If True, skip the brief pause before showing.

    Returns:
        Action taken as a string, or None if skipped.
    """
    # Brief pause to let the grade sink in
    if not skip_delay:
        time.sleep(SHARE_DELAY)

    # Track that the share prompt was shown
    _track_posthog("share_prompt_shown", {"grade": grade, "score": score})

    with contextlib.suppress(Exception):
        from deepsweep.reputation.metrics import track_share_prompt

        track_share_prompt(score=score, tier="", context="post_validation")

    headline = _get_share_headline(grade)
    subline = f"Your code passed {passed_count} of {total_count} security checks"

    border_color = "green" if grade.startswith("A") else "blue"

    click.echo()
    click.echo(click.style(f"--- Grade {grade} ---", fg=border_color, bold=True))
    click.echo()
    click.echo(click.style(f"  {headline}", bold=True))
    click.echo(f"  {subline}")
    click.echo()
    click.echo("  Share your security grade:")
    click.echo()
    click.echo("    [1] Share on X (Twitter)")
    click.echo("    [2] Share on LinkedIn")
    click.echo("    [3] Copy badge for README")
    click.echo("    [4] Copy extension link")
    click.echo()
    click.echo(click.style("  Press Enter to skip", dim=True))
    click.echo()

    try:
        choice = click.prompt(
            "Your choice",
            default="",
            show_default=False,
        )
    except (EOFError, KeyboardInterrupt):
        _track_posthog("share_skipped", {"grade": grade, "reason": "interrupt"})
        return None

    choice = choice.strip()
    if not choice or choice not in ("1", "2", "3", "4"):
        _track_posthog("share_skipped", {"grade": grade})
        return None

    share_text = get_share_text(grade, score)
    share_url = get_share_url(project_name)
    badge_markdown = generate_badge_markdown(grade, score, project_name)

    action: str | None = None

    if choice == "1":
        url = get_twitter_url(share_text, share_url)
        _open_url(url)
        click.echo()
        click.echo(f"{SYMBOL_PASS} Opening X (Twitter)...")
        click.echo()
        action = "twitter_share"
        _track_posthog("share_action_twitter", {"grade": grade, "score": score})

    elif choice == "2":
        url = get_linkedin_url(share_url)
        _open_url(url)
        click.echo()
        click.echo(f"{SYMBOL_PASS} Opening LinkedIn...")
        click.echo()
        action = "linkedin_share"
        _track_posthog("share_action_linkedin", {"grade": grade, "score": score})

    elif choice == "3":
        copied = _copy_to_clipboard(badge_markdown)
        click.echo()
        if copied:
            click.echo(f"{SYMBOL_PASS} Badge markdown copied to clipboard")
        else:
            click.echo(f"{SYMBOL_PASS} Badge markdown (copy manually):")
        click.echo()
        click.echo(click.style("  Paste this in your README.md:", dim=True))
        click.echo(f"  {badge_markdown}")
        click.echo()
        action = "badge_copied"
        _track_posthog("share_action_badge", {"grade": grade, "score": score})

    elif choice == "4":
        ext_url = EXTENSION_URL
        copied = _copy_to_clipboard(ext_url)
        click.echo()
        if copied:
            click.echo(f"{SYMBOL_PASS} Extension link copied to clipboard")
            click.echo(click.style(f"  {ext_url}", dim=True))
        else:
            click.echo(f"Extension: {ext_url}")
        click.echo()
        action = "extension_copied"
        _track_posthog("share_action_extension", {"grade": grade, "score": score})

    # Track the action via reputation metrics
    if action:
        with contextlib.suppress(Exception):
            from deepsweep.reputation.metrics import track_share_action

            track_share_action(
                action=action,
                platform=action.split("_")[0],
                score=score,
                tier="",
            )

    return action


def _get_share_headline(grade: str) -> str:
    """Get celebratory headline based on grade."""
    if grade in ("A+", "A"):
        return "Your code is ready to ship"
    elif grade in ("A-", "B+", "B"):
        return "Looking good -- ready with minor review"
    elif grade in ("B-", "C+", "C"):
        return "Solid foundation -- a few items to check"
    else:
        return "Room for improvement -- let's fix these"


def _open_url(url: str) -> None:
    """Open URL in default browser."""
    with contextlib.suppress(Exception):
        webbrowser.open(url)
