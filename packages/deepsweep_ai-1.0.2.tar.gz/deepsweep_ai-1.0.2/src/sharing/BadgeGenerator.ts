/**
 * Badge markdown generator for VS Code extension.
 *
 * Generates shields.io badge URLs and markdown for README embedding.
 */

/** Badge color mapping by letter grade. */
const GRADE_COLORS: Record<string, string> = {
  "A+": "10B981",
  A: "22C55E",
  "A-": "34D399",
  "B+": "6366F1",
  B: "818CF8",
  "B-": "A5B4FC",
  "C+": "F59E0B",
  C: "FBBF24",
  "C-": "FCD34D",
  D: "EF4444",
  F: "DC2626",
};

export class BadgeGenerator {
  /**
   * Generate a shields.io badge URL for the given grade and score.
   */
  static getBadgeUrl(grade: string, score: number): string {
    const color = GRADE_COLORS[grade] || "6366F1";
    const message = encodeURIComponent(`${grade} (${score})`);
    return `https://img.shields.io/badge/DeepSweep-${message}-${color}?style=flat-square`;
  }

  /**
   * Generate markdown for a README badge.
   *
   * Returns a string like:
   * ```
   * [![DeepSweep Security Grade](badge-url)](profile-url)
   * ```
   */
  static getMarkdown(
    grade: string,
    score: number,
    projectName: string,
  ): string {
    const badgeUrl = this.getBadgeUrl(grade, score);
    const profileUrl = `https://deepsweep.ai/badge/${encodeURIComponent(projectName)}`;
    return `[![DeepSweep Security Grade](${badgeUrl})](${profileUrl})`;
  }

  /**
   * Generate an HTML embed for the badge.
   */
  static getHtml(grade: string, score: number, projectName: string): string {
    const badgeUrl = this.getBadgeUrl(grade, score);
    const profileUrl = `https://deepsweep.ai/badge/${encodeURIComponent(projectName)}`;
    return `<a href="${profileUrl}"><img src="${badgeUrl}" alt="DeepSweep Security Grade" /></a>`;
  }

  /**
   * Get the color hex code for a given grade.
   */
  static getColor(grade: string): string {
    return GRADE_COLORS[grade] || "6366F1";
  }
}
