/**
 * Social URL generators for VS Code extension.
 *
 * Builds intent URLs for Twitter/X and LinkedIn sharing.
 */

export class SocialShare {
  /**
   * Generate a Twitter/X intent URL.
   */
  static getTwitterUrl(text: string, url: string): string {
    const encodedText = encodeURIComponent(text);
    const encodedUrl = encodeURIComponent(url);
    return `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`;
  }

  /**
   * Generate a LinkedIn share URL.
   */
  static getLinkedInUrl(url: string): string {
    const encodedUrl = encodeURIComponent(url);
    return `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`;
  }

  /**
   * Generate appropriate share text based on grade.
   *
   * Uses optimistic, celebratory tone.
   */
  static getShareText(grade: string, score: number): string {
    if (grade === "A+" || grade === "A") {
      return `Just validated my AI-generated code with @DeepSweepAI -- Grade ${grade}! Ship-ready.`;
    } else if (
      grade === "A-" ||
      grade === "B+" ||
      grade === "B"
    ) {
      return `Validated my code with @DeepSweepAI -- Grade ${grade} (${score}/100). Ready to ship safely.`;
    } else if (
      grade === "B-" ||
      grade === "C+" ||
      grade === "C"
    ) {
      return `Using @DeepSweepAI to validate my AI-generated code. Grade ${grade} -- improving every commit.`;
    } else {
      return "Started validating my AI code with @DeepSweepAI. Every project starts somewhere.";
    }
  }
}
