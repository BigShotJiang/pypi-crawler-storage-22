"""Tests for share trigger and related modules."""

from deepsweep.share.badge import (
    generate_badge_markdown,
    generate_badge_url,
    generate_extension_badge,
    sanitize_project_name,
)
from deepsweep.share.constants import EXTENSION_ID, EXTENSION_URL, OPENVSX_URL
from deepsweep.share.social import (
    get_extension_url,
    get_linkedin_url,
    get_share_text,
    get_share_url,
    get_twitter_url,
)
from deepsweep.share.trigger import (
    _get_share_headline,
    show_share_trigger,
)

# ---------------------------------------------------------------------------
# Constants tests
# ---------------------------------------------------------------------------


class TestConstants:
    """Test that constants are correct."""

    def test_extension_url_is_openvsx(self):
        """Extension URL should be OpenVSX (primary target)."""
        assert "open-vsx.org" in EXTENSION_URL
        assert "deepsweep-ai" in EXTENSION_URL

    def test_openvsx_url_format(self):
        """OpenVSX URL should have correct format."""
        assert OPENVSX_URL == "https://open-vsx.org/extension/deepsweep-ai/deepsweep"

    def test_extension_id_format(self):
        """Extension ID should be publisher.name format."""
        assert EXTENSION_ID == "deepsweep-ai.deepsweep"


# ---------------------------------------------------------------------------
# Badge tests
# ---------------------------------------------------------------------------


class TestBadgeGeneration:
    """Tests for badge generation."""

    def test_badge_url_has_correct_format(self):
        """Badge URL should be valid shields.io format."""
        url = generate_badge_url("A", 95)
        assert "img.shields.io/badge" in url
        assert "DeepSweep" in url
        assert "22C55E" in url  # A grade color

    def test_badge_url_uses_flat_square_style(self):
        url = generate_badge_url("A", 95)
        assert "style=flat-square" in url

    def test_badge_url_fallback_color(self):
        url = generate_badge_url("Z", 50)
        assert "6366F1" in url

    def test_badge_markdown_links_to_landing(self):
        """Badge markdown should link to deepsweep.ai landing."""
        md = generate_badge_markdown("A", 95, "my-project")
        assert "deepsweep.ai/badge" in md
        assert "my-project" in md

    def test_badge_markdown_contains_shields_url(self):
        md = generate_badge_markdown("A", 95, "my-project")
        assert "img.shields.io" in md

    def test_extension_badge_links_to_openvsx(self):
        """Extension badge should link to OpenVSX."""
        badge = generate_extension_badge()
        assert "open-vsx.org" in badge
        assert "deepsweep-ai" in badge

    def test_sanitize_project_name_removes_special(self):
        """Should sanitize special characters."""
        assert sanitize_project_name("my project!") == "my-project"
        assert sanitize_project_name("") == "project"

    def test_sanitize_project_name_collapses_hyphens(self):
        assert sanitize_project_name("a---b") == "a-b"

    def test_sanitize_project_name_truncates(self):
        long_name = "a" * 100
        result = sanitize_project_name(long_name)
        assert len(result) <= 50


# ---------------------------------------------------------------------------
# Social URL tests
# ---------------------------------------------------------------------------


class TestSocialUrls:
    """Tests for social URL generation."""

    def test_twitter_url_includes_text_and_url(self):
        """Twitter URL should have text and URL params."""
        url = get_twitter_url("Hello world", "https://example.com")
        assert "twitter.com/intent/tweet" in url
        assert "text=" in url
        assert "url=" in url

    def test_linkedin_url_format(self):
        url = get_linkedin_url("https://example.com")
        assert "linkedin.com/sharing/share-offsite" in url
        assert "example.com" in url

    def test_share_text_no_emojis(self):
        """Share text should not contain emojis."""
        text = get_share_text("A+", 99)
        # Check for common emoji code points
        assert not any(ord(c) > 0x1F000 for c in text)

    def test_share_text_optimistic_tone(self):
        """Share text should be optimistic, not fear-based."""
        text = get_share_text("A", 95)
        assert "Ready to ship" in text
        assert "vulnerability" not in text.lower()
        assert "threat" not in text.lower()

    def test_share_text_grade_a(self):
        text = get_share_text("A", 95)
        assert "Grade A" in text

    def test_share_text_grade_b(self):
        text = get_share_text("B", 82)
        assert "confidence" in text.lower()

    def test_share_text_grade_c(self):
        text = get_share_text("C", 72)
        assert "improving" in text.lower()

    def test_share_text_grade_d(self):
        text = get_share_text("D", 55)
        assert "habits" in text.lower()

    def test_get_share_url_format(self):
        url = get_share_url("my-project")
        assert "deepsweep.ai/badge/my-project" in url

    def test_get_extension_url_is_openvsx(self):
        """Extension URL should be OpenVSX."""
        url = get_extension_url()
        assert "open-vsx.org" in url
        assert "deepsweep-ai" in url


# ---------------------------------------------------------------------------
# Trigger headline tests
# ---------------------------------------------------------------------------


class TestShareHeadline:
    def test_grade_a_headline(self):
        assert "ready to ship" in _get_share_headline("A")

    def test_grade_b_headline(self):
        assert "minor review" in _get_share_headline("B")

    def test_grade_c_headline(self):
        assert "few items" in _get_share_headline("C")

    def test_grade_d_headline(self):
        assert "improvement" in _get_share_headline("D")


# ---------------------------------------------------------------------------
# Integration: show_share_trigger with simulated input
# ---------------------------------------------------------------------------


class TestShareTrigger:
    """Tests for share trigger flow."""

    def test_skip_returns_none(self, monkeypatch):
        """Pressing Enter (empty input) should return None."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "")
        result = show_share_trigger(
            grade="A",
            score=95,
            passed_count=12,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result is None

    def test_choice_1_returns_twitter_share(self, monkeypatch):
        """Choosing 1 should return twitter_share."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "1")
        monkeypatch.setattr(
            "deepsweep.share.trigger._open_url", lambda _: None
        )
        result = show_share_trigger(
            grade="A",
            score=95,
            passed_count=12,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result == "twitter_share"

    def test_choice_2_returns_linkedin_share(self, monkeypatch):
        """Choosing 2 should return linkedin_share."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "2")
        monkeypatch.setattr(
            "deepsweep.share.trigger._open_url", lambda _: None
        )
        result = show_share_trigger(
            grade="B",
            score=82,
            passed_count=10,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result == "linkedin_share"

    def test_choice_3_returns_badge_copied(self, monkeypatch):
        """Choosing 3 should return badge_copied."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "3")
        monkeypatch.setattr(
            "deepsweep.share.trigger._copy_to_clipboard", lambda _: True
        )
        result = show_share_trigger(
            grade="A",
            score=95,
            passed_count=12,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result == "badge_copied"

    def test_choice_4_returns_extension_copied(self, monkeypatch):
        """Choosing 4 should return extension_copied."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "4")
        monkeypatch.setattr(
            "deepsweep.share.trigger._copy_to_clipboard", lambda _: True
        )
        result = show_share_trigger(
            grade="A",
            score=95,
            passed_count=12,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result == "extension_copied"

    def test_invalid_choice_returns_none(self, monkeypatch):
        """Invalid input should return None."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "9")
        result = show_share_trigger(
            grade="A",
            score=95,
            passed_count=12,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result is None
