"""CLI integration tests."""

from pathlib import Path

import pytest
from click.testing import CliRunner

from deepsweep.cli import main


@pytest.fixture
def runner():
    return CliRunner()


class TestValidateCommand:
    """Tests for 'deepsweep validate' command."""

    def test_validate_clean_directory(self, runner: CliRunner, temp_dir: Path):
        result = runner.invoke(main, ["validate", str(temp_dir)])

        assert result.exit_code == 0
        # v1.0.2 Plain English message
        assert "Ship with confidence" in result.output or "secure" in result.output.lower()

    def test_validate_with_malicious_file(self, runner: CliRunner, malicious_cursorrules: Path):
        result = runner.invoke(main, ["validate", str(malicious_cursorrules.parent)])

        # In Plain English mode (default), pattern ID not shown but finding is detected
        # Use --verbose to see pattern IDs
        assert result.exit_code == 1  # Should fail due to findings
        # Check for severity label in Plain English mode
        assert "[CRITICAL]" in result.output or "[HIGH]" in result.output or "tricked" in result.output.lower()

    def test_no_color_flag(self, runner: CliRunner, temp_dir: Path):
        result = runner.invoke(main, ["validate", str(temp_dir), "--no-color"])

        assert "\033[" not in result.output

    def test_json_output(self, runner: CliRunner, temp_dir: Path):
        result = runner.invoke(main, ["validate", str(temp_dir), "--format", "json"])

        assert result.exit_code == 0
        assert '"score"' in result.output
        assert '"findings"' in result.output

    def test_fail_on_critical(self, runner: CliRunner, malicious_cursorrules: Path):
        result = runner.invoke(
            main, ["validate", str(malicious_cursorrules.parent), "--fail-on", "critical"]
        )

        # CURSOR-RULES-001 is CRITICAL, should fail
        assert result.exit_code == 1


class TestHelpCommand:
    """Tests for help output."""

    def test_help_includes_vibe_coding(self, runner: CliRunner):
        result = runner.invoke(main, ["--help"])

        # Should mention AI-generated code or AI-built apps
        assert "ai-generated code" in result.output.lower() or "ai-built apps" in result.output.lower()

    def test_version(self, runner: CliRunner):
        result = runner.invoke(main, ["--version"])

        from deepsweep import __version__
        assert __version__ in result.output


class TestBadgeCommand:
    """Tests for 'deepsweep badge' command."""

    def test_badge_creates_file(self, runner: CliRunner, temp_dir: Path):
        with runner.isolated_filesystem(temp_dir=temp_dir):
            result = runner.invoke(main, ["badge", "--format", "json"])

            assert result.exit_code == 0
            assert Path("badge.svg").exists() or "[PASS]" in result.output


class TestPatternsCommand:
    """Tests for 'deepsweep patterns' command."""

    def test_lists_patterns(self, runner: CliRunner):
        result = runner.invoke(main, ["patterns"])

        assert result.exit_code == 0
        assert "CURSOR-RULES-001" in result.output
        assert "MCP-POISON-001" in result.output
