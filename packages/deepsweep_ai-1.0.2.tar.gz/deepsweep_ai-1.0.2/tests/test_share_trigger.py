"""Tests for the post-validation share trigger module."""

from deepsweep.share.badge import (
    generate_badge_html,
    generate_badge_markdown,
    generate_badge_url,
    sanitize_project_name,
)
from deepsweep.share.constants import GRADE_COLORS
from deepsweep.share.social import (
    get_linkedin_url,
    get_share_text_for_grade,
    get_twitter_url,
)
from deepsweep.share.trigger import _get_share_headline, show_share_trigger

# ---------------------------------------------------------------------------
# Badge tests
# ---------------------------------------------------------------------------


class TestBadgeUrl:
    def test_returns_shields_io_url(self):
        url = generate_badge_url("A", 95)
        assert url.startswith("https://img.shields.io/badge/")

    def test_contains_grade_and_score(self):
        url = generate_badge_url("B", 82)
        # URL-encoded "B (82)"
        assert "B" in url
        assert "82" in url

    def test_uses_correct_color(self):
        url = generate_badge_url("A", 95)
        assert GRADE_COLORS["A"] in url

    def test_uses_flat_square_style(self):
        url = generate_badge_url("A", 95)
        assert "style=flat-square" in url

    def test_fallback_color_for_unknown_grade(self):
        url = generate_badge_url("Z", 50)
        assert "6366F1" in url


class TestBadgeMarkdown:
    def test_contains_image_link(self):
        md = generate_badge_markdown("A", 95, "my-project")
        assert md.startswith("[![DeepSweep Security Grade]")

    def test_contains_profile_url(self):
        md = generate_badge_markdown("A", 95, "my-project")
        assert "https://deepsweep.ai/badge/my-project" in md

    def test_contains_shields_url(self):
        md = generate_badge_markdown("A", 95, "my-project")
        assert "img.shields.io" in md


class TestBadgeHtml:
    def test_contains_anchor_tag(self):
        html = generate_badge_html("B", 80, "test-proj")
        assert "<a href=" in html
        assert "<img src=" in html

    def test_contains_alt_text(self):
        html = generate_badge_html("B", 80, "test-proj")
        assert 'alt="DeepSweep Security Grade"' in html


class TestSanitizeProjectName:
    def test_empty_returns_project(self):
        assert sanitize_project_name("") == "project"

    def test_collapses_hyphens(self):
        assert sanitize_project_name("a---b") == "a-b"

    def test_truncates_long_names(self):
        result = sanitize_project_name("a" * 100)
        assert len(result) <= 50


# ---------------------------------------------------------------------------
# Social URL tests
# ---------------------------------------------------------------------------


class TestTwitterUrl:
    def test_returns_twitter_intent_url(self):
        url = get_twitter_url("Hello world", "https://example.com")
        assert url.startswith("https://twitter.com/intent/tweet?")

    def test_contains_encoded_text(self):
        url = get_twitter_url("Hello world", "https://example.com")
        assert "Hello" in url

    def test_contains_encoded_url(self):
        url = get_twitter_url("text", "https://example.com")
        assert "example.com" in url


class TestLinkedInUrl:
    def test_returns_linkedin_share_url(self):
        url = get_linkedin_url("https://example.com")
        assert url.startswith("https://www.linkedin.com/sharing/share-offsite/")

    def test_contains_encoded_url(self):
        url = get_linkedin_url("https://example.com")
        assert "example.com" in url


class TestShareTextForGrade:
    def test_grade_a_text(self):
        text = get_share_text_for_grade("A", 95)
        assert "Ready to ship" in text

    def test_grade_b_text(self):
        text = get_share_text_for_grade("B", 82)
        assert "confidence" in text.lower()

    def test_grade_c_text(self):
        text = get_share_text_for_grade("C", 72)
        assert "improving" in text.lower()

    def test_grade_d_text(self):
        text = get_share_text_for_grade("D", 55)
        assert "habits" in text.lower()

    def test_grade_f_text(self):
        text = get_share_text_for_grade("F", 30)
        assert "habits" in text.lower()


# ---------------------------------------------------------------------------
# Trigger headline tests
# ---------------------------------------------------------------------------


class TestShareHeadline:
    def test_grade_a_headline(self):
        assert "ready to ship" in _get_share_headline("A")

    def test_grade_b_headline(self):
        assert "minor review" in _get_share_headline("B")

    def test_grade_c_headline(self):
        assert "few items" in _get_share_headline("C")

    def test_grade_d_headline(self):
        assert "improvement" in _get_share_headline("D")


# ---------------------------------------------------------------------------
# Integration: show_share_trigger with simulated input
# ---------------------------------------------------------------------------


class TestShowShareTrigger:
    def test_skip_returns_none(self, monkeypatch):
        """Pressing Enter (empty input) should return None."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "")
        result = show_share_trigger(
            grade="A",
            score=95,
            passed_count=12,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result is None

    def test_choice_1_returns_twitter_share(self, monkeypatch):
        """Choosing 1 should return twitter_share."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "1")
        monkeypatch.setattr(
            "deepsweep.share.trigger._open_url", lambda _: None
        )
        result = show_share_trigger(
            grade="A",
            score=95,
            passed_count=12,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result == "twitter_share"

    def test_choice_2_returns_linkedin_share(self, monkeypatch):
        """Choosing 2 should return linkedin_share."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "2")
        monkeypatch.setattr(
            "deepsweep.share.trigger._open_url", lambda _: None
        )
        result = show_share_trigger(
            grade="B",
            score=82,
            passed_count=10,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result == "linkedin_share"

    def test_choice_3_returns_badge_copied(self, monkeypatch):
        """Choosing 3 should return badge_copied."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "3")
        monkeypatch.setattr(
            "deepsweep.share.trigger._copy_to_clipboard", lambda _: True
        )
        result = show_share_trigger(
            grade="A",
            score=95,
            passed_count=12,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result == "badge_copied"

    def test_choice_4_returns_extension_copied(self, monkeypatch):
        """Choosing 4 should return extension_copied."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "4")
        monkeypatch.setattr(
            "deepsweep.share.trigger._copy_to_clipboard", lambda _: True
        )
        result = show_share_trigger(
            grade="A",
            score=95,
            passed_count=12,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result == "extension_copied"

    def test_invalid_choice_returns_none(self, monkeypatch):
        """Invalid input should return None."""
        monkeypatch.setattr("click.prompt", lambda *_args, **_kwargs: "9")
        result = show_share_trigger(
            grade="A",
            score=95,
            passed_count=12,
            total_count=14,
            project_name="test-project",
            skip_delay=True,
        )
        assert result is None
