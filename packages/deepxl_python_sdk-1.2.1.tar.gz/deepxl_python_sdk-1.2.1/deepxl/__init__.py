"""DeepXL Python SDK"""

from .client import DeepXLClient
from .types import (
    Tag,
    FileData,
    ModelMetadata,
    FraudDetection,
    DetectionHistoryResponse,
    DetectionResponse,
    DetectionQueryParams,
    AnalyzeFileOptions,
    APIParse,
    APIParseHistoryResponse,
    APIParseResponse,
    ParseQueryParams,
    ParseDocumentOptions,
    Verification,
    VerificationResponse,
    APIVerificationHistoryResponse,
    VerificationQueryParams,
    VerifyOptions,
    DeepXLClientConfig,
)

__all__ = [
    'DeepXLClient',
    'Tag',
    'FileData',
    'ModelMetadata',
    'FraudDetection',
    'DetectionHistoryResponse',
    'DetectionResponse',
    'DetectionQueryParams',
    'AnalyzeFileOptions',
    'APIParse',
    'APIParseHistoryResponse',
    'APIParseResponse',
    'ParseQueryParams',
    'ParseDocumentOptions',
    'Verification',
    'VerificationResponse',
    'APIVerificationHistoryResponse',
    'VerificationQueryParams',
    'VerifyOptions',
    'DeepXLClientConfig',
]

__version__ = '1.0.0'
