"""DeepXL API Client"""

import json
import requests
from typing import Optional, Dict, Any, Union, List
from io import BytesIO

from .types import (
    DeepXLClientConfig,
    ModelMetadata,
    DetectionHistoryResponse,
    DetectionResponse,
    DetectionQueryParams,
    AnalyzeFileOptions,
    APIParseHistoryResponse,
    APIParseResponse,
    ParseQueryParams,
    ParseDocumentOptions,
    APIVerificationHistoryResponse,
    VerificationResponse,
    VerificationQueryParams,
    VerifyOptions,
)


class DeepXLClient:
    """Client for interacting with the DeepXL API"""

    BASE_URL = 'https://api.deepxl.ai'

    def __init__(self, config: DeepXLClientConfig):
        """
        Initialize the DeepXL client.

        Args:
            config: Configuration object containing apiKey
        """
        if not config.apiKey:
            raise ValueError('apiKey must be provided')
        self.api_key = config.apiKey
        self.base_url = self.BASE_URL

    def _get_headers(self) -> Dict[str, str]:
        """Get default headers for API requests"""
        return {
            'x-api-key': self.api_key,
        }

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """
        Make an HTTP request to the API.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: API endpoint path
            params: Query parameters
            files: Files to upload (for multipart/form-data)
            data: Form data (for multipart/form-data)

        Returns:
            Response JSON data

        Raises:
            ValueError: If the request fails
        """
        url = f'{self.base_url}{path}'
        headers = self._get_headers()

        # Prepare query parameters
        query_params = {}
        if params:
            for key, value in params.items():
                if value is not None:
                    query_params[key] = value

        try:
            if files or data:
                # Multipart form data request
                response = requests.request(
                    method=method,
                    url=url,
                    headers=headers,
                    params=query_params,
                    files=files,
                    data=data,
                )
            else:
                # JSON request
                response = requests.request(
                    method=method,
                    url=url,
                    headers=headers,
                    params=query_params,
                )

            response.raise_for_status()

            # Handle file downloads
            content_type = response.headers.get('content-type', '')
            if 'application/octet-stream' in content_type:
                return response

            return response.json()

        except requests.exceptions.HTTPError as e:
            error_message = str(e)
            try:
                error_json = response.json()
                error_message = error_json.get('detail') or error_json.get('message') or error_message
            except:
                pass
            raise ValueError(error_message) from e

    def _prepare_file(self, file: Union[bytes, Any], filename: Optional[str] = None) -> tuple:
        """
        Prepare a file for upload.

        Args:
            file: File data (bytes or file-like object)
            filename: Optional filename

        Returns:
            Tuple of (file_data, filename)
        """
        if isinstance(file, bytes):
            file_obj = BytesIO(file)
            filename = filename or 'file'
        else:
            # Assume it's a file-like object
            file_obj = file
            if hasattr(file, 'name'):
                filename = filename or file.name
            else:
                filename = filename or 'file'

        return (filename, file_obj)

    # Fraud Detection Methods
    def get_detection_models(self) -> List[ModelMetadata]:
        """Get available fraud detection models"""
        return self._request('GET', '/v1/detection-models')

    def get_detection_history(self, params: Optional[DetectionQueryParams] = None) -> DetectionHistoryResponse:
        """Get fraud detection history"""
        return self._request('GET', '/v1/detection', params=params)

    def get_detection_by_id(self, detection_id: int) -> DetectionResponse:
        """Get a fraud detection record by ID"""
        return self._request('GET', f'/v1/detection/{detection_id}')

    def analyze_file(self, options: AnalyzeFileOptions) -> DetectionResponse:
        """
        Analyze a file for fraud detection.

        Args:
            options: Options containing model, file, fileName, and optional tags

        Returns:
            Detection response with analysis results
        """
        filename, file_obj = self._prepare_file(options.file, options.fileName)

        files = {
            'file': (filename, file_obj),
        }

        data = {
            'model': options.model,
        }

        if options.tags:
            data['tags'] = json.dumps(options.tags)

        return self._request('POST', '/v1/detection', files=files, data=data)

    # Document Parsing Methods
    def get_parsing_models(self) -> List[ModelMetadata]:
        """Get available parsing models"""
        return self._request('GET', '/v1/parsing-models')

    def get_parsing_history(self, params: Optional[ParseQueryParams] = None) -> APIParseHistoryResponse:
        """Get document parsing history"""
        return self._request('GET', '/v1/parse', params=params)

    def get_parse_by_id(self, parse_id: int) -> APIParseResponse:
        """Get a parsed document by ID"""
        return self._request('GET', f'/v1/parse/{parse_id}')

    def parse_document(self, options: ParseDocumentOptions) -> APIParseResponse:
        """
        Parse a document.

        Args:
            options: Options containing model, file, fileName, and optional tags

        Returns:
            Parse response with extracted data
        """
        filename, file_obj = self._prepare_file(options.file, options.fileName)

        files = {
            'file': (filename, file_obj),
        }

        data = {
            'model': options.model,
        }

        if options.tags:
            data['tags'] = json.dumps(options.tags)

        return self._request('POST', '/v1/parse', files=files, data=data)

    # Verification Methods
    def get_verification_history(self, params: Optional[VerificationQueryParams] = None) -> APIVerificationHistoryResponse:
        """Get verification history"""
        return self._request('GET', '/v1/verification', params=params)

    def get_verification_by_id(self, verification_id: int) -> VerificationResponse:
        """Get a verification record by ID"""
        return self._request('GET', f'/v1/verification/{verification_id}')

    def verify(self, options: VerifyOptions) -> VerificationResponse:
        """
        Verify a user with their ID and selfie.

        Args:
            options: Options containing idFile, selfieFile, and optional tags

        Returns:
            Verification response with verification results
        """
        id_filename, id_file_obj = self._prepare_file(options.idFile, options.idFileName)
        selfie_filename, selfie_file_obj = self._prepare_file(options.selfieFile, options.selfieFileName)

        files = {
            'idFile': (id_filename, id_file_obj),
            'selfieFile': (selfie_filename, selfie_file_obj),
        }

        data = {}
        if options.tags:
            data['tags'] = json.dumps(options.tags)

        return self._request('POST', '/v1/verification', files=files, data=data)

    # File Retrieval Methods
    def get_file(self, file_name: str) -> requests.Response:
        """
        Get a file from the API.

        Args:
            file_name: Name of the file to retrieve

        Returns:
            Response object with file content
        """
        return self._request('GET', f'/v1/files/{file_name}')

    def download_file(self, file_name: str) -> bytes:
        """
        Download a file from the API.

        Args:
            file_name: Name of the file to download

        Returns:
            File content as bytes
        """
        response = self.get_file(file_name)
        return response.content
