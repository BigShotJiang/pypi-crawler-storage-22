"""Type definitions for DeepXL API"""

from typing import TypedDict, Optional, List, Dict, Any, Union, Literal
from dataclasses import dataclass


class Tag(TypedDict):
    name: str
    value: str


class FileData(TypedDict, total=False):
    category: Optional[str]
    fileName: str
    fileSize: int
    contentType: str
    timestamp: int
    timestampISO: str
    url: Optional[str]


class ModelMetadata(TypedDict):
    name: str
    description: str
    tags: List[str]
    category: str
    validInputTypes: List[str]
    validFileTypes: List[str]
    ownedBy: str
    version: str


# Fraud Detection Types
class FraudDetection(TypedDict, total=False):
    detectionId: int
    mediaType: str
    fileName: str
    size: int
    fileType: str
    model: str
    likelihood: float
    fraudSeverity: Literal["low", "medium", "high"]
    reasoning: List[str]
    modelResults: Dict[str, Any]
    classification: Optional[str]
    timestamp: int
    timestampISO: str
    tags: List[Tag]
    files: List[FileData]


class DetectionHistoryResponse(TypedDict):
    totalCount: int
    count: int
    data: List[FraudDetection]


class DetectionResponse(TypedDict):
    result: FraudDetection


class DetectionQueryParams(TypedDict, total=False):
    limit: Optional[int]
    offset: Optional[int]
    sortBy: Optional[Literal["fraudDetectionId", "fileName", "size", "fileType", "model", "likelihood", "createdOn"]]
    direction: Optional[Literal["asc", "desc"]]
    tagFilter: Optional[str]
    mediaType: Optional[str]
    fileType: Optional[str]
    fileName: Optional[str]
    model: Optional[str]
    minLikelihood: Optional[float]
    maxLikelihood: Optional[float]
    fraudSeverity: Optional[Literal["low", "medium", "high"]]
    classification: Optional[str]
    minTimestamp: Optional[int]
    maxTimestamp: Optional[int]


@dataclass
class AnalyzeFileOptions:
    model: str
    file: Union[bytes, Any]  # bytes or file-like object
    fileName: Optional[str] = None
    tags: Optional[Dict[str, str]] = None


# Document Parsing Types
class APIParse(TypedDict, total=False):
    parseId: int
    mediaType: str
    fileType: str
    fileName: str
    size: int
    model: str
    likelihood: float
    documentType: str
    parsedData: Dict[str, Any]
    timestamp: int
    timestampISO: str
    tags: List[Tag]
    files: List[FileData]


class APIParseHistoryResponse(TypedDict):
    totalCount: int
    count: int
    data: List[APIParse]


class APIParseResponse(TypedDict):
    result: APIParse


class ParseQueryParams(TypedDict, total=False):
    limit: Optional[int]
    offset: Optional[int]
    sortBy: Optional[Literal["parseId", "mediaType", "fileType", "fileName", "size", "confidence", "documentType", "timestamp"]]
    direction: Optional[Literal["asc", "desc"]]
    tagFilter: Optional[str]
    mediaType: Optional[str]
    fileType: Optional[str]
    fileName: Optional[str]
    minSize: Optional[int]
    maxSize: Optional[int]
    model: Optional[str]
    documentType: Optional[str]
    minTimestamp: Optional[int]
    maxTimestamp: Optional[int]


@dataclass
class ParseDocumentOptions:
    model: str
    file: Union[bytes, Any]  # bytes or file-like object
    fileName: Optional[str] = None
    tags: Optional[Dict[str, str]] = None


# Verification Types
class TechnicalCheck(TypedDict, total=False):
    type: str
    status: str
    confidence: Optional[float]
    details: Optional[str]


class Verification(TypedDict, total=False):
    verificationId: int
    idName: str
    idSize: int
    idFileType: str
    selfieName: str
    selfieSize: int
    selfieFileType: str
    verified: bool
    technicalChecks: List[TechnicalCheck]
    timestamp: int
    timestampISO: str
    tags: List[Tag]
    files: List[FileData]


class VerificationResponse(TypedDict):
    result: Verification


class APIVerificationHistoryResponse(TypedDict):
    totalCount: int
    count: int
    data: List[Verification]


class VerificationQueryParams(TypedDict, total=False):
    limit: Optional[int]
    offset: Optional[int]
    sortBy: Optional[Literal["verificationId", "idName", "idSize", "idFileType", "selfieName", "selfieSize", "selfieFileType", "verified", "timestamp"]]
    direction: Optional[Literal["asc", "desc"]]
    tagFilter: Optional[str]
    idName: Optional[str]
    idFileType: Optional[str]
    selfieName: Optional[str]
    selfieFileType: Optional[str]
    minIdSize: Optional[int]
    maxIdSize: Optional[int]
    minSelfieSize: Optional[int]
    maxSelfieSize: Optional[int]
    verified: Optional[bool]
    minTimestamp: Optional[int]
    maxTimestamp: Optional[int]


@dataclass
class VerifyOptions:
    idFile: Union[bytes, Any]  # bytes or file-like object
    idFileName: Optional[str] = None
    selfieFile: Union[bytes, Any]  # bytes or file-like object
    selfieFileName: Optional[str] = None
    tags: Optional[Dict[str, str]] = None


# Client Configuration
@dataclass
class DeepXLClientConfig:
    apiKey: str
