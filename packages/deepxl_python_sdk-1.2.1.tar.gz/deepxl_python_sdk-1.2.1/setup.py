"""Setup configuration for DeepXL Python SDK"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="deepxl-python-sdk",
    version="1.2.1",
    author="DeepXL",
    author_email="david@deepxl.ai",
    description="Python SDK for DeepXL fraud detection, document parsing, and verification services",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/deepxl/deepxl-python-sdk",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
)
