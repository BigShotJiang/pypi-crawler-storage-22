"""Fixtures for skills tests."""
