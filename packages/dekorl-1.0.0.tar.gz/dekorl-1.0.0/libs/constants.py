VERSION = "1.0.0"
AUTHOR = "MurilooPrDev"
PROJECT = "DekoRL"
