# Deko Magnitude Library
from .engine import DekoEngine
from .storage import StorageManager
