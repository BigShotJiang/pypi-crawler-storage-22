# Cache Cleaner 🧹

A beautiful terminal tool to clean cache from various package managers with rich visual feedback.

## Features

- **Beautiful UI**: Uses Rich for terminal beautification
- **Live Status**: See real-time progress with colored indicators
- **Multiple Package Managers**: Supports pip, npm, yarn, cargo, gem, composer, apt, brew, and go
- **Verbose Mode**: See detailed information about what's being cleaned
- **Dry Run**: Preview what would be cleaned without making changes
- **Force Mode**: Clean system caches that require sudo

## Installation

```bash
pip install del-cache
```

Or install from source
```bash
git clone https://github.com/2kDarki/cache-cleaner
cd cache-cleaner
pip install -e .
```

## Usage

```bash
# Clean all caches
clean

# Preview what would be cleaned
clean --dry-run

# Show detailed output
clean --verbose

# Clean system caches (requires sudo)
clean --force

# Show help
clean --help
```

## [Licence](LICENCE)