"""Package Manager Cache Cleaner - A tool to clean cache from various package managers."""

__version__ = "1.0.0"
__author__ = "2kDarki"
__description__ = "Clean cache from package managers with beautiful terminal output"