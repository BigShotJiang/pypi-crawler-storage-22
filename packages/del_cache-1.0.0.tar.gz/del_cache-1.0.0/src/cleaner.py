from dataclasses import dataclass
from typing import Literal
from pathlib import Path
import subprocess
import shutil
import sys
import os

from tuikit.logictools import any_eq


@dataclass
class CacheInfo:
    """Formal definition of a cache entry."""
    name: str
    type: Literal["download", "build", "mixed"]
    location: Path
    description: str
    rationale: list[str]


class PackageManagerCleaner:
    """Clean cache from various package managers."""
    
    def __init__(self, dry_run: bool = False, verbose: bool = False, force: bool = False):
        self.dry_run = dry_run
        self.verbose = verbose
        self.force = force
        self.home = Path.home()
        
    def _run_command(self, cmd: str, capture_output: bool = True) -> tuple[bool, str]:
        """Run a shell command."""
        try:
            if capture_output:
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                return result.returncode == 0, result.stdout.strip()
            else:
                result = subprocess.run(cmd, shell=True)
                return result.returncode == 0, ""
        except Exception as e:
            return False, str(e)
    
    def _get_dir_size(self, path: Path) -> int:
        """Get directory size in bytes."""
        if not path.exists():
            return 0
        
        total_size = 0
        try:
            for entry in path.rglob('*'):
                if entry.is_file():
                    total_size += entry.stat().st_size
        except:
            pass
        
        return total_size
    
    def _clean_cache(self, name, cmd, success, output, explain, cache_info, cache_type):
        details = []
        special = any_eq("cargo", "gem", "apt", eq=name)

        if not special:
            if not success or not output:
                return {
                    "success": False,
                    "skipped": True,
                    "message": f"{name} not found or cache directory not accessible",
                    "details": details,
                    "size_freed": 0,
                    "cache_info": None
                }
            cache_dir = Path(output.strip())
        elif name == "apt":
            cache_dir = Path("/var/cache/apt/archives")
        else:
            cache_dir = self.home / f".{name}"
            if name == "cargo": cache_dir /= "registry"

        if not cache_dir.exists() or not any(cache_dir.iterdir()):
            return {
                "success": False,
                "skipped": True,
                "message": f"No {name} cache found",
                "details": details,
                "size_freed": 0,
                "cache_info": None
            }
        
        if explain:
            return {
                "success": True,
                "skipped": False,
                "message": f"{name} cache information",
                "details": details,
                "size_freed": 0,
                "cache_info": cache_info
            }
        
        size_before = self._get_dir_size(cache_dir)
        details.append(f"Cache location: {cache_dir}")
        details.append(f"Cache size: {self._format_bytes(size_before)}")
        details.append(f"Cache type: {cache_type}")
        
        if self.dry_run:
            return {
                "success": True,
                "skipped": False,
                "message": f"Would clean {self._format_bytes(size_before)}",
                "details": details,
                "size_freed": size_before,
                "cache_info": cache_info
            }
        
        # Actually clean
        if name == "cargo":
            # Try cargo-cache first, then manual cleanup
            if shutil.which("cargo-cache"):
                success, output = self._run_command("cargo cache --autoclean")
            else: # Manual cleanup
                cache_subdir = cache_dir / "cache"
                src_subdir   = cache_dir / "src"
                try:
                    if cache_subdir.exists():
                        shutil.rmtree(cache_subdir)
                    if src_subdir.exists():
                        shutil.rmtree(src_subdir)
                    success = True
                except: success = False
        else:
            if name == "apt":
                # Check if we have permission
                if os.geteuid() != 0 and not self.force:
                    return {
                        "success": False,
                        "skipped": True,
                        "message": "Requires sudo (use --force)",
                        "details": details,
                        "size_freed": 0,
                        "cache_info": cache_info
                    }
                
                cmd = "sudo apt-get clean" if os.geteuid() != 0 else "apt-get clean"
            success, output = self._run_command(cmd)

        if success:
            size_after = self._get_dir_size(cache_dir)
            freed = size_before - size_after
            return {
                "success": True,
                "skipped": False,
                "message": f"Cleaned {self._format_bytes(freed)}",
                "details": details,
                "size_freed": freed,
                "cache_info": cache_info
            }
        else:
            return {
                "success": False,
                "skipped": False,
                "message": f"Failed to clean {name} cache",
                "details": details,
                "size_freed": 0,
                "cache_info": cache_info
            }
    
    def _get_cache_info(self, name, cmd, cache_type) -> CacheInfo | None:
        """Get cache information for explain mode."""
        special = any_eq("cargo", "gem", "apt", eq=name)
        if not special:
            success, output = self._run_command(cmd)
            if not success or not output: return None

            cache_dir = Path(output.strip())
        elif name == "apt":
            cache_dir = Path("/var/cache/apt/archives")
        else:
            cache_dir = self.home / ".cargo"
            if name == "cargo": cache_dir /= "registry"

        if not cache_dir.exists(): return None

        return CacheInfo(
            name=name,
            type=cache_type,
            location=cache_dir,
            description=self._get_desc(name),
            rationale=self._get_rationale(name)
        )

    def clean_pip(self, explain: bool = False) -> dict:
        """Clean pip cache."""
        # Try pip3 first, then pip
        cmd = "pip3" if shutil.which("pip3") else "pip"
        cmd = f"{cmd} cache dir"

        success, output = self._run_command(cmd)
        cache_info      = self._get_cache_info("pip", cmd,
                          "download")

        return self._clean_cache(
            "pip",
            f"{cmd} cache purge",
            success,
            output,
            explain,
            cache_info,
            "download"
        )
    
    def clean_npm(self, explain: bool = False) -> dict:
        """Clean npm cache."""
        if not shutil.which("npm"):
            return {
                "success": False,
                "skipped": True,
                "message": "npm not installed",
                "details": [],
                "size_freed": 0,
                "cache_info": None
            }
        
        cmd = "npm config get cache"
        success, output = self._run_command(cmd)
        cache_info      = self._get_cache_info("npm", cmd,
                         "download")
        return self._clean_cache(
            "npm",
            "npm cache clean --force",
            success,
            output,
            explain,
            cache_info,
            "download"
        )
    
    def clean_yarn(self, explain: bool = False) -> dict:
        """Clean yarn cache."""
        if not shutil.which("yarn"):
            return {
                "success": False,
                "skipped": True,
                "message": "yarn not installed",
                "details": [],
                "size_freed": 0,
                "cache_info": None
            }
        
        cmd = "yarn cache dir"
        success, output = self._run_command(cmd)
        cache_info      = self._get_cache_info("yarn", cmd,
                         "download")
        return self._clean_cache(
            "yarn",
            "yarn cache clean",
            success,
            output,
            explain,
            cache_info,
            "download"
        )
    
    def clean_cargo(self, explain: bool = False) -> dict:
        """Clean cargo cache."""
        if not shutil.which("cargo"):
            return {
                "success": False,
                "skipped": True,
                "message": "cargo not installed",
                "details": [],
                "size_freed": 0,
                "cache_info": None
            }

        cache_info = self._get_cache_info("cargo", None,
                     "mixed")
        return self._clean_cache(
            "cargo",
            None,
            None,
            None,
            explain,
            cache_info,
            "mixed"
        )

    def clean_gem(self, explain: bool = False) -> dict:
        """Clean gem cache."""
        if not shutil.which("gem"):
            return {
                "success": False,
                "skipped": True,
                "message": "gem not installed",
                "details": [],
                "size_freed": 0,
                "cache_info": None
            }

        cache_info = self._get_cache_info("gem", None,
                     "download")
        return self._clean_cache(
            "gem",
            "gem cleanup",
            None,
            None,
            explain,
            cache_info,
            "download"
        )
    
    def clean_composer(self, explain: bool = False) -> dict:
        """Clean composer cache."""
        if not shutil.which("composer"):
            return {
                "success": False,
                "skipped": True,
                "message": "composer not installed",
                "details": [],
                "size_freed": 0,
                "cache_info": None
            }

        cmd = "composer config cache-dir"
        success, output = self._run_command(cmd)
        cache_info      = self._get_cache_info("composer",
                          cmd, "download")
        return self._clean_cache(
            "composer",
            "composer clear-cache",
            success,
            output,
            explain,
            cache_info,
            "download"
        )
    
    def clean_apt(self, explain: bool = False) -> dict:
        """Clean apt cache."""
        if not shutil.which("apt-get"):
            return {
                "success": False,
                "skipped": True,
                "message": "apt-get not available",
                "details": [],
                "size_freed": 0,
                "cache_info": None
            }

        cache_info = self._get_cache_info("apt", None,
                     "download")
        return self._clean_cache(
            "apt",
            None,
            None,
            None,
            explain,
            cache_info,
            "download"
        )

    def clean_brew(self, explain: bool = False) -> dict:
        """Clean brew cache."""
        if not shutil.which("brew"):
            return {
                "success": False,
                "skipped": True,
                "message": "brew not installed",
                "details": [],
                "size_freed": 0,
                "cache_info": None
            }
        
        cmd = "brew --cache"
        success, output = self._run_command(cmd)
        cache_info      = self._get_cache_info("brew", cmd,
                         "download")
        return self._clean_cache(
            "brew",
            "brew cleanup --prune=all",
            success,
            output,
            explain,
            cache_info,
            "download"
        )
    
    def clean_go(self, explain: bool = False) -> dict:
        """Clean go cache."""
        if not shutil.which("go"):
            return {
                "success": False,
                "skipped": True,
                "message": "go not installed",
                "details": [],
                "size_freed": 0,
                "cache_info": None
            }
        
        cmd = "go env GOCACHE"
        success, output = self._run_command(cmd)
        cache_info      = self._get_cache_info("go", cmd,
                          "build")
        return self._clean_cache(
            "go",
            "go clean -cache",
            success,
            output,
            explain,
            cache_info,
            "build"
        )
    
    def _get_desc(self, name):
        pkg_map = {
            "pip": "Python",
            "npm": "Node.js",
            "yarn": "Yarn",
            "apt": "APT",
            "brew": "Homebrew",
        }

        if name in pkg_map.keys():
            return f"{pkg_map[name]} package download cache"
        elif name == "composer": return "PHP Composer cache"
        elif name == "go": return "Go build cache"
        else:
            if name == "gem": return "Ruby gem cache"
            else: return "Rust package registry cache"

    def _get_rationale(self, name):
        rationale_map = {
            "pip": [
                "Contains downloaded .whl and .tar.gz packages",
                "Speeds up repeated installations",
                "Safe to clean: packages can be re-downloaded",
                "Location determined by: pip cache dir"
            ],

            "npm": [
                "Contains downloaded npm package tarballs",
                "Stores metadata and package versions",
                "Safe to clean: packages can be re-downloaded",
                "Location determined by: npm config get cache"
            ],

            "yarn": [
                "Contains downloaded package archives",
                "Includes offline mirror if configured",
                "Safe to clean: packages can be re-downloaded",
                "Location determined by: yarn cache dir"
            ],

            "cargo": [
                "Contains downloaded crates in 'cache' subdirectory",
                "Contains extracted source code in 'src' subdirectory",
                "Mixed cache: both downloaded archives and extracted sources",
                "Safe to clean: crates can be re-downloaded and re-extracted",
                "Standard location: ~/.cargo/registry/"
            ],

            "gem": [
                "Contains downloaded .gem files",
                "Stores gem specifications and documentation",
                "Safe to clean: gems can be re-downloaded",
                "Standard location: ~/.gem/"
            ],

            "composer": [
                "Contains downloaded PHP packages",
                "Stores metadata and package versions",
                "Safe to clean: packages can be re-downloaded",
                "Location determined by: composer config cache-dir"
            ],

            "apt": [
                "Contains downloaded .deb package files",
                "Allows offline reinstallation of packages",
                "Safe to clean: packages can be re-downloaded from repositories",
                "Standard system location: /var/cache/apt/archives/",
                "Requires sudo privileges to clean"
            ],

            "brew": [
                "Contains downloaded formula bottles and source tarballs",
                "Includes Git repositories for formulas",
                "Safe to clean: packages can be re-downloaded",
                "Location determined by: brew --cache"
            ],

            "go": [
                "Contains compiled package objects and test results",
                "Speeds up incremental builds",
                "Build cache: cleaning may slow down next build",
                "Location determined by: go env GOCACHE"
            ]
        }

        return rationale_map[name]

    def _format_bytes(self, bytes_size: int) -> str:
        """Format bytes to human readable format."""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes_size < 1024.0:
                return f"{bytes_size:.1f}{unit}"
            bytes_size /= 1024.0
        return f"{bytes_size:.1f}TB"
