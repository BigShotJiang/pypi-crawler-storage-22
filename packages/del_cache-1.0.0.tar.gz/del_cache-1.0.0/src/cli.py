#!/usr/bin/env python3
"""Command-line interface for cache-cleaner."""
from functools import partial
import argparse
import sys

from .cleaner import PackageManagerCleaner
from .ui import UI


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Package Manager Cache Cleaner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Supported package managers:
  - pip (Python) - download cache
  - npm (Node.js) - download cache
  - yarn (Node.js) - download cache
  - cargo (Rust) - mixed cache
  - gem (Ruby) - download cache
  - composer (PHP) - download cache
  - apt (Debian/Ubuntu) - download cache
  - brew (macOS) - download cache
  - go (Go) - build cache

Cache types:
  download: Contains downloaded packages, safe to clean
  build: Contains compiled objects, cleaning may slow builds
  mixed: Contains both downloaded and built files

Examples:
  cache-clean
  cache-clean --dry-run
  cache-clean --force
  cache-clean --verbose
  cache-clean --explain
  cache-clean --only-download-cache
  cache-clean --exclude-build-cache
"""
    )

    parser.add_argument(
        "-d", "--dry-run",
        action="store_true",
        help="Show what would be cleaned without actually cleaning",
    )

    parser.add_argument(
        "-f", "--force",
        action="store_true",
        help="Force cleaning (including operations requiring sudo)",
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output",
    )

    parser.add_argument(
        "--explain",
        action="store_true",
        help="Explain cache locations and types without cleaning",
    )

    parser.add_argument(
        "--only-download-cache",
        action="store_true",
        help="Only clean download caches (safe to clean)",
    )

    parser.add_argument(
        "--exclude-build-cache",
        action="store_true",
        help="Exclude build caches (may slow down builds if cleaned)",
    )

    parser.add_argument(
        "--version",
        action="store_true",
        help="Show version information",
    )

    return parser


def should_include_cache(cache_type: str, args) -> bool:
    """Determine if a cache should be included based on filter arguments."""
    if args.only_download_cache:
        return cache_type == "download"
    if args.exclude_build_cache:
        return cache_type != "build"
    return True


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.version:
        from cache_cleaner import __version__
        print(f"Cache Cleaner v{__version__}")
        sys.exit(0)

    # --- core wiring ---
    cleaner = PackageManagerCleaner(
        dry_run=args.dry_run,
        verbose=args.verbose,
        force=args.force,
    )

    ui = UI(
        verbose=args.verbose,
        dry_run=args.dry_run,
    )

    # Cache type mapping
    cache_types = {
        "pip": "download",
        "npm": "download", 
        "yarn": "download",
        "cargo": "mixed",
        "gem": "download",
        "composer": "download",
        "apt": "download",
        "brew": "download",
        "go": "build",
    }

    # Add steps with filtering
    for name, cache_type in cache_types.items():
        if should_include_cache(cache_type, args):
            method = getattr(cleaner, f"clean_{name}")
            # Pass explain flag to cleaner methods
            if args.explain:
                ui.add_step(f"{name} ({cache_type})", partial(method, explain=True))
            else:
                ui.add_step(f"{name} ({cache_type})", partial(method, explain=False))

    if not ui.steps:
        print("No caches match the specified filters.")
        sys.exit(0)

    results = ui.run()
    
    if args.explain:
        # In explain mode, show cache information differently
        ui.show_explain_summary(results)
    else:
        ui.show_summary(results)


if __name__ == "__main__":
    main()
