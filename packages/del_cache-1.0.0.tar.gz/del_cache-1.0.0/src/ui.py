from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.console import Console
from rich.table import Table
from rich.text import Text
from rich import box


console = Console()


class UI:
    def __init__(self, *, verbose: bool, dry_run: bool):
        self.verbose = verbose
        self.dry_run = dry_run
        self.steps: list[tuple[str, callable]] = []

    def add_step(self, name: str, fn):
        self.steps.append((name, fn))

    def run(self) -> dict:
        results = {
            "total_cleaned": 0,
            "total_size": 0,
            "steps": [],
        }

        progress = Progress(
            SpinnerColumn(style="cyan"),
            TextColumn("[bold]{task.description}"),
            transient=True,
            console=console,
        )

        console.clear()

        title = "Package Manager Cache Cleaner"
        if self.dry_run:
            title += " [yellow](DRY RUN)[/]"

        console.rule(f"[bold cyan]{title}[/]")
        console.print()

        with progress:
            task_ids = {}

            # create all tasks first (mirrors static bash output)
            for name, _ in self.steps:
                task_ids[name] = progress.add_task(
                    description=f"{name}: checking...",
                    start=False,
                )

            # run them sequentially (but visually parallel)
            for name, fn in self.steps:
                task_id = task_ids[name]
                progress.start_task(task_id)

                try:
                    result = fn()
                    size = result.get("size_freed", 0)
                    msg = result.get("message", "")
                    cache_info = result.get("cache_info", None)

                    if result.get("skipped"):
                        progress.update(
                            task_id,
                            description=f"[yellow]✖ {name} — {msg}[/]",
                        )
                    elif result.get("success"):
                        progress.update(
                            task_id,
                            description=f"[green]✔ {name} — {msg}[/]",
                        )
                        if size > 0:
                            results["total_cleaned"] += 1
                            results["total_size"] += size
                    else:
                        progress.update(
                            task_id,
                            description=f"[red]✖ {name} — {msg}[/]",
                        )

                    if self.verbose:
                        for d in result.get("details", []):
                            console.print(f"  [dim]{d}[/]")

                    # Store cache info for explain mode
                    results["steps"].append({
                        "name": name,
                        "size_freed": size,
                        "cache_info": cache_info,
                        "result": result,
                    })

                except Exception as e:
                    progress.update(
                        task_id,
                        description=f"[red]✖ {name} — {e}[/]",
                    )

                progress.stop_task(task_id)

        return results

    def show_summary(self, results: dict):
        console.print()
        console.rule("[bold cyan]Summary[/]")

        if self.dry_run:
            console.print(
                f"[cyan]Cache directories identified:[/] {results['total_cleaned']}"
            )
            console.print(
                Text("Potential space: ", style="cyan")
                + Text(self._fmt(results["total_size"]), style="bold cyan")
            )
            console.print()
            console.print(
                "[yellow] ⚠ This was a dry run. Run without --dry-run to actually clean.[/]"
            )
        else:
            console.print(
                f"[green]Caches cleaned:[/] {results['total_cleaned']}"
            )
            console.print(
                f"[green]Space freed:[/] {self._fmt(results['total_size'])}"
            )

    def show_explain_summary(self, results: dict):
        """Show detailed cache information in explain mode."""
        console.print()
        console.rule("[bold cyan]Cache Information[/]")
        console.print()

        # Create a table for cache information
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Package Manager")
        table.add_column("Type")
        table.add_column("Location")
        table.add_column("Size")
        table.add_column("Status")

        for step in results["steps"]:
            cache_info = step.get("cache_info")
            result = step.get("result", {})
            
            if cache_info:
                # Try to get size if available
                size_str = "N/A"
                if "details" in result:
                    for detail in result["details"]:
                        if "Cache size:" in detail:
                            size_str = detail.split(":", 1)[1].strip()
                            break
                
                status = "Available"
                if result.get("skipped"):
                    status = f"Skipped: {result.get('message', 'Unknown')}"
                
                # Color code cache types
                type_color = {
                    "download": "green",
                    "build": "yellow",
                    "mixed": "cyan"
                }.get(cache_info.type, "white")
                
                table.add_row(
                    cache_info.name,
                    f"[{type_color}]{cache_info.type}[/{type_color}]",
                    str(cache_info.location),
                    size_str,
                    status
                )
            else:
                table.add_row(
                    step["name"].split(" ")[0],
                    "[dim]N/A[/dim]",
                    "[dim]Not found or not accessible[/dim]",
                    "[dim]N/A[/dim]",
                    f"[red]{result.get('message', 'Error')}[/red]"
                )

        console.print(table)
        
        # Show rationale for each cache
        console.print()
        console.rule("[bold cyan]Cache Explanations[/]")
        console.print()
        
        for step in results["steps"]:
            cache_info = step.get("cache_info")
            if cache_info:
                console.print(f"[bold cyan]{cache_info.name}[/bold cyan] ([green]{cache_info.type}[/green] cache):")
                console.print(f"  [dim]Description:[/dim] {cache_info.description}")
                console.print(f"  [dim]Location:[/dim] {cache_info.location}")
                for rationale in cache_info.rationale:
                    console.print(f"  • {rationale}")
                console.print()

    @staticmethod
    def _fmt(n: int) -> str:
        for unit in ("B", "KB", "MB", "GB"):
            if n < 1024:
                return f"{n:.1f}{unit}"
            n /= 1024
        return f"{n:.1f}TB"
