"""A module containing basic tools for connecting to eXist"""

from __future__ import annotations

import re
import warnings
from pathlib import PurePosixPath
from string import Template
from typing import TYPE_CHECKING, cast, Final, NamedTuple, Optional, TypedDict
from urllib.parse import urlparse

import httpx
from _delb.builder import parse_tree
from _delb.parser import ParserOptions
from _delb.typing import TagNodeType

from delb_existdb.exceptions import (
    DelbExistdbConfigError,
    DelbExistdbNotFound,
    DelbExistdbQueryError,
    DelbExistdbReadError,
    DelbExistdbWriteError,
)

if TYPE_CHECKING:
    from delb import Document


# constants


EXISTDB_NAMESPACE: Final = "http://exist.sourceforge.net/NS/exist"
DELB_EXISTDB_NAMESPACE: Final = "https://delb-existdb.readthedocs.io/"
TRANSPORT_PROTOCOLS: Final = {"https": 443, "http": 80}  # the order matters!


# client configuration


# TODO allow configuration with environment variables
DEFAULT_COLLECTION: Final = "/"
DEFAULT_HOST: Final = "localhost"
DEFAULT_PASSWORD: Final = ""
DEFAULT_PORT: Final = 8080
DEFAULT_PREFIX: Final = "exist"
DEFAULT_TRANSPORT: Final = "http"
DEFAULT_USER: Final = "admin"


class ClientConfig(TypedDict):
    base_url: str
    collection: str
    collection_base_url: str
    host: str
    parser_options: ParserOptions
    password: str
    port: int
    prefix: str
    transport: str
    user: str


class ClientOptions(TypedDict, total=False):
    collection: str
    host: str
    parser_options: ParserOptions
    password: str
    port: int
    prefix: str
    transport: str
    user: str


DEFAULT_CLIENT_OPTIONS: Final[ClientOptions] = {
    "collection": DEFAULT_COLLECTION,
    "host": DEFAULT_HOST,
    "password": DEFAULT_PASSWORD,
    "port": DEFAULT_PORT,
    "prefix": DEFAULT_PREFIX,
    "transport": DEFAULT_TRANSPORT,
    "user": DEFAULT_USER,
}


# query templates

# for successful code deduplication, these symbols are canonically used, most relate
# to those with the same name in the Python client code:
# @document_id
# @node_id
# @serialisat


class QueryTemplate(Template):
    delimiter = "@"


DOCUMENT_BY_ID: Final = "util:get-resource-by-absolute-id(@document_id)"
DOCUMENT_PATH_OF_NODE: Final = (
    'util:collection-name($node) || "/" || util:document-name($node)'
)


FETCH_NODE_QUERY: Final = QueryTemplate(
    f'util:node-by-id({DOCUMENT_BY_ID}, "@node_id")'
)

DELETE_NODE_QUERY: Final = QueryTemplate("update delete " + FETCH_NODE_QUERY.template)

GET_PATH_OF_RESOURCE_QUERY: Final = QueryTemplate(
    f"let $node := {DOCUMENT_BY_ID} return {DOCUMENT_PATH_OF_NODE}"
)

UPDATE_NODE_QUERY: Final = QueryTemplate(
    "update replace " + FETCH_NODE_QUERY.template + " with @serialisat"
)

XPATH_QUERY: Final = QueryTemplate(
    """\
for $node in @expression return
<s:result xmlns:s="DELB_EXISTDB_NAMESPACE"
  s:documentID="{util:absolute-resource-id($node)}"
  s:nodeID="{util:node-id($node)}"
  s:path="{DOCUMENT_PATH}"
>{$node}</s:result>
""".replace("DOCUMENT_PATH", DOCUMENT_PATH_OF_NODE).replace(
        "DELB_EXISTDB_NAMESPACE", DELB_EXISTDB_NAMESPACE
    )
)


XQUERY_PAYLOAD: Final = QueryTemplate("""\
<query xmlns="EXISTDB_NAMESPACE" start="1" max="0" cache="no">
  <text><![CDATA[@query]]></text>
  <properties>
    <property name="indent" value="no"/>
    <property name="wrap" value="yes"/>
  </properties>
</query>
""".replace("EXISTDB_NAMESPACE", EXISTDB_NAMESPACE))


# utils


content_type_is_xml: Final = re.compile(r"^(application|text)/xml(;.+)?").match


def _strip_outer_path_separators(path: str) -> str:
    return path.strip("/")


# database resources


class QueryResultItem(NamedTuple):
    document_id: str
    node_id: str
    document_path: str
    node: TagNodeType


# TODO protect from operations of deleted resources
class NodeResource:
    """
    A representation of an XML node in a eXist-db resource.
    Each object is coupled to an :class:`ExistClient`.
    Resources are identified by a document ID that points to the containing document and
    a node ID within that document.
    """

    __slots__ = (
        "__document_id",
        "__document_path",
        "__exist_client",
        "node",
        "__node_id",
    )

    def __init__(
        self,
        exist_client: "ExistClient",
        query_result: QueryResultItem,
    ):
        self.__document_id = query_result.document_id
        self.__document_path = query_result.document_path
        self.__exist_client = exist_client
        self.node = query_result.node
        """ A delb node representation of the node. """
        self.__node_id = query_result.node_id

    def __str__(self):
        return str(self.node)

    def update_pull(self):
        """
        Retrieve the current node state from the database and update the object.
        """
        self.node = self.__exist_client.fetch_node(
            document_id=self.__document_id, node_id=self.__node_id
        ).node

    def update_push(self):
        """
        Writes the current :attr:`NodeResource.node` contents to the database, replacing
        the previous state.
        """
        self.__exist_client.update_node(
            document_id=self.__document_id,
            node=self.node,
            node_id=self.__node_id,
        )

    def delete(self):
        """Deletes the node from the database."""
        self.__exist_client.delete_node(
            document_id=self.__document_id, node_id=self.__node_id
        )
        self.__document_id = ""
        self.__node_id = ""

    @property
    def abs_resource_id(self):
        warnings.warn(
            "This attribute was renamed to `document_id`.", category=DeprecationWarning
        )
        return self.__document_id

    @property
    def document_id(self):
        """
        The absolute resource ID pointing to a document in the database.
        """
        return self.__document_id

    @property
    def node_id(self):
        """
        The node ID locating the node relative to the containing document.
        """
        return self.__node_id

    @property
    def document_path(self):
        """
        The resource path pointing to the document.
        """
        return self.__document_path


# client


# TODO sort attributes and methods
class ExistClient:
    """
    An eXist-db client object to interact with a database instance.
    The client can be used for CRUD operations.
    Nodes can be queried using an XPath expression.
    Queried resources are identified by a document and a node ID (these map to
    eXist-db's absolute and relative resource IDs).

    .. caution::

        The node IDs are mere pointers by index to a node within a document. Structural
        changes to a document may invalidate these and lead to undesired behaviour.

    :param host: The name of the database serving host.
    :param port: The port the database instance is listening to.
    :param user: An optional username to authenticate.
    :param password: The accompanying password for authentication.
    :param prefix: The HTTP path prefix for the database instance.
    :param collection: The path to the collection which will be used as root for
                       all document paths.
    :param parser_options: A named tuple from delb to define the XML parser's behaviour.
    """

    __slots__ = ("__config", "http_client")

    def __init__(self, /, **options: ClientOptions):
        o: ClientConfig = cast("ClientConfig", DEFAULT_CLIENT_OPTIONS | options)

        o["prefix"] = prefix = _strip_outer_path_separators(o["prefix"])

        o["base_url"] = base_url = (
            f"{o['transport']}://{o['user']}:{o['password']}@{o['host']}:{o['port']}"
            f"/{prefix}"
        )

        if (collection := o["collection"]) == ".":
            o["collection"] = collection = "/"
        else:
            o["collection"] = collection = (
                f"/{_strip_outer_path_separators(collection)}"
            )

        o["collection_base_url"] = f"{base_url}/rest{collection}"

        if (parser_options := o.get("parser_options")) is None:
            o["parser_options"] = ParserOptions(
                encoding="UTF-8", reduce_whitespace=True
            )
        else:
            o["parser_options"] = parser_options._replace(encoding="UTF-8")

        self.__config: Final[ClientConfig] = o
        self.http_client: Final = httpx.Client(http2=True)

    @classmethod
    def from_url(
        cls,
        url: str,
        parser_options: Optional[ParserOptions] = None,
    ) -> ExistClient:
        """
        Returns a client instance from the given URL. Path parts that point to something
        beyond the database instance's path prefix are ignored.
        """
        parsed_url = urlparse(url)

        if parsed_url.scheme == "existdb":
            transport = None
        elif parsed_url.scheme.startswith("existdb+"):
            transport = parsed_url.scheme.split("+")[1]
            if transport not in TRANSPORT_PROTOCOLS:
                raise DelbExistdbConfigError(
                    f"Invalid transport '{transport}' for existdb."
                )
        else:
            raise DelbExistdbConfigError(
                f"Invalid URL scheme '{parsed_url.scheme}' for existdb."
            )

        user = parsed_url.username or ""
        password = parsed_url.password or ""
        host = parsed_url.hostname
        port = parsed_url.port

        if host is None:
            raise DelbExistdbConfigError("No host provided in URL.")

        if transport is None:
            probe_result = cls._probe_transport_and_port(
                f"{user}:{password}@{host}", port
            )
            if probe_result is None:
                raise DelbExistdbConfigError(
                    f"Couldn't figure out how to talk to {host}."
                )
            transport, port = probe_result
        elif port is None:
            port = TRANSPORT_PROTOCOLS[transport]

        prefix = cls._probe_instance_prefix(
            f"{transport}://{user}:{password}@{host}:{port}", parsed_url.path
        )
        if prefix is None:
            raise DelbExistdbConfigError(
                "Couldn't determine the location of the 'rest' interface."
            )

        return cls(
            **{  # type: ignore
                "host": host,
                "parser_options": parser_options,
                "password": password,
                "port": port,
                "prefix": prefix,
                "transport": transport,
                "user": user,
            }
        )

    @staticmethod
    def _probe_transport_and_port(
        host: str, port: Optional[int]
    ) -> tuple[str, int] | None:
        for transport, default_port in TRANSPORT_PROTOCOLS.items():
            _port = port or default_port
            try:
                httpx.head(f"{transport}://{host}:{_port}/")
            except httpx.TransportError:
                pass
            else:
                return transport, _port
        return None

    @staticmethod
    def _probe_instance_prefix(base: str, path: str) -> Optional[str]:
        path_parts = PurePosixPath(path).parts[1:]
        encountered_collection = False

        # looks for longest path as different instances could have overlapping prefixes
        # will return false results if a path contained a part named "rest"
        for i in range(len(path_parts), 0, -1):
            response = httpx.get(f"{base}/{'/'.join(path_parts[:i])}/rest/")

            if response.status_code == 401:
                raise DelbExistdbConfigError("Failed authentication.")

            if not content_type_is_xml(response.headers.get("Content-Type", "")):
                if encountered_collection:
                    break
                else:
                    continue

            parsed_response = parse_tree(
                response.text, options=ParserOptions(encoding="UTF-8")
            )
            assert isinstance(parsed_response, TagNodeType)
            if (
                parsed_response.namespace == EXISTDB_NAMESPACE
                and parsed_response.local_name == "result"
            ):
                encountered_collection = True
            elif encountered_collection:
                break

        if encountered_collection:
            return "/".join(path_parts[:i])
        else:
            return None

    def _get_altered_client(self, **options: ClientOptions) -> ExistClient:
        return self.__class__(**(self.__config | options))  # type: ignore

    @property
    def base_url(self) -> str:
        """The base URL pointing to the eXist instance."""
        return self.__config["base_url"]

    @property
    def transport(self) -> str:
        """The used transport protocol."""
        return self.__config["transport"]

    @property
    def host(self) -> str:
        """The database hostname."""
        return self.__config["host"]

    @property
    def port(self) -> int:
        """The database port number."""
        return self.__config["port"]

    @property
    def user(self) -> str:
        """The user name used to connect to the database."""
        return self.__config["user"]

    @property
    def parser_options(self) -> ParserOptions:
        return self.__config["parser_options"]

    @property
    def password(self) -> str:
        """The password used to connect to the database."""
        return self.__config["password"]

    @property
    def prefix(self) -> str:
        """The URL prefix of the database."""
        return str(self.__config["prefix"])

    @property
    def collection(self) -> str:
        """
        The collection for database queries. The attribute can be changed on an
        initialized client.
        """
        return self.__config["collection"]

    @property
    def collection_base_url(self) -> str:
        """
        The URL pointing to the configured collection.
        """
        return self.__config["collection_base_url"]

    # TODO rename to xquery
    def query(self, query_expression: str) -> TagNodeType:
        """
        Make a database query using XQuery. The configured collection will be the
        starting point of the query.

        :param query_expression: XQuery expression.
        :return: The query result as a :class:`delb.TagNode` object.
        """
        payload = XQUERY_PAYLOAD.substitute(query=query_expression)
        response = self.http_client.post(
            self.collection_base_url,
            headers={"Content-Type": "application/xml"},
            content=payload,
        )

        if response.status_code == 400:
            raise DelbExistdbQueryError(payload, response)

        try:
            response.raise_for_status()
        except Exception as e:
            raise DelbExistdbReadError("Unhandled query error.") from e

        result = parse_tree(response.text, options=self.parser_options)
        assert isinstance(result, TagNodeType)
        return result

    def xpath(self, expression: str) -> list[NodeResource]:
        """
        Retrieve a set of resources from the database using an XPath expression.
        The configured collection will be the starting point of the query.

        :param expression: XPath expression (whatever version your eXist instance
                           supports via its RESTful API)
        :return: The query results as a list of :class:`NodeResource` objects.
        """
        # TODO namespaces support
        results_node = self.query(XPATH_QUERY.substitute(expression=expression))
        assert results_node.namespace == EXISTDB_NAMESPACE
        assert results_node.local_name == "result"
        resources = []
        for result_node in results_node.xpath(
            "//result", namespaces={"": DELB_EXISTDB_NAMESPACE}
        ):
            assert isinstance(result_node, TagNodeType)
            content_node = result_node[0].detach()
            assert isinstance(content_node, TagNodeType)
            query_result = QueryResultItem(
                document_id=result_node["documentID"].value,  # type: ignore
                node_id=result_node["nodeID"].value,  # type: ignore
                document_path=result_node["path"].value,  # type: ignore
                node=content_node,
            )
            resources.append(NodeResource(exist_client=self, query_result=query_result))
        return resources

    def retrieve_resource(self, abs_resource_id: str, node_id: str) -> NodeResource:
        """Deprecated. Use :meth:`ExistClient.fetch_node`"""
        warnings.warn(
            "This method has been renamed to `fetch_node`.", category=DeprecationWarning
        )
        return self.fetch_node(abs_resource_id, node_id)

    # TODO handle unexisting nodes
    def fetch_node(self, document_id: str, node_id: str) -> NodeResource:
        """
        Retrieve a node resource by its internal database IDs.

        :param document_id: The ID of a document.
        :param node_id: The node ID locating a node inside a document (optional).
        :return: The queried resource object.
        """
        queried_node = self.query(
            FETCH_NODE_QUERY.substitute(document_id=document_id, node_id=node_id)
        )[0].detach()
        assert isinstance(queried_node, TagNodeType)
        return NodeResource(
            self,
            QueryResultItem(
                document_id=document_id,
                node_id=node_id,
                document_path=self.__get_document_path_of_node(document_id),
                node=queried_node,
            ),
        )

    def __get_document_path_of_node(self, document_id: str) -> str:
        result_node = (
            self.query(GET_PATH_OF_RESOURCE_QUERY.substitute(document_id=document_id))
            .xpath("//result/value", namespaces={"": EXISTDB_NAMESPACE})
            .first
        )
        assert isinstance(result_node, TagNodeType)
        return result_node.full_text

    def update_node(self, node: TagNodeType, document_id: str, node_id: str):
        """
        Replace a node with the contents of the given one.

        :param node: An XML node to replace the old one with.
        :param document_id: The document ID of the target.
        :param node_id: The node ID locating the node inside the containing document.
        """
        self.query(
            UPDATE_NODE_QUERY.substitute(
                document_id=document_id,
                node_id=node_id,
                serialisat=node.serialize(),
            )
        )

    def delete_node(self, document_id: str, node_id: str = "") -> None:
        """
        Remove a node from the database.

        :param document_id: The absolute resource ID pointing to the document.
        :param node_id: The node ID locating a node inside a document (optional).
        """
        self.query(
            DELETE_NODE_QUERY.substitute(document_id=document_id, node_id=node_id)
        )

    def delete_document(self, path: str) -> None:
        """
        Removes a document from the associated database.

        :param path: The path pointing to the document within the collection.
        """
        response = self.http_client.delete(
            f"{self.collection_base_url}/{_strip_outer_path_separators(path)}"
        )
        if response.status_code == 404:
            raise DelbExistdbNotFound(f"Document '{path}' not found.")
        try:
            response.raise_for_status()
        except Exception as e:
            raise DelbExistdbWriteError("Unhandled error while deleting.") from e

    def fetch_document(self, path: str) -> Document:
        """
        Fetches a document from the client's configured collection.

        :param path: Path of the document.
        """
        from delb import Document  # TODO future lazy import? (PEP-810)

        return Document(
            f"{self.collection_base_url}/{_strip_outer_path_separators(path)}",
            existdb_client=self,
            parser_options=self.parser_options,
        )
