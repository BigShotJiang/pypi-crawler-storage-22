import { openPanel } from "../state.js";
import { CopyBtn } from "./CopyBtn.jsx";
import { taskIdStr } from "../utils.js";

/**
 * Renders /cost command output - cost analytics summary.
 * @param {Object} props
 * @param {Object|null} props.result - Cost summary data from backend
 */
export function CostBlock({ result }) {
  if (!result) {
    return (
      <div class="cost-block error">
        <div class="cost-header">Cost Summary</div>
        <div class="cost-body">Error loading cost data</div>
      </div>
    );
  }

  // result may be a JSON string if loaded from DB (not yet parsed)
  const data = typeof result === "string" ? (() => { try { return JSON.parse(result); } catch { return null; } })() : result;
  if (!data || !data.today || !data.this_week) {
    return (
      <div class="cost-block error">
        <div class="cost-header">Cost Summary</div>
        <div class="cost-body">Error loading cost data</div>
      </div>
    );
  }

  const { today, this_week, top_tasks } = data;

  const formatCost = (amount) => {
    if (amount == null) return "$0.00";
    return `$${Number(amount).toFixed(2)}`;
  };

  const formatTaskTitle = (title) => {
    if (!title) return "Unknown";
    return title.length > 40 ? title.slice(0, 40) + "..." : title;
  };

  const handleTaskClick = (e, taskId) => {
    e.preventDefault();
    openPanel('task', taskId);
  };

  return (
    <div class="cost-block">
      <div class="cost-header">Cost Summary</div>
      <div class="cost-body">
        <div class="cost-section">
          <div class="cost-row">
            <span class="cost-label">Today:</span>
            <span class="cost-value">
              {formatCost(today.total_cost_usd)} across {today.task_count} task{today.task_count !== 1 ? 's' : ''}
              {today.task_count > 0 && ` (avg ${formatCost(today.avg_cost_per_task)}/task)`}
            </span>
          </div>
          <div class="cost-row">
            <span class="cost-label">This Week:</span>
            <span class="cost-value">
              {formatCost(this_week.total_cost_usd)} across {this_week.task_count} task{this_week.task_count !== 1 ? 's' : ''}
              {this_week.task_count > 0 && ` (avg ${formatCost(this_week.avg_cost_per_task)}/task)`}
            </span>
          </div>
        </div>

        {top_tasks && top_tasks.length > 0 && (
          <div class="cost-section">
            <div class="cost-section-title">Top Tasks by Cost:</div>
            {top_tasks.map(task => (
              <div key={task.task_id} class="cost-task-row">
                <span
                  class="task-id copyable cost-task-link"
                  onClick={(e) => handleTaskClick(e, task.task_id)}
                >
                  {taskIdStr(task.task_id)}<CopyBtn text={taskIdStr(task.task_id)} />
                </span>
                <span class="cost-task-title">{formatTaskTitle(task.title)}</span>
                <span class="cost-task-amount">{formatCost(task.cost_usd)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
