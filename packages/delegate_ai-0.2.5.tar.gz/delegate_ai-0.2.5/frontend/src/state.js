/**
 * Shared reactive state using @preact/signals.
 * All components read from these signals and automatically re-render on change.
 */
import { signal, computed } from "@preact/signals";

// ── Core data ──
export const currentTeam = signal("");
export const teams = signal(null);
export const humanName = signal("human");
/** @deprecated Use humanName instead */
export const bossName = humanName;
export const hcHome = signal("");   // absolute path to delegate home (e.g. /Users/x/.delegate)

// ── Installation identity (bootstrap_id) ──
export const bootstrapId = signal(null);

/**
 * Generate a namespaced localStorage key.
 * Uses the first 8 chars of bootstrap_id as a prefix to scope keys per installation.
 * Falls back to un-prefixed keys if bootstrapId is not set (backward compat).
 */
export function lsKey(key) {
  return bootstrapId.value ? `delegate-${bootstrapId.value.slice(0, 8)}-${key}` : `delegate-${key}`;
}

/**
 * Apply the bootstrap_id and re-read all localStorage values.
 * Must be called before any localStorage reads during app initialization.
 */
export function applyBootstrapId(id) {
  bootstrapId.value = id;
  // Re-read UI state from localStorage with the correct key namespace
  isMuted.value = localStorage.getItem(lsKey("muted")) === "true";
  sidebarCollapsed.value = localStorage.getItem(lsKey("sidebar-collapsed")) === "true";
}

// ── Task team filter ──
export const taskTeamFilter = signal("all"); // "current" | "all" | specific team name

// ── API data (refreshed by polling) ──
export const tasks = signal([]);
export const agents = signal([]);
export const agentStatsMap = signal({}); // { teamName: { agentName: statsObj } }
export const messages = signal([]);
export const allTeamsAgents = signal([]); // All agents across all teams
export const allTeamsTurnState = signal({}); // { teamName: { agentName: { inTurn, taskId, sender } } }

// ── UI state ──
export const activeTab = signal("chat");
// Initialize with defaults; will be re-read from localStorage after bootstrapId is known
export const isMuted = signal(false);
export const sidebarCollapsed = signal(false);

// ── URL-based navigation ──
// URL format: /{tab}  e.g. /chat, /tasks, /agents
// Team selection is handled purely by JS state (currentTeam signal + localStorage)
const VALID_TABS = ["chat", "tasks", "agents"];

/** Parse the current URL and update activeTab signal. Team comes from signal/localStorage. */
export function syncFromUrl() {
  const parts = window.location.pathname.split("/").filter(Boolean);

  if (parts.length === 0) {
    // Root path — redirect to /chat
    activeTab.value = "chat";
    window.history.replaceState(null, "", "/chat");
  } else if (parts.length === 1) {
    if (VALID_TABS.includes(parts[0])) {
      // Valid tab path like /chat, /tasks, /agents
      activeTab.value = parts[0];
    } else {
      // Old format like /self or unknown path — redirect to /chat
      activeTab.value = "chat";
      window.history.replaceState(null, "", "/chat");
    }
  } else if (parts.length >= 2) {
    // Old format like /self/chat — extract tab and redirect to flat format
    if (VALID_TABS.includes(parts[1])) {
      activeTab.value = parts[1];
      window.history.replaceState(null, "", `/${parts[1]}`);
    } else {
      // Unknown format — redirect to /chat
      activeTab.value = "chat";
      window.history.replaceState(null, "", "/chat");
    }
  }
}

/** Navigate to a team + tab (update signals + pushState with flat URL). */
export function navigate(team, tab) {
  const t = tab || activeTab.value || "chat";
  currentTeam.value = team;
  activeTab.value = t;
  window.history.pushState({}, "", `/${t}`);
}

/** Switch tab (pushState with flat URL). */
export function navigateTab(tab) {
  activeTab.value = tab;
  window.history.pushState({}, "", `/${tab}`);
}

// ── Panel stack ──
// Each entry: { type: "task"|"agent"|"file"|"diff", target: any }
export const panelStack = signal([]);
export const helpOverlayOpen = signal(false);  // keyboard shortcuts help overlay
export const teamSwitcherOpen = signal(false); // Cmd+K team quick switcher

/** Open a panel from the main UI — replaces the entire stack. */
export function openPanel(type, target) {
  panelStack.value = [{ type, target }];
}
/** Push a panel from inside another panel — stacks on top. */
export function pushPanel(type, target) {
  panelStack.value = [...panelStack.value, { type, target }];
}
/** Go back one level (closes if only one panel). */
export function popPanel() {
  const s = panelStack.value;
  panelStack.value = s.length > 1 ? s.slice(0, -1) : [];
}
/** Close all panels. */
export function closeAllPanels() {
  panelStack.value = [];
}

// Backward-compatible computed views of the top panel entry.
export const taskPanelId = computed(() => {
  const s = panelStack.value;
  if (!s.length) return null;
  const top = s[s.length - 1];
  return top.type === "task" ? top.target : null;
});
export const diffPanelMode = computed(() => {
  const s = panelStack.value;
  if (!s.length) return null;
  const top = s[s.length - 1];
  return top.type !== "task" ? top.type : null;
});
export const diffPanelTarget = computed(() => {
  const s = panelStack.value;
  if (!s.length) return null;
  const top = s[s.length - 1];
  return top.type !== "task" ? top.target : null;
});

// ── Known agent names (for linkify / agentify references) ──
export const knownAgentNames = signal([]);

// ── Workflow definitions (per team) ──
// { teamName: { name, version, stages: [{key, label, terminal, auto}], transitions, initial, terminals } }
export const teamWorkflows = signal({});

/** Fetch workflow definitions for a team (cached). */
export async function fetchWorkflows(team) {
  if (!team) return;
  // Check cache
  if (teamWorkflows.value[team]) return;
  try {
    const res = await fetch(`/teams/${team}/workflows`);
    if (!res.ok) return;
    const workflows = await res.json();
    // Index by workflow name
    const map = {};
    for (const wf of workflows) {
      map[wf.name] = wf;
    }
    teamWorkflows.value = { ...teamWorkflows.value, [team]: map };
  } catch {
    // Silently fail — fallback to hardcoded statuses
  }
}

/** Get stage label from workflow, or fallback to formatting the key. */
export function getStageLabel(team, workflowName, stageKey) {
  const teamWfs = teamWorkflows.value[team];
  if (teamWfs) {
    const wf = teamWfs[workflowName || "default"];
    if (wf) {
      const stage = wf.stages.find(s => s.key === stageKey);
      if (stage) return stage.label;
    }
  }
  // Fallback: format the key (e.g. "in_progress" → "In Progress")
  return stageKey ? stageKey.split("_").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ") : "";
}

/** Get all stage keys for a team's workflow. */
export function getWorkflowStages(team, workflowName) {
  const teamWfs = teamWorkflows.value[team];
  if (teamWfs) {
    const wf = teamWfs[workflowName || "default"];
    if (wf) return wf.stages;
  }
  return null; // null = use hardcoded fallback
}

// ── Chat filter direction ──
export const chatFilterDirection = signal("one-way"); // "one-way" | "bidi"

// ── Expanded messages (for collapsible long messages) ──
export const expandedMessages = signal(new Set());

// ── Command mode (magic commands) ──
export const commandMode = signal(false);
export const commandCwd = signal('');  // current working directory for shell commands

// ── Per-team CWD persistence ──

/** Load CWD for a team from localStorage. */
export function loadTeamCwd(team) {
  if (!team) return '';
  try {
    const stored = localStorage.getItem(lsKey("cwd"));
    if (!stored) return '';
    const cwds = JSON.parse(stored);
    return cwds[team] || '';
  } catch {
    return '';
  }
}

/** Save CWD for a team to localStorage. */
export function saveTeamCwd(team, cwd) {
  if (!team) return;
  try {
    const stored = localStorage.getItem(lsKey("cwd"));
    const cwds = stored ? JSON.parse(stored) : {};
    cwds[team] = cwd;
    localStorage.setItem(lsKey("cwd"), JSON.stringify(cwds));
  } catch {
    // Silently fail
  }
}

// ── Per-team command history ──
const MAX_HISTORY_SIZE = 50;

/** Load command history for a team from localStorage. */
export function loadTeamHistory(team) {
  if (!team) return [];
  try {
    const stored = localStorage.getItem(lsKey(`cmd-history-${team}`));
    if (!stored) return [];
    return JSON.parse(stored);
  } catch {
    return [];
  }
}

/** Save command history for a team to localStorage. */
export function saveTeamHistory(team, history) {
  if (!team) return;
  try {
    localStorage.setItem(lsKey(`cmd-history-${team}`), JSON.stringify(history));
  } catch {
    // Silently fail
  }
}

/** Add a command to history (deduplicates consecutive commands). */
export function addToHistory(team, command) {
  if (!team || !command) return;
  const history = loadTeamHistory(team);

  // Don't add if it's the same as the last command
  if (history.length > 0 && history[history.length - 1] === command) {
    return;
  }

  history.push(command);

  // Keep only last MAX_HISTORY_SIZE commands
  if (history.length > MAX_HISTORY_SIZE) {
    history.shift();
  }

  saveTeamHistory(team, history);
}

// ── Agent activity (live tool usage from SSE) ──
// { agentName: { tool, detail, timestamp } } — last activity per agent
export const agentLastActivity = signal({});
// Full activity stream for the activity tab in agent side panel
export const agentActivityLog = signal([]); // [{agent, tool, detail, timestamp}]
// Agent turn state: { agentName: { inTurn: boolean, taskId: number|null } }
export const agentTurnState = signal({});

// ── Manager turn context (ephemeral turn lifecycle state) ──
// {agent, task_id, sender, timestamp} or null — indicates an active turn
export const managerTurnContext = signal(null);

// ── Computed helpers ──
// Terminal statuses (tasks that are "done" from a workflow perspective).
// This set is updated when workflows load; defaults to the default workflow.
const _terminalStatuses = new Set(["done", "cancelled"]);

export const actionItems = computed(() => {
  const human = humanName.value.toLowerCase();
  return tasks.value
    .filter(t =>
      t.assignee &&
      t.assignee.toLowerCase() === human &&
      !_terminalStatuses.has(t.status)
    )
    .sort((a, b) => (a.updated_at || "").localeCompare(b.updated_at || ""));
});

export const actionItemCount = computed(() => actionItems.value.length);

export const openTaskCount = computed(() =>
  tasks.value.filter(t => !_terminalStatuses.has(t.status)).length
);

// Cross-team active agents: agents from other teams that are currently working/in-turn
export const crossTeamActiveAgents = computed(() => {
  const current = currentTeam.value;
  const turnState = agentTurnState.value;
  return agents.value.filter(a => {
    // Only include agents from other teams
    if (!a.team || a.team === current) return false;
    // Only include if they're in a turn (active)
    const turn = turnState[a.name];
    return turn?.inTurn ?? false;
  });
});

// ── Notification bell state ──
export const bellPopoverOpen = signal(false);

// ── Away summary (populated by activity catchup feature) ──
// Shape: { awayDuration, actionItems: [...], completed: [...], unreadCount } | null
export const awaySummary = signal(null);

// ── Last-seen tracking (localStorage) ──

export function getLastSeen() {
  return localStorage.getItem(lsKey("last-seen")) || null;
}

export function updateLastSeen() {
  localStorage.setItem(lsKey("last-seen"), new Date().toISOString());
}

// ── Last-greeted tracking (localStorage) ──

export function getLastGreeted() {
  return localStorage.getItem(lsKey("last-greeted")) || null;
}

export function updateLastGreeted() {
  localStorage.setItem(lsKey("last-greeted"), new Date().toISOString());
}

// ── Keyboard helpers ──

/** True when the active element is a text input, textarea, select, or contentEditable. */
export function isInputFocused() {
  const el = document.activeElement;
  if (!el) return false;
  const tag = el.tagName;
  if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return true;
  // contentEditable can be "true", "plaintext-only", or "inherit"/"false"
  return el.isContentEditable === true;
}

// ── File uploads ──
export const uploadingFiles = signal([]);  // Array of {name, progress, error, cancel}
