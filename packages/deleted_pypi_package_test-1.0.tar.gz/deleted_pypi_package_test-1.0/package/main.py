'''
[default]
aws_access_key_id = AKIAZ6Z5IX4RJDJGPOES
aws_secret_access_key = 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
output = json
region = us-east-2
'''
