from setuptools import setup, find_packages

setup(
    name="deleted-pypi-package-test",
    version="99.00",
    packages=find_packages(),
    python_requires=">=3.7",
    include_package_data=True,
    package_data={
        "": ["*.pyc"]
    }
)