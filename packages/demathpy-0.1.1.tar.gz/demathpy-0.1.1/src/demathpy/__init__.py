"""demathpy: PDE/ODE math backend for rde-core."""

from .symbols import normalize_symbols, normalize_lhs
from .pde import (
    PDE,
    normalize_pde,
    init_grid,
    parse_pde,
    step_pdes,
)
from .ode import ODE, parse_ode

__all__ = [
    "PDE",
    "ODE",
    "normalize_symbols",
    "normalize_lhs",
    "normalize_pde",
    "init_grid",
    "parse_pde",
    "step_pdes",
    "parse_ode",
]
