# Demoekz - Django Music Application System

Django music request management system.

```bash

pip install demekz