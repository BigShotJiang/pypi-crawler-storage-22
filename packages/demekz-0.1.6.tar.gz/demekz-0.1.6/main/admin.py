from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils.html import format_html
from .models import CustomUser, MusicApplication


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'full_name', 'phone', 'is_staff')
    list_filter = ('is_staff', 'is_superuser')
    search_fields = ('username', 'email', 'full_name', 'phone')
    fieldsets = UserAdmin.fieldsets + (
        ('Дополнительная информация', {
            'fields': ('full_name', 'phone')
        }),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Дополнительная информация', {
            'fields': ('full_name', 'phone', 'email')
        }),
    )


@admin.register(MusicApplication)
class MusicApplicationAdmin(admin.ModelAdmin):
    list_display = ('id', 'project_name', 'user', 'event_date', 'music_genre',
                    'participation_format', 'status', 'image_preview', 'created_at')
    list_filter = ('status', 'music_genre', 'participation_format', 'created_at')
    search_fields = ('project_name', 'user__username', 'user__full_name', 'description')
    list_editable = ('status',)
    readonly_fields = ('created_at', 'updated_at', 'image_preview_large')
    fieldsets = (
        ('Основная информация', {
            'fields': ('user', 'project_name', 'description')
        }),
        ('Детали мероприятия', {
            'fields': ('event_date', 'music_genre', 'participation_format')
        }),
        ('Изображение', {
            'fields': ('image', 'image_preview_large')
        }),
        ('Статус заявки', {
            'fields': ('status', 'admin_comment')
        }),
        ('Дополнительная информация', {
            'fields': ('created_at', 'updated_at')
        }),
    )

    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" style="max-height: 50px; max-width: 50px;" />', obj.image.url)
        return "Нет изображения"

    image_preview.short_description = 'Изображение'

    def image_preview_large(self, obj):
        if obj.image:
            return format_html('<img src="{}" style="max-height: 300px; max-width: 100%;" />', obj.image.url)
        return "Нет изображения"

    image_preview_large.short_description = 'Предпросмотр изображения'