from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser, MusicApplication
import re


class CustomUserCreationForm(UserCreationForm):
    password1 = forms.CharField(
        label="Пароль",
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        min_length=8
    )
    password2 = forms.CharField(
        label="Подтверждение пароля",
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )

    class Meta:
        model = CustomUser
        fields = ('username', 'full_name', 'phone', 'email')
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'full_name': forms.TextInput(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '8(XXX)XXX-XX-XX'
            }),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }
        labels = {
            'username': 'Логин',
            'full_name': 'ФИО',
            'phone': 'Телефон',
            'email': 'Email',
        }

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if not re.match(r'^[a-zA-Z0-9]{6,}$', username):
            raise forms.ValidationError(
                'Логин должен содержать минимум 6 символов содержащие латиницу и цифры'
            )
        return username

    def clean_full_name(self):
        full_name = self.cleaned_data.get('full_name')
        if not re.match(r'^[а-яА-ЯёЁ\s]+$', full_name):
            raise forms.ValidationError(
                'ФИО должно содержать только кириллические символы и пробелы'
            )
        return full_name

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        if not re.match(r'^8\(\d{3}\)\d{3}-\d{2}-\d{2}$', phone):
            raise forms.ValidationError(
                'Телефон должен быть в формате: 8(XXX)XXX-XX-XX'
            )
        return phone


class CustomAuthenticationForm(AuthenticationForm):
    username = forms.CharField(
        label="Логин",
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    password = forms.CharField(
        label="Пароль",
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )


class MusicApplicationForm(forms.ModelForm):
    class Meta:
        model = MusicApplication
        fields = ('project_name', 'event_date', 'music_genre', 'participation_format', 'description', 'image')
        widgets = {
            'project_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Введите название проекта или мероприятия'
            }),
            'event_date': forms.DateInput(
                attrs={
                    'class': 'form-control',
                    'type': 'date'
                },
                format='%Y-%m-%d'
            ),
            'music_genre': forms.Select(attrs={'class': 'form-control'}),
            'participation_format': forms.Select(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Опишите ваш проект, музыкальный стиль, цели и т.д.'
            }),
            'image': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': 'image/*'
            }),
        }
        labels = {
            'project_name': 'Название проекта/мероприятия',
            'event_date': 'Дата мероприятия',
            'music_genre': 'Жанр музыки',
            'participation_format': 'Формат участия',
            'description': 'Описание проекта',
            'image': 'Изображение проекта',
        }

    def clean_image(self):
        image = self.cleaned_data.get('image')
        if image:
            max_size = 5 * 1024 * 1024
            if image.size > max_size:
                raise forms.ValidationError('Размер изображения не должен превышать 5MB.')
        return image


class MusicApplicationAdminForm(forms.ModelForm):
    class Meta:
        model = MusicApplication
        fields = ('status', 'admin_comment')
        widgets = {
            'status': forms.Select(attrs={'class': 'form-control'}),
            'admin_comment': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Комментарий для пользователя'
            }),
        }