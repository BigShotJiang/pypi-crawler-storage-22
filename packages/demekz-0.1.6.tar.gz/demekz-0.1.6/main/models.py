from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator, MinLengthValidator, FileExtensionValidator
import re
import os
from django.core.exceptions import ValidationError
from django.utils import timezone


class CustomUser(AbstractUser):
    phone_regex = RegexValidator(
        regex=r'^8\(\d{3}\)\d{3}-\d{2}-\d{2}$',
        message="Телефон должен быть в формате: 8(XXX)XXX-XX-XX"
    )

    username = models.CharField(
        max_length=150,
        unique=True,
        validators=[
            MinLengthValidator(6),
            RegexValidator(
                regex=r'^[a-zA-Z0-9]+$',
                message='Логин должен содержать только латинские буквы и цифры'
            )
        ],
        verbose_name='Логин'
    )

    full_name = models.CharField(
        max_length=255,
        validators=[
            RegexValidator(
                regex=r'^[а-яА-ЯёЁ\s]+$',
                message='ФИО должно содержать только кириллические символы и пробелы'
            )
        ],
        verbose_name='ФИО'
    )

    phone = models.CharField(
        max_length=20,
        validators=[phone_regex],
        unique=True,
        verbose_name='Телефон'
    )

    email = models.EmailField(unique=True, verbose_name='Email')

    def clean(self):
        super().clean()
        if not re.match(r'^[a-zA-Z0-9]{6,}$', self.username):
            raise ValidationError({
                'username': 'Логин должен содержать минимум 6 символов (латиница и цифры)'
            })

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'


def music_application_image_path(instance, filename):
    ext = filename.split('.')[-1]
    filename = f'{instance.id}_{timezone.now().strftime("%Y%m%d_%H%M%S")}.{ext}'
    return f'application_images/{instance.user.id}/{filename}'


class MusicApplication(models.Model):
    STATUS_CHOICES = [
        ('new', 'Новая'),
        ('review', 'Рассматривается'),
        ('approved', 'Одобрена'),
        ('rejected', 'Отклонена'),
    ]

    GENRE_CHOICES = [
        ('pop', 'Поп-музыка'),
        ('rock', 'Рок'),
        ('jazz', 'Джаз'),
        ('classical', 'Классическая'),
        ('hiphop', 'Хип-хоп'),
        ('electronic', 'Электронная'),
        ('folk', 'Фолк'),
        ('rnb', 'R&B'),
        ('metal', 'Метал'),
        ('other', 'Другой'),
    ]

    FORMAT_CHOICES = [
        ('solo', 'Сольное выступление'),
        ('group', 'Групповое выступление'),
        ('online', 'Онлайн-трансляция'),
        ('recording', 'Запись трека'),
        ('collaboration', 'Коллаборация'),
        ('other', 'Другой формат'),
    ]

    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, verbose_name='Пользователь')
    project_name = models.CharField(max_length=255, verbose_name='Название музыкального проекта/мероприятия')
    event_date = models.DateField(verbose_name='Дата мероприятия')
    music_genre = models.CharField(
        max_length=20,
        choices=GENRE_CHOICES,
        default='pop',
        verbose_name='Жанр музыки'
    )
    participation_format = models.CharField(
        max_length=20,
        choices=FORMAT_CHOICES,
        default='solo',
        verbose_name='Формат участия'
    )
    description = models.TextField(blank=True, null=True, verbose_name='Описание проекта')

    image = models.ImageField(
        upload_to=music_application_image_path,
        blank=True,
        null=True,
        verbose_name='Изображение проекта',
        validators=[
            FileExtensionValidator(
                allowed_extensions=['jpg', 'jpeg', 'png', 'gif', 'bmp'],
                message='Допустимые форматы: JPG, JPEG, PNG, GIF, BMP'
            )
        ]
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='new',
        verbose_name='Статус заявки'
    )
    admin_comment = models.TextField(blank=True, null=True, verbose_name='Комментарий администратора')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата создания')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='Дата обновления')

    class Meta:
        verbose_name = 'Музыкальная заявка'
        verbose_name_plural = 'Музыкальные заявки'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.project_name} - {self.user.username}"

    def delete(self, *args, **kwargs):
        if self.image:
            if os.path.isfile(self.image.path):
                os.remove(self.image.path)
        super().delete(*args, **kwargs)