from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from .forms import (
    CustomUserCreationForm,
    CustomAuthenticationForm,
    MusicApplicationForm,
    MusicApplicationAdminForm
)
from .models import MusicApplication


def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Регистрация успешно завершена!')
            return redirect('profile')
    else:
        form = CustomUserCreationForm()

    return render(request, 'main/register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Добро пожаловать, {user.username}!')

                if username == 'Admin':
                    return redirect('admin_dashboard')
                return redirect('profile')
            else:
                messages.error(request, 'Неверный логин или пароль.')
        else:
            messages.error(request, 'Неверный логин или пароль.')
    else:
        form = CustomAuthenticationForm()

    return render(request, 'main/login.html', {'form': form})


def logout_view(request):
    logout(request)
    messages.info(request, 'Вы вышли из системы.')
    return redirect('login')


@login_required
def profile_view(request):
    total_applications = MusicApplication.objects.filter(user=request.user).count()
    new_applications = MusicApplication.objects.filter(
        user=request.user,
        status='new'
    ).count()
    under_review = MusicApplication.objects.filter(
        user=request.user,
        status='review'
    ).count()
    approved_applications = MusicApplication.objects.filter(
        user=request.user,
        status='approved'
    ).count()
    rejected_applications = MusicApplication.objects.filter(
        user=request.user,
        status='rejected'
    ).count()

    recent_applications = MusicApplication.objects.filter(
        user=request.user
    ).order_by('-created_at')[:3]

    context = {
        'total_applications': total_applications,
        'new_applications': new_applications,
        'under_review': under_review,
        'approved_applications': approved_applications,
        'rejected_applications': rejected_applications,
        'recent_applications': recent_applications,
    }

    return render(request, 'main/profile.html', context)


@login_required
def applications_view(request):
    applications = MusicApplication.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'main/applications.html', {'applications': applications})


@login_required
def create_application_view(request):
    if request.method == 'POST':
        form = MusicApplicationForm(request.POST, request.FILES)  # Добавлен request.FILES для изображений
        if form.is_valid():
            application = form.save(commit=False)
            application.user = request.user
            application.save()
            messages.success(request,
                             'Заявка успешно создана! Она получила статус "Новая" и направлена на рассмотрение.')
            return redirect('applications')
    else:
        form = MusicApplicationForm()

    return render(request, 'main/create_application.html', {'form': form})


def is_admin(user):
    return user.is_authenticated and user.username == 'Admin'


@user_passes_test(is_admin)
def admin_dashboard_view(request):
    applications = MusicApplication.objects.all().order_by('-created_at')

    if request.method == 'POST':
        application_id = request.POST.get('application_id')
        new_status = request.POST.get('status')
        admin_comment = request.POST.get('admin_comment', '')

        if application_id and new_status:
            application = get_object_or_404(MusicApplication, id=application_id)
            application.status = new_status
            application.admin_comment = admin_comment
            application.save()

            status_display = dict(MusicApplication.STATUS_CHOICES).get(new_status, new_status)
            messages.success(request, f'Статус заявки #{application_id} изменен на "{status_display}"')
            return redirect('admin_dashboard')

    return render(request, 'main/admin_dashboard.html', {'applications': applications})


@user_passes_test(is_admin)
def admin_application_detail_view(request, application_id):
    application = get_object_or_404(MusicApplication, id=application_id)

    if request.method == 'POST':
        form = MusicApplicationAdminForm(request.POST, instance=application)
        if form.is_valid():
            form.save()
            messages.success(request, 'Заявка успешно обновлена!')
            return redirect('admin_dashboard')
    else:
        form = MusicApplicationAdminForm(instance=application)

    context = {
        'application': application,
        'form': form,
    }

    return render(request, 'main/admin_application_detail.html', context)