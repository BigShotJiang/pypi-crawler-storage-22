# demekz/management/commands/install_demekz.py
import os
import pkg_resources
import sys
import shutil
from pathlib import Path
from django.core.management.base import BaseCommand
from django.core.management import execute_from_command_line


class Command(BaseCommand):
    help = 'Установка компонентов demekz в текущий Django проект'

    def add_arguments(self, parser):
        parser.add_argument(
            '--force',
            action='store_true',
            help='Принудительная перезапись существующих файлов',
        )
        parser.add_argument(
            '--no-settings',
            action='store_true',
            help='Не обновлять settings.py',
        )

    def handle(self, *args, **options):
        # Проверяем, что это Django проект
        if not (Path.cwd() / 'manage.py').exists():
            self.stdout.write(self.style.ERROR('❌ Это не Django проект!'))
            self.stdout.write('Создайте Django проект сначала: django-admin startproject myproject')
            self.stdout.write('Затем выполните: python manage.py install_demekz --force')
            return

        self.force = options['force']
        self.no_settings = options['no_settings']

        self.stdout.write(self.style.SUCCESS('🚀 Начинаю установку demekz...'))
        self.stdout.write('=' * 60)

        # Определяем путь к установленному пакету
        package_path = self.get_package_path()
        if not package_path:
            return

        project_path = Path.cwd()

        # 1. Установка приложения main
        self.install_main_app(package_path, project_path)

        # 2. Установка конфигурации
        self.install_config(package_path, project_path)

        # 3. Обновление настроек
        if not self.no_settings:
            self.update_settings(project_path)

        # 4. Копирование статических и медиа файлов
        self.install_static_media(package_path, project_path)

        self.stdout.write('=' * 60)
        self.stdout.write(self.style.SUCCESS('✅ Установка demekz завершена!'))
        self.print_next_steps()

    def get_package_path(self):
        """Получает путь к установленному пакету demekz"""
        try:
            # Пробуем несколько способов найти пакет
            try:
                # Способ 1: через importlib
                import demekz
                package_path = Path(demekz.__file__).parent
            except ImportError:
                # Способ 2: через pkg_resources
                package_path = Path(pkg_resources.resource_filename('demekz', ''))

            if package_path.exists():
                self.stdout.write(f"   📍 Пакет найден: {package_path}")
                return package_path
            else:
                self.stdout.write(self.style.ERROR('❌ Пакет demekz найден, но путь не существует'))
                return None

        except Exception as e:
            self.stdout.write(self.style.ERROR(f'❌ Ошибка поиска пакета: {e}'))
            self.stdout.write('Установите его через: pip install demekz')
            return None

    def install_main_app(self, package_path, project_path):
        """Устанавливает приложение main"""
        self.stdout.write('📦 Устанавливаю приложение main...')

        src_main = package_path / 'main'
        dst_main = project_path / 'main'

        if dst_main.exists() and not self.force:
            self.stdout.write(self.style.WARNING(f'⚠️  Папка {dst_main} уже существует'))
            self.stdout.write('   Используйте --force для перезаписи')
            return

        try:
            if dst_main.exists():
                shutil.rmtree(dst_main)

            shutil.copytree(src_main, dst_main)
            self.stdout.write(self.style.SUCCESS(f'   ✅ main установлен в {dst_main}'))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'   ❌ Ошибка: {e}'))

    def install_config(self, package_path, project_path):
        """Устанавливает конфигурационные файлы"""
        self.stdout.write('⚙️  Устанавливаю конфигурацию...')

        src_config = package_path / 'config'
        dst_config = project_path / 'config'

        # Если config уже существует, копируем только недостающие файлы
        if dst_config.exists() and not self.force:
            self.stdout.write(self.style.WARNING('⚠️  Папка config уже существует'))
            # Копируем только urls.py если нужно
            self.copy_single_file(src_config, dst_config, 'urls.py')
        else:
            try:
                if dst_config.exists():
                    shutil.rmtree(dst_config)

                shutil.copytree(src_config, dst_config)
                self.stdout.write(self.style.SUCCESS(f'   ✅ config установлен в {dst_config}'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'   ❌ Ошибка: {e}'))

    def copy_single_file(self, src_dir, dst_dir, filename):
        """Копирует один файл если он отсутствует"""
        src_file = src_dir / filename
        dst_file = dst_dir / filename

        if src_file.exists() and not dst_file.exists():
            shutil.copy2(src_file, dst_file)
            self.stdout.write(self.style.SUCCESS(f'   ✅ {filename} скопирован'))

    def install_static_media(self, package_path, project_path):
        """Копирует статические, медиа файлы и шаблоны"""
        self.stdout.write('📁 Копирую статические файлы и шаблоны...')

        # Копируем шаблоны
        src_templates = package_path / 'templates'
        dst_templates = project_path / 'templates'

        if src_templates.exists():
            if not dst_templates.exists():
                dst_templates.mkdir()

            # Копируем все файлы и папки из templates
            for item in src_templates.iterdir():
                dst_item = dst_templates / item.name
                if item.is_dir():
                    shutil.copytree(item, dst_item, dirs_exist_ok=True)
                else:
                    shutil.copy2(item, dst_item)
            self.stdout.write(self.style.SUCCESS('   ✅ Шаблоны скопированы'))

        # Создаём необходимые директории для static и media
        for folder in ['static', 'media']:
            dst_folder = project_path / folder
            src_folder = package_path / folder

            if not dst_folder.exists():
                dst_folder.mkdir()
                self.stdout.write(self.style.SUCCESS(f'   ✅ Создана папка {folder}'))

            if src_folder.exists():
                # Копируем содержимое если есть
                for item in src_folder.iterdir():
                    dst_item = dst_folder / item.name
                    if item.is_dir():
                        if not dst_item.exists():
                            shutil.copytree(item, dst_item)
                    else:
                        shutil.copy2(item, dst_item)

    def update_settings(self, project_path):
        """Обновляет settings.py"""
        self.stdout.write('🔧 Обновляю настройки...')

        settings_file = project_path / 'config' / 'settings.py'

        if not settings_file.exists():
            self.stdout.write(self.style.WARNING('⚠️  settings.py не найден'))
            return

        try:
            with open(settings_file, 'r', encoding='utf-8') as f:
                content = f.read()

            # Проверяем, не добавлено ли уже приложение
            if "'main'" in content or '"main"' in content:
                self.stdout.write(self.style.WARNING('   Приложение main уже добавлено'))
                return

            # Ищем INSTALLED_APPS и добавляем наше приложение
            if 'INSTALLED_APPS' in content:
                # Добавляем в конец списка INSTALLED_APPS
                lines = content.split('\n')
                for i, line in enumerate(lines):
                    if 'INSTALLED_APPS' in line and '=' in line:
                        # Ищем закрывающую скобку списка
                        for j in range(i, len(lines)):
                            if ']' in lines[j]:
                                lines.insert(j, "    'main',")
                                break
                        break

                content = '\n'.join(lines)

                # Добавляем настройки медиа
                media_settings = """
# Настройки медиа-файлов
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Настройки статических файлов
STATICFILES_DIRS = [BASE_DIR / 'static']
"""
                content += media_settings

                with open(settings_file, 'w', encoding='utf-8') as f:
                    f.write(content)

                self.stdout.write(self.style.SUCCESS('   ✅ settings.py обновлен'))

        except Exception as e:
            self.stdout.write(self.style.ERROR(f'   ❌ Ошибка обновления settings.py: {e}'))

    def print_next_steps(self):
        """Выводит дальнейшие шаги"""
        self.stdout.write('\n📋 Для завершения установки выполните:')
        self.stdout.write('1. Добавьте в config/urls.py:')
        self.stdout.write('   from django.conf import settings')
        self.stdout.write('   from django.conf.urls.static import static')
        self.stdout.write('   urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)')
        self.stdout.write('')
        self.stdout.write('2. Выполните миграции:')
        self.stdout.write('   python manage.py migrate')
        self.stdout.write('')
        self.stdout.write('3. Создайте суперпользователя:')
        self.stdout.write('   python manage.py createsuperuser')
        self.stdout.write('')
        self.stdout.write('4. Запустите сервер:')
        self.stdout.write('   python manage.py runserver')


def run_from_cli():
    """Функция для запуска из командной строки"""
    # Создаем аргументы для Django manage.py
    sys.argv = ['manage.py', 'install_demekz']  # Изменил с startproject на install_demekz

    # Если переданы аргументы из консоли
    if len(sys.argv) > 1:
        sys.argv.extend(sys.argv[1:])

    # Запускаем Django команду
    execute_from_command_line(sys.argv)