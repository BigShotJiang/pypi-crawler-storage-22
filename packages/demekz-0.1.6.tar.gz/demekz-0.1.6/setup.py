from setuptools import setup, find_packages
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="demekz",
    version="0.1.6",
    author="Anonymous",
    author_email="msdeath124@mail.com",
    description="Django Music Application System",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://pypi.org/project/demekz/",

    packages=find_packages(),
    include_package_data=True,

    package_data={
        'demekz': [
            'templates/**/*',
            'static/**/*',
            'locale/**/*',
            'main/**/*',
            'config/**/*',
            'management/**/*',
        ],
    },

    classifiers=[
        "Development Status :: 3 - Alpha",
        "Framework :: Django",
        "Framework :: Django :: 4.2",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],

    python_requires=">=3.8",

    install_requires=[
        "Django>=4.2,<5.0",
        "Pillow>=10.0.0",
    ],

    # ДОБАВЬТЕ ЭТО
    scripts=['demekz/setup_project.py'],

    entry_points={
        'console_scripts': [
            'demekz-setup=demekz.setup_project:main',
        ],
    },

    zip_safe=False,
)