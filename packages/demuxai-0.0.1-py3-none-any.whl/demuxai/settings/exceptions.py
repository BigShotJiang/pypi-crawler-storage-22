class InvalidConfigurationError(Exception):
    pass
