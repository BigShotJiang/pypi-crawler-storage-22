from typing import Optional

from .apps import Apps, AsyncApps
from .revisions import Revisions, AsyncRevisions
from .snapshots import Snapshots, AsyncSnapshots
from .timelines import Timelines, AsyncTimelines
from .volumes import Volumes, AsyncVolumes
from .bridge import AsyncBridge
from .sandbox import (
    AsyncSandboxApi,
    SandboxApi,
)
from .console import AsyncConsoleClient
from .options import Options, get_internal_options

__all__ = ["DenoDeploy", "AsyncDenoDeploy", "Options"]


class DenoDeploy:
    def __init__(self, options: Optional[Options] = None):
        internal_options = get_internal_options(options)
        bridge = AsyncBridge()

        client = AsyncConsoleClient(internal_options)
        self.apps = Apps(client, bridge)
        self.revisions = Revisions(client, bridge)
        self.timelines = Timelines(client, bridge)
        self.sandbox = SandboxApi(client, bridge)
        self.snapshots = Snapshots(client, bridge)
        self.volumes = Volumes(client, bridge)


class AsyncDenoDeploy:
    def __init__(self, options: Optional[Options] = None):
        internal_options = get_internal_options(options)
        client = AsyncConsoleClient(internal_options)

        self.apps = AsyncApps(client)
        self.revisions = AsyncRevisions(client)
        self.timelines = AsyncTimelines(client)
        self.sandbox = AsyncSandboxApi(client)
        self.snapshots = AsyncSnapshots(client)
        self.volumes = AsyncVolumes(client)
