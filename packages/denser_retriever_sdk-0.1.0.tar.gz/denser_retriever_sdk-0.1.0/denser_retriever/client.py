import time
import requests
from typing import Optional, Any, Dict
from .types import (
    ApiResponse,
    PollOptions,
    APIError,
)

API_PATH = "/api/open/v1"

class DenserRetriever:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://retriever.denser.ai",
        timeout: int = 30,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/") + API_PATH
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(
            {"Content-Type": "application/json", "x-api-key": api_key}
        )

    def _handle_response(self, response) -> ApiResponse:
        """Common response handler for API requests"""
        # Try to parse JSON response
        try:
            res_data = response.json()
        except ValueError:
            # If non-JSON response and error status
            raise APIError(
                message=f"Request failed with status {response.status_code}",
                http_status=response.status_code,
            )

        if response.status_code != 200:
            raise APIError(
                message=res_data.get("message")
                or f"Request failed with status {response.status_code}",
                code=res_data.get("errorCode"),
                http_status=response.status_code,
                data=res_data.get("data"),
            )

        return res_data

    def _handle_request_error(self, error: requests.exceptions.RequestException):
        """Common error handler for request exceptions"""
        status = None
        message = str(error)
        code = None
        details = None

        if error.response is not None:
            status = error.response.status_code
            try:
                error_body = error.response.json()
                message = error_body.get("message") or message
                code = error_body.get("errorCode")
                details = error_body.get("data")
            except ValueError:
                pass

        raise APIError(message=message, code=code, http_status=status, data=details)

    def _post(
        self, endpoint: str, data: Optional[Dict[str, Any]] = None
    ) -> ApiResponse:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"

        if data is None:
            data = {}

        try:
            response = self.session.post(url, json=data, timeout=self.timeout)
            return self._handle_response(response)
        except requests.exceptions.RequestException as error:
            self._handle_request_error(error)

    def _get(
        self, endpoint: str, params: Optional[Dict[str, Any]] = None
    ) -> ApiResponse:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"

        if params is None:
            params = {}

        try:
            response = self.session.get(url, params=params, timeout=self.timeout)
            return self._handle_response(response)
        except requests.exceptions.RequestException as error:
            self._handle_request_error(error)

    def _poll_document_status(
        self, document_id: str, options: Optional[PollOptions] = None
    ) -> ApiResponse:
        options = options or {}
        interval_ms = options.get("intervalMs", 2000)
        timeout_ms = options.get("timeoutMs", 600000)

        start_time = time.time()
        timeout_sec = timeout_ms / 1000.0
        interval_sec = interval_ms / 1000.0

        while True:
            if (time.time() - start_time) > timeout_sec:
                raise Exception(
                    f"Polling timed out after {timeout_ms}ms for document {document_id}"
                )

            status_res = self.get_document_status(document_id)

            if not status_res.get("success"):
                raise Exception(f"Failed to check status: {status_res}")

            status = status_res["data"]["status"]

            if status == "processed":
                return status_res
            if status == "failed" or status == "timeout":
                raise Exception(
                    f"Document processing {status} for document {document_id}"
                )

            time.sleep(interval_sec)

    def get_usage(self) -> ApiResponse:
        return self._get("getUsage")

    def get_balance(self) -> ApiResponse:
        return self._get("getBalance")

    def create_knowledge_base(
        self, name: str, description: Optional[str] = None
    ) -> ApiResponse:
        data = {"name": name}
        if description is not None:
            data["description"] = description
        return self._post("createKnowledgeBase", data)

    def list_knowledge_bases(self) -> ApiResponse:
        return self._get("listKnowledgeBases")

    def update_knowledge_base(
        self,
        knowledge_base_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> ApiResponse:
        data = {"id": knowledge_base_id}
        if name is not None:
            data["name"] = name
        if description is not None:
            data["description"] = description
        return self._post("updateKnowledgeBase", data)

    def delete_knowledge_base(self, knowledge_base_id: str) -> ApiResponse:
        return self._post("deleteKnowledgeBase", {"knowledgeBaseId": knowledge_base_id})

    def presign_upload_url(
        self, knowledge_base_id: str, file_name: str, size: int
    ) -> ApiResponse:
        data = {
            "knowledgeBaseId": knowledge_base_id,
            "fileName": file_name,
            "size": size,
        }
        return self._post("presignUploadUrl", data)

    def import_file(self, file_id: str) -> ApiResponse:
        return self._post("importFile", {"fileId": file_id})

    def import_file_and_poll(
        self, file_id: str, options: Optional[PollOptions] = None
    ) -> ApiResponse:
        """
        Import file and poll status.
        Note: The file must be uploaded to S3 first using the Presigned URL.
        """
        # 1. Register File
        import_res = self.import_file(file_id)
        if not import_res.get("success"):
            raise Exception(f"Failed to start import: {import_res}")

        # 2. Poll
        statusRes = self._poll_document_status(import_res["data"]["id"], options)
        return {
            "success": statusRes.get("success"),
            "data": {
                **import_res.get("data", {}),
                "status": statusRes.get("data", {}).get("status"),
            },
        }

    def import_text_content(
        self, knowledge_base_id: str, title: str, content: str
    ) -> ApiResponse:
        data = {
            "knowledgeBaseId": knowledge_base_id,
            "title": title,
            "content": content,
        }
        return self._post("importTextContent", data)

    def import_text_content_and_poll(
        self,
        knowledge_base_id: str,
        title: str,
        content: str,
        options: Optional[PollOptions] = None,
    ) -> ApiResponse:
        import_res = self.import_text_content(knowledge_base_id, title, content)
        if not import_res.get("success"):
            raise Exception(f"Failed to start text import: {import_res}")

        # import_res["data"] is DocumentInfo, which has "id"
        doc_id = import_res["data"]["id"]
        status_res = self._poll_document_status(doc_id, options)

        return {
            "success": status_res.get("success"),
            "data": {
                **import_res.get("data", {}),
                "status": status_res.get("data", {}).get("status"),
            },
        }

    def list_documents(self, knowledge_base_id: str) -> ApiResponse:
        return self._get("listDocuments", {"knowledgeBaseId": knowledge_base_id})

    def delete_document(self, document_id: str) -> ApiResponse:
        return self._post("deleteDocument", {"documentId": document_id})

    def get_document_status(self, document_id: str) -> ApiResponse:
        return self._get("getDocumentStatus", {"documentId": document_id})

    def query(
        self,
        query: str,
        knowledge_base_ids: Optional[list[str]] = None,
        limit: Optional[int] = None,
    ) -> ApiResponse:
        data = {"query": query}
        if knowledge_base_ids is not None:
            data["knowledgeBaseIds"] = knowledge_base_ids
        if limit is not None:
            data["limit"] = limit
        return self._post("query", data)
