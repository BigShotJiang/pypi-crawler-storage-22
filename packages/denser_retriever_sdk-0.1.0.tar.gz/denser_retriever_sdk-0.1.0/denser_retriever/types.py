from typing import Any, List, Optional, TypedDict, Literal, Dict


class APIError(Exception):
    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        http_status: Optional[int] = None,
        data: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.code = code
        self.http_status = http_status
        self.data = data

    def __str__(self):
        code_str = f" (Code: {self.code})" if self.code else ""
        status_str = f" (Status: {self.http_status})" if self.http_status else ""
        return f"{self.args[0]}{code_str}{status_str}"


# Common Response Wrapper
class ApiResponse(TypedDict):
    success: bool
    data: Any


# Poll Options
class PollOptions(TypedDict, total=False):
    intervalMs: int
    timeoutMs: int


# 1. Get Usage
class UsageData(TypedDict):
    knowledgeBaseCount: int
    storageUsed: int


# 2. Get Balance
class BalanceData(TypedDict):
    balance: float


# Common Knowledge Base Fields
class KnowledgeBase(TypedDict):
    id: str
    name: str
    description: Optional[str]
    createdAt: str
    updatedAt: str


# 7. Presign Upload URL
class PresignedUrlData(TypedDict):
    fileId: str
    uploadUrl: str
    expiresAt: int


# Document Common Fields
DocumentType = Literal["file", "webpage", "composed"]
DocumentStatus = Literal[
    "wait_for_upload", "pending", "processing", "processed", "failed", "timeout"
]


class DocumentInfo(TypedDict):
    id: str
    title: str
    type: DocumentType
    size: int
    status: DocumentStatus
    createdAt: str


class DocumentStatusData(TypedDict):
    id: str
    status: DocumentStatus


class QueryOptions(TypedDict, total=False):
    knowledgeBaseIds: Optional[List[str]]
    limit: Optional[int]


class QueryResultItem(TypedDict):
    id: str
    score: float
    document_id: str
    knowledge_base_id: str
    title: str
    type: str
    content: str
