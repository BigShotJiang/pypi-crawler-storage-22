"""
Setup script for backward compatibility.
Modern configuration is in pyproject.toml.
"""
from setuptools import setup

# All configuration is now in pyproject.toml
setup()
