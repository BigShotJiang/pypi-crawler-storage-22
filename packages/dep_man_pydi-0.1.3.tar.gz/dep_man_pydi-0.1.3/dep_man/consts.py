"""Module consts."""

DEFAULT_DEPENDENCIES_FILE_NAME = "dependencies"
