"""Module core logic."""
