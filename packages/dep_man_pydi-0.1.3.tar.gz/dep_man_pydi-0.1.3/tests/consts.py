PACKAGES = ("tests.deps.core.foo", "tests.deps.core.bar")
FOO_SYNC_ARG_RESULT = "foo_sync_arg_result"
FOO_ASYNC_ARG_RESULT = "foo_async_arg_result"
BAR_SYNC_ARG_RESULT = "bar_sync_arg_result"
BAR_EXPORT_RESULT = "bar_export_result"
FOO_USE_CASE_RESULT = "foo_use_case_result"
BAR_USE_CASE_RESULT = "bar_use_case_result"
