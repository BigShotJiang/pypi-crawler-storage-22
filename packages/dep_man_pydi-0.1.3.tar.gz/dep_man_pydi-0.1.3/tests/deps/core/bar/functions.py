from tests.consts import BAR_EXPORT_RESULT, BAR_SYNC_ARG_RESULT


def bar_sync_arg():
    return BAR_SYNC_ARG_RESULT


def bar_export():
    return BAR_EXPORT_RESULT
