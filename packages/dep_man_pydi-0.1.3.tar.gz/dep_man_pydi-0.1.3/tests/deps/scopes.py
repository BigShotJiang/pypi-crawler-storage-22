from enum import Enum


class Scopes(Enum):
    BAR = "bar"
    FOO = "foo"
    INTEGRATIONS = "integrations"
