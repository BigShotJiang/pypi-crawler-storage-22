# DerivaModel

The DerivaModel class provides schema introspection and manipulation capabilities
for Deriva catalogs. It handles table relationships, associations, and catalog
structure management.

::: deriva_ml.model
    handler: python
