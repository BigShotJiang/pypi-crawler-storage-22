# Exceptions

DerivaML defines custom exceptions to provide clear error messages for common
error conditions when working with catalogs, datasets, and executions.

::: deriva_ml.core.exceptions
    handler: python
