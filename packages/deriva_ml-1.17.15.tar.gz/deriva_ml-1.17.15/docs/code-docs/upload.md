# Upload Utilities

Utilities for uploading files and assets to a Deriva catalog's Hatrac object store.

::: deriva_ml.dataset.upload
    handler: python
