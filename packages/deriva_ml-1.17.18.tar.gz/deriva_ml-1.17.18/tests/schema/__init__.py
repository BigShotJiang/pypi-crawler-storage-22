"""Schema validation tests."""
