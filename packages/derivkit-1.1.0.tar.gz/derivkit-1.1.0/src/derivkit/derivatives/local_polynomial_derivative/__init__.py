"""Local polynomial derivative init."""
