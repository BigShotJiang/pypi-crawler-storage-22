"""Local polynomial fitting with outlier trimming."""

from __future__ import annotations

import numpy as np

from derivkit.derivatives.local_polynomial_derivative.local_poly_config import (
    LocalPolyConfig,
)

__all__ = [
    "design_matrix",
    "trimmed_polyfit",
    "centered_polyfit_least_squares",
]


def design_matrix(
        x0: float,
        config: LocalPolyConfig,
        sample_points: np.ndarray,
        degree: int) -> np.ndarray:
    """Builds a Vandermonde design matrix.

    This method constructs the Vandermonde matrix for polynomial fitting based
    on whether centering around x0 is specified in the config.

    Args:
        x0:
            The center point for polynomial fitting.
        config:
            LocalPolyConfig instance with fitting settings.
        sample_points:
            An array of sample points (shape ``(n_samples,)``).
        degree:
            The degree of the polynomial to fit.

    Returns:
        A Vandermonde matrix (shape ``(n_samples, degree + 1)``).
    """
    if config.center:
        z = sample_points - x0
    else:
        z = sample_points
    return np.vander(z, N=degree + 1, increasing=True)


def trimmed_polyfit(
    x0: float,
    config: LocalPolyConfig,
    xs: np.ndarray,
    ys: np.ndarray,
    degree: int,
) -> tuple[np.ndarray, np.ndarray, bool]:
    """Returns a polynomial fit with trimmed outliers.

    This method fits a polynomial of the specified degree to the provided samples
    and iteratively removes sample points whose residuals exceed the configured
    tolerances. Trimming continues until either all residuals are within tolerance
    or the maximum number of trims is reached. If trimming can no longer proceed
    without violating the minimum sample requirement, the last valid fit is
    returned.

    Args:
        x0:
            The center point for polynomial fitting.
        config:
            LocalPolyConfig instance with fitting settings.
        xs:
            An array of sample points (shape ``(n_samples,)``).
        ys:
            An array of function evaluations (shape
            ``(n_samples, n_components)``).
        degree:
            The degree of the polynomial to fit.

    Returns:
        coeffs:
            The fitted polynomial coefficients. Each column corresponds to
            one output component of ``ys``, and row ``k`` contains the
            coefficient of the ``x^k`` term (or ``(x−x0)^k`` if centering is
            enabled).
        used_mask:
            A boolean array indicating which sample points were kept after
            trimming. ``True`` means the point was used in the final fit.
        ok:
            ``True`` if, after trimming, all remaining sample points satisfied
            the residual tolerances defined in ``config``. ``False`` means the
            loop stopped due to hitting trimming limits or minimum-sample
            constraints.
    """
    n_samples, n_comp = ys.shape
    keep = np.ones(n_samples, dtype=bool)
    n_trim = 0

    last_coeffs = None
    last_keep = keep.copy()
    last_ok = False

    needed = max(config.min_samples, degree + 1)

    while keep.sum() >= needed and n_trim <= config.max_trim:
        idx = np.where(keep)[0]
        x_use = xs[idx]
        y_use = ys[idx]

        mat = design_matrix(x0, config, x_use, degree)
        coeffs, *_ = np.linalg.lstsq(mat, y_use, rcond=None)

        y_fit = mat @ coeffs
        denom = np.maximum(np.abs(y_use), config.tol_abs)
        err = np.abs(y_fit - y_use) / denom

        bad_rows = (err > config.tol_rel).any(axis=1)
        if not bad_rows.any():
            last_coeffs = coeffs
            last_keep = keep.copy()
            last_ok = True
            break

        bad_idx_all = idx[bad_rows]
        leftmost, rightmost = idx[0], idx[-1]
        trimmed = False

        # shave edges only if we keep enough for this degree
        if bad_idx_all[0] == leftmost and keep.sum() - 1 >= needed:
            keep[leftmost] = False
            trimmed = True
        if bad_idx_all[-1] == rightmost and keep.sum() - 1 >= needed:
            keep[rightmost] = False
            trimmed = True

        if not trimmed:
            last_coeffs = coeffs
            last_keep = keep.copy()
            last_ok = False
            break

        last_coeffs = coeffs
        last_keep = keep.copy()
        last_ok = False
        n_trim += 1

    if last_coeffs is None:
        last_coeffs = np.zeros((degree + 1, n_comp), dtype=float)
        last_keep = keep.copy()
        last_ok = False

    return last_coeffs, last_keep, last_ok


def centered_polyfit_least_squares(
    x0: float,
    xs: np.ndarray,
    ys: np.ndarray,
    degree: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Calculates a plain least-squares polynomial fit in powers of (x - x0).

    Args:
        x0: Expansion point.
        xs: Sample locations (1D array-like).
        ys: Sample values (shape ``(n_samples,)`` or ``(n_samples, n_comp)``).
        degree: Polynomial degree.

    Returns:
        A tuple containing

            - An array of shape ``(degree+1, n_comp)`` with coefficients for
              :math:`sum_k a_k (x - x0)^k`.
            - A boolean mask of length ``n_samples`` (all ``True`` here).
            - An array of shape ``(degree+1, n)``.
    """
    xs = np.asarray(xs, dtype=float)
    ys = np.asarray(ys)

    if ys.ndim == 1:
        ys = ys[:, None]

    t = xs - x0
    vander = np.vander(t, N=degree + 1, increasing=True)  # (n_samples, degree+1)

    coeffs, *_ = np.linalg.lstsq(vander, ys, rcond=None)
    used_mask = np.ones(xs.shape[0], dtype=bool)

    y_fit = vander @ coeffs
    residuals = y_fit - ys  # (n_samples, n_comp)
    n_samples = vander.shape[0]
    n_params = degree + 1
    dof = max(n_samples - n_params, 1)

    sigma2 = np.sum(residuals ** 2, axis=0) / dof  # shape (n_comp,)

    xtx_inv = np.linalg.inv(vander.T @ vander)  # (p, p)
    diag_xtx_inv = np.diag(xtx_inv)[:, None]  # (p, 1)

    coeff_std = np.sqrt(diag_xtx_inv * sigma2[None, :])

    return coeffs, used_mask, coeff_std
