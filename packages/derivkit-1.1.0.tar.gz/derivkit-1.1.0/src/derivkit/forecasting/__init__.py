"""Forecasting utilities."""
