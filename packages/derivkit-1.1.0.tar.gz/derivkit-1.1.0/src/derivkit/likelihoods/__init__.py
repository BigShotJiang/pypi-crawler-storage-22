"""Likelihood utilities."""
