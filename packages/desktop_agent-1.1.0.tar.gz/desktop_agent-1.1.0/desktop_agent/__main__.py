"""Entry point for running desktop-agent as a module.

Usage: python -m desktop_agent <command>
"""
from desktop_agent import app

if __name__ == "__main__":
    app()
