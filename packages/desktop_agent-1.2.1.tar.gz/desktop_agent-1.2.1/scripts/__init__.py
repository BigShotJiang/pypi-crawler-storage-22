"""Scripts package for desktop-skill."""
