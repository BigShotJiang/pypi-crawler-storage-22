"""Commands package for desktop-skill CLI."""
