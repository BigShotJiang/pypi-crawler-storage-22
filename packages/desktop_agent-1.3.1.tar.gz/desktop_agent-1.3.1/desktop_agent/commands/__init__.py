"""Commands package for desktop-agent CLI."""
