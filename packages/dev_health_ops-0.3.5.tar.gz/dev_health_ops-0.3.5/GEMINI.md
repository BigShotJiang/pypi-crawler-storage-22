Read AGENTS.md for context.
