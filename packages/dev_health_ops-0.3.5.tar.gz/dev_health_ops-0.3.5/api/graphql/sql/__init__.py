"""SQL layer for GraphQL analytics."""
