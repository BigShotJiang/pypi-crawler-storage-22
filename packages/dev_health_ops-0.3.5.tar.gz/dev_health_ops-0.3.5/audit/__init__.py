"""Audit helpers for data completeness and quality checks."""
