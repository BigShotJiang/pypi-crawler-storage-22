"""Daily metrics computation and sink writers."""

