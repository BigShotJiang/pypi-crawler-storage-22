"""GitHub provider adapter (issues + Projects v2) -> WorkItem normalization."""

