"""Jira provider adapter (issues, changelog, sprints) -> WorkItem normalization."""

