"""Investment materialization pipeline for work graph outputs."""
