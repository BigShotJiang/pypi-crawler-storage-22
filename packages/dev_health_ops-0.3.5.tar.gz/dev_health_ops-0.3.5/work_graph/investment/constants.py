"""Shared constants for investment materialization and validation."""

MIN_EVIDENCE_CHARS = 300

