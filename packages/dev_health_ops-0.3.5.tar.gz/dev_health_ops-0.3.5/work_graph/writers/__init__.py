"""Work graph writers.

This package is intentionally empty.

Rule:
- Do not add bespoke backend writers here.
- Persist derived work graph rows via `metrics/sinks/*` by extending the canonical sink contract.
"""
