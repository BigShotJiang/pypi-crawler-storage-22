Read AGENTS.md for context.

Run all tests and resolve issues before finalizing any commit or PR.
