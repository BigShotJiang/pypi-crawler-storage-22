# Legacy and deprecated docs

These documents are kept for historical context and may be out of date.

- GraphQL migration notes: `graphql-migration.md`
- GraphQL subscriptions notes: `graphql-subscriptions.md`
- Performance notes: `perf_notes.md`
- Integrations index (old): `integrations/index.md`
