# Code Hotspots

## What it answers
- Where is churn concentrated?
- Which areas are persistent risk multipliers?

## Typical visualizations
- Heatmap (time × component)
- Treemap/sunburst (repo → path → file)

## Backing computations
- churn aggregation
- hotspot ranking (persistence + magnitude)
