# Flame diagrams

Flame diagrams explain a single selected point by decomposing contributions (repo/path/file/etc.).

UX rule:
- “Explore” must render the flame chart (not only navigate).
