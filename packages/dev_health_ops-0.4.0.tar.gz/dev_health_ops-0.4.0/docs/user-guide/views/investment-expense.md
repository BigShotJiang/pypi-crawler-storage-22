# Investment Expense (Stacked Area)

## What it answers
- How does theme composition drift over time?
- Are changes spiky (incidents) or gradual (structural)?

## Backing surfaces
- GraphQL `analytics.timeseries`
- SQL compiler `compile_timeseries`
