# Quadrants

Quadrants classify system state using raw values only.

Required quadrant pairs:
- Churn × Throughput
- Cycle Time × Throughput
- WIP × Throughput
- Review Load × Review Latency

Guardrails:
- No scoring
- No rankings
