"""Analytics utilities and metric computation."""
