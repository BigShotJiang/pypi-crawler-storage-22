"""GitLab provider adapter (projects + issues) -> WorkItem normalization."""
