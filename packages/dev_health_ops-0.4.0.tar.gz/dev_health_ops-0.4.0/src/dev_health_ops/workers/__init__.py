"""Celery worker package for background job processing."""
