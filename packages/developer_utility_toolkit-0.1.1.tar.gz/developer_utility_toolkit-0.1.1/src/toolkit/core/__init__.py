"""Core toolkit components."""
