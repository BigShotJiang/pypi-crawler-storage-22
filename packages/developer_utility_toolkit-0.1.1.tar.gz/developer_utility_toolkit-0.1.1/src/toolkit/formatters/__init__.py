"""Formatting and validation tools."""
