"""Command history utilities."""
