"""Image utility tools."""
