# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.2] - 2026-02-02

### Added
- MANIFEST.in file for proper package distribution control

### Changed
- Removed internal/ directory from version control for security
- Updated .gitignore to exclude entire internal/ directory
- Prepared for public release via git archive

### Security
- Internal development files with lab IPs no longer tracked by git
- Lab device credentials and sensitive data properly excluded from repository

### Notes
- This version is ready for publication to GitHub and PyPI
- Use git archive for safe export to public repository
- All sensitive data confined to local development environment

## [0.2.1] - 2026-02-02

### Changed
- Updated development status from Pre-Alpha to Alpha
- Version bump for stability improvements and wider testing readiness

### Status
- **Development Status**: Alpha (ready for early adopters and testing)
- All 353 tests passing (100%)
- 93% code coverage maintained
- Production-ready codebase with comprehensive test coverage

### Notes
- API is mostly stable but may still have minor changes before 1.0.0
- Feedback and bug reports welcome from early adopters
- Suitable for testing and evaluation, not yet recommended for critical production use

## [0.2.0] - 2026-01-30

### Changed
- **Modular architecture**: Refactored monolithic patterns.py into modular structure
  - Each device type now has its own file under `device_types/`
  - Organized by vendor (cisco/, aruba/, hp/, juniper/)
  - Auto-discovery registry system
- **Better code organization**: 18 new files created with clear separation of concerns
- **Improved maintainability**: Smaller, focused files instead of 700+ line monolith

### Added
- Pattern validation utilities in `device_types/base.py`
- Comprehensive refactoring guide in `REFACTORING_v0.2.0.md`
- Individual pattern files for all 10 device types

### Technical
- 100% backward compatible (no API changes)
- All 353 tests passing
- Zero breaking changes to existing code
- Easy to add new device types (just create a new file)

## [0.1.9] - 2026-01-30

### Added
- **Multi-framework driver mappings**: DetectionResult now includes driver names for multiple automation frameworks
  - `scrapli_driver`: Scrapli driver name (e.g., 'cisco_iosxe')
  - `napalm_driver`: NAPALM driver name (e.g., 'ios')
  - `nornir_platform`: Nornir platform name (e.g., 'ios')
- CLI `--show-driver` flag to display driver mappings
  - Supports: all, netmiko, ansible, scrapli, napalm, nornir
- CLI `--driver-only` mode for automation-friendly output
- 34 comprehensive unit tests for driver mapping functionality
- Support for 10 device types with complete driver mappings:
  - Cisco IOS, IOS-XE, NX-OS, IOS-XR, WLC
  - Aruba ProCurve, AOS-CX
  - HP ProCurve, Comware
  - Juniper Junos

### Changed
- Updated all DEVICE_PATTERNS with framework-specific driver information
- JSON output now automatically includes all driver fields
- Enhanced DetectionResult model with driver fields

### Technical
- 353 unit tests passing (100%)
- 92% code coverage maintained
- Comprehensive test coverage for driver mappings

## [0.1.8] - 2026-01-XX

### Added
- Multi-host concurrent detection via CLI
- `--host` flag can be specified multiple times
- `--hosts-file` for batch processing from file
- `--inventory` for YAML/JSON inventory files
- `--max-workers` to control concurrency
- Progress callbacks for multi-host operations
- Summary statistics for batch operations

### Changed
- Enhanced CLI with multi-host capabilities
- Improved error handling for batch operations

## [0.1.7] - 2026-01-XX

### Added
- Offline detection capabilities
- `detect_offline()` static method
- Data collection mode (`--collect`)
- Support for pre-collected device data analysis

### Changed
- Enhanced data collection with metadata
- Improved offline detection accuracy

## [0.1.6] - 2026-01-XX

### Added
- Fallback detection mode
- Enhanced pattern matching
- Improved error handling

## [0.1.5] - 2026-01-XX

### Added
- SSH version detection
- Banner-based vendor hints
- Priority-based pattern matching

## [0.1.0] - 2026-01-XX

### Added
- Initial release
- Basic device detection via SSH
- Support for Cisco, Aruba, HP, Juniper devices
- CLI interface
- Python API
- Netmiko and Ansible network_os mappings

---

## Version Numbering

- **0.1.x**: Initial development releases
- **0.2.x**: Planned - SNMP support
- **1.0.0**: Planned - Stable API release

## Links

- [PyPI](https://pypi.org/project/device-detect/)
- [GitHub](https://github.com/mdrbh/device-detect)
- [Documentation](https://github.com/mdrbh/device-detect/wiki)
- [Issues](https://github.com/mdrbh/device-detect/issues)
