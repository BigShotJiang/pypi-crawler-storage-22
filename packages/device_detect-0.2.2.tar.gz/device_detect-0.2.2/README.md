# device-detect

Simple network device auto-detection library using SSH protocol. Auto-identifies device types and vendors for network automation frameworks (Netmiko, NAPALM, Scrapli, Ansible). Features progressive discovery, vendor intelligence, offline detection, and data collection. Based on netmiko's detection logic.

## Features

- **SSH-based Detection**: Auto-detect device type and vendor via SSH
- **Offline Detection**: Analyze pre-collected device data without live connections
- **Data Collection**: Collect device data for offline analysis and machine learning
- **Multi-vendor Support**: Cisco, Aruba, HP, Juniper, and more
- **Pattern Filtering**: Filter by vendor, device_type, or ansible_network_os
- **Banner Analysis**: Optional SSH banner detection for faster filtering
- **High Accuracy**: 95%+ confidence scoring
- **Context Manager**: Automatic connection management
- **Thread-safe**: Safe for concurrent frameworks

## Installation

```bash
pip install device-detect
```

## Quick Start

### Basic Detection

```python
from device_detect import DeviceDetector

# Auto-detect device type
with DeviceDetector(host='192.168.1.1', username='admin', password='password') as detector:
    result = detector.ssh_detect()
    
    print(f"Device Type: {result.device_type}")      # cisco_ios
    print(f"Vendor: {result.vendor}")                # cisco
    print(f"Confidence: {result.confidence}")        # 0.95
    print(f"Ansible OS: {result.ansible_network_os}") # cisco.ios.ios
```

### Data Collection & Offline Detection

```python
from device_detect import DeviceDetector

# Step 1: Collect data from device
with DeviceDetector(host='192.168.1.1', username='admin', password='password') as detector:
    data = detector.collect_data(vendor='cisco', device_type='cisco_ios')
    
    # Save for later analysis
    import json
    with open('device_data.json', 'w') as f:
        json.dump(data, f, indent=2)

# Step 2: Offline detection (no device connection needed)
with open('device_data.json', 'r') as f:
    collected_data = json.load(f)

result = DeviceDetector.detect_offline(collected_data)
print(f"Detected: {result.device_type} (confidence: {result.confidence})")
```

### Concurrent Detection (NEW in v0.1.8)

Detect multiple devices in parallel for faster batch operations:

```python
from device_detect import detect_multiple, load_hosts_file, create_summary

# Detect multiple devices concurrently
hosts = ['192.168.1.1', '192.168.1.2', '192.168.1.3']
results = detect_multiple(
    hosts=hosts,
    username='admin',
    password='password',
    max_workers=10,  # Concurrent connections
    vendors='cisco'  # Optional filter
)

# Process results
for host, result in results.items():
    if result.success:
        print(f"{host}: {result.device_type}")
    else:
        print(f"{host}: Failed - {result.error}")

# Generate summary
summary = create_summary(results)
print(f"Success rate: {summary['success_rate']}")
print(f"Successful: {summary['successful']}/{summary['total_devices']}")
```

**Load from inventory file:**

```python
from device_detect import load_inventory, detect_multiple

# Load devices from YAML or JSON inventory
devices = load_inventory('inventory.yaml')
hosts = [d['host'] for d in devices]

results = detect_multiple(
    hosts=hosts,
    username='admin',
    password='password',
    max_workers=10
)
```

**Performance:**
- 2 devices: ~2x faster (8-10s vs 16-20s)
- 10 devices: ~8x faster (10-15s vs 80-100s)
- 50 devices: ~40x faster (20-30s vs 400-500s)

### Filtered Detection

```python
# Detect only Cisco devices (faster)
result = detector.ssh_detect(vendors='cisco')

# Detect specific device types
result = detector.ssh_detect(device_types=['cisco_ios', 'cisco_nxos'])

# Disable SSH version detection (faster)
result = detector.ssh_detect(use_ssh_version=False)
```

### Filter Logic: AND vs OR (NEW in v0.1.6)

The library supports two filtering modes for pattern matching:

**AND Logic (Default)** - Patterns must match ALL active constraints:
```python
# Default: AND logic (most precise)
detector = DeviceDetector(host='192.168.1.1', username='admin', password='password')
result = detector.ssh_detect(vendors='cisco')
# Tests ONLY Cisco devices that ALSO match SSH version detection
# Typical result: 2-3 patterns tested (very fast, precise)
```

**OR Logic** - Patterns match ANY constraint (legacy behavior):
```python
# Explicit OR logic (broader search)
detector = DeviceDetector(
    host='192.168.1.1',
    username='admin',
    password='password',
    filter_logic='or'  # Use OR logic
)
result = detector.ssh_detect(vendors='cisco')
# Tests ALL Cisco devices regardless of SSH version
# Typical result: 5+ patterns tested (slower, comprehensive)
```

**Two-Phase Fallback** - Progressive relaxation for thorough detection:
```python
# Three-phase detection: AND → OR → ALL
detector = DeviceDetector(host='192.168.1.1', username='admin', password='password')
result = detector.ssh_detect(vendors='cisco', fallback=True)
# Phase 1: Tests patterns matching ALL constraints (AND)
# Phase 2: Tests remaining patterns matching ANY constraint (OR)
# Phase 3: Tests all remaining patterns (comprehensive)
```

**Performance Comparison:**
- **AND Logic**: 10-30% faster (fewer patterns tested)
- **OR Logic**: More comprehensive (tests more patterns)
- **Recommendation**: Use AND (default) for speed and precision

**Migration from v0.1.5:**
```python
# No changes needed - AND logic works automatically
# To restore legacy behavior, add filter_logic='or':
detector = DeviceDetector(..., filter_logic='or')
```

## Command-Line Interface (CLI)

### Installation

The `device-detect` CLI tool is automatically installed with the package:

```bash
pip install device-detect
```

After installation, the `device-detect` command will be available in your terminal.

### Basic Usage

The CLI provides an easy-to-use interface for device detection without writing Python code.

#### Interactive Mode (Recommended)

The CLI will prompt for credentials if not provided:

```bash
# Only host required - prompts for username and password
device-detect --host 192.168.1.1
Username: admin
Password: ********  # Hidden input
✓ Device detected: cisco_ios
  Vendor: cisco
  Confidence: 95%
  Ansible: cisco.ios.ios
  SSH Version: SSH-2.0-Cisco-1.25
  Method: command
```

#### With Credentials

```bash
# Provide credentials directly
device-detect --host 192.168.1.1 --user admin --password secret

# Using environment variables (more secure)
export DEVICE_USERNAME=admin
export DEVICE_PASSWORD=secret
device-detect --host 192.168.1.1
```

### CLI Features

#### 1. Detection with Filters

```bash
# Filter by vendor (faster detection)
device-detect --host 192.168.1.1 --vendor cisco

# Filter by device type
device-detect --host 192.168.1.1 --device-type cisco_ios

# Use fallback mode for comprehensive detection
device-detect --host 192.168.1.1 --vendor cisco --fallback
```

#### 2. Output Formats

```bash
# Default text format
device-detect --host 192.168.1.1

# JSON format
device-detect --host 192.168.1.1 --format json

# Table format
device-detect --host 192.168.1.1 --format table
```

#### 3. Verification Mode

```bash
# Verify a specific device type
device-detect --host 192.168.1.1 --verify cisco_ios

# With table output
device-detect --host 192.168.1.1 --verify cisco_ios --format table
```

#### 4. Data Collection

```bash
# Collect device data for offline analysis
device-detect --host 192.168.1.1 --collect --output device_data.json
✓ Data collected and saved to device_data.json

# Collect without saving to file (prints JSON)
device-detect --host 192.168.1.1 --collect
```

#### 5. Offline Detection

```bash
# Detect using previously collected data (no device connection needed)
device-detect --offline device_data.json

# With filters and different format
device-detect --offline device_data.json --vendor cisco --format json
```

### CLI Options Reference

```
usage: device-detect [-h] [--host HOST] [--user USER] [--password PASSWORD] 
                     [--port PORT] [--timeout TIMEOUT] [--vendor VENDOR]
                     [--device-type DEVICE_TYPE] [--ansible-os ANSIBLE_OS]
                     [--fallback] [--no-ssh-version] [--no-banner]
                     [--filter-logic {and,or}] [--verify DEVICE_TYPE]
                     [--collect] [--offline DATA_FILE] [--output OUTPUT]
                     [--format {text,json,table}]
                     [--log-level {DEBUG,INFO,WARNING,ERROR}] [--version]

Required (except in offline mode):
  --host HOST              Device IP address or hostname

Credentials (optional - will prompt if not provided):
  --user USER              SSH username (or set DEVICE_USERNAME env var)
  --password PASSWORD      SSH password (or set DEVICE_PASSWORD env var)

Connection Options:
  --port PORT              SSH port (default: 22)
  --timeout TIMEOUT        SSH timeout in seconds (default: 60)

Detection Filters:
  --vendor VENDOR          Filter by vendor (cisco, aruba, hp, juniper)
  --device-type TYPE       Filter by device type (cisco_ios, aruba_procurve)
  --ansible-os OS          Filter by Ansible network OS
  --fallback               Enable fallback mode (tests more patterns)
  --no-ssh-version         Disable SSH version detection
  --no-banner              Disable banner analysis
  --filter-logic LOGIC     Pattern filter logic: and (default) or or

Operation Modes:
  --verify DEVICE_TYPE     Verify specific device type instead of detecting
  --collect                Collect device data for offline analysis
  --offline DATA_FILE      Perform offline detection using collected data

Output Options:
  --output FILE, -o FILE   Output file for collected data or results
  --format FORMAT          Output format: text (default), json, table
  --log-level LEVEL        Logging level: DEBUG, INFO, WARNING, ERROR

Other:
  --version                Show version and exit
  --help, -h               Show help message and exit
```

### Environment Variables

The CLI supports environment variables for secure credential management:

- `DEVICE_USERNAME` - SSH username
- `DEVICE_PASSWORD` - SSH password

```bash
# Set environment variables (Linux/macOS)
export DEVICE_USERNAME=admin
export DEVICE_PASSWORD=secret

# Set environment variables (Windows PowerShell)
$env:DEVICE_USERNAME="admin"
$env:DEVICE_PASSWORD="secret"

# Now use CLI without credential arguments
device-detect --host 192.168.1.1
```

### CLI Security Best Practices

✅ **DO: Use interactive mode for manual operations**
```bash
device-detect --host 192.168.1.1
Username: admin
Password: ********  # Secure, hidden input
```

✅ **DO: Use environment variables for scripts**
```bash
export DEVICE_USERNAME=admin
export DEVICE_PASSWORD=secret
device-detect --host 192.168.1.1
```

✅ **DO: Use password managers with CLI**
```bash
device-detect --host 192.168.1.1 --password $(pass show network/device)
```

❌ **DON'T: Hardcode passwords in scripts**
```bash
# Avoid this - password visible in command history
device-detect --host 192.168.1.1 --user admin --password hardcoded123
```

### CLI Examples

#### Example 1: Quick Detection
```bash
$ device-detect --host 192.168.1.1
Username: nornir
Password: ********
✓ Device detected: cisco_ios
  Vendor: cisco
  Confidence: 95%
  Ansible: cisco.ios.ios
  Method: command
```

#### Example 2: JSON Output for Automation
```bash
$ device-detect --host 192.168.1.1 --user nornir --password secret --format json
{
  "success": true,
  "device_type": "cisco_ios",
  "vendor": "cisco",
  "confidence": 0.95,
  "ansible_network_os": "cisco.ios.ios",
  "method": "command",
  "timestamp": "2025-12-19T13:37:27.207131"
}
```

#### Example 3: Data Collection Workflow
```bash
# Step 1: Collect data from device
$ device-detect --host 192.168.1.1 --collect --output cisco_device.json
✓ Data collected and saved to cisco_device.json

# Step 2: Offline detection (no device connection needed)
$ device-detect --offline cisco_device.json
✓ Device detected: cisco_ios
  Vendor: cisco
  Confidence: 95%
  Method: offline
```

#### Example 4: Multi-Host Concurrent Detection (NEW in v0.1.8)
```bash
# Multiple hosts with hosts file
device-detect --hosts-file hosts.txt --user admin --password secret
Host: 192.168.1.1
✓ Device detected: cisco_ios
  Vendor: cisco
  Confidence: 95%

Host: 192.168.1.3
✓ Device detected: aruba_procurve
  Vendor: aruba
  Confidence: 95%

Summary: 2/2 successful (100.0%)

# Multiple --host arguments
device-detect --host 192.168.1.1 --host 192.168.1.3 --collect --output-dir data/
✓ Collected data from 2 devices to data/

# With inventory file and JSON output
device-detect --inventory inventory.yaml --format json --output-mode aggregated -o results.json
✓ Aggregated results saved to results.json

Summary: 2/2 successful (100.0%)

# With progress bar (requires: pip install device-detect[progress])
device-detect --hosts-file hosts.txt --progress --max-workers 5
Progress: 100%|████████████| 2/2 [00:08<00:00,  4.2s/device]
```

#### Example 5: Sequential vs Concurrent Comparison
```bash
# Sequential (old way with shell loop - slow)
for ip in 192.168.1.1 192.168.1.2 192.168.1.3; do
    device-detect --host $ip --format json >> devices.json
done
# Takes ~45 seconds for 3 devices

# Concurrent (new way - fast!)
device-detect --host 192.168.1.1 --host 192.168.1.2 --host 192.168.1.3 \
  --format json --output-mode aggregated -o devices.json
# Takes ~10 seconds for 3 devices (~4.5x faster!)
```

#### Example 6: Debug Mode
```bash
# Enable debug logging for troubleshooting
device-detect --host 192.168.1.1 --log-level DEBUG
```

### CLI vs Python API

| Feature | CLI | Python API |
|---------|-----|------------|
| Ease of Use | ✅ Very easy | Requires Python code |
| Automation | ✅ Shell scripts | ✅ Python scripts |
| Flexibility | Good | ✅ Full control |
| Batch Processing | Shell loops | ✅ Python loops |
| Advanced Features | Basic | ✅ All features |
| Best For | Quick checks, ops | Integration, apps |

**Use the CLI for:**
- Quick device checks
- Manual operations
- Shell script automation
- Simple batch processing

**Use the Python API for:**
- Application integration
- Complex workflows
- Custom error handling
- Advanced pattern matching

## Supported Devices

- **Cisco**: IOS, NX-OS, IOS-XR, WLC
- **Aruba**: ProCurve, AOS-CX
- **HP**: Comware, ProCurve
- **Juniper**: Junos

## API Reference

### DeviceDetector

```python
DeviceDetector(
    host: str,
    username: str,
    password: str,
    port: int = 22,
    timeout: int = 30,
    use_ssh_version: bool = True,
    use_banner: bool = True,
    filter_logic: str = 'and'  # NEW in v0.1.6
)
```

**Parameters:**
- `host` - Device IP address or hostname
- `username` - SSH username
- `password` - SSH password
- `port` - SSH port (default: 22)
- `timeout` - Connection timeout in seconds (default: 30)
- `use_ssh_version` - Enable SSH version detection (default: True)
- `use_banner` - Enable banner analysis (default: True)
- `filter_logic` - Pattern filtering mode: 'and' or 'or' (default: 'and')

**Methods:**
- `ssh_detect(**filters, filter_logic=None)` - Auto-detect device type
  - Optional filters: `vendors`, `device_types`, `ansible_network_os`, `fallback`, `use_ssh_version`, `use_banner`, `filter_logic`
- `ssh_verify(device_type)` - Verify specific device type
- `collect_data(vendor=None, device_type=None)` - Collect device data
- `detect_offline(collected_data, filter_logic='and')` - Offline detection (static method)
- `disconnect()` - Close SSH connection

### DetectionResult

```python
DetectionResult(
    success: bool,
    device_type: str,
    vendor: str,
    ansible_network_os: str,
    confidence: float,
    method: str,
    ssh_version: str = None,
    error_message: str = None,
    timestamp: str = None
)
```

**Methods:**
- `to_dict()` - Convert to dictionary
- `to_json(indent=2)` - Convert to JSON string

## Testing

The project has comprehensive test coverage with 353 passing tests and 90% code coverage.

**Quick Test Commands:**
```bash
# Run all unit tests (fast, <3s)
pytest tests/unit/ -v

# Run with coverage
pytest tests/ --cov=device_detect --cov-report=html
```

**Test Suite:**
- 353 tests total (unit, integration, security, performance, e2e)
- 90% code coverage
- 77.78% mutation score (very good)
- All tests passing

For detailed testing information including test structure, markers, fixtures, and contribution guidelines, see [TESTING.md](TESTING.md).

## Examples

See the `examples/` directory for more:

- `basic_detection.py` - Basic usage examples
- `cisco_detection.py` - Cisco-specific examples
- `aruba_detection.py` - Aruba-specific examples
- `offline_detection_example.py` - Offline detection workflow
- `data_collection_example.py` - Data collection examples
- `ssh_version_example.py` - SSH version detection examples

## Performance

- **Cisco IOS**: ~7-9 seconds (optimized)
- **Aruba ProCurve**: ~11-13 seconds (optimized)
- **Vendor filtering**: ~30% faster (tests fewer patterns)
- **Offline detection**: <1 second (no SSH connection)

## Security

The `device-detect` library handles sensitive network credentials and SSH connections. Security is a top priority.

### Security Features

- ✅ **Credential Protection**: Passwords/secrets never exposed in logs, errors, or `__repr__()`
- ✅ **Input Validation**: Protection against command injection, XSS, and path traversal
- ✅ **SSH Security**: Encrypted connections with host key verification
- ✅ **Connection Isolation**: No shared state between detector instances

### Best Practices

```python
# ✅ DO: Use environment variables for credentials
import os
detector = DeviceDetector(
    host='192.168.1.1',
    username=os.environ['DEVICE_USER'],
    password=os.environ['DEVICE_PASS']
)

# ✅ DO: Use context managers for automatic cleanup
with DeviceDetector(host='192.168.1.1', ...) as detector:
    result = detector.ssh_detect()
# Connection automatically closed

# ❌ DON'T: Hardcode credentials
detector = DeviceDetector(host='192.168.1.1', username='admin', password='secret123')
```

### Security Testing

The library includes 215+ security tests covering:
- Credential exposure prevention
- Input sanitization and injection attacks
- SSH connection security
- Secret (enable password) handling

See [SECURITY.md](SECURITY.md) for complete security documentation, reporting vulnerabilities, and security best practices.

## Requirements

- Python 3.8+
- netmiko >= 4.1.0
- paramiko >= 2.12.0

## Development

```bash
# Clone repository
git clone https://github.com/mdrbh/device-detect.git
cd device-detect

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest tests/unit/ -v

# Run with coverage
pytest tests/ --cov=device_detect --cov-report=html
```

## License

MIT License - See LICENSE file for details

## Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Add tests for new features
4. Ensure all tests pass
5. Submit a pull request

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for version history.

## Author

Mohamed Rabeh - [GitHub](https://github.com/mdrbh)
