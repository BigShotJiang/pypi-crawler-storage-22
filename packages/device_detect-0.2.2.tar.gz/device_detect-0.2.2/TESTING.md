# Testing Guide

This document provides comprehensive information about testing the device-detect library.

## Test Suite Overview

The project includes comprehensive unit, integration, performance, and e2e tests with mutation testing validation:

- **Total Tests**: 353 tests
- **Code Coverage**: 90%
- **Mutation Score**: 77.78% (models.py) - "Very Good" rating
- **Test Duration**: Unit tests < 3s, Full suite ~2-3 minutes

## Quick Start

### Run All Tests

```bash
# Run all tests
pytest tests/ -v

# Unit tests only (fast, <2s)
pytest tests/unit/ -v

# Integration tests (requires lab devices)
pytest tests/integration/ -v -m integration

# With coverage report
pytest tests/ --cov=device_detect --cov-report=html

# View coverage
start htmlcov/index.html  # Windows
open htmlcov/index.html   # macOS
```

## Test Coverage

### Module-by-Module Coverage

| Module | Coverage | Status |
|--------|----------|--------|
| `__init__.py` | 100% | ✅ Perfect |
| `exceptions.py` | 100% | ✅ Perfect |
| `models.py` | 100% | ✅ Perfect |
| `detector.py` | 92% | ✅ Excellent |
| `patterns.py` | 90% | ✅ Excellent |
| **Overall** | **90%** | **✅ Excellent** |

## Mutation Testing

Mutation testing validates the quality of tests by introducing small code changes ("mutations") and checking if tests catch them.

- **Mutation Score**: 77.78% (models.py) - "Very Good" rating
- **Tool**: cosmic-ray (cross-platform)
- **Results**: 7 out of 9 mutations killed
- **Details**: See `tests/MUTATION_TESTING_FINAL_RESULTS.md`

### Run Mutation Tests

```bash
# Install cosmic-ray
pip install cosmic-ray

# Run mutation testing
cosmic-ray run --config internal/cosmic-ray.toml
```

## Test Structure

```
tests/
├── unit/ (230 tests)           # Unit tests (fast, <3s)
│   ├── test_models.py          # DetectionResult tests (22 tests)
│   ├── test_offline_detection* # Offline detection (28 tests)
│   ├── test_ssh_*.py           # SSH workflows (29 tests)
│   ├── test_edge_cases.py      # Edge cases (21 tests)
│   ├── test_exceptions.py      # Exception tests (18 tests)
│   ├── test_patterns.py        # Pattern utilities (20 tests)
│   ├── test_detector_core.py   # Detector core methods (35 tests)
│   ├── test_cli.py             # CLI functionality (40+ tests)
│   └── ...                     # Additional unit tests
├── integration/ (87 tests)     # Integration tests (requires devices)
│   ├── test_cisco_ios_detection.py       # Cisco device tests
│   ├── test_aruba_procurve_detection.py  # Aruba device tests
│   ├── test_multi_vendor_workflows.py    # Multi-vendor workflows
│   ├── test_data_collection.py           # Data collection tests
│   └── test_error_handling.py            # Error handling tests
├── security/ (215+ tests)      # Security & validation tests
│   ├── test_credential_security.py  # Credential protection (72 tests)
│   ├── test_input_sanitization.py   # Input validation (50+ tests)
│   ├── test_connection_security.py  # SSH security (45+ tests)
│   └── test_secret_handling.py      # Secret management (48 tests)
├── performance/ (2 tests)      # Performance benchmarks
│   └── test_benchmarks.py      # Speed & memory tests
└── e2e/ (18 tests)            # End-to-end workflow tests
    └── test_detection_workflows.py  # Real-world scenarios
```

## Test Categories

### Unit Tests

Fast, isolated tests that don't require network access or real devices.

```bash
# Run all unit tests
pytest tests/unit/ -v

# Run specific test file
pytest tests/unit/test_models.py -v

# Run specific test class
pytest tests/unit/test_models.py::TestDetectionResult -v

# Run specific test
pytest tests/unit/test_models.py::TestDetectionResult::test_to_dict -v
```

### Integration Tests

Tests requiring access to real lab devices.

```bash
# Run all integration tests
pytest tests/integration/ -v -m integration

# Run specific vendor tests
pytest tests/integration/test_cisco_ios_detection.py -v
pytest tests/integration/test_aruba_procurve_detection.py -v
```

**Note**: Integration tests require lab devices configured in `internal/lab_devices.yaml`.

### Security Tests

Comprehensive security and validation tests.

```bash
# Run all security tests
pytest tests/security/ -v -m security

# Run specific security test categories
pytest tests/security/test_credential_security.py -v
pytest tests/security/test_input_sanitization.py -v
pytest tests/security/test_connection_security.py -v
pytest tests/security/test_secret_handling.py -v
```

### Performance Tests

Benchmark tests for detection speed and memory usage.

```bash
# Run performance tests
pytest tests/performance/ -v

# Run with benchmarking plugin
pytest tests/performance/ -v --benchmark-only
```

### E2E Tests

End-to-end workflow tests for real-world scenarios.

```bash
# Run E2E tests
pytest tests/e2e/ -v -m e2e
```

## Test Markers

Tests are organized using pytest markers:

- `@pytest.mark.unit`: Fast unit tests (no network)
- `@pytest.mark.integration`: Integration tests (requires lab devices)
- `@pytest.mark.slow`: Tests that may take longer to execute
- `@pytest.mark.security`: Security and validation tests
- `@pytest.mark.e2e`: End-to-end workflow tests

### Run Tests by Marker

```bash
# Run only unit tests
pytest -v -m unit

# Run only fast tests
pytest -v -m "not slow"

# Run security tests
pytest -v -m security

# Combine markers
pytest -v -m "unit and not slow"
```

## Code Coverage

### Generate Coverage Report

```bash
# Run tests with coverage
pytest tests/ --cov=device_detect --cov-report=html --cov-report=term

# View HTML coverage report
start htmlcov/index.html  # Windows
open htmlcov/index.html   # macOS
xdg-open htmlcov/index.html  # Linux
```

### Coverage Configuration

Coverage settings are defined in `pyproject.toml`:

```toml
[tool.pytest.ini_options]
addopts = [
    "--verbose",
    "--cov=device_detect",
    "--cov-report=term-missing",
    "--cov-report=html",
]
```

## Test Fixtures

Common test fixtures are defined in `tests/conftest.py`:

### Lab Device Fixtures
- `lab_config` - Lab configuration
- `lab_credentials` - SSH credentials
- `cisco_device_ip` - Primary Cisco device
- `aruba_device_ip` - Aruba device
- `offline_device_ip` - Offline device for error testing

### Sample Data Fixtures
- `sample_cisco_show_version` - Cisco command output
- `sample_aruba_show_version` - Aruba command output
- `collected_data_cisco` - Sample collected data
- `collected_data_aruba` - Sample collected data

### Mock Fixtures
- `mock_netmiko_connection` - Mock connection object
- `temp_json_file` - Temporary file path

## Writing New Tests

### Test File Naming Convention

- Unit tests: `tests/unit/test_<module>.py`
- Integration tests: `tests/integration/test_<feature>.py`
- Security tests: `tests/security/test_<aspect>_security.py`
- Performance tests: `tests/performance/test_benchmarks.py`

### Example Unit Test

```python
import pytest
from device_detect import DeviceDetector, DetectionResult

class TestDeviceDetector:
    """Test DeviceDetector class."""
    
    def test_initialization(self):
        """Test detector initialization."""
        detector = DeviceDetector(
            host='192.168.1.1',
            username='admin',
            password='password'
        )
        assert detector.host == '192.168.1.1'
        assert detector.username == 'admin'
    
    @pytest.mark.parametrize("vendor,expected", [
        ('cisco', 'cisco'),
        ('aruba', 'aruba'),
        ('hp', 'hp'),
    ])
    def test_vendor_detection(self, vendor, expected):
        """Test vendor detection."""
        # Test implementation
        pass
```

### Example Integration Test

```python
import pytest

@pytest.mark.integration
class TestCiscoDetection:
    """Integration tests for Cisco device detection."""
    
    def test_cisco_ios_detection(self, cisco_device_ip, lab_credentials):
        """Test detection of Cisco IOS device."""
        detector = DeviceDetector(
            host=cisco_device_ip,
            username=lab_credentials['username'],
            password=lab_credentials['password']
        )
        
        with detector:
            result = detector.ssh_detect()
        
        assert result.success is True
        assert result.vendor == 'cisco'
        assert result.confidence >= 0.90
```

## Continuous Integration

### GitHub Actions

Tests run automatically on:
- Every push to `dev` and `main` branches
- Every pull request
- Scheduled nightly builds

### Local Pre-Commit

Run tests before committing:

```bash
# Install pre-commit hooks
pip install pre-commit
pre-commit install

# Run hooks manually
pre-commit run --all-files
```

## Troubleshooting

### Common Issues

**Issue**: Tests fail with "Connection refused"
```bash
# Solution: Check if using mock devices for unit tests
pytest tests/unit/ -v  # Should not require real devices
```

**Issue**: Integration tests fail
```bash
# Solution: Verify lab devices are accessible
ping <device-ip>
ssh <username>@<device-ip>
```

**Issue**: Coverage report not generated
```bash
# Solution: Install pytest-cov
pip install pytest-cov
```

### Debug Mode

Run tests with verbose output:

```bash
# Verbose pytest output
pytest tests/ -vv

# Show print statements
pytest tests/ -s

# Stop on first failure
pytest tests/ -x

# Show local variables on failure
pytest tests/ -l
```

## Test Quality Metrics

### Current Metrics
- **Test Count**: 353 tests
- **Code Coverage**: 90%
- **Mutation Score**: 77.78%
- **Test Speed**: <3 seconds (unit tests)
- **Success Rate**: 100%

### Quality Goals
- Maintain >85% code coverage
- Keep mutation score >75%
- Unit tests should run in <5 seconds
- All tests should pass before merging

## Resources

- [pytest Documentation](https://docs.pytest.org/)
- [pytest-cov Plugin](https://pytest-cov.readthedocs.io/)
- [Cosmic Ray (Mutation Testing)](https://cosmic-ray.readthedocs.io/)
- [Test Coverage Report](tests/TEST_COVERAGE_REPORT.md)
- [Mutation Testing Results](tests/MUTATION_TESTING_FINAL_RESULTS.md)

## Contributing Tests

When contributing new features:

1. **Write tests first** (TDD approach recommended)
2. **Ensure all tests pass** (`pytest tests/ -v`)
3. **Check coverage** (`pytest tests/ --cov`)
4. **Add integration tests** for new device types
5. **Update this documentation** if adding new test categories

For questions about testing, see the main [README.md](README.md) or open an issue on GitHub.
