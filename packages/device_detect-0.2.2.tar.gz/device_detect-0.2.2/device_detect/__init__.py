"""
device-detect: SSH-based network device detection library

Provides auto-detection of network device types via SSH for automation frameworks.
"""

__version__ = '0.2.2'
__author__ = 'Mohamed RABAH'
__email__ = 'mdrbh0@gmail.com'

from .detector import DeviceDetector
from .models import DetectionResult
from .exceptions import (
    DeviceDetectException,
    ConnectionError,
    AuthenticationError,
    TimeoutError,
    PatternNotFoundError,
    DetectionError
)
from .concurrent import (
    detect_multiple,
    collect_data_multiple,
    load_hosts_file,
    load_inventory,
    create_summary
)

__all__ = [
    'DeviceDetector',
    'DetectionResult',
    'DeviceDetectException',
    'ConnectionError',
    'AuthenticationError',
    'TimeoutError',
    'PatternNotFoundError',
    'DetectionError',
    'detect_multiple',
    'collect_data_multiple',
    'load_hosts_file',
    'load_inventory',
    'create_summary',
]
