"""
Command-Line Interface for device-detect

Provides a user-friendly CLI for device detection, verification, and data collection.
"""

import sys
import argparse
import json
import logging
import os
import getpass
from typing import Optional
from pathlib import Path

from . import DeviceDetector, __version__
from .concurrent import (
    detect_multiple,
    collect_data_multiple,
    load_hosts_file,
    load_inventory,
    create_summary
)


def get_credentials(args) -> tuple:
    """
    Get username and password from args, environment variables, or interactive prompts.
    
    Priority order:
    1. Command-line arguments (--user, --password)
    2. Environment variables (DEVICE_USERNAME, DEVICE_PASSWORD)
    3. Interactive prompts (secure, hidden input for password)
    
    Args:
        args: Parsed command-line arguments
        
    Returns:
        Tuple of (username, password)
    """
    # Get username
    username = args.user
    if not username:
        username = os.environ.get('DEVICE_USERNAME')
    if not username:
        try:
            username = input('Username: ')
        except (KeyboardInterrupt, EOFError):
            print("\nOperation cancelled")
            sys.exit(1)
    
    # Get password
    password = args.password
    if not password:
        password = os.environ.get('DEVICE_PASSWORD')
    if not password:
        try:
            password = getpass.getpass('Password: ')
        except (KeyboardInterrupt, EOFError):
            print("\nOperation cancelled")
            sys.exit(1)
    
    return username, password


def print_result_text(result, show_driver=None, driver_only=False):
    """Print detection result in human-readable text format.
    
    Args:
        result: DetectionResult object
        show_driver: Which driver to show ('all', 'netmiko', 'ansible', 'scrapli', 'napalm', 'nornir', or None)
        driver_only: If True, output ONLY the driver name (no other fields)
    """
    # DRIVER-ONLY MODE: Output only the driver value
    if driver_only and show_driver:
        if not result.success:
            print("DETECTION_FAILED")
            return
        
        # Map show_driver choice to result attribute
        driver_map = {
            'netmiko': result.device_type,           # Use device_type for Netmiko!
            'ansible': result.ansible_network_os,
            'scrapli': result.scrapli_driver,
            'napalm': result.napalm_driver,
            'nornir': result.nornir_platform
        }
        
        driver_value = driver_map.get(show_driver)
        if driver_value:
            print(driver_value)
        else:
            print("NOT_SUPPORTED")
        return
    
    # STANDARD MODE: Full output
    if result.success:
        print(f"✓ Device detected: {result.device_type}")
        print(f"  Vendor: {result.vendor}")
        print(f"  Confidence: {result.confidence:.0%}")
        
        # Handle driver display based on --show-driver option
        if show_driver == 'all':
            print(f"\n  Driver Mappings:")
            if result.device_type:
                print(f"    Netmiko: {result.device_type}")
            if result.ansible_network_os:
                print(f"    Ansible: {result.ansible_network_os}")
            if result.scrapli_driver:
                print(f"    Scrapli: {result.scrapli_driver}")
            if result.napalm_driver:
                print(f"    NAPALM: {result.napalm_driver}")
            if result.nornir_platform:
                print(f"    Nornir: {result.nornir_platform}")
        elif show_driver == 'netmiko':
            print(f"  Netmiko Driver: {result.device_type}")
        elif show_driver == 'ansible':
            print(f"  Ansible OS: {result.ansible_network_os or 'Not supported'}")
        elif show_driver == 'scrapli':
            print(f"  Scrapli Driver: {result.scrapli_driver or 'Not supported'}")
        elif show_driver == 'napalm':
            print(f"  NAPALM Driver: {result.napalm_driver or 'Not supported'}")
        elif show_driver == 'nornir':
            print(f"  Nornir Platform: {result.nornir_platform or 'Not supported'}")
        elif result.ansible_network_os and show_driver is None:
            print(f"  Ansible: {result.ansible_network_os}")
        
        if result.ssh_version:
            print(f"  SSH Version: {result.ssh_version}")
        print(f"  Method: {result.method}")
    else:
        if driver_only:
            print("DETECTION_FAILED")
        else:
            print(f"✗ Detection failed")
            if hasattr(result, 'error') and result.error:
                print(f"  Error: {result.error}")
            print(f"  Method: {result.method}")


def print_result_table(result):
    """Print detection result in table format."""
    print(f"{'Field':<20} {'Value':<50}")
    print("-" * 70)
    print(f"{'Success':<20} {result.success}")
    print(f"{'Device Type':<20} {result.device_type or 'N/A'}")
    print(f"{'Vendor':<20} {result.vendor or 'N/A'}")
    print(f"{'Confidence':<20} {result.confidence:.2%}" if result.confidence else f"{'Confidence':<20} N/A")
    print(f"{'Ansible OS':<20} {result.ansible_network_os or 'N/A'}")
    print(f"{'SSH Version':<20} {result.ssh_version or 'N/A'}")
    print(f"{'Method':<20} {result.method}")
    if hasattr(result, 'error') and result.error:
        print(f"{'Error':<20} {result.error}")


def print_result_json(result):
    """Print detection result in JSON format."""
    print(result.to_json())


def configure_logging(log_level: str):
    """
    Configure logging for the CLI.
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
    """
    # Convert string to logging level
    numeric_level = getattr(logging, log_level.upper(), None)
    if not isinstance(numeric_level, int):
        print(f"Warning: Invalid log level '{log_level}', using INFO")
        numeric_level = logging.INFO
    
    # Configure logging format
    logging.basicConfig(
        level=numeric_level,
        format='%(levelname)s: %(message)s',
        stream=sys.stderr  # Send logs to stderr, results to stdout
    )


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog='device-detect',
        description='Network device detection via SSH',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  # Interactive mode (recommended - prompts for credentials)
  device-detect --host 192.168.1.1
  
  # With vendor filter (faster detection)
  device-detect --host 192.168.1.1 --vendor cisco
  
  # JSON output
  device-detect --host 192.168.1.1 --format json
  
  # Verify specific device type
  device-detect --host 192.168.1.1 --verify cisco_ios
  
  # Collect device data
  device-detect --host 192.168.1.1 --collect --output device_data.json
  
  # Using environment variables for credentials
  export DEVICE_USERNAME=admin
  export DEVICE_PASSWORD=secret
  device-detect --host 192.168.1.1
  
  # Enable debug logging
  device-detect --host 192.168.1.1 --log-level DEBUG
        '''
    )
    
    # Host input methods (mutually exclusive for single vs multi-host)
    parser.add_argument(
        '--host',
        action='append',
        help='Device IP address or hostname (can be repeated for multiple hosts)'
    )
    parser.add_argument(
        '--hosts-file',
        help='File containing list of hosts (one per line, # for comments)'
    )
    parser.add_argument(
        '--inventory',
        help='Inventory file in YAML or JSON format with device list'
    )
    
    # Multi-host options
    parser.add_argument(
        '--max-workers',
        type=int,
        default=10,
        help='Maximum concurrent connections for multi-host operations (default: 10)'
    )
    parser.add_argument(
        '--output-mode',
        choices=['per-host', 'aggregated', 'both'],
        default='per-host',
        help='Output mode for multi-host: per-host files, aggregated file, or both (default: per-host)'
    )
    parser.add_argument(
        '--output-dir',
        help='Directory for per-host output files (default: current directory)'
    )
    parser.add_argument(
        '--progress',
        action='store_true',
        help='Show progress bar for multi-host operations (requires tqdm)'
    )
    
    # Optional credential arguments
    parser.add_argument(
        '--user', '--username',
        help='SSH username (or set DEVICE_USERNAME env var, or will prompt)'
    )
    parser.add_argument(
        '--password',
        help='SSH password (or set DEVICE_PASSWORD env var, or will prompt)'
    )
    
    # Connection options
    parser.add_argument(
        '--port',
        type=int,
        default=22,
        help='SSH port (default: 22)'
    )
    parser.add_argument(
        '--timeout',
        type=int,
        default=60,
        help='SSH timeout in seconds (default: 60)'
    )
    
    # Detection filters
    parser.add_argument(
        '--vendor', '--vendors',
        help='Filter by vendor (e.g., cisco, aruba, hp, juniper)'
    )
    parser.add_argument(
        '--device-type', '--device-types',
        help='Filter by device type (e.g., cisco_ios, aruba_procurve)'
    )
    parser.add_argument(
        '--ansible-os',
        help='Filter by Ansible network OS'
    )
    
    # Detection options
    parser.add_argument(
        '--fallback',
        action='store_true',
        help='Enable fallback mode (tests more patterns if initial detection fails)'
    )
    parser.add_argument(
        '--no-ssh-version',
        action='store_true',
        help='Disable SSH version detection'
    )
    parser.add_argument(
        '--no-banner',
        action='store_true',
        help='Disable banner analysis'
    )
    parser.add_argument(
        '--filter-logic',
        choices=['and', 'or'],
        default='and',
        help='Pattern filter logic: and (precise, default) or or (comprehensive)'
    )
    
    # Operation modes
    parser.add_argument(
        '--verify',
        metavar='DEVICE_TYPE',
        help='Verify specific device type instead of detecting'
    )
    parser.add_argument(
        '--collect',
        action='store_true',
        help='Collect device data for offline analysis'
    )
    parser.add_argument(
        '--offline',
        metavar='DATA_FILE',
        help='Perform offline detection using collected data file'
    )
    
    # Output options
    parser.add_argument(
        '--output', '-o',
        help='Output file for collected data or JSON results'
    )
    parser.add_argument(
        '--format',
        choices=['text', 'json', 'table'],
        default='text',
        help='Output format (default: text)'
    )
    
    # Driver mapping options
    parser.add_argument(
        '--show-driver',
        choices=['all', 'netmiko', 'ansible', 'scrapli', 'napalm', 'nornir'],
        help='Show specific automation framework driver mapping'
    )
    
    parser.add_argument(
        '--driver-only',
        action='store_true',
        help='Output only the driver name (use with --show-driver, excludes all other fields)'
    )
    
    # Logging
    parser.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='WARNING',
        help='Logging level (default: WARNING)'
    )
    
    # Version
    parser.add_argument(
        '--version',
        action='version',
        version=f'device-detect {__version__}'
    )
    
    # Parse arguments
    args = parser.parse_args()
    
    # Validate driver options
    if args.driver_only:
        if not args.show_driver:
            parser.error("--driver-only requires --show-driver to be specified")
        if args.show_driver == 'all':
            parser.error("--driver-only cannot be used with --show-driver all")
        if args.format != 'text':
            parser.error("--driver-only only works with text format (default)")
    
    # Determine hosts from various input methods
    hosts = []
    if args.host:
        hosts = args.host  # Already a list due to action='append'
    elif args.hosts_file:
        hosts = load_hosts_file(args.hosts_file)
    elif args.inventory:
        devices = load_inventory(args.inventory)
        hosts = [d['host'] for d in devices]
    elif not args.offline:
        parser.error("One of --host, --hosts-file, --inventory, or --offline is required")
    
    # Configure logging
    configure_logging(args.log_level)
    
    # Determine if multi-host mode
    is_multi_host = len(hosts) > 1
    
    try:
        # Handle offline detection mode
        if args.offline:
            logging.info(f"Performing offline detection from {args.offline}")
            result = DeviceDetector.detect_offline(
                data=args.offline,
                vendors=args.vendor,
                device_types=args.device_type,
                ansible_network_os=args.ansible_os,
                filter_logic=args.filter_logic
            )
            
            # Print result
            if args.format == 'json':
                print_result_json(result)
            elif args.format == 'table':
                print_result_table(result)
            else:
                print_result_text(result, show_driver=args.show_driver, driver_only=args.driver_only)
            
            # Exit with appropriate code
            sys.exit(0 if result.success else 1)
        
        # Get credentials (interactive if not provided)
        username, password = get_credentials(args)
        
        # MULTI-HOST MODE
        if is_multi_host:
            logging.info(f"Multi-host mode: {len(hosts)} hosts")
            
            # Setup progress callback if requested
            progress_callback = None
            if args.progress:
                try:
                    from tqdm import tqdm
                    pbar = tqdm(total=len(hosts), desc="Progress")
                    def progress_callback(completed, total):
                        pbar.update(1)
                except ImportError:
                    print("Warning: tqdm not installed, progress bar disabled")
                    print("Install with: pip install device-detect[progress]")
            
            # Handle collection mode
            if args.collect:
                results = collect_data_multiple(
                    hosts=hosts,
                    username=username,
                    password=password,
                    port=args.port,
                    timeout=args.timeout,
                    max_workers=args.max_workers,
                    progress_callback=progress_callback
                )
                
                # Save results based on output mode
                output_dir = Path(args.output_dir) if args.output_dir else Path.cwd()
                output_dir.mkdir(parents=True, exist_ok=True)
                
                if args.output_mode in ['per-host', 'both']:
                    for host, data in results.items():
                        filename = host.replace('.', '_').replace(':', '_') + '.json'
                        filepath = output_dir / filename
                        with open(filepath, 'w') as f:
                            json.dump(data, f, indent=2)
                    print(f"✓ Collected data from {len(results)} devices to {output_dir}")
                
                if args.output_mode in ['aggregated', 'both']:
                    aggregated_file = args.output or 'collected_data.json'
                    with open(aggregated_file, 'w') as f:
                        json.dump(results, f, indent=2)
                    print(f"✓ Aggregated results saved to {aggregated_file}")
                
                # Print summary
                summary = create_summary(results)
                print(f"\nSummary: {summary['successful']}/{summary['total_devices']} successful ({summary['success_rate']})")
                sys.exit(0 if summary['successful'] == summary['total_devices'] else 1)
            
            # Handle detection mode (verification not supported for multi-host)
            else:
                if args.verify:
                    print("Warning: --verify mode not supported for multi-host, using detection mode")
                
                results = detect_multiple(
                    hosts=hosts,
                    username=username,
                    password=password,
                    port=args.port,
                    timeout=args.timeout,
                    max_workers=args.max_workers,
                    vendors=args.vendor,
                    device_types=args.device_type,
                    ansible_network_os=args.ansible_os,
                    fallback=args.fallback,
                    use_ssh_version=not args.no_ssh_version,
                    use_banner=not args.no_banner,
                    filter_logic=args.filter_logic,
                    progress_callback=progress_callback
                )
                
                # Save/print results based on format and output mode
                if args.format == 'json':
                    if args.output_mode in ['per-host', 'both']:
                        output_dir = Path(args.output_dir) if args.output_dir else Path.cwd()
                        output_dir.mkdir(parents=True, exist_ok=True)
                        for host, result in results.items():
                            filename = host.replace('.', '_').replace(':', '_') + '.json'
                            filepath = output_dir / filename
                            with open(filepath, 'w') as f:
                                f.write(result.to_json())
                        print(f"✓ Results saved to {output_dir}")
                    
                    if args.output_mode in ['aggregated', 'both']:
                        aggregated_file = args.output or 'detection_results.json'
                        aggregated_data = {host: json.loads(result.to_json()) for host, result in results.items()}
                        with open(aggregated_file, 'w') as f:
                            json.dump(aggregated_data, f, indent=2)
                        print(f"✓ Aggregated results saved to {aggregated_file}")
                else:
                    # Text/table output
                    for host, result in results.items():
                        print(f"\n{'='*70}")
                        print(f"Host: {host}")
                        print('='*70)
                        if args.format == 'table':
                            print_result_table(result)
                        else:
                            print_result_text(result)
                
                # Print summary
                summary = create_summary(results)
                print(f"\n{'='*70}")
                print(f"Summary: {summary['successful']}/{summary['total_devices']} successful ({summary['success_rate']})")
                sys.exit(0 if summary['successful'] == summary['total_devices'] else 1)
        
        # SINGLE-HOST MODE (original logic)
        else:
            host = hosts[0]
            logging.info(f"Connecting to {host}:{args.port} as {username}")
            
            # Create detector
            detector = DeviceDetector(
                host=host,
                username=username,
                password=password,
                port=args.port,
                timeout=args.timeout,
                use_ssh_version=not args.no_ssh_version,
                use_banner=not args.no_banner,
                filter_logic=args.filter_logic
            )
            
            try:
                # Handle data collection mode
                if args.collect:
                    logging.info("Collecting device data")
                    data = detector.collect_data()
                    
                    if args.output:
                        with open(args.output, 'w') as f:
                            json.dump(data, f, indent=2)
                        print(f"✓ Data collected and saved to {args.output}")
                    else:
                        print(json.dumps(data, indent=2))
                    
                    sys.exit(0)
                
                # Handle verification mode
                elif args.verify:
                    logging.info(f"Verifying device type: {args.verify}")
                    result = detector.ssh_verify(args.verify)
                
                # Handle detection mode (default)
                else:
                    logging.info("Starting device detection")
                    result = detector.ssh_detect(
                        vendors=args.vendor,
                        device_types=args.device_type,
                        ansible_network_os=args.ansible_os,
                        fallback=args.fallback
                    )
                
                # Print result based on format
                if args.format == 'json':
                    if args.output:
                        with open(args.output, 'w') as f:
                            f.write(result.to_json())
                        print(f"✓ Results saved to {args.output}")
                    else:
                        print_result_json(result)
                elif args.format == 'table':
                    print_result_table(result)
                else:
                    print_result_text(result, show_driver=args.show_driver, driver_only=args.driver_only)
                
                # Exit with appropriate code
                sys.exit(0 if result.success else 1)
                
            finally:
                # Always disconnect
                detector.disconnect()
                logging.debug("Disconnected from device")
    
    except KeyboardInterrupt:
        print("\n✗ Operation cancelled by user")
        sys.exit(130)  # Standard exit code for Ctrl+C
    
    except Exception as e:
        logging.error(f"Unexpected error: {e}", exc_info=args.log_level == 'DEBUG')
        print(f"\n✗ Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
