"""
Concurrent device detection utilities for multiple hosts.

Provides parallel detection and data collection capabilities using ThreadPoolExecutor.
"""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Optional, Union
from pathlib import Path
import json
import time

from . import DeviceDetector
from .models import DetectionResult


logger = logging.getLogger(__name__)


def detect_multiple(
    hosts: List[str],
    username: str,
    password: str,
    port: int = 22,
    timeout: int = 60,
    max_workers: int = 10,
    vendors: Optional[str] = None,
    device_types: Optional[str] = None,
    ansible_network_os: Optional[str] = None,
    fallback: bool = False,
    use_ssh_version: bool = True,
    use_banner: bool = True,
    filter_logic: str = 'and',
    progress_callback: Optional[callable] = None
) -> Dict[str, DetectionResult]:
    """
    Detect multiple devices concurrently.
    
    Args:
        hosts: List of host IPs/hostnames
        username: SSH username
        password: SSH password
        port: SSH port (default: 22)
        timeout: Connection timeout in seconds
        max_workers: Maximum concurrent connections (default: 10)
        vendors: Vendor filter
        device_types: Device type filter
        ansible_network_os: Ansible OS filter
        fallback: Enable fallback mode
        use_ssh_version: Use SSH version detection
        use_banner: Use banner analysis
        filter_logic: Pattern filter logic ('and' or 'or')
        progress_callback: Optional callback function for progress updates
        
    Returns:
        Dict mapping host -> DetectionResult
    """
    results = {}
    start_time = time.time()
    total = len(hosts)
    completed = 0
    
    logger.info(f"Starting concurrent detection for {total} hosts with {max_workers} workers")
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all detection tasks
        future_to_host = {}
        for host in hosts:
            future = executor.submit(
                _detect_single,
                host=host,
                username=username,
                password=password,
                port=port,
                timeout=timeout,
                vendors=vendors,
                device_types=device_types,
                ansible_network_os=ansible_network_os,
                fallback=fallback,
                use_ssh_version=use_ssh_version,
                use_banner=use_banner,
                filter_logic=filter_logic
            )
            future_to_host[future] = host
        
        # Collect results as they complete
        for future in as_completed(future_to_host):
            host = future_to_host[future]
            completed += 1
            
            try:
                result = future.result()
                results[host] = result
                logger.info(f"Completed {host}: {result.device_type if result.success else 'failed'}")
            except Exception as e:
                logger.error(f"Failed to detect {host}: {e}")
                results[host] = DetectionResult(
                    success=False,
                    error=str(e),
                    method='concurrent'
                )
            
            # Progress callback
            if progress_callback:
                progress_callback(completed, total)
    
    duration = time.time() - start_time
    logger.info(f"Concurrent detection completed in {duration:.2f}s")
    
    return results


def collect_data_multiple(
    hosts: List[str],
    username: str,
    password: str,
    port: int = 22,
    timeout: int = 60,
    max_workers: int = 10,
    progress_callback: Optional[callable] = None
) -> Dict[str, dict]:
    """
    Collect data from multiple devices concurrently.
    
    Args:
        hosts: List of host IPs/hostnames
        username: SSH username
        password: SSH password
        port: SSH port (default: 22)
        timeout: Connection timeout in seconds
        max_workers: Maximum concurrent connections (default: 10)
        progress_callback: Optional callback function for progress updates
        
    Returns:
        Dict mapping host -> collected_data
    """
    results = {}
    start_time = time.time()
    total = len(hosts)
    completed = 0
    
    logger.info(f"Starting concurrent data collection for {total} hosts with {max_workers} workers")
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all collection tasks
        future_to_host = {}
        for host in hosts:
            future = executor.submit(
                _collect_single,
                host=host,
                username=username,
                password=password,
                port=port,
                timeout=timeout
            )
            future_to_host[future] = host
        
        # Collect results as they complete
        for future in as_completed(future_to_host):
            host = future_to_host[future]
            completed += 1
            
            try:
                data = future.result()
                results[host] = data
                logger.info(f"Collected data from {host}")
            except Exception as e:
                logger.error(f"Failed to collect data from {host}: {e}")
                results[host] = {
                    'error': str(e),
                    'success': False,
                    'metadata': {'host': host}
                }
            
            # Progress callback
            if progress_callback:
                progress_callback(completed, total)
    
    duration = time.time() - start_time
    logger.info(f"Concurrent data collection completed in {duration:.2f}s")
    
    return results


def _detect_single(
    host: str,
    username: str,
    password: str,
    port: int = 22,
    timeout: int = 60,
    **kwargs
) -> DetectionResult:
    """
    Detect a single device (internal helper function).
    
    Args:
        host: Device IP/hostname
        username: SSH username
        password: SSH password
        port: SSH port
        timeout: Connection timeout
        **kwargs: Additional DeviceDetector.ssh_detect() arguments
        
    Returns:
        DetectionResult
    """
    try:
        detector = DeviceDetector(
            host=host,
            username=username,
            password=password,
            port=port,
            timeout=timeout
        )
        
        try:
            result = detector.ssh_detect(**kwargs)
            return result
        finally:
            detector.disconnect()
    
    except Exception as e:
        logger.error(f"Error detecting {host}: {e}")
        return DetectionResult(
            success=False,
            error=str(e),
            method='concurrent'
        )


def _collect_single(
    host: str,
    username: str,
    password: str,
    port: int = 22,
    timeout: int = 60
) -> dict:
    """
    Collect data from a single device (internal helper function).
    
    Args:
        host: Device IP/hostname
        username: SSH username
        password: SSH password
        port: SSH port
        timeout: Connection timeout
        
    Returns:
        Collected data dictionary
    """
    detector = DeviceDetector(
        host=host,
        username=username,
        password=password,
        port=port,
        timeout=timeout
    )
    
    try:
        data = detector.collect_data()
        return data
    finally:
        detector.disconnect()


def load_hosts_file(filepath: Union[str, Path]) -> List[str]:
    """
    Load hosts from a simple text file (one host per line).
    
    Args:
        filepath: Path to hosts file
        
    Returns:
        List of host addresses
    """
    hosts = []
    filepath = Path(filepath)
    
    logger.info(f"Loading hosts from {filepath}")
    
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            # Skip empty lines and comments
            if line and not line.startswith('#'):
                hosts.append(line)
    
    logger.info(f"Loaded {len(hosts)} hosts from {filepath}")
    return hosts


def load_inventory(filepath: Union[str, Path]) -> List[Dict]:
    """
    Load inventory from YAML or JSON file.
    
    Args:
        filepath: Path to inventory file (.yaml, .yml, or .json)
        
    Returns:
        List of device dictionaries with 'host' and optional hints
    """
    filepath = Path(filepath)
    logger.info(f"Loading inventory from {filepath}")
    
    # Determine file format
    suffix = filepath.suffix.lower()
    
    if suffix in ['.yaml', '.yml']:
        import yaml
        with open(filepath, 'r') as f:
            data = yaml.safe_load(f)
    elif suffix == '.json':
        with open(filepath, 'r') as f:
            data = json.load(f)
    else:
        raise ValueError(f"Unsupported inventory format: {suffix}. Use .yaml, .yml, or .json")
    
    # Extract devices list
    if 'devices' in data:
        devices = data['devices']
    elif isinstance(data, list):
        devices = data
    else:
        raise ValueError("Inventory must contain 'devices' key or be a list")
    
    # Validate devices
    for device in devices:
        if 'host' not in device:
            raise ValueError(f"Device entry missing 'host' field: {device}")
    
    logger.info(f"Loaded {len(devices)} devices from inventory")
    return devices


def create_summary(results: Dict[str, Union[DetectionResult, dict]]) -> dict:
    """
    Create a summary report from detection/collection results.
    
    Args:
        results: Dict mapping host -> result
        
    Returns:
        Summary dictionary
    """
    total = len(results)
    successful = 0
    failed = 0
    
    for result in results.values():
        if isinstance(result, DetectionResult):
            if result.success:
                successful += 1
            else:
                failed += 1
        elif isinstance(result, dict):
            if result.get('success', True) and 'error' not in result:
                successful += 1
            else:
                failed += 1
    
    summary = {
        'total_devices': total,
        'successful': successful,
        'failed': failed,
        'success_rate': f"{(successful/total*100):.1f}%" if total > 0 else "0%"
    }
    
    return summary
