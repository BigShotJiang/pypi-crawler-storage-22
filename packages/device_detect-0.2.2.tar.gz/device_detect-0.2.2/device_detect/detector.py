"""
Device Detector Module

This module contains the DeviceDetector class which is the main entry point
for SSH-based device detection and verification.
"""

import logging
from typing import Optional, Union, List
from netmiko import ConnectHandler
from netmiko.exceptions import (
    NetMikoTimeoutException,
    NetMikoAuthenticationException,
)

from .models import DetectionResult
from .exceptions import (
    ConnectionError,
    AuthenticationError,
    TimeoutError,
    PatternNotFoundError,
    DetectionError,
)
from .patterns import (
    filter_patterns,
    filter_patterns_and,
    filter_patterns_or,
    get_detection_order,
    SSH_DETECTION_PATTERNS,
    BANNER_VENDOR_PATTERNS,
)

# Initialize logger
logger = logging.getLogger(__name__)


class DeviceDetector:
    """
    Main class for SSH-based network device detection and verification.
    
    Design Principles:
    - Lazy connection: SSH connection established when detection/verification methods are called
    - Reusable connection: Same connection can be used for multiple operations
    - Resource management: Proper cleanup with context manager support
    - Thread-safe: Can be used by concurrent frameworks (no shared state)
    
    Example:
        >>> # Basic detection
        >>> detector = DeviceDetector(
        ...     host='192.168.1.1',
        ...     username='admin',
        ...     password='your_password'
        ... )
        >>> result = detector.ssh_detect()
        >>> print(result.device_type)
        'cisco_ios'
        >>> detector.disconnect()
        
        >>> # With context manager
        >>> with DeviceDetector(host='192.168.1.1', ...) as detector:
        ...     result = detector.ssh_detect(vendors='cisco')
        ...     print(result.vendor)
        'cisco'
    """
    
    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        port: int = 22,
        secret: Optional[str] = None,
        timeout: int = 60,
        use_ssh_version: bool = True,
        use_banner: bool = True,
        filter_logic: str = 'and'
    ):
        """
        Initialize detector with connection parameters (no connection established yet).
        
        Args:
            host: IP address or hostname of the device
            username: SSH username
            password: SSH password
            port: SSH port (default: 22)
            secret: Enable password for privilege escalation (optional)
            timeout: Global timeout for SSH operations in seconds (default: 60)
            use_ssh_version: Enable SSH version detection for speed optimization (default: True)
            use_banner: Enable banner analysis for vendor detection (default: True)
            filter_logic: Pattern filtering logic - 'and' (default, intersection) or 'or' (union)
        """
        self.host = host
        self.username = username
        self.password = password
        self.port = port
        self.secret = secret
        self.timeout = timeout
        self.use_ssh_version = use_ssh_version
        self.use_banner = use_banner
        self.filter_logic = filter_logic
        
        # Connection state (lazy initialization)
        self._connection = None
        self._connected = False
        
        logger.info(f"Initialized DeviceDetector for {host}:{port} (user: {username})")
    
    def _connect(self) -> None:
        """
        Establish SSH connection (lazy initialization).
        
        Uses netmiko with device_type='autodetect' for generic connection.
        Connection is reused for subsequent operations.
        
        Raises:
            ConnectionError: If SSH connection fails
            AuthenticationError: If SSH authentication fails
            TimeoutError: If connection times out
        """
        if self._connected and self._connection:
            logger.debug(f"Reusing existing connection to {self.host}")
            return  # Already connected, reuse connection
        
        logger.debug(f"Connecting to {self.host}:{self.port}")
        try:
            # Use netmiko's autodetect for initial connection
            self._connection = ConnectHandler(
                device_type='autodetect',
                host=self.host,
                username=self.username,
                password=self.password,
                port=self.port,
                secret=self.secret,
                timeout=self.timeout,
            )
            
            # Wait for login to complete and capture initial output (banner)
            import time
            time.sleep(0.5)  # Reduced from 3s - banner available in <0.1s (5x safety margin)
            
            # Capture banner and initial shell output for vendor detection
            from netmiko.base_connection import BaseConnection
            output = BaseConnection._test_channel_read(self._connection)
            self._initial_buffer = output
            
            # Detect prompt by sending newlines
            self._prompt = self._detect_prompt()
            
            self._connected = True
            
        except NetMikoAuthenticationException as e:
            raise AuthenticationError(f"SSH authentication failed for {self.host}: {e}")
        except NetMikoTimeoutException as e:
            raise TimeoutError(f"SSH connection timeout for {self.host}: {e}")
        except Exception as e:
            raise ConnectionError(f"SSH connection failed for {self.host}: {e}")
    
    def _detect_vendor_from_banner(self, banner: str) -> Optional[str]:
        """
        Detect vendor from SSH banner/initial output.
        
        Only detects Aruba and HP vendors from banner (defined in BANNER_VENDOR_PATTERNS).
        Returns None for other vendors (they will use full pattern matching).
        
        Args:
            banner: Initial SSH output containing banner and login messages
            
        Returns:
            Vendor name ('aruba', 'hp') or None if not detected
        """
        import re
        
        for vendor, patterns in BANNER_VENDOR_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, banner, re.IGNORECASE):
                    return vendor
        
        return None
    
    def _detect_prompt(self) -> str:
        """
        Detect the device prompt by sending newlines.
        
        Returns:
            Detected prompt string
        """
        import time
        import re
        
        # Clear any buffered output
        self._connection.clear_buffer()
        
        # Send multiple newlines to get clean prompt
        self._connection.write_channel("\n\n\n")
        time.sleep(0.5)
        
        # Read response
        output = self._connection.read_channel()
        
        # Extract prompt (last non-empty line)
        lines = [line for line in output.splitlines() if line.strip()]
        if lines:
            # Last line should be the prompt
            prompt = lines[-1].strip()
            # Clean escape sequences
            prompt = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', prompt)
            return prompt
        
        # Fallback: return generic prompt pattern
        return r'[\w\-\.]+[#>]'
    
    def _detect_ssh_version(self) -> Optional[str]:
        """
        Detect remote SSH server version using paramiko transport.
        
        Uses Netmiko's invalid_responses technique:
        - Filters out empty SSH version strings with pattern [r"^$"]
        - Returns None if version is invalid/empty
        
        Returns:
            SSH version string or None if invalid
            
        Example:
            >>> ssh_version = detector._detect_ssh_version()
            >>> print(ssh_version)
            'SSH-2.0-Cisco-1.25'
        """
        import re
        import paramiko
        
        # Netmiko's invalid_responses pattern for SSH version detection
        invalid_responses = [r"^$"]  # Filter empty strings
        
        try:
            remote_conn = self._connection.remote_conn
            if not isinstance(remote_conn, paramiko.Channel):
                return None
                
            if remote_conn.transport is None:
                return None
                
            remote_version = remote_conn.transport.remote_version
            
            # Apply invalid_responses filter (Netmiko technique)
            for pattern in invalid_responses:
                if re.search(pattern, remote_version, re.I):
                    return None  # Ignore empty/invalid versions
            
            return remote_version
            
        except Exception:
            return None  # Silent failure - SSH version detection is optional
    
    def _match_ssh_version(self, ssh_version: str) -> List[str]:
        """
        Match SSH version string against device patterns.
        
        Returns list of matching device_types ordered by priority.
        Uses patterns from DEVICE_PATTERNS['device_type']['ssh_version'].
        
        Args:
            ssh_version: SSH server version string
            
        Returns:
            List of device_type strings that match (ordered by priority)
            
        Example:
            >>> matches = detector._match_ssh_version('SSH-2.0-Cisco-1.25')
            >>> print(matches)
            ['cisco_nxos', 'cisco_xr', 'cisco_wlc', 'cisco_ios']  # Ordered by priority
        """
        import re
        from .patterns import get_ssh_version_detection_order
        
        matches = []
        
        for device_type, ssh_pattern in get_ssh_version_detection_order():
            search_patterns = ssh_pattern.get('search_patterns', [])
            
            for pattern in search_patterns:
                if re.search(pattern, ssh_version, re.IGNORECASE):
                    matches.append(device_type)
                    break  # Found match for this device_type, move to next
        
        return matches
    
    def _execute_command(self, cmd: str) -> str:
        """
        Execute command and return output using prompt-based detection.
        
        Args:
            cmd: Command to execute
            
        Returns:
            Command output
        """
        import time
        
        # Clear buffer
        self._connection.clear_buffer()
        
        # Send command
        self._connection.write_channel(cmd + "\n")
        
        # Small delay to let command start
        time.sleep(0.3)
        
        # Read until we see the prompt again (or timeout)
        try:
            # Use prompt-based reading if we have a good prompt
            if hasattr(self, '_prompt') and self._prompt and len(self._prompt) > 5:
                output = self._connection.read_until_prompt(pattern=self._prompt, read_timeout=10)
            else:
                # Fallback to timing-based (shorter delay)
                output = self._connection.read_channel_timing(last_read=2.0)
        except Exception:
            # If prompt reading fails, use timing-based
            output = self._connection.read_channel_timing(last_read=2.0)
        
        # Clean output
        output = self._connection.strip_backspaces(output)
        
        return output
    
    def ssh_detect(
        self,
        vendors: Optional[Union[str, List[str]]] = None,
        device_types: Optional[Union[str, List[str]]] = None,
        ansible_network_os: Optional[Union[str, List[str]]] = None,
        fallback: bool = False,
        use_ssh_version: Optional[bool] = None,
        use_banner: Optional[bool] = None,
        filter_logic: Optional[str] = None
    ) -> DetectionResult:
        """
        Detect device type using SSH pattern matching with configurable filter logic.
        
        Detection workflow:
        1. Establish SSH connection (lazy)
        2. Auto-detect hints from SSH version and banner (if enabled)
        3. Filter patterns using AND or OR logic
        4. Apply detection techniques (command execution)
        5. If fallback enabled: Phase 2 (OR) → Phase 3 (ALL)
        
        Filter Logic Modes:
        - 'and' (default): Intersection - patterns must match ALL active constraints
        - 'or': Union - patterns match ANY constraint (legacy behavior)
        
        Args:
            vendors: Filter patterns by vendor name(s) (list or string)
            device_types: Filter patterns by device type(s) (list or string)
            ansible_network_os: Filter patterns by Ansible network OS (list or string)
            fallback: If True, use two-phase fallback (AND→OR→ALL) (default: False)
            use_ssh_version: Override instance setting for SSH version detection
            use_banner: Override instance setting for banner analysis
            filter_logic: Override instance filter_logic ('and' or 'or')
            
        Returns:
            DetectionResult object with device_type, vendor, confidence, etc.
            
        Example:
            >>> # AND logic (default) - very precise
            >>> detector = DeviceDetector(host='192.168.1.1', ...)
            >>> result = detector.ssh_detect(vendors='cisco')
            >>> # Tests only Cisco devices matching SSH version AND banner
            
            >>> # OR logic - broader search
            >>> result = detector.ssh_detect(vendors='cisco', filter_logic='or')
            
            >>> # Two-phase fallback
            >>> result = detector.ssh_detect(vendors='cisco', fallback=True)
            >>> # Phase 1: AND logic, Phase 2: OR logic, Phase 3: ALL patterns
        """
        ssh_version = None
        
        try:
            # Step 1: Establish connection
            self._connect()
            
            # Determine settings (method parameter > instance setting)
            enable_ssh_version = use_ssh_version if use_ssh_version is not None else self.use_ssh_version
            enable_banner = use_banner if use_banner is not None else self.use_banner
            logic_mode = filter_logic if filter_logic is not None else self.filter_logic
            
            # Step 2: Detect SSH version (if enabled)
            if enable_ssh_version:
                ssh_version = self._detect_ssh_version()
            
            # Step 3: Detect SSH version matches
            ssh_version_matches = []
            if enable_ssh_version and ssh_version:
                ssh_version_matches = self._match_ssh_version(ssh_version)
            
            # Step 4: Detect banner vendor
            banner_vendor = None
            if enable_banner and hasattr(self, '_initial_buffer'):
                banner_vendor = self._detect_vendor_from_banner(self._initial_buffer)
            
            # PHASE 1: Primary detection with selected logic mode
            if logic_mode == 'and':
                patterns_phase1 = filter_patterns_and(
                    user_vendors=vendors,
                    user_device_types=device_types,
                    user_ansible_os=ansible_network_os,
                    ssh_device_types=ssh_version_matches if ssh_version_matches else None,
                    banner_vendor=banner_vendor,
                    use_ssh_version=enable_ssh_version,
                    use_banner=enable_banner
                )
            else:  # logic_mode == 'or'
                patterns_phase1 = filter_patterns_or(
                    user_vendors=vendors,
                    user_device_types=device_types,
                    user_ansible_os=ansible_network_os,
                    ssh_device_types=ssh_version_matches if ssh_version_matches else None,
                    banner_vendor=banner_vendor,
                    use_ssh_version=enable_ssh_version,
                    use_banner=enable_banner
                )
            
            if not patterns_phase1:
                return DetectionResult(
                    success=False,
                    error="No patterns match the filter criteria",
                    method='filter',
                    ssh_version=ssh_version
                )
            
            # Sort patterns by priority
            sorted_patterns_phase1 = sorted(
                patterns_phase1.items(),
                key=lambda x: x[1].get('priority', 0),
                reverse=True
            )
            
            # Collect and execute unique commands ONCE
            unique_commands = {}
            for device_type, pattern in sorted_patterns_phase1:
                cmd = pattern.get('cmd')
                if cmd and cmd not in unique_commands:
                    unique_commands[cmd] = None
            
            command_cache = {}
            for cmd in unique_commands.keys():
                try:
                    output = self._execute_command(cmd)
                    command_cache[cmd] = output
                except Exception:
                    command_cache[cmd] = ""
            
            # Test Phase 1 patterns
            tested_patterns = set()
            for device_type, pattern in sorted_patterns_phase1:
                tested_patterns.add(device_type)
                result = self._try_pattern(device_type, pattern, command_cache, ssh_version)
                if result.success:
                    return result
            
            # PHASE 2: Fallback to OR mode (only if in AND mode and fallback enabled)
            if fallback and logic_mode == 'and':
                patterns_phase2 = filter_patterns_or(
                    user_vendors=vendors,
                    user_device_types=device_types,
                    user_ansible_os=ansible_network_os,
                    ssh_device_types=ssh_version_matches if ssh_version_matches else None,
                    banner_vendor=banner_vendor,
                    use_ssh_version=enable_ssh_version,
                    use_banner=enable_banner
                )
                
                sorted_patterns_phase2 = sorted(
                    patterns_phase2.items(),
                    key=lambda x: x[1].get('priority', 0),
                    reverse=True
                )
                
                # Test untested patterns from OR mode
                for device_type, pattern in sorted_patterns_phase2:
                    if device_type not in tested_patterns:
                        tested_patterns.add(device_type)
                        result = self._try_pattern(device_type, pattern, command_cache, ssh_version)
                        if result.success:
                            return result
            
            # PHASE 3: Fallback to ALL patterns (if enabled)
            if fallback:
                all_patterns = get_detection_order()
                for device_type, pattern in all_patterns:
                    if device_type not in tested_patterns:
                        result = self._try_pattern(device_type, pattern, None, ssh_version)
                        if result.success:
                            return result
            
            # No patterns matched
            return DetectionResult(
                success=False,
                error=f"No matching patterns found after testing {len(tested_patterns)} patterns",
                method='command',
                ssh_version=ssh_version
            )
            
        except (ConnectionError, AuthenticationError, TimeoutError) as e:
            return DetectionResult(
                success=False,
                error=str(e),
                method='connection',
                ssh_version=ssh_version if 'ssh_version' in locals() else None
            )
        except Exception as e:
            return DetectionResult(
                success=False,
                error=f"Detection failed: {e}",
                method='unknown',
                ssh_version=ssh_version if 'ssh_version' in locals() else None
            )
    
    def _try_pattern(self, device_type: str, pattern: dict, command_cache: dict = None, ssh_version: Optional[str] = None) -> DetectionResult:
        """
        Try a single detection pattern.
        
        Args:
            device_type: Device type identifier
            pattern: Pattern dictionary
            command_cache: Optional cache of already-executed commands
            ssh_version: Optional SSH version string to include in result
            
        Returns:
            DetectionResult with success status
        """
        import re
        
        try:
            # Get command and search patterns
            cmd = pattern.get('cmd')
            search_patterns = pattern.get('search_patterns', [])
            
            if not cmd or not search_patterns:
                return DetectionResult(
                    success=False,
                    error=f"Invalid pattern for {device_type}: missing cmd or search_patterns",
                    method='command',
                    ssh_version=ssh_version
                )
            
            # Use cached output if available, otherwise execute command
            if command_cache and cmd in command_cache:
                output = command_cache[cmd]
            else:
                # Execute command (fallback for ssh_verify and fallback mode)
                output = self._execute_command(cmd)
            
            # Try to match against search patterns
            matches = []
            for search_pattern in search_patterns:
                if re.search(search_pattern, output, re.IGNORECASE):
                    matches.append(search_pattern)
            
            # Calculate confidence based on matches
            if matches:
                # Fixed high confidence for any pattern match (OR logic)
                # Multiple search_patterns are alternatives, not requirements
                confidence = 0.95
                
                # Get driver mappings from DEVICE_PATTERNS
                from .patterns import DEVICE_PATTERNS
                device_pattern = DEVICE_PATTERNS.get(device_type, {})
                
                return DetectionResult(
                    success=True,
                    device_type=device_type,
                    vendor=pattern.get('vendor'),
                    ansible_network_os=pattern.get('ansible_network_os'),
                    scrapli_driver=device_pattern.get('scrapli_driver'),
                    napalm_driver=device_pattern.get('napalm_driver'),
                    nornir_platform=device_pattern.get('nornir_platform'),
                    confidence=confidence,
                    method='command',
                    matched_pattern=', '.join(matches[:2]),  # First 2 matches
                    ssh_version=ssh_version
                )
            else:
                # No matches
                return DetectionResult(
                    success=False,
                    error=f"No patterns matched for {device_type}",
                    method='command',
                    ssh_version=ssh_version
                )
                
        except Exception as e:
            return DetectionResult(
                success=False,
                error=f"Pattern test failed for {device_type}: {e}",
                method='command',
                ssh_version=ssh_version
            )
    
    def ssh_verify(self, device_type: str) -> DetectionResult:
        """
        Verify a suspected device type using SSH (MANUAL USE ONLY).
        
        NOTE: This method is NOT called automatically by ssh_detect().
        It is designed for:
        - Manual verification by user when device type is already suspected
        - Future v2.0: Verifying SNMP detection results via SSH
        - Explicit confirmation of device type from external sources
        
        Args:
            device_type: The device type to verify (e.g., 'cisco_ios', 'juniper_junos')
            
        Returns:
            DetectionResult object with verification success/failure and confidence
        
        Example:
            # Manual verification
            detector = DeviceDetector(host='192.168.1.1', ...)
            result = detector.ssh_verify('cisco_ios')  # Explicitly verify
        """
        try:
            # Step 1: Establish connection
            self._connect()
            
            # Step 2: Retrieve pattern
            if device_type not in SSH_DETECTION_PATTERNS:
                return DetectionResult(
                    success=False,
                    error=f"Pattern not found for device_type: {device_type}",
                    method='verification'
                )
            
            pattern = SSH_DETECTION_PATTERNS[device_type]
            
            # Step 3: Execute verification
            result = self._try_pattern(device_type, pattern)
            
            # Verification requires high confidence
            if result.success and result.confidence >= 0.95:
                return result
            else:
                return DetectionResult(
                    success=False,
                    device_type=device_type,
                    error="Verification failed: confidence too low",
                    confidence=result.confidence if result else 0.0,
                    method='verification'
                )
                
        except (ConnectionError, AuthenticationError, TimeoutError) as e:
            return DetectionResult(
                success=False,
                error=str(e),
                method='verification'
            )
        except Exception as e:
            return DetectionResult(
                success=False,
                error=f"Verification failed: {e}",
                method='verification'
            )
    
    def collect_data(
        self,
        vendor: Optional[str] = None,
        device_type: Optional[str] = None,
    ) -> dict:
        """
        Collect raw device data for offline detection or AI training.
        
        This method connects to the device and collects all data needed for detection
        WITHOUT performing actual pattern matching. The data can be saved and used
        later for offline detection or for training AI models to generate better patterns.
        
        Data Collection Process:
        1. Establish SSH connection
        2. Collect SSH version string
        3. Collect banner/initial output
        4. Execute ALL commands from detection patterns (same as ssh_detect)
        5. Return structured dictionary with all collected data
        
        Args:
            vendor: Optional expected vendor (for AI training labels)
            device_type: Optional expected device_type (for AI training labels)
            
        Returns:
            Dictionary with collected data in standardized format:
            {
                "metadata": {
                    "host": str,
                    "port": int,
                    "timestamp": str (ISO format),
                    "collector_version": str,
                    "expected_vendor": str (optional),
                    "expected_device_type": str (optional)
                },
                "ssh_data": {
                    "ssh_version": str or None,
                    "banner": str,
                    "prompt": str
                },
                "command_outputs": {
                    "command1": "output1",
                    "command2": "output2",
                    ...
                }
            }
            
        Example:
            >>> detector = DeviceDetector(host='192.168.1.1', ...)
            >>> data = detector.collect_data(vendor='cisco', device_type='cisco_ios')
            >>> 
            >>> # Save for later use
            >>> import json
            >>> with open('device_data.json', 'w') as f:
            ...     json.dump(data, f, indent=2)
            >>> 
            >>> # Later: offline detection
            >>> result = DeviceDetector.detect_offline('device_data.json')
        """
        from datetime import datetime
        from . import __version__
        
        try:
            # Step 1: Establish connection
            self._connect()
            
            # Step 2: Collect SSH version
            ssh_version = None
            if self.use_ssh_version:
                ssh_version = self._detect_ssh_version()
            
            # Step 3: Collect banner
            banner = ""
            if self.use_banner and hasattr(self, '_initial_buffer'):
                banner = self._initial_buffer
            
            # Step 4: Collect prompt
            prompt = ""
            if hasattr(self, '_prompt'):
                prompt = self._prompt
            
            # Step 5: Get all unique commands from patterns
            unique_commands = set()
            for device_type_key, pattern in SSH_DETECTION_PATTERNS.items():
                cmd = pattern.get('cmd')
                if cmd:
                    unique_commands.add(cmd)
            
            # Step 6: Execute all commands and collect outputs
            command_outputs = {}
            for cmd in sorted(unique_commands):  # Sort for consistent output
                try:
                    output = self._execute_command(cmd)
                    command_outputs[cmd] = output
                except Exception as e:
                    # Store empty string on error (device may not support command)
                    command_outputs[cmd] = ""
            
            # Step 7: Build structured data dictionary
            collected_data = {
                "metadata": {
                    "host": self.host,
                    "port": self.port,
                    "timestamp": datetime.now().isoformat(),
                    "collector_version": __version__,
                },
                "ssh_data": {
                    "ssh_version": ssh_version,
                    "banner": banner,
                    "prompt": prompt,
                },
                "command_outputs": command_outputs,
            }
            
            # Add optional labels for AI training
            if vendor:
                collected_data["metadata"]["expected_vendor"] = vendor
            if device_type:
                collected_data["metadata"]["expected_device_type"] = device_type
            
            return collected_data
            
        except (ConnectionError, AuthenticationError, TimeoutError) as e:
            raise
        except Exception as e:
            raise DetectionError(f"Data collection failed: {e}")
    
    @staticmethod
    def _load_collected_data(data: Union[str, dict, 'Path']) -> dict:
        """
        Load collected data from various input formats.
        
        Args:
            data: JSON file path (str/Path), JSON string, or dict
            
        Returns:
            Parsed data dictionary
            
        Raises:
            ValueError: If data cannot be loaded or parsed
        """
        import json
        from pathlib import Path
        
        # Case 1: Already a dictionary
        if isinstance(data, dict):
            return data
        
        # Case 2: File path (string or Path object)
        if isinstance(data, (str, Path)):
            try:
                path = Path(data)
                if path.exists() and path.is_file():
                    with open(path, 'r') as f:
                        return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass  # Try parsing as JSON string
            
            # Case 3: JSON string
            try:
                return json.loads(data)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON data: {e}")
        
        raise ValueError(f"Unsupported data type: {type(data)}")
    
    @staticmethod
    def _validate_collected_data(data: dict) -> tuple:
        """
        Validate structure of collected data.
        
        Args:
            data: Collected data dictionary to validate
            
        Returns:
            Tuple of (is_valid, error_message)
            - is_valid: True if data is valid, False otherwise
            - error_message: None if valid, error description if invalid
        """
        # Check top-level structure
        required_keys = {'metadata', 'ssh_data', 'command_outputs'}
        if not all(key in data for key in required_keys):
            missing = required_keys - set(data.keys())
            return False, f"Missing required keys: {missing}"
        
        # Validate metadata
        metadata = data.get('metadata', {})
        if not isinstance(metadata, dict):
            return False, "metadata must be a dictionary"
        
        required_metadata = {'host', 'timestamp', 'collector_version'}
        if not all(key in metadata for key in required_metadata):
            missing = required_metadata - set(metadata.keys())
            return False, f"Missing required metadata keys: {missing}"
        
        # Validate ssh_data
        ssh_data = data.get('ssh_data', {})
        if not isinstance(ssh_data, dict):
            return False, "ssh_data must be a dictionary"
        
        # Validate command_outputs
        command_outputs = data.get('command_outputs', {})
        if not isinstance(command_outputs, dict):
            return False, "command_outputs must be a dictionary"
        
        return True, None
    
    @staticmethod
    def detect_offline(
        data: Union[str, dict, 'Path'],
        vendors: Optional[Union[str, List[str]]] = None,
        device_types: Optional[Union[str, List[str]]] = None,
        ansible_network_os: Optional[Union[str, List[str]]] = None,
        filter_logic: str = 'and'
    ) -> DetectionResult:
        """
        Perform offline detection using previously collected data with configurable filter logic.
        
        This static method performs device detection without requiring an SSH connection.
        It uses data previously collected via collect_data() to match against detection
        patterns. Useful for testing patterns, batch processing, or AI model evaluation.
        
        Detection Process:
        1. Load and validate collected data
        2. Auto-detect hints from SSH version and banner
        3. Filter patterns using AND or OR logic
        4. Match command output patterns
        5. Return DetectionResult
        
        Args:
            data: Collected data (JSON file path, JSON string, or dict)
            vendors: Filter patterns by vendor name(s) (list or string)
            device_types: Filter patterns by device type(s) (list or string)
            ansible_network_os: Filter patterns by Ansible network OS (list or string)
            filter_logic: Pattern filtering logic - 'and' (default, intersection) or 'or' (union)
            
        Returns:
            DetectionResult object with detection results
            
        Raises:
            ValueError: If data is invalid or cannot be loaded
            
        Example:
            >>> # AND logic (default) - very precise
            >>> result = DeviceDetector.detect_offline('device_data.json')
            >>> print(result.device_type)
            'cisco_ios'
            >>> 
            >>> # From dict with AND logic
            >>> data = {...}
            >>> result = DeviceDetector.detect_offline(data, vendors='cisco')
            >>> 
            >>> # OR logic - broader search
            >>> result = DeviceDetector.detect_offline(
            ...     'data.json',
            ...     vendors=['cisco', 'aruba'],
            ...     filter_logic='or'
            ... )
        """
        import re
        
        try:
            # Step 1: Load data
            collected_data = DeviceDetector._load_collected_data(data)
            
            # Step 2: Validate data
            is_valid, error_msg = DeviceDetector._validate_collected_data(collected_data)
            if not is_valid:
                return DetectionResult(
                    success=False,
                    error=f"Invalid collected data: {error_msg}",
                    method='offline'
                )
            
            # Extract data sections
            ssh_data = collected_data.get('ssh_data', {})
            command_outputs = collected_data.get('command_outputs', {})
            ssh_version = ssh_data.get('ssh_version')
            banner = ssh_data.get('banner', '')
            
            # Step 3: Auto-detect hints from SSH version
            ssh_version_matches = []
            if ssh_version:
                from .patterns import get_ssh_version_detection_order
                
                for dt, ssh_pattern in get_ssh_version_detection_order():
                    search_patterns = ssh_pattern.get('search_patterns', [])
                    for pattern in search_patterns:
                        if re.search(pattern, ssh_version, re.IGNORECASE):
                            ssh_version_matches.append(dt)
                            break
            
            # Step 4: Auto-detect vendor from banner
            banner_vendor = None
            if banner:
                for vendor, patterns in BANNER_VENDOR_PATTERNS.items():
                    for pattern in patterns:
                        if re.search(pattern, banner, re.IGNORECASE):
                            banner_vendor = vendor
                            break
                    if banner_vendor:
                        break
            
            # Step 5: Filter patterns using selected logic
            if filter_logic == 'and':
                patterns = filter_patterns_and(
                    user_vendors=vendors,
                    user_device_types=device_types,
                    user_ansible_os=ansible_network_os,
                    ssh_device_types=ssh_version_matches if ssh_version_matches else None,
                    banner_vendor=banner_vendor,
                    use_ssh_version=True,  # Always enabled for offline data
                    use_banner=True  # Always enabled for offline data
                )
            else:  # filter_logic == 'or'
                patterns = filter_patterns_or(
                    user_vendors=vendors,
                    user_device_types=device_types,
                    user_ansible_os=ansible_network_os,
                    ssh_device_types=ssh_version_matches if ssh_version_matches else None,
                    banner_vendor=banner_vendor,
                    use_ssh_version=True,
                    use_banner=True
                )
            
            if not patterns:
                return DetectionResult(
                    success=False,
                    error="No patterns match the filter criteria",
                    method='offline',
                    ssh_version=ssh_version
                )
            
            # Step 6: Test patterns against collected data
            sorted_patterns = sorted(
                patterns.items(),
                key=lambda x: x[1].get('priority', 0),
                reverse=True
            )
            
            for device_type, pattern in sorted_patterns:
                # Get command and search patterns
                cmd = pattern.get('cmd')
                search_patterns = pattern.get('search_patterns', [])
                
                if not cmd or not search_patterns:
                    continue
                
                # Get command output from collected data
                output = command_outputs.get(cmd, '')
                
                if not output:
                    continue  # Command not in collected data or failed
                
                # Try to match against search patterns
                matches = []
                for search_pattern in search_patterns:
                    if re.search(search_pattern, output, re.IGNORECASE):
                        matches.append(search_pattern)
                
                # If we have matches, return success
                if matches:
                    # Get driver mappings from DEVICE_PATTERNS
                    from .patterns import DEVICE_PATTERNS
                    device_pattern = DEVICE_PATTERNS.get(device_type, {})
                    
                    return DetectionResult(
                        success=True,
                        device_type=device_type,
                        vendor=pattern.get('vendor'),
                        ansible_network_os=pattern.get('ansible_network_os'),
                        scrapli_driver=device_pattern.get('scrapli_driver'),
                        napalm_driver=device_pattern.get('napalm_driver'),
                        nornir_platform=device_pattern.get('nornir_platform'),
                        confidence=0.95,
                        method='offline',
                        matched_pattern=', '.join(matches[:2]),
                        ssh_version=ssh_version
                    )
            
            # No patterns matched
            return DetectionResult(
                success=False,
                error=f"No matching patterns found after testing {len(patterns)} patterns",
                method='offline',
                ssh_version=ssh_version
            )
            
        except ValueError as e:
            return DetectionResult(
                success=False,
                error=str(e),
                method='offline'
            )
        except Exception as e:
            return DetectionResult(
                success=False,
                error=f"Offline detection failed: {e}",
                method='offline'
            )
    
    def disconnect(self) -> None:
        """Explicitly close SSH connection."""
        if self._connection and self._connected:
            try:
                self._connection.disconnect()
            except Exception:
                pass  # Ignore disconnect errors
            finally:
                self._connection = None
                self._connected = False
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit with automatic cleanup."""
        self.disconnect()
        return False  # Don't suppress exceptions
    
    def __repr__(self) -> str:
        """String representation of DeviceDetector."""
        status = "connected" if self._connected else "disconnected"
        return f"DeviceDetector(host='{self.host}', status='{status}')"
