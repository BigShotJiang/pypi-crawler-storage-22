"""
Device Types Registry

This module auto-discovers and loads all device type patterns from vendor subdirectories.
It builds the DEVICE_PATTERNS dictionary dynamically from individual device type modules.
"""

from typing import Dict, Any
from . import cisco, aruba, hp, juniper


def load_device_patterns() -> Dict[str, Dict[str, Any]]:
    """
    Load all device patterns from vendor modules.
    
    This function dynamically builds the DEVICE_PATTERNS dictionary by importing
    patterns from all vendor subdirectories. Each vendor module exports device
    type patterns as module attributes.
    
    Returns:
        Dictionary of {device_type: pattern_dict}
    """
    patterns = {}
    
    # Load Cisco patterns
    for device_type in cisco.__all__:
        pattern = getattr(cisco, device_type)
        patterns[device_type] = pattern
    
    # Load Aruba patterns
    for device_type in aruba.__all__:
        pattern = getattr(aruba, device_type)
        patterns[device_type] = pattern
    
    # Load HP patterns
    for device_type in hp.__all__:
        pattern = getattr(hp, device_type)
        patterns[device_type] = pattern
    
    # Load Juniper patterns
    for device_type in juniper.__all__:
        pattern = getattr(juniper, device_type)
        patterns[device_type] = pattern
    
    return patterns


# Build the DEVICE_PATTERNS dictionary
DEVICE_PATTERNS = load_device_patterns()

# Export for external use
__all__ = ['DEVICE_PATTERNS', 'load_device_patterns']
