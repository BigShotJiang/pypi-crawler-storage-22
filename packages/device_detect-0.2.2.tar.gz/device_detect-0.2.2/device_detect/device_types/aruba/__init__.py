"""Aruba Device Type Patterns"""

from .aruba_procurve import PATTERN as aruba_procurve
from .aruba_aoscx import PATTERN as aruba_aoscx

__all__ = [
    'aruba_procurve',
    'aruba_aoscx',
]
