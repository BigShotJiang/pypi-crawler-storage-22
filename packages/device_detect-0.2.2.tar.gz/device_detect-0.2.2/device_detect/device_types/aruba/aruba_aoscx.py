"""Aruba AOS-CX Device Pattern"""

PATTERN = {
    'vendor': 'aruba',
    'device_type': 'aruba_aoscx',
    'ansible_network_os': 'arubanetworks.aoscx.aoscx',
    'scrapli_driver': 'aruba_aoscx',
    'napalm_driver': None,
    'nornir_platform': 'aoscx',
    'enabled': True,
    'priority': 99,
    
    'ssh': {
        'cmd': 'show version',
        'search_patterns': [r'ArubaOS-CX'],
        'dispatch': '_autodetect_std',
    },
    
    'ssh_version': {
        'search_patterns': [r'Aruba'],  # May use different SSH version than ProCurve
        'priority': 99,
    },
    
    'banner': {
        'search_patterns': [r'Aruba'],
    },
    
    'prompt': None,
    'snmp': None,
}
