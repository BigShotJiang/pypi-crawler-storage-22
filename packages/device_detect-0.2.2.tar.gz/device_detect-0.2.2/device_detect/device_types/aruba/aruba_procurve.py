"""Aruba ProCurve Device Pattern"""

PATTERN = {
    'vendor': 'aruba',
    'device_type': 'aruba_procurve',
    'ansible_network_os': 'arubanetworks.aos_switch.aos_switch',
    'scrapli_driver': None,
    'napalm_driver': None,
    'nornir_platform': 'procurve',
    'enabled': True,
    'priority': 99,
    
    'ssh': {
        'cmd': 'show version',
        'search_patterns': [r'Image stamp.*/code/build', r'ProCurve', r'Software revision'],
        'dispatch': '_autodetect_std',
    },
    
    'ssh_version': {
        'search_patterns': [r'Mocana'],  # Verified from real device: SSH-2.0-Mocana SSH 6.3
        'priority': 99,
    },
    
    'banner': {
        'search_patterns': [r'Aruba', r'ProCurve'],  # Vendor hint for faster detection
    },
    
    'prompt': None,  # Not implemented yet
    'snmp': None,
}
