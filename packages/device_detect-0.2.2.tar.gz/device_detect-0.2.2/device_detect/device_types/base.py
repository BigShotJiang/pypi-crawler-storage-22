"""
Base Pattern Structure and Validation

This module defines the base structure for device type patterns and provides
validation functions to ensure pattern consistency.
"""

from typing import Dict, Any, List, Optional


def validate_pattern(device_type: str, pattern: Dict[str, Any]) -> tuple[bool, Optional[str]]:
    """
    Validate a device pattern structure.
    
    Args:
        device_type: The device type identifier (e.g., 'cisco_ios')
        pattern: The pattern dictionary to validate
        
    Returns:
        Tuple of (is_valid, error_message)
        - is_valid: True if pattern is valid, False otherwise
        - error_message: None if valid, error description if invalid
    """
    # Required top-level fields
    required_fields = ['vendor', 'device_type', 'ansible_network_os', 'enabled', 'priority']
    
    for field in required_fields:
        if field not in pattern:
            return False, f"Missing required field: {field}"
    
    # Validate device_type matches
    if pattern['device_type'] != device_type:
        return False, f"device_type mismatch: expected '{device_type}', got '{pattern['device_type']}'"
    
    # Validate types
    if not isinstance(pattern['vendor'], str):
        return False, "vendor must be a string"
    
    if not isinstance(pattern['enabled'], bool):
        return False, "enabled must be a boolean"
    
    if not isinstance(pattern['priority'], int):
        return False, "priority must be an integer"
    
    # Validate SSH section (if present)
    if pattern.get('ssh'):
        ssh = pattern['ssh']
        if not isinstance(ssh, dict):
            return False, "ssh must be a dictionary"
        
        if 'cmd' not in ssh or 'search_patterns' not in ssh:
            return False, "ssh section must have 'cmd' and 'search_patterns'"
        
        if not isinstance(ssh['search_patterns'], list):
            return False, "ssh.search_patterns must be a list"
    
    return True, None


def get_required_pattern_fields() -> List[str]:
    """
    Get list of required fields for a device pattern.
    
    Returns:
        List of required field names
    """
    return ['vendor', 'device_type', 'ansible_network_os', 'enabled', 'priority']


def get_optional_pattern_fields() -> List[str]:
    """
    Get list of optional fields for a device pattern.
    
    Returns:
        List of optional field names
    """
    return [
        'scrapli_driver',
        'napalm_driver',
        'nornir_platform',
        'ssh',
        'ssh_version',
        'banner',
        'prompt',
        'snmp',
        'notes'
    ]
