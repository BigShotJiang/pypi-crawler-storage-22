"""Cisco Device Type Patterns"""

from .cisco_ios import PATTERN as cisco_ios
from .cisco_xe import PATTERN as cisco_xe
from .cisco_nxos import PATTERN as cisco_nxos
from .cisco_xr import PATTERN as cisco_xr
from .cisco_wlc import PATTERN as cisco_wlc

__all__ = [
    'cisco_ios',
    'cisco_xe',
    'cisco_nxos',
    'cisco_xr',
    'cisco_wlc',
]
