"""Cisco IOS Device Pattern"""

PATTERN = {
    'vendor': 'cisco',
    'device_type': 'cisco_ios',
    'ansible_network_os': 'cisco.ios.ios',
    'scrapli_driver': 'cisco_iosxe',
    'napalm_driver': 'ios',
    'nornir_platform': 'ios',
    'enabled': True,
    'priority': 95,  # Lower priority to avoid conflicts with cisco_xe
    
    'ssh': {
        'cmd': 'show version',
        'search_patterns': [
            'Cisco IOS Software',
            'Cisco Internetwork Operating System Software',
        ],
        'dispatch': '_autodetect_std',
    },
    
    'ssh_version': {
        'search_patterns': [r'Cisco'],  # Verified from real device: SSH-2.0-Cisco-1.25
        'priority': 95,
    },
    
    'banner': None,  # Cisco doesn't use banner detection
    'prompt': None,  # Not implemented yet
    'snmp': None,    # Future implementation
}
