"""Cisco NX-OS Device Pattern"""

PATTERN = {
    'vendor': 'cisco',
    'device_type': 'cisco_nxos',
    'ansible_network_os': 'cisco.nxos.nxos',
    'scrapli_driver': 'cisco_nxos',
    'napalm_driver': 'nxos',
    'nornir_platform': 'nxos',
    'enabled': True,
    'priority': 99,
    
    'ssh': {
        'cmd': 'show version',
        'search_patterns': [r'Cisco Nexus Operating System', r'NX-OS'],
        'dispatch': '_autodetect_std',
    },
    
    'ssh_version': {
        'search_patterns': [r'Cisco'],  # Same SSH version pattern as cisco_ios
        'priority': 99,
    },
    
    'banner': None,
    'prompt': None,
    'snmp': None,
}
