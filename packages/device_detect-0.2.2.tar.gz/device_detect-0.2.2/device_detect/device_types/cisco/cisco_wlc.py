"""Cisco Wireless LAN Controller Device Pattern"""

PATTERN = {
    'vendor': 'cisco',
    'device_type': 'cisco_wlc',
    'ansible_network_os': 'cisco.wlc.wlc',
    'scrapli_driver': None,
    'napalm_driver': None,
    'nornir_platform': None,
    'enabled': True,
    'priority': 99,
    
    'ssh': {
        'cmd': 'show version',
        'search_patterns': [r'CISCO_WLC', r'Cisco.*Wireless.*Controller'],
        'dispatch': '_autodetect_std',
    },
    
    'ssh_version': {
        'search_patterns': [r'Cisco'],  # Same SSH version pattern as cisco_ios
        'priority': 99,
    },
    
    'banner': None,
    'prompt': None,
    'snmp': None,
}
