"""Cisco IOS XE Device Pattern"""

PATTERN = {
    'vendor': 'cisco',
    'device_type': 'cisco_xe',
    'ansible_network_os': 'cisco.ios.ios',
    'scrapli_driver': 'cisco_iosxe',
    'napalm_driver': 'ios',
    'nornir_platform': 'ios',
    'enabled': True,
    'priority': 99,  # Higher than cisco_ios to detect XE before IOS
    
    'ssh': {
        'cmd': 'show version',
        'search_patterns': [r'Cisco IOS XE Software'],  # From Netmiko
        'dispatch': '_autodetect_std',
    },
    
    'ssh_version': {
        'search_patterns': [r'Cisco'],  # Same SSH version pattern as other Cisco devices
        'priority': 99,
    },
    
    'banner': None,
    'prompt': None,
    'snmp': None,
}
