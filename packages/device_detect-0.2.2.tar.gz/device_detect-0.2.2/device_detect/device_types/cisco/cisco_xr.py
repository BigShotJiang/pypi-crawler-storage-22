"""Cisco IOS XR Device Pattern"""

PATTERN = {
    'vendor': 'cisco',
    'device_type': 'cisco_xr',
    'ansible_network_os': 'cisco.iosxr.iosxr',
    'scrapli_driver': 'cisco_iosxr',
    'napalm_driver': 'iosxr',
    'nornir_platform': 'iosxr',
    'enabled': True,
    'priority': 99,
    
    'ssh': {
        'cmd': 'show version',
        'search_patterns': [r'Cisco IOS XR'],
        'dispatch': '_autodetect_std',
    },
    
    'ssh_version': {
        'search_patterns': [r'Cisco'],  # Same SSH version pattern as cisco_ios
        'priority': 99,
    },
    
    'banner': None,
    'prompt': None,
    'snmp': None,
}
