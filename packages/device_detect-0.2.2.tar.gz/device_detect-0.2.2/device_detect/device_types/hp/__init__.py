"""HP Device Type Patterns"""

from .hp_procurve import PATTERN as hp_procurve
from .hp_comware import PATTERN as hp_comware

__all__ = [
    'hp_procurve',
    'hp_comware',
]
