"""HP Comware Device Pattern"""

PATTERN = {
    'vendor': 'hp',
    'device_type': 'hp_comware',
    'ansible_network_os': 'hpe.comware.comware',
    'scrapli_driver': None,
    'napalm_driver': None,
    'nornir_platform': 'comware',
    'enabled': True,
    'priority': 99,
    
    'ssh': {
        'cmd': 'display version',
        'search_patterns': ['HPE Comware', 'HP Comware'],
        'dispatch': '_autodetect_std',
    },
    
    'banner': {
        'search_patterns': [r'HPE', r'HP\s'],
    },
    
    'prompt': None,
    'snmp': None,
}
