"""HP ProCurve Device Pattern"""

PATTERN = {
    'vendor': 'hp',
    'device_type': 'hp_procurve',
    'ansible_network_os': 'hpe.procurve.procurve',
    'scrapli_driver': None,
    'napalm_driver': None,
    'nornir_platform': 'procurve',
    'enabled': True,
    'priority': 99,
    
    'ssh': {
        'cmd': 'show version',
        'search_patterns': [r'Image stamp.*/code/build'],
        'dispatch': '_autodetect_std',
    },
    
    'banner': {
        'search_patterns': [r'HPE', r'HP\s', r'Hewlett Packard'],
    },
    
    'prompt': None,
    'snmp': None,
    'notes': 'Shared with aruba_procurve - same Netmiko class HPProcurveSSH',
}
