"""Juniper Device Type Patterns"""

from .juniper_junos import PATTERN as juniper_junos

__all__ = [
    'juniper_junos',
]
