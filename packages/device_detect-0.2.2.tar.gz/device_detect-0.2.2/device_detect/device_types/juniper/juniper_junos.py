"""Juniper Junos Device Pattern"""

PATTERN = {
    'vendor': 'juniper',
    'device_type': 'juniper_junos',
    'ansible_network_os': 'junipernetworks.junos.junos',
    'scrapli_driver': 'juniper_junos',
    'napalm_driver': 'junos',
    'nornir_platform': 'junos',
    'enabled': True,
    'priority': 99,
    
    'ssh': {
        'cmd': 'show version',
        'search_patterns': [r'JUNOS'],
        'dispatch': '_autodetect_std',
    },
    
    'banner': None,
    'prompt': None,
    'snmp': None,
}
