"""
Custom exceptions for device-detect package

This module defines all custom exceptions used throughout the package
for handling various error conditions during device detection and verification.
"""


class DeviceDetectException(Exception):
    """Base exception for all device detection errors."""
    pass


class ConnectionError(DeviceDetectException):
    """
    SSH connection failed.
    
    Raised when unable to establish SSH connection to the device.
    Common causes:
    - Device is offline or unreachable
    - Network connectivity issues
    - Firewall blocking connection
    - Incorrect IP address or hostname
    """
    pass


class AuthenticationError(DeviceDetectException):
    """
    SSH authentication failed.
    
    Raised when SSH authentication fails.
    Common causes:
    - Incorrect username or password
    - SSH key authentication failed
    - Account locked or disabled
    - Authentication method not supported
    """
    pass


class TimeoutError(DeviceDetectException):
    """
    Operation timed out.
    
    Raised when an operation exceeds the configured timeout.
    Common causes:
    - Device is slow to respond
    - Network latency issues
    - Command execution taking too long
    - Timeout value set too low
    """
    pass


class PatternNotFoundError(DeviceDetectException):
    """
    Pattern for device type not found.
    
    Raised when attempting to use a device type pattern that doesn't exist.
    Common causes:
    - Invalid device_type specified
    - Pattern not loaded or registered
    - Typo in device_type name
    """
    pass


class DetectionError(DeviceDetectException):
    """
    Device detection failed.
    
    Raised when device detection process fails for any reason.
    Common causes:
    - No patterns matched the device output
    - Device output is malformed or unexpected
    - All detection techniques failed
    - Pattern matching errors
    """
    pass
