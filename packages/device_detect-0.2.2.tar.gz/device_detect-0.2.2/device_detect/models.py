"""
Data models for device-detect package

This module defines the data structures used throughout the package,
primarily the DetectionResult dataclass that represents the outcome
of device detection and verification operations.
"""

from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Optional
import json


@dataclass
class DetectionResult:
    """
    Immutable result object returned by detection and verification operations.
    
    This dataclass encapsulates all information about a device detection
    or verification attempt, including success status, detected device type,
    confidence level, and any errors encountered.
    
    Attributes:
        success: Whether the detection/verification succeeded
        device_type: Detected device type (e.g., 'cisco_ios', 'aruba_procurve')
                    Note: device_type is also the Netmiko driver identifier
        vendor: Detected vendor name (e.g., 'cisco', 'aruba', 'hp')
        ansible_network_os: Ansible network OS identifier for automation
        scrapli_driver: Scrapli driver identifier (e.g., 'cisco_iosxe', 'juniper_junos')
        napalm_driver: NAPALM driver identifier (e.g., 'ios', 'junos')
        nornir_platform: Nornir platform identifier (e.g., 'ios', 'nxos')
        confidence: Confidence score from 0.0 to 1.0
        method: Detection method used ('banner', 'prompt', 'command')
        matched_pattern: The specific pattern that matched
        error: Error message if detection/verification failed
        timestamp: When the detection/verification occurred
    
    Example:
        >>> result = DetectionResult(
        ...     success=True,
        ...     device_type='cisco_ios',
        ...     vendor='cisco',
        ...     ansible_network_os='cisco.ios.ios',
        ...     scrapli_driver='cisco_iosxe',
        ...     napalm_driver='ios',
        ...     nornir_platform='ios',
        ...     confidence=0.92,
        ...     method='command',
        ...     matched_pattern='Cisco IOS Software',
        ...     error=None,
        ...     timestamp=datetime.now()
        ... )
        >>> print(result.to_json())
        >>> print(result.confidence)
        0.92
    """
    
    success: bool
    device_type: Optional[str] = None
    vendor: Optional[str] = None
    ansible_network_os: Optional[str] = None
    scrapli_driver: Optional[str] = None
    napalm_driver: Optional[str] = None
    nornir_platform: Optional[str] = None
    confidence: float = 0.0
    method: str = 'unknown'
    matched_pattern: Optional[str] = None
    ssh_version: Optional[str] = None
    error: Optional[str] = None
    timestamp: datetime = None
    
    def __post_init__(self):
        """Set timestamp to current time if not provided."""
        if self.timestamp is None:
            self.timestamp = datetime.now()
    
    def to_dict(self) -> dict:
        """
        Convert DetectionResult to dictionary.
        
        Returns:
            Dictionary representation of the detection result
            
        Example:
            >>> result = DetectionResult(success=True, device_type='cisco_ios', ...)
            >>> data = result.to_dict()
            >>> print(data['device_type'])
            'cisco_ios'
        """
        data = asdict(self)
        # Convert timestamp to ISO format string for JSON serialization
        if self.timestamp:
            data['timestamp'] = self.timestamp.isoformat()
        return data
    
    def to_json(self, indent: int = 2) -> str:
        """
        Serialize DetectionResult to JSON string.
        
        Args:
            indent: Number of spaces for JSON indentation (default: 2)
            
        Returns:
            JSON string representation of the detection result
            
        Example:
            >>> result = DetectionResult(success=True, device_type='cisco_ios', ...)
            >>> json_str = result.to_json()
            >>> print(json_str)
            {
              "success": true,
              "device_type": "cisco_ios",
              ...
            }
        """
        return json.dumps(self.to_dict(), indent=indent)
    
    def __str__(self) -> str:
        """
        String representation of DetectionResult.
        
        Returns:
            Human-readable string summarizing the detection result
        """
        if self.success:
            return (f"DetectionResult(success=True, device_type='{self.device_type}', "
                   f"vendor='{self.vendor}', confidence={self.confidence:.2f})")
        else:
            return f"DetectionResult(success=False, error='{self.error}')"
    
    def __repr__(self) -> str:
        """Detailed representation of DetectionResult."""
        return (f"DetectionResult(success={self.success}, "
               f"device_type={self.device_type!r}, "
               f"vendor={self.vendor!r}, "
               f"ansible_network_os={self.ansible_network_os!r}, "
               f"confidence={self.confidence}, "
               f"method={self.method!r}, "
               f"matched_pattern={self.matched_pattern!r}, "
               f"error={self.error!r}, "
               f"timestamp={self.timestamp!r})")
