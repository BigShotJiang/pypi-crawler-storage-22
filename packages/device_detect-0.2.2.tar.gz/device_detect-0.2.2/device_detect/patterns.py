"""
Device Detection Patterns

This module provides access to device detection patterns loaded from the modular
device_types structure. All patterns are now organized by vendor in separate files.

For modular pattern structure, see: device_types/
For pattern validation, see: device_types/base.py
"""

from typing import Dict, Any, List, Optional, Union
from .device_types import DEVICE_PATTERNS


# =============================================================================
# BACKWARD COMPATIBILITY - SSH_DETECTION_PATTERNS
# =============================================================================

# For backward compatibility, create SSH_DETECTION_PATTERNS from DEVICE_PATTERNS
SSH_DETECTION_PATTERNS = {}
for device_type, pattern in DEVICE_PATTERNS.items():
    # Flatten ssh section into root level for backward compatibility
    ssh_pattern = {
        'vendor': pattern['vendor'],
        'device_type': pattern['device_type'],
        'ansible_network_os': pattern['ansible_network_os'],
        'enabled': pattern['enabled'],
        'priority': pattern['priority'],
    }
    
    # Add SSH fields
    if pattern.get('ssh'):
        ssh_pattern.update(pattern['ssh'])
    
    # Add notes if present
    if 'notes' in pattern:
        ssh_pattern['notes'] = pattern['notes']
    
    SSH_DETECTION_PATTERNS[device_type] = ssh_pattern


# =============================================================================
# BANNER VENDOR DETECTION PATTERNS
# =============================================================================

# Extract banner patterns from DEVICE_PATTERNS
BANNER_VENDOR_PATTERNS = {}
for device_type, pattern in DEVICE_PATTERNS.items():
    if pattern.get('banner') and pattern['banner'] is not None:
        vendor = pattern['vendor']
        if vendor not in BANNER_VENDOR_PATTERNS:
            BANNER_VENDOR_PATTERNS[vendor] = []
        
        # Add banner patterns for this vendor (avoid duplicates)
        for search_pattern in pattern['banner']['search_patterns']:
            if search_pattern not in BANNER_VENDOR_PATTERNS[vendor]:
                BANNER_VENDOR_PATTERNS[vendor].append(search_pattern)


# =============================================================================
# VENDOR GROUPINGS
# =============================================================================

# Build VENDORS dictionary dynamically from DEVICE_PATTERNS
VENDORS = {}
for device_type, pattern in DEVICE_PATTERNS.items():
    vendor = pattern['vendor']
    if vendor not in VENDORS:
        VENDORS[vendor] = []
    VENDORS[vendor].append(device_type)


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def get_patterns_by_vendor(vendor: str) -> Dict[str, Dict[str, Any]]:
    """
    Get all device type patterns for a specific vendor.
    
    Args:
        vendor: Vendor name (e.g., 'cisco', 'aruba', 'hp')
        
    Returns:
        Dictionary of patterns for the specified vendor
    """
    return {k: v for k, v in DEVICE_PATTERNS.items() if v['vendor'] == vendor}


def get_patterns_by_priority(min_priority: int = 95) -> Dict[str, Dict[str, Any]]:
    """
    Get patterns with priority >= min_priority.
    
    Args:
        min_priority: Minimum priority threshold (default: 95)
        
    Returns:
        Dictionary of patterns meeting the priority threshold
    """
    return {k: v for k, v in DEVICE_PATTERNS.items() 
            if v.get('priority', 0) >= min_priority}


def get_auto_detectable_patterns() -> Dict[str, Dict[str, Any]]:
    """
    Get only patterns that have auto-detection support.
    
    Returns:
        Dictionary of patterns with 'dispatch' attribute in ssh section
    """
    return {k: v for k, v in DEVICE_PATTERNS.items() 
            if v.get('ssh') and 'dispatch' in v['ssh']}


def get_detection_order() -> List[tuple]:
    """
    Returns device types ordered by priority (highest first).
    
    Returns:
        List of (device_type, pattern) tuples sorted by priority
    """
    return sorted(
        SSH_DETECTION_PATTERNS.items(),
        key=lambda x: x[1].get('priority', 0),
        reverse=True
    )


def normalize_to_list(value: Union[None, str, List]) -> List:
    """
    Normalize input to list format.
    
    Args:
        value: String or list input
        
    Returns:
        List representation of the input
    """
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return value
    return list(value)


def filter_patterns(
    vendors: Optional[Union[str, List[str]]] = None,
    device_types: Optional[Union[str, List[str]]] = None,
    ansible_network_os: Optional[Union[str, List[str]]] = None
) -> Dict[str, Dict[str, Any]]:
    """
    Filter patterns based on input criteria.
    
    Logic:
    1. If no criteria: return all enabled patterns
    2. If any criteria: return patterns matching ANY criteria (OR logic)
    3. Override: if disabled pattern explicitly mentioned, include it
    
    Args:
        vendors: Vendor name(s) to filter by (string or list)
        device_types: Device type(s) to filter by (string or list)
        ansible_network_os: Ansible network OS(es) to filter by (string or list)
        
    Returns:
        Dictionary of filtered patterns (SSH format for backward compatibility)
    """
    if not any([vendors, device_types, ansible_network_os]):
        # No filtering, return all enabled patterns
        return {k: v for k, v in SSH_DETECTION_PATTERNS.items() if v.get('enabled', True)}
    
    # Normalize inputs to lists
    vendors = normalize_to_list(vendors)
    device_types = normalize_to_list(device_types)
    ansible_network_os = normalize_to_list(ansible_network_os)
    
    filtered = {}
    for dt, pattern in SSH_DETECTION_PATTERNS.items():
        # Check if pattern matches any criteria
        matches = False
        explicitly_mentioned = False
        
        if device_types and dt in device_types:
            matches = True
            explicitly_mentioned = True
            
        if vendors and pattern.get('vendor') in vendors:
            matches = True
            
        if ansible_network_os and pattern.get('ansible_network_os') in ansible_network_os:
            matches = True
        
        # Include if matches and (enabled OR explicitly mentioned)
        if matches and (pattern.get('enabled', True) or explicitly_mentioned):
            filtered[dt] = pattern
    
    return filtered


def get_ssh_version_patterns() -> Dict[str, Dict[str, Any]]:
    """
    Extract SSH version detection patterns from DEVICE_PATTERNS.
    
    Returns:
        Dict of {device_type: ssh_version_config} for devices with SSH version detection
    """
    return {
        device_type: pattern['ssh_version']
        for device_type, pattern in DEVICE_PATTERNS.items()
        if pattern.get('ssh_version')
    }


def get_ssh_version_detection_order() -> List[tuple]:
    """
    Returns device types ordered by SSH version priority (highest first).
    
    Returns:
        List of (device_type, ssh_version_pattern) tuples sorted by priority
    """
    ssh_patterns = get_ssh_version_patterns()
    return sorted(
        ssh_patterns.items(),
        key=lambda x: x[1].get('priority', 0),
        reverse=True
    )


def filter_patterns_and(
    user_vendors: Optional[Union[str, List[str]]] = None,
    user_device_types: Optional[Union[str, List[str]]] = None,
    user_ansible_os: Optional[Union[str, List[str]]] = None,
    ssh_device_types: Optional[List[str]] = None,
    banner_vendor: Optional[str] = None,
    use_ssh_version: bool = True,
    use_banner: bool = True
) -> Dict[str, Dict[str, Any]]:
    """
    Filter patterns using AND logic (intersection).
    
    This function applies intersection/AND logic across all active constraints:
    - User-specified filters (vendors, device_types, ansible_network_os)
    - Auto-detected SSH version device_types (only if use_ssh_version=True AND detected)
    - Auto-detected banner vendor (only if use_banner=True AND detected)
    
    Only constraints that are both enabled and have values are applied.
    
    Args:
        user_vendors: User-specified vendor name(s) to filter by (string or list)
        user_device_types: User-specified device type(s) to filter by (string or list)
        user_ansible_os: User-specified Ansible network OS(es) to filter by (string or list)
        ssh_device_types: Auto-detected device types from SSH version (list or None)
        banner_vendor: Auto-detected vendor from banner (string or None)
        use_ssh_version: Whether SSH version detection is enabled (default: True)
        use_banner: Whether banner detection is enabled (default: True)
        
    Returns:
        Dictionary of filtered patterns matching ALL active constraints
        
    Example:
        >>> # User specifies cisco, SSH detects ['cisco_ios', 'cisco_xe']
        >>> patterns = filter_patterns_and(
        ...     user_vendors='cisco',
        ...     ssh_device_types=['cisco_ios', 'cisco_xe'],
        ...     use_ssh_version=True
        ... )
        >>> # Returns only cisco_ios and cisco_xe (intersection)
    """
    # Start with all enabled patterns
    candidates = {k: v for k, v in SSH_DETECTION_PATTERNS.items() if v.get('enabled', True)}
    
    # Apply user device_types filter (if specified)
    if user_device_types:
        dt_list = normalize_to_list(user_device_types)
        candidates = {k: v for k, v in candidates.items() if k in dt_list}
    
    # Apply user vendors filter (if specified)
    if user_vendors:
        v_list = normalize_to_list(user_vendors)
        candidates = {k: v for k, v in candidates.items() if v.get('vendor') in v_list}
    
    # Apply user ansible_network_os filter (if specified)
    if user_ansible_os:
        os_list = normalize_to_list(user_ansible_os)
        candidates = {k: v for k, v in candidates.items() 
                     if v.get('ansible_network_os') in os_list}
    
    # Apply SSH version constraint (only if enabled AND detected)
    if use_ssh_version and ssh_device_types:
        candidates = {k: v for k, v in candidates.items() if k in ssh_device_types}
    
    # Apply banner vendor constraint (only if enabled AND detected)
    if use_banner and banner_vendor:
        candidates = {k: v for k, v in candidates.items() 
                     if v.get('vendor') == banner_vendor}
    
    return candidates


def filter_patterns_or(
    user_vendors: Optional[Union[str, List[str]]] = None,
    user_device_types: Optional[Union[str, List[str]]] = None,
    user_ansible_os: Optional[Union[str, List[str]]] = None,
    ssh_device_types: Optional[List[str]] = None,
    banner_vendor: Optional[str] = None,
    use_ssh_version: bool = True,
    use_banner: bool = True
) -> Dict[str, Dict[str, Any]]:
    """
    Filter patterns using OR logic (union with replacement).
    
    This is the legacy behavior where auto-detected hints replace user inputs:
    - SSH version device_types replace user device_types (if SSH detected and user didn't specify)
    - Banner vendor replaces user vendor (if banner detected and user didn't specify vendor/device_types)
    
    Then uses filter_patterns() to apply OR logic across remaining criteria.
    
    Args:
        user_vendors: User-specified vendor name(s) to filter by (string or list)
        user_device_types: User-specified device type(s) to filter by (string or list)
        user_ansible_os: User-specified Ansible network OS(es) to filter by (string or list)
        ssh_device_types: Auto-detected device types from SSH version (list or None)
        banner_vendor: Auto-detected vendor from banner (string or None)
        use_ssh_version: Whether SSH version detection is enabled (default: True)
        use_banner: Whether banner detection is enabled (default: True)
        
    Returns:
        Dictionary of filtered patterns using OR logic
        
    Example:
        >>> # No user input, SSH detects ['cisco_ios', 'cisco_xe']
        >>> patterns = filter_patterns_or(
        ...     ssh_device_types=['cisco_ios', 'cisco_xe'],
        ...     use_ssh_version=True
        ... )
        >>> # Returns cisco_ios and cisco_xe (replacement logic)
    """
    # Apply replacement logic (current/legacy behavior)
    vendors = user_vendors
    device_types = user_device_types
    ansible_os = user_ansible_os
    
    # SSH version replaces device_types if detected and user didn't specify
    if use_ssh_version and ssh_device_types and not device_types:
        device_types = ssh_device_types
    
    # Banner replaces vendor if detected and user didn't specify vendor/device_types
    if use_banner and banner_vendor and not device_types and not vendors:
        vendors = banner_vendor
    
    # Use existing filter_patterns() function for OR logic
    return filter_patterns(
        vendors=vendors,
        device_types=device_types,
        ansible_network_os=ansible_os
    )


def print_pattern_summary() -> None:
    """Print a summary of all patterns."""
    print(f"\n{'='*80}")
    print(f"DEVICE DETECTION PATTERNS SUMMARY")
    print(f"{'='*80}")
    print(f"\nTotal Patterns: {len(DEVICE_PATTERNS)}")
    
    # Count by vendor
    vendor_counts = {}
    for pattern in DEVICE_PATTERNS.values():
        vendor = pattern.get('vendor', 'unknown')
        vendor_counts[vendor] = vendor_counts.get(vendor, 0) + 1
    
    for vendor, count in sorted(vendor_counts.items()):
        print(f"  - {vendor.capitalize()}: {count}")
    
    # Detection methods
    ssh_count = sum(1 for p in DEVICE_PATTERNS.values() if p.get('ssh'))
    banner_count = sum(1 for p in DEVICE_PATTERNS.values() if p.get('banner'))
    prompt_count = sum(1 for p in DEVICE_PATTERNS.values() if p.get('prompt'))
    snmp_count = sum(1 for p in DEVICE_PATTERNS.values() if p.get('snmp'))
    
    print(f"\nDetection Methods:")
    print(f"  - SSH: {ssh_count}")
    print(f"  - Banner: {banner_count}")
    print(f"  - Prompt: {prompt_count}")
    print(f"  - SNMP: {snmp_count}")
    
    auto_detectable = len(get_auto_detectable_patterns())
    print(f"\nAuto-detectable: {auto_detectable}")
    print(f"{'='*80}\n")


# =============================================================================
# MODULE INITIALIZATION
# =============================================================================

if __name__ == '__main__':
    # Print summary when module is run directly
    print_pattern_summary()
    
    # Show detection order
    print("\nDetection Order (by priority):")
    print("-" * 80)
    for device_type, pattern in get_detection_order():
        print(f"{pattern['priority']:3d} | {device_type:20s} | {pattern['vendor']}")
    
    # Show banner patterns
    print("\nBanner Vendor Patterns:")
    print("-" * 80)
    for vendor, patterns in BANNER_VENDOR_PATTERNS.items():
        print(f"{vendor}: {patterns}")
