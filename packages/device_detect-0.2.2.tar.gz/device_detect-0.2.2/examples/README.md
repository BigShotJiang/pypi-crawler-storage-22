# Device-Detect Examples

This directory contains example scripts demonstrating the use of the `device-detect` library.

## 🔒 Security Best Practices

**⚠️ NEVER hardcode credentials in your code!**

Always use one of these secure methods:

### 1. Environment Variables (Recommended)
```bash
# Windows PowerShell
$env:DEVICE_HOST="192.168.1.1"
$env:DEVICE_USER="admin"
$env:DEVICE_PASSWORD="your_password"

# Linux/macOS bash
export DEVICE_HOST="192.168.1.1"
export DEVICE_USER="admin"
export DEVICE_PASSWORD="your_password"
```

### 2. Credential Management Systems
- HashiCorp Vault
- AWS Secrets Manager
- Azure Key Vault
- CyberArk

### 3. Interactive Prompts
```python
import getpass
username = input("Username: ")
password = getpass.getpass("Password: ")
```

---

## 📝 Available Examples

### basic_example.py
**Basic device detection with SSH connection**

Demonstrates:
- Reading credentials from environment variables
- Establishing SSH connection
- Performing device detection
- Displaying results with driver mappings

Usage:
```bash
# Set credentials
export DEVICE_HOST="192.168.1.1"
export DEVICE_USER="admin"
export DEVICE_PASSWORD="secret"

# Run example
python examples/basic_example.py
```

---

### offline_example.py
**Offline device detection from collected data**

Demonstrates:
- Loading pre-collected device data
- Performing offline detection
- Analyzing results without live device access
- JSON output formatting

Usage:
```bash
# First, collect data from a device
device-detect --host 192.168.1.1 --user admin --password secret \
              --collect --output device_data.json

# Then analyze offline
python examples/offline_example.py device_data.json
```

**Benefits of Offline Detection:**
- Test without device access
- Analyze historical data
- Batch processing
- CI/CD integration
- No credential exposure

---

## 🚀 Quick Start

### Installation
```bash
pip install device-detect
```

### Minimal Example
```python
from device_detect import DeviceDetector

with DeviceDetector(host="192.168.1.1", 
                    username="admin", 
                    password="secret") as detector:
    result = detector.ssh_detect()
    if result.success:
        print(f"Device: {result.device_type}")
        print(f"Vendor: {result.vendor}")
```

---

## 📚 Additional Resources

- **Documentation:** https://github.com/mdrbh/device-detect
- **PyPI:** https://pypi.org/project/device-detect/
- **Issues:** https://github.com/mdrbh/device-detect/issues

---

## ⚙️ Supported Device Types

| Vendor | Device Type | Netmiko | Ansible | Scrapli | NAPALM | Nornir |
|--------|-------------|---------|---------|---------|--------|--------|
| Cisco  | cisco_ios   | ✅ | cisco.ios.ios | cisco_iosxe | ios | ios |
| Cisco  | cisco_xe    | ✅ | cisco.ios.ios | cisco_iosxe | ios | ios |
| Cisco  | cisco_nxos  | ✅ | cisco.nxos.nxos | cisco_nxos | nxos_ssh | nxos |
| Cisco  | cisco_xr    | ✅ | cisco.iosxr.iosxr | cisco_iosxr | iosxr | iosxr |
| Cisco  | cisco_wlc   | ✅ | cisco.ios.ios | - | - | - |
| Aruba  | aruba_procurve | ✅ | arubanetworks.aos_switch.arubaoss | aruba_procurve | - | procurve |
| Aruba  | aruba_aoscx | ✅ | arubanetworks.aoscx.aoscx | aruba_aoscx | - | aoscx |
| HP     | hp_procurve | ✅ | - | hp_procurve | - | procurve |
| HP     | hp_comware  | ✅ | - | hp_comware | - | comware |
| Juniper| juniper_junos | ✅ | junipernetworks.junos.junos | juniper_junos | junos | junos |

---

## 🔍 Detection Methods

The library uses multiple detection methods in priority order:

1. **SSH Version String** - Fastest, most accurate
2. **Banner Detection** - Pre-login information
3. **Command Output Parsing** - Pattern matching on device responses

All methods work with vendor filtering and offline detection.

---

## 💡 Tips

1. **Use Vendor Filtering** - Speed up detection by limiting scope:
   ```python
   result = detector.ssh_detect(vendors='cisco')
   ```

2. **Offline Testing** - Test your detection logic without devices:
   ```python
   result = DeviceDetector.detect_offline('test_data.json')
   ```

3. **Multi-Host Detection** - Process multiple devices concurrently:
   ```bash
   device-detect --host 10.0.0.1 --host 10.0.0.2 --user admin --password secret
   ```

4. **Driver-Only Output** - Get just the driver name for automation:
   ```bash
   device-detect --host 10.0.0.1 --user admin --password secret \
                 --show-driver scrapli --driver-only
   ```

---

## 📄 License

MIT License - See LICENSE file for details
