"""
Basic Device Detection Example

This example demonstrates basic device detection using the device-detect library.

SECURITY WARNING:
================
Never hardcode credentials in production code! Always use one of these methods:
1. Environment variables (recommended for scripts)
2. Secure credential management systems (recommended for production)
3. Interactive prompts (for manual operations)

For testing, you can set environment variables:
    Windows (PowerShell): $env:DEVICE_HOST="192.0.2.1"; $env:DEVICE_USER="admin"; $env:DEVICE_PASSWORD="secret"
    Linux/macOS (bash):   export DEVICE_HOST=192.0.2.1 DEVICE_USER=admin DEVICE_PASSWORD=secret
"""

import os
import sys
from device_detect import DeviceDetector


def main():
    """Basic device detection example using environment variables."""
    
    # Get connection details from environment variables
    # Using RFC 5737 TEST-NET-1 address as default (not routable)
    host = os.getenv('DEVICE_HOST', '192.0.2.1')
    username = os.getenv('DEVICE_USER')
    password = os.getenv('DEVICE_PASSWORD')
    
    # Validate credentials are provided
    if not username or not password:
        print("Error: Credentials not provided!")
        print("Please set environment variables:")
        print("  - DEVICE_HOST (device IP address)")
        print("  - DEVICE_USER (SSH username)")
        print("  - DEVICE_PASSWORD (SSH password)")
        print("\nExample (Windows PowerShell):")
        print('  $env:DEVICE_HOST="192.168.1.1"')
        print('  $env:DEVICE_USER="admin"')
        print('  $env:DEVICE_PASSWORD="your_password"')
        sys.exit(1)
    
    print(f"Connecting to {host}...")
    print("-" * 50)
    
    try:
        # Create detector with context manager for automatic cleanup
        with DeviceDetector(
            host=host,
            username=username,
            password=password,
            timeout=60
        ) as detector:
            
            # Perform detection
            result = detector.ssh_detect()
            
            # Display results
            if result.success:
                print("✓ Device Detection Successful!")
                print(f"  Device Type:  {result.device_type}")
                print(f"  Vendor:       {result.vendor}")
                print(f"  Confidence:   {result.confidence:.0%}")
                print(f"  Ansible OS:   {result.ansible_network_os}")
                
                # Show framework driver mappings
                if result.scrapli_driver:
                    print(f"  Scrapli:      {result.scrapli_driver}")
                if result.napalm_driver:
                    print(f"  NAPALM:       {result.napalm_driver}")
                if result.nornir_platform:
                    print(f"  Nornir:       {result.nornir_platform}")
                
                if result.ssh_version:
                    print(f"  SSH Version:  {result.ssh_version}")
                print(f"  Method:       {result.method}")
            else:
                print("✗ Device Detection Failed")
                print(f"  Error: {result.error}")
                sys.exit(1)
    
    except KeyboardInterrupt:
        print("\n\nOperation cancelled by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
