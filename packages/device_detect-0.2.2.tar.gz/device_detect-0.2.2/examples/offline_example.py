"""
Offline Device Detection Example

This example demonstrates offline detection by analyzing pre-collected device data.
This is useful for:
- Analyzing historical data
- Testing detection logic without live devices
- Batch processing of device information
- CI/CD testing

To collect data for offline analysis, use:
    device-detect --host <IP> --user <USER> --password <PASS> --collect --output device_data.json
"""

import sys
import json
from pathlib import Path
from device_detect import DeviceDetector


def main():
    """Perform offline device detection from collected data file."""
    
    # Check if data file was provided
    if len(sys.argv) < 2:
        print("Usage: python offline_example.py <device_data.json>")
        print("\nTo collect device data:")
        print("  device-detect --host <IP> --user <USER> --password <PASS> \\")
        print("                --collect --output device_data.json")
        print("\nExample data files can be collected from any device.")
        sys.exit(1)
    
    data_file = Path(sys.argv[1])
    
    # Validate file exists
    if not data_file.exists():
        print(f"Error: File not found: {data_file}")
        sys.exit(1)
    
    print(f"Analyzing device data from: {data_file}")
    print("-" * 50)
    
    try:
        # Perform offline detection
        # Can provide a file path, Path object, dict, or JSON string
        result = DeviceDetector.detect_offline(data_file)
        
        # Display results
        if result.success:
            print("✓ Device Detection Successful!")
            print(f"  Device Type:      {result.device_type}")
            print(f"  Vendor:           {result.vendor}")
            print(f"  Confidence:       {result.confidence:.0%}")
            print(f"  Ansible Network:  {result.ansible_network_os}")
            
            # Show framework driver mappings (new in v0.1.9)
            print("\n  Framework Drivers:")
            print(f"    Netmiko:        {result.device_type}")
            if result.scrapli_driver:
                print(f"    Scrapli:        {result.scrapli_driver}")
            if result.napalm_driver:
                print(f"    NAPALM:         {result.napalm_driver}")
            if result.nornir_platform:
                print(f"    Nornir:         {result.nornir_platform}")
            
            # Additional details
            if result.ssh_version:
                print(f"\n  SSH Version:      {result.ssh_version}")
            print(f"  Detection Method: {result.method}")
            print(f"  Timestamp:        {result.timestamp}")
            
            # Show JSON representation
            print("\n" + "-" * 50)
            print("JSON Output:")
            print(json.dumps(result.to_dict(), indent=2))
            
        else:
            print("✗ Device Detection Failed")
            print(f"  Error: {result.error}")
            print("\nTroubleshooting:")
            print("  - Ensure the data file contains valid device output")
            print("  - Check that commands like 'show version' were executed")
            print("  - Verify the device type is supported")
            sys.exit(1)
    
    except FileNotFoundError as e:
        print(f"✗ Error: File not found - {e}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"✗ Error: Invalid JSON in data file - {e}")
        sys.exit(1)
    except ValueError as e:
        print(f"✗ Error: Invalid data format - {e}")
        print("\nThe data file must contain:")
        print("  - metadata (with host, timestamp)")
        print("  - ssh_data (with SSH version info)")
        print("  - command_outputs (device command responses)")
        sys.exit(1)
    except Exception as e:
        print(f"✗ Unexpected error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
