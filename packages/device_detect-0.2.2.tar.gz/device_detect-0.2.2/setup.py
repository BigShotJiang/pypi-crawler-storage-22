"""
Setup configuration for device-detect package
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file for long description
readme_file = Path(__file__).parent / 'README.md'
long_description = readme_file.read_text(encoding='utf-8') if readme_file.exists() else ''

# Read version from package
version = {}
with open('device_detect/__init__.py', 'r', encoding='utf-8') as f:
    for line in f:
        if line.startswith('__version__'):
            exec(line, version)
            break

setup(
    name='device-detect',
    version=version.get('__version__', '0.1.0'),
    description='SSH-based network device detection and verification',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Device Detect Contributors',
    author_email='',
    url='https://github.com/mdrbh/device-detect',
    license='MIT',
    
    packages=find_packages(exclude=['tests*', 'internal*', 'examples*']),
    
    install_requires=[
        'netmiko>=4.0.0',
    ],
    
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=3.0.0',
            'black>=22.0.0',
            'flake8>=4.0.0',
            'pyyaml>=6.0.0',  # For loading lab_devices.yaml in tests
        ],
    },
    
    python_requires='>=3.7',
    
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: System Administrators',
        'Intended Audience :: Developers',
        'Topic :: System :: Networking',
        'Topic :: System :: Systems Administration',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
    ],
    
    keywords='network automation ssh device detection netmiko',
    
    project_urls={
        'Bug Reports': 'https://github.com/mdrbh/device-detect/issues',
        'Source': 'https://github.com/mdrbh/device-detect',
    },
)
