# Changelog

## [0.1.0] - 2024-05-23

### Added
- Initial release
- Session management (create, list, get, terminate)
- Message sending and history viewing
- Watch command for live status polling
- File attachments
- Knowledge, Playbook, and Secret management commands
- Shell completion support
