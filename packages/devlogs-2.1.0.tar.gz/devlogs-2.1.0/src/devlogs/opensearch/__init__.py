# OpenSearch helpers for devlogs
