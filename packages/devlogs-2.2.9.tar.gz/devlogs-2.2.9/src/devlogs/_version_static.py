# AUTO-GENERATED at build time — do not edit or commit
__version__ = "2.2.9"
