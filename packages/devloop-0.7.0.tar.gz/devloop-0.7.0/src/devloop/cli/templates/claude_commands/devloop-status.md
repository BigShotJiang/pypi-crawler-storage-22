---
description: Check if devloop watch is running and show status
---

Check the status of devloop watch by running the `./.agents/check-devloop-status` script.

Show:
- Whether devloop watch is running
- Process ID and memory usage if running
- Instructions to start it if not running

Keep the output concise and actionable.
