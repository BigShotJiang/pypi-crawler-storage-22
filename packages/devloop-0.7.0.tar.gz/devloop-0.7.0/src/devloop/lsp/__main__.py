"""Entry point for running the DevLoop LSP server."""

from devloop.lsp.server import main

if __name__ == "__main__":
    main()
