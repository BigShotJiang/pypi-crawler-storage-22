# DevOps Dojo CLI

Level up your DevOps skills with AI-powered interview drills and hands-on labs. Practice Git, CI/CD, Terraform, Kubernetes, and Azure across foundational to advanced levels.

## Installation

```bash
pip install devops-dojo
```

## Usage

```bash
# Interactive mode (recommended)
devops-dojo start

# Interview mode
devops-dojo interview --topic kubernetes --level foundational
devops-dojo interview --topic terraform --level intermediate
devops-dojo interview --random

# Lab mode
devops-dojo lab list
devops-dojo lab info 1.1-git-workflow
devops-dojo lab submit https://github.com/user/repo --lab 1.1-git-workflow

# Progress tracking
devops-dojo progress summary
devops-dojo progress weak-areas
devops-dojo progress export --format html

# Configuration
devops-dojo config set api_url https://api.devops-dojo.tech
devops-dojo config show
```

## Topics

- **Git** - Workflows, branching strategies, advanced operations
- **CI/CD** - Pipelines, multi-stage deployments, GitOps
- **Terraform** - Infrastructure as Code, modules, state management
- **Kubernetes** - Deployments, Helm, operations
- **Azure** - Networking, compute, storage, HA patterns

## Levels

| Level | Focus |
|-------|-------|
| **Foundational** | Core concepts, single environment, "how to do it" |
| **Intermediate** | Multi-environment, advanced patterns, "how to do it well" |
| **Advanced** | Architecture, trade-offs, "why" |

## Configuration

Configuration is stored in `~/.devops-dojo/config.yaml`:

```yaml
api_url: https://api.devops-dojo.tech
api_key: your-api-key
```

## Progress & Reports

Your progress is tracked locally in `~/.devops-dojo/data/progress.json`. Export as HTML:

```bash
devops-dojo progress export --format html
```
