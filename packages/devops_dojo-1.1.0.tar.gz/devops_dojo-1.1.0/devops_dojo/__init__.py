"""DevOps Dojo - Interactive CLI for DevOps skill development."""

__version__ = "1.0.0"
