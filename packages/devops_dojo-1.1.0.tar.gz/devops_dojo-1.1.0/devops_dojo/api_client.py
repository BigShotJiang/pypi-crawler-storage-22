"""HTTP client for communicating with the backend API."""

import os
from typing import Any, Optional

import httpx

from devops_dojo.config import config_manager


class APIClient:
    """Client for the DevOps Dojo backend API."""

    def __init__(self, base_url: str | None = None, api_key: str | None = None) -> None:
        """
        Initialize the API client.

        Args:
            base_url: Optional base URL override
            api_key: Optional API key override
        """
        self.base_url = base_url or config_manager.get("api_url")
        self.timeout = httpx.Timeout(60.0)  # 60 second timeout for AI calls

        # Get API key from: parameter > env var > config file
        self.api_key = (
            api_key
            or os.environ.get("DEVOPS_DOJO_API_KEY")
            or config_manager.get("api_key")
        )

    def _get_headers(self) -> dict[str, str]:
        """
        Get headers for API requests.

        Returns:
            Headers dict with API key if available
        """
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        return headers

    async def health_check(self) -> dict[str, Any]:
        """
        Check API health status.

        Returns:
            Health status response

        Raises:
            httpx.HTTPError: If the request fails
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(f"{self.base_url}/api/health")
            response.raise_for_status()
            return response.json()

    async def evaluate_answer(
        self,
        question_id: str,
        question: str,
        answer: str,
        must_mention: list[str],
        bonus_points: list[str],
    ) -> dict[str, Any]:
        """
        Evaluate an interview answer.

        Args:
            question_id: Unique question identifier
            question: The question text
            answer: User's answer to evaluate
            must_mention: Required points to cover
            bonus_points: Optional bonus points

        Returns:
            Evaluation response with score and feedback

        Raises:
            httpx.HTTPError: If the request fails
        """
        payload = {
            "question_id": question_id,
            "question": question,
            "answer": answer,
            "evaluation_criteria": {
                "must_mention": must_mention,
                "bonus_points": bonus_points,
            },
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{self.base_url}/api/evaluate/answer",
                headers=self._get_headers(),
                json=payload,
            )
            response.raise_for_status()
            return response.json()

    async def evaluate_repo(
        self,
        lab_id: str,
        repo_url: str,
        requirements: dict[str, Any],
        files_to_analyze: list[str],
    ) -> dict[str, Any]:
        """
        Evaluate a GitHub repository submission.

        Args:
            lab_id: Lab challenge identifier
            repo_url: GitHub repository URL
            requirements: Lab requirements to check
            files_to_analyze: Files or patterns to analyze

        Returns:
            Evaluation response with score and breakdown

        Raises:
            httpx.HTTPError: If the request fails
        """
        payload = {
            "lab_id": lab_id,
            "repo_url": repo_url,
            "requirements": requirements,
            "files_to_analyze": files_to_analyze,
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{self.base_url}/api/evaluate/repo",
                headers=self._get_headers(),
                json=payload,
            )
            response.raise_for_status()
            return response.json()

    # =========================================================================
    # V2 Content API Methods
    # =========================================================================

    async def get_topics(self) -> dict[str, Any]:
        """
        Get available topics and difficulty levels.

        Returns:
            Dict with 'topics' and 'levels' lists

        Raises:
            httpx.HTTPError: If the request fails
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(
                f"{self.base_url}/api/content/topics",
                headers=self._get_headers(),
            )
            response.raise_for_status()
            return response.json()

    async def get_questions(
        self,
        topic: Optional[str] = None,
        level: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Get questions, optionally filtered by topic and/or level.

        Args:
            topic: Filter by topic (optional)
            level: Filter by level (optional)

        Returns:
            Dict with 'questions' list and 'total' count

        Raises:
            httpx.HTTPError: If the request fails
        """
        params = {}
        if topic:
            params["topic"] = topic
        if level:
            params["level"] = level

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(
                f"{self.base_url}/api/content/questions",
                headers=self._get_headers(),
                params=params,
            )
            response.raise_for_status()
            return response.json()

    async def get_reference_answer(self, question_id: str) -> dict[str, Any]:
        """
        Get the reference answer for a question.

        Args:
            question_id: The question identifier

        Returns:
            Dict with 'question_id' and 'reference_answer'

        Raises:
            httpx.HTTPError: If the request fails
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(
                f"{self.base_url}/api/content/questions/{question_id}/reference-answer",
                headers=self._get_headers(),
            )
            response.raise_for_status()
            return response.json()

    async def get_labs(self, phase: Optional[int] = None) -> dict[str, Any]:
        """
        Get labs, optionally filtered by phase.

        Args:
            phase: Filter by phase number (optional)

        Returns:
            Dict with 'labs' list and 'total' count

        Raises:
            httpx.HTTPError: If the request fails
        """
        params = {}
        if phase is not None:
            params["phase"] = phase

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(
                f"{self.base_url}/api/content/labs",
                headers=self._get_headers(),
                params=params,
            )
            response.raise_for_status()
            return response.json()

    async def get_lab(self, lab_id: str) -> dict[str, Any]:
        """
        Get a single lab by ID.

        Args:
            lab_id: The lab identifier

        Returns:
            Lab data dict

        Raises:
            httpx.HTTPError: If the request fails
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(
                f"{self.base_url}/api/content/labs/{lab_id}",
                headers=self._get_headers(),
            )
            response.raise_for_status()
            return response.json()

    async def get_testing_guide(self) -> dict[str, Any]:
        """
        Get the lab testing guide.

        Returns:
            Dict with 'content' (markdown string)

        Raises:
            httpx.HTTPError: If the request fails
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(
                f"{self.base_url}/api/content/labs/testing-guide",
                headers=self._get_headers(),
            )
            response.raise_for_status()
            return response.json()

    # =========================================================================
    # V2 Evaluate Methods (server-side criteria lookup)
    # =========================================================================

    async def evaluate_answer_v2(
        self,
        question_id: str,
        answer: str,
    ) -> dict[str, Any]:
        """
        V2: Evaluate an interview answer with server-side criteria lookup.

        Unlike evaluate_answer(), this does not require question text or criteria.
        The server looks up the question and evaluation criteria by question_id.

        Args:
            question_id: Unique question identifier
            answer: User's answer to evaluate

        Returns:
            Evaluation response with score and feedback

        Raises:
            httpx.HTTPError: If the request fails
        """
        payload = {
            "question_id": question_id,
            "answer": answer,
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{self.base_url}/api/v2/evaluate/answer",
                headers=self._get_headers(),
                json=payload,
            )
            response.raise_for_status()
            return response.json()

    async def evaluate_repo_v2(
        self,
        lab_id: str,
        repo_url: str,
    ) -> dict[str, Any]:
        """
        V2: Evaluate a GitHub repository with server-side requirements lookup.

        Unlike evaluate_repo(), this does not require requirements or files_to_analyze.
        The server looks up the lab requirements by lab_id.

        Args:
            lab_id: Lab challenge identifier
            repo_url: GitHub repository URL

        Returns:
            Evaluation response with score and breakdown

        Raises:
            httpx.HTTPError: If the request fails
        """
        payload = {
            "lab_id": lab_id,
            "repo_url": repo_url,
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{self.base_url}/api/v2/evaluate/repo",
                headers=self._get_headers(),
                json=payload,
            )
            response.raise_for_status()
            return response.json()


# Global client instance
api_client = APIClient()
