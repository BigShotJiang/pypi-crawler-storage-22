"""DevOps Dojo CLI entry point."""

import asyncio
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

from devops_dojo import __version__
from devops_dojo.config import config_manager
from devops_dojo.modes.interview import interview_mode
from devops_dojo.modes.lab import lab_mode
from devops_dojo.modes.progress import progress_tracker
from devops_dojo.reports.generator import report_generator

console = Console()

# Main app
app = typer.Typer(
    name="devops-dojo",
    help="Interactive CLI tool for DevOps skill development",
    no_args_is_help=False,
)

# Sub-apps
interview_app = typer.Typer(help="Interview drill mode")
lab_app = typer.Typer(help="Hands-on lab challenges")
progress_app = typer.Typer(help="Progress tracking")
config_app = typer.Typer(help="Configuration management")

app.add_typer(interview_app, name="interview")
app.add_typer(lab_app, name="lab")
app.add_typer(progress_app, name="progress")
app.add_typer(config_app, name="config")


# ==================== Version & Start ====================

@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Annotated[
        bool,
        typer.Option("--version", "-v", help="Show version and exit"),
    ] = False,
) -> None:
    """DevOps Dojo - Level up your DevOps skills."""
    if version:
        console.print(f"devops-dojo version {__version__}")
        raise typer.Exit()

    # If no subcommand, show interactive menu
    if ctx.invoked_subcommand is None:
        show_interactive_menu()


def show_interactive_menu() -> None:
    """Show interactive welcome menu for level and mode selection."""
    # Welcome banner
    console.print()
    console.print(
        Panel(
            "[bold cyan]Welcome to DevOps Dojo![/bold cyan]\n\n"
            "Level up your DevOps skills through interview drills and hands-on labs.\n"
            "AI-powered evaluation helps you identify areas for improvement.\n\n"
            "[dim]Tip: Export your progress as HTML report:[/dim] [cyan]devops-dojo progress export --format html[/cyan]",
            title="DevOps Dojo",
            border_style="cyan",
        )
    )

    # Show current progress summary
    summary = progress_tracker.get_summary()
    if summary["total_questions"] > 0 or summary["total_labs"] > 0:
        console.print()
        console.print(
            f"[dim]Progress: {summary['total_questions']} questions answered, "
            f"{summary['total_labs']} labs completed[/dim]"
        )

    # Step 1: Choose level
    console.print()
    console.print("[bold]Step 1: Select your skill level[/bold]")
    console.print()

    level_table = Table(show_header=False, box=None, padding=(0, 2))
    level_table.add_column("Option", style="cyan")
    level_table.add_column("Level", style="white")
    level_table.add_column("Description", style="dim")

    level_table.add_row("1", "Foundational", "Fundamentals, single environment, 'how to do it'")
    level_table.add_row("2", "Intermediate", "Multi-env, advanced patterns, 'how to do it well'")
    level_table.add_row("3", "Advanced", "Architecture, trade-offs, design decisions")

    console.print(level_table)
    console.print()

    level_choice = Prompt.ask(
        "Choose level",
        choices=["1", "2", "3", "q"],
        default="1",
    )

    if level_choice == "q":
        console.print("[yellow]Goodbye![/yellow]")
        raise typer.Exit()

    level_map = {"1": "foundational", "2": "intermediate", "3": "advanced"}
    selected_level = level_map[level_choice]

    # Step 2: Choose mode
    console.print()
    console.print("[bold]Step 2: What would you like to do?[/bold]")
    console.print()

    mode_table = Table(show_header=False, box=None, padding=(0, 2))
    mode_table.add_column("Option", style="cyan")
    mode_table.add_column("Mode", style="white")
    mode_table.add_column("Description", style="dim")

    mode_table.add_row("1", "Interview Questions", "Practice Q&A with AI-powered feedback")
    mode_table.add_row("2", "Lab Scenarios", "Hands-on challenges with repo evaluation")
    mode_table.add_row("3", "View Progress", "See your learning progress and weak areas")

    console.print(mode_table)
    console.print()

    mode_choice = Prompt.ask(
        "Choose mode",
        choices=["1", "2", "3", "q"],
        default="1",
    )

    if mode_choice == "q":
        console.print("[yellow]Goodbye![/yellow]")
        raise typer.Exit()

    # Execute chosen mode
    if mode_choice == "1":
        # Interview mode - also let them pick topic
        console.print()
        console.print("[bold]Step 3: Select a topic (or 'all' for random)[/bold]")
        console.print()

        topic_table = Table(show_header=False, box=None, padding=(0, 2))
        topic_table.add_column("Option", style="cyan")
        topic_table.add_column("Topic", style="white")

        topics = interview_mode.TOPICS
        for i, topic in enumerate(topics, 1):
            topic_table.add_row(str(i), topic.title())
        topic_table.add_row("a", "All topics (random)")

        console.print(topic_table)
        console.print()

        valid_choices = [str(i) for i in range(1, len(topics) + 1)] + ["a", "q"]
        topic_choice = Prompt.ask(
            "Choose topic",
            choices=valid_choices,
            default="a",
        )

        if topic_choice == "q":
            console.print("[yellow]Goodbye![/yellow]")
            raise typer.Exit()

        if topic_choice == "a":
            selected_topic = None
            random_mode = True
        else:
            selected_topic = topics[int(topic_choice) - 1]
            random_mode = False

        console.print()
        console.print(
            f"[green]Starting interview session: "
            f"{selected_topic.title() if selected_topic else 'All topics'} | "
            f"{selected_level.replace('_', ' ').title()}[/green]"
        )
        console.print()

        restart = asyncio.run(interview_mode.run_drill(selected_topic, selected_level, random_mode))
        if restart:
            show_interactive_menu()  # Return to main menu
        return

    elif mode_choice == "2":
        # Lab mode - show available labs and let user choose
        # Load and filter labs by level (async call)
        asyncio.run(lab_mode.load_labs())
        level_labs = [lab for lab in lab_mode.labs if lab.level == selected_level]

        if not level_labs:
            # If no labs for this level, show all labs
            level_labs = lab_mode.labs

        if not level_labs:
            console.print("[yellow]No labs found.[/yellow]")
            console.print(
                "[dim]Make sure the API server is reachable.[/dim]"
            )
            return

        # Loop to allow returning to lab table after viewing guide
        while True:
            console.print()
            console.print(
                f"[green]Showing labs for {selected_level.replace('_', ' ').title()} level[/green]"
            )
            console.print()

            # Display labs table
            table = Table(title="Available Labs")
            table.add_column("#", style="cyan")
            table.add_column("ID", style="white")
            table.add_column("Title", style="white")
            table.add_column("Phase", style="magenta")
            table.add_column("Level", style="yellow")
            table.add_column("Time", style="dim")

            # Add testing guide as option 0
            table.add_row(
                "0",
                "how-to-test-labs",
                "How to Test Labs Without Cloud Costs",
                "-",
                "All",
                "5 min read",
            )

            for i, lab in enumerate(level_labs, 1):
                table.add_row(
                    str(i),
                    lab.id,
                    lab.title,
                    str(lab.phase),
                    lab.level.replace("_", " ").title(),
                    lab.estimated_time,
                )

            console.print(table)
            console.print()

            # Let user choose a lab
            valid_choices = ["0"] + [str(i) for i in range(1, len(level_labs) + 1)] + ["q"]
            lab_choice = Prompt.ask(
                "Choose a lab to view details (or 'q' to quit)",
                choices=valid_choices,
                default="0",
            )

            if lab_choice == "q":
                console.print("[yellow]Goodbye![/yellow]")
                raise typer.Exit()

            # Handle testing guide selection
            if lab_choice == "0":
                console.print()
                asyncio.run(lab_mode.show_testing_guide())
                console.print()

                # Ask what to do next
                next_action = Prompt.ask(
                    "What next?",
                    choices=["back", "quit"],
                    default="back",
                )
                if next_action == "back":
                    continue  # Loop back to show lab table again
                else:
                    console.print("[yellow]Goodbye![/yellow]")
                    return

            # Handle regular lab selection (keep inside loop)
            selected_lab = level_labs[int(lab_choice) - 1]

            # Show lab info
            console.print()
            asyncio.run(lab_mode.show_lab_info(selected_lab.id))

            # Ask what to do next
            console.print()
            action_choice = Prompt.ask(
                "What would you like to do?",
                choices=["start", "back", "quit"],
                default="start",
            )

            if action_choice == "start":
                console.print()
                console.print(
                    Panel(
                        "1. Create a new GitHub repository for your solution\n"
                        "2. Implement the requirements listed above\n"
                        "3. Push your code to GitHub\n"
                        f"4. Submit using: [cyan]devops-dojo lab submit <repo-url> --lab {selected_lab.id}[/cyan]\n\n"
                        "[dim]Tip: Run [cyan]devops-dojo lab how-to-test-labs[/cyan] to learn how to test without expensive cloud resources[/dim]",
                        title="Getting Started",
                        border_style="green",
                    )
                )
                console.print()

                # Ask if user wants to continue or exit
                next_action = Prompt.ask(
                    "What next?",
                    choices=["back", "quit"],
                    default="quit",
                )
                if next_action == "back":
                    continue  # Go back to lab table
                else:
                    console.print("[dim]Good luck! Run 'devops-dojo' again when you're ready to submit.[/dim]")
                    return
            elif action_choice == "back":
                continue  # Go back to lab table
            elif action_choice == "quit":
                console.print("[yellow]Goodbye![/yellow]")
                return

    elif mode_choice == "3":
        # Progress mode
        progress_tracker.display_summary()
        console.print()
        progress_tracker.display_weak_areas()
        console.print()
        console.print(
            "[dim]Export as HTML report:[/dim] [cyan]devops-dojo progress export --format html[/cyan]"
        )


# ==================== Start Command ====================

@app.command("start")
def start_interactive() -> None:
    """Launch interactive mode selection menu."""
    show_interactive_menu()


# ==================== Interview Commands ====================

@interview_app.callback(invoke_without_command=True)
def interview_default(
    ctx: typer.Context,
    topic: Annotated[
        Optional[str],
        typer.Option("--topic", "-t", help="Topic: git, cicd, terraform, kubernetes, azure"),
    ] = None,
    level: Annotated[
        Optional[str],
        typer.Option("--level", "-l", help="Level: foundational, intermediate, advanced"),
    ] = None,
    random: Annotated[
        bool,
        typer.Option("--random", "-r", help="Random questions across all topics/levels"),
    ] = False,
) -> None:
    """Start an interview drill session."""
    if ctx.invoked_subcommand is not None:
        return

    if topic and topic not in interview_mode.TOPICS:
        console.print(f"[red]Invalid topic. Choose from: {', '.join(interview_mode.TOPICS)}[/red]")
        raise typer.Exit(1)

    if level and level not in interview_mode.LEVELS:
        console.print(f"[red]Invalid level. Choose from: {', '.join(interview_mode.LEVELS)}[/red]")
        raise typer.Exit(1)

    restart = asyncio.run(interview_mode.run_drill(topic, level, random))
    if restart:
        show_interactive_menu()  # Return to main menu


@interview_app.command("topics")
def list_topics() -> None:
    """List available topics."""
    console.print("[bold]Available Topics:[/bold]")
    for topic in interview_mode.TOPICS:
        console.print(f"  • {topic}")

    console.print("\n[bold]Available Levels:[/bold]")
    for level in interview_mode.LEVELS:
        console.print(f"  • {level.replace('_', ' ').title()}")


# ==================== Lab Commands ====================

@lab_app.callback(invoke_without_command=True)
def lab_default(ctx: typer.Context) -> None:
    """Lab challenge mode."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(lab_list)


@lab_app.command("list")
def lab_list(
    phase: Annotated[
        Optional[int],
        typer.Option("--phase", "-p", help="Filter by phase number"),
    ] = None,
) -> None:
    """List available lab challenges."""
    asyncio.run(lab_mode.list_labs(phase))


@lab_app.command("info")
def lab_info(
    lab_id: Annotated[str, typer.Argument(help="Lab ID to show info for")],
) -> None:
    """Show detailed information about a lab."""
    asyncio.run(lab_mode.show_lab_info(lab_id))


@lab_app.command("start")
def lab_start(
    lab_id: Annotated[str, typer.Argument(help="Lab ID to start")],
) -> None:
    """Show instructions for starting a lab."""
    asyncio.run(lab_mode.show_lab_info(lab_id))
    console.print()
    console.print(
        Panel(
            "1. Create a new GitHub repository for your solution\n"
            "2. Implement the requirements listed above\n"
            "3. Push your code to GitHub\n"
            "4. Submit using: [cyan]devops-dojo lab submit <repo-url>[/cyan]\n\n"
            "[dim]Tip: Run [cyan]devops-dojo lab how-to-test-labs[/cyan] to learn how to test without expensive cloud resources[/dim]",
            title="Getting Started",
            border_style="green",
        )
    )


@lab_app.command("submit")
def lab_submit(
    repo_url: Annotated[str, typer.Argument(help="GitHub repository URL")],
    lab_id: Annotated[
        Optional[str],
        typer.Option("--lab", "-l", help="Lab ID (if not auto-detected)"),
    ] = None,
) -> None:
    """Submit a lab solution for evaluation."""
    if not lab_id:
        console.print("[yellow]Please specify the lab ID with --lab option[/yellow]")
        console.print("Example: devops-dojo lab submit https://github.com/user/repo --lab 1.1-git-workflow")
        raise typer.Exit(1)

    asyncio.run(lab_mode.submit_lab(lab_id, repo_url))


@lab_app.command("how-to-test-labs")
def lab_how_to_test_labs() -> None:
    """Show how to complete and test labs without expensive cloud environments."""
    asyncio.run(lab_mode.show_testing_guide())


# ==================== Progress Commands ====================

@progress_app.callback(invoke_without_command=True)
def progress_default(ctx: typer.Context) -> None:
    """Progress tracking."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(progress_summary)


@progress_app.command("summary")
def progress_summary() -> None:
    """Show progress summary."""
    progress_tracker.display_summary()


@progress_app.command("weak-areas")
def progress_weak_areas() -> None:
    """Show areas that need improvement."""
    progress_tracker.display_weak_areas()


@progress_app.command("history")
def progress_history(
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="Number of records to show"),
    ] = 20,
) -> None:
    """Show recent activity history."""
    progress_tracker.display_history(limit)


@progress_app.command("export")
def progress_export(
    format: Annotated[
        str,
        typer.Option("--format", "-f", help="Export format: html"),
    ] = "html",
    output: Annotated[
        Optional[Path],
        typer.Option("--output", "-o", help="Output file path"),
    ] = None,
) -> None:
    """Export progress report."""
    if format != "html":
        console.print("[red]Only HTML format is currently supported.[/red]")
        raise typer.Exit(1)

    output_path = report_generator.generate_progress_report(output)
    console.print(f"[green]Report exported to: {output_path}[/green]")


@progress_app.command("reset")
def progress_reset(
    confirm: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Confirm reset without prompting"),
    ] = False,
) -> None:
    """Reset all progress data."""
    if not confirm:
        confirm = typer.confirm("Are you sure you want to reset all progress data?")

    if confirm:
        progress_tracker.reset()
    else:
        console.print("[yellow]Reset cancelled.[/yellow]")


# ==================== Config Commands ====================

@config_app.command("show")
def config_show() -> None:
    """Show current configuration."""
    import os
    config = config_manager.load()
    console.print("[bold]Current Configuration:[/bold]")
    console.print(f"  api_url: {config.api_url}")

    # Show API key status (masked)
    api_key = os.environ.get("DEVOPS_DOJO_API_KEY") or config.api_key
    if api_key:
        masked = api_key[:4] + "..." + api_key[-4:] if len(api_key) > 8 else "****"
        source = "env" if os.environ.get("DEVOPS_DOJO_API_KEY") else "config"
        console.print(f"  api_key: {masked} (from {source})")
    else:
        console.print("  api_key: [yellow]not set[/yellow]")
        console.print()
        console.print("[dim]Set API key with:[/dim]")
        console.print("[dim]  devops-dojo config set api-key <your-key>[/dim]")
        console.print("[dim]  or export DEVOPS_DOJO_API_KEY=<your-key>[/dim]")


@config_app.command("set")
def config_set(
    key: Annotated[str, typer.Argument(help="Config key (e.g., api-url)")],
    value: Annotated[str, typer.Argument(help="Config value")],
) -> None:
    """Set a configuration value."""
    # Normalize key name
    key = key.replace("-", "_")

    try:
        config_manager.set(key, value)
        console.print(f"[green]Set {key} = {value}[/green]")
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
