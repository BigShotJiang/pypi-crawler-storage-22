"""CLI configuration management."""

from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel


class Config(BaseModel):
    """CLI configuration settings."""

    api_url: str = "https://devops-dojo.tech"
    api_key: Optional[str] = None  # API key for authentication


class ConfigManager:
    """Manages CLI configuration storage and retrieval."""

    def __init__(self) -> None:
        """Initialize config manager with default paths."""
        self.config_dir = Path.home() / ".devops-dojo"
        self.config_file = self.config_dir / "config.yaml"
        self._ensure_config_dir()

    def _ensure_config_dir(self) -> None:
        """Create config directory if it doesn't exist."""
        self.config_dir.mkdir(parents=True, exist_ok=True)

    def load(self) -> Config:
        """
        Load configuration from file.

        Returns:
            Config object with current settings
        """
        if self.config_file.exists():
            with open(self.config_file, encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            return Config(**data)
        return Config()

    def save(self, config: Config) -> None:
        """
        Save configuration to file.

        Args:
            config: Config object to save
        """
        with open(self.config_file, "w", encoding="utf-8") as f:
            yaml.dump(config.model_dump(), f, default_flow_style=False)

    def get(self, key: str) -> Any:
        """Get a specific config value."""
        config = self.load()
        return getattr(config, key, None)

    def set(self, key: str, value: Any) -> None:
        """Set a specific config value."""
        config = self.load()
        if hasattr(config, key):
            setattr(config, key, value)
            self.save(config)
        else:
            raise ValueError(f"Unknown config key: {key}")


# Global config manager instance
config_manager = ConfigManager()


def get_data_dir() -> Path:
    """Get the path to the local data directory."""
    data_dir = Path.home() / ".devops-dojo" / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir
