"""GitHub client for fetching repository contents."""

from devops_dojo.github.client import GitHubClient

__all__ = ["GitHubClient"]
