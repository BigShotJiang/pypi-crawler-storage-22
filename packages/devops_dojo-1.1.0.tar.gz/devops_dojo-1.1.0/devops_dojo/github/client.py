"""GitHub API client for fetching repository contents."""

import re
from typing import Any
from urllib.parse import urlparse

import httpx


class GitHubClient:
    """Client for interacting with GitHub API."""

    def __init__(self, token: str | None = None) -> None:
        """
        Initialize GitHub client.

        Args:
            token: Optional GitHub personal access token for higher rate limits
        """
        self.base_url = "https://api.github.com"
        self.headers = {"Accept": "application/vnd.github.v3+json"}
        if token:
            self.headers["Authorization"] = f"token {token}"

    def parse_repo_url(self, url: str) -> tuple[str, str]:
        """
        Parse a GitHub URL to extract owner and repo name.

        Args:
            url: GitHub repository URL

        Returns:
            Tuple of (owner, repo)

        Raises:
            ValueError: If URL is invalid
        """
        parsed = urlparse(url)
        path_parts = parsed.path.strip("/").split("/")

        if len(path_parts) < 2:
            raise ValueError(f"Invalid GitHub URL: {url}")

        return path_parts[0], path_parts[1].replace(".git", "")

    async def get_repo_info(self, owner: str, repo: str) -> dict[str, Any]:
        """
        Get repository information.

        Args:
            owner: Repository owner
            repo: Repository name

        Returns:
            Repository information
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.base_url}/repos/{owner}/{repo}",
                headers=self.headers,
            )
            response.raise_for_status()
            return response.json()

    async def get_repo_tree(
        self,
        owner: str,
        repo: str,
        branch: str = "main",
    ) -> list[dict[str, Any]]:
        """
        Get the file tree of a repository.

        Args:
            owner: Repository owner
            repo: Repository name
            branch: Branch name (default: main)

        Returns:
            List of file/directory entries
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.base_url}/repos/{owner}/{repo}/git/trees/{branch}?recursive=1",
                headers=self.headers,
            )

            if response.status_code == 404:
                # Try master branch
                response = await client.get(
                    f"{self.base_url}/repos/{owner}/{repo}/git/trees/master?recursive=1",
                    headers=self.headers,
                )

            response.raise_for_status()
            data = response.json()
            return data.get("tree", [])

    async def get_file_content(
        self,
        owner: str,
        repo: str,
        path: str,
    ) -> str | None:
        """
        Get the content of a file.

        Args:
            owner: Repository owner
            repo: Repository name
            path: File path

        Returns:
            File content as string, or None if not found
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.base_url}/repos/{owner}/{repo}/contents/{path}",
                headers={**self.headers, "Accept": "application/vnd.github.v3.raw"},
            )

            if response.status_code == 200:
                return response.text
            return None

    async def get_files_matching_patterns(
        self,
        owner: str,
        repo: str,
        patterns: list[str],
        max_files: int = 20,
    ) -> dict[str, str]:
        """
        Get contents of files matching specified patterns.

        Args:
            owner: Repository owner
            repo: Repository name
            patterns: List of file patterns (glob-style)
            max_files: Maximum number of files to fetch

        Returns:
            Dictionary of file path -> content
        """
        tree = await self.get_repo_tree(owner, repo)

        # Filter to blobs (files) only
        files = [item["path"] for item in tree if item["type"] == "blob"]

        # Match against patterns
        matched = set()
        for file_path in files:
            for pattern in patterns:
                regex_pattern = pattern.replace("*", ".*").replace("?", ".")
                if re.match(regex_pattern, file_path, re.IGNORECASE):
                    matched.add(file_path)
                    break

        # Fetch contents
        contents = {}
        for file_path in list(matched)[:max_files]:
            content = await self.get_file_content(owner, repo, file_path)
            if content is not None:
                contents[file_path] = content

        return contents


# Global client instance
github_client = GitHubClient()
