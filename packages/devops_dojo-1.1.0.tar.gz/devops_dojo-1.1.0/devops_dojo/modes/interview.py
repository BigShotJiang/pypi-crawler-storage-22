"""Interview drill mode for practicing DevOps questions."""

import random
import sys
from typing import Any

import readchar
from readchar import key as special_keys
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

from devops_dojo.api_client import api_client
from devops_dojo.modes.progress import progress_tracker

console = Console()


class Question:
    """Represents an interview question loaded from API."""

    def __init__(self, data: dict[str, Any]) -> None:
        """
        Initialize from API response data.

        Args:
            data: Question dict from API (without evaluation criteria)
        """
        self.id = data["id"]
        self.question = data["question"]
        self.topic = data.get("topic", "")
        self.level = data.get("level", "")
        self.difficulty = data.get("difficulty", "medium")
        self.tags = data.get("tags", [])
        self.follow_up_questions = data.get("follow_up_questions", [])
        self.related_labs = data.get("related_labs", [])
        self.has_reference_answer = data.get("has_reference_answer", False)


class InterviewMode:
    """Handles the interview drill mode."""

    # Constants for menu display and validation (kept for CLI compatibility)
    TOPICS = ["git", "cicd", "terraform", "kubernetes", "azure"]
    LEVELS = ["foundational", "intermediate", "advanced"]

    def __init__(self) -> None:
        self.questions: list[Question] = []

    async def load_questions(
        self,
        topic: str | None = None,
        level: str | None = None,
    ) -> list[Question]:
        """
        Load questions from API.

        Args:
            topic: Filter by topic (optional)
            level: Filter by level (optional)

        Returns:
            List of Question objects
        """
        try:
            response = await api_client.get_questions(topic=topic, level=level)
            questions_data = response.get("questions", [])
            self.questions = [Question(q) for q in questions_data]
            return self.questions
        except Exception:
            self.questions = []
            return []

    def get_random_question(self) -> Question | None:
        """Get a random question from loaded questions."""
        if not self.questions:
            return None
        return random.choice(self.questions)

    async def run_drill(
        self,
        topic: str | None = None,
        level: str | None = None,
        random_mode: bool = False,
    ) -> bool:
        """
        Run an interactive interview drill session.

        Args:
            topic: Topic to focus on
            level: Difficulty level
            random_mode: If True, randomize across all topics/levels

        Returns:
            True if user wants to return to main menu, False to exit
        """
        if random_mode:
            await self.load_questions()
        else:
            await self.load_questions(topic, level)

        if not self.questions:
            console.print(
                "[red]No questions found for the specified criteria.[/red]"
            )
            console.print(
                "[yellow]Make sure the API server is reachable.[/yellow]"
            )
            return False

        console.print(
            Panel(
                "[bold blue]DevOps Dojo - Interview Mode[/bold blue]\n\n"
                "Answer the questions to test your knowledge.\n"
                "Type 'quit' or 'q' to exit, 'skip' to skip a question.",
                title="Welcome",
            )
        )

        session_scores: list[int] = []

        while True:
            question = self.get_random_question()
            if not question:
                break

            console.print()
            console.print(
                Panel(
                    f"[bold]{question.question}[/bold]",
                    title=f"[{question.topic.upper()}] {question.level.replace('_', ' ').title()} - {question.difficulty.title()}",
                    border_style="cyan",
                )
            )

            # Get user's answer
            console.print()
            answer = Prompt.ask("[green]Your answer[/green]")

            if answer.lower() in ("quit", "q"):
                break

            if answer.lower() == "skip":
                console.print("[yellow]Skipping question...[/yellow]")
                continue

            # Evaluate the answer using V2 API (server-side criteria lookup)
            console.print()
            console.print("[dim]Evaluating your answer...[/dim]")

            try:
                result = await api_client.evaluate_answer_v2(
                    question_id=question.id,
                    answer=answer,
                )

                self._display_evaluation(result)
                session_scores.append(result["score"])

                # Track progress
                progress_tracker.record_answer(
                    question_id=question.id,
                    topic=question.topic,
                    level=question.level,
                    score=result["score"],
                )

                # Offer to show reference answer (fetch on demand)
                if question.has_reference_answer:
                    console.print()
                    show_answer = Prompt.ask(
                        "Would you like to see the reference answer?",
                        choices=["y", "n"],
                        default="y" if result["score"] < 70 else "n",
                    )
                    if show_answer.lower() == "y":
                        await self._fetch_and_display_reference_answer(question.id)

            except Exception as e:
                console.print(f"[red]Error evaluating answer: {e}[/red]")
                console.print(
                    "[yellow]Make sure the API server is running.[/yellow]"
                )

            # Ask to continue
            console.print()
            continue_choice = Prompt.ask(
                "Continue?",
                choices=["y", "n"],
                default="y",
            )
            if continue_choice.lower() == "n":
                break

        # Show session summary and offer next action
        if session_scores:
            self._display_session_summary(session_scores)

        # Offer choice to exit or return to main menu
        console.print()
        console.print("[bold]What would you like to do?[/bold]")
        console.print("  [cyan]1[/cyan]  Return to main menu")
        console.print("  [cyan]2[/cyan]  Exit")
        console.print()
        next_action = Prompt.ask(
            "Choose",
            choices=["1", "2"],
            default="1",
        )

        return next_action == "1"  # Return True to restart main menu

    def _display_evaluation(self, result: dict[str, Any]) -> None:
        """Display the evaluation results."""
        score = result["score"]

        # Determine color based on score
        if score >= 80:
            color = "green"
        elif score >= 60:
            color = "yellow"
        else:
            color = "red"

        # Score panel
        console.print(
            Panel(
                f"[bold {color}]Score: {score}/100[/bold {color}]",
                title="Evaluation",
                border_style=color,
            )
        )

        # Feedback
        console.print()
        console.print("[bold]Feedback:[/bold]")
        console.print(result["feedback"])

        # Points covered
        if result.get("must_mention_hits"):
            console.print()
            console.print("[green]Points covered:[/green]")
            for point in result["must_mention_hits"]:
                console.print(f"  - {point}")

        # Points missed
        if result.get("must_mention_misses"):
            console.print()
            console.print("[red]Points missed:[/red]")
            for point in result["must_mention_misses"]:
                console.print(f"  - {point}")

        # Bonus points
        if result.get("bonus_hits"):
            console.print()
            console.print("[cyan]Bonus points earned:[/cyan]")
            for point in result["bonus_hits"]:
                console.print(f"  - {point}")

        # Improvements
        if result.get("improvements"):
            console.print()
            console.print("[yellow]Suggestions for improvement:[/yellow]")
            for improvement in result["improvements"]:
                console.print(f"  -> {improvement}")

    async def _fetch_and_display_reference_answer(self, question_id: str) -> None:
        """Fetch reference answer from API and display it."""
        try:
            response = await api_client.get_reference_answer(question_id)
            reference_answer = response.get("reference_answer", "")
            if reference_answer:
                self._display_reference_answer(reference_answer)
            else:
                console.print("[yellow]Reference answer not available.[/yellow]")
        except Exception as e:
            console.print(f"[red]Error fetching reference answer: {e}[/red]")

    def _display_reference_answer(self, reference_answer: str) -> None:
        """Display the reference answer with line-based pagination."""
        console.print()
        console.print(
            Panel(
                "Reference Answer",
                style="bold cyan",
                border_style="cyan",
            )
        )
        console.print()

        # Split content into lines and group into pages
        lines = reference_answer.split('\n')
        lines_per_page = 15  # Show ~15 lines at a time

        # Group lines into pages
        pages: list[str] = []
        for i in range(0, len(lines), lines_per_page):
            page_lines = lines[i:i + lines_per_page]
            pages.append('\n'.join(page_lines))

        for i, page in enumerate(pages):
            # Render markdown for this page
            md = Markdown(page)
            console.print(md)

            # Show pagination prompt (except for last page)
            if i < len(pages) - 1:
                console.print()
                console.print(
                    f"[dim]Page {i + 1}/{len(pages)} - Press [cyan]Space[/cyan], [cyan]Enter[/cyan], or [cyan]Down[/cyan] for next | [cyan]q[/cyan] to quit[/dim]"
                )

                try:
                    # Wait for keypress
                    while True:
                        k = readchar.readkey()

                        # Handle quit
                        if k in ("q", "Q"):
                            console.print()
                            return  # Exit the function entirely
                        # Handle next: Space, Enter, Down arrow
                        elif k == " ":  # Space
                            break
                        elif k in ("\r", "\n"):  # Enter
                            break
                        elif k == special_keys.DOWN:  # Down arrow
                            break
                        elif k == special_keys.SPACE:  # Alternative space constant
                            break
                    # Clear the prompt lines using direct stdout (Rich escapes ANSI codes)
                    sys.stdout.write("\033[F\033[K\033[F\033[K")
                    sys.stdout.flush()
                except Exception as e:
                    # Fallback if readchar doesn't work
                    console.print(f"[dim]Note: Keyboard navigation unavailable ({e})[/dim]")
                    choice = Prompt.ask(
                        "",
                        choices=["", "q"],
                        default="",
                        show_choices=False,
                    )
                    if choice == "q":
                        console.print()
                        return

        console.print()

    def _display_session_summary(self, scores: list[int]) -> None:
        """Display a summary of the session."""
        avg_score = sum(scores) / len(scores)

        table = Table(title="Session Summary")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Questions Answered", str(len(scores)))
        table.add_row("Average Score", f"{avg_score:.1f}/100")
        table.add_row("Highest Score", f"{max(scores)}/100")
        table.add_row("Lowest Score", f"{min(scores)}/100")

        console.print()
        console.print(table)


# Global instance
interview_mode = InterviewMode()
