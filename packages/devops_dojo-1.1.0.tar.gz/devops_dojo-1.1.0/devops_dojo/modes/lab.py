"""Lab challenge mode for hands-on DevOps practice."""

import sys
from typing import Any

import readchar
from readchar import key as special_keys
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

from devops_dojo.api_client import api_client
from devops_dojo.modes.progress import progress_tracker

console = Console()


class Lab:
    """Represents a lab challenge loaded from API."""

    def __init__(self, data: dict[str, Any]) -> None:
        """
        Initialize from API response data.

        Args:
            data: Lab dict from API
        """
        self.id = data["id"]
        self.title = data["title"]
        self.phase = data.get("phase", 1)
        self.level = data.get("level", "foundational")
        self.estimated_time = data.get("estimated_time", "Unknown")
        self.topics = data.get("topics", [])
        self.description = data.get("description", "")
        self.files_to_analyze = data.get("files_to_analyze", [])
        self.passing_score = data.get("passing_score", 70)

        # Requirements come nested from API
        requirements = data.get("requirements", {})
        self.requirements = {
            "must_have": requirements.get("must_have", {}),
            "should_have": requirements.get("should_have", {}),
            "bonus": requirements.get("bonus", {}),
        }

        # Scoring comes nested from API
        scoring = data.get("scoring", {})
        self.scoring = {
            "requirements_met": scoring.get("requirements_met", 40),
            "code_quality": scoring.get("code_quality", 20),
            "security": scoring.get("security", 20),
            "documentation": scoring.get("documentation", 10),
            "bonus": scoring.get("bonus", 10),
        }


class LabMode:
    """Handles the lab challenge mode."""

    def __init__(self) -> None:
        self.labs: list[Lab] = []

    async def load_labs(self, phase: int | None = None) -> list[Lab]:
        """
        Load lab challenges from API.

        Args:
            phase: Filter by phase number (optional)

        Returns:
            List of Lab objects
        """
        try:
            response = await api_client.get_labs(phase=phase)
            labs_data = response.get("labs", [])
            self.labs = [Lab(lab) for lab in labs_data]
            return self.labs
        except Exception:
            self.labs = []
            return []

    async def get_lab_by_id(self, lab_id: str) -> Lab | None:
        """
        Find a lab by its ID from API.

        Args:
            lab_id: The lab identifier

        Returns:
            Lab object or None if not found
        """
        try:
            lab_data = await api_client.get_lab(lab_id)
            return Lab(lab_data)
        except Exception:
            return None

    async def list_labs(self, phase: int | None = None) -> None:
        """
        Display available labs.

        Args:
            phase: Filter by phase number
        """
        await self.load_labs(phase)

        if not self.labs:
            console.print("[yellow]No labs found.[/yellow]")
            console.print(
                "[dim]Make sure the API server is reachable.[/dim]"
            )
            return

        table = Table(title="Available Labs")
        table.add_column("ID", style="cyan")
        table.add_column("Title", style="white")
        table.add_column("Phase", style="magenta")
        table.add_column("Level", style="yellow")
        table.add_column("Time", style="dim")

        # Add testing guide as first row
        table.add_row(
            "how-to-test-labs",
            "How to Test Labs Without Cloud Costs",
            "-",
            "All",
            "5 min read",
        )

        for lab in self.labs:
            table.add_row(
                lab.id,
                lab.title,
                str(lab.phase),
                lab.level.replace("_", " ").title(),
                lab.estimated_time,
            )

        console.print(table)
        console.print()
        console.print(
            "[dim]View the testing guide: [cyan]devops-dojo lab how-to-test-labs[/cyan] or [cyan]devops-dojo lab info how-to-test-labs[/cyan][/dim]"
        )

    async def show_lab_info(self, lab_id: str) -> None:
        """
        Display detailed information about a lab.

        Args:
            lab_id: The lab identifier
        """
        # Handle special case: testing guide
        if lab_id == "how-to-test-labs":
            await self.show_testing_guide()
            return

        lab = await self.get_lab_by_id(lab_id)
        if not lab:
            console.print(f"[red]Lab '{lab_id}' not found.[/red]")
            return

        # Build sections for pagination
        sections = []

        # Section 1: Title and Description
        section1 = []
        section1.append(
            Panel(
                f"[bold]{lab.title}[/bold]\n\n"
                f"[dim]Phase {lab.phase} | {lab.level.replace('_', ' ').title()} | {lab.estimated_time}[/dim]",
                title=f"Lab: {lab.id}",
                border_style="blue",
            )
        )
        section1.append("\n[bold]Description:[/bold]")
        section1.append(lab.description)
        if lab.topics:
            section1.append("\n[bold]Topics:[/bold]")
            section1.append(", ".join(lab.topics))
        sections.append(section1)

        # Section 2: Requirements
        section2 = []
        section2.append("[bold]Requirements:[/bold]\n")
        if lab.requirements.get("must_have"):
            section2.append("[green]Must Have:[/green]")
            for key, desc in lab.requirements["must_have"].items():
                section2.append(f"  - [cyan]{key}[/cyan]: {desc}")
        sections.append(section2)

        # Section 3: Should Have (if exists)
        if lab.requirements.get("should_have"):
            section3 = []
            section3.append("[yellow]Should Have:[/yellow]")
            for key, desc in lab.requirements["should_have"].items():
                section3.append(f"  - [cyan]{key}[/cyan]: {desc}")
            sections.append(section3)

        # Section 4: Bonus (if exists)
        if lab.requirements.get("bonus"):
            section4 = []
            section4.append("[magenta]Bonus:[/magenta]")
            for key, desc in lab.requirements["bonus"].items():
                section4.append(f"  - [cyan]{key}[/cyan]: {desc}")
            sections.append(section4)

        # Section 5: Scoring
        if lab.scoring:
            section5 = []
            section5.append("[bold]Scoring:[/bold]")
            for category, points in lab.scoring.items():
                section5.append(f"  - {category.replace('_', ' ').title()}: {points} points")
            section5.append(f"\n[dim]Passing score: {lab.passing_score}/100[/dim]")
            sections.append(section5)

        # Display sections with pagination
        for i, section in enumerate(sections):
            console.print()
            for item in section:
                if isinstance(item, Panel):
                    console.print(item)
                else:
                    console.print(item)

            # Show pagination prompt (except for last section)
            if i < len(sections) - 1:
                console.print()
                console.print(
                    "[dim]Press [cyan]Space[/cyan], [cyan]Enter[/cyan], or [cyan]Down[/cyan] for next section | [cyan]q[/cyan] to quit[/dim]"
                )

                try:
                    # Wait for keypress
                    while True:
                        k = readchar.readkey()

                        # Handle quit
                        if k in ("q", "Q"):
                            return  # Exit the function entirely
                        # Handle next: Space, Enter, Down arrow
                        elif k == " ":  # Space
                            break
                        elif k in ("\r", "\n"):  # Enter
                            break
                        elif k == special_keys.DOWN:  # Down arrow
                            break
                        elif k == special_keys.SPACE:  # Alternative space constant
                            break
                    # Clear the prompt lines using direct stdout (Rich escapes ANSI codes)
                    sys.stdout.write("\033[F\033[K\033[F\033[K")
                    sys.stdout.flush()
                except Exception as e:
                    # Fallback if readchar doesn't work
                    console.print(f"[dim]Note: Keyboard navigation unavailable ({e})[/dim]")
                    choice = Prompt.ask(
                        "",
                        choices=["", "q"],
                        default="",
                        show_choices=False,
                    )
                    if choice == "q":
                        return

        console.print()

    async def submit_lab(self, lab_id: str, repo_url: str) -> None:
        """
        Submit a lab solution for evaluation using V2 API.

        Args:
            lab_id: The lab identifier
            repo_url: GitHub repository URL with the solution
        """
        # Get lab info for display (passing_score)
        lab = await self.get_lab_by_id(lab_id)
        if not lab:
            console.print(f"[red]Lab '{lab_id}' not found.[/red]")
            return

        console.print(
            Panel(
                f"[bold]Submitting solution for: {lab.title}[/bold]\n\n"
                f"Repository: {repo_url}",
                title="Lab Submission",
                border_style="cyan",
            )
        )

        console.print()
        console.print("[dim]Evaluating your submission...[/dim]")
        console.print("[dim]This may take a moment.[/dim]")

        try:
            # Use V2 API - server looks up requirements
            result = await api_client.evaluate_repo_v2(
                lab_id=lab_id,
                repo_url=repo_url,
            )

            self._display_evaluation(result, lab)

            # Track progress
            progress_tracker.record_lab(
                lab_id=lab_id,
                score=result["score"],
                passed=result["passed"],
            )

        except Exception as e:
            console.print(f"[red]Error evaluating submission: {e}[/red]")
            console.print(
                "[yellow]Make sure the API server is running and the repository is public.[/yellow]"
            )

    def _display_evaluation(self, result: dict[str, Any], lab: Lab) -> None:
        """Display the evaluation results."""
        score = result["score"]
        passed = result["passed"]

        # Determine color based on pass/fail
        color = "green" if passed else "red"
        status = "PASSED" if passed else "FAILED"

        # Score panel
        console.print()
        console.print(
            Panel(
                f"[bold {color}]Score: {score}/100 - {status}[/bold {color}]\n\n"
                f"[dim]Passing score: {lab.passing_score}[/dim]",
                title="Evaluation Result",
                border_style=color,
            )
        )

        # Score breakdown
        breakdown = result.get("breakdown", {})
        if breakdown:
            console.print()
            table = Table(title="Score Breakdown")
            table.add_column("Category", style="cyan")
            table.add_column("Score", style="white")
            table.add_column("Max", style="dim")

            categories = [
                ("requirements_met", "Requirements Met", 40),
                ("code_quality", "Code Quality", 20),
                ("security", "Security", 20),
                ("documentation", "Documentation", 10),
                ("bonus", "Bonus", 10),
            ]

            for key, name, max_score in categories:
                actual = breakdown.get(key, 0)
                table.add_row(name, str(actual), str(max_score))

            console.print(table)

        # Files analyzed
        if result.get("files_analyzed"):
            console.print()
            console.print("[bold]Files Analyzed:[/bold]")
            for file in result["files_analyzed"]:
                console.print(f"  - {file}")

        # Issues
        if result.get("issues"):
            console.print()
            console.print("[red]Issues Found:[/red]")
            for issue in result["issues"]:
                console.print(f"  x {issue}")

        # Recommendations
        if result.get("recommendations"):
            console.print()
            console.print("[yellow]Recommendations:[/yellow]")
            for rec in result["recommendations"]:
                console.print(f"  -> {rec}")

    async def show_testing_guide(self) -> None:
        """Display the lab testing guide from API."""
        try:
            response = await api_client.get_testing_guide()
            content = response.get("content", "")

            if not content:
                console.print("[red]Testing guide not found.[/red]")
                return

            # Display title panel
            console.print()
            console.print(
                Panel(
                    "How to Test Labs Without Cloud Costs",
                    style="bold cyan",
                    border_style="cyan",
                )
            )
            console.print()

            # Split content into sections for manual pagination
            sections = content.split('\n## ')

            for i, section in enumerate(sections):
                if i == 0:
                    # First section doesn't have ## prefix
                    md = Markdown(section)
                else:
                    # Add back the ## prefix
                    md = Markdown(f"## {section}")

                console.print(md)

                # Show pagination prompt (except for last section)
                if i < len(sections) - 1:
                    console.print()
                    console.print(
                        "[dim]Press [cyan]Space[/cyan], [cyan]Enter[/cyan], or [cyan]Down[/cyan] for next section | [cyan]q[/cyan] to quit[/dim]"
                    )

                    try:
                        # Wait for keypress
                        while True:
                            k = readchar.readkey()

                            # Handle quit
                            if k in ("q", "Q"):
                                return  # Exit the function entirely
                            # Handle next: Space, Enter, Down arrow
                            elif k == " ":  # Space
                                break
                            elif k in ("\r", "\n"):  # Enter
                                break
                            elif k == special_keys.DOWN:  # Down arrow
                                break
                            elif k == special_keys.SPACE:  # Alternative space constant
                                break
                        # Clear the prompt lines using direct stdout (Rich escapes ANSI codes)
                        sys.stdout.write("\033[F\033[K\033[F\033[K")
                        sys.stdout.flush()
                    except Exception as e:
                        # Fallback if readchar doesn't work
                        console.print(f"[dim]Note: Keyboard navigation unavailable ({e})[/dim]")
                        choice = Prompt.ask(
                            "",
                            choices=["", "q"],
                            default="",
                            show_choices=False,
                        )
                        if choice == "q":
                            return

            console.print()

        except Exception as e:
            console.print(f"[red]Error fetching testing guide: {e}[/red]")
            console.print("[yellow]Make sure the API server is reachable.[/yellow]")


# Global instance
lab_mode = LabMode()
