"""Progress tracking for DevOps Dojo."""

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from devops_dojo.config import get_data_dir

console = Console()


class ProgressTracker:
    """Tracks user progress through interviews and labs."""

    def __init__(self) -> None:
        self.data_file = get_data_dir() / "progress.json"
        self._ensure_data_file()

    def _ensure_data_file(self) -> None:
        """Create data file if it doesn't exist."""
        if not self.data_file.exists():
            self._save_data(self._empty_data())

    def _empty_data(self) -> dict[str, Any]:
        """Return empty progress data structure."""
        return {
            "interviews": [],
            "labs": [],
            "stats": {
                "total_questions": 0,
                "total_labs": 0,
                "topics": {},
            },
        }

    def _load_data(self) -> dict[str, Any]:
        """Load progress data from file."""
        if not self.data_file.exists():
            return self._empty_data()

        with open(self.data_file) as f:
            return json.load(f)

    def _save_data(self, data: dict[str, Any]) -> None:
        """Save progress data to file."""
        with open(self.data_file, "w") as f:
            json.dump(data, f, indent=2, default=str)

    def record_answer(
        self,
        question_id: str,
        topic: str,
        level: str,
        score: int,
    ) -> None:
        """
        Record an interview answer result.

        Args:
            question_id: The question identifier
            topic: Question topic
            level: Question level
            score: Score achieved
        """
        data = self._load_data()

        record = {
            "question_id": question_id,
            "topic": topic,
            "level": level,
            "score": score,
            "timestamp": datetime.now().isoformat(),
        }

        data["interviews"].append(record)
        data["stats"]["total_questions"] += 1

        # Update topic stats
        if topic not in data["stats"]["topics"]:
            data["stats"]["topics"][topic] = {
                "questions": 0,
                "total_score": 0,
                "labs_passed": 0,
            }

        data["stats"]["topics"][topic]["questions"] += 1
        data["stats"]["topics"][topic]["total_score"] += score

        self._save_data(data)

    def record_lab(
        self,
        lab_id: str,
        score: int,
        passed: bool,
    ) -> None:
        """
        Record a lab submission result.

        Args:
            lab_id: The lab identifier
            score: Score achieved
            passed: Whether the lab was passed
        """
        data = self._load_data()

        record = {
            "lab_id": lab_id,
            "score": score,
            "passed": passed,
            "timestamp": datetime.now().isoformat(),
        }

        data["labs"].append(record)
        data["stats"]["total_labs"] += 1

        self._save_data(data)

    def get_summary(self) -> dict[str, Any]:
        """Get a summary of progress."""
        data = self._load_data()

        interviews = data.get("interviews", [])
        labs = data.get("labs", [])

        summary = {
            "total_questions": len(interviews),
            "total_labs": len(labs),
            "average_score": 0,
            "labs_passed": sum(1 for l in labs if l.get("passed")),
            "topics": {},
        }

        if interviews:
            summary["average_score"] = sum(i["score"] for i in interviews) / len(interviews)

        # Group by topic
        for interview in interviews:
            topic = interview["topic"]
            if topic not in summary["topics"]:
                summary["topics"][topic] = {
                    "questions": 0,
                    "average_score": 0,
                    "scores": [],
                }
            summary["topics"][topic]["questions"] += 1
            summary["topics"][topic]["scores"].append(interview["score"])

        # Calculate topic averages
        for topic, stats in summary["topics"].items():
            if stats["scores"]:
                stats["average_score"] = sum(stats["scores"]) / len(stats["scores"])
            del stats["scores"]

        return summary

    def get_weak_areas(self) -> list[dict[str, Any]]:
        """Identify areas that need improvement."""
        summary = self.get_summary()
        weak_areas = []

        for topic, stats in summary["topics"].items():
            if stats["average_score"] < 70 and stats["questions"] >= 2:
                weak_areas.append({
                    "topic": topic,
                    "average_score": stats["average_score"],
                    "questions_attempted": stats["questions"],
                })

        # Sort by average score (lowest first)
        weak_areas.sort(key=lambda x: x["average_score"])
        return weak_areas

    def get_history(self, limit: int = 20) -> list[dict[str, Any]]:
        """
        Get recent activity history.

        Args:
            limit: Maximum number of records to return

        Returns:
            List of recent activities
        """
        data = self._load_data()

        # Combine interviews and labs
        history = []

        for interview in data.get("interviews", []):
            history.append({
                "type": "interview",
                "id": interview["question_id"],
                "topic": interview["topic"],
                "level": interview.get("level", "unknown"),
                "score": interview["score"],
                "timestamp": interview["timestamp"],
            })

        for lab in data.get("labs", []):
            history.append({
                "type": "lab",
                "id": lab["lab_id"],
                "score": lab["score"],
                "passed": lab["passed"],
                "timestamp": lab["timestamp"],
            })

        # Sort by timestamp descending
        history.sort(key=lambda x: x["timestamp"], reverse=True)
        return history[:limit]

    def display_summary(self) -> None:
        """Display a progress summary."""
        summary = self.get_summary()
        data = self._load_data()

        # Main stats
        console.print(
            Panel(
                f"[bold]Questions Answered:[/bold] {summary['total_questions']}\n"
                f"[bold]Labs Completed:[/bold] {summary['total_labs']}\n"
                f"[bold]Labs Passed:[/bold] {summary['labs_passed']}\n"
                f"[bold]Average Score:[/bold] {summary['average_score']:.1f}/100",
                title="Progress Summary",
                border_style="blue",
            )
        )

        # Level breakdown
        interviews = data.get("interviews", [])
        if interviews:
            level_stats: dict[str, dict] = {}
            for interview in interviews:
                level = interview.get("level", "unknown")
                if level not in level_stats:
                    level_stats[level] = {"count": 0, "total_score": 0}
                level_stats[level]["count"] += 1
                level_stats[level]["total_score"] += interview["score"]

            console.print()
            level_table = Table(title="Performance by Level")
            level_table.add_column("Level", style="yellow")
            level_table.add_column("Questions", style="white")
            level_table.add_column("Avg Score", style="white")

            level_order = ["engineer", "sr_engineer", "expert"]
            for level in level_order:
                if level in level_stats:
                    stats = level_stats[level]
                    avg = stats["total_score"] / stats["count"]
                    level_table.add_row(
                        level.replace("_", " ").title(),
                        str(stats["count"]),
                        f"{avg:.1f}",
                    )

            console.print(level_table)

        # Topic breakdown
        if summary["topics"]:
            console.print()
            table = Table(title="Performance by Topic")
            table.add_column("Topic", style="cyan")
            table.add_column("Questions", style="white")
            table.add_column("Avg Score", style="white")
            table.add_column("Status", style="white")

            for topic, stats in sorted(summary["topics"].items()):
                avg = stats["average_score"]
                if avg >= 80:
                    status = "[green]Strong[/green]"
                elif avg >= 60:
                    status = "[yellow]Improving[/yellow]"
                else:
                    status = "[red]Needs Work[/red]"

                table.add_row(
                    topic.title(),
                    str(stats["questions"]),
                    f"{avg:.1f}",
                    status,
                )

            console.print(table)

    def display_weak_areas(self) -> None:
        """Display areas that need improvement."""
        weak_areas = self.get_weak_areas()

        if not weak_areas:
            console.print(
                "[green]No weak areas identified yet. Keep practicing![/green]"
            )
            return

        console.print(
            Panel(
                "[bold]Topics that need more practice:[/bold]",
                title="Weak Areas",
                border_style="yellow",
            )
        )

        for area in weak_areas:
            console.print(
                f"\n[red]•[/red] [bold]{area['topic'].title()}[/bold]\n"
                f"  Average Score: {area['average_score']:.1f}/100\n"
                f"  Questions Attempted: {area['questions_attempted']}"
            )

    def display_history(self, limit: int = 20) -> None:
        """Display recent activity history."""
        history = self.get_history(limit)

        if not history:
            console.print("[dim]No activity recorded yet.[/dim]")
            return

        table = Table(title="Recent Activity")
        table.add_column("Type", style="cyan")
        table.add_column("Topic/ID", style="white")
        table.add_column("Level", style="yellow")
        table.add_column("Score", style="white")
        table.add_column("Date", style="dim")

        for item in history:
            type_str = "Interview" if item["type"] == "interview" else "Lab"
            score_str = str(item["score"])

            # Format level
            level_str = item.get("level", "-")
            if level_str and level_str != "-":
                level_str = level_str.replace("_", " ").title()

            if item["type"] == "lab":
                if item.get("passed"):
                    score_str = f"[green]{score_str} Pass[/green]"
                else:
                    score_str = f"[red]{score_str} Fail[/red]"

            # Format timestamp
            ts = datetime.fromisoformat(item["timestamp"])
            date_str = ts.strftime("%Y-%m-%d %H:%M")

            table.add_row(
                type_str,
                item.get("topic", item["id"]).title() if item.get("topic") else item["id"],
                level_str,
                score_str,
                date_str,
            )

        console.print(table)

    def reset(self) -> None:
        """Reset all progress data."""
        self._save_data(self._empty_data())
        console.print("[green]Progress data has been reset.[/green]")


# Global instance
progress_tracker = ProgressTracker()
