"""Report generation for DevOps Dojo."""

from devops_dojo.reports.generator import ReportGenerator

__all__ = ["ReportGenerator"]
