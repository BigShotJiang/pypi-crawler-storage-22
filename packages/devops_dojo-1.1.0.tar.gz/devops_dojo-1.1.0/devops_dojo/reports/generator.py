"""HTML report generation using Jinja2."""

from datetime import datetime
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, select_autoescape

from devops_dojo.modes.progress import progress_tracker


class ReportGenerator:
    """Generates HTML reports from progress data."""

    def __init__(self) -> None:
        """Initialize the report generator."""
        templates_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(templates_dir),
            autoescape=select_autoescape(["html", "xml"]),
        )

    def generate_progress_report(self, output_path: Path | None = None) -> Path:
        """
        Generate an HTML progress report.

        Args:
            output_path: Optional path for the output file

        Returns:
            Path to the generated report
        """
        summary = progress_tracker.get_summary()
        history = progress_tracker.get_history(50)
        weak_areas = progress_tracker.get_weak_areas()

        template = self.env.get_template("progress.html")
        html = template.render(
            summary=summary,
            history=history,
            weak_areas=weak_areas,
            generated_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )

        if output_path is None:
            output_path = Path.cwd() / "reports" / f"progress_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"

        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w") as f:
            f.write(html)

        return output_path

    def generate_evaluation_report(
        self,
        evaluation_type: str,
        evaluation_data: dict[str, Any],
        output_path: Path | None = None,
    ) -> Path:
        """
        Generate an HTML evaluation report.

        Args:
            evaluation_type: Type of evaluation ("interview" or "lab")
            evaluation_data: The evaluation results
            output_path: Optional path for the output file

        Returns:
            Path to the generated report
        """
        template = self.env.get_template("evaluation.html")
        html = template.render(
            evaluation_type=evaluation_type,
            data=evaluation_data,
            generated_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )

        if output_path is None:
            output_path = Path.cwd() / "reports" / f"{evaluation_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"

        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w") as f:
            f.write(html)

        return output_path


# Global instance
report_generator = ReportGenerator()
