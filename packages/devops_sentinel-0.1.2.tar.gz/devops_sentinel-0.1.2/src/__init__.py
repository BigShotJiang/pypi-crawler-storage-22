"""DevOps Sentinel - Autonomous SRE Agents"""

__version__ = "0.1.0"
