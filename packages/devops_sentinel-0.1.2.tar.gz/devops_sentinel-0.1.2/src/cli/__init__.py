"""DevOps Sentinel CLI Package"""

from .main import cli

__all__ = ['cli']
