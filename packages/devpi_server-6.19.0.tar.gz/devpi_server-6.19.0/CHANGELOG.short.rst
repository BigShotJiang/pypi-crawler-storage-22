

=========
Changelog
=========




.. towncrier release notes start

6.19.0 (2026-02-06)
===================

Features
--------

- Add ``--autocreate-users`` server option.
  Automatically creates users that don't exist in devpi, but have successfully authenticated via an authentication plugin.
  A typical example of when to enable this would be when authenticating via an LDAP directory.
  Automatically created users do not have passwords, and have no password hash to prevent local authentication.

- Add ``replica-files-in-sync-at``, ``replica-init-queue-finished-at`` and ``replica-metadata-in-sync-at`` to status view, the existing ``replica-in-sync-at`` is now a combination of all three instead of just metadata.

- Warn when an unknown option is found in config file to detect typos. Be aware that some commands don't use all the options, that is why this only warns instead of exiting.

- Add new ``devpiserver_user_created`` hook which can be used to create default indexes or other setup for newly created users.

Bug Fixes
---------

- Fix ``+status`` json encoding errors by making sure the ``FatalResponse.url`` attribute is a string.

- Ignore existing unknown index options from uninstalled plugins when patching other options with ``+=`` and ``-=``.

- Fix removal with ``-=`` of index options with default values from ``devpiserver_indexconfig_defaults`` hooks.

- Fix #1110: a list for the ``listen`` option in a config file stopped working in 6.18.0.


6.18.0 (2026-01-27)
===================

Features
--------

- Store all available hashes of files.

- Validate hashes of all files during devpi-import, not only releases.

Bug Fixes
---------

- Apply argparse transformations on values read from config file or environment.

- Restore Python and platform info in user agent string after switch to httpx.

- Remove all database entries on project deletion instead of only emptying them.

- Fix error at end of replica streaming caused by changed behavior from switch to httpx.

- Fix #1102: The data stream was cut off after 64k when proxying from replica to primary after switching to httpx.

- Fix #1107: retry file downloads if there has been an error during download.

Other Changes
-------------

- The filenames of some exported doczip files change due to normalization of the project name caused by changing the internals during export to allow ``--hard-links`` to work.


6.17.0 (2025-08-27)
===================

Deprecations and Removals
-------------------------

- Dropped support for migrating old password hashes that were replaced in devpi-server 4.2.0.

- Removed support for basic authorization in primary URL. The connection is already secured by a bearer token header.

- Removed the experimental ``--replica-cert`` option. The replica is already using a token via a shared secret, so this is redundant.

- Removed ``--replica-max-retries`` option. It wasn't implemented for async_httpget and didn't work correctly when streaming data.

Features
--------

- Use httpx for all data fetching for mirrors and fetch projects list asynchronously to allow update in background even after a timeout.

- Use httpx instead of requests when proxying from replicas to primary.

- Use httpx for all requests from replicas to primary.

- Use httpx when pushing releases to external index.

- Added ``mirror_ignore_serial_header`` mirror index option, which allows switching from PyPI to a mirror without serials header when set to ``True``, otherwise only stale links will be served and no updates be stored.

- The HTTP cache information for mirrored projects is persisted and re-used on server restarts.

- Added ``--file-replication-skip-indexes`` option to skip file replication for ``all``, by index type (i.e. ``mirror``) or index name (i.e. ``root/pypi``).

Bug Fixes
---------

- Correctly handle lists for ``Provides-Extra`` and ``License-File`` metadata in database.

- Fix traceback by returning 401 error code when using wrong password with a user that was created using an authentication plugin like devpi-ldap which passes authentication through in that case.

- Fix #1053: allow users to update their passwords when ``--restrict-modify`` is used.

- Fix #1097: return 404 when trying to POST to +simple.

Other Changes
-------------

- Changed User-Agent when fetching data for mirrors from just "server" to "devpi-server".


6.16.0 (2025-06-25)
===================

Deprecations and Removals
-------------------------

- Dropped support for Python 3.7 and 3.8.

Features
--------

- Update stored package metadata fields to version 2.4 for license expressions (PEP 639).

Bug Fixes
---------

- Preserve hash when importing mirror data to prevent unnecessary updates later on.

- Keep original metadata_version in database.


6.15.0 (2025-05-18)
===================

Features
--------

- Add ``--connection-limit`` option to devpi-server passed on to waitress.

