# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2026 devqubit

"""
Result processing for Qiskit adapter.

Extracts and normalizes measurement results from Qiskit jobs,
producing structures compatible with the devqubit Uniform Execution
Contract (UEC).
"""

from __future__ import annotations

import logging
from typing import Any

from devqubit_engine.uec.models.result import ResultType
from devqubit_engine.utils.serialization import to_jsonable


logger = logging.getLogger(__name__)


# =============================================================================
# Result Type Detection
# =============================================================================


def detect_result_type(result: Any) -> ResultType:
    """
    Detect the result type from a Qiskit result object.

    Handles counts, quasi-distributions, expectation values,
    statevectors, and density matrices.

    Parameters
    ----------
    result : Any
        Qiskit Result object.

    Returns
    -------
    ResultType
        Detected result type.
    """
    if result is None:
        return ResultType.OTHER

    # Check for quasi-distributions (Runtime Sampler) — attribute check only
    if getattr(result, "quasi_dists", None) is not None:
        return ResultType.QUASI_DIST

    # Check for expectation values (Runtime Estimator) — attribute check only
    if getattr(result, "values", None) is not None:
        return ResultType.EXPECTATION

    # Check for statevector (simulator) — method presence only, no call
    if hasattr(result, "get_statevector") and callable(
        getattr(result, "get_statevector", None)
    ):
        # Peek at result data to confirm statevector without triggering computation
        try:
            results_list = getattr(result, "results", None)
            if results_list and hasattr(results_list[0], "data"):
                data = results_list[0].data
                if hasattr(data, "statevector"):
                    return ResultType.STATEVECTOR
        except (AttributeError, IndexError, TypeError) as e:
            logger.debug("Failed to detect result type: %s", e)

    # Check for measurement counts — method presence, fall back to result structure
    if hasattr(result, "get_counts") and callable(getattr(result, "get_counts", None)):
        return ResultType.COUNTS

    return ResultType.OTHER


# =============================================================================
# Counts Extraction
# =============================================================================


def normalize_result_counts(result: Any) -> dict[str, Any]:
    """
    Extract and normalize measurement counts from a Qiskit result.

    Parameters
    ----------
    result : Any
        Qiskit Result object from job.result().

    Returns
    -------
    dict
        Normalized counts with structure::

            {
                "experiments": [
                    {"index": 0, "counts": {"00": 500, "11": 500}, "shots": 1000},
                    ...
                ]
            }

    Notes
    -----
    Qiskit's Result.get_counts() supports selecting an experiment by index.
    This function iterates through all experiments to extract counts.
    """
    output: dict[str, Any] = {"experiments": []}

    if result is None:
        return output

    # Determine number of experiments
    num_experiments = _get_num_experiments(result)

    # Single experiment fallback
    if num_experiments is None:
        exp = _extract_single_experiment(result)
        if exp:
            output["experiments"].append(exp)
        return output

    # Multiple experiments
    for idx in range(int(num_experiments)):
        exp = _extract_experiment_by_index(result, idx)
        if exp:
            output["experiments"].append(exp)

    return output


def _get_num_experiments(result: Any) -> int | None:
    """Get number of experiments from result."""
    try:
        if hasattr(result, "results") and result.results is not None:
            return len(result.results)
    except (AttributeError, TypeError) as e:
        logger.debug("Failed to get num_experiments: %s", e)
    return None


def _extract_single_experiment(result: Any) -> dict[str, Any] | None:
    """Extract counts from a single-experiment result."""
    try:
        if hasattr(result, "get_counts") and callable(result.get_counts):
            counts = result.get_counts()
            counts_dict = to_jsonable(counts)
            shots = sum(counts_dict.values()) if isinstance(counts_dict, dict) else None
            return {"index": 0, "counts": counts_dict, "shots": shots}
    except Exception as e:
        logger.debug("Failed to extract single experiment counts: %s", e)
    return None


def _extract_experiment_by_index(result: Any, idx: int) -> dict[str, Any] | None:
    """Extract counts for a specific experiment index."""
    try:
        counts = result.get_counts(idx)
        counts_dict = to_jsonable(counts)
        shots = sum(counts_dict.values()) if isinstance(counts_dict, dict) else None

        exp_data: dict[str, Any] = {"index": idx, "counts": counts_dict, "shots": shots}

        # Try to get experiment name
        try:
            if hasattr(result.results[idx], "header"):
                name = getattr(result.results[idx].header, "name", None)
                if name:
                    exp_data["name"] = str(name)
        except (AttributeError, IndexError, TypeError) as e:
            logger.debug("Failed to get experiment name: %s", e)

        return exp_data
    except (AttributeError, IndexError, TypeError) as e:
        logger.debug("Failed to get experiment name: %s", e)
        return None


# =============================================================================
# Result Metadata
# =============================================================================


def extract_result_metadata(result: Any) -> dict[str, Any]:
    """
    Extract metadata from a Qiskit result object.

    Parameters
    ----------
    result : Any
        Qiskit Result object.

    Returns
    -------
    dict
        Result metadata including backend name, job ID, success status,
        and execution timestamps.
    """
    metadata: dict[str, Any] = {}

    if result is None:
        return metadata

    attrs = [
        ("backend_name", str),
        ("job_id", str),
        ("success", bool),
        ("status", str),
        ("date", str),
        ("time_taken", float),
    ]

    for attr, converter in attrs:
        val = _safe_getattr(result, attr, converter)
        if val is not None:
            metadata[attr] = val

    return metadata


def _safe_getattr(obj: Any, attr: str, converter: type | None = None) -> Any | None:
    """Safely get and optionally convert an attribute value."""
    try:
        val = getattr(obj, attr, None)
        if val is None:
            return None
        if converter is not None:
            return converter(val)
        return val
    except (AttributeError, TypeError, ValueError) as e:
        logger.debug("Failed to extract result field: %s", e)
        return None


# =============================================================================
# Quasi-Distribution Extraction
# =============================================================================


def extract_quasi_distributions(result: Any) -> list[dict[str, float]] | None:
    """
    Extract quasi-probability distributions from a Qiskit result.

    This is primarily used for results from Qiskit Runtime Sampler
    which returns quasi-distributions rather than raw counts.

    Parameters
    ----------
    result : Any
        Qiskit result object (typically SamplerResult).

    Returns
    -------
    list of dict or None
        List of quasi-distributions (one per circuit), or None if
        not available.

    Notes
    -----
    Quasi-distributions can have negative values for error-mitigated
    results. The values should sum to approximately 1.0.
    """
    if result is None:
        return None

    quasi_dists: list[dict[str, float]] = []

    try:
        if hasattr(result, "quasi_dists") and result.quasi_dists is not None:
            for qd in result.quasi_dists:
                if hasattr(qd, "binary_probabilities") and callable(
                    qd.binary_probabilities
                ):
                    quasi_dists.append(dict(qd.binary_probabilities()))
                elif isinstance(qd, dict):
                    if qd:
                        max_key = max(qd.keys())
                        # bit_length() returns 0 for key 0; ensure at least 1 bit
                        num_bits = max(max_key.bit_length(), 1) if max_key >= 0 else 1
                    else:
                        num_bits = 1
                    quasi_dists.append(
                        {format(k, f"0{num_bits}b"): v for k, v in qd.items()}
                    )
            if quasi_dists:
                return quasi_dists
    except (AttributeError, TypeError, ValueError) as e:
        logger.debug("Failed to extract quasi-distributions: %s", e)

    return None


def extract_expectation_values(
    result: Any,
) -> list[tuple[float, float | None]] | None:
    """
    Extract expectation values from a Qiskit Estimator result.

    Parameters
    ----------
    result : Any
        Qiskit result object (typically EstimatorResult).

    Returns
    -------
    list of tuple or None
        List of (value, std_error) tuples for each observable,
        or None if not available.
    """
    if result is None:
        return None

    try:
        if hasattr(result, "values") and result.values is not None:
            values = list(result.values)
            std_errors: list[float | None]
            if (
                hasattr(result, "metadata")
                and result.metadata
                and len(result.metadata) > 0
            ):
                std_errors = list(result.metadata[0].get("std_error", []))
            else:
                std_errors = [None] * len(values)
            return list(zip(values, std_errors))
    except (AttributeError, KeyError, TypeError, ValueError) as e:
        logger.debug("Failed to extract estimator values: %s", e)

    return None


# =============================================================================
# Primitive Result Normalization
# =============================================================================


def normalize_primitive_result(result: Any) -> dict[str, Any]:
    """
    Normalize results from Qiskit Runtime primitives.

    Handles SamplerV2 and EstimatorV2 result formats which differ
    from standard Result objects.

    Parameters
    ----------
    result : Any
        Qiskit Runtime primitive result.

    Returns
    -------
    dict
        Normalized result data with type indicator.
    """
    output: dict[str, Any] = {"result_type": "unknown"}

    if result is None:
        return output

    # Handle SamplerV2 results
    quasi_dists = extract_quasi_distributions(result)
    if quasi_dists is not None:
        output["result_type"] = "quasi_dist"
        output["quasi_distributions"] = quasi_dists
        return output

    # Handle EstimatorV2 results
    expectations = extract_expectation_values(result)
    if expectations is not None:
        output["result_type"] = "expectation"
        output["expectation_values"] = [
            {"value": v, "std_error": e} for v, e in expectations
        ]
        return output

    # Fallback to counts
    counts_data = normalize_result_counts(result)
    if counts_data.get("experiments"):
        output["result_type"] = "counts"
        output["experiments"] = counts_data["experiments"]
        return output

    return output
