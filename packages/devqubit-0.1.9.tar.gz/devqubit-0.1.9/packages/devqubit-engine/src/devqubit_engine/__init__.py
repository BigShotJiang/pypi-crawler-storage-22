"""
Internal implementation package for devqubit.

This package is installed as a dependency of `devqubit` and is not considered
part of the stable public API. Prefer importing from `devqubit`.
"""
