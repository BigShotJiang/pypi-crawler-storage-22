import re
import os
from devsecops_engine_tools.engine_core.src.domain.model.gateway.devops_platform_gateway import DevopsPlatformGateway
from devsecops_engine_tools.engine_utilities.defect_dojo.infraestructure.driver_adapters.cmdb import CmdbRestConsumer
from devsecops_engine_tools.engine_utilities.defect_dojo.domain.request_objects.import_scan import ImportScanRequest
from devsecops_engine_tools.engine_utilities.utils.logger_info import MyLogger
from devsecops_engine_tools.engine_utilities.settings import SETTING_LOGGER

logger = MyLogger.__call__(**SETTING_LOGGER).get_logger()


class CmdbUserCase:
    def __init__(self, rest_consumer_cmdb: CmdbRestConsumer, remote_config_source_gateway: DevopsPlatformGateway, expression) -> None:
        self.__rc_cmdb = rest_consumer_cmdb
        self.__remote_config_source_gateway = remote_config_source_gateway
        self.__expression = expression

    def execute(self, request: ImportScanRequest) -> ImportScanRequest:
        # Connection config map
        remote_config = self.__remote_config_source_gateway.get_remote_config(
            request.remote_config_repo,
            request.remote_config_path,
            request.remote_config_branch,
        )

        request.code_app = (
            os.environ.get(request.variable_code_app)
            if request.variable_code_app
            else self.get_code_app(request.engagement_name)
        )

        # connect cmdb
        product_data = self.__rc_cmdb.get_product_info(request)
        search_type_product = next(
            (
                key
                for key, list in remote_config.get("products_sync_with_other_productype", {}).items()
                if request.code_app in list
            ),
            None,
        )
        if search_type_product:
            request.product_type_name = search_type_product
        else:
            request.product_type_name = (
                remote_config["types_product"].get(product_data.product_type_name, product_data.product_type_name)
                if product_data.product_type_name
                else remote_config["types_product"].get("ORPHAN_PRODUCT_TYPE", "ORPHAN_PRODUCT_TYPE")
            )

        request.product_name = product_data.product_name
        request.product_description = product_data.product_description

        return request

    def get_code_app(self, engagement_name: str):
        m = re.search(r"" + self.__expression, engagement_name, re.IGNORECASE)
        if m is None:
            logger.warning(f"Engagement name {engagement_name} not match whit expression: {self.__expression}")
            return ''
        code_app = m.group(1)
        logger.debug(code_app)
        return code_app.lower()
