# Context extraction adapters
