"""MCP server configuration management."""
