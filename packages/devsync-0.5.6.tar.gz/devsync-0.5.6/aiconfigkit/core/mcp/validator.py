"""MCP server configuration validation."""
