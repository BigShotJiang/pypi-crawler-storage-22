# Devtastic Django Utils

These utils are used in Devtastic Django projects.

## Usage
```python
from devtastic.email import send_templated_email
```