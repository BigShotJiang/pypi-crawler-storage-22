__title__ = "Devtastic utilities for Django, DRF and Python"
__version__ = "1.0.0"
__author__ = "Leon van der Grient"
__license__ = "MIT"

# Version synonym
VERSION = __version__
