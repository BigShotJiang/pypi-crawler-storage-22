import humps
import requests
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.utils.translation import get_language


def send_templated_email(
    to, subject: str, template: str, context=None, attachments=None, **kwargs
):
    """
    Sends an email using the Next.js email service endpoint for generating emails.
    """
    if not context:
        context = {}

    to = to if isinstance(to, list) else [to]

    lang = get_language()

    try:
        res = requests.post(
            settings.EMAIL_TEMPLATE_URL,
            json=humps.camelize(
                {"template_id": template, "data": context, "lang": lang}
            ),
        )
        data = res.json()
    except Exception as e:
        print(e)
        return 0

    email = EmailMultiAlternatives(
        to=to,
        subject=subject,
        body=data["plain"],
        **kwargs,
    )

    email.attach_alternative(data["html"], "text/html")

    if attachments:
        email.attachments = attachments

    return email.send(fail_silently=False)
