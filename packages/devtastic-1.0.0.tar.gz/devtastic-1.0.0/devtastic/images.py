from io import BytesIO

from PIL import Image
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.files.uploadedfile import InMemoryUploadedFile


def create_thumbnail(image, size):

    with Image.open(image) as im:
        # Preserve the format
        original_format = im.format or "JPEG"

        # Create a copy to avoid modifying the original
        im.thumbnail(size, Image.Resampling.LANCZOS)

        # Save to BytesIO buffer
        buffer = BytesIO()

        # Handle RGBA images for JPEG
        if original_format == "JPEG" and im.mode in ("RGBA", "LA", "P"):
            im = im.convert("RGB")

        im.save(buffer, format="AVIF", quality=75)
        buffer.seek(0)

        return ContentFile(buffer.read())


THUMBNAIL_PRESETS = [("LG", 1720), ("MD", 1024), ("SM", 640)]


def create_thumbnails(file, force=False):
    file.seek(0)

    for preset in THUMBNAIL_PRESETS:
        try:
            exists = not force and default_storage.exists(
                f"{file.name}_THUMB_{preset[0]}"
            )

            if exists:
                print(f"Thumbnail {preset} for {file.name} already exists.")
                continue

            thumb = create_thumbnail(file, (preset[1], preset[1]))

            thumb_file = InMemoryUploadedFile(
                thumb,
                None,
                f"{file.name}_THUMB_{preset[0]}",
                "image/avif",
                thumb.tell(),
                None,
            )

            default_storage.save(
                f"{file.name}_THUMB_{preset[0]}",
                thumb_file,
            )
            print(f"Created thumbnail {preset} for {file.name}.")
        except Exception as e:
            print(f"Thumbnail {preset} for {file.name} failed: {e}.")
            continue
