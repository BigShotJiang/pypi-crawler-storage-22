import humps
import requests
from django.conf import settings
from django.utils.translation import get_language


def get_templated_pdf(template: str, context=None, **kwargs):
    """
    Generates a PDF using the Next.js PDF service endpoint.
    """
    if not context:
        context = {}

    lang = get_language()

    try:
        res = requests.post(
            settings.PDF_SERVICE_URL,
            json=humps.camelize(
                {"template_id": template, "data": context, "lang": lang}
            ),
        )
        if res.ok:
            return res.content
        else:
            return None

    except Exception as e:
        print("Could not generate PDF:", e)
        return None
