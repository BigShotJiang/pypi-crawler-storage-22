# devtime-cli ⏱️

Install:

```bash
pip install devtime-cli
```

Run:

```bash
devtime start backend
```


