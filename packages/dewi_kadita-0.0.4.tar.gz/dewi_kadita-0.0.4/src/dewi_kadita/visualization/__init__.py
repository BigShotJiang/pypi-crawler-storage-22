"""Visualization tools for oceanic fish schooling."""

from .animator import Animator

__all__ = ["Animator"]
