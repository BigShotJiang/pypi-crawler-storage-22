# Pre-compiled for IP protection - All Python code is compiled to native binary
import sys
from pathlib import Path
import importlib.machinery
import importlib.util

# Find the compiled implementation module
_module_dir = Path(__file__).parent
_impl_so = _module_dir / 'impl.so' if (_module_dir / 'impl.so').exists() else _module_dir / 'impl.pyd'

if not _impl_so.exists():
    raise ImportError('Implementation module not found')

# Load the implementation module
loader = importlib.machinery.ExtensionFileLoader('dexcomm', str(_impl_so))
_spec = importlib.util.spec_from_loader('dexcomm', loader,  origin=str(_impl_so), is_package=True)
_impl_module = importlib.util.module_from_spec(_spec)

# Add to sys.modules under a different name to avoid recursion
sys.modules['_dexcomm_impl'] = _impl_module

# Execute the module
try:
    _spec.loader.exec_module(_impl_module)
except Exception as e:
    raise ImportError(f'Failed to load implementation module: {e}') from e

# Import Rust core FIRST (these are the optimized implementations)
from dexcomm._core import *
from dexcomm._core import __all__ as _core_all

# Import from implementation module (flattened package structure)
# Get all functions/classes that aren't already in globals from _core
for _name in dir(_impl_module):
    if not _name.startswith('_') and _name not in globals():
        globals()[_name] = getattr(_impl_module, _name)

# Build __all__ from both _core and implementation module
__all__ = list(_core_all)
for _name in dir(_impl_module):
    if not _name.startswith('_') and _name not in __all__:
        __all__.append(_name)
