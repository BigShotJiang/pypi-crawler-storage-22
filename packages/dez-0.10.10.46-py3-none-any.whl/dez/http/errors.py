class HTTPProtocolError(Exception):
    pass
