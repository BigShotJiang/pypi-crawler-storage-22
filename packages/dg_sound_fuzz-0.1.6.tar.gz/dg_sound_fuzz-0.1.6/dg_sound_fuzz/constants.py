class Constants:
    EMPLOYER_COMMON_WORDS = [
        "pvt.ltd.",
        "pvt.ltd",
        "limited.,",
        "limited.",
        "limited,",
        "ltd.,",
        "ltd.",
        "ltd",
        "limited",
        "(l)",
        "private",
        "pvt,",
        "pvt.",
        "pvt",
        "(p)",
    ]
