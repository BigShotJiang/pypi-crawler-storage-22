# DIAAD (Deprecated)

This repository is deprecated and no longer under active development.

The project previously known as **DIAAD (Digital Interface for Aggregate Analysis of Dialog)** has been renamed and substantially revised as:

## **TAALCR**
**Toolkit for Aggregate Analysis of Language in Conversation, for Research**

All current development, documentation, and future releases are available at:

👉 https://github.com/<your-username>/TAALCR

Please update any references or dependencies accordingly.

---

**Author:** Nick McCloskey  
**Contact:** nsm [at] temple.edu
