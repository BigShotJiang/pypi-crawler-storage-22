def FluxInfiniteYouImageProjectorStateDictConverter(state_dict):
    return state_dict['image_proj']