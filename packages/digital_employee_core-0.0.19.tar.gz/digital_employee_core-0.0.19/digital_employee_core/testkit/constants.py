"""Constants for testkit module."""

SEPARATOR_THICK = "=" * 80
SEPARATOR_THIN = "─" * 80
