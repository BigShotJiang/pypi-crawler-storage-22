"""Agents package for digital employee core.

This package provides pre-configured Agent instances for various specialized tasks.
"""

from digital_employee_core.agents.mom_agent import create_mom_agent
from digital_employee_core.agents.mom_docs_agent import create_mom_docs_agent
from digital_employee_core.agents.mom_mail_agent import create_mom_mail_agent

__all__ = [
    "create_mom_agent",
    "create_mom_docs_agent",
    "create_mom_mail_agent",
]
