# SPDX-FileCopyrightText: © 2025 DSLab - Fondazione Bruno Kessler
#
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from digitalhub_runtime_guardrail.entities.run._base.spec import RunSpecGuardrailRun, RunValidatorGuardrailRun


class RunSpecGuardrailRunServe(RunSpecGuardrailRun):
    """RunSpecGuardrailRunServe specifications."""


class RunValidatorGuardrailRunServe(RunValidatorGuardrailRun):
    """RunValidatorGuardrailRunServe validator."""
