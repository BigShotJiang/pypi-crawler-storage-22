"""LCM generated Python bindings for ROS based types."""

__version__ = "0.1.1"
