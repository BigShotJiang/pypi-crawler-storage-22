This file lists all authors who contributed to the code (alphabetical in  each section).
Please contact anyone on this list if you believe you should be included and your name is
not listed.

### Lead developers

* Maximilian Dax
* Stephen Green

### Major contributors

* Nihar Gupte
* Annalena Kofler
* Michael Puerrer
* Jonas Wildberger

### Contributors

* Vincent Berenz
* Samuel Clyne
* Hector Estelles
* Jonathan Gair
