# This import is to try to resolve an incompatibility between lal and pytorch, which
# involves MKL. See https://git.ligo.org/lscsoft/lalsuite/-/issues/300#note_680778.
import lal
