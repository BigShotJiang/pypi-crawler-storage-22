"""
Implements sampling-importance-resampling (sir) for GW posteriors.
"""