# dingtalk-app-accesstoken-refresh

钉钉应用 AccessToken 刷新工具

## 基本逻辑

1. 通过 HTTP 请求获取指定应用的 AccessToken
2. 获取到的 AccessToken 存储到本地文件
3. 在获取 AccessToken 时，先从本地文件获取，如果过期则重新获取

## 安装

```bash
pip install dingtalk-app-accesstoken-refresh
```

## 依赖库

- TinyDB 作为本地存储库

## 使用方法

```python
from dingtalk_app_accesstoken_refresh import (
    CacheSource,
    DingTalkAppAccessTokenRefreshClient,
)

client = DingTalkAppAccessTokenRefreshClient()
client.enable_local_cache('cache.json')
with client.get_access_token(
    client_id='<client_id>',
    client_secret='<client_secret>',
    cache_source=CacheSource.LOCAL,
) as access_token:
    print(access_token)
```
