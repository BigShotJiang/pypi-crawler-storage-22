from enum import StrEnum


class CacheSource(StrEnum):
    """
    缓存源
    """

    LOCAL = 'local'
