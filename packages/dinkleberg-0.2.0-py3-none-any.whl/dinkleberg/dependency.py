class Dependency:
    pass
