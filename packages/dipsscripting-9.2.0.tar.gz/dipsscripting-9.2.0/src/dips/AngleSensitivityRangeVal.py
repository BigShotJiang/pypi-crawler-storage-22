"""Generated wrapper for AngleSensitivityRange protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .AngleDataVal import AngleDataVal

class AngleSensitivityRangeVal:
    """Simple wrapper for AngleSensitivityRange with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.AngleSensitivityRange


    def __init__(self, current: Optional[AngleDataVal] = None, range_from: Optional[AngleDataVal] = None, range_to: Optional[AngleDataVal] = None, interval: Optional[AngleDataVal] = None, proto_message: Optional[Any] = None):
        """Initialize the AngleSensitivityRange wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if current is not None:
            self._proto_message.Current.CopyFrom(current.to_proto())
            self._current_wrapper = current
        if range_from is not None:
            self._proto_message.RangeFrom.CopyFrom(range_from.to_proto())
            self._range_from_wrapper = range_from
        if range_to is not None:
            self._proto_message.RangeTo.CopyFrom(range_to.to_proto())
            self._range_to_wrapper = range_to
        if interval is not None:
            self._proto_message.Interval.CopyFrom(interval.to_proto())
            self._interval_wrapper = interval


    # Properties

    @property
    def apply(self) -> bool:
        """Get the Apply field value."""
        return self._proto_message.Apply
    
    @apply.setter
    def apply(self, value: bool) -> None:
        """Set the Apply field value."""
        self._proto_message.Apply = value


    @property
    def current(self) -> AngleDataVal:
        """Get the Current field as a wrapper."""
        if not hasattr(self, '_current_wrapper'):
            self._current_wrapper = AngleDataVal(proto_message=self._proto_message.Current)
        return self._current_wrapper
    
    @current.setter
    def current(self, value: AngleDataVal) -> None:
        """Set the Current field to a wrapper."""
        self._proto_message.Current.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_current_wrapper'):
            self._current_wrapper._proto_message.CopyFrom(self._proto_message.Current)


    @property
    def range_from(self) -> AngleDataVal:
        """Get the RangeFrom field as a wrapper."""
        if not hasattr(self, '_range_from_wrapper'):
            self._range_from_wrapper = AngleDataVal(proto_message=self._proto_message.RangeFrom)
        return self._range_from_wrapper
    
    @range_from.setter
    def range_from(self, value: AngleDataVal) -> None:
        """Set the RangeFrom field to a wrapper."""
        self._proto_message.RangeFrom.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_range_from_wrapper'):
            self._range_from_wrapper._proto_message.CopyFrom(self._proto_message.RangeFrom)


    @property
    def range_to(self) -> AngleDataVal:
        """Get the RangeTo field as a wrapper."""
        if not hasattr(self, '_range_to_wrapper'):
            self._range_to_wrapper = AngleDataVal(proto_message=self._proto_message.RangeTo)
        return self._range_to_wrapper
    
    @range_to.setter
    def range_to(self, value: AngleDataVal) -> None:
        """Set the RangeTo field to a wrapper."""
        self._proto_message.RangeTo.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_range_to_wrapper'):
            self._range_to_wrapper._proto_message.CopyFrom(self._proto_message.RangeTo)


    @property
    def interval(self) -> AngleDataVal:
        """Get the Interval field as a wrapper."""
        if not hasattr(self, '_interval_wrapper'):
            self._interval_wrapper = AngleDataVal(proto_message=self._proto_message.Interval)
        return self._interval_wrapper
    
    @interval.setter
    def interval(self, value: AngleDataVal) -> None:
        """Set the Interval field to a wrapper."""
        self._proto_message.Interval.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_interval_wrapper'):
            self._interval_wrapper._proto_message.CopyFrom(self._proto_message.Interval)


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
