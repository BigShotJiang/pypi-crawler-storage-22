from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .ArrowToolEntityInfoVal import ArrowToolEntityInfoVal
from .ArrowToolEntityInfoVal import ArrowToolEntityInfoVal
from .ValidatableResultVal import ValidatableResultVal

class ArrowToolEntityInfoRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_ArrowToolEntityInfo):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__RosetteServicesStubLocal = DipsAPI_pb2_grpc.RosetteServicesStub(channelToConnectOn)
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> ArrowToolEntityInfoVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.ArrowToolEntityInfo()
        ret.MergeFromString(bytes.data)
        return ArrowToolEntityInfoVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def DeleteRosetteArrowTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ArrowToolEntityInfo(This=self.__modelRef)
        ret = self.__RosetteServicesStubLocal.DeleteRosetteArrowTool(functionParam)
        

    def SetRosetteArrowToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ArrowToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__RosetteServicesStubLocal.SetRosetteArrowToolVisibility(functionParam)
        

    def UpdateRosetteArrowTool(self,  ArrowToolEntityInfo: ArrowToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ArrowToolEntityInfo_ArrowToolEntityInfo(This=self.__modelRef,  Input1=(ArrowToolEntityInfo.to_proto() if hasattr(ArrowToolEntityInfo, 'to_proto') else ArrowToolEntityInfo))
        ret = self.__RosetteServicesStubLocal.UpdateRosetteArrowTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def DeleteStereonet2DArrowTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ArrowToolEntityInfo(This=self.__modelRef)
        ret = self.__Stereonet2DServicesStubLocal.DeleteStereonet2DArrowTool(functionParam)
        

    def SetStereonet2DArrowToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ArrowToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetStereonet2DArrowToolVisibility(functionParam)
        

    def UpdateStereonet2DArrowTool(self,  ArrowToolEntityInfo: ArrowToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ArrowToolEntityInfo_ArrowToolEntityInfo(This=self.__modelRef,  Input1=(ArrowToolEntityInfo.to_proto() if hasattr(ArrowToolEntityInfo, 'to_proto') else ArrowToolEntityInfo))
        ret = self.__Stereonet2DServicesStubLocal.UpdateStereonet2DArrowTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 