from .DataFormatterVal import DataFormatterVal

TextDataFormatter = DataFormatterVal()
TextDataFormatter.data_format = ""

UnitlessNumericDataFormatter = DataFormatterVal()
UnitlessNumericDataFormatter.data_format = ""

RatioPercentDataFormatter = DataFormatterVal()
RatioPercentDataFormatter.data_format = "%"

LengthMeterDataFormatter = DataFormatterVal()
LengthMeterDataFormatter.data_format = "m"
LengthCentimeterDataFormatter = DataFormatterVal()
LengthCentimeterDataFormatter.data_format = "cm"
LengthKilometerDataFormatter = DataFormatterVal()
LengthKilometerDataFormatter.data_format = "km"
LengthMillimeterDataFormatter = DataFormatterVal()
LengthMillimeterDataFormatter.data_format = "mm"
LengthFootDataFormatter = DataFormatterVal()
LengthFootDataFormatter.data_format = "ft"
LengthInchDataFormatter = DataFormatterVal()
LengthInchDataFormatter.data_format = "in"
LengthMileDataFormatter = DataFormatterVal()
LengthMileDataFormatter.data_format = "mi"

# Angles
AngleDegreeDataFormatter = DataFormatterVal()
AngleDegreeDataFormatter.data_format = "°"
AngleRadianDataFormatter = DataFormatterVal()
AngleRadianDataFormatter.data_format = "rad"

# Areas
AreaSquareKilometerDataFormatter = DataFormatterVal()
AreaSquareKilometerDataFormatter.data_format = "km²"
AreaSquareMeterDataFormatter = DataFormatterVal()
AreaSquareMeterDataFormatter.data_format = "m²"
AreaSquareCentimeterDataFormatter = DataFormatterVal()
AreaSquareCentimeterDataFormatter.data_format = "cm²"
AreaSquareMileDataFormatter = DataFormatterVal()
AreaSquareMileDataFormatter.data_format = "mi²"
AreaSquareFootDataFormatter = DataFormatterVal()
AreaSquareFootDataFormatter.data_format = "ft²"
AreaSquareInchDataFormatter = DataFormatterVal()
AreaSquareInchDataFormatter.data_format = "in²"

# Volumes
VolumeCubicMeterDataFormatter = DataFormatterVal()
VolumeCubicMeterDataFormatter.data_format = "m³"
VolumeCubicFootDataFormatter = DataFormatterVal()
VolumeCubicFootDataFormatter.data_format = "ft³"

# Force
ForceKilonewtonDataFormatter = DataFormatterVal()
ForceKilonewtonDataFormatter.data_format = "kN"
ForceMeganewtonDataFormatter = DataFormatterVal()
ForceMeganewtonDataFormatter.data_format = "MN"
ForceTonneForceDataFormatter = DataFormatterVal()
ForceTonneForceDataFormatter.data_format = "tf"
ForceShortTonForceDataFormatter = DataFormatterVal()
ForceShortTonForceDataFormatter.data_format = "tonf (US)"
ForcePoundForceDataFormatter = DataFormatterVal()
ForcePoundForceDataFormatter.data_format = "lbf"
ForcePoundalDataFormatter = DataFormatterVal()
ForcePoundalDataFormatter.data_format = "pdl"

# Pressure
PressureKilopascalDataFormatter = DataFormatterVal()
PressureKilopascalDataFormatter.data_format = "kPa"
PressureMegapascalDataFormatter = DataFormatterVal()
PressureMegapascalDataFormatter.data_format = "MPa"
PressureTonneForcePerSquareMeterDataFormatter = DataFormatterVal()
PressureTonneForcePerSquareMeterDataFormatter.data_format = "tf/m²"
PressureKilopoundForcePerSquareFootDataFormatter = DataFormatterVal()
PressureKilopoundForcePerSquareFootDataFormatter.data_format = "kip/ft²"
PressureKilopoundForcePerSquareInchDataFormatter = DataFormatterVal()
PressureKilopoundForcePerSquareInchDataFormatter.data_format = "ksi"
PressurePoundForcePerSquareFootDataFormatter = DataFormatterVal()
PressurePoundForcePerSquareFootDataFormatter.data_format = "psf"
PressurePoundForcePerSquareInchDataFormatter = DataFormatterVal()
PressurePoundForcePerSquareInchDataFormatter.data_format = "psi"