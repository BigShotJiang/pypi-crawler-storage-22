from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .CumulativeChartViewVal import CumulativeChartViewVal
from .CumulativePlotSettingsVal import CumulativePlotSettingsVal
from .DataFilterRef import DataFilterRef as DataFilter_RefType
from .ValidatableResultVal import ValidatableResultVal

class CumulativeChartViewRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_CumulativeChartView):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__CumulativeChartServicesStubLocal = DipsAPI_pb2_grpc.CumulativeChartServicesStub(channelToConnectOn)

    
    def GetValue(self) -> CumulativeChartViewVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.CumulativeChartView()
        ret.MergeFromString(bytes.data)
        return CumulativeChartViewVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def CloseCumulativeChartView(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_CumulativeChartView(This=self.__modelRef)
        ret = self.__CumulativeChartServicesStubLocal.CloseCumulativeChartView(functionParam)
        

    def GetActiveDataFilter(self) -> Optional[DataFilter_RefType]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_CumulativeChartView(This=self.__modelRef)
        ret = self.__CumulativeChartServicesStubLocal.GetActiveDataFilter(functionParam)
        
        if ret.ID.ID:
            return DataFilter_RefType(self.__channelToConnectOn, ret)
        return None
        

    def SetActiveDataFilter(self,  DataFilter: DataFilter_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_CumulativeChartView_ProtoReference_DataFilter(This=self.__modelRef,  Input1=DataFilter.get_model_ref())
        ret = self.__CumulativeChartServicesStubLocal.SetActiveDataFilter(functionParam)
        

    def SetIsWeighted(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_CumulativeChartView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__CumulativeChartServicesStubLocal.SetIsWeighted(functionParam)
        

    def UpdateCumulativePlotSettings(self,  CumulativePlotSettings: CumulativePlotSettingsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_CumulativeChartView_CumulativePlotSettings(This=self.__modelRef,  Input1=(CumulativePlotSettings.to_proto() if hasattr(CumulativePlotSettings, 'to_proto') else CumulativePlotSettings))
        ret = self.__CumulativeChartServicesStubLocal.UpdateCumulativePlotSettings(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 