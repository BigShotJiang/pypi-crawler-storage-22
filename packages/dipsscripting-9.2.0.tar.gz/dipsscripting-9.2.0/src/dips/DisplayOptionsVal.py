"""Generated wrapper for DisplayOptions protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .EntityColorOptionsVal import EntityColorOptionsVal
from .GeneralSymbolDisplayOptionsVal import GeneralSymbolDisplayOptionsVal
from .KinematicAnalysisDisplayOptionsVal import KinematicAnalysisDisplayOptionsVal
from .RosettePlotDisplayOptionsVal import RosettePlotDisplayOptionsVal
from .Stereonet2DDisplayOptionsVal import Stereonet2DDisplayOptionsVal
from .Stereonet3DDisplayOptionsVal import Stereonet3DDisplayOptionsVal

class DisplayOptionsVal:
    """Simple wrapper for DisplayOptions with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.DisplayOptions


    def __init__(self, kinematic_analysis_options: Optional[KinematicAnalysisDisplayOptionsVal] = None, rosette_plot_options: Optional[RosettePlotDisplayOptionsVal] = None, entity_color_options: Optional[EntityColorOptionsVal] = None, stereonet2_d_display_options: Optional[Stereonet2DDisplayOptionsVal] = None, stereonet3_d_display_options: Optional[Stereonet3DDisplayOptionsVal] = None, general_symbol_display_options: Optional[GeneralSymbolDisplayOptionsVal] = None, proto_message: Optional[Any] = None):
        """Initialize the DisplayOptions wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if kinematic_analysis_options is not None:
            self._proto_message.KinematicAnalysisOptions.CopyFrom(kinematic_analysis_options.to_proto())
            self._kinematic_analysis_options_wrapper = kinematic_analysis_options
        if rosette_plot_options is not None:
            self._proto_message.RosettePlotOptions.CopyFrom(rosette_plot_options.to_proto())
            self._rosette_plot_options_wrapper = rosette_plot_options
        if entity_color_options is not None:
            self._proto_message.EntityColorOptions.CopyFrom(entity_color_options.to_proto())
            self._entity_color_options_wrapper = entity_color_options
        if stereonet2_d_display_options is not None:
            self._proto_message.Stereonet2DDisplayOptions.CopyFrom(stereonet2_d_display_options.to_proto())
            self._stereonet2_d_display_options_wrapper = stereonet2_d_display_options
        if stereonet3_d_display_options is not None:
            self._proto_message.Stereonet3DDisplayOptions.CopyFrom(stereonet3_d_display_options.to_proto())
            self._stereonet3_d_display_options_wrapper = stereonet3_d_display_options
        if general_symbol_display_options is not None:
            self._proto_message.GeneralSymbolDisplayOptions.CopyFrom(general_symbol_display_options.to_proto())
            self._general_symbol_display_options_wrapper = general_symbol_display_options


    # Properties

    @property
    def kinematic_analysis_options(self) -> KinematicAnalysisDisplayOptionsVal:
        """Get the KinematicAnalysisOptions field as a wrapper."""
        if not hasattr(self, '_kinematic_analysis_options_wrapper'):
            self._kinematic_analysis_options_wrapper = KinematicAnalysisDisplayOptionsVal(proto_message=self._proto_message.KinematicAnalysisOptions)
        return self._kinematic_analysis_options_wrapper
    
    @kinematic_analysis_options.setter
    def kinematic_analysis_options(self, value: KinematicAnalysisDisplayOptionsVal) -> None:
        """Set the KinematicAnalysisOptions field to a wrapper."""
        self._proto_message.KinematicAnalysisOptions.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_kinematic_analysis_options_wrapper'):
            self._kinematic_analysis_options_wrapper._proto_message.CopyFrom(self._proto_message.KinematicAnalysisOptions)


    @property
    def rosette_plot_options(self) -> RosettePlotDisplayOptionsVal:
        """Get the RosettePlotOptions field as a wrapper."""
        if not hasattr(self, '_rosette_plot_options_wrapper'):
            self._rosette_plot_options_wrapper = RosettePlotDisplayOptionsVal(proto_message=self._proto_message.RosettePlotOptions)
        return self._rosette_plot_options_wrapper
    
    @rosette_plot_options.setter
    def rosette_plot_options(self, value: RosettePlotDisplayOptionsVal) -> None:
        """Set the RosettePlotOptions field to a wrapper."""
        self._proto_message.RosettePlotOptions.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_rosette_plot_options_wrapper'):
            self._rosette_plot_options_wrapper._proto_message.CopyFrom(self._proto_message.RosettePlotOptions)


    @property
    def entity_color_options(self) -> EntityColorOptionsVal:
        """Get the EntityColorOptions field as a wrapper."""
        if not hasattr(self, '_entity_color_options_wrapper'):
            self._entity_color_options_wrapper = EntityColorOptionsVal(proto_message=self._proto_message.EntityColorOptions)
        return self._entity_color_options_wrapper
    
    @entity_color_options.setter
    def entity_color_options(self, value: EntityColorOptionsVal) -> None:
        """Set the EntityColorOptions field to a wrapper."""
        self._proto_message.EntityColorOptions.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_entity_color_options_wrapper'):
            self._entity_color_options_wrapper._proto_message.CopyFrom(self._proto_message.EntityColorOptions)


    @property
    def stereonet2_d_display_options(self) -> Stereonet2DDisplayOptionsVal:
        """Get the Stereonet2DDisplayOptions field as a wrapper."""
        if not hasattr(self, '_stereonet2_d_display_options_wrapper'):
            self._stereonet2_d_display_options_wrapper = Stereonet2DDisplayOptionsVal(proto_message=self._proto_message.Stereonet2DDisplayOptions)
        return self._stereonet2_d_display_options_wrapper
    
    @stereonet2_d_display_options.setter
    def stereonet2_d_display_options(self, value: Stereonet2DDisplayOptionsVal) -> None:
        """Set the Stereonet2DDisplayOptions field to a wrapper."""
        self._proto_message.Stereonet2DDisplayOptions.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_stereonet2_d_display_options_wrapper'):
            self._stereonet2_d_display_options_wrapper._proto_message.CopyFrom(self._proto_message.Stereonet2DDisplayOptions)


    @property
    def stereonet3_d_display_options(self) -> Stereonet3DDisplayOptionsVal:
        """Get the Stereonet3DDisplayOptions field as a wrapper."""
        if not hasattr(self, '_stereonet3_d_display_options_wrapper'):
            self._stereonet3_d_display_options_wrapper = Stereonet3DDisplayOptionsVal(proto_message=self._proto_message.Stereonet3DDisplayOptions)
        return self._stereonet3_d_display_options_wrapper
    
    @stereonet3_d_display_options.setter
    def stereonet3_d_display_options(self, value: Stereonet3DDisplayOptionsVal) -> None:
        """Set the Stereonet3DDisplayOptions field to a wrapper."""
        self._proto_message.Stereonet3DDisplayOptions.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_stereonet3_d_display_options_wrapper'):
            self._stereonet3_d_display_options_wrapper._proto_message.CopyFrom(self._proto_message.Stereonet3DDisplayOptions)


    @property
    def general_symbol_display_options(self) -> GeneralSymbolDisplayOptionsVal:
        """Get the GeneralSymbolDisplayOptions field as a wrapper."""
        if not hasattr(self, '_general_symbol_display_options_wrapper'):
            self._general_symbol_display_options_wrapper = GeneralSymbolDisplayOptionsVal(proto_message=self._proto_message.GeneralSymbolDisplayOptions)
        return self._general_symbol_display_options_wrapper
    
    @general_symbol_display_options.setter
    def general_symbol_display_options(self, value: GeneralSymbolDisplayOptionsVal) -> None:
        """Set the GeneralSymbolDisplayOptions field to a wrapper."""
        self._proto_message.GeneralSymbolDisplayOptions.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_general_symbol_display_options_wrapper'):
            self._general_symbol_display_options_wrapper._proto_message.CopyFrom(self._proto_message.GeneralSymbolDisplayOptions)


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
