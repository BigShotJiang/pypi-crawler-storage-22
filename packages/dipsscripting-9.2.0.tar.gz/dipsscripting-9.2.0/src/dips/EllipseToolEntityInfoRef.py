from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .EllipseToolEntityInfoVal import EllipseToolEntityInfoVal
from .EllipseToolEntityInfoVal import EllipseToolEntityInfoVal
from .ValidatableResultVal import ValidatableResultVal

class EllipseToolEntityInfoRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_EllipseToolEntityInfo):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__RosetteServicesStubLocal = DipsAPI_pb2_grpc.RosetteServicesStub(channelToConnectOn)
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> EllipseToolEntityInfoVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.EllipseToolEntityInfo()
        ret.MergeFromString(bytes.data)
        return EllipseToolEntityInfoVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def DeleteRosetteEllipseTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_EllipseToolEntityInfo(This=self.__modelRef)
        ret = self.__RosetteServicesStubLocal.DeleteRosetteEllipseTool(functionParam)
        

    def SetRosetteEllipseToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_EllipseToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__RosetteServicesStubLocal.SetRosetteEllipseToolVisibility(functionParam)
        

    def UpdateRosetteEllipseTool(self,  EllipseToolEntityInfo: EllipseToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_EllipseToolEntityInfo_EllipseToolEntityInfo(This=self.__modelRef,  Input1=(EllipseToolEntityInfo.to_proto() if hasattr(EllipseToolEntityInfo, 'to_proto') else EllipseToolEntityInfo))
        ret = self.__RosetteServicesStubLocal.UpdateRosetteEllipseTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def DeleteStereonet2DEllipseTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_EllipseToolEntityInfo(This=self.__modelRef)
        ret = self.__Stereonet2DServicesStubLocal.DeleteStereonet2DEllipseTool(functionParam)
        

    def SetStereonet2DEllipseToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_EllipseToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetStereonet2DEllipseToolVisibility(functionParam)
        

    def UpdateStereonet2DEllipseTool(self,  EllipseToolEntityInfo: EllipseToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_EllipseToolEntityInfo_EllipseToolEntityInfo(This=self.__modelRef,  Input1=(EllipseToolEntityInfo.to_proto() if hasattr(EllipseToolEntityInfo, 'to_proto') else EllipseToolEntityInfo))
        ret = self.__Stereonet2DServicesStubLocal.UpdateStereonet2DEllipseTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 