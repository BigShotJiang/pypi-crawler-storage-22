"""Generated wrapper for EntityColorOptions protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .ColorSurrogateVal import ColorSurrogateVal

class EntityColorOptionsVal:
    """Simple wrapper for EntityColorOptions with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.EntityColorOptions


    def __init__(self, set_color: Optional[ColorSurrogateVal] = None, user_plane: Optional[ColorSurrogateVal] = None, variability: Optional[ColorSurrogateVal] = None, confidence: Optional[ColorSurrogateVal] = None, fold: Optional[ColorSurrogateVal] = None, global_mean: Optional[ColorSurrogateVal] = None, global_best_fit: Optional[ColorSurrogateVal] = None, cone: Optional[ColorSurrogateVal] = None, trend_line: Optional[ColorSurrogateVal] = None, pitch_grid: Optional[ColorSurrogateVal] = None, annotative_tools: Optional[ColorSurrogateVal] = None, measurement_tools: Optional[ColorSurrogateVal] = None, proto_message: Optional[Any] = None):
        """Initialize the EntityColorOptions wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if set_color is not None:
            self._proto_message.SetColor.CopyFrom(set_color.to_proto())
            self._set_color_wrapper = set_color
        if user_plane is not None:
            self._proto_message.UserPlane.CopyFrom(user_plane.to_proto())
            self._user_plane_wrapper = user_plane
        if variability is not None:
            self._proto_message.Variability.CopyFrom(variability.to_proto())
            self._variability_wrapper = variability
        if confidence is not None:
            self._proto_message.Confidence.CopyFrom(confidence.to_proto())
            self._confidence_wrapper = confidence
        if fold is not None:
            self._proto_message.Fold.CopyFrom(fold.to_proto())
            self._fold_wrapper = fold
        if global_mean is not None:
            self._proto_message.GlobalMean.CopyFrom(global_mean.to_proto())
            self._global_mean_wrapper = global_mean
        if global_best_fit is not None:
            self._proto_message.GlobalBestFit.CopyFrom(global_best_fit.to_proto())
            self._global_best_fit_wrapper = global_best_fit
        if cone is not None:
            self._proto_message.Cone.CopyFrom(cone.to_proto())
            self._cone_wrapper = cone
        if trend_line is not None:
            self._proto_message.TrendLine.CopyFrom(trend_line.to_proto())
            self._trend_line_wrapper = trend_line
        if pitch_grid is not None:
            self._proto_message.PitchGrid.CopyFrom(pitch_grid.to_proto())
            self._pitch_grid_wrapper = pitch_grid
        if annotative_tools is not None:
            self._proto_message.AnnotativeTools.CopyFrom(annotative_tools.to_proto())
            self._annotative_tools_wrapper = annotative_tools
        if measurement_tools is not None:
            self._proto_message.MeasurementTools.CopyFrom(measurement_tools.to_proto())
            self._measurement_tools_wrapper = measurement_tools


    # Properties

    @property
    def set_color(self) -> ColorSurrogateVal:
        """Get the SetColor field as a wrapper."""
        if not hasattr(self, '_set_color_wrapper'):
            self._set_color_wrapper = ColorSurrogateVal(proto_message=self._proto_message.SetColor)
        return self._set_color_wrapper
    
    @set_color.setter
    def set_color(self, value: ColorSurrogateVal) -> None:
        """Set the SetColor field to a wrapper."""
        self._proto_message.SetColor.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_set_color_wrapper'):
            self._set_color_wrapper._proto_message.CopyFrom(self._proto_message.SetColor)


    @property
    def user_plane(self) -> ColorSurrogateVal:
        """Get the UserPlane field as a wrapper."""
        if not hasattr(self, '_user_plane_wrapper'):
            self._user_plane_wrapper = ColorSurrogateVal(proto_message=self._proto_message.UserPlane)
        return self._user_plane_wrapper
    
    @user_plane.setter
    def user_plane(self, value: ColorSurrogateVal) -> None:
        """Set the UserPlane field to a wrapper."""
        self._proto_message.UserPlane.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_user_plane_wrapper'):
            self._user_plane_wrapper._proto_message.CopyFrom(self._proto_message.UserPlane)


    @property
    def variability(self) -> ColorSurrogateVal:
        """Get the Variability field as a wrapper."""
        if not hasattr(self, '_variability_wrapper'):
            self._variability_wrapper = ColorSurrogateVal(proto_message=self._proto_message.Variability)
        return self._variability_wrapper
    
    @variability.setter
    def variability(self, value: ColorSurrogateVal) -> None:
        """Set the Variability field to a wrapper."""
        self._proto_message.Variability.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_variability_wrapper'):
            self._variability_wrapper._proto_message.CopyFrom(self._proto_message.Variability)


    @property
    def confidence(self) -> ColorSurrogateVal:
        """Get the Confidence field as a wrapper."""
        if not hasattr(self, '_confidence_wrapper'):
            self._confidence_wrapper = ColorSurrogateVal(proto_message=self._proto_message.Confidence)
        return self._confidence_wrapper
    
    @confidence.setter
    def confidence(self, value: ColorSurrogateVal) -> None:
        """Set the Confidence field to a wrapper."""
        self._proto_message.Confidence.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_confidence_wrapper'):
            self._confidence_wrapper._proto_message.CopyFrom(self._proto_message.Confidence)


    @property
    def fold(self) -> ColorSurrogateVal:
        """Get the Fold field as a wrapper."""
        if not hasattr(self, '_fold_wrapper'):
            self._fold_wrapper = ColorSurrogateVal(proto_message=self._proto_message.Fold)
        return self._fold_wrapper
    
    @fold.setter
    def fold(self, value: ColorSurrogateVal) -> None:
        """Set the Fold field to a wrapper."""
        self._proto_message.Fold.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_fold_wrapper'):
            self._fold_wrapper._proto_message.CopyFrom(self._proto_message.Fold)


    @property
    def global_mean(self) -> ColorSurrogateVal:
        """Get the GlobalMean field as a wrapper."""
        if not hasattr(self, '_global_mean_wrapper'):
            self._global_mean_wrapper = ColorSurrogateVal(proto_message=self._proto_message.GlobalMean)
        return self._global_mean_wrapper
    
    @global_mean.setter
    def global_mean(self, value: ColorSurrogateVal) -> None:
        """Set the GlobalMean field to a wrapper."""
        self._proto_message.GlobalMean.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_global_mean_wrapper'):
            self._global_mean_wrapper._proto_message.CopyFrom(self._proto_message.GlobalMean)


    @property
    def global_best_fit(self) -> ColorSurrogateVal:
        """Get the GlobalBestFit field as a wrapper."""
        if not hasattr(self, '_global_best_fit_wrapper'):
            self._global_best_fit_wrapper = ColorSurrogateVal(proto_message=self._proto_message.GlobalBestFit)
        return self._global_best_fit_wrapper
    
    @global_best_fit.setter
    def global_best_fit(self, value: ColorSurrogateVal) -> None:
        """Set the GlobalBestFit field to a wrapper."""
        self._proto_message.GlobalBestFit.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_global_best_fit_wrapper'):
            self._global_best_fit_wrapper._proto_message.CopyFrom(self._proto_message.GlobalBestFit)


    @property
    def cone(self) -> ColorSurrogateVal:
        """Get the Cone field as a wrapper."""
        if not hasattr(self, '_cone_wrapper'):
            self._cone_wrapper = ColorSurrogateVal(proto_message=self._proto_message.Cone)
        return self._cone_wrapper
    
    @cone.setter
    def cone(self, value: ColorSurrogateVal) -> None:
        """Set the Cone field to a wrapper."""
        self._proto_message.Cone.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_cone_wrapper'):
            self._cone_wrapper._proto_message.CopyFrom(self._proto_message.Cone)


    @property
    def trend_line(self) -> ColorSurrogateVal:
        """Get the TrendLine field as a wrapper."""
        if not hasattr(self, '_trend_line_wrapper'):
            self._trend_line_wrapper = ColorSurrogateVal(proto_message=self._proto_message.TrendLine)
        return self._trend_line_wrapper
    
    @trend_line.setter
    def trend_line(self, value: ColorSurrogateVal) -> None:
        """Set the TrendLine field to a wrapper."""
        self._proto_message.TrendLine.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_trend_line_wrapper'):
            self._trend_line_wrapper._proto_message.CopyFrom(self._proto_message.TrendLine)


    @property
    def pitch_grid(self) -> ColorSurrogateVal:
        """Get the PitchGrid field as a wrapper."""
        if not hasattr(self, '_pitch_grid_wrapper'):
            self._pitch_grid_wrapper = ColorSurrogateVal(proto_message=self._proto_message.PitchGrid)
        return self._pitch_grid_wrapper
    
    @pitch_grid.setter
    def pitch_grid(self, value: ColorSurrogateVal) -> None:
        """Set the PitchGrid field to a wrapper."""
        self._proto_message.PitchGrid.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_pitch_grid_wrapper'):
            self._pitch_grid_wrapper._proto_message.CopyFrom(self._proto_message.PitchGrid)


    @property
    def annotative_tools(self) -> ColorSurrogateVal:
        """Get the AnnotativeTools field as a wrapper."""
        if not hasattr(self, '_annotative_tools_wrapper'):
            self._annotative_tools_wrapper = ColorSurrogateVal(proto_message=self._proto_message.AnnotativeTools)
        return self._annotative_tools_wrapper
    
    @annotative_tools.setter
    def annotative_tools(self, value: ColorSurrogateVal) -> None:
        """Set the AnnotativeTools field to a wrapper."""
        self._proto_message.AnnotativeTools.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_annotative_tools_wrapper'):
            self._annotative_tools_wrapper._proto_message.CopyFrom(self._proto_message.AnnotativeTools)


    @property
    def measurement_tools(self) -> ColorSurrogateVal:
        """Get the MeasurementTools field as a wrapper."""
        if not hasattr(self, '_measurement_tools_wrapper'):
            self._measurement_tools_wrapper = ColorSurrogateVal(proto_message=self._proto_message.MeasurementTools)
        return self._measurement_tools_wrapper
    
    @measurement_tools.setter
    def measurement_tools(self, value: ColorSurrogateVal) -> None:
        """Set the MeasurementTools field to a wrapper."""
        self._proto_message.MeasurementTools.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_measurement_tools_wrapper'):
            self._measurement_tools_wrapper._proto_message.CopyFrom(self._proto_message.MeasurementTools)


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
