from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .FoldEntityVisibilityVal import FoldEntityVisibilityVal
from .FoldEntityOptionsVal import FoldEntityOptionsVal
from .ValidatableResultVal import ValidatableResultVal

class FoldEntityVisibilityRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_FoldEntityVisibility):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)
        self.__Stereonet3DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet3DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> FoldEntityVisibilityVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.FoldEntityVisibility()
        ret.MergeFromString(bytes.data)
        return FoldEntityVisibilityVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def SetFoldEntityOptions(self,  FoldEntityOptions: FoldEntityOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_FoldEntityVisibility_FoldEntityOptions(This=self.__modelRef,  Input1=(FoldEntityOptions.to_proto() if hasattr(FoldEntityOptions, 'to_proto') else FoldEntityOptions))
        ret = self.__Stereonet2DServicesStubLocal.SetFoldEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetFoldEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_FoldEntityVisibility_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetFoldEntityVisibility(functionParam)
        

    def SetFoldEntityOptions(self,  FoldEntityOptions: FoldEntityOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_FoldEntityVisibility_FoldEntityOptions(This=self.__modelRef,  Input1=(FoldEntityOptions.to_proto() if hasattr(FoldEntityOptions, 'to_proto') else FoldEntityOptions))
        ret = self.__Stereonet3DServicesStubLocal.SetFoldEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetFoldEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_FoldEntityVisibility_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetFoldEntityVisibility(functionParam)
        

 