"""Generated wrapper for FontOptions protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

class FontOptionsVal:
    """Simple wrapper for FontOptions with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.FontOptions


    def __init__(self, proto_message: Optional[Any] = None):
        """Initialize the FontOptions wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()



    # Properties

    @property
    def italic(self) -> bool:
        """Get the Italic field value."""
        return self._proto_message.Italic
    
    @italic.setter
    def italic(self, value: bool) -> None:
        """Set the Italic field value."""
        self._proto_message.Italic = value


    @property
    def bold(self) -> bool:
        """Get the Bold field value."""
        return self._proto_message.Bold
    
    @bold.setter
    def bold(self, value: bool) -> None:
        """Set the Bold field value."""
        self._proto_message.Bold = value


    @property
    def underlined(self) -> bool:
        """Get the Underlined field value."""
        return self._proto_message.Underlined
    
    @underlined.setter
    def underlined(self, value: bool) -> None:
        """Set the Underlined field value."""
        self._proto_message.Underlined = value


    @property
    def font_size(self) -> float:
        """Get the FontSize field value."""
        return self._proto_message.FontSize
    
    @font_size.setter
    def font_size(self, value: float) -> None:
        """Set the FontSize field value."""
        self._proto_message.FontSize = value


    @property
    def font_name(self) -> str:
        """Get the FontName field value."""
        return self._proto_message.FontName
    
    @font_name.setter
    def font_name(self, value: str) -> None:
        """Set the FontName field value."""
        self._proto_message.FontName = value


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
