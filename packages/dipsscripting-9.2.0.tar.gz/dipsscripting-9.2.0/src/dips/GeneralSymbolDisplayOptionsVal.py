"""Generated wrapper for GeneralSymbolDisplayOptions protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .SymbolDisplaySettingVal import SymbolDisplaySettingVal

class GeneralSymbolDisplayOptionsVal:
    """Simple wrapper for GeneralSymbolDisplayOptions with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.GeneralSymbolDisplayOptions


    def __init__(self, pole_vectors: Optional[SymbolDisplaySettingVal] = None, dip_vectors: Optional[SymbolDisplaySettingVal] = None, critical_vectors: Optional[SymbolDisplaySettingVal] = None, intersection_grid: Optional[SymbolDisplaySettingVal] = None, critical_intersection_grid: Optional[SymbolDisplaySettingVal] = None, intersection_other: Optional[SymbolDisplaySettingVal] = None, critical_intersection_other: Optional[SymbolDisplaySettingVal] = None, traverses: Optional[SymbolDisplaySettingVal] = None, proto_message: Optional[Any] = None):
        """Initialize the GeneralSymbolDisplayOptions wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if pole_vectors is not None:
            self._proto_message.PoleVectors.CopyFrom(pole_vectors.to_proto())
            self._pole_vectors_wrapper = pole_vectors
        if dip_vectors is not None:
            self._proto_message.DipVectors.CopyFrom(dip_vectors.to_proto())
            self._dip_vectors_wrapper = dip_vectors
        if critical_vectors is not None:
            self._proto_message.CriticalVectors.CopyFrom(critical_vectors.to_proto())
            self._critical_vectors_wrapper = critical_vectors
        if intersection_grid is not None:
            self._proto_message.IntersectionGrid.CopyFrom(intersection_grid.to_proto())
            self._intersection_grid_wrapper = intersection_grid
        if critical_intersection_grid is not None:
            self._proto_message.CriticalIntersectionGrid.CopyFrom(critical_intersection_grid.to_proto())
            self._critical_intersection_grid_wrapper = critical_intersection_grid
        if intersection_other is not None:
            self._proto_message.IntersectionOther.CopyFrom(intersection_other.to_proto())
            self._intersection_other_wrapper = intersection_other
        if critical_intersection_other is not None:
            self._proto_message.CriticalIntersectionOther.CopyFrom(critical_intersection_other.to_proto())
            self._critical_intersection_other_wrapper = critical_intersection_other
        if traverses is not None:
            self._proto_message.Traverses.CopyFrom(traverses.to_proto())
            self._traverses_wrapper = traverses


    # Properties

    @property
    def all_symbol_scale_percentage(self) -> float:
        """Get the AllSymbolScalePercentage field value."""
        return self._proto_message.AllSymbolScalePercentage
    
    @all_symbol_scale_percentage.setter
    def all_symbol_scale_percentage(self, value: float) -> None:
        """Set the AllSymbolScalePercentage field value."""
        self._proto_message.AllSymbolScalePercentage = value


    @property
    def pole_vectors(self) -> SymbolDisplaySettingVal:
        """Get the PoleVectors field as a wrapper."""
        if not hasattr(self, '_pole_vectors_wrapper'):
            self._pole_vectors_wrapper = SymbolDisplaySettingVal(proto_message=self._proto_message.PoleVectors)
        return self._pole_vectors_wrapper
    
    @pole_vectors.setter
    def pole_vectors(self, value: SymbolDisplaySettingVal) -> None:
        """Set the PoleVectors field to a wrapper."""
        self._proto_message.PoleVectors.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_pole_vectors_wrapper'):
            self._pole_vectors_wrapper._proto_message.CopyFrom(self._proto_message.PoleVectors)


    @property
    def dip_vectors(self) -> SymbolDisplaySettingVal:
        """Get the DipVectors field as a wrapper."""
        if not hasattr(self, '_dip_vectors_wrapper'):
            self._dip_vectors_wrapper = SymbolDisplaySettingVal(proto_message=self._proto_message.DipVectors)
        return self._dip_vectors_wrapper
    
    @dip_vectors.setter
    def dip_vectors(self, value: SymbolDisplaySettingVal) -> None:
        """Set the DipVectors field to a wrapper."""
        self._proto_message.DipVectors.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_dip_vectors_wrapper'):
            self._dip_vectors_wrapper._proto_message.CopyFrom(self._proto_message.DipVectors)


    @property
    def critical_vectors(self) -> SymbolDisplaySettingVal:
        """Get the CriticalVectors field as a wrapper."""
        if not hasattr(self, '_critical_vectors_wrapper'):
            self._critical_vectors_wrapper = SymbolDisplaySettingVal(proto_message=self._proto_message.CriticalVectors)
        return self._critical_vectors_wrapper
    
    @critical_vectors.setter
    def critical_vectors(self, value: SymbolDisplaySettingVal) -> None:
        """Set the CriticalVectors field to a wrapper."""
        self._proto_message.CriticalVectors.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_critical_vectors_wrapper'):
            self._critical_vectors_wrapper._proto_message.CopyFrom(self._proto_message.CriticalVectors)


    @property
    def intersection_grid(self) -> SymbolDisplaySettingVal:
        """Get the IntersectionGrid field as a wrapper."""
        if not hasattr(self, '_intersection_grid_wrapper'):
            self._intersection_grid_wrapper = SymbolDisplaySettingVal(proto_message=self._proto_message.IntersectionGrid)
        return self._intersection_grid_wrapper
    
    @intersection_grid.setter
    def intersection_grid(self, value: SymbolDisplaySettingVal) -> None:
        """Set the IntersectionGrid field to a wrapper."""
        self._proto_message.IntersectionGrid.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_intersection_grid_wrapper'):
            self._intersection_grid_wrapper._proto_message.CopyFrom(self._proto_message.IntersectionGrid)


    @property
    def critical_intersection_grid(self) -> SymbolDisplaySettingVal:
        """Get the CriticalIntersectionGrid field as a wrapper."""
        if not hasattr(self, '_critical_intersection_grid_wrapper'):
            self._critical_intersection_grid_wrapper = SymbolDisplaySettingVal(proto_message=self._proto_message.CriticalIntersectionGrid)
        return self._critical_intersection_grid_wrapper
    
    @critical_intersection_grid.setter
    def critical_intersection_grid(self, value: SymbolDisplaySettingVal) -> None:
        """Set the CriticalIntersectionGrid field to a wrapper."""
        self._proto_message.CriticalIntersectionGrid.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_critical_intersection_grid_wrapper'):
            self._critical_intersection_grid_wrapper._proto_message.CopyFrom(self._proto_message.CriticalIntersectionGrid)


    @property
    def intersection_other(self) -> SymbolDisplaySettingVal:
        """Get the IntersectionOther field as a wrapper."""
        if not hasattr(self, '_intersection_other_wrapper'):
            self._intersection_other_wrapper = SymbolDisplaySettingVal(proto_message=self._proto_message.IntersectionOther)
        return self._intersection_other_wrapper
    
    @intersection_other.setter
    def intersection_other(self, value: SymbolDisplaySettingVal) -> None:
        """Set the IntersectionOther field to a wrapper."""
        self._proto_message.IntersectionOther.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_intersection_other_wrapper'):
            self._intersection_other_wrapper._proto_message.CopyFrom(self._proto_message.IntersectionOther)


    @property
    def critical_intersection_other(self) -> SymbolDisplaySettingVal:
        """Get the CriticalIntersectionOther field as a wrapper."""
        if not hasattr(self, '_critical_intersection_other_wrapper'):
            self._critical_intersection_other_wrapper = SymbolDisplaySettingVal(proto_message=self._proto_message.CriticalIntersectionOther)
        return self._critical_intersection_other_wrapper
    
    @critical_intersection_other.setter
    def critical_intersection_other(self, value: SymbolDisplaySettingVal) -> None:
        """Set the CriticalIntersectionOther field to a wrapper."""
        self._proto_message.CriticalIntersectionOther.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_critical_intersection_other_wrapper'):
            self._critical_intersection_other_wrapper._proto_message.CopyFrom(self._proto_message.CriticalIntersectionOther)


    @property
    def traverses(self) -> SymbolDisplaySettingVal:
        """Get the Traverses field as a wrapper."""
        if not hasattr(self, '_traverses_wrapper'):
            self._traverses_wrapper = SymbolDisplaySettingVal(proto_message=self._proto_message.Traverses)
        return self._traverses_wrapper
    
    @traverses.setter
    def traverses(self, value: SymbolDisplaySettingVal) -> None:
        """Set the Traverses field to a wrapper."""
        self._proto_message.Traverses.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_traverses_wrapper'):
            self._traverses_wrapper._proto_message.CopyFrom(self._proto_message.Traverses)


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
