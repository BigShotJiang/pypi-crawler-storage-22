from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .HistogramChartViewVal import HistogramChartViewVal
from .DataFilterRef import DataFilterRef as DataFilter_RefType
from .HistogramPlotSettingsVal import HistogramPlotSettingsVal
from .ValidatableResultVal import ValidatableResultVal

class HistogramChartViewRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_HistogramChartView):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__HistogramChartServicesStubLocal = DipsAPI_pb2_grpc.HistogramChartServicesStub(channelToConnectOn)

    
    def GetValue(self) -> HistogramChartViewVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.HistogramChartView()
        ret.MergeFromString(bytes.data)
        return HistogramChartViewVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def CloseHistogramChartView(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_HistogramChartView(This=self.__modelRef)
        ret = self.__HistogramChartServicesStubLocal.CloseHistogramChartView(functionParam)
        

    def GetActiveDataFilter(self) -> Optional[DataFilter_RefType]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_HistogramChartView(This=self.__modelRef)
        ret = self.__HistogramChartServicesStubLocal.GetActiveDataFilter(functionParam)
        
        if ret.ID.ID:
            return DataFilter_RefType(self.__channelToConnectOn, ret)
        return None
        

    def SetActiveDataFilter(self,  DataFilter: DataFilter_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_HistogramChartView_ProtoReference_DataFilter(This=self.__modelRef,  Input1=DataFilter.get_model_ref())
        ret = self.__HistogramChartServicesStubLocal.SetActiveDataFilter(functionParam)
        

    def SetIsWeighted(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_HistogramChartView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__HistogramChartServicesStubLocal.SetIsWeighted(functionParam)
        

    def UpdateHistogramPlotSettings(self,  HistogramPlotSettings: HistogramPlotSettingsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_HistogramChartView_HistogramPlotSettings(This=self.__modelRef,  Input1=(HistogramPlotSettings.to_proto() if hasattr(HistogramPlotSettings, 'to_proto') else HistogramPlotSettings))
        ret = self.__HistogramChartServicesStubLocal.UpdateHistogramPlotSettings(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 