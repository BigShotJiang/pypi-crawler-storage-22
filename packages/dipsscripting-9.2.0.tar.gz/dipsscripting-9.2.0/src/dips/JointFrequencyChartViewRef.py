from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .JointFrequencyChartViewVal import JointFrequencyChartViewVal
from .DataFilterRef import DataFilterRef as DataFilter_RefType
from .JointFrequencyAnalysisSettingsVal import JointFrequencyAnalysisSettingsVal
from .ValidatableResultVal import ValidatableResultVal

class JointFrequencyChartViewRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_JointFrequencyChartView):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__JointFrequencyChartServicesStubLocal = DipsAPI_pb2_grpc.JointFrequencyChartServicesStub(channelToConnectOn)

    
    def GetValue(self) -> JointFrequencyChartViewVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.JointFrequencyChartView()
        ret.MergeFromString(bytes.data)
        return JointFrequencyChartViewVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def CloseJointFrequencyChartView(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_JointFrequencyChartView(This=self.__modelRef)
        ret = self.__JointFrequencyChartServicesStubLocal.CloseJointFrequencyChartView(functionParam)
        

    def GetActiveDataFilter(self) -> Optional[DataFilter_RefType]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_JointFrequencyChartView(This=self.__modelRef)
        ret = self.__JointFrequencyChartServicesStubLocal.GetActiveDataFilter(functionParam)
        
        if ret.ID.ID:
            return DataFilter_RefType(self.__channelToConnectOn, ret)
        return None
        

    def SetActiveDataFilter(self,  DataFilter: DataFilter_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_JointFrequencyChartView_ProtoReference_DataFilter(This=self.__modelRef,  Input1=DataFilter.get_model_ref())
        ret = self.__JointFrequencyChartServicesStubLocal.SetActiveDataFilter(functionParam)
        

    def SetIsWeighted(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_JointFrequencyChartView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__JointFrequencyChartServicesStubLocal.SetIsWeighted(functionParam)
        

    def UpdateJointFrequencyAnalysisSettings(self,  JointFrequencyAnalysisSettings: JointFrequencyAnalysisSettingsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_JointFrequencyChartView_JointFrequencyAnalysisSettings(This=self.__modelRef,  Input1=(JointFrequencyAnalysisSettings.to_proto() if hasattr(JointFrequencyAnalysisSettings, 'to_proto') else JointFrequencyAnalysisSettings))
        ret = self.__JointFrequencyChartServicesStubLocal.UpdateJointFrequencyAnalysisSettings(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 