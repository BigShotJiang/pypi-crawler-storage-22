"""Generated wrapper for KinematicAnalysisDisplayOptions protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .ColorSurrogateVal import ColorSurrogateVal
from .LineFormatVal import LineFormatVal

class KinematicAnalysisDisplayOptionsVal:
    """Simple wrapper for KinematicAnalysisDisplayOptions with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.KinematicAnalysisDisplayOptions


    def __init__(self, construction_line: Optional[LineFormatVal] = None, slope_plane_line: Optional[LineFormatVal] = None, critical_zone_line: Optional[LineFormatVal] = None, critical_zone_primary_color: Optional[ColorSurrogateVal] = None, critical_zone_secondary_color: Optional[ColorSurrogateVal] = None, critical_zone_tertiary_color: Optional[ColorSurrogateVal] = None, proto_message: Optional[Any] = None):
        """Initialize the KinematicAnalysisDisplayOptions wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if construction_line is not None:
            self._proto_message.ConstructionLine.CopyFrom(construction_line.to_proto())
            self._construction_line_wrapper = construction_line
        if slope_plane_line is not None:
            self._proto_message.SlopePlaneLine.CopyFrom(slope_plane_line.to_proto())
            self._slope_plane_line_wrapper = slope_plane_line
        if critical_zone_line is not None:
            self._proto_message.CriticalZoneLine.CopyFrom(critical_zone_line.to_proto())
            self._critical_zone_line_wrapper = critical_zone_line
        if critical_zone_primary_color is not None:
            self._proto_message.CriticalZonePrimaryColor.CopyFrom(critical_zone_primary_color.to_proto())
            self._critical_zone_primary_color_wrapper = critical_zone_primary_color
        if critical_zone_secondary_color is not None:
            self._proto_message.CriticalZoneSecondaryColor.CopyFrom(critical_zone_secondary_color.to_proto())
            self._critical_zone_secondary_color_wrapper = critical_zone_secondary_color
        if critical_zone_tertiary_color is not None:
            self._proto_message.CriticalZoneTertiaryColor.CopyFrom(critical_zone_tertiary_color.to_proto())
            self._critical_zone_tertiary_color_wrapper = critical_zone_tertiary_color


    # Properties

    @property
    def show_construction_lines(self) -> bool:
        """Get the ShowConstructionLines field value."""
        return self._proto_message.ShowConstructionLines
    
    @show_construction_lines.setter
    def show_construction_lines(self, value: bool) -> None:
        """Set the ShowConstructionLines field value."""
        self._proto_message.ShowConstructionLines = value


    @property
    def show_critical_zone_outline(self) -> bool:
        """Get the ShowCriticalZoneOutline field value."""
        return self._proto_message.ShowCriticalZoneOutline
    
    @show_critical_zone_outline.setter
    def show_critical_zone_outline(self, value: bool) -> None:
        """Set the ShowCriticalZoneOutline field value."""
        self._proto_message.ShowCriticalZoneOutline = value


    @property
    def show_slope_plane_line(self) -> bool:
        """Get the ShowSlopePlaneLine field value."""
        return self._proto_message.ShowSlopePlaneLine
    
    @show_slope_plane_line.setter
    def show_slope_plane_line(self, value: bool) -> None:
        """Set the ShowSlopePlaneLine field value."""
        self._proto_message.ShowSlopePlaneLine = value


    @property
    def construction_line(self) -> LineFormatVal:
        """Get the ConstructionLine field as a wrapper."""
        if not hasattr(self, '_construction_line_wrapper'):
            self._construction_line_wrapper = LineFormatVal(proto_message=self._proto_message.ConstructionLine)
        return self._construction_line_wrapper
    
    @construction_line.setter
    def construction_line(self, value: LineFormatVal) -> None:
        """Set the ConstructionLine field to a wrapper."""
        self._proto_message.ConstructionLine.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_construction_line_wrapper'):
            self._construction_line_wrapper._proto_message.CopyFrom(self._proto_message.ConstructionLine)


    @property
    def slope_plane_line(self) -> LineFormatVal:
        """Get the SlopePlaneLine field as a wrapper."""
        if not hasattr(self, '_slope_plane_line_wrapper'):
            self._slope_plane_line_wrapper = LineFormatVal(proto_message=self._proto_message.SlopePlaneLine)
        return self._slope_plane_line_wrapper
    
    @slope_plane_line.setter
    def slope_plane_line(self, value: LineFormatVal) -> None:
        """Set the SlopePlaneLine field to a wrapper."""
        self._proto_message.SlopePlaneLine.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_slope_plane_line_wrapper'):
            self._slope_plane_line_wrapper._proto_message.CopyFrom(self._proto_message.SlopePlaneLine)


    @property
    def critical_zone_line(self) -> LineFormatVal:
        """Get the CriticalZoneLine field as a wrapper."""
        if not hasattr(self, '_critical_zone_line_wrapper'):
            self._critical_zone_line_wrapper = LineFormatVal(proto_message=self._proto_message.CriticalZoneLine)
        return self._critical_zone_line_wrapper
    
    @critical_zone_line.setter
    def critical_zone_line(self, value: LineFormatVal) -> None:
        """Set the CriticalZoneLine field to a wrapper."""
        self._proto_message.CriticalZoneLine.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_critical_zone_line_wrapper'):
            self._critical_zone_line_wrapper._proto_message.CopyFrom(self._proto_message.CriticalZoneLine)


    @property
    def critical_zone_primary_color(self) -> ColorSurrogateVal:
        """Get the CriticalZonePrimaryColor field as a wrapper."""
        if not hasattr(self, '_critical_zone_primary_color_wrapper'):
            self._critical_zone_primary_color_wrapper = ColorSurrogateVal(proto_message=self._proto_message.CriticalZonePrimaryColor)
        return self._critical_zone_primary_color_wrapper
    
    @critical_zone_primary_color.setter
    def critical_zone_primary_color(self, value: ColorSurrogateVal) -> None:
        """Set the CriticalZonePrimaryColor field to a wrapper."""
        self._proto_message.CriticalZonePrimaryColor.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_critical_zone_primary_color_wrapper'):
            self._critical_zone_primary_color_wrapper._proto_message.CopyFrom(self._proto_message.CriticalZonePrimaryColor)


    @property
    def critical_zone_secondary_color(self) -> ColorSurrogateVal:
        """Get the CriticalZoneSecondaryColor field as a wrapper."""
        if not hasattr(self, '_critical_zone_secondary_color_wrapper'):
            self._critical_zone_secondary_color_wrapper = ColorSurrogateVal(proto_message=self._proto_message.CriticalZoneSecondaryColor)
        return self._critical_zone_secondary_color_wrapper
    
    @critical_zone_secondary_color.setter
    def critical_zone_secondary_color(self, value: ColorSurrogateVal) -> None:
        """Set the CriticalZoneSecondaryColor field to a wrapper."""
        self._proto_message.CriticalZoneSecondaryColor.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_critical_zone_secondary_color_wrapper'):
            self._critical_zone_secondary_color_wrapper._proto_message.CopyFrom(self._proto_message.CriticalZoneSecondaryColor)


    @property
    def critical_zone_tertiary_color(self) -> ColorSurrogateVal:
        """Get the CriticalZoneTertiaryColor field as a wrapper."""
        if not hasattr(self, '_critical_zone_tertiary_color_wrapper'):
            self._critical_zone_tertiary_color_wrapper = ColorSurrogateVal(proto_message=self._proto_message.CriticalZoneTertiaryColor)
        return self._critical_zone_tertiary_color_wrapper
    
    @critical_zone_tertiary_color.setter
    def critical_zone_tertiary_color(self, value: ColorSurrogateVal) -> None:
        """Set the CriticalZoneTertiaryColor field to a wrapper."""
        self._proto_message.CriticalZoneTertiaryColor.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_critical_zone_tertiary_color_wrapper'):
            self._critical_zone_tertiary_color_wrapper._proto_message.CopyFrom(self._proto_message.CriticalZoneTertiaryColor)


    @property
    def critical_zone_transparency_percentage(self) -> float:
        """Get the CriticalZoneTransparencyPercentage field value."""
        return self._proto_message.CriticalZoneTransparencyPercentage
    
    @critical_zone_transparency_percentage.setter
    def critical_zone_transparency_percentage(self, value: float) -> None:
        """Set the CriticalZoneTransparencyPercentage field value."""
        self._proto_message.CriticalZoneTransparencyPercentage = value


    @property
    def show_critical_zone_fill(self) -> bool:
        """Get the ShowCriticalZoneFill field value."""
        return self._proto_message.ShowCriticalZoneFill
    
    @show_critical_zone_fill.setter
    def show_critical_zone_fill(self, value: bool) -> None:
        """Set the ShowCriticalZoneFill field value."""
        self._proto_message.ShowCriticalZoneFill = value


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
