from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .KinematicSensitivityChartViewVal import KinematicSensitivityChartViewVal
from .DataFilterRef import DataFilterRef as DataFilter_RefType
from .KinematicSensitivitySettingsVal import KinematicSensitivitySettingsVal
from .ValidatableResultVal import ValidatableResultVal

class KinematicSensitivityChartViewRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_KinematicSensitivityChartView):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__KinematicSensitivityChartServicesStubLocal = DipsAPI_pb2_grpc.KinematicSensitivityChartServicesStub(channelToConnectOn)

    
    def GetValue(self) -> KinematicSensitivityChartViewVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.KinematicSensitivityChartView()
        ret.MergeFromString(bytes.data)
        return KinematicSensitivityChartViewVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def CloseKinematicSensitivityChartView(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_KinematicSensitivityChartView(This=self.__modelRef)
        ret = self.__KinematicSensitivityChartServicesStubLocal.CloseKinematicSensitivityChartView(functionParam)
        

    def GetActiveDataFilter(self) -> Optional[DataFilter_RefType]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_KinematicSensitivityChartView(This=self.__modelRef)
        ret = self.__KinematicSensitivityChartServicesStubLocal.GetActiveDataFilter(functionParam)
        
        if ret.ID.ID:
            return DataFilter_RefType(self.__channelToConnectOn, ret)
        return None
        

    def SetActiveDataFilter(self,  DataFilter: DataFilter_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_KinematicSensitivityChartView_ProtoReference_DataFilter(This=self.__modelRef,  Input1=DataFilter.get_model_ref())
        ret = self.__KinematicSensitivityChartServicesStubLocal.SetActiveDataFilter(functionParam)
        

    def SetIsWeighted(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_KinematicSensitivityChartView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__KinematicSensitivityChartServicesStubLocal.SetIsWeighted(functionParam)
        

    def UpdateKinematicSensitivitySettings(self,  KinematicSensitivitySettings: KinematicSensitivitySettingsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_KinematicSensitivityChartView_KinematicSensitivitySettings(This=self.__modelRef,  Input1=(KinematicSensitivitySettings.to_proto() if hasattr(KinematicSensitivitySettings, 'to_proto') else KinematicSensitivitySettings))
        ret = self.__KinematicSensitivityChartServicesStubLocal.UpdateKinematicSensitivitySettings(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 