from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .LineToolEntityInfoVal import LineToolEntityInfoVal
from .LineToolEntityInfoVal import LineToolEntityInfoVal
from .ValidatableResultVal import ValidatableResultVal

class LineToolEntityInfoRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_LineToolEntityInfo):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__RosetteServicesStubLocal = DipsAPI_pb2_grpc.RosetteServicesStub(channelToConnectOn)
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> LineToolEntityInfoVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.LineToolEntityInfo()
        ret.MergeFromString(bytes.data)
        return LineToolEntityInfoVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def DeleteRosetteLineTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_LineToolEntityInfo(This=self.__modelRef)
        ret = self.__RosetteServicesStubLocal.DeleteRosetteLineTool(functionParam)
        

    def SetRosetteLineToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_LineToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__RosetteServicesStubLocal.SetRosetteLineToolVisibility(functionParam)
        

    def UpdateRosetteLineTool(self,  LineToolEntityInfo: LineToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_LineToolEntityInfo_LineToolEntityInfo(This=self.__modelRef,  Input1=(LineToolEntityInfo.to_proto() if hasattr(LineToolEntityInfo, 'to_proto') else LineToolEntityInfo))
        ret = self.__RosetteServicesStubLocal.UpdateRosetteLineTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def DeleteStereonet2DLineTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_LineToolEntityInfo(This=self.__modelRef)
        ret = self.__Stereonet2DServicesStubLocal.DeleteStereonet2DLineTool(functionParam)
        

    def SetStereonet2DLineToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_LineToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetStereonet2DLineToolVisibility(functionParam)
        

    def UpdateStereonet2DLineTool(self,  LineToolEntityInfo: LineToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_LineToolEntityInfo_LineToolEntityInfo(This=self.__modelRef,  Input1=(LineToolEntityInfo.to_proto() if hasattr(LineToolEntityInfo, 'to_proto') else LineToolEntityInfo))
        ret = self.__Stereonet2DServicesStubLocal.UpdateStereonet2DLineTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 