"""Generated wrapper for ManualClusterAnalysisSettings protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .AngleDataVal import AngleDataVal
from .ColorSurrogateVal import ColorSurrogateVal

class ManualClusterAnalysisSettingsVal:
    """Simple wrapper for ManualClusterAnalysisSettings with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.ManualClusterAnalysisSettings


    def __init__(self, maximum_cluster_size: Optional[AngleDataVal] = None, entity_color: Optional[ColorSurrogateVal] = None, proto_message: Optional[Any] = None):
        """Initialize the ManualClusterAnalysisSettings wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if maximum_cluster_size is not None:
            self._proto_message.MaximumClusterSize.CopyFrom(maximum_cluster_size.to_proto())
            self._maximum_cluster_size_wrapper = maximum_cluster_size
        if entity_color is not None:
            self._proto_message.EntityColor.CopyFrom(entity_color.to_proto())
            self._entity_color_wrapper = entity_color


    # Properties

    @property
    def maximum_cluster_size(self) -> AngleDataVal:
        """Get the MaximumClusterSize field as a wrapper."""
        if not hasattr(self, '_maximum_cluster_size_wrapper'):
            self._maximum_cluster_size_wrapper = AngleDataVal(proto_message=self._proto_message.MaximumClusterSize)
        return self._maximum_cluster_size_wrapper
    
    @maximum_cluster_size.setter
    def maximum_cluster_size(self, value: AngleDataVal) -> None:
        """Set the MaximumClusterSize field to a wrapper."""
        self._proto_message.MaximumClusterSize.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_maximum_cluster_size_wrapper'):
            self._maximum_cluster_size_wrapper._proto_message.CopyFrom(self._proto_message.MaximumClusterSize)


    @property
    def entity_color(self) -> ColorSurrogateVal:
        """Get the EntityColor field as a wrapper."""
        if not hasattr(self, '_entity_color_wrapper'):
            self._entity_color_wrapper = ColorSurrogateVal(proto_message=self._proto_message.EntityColor)
        return self._entity_color_wrapper
    
    @entity_color.setter
    def entity_color(self, value: ColorSurrogateVal) -> None:
        """Set the EntityColor field to a wrapper."""
        self._proto_message.EntityColor.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_entity_color_wrapper'):
            self._entity_color_wrapper._proto_message.CopyFrom(self._proto_message.EntityColor)


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
