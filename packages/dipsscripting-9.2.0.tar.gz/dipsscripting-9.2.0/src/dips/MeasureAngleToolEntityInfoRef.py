from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .MeasureAngleToolEntityInfoVal import MeasureAngleToolEntityInfoVal
from .MeasureAngleToolEntityInfoVal import MeasureAngleToolEntityInfoVal
from .ValidatableResultVal import ValidatableResultVal

class MeasureAngleToolEntityInfoRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_MeasureAngleToolEntityInfo):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> MeasureAngleToolEntityInfoVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.MeasureAngleToolEntityInfo()
        ret.MergeFromString(bytes.data)
        return MeasureAngleToolEntityInfoVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def DeleteStereonet2DMeasureAngleTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_MeasureAngleToolEntityInfo(This=self.__modelRef)
        ret = self.__Stereonet2DServicesStubLocal.DeleteStereonet2DMeasureAngleTool(functionParam)
        

    def SetStereonet2DMeasureAngleToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_MeasureAngleToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetStereonet2DMeasureAngleToolVisibility(functionParam)
        

    def UpdateStereonet2DMeasureAngleTool(self,  MeasureAngleToolEntityInfo: MeasureAngleToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_MeasureAngleToolEntityInfo_MeasureAngleToolEntityInfo(This=self.__modelRef,  Input1=(MeasureAngleToolEntityInfo.to_proto() if hasattr(MeasureAngleToolEntityInfo, 'to_proto') else MeasureAngleToolEntityInfo))
        ret = self.__Stereonet2DServicesStubLocal.UpdateStereonet2DMeasureAngleTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 