from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .PlaneEntityVisibilityVal import PlaneEntityVisibilityVal
from .UserPlaneEntityOptionsVal import UserPlaneEntityOptionsVal
from .ValidatableResultVal import ValidatableResultVal

class PlaneEntityVisibilityRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_PlaneEntityVisibility):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__RosetteServicesStubLocal = DipsAPI_pb2_grpc.RosetteServicesStub(channelToConnectOn)
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)
        self.__Stereonet3DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet3DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> PlaneEntityVisibilityVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.PlaneEntityVisibility()
        ret.MergeFromString(bytes.data)
        return PlaneEntityVisibilityVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def SetUserPlaneEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_PlaneEntityVisibility_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__RosetteServicesStubLocal.SetUserPlaneEntityVisibility(functionParam)
        

    def SetUserPlaneEntityOptions(self,  UserPlaneEntityOptions: UserPlaneEntityOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_PlaneEntityVisibility_UserPlaneEntityOptions(This=self.__modelRef,  Input1=(UserPlaneEntityOptions.to_proto() if hasattr(UserPlaneEntityOptions, 'to_proto') else UserPlaneEntityOptions))
        ret = self.__Stereonet2DServicesStubLocal.SetUserPlaneEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetUserPlaneEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_PlaneEntityVisibility_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetUserPlaneEntityVisibility(functionParam)
        

    def SetUserPlaneEntityOptions(self,  UserPlaneEntityOptions: UserPlaneEntityOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_PlaneEntityVisibility_UserPlaneEntityOptions(This=self.__modelRef,  Input1=(UserPlaneEntityOptions.to_proto() if hasattr(UserPlaneEntityOptions, 'to_proto') else UserPlaneEntityOptions))
        ret = self.__Stereonet3DServicesStubLocal.SetUserPlaneEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetUserPlaneEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_PlaneEntityVisibility_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetUserPlaneEntityVisibility(functionParam)
        

 