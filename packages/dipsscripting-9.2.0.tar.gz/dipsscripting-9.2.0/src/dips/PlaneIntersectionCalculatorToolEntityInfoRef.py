from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .PlaneIntersectionCalculatorToolEntityInfoVal import PlaneIntersectionCalculatorToolEntityInfoVal
from .PlaneIntersectionCalculatorToolEntityInfoVal import PlaneIntersectionCalculatorToolEntityInfoVal
from .ValidatableResultVal import ValidatableResultVal

class PlaneIntersectionCalculatorToolEntityInfoRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_PlaneIntersectionCalculatorToolEntityInfo):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> PlaneIntersectionCalculatorToolEntityInfoVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.PlaneIntersectionCalculatorToolEntityInfo()
        ret.MergeFromString(bytes.data)
        return PlaneIntersectionCalculatorToolEntityInfoVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def DeleteStereonet2DPlaneIntersectionCalculatorTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_PlaneIntersectionCalculatorToolEntityInfo(This=self.__modelRef)
        ret = self.__Stereonet2DServicesStubLocal.DeleteStereonet2DPlaneIntersectionCalculatorTool(functionParam)
        

    def SetStereonet2DPlaneIntersectionCalculatorToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_PlaneIntersectionCalculatorToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetStereonet2DPlaneIntersectionCalculatorToolVisibility(functionParam)
        

    def UpdateStereonet2DPlaneIntersectionCalculatorTool(self,  PlaneIntersectionCalculatorToolEntityInfo: PlaneIntersectionCalculatorToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_PlaneIntersectionCalculatorToolEntityInfo_PlaneIntersectionCalculatorToolEntityInfo(This=self.__modelRef,  Input1=(PlaneIntersectionCalculatorToolEntityInfo.to_proto() if hasattr(PlaneIntersectionCalculatorToolEntityInfo, 'to_proto') else PlaneIntersectionCalculatorToolEntityInfo))
        ret = self.__Stereonet2DServicesStubLocal.UpdateStereonet2DPlaneIntersectionCalculatorTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 