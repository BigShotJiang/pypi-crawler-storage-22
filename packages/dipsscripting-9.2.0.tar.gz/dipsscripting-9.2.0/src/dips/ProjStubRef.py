from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .ProjStubVal import ProjStubVal
from .ArrowToolEntityInfoVal import ArrowToolEntityInfoVal
from .ConeToolEntityInfoVal import ConeToolEntityInfoVal
from .ContourOptionsVal import ContourOptionsVal
from .CumulativeChartViewRef import CumulativeChartViewRef
from .CumulativeChartViewRef import CumulativeChartViewRef as CumulativeChartView_RefType
from .CumulativePlotSettingsVal import CumulativePlotSettingsVal
from .DataDescriptorVal import DataDescriptorVal
from .DataFilterRef import DataFilterRef
from .DataFilterRef import DataFilterRef as DataFilter_RefType
from .DataFilterVal import DataFilterVal
from .DisplayOptionsVal import DisplayOptionsVal
from .EllipseToolEntityInfoVal import EllipseToolEntityInfoVal
from .EntityColorOptionsVal import EntityColorOptionsVal
from .FoldEntityInfoRef import FoldEntityInfoRef
from .FoldEntityInfoRef import FoldEntityInfoRef as FoldEntityInfo_RefType
from .FoldEntityOptionsVal import FoldEntityOptionsVal
from .FoldWindowEntityInfoVal import FoldWindowEntityInfoVal
from .FontOptionsVal import FontOptionsVal
from .GeneralSymbolDisplayOptionsVal import GeneralSymbolDisplayOptionsVal
from .HistogramChartViewRef import HistogramChartViewRef
from .HistogramChartViewRef import HistogramChartViewRef as HistogramChartView_RefType
from .HistogramPlotSettingsVal import HistogramPlotSettingsVal
from .IntersectionOptionsVal import IntersectionOptionsVal
from .JointFrequencyAnalysisSettingsVal import JointFrequencyAnalysisSettingsVal
from .JointFrequencyChartViewRef import JointFrequencyChartViewRef
from .JointFrequencyChartViewRef import JointFrequencyChartViewRef as JointFrequencyChartView_RefType
from .JointSpacingAnalysisSettingsVal import JointSpacingAnalysisSettingsVal
from .JointSpacingChartViewRef import JointSpacingChartViewRef
from .JointSpacingChartViewRef import JointSpacingChartViewRef as JointSpacingChartView_RefType
from .KinematicAnalysisDisplayOptionsVal import KinematicAnalysisDisplayOptionsVal
from .KinematicAnalysisSettingsVal import KinematicAnalysisSettingsVal
from .KinematicSensitivityChartViewRef import KinematicSensitivityChartViewRef
from .KinematicSensitivityChartViewRef import KinematicSensitivityChartViewRef as KinematicSensitivityChartView_RefType
from .KinematicSensitivitySettingsVal import KinematicSensitivitySettingsVal
from .LineIntersectionCalculatorToolEntityInfoVal import LineIntersectionCalculatorToolEntityInfoVal
from .LineToolEntityInfoVal import LineToolEntityInfoVal
from .ManualClusterAnalysisSettingsVal import ManualClusterAnalysisSettingsVal
from .MeasureAngleToolEntityInfoVal import MeasureAngleToolEntityInfoVal
from .OrientationDataSetRef import OrientationDataSetRef
from .OrientationDataSetRef import OrientationDataSetRef as OrientationDataSet_RefType
from .OrientationDataSetVal import OrientationDataSetVal
from .PitchGridToolEntityInfoVal import PitchGridToolEntityInfoVal
from .PlaneEntityInfoRef import PlaneEntityInfoRef
from .PlaneEntityInfoRef import PlaneEntityInfoRef as PlaneEntityInfo_RefType
from .PlaneEntityInfoVal import PlaneEntityInfoVal
from .PlaneIntersectionCalculatorToolEntityInfoVal import PlaneIntersectionCalculatorToolEntityInfoVal
from .PolygonToolEntityInfoVal import PolygonToolEntityInfoVal
from .PolylineToolEntityInfoVal import PolylineToolEntityInfoVal
from .ProcessedDataVal import ProcessedDataVal
from .ProjectSettingsVal import ProjectSettingsVal
from .ProjectSummaryVal import ProjectSummaryVal
from .QualitativeQuantitativeAnalysisSettingsVal import QualitativeQuantitativeAnalysisSettingsVal
from .QualitativeQuantitativeChartViewRef import QualitativeQuantitativeChartViewRef
from .QualitativeQuantitativeChartViewRef import QualitativeQuantitativeChartViewRef as QualitativeQuantitativeChartView_RefType
from .QuantitativeContourSettingsVal import QuantitativeContourSettingsVal
from .RQDAnalysisChartViewRef import RQDAnalysisChartViewRef
from .RQDAnalysisChartViewRef import RQDAnalysisChartViewRef as RQDAnalysisChartView_RefType
from .RQDAnalysisSettingsVal import RQDAnalysisSettingsVal
from .RectangleToolEntityInfoVal import RectangleToolEntityInfoVal
from .RosettePlotDisplayOptionsVal import RosettePlotDisplayOptionsVal
from .RosettePresetOptionsVal import RosettePresetOptionsVal
from .RosetteSettingsVal import RosetteSettingsVal
from .RosetteViewRef import RosetteViewRef
from .RosetteViewRef import RosetteViewRef as RosetteView_RefType
from .RosetteViewVal import RosetteViewVal
from .RotateDataSettingsVal import RotateDataSettingsVal
from .ScatterChartViewRef import ScatterChartViewRef
from .ScatterChartViewRef import ScatterChartViewRef as ScatterChartView_RefType
from .ScatterPlotSettingsVal import ScatterPlotSettingsVal
from .SetEntityInfoRef import SetEntityInfoRef
from .SetEntityInfoRef import SetEntityInfoRef as SetEntityInfo_RefType
from .SetEntityOptionsVal import SetEntityOptionsVal
from .SetStatisticsSettingsVal import SetStatisticsSettingsVal
from .SetWindowEntityInfoVal import SetWindowEntityInfoVal
from .Stereonet2DDisplayOptionsVal import Stereonet2DDisplayOptionsVal
from .Stereonet2DPresetOptionsVal import Stereonet2DPresetOptionsVal
from .Stereonet2DViewRef import Stereonet2DViewRef
from .Stereonet2DViewRef import Stereonet2DViewRef as Stereonet2DView_RefType
from .Stereonet2DViewVal import Stereonet2DViewVal
from .Stereonet3DDisplayOptionsVal import Stereonet3DDisplayOptionsVal
from .Stereonet3DPresetOptionsVal import Stereonet3DPresetOptionsVal
from .Stereonet3DViewRef import Stereonet3DViewRef
from .Stereonet3DViewRef import Stereonet3DViewRef as Stereonet3DView_RefType
from .Stereonet3DViewVal import Stereonet3DViewVal
from .StereonetProjectionModeVal import StereonetProjectionModeVal
from .SymbolicSettingsVal import SymbolicSettingsVal
from .SyntheticJointsSettingsVal import SyntheticJointsSettingsVal
from .TextToolEntityInfoVal import TextToolEntityInfoVal
from .TraverseEntityOptionsVal import TraverseEntityOptionsVal
from .TrendLineToolEntityInfoVal import TrendLineToolEntityInfoVal
from .UserPlaneEntityOptionsVal import UserPlaneEntityOptionsVal
from .ValidatableResultVal import ValidatableResultVal
from .VectorDensityContourSettingsVal import VectorDensityContourSettingsVal
from .WeightingSettingsVal import WeightingSettingsVal

class ProjStubRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_ProjStub):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__CumulativeChartServicesStubLocal = DipsAPI_pb2_grpc.CumulativeChartServicesStub(channelToConnectOn)
        self.__DataFilterServicesStubLocal = DipsAPI_pb2_grpc.DataFilterServicesStub(channelToConnectOn)
        self.__DefaultProviderServicesStubLocal = DipsAPI_pb2_grpc.DefaultProviderServicesStub(channelToConnectOn)
        self.__FoldServicesStubLocal = DipsAPI_pb2_grpc.FoldServicesStub(channelToConnectOn)
        self.__HistogramChartServicesStubLocal = DipsAPI_pb2_grpc.HistogramChartServicesStub(channelToConnectOn)
        self.__JointFrequencyChartServicesStubLocal = DipsAPI_pb2_grpc.JointFrequencyChartServicesStub(channelToConnectOn)
        self.__JointSpacingChartServicesStubLocal = DipsAPI_pb2_grpc.JointSpacingChartServicesStub(channelToConnectOn)
        self.__KinematicSensitivityChartServicesStubLocal = DipsAPI_pb2_grpc.KinematicSensitivityChartServicesStub(channelToConnectOn)
        self.__ProcessedDataManagerStubLocal = DipsAPI_pb2_grpc.ProcessedDataManagerStub(channelToConnectOn)
        self.__ProjStubServiceStubLocal = DipsAPI_pb2_grpc.ProjStubServiceStub(channelToConnectOn)
        self.__QualitativeQuantitativeChartServicesStubLocal = DipsAPI_pb2_grpc.QualitativeQuantitativeChartServicesStub(channelToConnectOn)
        self.__RQDAnalysisChartServicesStubLocal = DipsAPI_pb2_grpc.RQDAnalysisChartServicesStub(channelToConnectOn)
        self.__RosetteServicesStubLocal = DipsAPI_pb2_grpc.RosetteServicesStub(channelToConnectOn)
        self.__ScatterChartServicesStubLocal = DipsAPI_pb2_grpc.ScatterChartServicesStub(channelToConnectOn)
        self.__SetServicesStubLocal = DipsAPI_pb2_grpc.SetServicesStub(channelToConnectOn)
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)
        self.__Stereonet3DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet3DServicesStub(channelToConnectOn)
        self.__TraverseServicesStubLocal = DipsAPI_pb2_grpc.TraverseServicesStub(channelToConnectOn)
        self.__UserPlaneServicesStubLocal = DipsAPI_pb2_grpc.UserPlaneServicesStub(channelToConnectOn)

    
    def GetValue(self) -> ProjStubVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.ProjStub()
        ret.MergeFromString(bytes.data)
        return ProjStubVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def CreateCumulativeChartView(self,  CumulativePlotSettings: CumulativePlotSettingsVal) -> CumulativeChartView_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_CumulativePlotSettings(This=self.__modelRef,  Input1=(CumulativePlotSettings.to_proto() if hasattr(CumulativePlotSettings, 'to_proto') else CumulativePlotSettings))
        ret = self.__CumulativeChartServicesStubLocal.CreateCumulativeChartView(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return CumulativeChartView_RefType(self.__channelToConnectOn, ret.Result)
        

    def GetCumulativeChartViewList(self) -> List[CumulativeChartViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__CumulativeChartServicesStubLocal.GetCumulativeChartViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( CumulativeChartViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def AddDataFilter(self,  DataFilter: DataFilterVal) -> DataFilter_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_DataFilter(This=self.__modelRef,  Input1=(DataFilter.to_proto() if hasattr(DataFilter, 'to_proto') else DataFilter))
        ret = self.__DataFilterServicesStubLocal.AddDataFilter(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return DataFilter_RefType(self.__channelToConnectOn, ret.Result)
        

    def DeleteDataFilter(self,  DataFilter: DataFilter_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_ProtoReference_DataFilter(This=self.__modelRef,  Input1=DataFilter.get_model_ref())
        ret = self.__DataFilterServicesStubLocal.DeleteDataFilter(functionParam)
        

    def GetDataFilterList(self) -> List[DataFilterRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DataFilterServicesStubLocal.GetDataFilterList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( DataFilterRef(self.__channelToConnectOn, item) )
        return retList
        

    def GetDefaultArrowToolEntityInfo(self) -> ArrowToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultArrowToolEntityInfo(functionParam)
        
        return ArrowToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultConeToolEntityInfo(self) -> ConeToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultConeToolEntityInfo(functionParam)
        
        return ConeToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultContourOptions(self) -> ContourOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultContourOptions(functionParam)
        
        return ContourOptionsVal.from_proto(ret)
        

    def GetDefaultCumulativePlotSettings(self) -> CumulativePlotSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultCumulativePlotSettings(functionParam)
        
        return CumulativePlotSettingsVal.from_proto(ret)
        

    def GetDefaultDisplayOptions(self) -> DisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultDisplayOptions(functionParam)
        
        return DisplayOptionsVal.from_proto(ret)
        

    def GetDefaultEllipseToolEntityInfo(self) -> EllipseToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultEllipseToolEntityInfo(functionParam)
        
        return EllipseToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultEntityColorOptions(self) -> EntityColorOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultEntityColorOptions(functionParam)
        
        return EntityColorOptionsVal.from_proto(ret)
        

    def GetDefaultFoldEntityOptions(self) -> FoldEntityOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultFoldEntityOptions(functionParam)
        
        return FoldEntityOptionsVal.from_proto(ret)
        

    def GetDefaultFontOptions(self) -> FontOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultFontOptions(functionParam)
        
        return FontOptionsVal.from_proto(ret)
        

    def GetDefaultGeneralSymbolDisplayOptions(self) -> GeneralSymbolDisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultGeneralSymbolDisplayOptions(functionParam)
        
        return GeneralSymbolDisplayOptionsVal.from_proto(ret)
        

    def GetDefaultHistogramPlotSettings(self) -> HistogramPlotSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultHistogramPlotSettings(functionParam)
        
        return HistogramPlotSettingsVal.from_proto(ret)
        

    def GetDefaultIntersectionOptions(self) -> IntersectionOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultIntersectionOptions(functionParam)
        
        return IntersectionOptionsVal.from_proto(ret)
        

    def GetDefaultJointFrequencyAnalysisSettings(self) -> JointFrequencyAnalysisSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultJointFrequencyAnalysisSettings(functionParam)
        
        return JointFrequencyAnalysisSettingsVal.from_proto(ret)
        

    def GetDefaultJointSpacingAnalysisSettings(self) -> JointSpacingAnalysisSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultJointSpacingAnalysisSettings(functionParam)
        
        return JointSpacingAnalysisSettingsVal.from_proto(ret)
        

    def GetDefaultKinematicAnalysisDisplayOptions(self) -> KinematicAnalysisDisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultKinematicAnalysisDisplayOptions(functionParam)
        
        return KinematicAnalysisDisplayOptionsVal.from_proto(ret)
        

    def GetDefaultKinematicAnalysisSettings(self) -> KinematicAnalysisSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultKinematicAnalysisSettings(functionParam)
        
        return KinematicAnalysisSettingsVal.from_proto(ret)
        

    def GetDefaultKinematicSensitivitySettings(self,  KinematicAnalysisSettings: KinematicAnalysisSettingsVal) -> KinematicSensitivitySettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_KinematicAnalysisSettings(This=self.__modelRef,  Input1=(KinematicAnalysisSettings.to_proto() if hasattr(KinematicAnalysisSettings, 'to_proto') else KinematicAnalysisSettings))
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultKinematicSensitivitySettings(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return KinematicSensitivitySettingsVal.from_proto(ret.Result)
        

    def GetDefaultLineIntersectionCalculatorToolEntityInfo(self) -> LineIntersectionCalculatorToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultLineIntersectionCalculatorToolEntityInfo(functionParam)
        
        return LineIntersectionCalculatorToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultLineToolEntityInfo(self) -> LineToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultLineToolEntityInfo(functionParam)
        
        return LineToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultManualClusterAnalysisSettings(self) -> ManualClusterAnalysisSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultManualClusterAnalysisSettings(functionParam)
        
        return ManualClusterAnalysisSettingsVal.from_proto(ret)
        

    def GetDefaultMeasureAngleToolEntityInfo(self) -> MeasureAngleToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultMeasureAngleToolEntityInfo(functionParam)
        
        return MeasureAngleToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultOrientationDataSet(self) -> OrientationDataSetVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultOrientationDataSet(functionParam)
        
        return OrientationDataSetVal.from_proto(ret)
        

    def GetDefaultPitchGridToolEntityInfo(self) -> PitchGridToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultPitchGridToolEntityInfo(functionParam)
        
        return PitchGridToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultPlaneIntersectionCalculatorToolEntityInfo(self) -> PlaneIntersectionCalculatorToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultPlaneIntersectionCalculatorToolEntityInfo(functionParam)
        
        return PlaneIntersectionCalculatorToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultPolygonToolEntityInfo(self) -> PolygonToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultPolygonToolEntityInfo(functionParam)
        
        return PolygonToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultPolylineToolEntityInfo(self) -> PolylineToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultPolylineToolEntityInfo(functionParam)
        
        return PolylineToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultProjectSettings(self) -> ProjectSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultProjectSettings(functionParam)
        
        return ProjectSettingsVal.from_proto(ret)
        

    def GetDefaultProjectSummary(self) -> ProjectSummaryVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultProjectSummary(functionParam)
        
        return ProjectSummaryVal.from_proto(ret)
        

    def GetDefaultQualitativeQuantitativeAnalysisSettings(self) -> QualitativeQuantitativeAnalysisSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultQualitativeQuantitativeAnalysisSettings(functionParam)
        
        return QualitativeQuantitativeAnalysisSettingsVal.from_proto(ret)
        

    def GetDefaultQuantitativeContourSettings(self) -> QuantitativeContourSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultQuantitativeContourSettings(functionParam)
        
        return QuantitativeContourSettingsVal.from_proto(ret)
        

    def GetDefaultRectangleToolEntityInfo(self) -> RectangleToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultRectangleToolEntityInfo(functionParam)
        
        return RectangleToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultRosettePlotDisplayOptions(self) -> RosettePlotDisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultRosettePlotDisplayOptions(functionParam)
        
        return RosettePlotDisplayOptionsVal.from_proto(ret)
        

    def GetDefaultRosettePresetOptions(self) -> RosettePresetOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultRosettePresetOptions(functionParam)
        
        return RosettePresetOptionsVal.from_proto(ret)
        

    def GetDefaultRosetteSettings(self) -> RosetteSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultRosetteSettings(functionParam)
        
        return RosetteSettingsVal.from_proto(ret)
        

    def GetDefaultRosetteView(self) -> RosetteViewVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultRosetteView(functionParam)
        
        return RosetteViewVal.from_proto(ret)
        

    def GetDefaultRotateDataSettings(self) -> RotateDataSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultRotateDataSettings(functionParam)
        
        return RotateDataSettingsVal.from_proto(ret)
        

    def GetDefaultRQDAnalysisSettings(self) -> RQDAnalysisSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultRQDAnalysisSettings(functionParam)
        
        return RQDAnalysisSettingsVal.from_proto(ret)
        

    def GetDefaultScatterPlotSettings(self) -> ScatterPlotSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultScatterPlotSettings(functionParam)
        
        return ScatterPlotSettingsVal.from_proto(ret)
        

    def GetDefaultSetEntityOptions(self) -> SetEntityOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultSetEntityOptions(functionParam)
        
        return SetEntityOptionsVal.from_proto(ret)
        

    def GetDefaultSetStatisticsSettings(self) -> SetStatisticsSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultSetStatisticsSettings(functionParam)
        
        return SetStatisticsSettingsVal.from_proto(ret)
        

    def GetDefaultStereonet2DDisplayOptions(self) -> Stereonet2DDisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultStereonet2DDisplayOptions(functionParam)
        
        return Stereonet2DDisplayOptionsVal.from_proto(ret)
        

    def GetDefaultStereonet2DPresetOptions(self) -> Stereonet2DPresetOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultStereonet2DPresetOptions(functionParam)
        
        return Stereonet2DPresetOptionsVal.from_proto(ret)
        

    def GetDefaultStereonet2DView(self) -> Stereonet2DViewVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultStereonet2DView(functionParam)
        
        return Stereonet2DViewVal.from_proto(ret)
        

    def GetDefaultStereonet3DDisplayOptions(self) -> Stereonet3DDisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultStereonet3DDisplayOptions(functionParam)
        
        return Stereonet3DDisplayOptionsVal.from_proto(ret)
        

    def GetDefaultStereonet3DPresetOptions(self) -> Stereonet3DPresetOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultStereonet3DPresetOptions(functionParam)
        
        return Stereonet3DPresetOptionsVal.from_proto(ret)
        

    def GetDefaultStereonet3DView(self) -> Stereonet3DViewVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultStereonet3DView(functionParam)
        
        return Stereonet3DViewVal.from_proto(ret)
        

    def GetDefaultStereonetProjectionMode(self) -> StereonetProjectionModeVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultStereonetProjectionMode(functionParam)
        
        return StereonetProjectionModeVal.from_proto(ret)
        

    def GetDefaultSymbolicSettings(self) -> SymbolicSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultSymbolicSettings(functionParam)
        
        return SymbolicSettingsVal.from_proto(ret)
        

    def GetDefaultSyntheticJointsSettings(self) -> SyntheticJointsSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultSyntheticJointsSettings(functionParam)
        
        return SyntheticJointsSettingsVal.from_proto(ret)
        

    def GetDefaultTextToolEntityInfo(self) -> TextToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultTextToolEntityInfo(functionParam)
        
        return TextToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultTraverseEntityOptions(self) -> TraverseEntityOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultTraverseEntityOptions(functionParam)
        
        return TraverseEntityOptionsVal.from_proto(ret)
        

    def GetDefaultTrendLineToolEntityInfo(self) -> TrendLineToolEntityInfoVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultTrendLineToolEntityInfo(functionParam)
        
        return TrendLineToolEntityInfoVal.from_proto(ret)
        

    def GetDefaultUserPlaneEntityOptions(self) -> UserPlaneEntityOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultUserPlaneEntityOptions(functionParam)
        
        return UserPlaneEntityOptionsVal.from_proto(ret)
        

    def GetDefaultVectorDensityContourSettings(self) -> VectorDensityContourSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultVectorDensityContourSettings(functionParam)
        
        return VectorDensityContourSettingsVal.from_proto(ret)
        

    def GetDefaultWeightingSettings(self) -> WeightingSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__DefaultProviderServicesStubLocal.GetDefaultWeightingSettings(functionParam)
        
        return WeightingSettingsVal.from_proto(ret)
        

    def AddFoldWindow(self,  FoldWindowEntityInfo: FoldWindowEntityInfoVal) -> FoldEntityInfo_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_FoldWindowEntityInfo(This=self.__modelRef,  Input1=(FoldWindowEntityInfo.to_proto() if hasattr(FoldWindowEntityInfo, 'to_proto') else FoldWindowEntityInfo))
        ret = self.__FoldServicesStubLocal.AddFoldWindow(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return FoldEntityInfo_RefType(self.__channelToConnectOn, ret.Result)
        

    def DeleteFold(self,  FoldEntityInfo: FoldEntityInfo_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_ProtoReference_FoldEntityInfo(This=self.__modelRef,  Input1=FoldEntityInfo.get_model_ref())
        ret = self.__FoldServicesStubLocal.DeleteFold(functionParam)
        

    def GetFoldList(self) -> List[FoldEntityInfoRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__FoldServicesStubLocal.GetFoldList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( FoldEntityInfoRef(self.__channelToConnectOn, item) )
        return retList
        

    def CreateHistogramChartView(self,  HistogramPlotSettings: HistogramPlotSettingsVal) -> HistogramChartView_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_HistogramPlotSettings(This=self.__modelRef,  Input1=(HistogramPlotSettings.to_proto() if hasattr(HistogramPlotSettings, 'to_proto') else HistogramPlotSettings))
        ret = self.__HistogramChartServicesStubLocal.CreateHistogramChartView(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return HistogramChartView_RefType(self.__channelToConnectOn, ret.Result)
        

    def GetHistogramChartViewList(self) -> List[HistogramChartViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__HistogramChartServicesStubLocal.GetHistogramChartViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( HistogramChartViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def CreateJointFrequencyChartView(self,  JointFrequencyAnalysisSettings: JointFrequencyAnalysisSettingsVal) -> JointFrequencyChartView_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_JointFrequencyAnalysisSettings(This=self.__modelRef,  Input1=(JointFrequencyAnalysisSettings.to_proto() if hasattr(JointFrequencyAnalysisSettings, 'to_proto') else JointFrequencyAnalysisSettings))
        ret = self.__JointFrequencyChartServicesStubLocal.CreateJointFrequencyChartView(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return JointFrequencyChartView_RefType(self.__channelToConnectOn, ret.Result)
        

    def GetJointFrequencyChartViewList(self) -> List[JointFrequencyChartViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__JointFrequencyChartServicesStubLocal.GetJointFrequencyChartViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( JointFrequencyChartViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def CreateJointSpacingChartView(self,  JointSpacingAnalysisSettings: JointSpacingAnalysisSettingsVal) -> JointSpacingChartView_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_JointSpacingAnalysisSettings(This=self.__modelRef,  Input1=(JointSpacingAnalysisSettings.to_proto() if hasattr(JointSpacingAnalysisSettings, 'to_proto') else JointSpacingAnalysisSettings))
        ret = self.__JointSpacingChartServicesStubLocal.CreateJointSpacingChartView(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return JointSpacingChartView_RefType(self.__channelToConnectOn, ret.Result)
        

    def GetJointSpacingChartViewList(self) -> List[JointSpacingChartViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__JointSpacingChartServicesStubLocal.GetJointSpacingChartViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( JointSpacingChartViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def CreateKinematicSensitivityChartView(self,  KinematicSensitivitySettings: KinematicSensitivitySettingsVal) -> KinematicSensitivityChartView_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_KinematicSensitivitySettings(This=self.__modelRef,  Input1=(KinematicSensitivitySettings.to_proto() if hasattr(KinematicSensitivitySettings, 'to_proto') else KinematicSensitivitySettings))
        ret = self.__KinematicSensitivityChartServicesStubLocal.CreateKinematicSensitivityChartView(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return KinematicSensitivityChartView_RefType(self.__channelToConnectOn, ret.Result)
        

    def GetKinematicSensitivityChartViewList(self) -> List[KinematicSensitivityChartViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__KinematicSensitivityChartServicesStubLocal.GetKinematicSensitivityChartViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( KinematicSensitivityChartViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def NumericRequest(self,  DataDescriptor: DataDescriptorVal):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_DataDescriptor(This=self.__modelRef,  Input1=(DataDescriptor.to_proto() if hasattr(DataDescriptor, 'to_proto') else DataDescriptor))
        ret = self.__ProcessedDataManagerStubLocal.NumericRequest(functionParam)
        
        return ret
        

    def PlanarRequest(self) -> ProcessedDataVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProcessedDataManagerStubLocal.PlanarRequest(functionParam)
        
        return ProcessedDataVal.from_proto(ret)
        

    def TextRequest(self,  DataDescriptor: DataDescriptorVal):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_DataDescriptor(This=self.__modelRef,  Input1=(DataDescriptor.to_proto() if hasattr(DataDescriptor, 'to_proto') else DataDescriptor))
        ret = self.__ProcessedDataManagerStubLocal.TextRequest(functionParam)
        
        return ret
        

    def GetEntityColorOptions(self) -> EntityColorOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProjStubServiceStubLocal.GetEntityColorOptions(functionParam)
        
        return EntityColorOptionsVal.from_proto(ret)
        

    def GetGeneralSymbolDisplayOptions(self) -> GeneralSymbolDisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProjStubServiceStubLocal.GetGeneralSymbolDisplayOptions(functionParam)
        
        return GeneralSymbolDisplayOptionsVal.from_proto(ret)
        

    def GetKinematicAnalysisDisplayOptions(self) -> KinematicAnalysisDisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProjStubServiceStubLocal.GetKinematicAnalysisDisplayOptions(functionParam)
        
        return KinematicAnalysisDisplayOptionsVal.from_proto(ret)
        

    def GetProjectSummary(self) -> ProjectSummaryVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProjStubServiceStubLocal.GetProjectSummary(functionParam)
        
        return ProjectSummaryVal.from_proto(ret)
        

    def GetReportingConvention(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProjStubServiceStubLocal.GetReportingConvention(functionParam)
        
        return ret
        

    def GetRosettePlotDisplayOptions(self) -> RosettePlotDisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProjStubServiceStubLocal.GetRosettePlotDisplayOptions(functionParam)
        
        return RosettePlotDisplayOptionsVal.from_proto(ret)
        

    def GetStereonet2DDisplayOptions(self) -> Stereonet2DDisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProjStubServiceStubLocal.GetStereonet2DDisplayOptions(functionParam)
        
        return Stereonet2DDisplayOptionsVal.from_proto(ret)
        

    def GetStereonet3DDisplayOptions(self) -> Stereonet3DDisplayOptionsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProjStubServiceStubLocal.GetStereonet3DDisplayOptions(functionParam)
        
        return Stereonet3DDisplayOptionsVal.from_proto(ret)
        

    def GetUnitSystem(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProjStubServiceStubLocal.GetUnitSystem(functionParam)
        
        return ret
        

    def GetWeightingOptions(self) -> WeightingSettingsVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ProjStubServiceStubLocal.GetWeightingOptions(functionParam)
        
        return WeightingSettingsVal.from_proto(ret)
        

    def SaveProject(self,  String: str) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_String(This=self.__modelRef,  Input1=(DipsAPI_pb2.String(Value=String) if hasattr(DipsAPI_pb2, 'String') else String))
        ret = self.__ProjStubServiceStubLocal.SaveProject(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetEntityColorOptions(self,  EntityColorOptions: EntityColorOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_EntityColorOptions(This=self.__modelRef,  Input1=(EntityColorOptions.to_proto() if hasattr(EntityColorOptions, 'to_proto') else EntityColorOptions))
        ret = self.__ProjStubServiceStubLocal.SetEntityColorOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetGeneralSymbolDisplayOptions(self,  GeneralSymbolDisplayOptions: GeneralSymbolDisplayOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_GeneralSymbolDisplayOptions(This=self.__modelRef,  Input1=(GeneralSymbolDisplayOptions.to_proto() if hasattr(GeneralSymbolDisplayOptions, 'to_proto') else GeneralSymbolDisplayOptions))
        ret = self.__ProjStubServiceStubLocal.SetGeneralSymbolDisplayOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetKinematicAnalysisDisplayOptions(self,  KinematicAnalysisDisplayOptions: KinematicAnalysisDisplayOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_KinematicAnalysisDisplayOptions(This=self.__modelRef,  Input1=(KinematicAnalysisDisplayOptions.to_proto() if hasattr(KinematicAnalysisDisplayOptions, 'to_proto') else KinematicAnalysisDisplayOptions))
        ret = self.__ProjStubServiceStubLocal.SetKinematicAnalysisDisplayOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetProjectSummary(self,  ProjectSummary: ProjectSummaryVal):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_ProjectSummary(This=self.__modelRef,  Input1=(ProjectSummary.to_proto() if hasattr(ProjectSummary, 'to_proto') else ProjectSummary))
        ret = self.__ProjStubServiceStubLocal.SetProjectSummary(functionParam)
        

    def SetReportingConvention(self,  eOrientationConvention: DipsAPI_pb2.eOrientationConvention):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_eOrientationConvention(This=self.__modelRef,  Input1=eOrientationConvention)
        ret = self.__ProjStubServiceStubLocal.SetReportingConvention(functionParam)
        

    def SetRosettePlotDisplayOptions(self,  RosettePlotDisplayOptions: RosettePlotDisplayOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_RosettePlotDisplayOptions(This=self.__modelRef,  Input1=(RosettePlotDisplayOptions.to_proto() if hasattr(RosettePlotDisplayOptions, 'to_proto') else RosettePlotDisplayOptions))
        ret = self.__ProjStubServiceStubLocal.SetRosettePlotDisplayOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetStereonet2DDisplayOptions(self,  Stereonet2DDisplayOptions: Stereonet2DDisplayOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_Stereonet2DDisplayOptions(This=self.__modelRef,  Input1=(Stereonet2DDisplayOptions.to_proto() if hasattr(Stereonet2DDisplayOptions, 'to_proto') else Stereonet2DDisplayOptions))
        ret = self.__ProjStubServiceStubLocal.SetStereonet2DDisplayOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetStereonet3DDisplayOptions(self,  Stereonet3DDisplayOptions: Stereonet3DDisplayOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_Stereonet3DDisplayOptions(This=self.__modelRef,  Input1=(Stereonet3DDisplayOptions.to_proto() if hasattr(Stereonet3DDisplayOptions, 'to_proto') else Stereonet3DDisplayOptions))
        ret = self.__ProjStubServiceStubLocal.SetStereonet3DDisplayOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetUnitSystem(self,  eUnitSystem: DipsAPI_pb2.eUnitSystem):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_eUnitSystem(This=self.__modelRef,  Input1=eUnitSystem)
        ret = self.__ProjStubServiceStubLocal.SetUnitSystem(functionParam)
        

    def SetWeightingOptions(self,  WeightingSettings: WeightingSettingsVal):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_WeightingSettings(This=self.__modelRef,  Input1=(WeightingSettings.to_proto() if hasattr(WeightingSettings, 'to_proto') else WeightingSettings))
        ret = self.__ProjStubServiceStubLocal.SetWeightingOptions(functionParam)
        

    def CreateQualitativeQuantitativeChartView(self,  QualitativeQuantitativeAnalysisSettings: QualitativeQuantitativeAnalysisSettingsVal) -> QualitativeQuantitativeChartView_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_QualitativeQuantitativeAnalysisSettings(This=self.__modelRef,  Input1=(QualitativeQuantitativeAnalysisSettings.to_proto() if hasattr(QualitativeQuantitativeAnalysisSettings, 'to_proto') else QualitativeQuantitativeAnalysisSettings))
        ret = self.__QualitativeQuantitativeChartServicesStubLocal.CreateQualitativeQuantitativeChartView(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return QualitativeQuantitativeChartView_RefType(self.__channelToConnectOn, ret.Result)
        

    def GetQualitativeQuantitativeChartViewList(self) -> List[QualitativeQuantitativeChartViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__QualitativeQuantitativeChartServicesStubLocal.GetQualitativeQuantitativeChartViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( QualitativeQuantitativeChartViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def CreateRQDAnalysisChartView(self,  RQDAnalysisSettings: RQDAnalysisSettingsVal) -> RQDAnalysisChartView_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_RQDAnalysisSettings(This=self.__modelRef,  Input1=(RQDAnalysisSettings.to_proto() if hasattr(RQDAnalysisSettings, 'to_proto') else RQDAnalysisSettings))
        ret = self.__RQDAnalysisChartServicesStubLocal.CreateRQDAnalysisChartView(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return RQDAnalysisChartView_RefType(self.__channelToConnectOn, ret.Result)
        

    def GetRQDAnalysisChartViewList(self) -> List[RQDAnalysisChartViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__RQDAnalysisChartServicesStubLocal.GetRQDAnalysisChartViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( RQDAnalysisChartViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def CreateRosetteView(self) -> Optional[RosetteView_RefType]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__RosetteServicesStubLocal.CreateRosetteView(functionParam)
        
        if ret.ID.ID:
            return RosetteView_RefType(self.__channelToConnectOn, ret)
        return None
        

    def GetRosetteViewList(self) -> List[RosetteViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__RosetteServicesStubLocal.GetRosetteViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( RosetteViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def CreateScatterChartView(self,  ScatterPlotSettings: ScatterPlotSettingsVal) -> ScatterChartView_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_ScatterPlotSettings(This=self.__modelRef,  Input1=(ScatterPlotSettings.to_proto() if hasattr(ScatterPlotSettings, 'to_proto') else ScatterPlotSettings))
        ret = self.__ScatterChartServicesStubLocal.CreateScatterChartView(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return ScatterChartView_RefType(self.__channelToConnectOn, ret.Result)
        

    def GetScatterChartViewList(self) -> List[ScatterChartViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__ScatterChartServicesStubLocal.GetScatterChartViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( ScatterChartViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def AddSetWindow(self,  SetWindowEntityInfo: SetWindowEntityInfoVal) -> SetEntityInfo_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_SetWindowEntityInfo(This=self.__modelRef,  Input1=(SetWindowEntityInfo.to_proto() if hasattr(SetWindowEntityInfo, 'to_proto') else SetWindowEntityInfo))
        ret = self.__SetServicesStubLocal.AddSetWindow(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return SetEntityInfo_RefType(self.__channelToConnectOn, ret.Result)
        

    def DeleteSet(self,  SetEntityInfo: SetEntityInfo_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_ProtoReference_SetEntityInfo(This=self.__modelRef,  Input1=SetEntityInfo.get_model_ref())
        ret = self.__SetServicesStubLocal.DeleteSet(functionParam)
        

    def GetSetList(self) -> List[SetEntityInfoRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__SetServicesStubLocal.GetSetList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( SetEntityInfoRef(self.__channelToConnectOn, item) )
        return retList
        

    def CreateStereonet2DView(self) -> Optional[Stereonet2DView_RefType]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__Stereonet2DServicesStubLocal.CreateStereonet2DView(functionParam)
        
        if ret.ID.ID:
            return Stereonet2DView_RefType(self.__channelToConnectOn, ret)
        return None
        

    def GetStereonet2DViewList(self) -> List[Stereonet2DViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__Stereonet2DServicesStubLocal.GetStereonet2DViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( Stereonet2DViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def CreateStereonet3DView(self) -> Optional[Stereonet3DView_RefType]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__Stereonet3DServicesStubLocal.CreateStereonet3DView(functionParam)
        
        if ret.ID.ID:
            return Stereonet3DView_RefType(self.__channelToConnectOn, ret)
        return None
        

    def GetStereonet3DViewList(self) -> List[Stereonet3DViewRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__Stereonet3DServicesStubLocal.GetStereonet3DViewList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( Stereonet3DViewRef(self.__channelToConnectOn, item) )
        return retList
        

    def AddTraverse(self,  OrientationDataSet: OrientationDataSetVal) -> OrientationDataSet_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_OrientationDataSet(This=self.__modelRef,  Input1=(OrientationDataSet.to_proto() if hasattr(OrientationDataSet, 'to_proto') else OrientationDataSet))
        ret = self.__TraverseServicesStubLocal.AddTraverse(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return OrientationDataSet_RefType(self.__channelToConnectOn, ret.Result)
        

    def DeleteTraverse(self,  OrientationDataSet: OrientationDataSet_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_ProtoReference_OrientationDataSet(This=self.__modelRef,  Input1=OrientationDataSet.get_model_ref())
        ret = self.__TraverseServicesStubLocal.DeleteTraverse(functionParam)
        

    def GetTraverseList(self) -> List[OrientationDataSetRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__TraverseServicesStubLocal.GetTraverseList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( OrientationDataSetRef(self.__channelToConnectOn, item) )
        return retList
        

    def AddUserPlane(self,  PlaneEntityInfo: PlaneEntityInfoVal) -> PlaneEntityInfo_RefType:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_PlaneEntityInfo(This=self.__modelRef,  Input1=(PlaneEntityInfo.to_proto() if hasattr(PlaneEntityInfo, 'to_proto') else PlaneEntityInfo))
        ret = self.__UserPlaneServicesStubLocal.AddUserPlane(functionParam)
        
        if len(ret.Errors) > 0:
            raise ValueError(ret.Errors[0].ErrorMessage)
        return PlaneEntityInfo_RefType(self.__channelToConnectOn, ret.Result)
        

    def DeleteUserPlane(self,  PlaneEntityInfo: PlaneEntityInfo_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub_ProtoReference_PlaneEntityInfo(This=self.__modelRef,  Input1=PlaneEntityInfo.get_model_ref())
        ret = self.__UserPlaneServicesStubLocal.DeleteUserPlane(functionParam)
        

    def GetUserPlaneList(self) -> List[PlaneEntityInfoRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_ProjStub(This=self.__modelRef)
        ret = self.__UserPlaneServicesStubLocal.GetUserPlaneList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( PlaneEntityInfoRef(self.__channelToConnectOn, item) )
        return retList
        

 