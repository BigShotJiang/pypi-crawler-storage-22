"""Generated wrapper for ProjectSettings protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

class ProjectSettingsVal:
    """Simple wrapper for ProjectSettings with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.ProjectSettings


    def __init__(self, proto_message: Optional[Any] = None):
        """Initialize the ProjectSettings wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()



    # Properties

    @property
    def reporting_orientation_convention(self) -> Any:
        """Get the ReportingOrientationConvention field value."""
        return self._proto_message.ReportingOrientationConvention
    
    @reporting_orientation_convention.setter
    def reporting_orientation_convention(self, value: Any) -> None:
        """Set the ReportingOrientationConvention field value."""
        self._proto_message.ReportingOrientationConvention = value


    @property
    def reporting_unit_convention(self) -> Any:
        """Get the ReportingUnitConvention field value."""
        return self._proto_message.ReportingUnitConvention
    
    @reporting_unit_convention.setter
    def reporting_unit_convention(self, value: Any) -> None:
        """Set the ReportingUnitConvention field value."""
        self._proto_message.ReportingUnitConvention = value


    @property
    def use_automatic_cluster_analysis(self) -> bool:
        """Get the UseAutomaticClusterAnalysis field value."""
        return self._proto_message.UseAutomaticClusterAnalysis
    
    @use_automatic_cluster_analysis.setter
    def use_automatic_cluster_analysis(self, value: bool) -> None:
        """Set the UseAutomaticClusterAnalysis field value."""
        self._proto_message.UseAutomaticClusterAnalysis = value


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
