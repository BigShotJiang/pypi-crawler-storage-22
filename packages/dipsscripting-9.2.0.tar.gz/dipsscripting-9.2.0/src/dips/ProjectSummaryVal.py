"""Generated wrapper for ProjectSummary protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

class ProjectSummaryVal:
    """Simple wrapper for ProjectSummary with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.ProjectSummary


    def __init__(self, proto_message: Optional[Any] = None):
        """Initialize the ProjectSummary wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()



    # Properties

    @property
    def project_title(self) -> str:
        """Get the ProjectTitle field value."""
        return self._proto_message.ProjectTitle
    
    @project_title.setter
    def project_title(self, value: str) -> None:
        """Set the ProjectTitle field value."""
        self._proto_message.ProjectTitle = value


    @property
    def analysis(self) -> str:
        """Get the Analysis field value."""
        return self._proto_message.Analysis
    
    @analysis.setter
    def analysis(self, value: str) -> None:
        """Set the Analysis field value."""
        self._proto_message.Analysis = value


    @property
    def author(self) -> str:
        """Get the Author field value."""
        return self._proto_message.Author
    
    @author.setter
    def author(self, value: str) -> None:
        """Set the Author field value."""
        self._proto_message.Author = value


    @property
    def company(self) -> str:
        """Get the Company field value."""
        return self._proto_message.Company
    
    @company.setter
    def company(self, value: str) -> None:
        """Set the Company field value."""
        self._proto_message.Company = value


    @property
    def date_created(self) -> str:
        """Get the DateCreated field value."""
        return self._proto_message.DateCreated
    
    @date_created.setter
    def date_created(self, value: str) -> None:
        """Set the DateCreated field value."""
        self._proto_message.DateCreated = value


    @property
    def comment1(self) -> str:
        """Get the Comment1 field value."""
        return self._proto_message.Comment1
    
    @comment1.setter
    def comment1(self, value: str) -> None:
        """Set the Comment1 field value."""
        self._proto_message.Comment1 = value


    @property
    def comment2(self) -> str:
        """Get the Comment2 field value."""
        return self._proto_message.Comment2
    
    @comment2.setter
    def comment2(self, value: str) -> None:
        """Set the Comment2 field value."""
        self._proto_message.Comment2 = value


    @property
    def comment3(self) -> str:
        """Get the Comment3 field value."""
        return self._proto_message.Comment3
    
    @comment3.setter
    def comment3(self, value: str) -> None:
        """Set the Comment3 field value."""
        self._proto_message.Comment3 = value


    @property
    def comment4(self) -> str:
        """Get the Comment4 field value."""
        return self._proto_message.Comment4
    
    @comment4.setter
    def comment4(self, value: str) -> None:
        """Set the Comment4 field value."""
        self._proto_message.Comment4 = value


    @property
    def comment5(self) -> str:
        """Get the Comment5 field value."""
        return self._proto_message.Comment5
    
    @comment5.setter
    def comment5(self, value: str) -> None:
        """Set the Comment5 field value."""
        self._proto_message.Comment5 = value


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
