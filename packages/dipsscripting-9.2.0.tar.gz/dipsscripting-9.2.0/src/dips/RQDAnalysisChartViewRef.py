from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .RQDAnalysisChartViewVal import RQDAnalysisChartViewVal
from .DataFilterRef import DataFilterRef as DataFilter_RefType
from .RQDAnalysisSettingsVal import RQDAnalysisSettingsVal
from .ValidatableResultVal import ValidatableResultVal

class RQDAnalysisChartViewRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_RQDAnalysisChartView):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__RQDAnalysisChartServicesStubLocal = DipsAPI_pb2_grpc.RQDAnalysisChartServicesStub(channelToConnectOn)

    
    def GetValue(self) -> RQDAnalysisChartViewVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.RQDAnalysisChartView()
        ret.MergeFromString(bytes.data)
        return RQDAnalysisChartViewVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def CloseRQDAnalysisChartView(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_RQDAnalysisChartView(This=self.__modelRef)
        ret = self.__RQDAnalysisChartServicesStubLocal.CloseRQDAnalysisChartView(functionParam)
        

    def GetActiveDataFilter(self) -> Optional[DataFilter_RefType]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_RQDAnalysisChartView(This=self.__modelRef)
        ret = self.__RQDAnalysisChartServicesStubLocal.GetActiveDataFilter(functionParam)
        
        if ret.ID.ID:
            return DataFilter_RefType(self.__channelToConnectOn, ret)
        return None
        

    def SetActiveDataFilter(self,  DataFilter: DataFilter_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_RQDAnalysisChartView_ProtoReference_DataFilter(This=self.__modelRef,  Input1=DataFilter.get_model_ref())
        ret = self.__RQDAnalysisChartServicesStubLocal.SetActiveDataFilter(functionParam)
        

    def UpdateRQDAnalysisSettings(self,  RQDAnalysisSettings: RQDAnalysisSettingsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_RQDAnalysisChartView_RQDAnalysisSettings(This=self.__modelRef,  Input1=(RQDAnalysisSettings.to_proto() if hasattr(RQDAnalysisSettings, 'to_proto') else RQDAnalysisSettings))
        ret = self.__RQDAnalysisChartServicesStubLocal.UpdateRQDAnalysisSettings(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 