from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .RectangleToolEntityInfoVal import RectangleToolEntityInfoVal
from .RectangleToolEntityInfoVal import RectangleToolEntityInfoVal
from .ValidatableResultVal import ValidatableResultVal

class RectangleToolEntityInfoRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_RectangleToolEntityInfo):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__RosetteServicesStubLocal = DipsAPI_pb2_grpc.RosetteServicesStub(channelToConnectOn)
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> RectangleToolEntityInfoVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.RectangleToolEntityInfo()
        ret.MergeFromString(bytes.data)
        return RectangleToolEntityInfoVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def DeleteRosetteRectangleTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_RectangleToolEntityInfo(This=self.__modelRef)
        ret = self.__RosetteServicesStubLocal.DeleteRosetteRectangleTool(functionParam)
        

    def SetRosetteRectangleToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_RectangleToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__RosetteServicesStubLocal.SetRosetteRectangleToolVisibility(functionParam)
        

    def UpdateRosetteRectangleTool(self,  RectangleToolEntityInfo: RectangleToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_RectangleToolEntityInfo_RectangleToolEntityInfo(This=self.__modelRef,  Input1=(RectangleToolEntityInfo.to_proto() if hasattr(RectangleToolEntityInfo, 'to_proto') else RectangleToolEntityInfo))
        ret = self.__RosetteServicesStubLocal.UpdateRosetteRectangleTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def DeleteStereonet2DRectangleTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_RectangleToolEntityInfo(This=self.__modelRef)
        ret = self.__Stereonet2DServicesStubLocal.DeleteStereonet2DRectangleTool(functionParam)
        

    def SetStereonet2DRectangleToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_RectangleToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetStereonet2DRectangleToolVisibility(functionParam)
        

    def UpdateStereonet2DRectangleTool(self,  RectangleToolEntityInfo: RectangleToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_RectangleToolEntityInfo_RectangleToolEntityInfo(This=self.__modelRef,  Input1=(RectangleToolEntityInfo.to_proto() if hasattr(RectangleToolEntityInfo, 'to_proto') else RectangleToolEntityInfo))
        ret = self.__Stereonet2DServicesStubLocal.UpdateStereonet2DRectangleTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 