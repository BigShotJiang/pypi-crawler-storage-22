"""Generated wrapper for RosettePlotDisplayOptions protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .ColorSurrogateVal import ColorSurrogateVal
from .LineFormatVal import LineFormatVal
from .TextFormatVal import TextFormatVal

class RosettePlotDisplayOptionsVal:
    """Simple wrapper for RosettePlotDisplayOptions with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.RosettePlotDisplayOptions


    def __init__(self, outer_grid_line: Optional[LineFormatVal] = None, inner_grid_line: Optional[LineFormatVal] = None, stereonet_color: Optional[ColorSurrogateVal] = None, background_color: Optional[ColorSurrogateVal] = None, labels_font: Optional[TextFormatVal] = None, fill_color: Optional[ColorSurrogateVal] = None, proto_message: Optional[Any] = None):
        """Initialize the RosettePlotDisplayOptions wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if outer_grid_line is not None:
            self._proto_message.OuterGridLine.CopyFrom(outer_grid_line.to_proto())
            self._outer_grid_line_wrapper = outer_grid_line
        if inner_grid_line is not None:
            self._proto_message.InnerGridLine.CopyFrom(inner_grid_line.to_proto())
            self._inner_grid_line_wrapper = inner_grid_line
        if stereonet_color is not None:
            self._proto_message.StereonetColor.CopyFrom(stereonet_color.to_proto())
            self._stereonet_color_wrapper = stereonet_color
        if background_color is not None:
            self._proto_message.BackgroundColor.CopyFrom(background_color.to_proto())
            self._background_color_wrapper = background_color
        if labels_font is not None:
            self._proto_message.LabelsFont.CopyFrom(labels_font.to_proto())
            self._labels_font_wrapper = labels_font
        if fill_color is not None:
            self._proto_message.FillColor.CopyFrom(fill_color.to_proto())
            self._fill_color_wrapper = fill_color


    # Properties

    @property
    def trend_label_mode(self) -> Any:
        """Get the TrendLabelMode field value."""
        return self._proto_message.TrendLabelMode
    
    @trend_label_mode.setter
    def trend_label_mode(self, value: Any) -> None:
        """Set the TrendLabelMode field value."""
        self._proto_message.TrendLabelMode = value


    @property
    def show_exterior_ticks(self) -> bool:
        """Get the ShowExteriorTicks field value."""
        return self._proto_message.ShowExteriorTicks
    
    @show_exterior_ticks.setter
    def show_exterior_ticks(self, value: bool) -> None:
        """Set the ShowExteriorTicks field value."""
        self._proto_message.ShowExteriorTicks = value


    @property
    def outer_grid_line(self) -> LineFormatVal:
        """Get the OuterGridLine field as a wrapper."""
        if not hasattr(self, '_outer_grid_line_wrapper'):
            self._outer_grid_line_wrapper = LineFormatVal(proto_message=self._proto_message.OuterGridLine)
        return self._outer_grid_line_wrapper
    
    @outer_grid_line.setter
    def outer_grid_line(self, value: LineFormatVal) -> None:
        """Set the OuterGridLine field to a wrapper."""
        self._proto_message.OuterGridLine.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_outer_grid_line_wrapper'):
            self._outer_grid_line_wrapper._proto_message.CopyFrom(self._proto_message.OuterGridLine)


    @property
    def inner_grid_line(self) -> LineFormatVal:
        """Get the InnerGridLine field as a wrapper."""
        if not hasattr(self, '_inner_grid_line_wrapper'):
            self._inner_grid_line_wrapper = LineFormatVal(proto_message=self._proto_message.InnerGridLine)
        return self._inner_grid_line_wrapper
    
    @inner_grid_line.setter
    def inner_grid_line(self, value: LineFormatVal) -> None:
        """Set the InnerGridLine field to a wrapper."""
        self._proto_message.InnerGridLine.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_inner_grid_line_wrapper'):
            self._inner_grid_line_wrapper._proto_message.CopyFrom(self._proto_message.InnerGridLine)


    @property
    def stereonet_color(self) -> ColorSurrogateVal:
        """Get the StereonetColor field as a wrapper."""
        if not hasattr(self, '_stereonet_color_wrapper'):
            self._stereonet_color_wrapper = ColorSurrogateVal(proto_message=self._proto_message.StereonetColor)
        return self._stereonet_color_wrapper
    
    @stereonet_color.setter
    def stereonet_color(self, value: ColorSurrogateVal) -> None:
        """Set the StereonetColor field to a wrapper."""
        self._proto_message.StereonetColor.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_stereonet_color_wrapper'):
            self._stereonet_color_wrapper._proto_message.CopyFrom(self._proto_message.StereonetColor)


    @property
    def background_color(self) -> ColorSurrogateVal:
        """Get the BackgroundColor field as a wrapper."""
        if not hasattr(self, '_background_color_wrapper'):
            self._background_color_wrapper = ColorSurrogateVal(proto_message=self._proto_message.BackgroundColor)
        return self._background_color_wrapper
    
    @background_color.setter
    def background_color(self, value: ColorSurrogateVal) -> None:
        """Set the BackgroundColor field to a wrapper."""
        self._proto_message.BackgroundColor.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_background_color_wrapper'):
            self._background_color_wrapper._proto_message.CopyFrom(self._proto_message.BackgroundColor)


    @property
    def outer_tick_spacing_in_degrees(self) -> int:
        """Get the OuterTickSpacingInDegrees field value."""
        return self._proto_message.OuterTickSpacingInDegrees
    
    @outer_tick_spacing_in_degrees.setter
    def outer_tick_spacing_in_degrees(self, value: int) -> None:
        """Set the OuterTickSpacingInDegrees field value."""
        self._proto_message.OuterTickSpacingInDegrees = value


    @property
    def labels_font(self) -> TextFormatVal:
        """Get the LabelsFont field as a wrapper."""
        if not hasattr(self, '_labels_font_wrapper'):
            self._labels_font_wrapper = TextFormatVal(proto_message=self._proto_message.LabelsFont)
        return self._labels_font_wrapper
    
    @labels_font.setter
    def labels_font(self, value: TextFormatVal) -> None:
        """Set the LabelsFont field to a wrapper."""
        self._proto_message.LabelsFont.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_labels_font_wrapper'):
            self._labels_font_wrapper._proto_message.CopyFrom(self._proto_message.LabelsFont)


    @property
    def fill_color(self) -> ColorSurrogateVal:
        """Get the FillColor field as a wrapper."""
        if not hasattr(self, '_fill_color_wrapper'):
            self._fill_color_wrapper = ColorSurrogateVal(proto_message=self._proto_message.FillColor)
        return self._fill_color_wrapper
    
    @fill_color.setter
    def fill_color(self, value: ColorSurrogateVal) -> None:
        """Set the FillColor field to a wrapper."""
        self._proto_message.FillColor.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_fill_color_wrapper'):
            self._fill_color_wrapper._proto_message.CopyFrom(self._proto_message.FillColor)


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
