"""Generated wrapper for RotateDataSettings protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .AngleDataVal import AngleDataVal
from .TrendPlungeVal import TrendPlungeVal

class RotateDataSettingsVal:
    """Simple wrapper for RotateDataSettings with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.RotateDataSettings


    def __init__(self, rotation_axis: Optional[TrendPlungeVal] = None, cw_rotation_angle: Optional[AngleDataVal] = None, proto_message: Optional[Any] = None):
        """Initialize the RotateDataSettings wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if rotation_axis is not None:
            self._proto_message.RotationAxis.CopyFrom(rotation_axis.to_proto())
            self._rotation_axis_wrapper = rotation_axis
        if cw_rotation_angle is not None:
            self._proto_message.CWRotationAngle.CopyFrom(cw_rotation_angle.to_proto())
            self._cw_rotation_angle_wrapper = cw_rotation_angle


    # Properties

    @property
    def rotation_axis(self) -> TrendPlungeVal:
        """Get the RotationAxis field as a wrapper."""
        if not hasattr(self, '_rotation_axis_wrapper'):
            self._rotation_axis_wrapper = TrendPlungeVal(proto_message=self._proto_message.RotationAxis)
        return self._rotation_axis_wrapper
    
    @rotation_axis.setter
    def rotation_axis(self, value: TrendPlungeVal) -> None:
        """Set the RotationAxis field to a wrapper."""
        self._proto_message.RotationAxis.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_rotation_axis_wrapper'):
            self._rotation_axis_wrapper._proto_message.CopyFrom(self._proto_message.RotationAxis)


    @property
    def cw_rotation_angle(self) -> AngleDataVal:
        """Get the CWRotationAngle field as a wrapper."""
        if not hasattr(self, '_cw_rotation_angle_wrapper'):
            self._cw_rotation_angle_wrapper = AngleDataVal(proto_message=self._proto_message.CWRotationAngle)
        return self._cw_rotation_angle_wrapper
    
    @cw_rotation_angle.setter
    def cw_rotation_angle(self, value: AngleDataVal) -> None:
        """Set the CWRotationAngle field to a wrapper."""
        self._proto_message.CWRotationAngle.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_cw_rotation_angle_wrapper'):
            self._cw_rotation_angle_wrapper._proto_message.CopyFrom(self._proto_message.CWRotationAngle)


    @property
    def rotate_sets(self) -> bool:
        """Get the RotateSets field value."""
        return self._proto_message.RotateSets
    
    @rotate_sets.setter
    def rotate_sets(self, value: bool) -> None:
        """Set the RotateSets field value."""
        self._proto_message.RotateSets = value


    @property
    def rotate_user_planes(self) -> bool:
        """Get the RotateUserPlanes field value."""
        return self._proto_message.RotateUserPlanes
    
    @rotate_user_planes.setter
    def rotate_user_planes(self, value: bool) -> None:
        """Set the RotateUserPlanes field value."""
        self._proto_message.RotateUserPlanes = value


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
