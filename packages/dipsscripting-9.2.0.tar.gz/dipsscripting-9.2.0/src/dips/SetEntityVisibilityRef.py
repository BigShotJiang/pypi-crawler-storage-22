from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .SetEntityVisibilityVal import SetEntityVisibilityVal
from .SetEntityOptionsVal import SetEntityOptionsVal
from .ValidatableResultVal import ValidatableResultVal

class SetEntityVisibilityRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_SetEntityVisibility):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)
        self.__Stereonet3DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet3DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> SetEntityVisibilityVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.SetEntityVisibility()
        ret.MergeFromString(bytes.data)
        return SetEntityVisibilityVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def SetMeanSetPlaneEntityOptions(self,  SetEntityOptions: SetEntityOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_SetEntityVisibility_SetEntityOptions(This=self.__modelRef,  Input1=(SetEntityOptions.to_proto() if hasattr(SetEntityOptions, 'to_proto') else SetEntityOptions))
        ret = self.__Stereonet2DServicesStubLocal.SetMeanSetPlaneEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetMeanSetPlaneEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_SetEntityVisibility_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetMeanSetPlaneEntityVisibility(functionParam)
        

    def SetMeanSetPlaneEntityOptions(self,  SetEntityOptions: SetEntityOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_SetEntityVisibility_SetEntityOptions(This=self.__modelRef,  Input1=(SetEntityOptions.to_proto() if hasattr(SetEntityOptions, 'to_proto') else SetEntityOptions))
        ret = self.__Stereonet3DServicesStubLocal.SetMeanSetPlaneEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetMeanSetPlaneEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_SetEntityVisibility_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetMeanSetPlaneEntityVisibility(functionParam)
        

 