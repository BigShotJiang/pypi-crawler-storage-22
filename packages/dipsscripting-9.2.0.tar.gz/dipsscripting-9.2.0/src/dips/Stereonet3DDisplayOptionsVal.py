"""Generated wrapper for Stereonet3DDisplayOptions protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .ColorSurrogateVal import ColorSurrogateVal

class Stereonet3DDisplayOptionsVal:
    """Simple wrapper for Stereonet3DDisplayOptions with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.Stereonet3DDisplayOptions


    def __init__(self, background_color: Optional[ColorSurrogateVal] = None, proto_message: Optional[Any] = None):
        """Initialize the Stereonet3DDisplayOptions wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if background_color is not None:
            self._proto_message.BackgroundColor.CopyFrom(background_color.to_proto())
            self._background_color_wrapper = background_color


    # Properties

    @property
    def show_axes(self) -> bool:
        """Get the ShowAxes field value."""
        return self._proto_message.ShowAxes
    
    @show_axes.setter
    def show_axes(self, value: bool) -> None:
        """Set the ShowAxes field value."""
        self._proto_message.ShowAxes = value


    @property
    def show_center_cross(self) -> bool:
        """Get the ShowCenterCross field value."""
        return self._proto_message.ShowCenterCross
    
    @show_center_cross.setter
    def show_center_cross(self, value: bool) -> None:
        """Set the ShowCenterCross field value."""
        self._proto_message.ShowCenterCross = value


    @property
    def background_color(self) -> ColorSurrogateVal:
        """Get the BackgroundColor field as a wrapper."""
        if not hasattr(self, '_background_color_wrapper'):
            self._background_color_wrapper = ColorSurrogateVal(proto_message=self._proto_message.BackgroundColor)
        return self._background_color_wrapper
    
    @background_color.setter
    def background_color(self, value: ColorSurrogateVal) -> None:
        """Set the BackgroundColor field to a wrapper."""
        self._proto_message.BackgroundColor.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_background_color_wrapper'):
            self._background_color_wrapper._proto_message.CopyFrom(self._proto_message.BackgroundColor)


    @property
    def show_directional_arrows(self) -> bool:
        """Get the ShowDirectionalArrows field value."""
        return self._proto_message.ShowDirectionalArrows
    
    @show_directional_arrows.setter
    def show_directional_arrows(self, value: bool) -> None:
        """Set the ShowDirectionalArrows field value."""
        self._proto_message.ShowDirectionalArrows = value


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
