from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .Stereonet3DViewVal import Stereonet3DViewVal
from .ContourEntityVisibilityVal import ContourEntityVisibilityVal
from .ContourOptionsVal import ContourOptionsVal
from .DataFilterRef import DataFilterRef as DataFilter_RefType
from .FoldEntityVisibilityRef import FoldEntityVisibilityRef
from .FoldWindowEntityVisibilityRef import FoldWindowEntityVisibilityRef
from .GlobalPlaneEntityVisibilityVal import GlobalPlaneEntityVisibilityVal
from .IntersectionOptionsVal import IntersectionOptionsVal
from .PlaneEntityVisibilityRef import PlaneEntityVisibilityRef
from .PoleEntityOptionsVal import PoleEntityOptionsVal
from .QuantitativeContourSettingsVal import QuantitativeContourSettingsVal
from .SetEntityVisibilityRef import SetEntityVisibilityRef
from .SetVersusSetVal import SetVersusSetVal
from .SetWindowEntityVisibilityRef import SetWindowEntityVisibilityRef
from .StereonetOverlayEntityVisibilityVal import StereonetOverlayEntityVisibilityVal
from .TraverseEntityVisibilityRef import TraverseEntityVisibilityRef
from .ValidatableResultVal import ValidatableResultVal
from .VectorDensityContourSettingsVal import VectorDensityContourSettingsVal

class Stereonet3DViewRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_Stereonet3DView):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__Stereonet3DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet3DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> Stereonet3DViewVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.Stereonet3DView()
        ret.MergeFromString(bytes.data)
        return Stereonet3DViewVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def CloseStereonet3DView(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView(This=self.__modelRef)
        ret = self.__Stereonet3DServicesStubLocal.CloseStereonet3DView(functionParam)
        

    def GetActiveDataFilter(self) -> Optional[DataFilter_RefType]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView(This=self.__modelRef)
        ret = self.__Stereonet3DServicesStubLocal.GetActiveDataFilter(functionParam)
        
        if ret.ID.ID:
            return DataFilter_RefType(self.__channelToConnectOn, ret)
        return None
        

    def GetBestFitFoldPlaneEntityVisibilityList(self) -> List[FoldEntityVisibilityRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView(This=self.__modelRef)
        ret = self.__Stereonet3DServicesStubLocal.GetBestFitFoldPlaneEntityVisibilityList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( FoldEntityVisibilityRef(self.__channelToConnectOn, item) )
        return retList
        

    def GetFoldWindowEntityVisibilityList(self) -> List[FoldWindowEntityVisibilityRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView(This=self.__modelRef)
        ret = self.__Stereonet3DServicesStubLocal.GetFoldWindowEntityVisibilityList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( FoldWindowEntityVisibilityRef(self.__channelToConnectOn, item) )
        return retList
        

    def GetMeanSetPlaneEntityVisibilityList(self) -> List[SetEntityVisibilityRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView(This=self.__modelRef)
        ret = self.__Stereonet3DServicesStubLocal.GetMeanSetPlaneEntityVisibilityList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( SetEntityVisibilityRef(self.__channelToConnectOn, item) )
        return retList
        

    def GetSetWindowEntityVisibilityList(self) -> List[SetWindowEntityVisibilityRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView(This=self.__modelRef)
        ret = self.__Stereonet3DServicesStubLocal.GetSetWindowEntityVisibilityList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( SetWindowEntityVisibilityRef(self.__channelToConnectOn, item) )
        return retList
        

    def GetTraverseEntityVisibilityList(self) -> List[TraverseEntityVisibilityRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView(This=self.__modelRef)
        ret = self.__Stereonet3DServicesStubLocal.GetTraverseEntityVisibilityList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( TraverseEntityVisibilityRef(self.__channelToConnectOn, item) )
        return retList
        

    def GetUserPlaneEntityVisibilityList(self) -> List[PlaneEntityVisibilityRef]:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView(This=self.__modelRef)
        ret = self.__Stereonet3DServicesStubLocal.GetUserPlaneEntityVisibilityList(functionParam)
        
        retList=[]
        for item in ret.items:
            retList.append( PlaneEntityVisibilityRef(self.__channelToConnectOn, item) )
        return retList
        

    def SetActiveDataFilter(self,  DataFilter: DataFilter_RefType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_ProtoReference_DataFilter(This=self.__modelRef,  Input1=DataFilter.get_model_ref())
        ret = self.__Stereonet3DServicesStubLocal.SetActiveDataFilter(functionParam)
        

    def SetBestFitFoldPlaneEntityGroupVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetBestFitFoldPlaneEntityGroupVisibility(functionParam)
        

    def SetContourEntityOptions(self,  ContourEntityVisibility: ContourEntityVisibilityVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_ContourEntityVisibility(This=self.__modelRef,  Input1=(ContourEntityVisibility.to_proto() if hasattr(ContourEntityVisibility, 'to_proto') else ContourEntityVisibility))
        ret = self.__Stereonet3DServicesStubLocal.SetContourEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetContourEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetContourEntityVisibility(functionParam)
        

    def SetContourType(self,  eContourType: DipsAPI_pb2.eContourType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_eContourType(This=self.__modelRef,  Input1=eContourType)
        ret = self.__Stereonet3DServicesStubLocal.SetContourType(functionParam)
        

    def SetFoldWindowEntityGroupVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetFoldWindowEntityGroupVisibility(functionParam)
        

    def SetGlobalBestFitPlaneEntityOptions(self,  GlobalPlaneEntityVisibility: GlobalPlaneEntityVisibilityVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_GlobalPlaneEntityVisibility(This=self.__modelRef,  Input1=(GlobalPlaneEntityVisibility.to_proto() if hasattr(GlobalPlaneEntityVisibility, 'to_proto') else GlobalPlaneEntityVisibility))
        ret = self.__Stereonet3DServicesStubLocal.SetGlobalBestFitPlaneEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetGlobalBestFitPlaneEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetGlobalBestFitPlaneEntityVisibility(functionParam)
        

    def SetGlobalMeanPlaneEntityOptions(self,  GlobalPlaneEntityVisibility: GlobalPlaneEntityVisibilityVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_GlobalPlaneEntityVisibility(This=self.__modelRef,  Input1=(GlobalPlaneEntityVisibility.to_proto() if hasattr(GlobalPlaneEntityVisibility, 'to_proto') else GlobalPlaneEntityVisibility))
        ret = self.__Stereonet3DServicesStubLocal.SetGlobalMeanPlaneEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetGlobalMeanPlaneEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetGlobalMeanPlaneEntityVisibility(functionParam)
        

    def SetIntersectionEntityOptions(self,  IntersectionOptions: IntersectionOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_IntersectionOptions(This=self.__modelRef,  Input1=(IntersectionOptions.to_proto() if hasattr(IntersectionOptions, 'to_proto') else IntersectionOptions))
        ret = self.__Stereonet3DServicesStubLocal.SetIntersectionEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetIntersectionEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetIntersectionEntityVisibility(functionParam)
        

    def SetIntersectionType(self,  eIntersectionType: DipsAPI_pb2.eIntersectionType):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_eIntersectionType(This=self.__modelRef,  Input1=eIntersectionType)
        ret = self.__Stereonet3DServicesStubLocal.SetIntersectionType(functionParam)
        

    def SetIntersectionVectorContourOptions(self,  ContourOptions: ContourOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_ContourOptions(This=self.__modelRef,  Input1=(ContourOptions.to_proto() if hasattr(ContourOptions, 'to_proto') else ContourOptions))
        ret = self.__Stereonet3DServicesStubLocal.SetIntersectionVectorContourOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetIntersectionVectorDensityContourSettings(self,  VectorDensityContourSettings: VectorDensityContourSettingsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_VectorDensityContourSettings(This=self.__modelRef,  Input1=(VectorDensityContourSettings.to_proto() if hasattr(VectorDensityContourSettings, 'to_proto') else VectorDensityContourSettings))
        ret = self.__Stereonet3DServicesStubLocal.SetIntersectionVectorDensityContourSettings(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetIsWeighted(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetIsWeighted(functionParam)
        

    def SetLegendVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetLegendVisibility(functionParam)
        

    def SetMeanSetPlaneEntityGroupVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetMeanSetPlaneEntityGroupVisibility(functionParam)
        

    def SetPoleEntityOptions(self,  PoleEntityOptions: PoleEntityOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_PoleEntityOptions(This=self.__modelRef,  Input1=(PoleEntityOptions.to_proto() if hasattr(PoleEntityOptions, 'to_proto') else PoleEntityOptions))
        ret = self.__Stereonet3DServicesStubLocal.SetPoleEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetPoleEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetPoleEntityVisibility(functionParam)
        

    def SetPoleVectorContourOptions(self,  ContourOptions: ContourOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_ContourOptions(This=self.__modelRef,  Input1=(ContourOptions.to_proto() if hasattr(ContourOptions, 'to_proto') else ContourOptions))
        ret = self.__Stereonet3DServicesStubLocal.SetPoleVectorContourOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetPoleVectorDensityContourSettings(self,  VectorDensityContourSettings: VectorDensityContourSettingsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_VectorDensityContourSettings(This=self.__modelRef,  Input1=(VectorDensityContourSettings.to_proto() if hasattr(VectorDensityContourSettings, 'to_proto') else VectorDensityContourSettings))
        ret = self.__Stereonet3DServicesStubLocal.SetPoleVectorDensityContourSettings(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetQuantitativeContourOptions(self,  ContourOptions: ContourOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_ContourOptions(This=self.__modelRef,  Input1=(ContourOptions.to_proto() if hasattr(ContourOptions, 'to_proto') else ContourOptions))
        ret = self.__Stereonet3DServicesStubLocal.SetQuantitativeContourOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetQuantitativeContourSettings(self,  QuantitativeContourSettings: QuantitativeContourSettingsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_QuantitativeContourSettings(This=self.__modelRef,  Input1=(QuantitativeContourSettings.to_proto() if hasattr(QuantitativeContourSettings, 'to_proto') else QuantitativeContourSettings))
        ret = self.__Stereonet3DServicesStubLocal.SetQuantitativeContourSettings(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetSetVersusSet(self,  SetVersusSet: SetVersusSetVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_SetVersusSet(This=self.__modelRef,  Input1=(SetVersusSet.to_proto() if hasattr(SetVersusSet, 'to_proto') else SetVersusSet))
        ret = self.__Stereonet3DServicesStubLocal.SetSetVersusSet(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetSetWindowEntityGroupVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetSetWindowEntityGroupVisibility(functionParam)
        

    def SetStereonetOverlayEntityOptions(self,  StereonetOverlayEntityVisibility: StereonetOverlayEntityVisibilityVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_StereonetOverlayEntityVisibility(This=self.__modelRef,  Input1=(StereonetOverlayEntityVisibility.to_proto() if hasattr(StereonetOverlayEntityVisibility, 'to_proto') else StereonetOverlayEntityVisibility))
        ret = self.__Stereonet3DServicesStubLocal.SetStereonetOverlayEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetStereonetOverlayEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetStereonetOverlayEntityVisibility(functionParam)
        

    def SetTraverseEntityGroupVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetTraverseEntityGroupVisibility(functionParam)
        

    def SetUserPlaneEntityGroupVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetUserPlaneEntityGroupVisibility(functionParam)
        

    def SetVectorMode(self,  eVectorMode: DipsAPI_pb2.eVectorMode):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_Stereonet3DView_eVectorMode(This=self.__modelRef,  Input1=eVectorMode)
        ret = self.__Stereonet3DServicesStubLocal.SetVectorMode(functionParam)
        

 