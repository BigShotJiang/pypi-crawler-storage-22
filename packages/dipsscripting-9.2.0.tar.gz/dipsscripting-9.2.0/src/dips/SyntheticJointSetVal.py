"""Generated wrapper for SyntheticJointSet protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .AngleDataVal import AngleDataVal

class SyntheticJointSetVal:
    """Simple wrapper for SyntheticJointSet with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.SyntheticJointSet


    def __init__(self, mean_dip: Optional[AngleDataVal] = None, mean_dip_direction: Optional[AngleDataVal] = None, standard_deviation: Optional[AngleDataVal] = None, proto_message: Optional[Any] = None):
        """Initialize the SyntheticJointSet wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if mean_dip is not None:
            self._proto_message.MeanDip.CopyFrom(mean_dip.to_proto())
            self._mean_dip_wrapper = mean_dip
        if mean_dip_direction is not None:
            self._proto_message.MeanDipDirection.CopyFrom(mean_dip_direction.to_proto())
            self._mean_dip_direction_wrapper = mean_dip_direction
        if standard_deviation is not None:
            self._proto_message.StandardDeviation.CopyFrom(standard_deviation.to_proto())
            self._standard_deviation_wrapper = standard_deviation


    # Properties

    @property
    def mean_dip(self) -> AngleDataVal:
        """Get the MeanDip field as a wrapper."""
        if not hasattr(self, '_mean_dip_wrapper'):
            self._mean_dip_wrapper = AngleDataVal(proto_message=self._proto_message.MeanDip)
        return self._mean_dip_wrapper
    
    @mean_dip.setter
    def mean_dip(self, value: AngleDataVal) -> None:
        """Set the MeanDip field to a wrapper."""
        self._proto_message.MeanDip.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_mean_dip_wrapper'):
            self._mean_dip_wrapper._proto_message.CopyFrom(self._proto_message.MeanDip)


    @property
    def mean_dip_direction(self) -> AngleDataVal:
        """Get the MeanDipDirection field as a wrapper."""
        if not hasattr(self, '_mean_dip_direction_wrapper'):
            self._mean_dip_direction_wrapper = AngleDataVal(proto_message=self._proto_message.MeanDipDirection)
        return self._mean_dip_direction_wrapper
    
    @mean_dip_direction.setter
    def mean_dip_direction(self, value: AngleDataVal) -> None:
        """Set the MeanDipDirection field to a wrapper."""
        self._proto_message.MeanDipDirection.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_mean_dip_direction_wrapper'):
            self._mean_dip_direction_wrapper._proto_message.CopyFrom(self._proto_message.MeanDipDirection)


    @property
    def standard_deviation(self) -> AngleDataVal:
        """Get the StandardDeviation field as a wrapper."""
        if not hasattr(self, '_standard_deviation_wrapper'):
            self._standard_deviation_wrapper = AngleDataVal(proto_message=self._proto_message.StandardDeviation)
        return self._standard_deviation_wrapper
    
    @standard_deviation.setter
    def standard_deviation(self, value: AngleDataVal) -> None:
        """Set the StandardDeviation field to a wrapper."""
        self._proto_message.StandardDeviation.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_standard_deviation_wrapper'):
            self._standard_deviation_wrapper._proto_message.CopyFrom(self._proto_message.StandardDeviation)


    @property
    def joint_quantity(self) -> int:
        """Get the JointQuantity field value."""
        return self._proto_message.JointQuantity
    
    @joint_quantity.setter
    def joint_quantity(self, value: int) -> None:
        """Set the JointQuantity field value."""
        self._proto_message.JointQuantity = value


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
