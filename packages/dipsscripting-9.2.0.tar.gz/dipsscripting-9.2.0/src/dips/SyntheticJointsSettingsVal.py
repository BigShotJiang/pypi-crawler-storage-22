"""Generated wrapper for SyntheticJointsSettings protobuf message."""

from typing import Any, Optional, List, Dict
from . import DipsAPI_pb2

from .ProtobufCollectionWrappers import _ProtobufListWrapper, _ProtobufMapWrapper

from .AngleDataVal import AngleDataVal
from .SyntheticJointSetVal import SyntheticJointSetVal

class SyntheticJointsSettingsVal:
    """Simple wrapper for SyntheticJointsSettings with Pythonic getters and setters."""

    _proto_class = DipsAPI_pb2.SyntheticJointsSettings


    def __init__(self, dip_error: Optional[AngleDataVal] = None, dip_direction_error: Optional[AngleDataVal] = None, proto_message: Optional[Any] = None):
        """Initialize the SyntheticJointsSettings wrapper."""
        # Initialize the protobuf message
        if proto_message is not None:
            self._proto_message = proto_message
        else:
            self._proto_message = self._proto_class()

        if dip_error is not None:
            self._proto_message.DipError.CopyFrom(dip_error.to_proto())
            self._dip_error_wrapper = dip_error
        if dip_direction_error is not None:
            self._proto_message.DipDirectionError.CopyFrom(dip_direction_error.to_proto())
            self._dip_direction_error_wrapper = dip_direction_error


    # Properties

    @property
    def joint_sets(self) -> List[SyntheticJointSetVal]:
        """Get the JointSets field as a list of wrappers."""
        return _ProtobufListWrapper(self._proto_message.JointSets, SyntheticJointSetVal)
    
    @joint_sets.setter
    def joint_sets(self, value: List[SyntheticJointSetVal]) -> None:
        """Set the JointSets field to a list of wrappers."""
        if not isinstance(value, (list, tuple)):
            raise TypeError(f"Expected list or tuple, got {type(value).__name__}")
        # Clear the repeated field using slice assignment
        self._proto_message.JointSets[:] = []
        for item in value:
            self._proto_message.JointSets.append(item.to_proto())


    @property
    def apply_random_joints(self) -> bool:
        """Get the ApplyRandomJoints field value."""
        return self._proto_message.ApplyRandomJoints
    
    @apply_random_joints.setter
    def apply_random_joints(self, value: bool) -> None:
        """Set the ApplyRandomJoints field value."""
        self._proto_message.ApplyRandomJoints = value


    @property
    def random_joint_quantity(self) -> int:
        """Get the RandomJointQuantity field value."""
        return self._proto_message.RandomJointQuantity
    
    @random_joint_quantity.setter
    def random_joint_quantity(self, value: int) -> None:
        """Set the RandomJointQuantity field value."""
        self._proto_message.RandomJointQuantity = value


    @property
    def apply_error(self) -> bool:
        """Get the ApplyError field value."""
        return self._proto_message.ApplyError
    
    @apply_error.setter
    def apply_error(self, value: bool) -> None:
        """Set the ApplyError field value."""
        self._proto_message.ApplyError = value


    @property
    def dip_error(self) -> AngleDataVal:
        """Get the DipError field as a wrapper."""
        if not hasattr(self, '_dip_error_wrapper'):
            self._dip_error_wrapper = AngleDataVal(proto_message=self._proto_message.DipError)
        return self._dip_error_wrapper
    
    @dip_error.setter
    def dip_error(self, value: AngleDataVal) -> None:
        """Set the DipError field to a wrapper."""
        self._proto_message.DipError.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_dip_error_wrapper'):
            self._dip_error_wrapper._proto_message.CopyFrom(self._proto_message.DipError)


    @property
    def dip_direction_error(self) -> AngleDataVal:
        """Get the DipDirectionError field as a wrapper."""
        if not hasattr(self, '_dip_direction_error_wrapper'):
            self._dip_direction_error_wrapper = AngleDataVal(proto_message=self._proto_message.DipDirectionError)
        return self._dip_direction_error_wrapper
    
    @dip_direction_error.setter
    def dip_direction_error(self, value: AngleDataVal) -> None:
        """Set the DipDirectionError field to a wrapper."""
        self._proto_message.DipDirectionError.CopyFrom(value.to_proto())
        # Update the cached wrapper if it exists
        if hasattr(self, '_dip_direction_error_wrapper'):
            self._dip_direction_error_wrapper._proto_message.CopyFrom(self._proto_message.DipDirectionError)


    @property
    def error_type(self) -> Any:
        """Get the ErrorType field value."""
        return self._proto_message.ErrorType
    
    @error_type.setter
    def error_type(self, value: Any) -> None:
        """Set the ErrorType field value."""
        self._proto_message.ErrorType = value


    # Utility methods

    def to_proto(self):
        """Get the underlying protobuf message."""
        return self._proto_message
    
    @classmethod
    def from_proto(cls, proto_message):
        """Create wrapper from existing protobuf message."""
        wrapper = cls()
        wrapper._proto_message.CopyFrom(proto_message)
        return wrapper
    
    def copy(self):
        """Create a copy of this wrapper."""
        new_wrapper = self.__class__()
        new_wrapper._proto_message.CopyFrom(self._proto_message)
        return new_wrapper
    
    def __str__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
    
    def __repr__(self) -> str:
        """Detailed string representation."""
        return f"{self.__class__.__name__}({self._proto_message})"
