from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .TextToolEntityInfoVal import TextToolEntityInfoVal
from .TextToolEntityInfoVal import TextToolEntityInfoVal
from .ValidatableResultVal import ValidatableResultVal

class TextToolEntityInfoRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_TextToolEntityInfo):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__RosetteServicesStubLocal = DipsAPI_pb2_grpc.RosetteServicesStub(channelToConnectOn)
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> TextToolEntityInfoVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.TextToolEntityInfo()
        ret.MergeFromString(bytes.data)
        return TextToolEntityInfoVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def DeleteRosetteTextTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TextToolEntityInfo(This=self.__modelRef)
        ret = self.__RosetteServicesStubLocal.DeleteRosetteTextTool(functionParam)
        

    def SetRosetteTextToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TextToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__RosetteServicesStubLocal.SetRosetteTextToolVisibility(functionParam)
        

    def UpdateRosetteTextTool(self,  TextToolEntityInfo: TextToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TextToolEntityInfo_TextToolEntityInfo(This=self.__modelRef,  Input1=(TextToolEntityInfo.to_proto() if hasattr(TextToolEntityInfo, 'to_proto') else TextToolEntityInfo))
        ret = self.__RosetteServicesStubLocal.UpdateRosetteTextTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def DeleteStereonet2DTextTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TextToolEntityInfo(This=self.__modelRef)
        ret = self.__Stereonet2DServicesStubLocal.DeleteStereonet2DTextTool(functionParam)
        

    def SetStereonet2DTextToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TextToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetStereonet2DTextToolVisibility(functionParam)
        

    def UpdateStereonet2DTextTool(self,  TextToolEntityInfo: TextToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TextToolEntityInfo_TextToolEntityInfo(This=self.__modelRef,  Input1=(TextToolEntityInfo.to_proto() if hasattr(TextToolEntityInfo, 'to_proto') else TextToolEntityInfo))
        ret = self.__Stereonet2DServicesStubLocal.UpdateStereonet2DTextTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 