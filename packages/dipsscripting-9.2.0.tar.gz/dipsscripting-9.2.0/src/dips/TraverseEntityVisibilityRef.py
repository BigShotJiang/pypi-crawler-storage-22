from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .TraverseEntityVisibilityVal import TraverseEntityVisibilityVal
from .TraverseEntityOptionsVal import TraverseEntityOptionsVal
from .ValidatableResultVal import ValidatableResultVal

class TraverseEntityVisibilityRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_TraverseEntityVisibility):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)
        self.__Stereonet3DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet3DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> TraverseEntityVisibilityVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.TraverseEntityVisibility()
        ret.MergeFromString(bytes.data)
        return TraverseEntityVisibilityVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def SetTraverseEntityOptions(self,  TraverseEntityOptions: TraverseEntityOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TraverseEntityVisibility_TraverseEntityOptions(This=self.__modelRef,  Input1=(TraverseEntityOptions.to_proto() if hasattr(TraverseEntityOptions, 'to_proto') else TraverseEntityOptions))
        ret = self.__Stereonet2DServicesStubLocal.SetTraverseEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetTraverseEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TraverseEntityVisibility_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetTraverseEntityVisibility(functionParam)
        

    def SetTraverseEntityOptions(self,  TraverseEntityOptions: TraverseEntityOptionsVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TraverseEntityVisibility_TraverseEntityOptions(This=self.__modelRef,  Input1=(TraverseEntityOptions.to_proto() if hasattr(TraverseEntityOptions, 'to_proto') else TraverseEntityOptions))
        ret = self.__Stereonet3DServicesStubLocal.SetTraverseEntityOptions(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def SetTraverseEntityVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TraverseEntityVisibility_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet3DServicesStubLocal.SetTraverseEntityVisibility(functionParam)
        

 