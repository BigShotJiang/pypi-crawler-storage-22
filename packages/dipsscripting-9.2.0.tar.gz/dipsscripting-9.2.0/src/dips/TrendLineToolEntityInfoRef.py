from typing import List, Optional
from . import DipsAPI_pb2_grpc
from . import DipsAPI_pb2
from .TrendLineToolEntityInfoVal import TrendLineToolEntityInfoVal
from .TrendLineToolEntityInfoVal import TrendLineToolEntityInfoVal
from .ValidatableResultVal import ValidatableResultVal

class TrendLineToolEntityInfoRef:
    def __init__(self, channelToConnectOn, ref: DipsAPI_pb2.ProtoReference_TrendLineToolEntityInfo):
        self.__modelRef = ref
        self.__refManagerStub = DipsAPI_pb2_grpc.nSameModuleReferenceAccessorStub(channelToConnectOn)
        self.__channelToConnectOn = channelToConnectOn
        self.__RosetteServicesStubLocal = DipsAPI_pb2_grpc.RosetteServicesStub(channelToConnectOn)
        self.__Stereonet2DServicesStubLocal = DipsAPI_pb2_grpc.Stereonet2DServicesStub(channelToConnectOn)

    
    def GetValue(self) -> TrendLineToolEntityInfoVal:
        bytes = self.__refManagerStub.GetValue(self.__modelRef.ID)
        ret = DipsAPI_pb2.TrendLineToolEntityInfo()
        ret.MergeFromString(bytes.data)
        return TrendLineToolEntityInfoVal.from_proto(ret)
    
    def get_model_ref(self):
        """Get the underlying model reference for direct protobuf operations."""
        return self.__modelRef
    
    def DeleteRosetteTrendLineTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TrendLineToolEntityInfo(This=self.__modelRef)
        ret = self.__RosetteServicesStubLocal.DeleteRosetteTrendLineTool(functionParam)
        

    def SetRosetteTrendLineToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TrendLineToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__RosetteServicesStubLocal.SetRosetteTrendLineToolVisibility(functionParam)
        

    def UpdateRosetteTrendLineTool(self,  TrendLineToolEntityInfo: TrendLineToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TrendLineToolEntityInfo_TrendLineToolEntityInfo(This=self.__modelRef,  Input1=(TrendLineToolEntityInfo.to_proto() if hasattr(TrendLineToolEntityInfo, 'to_proto') else TrendLineToolEntityInfo))
        ret = self.__RosetteServicesStubLocal.UpdateRosetteTrendLineTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

    def DeleteStereonet2DTrendLineTool(self):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TrendLineToolEntityInfo(This=self.__modelRef)
        ret = self.__Stereonet2DServicesStubLocal.DeleteStereonet2DTrendLineTool(functionParam)
        

    def SetStereonet2DTrendLineToolVisibility(self,  Boolean: bool):
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TrendLineToolEntityInfo_Boolean(This=self.__modelRef,  Input1=Boolean)
        ret = self.__Stereonet2DServicesStubLocal.SetStereonet2DTrendLineToolVisibility(functionParam)
        

    def UpdateStereonet2DTrendLineTool(self,  TrendLineToolEntityInfo: TrendLineToolEntityInfoVal) -> ValidatableResultVal:
        functionParam = DipsAPI_pb2.ProtoMemberFunction_ProtoReference_TrendLineToolEntityInfo_TrendLineToolEntityInfo(This=self.__modelRef,  Input1=(TrendLineToolEntityInfo.to_proto() if hasattr(TrendLineToolEntityInfo, 'to_proto') else TrendLineToolEntityInfo))
        ret = self.__Stereonet2DServicesStubLocal.UpdateStereonet2DTrendLineTool(functionParam)
        
        return ValidatableResultVal.from_proto(ret)
        

 