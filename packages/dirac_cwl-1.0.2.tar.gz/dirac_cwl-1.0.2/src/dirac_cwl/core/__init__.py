"""Dirac-cwl core package."""
