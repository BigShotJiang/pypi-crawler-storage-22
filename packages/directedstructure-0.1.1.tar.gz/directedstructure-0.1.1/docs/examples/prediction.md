```{toctree}# Example: Prediction

```{literalinclude} ../../examples/prediction.py
:language: python
:linenos:
```