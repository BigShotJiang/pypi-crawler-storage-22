```{toctree}# Example: Speed test

```{literalinclude} ../../examples/speed.py
:language: python
:linenos:
```