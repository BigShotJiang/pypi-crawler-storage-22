```{toctree}# Example: Visualization

```{literalinclude} ../../examples/visualization.py
:language: python
:linenos:
```