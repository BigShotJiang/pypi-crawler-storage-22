# directedstructure

```{toctree}
:maxdepth: 2
:hidden:
:caption: Contents:
:glob:

modules.md
examples/prediction.md
examples/speed_test.md
examples/visualization.md
```


```{include} ../README.md
:start-after: <!-- SPHINX-START -->
```