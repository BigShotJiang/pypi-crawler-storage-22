# Module Documentation

```{eval-rst}
.. automodule:: directedstructure
   :members:
   :undoc-members:
   :show-inheritance:
```