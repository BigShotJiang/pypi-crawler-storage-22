graph [
  directed 1
  node [
    id 0
    label "1"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 1
    label "52"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 2
    label "3"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 3
    label "6"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 4
    label "29"
    community 2
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 5
    label "34"
    community 2
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 6
    label "40"
    community 1
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 7
    label "19"
    community 1
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 8
    label "26"
    community 1
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 9
    label "47"
    community 1
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 10
    label "8"
    community 3
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 11
    label "5"
    community 0
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 12
    label "14"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 13
    label "18"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 14
    label "23"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 15
    label "35"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 16
    label "38"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 17
    label "60"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 18
    label "9"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 19
    label "36"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 20
    label "37"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 21
    label "49"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 22
    label "50"
    community 3
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 23
    label "67"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 24
    label "12"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 25
    label "54"
    community 2
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 26
    label "30"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 27
    label "43"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 28
    label "25"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 29
    label "48"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 30
    label "58"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 31
    label "61"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 32
    label "28"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 33
    label "32"
    community 0
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 34
    label "41"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 35
    label "39"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 36
    label "53"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 37
    label "66"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 38
    label "68"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 39
    label "55"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 40
    label "44"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 41
    label "63"
    community 0
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 42
    label "71"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  edge [
    source 0
    target 1
    type "neutral"
  ]
  edge [
    source 0
    target 19
    type "dominant"
  ]
  edge [
    source 0
    target 20
    type "dominant"
  ]
  edge [
    source 1
    target 42
    type "neutral"
  ]
  edge [
    source 1
    target 37
    type "dominant"
  ]
  edge [
    source 2
    target 3
    type "neutral"
  ]
  edge [
    source 2
    target 6
    type "neutral"
  ]
  edge [
    source 3
    target 6
    type "neutral"
  ]
  edge [
    source 4
    target 2
    type "dominant"
  ]
  edge [
    source 4
    target 5
    type "neutral"
  ]
  edge [
    source 4
    target 25
    type "neutral"
  ]
  edge [
    source 4
    target 30
    type "neutral"
  ]
  edge [
    source 4
    target 31
    type "neutral"
  ]
  edge [
    source 4
    target 8
    type "dominant"
  ]
  edge [
    source 5
    target 2
    type "dominant"
  ]
  edge [
    source 5
    target 28
    type "neutral"
  ]
  edge [
    source 5
    target 27
    type "neutral"
  ]
  edge [
    source 5
    target 36
    type "neutral"
  ]
  edge [
    source 5
    target 25
    type "neutral"
  ]
  edge [
    source 5
    target 31
    type "neutral"
  ]
  edge [
    source 5
    target 37
    type "neutral"
  ]
  edge [
    source 5
    target 8
    type "dominant"
  ]
  edge [
    source 5
    target 30
    type "dominant"
  ]
  edge [
    source 5
    target 33
    type "dominant"
  ]
  edge [
    source 7
    target 3
    type "dominant"
  ]
  edge [
    source 7
    target 6
    type "dominant"
  ]
  edge [
    source 7
    target 8
    type "neutral"
  ]
  edge [
    source 7
    target 9
    type "neutral"
  ]
  edge [
    source 8
    target 3
    type "dominant"
  ]
  edge [
    source 8
    target 9
    type "neutral"
  ]
  edge [
    source 9
    target 3
    type "dominant"
  ]
  edge [
    source 9
    target 6
    type "dominant"
  ]
  edge [
    source 10
    target 13
    type "neutral"
  ]
  edge [
    source 10
    target 14
    type "neutral"
  ]
  edge [
    source 10
    target 15
    type "neutral"
  ]
  edge [
    source 10
    target 18
    type "dominant"
  ]
  edge [
    source 10
    target 27
    type "dominant"
  ]
  edge [
    source 10
    target 40
    type "dominant"
  ]
  edge [
    source 11
    target 10
    type "dominant"
  ]
  edge [
    source 11
    target 12
    type "dominant"
  ]
  edge [
    source 11
    target 16
    type "dominant"
  ]
  edge [
    source 11
    target 40
    type "dominant"
  ]
  edge [
    source 12
    target 10
    type "dominant"
  ]
  edge [
    source 12
    target 26
    type "neutral"
  ]
  edge [
    source 12
    target 16
    type "neutral"
  ]
  edge [
    source 12
    target 13
    type "dominant"
  ]
  edge [
    source 12
    target 40
    type "dominant"
  ]
  edge [
    source 13
    target 16
    type "neutral"
  ]
  edge [
    source 13
    target 40
    type "dominant"
  ]
  edge [
    source 14
    target 18
    type "neutral"
  ]
  edge [
    source 14
    target 15
    type "neutral"
  ]
  edge [
    source 14
    target 17
    type "dominant"
  ]
  edge [
    source 14
    target 21
    type "dominant"
  ]
  edge [
    source 14
    target 32
    type "dominant"
  ]
  edge [
    source 15
    target 1
    type "dominant"
  ]
  edge [
    source 15
    target 6
    type "dominant"
  ]
  edge [
    source 15
    target 16
    type "neutral"
  ]
  edge [
    source 15
    target 17
    type "neutral"
  ]
  edge [
    source 15
    target 38
    type "neutral"
  ]
  edge [
    source 16
    target 10
    type "dominant"
  ]
  edge [
    source 16
    target 38
    type "neutral"
  ]
  edge [
    source 16
    target 27
    type "dominant"
  ]
  edge [
    source 17
    target 8
    type "dominant"
  ]
  edge [
    source 17
    target 10
    type "dominant"
  ]
  edge [
    source 17
    target 13
    type "dominant"
  ]
  edge [
    source 17
    target 16
    type "dominant"
  ]
  edge [
    source 17
    target 20
    type "neutral"
  ]
  edge [
    source 17
    target 32
    type "dominant"
  ]
  edge [
    source 17
    target 33
    type "dominant"
  ]
  edge [
    source 18
    target 17
    type "dominant"
  ]
  edge [
    source 18
    target 19
    type "neutral"
  ]
  edge [
    source 18
    target 20
    type "neutral"
  ]
  edge [
    source 18
    target 21
    type "neutral"
  ]
  edge [
    source 18
    target 22
    type "neutral"
  ]
  edge [
    source 19
    target 13
    type "dominant"
  ]
  edge [
    source 19
    target 14
    type "dominant"
  ]
  edge [
    source 19
    target 17
    type "dominant"
  ]
  edge [
    source 19
    target 20
    type "neutral"
  ]
  edge [
    source 19
    target 21
    type "neutral"
  ]
  edge [
    source 19
    target 22
    type "neutral"
  ]
  edge [
    source 19
    target 23
    type "neutral"
  ]
  edge [
    source 20
    target 14
    type "dominant"
  ]
  edge [
    source 21
    target 23
    type "neutral"
  ]
  edge [
    source 22
    target 15
    type "dominant"
  ]
  edge [
    source 22
    target 21
    type "dominant"
  ]
  edge [
    source 22
    target 26
    type "neutral"
  ]
  edge [
    source 23
    target 14
    type "dominant"
  ]
  edge [
    source 23
    target 18
    type "dominant"
  ]
  edge [
    source 24
    target 25
    type "neutral"
  ]
  edge [
    source 25
    target 8
    type "dominant"
  ]
  edge [
    source 25
    target 26
    type "dominant"
  ]
  edge [
    source 25
    target 27
    type "dominant"
  ]
  edge [
    source 25
    target 28
    type "dominant"
  ]
  edge [
    source 25
    target 31
    type "dominant"
  ]
  edge [
    source 25
    target 36
    type "dominant"
  ]
  edge [
    source 26
    target 13
    type "dominant"
  ]
  edge [
    source 26
    target 35
    type "neutral"
  ]
  edge [
    source 26
    target 27
    type "dominant"
  ]
  edge [
    source 26
    target 40
    type "dominant"
  ]
  edge [
    source 27
    target 12
    type "dominant"
  ]
  edge [
    source 27
    target 33
    type "neutral"
  ]
  edge [
    source 27
    target 39
    type "dominant"
  ]
  edge [
    source 27
    target 40
    type "dominant"
  ]
  edge [
    source 28
    target 29
    type "neutral"
  ]
  edge [
    source 28
    target 30
    type "neutral"
  ]
  edge [
    source 28
    target 31
    type "neutral"
  ]
  edge [
    source 28
    target 37
    type "dominant"
  ]
  edge [
    source 29
    target 4
    type "dominant"
  ]
  edge [
    source 29
    target 5
    type "dominant"
  ]
  edge [
    source 29
    target 30
    type "neutral"
  ]
  edge [
    source 29
    target 31
    type "neutral"
  ]
  edge [
    source 29
    target 37
    type "neutral"
  ]
  edge [
    source 30
    target 31
    type "neutral"
  ]
  edge [
    source 31
    target 37
    type "neutral"
  ]
  edge [
    source 31
    target 36
    type "dominant"
  ]
  edge [
    source 32
    target 33
    type "neutral"
  ]
  edge [
    source 34
    target 4
    type "dominant"
  ]
  edge [
    source 34
    target 6
    type "dominant"
  ]
  edge [
    source 34
    target 36
    type "neutral"
  ]
  edge [
    source 35
    target 39
    type "neutral"
  ]
  edge [
    source 37
    target 6
    type "dominant"
  ]
  edge [
    source 37
    target 30
    type "dominant"
  ]
  edge [
    source 37
    target 42
    type "dominant"
  ]
  edge [
    source 38
    target 1
    type "dominant"
  ]
  edge [
    source 38
    target 37
    type "dominant"
  ]
  edge [
    source 41
    target 1
    type "dominant"
  ]
  edge [
    source 41
    target 38
    type "dominant"
  ]
  edge [
    source 42
    target 38
    type "dominant"
  ]
]
