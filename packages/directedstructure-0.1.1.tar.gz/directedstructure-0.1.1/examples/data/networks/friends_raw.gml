graph [
  directed 1
  node [
    id 0
    label "1"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 1
    label "52"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 2
    label "3"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 3
    label "6"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 4
    label "29"
    community 2
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 5
    label "34"
    community 2
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 6
    label "40"
    community 1
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 7
    label "19"
    community 1
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 8
    label "26"
    community 1
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 9
    label "47"
    community 1
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 10
    label "8"
    community 3
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 11
    label "5"
    community 0
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 12
    label "14"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 13
    label "18"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 14
    label "23"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 15
    label "35"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 16
    label "38"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 17
    label "60"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 18
    label "9"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 19
    label "36"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 20
    label "37"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 21
    label "49"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 22
    label "50"
    community 3
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 23
    label "67"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 24
    label "12"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 25
    label "54"
    community 2
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 26
    label "30"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 27
    label "43"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 28
    label "25"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 29
    label "48"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 30
    label "58"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 31
    label "61"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 32
    label "28"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 33
    label "32"
    community 0
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 34
    label "41"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 35
    label "39"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 36
    label "53"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 37
    label "66"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 38
    label "68"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 39
    label "55"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 40
    label "44"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 41
    label "63"
    community 0
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 42
    label "71"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  edge [
    source 0
    target 1
  ]
  edge [
    source 1
    target 0
  ]
  edge [
    source 1
    target 15
  ]
  edge [
    source 1
    target 41
  ]
  edge [
    source 1
    target 38
  ]
  edge [
    source 1
    target 42
  ]
  edge [
    source 2
    target 3
  ]
  edge [
    source 2
    target 4
  ]
  edge [
    source 2
    target 5
  ]
  edge [
    source 2
    target 6
  ]
  edge [
    source 3
    target 2
  ]
  edge [
    source 3
    target 7
  ]
  edge [
    source 3
    target 8
  ]
  edge [
    source 3
    target 6
  ]
  edge [
    source 3
    target 9
  ]
  edge [
    source 4
    target 5
  ]
  edge [
    source 4
    target 34
  ]
  edge [
    source 4
    target 29
  ]
  edge [
    source 4
    target 25
  ]
  edge [
    source 4
    target 30
  ]
  edge [
    source 4
    target 31
  ]
  edge [
    source 5
    target 28
  ]
  edge [
    source 5
    target 4
  ]
  edge [
    source 5
    target 27
  ]
  edge [
    source 5
    target 29
  ]
  edge [
    source 5
    target 36
  ]
  edge [
    source 5
    target 25
  ]
  edge [
    source 5
    target 31
  ]
  edge [
    source 5
    target 37
  ]
  edge [
    source 6
    target 2
  ]
  edge [
    source 6
    target 3
  ]
  edge [
    source 6
    target 7
  ]
  edge [
    source 6
    target 15
  ]
  edge [
    source 6
    target 34
  ]
  edge [
    source 6
    target 9
  ]
  edge [
    source 6
    target 37
  ]
  edge [
    source 7
    target 8
  ]
  edge [
    source 7
    target 9
  ]
  edge [
    source 8
    target 7
  ]
  edge [
    source 8
    target 4
  ]
  edge [
    source 8
    target 5
  ]
  edge [
    source 8
    target 9
  ]
  edge [
    source 8
    target 25
  ]
  edge [
    source 8
    target 17
  ]
  edge [
    source 9
    target 7
  ]
  edge [
    source 9
    target 8
  ]
  edge [
    source 10
    target 11
  ]
  edge [
    source 10
    target 12
  ]
  edge [
    source 10
    target 13
  ]
  edge [
    source 10
    target 14
  ]
  edge [
    source 10
    target 15
  ]
  edge [
    source 10
    target 16
  ]
  edge [
    source 10
    target 17
  ]
  edge [
    source 12
    target 11
  ]
  edge [
    source 12
    target 26
  ]
  edge [
    source 12
    target 16
  ]
  edge [
    source 12
    target 27
  ]
  edge [
    source 13
    target 10
  ]
  edge [
    source 13
    target 12
  ]
  edge [
    source 13
    target 26
  ]
  edge [
    source 13
    target 19
  ]
  edge [
    source 13
    target 16
  ]
  edge [
    source 13
    target 17
  ]
  edge [
    source 14
    target 10
  ]
  edge [
    source 14
    target 18
  ]
  edge [
    source 14
    target 15
  ]
  edge [
    source 14
    target 19
  ]
  edge [
    source 14
    target 20
  ]
  edge [
    source 14
    target 23
  ]
  edge [
    source 15
    target 10
  ]
  edge [
    source 15
    target 14
  ]
  edge [
    source 15
    target 16
  ]
  edge [
    source 15
    target 22
  ]
  edge [
    source 15
    target 17
  ]
  edge [
    source 15
    target 38
  ]
  edge [
    source 16
    target 12
  ]
  edge [
    source 16
    target 13
  ]
  edge [
    source 16
    target 15
  ]
  edge [
    source 16
    target 11
  ]
  edge [
    source 16
    target 17
  ]
  edge [
    source 16
    target 38
  ]
  edge [
    source 17
    target 15
  ]
  edge [
    source 17
    target 20
  ]
  edge [
    source 17
    target 18
  ]
  edge [
    source 17
    target 14
  ]
  edge [
    source 17
    target 19
  ]
  edge [
    source 18
    target 10
  ]
  edge [
    source 18
    target 14
  ]
  edge [
    source 18
    target 19
  ]
  edge [
    source 18
    target 20
  ]
  edge [
    source 18
    target 21
  ]
  edge [
    source 18
    target 22
  ]
  edge [
    source 18
    target 23
  ]
  edge [
    source 19
    target 18
  ]
  edge [
    source 19
    target 0
  ]
  edge [
    source 19
    target 20
  ]
  edge [
    source 19
    target 21
  ]
  edge [
    source 19
    target 22
  ]
  edge [
    source 19
    target 23
  ]
  edge [
    source 20
    target 18
  ]
  edge [
    source 20
    target 19
  ]
  edge [
    source 20
    target 0
  ]
  edge [
    source 20
    target 17
  ]
  edge [
    source 21
    target 18
  ]
  edge [
    source 21
    target 19
  ]
  edge [
    source 21
    target 14
  ]
  edge [
    source 21
    target 22
  ]
  edge [
    source 21
    target 23
  ]
  edge [
    source 22
    target 18
  ]
  edge [
    source 22
    target 26
  ]
  edge [
    source 22
    target 19
  ]
  edge [
    source 23
    target 19
  ]
  edge [
    source 23
    target 21
  ]
  edge [
    source 24
    target 25
  ]
  edge [
    source 25
    target 24
  ]
  edge [
    source 25
    target 4
  ]
  edge [
    source 25
    target 5
  ]
  edge [
    source 26
    target 12
  ]
  edge [
    source 26
    target 35
  ]
  edge [
    source 26
    target 22
  ]
  edge [
    source 26
    target 25
  ]
  edge [
    source 27
    target 33
  ]
  edge [
    source 27
    target 5
  ]
  edge [
    source 27
    target 10
  ]
  edge [
    source 27
    target 26
  ]
  edge [
    source 27
    target 16
  ]
  edge [
    source 27
    target 25
  ]
  edge [
    source 28
    target 5
  ]
  edge [
    source 28
    target 29
  ]
  edge [
    source 28
    target 25
  ]
  edge [
    source 28
    target 30
  ]
  edge [
    source 28
    target 31
  ]
  edge [
    source 29
    target 28
  ]
  edge [
    source 29
    target 30
  ]
  edge [
    source 29
    target 31
  ]
  edge [
    source 29
    target 37
  ]
  edge [
    source 30
    target 28
  ]
  edge [
    source 30
    target 4
  ]
  edge [
    source 30
    target 29
  ]
  edge [
    source 30
    target 5
  ]
  edge [
    source 30
    target 31
  ]
  edge [
    source 30
    target 37
  ]
  edge [
    source 31
    target 28
  ]
  edge [
    source 31
    target 4
  ]
  edge [
    source 31
    target 5
  ]
  edge [
    source 31
    target 29
  ]
  edge [
    source 31
    target 30
  ]
  edge [
    source 31
    target 25
  ]
  edge [
    source 31
    target 37
  ]
  edge [
    source 32
    target 14
  ]
  edge [
    source 32
    target 33
  ]
  edge [
    source 32
    target 17
  ]
  edge [
    source 33
    target 32
  ]
  edge [
    source 33
    target 5
  ]
  edge [
    source 33
    target 27
  ]
  edge [
    source 33
    target 17
  ]
  edge [
    source 34
    target 36
  ]
  edge [
    source 35
    target 26
  ]
  edge [
    source 35
    target 39
  ]
  edge [
    source 36
    target 5
  ]
  edge [
    source 36
    target 34
  ]
  edge [
    source 36
    target 25
  ]
  edge [
    source 36
    target 31
  ]
  edge [
    source 37
    target 5
  ]
  edge [
    source 37
    target 29
  ]
  edge [
    source 37
    target 31
  ]
  edge [
    source 37
    target 28
  ]
  edge [
    source 37
    target 1
  ]
  edge [
    source 37
    target 38
  ]
  edge [
    source 38
    target 15
  ]
  edge [
    source 38
    target 16
  ]
  edge [
    source 38
    target 41
  ]
  edge [
    source 38
    target 42
  ]
  edge [
    source 39
    target 35
  ]
  edge [
    source 39
    target 27
  ]
  edge [
    source 40
    target 11
  ]
  edge [
    source 40
    target 10
  ]
  edge [
    source 40
    target 12
  ]
  edge [
    source 40
    target 13
  ]
  edge [
    source 40
    target 26
  ]
  edge [
    source 40
    target 27
  ]
  edge [
    source 42
    target 1
  ]
  edge [
    source 42
    target 37
  ]
]