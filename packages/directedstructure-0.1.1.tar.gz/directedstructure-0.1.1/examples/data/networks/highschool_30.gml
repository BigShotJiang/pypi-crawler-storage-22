graph [
  directed 1
  node [
    id 0
    label "1"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 1
    label "44"
    community 1
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 2
    label "499"
    community 1
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 3
    label "583"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 4
    label "589"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 5
    label "2"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 6
    label "48"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 7
    label "59"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 8
    label "171"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 9
    label "210"
    community 4
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 10
    label "420"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 11
    label "571"
    community 5
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 12
    label "681"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 13
    label "4"
    community 5
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 14
    label "43"
    community 5
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 15
    label "213"
    community 6
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 16
    label "284"
    community 6
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 17
    label "527"
    community 5
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 18
    label "634"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 19
    label "742"
    community 5
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 20
    label "6"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 21
    label "83"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 22
    label "345"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 23
    label "438"
    community 8
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 24
    label "478"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 25
    label "629"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 26
    label "639"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 27
    label "8"
    community 9
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 28
    label "11"
    community 9
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 29
    label "66"
    community 9
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 30
    label "104"
    community 9
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 31
    label "189"
    community 9
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 32
    label "262"
    community 9
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 33
    label "349"
    community 9
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 34
    label "568"
    community 10
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 35
    label "597"
    community 9
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 36
    label "611"
    community 9
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 37
    label "9"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 38
    label "127"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 39
    label "134"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 40
    label "207"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 41
    label "329"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 42
    label "424"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 43
    label "494"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 44
    label "311"
    community 11
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 45
    label "620"
    community 12
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 46
    label "628"
    community 9
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 47
    label "683"
    community 12
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 48
    label "12"
    community 11
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 49
    label "303"
    community 11
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 50
    label "359"
    community 11
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 51
    label "664"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 52
    label "16"
    community 13
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 53
    label "93"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 54
    label "541"
    community 13
    race "missing"
    sex "female"
    grade 9
  ]
  node [
    id 55
    label "17"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 56
    label "35"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 57
    label "63"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 58
    label "130"
    community 14
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 59
    label "358"
    community 1
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 60
    label "715"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 61
    label "18"
    community 11
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 62
    label "220"
    community 11
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 63
    label "565"
    community 11
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 64
    label "20"
    community 7
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 65
    label "200"
    community 7
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 66
    label "259"
    community 13
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 67
    label "260"
    community 13
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 68
    label "351"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 69
    label "684"
    community 7
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 70
    label "22"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 71
    label "42"
    community 3
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 72
    label "578"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 73
    label "708"
    community 14
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 74
    label "23"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 75
    label "54"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 76
    label "174"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 77
    label "270"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 78
    label "306"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 79
    label "373"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 80
    label "556"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 81
    label "563"
    community 15
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 82
    label "26"
    community 6
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 83
    label "140"
    community 6
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 84
    label "228"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 85
    label "281"
    community 5
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 86
    label "316"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 87
    label "344"
    community 6
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 88
    label "369"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 89
    label "615"
    community 6
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 90
    label "30"
    community 9
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 91
    label "176"
    community 9
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 92
    label "226"
    community 9
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 93
    label "298"
    community 9
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 94
    label "31"
    community 11
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 95
    label "175"
    community 5
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 96
    label "548"
    community 9
    race "missing"
    sex "female"
    grade 11
  ]
  node [
    id 97
    label "729"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 98
    label "33"
    community 9
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 99
    label "372"
    community 2
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 100
    label "454"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 101
    label "34"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 102
    label "128"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 103
    label "188"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 104
    label "194"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 105
    label "205"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 106
    label "276"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 107
    label "408"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 108
    label "434"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 109
    label "497"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 110
    label "621"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 111
    label "656"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 112
    label "705"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 113
    label "36"
    community 11
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 114
    label "452"
    community 11
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 115
    label "665"
    community 11
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 116
    label "37"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 117
    label "269"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 118
    label "365"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 119
    label "400"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 120
    label "448"
    community 6
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 121
    label "522"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 122
    label "623"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 123
    label "38"
    community 14
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 124
    label "29"
    community 16
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 125
    label "172"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 126
    label "258"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 127
    label "490"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 128
    label "680"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 129
    label "743"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 130
    label "371"
    community 15
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 131
    label "521"
    community 5
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 132
    label "62"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 133
    label "468"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 134
    label "543"
    community 1
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 135
    label "45"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 136
    label "46"
    community 1
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 137
    label "208"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 138
    label "261"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 139
    label "699"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 140
    label "47"
    community 4
    race "mixed"
    sex "male"
    grade 12
  ]
  node [
    id 141
    label "592"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 142
    label "73"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 143
    label "109"
    community 11
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 144
    label "113"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 145
    label "241"
    community 13
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 146
    label "50"
    community 16
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 147
    label "106"
    community 16
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 148
    label "52"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 149
    label "638"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 150
    label "709"
    community 9
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 151
    label "53"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 152
    label "198"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 153
    label "209"
    community 5
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 154
    label "476"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 155
    label "492"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 156
    label "585"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 157
    label "479"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 158
    label "544"
    community 15
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 159
    label "56"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 160
    label "227"
    community 6
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 161
    label "247"
    community 1
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 162
    label "411"
    community 6
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 163
    label "599"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 164
    label "689"
    community 6
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 165
    label "58"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 166
    label "160"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 167
    label "251"
    community 4
    race "white"
    sex "missing"
    grade 12
  ]
  node [
    id 168
    label "413"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 169
    label "350"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 170
    label "65"
    community 8
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 171
    label "124"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 172
    label "186"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 173
    label "475"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 174
    label "192"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 175
    label "68"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 176
    label "70"
    community 3
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 177
    label "74"
    community 14
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 178
    label "77"
    community 14
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 179
    label "193"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 180
    label "366"
    community 14
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 181
    label "464"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 182
    label "558"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 183
    label "598"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 184
    label "91"
    community 14
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 185
    label "157"
    community 14
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 186
    label "606"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 187
    label "740"
    community 14
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 188
    label "75"
    community 12
    race "mixed"
    sex "male"
    grade 12
  ]
  node [
    id 189
    label "197"
    community 12
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 190
    label "415"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 191
    label "523"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 192
    label "76"
    community 11
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 193
    label "89"
    community 11
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 194
    label "280"
    community 6
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 195
    label "466"
    community 10
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 196
    label "584"
    community 11
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 197
    label "640"
    community 11
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 198
    label "133"
    community 14
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 199
    label "79"
    community 1
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 200
    label "181"
    community 6
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 201
    label "486"
    community 4
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 202
    label "609"
    community 14
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 203
    label "730"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 204
    label "80"
    community 8
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 205
    label "110"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 206
    label "184"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 207
    label "340"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 208
    label "745"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 209
    label "165"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 210
    label "201"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 211
    label "679"
    community 15
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 212
    label "87"
    community 12
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 213
    label "346"
    community 12
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 214
    label "381"
    community 12
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 215
    label "530"
    community 12
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 216
    label "131"
    community 10
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 217
    label "265"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 218
    label "461"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 219
    label "707"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 220
    label "92"
    community 5
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 221
    label "397"
    community 16
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 222
    label "594"
    community 5
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 223
    label "719"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 224
    label "377"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 225
    label "96"
    community 6
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 226
    label "216"
    community 12
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 227
    label "234"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 228
    label "339"
    community 6
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 229
    label "614"
    community 6
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 230
    label "617"
    community 6
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 231
    label "101"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 232
    label "643"
    community 12
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 233
    label "105"
    community 10
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 234
    label "111"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 235
    label "437"
    community 10
    race "mixed"
    sex "missing"
    grade 9
  ]
  node [
    id 236
    label "107"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 237
    label "246"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 238
    label "323"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 239
    label "570"
    community 5
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 240
    label "660"
    community 11
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 241
    label "610"
    community 15
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 242
    label "720"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 243
    label "154"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 244
    label "244"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 245
    label "253"
    community 15
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 246
    label "290"
    community 13
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 247
    label "562"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 248
    label "711"
    community 13
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 249
    label "112"
    community 0
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 250
    label "248"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 251
    label "441"
    community 15
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 252
    label "572"
    community 0
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 253
    label "590"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 254
    label "114"
    community 15
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 255
    label "203"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 256
    label "318"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 257
    label "115"
    community 2
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 258
    label "212"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 259
    label "384"
    community 2
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 260
    label "577"
    community 2
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 261
    label "704"
    community 12
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 262
    label "116"
    community 10
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 263
    label "282"
    community 10
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 264
    label "462"
    community 10
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 265
    label "118"
    community 13
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 266
    label "498"
    community 13
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 267
    label "645"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 268
    label "120"
    community 16
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 269
    label "447"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 270
    label "122"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 271
    label "123"
    community 1
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 272
    label "161"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 273
    label "177"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 274
    label "126"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 275
    label "726"
    community 7
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 276
    label "242"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 277
    label "618"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 278
    label "608"
    community 10
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 279
    label "633"
    community 10
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 280
    label "636"
    community 10
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 281
    label "668"
    community 10
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 282
    label "132"
    community 11
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 283
    label "375"
    community 11
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 284
    label "533"
    community 11
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 285
    label "676"
    community 11
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 286
    label "551"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 287
    label "137"
    community 5
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 288
    label "138"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 289
    label "691"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 290
    label "139"
    community 12
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 291
    label "202"
    community 12
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 292
    label "695"
    community 12
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 293
    label "237"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 294
    label "142"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 295
    label "144"
    community 10
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 296
    label "143"
    community 5
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 297
    label "219"
    community 5
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 298
    label "378"
    community 11
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 299
    label "501"
    community 5
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 300
    label "648"
    community 10
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 301
    label "670"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 302
    label "146"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 303
    label "148"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 304
    label "453"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 305
    label "150"
    community 7
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 306
    label "297"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 307
    label "151"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 308
    label "231"
    community 13
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 309
    label "254"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 310
    label "376"
    community 13
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 311
    label "152"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 312
    label "332"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 313
    label "353"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 314
    label "509"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 315
    label "605"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 316
    label "230"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 317
    label "310"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 318
    label "567"
    community 13
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 319
    label "440"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 320
    label "717"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 321
    label "302"
    community 1
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 322
    label "163"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 323
    label "538"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 324
    label "166"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 325
    label "279"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 326
    label "529"
    community 11
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 327
    label "169"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 328
    label "285"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 329
    label "619"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 330
    label "728"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 331
    label "423"
    community 2
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 332
    label "263"
    community 11
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 333
    label "380"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 334
    label "487"
    community 11
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 335
    label "698"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 336
    label "463"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 337
    label "511"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 338
    label "195"
    community 16
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 339
    label "199"
    community 11
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 340
    label "616"
    community 13
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 341
    label "655"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 342
    label "731"
    community 12
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 343
    label "206"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 344
    label "341"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 345
    label "396"
    community 10
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 346
    label "516"
    community 5
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 347
    label "658"
    community 5
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 348
    label "211"
    community 16
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 349
    label "236"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 350
    label "465"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 351
    label "666"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 352
    label "682"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 353
    label "283"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 354
    label "641"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 355
    label "457"
    community 12
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 356
    label "218"
    community 11
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 357
    label "223"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 358
    label "512"
    community 16
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 359
    label "554"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 360
    label "229"
    community 10
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 361
    label "245"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 362
    label "330"
    community 13
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 363
    label "267"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 364
    label "235"
    community 16
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 365
    label "225"
    community 16
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 366
    label "733"
    community 16
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 367
    label "735"
    community 16
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 368
    label "539"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 369
    label "362"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 370
    label "28"
    community 13
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 371
    label "313"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 372
    label "552"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 373
    label "696"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 374
    label "718"
    community 13
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 375
    label "514"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 376
    label "249"
    community 0
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 377
    label "250"
    community 10
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 378
    label "252"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 379
    label "535"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 380
    label "674"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 381
    label "625"
    community 8
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 382
    label "642"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 383
    label "662"
    community 9
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 384
    label "706"
    community 9
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 385
    label "496"
    community 11
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 386
    label "702"
    community 7
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 387
    label "734"
    community 7
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 388
    label "286"
    community 16
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 389
    label "564"
    community 16
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 390
    label "287"
    community 11
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 391
    label "301"
    community 12
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 392
    label "305"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 393
    label "309"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 394
    label "459"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 395
    label "561"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 396
    label "471"
    community 14
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 397
    label "319"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 398
    label "326"
    community 11
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 399
    label "421"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 400
    label "474"
    community 8
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 401
    label "505"
    community 16
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 402
    label "386"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 403
    label "352"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 404
    label "410"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 405
    label "356"
    community 4
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 406
    label "363"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 407
    label "510"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 408
    label "379"
    community 5
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 409
    label "403"
    community 13
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 410
    label "519"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 411
    label "392"
    community 16
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 412
    label "147"
    community 16
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 413
    label "274"
    community 16
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 414
    label "398"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 415
    label "240"
    community 4
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 416
    label "414"
    community 12
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 417
    label "417"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 418
    label "630"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 419
    label "714"
    community 15
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 420
    label "86"
    community 2
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 421
    label "347"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 422
    label "426"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 423
    label "485"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 424
    label "439"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 425
    label "456"
    community 11
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 426
    label "507"
    community 10
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 427
    label "534"
    community 16
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 428
    label "722"
    community 16
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 429
    label "686"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 430
    label "649"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 431
    label "407"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 432
    label "671"
    community 13
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 433
    label "502"
    community 6
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 434
    label "503"
    community 11
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 435
    label "435"
    community 11
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 436
    label "98"
    community 10
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 437
    label "531"
    community 16
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 438
    label "528"
    community 16
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 439
    label "712"
    community 16
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 440
    label "550"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 441
    label "724"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 442
    label "540"
    community 7
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 443
    label "576"
    community 7
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 444
    label "654"
    community 15
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 445
    label "555"
    community 16
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 446
    label "348"
    community 16
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 447
    label "627"
    community 13
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 448
    label "185"
    community 13
    race "mixed"
    sex "male"
    grade 12
  ]
  node [
    id 449
    label "72"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 450
    label "692"
    community 13
    race "white"
    sex "missing"
    grade 10
  ]
  node [
    id 451
    label "667"
    community 9
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 452
    label "631"
    community 6
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 453
    label "657"
    community 9
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 454
    label "697"
    community 16
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 455
    label "646"
    community 16
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 456
    label "727"
    community 16
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 457
    label "737"
    community 4
    race "white"
    sex "male"
    grade 12
  ]
  edge [
    source 0
    target 1
    type "neutral"
  ]
  edge [
    source 0
    target 3
    type "neutral"
  ]
  edge [
    source 0
    target 4
    type "neutral"
  ]
  edge [
    source 1
    target 132
    type "neutral"
  ]
  edge [
    source 1
    target 134
    type "neutral"
  ]
  edge [
    source 1
    target 3
    type "neutral"
  ]
  edge [
    source 1
    target 169
    type "dominant"
  ]
  edge [
    source 2
    target 0
    type "dominant"
  ]
  edge [
    source 2
    target 1
    type "dominant"
  ]
  edge [
    source 3
    target 234
    type "neutral"
  ]
  edge [
    source 3
    target 249
    type "neutral"
  ]
  edge [
    source 3
    target 250
    type "neutral"
  ]
  edge [
    source 3
    target 375
    type "neutral"
  ]
  edge [
    source 3
    target 133
    type "dominant"
  ]
  edge [
    source 3
    target 145
    type "dominant"
  ]
  edge [
    source 3
    target 148
    type "dominant"
  ]
  edge [
    source 3
    target 330
    type "dominant"
  ]
  edge [
    source 3
    target 376
    type "dominant"
  ]
  edge [
    source 4
    target 361
    type "neutral"
  ]
  edge [
    source 4
    target 325
    type "neutral"
  ]
  edge [
    source 4
    target 374
    type "dominant"
  ]
  edge [
    source 6
    target 5
    type "dominant"
  ]
  edge [
    source 7
    target 5
    type "dominant"
  ]
  edge [
    source 7
    target 12
    type "dominant"
  ]
  edge [
    source 7
    target 286
    type "dominant"
  ]
  edge [
    source 7
    target 372
    type "dominant"
  ]
  edge [
    source 7
    target 400
    type "dominant"
  ]
  edge [
    source 8
    target 5
    type "dominant"
  ]
  edge [
    source 8
    target 38
    type "neutral"
  ]
  edge [
    source 8
    target 138
    type "neutral"
  ]
  edge [
    source 8
    target 183
    type "neutral"
  ]
  edge [
    source 8
    target 187
    type "neutral"
  ]
  edge [
    source 8
    target 59
    type "dominant"
  ]
  edge [
    source 8
    target 199
    type "dominant"
  ]
  edge [
    source 8
    target 202
    type "dominant"
  ]
  edge [
    source 8
    target 393
    type "dominant"
  ]
  edge [
    source 9
    target 5
    type "dominant"
  ]
  edge [
    source 9
    target 6
    type "dominant"
  ]
  edge [
    source 9
    target 140
    type "neutral"
  ]
  edge [
    source 9
    target 107
    type "neutral"
  ]
  edge [
    source 9
    target 108
    type "neutral"
  ]
  edge [
    source 9
    target 337
    type "neutral"
  ]
  edge [
    source 9
    target 57
    type "dominant"
  ]
  edge [
    source 9
    target 97
    type "dominant"
  ]
  edge [
    source 9
    target 135
    type "dominant"
  ]
  edge [
    source 9
    target 136
    type "dominant"
  ]
  edge [
    source 9
    target 188
    type "dominant"
  ]
  edge [
    source 9
    target 305
    type "dominant"
  ]
  edge [
    source 9
    target 391
    type "dominant"
  ]
  edge [
    source 9
    target 414
    type "dominant"
  ]
  edge [
    source 9
    target 429
    type "dominant"
  ]
  edge [
    source 10
    target 5
    type "dominant"
  ]
  edge [
    source 10
    target 288
    type "neutral"
  ]
  edge [
    source 10
    target 260
    type "neutral"
  ]
  edge [
    source 10
    target 12
    type "neutral"
  ]
  edge [
    source 10
    target 29
    type "dominant"
  ]
  edge [
    source 11
    target 5
    type "dominant"
  ]
  edge [
    source 11
    target 363
    type "neutral"
  ]
  edge [
    source 11
    target 201
    type "neutral"
  ]
  edge [
    source 11
    target 17
    type "neutral"
  ]
  edge [
    source 11
    target 239
    type "neutral"
  ]
  edge [
    source 11
    target 203
    type "neutral"
  ]
  edge [
    source 11
    target 13
    type "dominant"
  ]
  edge [
    source 11
    target 212
    type "dominant"
  ]
  edge [
    source 11
    target 261
    type "dominant"
  ]
  edge [
    source 11
    target 268
    type "dominant"
  ]
  edge [
    source 11
    target 272
    type "dominant"
  ]
  edge [
    source 11
    target 296
    type "dominant"
  ]
  edge [
    source 11
    target 322
    type "dominant"
  ]
  edge [
    source 11
    target 333
    type "dominant"
  ]
  edge [
    source 11
    target 374
    type "dominant"
  ]
  edge [
    source 12
    target 5
    type "dominant"
  ]
  edge [
    source 12
    target 223
    type "neutral"
  ]
  edge [
    source 12
    target 288
    type "dominant"
  ]
  edge [
    source 13
    target 19
    type "neutral"
  ]
  edge [
    source 14
    target 13
    type "dominant"
  ]
  edge [
    source 14
    target 131
    type "neutral"
  ]
  edge [
    source 14
    target 17
    type "neutral"
  ]
  edge [
    source 14
    target 19
    type "neutral"
  ]
  edge [
    source 14
    target 37
    type "dominant"
  ]
  edge [
    source 14
    target 291
    type "dominant"
  ]
  edge [
    source 14
    target 322
    type "dominant"
  ]
  edge [
    source 14
    target 382
    type "dominant"
  ]
  edge [
    source 15
    target 13
    type "dominant"
  ]
  edge [
    source 15
    target 122
    type "neutral"
  ]
  edge [
    source 15
    target 83
    type "dominant"
  ]
  edge [
    source 15
    target 119
    type "dominant"
  ]
  edge [
    source 15
    target 121
    type "dominant"
  ]
  edge [
    source 15
    target 190
    type "dominant"
  ]
  edge [
    source 15
    target 200
    type "dominant"
  ]
  edge [
    source 15
    target 224
    type "dominant"
  ]
  edge [
    source 15
    target 228
    type "dominant"
  ]
  edge [
    source 15
    target 290
    type "dominant"
  ]
  edge [
    source 15
    target 291
    type "dominant"
  ]
  edge [
    source 15
    target 293
    type "dominant"
  ]
  edge [
    source 15
    target 297
    type "dominant"
  ]
  edge [
    source 15
    target 322
    type "dominant"
  ]
  edge [
    source 15
    target 382
    type "dominant"
  ]
  edge [
    source 15
    target 408
    type "dominant"
  ]
  edge [
    source 15
    target 433
    type "dominant"
  ]
  edge [
    source 16
    target 13
    type "dominant"
  ]
  edge [
    source 16
    target 15
    type "dominant"
  ]
  edge [
    source 16
    target 46
    type "dominant"
  ]
  edge [
    source 16
    target 87
    type "dominant"
  ]
  edge [
    source 16
    target 119
    type "dominant"
  ]
  edge [
    source 16
    target 121
    type "dominant"
  ]
  edge [
    source 16
    target 122
    type "dominant"
  ]
  edge [
    source 16
    target 192
    type "dominant"
  ]
  edge [
    source 16
    target 194
    type "dominant"
  ]
  edge [
    source 16
    target 322
    type "dominant"
  ]
  edge [
    source 16
    target 433
    type "dominant"
  ]
  edge [
    source 17
    target 13
    type "dominant"
  ]
  edge [
    source 17
    target 130
    type "neutral"
  ]
  edge [
    source 17
    target 408
    type "neutral"
  ]
  edge [
    source 17
    target 333
    type "neutral"
  ]
  edge [
    source 17
    target 131
    type "neutral"
  ]
  edge [
    source 17
    target 19
    type "neutral"
  ]
  edge [
    source 17
    target 220
    type "dominant"
  ]
  edge [
    source 17
    target 222
    type "dominant"
  ]
  edge [
    source 17
    target 410
    type "dominant"
  ]
  edge [
    source 18
    target 13
    type "dominant"
  ]
  edge [
    source 18
    target 14
    type "dominant"
  ]
  edge [
    source 18
    target 151
    type "neutral"
  ]
  edge [
    source 18
    target 142
    type "neutral"
  ]
  edge [
    source 18
    target 39
    type "neutral"
  ]
  edge [
    source 18
    target 306
    type "neutral"
  ]
  edge [
    source 18
    target 286
    type "neutral"
  ]
  edge [
    source 18
    target 19
    type "neutral"
  ]
  edge [
    source 18
    target 37
    type "dominant"
  ]
  edge [
    source 18
    target 173
    type "dominant"
  ]
  edge [
    source 18
    target 192
    type "dominant"
  ]
  edge [
    source 18
    target 215
    type "dominant"
  ]
  edge [
    source 18
    target 223
    type "dominant"
  ]
  edge [
    source 18
    target 393
    type "dominant"
  ]
  edge [
    source 18
    target 395
    type "dominant"
  ]
  edge [
    source 19
    target 192
    type "neutral"
  ]
  edge [
    source 19
    target 83
    type "dominant"
  ]
  edge [
    source 19
    target 194
    type "dominant"
  ]
  edge [
    source 20
    target 21
    type "neutral"
  ]
  edge [
    source 20
    target 24
    type "neutral"
  ]
  edge [
    source 20
    target 25
    type "neutral"
  ]
  edge [
    source 20
    target 26
    type "neutral"
  ]
  edge [
    source 21
    target 209
    type "neutral"
  ]
  edge [
    source 21
    target 211
    type "neutral"
  ]
  edge [
    source 21
    target 24
    type "dominant"
  ]
  edge [
    source 21
    target 57
    type "dominant"
  ]
  edge [
    source 21
    target 109
    type "dominant"
  ]
  edge [
    source 21
    target 208
    type "dominant"
  ]
  edge [
    source 21
    target 264
    type "dominant"
  ]
  edge [
    source 21
    target 308
    type "dominant"
  ]
  edge [
    source 21
    target 343
    type "dominant"
  ]
  edge [
    source 21
    target 345
    type "dominant"
  ]
  edge [
    source 21
    target 372
    type "dominant"
  ]
  edge [
    source 21
    target 382
    type "dominant"
  ]
  edge [
    source 21
    target 444
    type "dominant"
  ]
  edge [
    source 22
    target 20
    type "dominant"
  ]
  edge [
    source 22
    target 55
    type "neutral"
  ]
  edge [
    source 22
    target 56
    type "neutral"
  ]
  edge [
    source 22
    target 142
    type "neutral"
  ]
  edge [
    source 22
    target 205
    type "neutral"
  ]
  edge [
    source 22
    target 171
    type "neutral"
  ]
  edge [
    source 22
    target 110
    type "neutral"
  ]
  edge [
    source 22
    target 23
    type "dominant"
  ]
  edge [
    source 22
    target 109
    type "dominant"
  ]
  edge [
    source 22
    target 231
    type "dominant"
  ]
  edge [
    source 22
    target 315
    type "dominant"
  ]
  edge [
    source 23
    target 20
    type "dominant"
  ]
  edge [
    source 23
    target 56
    type "neutral"
  ]
  edge [
    source 23
    target 171
    type "neutral"
  ]
  edge [
    source 23
    target 55
    type "dominant"
  ]
  edge [
    source 23
    target 400
    type "dominant"
  ]
  edge [
    source 23
    target 402
    type "dominant"
  ]
  edge [
    source 24
    target 170
    type "neutral"
  ]
  edge [
    source 24
    target 402
    type "neutral"
  ]
  edge [
    source 24
    target 26
    type "dominant"
  ]
  edge [
    source 24
    target 110
    type "dominant"
  ]
  edge [
    source 24
    target 379
    type "dominant"
  ]
  edge [
    source 26
    target 22
    type "dominant"
  ]
  edge [
    source 26
    target 25
    type "dominant"
  ]
  edge [
    source 26
    target 404
    type "neutral"
  ]
  edge [
    source 27
    target 28
    type "neutral"
  ]
  edge [
    source 27
    target 29
    type "neutral"
  ]
  edge [
    source 27
    target 30
    type "neutral"
  ]
  edge [
    source 27
    target 31
    type "neutral"
  ]
  edge [
    source 27
    target 35
    type "neutral"
  ]
  edge [
    source 27
    target 391
    type "dominant"
  ]
  edge [
    source 28
    target 46
    type "neutral"
  ]
  edge [
    source 29
    target 32
    type "neutral"
  ]
  edge [
    source 30
    target 28
    type "dominant"
  ]
  edge [
    source 30
    target 31
    type "neutral"
  ]
  edge [
    source 30
    target 93
    type "neutral"
  ]
  edge [
    source 30
    target 232
    type "neutral"
  ]
  edge [
    source 30
    target 150
    type "neutral"
  ]
  edge [
    source 30
    target 96
    type "dominant"
  ]
  edge [
    source 30
    target 148
    type "dominant"
  ]
  edge [
    source 31
    target 29
    type "dominant"
  ]
  edge [
    source 31
    target 214
    type "neutral"
  ]
  edge [
    source 31
    target 215
    type "neutral"
  ]
  edge [
    source 31
    target 32
    type "dominant"
  ]
  edge [
    source 31
    target 33
    type "dominant"
  ]
  edge [
    source 31
    target 212
    type "dominant"
  ]
  edge [
    source 32
    target 27
    type "dominant"
  ]
  edge [
    source 32
    target 383
    type "neutral"
  ]
  edge [
    source 32
    target 384
    type "neutral"
  ]
  edge [
    source 33
    target 27
    type "dominant"
  ]
  edge [
    source 33
    target 29
    type "dominant"
  ]
  edge [
    source 34
    target 27
    type "dominant"
  ]
  edge [
    source 34
    target 377
    type "neutral"
  ]
  edge [
    source 34
    target 100
    type "dominant"
  ]
  edge [
    source 34
    target 195
    type "dominant"
  ]
  edge [
    source 34
    target 217
    type "dominant"
  ]
  edge [
    source 34
    target 295
    type "dominant"
  ]
  edge [
    source 34
    target 384
    type "dominant"
  ]
  edge [
    source 35
    target 28
    type "dominant"
  ]
  edge [
    source 35
    target 32
    type "dominant"
  ]
  edge [
    source 36
    target 27
    type "dominant"
  ]
  edge [
    source 36
    target 31
    type "dominant"
  ]
  edge [
    source 36
    target 212
    type "dominant"
  ]
  edge [
    source 36
    target 398
    type "dominant"
  ]
  edge [
    source 37
    target 410
    type "dominant"
  ]
  edge [
    source 38
    target 14
    type "dominant"
  ]
  edge [
    source 38
    target 37
    type "dominant"
  ]
  edge [
    source 38
    target 138
    type "neutral"
  ]
  edge [
    source 38
    target 41
    type "dominant"
  ]
  edge [
    source 38
    target 80
    type "dominant"
  ]
  edge [
    source 38
    target 136
    type "dominant"
  ]
  edge [
    source 38
    target 286
    type "dominant"
  ]
  edge [
    source 38
    target 399
    type "dominant"
  ]
  edge [
    source 39
    target 37
    type "dominant"
  ]
  edge [
    source 39
    target 286
    type "neutral"
  ]
  edge [
    source 39
    target 68
    type "dominant"
  ]
  edge [
    source 39
    target 82
    type "dominant"
  ]
  edge [
    source 39
    target 118
    type "dominant"
  ]
  edge [
    source 39
    target 441
    type "dominant"
  ]
  edge [
    source 40
    target 21
    type "dominant"
  ]
  edge [
    source 40
    target 37
    type "dominant"
  ]
  edge [
    source 40
    target 59
    type "dominant"
  ]
  edge [
    source 40
    target 109
    type "dominant"
  ]
  edge [
    source 41
    target 37
    type "dominant"
  ]
  edge [
    source 41
    target 135
    type "neutral"
  ]
  edge [
    source 41
    target 399
    type "neutral"
  ]
  edge [
    source 41
    target 42
    type "neutral"
  ]
  edge [
    source 41
    target 387
    type "dominant"
  ]
  edge [
    source 42
    target 37
    type "dominant"
  ]
  edge [
    source 42
    target 39
    type "dominant"
  ]
  edge [
    source 42
    target 135
    type "neutral"
  ]
  edge [
    source 42
    target 286
    type "dominant"
  ]
  edge [
    source 42
    target 387
    type "dominant"
  ]
  edge [
    source 42
    target 395
    type "dominant"
  ]
  edge [
    source 42
    target 399
    type "dominant"
  ]
  edge [
    source 42
    target 430
    type "dominant"
  ]
  edge [
    source 42
    target 441
    type "dominant"
  ]
  edge [
    source 43
    target 37
    type "dominant"
  ]
  edge [
    source 43
    target 39
    type "dominant"
  ]
  edge [
    source 43
    target 138
    type "dominant"
  ]
  edge [
    source 43
    target 152
    type "dominant"
  ]
  edge [
    source 43
    target 155
    type "dominant"
  ]
  edge [
    source 43
    target 173
    type "dominant"
  ]
  edge [
    source 43
    target 331
    type "dominant"
  ]
  edge [
    source 43
    target 395
    type "dominant"
  ]
  edge [
    source 43
    target 430
    type "dominant"
  ]
  edge [
    source 44
    target 28
    type "dominant"
  ]
  edge [
    source 44
    target 334
    type "dominant"
  ]
  edge [
    source 45
    target 28
    type "dominant"
  ]
  edge [
    source 45
    target 391
    type "neutral"
  ]
  edge [
    source 45
    target 355
    type "neutral"
  ]
  edge [
    source 45
    target 47
    type "neutral"
  ]
  edge [
    source 46
    target 232
    type "dominant"
  ]
  edge [
    source 47
    target 28
    type "dominant"
  ]
  edge [
    source 47
    target 290
    type "neutral"
  ]
  edge [
    source 47
    target 226
    type "neutral"
  ]
  edge [
    source 47
    target 355
    type "neutral"
  ]
  edge [
    source 47
    target 291
    type "dominant"
  ]
  edge [
    source 48
    target 49
    type "neutral"
  ]
  edge [
    source 49
    target 298
    type "neutral"
  ]
  edge [
    source 49
    target 398
    type "dominant"
  ]
  edge [
    source 50
    target 48
    type "dominant"
  ]
  edge [
    source 51
    target 48
    type "dominant"
  ]
  edge [
    source 51
    target 237
    type "neutral"
  ]
  edge [
    source 51
    target 374
    type "neutral"
  ]
  edge [
    source 51
    target 366
    type "dominant"
  ]
  edge [
    source 51
    target 367
    type "dominant"
  ]
  edge [
    source 51
    target 432
    type "dominant"
  ]
  edge [
    source 52
    target 53
    type "neutral"
  ]
  edge [
    source 52
    target 54
    type "neutral"
  ]
  edge [
    source 52
    target 215
    type "dominant"
  ]
  edge [
    source 53
    target 25
    type "dominant"
  ]
  edge [
    source 53
    target 224
    type "neutral"
  ]
  edge [
    source 53
    target 54
    type "neutral"
  ]
  edge [
    source 53
    target 208
    type "dominant"
  ]
  edge [
    source 54
    target 432
    type "neutral"
  ]
  edge [
    source 54
    target 224
    type "dominant"
  ]
  edge [
    source 54
    target 245
    type "dominant"
  ]
  edge [
    source 54
    target 318
    type "dominant"
  ]
  edge [
    source 55
    target 56
    type "neutral"
  ]
  edge [
    source 55
    target 109
    type "dominant"
  ]
  edge [
    source 55
    target 293
    type "dominant"
  ]
  edge [
    source 55
    target 311
    type "dominant"
  ]
  edge [
    source 55
    target 400
    type "dominant"
  ]
  edge [
    source 56
    target 21
    type "dominant"
  ]
  edge [
    source 56
    target 26
    type "dominant"
  ]
  edge [
    source 56
    target 109
    type "neutral"
  ]
  edge [
    source 56
    target 110
    type "neutral"
  ]
  edge [
    source 56
    target 112
    type "neutral"
  ]
  edge [
    source 56
    target 204
    type "dominant"
  ]
  edge [
    source 56
    target 209
    type "dominant"
  ]
  edge [
    source 56
    target 301
    type "dominant"
  ]
  edge [
    source 56
    target 402
    type "dominant"
  ]
  edge [
    source 57
    target 23
    type "dominant"
  ]
  edge [
    source 57
    target 55
    type "dominant"
  ]
  edge [
    source 57
    target 170
    type "neutral"
  ]
  edge [
    source 57
    target 171
    type "neutral"
  ]
  edge [
    source 57
    target 110
    type "dominant"
  ]
  edge [
    source 57
    target 112
    type "dominant"
  ]
  edge [
    source 57
    target 416
    type "dominant"
  ]
  edge [
    source 57
    target 423
    type "dominant"
  ]
  edge [
    source 58
    target 55
    type "dominant"
  ]
  edge [
    source 58
    target 123
    type "neutral"
  ]
  edge [
    source 58
    target 184
    type "neutral"
  ]
  edge [
    source 58
    target 187
    type "dominant"
  ]
  edge [
    source 58
    target 251
    type "dominant"
  ]
  edge [
    source 58
    target 271
    type "dominant"
  ]
  edge [
    source 58
    target 315
    type "dominant"
  ]
  edge [
    source 59
    target 55
    type "dominant"
  ]
  edge [
    source 59
    target 295
    type "dominant"
  ]
  edge [
    source 59
    target 400
    type "dominant"
  ]
  edge [
    source 60
    target 23
    type "dominant"
  ]
  edge [
    source 60
    target 42
    type "dominant"
  ]
  edge [
    source 60
    target 55
    type "dominant"
  ]
  edge [
    source 60
    target 171
    type "dominant"
  ]
  edge [
    source 60
    target 228
    type "dominant"
  ]
  edge [
    source 60
    target 286
    type "dominant"
  ]
  edge [
    source 60
    target 393
    type "dominant"
  ]
  edge [
    source 60
    target 399
    type "dominant"
  ]
  edge [
    source 60
    target 410
    type "dominant"
  ]
  edge [
    source 60
    target 430
    type "dominant"
  ]
  edge [
    source 60
    target 443
    type "dominant"
  ]
  edge [
    source 61
    target 119
    type "dominant"
  ]
  edge [
    source 61
    target 291
    type "dominant"
  ]
  edge [
    source 61
    target 333
    type "dominant"
  ]
  edge [
    source 62
    target 61
    type "dominant"
  ]
  edge [
    source 62
    target 63
    type "neutral"
  ]
  edge [
    source 62
    target 356
    type "dominant"
  ]
  edge [
    source 63
    target 61
    type "dominant"
  ]
  edge [
    source 63
    target 217
    type "neutral"
  ]
  edge [
    source 64
    target 65
    type "neutral"
  ]
  edge [
    source 64
    target 68
    type "neutral"
  ]
  edge [
    source 64
    target 69
    type "neutral"
  ]
  edge [
    source 64
    target 343
    type "dominant"
  ]
  edge [
    source 66
    target 64
    type "dominant"
  ]
  edge [
    source 66
    target 69
    type "dominant"
  ]
  edge [
    source 66
    target 172
    type "dominant"
  ]
  edge [
    source 66
    target 238
    type "dominant"
  ]
  edge [
    source 66
    target 304
    type "dominant"
  ]
  edge [
    source 66
    target 340
    type "dominant"
  ]
  edge [
    source 67
    target 64
    type "dominant"
  ]
  edge [
    source 67
    target 65
    type "dominant"
  ]
  edge [
    source 67
    target 234
    type "neutral"
  ]
  edge [
    source 67
    target 303
    type "neutral"
  ]
  edge [
    source 67
    target 68
    type "dominant"
  ]
  edge [
    source 67
    target 69
    type "dominant"
  ]
  edge [
    source 67
    target 310
    type "dominant"
  ]
  edge [
    source 68
    target 65
    type "dominant"
  ]
  edge [
    source 68
    target 274
    type "neutral"
  ]
  edge [
    source 68
    target 69
    type "neutral"
  ]
  edge [
    source 68
    target 275
    type "neutral"
  ]
  edge [
    source 68
    target 298
    type "dominant"
  ]
  edge [
    source 69
    target 65
    type "dominant"
  ]
  edge [
    source 70
    target 161
    type "dominant"
  ]
  edge [
    source 70
    target 225
    type "dominant"
  ]
  edge [
    source 70
    target 233
    type "dominant"
  ]
  edge [
    source 70
    target 393
    type "dominant"
  ]
  edge [
    source 71
    target 6
    type "dominant"
  ]
  edge [
    source 71
    target 70
    type "dominant"
  ]
  edge [
    source 71
    target 101
    type "neutral"
  ]
  edge [
    source 71
    target 102
    type "neutral"
  ]
  edge [
    source 71
    target 127
    type "neutral"
  ]
  edge [
    source 71
    target 72
    type "neutral"
  ]
  edge [
    source 71
    target 128
    type "neutral"
  ]
  edge [
    source 71
    target 129
    type "neutral"
  ]
  edge [
    source 71
    target 103
    type "dominant"
  ]
  edge [
    source 71
    target 115
    type "dominant"
  ]
  edge [
    source 71
    target 144
    type "dominant"
  ]
  edge [
    source 71
    target 166
    type "dominant"
  ]
  edge [
    source 71
    target 181
    type "dominant"
  ]
  edge [
    source 71
    target 191
    type "dominant"
  ]
  edge [
    source 71
    target 209
    type "dominant"
  ]
  edge [
    source 71
    target 219
    type "dominant"
  ]
  edge [
    source 71
    target 239
    type "dominant"
  ]
  edge [
    source 71
    target 283
    type "dominant"
  ]
  edge [
    source 71
    target 300
    type "dominant"
  ]
  edge [
    source 71
    target 302
    type "dominant"
  ]
  edge [
    source 71
    target 315
    type "dominant"
  ]
  edge [
    source 71
    target 411
    type "dominant"
  ]
  edge [
    source 72
    target 70
    type "dominant"
  ]
  edge [
    source 72
    target 123
    type "neutral"
  ]
  edge [
    source 72
    target 144
    type "neutral"
  ]
  edge [
    source 72
    target 102
    type "neutral"
  ]
  edge [
    source 72
    target 126
    type "dominant"
  ]
  edge [
    source 72
    target 191
    type "dominant"
  ]
  edge [
    source 72
    target 295
    type "dominant"
  ]
  edge [
    source 72
    target 300
    type "dominant"
  ]
  edge [
    source 72
    target 302
    type "dominant"
  ]
  edge [
    source 72
    target 396
    type "dominant"
  ]
  edge [
    source 72
    target 411
    type "dominant"
  ]
  edge [
    source 73
    target 42
    type "dominant"
  ]
  edge [
    source 73
    target 70
    type "dominant"
  ]
  edge [
    source 73
    target 123
    type "dominant"
  ]
  edge [
    source 73
    target 156
    type "dominant"
  ]
  edge [
    source 73
    target 161
    type "dominant"
  ]
  edge [
    source 73
    target 173
    type "dominant"
  ]
  edge [
    source 73
    target 178
    type "dominant"
  ]
  edge [
    source 73
    target 184
    type "dominant"
  ]
  edge [
    source 73
    target 198
    type "dominant"
  ]
  edge [
    source 73
    target 296
    type "dominant"
  ]
  edge [
    source 73
    target 396
    type "dominant"
  ]
  edge [
    source 73
    target 397
    type "dominant"
  ]
  edge [
    source 74
    target 75
    type "neutral"
  ]
  edge [
    source 74
    target 76
    type "neutral"
  ]
  edge [
    source 74
    target 79
    type "neutral"
  ]
  edge [
    source 74
    target 158
    type "dominant"
  ]
  edge [
    source 75
    target 158
    type "neutral"
  ]
  edge [
    source 75
    target 81
    type "neutral"
  ]
  edge [
    source 75
    target 241
    type "dominant"
  ]
  edge [
    source 76
    target 79
    type "neutral"
  ]
  edge [
    source 76
    target 323
    type "neutral"
  ]
  edge [
    source 76
    target 80
    type "neutral"
  ]
  edge [
    source 76
    target 130
    type "dominant"
  ]
  edge [
    source 76
    target 209
    type "dominant"
  ]
  edge [
    source 76
    target 392
    type "dominant"
  ]
  edge [
    source 77
    target 74
    type "dominant"
  ]
  edge [
    source 77
    target 255
    type "neutral"
  ]
  edge [
    source 77
    target 126
    type "neutral"
  ]
  edge [
    source 77
    target 106
    type "neutral"
  ]
  edge [
    source 77
    target 141
    type "neutral"
  ]
  edge [
    source 77
    target 219
    type "neutral"
  ]
  edge [
    source 77
    target 129
    type "neutral"
  ]
  edge [
    source 77
    target 104
    type "dominant"
  ]
  edge [
    source 77
    target 140
    type "dominant"
  ]
  edge [
    source 77
    target 156
    type "dominant"
  ]
  edge [
    source 77
    target 375
    type "dominant"
  ]
  edge [
    source 78
    target 74
    type "dominant"
  ]
  edge [
    source 78
    target 327
    type "neutral"
  ]
  edge [
    source 78
    target 328
    type "neutral"
  ]
  edge [
    source 78
    target 329
    type "neutral"
  ]
  edge [
    source 78
    target 330
    type "neutral"
  ]
  edge [
    source 78
    target 187
    type "neutral"
  ]
  edge [
    source 79
    target 75
    type "dominant"
  ]
  edge [
    source 79
    target 190
    type "neutral"
  ]
  edge [
    source 79
    target 407
    type "neutral"
  ]
  edge [
    source 79
    target 323
    type "neutral"
  ]
  edge [
    source 79
    target 80
    type "dominant"
  ]
  edge [
    source 79
    target 165
    type "dominant"
  ]
  edge [
    source 79
    target 251
    type "dominant"
  ]
  edge [
    source 80
    target 4
    type "dominant"
  ]
  edge [
    source 80
    target 74
    type "dominant"
  ]
  edge [
    source 80
    target 106
    type "neutral"
  ]
  edge [
    source 80
    target 325
    type "neutral"
  ]
  edge [
    source 80
    target 256
    type "neutral"
  ]
  edge [
    source 80
    target 323
    type "neutral"
  ]
  edge [
    source 80
    target 374
    type "dominant"
  ]
  edge [
    source 80
    target 411
    type "dominant"
  ]
  edge [
    source 80
    target 424
    type "dominant"
  ]
  edge [
    source 81
    target 74
    type "dominant"
  ]
  edge [
    source 81
    target 77
    type "dominant"
  ]
  edge [
    source 81
    target 205
    type "neutral"
  ]
  edge [
    source 81
    target 254
    type "neutral"
  ]
  edge [
    source 81
    target 256
    type "neutral"
  ]
  edge [
    source 81
    target 130
    type "dominant"
  ]
  edge [
    source 81
    target 158
    type "dominant"
  ]
  edge [
    source 81
    target 168
    type "dominant"
  ]
  edge [
    source 81
    target 191
    type "dominant"
  ]
  edge [
    source 82
    target 83
    type "neutral"
  ]
  edge [
    source 82
    target 85
    type "neutral"
  ]
  edge [
    source 82
    target 87
    type "neutral"
  ]
  edge [
    source 83
    target 87
    type "neutral"
  ]
  edge [
    source 84
    target 59
    type "dominant"
  ]
  edge [
    source 84
    target 82
    type "dominant"
  ]
  edge [
    source 84
    target 132
    type "neutral"
  ]
  edge [
    source 84
    target 271
    type "neutral"
  ]
  edge [
    source 84
    target 97
    type "neutral"
  ]
  edge [
    source 84
    target 134
    type "dominant"
  ]
  edge [
    source 84
    target 135
    type "dominant"
  ]
  edge [
    source 84
    target 163
    type "dominant"
  ]
  edge [
    source 84
    target 169
    type "dominant"
  ]
  edge [
    source 84
    target 188
    type "dominant"
  ]
  edge [
    source 84
    target 199
    type "dominant"
  ]
  edge [
    source 84
    target 272
    type "dominant"
  ]
  edge [
    source 84
    target 295
    type "dominant"
  ]
  edge [
    source 84
    target 442
    type "dominant"
  ]
  edge [
    source 85
    target 34
    type "dominant"
  ]
  edge [
    source 85
    target 87
    type "neutral"
  ]
  edge [
    source 85
    target 222
    type "neutral"
  ]
  edge [
    source 85
    target 347
    type "neutral"
  ]
  edge [
    source 85
    target 153
    type "dominant"
  ]
  edge [
    source 86
    target 82
    type "dominant"
  ]
  edge [
    source 86
    target 88
    type "dominant"
  ]
  edge [
    source 86
    target 119
    type "dominant"
  ]
  edge [
    source 86
    target 121
    type "dominant"
  ]
  edge [
    source 86
    target 364
    type "dominant"
  ]
  edge [
    source 87
    target 136
    type "dominant"
  ]
  edge [
    source 87
    target 380
    type "dominant"
  ]
  edge [
    source 87
    target 434
    type "dominant"
  ]
  edge [
    source 88
    target 82
    type "dominant"
  ]
  edge [
    source 88
    target 200
    type "neutral"
  ]
  edge [
    source 88
    target 122
    type "dominant"
  ]
  edge [
    source 88
    target 163
    type "dominant"
  ]
  edge [
    source 89
    target 82
    type "dominant"
  ]
  edge [
    source 89
    target 87
    type "dominant"
  ]
  edge [
    source 89
    target 227
    type "neutral"
  ]
  edge [
    source 89
    target 363
    type "neutral"
  ]
  edge [
    source 89
    target 225
    type "dominant"
  ]
  edge [
    source 90
    target 91
    type "neutral"
  ]
  edge [
    source 90
    target 150
    type "dominant"
  ]
  edge [
    source 90
    target 453
    type "dominant"
  ]
  edge [
    source 91
    target 325
    type "neutral"
  ]
  edge [
    source 91
    target 98
    type "dominant"
  ]
  edge [
    source 92
    target 30
    type "dominant"
  ]
  edge [
    source 92
    target 90
    type "dominant"
  ]
  edge [
    source 92
    target 93
    type "dominant"
  ]
  edge [
    source 92
    target 96
    type "dominant"
  ]
  edge [
    source 92
    target 150
    type "dominant"
  ]
  edge [
    source 92
    target 189
    type "dominant"
  ]
  edge [
    source 92
    target 303
    type "dominant"
  ]
  edge [
    source 92
    target 453
    type "dominant"
  ]
  edge [
    source 93
    target 90
    type "dominant"
  ]
  edge [
    source 93
    target 150
    type "neutral"
  ]
  edge [
    source 93
    target 96
    type "dominant"
  ]
  edge [
    source 93
    target 98
    type "dominant"
  ]
  edge [
    source 95
    target 94
    type "dominant"
  ]
  edge [
    source 95
    target 239
    type "dominant"
  ]
  edge [
    source 96
    target 85
    type "dominant"
  ]
  edge [
    source 96
    target 94
    type "dominant"
  ]
  edge [
    source 97
    target 94
    type "dominant"
  ]
  edge [
    source 97
    target 271
    type "neutral"
  ]
  edge [
    source 97
    target 272
    type "neutral"
  ]
  edge [
    source 97
    target 380
    type "dominant"
  ]
  edge [
    source 98
    target 100
    type "neutral"
  ]
  edge [
    source 98
    target 445
    type "dominant"
  ]
  edge [
    source 98
    target 453
    type "dominant"
  ]
  edge [
    source 99
    target 98
    type "dominant"
  ]
  edge [
    source 99
    target 258
    type "neutral"
  ]
  edge [
    source 99
    target 259
    type "neutral"
  ]
  edge [
    source 100
    target 310
    type "neutral"
  ]
  edge [
    source 100
    target 236
    type "dominant"
  ]
  edge [
    source 100
    target 267
    type "dominant"
  ]
  edge [
    source 100
    target 352
    type "dominant"
  ]
  edge [
    source 101
    target 57
    type "dominant"
  ]
  edge [
    source 101
    target 102
    type "neutral"
  ]
  edge [
    source 101
    target 103
    type "neutral"
  ]
  edge [
    source 101
    target 104
    type "neutral"
  ]
  edge [
    source 101
    target 108
    type "neutral"
  ]
  edge [
    source 101
    target 142
    type "dominant"
  ]
  edge [
    source 101
    target 144
    type "dominant"
  ]
  edge [
    source 101
    target 176
    type "dominant"
  ]
  edge [
    source 102
    target 57
    type "dominant"
  ]
  edge [
    source 102
    target 176
    type "neutral"
  ]
  edge [
    source 102
    target 103
    type "neutral"
  ]
  edge [
    source 102
    target 104
    type "neutral"
  ]
  edge [
    source 103
    target 176
    type "neutral"
  ]
  edge [
    source 103
    target 142
    type "neutral"
  ]
  edge [
    source 103
    target 104
    type "neutral"
  ]
  edge [
    source 103
    target 105
    type "dominant"
  ]
  edge [
    source 103
    target 126
    type "dominant"
  ]
  edge [
    source 103
    target 128
    type "dominant"
  ]
  edge [
    source 103
    target 179
    type "dominant"
  ]
  edge [
    source 103
    target 188
    type "dominant"
  ]
  edge [
    source 104
    target 6
    type "dominant"
  ]
  edge [
    source 104
    target 176
    type "neutral"
  ]
  edge [
    source 104
    target 167
    type "neutral"
  ]
  edge [
    source 104
    target 331
    type "neutral"
  ]
  edge [
    source 104
    target 156
    type "neutral"
  ]
  edge [
    source 104
    target 105
    type "dominant"
  ]
  edge [
    source 104
    target 107
    type "dominant"
  ]
  edge [
    source 104
    target 126
    type "dominant"
  ]
  edge [
    source 104
    target 127
    type "dominant"
  ]
  edge [
    source 104
    target 142
    type "dominant"
  ]
  edge [
    source 104
    target 144
    type "dominant"
  ]
  edge [
    source 104
    target 145
    type "dominant"
  ]
  edge [
    source 104
    target 151
    type "dominant"
  ]
  edge [
    source 104
    target 165
    type "dominant"
  ]
  edge [
    source 104
    target 166
    type "dominant"
  ]
  edge [
    source 104
    target 178
    type "dominant"
  ]
  edge [
    source 104
    target 179
    type "dominant"
  ]
  edge [
    source 104
    target 289
    type "dominant"
  ]
  edge [
    source 104
    target 326
    type "dominant"
  ]
  edge [
    source 104
    target 375
    type "dominant"
  ]
  edge [
    source 104
    target 396
    type "dominant"
  ]
  edge [
    source 105
    target 101
    type "dominant"
  ]
  edge [
    source 105
    target 102
    type "dominant"
  ]
  edge [
    source 105
    target 282
    type "neutral"
  ]
  edge [
    source 105
    target 179
    type "neutral"
  ]
  edge [
    source 105
    target 337
    type "neutral"
  ]
  edge [
    source 105
    target 175
    type "dominant"
  ]
  edge [
    source 105
    target 283
    type "dominant"
  ]
  edge [
    source 106
    target 4
    type "dominant"
  ]
  edge [
    source 106
    target 101
    type "dominant"
  ]
  edge [
    source 106
    target 165
    type "neutral"
  ]
  edge [
    source 106
    target 167
    type "neutral"
  ]
  edge [
    source 106
    target 168
    type "neutral"
  ]
  edge [
    source 106
    target 141
    type "neutral"
  ]
  edge [
    source 106
    target 107
    type "dominant"
  ]
  edge [
    source 106
    target 129
    type "dominant"
  ]
  edge [
    source 106
    target 156
    type "dominant"
  ]
  edge [
    source 106
    target 223
    type "dominant"
  ]
  edge [
    source 106
    target 256
    type "dominant"
  ]
  edge [
    source 106
    target 323
    type "dominant"
  ]
  edge [
    source 106
    target 325
    type "dominant"
  ]
  edge [
    source 107
    target 101
    type "dominant"
  ]
  edge [
    source 107
    target 102
    type "dominant"
  ]
  edge [
    source 107
    target 179
    type "neutral"
  ]
  edge [
    source 107
    target 108
    type "neutral"
  ]
  edge [
    source 107
    target 375
    type "neutral"
  ]
  edge [
    source 107
    target 129
    type "neutral"
  ]
  edge [
    source 107
    target 140
    type "dominant"
  ]
  edge [
    source 107
    target 259
    type "dominant"
  ]
  edge [
    source 107
    target 414
    type "dominant"
  ]
  edge [
    source 108
    target 140
    type "neutral"
  ]
  edge [
    source 108
    target 270
    type "neutral"
  ]
  edge [
    source 108
    target 129
    type "neutral"
  ]
  edge [
    source 108
    target 126
    type "dominant"
  ]
  edge [
    source 108
    target 241
    type "dominant"
  ]
  edge [
    source 108
    target 391
    type "dominant"
  ]
  edge [
    source 108
    target 414
    type "dominant"
  ]
  edge [
    source 108
    target 429
    type "dominant"
  ]
  edge [
    source 110
    target 109
    type "dominant"
  ]
  edge [
    source 110
    target 231
    type "neutral"
  ]
  edge [
    source 110
    target 400
    type "dominant"
  ]
  edge [
    source 110
    target 423
    type "dominant"
  ]
  edge [
    source 111
    target 22
    type "dominant"
  ]
  edge [
    source 111
    target 26
    type "dominant"
  ]
  edge [
    source 111
    target 56
    type "dominant"
  ]
  edge [
    source 111
    target 112
    type "dominant"
  ]
  edge [
    source 111
    target 204
    type "dominant"
  ]
  edge [
    source 111
    target 208
    type "dominant"
  ]
  edge [
    source 111
    target 210
    type "dominant"
  ]
  edge [
    source 111
    target 231
    type "dominant"
  ]
  edge [
    source 111
    target 301
    type "dominant"
  ]
  edge [
    source 111
    target 315
    type "dominant"
  ]
  edge [
    source 111
    target 341
    type "dominant"
  ]
  edge [
    source 111
    target 402
    type "dominant"
  ]
  edge [
    source 111
    target 404
    type "dominant"
  ]
  edge [
    source 112
    target 21
    type "dominant"
  ]
  edge [
    source 112
    target 23
    type "dominant"
  ]
  edge [
    source 112
    target 402
    type "neutral"
  ]
  edge [
    source 112
    target 404
    type "neutral"
  ]
  edge [
    source 112
    target 341
    type "neutral"
  ]
  edge [
    source 112
    target 204
    type "dominant"
  ]
  edge [
    source 112
    target 210
    type "dominant"
  ]
  edge [
    source 112
    target 345
    type "dominant"
  ]
  edge [
    source 113
    target 34
    type "dominant"
  ]
  edge [
    source 113
    target 115
    type "neutral"
  ]
  edge [
    source 113
    target 216
    type "dominant"
  ]
  edge [
    source 113
    target 217
    type "dominant"
  ]
  edge [
    source 113
    target 278
    type "dominant"
  ]
  edge [
    source 113
    target 285
    type "dominant"
  ]
  edge [
    source 113
    target 457
    type "dominant"
  ]
  edge [
    source 114
    target 113
    type "dominant"
  ]
  edge [
    source 114
    target 115
    type "dominant"
  ]
  edge [
    source 114
    target 216
    type "dominant"
  ]
  edge [
    source 114
    target 217
    type "dominant"
  ]
  edge [
    source 115
    target 339
    type "neutral"
  ]
  edge [
    source 116
    target 117
    type "neutral"
  ]
  edge [
    source 116
    target 122
    type "neutral"
  ]
  edge [
    source 116
    target 384
    type "dominant"
  ]
  edge [
    source 117
    target 118
    type "neutral"
  ]
  edge [
    source 117
    target 188
    type "dominant"
  ]
  edge [
    source 118
    target 116
    type "dominant"
  ]
  edge [
    source 119
    target 116
    type "dominant"
  ]
  edge [
    source 119
    target 333
    type "neutral"
  ]
  edge [
    source 119
    target 121
    type "neutral"
  ]
  edge [
    source 119
    target 122
    type "dominant"
  ]
  edge [
    source 119
    target 200
    type "dominant"
  ]
  edge [
    source 119
    target 322
    type "dominant"
  ]
  edge [
    source 120
    target 116
    type "dominant"
  ]
  edge [
    source 120
    target 117
    type "dominant"
  ]
  edge [
    source 120
    target 199
    type "dominant"
  ]
  edge [
    source 121
    target 87
    type "dominant"
  ]
  edge [
    source 121
    target 116
    type "dominant"
  ]
  edge [
    source 121
    target 117
    type "dominant"
  ]
  edge [
    source 121
    target 322
    type "neutral"
  ]
  edge [
    source 121
    target 228
    type "neutral"
  ]
  edge [
    source 121
    target 122
    type "neutral"
  ]
  edge [
    source 121
    target 145
    type "dominant"
  ]
  edge [
    source 122
    target 117
    type "dominant"
  ]
  edge [
    source 122
    target 322
    type "neutral"
  ]
  edge [
    source 122
    target 145
    type "neutral"
  ]
  edge [
    source 122
    target 194
    type "neutral"
  ]
  edge [
    source 122
    target 228
    type "neutral"
  ]
  edge [
    source 122
    target 192
    type "dominant"
  ]
  edge [
    source 122
    target 287
    type "dominant"
  ]
  edge [
    source 122
    target 290
    type "dominant"
  ]
  edge [
    source 122
    target 297
    type "dominant"
  ]
  edge [
    source 123
    target 127
    type "dominant"
  ]
  edge [
    source 123
    target 155
    type "dominant"
  ]
  edge [
    source 123
    target 184
    type "dominant"
  ]
  edge [
    source 123
    target 206
    type "dominant"
  ]
  edge [
    source 123
    target 396
    type "dominant"
  ]
  edge [
    source 124
    target 71
    type "dominant"
  ]
  edge [
    source 125
    target 71
    type "dominant"
  ]
  edge [
    source 125
    target 72
    type "dominant"
  ]
  edge [
    source 125
    target 104
    type "dominant"
  ]
  edge [
    source 125
    target 129
    type "dominant"
  ]
  edge [
    source 125
    target 142
    type "dominant"
  ]
  edge [
    source 125
    target 144
    type "dominant"
  ]
  edge [
    source 125
    target 176
    type "dominant"
  ]
  edge [
    source 125
    target 179
    type "dominant"
  ]
  edge [
    source 125
    target 184
    type "dominant"
  ]
  edge [
    source 125
    target 219
    type "dominant"
  ]
  edge [
    source 125
    target 255
    type "dominant"
  ]
  edge [
    source 126
    target 71
    type "dominant"
  ]
  edge [
    source 126
    target 255
    type "neutral"
  ]
  edge [
    source 126
    target 219
    type "neutral"
  ]
  edge [
    source 126
    target 283
    type "dominant"
  ]
  edge [
    source 127
    target 165
    type "neutral"
  ]
  edge [
    source 127
    target 166
    type "neutral"
  ]
  edge [
    source 127
    target 167
    type "neutral"
  ]
  edge [
    source 127
    target 168
    type "neutral"
  ]
  edge [
    source 127
    target 141
    type "dominant"
  ]
  edge [
    source 127
    target 176
    type "dominant"
  ]
  edge [
    source 127
    target 181
    type "dominant"
  ]
  edge [
    source 127
    target 191
    type "dominant"
  ]
  edge [
    source 127
    target 295
    type "dominant"
  ]
  edge [
    source 127
    target 319
    type "dominant"
  ]
  edge [
    source 128
    target 166
    type "dominant"
  ]
  edge [
    source 129
    target 6
    type "dominant"
  ]
  edge [
    source 129
    target 102
    type "dominant"
  ]
  edge [
    source 129
    target 175
    type "neutral"
  ]
  edge [
    source 129
    target 179
    type "neutral"
  ]
  edge [
    source 129
    target 156
    type "neutral"
  ]
  edge [
    source 129
    target 141
    type "neutral"
  ]
  edge [
    source 129
    target 168
    type "dominant"
  ]
  edge [
    source 129
    target 178
    type "dominant"
  ]
  edge [
    source 129
    target 181
    type "dominant"
  ]
  edge [
    source 129
    target 191
    type "dominant"
  ]
  edge [
    source 129
    target 255
    type "dominant"
  ]
  edge [
    source 129
    target 256
    type "dominant"
  ]
  edge [
    source 129
    target 457
    type "dominant"
  ]
  edge [
    source 130
    target 14
    type "dominant"
  ]
  edge [
    source 130
    target 250
    type "dominant"
  ]
  edge [
    source 131
    target 220
    type "neutral"
  ]
  edge [
    source 131
    target 296
    type "neutral"
  ]
  edge [
    source 131
    target 408
    type "neutral"
  ]
  edge [
    source 132
    target 169
    type "neutral"
  ]
  edge [
    source 132
    target 134
    type "neutral"
  ]
  edge [
    source 132
    target 163
    type "neutral"
  ]
  edge [
    source 132
    target 161
    type "dominant"
  ]
  edge [
    source 132
    target 295
    type "dominant"
  ]
  edge [
    source 133
    target 1
    type "dominant"
  ]
  edge [
    source 133
    target 148
    type "neutral"
  ]
  edge [
    source 133
    target 145
    type "neutral"
  ]
  edge [
    source 133
    target 328
    type "neutral"
  ]
  edge [
    source 133
    target 249
    type "dominant"
  ]
  edge [
    source 133
    target 330
    type "dominant"
  ]
  edge [
    source 134
    target 161
    type "neutral"
  ]
  edge [
    source 134
    target 169
    type "neutral"
  ]
  edge [
    source 134
    target 391
    type "dominant"
  ]
  edge [
    source 135
    target 138
    type "dominant"
  ]
  edge [
    source 135
    target 152
    type "dominant"
  ]
  edge [
    source 136
    target 59
    type "dominant"
  ]
  edge [
    source 137
    target 132
    type "dominant"
  ]
  edge [
    source 137
    target 136
    type "dominant"
  ]
  edge [
    source 137
    target 367
    type "dominant"
  ]
  edge [
    source 138
    target 136
    type "dominant"
  ]
  edge [
    source 138
    target 274
    type "dominant"
  ]
  edge [
    source 138
    target 275
    type "dominant"
  ]
  edge [
    source 138
    target 380
    type "dominant"
  ]
  edge [
    source 139
    target 38
    type "dominant"
  ]
  edge [
    source 139
    target 132
    type "dominant"
  ]
  edge [
    source 139
    target 136
    type "dominant"
  ]
  edge [
    source 139
    target 138
    type "dominant"
  ]
  edge [
    source 139
    target 169
    type "dominant"
  ]
  edge [
    source 139
    target 274
    type "dominant"
  ]
  edge [
    source 140
    target 106
    type "dominant"
  ]
  edge [
    source 140
    target 141
    type "neutral"
  ]
  edge [
    source 140
    target 260
    type "dominant"
  ]
  edge [
    source 140
    target 270
    type "dominant"
  ]
  edge [
    source 140
    target 318
    type "dominant"
  ]
  edge [
    source 140
    target 407
    type "dominant"
  ]
  edge [
    source 140
    target 414
    type "dominant"
  ]
  edge [
    source 140
    target 429
    type "dominant"
  ]
  edge [
    source 141
    target 270
    type "neutral"
  ]
  edge [
    source 141
    target 167
    type "neutral"
  ]
  edge [
    source 141
    target 156
    type "neutral"
  ]
  edge [
    source 141
    target 158
    type "dominant"
  ]
  edge [
    source 141
    target 168
    type "dominant"
  ]
  edge [
    source 141
    target 179
    type "dominant"
  ]
  edge [
    source 141
    target 241
    type "dominant"
  ]
  edge [
    source 141
    target 414
    type "dominant"
  ]
  edge [
    source 141
    target 457
    type "dominant"
  ]
  edge [
    source 142
    target 6
    type "dominant"
  ]
  edge [
    source 142
    target 39
    type "dominant"
  ]
  edge [
    source 142
    target 176
    type "neutral"
  ]
  edge [
    source 142
    target 183
    type "neutral"
  ]
  edge [
    source 142
    target 341
    type "dominant"
  ]
  edge [
    source 143
    target 6
    type "dominant"
  ]
  edge [
    source 143
    target 239
    type "neutral"
  ]
  edge [
    source 143
    target 240
    type "neutral"
  ]
  edge [
    source 143
    target 390
    type "dominant"
  ]
  edge [
    source 143
    target 401
    type "dominant"
  ]
  edge [
    source 144
    target 6
    type "dominant"
  ]
  edge [
    source 144
    target 103
    type "dominant"
  ]
  edge [
    source 144
    target 105
    type "dominant"
  ]
  edge [
    source 144
    target 142
    type "dominant"
  ]
  edge [
    source 144
    target 175
    type "neutral"
  ]
  edge [
    source 144
    target 176
    type "neutral"
  ]
  edge [
    source 144
    target 210
    type "dominant"
  ]
  edge [
    source 144
    target 302
    type "dominant"
  ]
  edge [
    source 144
    target 315
    type "dominant"
  ]
  edge [
    source 145
    target 6
    type "dominant"
  ]
  edge [
    source 145
    target 47
    type "dominant"
  ]
  edge [
    source 145
    target 148
    type "neutral"
  ]
  edge [
    source 145
    target 234
    type "neutral"
  ]
  edge [
    source 145
    target 237
    type "neutral"
  ]
  edge [
    source 145
    target 243
    type "dominant"
  ]
  edge [
    source 145
    target 248
    type "dominant"
  ]
  edge [
    source 145
    target 328
    type "dominant"
  ]
  edge [
    source 145
    target 355
    type "dominant"
  ]
  edge [
    source 145
    target 374
    type "dominant"
  ]
  edge [
    source 145
    target 432
    type "dominant"
  ]
  edge [
    source 147
    target 146
    type "dominant"
  ]
  edge [
    source 147
    target 439
    type "dominant"
  ]
  edge [
    source 148
    target 149
    type "neutral"
  ]
  edge [
    source 148
    target 150
    type "neutral"
  ]
  edge [
    source 148
    target 214
    type "dominant"
  ]
  edge [
    source 148
    target 252
    type "dominant"
  ]
  edge [
    source 148
    target 328
    type "dominant"
  ]
  edge [
    source 148
    target 361
    type "dominant"
  ]
  edge [
    source 149
    target 232
    type "neutral"
  ]
  edge [
    source 149
    target 243
    type "dominant"
  ]
  edge [
    source 150
    target 91
    type "dominant"
  ]
  edge [
    source 150
    target 96
    type "dominant"
  ]
  edge [
    source 151
    target 39
    type "dominant"
  ]
  edge [
    source 151
    target 153
    type "neutral"
  ]
  edge [
    source 151
    target 154
    type "neutral"
  ]
  edge [
    source 151
    target 155
    type "neutral"
  ]
  edge [
    source 151
    target 396
    type "dominant"
  ]
  edge [
    source 152
    target 151
    type "dominant"
  ]
  edge [
    source 152
    target 155
    type "dominant"
  ]
  edge [
    source 152
    target 165
    type "dominant"
  ]
  edge [
    source 152
    target 289
    type "dominant"
  ]
  edge [
    source 152
    target 331
    type "dominant"
  ]
  edge [
    source 153
    target 346
    type "neutral"
  ]
  edge [
    source 153
    target 222
    type "neutral"
  ]
  edge [
    source 153
    target 347
    type "neutral"
  ]
  edge [
    source 154
    target 405
    type "neutral"
  ]
  edge [
    source 154
    target 375
    type "neutral"
  ]
  edge [
    source 154
    target 331
    type "dominant"
  ]
  edge [
    source 155
    target 289
    type "neutral"
  ]
  edge [
    source 155
    target 203
    type "neutral"
  ]
  edge [
    source 155
    target 288
    type "dominant"
  ]
  edge [
    source 155
    target 331
    type "dominant"
  ]
  edge [
    source 156
    target 151
    type "dominant"
  ]
  edge [
    source 156
    target 154
    type "dominant"
  ]
  edge [
    source 156
    target 155
    type "dominant"
  ]
  edge [
    source 156
    target 324
    type "neutral"
  ]
  edge [
    source 156
    target 179
    type "neutral"
  ]
  edge [
    source 156
    target 331
    type "dominant"
  ]
  edge [
    source 156
    target 339
    type "dominant"
  ]
  edge [
    source 156
    target 414
    type "dominant"
  ]
  edge [
    source 157
    target 75
    type "dominant"
  ]
  edge [
    source 157
    target 375
    type "dominant"
  ]
  edge [
    source 157
    target 411
    type "dominant"
  ]
  edge [
    source 159
    target 161
    type "neutral"
  ]
  edge [
    source 159
    target 163
    type "neutral"
  ]
  edge [
    source 159
    target 194
    type "dominant"
  ]
  edge [
    source 160
    target 15
    type "dominant"
  ]
  edge [
    source 160
    target 159
    type "dominant"
  ]
  edge [
    source 160
    target 194
    type "dominant"
  ]
  edge [
    source 160
    target 452
    type "dominant"
  ]
  edge [
    source 161
    target 169
    type "neutral"
  ]
  edge [
    source 161
    target 163
    type "neutral"
  ]
  edge [
    source 162
    target 15
    type "dominant"
  ]
  edge [
    source 162
    target 159
    type "dominant"
  ]
  edge [
    source 162
    target 163
    type "dominant"
  ]
  edge [
    source 162
    target 194
    type "dominant"
  ]
  edge [
    source 163
    target 121
    type "dominant"
  ]
  edge [
    source 163
    target 134
    type "dominant"
  ]
  edge [
    source 163
    target 169
    type "neutral"
  ]
  edge [
    source 164
    target 15
    type "dominant"
  ]
  edge [
    source 164
    target 159
    type "dominant"
  ]
  edge [
    source 164
    target 194
    type "dominant"
  ]
  edge [
    source 164
    target 297
    type "dominant"
  ]
  edge [
    source 165
    target 141
    type "dominant"
  ]
  edge [
    source 165
    target 166
    type "neutral"
  ]
  edge [
    source 165
    target 167
    type "neutral"
  ]
  edge [
    source 165
    target 168
    type "neutral"
  ]
  edge [
    source 165
    target 250
    type "dominant"
  ]
  edge [
    source 166
    target 254
    type "neutral"
  ]
  edge [
    source 166
    target 167
    type "neutral"
  ]
  edge [
    source 166
    target 319
    type "neutral"
  ]
  edge [
    source 166
    target 320
    type "neutral"
  ]
  edge [
    source 166
    target 168
    type "dominant"
  ]
  edge [
    source 166
    target 191
    type "dominant"
  ]
  edge [
    source 166
    target 285
    type "dominant"
  ]
  edge [
    source 167
    target 250
    type "dominant"
  ]
  edge [
    source 167
    target 376
    type "dominant"
  ]
  edge [
    source 168
    target 107
    type "dominant"
  ]
  edge [
    source 168
    target 130
    type "dominant"
  ]
  edge [
    source 168
    target 167
    type "dominant"
  ]
  edge [
    source 168
    target 191
    type "dominant"
  ]
  edge [
    source 168
    target 242
    type "dominant"
  ]
  edge [
    source 168
    target 249
    type "dominant"
  ]
  edge [
    source 168
    target 250
    type "dominant"
  ]
  edge [
    source 168
    target 457
    type "dominant"
  ]
  edge [
    source 170
    target 171
    type "neutral"
  ]
  edge [
    source 170
    target 308
    type "dominant"
  ]
  edge [
    source 170
    target 381
    type "dominant"
  ]
  edge [
    source 170
    target 422
    type "dominant"
  ]
  edge [
    source 170
    target 423
    type "dominant"
  ]
  edge [
    source 171
    target 24
    type "dominant"
  ]
  edge [
    source 171
    target 110
    type "dominant"
  ]
  edge [
    source 171
    target 112
    type "dominant"
  ]
  edge [
    source 171
    target 138
    type "dominant"
  ]
  edge [
    source 171
    target 173
    type "dominant"
  ]
  edge [
    source 171
    target 263
    type "dominant"
  ]
  edge [
    source 171
    target 423
    type "dominant"
  ]
  edge [
    source 172
    target 57
    type "dominant"
  ]
  edge [
    source 172
    target 335
    type "neutral"
  ]
  edge [
    source 172
    target 206
    type "dominant"
  ]
  edge [
    source 173
    target 23
    type "dominant"
  ]
  edge [
    source 173
    target 42
    type "dominant"
  ]
  edge [
    source 173
    target 57
    type "dominant"
  ]
  edge [
    source 173
    target 161
    type "dominant"
  ]
  edge [
    source 173
    target 397
    type "neutral"
  ]
  edge [
    source 173
    target 395
    type "neutral"
  ]
  edge [
    source 173
    target 430
    type "neutral"
  ]
  edge [
    source 173
    target 283
    type "dominant"
  ]
  edge [
    source 173
    target 364
    type "dominant"
  ]
  edge [
    source 173
    target 387
    type "dominant"
  ]
  edge [
    source 173
    target 393
    type "dominant"
  ]
  edge [
    source 173
    target 394
    type "dominant"
  ]
  edge [
    source 173
    target 410
    type "dominant"
  ]
  edge [
    source 173
    target 442
    type "dominant"
  ]
  edge [
    source 173
    target 443
    type "dominant"
  ]
  edge [
    source 173
    target 454
    type "dominant"
  ]
  edge [
    source 174
    target 18
    type "dominant"
  ]
  edge [
    source 174
    target 110
    type "dominant"
  ]
  edge [
    source 174
    target 170
    type "dominant"
  ]
  edge [
    source 174
    target 253
    type "dominant"
  ]
  edge [
    source 175
    target 177
    type "neutral"
  ]
  edge [
    source 175
    target 178
    type "neutral"
  ]
  edge [
    source 175
    target 181
    type "neutral"
  ]
  edge [
    source 175
    target 255
    type "dominant"
  ]
  edge [
    source 175
    target 457
    type "dominant"
  ]
  edge [
    source 176
    target 107
    type "dominant"
  ]
  edge [
    source 176
    target 175
    type "dominant"
  ]
  edge [
    source 176
    target 179
    type "neutral"
  ]
  edge [
    source 177
    target 178
    type "neutral"
  ]
  edge [
    source 177
    target 184
    type "neutral"
  ]
  edge [
    source 177
    target 185
    type "neutral"
  ]
  edge [
    source 177
    target 187
    type "neutral"
  ]
  edge [
    source 177
    target 180
    type "dominant"
  ]
  edge [
    source 177
    target 183
    type "dominant"
  ]
  edge [
    source 177
    target 199
    type "dominant"
  ]
  edge [
    source 177
    target 202
    type "dominant"
  ]
  edge [
    source 178
    target 153
    type "dominant"
  ]
  edge [
    source 178
    target 184
    type "neutral"
  ]
  edge [
    source 178
    target 198
    type "neutral"
  ]
  edge [
    source 178
    target 180
    type "dominant"
  ]
  edge [
    source 178
    target 288
    type "dominant"
  ]
  edge [
    source 178
    target 396
    type "dominant"
  ]
  edge [
    source 179
    target 102
    type "dominant"
  ]
  edge [
    source 179
    target 175
    type "dominant"
  ]
  edge [
    source 179
    target 337
    type "neutral"
  ]
  edge [
    source 179
    target 198
    type "dominant"
  ]
  edge [
    source 180
    target 58
    type "dominant"
  ]
  edge [
    source 180
    target 175
    type "dominant"
  ]
  edge [
    source 180
    target 185
    type "neutral"
  ]
  edge [
    source 180
    target 202
    type "neutral"
  ]
  edge [
    source 180
    target 321
    type "dominant"
  ]
  edge [
    source 181
    target 176
    type "dominant"
  ]
  edge [
    source 181
    target 405
    type "neutral"
  ]
  edge [
    source 181
    target 319
    type "neutral"
  ]
  edge [
    source 181
    target 182
    type "dominant"
  ]
  edge [
    source 182
    target 175
    type "dominant"
  ]
  edge [
    source 182
    target 319
    type "neutral"
  ]
  edge [
    source 182
    target 277
    type "neutral"
  ]
  edge [
    source 182
    target 414
    type "dominant"
  ]
  edge [
    source 183
    target 379
    type "dominant"
  ]
  edge [
    source 184
    target 11
    type "dominant"
  ]
  edge [
    source 184
    target 144
    type "dominant"
  ]
  edge [
    source 184
    target 180
    type "dominant"
  ]
  edge [
    source 184
    target 198
    type "neutral"
  ]
  edge [
    source 184
    target 219
    type "neutral"
  ]
  edge [
    source 184
    target 202
    type "dominant"
  ]
  edge [
    source 184
    target 203
    type "dominant"
  ]
  edge [
    source 184
    target 288
    type "dominant"
  ]
  edge [
    source 184
    target 396
    type "dominant"
  ]
  edge [
    source 185
    target 202
    type "neutral"
  ]
  edge [
    source 185
    target 187
    type "dominant"
  ]
  edge [
    source 185
    target 319
    type "dominant"
  ]
  edge [
    source 186
    target 21
    type "dominant"
  ]
  edge [
    source 186
    target 112
    type "dominant"
  ]
  edge [
    source 186
    target 177
    type "dominant"
  ]
  edge [
    source 187
    target 128
    type "dominant"
  ]
  edge [
    source 187
    target 180
    type "dominant"
  ]
  edge [
    source 187
    target 183
    type "dominant"
  ]
  edge [
    source 187
    target 327
    type "neutral"
  ]
  edge [
    source 187
    target 202
    type "neutral"
  ]
  edge [
    source 187
    target 330
    type "neutral"
  ]
  edge [
    source 187
    target 288
    type "dominant"
  ]
  edge [
    source 187
    target 396
    type "dominant"
  ]
  edge [
    source 188
    target 189
    type "neutral"
  ]
  edge [
    source 188
    target 212
    type "dominant"
  ]
  edge [
    source 188
    target 355
    type "dominant"
  ]
  edge [
    source 188
    target 411
    type "dominant"
  ]
  edge [
    source 188
    target 442
    type "dominant"
  ]
  edge [
    source 190
    target 130
    type "dominant"
  ]
  edge [
    source 190
    target 188
    type "dominant"
  ]
  edge [
    source 190
    target 245
    type "neutral"
  ]
  edge [
    source 190
    target 417
    type "neutral"
  ]
  edge [
    source 190
    target 418
    type "neutral"
  ]
  edge [
    source 190
    target 382
    type "neutral"
  ]
  edge [
    source 190
    target 419
    type "neutral"
  ]
  edge [
    source 190
    target 407
    type "dominant"
  ]
  edge [
    source 191
    target 188
    type "dominant"
  ]
  edge [
    source 191
    target 205
    type "dominant"
  ]
  edge [
    source 191
    target 241
    type "dominant"
  ]
  edge [
    source 191
    target 319
    type "dominant"
  ]
  edge [
    source 192
    target 193
    type "neutral"
  ]
  edge [
    source 192
    target 194
    type "neutral"
  ]
  edge [
    source 192
    target 196
    type "neutral"
  ]
  edge [
    source 192
    target 342
    type "dominant"
  ]
  edge [
    source 193
    target 196
    type "dominant"
  ]
  edge [
    source 194
    target 15
    type "dominant"
  ]
  edge [
    source 194
    target 290
    type "neutral"
  ]
  edge [
    source 194
    target 399
    type "dominant"
  ]
  edge [
    source 195
    target 100
    type "dominant"
  ]
  edge [
    source 195
    target 192
    type "dominant"
  ]
  edge [
    source 195
    target 278
    type "neutral"
  ]
  edge [
    source 195
    target 426
    type "dominant"
  ]
  edge [
    source 196
    target 425
    type "dominant"
  ]
  edge [
    source 197
    target 63
    type "dominant"
  ]
  edge [
    source 197
    target 143
    type "dominant"
  ]
  edge [
    source 197
    target 192
    type "dominant"
  ]
  edge [
    source 197
    target 332
    type "dominant"
  ]
  edge [
    source 197
    target 398
    type "dominant"
  ]
  edge [
    source 198
    target 144
    type "dominant"
  ]
  edge [
    source 198
    target 202
    type "dominant"
  ]
  edge [
    source 198
    target 239
    type "dominant"
  ]
  edge [
    source 198
    target 288
    type "dominant"
  ]
  edge [
    source 198
    target 337
    type "dominant"
  ]
  edge [
    source 198
    target 437
    type "dominant"
  ]
  edge [
    source 199
    target 200
    type "neutral"
  ]
  edge [
    source 200
    target 217
    type "neutral"
  ]
  edge [
    source 201
    target 9
    type "dominant"
  ]
  edge [
    source 201
    target 108
    type "dominant"
  ]
  edge [
    source 201
    target 199
    type "dominant"
  ]
  edge [
    source 201
    target 298
    type "neutral"
  ]
  edge [
    source 201
    target 429
    type "neutral"
  ]
  edge [
    source 202
    target 72
    type "dominant"
  ]
  edge [
    source 202
    target 77
    type "dominant"
  ]
  edge [
    source 202
    target 199
    type "dominant"
  ]
  edge [
    source 202
    target 396
    type "neutral"
  ]
  edge [
    source 203
    target 199
    type "dominant"
  ]
  edge [
    source 203
    target 288
    type "neutral"
  ]
  edge [
    source 203
    target 287
    type "dominant"
  ]
  edge [
    source 203
    target 296
    type "dominant"
  ]
  edge [
    source 204
    target 373
    type "dominant"
  ]
  edge [
    source 205
    target 24
    type "dominant"
  ]
  edge [
    source 205
    target 204
    type "dominant"
  ]
  edge [
    source 205
    target 206
    type "neutral"
  ]
  edge [
    source 205
    target 241
    type "neutral"
  ]
  edge [
    source 205
    target 242
    type "neutral"
  ]
  edge [
    source 205
    target 256
    type "dominant"
  ]
  edge [
    source 205
    target 301
    type "dominant"
  ]
  edge [
    source 205
    target 311
    type "dominant"
  ]
  edge [
    source 205
    target 315
    type "dominant"
  ]
  edge [
    source 206
    target 204
    type "dominant"
  ]
  edge [
    source 206
    target 312
    type "neutral"
  ]
  edge [
    source 206
    target 242
    type "neutral"
  ]
  edge [
    source 206
    target 311
    type "dominant"
  ]
  edge [
    source 207
    target 204
    type "dominant"
  ]
  edge [
    source 207
    target 311
    type "neutral"
  ]
  edge [
    source 207
    target 373
    type "neutral"
  ]
  edge [
    source 207
    target 242
    type "neutral"
  ]
  edge [
    source 208
    target 204
    type "dominant"
  ]
  edge [
    source 208
    target 294
    type "dominant"
  ]
  edge [
    source 209
    target 10
    type "dominant"
  ]
  edge [
    source 209
    target 85
    type "dominant"
  ]
  edge [
    source 209
    target 110
    type "dominant"
  ]
  edge [
    source 209
    target 260
    type "neutral"
  ]
  edge [
    source 209
    target 293
    type "dominant"
  ]
  edge [
    source 209
    target 317
    type "dominant"
  ]
  edge [
    source 209
    target 335
    type "dominant"
  ]
  edge [
    source 209
    target 343
    type "dominant"
  ]
  edge [
    source 209
    target 401
    type "dominant"
  ]
  edge [
    source 210
    target 21
    type "dominant"
  ]
  edge [
    source 210
    target 24
    type "dominant"
  ]
  edge [
    source 210
    target 205
    type "dominant"
  ]
  edge [
    source 210
    target 315
    type "neutral"
  ]
  edge [
    source 210
    target 341
    type "neutral"
  ]
  edge [
    source 210
    target 301
    type "dominant"
  ]
  edge [
    source 210
    target 402
    type "dominant"
  ]
  edge [
    source 211
    target 417
    type "neutral"
  ]
  edge [
    source 211
    target 424
    type "neutral"
  ]
  edge [
    source 211
    target 251
    type "neutral"
  ]
  edge [
    source 211
    target 253
    type "dominant"
  ]
  edge [
    source 212
    target 214
    type "neutral"
  ]
  edge [
    source 212
    target 215
    type "neutral"
  ]
  edge [
    source 212
    target 292
    type "dominant"
  ]
  edge [
    source 213
    target 31
    type "dominant"
  ]
  edge [
    source 213
    target 47
    type "dominant"
  ]
  edge [
    source 213
    target 149
    type "dominant"
  ]
  edge [
    source 213
    target 189
    type "dominant"
  ]
  edge [
    source 213
    target 212
    type "dominant"
  ]
  edge [
    source 213
    target 214
    type "dominant"
  ]
  edge [
    source 213
    target 252
    type "dominant"
  ]
  edge [
    source 213
    target 292
    type "dominant"
  ]
  edge [
    source 213
    target 355
    type "dominant"
  ]
  edge [
    source 213
    target 392
    type "dominant"
  ]
  edge [
    source 214
    target 47
    type "dominant"
  ]
  edge [
    source 214
    target 93
    type "dominant"
  ]
  edge [
    source 214
    target 150
    type "dominant"
  ]
  edge [
    source 214
    target 363
    type "neutral"
  ]
  edge [
    source 214
    target 232
    type "neutral"
  ]
  edge [
    source 214
    target 261
    type "neutral"
  ]
  edge [
    source 214
    target 215
    type "dominant"
  ]
  edge [
    source 214
    target 389
    type "dominant"
  ]
  edge [
    source 214
    target 390
    type "dominant"
  ]
  edge [
    source 215
    target 292
    type "neutral"
  ]
  edge [
    source 216
    target 193
    type "dominant"
  ]
  edge [
    source 216
    target 278
    type "neutral"
  ]
  edge [
    source 216
    target 279
    type "neutral"
  ]
  edge [
    source 216
    target 280
    type "neutral"
  ]
  edge [
    source 216
    target 442
    type "dominant"
  ]
  edge [
    source 217
    target 119
    type "dominant"
  ]
  edge [
    source 217
    target 193
    type "dominant"
  ]
  edge [
    source 217
    target 333
    type "neutral"
  ]
  edge [
    source 217
    target 266
    type "dominant"
  ]
  edge [
    source 217
    target 434
    type "dominant"
  ]
  edge [
    source 217
    target 442
    type "dominant"
  ]
  edge [
    source 218
    target 25
    type "dominant"
  ]
  edge [
    source 218
    target 143
    type "dominant"
  ]
  edge [
    source 218
    target 193
    type "dominant"
  ]
  edge [
    source 218
    target 217
    type "dominant"
  ]
  edge [
    source 219
    target 38
    type "dominant"
  ]
  edge [
    source 219
    target 81
    type "dominant"
  ]
  edge [
    source 219
    target 103
    type "dominant"
  ]
  edge [
    source 219
    target 255
    type "neutral"
  ]
  edge [
    source 219
    target 254
    type "dominant"
  ]
  edge [
    source 220
    target 223
    type "neutral"
  ]
  edge [
    source 221
    target 220
    type "dominant"
  ]
  edge [
    source 222
    target 220
    type "dominant"
  ]
  edge [
    source 222
    target 323
    type "neutral"
  ]
  edge [
    source 222
    target 347
    type "neutral"
  ]
  edge [
    source 222
    target 346
    type "dominant"
  ]
  edge [
    source 223
    target 10
    type "dominant"
  ]
  edge [
    source 223
    target 406
    type "neutral"
  ]
  edge [
    source 225
    target 226
    type "neutral"
  ]
  edge [
    source 225
    target 227
    type "neutral"
  ]
  edge [
    source 225
    target 228
    type "neutral"
  ]
  edge [
    source 226
    target 290
    type "neutral"
  ]
  edge [
    source 226
    target 355
    type "neutral"
  ]
  edge [
    source 226
    target 292
    type "neutral"
  ]
  edge [
    source 226
    target 291
    type "dominant"
  ]
  edge [
    source 227
    target 363
    type "neutral"
  ]
  edge [
    source 227
    target 229
    type "neutral"
  ]
  edge [
    source 227
    target 230
    type "neutral"
  ]
  edge [
    source 227
    target 322
    type "dominant"
  ]
  edge [
    source 227
    target 384
    type "dominant"
  ]
  edge [
    source 229
    target 87
    type "dominant"
  ]
  edge [
    source 229
    target 225
    type "dominant"
  ]
  edge [
    source 229
    target 363
    type "neutral"
  ]
  edge [
    source 229
    target 322
    type "dominant"
  ]
  edge [
    source 229
    target 364
    type "dominant"
  ]
  edge [
    source 230
    target 87
    type "dominant"
  ]
  edge [
    source 230
    target 225
    type "dominant"
  ]
  edge [
    source 230
    target 363
    type "neutral"
  ]
  edge [
    source 230
    target 364
    type "dominant"
  ]
  edge [
    source 231
    target 316
    type "dominant"
  ]
  edge [
    source 231
    target 400
    type "dominant"
  ]
  edge [
    source 232
    target 47
    type "dominant"
  ]
  edge [
    source 232
    target 247
    type "neutral"
  ]
  edge [
    source 232
    target 447
    type "neutral"
  ]
  edge [
    source 232
    target 432
    type "dominant"
  ]
  edge [
    source 234
    target 11
    type "dominant"
  ]
  edge [
    source 234
    target 189
    type "dominant"
  ]
  edge [
    source 234
    target 207
    type "dominant"
  ]
  edge [
    source 234
    target 233
    type "dominant"
  ]
  edge [
    source 234
    target 243
    type "neutral"
  ]
  edge [
    source 234
    target 247
    type "neutral"
  ]
  edge [
    source 234
    target 248
    type "neutral"
  ]
  edge [
    source 234
    target 242
    type "dominant"
  ]
  edge [
    source 234
    target 303
    type "dominant"
  ]
  edge [
    source 234
    target 318
    type "dominant"
  ]
  edge [
    source 234
    target 374
    type "dominant"
  ]
  edge [
    source 235
    target 233
    type "dominant"
  ]
  edge [
    source 236
    target 237
    type "neutral"
  ]
  edge [
    source 236
    target 352
    type "dominant"
  ]
  edge [
    source 237
    target 244
    type "neutral"
  ]
  edge [
    source 237
    target 373
    type "neutral"
  ]
  edge [
    source 237
    target 374
    type "neutral"
  ]
  edge [
    source 237
    target 266
    type "dominant"
  ]
  edge [
    source 237
    target 335
    type "dominant"
  ]
  edge [
    source 237
    target 348
    type "dominant"
  ]
  edge [
    source 237
    target 366
    type "dominant"
  ]
  edge [
    source 237
    target 367
    type "dominant"
  ]
  edge [
    source 238
    target 236
    type "dominant"
  ]
  edge [
    source 238
    target 244
    type "dominant"
  ]
  edge [
    source 238
    target 264
    type "dominant"
  ]
  edge [
    source 238
    target 304
    type "dominant"
  ]
  edge [
    source 239
    target 346
    type "neutral"
  ]
  edge [
    source 239
    target 241
    type "dominant"
  ]
  edge [
    source 239
    target 437
    type "dominant"
  ]
  edge [
    source 240
    target 63
    type "dominant"
  ]
  edge [
    source 240
    target 183
    type "dominant"
  ]
  edge [
    source 240
    target 239
    type "dominant"
  ]
  edge [
    source 240
    target 333
    type "dominant"
  ]
  edge [
    source 241
    target 320
    type "neutral"
  ]
  edge [
    source 241
    target 256
    type "dominant"
  ]
  edge [
    source 242
    target 311
    type "neutral"
  ]
  edge [
    source 242
    target 400
    type "dominant"
  ]
  edge [
    source 242
    target 403
    type "dominant"
  ]
  edge [
    source 243
    target 67
    type "dominant"
  ]
  edge [
    source 243
    target 294
    type "neutral"
  ]
  edge [
    source 243
    target 316
    type "neutral"
  ]
  edge [
    source 243
    target 318
    type "neutral"
  ]
  edge [
    source 244
    target 234
    type "dominant"
  ]
  edge [
    source 244
    target 304
    type "neutral"
  ]
  edge [
    source 244
    target 247
    type "neutral"
  ]
  edge [
    source 244
    target 340
    type "dominant"
  ]
  edge [
    source 245
    target 234
    type "dominant"
  ]
  edge [
    source 246
    target 234
    type "dominant"
  ]
  edge [
    source 246
    target 248
    type "dominant"
  ]
  edge [
    source 246
    target 355
    type "dominant"
  ]
  edge [
    source 247
    target 67
    type "dominant"
  ]
  edge [
    source 247
    target 243
    type "dominant"
  ]
  edge [
    source 247
    target 304
    type "neutral"
  ]
  edge [
    source 247
    target 265
    type "dominant"
  ]
  edge [
    source 247
    target 303
    type "dominant"
  ]
  edge [
    source 247
    target 307
    type "dominant"
  ]
  edge [
    source 247
    target 308
    type "dominant"
  ]
  edge [
    source 247
    target 310
    type "dominant"
  ]
  edge [
    source 247
    target 340
    type "dominant"
  ]
  edge [
    source 247
    target 427
    type "dominant"
  ]
  edge [
    source 247
    target 447
    type "dominant"
  ]
  edge [
    source 248
    target 207
    type "dominant"
  ]
  edge [
    source 249
    target 250
    type "neutral"
  ]
  edge [
    source 249
    target 252
    type "neutral"
  ]
  edge [
    source 250
    target 149
    type "dominant"
  ]
  edge [
    source 250
    target 330
    type "neutral"
  ]
  edge [
    source 250
    target 376
    type "dominant"
  ]
  edge [
    source 250
    target 411
    type "dominant"
  ]
  edge [
    source 251
    target 249
    type "dominant"
  ]
  edge [
    source 251
    target 253
    type "dominant"
  ]
  edge [
    source 252
    target 328
    type "neutral"
  ]
  edge [
    source 252
    target 444
    type "neutral"
  ]
  edge [
    source 252
    target 392
    type "dominant"
  ]
  edge [
    source 253
    target 249
    type "dominant"
  ]
  edge [
    source 253
    target 424
    type "neutral"
  ]
  edge [
    source 253
    target 417
    type "dominant"
  ]
  edge [
    source 254
    target 130
    type "dominant"
  ]
  edge [
    source 254
    target 255
    type "neutral"
  ]
  edge [
    source 254
    target 256
    type "neutral"
  ]
  edge [
    source 254
    target 302
    type "dominant"
  ]
  edge [
    source 255
    target 153
    type "dominant"
  ]
  edge [
    source 256
    target 247
    type "dominant"
  ]
  edge [
    source 257
    target 258
    type "neutral"
  ]
  edge [
    source 257
    target 259
    type "neutral"
  ]
  edge [
    source 257
    target 260
    type "neutral"
  ]
  edge [
    source 257
    target 354
    type "dominant"
  ]
  edge [
    source 258
    target 59
    type "dominant"
  ]
  edge [
    source 258
    target 118
    type "dominant"
  ]
  edge [
    source 258
    target 353
    type "neutral"
  ]
  edge [
    source 258
    target 259
    type "neutral"
  ]
  edge [
    source 258
    target 354
    type "neutral"
  ]
  edge [
    source 258
    target 260
    type "dominant"
  ]
  edge [
    source 259
    target 353
    type "neutral"
  ]
  edge [
    source 259
    target 354
    type "neutral"
  ]
  edge [
    source 260
    target 76
    type "dominant"
  ]
  edge [
    source 261
    target 227
    type "dominant"
  ]
  edge [
    source 261
    target 257
    type "dominant"
  ]
  edge [
    source 261
    target 363
    type "neutral"
  ]
  edge [
    source 261
    target 408
    type "neutral"
  ]
  edge [
    source 261
    target 292
    type "neutral"
  ]
  edge [
    source 261
    target 342
    type "neutral"
  ]
  edge [
    source 261
    target 425
    type "dominant"
  ]
  edge [
    source 262
    target 263
    type "neutral"
  ]
  edge [
    source 262
    target 264
    type "neutral"
  ]
  edge [
    source 264
    target 291
    type "neutral"
  ]
  edge [
    source 264
    target 426
    type "neutral"
  ]
  edge [
    source 265
    target 267
    type "neutral"
  ]
  edge [
    source 265
    target 318
    type "dominant"
  ]
  edge [
    source 265
    target 388
    type "dominant"
  ]
  edge [
    source 266
    target 265
    type "dominant"
  ]
  edge [
    source 266
    target 432
    type "neutral"
  ]
  edge [
    source 266
    target 290
    type "dominant"
  ]
  edge [
    source 266
    target 294
    type "dominant"
  ]
  edge [
    source 266
    target 433
    type "dominant"
  ]
  edge [
    source 267
    target 308
    type "neutral"
  ]
  edge [
    source 267
    target 310
    type "neutral"
  ]
  edge [
    source 269
    target 67
    type "dominant"
  ]
  edge [
    source 269
    target 238
    type "dominant"
  ]
  edge [
    source 269
    target 244
    type "dominant"
  ]
  edge [
    source 269
    target 247
    type "dominant"
  ]
  edge [
    source 269
    target 268
    type "dominant"
  ]
  edge [
    source 269
    target 303
    type "dominant"
  ]
  edge [
    source 269
    target 340
    type "dominant"
  ]
  edge [
    source 270
    target 201
    type "dominant"
  ]
  edge [
    source 270
    target 414
    type "dominant"
  ]
  edge [
    source 270
    target 429
    type "dominant"
  ]
  edge [
    source 272
    target 183
    type "dominant"
  ]
  edge [
    source 272
    target 271
    type "dominant"
  ]
  edge [
    source 273
    target 58
    type "dominant"
  ]
  edge [
    source 273
    target 97
    type "dominant"
  ]
  edge [
    source 273
    target 183
    type "dominant"
  ]
  edge [
    source 273
    target 271
    type "dominant"
  ]
  edge [
    source 274
    target 39
    type "dominant"
  ]
  edge [
    source 274
    target 275
    type "neutral"
  ]
  edge [
    source 274
    target 379
    type "dominant"
  ]
  edge [
    source 274
    target 441
    type "dominant"
  ]
  edge [
    source 275
    target 39
    type "dominant"
  ]
  edge [
    source 275
    target 441
    type "neutral"
  ]
  edge [
    source 276
    target 58
    type "dominant"
  ]
  edge [
    source 276
    target 183
    type "dominant"
  ]
  edge [
    source 277
    target 58
    type "dominant"
  ]
  edge [
    source 277
    target 181
    type "dominant"
  ]
  edge [
    source 277
    target 319
    type "neutral"
  ]
  edge [
    source 278
    target 279
    type "neutral"
  ]
  edge [
    source 278
    target 280
    type "neutral"
  ]
  edge [
    source 279
    target 280
    type "neutral"
  ]
  edge [
    source 279
    target 345
    type "dominant"
  ]
  edge [
    source 280
    target 294
    type "dominant"
  ]
  edge [
    source 280
    target 345
    type "dominant"
  ]
  edge [
    source 281
    target 216
    type "dominant"
  ]
  edge [
    source 281
    target 278
    type "dominant"
  ]
  edge [
    source 281
    target 279
    type "dominant"
  ]
  edge [
    source 281
    target 280
    type "dominant"
  ]
  edge [
    source 282
    target 87
    type "dominant"
  ]
  edge [
    source 282
    target 228
    type "dominant"
  ]
  edge [
    source 282
    target 334
    type "dominant"
  ]
  edge [
    source 282
    target 434
    type "dominant"
  ]
  edge [
    source 282
    target 441
    type "dominant"
  ]
  edge [
    source 283
    target 282
    type "dominant"
  ]
  edge [
    source 283
    target 285
    type "neutral"
  ]
  edge [
    source 283
    target 356
    type "dominant"
  ]
  edge [
    source 284
    target 282
    type "dominant"
  ]
  edge [
    source 284
    target 322
    type "dominant"
  ]
  edge [
    source 285
    target 250
    type "dominant"
  ]
  edge [
    source 285
    target 282
    type "dominant"
  ]
  edge [
    source 285
    target 295
    type "dominant"
  ]
  edge [
    source 285
    target 444
    type "dominant"
  ]
  edge [
    source 286
    target 305
    type "dominant"
  ]
  edge [
    source 286
    target 410
    type "dominant"
  ]
  edge [
    source 288
    target 153
    type "dominant"
  ]
  edge [
    source 289
    target 203
    type "dominant"
  ]
  edge [
    source 289
    target 288
    type "dominant"
  ]
  edge [
    source 289
    target 331
    type "neutral"
  ]
  edge [
    source 290
    target 291
    type "neutral"
  ]
  edge [
    source 291
    target 355
    type "dominant"
  ]
  edge [
    source 292
    target 45
    type "dominant"
  ]
  edge [
    source 292
    target 47
    type "dominant"
  ]
  edge [
    source 292
    target 290
    type "dominant"
  ]
  edge [
    source 292
    target 291
    type "dominant"
  ]
  edge [
    source 292
    target 416
    type "neutral"
  ]
  edge [
    source 292
    target 342
    type "neutral"
  ]
  edge [
    source 293
    target 83
    type "dominant"
  ]
  edge [
    source 293
    target 367
    type "dominant"
  ]
  edge [
    source 293
    target 373
    type "dominant"
  ]
  edge [
    source 293
    target 411
    type "dominant"
  ]
  edge [
    source 295
    target 195
    type "dominant"
  ]
  edge [
    source 295
    target 294
    type "dominant"
  ]
  edge [
    source 295
    target 312
    type "dominant"
  ]
  edge [
    source 295
    target 345
    type "dominant"
  ]
  edge [
    source 296
    target 297
    type "neutral"
  ]
  edge [
    source 296
    target 299
    type "neutral"
  ]
  edge [
    source 296
    target 389
    type "dominant"
  ]
  edge [
    source 297
    target 299
    type "neutral"
  ]
  edge [
    source 297
    target 347
    type "dominant"
  ]
  edge [
    source 297
    target 378
    type "dominant"
  ]
  edge [
    source 297
    target 442
    type "dominant"
  ]
  edge [
    source 298
    target 63
    type "dominant"
  ]
  edge [
    source 298
    target 296
    type "dominant"
  ]
  edge [
    source 299
    target 248
    type "dominant"
  ]
  edge [
    source 300
    target 295
    type "dominant"
  ]
  edge [
    source 301
    target 235
    type "dominant"
  ]
  edge [
    source 301
    target 295
    type "dominant"
  ]
  edge [
    source 301
    target 381
    type "dominant"
  ]
  edge [
    source 303
    target 243
    type "dominant"
  ]
  edge [
    source 303
    target 384
    type "dominant"
  ]
  edge [
    source 304
    target 67
    type "dominant"
  ]
  edge [
    source 304
    target 303
    type "dominant"
  ]
  edge [
    source 304
    target 340
    type "neutral"
  ]
  edge [
    source 304
    target 307
    type "dominant"
  ]
  edge [
    source 304
    target 345
    type "dominant"
  ]
  edge [
    source 304
    target 447
    type "dominant"
  ]
  edge [
    source 306
    target 161
    type "dominant"
  ]
  edge [
    source 306
    target 305
    type "dominant"
  ]
  edge [
    source 306
    target 343
    type "dominant"
  ]
  edge [
    source 306
    target 384
    type "dominant"
  ]
  edge [
    source 306
    target 434
    type "dominant"
  ]
  edge [
    source 307
    target 45
    type "dominant"
  ]
  edge [
    source 308
    target 307
    type "dominant"
  ]
  edge [
    source 308
    target 310
    type "neutral"
  ]
  edge [
    source 308
    target 454
    type "dominant"
  ]
  edge [
    source 309
    target 248
    type "dominant"
  ]
  edge [
    source 309
    target 307
    type "dominant"
  ]
  edge [
    source 310
    target 54
    type "dominant"
  ]
  edge [
    source 310
    target 121
    type "dominant"
  ]
  edge [
    source 310
    target 206
    type "dominant"
  ]
  edge [
    source 310
    target 243
    type "dominant"
  ]
  edge [
    source 310
    target 307
    type "dominant"
  ]
  edge [
    source 312
    target 242
    type "dominant"
  ]
  edge [
    source 312
    target 311
    type "dominant"
  ]
  edge [
    source 312
    target 400
    type "neutral"
  ]
  edge [
    source 312
    target 372
    type "neutral"
  ]
  edge [
    source 313
    target 242
    type "dominant"
  ]
  edge [
    source 313
    target 311
    type "dominant"
  ]
  edge [
    source 313
    target 404
    type "neutral"
  ]
  edge [
    source 313
    target 403
    type "dominant"
  ]
  edge [
    source 314
    target 206
    type "dominant"
  ]
  edge [
    source 314
    target 311
    type "dominant"
  ]
  edge [
    source 315
    target 301
    type "dominant"
  ]
  edge [
    source 315
    target 311
    type "dominant"
  ]
  edge [
    source 315
    target 341
    type "neutral"
  ]
  edge [
    source 315
    target 385
    type "dominant"
  ]
  edge [
    source 317
    target 243
    type "dominant"
  ]
  edge [
    source 317
    target 304
    type "dominant"
  ]
  edge [
    source 317
    target 392
    type "neutral"
  ]
  edge [
    source 318
    target 248
    type "dominant"
  ]
  edge [
    source 318
    target 266
    type "dominant"
  ]
  edge [
    source 318
    target 338
    type "dominant"
  ]
  edge [
    source 319
    target 126
    type "dominant"
  ]
  edge [
    source 319
    target 152
    type "dominant"
  ]
  edge [
    source 319
    target 405
    type "neutral"
  ]
  edge [
    source 319
    target 457
    type "dominant"
  ]
  edge [
    source 320
    target 127
    type "dominant"
  ]
  edge [
    source 320
    target 167
    type "dominant"
  ]
  edge [
    source 320
    target 168
    type "dominant"
  ]
  edge [
    source 320
    target 191
    type "dominant"
  ]
  edge [
    source 320
    target 252
    type "dominant"
  ]
  edge [
    source 320
    target 319
    type "dominant"
  ]
  edge [
    source 321
    target 272
    type "dominant"
  ]
  edge [
    source 321
    target 278
    type "dominant"
  ]
  edge [
    source 323
    target 209
    type "dominant"
  ]
  edge [
    source 323
    target 256
    type "dominant"
  ]
  edge [
    source 323
    target 325
    type "neutral"
  ]
  edge [
    source 323
    target 407
    type "neutral"
  ]
  edge [
    source 323
    target 424
    type "dominant"
  ]
  edge [
    source 324
    target 325
    type "neutral"
  ]
  edge [
    source 324
    target 326
    type "neutral"
  ]
  edge [
    source 324
    target 457
    type "dominant"
  ]
  edge [
    source 326
    target 285
    type "dominant"
  ]
  edge [
    source 327
    target 329
    type "neutral"
  ]
  edge [
    source 327
    target 330
    type "neutral"
  ]
  edge [
    source 328
    target 327
    type "dominant"
  ]
  edge [
    source 328
    target 330
    type "neutral"
  ]
  edge [
    source 328
    target 329
    type "dominant"
  ]
  edge [
    source 328
    target 392
    type "dominant"
  ]
  edge [
    source 328
    target 457
    type "dominant"
  ]
  edge [
    source 329
    target 187
    type "dominant"
  ]
  edge [
    source 329
    target 330
    type "neutral"
  ]
  edge [
    source 330
    target 34
    type "dominant"
  ]
  edge [
    source 330
    target 376
    type "dominant"
  ]
  edge [
    source 330
    target 379
    type "dominant"
  ]
  edge [
    source 331
    target 76
    type "dominant"
  ]
  edge [
    source 331
    target 252
    type "dominant"
  ]
  edge [
    source 331
    target 260
    type "dominant"
  ]
  edge [
    source 331
    target 372
    type "dominant"
  ]
  edge [
    source 331
    target 424
    type "dominant"
  ]
  edge [
    source 332
    target 200
    type "dominant"
  ]
  edge [
    source 333
    target 63
    type "dominant"
  ]
  edge [
    source 333
    target 200
    type "dominant"
  ]
  edge [
    source 333
    target 408
    type "dominant"
  ]
  edge [
    source 333
    target 434
    type "dominant"
  ]
  edge [
    source 334
    target 200
    type "dominant"
  ]
  edge [
    source 334
    target 266
    type "dominant"
  ]
  edge [
    source 335
    target 350
    type "neutral"
  ]
  edge [
    source 335
    target 351
    type "neutral"
  ]
  edge [
    source 335
    target 349
    type "dominant"
  ]
  edge [
    source 335
    target 454
    type "dominant"
  ]
  edge [
    source 336
    target 31
    type "dominant"
  ]
  edge [
    source 336
    target 292
    type "dominant"
  ]
  edge [
    source 337
    target 108
    type "dominant"
  ]
  edge [
    source 337
    target 283
    type "dominant"
  ]
  edge [
    source 337
    target 414
    type "dominant"
  ]
  edge [
    source 338
    target 293
    type "dominant"
  ]
  edge [
    source 338
    target 367
    type "dominant"
  ]
  edge [
    source 340
    target 12
    type "dominant"
  ]
  edge [
    source 340
    target 19
    type "dominant"
  ]
  edge [
    source 340
    target 65
    type "dominant"
  ]
  edge [
    source 340
    target 67
    type "dominant"
  ]
  edge [
    source 341
    target 386
    type "dominant"
  ]
  edge [
    source 342
    target 169
    type "dominant"
  ]
  edge [
    source 342
    target 291
    type "dominant"
  ]
  edge [
    source 342
    target 416
    type "dominant"
  ]
  edge [
    source 344
    target 26
    type "dominant"
  ]
  edge [
    source 344
    target 343
    type "dominant"
  ]
  edge [
    source 345
    target 278
    type "dominant"
  ]
  edge [
    source 345
    target 343
    type "dominant"
  ]
  edge [
    source 346
    target 347
    type "dominant"
  ]
  edge [
    source 348
    target 335
    type "dominant"
  ]
  edge [
    source 348
    target 349
    type "neutral"
  ]
  edge [
    source 348
    target 350
    type "neutral"
  ]
  edge [
    source 348
    target 351
    type "neutral"
  ]
  edge [
    source 348
    target 352
    type "neutral"
  ]
  edge [
    source 349
    target 350
    type "neutral"
  ]
  edge [
    source 349
    target 351
    type "neutral"
  ]
  edge [
    source 350
    target 351
    type "neutral"
  ]
  edge [
    source 351
    target 293
    type "dominant"
  ]
  edge [
    source 351
    target 352
    type "neutral"
  ]
  edge [
    source 351
    target 366
    type "dominant"
  ]
  edge [
    source 354
    target 260
    type "dominant"
  ]
  edge [
    source 354
    target 353
    type "dominant"
  ]
  edge [
    source 356
    target 372
    type "dominant"
  ]
  edge [
    source 356
    target 444
    type "dominant"
  ]
  edge [
    source 357
    target 358
    type "neutral"
  ]
  edge [
    source 357
    target 364
    type "dominant"
  ]
  edge [
    source 357
    target 454
    type "dominant"
  ]
  edge [
    source 358
    target 364
    type "neutral"
  ]
  edge [
    source 359
    target 357
    type "dominant"
  ]
  edge [
    source 359
    target 445
    type "dominant"
  ]
  edge [
    source 361
    target 252
    type "dominant"
  ]
  edge [
    source 361
    target 360
    type "dominant"
  ]
  edge [
    source 362
    target 308
    type "dominant"
  ]
  edge [
    source 363
    target 408
    type "dominant"
  ]
  edge [
    source 363
    target 416
    type "dominant"
  ]
  edge [
    source 364
    target 366
    type "neutral"
  ]
  edge [
    source 364
    target 367
    type "neutral"
  ]
  edge [
    source 365
    target 358
    type "dominant"
  ]
  edge [
    source 365
    target 364
    type "dominant"
  ]
  edge [
    source 368
    target 293
    type "dominant"
  ]
  edge [
    source 369
    target 238
    type "dominant"
  ]
  edge [
    source 369
    target 244
    type "dominant"
  ]
  edge [
    source 370
    target 237
    type "dominant"
  ]
  edge [
    source 371
    target 237
    type "dominant"
  ]
  edge [
    source 372
    target 237
    type "dominant"
  ]
  edge [
    source 372
    target 400
    type "neutral"
  ]
  edge [
    source 372
    target 444
    type "neutral"
  ]
  edge [
    source 374
    target 432
    type "neutral"
  ]
  edge [
    source 375
    target 250
    type "dominant"
  ]
  edge [
    source 377
    target 100
    type "dominant"
  ]
  edge [
    source 377
    target 195
    type "dominant"
  ]
  edge [
    source 378
    target 380
    type "neutral"
  ]
  edge [
    source 379
    target 173
    type "dominant"
  ]
  edge [
    source 379
    target 378
    type "dominant"
  ]
  edge [
    source 379
    target 440
    type "neutral"
  ]
  edge [
    source 379
    target 441
    type "neutral"
  ]
  edge [
    source 379
    target 380
    type "dominant"
  ]
  edge [
    source 379
    target 386
    type "dominant"
  ]
  edge [
    source 379
    target 387
    type "dominant"
  ]
  edge [
    source 379
    target 394
    type "dominant"
  ]
  edge [
    source 379
    target 399
    type "dominant"
  ]
  edge [
    source 379
    target 410
    type "dominant"
  ]
  edge [
    source 381
    target 245
    type "dominant"
  ]
  edge [
    source 381
    target 422
    type "neutral"
  ]
  edge [
    source 381
    target 423
    type "neutral"
  ]
  edge [
    source 381
    target 382
    type "dominant"
  ]
  edge [
    source 381
    target 407
    type "dominant"
  ]
  edge [
    source 382
    target 245
    type "dominant"
  ]
  edge [
    source 382
    target 407
    type "neutral"
  ]
  edge [
    source 382
    target 418
    type "neutral"
  ]
  edge [
    source 382
    target 419
    type "neutral"
  ]
  edge [
    source 383
    target 235
    type "dominant"
  ]
  edge [
    source 385
    target 332
    type "dominant"
  ]
  edge [
    source 386
    target 332
    type "dominant"
  ]
  edge [
    source 387
    target 194
    type "dominant"
  ]
  edge [
    source 387
    target 399
    type "neutral"
  ]
  edge [
    source 387
    target 410
    type "neutral"
  ]
  edge [
    source 389
    target 388
    type "dominant"
  ]
  edge [
    source 389
    target 456
    type "dominant"
  ]
  edge [
    source 393
    target 387
    type "dominant"
  ]
  edge [
    source 393
    target 399
    type "dominant"
  ]
  edge [
    source 393
    target 410
    type "dominant"
  ]
  edge [
    source 394
    target 383
    type "dominant"
  ]
  edge [
    source 394
    target 393
    type "dominant"
  ]
  edge [
    source 394
    target 395
    type "neutral"
  ]
  edge [
    source 394
    target 410
    type "dominant"
  ]
  edge [
    source 395
    target 239
    type "dominant"
  ]
  edge [
    source 395
    target 393
    type "dominant"
  ]
  edge [
    source 395
    target 430
    type "neutral"
  ]
  edge [
    source 395
    target 441
    type "dominant"
  ]
  edge [
    source 395
    target 442
    type "dominant"
  ]
  edge [
    source 396
    target 256
    type "dominant"
  ]
  edge [
    source 396
    target 427
    type "dominant"
  ]
  edge [
    source 400
    target 342
    type "dominant"
  ]
  edge [
    source 401
    target 228
    type "dominant"
  ]
  edge [
    source 401
    target 389
    type "dominant"
  ]
  edge [
    source 401
    target 427
    type "dominant"
  ]
  edge [
    source 402
    target 22
    type "dominant"
  ]
  edge [
    source 402
    target 110
    type "dominant"
  ]
  edge [
    source 402
    target 208
    type "dominant"
  ]
  edge [
    source 404
    target 403
    type "dominant"
  ]
  edge [
    source 405
    target 191
    type "dominant"
  ]
  edge [
    source 406
    target 347
    type "dominant"
  ]
  edge [
    source 407
    target 211
    type "dominant"
  ]
  edge [
    source 407
    target 417
    type "neutral"
  ]
  edge [
    source 407
    target 419
    type "dominant"
  ]
  edge [
    source 408
    target 310
    type "dominant"
  ]
  edge [
    source 409
    target 25
    type "dominant"
  ]
  edge [
    source 409
    target 224
    type "dominant"
  ]
  edge [
    source 409
    target 248
    type "dominant"
  ]
  edge [
    source 410
    target 399
    type "dominant"
  ]
  edge [
    source 410
    target 408
    type "dominant"
  ]
  edge [
    source 411
    target 407
    type "dominant"
  ]
  edge [
    source 411
    target 445
    type "dominant"
  ]
  edge [
    source 412
    target 411
    type "dominant"
  ]
  edge [
    source 412
    target 439
    type "dominant"
  ]
  edge [
    source 413
    target 411
    type "dominant"
  ]
  edge [
    source 413
    target 437
    type "dominant"
  ]
  edge [
    source 415
    target 181
    type "dominant"
  ]
  edge [
    source 415
    target 182
    type "dominant"
  ]
  edge [
    source 415
    target 414
    type "dominant"
  ]
  edge [
    source 416
    target 261
    type "dominant"
  ]
  edge [
    source 418
    target 444
    type "neutral"
  ]
  edge [
    source 418
    target 419
    type "neutral"
  ]
  edge [
    source 419
    target 355
    type "dominant"
  ]
  edge [
    source 420
    target 10
    type "dominant"
  ]
  edge [
    source 421
    target 10
    type "dominant"
  ]
  edge [
    source 422
    target 423
    type "neutral"
  ]
  edge [
    source 423
    target 380
    type "dominant"
  ]
  edge [
    source 424
    target 251
    type "dominant"
  ]
  edge [
    source 427
    target 336
    type "dominant"
  ]
  edge [
    source 428
    target 336
    type "dominant"
  ]
  edge [
    source 429
    target 155
    type "dominant"
  ]
  edge [
    source 429
    target 181
    type "dominant"
  ]
  edge [
    source 429
    target 242
    type "dominant"
  ]
  edge [
    source 429
    target 346
    type "dominant"
  ]
  edge [
    source 429
    target 387
    type "dominant"
  ]
  edge [
    source 429
    target 457
    type "dominant"
  ]
  edge [
    source 430
    target 347
    type "dominant"
  ]
  edge [
    source 430
    target 379
    type "dominant"
  ]
  edge [
    source 430
    target 442
    type "dominant"
  ]
  edge [
    source 431
    target 266
    type "dominant"
  ]
  edge [
    source 434
    target 46
    type "dominant"
  ]
  edge [
    source 435
    target 434
    type "dominant"
  ]
  edge [
    source 435
    target 441
    type "dominant"
  ]
  edge [
    source 436
    target 426
    type "dominant"
  ]
  edge [
    source 438
    target 367
    type "dominant"
  ]
  edge [
    source 438
    target 437
    type "dominant"
  ]
  edge [
    source 439
    target 427
    type "dominant"
  ]
  edge [
    source 440
    target 275
    type "dominant"
  ]
  edge [
    source 440
    target 387
    type "dominant"
  ]
  edge [
    source 440
    target 430
    type "dominant"
  ]
  edge [
    source 440
    target 441
    type "neutral"
  ]
  edge [
    source 443
    target 442
    type "dominant"
  ]
  edge [
    source 444
    target 382
    type "dominant"
  ]
  edge [
    source 444
    target 419
    type "dominant"
  ]
  edge [
    source 446
    target 445
    type "dominant"
  ]
  edge [
    source 447
    target 445
    type "dominant"
  ]
  edge [
    source 448
    target 318
    type "dominant"
  ]
  edge [
    source 449
    target 3
    type "dominant"
  ]
  edge [
    source 449
    target 289
    type "dominant"
  ]
  edge [
    source 450
    target 340
    type "dominant"
  ]
  edge [
    source 451
    target 46
    type "dominant"
  ]
  edge [
    source 455
    target 428
    type "dominant"
  ]
  edge [
    source 456
    target 367
    type "dominant"
  ]
]
