graph [
  directed 1
  node [
    id 0
    label "1"
    community 0
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 1
    label "191"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 2
    label "285"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 3
    label "3"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 4
    label "65"
    community 0
    race "black"
    sex "missing"
    grade 12
  ]
  node [
    id 5
    label "111"
    community 0
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 6
    label "223"
    community 1
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 7
    label "260"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 8
    label "379"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 9
    label "423"
    community 2
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 10
    label "4"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 11
    label "91"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 12
    label "119"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 13
    label "170"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 14
    label "174"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 15
    label "193"
    community 0
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 16
    label "212"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 17
    label "395"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 18
    label "438"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 19
    label "444"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 20
    label "5"
    community 0
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 21
    label "263"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 22
    label "6"
    community 3
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 23
    label "400"
    community 3
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 24
    label "7"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 25
    label "132"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 26
    label "165"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 27
    label "211"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 28
    label "8"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 29
    label "51"
    community 0
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 30
    label "307"
    community 4
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 31
    label "9"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 32
    label "115"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 33
    label "152"
    community 3
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 34
    label "264"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 35
    label "280"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 36
    label "12"
    community 5
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 37
    label "29"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 38
    label "210"
    community 5
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 39
    label "13"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 40
    label "129"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 41
    label "17"
    community 4
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 42
    label "44"
    community 4
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 43
    label "143"
    community 4
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 44
    label "241"
    community 4
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 45
    label "270"
    community 4
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 46
    label "344"
    community 4
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 47
    label "412"
    community 4
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 48
    label "421"
    community 1
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 49
    label "18"
    community 1
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 50
    label "30"
    community 4
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 51
    label "137"
    community 1
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 52
    label "158"
    community 1
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 53
    label "162"
    community 1
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 54
    label "429"
    community 1
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 55
    label "19"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 56
    label "156"
    community 0
    race "mixed"
    sex "male"
    grade 12
  ]
  node [
    id 57
    label "190"
    community 4
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 58
    label "200"
    community 0
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 59
    label "205"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 60
    label "430"
    community 7
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 61
    label "20"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 62
    label "126"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 63
    label "21"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 64
    label "68"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 65
    label "289"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 66
    label "23"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 67
    label "227"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 68
    label "377"
    community 2
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 69
    label "24"
    community 7
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 70
    label "101"
    community 7
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 71
    label "249"
    community 7
    race "mixed"
    sex "male"
    grade 12
  ]
  node [
    id 72
    label "343"
    community 7
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 73
    label "25"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 74
    label "100"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 75
    label "342"
    community 3
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 76
    label "26"
    community 1
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 77
    label "184"
    community 0
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 78
    label "441"
    community 1
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 79
    label "127"
    community 6
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 80
    label "196"
    community 6
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 81
    label "219"
    community 6
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 82
    label "248"
    community 6
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 83
    label "322"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 84
    label "440"
    community 6
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 85
    label "149"
    community 4
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 86
    label "394"
    community 4
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 87
    label "31"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 88
    label "207"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 89
    label "37"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 90
    label "148"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 91
    label "370"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 92
    label "387"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 93
    label "39"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 94
    label "128"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 95
    label "278"
    community 5
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 96
    label "396"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 97
    label "404"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 98
    label "41"
    community 0
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 99
    label "138"
    community 0
    race "black"
    sex "missing"
    grade 9
  ]
  node [
    id 100
    label "427"
    community 0
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 101
    label "69"
    community 4
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 102
    label "47"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 103
    label "125"
    community 0
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 104
    label "142"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 105
    label "367"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 106
    label "425"
    community 2
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 107
    label "432"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 108
    label "48"
    community 8
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 109
    label "103"
    community 8
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 110
    label "186"
    community 8
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 111
    label "287"
    community 8
    race "missing"
    sex "female"
    grade 11
  ]
  node [
    id 112
    label "49"
    community 0
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 113
    label "94"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 114
    label "105"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 115
    label "415"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 116
    label "67"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 117
    label "52"
    community 0
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 118
    label "213"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 119
    label "383"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 120
    label "53"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 121
    label "157"
    community 0
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 122
    label "340"
    community 0
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 123
    label "55"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 124
    label "188"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 125
    label "226"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 126
    label "56"
    community 7
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 127
    label "141"
    community 7
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 128
    label "339"
    community 7
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 129
    label "58"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 130
    label "318"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 131
    label "61"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 132
    label "71"
    community 7
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 133
    label "268"
    community 8
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 134
    label "269"
    community 8
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 135
    label "358"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 136
    label "63"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 137
    label "62"
    community 2
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 138
    label "90"
    community 0
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 139
    label "234"
    community 1
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 140
    label "303"
    community 0
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 141
    label "445"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 142
    label "364"
    community 0
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 143
    label "70"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 144
    label "240"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 145
    label "402"
    community 5
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 146
    label "27"
    community 7
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 147
    label "215"
    community 7
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 148
    label "72"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 149
    label "253"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 150
    label "73"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 151
    label "298"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 152
    label "351"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 153
    label "76"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 154
    label "313"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 155
    label "78"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 156
    label "380"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 157
    label "79"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 158
    label "102"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 159
    label "80"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 160
    label "22"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 161
    label "254"
    community 8
    race "missing"
    sex "female"
    grade 11
  ]
  node [
    id 162
    label "81"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 163
    label "274"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 164
    label "83"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 165
    label "282"
    community 0
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 166
    label "84"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 167
    label "356"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 168
    label "87"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 169
    label "179"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 170
    label "284"
    community 2
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 171
    label "89"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 172
    label "224"
    community 4
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 173
    label "266"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 174
    label "317"
    community 0
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 175
    label "359"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 176
    label "414"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 177
    label "93"
    community 3
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 178
    label "99"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 179
    label "95"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 180
    label "130"
    community 7
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 181
    label "433"
    community 7
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 182
    label "10"
    community 8
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 183
    label "292"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 184
    label "110"
    community 8
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 185
    label "147"
    community 8
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 186
    label "112"
    community 8
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 187
    label "114"
    community 8
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 188
    label "120"
    community 8
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 189
    label "426"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 190
    label "121"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 191
    label "122"
    community 6
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 192
    label "236"
    community 6
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 193
    label "393"
    community 6
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 194
    label "123"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 195
    label "277"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 196
    label "297"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 197
    label "309"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 198
    label "363"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 199
    label "290"
    community 0
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 200
    label "361"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 201
    label "385"
    community 0
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 202
    label "353"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 203
    label "428"
    community 7
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 204
    label "131"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 205
    label "350"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 206
    label "50"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 207
    label "133"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 208
    label "221"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 209
    label "324"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 210
    label "134"
    community 1
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 211
    label "154"
    community 1
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 212
    label "312"
    community 1
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 213
    label "316"
    community 1
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 214
    label "372"
    community 1
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 215
    label "431"
    community 1
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 216
    label "140"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 217
    label "228"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 218
    label "354"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 219
    label "199"
    community 4
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 220
    label "146"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 221
    label "416"
    community 1
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 222
    label "178"
    community 1
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 223
    label "159"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 224
    label "166"
    community 8
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 225
    label "341"
    community 6
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 226
    label "169"
    community 5
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 227
    label "306"
    community 5
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 228
    label "310"
    community 5
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 229
    label "194"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 230
    label "180"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 231
    label "40"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 232
    label "320"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 233
    label "368"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 234
    label "391"
    community 2
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 235
    label "181"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 236
    label "239"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 237
    label "183"
    community 5
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 238
    label "232"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 239
    label "272"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 240
    label "373"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 241
    label "189"
    community 3
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 242
    label "409"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 243
    label "192"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 244
    label "66"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 245
    label "302"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 246
    label "384"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 247
    label "195"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 248
    label "201"
    community 0
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 249
    label "392"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 250
    label "202"
    community 3
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 251
    label "86"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 252
    label "259"
    community 5
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 253
    label "424"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 254
    label "203"
    community 8
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 255
    label "150"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 256
    label "218"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 257
    label "365"
    community 8
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 258
    label "332"
    community 3
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 259
    label "220"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 260
    label "251"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 261
    label "222"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 262
    label "319"
    community 1
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 263
    label "405"
    community 1
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 264
    label "209"
    community 2
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 265
    label "230"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 266
    label "245"
    community 1
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 267
    label "331"
    community 1
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 268
    label "235"
    community 0
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 269
    label "439"
    community 4
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 270
    label "75"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 271
    label "403"
    community 1
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 272
    label "247"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 273
    label "255"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 274
    label "256"
    community 5
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 275
    label "311"
    community 5
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 276
    label "257"
    community 6
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 277
    label "261"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 278
    label "378"
    community 0
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 279
    label "369"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 280
    label "407"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 281
    label "265"
    community 0
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 282
    label "267"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 283
    label "286"
    community 0
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 284
    label "271"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 285
    label "45"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 286
    label "296"
    community 4
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 287
    label "246"
    community 2
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 288
    label "279"
    community 0
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 289
    label "281"
    community 3
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 290
    label "325"
    community 6
    race "missing"
    sex "female"
    grade 10
  ]
  node [
    id 291
    label "417"
    community 3
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 292
    label "390"
    community 8
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 293
    label "288"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 294
    label "293"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 295
    label "294"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 296
    label "321"
    community 4
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 297
    label "374"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 298
    label "300"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 299
    label "301"
    community 1
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 300
    label "329"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 301
    label "355"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 302
    label "376"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 303
    label "107"
    community 0
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 304
    label "371"
    community 0
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 305
    label "308"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 306
    label "335"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 307
    label "337"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 308
    label "323"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 309
    label "326"
    community 1
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 310
    label "153"
    community 1
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 311
    label "330"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 312
    label "338"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 313
    label "163"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 314
    label "422"
    community 0
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 315
    label "347"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 316
    label "348"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 317
    label "349"
    community 4
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 318
    label "96"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 319
    label "411"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 320
    label "398"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 321
    label "401"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 322
    label "64"
    community 8
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 323
    label "198"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 324
    label "436"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 325
    label "360"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 326
    label "187"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 327
    label "108"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 328
    label "366"
    community 3
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 329
    label "252"
    community 3
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 330
    label "216"
    community 0
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 331
    label "295"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 332
    label "145"
    community 5
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 333
    label "42"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 334
    label "382"
    community 0
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 335
    label "386"
    community 1
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 336
    label "388"
    community 0
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 337
    label "443"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 338
    label "175"
    community 2
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 339
    label "231"
    community 2
    race "mixed"
    sex "missing"
    grade 9
  ]
  node [
    id 340
    label "397"
    community 2
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 341
    label "406"
    community 2
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 342
    label "237"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 343
    label "410"
    community 0
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 344
    label "413"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 345
    label "164"
    community 0
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 346
    label "434"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 347
    label "32"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 348
    label "57"
    community 7
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 349
    label "446"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 350
    label "435"
    community 0
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 351
    label "442"
    community 0
    race "mixed"
    sex "male"
    grade 11
  ]
  edge [
    source 0
    target 69
    type "dominant"
  ]
  edge [
    source 0
    target 72
    type "dominant"
  ]
  edge [
    source 0
    target 73
    type "dominant"
  ]
  edge [
    source 0
    target 190
    type "dominant"
  ]
  edge [
    source 1
    target 0
    type "dominant"
  ]
  edge [
    source 1
    target 49
    type "dominant"
  ]
  edge [
    source 1
    target 51
    type "dominant"
  ]
  edge [
    source 1
    target 66
    type "dominant"
  ]
  edge [
    source 1
    target 190
    type "dominant"
  ]
  edge [
    source 1
    target 278
    type "dominant"
  ]
  edge [
    source 1
    target 321
    type "dominant"
  ]
  edge [
    source 2
    target 0
    type "dominant"
  ]
  edge [
    source 2
    target 17
    type "dominant"
  ]
  edge [
    source 2
    target 129
    type "dominant"
  ]
  edge [
    source 2
    target 172
    type "dominant"
  ]
  edge [
    source 2
    target 190
    type "dominant"
  ]
  edge [
    source 3
    target 8
    type "neutral"
  ]
  edge [
    source 4
    target 3
    type "dominant"
  ]
  edge [
    source 5
    target 3
    type "dominant"
  ]
  edge [
    source 5
    target 207
    type "dominant"
  ]
  edge [
    source 6
    target 3
    type "dominant"
  ]
  edge [
    source 6
    target 263
    type "neutral"
  ]
  edge [
    source 7
    target 3
    type "dominant"
  ]
  edge [
    source 7
    target 19
    type "dominant"
  ]
  edge [
    source 8
    target 50
    type "dominant"
  ]
  edge [
    source 8
    target 167
    type "dominant"
  ]
  edge [
    source 9
    target 3
    type "dominant"
  ]
  edge [
    source 9
    target 11
    type "neutral"
  ]
  edge [
    source 9
    target 230
    type "neutral"
  ]
  edge [
    source 9
    target 208
    type "dominant"
  ]
  edge [
    source 9
    target 234
    type "dominant"
  ]
  edge [
    source 10
    target 12
    type "neutral"
  ]
  edge [
    source 10
    target 13
    type "neutral"
  ]
  edge [
    source 10
    target 16
    type "neutral"
  ]
  edge [
    source 10
    target 317
    type "dominant"
  ]
  edge [
    source 11
    target 10
    type "dominant"
  ]
  edge [
    source 11
    target 13
    type "neutral"
  ]
  edge [
    source 11
    target 176
    type "neutral"
  ]
  edge [
    source 11
    target 86
    type "dominant"
  ]
  edge [
    source 11
    target 112
    type "dominant"
  ]
  edge [
    source 11
    target 305
    type "dominant"
  ]
  edge [
    source 13
    target 12
    type "dominant"
  ]
  edge [
    source 13
    target 101
    type "dominant"
  ]
  edge [
    source 13
    target 218
    type "dominant"
  ]
  edge [
    source 13
    target 288
    type "dominant"
  ]
  edge [
    source 13
    target 304
    type "dominant"
  ]
  edge [
    source 14
    target 10
    type "dominant"
  ]
  edge [
    source 14
    target 159
    type "dominant"
  ]
  edge [
    source 14
    target 317
    type "dominant"
  ]
  edge [
    source 15
    target 10
    type "dominant"
  ]
  edge [
    source 15
    target 305
    type "dominant"
  ]
  edge [
    source 16
    target 58
    type "neutral"
  ]
  edge [
    source 16
    target 30
    type "neutral"
  ]
  edge [
    source 16
    target 19
    type "neutral"
  ]
  edge [
    source 16
    target 112
    type "dominant"
  ]
  edge [
    source 16
    target 161
    type "dominant"
  ]
  edge [
    source 16
    target 168
    type "dominant"
  ]
  edge [
    source 16
    target 304
    type "dominant"
  ]
  edge [
    source 17
    target 10
    type "dominant"
  ]
  edge [
    source 17
    target 321
    type "neutral"
  ]
  edge [
    source 17
    target 39
    type "dominant"
  ]
  edge [
    source 17
    target 167
    type "dominant"
  ]
  edge [
    source 17
    target 176
    type "dominant"
  ]
  edge [
    source 18
    target 10
    type "dominant"
  ]
  edge [
    source 19
    target 10
    type "dominant"
  ]
  edge [
    source 19
    target 47
    type "dominant"
  ]
  edge [
    source 20
    target 21
    type "neutral"
  ]
  edge [
    source 20
    target 268
    type "dominant"
  ]
  edge [
    source 20
    target 281
    type "dominant"
  ]
  edge [
    source 21
    target 34
    type "dominant"
  ]
  edge [
    source 21
    target 272
    type "dominant"
  ]
  edge [
    source 22
    target 35
    type "dominant"
  ]
  edge [
    source 23
    target 22
    type "dominant"
  ]
  edge [
    source 23
    target 250
    type "dominant"
  ]
  edge [
    source 24
    target 26
    type "neutral"
  ]
  edge [
    source 24
    target 27
    type "neutral"
  ]
  edge [
    source 24
    target 179
    type "dominant"
  ]
  edge [
    source 25
    target 24
    type "dominant"
  ]
  edge [
    source 25
    target 27
    type "neutral"
  ]
  edge [
    source 26
    target 179
    type "neutral"
  ]
  edge [
    source 26
    target 35
    type "dominant"
  ]
  edge [
    source 27
    target 141
    type "neutral"
  ]
  edge [
    source 28
    target 272
    type "dominant"
  ]
  edge [
    source 29
    target 28
    type "dominant"
  ]
  edge [
    source 29
    target 121
    type "dominant"
  ]
  edge [
    source 29
    target 281
    type "dominant"
  ]
  edge [
    source 30
    target 28
    type "dominant"
  ]
  edge [
    source 30
    target 42
    type "neutral"
  ]
  edge [
    source 30
    target 57
    type "neutral"
  ]
  edge [
    source 30
    target 58
    type "neutral"
  ]
  edge [
    source 30
    target 45
    type "neutral"
  ]
  edge [
    source 30
    target 296
    type "neutral"
  ]
  edge [
    source 30
    target 269
    type "neutral"
  ]
  edge [
    source 30
    target 47
    type "dominant"
  ]
  edge [
    source 30
    target 50
    type "dominant"
  ]
  edge [
    source 30
    target 86
    type "dominant"
  ]
  edge [
    source 30
    target 219
    type "dominant"
  ]
  edge [
    source 30
    target 317
    type "dominant"
  ]
  edge [
    source 31
    target 32
    type "neutral"
  ]
  edge [
    source 31
    target 34
    type "neutral"
  ]
  edge [
    source 31
    target 35
    type "neutral"
  ]
  edge [
    source 32
    target 35
    type "neutral"
  ]
  edge [
    source 33
    target 31
    type "dominant"
  ]
  edge [
    source 34
    target 205
    type "dominant"
  ]
  edge [
    source 36
    target 37
    type "neutral"
  ]
  edge [
    source 36
    target 38
    type "neutral"
  ]
  edge [
    source 36
    target 102
    type "dominant"
  ]
  edge [
    source 36
    target 340
    type "dominant"
  ]
  edge [
    source 37
    target 79
    type "neutral"
  ]
  edge [
    source 37
    target 80
    type "neutral"
  ]
  edge [
    source 37
    target 82
    type "neutral"
  ]
  edge [
    source 37
    target 84
    type "neutral"
  ]
  edge [
    source 37
    target 96
    type "dominant"
  ]
  edge [
    source 37
    target 134
    type "dominant"
  ]
  edge [
    source 37
    target 184
    type "dominant"
  ]
  edge [
    source 37
    target 239
    type "dominant"
  ]
  edge [
    source 37
    target 245
    type "dominant"
  ]
  edge [
    source 38
    target 37
    type "dominant"
  ]
  edge [
    source 38
    target 226
    type "neutral"
  ]
  edge [
    source 38
    target 239
    type "neutral"
  ]
  edge [
    source 38
    target 227
    type "neutral"
  ]
  edge [
    source 38
    target 228
    type "neutral"
  ]
  edge [
    source 38
    target 82
    type "dominant"
  ]
  edge [
    source 38
    target 93
    type "dominant"
  ]
  edge [
    source 38
    target 96
    type "dominant"
  ]
  edge [
    source 38
    target 274
    type "dominant"
  ]
  edge [
    source 39
    target 40
    type "neutral"
  ]
  edge [
    source 39
    target 272
    type "dominant"
  ]
  edge [
    source 41
    target 42
    type "neutral"
  ]
  edge [
    source 41
    target 43
    type "neutral"
  ]
  edge [
    source 41
    target 47
    type "neutral"
  ]
  edge [
    source 41
    target 219
    type "dominant"
  ]
  edge [
    source 41
    target 263
    type "dominant"
  ]
  edge [
    source 41
    target 296
    type "dominant"
  ]
  edge [
    source 41
    target 317
    type "dominant"
  ]
  edge [
    source 42
    target 101
    type "neutral"
  ]
  edge [
    source 42
    target 43
    type "dominant"
  ]
  edge [
    source 42
    target 45
    type "dominant"
  ]
  edge [
    source 42
    target 47
    type "dominant"
  ]
  edge [
    source 42
    target 103
    type "dominant"
  ]
  edge [
    source 42
    target 286
    type "dominant"
  ]
  edge [
    source 42
    target 296
    type "dominant"
  ]
  edge [
    source 43
    target 47
    type "neutral"
  ]
  edge [
    source 43
    target 286
    type "dominant"
  ]
  edge [
    source 44
    target 41
    type "dominant"
  ]
  edge [
    source 44
    target 45
    type "neutral"
  ]
  edge [
    source 45
    target 41
    type "dominant"
  ]
  edge [
    source 45
    target 86
    type "neutral"
  ]
  edge [
    source 45
    target 269
    type "neutral"
  ]
  edge [
    source 45
    target 47
    type "dominant"
  ]
  edge [
    source 45
    target 67
    type "dominant"
  ]
  edge [
    source 45
    target 103
    type "dominant"
  ]
  edge [
    source 45
    target 176
    type "dominant"
  ]
  edge [
    source 45
    target 343
    type "dominant"
  ]
  edge [
    source 46
    target 30
    type "dominant"
  ]
  edge [
    source 46
    target 41
    type "dominant"
  ]
  edge [
    source 46
    target 42
    type "dominant"
  ]
  edge [
    source 46
    target 47
    type "dominant"
  ]
  edge [
    source 46
    target 101
    type "dominant"
  ]
  edge [
    source 46
    target 118
    type "dominant"
  ]
  edge [
    source 46
    target 172
    type "dominant"
  ]
  edge [
    source 46
    target 208
    type "dominant"
  ]
  edge [
    source 47
    target 219
    type "dominant"
  ]
  edge [
    source 47
    target 296
    type "dominant"
  ]
  edge [
    source 48
    target 41
    type "dominant"
  ]
  edge [
    source 48
    target 212
    type "dominant"
  ]
  edge [
    source 48
    target 273
    type "dominant"
  ]
  edge [
    source 48
    target 299
    type "dominant"
  ]
  edge [
    source 48
    target 308
    type "dominant"
  ]
  edge [
    source 48
    target 309
    type "dominant"
  ]
  edge [
    source 49
    target 40
    type "dominant"
  ]
  edge [
    source 49
    target 51
    type "neutral"
  ]
  edge [
    source 49
    target 52
    type "neutral"
  ]
  edge [
    source 49
    target 54
    type "neutral"
  ]
  edge [
    source 49
    target 76
    type "dominant"
  ]
  edge [
    source 49
    target 309
    type "dominant"
  ]
  edge [
    source 50
    target 49
    type "dominant"
  ]
  edge [
    source 50
    target 85
    type "neutral"
  ]
  edge [
    source 50
    target 57
    type "neutral"
  ]
  edge [
    source 51
    target 76
    type "neutral"
  ]
  edge [
    source 51
    target 86
    type "neutral"
  ]
  edge [
    source 51
    target 54
    type "neutral"
  ]
  edge [
    source 51
    target 336
    type "dominant"
  ]
  edge [
    source 52
    target 51
    type "dominant"
  ]
  edge [
    source 52
    target 222
    type "neutral"
  ]
  edge [
    source 52
    target 212
    type "neutral"
  ]
  edge [
    source 52
    target 215
    type "neutral"
  ]
  edge [
    source 52
    target 116
    type "dominant"
  ]
  edge [
    source 52
    target 194
    type "dominant"
  ]
  edge [
    source 52
    target 210
    type "dominant"
  ]
  edge [
    source 53
    target 49
    type "dominant"
  ]
  edge [
    source 53
    target 52
    type "dominant"
  ]
  edge [
    source 54
    target 86
    type "neutral"
  ]
  edge [
    source 55
    target 141
    type "dominant"
  ]
  edge [
    source 56
    target 55
    type "dominant"
  ]
  edge [
    source 57
    target 55
    type "dominant"
  ]
  edge [
    source 57
    target 73
    type "neutral"
  ]
  edge [
    source 57
    target 85
    type "neutral"
  ]
  edge [
    source 57
    target 220
    type "dominant"
  ]
  edge [
    source 58
    target 55
    type "dominant"
  ]
  edge [
    source 58
    target 112
    type "neutral"
  ]
  edge [
    source 58
    target 133
    type "neutral"
  ]
  edge [
    source 59
    target 21
    type "dominant"
  ]
  edge [
    source 59
    target 55
    type "dominant"
  ]
  edge [
    source 59
    target 261
    type "dominant"
  ]
  edge [
    source 60
    target 55
    type "dominant"
  ]
  edge [
    source 60
    target 180
    type "neutral"
  ]
  edge [
    source 60
    target 147
    type "neutral"
  ]
  edge [
    source 60
    target 181
    type "neutral"
  ]
  edge [
    source 60
    target 70
    type "dominant"
  ]
  edge [
    source 60
    target 127
    type "dominant"
  ]
  edge [
    source 61
    target 112
    type "dominant"
  ]
  edge [
    source 62
    target 61
    type "dominant"
  ]
  edge [
    source 64
    target 63
    type "dominant"
  ]
  edge [
    source 64
    target 312
    type "dominant"
  ]
  edge [
    source 65
    target 40
    type "dominant"
  ]
  edge [
    source 65
    target 63
    type "dominant"
  ]
  edge [
    source 65
    target 223
    type "dominant"
  ]
  edge [
    source 65
    target 278
    type "dominant"
  ]
  edge [
    source 65
    target 336
    type "dominant"
  ]
  edge [
    source 66
    target 67
    type "neutral"
  ]
  edge [
    source 66
    target 245
    type "dominant"
  ]
  edge [
    source 66
    target 301
    type "dominant"
  ]
  edge [
    source 67
    target 245
    type "dominant"
  ]
  edge [
    source 67
    target 275
    type "dominant"
  ]
  edge [
    source 67
    target 277
    type "dominant"
  ]
  edge [
    source 67
    target 301
    type "dominant"
  ]
  edge [
    source 68
    target 30
    type "dominant"
  ]
  edge [
    source 68
    target 66
    type "dominant"
  ]
  edge [
    source 68
    target 207
    type "dominant"
  ]
  edge [
    source 69
    target 70
    type "neutral"
  ]
  edge [
    source 69
    target 72
    type "neutral"
  ]
  edge [
    source 69
    target 203
    type "dominant"
  ]
  edge [
    source 70
    target 180
    type "neutral"
  ]
  edge [
    source 70
    target 181
    type "neutral"
  ]
  edge [
    source 71
    target 69
    type "dominant"
  ]
  edge [
    source 71
    target 132
    type "dominant"
  ]
  edge [
    source 72
    target 73
    type "neutral"
  ]
  edge [
    source 72
    target 203
    type "dominant"
  ]
  edge [
    source 73
    target 161
    type "dominant"
  ]
  edge [
    source 73
    target 220
    type "dominant"
  ]
  edge [
    source 74
    target 73
    type "dominant"
  ]
  edge [
    source 74
    target 307
    type "dominant"
  ]
  edge [
    source 74
    target 343
    type "dominant"
  ]
  edge [
    source 75
    target 73
    type "dominant"
  ]
  edge [
    source 75
    target 291
    type "neutral"
  ]
  edge [
    source 75
    target 241
    type "dominant"
  ]
  edge [
    source 75
    target 346
    type "dominant"
  ]
  edge [
    source 76
    target 64
    type "dominant"
  ]
  edge [
    source 76
    target 78
    type "neutral"
  ]
  edge [
    source 76
    target 140
    type "dominant"
  ]
  edge [
    source 76
    target 350
    type "dominant"
  ]
  edge [
    source 77
    target 76
    type "dominant"
  ]
  edge [
    source 77
    target 273
    type "dominant"
  ]
  edge [
    source 78
    target 139
    type "neutral"
  ]
  edge [
    source 78
    target 309
    type "neutral"
  ]
  edge [
    source 78
    target 116
    type "dominant"
  ]
  edge [
    source 78
    target 247
    type "dominant"
  ]
  edge [
    source 79
    target 80
    type "neutral"
  ]
  edge [
    source 79
    target 82
    type "neutral"
  ]
  edge [
    source 79
    target 96
    type "neutral"
  ]
  edge [
    source 79
    target 203
    type "dominant"
  ]
  edge [
    source 80
    target 81
    type "neutral"
  ]
  edge [
    source 80
    target 82
    type "neutral"
  ]
  edge [
    source 80
    target 225
    type "neutral"
  ]
  edge [
    source 80
    target 84
    type "neutral"
  ]
  edge [
    source 80
    target 96
    type "dominant"
  ]
  edge [
    source 80
    target 191
    type "dominant"
  ]
  edge [
    source 81
    target 37
    type "dominant"
  ]
  edge [
    source 82
    target 96
    type "neutral"
  ]
  edge [
    source 83
    target 37
    type "dominant"
  ]
  edge [
    source 83
    target 80
    type "dominant"
  ]
  edge [
    source 83
    target 240
    type "dominant"
  ]
  edge [
    source 84
    target 81
    type "dominant"
  ]
  edge [
    source 84
    target 225
    type "neutral"
  ]
  edge [
    source 86
    target 50
    type "dominant"
  ]
  edge [
    source 86
    target 78
    type "dominant"
  ]
  edge [
    source 86
    target 269
    type "neutral"
  ]
  edge [
    source 86
    target 116
    type "dominant"
  ]
  edge [
    source 86
    target 194
    type "dominant"
  ]
  edge [
    source 86
    target 219
    type "dominant"
  ]
  edge [
    source 86
    target 262
    type "dominant"
  ]
  edge [
    source 86
    target 296
    type "dominant"
  ]
  edge [
    source 87
    target 88
    type "neutral"
  ]
  edge [
    source 88
    target 204
    type "neutral"
  ]
  edge [
    source 88
    target 286
    type "dominant"
  ]
  edge [
    source 89
    target 92
    type "neutral"
  ]
  edge [
    source 89
    target 218
    type "dominant"
  ]
  edge [
    source 90
    target 89
    type "dominant"
  ]
  edge [
    source 91
    target 89
    type "dominant"
  ]
  edge [
    source 92
    target 125
    type "dominant"
  ]
  edge [
    source 93
    target 95
    type "neutral"
  ]
  edge [
    source 93
    target 145
    type "dominant"
  ]
  edge [
    source 93
    target 328
    type "dominant"
  ]
  edge [
    source 94
    target 93
    type "dominant"
  ]
  edge [
    source 94
    target 97
    type "dominant"
  ]
  edge [
    source 95
    target 136
    type "neutral"
  ]
  edge [
    source 95
    target 143
    type "dominant"
  ]
  edge [
    source 95
    target 239
    type "dominant"
  ]
  edge [
    source 96
    target 93
    type "dominant"
  ]
  edge [
    source 96
    target 239
    type "dominant"
  ]
  edge [
    source 97
    target 35
    type "dominant"
  ]
  edge [
    source 97
    target 93
    type "dominant"
  ]
  edge [
    source 97
    target 95
    type "dominant"
  ]
  edge [
    source 97
    target 143
    type "dominant"
  ]
  edge [
    source 99
    target 98
    type "dominant"
  ]
  edge [
    source 100
    target 98
    type "dominant"
  ]
  edge [
    source 101
    target 11
    type "dominant"
  ]
  edge [
    source 101
    target 86
    type "dominant"
  ]
  edge [
    source 101
    target 112
    type "dominant"
  ]
  edge [
    source 101
    target 176
    type "dominant"
  ]
  edge [
    source 101
    target 194
    type "dominant"
  ]
  edge [
    source 101
    target 286
    type "dominant"
  ]
  edge [
    source 101
    target 296
    type "dominant"
  ]
  edge [
    source 103
    target 102
    type "dominant"
  ]
  edge [
    source 104
    target 67
    type "dominant"
  ]
  edge [
    source 104
    target 102
    type "dominant"
  ]
  edge [
    source 104
    target 320
    type "dominant"
  ]
  edge [
    source 105
    target 102
    type "dominant"
  ]
  edge [
    source 105
    target 344
    type "dominant"
  ]
  edge [
    source 106
    target 102
    type "dominant"
  ]
  edge [
    source 106
    target 308
    type "dominant"
  ]
  edge [
    source 107
    target 102
    type "dominant"
  ]
  edge [
    source 107
    target 207
    type "dominant"
  ]
  edge [
    source 107
    target 208
    type "dominant"
  ]
  edge [
    source 107
    target 213
    type "dominant"
  ]
  edge [
    source 107
    target 262
    type "dominant"
  ]
  edge [
    source 108
    target 109
    type "neutral"
  ]
  edge [
    source 108
    target 110
    type "neutral"
  ]
  edge [
    source 108
    target 188
    type "dominant"
  ]
  edge [
    source 108
    target 247
    type "dominant"
  ]
  edge [
    source 108
    target 292
    type "dominant"
  ]
  edge [
    source 109
    target 110
    type "dominant"
  ]
  edge [
    source 109
    target 216
    type "dominant"
  ]
  edge [
    source 109
    target 292
    type "dominant"
  ]
  edge [
    source 110
    target 95
    type "dominant"
  ]
  edge [
    source 111
    target 108
    type "dominant"
  ]
  edge [
    source 111
    target 133
    type "neutral"
  ]
  edge [
    source 111
    target 292
    type "neutral"
  ]
  edge [
    source 112
    target 113
    type "neutral"
  ]
  edge [
    source 112
    target 115
    type "neutral"
  ]
  edge [
    source 113
    target 305
    type "dominant"
  ]
  edge [
    source 114
    target 112
    type "dominant"
  ]
  edge [
    source 114
    target 155
    type "dominant"
  ]
  edge [
    source 115
    target 197
    type "neutral"
  ]
  edge [
    source 115
    target 277
    type "dominant"
  ]
  edge [
    source 115
    target 305
    type "dominant"
  ]
  edge [
    source 116
    target 29
    type "dominant"
  ]
  edge [
    source 116
    target 309
    type "dominant"
  ]
  edge [
    source 117
    target 115
    type "dominant"
  ]
  edge [
    source 117
    target 118
    type "neutral"
  ]
  edge [
    source 117
    target 321
    type "dominant"
  ]
  edge [
    source 118
    target 45
    type "dominant"
  ]
  edge [
    source 118
    target 194
    type "neutral"
  ]
  edge [
    source 119
    target 40
    type "dominant"
  ]
  edge [
    source 119
    target 117
    type "dominant"
  ]
  edge [
    source 119
    target 153
    type "dominant"
  ]
  edge [
    source 120
    target 122
    type "neutral"
  ]
  edge [
    source 120
    target 281
    type "dominant"
  ]
  edge [
    source 121
    target 120
    type "dominant"
  ]
  edge [
    source 121
    target 122
    type "neutral"
  ]
  edge [
    source 121
    target 157
    type "dominant"
  ]
  edge [
    source 123
    target 124
    type "neutral"
  ]
  edge [
    source 123
    target 204
    type "dominant"
  ]
  edge [
    source 123
    target 261
    type "dominant"
  ]
  edge [
    source 124
    target 240
    type "neutral"
  ]
  edge [
    source 124
    target 205
    type "dominant"
  ]
  edge [
    source 125
    target 123
    type "dominant"
  ]
  edge [
    source 125
    target 241
    type "neutral"
  ]
  edge [
    source 125
    target 346
    type "dominant"
  ]
  edge [
    source 126
    target 131
    type "dominant"
  ]
  edge [
    source 126
    target 132
    type "dominant"
  ]
  edge [
    source 126
    target 161
    type "dominant"
  ]
  edge [
    source 127
    target 126
    type "dominant"
  ]
  edge [
    source 127
    target 128
    type "dominant"
  ]
  edge [
    source 127
    target 181
    type "dominant"
  ]
  edge [
    source 127
    target 254
    type "dominant"
  ]
  edge [
    source 128
    target 70
    type "dominant"
  ]
  edge [
    source 128
    target 126
    type "dominant"
  ]
  edge [
    source 128
    target 180
    type "neutral"
  ]
  edge [
    source 128
    target 181
    type "dominant"
  ]
  edge [
    source 129
    target 130
    type "neutral"
  ]
  edge [
    source 129
    target 249
    type "dominant"
  ]
  edge [
    source 129
    target 316
    type "dominant"
  ]
  edge [
    source 131
    target 256
    type "dominant"
  ]
  edge [
    source 132
    target 131
    type "dominant"
  ]
  edge [
    source 132
    target 147
    type "neutral"
  ]
  edge [
    source 133
    target 131
    type "dominant"
  ]
  edge [
    source 133
    target 132
    type "dominant"
  ]
  edge [
    source 133
    target 184
    type "neutral"
  ]
  edge [
    source 133
    target 186
    type "neutral"
  ]
  edge [
    source 133
    target 299
    type "dominant"
  ]
  edge [
    source 134
    target 131
    type "dominant"
  ]
  edge [
    source 134
    target 187
    type "neutral"
  ]
  edge [
    source 134
    target 254
    type "neutral"
  ]
  edge [
    source 134
    target 226
    type "dominant"
  ]
  edge [
    source 135
    target 27
    type "dominant"
  ]
  edge [
    source 135
    target 82
    type "dominant"
  ]
  edge [
    source 135
    target 96
    type "dominant"
  ]
  edge [
    source 135
    target 131
    type "dominant"
  ]
  edge [
    source 135
    target 184
    type "neutral"
  ]
  edge [
    source 135
    target 187
    type "dominant"
  ]
  edge [
    source 135
    target 218
    type "dominant"
  ]
  edge [
    source 136
    target 97
    type "dominant"
  ]
  edge [
    source 137
    target 136
    type "dominant"
  ]
  edge [
    source 137
    target 233
    type "dominant"
  ]
  edge [
    source 137
    target 259
    type "dominant"
  ]
  edge [
    source 137
    target 320
    type "dominant"
  ]
  edge [
    source 137
    target 340
    type "dominant"
  ]
  edge [
    source 138
    target 116
    type "dominant"
  ]
  edge [
    source 139
    target 82
    type "dominant"
  ]
  edge [
    source 139
    target 96
    type "dominant"
  ]
  edge [
    source 139
    target 116
    type "dominant"
  ]
  edge [
    source 139
    target 266
    type "neutral"
  ]
  edge [
    source 139
    target 267
    type "neutral"
  ]
  edge [
    source 139
    target 153
    type "dominant"
  ]
  edge [
    source 139
    target 219
    type "dominant"
  ]
  edge [
    source 139
    target 309
    type "dominant"
  ]
  edge [
    source 140
    target 116
    type "dominant"
  ]
  edge [
    source 140
    target 304
    type "neutral"
  ]
  edge [
    source 141
    target 116
    type "dominant"
  ]
  edge [
    source 142
    target 64
    type "dominant"
  ]
  edge [
    source 143
    target 145
    type "neutral"
  ]
  edge [
    source 144
    target 143
    type "dominant"
  ]
  edge [
    source 144
    target 237
    type "neutral"
  ]
  edge [
    source 144
    target 265
    type "neutral"
  ]
  edge [
    source 144
    target 252
    type "neutral"
  ]
  edge [
    source 144
    target 191
    type "dominant"
  ]
  edge [
    source 144
    target 241
    type "dominant"
  ]
  edge [
    source 145
    target 144
    type "dominant"
  ]
  edge [
    source 146
    target 60
    type "dominant"
  ]
  edge [
    source 146
    target 132
    type "dominant"
  ]
  edge [
    source 146
    target 134
    type "dominant"
  ]
  edge [
    source 146
    target 147
    type "dominant"
  ]
  edge [
    source 146
    target 180
    type "dominant"
  ]
  edge [
    source 147
    target 128
    type "dominant"
  ]
  edge [
    source 147
    target 203
    type "neutral"
  ]
  edge [
    source 148
    target 52
    type "dominant"
  ]
  edge [
    source 148
    target 233
    type "dominant"
  ]
  edge [
    source 148
    target 262
    type "dominant"
  ]
  edge [
    source 148
    target 284
    type "dominant"
  ]
  edge [
    source 148
    target 301
    type "dominant"
  ]
  edge [
    source 148
    target 340
    type "dominant"
  ]
  edge [
    source 149
    target 148
    type "dominant"
  ]
  edge [
    source 149
    target 235
    type "dominant"
  ]
  edge [
    source 150
    target 155
    type "dominant"
  ]
  edge [
    source 151
    target 150
    type "dominant"
  ]
  edge [
    source 152
    target 72
    type "dominant"
  ]
  edge [
    source 152
    target 114
    type "dominant"
  ]
  edge [
    source 152
    target 150
    type "dominant"
  ]
  edge [
    source 153
    target 254
    type "dominant"
  ]
  edge [
    source 154
    target 153
    type "dominant"
  ]
  edge [
    source 154
    target 199
    type "neutral"
  ]
  edge [
    source 156
    target 16
    type "dominant"
  ]
  edge [
    source 156
    target 19
    type "dominant"
  ]
  edge [
    source 156
    target 122
    type "dominant"
  ]
  edge [
    source 156
    target 155
    type "dominant"
  ]
  edge [
    source 158
    target 157
    type "dominant"
  ]
  edge [
    source 160
    target 57
    type "dominant"
  ]
  edge [
    source 160
    target 159
    type "dominant"
  ]
  edge [
    source 161
    target 159
    type "dominant"
  ]
  edge [
    source 161
    target 186
    type "neutral"
  ]
  edge [
    source 162
    target 67
    type "dominant"
  ]
  edge [
    source 162
    target 293
    type "dominant"
  ]
  edge [
    source 163
    target 162
    type "dominant"
  ]
  edge [
    source 165
    target 164
    type "dominant"
  ]
  edge [
    source 166
    target 167
    type "neutral"
  ]
  edge [
    source 167
    target 40
    type "dominant"
  ]
  edge [
    source 167
    target 176
    type "neutral"
  ]
  edge [
    source 167
    target 219
    type "dominant"
  ]
  edge [
    source 169
    target 168
    type "dominant"
  ]
  edge [
    source 169
    target 229
    type "neutral"
  ]
  edge [
    source 170
    target 168
    type "dominant"
  ]
  edge [
    source 170
    target 230
    type "dominant"
  ]
  edge [
    source 171
    target 273
    type "dominant"
  ]
  edge [
    source 172
    target 47
    type "dominant"
  ]
  edge [
    source 172
    target 171
    type "dominant"
  ]
  edge [
    source 172
    target 208
    type "neutral"
  ]
  edge [
    source 172
    target 219
    type "dominant"
  ]
  edge [
    source 173
    target 171
    type "dominant"
  ]
  edge [
    source 173
    target 172
    type "dominant"
  ]
  edge [
    source 174
    target 171
    type "dominant"
  ]
  edge [
    source 175
    target 171
    type "dominant"
  ]
  edge [
    source 178
    target 32
    type "dominant"
  ]
  edge [
    source 178
    target 88
    type "dominant"
  ]
  edge [
    source 178
    target 124
    type "dominant"
  ]
  edge [
    source 178
    target 177
    type "dominant"
  ]
  edge [
    source 178
    target 204
    type "dominant"
  ]
  edge [
    source 178
    target 205
    type "dominant"
  ]
  edge [
    source 179
    target 35
    type "dominant"
  ]
  edge [
    source 180
    target 147
    type "dominant"
  ]
  edge [
    source 180
    target 181
    type "dominant"
  ]
  edge [
    source 181
    target 25
    type "dominant"
  ]
  edge [
    source 181
    target 276
    type "dominant"
  ]
  edge [
    source 182
    target 109
    type "dominant"
  ]
  edge [
    source 182
    target 292
    type "dominant"
  ]
  edge [
    source 183
    target 17
    type "dominant"
  ]
  edge [
    source 183
    target 114
    type "dominant"
  ]
  edge [
    source 183
    target 321
    type "dominant"
  ]
  edge [
    source 184
    target 185
    type "neutral"
  ]
  edge [
    source 186
    target 58
    type "dominant"
  ]
  edge [
    source 186
    target 79
    type "dominant"
  ]
  edge [
    source 186
    target 224
    type "dominant"
  ]
  edge [
    source 187
    target 133
    type "dominant"
  ]
  edge [
    source 187
    target 141
    type "dominant"
  ]
  edge [
    source 187
    target 186
    type "dominant"
  ]
  edge [
    source 187
    target 224
    type "dominant"
  ]
  edge [
    source 187
    target 344
    type "dominant"
  ]
  edge [
    source 188
    target 254
    type "dominant"
  ]
  edge [
    source 189
    target 35
    type "dominant"
  ]
  edge [
    source 189
    target 188
    type "dominant"
  ]
  edge [
    source 189
    target 304
    type "dominant"
  ]
  edge [
    source 190
    target 86
    type "dominant"
  ]
  edge [
    source 190
    target 152
    type "dominant"
  ]
  edge [
    source 192
    target 79
    type "dominant"
  ]
  edge [
    source 192
    target 80
    type "dominant"
  ]
  edge [
    source 192
    target 82
    type "dominant"
  ]
  edge [
    source 192
    target 96
    type "dominant"
  ]
  edge [
    source 192
    target 191
    type "dominant"
  ]
  edge [
    source 193
    target 191
    type "dominant"
  ]
  edge [
    source 193
    target 276
    type "neutral"
  ]
  edge [
    source 193
    target 225
    type "neutral"
  ]
  edge [
    source 194
    target 197
    type "neutral"
  ]
  edge [
    source 194
    target 198
    type "neutral"
  ]
  edge [
    source 195
    target 194
    type "dominant"
  ]
  edge [
    source 195
    target 334
    type "dominant"
  ]
  edge [
    source 196
    target 194
    type "dominant"
  ]
  edge [
    source 196
    target 198
    type "dominant"
  ]
  edge [
    source 196
    target 229
    type "dominant"
  ]
  edge [
    source 197
    target 198
    type "neutral"
  ]
  edge [
    source 197
    target 305
    type "dominant"
  ]
  edge [
    source 199
    target 103
    type "dominant"
  ]
  edge [
    source 199
    target 172
    type "dominant"
  ]
  edge [
    source 200
    target 103
    type "dominant"
  ]
  edge [
    source 200
    target 201
    type "dominant"
  ]
  edge [
    source 200
    target 337
    type "dominant"
  ]
  edge [
    source 201
    target 103
    type "dominant"
  ]
  edge [
    source 202
    target 40
    type "dominant"
  ]
  edge [
    source 202
    target 47
    type "dominant"
  ]
  edge [
    source 202
    target 312
    type "dominant"
  ]
  edge [
    source 203
    target 180
    type "dominant"
  ]
  edge [
    source 203
    target 261
    type "dominant"
  ]
  edge [
    source 204
    target 125
    type "dominant"
  ]
  edge [
    source 204
    target 205
    type "neutral"
  ]
  edge [
    source 206
    target 25
    type "dominant"
  ]
  edge [
    source 206
    target 125
    type "dominant"
  ]
  edge [
    source 207
    target 208
    type "neutral"
  ]
  edge [
    source 207
    target 284
    type "dominant"
  ]
  edge [
    source 207
    target 320
    type "dominant"
  ]
  edge [
    source 208
    target 234
    type "dominant"
  ]
  edge [
    source 208
    target 320
    type "dominant"
  ]
  edge [
    source 208
    target 340
    type "dominant"
  ]
  edge [
    source 208
    target 341
    type "dominant"
  ]
  edge [
    source 209
    target 207
    type "dominant"
  ]
  edge [
    source 209
    target 311
    type "dominant"
  ]
  edge [
    source 209
    target 320
    type "dominant"
  ]
  edge [
    source 211
    target 52
    type "dominant"
  ]
  edge [
    source 211
    target 210
    type "dominant"
  ]
  edge [
    source 211
    target 215
    type "dominant"
  ]
  edge [
    source 211
    target 262
    type "dominant"
  ]
  edge [
    source 211
    target 336
    type "dominant"
  ]
  edge [
    source 212
    target 210
    type "dominant"
  ]
  edge [
    source 212
    target 215
    type "neutral"
  ]
  edge [
    source 212
    target 222
    type "dominant"
  ]
  edge [
    source 213
    target 210
    type "dominant"
  ]
  edge [
    source 213
    target 212
    type "dominant"
  ]
  edge [
    source 213
    target 263
    type "dominant"
  ]
  edge [
    source 213
    target 286
    type "dominant"
  ]
  edge [
    source 213
    target 335
    type "dominant"
  ]
  edge [
    source 213
    target 344
    type "dominant"
  ]
  edge [
    source 214
    target 210
    type "dominant"
  ]
  edge [
    source 214
    target 233
    type "dominant"
  ]
  edge [
    source 215
    target 210
    type "dominant"
  ]
  edge [
    source 215
    target 213
    type "dominant"
  ]
  edge [
    source 215
    target 222
    type "neutral"
  ]
  edge [
    source 217
    target 216
    type "dominant"
  ]
  edge [
    source 217
    target 344
    type "dominant"
  ]
  edge [
    source 218
    target 21
    type "dominant"
  ]
  edge [
    source 218
    target 216
    type "dominant"
  ]
  edge [
    source 219
    target 43
    type "dominant"
  ]
  edge [
    source 220
    target 289
    type "dominant"
  ]
  edge [
    source 221
    target 52
    type "dominant"
  ]
  edge [
    source 221
    target 211
    type "dominant"
  ]
  edge [
    source 221
    target 213
    type "dominant"
  ]
  edge [
    source 221
    target 335
    type "dominant"
  ]
  edge [
    source 224
    target 280
    type "dominant"
  ]
  edge [
    source 225
    target 82
    type "dominant"
  ]
  edge [
    source 225
    target 96
    type "dominant"
  ]
  edge [
    source 225
    target 224
    type "dominant"
  ]
  edge [
    source 225
    target 276
    type "neutral"
  ]
  edge [
    source 225
    target 245
    type "dominant"
  ]
  edge [
    source 226
    target 228
    type "neutral"
  ]
  edge [
    source 227
    target 226
    type "dominant"
  ]
  edge [
    source 228
    target 84
    type "dominant"
  ]
  edge [
    source 228
    target 144
    type "dominant"
  ]
  edge [
    source 230
    target 234
    type "neutral"
  ]
  edge [
    source 230
    target 301
    type "dominant"
  ]
  edge [
    source 230
    target 341
    type "dominant"
  ]
  edge [
    source 231
    target 230
    type "dominant"
  ]
  edge [
    source 231
    target 315
    type "dominant"
  ]
  edge [
    source 232
    target 230
    type "dominant"
  ]
  edge [
    source 233
    target 208
    type "dominant"
  ]
  edge [
    source 233
    target 230
    type "dominant"
  ]
  edge [
    source 233
    target 298
    type "dominant"
  ]
  edge [
    source 233
    target 340
    type "dominant"
  ]
  edge [
    source 234
    target 341
    type "neutral"
  ]
  edge [
    source 235
    target 248
    type "dominant"
  ]
  edge [
    source 236
    target 235
    type "dominant"
  ]
  edge [
    source 236
    target 343
    type "dominant"
  ]
  edge [
    source 237
    target 238
    type "neutral"
  ]
  edge [
    source 237
    target 274
    type "dominant"
  ]
  edge [
    source 239
    target 237
    type "dominant"
  ]
  edge [
    source 239
    target 274
    type "neutral"
  ]
  edge [
    source 240
    target 260
    type "dominant"
  ]
  edge [
    source 242
    target 57
    type "dominant"
  ]
  edge [
    source 243
    target 294
    type "dominant"
  ]
  edge [
    source 244
    target 243
    type "dominant"
  ]
  edge [
    source 245
    target 243
    type "dominant"
  ]
  edge [
    source 245
    target 301
    type "neutral"
  ]
  edge [
    source 246
    target 229
    type "dominant"
  ]
  edge [
    source 246
    target 309
    type "dominant"
  ]
  edge [
    source 247
    target 254
    type "dominant"
  ]
  edge [
    source 248
    target 249
    type "neutral"
  ]
  edge [
    source 250
    target 234
    type "dominant"
  ]
  edge [
    source 251
    target 250
    type "dominant"
  ]
  edge [
    source 252
    target 250
    type "dominant"
  ]
  edge [
    source 253
    target 250
    type "dominant"
  ]
  edge [
    source 253
    target 295
    type "neutral"
  ]
  edge [
    source 253
    target 346
    type "neutral"
  ]
  edge [
    source 253
    target 328
    type "dominant"
  ]
  edge [
    source 255
    target 38
    type "dominant"
  ]
  edge [
    source 255
    target 233
    type "dominant"
  ]
  edge [
    source 257
    target 111
    type "dominant"
  ]
  edge [
    source 257
    target 256
    type "dominant"
  ]
  edge [
    source 257
    target 292
    type "neutral"
  ]
  edge [
    source 258
    target 81
    type "dominant"
  ]
  edge [
    source 258
    target 328
    type "dominant"
  ]
  edge [
    source 259
    target 245
    type "dominant"
  ]
  edge [
    source 260
    target 208
    type "dominant"
  ]
  edge [
    source 261
    target 6
    type "dominant"
  ]
  edge [
    source 261
    target 145
    type "dominant"
  ]
  edge [
    source 261
    target 346
    type "dominant"
  ]
  edge [
    source 262
    target 6
    type "dominant"
  ]
  edge [
    source 262
    target 263
    type "neutral"
  ]
  edge [
    source 264
    target 67
    type "dominant"
  ]
  edge [
    source 265
    target 240
    type "dominant"
  ]
  edge [
    source 265
    target 260
    type "dominant"
  ]
  edge [
    source 266
    target 78
    type "dominant"
  ]
  edge [
    source 266
    target 267
    type "dominant"
  ]
  edge [
    source 266
    target 309
    type "dominant"
  ]
  edge [
    source 269
    target 44
    type "dominant"
  ]
  edge [
    source 269
    target 325
    type "dominant"
  ]
  edge [
    source 270
    target 175
    type "dominant"
  ]
  edge [
    source 270
    target 266
    type "dominant"
  ]
  edge [
    source 270
    target 325
    type "dominant"
  ]
  edge [
    source 271
    target 266
    type "dominant"
  ]
  edge [
    source 273
    target 128
    type "dominant"
  ]
  edge [
    source 274
    target 275
    type "neutral"
  ]
  edge [
    source 276
    target 84
    type "dominant"
  ]
  edge [
    source 278
    target 277
    type "dominant"
  ]
  edge [
    source 279
    target 21
    type "dominant"
  ]
  edge [
    source 280
    target 21
    type "dominant"
  ]
  edge [
    source 283
    target 282
    type "dominant"
  ]
  edge [
    source 284
    target 233
    type "dominant"
  ]
  edge [
    source 284
    target 340
    type "dominant"
  ]
  edge [
    source 285
    target 284
    type "dominant"
  ]
  edge [
    source 286
    target 284
    type "dominant"
  ]
  edge [
    source 287
    target 239
    type "dominant"
  ]
  edge [
    source 289
    target 291
    type "neutral"
  ]
  edge [
    source 290
    target 84
    type "dominant"
  ]
  edge [
    source 290
    target 225
    type "dominant"
  ]
  edge [
    source 290
    target 289
    type "dominant"
  ]
  edge [
    source 290
    target 297
    type "dominant"
  ]
  edge [
    source 291
    target 328
    type "dominant"
  ]
  edge [
    source 296
    target 286
    type "dominant"
  ]
  edge [
    source 297
    target 286
    type "dominant"
  ]
  edge [
    source 297
    target 336
    type "dominant"
  ]
  edge [
    source 300
    target 234
    type "dominant"
  ]
  edge [
    source 300
    target 245
    type "dominant"
  ]
  edge [
    source 302
    target 245
    type "dominant"
  ]
  edge [
    source 303
    target 140
    type "dominant"
  ]
  edge [
    source 305
    target 175
    type "dominant"
  ]
  edge [
    source 306
    target 174
    type "dominant"
  ]
  edge [
    source 307
    target 174
    type "dominant"
  ]
  edge [
    source 310
    target 309
    type "dominant"
  ]
  edge [
    source 311
    target 68
    type "dominant"
  ]
  edge [
    source 313
    target 278
    type "dominant"
  ]
  edge [
    source 313
    target 312
    type "dominant"
  ]
  edge [
    source 314
    target 122
    type "dominant"
  ]
  edge [
    source 318
    target 205
    type "dominant"
  ]
  edge [
    source 318
    target 279
    type "dominant"
  ]
  edge [
    source 319
    target 218
    type "dominant"
  ]
  edge [
    source 320
    target 301
    type "dominant"
  ]
  edge [
    source 321
    target 167
    type "dominant"
  ]
  edge [
    source 321
    target 336
    type "dominant"
  ]
  edge [
    source 321
    target 344
    type "dominant"
  ]
  edge [
    source 321
    target 350
    type "dominant"
  ]
  edge [
    source 322
    target 135
    type "dominant"
  ]
  edge [
    source 323
    target 175
    type "dominant"
  ]
  edge [
    source 324
    target 175
    type "dominant"
  ]
  edge [
    source 326
    target 198
    type "dominant"
  ]
  edge [
    source 327
    target 142
    type "dominant"
  ]
  edge [
    source 329
    target 328
    type "dominant"
  ]
  edge [
    source 330
    target 304
    type "dominant"
  ]
  edge [
    source 331
    target 203
    type "dominant"
  ]
  edge [
    source 331
    target 304
    type "dominant"
  ]
  edge [
    source 332
    target 240
    type "dominant"
  ]
  edge [
    source 333
    target 278
    type "dominant"
  ]
  edge [
    source 337
    target 336
    type "dominant"
  ]
  edge [
    source 338
    target 234
    type "dominant"
  ]
  edge [
    source 338
    target 341
    type "dominant"
  ]
  edge [
    source 339
    target 234
    type "dominant"
  ]
  edge [
    source 340
    target 234
    type "dominant"
  ]
  edge [
    source 342
    target 271
    type "dominant"
  ]
  edge [
    source 345
    target 344
    type "dominant"
  ]
  edge [
    source 346
    target 349
    type "neutral"
  ]
  edge [
    source 347
    target 203
    type "dominant"
  ]
  edge [
    source 348
    target 60
    type "dominant"
  ]
  edge [
    source 351
    target 269
    type "dominant"
  ]
]
