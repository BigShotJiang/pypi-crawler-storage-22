graph [
  directed 1
  node [
    id 0
    label "1"
    community 0
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 1
    label "583"
    community 0
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 2
    label "3"
    community 1
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 3
    label "249"
    community 1
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 4
    label "790"
    community 1
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 5
    label "945"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 6
    label "4"
    community 2
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 7
    label "338"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 8
    label "996"
    community 2
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 9
    label "5"
    community 4
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 10
    label "141"
    community 4
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 11
    label "153"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 12
    label "687"
    community 4
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 13
    label "7"
    community 0
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 14
    label "677"
    community 0
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 15
    label "8"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 16
    label "275"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 17
    label "452"
    community 3
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 18
    label "899"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 19
    label "11"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 20
    label "159"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 21
    label "474"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 22
    label "526"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 23
    label "548"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 24
    label "12"
    community 2
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 25
    label "60"
    community 2
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 26
    label "13"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 27
    label "666"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 28
    label "793"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 29
    label "1001"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 30
    label "14"
    community 7
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 31
    label "239"
    community 7
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 32
    label "431"
    community 7
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 33
    label "15"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 34
    label "70"
    community 3
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 35
    label "476"
    community 3
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 36
    label "676"
    community 3
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 37
    label "789"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 38
    label "796"
    community 3
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 39
    label "18"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 40
    label "352"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 41
    label "435"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 42
    label "662"
    community 5
    race "mixed"
    sex "missing"
    grade 12
  ]
  node [
    id 43
    label "19"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 44
    label "243"
    community 1
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 45
    label "357"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 46
    label "568"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 47
    label "768"
    community 1
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 48
    label "20"
    community 8
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 49
    label "164"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 50
    label "337"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 51
    label "532"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 52
    label "748"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 53
    label "780"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 54
    label "995"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 55
    label "23"
    community 9
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 56
    label "55"
    community 9
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 57
    label "274"
    community 9
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 58
    label "384"
    community 9
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 59
    label "985"
    community 9
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 60
    label "994"
    community 9
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 61
    label "24"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 62
    label "25"
    community 10
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 63
    label "376"
    community 10
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 64
    label "544"
    community 10
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 65
    label "765"
    community 10
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 66
    label "844"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 67
    label "950"
    community 10
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 68
    label "27"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 69
    label "158"
    community 11
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 70
    label "672"
    community 11
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 71
    label "1003"
    community 11
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 72
    label "1006"
    community 11
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 73
    label "28"
    community 8
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 74
    label "257"
    community 9
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 75
    label "350"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 76
    label "29"
    community 2
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 77
    label "669"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 78
    label "890"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 79
    label "31"
    community 2
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 80
    label "34"
    community 7
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 81
    label "561"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 82
    label "785"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 83
    label "1000"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 84
    label "32"
    community 12
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 85
    label "47"
    community 12
    race "white"
    sex "missing"
    grade 11
  ]
  node [
    id 86
    label "127"
    community 12
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 87
    label "784"
    community 12
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 88
    label "85"
    community 7
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 89
    label "244"
    community 7
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 90
    label "254"
    community 7
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 91
    label "443"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 92
    label "35"
    community 1
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 93
    label "175"
    community 4
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 94
    label "463"
    community 1
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 95
    label "758"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 96
    label "37"
    community 4
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 97
    label "265"
    community 4
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 98
    label "529"
    community 4
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 99
    label "38"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 100
    label "268"
    community 4
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 101
    label "444"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 102
    label "550"
    community 4
    race "missing"
    sex "male"
    grade 9
  ]
  node [
    id 103
    label "864"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 104
    label "872"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 105
    label "39"
    community 12
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 106
    label "155"
    community 4
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 107
    label "241"
    community 2
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 108
    label "259"
    community 12
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 109
    label "764"
    community 12
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 110
    label "41"
    community 2
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 111
    label "279"
    community 2
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 112
    label "441"
    community 2
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 113
    label "653"
    community 2
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 114
    label "42"
    community 4
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 115
    label "174"
    community 4
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 116
    label "246"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 117
    label "367"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 118
    label "378"
    community 4
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 119
    label "381"
    community 4
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 120
    label "43"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 121
    label "44"
    community 11
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 122
    label "139"
    community 11
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 123
    label "366"
    community 11
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 124
    label "46"
    community 7
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 125
    label "438"
    community 7
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 126
    label "848"
    community 7
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 127
    label "48"
    community 13
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 128
    label "76"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 129
    label "742"
    community 13
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 130
    label "792"
    community 13
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 131
    label "49"
    community 0
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 132
    label "988"
    community 3
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 133
    label "52"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 134
    label "51"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 135
    label "272"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 136
    label "288"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 137
    label "289"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 138
    label "383"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 139
    label "54"
    community 7
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 140
    label "143"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 141
    label "451"
    community 7
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 142
    label "519"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 143
    label "56"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 144
    label "125"
    community 6
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 145
    label "193"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 146
    label "267"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 147
    label "365"
    community 10
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 148
    label "745"
    community 6
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 149
    label "58"
    community 6
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 150
    label "800"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 151
    label "856"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 152
    label "59"
    community 10
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 153
    label "382"
    community 10
    race "hispanic"
    sex "missing"
    grade 9
  ]
  node [
    id 154
    label "426"
    community 10
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 155
    label "775"
    community 10
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 156
    label "556"
    community 2
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 157
    label "61"
    community 6
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 158
    label "578"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 159
    label "946"
    community 6
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 160
    label "969"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 161
    label "62"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 162
    label "458"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 163
    label "849"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 164
    label "63"
    community 6
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 165
    label "190"
    community 6
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 166
    label "839"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 167
    label "67"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 168
    label "133"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 169
    label "528"
    community 5
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 170
    label "862"
    community 5
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 171
    label "68"
    community 1
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 172
    label "449"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 173
    label "680"
    community 1
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 174
    label "69"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 175
    label "370"
    community 5
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 176
    label "741"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 177
    label "72"
    community 10
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 178
    label "192"
    community 10
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 179
    label "74"
    community 2
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 180
    label "539"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 181
    label "234"
    community 6
    race "black"
    sex "male"
    grade 9
  ]
  node [
    id 182
    label "80"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 183
    label "540"
    community 12
    race "mixed"
    sex "male"
    grade 12
  ]
  node [
    id 184
    label "746"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 185
    label "81"
    community 2
    race "missing"
    sex "female"
    grade 11
  ]
  node [
    id 186
    label "163"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 187
    label "420"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 188
    label "941"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 189
    label "82"
    community 4
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 190
    label "465"
    community 4
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 191
    label "527"
    community 4
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 192
    label "870"
    community 0
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 193
    label "961"
    community 0
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 194
    label "83"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 195
    label "152"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 196
    label "437"
    community 9
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 197
    label "256"
    community 7
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 198
    label "369"
    community 7
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 199
    label "990"
    community 1
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 200
    label "86"
    community 3
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 201
    label "87"
    community 13
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 202
    label "185"
    community 13
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 203
    label "763"
    community 13
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 204
    label "852"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 205
    label "88"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 206
    label "558"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 207
    label "767"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 208
    label "770"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 209
    label "842"
    community 3
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 210
    label "893"
    community 11
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 211
    label "89"
    community 12
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 212
    label "650"
    community 12
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 213
    label "90"
    community 11
    race "black"
    sex "male"
    grade 11
  ]
  node [
    id 214
    label "91"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 215
    label "847"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 216
    label "93"
    community 4
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 217
    label "351"
    community 4
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 218
    label "786"
    community 4
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 219
    label "94"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 220
    label "150"
    community 2
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 221
    label "154"
    community 2
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 222
    label "873"
    community 2
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 223
    label "95"
    community 2
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 224
    label "97"
    community 12
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 225
    label "967"
    community 12
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 226
    label "970"
    community 12
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 227
    label "99"
    community 0
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 228
    label "40"
    community 3
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 229
    label "186"
    community 0
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 230
    label "188"
    community 0
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 231
    label "347"
    community 10
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 232
    label "691"
    community 10
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 233
    label "101"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 234
    label "831"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 235
    label "104"
    community 0
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 236
    label "418"
    community 0
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 237
    label "106"
    community 4
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 238
    label "177"
    community 2
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 239
    label "341"
    community 0
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 240
    label "737"
    community 0
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 241
    label "738"
    community 12
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 242
    label "108"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 243
    label "291"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 244
    label "109"
    community 2
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 245
    label "731"
    community 2
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 246
    label "110"
    community 12
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 247
    label "33"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 248
    label "538"
    community 12
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 249
    label "111"
    community 3
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 250
    label "865"
    community 3
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 251
    label "112"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 252
    label "115"
    community 2
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 253
    label "380"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 254
    label "668"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 255
    label "772"
    community 0
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 256
    label "116"
    community 7
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 257
    label "375"
    community 7
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 258
    label "117"
    community 4
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 259
    label "656"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 260
    label "118"
    community 12
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 261
    label "178"
    community 12
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 262
    label "238"
    community 12
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 263
    label "266"
    community 2
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 264
    label "119"
    community 3
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 265
    label "138"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 266
    label "270"
    community 11
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 267
    label "537"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 268
    label "120"
    community 0
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 269
    label "121"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 270
    label "371"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 271
    label "466"
    community 5
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 272
    label "122"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 273
    label "778"
    community 11
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 274
    label "949"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 275
    label "1004"
    community 6
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 276
    label "123"
    community 3
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 277
    label "124"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 278
    label "638"
    community 12
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 279
    label "128"
    community 2
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 280
    label "581"
    community 2
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 281
    label "795"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 282
    label "129"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 283
    label "372"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 284
    label "131"
    community 12
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 285
    label "132"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 286
    label "735"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 287
    label "879"
    community 1
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 288
    label "184"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 289
    label "646"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 290
    label "882"
    community 10
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 291
    label "134"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 292
    label "149"
    community 8
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 293
    label "242"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 294
    label "445"
    community 6
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 295
    label "845"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 296
    label "971"
    community 8
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 297
    label "136"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 298
    label "883"
    community 6
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 299
    label "137"
    community 13
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 300
    label "635"
    community 13
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 301
    label "673"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 302
    label "140"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 303
    label "762"
    community 3
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 304
    label "963"
    community 3
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 305
    label "982"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 306
    label "999"
    community 3
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 307
    label "832"
    community 4
    race "mixed"
    sex "male"
    grade 12
  ]
  node [
    id 308
    label "142"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 309
    label "747"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 310
    label "880"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 311
    label "144"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 312
    label "641"
    community 8
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 313
    label "146"
    community 12
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 314
    label "176"
    community 12
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 315
    label "530"
    community 12
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 316
    label "655"
    community 12
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 317
    label "148"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 318
    label "468"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 319
    label "788"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 320
    label "889"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 321
    label "151"
    community 12
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 322
    label "160"
    community 12
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 323
    label "689"
    community 8
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 324
    label "339"
    community 3
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 325
    label "157"
    community 1
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 326
    label "237"
    community 1
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 327
    label "276"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 328
    label "797"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 329
    label "161"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 330
    label "165"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 331
    label "162"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 332
    label "182"
    community 8
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 333
    label "896"
    community 8
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 334
    label "1005"
    community 3
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 335
    label "183"
    community 1
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 336
    label "135"
    community 8
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 337
    label "734"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 338
    label "166"
    community 2
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 339
    label "531"
    community 0
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 340
    label "167"
    community 9
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 341
    label "978"
    community 9
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 342
    label "169"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 343
    label "684"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 344
    label "170"
    community 8
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 345
    label "361"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 346
    label "750"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 347
    label "173"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 348
    label "336"
    community 1
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 349
    label "446"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 350
    label "546"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 351
    label "973"
    community 1
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 352
    label "975"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 353
    label "432"
    community 1
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 354
    label "543"
    community 4
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 355
    label "633"
    community 4
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 356
    label "654"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 357
    label "730"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 358
    label "648"
    community 12
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 359
    label "733"
    community 12
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 360
    label "766"
    community 12
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 361
    label "179"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 362
    label "240"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 363
    label "180"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 364
    label "181"
    community 6
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 365
    label "757"
    community 6
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 366
    label "740"
    community 8
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 367
    label "854"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 368
    label "290"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 369
    label "191"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 370
    label "799"
    community 0
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 371
    label "342"
    community 10
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 372
    label "670"
    community 10
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 373
    label "686"
    community 7
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 374
    label "993"
    community 10
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 375
    label "195"
    community 9
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 376
    label "348"
    community 9
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 377
    label "545"
    community 9
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 378
    label "647"
    community 9
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 379
    label "196"
    community 13
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 380
    label "198"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 381
    label "377"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 382
    label "199"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 383
    label "201"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 384
    label "262"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 385
    label "956"
    community 1
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 386
    label "202"
    community 5
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 387
    label "428"
    community 5
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 388
    label "843"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 389
    label "203"
    community 9
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 390
    label "75"
    community 9
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 391
    label "205"
    community 7
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 392
    label "206"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 393
    label "282"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 394
    label "208"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 395
    label "959"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 396
    label "210"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 397
    label "50"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 398
    label "211"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 399
    label "212"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 400
    label "213"
    community 2
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 401
    label "753"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 402
    label "214"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 403
    label "252"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 404
    label "379"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 405
    label "582"
    community 6
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 406
    label "215"
    community 6
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 407
    label "261"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 408
    label "895"
    community 6
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 409
    label "216"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 410
    label "217"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 411
    label "682"
    community 11
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 412
    label "219"
    community 6
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 413
    label "220"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 414
    label "221"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 415
    label "222"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 416
    label "356"
    community 6
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 417
    label "385"
    community 11
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 418
    label "891"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 419
    label "223"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 420
    label "560"
    community 2
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 421
    label "640"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 422
    label "224"
    community 1
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 423
    label "228"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 424
    label "273"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 425
    label "547"
    community 0
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 426
    label "897"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 427
    label "229"
    community 5
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 428
    label "231"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 429
    label "749"
    community 3
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 430
    label "579"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 431
    label "944"
    community 6
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 432
    label "943"
    community 1
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 433
    label "957"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 434
    label "335"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 435
    label "743"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 436
    label "553"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 437
    label "871"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 438
    label "424"
    community 1
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 439
    label "576"
    community 0
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 440
    label "245"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 441
    label "79"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 442
    label "861"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 443
    label "774"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 444
    label "247"
    community 10
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 445
    label "362"
    community 10
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 446
    label "541"
    community 10
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 447
    label "679"
    community 10
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 448
    label "690"
    community 10
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 449
    label "850"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 450
    label "250"
    community 2
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 451
    label "251"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 452
    label "292"
    community 11
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 453
    label "756"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 454
    label "992"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 455
    label "253"
    community 0
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 456
    label "965"
    community 0
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 457
    label "355"
    community 9
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 458
    label "954"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 459
    label "258"
    community 0
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 460
    label "78"
    community 2
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 461
    label "263"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 462
    label "521"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 463
    label "566"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 464
    label "661"
    community 4
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 465
    label "966"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 466
    label "464"
    community 4
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 467
    label "524"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 468
    label "57"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 469
    label "554"
    community 10
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 470
    label "652"
    community 4
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 471
    label "269"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 472
    label "287"
    community 6
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 473
    label "551"
    community 6
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 474
    label "567"
    community 11
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 475
    label "857"
    community 11
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 476
    label "271"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 477
    label "977"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 478
    label "36"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 479
    label "255"
    community 0
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 480
    label "639"
    community 11
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 481
    label "660"
    community 0
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 482
    label "277"
    community 11
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 483
    label "280"
    community 5
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 484
    label "235"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 485
    label "759"
    community 5
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 486
    label "998"
    community 6
    race "missing"
    sex "male"
    grade 10
  ]
  node [
    id 487
    label "363"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 488
    label "294"
    community 11
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 489
    label "189"
    community 11
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 490
    label "295"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 491
    label "296"
    community 6
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 492
    label "297"
    community 8
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 493
    label "298"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 494
    label "520"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 495
    label "299"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 496
    label "300"
    community 11
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 497
    label "436"
    community 11
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 498
    label "301"
    community 11
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 499
    label "779"
    community 11
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 500
    label "840"
    community 13
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 501
    label "846"
    community 8
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 502
    label "303"
    community 8
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 503
    label "575"
    community 8
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 504
    label "305"
    community 1
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 505
    label "644"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 506
    label "306"
    community 0
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 507
    label "64"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 508
    label "308"
    community 12
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 509
    label "309"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 510
    label "469"
    community 12
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 511
    label "678"
    community 8
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 512
    label "887"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 513
    label "310"
    community 3
    race "black"
    sex "male"
    grade 12
  ]
  node [
    id 514
    label "755"
    community 3
    race "white"
    sex "missing"
    grade 12
  ]
  node [
    id 515
    label "835"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 516
    label "311"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 517
    label "313"
    community 12
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 518
    label "316"
    community 13
    race "missing"
    sex "female"
    grade 11
  ]
  node [
    id 519
    label "667"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 520
    label "983"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 521
    label "991"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 522
    label "318"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 523
    label "323"
    community 6
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 524
    label "326"
    community 10
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 525
    label "948"
    community 10
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 526
    label "328"
    community 11
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 527
    label "467"
    community 11
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 528
    label "688"
    community 13
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 529
    label "332"
    community 0
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 530
    label "333"
    community 6
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 531
    label "334"
    community 4
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 532
    label "429"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 533
    label "434"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 534
    label "572"
    community 13
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 535
    label "972"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 536
    label "340"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 537
    label "657"
    community 10
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 538
    label "343"
    community 0
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 539
    label "281"
    community 0
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 540
    label "344"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 541
    label "671"
    community 1
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 542
    label "986"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 543
    label "345"
    community 3
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 544
    label "798"
    community 10
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 545
    label "952"
    community 10
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 546
    label "955"
    community 10
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 547
    label "358"
    community 6
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 548
    label "359"
    community 2
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 549
    label "65"
    community 10
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 550
    label "419"
    community 10
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 551
    label "664"
    community 10
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 552
    label "777"
    community 10
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 553
    label "860"
    community 10
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 554
    label "368"
    community 6
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 555
    label "433"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 556
    label "858"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 557
    label "373"
    community 0
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 558
    label "439"
    community 4
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 559
    label "387"
    community 8
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 560
    label "278"
    community 8
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 561
    label "388"
    community 1
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 562
    label "389"
    community 11
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 563
    label "392"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 564
    label "645"
    community 1
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 565
    label "393"
    community 8
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 566
    label "459"
    community 8
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 567
    label "394"
    community 6
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 568
    label "395"
    community 1
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 569
    label "396"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 570
    label "397"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 571
    label "398"
    community 1
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 572
    label "399"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 573
    label "427"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 574
    label "401"
    community 12
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 575
    label "168"
    community 12
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 576
    label "402"
    community 7
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 577
    label "457"
    community 7
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 578
    label "562"
    community 7
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 579
    label "404"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 580
    label "405"
    community 13
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 581
    label "473"
    community 7
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 582
    label "406"
    community 11
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 583
    label "407"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 584
    label "410"
    community 12
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 585
    label "552"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 586
    label "876"
    community 12
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 587
    label "412"
    community 5
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 588
    label "417"
    community 13
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 589
    label "769"
    community 13
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 590
    label "422"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 591
    label "674"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 592
    label "685"
    community 13
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 593
    label "425"
    community 4
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 594
    label "942"
    community 4
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 595
    label "471"
    community 13
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 596
    label "659"
    community 3
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 597
    label "450"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 598
    label "386"
    community 3
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 599
    label "462"
    community 13
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 600
    label "440"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 601
    label "898"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 602
    label "448"
    community 6
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 603
    label "525"
    community 6
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 604
    label "739"
    community 3
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 605
    label "454"
    community 11
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 606
    label "570"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 607
    label "456"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 608
    label "729"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 609
    label "460"
    community 0
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 610
    label "475"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 611
    label "478"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 612
    label "479"
    community 1
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 613
    label "481"
    community 8
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 614
    label "482"
    community 3
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 615
    label "483"
    community 8
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 616
    label "791"
    community 5
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 617
    label "484"
    community 0
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 618
    label "485"
    community 8
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 619
    label "486"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 620
    label "522"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 621
    label "487"
    community 9
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 622
    label "488"
    community 2
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 623
    label "555"
    community 2
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 624
    label "489"
    community 10
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 625
    label "490"
    community 2
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 626
    label "491"
    community 6
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 627
    label "573"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 628
    label "492"
    community 1
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 629
    label "493"
    community 13
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 630
    label "494"
    community 2
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 631
    label "495"
    community 2
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 632
    label "496"
    community 6
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 633
    label "536"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 634
    label "497"
    community 12
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 635
    label "498"
    community 5
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 636
    label "833"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 637
    label "499"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 638
    label "503"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 639
    label "881"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 640
    label "504"
    community 9
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 641
    label "754"
    community 9
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 642
    label "508"
    community 10
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 643
    label "509"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 644
    label "510"
    community 10
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 645
    label "834"
    community 5
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 646
    label "951"
    community 10
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 647
    label "515"
    community 0
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 648
    label "516"
    community 10
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 649
    label "517"
    community 5
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 650
    label "630"
    community 5
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 651
    label "518"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 652
    label "732"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 653
    label "658"
    community 4
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 654
    label "631"
    community 6
    race "black"
    sex "female"
    grade 9
  ]
  node [
    id 655
    label "533"
    community 2
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 656
    label "534"
    community 12
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 657
    label "535"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 658
    label "628"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 659
    label "947"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 660
    label "542"
    community 3
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 661
    label "783"
    community 3
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 662
    label "236"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 663
    label "549"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 664
    label "557"
    community 2
    race "missing"
    sex "male"
    grade 11
  ]
  node [
    id 665
    label "979"
    community 7
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 666
    label "564"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 667
    label "565"
    community 11
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 668
    label "569"
    community 12
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 669
    label "874"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 670
    label "877"
    community 11
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 671
    label "571"
    community 5
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 672
    label "574"
    community 10
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 673
    label "559"
    community 0
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 674
    label "580"
    community 0
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 675
    label "156"
    community 0
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 676
    label "584"
    community 0
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 677
    label "587"
    community 2
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 678
    label "588"
    community 12
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 679
    label "589"
    community 9
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 680
    label "590"
    community 13
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 681
    label "591"
    community 13
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 682
    label "593"
    community 13
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 683
    label "594"
    community 2
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 684
    label "595"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 685
    label "596"
    community 12
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 686
    label "597"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 687
    label "598"
    community 8
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 688
    label "346"
    community 8
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 689
    label "599"
    community 1
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 690
    label "602"
    community 1
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 691
    label "604"
    community 10
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 692
    label "423"
    community 10
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 693
    label "606"
    community 5
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 694
    label "609"
    community 1
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 695
    label "610"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 696
    label "612"
    community 0
    race "mixed"
    sex "male"
    grade 11
  ]
  node [
    id 697
    label "615"
    community 0
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 698
    label "616"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 699
    label "617"
    community 3
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 700
    label "620"
    community 3
    race "black"
    sex "female"
    grade 10
  ]
  node [
    id 701
    label "621"
    community 2
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 702
    label "623"
    community 5
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 703
    label "624"
    community 1
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 704
    label "752"
    community 2
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 705
    label "629"
    community 13
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 706
    label "855"
    community 6
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 707
    label "632"
    community 6
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 708
    label "665"
    community 6
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 709
    label "634"
    community 7
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 710
    label "987"
    community 7
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 711
    label "84"
    community 5
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 712
    label "643"
    community 5
    race "mixed"
    sex "female"
    grade 9
  ]
  node [
    id 713
    label "649"
    community 12
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 714
    label "642"
    community 12
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 715
    label "447"
    community 12
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 716
    label "836"
    community 11
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 717
    label "675"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 718
    label "171"
    community 5
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 719
    label "349"
    community 5
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 720
    label "681"
    community 10
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 721
    label "683"
    community 5
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 722
    label "692"
    community 5
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 723
    label "694"
    community 4
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 724
    label "695"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 725
    label "698"
    community 7
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 726
    label "699"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 727
    label "700"
    community 12
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 728
    label "701"
    community 2
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 729
    label "703"
    community 2
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 730
    label "704"
    community 11
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 731
    label "705"
    community 0
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 732
    label "706"
    community 0
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 733
    label "364"
    community 0
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 734
    label "708"
    community 2
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 735
    label "709"
    community 3
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 736
    label "866"
    community 3
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 737
    label "710"
    community 10
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 738
    label "711"
    community 10
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 739
    label "713"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 740
    label "585"
    community 12
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 741
    label "651"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 742
    label "960"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 743
    label "714"
    community 4
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 744
    label "715"
    community 1
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 745
    label "716"
    community 3
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 746
    label "718"
    community 6
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 747
    label "586"
    community 6
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 748
    label "719"
    community 1
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 749
    label "720"
    community 4
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 750
    label "723"
    community 12
    race "black"
    sex "female"
    grade 12
  ]
  node [
    id 751
    label "726"
    community 12
    race "asian"
    sex "female"
    grade 9
  ]
  node [
    id 752
    label "736"
    community 5
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 753
    label "761"
    community 5
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 754
    label "744"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 755
    label "284"
    community 0
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 756
    label "751"
    community 0
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 757
    label "461"
    community 2
    race "mixed"
    sex "female"
    grade 12
  ]
  node [
    id 758
    label "760"
    community 2
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 759
    label "782"
    community 8
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 760
    label "989"
    community 6
    race "hispanic"
    sex "female"
    grade 9
  ]
  node [
    id 761
    label "794"
    community 0
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 762
    label "802"
    community 2
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 763
    label "803"
    community 12
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 764
    label "875"
    community 12
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 765
    label "805"
    community 1
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 766
    label "806"
    community 10
    race "hispanic"
    sex "female"
    grade 11
  ]
  node [
    id 767
    label "807"
    community 11
    race "mixed"
    sex "female"
    grade 11
  ]
  node [
    id 768
    label "808"
    community 12
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 769
    label "809"
    community 7
    race "white"
    sex "male"
    grade 11
  ]
  node [
    id 770
    label "974"
    community 7
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 771
    label "810"
    community 12
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 772
    label "811"
    community 6
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 773
    label "813"
    community 8
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 774
    label "814"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 775
    label "815"
    community 6
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 776
    label "821"
    community 11
    race "black"
    sex "female"
    grade 11
  ]
  node [
    id 777
    label "822"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 778
    label "824"
    community 2
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 779
    label "826"
    community 11
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 780
    label "894"
    community 11
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 781
    label "827"
    community 10
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 782
    label "837"
    community 3
    race "mixed"
    sex "male"
    grade 10
  ]
  node [
    id 783
    label "838"
    community 5
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 784
    label "145"
    community 5
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 785
    label "968"
    community 5
    race "asian"
    sex "male"
    grade 9
  ]
  node [
    id 786
    label "841"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 787
    label "851"
    community 5
    race "white"
    sex "male"
    grade 9
  ]
  node [
    id 788
    label "859"
    community 6
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 789
    label "787"
    community 6
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 790
    label "853"
    community 11
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 791
    label "868"
    community 11
    race "mixed"
    sex "male"
    grade 12
  ]
  node [
    id 792
    label "187"
    community 11
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 793
    label "878"
    community 5
    race "mixed"
    sex "male"
    grade 9
  ]
  node [
    id 794
    label "981"
    community 6
    race "hispanic"
    sex "male"
    grade 10
  ]
  node [
    id 795
    label "884"
    community 9
    race "hispanic"
    sex "missing"
    grade 12
  ]
  node [
    id 796
    label "886"
    community 9
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 797
    label "892"
    community 0
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 798
    label "900"
    community 0
    race "white"
    sex "female"
    grade 11
  ]
  node [
    id 799
    label "901"
    community 0
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 800
    label "902"
    community 1
    race "white"
    sex "male"
    grade 10
  ]
  node [
    id 801
    label "904"
    community 12
    race "asian"
    sex "male"
    grade 10
  ]
  node [
    id 802
    label "905"
    community 3
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 803
    label "906"
    community 7
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 804
    label "953"
    community 0
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 805
    label "907"
    community 0
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 806
    label "908"
    community 3
    race "white"
    sex "female"
    grade 10
  ]
  node [
    id 807
    label "909"
    community 12
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 808
    label "910"
    community 5
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 809
    label "912"
    community 5
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 810
    label "913"
    community 3
    race "asian"
    sex "female"
    grade 11
  ]
  node [
    id 811
    label "914"
    community 1
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 812
    label "915"
    community 2
    race "hispanic"
    sex "male"
    grade 12
  ]
  node [
    id 813
    label "917"
    community 12
    race "asian"
    sex "male"
    grade 11
  ]
  node [
    id 814
    label "918"
    community 12
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 815
    label "920"
    community 8
    race "hispanic"
    sex "female"
    grade 12
  ]
  node [
    id 816
    label "921"
    community 4
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 817
    label "922"
    community 13
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 818
    label "924"
    community 1
    race "white"
    sex "female"
    grade 9
  ]
  node [
    id 819
    label "925"
    community 5
    race "hispanic"
    sex "male"
    grade 9
  ]
  node [
    id 820
    label "928"
    community 6
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 821
    label "932"
    community 2
    race "asian"
    sex "female"
    grade 10
  ]
  node [
    id 822
    label "933"
    community 11
    race "black"
    sex "male"
    grade 10
  ]
  node [
    id 823
    label "936"
    community 6
    race "hispanic"
    sex "female"
    grade 10
  ]
  node [
    id 824
    label "937"
    community 0
    race "hispanic"
    sex "male"
    grade 11
  ]
  node [
    id 825
    label "958"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  node [
    id 826
    label "938"
    community 0
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 827
    label "940"
    community 8
    race "mixed"
    sex "female"
    grade 10
  ]
  node [
    id 828
    label "663"
    community 2
    race "asian"
    sex "female"
    grade 12
  ]
  node [
    id 829
    label "964"
    community 7
    race "white"
    sex "male"
    grade 12
  ]
  node [
    id 830
    label "248"
    community 0
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 831
    label "984"
    community 2
    race "asian"
    sex "male"
    grade 12
  ]
  node [
    id 832
    label "869"
    community 0
    race "white"
    sex "female"
    grade 12
  ]
  edge [
    source 1
    target 0
    type "dominant"
  ]
  edge [
    source 1
    target 456
    type "neutral"
  ]
  edge [
    source 1
    target 617
    type "dominant"
  ]
  edge [
    source 1
    target 829
    type "dominant"
  ]
  edge [
    source 3
    target 2
    type "dominant"
  ]
  edge [
    source 3
    target 285
    type "neutral"
  ]
  edge [
    source 3
    target 286
    type "neutral"
  ]
  edge [
    source 3
    target 449
    type "neutral"
  ]
  edge [
    source 3
    target 19
    type "dominant"
  ]
  edge [
    source 3
    target 20
    type "dominant"
  ]
  edge [
    source 3
    target 95
    type "dominant"
  ]
  edge [
    source 3
    target 413
    type "dominant"
  ]
  edge [
    source 4
    target 2
    type "dominant"
  ]
  edge [
    source 4
    target 20
    type "neutral"
  ]
  edge [
    source 4
    target 449
    type "neutral"
  ]
  edge [
    source 4
    target 570
    type "dominant"
  ]
  edge [
    source 4
    target 731
    type "dominant"
  ]
  edge [
    source 4
    target 769
    type "dominant"
  ]
  edge [
    source 4
    target 811
    type "dominant"
  ]
  edge [
    source 5
    target 2
    type "dominant"
  ]
  edge [
    source 5
    target 47
    type "dominant"
  ]
  edge [
    source 5
    target 61
    type "dominant"
  ]
  edge [
    source 5
    target 233
    type "dominant"
  ]
  edge [
    source 5
    target 234
    type "dominant"
  ]
  edge [
    source 5
    target 286
    type "dominant"
  ]
  edge [
    source 5
    target 287
    type "dominant"
  ]
  edge [
    source 5
    target 340
    type "dominant"
  ]
  edge [
    source 5
    target 438
    type "dominant"
  ]
  edge [
    source 5
    target 449
    type "dominant"
  ]
  edge [
    source 5
    target 504
    type "dominant"
  ]
  edge [
    source 5
    target 570
    type "dominant"
  ]
  edge [
    source 7
    target 6
    type "dominant"
  ]
  edge [
    source 7
    target 200
    type "neutral"
  ]
  edge [
    source 7
    target 533
    type "neutral"
  ]
  edge [
    source 7
    target 79
    type "dominant"
  ]
  edge [
    source 8
    target 6
    type "dominant"
  ]
  edge [
    source 8
    target 107
    type "dominant"
  ]
  edge [
    source 8
    target 111
    type "dominant"
  ]
  edge [
    source 8
    target 257
    type "dominant"
  ]
  edge [
    source 8
    target 338
    type "dominant"
  ]
  edge [
    source 8
    target 456
    type "dominant"
  ]
  edge [
    source 8
    target 625
    type "dominant"
  ]
  edge [
    source 8
    target 660
    type "dominant"
  ]
  edge [
    source 10
    target 9
    type "dominant"
  ]
  edge [
    source 10
    target 12
    type "neutral"
  ]
  edge [
    source 10
    target 406
    type "dominant"
  ]
  edge [
    source 10
    target 725
    type "dominant"
  ]
  edge [
    source 11
    target 9
    type "dominant"
  ]
  edge [
    source 11
    target 282
    type "dominant"
  ]
  edge [
    source 11
    target 388
    type "dominant"
  ]
  edge [
    source 11
    target 419
    type "dominant"
  ]
  edge [
    source 11
    target 787
    type "dominant"
  ]
  edge [
    source 12
    target 9
    type "dominant"
  ]
  edge [
    source 12
    target 96
    type "dominant"
  ]
  edge [
    source 12
    target 317
    type "dominant"
  ]
  edge [
    source 12
    target 712
    type "dominant"
  ]
  edge [
    source 14
    target 13
    type "dominant"
  ]
  edge [
    source 14
    target 459
    type "dominant"
  ]
  edge [
    source 14
    target 777
    type "dominant"
  ]
  edge [
    source 16
    target 15
    type "dominant"
  ]
  edge [
    source 16
    target 18
    type "dominant"
  ]
  edge [
    source 16
    target 33
    type "dominant"
  ]
  edge [
    source 16
    target 34
    type "dominant"
  ]
  edge [
    source 16
    target 35
    type "dominant"
  ]
  edge [
    source 16
    target 77
    type "dominant"
  ]
  edge [
    source 16
    target 271
    type "dominant"
  ]
  edge [
    source 16
    target 424
    type "dominant"
  ]
  edge [
    source 16
    target 695
    type "dominant"
  ]
  edge [
    source 16
    target 745
    type "dominant"
  ]
  edge [
    source 17
    target 15
    type "dominant"
  ]
  edge [
    source 17
    target 34
    type "neutral"
  ]
  edge [
    source 17
    target 38
    type "neutral"
  ]
  edge [
    source 17
    target 77
    type "dominant"
  ]
  edge [
    source 17
    target 516
    type "dominant"
  ]
  edge [
    source 17
    target 745
    type "dominant"
  ]
  edge [
    source 17
    target 762
    type "dominant"
  ]
  edge [
    source 18
    target 15
    type "dominant"
  ]
  edge [
    source 18
    target 17
    type "dominant"
  ]
  edge [
    source 18
    target 33
    type "dominant"
  ]
  edge [
    source 18
    target 130
    type "dominant"
  ]
  edge [
    source 18
    target 142
    type "dominant"
  ]
  edge [
    source 18
    target 480
    type "dominant"
  ]
  edge [
    source 18
    target 516
    type "dominant"
  ]
  edge [
    source 18
    target 695
    type "dominant"
  ]
  edge [
    source 18
    target 745
    type "dominant"
  ]
  edge [
    source 20
    target 19
    type "dominant"
  ]
  edge [
    source 20
    target 46
    type "dominant"
  ]
  edge [
    source 20
    target 172
    type "dominant"
  ]
  edge [
    source 20
    target 353
    type "dominant"
  ]
  edge [
    source 20
    target 637
    type "dominant"
  ]
  edge [
    source 21
    target 19
    type "dominant"
  ]
  edge [
    source 22
    target 14
    type "dominant"
  ]
  edge [
    source 22
    target 19
    type "dominant"
  ]
  edge [
    source 22
    target 335
    type "neutral"
  ]
  edge [
    source 22
    target 46
    type "neutral"
  ]
  edge [
    source 22
    target 352
    type "neutral"
  ]
  edge [
    source 22
    target 23
    type "dominant"
  ]
  edge [
    source 22
    target 43
    type "dominant"
  ]
  edge [
    source 22
    target 44
    type "dominant"
  ]
  edge [
    source 22
    target 47
    type "dominant"
  ]
  edge [
    source 22
    target 220
    type "dominant"
  ]
  edge [
    source 22
    target 325
    type "dominant"
  ]
  edge [
    source 22
    target 353
    type "dominant"
  ]
  edge [
    source 22
    target 355
    type "dominant"
  ]
  edge [
    source 22
    target 384
    type "dominant"
  ]
  edge [
    source 22
    target 385
    type "dominant"
  ]
  edge [
    source 22
    target 568
    type "dominant"
  ]
  edge [
    source 22
    target 679
    type "dominant"
  ]
  edge [
    source 22
    target 689
    type "dominant"
  ]
  edge [
    source 22
    target 690
    type "dominant"
  ]
  edge [
    source 22
    target 694
    type "dominant"
  ]
  edge [
    source 22
    target 732
    type "dominant"
  ]
  edge [
    source 22
    target 777
    type "dominant"
  ]
  edge [
    source 23
    target 19
    type "dominant"
  ]
  edge [
    source 23
    target 335
    type "neutral"
  ]
  edge [
    source 25
    target 24
    type "dominant"
  ]
  edge [
    source 27
    target 26
    type "dominant"
  ]
  edge [
    source 27
    target 409
    type "dominant"
  ]
  edge [
    source 27
    target 632
    type "dominant"
  ]
  edge [
    source 28
    target 26
    type "dominant"
  ]
  edge [
    source 28
    target 137
    type "neutral"
  ]
  edge [
    source 28
    target 406
    type "dominant"
  ]
  edge [
    source 28
    target 491
    type "dominant"
  ]
  edge [
    source 29
    target 26
    type "dominant"
  ]
  edge [
    source 29
    target 27
    type "dominant"
  ]
  edge [
    source 29
    target 28
    type "dominant"
  ]
  edge [
    source 29
    target 288
    type "dominant"
  ]
  edge [
    source 29
    target 611
    type "dominant"
  ]
  edge [
    source 29
    target 775
    type "dominant"
  ]
  edge [
    source 31
    target 30
    type "dominant"
  ]
  edge [
    source 31
    target 32
    type "dominant"
  ]
  edge [
    source 31
    target 576
    type "dominant"
  ]
  edge [
    source 31
    target 665
    type "dominant"
  ]
  edge [
    source 31
    target 803
    type "dominant"
  ]
  edge [
    source 32
    target 30
    type "dominant"
  ]
  edge [
    source 32
    target 125
    type "neutral"
  ]
  edge [
    source 32
    target 373
    type "dominant"
  ]
  edge [
    source 34
    target 33
    type "dominant"
  ]
  edge [
    source 34
    target 79
    type "neutral"
  ]
  edge [
    source 34
    target 38
    type "neutral"
  ]
  edge [
    source 34
    target 195
    type "dominant"
  ]
  edge [
    source 34
    target 695
    type "dominant"
  ]
  edge [
    source 35
    target 18
    type "dominant"
  ]
  edge [
    source 35
    target 33
    type "dominant"
  ]
  edge [
    source 35
    target 142
    type "dominant"
  ]
  edge [
    source 35
    target 306
    type "dominant"
  ]
  edge [
    source 36
    target 18
    type "dominant"
  ]
  edge [
    source 36
    target 33
    type "dominant"
  ]
  edge [
    source 36
    target 127
    type "dominant"
  ]
  edge [
    source 36
    target 661
    type "dominant"
  ]
  edge [
    source 37
    target 18
    type "dominant"
  ]
  edge [
    source 37
    target 33
    type "dominant"
  ]
  edge [
    source 37
    target 35
    type "dominant"
  ]
  edge [
    source 38
    target 33
    type "dominant"
  ]
  edge [
    source 38
    target 195
    type "neutral"
  ]
  edge [
    source 38
    target 264
    type "dominant"
  ]
  edge [
    source 38
    target 735
    type "dominant"
  ]
  edge [
    source 40
    target 39
    type "dominant"
  ]
  edge [
    source 40
    target 116
    type "neutral"
  ]
  edge [
    source 40
    target 638
    type "dominant"
  ]
  edge [
    source 40
    target 722
    type "dominant"
  ]
  edge [
    source 41
    target 39
    type "dominant"
  ]
  edge [
    source 41
    target 269
    type "dominant"
  ]
  edge [
    source 41
    target 406
    type "dominant"
  ]
  edge [
    source 41
    target 556
    type "dominant"
  ]
  edge [
    source 42
    target 39
    type "dominant"
  ]
  edge [
    source 44
    target 43
    type "dominant"
  ]
  edge [
    source 44
    target 46
    type "neutral"
  ]
  edge [
    source 44
    target 439
    type "neutral"
  ]
  edge [
    source 44
    target 47
    type "neutral"
  ]
  edge [
    source 44
    target 172
    type "dominant"
  ]
  edge [
    source 44
    target 561
    type "dominant"
  ]
  edge [
    source 44
    target 568
    type "dominant"
  ]
  edge [
    source 44
    target 612
    type "dominant"
  ]
  edge [
    source 45
    target 41
    type "dominant"
  ]
  edge [
    source 45
    target 43
    type "dominant"
  ]
  edge [
    source 45
    target 75
    type "neutral"
  ]
  edge [
    source 45
    target 383
    type "dominant"
  ]
  edge [
    source 45
    target 612
    type "dominant"
  ]
  edge [
    source 46
    target 23
    type "dominant"
  ]
  edge [
    source 46
    target 43
    type "dominant"
  ]
  edge [
    source 46
    target 47
    type "dominant"
  ]
  edge [
    source 46
    target 413
    type "dominant"
  ]
  edge [
    source 46
    target 568
    type "dominant"
  ]
  edge [
    source 46
    target 628
    type "dominant"
  ]
  edge [
    source 46
    target 694
    type "dominant"
  ]
  edge [
    source 47
    target 43
    type "dominant"
  ]
  edge [
    source 47
    target 439
    type "neutral"
  ]
  edge [
    source 49
    target 48
    type "dominant"
  ]
  edge [
    source 49
    target 88
    type "neutral"
  ]
  edge [
    source 49
    target 335
    type "neutral"
  ]
  edge [
    source 49
    target 827
    type "dominant"
  ]
  edge [
    source 50
    target 45
    type "dominant"
  ]
  edge [
    source 50
    target 48
    type "dominant"
  ]
  edge [
    source 50
    target 532
    type "neutral"
  ]
  edge [
    source 50
    target 233
    type "dominant"
  ]
  edge [
    source 50
    target 492
    type "dominant"
  ]
  edge [
    source 51
    target 48
    type "dominant"
  ]
  edge [
    source 51
    target 49
    type "dominant"
  ]
  edge [
    source 51
    target 234
    type "dominant"
  ]
  edge [
    source 51
    target 242
    type "dominant"
  ]
  edge [
    source 51
    target 827
    type "dominant"
  ]
  edge [
    source 52
    target 48
    type "dominant"
  ]
  edge [
    source 52
    target 568
    type "dominant"
  ]
  edge [
    source 52
    target 612
    type "dominant"
  ]
  edge [
    source 52
    target 800
    type "dominant"
  ]
  edge [
    source 53
    target 48
    type "dominant"
  ]
  edge [
    source 53
    target 385
    type "dominant"
  ]
  edge [
    source 53
    target 467
    type "dominant"
  ]
  edge [
    source 54
    target 4
    type "dominant"
  ]
  edge [
    source 54
    target 48
    type "dominant"
  ]
  edge [
    source 54
    target 432
    type "neutral"
  ]
  edge [
    source 54
    target 348
    type "dominant"
  ]
  edge [
    source 54
    target 765
    type "dominant"
  ]
  edge [
    source 54
    target 811
    type "dominant"
  ]
  edge [
    source 56
    target 55
    type "dominant"
  ]
  edge [
    source 56
    target 57
    type "neutral"
  ]
  edge [
    source 56
    target 58
    type "neutral"
  ]
  edge [
    source 56
    target 60
    type "neutral"
  ]
  edge [
    source 57
    target 55
    type "dominant"
  ]
  edge [
    source 57
    target 58
    type "neutral"
  ]
  edge [
    source 57
    target 294
    type "dominant"
  ]
  edge [
    source 57
    target 737
    type "dominant"
  ]
  edge [
    source 58
    target 55
    type "dominant"
  ]
  edge [
    source 58
    target 60
    type "neutral"
  ]
  edge [
    source 58
    target 795
    type "dominant"
  ]
  edge [
    source 58
    target 796
    type "dominant"
  ]
  edge [
    source 59
    target 55
    type "dominant"
  ]
  edge [
    source 60
    target 55
    type "dominant"
  ]
  edge [
    source 60
    target 57
    type "dominant"
  ]
  edge [
    source 60
    target 59
    type "dominant"
  ]
  edge [
    source 60
    target 693
    type "dominant"
  ]
  edge [
    source 60
    target 796
    type "dominant"
  ]
  edge [
    source 63
    target 62
    type "dominant"
  ]
  edge [
    source 63
    target 374
    type "neutral"
  ]
  edge [
    source 63
    target 411
    type "dominant"
  ]
  edge [
    source 63
    target 672
    type "dominant"
  ]
  edge [
    source 64
    target 62
    type "dominant"
  ]
  edge [
    source 64
    target 152
    type "neutral"
  ]
  edge [
    source 64
    target 147
    type "neutral"
  ]
  edge [
    source 64
    target 553
    type "neutral"
  ]
  edge [
    source 64
    target 67
    type "dominant"
  ]
  edge [
    source 64
    target 642
    type "dominant"
  ]
  edge [
    source 65
    target 62
    type "dominant"
  ]
  edge [
    source 65
    target 152
    type "neutral"
  ]
  edge [
    source 65
    target 444
    type "dominant"
  ]
  edge [
    source 65
    target 524
    type "dominant"
  ]
  edge [
    source 66
    target 52
    type "dominant"
  ]
  edge [
    source 66
    target 62
    type "dominant"
  ]
  edge [
    source 66
    target 103
    type "dominant"
  ]
  edge [
    source 66
    target 369
    type "dominant"
  ]
  edge [
    source 66
    target 370
    type "dominant"
  ]
  edge [
    source 66
    target 424
    type "dominant"
  ]
  edge [
    source 66
    target 799
    type "dominant"
  ]
  edge [
    source 66
    target 800
    type "dominant"
  ]
  edge [
    source 67
    target 62
    type "dominant"
  ]
  edge [
    source 67
    target 374
    type "neutral"
  ]
  edge [
    source 67
    target 372
    type "dominant"
  ]
  edge [
    source 67
    target 445
    type "dominant"
  ]
  edge [
    source 69
    target 68
    type "dominant"
  ]
  edge [
    source 70
    target 68
    type "dominant"
  ]
  edge [
    source 70
    target 392
    type "dominant"
  ]
  edge [
    source 70
    target 452
    type "dominant"
  ]
  edge [
    source 70
    target 488
    type "dominant"
  ]
  edge [
    source 70
    target 527
    type "dominant"
  ]
  edge [
    source 70
    target 562
    type "dominant"
  ]
  edge [
    source 70
    target 626
    type "dominant"
  ]
  edge [
    source 71
    target 68
    type "dominant"
  ]
  edge [
    source 71
    target 72
    type "dominant"
  ]
  edge [
    source 71
    target 767
    type "dominant"
  ]
  edge [
    source 71
    target 791
    type "dominant"
  ]
  edge [
    source 72
    target 68
    type "dominant"
  ]
  edge [
    source 72
    target 767
    type "dominant"
  ]
  edge [
    source 72
    target 791
    type "dominant"
  ]
  edge [
    source 74
    target 73
    type "dominant"
  ]
  edge [
    source 74
    target 389
    type "dominant"
  ]
  edge [
    source 74
    target 679
    type "dominant"
  ]
  edge [
    source 75
    target 50
    type "dominant"
  ]
  edge [
    source 75
    target 73
    type "dominant"
  ]
  edge [
    source 75
    target 234
    type "neutral"
  ]
  edge [
    source 75
    target 227
    type "dominant"
  ]
  edge [
    source 75
    target 233
    type "dominant"
  ]
  edge [
    source 75
    target 277
    type "dominant"
  ]
  edge [
    source 75
    target 383
    type "dominant"
  ]
  edge [
    source 75
    target 492
    type "dominant"
  ]
  edge [
    source 75
    target 637
    type "dominant"
  ]
  edge [
    source 75
    target 759
    type "dominant"
  ]
  edge [
    source 77
    target 76
    type "dominant"
  ]
  edge [
    source 77
    target 95
    type "neutral"
  ]
  edge [
    source 77
    target 286
    type "dominant"
  ]
  edge [
    source 77
    target 773
    type "dominant"
  ]
  edge [
    source 78
    target 76
    type "dominant"
  ]
  edge [
    source 78
    target 367
    type "dominant"
  ]
  edge [
    source 78
    target 495
    type "dominant"
  ]
  edge [
    source 79
    target 82
    type "neutral"
  ]
  edge [
    source 79
    target 83
    type "neutral"
  ]
  edge [
    source 79
    target 321
    type "dominant"
  ]
  edge [
    source 79
    target 456
    type "dominant"
  ]
  edge [
    source 79
    target 734
    type "dominant"
  ]
  edge [
    source 80
    target 79
    type "dominant"
  ]
  edge [
    source 80
    target 88
    type "neutral"
  ]
  edge [
    source 80
    target 90
    type "neutral"
  ]
  edge [
    source 80
    target 578
    type "dominant"
  ]
  edge [
    source 81
    target 79
    type "dominant"
  ]
  edge [
    source 81
    target 533
    type "neutral"
  ]
  edge [
    source 81
    target 82
    type "neutral"
  ]
  edge [
    source 81
    target 241
    type "dominant"
  ]
  edge [
    source 81
    target 256
    type "dominant"
  ]
  edge [
    source 81
    target 305
    type "dominant"
  ]
  edge [
    source 81
    target 420
    type "dominant"
  ]
  edge [
    source 81
    target 514
    type "dominant"
  ]
  edge [
    source 81
    target 734
    type "dominant"
  ]
  edge [
    source 82
    target 655
    type "neutral"
  ]
  edge [
    source 82
    target 90
    type "dominant"
  ]
  edge [
    source 82
    target 127
    type "dominant"
  ]
  edge [
    source 82
    target 734
    type "dominant"
  ]
  edge [
    source 83
    target 455
    type "dominant"
  ]
  edge [
    source 83
    target 799
    type "dominant"
  ]
  edge [
    source 84
    target 700
    type "dominant"
  ]
  edge [
    source 84
    target 750
    type "dominant"
  ]
  edge [
    source 84
    target 772
    type "dominant"
  ]
  edge [
    source 85
    target 84
    type "dominant"
  ]
  edge [
    source 85
    target 87
    type "neutral"
  ]
  edge [
    source 85
    target 90
    type "dominant"
  ]
  edge [
    source 86
    target 84
    type "dominant"
  ]
  edge [
    source 86
    target 87
    type "neutral"
  ]
  edge [
    source 86
    target 727
    type "dominant"
  ]
  edge [
    source 87
    target 84
    type "dominant"
  ]
  edge [
    source 87
    target 192
    type "dominant"
  ]
  edge [
    source 87
    target 729
    type "dominant"
  ]
  edge [
    source 88
    target 89
    type "neutral"
  ]
  edge [
    source 88
    target 197
    type "neutral"
  ]
  edge [
    source 88
    target 198
    type "neutral"
  ]
  edge [
    source 89
    target 80
    type "dominant"
  ]
  edge [
    source 89
    target 256
    type "dominant"
  ]
  edge [
    source 89
    target 573
    type "dominant"
  ]
  edge [
    source 89
    target 576
    type "dominant"
  ]
  edge [
    source 89
    target 770
    type "dominant"
  ]
  edge [
    source 90
    target 341
    type "neutral"
  ]
  edge [
    source 90
    target 427
    type "dominant"
  ]
  edge [
    source 90
    target 578
    type "dominant"
  ]
  edge [
    source 91
    target 80
    type "dominant"
  ]
  edge [
    source 91
    target 89
    type "dominant"
  ]
  edge [
    source 91
    target 330
    type "neutral"
  ]
  edge [
    source 91
    target 332
    type "neutral"
  ]
  edge [
    source 92
    target 94
    type "neutral"
  ]
  edge [
    source 92
    target 95
    type "neutral"
  ]
  edge [
    source 92
    target 234
    type "dominant"
  ]
  edge [
    source 92
    target 383
    type "dominant"
  ]
  edge [
    source 92
    target 612
    type "dominant"
  ]
  edge [
    source 92
    target 628
    type "dominant"
  ]
  edge [
    source 92
    target 743
    type "dominant"
  ]
  edge [
    source 92
    target 800
    type "dominant"
  ]
  edge [
    source 93
    target 92
    type "dominant"
  ]
  edge [
    source 93
    target 344
    type "neutral"
  ]
  edge [
    source 93
    target 355
    type "neutral"
  ]
  edge [
    source 93
    target 94
    type "dominant"
  ]
  edge [
    source 93
    target 104
    type "dominant"
  ]
  edge [
    source 93
    target 212
    type "dominant"
  ]
  edge [
    source 93
    target 316
    type "dominant"
  ]
  edge [
    source 93
    target 361
    type "dominant"
  ]
  edge [
    source 93
    target 470
    type "dominant"
  ]
  edge [
    source 93
    target 634
    type "dominant"
  ]
  edge [
    source 93
    target 743
    type "dominant"
  ]
  edge [
    source 93
    target 801
    type "dominant"
  ]
  edge [
    source 94
    target 21
    type "dominant"
  ]
  edge [
    source 94
    target 23
    type "dominant"
  ]
  edge [
    source 94
    target 45
    type "dominant"
  ]
  edge [
    source 94
    target 171
    type "neutral"
  ]
  edge [
    source 94
    target 95
    type "neutral"
  ]
  edge [
    source 94
    target 355
    type "dominant"
  ]
  edge [
    source 94
    target 383
    type "dominant"
  ]
  edge [
    source 94
    target 612
    type "dominant"
  ]
  edge [
    source 94
    target 628
    type "dominant"
  ]
  edge [
    source 94
    target 637
    type "dominant"
  ]
  edge [
    source 94
    target 743
    type "dominant"
  ]
  edge [
    source 94
    target 799
    type "dominant"
  ]
  edge [
    source 95
    target 172
    type "dominant"
  ]
  edge [
    source 95
    target 181
    type "dominant"
  ]
  edge [
    source 95
    target 353
    type "dominant"
  ]
  edge [
    source 95
    target 383
    type "dominant"
  ]
  edge [
    source 95
    target 384
    type "dominant"
  ]
  edge [
    source 95
    target 422
    type "dominant"
  ]
  edge [
    source 95
    target 612
    type "dominant"
  ]
  edge [
    source 95
    target 743
    type "dominant"
  ]
  edge [
    source 96
    target 97
    type "neutral"
  ]
  edge [
    source 96
    target 114
    type "dominant"
  ]
  edge [
    source 96
    target 558
    type "dominant"
  ]
  edge [
    source 98
    target 96
    type "dominant"
  ]
  edge [
    source 98
    target 103
    type "dominant"
  ]
  edge [
    source 98
    target 114
    type "dominant"
  ]
  edge [
    source 98
    target 189
    type "dominant"
  ]
  edge [
    source 98
    target 190
    type "dominant"
  ]
  edge [
    source 98
    target 354
    type "dominant"
  ]
  edge [
    source 99
    target 100
    type "neutral"
  ]
  edge [
    source 99
    target 103
    type "neutral"
  ]
  edge [
    source 99
    target 104
    type "neutral"
  ]
  edge [
    source 99
    target 237
    type "dominant"
  ]
  edge [
    source 99
    target 398
    type "dominant"
  ]
  edge [
    source 99
    target 493
    type "dominant"
  ]
  edge [
    source 99
    target 743
    type "dominant"
  ]
  edge [
    source 100
    target 361
    type "neutral"
  ]
  edge [
    source 100
    target 470
    type "neutral"
  ]
  edge [
    source 100
    target 104
    type "neutral"
  ]
  edge [
    source 100
    target 211
    type "dominant"
  ]
  edge [
    source 100
    target 212
    type "dominant"
  ]
  edge [
    source 100
    target 398
    type "dominant"
  ]
  edge [
    source 100
    target 463
    type "dominant"
  ]
  edge [
    source 100
    target 494
    type "dominant"
  ]
  edge [
    source 100
    target 652
    type "dominant"
  ]
  edge [
    source 100
    target 723
    type "dominant"
  ]
  edge [
    source 101
    target 99
    type "dominant"
  ]
  edge [
    source 101
    target 100
    type "dominant"
  ]
  edge [
    source 101
    target 237
    type "dominant"
  ]
  edge [
    source 101
    target 259
    type "dominant"
  ]
  edge [
    source 101
    target 361
    type "dominant"
  ]
  edge [
    source 101
    target 398
    type "dominant"
  ]
  edge [
    source 101
    target 462
    type "dominant"
  ]
  edge [
    source 101
    target 470
    type "dominant"
  ]
  edge [
    source 101
    target 493
    type "dominant"
  ]
  edge [
    source 101
    target 555
    type "dominant"
  ]
  edge [
    source 102
    target 93
    type "dominant"
  ]
  edge [
    source 102
    target 99
    type "dominant"
  ]
  edge [
    source 102
    target 100
    type "dominant"
  ]
  edge [
    source 102
    target 104
    type "dominant"
  ]
  edge [
    source 102
    target 259
    type "dominant"
  ]
  edge [
    source 102
    target 464
    type "dominant"
  ]
  edge [
    source 102
    target 652
    type "dominant"
  ]
  edge [
    source 102
    target 685
    type "dominant"
  ]
  edge [
    source 103
    target 189
    type "neutral"
  ]
  edge [
    source 103
    target 261
    type "neutral"
  ]
  edge [
    source 103
    target 191
    type "neutral"
  ]
  edge [
    source 103
    target 465
    type "neutral"
  ]
  edge [
    source 103
    target 354
    type "dominant"
  ]
  edge [
    source 103
    target 464
    type "dominant"
  ]
  edge [
    source 103
    target 619
    type "dominant"
  ]
  edge [
    source 103
    target 743
    type "dominant"
  ]
  edge [
    source 104
    target 285
    type "neutral"
  ]
  edge [
    source 104
    target 555
    type "neutral"
  ]
  edge [
    source 104
    target 470
    type "dominant"
  ]
  edge [
    source 105
    target 77
    type "dominant"
  ]
  edge [
    source 105
    target 106
    type "neutral"
  ]
  edge [
    source 105
    target 260
    type "dominant"
  ]
  edge [
    source 105
    target 262
    type "dominant"
  ]
  edge [
    source 105
    target 574
    type "dominant"
  ]
  edge [
    source 105
    target 678
    type "dominant"
  ]
  edge [
    source 105
    target 723
    type "dominant"
  ]
  edge [
    source 106
    target 104
    type "dominant"
  ]
  edge [
    source 106
    target 259
    type "dominant"
  ]
  edge [
    source 106
    target 361
    type "dominant"
  ]
  edge [
    source 106
    target 493
    type "dominant"
  ]
  edge [
    source 106
    target 678
    type "dominant"
  ]
  edge [
    source 106
    target 723
    type "dominant"
  ]
  edge [
    source 106
    target 743
    type "dominant"
  ]
  edge [
    source 107
    target 105
    type "dominant"
  ]
  edge [
    source 107
    target 436
    type "neutral"
  ]
  edge [
    source 107
    target 223
    type "dominant"
  ]
  edge [
    source 107
    target 677
    type "dominant"
  ]
  edge [
    source 107
    target 728
    type "dominant"
  ]
  edge [
    source 107
    target 729
    type "dominant"
  ]
  edge [
    source 108
    target 105
    type "dominant"
  ]
  edge [
    source 108
    target 315
    type "neutral"
  ]
  edge [
    source 108
    target 260
    type "dominant"
  ]
  edge [
    source 108
    target 313
    type "dominant"
  ]
  edge [
    source 108
    target 574
    type "dominant"
  ]
  edge [
    source 108
    target 656
    type "dominant"
  ]
  edge [
    source 108
    target 684
    type "dominant"
  ]
  edge [
    source 108
    target 801
    type "dominant"
  ]
  edge [
    source 108
    target 813
    type "dominant"
  ]
  edge [
    source 109
    target 105
    type "dominant"
  ]
  edge [
    source 109
    target 284
    type "neutral"
  ]
  edge [
    source 109
    target 574
    type "dominant"
  ]
  edge [
    source 109
    target 814
    type "dominant"
  ]
  edge [
    source 110
    target 107
    type "dominant"
  ]
  edge [
    source 110
    target 111
    type "neutral"
  ]
  edge [
    source 110
    target 246
    type "dominant"
  ]
  edge [
    source 110
    target 338
    type "dominant"
  ]
  edge [
    source 110
    target 614
    type "dominant"
  ]
  edge [
    source 110
    target 623
    type "dominant"
  ]
  edge [
    source 110
    target 701
    type "dominant"
  ]
  edge [
    source 110
    target 821
    type "dominant"
  ]
  edge [
    source 111
    target 200
    type "dominant"
  ]
  edge [
    source 111
    target 515
    type "dominant"
  ]
  edge [
    source 112
    target 110
    type "dominant"
  ]
  edge [
    source 112
    target 450
    type "dominant"
  ]
  edge [
    source 112
    target 701
    type "dominant"
  ]
  edge [
    source 113
    target 110
    type "dominant"
  ]
  edge [
    source 113
    target 622
    type "dominant"
  ]
  edge [
    source 114
    target 115
    type "neutral"
  ]
  edge [
    source 114
    target 116
    type "neutral"
  ]
  edge [
    source 114
    target 118
    type "neutral"
  ]
  edge [
    source 114
    target 119
    type "neutral"
  ]
  edge [
    source 114
    target 749
    type "dominant"
  ]
  edge [
    source 115
    target 354
    type "neutral"
  ]
  edge [
    source 115
    target 607
    type "dominant"
  ]
  edge [
    source 116
    target 635
    type "dominant"
  ]
  edge [
    source 116
    target 808
    type "dominant"
  ]
  edge [
    source 117
    target 40
    type "dominant"
  ]
  edge [
    source 117
    target 114
    type "dominant"
  ]
  edge [
    source 117
    target 116
    type "dominant"
  ]
  edge [
    source 117
    target 120
    type "dominant"
  ]
  edge [
    source 117
    target 190
    type "dominant"
  ]
  edge [
    source 117
    target 387
    type "dominant"
  ]
  edge [
    source 117
    target 636
    type "dominant"
  ]
  edge [
    source 118
    target 119
    type "neutral"
  ]
  edge [
    source 118
    target 558
    type "neutral"
  ]
  edge [
    source 118
    target 671
    type "dominant"
  ]
  edge [
    source 119
    target 558
    type "neutral"
  ]
  edge [
    source 119
    target 216
    type "dominant"
  ]
  edge [
    source 119
    target 217
    type "dominant"
  ]
  edge [
    source 119
    target 749
    type "dominant"
  ]
  edge [
    source 121
    target 123
    type "neutral"
  ]
  edge [
    source 121
    target 498
    type "dominant"
  ]
  edge [
    source 122
    target 121
    type "dominant"
  ]
  edge [
    source 122
    target 123
    type "dominant"
  ]
  edge [
    source 122
    target 124
    type "dominant"
  ]
  edge [
    source 122
    target 498
    type "dominant"
  ]
  edge [
    source 122
    target 776
    type "dominant"
  ]
  edge [
    source 123
    target 480
    type "dominant"
  ]
  edge [
    source 123
    target 812
    type "dominant"
  ]
  edge [
    source 124
    target 32
    type "dominant"
  ]
  edge [
    source 124
    target 125
    type "neutral"
  ]
  edge [
    source 124
    target 126
    type "neutral"
  ]
  edge [
    source 124
    target 290
    type "dominant"
  ]
  edge [
    source 124
    target 373
    type "dominant"
  ]
  edge [
    source 124
    target 498
    type "dominant"
  ]
  edge [
    source 124
    target 617
    type "dominant"
  ]
  edge [
    source 124
    target 676
    type "dominant"
  ]
  edge [
    source 124
    target 829
    type "dominant"
  ]
  edge [
    source 125
    target 577
    type "neutral"
  ]
  edge [
    source 125
    target 126
    type "neutral"
  ]
  edge [
    source 125
    target 373
    type "dominant"
  ]
  edge [
    source 125
    target 810
    type "dominant"
  ]
  edge [
    source 126
    target 580
    type "dominant"
  ]
  edge [
    source 127
    target 178
    type "dominant"
  ]
  edge [
    source 127
    target 371
    type "dominant"
  ]
  edge [
    source 127
    target 406
    type "dominant"
  ]
  edge [
    source 128
    target 77
    type "dominant"
  ]
  edge [
    source 128
    target 127
    type "dominant"
  ]
  edge [
    source 128
    target 130
    type "neutral"
  ]
  edge [
    source 128
    target 214
    type "dominant"
  ]
  edge [
    source 128
    target 299
    type "dominant"
  ]
  edge [
    source 128
    target 580
    type "dominant"
  ]
  edge [
    source 128
    target 592
    type "dominant"
  ]
  edge [
    source 129
    target 127
    type "dominant"
  ]
  edge [
    source 130
    target 127
    type "dominant"
  ]
  edge [
    source 130
    target 214
    type "dominant"
  ]
  edge [
    source 130
    target 534
    type "dominant"
  ]
  edge [
    source 130
    target 592
    type "dominant"
  ]
  edge [
    source 131
    target 192
    type "dominant"
  ]
  edge [
    source 131
    target 268
    type "dominant"
  ]
  edge [
    source 132
    target 131
    type "dominant"
  ]
  edge [
    source 132
    target 200
    type "neutral"
  ]
  edge [
    source 132
    target 250
    type "dominant"
  ]
  edge [
    source 132
    target 527
    type "dominant"
  ]
  edge [
    source 132
    target 535
    type "dominant"
  ]
  edge [
    source 132
    target 614
    type "dominant"
  ]
  edge [
    source 132
    target 699
    type "dominant"
  ]
  edge [
    source 132
    target 700
    type "dominant"
  ]
  edge [
    source 132
    target 802
    type "dominant"
  ]
  edge [
    source 133
    target 135
    type "neutral"
  ]
  edge [
    source 133
    target 136
    type "neutral"
  ]
  edge [
    source 133
    target 137
    type "neutral"
  ]
  edge [
    source 133
    target 138
    type "neutral"
  ]
  edge [
    source 133
    target 490
    type "dominant"
  ]
  edge [
    source 134
    target 133
    type "dominant"
  ]
  edge [
    source 134
    target 136
    type "dominant"
  ]
  edge [
    source 134
    target 138
    type "dominant"
  ]
  edge [
    source 134
    target 399
    type "dominant"
  ]
  edge [
    source 134
    target 523
    type "dominant"
  ]
  edge [
    source 135
    target 138
    type "neutral"
  ]
  edge [
    source 135
    target 136
    type "dominant"
  ]
  edge [
    source 135
    target 414
    type "dominant"
  ]
  edge [
    source 136
    target 138
    type "dominant"
  ]
  edge [
    source 136
    target 150
    type "dominant"
  ]
  edge [
    source 136
    target 490
    type "dominant"
  ]
  edge [
    source 137
    target 402
    type "dominant"
  ]
  edge [
    source 137
    target 406
    type "dominant"
  ]
  edge [
    source 138
    target 490
    type "dominant"
  ]
  edge [
    source 138
    target 671
    type "dominant"
  ]
  edge [
    source 138
    target 775
    type "dominant"
  ]
  edge [
    source 139
    target 141
    type "neutral"
  ]
  edge [
    source 139
    target 262
    type "dominant"
  ]
  edge [
    source 139
    target 308
    type "dominant"
  ]
  edge [
    source 139
    target 379
    type "dominant"
  ]
  edge [
    source 139
    target 391
    type "dominant"
  ]
  edge [
    source 139
    target 430
    type "dominant"
  ]
  edge [
    source 139
    target 632
    type "dominant"
  ]
  edge [
    source 140
    target 17
    type "dominant"
  ]
  edge [
    source 140
    target 139
    type "dominant"
  ]
  edge [
    source 140
    target 141
    type "dominant"
  ]
  edge [
    source 140
    target 725
    type "dominant"
  ]
  edge [
    source 141
    target 89
    type "dominant"
  ]
  edge [
    source 141
    target 90
    type "dominant"
  ]
  edge [
    source 141
    target 142
    type "neutral"
  ]
  edge [
    source 141
    target 192
    type "dominant"
  ]
  edge [
    source 141
    target 725
    type "dominant"
  ]
  edge [
    source 141
    target 761
    type "dominant"
  ]
  edge [
    source 142
    target 139
    type "dominant"
  ]
  edge [
    source 142
    target 595
    type "neutral"
  ]
  edge [
    source 142
    target 534
    type "neutral"
  ]
  edge [
    source 142
    target 415
    type "dominant"
  ]
  edge [
    source 142
    target 520
    type "dominant"
  ]
  edge [
    source 142
    target 698
    type "dominant"
  ]
  edge [
    source 142
    target 725
    type "dominant"
  ]
  edge [
    source 144
    target 143
    type "dominant"
  ]
  edge [
    source 145
    target 143
    type "dominant"
  ]
  edge [
    source 145
    target 147
    type "dominant"
  ]
  edge [
    source 145
    target 149
    type "dominant"
  ]
  edge [
    source 145
    target 370
    type "dominant"
  ]
  edge [
    source 145
    target 406
    type "dominant"
  ]
  edge [
    source 145
    target 569
    type "dominant"
  ]
  edge [
    source 146
    target 143
    type "dominant"
  ]
  edge [
    source 146
    target 403
    type "neutral"
  ]
  edge [
    source 146
    target 147
    type "dominant"
  ]
  edge [
    source 146
    target 454
    type "dominant"
  ]
  edge [
    source 146
    target 569
    type "dominant"
  ]
  edge [
    source 146
    target 642
    type "dominant"
  ]
  edge [
    source 147
    target 143
    type "dominant"
  ]
  edge [
    source 147
    target 550
    type "neutral"
  ]
  edge [
    source 148
    target 143
    type "dominant"
  ]
  edge [
    source 149
    target 251
    type "dominant"
  ]
  edge [
    source 149
    target 410
    type "dominant"
  ]
  edge [
    source 150
    target 149
    type "dominant"
  ]
  edge [
    source 150
    target 415
    type "dominant"
  ]
  edge [
    source 151
    target 149
    type "dominant"
  ]
  edge [
    source 151
    target 440
    type "neutral"
  ]
  edge [
    source 151
    target 167
    type "dominant"
  ]
  edge [
    source 151
    target 169
    type "dominant"
  ]
  edge [
    source 151
    target 717
    type "dominant"
  ]
  edge [
    source 152
    target 553
    type "dominant"
  ]
  edge [
    source 153
    target 152
    type "dominant"
  ]
  edge [
    source 153
    target 169
    type "dominant"
  ]
  edge [
    source 153
    target 644
    type "dominant"
  ]
  edge [
    source 154
    target 152
    type "dominant"
  ]
  edge [
    source 154
    target 155
    type "dominant"
  ]
  edge [
    source 154
    target 444
    type "dominant"
  ]
  edge [
    source 154
    target 445
    type "dominant"
  ]
  edge [
    source 154
    target 524
    type "dominant"
  ]
  edge [
    source 154
    target 569
    type "dominant"
  ]
  edge [
    source 154
    target 644
    type "dominant"
  ]
  edge [
    source 154
    target 766
    type "dominant"
  ]
  edge [
    source 154
    target 796
    type "dominant"
  ]
  edge [
    source 155
    target 152
    type "dominant"
  ]
  edge [
    source 155
    target 550
    type "dominant"
  ]
  edge [
    source 156
    target 25
    type "dominant"
  ]
  edge [
    source 156
    target 407
    type "neutral"
  ]
  edge [
    source 157
    target 158
    type "neutral"
  ]
  edge [
    source 157
    target 159
    type "neutral"
  ]
  edge [
    source 157
    target 567
    type "dominant"
  ]
  edge [
    source 157
    target 823
    type "dominant"
  ]
  edge [
    source 158
    target 308
    type "dominant"
  ]
  edge [
    source 158
    target 491
    type "dominant"
  ]
  edge [
    source 158
    target 495
    type "dominant"
  ]
  edge [
    source 158
    target 654
    type "dominant"
  ]
  edge [
    source 159
    target 262
    type "dominant"
  ]
  edge [
    source 159
    target 284
    type "dominant"
  ]
  edge [
    source 159
    target 567
    type "dominant"
  ]
  edge [
    source 159
    target 823
    type "dominant"
  ]
  edge [
    source 160
    target 157
    type "dominant"
  ]
  edge [
    source 160
    target 521
    type "neutral"
  ]
  edge [
    source 160
    target 301
    type "dominant"
  ]
  edge [
    source 160
    target 518
    type "dominant"
  ]
  edge [
    source 160
    target 519
    type "dominant"
  ]
  edge [
    source 160
    target 520
    type "dominant"
  ]
  edge [
    source 160
    target 572
    type "dominant"
  ]
  edge [
    source 160
    target 573
    type "dominant"
  ]
  edge [
    source 161
    target 162
    type "neutral"
  ]
  edge [
    source 161
    target 288
    type "dominant"
  ]
  edge [
    source 161
    target 415
    type "dominant"
  ]
  edge [
    source 161
    target 418
    type "dominant"
  ]
  edge [
    source 162
    target 163
    type "neutral"
  ]
  edge [
    source 162
    target 418
    type "neutral"
  ]
  edge [
    source 162
    target 170
    type "dominant"
  ]
  edge [
    source 163
    target 161
    type "dominant"
  ]
  edge [
    source 163
    target 396
    type "dominant"
  ]
  edge [
    source 163
    target 626
    type "dominant"
  ]
  edge [
    source 164
    target 165
    type "neutral"
  ]
  edge [
    source 164
    target 547
    type "dominant"
  ]
  edge [
    source 165
    target 365
    type "dominant"
  ]
  edge [
    source 165
    target 412
    type "dominant"
  ]
  edge [
    source 165
    target 547
    type "dominant"
  ]
  edge [
    source 166
    target 164
    type "dominant"
  ]
  edge [
    source 166
    target 337
    type "dominant"
  ]
  edge [
    source 166
    target 569
    type "dominant"
  ]
  edge [
    source 166
    target 759
    type "dominant"
  ]
  edge [
    source 167
    target 169
    type "neutral"
  ]
  edge [
    source 167
    target 217
    type "dominant"
  ]
  edge [
    source 167
    target 819
    type "dominant"
  ]
  edge [
    source 168
    target 167
    type "dominant"
  ]
  edge [
    source 168
    target 402
    type "dominant"
  ]
  edge [
    source 168
    target 819
    type "dominant"
  ]
  edge [
    source 169
    target 387
    type "neutral"
  ]
  edge [
    source 169
    target 616
    type "dominant"
  ]
  edge [
    source 170
    target 167
    type "dominant"
  ]
  edge [
    source 170
    target 168
    type "dominant"
  ]
  edge [
    source 170
    target 726
    type "dominant"
  ]
  edge [
    source 170
    target 819
    type "dominant"
  ]
  edge [
    source 171
    target 172
    type "neutral"
  ]
  edge [
    source 171
    target 563
    type "dominant"
  ]
  edge [
    source 172
    target 353
    type "neutral"
  ]
  edge [
    source 172
    target 384
    type "dominant"
  ]
  edge [
    source 172
    target 563
    type "dominant"
  ]
  edge [
    source 172
    target 612
    type "dominant"
  ]
  edge [
    source 173
    target 171
    type "dominant"
  ]
  edge [
    source 173
    target 318
    type "neutral"
  ]
  edge [
    source 173
    target 383
    type "dominant"
  ]
  edge [
    source 174
    target 27
    type "dominant"
  ]
  edge [
    source 174
    target 175
    type "neutral"
  ]
  edge [
    source 174
    target 176
    type "neutral"
  ]
  edge [
    source 175
    target 317
    type "neutral"
  ]
  edge [
    source 175
    target 319
    type "neutral"
  ]
  edge [
    source 175
    target 427
    type "dominant"
  ]
  edge [
    source 175
    target 587
    type "dominant"
  ]
  edge [
    source 175
    target 712
    type "dominant"
  ]
  edge [
    source 177
    target 178
    type "neutral"
  ]
  edge [
    source 177
    target 372
    type "dominant"
  ]
  edge [
    source 177
    target 483
    type "dominant"
  ]
  edge [
    source 177
    target 737
    type "dominant"
  ]
  edge [
    source 178
    target 371
    type "neutral"
  ]
  edge [
    source 178
    target 372
    type "neutral"
  ]
  edge [
    source 178
    target 374
    type "neutral"
  ]
  edge [
    source 178
    target 545
    type "dominant"
  ]
  edge [
    source 178
    target 691
    type "dominant"
  ]
  edge [
    source 180
    target 179
    type "dominant"
  ]
  edge [
    source 180
    target 659
    type "neutral"
  ]
  edge [
    source 180
    target 395
    type "dominant"
  ]
  edge [
    source 180
    target 734
    type "dominant"
  ]
  edge [
    source 180
    target 778
    type "dominant"
  ]
  edge [
    source 181
    target 78
    type "dominant"
  ]
  edge [
    source 181
    target 128
    type "dominant"
  ]
  edge [
    source 181
    target 430
    type "neutral"
  ]
  edge [
    source 181
    target 431
    type "neutral"
  ]
  edge [
    source 181
    target 419
    type "dominant"
  ]
  edge [
    source 181
    target 816
    type "dominant"
  ]
  edge [
    source 182
    target 184
    type "neutral"
  ]
  edge [
    source 183
    target 182
    type "dominant"
  ]
  edge [
    source 183
    target 184
    type "dominant"
  ]
  edge [
    source 184
    target 512
    type "neutral"
  ]
  edge [
    source 184
    target 241
    type "dominant"
  ]
  edge [
    source 184
    target 362
    type "dominant"
  ]
  edge [
    source 184
    target 435
    type "dominant"
  ]
  edge [
    source 184
    target 802
    type "dominant"
  ]
  edge [
    source 185
    target 187
    type "neutral"
  ]
  edge [
    source 185
    target 728
    type "dominant"
  ]
  edge [
    source 186
    target 185
    type "dominant"
  ]
  edge [
    source 186
    target 187
    type "dominant"
  ]
  edge [
    source 186
    target 219
    type "dominant"
  ]
  edge [
    source 186
    target 579
    type "dominant"
  ]
  edge [
    source 187
    target 728
    type "dominant"
  ]
  edge [
    source 188
    target 185
    type "dominant"
  ]
  edge [
    source 188
    target 187
    type "dominant"
  ]
  edge [
    source 189
    target 190
    type "neutral"
  ]
  edge [
    source 189
    target 731
    type "dominant"
  ]
  edge [
    source 190
    target 361
    type "neutral"
  ]
  edge [
    source 190
    target 217
    type "dominant"
  ]
  edge [
    source 190
    target 237
    type "dominant"
  ]
  edge [
    source 190
    target 398
    type "dominant"
  ]
  edge [
    source 190
    target 422
    type "dominant"
  ]
  edge [
    source 191
    target 98
    type "dominant"
  ]
  edge [
    source 191
    target 189
    type "dominant"
  ]
  edge [
    source 191
    target 190
    type "dominant"
  ]
  edge [
    source 191
    target 361
    type "neutral"
  ]
  edge [
    source 191
    target 354
    type "neutral"
  ]
  edge [
    source 191
    target 465
    type "neutral"
  ]
  edge [
    source 191
    target 217
    type "dominant"
  ]
  edge [
    source 191
    target 593
    type "dominant"
  ]
  edge [
    source 191
    target 619
    type "dominant"
  ]
  edge [
    source 191
    target 635
    type "dominant"
  ]
  edge [
    source 191
    target 816
    type "dominant"
  ]
  edge [
    source 192
    target 90
    type "dominant"
  ]
  edge [
    source 192
    target 189
    type "dominant"
  ]
  edge [
    source 193
    target 189
    type "dominant"
  ]
  edge [
    source 193
    target 424
    type "dominant"
  ]
  edge [
    source 193
    target 476
    type "dominant"
  ]
  edge [
    source 193
    target 643
    type "dominant"
  ]
  edge [
    source 193
    target 731
    type "dominant"
  ]
  edge [
    source 193
    target 808
    type "dominant"
  ]
  edge [
    source 194
    target 534
    type "dominant"
  ]
  edge [
    source 195
    target 194
    type "dominant"
  ]
  edge [
    source 195
    target 303
    type "neutral"
  ]
  edge [
    source 195
    target 264
    type "dominant"
  ]
  edge [
    source 195
    target 535
    type "dominant"
  ]
  edge [
    source 195
    target 596
    type "dominant"
  ]
  edge [
    source 195
    target 734
    type "dominant"
  ]
  edge [
    source 195
    target 735
    type "dominant"
  ]
  edge [
    source 196
    target 194
    type "dominant"
  ]
  edge [
    source 196
    target 378
    type "neutral"
  ]
  edge [
    source 196
    target 338
    type "dominant"
  ]
  edge [
    source 196
    target 375
    type "dominant"
  ]
  edge [
    source 196
    target 377
    type "dominant"
  ]
  edge [
    source 196
    target 621
    type "dominant"
  ]
  edge [
    source 196
    target 796
    type "dominant"
  ]
  edge [
    source 197
    target 198
    type "dominant"
  ]
  edge [
    source 198
    target 256
    type "dominant"
  ]
  edge [
    source 198
    target 769
    type "dominant"
  ]
  edge [
    source 199
    target 88
    type "dominant"
  ]
  edge [
    source 199
    target 483
    type "dominant"
  ]
  edge [
    source 199
    target 504
    type "dominant"
  ]
  edge [
    source 199
    target 571
    type "dominant"
  ]
  edge [
    source 199
    target 637
    type "dominant"
  ]
  edge [
    source 199
    target 703
    type "dominant"
  ]
  edge [
    source 200
    target 52
    type "dominant"
  ]
  edge [
    source 200
    target 264
    type "dominant"
  ]
  edge [
    source 200
    target 311
    type "dominant"
  ]
  edge [
    source 200
    target 379
    type "dominant"
  ]
  edge [
    source 200
    target 511
    type "dominant"
  ]
  edge [
    source 200
    target 526
    type "dominant"
  ]
  edge [
    source 200
    target 618
    type "dominant"
  ]
  edge [
    source 200
    target 700
    type "dominant"
  ]
  edge [
    source 202
    target 201
    type "dominant"
  ]
  edge [
    source 202
    target 206
    type "dominant"
  ]
  edge [
    source 202
    target 595
    type "dominant"
  ]
  edge [
    source 202
    target 599
    type "dominant"
  ]
  edge [
    source 202
    target 681
    type "dominant"
  ]
  edge [
    source 203
    target 201
    type "dominant"
  ]
  edge [
    source 203
    target 204
    type "dominant"
  ]
  edge [
    source 203
    target 214
    type "dominant"
  ]
  edge [
    source 203
    target 580
    type "dominant"
  ]
  edge [
    source 204
    target 87
    type "dominant"
  ]
  edge [
    source 204
    target 201
    type "dominant"
  ]
  edge [
    source 204
    target 580
    type "dominant"
  ]
  edge [
    source 206
    target 205
    type "dominant"
  ]
  edge [
    source 206
    target 373
    type "dominant"
  ]
  edge [
    source 206
    target 680
    type "dominant"
  ]
  edge [
    source 207
    target 205
    type "dominant"
  ]
  edge [
    source 207
    target 209
    type "neutral"
  ]
  edge [
    source 207
    target 276
    type "dominant"
  ]
  edge [
    source 207
    target 576
    type "dominant"
  ]
  edge [
    source 208
    target 205
    type "dominant"
  ]
  edge [
    source 208
    target 209
    type "dominant"
  ]
  edge [
    source 208
    target 276
    type "dominant"
  ]
  edge [
    source 208
    target 429
    type "dominant"
  ]
  edge [
    source 209
    target 205
    type "dominant"
  ]
  edge [
    source 209
    target 597
    type "neutral"
  ]
  edge [
    source 209
    target 276
    type "dominant"
  ]
  edge [
    source 210
    target 205
    type "dominant"
  ]
  edge [
    source 210
    target 213
    type "dominant"
  ]
  edge [
    source 210
    target 498
    type "dominant"
  ]
  edge [
    source 212
    target 211
    type "dominant"
  ]
  edge [
    source 212
    target 224
    type "dominant"
  ]
  edge [
    source 212
    target 508
    type "dominant"
  ]
  edge [
    source 212
    target 584
    type "dominant"
  ]
  edge [
    source 212
    target 742
    type "dominant"
  ]
  edge [
    source 215
    target 214
    type "dominant"
  ]
  edge [
    source 215
    target 588
    type "neutral"
  ]
  edge [
    source 215
    target 534
    type "neutral"
  ]
  edge [
    source 215
    target 589
    type "dominant"
  ]
  edge [
    source 215
    target 592
    type "dominant"
  ]
  edge [
    source 215
    target 682
    type "dominant"
  ]
  edge [
    source 217
    target 216
    type "dominant"
  ]
  edge [
    source 218
    target 216
    type "dominant"
  ]
  edge [
    source 218
    target 466
    type "dominant"
  ]
  edge [
    source 220
    target 219
    type "dominant"
  ]
  edge [
    source 221
    target 219
    type "dominant"
  ]
  edge [
    source 221
    target 222
    type "dominant"
  ]
  edge [
    source 221
    target 238
    type "dominant"
  ]
  edge [
    source 221
    target 729
    type "dominant"
  ]
  edge [
    source 222
    target 93
    type "dominant"
  ]
  edge [
    source 222
    target 192
    type "dominant"
  ]
  edge [
    source 222
    target 219
    type "dominant"
  ]
  edge [
    source 222
    target 238
    type "neutral"
  ]
  edge [
    source 222
    target 362
    type "dominant"
  ]
  edge [
    source 225
    target 224
    type "dominant"
  ]
  edge [
    source 225
    target 500
    type "dominant"
  ]
  edge [
    source 225
    target 763
    type "dominant"
  ]
  edge [
    source 226
    target 86
    type "dominant"
  ]
  edge [
    source 226
    target 224
    type "dominant"
  ]
  edge [
    source 226
    target 316
    type "dominant"
  ]
  edge [
    source 226
    target 742
    type "dominant"
  ]
  edge [
    source 228
    target 227
    type "dominant"
  ]
  edge [
    source 228
    target 597
    type "dominant"
  ]
  edge [
    source 228
    target 683
    type "dominant"
  ]
  edge [
    source 229
    target 227
    type "dominant"
  ]
  edge [
    source 230
    target 227
    type "dominant"
  ]
  edge [
    source 230
    target 255
    type "dominant"
  ]
  edge [
    source 230
    target 373
    type "dominant"
  ]
  edge [
    source 230
    target 536
    type "dominant"
  ]
  edge [
    source 231
    target 227
    type "dominant"
  ]
  edge [
    source 231
    target 738
    type "dominant"
  ]
  edge [
    source 232
    target 67
    type "dominant"
  ]
  edge [
    source 232
    target 227
    type "dominant"
  ]
  edge [
    source 232
    target 537
    type "neutral"
  ]
  edge [
    source 232
    target 371
    type "dominant"
  ]
  edge [
    source 232
    target 524
    type "dominant"
  ]
  edge [
    source 232
    target 624
    type "dominant"
  ]
  edge [
    source 232
    target 646
    type "dominant"
  ]
  edge [
    source 232
    target 672
    type "dominant"
  ]
  edge [
    source 232
    target 737
    type "dominant"
  ]
  edge [
    source 234
    target 50
    type "dominant"
  ]
  edge [
    source 234
    target 233
    type "dominant"
  ]
  edge [
    source 234
    target 337
    type "dominant"
  ]
  edge [
    source 236
    target 235
    type "dominant"
  ]
  edge [
    source 238
    target 237
    type "dominant"
  ]
  edge [
    source 238
    target 814
    type "dominant"
  ]
  edge [
    source 239
    target 47
    type "dominant"
  ]
  edge [
    source 239
    target 237
    type "dominant"
  ]
  edge [
    source 239
    target 439
    type "dominant"
  ]
  edge [
    source 239
    target 610
    type "dominant"
  ]
  edge [
    source 240
    target 192
    type "dominant"
  ]
  edge [
    source 240
    target 218
    type "dominant"
  ]
  edge [
    source 240
    target 237
    type "dominant"
  ]
  edge [
    source 240
    target 798
    type "dominant"
  ]
  edge [
    source 241
    target 237
    type "dominant"
  ]
  edge [
    source 243
    target 242
    type "dominant"
  ]
  edge [
    source 245
    target 244
    type "dominant"
  ]
  edge [
    source 245
    target 758
    type "dominant"
  ]
  edge [
    source 247
    target 246
    type "dominant"
  ]
  edge [
    source 247
    target 508
    type "dominant"
  ]
  edge [
    source 247
    target 668
    type "dominant"
  ]
  edge [
    source 247
    target 814
    type "dominant"
  ]
  edge [
    source 248
    target 86
    type "dominant"
  ]
  edge [
    source 248
    target 93
    type "dominant"
  ]
  edge [
    source 248
    target 246
    type "dominant"
  ]
  edge [
    source 248
    target 356
    type "dominant"
  ]
  edge [
    source 248
    target 357
    type "dominant"
  ]
  edge [
    source 248
    target 362
    type "dominant"
  ]
  edge [
    source 248
    target 470
    type "dominant"
  ]
  edge [
    source 248
    target 685
    type "dominant"
  ]
  edge [
    source 250
    target 249
    type "dominant"
  ]
  edge [
    source 250
    target 267
    type "neutral"
  ]
  edge [
    source 250
    target 311
    type "dominant"
  ]
  edge [
    source 250
    target 802
    type "dominant"
  ]
  edge [
    source 253
    target 252
    type "dominant"
  ]
  edge [
    source 253
    target 394
    type "dominant"
  ]
  edge [
    source 254
    target 252
    type "dominant"
  ]
  edge [
    source 254
    target 630
    type "dominant"
  ]
  edge [
    source 255
    target 252
    type "dominant"
  ]
  edge [
    source 255
    target 339
    type "neutral"
  ]
  edge [
    source 255
    target 290
    type "neutral"
  ]
  edge [
    source 255
    target 766
    type "dominant"
  ]
  edge [
    source 257
    target 89
    type "dominant"
  ]
  edge [
    source 257
    target 256
    type "dominant"
  ]
  edge [
    source 257
    target 391
    type "dominant"
  ]
  edge [
    source 257
    target 429
    type "dominant"
  ]
  edge [
    source 257
    target 431
    type "dominant"
  ]
  edge [
    source 259
    target 258
    type "dominant"
  ]
  edge [
    source 259
    target 470
    type "neutral"
  ]
  edge [
    source 259
    target 493
    type "dominant"
  ]
  edge [
    source 261
    target 191
    type "dominant"
  ]
  edge [
    source 261
    target 260
    type "dominant"
  ]
  edge [
    source 261
    target 358
    type "neutral"
  ]
  edge [
    source 261
    target 359
    type "neutral"
  ]
  edge [
    source 261
    target 360
    type "neutral"
  ]
  edge [
    source 261
    target 678
    type "dominant"
  ]
  edge [
    source 261
    target 743
    type "dominant"
  ]
  edge [
    source 262
    target 260
    type "dominant"
  ]
  edge [
    source 263
    target 81
    type "dominant"
  ]
  edge [
    source 263
    target 260
    type "dominant"
  ]
  edge [
    source 265
    target 264
    type "dominant"
  ]
  edge [
    source 265
    target 303
    type "neutral"
  ]
  edge [
    source 265
    target 305
    type "neutral"
  ]
  edge [
    source 265
    target 306
    type "neutral"
  ]
  edge [
    source 265
    target 331
    type "dominant"
  ]
  edge [
    source 265
    target 769
    type "dominant"
  ]
  edge [
    source 265
    target 778
    type "dominant"
  ]
  edge [
    source 266
    target 264
    type "dominant"
  ]
  edge [
    source 266
    target 475
    type "neutral"
  ]
  edge [
    source 267
    target 264
    type "dominant"
  ]
  edge [
    source 267
    target 303
    type "neutral"
  ]
  edge [
    source 267
    target 535
    type "neutral"
  ]
  edge [
    source 267
    target 277
    type "dominant"
  ]
  edge [
    source 267
    target 306
    type "dominant"
  ]
  edge [
    source 267
    target 334
    type "dominant"
  ]
  edge [
    source 267
    target 527
    type "dominant"
  ]
  edge [
    source 267
    target 618
    type "dominant"
  ]
  edge [
    source 267
    target 801
    type "dominant"
  ]
  edge [
    source 267
    target 802
    type "dominant"
  ]
  edge [
    source 270
    target 269
    type "dominant"
  ]
  edge [
    source 270
    target 555
    type "neutral"
  ]
  edge [
    source 270
    target 556
    type "neutral"
  ]
  edge [
    source 270
    target 320
    type "neutral"
  ]
  edge [
    source 270
    target 271
    type "dominant"
  ]
  edge [
    source 270
    target 277
    type "dominant"
  ]
  edge [
    source 270
    target 388
    type "dominant"
  ]
  edge [
    source 271
    target 269
    type "dominant"
  ]
  edge [
    source 271
    target 482
    type "neutral"
  ]
  edge [
    source 271
    target 644
    type "dominant"
  ]
  edge [
    source 273
    target 272
    type "dominant"
  ]
  edge [
    source 273
    target 606
    type "neutral"
  ]
  edge [
    source 273
    target 670
    type "neutral"
  ]
  edge [
    source 273
    target 312
    type "dominant"
  ]
  edge [
    source 273
    target 669
    type "dominant"
  ]
  edge [
    source 274
    target 181
    type "dominant"
  ]
  edge [
    source 274
    target 272
    type "dominant"
  ]
  edge [
    source 274
    target 310
    type "neutral"
  ]
  edge [
    source 274
    target 288
    type "dominant"
  ]
  edge [
    source 274
    target 308
    type "dominant"
  ]
  edge [
    source 274
    target 430
    type "dominant"
  ]
  edge [
    source 274
    target 632
    type "dominant"
  ]
  edge [
    source 274
    target 775
    type "dominant"
  ]
  edge [
    source 275
    target 272
    type "dominant"
  ]
  edge [
    source 275
    target 554
    type "neutral"
  ]
  edge [
    source 278
    target 86
    type "dominant"
  ]
  edge [
    source 278
    target 666
    type "neutral"
  ]
  edge [
    source 278
    target 320
    type "neutral"
  ]
  edge [
    source 278
    target 398
    type "dominant"
  ]
  edge [
    source 278
    target 727
    type "dominant"
  ]
  edge [
    source 279
    target 280
    type "neutral"
  ]
  edge [
    source 281
    target 279
    type "dominant"
  ]
  edge [
    source 281
    target 420
    type "neutral"
  ]
  edge [
    source 281
    target 407
    type "dominant"
  ]
  edge [
    source 281
    target 462
    type "dominant"
  ]
  edge [
    source 282
    target 283
    type "neutral"
  ]
  edge [
    source 282
    target 663
    type "dominant"
  ]
  edge [
    source 283
    target 41
    type "dominant"
  ]
  edge [
    source 283
    target 271
    type "dominant"
  ]
  edge [
    source 283
    target 281
    type "dominant"
  ]
  edge [
    source 283
    target 556
    type "dominant"
  ]
  edge [
    source 283
    target 600
    type "dominant"
  ]
  edge [
    source 284
    target 574
    type "dominant"
  ]
  edge [
    source 284
    target 814
    type "dominant"
  ]
  edge [
    source 285
    target 21
    type "dominant"
  ]
  edge [
    source 285
    target 286
    type "neutral"
  ]
  edge [
    source 285
    target 287
    type "neutral"
  ]
  edge [
    source 285
    target 413
    type "dominant"
  ]
  edge [
    source 285
    target 422
    type "dominant"
  ]
  edge [
    source 285
    target 449
    type "dominant"
  ]
  edge [
    source 286
    target 449
    type "neutral"
  ]
  edge [
    source 286
    target 287
    type "dominant"
  ]
  edge [
    source 286
    target 337
    type "dominant"
  ]
  edge [
    source 286
    target 407
    type "dominant"
  ]
  edge [
    source 286
    target 413
    type "dominant"
  ]
  edge [
    source 287
    target 3
    type "dominant"
  ]
  edge [
    source 287
    target 388
    type "neutral"
  ]
  edge [
    source 287
    target 413
    type "dominant"
  ]
  edge [
    source 287
    target 570
    type "dominant"
  ]
  edge [
    source 288
    target 27
    type "dominant"
  ]
  edge [
    source 288
    target 28
    type "dominant"
  ]
  edge [
    source 288
    target 137
    type "dominant"
  ]
  edge [
    source 288
    target 168
    type "dominant"
  ]
  edge [
    source 288
    target 415
    type "dominant"
  ]
  edge [
    source 289
    target 27
    type "dominant"
  ]
  edge [
    source 289
    target 168
    type "dominant"
  ]
  edge [
    source 289
    target 170
    type "dominant"
  ]
  edge [
    source 289
    target 288
    type "dominant"
  ]
  edge [
    source 289
    target 308
    type "dominant"
  ]
  edge [
    source 290
    target 168
    type "dominant"
  ]
  edge [
    source 290
    target 393
    type "neutral"
  ]
  edge [
    source 290
    target 551
    type "neutral"
  ]
  edge [
    source 290
    target 409
    type "dominant"
  ]
  edge [
    source 291
    target 166
    type "dominant"
  ]
  edge [
    source 291
    target 337
    type "dominant"
  ]
  edge [
    source 291
    target 492
    type "dominant"
  ]
  edge [
    source 292
    target 291
    type "dominant"
  ]
  edge [
    source 292
    target 337
    type "dominant"
  ]
  edge [
    source 292
    target 475
    type "dominant"
  ]
  edge [
    source 293
    target 291
    type "dominant"
  ]
  edge [
    source 293
    target 437
    type "neutral"
  ]
  edge [
    source 293
    target 565
    type "dominant"
  ]
  edge [
    source 293
    target 700
    type "dominant"
  ]
  edge [
    source 294
    target 291
    type "dominant"
  ]
  edge [
    source 294
    target 297
    type "neutral"
  ]
  edge [
    source 295
    target 291
    type "dominant"
  ]
  edge [
    source 295
    target 337
    type "dominant"
  ]
  edge [
    source 296
    target 291
    type "dominant"
  ]
  edge [
    source 296
    target 502
    type "dominant"
  ]
  edge [
    source 296
    target 815
    type "dominant"
  ]
  edge [
    source 297
    target 135
    type "dominant"
  ]
  edge [
    source 297
    target 138
    type "dominant"
  ]
  edge [
    source 297
    target 298
    type "neutral"
  ]
  edge [
    source 298
    target 138
    type "dominant"
  ]
  edge [
    source 298
    target 820
    type "dominant"
  ]
  edge [
    source 299
    target 681
    type "dominant"
  ]
  edge [
    source 300
    target 299
    type "dominant"
  ]
  edge [
    source 300
    target 306
    type "dominant"
  ]
  edge [
    source 300
    target 379
    type "dominant"
  ]
  edge [
    source 301
    target 299
    type "dominant"
  ]
  edge [
    source 301
    target 573
    type "neutral"
  ]
  edge [
    source 302
    target 265
    type "dominant"
  ]
  edge [
    source 302
    target 529
    type "dominant"
  ]
  edge [
    source 302
    target 697
    type "dominant"
  ]
  edge [
    source 303
    target 305
    type "neutral"
  ]
  edge [
    source 303
    target 306
    type "dominant"
  ]
  edge [
    source 303
    target 496
    type "dominant"
  ]
  edge [
    source 303
    target 556
    type "dominant"
  ]
  edge [
    source 303
    target 700
    type "dominant"
  ]
  edge [
    source 304
    target 7
    type "dominant"
  ]
  edge [
    source 304
    target 195
    type "dominant"
  ]
  edge [
    source 304
    target 265
    type "dominant"
  ]
  edge [
    source 304
    target 782
    type "dominant"
  ]
  edge [
    source 304
    target 810
    type "dominant"
  ]
  edge [
    source 305
    target 267
    type "dominant"
  ]
  edge [
    source 305
    target 306
    type "neutral"
  ]
  edge [
    source 305
    target 331
    type "dominant"
  ]
  edge [
    source 305
    target 527
    type "dominant"
  ]
  edge [
    source 305
    target 778
    type "dominant"
  ]
  edge [
    source 306
    target 281
    type "dominant"
  ]
  edge [
    source 306
    target 482
    type "dominant"
  ]
  edge [
    source 307
    target 10
    type "dominant"
  ]
  edge [
    source 308
    target 162
    type "dominant"
  ]
  edge [
    source 308
    target 217
    type "dominant"
  ]
  edge [
    source 308
    target 288
    type "dominant"
  ]
  edge [
    source 308
    target 310
    type "neutral"
  ]
  edge [
    source 308
    target 632
    type "dominant"
  ]
  edge [
    source 308
    target 775
    type "dominant"
  ]
  edge [
    source 309
    target 308
    type "dominant"
  ]
  edge [
    source 309
    target 724
    type "dominant"
  ]
  edge [
    source 310
    target 430
    type "dominant"
  ]
  edge [
    source 310
    target 775
    type "dominant"
  ]
  edge [
    source 311
    target 386
    type "dominant"
  ]
  edge [
    source 311
    target 387
    type "dominant"
  ]
  edge [
    source 312
    target 311
    type "dominant"
  ]
  edge [
    source 312
    target 566
    type "neutral"
  ]
  edge [
    source 312
    target 827
    type "dominant"
  ]
  edge [
    source 313
    target 109
    type "dominant"
  ]
  edge [
    source 313
    target 463
    type "dominant"
  ]
  edge [
    source 313
    target 508
    type "dominant"
  ]
  edge [
    source 313
    target 668
    type "dominant"
  ]
  edge [
    source 313
    target 771
    type "dominant"
  ]
  edge [
    source 314
    target 212
    type "dominant"
  ]
  edge [
    source 314
    target 313
    type "dominant"
  ]
  edge [
    source 314
    target 356
    type "neutral"
  ]
  edge [
    source 314
    target 316
    type "dominant"
  ]
  edge [
    source 314
    target 774
    type "dominant"
  ]
  edge [
    source 315
    target 313
    type "dominant"
  ]
  edge [
    source 315
    target 713
    type "dominant"
  ]
  edge [
    source 315
    target 801
    type "dominant"
  ]
  edge [
    source 316
    target 313
    type "dominant"
  ]
  edge [
    source 317
    target 318
    type "neutral"
  ]
  edge [
    source 317
    target 319
    type "neutral"
  ]
  edge [
    source 317
    target 393
    type "dominant"
  ]
  edge [
    source 317
    target 587
    type "dominant"
  ]
  edge [
    source 317
    target 712
    type "dominant"
  ]
  edge [
    source 318
    target 393
    type "dominant"
  ]
  edge [
    source 318
    target 457
    type "dominant"
  ]
  edge [
    source 318
    target 597
    type "dominant"
  ]
  edge [
    source 319
    target 393
    type "neutral"
  ]
  edge [
    source 319
    target 406
    type "dominant"
  ]
  edge [
    source 319
    target 556
    type "dominant"
  ]
  edge [
    source 319
    target 587
    type "dominant"
  ]
  edge [
    source 319
    target 640
    type "dominant"
  ]
  edge [
    source 319
    target 694
    type "dominant"
  ]
  edge [
    source 319
    target 712
    type "dominant"
  ]
  edge [
    source 320
    target 175
    type "dominant"
  ]
  edge [
    source 320
    target 317
    type "dominant"
  ]
  edge [
    source 320
    target 319
    type "dominant"
  ]
  edge [
    source 320
    target 555
    type "neutral"
  ]
  edge [
    source 320
    target 388
    type "dominant"
  ]
  edge [
    source 322
    target 314
    type "dominant"
  ]
  edge [
    source 322
    target 316
    type "dominant"
  ]
  edge [
    source 322
    target 321
    type "dominant"
  ]
  edge [
    source 322
    target 356
    type "dominant"
  ]
  edge [
    source 322
    target 357
    type "dominant"
  ]
  edge [
    source 322
    target 677
    type "dominant"
  ]
  edge [
    source 322
    target 685
    type "dominant"
  ]
  edge [
    source 322
    target 774
    type "dominant"
  ]
  edge [
    source 323
    target 52
    type "dominant"
  ]
  edge [
    source 323
    target 191
    type "dominant"
  ]
  edge [
    source 323
    target 321
    type "dominant"
  ]
  edge [
    source 323
    target 344
    type "neutral"
  ]
  edge [
    source 323
    target 526
    type "dominant"
  ]
  edge [
    source 323
    target 676
    type "dominant"
  ]
  edge [
    source 324
    target 195
    type "dominant"
  ]
  edge [
    source 324
    target 514
    type "neutral"
  ]
  edge [
    source 324
    target 535
    type "neutral"
  ]
  edge [
    source 324
    target 513
    type "dominant"
  ]
  edge [
    source 324
    target 660
    type "dominant"
  ]
  edge [
    source 325
    target 326
    type "neutral"
  ]
  edge [
    source 325
    target 568
    type "dominant"
  ]
  edge [
    source 326
    target 323
    type "dominant"
  ]
  edge [
    source 326
    target 344
    type "dominant"
  ]
  edge [
    source 326
    target 382
    type "dominant"
  ]
  edge [
    source 326
    target 562
    type "dominant"
  ]
  edge [
    source 326
    target 572
    type "dominant"
  ]
  edge [
    source 327
    target 325
    type "dominant"
  ]
  edge [
    source 327
    target 818
    type "dominant"
  ]
  edge [
    source 328
    target 325
    type "dominant"
  ]
  edge [
    source 329
    target 585
    type "dominant"
  ]
  edge [
    source 329
    target 610
    type "dominant"
  ]
  edge [
    source 330
    target 329
    type "dominant"
  ]
  edge [
    source 330
    target 331
    type "neutral"
  ]
  edge [
    source 330
    target 332
    type "neutral"
  ]
  edge [
    source 330
    target 337
    type "neutral"
  ]
  edge [
    source 331
    target 72
    type "dominant"
  ]
  edge [
    source 331
    target 332
    type "neutral"
  ]
  edge [
    source 331
    target 565
    type "dominant"
  ]
  edge [
    source 332
    target 243
    type "dominant"
  ]
  edge [
    source 332
    target 344
    type "neutral"
  ]
  edge [
    source 332
    target 618
    type "dominant"
  ]
  edge [
    source 333
    target 331
    type "dominant"
  ]
  edge [
    source 333
    target 565
    type "dominant"
  ]
  edge [
    source 334
    target 331
    type "dominant"
  ]
  edge [
    source 334
    target 417
    type "neutral"
  ]
  edge [
    source 334
    target 660
    type "neutral"
  ]
  edge [
    source 334
    target 543
    type "dominant"
  ]
  edge [
    source 335
    target 327
    type "dominant"
  ]
  edge [
    source 335
    target 342
    type "dominant"
  ]
  edge [
    source 335
    target 687
    type "dominant"
  ]
  edge [
    source 335
    target 800
    type "dominant"
  ]
  edge [
    source 336
    target 330
    type "dominant"
  ]
  edge [
    source 336
    target 332
    type "dominant"
  ]
  edge [
    source 339
    target 338
    type "dominant"
  ]
  edge [
    source 339
    target 732
    type "dominant"
  ]
  edge [
    source 340
    target 341
    type "neutral"
  ]
  edge [
    source 340
    target 483
    type "dominant"
  ]
  edge [
    source 341
    target 457
    type "neutral"
  ]
  edge [
    source 342
    target 665
    type "dominant"
  ]
  edge [
    source 343
    target 23
    type "dominant"
  ]
  edge [
    source 343
    target 335
    type "dominant"
  ]
  edge [
    source 343
    target 342
    type "dominant"
  ]
  edge [
    source 343
    target 422
    type "dominant"
  ]
  edge [
    source 343
    target 800
    type "dominant"
  ]
  edge [
    source 344
    target 191
    type "dominant"
  ]
  edge [
    source 344
    target 501
    type "dominant"
  ]
  edge [
    source 344
    target 559
    type "dominant"
  ]
  edge [
    source 344
    target 565
    type "dominant"
  ]
  edge [
    source 344
    target 614
    type "dominant"
  ]
  edge [
    source 344
    target 615
    type "dominant"
  ]
  edge [
    source 344
    target 618
    type "dominant"
  ]
  edge [
    source 344
    target 735
    type "dominant"
  ]
  edge [
    source 344
    target 773
    type "dominant"
  ]
  edge [
    source 344
    target 799
    type "dominant"
  ]
  edge [
    source 345
    target 83
    type "dominant"
  ]
  edge [
    source 345
    target 94
    type "dominant"
  ]
  edge [
    source 345
    target 344
    type "dominant"
  ]
  edge [
    source 345
    target 383
    type "dominant"
  ]
  edge [
    source 345
    target 703
    type "dominant"
  ]
  edge [
    source 346
    target 104
    type "dominant"
  ]
  edge [
    source 346
    target 344
    type "dominant"
  ]
  edge [
    source 346
    target 500
    type "dominant"
  ]
  edge [
    source 346
    target 751
    type "dominant"
  ]
  edge [
    source 346
    target 801
    type "dominant"
  ]
  edge [
    source 347
    target 349
    type "neutral"
  ]
  edge [
    source 347
    target 352
    type "neutral"
  ]
  edge [
    source 347
    target 571
    type "dominant"
  ]
  edge [
    source 347
    target 689
    type "dominant"
  ]
  edge [
    source 347
    target 690
    type "dominant"
  ]
  edge [
    source 347
    target 811
    type "dominant"
  ]
  edge [
    source 348
    target 347
    type "dominant"
  ]
  edge [
    source 348
    target 504
    type "dominant"
  ]
  edge [
    source 348
    target 811
    type "dominant"
  ]
  edge [
    source 349
    target 352
    type "neutral"
  ]
  edge [
    source 349
    target 563
    type "dominant"
  ]
  edge [
    source 349
    target 568
    type "dominant"
  ]
  edge [
    source 349
    target 571
    type "dominant"
  ]
  edge [
    source 349
    target 694
    type "dominant"
  ]
  edge [
    source 349
    target 811
    type "dominant"
  ]
  edge [
    source 350
    target 21
    type "dominant"
  ]
  edge [
    source 350
    target 54
    type "dominant"
  ]
  edge [
    source 350
    target 90
    type "dominant"
  ]
  edge [
    source 350
    target 334
    type "dominant"
  ]
  edge [
    source 350
    target 335
    type "dominant"
  ]
  edge [
    source 350
    target 347
    type "dominant"
  ]
  edge [
    source 350
    target 571
    type "dominant"
  ]
  edge [
    source 350
    target 628
    type "dominant"
  ]
  edge [
    source 351
    target 347
    type "dominant"
  ]
  edge [
    source 351
    target 349
    type "dominant"
  ]
  edge [
    source 351
    target 563
    type "dominant"
  ]
  edge [
    source 351
    target 690
    type "dominant"
  ]
  edge [
    source 352
    target 46
    type "dominant"
  ]
  edge [
    source 352
    target 172
    type "dominant"
  ]
  edge [
    source 352
    target 612
    type "dominant"
  ]
  edge [
    source 352
    target 628
    type "dominant"
  ]
  edge [
    source 352
    target 689
    type "dominant"
  ]
  edge [
    source 352
    target 694
    type "dominant"
  ]
  edge [
    source 353
    target 115
    type "dominant"
  ]
  edge [
    source 353
    target 354
    type "neutral"
  ]
  edge [
    source 353
    target 422
    type "dominant"
  ]
  edge [
    source 353
    target 540
    type "dominant"
  ]
  edge [
    source 353
    target 632
    type "dominant"
  ]
  edge [
    source 354
    target 607
    type "dominant"
  ]
  edge [
    source 354
    target 619
    type "dominant"
  ]
  edge [
    source 355
    target 361
    type "neutral"
  ]
  edge [
    source 355
    target 630
    type "dominant"
  ]
  edge [
    source 356
    target 212
    type "dominant"
  ]
  edge [
    source 356
    target 668
    type "neutral"
  ]
  edge [
    source 356
    target 357
    type "neutral"
  ]
  edge [
    source 356
    target 363
    type "dominant"
  ]
  edge [
    source 356
    target 456
    type "dominant"
  ]
  edge [
    source 356
    target 685
    type "dominant"
  ]
  edge [
    source 356
    target 774
    type "dominant"
  ]
  edge [
    source 356
    target 786
    type "dominant"
  ]
  edge [
    source 356
    target 814
    type "dominant"
  ]
  edge [
    source 357
    target 314
    type "dominant"
  ]
  edge [
    source 357
    target 363
    type "neutral"
  ]
  edge [
    source 357
    target 666
    type "dominant"
  ]
  edge [
    source 357
    target 668
    type "dominant"
  ]
  edge [
    source 357
    target 774
    type "dominant"
  ]
  edge [
    source 358
    target 360
    type "neutral"
  ]
  edge [
    source 359
    target 358
    type "dominant"
  ]
  edge [
    source 360
    target 354
    type "dominant"
  ]
  edge [
    source 361
    target 46
    type "dominant"
  ]
  edge [
    source 361
    target 362
    type "neutral"
  ]
  edge [
    source 361
    target 685
    type "dominant"
  ]
  edge [
    source 361
    target 743
    type "dominant"
  ]
  edge [
    source 362
    target 241
    type "dominant"
  ]
  edge [
    source 362
    target 434
    type "neutral"
  ]
  edge [
    source 362
    target 435
    type "neutral"
  ]
  edge [
    source 362
    target 483
    type "dominant"
  ]
  edge [
    source 363
    target 774
    type "dominant"
  ]
  edge [
    source 365
    target 364
    type "dominant"
  ]
  edge [
    source 365
    target 547
    type "dominant"
  ]
  edge [
    source 366
    target 332
    type "dominant"
  ]
  edge [
    source 366
    target 511
    type "dominant"
  ]
  edge [
    source 366
    target 565
    type "dominant"
  ]
  edge [
    source 366
    target 618
    type "dominant"
  ]
  edge [
    source 367
    target 332
    type "dominant"
  ]
  edge [
    source 368
    target 288
    type "dominant"
  ]
  edge [
    source 368
    target 415
    type "dominant"
  ]
  edge [
    source 368
    target 775
    type "dominant"
  ]
  edge [
    source 369
    target 192
    type "dominant"
  ]
  edge [
    source 369
    target 578
    type "dominant"
  ]
  edge [
    source 369
    target 593
    type "dominant"
  ]
  edge [
    source 369
    target 609
    type "dominant"
  ]
  edge [
    source 369
    target 643
    type "dominant"
  ]
  edge [
    source 369
    target 731
    type "dominant"
  ]
  edge [
    source 369
    target 804
    type "dominant"
  ]
  edge [
    source 369
    target 805
    type "dominant"
  ]
  edge [
    source 370
    target 339
    type "dominant"
  ]
  edge [
    source 370
    target 369
    type "dominant"
  ]
  edge [
    source 370
    target 423
    type "dominant"
  ]
  edge [
    source 370
    target 424
    type "dominant"
  ]
  edge [
    source 370
    target 476
    type "dominant"
  ]
  edge [
    source 370
    target 481
    type "dominant"
  ]
  edge [
    source 370
    target 643
    type "dominant"
  ]
  edge [
    source 370
    target 731
    type "dominant"
  ]
  edge [
    source 370
    target 777
    type "dominant"
  ]
  edge [
    source 371
    target 192
    type "dominant"
  ]
  edge [
    source 371
    target 537
    type "neutral"
  ]
  edge [
    source 371
    target 374
    type "neutral"
  ]
  edge [
    source 372
    target 371
    type "dominant"
  ]
  edge [
    source 372
    target 374
    type "dominant"
  ]
  edge [
    source 372
    target 545
    type "dominant"
  ]
  edge [
    source 372
    target 691
    type "dominant"
  ]
  edge [
    source 373
    target 178
    type "dominant"
  ]
  edge [
    source 373
    target 255
    type "dominant"
  ]
  edge [
    source 374
    target 551
    type "dominant"
  ]
  edge [
    source 374
    target 691
    type "dominant"
  ]
  edge [
    source 376
    target 375
    type "dominant"
  ]
  edge [
    source 376
    target 377
    type "neutral"
  ]
  edge [
    source 376
    target 378
    type "dominant"
  ]
  edge [
    source 377
    target 375
    type "dominant"
  ]
  edge [
    source 377
    target 378
    type "neutral"
  ]
  edge [
    source 378
    target 375
    type "dominant"
  ]
  edge [
    source 378
    target 640
    type "dominant"
  ]
  edge [
    source 378
    target 796
    type "dominant"
  ]
  edge [
    source 381
    target 111
    type "dominant"
  ]
  edge [
    source 381
    target 380
    type "dominant"
  ]
  edge [
    source 381
    target 515
    type "dominant"
  ]
  edge [
    source 381
    target 625
    type "dominant"
  ]
  edge [
    source 384
    target 383
    type "dominant"
  ]
  edge [
    source 385
    target 383
    type "dominant"
  ]
  edge [
    source 385
    target 540
    type "dominant"
  ]
  edge [
    source 385
    target 689
    type "dominant"
  ]
  edge [
    source 387
    target 386
    type "dominant"
  ]
  edge [
    source 387
    target 616
    type "dominant"
  ]
  edge [
    source 388
    target 386
    type "dominant"
  ]
  edge [
    source 388
    target 387
    type "dominant"
  ]
  edge [
    source 388
    target 555
    type "neutral"
  ]
  edge [
    source 388
    target 428
    type "dominant"
  ]
  edge [
    source 388
    target 787
    type "dominant"
  ]
  edge [
    source 390
    target 74
    type "dominant"
  ]
  edge [
    source 390
    target 389
    type "dominant"
  ]
  edge [
    source 390
    target 457
    type "dominant"
  ]
  edge [
    source 390
    target 621
    type "dominant"
  ]
  edge [
    source 393
    target 138
    type "dominant"
  ]
  edge [
    source 393
    target 392
    type "dominant"
  ]
  edge [
    source 393
    target 421
    type "neutral"
  ]
  edge [
    source 393
    target 427
    type "dominant"
  ]
  edge [
    source 393
    target 587
    type "dominant"
  ]
  edge [
    source 393
    target 671
    type "dominant"
  ]
  edge [
    source 393
    target 712
    type "dominant"
  ]
  edge [
    source 395
    target 394
    type "dominant"
  ]
  edge [
    source 395
    target 595
    type "dominant"
  ]
  edge [
    source 395
    target 682
    type "dominant"
  ]
  edge [
    source 397
    target 163
    type "dominant"
  ]
  edge [
    source 397
    target 396
    type "dominant"
  ]
  edge [
    source 401
    target 400
    type "dominant"
  ]
  edge [
    source 401
    target 548
    type "neutral"
  ]
  edge [
    source 401
    target 631
    type "dominant"
  ]
  edge [
    source 401
    target 658
    type "dominant"
  ]
  edge [
    source 401
    target 805
    type "dominant"
  ]
  edge [
    source 403
    target 138
    type "dominant"
  ]
  edge [
    source 403
    target 402
    type "dominant"
  ]
  edge [
    source 403
    target 454
    type "neutral"
  ]
  edge [
    source 403
    target 569
    type "dominant"
  ]
  edge [
    source 403
    target 775
    type "dominant"
  ]
  edge [
    source 404
    target 170
    type "dominant"
  ]
  edge [
    source 404
    target 402
    type "dominant"
  ]
  edge [
    source 404
    target 454
    type "neutral"
  ]
  edge [
    source 404
    target 530
    type "dominant"
  ]
  edge [
    source 405
    target 402
    type "dominant"
  ]
  edge [
    source 407
    target 406
    type "dominant"
  ]
  edge [
    source 407
    target 420
    type "neutral"
  ]
  edge [
    source 408
    target 181
    type "dominant"
  ]
  edge [
    source 408
    target 406
    type "dominant"
  ]
  edge [
    source 408
    target 788
    type "dominant"
  ]
  edge [
    source 411
    target 410
    type "dominant"
  ]
  edge [
    source 411
    target 657
    type "neutral"
  ]
  edge [
    source 416
    target 163
    type "dominant"
  ]
  edge [
    source 416
    target 415
    type "dominant"
  ]
  edge [
    source 416
    target 418
    type "dominant"
  ]
  edge [
    source 416
    target 626
    type "dominant"
  ]
  edge [
    source 417
    target 415
    type "dominant"
  ]
  edge [
    source 418
    target 163
    type "dominant"
  ]
  edge [
    source 418
    target 415
    type "dominant"
  ]
  edge [
    source 418
    target 471
    type "neutral"
  ]
  edge [
    source 420
    target 419
    type "dominant"
  ]
  edge [
    source 421
    target 419
    type "dominant"
  ]
  edge [
    source 424
    target 423
    type "dominant"
  ]
  edge [
    source 424
    target 477
    type "neutral"
  ]
  edge [
    source 424
    target 439
    type "dominant"
  ]
  edge [
    source 424
    target 696
    type "dominant"
  ]
  edge [
    source 425
    target 14
    type "dominant"
  ]
  edge [
    source 425
    target 423
    type "dominant"
  ]
  edge [
    source 425
    target 585
    type "dominant"
  ]
  edge [
    source 425
    target 777
    type "dominant"
  ]
  edge [
    source 425
    target 826
    type "dominant"
  ]
  edge [
    source 426
    target 423
    type "dominant"
  ]
  edge [
    source 426
    target 777
    type "dominant"
  ]
  edge [
    source 429
    target 428
    type "dominant"
  ]
  edge [
    source 429
    target 667
    type "dominant"
  ]
  edge [
    source 430
    target 78
    type "dominant"
  ]
  edge [
    source 430
    target 431
    type "neutral"
  ]
  edge [
    source 431
    target 78
    type "dominant"
  ]
  edge [
    source 431
    target 495
    type "dominant"
  ]
  edge [
    source 431
    target 522
    type "dominant"
  ]
  edge [
    source 432
    target 326
    type "dominant"
  ]
  edge [
    source 432
    target 765
    type "dominant"
  ]
  edge [
    source 433
    target 326
    type "dominant"
  ]
  edge [
    source 433
    target 432
    type "dominant"
  ]
  edge [
    source 433
    target 765
    type "dominant"
  ]
  edge [
    source 434
    target 494
    type "neutral"
  ]
  edge [
    source 434
    target 435
    type "neutral"
  ]
  edge [
    source 435
    target 494
    type "neutral"
  ]
  edge [
    source 435
    target 508
    type "dominant"
  ]
  edge [
    source 435
    target 807
    type "dominant"
  ]
  edge [
    source 436
    target 647
    type "dominant"
  ]
  edge [
    source 436
    target 777
    type "dominant"
  ]
  edge [
    source 436
    target 805
    type "dominant"
  ]
  edge [
    source 436
    target 824
    type "dominant"
  ]
  edge [
    source 437
    target 176
    type "dominant"
  ]
  edge [
    source 437
    target 822
    type "dominant"
  ]
  edge [
    source 438
    target 44
    type "dominant"
  ]
  edge [
    source 438
    target 467
    type "dominant"
  ]
  edge [
    source 438
    target 748
    type "dominant"
  ]
  edge [
    source 439
    target 384
    type "dominant"
  ]
  edge [
    source 439
    target 476
    type "neutral"
  ]
  edge [
    source 439
    target 610
    type "neutral"
  ]
  edge [
    source 439
    target 477
    type "neutral"
  ]
  edge [
    source 439
    target 696
    type "dominant"
  ]
  edge [
    source 439
    target 799
    type "dominant"
  ]
  edge [
    source 441
    target 170
    type "dominant"
  ]
  edge [
    source 441
    target 440
    type "dominant"
  ]
  edge [
    source 442
    target 151
    type "dominant"
  ]
  edge [
    source 442
    target 440
    type "dominant"
  ]
  edge [
    source 442
    target 543
    type "dominant"
  ]
  edge [
    source 442
    target 717
    type "dominant"
  ]
  edge [
    source 443
    target 116
    type "dominant"
  ]
  edge [
    source 444
    target 446
    type "neutral"
  ]
  edge [
    source 444
    target 448
    type "neutral"
  ]
  edge [
    source 444
    target 524
    type "dominant"
  ]
  edge [
    source 444
    target 525
    type "dominant"
  ]
  edge [
    source 444
    target 766
    type "dominant"
  ]
  edge [
    source 444
    target 781
    type "dominant"
  ]
  edge [
    source 445
    target 444
    type "dominant"
  ]
  edge [
    source 445
    target 524
    type "dominant"
  ]
  edge [
    source 446
    target 155
    type "dominant"
  ]
  edge [
    source 446
    target 525
    type "neutral"
  ]
  edge [
    source 446
    target 448
    type "dominant"
  ]
  edge [
    source 446
    target 524
    type "dominant"
  ]
  edge [
    source 446
    target 766
    type "dominant"
  ]
  edge [
    source 446
    target 781
    type "dominant"
  ]
  edge [
    source 447
    target 444
    type "dominant"
  ]
  edge [
    source 447
    target 446
    type "dominant"
  ]
  edge [
    source 447
    target 448
    type "dominant"
  ]
  edge [
    source 447
    target 524
    type "dominant"
  ]
  edge [
    source 447
    target 657
    type "dominant"
  ]
  edge [
    source 447
    target 781
    type "dominant"
  ]
  edge [
    source 448
    target 445
    type "dominant"
  ]
  edge [
    source 449
    target 690
    type "dominant"
  ]
  edge [
    source 450
    target 381
    type "dominant"
  ]
  edge [
    source 451
    target 1
    type "dominant"
  ]
  edge [
    source 451
    target 452
    type "neutral"
  ]
  edge [
    source 451
    target 482
    type "dominant"
  ]
  edge [
    source 452
    target 482
    type "neutral"
  ]
  edge [
    source 452
    target 562
    type "dominant"
  ]
  edge [
    source 453
    target 451
    type "dominant"
  ]
  edge [
    source 453
    target 452
    type "dominant"
  ]
  edge [
    source 453
    target 590
    type "neutral"
  ]
  edge [
    source 453
    target 591
    type "neutral"
  ]
  edge [
    source 453
    target 716
    type "neutral"
  ]
  edge [
    source 454
    target 569
    type "dominant"
  ]
  edge [
    source 455
    target 613
    type "dominant"
  ]
  edge [
    source 456
    target 83
    type "dominant"
  ]
  edge [
    source 456
    target 455
    type "dominant"
  ]
  edge [
    source 456
    target 615
    type "dominant"
  ]
  edge [
    source 456
    target 617
    type "dominant"
  ]
  edge [
    source 456
    target 799
    type "dominant"
  ]
  edge [
    source 457
    target 74
    type "dominant"
  ]
  edge [
    source 457
    target 90
    type "dominant"
  ]
  edge [
    source 457
    target 540
    type "dominant"
  ]
  edge [
    source 457
    target 640
    type "dominant"
  ]
  edge [
    source 457
    target 679
    type "dominant"
  ]
  edge [
    source 457
    target 682
    type "dominant"
  ]
  edge [
    source 458
    target 90
    type "dominant"
  ]
  edge [
    source 460
    target 407
    type "dominant"
  ]
  edge [
    source 461
    target 462
    type "neutral"
  ]
  edge [
    source 461
    target 465
    type "neutral"
  ]
  edge [
    source 461
    target 762
    type "dominant"
  ]
  edge [
    source 463
    target 461
    type "dominant"
  ]
  edge [
    source 463
    target 652
    type "neutral"
  ]
  edge [
    source 463
    target 464
    type "dominant"
  ]
  edge [
    source 463
    target 531
    type "dominant"
  ]
  edge [
    source 464
    target 461
    type "dominant"
  ]
  edge [
    source 464
    target 465
    type "neutral"
  ]
  edge [
    source 465
    target 354
    type "dominant"
  ]
  edge [
    source 465
    target 619
    type "dominant"
  ]
  edge [
    source 466
    target 97
    type "dominant"
  ]
  edge [
    source 466
    target 816
    type "dominant"
  ]
  edge [
    source 467
    target 97
    type "dominant"
  ]
  edge [
    source 467
    target 173
    type "dominant"
  ]
  edge [
    source 468
    target 146
    type "dominant"
  ]
  edge [
    source 468
    target 150
    type "dominant"
  ]
  edge [
    source 469
    target 146
    type "dominant"
  ]
  edge [
    source 469
    target 147
    type "dominant"
  ]
  edge [
    source 469
    target 155
    type "dominant"
  ]
  edge [
    source 469
    target 552
    type "neutral"
  ]
  edge [
    source 469
    target 644
    type "dominant"
  ]
  edge [
    source 471
    target 472
    type "neutral"
  ]
  edge [
    source 473
    target 150
    type "dominant"
  ]
  edge [
    source 473
    target 471
    type "dominant"
  ]
  edge [
    source 474
    target 266
    type "dominant"
  ]
  edge [
    source 474
    target 678
    type "dominant"
  ]
  edge [
    source 474
    target 791
    type "dominant"
  ]
  edge [
    source 475
    target 38
    type "dominant"
  ]
  edge [
    source 475
    target 453
    type "dominant"
  ]
  edge [
    source 475
    target 497
    type "neutral"
  ]
  edge [
    source 475
    target 488
    type "dominant"
  ]
  edge [
    source 475
    target 526
    type "dominant"
  ]
  edge [
    source 476
    target 477
    type "neutral"
  ]
  edge [
    source 476
    target 696
    type "dominant"
  ]
  edge [
    source 477
    target 14
    type "dominant"
  ]
  edge [
    source 477
    target 585
    type "dominant"
  ]
  edge [
    source 477
    target 696
    type "dominant"
  ]
  edge [
    source 477
    target 777
    type "dominant"
  ]
  edge [
    source 477
    target 805
    type "dominant"
  ]
  edge [
    source 478
    target 424
    type "dominant"
  ]
  edge [
    source 479
    target 424
    type "dominant"
  ]
  edge [
    source 479
    target 805
    type "dominant"
  ]
  edge [
    source 480
    target 424
    type "dominant"
  ]
  edge [
    source 481
    target 424
    type "dominant"
  ]
  edge [
    source 481
    target 643
    type "dominant"
  ]
  edge [
    source 481
    target 696
    type "dominant"
  ]
  edge [
    source 481
    target 731
    type "dominant"
  ]
  edge [
    source 482
    target 583
    type "dominant"
  ]
  edge [
    source 482
    target 676
    type "dominant"
  ]
  edge [
    source 483
    target 445
    type "dominant"
  ]
  edge [
    source 484
    target 241
    type "dominant"
  ]
  edge [
    source 484
    target 483
    type "dominant"
  ]
  edge [
    source 484
    target 493
    type "dominant"
  ]
  edge [
    source 484
    target 751
    type "dominant"
  ]
  edge [
    source 484
    target 814
    type "dominant"
  ]
  edge [
    source 485
    target 483
    type "dominant"
  ]
  edge [
    source 485
    target 702
    type "dominant"
  ]
  edge [
    source 486
    target 137
    type "dominant"
  ]
  edge [
    source 487
    target 452
    type "dominant"
  ]
  edge [
    source 487
    target 495
    type "dominant"
  ]
  edge [
    source 487
    target 724
    type "dominant"
  ]
  edge [
    source 488
    target 417
    type "dominant"
  ]
  edge [
    source 489
    target 488
    type "dominant"
  ]
  edge [
    source 494
    target 493
    type "dominant"
  ]
  edge [
    source 494
    target 786
    type "dominant"
  ]
  edge [
    source 497
    target 77
    type "dominant"
  ]
  edge [
    source 497
    target 496
    type "dominant"
  ]
  edge [
    source 499
    target 72
    type "dominant"
  ]
  edge [
    source 499
    target 498
    type "dominant"
  ]
  edge [
    source 499
    target 582
    type "dominant"
  ]
  edge [
    source 500
    target 498
    type "dominant"
  ]
  edge [
    source 500
    target 599
    type "neutral"
  ]
  edge [
    source 501
    target 498
    type "dominant"
  ]
  edge [
    source 503
    target 502
    type "dominant"
  ]
  edge [
    source 503
    target 756
    type "dominant"
  ]
  edge [
    source 503
    target 815
    type "dominant"
  ]
  edge [
    source 505
    target 504
    type "dominant"
  ]
  edge [
    source 505
    target 661
    type "neutral"
  ]
  edge [
    source 505
    target 640
    type "dominant"
  ]
  edge [
    source 507
    target 506
    type "dominant"
  ]
  edge [
    source 510
    target 509
    type "dominant"
  ]
  edge [
    source 510
    target 517
    type "dominant"
  ]
  edge [
    source 510
    target 543
    type "dominant"
  ]
  edge [
    source 511
    target 509
    type "dominant"
  ]
  edge [
    source 511
    target 565
    type "dominant"
  ]
  edge [
    source 512
    target 60
    type "dominant"
  ]
  edge [
    source 512
    target 509
    type "dominant"
  ]
  edge [
    source 512
    target 511
    type "dominant"
  ]
  edge [
    source 514
    target 420
    type "dominant"
  ]
  edge [
    source 514
    target 513
    type "dominant"
  ]
  edge [
    source 515
    target 513
    type "dominant"
  ]
  edge [
    source 515
    target 625
    type "dominant"
  ]
  edge [
    source 515
    target 658
    type "dominant"
  ]
  edge [
    source 519
    target 59
    type "dominant"
  ]
  edge [
    source 519
    target 518
    type "dominant"
  ]
  edge [
    source 519
    target 520
    type "neutral"
  ]
  edge [
    source 519
    target 599
    type "dominant"
  ]
  edge [
    source 519
    target 623
    type "dominant"
  ]
  edge [
    source 519
    target 629
    type "dominant"
  ]
  edge [
    source 519
    target 705
    type "dominant"
  ]
  edge [
    source 520
    target 518
    type "dominant"
  ]
  edge [
    source 520
    target 705
    type "neutral"
  ]
  edge [
    source 520
    target 686
    type "dominant"
  ]
  edge [
    source 521
    target 301
    type "dominant"
  ]
  edge [
    source 521
    target 518
    type "dominant"
  ]
  edge [
    source 521
    target 573
    type "dominant"
  ]
  edge [
    source 525
    target 524
    type "dominant"
  ]
  edge [
    source 525
    target 781
    type "dominant"
  ]
  edge [
    source 527
    target 372
    type "dominant"
  ]
  edge [
    source 527
    target 526
    type "dominant"
  ]
  edge [
    source 527
    target 562
    type "dominant"
  ]
  edge [
    source 527
    target 565
    type "dominant"
  ]
  edge [
    source 528
    target 526
    type "dominant"
  ]
  edge [
    source 528
    target 592
    type "dominant"
  ]
  edge [
    source 528
    target 796
    type "dominant"
  ]
  edge [
    source 531
    target 567
    type "dominant"
  ]
  edge [
    source 531
    target 652
    type "dominant"
  ]
  edge [
    source 532
    target 596
    type "neutral"
  ]
  edge [
    source 532
    target 734
    type "dominant"
  ]
  edge [
    source 532
    target 806
    type "dominant"
  ]
  edge [
    source 533
    target 597
    type "neutral"
  ]
  edge [
    source 533
    target 810
    type "dominant"
  ]
  edge [
    source 534
    target 7
    type "dominant"
  ]
  edge [
    source 534
    target 580
    type "dominant"
  ]
  edge [
    source 534
    target 589
    type "dominant"
  ]
  edge [
    source 534
    target 592
    type "dominant"
  ]
  edge [
    source 534
    target 698
    type "dominant"
  ]
  edge [
    source 534
    target 769
    type "dominant"
  ]
  edge [
    source 534
    target 817
    type "dominant"
  ]
  edge [
    source 535
    target 303
    type "dominant"
  ]
  edge [
    source 535
    target 532
    type "dominant"
  ]
  edge [
    source 535
    target 596
    type "neutral"
  ]
  edge [
    source 535
    target 806
    type "dominant"
  ]
  edge [
    source 537
    target 67
    type "dominant"
  ]
  edge [
    source 537
    target 231
    type "dominant"
  ]
  edge [
    source 537
    target 646
    type "neutral"
  ]
  edge [
    source 539
    target 538
    type "dominant"
  ]
  edge [
    source 541
    target 540
    type "dominant"
  ]
  edge [
    source 542
    target 540
    type "dominant"
  ]
  edge [
    source 542
    target 557
    type "dominant"
  ]
  edge [
    source 542
    target 804
    type "dominant"
  ]
  edge [
    source 544
    target 231
    type "dominant"
  ]
  edge [
    source 544
    target 374
    type "dominant"
  ]
  edge [
    source 544
    target 537
    type "dominant"
  ]
  edge [
    source 544
    target 545
    type "neutral"
  ]
  edge [
    source 544
    target 546
    type "neutral"
  ]
  edge [
    source 544
    target 737
    type "dominant"
  ]
  edge [
    source 544
    target 738
    type "dominant"
  ]
  edge [
    source 544
    target 795
    type "dominant"
  ]
  edge [
    source 544
    target 796
    type "dominant"
  ]
  edge [
    source 545
    target 231
    type "dominant"
  ]
  edge [
    source 545
    target 737
    type "dominant"
  ]
  edge [
    source 545
    target 788
    type "dominant"
  ]
  edge [
    source 546
    target 231
    type "dominant"
  ]
  edge [
    source 546
    target 737
    type "dominant"
  ]
  edge [
    source 549
    target 64
    type "dominant"
  ]
  edge [
    source 549
    target 147
    type "dominant"
  ]
  edge [
    source 549
    target 642
    type "dominant"
  ]
  edge [
    source 550
    target 648
    type "dominant"
  ]
  edge [
    source 551
    target 147
    type "dominant"
  ]
  edge [
    source 551
    target 469
    type "dominant"
  ]
  edge [
    source 552
    target 64
    type "dominant"
  ]
  edge [
    source 552
    target 147
    type "dominant"
  ]
  edge [
    source 552
    target 551
    type "dominant"
  ]
  edge [
    source 552
    target 553
    type "neutral"
  ]
  edge [
    source 552
    target 632
    type "dominant"
  ]
  edge [
    source 552
    target 648
    type "dominant"
  ]
  edge [
    source 553
    target 147
    type "dominant"
  ]
  edge [
    source 553
    target 642
    type "dominant"
  ]
  edge [
    source 553
    target 648
    type "dominant"
  ]
  edge [
    source 553
    target 726
    type "dominant"
  ]
  edge [
    source 554
    target 631
    type "dominant"
  ]
  edge [
    source 555
    target 175
    type "dominant"
  ]
  edge [
    source 555
    target 190
    type "dominant"
  ]
  edge [
    source 555
    target 259
    type "dominant"
  ]
  edge [
    source 555
    target 271
    type "dominant"
  ]
  edge [
    source 556
    target 636
    type "dominant"
  ]
  edge [
    source 556
    target 704
    type "dominant"
  ]
  edge [
    source 556
    target 778
    type "dominant"
  ]
  edge [
    source 558
    target 749
    type "dominant"
  ]
  edge [
    source 560
    target 559
    type "dominant"
  ]
  edge [
    source 560
    target 751
    type "dominant"
  ]
  edge [
    source 564
    target 563
    type "dominant"
  ]
  edge [
    source 564
    target 637
    type "dominant"
  ]
  edge [
    source 564
    target 694
    type "dominant"
  ]
  edge [
    source 564
    target 744
    type "dominant"
  ]
  edge [
    source 566
    target 553
    type "dominant"
  ]
  edge [
    source 566
    target 565
    type "dominant"
  ]
  edge [
    source 566
    target 613
    type "dominant"
  ]
  edge [
    source 566
    target 765
    type "dominant"
  ]
  edge [
    source 573
    target 572
    type "dominant"
  ]
  edge [
    source 573
    target 595
    type "neutral"
  ]
  edge [
    source 575
    target 553
    type "dominant"
  ]
  edge [
    source 575
    target 574
    type "dominant"
  ]
  edge [
    source 577
    target 126
    type "dominant"
  ]
  edge [
    source 577
    target 576
    type "dominant"
  ]
  edge [
    source 578
    target 576
    type "dominant"
  ]
  edge [
    source 578
    target 665
    type "neutral"
  ]
  edge [
    source 581
    target 373
    type "dominant"
  ]
  edge [
    source 581
    target 580
    type "dominant"
  ]
  edge [
    source 585
    target 578
    type "dominant"
  ]
  edge [
    source 585
    target 584
    type "dominant"
  ]
  edge [
    source 585
    target 610
    type "neutral"
  ]
  edge [
    source 585
    target 586
    type "dominant"
  ]
  edge [
    source 585
    target 605
    type "dominant"
  ]
  edge [
    source 585
    target 797
    type "dominant"
  ]
  edge [
    source 586
    target 155
    type "dominant"
  ]
  edge [
    source 586
    target 316
    type "dominant"
  ]
  edge [
    source 586
    target 584
    type "dominant"
  ]
  edge [
    source 586
    target 634
    type "dominant"
  ]
  edge [
    source 586
    target 768
    type "dominant"
  ]
  edge [
    source 586
    target 797
    type "dominant"
  ]
  edge [
    source 588
    target 589
    type "neutral"
  ]
  edge [
    source 588
    target 682
    type "dominant"
  ]
  edge [
    source 590
    target 591
    type "neutral"
  ]
  edge [
    source 592
    target 590
    type "dominant"
  ]
  edge [
    source 593
    target 816
    type "dominant"
  ]
  edge [
    source 594
    target 593
    type "dominant"
  ]
  edge [
    source 595
    target 206
    type "dominant"
  ]
  edge [
    source 595
    target 534
    type "dominant"
  ]
  edge [
    source 595
    target 681
    type "dominant"
  ]
  edge [
    source 596
    target 806
    type "dominant"
  ]
  edge [
    source 597
    target 192
    type "dominant"
  ]
  edge [
    source 598
    target 81
    type "dominant"
  ]
  edge [
    source 598
    target 303
    type "dominant"
  ]
  edge [
    source 598
    target 497
    type "dominant"
  ]
  edge [
    source 599
    target 125
    type "dominant"
  ]
  edge [
    source 601
    target 600
    type "dominant"
  ]
  edge [
    source 602
    target 603
    type "neutral"
  ]
  edge [
    source 602
    target 776
    type "dominant"
  ]
  edge [
    source 603
    target 654
    type "neutral"
  ]
  edge [
    source 603
    target 772
    type "dominant"
  ]
  edge [
    source 604
    target 17
    type "dominant"
  ]
  edge [
    source 604
    target 38
    type "dominant"
  ]
  edge [
    source 604
    target 334
    type "dominant"
  ]
  edge [
    source 604
    target 456
    type "dominant"
  ]
  edge [
    source 604
    target 660
    type "dominant"
  ]
  edge [
    source 605
    target 21
    type "dominant"
  ]
  edge [
    source 605
    target 606
    type "neutral"
  ]
  edge [
    source 605
    target 669
    type "dominant"
  ]
  edge [
    source 606
    target 669
    type "neutral"
  ]
  edge [
    source 607
    target 465
    type "dominant"
  ]
  edge [
    source 608
    target 150
    type "dominant"
  ]
  edge [
    source 608
    target 159
    type "dominant"
  ]
  edge [
    source 608
    target 162
    type "dominant"
  ]
  edge [
    source 608
    target 418
    type "dominant"
  ]
  edge [
    source 608
    target 823
    type "dominant"
  ]
  edge [
    source 610
    target 47
    type "dominant"
  ]
  edge [
    source 610
    target 754
    type "dominant"
  ]
  edge [
    source 616
    target 615
    type "dominant"
  ]
  edge [
    source 620
    target 619
    type "dominant"
  ]
  edge [
    source 620
    target 651
    type "neutral"
  ]
  edge [
    source 623
    target 622
    type "dominant"
  ]
  edge [
    source 623
    target 655
    type "dominant"
  ]
  edge [
    source 623
    target 812
    type "dominant"
  ]
  edge [
    source 623
    target 831
    type "dominant"
  ]
  edge [
    source 627
    target 626
    type "dominant"
  ]
  edge [
    source 627
    target 632
    type "dominant"
  ]
  edge [
    source 633
    target 632
    type "dominant"
  ]
  edge [
    source 636
    target 635
    type "dominant"
  ]
  edge [
    source 636
    target 793
    type "dominant"
  ]
  edge [
    source 639
    target 638
    type "dominant"
  ]
  edge [
    source 639
    target 726
    type "dominant"
  ]
  edge [
    source 641
    target 173
    type "dominant"
  ]
  edge [
    source 641
    target 640
    type "dominant"
  ]
  edge [
    source 645
    target 644
    type "dominant"
  ]
  edge [
    source 645
    target 721
    type "neutral"
  ]
  edge [
    source 646
    target 644
    type "dominant"
  ]
  edge [
    source 646
    target 720
    type "dominant"
  ]
  edge [
    source 649
    target 650
    type "neutral"
  ]
  edge [
    source 651
    target 359
    type "dominant"
  ]
  edge [
    source 652
    target 462
    type "dominant"
  ]
  edge [
    source 653
    target 620
    type "dominant"
  ]
  edge [
    source 655
    target 81
    type "dominant"
  ]
  edge [
    source 655
    target 683
    type "dominant"
  ]
  edge [
    source 655
    target 729
    type "dominant"
  ]
  edge [
    source 658
    target 180
    type "dominant"
  ]
  edge [
    source 658
    target 395
    type "dominant"
  ]
  edge [
    source 658
    target 704
    type "neutral"
  ]
  edge [
    source 658
    target 659
    type "dominant"
  ]
  edge [
    source 659
    target 778
    type "dominant"
  ]
  edge [
    source 660
    target 18
    type "dominant"
  ]
  edge [
    source 660
    target 72
    type "dominant"
  ]
  edge [
    source 660
    target 210
    type "dominant"
  ]
  edge [
    source 660
    target 514
    type "dominant"
  ]
  edge [
    source 660
    target 661
    type "neutral"
  ]
  edge [
    source 662
    target 354
    type "dominant"
  ]
  edge [
    source 664
    target 81
    type "dominant"
  ]
  edge [
    source 664
    target 281
    type "dominant"
  ]
  edge [
    source 666
    target 791
    type "dominant"
  ]
  edge [
    source 668
    target 786
    type "dominant"
  ]
  edge [
    source 669
    target 72
    type "dominant"
  ]
  edge [
    source 669
    target 730
    type "dominant"
  ]
  edge [
    source 670
    target 606
    type "dominant"
  ]
  edge [
    source 670
    target 669
    type "dominant"
  ]
  edge [
    source 672
    target 374
    type "dominant"
  ]
  edge [
    source 673
    target 439
    type "dominant"
  ]
  edge [
    source 675
    target 674
    type "dominant"
  ]
  edge [
    source 676
    target 824
    type "dominant"
  ]
  edge [
    source 677
    target 729
    type "dominant"
  ]
  edge [
    source 678
    target 77
    type "dominant"
  ]
  edge [
    source 678
    target 773
    type "dominant"
  ]
  edge [
    source 688
    target 481
    type "dominant"
  ]
  edge [
    source 688
    target 687
    type "dominant"
  ]
  edge [
    source 692
    target 372
    type "dominant"
  ]
  edge [
    source 692
    target 691
    type "dominant"
  ]
  edge [
    source 704
    target 778
    type "dominant"
  ]
  edge [
    source 706
    target 654
    type "dominant"
  ]
  edge [
    source 706
    target 707
    type "dominant"
  ]
  edge [
    source 708
    target 707
    type "dominant"
  ]
  edge [
    source 709
    target 710
    type "neutral"
  ]
  edge [
    source 710
    target 829
    type "neutral"
  ]
  edge [
    source 711
    target 421
    type "dominant"
  ]
  edge [
    source 714
    target 713
    type "dominant"
  ]
  edge [
    source 715
    target 316
    type "dominant"
  ]
  edge [
    source 715
    target 771
    type "dominant"
  ]
  edge [
    source 716
    target 591
    type "dominant"
  ]
  edge [
    source 717
    target 793
    type "dominant"
  ]
  edge [
    source 718
    target 636
    type "dominant"
  ]
  edge [
    source 718
    target 717
    type "dominant"
  ]
  edge [
    source 719
    target 717
    type "dominant"
  ]
  edge [
    source 720
    target 766
    type "dominant"
  ]
  edge [
    source 720
    target 781
    type "dominant"
  ]
  edge [
    source 733
    target 732
    type "dominant"
  ]
  edge [
    source 736
    target 735
    type "dominant"
  ]
  edge [
    source 740
    target 739
    type "dominant"
  ]
  edge [
    source 741
    target 739
    type "dominant"
  ]
  edge [
    source 741
    target 742
    type "dominant"
  ]
  edge [
    source 741
    target 763
    type "dominant"
  ]
  edge [
    source 742
    target 739
    type "dominant"
  ]
  edge [
    source 742
    target 763
    type "dominant"
  ]
  edge [
    source 747
    target 431
    type "dominant"
  ]
  edge [
    source 747
    target 746
    type "dominant"
  ]
  edge [
    source 752
    target 485
    type "dominant"
  ]
  edge [
    source 753
    target 752
    type "dominant"
  ]
  edge [
    source 755
    target 754
    type "dominant"
  ]
  edge [
    source 757
    target 401
    type "dominant"
  ]
  edge [
    source 760
    target 28
    type "dominant"
  ]
  edge [
    source 764
    target 763
    type "dominant"
  ]
  edge [
    source 770
    target 769
    type "dominant"
  ]
  edge [
    source 780
    target 779
    type "dominant"
  ]
  edge [
    source 784
    target 546
    type "dominant"
  ]
  edge [
    source 784
    target 783
    type "dominant"
  ]
  edge [
    source 784
    target 785
    type "dominant"
  ]
  edge [
    source 785
    target 783
    type "dominant"
  ]
  edge [
    source 785
    target 809
    type "dominant"
  ]
  edge [
    source 789
    target 788
    type "dominant"
  ]
  edge [
    source 790
    target 553
    type "dominant"
  ]
  edge [
    source 792
    target 791
    type "dominant"
  ]
  edge [
    source 794
    target 298
    type "dominant"
  ]
  edge [
    source 794
    target 820
    type "dominant"
  ]
  edge [
    source 796
    target 795
    type "dominant"
  ]
  edge [
    source 804
    target 803
    type "dominant"
  ]
  edge [
    source 825
    target 824
    type "dominant"
  ]
  edge [
    source 828
    target 395
    type "dominant"
  ]
  edge [
    source 830
    target 829
    type "dominant"
  ]
  edge [
    source 832
    target 831
    type "dominant"
  ]
]
