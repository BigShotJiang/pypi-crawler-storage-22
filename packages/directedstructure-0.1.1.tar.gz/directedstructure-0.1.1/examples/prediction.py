# Link prediction and anomaly detection
