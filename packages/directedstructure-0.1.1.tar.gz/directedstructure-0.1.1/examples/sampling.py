# Taking and saving posterior samples
