# Measuring speed of inferences
