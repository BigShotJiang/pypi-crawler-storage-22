# Plotting inferred network structures

# Groups


# Hierarchy


# Joint distribution of groups and hierarchy


# Posterior samples of individual and group depths
