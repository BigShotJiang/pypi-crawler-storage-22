# 🗺️ directorymap

> Project directory structure tracker CLI  
> Lightweight. Deterministic. Automation-friendly.

**directorymap** scans your project, respects ignore rules, and generates a clean,
reproducible snapshot of your filesystem structure.

It helps you *see* and *track* how your folders evolve over time.

---

## ✨ Features

- Track folder structure changes
- Ignore junk files automatically
- Generate clean tree snapshots
- Diff previous structure
- File/folder statistics
- Structural hashing
- Watch mode (auto update)
- CI/CD friendly

---

## 📦 Install

```bash
pip install directorymap
```

---

## 🚀 Quick start

```bash
directorymap init
directorymap build
directorymap diff
directorymap stats
directorymap watch
```

---

## 🧰 Commands

| Command | Description |
|--------|-------------|
| `init` | create `.directorymap/config` and first snapshot |
| `build` | generate `structure.ini` |
| `diff` | show changes vs previous snapshot |
| `stats` | file/folder/size statistics |
| `hash` | structural fingerprint |
| `watch` | auto-update on changes |

---

## 📂 Example output

```text
project/
├─ src/
│  ├─ main.py
│  └─ utils.py
├─ tests/
└─ README.md
```

---

## ⚙️ Configuration

Path:

```
.directorymap/config
```

Example:

```text
node_modules
.git
__pycache__
.DS_Store
*.log
*.tmp
dist
```

---

## 📊 Stats example

```text
files: 124
