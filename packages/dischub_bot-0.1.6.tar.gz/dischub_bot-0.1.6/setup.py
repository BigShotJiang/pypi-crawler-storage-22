from setuptools import setup, find_packages
import os

def find_pyc_files(package_dir):
    pyc_files = []
    for root, dirs, files in os.walk(package_dir):
        for f in files:
            if f.endswith(".pyc"):
                # include relative path from package root
                rel_path = os.path.relpath(os.path.join(root, f), package_dir)
                pyc_files.append(rel_path)
    return pyc_files

pyc_files = find_pyc_files("dischub_bot")

setup(
    name="dischub_bot",
    version="0.1.6",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "dischub_bot": pyc_files,
    },
    install_requires=[
        "MetaTrader5",
        "requests",
        "django>=4.2",
    ],
    python_requires=">=3.9",
    entry_points={
        "console_scripts": [
            "launch-dischub=dischub_bot:launch_bot_ui",
        ],
    },
    author="DiscHub",
    author_email="chihoyistanford@gmail.com",
    description="Dischub automated scalping bot for MetaTrader 5",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://dischub.co.zw",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: Microsoft :: Windows",
        "License :: OSI Approved :: MIT License",
    ],
)
