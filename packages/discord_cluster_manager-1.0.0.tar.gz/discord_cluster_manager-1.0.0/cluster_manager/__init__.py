"""
A library to manage Discord bot clusters with shard distribution. 
~~~~~~~~~~~~~~~~~~~

:copyright: (c) 2026 Manreet Singh
:license: See LICENSE for more details.

"""

__version__ = "1.0.0"

from .api import initialize, notify_ready, run_bot
from .runner import run
from .types import ShardConfig
from .manager import ClusterManager as Manager

__all__ = [
    'initialize',
    'notify_ready',
    'run_bot',
    'run',
    'ShardConfig',
    'Manager'
]