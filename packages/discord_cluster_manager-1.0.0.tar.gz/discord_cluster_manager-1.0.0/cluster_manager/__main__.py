from .manager import ClusterManager
from .config import load_config


def main():
    manager = ClusterManager(load_config())
    manager.run()

if __name__ == "__main__":
    main()