import os
import sys
from typing import Optional

from .config import load_config
from .inject import inject
from .manager import ClusterManager
from .types import ShardConfig

_manager: Optional[ClusterManager] = None
_ready_notified = False

# Magic string used for IPC via stdout
READY_MAGIC_STRING = "__CLUSTER_READY__{cid}__"


def initialize(bot, config: Optional[ShardConfig] = None) -> Optional[ClusterManager]:
    """
    Initializes the cluster management system.

    This function determines the execution context (manager vs. worker).
    - In a worker process (cluster), it injects shard configuration into the bot instance
      and registers an `on_ready` event listener to notify the manager when the bot is ready.
    - In the manager process, it initializes and returns a `ClusterManager` instance.

    Args:
        bot: The Discord bot instance (e.g., commands.Bot or discord.Client).
        config (Optional[ShardConfig]): The sharding configuration. If None, it attempts
            to load from `shards.py` or uses defaults.

    Returns:
        Optional[ClusterManager]: The manager instance if called in the manager process,
        otherwise None.
    """
    global _manager

    cid = os.getenv("CLUSTER_ID")
    if cid is not None:
        inject(bot)

        # Automatically hook into on_ready to notify the manager
        @bot.event
        async def on_ready():
            notify_ready()
            # If the user has their own on_ready, discord.py will usually 
            # only call one unless we use listeners or the user uses @bot.listen()
            # However, for most users @bot.event on_ready is standard.
            # To be safer, we could use bot.add_listener, but bot.event is common.
        
        # Safer approach using listener to not overwrite user's on_ready
        # bot.add_listener(on_ready) # Currently commented out to avoide double calls but can be used if needed
        return None

    if _manager is not None:
        return _manager

    c = config or load_config()
    if not config and not os.path.exists("shards.py"):
        if c.bot_entry == "main.py" and not os.path.exists("main.py"):
             c.bot_entry = os.path.basename(sys.argv[0])

    _manager = ClusterManager(c)
    return _manager


def run_bot(bot, *args, **kwargs):
    """
    Executes the bot or the cluster manager based on the current process context.

    If the process is a worker (identified by `CLUSTER_ID` env var), it calls `bot.run()`.
    If the process is the manager, it initializes the `ClusterManager` (if not already done)
    and starts the management loop.

    Args:
        bot: The Discord bot instance.
        *args: Positional arguments to pass to `bot.run()`.
        **kwargs: Keyword arguments to pass to `bot.run()`.
    """
    global _manager
    
    if os.getenv("CLUSTER_ID") is not None:
        bot.run(*args, **kwargs)
    else:
        if _manager is None:
            _manager = initialize(bot)
            
        if _manager:
            _manager.run()
            sys.exit(0)
        else:
            bot.run(*args, **kwargs)


def notify_ready():
    """
    Signals to the cluster manager that the current cluster is fully ready.

    This function prints a specific magic string to stdout, which the manager process
    intercepts to track cluster readiness. It is safe to call this function multiple times;
    subsequent calls will be ignored.
    """
    global _ready_notified

    if _ready_notified:
        return

    cid = os.getenv("CLUSTER_ID")
    if cid is None:
        return  # Not running under cluster manager

    # Print the magic string to stdout for the manager to capture
    print(READY_MAGIC_STRING.format(cid=cid), flush=True)
    _ready_notified = True