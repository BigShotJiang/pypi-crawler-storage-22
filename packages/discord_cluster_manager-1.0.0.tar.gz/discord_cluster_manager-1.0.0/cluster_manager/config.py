import importlib.util
import sys
from pathlib import Path

from .types import ShardConfig


def load_config() -> ShardConfig:
    path = Path("shards.py")

    if not path.exists():
        return ShardConfig()

    spec = importlib.util.spec_from_file_location("shards", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["shards"] = module
    spec.loader.exec_module(module)

    if not hasattr(module, "config"):
        raise RuntimeError("shards.py must define `config`")

    if not isinstance(module.config, ShardConfig):
        raise TypeError("config must be an instance of ShardConfig")

    return module.config