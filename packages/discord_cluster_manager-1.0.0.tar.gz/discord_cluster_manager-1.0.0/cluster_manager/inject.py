import os


def inject(client):
    shard_list = os.getenv("SHARD_LIST")
    total_shards = os.getenv("TOTAL_SHARDS")

    if shard_list:
        client.shard_ids = [int(x) for x in shard_list.split(",")]

    if total_shards:
        client.shard_count = int(total_shards)