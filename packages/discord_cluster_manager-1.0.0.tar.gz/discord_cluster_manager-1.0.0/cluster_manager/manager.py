import math
import os
import signal
import subprocess
import sys
import threading
import time
import logging
from typing import Dict, Set, Callable, List

import requests

from .types import ShardConfig


class ClusterManager:
    def __init__(self, config: ShardConfig):
        self.config = config

        self.processes: Dict[int, subprocess.Popen] = {}
        self.restart_count: Dict[int, int] = {}
        self.last_restart: Dict[int, float] = {}
        self.disabled: Set[int] = set()

        self.shutting_down = False
        self.lock = threading.Lock()
        
        # Readiness events
        self._ready_events: Dict[int, threading.Event] = {}

        # Setup logging
        logging.basicConfig(level=config.log_level, format=config.log_format)
        self.log = logging.getLogger("ClusterManager")

        # Event Handlers
        self._events: Dict[str, List[Callable]] = {
            "launch": [],
            "ready": [],
            "stop": [],
            "all_ready": [],
        }

        self.total_shards = self.resolve_shards()
        self.total_clusters = max(
            1, math.ceil(self.total_shards / self.config.shards_per_cluster)
        )

        self.log.info(f"total_shards={self.total_shards}")
        self.log.info(f"total_clusters={self.total_clusters}")
        self.log.info(f"bot_entry={self.config.bot_entry}")

    def on_cluster_launch(self, func: Callable[[int], None]):
        """Decorator or method to register launch events."""
        self._events["launch"].append(func)
        return func

    def on_cluster_ready(self, func: Callable[[int], None]):
        """Decorator or method to register ready events."""
        self._events["ready"].append(func)
        return func

    def on_cluster_stop(self, func: Callable[[int, int], None]):
        """Decorator or method to register stop events (cid, exit_code)."""
        self._events["stop"].append(func)
        return func

    def on_all_ready(self, func: Callable[[], None]):
        """Decorator or method to register when all clusters are ready."""
        self._events["all_ready"].append(func)
        return func

    def _trigger(self, event: str, *args, **kwargs):
        for handler in self._events.get(event, []):
            try:
                handler(*args, **kwargs)
            except Exception as e:
                self.log.error(f"Error in {event} handler: {e}")

    def resolve_shards(self) -> int:
        if self.config.total_shards is not None:
            if self.config.total_shards < 1:
                raise ValueError("total_shards must be >= 1")

            self.log.info(f"Using user-defined shard count: {self.config.total_shards}")
            return self.config.total_shards

        token = os.getenv("TOKEN")
        if not token:
            raise RuntimeError(
                "TOKEN is required when total_shards is not set in ShardConfig"
            )

        try:
            r = requests.get(
                "https://discord.com/api/v10/gateway/bot",
                headers={"Authorization": f"Bot {token}"},
                timeout=10,
            )
            r.raise_for_status()
            shards = int(r.json().get("shards", 1))
            self.log.info(f"Fetched shard count from Discord: {shards}")
            return shards
        except Exception as e:
            self.log.warning(f"Failed to fetch shards, fallback=1 → {e}")
            return 1

    def spawn(self, cid: int):
        shards_per = math.ceil(self.total_shards / self.total_clusters)
        start = cid * shards_per
        end = min(start + shards_per, self.total_shards)

        shard_list = ",".join(map(str, range(start, end)))
        
        env = {
            **os.environ,
            "CLUSTER_ID": str(cid),
            "TOTAL_SHARDS": str(self.total_shards),
            "SHARD_LIST": shard_list,
        }

        self.log.info(f"[Cluster {cid}] Launching shards {start}-{end - 1}")

        self._trigger("launch", cid)

        bot_path = os.path.abspath(self.config.bot_entry)
        
        # Create event for ready signaling
        ready_event = threading.Event()
        self._ready_events[cid] = ready_event

        proc = subprocess.Popen(
            [sys.executable, bot_path],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,  # Merge stderr into stdout for easier scanning
            text=True,
            bufsize=1,  # Line buffered
        )

        self.processes[cid] = proc
        self.restart_count.setdefault(cid, 0)

        # Start output scanner thread
        threading.Thread(target=self._scan_output, args=(cid, proc), daemon=True).start()

        try:
            self.wait_ready(proc, cid)
            self._trigger("ready", cid)
        except Exception as e:
            self.log.error(f"[Cluster {cid}] Failed to start: {e}")
            raise

    def _scan_output(self, cid: int, proc: subprocess.Popen):
        """Scans the stdout of a process for the ready magic string."""
        from .api import READY_MAGIC_STRING
        magic = READY_MAGIC_STRING.format(cid=cid)

        try:
            for line in iter(proc.stdout.readline, ""):
                if magic in line:
                    self._ready_events[cid].set()
                    continue  # Don't print the magic string to main stdout

                # Forward the line to main stdout
                sys.stdout.write(line)
                sys.stdout.flush()
        except Exception as e:
            self.log.debug(f"[Cluster {cid}] Output scanner stopped: {e}")
        finally:
            if proc.stdout:
                proc.stdout.close()

    def wait_ready(self, proc, cid: int):
        ready_event = self._ready_events[cid]
        
        # Wait for the event with a timeout
        success = ready_event.wait(timeout=self.config.boot_timeout)
        
        if not success:
            if proc.poll() is not None:
                raise RuntimeError(f"Cluster {cid} crashed during startup with exit code {proc.returncode}")
            
            proc.kill()
            raise TimeoutError(f"Cluster {cid} boot timeout reached ({self.config.boot_timeout}s)")

        self.log.info(f"[Cluster {cid}] READY signal received via stdout")

    def launch(self, cid: int):
        if self.shutting_down or cid in self.disabled:
            return

        now = time.time()
        if now - self.last_restart.get(cid, 0) < self.config.restart_cooldown:
            return

        self.last_restart[cid] = now

        while not self.shutting_down:
            try:
                self.spawn(cid)
                return
            except Exception as e:
                self.restart_count[cid] += 1
                self.log.error(f"[Cluster {cid}] crash → {e}")

                if self.restart_count[cid] >= self.config.max_restarts:
                    self.log.critical(f"[Cluster {cid}] Reached max restarts. DISABLING.")
                    self.disabled.add(cid)
                    with self.lock:
                        self.processes.pop(cid, None)
                    return

                backoff = min(60, 2 ** self.restart_count[cid])
                self.log.info(f"[Cluster {cid}] restarting in {backoff}s")
                time.sleep(backoff)

    def launch_all(self):
        for cid in range(self.total_clusters):
            self.launch(cid)
            if cid < self.total_clusters - 1:
                time.sleep(self.config.identify_delay)
        
        self.log.info("All clusters launched")
        self._trigger("all_ready")

    def monitor(self):
        while not self.shutting_down:
            with self.lock:
                for cid, proc in list(self.processes.items()):
                    if cid in self.disabled:
                        continue

                    exit_code = proc.poll()
                    if exit_code is not None:
                        self.log.warning(f"[Cluster {cid}] EXITED with code {exit_code}")
                        self.processes.pop(cid, None)
                        self._trigger("stop", cid, exit_code)
                        
                        threading.Thread(target=self.launch, args=(cid,), daemon=True).start()

            time.sleep(self.config.monitor_interval)

    def shutdown(self, *_):
        if self.shutting_down:
            return

        self.log.info("Shutdown initiated...")
        self.shutting_down = True

        with self.lock:
            for cid, proc in self.processes.items():
                try:
                    self.log.info(f"Terminating Cluster {cid}...")
                    proc.terminate()
                except Exception:
                    pass

        time.sleep(5)

        with self.lock:
            for cid, proc in self.processes.items():
                if proc.poll() is None:
                    self.log.info(f"Killing Cluster {cid} (not responding to terminate)...")
                    try:
                        proc.kill()
                    except Exception:
                        pass
        
        self.log.info("Shutdown complete.")

    def run(self):
        signal.signal(signal.SIGINT, self.shutdown)
        signal.signal(signal.SIGTERM, self.shutdown)

        self.launch_all()
        self.monitor()
