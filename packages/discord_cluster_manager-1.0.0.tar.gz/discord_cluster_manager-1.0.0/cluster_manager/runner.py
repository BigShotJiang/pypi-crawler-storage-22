from .manager import ClusterManager
from .types import ShardConfig


def run(config: ShardConfig):
    """
    Starts the cluster manager with the given configuration.

    This function initializes the ClusterManager with the provided configuration
    and begins the process of managing bot clusters. It serves as the main entry
    point when running the `shards.py` script.

    Args:
        config (ShardConfig): The configuration object containing settings for
            sharding, such as shards per cluster, total shards, and bot entry file.
    """
    manager = ClusterManager(config)
    manager.run()
