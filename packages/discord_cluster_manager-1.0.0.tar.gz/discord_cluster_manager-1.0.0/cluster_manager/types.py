from dataclasses import dataclass
from typing import Optional


@dataclass(slots=True)
class ShardConfig:
    # Sharding
    shards_per_cluster: int = 4
    total_shards: Optional[int] = None  # If set, Discord API is NOT used

    # Process behavior
    identify_delay: int = 6
    boot_timeout: int = 360
    monitor_interval: int = 10
    max_restarts: int = 5
    restart_cooldown: int = 30

    # Bot entry file
    bot_entry: str = "main.py"
    
    # Logging
    log_level: str = "INFO"
    log_format: str = "[%(asctime)s] [%(name)s] [%(levelname)s] %(message)s"