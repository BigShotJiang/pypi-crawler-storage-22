"""discordcn for pycord."""

# ruff: noqa: E402
from discordcn._utils import require_extra

require_extra(package="py-cord", import_name="discord", version=(2, 7, 0))

from .interfaces import (
    AccordionInterface,
    ConfirmInterface,
    PageButton,
    PageIndicatorButton,
    PaginatorControls,
    PaginatorControlsBase,
    PaginatorInterface,
    PaginatorInterfaceBase,
)

__all__ = (
    "AccordionInterface",
    "ConfirmInterface",
    "PageButton",
    "PageIndicatorButton",
    "PaginatorControls",
    "PaginatorControlsBase",
    "PaginatorInterface",
    "PaginatorInterfaceBase",
)
