"""discordcn interfaces for pycord."""

from .accordion import AccordionInterface
from .confirm import ConfirmInterface
from .paginator import (
    PageButton,
    PageIndicatorButton,
    PaginatorControls,
    PaginatorControlsBase,
    PaginatorIndicatorModal,
    PaginatorInterface,
    PaginatorInterfaceBase,
)

__all__ = (
    "AccordionInterface",
    "ConfirmInterface",
    "PageButton",
    "PageIndicatorButton",
    "PaginatorControls",
    "PaginatorControlsBase",
    "PaginatorIndicatorModal",
    "PaginatorInterface",
    "PaginatorInterfaceBase",
)
