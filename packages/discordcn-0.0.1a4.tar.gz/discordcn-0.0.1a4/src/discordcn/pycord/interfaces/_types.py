from collections.abc import Awaitable, Callable
from typing import Any, TypeAlias, TypeVar

import discord

T = TypeVar("T")


Callback: TypeAlias = Callable[[T], Awaitable[Any] | Any]

EmojiType: TypeAlias = discord.PartialEmoji | discord.AppEmoji | discord.GuildEmoji
"""Accepted emoji types for section accessory buttons."""

__all__ = ("Callback",)
