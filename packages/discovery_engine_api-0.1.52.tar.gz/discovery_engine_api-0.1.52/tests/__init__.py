"""Tests for the Discovery Engine Python SDK Client."""
