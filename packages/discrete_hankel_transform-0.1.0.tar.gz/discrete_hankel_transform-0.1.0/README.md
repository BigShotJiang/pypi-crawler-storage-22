# Discrete Hankel Transform

Lightweight Python implementation of the **discrete Hankel transform (DHT)** for cylindrical and axially symmetric problems.

Designed for numerical simulations in areas such as:

* Ultracold atoms
* Bose–Einstein condensates
* Radially symmetric PDEs
* Spectral methods in cylindrical coordinates

The package provides both:

* Simple function interface (`dht`, `idht`)
* A reusable `HankelTransform` class optimized for repeated transforms in simulations

---

## Installation

### Using pixi (recommended)

Install in a pixi project:

```bash
pixi add git+https://github.com/serranolio/discrete-hankel-transform.git
```

Or locally during development:

```bash
pixi add --editable .
```

---

### Using pip

From GitHub:

```bash
pip install git+https://github.com/serranolio/discrete-hankel-transform.git
```

---

## Quick Example

```python
import numpy as np
from discrete_hankel_transform import Hank
```

