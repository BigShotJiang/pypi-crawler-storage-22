Verify a AlmaLinux 9 aarch64 image
