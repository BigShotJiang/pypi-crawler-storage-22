Verify a AlmaLinux 9 image
