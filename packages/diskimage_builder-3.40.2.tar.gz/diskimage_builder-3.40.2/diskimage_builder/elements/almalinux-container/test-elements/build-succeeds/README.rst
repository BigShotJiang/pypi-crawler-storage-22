Verify we can build a almalinux-container image.
