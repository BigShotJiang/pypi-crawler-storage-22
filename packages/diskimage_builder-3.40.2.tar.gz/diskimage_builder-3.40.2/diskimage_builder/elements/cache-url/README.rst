=========
cache-url
=========

A helper script to download images into a local cache.

**NOTE** : on RedHat platforms, ensure the curl binary is available.
Due to conflicting differences in platform usage of ```curl-minimal``
and ```curl``, the usual package dependency methods do not work for
this package.
