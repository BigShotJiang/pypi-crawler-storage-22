==============
centos-minimal
==============
Create a minimal image based on CentOS

Use of this element will require 'yum' and 'yum-utils' to be installed on
Ubuntu and Debian. Nothing additional is needed on Fedora or CentOS.

By default this builds CentOS-Stream 9 images.  Set ``DIB_RELEASE`` to
``8`` or ``8-stream`` to explicitly select the release.
