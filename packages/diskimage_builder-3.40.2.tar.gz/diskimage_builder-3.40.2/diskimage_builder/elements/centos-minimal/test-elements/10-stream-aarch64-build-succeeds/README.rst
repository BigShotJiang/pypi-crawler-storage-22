Verify we can build a centos-minimal image.
