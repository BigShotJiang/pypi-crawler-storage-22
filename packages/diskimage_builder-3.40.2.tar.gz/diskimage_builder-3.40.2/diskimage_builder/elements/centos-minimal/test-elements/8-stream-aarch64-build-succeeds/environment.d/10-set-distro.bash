export DIB_RELEASE=8-stream
