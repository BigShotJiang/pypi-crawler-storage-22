Centos Stream 10 test
