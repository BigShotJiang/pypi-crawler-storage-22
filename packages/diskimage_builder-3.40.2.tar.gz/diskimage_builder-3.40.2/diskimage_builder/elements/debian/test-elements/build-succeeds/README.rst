Test that we can successfully build a debian image.
