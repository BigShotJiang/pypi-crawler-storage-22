============
deploy-kexec
============
Boots into the new image once baremetal-deploy-helper signals
it is finished by downloading the kernel and ramdisk via tftp,
and using the kexec utilities.
