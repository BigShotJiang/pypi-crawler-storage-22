===============
disable-nouveau
===============
Blacklist nouveau module

This is required when installing NVIDIA GPU drivers and to avoid issues with PCI
passthrough of NVIDIA GPUs.
