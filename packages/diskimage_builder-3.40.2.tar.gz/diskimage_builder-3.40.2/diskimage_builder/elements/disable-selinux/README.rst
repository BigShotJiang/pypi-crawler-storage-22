disable-selinux
---------------

Including this element disables SELinux.
