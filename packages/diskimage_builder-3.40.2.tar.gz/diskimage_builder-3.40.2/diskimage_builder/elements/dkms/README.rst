====
dkms
====
This is the dkms (Dynamic Kernel Module System) element.

Some distributions such as Fedora and Ubuntu include DKMS in their packaging.
In these distros, it is reasonable to include dkms.  Other RHEL based
derivatives do not include DKMS, so those distros should not use the DKMS
element.
