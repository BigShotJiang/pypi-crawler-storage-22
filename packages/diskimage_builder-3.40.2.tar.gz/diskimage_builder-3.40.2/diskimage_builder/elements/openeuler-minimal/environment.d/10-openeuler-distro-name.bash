export DISTRO_NAME=openeuler
export DIB_RELEASE=${DIB_RELEASE:-22.03-LTS}
export EFI_BOOT_DIR="EFI/openEuler"
