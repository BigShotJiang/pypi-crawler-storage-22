openEuler 22.03-LTS test
