Verify we can build an openSUSE Leap 15.1 image.
