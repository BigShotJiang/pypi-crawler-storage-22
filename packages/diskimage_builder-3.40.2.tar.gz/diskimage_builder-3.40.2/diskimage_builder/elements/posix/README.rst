posix
=====

* This element installs packages to ensure that the resulting image has
  binaries necessary to meet the requirements of POSIX, laid out in the
  following URL:

  + http://pubs.opengroup.org/onlinepubs/9699919799/idx/utilities.html

* This has been tested to work on Ubuntu, Debian, and CentOS, although
  should work on Red Hat Enterprise Linux.

* To add support for other distros please consult the URL for binaries,
  then add the providing packages to pkg-map.
