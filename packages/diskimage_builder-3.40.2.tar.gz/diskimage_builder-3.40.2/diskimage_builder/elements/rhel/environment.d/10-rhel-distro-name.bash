export DISTRO_NAME=rhel
export DIB_RELEASE=${DIB_RELEASE:-8}
export EFI_BOOT_DIR="EFI/redhat"
export YUM=dnf
