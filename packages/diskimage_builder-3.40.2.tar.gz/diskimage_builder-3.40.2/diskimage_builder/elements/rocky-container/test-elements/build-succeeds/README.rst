Verify we can build a rocky-container image.
