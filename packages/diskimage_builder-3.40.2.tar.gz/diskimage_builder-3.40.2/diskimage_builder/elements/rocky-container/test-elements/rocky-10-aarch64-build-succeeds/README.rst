Verify a Rocky 10 aarch64 image
