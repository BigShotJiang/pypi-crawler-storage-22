Verify a Rocky 10 image
