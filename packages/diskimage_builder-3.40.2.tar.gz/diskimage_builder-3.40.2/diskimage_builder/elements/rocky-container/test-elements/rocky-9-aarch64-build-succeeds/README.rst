Verify a Rocky 9 aarch64 image
