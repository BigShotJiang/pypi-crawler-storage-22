Verify a Rocky 9 image
