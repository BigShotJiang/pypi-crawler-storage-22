selinux-fixfiles-restore
------------------------

Performs an selinux relabel in the cleanup phase.
