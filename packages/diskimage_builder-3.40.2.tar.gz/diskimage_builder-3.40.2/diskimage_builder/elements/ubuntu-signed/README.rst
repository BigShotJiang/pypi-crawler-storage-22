=============
ubuntu-signed
=============

The ``ubuntu-signed`` element installs ``linux-signed-image-generic``
that provides signed kernel that can be used for deploy in UEFI secure
boot mode.

.. element_deps::
