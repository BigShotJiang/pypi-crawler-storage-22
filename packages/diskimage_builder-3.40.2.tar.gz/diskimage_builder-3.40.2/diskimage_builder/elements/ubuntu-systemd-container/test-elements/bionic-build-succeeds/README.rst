Verify we can build a ubuntu-systemd-container image.
