Verify we can build a ubuntu image.
