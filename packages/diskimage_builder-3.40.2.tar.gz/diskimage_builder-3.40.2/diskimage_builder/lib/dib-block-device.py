import sys

from diskimage_builder.block_device.cmd import main


if __name__ == "__main__":
    sys.exit(main())
