Elements
========

Elements are found in the subdirectory elements. Each element is in a directory
named after the element itself. Elements *should* have a README.rst in the root
of the element directory describing what it is for.

.. toctree::
   :glob:

   elements/*/*
