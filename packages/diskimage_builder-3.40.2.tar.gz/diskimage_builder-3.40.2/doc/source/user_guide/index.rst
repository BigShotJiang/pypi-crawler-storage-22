User Guide
==========

.. toctree::
   :maxdepth: 1

   supported_distros
   installation
   building_an_image
   install_types
