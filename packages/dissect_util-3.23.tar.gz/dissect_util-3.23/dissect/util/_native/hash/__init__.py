from dissect.util._native.hash import crc32c

__all__ = ["crc32c"]
