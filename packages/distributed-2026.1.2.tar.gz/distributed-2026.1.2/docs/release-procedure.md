Distributed follows a similar procedure for releasing as the core Dask project.

See https://github.com/dask/dask/blob/main/docs/release-procedure.md for instructions.
