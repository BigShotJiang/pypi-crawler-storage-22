Examples
========

.. toctree::
   :maxdepth: 1
   
   examples/word-count
