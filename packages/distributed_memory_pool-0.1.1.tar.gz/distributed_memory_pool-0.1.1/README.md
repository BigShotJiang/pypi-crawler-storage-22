# Memory Object Server

A high-performance Python object sharing pool with distributed capabilities.

## Features

- **Support for any Python object**: Including system-level objects like sockets
- **Asynchronous communication**: Built on asyncio for high performance
- **Minimal API**: Simple and intuitive interface
- **Distributed support**: Multi-node synchronization and discovery
- **Auto-reconnection**: Reliable TCP socket communication with automatic reconnection
- **Thread-safe**: Concurrent operations are fully supported
- **Port detection**: Smart startup with port availability checking

## Installation

```bash
pip install memory-obj-server
```

## Quick Start

### Server

```python
from memory_obj_pool import Server

server = Server(host='0.0.0.0', port=8765)
server.run()
```

### Client

```python
from memory_obj_pool import SyncClient

client = SyncClient(host='localhost', port=8765)

client.put('key', {'data': 'value'})
result = client.get('key')
print(result)  # {'data': 'value'}
```

### Async Client

```python
import asyncio
from memory_obj_pool import Client

async def main():
    client = Client(host='localhost', port=8765)
    await client.put('key', {'data': 'value'})
    result = await client.get('key')
    print(result)

asyncio.run(main())
```

## API Reference

### Server

- `Server(host='0.0.0.0', port=8765, max_size=10000)`: Create a server instance
- `server.run()`: Start the server (blocking)
- `await server.start()`: Start the server (async)
- `await server.stop()`: Stop the server

### Client

- `Client(host='localhost', port=8765, auto_reconnect=True)`: Create async client
- `await client.connect()`: Connect to server
- `await client.put(key, obj)`: Store an object
- `await client.get(key)`: Retrieve an object
- `await client.remove(key)`: Remove an object
- `await client.clear()`: Clear all objects
- `await client.size()`: Get pool size
- `await client.contains(key)`: Check if key exists

### SyncClient

- `SyncClient(host='localhost', port=8765, auto_reconnect=True)`: Create sync client
- `client.put(key, obj)`: Store an object
- `client.get(key)`: Retrieve an object
- `client.remove(key)`: Remove an object
- `client.clear()`: Clear all objects
- `client.size()`: Get pool size
- `client.contains(key)`: Check if key exists

## Distributed Usage

```python
from memory_obj_pool import DistributedPool

pool = DistributedPool(
    node_id='node1',
    known_nodes=[('localhost', 8765)]
)
pool.start()
```

## Requirements

- Python 3.7+
- dill
- asyncio

## License

Apache License 2.0