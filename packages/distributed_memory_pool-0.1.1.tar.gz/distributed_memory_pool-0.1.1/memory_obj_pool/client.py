import asyncio
import dill
from typing import Any, Optional, Dict

class Client:
    def __init__(self, host: str = 'localhost', port: int = 8765, auto_reconnect: bool = True):
        self.host = host
        self.port = port
        self.reader = None
        self.writer = None
        self.auto_reconnect = auto_reconnect
        self._connected = False
    
    async def connect(self):
        try:
            self.reader, self.writer = await asyncio.open_connection(self.host, self.port)
            self._connected = True
        except Exception as e:
            self._connected = False
            raise ConnectionError(f"Failed to connect to {self.host}:{self.port}: {e}")
    
    async def _send_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        if not self._connected or self.writer is None or self.reader is None:
            await self.connect()
        
        try:
            data = dill.dumps(request)
            length = len(data).to_bytes(4, byteorder='big')
            
            self.writer.write(length + data)
            await self.writer.drain()
            
            length_data = await self.reader.readexactly(4)
            response_length = int.from_bytes(length_data, byteorder='big')
            response_data = await self.reader.readexactly(response_length)
            
            return dill.loads(response_data)
        except (ConnectionResetError, BrokenPipeError, asyncio.IncompleteReadError) as e:
            self._connected = False
            if self.auto_reconnect:
                await self.connect()
                return await self._send_request(request)
            raise ConnectionError(f"Connection lost: {e}")
    
    async def put(self, key: str, obj: Any) -> bool:
        request = {'action': 'put', 'key': key, 'obj': obj}
        response = await self._send_request(request)
        return response.get('success', False)
    
    async def get(self, key: str) -> Optional[Any]:
        request = {'action': 'get', 'key': key}
        response = await self._send_request(request)
        if response.get('success', False):
            return response.get('data')
        return None
    
    async def remove(self, key: str) -> bool:
        request = {'action': 'remove', 'key': key}
        response = await self._send_request(request)
        return response.get('success', False)
    
    async def clear(self) -> bool:
        request = {'action': 'clear'}
        response = await self._send_request(request)
        return response.get('success', False)
    
    async def size(self) -> int:
        request = {'action': 'size'}
        response = await self._send_request(request)
        if response.get('success', False):
            return response.get('data', 0)
        return 0
    
    async def contains(self, key: str) -> bool:
        request = {'action': 'contains', 'key': key}
        response = await self._send_request(request)
        if response.get('success', False):
            return response.get('data', False)
        return False
    
    async def close(self):
        self._connected = False
        if self.writer:
            self.writer.close()
            await self.writer.wait_closed()
            self.writer = None
            self.reader = None

class SyncClient:
    def __init__(self, host: str = 'localhost', port: int = 8765, auto_reconnect: bool = True):
        self.client = Client(host, port, auto_reconnect)
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
    
    def put(self, key: str, obj: Any) -> bool:
        return self.loop.run_until_complete(self.client.put(key, obj))
    
    def get(self, key: str) -> Optional[Any]:
        return self.loop.run_until_complete(self.client.get(key))
    
    def remove(self, key: str) -> bool:
        return self.loop.run_until_complete(self.client.remove(key))
    
    def clear(self) -> bool:
        return self.loop.run_until_complete(self.client.clear())
    
    def size(self) -> int:
        return self.loop.run_until_complete(self.client.size())
    
    def contains(self, key: str) -> bool:
        return self.loop.run_until_complete(self.client.contains(key))
    
    def close(self):
        self.loop.run_until_complete(self.client.close())
        self.loop.close()
