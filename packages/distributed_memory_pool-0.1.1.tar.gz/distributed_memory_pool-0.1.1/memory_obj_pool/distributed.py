import asyncio
import dill
import socket
import threading
from typing import Dict, Set, Any, Optional
from .pool import Pool
from .client import Client

class DistributedPool:
    def __init__(self, host: str = '0.0.0.0', port: int = 8765, 
                 broadcast_port: int = 8766, max_size: int = 10000):
        self.host = host
        self.port = port
        self.broadcast_port = broadcast_port
        self.pool = Pool(max_size=max_size)
        self.nodes: Set[tuple] = set()
        self.lock = threading.RLock()
        self.running = False
        self.broadcast_thread = None
        self.discovery_thread = None
        self.server = None
    
    async def start(self):
        self.running = True
        # 启动TCP服务器
        self.server = await asyncio.start_server(
            self._handle_client,
            self.host,
            self.port
        )
        print(f"Distributed pool started on {self.host}:{self.port}")
        
        # 启动节点发现
        self.discovery_thread = threading.Thread(target=self._discovery_loop, daemon=True)
        self.discovery_thread.start()
        
        # 启动广播
        self.broadcast_thread = threading.Thread(target=self._broadcast_loop, daemon=True)
        self.broadcast_thread.start()
    
    async def _handle_client(self, reader, writer):
        try:
            while True:
                length_data = await reader.readexactly(4)
                request_length = int.from_bytes(length_data, byteorder='big')
                request_data = await reader.readexactly(request_length)
                
                request = dill.loads(request_data)
                response = self._handle_request(request)
                
                response_data = dill.dumps(response)
                response_length = len(response_data).to_bytes(4, byteorder='big')
                
                writer.write(response_length + response_data)
                await writer.drain()
        except (ConnectionResetError, BrokenPipeError, asyncio.IncompleteReadError):
            pass
        except Exception as e:
            print(f"Client error: {e}")
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except:
                pass
    
    def _handle_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        action = request.get('action')
        key = request.get('key')
        obj = request.get('obj')
        
        response = {'success': False, 'data': None, 'error': None}
        
        try:
            if action == 'put':
                success = self.pool.put(key, obj)
                response['success'] = success
            elif action == 'get':
                result = self.pool.get(key)
                response['success'] = True
                response['data'] = result
            elif action == 'remove':
                success = self.pool.remove(key)
                response['success'] = success
            elif action == 'clear':
                self.pool.clear()
                response['success'] = True
            elif action == 'size':
                size = self.pool.size()
                response['success'] = True
                response['data'] = size
            elif action == 'contains':
                contains = self.pool.contains(key)
                response['success'] = True
                response['data'] = contains
            else:
                response['error'] = f"Unknown action: {action}"
        except Exception as e:
            response['error'] = str(e)
        
        return response
    
    def _broadcast_loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        while self.running:
            try:
                message = dill.dumps({'type': 'HELLO', 'host': self.host, 'port': self.port})
                sock.sendto(message, ('255.255.255.255', self.broadcast_port))
                import time
                time.sleep(5)
            except Exception:
                pass
        
        sock.close()
    
    def _discovery_loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', self.broadcast_port))
        sock.settimeout(1)
        
        while self.running:
            try:
                data, addr = sock.recvfrom(1024)
                message = dill.loads(data)
                if message['type'] == 'HELLO':
                    node = (message['host'], message['port'])
                    if node != (self.host, self.port):
                        with self.lock:
                            self.nodes.add(node)
            except socket.timeout:
                continue
            except Exception:
                pass
        
        sock.close()
    
    def put(self, key: str, obj: Any) -> bool:
        success = self.pool.put(key, obj)
        if success:
            self._sync_to_nodes('put', key, obj)
        return success
    
    def get(self, key: str) -> Optional[Any]:
        obj = self.pool.get(key)
        if obj is not None:
            return obj
        
        with self.lock:
            for node in self.nodes:
                try:
                    client = Client(node[0], node[1])
                    obj = asyncio.run(client.get(key))
                    if obj is not None:
                        self.pool.put(key, obj)
                        return obj
                except Exception:
                    pass
        
        return None
    
    def remove(self, key: str) -> bool:
        success = self.pool.remove(key)
        if success:
            self._sync_to_nodes('remove', key)
        return success
    
    def _sync_to_nodes(self, action: str, key: str, obj: Any = None):
        with self.lock:
            for node in list(self.nodes):
                try:
                    client = Client(node[0], node[1])
                    if action == 'put':
                        asyncio.run(client.put(key, obj))
                    elif action == 'remove':
                        asyncio.run(client.remove(key))
                except Exception:
                    self.nodes.remove(node)
    
    def get_nodes(self):
        with self.lock:
            return list(self.nodes)
    
    def size(self) -> int:
        return self.pool.size()
    
    def contains(self, key: str) -> bool:
        if self.pool.contains(key):
            return True
        
        with self.lock:
            for node in self.nodes:
                try:
                    client = Client(node[0], node[1])
                    if asyncio.run(client.contains(key)):
                        return True
                except Exception:
                    pass
        
        return False
    
    def clear(self) -> bool:
        self.pool.clear()
        self._sync_to_nodes('clear', '')
        return True
    
    async def stop(self):
        self.running = False
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        print("Distributed pool stopped")
