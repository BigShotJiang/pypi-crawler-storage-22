import dill
import threading
from typing import Any, Dict, Optional

class Pool:
    def __init__(self, max_size: int = 10000):
        self._pool: Dict[str, bytes] = {}
        self._objects: Dict[str, Any] = {}
        self._lock = threading.RLock()
        self._max_size = max_size
    
    def put(self, key: str, obj: Any) -> bool:
        with self._lock:
            if len(self._pool) >= self._max_size and key not in self._pool:
                return False
            try:
                self._pool[key] = dill.dumps(obj)
                return True
            except Exception:
                # 如果无法序列化，存储对象引用
                self._objects[key] = obj
                return True
    
    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            if key in self._pool:
                return dill.loads(self._pool[key])
            elif key in self._objects:
                return self._objects[key]
            return None
    
    def remove(self, key: str) -> bool:
        with self._lock:
            existed = key in self._pool or key in self._objects
            if key in self._pool:
                del self._pool[key]
            if key in self._objects:
                del self._objects[key]
            return existed
    
    def clear(self) -> None:
        with self._lock:
            self._pool.clear()
            self._objects.clear()
    
    def size(self) -> int:
        with self._lock:
            return len(self._pool) + len(self._objects)
    
    def contains(self, key: str) -> bool:
        with self._lock:
            return key in self._pool or key in self._objects
