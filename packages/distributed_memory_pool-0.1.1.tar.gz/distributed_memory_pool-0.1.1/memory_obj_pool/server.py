import asyncio
import socket
import sys
import dill
from typing import Dict, Any, Optional
from .pool import Pool

class Server:
    def __init__(self, host: str = '0.0.0.0', port: int = 8765, max_size: int = 10000):
        self.host = host
        self.port = port
        self.pool = Pool(max_size=max_size)
        self.server = None
    
    def _check_port_available(self) -> bool:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind((self.host, self.port))
            return True
        except OSError:
            return False
    
    def _test_existing_service(self) -> bool:
        try:
            test_host = 'localhost' if self.host == '0.0.0.0' else self.host
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(1)
                s.connect((test_host, self.port))
                return True
        except:
            return False
    
    async def handle_client(self, reader, writer):
        try:
            while True:
                length_data = await reader.readexactly(4)
                request_length = int.from_bytes(length_data, byteorder='big')
                request_data = await reader.readexactly(request_length)
                
                request = dill.loads(request_data)
                response = self._handle_request(request)
                
                response_data = dill.dumps(response)
                response_length = len(response_data).to_bytes(4, byteorder='big')
                
                writer.write(response_length + response_data)
                await writer.drain()
        except (ConnectionResetError, BrokenPipeError, asyncio.IncompleteReadError):
            pass
        except Exception as e:
            print(f"Client error: {e}")
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except:
                pass
    
    def _handle_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        action = request.get('action')
        key = request.get('key')
        obj = request.get('obj')
        
        response = {'success': False, 'data': None, 'error': None}
        
        try:
            if action == 'put':
                success = self.pool.put(key, obj)
                response['success'] = success
            elif action == 'get':
                result = self.pool.get(key)
                response['success'] = True
                response['data'] = result
            elif action == 'remove':
                success = self.pool.remove(key)
                response['success'] = success
            elif action == 'clear':
                self.pool.clear()
                response['success'] = True
            elif action == 'size':
                size = self.pool.size()
                response['success'] = True
                response['data'] = size
            elif action == 'contains':
                contains = self.pool.contains(key)
                response['success'] = True
                response['data'] = contains
            else:
                response['error'] = f"Unknown action: {action}"
        except Exception as e:
            response['error'] = str(e)
        
        return response
    
    async def start(self):
        port_available = self._check_port_available()
        
        if not port_available:
            print(f"端口 {self.host}:{self.port} 已被占用")
            service_available = self._test_existing_service()
            
            if service_available:
                print(f"检测到已有服务运行在 {self.host}:{self.port}")
                print(f"该服务可用，无需启动新服务")
                return False
            else:
                print(f"端口被占用但服务不可用，请检查端口状态")
                return False
        
        self.server = await asyncio.start_server(
            self.handle_client,
            self.host,
            self.port
        )
        print(f"Server started on {self.host}:{self.port}")
        return True
    
    def run(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        started = loop.run_until_complete(self.start())
        if started:
            loop.run_forever()
    
    async def stop(self):
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        print("Server stopped")
