from setuptools import setup, find_packages
import os

here = os.path.abspath(os.path.dirname(__file__))

with open(os.path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='distributed-memory-pool',
    version='0.1.1',
    description='A high-performance Python object sharing pool with distributed capabilities',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/15525730080/memory-obj-server',
    author='15525730080',
    author_email='15525730080@qq.com',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: Apache Software License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
    keywords='object pool, distributed, async, tcp, socket, serialization',
    packages=find_packages(exclude=['tests', 'tests.*']),
    python_requires='>=3.7',
    install_requires=[
        'dill>=0.3.6',
    ],
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'pytest-asyncio>=0.21.0',
        ],
    },
    project_urls={
        'Bug Reports': 'https://github.com/15525730080/memory-obj-server/issues',
        'Source': 'https://github.com/15525730080/memory-obj-server',
    },
)
