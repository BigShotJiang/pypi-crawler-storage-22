"""
Constants that both divbase-api and divbase-cli need to agree on.
"""

ONE_MiB = 1024 * 1024

# When you download a file that has been uploaded in parts, you have
# to know the part/chunk size used in order to correctly calculate the composite checksum
S3_MULTIPART_CHUNK_SIZE = 32 * ONE_MiB

# At what point you swap from single part to multipart upload to S3.
# If server and client used the same threshold then makes life easier
# when validating the checksums of files in s3 as single part and multipart uploads use different ETag formats.
# (No benefit in constraining the download threshold, so not done here)
S3_MULTIPART_UPLOAD_THRESHOLD = 96 * ONE_MiB

# Max number of items that can be processed in a single API call to divbase-api's S3 routes
# covers e.g pre-signed urls for upload/download, soft delete and checksum comparisons
# client has to batch requests if exceeding this limit
MAX_S3_API_BATCH_SIZE = 100

# How long the pre-signed URLs divbase-api creates are valid for
SINGLE_PART_UPLOAD_URL_EXPIRATION_SECONDS = 3600  # 1 hour
MULTI_PART_UPLOAD_URL_EXPIRATION_SECONDS = 36000  # 10 hours
DOWNLOAD_URL_EXPIRATION_SECONDS = 36000  # 10 hours

# (Not used anywhere, just making it explicit)
# This is limited by our fixing of the chunk size and S3's limit to the number of chunks allowed (10,000)
# 320 GiB if using 32 MiB chunks
LARGEST_FILE_UPLOADABLE_TO_DIVBASE_BYTES = 10_000 * S3_MULTIPART_CHUNK_SIZE

# File types that DivBase supports
# Whilst we can't realistically limit what file types a user actually uploads,
# this is here to say what we know should work in DivBase.
SUPPORTED_DIVBASE_FILE_TYPES = (".tsv", ".vcf.gz", ".csi", ".tbi")

# Characters that are not allowed in file names uploaded to DivBase
# This is to prevent issues when users try to filter/query files on DivBase using these characters
# or when downloading files (e.g. ":" is used to specify file versions when downloading files
UNSUPPORTED_CHARACTERS_IN_FILENAMES = (":", "*", "?", "<", ">", "|", "\\")

# This prefix is used for all *.vcf.gz results files from a query job/task.
# After the prefix comes the job id which is a rolling integer.
# E.g. format: result_of_job_<job-id>.vcf.gz , where <job-id> = 1 and is auto-incremented for every new job.
QUERY_RESULTS_FILE_PREFIX = "result_of_job_"
