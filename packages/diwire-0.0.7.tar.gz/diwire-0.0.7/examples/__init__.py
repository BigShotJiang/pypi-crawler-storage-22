"""Diwire example modules demonstrating DI container usage patterns."""
