"""Scope management examples."""
