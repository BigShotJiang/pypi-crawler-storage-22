"""Function injection examples using Injected and decorators."""
