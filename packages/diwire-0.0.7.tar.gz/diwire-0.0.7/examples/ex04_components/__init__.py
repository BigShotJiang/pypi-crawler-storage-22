"""Named component registration examples."""
