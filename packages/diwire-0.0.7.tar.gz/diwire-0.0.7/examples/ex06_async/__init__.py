"""Async dependency injection examples."""
