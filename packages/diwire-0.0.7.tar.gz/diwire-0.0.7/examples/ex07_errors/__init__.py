"""Error handling and detection examples."""
