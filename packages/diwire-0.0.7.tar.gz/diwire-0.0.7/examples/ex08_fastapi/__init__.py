"""FastAPI integration examples."""
