"""Django LLM migrations."""
