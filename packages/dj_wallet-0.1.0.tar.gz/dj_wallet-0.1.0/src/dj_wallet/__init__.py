"""
Django Wallets - A secure, flexible virtual wallet system for Django.
"""

__version__ = "0.1.0"
