# dj_wallet/migrations/__init__.py
"""Django migrations package for dj_wallet."""
