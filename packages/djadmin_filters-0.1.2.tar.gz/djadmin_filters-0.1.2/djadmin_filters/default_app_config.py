# This file is intentionally empty - using apps.py directly
