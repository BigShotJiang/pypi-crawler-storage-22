"""Default app config for Django < 3.2 compatibility."""

default_app_config = 'djadmin_formset.apps.DjAdminFormsetConfig'
