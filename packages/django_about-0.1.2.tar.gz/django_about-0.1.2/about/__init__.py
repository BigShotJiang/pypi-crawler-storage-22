"""Django About - System version information for Django admin."""

__version__ = "0.1.2"

default_app_config = 'about.apps.AboutConfig'
