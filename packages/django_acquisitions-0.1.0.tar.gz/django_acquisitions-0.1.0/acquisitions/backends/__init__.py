"""
Communication backends for email and SMS.
"""
