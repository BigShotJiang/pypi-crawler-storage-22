"""Tests for django-acquisitions."""
