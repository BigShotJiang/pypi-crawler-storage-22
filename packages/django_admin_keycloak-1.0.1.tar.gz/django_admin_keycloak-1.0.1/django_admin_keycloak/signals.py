from django.dispatch import Signal

sso_user_login = Signal()
sso_user_logout = Signal()
