var ChatWidgetModule=(()=>{var Se=Object.defineProperty;var Pt=Object.getOwnPropertyDescriptor;var Ht=Object.getOwnPropertyNames;var Ft=Object.prototype.hasOwnProperty;var Nt=(e,t)=>{for(var n in t)Se(e,n,{get:t[n],enumerable:!0})},Ot=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of Ht(t))!Ft.call(e,r)&&r!==n&&Se(e,r,{get:()=>t[r],enumerable:!(o=Pt(t,r))||o.enumerable});return e};var Ut=e=>Ot(Se({},"__esModule",{value:!0}),e);var pn={};Nt(pn,{ChatWidget:()=>Ce,default:()=>_n});var _e,P,je,Wt,Y,Le,Je,Ve,qe,Ee,Me,Te,Lt,oe={},Ge=[],Kt=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,pe=Array.isArray;function X(e,t){for(var n in t)e[n]=t[n];return e}function Ie(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function fe(e,t,n){var o,r,s,i={};for(s in t)s=="key"?o=t[s]:s=="ref"?r=t[s]:i[s]=t[s];if(arguments.length>2&&(i.children=arguments.length>3?_e.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(s in e.defaultProps)i[s]===void 0&&(i[s]=e.defaultProps[s]);return ue(e,i,o,r,null)}function ue(e,t,n,o,r){var s={type:e,props:t,key:n,ref:o,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:r??++je,__i:-1,__u:0};return r==null&&P.vnode!=null&&P.vnode(s),s}function he(e){return e.children}function ne(e,t){this.props=e,this.context=t}function te(e,t){if(t==null)return e.__?te(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?te(e):null}function Xe(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return Xe(e)}}function Ke(e){(!e.__d&&(e.__d=!0)&&Y.push(e)&&!de.__r++||Le!=P.debounceRendering)&&((Le=P.debounceRendering)||Je)(de)}function de(){for(var e,t,n,o,r,s,i,c=1;Y.length;)Y.length>c&&Y.sort(Ve),e=Y.shift(),c=Y.length,e.__d&&(n=void 0,o=void 0,r=(o=(t=e).__v).__e,s=[],i=[],t.__P&&((n=X({},o)).__v=o.__v+1,P.vnode&&P.vnode(n),Ae(t.__P,n,o,t.__n,t.__P.namespaceURI,32&o.__u?[r]:null,s,r??te(o),!!(32&o.__u),i),n.__v=o.__v,n.__.__k[n.__i]=n,Ye(s,n,i),o.__e=o.__=null,n.__e!=r&&Xe(n)));de.__r=0}function Qe(e,t,n,o,r,s,i,c,d,l,u){var a,p,f,$,k,g,v,w=o&&o.__k||Ge,A=t.length;for(d=Bt(n,t,w,d,A),a=0;a<A;a++)(f=n.__k[a])!=null&&(p=f.__i==-1?oe:w[f.__i]||oe,f.__i=a,g=Ae(e,f,p,r,s,i,c,d,l,u),$=f.__e,f.ref&&p.ref!=f.ref&&(p.ref&&Re(p.ref,null,f),u.push(f.ref,f.__c||$,f)),k==null&&$!=null&&(k=$),(v=!!(4&f.__u))||p.__k===f.__k?d=Ze(f,d,e,v):typeof f.type=="function"&&g!==void 0?d=g:$&&(d=$.nextSibling),f.__u&=-7);return n.__e=k,d}function Bt(e,t,n,o,r){var s,i,c,d,l,u=n.length,a=u,p=0;for(e.__k=new Array(r),s=0;s<r;s++)(i=t[s])!=null&&typeof i!="boolean"&&typeof i!="function"?(typeof i=="string"||typeof i=="number"||typeof i=="bigint"||i.constructor==String?i=e.__k[s]=ue(null,i,null,null,null):pe(i)?i=e.__k[s]=ue(he,{children:i},null,null,null):i.constructor===void 0&&i.__b>0?i=e.__k[s]=ue(i.type,i.props,i.key,i.ref?i.ref:null,i.__v):e.__k[s]=i,d=s+p,i.__=e,i.__b=e.__b+1,c=null,(l=i.__i=zt(i,n,d,a))!=-1&&(a--,(c=n[l])&&(c.__u|=2)),c==null||c.__v==null?(l==-1&&(r>u?p--:r<u&&p++),typeof i.type!="function"&&(i.__u|=4)):l!=d&&(l==d-1?p--:l==d+1?p++:(l>d?p--:p++,i.__u|=4))):e.__k[s]=null;if(a)for(s=0;s<u;s++)(c=n[s])!=null&&!(2&c.__u)&&(c.__e==o&&(o=te(c)),tt(c,c));return o}function Ze(e,t,n,o){var r,s;if(typeof e.type=="function"){for(r=e.__k,s=0;r&&s<r.length;s++)r[s]&&(r[s].__=e,t=Ze(r[s],t,n,o));return t}e.__e!=t&&(o&&(t&&e.type&&!t.parentNode&&(t=te(e)),n.insertBefore(e.__e,t||null)),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function zt(e,t,n,o){var r,s,i,c=e.key,d=e.type,l=t[n],u=l!=null&&(2&l.__u)==0;if(l===null&&c==null||u&&c==l.key&&d==l.type)return n;if(o>(u?1:0)){for(r=n-1,s=n+1;r>=0||s<t.length;)if((l=t[i=r>=0?r--:s++])!=null&&!(2&l.__u)&&c==l.key&&d==l.type)return i}return-1}function Be(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Kt.test(t)?n:n+"px"}function ce(e,t,n,o,r){var s,i;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof o=="string"&&(e.style.cssText=o=""),o)for(t in o)n&&t in n||Be(e.style,t,"");if(n)for(t in n)o&&n[t]==o[t]||Be(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")s=t!=(t=t.replace(qe,"$1")),i=t.toLowerCase(),t=i in e||t=="onFocusOut"||t=="onFocusIn"?i.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+s]=n,n?o?n.u=o.u:(n.u=Ee,e.addEventListener(t,s?Te:Me,s)):e.removeEventListener(t,s?Te:Me,s);else{if(r=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function ze(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=Ee++;else if(t.t<n.u)return;return n(P.event?P.event(t):t)}}}function Ae(e,t,n,o,r,s,i,c,d,l){var u,a,p,f,$,k,g,v,w,A,N,J,O,j,V,K,b,F=t.type;if(t.constructor!==void 0)return null;128&n.__u&&(d=!!(32&n.__u),s=[c=t.__e=n.__e]),(u=P.__b)&&u(t);e:if(typeof F=="function")try{if(v=t.props,w="prototype"in F&&F.prototype.render,A=(u=F.contextType)&&o[u.__c],N=u?A?A.props.value:u.__:o,n.__c?g=(a=t.__c=n.__c).__=a.__E:(w?t.__c=a=new F(v,N):(t.__c=a=new ne(v,N),a.constructor=F,a.render=Jt),A&&A.sub(a),a.state||(a.state={}),a.__n=o,p=a.__d=!0,a.__h=[],a._sb=[]),w&&a.__s==null&&(a.__s=a.state),w&&F.getDerivedStateFromProps!=null&&(a.__s==a.state&&(a.__s=X({},a.__s)),X(a.__s,F.getDerivedStateFromProps(v,a.__s))),f=a.props,$=a.state,a.__v=t,p)w&&F.getDerivedStateFromProps==null&&a.componentWillMount!=null&&a.componentWillMount(),w&&a.componentDidMount!=null&&a.__h.push(a.componentDidMount);else{if(w&&F.getDerivedStateFromProps==null&&v!==f&&a.componentWillReceiveProps!=null&&a.componentWillReceiveProps(v,N),t.__v==n.__v||!a.__e&&a.shouldComponentUpdate!=null&&a.shouldComponentUpdate(v,a.__s,N)===!1){for(t.__v!=n.__v&&(a.props=v,a.state=a.__s,a.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(y){y&&(y.__=t)}),J=0;J<a._sb.length;J++)a.__h.push(a._sb[J]);a._sb=[],a.__h.length&&i.push(a);break e}a.componentWillUpdate!=null&&a.componentWillUpdate(v,a.__s,N),w&&a.componentDidUpdate!=null&&a.__h.push(function(){a.componentDidUpdate(f,$,k)})}if(a.context=N,a.props=v,a.__P=e,a.__e=!1,O=P.__r,j=0,w){for(a.state=a.__s,a.__d=!1,O&&O(t),u=a.render(a.props,a.state,a.context),V=0;V<a._sb.length;V++)a.__h.push(a._sb[V]);a._sb=[]}else do a.__d=!1,O&&O(t),u=a.render(a.props,a.state,a.context),a.state=a.__s;while(a.__d&&++j<25);a.state=a.__s,a.getChildContext!=null&&(o=X(X({},o),a.getChildContext())),w&&!p&&a.getSnapshotBeforeUpdate!=null&&(k=a.getSnapshotBeforeUpdate(f,$)),K=u,u!=null&&u.type===he&&u.key==null&&(K=et(u.props.children)),c=Qe(e,pe(K)?K:[K],t,n,o,r,s,i,c,d,l),a.base=t.__e,t.__u&=-161,a.__h.length&&i.push(a),g&&(a.__E=a.__=null)}catch(y){if(t.__v=null,d||s!=null)if(y.then){for(t.__u|=d?160:128;c&&c.nodeType==8&&c.nextSibling;)c=c.nextSibling;s[s.indexOf(c)]=null,t.__e=c}else{for(b=s.length;b--;)Ie(s[b]);xe(t)}else t.__e=n.__e,t.__k=n.__k,y.then||xe(t);P.__e(y,t,n)}else s==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):c=t.__e=jt(n.__e,t,n,o,r,s,i,d,l);return(u=P.diffed)&&u(t),128&t.__u?void 0:c}function xe(e){e&&e.__c&&(e.__c.__e=!0),e&&e.__k&&e.__k.forEach(xe)}function Ye(e,t,n){for(var o=0;o<n.length;o++)Re(n[o],n[++o],n[++o]);P.__c&&P.__c(t,e),e.some(function(r){try{e=r.__h,r.__h=[],e.some(function(s){s.call(r)})}catch(s){P.__e(s,r.__v)}})}function et(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:pe(e)?e.map(et):X({},e)}function jt(e,t,n,o,r,s,i,c,d){var l,u,a,p,f,$,k,g=n.props||oe,v=t.props,w=t.type;if(w=="svg"?r="http://www.w3.org/2000/svg":w=="math"?r="http://www.w3.org/1998/Math/MathML":r||(r="http://www.w3.org/1999/xhtml"),s!=null){for(l=0;l<s.length;l++)if((f=s[l])&&"setAttribute"in f==!!w&&(w?f.localName==w:f.nodeType==3)){e=f,s[l]=null;break}}if(e==null){if(w==null)return document.createTextNode(v);e=document.createElementNS(r,w,v.is&&v),c&&(P.__m&&P.__m(t,s),c=!1),s=null}if(w==null)g===v||c&&e.data==v||(e.data=v);else{if(s=s&&_e.call(e.childNodes),!c&&s!=null)for(g={},l=0;l<e.attributes.length;l++)g[(f=e.attributes[l]).name]=f.value;for(l in g)if(f=g[l],l!="children"){if(l=="dangerouslySetInnerHTML")a=f;else if(!(l in v)){if(l=="value"&&"defaultValue"in v||l=="checked"&&"defaultChecked"in v)continue;ce(e,l,null,f,r)}}for(l in v)f=v[l],l=="children"?p=f:l=="dangerouslySetInnerHTML"?u=f:l=="value"?$=f:l=="checked"?k=f:c&&typeof f!="function"||g[l]===f||ce(e,l,f,g[l],r);if(u)c||a&&(u.__html==a.__html||u.__html==e.innerHTML)||(e.innerHTML=u.__html),t.__k=[];else if(a&&(e.innerHTML=""),Qe(t.type=="template"?e.content:e,pe(p)?p:[p],t,n,o,w=="foreignObject"?"http://www.w3.org/1999/xhtml":r,s,i,s?s[0]:n.__k&&te(n,0),c,d),s!=null)for(l=s.length;l--;)Ie(s[l]);c||(l="value",w=="progress"&&$==null?e.removeAttribute("value"):$!=null&&($!==e[l]||w=="progress"&&!$||w=="option"&&$!=g[l])&&ce(e,l,$,g[l],r),l="checked",k!=null&&k!=e[l]&&ce(e,l,k,g[l],r))}return e}function Re(e,t,n){try{if(typeof e=="function"){var o=typeof e.__u=="function";o&&e.__u(),o&&t==null||(e.__u=e(t))}else e.current=t}catch(r){P.__e(r,n)}}function tt(e,t,n){var o,r;if(P.unmount&&P.unmount(e),(o=e.ref)&&(o.current&&o.current!=e.__e||Re(o,null,t)),(o=e.__c)!=null){if(o.componentWillUnmount)try{o.componentWillUnmount()}catch(s){P.__e(s,t)}o.base=o.__P=null}if(o=e.__k)for(r=0;r<o.length;r++)o[r]&&tt(o[r],t,n||typeof e.type!="function");n||Ie(e.__e),e.__c=e.__=e.__e=void 0}function Jt(e,t,n){return this.constructor(e,n)}function me(e,t,n){var o,r,s,i;t==document&&(t=document.documentElement),P.__&&P.__(e,t),r=(o=typeof n=="function")?null:n&&n.__k||t.__k,s=[],i=[],Ae(t,e=(!o&&n||t).__k=fe(he,null,[e]),r||oe,oe,t.namespaceURI,!o&&n?[n]:r?null:t.firstChild?_e.call(t.childNodes):null,s,!o&&n?n:r?r.__e:t.firstChild,o,i),Ye(s,e,i)}_e=Ge.slice,P={__e:function(e,t,n,o){for(var r,s,i;t=t.__;)if((r=t.__c)&&!r.__)try{if((s=r.constructor)&&s.getDerivedStateFromError!=null&&(r.setState(s.getDerivedStateFromError(e)),i=r.__d),r.componentDidCatch!=null&&(r.componentDidCatch(e,o||{}),i=r.__d),i)return r.__E=r}catch(c){e=c}throw e}},je=0,Wt=function(e){return e!=null&&e.constructor===void 0},ne.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=X({},this.state),typeof e=="function"&&(e=e(X({},n),this.props)),e&&X(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),Ke(this))},ne.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),Ke(this))},ne.prototype.render=he,Y=[],Je=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,Ve=function(e,t){return e.__v.__b-t.__v.__b},de.__r=0,qe=/(PointerCapture)$|Capture$/i,Ee=0,Me=ze(!1),Te=ze(!0),Lt=0;var ot=function(e,t,n,o){var r;t[0]=0;for(var s=1;s<t.length;s++){var i=t[s++],c=t[s]?(t[0]|=i?1:2,n[t[s++]]):t[++s];i===3?o[0]=c:i===4?o[1]=Object.assign(o[1]||{},c):i===5?(o[1]=o[1]||{})[t[++s]]=c:i===6?o[1][t[++s]]+=c+"":i?(r=e.apply(c,ot(e,c,n,["",null])),o.push(r),c[0]?t[0]|=2:(t[s-2]=0,t[s]=r)):o.push(c)}return o},nt=new Map;function st(e){var t=nt.get(this);return t||(t=new Map,nt.set(this,t)),(t=ot(this,t.get(e)||(t.set(e,t=function(n){for(var o,r,s=1,i="",c="",d=[0],l=function(p){s===1&&(p||(i=i.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?d.push(0,p,i):s===3&&(p||i)?(d.push(3,p,i),s=2):s===2&&i==="..."&&p?d.push(4,p,0):s===2&&i&&!p?d.push(5,0,!0,i):s>=5&&((i||!p&&s===5)&&(d.push(s,0,i,r),s=6),p&&(d.push(s,p,0,r),s=6)),i=""},u=0;u<n.length;u++){u&&(s===1&&l(),l(u));for(var a=0;a<n[u].length;a++)o=n[u][a],s===1?o==="<"?(l(),d=[d],s=3):i+=o:s===4?i==="--"&&o===">"?(s=1,i=""):i=o+i[0]:c?o===c?c="":i+=o:o==='"'||o==="'"?c=o:o===">"?(l(),s=1):s&&(o==="="?(s=5,r=i,i=""):o==="/"&&(s<5||n[u][a+1]===">")?(l(),s===3&&(d=d[0]),s=d,(d=d[0]).push(2,0,s),s=0):o===" "||o==="	"||o===`
`||o==="\r"?(l(),s=2):i+=o),s===3&&i==="!--"&&(s=4,d=d[0])}return l(),d}(e)),t),arguments,[])).length>1?t:t[0]}var m=st.bind(fe);var se,U,De,rt,re=0,pt=[],W=P,at=W.__b,it=W.__r,lt=W.diffed,ct=W.__c,ut=W.unmount,dt=W.__;function He(e,t){W.__h&&W.__h(U,e,re||t),re=0;var n=U.__H||(U.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function M(e){return re=1,Vt(ht,e)}function Vt(e,t,n){var o=He(se++,2);if(o.t=e,!o.__c&&(o.__=[n?n(t):ht(void 0,t),function(c){var d=o.__N?o.__N[0]:o.__[0],l=o.t(d,c);d!==l&&(o.__N=[l,o.__[1]],o.__c.setState({}))}],o.__c=U,!U.__f)){var r=function(c,d,l){if(!o.__c.__H)return!0;var u=o.__c.__H.__.filter(function(p){return!!p.__c});if(u.every(function(p){return!p.__N}))return!s||s.call(this,c,d,l);var a=o.__c.props!==c;return u.forEach(function(p){if(p.__N){var f=p.__[0];p.__=p.__N,p.__N=void 0,f!==p.__[0]&&(a=!0)}}),s&&s.call(this,c,d,l)||a};U.__f=!0;var s=U.shouldComponentUpdate,i=U.componentWillUpdate;U.componentWillUpdate=function(c,d,l){if(this.__e){var u=s;s=void 0,r(c,d,l),s=u}i&&i.call(this,c,d,l)},U.shouldComponentUpdate=r}return o.__N||o.__}function L(e,t){var n=He(se++,3);!W.__s&&ft(n.__H,t)&&(n.__=e,n.u=t,U.__H.__h.push(n))}function G(e){return re=5,ae(function(){return{current:e}},[])}function ae(e,t){var n=He(se++,7);return ft(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function z(e,t){return re=8,ae(function(){return e},t)}function qt(){for(var e;e=pt.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(ge),e.__H.__h.forEach(Pe),e.__H.__h=[]}catch(t){e.__H.__h=[],W.__e(t,e.__v)}}W.__b=function(e){U=null,at&&at(e)},W.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),dt&&dt(e,t)},W.__r=function(e){it&&it(e),se=0;var t=(U=e.__c).__H;t&&(De===U?(t.__h=[],U.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(ge),t.__h.forEach(Pe),t.__h=[],se=0)),De=U},W.diffed=function(e){lt&&lt(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(pt.push(t)!==1&&rt===W.requestAnimationFrame||((rt=W.requestAnimationFrame)||Gt)(qt)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),De=U=null},W.__c=function(e,t){t.some(function(n){try{n.__h.forEach(ge),n.__h=n.__h.filter(function(o){return!o.__||Pe(o)})}catch(o){t.some(function(r){r.__h&&(r.__h=[])}),t=[],W.__e(o,n.__v)}}),ct&&ct(e,t)},W.unmount=function(e){ut&&ut(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(o){try{ge(o)}catch(r){t=r}}),n.__H=void 0,t&&W.__e(t,n.__v))};var _t=typeof requestAnimationFrame=="function";function Gt(e){var t,n=function(){clearTimeout(o),_t&&cancelAnimationFrame(t),setTimeout(e)},o=setTimeout(n,35);_t&&(t=requestAnimationFrame(n))}function ge(e){var t=U,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),U=t}function Pe(e){var t=U;e.__c=e.__(),U=t}function ft(e,t){return!e||e.length!==t.length||t.some(function(n,o){return n!==e[o]})}function ht(e,t){return typeof t=="function"?t(e):t}function Xt(e){return e.replace(/_([a-z])/g,(t,n)=>n.toUpperCase())}function Fe(e){return e.replace(/[A-Z]/g,t=>`_${t.toLowerCase()}`)}function ye(e){return Array.isArray(e)?e.map(ye):e!==null&&typeof e=="object"?Object.fromEntries(Object.entries(e).map(([t,n])=>[Xt(t),ye(n)])):e}function ve(e){return Array.isArray(e)?e.map(ve):e!==null&&typeof e=="object"?Object.fromEntries(Object.entries(e).map(([t,n])=>[Fe(t),ve(n)])):e}function we(){return"msg-"+Date.now()+"-"+Math.random().toString(36).substr(2,9)}function B(e){let t=document.createElement("div");return t.textContent=e,t.innerHTML}function mt(e){if(!e)return"";try{let t=new Date(e),o=new Date-t,r=Math.floor(o/6e4),s=Math.floor(o/36e5),i=Math.floor(o/864e5);return r<1?"Just now":r<60?`${r}m ago`:s<24?`${s}h ago`:i<7?`${i}d ago`:t.toLocaleDateString()}catch{return""}}function gt(e,t=null){if(t)return t(e);let n=B(e);return n=n.replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/__(.+?)__/g,"<strong>$1</strong>"),n=n.replace(/\*(.+?)\*/g,"<em>$1</em>"),n=n.replace(/_(.+?)_/g,"<em>$1</em>"),n=n.replace(/`(.+?)`/g,"<code>$1</code>"),n=n.replace(/\[(.+?)\]\((.+?)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>'),n=n.replace(/\n/g,"<br>"),n}function yt(e=""){let t=n=>e?`${n}_${e}`:n;return{get(n){try{return localStorage.getItem(t(n))}catch{return null}},set(n,o){try{let r=t(n);o===null?localStorage.removeItem(r):localStorage.setItem(r,o)}catch{}}}}function vt(e="csrftoken"){let t=document.cookie.split(";");for(let o of t){let[r,s]=o.trim().split("=");if(r===e)return decodeURIComponent(s)}let n=document.querySelector('meta[name="csrf-token"]');return n?n.getAttribute("content"):null}function $e(e){if(e===0)return"0 B";let t=1024,n=["B","KB","MB","GB"],o=Math.floor(Math.log(e)/Math.log(t));return parseFloat((e/Math.pow(t,o)).toFixed(1))+" "+n[o]}function be(e){return e?e.startsWith("image/")?"\u{1F5BC}\uFE0F":e.startsWith("video/")?"\u{1F3AC}":e.startsWith("audio/")?"\u{1F3B5}":e.includes("pdf")?"\u{1F4D5}":e.includes("spreadsheet")||e.includes("excel")?"\u{1F4CA}":e.includes("document")||e.includes("word")?"\u{1F4DD}":e.includes("presentation")||e.includes("powerpoint")?"\u{1F4FD}\uFE0F":e.includes("zip")||e.includes("compressed")?"\u{1F5DC}\uFE0F":(e.includes("text/"),"\u{1F4C4}"):"\u{1F4C4}"}function wt({config:e,debugMode:t,isExpanded:n,isSpeaking:o,messagesCount:r,isLoading:s,currentAgent:i,onClose:c,onToggleExpand:d,onToggleDebug:l,onToggleTTS:u,onClear:a,onToggleSidebar:p}){let{title:f,primaryColor:$,embedded:k,showConversationSidebar:g,showClearButton:v,showDebugButton:w,enableDebugMode:A,showTTSButton:N,showExpandButton:J,enableTTS:O,elevenLabsApiKey:j,ttsProxyUrl:V}=e,K=j||V;return m`
    <div class="cw-header" style=${{backgroundColor:$}}>
      ${g&&m`
        <button
          class="cw-header-btn cw-hamburger"
          onClick=${p}
          title="Conversations"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16">
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <line x1="3" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="18" x2="21" y2="18"></line>
          </svg>
        </button>
      `}

      <div class="cw-title-container">
        <span class="cw-title">${B(f)}</span>
        ${i&&m`
          <span class="cw-current-agent" title="Currently active agent">
            <span class="cw-agent-indicator">🤖</span>
            <span class="cw-agent-name">${B(i.name||i.key)}</span>
          </span>
        `}
      </div>
      
      <div class="cw-header-actions">
        ${v&&m`
          <button 
            class="cw-header-btn" 
            onClick=${a}
            title="Clear"
            disabled=${s||r===0}
          >🗑️</button>
        `}
        
        ${w&&A&&m`
          <button 
            class="cw-header-btn ${t?"cw-btn-active":""}" 
            onClick=${l}
            title="Debug"
          >🐛</button>
        `}
        
        ${N&&K&&m`
          <button 
            class="cw-header-btn ${O?"cw-btn-active":""}" 
            onClick=${u}
            title="TTS"
          >${O?"\u{1F50A}":"\u{1F507}"}</button>
        `}
        
        ${J&&!k&&m`
          <button 
            class="cw-header-btn" 
            onClick=${d}
            title=${n?"Minimize":"Expand"}
          >${n?"\u2296":"\u2295"}</button>
        `}
        
        ${!k&&m`
          <button 
            class="cw-header-btn" 
            onClick=${c}
            title="Close"
          >✕</button>
        `}
      </div>
    </div>
  `}function Ne({msg:e,show:t,onToggle:n}){return t?m`
    <div class="cw-debug-payload">
      <button class="cw-debug-payload-close" onClick=${n}>×</button>
      <pre class="cw-debug-payload-content">${JSON.stringify(e,null,2)}</pre>
    </div>
  `:m`
      <button
        class="cw-debug-payload-btn"
        onClick=${n}
        title="Show message payload"
      >{ }</button>
    `}function $t({onEdit:e,onRetry:t,isLoading:n,position:o,showEdit:r=!0}){return n?null:m`
    <div class="cw-message-actions cw-message-actions-${o||"left"}">
      ${r&&m`
        <button
          class="cw-message-action-btn"
          onClick=${e}
          title="Edit message"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
          </svg>
        </button>
      `}
      <button
        class="cw-message-action-btn"
        onClick=${t}
        title="Retry from here"
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 2v6h-6"></path>
          <path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path>
          <path d="M3 22v-6h6"></path>
          <path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path>
        </svg>
      </button>
    </div>
  `}function Qt({initialContent:e,onSave:t,onCancel:n}){let[o,r]=M(e),s=G(null);return L(()=>{s.current&&(s.current.focus(),s.current.setSelectionRange(o.length,o.length),s.current.style.height="auto",s.current.style.height=s.current.scrollHeight+"px")},[]),m`
    <div class="cw-inline-edit">
      <textarea
        ref=${s}
        class="cw-inline-edit-input"
        value=${o}
        onInput=${d=>{r(d.target.value),d.target.style.height="auto",d.target.style.height=d.target.scrollHeight+"px"}}
        onKeyDown=${d=>{d.key==="Enter"&&!d.shiftKey?(d.preventDefault(),o.trim()&&t(o.trim())):d.key==="Escape"&&n()}}
        rows="1"
      />
      <div class="cw-inline-edit-actions">
        <button
          class="cw-inline-edit-btn cw-inline-edit-cancel"
          onClick=${n}
          title="Cancel (Esc)"
        >Cancel</button>
        <button
          class="cw-inline-edit-btn cw-inline-edit-save"
          onClick=${()=>o.trim()&&t(o.trim())}
          disabled=${!o.trim()}
          title="Save & Resend (Enter)"
        >Save & Send</button>
      </div>
    </div>
  `}function bt({msg:e,debugMode:t,markdownParser:n,onEdit:o,onRetry:r,isLoading:s,messageIndex:i}){let[c,d]=M(!1),[l,u]=M(!1),[a,p]=M(!1),f=e.role==="user",$=e.role==="system",k=e.type==="tool_call",g=e.type==="tool_result",v=e.type==="error",w=e.type==="sub_agent_start",A=e.type==="sub_agent_end",N=e.type==="agent_context";if($&&!t)return null;if(w||A||N)return m`
      <div class="cw-agent-context ${w?"cw-agent-delegating":""} ${A?"cw-agent-returned":""}" style="position: relative;">
        <span class="cw-agent-context-icon">${w?"\u{1F517}":A?"\u2713":"\u{1F916}"}</span>
        <span class="cw-agent-context-text">${e.content}</span>
        ${e.metadata?.agentName&&m`
          <span class="cw-agent-context-name">${e.metadata.agentName}</span>
        `}
        ${t&&m`<${Ne} msg=${e} show=${l} onToggle=${()=>u(!l)} />`}
      </div>
    `;if(k||g){let C=e.metadata?.arguments||e.metadata?.result,T=_=>{if(typeof _=="string")try{return JSON.stringify(JSON.parse(_),null,2)}catch{return _}return JSON.stringify(_,null,2)};return m`
      <div class="cw-tool-message ${g?"cw-tool-result":"cw-tool-call"}" style="position: relative;">
        <span class="cw-tool-label" onClick=${()=>C&&d(!c)}>
          ${e.content}
          ${C&&m`<span class="cw-tool-expand">${c?"\u25BC":"\u25B6"}</span>`}
        </span>
        ${c&&C&&m`
          <pre class="cw-tool-details">${B(T(k?e.metadata.arguments:e.metadata.result))}</pre>
        `}
        ${t&&m`<${Ne} msg=${e} show=${l} onToggle=${()=>u(!l)} />`}
      </div>
    `}let J=["cw-message",f&&"cw-message-user",v&&"cw-message-error"].filter(Boolean).join(" "),O=`cw-message-row ${f?"cw-message-row-user":""}`,j=e.role==="assistant"?gt(e.content,n):B(e.content),V=e.files&&e.files.length>0,K=()=>V?m`
      <div class="cw-message-attachments">
        ${e.files.map(C=>C.type&&C.type.startsWith("image/")?m`
              <a class="cw-attachment-thumbnail" href=${C.url} target="_blank" title=${C.name}>
                <img src=${C.url} alt=${C.name} />
              </a>
            `:m`
            <a class="cw-attachment-file" href=${C.url} target="_blank" title=${C.name}>
              <span class="cw-attachment-icon">${be(C.type)}</span>
              <span class="cw-attachment-info">
                <span class="cw-attachment-name">${C.name}</span>
                <span class="cw-attachment-size">${$e(C.size)}</span>
              </span>
            </a>
          `)}
      </div>
    `:null,b=C=>{p(!1),o&&o(i,C)},F=()=>{r&&r(i)};if(f&&a)return m`
      <div class=${O} style="position: relative;">
        ${K()}
        <${Qt}
          initialContent=${e.content}
          onSave=${b}
          onCancel=${()=>p(!1)}
        />
      </div>
    `;let y=f&&o&&r,H=e.role==="assistant"&&r&&!s;return m`
    <div class="${O} ${y||H?"cw-message-row-with-actions":""}">
      ${K()}
      ${y&&m`
        <div class="cw-user-actions-wrapper">
          <${$t}
            onEdit=${()=>p(!0)}
            onRetry=${F}
            isLoading=${s}
            position="left"
            showEdit=${!0}
          />
          <div class=${J} dangerouslySetInnerHTML=${{__html:j}} />
        </div>
      `}
      ${!y&&m`
        <div class=${J} dangerouslySetInnerHTML=${{__html:j}} />
      `}
      ${H&&m`
        <${$t}
          onRetry=${F}
          isLoading=${s}
          position="right"
          showEdit=${!1}
        />
      `}
      ${t&&m`<${Ne} msg=${e} show=${l} onToggle=${()=>u(!l)} />`}
    </div>
  `}function kt({messages:e,isLoading:t,hasMoreMessages:n,loadingMoreMessages:o,onLoadMore:r,onEditMessage:s,onRetryMessage:i,debugMode:c,markdownParser:d,emptyStateTitle:l,emptyStateMessage:u}){let a=G(null),p=G(!0),f=k=>{let g=k.target,v=g.scrollHeight-g.scrollTop-g.clientHeight<100;if(p.current=v,g.scrollTop<50&&n&&!o){let w=g.scrollHeight;r().then(()=>{let A=g.scrollHeight;g.scrollTop=A-w+g.scrollTop})}};L(()=>{let k=a.current;k&&p.current&&requestAnimationFrame(()=>{k.scrollTop=k.scrollHeight})},[e,t]),L(()=>{let k=a.current;k&&e.length<=2&&(p.current=!0,requestAnimationFrame(()=>{k.scrollTop=k.scrollHeight}))},[e.length]);let $=e.length===0;return m`
    <div class="cw-messages" ref=${a} onScroll=${f}>
      ${$&&m`
        <div class="cw-empty-state">
          <svg class="cw-empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
          <h3>${B(l)}</h3>
          <p>${B(u)}</p>
        </div>
      `}
      
      ${!$&&n&&m`
        <div class="cw-load-more" onClick=${r}>
          ${o?m`<span class="cw-spinner"></span><span>Loading...</span>`:m`<span>↑ Scroll up or click to load older messages</span>`}
        </div>
      `}
      
      ${e.map((k,g)=>m`
        <${bt}
          key=${k.id}
          msg=${k}
          messageIndex=${g}
          debugMode=${c}
          markdownParser=${d}
          onEdit=${s}
          onRetry=${i}
          isLoading=${t}
        />
      `)}
      
      ${t&&m`
        <div class="cw-message-row">
          <div class="cw-typing">
            <span class="cw-spinner"></span>
            <span>Thinking...</span>
          </div>
        </div>
      `}
    </div>
  `}var Oe=typeof window<"u"?window.SpeechRecognition||window.webkitSpeechRecognition:null;function Ct({onSend:e,onCancel:t,isLoading:n,placeholder:o,primaryColor:r,enableVoice:s=!0,enableFiles:i=!0}){let[c,d]=M(""),[l,u]=M([]),[a,p]=M(!1),[f,$]=M(!1),[k]=M(()=>!!Oe),g=G(null),v=G(null),w=G(null),A=G(!1);L(()=>{!n&&g.current&&g.current.focus()},[n]),L(()=>{g.current&&(g.current.style.height="auto",g.current.style.height=Math.min(g.current.scrollHeight,150)+"px")},[c]),L(()=>()=>{A.current=!1,w.current&&w.current.abort()},[]);let N=_=>{_.preventDefault(),(c.trim()||l.length>0)&&!n&&(e(c,l),d(""),u([]),g.current&&(g.current.style.height="auto"),v.current&&(v.current.value=""))},J=_=>{let S=Array.from(_.target.files||[]);S.length>0&&u(I=>[...I,...S])},O=_=>{u(S=>S.filter((I,h)=>h!==_))},j=_=>{_.preventDefault(),v.current&&!n&&v.current.click()},V=_=>{_.key==="Enter"&&!_.shiftKey&&(_.preventDefault(),N(_))},K=_=>{n&&t&&(_.preventDefault(),t())},b=()=>{if(!Oe||n)return;A.current=!0;let _=new Oe;_.continuous=!0,_.interimResults=!0,_.lang=navigator.language||"en-US";let S=c,I="";_.onstart=()=>{$(!0)},_.onresult=h=>{I="";for(let D=h.resultIndex;D<h.results.length;D++){let q=h.results[D][0].transcript;h.results[D].isFinal?S+=(S?" ":"")+q:I+=q}d(S+(I?" "+I:""))},_.onerror=h=>{if(h.error==="no-speech"||h.error==="aborted"){console.log("[ChatWidget] Speech recognition:",h.error,"- continuing...");return}console.warn("[ChatWidget] Speech recognition error:",h.error),A.current=!1,$(!1),d(S||c)},_.onend=()=>{if(A.current){console.log("[ChatWidget] Recognition paused, restarting...");try{_.start();return}catch(h){console.warn("[ChatWidget] Could not restart recognition:",h)}}$(!1),S&&d(S),w.current=null},w.current=_,_.start()},F=()=>{A.current=!1,w.current&&w.current.stop()},y=_=>{_.preventDefault(),f?F():b()},E=m`
    <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
      <rect x="2" y="2" width="10" height="10" rx="1" />
    </svg>
  `,H=m`
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
      <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
      <line x1="12" y1="19" x2="12" y2="23"></line>
      <line x1="8" y1="23" x2="16" y2="23"></line>
    </svg>
  `,x=m`
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path>
    </svg>
  `,C=s&&k,T=i;return m`
    <form class="cw-input-form" onSubmit=${N}>
      <input
        type="file"
        ref=${v}
        style="display: none"
        multiple
        onChange=${J}
      />
      ${l.length>0&&m`
        <div class="cw-file-chips">
          ${l.map((_,S)=>m`
            <div class="cw-file-chip" key=${S}>
              <span class="cw-file-chip-icon">${be(_.type)}</span>
              <span class="cw-file-chip-name" title=${_.name}>${_.name.length>20?_.name.substring(0,17)+"...":_.name}</span>
              <span class="cw-file-chip-size">(${$e(_.size)})</span>
              <button
                type="button"
                class="cw-file-chip-remove"
                onClick=${()=>O(S)}
                title="Remove file"
              >×</button>
            </div>
          `)}
        </div>
      `}
      <textarea
        ref=${g}
        class="cw-input"
        placeholder=${B(o)}
        value=${c}
        onInput=${_=>d(_.target.value)}
        onKeyDown=${V}
        disabled=${n}
        rows="1"
      />
      ${T&&m`
        <button
          type="button"
          class="cw-attach-btn"
          onClick=${j}
          disabled=${n}
          title="Attach files"
        >
          ${x}
        </button>
      `}
      ${C&&m`
        <button
          type="button"
          class=${`cw-voice-btn ${f?"cw-voice-btn-recording":""}`}
          onClick=${y}
          disabled=${n}
          title=${f?"Stop recording":"Voice input"}
        >
          ${H}
        </button>
      `}
      <button
        type=${n?"button":"submit"}
        class=${`cw-send-btn ${n?"cw-send-btn-loading":""} ${n&&a?"cw-send-btn-stop":""}`}
        style=${{backgroundColor:n&&a?"#dc2626":r}}
        onClick=${K}
        onMouseEnter=${()=>p(!0)}
        onMouseLeave=${()=>p(!1)}
        title=${n?"Stop":"Send"}
      >
        ${n?a?E:m`<span class="cw-spinner"></span>`:"\u27A4"}
      </button>
    </form>
  `}function St({isOpen:e,conversations:t,conversationsLoading:n,currentConversationId:o,onClose:r,onNewConversation:s,onSwitchConversation:i}){return m`
    <div class="cw-sidebar ${e?"cw-sidebar-open":""}">
      <div class="cw-sidebar-header">
        <span>Conversations</span>
        <button class="cw-sidebar-close" onClick=${r}>✕</button>
      </div>
      
      <button class="cw-new-conversation" onClick=${s}>
        <span>+ New Conversation</span>
      </button>
      
      <div class="cw-conversation-list">
        ${n&&m`
          <div class="cw-sidebar-loading">
            <span class="cw-spinner"></span>
          </div>
        `}
        
        ${!n&&t.length===0&&m`
          <div class="cw-sidebar-empty">No conversations yet</div>
        `}
        
        ${t.map(c=>m`
          <div 
            key=${c.id}
            class="cw-conversation-item ${c.id===o?"cw-conversation-active":""}"
            onClick=${()=>i(c.id)}
          >
            <div class="cw-conversation-title">${B(c.title||"Untitled")}</div>
            <div class="cw-conversation-date">${mt(c.updatedAt||c.createdAt)}</div>
          </div>
        `)}
      </div>
    </div>
    
    <div 
      class="cw-sidebar-overlay ${e?"cw-sidebar-overlay-visible":""}" 
      onClick=${r}
    />
  `}function Mt({availableModels:e,selectedModel:t,onSelectModel:n,disabled:o}){let[r,s]=M(!1);if(!e||e.length===0)return null;let c=e.find(u=>u.id===t)?.name||"Select Model",d=()=>{o||s(!r)},l=u=>{n(u),s(!1)};return m`
    <div class="cw-model-selector">
      <button 
        class="cw-model-btn" 
        onClick=${d}
        disabled=${o}
        title="Select Model"
      >
        <span class="cw-model-icon">🤖</span>
        <span class="cw-model-name">${B(c)}</span>
        <span class="cw-model-chevron">${r?"\u25B2":"\u25BC"}</span>
      </button>
      
      ${r&&m`
        <div class="cw-model-dropdown">
          ${e.map(u=>m`
            <button 
              key=${u.id}
              class="cw-model-option ${u.id===t?"cw-model-option-selected":""}"
              onClick=${()=>l(u.id)}
            >
              <span class="cw-model-option-name">${B(u.name)}</span>
              <span class="cw-model-option-provider">${B(u.provider)}</span>
              ${u.description&&m`
                <span class="cw-model-option-desc">${B(u.description)}</span>
              `}
            </button>
          `)}
        </div>
      `}
    </div>
  `}function Tt(e,t,n){let[o,r]=M([]),[s,i]=M(!1),[c,d]=M(null),[l,u]=M(()=>n?.get(e.conversationIdKey)||null),[a,p]=M(!1),[f,$]=M(!1),[k,g]=M(0),v=G(null),w=G(null);L(()=>{l&&n?.set(e.conversationIdKey,l)},[l,e.conversationIdKey,n]);let A=z(async(y,E,H)=>{v.current&&v.current.close();let x=e.apiPaths.runEvents.replace("{runId}",y),C=`${e.backendUrl}${x}`;E&&(C+=`?anonymous_token=${encodeURIComponent(E)}`);let T=new EventSource(C);v.current=T;let _="";T.addEventListener("assistant.message",I=>{try{let h=JSON.parse(I.data);e.onEvent&&e.onEvent("assistant.message",h.payload);let D=h.payload.content;D&&(_+=D,r(q=>{let Q=q[q.length-1];return Q?.role==="assistant"&&Q.id.startsWith("assistant-stream-")?[...q.slice(0,-1),{...Q,content:_}]:[...q,{id:"assistant-stream-"+Date.now(),role:"assistant",content:_,timestamp:new Date,type:"message"}]}))}catch(h){console.error("[ChatWidget] Parse error:",h)}}),T.addEventListener("tool.call",I=>{try{let h=JSON.parse(I.data);e.onEvent&&e.onEvent("tool.call",h.payload),r(D=>[...D,{id:"tool-call-"+Date.now(),role:"assistant",content:`\u{1F527} ${h.payload.name}`,timestamp:new Date,type:"tool_call",metadata:{toolName:h.payload.name,arguments:h.payload.arguments,toolCallId:h.payload.id}}])}catch(h){console.error("[ChatWidget] Parse error:",h)}}),T.addEventListener("tool.result",I=>{try{let h=JSON.parse(I.data);e.onEvent&&e.onEvent("tool.result",h.payload);let D=h.payload.result,q=D?.error;r(Q=>[...Q,{id:"tool-result-"+Date.now(),role:"system",content:q?`\u274C ${D.error}`:"\u2713 Done",timestamp:new Date,type:"tool_result",metadata:{toolName:h.payload.name,result:D,toolCallId:h.payload.tool_call_id}}])}catch(h){console.error("[ChatWidget] Parse error:",h)}}),T.addEventListener("custom",I=>{try{let h=JSON.parse(I.data);e.onEvent&&e.onEvent("custom",h.payload),h.payload?.type==="ui_control"&&e.onUIControl&&e.onUIControl(h.payload),h.payload?.type==="agent_context"&&r(D=>[...D,{id:"agent-context-"+Date.now(),role:"system",content:`\u{1F517} ${h.payload.agent_name||"Sub-agent"} is now handling this request`,timestamp:new Date,type:"agent_context",metadata:{agentKey:h.payload.agent_key,agentName:h.payload.agent_name,action:h.payload.action}}])}catch(h){console.error("[ChatWidget] Parse error:",h)}}),T.addEventListener("sub_agent.start",I=>{try{let h=JSON.parse(I.data);e.onEvent&&e.onEvent("sub_agent.start",h.payload),r(D=>[...D,{id:"sub-agent-start-"+Date.now(),role:"system",content:`\u{1F517} Delegating to ${h.payload.agent_name||h.payload.sub_agent_key||"sub-agent"}...`,timestamp:new Date,type:"sub_agent_start",metadata:{subAgentKey:h.payload.sub_agent_key,agentName:h.payload.agent_name,invocationMode:h.payload.invocation_mode}}])}catch(h){console.error("[ChatWidget] Parse error:",h)}}),T.addEventListener("sub_agent.end",I=>{try{let h=JSON.parse(I.data);e.onEvent&&e.onEvent("sub_agent.end",h.payload),r(D=>[...D,{id:"sub-agent-end-"+Date.now(),role:"system",content:`\u2713 ${h.payload.agent_name||"Sub-agent"} completed`,timestamp:new Date,type:"sub_agent_end",metadata:{subAgentKey:h.payload.sub_agent_key,agentName:h.payload.agent_name}}])}catch(h){console.error("[ChatWidget] Parse error:",h)}});let S=I=>{try{let h=JSON.parse(I.data);if(e.onEvent&&e.onEvent(h.type,h.payload),h.type==="run.failed"){let D=h.payload.error||"Agent run failed";d(D),r(q=>[...q,{id:"error-"+Date.now(),role:"system",content:`\u274C Error: ${D}`,timestamp:new Date,type:"error"}])}}catch(h){console.error("[ChatWidget] Parse error:",h)}i(!1),T.close(),v.current=null,_&&H&&H(_)};T.addEventListener("run.succeeded",S),T.addEventListener("run.failed",S),T.addEventListener("run.cancelled",S),T.addEventListener("run.timed_out",S),T.onerror=()=>{i(!1),T.close(),v.current=null}},[e]),N=z(async(y,E={},H={})=>{if(!y.trim()||s)return;let x=[],C={};typeof E=="function"?C={onAssistantMessage:E}:Array.isArray(E)?(x=E,C=H):C=E||{};let{model:T,onAssistantMessage:_,supersedeFromMessageIndex:S}=C;i(!0),d(null);let I={id:we(),role:"user",content:y.trim(),timestamp:new Date,type:"message",files:x.length>0?x.map(h=>({name:h.name,size:h.size,type:h.type})):void 0};r(h=>[...h,I]);try{let h=await t.getOrCreateSession(),D;if(x.length>0){let ee=e.apiCaseStyle!=="camel",We=le=>ee?Fe(le):le,Z=new FormData;Z.append(We("agentKey"),e.agentKey),l&&Z.append(We("conversationId"),l),Z.append("messages",JSON.stringify([{role:"user",content:y.trim()}])),Z.append("metadata",JSON.stringify(ee?{...e.metadata,journey_type:e.defaultJourneyType}:{...e.metadata,journeyType:e.defaultJourneyType})),T&&Z.append("model",T),x.forEach(le=>{Z.append("files",le)}),D=t.getFetchOptions({method:"POST",body:Z},h)}else{let ee=t.transformRequest({agentKey:e.agentKey,conversationId:l,messages:[{role:"user",content:y.trim()}],metadata:{...e.metadata,journeyType:e.defaultJourneyType},...T&&{model:T},...S!==void 0&&{supersedeFromMessageIndex:S}});D=t.getFetchOptions({method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(ee)},h)}let q=await fetch(`${e.backendUrl}${e.apiPaths.runs}`,D);if(!q.ok){let ee=await q.json().catch(()=>({}));throw new Error(ee.error||`HTTP ${q.status}`)}let Q=await q.json(),ie=t.transformResponse(Q);w.current=ie.id,!l&&ie.conversationId&&u(ie.conversationId),await A(ie.id,h,_)}catch(h){d(h.message||"Failed to send message"),i(!1)}finally{w.current=null}},[e,t,l,s,A]),J=z(async()=>{let y=w.current;if(!(!y||!s))try{let E=e.apiPaths.cancelRun?e.apiPaths.cancelRun.replace("{runId}",y):`${e.apiPaths.runs}${y}/cancel/`;(await fetch(`${e.backendUrl}${E}`,t.getFetchOptions({method:"POST",headers:{"Content-Type":"application/json"}}))).ok&&(v.current&&(v.current.close(),v.current=null),i(!1),w.current=null,r(x=>[...x,{id:"cancelled-"+Date.now(),role:"system",content:"\u23F9 Run cancelled",timestamp:new Date,type:"cancelled"}]))}catch(E){console.error("[ChatWidget] Failed to cancel run:",E)}},[e,t,s]),O=z(()=>{r([]),u(null),d(null),p(!1),g(0),n?.set(e.conversationIdKey,null)},[e.conversationIdKey,n]),j=y=>{let E={id:we(),role:y.role,timestamp:y.timestamp?new Date(y.timestamp):new Date};if(y.role==="tool")return{...E,role:"system",content:"\u2713 Done",type:"tool_result",metadata:{result:y.content,toolCallId:y.toolCallId}};if(y.role==="assistant"&&y.toolCalls&&y.toolCalls.length>0)return y.toolCalls.map(x=>({id:we(),role:"assistant",content:`\u{1F527} ${x.function?.name||x.name||"tool"}`,timestamp:E.timestamp,type:"tool_call",metadata:{toolName:x.function?.name||x.name,arguments:x.function?.arguments||x.arguments,toolCallId:x.id}}));let H=typeof y.content=="string"?y.content:JSON.stringify(y.content);return y.role==="assistant"&&!H?.trim()?null:{...E,content:H,type:"message"}},V=z(async y=>{i(!0),r([]),u(y);try{let E=await t.getOrCreateSession(),x=`${e.backendUrl}${e.apiPaths.conversations}${y}/?limit=10&offset=0`,C=await fetch(x,t.getFetchOptions({method:"GET"},E));if(C.ok){let T=await C.json(),_=t.transformResponse(T);_.messages&&r(_.messages.flatMap(j).filter(Boolean)),p(_.hasMore||!1),g(_.messages?.length||0)}else C.status===404&&(u(null),n?.set(e.conversationIdKey,null))}catch(E){console.error("[ChatWidget] Failed to load conversation:",E)}finally{i(!1)}},[e,t,n]),K=z(async()=>{if(!(!l||f||!a)){$(!0);try{let y=await t.getOrCreateSession(),H=`${e.backendUrl}${e.apiPaths.conversations}${l}/?limit=10&offset=${k}`,x=await fetch(H,t.getFetchOptions({method:"GET"},y));if(x.ok){let C=await x.json(),T=t.transformResponse(C);if(T.messages?.length>0){let _=T.messages.flatMap(j).filter(Boolean);r(S=>[..._,...S]),g(S=>S+T.messages.length),p(T.hasMore||!1)}else p(!1)}}catch(y){console.error("[ChatWidget] Failed to load more messages:",y)}finally{$(!1)}}},[e,t,l,k,f,a]),b=z(async(y,E,H={})=>{if(s)return;let x=o[y];if(!x||x.role!=="user")return;let C=o.slice(0,y);r(C),await N(E,{...H,supersedeFromMessageIndex:y})},[o,s,N]),F=z(async(y,E={})=>{if(s)return;let H=o[y];if(!H)return;let x=y,C=H;if(H.role==="assistant"){for(let _=y-1;_>=0;_--)if(o[_].role==="user"){x=_,C=o[_];break}if(C.role!=="user")return}else if(H.role!=="user")return;let T=o.slice(0,x);r(T),await N(C.content,{...E,supersedeFromMessageIndex:x})},[o,s,N]);return L(()=>()=>{v.current&&v.current.close()},[]),{messages:o,isLoading:s,error:c,conversationId:l,hasMoreMessages:a,loadingMoreMessages:f,sendMessage:N,cancelRun:J,clearMessages:O,loadConversation:V,loadMoreMessages:K,setConversationId:u,editMessage:b,retryMessage:F}}function xt(e,t,n){let[o,r]=M([]),[s,i]=M(null),[c,d]=M(null),[l,u]=M(!1);L(()=>{(async()=>{if(e.showModelSelector){u(!0);try{let $=await fetch(`${e.backendUrl}${e.apiPaths.models}`,t.getFetchOptions({method:"GET"}));if($.ok){let k=await $.json(),g=k.models||[];r(g),d(k.default);let v=n?.get(e.modelKey);v&&g.some(w=>w.id===v)?i(v):i(k.default)}}catch($){console.warn("[ChatWidget] Failed to load models:",$)}finally{u(!1)}}})()},[e.backendUrl,e.apiPaths.models,e.showModelSelector,e.modelKey,t,n]);let a=z(f=>{i(f),n?.set(e.modelKey,f)},[e.modelKey,n]),p=z(()=>o.find(f=>f.id===s)||null,[o,s]);return{availableModels:o,selectedModel:s,defaultModel:c,isLoading:l,selectModel:a,getSelectedModelInfo:p}}function Et(e,t,n){let o=l=>!l||typeof l!="object"||e.apiCaseStyle==="camel"?l:ve(l),r=l=>!l||typeof l!="object"||e.apiCaseStyle==="snake"?l:ye(l),s=()=>e.authStrategy?e.authStrategy:e.authToken?"token":e.apiPaths.anonymousSession||e.anonymousSessionEndpoint?"anonymous":"none",i=(l=null)=>{let u=s(),a={},p=l||e.authToken||t().authToken;if(u==="token"&&p){let f=e.authHeader||"Authorization",$=e.authTokenPrefix!==void 0?e.authTokenPrefix:"Token";a[f]=$?`${$} ${p}`:p}else if(u==="jwt"&&p){let f=e.authHeader||"Authorization",$=e.authTokenPrefix!==void 0?e.authTokenPrefix:"Bearer";a[f]=$?`${$} ${p}`:p}else if(u==="anonymous"&&p){let f=e.authHeader||e.anonymousTokenHeader||"X-Anonymous-Token";a[f]=p}if(u==="session"){let f=vt(e.csrfCookieName);f&&(a["X-CSRFToken"]=f)}return a};return{getAuthStrategy:s,getAuthHeaders:i,getFetchOptions:(l={},u=null)=>{let a=s(),p={...l};return p.headers={...p.headers,...i(u)},a==="session"&&(p.credentials="include"),p},getOrCreateSession:async()=>{let l=s(),u=t();if(l!=="anonymous")return e.authToken||u.authToken;if(u.authToken)return u.authToken;let a=e.anonymousTokenKey||e.sessionTokenKey,p=u.storage?.get(a);if(p)return n(f=>({...f,authToken:p})),p;try{let f=e.anonymousSessionEndpoint||e.apiPaths.anonymousSession,$=await fetch(`${e.backendUrl}${f}`,{method:"POST",headers:{"Content-Type":"application/json"}});if($.ok){let k=await $.json();return n(g=>({...g,authToken:k.token})),u.storage?.set(a,k.token),k.token}}catch(f){console.warn("[ChatWidget] Failed to create session:",f)}return null},transformRequest:o,transformResponse:r}}function It({config:e,onStateChange:t,markdownParser:n,apiRef:o}){let[r,s]=M(e.embedded||e.forceOpen===!0),[i,c]=M(!1),[d,l]=M(!1),[u,a]=M(!1),[p,f]=M([]),[$,k]=M(!1),[g,v]=M(e.enableTTS),[w,A]=M(!1),[N,J]=M(null);L(()=>{e.forceOpen!==void 0&&s(e.forceOpen)},[e.forceOpen]);let O=ae(()=>yt(e.containerId),[e.containerId]),[j,V]=M(e.authToken||null),K=ae(()=>Et(e,()=>({authToken:j,storage:O}),I=>{let h=I({authToken:j,storage:O});h.authToken!==j&&V(h.authToken)}),[e,j,O]),b=Tt(e,K,O),F=xt(e,K,O);L(()=>{for(let _=b.messages.length-1;_>=0;_--){let S=b.messages[_];if(S.type==="sub_agent_start"){J({key:S.metadata?.subAgentKey,name:S.metadata?.agentName});return}if(S.type==="sub_agent_end"){J(null);return}}},[b.messages]),L(()=>{let _=O.get(e.conversationIdKey);_&&b.loadConversation(_)},[]),L(()=>{t&&t({isOpen:r,isExpanded:i,debugMode:d,messages:b.messages,conversationId:b.conversationId,isLoading:b.isLoading,error:b.error})},[r,i,d,b.messages,b.conversationId,b.isLoading,b.error]);let y=z(async()=>{if(e.showConversationSidebar){k(!0);try{let _=`${e.backendUrl}${e.apiPaths.conversations}?agent_key=${encodeURIComponent(e.agentKey)}`,S=await fetch(_,K.getFetchOptions({method:"GET"}));if(S.ok){let I=await S.json();f(I.results||I)}}catch(_){console.error("[ChatWidget] Failed to load conversations:",_),f([])}finally{k(!1)}}},[e,K]),E=z(()=>{let _=!u;a(_),_&&y()},[u,y]),H=z(_=>{_!==b.conversationId&&b.loadConversation(_),a(!1)},[b]),x=z(()=>{b.clearMessages(),a(!1)},[b]),C=z(_=>{b.sendMessage(_,{model:F.selectedModel,onAssistantMessage:S=>{}})},[b,g,F.selectedModel]);if(L(()=>{o&&(o.current={open:()=>s(!0),close:()=>s(!1),send:_=>C(_),clearMessages:()=>b.clearMessages(),toggleTTS:()=>v(_=>!_),stopSpeech:()=>A(!1),setAuth:_=>{_.token!==void 0&&V(_.token)},clearAuth:()=>V(null)})},[b,o,C]),!e.embedded&&!r)return m`
      <button 
        class="cw-fab" 
        style=${{backgroundColor:e.primaryColor}}
        onClick=${()=>s(!0)}
      >
        <svg class="cw-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
        </svg>
      </button>
    `;let T=["cw-widget",i&&"cw-widget-expanded",e.embedded&&"cw-widget-embedded"].filter(Boolean).join(" ");return m`
    <div class=${T} style=${{"--cw-primary":e.primaryColor}}>
      ${e.showConversationSidebar&&m`
        <${St}
          isOpen=${u}
          conversations=${p}
          conversationsLoading=${$}
          currentConversationId=${b.conversationId}
          onClose=${()=>a(!1)}
          onNewConversation=${x}
          onSwitchConversation=${H}
        />
      `}
      
      <${wt}
        config=${e}
        debugMode=${d}
        isExpanded=${i}
        isSpeaking=${w}
        messagesCount=${b.messages.length}
        isLoading=${b.isLoading}
        currentAgent=${N}
        onClose=${()=>s(!1)}
        onToggleExpand=${()=>c(!i)}
        onToggleDebug=${()=>l(!d)}
        onToggleTTS=${()=>v(!g)}
        onClear=${b.clearMessages}
        onToggleSidebar=${E}
      />

      ${d&&m`<div class="cw-status-bar"><span>🐛 Debug</span></div>`}

      <${kt}
        messages=${b.messages}
        isLoading=${b.isLoading}
        hasMoreMessages=${b.hasMoreMessages}
        loadingMoreMessages=${b.loadingMoreMessages}
        onLoadMore=${b.loadMoreMessages}
        onEditMessage=${b.editMessage}
        onRetryMessage=${b.retryMessage}
        debugMode=${d}
        markdownParser=${n}
        emptyStateTitle=${e.emptyStateTitle}
        emptyStateMessage=${e.emptyStateMessage}
      />

      ${b.error&&m`<div class="cw-error-bar">${b.error}</div>`}

      ${e.showModelSelector&&F.availableModels.length>0&&m`
        <${Mt}
          availableModels=${F.availableModels}
          selectedModel=${F.selectedModel}
          onSelectModel=${F.selectModel}
          disabled=${b.isLoading}
        />
      `}

      <${Ct}
        onSend=${C}
        onCancel=${b.cancelRun}
        isLoading=${b.isLoading}
        placeholder=${e.placeholder}
        primaryColor=${e.primaryColor}
        enableVoice=${e.enableVoice}
      />
    </div>
  `}var At={backendUrl:"http://localhost:8000",agentKey:"default-agent",title:"Chat Assistant",subtitle:"How can we help you today?",primaryColor:"#0066cc",position:"bottom-right",defaultJourneyType:"general",enableDebugMode:!0,enableAutoRun:!0,journeyTypes:{},customerPrompts:{},placeholder:"Type your message...",emptyStateTitle:"Start a Conversation",emptyStateMessage:"Send a message to get started.",authStrategy:null,authToken:null,authHeader:null,authTokenPrefix:null,anonymousSessionEndpoint:null,anonymousTokenKey:"chat_widget_anonymous_token",onAuthError:null,anonymousTokenHeader:"X-Anonymous-Token",conversationIdKey:"chat_widget_conversation_id",sessionTokenKey:"chat_widget_session_token",apiPaths:{anonymousSession:"/api/accounts/anonymous-session/",conversations:"/api/agent-runtime/conversations/",runs:"/api/agent-runtime/runs/",runEvents:"/api/agent-runtime/runs/{runId}/events/",simulateCustomer:"/api/agent-runtime/simulate-customer/",ttsVoices:"/api/tts/voices/",ttsSetVoice:"/api/tts/set-voice/",models:"/api/agent-runtime/models/"},apiCaseStyle:"auto",showConversationSidebar:!0,showClearButton:!0,showDebugButton:!0,showTTSButton:!0,showVoiceSettings:!0,showExpandButton:!0,showModelSelector:!1,enableVoice:!0,modelKey:"chat_widget_selected_model",autoRunDelay:1e3,autoRunMode:"automatic",enableTTS:!1,ttsProxyUrl:null,elevenLabsApiKey:null,ttsVoices:{assistant:null,user:null},ttsModel:"eleven_turbo_v2_5",ttsSettings:{stability:.5,similarity_boost:.75,style:0,use_speaker_boost:!0},availableVoices:[],onEvent:null,containerId:null,embedded:!1,metadata:{}};function Rt(e){let t={...At.apiPaths,...e.apiPaths||{}};return{...At,...e,apiPaths:t}}var ke=new Map,Zt=0,R=null,Ue=class{constructor(t={}){this.instanceId=`cw-${++Zt}`,this.config=Rt(t),this.container=null,this._state={},this._apiRef={current:null},ke.set(this.instanceId,this)}_handleStateChange=t=>{this._state=t};init(){if(this.config.containerId){if(this.container=document.getElementById(this.config.containerId),!this.container)return console.error(`[ChatWidget] Container not found: ${this.config.containerId}`),this;this.container.classList.add("cw-container-embedded")}else this.container=document.createElement("div"),this.container.id=this.instanceId,this.container.className=`cw-container cw-position-${this.config.position}`,document.body.appendChild(this.container);return this._render(),console.log(`[ChatWidget] Instance ${this.instanceId} initialized`),this}_render(t={}){this.container&&me(m`<${It}
        config=${{...this.config,...t}}
        onStateChange=${this._handleStateChange}
        markdownParser=${Ce._enhancedMarkdownParser}
        apiRef=${this._apiRef}
      />`,this.container)}destroy(){this.container&&(me(null,this.container),this.config.containerId?this.container.classList.remove("cw-container-embedded"):this.container.remove(),this.container=null),ke.delete(this.instanceId),console.log(`[ChatWidget] Instance ${this.instanceId} destroyed`)}open(){this._apiRef.current?this._apiRef.current.open():this._render({forceOpen:!0})}close(){this._apiRef.current?this._apiRef.current.close():this._render({forceOpen:!1})}send(t){this._apiRef.current&&this._apiRef.current.send(t)}clearMessages(){this._apiRef.current&&this._apiRef.current.clearMessages()}toggleTTS(){this._apiRef.current&&this._apiRef.current.toggleTTS()}stopSpeech(){this._apiRef.current&&this._apiRef.current.stopSpeech()}setAuth(t){this._apiRef.current&&this._apiRef.current.setAuth(t)}clearAuth(){this._apiRef.current&&this._apiRef.current.clearAuth()}getState(){return{...this._state}}getConfig(){return{...this.config}}updateMetadata(t){this.config.metadata={...this.config.metadata,...t},this._render(),console.log(`[ChatWidget] Instance ${this.instanceId} metadata updated:`,t)}updateConfig(t){this.config={...this.config,...t},this._render(),console.log(`[ChatWidget] Instance ${this.instanceId} config updated`)}};function Dt(e={}){return new Ue(e).init()}function Yt(e={}){return R&&R.destroy(),R=Dt(e),R}function en(){R&&(R.destroy(),R=null)}function tn(){R&&R.open()}function nn(){R&&R.close()}function on(e){R&&R.send(e)}function sn(){R&&R.clearMessages()}function rn(){R&&R.toggleTTS()}function an(){R&&R.stopSpeech()}function ln(e){R&&R.setAuth(e)}function cn(){R&&R.clearAuth()}function un(){return R?R.getState():null}function dn(){return R?R.getConfig():null}var Ce={createInstance:Dt,getInstance:e=>ke.get(e),getAllInstances:()=>Array.from(ke.values()),init:Yt,destroy:en,open:tn,close:nn,send:on,clearMessages:sn,toggleTTS:rn,stopSpeech:an,setAuth:ln,clearAuth:cn,getState:un,getConfig:dn,_enhancedMarkdownParser:null};var _n=Ce;typeof window<"u"&&(window.ChatWidget=Ce);return Ut(pn);})();
