# Authors

## Project Lead

**Guglielmo Celata** <guglielmo.celata@gmail.com>
- Original author and maintainer
- Architecture and implementation

## Contributors

This project welcomes contributions. See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## Acknowledgments

Thanks to all contributors who have helped improve this project.
