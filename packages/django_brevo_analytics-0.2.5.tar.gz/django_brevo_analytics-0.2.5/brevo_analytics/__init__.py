"""
Django Brevo Analytics
~~~~~~~~~~~~~~~~~~~~~

A reusable Django package for viewing Brevo transactional email
analytics in Django admin.
"""

__version__ = '0.2.4'
