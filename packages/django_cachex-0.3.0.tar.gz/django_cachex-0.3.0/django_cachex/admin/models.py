from __future__ import annotations

from typing import Any

from django.conf import settings
from django.core.cache import InvalidCacheBackendError
from django.db import models


class Cache(models.Model):
    """Unmanaged model representing a Django cache backend for admin display."""

    # Fake primary key - corresponds to cache name
    name = models.CharField(max_length=255, primary_key=True)

    class Meta:
        managed = False
        app_label = "django_cachex"
        default_permissions = ("view", "change")
        verbose_name = "Cache"
        verbose_name_plural = "Caches"

    def __str__(self) -> str:
        return self.name or "Cache"

    @classmethod
    def get_all(cls) -> list[Cache]:
        """Get all configured caches as Cache objects."""
        caches = []
        for name in settings.CACHES:
            cache = cls()
            cache.name = name
            caches.append(cache)
        return caches

    @classmethod
    def get_by_name(cls, name: str) -> Cache | None:
        """Get a Cache object by name."""
        if name in settings.CACHES:
            cache = cls()
            cache.name = name
            return cache
        return None

    @property
    def config(self) -> dict:
        """Get the cache configuration dict."""
        return dict(settings.CACHES.get(self.name, {}))

    @property
    def backend(self) -> str:
        """Get the backend class path."""
        return str(self.config.get("BACKEND", "Unknown"))

    @property
    def backend_short(self) -> str:
        """Get the short backend class name."""
        backend = self.backend
        return backend.rsplit(".", 1)[-1] if "." in backend else backend

    @property
    def location(self) -> str:
        """Get the cache location."""
        loc = self.config.get("LOCATION", "")
        if isinstance(loc, list):
            return ", ".join(str(item) for item in loc)
        return str(loc) if loc else ""

    def _get_cache(self) -> Any | None:
        """Get the raw cache backend."""
        from django.core.cache import caches

        try:
            return caches[self.name]
        except (InvalidCacheBackendError, KeyError):
            return None

    @property
    def support_level(self) -> str:
        """Determine the support level for this cache backend."""
        # Check for _cachex_support attribute on the cache backend (set by wrap_cache
        # or native django-cachex backends)
        cache = self._get_cache()
        if cache is not None and hasattr(cache, "_cachex_support"):
            return cache._cachex_support

        # Fall back to backend string check
        backend = self.backend

        # django-cachex backends - full support
        if backend.startswith("django_cachex."):
            return "cachex"

        # Django core builtin backends - wrapped support
        django_builtins = {
            "django.core.cache.backends.locmem.LocMemCache",
            "django.core.cache.backends.db.DatabaseCache",
            "django.core.cache.backends.filebased.FileBasedCache",
            "django.core.cache.backends.dummy.DummyCache",
            "django.core.cache.backends.memcached.PyMemcacheCache",
            "django.core.cache.backends.memcached.PyLibMCCache",
            "django.core.cache.backends.memcached.MemcachedCache",
        }
        if backend in django_builtins:
            return "wrapped"

        # Unknown/custom backends
        return "limited"

    @property
    def pk(self) -> str:
        """Primary key is the cache name."""
        return self.name

    @pk.setter
    def pk(self, value: str):
        """Set primary key (cache name)."""
        self.name = value


class Key(models.Model):
    """Unmanaged model representing a cache key, identified by (cache_name, key_name)."""

    # Composite identifier: cache_name:key_name
    id = models.CharField(max_length=2048, primary_key=True)

    # Denormalized fields for display
    cache_name = models.CharField(max_length=255)
    key_name = models.CharField(max_length=2048)

    class Meta:
        managed = False
        app_label = "django_cachex"
        default_permissions = ("add", "change", "delete", "view")
        verbose_name = "Key"
        verbose_name_plural = "Keys"

    def __str__(self) -> str:
        return self.key_name or "Key"

    @classmethod
    def make_pk(cls, cache_name: str, key_name: str) -> str:
        """Create a primary key from cache name and key name."""
        return f"{cache_name}:{key_name}"

    @classmethod
    def parse_pk(cls, pk: str) -> tuple[str, str]:
        """Parse a primary key into (cache_name, key_name)."""
        parts = pk.split(":", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
        return "", pk

    @classmethod
    def from_cache_key(cls, cache_name: str, key_name: str) -> Key:
        """Create a Key instance from cache name and key name."""
        key = cls()
        key.id = cls.make_pk(cache_name, key_name)
        key.cache_name = cache_name
        key.key_name = key_name
        return key

    @property
    def pk(self) -> str:
        """Primary key is the encoded cache:key composite."""
        return self.id

    @pk.setter
    def pk(self, value: str):
        """Set primary key and update cache_name/key_name."""
        self.id = value
        self.cache_name, self.key_name = self.parse_pk(value)

    @property
    def cache(self) -> Cache | None:
        """Get the parent Cache object."""
        return Cache.get_by_name(self.cache_name)
