from django.db import models
from django.contrib.auth import get_user_model
from django.contrib.auth.models import User as default_user
UserGet = get_user_model()



class Wallet(models.Model):
    user = models.OneToOneField(default_user, on_delete=models.CASCADE, related_name='wallet_drf_chelseru')
    amount = models.FloatField(default=0.0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'{self.user} - {self.amount}'


class PayMode(models.IntegerChoices):
    CHARGE_WALLET = 1, 'Charge wallet'
    ONLY_PAY = 2, 'Only pay'
    

class Payment(models.Model):
    PAID = 'paid'
    UNPAID = 'unpaid'
    CANCELED = 'canceled'
    REFOUNDED = 'refounded'
    STATUS_CHOICES = [
        (PAID, 'paid'),
        (UNPAID, 'unpaid'),
        (CANCELED, 'canceled'),
        (REFOUNDED, 'refounded')
    ]

    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default=UNPAID)
    user = models.ForeignKey(default_user, models.DO_NOTHING)
    pay_mode = models.IntegerField(choices=PayMode.choices, default=PayMode.CHARGE_WALLET)
    order_id = models.CharField(max_length=20)
    amount = models.FloatField()
    description = models.TextField()
    callback_url = models.URLField()
    mobile = models.CharField(max_length=11, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    currency = models.CharField(max_length=20, blank=True, null=True)

    gateway_title = models.CharField(max_length=25, blank=True, null=True)
    gateway_url = models.URLField(blank=True, null=True)
    authority = models.TextField(blank=True, null=True)
    status_code = models.IntegerField(blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    card_hash = models.TextField(blank=True, null=True)
    card_pan = models.TextField(blank=True, null=True)
    ref_id = models.BigIntegerField(blank=True, null=True)

    data = models.TextField(blank=True, null=True)
    data_verify = models.TextField(blank=True, null=True)

    paid_at = models.TextField(blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'payment id: {self.id} - order id: {self.order_id} amount: {self.amount}'

    def set_request_data(self, **kwargs: dict):
        '''
        inputs:
            currency
            gateway_title
            gateway_url
            callback_url
            authority
            status_code
            message
            data
        '''

        currency = kwargs.get('currency')
        gateway_title = kwargs.get('gateway_title')
        gateway_url = kwargs.get('gateway_url')
        callback_url = kwargs.get('callback_url')
        authority = kwargs.get('authority')
        status_code = kwargs.get('status_code')
        message = kwargs.get('message')
        data = kwargs.get('data')

        if not callback_url:
            return False
        
        self.callback_url = callback_url

        if currency is not None:
            self.currency = currency

        if gateway_title is not None:
            self.gateway_title = gateway_title

        if gateway_url is not None:
            self.gateway_url = gateway_url

        if authority is not None:
            self.authority = authority
        
        if status_code is not None:
            self.status_code = status_code
        
        if message is not None:
            self.message = message

        if data is not None:
            self.data = f'{self.data} | {data}'
        
        self.save()
    
    def set_verify_data(self, **kwargs: dict):
        '''
        inputs:
            is_pay  0=False, 1=True
            status_code
            message
            card_hash
            card_pan
            ref_id
            data_verify
        '''
        is_pay = kwargs.get('is_pay')
        status_code = kwargs.get('status_code')
        message = kwargs.get('message')
        card_hash = kwargs.get('card_hash')
        card_pan = kwargs.get('card_pan')
        ref_id = kwargs.get('ref_id')
        data_verify = kwargs.get('data_verify')
        

        if is_pay == 1:
            if self.status != self.PAID:
                self.status = self.PAID
                if hasattr(self.user, 'wallet_drf_chelseru'):
                    self.user.wallet_drf_chelseru.amount += self.amount
                    self.user.wallet_drf_chelseru.save()

        if status_code is not None:
            self.status_code = status_code

        if message is not None:
            self.message = message

        if card_hash is not None:
            self.card_hash = card_hash

        if card_pan is not None:
            self.card_pan = card_pan

        if ref_id is not None:
            self.ref_id = ref_id

        if data_verify is not None:
            self.data = f'{self.data} | {data_verify}'
            # self.data_verify = data_verify
        
        self.save()
    pass
    