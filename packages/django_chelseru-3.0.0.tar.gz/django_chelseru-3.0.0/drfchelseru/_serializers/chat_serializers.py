from rest_framework.serializers import ModelSerializer, SerializerMethodField
from .._models import (
    ChatRoomModel as ChatRoom,
    MsgModel as MessageChat,
)
from . import DefaultUserSerializer


class ChatRoomSerializer(ModelSerializer):
    user_1, user_2 = DefaultUserSerializer(read_only=True), DefaultUserSerializer(read_only=True)
    users = DefaultUserSerializer(many=True, read_only=True)
    unread_count = SerializerMethodField()

    class Meta:
        model = ChatRoom
        fields = '__all__'
        depth = 1

    
    def get_unread_count(self, obj):
        user = self.context['request'].user
        print(obj.messages_chat_drf_chelseru.exclude(read_by=user).count())
        return obj.messages_chat_drf_chelseru.exclude(read_by=user).count()


class MessageChatSerializer(ModelSerializer):
    sender = DefaultUserSerializer(read_only=True)
    
    class Meta:
        model = MessageChat
        fields = '__all__'
        depth = 1
