from . import MobileSerializer
from .._models import (
    PaymentModel as Payment
)


class PaymentSerializer(MobileSerializer):
    class Meta:
        model = Payment
        fields = '__all__'