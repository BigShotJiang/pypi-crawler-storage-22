import json
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import ChatRoomModel as ChatRoom, MsgModel as MessageChat, AttachFileModel

from django.contrib.auth import get_user_model
from asgiref.sync import sync_to_async
from .signals import chat_message_created


User = get_user_model()

class ChatConsumer(AsyncWebsocketConsumer):
    @sync_to_async
    def is_user_in_chat_room(self, user, chat_room):
        if chat_room.users.filter(id=user.id).exists():
            return True
        return user == chat_room.user_1 or user == chat_room.user_2

    async def connect(self):
        user = self.scope["user"]
        if user.is_authenticated:
            self.user = user
            self.chat_room_id = self.scope['url_route']['kwargs']['chat_room_id']
            self.chat_room = await sync_to_async(ChatRoom.objects.get)(id=self.chat_room_id)

            if not await self.is_user_in_chat_room(user, self.chat_room):
                await self.close()
                return

            self.room_group_name = f"chat_{self.chat_room.id}"

            # Join room group
            await self.channel_layer.group_add(
                self.room_group_name,
                self.channel_name
            )

            await self.accept()
        else:
            await self.close()

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        user = self.scope["user"]
        data = json.loads(text_data)
        msg_type = data.get('message_type', 'text')

        # هندل کردن پیام‌های فایل‌دار یا لوکیشن
        message_text = data.get('message', '')
        attach_id = data.get('attach_id') # آیدی که از ویو آپلود گرفتیم
        lat = data.get('lat')
        lng = data.get('lng')

        # ایجاد پیام در دیتابیس
        chat_message = await sync_to_async(MessageChat.objects.create)(
            chat_room=self.chat_room,
            sender=user,
            text=message_text,
            message_type=msg_type, # اگر فیلد را اضافه کردی
            lat=lat,
            lng=lng
        )

        # اگر فایل بود، پیام را به AttachFile وصل می‌کنیم
        file_url = None
        if attach_id:
            attach = await sync_to_async(AttachFileModel.objects.get)(id=attach_id)
            attach.message = chat_message
            await sync_to_async(attach.save)()
            file_url = attach.file.url

        # ارسال به گروه (Broadcast)
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'id': chat_message.id,
                'message': chat_message.text,
                'message_type': msg_type,
                'file_url': file_url,
                'lat': lat,
                'lng': lng,
                'sender': {'id': user.id, 'username': user.username},
                'created_at': chat_message.created_at.isoformat()
            }
        )

    # اضافه کردن هندلر جدید برای سیگنال‌ها
    async def webrtc_signal(self, event):
        # پیام را به همه به جز فرستنده بفرست
        if self.scope['user'].id != event['sender_id']:
            await self.send(text_data=json.dumps(event['data']))

    async def chat_message(self, event):
        # Send message to WebSocket
        await self.send(text_data=json.dumps(event))