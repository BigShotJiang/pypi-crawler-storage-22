from django.db import models
from django.contrib.auth import get_user_model
from . import UserModel as User
from django.core.exceptions import ValidationError

def validate_file_size(value):
    # محدودیت ۵ مگابایت (قابل تغییر)
    if value.size > 200 * 1024 * 1024:
        raise ValidationError("حداکثر حجم مجاز فایل 200 مگابایت است.")

UserGet = get_user_model()


class Organization(models.Model):
    owner = models.OneToOneField(UserGet, related_name='organization_drf_chelseru', on_delete=models.DO_NOTHING)
    name = models.CharField(max_length=45)
    uname = models.CharField(max_length=45, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'owner: {self.owner} - unique name: {self.uname}'


class ChatRoomPermissions(models.Model):
    READ_ONLY = 0
    MEMBER = 1
    CAN_ADD_MEMBER = 2
    CAN_KICK_MEMBER = 3
    CAN_BAN_MEMBER = 4
    CAN_ADD_ACCESS = 5
    CAN_REMOVE_ACCESS = 6
    CAN_KICK_ADMIN = 7
    CAN_CLOSE_CHAT = 8
    CAN_REOPEN_CHAT = 9
    CAN_RENAME_CHAT = 10
    CAN_UPDATE_AVATAR = 11
    CAN_DELETE_CHAT = 12

    ACCESS_CHOICES = [
        (READ_ONLY, 'Read Only'),
        (MEMBER, 'Member'),
        (CAN_ADD_MEMBER, 'Can Add Members'),
        (CAN_KICK_MEMBER, 'Can Kick Members'),
        (CAN_BAN_MEMBER, 'Can Ban Members'),
        (CAN_ADD_ACCESS, 'Can Add Access'),
        (CAN_REMOVE_ACCESS, 'Can Remove Accessa'),
        (CAN_KICK_ADMIN, 'Can Kick Admins'),
        (CAN_CLOSE_CHAT, 'Can Close Chat Room'),
        (CAN_REOPEN_CHAT, 'Can ReOpen Chat Room'),
        (CAN_RENAME_CHAT, 'Can Rename Chat Room'),
        (CAN_UPDATE_AVATAR, 'Can Update Chatroom Avatar'),
        (CAN_DELETE_CHAT, 'Can Delete Chat Room'),
    ]
    user = models.ManyToManyField(UserGet, related_name='user_drf_chelseru')
    access = models.IntegerField(choices=ACCESS_CHOICES, default=MEMBER)

    def __str__(self):
        return f'user: {self.user} - access: {self.access}'


class ChatRoom(models.Model):
    STATUS_OPEN = 1
    STATUS_CLOSE = 2
    STATUS_HOLD = 3

    STATUS_CHOICES = [
        (STATUS_OPEN, 'Open'),
        (STATUS_CLOSE, 'Close'),
        (STATUS_HOLD, 'Hold')
    ]

    user_1 = models.ForeignKey(UserGet, on_delete=models.CASCADE, related_name='user1_chats_drf_chelseru', blank=True, null=True)
    user_2 = models.ForeignKey(UserGet, on_delete=models.CASCADE, related_name='user2_chats_drf_chelseru', blank=True, null=True)

    users = models.ManyToManyField(UserGet, blank=True, related_name='users_drf_chelseru')
    organization = models.ForeignKey(Organization, on_delete=models.DO_NOTHING, related_name='chatroom_drf_chelseru', blank=True, null=True)
    pinned_for = models.ManyToManyField(UserGet, blank=True, related_name='pinned_drf_chelseru')
    permissions = models.ManyToManyField(ChatRoomPermissions, blank=True, related_name='permissions_drf_chelseru')
    status = models.IntegerField(choices=STATUS_CHOICES, default=STATUS_OPEN)
    banneds = models.ManyToManyField(UserGet, blank=True, related_name='bans_drf_chelseru')
    name = models.CharField(max_length=45, blank=True, null=True)
    descriptions = models.TextField(blank=True, null=True)

    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ()

    def __str__(self):
        return f"ID: {self.id}"


class MessageChat(models.Model):
    MESSAGE_TYPES = [
        ('text', 'Text'),
        ('image', 'Image'),
        ('file', 'File'),
        ('location', 'Location'),
    ]
    message_type = models.CharField(max_length=10, choices=MESSAGE_TYPES, default='text')
    chat_room = models.ForeignKey(ChatRoom, on_delete=models.CASCADE, related_name='messages_chat_drf_chelseru')
    sender = models.ForeignKey(UserGet, on_delete=models.CASCADE)
    text = models.TextField()
    read_by = models.ManyToManyField(UserGet, related_name="read_messages_drf_chelseru", blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    lat = models.FloatField(null=True, blank=True)
    lng = models.FloatField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        is_new = self._state.adding 
        super().save(*args, **kwargs)
        
        if is_new:
            self.chat_room.updated_at = self.created_at
            self.chat_room.save(update_fields=['updated_at'])

    def __str__(self):
        return f"iD: {self.id} | Message from {self.sender.username} at {self.timestamp} | Chatroom ID: {self.chat_room.id}"
    


class AttachFile(models.Model):
    user = models.ForeignKey(UserGet, on_delete=models.CASCADE, related_name='files_sended_drf_chelseru')
    chatroom = models.ForeignKey(ChatRoom, on_delete=models.CASCADE, related_name='chatroomfiles_drf_chelseru')
    message = models.ForeignKey(MessageChat, on_delete=models.SET_NULL, blank=True, null=True, related_name='messagefiles_drf_chelseru')
    
    # فیلد اصلی فایل
    file = models.FileField(upload_to='uploads/chat_files/%Y/%m/%d/', validators=[validate_file_size])
    file_type = models.CharField(max_length=20, blank=True) # مثلا image/jpeg
    
    text = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"File from {self.user.username} - {self.file.name}"