from rest_framework.serializers import ModelSerializer, SerializerMethodField
from ..models import (
    ChatRoomModel as ChatRoom,
    MsgModel as MessageChat,
    AttachFileModel
)
from . import DefaultUserSerializer


class ChatRoomSerializer(ModelSerializer):
    user_1, user_2 = DefaultUserSerializer(read_only=True), DefaultUserSerializer(read_only=True)
    users = DefaultUserSerializer(many=True, read_only=True)
    unread_count = SerializerMethodField()

    class Meta:
        model = ChatRoom
        fields = '__all__'
        depth = 1

    
    def get_unread_count(self, obj):
        user = self.context['request'].user
        return obj.messages_chat_drf_chelseru.exclude(read_by=user).count()


class MessageChatSerializer(ModelSerializer):
    sender = DefaultUserSerializer(read_only=True)
    file_url = SerializerMethodField()

    class Meta:
        model = MessageChat
        fields = '__all__'
        depth = 1

    def get_file_url(self, obj):
        # پیدا کردن اولین فایل مرتبط با این پیام
        attachment = obj.messagefiles_drf_chelseru.first()
        if attachment:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(attachment.file.url)
            return attachment.file.url
        return None


class AttachFileSerializer(ModelSerializer):
    class Meta:
        model = AttachFileModel
        fields = ['id', 'file', 'chatroom', 'text', 'created_at']