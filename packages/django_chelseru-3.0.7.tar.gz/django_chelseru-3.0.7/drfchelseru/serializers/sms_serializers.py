from rest_framework.serializers import ModelSerializer
from ..models import (
    OTPModel as OTPCode,
    SMSModel as MessageSMS,
)


class OTPCodeSerializer(ModelSerializer):
    class Meta:
        model = OTPCode
        fields = '__all__'
        read_only_fields = ('code', )


class MessageSerializer(ModelSerializer):
    class Meta:
        model = MessageSMS
        fields = '__all__'