from . import MobileSerializer
from ..models import (
    PaymentModel as Payment
)


class PaymentSerializer(MobileSerializer):
    class Meta:
        model = Payment
        fields = '__all__'