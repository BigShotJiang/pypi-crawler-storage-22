from django.core.exceptions import ImproperlyConfigured
from ...services.pay_services.pay_payping import PaypingIR
from ...services.pay_services.pay_zarinpal import ZarinpalCom
from ...settings import bank_init_check, GATEWAY_PAYPING, GATEWAY_ZARINPAL



def create_payment(amount, description, merchant_id=None, callback_url=None, order_id=None, mobile=None, email=None, currency=None, client_refid=None, **kwargs):
    try:
        ickeck = bank_init_check()
        gateway = ickeck['gateway']
        if not merchant_id:
            merchant_id = ickeck['settings'].get('merchant_id')
        if not callback_url:
            callback_url = ickeck['settings'].get('callback_url')
        if not currency:
            currency = ickeck['settings'].get('currency')

        # callback_url = callback_url + '/payment/callback/' if callback_url[-1] != '/' else callback_url + 'payment/callback/'

        response = None
        match gateway:
            case gw if gw == GATEWAY_ZARINPAL:
                gw = ZarinpalCom(merchant_id=merchant_id)
                _response = gw.create_payment(amount, callback_url, description, order_id, mobile, email, currency)
                if 'data' not in _response:
                    response = {
                        'callback_url': callback_url, 
                        'message': _response['errors'].get('message'), 
                        'status_code': _response['errors'].get('code'), 
                        'data': _response['errors']
                        }
                else:
                    response = {
                        'currency': currency,
                        'gateway_title': GATEWAY_ZARINPAL,
                        'gateway_url': f"https://payment.zarinpal.com/pg/StartPay/{_response['data'].get('authority')}",
                        'callback_url': callback_url,
                        'authority': _response['data'].get('authority'),
                        'status_code': _response['data'].get('code'),
                        'message': _response['data'].get('message'),
                        'data': _response['data']
                    }
            
            case gw if gw == GATEWAY_PAYPING:
                gw = PaypingIR(merchant_id=merchant_id)
                _response = gw.create_payment(amount, callback_url, description, order_id, mobile, email, client_refid)
                if 'errors' in _response:
                    response = {
                        'callback_url': callback_url, 
                        'message': _response['errors'].get('message'), 
                        'status_code': _response['errors'].get('code'), 
                        'data': _response['errors']
                        }
                else:
                    response = {
                        'gateway_title': GATEWAY_PAYPING,
                        'gateway_url': _response['url'],
                        'callback_url': callback_url,
                        'authority': _response['paymentCode'],
                        'status_code': 100,
                        'data': _response
                    }

        if response is not None:
            return response
    except ImproperlyConfigured as e:
        raise
    except:
        pass


def verify_payment(authority, amount, merchant_id=None, payment_refid:int=None, card_number:str=None, card_hash_pan:str=None):
    try:
        ickeck = bank_init_check()
        gateway = ickeck['gateway']
        if not merchant_id:
            merchant_id = ickeck['settings'].get('merchant_id')
        response = None
        match gateway:
            case gw if gw == GATEWAY_ZARINPAL:
                gw = ZarinpalCom(merchant_id=merchant_id)
                _response = gw.verify_payment(authority, amount)
                if 'data' not in _response:
                    response = {
                        'is_pay': 1 if _response['errors'].get('code') in [101, 100] else 0,
                        'status_code': _response['errors'].get('code'),
                        'message': _response['errors'].get('message'),
                        'data_verify': _response['errors'],
                    }
                else:
                    response = {
                        'is_pay': 1 if _response['data'].get('code') in [101, 100] else 0,
                        'status_code': _response['data'].get('code'),
                        'message': _response['data'].get('message'),
                        'card_hash': _response['data'].get('card_hash'),
                        'card_pan': _response['data'].get('card_pan'),
                        'ref_id': _response['data'].get('ref_id'),
                        'data_verify': _response['data'],
                    }
            
            case gw if gw == GATEWAY_PAYPING:
                gw = PaypingIR(merchant_id=merchant_id)
                _response = gw.verify_payment(authority, int(amount), payment_refid, card_number, card_hash_pan)
                if 'errors' in _response:
                    response = {
                        'is_pay': 1 if _response['errors'].get('code') == 110 else 0,
                        'message': _response['errors'].get('message'), 
                        'status_code': _response['errors'].get('code'),
                        'ref_id': _response['errors'].get('ref_id'),
                        'card_pan': _response['errors'].get('card_number'),
                        'card_hash': _response['errors'].get('card_hash_pan'),
                        'data_verify': _response['errors']
                    }
                else:
                    response = {
                        'is_pay': 1 if 'code' in _response and _response.get('code') not in [500, 503, 401, 403, 404, 200, 400] else 0,
                        'message': _response['code'],
                        'status_code': 100,
                        'ref_id': _response['paymentRefId'],
                        'card_pan': _response['cardNumber'],
                        'card_hash': _response['cardHashPan'],
                        'paid_at': _response['payedDate'],
                        'data_verify': _response
                    }
                
        if response is not None:
            return response
    except ImproperlyConfigured as e:
        raise