import requests


class ZarinpalCom:
    """
    merchant_id
    currency
    """
    def __init__(self, merchant_id):
        self.merchant_id = merchant_id

    def create_payment(self, amount, callback_url, description, order_id=None, mobile=None, email=None, currency=None, **metadata):
        '''
        curl -X POST \
            https://payment.zarinpal.com/pg/v4/payment/request.json \
            -H 'accept: application/json' \
            -H 'content-type: application/json' \
            -d '{
            "merchant_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
            "amount": 1000,
            "callback_url": "http://your-site.com/verify",
            "description": "Transaction description.",
            "metadata": {"mobile": "09121234567","email": "info.test@gmail.com"}
            }
            ___

            {
            "data": {
                "code": 100,
                "message": "Success",
                "authority": "A0000000000000000000000000000wwOGYpd",
                "fee_type": "Merchant",
                "fee": 100
            },
            "errors": []
            }


            merchant_id	String	بله	كد ۳۶ كاراكتری اختصاصی پذیرنده
            amount	Integer	بله	مبلغ تراكنش
            currency	String	خیر	تعیین واحد پولی ریال (IRR) یا تومان(IRT)
            description	String	بله	توضیحات مربوط به تراکنش
            callback_url	String	بله	صفحه بازگشت مشتري، پس از انجام عمل پرداخت
            metadata	Array		دارای مقدار های mobile و email و order_id
            mobile	String	خیر	شماره تماس خریدار
            email	String	خیر	ایمیل خریدار
            order_id	String	خیر	شماره سفارش
        '''
        url = 'https://payment.zarinpal.com/pg/v4/payment/request.json'
        headers = {
            'accept': 'application/json',
            'content-type': 'application/json'
        }
        try:
            data = metadata
            data['merchant_id'] = self.merchant_id
            data['amount'] = amount
            data['callback_url'] = callback_url
            data['description'] = description
            if order_id:
                data['order_id'] = order_id
            
            if mobile:
                data['mobile'] = mobile
            
            if email:
                data['email'] = email

            if currency:
                data['currency'] = currency
            
            response = requests.post(url=url, data=data)

            if 'errors' in response.json() and 'code' in response.json()['errors']:
                return {'errors': response.json()['errors']}

            return response.json()
            
        except:
            return False
    

    def verify_payment(self, authority, amount):
        '''
        curl -X POST \
            https://payment.zarinpal.com/pg/v4/payment/verify.json \
                    -H 'accept: application/json' \
            -H 'content-type: application/json' \
            -d '{
            "merchant_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
                    "amount": 1000,
                    "authority": "A0000000000000000000000000000wwOGYpd"
            }'


        {
            "data": {
                "code": 100,
                "message": "Verified",
                "card_hash": "1EBE3EBEBE35C7EC0F8D6EE4F2F859107A87822CA179BC9528767EA7B5489B69",
                "card_pan": "502229******5995",
                "ref_id": 201,
                "fee_type": "Merchant",
                "fee": 0
            },
            "errors": []
            }


            code	Integer	عددی كه نشان دهنده موفق بودن یا موفق نبودن پرداخت است.
            ref_id	Integer	در صورتی كه پرداخت موفق باشد، شماره تراكنش پرداخت انجام شده را بر می‌گرداند.
            card_pan	String	شماره کارت به صورت Mask
            card_hash	String	هش کارت به صورت SHA256
            fee_type	String	پرداخت کننده کارمزد: که در پنل کاربری میان خریدار یا خود پذیرنده قابل انتخاب است.
            fee	Integer	کارمزد
        '''
        url = 'https://payment.zarinpal.com/pg/v4/payment/verify.json'
        headers = {
            'accept': 'application/json',
            'content-type': 'application/json'
        }
        data = {
            'merchant_id': self.merchant_id,
            'amount': int(amount),
            'authority': authority
        }

        try:
            response = requests.post(url=url, data=data)
            response = response.json()
            if 'errors' in response and 'code' in response['errors']:
                return {'errors': response['errors']}
            
            return response
        except:
            return False

 