from zeep import Client


class MeliPayamakCom:
    '''
    username
    password
    from
    to
    text
    '''
    USERNAME = None
    PASSWORD = None
    FROM = None

    def __init__(self, mobile, options, *args, **kwargs):
        self.RECEIVER = mobile
        if options and 'username' in options and 'password' in options and 'from' in options:
            self.USERNAME = options['username']
            self.PASSWORD = options['password']
            self.FROM = options['from']

    def send_message(self, message):
        try:
            client = Client(wsdl='https://api.payamak-panel.com/post/Send.asmx?wsdl')
            data = {
                'username': self.USERNAME,
                'password': self.PASSWORD,
                'from': self.FROM,
                'to': self.RECEIVER,
                'text': message,
                'isflash': False
            }

            response = client.service.SendSimpleSMS2(**data)
            return response
            """
                response:
                    status:
                        recld (Unique value for each successful submission)
                        0   The username or password is incorrect.
                        2   Not enough credit.
                        3   Limit on daily sending.
                        4   Limit on sending volume.
                        5   The sender's number is not valid.
                        6   The system is being updated.
                        7   The text contains the filtered word.
                        9   Sending from public lines via web service is not possible.
                        10  The desired user is not active.
                        11  Not sent.
                        12  The user's credentials are not complete.
                        14  The text contains a link.
                        15  Sending to more than 1 mobile number is not possible without inserting "لغو11".
                        16  No recipient number found
                        17  The text of the SMS is empty.
                        35  In REST, it means that the number is on the blacklist of communications.
            """
        except:
            return False

    def generate_response(self, api_response, mobile_number, message_text):
        from rest_framework.status import HTTP_502_BAD_GATEWAY, HTTP_200_OK
        obj_status = api_response
        if api_response in [0, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 14, 15, 16, 17, 35]:
            response_data = {'details': 'The SMS service provider was unable to process the request.', 'errorcode': api_response}
            response_status_code = HTTP_502_BAD_GATEWAY
            is_successfully = False
        else:
            response_data = {'receiver': mobile_number, 'message': message_text, 'messageid': api_response}
            response_status_code = HTTP_200_OK
            is_successfully = True
        return is_successfully, {'data': response_data, 'obj_status': obj_status, 'status': response_status_code}

