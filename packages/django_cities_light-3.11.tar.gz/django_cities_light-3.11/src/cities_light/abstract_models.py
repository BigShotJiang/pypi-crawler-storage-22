import re
import autoslug
import pytz

from django.db import models
from django.db.models import lookups
from django.utils.encoding import force_str
from django.conf import settings
from django.utils.translation import gettext_lazy as _

from unidecode import unidecode

from .validators import timezone_validator
from .settings import INDEX_SEARCH_NAMES, CITIES_LIGHT_APP_NAME

__all__ = [
    "AbstractCountry",
    "AbstractRegion",
    "AbstractSubRegion",
    "AbstractCity",
    "CONTINENT_CHOICES",
]

CONTINENT_CHOICES = (
    ("OC", _("Oceania")),
    ("EU", _("Europe")),
    ("AF", _("Africa")),
    ("NA", _("North America")),
    ("AN", _("Antarctica")),
    ("SA", _("South America")),
    ("AS", _("Asia")),
)

ALPHA_REGEXP = re.compile(r"[\W_]+", re.UNICODE)


def to_ascii(value):
    """
    Convert a unicode value to ASCII-only unicode string.

    For example, 'République Françaisen' would become 'Republique Francaisen'
    """
    return force_str(unidecode(value))


def to_search(value):
    """
    Convert a string value into a string that is usable against
    City.search_names.

    For example, 'Paris Texas' would become 'paristexas'.
    """

    return ALPHA_REGEXP.sub("", to_ascii(value)).lower()


class ToSearchIContainsLookup(lookups.IContains):
    """IContains lookup for ToSearchTextField."""

    def get_prep_lookup(self):
        """Return the value passed through to_search()."""
        value = super().get_prep_lookup()
        return to_search(value)


class ToSearchTextField(models.TextField):
    """
    Trivial TextField subclass that passes values through to_search
    automatically.
    """


ToSearchTextField.register_lookup(ToSearchIContainsLookup)


class BaseManager(models.Manager):
    def get_by_natural_key(self, geoname_id):
        return self.get(geoname_id=geoname_id)


class Base(models.Model):
    """
    Base model with boilerplate for all models.
    """

    name = models.CharField(max_length=200, db_index=True, verbose_name=_("name"))
    name_ascii = models.CharField(
        max_length=200, blank=True, db_index=True, verbose_name=_("ASCII name")
    )
    slug = autoslug.AutoSlugField(populate_from="name_ascii", verbose_name=_("slug"))
    geoname_id = models.IntegerField(
        null=True, blank=True, unique=True, verbose_name=_("Geonames ID")
    )
    alternate_names = models.TextField(
        null=True, blank=True, default="", verbose_name=_("alternate names")
    )
    translations = models.JSONField(
        default=dict, blank=True, verbose_name=_("translations")
    )

    objects = BaseManager()

    class Meta:
        abstract = True
        ordering = ["name"]

    def natural_key(self):
        return (self.geoname_id,)

    def __str__(self):
        display_name = getattr(self, "display_name", None)
        if display_name:
            return display_name
        return self.name


class AbstractCountry(Base):
    """
    Base Country model.
    """

    code2 = models.CharField(
        max_length=2,
        null=True,
        blank=True,
        unique=True,
        verbose_name=_("ISO 3166-1 alpha-2"),
    )
    code3 = models.CharField(
        max_length=3,
        null=True,
        blank=True,
        unique=True,
        verbose_name=_("ISO 3166-1 alpha-3"),
    )
    continent = models.CharField(
        max_length=2,
        db_index=True,
        choices=CONTINENT_CHOICES,
        verbose_name=_("continent"),
    )
    tld = models.CharField(
        max_length=5, blank=True, db_index=True, verbose_name=_("top-level domain")
    )
    phone = models.CharField(
        max_length=20, null=True, blank=True, verbose_name=_("phone code")
    )

    class Meta(Base.Meta):
        verbose_name_plural = _("countries")
        abstract = True


class AbstractRegion(Base):
    """
    Base Region/State model.
    """

    display_name = models.CharField(max_length=200, verbose_name=_("display name"))
    geoname_code = models.CharField(
        max_length=50,
        null=True,
        blank=True,
        db_index=True,
        verbose_name=_("Geonames code"),
    )

    country = models.ForeignKey(
        CITIES_LIGHT_APP_NAME + ".Country",
        on_delete=models.CASCADE,
        verbose_name=_("country"),
    )

    class Meta(Base.Meta):
        unique_together = (("country", "name"), ("country", "slug"))
        verbose_name = _("region/state")
        verbose_name_plural = _("regions/states")
        abstract = True

    def get_display_name(self):
        return "%s, %s" % (self.name, self.country.name)


class AbstractSubRegion(Base):
    """
    Base SubRegion model.
    """

    display_name = models.CharField(max_length=200, verbose_name=_("display name"))
    geoname_code = models.CharField(
        max_length=50,
        null=True,
        blank=True,
        db_index=True,
        verbose_name=_("Geonames code"),
    )

    country = models.ForeignKey(
        CITIES_LIGHT_APP_NAME + ".Country",
        on_delete=models.CASCADE,
        verbose_name=_("country"),
    )
    region = models.ForeignKey(
        CITIES_LIGHT_APP_NAME + ".Region",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        verbose_name=_("region"),
    )

    class Meta(Base.Meta):
        verbose_name = _("SubRegion")
        verbose_name_plural = _("SubRegions")
        abstract = True

    def get_display_name(self):
        return "%s, %s" % (self.name, self.country.name)


class AbstractCity(Base):
    """
    Base City model.
    """

    display_name = models.CharField(max_length=200, verbose_name=_("display name"))

    search_names = ToSearchTextField(
        max_length=4000,
        db_index=INDEX_SEARCH_NAMES,
        blank=True,
        default="",
        verbose_name=_("search names"),
    )

    latitude = models.DecimalField(
        max_digits=8,
        decimal_places=5,
        null=True,
        blank=True,
        verbose_name=_("latitude"),
    )

    longitude = models.DecimalField(
        max_digits=8,
        decimal_places=5,
        null=True,
        blank=True,
        verbose_name=_("longitude"),
    )

    subregion = models.ForeignKey(
        CITIES_LIGHT_APP_NAME + ".SubRegion",
        blank=True,
        null=True,
        on_delete=models.CASCADE,
        verbose_name=_("subregion"),
    )
    region = models.ForeignKey(
        CITIES_LIGHT_APP_NAME + ".Region",
        blank=True,
        null=True,
        on_delete=models.CASCADE,
        verbose_name=_("region"),
    )
    country = models.ForeignKey(
        CITIES_LIGHT_APP_NAME + ".Country",
        on_delete=models.CASCADE,
        verbose_name=_("country"),
    )
    population = models.BigIntegerField(
        null=True, blank=True, db_index=True, verbose_name=_("population")
    )
    feature_code = models.CharField(
        max_length=10,
        null=True,
        blank=True,
        db_index=True,
        verbose_name=_("feature code"),
    )
    timezone = models.CharField(
        max_length=40,
        blank=True,
        null=True,
        db_index=True,
        validators=[timezone_validator],
        verbose_name=_("timezone"),
    )

    class Meta(Base.Meta):
        unique_together = (
            ("region", "subregion", "name"),
            ("region", "subregion", "slug"),
        )
        verbose_name_plural = _("cities")
        abstract = True

    def get_display_name(self):
        if self.region_id:
            return "%s, %s, %s" % (self.name, self.region.name, self.country.name)
        else:
            return "%s, %s" % (self.name, self.country.name)

    def get_timezone_info(self):
        """Return timezone info for self.timezone.

        If self.timezone has wrong value, it returns timezone info
        for value specified in settings.TIME_ZONE.
        """
        try:
            return pytz.timezone(self.timezone)
        except (pytz.UnknownTimeZoneError, AttributeError):
            return pytz.timezone(settings.TIME_ZONE)
