from django.urls.converters import StringConverter


class PackagesConverter(StringConverter):
    """JavaScriptCatalog packages converter."""

    # Same as SlugConverter, but with extra '+', that is used in JavaScriptCatalog as a sepearator in list of packages.
    regex = "[-a-zA-Z0-9_+]+"
