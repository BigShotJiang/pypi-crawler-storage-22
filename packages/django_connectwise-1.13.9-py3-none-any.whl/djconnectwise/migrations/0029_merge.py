# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('djconnectwise', '0028_remove_company_company_alias'),
        ('djconnectwise', '0028_merge'),
    ]

    operations = [
    ]
