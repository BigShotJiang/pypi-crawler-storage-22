# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('djconnectwise', '0051_merge'),
        ('djconnectwise', '0050_servicenote'),
    ]

    operations = [
    ]
