__title__ = "Django Content Studio"
__version__ = "1.0.0-beta.10"
__author__ = "Leon van der Grient"
__license__ = "MIT"

# Version synonym
VERSION = __version__
