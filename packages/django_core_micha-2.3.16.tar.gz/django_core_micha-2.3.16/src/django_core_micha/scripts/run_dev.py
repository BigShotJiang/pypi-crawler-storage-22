import argparse
import subprocess
import sys
import shutil
import os
import threading
from pathlib import Path

# Import existing scripts as modules
from django_core_micha.scripts import generate_env, sync_secrets

def run_command(command, cwd=None, ignore_errors=False, shell=False, capture_output=False):
    """Helper function to execute shell commands."""
    if not capture_output:
        print(f"[INFO] Running: {' '.join(command) if isinstance(command, list) else command}")
    
    try:
        is_windows = sys.platform == "win32"
        use_shell = shell or is_windows
        
        if capture_output:
            return subprocess.Popen(command, cwd=cwd, shell=use_shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        
        subprocess.run(command, check=True, cwd=cwd, shell=use_shell)
    except subprocess.CalledProcessError as e:
        if ignore_errors:
            print(f"[WARN] Command failed (ignored): {e}")
        else:
            print(f"[ERROR] Command failed: {e}")
            sys.exit(e.returncode)

def stream_docker_logs(compose_files_args):
    """
    Runs in a separate thread to stream docker logs while frontend is running.
    """
    print("[INFO] Starting Docker Log Stream...")
    # Nur Backend & Celery Logs (Java & Redis ausgeblendet für Ruhe)
    cmd = ["docker-compose"] + compose_files_args + ["logs", "-f", "--tail=10", "backend", "celery_worker"]
    
    try:
        subprocess.run(cmd, check=False, shell=(sys.platform == "win32"))
    except Exception as e:
        print(f"[WARN] Log stream interrupted: {e}")

def main():
    parser = argparse.ArgumentParser(description="Developer Runner for Docker setup")
    parser.add_argument("--local", action="store_true", help="Set environment to local")
    parser.add_argument("--edge", action="store_true", help="Set environment to edge")
    parser.add_argument("--all", action="store_true", help="Sync ALL secrets")
    
    parser.add_argument("--env", action="store_true", help="Force regenerate .env file")
    parser.add_argument("--vite", action="store_true", help="Use Hot-Reloading Mode (Vite on Host)")
    parser.add_argument("--docker", action="store_true", help="Use Classic Mode (Full Docker Build)")
    parser.add_argument("--refresh", action="store_true", help="Force refresh of Python dependencies")

    args = parser.parse_args()

    # --- KONFIGURATION (FIX) ---
    # Wir nutzen das aktuelle Arbeitsverzeichnis (wo du den Befehl ausführst),
    # nicht den Speicherort des Skripts.
    BASE_DIR = Path.cwd()
    frontend_dir = BASE_DIR / "frontend"
    
    env_mode = "edge" if args.edge else "local"
    MODE = "VITE" if args.vite else "CLASSIC"
    FORCE_ENV = args.env

    if args.refresh:
        print("[INFO] 🐢 Dependency Refresh ACTIVE: Downloading latest packages...")
        os.environ["UV_FLAGS"] = "--refresh"
    else:
        os.environ["UV_FLAGS"] = ""

    print(f"==================================================")
    print(f"🚀 RUN-DEV | Mode: {MODE} | Env-Regen: {FORCE_ENV}")
    print(f"==================================================")
    # DEBUG OUTPUT: Damit wir sehen, wo er sucht
    print(f"[DEBUG] Searching for frontend in: {frontend_dir}")

    # --- SCHRITT 1: ENV GENERATION ---
    if FORCE_ENV:
        if args.local or args.all:
            sys.argv = ["sync-secrets", "--target", "local"]
            sync_secrets.main()
        if args.all:
            sys.argv = ["sync-secrets", "--target", "github"]
            sync_secrets.main()

        print(f"[INFO] Generating .env for {env_mode}...")
        sys.argv = ["generate-env", "--env", env_mode]
        generate_env.main()

        frontend_env_path = frontend_dir / ".env"
        if frontend_dir.exists():
            shutil.copy(".env", frontend_env_path)
    else:
        print("[INFO] Skipping .env generation (use --env to force)")


    # --- SCHRITT 2: DOCKER FILES ---
    compose_files_args = ["-f", "docker-compose.yml"]
    if args.edge:
        if Path("docker-compose.edge.yml").exists():
            compose_files_args.extend(["-f", "docker-compose.edge.yml"])
    elif MODE == "VITE":
        if Path("docker-compose.local.yml").exists():
            compose_files_args.extend(["-f", "docker-compose.local.yml"])
        else:
            print("[ERROR] --vite requires docker-compose.local.yml!")
            sys.exit(1)
    elif MODE == "CLASSIC":
        # New default: prefer local compose even in CLASSIC mode.
        # This keeps local mount protections (templates/static) consistent.
        if Path("docker-compose.local.yml").exists():
            compose_files_args.extend(["-f", "docker-compose.local.yml"])
        elif Path("docker-compose.override.yml").exists():
            print("[WARN] docker-compose.local.yml not found, falling back to docker-compose.override.yml")
            compose_files_args.extend(["-f", "docker-compose.override.yml"])

    print(f"[INFO] Compose files: {' '.join(compose_files_args)}")

    # --- SCHRITT 3: CLEANUP ---
    print("[INFO] Stopping containers...")
    run_command(["docker", "rm", "-f", "traefik"], ignore_errors=True)
    subprocess.run(["docker-compose"] + compose_files_args + ["rm", "-s", "-f", "-v", "backend", "celery_worker"], 
                   stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL, shell=(sys.platform=="win32"))


    # --- SCHRITT 4: START ---
    
    if MODE == "CLASSIC":
        print("[INFO] Starting Classic Docker Build...")
        run_command(["docker-compose"] + compose_files_args + ["build"])
        
        print("[INFO] Starting Containers (Detached)...")
        # 1. Alles im Hintergrund starten (damit Java uns nicht vollquatscht)
        run_command(["docker-compose"] + compose_files_args + ["up", "-d", "--remove-orphans"])
        
        print("[INFO] Streaming logs for backend & celery_worker (Ctrl+C to stop)...")
        try:
            # 2. Nur RELEVANTE Logs anzeigen (Main Thread blockiert hier)
            # Das ist der gleiche Filter wie im Vite-Modus
            cmd = ["docker-compose"] + compose_files_args + ["logs", "-f", "backend", "celery_worker"]
            subprocess.run(cmd, check=True, shell=(sys.platform=="win32"))
        except KeyboardInterrupt:
            print("\n[INFO] Stopping containers...")
            # 3. Aufräumen: Wenn du CTRL+C drückst, stoppen wir alles (wie beim normalen 'up')
            run_command(["docker-compose"] + compose_files_args + ["stop"])
            
    elif MODE == "VITE":
        # 1. Backend starten
        print("[INFO] Starting Backend Containers...")
        run_command(["docker-compose"] + compose_files_args + ["up", "-d", "--build", "--remove-orphans"])
        
        # 2. Frontend
        if frontend_dir.exists():
            print("\n[INFO] Starting Vite...")
            
            log_thread = threading.Thread(target=stream_docker_logs, args=(compose_files_args,), daemon=True)
            log_thread.start()

            try:
                # Node Modules Check
                node_modules = frontend_dir / "node_modules"
                if not node_modules.exists():
                     print("[INFO] node_modules not found. Running pnpm install...")
                     subprocess.run("pnpm install", cwd=str(frontend_dir), shell=True, check=True)
                
                # Vite Start
                print(f"[INFO] Executing 'pnpm dev' in {frontend_dir}...")
                subprocess.run("pnpm dev", cwd=str(frontend_dir), shell=True, check=True)
                
            except KeyboardInterrupt:
                print("\n[INFO] Stopping...")
            except subprocess.CalledProcessError as e:
                print(f"[ERROR] Frontend process failed: {e}")
        else:
             print(f"[WARN] No frontend directory found at {frontend_dir}!")
             run_command(["docker-compose"] + compose_files_args + ["logs", "-f", "backend", "celery_worker"])

if __name__ == "__main__":
    main()
