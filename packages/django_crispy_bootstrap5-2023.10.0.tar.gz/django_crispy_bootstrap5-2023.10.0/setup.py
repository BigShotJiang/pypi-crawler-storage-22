
import sys
from setuptools import setup

setup(
    name="django-crispy-bootstrap5",
    version="2023.10.0", 
    description="",
    author="",
    author_email="",
    url="",
)
