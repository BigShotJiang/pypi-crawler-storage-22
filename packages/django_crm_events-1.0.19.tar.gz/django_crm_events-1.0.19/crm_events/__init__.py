"""
Event-driven CRM integration for Shopify apps.

Dispatches shop lifecycle events to all configured CRM services.
Each service failure is isolated — one failing service won't affect the others.

Usage:
    from crm_events import on_install, on_login, on_billing_plan_change, on_uninstall, register_usage

    on_install(shop_data)
    on_login(shop_data, user_data)
    on_billing_plan_change(shop_data, monthly_price)
    on_uninstall(shop_data, users_data)
    register_usage(shop_data, is_using_service)
"""

import logging
import warnings
from time import sleep


from .crms.clickup import Clickup
from .crms.klaviyo import Klaviyo
from .crms.pipedrive import PipeDrive
from .crms.hubfy import Hubfy

logger = logging.getLogger(__name__)

services = [PipeDrive, Clickup, Klaviyo, Hubfy]


def get_available_services():
    """Return instances of services that have their required Django settings configured."""
    return [service for service in services if service().is_available()]


def _handle_service_error(service, action):
    """Log the exception with full traceback and emit a RuntimeWarning as fallback."""
    msg = f"{action} failed for {service.__name__}"
    logger.exception(msg)
    warnings.warn(msg, RuntimeWarning, stacklevel=3)


def on_install(shop_data):
    """Notify all available CRM services that a shop has installed the app.

    Args:
        shop_data: Dict with keys: name, domain, email, phone, country.
    """
    for service in get_available_services():
        try:
            service().on_install(shop_data)
        except Exception:
            _handle_service_error(service, "on_install")


def on_login(shop_data, user_data, sleep_time=5):
    """Notify all available CRM services that a user has logged in.

    Args:
        shop_data: Dict with keys: name, domain, email, phone, country.
        user_data: Dict with keys: first_name, last_name, email, phone.
        sleep_time: Seconds to wait before dispatching (default: 5).
    """
    sleep(sleep_time)
    for service in get_available_services():
        try:
            service().on_login(shop_data, user_data)
        except Exception:
            _handle_service_error(service, "on_login")


def on_billing_plan_change(shop_data, monthly_price):
    """Notify all available CRM services that a shop's billing plan has changed.

    Args:
        shop_data: Dict with keys: name, domain, email, phone, country.
        monthly_price: The new monthly price. Use 0 to indicate a cancelled plan.
    """
    for service in get_available_services():
        try:
            service().on_billing_plan_change(shop_data, monthly_price)
        except Exception:
            _handle_service_error(service, "on_billing_plan_change")


def on_uninstall(shop_data, users_data):
    """Notify all available CRM services that a shop has uninstalled the app.

    Args:
        shop_data: Dict with keys: name, domain, email, phone, country.
        users_data: List of user dicts, each with keys: first_name, last_name, email, phone.
    """
    for service in get_available_services():
        try:
            service().on_uninstall(shop_data, users_data)
        except Exception:
            _handle_service_error(service, "on_uninstall")


def register_usage(shop_data, is_using_service):
    """Notify all available CRM services about app usage status for a shop.

    Args:
        shop_data: Dict with keys: name, domain, email, phone, country.
        is_using_service: Boolean indicating whether the shop is actively using the app.
    """
    for service in get_available_services():
        try:
            service().register_usage(shop_data, is_using_service)
        except Exception:
            _handle_service_error(service, "register_usage")
