import logging
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class BaseService(ABC):
    def on_install(self, shop):
        logger.debug("%s on_install not implemented", self.__class__.__name__)

    def on_login(self, shop, user):
        logger.debug("%s on_login not implemented", self.__class__.__name__)

    def on_billing_plan_change(self, shop, monthly_price):
        logger.debug("%s on_billing_plan_change not implemented", self.__class__.__name__)

    def on_uninstall(self, shop, users):
        logger.debug("%s on_uninstall not implemented", self.__class__.__name__)

    @abstractmethod
    def is_available(self):
        return False
