# django-dbreqresp

Django DbReqRes stores data about http requests and responses for a given url path or a given view
