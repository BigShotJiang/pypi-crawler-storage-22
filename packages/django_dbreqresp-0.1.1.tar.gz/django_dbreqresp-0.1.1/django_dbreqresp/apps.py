from django.apps import AppConfig


class ApilogConfig(AppConfig):
    name = "django_dbreqresp"
