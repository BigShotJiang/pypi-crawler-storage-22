import{d as s,j as o}from"./render-DxKzmxsB.js";const h=s(o.jsx("path",{d:"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"}));export{h as P};
//# sourceMappingURL=Add-cRNxFEdd.js.map
