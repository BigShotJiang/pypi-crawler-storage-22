import{d as t,j as s}from"./render-DxKzmxsB.js";const r=t(s.jsx("path",{d:"M10 18h4v-2h-4zM3 6v2h18V6zm3 7h12v-2H6z"}));export{r as F};
//# sourceMappingURL=FilterList-B877vPDP.js.map
