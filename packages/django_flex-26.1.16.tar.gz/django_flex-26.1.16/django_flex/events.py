"""
Django Flex Event Tracking

Automatic event logging for all mutations (add, edit, delete).
Configure via DJANGO_FLEX settings to enable audit trails.

Example settings:
    DJANGO_FLEX = {
        'EVENT_TRACKING': {
            'MODEL': 'myapp.models.AuditLog',
            'FIELDS_MAPPING': {
                # internal_key: model_column_name
                'domain': 'module',      # model name -> 'module' column
                'action': 'action',      # action type -> 'action' column
                'user': 'actor',         # user FK -> 'actor_id' column
                'target_type': 'content_type',  # GenericFK type
                'target_id': 'object_id',       # GenericFK id
                'request': 'request_data',      # request JSON
                'response': 'response_data',    # response JSON
                'note': 'note',                 # optional note text
                'screen': 'screen',             # UI origin
                'company': 'company',           # custom field (e.g., multi-tenant)
            },
            'SCRUB_FIELDS': ['password', 'new_password', 'auth_token'],  # scrubbed from request
        },
    }
"""

import logging

from django_flex.conf import flex_settings

logger = logging.getLogger("django_flex.events")

_event_model_cache = None


def get_event_model():
    """
    Resolve the configured Event model class.

    Returns:
        Model class or None if event tracking is disabled.
    """
    global _event_model_cache

    event_tracking = flex_settings.EVENT_TRACKING
    event_model_path = event_tracking.get("MODEL") if event_tracking else None
    if not event_model_path:
        return None

    # Return cached model if available
    if _event_model_cache is not None:
        return _event_model_cache

    try:
        from django.apps import apps

        # Parse 'app.models.Event' -> app_label='app', model_name='Event'
        parts = event_model_path.rsplit(".", 1)
        if len(parts) != 2:
            logger.error(f"Invalid EVENT_MODEL format: {event_model_path}")
            return None

        module_path, model_name = parts
        # Handle 'app.models.Event' format
        if ".models." in module_path or module_path.endswith(".models"):
            app_label = module_path.split(".")[0]
        else:
            app_label = module_path

        _event_model_cache = apps.get_model(app_label, model_name)
        return _event_model_cache

    except LookupError as e:
        logger.error(f"EVENT_MODEL not found: {e}")
        return None
    except Exception as e:
        logger.warning(f"Error loading EVENT_MODEL: {type(e).__name__}: {e}")
        return None


# Default field keys that define the standard event structure
STANDARD_KEYS = {"domain", "action", "user", "target_type", "target_id", "request", "response"}

# Known FK fields - values for these are stored with _id suffix
FK_FIELD_HINTS = {"company", "tenant", "organization", "team", "workspace", "project"}


def create_event(user, model_name, action, target_obj=None, request_data=None, response_data=None, extra_fields=None):
    """
    Create an event record for a mutation.

    Uses FIELDS_MAPPING dict to map internal keys to model column names:
        - domain: the model name being mutated
        - action: the action type ('create', 'update', 'delete')
        - user: the user who performed the action (FK)
        - target_type: GenericFK content type (optional)
        - target_id: GenericFK object id (optional)
        - request: the request payload (JSON)
        - response: the response payload (JSON)

    Any additional keys in FIELDS_MAPPING can be passed via extra_fields dict,
    or are auto-populated from target_obj if present. This allows adding new
    event fields (like 'screen', 'note', 'company') without modifying this code.

    Args:
        user: The user who performed the action (or None)
        model_name: The model/module being mutated (domain)
        action: The action performed ('create', 'update', 'delete', or RPC action)
        target_obj: The object that was mutated (optional, for GenericFK)
        request_data: The original request payload (dict)
        response_data: The response payload (dict)
        extra_fields: Dict of additional fields to populate (e.g., screen, note, company)
                      Keys should match FIELDS_MAPPING keys.

    Returns:
        Event instance or None if tracking disabled or failed
    """
    EventModel = get_event_model()
    if EventModel is None:
        return None

    # Get user's EVENT_TRACKING config
    from django_flex.conf import DEFAULTS

    user_event_tracking = flex_settings.user_settings.get("EVENT_TRACKING", {})

    # Merge with defaults for FIELDS_MAPPING
    default_mapping = DEFAULTS["EVENT_TRACKING"]["FIELDS_MAPPING"]
    user_mapping = user_event_tracking.get("FIELDS_MAPPING", {})
    event_fields = {**default_mapping, **user_mapping}

    try:
        event_data = {}

        # Domain (model/module name)
        if "domain" in event_fields:
            event_data[event_fields["domain"]] = model_name

        # Action
        if "action" in event_fields:
            event_data[event_fields["action"]] = action

        # User (FK)
        if "user" in event_fields and user:
            event_data[f"{event_fields['user']}_id"] = user.pk if hasattr(user, "pk") else user

        # Target object (GenericFK)
        if target_obj and "target_type" in event_fields and "target_id" in event_fields:
            if hasattr(target_obj, "_meta") and hasattr(target_obj, "pk"):
                from django.contrib.contenttypes.models import ContentType

                content_type = ContentType.objects.get_for_model(target_obj)
                event_data[f"{event_fields['target_type']}_id"] = content_type.pk
                event_data[event_fields["target_id"]] = target_obj.pk

        # Request data (JSON) - scrub sensitive fields first
        if "request" in event_fields and request_data:
            # Scrub sensitive fields
            scrub_fields = user_event_tracking.get("SCRUB_FIELDS", []) or DEFAULTS["EVENT_TRACKING"].get("SCRUB_FIELDS", [])
            scrubbed_request = dict(request_data)
            for field in scrub_fields:
                if field in scrubbed_request:
                    scrubbed_request[field] = "***"
            event_data[event_fields["request"]] = scrubbed_request

        # Response data (JSON)
        if "response" in event_fields and response_data:
            event_data[event_fields["response"]] = response_data

        # Process extra_fields from request (screen, note, company, etc.)
        # These are passed explicitly from query.py or index.py
        if extra_fields:
            for field_key, value in extra_fields.items():
                if field_key in event_fields and value is not None and field_key not in STANDARD_KEYS:
                    column_name = event_fields[field_key]
                    # Skip if already set
                    if column_name in event_data or f"{column_name}_id" in event_data:
                        continue
                    # FK fields need _id suffix
                    if hasattr(value, "pk"):
                        event_data[f"{column_name}_id"] = value.pk
                    elif isinstance(value, int) and field_key in FK_FIELD_HINTS:
                        # Assume integer values for known FK fields
                        event_data[f"{column_name}_id"] = value
                    else:
                        event_data[column_name] = value

        # Auto-populate remaining fields from target_obj if not already set
        for internal_key, column_name in event_fields.items():
            if internal_key not in STANDARD_KEYS:
                # Skip if already set via extra_fields
                if column_name in event_data or f"{column_name}_id" in event_data:
                    continue
                # Try to get from target_obj
                if target_obj:
                    # Try FK field first (field_id)
                    fk_attr = f"{internal_key}_id"
                    if hasattr(target_obj, fk_attr):
                        value = getattr(target_obj, fk_attr, None)
                        if value is not None:
                            event_data[f"{column_name}_id"] = value
                    elif hasattr(target_obj, internal_key):
                        value = getattr(target_obj, internal_key, None)
                        if value is not None:
                            event_data[column_name] = value

        return EventModel.objects.create(**event_data)

    except Exception as e:
        logger.warning(f"Failed to create event: {type(e).__name__}: {e}")
        return None


def clear_event_model_cache():
    """Clear the cached event model (useful for testing)."""
    global _event_model_cache
    _event_model_cache = None
