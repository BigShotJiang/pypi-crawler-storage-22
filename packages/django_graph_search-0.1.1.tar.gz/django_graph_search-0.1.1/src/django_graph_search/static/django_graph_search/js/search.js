// Reserved for future enhancements (autocomplete, async search).

