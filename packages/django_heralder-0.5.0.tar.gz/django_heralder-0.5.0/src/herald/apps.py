"""
Django app config for herald. Using this to call autodiscover
"""

from django.apps import AppConfig
from django.db.utils import OperationalError, ProgrammingError


class HeraldConfig(AppConfig):
    """
    Django app config for herald. Using this to call autodiscover
    """

    default_auto_field = "django.db.models.AutoField"
    name = "herald"

    def ready(self):
        from herald import registry

        self.module.autodiscover()

        self.register_admins()

        Notification = self.get_model("Notification")

        try:
            # add any new notifications to database.
            for index, klass in enumerate(registry._registry):
                notification, created = Notification.objects.get_or_create(
                    notification_class=klass.get_class_path(),
                    defaults={
                        "verbose_name": klass.get_verbose_name(),
                        "can_disable": klass.can_disable,
                    },
                )

                if not created:
                    notification.verbose_name = klass.get_verbose_name()
                    notification.can_disable = klass.can_disable
                    notification.save()

        except OperationalError:
            # if the table is not created yet, just keep going.
            pass
        except ProgrammingError:
            # if the database is not created yet, keep going (ie: during testing)
            pass

    def register_admins(self):
        """
        Register admin classes if they are not already registered.
        This is the correct way to handle admin registration for swappable models.
        """
        from django.contrib import admin

        from herald.admin import NotificationAdmin, SentNotificationAdmin
        from herald.models import Notification
        from herald.utils import get_sent_notification_model

        SentNotification = get_sent_notification_model()

        admin.site.register(Notification, NotificationAdmin)

        if not admin.site.is_registered(SentNotification):
            admin.site.register(SentNotification, SentNotificationAdmin)
