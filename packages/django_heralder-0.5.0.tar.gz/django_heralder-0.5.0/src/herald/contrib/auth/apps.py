from django.apps import AppConfig


class HeraldAuthConfig(AppConfig):
    name = "herald.contrib.auth"
    label = "herald_contrib_auth"
