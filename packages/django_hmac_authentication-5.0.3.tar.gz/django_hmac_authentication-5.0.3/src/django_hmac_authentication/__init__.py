name = 'django_hmac_authentication'
version = '5.0.3'
default_app_config = 'django_hmac_authentication.apps.DjangoHMACAuthenticationConfig'
