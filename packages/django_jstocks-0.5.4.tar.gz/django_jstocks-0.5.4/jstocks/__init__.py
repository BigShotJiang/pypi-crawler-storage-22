default_app_config = "jstocks.apps.JStocksConfig"
