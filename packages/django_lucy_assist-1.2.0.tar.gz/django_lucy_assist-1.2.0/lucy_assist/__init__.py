"""
Lucy Assist - Assistant IA intelligent pour applications Django.

Un chatbot IA base sur Mistral AI, integrable dans n'importe quelle
application Django pour fournir une assistance contextuelle aux utilisateurs.
"""

__version__ = '1.2.0'
__author__ = 'Revolucy'

default_app_config = 'lucy_assist.apps.LucyAssistConfig'
