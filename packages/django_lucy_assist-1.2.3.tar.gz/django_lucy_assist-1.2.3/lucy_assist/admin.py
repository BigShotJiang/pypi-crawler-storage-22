from django.contrib import admin

from lucy_assist.models import Conversation, Message, ConfigurationLucyAssist


class BlockMessage(admin.StackedInline):
    model = Message
    extra = 1


@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ('id', 'utilisateur', 'titre', 'created_date', 'is_active')
    list_filter = ('is_active', 'created_date')
    search_fields = ('utilisateur__email', 'titre')
    ordering = ('-created_date',)
    inlines = [BlockMessage]


@admin.register(ConfigurationLucyAssist)
class ConfigurationLucyAssistAdmin(admin.ModelAdmin):
    list_display = ('id', 'tokens_disponibles', 'prix_par_million_tokens', 'nb_vues_crud', 'has_project_context', 'updated_date')
    readonly_fields = ('crud_views_mapping_display', 'model_app_mapping_display', 'project_context_display')
    fieldsets = (
        ('Configuration Tokens', {
            'fields': ('tokens_disponibles', 'prix_par_million_tokens', 'actif')
        }),
        ('Personnalisation', {
            'fields': ('avatar', 'questions_frequentes')
        }),
        ('Prompt Systeme', {
            'fields': ('system_prompt',),
            'classes': ('collapse',),
            'description': 'Le prompt systeme est initialise automatiquement si vide.'
        }),
        ('Contexte Projet GitLab', {
            'fields': ('project_context_display',),
            'classes': ('collapse',),
            'description': 'Analyse du projet depuis GitLab. Utilisez l\'action "Rafraichir le contexte projet" pour mettre a jour.'
        }),
        ('Mapping Automatique (lecture seule)', {
            'fields': ('crud_views_mapping_display', 'model_app_mapping_display'),
            'classes': ('collapse',)
        }),
    )
    actions = ['refresh_crud_views', 'refresh_project_context']

    def nb_vues_crud(self, obj):
        """Affiche le nombre de modeles avec des vues CRUD decouvertes."""
        if obj.crud_views_mapping:
            return len(obj.crud_views_mapping)
        return 0
    nb_vues_crud.short_description = "Modeles CRUD"

    def has_project_context(self, obj):
        """Indique si le contexte projet est configure."""
        return bool(obj.project_context)
    has_project_context.short_description = "Contexte GitLab"
    has_project_context.boolean = True

    def crud_views_mapping_display(self, obj):
        """Affiche le mapping des vues CRUD de manière lisible."""
        import json
        if obj.crud_views_mapping:
            return json.dumps(obj.crud_views_mapping, indent=2, ensure_ascii=False)
        return "Aucune vue découverte. Utilisez l'action 'Rafraîchir les vues CRUD'."
    crud_views_mapping_display.short_description = "Vues CRUD découvertes"

    def model_app_mapping_display(self, obj):
        """Affiche le mapping modele -> app de maniere lisible."""
        import json
        if obj.model_app_mapping:
            return json.dumps(obj.model_app_mapping, indent=2, ensure_ascii=False)
        return "Aucun mapping. Sera construit automatiquement."
    model_app_mapping_display.short_description = "Mapping Modele -> App"

    def project_context_display(self, obj):
        """Affiche le contexte projet analyse depuis GitLab."""
        if obj.project_context:
            return obj.project_context
        return "Aucun contexte. Utilisez l'action 'Rafraichir le contexte projet' ou configurez GitLab."
    project_context_display.short_description = "Contexte Projet"

    @admin.action(description="Rafraichir les vues CRUD decouvertes")
    def refresh_crud_views(self, request, queryset):
        """Action admin pour rafraichir le mapping des vues CRUD."""
        for config in queryset:
            mapping = config.refresh_crud_views_mapping()
            nb_models = len(mapping)
            nb_views = sum(len(actions) for actions in mapping.values())
            self.message_user(
                request,
                f"Mapping rafraichi: {nb_models} modeles, {nb_views} vues decouvertes."
            )

    @admin.action(description="Rafraichir le contexte projet (GitLab)")
    def refresh_project_context(self, request, queryset):
        """Action admin pour analyser le projet depuis GitLab."""
        for config in queryset:
            result = config.refresh_project_context()
            if "non configure" in result.lower():
                self.message_user(request, result, level='warning')
            else:
                # Compter les lignes pour donner une idee de la taille
                nb_lines = len(result.split('\n'))
                self.message_user(
                    request,
                    f"Contexte projet rafraichi: {nb_lines} lignes d'analyse."
                )
