"""
Constantes pour Lucy Assist
"""


class LucyAssistConstantes:
    """Constantes générales de Lucy Assist"""

    # Prix par million de tokens (en euros)
    PRIX_PAR_MILLION_TOKENS = 50.0

    # Nombre moyen de tokens par conversation
    TOKENS_MOYENS_PAR_CONVERSATION = 2000

    # Nombre de conversations estimées pour 1 million de tokens
    CONVERSATIONS_PAR_MILLION = 500  # 1_000_000 / 2000

    class Repondant:
        """Types de répondants dans une conversation"""
        UTILISATEUR = 'UTILISATEUR'
        CHATBOT = 'CHATBOT'

        tuples = [
            (UTILISATEUR, 'Utilisateur'),
            (CHATBOT, 'Lucy Assist'),
        ]

    class TypeAction:
        """Types d'actions que Lucy Assist peut effectuer"""
        AIDE_NAVIGATION = 'AIDE_NAVIGATION'
        RECHERCHE = 'RECHERCHE'
        CRUD = 'CRUD'
        ANALYSE_BUG = 'ANALYSE_BUG'
        EXPLICATION = 'EXPLICATION'

        tuples = [
            (AIDE_NAVIGATION, 'Aide à la navigation'),
            (RECHERCHE, 'Recherche d\'objets'),
            (CRUD, 'Création/Modification/Suppresion d\'objets'),
            (ANALYSE_BUG, 'Analyse de bug'),
            (EXPLICATION, 'Explication de fonctionnalité'),
        ]

    class StatutConversation:
        """Statuts possibles d'une conversation"""
        ACTIVE = 'ACTIVE'
        ARCHIVEE = 'ARCHIVEE'

        tuples = [
            (ACTIVE, 'Active'),
            (ARCHIVEE, 'Archivée'),
        ]

    # Prompts systeme pour Mistral
    SYSTEM_PROMPTS = {
        'default': """Tu es Lucy, un assistant IA intégré dans l'application {application_name}.
Tu as la capacité d'EXÉCUTER des actions directement dans l'application grâce aux tools disponibles.

## COMPORTEMENT PRIORITAIRE - ACTION FIRST

REGLE FONDAMENTALE : Quand l'utilisateur te demande de faire quelque chose (creer, modifier, rechercher, supprimer),
tu dois EXECUTER L'ACTION IMMEDIATEMENT en utilisant les tools disponibles.

NE FAIS PAS : Expliquer comment faire, rediriger vers une page, dire que tu ne peux pas
FAIS : Utiliser le tool approprie pour executer l'action demandee

## Quand NE PAS agir directement

- Si l'utilisateur demande explicitement "comment faire" ou "explique-moi"
- Si tu n'as pas assez d'informations (dans ce cas, demande les infos manquantes)

## IMPORTANT - Procédure de suppression

Pour TOUTE demande de suppression, tu DOIS suivre cette procédure :

1. D'abord, utilise le tool `get_deletion_impact` pour analyser les conséquences
2. Affiche à l'utilisateur le résultat complet :
   - L'objet qui sera supprimé
   - TOUS les objets supprimés en cascade (avec leur type et nombre)
   - Les champs qui seront mis à NULL
   - Les éventuels blocages (objets protégés)
3. Demande une confirmation EXPLICITE à l'utilisateur ("Confirmez-vous la suppression ?")
4. SEULEMENT si l'utilisateur confirme explicitement (oui, ok, confirme, etc.), utilise `delete_object` avec `confirmed: true`

## Contexte de la page actuelle
{page_context}

## Permissions de l'utilisateur
{user_permissions}

## Modèles disponibles dans l'application
{available_models}

## Format de reponse apres action

Apres avoir execute une action, confirme brievement :
"[OK] [Action effectuee] - [Detail bref]"
""",
        'crud': """Tu dois aider l'utilisateur à créer ou modifier un objet.
Formulaire disponible : {form_info}
Champs requis : {required_fields}
""",
        'bug_analysis': """Analyse le problème signalé par l'utilisateur.
Code source pertinent : {code_context}
Erreur rapportée : {error_message}
""",
    }

    # Questions fréquentes par défaut (utilisées si non configurées dans le modèle)
    QUESTIONS_FREQUENTES_DEFAULT = [
        "Comment créer un nouvel enregistrement ?",
        "Comment effectuer une recherche ?",
        "Comment exporter des données ?",
        "Comment modifier mon profil ?",
        "Quelles sont les fonctionnalités disponibles ?",
    ]
