"""
Service d'integration avec Mistral AI API.

Optimisations tokens:
- Cache du contexte projet via ProjectContextService
- Resume des conversations longues
- Compression intelligente du contexte

Tools CRUD:
- Mistral peut executer des actions CRUD via les tools
- Les tools sont executes cote serveur avec les permissions de l'utilisateur
"""
import json
from typing import Generator, List, Dict, Any

from mistralai import Mistral

from lucy_assist.utils.log_utils import LogUtils
from lucy_assist.constantes import LucyAssistConstantes
from lucy_assist.services.tools_definition import LUCY_ASSIST_TOOLS
from lucy_assist.conf import lucy_assist_settings


class MistralService:
    """Service pour interagir avec l'API Mistral AI."""

    MAX_TOKENS = 4096

    # Seuils pour l'optimisation
    MAX_MESSAGES_BEFORE_SUMMARY = 10  # Resumer apres 10 messages
    MAX_CONTEXT_TOKENS = 2000  # Limiter le contexte a 2000 tokens estimes

    def __init__(self):
        self.api_key = lucy_assist_settings.MISTRAL_LUCY_API_KEY
        if not self.api_key:
            raise ValueError("MISTRAL_LUCY_API_KEY non configuree dans les settings")

        self.client = Mistral(api_key=self.api_key)
        self._project_context_service = None
        self._tools = LUCY_ASSIST_TOOLS
        self._model = lucy_assist_settings.MISTRAL_MODEL

    @property
    def project_context_service(self):
        """Lazy loading du service de contexte projet."""
        if self._project_context_service is None:
            from lucy_assist.services.project_context_service import ProjectContextService
            self._project_context_service = ProjectContextService()
        return self._project_context_service

    def _build_system_prompt(
        self,
        page_context: Dict,
        user,
        user_question: str = ""
    ) -> str:
        """
        Construit le prompt systeme avec le contexte optimise.

        Utilise le prompt stocke en base de donnees et le cache
        pour reduire la redondance des informations sur le projet.
        """
        # Recuperer les permissions utilisateur (compressees)
        user_permissions = []
        if hasattr(user, 'get_all_permissions'):
            # Ne garder que les permissions pertinentes (sans prefixe d'app commun)
            all_perms = list(user.get_all_permissions())
            user_permissions = [p.split('.')[-1] for p in all_perms[:15]]

        # Recuperer le contexte projet optimise depuis le cache
        page_url = page_context.get('page_url', page_context.get('url', ''))
        optimized_context = self.project_context_service.get_optimized_context(
            page_url=page_url,
            user_question=user_question
        )

        # Fusionner le contexte de page avec le contexte projet cache
        enriched_context = {
            'page': page_context,
            'projet': optimized_context.get('relevant_info', {}),
            'cache_stats': optimized_context.get('stats', {})
        }

        # Recuperer la configuration avec le prompt systeme
        from lucy_assist.models import ConfigurationLucyAssist
        config = ConfigurationLucyAssist.get_config()

        # Generer la description des modeles disponibles
        available_models = config.get_available_models_description()

        # Construire le prompt depuis la configuration
        prompt = config.get_system_prompt(
            page_context=json.dumps(enriched_context, ensure_ascii=False, indent=2),
            user_permissions=', '.join(user_permissions),
            available_models=available_models
        )

        return prompt

    def _optimize_messages(self, messages: List) -> List[Dict]:
        """
        Optimise l'historique des messages pour reduire les tokens.

        Pour les conversations longues, resume les anciens messages
        au lieu de les envoyer en entier.
        """
        formatted = self._format_messages(messages)

        if len(formatted) <= self.MAX_MESSAGES_BEFORE_SUMMARY:
            return formatted

        # Resumer la conversation
        summary_data = self.project_context_service.summarize_conversation(
            formatted,
            max_tokens=500
        )

        if not summary_data:
            return formatted

        # Reconstruire les messages avec le resume
        optimized = []

        # Ajouter les premiers messages
        optimized.extend(summary_data['first_messages'])

        # Ajouter le resume comme message systeme
        optimized.append({
            'role': 'user',
            'content': f"[Note: {summary_data['original_count'] - 4} messages resumes]\n{summary_data['summary']}"
        })

        # Ajouter les derniers messages
        optimized.extend(summary_data['last_messages'])

        LogUtils.info(
            f"Conversation optimisee: {len(formatted)} -> {len(optimized)} messages, "
            f"~{summary_data.get('tokens_saved_estimate', 0)} tokens economises"
        )

        return optimized

    def _format_messages(self, messages: List) -> List[Dict]:
        """Formate les messages pour l'API Mistral."""
        formatted = []

        for msg in messages:
            role = "user" if msg.repondant == LucyAssistConstantes.Repondant.UTILISATEUR else "assistant"
            formatted.append({
                "role": role,
                "content": msg.contenu
            })

        return formatted

    def _convert_tool_results_for_mistral(self, tool_results: List[Dict]) -> List[Dict]:
        """Convertit les resultats de tools au format Mistral."""
        mistral_results = []
        for result in tool_results:
            mistral_results.append({
                "role": "tool",
                "tool_call_id": result.get('tool_use_id', result.get('tool_call_id')),
                "content": result.get('content', '{}')
            })
        return mistral_results

    def chat_completion_stream(
        self,
        messages: List,
        page_context: Dict,
        user,
        tool_executor=None
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Genere une reponse en streaming avec support des tools.

        Args:
            messages: Liste des messages de la conversation
            page_context: Contexte de la page courante
            user: Utilisateur Django
            tool_executor: Callable pour executer les tools (optionnel)

        Yields:
            Dict avec 'type' (content/tool_use/tool_result/usage/error) et les donnees associees
        """
        try:
            # Extraire la question utilisateur du dernier message
            user_question = ""
            if messages:
                last_msg = messages[-1] if hasattr(messages[-1], 'contenu') else messages[-1]
                user_question = getattr(last_msg, 'contenu', '') if hasattr(last_msg, 'contenu') else str(last_msg)

            system_prompt = self._build_system_prompt(page_context, user, user_question)

            # Utiliser l'optimisation des messages pour les longues conversations
            formatted_messages = self._optimize_messages(messages)

            if not formatted_messages:
                yield {'type': 'error', 'error': 'Aucun message a traiter'}
                return

            # Ajouter le system prompt comme premier message
            messages_with_system = [
                {"role": "system", "content": system_prompt}
            ] + formatted_messages

            # Boucle pour gerer les appels de tools
            current_messages = messages_with_system.copy()
            max_tool_iterations = 5  # Limite de securite

            for iteration in range(max_tool_iterations):
                response_text = ""
                tool_calls = []
                total_input_tokens = 0
                total_output_tokens = 0

                # Streaming avec Mistral
                stream_response = self.client.chat.stream(
                    model=self._model,
                    max_tokens=self.MAX_TOKENS,
                    messages=current_messages,
                    tools=self._tools,
                    tool_choice="auto"
                )

                # Collecter le contenu et les tool calls
                for chunk in stream_response:
                    if chunk.data.choices:
                        choice = chunk.data.choices[0]
                        delta = choice.delta

                        # Contenu textuel
                        if delta.content:
                            response_text += delta.content
                            yield {'type': 'content', 'content': delta.content}

                        # Tool calls
                        if delta.tool_calls:
                            for tc in delta.tool_calls:
                                # Accumuler les tool calls
                                if tc.id:
                                    tool_calls.append({
                                        'id': tc.id,
                                        'name': tc.function.name if tc.function else '',
                                        'arguments': tc.function.arguments if tc.function else ''
                                    })
                                elif tool_calls and tc.function:
                                    # Continuation du dernier tool call
                                    tool_calls[-1]['arguments'] += tc.function.arguments or ''

                    # Usage tokens
                    if chunk.data.usage:
                        total_input_tokens = chunk.data.usage.prompt_tokens
                        total_output_tokens = chunk.data.usage.completion_tokens

                # Verifier le stop reason
                finish_reason = None
                if stream_response:
                    # Le dernier chunk contient le finish_reason
                    pass  # finish_reason est dans le dernier choice

                # Si pas de tool calls, on a fini
                if not tool_calls:
                    if total_input_tokens or total_output_tokens:
                        yield {
                            'type': 'usage',
                            'input_tokens': total_input_tokens,
                            'output_tokens': total_output_tokens,
                            'total_tokens': total_input_tokens + total_output_tokens
                        }
                    return

                # Executer les tools
                tool_results = []
                assistant_tool_calls = []

                for tool_call in tool_calls:
                    tool_name = tool_call['name']
                    try:
                        tool_input = json.loads(tool_call['arguments'])
                    except json.JSONDecodeError:
                        tool_input = {}

                    yield {
                        'type': 'tool_use',
                        'tool_name': tool_name,
                        'tool_input': tool_input
                    }

                    # Preparer le format pour l'assistant message
                    assistant_tool_calls.append({
                        "id": tool_call['id'],
                        "type": "function",
                        "function": {
                            "name": tool_name,
                            "arguments": tool_call['arguments']
                        }
                    })

                    # Executer le tool si un executor est fourni
                    if tool_executor:
                        try:
                            result = tool_executor(
                                tool_name,
                                tool_input,
                                user
                            )
                            tool_results.append({
                                'role': 'tool',
                                'tool_call_id': tool_call['id'],
                                'content': json.dumps(result, ensure_ascii=False)
                            })
                            yield {
                                'type': 'tool_result',
                                'tool_name': tool_name,
                                'result': result
                            }
                        except Exception as e:
                            error_result = {'error': str(e)}
                            tool_results.append({
                                'role': 'tool',
                                'tool_call_id': tool_call['id'],
                                'content': json.dumps(error_result)
                            })
                            yield {
                                'type': 'tool_error',
                                'tool_name': tool_name,
                                'error': str(e)
                            }
                    else:
                        # Pas d'executor, on ne peut pas executer le tool
                        tool_results.append({
                            'role': 'tool',
                            'tool_call_id': tool_call['id'],
                            'content': json.dumps({'error': 'Tool executor not available'})
                        })

                # Ajouter les messages pour continuer la conversation
                # Message assistant avec tool_calls
                current_messages.append({
                    'role': 'assistant',
                    'content': response_text or None,
                    'tool_calls': assistant_tool_calls
                })

                # Messages tool results
                current_messages.extend(tool_results)

        except Exception as e:
            LogUtils.error(f"Erreur lors de l'appel Mistral: {e}")
            error_message = str(e)
            if "rate" in error_message.lower() or "limit" in error_message.lower():
                yield {'type': 'error', 'error': 'Service temporairement surcharge, veuillez reessayer'}
            elif "connection" in error_message.lower() or "connect" in error_message.lower():
                yield {'type': 'error', 'error': 'Impossible de se connecter au service IA'}
            else:
                yield {'type': 'error', 'error': error_message}

    def chat_completion(
        self,
        messages: List,
        page_context: Dict,
        user
    ) -> Dict[str, Any]:
        """
        Genere une reponse complete (non-streaming).

        Returns:
            Dict avec 'content', 'tokens_utilises', ou 'error'
        """
        try:
            # Extraire la question utilisateur
            user_question = ""
            if messages:
                last_msg = messages[-1] if hasattr(messages[-1], 'contenu') else messages[-1]
                user_question = getattr(last_msg, 'contenu', '') if hasattr(last_msg, 'contenu') else str(last_msg)

            system_prompt = self._build_system_prompt(page_context, user, user_question)

            # Utiliser l'optimisation des messages
            formatted_messages = self._optimize_messages(messages)

            if not formatted_messages:
                return {'error': 'Aucun message a traiter'}

            # Ajouter le system prompt comme premier message
            messages_with_system = [
                {"role": "system", "content": system_prompt}
            ] + formatted_messages

            response = self.client.chat.complete(
                model=self._model,
                max_tokens=self.MAX_TOKENS,
                messages=messages_with_system
            )

            content = ""
            if response.choices:
                content = response.choices[0].message.content or ""

            total_tokens = 0
            input_tokens = 0
            output_tokens = 0
            if response.usage:
                input_tokens = response.usage.prompt_tokens
                output_tokens = response.usage.completion_tokens
                total_tokens = input_tokens + output_tokens

            return {
                'content': content,
                'tokens_utilises': total_tokens,
                'input_tokens': input_tokens,
                'output_tokens': output_tokens
            }

        except Exception as e:
            LogUtils.error(f"Erreur lors de l'appel Mistral: {e}")
            return {'error': str(e)}

    def analyze_code_for_bug(
        self,
        error_message: str,
        code_context: str,
        user_description: str
    ) -> Dict[str, Any]:
        """
        Analyse du code pour detecter un bug potentiel.

        Returns:
            Dict avec 'is_bug', 'analysis', 'recommendation'
        """
        prompt = f"""Analyse le probleme suivant signale par un utilisateur:

Description de l'utilisateur: {user_description}

Message d'erreur (si disponible): {error_message}

Code source pertinent:
```
{code_context}
```

Reponds au format JSON avec les cles suivantes:
- is_bug: boolean (true si c'est un bug dans le code, false si c'est une erreur utilisateur)
- analysis: string (explication du probleme)
- recommendation: string (recommandation pour resoudre le probleme)
- severity: string (low/medium/high si c'est un bug)
"""

        try:
            response = self.client.chat.complete(
                model=self._model,
                max_tokens=1024,
                messages=[
                    {"role": "system", "content": "Tu es un expert en analyse de bugs. Reponds uniquement en JSON valide."},
                    {"role": "user", "content": prompt}
                ]
            )

            content = ""
            if response.choices:
                content = response.choices[0].message.content or "{}"

            # Essayer de parser le JSON
            try:
                # Extraire le JSON de la reponse
                import re
                json_match = re.search(r'\{[^{}]*\}', content, re.DOTALL)
                if json_match:
                    return json.loads(json_match.group())
            except json.JSONDecodeError:
                pass

            return {
                'is_bug': False,
                'analysis': content,
                'recommendation': 'Contactez le support si le probleme persiste.'
            }

        except Exception as e:
            LogUtils.error(f"Erreur lors de l'analyse de bug: {e}")
            return {
                'error': str(e),
                'is_bug': False,
                'analysis': 'Impossible d\'analyser le probleme',
                'recommendation': 'Veuillez contacter le support technique.'
            }


# Alias pour compatibilite avec l'ancien code
ClaudeService = MistralService
