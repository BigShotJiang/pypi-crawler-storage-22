from django.contrib import admin

from lucy_assist.models import Conversation, Message, ConfigurationLucyAssist


class BlockMessage(admin.StackedInline):
    model = Message
    extra = 1


@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ('id', 'utilisateur', 'titre', 'created_date', 'is_active')
    list_filter = ('is_active', 'created_date')
    search_fields = ('utilisateur__email', 'titre')
    ordering = ('-created_date',)
    inlines = [BlockMessage]


@admin.register(ConfigurationLucyAssist)
class ConfigurationLucyAssistAdmin(admin.ModelAdmin):
    list_display = ('id', 'tokens_disponibles', 'prix_par_million_tokens', 'nb_vues_crud', 'updated_date')
    readonly_fields = ('crud_views_mapping_display', 'model_app_mapping_display')
    fieldsets = (
        ('Configuration Tokens', {
            'fields': ('tokens_disponibles', 'prix_par_million_tokens', 'actif')
        }),
        ('Personnalisation', {
            'fields': ('avatar', 'questions_frequentes')
        }),
        ('Prompt Systeme', {
            'fields': ('system_prompt',),
            'classes': ('collapse',),
            'description': 'Le prompt systeme est initialise automatiquement si vide.'
        }),
        ('Mapping Automatique (lecture seule)', {
            'fields': ('crud_views_mapping_display', 'model_app_mapping_display'),
            'classes': ('collapse',)
        }),
    )
    actions = ['refresh_crud_views']

    def nb_vues_crud(self, obj):
        """Affiche le nombre de modeles avec des vues CRUD decouvertes."""
        if obj.crud_views_mapping:
            return len(obj.crud_views_mapping)
        return 0
    nb_vues_crud.short_description = "Modeles CRUD"

    def crud_views_mapping_display(self, obj):
        """Affiche le mapping des vues CRUD de maniere lisible."""
        import json
        if obj.crud_views_mapping:
            return json.dumps(obj.crud_views_mapping, indent=2, ensure_ascii=False)
        return "Aucune vue decouverte. Utilisez l'action 'Rafraichir les vues CRUD'."
    crud_views_mapping_display.short_description = "Vues CRUD decouvertes"

    def model_app_mapping_display(self, obj):
        """Affiche le mapping modele -> app de maniere lisible."""
        import json
        if obj.model_app_mapping:
            return json.dumps(obj.model_app_mapping, indent=2, ensure_ascii=False)
        return "Aucun mapping. Sera construit automatiquement."
    model_app_mapping_display.short_description = "Mapping Modele -> App"

    @admin.action(description="Rafraichir les vues CRUD decouvertes")
    def refresh_crud_views(self, request, queryset):
        """Action admin pour rafraichir le mapping des vues CRUD."""
        for config in queryset:
            mapping = config.refresh_crud_views_mapping()
            nb_models = len(mapping)
            nb_views = sum(len(actions) for actions in mapping.values())
            self.message_user(
                request,
                f"Mapping rafraichi: {nb_models} modeles, {nb_views} vues decouvertes."
            )
