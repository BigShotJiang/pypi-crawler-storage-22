"""
Definition des tools pour l'API Mistral.

Ces tools permettent a Lucy Assist d'executer des actions CRUD
directement dans l'application.

Format: Compatible OpenAI/Mistral (type: function)
"""

# Tools disponibles pour Mistral (format OpenAI)
LUCY_ASSIST_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "create_object",
            "description": """Cree un nouvel objet dans la base de donnees.
            Utilise ce tool quand l'utilisateur demande de creer un objet metier (client, facture, etc.).
            IMPORTANT: Utilise ce tool en priorite quand l'utilisateur demande une creation.
            Ne demande pas de confirmation, execute directement l'action.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Nom de l'application Django (ex: client, facture)"
                    },
                    "model_name": {
                        "type": "string",
                        "description": "Nom du modele Django (ex: Client, Facture)"
                    },
                    "data": {
                        "type": "object",
                        "description": "Donnees pour creer l'objet. Les cles sont les noms des champs du modele.",
                        "additionalProperties": True
                    }
                },
                "required": ["app_name", "model_name", "data"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "update_object",
            "description": """Met a jour un objet existant dans la base de donnees.
            Utilise ce tool quand l'utilisateur demande de modifier un objet existant.
            IMPORTANT: Execute directement l'action sans demander de confirmation.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Nom de l'application Django"
                    },
                    "model_name": {
                        "type": "string",
                        "description": "Nom du modele Django"
                    },
                    "object_id": {
                        "type": "integer",
                        "description": "ID de l'objet a modifier"
                    },
                    "data": {
                        "type": "object",
                        "description": "Donnees a mettre a jour",
                        "additionalProperties": True
                    }
                },
                "required": ["app_name", "model_name", "object_id", "data"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_deletion_impact",
            "description": """Analyse l'impact d'une suppression AVANT de supprimer.
            OBLIGATOIRE: Utilise TOUJOURS ce tool AVANT delete_object pour montrer a l'utilisateur
            toutes les consequences de la suppression (objets supprimes en cascade, champs mis a NULL, etc.)
            Affiche le resultat a l'utilisateur et demande sa confirmation explicite avant de supprimer.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Nom de l'application Django"
                    },
                    "model_name": {
                        "type": "string",
                        "description": "Nom du modele Django"
                    },
                    "object_id": {
                        "type": "integer",
                        "description": "ID de l'objet a analyser"
                    }
                },
                "required": ["app_name", "model_name", "object_id"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "delete_object",
            "description": """Supprime un objet de la base de donnees.
            IMPORTANT: Tu DOIS d'abord utiliser get_deletion_impact pour analyser les consequences,
            puis afficher le resultat a l'utilisateur, et obtenir sa CONFIRMATION EXPLICITE avant d'executer ce tool.
            Ne JAMAIS supprimer sans avoir montre l'impact et obtenu confirmation.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Nom de l'application Django"
                    },
                    "model_name": {
                        "type": "string",
                        "description": "Nom du modele Django"
                    },
                    "object_id": {
                        "type": "integer",
                        "description": "ID de l'objet a supprimer"
                    },
                    "confirmed": {
                        "type": "boolean",
                        "description": "OBLIGATOIRE: true si l'utilisateur a explicitement confirme la suppression apres avoir vu l'impact"
                    }
                },
                "required": ["app_name", "model_name", "object_id", "confirmed"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_objects",
            "description": """Recherche des objets dans la base de donnees.
            Utilise ce tool pour trouver des clients, reservations, ou tout autre objet metier.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Terme de recherche"
                    },
                    "model_name": {
                        "type": "string",
                        "description": "Nom du modele a rechercher (optionnel, cherche dans tous si non specifie)"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Nombre maximum de resultats (defaut: 10)",
                        "default": 10
                    }
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_object_details",
            "description": """Recupere les details d'un objet specifique.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Nom de l'application Django"
                    },
                    "model_name": {
                        "type": "string",
                        "description": "Nom du modele Django"
                    },
                    "object_id": {
                        "type": "integer",
                        "description": "ID de l'objet"
                    }
                },
                "required": ["app_name", "model_name", "object_id"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_form_fields",
            "description": """Recupere les champs requis et optionnels d'un formulaire.
            Utilise ce tool uniquement si tu as besoin de connaitre les champs avant de creer un objet,
            ou si l'utilisateur demande explicitement quels champs sont disponibles.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Nom de l'application Django"
                    },
                    "model_name": {
                        "type": "string",
                        "description": "Nom du modele Django"
                    }
                },
                "required": ["app_name", "model_name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "navigate_to_page",
            "description": """Genere une URL pour naviguer vers une page specifique.
            Utilise ce tool uniquement si l'utilisateur demande explicitement d'aller quelque part
            ou si tu as besoin de lui montrer ou aller.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "page_type": {
                        "type": "string",
                        "enum": ["list", "create", "detail", "edit"],
                        "description": "Type de page"
                    },
                    "app_name": {
                        "type": "string",
                        "description": "Nom de l'application"
                    },
                    "model_name": {
                        "type": "string",
                        "description": "Nom du modele"
                    },
                    "object_id": {
                        "type": "integer",
                        "description": "ID de l'objet (pour detail/edit)"
                    }
                },
                "required": ["page_type", "app_name", "model_name"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "analyze_bug",
            "description": """Analyse un bug potentiel en se connectant a GitLab pour examiner le code source.
            Utilise ce tool quand l'utilisateur signale un probleme technique, une erreur, ou un comportement inattendu.
            Ce tool analyse le code via GitLab et si un bug est detecte, envoie automatiquement une notification
            a l'equipe Revolucy pour correction.
            IMPORTANT: Utilise ce tool des qu'un utilisateur signale un message d'erreur ou un dysfonctionnement.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "user_description": {
                        "type": "string",
                        "description": "Description du probleme par l'utilisateur (obligatoire)"
                    },
                    "error_message": {
                        "type": "string",
                        "description": "Message d'erreur exact (si disponible)"
                    },
                    "page_url": {
                        "type": "string",
                        "description": "URL de la page ou le probleme se produit"
                    },
                    "model_name": {
                        "type": "string",
                        "description": "Nom du modele Django concerne (si identifiable, ex: Client, Reservation)"
                    },
                    "action_type": {
                        "type": "string",
                        "enum": ["create", "update", "delete", "list", "search", "other"],
                        "description": "Type d'action qui a cause le probleme"
                    }
                },
                "required": ["user_description"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_page_help",
            "description": """Recupere l'aide contextuelle pour la page actuelle.
            Utilise ce tool pour obtenir des informations sur ce que l'utilisateur peut faire sur la page.
            Retourne les actions suggerees, liens utiles et conseils.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "url_path": {
                        "type": "string",
                        "description": "URL de la page actuelle (disponible dans le contexte)"
                    }
                },
                "required": ["url_path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_code_gitlab",
            "description": """USAGE INTERNE - Recherche dans le code source pour comprendre le fonctionnement.
            Utilise ce tool pour comprendre comment fonctionne une fonctionnalite.
            IMPORTANT: Les resultats sont pour TON usage interne uniquement.
            Ne JAMAIS montrer les chemins de fichiers ou le code a l'utilisateur.
            Utilise ces informations pour repondre en termes simples avec des liens vers les pages.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Terme de recherche (nom de classe, fonction, variable, texte)"
                    },
                    "file_type": {
                        "type": "string",
                        "enum": ["models", "views", "urls", "forms", "admin", "all"],
                        "description": "Type de fichier a rechercher (defaut: all)"
                    }
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_file_content_gitlab",
            "description": """USAGE INTERNE - Recupere le contenu d'un fichier pour comprendre le fonctionnement.
            IMPORTANT: Les resultats sont pour TON usage interne uniquement.
            Ne JAMAIS montrer le code source ou les chemins de fichiers a l'utilisateur.
            Utilise ces informations pour repondre en termes simples avec des liens vers les pages.""",
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Chemin du fichier dans le repository"
                    }
                },
                "required": ["file_path"]
            }
        }
    }
]


def get_app_for_model(model_name: str) -> str:
    """
    Retourne le nom de l'app Django pour un modele donne.

    Utilise la configuration stockee en base de donnees.
    """
    from lucy_assist.models import ConfigurationLucyAssist
    return ConfigurationLucyAssist.get_app_for_model_static(model_name)
