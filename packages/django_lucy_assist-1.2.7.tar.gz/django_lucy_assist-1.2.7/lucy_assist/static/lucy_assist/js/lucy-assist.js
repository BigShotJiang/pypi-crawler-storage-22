/**
 * Lucy Assist - Chatbot en vanilla JavaScript
 * Zero dependance externe - pas d'Alpine.js, pas de Font Awesome
 */
(function () {
    'use strict';

    // ========================================================================
    // ETAT
    // ========================================================================
    const state = {
        isOpen: false,
        isExpanded: false,
        isLoading: false,
        showHistory: false,
        showDoc: false,
        hasNewMessage: false,
        hasError: false,
        lucyDidNotUnderstand: false,
        currentMessage: '',
        messages: [],
        conversations: [],
        suggestions: [],
        currentConversationId: null,
        tokensDisponibles: 0,
        buyAmount: 10,
        feedbackDescription: '',
        feedbackSending: false,
        guideStep: 1,
    };

    // ========================================================================
    // CONFIG
    // ========================================================================
    const API_BASE = '/lucy-assist/api';
    let csrfToken = '';

    // ========================================================================
    // ELEMENTS DOM (caches apres init)
    // ========================================================================
    const $ = (id) => document.getElementById(id);

    let els = {};

    // ========================================================================
    // HELPERS
    // ========================================================================

    function getCookie(name) {
        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? decodeURIComponent(match[2]) : null;
    }

    function formatTokens(tokens) {
        if (tokens >= 1000000) return (tokens / 1000000).toFixed(1) + 'M';
        if (tokens >= 1000) return (tokens / 1000).toFixed(0) + 'K';
        return tokens.toString();
    }

    function formatTokenCost(tokens) {
        return ((tokens / 1000000) * 10).toFixed(4) + '€';
    }

    function formatDate(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;
        if (diff < 60000) return "À l'instant";
        if (diff < 3600000) return `Il y a ${Math.floor(diff / 60000)} min`;
        if (date.toDateString() === now.toDateString())
            return `Aujourd'hui à ${date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`;
        if (diff < 7 * 86400000)
            return date.toLocaleDateString('fr-FR', { weekday: 'long', hour: '2-digit', minute: '2-digit' });
        return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
    }

    function formatTime(dateString) {
        return new Date(dateString).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    }

    function escapeHtml(s) {
        return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function formatMessage(content) {
        if (!content) return '';
        let f = escapeHtml(content);
        f = f.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        f = f.replace(/\*(.*?)\*/g, '<em>$1</em>');
        f = f.replace(/`(.*?)`/g, '<code style="background:rgba(0,0,0,.1);padding:0 4px;border-radius:3px;">$1</code>');
        f = f.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" style="color:var(--lucy-primary,#6366f1);text-decoration:underline;">$1</a>');
        f = f.replace(/\n/g, '<br>');
        return f;
    }

    function checkIfLucyDidNotUnderstand(response) {
        if (!response) return false;
        const lower = response.toLowerCase();
        const patterns = [
            'je ne comprends pas', "je n'ai pas compris", 'pourriez-vous reformuler',
            'pouvez-vous reformuler', 'pourriez-vous préciser', 'pouvez-vous préciser',
            "je ne suis pas sûr de comprendre", "je n'ai pas accès", "je n'ai pas les outils",
            'je ne peux pas', 'je ne suis pas en mesure', 'fonctionnalité non disponible',
            'je ne dispose pas', 'mes outils actuels ne permettent pas', "je n'arrive pas à",
            'impossible de réaliser', 'en dehors de mon périmètre', 'hors de mon champ',
            'dépasse mes capacités', 'comment puis-je vous aider avec votre crm'
        ];
        return patterns.some(p => lower.includes(p));
    }

    // ========================================================================
    // API
    // ========================================================================

    async function apiGet(endpoint) {
        const r = await fetch(API_BASE + endpoint, {
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken }
        });
        if (!r.ok) throw { status: r.status, ...(await r.json()) };
        return r.json();
    }

    async function apiPost(endpoint, data) {
        const r = await fetch(API_BASE + endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken },
            body: JSON.stringify(data)
        });
        if (!r.ok) throw { status: r.status, ...(await r.json()) };
        return r.json();
    }

    async function apiDelete(endpoint) {
        const r = await fetch(API_BASE + endpoint, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken }
        });
        if (!r.ok) throw { status: r.status, ...(await r.json()) };
        return r.json();
    }

    // ========================================================================
    // RENDU
    // ========================================================================

    function scrollToBottom() {
        const c = els.messages;
        if (c) c.scrollTop = c.scrollHeight;
    }

    function updateTokensDisplay() {
        els.tokens.textContent = formatTokens(state.tokensDisponibles);
        els.btnBuyCredits.style.display = state.tokensDisponibles < 100000 ? '' : 'none';
    }

    function updateExpandIcons() {
        const expand = els.sidebar.querySelector('.lucy-icon-expand');
    }

    /** Affiche la bonne vue : chat / history / doc */
    function showView(view) {
        state.showHistory = view === 'history';
        state.showDoc = view === 'doc';

        els.viewHistory.style.display = state.showHistory ? '' : 'none';
        els.viewDoc.style.display = state.showDoc ? '' : 'none';
        els.viewChat.style.display = (!state.showHistory && !state.showDoc) ? '' : 'none';

        // boutons actifs
        els.btnHistory.classList.toggle('active', state.showHistory);
        els.btnDoc.classList.toggle('active', state.showDoc);
    }

    /** Rend la liste des conversations dans l'historique */
    function renderHistoryList() {
        const container = els.historyList;
        if (!container) return;

        if (state.conversations.length === 0) {
            container.innerHTML = '<p class="lucy-history-empty">Aucune conversation</p>';
            return;
        }

        container.innerHTML = state.conversations.map(conv => `
            <div class="lucy-history-item ${state.currentConversationId === conv.id ? 'active' : ''}"
                 data-conv-id="${conv.id}">
                <div class="lucy-history-item-title">${escapeHtml(conv.titre || 'Sans titre')}</div>
                <div class="lucy-history-item-meta">
                    <span>${formatDate(conv.created_date)}</span>
                    <span style="margin-left:.5rem">${conv.total_tokens} tokens | ${formatTokenCost(conv.total_tokens)}</span>
                </div>
                <button class="lucy-btn-delete" data-delete-id="${conv.id}">🗑️ Supprimer</button>
            </div>
        `).join('');

        // Event delegation
        container.querySelectorAll('[data-conv-id]').forEach(el => {
            el.addEventListener('click', (e) => {
                if (e.target.closest('[data-delete-id]')) return;
                loadConversation(parseInt(el.dataset.convId));
            });
        });
        container.querySelectorAll('[data-delete-id]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                deleteConversation(parseInt(btn.dataset.deleteId));
            });
        });
    }

    /** Rend la zone de messages */
    function renderMessages() {
        const container = els.messages;
        if (!container) return;

        if (state.messages.length === 0) {
            els.welcome.style.display = '';
            // Feedback bars cachees quand pas de messages
            els.feedbackContact.style.display = 'none';
            els.feedbackError.style.display = 'none';
            return;
        }

        els.welcome.style.display = 'none';

        // Garder le welcome puis ajouter les messages
        // On reconstruit uniquement les bulles
        // Supprimer les anciens message-divs
        container.querySelectorAll('.lucy-message').forEach(el => el.remove());

        const avatarUrl = container.dataset.avatarUrl || '';
        const lucyIcon = container.dataset.lucyIcon || '';

        state.messages.forEach(msg => {
            const isUser = msg.repondant === 'UTILISATEUR';
            const div = document.createElement('div');
            div.className = 'lucy-message ' + (isUser ? 'user' : 'bot');

            let avatarHtml;
            if (isUser) {
                avatarHtml = avatarUrl
                    ? `<img src="${avatarUrl}" alt="Utilisateur">`
                    : `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>`;
            } else {
                avatarHtml = lucyIcon
                    ? `<img src="${lucyIcon}" alt="Lucy">`
                    : '🤖';
            }

            const bubbleContent = msg.contenu
                ? `<span>${formatMessage(msg.contenu)}</span>`
                : `<span class="lucy-loading-dots"><span></span><span></span><span></span></span>`;

            div.innerHTML = `
                <div class="lucy-message-avatar">${avatarHtml}</div>
                <div class="lucy-message-content">
                    <div class="lucy-message-bubble">${bubbleContent}</div>
                    <div class="lucy-message-time">${formatTime(msg.created_date)}</div>
                </div>
            `;
            container.appendChild(div);
        });

        // Feedback bars
        els.feedbackContact.style.display = (state.lucyDidNotUnderstand && state.messages.length > 0) ? '' : 'none';
        els.feedbackError.style.display = (state.hasError && !state.lucyDidNotUnderstand && state.messages.length > 0) ? '' : 'none';

        requestAnimationFrame(scrollToBottom);
    }

    /** Rend les suggestions */
    function renderSuggestions() {
        const container = els.suggestions;
        if (!container) return;
        container.innerHTML = state.suggestions.map(s => `
            <button class="lucy-suggestion-btn" data-suggestion="${escapeHtml(s)}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="flex-shrink:0;color:#f59e0b"><path stroke-linecap="round" stroke-linejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>
                <span>${escapeHtml(s)}</span>
            </button>
        `).join('');

        container.querySelectorAll('[data-suggestion]').forEach(btn => {
            btn.addEventListener('click', () => sendMessage(btn.dataset.suggestion));
        });
    }

    function updateBuyModal() {
        const tokens = Math.floor((state.buyAmount / 10) * 1000000);
        els.buyTokens.textContent = formatTokens(tokens);
        els.buyConvs.textContent = Math.floor(tokens / 2000).toString();
    }

    // ========================================================================
    // ACTIONS
    // ========================================================================

    function openSidebar() {
        state.isOpen = true;
        state.hasNewMessage = false;
        els.floatBtn.style.display = 'none';
        els.sidebar.style.display = '';
        els.sidebar.classList.remove('hidden');
        saveState();
        setTimeout(() => els.input.focus(), 100);
    }

    function closeSidebar() {
        state.isOpen = false;
        state.showHistory = false;
        state.showDoc = false;
        els.sidebar.style.display = 'none';
        els.sidebar.classList.add('hidden');
        els.floatBtn.style.display = '';
        showView('chat');
        saveState();
    }

    function toggleSidebar() {
        state.isOpen ? closeSidebar() : openSidebar();
    }

    function toggleExpanded() {
        state.isExpanded = !state.isExpanded;
        els.sidebar.classList.toggle('expanded', state.isExpanded);
        updateExpandIcons();
        saveState();
    }

    async function loadTokenStatus() {
        try {
            const r = await apiGet('/tokens/status');
            state.tokensDisponibles = r.tokens_disponibles || 0;
            updateTokensDisplay();
        } catch (e) { console.error('Erreur chargement tokens:', e); }
    }

    async function loadConversations() {
        try {
            const r = await apiGet('/conversations');
            state.conversations = r.conversations || [];
            renderHistoryList();
        } catch (e) { console.error('Erreur chargement conversations:', e); }
    }

    async function loadSuggestions() {
        try {
            const r = await apiGet('/suggestions');
            state.suggestions = r.suggestions || [];
        } catch (e) {
            state.suggestions = [
                "Comment créer un nouveau membre ?",
                "Comment effectuer un paiement ?",
                "Où trouver la liste des adhésions ?"
            ];
        }
        renderSuggestions();
    }

    async function newConversation() {
        try {
            const r = await apiPost('/conversations', { page_contexte: window.location.pathname });
            state.currentConversationId = r.id;
            state.messages = [];
            showView('chat');
            renderMessages();
            saveState();
            await loadConversations();
        } catch (e) { console.error('Erreur création conversation:', e); }
    }

    async function loadConversation(id) {
        try {
            const r = await apiGet(`/conversations/${id}`);
            state.currentConversationId = id;
            state.messages = r.messages || [];
            showView('chat');
            renderMessages();
            saveState();
            setTimeout(scrollToBottom, 100);
        } catch (e) {
            console.error('Erreur chargement conversation:', e);
            state.currentConversationId = null;
            state.messages = [];
            renderMessages();
            saveState();
        }
    }

    async function deleteConversation(id) {
        if (!confirm('Êtes-vous sûr de vouloir supprimer cette conversation ?')) return;
        try {
            await apiDelete(`/conversations/${id}`);
            await loadConversations();
            if (state.currentConversationId === id) {
                state.currentConversationId = null;
                state.messages = [];
                renderMessages();
            }
        } catch (e) { console.error('Erreur suppression:', e); }
    }

    async function sendMessage(message) {
        if (state.isLoading || !message.trim()) return;

        state.lucyDidNotUnderstand = false;

        if (!state.currentConversationId) await newConversation();

        // Message utilisateur
        state.messages.push({
            id: Date.now(),
            repondant: 'UTILISATEUR',
            contenu: message,
            created_date: new Date().toISOString(),
            tokens_utilises: 0
        });
        state.currentMessage = '';
        els.input.value = '';
        els.input.style.height = 'auto';
        updateSendBtn();
        renderMessages();

        try {
            state.isLoading = true;
            els.input.disabled = true;
            els.btnSend.disabled = true;

            await apiPost(`/conversations/${state.currentConversationId}/messages`, { contenu: message });
            await streamChatCompletion();
        } catch (e) {
            console.error('Erreur envoi message:', e);
            if (e.status === 402) {
                showModal('buy');
            } else {
                state.hasError = true;
                renderMessages();
            }
        } finally {
            state.isLoading = false;
            els.input.disabled = false;
            updateSendBtn();
            els.input.focus();
        }
    }

    async function streamChatCompletion() {
        const url = `${API_BASE}/conversations/${state.currentConversationId}/chat`;
        const botIdx = state.messages.length;

        state.messages.push({
            id: Date.now() + 1,
            repondant: 'CHATBOT',
            contenu: '',
            created_date: new Date().toISOString(),
            tokens_utilises: 0
        });
        renderMessages();

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken },
                body: JSON.stringify({ page_contexte: window.location.pathname })
            });

            if (!response.ok) throw { status: response.status, ...(await response.json()) };

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let fullContent = '';

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const text = decoder.decode(value);
                for (const line of text.split('\n')) {
                    if (!line.startsWith('data: ')) continue;
                    try {
                        const data = JSON.parse(line.slice(6));
                        if (data.type === 'content') {
                            fullContent += data.content;
                            state.messages[botIdx].contenu = fullContent;
                            renderMessages();
                        } else if (data.type === 'done') {
                            state.messages[botIdx].id = data.message_id;
                            state.messages[botIdx].tokens_utilises = data.tokens_utilises;
                            await loadTokenStatus();
                        } else if (data.type === 'error') {
                            throw new Error(data.error);
                        }
                    } catch (e) { if (e.message) throw e; }
                }
            }

            if (!state.messages[botIdx]?.contenu) {
                state.messages.splice(botIdx, 1);
            }

            state.lucyDidNotUnderstand = checkIfLucyDidNotUnderstand(state.messages[botIdx]?.contenu || '');
            if (!state.lucyDidNotUnderstand) state.hasError = false;

            renderMessages();
            await loadConversations();
        } catch (e) {
            state.hasError = true;
            if (botIdx < state.messages.length && !state.messages[botIdx]?.contenu) {
                state.messages.splice(botIdx, 1);
            }
            renderMessages();
            throw e;
        }
    }

    async function sendFeedback() {
        if (!state.currentConversationId) return;
        state.feedbackSending = true;
        try {
            await apiPost('/feedback', {
                conversation_id: state.currentConversationId,
                description: state.feedbackDescription,
                page_url: window.location.href
            });
            state.hasError = false;
            state.lucyDidNotUnderstand = false;
            hideModal('feedback');
            renderMessages();
        } catch (e) { console.error('Erreur feedback:', e); }
        finally { state.feedbackSending = false; }
    }

    async function buyCredits() {
        if (state.buyAmount < 10) return;
        try {
            const r = await apiPost('/tokens/buy', { montant_ht: state.buyAmount });
            window.open(r.url_souscription, '_blank');
            hideModal('buy');
        } catch (e) { console.error('Erreur achat:', e); }
    }

    // ========================================================================
    // MODALS
    // ========================================================================

    function showModal(name) {
        if (name === 'buy') {
            els.modalBuy.style.display = '';
            updateBuyModal();
        } else if (name === 'feedback') {
            els.modalFeedback.style.display = '';
            state.feedbackDescription = '';
            els.feedbackDesc.value = '';
        }
    }

    function hideModal(name) {
        if (name === 'buy') els.modalBuy.style.display = 'none';
        else if (name === 'feedback') els.modalFeedback.style.display = 'none';
    }

    // ========================================================================
    // GUIDE
    // ========================================================================

    function checkFirstLaunch() {
        if (!localStorage.getItem('lucy_assist_guide_seen') && state.conversations.length === 0) {
            setTimeout(() => {
                if (state.conversations.length === 0) {
                    els.guideOverlay.style.display = '';
                    openSidebar();
                }
            }, 2000);
        }
    }

    function guideNext() {
        state.guideStep = 2;
        els.guideStep1.style.display = 'none';
        els.guideStep2.style.display = '';
    }

    function guideFinish() {
        els.guideOverlay.style.display = 'none';
        localStorage.setItem('lucy_assist_guide_seen', 'true');
    }

    // ========================================================================
    // STATE PERSISTENCE
    // ========================================================================

    function saveState() {
        sessionStorage.setItem('lucy_assist_state', JSON.stringify({
            isOpen: state.isOpen,
            isExpanded: state.isExpanded,
            currentConversationId: state.currentConversationId,
            showHistory: state.showHistory,
            showDoc: state.showDoc
        }));
    }

    function restoreState() {
        try {
            const s = JSON.parse(sessionStorage.getItem('lucy_assist_state'));
            if (!s) return;
            state.isOpen = s.isOpen || false;
            state.isExpanded = s.isExpanded || false;
            state.currentConversationId = s.currentConversationId || null;
            state.showHistory = s.showHistory || false;
            state.showDoc = s.showDoc || false;
        } catch (e) {}
    }

    // ========================================================================
    // SEND BUTTON STATE
    // ========================================================================

    function updateSendBtn() {
        els.btnSend.disabled = state.isLoading || !els.input.value.trim();
    }

    // ========================================================================
    // INIT
    // ========================================================================

    function init() {
        // Cache des elements
        els = {
            floatBtn: $('lucy-float-btn'),
            sidebar: $('lucy-sidebar'),
            tokens: $('lucy-tokens'),
            btnBuyCredits: $('lucy-btn-buy-credits'),
            btnExpand: $('lucy-btn-expand'),
            btnHistory: $('lucy-btn-history'),
            btnNew: $('lucy-btn-new'),
            btnDoc: $('lucy-btn-doc'),
            btnClose: $('lucy-btn-close'),
            btnSend: $('lucy-btn-send'),
            input: $('lucy-input'),
            messages: $('lucy-messages'),
            welcome: $('lucy-welcome'),
            suggestions: $('lucy-suggestions'),
            viewHistory: $('lucy-view-history'),
            viewDoc: $('lucy-view-doc'),
            viewChat: $('lucy-view-chat'),
            historyList: $('lucy-history-list'),
            feedbackContact: $('lucy-feedback-contact'),
            feedbackError: $('lucy-feedback-error'),
            btnFeedbackContact: $('lucy-btn-feedback-contact'),
            btnFeedbackError: $('lucy-btn-feedback-error'),
            modalBuy: $('lucy-modal-buy'),
            modalFeedback: $('lucy-modal-feedback'),
            buyAmount: $('lucy-buy-amount'),
            buyTokens: $('lucy-buy-tokens'),
            buyConvs: $('lucy-buy-convs'),
            buyCancel: $('lucy-buy-cancel'),
            buyConfirm: $('lucy-buy-confirm'),
            feedbackDesc: $('lucy-feedback-desc'),
            feedbackCancel: $('lucy-feedback-cancel'),
            feedbackConfirm: $('lucy-feedback-confirm'),
            guideOverlay: $('lucy-guide-overlay'),
            guideStep1: $('lucy-guide-step1'),
            guideStep2: $('lucy-guide-step2'),
            guideSkip: $('lucy-guide-skip'),
            guideNext: $('lucy-guide-next'),
            guideFinish: $('lucy-guide-finish'),
        };

        // CSRF
        csrfToken = document.querySelector('[name=csrfmiddlewaretoken]')?.value || getCookie('csrftoken') || '';

        // Restaurer l'etat
        restoreState();

        // Appliquer l'etat initial
        if (state.isOpen) {
            els.floatBtn.style.display = 'none';
            els.sidebar.style.display = '';
            els.sidebar.classList.remove('hidden');
        }
        if (state.isExpanded) {
            els.sidebar.classList.add('expanded');
        }
        updateExpandIcons();

        if (state.showHistory) showView('history');
        else if (state.showDoc) showView('doc');
        else showView('chat');

        // ---- EVENT LISTENERS ----

        // Bouton flottant
        els.floatBtn.addEventListener('click', toggleSidebar);

        // Header buttons
        els.btnExpand.addEventListener('click', toggleExpanded);
        els.btnHistory.addEventListener('click', () => showView(state.showHistory ? 'chat' : 'history'));
        els.btnNew.addEventListener('click', newConversation);
        els.btnDoc.addEventListener('click', () => showView(state.showDoc ? 'chat' : 'doc'));
        els.btnClose.addEventListener('click', closeSidebar);

        // Input
        els.input.addEventListener('input', () => {
            state.currentMessage = els.input.value;
            els.input.style.height = 'auto';
            els.input.style.height = Math.min(els.input.scrollHeight, 128) + 'px';
            updateSendBtn();
        });
        els.input.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                sendMessage(els.input.value);
            }
        });

        // Send
        els.btnSend.addEventListener('click', () => sendMessage(els.input.value));

        // Feedback
        els.btnFeedbackContact.addEventListener('click', () => showModal('feedback'));
        els.btnFeedbackError.addEventListener('click', () => showModal('feedback'));

        // Buy credits
        els.btnBuyCredits.addEventListener('click', () => showModal('buy'));
        els.buyCancel.addEventListener('click', () => hideModal('buy'));
        els.buyConfirm.addEventListener('click', buyCredits);
        els.buyAmount.addEventListener('input', () => {
            state.buyAmount = parseInt(els.buyAmount.value) || 10;
            updateBuyModal();
        });

        // Feedback modal
        els.feedbackCancel.addEventListener('click', () => hideModal('feedback'));
        els.feedbackConfirm.addEventListener('click', sendFeedback);
        els.feedbackDesc.addEventListener('input', () => {
            state.feedbackDescription = els.feedbackDesc.value;
        });

        // Guide
        els.guideSkip.addEventListener('click', guideFinish);
        els.guideNext.addEventListener('click', guideNext);
        els.guideFinish.addEventListener('click', guideFinish);

        // Raccourcis clavier globaux
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'k') { e.preventDefault(); toggleSidebar(); }
            if (e.key === 'Escape' && state.isOpen) closeSidebar();
        });

        // Sauvegarder avant de quitter
        window.addEventListener('beforeunload', saveState);

        // Charger les donnees
        loadTokenStatus();
        loadConversations().then(() => {
            if (state.currentConversationId) loadConversation(state.currentConversationId);
        });
        loadSuggestions();
        checkFirstLaunch();
    }

    // Lancer l'init quand le DOM est pret
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
