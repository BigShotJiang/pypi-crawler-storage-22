# Django Lucy Assist

Assistant IA intelligent base sur Mistral AI, integrable dans n'importe quelle application Django.

## Installation

```bash
pip install django-lucy-assist
```

## Configuration

### 1. Ajouter l'application a INSTALLED_APPS

```python
INSTALLED_APPS = [
    ...
    'lucy_assist',
]
```

### 2. Configurer les variables d'environnement

Ajouter dans votre fichier `.env` :

```bash
# ======================================== LUCY ASSIST ========================================
MISTRAL_LUCY_API_KEY=votre-cle-api-mistral
GITLAB_TOKEN=glpat-...
GITLAB_PROJECT_ID=123

# SIREN client pour l'API Lucy CRM  (Si non present via le module de retour)
SIREN_CLIENT=123456789
```

Puis dans votre `settings.py` :

```python
import os

#############################################################################################################
# Lucy Assist
MISTRAL_LUCY_API_KEY = env('MISTRAL_LUCY_API_KEY', default=None)
GITLAB_URL = env('GITLAB_URL', default=None)
GITLAB_TOKEN = env('GITLAB_TOKEN', default=None)
GITLAB_PROJECT_ID = env('GITLAB_PROJECT_ID', default=None)
LUCY_ASSIST = {
    'PROJECT_APPS_PREFIX': 'apps.',
    # 'MISTRAL_MODEL': 'mistral-large-latest',  # Modele par defaut (le plus performant)
}
```

### 3. Ajouter les URLs

```python
# urls.py
from django.urls import path, include

urlpatterns = [
    ...
    path('lucy-assist/', include('lucy_assist.urls')),
]
```

### 4. Ajouter le context processor

```python
# settings.py
TEMPLATES = [
    {
        ...
        'OPTIONS': {
            'context_processors': [
                ...
                'lucy_assist.context_processors.lucy_assist_context',
            ],
        },
    },
]
```

### 5. Inclure le template dans votre base.html

```html
<!-- templates/base.html -->
{% include 'lucy_assist/chatbot_sidebar.html' %}
```

### 6. Executer les migrations

```bash
python manage.py migrate lucy_assist
```

## Utilisation

Une fois installe et configure, Lucy Assist apparaitra automatiquement sur toutes les pages de votre application avec un bouton flottant en bas a droite.

### Fonctionnalites

- **Chat IA contextuel** : Lucy comprend le contexte de la page actuelle
- **Actions CRUD** : Lucy peut creer, modifier, rechercher et supprimer des objets
- **Analyse de bugs** : Connexion a GitLab pour analyser les problemes signales
- **Historique des conversations** : Sauvegarde automatique des conversations
- **Gestion des tokens** : Suivi de la consommation des tokens Mistral

## Configuration avancee

### Modele de base personnalise

Si vous utilisez un modele de base personnalise avec des champs d'audit (created_date, updated_date, etc.), vous pouvez le configurer :

```python
LUCY_ASSIST = {
    'BASE_MODEL': 'mon_app.models.MonModeleBase',
}
```

### Modele Mistral

Par defaut, Lucy Assist utilise `mistral-large-latest` (le modele le plus performant). Vous pouvez changer le modele :

```python
LUCY_ASSIST = {
    'MISTRAL_MODEL': 'mistral-large-latest',  # Ou 'mistral-medium', 'mistral-small', etc.
}
```

### Personnalisation des questions frequentes

```python
LUCY_ASSIST = {
    'QUESTIONS_FREQUENTES_DEFAULT': [
        "Comment creer un nouveau membre ?",
        "Comment effectuer un paiement ?",
        "Comment exporter des donnees ?",
    ],
}
```

## API

Lucy Assist expose plusieurs endpoints API :

- `GET /lucy-assist/api/conversations/` - Liste des conversations
- `POST /lucy-assist/api/conversations/` - Creer une conversation
- `GET /lucy-assist/api/conversations/<id>/` - Detail d'une conversation
- `POST /lucy-assist/api/conversations/<id>/messages/` - Ajouter un message
- `POST /lucy-assist/api/conversations/<id>/completion/` - Generer une reponse (streaming)
- `GET /lucy-assist/api/tokens/status/` - Statut des tokens

## Licence

[Revolucy](https://www.revolucy.fr)

## Deploiement Pypi

1. `docker-compose exec django pip install build twine`
2. `python -m build`
3. `python -m twine upload dist/*`
4. Indiquer le token present dans 1Password
