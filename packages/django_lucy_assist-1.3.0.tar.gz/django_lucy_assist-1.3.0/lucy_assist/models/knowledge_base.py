"""
Base de connaissances pour enrichir les réponses de Lucy Assist.

Permet aux clients de stocker des informations métier spécifiques
(FAQ, process, aide contextuelle) que Lucy utilisera pour
produire des réponses plus précises et pertinentes.
"""
from django.db import models

from lucy_assist.models.base import LucyAssistBaseModel


class KnowledgeBase(LucyAssistBaseModel):
    """
    Base de connaissances pour enrichir les réponses de Lucy.

    Chaque entrée représente une connaissance métier que Lucy
    peut utiliser pour répondre plus précisément aux utilisateurs.
    """

    class Categorie(models.TextChoices):
        FAQ = 'FAQ', 'Question fréquente'
        PROCESS = 'PROCESS', 'Processus métier'
        AIDE = 'AIDE', 'Aide contextuelle'
        VOCABULAIRE = 'VOCABULAIRE', 'Vocabulaire métier'
        REGLE = 'REGLE', 'Règle métier'
        ASTUCE = 'ASTUCE', 'Astuce / Bonne pratique'

    titre = models.CharField(
        max_length=255,
        help_text="Titre court et descriptif de la connaissance"
    )
    contenu = models.TextField(
        help_text="Le contenu détaillé de la connaissance. "
                  "Lucy utilisera ce texte pour formuler ses réponses."
    )
    categorie = models.CharField(
        max_length=20,
        choices=Categorie.choices,
        default=Categorie.FAQ,
        help_text="Type de connaissance"
    )
    mots_cles = models.JSONField(
        default=list,
        blank=True,
        help_text="Liste de mots-clés pour le matching (ex: ['facture', 'paiement', 'devis'])"
    )
    pages_cibles = models.JSONField(
        default=list,
        blank=True,
        help_text="URLs des pages où cette connaissance est particulièrement pertinente "
                  "(ex: ['/facture/', '/devis/']). Vide = toutes les pages."
    )
    priorite = models.IntegerField(
        default=0,
        help_text="Plus la priorité est haute, plus cette connaissance sera injectée en premier "
                  "(0 = normale, 10 = très haute)"
    )

    class Meta:
        verbose_name = "Base de connaissances"
        verbose_name_plural = "Base de connaissances"
        ordering = ['-priorite', '-created_date']

    def __str__(self):
        return f"[{self.get_categorie_display()}] {self.titre}"

    @classmethod
    def get_relevant_knowledge(
        cls,
        user_question: str,
        page_url: str = '',
        max_results: int = 8
    ):
        """
        Récupère les connaissances pertinentes pour une question utilisateur.

        Stratégie de matching (par score décroissant):
        1. Connaissances ciblant cette page spécifique
        2. Connaissances dont les mots-clés matchent la question
        3. Connaissances avec haute priorité (catch-all)

        Args:
            user_question: Question de l'utilisateur
            page_url: URL de la page actuelle
            max_results: Nombre max de résultats

        Returns:
            QuerySet de KnowledgeBase triées par pertinence
        """
        from django.db.models import Q, Case, When, IntegerField, Value

        question_lower = user_question.lower()
        question_words = set(question_lower.split())

        # Récupérer toutes les connaissances actives
        all_knowledge = cls.objects.filter(is_active=True)

        if not all_knowledge.exists():
            return cls.objects.none()

        # Scorer chaque connaissance
        scored_knowledge = []

        for kb in all_knowledge:
            score = kb.priorite  # Score de base = priorité

            # Bonus si la page est ciblée
            if page_url and kb.pages_cibles:
                for page_pattern in kb.pages_cibles:
                    if page_pattern in page_url or page_url.startswith(page_pattern):
                        score += 50  # Gros bonus pour ciblage page
                        break

            # Bonus par mot-clé matchant
            if kb.mots_cles:
                matching_keywords = 0
                for keyword in kb.mots_cles:
                    keyword_lower = keyword.lower()
                    if keyword_lower in question_lower:
                        matching_keywords += 1
                    # Vérifier aussi les mots individuels
                    elif any(keyword_lower in word or word in keyword_lower
                             for word in question_words if len(word) > 2):
                        matching_keywords += 0.5

                if matching_keywords > 0:
                    score += matching_keywords * 20

            # Bonus si le titre matche
            titre_lower = kb.titre.lower()
            titre_words = set(titre_lower.split())
            common_words = question_words & titre_words
            significant_common = {w for w in common_words if len(w) > 3}
            if significant_common:
                score += len(significant_common) * 15

            # Bonus si le contenu contient des mots de la question
            contenu_lower = kb.contenu.lower()
            content_matches = sum(
                1 for word in question_words
                if len(word) > 3 and word in contenu_lower
            )
            score += content_matches * 5

            if score > 0:
                scored_knowledge.append((kb.pk, score))

        if not scored_knowledge:
            # Si aucun match, retourner les connaissances à haute priorité
            return all_knowledge.filter(priorite__gte=5).order_by('-priorite')[:max_results]

        # Trier par score décroissant et récupérer les IDs
        scored_knowledge.sort(key=lambda x: x[1], reverse=True)
        top_ids = [pk for pk, _ in scored_knowledge[:max_results]]

        # Récupérer les objets dans l'ordre du score
        preserved_order = Case(
            *[When(pk=pk, then=pos) for pos, pk in enumerate(top_ids)],
            output_field=IntegerField()
        )

        return all_knowledge.filter(pk__in=top_ids).order_by(preserved_order)

    @classmethod
    def format_for_prompt(cls, knowledge_entries) -> str:
        """
        Formate les connaissances pour injection dans le prompt système.

        Args:
            knowledge_entries: QuerySet ou liste de KnowledgeBase

        Returns:
            Texte formaté pour le prompt
        """
        if not knowledge_entries:
            return ""

        sections = []
        for kb in knowledge_entries:
            category_label = kb.get_categorie_display() if hasattr(kb, 'get_categorie_display') else kb.categorie
            sections.append(
                f"### {kb.titre} ({category_label})\n{kb.contenu}"
            )

        return "\n\n".join(sections)
