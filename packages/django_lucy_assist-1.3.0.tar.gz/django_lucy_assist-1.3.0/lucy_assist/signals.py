"""
Signaux pour Lucy Assist
"""
from django.db.models import F
from django.db.models.functions import Greatest
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.cache import cache

from lucy_assist.models import Message, ConfigurationLucyAssist


@receiver(post_save, sender=Message)
def message_post_save(sender, instance, created, **kwargs):
    """
    Signal déclenché après sauvegarde d'un message.
    Décompte les tokens utilisés de la configuration.
    Utilise F() pour éviter les race conditions sur les mises à jour concurrentes.
    """
    if getattr(instance, '_skip_signals', False):
        return

    if created and instance.tokens_utilises > 0:
        # Déduire les tokens via SQL F() pour éviter les race conditions
        updated = ConfigurationLucyAssist.objects.filter(pk=1).update(
            tokens_disponibles=Greatest(F('tokens_disponibles') - instance.tokens_utilises, 0)
        )
        if updated:
            cache.delete('lucy_assist_config')


