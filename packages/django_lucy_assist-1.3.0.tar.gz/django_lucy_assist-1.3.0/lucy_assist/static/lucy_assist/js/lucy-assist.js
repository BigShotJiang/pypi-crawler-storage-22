/**
 * Lucy Assist - Chatbot en vanilla JavaScript
 * Zero dependance externe - pas d'Alpine.js, pas de Font Awesome
 */
(function () {
    'use strict';

    // ========================================================================
    // ETAT
    // ========================================================================
    const state = {
        isOpen: false,
        isExpanded: false,
        isLoading: false,
        showHistory: false,
        showDoc: false,
        hasNewMessage: false,
        hasError: false,
        lucyDidNotUnderstand: false,
        currentMessage: '',
        messages: [],
        conversations: [],
        suggestions: [],
        currentConversationId: null,
        tokensDisponibles: 0,
        buyAmount: 10,
        feedbackDescription: '',
        feedbackSending: false,
    };

    // ========================================================================
    // CONFIG
    // ========================================================================
    const API_BASE = '/lucy-assist/api';
    let csrfToken = '';

    // ========================================================================
    // ELEMENTS DOM
    // ========================================================================
    const el = {};

    function $(id) {
        return document.getElementById(id);
    }

    /** Attache un event listener si l'element existe */
    function on(element, event, handler) {
        if (element) element.addEventListener(event, handler);
    }

    // ========================================================================
    // HELPERS
    // ========================================================================

    function getCookie(name) {
        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? decodeURIComponent(match[2]) : null;
    }

    function formatTokens(tokens) {
        if (tokens >= 1000000) return (tokens / 1000000).toFixed(1) + 'M';
        if (tokens >= 1000) return (tokens / 1000).toFixed(0) + 'K';
        return tokens.toString();
    }

    function formatTokenCost(tokens) {
        return ((tokens / 1000000) * 10).toFixed(4) + '€';
    }

    function formatDate(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;
        if (diff < 60000) return "À l'instant";
        if (diff < 3600000) return 'Il y a ' + Math.floor(diff / 60000) + ' min';
        if (date.toDateString() === now.toDateString())
            return "Aujourd'hui à " + date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
        if (diff < 7 * 86400000)
            return date.toLocaleDateString('fr-FR', { weekday: 'long', hour: '2-digit', minute: '2-digit' });
        return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
    }

    function formatTime(dateString) {
        return new Date(dateString).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    }

    function escapeHtml(s) {
        return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function formatMessage(content) {
        if (!content) return '';
        var f = escapeHtml(content);
        f = f.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        f = f.replace(/\*(.*?)\*/g, '<em>$1</em>');
        f = f.replace(/`(.*?)`/g, '<code style="background:rgba(0,0,0,.1);padding:0 4px;border-radius:3px;">$1</code>');
        f = f.replace(/\[([^\]]+)\]\(([^)]+)\)/g, function(match, text, url) {
            if (/^(https?:\/\/|\/|#)/i.test(url)) {
                return '<a href="' + url + '" target="_blank" style="color:var(--lucy-primary,#6366f1);text-decoration:underline;">' + text + '</a>';
            }
            return text;
        });
        f = f.replace(/\n/g, '<br>');
        return f;
    }

    function checkIfLucyDidNotUnderstand(response) {
        if (!response) return false;
        var lower = response.toLowerCase();
        var patterns = [
            'je ne comprends pas', "je n'ai pas compris", 'pourriez-vous reformuler',
            'pouvez-vous reformuler', 'pourriez-vous préciser', 'pouvez-vous préciser',
            "je ne suis pas sûr de comprendre", "je n'ai pas accès", "je n'ai pas les outils",
            'je ne peux pas', 'je ne suis pas en mesure', 'fonctionnalité non disponible',
            'je ne dispose pas', 'mes outils actuels ne permettent pas', "je n'arrive pas à",
            'impossible de réaliser', 'en dehors de mon périmètre', 'hors de mon champ',
            'dépasse mes capacités', 'comment puis-je vous aider avec votre crm'
        ];
        return patterns.some(function (p) { return lower.includes(p); });
    }

    // ========================================================================
    // API
    // ========================================================================

    async function apiGet(endpoint) {
        var r = await fetch(API_BASE + endpoint, {
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken }
        });
        if (!r.ok) { var e = await r.json(); e.status = r.status; throw e; }
        return r.json();
    }

    async function apiPost(endpoint, data) {
        var r = await fetch(API_BASE + endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken },
            body: JSON.stringify(data)
        });
        if (!r.ok) { var e = await r.json(); e.status = r.status; throw e; }
        return r.json();
    }

    async function apiDelete(endpoint) {
        var r = await fetch(API_BASE + endpoint, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken }
        });
        if (!r.ok) { var e = await r.json(); e.status = r.status; throw e; }
        return r.json();
    }

    // ========================================================================
    // RENDU
    // ========================================================================

    function scrollToBottom() {
        if (el.messages) el.messages.scrollTop = el.messages.scrollHeight;
    }

    function updateTokensDisplay() {
        if (el.tokens) el.tokens.textContent = formatTokens(state.tokensDisponibles);
        if (el.btnBuyCredits) el.btnBuyCredits.style.display = state.tokensDisponibles < 100000 ? '' : 'none';
    }

    function updateExpandIcons() {
        var expand = el.sidebar ? el.sidebar.querySelector('.lucy-icon-expand') : null;
    }

    /** Affiche la bonne vue : chat / history / doc */
    function showView(view) {
        state.showHistory = view === 'history';
        state.showDoc = view === 'doc';

        if (el.viewHistory) el.viewHistory.style.display = state.showHistory ? '' : 'none';
        if (el.viewDoc) el.viewDoc.style.display = state.showDoc ? '' : 'none';
        if (el.viewChat) el.viewChat.style.display = (!state.showHistory && !state.showDoc) ? '' : 'none';

        if (el.btnHistory) el.btnHistory.classList.toggle('active', state.showHistory);
        if (el.btnDoc) el.btnDoc.classList.toggle('active', state.showDoc);
    }

    /** Rend la liste des conversations dans l'historique */
    function renderHistoryList() {
        if (!el.historyList) return;

        if (state.conversations.length === 0) {
            el.historyList.innerHTML = '<p class="lucy-history-empty">Aucune conversation</p>';
            return;
        }

        el.historyList.innerHTML = state.conversations.map(function (conv) {
            return '<div class="lucy-history-item ' + (state.currentConversationId === conv.id ? 'active' : '') + '" data-conv-id="' + conv.id + '">'
                + '<div class="lucy-history-item-title">' + escapeHtml(conv.titre || 'Sans titre') + '</div>'
                + '<div class="lucy-history-item-meta"><span>' + formatDate(conv.created_date) + '</span>'
                + '<span style="margin-left:.5rem">🪙 ' + conv.total_tokens + ' tokens | ' + formatTokenCost(conv.total_tokens) + '</span></div>'
                + '<button class="lucy-btn-delete" data-delete-id="' + conv.id + '">🗑️ Supprimer</button>'
                + '</div>';
        }).join('');

        el.historyList.querySelectorAll('[data-conv-id]').forEach(function (item) {
            item.addEventListener('click', function (e) {
                if (e.target.closest('[data-delete-id]')) return;
                loadConversation(parseInt(item.dataset.convId));
            });
        });
        el.historyList.querySelectorAll('[data-delete-id]').forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                e.stopPropagation();
                deleteConversation(parseInt(btn.dataset.deleteId));
            });
        });
    }

    /** Rend la zone de messages */
    function renderMessages() {
        if (!el.messages) return;

        if (state.messages.length === 0) {
            if (el.welcome) el.welcome.style.display = '';
            if (el.feedbackContact) el.feedbackContact.style.display = 'none';
            if (el.feedbackError) el.feedbackError.style.display = 'none';
            // Supprimer les anciens messages
            el.messages.querySelectorAll('.lucy-message').forEach(function (m) { m.remove(); });
            return;
        }

        if (el.welcome) el.welcome.style.display = 'none';

        // Supprimer les anciens messages
        el.messages.querySelectorAll('.lucy-message').forEach(function (m) { m.remove(); });

        var avatarUrl = el.messages.dataset.avatarUrl || '';
        var lucyIcon = el.messages.dataset.lucyIcon || '';

        state.messages.forEach(function (msg) {
            var isUser = msg.repondant === 'UTILISATEUR';
            var div = document.createElement('div');
            div.className = 'lucy-message ' + (isUser ? 'user' : 'bot');

            var avatarHtml;
            if (isUser) {
                avatarHtml = avatarUrl
                    ? '<img src="' + avatarUrl + '" alt="Utilisateur">'
                    : '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>';
            } else {
                avatarHtml = lucyIcon
                    ? '<img src="' + lucyIcon + '" alt="Lucy">'
                    : '🤖';
            }

            var bubbleContent = msg.contenu
                ? '<span>' + formatMessage(msg.contenu) + '</span>'
                : '<span class="lucy-loading-dots"><span></span><span></span><span></span></span>';

            div.innerHTML = '<div class="lucy-message-avatar">' + avatarHtml + '</div>'
                + '<div class="lucy-message-content">'
                + '<div class="lucy-message-bubble">' + bubbleContent + '</div>'
                + '<div class="lucy-message-time">' + formatTime(msg.created_date) + '</div>'
                + '</div>';

            el.messages.appendChild(div);
        });

        // Feedback bars
        if (el.feedbackContact) el.feedbackContact.style.display = (state.lucyDidNotUnderstand && state.messages.length > 0) ? '' : 'none';
        if (el.feedbackError) el.feedbackError.style.display = (state.hasError && !state.lucyDidNotUnderstand && state.messages.length > 0) ? '' : 'none';

        requestAnimationFrame(scrollToBottom);
    }

    /** Rend les suggestions */
    function renderSuggestions() {
        if (!el.suggestions) return;
        el.suggestions.innerHTML = state.suggestions.map(function (s) {
            return '<button class="lucy-suggestion-btn" data-suggestion="' + escapeHtml(s) + '">'
                + '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="flex-shrink:0;color:#f59e0b"><path stroke-linecap="round" stroke-linejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>'
                + '<span>' + escapeHtml(s) + '</span></button>';
        }).join('');

        el.suggestions.querySelectorAll('[data-suggestion]').forEach(function (btn) {
            btn.addEventListener('click', function () { sendMessage(btn.dataset.suggestion); });
        });
    }

    function updateBuyModal() {
        var tokens = Math.floor((state.buyAmount / 10) * 1000000);
        if (el.buyTokens) el.buyTokens.textContent = formatTokens(tokens);
        if (el.buyConvs) el.buyConvs.textContent = Math.floor(tokens / 2000).toString();
    }

    function updateSendBtn() {
        if (el.btnSend) el.btnSend.disabled = state.isLoading || !(el.input && el.input.value.trim());
    }

    // ========================================================================
    // ACTIONS
    // ========================================================================

    function openSidebar() {
        state.isOpen = true;
        state.hasNewMessage = false;
        if (el.floatBtn) el.floatBtn.style.display = 'none';
        if (el.sidebar) {
            // 1) Rendre visible mais hors-ecran (classe hidden = translateX(100%))
            el.sidebar.style.display = '';
            // 2) Forcer un reflow pour que le navigateur prenne en compte le display
            el.sidebar.offsetHeight; // eslint-disable-line no-unused-expressions
            // 3) Retirer hidden pour declencher la transition CSS
            el.sidebar.classList.remove('hidden');
        }
        saveState();
        setTimeout(function () { if (el.input) el.input.focus(); }, 300);
    }

    function closeSidebar() {
        state.isOpen = false;
        state.showHistory = false;
        state.showDoc = false;
        if (el.sidebar) {
            el.sidebar.classList.add('hidden');
            // Attendre la fin de la transition avant de masquer
            setTimeout(function () {
                if (!state.isOpen && el.sidebar) el.sidebar.style.display = 'none';
            }, 350);
        }
        if (el.floatBtn) el.floatBtn.style.display = '';
        showView('chat');
        saveState();
    }

    function toggleSidebar() {
        state.isOpen ? closeSidebar() : openSidebar();
    }

    function toggleExpanded() {
        state.isExpanded = !state.isExpanded;
        if (el.sidebar) el.sidebar.classList.toggle('expanded', state.isExpanded);
        updateExpandIcons();
        saveState();
    }

    async function loadTokenStatus() {
        try {
            var r = await apiGet('/tokens/status');
            state.tokensDisponibles = r.tokens_disponibles || 0;
            updateTokensDisplay();
        } catch (e) { console.error('Lucy: erreur tokens', e); }
    }

    async function loadConversations() {
        try {
            var r = await apiGet('/conversations');
            state.conversations = r.conversations || [];
            renderHistoryList();
        } catch (e) { console.error('Lucy: erreur conversations', e); }
    }

    async function loadSuggestions() {
        try {
            var r = await apiGet('/suggestions');
            state.suggestions = r.suggestions || [];
        } catch (e) {
            state.suggestions = [
                'Comment créer un nouveau membre ?',
                'Comment effectuer un paiement ?',
                'Où trouver la liste des adhésions ?'
            ];
        }
        renderSuggestions();
    }

    async function newConversation() {
        try {
            var r = await apiPost('/conversations', { page_contexte: window.location.pathname });
            state.currentConversationId = r.id;
            state.messages = [];
            showView('chat');
            renderMessages();
            saveState();
            await loadConversations();
        } catch (e) { console.error('Lucy: erreur new conversation', e); }
    }

    async function loadConversation(id) {
        try {
            var r = await apiGet('/conversations/' + id);
            state.currentConversationId = id;
            state.messages = r.messages || [];
            showView('chat');
            renderMessages();
            saveState();
            setTimeout(scrollToBottom, 100);
        } catch (e) {
            console.error('Lucy: erreur load conversation', e);
            state.currentConversationId = null;
            state.messages = [];
            renderMessages();
            saveState();
        }
    }

    async function deleteConversation(id) {
        if (!confirm('Êtes-vous sûr de vouloir supprimer cette conversation ?')) return;
        try {
            await apiDelete('/conversations/' + id);
            await loadConversations();
            if (state.currentConversationId === id) {
                state.currentConversationId = null;
                state.messages = [];
                renderMessages();
            }
        } catch (e) { console.error('Lucy: erreur suppression', e); }
    }

    async function sendMessage(message) {
        if (state.isLoading || !message || !message.trim()) return;

        state.lucyDidNotUnderstand = false;

        if (!state.currentConversationId) await newConversation();

        // Message utilisateur
        state.messages.push({
            id: Date.now(),
            repondant: 'UTILISATEUR',
            contenu: message,
            created_date: new Date().toISOString(),
            tokens_utilises: 0
        });
        state.currentMessage = '';
        if (el.input) {
            el.input.value = '';
            el.input.style.height = 'auto';
        }
        updateSendBtn();
        renderMessages();

        try {
            state.isLoading = true;
            if (el.input) el.input.disabled = true;
            if (el.btnSend) el.btnSend.disabled = true;

            await apiPost('/conversations/' + state.currentConversationId + '/messages', { contenu: message });
            await streamChatCompletion();
        } catch (e) {
            console.error('Lucy: erreur envoi', e);
            if (e.status === 402) {
                showModal('buy');
            } else {
                state.hasError = true;
                renderMessages();
            }
        } finally {
            state.isLoading = false;
            if (el.input) el.input.disabled = false;
            updateSendBtn();
            if (el.input) el.input.focus();
        }
    }

    async function streamChatCompletion() {
        var url = API_BASE + '/conversations/' + state.currentConversationId + '/chat';
        var botIdx = state.messages.length;

        state.messages.push({
            id: Date.now() + 1,
            repondant: 'CHATBOT',
            contenu: '',
            created_date: new Date().toISOString(),
            tokens_utilises: 0
        });
        renderMessages();

        try {
            var response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken },
                body: JSON.stringify({ page_contexte: window.location.pathname })
            });

            if (!response.ok) { var err = await response.json(); err.status = response.status; throw err; }

            var reader = response.body.getReader();
            var decoder = new TextDecoder();
            var fullContent = '';

            while (true) {
                var result = await reader.read();
                if (result.done) break;

                var text = decoder.decode(result.value);
                var lines = text.split('\n');

                for (var i = 0; i < lines.length; i++) {
                    var line = lines[i];
                    if (!line.startsWith('data: ')) continue;
                    try {
                        var data = JSON.parse(line.slice(6));
                        if (data.type === 'content') {
                            fullContent += data.content;
                            state.messages[botIdx].contenu = fullContent;
                            renderMessages();
                        } else if (data.type === 'done') {
                            state.messages[botIdx].id = data.message_id;
                            state.messages[botIdx].tokens_utilises = data.tokens_utilises;
                            await loadTokenStatus();
                        } else if (data.type === 'error') {
                            throw new Error(data.error);
                        }
                    } catch (parseErr) { if (parseErr.message) throw parseErr; }
                }
            }

            if (!state.messages[botIdx] || !state.messages[botIdx].contenu) {
                state.messages.splice(botIdx, 1);
            }

            state.lucyDidNotUnderstand = checkIfLucyDidNotUnderstand(
                (state.messages[botIdx] && state.messages[botIdx].contenu) || ''
            );
            if (!state.lucyDidNotUnderstand) state.hasError = false;

            renderMessages();
            await loadConversations();
        } catch (e) {
            state.hasError = true;
            if (botIdx < state.messages.length && state.messages[botIdx] && !state.messages[botIdx].contenu) {
                state.messages.splice(botIdx, 1);
            }
            renderMessages();
            throw e;
        }
    }

    async function sendFeedback() {
        if (!state.currentConversationId) return;
        state.feedbackSending = true;
        try {
            await apiPost('/feedback', {
                conversation_id: state.currentConversationId,
                description: state.feedbackDescription,
                page_url: window.location.href
            });
            state.hasError = false;
            state.lucyDidNotUnderstand = false;
            hideModal('feedback');
            renderMessages();
        } catch (e) { console.error('Lucy: erreur feedback', e); }
        finally { state.feedbackSending = false; }
    }

    async function buyCredits() {
        if (state.buyAmount < 10) return;
        try {
            var r = await apiPost('/tokens/buy', { montant_ht: state.buyAmount });
            window.open(r.url_souscription, '_blank');
            hideModal('buy');
        } catch (e) { console.error('Lucy: erreur achat', e); }
    }

    // ========================================================================
    // MODALS
    // ========================================================================

    function showModal(name) {
        if (name === 'buy' && el.modalBuy) {
            el.modalBuy.style.display = '';
            updateBuyModal();
        } else if (name === 'feedback' && el.modalFeedback) {
            el.modalFeedback.style.display = '';
            state.feedbackDescription = '';
            if (el.feedbackDesc) el.feedbackDesc.value = '';
        }
    }

    function hideModal(name) {
        if (name === 'buy' && el.modalBuy) el.modalBuy.style.display = 'none';
        else if (name === 'feedback' && el.modalFeedback) el.modalFeedback.style.display = 'none';
    }

    // ========================================================================
    // STATE PERSISTENCE
    // ========================================================================

    function saveState() {
        try {
            sessionStorage.setItem('lucy_assist_state', JSON.stringify({
                isOpen: state.isOpen,
                isExpanded: state.isExpanded,
                currentConversationId: state.currentConversationId,
                showHistory: state.showHistory,
                showDoc: state.showDoc
            }));
        } catch (e) {}
    }

    function restoreState() {
        try {
            var s = JSON.parse(sessionStorage.getItem('lucy_assist_state'));
            if (!s) return;
            state.isOpen = s.isOpen || false;
            state.isExpanded = s.isExpanded || false;
            state.currentConversationId = s.currentConversationId || null;
            state.showHistory = s.showHistory || false;
            state.showDoc = s.showDoc || false;
        } catch (e) {}
    }

    // ========================================================================
    // INIT
    // ========================================================================

    function init() {
        console.log('Lucy Assist: init');

        // Cache des elements - tous optionnels
        el.floatBtn = $('lucy-float-btn');
        el.sidebar = $('lucy-sidebar');
        el.tokens = $('lucy-tokens');
        el.btnBuyCredits = $('lucy-btn-buy-credits');
        el.btnExpand = $('lucy-btn-expand');
        el.btnHistory = $('lucy-btn-history');
        el.btnNew = $('lucy-btn-new');
        el.btnDoc = $('lucy-btn-doc');
        el.btnClose = $('lucy-btn-close');
        el.btnSend = $('lucy-btn-send');
        el.input = $('lucy-input');
        el.messages = $('lucy-messages');
        el.welcome = $('lucy-welcome');
        el.suggestions = $('lucy-suggestions');
        el.viewHistory = $('lucy-view-history');
        el.viewDoc = $('lucy-view-doc');
        el.viewChat = $('lucy-view-chat');
        el.historyList = $('lucy-history-list');
        el.feedbackContact = $('lucy-feedback-contact');
        el.feedbackError = $('lucy-feedback-error');
        el.modalBuy = $('lucy-modal-buy');
        el.modalFeedback = $('lucy-modal-feedback');
        el.buyAmount = $('lucy-buy-amount');
        el.buyTokens = $('lucy-buy-tokens');
        el.buyConvs = $('lucy-buy-convs');
        el.buyCancel = $('lucy-buy-cancel');
        el.buyConfirm = $('lucy-buy-confirm');
        el.feedbackDesc = $('lucy-feedback-desc');
        el.feedbackCancel = $('lucy-feedback-cancel');
        el.feedbackConfirm = $('lucy-feedback-confirm');
        // Verifier que le root existe
        if (!el.floatBtn && !el.sidebar) {
            console.warn('Lucy Assist: elements DOM introuvables, abort.');
            return;
        }

        console.log('Lucy Assist: elements trouves, floatBtn=' + !!el.floatBtn + ', sidebar=' + !!el.sidebar);

        // CSRF
        var csrfEl = document.querySelector('[name=csrfmiddlewaretoken]');
        csrfToken = (csrfEl && csrfEl.value) || getCookie('csrftoken') || '';

        // Restaurer l'etat
        restoreState();

        // Appliquer l'etat initial
        if (state.isOpen) {
            if (el.floatBtn) el.floatBtn.style.display = 'none';
            if (el.sidebar) {
                el.sidebar.style.display = '';
                el.sidebar.classList.remove('hidden');
            }
        }
        if (state.isExpanded && el.sidebar) {
            el.sidebar.classList.add('expanded');
        }
        updateExpandIcons();

        if (state.showHistory) showView('history');
        else if (state.showDoc) showView('doc');
        else showView('chat');

        // ---- EVENT LISTENERS (tous avec null-safety via on()) ----
        on(el.floatBtn, 'click', toggleSidebar);
        on(el.btnExpand, 'click', toggleExpanded);
        on(el.btnHistory, 'click', function () { showView(state.showHistory ? 'chat' : 'history'); });
        on(el.btnNew, 'click', newConversation);
        on(el.btnDoc, 'click', function () { showView(state.showDoc ? 'chat' : 'doc'); });
        on(el.btnClose, 'click', closeSidebar);

        function onInputChange() {
            if (!el.input) return;
            state.currentMessage = el.input.value;
            el.input.style.height = 'auto';
            el.input.style.height = Math.min(el.input.scrollHeight, 128) + 'px';
            updateSendBtn();
        }
        on(el.input, 'input', onInputChange);
        on(el.input, 'keyup', onInputChange);
        on(el.input, 'change', onInputChange);
        on(el.input, 'keydown', function (e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                sendMessage(el.input.value);
            }
            // Mettre a jour le bouton sur la prochaine frame
            setTimeout(updateSendBtn, 0);
        });

        on(el.btnSend, 'click', function () { sendMessage(el.input ? el.input.value : ''); });

        on($('lucy-btn-feedback-contact'), 'click', function () { showModal('feedback'); });
        on($('lucy-btn-feedback-error'), 'click', function () { showModal('feedback'); });

        on(el.btnBuyCredits, 'click', function () { showModal('buy'); });
        on(el.buyCancel, 'click', function () { hideModal('buy'); });
        on(el.buyConfirm, 'click', buyCredits);
        on(el.buyAmount, 'input', function () {
            state.buyAmount = parseInt(el.buyAmount.value) || 10;
            updateBuyModal();
        });

        on(el.feedbackCancel, 'click', function () { hideModal('feedback'); });
        on(el.feedbackConfirm, 'click', sendFeedback);
        on(el.feedbackDesc, 'input', function () {
            state.feedbackDescription = el.feedbackDesc.value;
        });

        // Raccourcis clavier globaux
        document.addEventListener('keydown', function (e) {
            if (e.ctrlKey && e.key === 'k') { e.preventDefault(); toggleSidebar(); }
            if (e.key === 'Escape' && state.isOpen) closeSidebar();
        });

        window.addEventListener('beforeunload', saveState);

        // Charger les donnees
        loadTokenStatus();
        loadConversations().then(function () {
            if (state.currentConversationId) loadConversation(state.currentConversationId);
        });
        loadSuggestions();

        console.log('Lucy Assist: init complete');
    }

    // Lancer quand le DOM est pret
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
