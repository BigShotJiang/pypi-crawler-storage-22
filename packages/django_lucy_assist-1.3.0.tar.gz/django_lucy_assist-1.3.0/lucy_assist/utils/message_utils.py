"""
Utilitaires pour le formatage des messages Lucy Assist.
Sans impact sur la base de données.
"""
import re
from typing import List, Dict


class MessageUtils:
    """Utilitaires de formatage et transformation des messages."""

    @staticmethod
    def tronquer_texte(texte: str, max_length: int = 50, suffix: str = "...") -> str:
        """
        Tronque un texte à une longueur maximale.

        Args:
            texte: Texte à tronquer
            max_length: Longueur maximale
            suffix: Suffixe à ajouter si tronqué

        Returns:
            Texte tronqué
        """
        if not texte:
            return ""
        if len(texte) <= max_length:
            return texte
        return texte[:max_length - len(suffix)] + suffix

    @staticmethod
    def formater_messages_pour_claude(messages: List) -> List[Dict]:
        """
        Formate les messages pour l'API Claude.

        Args:
            messages: Liste de messages (objets Message)

        Returns:
            Liste de dicts formatés pour Claude
        """
        from lucy_assist.constantes import LucyAssistConstantes

        formatted = []
        for msg in messages:
            role = "user" if msg.repondant == LucyAssistConstantes.Repondant.UTILISATEUR else "assistant"
            formatted.append({
                "role": role,
                "content": msg.contenu
            })
        return formatted

    @staticmethod
    def extraire_json_de_reponse(texte: str) -> dict:
        """
        Extrait un objet JSON d'une réponse texte.
        Supporte le JSON imbriqué.

        Args:
            texte: Texte contenant potentiellement du JSON

        Returns:
            Dict extrait ou dict vide
        """
        import json

        try:
            start = texte.find('{')
            if start >= 0:
                for end in range(len(texte), start, -1):
                    try:
                        return json.loads(texte[start:end])
                    except json.JSONDecodeError:
                        continue
        except (ValueError, AttributeError):
            pass

        return {}

    @staticmethod
    def nettoyer_message(message: str) -> str:
        """
        Nettoie un message utilisateur.

        Args:
            message: Message brut

        Returns:
            Message nettoyé
        """
        if not message:
            return ""

        # Supprimer les espaces multiples
        message = re.sub(r'\s+', ' ', message)

        # Trim
        message = message.strip()

        return message

    @staticmethod
    def markdown_to_html_basic(texte: str) -> str:
        """
        Conversion basique de Markdown vers HTML.

        Args:
            texte: Texte en markdown

        Returns:
            Texte en HTML
        """
        if not texte:
            return ""

        # Échapper le HTML
        texte = texte.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

        # Gras
        texte = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', texte)

        # Italique
        texte = re.sub(r'\*(.*?)\*', r'<em>\1</em>', texte)

        # Code inline
        texte = re.sub(r'`(.*?)`', r'<code>\1</code>', texte)

        # Liens
        texte = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2" target="_blank">\1</a>', texte)

        # Sauts de ligne
        texte = texte.replace('\n', '<br>')

        return texte

    @staticmethod
    def remove_emojis(texte: str) -> str:
        """
        Supprime les emojis et caractères 4-bytes incompatibles avec MySQL utf8.
        Cible uniquement les vrais emojis sans affecter les symboles techniques
        (box-drawing, mathématiques, flèches, etc.).

        Args:
            texte: Texte contenant potentiellement des emojis

        Returns:
            Texte sans emojis
        """
        if not texte:
            return ""

        # Pattern ciblant uniquement les vrais emojis (plans Unicode supplémentaires)
        emoji_pattern = re.compile(
            "["
            "\U0001F600-\U0001F64F"  # emoticons (smileys)
            "\U0001F300-\U0001F5FF"  # symbols & pictographs
            "\U0001F680-\U0001F6FF"  # transport & map symbols
            "\U0001F700-\U0001F77F"  # alchemical symbols
            "\U0001F780-\U0001F7FF"  # geometric shapes extended
            "\U0001F800-\U0001F8FF"  # supplemental arrows-C
            "\U0001F900-\U0001F9FF"  # supplemental symbols & pictographs
            "\U0001FA00-\U0001FA6F"  # chess symbols
            "\U0001FA70-\U0001FAFF"  # symbols & pictographs extended-A
            "\U0001F1E0-\U0001F1FF"  # flags (regional indicators)
            "\u200d"                  # zero width joiner (emoji sequences)
            "\ufe0f"                  # variation selector-16 (emoji presentation)
            "]+",
            re.UNICODE
        )
        return emoji_pattern.sub('', texte)
