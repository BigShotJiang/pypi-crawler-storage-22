import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='ConfigurationLucyAssist',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('updated_date', models.DateTimeField(auto_now=True, null=True)),
                ('is_active', models.BooleanField(default=True)),
                ('tokens_disponibles', models.BigIntegerField(default=0)),
                ('prix_par_million_tokens', models.DecimalField(decimal_places=2, default=50.0, max_digits=10)),
                ('questions_frequentes', models.JSONField(blank=True, default=list)),
                ('actif', models.BooleanField(default=True)),
                ('avatar', models.ImageField(blank=True, null=True, upload_to='')),
                ('description_metier', models.TextField(blank=True, default='', help_text="Description de l'activité et du métier du client. Ex: 'Hôtel 4 étoiles à Lyon, 120 chambres, gestion des réservations, événements MICE, restauration.' Lucy utilisera cette description pour adapter son vocabulaire et comprendre le contexte métier.")),
                ('instructions_complementaires', models.TextField(blank=True, default='', help_text="Instructions supplémentaires pour personnaliser le comportement de Lucy. Ex: 'Toujours proposer de vérifier la disponibilité avant de créer une réservation.' Ces instructions seront ajoutées au prompt système.")),
                ('system_prompt', models.TextField(blank=True, default='')),
                ('model_app_mapping', models.JSONField(blank=True, default=dict)),
                ('crud_views_mapping', models.JSONField(blank=True, default=dict)),
            ],
            options={
                'verbose_name': 'Configuration Lucy Assist',
                'verbose_name_plural': 'Configuration Lucy Assist',
            },
        ),
        migrations.CreateModel(
            name='KnowledgeBase',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('updated_date', models.DateTimeField(auto_now=True, null=True)),
                ('is_active', models.BooleanField(default=True)),
                ('titre', models.CharField(help_text='Titre court et descriptif de la connaissance', max_length=255)),
                ('contenu', models.TextField(help_text='Le contenu détaillé de la connaissance. Lucy utilisera ce texte pour formuler ses réponses.')),
                ('categorie', models.CharField(choices=[('FAQ', 'Question fréquente'), ('PROCESS', 'Processus métier'), ('AIDE', 'Aide contextuelle'), ('VOCABULAIRE', 'Vocabulaire métier'), ('REGLE', 'Règle métier'), ('ASTUCE', 'Astuce / Bonne pratique')], default='FAQ', help_text='Type de connaissance', max_length=20)),
                ('mots_cles', models.JSONField(blank=True, default=list, help_text="Liste de mots-clés pour le matching (ex: ['facture', 'paiement', 'devis'])")),
                ('pages_cibles', models.JSONField(blank=True, default=list, help_text="URLs des pages où cette connaissance est particulièrement pertinente (ex: ['/facture/', '/devis/']). Vide = toutes les pages.")),
                ('priorite', models.IntegerField(default=0, help_text='Plus la priorité est haute, plus cette connaissance sera injectée en premier (0 = normale, 10 = très haute)')),
            ],
            options={
                'verbose_name': 'Base de connaissances',
                'verbose_name_plural': 'Base de connaissances',
                'ordering': ['-priorite', '-created_date'],
            },
        ),
        migrations.CreateModel(
            name='ProjectContextCache',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('updated_date', models.DateTimeField(auto_now=True, null=True)),
                ('is_active', models.BooleanField(default=True)),
                ('cache_key', models.CharField(db_index=True, max_length=255, unique=True)),
                ('contenu', models.JSONField(default=dict)),
                ('content_hash', models.CharField(blank=True, max_length=64)),
                ('expire_at', models.DateTimeField()),
                ('tokens_economises', models.BigIntegerField(default=0)),
                ('hit_count', models.IntegerField(default=0)),
            ],
            options={
                'verbose_name': 'Cache contexte projet',
                'verbose_name_plural': 'Caches contexte projet',
            },
        ),
        migrations.CreateModel(
            name='Conversation',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('updated_date', models.DateTimeField(auto_now=True, null=True)),
                ('is_active', models.BooleanField(default=True)),
                ('titre', models.CharField(blank=True, max_length=255, null=True)),
                ('page_contexte', models.CharField(blank=True, max_length=500, null=True)),
                ('utilisateur', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='lucy_assist_conversations', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'Conversation Lucy Assist',
                'verbose_name_plural': 'Conversations Lucy Assist',
                'ordering': ['-created_date'],
            },
        ),
        migrations.CreateModel(
            name='Message',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_date', models.DateTimeField(auto_now_add=True)),
                ('updated_date', models.DateTimeField(auto_now=True, null=True)),
                ('is_active', models.BooleanField(default=True)),
                ('repondant', models.CharField(choices=[('UTILISATEUR', 'Utilisateur'), ('CHATBOT', 'Lucy Assist')], max_length=20)),
                ('contenu', models.TextField()),
                ('tokens_utilises', models.IntegerField(default=0)),
                ('type_action', models.CharField(blank=True, choices=[('AIDE_NAVIGATION', 'Aide à la navigation'), ('RECHERCHE', "Recherche d'objets"), ('CRUD', "Création/Modification/Suppresion d'objets"), ('ANALYSE_BUG', 'Analyse de bug'), ('EXPLICATION', 'Explication de fonctionnalité')], max_length=50, null=True)),
                ('metadata', models.JSONField(blank=True, default=dict)),
                ('conversation', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='messages', to='lucy_assist.conversation')),
            ],
            options={
                'verbose_name': 'Message Lucy Assist',
                'verbose_name_plural': 'Messages Lucy Assist',
                'ordering': ['created_date'],
            },
        ),
    ]
