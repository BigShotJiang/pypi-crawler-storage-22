"""
Service de découverte automatique des vues CRUD du projet.

Parcourt les URL patterns Django pour identifier les vues CRUD
et construire un mapping utilisable par Lucy Assist.
"""
import re
from typing import Dict, List, Optional, Tuple
from django.urls import URLPattern, URLResolver, get_resolver
from django.urls.resolvers import RoutePattern

from lucy_assist.utils.log_utils import LogUtils
from lucy_assist.conf import lucy_assist_settings


class ViewDiscoveryService:
    """
    Service pour découvrir automatiquement les vues CRUD d'un projet Django.

    La découverte est mise en cache en mémoire pour éviter de scanner
    les URLs à chaque requête.
    """

    # Cache en mémoire pour les vues découvertes (partagé entre instances)
    _views_cache = None
    _cache_timestamp = None
    CACHE_TTL = 300  # 5 minutes

    # Patterns de nommage courants pour les vues CRUD
    # Supporte suffixes (client-list), préfixes (creation-client) et mots-clés (fallback)
    CRUD_PATTERNS = {
        'list': {
            'suffix': [r'-list$', r'-liste$', r'-gestion$', r'-index$', r'_list$', r'_liste$', r'_gestion$', r'_index$'],
            'prefix': [r'^list-', r'^liste-', r'^gestion-', r'^index-'],
            'keywords': ['list', 'liste', 'gestion', 'index'],
        },
        'create': {
            'suffix': [r'-create$', r'-add$', r'-nouveau$', r'-new$', r'-creation$', r'_create$', r'_add$', r'_creation$'],
            'prefix': [r'^create-', r'^creation-', r'^add-', r'^nouveau-', r'^new-', r'^ajout-'],
            'keywords': ['create', 'creation', 'add', 'nouveau', 'new', 'ajout'],
        },
        'detail': {
            'suffix': [r'-detail$', r'-view$', r'-show$', r'-fiche$', r'-consulter$', r'-consultation$', r'_detail$', r'_fiche$', r'_consultation$'],
            'prefix': [r'^detail-', r'^fiche-', r'^consultation-', r'^consulter-', r'^view-', r'^show-'],
            'keywords': ['detail', 'fiche', 'consultation', 'consulter', 'view', 'show'],
        },
        'update': {
            'suffix': [r'-update$', r'-edit$', r'-modifier$', r'-modification$', r'-edition$', r'_update$', r'_edit$', r'_modification$', r'_edition$'],
            'prefix': [r'^update-', r'^edit-', r'^modifier-', r'^modification-', r'^edition-'],
            'keywords': ['update', 'edit', 'modifier', 'modification', 'edition'],
        },
        'delete': {
            'suffix': [r'-delete$', r'-suppression$', r'-supprimer$', r'-remove$', r'_delete$', r'_suppression$'],
            'prefix': [r'^delete-', r'^suppression-', r'^supprimer-', r'^remove-'],
            'keywords': ['delete', 'suppression', 'supprimer', 'remove'],
        },
        'formulaire': {
            'suffix': [r'-formulaire$', r'-form$', r'_formulaire$', r'_form$'],
            'prefix': [r'^formulaire-', r'^form-'],
            'keywords': ['formulaire', 'form'],
        },
    }

    # Patterns d'URL pour détecter les paramètres
    URL_PARAM_PATTERNS = [
        (r'<int:pk>', 'pk'),
        (r'<pk>', 'pk'),
        (r'<int:id>', 'id'),
        (r'<id>', 'id'),
        (r'<slug:slug>', 'slug'),
    ]

    def __init__(self):
        self.apps_prefix = lucy_assist_settings.PROJECT_APPS_PREFIX or ''

    @classmethod
    def get_cached_views(cls) -> Dict:
        """
        Retourne les vues CRUD depuis le cache mémoire.
        Redécouvre automatiquement si le cache est expiré.
        """
        import time

        now = time.time()

        # Vérifier si le cache est valide
        if (cls._views_cache is not None and
            cls._cache_timestamp is not None and
            now - cls._cache_timestamp < cls.CACHE_TTL):
            return cls._views_cache

        # Redécouvrir les vues
        service = cls()
        cls._views_cache = service.discover_crud_views()
        cls._cache_timestamp = now

        return cls._views_cache

    @classmethod
    def invalidate_cache(cls):
        """Force la redécouverte des vues au prochain appel."""
        cls._views_cache = None
        cls._cache_timestamp = None

    def discover_crud_views(self) -> Dict:
        """
        Découvre toutes les vues CRUD du projet.

        Returns:
            Dict avec le mapping modèle -> actions -> infos vue
        """
        LogUtils.info("[ViewDiscovery] Début de la découverte des vues CRUD")

        crud_mapping = {}
        resolver = get_resolver()

        # Parcourir tous les URL patterns
        self._scan_url_patterns(resolver.url_patterns, '', '', crud_mapping)

        LogUtils.info(f"[ViewDiscovery] {len(crud_mapping)} modèles découverts")
        for model, actions in crud_mapping.items():
            LogUtils.info(f"[ViewDiscovery] {model}: {list(actions.keys())}")

        return crud_mapping

    def _scan_url_patterns(
        self,
        patterns: List,
        namespace: str,
        url_prefix: str,
        crud_mapping: Dict
    ):
        """
        Parcourt récursivement les URL patterns.
        """
        for pattern in patterns:
            if isinstance(pattern, URLResolver):
                # C'est un include() - descendre récursivement
                new_namespace = pattern.namespace
                if namespace and new_namespace:
                    new_namespace = f"{namespace}:{new_namespace}"
                elif namespace:
                    new_namespace = namespace

                # Construire le préfixe URL
                pattern_str = self._get_pattern_string(pattern.pattern)
                new_url_prefix = url_prefix + pattern_str

                # Filtrer les apps Django internes et admin
                app_name = getattr(pattern, 'app_name', '') or ''
                skip_prefixes = ['django.', 'lucy_assist', 'admin']
                if app_name and any(app_name.startswith(p) for p in skip_prefixes):
                    continue
                if new_namespace and any(new_namespace.startswith(p) for p in ['admin', 'lucy_assist']):
                    continue

                self._scan_url_patterns(
                    pattern.url_patterns,
                    new_namespace or '',
                    new_url_prefix,
                    crud_mapping
                )

            elif isinstance(pattern, URLPattern):
                # C'est une vue finale
                self._process_url_pattern(
                    pattern,
                    namespace,
                    url_prefix,
                    crud_mapping
                )

    def _process_url_pattern(
        self,
        pattern: URLPattern,
        namespace: str,
        url_prefix: str,
        crud_mapping: Dict
    ):
        """
        Analyse un URL pattern pour détecter s'il s'agit d'une vue CRUD.
        """
        url_name = pattern.name
        if not url_name:
            return

        # Construire l'URL complète
        pattern_str = self._get_pattern_string(pattern.pattern)
        full_url = '/' + url_prefix + pattern_str
        full_url = re.sub(r'/+', '/', full_url)  # Normaliser les slashes

        # Construire le nom complet de la vue
        full_name = f"{namespace}:{url_name}" if namespace else url_name

        # Détecter le modèle et l'action depuis le nom de l'URL
        model_name, action = self._detect_model_and_action(url_name)

        if not model_name or not action:
            LogUtils.debug(f"[ViewDiscovery] Pattern non reconnu comme CRUD: {full_name} ({full_url})")
            return

        # Détecter si l'URL nécessite un paramètre (pk, id, etc.)
        requires_pk = self._url_requires_pk(full_url)

        # Déterminer la méthode HTTP
        http_method = self._detect_http_method(pattern, action)

        # Ajouter au mapping
        model_lower = model_name.lower()
        if model_lower not in crud_mapping:
            crud_mapping[model_lower] = {}

        # Les vues "formulaire" gèrent généralement create ET update
        if action == 'formulaire':
            crud_mapping[model_lower]['create'] = {
                'url_name': full_name,
                'url': full_url,
                'method': 'POST',
                'requires_pk': False
            }
            crud_mapping[model_lower]['update'] = {
                'url_name': full_name,
                'url': full_url,
                'method': 'POST',
                'requires_pk': True  # pk passé en POST ou GET
            }
            return

        # Pour les autres actions create/update
        if action == 'create' and requires_pk:
            # C'est probablement une vue qui gère create et update
            action = 'update'

        crud_mapping[model_lower][action] = {
            'url_name': full_name,
            'url': full_url,
            'method': http_method,
            'requires_pk': requires_pk
        }

    def _detect_model_and_action(self, url_name: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Détecte le nom du modèle et l'action CRUD depuis le nom de l'URL.

        Stratégie en 3 étapes :
        1. Suffixes (client-list, reservation-formulaire)
        2. Préfixes (creation-filtre-dispache, liste-membre)
        3. Mots-clés dans les parties splitées (fallback)

        Args:
            url_name: Nom de l'URL (ex: 'client-list', 'creation-filtre-dispache')

        Returns:
            Tuple (model_name, action) ou (None, None)
        """
        url_name_lower = url_name.lower()

        detected_action = None
        model_name = None

        # Étape 1 : Chercher par suffixe (ancien comportement)
        for action, config in self.CRUD_PATTERNS.items():
            for pattern in config['suffix']:
                if re.search(pattern, url_name_lower):
                    detected_action = action
                    model_name = re.sub(pattern, '', url_name_lower).strip('-_')
                    break
            if detected_action:
                break

        # Étape 2 : Chercher par préfixe (ex: creation-filtre-dispache)
        if not detected_action:
            for action, config in self.CRUD_PATTERNS.items():
                for pattern in config['prefix']:
                    if re.search(pattern, url_name_lower):
                        detected_action = action
                        model_name = re.sub(pattern, '', url_name_lower).strip('-_')
                        break
                if detected_action:
                    break

        # Étape 3 : Chercher par mots-clés dans les parties splitées (fallback)
        if not detected_action:
            parts = re.split(r'[-_]', url_name_lower)
            for action, config in self.CRUD_PATTERNS.items():
                for keyword in config['keywords']:
                    if keyword in parts:
                        detected_action = action
                        remaining = [p for p in parts if p != keyword]
                        model_name = '_'.join(remaining)
                        break
                if detected_action:
                    break

        if not detected_action or not model_name:
            return None, None

        # Normaliser le nom du modèle : tirets → underscores
        model_name_normalized = model_name.replace('-', '_')

        return model_name_normalized, detected_action

    def _get_pattern_string(self, pattern) -> str:
        """
        Extrait la chaîne de pattern depuis un RoutePattern ou RegexPattern.
        """
        if hasattr(pattern, '_route'):
            return pattern._route
        elif hasattr(pattern, '_regex'):
            # Convertir le regex en quelque chose de lisible
            regex = pattern._regex
            # Simplifier les captures
            regex = re.sub(r'\(\?P<(\w+)>[^)]+\)', r'<\1>', regex)
            regex = regex.strip('^$')
            return regex
        return ''

    def _url_requires_pk(self, url: str) -> bool:
        """
        Vérifie si l'URL nécessite un paramètre pk/id.
        """
        pk_patterns = ['<pk>', '<int:pk>', '<id>', '<int:id>', '<slug>']
        return any(p in url for p in pk_patterns)

    def _detect_http_method(self, pattern: URLPattern, action: str) -> str:
        """
        Détecte la méthode HTTP appropriée pour une action.
        """
        # Pour les vues basées sur des classes, on peut essayer de détecter
        # les méthodes supportées, mais par défaut on utilise les conventions

        method_map = {
            'list': 'GET',
            'detail': 'GET',
            'create': 'POST',
            'update': 'POST',  # Souvent POST dans Django (pas PUT)
            'delete': 'POST',  # Souvent POST dans Django (pas DELETE)
        }

        return method_map.get(action, 'GET')

    def get_view_info(self, model_name: str, action: str) -> Optional[Dict]:
        """
        Récupère les informations d'une vue pour un modèle et une action.

        Utilise le cache mémoire pour éviter de scanner les URLs à chaque requête.
        Le cache est automatiquement rafraîchi après CACHE_TTL secondes.

        Args:
            model_name: Nom du modèle
            action: Action CRUD ('list', 'create', 'detail', 'update', 'delete')

        Returns:
            Dict avec 'url_name', 'url', 'method', 'requires_pk' ou None
        """
        # Utiliser le cache mémoire (découverte dynamique)
        crud_views_mapping = self.get_cached_views()

        model_lower = model_name.lower()

        # Essayer plusieurs variations du nom de modèle
        variations = [
            model_lower,
            model_lower.replace('_', '-'),  # client_b2b -> client-b2b
            model_lower.replace('-', '_'),  # client-b2b -> client_b2b
            model_lower.replace('_', ''),   # client_b2b -> clientb2b
        ]

        for variant in variations:
            model_views = crud_views_mapping.get(variant, {})
            if model_views and action in model_views:
                LogUtils.info(f"[ViewDiscovery] Vue trouvée: {variant}.{action} -> {model_views[action].get('url_name')}")
                return model_views.get(action)

        LogUtils.info(f"[ViewDiscovery] Aucune vue trouvée pour {model_name}.{action}")
        return None

    def get_all_discovered_models(self) -> List[str]:
        """
        Retourne la liste de tous les modèles découverts avec des vues CRUD.

        Returns:
            Liste des noms de modèles
        """
        crud_views_mapping = self.get_cached_views()
        return list(crud_views_mapping.keys())
