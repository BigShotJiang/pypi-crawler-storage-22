"""
Tests de scénarios utilisateur pour Lucy Assist.

Vérifie que Lucy reçoit les bonnes informations pour répondre
correctement aux questions des utilisateurs dans différents contextes :

- Page list : "combien de X ?", "montre-moi les X"
- Page formulaire : "comment remplir ce champ ?"
- Navigation : "où trouver les X ?"
- Knowledge base : réponses enrichies par les connaissances métier
- API chat : le flux complet message → réponse via l'endpoint
"""
import json
from unittest.mock import patch, MagicMock

from django.test import TestCase, RequestFactory
from django.contrib.auth.models import User
from django.urls import reverse

from lucy_assist.models import (
    ConfigurationLucyAssist,
    Conversation,
    Message,
    KnowledgeBase,
)
from lucy_assist.constantes import LucyAssistConstantes
from lucy_assist.services.context_service import ContextService


# ---------------------------------------------------------------------------
# SCÉNARIO 1 : Questions de comptage sur une page list
# ---------------------------------------------------------------------------
class TestScenarioComptageList(TestCase):
    """
    L'utilisateur est sur /sinistre/liste-sinistre et demande
    "combien de sinistres ?". Lucy doit voir le nombre total.
    """

    def setUp(self):
        self.user = User.objects.create_superuser('admin', 'admin@test.com', 'adminpass')
        self.service = ContextService(self.user)
        ConfigurationLucyAssist.get_config()

    @patch.object(ContextService, 'get_page_context')
    def test_lucy_voit_le_total(self, mock_ctx):
        """Lucy reçoit le total_count pour répondre 'combien ?'."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }
        for i in range(50):
            KnowledgeBase.objects.create(titre=f"Item {i}", contenu=f"Contenu {i}")

        result = self.service.get_list_page_data('/sinistre/liste-sinistre/')

        self.assertIsNotNone(result, "get_list_page_data ne doit pas retourner None sur une list")
        self.assertEqual(result['total_count'], 50)

    @patch.object(ContextService, 'get_page_context')
    def test_lucy_voit_les_premiers_enregistrements(self, mock_ctx):
        """Lucy reçoit les 10 premiers enregistrements pour donner des détails."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }
        for i in range(20):
            KnowledgeBase.objects.create(titre=f"Sinistre #{i:03d}", contenu=f"Détails {i}")

        result = self.service.get_list_page_data('/sinistre/liste-sinistre/')

        self.assertEqual(len(result['records']), 10)
        # Chaque enregistrement a un ID et une représentation lisible
        for record in result['records']:
            self.assertIn('id', record)
            self.assertIn('str', record)
            self.assertTrue(len(record['str']) > 0)

    @patch('lucy_assist.services.context_service.ContextService.get_list_page_data')
    def test_prompt_contient_le_total_pour_mistral(self, mock_list_data):
        """Le prompt système envoyé à Mistral contient le total."""
        mock_list_data.return_value = {
            'model': 'Sinistre',
            'total_count': 50,
            'records': [{'id': 1, 'str': 'Sinistre #001'}],
        }
        from lucy_assist.services.mistral_service import MistralService

        with patch('lucy_assist.services.mistral_service.Mistral'):
            with patch(
                'lucy_assist.services.mistral_service.lucy_assist_settings'
            ) as ms:
                ms.MISTRAL_LUCY_API_KEY = 'fake'
                ms.MISTRAL_MODEL = 'mistral-small-latest'
                ms.PROJECT_APPS_PREFIX = None
                ms.QUESTIONS_FREQUENTES_DEFAULT = []
                service = MistralService()

        prompt = service._build_system_prompt(
            {'page_url': '/sinistre/liste/', 'url': '/sinistre/liste/'},
            self.user,
            'combien de sinistres ?',
        )

        self.assertIn('50', prompt)
        self.assertIn('donnees_page', prompt)


# ---------------------------------------------------------------------------
# SCÉNARIO 2 : Aide sur un formulaire
# ---------------------------------------------------------------------------
class TestScenarioAideFormulaire(TestCase):
    """
    L'utilisateur est sur un formulaire et demande de l'aide.
    Lucy doit connaître les champs du modèle.
    """

    def setUp(self):
        self.user = User.objects.create_superuser('admin', 'admin@test.com', 'adminpass')
        self.service = ContextService(self.user)
        ConfigurationLucyAssist.get_config()

    def test_form_info_retourne_les_champs(self):
        """get_form_info retourne la liste des champs et les champs requis."""
        info = self.service.get_form_info('lucy_assist', 'KnowledgeBase')

        self.assertIsNotNone(info)
        self.assertIn('fields', info)
        self.assertIn('required_fields', info)
        self.assertGreater(len(info['fields']), 0)

        # Le champ 'titre' doit être dans la liste
        field_names = [f['name'] for f in info['fields']]
        self.assertIn('titre', field_names)

    def test_form_info_identifie_champs_requis(self):
        """Les champs obligatoires sont correctement identifiés."""
        info = self.service.get_form_info('lucy_assist', 'KnowledgeBase')

        self.assertIsNotNone(info)
        # 'titre' est un CharField requis (blank=False par défaut)
        self.assertTrue(len(info['required_fields']) > 0)

    def test_form_info_modele_inexistant(self):
        """Pas de crash pour un modèle inexistant."""
        info = self.service.get_form_info('lucy_assist', 'ModeleQuiNexistePas')

        self.assertIsNone(info)

    @patch.object(ContextService, 'get_page_context')
    def test_page_formulaire_pas_de_list_data(self, mock_ctx):
        """Sur un formulaire, get_list_page_data retourne None."""
        mock_ctx.return_value = {
            'action': 'create_or_edit',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }

        result = self.service.get_list_page_data('/test/form/')

        self.assertIsNone(result)


# ---------------------------------------------------------------------------
# SCÉNARIO 3 : Navigation et aide contextuelle
# ---------------------------------------------------------------------------
class TestScenarioNavigation(TestCase):
    """
    L'utilisateur demande de l'aide sur la navigation.
    Lucy doit connaître le type de page et les actions possibles.
    """

    def setUp(self):
        self.user = User.objects.create_superuser('admin', 'admin@test.com', 'adminpass')
        self.service = ContextService(self.user)
        ConfigurationLucyAssist.get_config()

    def test_page_help_list(self):
        """L'aide contextuelle d'une page list propose des actions pertinentes."""
        # On utilise une URL connue pour éviter le Resolver404
        help_info = self.service.get_page_help('/lucy-assist/api/suggestions')

        self.assertIn('help_message', help_info)
        self.assertIn('suggested_actions', help_info)
        self.assertIsInstance(help_info['suggested_actions'], list)

    def test_page_help_contains_model_name(self):
        """L'aide mentionne le modèle de la page."""
        help_info = self.service.get_page_help('/lucy-assist/api/suggestions')

        self.assertIn('current_model', help_info)

    def test_help_for_unknown_page(self):
        """L'aide fonctionne même pour une page inconnue."""
        help_info = self.service.get_page_help('/page-inconnue/')

        self.assertIn('help_message', help_info)
        self.assertIn('suggested_actions', help_info)


# ---------------------------------------------------------------------------
# SCÉNARIO 4 : Knowledge Base enrichit les réponses
# ---------------------------------------------------------------------------
class TestScenarioKnowledgeBase(TestCase):
    """
    Des connaissances métier sont configurées.
    Lucy les utilise pour enrichir ses réponses.
    """

    def setUp(self):
        self.user = User.objects.create_superuser('admin', 'admin@test.com', 'adminpass')
        ConfigurationLucyAssist.get_config()

    def test_knowledge_matching_par_mots_cles(self):
        """Les connaissances sont trouvées par mots-clés."""
        KnowledgeBase.objects.create(
            titre="Processus de paiement",
            contenu="Le paiement se fait par virement sous 30 jours.",
            categorie='PROCESS',
            mots_cles=['paiement', 'virement', 'facture'],
            priorite=5,
        )

        results = KnowledgeBase.get_relevant_knowledge(
            user_question="comment effectuer un paiement ?",
            page_url='/facture/list/',
        )

        self.assertGreater(len(results), 0)
        self.assertIn('virement', results[0].contenu)

    def test_knowledge_matching_par_page_cible(self):
        """Les connaissances ciblant une page sont prioritaires."""
        KnowledgeBase.objects.create(
            titre="Aide sinistres",
            contenu="Pour un nouveau sinistre, cliquer sur Nouveau.",
            categorie='AIDE',
            pages_cibles=['/sinistre/'],
            priorite=3,
        )
        KnowledgeBase.objects.create(
            titre="Aide générale",
            contenu="Bienvenue dans l'application.",
            categorie='AIDE',
            priorite=1,
        )

        results = KnowledgeBase.get_relevant_knowledge(
            user_question="aide",
            page_url='/sinistre/liste/',
        )

        self.assertGreater(len(results), 0)
        # La connaissance ciblant /sinistre/ doit apparaître en premier
        self.assertEqual(results[0].titre, "Aide sinistres")

    def test_knowledge_format_for_prompt(self):
        """Les connaissances sont formatées correctement pour le prompt."""
        kb1 = KnowledgeBase.objects.create(
            titre="FAQ Paiement",
            contenu="Paiement sous 30 jours.",
            categorie='FAQ',
        )
        kb2 = KnowledgeBase.objects.create(
            titre="Règle validation",
            contenu="Toute facture doit être validée.",
            categorie='REGLE',
        )

        formatted = KnowledgeBase.format_for_prompt([kb1, kb2])

        self.assertIn("FAQ Paiement", formatted)
        self.assertIn("Règle validation", formatted)
        self.assertIn("Paiement sous 30 jours", formatted)

    def test_no_knowledge_returns_empty(self):
        """Sans connaissances, le formatage retourne une chaîne vide."""
        formatted = KnowledgeBase.format_for_prompt([])

        self.assertEqual(formatted, "")


# ---------------------------------------------------------------------------
# SCÉNARIO 5 : API Chat endpoint
# ---------------------------------------------------------------------------
class TestScenarioAPIChat(TestCase):
    """
    Test du flux complet via l'endpoint API :
    1. Créer une conversation
    2. Envoyer un message
    3. Obtenir la réponse de Lucy (Mistral mocké)
    """

    def setUp(self):
        self.user = User.objects.create_superuser('admin', 'admin@test.com', 'adminpass')
        self.client.force_login(self.user)
        self.config = ConfigurationLucyAssist.get_config()
        self.config.tokens_disponibles = 1_000_000
        self.config.actif = True
        self.config.save()

    def test_creer_conversation(self):
        """Création d'une conversation via l'API."""
        url = reverse("lucy_assist:api-conversations")
        response = self.client.post(
            url,
            data=json.dumps({'page_contexte': '/sinistre/liste-sinistre'}),
            content_type='application/json',
        )

        self.assertEqual(response.status_code, 201)
        data = response.json()
        self.assertIn('id', data)

    def test_envoyer_message_utilisateur(self):
        """Envoi d'un message utilisateur dans une conversation."""
        conv = Conversation.objects.create(
            utilisateur=self.user,
            page_contexte='/sinistre/list/',
        )

        url = reverse("lucy_assist:api-messages", kwargs={'conversation_id': conv.pk})
        response = self.client.post(
            url,
            data=json.dumps({'contenu': 'Combien de sinistres ?'}),
            content_type='application/json',
        )

        self.assertEqual(response.status_code, 201)
        data = response.json()
        self.assertIn('contenu', data)

    def test_message_vide_refuse(self):
        """Un message vide est refusé."""
        conv = Conversation.objects.create(
            utilisateur=self.user,
            page_contexte='/sinistre/list/',
        )

        url = reverse("lucy_assist:api-messages", kwargs={'conversation_id': conv.pk})
        response = self.client.post(
            url,
            data=json.dumps({'contenu': ''}),
            content_type='application/json',
        )

        self.assertEqual(response.status_code, 400)

    @patch('lucy_assist.views.api_views.MistralService')
    def test_chat_endpoint_retourne_stream(self, MockMistralService):
        """L'endpoint chat retourne un stream SSE."""
        # Préparer la conversation avec un message
        conv = Conversation.objects.create(
            utilisateur=self.user,
            page_contexte='/sinistre/list/',
        )
        Message.objects.create(
            conversation=conv,
            repondant=LucyAssistConstantes.Repondant.UTILISATEUR,
            contenu='Combien de sinistres ?',
        )

        # Mocker le streaming Mistral
        mock_service = MagicMock()

        def fake_stream(*args, **kwargs):
            yield {'type': 'content', 'content': 'Il y a '}
            yield {'type': 'content', 'content': '50 sinistres.'}
            yield {'type': 'usage', 'input_tokens': 500, 'output_tokens': 50, 'total_tokens': 550}

        mock_service.chat_completion_stream.return_value = fake_stream()
        MockMistralService.return_value = mock_service

        url = reverse("lucy_assist:api-chat", kwargs={'conversation_id': conv.pk})
        response = self.client.post(
            url,
            data=json.dumps({'page_contexte': '/sinistre/list/'}),
            content_type='application/json',
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'text/event-stream')

    def test_chat_sans_tokens_refuse(self):
        """Lucy refuse de répondre sans tokens disponibles."""
        self.config.tokens_disponibles = 0
        self.config.save()

        conv = Conversation.objects.create(
            utilisateur=self.user,
            page_contexte='/test/',
        )
        Message.objects.create(
            conversation=conv,
            repondant=LucyAssistConstantes.Repondant.UTILISATEUR,
            contenu='Test',
        )

        url = reverse("lucy_assist:api-chat", kwargs={'conversation_id': conv.pk})
        response = self.client.post(
            url,
            data=json.dumps({}),
            content_type='application/json',
        )

        self.assertEqual(response.status_code, 402)

    def test_statut_tokens(self):
        """L'endpoint token-status retourne les infos correctes."""
        url = reverse("lucy_assist:api-token-status")
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn('tokens_disponibles', data)
        self.assertEqual(data['tokens_disponibles'], 1_000_000)

    def test_suggestions(self):
        """L'endpoint suggestions retourne des questions."""
        url = reverse("lucy_assist:api-suggestions")
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn('suggestions', data)
        self.assertIsInstance(data['suggestions'], list)

    def test_page_context_endpoint(self):
        """L'endpoint page-context retourne le contexte d'une URL."""
        url = reverse("lucy_assist:api-context")
        response = self.client.get(url, {'url': '/sinistre/liste-sinistre/'})

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn('url', data)
        self.assertIn('action', data)
        self.assertEqual(data['action'], 'list')


# ---------------------------------------------------------------------------
# SCÉNARIO 6 : Recherche d'objets
# ---------------------------------------------------------------------------
class TestScenarioRecherche(TestCase):
    """
    L'utilisateur demande à Lucy de chercher un élément spécifique.
    Lucy utilise search_objects pour trouver des résultats.
    """

    def setUp(self):
        self.user = User.objects.create_superuser('admin', 'admin@test.com', 'adminpass')
        self.service = ContextService(self.user)
        ConfigurationLucyAssist.get_config()

    def test_recherche_par_titre(self):
        """Lucy trouve un objet par son titre."""
        KnowledgeBase.objects.create(
            titre="Procédure de réclamation client",
            contenu="Etapes détaillées pour traiter une réclamation.",
            categorie='PROCESS',
        )

        results = self.service.search_objects("réclamation", model_name="KnowledgeBase")

        self.assertGreater(len(results), 0)
        self.assertEqual(results[0]['model'], 'KnowledgeBase')

    def test_recherche_sans_resultat(self):
        """Lucy retourne une liste vide si rien ne correspond."""
        results = self.service.search_objects("xyzinexistant123")

        self.assertEqual(len(results), 0)

    def test_recherche_multi_mots(self):
        """Lucy gère la recherche multi-mots."""
        KnowledgeBase.objects.create(
            titre="Guide utilisateur avancé",
            contenu="Ce guide couvre les fonctionnalités avancées.",
            categorie='AIDE',
        )

        results = self.service.search_objects("guide avancé", model_name="KnowledgeBase")

        self.assertGreater(len(results), 0)
