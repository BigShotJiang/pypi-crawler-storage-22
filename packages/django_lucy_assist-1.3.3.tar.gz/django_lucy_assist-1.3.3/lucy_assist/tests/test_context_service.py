"""
Tests unitaires pour le ContextService.

Vérifie :
- La détection du type de page (list, form, detail, delete)
- L'extraction des données list (get_list_page_data)
- La recherche d'objets (search_objects)
- La construction du contexte de page
"""
from unittest.mock import patch

from django.test import TestCase
from django.contrib.auth.models import User

from lucy_assist.services.context_service import ContextService
from lucy_assist.models import KnowledgeBase, ConfigurationLucyAssist


# ---------------------------------------------------------------------------
# DÉTECTION D'ACTION
# ---------------------------------------------------------------------------
class TestDetectAction(TestCase):
    """Vérifie que _detect_action identifie correctement le type de page."""

    def setUp(self):
        self.user = User.objects.create_user('testuser', password='testpass')
        self.service = ContextService(self.user)

    def test_list_page(self):
        self.assertEqual(self.service._detect_action('sinistre-list'), 'list')
        self.assertEqual(self.service._detect_action('membre-list'), 'list')
        self.assertEqual(self.service._detect_action('liste-client'), 'list')

    def test_create_page(self):
        self.assertEqual(self.service._detect_action('sinistre-form'), 'create_or_edit')
        self.assertEqual(self.service._detect_action('sinistre-create'), 'create_or_edit')
        self.assertEqual(self.service._detect_action('add-membre'), 'create_or_edit')

    def test_detail_page(self):
        self.assertEqual(self.service._detect_action('sinistre-detail'), 'detail')
        self.assertEqual(self.service._detect_action('client-view'), 'detail')

    def test_delete_page(self):
        self.assertEqual(self.service._detect_action('sinistre-delete'), 'delete')

    def test_edit_page(self):
        self.assertEqual(self.service._detect_action('sinistre-edit'), 'edit')
        self.assertEqual(self.service._detect_action('update-client'), 'edit')

    def test_unknown_action(self):
        self.assertEqual(self.service._detect_action('sinistre-export'), 'unknown')

    def test_none_returns_none(self):
        self.assertIsNone(self.service._detect_action(None))


# ---------------------------------------------------------------------------
# CONTEXTE DE PAGE
# ---------------------------------------------------------------------------
class TestGetPageContext(TestCase):
    """Vérifie la construction du contexte de page."""

    def setUp(self):
        self.user = User.objects.create_user('testuser', password='testpass')
        self.service = ContextService(self.user)

    def test_empty_url_returns_default_context(self):
        context = self.service.get_page_context('')
        self.assertIsNone(context['action'])
        self.assertIsNone(context['model_name'])
        self.assertIsNone(context['app_name'])
        self.assertEqual(context['available_actions'], [])

    def test_unresolvable_url_with_list(self):
        """Une URL non résolue contenant 'list' est détectée comme page list."""
        context = self.service.get_page_context('/sinistre/liste-sinistre/')
        self.assertEqual(context['action'], 'list')

    def test_unresolvable_url_with_form(self):
        """Une URL non résolue contenant 'form' est détectée comme formulaire."""
        context = self.service.get_page_context('/sinistre/creation-sinistre/')
        self.assertEqual(context['action'], 'create_or_edit')

    def test_resolved_url_lucy_assist(self):
        """Les URLs Lucy Assist sont résolues correctement."""
        context = self.service.get_page_context('/lucy-assist/api/suggestions')
        self.assertEqual(context['app_name'], 'lucy_assist')

    def test_context_has_all_keys(self):
        """Le contexte contient toutes les clés attendues."""
        context = self.service.get_page_context('/quelque-chose/')
        expected_keys = {
            'url', 'app_name', 'view_name', 'model_name',
            'object_id', 'action', 'available_actions', 'help_text',
        }
        self.assertTrue(expected_keys.issubset(set(context.keys())))


# ---------------------------------------------------------------------------
# GET LIST PAGE DATA
# ---------------------------------------------------------------------------
class TestGetListPageData(TestCase):
    """
    Vérifie get_list_page_data() - extraction des données pour les pages list.
    C'est la brique clé pour que Lucy puisse répondre
    "combien de X ?" ou "montre-moi les X".
    """

    def setUp(self):
        self.user = User.objects.create_user('testuser', password='testpass')
        self.service = ContextService(self.user)
        ConfigurationLucyAssist.get_config()

    # -- Cas positif --

    @patch.object(ContextService, 'get_page_context')
    def test_returns_data_for_list_page(self, mock_ctx):
        """Sur une page list valide, retourne le count et les enregistrements."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }
        KnowledgeBase.objects.create(titre="FAQ 1", contenu="Contenu 1", categorie='FAQ')
        KnowledgeBase.objects.create(titre="FAQ 2", contenu="Contenu 2", categorie='FAQ')

        result = self.service.get_list_page_data('/test/list/')

        self.assertIsNotNone(result)
        self.assertEqual(result['total_count'], 2)
        self.assertEqual(result['model'], 'KnowledgeBase')
        self.assertEqual(len(result['records']), 2)

    @patch.object(ContextService, 'get_page_context')
    def test_records_contain_id_and_str(self, mock_ctx):
        """Chaque enregistrement contient un ID et une représentation textuelle."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }
        kb = KnowledgeBase.objects.create(titre="Mon Titre", contenu="Mon contenu")

        result = self.service.get_list_page_data('/test/list/')

        record = result['records'][0]
        self.assertIn('id', record)
        self.assertIn('str', record)
        self.assertEqual(record['id'], kb.pk)

    @patch.object(ContextService, 'get_page_context')
    def test_records_contain_verbose_field_names(self, mock_ctx):
        """Les champs utilisent le verbose_name, pas le nom technique."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }
        KnowledgeBase.objects.create(
            titre="FAQ Test", contenu="Contenu test", categorie='FAQ', priorite=5,
        )

        result = self.service.get_list_page_data('/test/list/')

        record = result['records'][0]
        # Les clés doivent être des verbose_name (pas les noms techniques)
        # Au minimum on doit avoir l'id et le str
        self.assertGreater(len(record), 2)

    @patch.object(ContextService, 'get_page_context')
    def test_empty_database_returns_zero_count(self, mock_ctx):
        """Base vide → total_count = 0 et records = []."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }

        result = self.service.get_list_page_data('/test/list/')

        self.assertEqual(result['total_count'], 0)
        self.assertEqual(result['records'], [])

    @patch.object(ContextService, 'get_page_context')
    def test_count_matches_database(self, mock_ctx):
        """total_count correspond exactement au nombre d'objets en base."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }
        for i in range(7):
            KnowledgeBase.objects.create(titre=f"KB {i}", contenu=f"Contenu {i}")

        result = self.service.get_list_page_data('/test/list/')

        self.assertEqual(result['total_count'], KnowledgeBase.objects.count())
        self.assertEqual(result['total_count'], 7)

    @patch.object(ContextService, 'get_page_context')
    def test_app_name_with_namespace(self, mock_ctx):
        """Gère les app_name avec namespace (ex: 'ns:lucy_assist')."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'namespace:lucy_assist',
        }
        KnowledgeBase.objects.create(titre="Test", contenu="Test")

        result = self.service.get_list_page_data('/test/list/')

        self.assertIsNotNone(result)
        self.assertEqual(result['total_count'], 1)

    # -- Limites --

    @patch.object(ContextService, 'get_page_context')
    def test_limits_records_to_10(self, mock_ctx):
        """Maximum 10 enregistrements retournés, même si plus en base."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }
        for i in range(15):
            KnowledgeBase.objects.create(titre=f"KB {i}", contenu=f"Contenu {i}")

        result = self.service.get_list_page_data('/test/list/')

        self.assertEqual(result['total_count'], 15)
        self.assertEqual(len(result['records']), 10)

    @patch.object(ContextService, 'get_page_context')
    def test_limits_fields_to_6(self, mock_ctx):
        """Maximum 6 champs métier par enregistrement (hors id et str)."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }
        KnowledgeBase.objects.create(titre="Test", contenu="Contenu test")

        result = self.service.get_list_page_data('/test/list/')

        record = result['records'][0]
        data_fields = [k for k in record.keys() if k not in ('id', 'str')]
        self.assertLessEqual(len(data_fields), 6,
                             f"Trop de champs ({len(data_fields)}): {data_fields}")

    @patch.object(ContextService, 'get_page_context')
    def test_truncates_long_values_to_100(self, mock_ctx):
        """Les valeurs de plus de 100 caractères sont tronquées."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }
        KnowledgeBase.objects.create(titre="Test", contenu="A" * 500)

        result = self.service.get_list_page_data('/test/list/')

        for key, value in result['records'][0].items():
            if isinstance(value, str):
                self.assertLessEqual(
                    len(value), 100,
                    f"Champ '{key}' dépasse 100 chars ({len(value)})"
                )

    @patch.object(ContextService, 'get_page_context')
    def test_excludes_technical_fields(self, mock_ctx):
        """Les champs techniques (created_date, updated_date...) sont exclus."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }
        KnowledgeBase.objects.create(titre="Test", contenu="Test")

        result = self.service.get_list_page_data('/test/list/')

        record = result['records'][0]
        excluded_names = {'id', 'pk', 'created_at', 'updated_at',
                          'created_date', 'updated_date',
                          'created_user', 'updated_user', 'is_active'}
        field_keys_lower = {k.lower() for k in record.keys() if k not in ('id', 'str')}
        overlap = field_keys_lower & excluded_names
        self.assertEqual(overlap, set(),
                         f"Champs techniques trouvés dans l'enregistrement: {overlap}")

    # -- Cas négatifs (retournent None sans crash) --

    @patch.object(ContextService, 'get_page_context')
    def test_returns_none_for_non_list_page(self, mock_ctx):
        """Ne retourne rien sur une page de détail."""
        mock_ctx.return_value = {
            'action': 'detail',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }

        result = self.service.get_list_page_data('/test/detail/1/')

        self.assertIsNone(result)

    @patch.object(ContextService, 'get_page_context')
    def test_returns_none_for_form_page(self, mock_ctx):
        """Ne retourne rien sur une page de formulaire."""
        mock_ctx.return_value = {
            'action': 'create_or_edit',
            'model_name': 'KnowledgeBase',
            'app_name': 'lucy_assist',
        }

        result = self.service.get_list_page_data('/test/form/')

        self.assertIsNone(result)

    @patch.object(ContextService, 'get_page_context')
    def test_returns_none_without_model_name(self, mock_ctx):
        """Pas de crash si model_name est absent."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': None,
            'app_name': 'lucy_assist',
        }

        result = self.service.get_list_page_data('/test/list/')

        self.assertIsNone(result)

    @patch.object(ContextService, 'get_page_context')
    def test_returns_none_without_app_name(self, mock_ctx):
        """Pas de crash si app_name est vide."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': '',
        }

        result = self.service.get_list_page_data('/test/list/')

        self.assertIsNone(result)

    @patch.object(ContextService, 'get_page_context')
    def test_returns_none_for_invalid_model(self, mock_ctx):
        """Pas de crash si le modèle n'existe pas."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'ModeleInexistant',
            'app_name': 'lucy_assist',
        }

        result = self.service.get_list_page_data('/test/list/')

        self.assertIsNone(result)

    @patch.object(ContextService, 'get_page_context')
    def test_returns_none_for_invalid_app(self, mock_ctx):
        """Pas de crash si l'app n'existe pas."""
        mock_ctx.return_value = {
            'action': 'list',
            'model_name': 'KnowledgeBase',
            'app_name': 'app_inexistante',
        }

        result = self.service.get_list_page_data('/test/list/')

        self.assertIsNone(result)


# ---------------------------------------------------------------------------
# SEARCH OBJECTS
# ---------------------------------------------------------------------------
class TestSearchObjects(TestCase):
    """Vérifie la recherche d'objets par texte et par date."""

    def setUp(self):
        self.user = User.objects.create_user('testuser', password='testpass')
        self.service = ContextService(self.user)
        ConfigurationLucyAssist.get_config()

    def test_search_by_text(self):
        """Recherche par texte dans les champs CharField/TextField."""
        KnowledgeBase.objects.create(titre="Processus facturation", contenu="Etapes")
        KnowledgeBase.objects.create(titre="FAQ paiement", contenu="Comment payer")

        results = self.service.search_objects("facturation", model_name="KnowledgeBase")

        self.assertGreaterEqual(len(results), 1)
        titles = [r['str'] for r in results]
        self.assertTrue(any("facturation" in t.lower() for t in titles))

    def test_search_no_results(self):
        """Pas de résultat pour un terme inexistant."""
        KnowledgeBase.objects.create(titre="FAQ test", contenu="Contenu")

        results = self.service.search_objects("zzzzinexistant", model_name="KnowledgeBase")

        self.assertEqual(len(results), 0)

    def test_search_respects_limit(self):
        """Le nombre de résultats est limité."""
        for i in range(20):
            KnowledgeBase.objects.create(titre=f"FAQ item {i}", contenu=f"Contenu {i}")

        results = self.service.search_objects("FAQ", model_name="KnowledgeBase", limit=5)

        self.assertLessEqual(len(results), 5)

    def test_search_results_contain_model_and_id(self):
        """Chaque résultat contient le nom du modèle et l'ID."""
        KnowledgeBase.objects.create(titre="FAQ test", contenu="Contenu test")

        results = self.service.search_objects("FAQ", model_name="KnowledgeBase")

        if results:
            self.assertIn('model', results[0])
            self.assertIn('id', results[0])
            self.assertEqual(results[0]['model'], 'KnowledgeBase')


# ---------------------------------------------------------------------------
# GET RELEVANT MODELS
# ---------------------------------------------------------------------------
class TestGetRelevantModels(TestCase):
    """Vérifie la découverte des modèles pertinents pour une page."""

    def setUp(self):
        self.user = User.objects.create_user('testuser', password='testpass')
        self.service = ContextService(self.user)
        ConfigurationLucyAssist.get_config()

    def test_returns_list_of_models(self):
        """Retourne une liste non vide de modèles."""
        models = self.service.get_relevant_models('/lucy-assist/api/suggestions')

        self.assertIsInstance(models, list)

    def test_model_info_has_required_keys(self):
        """Chaque modèle retourné a les clés nécessaires."""
        models = self.service.get_relevant_models('/lucy-assist/api/suggestions')

        if models:
            model = models[0]
            self.assertIn('name', model)
            self.assertIn('fields', model)
            self.assertIn('app', model)

    def test_get_all_model_names(self):
        """get_all_model_names retourne une liste de noms de modèles."""
        names = self.service.get_all_model_names()

        self.assertIsInstance(names, list)
        # Avec PROJECT_APPS_PREFIX=None, lucy_assist est exclu (app interne),
        # mais les modèles du projet hôte seraient retournés.
        # En environnement de test sans app métier, la liste peut être vide.
        # On vérifie juste que ça ne crash pas et retourne une liste.
        self.assertIsInstance(names, list)
