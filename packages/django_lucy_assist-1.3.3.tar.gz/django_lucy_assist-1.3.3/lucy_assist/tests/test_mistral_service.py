"""
Tests unitaires pour le MistralService.

Vérifie :
- La construction du prompt système (contexte de page, données list, knowledge base)
- Les appels chat_completion et chat_completion_stream (API Mistral mockée)
- La gestion des erreurs et cas limites

Tous les appels à l'API Mistral sont mockés : aucun appel réseau n'est effectué.
"""
import json
from unittest.mock import patch, MagicMock

from django.test import TestCase
from django.contrib.auth.models import User

from lucy_assist.models import ConfigurationLucyAssist, KnowledgeBase
from lucy_assist.constantes import LucyAssistConstantes


def _create_mistral_service():
    """
    Crée un MistralService avec le client Mistral mocké.
    Permet de tester _build_system_prompt et chat_completion
    sans appel réseau ni clé API réelle.
    """
    with patch('lucy_assist.services.mistral_service.Mistral') as MockMistral:
        with patch(
            'lucy_assist.services.mistral_service.lucy_assist_settings'
        ) as mock_settings:
            mock_settings.MISTRAL_LUCY_API_KEY = 'test-key-fake'
            mock_settings.MISTRAL_MODEL = 'mistral-small-latest'
            mock_settings.PROJECT_APPS_PREFIX = None
            mock_settings.QUESTIONS_FREQUENTES_DEFAULT = []
            mock_settings.PRIX_PAR_MILLION_TOKENS = 50.0
            mock_settings.TOKENS_MOYENS_PAR_CONVERSATION = 2000

            from lucy_assist.services.mistral_service import MistralService
            service = MistralService()
            return service, MockMistral.return_value


# ---------------------------------------------------------------------------
# CONSTRUCTION DU PROMPT SYSTÈME
# ---------------------------------------------------------------------------
class TestBuildSystemPrompt(TestCase):
    """
    Vérifie que _build_system_prompt() inclut les bonnes informations
    pour que Mistral puisse répondre aux questions de l'utilisateur.
    """

    def setUp(self):
        self.user = User.objects.create_superuser('admin', 'admin@test.com', 'adminpass')
        self.config = ConfigurationLucyAssist.get_config()
        self.config.tokens_disponibles = 1_000_000
        self.config.actif = True
        self.config.save()

    def _build_prompt(self, page_url, question=''):
        """Helper : construit le prompt pour une page et une question données."""
        service, _ = _create_mistral_service()
        return service._build_system_prompt(
            {'page_url': page_url, 'url': page_url},
            self.user,
            question,
        )

    # -- Données list --

    @patch('lucy_assist.services.context_service.ContextService.get_list_page_data')
    def test_prompt_includes_list_data_on_list_page(self, mock_list_data):
        """
        Quand l'utilisateur est sur une page list,
        le prompt contient les données (count + enregistrements).
        """
        mock_list_data.return_value = {
            'model': 'Sinistre',
            'total_count': 50,
            'records': [
                {'id': 1, 'str': 'Sinistre #001', 'Référence': 'SIN-001'},
                {'id': 2, 'str': 'Sinistre #002', 'Référence': 'SIN-002'},
            ],
        }

        prompt = self._build_prompt('/sinistre/liste-sinistre/', 'combien de sinistres ?')

        self.assertIn('donnees_page', prompt)
        self.assertIn('50', prompt)
        self.assertIn('SIN-001', prompt)

    @patch('lucy_assist.services.context_service.ContextService.get_list_page_data')
    def test_prompt_no_list_data_on_form_page(self, mock_list_data):
        """Sur une page formulaire, pas de données list dans le prompt."""
        mock_list_data.return_value = None

        prompt = self._build_prompt('/sinistre/form/', 'comment remplir ce formulaire ?')

        self.assertNotIn('donnees_page', prompt)

    @patch('lucy_assist.services.context_service.ContextService.get_list_page_data')
    def test_prompt_no_list_data_on_detail_page(self, mock_list_data):
        """Sur une page détail, pas de données list dans le prompt."""
        mock_list_data.return_value = None

        prompt = self._build_prompt('/sinistre/detail/1/', 'quelles sont les infos ?')

        self.assertNotIn('donnees_page', prompt)

    # -- Knowledge Base --

    def test_prompt_includes_knowledge_base(self):
        """Le prompt contient les connaissances métier pertinentes."""
        KnowledgeBase.objects.create(
            titre="Règle de facturation",
            contenu="Les factures doivent être envoyées sous 48h.",
            categorie='REGLE',
            mots_cles=['facture', 'facturation', 'délai'],
            priorite=5,
        )

        prompt = self._build_prompt('/facture/list/', 'quel est le délai pour les factures ?')

        self.assertIn('48h', prompt)

    def test_prompt_includes_targeted_knowledge(self):
        """Les connaissances ciblant la page actuelle sont incluses."""
        KnowledgeBase.objects.create(
            titre="Aide sinistres",
            contenu="Pour déclarer un sinistre, remplir le formulaire.",
            categorie='AIDE',
            pages_cibles=['/sinistre/'],
            priorite=3,
        )

        prompt = self._build_prompt('/sinistre/list/', 'comment déclarer un sinistre ?')

        self.assertIn('déclarer un sinistre', prompt)

    def test_prompt_without_knowledge(self):
        """Le prompt fonctionne même sans connaissances métier."""
        prompt = self._build_prompt('/', 'bonjour')

        self.assertIn('Lucy', prompt)

    # -- Modèles disponibles --

    def test_prompt_includes_models_section(self):
        """Le prompt contient une section sur les modèles disponibles."""
        prompt = self._build_prompt('/', 'quels modèles sont disponibles ?')

        # La section modèles est toujours présente dans le prompt
        self.assertIn('Modèles disponibles', prompt)

    def test_prompt_includes_user_permissions(self):
        """Le prompt mentionne les permissions de l'utilisateur."""
        prompt = self._build_prompt('/', 'que puis-je faire ?')

        # Un superuser a des permissions
        self.assertIsInstance(prompt, str)
        self.assertGreater(len(prompt), 100)

    # -- Structure du prompt --

    def test_prompt_contains_page_url(self):
        """Le prompt contient l'URL de la page actuelle."""
        prompt = self._build_prompt('/sinistre/liste-sinistre/', 'où suis-je ?')

        self.assertIn('/sinistre/liste-sinistre/', prompt)

    def test_prompt_is_string(self):
        """Le prompt est une string non vide."""
        prompt = self._build_prompt('/', 'test')

        self.assertIsInstance(prompt, str)
        self.assertGreater(len(prompt), 0)


# ---------------------------------------------------------------------------
# CHAT COMPLETION (NON-STREAMING)
# ---------------------------------------------------------------------------
class TestChatCompletion(TestCase):
    """Vérifie chat_completion avec API Mistral mockée."""

    def setUp(self):
        self.user = User.objects.create_superuser('admin', 'admin@test.com', 'adminpass')
        self.config = ConfigurationLucyAssist.get_config()
        self.config.tokens_disponibles = 1_000_000
        self.config.actif = True
        self.config.save()

    def _make_message(self, contenu, repondant='UTILISATEUR'):
        """Crée un objet message mocké."""
        msg = MagicMock()
        msg.repondant = repondant
        msg.contenu = contenu
        return msg

    def test_returns_content_from_mistral(self):
        """La réponse Mistral est correctement retournée."""
        service, mock_client = _create_mistral_service()

        # Mock de la réponse Mistral
        mock_response = MagicMock()
        mock_choice = MagicMock()
        mock_choice.message.content = "Il y a 50 sinistres dans la liste."
        mock_response.choices = [mock_choice]
        mock_response.usage.prompt_tokens = 500
        mock_response.usage.completion_tokens = 50
        mock_client.chat.complete.return_value = mock_response

        result = service.chat_completion(
            messages=[self._make_message("Combien de sinistres ?")],
            page_context={'page_url': '/sinistre/list/', 'url': '/sinistre/list/'},
            user=self.user,
        )

        self.assertIn('content', result)
        self.assertEqual(result['content'], "Il y a 50 sinistres dans la liste.")
        self.assertGreater(result['tokens_utilises'], 0)

    def test_returns_error_on_api_failure(self):
        """Une erreur API est gérée proprement."""
        service, mock_client = _create_mistral_service()
        mock_client.chat.complete.side_effect = Exception("API timeout")

        result = service.chat_completion(
            messages=[self._make_message("Test question")],
            page_context={'page_url': '/', 'url': '/'},
            user=self.user,
        )

        self.assertIn('error', result)

    def test_returns_error_on_empty_messages(self):
        """Une erreur est retournée si aucun message n'est fourni."""
        service, _ = _create_mistral_service()

        result = service.chat_completion(
            messages=[],
            page_context={'page_url': '/', 'url': '/'},
            user=self.user,
        )

        self.assertIn('error', result)

    def test_handles_multiple_messages(self):
        """Gère correctement une conversation avec plusieurs échanges."""
        service, mock_client = _create_mistral_service()

        mock_response = MagicMock()
        mock_choice = MagicMock()
        mock_choice.message.content = "Voici les détails du sinistre #001."
        mock_response.choices = [mock_choice]
        mock_response.usage.prompt_tokens = 800
        mock_response.usage.completion_tokens = 100
        mock_client.chat.complete.return_value = mock_response

        messages = [
            self._make_message("Montre-moi le sinistre #001"),
            self._make_message("Voici le sinistre #001...", 'CHATBOT'),
            self._make_message("Donne-moi plus de détails"),
        ]

        result = service.chat_completion(
            messages=messages,
            page_context={'page_url': '/sinistre/list/', 'url': '/sinistre/list/'},
            user=self.user,
        )

        self.assertIn('content', result)
        # Vérifier que l'API a bien été appelée avec les messages formatés
        mock_client.chat.complete.assert_called_once()
        call_kwargs = mock_client.chat.complete.call_args
        sent_messages = call_kwargs.kwargs.get('messages', call_kwargs[1].get('messages', []))
        # Premier message = system, puis les 3 messages de la conversation
        self.assertEqual(len(sent_messages), 4)


# ---------------------------------------------------------------------------
# CHAT COMPLETION STREAM
# ---------------------------------------------------------------------------
class TestChatCompletionStream(TestCase):
    """Vérifie chat_completion_stream avec API Mistral mockée."""

    def setUp(self):
        self.user = User.objects.create_superuser('admin', 'admin@test.com', 'adminpass')
        self.config = ConfigurationLucyAssist.get_config()
        self.config.tokens_disponibles = 1_000_000
        self.config.actif = True
        self.config.save()

    def _make_message(self, contenu, repondant='UTILISATEUR'):
        msg = MagicMock()
        msg.repondant = repondant
        msg.contenu = contenu
        return msg

    def _make_stream_chunks(self, text_parts):
        """Crée des chunks de streaming simulés."""
        chunks = []
        for i, text in enumerate(text_parts):
            chunk = MagicMock()
            choice = MagicMock()
            choice.delta.content = text
            choice.delta.tool_calls = None
            chunk.data.choices = [choice]
            chunk.data.usage = None
            chunks.append(chunk)

        # Dernier chunk avec usage
        final_chunk = MagicMock()
        final_choice = MagicMock()
        final_choice.delta.content = None
        final_choice.delta.tool_calls = None
        final_chunk.data.choices = [final_choice]
        final_chunk.data.usage = MagicMock()
        final_chunk.data.usage.prompt_tokens = 500
        final_chunk.data.usage.completion_tokens = 50
        chunks.append(final_chunk)

        return chunks

    def test_streams_content_chunks(self):
        """Le streaming retourne des événements de type 'content'."""
        service, mock_client = _create_mistral_service()

        chunks = self._make_stream_chunks(["Il y a ", "50 ", "sinistres."])
        mock_client.chat.stream.return_value = iter(chunks)

        events = list(service.chat_completion_stream(
            messages=[self._make_message("Combien de sinistres ?")],
            page_context={'page_url': '/sinistre/list/', 'url': '/sinistre/list/'},
            user=self.user,
        ))

        content_events = [e for e in events if e['type'] == 'content']
        self.assertGreater(len(content_events), 0)

        full_text = ''.join(e['content'] for e in content_events)
        self.assertEqual(full_text, "Il y a 50 sinistres.")

    def test_streams_usage_info(self):
        """Le streaming inclut les informations d'usage des tokens."""
        service, mock_client = _create_mistral_service()

        chunks = self._make_stream_chunks(["Réponse test."])
        mock_client.chat.stream.return_value = iter(chunks)

        events = list(service.chat_completion_stream(
            messages=[self._make_message("Test")],
            page_context={'page_url': '/', 'url': '/'},
            user=self.user,
        ))

        usage_events = [e for e in events if e['type'] == 'usage']
        self.assertEqual(len(usage_events), 1)
        self.assertIn('input_tokens', usage_events[0])
        self.assertIn('output_tokens', usage_events[0])

    def test_handles_stream_error(self):
        """Les erreurs de streaming sont gérées proprement."""
        service, mock_client = _create_mistral_service()
        mock_client.chat.stream.side_effect = Exception("Connection error")

        events = list(service.chat_completion_stream(
            messages=[self._make_message("Test")],
            page_context={'page_url': '/', 'url': '/'},
            user=self.user,
        ))

        error_events = [e for e in events if e['type'] == 'error']
        self.assertEqual(len(error_events), 1)

    def test_handles_empty_messages(self):
        """Retourne une erreur si aucun message."""
        service, _ = _create_mistral_service()

        events = list(service.chat_completion_stream(
            messages=[],
            page_context={'page_url': '/', 'url': '/'},
            user=self.user,
        ))

        error_events = [e for e in events if e['type'] == 'error']
        self.assertEqual(len(error_events), 1)

    def test_handles_rate_limit_error(self):
        """Les erreurs de rate limit retournent un message clair."""
        service, mock_client = _create_mistral_service()
        mock_client.chat.stream.side_effect = Exception("Rate limit exceeded")

        events = list(service.chat_completion_stream(
            messages=[self._make_message("Test")],
            page_context={'page_url': '/', 'url': '/'},
            user=self.user,
        ))

        error_events = [e for e in events if e['type'] == 'error']
        self.assertEqual(len(error_events), 1)
        self.assertIn('surcharge', error_events[0]['error'].lower())
