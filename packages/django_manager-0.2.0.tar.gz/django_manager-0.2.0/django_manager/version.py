"""
Version information.
"""

__version__ = "0.2.0"
VERSION = (0, 2, 0)


def version_tuple():
    return VERSION


def version_string():
    return ".".join(str(x) for x in VERSION)
