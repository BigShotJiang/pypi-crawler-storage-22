"""
django-manager
~~~~~~~~~~~~~~

Standardized service layer and data processing abstractions
for Django applications.

:copyright: (c) 2025 django-manager contributors
:license: MIT
"""

from .version import __version__

__author__ = "django-manager contributors"
__license__ = "MIT"

default_app_config = "django_manager.fabric.apps.FabricConfig"


def get_version():
    """Return current package version."""
    return __version__
