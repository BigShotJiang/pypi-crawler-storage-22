"""
Compatibility shims for different Python/Django versions.
"""
import sys

PY312_PLUS = sys.version_info >= (3, 12)
PY313_PLUS = sys.version_info >= (3, 13)

try:
    from django import VERSION as DJANGO_VERSION
    DJANGO_5_PLUS = DJANGO_VERSION >= (5, 0)
    DJANGO_6_PLUS = DJANGO_VERSION >= (6, 0)
except ImportError:
    DJANGO_VERSION = None
    DJANGO_5_PLUS = False
    DJANGO_6_PLUS = False

try:
    from functools import cache
except ImportError:
    from functools import lru_cache
    cache = lru_cache(maxsize=None)

try:
    from enum import StrEnum
except ImportError:
    from enum import Enum

    class StrEnum(str, Enum):
        pass


def ensure_str(value) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return str(value)


def ensure_bytes(value) -> bytes:
    if isinstance(value, str):
        return value.encode("utf-8")
    return bytes(value)
