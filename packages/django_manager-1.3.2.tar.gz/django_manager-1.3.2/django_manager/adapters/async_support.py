"""
Async adapter support utilities.
"""
import asyncio
import logging
from typing import Any, Dict, Callable, Optional
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)

_executor = ThreadPoolExecutor(max_workers=4)


async def run_sync_adapter(fn: Callable, *args, **kwargs) -> Any:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(_executor, lambda: fn(*args, **kwargs))


class AsyncAdapterWrapper:
    def __init__(self, sync_adapter):
        self._adapter = sync_adapter

    async def execute(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return await run_sync_adapter(self._adapter.execute, payload)

    async def health_check(self) -> bool:
        return await run_sync_adapter(self._adapter.health_check)


class BatchExecutor:
    def __init__(self, adapter, concurrency: int = 3):
        self._adapter = adapter
        self._concurrency = concurrency

    async def execute_many(self, payloads: list) -> list:
        semaphore = asyncio.Semaphore(self._concurrency)
        async def _run(p):
            async with semaphore:
                wrapper = AsyncAdapterWrapper(self._adapter)
                return await wrapper.execute(p)
        return await asyncio.gather(*[_run(p) for p in payloads])
