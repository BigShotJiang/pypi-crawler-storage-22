"""
Abstract base adapter for pluggable backends.
"""
import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class BaseAdapter(ABC):
    """Interface for external service adapters."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self._config = config or {}
        self._initialized = False

    def initialize(self):
        self._initialized = True
        logger.debug("%s initialized", self.__class__.__name__)

    @abstractmethod
    def execute(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        ...

    @abstractmethod
    def health_check(self) -> bool:
        ...

    def teardown(self):
        self._initialized = False


class NullAdapter(BaseAdapter):
    """No-op adapter for testing."""

    def execute(self, payload):
        return {"status": "noop"}

    def health_check(self):
        return True
