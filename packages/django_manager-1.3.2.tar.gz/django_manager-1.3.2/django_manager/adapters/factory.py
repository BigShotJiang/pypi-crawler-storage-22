"""
Adapter configuration and factory patterns.
"""
from typing import Any, Dict, Optional, Type
from .base import BaseAdapter


class AdapterConfig:
    def __init__(self, adapter_cls: Type[BaseAdapter], **defaults):
        self.adapter_cls = adapter_cls
        self.defaults = defaults

    def create(self, **overrides) -> BaseAdapter:
        config = {**self.defaults, **overrides}
        instance = self.adapter_cls(config=config)
        instance.initialize()
        return instance


class AdapterFactory:
    _configs: Dict[str, AdapterConfig] = {}

    @classmethod
    def register(cls, name: str, adapter_cls: Type[BaseAdapter], **defaults):
        cls._configs[name] = AdapterConfig(adapter_cls, **defaults)

    @classmethod
    def create(cls, name: str, **overrides) -> BaseAdapter:
        if name not in cls._configs:
            raise KeyError(f"No adapter config for '{name}'")
        return cls._configs[name].create(**overrides)

    @classmethod
    def available(cls):
        return list(cls._configs.keys())
