"""
HTTP adapter for REST endpoints.
"""
import requests
from .base import BaseAdapter


class HttpAdapter(BaseAdapter):

    def execute(self, payload):
        method = payload.get('method', 'GET')
        url = payload['url']
        resp = requests.request(method, url, json=payload.get('body'), timeout=10)
        return {'status_code': resp.status_code, 'body': resp.text}

    def health_check(self):
        return True
