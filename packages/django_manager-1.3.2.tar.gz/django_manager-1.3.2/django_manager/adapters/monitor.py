"""
Adapter lifecycle and health monitoring.
"""
import time
import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class AdapterMonitor:
    _stats: Dict[str, dict] = {}

    @classmethod
    def record_call(cls, adapter_name: str, duration: float, success: bool):
        if adapter_name not in cls._stats:
            cls._stats[adapter_name] = {'calls': 0, 'errors': 0, 'total_time': 0.0}
        cls._stats[adapter_name]['calls'] += 1
        cls._stats[adapter_name]['total_time'] += duration
        if not success:
            cls._stats[adapter_name]['errors'] += 1

    @classmethod
    def get_stats(cls, adapter_name: str) -> dict:
        return cls._stats.get(adapter_name, {})

    @classmethod
    def reset(cls):
        cls._stats.clear()


class CircuitBreaker:
    def __init__(self, failure_threshold: int = 5, recovery_timeout: float = 30.0):
        self._failure_count = 0
        self._threshold = failure_threshold
        self._recovery_timeout = recovery_timeout
        self._last_failure: Optional[float] = None
        self._state = 'closed'

    @property
    def is_open(self) -> bool:
        if self._state == 'open' and self._last_failure:
            if time.time() - self._last_failure > self._recovery_timeout:
                self._state = 'half-open'
                return False
        return self._state == 'open'

    def record_success(self):
        self._failure_count = 0
        self._state = 'closed'

    def record_failure(self):
        self._failure_count += 1
        self._last_failure = time.time()
        if self._failure_count >= self._threshold:
            self._state = 'open'
            logger.warning("Circuit breaker opened after %d failures", self._failure_count)
