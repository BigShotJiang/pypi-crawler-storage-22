"""
Adapter retry and timeout policies.
"""
import time
import logging
from typing import Any, Dict, Optional
from functools import wraps

logger = logging.getLogger(__name__)


class RetryPolicy:
    def __init__(self, max_retries: int = 3, base_delay: float = 0.5, backoff: float = 2.0):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.backoff = backoff

    def execute(self, fn, *args, **kwargs) -> Any:
        delay = self.base_delay
        for attempt in range(1, self.max_retries + 1):
            try:
                return fn(*args, **kwargs)
            except Exception as exc:
                if attempt == self.max_retries:
                    raise
                logger.warning("Retry %d/%d: %s", attempt, self.max_retries, exc)
                time.sleep(delay)
                delay *= self.backoff


class TimeoutPolicy:
    def __init__(self, timeout: float = 10.0):
        self.timeout = timeout

    def check(self, start_time: float) -> bool:
        elapsed = time.time() - start_time
        if elapsed > self.timeout:
            raise TimeoutError(f"Operation exceeded {self.timeout}s timeout")
        return True


class BulkheadPolicy:
    """Limits concurrent adapter calls."""
    def __init__(self, max_concurrent: int = 10):
        self._max = max_concurrent
        self._current = 0

    def acquire(self):
        if self._current >= self._max:
            raise RuntimeError(f"Bulkhead limit ({self._max}) reached")
        self._current += 1

    def release(self):
        self._current = max(0, self._current - 1)

    @property
    def available(self) -> int:
        return self._max - self._current
