"""
Adapter registry and discovery.
"""
from typing import Dict, Type
from .base import BaseAdapter

_registry: Dict[str, Type[BaseAdapter]] = {}


def register_adapter(name: str, adapter_cls: Type[BaseAdapter]):
    _registry[name] = adapter_cls


def get_adapter(name: str, **config) -> BaseAdapter:
    cls = _registry.get(name)
    if cls is None:
        raise KeyError(f"Adapter '{name}' not registered")
    instance = cls(config=config)
    instance.initialize()
    return instance


def list_adapters():
    return list(_registry.keys())
