"""
Adapter test utilities and fixtures.
"""
from typing import Any, Dict, List
from .base import BaseAdapter


class RecordingAdapter(BaseAdapter):
    """Records all calls for assertions in tests."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.calls: List[Dict[str, Any]] = []
        self._responses: List[dict] = []

    def stub_response(self, response: dict):
        self._responses.append(response)

    def execute(self, payload):
        self.calls.append(payload)
        if self._responses:
            return self._responses.pop(0)
        return {"status": "recorded"}

    def health_check(self):
        return True

    @property
    def call_count(self) -> int:
        return len(self.calls)

    def last_call(self) -> Dict[str, Any]:
        return self.calls[-1] if self.calls else {}

    def reset(self):
        self.calls.clear()
        self._responses.clear()


class FailingAdapter(BaseAdapter):
    """Always raises an exception — for error handling tests."""

    def __init__(self, exc_cls=RuntimeError, msg="Adapter failure", **kw):
        super().__init__(**kw)
        self._exc_cls = exc_cls
        self._msg = msg

    def execute(self, payload):
        raise self._exc_cls(self._msg)

    def health_check(self):
        return False
