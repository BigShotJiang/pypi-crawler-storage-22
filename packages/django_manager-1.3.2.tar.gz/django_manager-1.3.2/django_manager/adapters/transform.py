"""
Adapter serialization and payload transformation.
"""
import json
import copy
from typing import Any, Callable, Dict, List, Optional


class PayloadTransformer:
    def __init__(self):
        self._transforms: List[Callable] = []

    def add(self, fn: Callable) -> 'PayloadTransformer':
        self._transforms.append(fn)
        return self

    def apply(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        result = copy.deepcopy(payload)
        for fn in self._transforms:
            result = fn(result)
        return result


def flatten_payload(data: dict, prefix: str = '', sep: str = '.') -> dict:
    items = {}
    for key, val in data.items():
        new_key = f"{prefix}{sep}{key}" if prefix else key
        if isinstance(val, dict):
            items.update(flatten_payload(val, new_key, sep))
        else:
            items[new_key] = val
    return items


def unflatten_payload(data: dict, sep: str = '.') -> dict:
    result = {}
    for key, val in data.items():
        parts = key.split(sep)
        d = result
        for part in parts[:-1]:
            d = d.setdefault(part, {})
        d[parts[-1]] = val
    return result


def mask_sensitive_fields(data: dict, fields: tuple = ('password', 'token', 'secret')) -> dict:
    masked = copy.deepcopy(data)
    for key in masked:
        if any(f in key.lower() for f in fields):
            masked[key] = '***'
    return masked
