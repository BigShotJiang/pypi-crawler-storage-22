"""
Codec and serialization layer.
"""
