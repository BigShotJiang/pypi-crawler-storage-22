"""
Binary serialization helpers.
"""
import struct
from typing import Any, Dict, List


def pack_header(version: int, flags: int, payload_size: int) -> bytes:
    return struct.pack('!BBI', version, flags, payload_size)


def unpack_header(data: bytes):
    version, flags, payload_size = struct.unpack('!BBI', data[:6])
    return {'version': version, 'flags': flags, 'payload_size': payload_size}


def encode_varint(value: int) -> bytes:
    result = bytearray()
    while value > 0x7F:
        result.append((value & 0x7F) | 0x80)
        value >>= 7
    result.append(value & 0x7F)
    return bytes(result)


def decode_varint(data: bytes, offset: int = 0):
    result = 0
    shift = 0
    while True:
        byte = data[offset]
        result |= (byte & 0x7F) << shift
        offset += 1
        if not (byte & 0x80):
            break
        shift += 7
    return result, offset


class BinaryFrame:
    __slots__ = ('tag', 'payload')

    def __init__(self, tag: int, payload: bytes):
        self.tag = tag
        self.payload = payload

    def to_bytes(self) -> bytes:
        header = struct.pack('!HI', self.tag, len(self.payload))
        return header + self.payload

    @classmethod
    def from_bytes(cls, data: bytes) -> 'BinaryFrame':
        tag, length = struct.unpack('!HI', data[:6])
        payload = data[6:6 + length]
        return cls(tag, payload)
