"""
Compatibility layer for optional codec backends.
"""
import importlib
from typing import Optional


_OPTIONAL_BACKENDS = {
    'msgpack': 'msgpack',
    'yaml': 'pyyaml',
    'toml': 'tomli',
    'cbor': 'cbor2',
    'bson': 'pymongo',
}


def _try_import(module_name: str):
    try:
        return importlib.import_module(module_name)
    except ImportError:
        return None


def has_backend(name: str) -> bool:
    pkg = _OPTIONAL_BACKENDS.get(name)
    if pkg is None:
        return False
    return _try_import(pkg.split('.')[0]) is not None


def get_optional_codec(name: str):
    if not has_backend(name):
        return None
    if name == 'msgpack':
        mod = _try_import('msgpack')
        return mod
    if name == 'yaml':
        mod = _try_import('yaml')
        return mod
    if name == 'toml':
        mod = _try_import('tomli')
        return mod
    return None


def list_available_backends():
    return [name for name in _OPTIONAL_BACKENDS if has_backend(name)]
