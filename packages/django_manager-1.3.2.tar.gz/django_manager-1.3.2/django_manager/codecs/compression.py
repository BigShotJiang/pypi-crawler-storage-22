"""
Compression utilities.
"""
import gzip
import zlib


def gzip_compress(data: bytes, level: int = 9) -> bytes:
    return gzip.compress(data, compresslevel=level)


def gzip_decompress(data: bytes) -> bytes:
    return gzip.decompress(data)


def zlib_compress(data: bytes, level: int = 6) -> bytes:
    return zlib.compress(data, level)


def zlib_decompress(data: bytes) -> bytes:
    return zlib.decompress(data)
