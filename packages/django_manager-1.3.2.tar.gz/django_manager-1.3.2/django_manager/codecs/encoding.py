"""
Encoding/decoding abstractions.
"""
import json
import base64
from abc import ABC, abstractmethod
from typing import Any


class BaseCodec(ABC):
    @abstractmethod
    def encode(self, data: Any) -> bytes: ...

    @abstractmethod
    def decode(self, raw: bytes) -> Any: ...


class JsonCodec(BaseCodec):
    def encode(self, data):
        return json.dumps(data, default=str, ensure_ascii=False).encode('utf-8')

    def decode(self, raw):
        return json.loads(raw)


class Base64Codec(BaseCodec):
    def encode(self, data):
        if isinstance(data, str):
            data = data.encode('utf-8')
        return base64.b64encode(data)

    def decode(self, raw):
        return base64.b64decode(raw)


class MsgPackCodec(BaseCodec):
    """Placeholder — requires msgpack installed."""
    def encode(self, data):
        try:
            import msgpack
            return msgpack.packb(data, use_bin_type=True)
        except ImportError:
            raise RuntimeError("msgpack not installed")

    def decode(self, raw):
        try:
            import msgpack
            return msgpack.unpackb(raw, raw=False)
        except ImportError:
            raise RuntimeError("msgpack not installed")
