"""
Codec validation and integrity checks.
"""
import hashlib
import hmac
from typing import Optional


def checksum_md5(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()


def checksum_sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def verify_checksum(data: bytes, expected: str, algorithm: str = 'sha256') -> bool:
    if algorithm == 'md5':
        return checksum_md5(data) == expected
    return checksum_sha256(data) == expected


def sign_payload(data: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), data, hashlib.sha256).hexdigest()


def verify_signature(data: bytes, signature: str, secret: str) -> bool:
    expected = sign_payload(data, secret)
    return hmac.compare_digest(expected, signature)


class IntegrityError(Exception):
    pass


def ensure_integrity(data: bytes, checksum: str, algorithm: str = 'sha256'):
    if not verify_checksum(data, checksum, algorithm):
        raise IntegrityError(f"Checksum mismatch ({algorithm})")
