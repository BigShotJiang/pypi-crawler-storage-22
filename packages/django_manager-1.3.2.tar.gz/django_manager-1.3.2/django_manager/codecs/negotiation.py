"""
Format negotiation and content type mapping.
"""
from typing import Dict, Optional


MIME_TO_CODEC: Dict[str, str] = {
    'application/json': 'json',
    'application/octet-stream': 'base64',
    'application/msgpack': 'msgpack',
    'text/plain': 'json',
}

CODEC_TO_MIME: Dict[str, str] = {v: k for k, v in MIME_TO_CODEC.items()}


def negotiate_codec(accept_header: str) -> Optional[str]:
    for mime in accept_header.split(','):
        mime = mime.strip().split(';')[0].strip()
        if mime in MIME_TO_CODEC:
            return MIME_TO_CODEC[mime]
    return 'json'


def get_content_type(codec_name: str) -> str:
    return CODEC_TO_MIME.get(codec_name, 'application/octet-stream')


class ContentNegotiator:
    def __init__(self, supported: tuple = ('json', 'base64')):
        self._supported = supported

    def resolve(self, accept: str) -> str:
        codec = negotiate_codec(accept)
        if codec in self._supported:
            return codec
        return self._supported[0]
