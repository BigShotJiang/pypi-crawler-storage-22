"""
Codec registry and auto-detection.
"""
from typing import Dict, Optional, Type
from .encoding import BaseCodec, JsonCodec, Base64Codec


_registry: Dict[str, Type[BaseCodec]] = {
    'json': JsonCodec,
    'base64': Base64Codec,
}


def register_codec(name: str, codec_cls: Type[BaseCodec]):
    _registry[name] = codec_cls


def get_codec(name: str) -> BaseCodec:
    cls = _registry.get(name)
    if cls is None:
        raise KeyError(f"Unknown codec: {name}")
    return cls()


def detect_codec(data: bytes) -> Optional[str]:
    if data.startswith(b'{') or data.startswith(b'['):
        return 'json'
    try:
        import base64
        base64.b64decode(data, validate=True)
        return 'base64'
    except Exception:
        pass
    return None


def list_codecs():
    return list(_registry.keys())


def auto_decode(data: bytes):
    name = detect_codec(data)
    if name:
        return get_codec(name).decode(data)
    return data
