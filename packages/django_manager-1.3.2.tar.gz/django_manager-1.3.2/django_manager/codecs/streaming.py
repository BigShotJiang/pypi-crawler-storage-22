"""
Streaming codec support for large payloads.
"""
import io
import json
from typing import Any, Generator, Iterator


class StreamEncoder:
    def __init__(self, chunk_size: int = 8192):
        self.chunk_size = chunk_size

    def encode_iter(self, data: Any) -> Generator[bytes, None, None]:
        raw = json.dumps(data, default=str, ensure_ascii=False).encode('utf-8')
        for i in range(0, len(raw), self.chunk_size):
            yield raw[i:i + self.chunk_size]


class StreamDecoder:
    def __init__(self):
        self._buffer = io.BytesIO()

    def feed(self, chunk: bytes):
        self._buffer.write(chunk)

    def decode(self) -> Any:
        self._buffer.seek(0)
        data = self._buffer.read()
        self._buffer = io.BytesIO()
        return json.loads(data)

    def reset(self):
        self._buffer = io.BytesIO()


class LineDelimitedDecoder:
    """Decodes newline-delimited JSON."""
    def decode_lines(self, data: bytes) -> list:
        results = []
        for line in data.split(b'\n'):
            line = line.strip()
            if line:
                results.append(json.loads(line))
        return results
