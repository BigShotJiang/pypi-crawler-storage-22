"""
Text codec utilities and character set operations.
"""
import re
from typing import Optional


ENCODING_ALIASES = {
    'utf8': 'utf-8',
    'utf16': 'utf-16',
    'ascii': 'ascii',
    'latin': 'latin-1',
    'iso8859': 'iso-8859-1',
}


def normalize_encoding(name: str) -> str:
    cleaned = name.lower().replace('-', '').replace('_', '')
    return ENCODING_ALIASES.get(cleaned, name)


def safe_decode(data: bytes, encoding: str = 'utf-8', errors: str = 'replace') -> str:
    enc = normalize_encoding(encoding)
    return data.decode(enc, errors=errors)


def safe_encode(text: str, encoding: str = 'utf-8', errors: str = 'replace') -> bytes:
    enc = normalize_encoding(encoding)
    return text.encode(enc, errors=errors)


def detect_encoding(data: bytes) -> Optional[str]:
    if data.startswith(b'\xef\xbb\xbf'):
        return 'utf-8-sig'
    if data.startswith(b'\xff\xfe'):
        return 'utf-16-le'
    if data.startswith(b'\xfe\xff'):
        return 'utf-16-be'
    try:
        data.decode('utf-8')
        return 'utf-8'
    except UnicodeDecodeError:
        pass
    try:
        data.decode('latin-1')
        return 'latin-1'
    except UnicodeDecodeError:
        return None


def strip_bom(data: bytes) -> bytes:
    for bom in (b'\xef\xbb\xbf', b'\xff\xfe', b'\xfe\xff'):
        if data.startswith(bom):
            return data[len(bom):]
    return data


class TextNormalizer:
    def __init__(self, target_encoding: str = 'utf-8'):
        self.target = target_encoding

    def normalize(self, data: bytes) -> str:
        source = detect_encoding(data) or 'utf-8'
        text = data.decode(source, errors='replace')
        text = re.sub(r'\r\n', '\n', text)
        return text
