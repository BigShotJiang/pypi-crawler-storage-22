"""
Package-level configuration and defaults.
"""
from typing import Any, Dict


_DEFAULTS: Dict[str, Any] = {
    "PAGINATION_PAGE_SIZE": 20,
    "MAX_PAGE_SIZE": 100,
    "TOKEN_HEADER_PREFIX": "Bearer",
    "TOKEN_EXPIRY_HOURS": 24,
    "MAX_UPLOAD_SIZE_MB": 10,
    "CACHE_TTL": 300,
    "LOG_LEVEL": "INFO",
    "RETRY_ATTEMPTS": 3,
    "RETRY_DELAY": 1.0,
    "TRANSPORT_BACKEND": "memory",
}

_user_config: Dict[str, Any] = {}


def configure(**kwargs):
    """Override default settings."""
    _user_config.update(kwargs)


def get_setting(key: str) -> Any:
    """Retrieve a config value with user override support."""
    return _user_config.get(key, _DEFAULTS.get(key))


def reset():
    """Reset user configuration to defaults."""
    _user_config.clear()


def as_dict() -> Dict[str, Any]:
    """Return merged config as a dictionary."""
    merged = dict(_DEFAULTS)
    merged.update(_user_config)
    return merged
