"""
Connector interfaces for data sources.
"""
