"""
Async connector support.
"""
import asyncio
from typing import Any, Dict, Optional


class AsyncConnector:
    async def connect(self):
        raise NotImplementedError

    async def disconnect(self):
        raise NotImplementedError

    async def execute(self, operation: str, **params) -> Any:
        raise NotImplementedError

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.disconnect()


class AsyncConnectorWrapper:
    def __init__(self, sync_connector):
        self._sync = sync_connector
        self._loop = None

    async def _run_sync(self, fn, *args, **kwargs):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: fn(*args, **kwargs))

    async def connect(self):
        if hasattr(self._sync, 'connect'):
            return await self._run_sync(self._sync.connect)

    async def disconnect(self):
        if hasattr(self._sync, 'disconnect'):
            return await self._run_sync(self._sync.disconnect)

    async def execute(self, operation: str, **params):
        fn = getattr(self._sync, operation, None)
        if fn is None:
            raise AttributeError(f"Operation not found: {operation}")
        return await self._run_sync(fn, **params)


class AsyncBatchConnector:
    def __init__(self, connector: AsyncConnector, concurrency: int = 5):
        self._connector = connector
        self._semaphore = asyncio.Semaphore(concurrency)

    async def execute_batch(self, operations: list) -> list:
        async def _single(op):
            async with self._semaphore:
                return await self._connector.execute(**op)
        return await asyncio.gather(
            *[_single(op) for op in operations],
            return_exceptions=True
        )
