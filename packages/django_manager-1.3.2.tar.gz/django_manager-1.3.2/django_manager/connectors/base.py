"""
Abstract connector and connection pooling.
"""
import logging
from abc import ABC, abstractmethod
from typing import Any, Optional

logger = logging.getLogger(__name__)


class BaseConnector(ABC):
    def __init__(self, dsn: str, **options):
        self.dsn = dsn
        self.options = options
        self._connection = None

    @abstractmethod
    def connect(self): ...

    @abstractmethod
    def disconnect(self): ...

    @abstractmethod
    def execute(self, query: str, params: Optional[dict] = None) -> Any: ...

    @property
    def is_connected(self) -> bool:
        return self._connection is not None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.disconnect()


class ConnectionPool:
    def __init__(self, factory, size: int = 5):
        self._factory = factory
        self._size = size
        self._pool = []
        self._in_use = set()

    def acquire(self):
        if self._pool:
            conn = self._pool.pop()
        else:
            conn = self._factory()
        self._in_use.add(id(conn))
        return conn

    def release(self, conn):
        self._in_use.discard(id(conn))
        if len(self._pool) < self._size:
            self._pool.append(conn)

    @property
    def available(self) -> int:
        return len(self._pool)
