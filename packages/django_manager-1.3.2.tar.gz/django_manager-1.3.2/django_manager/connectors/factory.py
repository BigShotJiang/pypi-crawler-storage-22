"""
Connector factory for dynamic instantiation.
"""
from typing import Any, Callable, Dict, Optional, Type


class ConnectorFactory:
    _registry: Dict[str, Callable] = {}

    @classmethod
    def register(cls, name: str, builder: Callable = None):
        if builder is not None:
            cls._registry[name] = builder
            return builder

        def decorator(fn):
            cls._registry[name] = fn
            return fn
        return decorator

    @classmethod
    def create(cls, name: str, **kwargs) -> Any:
        builder = cls._registry.get(name)
        if builder is None:
            raise KeyError(f"Unknown connector type: {name}")
        return builder(**kwargs)

    @classmethod
    def list_types(cls):
        return list(cls._registry.keys())

    @classmethod
    def clear(cls):
        cls._registry.clear()


class ConnectorConfig:
    def __init__(self, connector_type: str, **options):
        self.connector_type = connector_type
        self.options = options

    def build(self):
        return ConnectorFactory.create(self.connector_type, **self.options)

    def to_dict(self) -> dict:
        return {
            'type': self.connector_type,
            'options': self.options,
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'ConnectorConfig':
        return cls(
            connector_type=data['type'],
            **data.get('options', {}),
        )
