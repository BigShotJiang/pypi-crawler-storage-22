"""
Connector health checking.
"""
import time
import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class HealthStatus:
    HEALTHY = 'healthy'
    DEGRADED = 'degraded'
    UNHEALTHY = 'unhealthy'
    UNKNOWN = 'unknown'


class HealthCheck:
    def __init__(self, connector, interval: float = 30.0,
                 timeout: float = 5.0, threshold: int = 3):
        self._connector = connector
        self._interval = interval
        self._timeout = timeout
        self._threshold = threshold
        self._consecutive_failures = 0
        self._last_check = 0.0
        self._last_status = HealthStatus.UNKNOWN

    def check(self) -> str:
        now = time.monotonic()
        if now - self._last_check < self._interval:
            return self._last_status

        self._last_check = now
        try:
            if hasattr(self._connector, 'ping'):
                self._connector.ping()
            elif hasattr(self._connector, 'is_connected'):
                if not self._connector.is_connected():
                    raise ConnectionError("Not connected")
            self._consecutive_failures = 0
            self._last_status = HealthStatus.HEALTHY
        except Exception as e:
            self._consecutive_failures += 1
            logger.warning("Health check failed (%d): %s",
                           self._consecutive_failures, e)
            if self._consecutive_failures >= self._threshold:
                self._last_status = HealthStatus.UNHEALTHY
            else:
                self._last_status = HealthStatus.DEGRADED

        return self._last_status

    @property
    def is_healthy(self) -> bool:
        return self.check() == HealthStatus.HEALTHY

    def status_report(self) -> dict:
        return {
            'status': self.check(),
            'consecutive_failures': self._consecutive_failures,
            'last_check': self._last_check,
            'connector': type(self._connector).__name__,
        }
