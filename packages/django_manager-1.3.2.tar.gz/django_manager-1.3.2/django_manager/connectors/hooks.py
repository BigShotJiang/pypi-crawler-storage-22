"""
Connector event hooks.
"""
from typing import Callable, List


class ConnectorHooks:
    def __init__(self):
        self._on_connect: List[Callable] = []
        self._on_disconnect: List[Callable] = []
        self._on_error: List[Callable] = []
        self._on_execute: List[Callable] = []

    def on_connect(self, fn: Callable):
        self._on_connect.append(fn)
        return fn

    def on_disconnect(self, fn: Callable):
        self._on_disconnect.append(fn)
        return fn

    def on_error(self, fn: Callable):
        self._on_error.append(fn)
        return fn

    def on_execute(self, fn: Callable):
        self._on_execute.append(fn)
        return fn

    def fire_connect(self, connector, **kwargs):
        for fn in self._on_connect:
            fn(connector, **kwargs)

    def fire_disconnect(self, connector, **kwargs):
        for fn in self._on_disconnect:
            fn(connector, **kwargs)

    def fire_error(self, connector, error: Exception, **kwargs):
        for fn in self._on_error:
            fn(connector, error, **kwargs)

    def fire_execute(self, connector, operation: str, **kwargs):
        for fn in self._on_execute:
            fn(connector, operation, **kwargs)


class HookedConnector:
    def __init__(self, connector, hooks: ConnectorHooks = None):
        self._connector = connector
        self._hooks = hooks or ConnectorHooks()

    def connect(self, **kwargs):
        result = self._connector.connect(**kwargs)
        self._hooks.fire_connect(self._connector, **kwargs)
        return result

    def disconnect(self, **kwargs):
        self._hooks.fire_disconnect(self._connector, **kwargs)
        return self._connector.disconnect(**kwargs)

    def execute(self, operation: str, **params):
        self._hooks.fire_execute(self._connector, operation, **params)
        try:
            return self._connector.execute(operation, **params)
        except Exception as e:
            self._hooks.fire_error(self._connector, e, operation=operation)
            raise
