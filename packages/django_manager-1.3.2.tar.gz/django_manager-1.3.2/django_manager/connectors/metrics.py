"""
Connector metrics collection.
"""
import time
import threading
from collections import defaultdict
from typing import Dict


class ConnectorMetrics:
    def __init__(self):
        self._lock = threading.Lock()
        self._calls: Dict[str, int] = defaultdict(int)
        self._errors: Dict[str, int] = defaultdict(int)
        self._latencies: Dict[str, list] = defaultdict(list)
        self._started = time.monotonic()

    def record_call(self, operation: str, duration: float, error: bool = False):
        with self._lock:
            self._calls[operation] += 1
            self._latencies[operation].append(duration)
            if error:
                self._errors[operation] += 1

    def get_stats(self, operation: str) -> dict:
        with self._lock:
            calls = self._calls.get(operation, 0)
            errors = self._errors.get(operation, 0)
            latencies = self._latencies.get(operation, [])
            avg_latency = sum(latencies) / len(latencies) if latencies else 0
            return {
                'calls': calls,
                'errors': errors,
                'error_rate': errors / calls if calls else 0,
                'avg_latency': round(avg_latency, 4),
                'max_latency': round(max(latencies), 4) if latencies else 0,
            }

    def summary(self) -> dict:
        with self._lock:
            return {
                'uptime': time.monotonic() - self._started,
                'operations': {
                    op: self.get_stats(op) for op in self._calls
                },
                'total_calls': sum(self._calls.values()),
                'total_errors': sum(self._errors.values()),
            }

    def reset(self):
        with self._lock:
            self._calls.clear()
            self._errors.clear()
            self._latencies.clear()
            self._started = time.monotonic()


def timed_operation(metrics: ConnectorMetrics, operation: str):
    """Context manager for timing an operation."""
    class _Timer:
        def __enter__(self):
            self._start = time.monotonic()
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            duration = time.monotonic() - self._start
            metrics.record_call(operation, duration, error=exc_type is not None)
    return _Timer()
