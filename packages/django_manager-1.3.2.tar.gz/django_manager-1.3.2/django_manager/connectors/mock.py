"""
Mock connector for testing.
"""
from .base import BaseConnector


class MockConnector(BaseConnector):
    def __init__(self, dsn='mock://', **opts):
        super().__init__(dsn, **opts)
        self._store = {}

    def connect(self):
        self._connection = True

    def disconnect(self):
        self._connection = None

    def execute(self, query, params=None):
        return {'query': query, 'params': params, 'rows': []}

    def set(self, key, value):
        self._store[key] = value

    def get(self, key):
        return self._store.get(key)
