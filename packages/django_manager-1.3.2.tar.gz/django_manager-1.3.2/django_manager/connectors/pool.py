"""
Connector pool management.
"""
import threading
import time
from collections import deque
from typing import Optional


class ConnectorPool:
    def __init__(self, factory, max_size: int = 10, max_idle: float = 300.0):
        self._factory = factory
        self._max_size = max_size
        self._max_idle = max_idle
        self._available: deque = deque()
        self._in_use = set()
        self._lock = threading.Lock()

    def acquire(self):
        with self._lock:
            self._cleanup_idle()
            if self._available:
                conn = self._available.popleft()
                self._in_use.add(id(conn))
                return conn
            if len(self._in_use) >= self._max_size:
                raise RuntimeError("Connector pool exhausted")
            conn = self._factory()
            self._in_use.add(id(conn))
            return conn

    def release(self, conn):
        with self._lock:
            self._in_use.discard(id(conn))
            self._available.append((time.monotonic(), conn))

    def _cleanup_idle(self):
        now = time.monotonic()
        fresh = deque()
        while self._available:
            item = self._available.popleft()
            ts, conn = item
            if now - ts < self._max_idle:
                fresh.append(item)
        self._available = fresh

    @property
    def active(self) -> int:
        return len(self._in_use)

    @property
    def idle(self) -> int:
        return len(self._available)

    def close_all(self):
        with self._lock:
            self._available.clear()
            self._in_use.clear()
