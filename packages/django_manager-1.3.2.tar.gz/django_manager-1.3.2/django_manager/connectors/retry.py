"""
Connector retry wrapper.
"""
import time
import random
import logging
from typing import Callable, Optional, Tuple, Type

logger = logging.getLogger(__name__)


class RetryableConnector:
    def __init__(self, connector, max_retries: int = 3,
                 base_delay: float = 0.5, max_delay: float = 30.0,
                 retryable: Tuple[Type[Exception], ...] = (Exception,)):
        self._connector = connector
        self._max_retries = max_retries
        self._base_delay = base_delay
        self._max_delay = max_delay
        self._retryable = retryable

    def _delay(self, attempt: int) -> float:
        delay = self._base_delay * (2 ** attempt)
        delay = min(delay, self._max_delay)
        return delay + random.uniform(0, delay * 0.1)

    def execute(self, method: str, *args, **kwargs):
        last_err = None
        for attempt in range(self._max_retries + 1):
            try:
                fn = getattr(self._connector, method)
                return fn(*args, **kwargs)
            except self._retryable as e:
                last_err = e
                if attempt < self._max_retries:
                    d = self._delay(attempt)
                    logger.warning(
                        "Connector retry %d/%d: %s (%.2fs)",
                        attempt + 1, self._max_retries, e, d
                    )
                    time.sleep(d)
        raise last_err

    def __getattr__(self, name):
        return getattr(self._connector, name)
