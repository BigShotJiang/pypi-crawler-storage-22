"""
Deprecation and warning utilities.
"""
import warnings
import functools


def deprecated(reason: str = "", version: str = ""):
    """Decorator to mark functions as deprecated."""
    def decorator(func):
        msg = f"{func.__name__} is deprecated"
        if version:
            msg += f" since {version}"
        if reason:
            msg += f": {reason}"

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            warnings.warn(msg, DeprecationWarning, stacklevel=2)
            return func(*args, **kwargs)

        wrapper.__deprecated__ = msg
        return wrapper
    return decorator


def pending_removal(version: str):
    """Mark something for removal in a future version."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            warnings.warn(
                f"{func.__name__} will be removed in {version}",
                FutureWarning,
                stacklevel=2,
            )
            return func(*args, **kwargs)
        return wrapper
    return decorator
