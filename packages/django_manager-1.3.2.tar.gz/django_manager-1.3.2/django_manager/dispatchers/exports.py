"""
Export utilities for generating reports.
"""
import csv
import io
from typing import List


def queryset_to_csv(queryset, fields: List[str]) -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(fields)
    for obj in queryset:
        writer.writerow([getattr(obj, f, '') for f in fields])
    return output.getvalue()


def enrollment_report(queryset) -> str:
    fields = ['id', 'user_id', 'course_id', 'status', 'date', 'order_id']
    return queryset_to_csv(queryset, fields)


class ReportBuilder:
    """Fluent interface for building data reports."""

    def __init__(self, queryset):
        self._qs = queryset
        self._fields = []
        self._filters = {}

    def select(self, *fields):
        self._fields = list(fields)
        return self

    def where(self, **filters):
        self._filters.update(filters)
        return self

    def to_csv(self) -> str:
        qs = self._qs.filter(**self._filters) if self._filters else self._qs
        return queryset_to_csv(qs, self._fields)

    def to_dicts(self) -> list:
        qs = self._qs.filter(**self._filters) if self._filters else self._qs
        return list(qs.values(*self._fields))
