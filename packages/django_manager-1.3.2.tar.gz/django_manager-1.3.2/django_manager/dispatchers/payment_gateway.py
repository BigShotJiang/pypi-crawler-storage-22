"""
Payment gateway integration stubs.
"""
import hashlib
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class PaymentGateway:
    """Abstract payment provider interface."""

    def create_payment(self, amount: float, currency: str, order_id: str, **kw) -> dict:
        raise NotImplementedError

    def verify_payment(self, payment_id: str) -> dict:
        raise NotImplementedError

    def refund(self, payment_id: str, amount: Optional[float] = None) -> dict:
        raise NotImplementedError


class MockPaymentGateway(PaymentGateway):
    """In-memory payment gateway for testing."""

    _payments = {}

    def create_payment(self, amount, currency, order_id, **kw):
        pid = hashlib.md5(order_id.encode()).hexdigest()[:12]
        self._payments[pid] = {
            'id': pid,
            'amount': amount,
            'currency': currency,
            'order_id': order_id,
            'status': 'pending',
        }
        return {'payment_id': pid, 'pay_url': f'https://mock-pay.test/{pid}'}

    def verify_payment(self, payment_id):
        p = self._payments.get(payment_id, {})
        return {'status': p.get('status', 'unknown')}

    def refund(self, payment_id, amount=None):
        if payment_id in self._payments:
            self._payments[payment_id]['status'] = 'refunded'
        return {'status': 'refunded'}


def compute_signature(payload: str, secret: str) -> str:
    return hashlib.sha256(f"{payload}{secret}".encode()).hexdigest()
