"""
Event emitters and pub/sub primitives.
"""
