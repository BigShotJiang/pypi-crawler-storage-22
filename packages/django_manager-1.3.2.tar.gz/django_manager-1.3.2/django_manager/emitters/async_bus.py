"""
Async event bus support.
"""
import asyncio
from collections import defaultdict
from typing import Any, Callable, Dict, List


class AsyncEventBus:
    def __init__(self):
        self._handlers: Dict[str, List[Callable]] = defaultdict(list)

    def on(self, event: str, handler: Callable):
        self._handlers[event].append(handler)

    def off(self, event: str, handler: Callable):
        handlers = self._handlers.get(event, [])
        try:
            handlers.remove(handler)
        except ValueError:
            pass

    async def emit(self, event: str, **kwargs):
        handlers = self._handlers.get(event, []) + self._handlers.get('*', [])
        tasks = []
        for handler in handlers:
            if asyncio.iscoroutinefunction(handler):
                tasks.append(handler(event, **kwargs))
            else:
                handler(event, **kwargs)
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def emit_sequential(self, event: str, **kwargs):
        handlers = self._handlers.get(event, []) + self._handlers.get('*', [])
        for handler in handlers:
            if asyncio.iscoroutinefunction(handler):
                await handler(event, **kwargs)
            else:
                handler(event, **kwargs)

    def clear(self):
        self._handlers.clear()
