"""
Event bus implementation.
"""
import logging
from collections import defaultdict
from typing import Any, Callable, Dict, List

logger = logging.getLogger(__name__)


class EventBus:
    def __init__(self):
        self._listeners: Dict[str, List[Callable]] = defaultdict(list)

    def on(self, event: str, handler: Callable):
        self._listeners[event].append(handler)

    def off(self, event: str, handler: Callable):
        self._listeners[event] = [h for h in self._listeners[event] if h != handler]

    def emit(self, event: str, *args, **kwargs):
        for handler in self._listeners.get(event, []):
            try:
                handler(*args, **kwargs)
            except Exception as exc:
                logger.error("Handler for '%s' failed: %s", event, exc)

    def once(self, event: str, handler: Callable):
        def wrapper(*args, **kwargs):
            handler(*args, **kwargs)
            self.off(event, wrapper)
        self.on(event, wrapper)

    def clear(self, event: str = None):
        if event:
            self._listeners.pop(event, None)
        else:
            self._listeners.clear()
