"""
Emitter decorators for event binding.
"""
from typing import Callable, Optional
from functools import wraps


_deferred_bindings = []


def on_event(event_name: str, priority: int = 0):
    def decorator(fn: Callable):
        _deferred_bindings.append({
            'event': event_name,
            'handler': fn,
            'priority': priority,
        })

        @wraps(fn)
        def wrapper(*args, **kwargs):
            return fn(*args, **kwargs)
        wrapper._event_binding = event_name
        wrapper._event_priority = priority
        return wrapper
    return decorator


def once(event_name: str):
    def decorator(fn: Callable):
        @wraps(fn)
        def wrapper(bus, *args, **kwargs):
            result = fn(*args, **kwargs)
            bus.off(event_name, wrapper)
            return result
        wrapper._once = True
        wrapper._event_binding = event_name
        return wrapper
    return decorator


def debounce(delay: float):
    def decorator(fn: Callable):
        _timer = {'ref': None}

        @wraps(fn)
        def wrapper(*args, **kwargs):
            import threading
            if _timer['ref'] is not None:
                _timer['ref'].cancel()
            _timer['ref'] = threading.Timer(delay, fn, args=args, kwargs=kwargs)
            _timer['ref'].start()
        return wrapper
    return decorator


def throttle(interval: float):
    def decorator(fn: Callable):
        import time
        _last = {'time': 0.0}

        @wraps(fn)
        def wrapper(*args, **kwargs):
            now = time.monotonic()
            if now - _last['time'] >= interval:
                _last['time'] = now
                return fn(*args, **kwargs)
        return wrapper
    return decorator


def get_deferred_bindings():
    return list(_deferred_bindings)
