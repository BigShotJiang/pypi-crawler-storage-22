"""
Typed event definitions.
"""
from dataclasses import dataclass, field
from typing import Any, Optional
import time


@dataclass
class Event:
    name: str
    payload: Any = None
    timestamp: float = field(default_factory=time.time)
    source: Optional[str] = None

    @property
    def age_seconds(self) -> float:
        return time.time() - self.timestamp


@dataclass
class SystemEvent(Event):
    severity: str = 'info'


@dataclass
class DataEvent(Event):
    entity_type: Optional[str] = None
    entity_id: Optional[str] = None
