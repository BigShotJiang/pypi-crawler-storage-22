"""
Event filtering and routing.
"""
from typing import Any, Callable, Dict, List, Optional
import re


class EventFilter:
    def match(self, event_name: str, payload: Dict[str, Any]) -> bool:
        raise NotImplementedError


class NameFilter(EventFilter):
    def __init__(self, pattern: str):
        self._regex = re.compile(pattern)

    def match(self, event_name: str, payload=None) -> bool:
        return bool(self._regex.match(event_name))


class PayloadFilter(EventFilter):
    def __init__(self, key: str, value: Any):
        self._key = key
        self._value = value

    def match(self, event_name: str, payload: Dict[str, Any] = None) -> bool:
        if payload is None:
            return False
        return payload.get(self._key) == self._value


class CompositeFilter(EventFilter):
    def __init__(self, filters: List[EventFilter], mode: str = 'all'):
        self._filters = filters
        self._mode = mode

    def match(self, event_name: str, payload=None) -> bool:
        fn = all if self._mode == 'all' else any
        return fn(f.match(event_name, payload) for f in self._filters)


class EventRouter:
    def __init__(self):
        self._routes: List[tuple] = []

    def add_route(self, filter_: EventFilter, handler: Callable):
        self._routes.append((filter_, handler))

    def route(self, event_name: str, payload: Dict[str, Any]):
        results = []
        for filter_, handler in self._routes:
            if filter_.match(event_name, payload):
                result = handler(event_name, payload)
                results.append(result)
        return results
