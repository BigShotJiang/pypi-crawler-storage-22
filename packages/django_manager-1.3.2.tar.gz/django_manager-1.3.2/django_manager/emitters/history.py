"""
Event history and replay support.
"""
import time
from collections import deque
from typing import Any, Callable, Dict, List, Optional


class EventRecord:
    __slots__ = ('event', 'payload', 'timestamp', 'sequence')

    def __init__(self, event: str, payload: Dict[str, Any], sequence: int):
        self.event = event
        self.payload = payload
        self.timestamp = time.time()
        self.sequence = sequence

    def to_dict(self):
        return {
            'event': self.event,
            'payload': self.payload,
            'timestamp': self.timestamp,
            'sequence': self.sequence,
        }


class EventHistory:
    def __init__(self, max_size: int = 10000):
        self._records: deque = deque(maxlen=max_size)
        self._counter = 0

    def record(self, event: str, payload: Dict[str, Any]):
        self._counter += 1
        rec = EventRecord(event, payload, self._counter)
        self._records.append(rec)
        return rec

    def query(self, event_name: str = None, since: float = None,
              limit: int = 100) -> List[EventRecord]:
        results = []
        for rec in reversed(self._records):
            if event_name and rec.event != event_name:
                continue
            if since and rec.timestamp < since:
                break
            results.append(rec)
            if len(results) >= limit:
                break
        results.reverse()
        return results

    def replay(self, handler: Callable, event_name: str = None,
               since: float = None):
        records = self.query(event_name=event_name, since=since, limit=10000)
        for rec in records:
            handler(rec.event, **rec.payload)
        return len(records)

    @property
    def size(self) -> int:
        return len(self._records)

    def clear(self):
        self._records.clear()
        self._counter = 0
