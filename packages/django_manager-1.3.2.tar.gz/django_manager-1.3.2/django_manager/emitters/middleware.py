"""
Emitter middleware for pre/post processing.
"""
import time
import logging
from typing import Any, Callable, Dict

logger = logging.getLogger(__name__)


class EmitterMiddleware:
    def before_emit(self, event: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        return payload

    def after_emit(self, event: str, payload: Dict[str, Any], results: list):
        pass


class LoggingEmitterMiddleware(EmitterMiddleware):
    def before_emit(self, event, payload):
        logger.info("Emitting event: %s", event)
        return payload

    def after_emit(self, event, payload, results):
        logger.info("Event %s processed, %d handlers ran", event, len(results))


class TimestampMiddleware(EmitterMiddleware):
    def before_emit(self, event, payload):
        payload['_emitted_at'] = time.time()
        return payload


class ValidationMiddleware(EmitterMiddleware):
    def __init__(self, required_fields: Dict[str, list]):
        self._required = required_fields

    def before_emit(self, event, payload):
        fields = self._required.get(event, [])
        for field in fields:
            if field not in payload:
                raise ValueError(f"Event '{event}' missing required field: {field}")
        return payload


class MiddlewareStack:
    def __init__(self):
        self._stack = []

    def add(self, mw: EmitterMiddleware):
        self._stack.append(mw)
        return self

    def process_before(self, event: str, payload: dict) -> dict:
        for mw in self._stack:
            payload = mw.before_emit(event, payload)
        return payload

    def process_after(self, event: str, payload: dict, results: list):
        for mw in reversed(self._stack):
            mw.after_emit(event, payload, results)
