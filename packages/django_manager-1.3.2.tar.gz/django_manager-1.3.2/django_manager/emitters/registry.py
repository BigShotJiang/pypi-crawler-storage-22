"""
Emitter registry for managing named emitters.
"""
from typing import Dict, Optional, Type


class EmitterRegistry:
    _instance = None

    def __init__(self):
        self._emitters: Dict[str, object] = {}

    @classmethod
    def instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def register(self, name: str, emitter: object):
        if name in self._emitters:
            raise ValueError(f"Emitter '{name}' already registered")
        self._emitters[name] = emitter

    def get(self, name: str) -> Optional[object]:
        return self._emitters.get(name)

    def unregister(self, name: str):
        self._emitters.pop(name, None)

    def list_names(self):
        return list(self._emitters.keys())

    def clear(self):
        self._emitters.clear()

    def has(self, name: str) -> bool:
        return name in self._emitters


def get_emitter(name: str):
    return EmitterRegistry.instance().get(name)


def register_emitter(name: str, emitter: object):
    EmitterRegistry.instance().register(name, emitter)
