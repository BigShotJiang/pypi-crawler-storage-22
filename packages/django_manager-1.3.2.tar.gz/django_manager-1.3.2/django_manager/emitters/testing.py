"""
Testing utilities for emitters.
"""
from collections import defaultdict
from typing import Any, Callable, Dict, List


class EventCollector:
    def __init__(self):
        self.events: List[Dict[str, Any]] = []

    def handler(self, event_name: str, **kwargs):
        self.events.append({'event': event_name, 'payload': kwargs})

    def clear(self):
        self.events.clear()

    def count(self, event_name: str = None) -> int:
        if event_name is None:
            return len(self.events)
        return sum(1 for e in self.events if e['event'] == event_name)

    def first(self, event_name: str = None):
        for e in self.events:
            if event_name is None or e['event'] == event_name:
                return e
        return None

    def last(self, event_name: str = None):
        for e in reversed(self.events):
            if event_name is None or e['event'] == event_name:
                return e
        return None

    def payloads(self, event_name: str) -> list:
        return [e['payload'] for e in self.events if e['event'] == event_name]


class MockBus:
    def __init__(self):
        self._collector = EventCollector()
        self._handlers: Dict[str, List[Callable]] = defaultdict(list)

    def on(self, event: str, handler: Callable):
        self._handlers[event].append(handler)

    def off(self, event: str, handler: Callable):
        try:
            self._handlers[event].remove(handler)
        except ValueError:
            pass

    def emit(self, event: str, **kwargs):
        self._collector.handler(event, **kwargs)
        for h in self._handlers.get(event, []):
            h(event, **kwargs)

    @property
    def collected(self) -> EventCollector:
        return self._collector

    def assert_emitted(self, event_name: str, times: int = None):
        count = self._collector.count(event_name)
        if count == 0:
            raise AssertionError(f"Event '{event_name}' was never emitted")
        if times is not None and count != times:
            raise AssertionError(
                f"Event '{event_name}' emitted {count} times, expected {times}"
            )

    def assert_not_emitted(self, event_name: str):
        if self._collector.count(event_name) > 0:
            raise AssertionError(f"Event '{event_name}' was emitted unexpectedly")
