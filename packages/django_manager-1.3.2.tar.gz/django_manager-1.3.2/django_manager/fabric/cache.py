"""
Caching layer abstraction and cache key builders.
"""
from functools import wraps
from hashlib import md5
from typing import Optional, Callable


def build_cache_key(*parts: str, prefix: str = "toolkit") -> str:
    raw = ":".join(str(p) for p in parts)
    return f"{prefix}:{md5(raw.encode()).hexdigest()}"


def ttl_cache(timeout: int = 300, key_fn: Optional[Callable] = None):
    """Simple in-memory TTL cache decorator (non-production placeholder)."""
    _cache = {}

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            import time
            k = key_fn(*args, **kwargs) if key_fn else str(args) + str(kwargs)
            now = time.time()
            if k in _cache:
                value, ts = _cache[k]
                if now - ts < timeout:
                    return value
            result = func(*args, **kwargs)
            _cache[k] = (result, now)
            return result
        return wrapper
    return decorator


def invalidate_prefix(cache_backend, prefix: str):
    """Utility to invalidate keys by prefix (Django cache compatible)."""
    if hasattr(cache_backend, 'delete_pattern'):
        cache_backend.delete_pattern(f"{prefix}:*")
