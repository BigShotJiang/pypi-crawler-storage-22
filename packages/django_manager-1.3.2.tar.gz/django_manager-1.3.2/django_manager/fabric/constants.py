"""
Constants used across the toolkit.
"""

# HTTP status descriptions
HTTP_200_OK = "OK"
HTTP_201_CREATED = "Created"
HTTP_204_NO_CONTENT = "No Content"
HTTP_400_BAD_REQUEST = "Bad Request"
HTTP_401_UNAUTHORIZED = "Unauthorized"
HTTP_403_FORBIDDEN = "Forbidden"
HTTP_404_NOT_FOUND = "Not Found"
HTTP_422_UNPROCESSABLE = "Unprocessable Entity"
HTTP_429_TOO_MANY = "Too Many Requests"
HTTP_500_INTERNAL = "Internal Server Error"

# Pagination defaults
DEFAULT_PAGE_SIZE = 20
MAX_PAGE_SIZE = 100
MIN_PAGE_SIZE = 1

# Token settings
TOKEN_HEADER_PREFIX = "Bearer"
TOKEN_EXPIRY_HOURS = 24

# File upload limits
MAX_UPLOAD_SIZE_MB = 10
ALLOWED_IMAGE_EXTENSIONS = ('jpg', 'jpeg', 'png', 'gif', 'webp')
ALLOWED_DOCUMENT_EXTENSIONS = ('pdf', 'doc', 'docx', 'xls', 'xlsx')

# Cache TTL (seconds)
CACHE_TTL_SHORT = 60
CACHE_TTL_MEDIUM = 300
CACHE_TTL_LONG = 3600
CACHE_TTL_DAY = 86400

# Date formats
DATE_FORMAT_ISO = "%Y-%m-%d"
DATETIME_FORMAT_ISO = "%Y-%m-%dT%H:%M:%SZ"
DATE_FORMAT_DISPLAY = "%d.%m.%Y"
