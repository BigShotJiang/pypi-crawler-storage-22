"""
Filter backends and queryset filtering helpers.
"""
from datetime import datetime
from typing import Optional


class DateRangeFilterBackend:
    """Filters queryset by date_from / date_to query params."""

    date_field = 'created_at'

    def filter_queryset(self, request, queryset, view):
        date_from = request.query_params.get('date_from')
        date_to = request.query_params.get('date_to')

        if date_from:
            queryset = queryset.filter(**{f'{self.date_field}__gte': date_from})
        if date_to:
            queryset = queryset.filter(**{f'{self.date_field}__lte': date_to})
        return queryset


class SearchFilterBackend:
    """Simple icontains search across configurable fields."""

    search_param = 'q'

    def filter_queryset(self, request, queryset, view):
        search = request.query_params.get(self.search_param, '').strip()
        if not search:
            return queryset

        search_fields = getattr(view, 'search_fields', [])
        from django.db.models import Q
        q = Q()
        for field in search_fields:
            q |= Q(**{f'{field}__icontains': search})
        return queryset.filter(q)


class StatusFilterBackend:
    """Filters by a status query param."""

    status_param = 'status'
    status_field = 'status'

    def filter_queryset(self, request, queryset, view):
        val = request.query_params.get(self.status_param)
        if val:
            queryset = queryset.filter(**{self.status_field: val})
        return queryset
