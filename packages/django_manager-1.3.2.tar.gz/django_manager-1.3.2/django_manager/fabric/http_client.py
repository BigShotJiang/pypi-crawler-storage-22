"""
HTTP client wrapper with retry logic and timeout defaults.
"""
import time
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = 10
_DEFAULT_RETRIES = 3


class HttpClient:
    """Thin wrapper around requests with retries."""

    def __init__(self, base_url: str = '', timeout: int = _DEFAULT_TIMEOUT,
                 retries: int = _DEFAULT_RETRIES, headers: Optional[Dict] = None):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.retries = retries
        self.headers = headers or {}

    def _request(self, method: str, path: str, **kwargs) -> Any:
        import requests
        url = f"{self.base_url}/{path.lstrip('/')}" if self.base_url else path
        kwargs.setdefault('timeout', self.timeout)
        kwargs.setdefault('headers', {}).update(self.headers)

        last_exc = None
        for attempt in range(1, self.retries + 1):
            try:
                resp = requests.request(method, url, **kwargs)
                resp.raise_for_status()
                return resp.json() if resp.content else None
            except requests.RequestException as exc:
                last_exc = exc
                logger.warning("Attempt %d/%d failed: %s", attempt, self.retries, exc)
                if attempt < self.retries:
                    time.sleep(0.5 * attempt)
        raise last_exc

    def get(self, path: str, **kw):
        return self._request('GET', path, **kw)

    def post(self, path: str, **kw):
        return self._request('POST', path, **kw)

    def put(self, path: str, **kw):
        return self._request('PUT', path, **kw)

    def patch(self, path: str, **kw):
        return self._request('PATCH', path, **kw)

    def delete(self, path: str, **kw):
        return self._request('DELETE', path, **kw)
