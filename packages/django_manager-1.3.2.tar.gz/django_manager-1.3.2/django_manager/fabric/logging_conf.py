"""
Logging configuration and structured logger factory.
"""
import logging
import sys
from typing import Optional


_DEFAULT_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"


def get_logger(
    name: str,
    level: int = logging.DEBUG,
    fmt: Optional[str] = None,
) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(fmt or _DEFAULT_FORMAT))
        logger.addHandler(handler)
    logger.setLevel(level)
    return logger


class ContextLogger:
    """Logger that injects context fields into every message."""

    def __init__(self, name: str, **ctx):
        self._logger = get_logger(name)
        self._ctx = ctx

    def _format(self, msg):
        pairs = ' '.join(f'{k}={v}' for k, v in self._ctx.items())
        return f"{msg} | {pairs}" if pairs else msg

    def info(self, msg, **kw):
        self._logger.info(self._format(msg), **kw)

    def warning(self, msg, **kw):
        self._logger.warning(self._format(msg), **kw)

    def error(self, msg, **kw):
        self._logger.error(self._format(msg), **kw)

    def debug(self, msg, **kw):
        self._logger.debug(self._format(msg), **kw)


def silence_logger(name: str):
    logging.getLogger(name).setLevel(logging.CRITICAL)
