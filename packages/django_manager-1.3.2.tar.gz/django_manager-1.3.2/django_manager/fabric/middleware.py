"""
Middleware components for request/response processing.
"""
import time
import logging

logger = logging.getLogger(__name__)


class RequestTimingMiddleware:
    """Logs request processing time."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        start = time.monotonic()
        response = self.get_response(request)
        duration = time.monotonic() - start
        logger.debug(
            "%s %s completed in %.3fs",
            request.method, request.path, duration,
        )
        response['X-Request-Duration'] = f"{duration:.4f}"
        return response


class JsonContentTypeMiddleware:
    """Ensures API responses have application/json content type."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        if request.path.startswith('/api/'):
            response['Content-Type'] = 'application/json; charset=utf-8'
        return response


class CORSSimpleMiddleware:
    """Minimal CORS headers for development."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response['Access-Control-Allow-Origin'] = '*'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
        response['Access-Control-Allow-Methods'] = 'GET, POST, PUT, PATCH, DELETE, OPTIONS'
        return response
