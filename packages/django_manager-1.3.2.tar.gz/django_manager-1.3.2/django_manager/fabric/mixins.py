"""
Mixin classes for DRF viewsets and views.
"""
from rest_framework.response import Response
from rest_framework import status


class BulkCreateMixin:
    """Adds bulk creation endpoint to a viewset."""

    def bulk_create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data, many=True)
        serializer.is_valid(raise_exception=True)
        self.perform_bulk_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def perform_bulk_create(self, serializer):
        serializer.save()


class SoftDeleteMixin:
    """Overrides destroy to set is_active=False instead of deleting."""

    def perform_destroy(self, instance):
        instance.is_active = False
        instance.save(update_fields=['is_active'])


class ActionSerializerMixin:
    """Use different serializers per action."""
    serializer_classes = {}

    def get_serializer_class(self):
        return self.serializer_classes.get(
            self.action, super().get_serializer_class()
        )


class OrderingMixin:
    """Adds default ordering support."""
    default_ordering = '-created_at'

    def get_queryset(self):
        qs = super().get_queryset()
        ordering = self.request.query_params.get('ordering', self.default_ordering)
        return qs.order_by(ordering)
