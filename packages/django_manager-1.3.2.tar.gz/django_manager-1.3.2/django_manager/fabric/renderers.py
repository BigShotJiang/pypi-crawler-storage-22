"""
Custom renderers for various output formats.
"""
import csv
import io
from rest_framework.renderers import BaseRenderer


class PlainTextRenderer(BaseRenderer):
    media_type = 'text/plain'
    format = 'txt'
    charset = 'utf-8'

    def render(self, data, accepted_media_type=None, renderer_context=None):
        if isinstance(data, str):
            return data
        return str(data)


class CSVRenderer(BaseRenderer):
    media_type = 'text/csv'
    format = 'csv'
    charset = 'utf-8'

    def render(self, data, accepted_media_type=None, renderer_context=None):
        if not data:
            return ''
        if isinstance(data, dict) and 'data' in data:
            data = data['data']
        if not isinstance(data, list):
            data = [data]

        output = io.StringIO()
        if data and isinstance(data[0], dict):
            writer = csv.DictWriter(output, fieldnames=data[0].keys())
            writer.writeheader()
            writer.writerows(data)
        return output.getvalue()


class XMLRenderer(BaseRenderer):
    media_type = 'application/xml'
    format = 'xml'
    charset = 'utf-8'

    def render(self, data, accepted_media_type=None, renderer_context=None):
        from xml.etree.ElementTree import Element, SubElement, tostring
        root = Element('response')
        self._build(root, data)
        return tostring(root, encoding='unicode')

    def _build(self, parent, data):
        from xml.etree.ElementTree import SubElement
        if isinstance(data, dict):
            for key, val in data.items():
                child = SubElement(parent, str(key))
                self._build(child, val)
        elif isinstance(data, (list, tuple)):
            for item in data:
                child = SubElement(parent, 'item')
                self._build(child, item)
        else:
            parent.text = str(data) if data is not None else ''
