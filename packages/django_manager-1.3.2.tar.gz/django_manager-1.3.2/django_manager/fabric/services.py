"""
Base service layer classes for business logic encapsulation.
"""
import logging
from typing import Any, Dict, Optional, Type

from django.db import models, transaction

logger = logging.getLogger(__name__)


class BaseService:
    """Abstract base for service classes."""

    model: Optional[Type[models.Model]] = None

    @classmethod
    def get_queryset(cls):
        assert cls.model is not None, "model must be set"
        return cls.model.objects.all()

    @classmethod
    def get_by_id(cls, pk: Any):
        return cls.get_queryset().filter(pk=pk).first()

    @classmethod
    def exists(cls, **filters) -> bool:
        return cls.get_queryset().filter(**filters).exists()

    @classmethod
    @transaction.atomic
    def create(cls, **data):
        return cls.model.objects.create(**data)

    @classmethod
    @transaction.atomic
    def update(cls, pk: Any, **data):
        obj = cls.get_by_id(pk)
        if obj is None:
            return None
        for attr, value in data.items():
            setattr(obj, attr, value)
        obj.save(update_fields=list(data.keys()))
        return obj

    @classmethod
    @transaction.atomic
    def delete(cls, pk: Any) -> bool:
        obj = cls.get_by_id(pk)
        if obj is None:
            return False
        obj.delete()
        return True


class ReadOnlyService(BaseService):
    """Service that only exposes read operations."""

    @classmethod
    def create(cls, **data):
        raise NotImplementedError("Read-only service")

    @classmethod
    def update(cls, pk, **data):
        raise NotImplementedError("Read-only service")

    @classmethod
    def delete(cls, pk):
        raise NotImplementedError("Read-only service")
