"""
Signal utilities and common signal handlers.
"""
import logging
from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver

logger = logging.getLogger(__name__)


def log_model_save(sender, instance, created, **kwargs):
    action = "created" if created else "updated"
    logger.info("%s %s: pk=%s", sender.__name__, action, instance.pk)


def log_model_delete(sender, instance, **kwargs):
    logger.info("%s deleted: pk=%s", sender.__name__, instance.pk)


def register_audit_signals(*models):
    for model in models:
        post_save.connect(log_model_save, sender=model)
        pre_delete.connect(log_model_delete, sender=model)


class SignalDebouncer:
    """Prevents duplicate signal processing within a time window."""

    _recent = {}

    @classmethod
    def should_process(cls, key: str, window: float = 2.0) -> bool:
        import time
        now = time.time()
        last = cls._recent.get(key, 0)
        if now - last < window:
            return False
        cls._recent[key] = now
        return True
