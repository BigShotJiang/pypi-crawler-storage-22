"""
django-api-toolkit
~~~~~~~~~~~~~~~~~~

Standardized service layer and data processing abstractions
for Django applications.

:copyright: (c) 2025 django-api-toolkit contributors
:license: MIT
"""

__version__ = "0.1.0"
__author__ = "django-api-toolkit contributors"
__license__ = "MIT"


def get_version():
    return __version__
