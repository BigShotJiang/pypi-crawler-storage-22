"""
Internal type definitions and type aliases used across the toolkit.
"""
from typing import Any, Dict, List, Optional, TypeVar, Union, Protocol

T = TypeVar("T")
JSON = Dict[str, Any]
JSONList = List[JSON]
OptionalStr = Optional[str]
Numeric = Union[int, float]


class Serializable(Protocol):
    def to_dict(self) -> JSON: ...


class Renderable(Protocol):
    def render(self, context: Optional[JSON] = None) -> str: ...


ResponsePayload = Dict[str, Union[str, int, float, list, dict, None]]
HeadersDict = Dict[str, str]
QueryParams = Dict[str, Union[str, List[str]]]
