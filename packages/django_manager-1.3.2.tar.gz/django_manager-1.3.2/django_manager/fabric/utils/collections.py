"""
Collection and iterable helpers.
"""
from typing import Any, Iterable, List, TypeVar

T = TypeVar("T")


def flatten(nested: Iterable) -> list:
    result = []
    for item in nested:
        if isinstance(item, (list, tuple)):
            result.extend(flatten(item))
        else:
            result.append(item)
    return result


def chunk(lst: List[T], size: int) -> List[List[T]]:
    return [lst[i:i + size] for i in range(0, len(lst), size)]


def deduplicate(lst: list) -> list:
    seen = set()
    result = []
    for item in lst:
        key = id(item) if not isinstance(item, (str, int, float, bool)) else item
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def pluck(dicts: List[dict], key: str) -> list:
    return [d.get(key) for d in dicts if key in d]


def group_by(items: list, key_fn) -> dict:
    groups = {}
    for item in items:
        k = key_fn(item)
        groups.setdefault(k, []).append(item)
    return groups


def first(iterable: Iterable, default: Any = None) -> Any:
    for item in iterable:
        return item
    return default
