"""
Data format converters: JSON, CSV, XML serialization helpers.
"""
import csv
import io
import json
from typing import Any, Dict, List
from xml.etree.ElementTree import Element, SubElement, tostring


def dict_to_xml(tag: str, data: Dict[str, Any]) -> str:
    root = Element(tag)
    for key, val in data.items():
        child = SubElement(root, key)
        child.text = str(val) if val is not None else ''
    return tostring(root, encoding='unicode')


def dicts_to_csv(data: List[Dict[str, Any]]) -> str:
    if not data:
        return ''
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=data[0].keys())
    writer.writeheader()
    writer.writerows(data)
    return output.getvalue()


def csv_to_dicts(csv_string: str) -> List[Dict[str, str]]:
    reader = csv.DictReader(io.StringIO(csv_string))
    return list(reader)


def pretty_json(data: Any, indent: int = 2) -> str:
    return json.dumps(data, indent=indent, ensure_ascii=False, default=str)


def safe_json_loads(raw: str, default: Any = None) -> Any:
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return default
