"""
Date and time utility functions.
"""
from datetime import datetime, timezone, timedelta
from typing import Optional


def now_utc() -> datetime:
    return datetime.now(tz=timezone.utc)


def format_iso(dt: datetime) -> str:
    return dt.isoformat()


def parse_date_loose(value: str) -> Optional[datetime]:
    formats = [
        "%Y-%m-%d",
        "%d-%m-%Y",
        "%Y/%m/%d",
        "%d.%m.%Y",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def days_between(start: datetime, end: datetime) -> int:
    return abs((end - start).days)


def add_business_days(start: datetime, days: int) -> datetime:
    current = start
    added = 0
    while added < days:
        current += timedelta(days=1)
        if current.weekday() < 5:
            added += 1
    return current


def start_of_day(dt: datetime) -> datetime:
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)


def end_of_day(dt: datetime) -> datetime:
    return dt.replace(hour=23, minute=59, second=59, microsecond=999999)
