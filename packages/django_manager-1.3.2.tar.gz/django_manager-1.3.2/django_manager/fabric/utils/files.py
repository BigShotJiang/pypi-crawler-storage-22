"""
File and path utility functions.
"""
import os
import mimetypes
from pathlib import Path
from typing import Optional


def safe_filename(filename: str) -> str:
    keepchars = (' ', '.', '_', '-')
    return ''.join(c for c in filename if c.isalnum() or c in keepchars).rstrip()


def get_extension(filename: str) -> str:
    return Path(filename).suffix.lstrip('.')


def get_mime_type(filename: str) -> Optional[str]:
    mime, _ = mimetypes.guess_type(filename)
    return mime


def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def file_size_human(size_bytes: int) -> str:
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} PB"


def read_text(path: str, encoding: str = 'utf-8') -> str:
    return Path(path).read_text(encoding=encoding)


def write_text(path: str, content: str, encoding: str = 'utf-8') -> None:
    Path(path).write_text(content, encoding=encoding)
