"""
Hashing and digest utilities.
"""
import hashlib
import hmac
import secrets


def hash_sha256(value: str) -> str:
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def hash_md5(value: str) -> str:
    return hashlib.md5(value.encode('utf-8')).hexdigest()


def short_hash(value: str, length: int = 8) -> str:
    return hash_sha256(value)[:length]


def hmac_sign(key: str, message: str) -> str:
    return hmac.new(
        key.encode('utf-8'),
        message.encode('utf-8'),
        hashlib.sha256,
    ).hexdigest()


def generate_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def constant_time_compare(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode('utf-8'), b.encode('utf-8'))
