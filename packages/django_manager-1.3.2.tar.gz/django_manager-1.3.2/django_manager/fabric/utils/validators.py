"""
Input validators and sanitizers.
"""
import re
from typing import Optional


_EMAIL_RE = re.compile(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$')
_PHONE_RE = re.compile(r'^\+?[1-9]\d{6,14}$')
_URL_RE = re.compile(
    r'^https?://'
    r'(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}'
    r'(?:/[^\s]*)?$'
)


def is_valid_email(value: str) -> bool:
    return bool(_EMAIL_RE.match(value))


def is_valid_phone(value: str) -> bool:
    return bool(_PHONE_RE.match(value))


def is_valid_url(value: str) -> bool:
    return bool(_URL_RE.match(value))


def sanitize_html(text: str) -> str:
    return re.sub(r'<[^>]+>', '', text)


def normalize_phone(phone: str) -> Optional[str]:
    digits = re.sub(r'\D', '', phone)
    if len(digits) < 7 or len(digits) > 15:
        return None
    return f"+{digits}"


def clamp(value, min_val, max_val):
    return max(min_val, min(value, max_val))


def is_positive_integer(value) -> bool:
    try:
        n = int(value)
        return n > 0
    except (TypeError, ValueError):
        return False
