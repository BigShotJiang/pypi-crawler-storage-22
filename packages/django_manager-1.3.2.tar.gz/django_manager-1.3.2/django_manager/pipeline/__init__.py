"""
Pipeline processing framework.
"""
