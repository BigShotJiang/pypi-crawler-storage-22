"""
Conditional and branching pipeline stages.
"""
from typing import Any, Callable, Dict, Optional


class ConditionalStage:
    def __init__(self, condition: Callable[[dict], bool], if_true: Callable, if_false: Optional[Callable] = None):
        self.condition = condition
        self.if_true = if_true
        self.if_false = if_false

    def run(self, ctx: dict) -> dict:
        if self.condition(ctx):
            return self.if_true(ctx)
        elif self.if_false:
            return self.if_false(ctx)
        return ctx


class LoopStage:
    def __init__(self, items_key: str, handler: Callable, output_key: str = '_loop_results'):
        self.items_key = items_key
        self.handler = handler
        self.output_key = output_key

    def run(self, ctx: dict) -> dict:
        items = ctx.get(self.items_key, [])
        results = []
        for item in items:
            sub_ctx = {**ctx, '_current_item': item}
            result = self.handler(sub_ctx)
            results.append(result.get('_current_item', item))
        ctx[self.output_key] = results
        return ctx


class ParallelStage:
    """Runs multiple handlers and merges results."""
    def __init__(self, *handlers: Callable):
        self.handlers = handlers

    def run(self, ctx: dict) -> dict:
        import copy
        results = {}
        for handler in self.handlers:
            sub_ctx = copy.deepcopy(ctx)
            result = handler(sub_ctx)
            results.update(result)
        ctx.update(results)
        return ctx
