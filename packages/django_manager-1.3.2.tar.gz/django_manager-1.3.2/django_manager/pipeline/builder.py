"""
Pipeline builder with fluent interface.
"""
from typing import Callable, List, Optional
from .engine import Pipeline, Stage


class PipelineBuilder:
    def __init__(self, name: str = 'default'):
        self._name = name
        self._stages: list = []
        self._error_handler: Optional[Callable] = None
        self._finally_handler: Optional[Callable] = None

    def stage(self, name: str, handler: Callable, **opts) -> 'PipelineBuilder':
        self._stages.append((name, handler, opts))
        return self

    def on_error(self, handler: Callable) -> 'PipelineBuilder':
        self._error_handler = handler
        return self

    def finally_do(self, handler: Callable) -> 'PipelineBuilder':
        self._finally_handler = handler
        return self

    def build(self) -> Pipeline:
        pipeline = Pipeline(name=self._name)
        for name, handler, opts in self._stages:
            pipeline.add(name, handler, **opts)
        return pipeline

    def build_and_run(self, ctx: Optional[dict] = None) -> dict:
        pipeline = self.build()
        try:
            result = pipeline.execute(ctx)
        except Exception as exc:
            if self._error_handler:
                self._error_handler(exc, ctx)
            raise
        finally:
            if self._finally_handler:
                self._finally_handler(ctx)
        return result
