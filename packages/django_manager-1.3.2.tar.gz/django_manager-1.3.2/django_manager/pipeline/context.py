"""
Pipeline context object and helpers.
"""
import copy
import time
from typing import Any, Dict, List, Optional


class PipelineContext:
    """Rich context object passed through pipeline stages."""

    def __init__(self, initial_data: Optional[Dict[str, Any]] = None):
        self._data: Dict[str, Any] = initial_data or {}
        self._metadata: Dict[str, Any] = {
            'created_at': time.time(),
            'stage_count': 0,
        }
        self._history: List[str] = []

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any):
        self._data[key] = value

    def remove(self, key: str):
        self._data.pop(key, None)

    def has(self, key: str) -> bool:
        return key in self._data

    def record_stage(self, name: str):
        self._history.append(name)
        self._metadata['stage_count'] += 1

    @property
    def data(self) -> Dict[str, Any]:
        return dict(self._data)

    @property
    def history(self) -> List[str]:
        return list(self._history)

    def snapshot(self) -> Dict[str, Any]:
        return copy.deepcopy(self._data)

    def merge(self, other: dict):
        self._data.update(other)
