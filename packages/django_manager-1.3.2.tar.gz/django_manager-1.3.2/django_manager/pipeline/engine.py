"""
Pipeline stage definitions and execution engine.
"""
import logging
from typing import Any, Callable, List, Optional

logger = logging.getLogger(__name__)


class Stage:
    """Single processing stage in a pipeline."""

    def __init__(self, name: str, handler: Callable, *, skip_on_error: bool = False):
        self.name = name
        self.handler = handler
        self.skip_on_error = skip_on_error

    def run(self, context: dict) -> dict:
        logger.debug("Running stage: %s", self.name)
        return self.handler(context)


class Pipeline:
    """Ordered sequence of stages with error handling."""

    def __init__(self, name: str = "default"):
        self.name = name
        self._stages: List[Stage] = []

    def add(self, name: str, handler: Callable, **opts) -> "Pipeline":
        self._stages.append(Stage(name, handler, **opts))
        return self

    def execute(self, initial_context: Optional[dict] = None) -> dict:
        ctx = initial_context or {}
        ctx['_pipeline'] = self.name
        ctx['_errors'] = []

        for stage in self._stages:
            try:
                ctx = stage.run(ctx)
            except Exception as exc:
                logger.error("Stage '%s' failed: %s", stage.name, exc)
                ctx['_errors'].append({'stage': stage.name, 'error': str(exc)})
                if not stage.skip_on_error:
                    raise
        return ctx

    def __len__(self):
        return len(self._stages)
