"""
Pipeline error strategies.
"""
import logging
from typing import Callable, Optional

logger = logging.getLogger(__name__)


class ErrorStrategy:
    def handle(self, stage_name: str, error: Exception, ctx: dict) -> dict:
        raise error


class SkipOnError(ErrorStrategy):
    def handle(self, stage_name, error, ctx):
        logger.warning("Skipping stage '%s': %s", stage_name, error)
        ctx.setdefault('_skipped', []).append(stage_name)
        return ctx


class FallbackOnError(ErrorStrategy):
    def __init__(self, fallback_fn: Callable):
        self._fallback = fallback_fn

    def handle(self, stage_name, error, ctx):
        logger.warning("Fallback for stage '%s': %s", stage_name, error)
        return self._fallback(ctx)


class RetryOnError(ErrorStrategy):
    def __init__(self, max_retries: int = 2, handler: Optional[Callable] = None):
        self._max = max_retries
        self._handler = handler

    def handle(self, stage_name, error, ctx):
        if self._handler:
            import time
            for i in range(self._max):
                try:
                    return self._handler(ctx)
                except Exception:
                    time.sleep(0.1 * (i + 1))
        raise error
