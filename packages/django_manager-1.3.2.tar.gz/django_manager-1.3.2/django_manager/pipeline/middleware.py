"""
Pipeline middleware and hooks.
"""
import time
import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class PipelineMiddleware:
    def before_stage(self, stage_name: str, ctx: dict) -> dict:
        return ctx

    def after_stage(self, stage_name: str, ctx: dict, duration: float) -> dict:
        return ctx

    def on_error(self, stage_name: str, ctx: dict, error: Exception):
        pass


class TimingMiddleware(PipelineMiddleware):
    def __init__(self):
        self._timings: Dict[str, float] = {}
        self._start: float = 0

    def before_stage(self, stage_name, ctx):
        self._start = time.monotonic()
        return ctx

    def after_stage(self, stage_name, ctx, duration):
        self._timings[stage_name] = duration
        return ctx

    @property
    def timings(self):
        return dict(self._timings)


class AuditMiddleware(PipelineMiddleware):
    def __init__(self):
        self.log: List[dict] = []

    def before_stage(self, stage_name, ctx):
        self.log.append({'stage': stage_name, 'event': 'start', 'time': time.time()})
        return ctx

    def after_stage(self, stage_name, ctx, duration):
        self.log.append({'stage': stage_name, 'event': 'end', 'duration': duration})
        return ctx

    def on_error(self, stage_name, ctx, error):
        self.log.append({'stage': stage_name, 'event': 'error', 'error': str(error)})
