"""
Built-in pipeline stages.
"""
import copy


def validate_stage(ctx: dict) -> dict:
    required = ctx.get('_required_fields', [])
    for field in required:
        if field not in ctx:
            raise ValueError(f"Missing required field: {field}")
    return ctx


def normalize_stage(ctx: dict) -> dict:
    if 'data' in ctx and isinstance(ctx['data'], dict):
        ctx['data'] = {k.strip().lower(): v for k, v in ctx['data'].items()}
    return ctx


def snapshot_stage(ctx: dict) -> dict:
    ctx.setdefault('_snapshots', [])
    ctx['_snapshots'].append(copy.deepcopy(ctx.get('data')))
    return ctx


def log_stage(ctx: dict) -> dict:
    import logging
    logging.getLogger('pipeline').info("Context keys: %s", list(ctx.keys()))
    return ctx
