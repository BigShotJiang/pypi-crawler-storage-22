"""
Notification helpers and email sending utilities.
"""
import logging
from typing import List, Optional

from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.conf import settings

logger = logging.getLogger(__name__)


def send_email_notification(
    subject: str,
    recipient_list: List[str],
    template: str,
    context: Optional[dict] = None,
    from_email: Optional[str] = None,
):
    html = render_to_string(template, context or {})
    try:
        send_mail(
            subject=subject,
            message='',
            from_email=from_email or settings.DEFAULT_FROM_EMAIL,
            recipient_list=recipient_list,
            html_message=html,
            fail_silently=False,
        )
        logger.info("Email sent to %s", recipient_list)
    except Exception as exc:
        logger.error("Failed to send email: %s", exc)


def send_plain_email(subject: str, body: str, recipients: List[str]):
    send_mail(
        subject=subject,
        message=body,
        from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', 'noreply@example.com'),
        recipient_list=recipients,
        fail_silently=True,
    )


class NotificationDispatcher:
    """Route notifications to different channels."""

    _handlers = {}

    @classmethod
    def register(cls, channel: str, handler):
        cls._handlers[channel] = handler

    @classmethod
    def dispatch(cls, channel: str, **kwargs):
        handler = cls._handlers.get(channel)
        if handler:
            return handler(**kwargs)
        logger.warning("No handler for channel: %s", channel)
