"""
User-related validation utilities.
"""
import re
from typing import List


def validate_password_strength(password: str) -> List[str]:
    errors = []
    if len(password) < 8:
        errors.append("Password must be at least 8 characters.")
    if not re.search(r'[A-Z]', password):
        errors.append("Password must contain an uppercase letter.")
    if not re.search(r'[a-z]', password):
        errors.append("Password must contain a lowercase letter.")
    if not re.search(r'\d', password):
        errors.append("Password must contain a digit.")
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        errors.append("Password must contain a special character.")
    return errors


def is_disposable_email(email: str) -> bool:
    disposable_domains = {
        'tempmail.com', 'throwaway.email', 'mailinator.com',
        'guerrillamail.com', 'yopmail.com', '10minutemail.com',
        'trashmail.com', 'fakeinbox.com',
    }
    domain = email.split('@')[-1].lower()
    return domain in disposable_domains


def normalize_email(email: str) -> str:
    local, domain = email.rsplit('@', 1)
    return f"{local.lower()}@{domain.lower()}"


def validate_username(username: str) -> List[str]:
    errors = []
    if len(username) < 3:
        errors.append("Username must be at least 3 characters.")
    if len(username) > 30:
        errors.append("Username must be at most 30 characters.")
    if not re.match(r'^[a-zA-Z0-9_]+$', username):
        errors.append("Username can only contain letters, digits, and underscores.")
    return errors
