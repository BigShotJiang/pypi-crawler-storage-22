from django.apps import AppConfig


class ResolversConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_manager.resolvers'
