"""
Course content processing pipeline.
"""
import re
import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)


class ContentProcessor:
    """Pipeline for transforming course text content."""

    def __init__(self):
        self._steps = []

    def add_step(self, fn):
        self._steps.append(fn)
        return self

    def process(self, text: str) -> str:
        for step in self._steps:
            text = step(text)
        return text


def strip_html_tags(text: str) -> str:
    return re.sub(r'<[^>]+>', '', text)


def normalize_line_breaks(text: str) -> str:
    return re.sub(r'\n{3,}', '\n\n', text)


def extract_headings(html: str) -> List[str]:
    return re.findall(r'<h[1-6][^>]*>(.*?)</h[1-6]>', html, re.IGNORECASE)


def word_count(text: str) -> int:
    return len(text.split())


def reading_time_minutes(text: str, wpm: int = 200) -> int:
    count = word_count(text)
    minutes = count / wpm
    return max(1, round(minutes))


def build_table_of_contents(lessons: List[Dict[str, Any]]) -> List[dict]:
    toc = []
    for i, lesson in enumerate(lessons, 1):
        toc.append({
            'number': i,
            'title': lesson.get('name', ''),
            'duration': lesson.get('hours', 0),
        })
    return toc
