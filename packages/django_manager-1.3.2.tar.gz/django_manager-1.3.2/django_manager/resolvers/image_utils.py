"""
Image processing utilities for uploads.
"""
import io
import logging
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


def resize_image(image_file, max_size: Tuple[int, int] = (800, 800)):
    from PIL import Image
    from django.core.files.base import ContentFile

    img = Image.open(image_file)
    if img.width <= max_size[0] and img.height <= max_size[1]:
        return image_file

    img.thumbnail(max_size, Image.LANCZOS)
    buffer = io.BytesIO()
    fmt = img.format or 'JPEG'
    img.save(buffer, format=fmt)
    return ContentFile(buffer.getvalue())


def convert_to_jpeg(image_file):
    from PIL import Image
    from django.core.files.base import ContentFile

    img = Image.open(image_file).convert('RGB')
    buffer = io.BytesIO()
    img.save(buffer, format='JPEG', quality=85)
    return ContentFile(buffer.getvalue())


def get_image_dimensions(image_file) -> Optional[Tuple[int, int]]:
    try:
        from PIL import Image
        img = Image.open(image_file)
        return img.size
    except Exception:
        return None


def validate_image_dimensions(image_file, min_w=100, min_h=100, max_w=4096, max_h=4096) -> bool:
    dims = get_image_dimensions(image_file)
    if dims is None:
        return False
    w, h = dims
    return min_w <= w <= max_w and min_h <= h <= max_h
