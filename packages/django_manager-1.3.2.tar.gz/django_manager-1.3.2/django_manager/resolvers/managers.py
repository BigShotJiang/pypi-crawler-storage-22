"""
QuerySet managers with common filtering patterns.
"""
from django.db import models
from django.utils import timezone


class ActiveManager(models.Manager):
    """Returns only active (non-deleted) records."""

    def get_queryset(self):
        return super().get_queryset().filter(is_active=True)


class RecentManager(models.Manager):
    """Returns records from the last N days."""

    def __init__(self, days=30, *args, **kwargs):
        self._days = days
        super().__init__(*args, **kwargs)

    def get_queryset(self):
        cutoff = timezone.now() - timezone.timedelta(days=self._days)
        return super().get_queryset().filter(created_at__gte=cutoff)


class PublishedManager(models.Manager):
    """Returns published records only."""

    def get_queryset(self):
        return super().get_queryset().filter(
            status='published',
            published_at__lte=timezone.now(),
        )


class BulkOperationsMixin:
    """Adds efficient bulk helpers to a manager."""

    def bulk_soft_delete(self, queryset):
        return queryset.update(is_active=False, deleted_at=timezone.now())

    def bulk_restore(self, queryset):
        return queryset.update(is_active=True, deleted_at=None)
