"""
Database router for multi-database setups.
"""


class DefaultRouter:
    """Routes all reads/writes to default, provides skeleton for extension."""

    route_app_labels = set()

    def db_for_read(self, model, **hints):
        if model._meta.app_label in self.route_app_labels:
            return 'secondary'
        return 'default'

    def db_for_write(self, model, **hints):
        if model._meta.app_label in self.route_app_labels:
            return 'secondary'
        return 'default'

    def allow_relation(self, obj1, obj2, **hints):
        return True

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        return True


class ReadReplicaRouter:
    """Sends reads to replica, writes to primary."""

    def db_for_read(self, model, **hints):
        return 'replica'

    def db_for_write(self, model, **hints):
        return 'default'

    def allow_relation(self, obj1, obj2, **hints):
        return True

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        return db == 'default'
