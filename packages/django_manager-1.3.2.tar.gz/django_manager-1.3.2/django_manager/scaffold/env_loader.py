"""
Configuration loader and environment variable helpers.
"""
import os
from typing import Any, List, Optional


def env(key: str, default: Any = None, cast: type = str) -> Any:
    value = os.environ.get(key)
    if value is None:
        return default
    if cast is bool:
        return value.lower() in ('1', 'true', 'yes', 'on')
    return cast(value)


def env_int(key: str, default: int = 0) -> int:
    return env(key, default=default, cast=int)


def env_bool(key: str, default: bool = False) -> bool:
    return env(key, default=default, cast=bool)


def env_list(key: str, separator: str = ',', default: Optional[List[str]] = None) -> List[str]:
    value = os.environ.get(key)
    if value is None:
        return default or []
    return [item.strip() for item in value.split(separator) if item.strip()]


def require_env(key: str) -> str:
    value = os.environ.get(key)
    if value is None:
        raise EnvironmentError(f"Required environment variable '{key}' is not set")
    return value


class EnvConfig:
    """Namespace for grouped env vars."""

    def __init__(self, prefix: str = ''):
        self._prefix = prefix

    def __call__(self, key: str, **kwargs):
        return env(f"{self._prefix}{key}", **kwargs)
