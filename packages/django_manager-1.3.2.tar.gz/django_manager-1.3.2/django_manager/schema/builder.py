"""
Schema builder with fluent API.
"""
from typing import Any, List, Optional
from .types import StringType, IntegerType, FloatType, BooleanType, ListType


class FieldBuilder:
    def __init__(self, name: str, schema_builder):
        self._name = name
        self._type = 'string'
        self._required = False
        self._default = None
        self._validators = []
        self._description = ''
        self._builder = schema_builder

    def type(self, field_type: str) -> 'FieldBuilder':
        self._type = field_type
        return self

    def required(self) -> 'FieldBuilder':
        self._required = True
        return self

    def default(self, value: Any) -> 'FieldBuilder':
        self._default = value
        return self

    def description(self, desc: str) -> 'FieldBuilder':
        self._description = desc
        return self

    def add_validator(self, validator) -> 'FieldBuilder':
        self._validators.append(validator)
        return self

    def done(self) -> 'SchemaBuilder':
        self._builder._fields[self._name] = {
            'type': self._type,
            'required': self._required,
            'default': self._default,
            'validators': self._validators,
            'description': self._description,
        }
        return self._builder

    def build_spec(self) -> dict:
        return {
            'name': self._name,
            'type': self._type,
            'required': self._required,
            'default': self._default,
            'description': self._description,
        }


class SchemaBuilder:
    def __init__(self, name: str = ''):
        self._name = name
        self._fields = {}
        self._version = 1
        self._strict = False

    def name(self, name: str) -> 'SchemaBuilder':
        self._name = name
        return self

    def version(self, v: int) -> 'SchemaBuilder':
        self._version = v
        return self

    def strict(self) -> 'SchemaBuilder':
        self._strict = True
        return self

    def field(self, name: str) -> FieldBuilder:
        return FieldBuilder(name, self)

    def string(self, name: str, required: bool = False) -> 'SchemaBuilder':
        self._fields[name] = {'type': 'string', 'required': required}
        return self

    def integer(self, name: str, required: bool = False) -> 'SchemaBuilder':
        self._fields[name] = {'type': 'integer', 'required': required}
        return self

    def boolean(self, name: str, required: bool = False) -> 'SchemaBuilder':
        self._fields[name] = {'type': 'boolean', 'required': required}
        return self

    def build(self) -> dict:
        return {
            'name': self._name,
            'version': self._version,
            'strict': self._strict,
            'fields': dict(self._fields),
        }
