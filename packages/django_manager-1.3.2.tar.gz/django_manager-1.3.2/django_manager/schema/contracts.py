"""
Schema contract validation engine.
"""
from typing import Any, Dict, Tuple
from .fields import Field


class Schema:
    """Declarative schema for dict validation."""

    _fields: Dict[str, Field] = {}

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls._fields = {}
        for key, val in cls.__dict__.items():
            if isinstance(val, Field):
                cls._fields[key] = val

    @classmethod
    def validate(cls, data: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, str]]:
        cleaned = {}
        errors = {}
        for name, field in cls._fields.items():
            try:
                cleaned[name] = field.validate(data.get(name))
            except (ValueError, TypeError) as exc:
                errors[name] = str(exc)
        return cleaned, errors

    @classmethod
    def is_valid(cls, data: Dict[str, Any]) -> bool:
        _, errors = cls.validate(data)
        return len(errors) == 0
