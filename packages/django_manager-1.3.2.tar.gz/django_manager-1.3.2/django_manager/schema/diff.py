"""
Schema comparison and diff.
"""
from typing import Any, Dict, List, Set, Tuple


class SchemaDiff:
    def __init__(self):
        self.added: List[str] = []
        self.removed: List[str] = []
        self.changed: List[Dict[str, Any]] = []

    @property
    def has_changes(self) -> bool:
        return bool(self.added or self.removed or self.changed)

    def summary(self) -> str:
        parts = []
        if self.added:
            parts.append(f"+{len(self.added)} fields")
        if self.removed:
            parts.append(f"-{len(self.removed)} fields")
        if self.changed:
            parts.append(f"~{len(self.changed)} modified")
        return ', '.join(parts) or 'no changes'

    def to_dict(self) -> dict:
        return {
            'added': self.added,
            'removed': self.removed,
            'changed': self.changed,
        }


def compare_schemas(old: dict, new: dict) -> SchemaDiff:
    diff = SchemaDiff()
    old_fields = set(old.get('fields', {}).keys())
    new_fields = set(new.get('fields', {}).keys())

    diff.added = sorted(new_fields - old_fields)
    diff.removed = sorted(old_fields - new_fields)

    for field in old_fields & new_fields:
        old_def = old['fields'][field]
        new_def = new['fields'][field]
        if old_def != new_def:
            diff.changed.append({
                'field': field,
                'old': old_def,
                'new': new_def,
            })

    return diff


def is_backward_compatible(old: dict, new: dict) -> bool:
    diff = compare_schemas(old, new)
    if diff.removed:
        return False
    for change in diff.changed:
        old_req = change['old'].get('required', False)
        new_req = change['new'].get('required', False)
        if new_req and not old_req:
            return False
    return True
