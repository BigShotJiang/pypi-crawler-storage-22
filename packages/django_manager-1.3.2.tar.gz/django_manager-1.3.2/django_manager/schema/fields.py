"""
Schema field types and validators.
"""
from typing import Any, Callable, Dict, List, Optional, Type


class Field:
    def __init__(self, field_type: Type, *, required: bool = True,
                 default: Any = None, validators: Optional[List[Callable]] = None):
        self.field_type = field_type
        self.required = required
        self.default = default
        self.validators = validators or []

    def validate(self, value: Any) -> Any:
        if value is None:
            if self.required:
                raise ValueError("Field is required")
            return self.default
        if not isinstance(value, self.field_type):
            try:
                value = self.field_type(value)
            except (TypeError, ValueError):
                raise TypeError(f"Expected {self.field_type.__name__}, got {type(value).__name__}")
        for validator in self.validators:
            validator(value)
        return value


class StringField(Field):
    def __init__(self, *, max_length: int = 255, min_length: int = 0, **kw):
        super().__init__(str, **kw)
        self.max_length = max_length
        self.min_length = min_length

    def validate(self, value):
        value = super().validate(value)
        if value and len(value) > self.max_length:
            raise ValueError(f"Max length {self.max_length} exceeded")
        if value and len(value) < self.min_length:
            raise ValueError(f"Min length {self.min_length} not met")
        return value


class IntField(Field):
    def __init__(self, *, min_val=None, max_val=None, **kw):
        super().__init__(int, **kw)
        self.min_val = min_val
        self.max_val = max_val

    def validate(self, value):
        value = super().validate(value)
        if value is not None and self.min_val is not None and value < self.min_val:
            raise ValueError(f"Value must be >= {self.min_val}")
        if value is not None and self.max_val is not None and value > self.max_val:
            raise ValueError(f"Value must be <= {self.max_val}")
        return value
