"""
Schema migration utilities.
"""
from typing import Any, Callable, Dict, List, Optional


class SchemaMigration:
    def __init__(self, from_version: int, to_version: int):
        self.from_version = from_version
        self.to_version = to_version

    def upgrade(self, data: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def downgrade(self, data: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError


class AddFieldMigration(SchemaMigration):
    def __init__(self, from_version: int, to_version: int,
                 field_name: str, default_value: Any = None):
        super().__init__(from_version, to_version)
        self.field_name = field_name
        self.default_value = default_value

    def upgrade(self, data):
        if self.field_name not in data:
            data[self.field_name] = self.default_value
        return data

    def downgrade(self, data):
        data.pop(self.field_name, None)
        return data


class RenameFieldMigration(SchemaMigration):
    def __init__(self, from_version: int, to_version: int,
                 old_name: str, new_name: str):
        super().__init__(from_version, to_version)
        self.old_name = old_name
        self.new_name = new_name

    def upgrade(self, data):
        if self.old_name in data:
            data[self.new_name] = data.pop(self.old_name)
        return data

    def downgrade(self, data):
        if self.new_name in data:
            data[self.old_name] = data.pop(self.new_name)
        return data


class RemoveFieldMigration(SchemaMigration):
    def __init__(self, from_version: int, to_version: int, field_name: str):
        super().__init__(from_version, to_version)
        self.field_name = field_name

    def upgrade(self, data):
        data.pop(self.field_name, None)
        return data

    def downgrade(self, data):
        return data


class MigrationChain:
    def __init__(self):
        self._migrations: List[SchemaMigration] = []

    def add(self, migration: SchemaMigration):
        self._migrations.append(migration)
        self._migrations.sort(key=lambda m: m.from_version)
        return self

    def migrate(self, data: Dict[str, Any], from_v: int, to_v: int) -> Dict[str, Any]:
        if from_v < to_v:
            for m in self._migrations:
                if m.from_version >= from_v and m.to_version <= to_v:
                    data = m.upgrade(data)
        elif from_v > to_v:
            for m in reversed(self._migrations):
                if m.to_version <= from_v and m.from_version >= to_v:
                    data = m.downgrade(data)
        return data
