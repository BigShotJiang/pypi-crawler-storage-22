"""
Schema registry for managing named schemas.
"""
from typing import Dict, List, Optional


class SchemaDefinition:
    def __init__(self, name: str, version: int = 1):
        self.name = name
        self.version = version
        self._fields: Dict[str, dict] = {}

    def add_field(self, name: str, field_type: str, required: bool = False,
                  default=None, description: str = ''):
        self._fields[name] = {
            'type': field_type,
            'required': required,
            'default': default,
            'description': description,
        }
        return self

    def get_field(self, name: str) -> Optional[dict]:
        return self._fields.get(name)

    @property
    def field_names(self) -> List[str]:
        return list(self._fields.keys())

    @property
    def required_fields(self) -> List[str]:
        return [k for k, v in self._fields.items() if v['required']]

    def to_dict(self) -> dict:
        return {
            'name': self.name,
            'version': self.version,
            'fields': dict(self._fields),
        }


class SchemaRegistry:
    _schemas: Dict[str, SchemaDefinition] = {}

    @classmethod
    def register(cls, schema: SchemaDefinition):
        key = f"{schema.name}@{schema.version}"
        cls._schemas[key] = schema

    @classmethod
    def get(cls, name: str, version: int = None) -> Optional[SchemaDefinition]:
        if version:
            return cls._schemas.get(f"{name}@{version}")
        matches = [s for k, s in cls._schemas.items() if s.name == name]
        if matches:
            return max(matches, key=lambda s: s.version)
        return None

    @classmethod
    def list_schemas(cls) -> List[str]:
        return list(cls._schemas.keys())

    @classmethod
    def clear(cls):
        cls._schemas.clear()
