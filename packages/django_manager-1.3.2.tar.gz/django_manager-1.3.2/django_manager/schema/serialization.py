"""
Schema serialization / deserialization.
"""
import json
from typing import Any, Dict, Optional


class SchemaSerializer:
    def serialize(self, schema: dict) -> str:
        return json.dumps(schema, indent=2, default=str, ensure_ascii=False)

    def deserialize(self, raw: str) -> dict:
        return json.loads(raw)


class CompactSerializer(SchemaSerializer):
    def serialize(self, schema: dict) -> str:
        return json.dumps(schema, separators=(',', ':'), default=str)


class VersionedSerializer:
    HEADER = '__schema__'

    def wrap(self, schema: dict, version: int = 1) -> dict:
        return {
            self.HEADER: {
                'version': version,
                'format': 'json',
            },
            'data': schema,
        }

    def unwrap(self, payload: dict):
        header = payload.get(self.HEADER, {})
        return {
            'version': header.get('version', 1),
            'data': payload.get('data', payload),
        }


def schema_to_json(schema: dict, compact: bool = False) -> str:
    serializer = CompactSerializer() if compact else SchemaSerializer()
    return serializer.serialize(schema)


def json_to_schema(raw: str) -> dict:
    return SchemaSerializer().deserialize(raw)


def schema_fingerprint(schema: dict) -> str:
    import hashlib
    raw = json.dumps(schema, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(raw.encode()).hexdigest()[:16]
