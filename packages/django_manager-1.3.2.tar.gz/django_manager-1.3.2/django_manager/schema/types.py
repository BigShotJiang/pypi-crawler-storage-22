"""
Schema type definitions.
"""
from typing import Any, Dict, List, Optional, Type, Union


class SchemaType:
    def __init__(self, python_type: Type, nullable: bool = False,
                 default: Any = None):
        self.python_type = python_type
        self.nullable = nullable
        self.default = default

    def coerce(self, value: Any) -> Any:
        if value is None:
            if self.nullable:
                return self.default
            raise TypeError("Value cannot be None")
        if isinstance(value, self.python_type):
            return value
        try:
            return self.python_type(value)
        except (ValueError, TypeError) as e:
            raise TypeError(f"Cannot coerce {type(value).__name__} to "
                            f"{self.python_type.__name__}: {e}")


class StringType(SchemaType):
    def __init__(self, max_length: int = None, **kwargs):
        super().__init__(str, **kwargs)
        self.max_length = max_length

    def coerce(self, value):
        result = super().coerce(value)
        if result is not None and self.max_length and len(result) > self.max_length:
            result = result[:self.max_length]
        return result


class IntegerType(SchemaType):
    def __init__(self, **kwargs):
        super().__init__(int, **kwargs)


class FloatType(SchemaType):
    def __init__(self, precision: int = None, **kwargs):
        super().__init__(float, **kwargs)
        self.precision = precision

    def coerce(self, value):
        result = super().coerce(value)
        if result is not None and self.precision is not None:
            result = round(result, self.precision)
        return result


class BooleanType(SchemaType):
    TRUTHY = {'true', '1', 'yes', 'on'}
    FALSY = {'false', '0', 'no', 'off'}

    def __init__(self, **kwargs):
        super().__init__(bool, **kwargs)

    def coerce(self, value):
        if isinstance(value, str):
            if value.lower() in self.TRUTHY:
                return True
            if value.lower() in self.FALSY:
                return False
        return super().coerce(value)


class ListType(SchemaType):
    def __init__(self, item_type: SchemaType = None, **kwargs):
        super().__init__(list, **kwargs)
        self.item_type = item_type

    def coerce(self, value):
        result = super().coerce(value)
        if result is not None and self.item_type:
            result = [self.item_type.coerce(item) for item in result]
        return result


class DictType(SchemaType):
    def __init__(self, **kwargs):
        super().__init__(dict, **kwargs)
