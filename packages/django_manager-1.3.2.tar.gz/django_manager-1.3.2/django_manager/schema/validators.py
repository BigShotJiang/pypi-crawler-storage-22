"""
Schema validation engine.
"""
from typing import Any, Dict, List, Optional


class ValidationError(Exception):
    def __init__(self, errors: List[Dict[str, str]]):
        self.errors = errors
        super().__init__(f"{len(errors)} validation error(s)")


class FieldValidator:
    def validate(self, value: Any, field_name: str) -> Optional[str]:
        raise NotImplementedError


class RequiredValidator(FieldValidator):
    def validate(self, value, field_name):
        if value is None:
            return f"'{field_name}' is required"
        return None


class TypeValidator(FieldValidator):
    def __init__(self, expected_type: type):
        self._type = expected_type

    def validate(self, value, field_name):
        if value is not None and not isinstance(value, self._type):
            return f"'{field_name}' must be {self._type.__name__}, got {type(value).__name__}"
        return None


class RangeValidator(FieldValidator):
    def __init__(self, min_val=None, max_val=None):
        self._min = min_val
        self._max = max_val

    def validate(self, value, field_name):
        if value is None:
            return None
        if self._min is not None and value < self._min:
            return f"'{field_name}' must be >= {self._min}"
        if self._max is not None and value > self._max:
            return f"'{field_name}' must be <= {self._max}"
        return None


class LengthValidator(FieldValidator):
    def __init__(self, min_len: int = 0, max_len: int = None):
        self._min = min_len
        self._max = max_len

    def validate(self, value, field_name):
        if value is None:
            return None
        length = len(value)
        if length < self._min:
            return f"'{field_name}' must have at least {self._min} items"
        if self._max is not None and length > self._max:
            return f"'{field_name}' must have at most {self._max} items"
        return None


class PatternValidator(FieldValidator):
    def __init__(self, pattern: str):
        import re
        self._regex = re.compile(pattern)
        self._pattern = pattern

    def validate(self, value, field_name):
        if value is not None and not self._regex.match(str(value)):
            return f"'{field_name}' does not match pattern: {self._pattern}"
        return None


def validate_schema(data: Dict[str, Any],
                    schema: Dict[str, List[FieldValidator]]) -> List[str]:
    errors = []
    for field, validators in schema.items():
        value = data.get(field)
        for v in validators:
            err = v.validate(value, field)
            if err:
                errors.append(err)
    return errors
