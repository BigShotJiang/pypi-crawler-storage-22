"""
Convenience shortcuts for common operations.
"""
from typing import Any, Dict, Optional


def ok(data: Any = None, **extra) -> Dict[str, Any]:
    """Build a success response payload."""
    resp = {"status": "ok"}
    if data is not None:
        resp["data"] = data
    resp.update(extra)
    return resp


def error(message: str, code: Optional[str] = None, **extra) -> Dict[str, Any]:
    """Build an error response payload."""
    resp = {"status": "error", "message": message}
    if code:
        resp["code"] = code
    resp.update(extra)
    return resp


def paginated(data: list, total: int, page: int, per_page: int) -> Dict[str, Any]:
    """Build a paginated response payload."""
    return {
        "data": data,
        "pagination": {
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page,
        },
    }
