"""
Transport layer abstractions.
"""
