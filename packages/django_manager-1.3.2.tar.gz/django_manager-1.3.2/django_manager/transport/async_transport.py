"""
Async transport support.
"""
import asyncio
from typing import Any, Dict, Optional, Callable


class AsyncTransport:
    async def send(self, request: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    async def close(self):
        pass


class AsyncHTTPTransport(AsyncTransport):
    def __init__(self, timeout: float = 30.0):
        self._timeout = timeout

    async def send(self, request: Dict[str, Any]) -> Dict[str, Any]:
        import aiohttp
        method = request.get('method', 'GET')
        url = request['url']
        headers = request.get('headers', {})
        body = request.get('body')

        async with aiohttp.ClientSession() as session:
            async with session.request(
                method, url, headers=headers, json=body,
                timeout=aiohttp.ClientTimeout(total=self._timeout)
            ) as resp:
                data = await resp.json()
                return {'status': resp.status, 'body': data, 'headers': dict(resp.headers)}


class AsyncBatchSender:
    def __init__(self, transport: AsyncTransport, concurrency: int = 5):
        self._transport = transport
        self._semaphore = asyncio.Semaphore(concurrency)

    async def _send_one(self, request: Dict):
        async with self._semaphore:
            return await self._transport.send(request)

    async def send_all(self, requests: list) -> list:
        tasks = [self._send_one(r) for r in requests]
        return await asyncio.gather(*tasks, return_exceptions=True)


class AsyncCircuitBreaker:
    def __init__(self, threshold: int = 5, reset_timeout: float = 60.0):
        self._threshold = threshold
        self._reset_timeout = reset_timeout
        self._failures = 0
        self._open_until: Optional[float] = None
        self._lock = asyncio.Lock()

    async def call(self, coro):
        async with self._lock:
            if self._open_until:
                import time
                if time.monotonic() < self._open_until:
                    raise RuntimeError("Circuit open")
                self._open_until = None
                self._failures = 0
        try:
            result = await coro
            async with self._lock:
                self._failures = 0
            return result
        except Exception as e:
            async with self._lock:
                self._failures += 1
                if self._failures >= self._threshold:
                    import time
                    self._open_until = time.monotonic() + self._reset_timeout
            raise
