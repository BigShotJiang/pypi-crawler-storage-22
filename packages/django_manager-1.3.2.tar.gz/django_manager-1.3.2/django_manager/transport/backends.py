"""
Message transport backends.
"""
import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from collections import deque

logger = logging.getLogger(__name__)


class BaseTransport(ABC):
    @abstractmethod
    def send(self, channel: str, message: Any) -> bool: ...

    @abstractmethod
    def receive(self, channel: str, timeout: Optional[float] = None) -> Any: ...


class InMemoryTransport(BaseTransport):
    """Queue-based in-memory transport for testing."""

    def __init__(self):
        self._queues: Dict[str, deque] = {}

    def send(self, channel, message):
        self._queues.setdefault(channel, deque()).append(message)
        return True

    def receive(self, channel, timeout=None):
        q = self._queues.get(channel)
        if q:
            return q.popleft()
        return None

    def pending(self, channel: str) -> int:
        return len(self._queues.get(channel, []))


class LogTransport(BaseTransport):
    """Transport that just logs messages."""

    def send(self, channel, message):
        logger.info("[%s] %s", channel, message)
        return True

    def receive(self, channel, timeout=None):
        return None
