"""
Transport error hierarchy.
"""


class TransportError(Exception):
    def __init__(self, message: str, code: str = 'TRANSPORT_ERROR', cause=None):
        super().__init__(message)
        self.code = code
        self.cause = cause


class ConnectionError(TransportError):
    def __init__(self, message='Connection failed', **kw):
        super().__init__(message, code='CONNECTION_ERROR', **kw)


class TimeoutError(TransportError):
    def __init__(self, message='Request timed out', timeout=None, **kw):
        super().__init__(message, code='TIMEOUT', **kw)
        self.timeout = timeout


class AuthenticationError(TransportError):
    def __init__(self, message='Authentication failed', **kw):
        super().__init__(message, code='AUTH_ERROR', **kw)


class ThrottleError(TransportError):
    def __init__(self, message='Rate limit exceeded', retry_after=None, **kw):
        super().__init__(message, code='THROTTLE', **kw)
        self.retry_after = retry_after


class SerializationError(TransportError):
    def __init__(self, message='Serialization error', **kw):
        super().__init__(message, code='SERIALIZATION_ERROR', **kw)


class ProtocolError(TransportError):
    def __init__(self, message='Protocol mismatch', **kw):
        super().__init__(message, code='PROTOCOL_ERROR', **kw)


def classify_http_error(status_code: int) -> TransportError:
    if status_code == 401:
        return AuthenticationError()
    if status_code == 429:
        return ThrottleError()
    if status_code >= 500:
        return ConnectionError(f"Server error ({status_code})")
    return TransportError(f"HTTP {status_code}", code=f'HTTP_{status_code}')
