"""
Transport metrics and health monitoring.
"""
import time
import threading
from collections import defaultdict
from typing import Dict, Optional


class TransportMetrics:
    def __init__(self):
        self._lock = threading.Lock()
        self._counters: Dict[str, int] = defaultdict(int)
        self._histograms: Dict[str, list] = defaultdict(list)
        self._started = time.monotonic()

    def increment(self, name: str, value: int = 1):
        with self._lock:
            self._counters[name] += value

    def observe(self, name: str, value: float):
        with self._lock:
            self._histograms[name].append(value)

    def get_counter(self, name: str) -> int:
        return self._counters.get(name, 0)

    def get_avg(self, name: str) -> float:
        values = self._histograms.get(name, [])
        return sum(values) / len(values) if values else 0.0

    def get_p99(self, name: str) -> float:
        values = sorted(self._histograms.get(name, []))
        if not values:
            return 0.0
        idx = int(len(values) * 0.99)
        return values[min(idx, len(values) - 1)]

    def snapshot(self) -> dict:
        with self._lock:
            return {
                'uptime': time.monotonic() - self._started,
                'counters': dict(self._counters),
                'averages': {k: self.get_avg(k) for k in self._histograms},
            }

    def reset(self):
        with self._lock:
            self._counters.clear()
            self._histograms.clear()
            self._started = time.monotonic()


class HealthChecker:
    def __init__(self, metrics: TransportMetrics,
                 error_threshold: float = 0.5):
        self._metrics = metrics
        self._error_threshold = error_threshold

    def is_healthy(self) -> bool:
        total = self._metrics.get_counter('requests')
        errors = self._metrics.get_counter('errors')
        if total == 0:
            return True
        return (errors / total) < self._error_threshold

    def status(self) -> dict:
        return {
            'healthy': self.is_healthy(),
            'metrics': self._metrics.snapshot(),
        }
