"""
Transport middleware support.
"""
import time
import logging
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger(__name__)


class TransportMiddleware:
    def before_send(self, request: Dict[str, Any]) -> Dict[str, Any]:
        return request

    def after_receive(self, response: Dict[str, Any]) -> Dict[str, Any]:
        return response

    def on_error(self, error: Exception) -> None:
        pass


class LoggingMiddleware(TransportMiddleware):
    def before_send(self, request):
        logger.debug("Sending request: %s %s", request.get('method'), request.get('url'))
        return request

    def after_receive(self, response):
        logger.debug("Received response: status=%s", response.get('status'))
        return response

    def on_error(self, error):
        logger.error("Transport error: %s", error)


class TimingMiddleware(TransportMiddleware):
    def __init__(self):
        self._start = None
        self.last_duration = 0.0

    def before_send(self, request):
        self._start = time.monotonic()
        return request

    def after_receive(self, response):
        if self._start is not None:
            self.last_duration = time.monotonic() - self._start
            response['_duration'] = self.last_duration
        return response


class HeaderInjector(TransportMiddleware):
    def __init__(self, headers: Dict[str, str]):
        self._headers = headers

    def before_send(self, request):
        existing = request.get('headers', {})
        existing.update(self._headers)
        request['headers'] = existing
        return request


class MiddlewareChain:
    def __init__(self):
        self._stack: list = []

    def add(self, mw: TransportMiddleware):
        self._stack.append(mw)
        return self

    def apply_before(self, request):
        for mw in self._stack:
            request = mw.before_send(request)
        return request

    def apply_after(self, response):
        for mw in reversed(self._stack):
            response = mw.after_receive(response)
        return response

    def apply_error(self, error):
        for mw in reversed(self._stack):
            mw.on_error(error)
