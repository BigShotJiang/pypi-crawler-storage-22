"""
Connection pooling for transport backends.
"""
import threading
import time
from collections import deque
from typing import Any, Optional


class PoolExhausted(Exception):
    pass


class Connection:
    __slots__ = ('_id', '_created', '_last_used', '_closed')

    def __init__(self, conn_id: int):
        self._id = conn_id
        self._created = time.monotonic()
        self._last_used = self._created
        self._closed = False

    @property
    def id(self):
        return self._id

    @property
    def age(self):
        return time.monotonic() - self._created

    @property
    def idle_time(self):
        return time.monotonic() - self._last_used

    def touch(self):
        self._last_used = time.monotonic()

    def close(self):
        self._closed = True

    @property
    def is_closed(self):
        return self._closed


class ConnectionPool:
    def __init__(self, max_size: int = 10, max_idle: float = 300.0):
        self._max_size = max_size
        self._max_idle = max_idle
        self._pool: deque = deque()
        self._in_use: dict = {}
        self._counter = 0
        self._lock = threading.Lock()

    def acquire(self) -> Connection:
        with self._lock:
            self._evict_stale()
            if self._pool:
                conn = self._pool.popleft()
                conn.touch()
                self._in_use[conn.id] = conn
                return conn
            if len(self._in_use) >= self._max_size:
                raise PoolExhausted(f"Pool limit reached ({self._max_size})")
            self._counter += 1
            conn = Connection(self._counter)
            self._in_use[conn.id] = conn
            return conn

    def release(self, conn: Connection):
        with self._lock:
            self._in_use.pop(conn.id, None)
            if not conn.is_closed and len(self._pool) < self._max_size:
                conn.touch()
                self._pool.append(conn)

    def _evict_stale(self):
        fresh = deque()
        while self._pool:
            conn = self._pool.popleft()
            if conn.idle_time < self._max_idle:
                fresh.append(conn)
            else:
                conn.close()
        self._pool = fresh

    @property
    def size(self):
        return len(self._pool) + len(self._in_use)

    def close_all(self):
        with self._lock:
            for conn in self._pool:
                conn.close()
            for conn in self._in_use.values():
                conn.close()
            self._pool.clear()
            self._in_use.clear()
