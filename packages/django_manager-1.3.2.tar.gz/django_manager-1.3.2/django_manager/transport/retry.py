"""
Transport retry policies.
"""
import time
import random
import logging
from typing import Callable, Optional, Type

logger = logging.getLogger(__name__)


class RetryConfig:
    __slots__ = ('max_retries', 'base_delay', 'max_delay', 'backoff_factor',
                 'jitter', 'retryable_exceptions')

    def __init__(self, max_retries=3, base_delay=0.5, max_delay=30.0,
                 backoff_factor=2.0, jitter=True, retryable_exceptions=None):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.backoff_factor = backoff_factor
        self.jitter = jitter
        self.retryable_exceptions = retryable_exceptions or (Exception,)

    def delay_for(self, attempt: int) -> float:
        delay = self.base_delay * (self.backoff_factor ** attempt)
        delay = min(delay, self.max_delay)
        if self.jitter:
            delay *= random.uniform(0.5, 1.5)
        return delay


def with_retry(config: Optional[RetryConfig] = None):
    cfg = config or RetryConfig()

    def decorator(fn: Callable):
        def wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(cfg.max_retries + 1):
                try:
                    return fn(*args, **kwargs)
                except cfg.retryable_exceptions as exc:
                    last_exc = exc
                    if attempt < cfg.max_retries:
                        delay = cfg.delay_for(attempt)
                        logger.warning(
                            "Retry %d/%d for %s after %.2fs: %s",
                            attempt + 1, cfg.max_retries, fn.__name__, delay, exc
                        )
                        time.sleep(delay)
            raise last_exc
        wrapper.__wrapped__ = fn
        return wrapper
    return decorator


class RetryBudget:
    def __init__(self, tokens_per_second: float = 10.0, max_tokens: float = 100.0):
        self._rate = tokens_per_second
        self._max = max_tokens
        self._tokens = max_tokens
        self._last = time.monotonic()

    def allow(self) -> bool:
        now = time.monotonic()
        elapsed = now - self._last
        self._last = now
        self._tokens = min(self._max, self._tokens + elapsed * self._rate)
        if self._tokens >= 1.0:
            self._tokens -= 1.0
            return True
        return False
