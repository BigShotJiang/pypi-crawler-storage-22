"""
Message envelope and routing.
"""
import uuid
import time
from typing import Any, Dict, Optional


class Envelope:
    """Wraps a message with metadata for transport."""

    def __init__(self, payload: Any, *, channel: str = 'default',
                 correlation_id: Optional[str] = None):
        self.id = uuid.uuid4().hex
        self.payload = payload
        self.channel = channel
        self.correlation_id = correlation_id or self.id
        self.timestamp = time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'channel': self.channel,
            'correlation_id': self.correlation_id,
            'timestamp': self.timestamp,
            'payload': self.payload,
        }


class Router:
    """Routes messages to channels based on rules."""

    def __init__(self):
        self._routes = {}

    def add_route(self, pattern: str, channel: str):
        self._routes[pattern] = channel

    def resolve(self, key: str) -> str:
        for pattern, channel in self._routes.items():
            if pattern in key:
                return channel
        return 'default'
