"""
Transport serialization helpers.
"""
import json
from typing import Any, Dict, Optional


class RequestSerializer:
    def serialize(self, method: str, url: str, headers: Dict = None,
                  body: Any = None) -> bytes:
        payload = {
            'method': method,
            'url': url,
            'headers': headers or {},
        }
        if body is not None:
            if isinstance(body, (dict, list)):
                payload['body'] = body
            elif isinstance(body, bytes):
                payload['body'] = body.hex()
                payload['body_encoding'] = 'hex'
            else:
                payload['body'] = str(body)
        return json.dumps(payload, default=str).encode('utf-8')

    def deserialize(self, data: bytes) -> Dict[str, Any]:
        payload = json.loads(data)
        if payload.get('body_encoding') == 'hex':
            payload['body'] = bytes.fromhex(payload['body'])
        return payload


class ResponseSerializer:
    def serialize(self, status: int, headers: Dict = None,
                  body: Any = None) -> bytes:
        payload = {
            'status': status,
            'headers': headers or {},
            'body': body,
        }
        return json.dumps(payload, default=str).encode('utf-8')

    def deserialize(self, data: bytes) -> Dict[str, Any]:
        return json.loads(data)
