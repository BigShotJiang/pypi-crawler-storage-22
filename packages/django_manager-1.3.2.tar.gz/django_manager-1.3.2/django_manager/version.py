"""
Version information.
"""

__version__ = "1.3.2"
VERSION = (1, 3, 2)


def version_tuple():
    return VERSION


def version_string():
    return ".".join(str(x) for x in VERSION)
