"""
Worker pool and task scheduling.
"""
