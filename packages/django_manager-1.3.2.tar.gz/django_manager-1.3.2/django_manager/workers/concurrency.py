"""
Worker concurrency primitives.
"""
import threading
from typing import Callable, List, Optional


class WorkerGroup:
    def __init__(self, target: Callable, count: int = 4, daemon: bool = True):
        self._target = target
        self._count = count
        self._daemon = daemon
        self._threads: List[threading.Thread] = []
        self._stop_event = threading.Event()

    def start(self):
        for i in range(self._count):
            t = threading.Thread(
                target=self._run_worker,
                name=f'worker-{i}',
                daemon=self._daemon,
            )
            self._threads.append(t)
            t.start()

    def _run_worker(self):
        while not self._stop_event.is_set():
            try:
                self._target()
            except Exception:
                pass

    def stop(self, timeout: float = 5.0):
        self._stop_event.set()
        for t in self._threads:
            t.join(timeout=timeout)
        self._threads.clear()

    @property
    def active_count(self) -> int:
        return sum(1 for t in self._threads if t.is_alive())

    @property
    def is_running(self) -> bool:
        return not self._stop_event.is_set()


class RateLimiter:
    def __init__(self, rate: float, burst: int = 1):
        self._rate = rate
        self._burst = burst
        self._tokens = float(burst)
        self._lock = threading.Lock()
        self._last_refill = 0.0

    def acquire(self, timeout: Optional[float] = None) -> bool:
        import time
        deadline = time.monotonic() + (timeout or 0)
        while True:
            with self._lock:
                now = time.monotonic()
                elapsed = now - self._last_refill
                self._last_refill = now
                self._tokens = min(
                    self._burst, self._tokens + elapsed * self._rate
                )
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    return True
            if timeout is not None and time.monotonic() >= deadline:
                return False
            import time as _t
            _t.sleep(0.01)
