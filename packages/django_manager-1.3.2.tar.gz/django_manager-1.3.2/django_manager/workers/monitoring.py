"""
Worker monitoring and statistics.
"""
import time
import threading
from collections import defaultdict
from typing import Dict, Optional


class WorkerStats:
    def __init__(self):
        self._lock = threading.Lock()
        self._processed = 0
        self._failed = 0
        self._retried = 0
        self._total_duration = 0.0
        self._started = time.monotonic()
        self._task_counts: Dict[str, int] = defaultdict(int)

    def record_success(self, task_name: str, duration: float):
        with self._lock:
            self._processed += 1
            self._total_duration += duration
            self._task_counts[task_name] += 1

    def record_failure(self, task_name: str):
        with self._lock:
            self._failed += 1
            self._task_counts[task_name] += 1

    def record_retry(self):
        with self._lock:
            self._retried += 1

    @property
    def uptime(self) -> float:
        return time.monotonic() - self._started

    @property
    def throughput(self) -> float:
        elapsed = self.uptime
        if elapsed == 0:
            return 0.0
        return self._processed / elapsed

    @property
    def avg_duration(self) -> float:
        if self._processed == 0:
            return 0.0
        return self._total_duration / self._processed

    @property
    def error_rate(self) -> float:
        total = self._processed + self._failed
        if total == 0:
            return 0.0
        return self._failed / total

    def snapshot(self) -> dict:
        with self._lock:
            return {
                'processed': self._processed,
                'failed': self._failed,
                'retried': self._retried,
                'uptime': round(self.uptime, 2),
                'throughput': round(self.throughput, 4),
                'avg_duration': round(self.avg_duration, 4),
                'error_rate': round(self.error_rate, 4),
                'by_task': dict(self._task_counts),
            }

    def reset(self):
        with self._lock:
            self._processed = 0
            self._failed = 0
            self._retried = 0
            self._total_duration = 0.0
            self._task_counts.clear()
            self._started = time.monotonic()
