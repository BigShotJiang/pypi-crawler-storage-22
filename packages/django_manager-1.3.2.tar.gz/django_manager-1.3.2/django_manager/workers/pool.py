"""
Task executor and worker pool implementation.
"""
import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class Task:
    _counter = 0

    def __init__(self, fn: Callable, *args, **kwargs):
        Task._counter += 1
        self.id = Task._counter
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.result = None
        self.error = None

    def execute(self):
        try:
            self.result = self.fn(*self.args, **self.kwargs)
        except Exception as exc:
            self.error = exc
            logger.error("Task %d failed: %s", self.id, exc)


class WorkerPool:
    def __init__(self, max_workers: int = 4):
        self._pool = ThreadPoolExecutor(max_workers=max_workers)
        self._futures = []

    def submit(self, fn: Callable, *args, **kwargs):
        future = self._pool.submit(fn, *args, **kwargs)
        self._futures.append(future)
        return future

    def wait_all(self, timeout: Optional[float] = None) -> List[Any]:
        results = []
        for future in as_completed(self._futures, timeout=timeout):
            try:
                results.append(future.result())
            except Exception as exc:
                results.append(exc)
        self._futures.clear()
        return results

    def shutdown(self, wait: bool = True):
        self._pool.shutdown(wait=wait)
