"""
Task queue implementation.
"""
import heapq
import threading
import time
from typing import Optional
from .tasks import Task, TaskState


class TaskQueue:
    def __init__(self, maxsize: int = 0):
        self._heap = []
        self._counter = 0
        self._lock = threading.Lock()
        self._not_empty = threading.Condition(self._lock)
        self._maxsize = maxsize

    def put(self, task: Task):
        with self._not_empty:
            if self._maxsize and len(self._heap) >= self._maxsize:
                raise QueueFull(f"Queue limit reached ({self._maxsize})")
            self._counter += 1
            heapq.heappush(self._heap, (-task.priority, self._counter, task))
            self._not_empty.notify()

    def get(self, timeout: Optional[float] = None) -> Task:
        with self._not_empty:
            while not self._heap:
                if not self._not_empty.wait(timeout=timeout):
                    raise QueueEmpty("Timed out waiting for task")
            _, _, task = heapq.heappop(self._heap)
            return task

    def peek(self) -> Optional[Task]:
        with self._lock:
            if self._heap:
                return self._heap[0][2]
            return None

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._heap)

    @property
    def empty(self) -> bool:
        return self.size == 0

    def clear(self):
        with self._lock:
            self._heap.clear()


class QueueFull(Exception):
    pass


class QueueEmpty(Exception):
    pass


class DeadLetterQueue:
    def __init__(self):
        self._tasks = []
        self._lock = threading.Lock()

    def add(self, task: Task, reason: str = ''):
        with self._lock:
            self._tasks.append({
                'task': task.to_dict(),
                'reason': reason,
                'timestamp': time.time(),
            })

    def list_all(self) -> list:
        with self._lock:
            return list(self._tasks)

    def size(self) -> int:
        with self._lock:
            return len(self._tasks)
