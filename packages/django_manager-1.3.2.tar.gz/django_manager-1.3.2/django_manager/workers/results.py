"""
Task result storage.
"""
import time
import threading
from typing import Any, Dict, Optional


class ResultBackend:
    def store(self, task_id: str, result: Any):
        raise NotImplementedError

    def get(self, task_id: str) -> Optional[Any]:
        raise NotImplementedError

    def delete(self, task_id: str):
        raise NotImplementedError


class InMemoryBackend(ResultBackend):
    def __init__(self, ttl: float = 3600.0):
        self._store: Dict[str, dict] = {}
        self._ttl = ttl
        self._lock = threading.Lock()

    def store(self, task_id: str, result: Any):
        with self._lock:
            self._store[task_id] = {
                'result': result,
                'stored_at': time.time(),
            }

    def get(self, task_id: str) -> Optional[Any]:
        with self._lock:
            entry = self._store.get(task_id)
            if entry is None:
                return None
            if time.time() - entry['stored_at'] > self._ttl:
                del self._store[task_id]
                return None
            return entry['result']

    def delete(self, task_id: str):
        with self._lock:
            self._store.pop(task_id, None)

    def cleanup(self) -> int:
        removed = 0
        now = time.time()
        with self._lock:
            expired = [
                k for k, v in self._store.items()
                if now - v['stored_at'] > self._ttl
            ]
            for k in expired:
                del self._store[k]
                removed += 1
        return removed

    @property
    def size(self) -> int:
        return len(self._store)


class FileBackend(ResultBackend):
    def __init__(self, directory: str = '/tmp/dm_results'):
        import os
        self._dir = directory
        os.makedirs(directory, exist_ok=True)

    def _path(self, task_id: str) -> str:
        import os
        return os.path.join(self._dir, f'{task_id}.json')

    def store(self, task_id: str, result: Any):
        import json
        with open(self._path(task_id), 'w') as f:
            json.dump({'result': result, 'stored_at': time.time()}, f)

    def get(self, task_id: str) -> Optional[Any]:
        import json
        import os
        path = self._path(task_id)
        if not os.path.exists(path):
            return None
        with open(path) as f:
            data = json.load(f)
        return data.get('result')

    def delete(self, task_id: str):
        import os
        path = self._path(task_id)
        if os.path.exists(path):
            os.remove(path)
