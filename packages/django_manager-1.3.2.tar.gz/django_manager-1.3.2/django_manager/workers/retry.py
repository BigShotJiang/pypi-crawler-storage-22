"""
Worker retry logic.
"""
import time
import random
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class RetryPolicy:
    def __init__(self, max_retries: int = 3, base_delay: float = 1.0,
                 max_delay: float = 60.0, exponential: bool = True):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential = exponential

    def compute_delay(self, attempt: int) -> float:
        if self.exponential:
            delay = self.base_delay * (2 ** attempt)
        else:
            delay = self.base_delay
        delay = min(delay, self.max_delay)
        jitter = random.uniform(0, delay * 0.1)
        return delay + jitter

    def should_retry(self, attempt: int, error: Exception) -> bool:
        return attempt < self.max_retries


class SelectiveRetryPolicy(RetryPolicy):
    def __init__(self, retryable_errors=None, **kwargs):
        super().__init__(**kwargs)
        self._retryable = tuple(retryable_errors or [Exception])

    def should_retry(self, attempt: int, error: Exception) -> bool:
        if not isinstance(error, self._retryable):
            return False
        return super().should_retry(attempt, error)


def execute_with_retry(fn, policy: Optional[RetryPolicy] = None, *args, **kwargs):
    policy = policy or RetryPolicy()
    last_error = None
    for attempt in range(policy.max_retries + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            last_error = e
            if not policy.should_retry(attempt, e):
                break
            delay = policy.compute_delay(attempt)
            logger.warning(
                "Retry %d/%d: %s (delay=%.2fs)",
                attempt + 1, policy.max_retries, e, delay
            )
            time.sleep(delay)
    raise last_error
