"""
Periodic scheduler for recurring tasks.
"""
import time
import threading
import logging
from typing import Callable, Dict

logger = logging.getLogger(__name__)


class PeriodicScheduler:
    def __init__(self):
        self._jobs: Dict[str, dict] = {}
        self._running = False
        self._thread = None

    def add_job(self, name: str, fn: Callable, interval: float):
        self._jobs[name] = {
            'fn': fn,
            'interval': interval,
            'last_run': 0,
        }

    def remove_job(self, name: str):
        self._jobs.pop(name, None)

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            now = time.time()
            for name, job in self._jobs.items():
                if now - job['last_run'] >= job['interval']:
                    try:
                        job['fn']()
                        job['last_run'] = now
                    except Exception as exc:
                        logger.error("Job '%s' failed: %s", name, exc)
            time.sleep(0.5)
