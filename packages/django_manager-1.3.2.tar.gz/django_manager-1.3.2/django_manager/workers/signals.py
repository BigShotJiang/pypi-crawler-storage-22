"""
Worker signals and hooks.
"""
from typing import Callable, Dict, List


class Signal:
    def __init__(self, name: str = ''):
        self.name = name
        self._receivers: List[Callable] = []

    def connect(self, receiver: Callable):
        if receiver not in self._receivers:
            self._receivers.append(receiver)

    def disconnect(self, receiver: Callable):
        try:
            self._receivers.remove(receiver)
        except ValueError:
            pass

    def send(self, **kwargs):
        results = []
        for receiver in self._receivers:
            try:
                result = receiver(**kwargs)
                results.append((receiver, result))
            except Exception as e:
                results.append((receiver, e))
        return results


task_prerun = Signal('task_prerun')
task_postrun = Signal('task_postrun')
task_failure = Signal('task_failure')
task_retry = Signal('task_retry')
worker_ready = Signal('worker_ready')
worker_shutdown = Signal('worker_shutdown')
pool_resize = Signal('pool_resize')


def on_task_prerun(fn: Callable):
    task_prerun.connect(fn)
    return fn


def on_task_postrun(fn: Callable):
    task_postrun.connect(fn)
    return fn


def on_task_failure(fn: Callable):
    task_failure.connect(fn)
    return fn
