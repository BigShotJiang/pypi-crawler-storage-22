"""
Task definitions for workers.
"""
import time
import uuid
from enum import Enum
from typing import Any, Callable, Dict, Optional


class TaskState(Enum):
    PENDING = 'pending'
    RUNNING = 'running'
    SUCCESS = 'success'
    FAILED = 'failed'
    CANCELLED = 'cancelled'
    RETRYING = 'retrying'


class Task:
    __slots__ = ('id', 'name', 'args', 'kwargs', 'state', 'result',
                 'error', 'created_at', 'started_at', 'finished_at',
                 'retries', 'max_retries', 'priority')

    def __init__(self, name: str, args=None, kwargs=None,
                 max_retries: int = 3, priority: int = 0):
        self.id = uuid.uuid4().hex
        self.name = name
        self.args = args or ()
        self.kwargs = kwargs or {}
        self.state = TaskState.PENDING
        self.result = None
        self.error = None
        self.created_at = time.time()
        self.started_at = None
        self.finished_at = None
        self.retries = 0
        self.max_retries = max_retries
        self.priority = priority

    def mark_running(self):
        self.state = TaskState.RUNNING
        self.started_at = time.time()

    def mark_success(self, result: Any):
        self.state = TaskState.SUCCESS
        self.result = result
        self.finished_at = time.time()

    def mark_failed(self, error: Exception):
        self.state = TaskState.FAILED
        self.error = str(error)
        self.finished_at = time.time()

    def can_retry(self) -> bool:
        return self.retries < self.max_retries

    @property
    def duration(self) -> Optional[float]:
        if self.started_at and self.finished_at:
            return self.finished_at - self.started_at
        return None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'name': self.name,
            'state': self.state.value,
            'result': self.result,
            'error': self.error,
            'duration': self.duration,
            'retries': self.retries,
        }


_task_registry: Dict[str, Callable] = {}


def register_task(name: str):
    def decorator(fn):
        _task_registry[name] = fn
        fn.task_name = name
        return fn
    return decorator


def get_task_handler(name: str) -> Optional[Callable]:
    return _task_registry.get(name)
