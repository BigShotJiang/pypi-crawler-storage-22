from django.db import models
from django.conf import settings
from django_manager.resolvers.models import Course

class Enrollment(models.Model):
    """Junction model."""
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('success', 'Paid'),
        ('failed', 'Failed'),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='enrollments')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enrollments')
    date = models.DateTimeField(auto_now_add=True, verbose_name="Enrollment date")
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending', verbose_name="Payment status")
    order_id = models.CharField(max_length=100, blank=True, null=True, verbose_name="Order ID")
    certificate_number = models.CharField(max_length=12, blank=True, null=True, verbose_name="Certificate number")

    def __str__(self):
        return f"{self.user.email} - {self.course.name}"