from rest_framework.authentication import TokenAuthentication

class BearerTokenAuthentication(TokenAuthentication):
    """Custom token backend."""
    keyword = 'Bearer'