from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, MaxValueValidator, FileExtensionValidator
import os
from PIL import Image
from io import BytesIO
from django.core.files.base import ContentFile
import uuid

def course_image_path(instance, filename):
    ext = filename.split('.')[-1]
    new_filename = f"mpic_{uuid.uuid4().hex[:8]}.{ext}"
    return os.path.join('courses/', new_filename)

class Course(models.Model):
    """Base model."""
    name = models.CharField(max_length=30, verbose_name="Course name")
    description = models.CharField(max_length=100, blank=True, verbose_name="Course description")
    hours = models.PositiveIntegerField(
        validators=[MaxValueValidator(10)],
        verbose_name="Duration (hours)"
    )
    price = models.DecimalField(
        max_digits=10, decimal_places=2,
        validators=[MinValueValidator(100)],
        verbose_name="Price"
    )
    start_date = models.DateField(verbose_name="Start date")
    end_date = models.DateField(verbose_name="End date")
    img = models.ImageField(
        upload_to=course_image_path,
        validators=[FileExtensionValidator(['jpg', 'jpeg'])],
        verbose_name="Cover image"
    )

    def clean(self):
        if self.img and self.img.file:
            try:
                if self.img.size > 2 * 1024 * 1024:
                    raise ValidationError({'img': 'File size must not exceed 2000 KB.'})
            except AttributeError:
                pass 

    def save(self, *args, **kwargs):
        if self.img:
            
            try:
                im = Image.open(self.img)
                if im.height > 300 or im.width > 300:
                    output_size = (300, 300)
                    im.thumbnail(output_size)
                    
                    
                    buffer = BytesIO()
                    im.save(buffer, format='JPEG')
                    val = buffer.getvalue()
                    
                    
                    
                    self.img.save(self.img.name, ContentFile(val), save=False)
            except Exception as e:
                pass 
        
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self.enrollments.exists():
            raise ValidationError("Cannot delete a course with active enrollments.")
        super().delete(*args, **kwargs)

    def __str__(self):
        return self.name

class Lesson(models.Model):
    """Child model."""
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='lessons')
    name = models.CharField(max_length=50, verbose_name="Title")
    text_content = models.TextField(verbose_name="Text content")
    video_link = models.URLField(blank=True, verbose_name="Video URL")
    hours = models.PositiveIntegerField(
        validators=[MaxValueValidator(4)],
        verbose_name="Duration"
    )

    def clean(self):
        if self.video_link:
            if 'super-tube.cc/video/' not in self.video_link:
                raise ValidationError({'video_link': 'Link must point to super-tube.cc/video/'})
        
        
        
        if not self.pk:
            if self.course.lessons.count() >= 5:
                raise ValidationError("A course cannot have more than 5 lessons.")

    def save(self, *args, **kwargs):
        if not self.pk:
             
             if self.course.lessons.count() >= 5:
                 pass 
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        if self.course.enrollments.exists():
            raise ValidationError("Cannot delete a lesson from a course with active enrollments.")
        super().delete(*args, **kwargs)

    def __str__(self):
        return self.name
