"""
Version information.
"""

__version__ = "1.3.5"
VERSION = (1, 3, 5)


def version_tuple():
    return VERSION


def version_string():
    return ".".join(str(x) for x in VERSION)
