"""
Your type-safe wrapper around Django's liquid core.

https://noumenal.es/mantle/
"""
from .db import create, update, Query
from .readers import overrides, spec, to_spec


__all__ = [
    "create",
    "overrides",
    "spec",
    "to_spec",
    "update",
    "Query",
]


__version__ = "26.3"
