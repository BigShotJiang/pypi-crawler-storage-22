# django-mantle-drf

Django REST Framework views powered by [Mantle](https://noumenal.es/mantle/)
and attrs shape classes.

Use attrs `@define` classes instead of DRF serialisers. Structure and
unstructure with cattrs. Generate OpenAPI schemas with drf-spectacular.

## Installation

```bash
pip install django-mantle-drf
```

For OpenAPI schema generation:

```bash
pip install "django-mantle-drf[spectacular]"
```

## Usage

Define a shape class:

```python
import attr

@attr.define
class BookmarkShape:
    url: str
    title: str
    comment: str = ""
```

Create a view:

```python
from mantle_drf.generics import ListCreateAPIView

class BookmarkList(ListCreateAPIView):
    queryset = Bookmark.objects.all()
    shape_class = BookmarkShape
```

That's it. `GET` returns unstructured shape data; `POST` structures the request
body into a shape and uses `mantle.create()` to persist it.

## What's Included

- **`GenericAPIView`** — base view with `shape_class` support
- **Mixins** — `CreateModelMixin`, `ListModelMixin`, `RetrieveModelMixin`,
  `UpdateModelMixin`, `DestroyModelMixin`
- **Concrete views** — `CreateAPIView`, `ListAPIView`, `RetrieveAPIView`,
  `DestroyAPIView`, `UpdateAPIView`, `ListCreateAPIView`,
  `RetrieveUpdateAPIView`, `RetrieveDestroyAPIView`,
  `RetrieveUpdateDestroyAPIView`
- **ViewSets** — `GenericViewSet`, `ReadOnlyModelViewSet`, `ModelViewSet`
- **drf-spectacular integration** — `AttrsExtension` for OpenAPI schema
  generation from attrs classes

## Documentation

Full docs at <https://noumenal.es/mantle-drf/>.

See `example/` for a runnable bookmarks API.

## License

MIT
