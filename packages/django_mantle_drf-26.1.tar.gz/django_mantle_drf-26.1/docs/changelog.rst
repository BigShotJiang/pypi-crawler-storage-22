Changelog
=========

26.1
----

- Initial release.
- ``GenericAPIView`` with ``shape_class`` support.
- Mixins: Create, List, Retrieve, Update, Destroy.
- Concrete views mirroring ``rest_framework.generics``.
- ViewSets: ``GenericViewSet``, ``ReadOnlyModelViewSet``, ``ModelViewSet``.
- drf-spectacular integration via ``AttrsExtension``.
- Example project.
