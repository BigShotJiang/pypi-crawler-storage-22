"""
Django REST Framework views and schema powered by Mantle and attrs shape classes.

https://noumenal.es/mantle-drf/
"""

__version__ = "26.1"
