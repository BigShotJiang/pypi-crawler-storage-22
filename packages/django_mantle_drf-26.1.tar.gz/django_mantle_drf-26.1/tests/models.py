from django.db import models


class Item(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)

    class Meta:
        app_label = "tests"

    def __str__(self):
        return self.name
