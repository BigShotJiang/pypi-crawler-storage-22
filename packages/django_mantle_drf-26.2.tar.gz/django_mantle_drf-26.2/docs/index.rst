Django-Mantle-DRF
=================

Django REST Framework views powered by `Mantle <https://noumenal.es/mantle/>`_
and attrs shape classes.

Use attrs ``@define`` classes instead of DRF serialisers. Structure and
unstructure with cattrs. Generate OpenAPI schemas with drf-spectacular.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   quickstart
   views
   schema
   changelog
