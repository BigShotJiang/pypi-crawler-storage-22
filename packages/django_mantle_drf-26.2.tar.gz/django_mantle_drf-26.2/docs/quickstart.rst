Quick Start
===========

Installation
------------

.. code-block:: bash

   pip install django-mantle-drf

For OpenAPI schema generation:

.. code-block:: bash

   pip install "django-mantle-drf[spectacular]"

Define a Shape Class
--------------------

Shape classes are plain attrs classes that describe the data your API reads and
writes:

.. code-block:: python

   import attr

   @attr.define
   class BookmarkShape:
       url: str
       title: str
       comment: str = ""

Create a View
-------------

Use shape classes wherever DRF expects a serialiser:

.. code-block:: python

   from mantle_drf.generics import ListCreateAPIView
   from .models import Bookmark
   from .shapes import BookmarkShape

   class BookmarkList(ListCreateAPIView):
       queryset = Bookmark.objects.all()
       shape_class = BookmarkShape

Wire up the URL as normal:

.. code-block:: python

   from django.urls import path
   from .views import BookmarkList

   urlpatterns = [
       path("bookmarks/", BookmarkList.as_view()),
   ]

That's it. ``GET`` returns unstructured shape data; ``POST`` structures the
request body into a shape and uses ``mantle.create()`` to persist it.
