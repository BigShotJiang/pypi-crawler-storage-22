Views & ViewSets
================

``django-mantle-drf`` mirrors the structure of ``rest_framework.generics`` and
``rest_framework.viewsets``, replacing ``serializer_class`` with
``shape_class``.

GenericAPIView
--------------

The base class. Set ``shape_class`` to an attrs-decorated class.

.. code-block:: python

   from mantle_drf.generics import GenericAPIView

Key methods:

``get_shape_class()``
   Returns the shape class. Override to vary by request.

``get_query(queryset=None)``
   Returns a ``mantle.Query`` for the current queryset and shape class.
   Used by the mixins for all read operations (list, retrieve). The
   ``Query`` handles the full django-readers → cattrs flow: queryset
   optimisation, projection, and structuring into attrs instances.

``structure(data)``
   Structure request data (a dict) into a shape instance using mantle's
   default converter.

``unstructure(shape)``
   Unstructure a shape instance to a JSON-serialisable dict.

Mixins
------

Five mixins provide the standard actions, mirroring
``rest_framework.mixins``:

- ``CreateModelMixin`` — uses ``mantle.create()``
- ``ListModelMixin``
- ``RetrieveModelMixin``
- ``UpdateModelMixin`` — uses ``mantle.update()``
- ``DestroyModelMixin``

.. code-block:: python

   from mantle_drf.mixins import CreateModelMixin, RetrieveModelMixin

Concrete Views
--------------

Compose mixins with ``GenericAPIView``, exactly as DRF does. All live in
``mantle_drf.generics``:

- ``CreateAPIView``
- ``ListAPIView``
- ``RetrieveAPIView``
- ``DestroyAPIView``
- ``UpdateAPIView``
- ``ListCreateAPIView``
- ``RetrieveUpdateAPIView``
- ``RetrieveDestroyAPIView``
- ``RetrieveUpdateDestroyAPIView``

ViewSets
--------

.. code-block:: python

   from mantle_drf.viewsets import ModelViewSet

- ``GenericViewSet`` — base, no actions
- ``ReadOnlyModelViewSet`` — ``list`` + ``retrieve``
- ``ModelViewSet`` — full CRUD
