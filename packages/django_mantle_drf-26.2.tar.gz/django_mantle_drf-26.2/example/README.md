# django-mantle-drf Example

A simple bookmarks API demonstrating `django-mantle-drf` with attrs shape
classes and drf-spectacular schema generation.

## Setup

From the project root:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[spectacular]"
```

## Run

```bash
cd example
python manage.py migrate
python manage.py runserver
```

## Endpoints

- `GET /bookmarks/` — List bookmarks
- `POST /bookmarks/` — Create a bookmark
- `GET /bookmarks/<id>/` — Retrieve a bookmark
- `PUT /bookmarks/<id>/` — Update a bookmark
- `PATCH /bookmarks/<id>/` — Partial update
- `DELETE /bookmarks/<id>/` — Delete a bookmark
- `GET /schema/` — OpenAPI schema (YAML)
- `GET /docs/` — Swagger UI

## Try it

```bash
# Create
curl -X POST http://localhost:8000/bookmarks/ \
  -H "Content-Type: application/json" \
  -d '{"url":"https://example.com","title":"Example"}'

# List
curl http://localhost:8000/bookmarks/

# Schema
curl http://localhost:8000/schema/
```
