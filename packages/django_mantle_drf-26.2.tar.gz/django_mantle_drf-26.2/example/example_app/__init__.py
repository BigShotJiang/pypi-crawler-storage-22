from django.apps import AppConfig


class ExampleAppConfig(AppConfig):
    name = "example_app"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self):
        import mantle_drf.schema  # noqa: F401 — register drf-spectacular extension
