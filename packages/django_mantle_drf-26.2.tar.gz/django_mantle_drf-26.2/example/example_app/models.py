from django.db import models


class Bookmark(models.Model):
    url = models.URLField(max_length=500)
    title = models.CharField(max_length=200)
    comment = models.TextField(blank=True, default="")

    def __str__(self):
        return self.title
