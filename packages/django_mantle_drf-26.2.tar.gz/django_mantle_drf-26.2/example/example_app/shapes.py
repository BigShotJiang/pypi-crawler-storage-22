import attr


@attr.define
class BookmarkShape:
    """Shape class for Bookmark read/write operations."""

    url: str
    title: str
    comment: str = ""
