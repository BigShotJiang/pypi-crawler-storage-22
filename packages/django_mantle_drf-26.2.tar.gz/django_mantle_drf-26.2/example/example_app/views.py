from drf_spectacular.utils import extend_schema

from mantle_drf.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView

from .models import Bookmark
from .shapes import BookmarkShape


class BookmarkList(ListCreateAPIView):
    queryset = Bookmark.objects.all()
    shape_class = BookmarkShape

    @extend_schema(responses=BookmarkShape, tags=["bookmarks"])
    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    @extend_schema(
        request=BookmarkShape, responses=BookmarkShape, tags=["bookmarks"]
    )
    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)


class BookmarkDetail(RetrieveUpdateDestroyAPIView):
    queryset = Bookmark.objects.all()
    shape_class = BookmarkShape

    @extend_schema(responses=BookmarkShape, tags=["bookmarks"])
    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    @extend_schema(
        request=BookmarkShape, responses=BookmarkShape, tags=["bookmarks"]
    )
    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    @extend_schema(
        request=BookmarkShape, responses=BookmarkShape, tags=["bookmarks"]
    )
    def patch(self, request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)

    @extend_schema(tags=["bookmarks"])
    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)
