from django.urls import path
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

from example_app.views import BookmarkDetail, BookmarkList

urlpatterns = [
    path("bookmarks/", BookmarkList.as_view(), name="bookmark-list"),
    path("bookmarks/<int:pk>/", BookmarkDetail.as_view(), name="bookmark-detail"),
    path("schema/", SpectacularAPIView.as_view(), name="schema"),
    path("docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="docs"),
]
