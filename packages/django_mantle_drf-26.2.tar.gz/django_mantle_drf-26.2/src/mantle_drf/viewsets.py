"""
ViewSets using attrs shape classes instead of DRF serializers.
"""
from rest_framework.viewsets import ViewSetMixin

from .generics import GenericAPIView
from .mixins import (
    CreateModelMixin,
    DestroyModelMixin,
    ListModelMixin,
    RetrieveModelMixin,
    UpdateModelMixin,
)


class GenericViewSet(ViewSetMixin, GenericAPIView):
    """
    GenericViewSet with shape class support.

    Does not provide any actions by default.
    """

    pass


class ReadOnlyModelViewSet(RetrieveModelMixin, ListModelMixin, GenericViewSet):
    """ViewSet providing default `list()` and `retrieve()` actions."""

    pass


class ModelViewSet(
    CreateModelMixin,
    RetrieveModelMixin,
    UpdateModelMixin,
    DestroyModelMixin,
    ListModelMixin,
    GenericViewSet,
):
    """ViewSet providing default CRUD actions."""

    pass
