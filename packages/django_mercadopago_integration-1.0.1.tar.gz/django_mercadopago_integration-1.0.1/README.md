# django-mercadopago-integration

Plug-and-play Mercado Pago integration for Django. Direct integration out of the box — fully customizable via config and handlers. No model changes — declare your entity in config and the package handles linking automatically.

*Actively developed — more features and customization options are added over time.*

- **Using the package in your project?** → [**Integration guide**](INTEGRATION.md) (install, credentials, URLs, entity & webhook setup).
- **Developing or publishing this package?** → [**Developer guide**](DEVELOPER.md) (local development, testing, publishing to PyPI).

---

## What it offers (high level)

- **Direct payments** — Charge customers from your main account.
- **Third-party account linking** — Connect sellers/suppliers via OAuth; they authorize once, the package links them to your entities automatically.
- **Split payments** — Split each payment between your business and linked third parties; fees and commissions tracked in Payment, Income, and Commission models.
- **Automatic logs** — Every webhook and notification is logged in `MercadoPagoNotificationLog` for audit and debugging.
- **Notification handling** — Webhook endpoint included; processes MP notifications, creates records, and calls your custom handler when configured.

---

## What you get

| What | Description |
|------|-------------|
| **URLs** | Include `mercado_pago.urls` to get callback, payments, webhook, and refresh routes. |
| **Endpoints** | OAuth callback, direct payment (main account), notifications. Per-entity: register, disconnect, create_payment (split to that entity’s account). |
| **Callbacks** | **OAuth** `GET /mercado_pago/oauth_callback/` (MP redirect; links account to entity). **Webhook** `POST /mercado_pago/notifications/` (notifications; creates Payment/Income/Commission and optionally calls `notification_handler`). See [INTEGRATION.md → Callbacks](INTEGRATION.md#callbacks-what-they-are-and-which-ones-exist). |
| **Models** | `MercadoPagoAccount`, `MercadoPagoAccountLink`, `MercadoPagoNotificationLog`, `MercadoPagoPayment`, `MercadoPagoIncome`, `MercadoPagoAppCommission`. Payment/Income/Commission are created automatically for approved notifications. |
| **Admin** | Django admin for accounts, links, and notification logs. |

Quick start (see [INTEGRATION.md](INTEGRATION.md) for full steps):

```bash
pip install django-mercadopago-integration
```

Add `"mercado_pago"` to `INSTALLED_APPS`, run migrations, set credentials, and include the URLs. For per-entity register, disconnect, and create_payment, add `entity_model` (and optional fee/notification keys) to `MERCADO_PAGO` and mount the nested ViewSet — no code in your app, linking and payments are automatic.

License: MIT
