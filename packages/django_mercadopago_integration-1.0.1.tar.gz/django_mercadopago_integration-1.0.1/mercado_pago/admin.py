from django.contrib import admin
from .models import (
    MercadoPagoAccount,
    MercadoPagoAccountLink,
    MercadoPagoAppCommission,
    MercadoPagoIncome,
    MercadoPagoNotificationLog,
    MercadoPagoPayment,
)


class MercadoPagoAccountLinkInline(admin.TabularInline):
    model = MercadoPagoAccountLink
    extra = 0
    readonly_fields = ["content_object", "created_at"]
    can_delete = True
    show_change_link = True


@admin.register(MercadoPagoAccount)
class MercadoPagoAccountAdmin(admin.ModelAdmin):
    list_display = ["id", "mercado_pago_user_id", "links_count", "expires_at", "created_at"]
    list_filter = ["created_at"]
    search_fields = ["mercado_pago_user_id"]
    readonly_fields = ["created_at", "updated_at"]
    inlines = [MercadoPagoAccountLinkInline]

    @admin.display(description="Linked entities")
    def links_count(self, obj):
        return obj.entity_links.count()


@admin.register(MercadoPagoAccountLink)
class MercadoPagoAccountLinkAdmin(admin.ModelAdmin):
    list_display = ["id", "content_object", "account", "created_at"]
    list_filter = ["content_type", "created_at"]
    search_fields = ["object_id"]
    readonly_fields = ["content_object"]


@admin.register(MercadoPagoNotificationLog)
class MercadoPagoNotificationLogAdmin(admin.ModelAdmin):
    list_display = [
        "id", "notification_type", "mp_payment_id", "status",
        "processing_status", "created_at",
    ]
    list_filter = ["processing_status", "notification_type", "created_at"]
    search_fields = ["mp_payment_id", "processing_message"]
    readonly_fields = [
        "notification_type", "action", "mp_payment_id", "status", "status_detail",
        "processing_status", "processing_message", "raw_body", "raw_headers",
        "raw_query_params", "created_at", "updated_at",
    ]


class MercadoPagoIncomeInline(admin.TabularInline):
    model = MercadoPagoIncome
    extra = 0
    readonly_fields = ["income_type", "amount", "entity", "created_at"]
    can_delete = False
    show_change_link = True


class MercadoPagoAppCommissionInline(admin.TabularInline):
    model = MercadoPagoAppCommission
    extra = 0
    readonly_fields = ["amount", "entity", "created_at"]
    can_delete = False
    show_change_link = True


@admin.register(MercadoPagoPayment)
class MercadoPagoPaymentAdmin(admin.ModelAdmin):
    list_display = [
        "id", "mp_payment_id", "payment_type", "transaction_amount",
        "application_fee_amount", "status", "created_at",
    ]
    list_filter = ["payment_type", "status", "created_at"]
    search_fields = ["mp_payment_id", "payer_email"]
    readonly_fields = [
        "mp_payment_id", "notification_log", "status", "status_detail",
        "payment_type", "transaction_amount", "currency_id", "application_fee_amount",
        "collector_id", "entity", "payment_for", "metadata", "payer_email", "payer_id",
        "payment_method_id", "payment_type_id", "date_approved",
        "raw_payment_info", "created_at", "updated_at",
    ]
    inlines = [MercadoPagoIncomeInline, MercadoPagoAppCommissionInline]


@admin.register(MercadoPagoIncome)
class MercadoPagoIncomeAdmin(admin.ModelAdmin):
    list_display = ["id", "payment", "income_type", "amount", "entity", "created_at"]
    list_filter = ["income_type", "created_at"]
    search_fields = ["payment__mp_payment_id"]
    readonly_fields = ["payment", "income_type", "amount", "entity", "created_at"]


@admin.register(MercadoPagoAppCommission)
class MercadoPagoAppCommissionAdmin(admin.ModelAdmin):
    list_display = ["id", "payment", "amount", "entity", "created_at"]
    list_filter = ["created_at"]
    search_fields = ["payment__mp_payment_id"]
    readonly_fields = ["payment", "amount", "entity", "created_at"]
