from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class MercadoPagoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "mercado_pago"
    verbose_name = _("Mercado Pago Integration")
