"""
Configuration: single MERCADO_PAGO dict in settings (like REST_FRAMEWORK),
with validation of allowed keys and required keys.
"""
import logging
from importlib import import_module

from django.apps import apps
from django.conf import settings

logger = logging.getLogger(__name__)

# Credential keys (values passed to MercadoPagoCredentials).
MERCADO_PAGO_CREDENTIAL_KEYS = frozenset({
    "CLIENT_ID",
    "CLIENT_SECRET",
    "PUBLIC_KEY",
    "REDIRECT_URI",
    "BASE_BACKEND_URL",
    "ACCESS_TOKEN",
    "WEBHOOKS_SECRET_KEY",
})

# Config keys (entity, fee, notification handler, etc.).
MERCADO_PAGO_CONFIG_KEYS = frozenset({
    "entity_model",
    "entity_lookup_url_kwarg",
    "entity_lookup_field",
    "entity_payment_for_key",
    "entity_payment_for_model",
    "fee_amount",
    "fee_percentage",
    "fee_callback",
    "notification_handler",
    "get_entity_from_request",
    "get_entity_payment_data",
    "get_state_data",
    "resolve_user_from_state",
})

# All allowed keys in the single MERCADO_PAGO dict.
MERCADO_PAGO_ALLOWED_KEYS = MERCADO_PAGO_CREDENTIAL_KEYS | MERCADO_PAGO_CONFIG_KEYS

# ACCESS_TOKEN is required for main account payments and webhook.
MERCADO_PAGO_REQUIRED_KEYS = frozenset({"ACCESS_TOKEN"})


def _load_callable(path):
    if not path or not isinstance(path, str):
        return None
    try:
        mod_path, _, attr = path.rpartition(".")
        mod = import_module(mod_path)
        return getattr(mod, attr)
    except Exception as e:
        logger.warning("Failed to load callable %s: %s", path, e)
        return None


class MercadoPagoCredentials:
    """Holds Mercado Pago credentials. Built from settings.MERCADO_PAGO only."""

    def __init__(
        self,
        *,
        client_id=None,
        client_secret=None,
        public_key=None,
        redirect_uri=None,
        base_backend_url=None,
        access_token=None,
        webhooks_secret_key=None,
    ):
        self.client_id = client_id
        self.client_secret = client_secret
        self.public_key = public_key
        self.redirect_uri = redirect_uri
        self.base_backend_url = base_backend_url
        self.access_token = access_token
        self.webhooks_secret_key = webhooks_secret_key


_credentials_cache = None


def _get_mercado_pago_raw():
    """Return the MERCADO_PAGO dict or object from settings."""
    return getattr(settings, "MERCADO_PAGO", None)


def _validate_and_build_credentials():
    """
    Read settings.MERCADO_PAGO (dict), validate keys, build MercadoPagoCredentials.
    Only credential keys are validated and used; config keys are ignored here.
    Raises ValueError on unknown keys or missing required keys.
    """
    raw = _get_mercado_pago_raw()
    if not isinstance(raw, dict):
        raise ValueError(
            "MERCADO_PAGO must be a dict in settings (e.g. MERCADO_PAGO = {"
            '"ACCESS_TOKEN": ..., "entity_model": ..., ...}).'
        )
    unknown = set(raw) - MERCADO_PAGO_ALLOWED_KEYS
    if unknown:
        raise ValueError(
            f"MERCADO_PAGO contains unknown keys: {sorted(unknown)}. "
            f"Allowed: {sorted(MERCADO_PAGO_ALLOWED_KEYS)}."
        )
    missing = [k for k in MERCADO_PAGO_REQUIRED_KEYS if not (raw.get(k) or "").strip()]
    if missing:
        raise ValueError(
            f"MERCADO_PAGO is missing required keys (must be non-empty): {sorted(missing)}. "
            "ACCESS_TOKEN is the main account token (payments and webhook)."
        )

    base = (raw.get("BASE_BACKEND_URL") or "").strip().rstrip("/")
    redirect = (raw.get("REDIRECT_URI") or "").strip()
    if not redirect and base:
        redirect = f"{base}/mercado_pago/oauth_callback/"

    return MercadoPagoCredentials(
        client_id=raw.get("CLIENT_ID") or None,
        client_secret=raw.get("CLIENT_SECRET") or None,
        public_key=raw.get("PUBLIC_KEY") or None,
        redirect_uri=redirect or None,
        base_backend_url=base or None,
        access_token=(raw.get("ACCESS_TOKEN") or "").strip() or None,
        webhooks_secret_key=raw.get("WEBHOOKS_SECRET_KEY") or None,
    )


def get_credentials():
    """Return the credentials object from settings.MERCADO_PAGO. Validates on first access."""
    global _credentials_cache
    if _credentials_cache is None:
        _credentials_cache = _validate_and_build_credentials()
    return _credentials_cache


def get_config():
    """Config (entity, fee, notification handler) from the same MERCADO_PAGO dict."""
    raw = _get_mercado_pago_raw()
    if hasattr(raw, "get_entity_from_request"):
        return raw
    if not raw or not isinstance(raw, dict):
        return _DefaultConfig()

    class ResolvedConfig(_DefaultConfig):
        pass

    c = ResolvedConfig()
    c.entity_model = raw.get("entity_model")
    c.entity_lookup_url_kwarg = raw.get("entity_lookup_url_kwarg", "company_pk")
    c.entity_lookup_field = raw.get("entity_lookup_field", "pk")
    c.entity_payment_for_key = raw.get("entity_payment_for_key", "payment_for_id")
    c.entity_payment_for_model = raw.get("entity_payment_for_model")
    c.fee_amount = raw.get("fee_amount")
    c.fee_percentage = raw.get("fee_percentage")
    c.fee_callback = _load_callable(raw.get("fee_callback"))
    c.notification_handler = _load_callable(raw.get("notification_handler"))
    c.get_entity_from_request = _load_callable(raw.get("get_entity_from_request"))
    c.get_entity_payment_data = _load_callable(raw.get("get_entity_payment_data"))
    c.get_state_data = _load_callable(raw.get("get_state_data"))
    c.resolve_user_from_state = _load_callable(raw.get("resolve_user_from_state"))
    return c


class _DefaultConfig:
    entity_model = None
    entity_lookup_url_kwarg = "company_pk"
    entity_lookup_field = "pk"
    entity_payment_for_key = "payment_for_id"
    entity_payment_for_model = None
    fee_amount = None
    fee_percentage = None
    fee_callback = None
    notification_handler = None
    get_entity_from_request = None
    get_entity_payment_data = None
    get_state_data = None
    resolve_user_from_state = None

    def get_entity_payment_fee(self, amount, entity):
        """
        Compute the marketplace fee for a payment to an entity.
        Priority: fee_callback(amount, entity) if set, else fee_percentage of amount, else fee_amount, else 0.
        Returns a number (int or Decimal) for the fee.
        """
        from decimal import Decimal

        if self.fee_callback:
            try:
                fee = self.fee_callback(amount, entity)
                if fee is not None:
                    return Decimal(str(fee))
            except Exception as e:
                logger.warning("fee_callback failed: %s", e)
        if self.fee_percentage is not None:
            pct = Decimal(str(self.fee_percentage))
            return (Decimal(str(amount)) * pct / 100).quantize(Decimal("0.01"))
        if self.fee_amount is not None:
            return Decimal(str(self.fee_amount))
        return Decimal("0")

    def get_entity(self, request, **url_kwargs):
        if self.get_entity_from_request:
            return self.get_entity_from_request(request, **url_kwargs)
        if not self.entity_model:
            return None
        model = self.get_entity_model()
        if model is None:
            return None
        kw = self.entity_lookup_url_kwarg
        value = url_kwargs.get(kw) or getattr(request, "parser_context", {}).get("kwargs", {}).get(kw)
        if value is None:
            return None
        return model.objects.filter(**{self.entity_lookup_field: value}).first()

    def get_mp_account_for_entity(self, entity):
        """Return the MercadoPagoAccount linked to this entity, or None."""
        if entity is None:
            return None
        from django.contrib.contenttypes.models import ContentType

        from .models import MercadoPagoAccountLink

        ct = ContentType.objects.get_for_model(entity)
        link = MercadoPagoAccountLink.objects.filter(
            content_type=ct, object_id=entity.pk
        ).select_related("account").first()
        return link.account if link else None

    def get_entity_model(self):
        """Return the entity model class from entity_model string, or None.
        Uses Django's app registry (e.g. 'users.User' resolves to the User model
        in the users app), so the model need not be importable as module.Class.
        """
        if not self.entity_model:
            return None
        app_label, _, model_name = self.entity_model.rpartition(".")
        try:
            return apps.get_model(app_label, model_name)
        except (LookupError, ValueError):
            logger.warning(
                "MERCADO_PAGO entity_model %r not found in app registry.",
                self.entity_model,
            )
            return None

    def get_payment_for_model(self):
        """Return the 'payment for' model class from entity_payment_for_model string, or None.
        E.g. 'events.Event' for payments associated to an Event.
        """
        if not self.entity_payment_for_model:
            return None
        app_label, _, model_name = self.entity_payment_for_model.rpartition(".")
        try:
            return apps.get_model(app_label, model_name)
        except (LookupError, ValueError):
            logger.warning(
                "MERCADO_PAGO entity_payment_for_model %r not found in app registry.",
                self.entity_payment_for_model,
            )
            return None
