"""
Default handlers for Mercado Pago notifications.
Creates MercadoPagoPayment, MercadoPagoIncome, and MercadoPagoAppCommission records
when an approved payment is received.
"""
import logging
from datetime import datetime
from decimal import Decimal

from django.contrib.contenttypes.models import ContentType

from .conf import get_config
from .models import (
    MercadoPagoAppCommission,
    MercadoPagoIncome,
    MercadoPagoNotificationLog,
    MercadoPagoPayment,
)

logger = logging.getLogger(__name__)


def _parse_datetime(value):
    """Parse MP datetime string to datetime or None."""
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    try:
        from django.utils.dateparse import parse_datetime
        return parse_datetime(str(value))
    except (ValueError, TypeError):
        return None


def _get_application_fee_amount(payment_info):
    """
    Extract marketplace/application fee from MP payment response.
    MP may return it as: application_fee_amount (top-level), or inside fee_details
    as {"type": "application_fee", "amount": <n>}.
    """
    value = payment_info.get("application_fee_amount")
    if value is not None:
        return Decimal(str(value))
    fee_details = payment_info.get("fee_details") or []
    for detail in fee_details:
        if isinstance(detail, dict) and detail.get("type") == "application_fee":
            amount = detail.get("amount")
            if amount is not None:
                return Decimal(str(amount))
    value = payment_info.get("marketplace_fee")
    if value is not None:
        return Decimal(str(value))
    value = (payment_info.get("transaction_details") or {}).get("marketplace_fee")
    if value is not None:
        return Decimal(str(value))
    return Decimal("0")


def process_default_payment_records(payment_info, log_entry):
    """
    Create MercadoPagoPayment, MercadoPagoIncome, and MercadoPagoAppCommission records
    for an approved Mercado Pago payment.

    - Direct payment: 1 Payment + 1 Income (app_direct, full amount)
    - Split payment: 1 Payment + 1 Income (entity, net) + 1 AppCommission (fee)

    Raises on error. Returns the created MercadoPagoPayment or None if skipped.
    """
    status = payment_info.get("status")
    if status != "approved":
        logger.debug("Skipping default payment records: status=%s", status)
        return None

    mp_payment_id = str(payment_info.get("id", ""))
    if not mp_payment_id:
        return None

    transaction_amount = Decimal(str(payment_info.get("transaction_amount", 0)))
    application_fee = _get_application_fee_amount(payment_info)
    metadata = payment_info.get("metadata") or {}
    # Treat as split if we have a fee or if metadata has entity_id (payment to linked account)
    has_entity_in_metadata = metadata.get("entity_id") is not None
    is_split = application_fee > 0 or has_entity_in_metadata

    payment_type = MercadoPagoPayment.PaymentType.SPLIT if is_split else MercadoPagoPayment.PaymentType.DIRECT

    entity_id = metadata.get("entity_id")
    entity_content_type = None
    entity_object_id = None
    if entity_id is not None:
        try:
            entity_object_id = int(entity_id)
            config = get_config()
            if config.entity_model:
                entity_model = config.get_entity_model()
                if entity_model:
                    entity_content_type = ContentType.objects.get_for_model(entity_model)
        except (ValueError, TypeError, LookupError):
            logger.warning("Could not resolve entity_id=%s for payment %s", entity_id, mp_payment_id)

    payment_for_content_type = None
    payment_for_object_id = None
    payment_for_id = metadata.get("payment_for_id")
    payment_for_type = metadata.get("payment_for_type")
    if payment_for_id is not None:
        try:
            payment_for_object_id = int(payment_for_id)
            config = get_config()
            if config.entity_payment_for_model:
                payment_for_model = config.get_payment_for_model()
                if payment_for_model:
                    payment_for_content_type = ContentType.objects.get_for_model(
                        payment_for_model
                    )
            elif payment_for_type:
                app_label, _, model_name = str(payment_for_type).rpartition(".")
                if app_label and model_name:
                    from django.apps import apps
                    payment_for_model = apps.get_model(app_label, model_name)
                    payment_for_content_type = ContentType.objects.get_for_model(
                        payment_for_model
                    )
        except (ValueError, TypeError, LookupError):
            logger.warning(
                "Could not resolve payment_for_id=%s for payment %s",
                payment_for_id,
                mp_payment_id,
            )

    payment, created = MercadoPagoPayment.objects.update_or_create(
        mp_payment_id=mp_payment_id,
        defaults={
            "notification_log": log_entry,
            "status": payment_info.get("status", ""),
            "status_detail": payment_info.get("status_detail", ""),
            "payment_type": payment_type,
            "transaction_amount": transaction_amount,
            "currency_id": payment_info.get("currency_id", "UYU"),
            "application_fee_amount": application_fee,
            "collector_id": str(payment_info.get("collector_id", "")),
            "entity_content_type": entity_content_type,
            "entity_object_id": entity_object_id,
            "payment_for_content_type": payment_for_content_type,
            "payment_for_object_id": payment_for_object_id,
            "metadata": metadata,
            "payer_email": payment_info.get("payer", {}).get("email", "") or "",
            "payer_id": str(payment_info.get("payer", {}).get("id", "")) or "",
            "payment_method_id": payment_info.get("payment_method_id", "") or "",
            "payment_type_id": payment_info.get("payment_type_id", "") or "",
            "date_approved": _parse_datetime(payment_info.get("date_approved")),
            "raw_payment_info": payment_info,
        },
    )

    if not created:
        logger.debug("Payment %s already recorded, skipping income/commission creation", mp_payment_id)
        return payment

    if is_split:
        entity_net = transaction_amount - application_fee
        MercadoPagoIncome.objects.create(
            payment=payment,
            income_type=MercadoPagoIncome.IncomeType.ENTITY,
            amount=entity_net,
            entity_content_type=entity_content_type,
            entity_object_id=entity_object_id,
        )
        if application_fee > 0:
            MercadoPagoAppCommission.objects.create(
                payment=payment,
                amount=application_fee,
                entity_content_type=entity_content_type,
                entity_object_id=entity_object_id,
            )
        logger.info(
            "Recorded split payment %s: entity_net=%s, commission=%s",
            mp_payment_id, entity_net, application_fee,
        )
    else:
        MercadoPagoIncome.objects.create(
            payment=payment,
            income_type=MercadoPagoIncome.IncomeType.APP_DIRECT,
            amount=transaction_amount,
        )
        logger.info("Recorded direct payment %s: amount=%s", mp_payment_id, transaction_amount)

    return payment
