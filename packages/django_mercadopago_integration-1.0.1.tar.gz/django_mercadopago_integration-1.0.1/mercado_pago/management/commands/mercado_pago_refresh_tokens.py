"""
Refresh Mercado Pago account tokens. For use from CRON or scheduler.

Examples:
  # Refresh all accounts that need it
  python manage.py mercado_pago_refresh_tokens

  # Refresh a specific account by id
  python manage.py mercado_pago_refresh_tokens --account-id=5
"""
from django.core.management.base import BaseCommand

from mercado_pago.services import refresh_all_mp_accounts, refresh_mp_account


class Command(BaseCommand):
    help = "Refresh Mercado Pago access tokens (all accounts or one by --account-id)."

    def add_arguments(self, parser):
        parser.add_argument(
            "--account-id",
            type=int,
            default=None,
            help="Refresh only this MercadoPagoAccount id. If omitted, refresh all accounts.",
        )

    def handle(self, *args, **options):
        account_id = options["account_id"]
        if account_id is not None:
            ok = refresh_mp_account(account_id)
            if ok:
                self.stdout.write(self.style.SUCCESS(f"Token refreshed for account id={account_id}"))
            else:
                self.stdout.write(self.style.WARNING(f"Refresh skipped or failed for account id={account_id}"))
            return
        result = refresh_all_mp_accounts()
        self.stdout.write(
            self.style.SUCCESS(
                f"Refreshed: {result['refreshed']}, failed: {result['failed']}, skipped (still valid): {result['skipped']}"
            )
        )
