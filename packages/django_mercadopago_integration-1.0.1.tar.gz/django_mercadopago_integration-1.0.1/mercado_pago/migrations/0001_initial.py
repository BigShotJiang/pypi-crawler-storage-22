# Generated manually for django-mercadopago-integration

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("contenttypes", "0002_remove_content_type_name"),
    ]

    operations = [
        migrations.CreateModel(
            name="MercadoPagoAccount",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("object_id", models.PositiveIntegerField(blank=True, null=True, verbose_name="Entity ID")),
                ("mercado_pago_user_id", models.CharField(blank=True, db_index=True, max_length=255, null=True)),
                ("access_token", models.CharField(blank=True, max_length=512, null=True)),
                ("refresh_token", models.CharField(blank=True, max_length=512, null=True)),
                ("expires_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "content_type",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="+",
                        to="contenttypes.contenttype",
                        verbose_name="Entity type",
                    ),
                ),
            ],
            options={
                "verbose_name": "Mercado Pago account",
                "verbose_name_plural": "Mercado Pago accounts",
                "unique_together": {("content_type", "object_id")},
            },
        ),
        migrations.CreateModel(
            name="MercadoPagoNotificationLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("notification_type", models.CharField(blank=True, max_length=50)),
                ("action", models.CharField(blank=True, max_length=50)),
                (
                    "mp_payment_id",
                    models.CharField(
                        blank=True,
                        db_index=True,
                        max_length=255,
                        null=True,
                        verbose_name="Mercado Pago payment ID",
                    ),
                ),
                ("status", models.CharField(blank=True, max_length=50)),
                ("status_detail", models.CharField(blank=True, max_length=100)),
                (
                    "processing_status",
                    models.CharField(
                        choices=[
                            ("received", "Received"),
                            ("ignored", "Ignored"),
                            ("processed", "Processed"),
                            ("error", "Error"),
                        ],
                        default="received",
                        max_length=20,
                    ),
                ),
                ("processing_message", models.TextField(blank=True)),
                ("raw_body", models.JSONField(blank=True, null=True)),
                ("raw_headers", models.JSONField(blank=True, null=True)),
                ("raw_query_params", models.JSONField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "verbose_name": "Mercado Pago notification log",
                "verbose_name_plural": "Mercado Pago notification logs",
                "ordering": ["-created_at"],
            },
        ),
    ]
