# Migrate from single entity per account to many-to-many via MercadoPagoAccountLink
# Multiple entities can link to the same account; account is deleted only when last link is removed

import django.db.models.deletion
from django.db import migrations, models


def migrate_to_links(apps, schema_editor):
    MercadoPagoAccount = apps.get_model("mercado_pago", "MercadoPagoAccount")
    MercadoPagoAccountLink = apps.get_model("mercado_pago", "MercadoPagoAccountLink")
    ContentType = apps.get_model("contenttypes", "ContentType")

    for account in MercadoPagoAccount.objects.filter(
        content_type__isnull=False, object_id__isnull=False
    ):
        MercadoPagoAccountLink.objects.get_or_create(
            content_type_id=account.content_type_id,
            object_id=account.object_id,
            defaults={"account": account},
        )


class Migration(migrations.Migration):

    dependencies = [
        ("contenttypes", "0002_remove_content_type_name"),
        ("mercado_pago", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="MercadoPagoAccountLink",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("object_id", models.PositiveIntegerField(verbose_name="Entity ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "account",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="entity_links",
                        to="mercado_pago.MercadoPagoAccount",
                        verbose_name="Mercado Pago account",
                    ),
                ),
                (
                    "content_type",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="contenttypes.contenttype",
                        verbose_name="Entity type",
                    ),
                ),
            ],
            options={
                "verbose_name": "Mercado Pago account link",
                "verbose_name_plural": "Mercado Pago account links",
                "unique_together": {("content_type", "object_id")},
            },
        ),
        migrations.RunPython(migrate_to_links, migrations.RunPython.noop),
        migrations.AlterUniqueTogether(
            name="mercadoPagoaccount",
            unique_together=set(),
        ),
        migrations.RemoveField(
            model_name="mercadoPagoaccount",
            name="content_type",
        ),
        migrations.RemoveField(
            model_name="mercadoPagoaccount",
            name="object_id",
        ),
    ]
