# Default models for payment recording: Payment, Income, AppCommission

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("contenttypes", "0002_remove_content_type_name"),
        ("mercado_pago", "0002_account_links"),
    ]

    operations = [
        migrations.CreateModel(
            name="MercadoPagoPayment",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                (
                    "mp_payment_id",
                    models.CharField(db_index=True, max_length=255, unique=True, verbose_name="Mercado Pago payment ID"),
                ),
                ("status", models.CharField(blank=True, max_length=50)),
                ("status_detail", models.CharField(blank=True, max_length=100)),
                (
                    "payment_type",
                    models.CharField(
                        choices=[("direct", "Direct to app"), ("split", "Split (entity + commission)")],
                        db_index=True,
                        max_length=20,
                    ),
                ),
                ("transaction_amount", models.DecimalField(decimal_places=2, max_digits=14, verbose_name="Transaction amount")),
                ("currency_id", models.CharField(blank=True, default="UYU", max_length=10)),
                (
                    "application_fee_amount",
                    models.DecimalField(
                        decimal_places=2,
                        default=0,
                        max_digits=14,
                        verbose_name="App commission (marketplace fee)",
                    ),
                ),
                ("collector_id", models.CharField(blank=True, max_length=255, verbose_name="MP collector user ID (recipient of main amount)")),
                ("metadata", models.JSONField(blank=True, default=dict)),
                ("payer_email", models.EmailField(blank=True, max_length=254)),
                ("payer_id", models.CharField(blank=True, max_length=255)),
                ("payment_method_id", models.CharField(blank=True, max_length=50)),
                ("payment_type_id", models.CharField(blank=True, max_length=50)),
                ("date_approved", models.DateTimeField(blank=True, null=True)),
                ("raw_payment_info", models.JSONField(blank=True, null=True, verbose_name="Full MP API response")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "entity_content_type",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to="contenttypes.contenttype",
                        verbose_name="Entity type (for split)",
                    ),
                ),
                (
                    "entity_object_id",
                    models.PositiveIntegerField(blank=True, null=True, verbose_name="Entity ID (for split)"),
                ),
                (
                    "notification_log",
                    models.OneToOneField(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="payment_record",
                        to="mercado_pago.MercadoPagoNotificationLog",
                        verbose_name="Notification log",
                    ),
                ),
            ],
            options={
                "verbose_name": "Mercado Pago payment",
                "verbose_name_plural": "Mercado Pago payments",
                "ordering": ["-created_at"],
            },
        ),
        migrations.CreateModel(
            name="MercadoPagoIncome",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                (
                    "income_type",
                    models.CharField(
                        choices=[("app_direct", "Direct to main app"), ("entity", "To linked entity")],
                        db_index=True,
                        max_length=20,
                    ),
                ),
                ("amount", models.DecimalField(decimal_places=2, max_digits=14)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "entity_content_type",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to="contenttypes.contenttype",
                        verbose_name="Entity type (for income_type=entity)",
                    ),
                ),
                (
                    "entity_object_id",
                    models.PositiveIntegerField(blank=True, null=True, verbose_name="Entity ID"),
                ),
                (
                    "payment",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="incomes",
                        to="mercado_pago.MercadoPagoPayment",
                        verbose_name="Payment",
                    ),
                ),
            ],
            options={
                "verbose_name": "Mercado Pago income",
                "verbose_name_plural": "Mercado Pago incomes",
                "ordering": ["-created_at"],
            },
        ),
        migrations.CreateModel(
            name="MercadoPagoAppCommission",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("amount", models.DecimalField(decimal_places=2, max_digits=14)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "entity_content_type",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to="contenttypes.contenttype",
                        verbose_name="Entity (whose payment generated this commission)",
                    ),
                ),
                (
                    "entity_object_id",
                    models.PositiveIntegerField(blank=True, null=True, verbose_name="Entity ID"),
                ),
                (
                    "payment",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="app_commissions",
                        to="mercado_pago.MercadoPagoPayment",
                        verbose_name="Payment",
                    ),
                ),
            ],
            options={
                "verbose_name": "Mercado Pago app commission",
                "verbose_name_plural": "Mercado Pago app commissions",
                "ordering": ["-created_at"],
            },
        ),
    ]
