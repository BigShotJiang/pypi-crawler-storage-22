# Add payment_for GFK to MercadoPagoPayment (entity that received the payment + object the payment was for)

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("contenttypes", "0002_remove_content_type_name"),
        ("mercado_pago", "0003_payment_income_commission"),
    ]

    operations = [
        migrations.AddField(
            model_name="mercadopagopayment",
            name="payment_for_content_type",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="+",
                to="contenttypes.contenttype",
                verbose_name="Payment for type (e.g. Event, Order)",
            ),
        ),
        migrations.AddField(
            model_name="mercadopagopayment",
            name="payment_for_object_id",
            field=models.PositiveIntegerField(
                blank=True, null=True, verbose_name="Payment for object ID"
            ),
        ),
    ]
