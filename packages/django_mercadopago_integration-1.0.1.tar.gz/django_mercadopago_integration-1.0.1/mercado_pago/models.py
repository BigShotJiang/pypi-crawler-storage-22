from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models
from django.utils.translation import gettext_lazy as _


class MercadoPagoAccount(models.Model):
    """Mercado Pago account linked via OAuth (marketplace/split).
    Multiple entities (User, Company, etc.) can link to the same account.
    Links are in MercadoPagoAccountLink. The account is only deleted when the last link is removed.
    """
    mercado_pago_user_id = models.CharField(max_length=255, null=True, blank=True, db_index=True)
    access_token = models.CharField(max_length=512, null=True, blank=True)
    refresh_token = models.CharField(max_length=512, null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Mercado Pago account")
        verbose_name_plural = _("Mercado Pago accounts")

    def __str__(self):
        return f"MercadoPagoAccount({self.mercado_pago_user_id or 'pending'})"


class MercadoPagoAccountLink(models.Model):
    """Links an entity (User, Company, etc.) to a MercadoPagoAccount.
    Multiple entities can link to the same account. Each entity can have at most one link.
    When the last link is removed, the account can be deleted.
    """
    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.CASCADE,
        verbose_name=_("Entity type"),
    )
    object_id = models.PositiveIntegerField(verbose_name=_("Entity ID"))
    content_object = GenericForeignKey("content_type", "object_id")

    account = models.ForeignKey(
        MercadoPagoAccount,
        on_delete=models.CASCADE,
        related_name="entity_links",
        verbose_name=_("Mercado Pago account"),
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Mercado Pago account link")
        verbose_name_plural = _("Mercado Pago account links")
        unique_together = [["content_type", "object_id"]]

    def __str__(self):
        return f"{self.content_object} → {self.account}"


class MercadoPagoNotificationLog(models.Model):
    """Log entry for each notification received from the Mercado Pago webhook."""
    class ProcessingStatus(models.TextChoices):
        RECEIVED = "received", _("Received")
        IGNORED = "ignored", _("Ignored")
        PROCESSED = "processed", _("Processed")
        ERROR = "error", _("Error")

    notification_type = models.CharField(max_length=50, blank=True)
    action = models.CharField(max_length=50, blank=True)
    mp_payment_id = models.CharField(
        max_length=255, null=True, blank=True, verbose_name=_("Mercado Pago payment ID"), db_index=True
    )
    status = models.CharField(max_length=50, blank=True)
    status_detail = models.CharField(max_length=100, blank=True)
    processing_status = models.CharField(
        max_length=20, choices=ProcessingStatus.choices, default=ProcessingStatus.RECEIVED
    )
    processing_message = models.TextField(blank=True)
    raw_body = models.JSONField(null=True, blank=True)
    raw_headers = models.JSONField(null=True, blank=True)
    raw_query_params = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Mercado Pago notification log")
        verbose_name_plural = _("Mercado Pago notification logs")
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.notification_type or 'notification'} - {self.mp_payment_id or 'no payment'}"


class MercadoPagoPayment(models.Model):
    """
    Canonical payment record for each approved Mercado Pago payment.
    Created automatically when processing webhook notifications with status=approved.
    """
    class PaymentType(models.TextChoices):
        DIRECT = "direct", _("Direct to app")
        SPLIT = "split", _("Split (entity + commission)")

    mp_payment_id = models.CharField(
        max_length=255, unique=True, db_index=True, verbose_name=_("Mercado Pago payment ID")
    )
    notification_log = models.OneToOneField(
        MercadoPagoNotificationLog,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="payment_record",
        verbose_name=_("Notification log"),
    )
    status = models.CharField(max_length=50, blank=True)
    status_detail = models.CharField(max_length=100, blank=True)
    payment_type = models.CharField(
        max_length=20, choices=PaymentType.choices, db_index=True
    )
    transaction_amount = models.DecimalField(
        max_digits=14, decimal_places=2, verbose_name=_("Transaction amount")
    )
    currency_id = models.CharField(max_length=10, blank=True, default="UYU")
    application_fee_amount = models.DecimalField(
        max_digits=14, decimal_places=2, default=0, verbose_name=_("App commission (marketplace fee)")
    )
    collector_id = models.CharField(
        max_length=255, blank=True, verbose_name=_("MP collector user ID (recipient of main amount)")
    )
    entity_content_type = models.ForeignKey(
        ContentType,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        verbose_name=_("Entity type (for split)"),
    )
    entity_object_id = models.PositiveIntegerField(
        null=True, blank=True, verbose_name=_("Entity ID (for split)")
    )
    entity = GenericForeignKey("entity_content_type", "entity_object_id")
    payment_for_content_type = models.ForeignKey(
        ContentType,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        verbose_name=_("Payment for type (e.g. Event, Order)"),
    )
    payment_for_object_id = models.PositiveIntegerField(
        null=True, blank=True, verbose_name=_("Payment for object ID")
    )
    payment_for = GenericForeignKey("payment_for_content_type", "payment_for_object_id")
    metadata = models.JSONField(default=dict, blank=True)
    payer_email = models.EmailField(blank=True)
    payer_id = models.CharField(max_length=255, blank=True)
    payment_method_id = models.CharField(max_length=50, blank=True)
    payment_type_id = models.CharField(max_length=50, blank=True)
    date_approved = models.DateTimeField(null=True, blank=True)
    raw_payment_info = models.JSONField(null=True, blank=True, verbose_name=_("Full MP API response"))
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Mercado Pago payment")
        verbose_name_plural = _("Mercado Pago payments")
        ordering = ["-created_at"]

    def __str__(self):
        return f"Payment {self.mp_payment_id} ({self.payment_type})"


class MercadoPagoIncome(models.Model):
    """
    Money flow record: app direct (full amount to main app) or entity (net to linked account).
    Created automatically when processing approved webhook notifications.
    """
    class IncomeType(models.TextChoices):
        APP_DIRECT = "app_direct", _("Direct to main app")
        ENTITY = "entity", _("To linked entity")

    payment = models.ForeignKey(
        MercadoPagoPayment,
        on_delete=models.CASCADE,
        related_name="incomes",
        verbose_name=_("Payment"),
    )
    income_type = models.CharField(
        max_length=20, choices=IncomeType.choices, db_index=True
    )
    amount = models.DecimalField(max_digits=14, decimal_places=2)
    entity_content_type = models.ForeignKey(
        ContentType,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        verbose_name=_("Entity type (for income_type=entity)"),
    )
    entity_object_id = models.PositiveIntegerField(
        null=True, blank=True, verbose_name=_("Entity ID")
    )
    entity = GenericForeignKey("entity_content_type", "entity_object_id")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Mercado Pago income")
        verbose_name_plural = _("Mercado Pago incomes")
        ordering = ["-created_at"]

    def __str__(self):
        return f"Income {self.income_type} {self.amount} (payment {self.payment_id})"


class MercadoPagoAppCommission(models.Model):
    """
    Commission/fee received by the main app from split payments.
    Created automatically for split payments when processing approved webhook notifications.
    """
    payment = models.ForeignKey(
        MercadoPagoPayment,
        on_delete=models.CASCADE,
        related_name="app_commissions",
        verbose_name=_("Payment"),
    )
    amount = models.DecimalField(max_digits=14, decimal_places=2)
    entity_content_type = models.ForeignKey(
        ContentType,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        verbose_name=_("Entity (whose payment generated this commission)"),
    )
    entity_object_id = models.PositiveIntegerField(
        null=True, blank=True, verbose_name=_("Entity ID")
    )
    entity = GenericForeignKey("entity_content_type", "entity_object_id")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Mercado Pago app commission")
        verbose_name_plural = _("Mercado Pago app commissions")
        ordering = ["-created_at"]

    def __str__(self):
        return f"Commission {self.amount} (payment {self.payment_id})"
