from rest_framework import serializers


class MercadoPagoCallbackSerializer(serializers.Serializer):
    code = serializers.CharField()
    state = serializers.CharField()


class MercadoPagoAccountRegisterSerializer(serializers.Serializer):
    redirect_url = serializers.URLField()


class CreatePaymentSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=10, decimal_places=2)
    buyer_email = serializers.EmailField(required=False, allow_blank=True)
    back_urls = serializers.DictField(child=serializers.URLField(), required=False, allow_null=True)
    title = serializers.CharField(required=False, default="Payment", max_length=255)
    metadata = serializers.DictField(required=False, allow_null=True)


def _validate_back_urls(value):
    if value is None:
        return value
    allowed = {"success", "failure", "pending"}
    if not set(value.keys()).issubset(allowed) or not value:
        raise serializers.ValidationError(
            "back_urls must contain at least one of: success, failure, pending"
        )
    return value


class CreateEntityPaymentSerializer(serializers.Serializer):
    """Serializer for split payment to an entity. Fee is computed from MERCADO_PAGO (not in body)."""
    payment_id = serializers.CharField()
    payment_title = serializers.CharField(max_length=255)
    amount = serializers.DecimalField(max_digits=10, decimal_places=2)
    buyer_email = serializers.EmailField(required=False, allow_blank=True)
    metadata = serializers.DictField(required=False, allow_null=True)
    back_urls = serializers.DictField(child=serializers.URLField(), required=False, allow_null=True)

    def validate_back_urls(self, value):
        return _validate_back_urls(value)


def get_create_entity_payment_minimal_serializer(payment_for_key="payment_for_id"):
    """
    Build a minimal serializer whose body has one configurable key (e.g. event_id, order_id)
    for the "payment for" object id, plus back_urls. Use entity_payment_for_key in
    MERCADO_PAGO to name that key; the callback receives validated_data with that key.
    """
    return type(
        "CreateEntityPaymentMinimalSerializer",
        (serializers.Serializer,),
        {
            payment_for_key: serializers.IntegerField(
                required=True,
                help_text="ID of the object this payment is for (e.g. Event, Order).",
            ),
            "back_urls": serializers.DictField(
                child=serializers.URLField(), required=False, allow_null=True
            ),
            "validate_back_urls": lambda self, value: _validate_back_urls(value),
        },
    )
