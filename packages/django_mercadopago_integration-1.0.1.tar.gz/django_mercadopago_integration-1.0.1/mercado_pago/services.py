"""
Mercado Pago integration service. Subclass MercadoPagoBase and override
generate_token (and optionally other methods) for custom behavior.
"""
import hashlib
import hmac
import json
import logging
from abc import ABC, abstractmethod
from datetime import timedelta
from urllib.parse import quote

import requests
from django.core.cache import cache
from django.utils import timezone
from django.utils.crypto import get_random_string

from .conf import get_credentials
from .models import MercadoPagoAccount

logger = logging.getLogger(__name__)


class MercadoPagoBase(ABC):
    """Base class for Mercado Pago API. Override in your project to customize token handling, etc."""

    @staticmethod
    @abstractmethod
    def generate_token(user=None):
        """
        Return a dict with at least: {"token": str, "expires_at": datetime}.
        The token is used as OAuth `state` and to look up cached data in the callback.
        """
        pass

    @classmethod
    def register_application_link(cls, user=None, front_redirect_url=None, entity_id=None, **extra_state):
        """
        Build the Mercado Pago OAuth URL and cache state for the callback.
        entity_id is typically the PK of the model that will receive the account (e.g. Company id).
        """
        token_data = cls.generate_token(user)
        token = token_data["token"]
        state = {
            "entity_id": entity_id,
            "front_redirect_url": front_redirect_url,
            "user_id": getattr(user, "pk", None),
            **extra_state,
        }
        cache.set(token, state, timeout=6000)

        creds = get_credentials()
        redirect_uri = creds.redirect_uri or ""
        encoded_callback_uri = quote(redirect_uri, safe="")
        client_id = creds.client_id or ""

        auth_url = (
            f"https://auth.mercadopago.com/authorization"
            f"?client_id={client_id}"
            f"&response_type=code"
            f"&platform_id=mp"
            f"&redirect_uri={encoded_callback_uri}"
            f"&scope=offline_access"
            f"&state={token}"
        )
        return auth_url

    @classmethod
    def register_application_callback(cls, code, user=None):
        """
        Exchange authorization code for tokens. Creates or updates MercadoPagoAccount.
        Returns (MercadoPagoAccount, None) on success or (None, error_dict) on failure.
        """
        creds = get_credentials()
        missing = []
        if not (creds.client_id or "").strip():
            missing.append("CLIENT_ID")
        if not (creds.client_secret or "").strip():
            missing.append("CLIENT_SECRET")
        if not (creds.redirect_uri or "").strip():
            missing.append("REDIRECT_URI or BASE_BACKEND_URL")
        if missing:
            return None, {
                "error": "OAuth credentials not configured",
                "details": {
                    "message": f"Set MERCADO_PAGO with {', '.join(missing)} in Django settings to link accounts via OAuth.",
                    "missing": missing,
                },
            }
        data = {
            "grant_type": "authorization_code",
            "client_id": creds.client_id,
            "client_secret": creds.client_secret,
            "code": code,
            "redirect_uri": creds.redirect_uri,
        }
        try:
            response = requests.post("https://api.mercadopago.com/oauth/token", data=data)
            response.raise_for_status()
            tokens = response.json()
        except requests.exceptions.RequestException as e:
            details = None
            if getattr(e, "response", None) is not None:
                try:
                    details = e.response.json()
                except Exception:
                    details = {"raw": e.response.text[:500] if e.response.text else None}
            logger.warning(
                "Mercado Pago OAuth token exchange failed: %s; details=%s; redirect_uri=%s",
                e, details, getattr(creds, "redirect_uri", None),
            )
            return None, {"error": str(e), "details": details}

        account = cls.persist_account(tokens, user=user)
        return account, None

    @classmethod
    def persist_account(cls, tokens, user=None):
        """
        Create or update MercadoPagoAccount from OAuth token response.
        Override to add user to a M2M or custom logic.
        """
        account, created = MercadoPagoAccount.objects.get_or_create(
            mercado_pago_user_id=tokens.get("user_id"),
            defaults={"access_token": "", "refresh_token": "", "expires_at": None},
        )
        account.access_token = tokens.get("access_token")
        account.refresh_token = tokens.get("refresh_token", account.refresh_token)
        account.expires_at = timezone.now() + timedelta(seconds=tokens.get("expires_in", 0))
        account.save()
        return account

    @classmethod
    def get_valid_access_token(cls, mp_account):
        """Return a valid access token, refreshing if needed."""
        return cls.refresh_access_token(mp_account)

    @classmethod
    def refresh_access_token(cls, mp_account):
        """
        Refresh the access token if expired or about to expire (within 5 minutes).
        Returns the access token string or None on failure.
        """
        if (
            mp_account.expires_at
            and mp_account.expires_at > timezone.now() + timedelta(minutes=5)
        ):
            return mp_account.access_token

        logger.info("Refreshing Mercado Pago token for user_id=%s", mp_account.mercado_pago_user_id)

        creds = get_credentials()
        data = {
            "grant_type": "refresh_token",
            "client_id": creds.client_id,
            "client_secret": creds.client_secret,
            "refresh_token": mp_account.refresh_token,
        }

        try:
            response = requests.post("https://api.mercadopago.com/oauth/token", data=data)
            response.raise_for_status()
            new_tokens = response.json()

            mp_account.access_token = new_tokens["access_token"]
            mp_account.refresh_token = new_tokens.get("refresh_token", mp_account.refresh_token)
            mp_account.expires_at = timezone.now() + timedelta(seconds=new_tokens["expires_in"])
            mp_account.save()

            logger.info("Mercado Pago token refreshed for user_id=%s", mp_account.mercado_pago_user_id)
            return mp_account.access_token

        except requests.exceptions.RequestException as e:
            logger.exception("Failed to refresh Mercado Pago token: %s", e)
            return None

    @classmethod
    def create_split_payment(
        cls,
        mp_account,
        payment_id,
        payment_title,
        amount,
        buyer_email=None,
        fee_amount=0,
        metadata=None,
        back_urls=None,
        notification_url=None,
        currency_id="UYU",
    ):
        """
        Create a split payment (checkout preference) on the given MP account.
        fee_amount is the marketplace fee (app commission). The buyer is charged
        amount + fee_amount so the entity receives amount and the app receives fee_amount.
        Returns preference dict or error dict with 'error' key.
        """
        creds = get_credentials()
        base_url = (creds.base_backend_url or "").rstrip("/")
        notification_url = notification_url or f"{base_url}/mercado_pago/notifications/"

        fee = float(fee_amount)
        total_price = float(amount) + fee

        payment_data = {
            "items": [
                {
                    "id": str(payment_id),
                    "title": str(payment_title)[:256],
                    "quantity": 1,
                    "currency_id": currency_id,
                    "unit_price": total_price,
                }
            ],
            "marketplace_fee": fee,
            "notification_url": notification_url,
        }
        if buyer_email:
            payment_data["payer"] = {"email": buyer_email}
        if metadata is not None:
            payment_data["metadata"] = metadata
        if back_urls:
            payment_data["back_urls"] = back_urls
            payment_data["auto_return"] = "approved"

        access_token = cls.get_valid_access_token(mp_account)
        if not access_token:
            return {"error": "Could not obtain valid access token for Mercado Pago account"}

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }

        try:
            response = requests.post(
                "https://api.mercadopago.com/checkout/preferences",
                headers=headers,
                json=payment_data,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            body = e.response.json() if e.response else None
            return {"error": str(e), "details": body}

    @classmethod
    def create_main_app_payment(
        cls,
        amount,
        buyer_email=None,
        back_urls=None,
        title="Payment",
        currency_id="UYU",
        notification_url=None,
        metadata=None,
    ):
        """
        Create a checkout preference using the app's own access token (single account).
        Returns preference dict or error dict with 'error' key.
        """
        creds = get_credentials()
        base_url = (creds.base_backend_url or "").rstrip("/")
        notification_url = notification_url or f"{base_url}/mercado_pago/notifications/"
        access_token = creds.access_token

        preference_data = {
            "items": [
                {
                    "title": title[:256],
                    "quantity": 1,
                    "unit_price": float(amount),
                    "currency_id": currency_id,
                }
            ],
            "payer": {"email": buyer_email or "default@example.com"},
            "notification_url": notification_url,
        }
        if metadata is not None:
            preference_data["metadata"] = metadata
        if back_urls:
            preference_data["back_urls"] = back_urls
            preference_data["auto_return"] = "approved"

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }

        try:
            response = requests.post(
                "https://api.mercadopago.com/checkout/preferences",
                headers=headers,
                json=preference_data,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            body = e.response.json() if e.response else None
            return {"error": str(e), "details": body}

    @classmethod
    def refund_payment(cls, payment_id, amount=None, use_app_token=True):
        """
        Refund a payment. use_app_token=True uses MERCADO_PAGO_ACCESS_TOKEN;
        otherwise you must pass an account and we use its token (not implemented here for simplicity).
        Returns response dict or error dict.
        """
        url = f"https://api.mercadopago.com/v1/payments/{payment_id}/refunds"
        token = get_credentials().access_token if use_app_token else None
        if not token:
            return {"error": "MERCADO_PAGO_ACCESS_TOKEN not set"}
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        data = {}
        if amount is not None:
            data["amount"] = float(amount)
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            body = e.response.json() if e.response else None
            return {"error": str(e), "details": body}

    @classmethod
    def check_mp_signature(cls, request, secret_key=None):
        """
        Verify Mercado Pago webhook signature (x-signature header).

        Follows Mercado Pago docs: manifest is
        id:[data.id];request-id:[x-request-id];ts:[ts];
        with data.id in lowercase when alphanumeric. HMAC-SHA256(secret, manifest) must match v1.

        Returns True if valid or if validation is skipped (no secret configured).
        """
        x_signature = request.headers.get("x-signature") or request.headers.get("X-Signature")
        x_request_id = request.headers.get("x-request-id") or request.headers.get("X-Request-Id")

        if not x_signature or not x_request_id:
            logger.warning(
                "MP signature check: missing headers x_signature=%s x_request_id=%s",
                bool(x_signature),
                bool(x_request_id),
            )
            return False

        data_id = request.query_params.get("data.id") or request.query_params.get("id")
        data_id_source = "query"
        if not data_id:
            try:
                body_data = json.loads(request.body.decode("utf-8"))
                raw_id = body_data.get("data", {}).get("id") or body_data.get("id")
                data_id = str(raw_id) if raw_id is not None else None
                data_id_source = "body"
            except (json.JSONDecodeError, ValueError, AttributeError) as e:
                logger.debug("MP signature: could not get data.id from body: %s", e)
        if not data_id:
            logger.warning(
                "MP signature check: no data.id in query_params=%s",
                dict(request.query_params),
            )
            return False

        # Mercado Pago docs: "if the data.id_url is alphanumeric, it must be sent in lowercase"
        data_id = data_id.strip()
        if data_id and data_id.replace("-", "").replace("_", "").isalnum():
            data_id = data_id.lower()

        secret = secret_key or get_credentials().webhooks_secret_key
        if not secret:
            logger.error("MERCADO_PAGO_WEBHOOKS_SECRET_KEY not configured")
            return False

        try:
            parts = {}
            for part in x_signature.split(","):
                kv = part.split("=", 1)
                if len(kv) == 2:
                    parts[kv[0].strip()] = kv[1].strip()
            if "ts" not in parts or "v1" not in parts:
                logger.warning("MP signature check: invalid format parts=%s", parts)
                return False
            ts, received_signature = parts["ts"], parts["v1"]
        except (ValueError, KeyError) as e:
            logger.warning("MP signature check: parse error %s", e)
            return False

        manifest = f"id:{data_id};request-id:{x_request_id};ts:{ts};"
        expected = hmac.new(secret.encode(), manifest.encode(), hashlib.sha256).hexdigest()
        valid = hmac.compare_digest(expected, received_signature)

        logger.info(
            "MP signature check data_id=%r data_id_source=%s ts=%s manifest=%r "
            "expected_hex=%s received_hex=%s valid=%s",
            data_id,
            data_id_source,
            ts,
            manifest,
            expected,
            received_signature,
            valid,
        )
        if not valid:
            logger.warning(
                "MP signature mismatch: manifest=%r expected=%s received=%s",
                manifest,
                expected,
                received_signature,
            )
        return valid


class MercadoPagoService(MercadoPagoBase):
    """Default implementation using cache for OAuth state (no DB token table)."""

    @staticmethod
    def generate_token(user=None):
        return {
            "token": get_random_string(30),
            "expires_at": timezone.now() + timedelta(hours=4),
        }


def _get_service_class():
    """Return the configured service class for token refresh etc."""
    from django.conf import settings
    return getattr(settings, "MERCADO_PAGO_SERVICE_CLASS", MercadoPagoService)


def refresh_mp_account(account_or_id):
    """
    Refresh the access token for one MercadoPagoAccount.
    Call from backend (e.g. management command, Celery task).
    Pass a MercadoPagoAccount instance or its pk (int).
    Returns True if token was refreshed, False if skipped (not expired) or on error.
    """
    if isinstance(account_or_id, int):
        account = MercadoPagoAccount.objects.filter(pk=account_or_id).first()
        if not account:
            logger.warning("MercadoPagoAccount pk=%s not found", account_or_id)
            return False
    else:
        account = account_or_id
    if not account.refresh_token:
        logger.warning("MercadoPagoAccount pk=%s has no refresh_token", account.pk)
        return False
    token = _get_service_class().refresh_access_token(account)
    return token is not None


def refresh_all_mp_accounts():
    """
    Refresh access tokens for all MercadoPagoAccounts that have a refresh_token.
    Call from backend (e.g. management command, CRON).
    Returns dict: {"refreshed": int, "failed": int, "skipped": int}.
    """
    accounts = MercadoPagoAccount.objects.exclude(refresh_token__isnull=True).exclude(refresh_token="")
    result = {"refreshed": 0, "failed": 0, "skipped": 0}
    service = _get_service_class()
    for account in accounts:
        if (
            account.expires_at
            and account.expires_at > timezone.now() + timedelta(minutes=5)
        ):
            result["skipped"] += 1
            continue
        token = service.refresh_access_token(account)
        if token is not None:
            result["refreshed"] += 1
        else:
            result["failed"] += 1
    return result
