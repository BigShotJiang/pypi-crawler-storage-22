"""
URLs provided by the package. Include in your project with:

    path("mercado_pago/", include("mercado_pago.urls")),

You get: oauth_callback, notifications, create_payment_to_account.
For per-entity register/disconnect/create_payment, register EntityMercadoPagoViewSet in your router (see README).
"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import MercadoPagoViewSet

router = DefaultRouter()
router.register(r"", MercadoPagoViewSet, basename="mercado-pago")

urlpatterns = [
    path("", include(router.urls)),
]
