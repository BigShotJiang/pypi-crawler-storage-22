"""
Default views for Mercado Pago: register/disconnect entity account, OAuth callback,
create payments, and webhook notifications. Override by subclassing and changing
serializer_class, service_class, or permission_classes.
"""
import json
import logging

import requests
from django.conf import settings
from django.core.cache import cache
from django.shortcuts import redirect
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .conf import get_config, get_credentials
from .models import MercadoPagoAccount, MercadoPagoAccountLink, MercadoPagoNotificationLog
from .serializers import (
    CreateEntityPaymentSerializer,
    CreatePaymentSerializer,
    get_create_entity_payment_minimal_serializer,
    MercadoPagoAccountRegisterSerializer,
    MercadoPagoCallbackSerializer,
)
from .services import MercadoPagoService

logger = logging.getLogger(__name__)


def _get_service():
    return getattr(settings, "MERCADO_PAGO_SERVICE_CLASS", MercadoPagoService)


class EntityMercadoPagoViewSet(viewsets.GenericViewSet):
    """
    ViewSet to register or disconnect a Mercado Pago account for an entity (e.g. Company).
    Mount under a route that includes the entity PK, e.g. company_router.register(..., basename='company-mercado-pago').
    Requires MERCADO_PAGO with get_entity_from_request or entity_model + entity_lookup_url_kwarg.
    """

    permission_classes = [IsAuthenticated]
    serializer_class = MercadoPagoAccountRegisterSerializer

    def _get_entity(self):
        kwargs = self.kwargs.copy()
        if hasattr(self, "request") and self.request:
            kwargs.update(self.request.parser_context.get("kwargs", {}))
        return get_config().get_entity(self.request, **kwargs)

    @action(detail=False, methods=["post"], url_path="register")
    def register_account(self, request, **kwargs):
        entity = self._get_entity()
        if not entity:
            return Response(
                {"error": "Entity not found or MERCADO_PAGO entity config not set"},
                status=status.HTTP_404_NOT_FOUND,
            )

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        entity_id = getattr(entity, "pk", None)
        auth_url = _get_service().register_application_link(
            request.user,
            front_redirect_url=data["redirect_url"],
            entity_id=entity_id,
        )
        return Response({"auth_url": auth_url})

    @action(detail=False, methods=["post"], url_path="disconnect")
    def disconnect_account(self, request, **kwargs):
        entity = self._get_entity()
        if not entity:
            return Response(
                {"error": "Entity not found or MERCADO_PAGO entity config not set"},
                status=status.HTTP_404_NOT_FOUND,
            )

        mp_account = get_config().get_mp_account_for_entity(entity)
        if not mp_account:
            return Response(
                {"error": "This entity does not have a Mercado Pago account linked"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        from django.contrib.contenttypes.models import ContentType

        ct = ContentType.objects.get_for_model(entity)
        MercadoPagoAccountLink.objects.filter(
            content_type=ct, object_id=entity.pk
        ).delete()

        # Delete account only when the last reference is removed
        if not MercadoPagoAccountLink.objects.filter(account=mp_account).exists():
            mp_account.delete()

        return Response({
            "message": "Mercado Pago account disconnected",
        })

    @action(detail=False, methods=["post"], url_path="create_payment")
    def create_payment(self, request, **kwargs):
        """Create a split payment to this entity's Mercado Pago account. mp_account is deduced from the URL.
        If get_entity_payment_data is set, the front sends only the configured key (e.g. event_id)
        and back_urls; the callback computes payment data. Entity (receiver) and payment-for (e.g. Event)
        are associated automatically in metadata (and optionally via entity_payment_for_model)."""
        entity = self._get_entity()
        if not entity:
            return Response(
                {"error": "Entity not found or MERCADO_PAGO entity config not set"},
                status=status.HTTP_404_NOT_FOUND,
            )

        mp_account = get_config().get_mp_account_for_entity(entity)
        if not mp_account:
            return Response(
                {"error": "This entity does not have a Mercado Pago account linked"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        config = get_config()
        if config.get_entity_payment_data:
            payment_for_key = config.entity_payment_for_key or "payment_for_id"
            minimal_serializer_class = get_create_entity_payment_minimal_serializer(payment_for_key)
            serializer = minimal_serializer_class(data=request.data)
            serializer.is_valid(raise_exception=True)
            minimal_data = serializer.validated_data
            try:
                payment_data = config.get_entity_payment_data(
                    request, minimal_data, entity
                )
            except Exception as e:
                logger.exception("get_entity_payment_data failed: %s", e)
                return Response(
                    {"error": str(e) or "Failed to resolve payment data"},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            if not payment_data or not isinstance(payment_data, dict):
                return Response(
                    {"error": "get_entity_payment_data must return a dict"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                )
            data = {
                "payment_id": payment_data.get("payment_id"),
                "payment_title": payment_data.get("payment_title"),
                "amount": payment_data.get("amount"),
                "buyer_email": payment_data.get("buyer_email"),
                "metadata": payment_data.get("metadata"),
                "back_urls": minimal_data.get("back_urls"),
            }
            missing = [k for k in ("payment_id", "payment_title", "amount") if data.get(k) is None]
            if missing:
                return Response(
                    {"error": f"get_entity_payment_data must return: {', '.join(missing)}"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                )
            payment_for_id = minimal_data.get(payment_for_key)
        else:
            serializer = CreateEntityPaymentSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            data = serializer.validated_data
            payment_for_id = None

        fee_amount = config.get_entity_payment_fee(data["amount"], entity)

        metadata = dict(data.get("metadata") or {})
        metadata.setdefault("entity_id", entity.pk)
        if payment_for_id is not None:
            metadata["payment_for_id"] = payment_for_id
            if config.entity_payment_for_model:
                metadata["payment_for_type"] = config.entity_payment_for_model

        result = _get_service().create_split_payment(
            mp_account=mp_account,
            payment_id=data["payment_id"],
            payment_title=data["payment_title"],
            amount=data["amount"],
            buyer_email=data.get("buyer_email"),
            fee_amount=fee_amount,
            metadata=metadata,
            back_urls=data.get("back_urls"),
        )
        if "error" in result:
            return Response({"error": result["error"]}, status=status.HTTP_400_BAD_REQUEST)
        return Response({
            "payment_url": result.get("init_point"),
            "preference_id": result.get("id"),
        })


class MercadoPagoViewSet(viewsets.GenericViewSet):
    """
    OAuth callback, create payments, and webhook notifications.
    Override service_class or MERCADO_PAGO_SERVICE_CLASS to use a custom token flow.
    """
    queryset = MercadoPagoAccount.objects.all()

    @action(detail=False, methods=["get"], url_path="oauth_callback", authentication_classes=[], permission_classes=[])
    def oauth_callback(self, request):
        serializer = MercadoPagoCallbackSerializer(data=request.query_params)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        token = data["state"]
        code = data["code"]
        config = get_config()
        state_data = config.get_state_data(token) if config.get_state_data else cache.get(token)
        if not state_data:
            return Response(
                {"error": "Invalid or expired state. Please start the linking process again."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        user = None
        if config.resolve_user_from_state:
            user = config.resolve_user_from_state(state_data)
        account, err = _get_service().register_application_callback(code, user=user)
        if err:
            return Response(
                {"error": err.get("error", "Failed to obtain access token"), "details": err.get("details")},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Auto-link account to entity (no handler needed — set entity_model in MERCADO_PAGO)
        # Multiple entities can link to the same account; each entity has at most one link
        entity_id = state_data.get("entity_id")
        if entity_id is not None and config.entity_model:
            from django.contrib.contenttypes.models import ContentType

            try:
                entity_model = config.get_entity_model()
                ct = ContentType.objects.get_for_model(entity_model)
                MercadoPagoAccountLink.objects.update_or_create(
                    content_type=ct,
                    object_id=entity_id,
                    defaults={"account": account},
                )
            except Exception as e:
                logger.exception("Failed to link account to entity: %s", e)
                return Response(
                    {"error": "Account was created but linking failed"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                )

        redirect_url = state_data.get("front_redirect_url")
        if redirect_url:
            return redirect(redirect_url)
        return Response({"message": "Mercado Pago account linked successfully"})

    @action(detail=False, methods=["post"], permission_classes=[IsAuthenticated])
    def create_payment_to_account(self, request):
        """Create a checkout preference for the main app account (single account)."""
        serializer = CreatePaymentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        result = _get_service().create_main_app_payment(
            amount=float(data["amount"]),
            buyer_email=data.get("buyer_email"),
            back_urls=data.get("back_urls"),
            title=data.get("title", "Payment"),
            metadata=data.get("metadata"),
        )
        if "error" in result:
            return Response({"error": result["error"]}, status=status.HTTP_400_BAD_REQUEST)
        return Response({
            "preference_id": result.get("id"),
            "payment_url": result.get("init_point"),
        })

    @action(detail=False, methods=["post"], authentication_classes=[], permission_classes=[], url_path="notifications")
    def notifications(self, request):
        """Webhook endpoint for Mercado Pago. Logs the notification and delegates to MERCADO_PAGO notification_handler."""
        raw_body = request.body
        x_request_id = request.headers.get("x-request-id") or request.headers.get("X-Request-Id")

        if x_request_id:
            cache_key = f"mp_notification_{x_request_id}"
            if cache.get(cache_key):
                logger.info("Duplicate MP notification request-id=%s", x_request_id)
                return Response({"message": "Already processed"}, status=status.HTTP_200_OK)
            cache.set(cache_key, True, timeout=300)

        logger.info("MP notification received query_params=%s", dict(request.query_params))

        topic_from_query = request.query_params.get("topic")
        skip_signature_for_topic = topic_from_query == "merchant_order"
        if skip_signature_for_topic:
            logger.debug("MP notification: skipping signature check for topic=merchant_order")

        if not skip_signature_for_topic:
            try:
                valid = _get_service().check_mp_signature(request)
                if not valid and get_credentials().webhooks_secret_key:
                    logger.warning("MP notification signature invalid")
                    # Uncomment to enforce: return Response({"error": "Invalid signature"}, status=403)
            except Exception as e:
                logger.exception("Signature check failed: %s", e)

        try:
            data = json.loads(raw_body.decode("utf-8"))
        except json.JSONDecodeError as e:
            logger.error("Invalid JSON in MP notification: %s", e)
            return Response({"error": "Invalid JSON"}, status=status.HTTP_400_BAD_REQUEST)

        topic = request.query_params.get("topic") or data.get("topic")
        payment_id = data.get("data", {}).get("id") or request.query_params.get("data.id") or request.query_params.get("id")

        log_entry = MercadoPagoNotificationLog.objects.create(
            notification_type=topic or data.get("type", ""),
            action=data.get("action", ""),
            mp_payment_id=str(payment_id) if payment_id else None,
            raw_body=data,
            raw_headers={k: v for k, v in request.headers.items()},
            raw_query_params={k: request.query_params.getlist(k) for k in request.query_params},
        )

        if topic == "merchant_order":
            return Response({"message": "Merchant order acknowledged"}, status=status.HTTP_200_OK)

        if not payment_id:
            log_entry.processing_status = MercadoPagoNotificationLog.ProcessingStatus.ERROR
            log_entry.processing_message = "No payment ID provided"
            log_entry.save(update_fields=["processing_status", "processing_message"])
            return Response({"error": "No payment ID provided"}, status=status.HTTP_400_BAD_REQUEST)

        access_token = get_credentials().access_token
        if not access_token:
            log_entry.processing_status = MercadoPagoNotificationLog.ProcessingStatus.ERROR
            log_entry.processing_message = "MERCADO_PAGO_ACCESS_TOKEN not set"
            log_entry.save(update_fields=["processing_status", "processing_message"])
            return Response({"error": "Server misconfiguration"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        url = f"https://api.mercadopago.com/v1/payments/{payment_id}"
        headers = {"Authorization": f"Bearer {access_token}"}

        try:
            response = requests.get(url, headers=headers, timeout=30)
            if response.status_code == 404:
                log_entry.processing_status = MercadoPagoNotificationLog.ProcessingStatus.ERROR
                log_entry.processing_message = "Payment not found in Mercado Pago (404)"
                log_entry.save(update_fields=["processing_status", "processing_message"])
                return Response({"message": "Payment not found"}, status=status.HTTP_200_OK)
            response.raise_for_status()
            payment_info = response.json()
        except requests.exceptions.RequestException as e:
            log_entry.processing_status = MercadoPagoNotificationLog.ProcessingStatus.ERROR
            log_entry.processing_message = str(e)
            log_entry.save(update_fields=["processing_status", "processing_message"])
            return Response({"error": str(e)}, status=status.HTTP_502_BAD_GATEWAY)

        log_entry.status = payment_info.get("status", "")
        log_entry.status_detail = payment_info.get("status_detail", "")
        log_entry.save(update_fields=["status", "status_detail", "mp_payment_id"])

        if payment_info.get("status") == "approved":
            try:
                from .handlers import process_default_payment_records
                process_default_payment_records(payment_info, log_entry)
            except Exception as e:
                logger.exception("Default payment recording failed: %s", e)
                log_entry.processing_status = MercadoPagoNotificationLog.ProcessingStatus.ERROR
                log_entry.processing_message = str(e)
                log_entry.save(update_fields=["processing_status", "processing_message"])
                return Response({"message": "Recording error"}, status=status.HTTP_200_OK)

        config = get_config()
        if config.notification_handler:
            try:
                result = config.notification_handler(request, payment_info, log_entry)
                if result is not None:
                    if hasattr(result, "status_code"):
                        return result
                    return Response(result if isinstance(result, dict) else {"message": "OK"})
            except Exception as e:
                logger.exception("Notification handler failed: %s", e)
                log_entry.processing_status = MercadoPagoNotificationLog.ProcessingStatus.ERROR
                log_entry.processing_message = str(e)
                log_entry.save(update_fields=["processing_status", "processing_message"])
                return Response({"message": "Handler error"}, status=status.HTTP_200_OK)

        log_entry.processing_status = MercadoPagoNotificationLog.ProcessingStatus.PROCESSED
        log_entry.processing_message = "No handler configured"
        log_entry.save(update_fields=["processing_status", "processing_message"])
        return Response({"message": "Notification received"}, status=status.HTTP_200_OK)
