# -*- coding: utf-8 -*-
"""
DjangoMOO support commands
"""
