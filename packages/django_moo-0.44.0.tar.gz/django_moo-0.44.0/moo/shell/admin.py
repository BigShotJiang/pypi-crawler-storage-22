# -*- coding: utf-8 -*-
"""
Django backend admin support.
"""

from django.contrib import admin

# Register your models here.
