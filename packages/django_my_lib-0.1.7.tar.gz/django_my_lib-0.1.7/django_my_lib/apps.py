from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class DjangoMyLib(AppConfig):
    name = 'django_my_lib'

    verbose_name = _('Django My Lib')
