from django.apps import AppConfig


class DjangoNubladoCoreConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_nublado_core"
    verbose_name = "Django Nublado Core"

    def ready(self):
        pass
