from dataclasses import dataclass

from django.conf import settings as django_settings

from .loader import load_app_settings

# The app's settings dict name
SETTINGS_DICT_NAME = "DJANGO_NUBLADO_CORE"

# The app settings default values.
SETTINGS_DEFAULTS = {
    "DEFAULT_LANGUAGE": django_settings.LANGUAGE_CODE
}


@dataclass(frozen=True)
class AppSettings:
    DEFAULT_LANGUAGE: str


app_settings = load_app_settings(
    settings_dict_name=SETTINGS_DICT_NAME,
    defaults=SETTINGS_DEFAULTS,
    cls=AppSettings,
)

