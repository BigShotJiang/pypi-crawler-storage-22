import logging
from dataclasses import fields
from typing import Any, Type

from django.conf import settings as django_settings
from django.core.exceptions import ImproperlyConfigured

logger = logging.getLogger("django")


def load_app_settings(
    *,
    settings_dict_name: str,
    defaults: dict[str, Any],
    cls: Type,
):
    """
    Load application settings from Django settings using a defaults dict
    and a dataclass for typed access.

    Behavior:
    - Reads user overrides from django.conf.settings[settings_dict_name]
    - Applies defaults for missing values
    - Ignores unknown user-defined keys (logs a warning)
    - Only loads fields explicitly declared on the dataclass
    - Logs defaults that are not exposed by the dataclass

    Args:
        defaults:
            Dict of default values. Must define defaults for all
            dataclass fields.
        settings_dict_name:
            Name of the dict in Django settings.py
        cls:
            Dataclass type to instantiate

    Returns:
        An instance of cls populated with merged settings

    Raises:
        ImproperlyConfigured:
            If the settings value is not a dict or defaults are incomplete
    """

    # Fetch user overrides
    user_settings = getattr(django_settings, settings_dict_name, {})

    if not isinstance(user_settings, dict):
        error_message = f"{settings_dict_name} must be a dict"
        logger.error(error_message)
        raise ImproperlyConfigured(error_message)

    # Dataclass fields
    field_names = {field.name for field in fields(cls)}

    # Enforce defaults completeness
    missing_defaults = field_names - defaults.keys()
    if missing_defaults:
        error_message = (
            f"Missing default values for settings {sorted(missing_defaults)} "
            f"in {settings_dict_name}"
        )
        logger.error(error_message)
        raise ImproperlyConfigured(error_message)

    # Warn on unknown user keys
    for key in user_settings:
        if key not in defaults:
            logger.warning(
                "Unknown setting '%s' in %s (ignored)",
                key,
                settings_dict_name,
            )

    # Build final settings payload
    data = {
        key: user_settings.get(key, defaults[key])
        for key in field_names
    }

    # Log unused defaults
    unused_defaults = set(defaults) - field_names
    if unused_defaults:
        logger.info(
            "Defaults %s defined for %s but not exposed in %s",
            sorted(unused_defaults),
            settings_dict_name,
            cls.__name__,
        )

    # logger.info("%s loaded", cls.__name__)

    return cls(**data)