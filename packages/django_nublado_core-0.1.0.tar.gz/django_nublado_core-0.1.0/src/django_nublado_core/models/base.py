import uuid

from django.db import models
from django.utils import timezone
from django.conf import settings
from django.utils.translation import gettext_lazy as _


class ValidatedSaveModel(models.Model):
    """
    An abstract model that provides an explicit workaround to validate a subclassed object
    before saving it, without overriding the model's save method and inadvertently
    messing something up.
    """

    class Meta:
        abstract = True

    def validate_and_save(self, **save_kwargs):
        self.full_clean()
        self.save(**save_kwargs)


class TimestampModel(models.Model):
    """
    An abstract model that adds automatic timestamp fields for object creation and updates.
    """

    date_created = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class UUIDModel(models.Model):
    """
    An abstract model that generates a uuid for a subclassed
    model's id (primary key) field.
    """

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
    )

    class Meta:
        abstract = True


language_members = [
    (key.replace("-", "_").upper(), (key, label))
    for key, label in settings.LANGUAGES
]
language_choices_enum = models.TextChoices(
    "LanguageChoices",
    language_members,
)


class LanguageModel(models.Model):
    """
    An abstract model that provides a language choices
    field populated by the project's language settings.
    """
    LanguageChoices = language_choices_enum

    language = models.CharField(
        max_length=2,
        choices=LanguageChoices,
        default=LanguageChoices.EN,
    )

    class Meta:
        abstract = True


class PublishedModel(models.Model):
    """
    An abstract model for "publishable" models
    (e.g., blog posts, news articles) to distinguish
    published and draft objects.
    """

    class PublishedStatus(models.TextChoices):
        DRAFT = ("DRAFT", _("Draft"))
        PUBLISHED = ("PUBLISHED", _("Published"))

    published_status = models.CharField(
        max_length=20,
        choices=PublishedStatus,
        default=PublishedStatus.DRAFT,
    )
    date_published = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True

    @property
    def is_published(self):
        return self.published_status == self.PublishedStatus.PUBLISHED

    def publish(self):
        """
        Set published status to published, 
        update the date published,validate, and save.
        """
        self.published_status = self.PublishedStatus.PUBLISHED
        if not self.date_published:
            self.date_published = timezone.now()
        self.full_clean()
        self.save()

    def unpublish(self):
        """
        Set published status to draft, 
        reset the date published to None, validate, and save.
        """
        self.published_status = self.PublishedStatus.DRAFT
        self.date_published = None
        self.full_clean()
        self.save()
