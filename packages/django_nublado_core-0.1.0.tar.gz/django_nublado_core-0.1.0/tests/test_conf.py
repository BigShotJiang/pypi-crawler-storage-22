import pytest
from dataclasses import dataclass

from django.core.exceptions import ImproperlyConfigured
from django.conf import settings as django_settings

from django_nublado_core.conf.loader import load_app_settings


@pytest.fixture()
def settings_dataclass():
    @dataclass(frozen=True)
    class TestSettings:
        FOO: str
        BAR: int
    return TestSettings


@pytest.fixture()
def settings_defaults():
    defaults = {
        "FOO": "foo",
        "BAR": 123,
    }
    return defaults

@pytest.fixture()
def settings_dict_name():
    return "TEST_APP"


def set_django_setting(monkeypatch, name, value):
    monkeypatch.setattr(django_settings, name, value, raising=False)


class TestAppSettings:

    def test_load_core_settings(self):
        """
        Sanity check. Load this app's settings to make sure everything
        is hooked up correctly.
        """
        from django_nublado_core.conf.app_settings import app_settings

        assert app_settings.DEFAULT_LANGUAGE

    def test_load_app_settings_with_defaults(
        self,
        monkeypatch,
        settings_defaults,
        settings_dict_name,
        settings_dataclass,
    ):
        """
        Load app settings from default values if no user settings are provided.
        """

        set_django_setting(monkeypatch, settings_dict_name, {})

        settings_obj = load_app_settings(
            defaults=settings_defaults,
            settings_dict_name=settings_dict_name,
            cls=settings_dataclass,
        )

        assert settings_obj.FOO == "foo"
        assert settings_obj.BAR == 123

    def test_load_app_settings_with_incomplete_defaults(
        self,
        settings_dict_name,
        settings_dataclass,
    ):
        """
        Raise an ImproperlyConfigured exception if incomplete defaults
        are loaded.
        """
        incomplete_defaults = {"FOO": "foo"}
        error_message =  "Missing default values for settings ['BAR']"
        with pytest.raises(ImproperlyConfigured) as excinfo:
            settings_obj = load_app_settings(
                defaults=incomplete_defaults,
                settings_dict_name=settings_dict_name,
                cls=settings_dataclass,
            )
        assert error_message in str(excinfo.value)

    def test_load_app_settings_with_unkown_key_ignored(
        self,
        monkeypatch,
        settings_defaults,
        settings_dict_name,
        settings_dataclass,
    ):
        """
        Keys that are not contained in defaults are ignored.
        """
        # Add a non-matching setting to defaults.

        unknown_key = "UNKNOWN"

        user_app_settings = {
            "FOO": "user_foo",
            "BAR": 222,
            unknown_key: "unknown key",
        }

        set_django_setting(monkeypatch, settings_dict_name, user_app_settings)

        settings_obj = load_app_settings(
            defaults=settings_defaults,
            settings_dict_name=settings_dict_name,
            cls=settings_dataclass,
        )

        assert settings_obj.FOO == user_app_settings["FOO"]
        assert settings_obj.BAR == user_app_settings["BAR"]
        assert hasattr(settings_obj, unknown_key) is False

    def test_load_app_settings_from_django_settings(
        self,
        monkeypatch,
        settings_defaults,
        settings_dict_name,
        settings_dataclass,

    ):
        """
        App settings set in Django settings by a user update the app settings.
        """
        # partial settings
        user_app_settings = {
            "FOO": "user_foo",
        }

        set_django_setting(monkeypatch, "TEST_APP", user_app_settings)

        settings_obj = load_app_settings(
            defaults=settings_defaults,
            settings_dict_name=settings_dict_name,
            cls=settings_dataclass,
        )

        # from user
        assert settings_obj.FOO == user_app_settings["FOO"]
        # from defaults
        assert settings_obj.BAR == settings_defaults["BAR"]

        user_app_settings = {
            "BAR": 222,
        }

        set_django_setting(monkeypatch, settings_dict_name, user_app_settings)

        settings_obj = load_app_settings(
            defaults=settings_defaults,
            settings_dict_name=settings_dict_name,
            cls=settings_dataclass,
        )

        # from defaults
        assert settings_obj.FOO == settings_defaults["FOO"]
        # from user
        assert settings_obj.BAR == user_app_settings["BAR"]

        user_app_settings = {
            "FOO": "user_foo",
            "BAR": 222,
        }

        set_django_setting(monkeypatch, settings_dict_name, user_app_settings)

        settings_obj = load_app_settings(
            defaults=settings_defaults,
            settings_dict_name=settings_dict_name,
            cls=settings_dataclass,
        )

        # from user
        assert settings_obj.FOO == user_app_settings["FOO"]
        assert settings_obj.BAR == user_app_settings["BAR"]

    def test_load_app_settings_no_dict(
        self,
        monkeypatch,
        settings_defaults,
        settings_dict_name,
        settings_dataclass,
    ):
        """
        Raise an ImproperlyConfigured exception if the app settings 
        provided by the user isn't a dict.
        """
        # partial settings
        user_app_settings = "not a dict"

        set_django_setting(monkeypatch, settings_dict_name, user_app_settings)

        error_message = f"{settings_dict_name} must be a dict"
        with pytest.raises(ImproperlyConfigured) as excinfo:
            settings_obj = load_app_settings(
                defaults=settings_defaults,
                settings_dict_name=settings_dict_name,
                cls=settings_dataclass,
            )
        assert error_message in str(excinfo.value)
