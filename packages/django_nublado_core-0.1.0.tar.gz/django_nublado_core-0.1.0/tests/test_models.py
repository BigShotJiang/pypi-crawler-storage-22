import pytest
import uuid

from django.db import models, connection
from django.utils import timezone
from django.core.exceptions import ValidationError
from django.conf import settings

from django_nublado_core.models import (
    LanguageModel,
    PublishedModel,
    TimestampModel,
    ValidatedSaveModel,
    UUIDModel,
)


# Test Models
test_app_label = "test_django_nublado_core"

class ModelTestSetup:
    test_models = []

    def setup_method(self, method):
        with connection.schema_editor() as schema_editor:
            schema_editor.connection.in_atomic_block = False
            for model in self.test_models:
                schema_editor.create_model(model)

    def teardown_method(self, method):
        with connection.schema_editor() as schema_editor:
            schema_editor.connection.in_atomic_block = False
            for model in self.test_models:
                schema_editor.delete_model(model)
            schema_editor.connection.in_atomic_block = True


class ValidatedSaveTestModel(ValidatedSaveModel):
    """
    A test model that subclasses the
    abstract model ValidatedSaveModel.
    """

    name = models.CharField(max_length=200, unique=True)

    class Meta:
        db_table = "test_validatedsave_model"
        app_label = test_app_label


class TimestampTestModel(TimestampModel):
    """
    A test model that subclasses the
    abstract model TimestampModel.
    """

    name = models.CharField(max_length=200, unique=True)

    class Meta:
        db_table = "test_timestamp_model"
        app_label = test_app_label


class LanguageTestModel(LanguageModel):
    """
    A test model that subclasses the
    abstract model LanguageModel.
    """

    name = models.CharField(max_length=200, unique=True)

    class Meta(LanguageModel.Meta):
        db_table = "test_language_model"
        app_label = test_app_label


class UUIDTestModel(UUIDModel):
    """
    A test model that subclasses the
    abstract model UUIDModel.
    """

    name = models.CharField(max_length=200, unique=True)

    class Meta:
        db_table = "test_uuid_model"
        app_label = test_app_label


class PublishedTestModel(PublishedModel):
    """
    A test model that subclasses the
    abstract model PublishedModel.
    """

    name = models.CharField(max_length=200, unique=True)

    class Meta:
        db_table = "test_published_model"
        app_label = test_app_label


# Tests
@pytest.mark.django_db(transaction=True)
class TestValidatedSaveModel(ModelTestSetup):
    """
    Tests for the abstract model ValidatedSaveModel
    """

    model = ValidatedSaveTestModel
    test_models = [model]

    def test_validate_and_save_calls_full_clean_before_save(self, mocker):
        obj = self.model.objects.create(name="foo")

        spy_full_clean = mocker.spy(obj, "full_clean")
        spy_save = mocker.spy(obj, "save")

        tracker = mocker.Mock()
        tracker.attach_mock(spy_full_clean, "full_clean")
        tracker.attach_mock(spy_save, "save")

        obj.name = "foo foo"
        obj.validate_and_save()

        # Called once
        spy_full_clean.assert_called_once()
        spy_save.assert_called_once()

        # Correct order
        tracker.assert_has_calls(
            [
                mocker.call.full_clean(),
                mocker.call.save(),
            ],
            any_order=False,
        )


@pytest.mark.django_db(transaction=True)
class TestTimestampModel(ModelTestSetup):
    """
    Tests for the abstract model TimestampModel
    """

    model = TimestampTestModel
    test_models = [model]

    def test_date_created_and_date_updated_default(self):
        obj = self.model.objects.create(name="foo")

        now = timezone.now()

        assert (now - obj.date_created).total_seconds() < 2
        assert (now - obj.date_updated).total_seconds() < 2


    def test_date_updated_changes_on_save(self):
        obj = self.model.objects.create(name="foo")
        created_updated = obj.date_updated

        obj.name = "foo foo"
        obj.save()

        obj.refresh_from_db()

        assert obj.date_updated >= created_updated
        assert (timezone.now() - obj.date_updated).total_seconds() < 1


@pytest.mark.django_db(transaction=True)
class TestLanguageModel(ModelTestSetup):
    """
    Tests for the abstract model LanguageModel
    """

    model = LanguageTestModel
    test_models = [model]

    def test_language_not_in_choices(self):
        """
        Language validation is enforced via Django model validation
        (full_clean), not database constraints.
        """
        invalid_language = "xx"
        obj = self.model.objects.create(name="hello")

        error_message = f"Value '{invalid_language}' is not a valid choice."
        with pytest.raises(ValidationError) as excinfo:
            obj.language = invalid_language
            obj.full_clean()
        assert error_message in str(excinfo.value)


@pytest.mark.django_db(transaction=True)
class TestUUIDModel(ModelTestSetup):
    """
    Tests for the abstract model UUIDModel
    """

    model = UUIDTestModel
    test_models = [model]

    def test_uuid_id_field_on_create(self):
        """
        Make sure the id is a uuid value and
        the primary key.
        """
        # Check if id is set as the primary key.
        assert self.model._meta.get_field("id").primary_key is True
        obj = self.model.objects.create()

        # Check if the id is a valid UUID.
        try:
            uuid.UUID(str(obj.id), version=4)
        except ValueError as exc:
            assert False, f"{obj.id} isn't a valid UUID."
        except:
            assert False

        # id and pk need to be the same uuid value
        assert obj.id == obj.pk


@pytest.mark.django_db(transaction=True)
class TestPublishedModel(ModelTestSetup):
    """
    Tests for the abstract model PublishedModel.
    """

    model = PublishedTestModel
    test_models = [model]

    def test_default_draft(self):
        # By default, the published status is draft.
        obj = self.model.objects.create(name="foo")
        obj.full_clean()
        assert obj.published_status == obj.PublishedStatus.DRAFT

    def test_is_published(self):
        obj = self.model.objects.create(name="foo")

        # By default, is_published is false.
        assert obj.is_published is False

        # Published
        obj.published_status = obj.PublishedStatus.PUBLISHED
        obj.full_clean()
        obj.save()
        assert obj.is_published is True

        # Draft
        obj.published_status = obj.PublishedStatus.DRAFT
        obj.full_clean()
        obj.save()
        assert obj.is_published is False

    def test_publish_unpublish(self):
        obj = self.model.objects.create(name="foo")
        obj_id = obj.id


        # check date_published
        assert obj.published_status == self.model.PublishedStatus.DRAFT
        obj.publish()
        assert obj.published_status == self.model.PublishedStatus.PUBLISHED

        # Saved in db
        obj = self.model.objects.get(id=obj_id)
        assert obj.published_status == self.model.PublishedStatus.PUBLISHED

        obj.unpublish()
        assert obj.published_status == self.model.PublishedStatus.DRAFT
        assert obj.date_published is None

        # Saved in db
        obj = self.model.objects.get(id=obj_id)
        assert obj.published_status == self.model.PublishedStatus.DRAFT
        assert obj.date_published is None