import pytest

from django_nublado_core.utils import (
    strip_language_prefix_from_path,
)


def test_strip_language_prefix_from_path():
    path = "/es/about"
    stripped_path = strip_language_prefix_from_path(path)
    assert stripped_path == "/about"

    # A path with no language prefix returns the path unchanged.
    path = "/about"
    path = strip_language_prefix_from_path(path)
    assert path == "/about"
