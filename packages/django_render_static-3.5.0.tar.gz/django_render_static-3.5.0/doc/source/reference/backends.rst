backends
--------

.. automodule:: render_static.backends.django

   .. autoclass:: StaticDjangoTemplates

.. automodule:: render_static.backends.jinja2

   .. autoclass:: StaticJinja2Templates
