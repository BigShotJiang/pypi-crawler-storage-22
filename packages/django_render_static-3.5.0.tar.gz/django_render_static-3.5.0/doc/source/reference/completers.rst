management.completers
---------------------

.. automodule:: render_static.management.completers

    .. autofunction:: complete_selector
