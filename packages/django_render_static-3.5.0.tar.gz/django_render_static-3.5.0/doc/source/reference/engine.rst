engine
-------

.. automodule:: render_static.engine

   .. autoclass:: StaticTemplateEngine
    :members:
    :special-members: __getitem__
