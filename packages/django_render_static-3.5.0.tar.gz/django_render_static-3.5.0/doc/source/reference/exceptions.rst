exceptions
----------

.. automodule:: render_static.exceptions

    .. autoclass:: URLGenerationFailed
    .. autoclass:: ReversalLimitHit

