.. _reference:

=========
Reference
=========

.. automodule:: render_static


.. toctree::
   :maxdepth: 2

   engine
   backends
   loaders
   origin
   templatetags
   transpilers/index
   exceptions
   placeholders
   context
   resource
   completers
