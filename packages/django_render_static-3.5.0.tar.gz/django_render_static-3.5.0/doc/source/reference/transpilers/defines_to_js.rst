defines_to_js
-------------

.. automodule:: render_static.transpilers.defines_to_js

   .. autoclass:: DefaultDefineTranspiler
   .. autoproperty:: DefaultDefineTranspiler.context
