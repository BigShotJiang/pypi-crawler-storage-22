enums_to_js
-----------

.. automodule:: render_static.transpilers.enums_to_js

   .. autoclass:: UnrecognizedBehavior
      :members:
   .. autoclass:: EnumTranspiler
   .. autoclass:: EnumClassWriter
   .. autoproperty:: EnumClassWriter.context

