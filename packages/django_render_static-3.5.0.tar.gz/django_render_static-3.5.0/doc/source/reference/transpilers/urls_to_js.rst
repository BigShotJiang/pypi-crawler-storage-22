urls_to_js
----------

.. automodule:: render_static.transpilers.urls_to_js

   .. autoclass:: URLTreeVisitor
   .. autoproperty:: URLTreeVisitor.context
   .. autoclass:: SimpleURLWriter
   .. autoproperty:: SimpleURLWriter.context
   .. autoclass:: ClassURLWriter
   .. autoproperty:: ClassURLWriter.context
   .. autoclass:: Substitute
   .. autofunction:: normalize_ns
   .. autofunction:: build_tree
