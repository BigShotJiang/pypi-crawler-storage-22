from .django import StaticDjangoTemplates

__all__ = ["StaticDjangoTemplates"]
