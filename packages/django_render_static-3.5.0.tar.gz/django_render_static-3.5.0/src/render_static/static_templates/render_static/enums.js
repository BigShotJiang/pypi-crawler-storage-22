{% enums_to_js enums=enums transpiler=transpiler|default:'render_static.transpilers.enums_to_js.EnumClassWriter' ident=indent|default:'\t' depth=depth|default:0 %}
