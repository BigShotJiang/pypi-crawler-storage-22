{% defines_to_js defines="tests.examples.models" %}
console.log(JSON.stringify(defines));
