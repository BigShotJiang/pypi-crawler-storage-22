context
-------

.. automodule:: render_static.context

   .. autofunction:: resolve_context
