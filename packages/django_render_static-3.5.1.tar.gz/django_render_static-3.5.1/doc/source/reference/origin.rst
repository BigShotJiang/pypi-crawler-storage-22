origin
------

.. automodule:: render_static.origin

   .. autoclass:: AppOrigin
