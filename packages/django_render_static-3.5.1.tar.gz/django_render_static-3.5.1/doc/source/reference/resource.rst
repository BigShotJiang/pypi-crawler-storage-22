resource
--------

.. automodule:: render_static.resource

   .. autofunction:: resource

