templatetags.render_static
--------------------------

.. automodule:: render_static.templatetags.render_static

    .. autofunction:: split
    .. autofunction:: defines_to_js
    .. autofunction:: urls_to_js
    .. autofunction:: enums_to_js
