from django.apps import AppConfig


class RenderStaticConfig(AppConfig):
    name = "render_static"
