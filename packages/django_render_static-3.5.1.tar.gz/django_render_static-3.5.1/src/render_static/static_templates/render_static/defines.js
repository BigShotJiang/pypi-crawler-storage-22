{% defines_to_js defines=defines transpiler=transpiler|default:'render_static.transpilers.defines_to_js.DefaultDefineTranspiler' ident=indent|default:'\t' depth=depth|default:0 %}
