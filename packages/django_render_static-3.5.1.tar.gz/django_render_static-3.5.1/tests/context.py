"""
A context as a python module.
"""

VARIABLE1 = "value1"

other_variable = "value2"
