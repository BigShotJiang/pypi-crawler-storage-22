not_a_define = 1


class EmptyParent:
    class MiddleDefine:
        A_SINGLE_DEFINE = ""

        class EmptyNester:
            pass
