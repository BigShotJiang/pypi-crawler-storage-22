-afd = 'adfasdf'

this_function_doesnt_exist(afd)
