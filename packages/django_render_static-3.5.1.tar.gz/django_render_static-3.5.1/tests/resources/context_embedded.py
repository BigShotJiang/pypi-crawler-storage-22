context = {"context": "embedded"}


def get_context():
    return {"context": "embedded_callable"}


not_a_dict = 1
