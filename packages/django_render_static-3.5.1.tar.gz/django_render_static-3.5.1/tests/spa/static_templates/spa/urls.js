{% urls_to_js visitor="render_static.transpilers.ClassURLWriter" es5=es5|default:False include=include %}
