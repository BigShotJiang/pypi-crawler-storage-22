from .module2 import Class1Module2, Class2Module2
