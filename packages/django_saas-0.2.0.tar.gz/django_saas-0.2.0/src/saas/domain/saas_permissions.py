from django.utils.translation import gettext_lazy as _

from saas.registry import Severity, perm_registry

perm_registry.register_permission(
    key='org.domain.view',
    label=_('View Domain'),
    module='Organization',
    description=_('Can view the list of custom domains and their verification status'),
    severity=Severity.NORMAL,
)
perm_registry.register_permission(
    key='org.domain.create',
    label=_('Add Domain'),
    module='Organization',
    description=_('Can add new custom domains to the tenant'),
    severity=Severity.CRITICAL,
)
perm_registry.register_permission(
    key='org.domain.verify',
    label=_('Verify Domain'),
    module='Organization',
    description=_('Can trigger DNS verification checks for domains'),
    severity=Severity.HIGH,
)
perm_registry.register_permission(
    key='org.domain.manage',
    label=_('Manage Domains'),
    module='Organization',
    description=_('Can re-add domain and change the primary domain'),
    severity=Severity.CRITICAL,
)
perm_registry.register_permission(
    key='org.domain.delete',
    label=_('Delete a Domain'),
    module='Organization',
    description=_('Can delete a domain from the tenant'),
    severity=Severity.CRITICAL,
)
