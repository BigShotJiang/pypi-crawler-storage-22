from drf_spectacular.extensions import OpenApiViewExtension
from drf_spectacular.utils import extend_schema

from saas.internals.serializers import (
    PermissionSerializer,
    RoleSerializer,
    ScopeSerializer,
)


class FixedPermissionEndpoint(OpenApiViewExtension):
    target_class = 'saas.internals.endpoints.PermissionListEndpoint'

    def view_replacement(self):
        class PermissionListEndpoint(self.target_class):
            @extend_schema(tags=['Config'], summary='All Permissions', responses={200: PermissionSerializer})
            def get(self, *args, **kwargs):
                pass

        return PermissionListEndpoint


class FixedRoleEndpoint(OpenApiViewExtension):
    target_class = 'saas.internals.endpoints.RoleListEndpoint'

    def view_replacement(self):
        class RoleListEndpoint(self.target_class):
            @extend_schema(tags=['Config'], summary='All Roles', responses={200: RoleSerializer})
            def get(self, *args, **kwargs):
                pass

        return RoleListEndpoint


class FixedScopeEndpoint(OpenApiViewExtension):
    target_class = 'saas.internals.endpoints.ScopeListEndpoint'

    def view_replacement(self):
        class RoleListEndpoint(self.target_class):
            @extend_schema(tags=['Config'], summary='All Scopes', responses={200: ScopeSerializer})
            def get(self, *args, **kwargs):
                pass

        return RoleListEndpoint
