from drf_spectacular.extensions import OpenApiViewExtension
from drf_spectacular.utils import extend_schema

from saas.tenancy.serializers.group import GroupSerializer
from saas.tenancy.serializers.member import MemberSerializer


class FixedGroupListEndpoint(OpenApiViewExtension):
    target_class = 'saas.tenancy.endpoints.groups.GroupListEndpoint'

    def view_replacement(self):
        class GroupListEndpoint(self.target_class):
            @extend_schema(tags=['Tenancy'], summary='List Groups', responses={200: GroupSerializer(many=True)})
            def get(self, *args, **kwargs):
                pass

            @extend_schema(tags=['Tenancy'], summary='Create Group', responses={201: GroupSerializer})
            def post(self, *args, **kwargs):
                pass

        return GroupListEndpoint


class FixedGroupItemEndpoint(OpenApiViewExtension):
    target_class = 'saas.tenancy.endpoints.groups.GroupItemEndpoint'

    def view_replacement(self):
        class GroupItemEndpoint(self.target_class):
            @extend_schema(tags=['Tenancy'], summary='Group Details', responses={200: GroupSerializer})
            def get(self, *args, **kwargs):
                pass

            @extend_schema(tags=['Tenancy'], summary='Update Group', responses={200: GroupSerializer})
            def put(self, *args, **kwargs):
                pass

            @extend_schema(tags=['Tenancy'], summary='Partial Update Group', responses={200: GroupSerializer})
            def patch(self, *args, **kwargs):
                pass

            @extend_schema(tags=['Tenancy'], summary='Delete Group', responses={204: None})
            def delete(self, *args, **kwargs):
                pass

        return GroupItemEndpoint


class FixedMemberListEndpoint(OpenApiViewExtension):
    target_class = 'saas.tenancy.endpoints.members.MemberListEndpoint'

    def view_replacement(self):
        class MemberListEndpoint(self.target_class):
            @extend_schema(tags=['Tenancy'], summary='List Members', responses={200: MemberSerializer(many=True)})
            def get(self, *args, **kwargs):
                pass

        return MemberListEndpoint


class FixedMemberItemEndpoint(OpenApiViewExtension):
    target_class = 'saas.tenancy.endpoints.members.MemberItemEndpoint'

    def view_replacement(self):
        class MemberItemEndpoint(self.target_class):
            @extend_schema(tags=['Tenancy'], summary='Retrieve Member', responses={200: MemberSerializer})
            def get(self, *args, **kwargs):
                pass

            @extend_schema(tags=['Tenancy'], summary='Update Member', responses={200: MemberSerializer})
            def patch(self, *args, **kwargs):
                pass

            @extend_schema(tags=['Tenancy'], summary='Remove Member', responses={204: None})
            def delete(self, *args, **kwargs):
                pass

        return MemberItemEndpoint
