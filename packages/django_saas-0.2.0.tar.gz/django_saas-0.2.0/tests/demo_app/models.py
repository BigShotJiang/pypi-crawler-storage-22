from django.conf import settings
from django.db import models

from saas.db.fields import EncryptedBinaryField, EncryptedJSONField, EncryptedTextField


class UserSecret(models.Model):
    secret_key = EncryptedBinaryField(null=True, blank=True)


class TenantSecret(models.Model):
    tenant = models.ForeignKey(settings.SAAS_TENANT_MODEL, on_delete=models.CASCADE)
    secret_key = EncryptedBinaryField(null=True, blank=True)


class UserNote(models.Model):
    note = EncryptedTextField(null=True, blank=True)


class UserConfig(models.Model):
    config = EncryptedJSONField(null=True, blank=True)
