# django-search-visualizer

A Django web view for Models data search

## How To setup

1. Add the app **django_search_visualizer** to the django **INSTALLED_APPS** in **settings.py**

![howto_setup_1](images/howto_setup_1.png)

2. Include the app urls **django_search_visualizer.urls** in the django main app **urlpatterns** list in **urls.py**

![howto_setup_2](images/howto_setup_2.png)

## How To Use

1. Navigate to **/model-search**

![step_1](images/howto_1.png)

2. Select an App from the existing Apps list

![step_2](images/howto_2.png)

3. Select a Model from the existing Models list

![step_3](images/howto_3.png)

4. Select the fields that you want to see and configure the filters is required

![step_4](images/howto_4.png)

The **Look For** options are the accepted ones by django filters

5. Press "Submit" or "Download" button

![step_5](images/howto_5.png)

6. View the data

![step_6](images/howto_6.png)

7. You can click in the table headers to sort them

![step_7](images/howto_7.png)

## Notes

To use the filter **in** a list is required like:
["test1", "test2"]

## To Do

- Include an option to plot the data
