__all__ = ["APP_NAME", "VERSION"]

APP_NAME = "django-search-visualizer"

# Do not use pkg_resources to find the version but set it here directly!
# see issue #1446
VERSION = "0.1"

# Code that discovers files or modules in INSTALLED_APPS imports this module.
urls = "django_search_visualizer.urls", APP_NAME
