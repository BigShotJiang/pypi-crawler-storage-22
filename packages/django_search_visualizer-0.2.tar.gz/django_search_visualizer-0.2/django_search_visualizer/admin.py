from django.contrib import admin

import django_search_visualizer.models

# Register your models here.
class testAdmin(admin.ModelAdmin):
    list_display = ["id", "created", "modified", "field1", "field2"]
    list_filter = []
    search_fields = []

admin.site.register(django_search_visualizer.models.test, testAdmin)