from django.db import models

# Create your models here.
class test(models.Model):
    created = models.DateTimeField(null=False, editable=False, auto_now_add=True)
    modified = models.DateTimeField(null=False, auto_now=True)
    field1 = models.IntegerField(null=True, blank=True)
    field2 = models.CharField(null=True, blank=False, choices=None)
    field3 = models.DateField(null=True, blank=False, auto_now_add=True)