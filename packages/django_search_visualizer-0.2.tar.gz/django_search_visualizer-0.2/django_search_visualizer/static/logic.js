function sortTable(colIndex, header) {
    const table = document.getElementById("results_table");
    const rows = Array.from(table.querySelectorAll("tbody tr"));
    const isAsc = !header.classList.contains("sorted-asc");

    // Remove previous sort indicators
    table.querySelectorAll("th").forEach(th => th.classList.remove("sorted-asc", "sorted-desc"));

    // Sort rows
    rows.sort((a, b) => {
        let x = a.children[colIndex].innerText.trim();
        let y = b.children[colIndex].innerText.trim();

        // Convert to numbers if numeric
        if (!isNaN(x) && !isNaN(y)) { x = Number(x); y = Number(y); }

        // Convert date strings to timestamps
        if (!isNaN(Date.parse(x)) && !isNaN(Date.parse(y))) {
            x = new Date(x);
            y = new Date(y);
        }

        return isAsc ? (x > y ? 1 : -1) : (x < y ? 1 : -1);
    });

    // Append sorted rows
    const tbody = table.querySelector("tbody");
    rows.forEach(row => tbody.appendChild(row));

    // Set sort class
    header.classList.add(isAsc ? "sorted-asc" : "sorted-desc");
}


function toggleDarkMode(self) {
    if (self.checked) {
        document.documentElement.setAttribute('data-bs-theme', 'dark');
        localStorage.setItem("darkMode", true);
    }
    else {
        document.documentElement.setAttribute('data-bs-theme', 'light');
        localStorage.setItem("darkMode", false);
    }
}


// load saved setting
window.onload = function () {
    if (localStorage.getItem("darkMode") === "true") {
        document.documentElement.setAttribute('data-bs-theme', 'dark');
        document.getElementById("darkModeToggle").checked = true;
    }

    document.getElementById("select_all").addEventListener("change", function () {
        const fields_table = document.getElementById("fields_table");
        const fields_cbs = Array.from(fields_table.getElementsByClassName("field_checkbox"));
        fields_cbs.forEach(element => {
            element.checked = this.checked;
        });
    });
};


async function updateModels() {
    const app = document.getElementById("appSelect").value;

    if (!app) return;

    const response = await fetch(`/get-app-models?app=${app}`);
    const data = await response.json();

    const select_all = document.getElementById("select_all");
    select_all.checked = false;

    const fields_table = document.getElementById("fields_table");
    fields_table.tHead.innerHTML = "";
    fields_table.tBodies[0].innerHTML = "";

    const results_count = document.getElementById("results_count");
    results_count.innerHTML = "Results: ";

    const results_cmd = document.getElementById("results_cmd");
    results_cmd.innerHTML = "Command: ";

    const results_table = document.getElementById("results_table");
    results_table.tHead.innerHTML = "";
    results_table.tBodies[0].innerHTML = "";

    if (data.models) {
        const modelSelect = document.getElementById("modelSelect");
        modelSelect.innerHTML = ""

        const opt = document.createElement("option");
        opt.value = "";
        opt.textContent = "-- Select Model --";
        modelSelect.appendChild(opt);

        data.models.forEach((model, i) => {
            const opt = document.createElement("option");
            opt.value = model.toLowerCase();
            opt.textContent = model;
            modelSelect.appendChild(opt);
        });
    }
}


async function updateFields() {
    const app = document.getElementById("appSelect").value;
    const model = document.getElementById("modelSelect").value;

    if (!model) return;

    const response = await fetch(`/get-model-fields?app=${app}&model=${model}`);
    const data = await response.json();

    const select_all = document.getElementById("select_all");
    select_all.checked = false;

    const results_count = document.getElementById("results_count");
    results_count.innerHTML = "Results: ";

    const results_table = document.getElementById("results_table");
    results_table.tHead.innerHTML = "";
    results_table.tBodies[0].innerHTML = "";

    if (data.fields) {
        const fields_table = document.getElementById("fields_table");
        fields_table.tHead.innerHTML = "";
        fields_table.tBodies[0].innerHTML = "";
        fields_table.border = "1";
        fields_table.style.borderCollapse = "collapse";
        fields_table.style.marginTop = "10px";

        tr = document.createElement("tr");

        cell = document.createElement("th");
        cell.style.padding = "6px 10px";
        cell.textContent = "Fields";
        tr.appendChild(cell);

        cell = document.createElement("th");
        cell.style.padding = "6px 10px";
        cell.textContent = "Look For";
        tr.appendChild(cell);

        cell = document.createElement("th");
        cell.style.padding = "6px 10px";
        cell.textContent = "Look For Case";
        tr.appendChild(cell);

        fields_table.tHead.appendChild(tr);

        data.fields.forEach((f, i) => {
            var tr = document.createElement("tr");

            // create the field cell
            var cb = document.createElement("input");
            cb.type = "checkbox";
            cb.name = f;
            cb.id = f;
            cb.classList.add("field_checkbox");
            cb.classList.add("form-check-input");

            var lb = document.createElement("label");
            lb.for = f;
            lb.innerText = "-".repeat(f.split("__").length - 1) + f + " (" + data.fields_types[i] + ")";
            lb.classList.add("form-check-label");

            var div = document.createElement("div");
            div.classList.add("form-check");
            div.appendChild(cb);
            div.appendChild(lb);

            var cell = document.createElement("td");
            cell.style.padding = "6px 10px";
            cell.appendChild(div);
            tr.appendChild(cell);

            // create the look for case cell
            const select = document.createElement("select");
            select.id = "case_select";
            select.classList.add("form-select");

            const field_look_ups = ["", "contains", "icontains", "date", "day", "endswith", "iendswith", "exact", "iexact", "in", "isnull", "gt", "gte", "hour", "lt", "lte", "minute", "month", "quarter", "range", "regex", "iregex", "second", "startswith", "istartswith", "time", "week", "week_day", "iso_week_day", "year", "iso_year"];

            field_look_ups.forEach(item => {
                const opt = document.createElement("option");
                opt.value = item.toLowerCase();
                opt.textContent = item;
                select.appendChild(opt);
            });

            cell = document.createElement("td");
            cell.style.padding = "6px 10px";
            cell.appendChild(select);
            tr.appendChild(cell);

            // create the look for cell
            var look_for = document.createElement("input");
            look_for.type = "text";
            look_for.classList.add("form-control");

            cell = document.createElement("td");
            cell.style.padding = "6px 10px";
            cell.appendChild(look_for);
            tr.appendChild(cell);

            // append the new row
            fields_table.tBodies[0].appendChild(tr);
        });

    } else {
        fieldList.innerHTML = `<li>No fields found</li>`;
    }
}


async function get_data(download, page = 1) {
    const app = document.getElementById("appSelect").value;
    const model = document.getElementById("modelSelect").value;
    const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]').value;

    if (!model) return;

    body = {
        "app": app,
        "model": model,
        "fields": tableToJson("fields_table"),
        "page": page,
    }
    // console.log(body);

    if (download) {
        const response = await fetch("/download-model-data", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            console.log(`Response status: ${response.status}`);
        }

        const data = await response.text();

        if (data) {
            const filename = model + "_" + Date.now();
            downloadCSV(data, filename);
        } else {
            const results = document.getElementById("results");
            results.innerHTML = `<li>Error</li>`;
        }
    }
    else {
        const response = await fetch("/get-model-data", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            console.log(`Response status: ${response.status}`);
        }

        const data = await response.json();

        const results_count = document.getElementById("results_count");
        results_count.innerHTML = "Results: ";

        const results_cmd = document.getElementById("results_cmd");
        results_cmd.innerHTML = "Command: ";

        const results_table = document.getElementById("results_table");
        results_table.tHead.innerHTML = "";
        results_table.tBodies[0].innerHTML = "";

        const first_page = document.getElementById("first_page");
        first_page.innerHTML = "";
        const first_page_link = document.getElementById("first_page_link");
        const previous_page = document.getElementById("previous_page");
        previous_page.innerHTML = "";
        const previous_page_link = document.getElementById("previous_page_link");
        const current_page = document.getElementById("current_page");
        current_page.innerHTML = "";
        const current_page_link = document.getElementById("current_page_link");
        const next_page = document.getElementById("next_page");
        next_page.innerHTML = "";
        const next_page_link = document.getElementById("next_page_link");
        const last_page = document.getElementById("last_page");
        last_page.innerHTML = "";
        const last_page_link = document.getElementById("last_page_link");

        if (data.count) {
            results_count.innerHTML = "Results: " + data.count;
        }

        if (data.cmd) {
            results_cmd.innerHTML = "Command: " + data.cmd;
        }

        if (data.pagination) {
            // console.log(data.pagination);
            first_page.innerHTML = 1;
            first_page_link.setAttribute("onclick", "get_data(false, " + 1 + ")")
            previous_page.innerHTML = data.pagination.previous_page_number;
            previous_page_link.setAttribute("onclick", "get_data(false, " + data.pagination.previous_page_number + ")")
            current_page.innerHTML = data.pagination.page_num;
            current_page_link.setAttribute("onclick", "get_data(false, " + data.pagination.page_num + ")")
            next_page.innerHTML = data.pagination.next_page_number;
            next_page_link.setAttribute("onclick", "get_data(false, " + data.pagination.next_page_number + ")")
            last_page.innerHTML = data.pagination.num_pages;
            last_page_link.setAttribute("onclick", "get_data(false, " + data.pagination.num_pages + ")")
        }

        if (data.results) {
            results_table.border = "1";
            results_table.style.borderCollapse = "collapse";
            results_table.style.marginTop = "10px";

            data.results.forEach((row, i) => {
                var tr = document.createElement("tr");

                row.forEach((col, j) => {
                    if (i === 0) {
                        var cell = document.createElement("th");
                        cell.addEventListener("click", () => sortTable(j, cell));
                        cell.textContent = col;
                        cell.style.padding = "6px 10px";
                        tr.appendChild(cell);
                        results_table.tHead.appendChild(tr);
                    }
                    else {
                        var cell = document.createElement("td");
                        cell.textContent = col;
                        cell.style.padding = "6px 10px";
                        tr.appendChild(cell);
                        results_table.tBodies[0].appendChild(tr);
                    }
                });
            });
        } else {
            console.log("Error");
        }
    }
}


function downloadCSV(data, filename) {
    const blob = new Blob([data], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}


function tableToJson(tableId) {
    const table = document.getElementById(tableId);
    const data = {};

    const headers = Array.from(table.querySelectorAll("thead th")).map(th => th.textContent.trim());

    const rows = table.querySelectorAll("tbody tr");

    rows.forEach(row => {
        const rowData = {};
        const cells = row.querySelectorAll("td");

        cells.forEach((cell, i) => {
            const input = cell.getElementsByTagName("input");
            const select = cell.getElementsByTagName("select");

            if (input.length > 0) {
                if (input[0].type == "checkbox") {
                    field = input[0].name;
                    rowData["checked"] = input[0].checked;
                }
                else if (input[0].type == "text") {
                    rowData["look_for"] = input[0].value;
                }
            }
            else if (select.length > 0) {
                rowData["case"] = select[0].value;
            }
        });

        data[field] = rowData;
    });

    return data;
}


document.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        document.getElementById("submit").click();
    }
});