from django.urls import path

from django_search_visualizer import views

urlpatterns = [
    path("model-search", views.model_search, name="model_search"),
    path("get-app-models", views.get_app_models, name="get_app_models"),
    path("get-model-fields", views.get_model_fields, name="get_model_fields"),
    path("get-model-data", views.get_model_data, name="get_model_data"),
    path("download-model-data", views.download_model_data, name="download_model_data"),
]
