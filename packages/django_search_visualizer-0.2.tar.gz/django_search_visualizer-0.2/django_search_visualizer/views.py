from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from django.apps import apps
from django.db.models.fields.related import ForeignKey, ManyToOneRel, ManyToManyRel
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required, user_passes_test

import json
import datetime


@login_required(login_url="/")
@user_passes_test(lambda user: user.is_superuser, login_url="/")
def model_search(request):
    # Get all installed apps
    installed_apps_ = apps.get_app_configs()
    installed_apps = list()

    for app in installed_apps_:
        installed_apps.append(app.label)

    data = {"apps": installed_apps}

    rend = render(request, "model_search.html", data)
    resp = HttpResponse(rend)
    return resp


@login_required(login_url="/")
@user_passes_test(lambda user: user.is_superuser, login_url="/")
def get_app_models(request):
    app_name = request.GET.get("app")

    if not app_name:
        return JsonResponse({"error": "No app provided"}, status=400)

    try:
        models_ = apps.get_app_config(app_name).get_models()
        models = list()
        for model in models_:
            models.append(model.__name__)

    except LookupError:
        return JsonResponse({"error": "App not found"}, status=404)

    return JsonResponse({"models": models})


@login_required(login_url="/")
@user_passes_test(lambda user: user.is_superuser, login_url="/")
def get_model_fields(request):
    app_name = request.GET.get("app")
    model_name = request.GET.get("model")

    if not model_name:
        return JsonResponse({"error": "No model provided"}, status=400)

    try:
        model = apps.get_model(app_name, model_name)
    except LookupError:
        return JsonResponse({"error": "Model not found"}, status=404)

    fields, fields_types = analyse_field(model)

    return JsonResponse({"fields": fields, "fields_types": fields_types})


def analyse_field(model, foreign=""):
    fields = list()
    fields_types = list()

    for field in model._meta.get_fields():
        if isinstance(field, ForeignKey):
            if foreign:
                new_foreign = foreign + "__" + field.name
            else:
                new_foreign = field.name

            fields_, fields_types_ = analyse_field(field.related_model, new_foreign)
            fields += fields_
            fields_types += fields_types_

        elif isinstance(field, ManyToOneRel) or isinstance(field, ManyToManyRel):
            pass

        else:
            if foreign:
                fields.append(foreign + "__" + field.name)
            else:
                fields.append(field.name)

            fields_types.append(field.get_internal_type())

    return fields, fields_types


@login_required(login_url="/")
@user_passes_test(lambda user: user.is_superuser, login_url="/")
def get_model_data(request):
    if request.method != "POST":
        return JsonResponse({"error": "POST required"}, status=400)

    request_data = json.loads(request.body)
    app_name = request_data.get("app")
    model_name = request_data.get("model")
    fields = request_data.get("fields", [])
    page_num = request_data.get("page", 1)
    # print(fields)

    results = get_data(app_name, model_name, fields, page_num)
    
    return JsonResponse(results)
    


@login_required(login_url="/")
@user_passes_test(lambda user: user.is_superuser, login_url="/")
def download_model_data(request):
    if request.method != "POST":
        return JsonResponse({"error": "POST required"}, status=400)

    request_data = json.loads(request.body)
    app_name = request_data.get("app")
    model_name = request_data.get("model")
    fields = request_data.get("fields", [])
    page_num = request_data.get("page", 1)

    results = get_data(app_name, model_name, fields)

    if results.get("error"):
        return JsonResponse(results, status=404)
    
    else:
        data = ""
        
        if len(results.get("results", [])) > 1:
            line = ""
            for i in results.get("results", [])[0]:
                line += i + ", "
            data += line + "\n"

            for result in results.get("results", [])[1:]:
                line = ""
                for i in result:
                    line += str(i) + ", "
                data += line + "\n"

        timestamp = int(datetime.datetime.now().timestamp())
        filename = f"{model_name}_{timestamp}.csv"
        response = HttpResponse(data, content_type="text/csv")
        response["Content-Disposition"] = f"attachment; filename={filename}"
        return response


def get_data(app_name, model_name, fields, page_num=1):
    if not model_name:
        return {"error": "No model provided"}

    try:
        model = apps.get_model(app_name, model_name)
    except LookupError:
        return {"error": "Model not found"}

    results_ = model.objects.all().order_by("id")
    values_list = list()
    filters = ""
    cmd = "{}.objects.all()".format(model_name)
    pagination = dict()

    try:
        for field, values in fields.items():
            if values.get("checked"):
                values_list.append(field)

                if values.get("look_for") and values.get("case"):
                    case = values.get("case")
                    look_for = values.get("look_for")

                    if case == "isnull":
                        if look_for in ["True", "true", "1"]:
                            look_for = True

                        elif look_for in ["False", "false", "0"]:
                            look_for = False

                    elif case == "in" or case == "range":
                        look_for = json.loads(look_for)

                    filters += ".filter({}__{}={})".format(field, case, look_for)
                    kwargs = {
                        "{0}__{1}".format(field, case): look_for,
                    }
                    results_ = results_.filter(**kwargs)

        cmd = "{}.objects{}".format(model_name, filters) if filters else cmd
        # print(cmd)

        # if there are no checked fields return nothing
        if values_list:
            results_ = results_.values_list(*values_list)
            count = results_.count()
            results_ = list(results_)

            page_obj = Paginator(results_, per_page=100)
            page = page_obj.page(page_num)

            pagination = {
                "page_num": page_num,
                "count": page_obj.count,
                "num_pages": page_obj.num_pages,
                "has_next": page.has_next(),
                "has_previous": page.has_previous(),
                "next_page_number": page.next_page_number() if page.has_next() else page_num,
                "previous_page_number": page.previous_page_number() if page.has_previous() else page_num,
            }
            
            # print(pagination)
            
            # results = [values_list] + results_
            results = [values_list] + page.object_list

        else:
            count = 0
            results = list()

        # print(results)
    
    except Exception as ex:
        print(ex)
        return {"error": str(ex)}

    return {"results": results, "count": count, "cmd": cmd, "pagination": pagination}