from setuptools import setup, find_packages

setup(
    name='django-search-visualizer',
    version='0.2',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'django>=3.2',  # Specify Django version or other dependencies
    ],
    description='A Django web view for Models data search',
    author='Filipe Fraqueiro',
    author_email='fraqueirofilipe@gmail.com',
    url='https://github.com/filipefraqueiro/django-search-visualizer',
    classifiers=[
        'Framework :: Django',
        'Programming Language :: Python :: 3',
    ],
    package_data={
        # Specify the package and the files to include
        "django_search_visualizer": ["static/*", "templates/*.html"],
    },
)
