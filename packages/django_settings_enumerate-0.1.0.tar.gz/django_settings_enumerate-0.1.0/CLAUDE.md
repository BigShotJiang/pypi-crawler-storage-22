# Project Instructions

**See [CLAUDE.xml](./CLAUDE.xml) for complete structured project instructions.**

This project uses XML format for better structure, machine parseability, and consistency with the brain/ knowledge base architecture.

## Quick Reference

### Critical Startup - INTERRUPT PATTERN
**STOP → CHECK brain/index.xml → ROUTE → LEARN → PROCEED**

When you see: tests, pytest, test failures, debugging, implementation, or refactoring:
1. **STOP** - Do NOT analyze yet
2. **CHECK** - Read `brain/index.xml` RIGHT NOW
3. **ROUTE** - Find pattern-id from intent-pattern-map
4. **LEARN** - Read `brain/patterns/{pattern-id}.xml`
5. **PROCEED** - Only now implement using the pattern

NEVER use LLM bling in commit messages.

**If user has to remind you to check brain/, you FAILED.**

### Token Optimization (NEW - 2025-10-09)
- **Use ctags MCP FIRST** for code navigation before reading files
- **Use Grep with context flags** (-A, -B, -C) instead of full file reads
- **Progressive disclosure**: Start cheap (Glob/ctags) → Get specific (Grep context) → Only full Read when needed

### Python Environment
- Always use `uv run` for Python operations
- Never use `python` or `python3` directly

### Brain Maintenance
- Edit pattern files directly in `brain/patterns/*.xml`
- Run `uv run python brain/update_index.py` after changes
- Run `uv run python brain/validate_brain.py` to ensure consistency

---

**Full documentation with examples, workflows, and detailed strategies**: [CLAUDE.xml](./CLAUDE.xml)
