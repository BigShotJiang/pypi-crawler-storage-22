# TODO — django-settings-enumerate

## Tasks

| # | Task | Status | Blocked By | Deep Think | Notes |
|---|------|--------|------------|:----------:|-------|
| 1 | Set up Django app package structure | done | — | No | Standard Django reusable app layout with management/commands/ |
| 2 | Implement the management command | done | 1 | **Yes** | CLI API design: flags (--names-only, --format, --filter), sensitive masking heuristics, output formats |
| 3 | Extract core logic into pure functions | done | 2 | **Yes** | Function boundaries, signatures, separation of command shell vs. business logic |
| 4 | Write tests for core logic | done | 3 | No | 28 tests, all passing |
| 5 | Update pyproject.toml with packaging metadata | done | 1 | No | hatchling build, pytest config, dev deps |
| 6 | Clean up and initial git commit | done | 4, 5 | No | Removed placeholder main.py, all tests green |

## Deep Think Rationale

Tasks marked **Yes** benefit from extended reasoning before implementation:

- **Task 2 (management command)**: Multiple design decisions — what flags to expose, how to detect sensitive settings, default behavior, output formatting. Thinking upfront avoids rework.
- **Task 3 (pure function extraction)**: The core architectural decision. Where to draw function boundaries determines testability and reusability of the entire package. Getting this right matters.

Tasks marked **No** are mechanical/boilerplate or follow directly from prior decisions.

## Dependency Graph

```
1 (app structure)
├── 2 (management command)
│   └── 3 (extract pure functions)
│       └── 4 (tests)
│           └── 6 (cleanup + commit)
└── 5 (pyproject.toml)
    └── 6 (cleanup + commit)
```
