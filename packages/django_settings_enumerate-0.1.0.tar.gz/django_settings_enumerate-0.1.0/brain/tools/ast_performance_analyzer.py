#!/usr/bin/env python3
"""
AST-based Performance Analyzer

Analyzes Python code for:
- Cyclomatic complexity
- Nesting depth
- Lines of code (LOC)
- Function parameters and returns
- Code structure metrics

Usage:
    uv run python brain/tools/ast_performance_analyzer.py src/
    uv run python brain/tools/ast_performance_analyzer.py src/ --threshold 15 --format json
    uv run python brain/tools/ast_performance_analyzer.py src/ --output reports/complexity-audit.md

See doc/thoughts/01-ast-performance-analyzer.md for design rationale.
"""

import ast
import sys
import json
import argparse
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Optional, Dict
from enum import Enum


# ============================================================================
# Data Models
# ============================================================================

@dataclass
class FunctionMetrics:
    """Metrics for a single function/method"""
    name: str
    qualified_name: str
    file_path: str
    lineno: int
    end_lineno: int
    complexity: int  # Cyclomatic complexity
    max_nesting_depth: int
    loc: int  # Lines of code
    num_params: int
    num_returns: int
    is_async: bool
    is_method: bool = False
    class_name: Optional[str] = None


@dataclass
class FileMetrics:
    """Metrics for a single Python file"""
    file_path: str
    total_functions: int = 0
    total_loc: int = 0
    avg_complexity: float = 0.0
    max_complexity: int = 0
    functions: List[FunctionMetrics] = field(default_factory=list)


@dataclass
class CodebaseMetrics:
    """Aggregate metrics for entire codebase"""
    total_files: int = 0
    total_functions: int = 0
    total_loc: int = 0
    avg_complexity: float = 0.0
    max_complexity: int = 0
    files: List[FileMetrics] = field(default_factory=list)
    hotspots: List[FunctionMetrics] = field(default_factory=list)  # complexity > threshold


# ============================================================================
# AST Visitor for Complexity Calculation
# ============================================================================

class ComplexityVisitor(ast.NodeVisitor):
    """
    Calculate cyclomatic complexity and nesting depth for a function.

    Cyclomatic Complexity = 1 + number of decision points
    Decision points: If, While, For, AsyncFor, ExceptHandler, AsyncWith,
                    and comprehension conditionals

    Design based on radon's approach for consistency.
    """

    def __init__(self):
        self.complexity = 1  # Start at 1 (base path)
        self.max_nesting = 0
        self.current_nesting = 0
        self.num_returns = 0

    def _enter_block(self):
        """Enter a nested block"""
        self.current_nesting += 1
        self.max_nesting = max(self.max_nesting, self.current_nesting)

    def _exit_block(self):
        """Exit a nested block"""
        self.current_nesting -= 1

    def visit_If(self, node):
        """If statement (+1 complexity)"""
        self.complexity += 1
        self._enter_block()
        self.generic_visit(node)
        self._exit_block()

    def visit_While(self, node):
        """While loop (+1 complexity)"""
        self.complexity += 1
        self._enter_block()
        self.generic_visit(node)
        self._exit_block()

    def visit_For(self, node):
        """For loop (+1 complexity)"""
        self.complexity += 1
        self._enter_block()
        self.generic_visit(node)
        self._exit_block()

    def visit_AsyncFor(self, node):
        """Async for loop (+1 complexity)"""
        self.complexity += 1
        self._enter_block()
        self.generic_visit(node)
        self._exit_block()

    def visit_ExceptHandler(self, node):
        """Exception handler (+1 complexity)"""
        self.complexity += 1
        self._enter_block()
        self.generic_visit(node)
        self._exit_block()

    def visit_AsyncWith(self, node):
        """Async with statement (+1 complexity)"""
        self.complexity += 1
        self._enter_block()
        self.generic_visit(node)
        self._exit_block()

    def visit_Return(self, node):
        """Return statement (count for metrics, not complexity)"""
        self.num_returns += 1
        self.generic_visit(node)

    def visit_FunctionDef(self, node):
        """Don't traverse nested functions (they get separate analysis)"""
        pass

    def visit_AsyncFunctionDef(self, node):
        """Don't traverse nested async functions"""
        pass

    # Comprehension handling - count conditionals
    def visit_ListComp(self, node):
        """List comprehension - count if clauses"""
        for generator in node.generators:
            for if_clause in generator.ifs:
                self.complexity += 1
        self.generic_visit(node)

    def visit_SetComp(self, node):
        """Set comprehension - count if clauses"""
        for generator in node.generators:
            for if_clause in generator.ifs:
                self.complexity += 1
        self.generic_visit(node)

    def visit_DictComp(self, node):
        """Dict comprehension - count if clauses"""
        for generator in node.generators:
            for if_clause in generator.ifs:
                self.complexity += 1
        self.generic_visit(node)

    def visit_GeneratorExp(self, node):
        """Generator expression - count if clauses"""
        for generator in node.generators:
            for if_clause in generator.ifs:
                self.complexity += 1
        self.generic_visit(node)


# ============================================================================
# Codebase Analyzer
# ============================================================================

class CodebaseAnalyzer:
    """Analyze entire codebase for performance metrics"""

    EXCLUDE_PATTERNS = {
        '__pycache__', '.venv', 'venv', '.tox', '.pytest_cache',
        'build', 'dist', '.eggs', '*.egg-info', 'node_modules'
    }

    def __init__(self, root_path: Path, complexity_threshold: int = 15):
        self.root_path = root_path
        self.complexity_threshold = complexity_threshold
        self.metrics = CodebaseMetrics()
        self.errors = []

    def analyze(self) -> CodebaseMetrics:
        """Analyze all Python files in codebase"""
        python_files = self._find_python_files()

        for file_path in python_files:
            file_metrics = self._analyze_file(file_path)
            if file_metrics:
                self.metrics.files.append(file_metrics)

        self._calculate_summary()
        return self.metrics

    def _find_python_files(self) -> List[Path]:
        """Find all Python files, excluding common non-source locations"""
        python_files = []

        for py_file in self.root_path.rglob("**/*.py"):
            # Skip excluded directories
            if any(pattern in str(py_file) for pattern in self.EXCLUDE_PATTERNS):
                continue
            python_files.append(py_file)

        return sorted(python_files)

    def _analyze_file(self, file_path: Path) -> Optional[FileMetrics]:
        """Analyze a single Python file"""
        try:
            source = file_path.read_text(encoding='utf-8')
            tree = ast.parse(source, filename=str(file_path))
        except (SyntaxError, UnicodeDecodeError) as e:
            error_msg = f"Could not parse {file_path}: {e}"
            self.errors.append(error_msg)
            print(f"Warning: {error_msg}", file=sys.stderr)
            return None

        rel_path = str(file_path.relative_to(self.root_path))
        file_metrics = FileMetrics(file_path=rel_path)

        # Analyze all top-level and class-level functions
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                func_metrics = self._analyze_function(node, rel_path)
                if func_metrics:
                    file_metrics.functions.append(func_metrics)

                    # Track hotspots
                    if func_metrics.complexity >= self.complexity_threshold:
                        self.metrics.hotspots.append(func_metrics)

        # Calculate file-level aggregates
        if file_metrics.functions:
            file_metrics.total_functions = len(file_metrics.functions)
            file_metrics.total_loc = sum(f.loc for f in file_metrics.functions)
            file_metrics.avg_complexity = (
                sum(f.complexity for f in file_metrics.functions) / len(file_metrics.functions)
            )
            file_metrics.max_complexity = max(f.complexity for f in file_metrics.functions)

        return file_metrics

    def _analyze_function(self, node, file_path: str) -> FunctionMetrics:
        """Analyze a single function"""
        visitor = ComplexityVisitor()
        # Visit the function body, not the function node itself
        # (visiting the function node would trigger the empty visit_FunctionDef method)
        for stmt in node.body:
            visitor.visit(stmt)

        # Calculate LOC
        loc = node.end_lineno - node.lineno + 1 if node.end_lineno else 1

        # Get function characteristics
        is_async = isinstance(node, ast.AsyncFunctionDef)

        # Count parameters
        num_params = len(node.args.args) + len(node.args.kwonlyargs)
        if node.args.vararg:
            num_params += 1
        if node.args.kwarg:
            num_params += 1

        # Create qualified name (TODO: could add class name prefix)
        qualified_name = node.name

        return FunctionMetrics(
            name=node.name,
            qualified_name=qualified_name,
            file_path=file_path,
            lineno=node.lineno,
            end_lineno=node.end_lineno or node.lineno,
            complexity=visitor.complexity,
            max_nesting_depth=visitor.max_nesting,
            loc=loc,
            num_params=num_params,
            num_returns=visitor.num_returns,
            is_async=is_async,
            is_method=False,  # TODO: Detect if inside class
        )

    def _calculate_summary(self):
        """Calculate codebase-wide summary statistics"""
        self.metrics.total_files = len(self.metrics.files)

        all_functions = [f for file in self.metrics.files for f in file.functions]
        self.metrics.total_functions = len(all_functions)

        if all_functions:
            self.metrics.total_loc = sum(f.loc for f in all_functions)
            self.metrics.avg_complexity = (
                sum(f.complexity for f in all_functions) / len(all_functions)
            )
            self.metrics.max_complexity = max(f.complexity for f in all_functions)

        # Sort hotspots by complexity descending
        self.metrics.hotspots.sort(key=lambda f: f.complexity, reverse=True)


# ============================================================================
# Output Formatters
# ============================================================================

class OutputFormatter:
    """Format analysis results for different outputs"""

    @staticmethod
    def to_json(metrics: CodebaseMetrics, output_file: Path):
        """Export to JSON for machine consumption"""
        data = asdict(metrics)
        with output_file.open('w') as f:
            json.dump(data, f, indent=2)
        print(f"JSON output written to: {output_file}")

    @staticmethod
    def to_markdown(metrics: CodebaseMetrics, output_file: Path, threshold: int = 15):
        """Export to Markdown for human consumption"""
        with output_file.open('w') as f:
            f.write("# Codebase Complexity Analysis\n\n")
            f.write(f"*Generated by AST Performance Analyzer*\n\n")

            # Summary
            f.write("## Summary\n\n")
            f.write(f"- **Total Files:** {metrics.total_files}\n")
            f.write(f"- **Total Functions:** {metrics.total_functions}\n")
            f.write(f"- **Total LOC:** {metrics.total_loc:,}\n")
            f.write(f"- **Average Complexity:** {metrics.avg_complexity:.2f}\n")
            f.write(f"- **Maximum Complexity:** {metrics.max_complexity}\n")
            f.write(f"- **Functions >{threshold} complexity:** {len(metrics.hotspots)}\n\n")

            # Hotspots
            if metrics.hotspots:
                f.write(f"## Complexity Hotspots (>{threshold})\n\n")
                f.write("*Functions exceeding complexity threshold - candidates for refactoring*\n\n")
                f.write("| Function | File | Line | Complexity | Nesting | LOC | Params | Returns |\n")
                f.write("|----------|------|------|------------|---------|-----|--------|----------|\n")
                for func in metrics.hotspots:
                    async_marker = " (async)" if func.is_async else ""
                    f.write(
                        f"| {func.name}{async_marker} | {func.file_path} | {func.lineno} | "
                        f"{func.complexity} | {func.max_nesting_depth} | {func.loc} | "
                        f"{func.num_params} | {func.num_returns} |\n"
                    )
                f.write("\n")

            # Per-file breakdown (top 20 by max complexity)
            f.write("## Per-File Analysis (Top 20 by Complexity)\n\n")
            sorted_files = sorted(metrics.files, key=lambda f: f.max_complexity, reverse=True)
            for file in sorted_files[:20]:
                if file.total_functions == 0:
                    continue

                f.write(f"### {file.file_path}\n\n")
                f.write(f"- **Functions:** {file.total_functions}\n")
                f.write(f"- **Total LOC:** {file.total_loc}\n")
                f.write(f"- **Average Complexity:** {file.avg_complexity:.2f}\n")
                f.write(f"- **Maximum Complexity:** {file.max_complexity}\n\n")

                # Show complex functions in this file
                complex_funcs = [fn for fn in file.functions if fn.complexity >= 8]
                if complex_funcs:
                    f.write("**Complex Functions:**\n\n")
                    for func in sorted(complex_funcs, key=lambda fn: fn.complexity, reverse=True):
                        async_marker = " (async)" if func.is_async else ""
                        f.write(
                            f"- `{func.name}{async_marker}` (line {func.lineno}): "
                            f"complexity {func.complexity}, nesting {func.max_nesting_depth}\n"
                        )
                    f.write("\n")

        print(f"Markdown output written to: {output_file}")

    @staticmethod
    def print_summary(metrics: CodebaseMetrics):
        """Print summary to console"""
        print("\n" + "=" * 80)
        print("CODEBASE COMPLEXITY ANALYSIS SUMMARY")
        print("=" * 80)
        print(f"\nTotal Files: {metrics.total_files}")
        print(f"Total Functions: {metrics.total_functions}")
        print(f"Total LOC: {metrics.total_loc:,}")
        print(f"Average Complexity: {metrics.avg_complexity:.2f}")
        print(f"Maximum Complexity: {metrics.max_complexity}")
        print(f"Functions >15: {len([h for h in metrics.hotspots if h.complexity > 15])}")
        print(f"Functions 11-15: {len([h for h in metrics.hotspots if 11 <= h.complexity <= 15])}")

        if metrics.hotspots:
            print("\n" + "-" * 80)
            print("TOP 10 MOST COMPLEX FUNCTIONS")
            print("-" * 80)
            print(f"{'Function':<35} {'File':<30} {'CC':>4} {'Nest':>4} {'LOC':>5}")
            print("-" * 80)

            for func in metrics.hotspots[:10]:
                async_marker = "async " if func.is_async else ""
                name = f"{async_marker}{func.name}"[:34]
                file = func.file_path[:29]
                print(f"{name:<35} {file:<30} {func.complexity:>4} {func.max_nesting_depth:>4} {func.loc:>5}")

        print("\n")


# ============================================================================
# Main Entry Point
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Analyze Python codebase for complexity and performance metrics",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s src/
  %(prog)s src/ --threshold 10
  %(prog)s src/ --format json --output reports/complexity.json
  %(prog)s src/ --output reports/complexity-audit.md

For design details, see: doc/thoughts/01-ast-performance-analyzer.md
        """
    )

    parser.add_argument(
        'path',
        type=Path,
        help='Root directory to analyze'
    )

    parser.add_argument(
        '-t', '--threshold',
        type=int,
        default=15,
        help='Complexity threshold for hotspot detection (default: 15)'
    )

    parser.add_argument(
        '-f', '--format',
        choices=['markdown', 'json', 'both'],
        default='markdown',
        help='Output format (default: markdown)'
    )

    parser.add_argument(
        '-o', '--output',
        type=Path,
        help='Output file path (default: stdout for markdown, reports/complexity-audit.{md,json})'
    )

    parser.add_argument(
        '--brief',
        action='store_true',
        help='Print brief summary only (no file output)'
    )

    args = parser.parse_args()

    # Validate path
    if not args.path.exists():
        print(f"Error: Path '{args.path}' does not exist", file=sys.stderr)
        sys.exit(1)

    if not args.path.is_dir():
        print(f"Error: Path '{args.path}' is not a directory", file=sys.stderr)
        sys.exit(1)

    # Run analysis
    print(f"Analyzing codebase at: {args.path}")
    print(f"Complexity threshold: {args.threshold}")

    analyzer = CodebaseAnalyzer(args.path, args.threshold)
    metrics = analyzer.analyze()

    # Print console summary
    OutputFormatter.print_summary(metrics)

    if analyzer.errors:
        print(f"\nWarning: {len(analyzer.errors)} file(s) could not be parsed", file=sys.stderr)

    # Generate output files
    if not args.brief:
        # Create reports directory if needed
        reports_dir = Path("reports")
        reports_dir.mkdir(exist_ok=True)

        if args.format in ['markdown', 'both']:
            output_path = args.output or reports_dir / "complexity-audit.md"
            OutputFormatter.to_markdown(metrics, output_path, args.threshold)

        if args.format in ['json', 'both']:
            if args.format == 'both':
                output_path = reports_dir / "complexity-audit.json"
            else:
                output_path = args.output or reports_dir / "complexity-audit.json"
            OutputFormatter.to_json(metrics, output_path)


if __name__ == '__main__':
    main()
