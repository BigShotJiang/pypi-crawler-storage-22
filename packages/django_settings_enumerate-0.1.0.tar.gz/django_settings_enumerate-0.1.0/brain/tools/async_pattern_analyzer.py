#!/usr/bin/env python3
"""
Async Pattern Analyzer

Analyzes async/await code patterns for:
- Blocking I/O calls in async functions
- asyncio.gather() anti-patterns
- Sequential await opportunities
- Missing awaits (limited detection)
- Async function distribution

Usage:
    uv run python brain/tools/async_pattern_analyzer.py src/
    uv run python brain/tools/async_pattern_analyzer.py src/ --output reports/async-patterns-audit.md

See doc/thoughts/02-async-pattern-analyzer.md for design rationale.
"""

import ast
import sys
import json
import argparse
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Optional, Dict, Set
from enum import Enum


# ============================================================================
# Data Models
# ============================================================================

class IssueType(Enum):
    """Types of async pattern issues"""
    BLOCKING_IO = "blocking_io"
    SINGLE_GATHER = "single_gather"
    NESTED_GATHER = "nested_gather"
    SEQUENTIAL_AWAITS = "sequential_awaits"
    MISSING_AWAIT = "missing_await"


class Severity(Enum):
    """Issue severity levels"""
    ERROR = "error"  # Likely runtime error
    WARNING = "warning"  # Performance issue
    INFO = "info"  # Suggestion


@dataclass
class AsyncIssue:
    """A single async pattern issue"""
    issue_type: IssueType
    severity: Severity
    file_path: str
    function_name: str
    lineno: int
    description: str
    suggestion: Optional[str] = None


@dataclass
class AsyncFunctionInfo:
    """Information about an async function"""
    name: str
    file_path: str
    lineno: int
    is_method: bool
    has_gather: bool
    await_count: int
    issues: List[AsyncIssue] = field(default_factory=list)


@dataclass
class AsyncAnalysisReport:
    """Complete async analysis report"""
    total_files_scanned: int = 0
    total_async_functions: int = 0
    total_issues: int = 0
    issues_by_severity: Dict[str, int] = field(default_factory=dict)
    issues_by_type: Dict[str, int] = field(default_factory=dict)
    functions: List[AsyncFunctionInfo] = field(default_factory=list)
    all_issues: List[AsyncIssue] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


# ============================================================================
# Known Blocking Patterns Configuration
# ============================================================================

BLOCKING_PATTERNS = {
    # File I/O (should use aiofiles)
    'open': 'Use aiofiles.open() instead of builtin open()',
    'builtins.open': 'Use aiofiles.open() instead',
    'io.open': 'Use aiofiles.open() instead',

    # Time sleep (should use asyncio.sleep)
    'time.sleep': 'Use asyncio.sleep() instead of time.sleep()',

    # Synchronous HTTP (should use aiohttp)
    'urllib.request.urlopen': 'Use aiohttp.ClientSession instead',
    'urllib.request.urlretrieve': 'Use aiohttp.ClientSession instead',
    'requests.get': 'Use aiohttp.ClientSession.get() instead',
    'requests.post': 'Use aiohttp.ClientSession.post() instead',
    'requests.put': 'Use aiohttp.ClientSession.put() instead',
    'requests.delete': 'Use aiohttp.ClientSession.delete() instead',
    'requests.request': 'Use aiohttp.ClientSession.request() instead',

    # Subprocess (should use asyncio.create_subprocess_*)
    'subprocess.run': 'Use asyncio.create_subprocess_exec() instead',
    'subprocess.call': 'Use asyncio.create_subprocess_exec() instead',
    'subprocess.check_call': 'Use asyncio.create_subprocess_exec() instead',
    'subprocess.check_output': 'Use asyncio.create_subprocess_exec() instead',
    'os.system': 'Use asyncio.create_subprocess_shell() instead',
}


# ============================================================================
# AST Visitors for Pattern Detection
# ============================================================================

class BlockingIODetector(ast.NodeVisitor):
    """Detect blocking I/O calls in async functions"""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.current_async_function = None
        self.issues = []

    def visit_AsyncFunctionDef(self, node):
        """Enter async function context"""
        old_function = self.current_async_function
        self.current_async_function = node.name
        self.generic_visit(node)
        self.current_async_function = old_function

    def visit_Call(self, node):
        """Check if call is potentially blocking"""
        if not self.current_async_function:
            self.generic_visit(node)
            return

        call_name = self._get_call_name(node)
        if call_name in BLOCKING_PATTERNS:
            self.issues.append(AsyncIssue(
                issue_type=IssueType.BLOCKING_IO,
                severity=Severity.WARNING,
                file_path=self.file_path,
                function_name=self.current_async_function,
                lineno=node.lineno,
                description=f"Potentially blocking call: {call_name}()",
                suggestion=BLOCKING_PATTERNS[call_name]
            ))

        self.generic_visit(node)

    def _get_call_name(self, node: ast.Call) -> str:
        """Extract qualified name from Call node"""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            # Handle module.function or obj.method
            parts = []
            current = node.func
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, ast.Name):
                parts.append(current.id)
            return '.'.join(reversed(parts))
        return ''


class GatherAnalyzer(ast.NodeVisitor):
    """Analyze asyncio.gather() usage patterns"""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.current_async_function = None
        self.issues = []

    def visit_AsyncFunctionDef(self, node):
        old_function = self.current_async_function
        self.current_async_function = node.name
        self.generic_visit(node)
        self.current_async_function = old_function

    def visit_Call(self, node):
        if not self.current_async_function:
            self.generic_visit(node)
            return

        # Detect asyncio.gather() calls
        if self._is_gather_call(node):
            self._analyze_gather(node)

        self.generic_visit(node)

    def _is_gather_call(self, node: ast.Call) -> bool:
        """Check if this is asyncio.gather() call"""
        if isinstance(node.func, ast.Attribute):
            if (isinstance(node.func.value, ast.Name) and
                node.func.value.id == 'asyncio' and
                node.func.attr == 'gather'):
                return True
        elif isinstance(node.func, ast.Name):
            # Direct import: from asyncio import gather
            if node.func.id == 'gather':
                return True
        return False

    def _analyze_gather(self, node: ast.Call):
        """Analyze a gather() call for anti-patterns"""
        num_args = len(node.args)

        # Pattern 1: Single-item gather
        # Only flag if we have exactly 1 arg AND it's not a starred expression
        # gather(*tasks) has 1 arg (Starred node) but unpacks to multiple at runtime
        if num_args == 1 and not isinstance(node.args[0], ast.Starred):
            self.issues.append(AsyncIssue(
                issue_type=IssueType.SINGLE_GATHER,
                severity=Severity.INFO,
                file_path=self.file_path,
                function_name=self.current_async_function,
                lineno=node.lineno,
                description="asyncio.gather() called with single item",
                suggestion="Consider direct await instead of gather for single item"
            ))

        # Pattern 2: Nested gather
        for arg in node.args:
            if isinstance(arg, ast.Call) and self._is_gather_call(arg):
                self.issues.append(AsyncIssue(
                    issue_type=IssueType.NESTED_GATHER,
                    severity=Severity.WARNING,
                    file_path=self.file_path,
                    function_name=self.current_async_function,
                    lineno=node.lineno,
                    description="Nested asyncio.gather() detected",
                    suggestion="Consider flattening gather calls for better performance"
                ))


class SequentialAwaitDetector(ast.NodeVisitor):
    """Detect sequential awaits that could be parallelized"""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.current_async_function = None
        self.issues = []

    def visit_AsyncFunctionDef(self, node):
        old_function = self.current_async_function
        self.current_async_function = node.name

        # Analyze awaits in function body
        awaits = self._find_sequential_awaits(node.body)
        if len(awaits) >= 3:  # Only report if 3+ sequential awaits
            self.issues.append(AsyncIssue(
                issue_type=IssueType.SEQUENTIAL_AWAITS,
                severity=Severity.INFO,
                file_path=self.file_path,
                function_name=node.name,
                lineno=awaits[0]['lineno'],
                description=(
                    f"Found {len(awaits)} sequential awaits "
                    f"(lines {awaits[0]['lineno']}-{awaits[-1]['lineno']})"
                ),
                suggestion="Consider using asyncio.gather() if operations are independent"
            ))

        self.generic_visit(node)
        self.current_async_function = old_function

    def _find_sequential_awaits(self, body: List[ast.stmt]) -> List[Dict]:
        """Find consecutive await expressions in function body"""
        awaits = []

        for stmt in body:
            # Look for await in assignments: x = await foo()
            if isinstance(stmt, ast.Assign):
                if isinstance(stmt.value, ast.Await):
                    awaits.append({
                        'lineno': stmt.lineno,
                        'type': 'assign'
                    })
                else:
                    # Non-await statement breaks the sequence
                    if len(awaits) >= 3:
                        break
                    awaits = []

            # Look for standalone await: await foo()
            elif isinstance(stmt, ast.Expr):
                if isinstance(stmt.value, ast.Await):
                    awaits.append({
                        'lineno': stmt.lineno,
                        'type': 'expr'
                    })
                else:
                    # Non-await statement breaks the sequence
                    if len(awaits) >= 3:
                        break
                    awaits = []

            # Any other statement type breaks the sequence
            else:
                if len(awaits) >= 3:
                    break
                awaits = []

        return awaits


class AsyncFunctionScanner(ast.NodeVisitor):
    """Scan for async functions and collect basic info"""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.functions = []

    def visit_AsyncFunctionDef(self, node):
        """Record async function"""
        # Count awaits in function
        await_count = sum(1 for _ in ast.walk(node) if isinstance(_, ast.Await))

        # Check for gather usage
        has_gather = any(
            isinstance(n, ast.Call) and self._is_gather(n)
            for n in ast.walk(node)
        )

        func_info = AsyncFunctionInfo(
            name=node.name,
            file_path=self.file_path,
            lineno=node.lineno,
            is_method=False,  # TODO: detect if inside class
            has_gather=has_gather,
            await_count=await_count
        )

        self.functions.append(func_info)
        self.generic_visit(node)

    def _is_gather(self, node: ast.Call) -> bool:
        """Check if call is asyncio.gather()"""
        if isinstance(node.func, ast.Attribute):
            if (isinstance(node.func.value, ast.Name) and
                node.func.value.id == 'asyncio' and
                node.func.attr == 'gather'):
                return True
        elif isinstance(node.func, ast.Name):
            if node.func.id == 'gather':
                return True
        return False


# ============================================================================
# Main Analyzer
# ============================================================================

class AsyncPatternAnalyzer:
    """Main async pattern analysis coordinator"""

    EXCLUDE_PATTERNS = {
        '__pycache__', '.venv', 'venv', '.tox', '.pytest_cache',
        'build', 'dist', '.eggs', '*.egg-info', 'node_modules'
    }

    def __init__(self, root_path: Path):
        self.root_path = root_path
        self.report = AsyncAnalysisReport()

    def analyze(self) -> AsyncAnalysisReport:
        """Analyze all Python files for async patterns"""
        python_files = self._find_python_files()

        for file_path in python_files:
            self._analyze_file(file_path)

        self._calculate_summary()
        return self.report

    def _find_python_files(self) -> List[Path]:
        """Find all Python files"""
        python_files = []

        for py_file in self.root_path.rglob("**/*.py"):
            if any(pattern in str(py_file) for pattern in self.EXCLUDE_PATTERNS):
                continue
            python_files.append(py_file)

        return sorted(python_files)

    def _analyze_file(self, file_path: Path):
        """Analyze single file"""
        try:
            source = file_path.read_text(encoding='utf-8')
            tree = ast.parse(source, filename=str(file_path))
        except (SyntaxError, UnicodeDecodeError) as e:
            error_msg = f"Could not parse {file_path}: {e}"
            self.report.errors.append(error_msg)
            print(f"Warning: {error_msg}", file=sys.stderr)
            return

        rel_path = str(file_path.relative_to(self.root_path))

        # Scan for async functions first
        function_scanner = AsyncFunctionScanner(rel_path)
        function_scanner.visit(tree)
        self.report.functions.extend(function_scanner.functions)

        # Run all detectors
        blocking_detector = BlockingIODetector(rel_path)
        blocking_detector.visit(tree)

        gather_analyzer = GatherAnalyzer(rel_path)
        gather_analyzer.visit(tree)

        sequential_detector = SequentialAwaitDetector(rel_path)
        sequential_detector.visit(tree)

        # Collect all issues
        all_file_issues = (
            blocking_detector.issues +
            gather_analyzer.issues +
            sequential_detector.issues
        )

        # Associate issues with functions
        for issue in all_file_issues:
            for func in function_scanner.functions:
                if func.name == issue.function_name:
                    func.issues.append(issue)
                    break

        self.report.all_issues.extend(all_file_issues)

    def _calculate_summary(self):
        """Calculate summary statistics"""
        self.report.total_async_functions = len(self.report.functions)
        self.report.total_issues = len(self.report.all_issues)

        # Count by severity
        for severity in Severity:
            count = sum(1 for issue in self.report.all_issues if issue.severity == severity)
            self.report.issues_by_severity[severity.value] = count

        # Count by type
        for issue_type in IssueType:
            count = sum(1 for issue in self.report.all_issues if issue.issue_type == issue_type)
            self.report.issues_by_type[issue_type.value] = count


# ============================================================================
# Output Formatters
# ============================================================================

class OutputFormatter:
    """Format analysis results"""

    @staticmethod
    def to_json(report: AsyncAnalysisReport, output_file: Path):
        """Export to JSON"""
        # Convert enums to strings for JSON serialization
        data = asdict(report)

        # Fix enum serialization
        for issue in data.get('all_issues', []):
            if isinstance(issue.get('issue_type'), IssueType):
                issue['issue_type'] = issue['issue_type'].value
            if isinstance(issue.get('severity'), Severity):
                issue['severity'] = issue['severity'].value

        for func in data.get('functions', []):
            for issue in func.get('issues', []):
                if isinstance(issue.get('issue_type'), IssueType):
                    issue['issue_type'] = issue['issue_type'].value
                if isinstance(issue.get('severity'), Severity):
                    issue['severity'] = issue['severity'].value

        with output_file.open('w') as f:
            json.dump(data, f, indent=2)
        print(f"JSON output written to: {output_file}")

    @staticmethod
    def to_markdown(report: AsyncAnalysisReport, output_file: Path):
        """Export to Markdown"""
        with output_file.open('w') as f:
            f.write("# Async Pattern Analysis Report\n\n")
            f.write("*Generated by Async Pattern Analyzer*\n\n")

            # Summary
            f.write("## Summary\n\n")
            f.write(f"- **Total Async Functions:** {report.total_async_functions}\n")
            f.write(f"- **Total Issues Found:** {report.total_issues}\n")
            f.write(f"- **Errors:** {report.issues_by_severity.get('error', 0)}\n")
            f.write(f"- **Warnings:** {report.issues_by_severity.get('warning', 0)}\n")
            f.write(f"- **Info:** {report.issues_by_severity.get('info', 0)}\n\n")

            # Issues by type
            f.write("## Issues by Type\n\n")
            for issue_type, count in sorted(report.issues_by_type.items()):
                if count > 0:
                    f.write(f"- **{issue_type.replace('_', ' ').title()}:** {count}\n")
            f.write("\n")

            # Critical issues (errors)
            errors = [i for i in report.all_issues if i.severity == Severity.ERROR]
            if errors:
                f.write("## Critical Issues (Errors)\n\n")
                for issue in errors:
                    f.write(f"### {issue.file_path}:{issue.lineno} - {issue.function_name}()\n\n")
                    f.write(f"**Issue:** {issue.description}\n\n")
                    if issue.suggestion:
                        f.write(f"**Suggestion:** {issue.suggestion}\n\n")
            else:
                f.write("## Critical Issues (Errors)\n\n")
                f.write("No critical issues found. ✅\n\n")

            # Warnings
            warnings = [i for i in report.all_issues if i.severity == Severity.WARNING]
            if warnings:
                f.write("## Warnings\n\n")

                # Group by type
                blocking_io = [w for w in warnings if w.issue_type == IssueType.BLOCKING_IO]
                if blocking_io:
                    f.write("### Blocking I/O in Async Functions\n\n")
                    f.write("| File | Function | Line | Issue | Suggestion |\n")
                    f.write("|------|----------|------|-------|------------|\n")
                    for issue in sorted(blocking_io, key=lambda x: (x.file_path, x.lineno)):
                        f.write(f"| {issue.file_path} | {issue.function_name} | "
                               f"{issue.lineno} | {issue.description} | {issue.suggestion} |\n")
                    f.write("\n")

                nested_gather = [w for w in warnings if w.issue_type == IssueType.NESTED_GATHER]
                if nested_gather:
                    f.write("### Nested asyncio.gather()\n\n")
                    f.write("| File | Function | Line | Suggestion |\n")
                    f.write("|------|----------|------|------------|\n")
                    for issue in sorted(nested_gather, key=lambda x: (x.file_path, x.lineno)):
                        f.write(f"| {issue.file_path} | {issue.function_name} | "
                               f"{issue.lineno} | {issue.suggestion} |\n")
                    f.write("\n")

            # Optimization opportunities (info)
            infos = [i for i in report.all_issues if i.severity == Severity.INFO]
            if infos:
                f.write("## Optimization Opportunities (Info)\n\n")

                # Sequential awaits
                sequential = [i for i in infos if i.issue_type == IssueType.SEQUENTIAL_AWAITS]
                if sequential:
                    f.write("### Sequential Await Opportunities\n\n")
                    f.write("*These functions have multiple sequential awaits that might benefit from parallelization*\n\n")
                    f.write("| File | Function | Lines | Count | Suggestion |\n")
                    f.write("|------|----------|-------|-------|------------|\n")
                    for issue in sorted(sequential, key=lambda x: (x.file_path, x.lineno)):
                        # Extract count from description
                        import re
                        match = re.search(r'Found (\d+) sequential', issue.description)
                        count = match.group(1) if match else "?"
                        f.write(f"| {issue.file_path} | {issue.function_name} | {issue.lineno}+ | "
                               f"{count} | {issue.suggestion} |\n")
                    f.write("\n")

                # Single-item gather
                single_gather = [i for i in infos if i.issue_type == IssueType.SINGLE_GATHER]
                if single_gather:
                    f.write("### Single-Item gather() Calls\n\n")
                    f.write("| File | Function | Line |\n")
                    f.write("|------|----------|------|\n")
                    for issue in sorted(single_gather, key=lambda x: (x.file_path, x.lineno)):
                        f.write(f"| {issue.file_path} | {issue.function_name} | {issue.lineno} |\n")
                    f.write("\n")

            # Async function inventory
            f.write("## Async Function Inventory\n\n")
            f.write(f"Total async functions: {report.total_async_functions}\n\n")

            # Functions using gather
            gather_users = [f for f in report.functions if f.has_gather]
            if gather_users:
                f.write(f"### Functions Using asyncio.gather() ({len(gather_users)})\n\n")
                f.write("| File | Function | Line | Awaits | Issues |\n")
                f.write("|------|----------|------|--------|--------|\n")
                for func in sorted(gather_users, key=lambda x: (x.file_path, x.lineno)):
                    f.write(f"| {func.file_path} | {func.name} | {func.lineno} | "
                           f"{func.await_count} | {len(func.issues)} |\n")
                f.write("\n")

        print(f"Markdown output written to: {output_file}")

    @staticmethod
    def print_summary(report: AsyncAnalysisReport):
        """Print summary to console"""
        print("\n" + "=" * 80)
        print("ASYNC PATTERN ANALYSIS SUMMARY")
        print("=" * 80)
        print(f"\nTotal Async Functions: {report.total_async_functions}")
        print(f"Total Issues: {report.total_issues}")
        print(f"  Errors: {report.issues_by_severity.get('error', 0)}")
        print(f"  Warnings: {report.issues_by_severity.get('warning', 0)}")
        print(f"  Info: {report.issues_by_severity.get('info', 0)}")

        print("\nIssues by Type:")
        for issue_type, count in sorted(report.issues_by_type.items()):
            if count > 0:
                print(f"  {issue_type.replace('_', ' ').title()}: {count}")

        if report.errors:
            print(f"\nWarning: {len(report.errors)} file(s) could not be parsed")

        print()


# ============================================================================
# Main Entry Point
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Analyze async/await patterns in Python codebase",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s src/
  %(prog)s src/ --format json --output reports/async-patterns.json
  %(prog)s src/ --output reports/async-patterns-audit.md

For design details, see: doc/thoughts/02-async-pattern-analyzer.md
        """
    )

    parser.add_argument(
        'path',
        type=Path,
        help='Root directory to analyze'
    )

    parser.add_argument(
        '-f', '--format',
        choices=['markdown', 'json', 'both'],
        default='markdown',
        help='Output format (default: markdown)'
    )

    parser.add_argument(
        '-o', '--output',
        type=Path,
        help='Output file path (default: reports/async-patterns-audit.{md,json})'
    )

    parser.add_argument(
        '--brief',
        action='store_true',
        help='Print brief summary only (no file output)'
    )

    args = parser.parse_args()

    # Validate path
    if not args.path.exists():
        print(f"Error: Path '{args.path}' does not exist", file=sys.stderr)
        sys.exit(1)

    if not args.path.is_dir():
        print(f"Error: Path '{args.path}' is not a directory", file=sys.stderr)
        sys.exit(1)

    # Run analysis
    print(f"Analyzing async patterns at: {args.path}")

    analyzer = AsyncPatternAnalyzer(args.path)
    report = analyzer.analyze()

    # Print console summary
    OutputFormatter.print_summary(report)

    # Generate output files
    if not args.brief:
        # Create reports directory if needed
        reports_dir = Path("reports")
        reports_dir.mkdir(exist_ok=True)

        if args.format in ['markdown', 'both']:
            output_path = args.output or reports_dir / "async-patterns-audit.md"
            OutputFormatter.to_markdown(report, output_path)

        if args.format in ['json', 'both']:
            if args.format == 'both':
                output_path = reports_dir / "async-patterns-audit.json"
            else:
                output_path = args.output or reports_dir / "async-patterns-audit.json"
            OutputFormatter.to_json(report, output_path)


if __name__ == '__main__':
    main()
