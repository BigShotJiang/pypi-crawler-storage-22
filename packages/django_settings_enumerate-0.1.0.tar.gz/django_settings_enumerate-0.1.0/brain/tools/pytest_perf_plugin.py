"""
Pytest Performance Plugin

Auto-instrument pytest test runs to track execution time without modifying tests.

Features:
- Automatic timing of all tests
- Identify slow tests (>1s by default, configurable)
- Summary report after test run
- Minimal overhead (<1%)

Usage:
    # In conftest.py or pytest.ini:
    pytest_plugins = ["brain.tools.pytest_perf_plugin"]

    # Or via command line:
    pytest -p brain.tools.pytest_perf_plugin

    # Configure threshold:
    pytest --perf-threshold 0.5

See doc/thoughts/04-pytest-plugin.md for design rationale.
"""

import pytest
import time
from typing import Dict
from pathlib import Path


# ============================================================================
# Plugin State
# ============================================================================

class PerformancePlugin:
    """Pytest plugin for test performance tracking"""

    def __init__(self, slow_threshold: float = 1.0):
        self.test_timings: Dict[str, float] = {}
        self.slow_threshold = slow_threshold

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_call(self, item):
        """Hook to time each test execution"""
        start = time.perf_counter()
        outcome = yield  # Run the test
        elapsed = time.perf_counter() - start

        self.test_timings[item.nodeid] = elapsed

        # Flag slow tests in real-time
        if elapsed > self.slow_threshold:
            print(f"\n⚠️  SLOW TEST ({elapsed:.2f}s): {item.nodeid}")

    @pytest.hookimpl(tryfirst=True)
    def pytest_terminal_summary(self, terminalreporter):
        """Print performance summary after all tests"""
        if not self.test_timings:
            return

        print("\n" + "=" * 80)
        print("TEST PERFORMANCE SUMMARY")
        print("=" * 80)

        total_time = sum(self.test_timings.values())
        avg_time = total_time / len(self.test_timings)
        slow_tests = {k: v for k, v in self.test_timings.items() if v > self.slow_threshold}

        print(f"\nTotal Tests: {len(self.test_timings)}")
        print(f"Total Time: {total_time:.2f}s")
        print(f"Average Time: {avg_time:.3f}s")
        print(f"Slow Tests (>{self.slow_threshold}s): {len(slow_tests)}")

        if slow_tests:
            print("\n" + "=" * 80)
            print(f"SLOW TESTS (>{self.slow_threshold}s)")
            print("=" * 80)
            for test, timing in sorted(slow_tests.items(), key=lambda x: x[1], reverse=True):
                print(f"❌ {timing:6.2f}s - {test}")

        print("\n" + "=" * 80)
        print("SLOWEST 20 TESTS")
        print("=" * 80)
        sorted_tests = sorted(self.test_timings.items(), key=lambda x: x[1], reverse=True)
        for test, timing in sorted_tests[:20]:
            if timing > self.slow_threshold:
                marker = "❌"
            elif timing > self.slow_threshold / 2:
                marker = "⚠️ "
            else:
                marker = "  "
            print(f"{marker} {timing:6.2f}s - {test}")

        # Print fastest tests too (for reference)
        print("\n" + "=" * 80)
        print("FASTEST 10 TESTS")
        print("=" * 80)
        for test, timing in sorted_tests[-10:]:
            print(f"✓  {timing:6.3f}s - {test}")

        print()


# ============================================================================
# Plugin Registration
# ============================================================================

_plugin_instance = None


def pytest_addoption(parser):
    """Add command-line options for the plugin"""
    group = parser.getgroup('performance', 'Performance tracking options')
    group.addoption(
        '--perf-threshold',
        action='store',
        type=float,
        default=1.0,
        help='Threshold in seconds for slow test detection (default: 1.0)'
    )
    group.addoption(
        '--perf-output',
        action='store',
        type=str,
        default=None,
        help='Output file for performance data (JSON format)'
    )


def pytest_configure(config):
    """Register the plugin instance"""
    global _plugin_instance

    threshold = config.getoption('--perf-threshold')
    _plugin_instance = PerformancePlugin(slow_threshold=threshold)
    config.pluginmanager.register(_plugin_instance, 'performance_plugin')


def pytest_unconfigure(config):
    """Cleanup and export data if requested"""
    global _plugin_instance

    if _plugin_instance is None:
        return

    output_file = config.getoption('--perf-output')
    if output_file and _plugin_instance.test_timings:
        import json
        from pathlib import Path

        data = {
            'summary': {
                'total_tests': len(_plugin_instance.test_timings),
                'total_time': sum(_plugin_instance.test_timings.values()),
                'avg_time': sum(_plugin_instance.test_timings.values()) / len(_plugin_instance.test_timings),
                'slow_threshold': _plugin_instance.slow_threshold,
                'slow_count': sum(1 for t in _plugin_instance.test_timings.values() if t > _plugin_instance.slow_threshold),
            },
            'timings': _plugin_instance.test_timings
        }

        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open('w') as f:
            json.dump(data, f, indent=2)

        print(f"\nPerformance data exported to: {output_path}")

    config.pluginmanager.unregister(_plugin_instance)
    _plugin_instance = None
