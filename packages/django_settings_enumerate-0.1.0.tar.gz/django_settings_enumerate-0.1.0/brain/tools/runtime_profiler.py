#!/usr/bin/env python3
"""
Runtime Profiler

Decorator-based profiling for Python functions:
- Function execution timing (sync and async)
- Memory usage tracking (optional)
- Call frequency tracking
- Statistical aggregation (min, max, avg, p95, p99)
- Report generation

Usage:
    # In code:
    from brain.tools.runtime_profiler import profile, ProfileReporter, get_registry

    @profile()
    def my_function():
        ...

    @profile(memory=True)
    async def memory_intensive():
        ...

    # Generate report:
    reporter = ProfileReporter(get_registry())
    reporter.print_summary()
    reporter.to_markdown(Path("reports/performance-audit.md"))

See doc/thoughts/03-runtime-profiler.md for design rationale.
"""

import time
import functools
import asyncio
import threading
import tracemalloc
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Callable
import json


# ============================================================================
# Data Models
# ============================================================================

@dataclass
class FunctionProfile:
    """Profile data for a single function"""
    name: str
    module: str
    call_count: int = 0
    total_time: float = 0.0
    min_time: float = float('inf')
    max_time: float = 0.0
    timings: List[float] = field(default_factory=list)
    total_memory: int = 0  # Bytes
    is_async: bool = False

    @property
    def avg_time(self) -> float:
        """Average execution time"""
        return self.total_time / self.call_count if self.call_count > 0 else 0.0

    @property
    def p95_time(self) -> float:
        """95th percentile execution time"""
        if not self.timings:
            return 0.0
        sorted_timings = sorted(self.timings)
        idx = int(len(sorted_timings) * 0.95)
        return sorted_timings[idx] if idx < len(sorted_timings) else sorted_timings[-1]

    @property
    def p99_time(self) -> float:
        """99th percentile execution time"""
        if not self.timings:
            return 0.0
        sorted_timings = sorted(self.timings)
        idx = int(len(sorted_timings) * 0.99)
        return sorted_timings[idx] if idx < len(sorted_timings) else sorted_timings[-1]


# ============================================================================
# Thread-Safe Profile Registry
# ============================================================================

class ProfileRegistry:
    """Thread-safe registry for profile data"""

    def __init__(self):
        self._profiles: Dict[str, FunctionProfile] = {}
        self._lock = threading.Lock()

    def record(self, func_name: str, module: str, elapsed: float,
               memory_delta: int = 0, is_async: bool = False):
        """Record a function execution"""
        with self._lock:
            key = f"{module}.{func_name}"
            if key not in self._profiles:
                self._profiles[key] = FunctionProfile(
                    name=func_name,
                    module=module,
                    is_async=is_async
                )

            profile = self._profiles[key]
            profile.call_count += 1
            profile.total_time += elapsed
            profile.min_time = min(profile.min_time, elapsed)
            profile.max_time = max(profile.max_time, elapsed)
            profile.timings.append(elapsed)
            profile.total_memory += memory_delta

    def get_profiles(self) -> List[FunctionProfile]:
        """Get all profiles (thread-safe copy)"""
        with self._lock:
            return list(self._profiles.values())

    def get_hotspots(self, min_time: float = 0.1) -> List[FunctionProfile]:
        """Get functions with total time > threshold"""
        profiles = self.get_profiles()
        return sorted(
            [p for p in profiles if p.total_time >= min_time],
            key=lambda p: p.total_time,
            reverse=True
        )

    def get_slow_functions(self, threshold: float = 1.0) -> List[FunctionProfile]:
        """Get functions where max_time > threshold"""
        profiles = self.get_profiles()
        return sorted(
            [p for p in profiles if p.max_time >= threshold],
            key=lambda p: p.max_time,
            reverse=True
        )

    def clear(self):
        """Clear all profile data"""
        with self._lock:
            self._profiles.clear()


# Global registry instance
_registry = ProfileRegistry()


def get_registry() -> ProfileRegistry:
    """Get the global profile registry"""
    return _registry


# ============================================================================
# Profiling Decorator
# ============================================================================

def profile(memory: bool = False):
    """
    Profiling decorator for functions.

    Works with both sync and async functions automatically.

    Args:
        memory: If True, track memory usage (adds ~10-20% overhead)

    Usage:
        @profile()
        def my_function():
            ...

        @profile(memory=True)
        async def memory_intensive():
            ...
    """
    def decorator(func: Callable):
        func_name = func.__name__
        module_name = func.__module__
        is_async = asyncio.iscoroutinefunction(func)

        if is_async:
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                start_time = time.perf_counter()
                memory_delta = 0

                if memory:
                    tracemalloc.start()
                    snapshot_before = tracemalloc.take_snapshot()

                try:
                    result = await func(*args, **kwargs)
                    return result
                finally:
                    elapsed = time.perf_counter() - start_time

                    if memory:
                        snapshot_after = tracemalloc.take_snapshot()
                        top_stats = snapshot_after.compare_to(snapshot_before, 'lineno')
                        memory_delta = sum(stat.size_diff for stat in top_stats)
                        tracemalloc.stop()

                    _registry.record(func_name, module_name, elapsed, memory_delta, is_async=True)

            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                start_time = time.perf_counter()
                memory_delta = 0

                if memory:
                    tracemalloc.start()
                    snapshot_before = tracemalloc.take_snapshot()

                try:
                    result = func(*args, **kwargs)
                    return result
                finally:
                    elapsed = time.perf_counter() - start_time

                    if memory:
                        snapshot_after = tracemalloc.take_snapshot()
                        top_stats = snapshot_after.compare_to(snapshot_before, 'lineno')
                        memory_delta = sum(stat.size_diff for stat in top_stats)
                        tracemalloc.stop()

                    _registry.record(func_name, module_name, elapsed, memory_delta, is_async=False)

            return sync_wrapper

    return decorator


# ============================================================================
# Report Generation
# ============================================================================

class ProfileReporter:
    """Generate profile reports in various formats"""

    def __init__(self, registry: ProfileRegistry):
        self.registry = registry

    def print_summary(self):
        """Print summary to console"""
        profiles = self.registry.get_profiles()
        if not profiles:
            print("No profile data collected")
            return

        print("\n" + "=" * 80)
        print("RUNTIME PROFILING SUMMARY")
        print("=" * 80)

        total_time = sum(p.total_time for p in profiles)
        total_calls = sum(p.call_count for p in profiles)

        print(f"\nTotal Functions Profiled: {len(profiles)}")
        print(f"Total Calls: {total_calls:,}")
        print(f"Total Time: {total_time:.2f}s")

        print("\n" + "-" * 80)
        print("TOP 20 FUNCTIONS BY TOTAL TIME")
        print("-" * 80)
        print(f"{'Function':<40} {'Calls':>8} {'Total':>10} {'Avg':>10} {'Max':>10}")
        print("-" * 80)

        hotspots = self.registry.get_hotspots()
        for profile in hotspots[:20]:
            async_marker = "(async) " if profile.is_async else ""
            name = f"{async_marker}{profile.name}"[:39]
            print(f"{name:<40} {profile.call_count:>8,} "
                  f"{profile.total_time:>9.3f}s {profile.avg_time:>9.3f}s "
                  f"{profile.max_time:>9.3f}s")

        # Show slow functions (>1s)
        slow = self.registry.get_slow_functions(threshold=1.0)
        if slow:
            print("\n" + "-" * 80)
            print("SLOW FUNCTIONS (max execution time > 1s)")
            print("-" * 80)
            print(f"{'Function':<40} {'Max Time':>10} {'Calls':>8}")
            print("-" * 80)
            for profile in slow[:10]:
                async_marker = "(async) " if profile.is_async else ""
                name = f"{async_marker}{profile.name}"[:39]
                print(f"{name:<40} {profile.max_time:>9.3f}s {profile.call_count:>8,}")

        print()

    def to_json(self, output_path: Path):
        """Export to JSON for machine consumption"""
        profiles = self.registry.get_profiles()
        data = {
            'summary': {
                'total_functions': len(profiles),
                'total_calls': sum(p.call_count for p in profiles),
                'total_time': sum(p.total_time for p in profiles),
            },
            'profiles': [
                {
                    'name': p.name,
                    'module': p.module,
                    'call_count': p.call_count,
                    'total_time': p.total_time,
                    'avg_time': p.avg_time,
                    'min_time': p.min_time,
                    'max_time': p.max_time,
                    'p95_time': p.p95_time,
                    'p99_time': p.p99_time,
                    'is_async': p.is_async,
                    'total_memory': p.total_memory,
                }
                for p in profiles
            ]
        }

        with output_path.open('w') as f:
            json.dump(data, f, indent=2)
        print(f"JSON output written to: {output_path}")

    def to_markdown(self, output_path: Path):
        """Export to Markdown for human consumption"""
        with output_path.open('w') as f:
            f.write("# Runtime Profiling Report\n\n")
            f.write("*Generated by Runtime Profiler*\n\n")

            profiles = self.registry.get_profiles()
            total_time = sum(p.total_time for p in profiles)
            total_calls = sum(p.call_count for p in profiles)

            # Summary
            f.write("## Summary\n\n")
            f.write(f"- **Total Functions Profiled:** {len(profiles)}\n")
            f.write(f"- **Total Calls:** {total_calls:,}\n")
            f.write(f"- **Total Time:** {total_time:.2f}s\n")
            f.write(f"- **Average Time per Function:** {total_time / len(profiles):.3f}s\n\n")

            # Hotspots by total time
            f.write("## Top Functions by Total Time\n\n")
            f.write("*Functions consuming the most cumulative runtime*\n\n")
            f.write("| Function | Module | Calls | Total | Avg | Max | P95 | P99 |\n")
            f.write("|----------|--------|-------|-------|-----|-----|-----|-----|\n")

            hotspots = self.registry.get_hotspots()
            for p in hotspots[:20]:
                async_marker = " (async)" if p.is_async else ""
                f.write(f"| {p.name}{async_marker} | {p.module} | {p.call_count:,} | "
                       f"{p.total_time:.3f}s | {p.avg_time:.3f}s | {p.max_time:.3f}s | "
                       f"{p.p95_time:.3f}s | {p.p99_time:.3f}s |\n")
            f.write("\n")

            # Slow functions
            slow = self.registry.get_slow_functions(threshold=1.0)
            if slow:
                f.write("## Slow Functions (max > 1s)\n\n")
                f.write("*Functions with at least one execution taking >1 second*\n\n")
                f.write("| Function | Module | Max Time | Avg Time | Call Count |\n")
                f.write("|----------|--------|----------|----------|------------|\n")
                for p in slow:
                    async_marker = " (async)" if p.is_async else ""
                    f.write(f"| {p.name}{async_marker} | {p.module} | "
                           f"{p.max_time:.3f}s | {p.avg_time:.3f}s | {p.call_count:,} |\n")
                f.write("\n")

            # Memory usage (if tracked)
            memory_profiles = [p for p in profiles if p.total_memory > 0]
            if memory_profiles:
                f.write("## Memory Usage\n\n")
                f.write("*Functions tracked with memory profiling enabled*\n\n")
                f.write("| Function | Module | Total Memory | Avg per Call | Calls |\n")
                f.write("|----------|--------|--------------|--------------|-------|\n")

                sorted_memory = sorted(memory_profiles, key=lambda p: p.total_memory, reverse=True)
                for p in sorted_memory[:20]:
                    async_marker = " (async)" if p.is_async else ""
                    avg_memory = p.total_memory / p.call_count if p.call_count > 0 else 0
                    f.write(f"| {p.name}{async_marker} | {p.module} | "
                           f"{self._format_bytes(p.total_memory)} | "
                           f"{self._format_bytes(avg_memory)} | {p.call_count:,} |\n")
                f.write("\n")

            # Frequently called functions
            frequent = sorted(profiles, key=lambda p: p.call_count, reverse=True)[:20]
            if frequent:
                f.write("## Most Frequently Called Functions\n\n")
                f.write("| Function | Module | Calls | Avg Time | Total Time |\n")
                f.write("|----------|--------|-------|----------|------------|\n")
                for p in frequent:
                    async_marker = " (async)" if p.is_async else ""
                    f.write(f"| {p.name}{async_marker} | {p.module} | {p.call_count:,} | "
                           f"{p.avg_time:.3f}s | {p.total_time:.3f}s |\n")
                f.write("\n")

        print(f"Markdown output written to: {output_path}")

    @staticmethod
    def _format_bytes(bytes_value: float) -> str:
        """Format bytes in human-readable format"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if abs(bytes_value) < 1024.0:
                return f"{bytes_value:.1f}{unit}"
            bytes_value /= 1024.0
        return f"{bytes_value:.1f}TB"


# ============================================================================
# Main Entry Point (for standalone testing)
# ============================================================================

def main():
    """Example usage and testing"""
    import argparse

    parser = argparse.ArgumentParser(
        description="Runtime Profiler - Decorator-based function profiling",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
This module is primarily used as a library via decorators:

    from brain.tools.runtime_profiler import profile

    @profile()
    def my_function():
        ...

For design details, see: doc/thoughts/03-runtime-profiler.md
        """
    )

    parser.add_argument(
        '--show',
        action='store_true',
        help='Show current profiling data'
    )

    parser.add_argument(
        '--clear',
        action='store_true',
        help='Clear profiling data'
    )

    parser.add_argument(
        '-o', '--output',
        type=Path,
        help='Output file path (markdown or json based on extension)'
    )

    args = parser.parse_args()

    reporter = ProfileReporter(_registry)

    if args.clear:
        _registry.clear()
        print("Profile data cleared")
        return

    if args.show:
        reporter.print_summary()

    if args.output:
        if args.output.suffix == '.json':
            reporter.to_json(args.output)
        elif args.output.suffix == '.md':
            reporter.to_markdown(args.output)
        else:
            print(f"Error: Unknown output format '{args.output.suffix}'. Use .json or .md")


if __name__ == '__main__':
    main()
