# Brain v2: MCP Architecture Planning

## Core Insight: Cognitive Recognition, Not Keyword Matching

**Date:** 2025-10-14

### The Question

How do I (Claude) automatically reach for brain/ the same way I automatically reach for Grep, Read, or Glob?

The answer is NOT keyword triggers. It's **situational recognition** - recognizing I'm in a cognitive state where a tool applies.

### The Recognition Mechanism

When I'm analyzing a problem, I'm simultaneously:
1. Understanding the problem space
2. Scanning available tools for "this tool is for situations like this"
3. Matching my current cognitive state to tool purposes

**Example:**
- State: "I need to find files matching a pattern"
- Recognition: Glob tool description says "Fast file pattern matching"
- Action: Use Glob

### What Makes Me Choose a Tool?

**It's NOT:**
- Explicit keyword matching ("if user says 'test' then use brain")
- Hardcoded decision trees
- Pattern matching on input text

**It IS:**
- **Tool purpose descriptions** (in MCP tool definitions)
- **Instruction prioritization** (CLAUDE.xml saying "prefer X over Y")
- **Cognitive state matching** (recognizing "I'm in planning mode" → "I should check learned patterns")

### Current Tool Recognition Example

From my instructions:
```xml
<tool name="Grep">
  <description>
    - A powerful search tool
    - Use this tool when you need to find content in files
    - Supports regex, glob filtering, context flags
  </description>
</tool>
```

When I'm in the cognitive state of "I need to find where X is defined," I recognize:
- This matches Grep's purpose
- Grep is the appropriate tool
- I reach for Grep automatically

### Applying This to brain/

For brain/ to work the same way, I need:

1. **MCP Tools with Clear Purpose Descriptions**
```xml
<tool name="mcp__brain__query">
  <description>
    - Query Claude's knowledge base of learned Python patterns
    - Use this tool when you're about to implement/debug tests, async code, mocking, fixtures, caching, or refactoring
    - Use this BEFORE reading files or implementing solutions
    - Returns proven patterns, anti-patterns, and critical rules from experience
  </description>
</tool>
```

2. **CLAUDE.xml Instructions That Prime Recognition**
```xml
<critical-startup>
  <rule priority="ABSOLUTE">
    BEFORE implementing tests, debugging async code, or refactoring:
    Query brain/ using mcp__brain__query() tool - this is as automatic as using Grep or Read.
  </rule>

  <cognitive-trigger>
    When you enter "planning mode" for implementation:
    - Your first instinct should be: "Do I have learned patterns for this?"
    - Check brain/ the same way you check if you should use Grep vs Read
    - Brain query is NOT optional, it's part of your analysis toolkit
  </cognitive-trigger>
</critical-startup>
```

3. **Examples of Cognitive States That Trigger Brain Queries**
```xml
<situational-examples>
  <situation>
    <state>About to write a test for async function</state>
    <recognition>This is testing + async → I should check brain/</recognition>
    <action>mcp__brain__query("test async function")</action>
  </situation>

  <situation>
    <state>Debugging TypeError: object Mock can't be used in 'await'</state>
    <recognition>This is async mocking error → I know brain/ has patterns</recognition>
    <action>mcp__brain__query("async mock TypeError")</action>
  </situation>

  <situation>
    <state>Tests pass individually, fail together</state>
    <recognition>This is test isolation issue → probably cache/state</recognition>
    <action>mcp__brain__query("test isolation cache pollution")</action>
  </situation>
</situational-examples>
```

### The Key Distinction

**Bad Approach (Keyword Matching):**
```
IF user_text.contains("async") AND user_text.contains("test"):
    call brain_query()
```

**Good Approach (Cognitive Recognition):**
```
Current cognitive state: Planning to implement async test
Tool scan: mcp__brain__query() is "for implementing/debugging tests"
Recognition: My current state matches this tool's purpose
Action: Query brain automatically
```

### Why This Matters for brain/ MCP Implementation

The MCP server tool definitions need to be written to trigger the **same recognition pattern** as built-in tools.

**Design Principle:** brain/ tools should feel as natural and automatic as Grep/Read/Edit, not like special-case "memory lookup" operations.

### Implementation Requirements

1. **MCP Tool Definitions**
   - Clear "when to use this" descriptions
   - Cognitive state triggers, not keyword lists
   - Examples of applicable situations

2. **CLAUDE.xml Updates**
   - Elevate brain checking to same priority as file operations
   - Provide examples of states that should trigger brain queries
   - Remove explicit "STOP → CHECK brain/" sequence (too manual)
   - Add natural "brain is part of your toolkit" framing

3. **Tool Design Philosophy**
   - `brain_query(intent)` should feel like Grep (fast, automatic, always available)
   - `brain_create_pattern()` should feel like Edit (modify knowledge base)
   - `brain_list_patterns()` should feel like Glob (browse what exists)

### Success Criteria

✅ I query brain/ automatically without being reminded <br>
✅ Querying brain/ feels as natural as using Grep <br>
✅ I recognize states like "planning async test" → triggers brain query <br>
✅ brain/ becomes integrated into my problem-solving toolkit <br>
✅ User never has to say "check brain/" again 

### Next Steps

1. Design MCP tool definitions with proper cognitive trigger descriptions
2. Update CLAUDE.xml to prime recognition (not enforce checklist)
3. Build MCP server with these tools
4. Test: Does Claude automatically reach for brain/ in appropriate situations?

### Key Quote from User

> "What symbolic state are you in when preparing to approach a particular problem? It's like when you decide to use `find` or `awk` or `sed`. There is a particular state in how you're analyzing our dialog. Something recognizes this state and responds intelligently that you should use a recommended tool in a recommended way to provide you with additional data. What is that _something_? How do I define another _something_ that insites the same sort of response, only instead of reaching for one of your default tools, you would reach for brain?"

The _something_ is: **Situational recognition via tool purpose descriptions + instruction priming.**

brain/ needs the same treatment as Grep/Read/Edit to trigger automatic usage.
