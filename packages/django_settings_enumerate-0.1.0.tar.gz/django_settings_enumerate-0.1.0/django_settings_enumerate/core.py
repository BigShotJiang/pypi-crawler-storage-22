"""Core logic for django-settings-enumerate.

All functions are pure: no Django imports at module level, no side effects.
The management command calls these; tests exercise them directly.
"""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any

# Matches Django's SafeExceptionReporterFilter.hidden_settings, minus HTTP_COOKIE
# which is irrelevant to settings names. This is a substring match (re.search).
SENSITIVE_PATTERN = re.compile(
    r"API|TOKEN|KEY|SECRET|PASS|SIGNATURE", re.IGNORECASE
)


def extract_settings(settings_obj: object) -> dict[str, Any]:
    """Extract all uppercase attributes from a settings object."""
    return {
        key: getattr(settings_obj, key)
        for key in sorted(dir(settings_obj))
        if key.isupper()
    }


def filter_by_prefix(
    settings_dict: dict[str, Any],
    prefix: str,
) -> dict[str, Any]:
    """Return only settings whose keys start with the given prefix (case-insensitive)."""
    prefix_upper = prefix.upper()
    return {
        k: v for k, v in settings_dict.items()
        if k.startswith(prefix_upper)
    }


def is_sensitive_key(key: str, pattern: re.Pattern = SENSITIVE_PATTERN) -> bool:
    """Return True if key matches the sensitive-settings heuristic."""
    try:
        return bool(pattern.search(key))
    except TypeError:
        return False


def _hash_value(value: Any) -> str:
    """Return sha256 hex digest of a value's repr."""
    return hashlib.sha256(repr(value).encode()).hexdigest()


def cleanse_value(key: str, value: Any, *, show_sensitive: bool = False) -> Any:
    """Replace value with its sha256 hash if key is sensitive.

    Recursively cleanses dicts, lists, and tuples.
    """
    if show_sensitive:
        return value

    if is_sensitive_key(key):
        return _hash_value(value)

    if isinstance(value, dict):
        return {k: cleanse_value(k, v, show_sensitive=show_sensitive) for k, v in value.items()}
    if isinstance(value, list):
        return [cleanse_value("", item, show_sensitive=show_sensitive) for item in value]
    if isinstance(value, tuple):
        return tuple(cleanse_value("", item, show_sensitive=show_sensitive) for item in value)

    return value


def cleanse_settings(
    settings_dict: dict[str, Any],
    *,
    show_sensitive: bool = False,
) -> dict[str, Any]:
    """Apply cleanse_value to every entry in settings_dict."""
    return {
        k: cleanse_value(k, v, show_sensitive=show_sensitive)
        for k, v in settings_dict.items()
    }


def flatten_settings(settings_dict: dict[str, Any]) -> dict[str, Any]:
    """Recursively flatten nested dicts/lists/tuples into dot-notation paths.

    Dict keys: ``prefix.key``, list/tuple indices: ``prefix[i]``.
    Returns ``{path: leaf_value}`` sorted by path.
    """
    flat: dict[str, Any] = {}

    def _flatten(prefix: str, value: Any) -> None:
        if isinstance(value, dict):
            for k, v in value.items():
                path = f"{prefix}.{k}" if prefix else k
                _flatten(path, v)
        elif isinstance(value, (list, tuple)):
            for i, v in enumerate(value):
                path = f"{prefix}[{i}]"
                _flatten(path, v)
        else:
            flat[prefix] = value

    for key in settings_dict:
        _flatten(key, settings_dict[key])

    return dict(sorted(flat.items()))


def _json_encode_leaf(value: Any) -> str:
    """Encode a leaf value as a JSON scalar string."""
    try:
        return json.dumps(value)
    except (TypeError, ValueError):
        return json.dumps(repr(value))


def format_text(settings_dict: dict[str, Any]) -> str:
    """Render settings as flattened dot-notation text lines, alphabetically sorted."""
    flat = flatten_settings(settings_dict)
    lines = []
    for path, value in flat.items():
        lines.append(f"{path} = {_json_encode_leaf(value)}")
    return "\n".join(lines)


def format_json(settings_dict: dict[str, Any]) -> str:
    """Render settings as JSON. Non-serializable values fall back to repr()."""
    return json.dumps(settings_dict, indent=2, sort_keys=True, default=repr)


def parse_text_dump(content: str) -> dict[str, str]:
    """Parse flattened dump back into ``{path: json_value_string}``.

    Splits each line on the first `` = `` separator. Skips blank lines.
    """
    result: dict[str, str] = {}
    for line in content.splitlines():
        line = line.strip()
        if not line:
            continue
        path, _, json_val = line.partition(" = ")
        result[path] = json_val
    return result


def diff_settings(
    current: dict[str, str],
    previous: dict[str, str],
) -> dict[str, Any]:
    """Compute diff between two ``{path: json_value_string}`` mappings.

    Returns ``{"added": {…}, "removed": {…}, "changed": {…}}``.
    """
    cur_keys = set(current)
    prev_keys = set(previous)

    added = {k: current[k] for k in sorted(cur_keys - prev_keys)}
    removed = {k: previous[k] for k in sorted(prev_keys - cur_keys)}
    changed = {}
    for k in sorted(cur_keys & prev_keys):
        if current[k] != previous[k]:
            changed[k] = {"current": current[k], "previous": previous[k]}

    return {"added": added, "removed": removed, "changed": changed}


def format_diff(diff: dict[str, Any]) -> str:
    """Render a diff dict as human-readable text.

    Format::

        + NEW_SETTING = "value"
        - OLD_SETTING = "value"
        ~ CHANGED_SETTING
          previous: "old"
          current:  "new"
    """
    lines: list[str] = []

    for path, val in diff.get("added", {}).items():
        lines.append(f"+ {path} = {val}")

    for path, val in diff.get("removed", {}).items():
        lines.append(f"- {path} = {val}")

    for path, info in diff.get("changed", {}).items():
        lines.append(f"~ {path}")
        lines.append(f"  previous: {info['previous']}")
        lines.append(f"  current:  {info['current']}")

    return "\n".join(lines)
