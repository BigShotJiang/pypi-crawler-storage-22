"""Management command: enumerate_settings

Dumps an ordered list of Django settings with optional filtering,
format selection, and automatic sensitive-value masking.
"""
from django.core.management.base import BaseCommand

from django_settings_enumerate.core import (
    cleanse_settings,
    diff_settings,
    extract_settings,
    filter_by_prefix,
    flatten_settings,
    format_diff,
    format_json,
    format_text,
    parse_text_dump,
    _json_encode_leaf,
)


class Command(BaseCommand):
    help = "Display an ordered list of Django settings."

    requires_system_checks = []

    def add_arguments(self, parser):
        parser.add_argument(
            "--format",
            choices=("text", "json"),
            default="text",
            dest="output_format",
            help='Output format: "text" (default) or "json".',
        )
        parser.add_argument(
            "--filter",
            dest="prefix_filter",
            default=None,
            help="Show only settings whose name starts with this prefix.",
        )
        parser.add_argument(
            "--show-sensitive",
            action="store_true",
            default=False,
            help="Show actual values for sensitive settings instead of masking them.",
        )
        parser.add_argument(
            "--diff",
            type=str,
            default=None,
            metavar="FILE",
            help="Diff current settings against a previous text dump file.",
        )

    def handle(self, *args, **options):
        from django.conf import settings

        settings_dict = extract_settings(settings)

        if options["prefix_filter"]:
            settings_dict = filter_by_prefix(
                settings_dict, options["prefix_filter"]
            )

        settings_dict = cleanse_settings(
            settings_dict,
            show_sensitive=options["show_sensitive"],
        )

        if options["diff"]:
            with open(options["diff"]) as f:
                previous_content = f.read()
            previous = parse_text_dump(previous_content)
            current_flat = flatten_settings(settings_dict)
            current = {path: _json_encode_leaf(val) for path, val in current_flat.items()}
            diff = diff_settings(current, previous)
            output = format_diff(diff)
        else:
            formatter = {
                "text": format_text,
                "json": format_json,
            }[options["output_format"]]
            output = formatter(settings_dict)

        self.stdout.write(output)
        if output and not output.endswith("\n"):
            self.stdout.write("\n")

        return output
