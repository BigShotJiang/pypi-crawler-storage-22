"""Tests for django_settings_enumerate.core — all pure functions, no Django setup needed."""
import hashlib
from types import SimpleNamespace

from django_settings_enumerate.core import (
    _hash_value,
    _json_encode_leaf,
    cleanse_settings,
    cleanse_value,
    diff_settings,
    extract_settings,
    filter_by_prefix,
    flatten_settings,
    format_diff,
    format_json,
    format_text,
    is_sensitive_key,
    parse_text_dump,
)


# ---------------------------------------------------------------------------
# extract_settings
# ---------------------------------------------------------------------------

class TestExtractSettings:
    def test_extracts_uppercase_only(self):
        obj = SimpleNamespace(DEBUG=True, ALLOWED_HOSTS=[], _internal="skip", lowercase="skip")
        result = extract_settings(obj)
        assert "DEBUG" in result
        assert "ALLOWED_HOSTS" in result
        assert "_internal" not in result
        assert "lowercase" not in result

    def test_sorted_alphabetically(self):
        obj = SimpleNamespace(ZEBRA=1, ALPHA=2, MIDDLE=3)
        result = extract_settings(obj)
        assert list(result.keys()) == ["ALPHA", "MIDDLE", "ZEBRA"]

    def test_empty_object(self):
        obj = SimpleNamespace()
        result = extract_settings(obj)
        # May include built-in uppercase attrs from object, but no custom ones
        assert isinstance(result, dict)


# ---------------------------------------------------------------------------
# filter_by_prefix
# ---------------------------------------------------------------------------

class TestFilterByPrefix:
    def test_filters_by_prefix(self):
        settings = {"DATABASE_URL": "x", "DATABASES": {}, "DEBUG": True, "ALLOWED_HOSTS": []}
        result = filter_by_prefix(settings, "DATABASE")
        assert set(result.keys()) == {"DATABASE_URL", "DATABASES"}

    def test_case_insensitive_prefix(self):
        settings = {"DATABASE_URL": "x", "DEBUG": True}
        result = filter_by_prefix(settings, "database")
        assert "DATABASE_URL" in result

    def test_no_match(self):
        settings = {"DEBUG": True}
        result = filter_by_prefix(settings, "CACHE")
        assert result == {}


# ---------------------------------------------------------------------------
# is_sensitive_key
# ---------------------------------------------------------------------------

class TestIsSensitiveKey:
    def test_secret_key(self):
        assert is_sensitive_key("SECRET_KEY") is True

    def test_password(self):
        assert is_sensitive_key("DATABASE_PASSWORD") is True

    def test_token(self):
        assert is_sensitive_key("CSRF_COOKIE_TOKEN") is True

    def test_api(self):
        assert is_sensitive_key("THIRD_PARTY_API_URL") is True

    def test_signature(self):
        assert is_sensitive_key("HMAC_SIGNATURE") is True

    def test_non_sensitive(self):
        assert is_sensitive_key("DEBUG") is False
        assert is_sensitive_key("ALLOWED_HOSTS") is False
        assert is_sensitive_key("LANGUAGE_CODE") is False

    def test_case_insensitive(self):
        assert is_sensitive_key("secret_key") is True


# ---------------------------------------------------------------------------
# cleanse_value
# ---------------------------------------------------------------------------

class TestHashValue:
    def test_deterministic(self):
        assert _hash_value("my-secret") == _hash_value("my-secret")

    def test_different_values_different_hashes(self):
        assert _hash_value("a") != _hash_value("b")

    def test_returns_hex_string(self):
        result = _hash_value("test")
        assert len(result) == 64
        assert all(c in "0123456789abcdef" for c in result)


class TestCleanseValue:
    def test_hashes_sensitive_key(self):
        result = cleanse_value("SECRET_KEY", "my-secret")
        assert result == _hash_value("my-secret")

    def test_passes_non_sensitive(self):
        assert cleanse_value("DEBUG", True) is True

    def test_show_sensitive_bypasses(self):
        assert cleanse_value("SECRET_KEY", "my-secret", show_sensitive=True) == "my-secret"

    def test_recurses_into_dict(self):
        value = {"PASSWORD": "hunter2", "HOST": "localhost"}
        result = cleanse_value("DATABASES", value)
        assert result["PASSWORD"] == _hash_value("hunter2")
        assert result["HOST"] == "localhost"

    def test_recurses_into_list(self):
        value = [1, 2, 3]
        result = cleanse_value("SOME_LIST", value)
        assert result == [1, 2, 3]

    def test_recurses_into_tuple(self):
        value = (1, 2)
        result = cleanse_value("SOME_TUPLE", value)
        assert result == (1, 2)


# ---------------------------------------------------------------------------
# cleanse_settings
# ---------------------------------------------------------------------------

class TestCleanseSettings:
    def test_hashes_sensitive_keys(self):
        settings = {"SECRET_KEY": "abc", "DEBUG": True}
        result = cleanse_settings(settings)
        assert result["SECRET_KEY"] == _hash_value("abc")
        assert result["DEBUG"] is True

    def test_show_sensitive(self):
        settings = {"SECRET_KEY": "abc"}
        result = cleanse_settings(settings, show_sensitive=True)
        assert result["SECRET_KEY"] == "abc"


# ---------------------------------------------------------------------------
# flatten_settings
# ---------------------------------------------------------------------------

class TestFlattenSettings:
    def test_scalar_values(self):
        settings = {"DEBUG": True, "TIMEOUT": 30}
        result = flatten_settings(settings)
        assert result == {"DEBUG": True, "TIMEOUT": 30}

    def test_nested_dict(self):
        settings = {"DATABASES": {"default": {"ENGINE": "postgresql", "HOST": "localhost"}}}
        result = flatten_settings(settings)
        assert result == {
            "DATABASES.default.ENGINE": "postgresql",
            "DATABASES.default.HOST": "localhost",
        }

    def test_list(self):
        settings = {"ALLOWED_HOSTS": ["*", "example.com"]}
        result = flatten_settings(settings)
        assert result == {
            "ALLOWED_HOSTS[0]": "*",
            "ALLOWED_HOSTS[1]": "example.com",
        }

    def test_tuple(self):
        settings = {"MIDDLEWARE": ("mw1", "mw2")}
        result = flatten_settings(settings)
        assert result == {
            "MIDDLEWARE[0]": "mw1",
            "MIDDLEWARE[1]": "mw2",
        }

    def test_mixed_nesting(self):
        settings = {"CACHES": {"default": {"BACKEND": "redis", "LOCATION": ["host1", "host2"]}}}
        result = flatten_settings(settings)
        assert result == {
            "CACHES.default.BACKEND": "redis",
            "CACHES.default.LOCATION[0]": "host1",
            "CACHES.default.LOCATION[1]": "host2",
        }

    def test_sorted_output(self):
        settings = {"ZEBRA": 1, "ALPHA": 2}
        result = flatten_settings(settings)
        assert list(result.keys()) == ["ALPHA", "ZEBRA"]

    def test_empty(self):
        assert flatten_settings({}) == {}


# ---------------------------------------------------------------------------
# format_text
# ---------------------------------------------------------------------------

class TestFormatText:
    def test_scalar_values(self):
        settings = {"DEBUG": True, "TIMEOUT": 30}
        result = format_text(settings)
        assert "DEBUG = true" in result
        assert "TIMEOUT = 30" in result

    def test_string_value_json_encoded(self):
        settings = {"HOST": "localhost"}
        result = format_text(settings)
        assert 'HOST = "localhost"' in result

    def test_nested_dict_flattened(self):
        settings = {"DB": {"default": {"HOST": "localhost"}}}
        result = format_text(settings)
        assert 'DB.default.HOST = "localhost"' in result

    def test_list_flattened(self):
        settings = {"HOSTS": ["a", "b"]}
        result = format_text(settings)
        assert 'HOSTS[0] = "a"' in result
        assert 'HOSTS[1] = "b"' in result

    def test_null_value(self):
        settings = {"EMPTY": None}
        result = format_text(settings)
        assert "EMPTY = null" in result

    def test_non_serializable_fallback(self):
        fn = lambda: None
        settings = {"FUNC": fn}
        result = format_text(settings)
        assert "FUNC = " in result
        assert "function" in result

    def test_empty(self):
        assert format_text({}) == ""


# ---------------------------------------------------------------------------
# format_json
# ---------------------------------------------------------------------------

class TestFormatJson:
    def test_json_object(self):
        import json
        settings = {"DEBUG": True, "ALPHA": 1}
        result = format_json(settings)
        parsed = json.loads(result)
        assert parsed["DEBUG"] is True
        assert parsed["ALPHA"] == 1

    def test_non_serializable_falls_back_to_repr(self):
        import json
        settings = {"FUNC": lambda: None}
        result = format_json(settings)
        parsed = json.loads(result)
        assert "function" in parsed["FUNC"]

    def test_empty(self):
        import json
        result = format_json({})
        assert json.loads(result) == {}


# ---------------------------------------------------------------------------
# parse_text_dump
# ---------------------------------------------------------------------------

class TestParseTextDump:
    def test_round_trip(self):
        settings = {"DEBUG": True, "HOST": "localhost", "COUNT": 42}
        text = format_text(settings)
        parsed = parse_text_dump(text)
        assert parsed == {"COUNT": "42", "DEBUG": "true", "HOST": '"localhost"'}

    def test_nested_round_trip(self):
        settings = {"DB": {"default": {"HOST": "localhost", "PORT": 5432}}}
        text = format_text(settings)
        parsed = parse_text_dump(text)
        assert parsed == {
            "DB.default.HOST": '"localhost"',
            "DB.default.PORT": "5432",
        }

    def test_skips_blank_lines(self):
        content = "A = 1\n\nB = 2\n"
        parsed = parse_text_dump(content)
        assert parsed == {"A": "1", "B": "2"}

    def test_empty_content(self):
        assert parse_text_dump("") == {}
        assert parse_text_dump("\n\n") == {}


# ---------------------------------------------------------------------------
# diff_settings
# ---------------------------------------------------------------------------

class TestDiffSettings:
    def test_added(self):
        current = {"A": "1", "B": "2"}
        previous = {"A": "1"}
        result = diff_settings(current, previous)
        assert result["added"] == {"B": "2"}
        assert result["removed"] == {}
        assert result["changed"] == {}

    def test_removed(self):
        current = {"A": "1"}
        previous = {"A": "1", "B": "2"}
        result = diff_settings(current, previous)
        assert result["added"] == {}
        assert result["removed"] == {"B": "2"}
        assert result["changed"] == {}

    def test_changed(self):
        current = {"A": "1"}
        previous = {"A": "99"}
        result = diff_settings(current, previous)
        assert result["added"] == {}
        assert result["removed"] == {}
        assert result["changed"] == {"A": {"current": "1", "previous": "99"}}

    def test_no_changes(self):
        data = {"A": "1", "B": "2"}
        result = diff_settings(data, data)
        assert result == {"added": {}, "removed": {}, "changed": {}}

    def test_mixed(self):
        current = {"A": "1", "C": "3"}
        previous = {"A": "99", "B": "2"}
        result = diff_settings(current, previous)
        assert result["added"] == {"C": "3"}
        assert result["removed"] == {"B": "2"}
        assert result["changed"] == {"A": {"current": "1", "previous": "99"}}


# ---------------------------------------------------------------------------
# format_diff
# ---------------------------------------------------------------------------

class TestFormatDiff:
    def test_added(self):
        diff = {"added": {"NEW": '"val"'}, "removed": {}, "changed": {}}
        result = format_diff(diff)
        assert result == '+ NEW = "val"'

    def test_removed(self):
        diff = {"added": {}, "removed": {"OLD": '"val"'}, "changed": {}}
        result = format_diff(diff)
        assert result == '- OLD = "val"'

    def test_changed(self):
        diff = {
            "added": {},
            "removed": {},
            "changed": {"X": {"current": '"new"', "previous": '"old"'}},
        }
        result = format_diff(diff)
        lines = result.split("\n")
        assert lines[0] == "~ X"
        assert lines[1] == '  previous: "old"'
        assert lines[2] == '  current:  "new"'

    def test_empty_diff(self):
        diff = {"added": {}, "removed": {}, "changed": {}}
        assert format_diff(diff) == ""

    def test_full_diff(self):
        diff = {
            "added": {"C": "3"},
            "removed": {"B": "2"},
            "changed": {"A": {"current": "1", "previous": "99"}},
        }
        result = format_diff(diff)
        assert "+ C = 3" in result
        assert "- B = 2" in result
        assert "~ A" in result
        assert "  previous: 99" in result
        assert "  current:  1" in result
