from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from django.contrib.auth.models import User
    from django.db.models import Model, QuerySet


def find_user_list_from_content_type(app_label: str, model_name: str) -> QuerySet[User]:
    from django.contrib.auth.models import Permission, Group, User
    from django.contrib.contenttypes.models import ContentType

    content_type = ContentType.objects.get(app_label=app_label, model=model_name)
    permission = Permission.objects.get(content_type=content_type, codename=f'view_{model_name}')
    groups = Group.objects.filter(permissions=permission)

    return User.objects.filter(groups__in=groups).distinct()


def generate_comment_user_list_data(user_list: QuerySet[User] | list[User]) -> list[dict]:
    return [
        {
            'full_name': user.get_full_name().replace(' ', '_'),
            'id': user.pk,
        }
        for user in user_list
    ]


def parse_user_id_to_int_list(user_id_str: str) -> QuerySet[User]:
    from django.contrib.auth.models import User

    user_id_list =  [int(user_id) for user_id in user_id_str.split(',')]
    return User.objects.filter(id__in=user_id_list)


def process_comment_notifications(
    user_list: QuerySet[User] | list[User],
    comment_information: str,
    related_obj: Model,
    user_commenting: User
) -> None:
    from django.contrib.sites.models import Site
    from django_spire.notification.models import Notification

    for user in user_list:
        if user != user_commenting:
            Notification.create(
                email=user.email,
                title='New Comment',
                body=f'You were tagged in a new comment! {user_commenting.get_full_name()} wrote "{comment_information}" on {related_obj}.',
                url=Site.objects.get_current()
            )
