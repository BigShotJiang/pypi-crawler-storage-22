from __future__ import annotations


class OrderingMixinGroupError(Exception):
    pass


class OrderingMixinError(Exception):
    pass
