from __future__ import annotations

from django_spire.core.middleware.maintenance import MaintenanceMiddleware


__all__ = ['MaintenanceMiddleware']
