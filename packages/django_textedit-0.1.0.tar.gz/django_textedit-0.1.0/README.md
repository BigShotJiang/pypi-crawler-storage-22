# django-textedit

A reusable Django rich text editor widget with image upload, emoji picker, and XSS protection. No external dependencies.

## Features

- **WYSIWYG Editor** : contenteditable-based, no external JS library
- **Toolbar** : bold, italic, underline, highlight, text color, uppercase, bullet lists (5 types), alignment, image insert, emoji insert
- **Image Upload** : drag & drop or file browser, with multi-layer server validation (extension, MIME, magic bytes, file size, filename sanitization)
- **Emoji Picker** : 7 categories (smileys, gestures, symbols, nature, food, travel, sport), 200+ emojis
- **Image Resize** : proportional resize handles on all 4 corners (mouse & touch)
- **HTML Sanitizer** : whitelist-based anti-XSS, automatic on save
- **Responsive** : mobile-first CSS with 3 breakpoints (mobile, tablet 768px+, desktop 1024px+)
- **Django Admin** : dedicated `AdminTextEditWidget` with admin-specific CSS
- **CSRF Protected** : image uploads use the CSRF token from cookie

## Quick Start

```bash
pip install django-textedit
```

Add to `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    # ...
    'textedit',
]
```

Configure media files in `settings.py`:

```python
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'
```

Include URLs in your `urls.py`:

```python
from django.urls import include, path

urlpatterns = [
    path('textedit/', include('textedit.urls')),
]
```

## Usage

### Model

```python
from django.db import models
from textedit.models import RichTextField

class Article(models.Model):
    title = models.CharField(max_length=200)
    content = RichTextField()
```

### Form

```python
from django import forms
from textedit.forms import TextEditFormField
from .models import Article

class ArticleForm(forms.ModelForm):
    content = TextEditFormField()

    class Meta:
        model = Article
        fields = ['title', 'content']
```

### Template

```html
<head>
    {{ form.media }}
</head>
<body>
    <form method="post">
        {% csrf_token %}
        {{ form.content }}
        <button type="submit">Save</button>
    </form>
</body>
```

## Configuration

Optional settings in `settings.py`:

```python
# Max upload size in bytes (default: 5 MB)
TEXTEDIT_MAX_UPLOAD_SIZE = 5 * 1024 * 1024

# Allowed image extensions
TEXTEDIT_ALLOWED_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp']

# Upload directory (relative to MEDIA_ROOT)
TEXTEDIT_UPLOAD_DIR = 'textedit_uploads'
```

## Requirements

- Python >= 3.10
- Django >= 4.2

## License

MIT
