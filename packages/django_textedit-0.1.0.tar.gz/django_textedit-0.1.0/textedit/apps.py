from django.apps import AppConfig


class TextEditConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'textedit'
    verbose_name = 'TextEdit Rich Text Editor'
