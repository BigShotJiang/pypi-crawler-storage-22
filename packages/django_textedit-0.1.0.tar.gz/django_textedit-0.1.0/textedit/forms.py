from django import forms

from .sanitizers import sanitize_html
from .widgets import TextEditWidget


class TextEditFormField(forms.CharField):
    """
    A form field that uses the TextEdit widget and sanitizes
    HTML content on clean.
    """

    widget = TextEditWidget

    def __init__(self, *args, sanitize=True, **kwargs):
        self.sanitize = sanitize
        super().__init__(*args, **kwargs)

    def clean(self, value):
        value = super().clean(value)
        if self.sanitize and value:
            value = sanitize_html(value)
        return value
