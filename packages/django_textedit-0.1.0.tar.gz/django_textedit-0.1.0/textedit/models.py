from django.db import models

from .sanitizers import sanitize_html
from .widgets import TextEditWidget


class RichTextField(models.TextField):
    """
    A TextField that uses the TextEdit rich text editor widget
    and sanitizes HTML content on save.
    """

    def __init__(self, *args, sanitize=True, **kwargs):
        self.sanitize = sanitize
        super().__init__(*args, **kwargs)

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        if not self.sanitize:
            kwargs['sanitize'] = False
        return name, path, args, kwargs

    def formfield(self, **kwargs):
        defaults = {'widget': TextEditWidget}
        defaults.update(kwargs)
        return super().formfield(**defaults)

    def pre_save(self, model_instance, add):
        value = getattr(model_instance, self.attname)
        if self.sanitize and value:
            value = sanitize_html(value)
            setattr(model_instance, self.attname, value)
        return value
