import re
from html.parser import HTMLParser

from . import settings as te_settings


class _SanitizingParser(HTMLParser):
    """
    HTML parser that strips disallowed tags/attributes and sanitizes
    CSS in style attributes to prevent XSS.
    """

    def __init__(self, allowed_tags, allowed_attributes, allowed_css_properties):
        super().__init__(convert_charrefs=False)
        self.allowed_tags = set(allowed_tags)
        self.allowed_attributes = allowed_attributes
        self.allowed_css = set(allowed_css_properties)
        self.result = []
        self._open_tags = []
        self._skip_depth = 0  # Track depth inside disallowed tags
        self._DANGEROUS_TAGS = frozenset(['script', 'style', 'iframe', 'object', 'embed', 'applet'])

    def handle_starttag(self, tag, attrs):
        if tag in self._DANGEROUS_TAGS:
            self._skip_depth += 1
            return
        if self._skip_depth > 0:
            return
        if tag not in self.allowed_tags:
            return
        clean_attrs = self._clean_attributes(tag, attrs)
        attr_str = ''
        for name, value in clean_attrs:
            if value is None:
                attr_str += f' {name}'
            else:
                escaped = value.replace('&', '&amp;').replace('"', '&quot;')
                attr_str += f' {name}="{escaped}"'
        self.result.append(f'<{tag}{attr_str}>')
        # Track open tags for proper closing (skip void elements)
        if tag not in ('br', 'img', 'hr', 'input', 'meta', 'link'):
            self._open_tags.append(tag)

    def handle_endtag(self, tag):
        if tag in self._DANGEROUS_TAGS:
            if self._skip_depth > 0:
                self._skip_depth -= 1
            return
        if self._skip_depth > 0:
            return
        if tag not in self.allowed_tags:
            return
        if tag in ('br', 'img', 'hr', 'input', 'meta', 'link'):
            return
        self.result.append(f'</{tag}>')

    def handle_data(self, data):
        if self._skip_depth > 0:
            return  # Suppress content inside dangerous tags
        self.result.append(data.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))

    def handle_entityref(self, name):
        self.result.append(f'&{name};')

    def handle_charref(self, name):
        self.result.append(f'&#{name};')

    def _clean_attributes(self, tag, attrs):
        """Filter attributes to only allowed ones, sanitize style."""
        allowed_global = self.allowed_attributes.get('*', [])
        allowed_for_tag = self.allowed_attributes.get(tag, [])
        allowed = set(allowed_global) | set(allowed_for_tag)

        clean = []
        for name, value in attrs:
            if name not in allowed:
                continue
            if name == 'style' and value:
                value = self._sanitize_css(value)
                if not value:
                    continue
            if name == 'href' and value:
                value = self._sanitize_href(value)
                if value is None:
                    continue
            if name == 'src' and value:
                value = self._sanitize_src(value)
                if value is None:
                    continue
            clean.append((name, value))
        return clean

    def _sanitize_css(self, style):
        """Only allow whitelisted CSS properties."""
        clean_props = []
        # Split on semicolons
        for prop in style.split(';'):
            prop = prop.strip()
            if not prop:
                continue
            if ':' not in prop:
                continue
            name, _, value = prop.partition(':')
            name = name.strip().lower()
            value = value.strip()
            if name in self.allowed_css:
                # Block expressions, url(), javascript: in CSS values
                lower_val = value.lower().replace(' ', '')
                if any(dangerous in lower_val for dangerous in
                       ['expression(', 'url(', 'javascript:', 'vbscript:']):
                    continue
                clean_props.append(f'{name}: {value}')
        return '; '.join(clean_props)

    def _sanitize_href(self, href):
        """Block javascript: and data: URLs in href attributes."""
        stripped = href.strip().lower()
        if stripped.startswith(('javascript:', 'vbscript:', 'data:')):
            return None
        return href

    def _sanitize_src(self, src):
        """Block javascript: and data: URLs in src attributes (except data:image)."""
        stripped = src.strip().lower()
        if stripped.startswith(('javascript:', 'vbscript:')):
            return None
        if stripped.startswith('data:') and not stripped.startswith('data:image/'):
            return None
        return src

    def get_clean_html(self):
        return ''.join(self.result)


def sanitize_html(html_content):
    """
    Sanitize HTML content by stripping disallowed tags, attributes,
    and dangerous CSS/URLs to prevent XSS attacks.
    """
    if not html_content:
        return ''

    allowed_tags = te_settings.TEXTEDIT_ALLOWED_TAGS
    allowed_attributes = te_settings.TEXTEDIT_ALLOWED_ATTRIBUTES
    allowed_css = te_settings.TEXTEDIT_ALLOWED_CSS_PROPERTIES

    parser = _SanitizingParser(allowed_tags, allowed_attributes, allowed_css)
    parser.feed(html_content)
    return parser.get_clean_html()
