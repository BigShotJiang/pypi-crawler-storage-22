from django.conf import settings

# Allowed image extensions for upload
TEXTEDIT_ALLOWED_EXTENSIONS = getattr(
    settings, 'TEXTEDIT_ALLOWED_EXTENSIONS',
    ['jpg', 'jpeg', 'png', 'gif', 'webp']
)

# Allowed MIME types for upload
TEXTEDIT_ALLOWED_MIME_TYPES = getattr(
    settings, 'TEXTEDIT_ALLOWED_MIME_TYPES',
    ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
)

# Maximum upload file size in bytes (default 5 MB)
TEXTEDIT_MAX_UPLOAD_SIZE = getattr(
    settings, 'TEXTEDIT_MAX_UPLOAD_SIZE',
    5 * 1024 * 1024
)

# Upload subdirectory under MEDIA_ROOT
TEXTEDIT_UPLOAD_DIR = getattr(
    settings, 'TEXTEDIT_UPLOAD_DIR',
    'textedit_uploads'
)

# HTML sanitizer: allowed tags
TEXTEDIT_ALLOWED_TAGS = getattr(
    settings, 'TEXTEDIT_ALLOWED_TAGS',
    [
        'p', 'br', 'strong', 'b', 'em', 'i', 'u', 's',
        'span', 'div', 'img', 'a',
        'ul', 'ol', 'li',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'blockquote', 'pre', 'code',
        'table', 'thead', 'tbody', 'tr', 'th', 'td',
    ]
)

# HTML sanitizer: allowed attributes per tag
TEXTEDIT_ALLOWED_ATTRIBUTES = getattr(
    settings, 'TEXTEDIT_ALLOWED_ATTRIBUTES',
    {
        '*': ['style'],
        'a': ['href', 'title', 'target', 'rel'],
        'img': ['src', 'alt', 'width', 'height'],
    }
)

# HTML sanitizer: allowed CSS properties in style attributes
TEXTEDIT_ALLOWED_CSS_PROPERTIES = getattr(
    settings, 'TEXTEDIT_ALLOWED_CSS_PROPERTIES',
    [
        'color', 'background-color', 'text-align',
        'font-weight', 'font-style', 'text-decoration',
        'list-style-type',
        'margin', 'padding', 'width', 'height',
        'max-width', 'max-height',
    ]
)
