(function() {
    'use strict';

    /* ======================================================================
       Utilities
       ====================================================================== */

    function getCookie(name) {
        var cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }

    var savedSelection = null;

    function saveSelection() {
        var sel = window.getSelection();
        if (sel.rangeCount > 0) {
            savedSelection = sel.getRangeAt(0).cloneRange();
        }
    }

    function restoreSelection() {
        if (savedSelection) {
            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(savedSelection);
        }
    }

    /* ======================================================================
       TextEditColorPicker
       ====================================================================== */

    var COLORS = [
        '#000000', '#e53935', '#d81b60', '#8e24aa', '#5e35b1',
        '#1e88e5', '#00acc1', '#43a047', '#7cb342', '#fdd835',
        '#fb8c00', '#6d4c41', '#ffffff'
    ];

    function TextEditColorPicker(container, editor) {
        this.container = container;
        this.editor = editor;
        this.dropdown = container.querySelector('[data-dropdown="color"]');
        this.panel = this.dropdown.querySelector('.textedit-color-panel');
        this.indicator = this.dropdown.querySelector('.textedit-color-indicator');
        this.currentColor = '#000000';
        this._buildSwatches();
        this._bindEvents();
    }

    TextEditColorPicker.prototype._buildSwatches = function() {
        this.panel.innerHTML = '';
        for (var i = 0; i < COLORS.length; i++) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'textedit-color-swatch';
            btn.style.backgroundColor = COLORS[i];
            if (COLORS[i] === '#ffffff') {
                btn.style.border = '2px solid #ccc';
            }
            btn.setAttribute('data-color', COLORS[i]);
            btn.title = COLORS[i];
            this.panel.appendChild(btn);
        }
    };

    TextEditColorPicker.prototype._bindEvents = function() {
        var self = this;
        this.panel.addEventListener('click', function(e) {
            var swatch = e.target.closest('.textedit-color-swatch');
            if (!swatch) return;
            var color = swatch.getAttribute('data-color');
            self.currentColor = color;
            self.indicator.style.backgroundColor = color;
            self.hide();
            restoreSelection();
            document.execCommand('foreColor', false, color);
            self.editor.syncToTextarea();
        });
    };

    TextEditColorPicker.prototype.toggle = function() {
        if (this.panel.style.display === 'none') {
            this.show();
        } else {
            this.hide();
        }
    };

    TextEditColorPicker.prototype.show = function() {
        this.panel.style.display = 'grid';
    };

    TextEditColorPicker.prototype.hide = function() {
        this.panel.style.display = 'none';
    };

    /* ======================================================================
       TextEditImageHandler
       ====================================================================== */

    var ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    var MAX_CLIENT_SIZE = 5 * 1024 * 1024;

    function TextEditImageHandler(container, editor) {
        this.container = container;
        this.editor = editor;
        this.modal = container.querySelector('.textedit-image-modal');
        this.dropzone = this.modal.querySelector('.textedit-dropzone');
        this.fileInput = this.modal.querySelector('.textedit-file-input');
        this.progressEl = this.modal.querySelector('.textedit-upload-progress');
        this.progressFill = this.modal.querySelector('.textedit-progress-fill');
        this.statusEl = this.modal.querySelector('.textedit-upload-status');
        this.errorEl = this.modal.querySelector('.textedit-upload-error');
        this.errorMsg = this.modal.querySelector('.textedit-error-message');
        this.uploadUrl = container.getAttribute('data-upload-url');
        this.csrfCookieName = container.getAttribute('data-csrf-cookie-name') || 'csrftoken';
        this._bindEvents();
    }

    TextEditImageHandler.prototype._bindEvents = function() {
        var self = this;
        var overlay = this.modal.querySelector('.textedit-modal-overlay');
        var closeBtn = this.modal.querySelector('.textedit-modal-close');

        overlay.addEventListener('click', function() { self.hide(); });
        closeBtn.addEventListener('click', function() { self.hide(); });

        // Drag & drop
        this.dropzone.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            self.dropzone.classList.add('dragover');
        });
        this.dropzone.addEventListener('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            self.dropzone.classList.remove('dragover');
        });
        this.dropzone.addEventListener('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            self.dropzone.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) {
                self._handleFile(e.dataTransfer.files[0]);
            }
        });

        // File input
        this.fileInput.addEventListener('change', function() {
            if (self.fileInput.files.length > 0) {
                self._handleFile(self.fileInput.files[0]);
            }
        });
    };

    TextEditImageHandler.prototype.show = function() {
        this._reset();
        this.modal.style.display = 'flex';
    };

    TextEditImageHandler.prototype.hide = function() {
        this.modal.style.display = 'none';
        this.fileInput.value = '';
    };

    TextEditImageHandler.prototype._reset = function() {
        this.dropzone.style.display = 'flex';
        this.progressEl.style.display = 'none';
        this.errorEl.style.display = 'none';
        this.progressFill.style.width = '0%';
    };

    TextEditImageHandler.prototype._handleFile = function(file) {
        // Client-side validation
        if (ALLOWED_TYPES.indexOf(file.type) === -1) {
            this._showError('Type de fichier non autorisé. Formats acceptés : JPG, PNG, GIF, WebP.');
            return;
        }
        if (file.size > MAX_CLIENT_SIZE) {
            this._showError('Le fichier est trop volumineux (maximum 5 Mo).');
            return;
        }
        var ext = file.name.split('.').pop().toLowerCase();
        var allowedExts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (allowedExts.indexOf(ext) === -1) {
            this._showError('Extension de fichier non autorisée.');
            return;
        }
        this._upload(file);
    };

    TextEditImageHandler.prototype._upload = function(file) {
        var self = this;
        this.dropzone.style.display = 'none';
        this.errorEl.style.display = 'none';
        this.progressEl.style.display = 'block';
        this.progressFill.style.width = '10%';
        this.statusEl.textContent = 'Envoi en cours...';

        var formData = new FormData();
        formData.append('image', file);

        var xhr = new XMLHttpRequest();
        xhr.open('POST', this.uploadUrl, true);
        xhr.setRequestHeader('X-CSRFToken', getCookie(this.csrfCookieName));

        xhr.upload.addEventListener('progress', function(e) {
            if (e.lengthComputable) {
                var pct = Math.round((e.loaded / e.total) * 90) + 10;
                self.progressFill.style.width = pct + '%';
            }
        });

        xhr.addEventListener('load', function() {
            if (xhr.status === 200) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    if (data.url) {
                        self.progressFill.style.width = '100%';
                        self.statusEl.textContent = 'Terminé !';
                        setTimeout(function() {
                            self.hide();
                            self._insertImage(data.url);
                        }, 300);
                    } else {
                        self._showError(data.error || 'Erreur lors de l\'envoi.');
                    }
                } catch (e) {
                    self._showError('Réponse invalide du serveur.');
                }
            } else {
                try {
                    var errData = JSON.parse(xhr.responseText);
                    self._showError(errData.error || 'Erreur serveur (' + xhr.status + ').');
                } catch (e) {
                    self._showError('Erreur serveur (' + xhr.status + ').');
                }
            }
        });

        xhr.addEventListener('error', function() {
            self._showError('Erreur réseau. Veuillez réessayer.');
        });

        xhr.send(formData);
    };

    TextEditImageHandler.prototype._showError = function(msg) {
        this.dropzone.style.display = 'none';
        this.progressEl.style.display = 'none';
        this.errorEl.style.display = 'block';
        this.errorMsg.textContent = msg;
        // Allow retry after 2 seconds
        var self = this;
        setTimeout(function() { self._reset(); }, 2000);
    };

    TextEditImageHandler.prototype._insertImage = function(url) {
        restoreSelection();
        var img = '<img src="' + url + '" alt="" style="max-width:100%;">';
        document.execCommand('insertHTML', false, img);
        this.editor.syncToTextarea();
    };

    /* ======================================================================
       TextEditEmojiPicker
       ====================================================================== */

    var EMOJIS = {
        smileys: [
            '😀','😃','😄','😁','😆','😅','🤣','😂','🙂','🙃',
            '😉','😊','😇','😍','🤩','😘','😗','😚','😙','🥰',
            '😋','😛','😜','🤪','😝','🤑','🤗','🤭','🤫','🤔',
            '😱','🤤','🤮','🤒','😡','🥵','😏','😈','💩','🤯'
        ],
        gestures: [
            '👋','🤚','🖐','✋','🖖','👌','🤌','🤏','✌','🤞',
            '🤟','🤘','🤙','👈','👉','👆','🖕','👇','☝','👍',
            '👎','✊','👊','🤛','🤜','👏','🙌','👐','🤲','🤝',
            '💪','🙏'
        ],
        symbols: [
            '❤','💔','🧡','💛','💚','💙','💜','🖤','🤍','🤎',
            '❣','💕','💞','💓','💗','💖','💘','💝','⭐','🌟',
            '✨','💫','🔥','💯','✅','❌','⚡','💡','🎵','🎶',
            '♠','♦','♣','♥','🛑','📧','📝','🔍','☎','📱',
            '🪦','➕'
        ],
        nature: [
            '🌸','🌹','🌺','🌻','🌼','🌷','🌱','🌿','☘','🍀',
            '🍁','🍂','🍃','🪴','🌍','🌎','🌏','🌙','⭐','☀','🌈',
            '☁','🌧','🌾','🌞','🌅','🐟',
            '🐍','🐶','🐱','🐭','🐴','🐰','🦎','🐔','🐮','🐷',
            '🐞','🐜','🦋','🐝'
        ],
        food: [
            '🍽','🥒','🍑','🥂','🍾','🍺','🍔','🍕','🍰','🍎',
            '🍇','🍓','🌽','🥕','🍗','🧀','🍣','🍜','🍩','☕',
            '🍌','🍍','🍹','🍷','🍵','🥃','💧','🧃','🥛',
            '🍊','🍋','🍒','🥐','🥖','🧁'
        ],
        travel: [
            '⛺','🚗','🚆','🛫','🏍','🚲','⛵','🚀','🚌','🚁',
            '🚂','🛳','🏖','🗺','🧳','🏔','🌋','🗼','🗽','🎡',
            '🌴'
        ],
        sport: [
            '⚽','🎾','🏓','🏀','🏉','🥊','⚾','🏎','🎣',
            '⛸','🛼','🛹','⛳','⛷','🏊','🏋','🏸','🤾','🏒','🧗','🏄','🎯','🏹','🎳','🎱','♟','🃏','🎲','🎮','🏅','🏆'
        ]
    };

    function TextEditEmojiPicker(container, editor) {
        this.container = container;
        this.editor = editor;
        this.modal = container.querySelector('.textedit-emoji-modal');
        this.grid = this.modal.querySelector('.textedit-emoji-grid');
        this.tabs = this.modal.querySelectorAll('.textedit-emoji-tab');
        this.currentCategory = 'smileys';
        this._renderGrid();
        this._bindEvents();
    }

    TextEditEmojiPicker.prototype._bindEvents = function() {
        var self = this;
        var overlay = this.modal.querySelector('.textedit-modal-overlay');
        var closeBtn = this.modal.querySelector('.textedit-modal-close');

        overlay.addEventListener('click', function() { self.hide(); });
        closeBtn.addEventListener('click', function() { self.hide(); });

        // Tab switching
        for (var i = 0; i < this.tabs.length; i++) {
            this.tabs[i].addEventListener('click', function() {
                var cat = this.getAttribute('data-category');
                self._switchCategory(cat);
            });
        }

        // Emoji click
        this.grid.addEventListener('click', function(e) {
            var item = e.target.closest('.textedit-emoji-item');
            if (!item) return;
            self.hide();
            restoreSelection();
            document.execCommand('insertText', false, item.textContent);
            self.editor.syncToTextarea();
        });
    };

    TextEditEmojiPicker.prototype._switchCategory = function(category) {
        this.currentCategory = category;
        for (var i = 0; i < this.tabs.length; i++) {
            if (this.tabs[i].getAttribute('data-category') === category) {
                this.tabs[i].classList.add('active');
            } else {
                this.tabs[i].classList.remove('active');
            }
        }
        this._renderGrid();
    };

    TextEditEmojiPicker.prototype._renderGrid = function() {
        var emojis = EMOJIS[this.currentCategory] || [];
        var html = '';
        for (var i = 0; i < emojis.length; i++) {
            html += '<button type="button" class="textedit-emoji-item">' + emojis[i] + '</button>';
        }
        this.grid.innerHTML = html;
    };

    TextEditEmojiPicker.prototype.show = function() {
        this.modal.style.display = 'flex';
    };

    TextEditEmojiPicker.prototype.hide = function() {
        this.modal.style.display = 'none';
    };

    /* ======================================================================
       TextEditBulletPicker
       Gère le dropdown de sélection du type de puces / listes.
       Propose 5 types : disc (•), circle (○), square (■), dash (—), ordered (1.)
       ====================================================================== */

    function TextEditBulletPicker(container, editor) {
        this.container = container;
        this.editor = editor;
        this.dropdown = container.querySelector('[data-dropdown="bullets"]');
        this.panel = this.dropdown.querySelector('.textedit-bullet-panel');
        this._bindEvents();
    }

    TextEditBulletPicker.prototype._bindEvents = function() {
        var self = this;

        /* Clic sur une option de puce dans le dropdown */
        this.panel.addEventListener('click', function(event) {
            var bulletOption = event.target.closest('.textedit-bullet-option');
            if (!bulletOption) return;

            var bulletType = bulletOption.getAttribute('data-bullet');
            self.hide();
            restoreSelection();
            self._applyBulletType(bulletType);
            self.editor.syncToTextarea();
        });
    };

    /**
     * Applique le type de puce sélectionné au texte courant.
     * - disc, circle, square : crée une liste <ul> avec le style CSS correspondant
     * - dash : crée une liste <ul> avec list-style-type: none et préfixe "— "
     * - ordered : crée une liste <ol> numérotée
     */
    TextEditBulletPicker.prototype._applyBulletType = function(bulletType) {
        if (bulletType === 'ordered') {
            /* Liste numérotée : on utilise la commande native insertOrderedList */
            document.execCommand('insertOrderedList', false, null);
            /* Applique le style list-style-type: decimal à la liste créée */
            this._styleCurrentList('ol', 'decimal');
        } else if (bulletType === 'dash') {
            /* Tiret : on crée une liste sans puce et on préfixe chaque <li> avec "— " */
            document.execCommand('insertUnorderedList', false, null);
            this._styleCurrentList('ul', 'none');
            this._prefixListItemsWithDash();
        } else {
            /* disc, circle, square : liste non ordonnée avec le style CSS correspondant */
            document.execCommand('insertUnorderedList', false, null);
            this._styleCurrentList('ul', bulletType);
        }
    };

    /**
     * Trouve la liste (<ul> ou <ol>) contenant la sélection courante
     * et lui applique le style list-style-type demandé.
     */
    TextEditBulletPicker.prototype._styleCurrentList = function(tagName, styleType) {
        var selection = window.getSelection();
        if (!selection.rangeCount) return;

        /* Remonte dans le DOM depuis le noeud sélectionné pour trouver la liste */
        var currentNode = selection.anchorNode;
        while (currentNode && currentNode !== this.editor.editorEl) {
            if (currentNode.nodeName && currentNode.nodeName.toLowerCase() === tagName) {
                currentNode.style.listStyleType = styleType;
                return;
            }
            currentNode = currentNode.parentNode;
        }

        /* Si on ne trouve pas en remontant, cherche la dernière liste dans l'éditeur */
        var allLists = this.container.querySelector('.textedit-editor').querySelectorAll(tagName);
        if (allLists.length > 0) {
            allLists[allLists.length - 1].style.listStyleType = styleType;
        }
    };

    /**
     * Ajoute le préfixe "— " au début du texte de chaque <li> de la dernière
     * liste <ul> qui a list-style-type: none (pour le style tiret).
     */
    TextEditBulletPicker.prototype._prefixListItemsWithDash = function() {
        var editorElement = this.container.querySelector('.textedit-editor');
        var allLists = editorElement.querySelectorAll('ul[style*="list-style-type: none"]');
        if (allLists.length === 0) return;

        var lastList = allLists[allLists.length - 1];
        var listItems = lastList.querySelectorAll('li');
        for (var idx = 0; idx < listItems.length; idx++) {
            var itemText = listItems[idx].textContent;
            /* Évite de doubler le tiret si déjà présent */
            if (itemText.indexOf('— ') !== 0) {
                listItems[idx].textContent = '— ' + itemText;
            }
        }
    };

    TextEditBulletPicker.prototype.toggle = function() {
        if (this.panel.style.display === 'none') {
            this.show();
        } else {
            this.hide();
        }
    };

    TextEditBulletPicker.prototype.show = function() {
        this.panel.style.display = 'flex';
    };

    TextEditBulletPicker.prototype.hide = function() {
        this.panel.style.display = 'none';
    };

    /* ======================================================================
       TextEditImageResizer
       Gère le redimensionnement proportionnel des images dans l'éditeur.
       Affiche 4 poignées aux coins de l'image cliquée. Le glissement
       d'une poignée (souris ou tactile) redimensionne largeur ET hauteur
       en conservant le ratio d'aspect original.
       ====================================================================== */

    function TextEditImageResizer(container, editor) {
        this.container = container;
        this.editor = editor;
        this.editorEl = container.querySelector('.textedit-editor');
        /* Référence vers l'image actuellement sélectionnée */
        this.activeImage = null;
        /* Wrapper <span> contenant l'image et les poignées */
        this.wrapper = null;
        /* Ratio d'aspect original (largeur / hauteur) */
        this.aspectRatio = 1;
        /* Dimensions et position au début du glissement */
        this.startWidth = 0;
        this.startHeight = 0;
        this.startX = 0;
        this.startY = 0;
        /* Identifiant du coin en cours de glissement (nw, ne, sw, se) */
        this.activeHandle = null;

        this._onMouseDown = this._onMouseDown.bind(this);
        this._onMouseMove = this._onMouseMove.bind(this);
        this._onMouseUp = this._onMouseUp.bind(this);
        this._onTouchStart = this._onTouchStart.bind(this);
        this._onTouchMove = this._onTouchMove.bind(this);
        this._onTouchEnd = this._onTouchEnd.bind(this);

        this._bindEvents();
    }

    /**
     * Écoute les clics sur les images dans l'éditeur pour afficher les poignées,
     * et les clics en dehors pour les masquer.
     */
    TextEditImageResizer.prototype._bindEvents = function() {
        var self = this;

        /* Clic sur une image dans l'éditeur → afficher les poignées */
        this.editorEl.addEventListener('click', function(event) {
            if (event.target.tagName === 'IMG') {
                event.preventDefault();
                self._selectImage(event.target);
            } else if (!event.target.closest('.textedit-resize-wrapper')) {
                /* Clic en dehors d'un wrapper → désélectionner */
                self._deselectImage();
            }
        });

        /* Clic en dehors de l'éditeur → désélectionner */
        document.addEventListener('mousedown', function(event) {
            if (!self.editorEl.contains(event.target)) {
                self._deselectImage();
            }
        });
    };

    /**
     * Sélectionne une image : crée le wrapper avec les 4 poignées autour.
     * Si une autre image était déjà sélectionnée, on la désélectionne d'abord.
     */
    TextEditImageResizer.prototype._selectImage = function(img) {
        /* Évite de re-sélectionner la même image */
        if (this.activeImage === img) return;

        /* Désélectionne l'image précédente si besoin */
        this._deselectImage();

        this.activeImage = img;

        /* Calcule le ratio d'aspect original de l'image */
        var currentWidth = img.offsetWidth || img.naturalWidth || 200;
        var currentHeight = img.offsetHeight || img.naturalHeight || 200;
        this.aspectRatio = currentWidth / currentHeight;

        /* Crée le wrapper <span> autour de l'image */
        this.wrapper = document.createElement('span');
        this.wrapper.className = 'textedit-resize-wrapper';
        this.wrapper.contentEditable = 'false';
        img.parentNode.insertBefore(this.wrapper, img);
        this.wrapper.appendChild(img);

        /* Crée les 4 poignées aux coins */
        var handles = ['nw', 'ne', 'sw', 'se'];
        for (var idx = 0; idx < handles.length; idx++) {
            var handle = document.createElement('span');
            handle.className = 'textedit-resize-handle';
            handle.setAttribute('data-handle', handles[idx]);
            handle.contentEditable = 'false';

            /* Événements souris */
            handle.addEventListener('mousedown', this._onMouseDown);

            /* Événements tactiles */
            handle.addEventListener('touchstart', this._onTouchStart, { passive: false });

            this.wrapper.appendChild(handle);
        }
    };

    /**
     * Désélectionne l'image active : retire le wrapper et les poignées,
     * remet l'image directement dans le DOM.
     */
    TextEditImageResizer.prototype._deselectImage = function() {
        if (!this.wrapper || !this.activeImage) return;

        var img = this.activeImage;
        var parent = this.wrapper.parentNode;
        if (parent) {
            parent.insertBefore(img, this.wrapper);
            parent.removeChild(this.wrapper);
        }

        this.wrapper = null;
        this.activeImage = null;
        this.editor.syncToTextarea();
    };

    /**
     * Début du glissement par souris sur une poignée.
     * Enregistre les dimensions initiales et attache les listeners de mouvement.
     */
    TextEditImageResizer.prototype._onMouseDown = function(event) {
        event.preventDefault();
        event.stopPropagation();

        this.activeHandle = event.target.getAttribute('data-handle');
        this.startX = event.clientX;
        this.startY = event.clientY;
        this.startWidth = this.activeImage.offsetWidth;
        this.startHeight = this.activeImage.offsetHeight;

        document.addEventListener('mousemove', this._onMouseMove);
        document.addEventListener('mouseup', this._onMouseUp);
    };

    /**
     * Mouvement de la souris pendant le glissement.
     * Calcule les nouvelles dimensions en maintenant le ratio d'aspect.
     */
    TextEditImageResizer.prototype._onMouseMove = function(event) {
        if (!this.activeHandle) return;
        event.preventDefault();

        var deltaX = event.clientX - this.startX;
        var deltaY = event.clientY - this.startY;

        this._applyResize(deltaX, deltaY);
    };

    /**
     * Fin du glissement par souris.
     * Détache les listeners et synchronise le textarea.
     */
    TextEditImageResizer.prototype._onMouseUp = function(event) {
        if (!this.activeHandle) return;
        event.preventDefault();

        this.activeHandle = null;
        document.removeEventListener('mousemove', this._onMouseMove);
        document.removeEventListener('mouseup', this._onMouseUp);

        this.editor.syncToTextarea();
    };

    /**
     * Début du glissement tactile sur une poignée.
     */
    TextEditImageResizer.prototype._onTouchStart = function(event) {
        event.preventDefault();
        event.stopPropagation();

        var touch = event.touches[0];
        this.activeHandle = event.target.getAttribute('data-handle');
        this.startX = touch.clientX;
        this.startY = touch.clientY;
        this.startWidth = this.activeImage.offsetWidth;
        this.startHeight = this.activeImage.offsetHeight;

        document.addEventListener('touchmove', this._onTouchMove, { passive: false });
        document.addEventListener('touchend', this._onTouchEnd);
    };

    /**
     * Mouvement tactile pendant le glissement.
     */
    TextEditImageResizer.prototype._onTouchMove = function(event) {
        if (!this.activeHandle) return;
        event.preventDefault();

        var touch = event.touches[0];
        var deltaX = touch.clientX - this.startX;
        var deltaY = touch.clientY - this.startY;

        this._applyResize(deltaX, deltaY);
    };

    /**
     * Fin du glissement tactile.
     */
    TextEditImageResizer.prototype._onTouchEnd = function(event) {
        if (!this.activeHandle) return;

        this.activeHandle = null;
        document.removeEventListener('touchmove', this._onTouchMove);
        document.removeEventListener('touchend', this._onTouchEnd);

        this.editor.syncToTextarea();
    };

    /**
     * Applique le redimensionnement proportionnel à l'image.
     * Le delta principal est choisi en fonction du coin tiré :
     * - nw/sw : la largeur diminue quand on tire vers la droite
     * - ne/se : la largeur augmente quand on tire vers la droite
     * La hauteur est toujours calculée à partir du ratio d'aspect.
     * Une taille minimale de 20px est imposée.
     */
    TextEditImageResizer.prototype._applyResize = function(deltaX, deltaY) {
        var newWidth;

        /* Calcul de la nouvelle largeur selon le coin tiré */
        switch (this.activeHandle) {
            case 'se':
                /* Coin bas-droite : agrandit vers la droite et le bas */
                newWidth = this.startWidth + deltaX;
                break;
            case 'sw':
                /* Coin bas-gauche : agrandit vers la gauche et le bas */
                newWidth = this.startWidth - deltaX;
                break;
            case 'ne':
                /* Coin haut-droite : agrandit vers la droite et le haut */
                newWidth = this.startWidth + deltaX;
                break;
            case 'nw':
                /* Coin haut-gauche : agrandit vers la gauche et le haut */
                newWidth = this.startWidth - deltaX;
                break;
            default:
                return;
        }

        /* Impose une taille minimale de 20px */
        if (newWidth < 20) newWidth = 20;

        /* Calcule la hauteur proportionnelle à partir du ratio d'aspect */
        var newHeight = Math.round(newWidth / this.aspectRatio);
        if (newHeight < 20) {
            newHeight = 20;
            newWidth = Math.round(newHeight * this.aspectRatio);
        }

        /* Applique les nouvelles dimensions à l'image */
        this.activeImage.style.width = newWidth + 'px';
        this.activeImage.style.height = newHeight + 'px';
        this.activeImage.setAttribute('width', newWidth);
        this.activeImage.setAttribute('height', newHeight);
    };

    /* ======================================================================
       TextEditToolbar
       ====================================================================== */

    function TextEditToolbar(container, editor) {
        this.container = container;
        this.editor = editor;
        this.colorPicker = new TextEditColorPicker(container, editor);
        this.bulletPicker = new TextEditBulletPicker(container, editor);
        this.imageHandler = new TextEditImageHandler(container, editor);
        this.emojiPicker = new TextEditEmojiPicker(container, editor);
        this.highlightActive = false;
        this._bindEvents();
    }

    TextEditToolbar.prototype._bindEvents = function() {
        var self = this;
        var toolbar = this.container.querySelector('.textedit-toolbar');

        toolbar.addEventListener('mousedown', function(e) {
            // Prevent toolbar clicks from stealing focus/selection from editor
            var btn = e.target.closest('.textedit-btn');
            if (btn) {
                e.preventDefault();
            }
        });

        toolbar.addEventListener('click', function(e) {
            var btn = e.target.closest('.textedit-btn');
            if (!btn) return;

            var action = btn.getAttribute('data-action');
            if (!action) return;

            self._executeAction(action);
        });

        // Ferme les dropdowns (couleur et puces) quand on clique en dehors
        document.addEventListener('click', function(e) {
            if (!self.container.querySelector('[data-dropdown="color"]').contains(e.target)) {
                self.colorPicker.hide();
            }
            if (!self.container.querySelector('[data-dropdown="bullets"]').contains(e.target)) {
                self.bulletPicker.hide();
            }
        });
    };

    TextEditToolbar.prototype._executeAction = function(action) {
        switch (action) {
            case 'bold':
                document.execCommand('bold', false, null);
                this.editor.syncToTextarea();
                break;
            case 'italic':
                document.execCommand('italic', false, null);
                this.editor.syncToTextarea();
                break;
            case 'underline':
                document.execCommand('underline', false, null);
                this.editor.syncToTextarea();
                break;
            case 'uppercase':
                this._applyUppercase();
                break;
            case 'highlight':
                this._toggleHighlight();
                break;
            case 'showBulletPicker':
                saveSelection();
                this.bulletPicker.toggle();
                break;
            case 'showColorPicker':
                saveSelection();
                this.colorPicker.toggle();
                break;
            case 'justifyCenter':
                document.execCommand('justifyCenter', false, null);
                this.editor.syncToTextarea();
                break;
            case 'justifyLeft':
                document.execCommand('justifyLeft', false, null);
                this.editor.syncToTextarea();
                break;
            case 'insertImage':
                saveSelection();
                this.imageHandler.show();
                break;
            case 'insertEmoji':
                saveSelection();
                this.emojiPicker.show();
                break;
        }
        this.updateButtonStates();
    };

    /**
     * Transforme le texte sélectionné en MAJUSCULES.
     * Utilise toUpperCase() de JavaScript qui gère nativement les caractères
     * accentués français : é→É, ç→Ç, û→Û, à→À, ê→Ê, etc.
     */
    TextEditToolbar.prototype._applyUppercase = function() {
        var selection = window.getSelection();
        if (!selection.rangeCount || selection.isCollapsed) return;

        var range = selection.getRangeAt(0);
        var selectedText = range.toString();

        /* Conversion en majuscules (gère les accents nativement) */
        var uppercasedText = selectedText.toUpperCase();

        /* Supprime le texte sélectionné et insère la version en majuscules */
        range.deleteContents();
        var textNode = document.createTextNode(uppercasedText);
        range.insertNode(textNode);

        /* Replace le curseur après le texte inséré */
        range.setStartAfter(textNode);
        range.setEndAfter(textNode);
        selection.removeAllRanges();
        selection.addRange(range);

        this.editor.syncToTextarea();
    };

    TextEditToolbar.prototype._toggleHighlight = function() {
        if (this.highlightActive) {
            document.execCommand('hiliteColor', false, 'transparent');
            this.highlightActive = false;
        } else {
            document.execCommand('hiliteColor', false, '#ffeb3b');
            this.highlightActive = true;
        }
        this.editor.syncToTextarea();
    };

    TextEditToolbar.prototype.updateButtonStates = function() {
        var buttons = this.container.querySelectorAll('.textedit-btn[data-action]');
        for (var i = 0; i < buttons.length; i++) {
            var action = buttons[i].getAttribute('data-action');
            var isActive = false;
            switch (action) {
                case 'bold':
                    isActive = document.queryCommandState('bold');
                    break;
                case 'italic':
                    isActive = document.queryCommandState('italic');
                    break;
                case 'underline':
                    isActive = document.queryCommandState('underline');
                    break;
                case 'highlight':
                    isActive = this.highlightActive;
                    break;
            }
            if (isActive) {
                buttons[i].classList.add('active');
            } else {
                buttons[i].classList.remove('active');
            }
        }
    };

    /* ======================================================================
       TextEditEditor (main orchestrator)
       ====================================================================== */

    function TextEditEditor(container) {
        this.container = container;
        this.editorEl = container.querySelector('.textedit-editor');
        this.textareaEl = container.querySelector('.textedit-textarea');
        this.toolbar = new TextEditToolbar(container, this);
        /* Initialise le redimensionnement des images par poignées aux 4 coins */
        this.imageResizer = new TextEditImageResizer(container, this);

        this._initContent();
        this._bindEvents();
    }

    TextEditEditor.prototype._initContent = function() {
        // Load initial content from textarea into contenteditable
        var initialContent = this.textareaEl.value;
        if (initialContent) {
            this.editorEl.innerHTML = initialContent;
        }
    };

    TextEditEditor.prototype._bindEvents = function() {
        var self = this;

        // Sync on input
        this.editorEl.addEventListener('input', function() {
            self.syncToTextarea();
        });

        // Update button states on selection change
        this.editorEl.addEventListener('keyup', function() {
            self.toolbar.updateButtonStates();
        });
        this.editorEl.addEventListener('mouseup', function() {
            self.toolbar.updateButtonStates();
        });

        // Save selection when editor loses focus
        this.editorEl.addEventListener('blur', function() {
            saveSelection();
        });

        // Sync before form submission
        var form = this.textareaEl.closest('form');
        if (form) {
            form.addEventListener('submit', function() {
                self.syncToTextarea();
            });
        }
    };

    TextEditEditor.prototype.syncToTextarea = function() {
        this.textareaEl.value = this.editorEl.innerHTML;
    };

    /* ======================================================================
       Auto-initialization
       ====================================================================== */

    function initAll() {
        var containers = document.querySelectorAll('.textedit-container');
        for (var i = 0; i < containers.length; i++) {
            if (!containers[i]._texteditInit) {
                containers[i]._texteditInit = true;
                new TextEditEditor(containers[i]);
            }
        }
    }

    // Init on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAll);
    } else {
        initAll();
    }

    // Expose for programmatic use
    window.TextEditEditor = TextEditEditor;

})();
