from django import forms
from django.test import TestCase

from textedit.forms import TextEditFormField
from textedit.widgets import TextEditWidget


class TextEditFormFieldTest(TestCase):

    def test_uses_textedit_widget(self):
        field = TextEditFormField()
        self.assertIsInstance(field.widget, TextEditWidget)

    def test_clean_sanitizes_html(self):
        field = TextEditFormField(required=False)
        result = field.clean('<p>Hello</p><script>alert(1)</script>')
        self.assertNotIn('<script>', result)
        self.assertIn('<p>', result)

    def test_clean_no_sanitize(self):
        field = TextEditFormField(required=False, sanitize=False)
        raw = '<script>alert(1)</script>'
        result = field.clean(raw)
        self.assertEqual(result, raw)

    def test_clean_empty(self):
        field = TextEditFormField(required=False)
        result = field.clean('')
        self.assertEqual(result, '')

    def test_required_validation(self):
        field = TextEditFormField(required=True)
        with self.assertRaises(forms.ValidationError):
            field.clean('')


class TextEditFormFieldInFormTest(TestCase):

    def test_form_integration(self):
        class TestForm(forms.Form):
            content = TextEditFormField(required=False)

        form = TestForm(data={'content': '<p>Test</p><script>x</script>'})
        self.assertTrue(form.is_valid())
        self.assertNotIn('<script>', form.cleaned_data['content'])
        self.assertIn('<p>', form.cleaned_data['content'])

    def test_form_widget_render(self):
        class TestForm(forms.Form):
            content = TextEditFormField()

        form = TestForm()
        html = str(form)
        self.assertIn('textedit-container', html)
