import os
import shutil
import tempfile

from django import forms
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings

from textedit.forms import TextEditFormField
from textedit.sanitizers import sanitize_html
from textedit.validators import validate_uploaded_image
from textedit.widgets import TextEditWidget

TEMP_MEDIA = tempfile.mkdtemp()


class WidgetFormIntegrationTest(TestCase):
    """Test that widgets, forms and sanitizers work together."""

    def test_form_field_renders_widget(self):
        class MyForm(forms.Form):
            body = TextEditFormField()

        form = MyForm()
        html = str(form)
        self.assertIn('textedit-container', html)
        self.assertIn('textedit-toolbar', html)
        self.assertIn('contenteditable="true"', html)

    def test_form_submit_with_xss_content(self):
        class MyForm(forms.Form):
            body = TextEditFormField(required=False)

        xss_payloads = [
            '<script>alert("xss")</script>',
            '<img src=x onerror="alert(1)">',
            '<a href="javascript:alert(1)">click</a>',
            '<div onclick="alert(1)">click</div>',
            '<p style="color: expression(alert(1))">test</p>',
        ]

        for payload in xss_payloads:
            form = MyForm(data={'body': payload})
            self.assertTrue(form.is_valid(), f"Form invalid for: {payload}")
            cleaned = form.cleaned_data['body']
            self.assertNotIn('<script', cleaned, f"Script not stripped for: {payload}")
            self.assertNotIn('onerror', cleaned, f"onerror not stripped for: {payload}")
            self.assertNotIn('javascript:', cleaned, f"javascript: not stripped for: {payload}")
            self.assertNotIn('onclick', cleaned, f"onclick not stripped for: {payload}")
            self.assertNotIn('expression(', cleaned, f"expression not stripped for: {payload}")

    def test_form_preserves_safe_html(self):
        class MyForm(forms.Form):
            body = TextEditFormField(required=False)

        safe_html = (
            '<p style="text-align: center">'
            '<em>Hello</em> <u>World</u>'
            '</p>'
            '<img src="/media/img.jpg" alt="test">'
        )
        form = MyForm(data={'body': safe_html})
        self.assertTrue(form.is_valid())
        cleaned = form.cleaned_data['body']
        self.assertIn('<em>', cleaned)
        self.assertIn('<u>', cleaned)
        self.assertIn('<img', cleaned)
        self.assertIn('text-align: center', cleaned)


@override_settings(MEDIA_ROOT=TEMP_MEDIA)
class UploadIntegrationTest(TestCase):
    """Test the complete upload flow."""

    url = '/textedit/upload/'

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        shutil.rmtree(TEMP_MEDIA, ignore_errors=True)

    def test_upload_then_use_in_form(self):
        """Upload an image, then use its URL in a form submission."""
        # 1. Upload image
        content = b'\xff\xd8\xff\xe0' + b'\x00' * 200
        f = SimpleUploadedFile('test.jpg', content, content_type='image/jpeg')
        response = self.client.post(self.url, {'image': f})
        self.assertEqual(response.status_code, 200)
        img_url = response.json()['url']

        # 2. Use URL in form content
        class MyForm(forms.Form):
            body = TextEditFormField(required=False)

        html_content = f'<p>Check this image:</p><img src="{img_url}" alt="test">'
        form = MyForm(data={'body': html_content})
        self.assertTrue(form.is_valid())
        cleaned = form.cleaned_data['body']
        self.assertIn('<img', cleaned)
        self.assertIn(img_url, cleaned)


class SanitizeCombinedTest(TestCase):
    """Test combined sanitization scenarios."""

    def test_nested_xss_in_style(self):
        html = '<span style="background: url(javascript:alert(1)); color: red">X</span>'
        result = sanitize_html(html)
        self.assertNotIn('javascript:', result)
        self.assertIn('color: red', result)

    def test_mixed_valid_and_invalid_content(self):
        html = (
            '<p>Good paragraph</p>'
            '<script>alert(1)</script>'
            '<em>Emphasis</em>'
            '<iframe src="evil"></iframe>'
            '<span style="color: blue">Blue</span>'
        )
        result = sanitize_html(html)
        self.assertIn('<p>', result)
        self.assertIn('<em>', result)
        self.assertIn('color: blue', result)
        self.assertNotIn('<script', result)
        self.assertNotIn('<iframe', result)
