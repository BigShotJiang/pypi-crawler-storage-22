from django.test import TestCase

from textedit.models import RichTextField
from textedit.widgets import TextEditWidget


class RichTextFieldTest(TestCase):

    def test_formfield_uses_textedit_widget(self):
        field = RichTextField()
        form_field = field.formfield()
        self.assertIsInstance(form_field.widget, TextEditWidget)

    def test_deconstruct_default(self):
        field = RichTextField()
        _, _, _, kwargs = field.deconstruct()
        self.assertNotIn('sanitize', kwargs)

    def test_deconstruct_sanitize_false(self):
        field = RichTextField(sanitize=False)
        _, _, _, kwargs = field.deconstruct()
        self.assertFalse(kwargs['sanitize'])

    def test_pre_save_sanitizes_html(self):
        """Test that pre_save sanitizes content with script tags."""
        field = RichTextField()
        field.attname = 'content'

        class FakeModel:
            content = '<p>Hello</p><script>alert("xss")</script>'

        instance = FakeModel()
        result = field.pre_save(instance, add=True)
        self.assertNotIn('<script>', result)
        self.assertIn('<p>', result)

    def test_pre_save_no_sanitize(self):
        """Test that pre_save skips sanitization when sanitize=False."""
        field = RichTextField(sanitize=False)
        field.attname = 'content'

        class FakeModel:
            content = '<script>alert("xss")</script>'

        instance = FakeModel()
        result = field.pre_save(instance, add=True)
        # Content is preserved as-is since sanitize=False
        self.assertEqual(result, '<script>alert("xss")</script>')

    def test_pre_save_empty_value(self):
        field = RichTextField()
        field.attname = 'content'

        class FakeModel:
            content = ''

        instance = FakeModel()
        result = field.pre_save(instance, add=True)
        self.assertEqual(result, '')
