from django.test import TestCase

from textedit.sanitizers import sanitize_html


class SanitizeHtmlBasicTest(TestCase):

    def test_empty_string(self):
        self.assertEqual(sanitize_html(''), '')

    def test_none_input(self):
        self.assertEqual(sanitize_html(None), '')

    def test_plain_text(self):
        result = sanitize_html('Hello world')
        self.assertEqual(result, 'Hello world')

    def test_allowed_tags_preserved(self):
        html = '<p>Hello <em>world</em></p>'
        result = sanitize_html(html)
        self.assertIn('<p>', result)
        self.assertIn('<em>', result)
        self.assertIn('</em>', result)
        self.assertIn('</p>', result)

    def test_bold_tag(self):
        html = '<strong>bold</strong>'
        result = sanitize_html(html)
        self.assertIn('<strong>', result)

    def test_underline_tag(self):
        html = '<u>underlined</u>'
        result = sanitize_html(html)
        self.assertIn('<u>', result)

    def test_br_preserved(self):
        html = 'line1<br>line2'
        result = sanitize_html(html)
        self.assertIn('<br>', result)

    def test_img_preserved(self):
        html = '<img src="/media/photo.jpg" alt="Photo">'
        result = sanitize_html(html)
        self.assertIn('<img', result)
        self.assertIn('src="/media/photo.jpg"', result)
        self.assertIn('alt="Photo"', result)


class SanitizeHtmlXSSTest(TestCase):

    def test_script_tag_stripped(self):
        html = '<p>Hello</p><script>alert("XSS")</script>'
        result = sanitize_html(html)
        self.assertNotIn('<script', result)
        self.assertNotIn('alert', result)

    def test_iframe_stripped(self):
        html = '<iframe src="evil.com"></iframe>'
        result = sanitize_html(html)
        self.assertNotIn('<iframe', result)

    def test_onerror_attribute_stripped(self):
        html = '<img src="x" onerror="alert(1)">'
        result = sanitize_html(html)
        self.assertNotIn('onerror', result)

    def test_onclick_attribute_stripped(self):
        html = '<p onclick="alert(1)">Click</p>'
        result = sanitize_html(html)
        self.assertNotIn('onclick', result)

    def test_javascript_href_stripped(self):
        html = '<a href="javascript:alert(1)">Link</a>'
        result = sanitize_html(html)
        self.assertNotIn('javascript:', result)

    def test_vbscript_href_stripped(self):
        html = '<a href="vbscript:alert(1)">Link</a>'
        result = sanitize_html(html)
        self.assertNotIn('vbscript:', result)

    def test_data_href_stripped(self):
        html = '<a href="data:text/html,<script>alert(1)</script>">Link</a>'
        result = sanitize_html(html)
        self.assertNotIn('data:', result)

    def test_javascript_src_stripped(self):
        html = '<img src="javascript:alert(1)">'
        result = sanitize_html(html)
        self.assertNotIn('javascript:', result)

    def test_data_image_src_allowed(self):
        html = '<img src="data:image/png;base64,abc">'
        result = sanitize_html(html)
        self.assertIn('data:image/png', result)


class SanitizeHtmlStyleTest(TestCase):

    def test_allowed_css_preserved(self):
        html = '<span style="color: red">Red</span>'
        result = sanitize_html(html)
        self.assertIn('color: red', result)

    def test_background_color_preserved(self):
        html = '<span style="background-color: yellow">Hi</span>'
        result = sanitize_html(html)
        self.assertIn('background-color: yellow', result)

    def test_text_align_preserved(self):
        html = '<p style="text-align: center">Centered</p>'
        result = sanitize_html(html)
        self.assertIn('text-align: center', result)

    def test_css_expression_stripped(self):
        html = '<span style="color: expression(alert(1))">X</span>'
        result = sanitize_html(html)
        self.assertNotIn('expression', result)

    def test_css_url_stripped(self):
        html = '<span style="background: url(evil.js)">X</span>'
        result = sanitize_html(html)
        self.assertNotIn('url(', result)

    def test_disallowed_css_property_stripped(self):
        html = '<span style="position: absolute; color: red">X</span>'
        result = sanitize_html(html)
        self.assertNotIn('position', result)
        self.assertIn('color: red', result)


class SanitizeHtmlListTest(TestCase):
    """Tests pour vérifier que les listes HTML sont correctement préservées par le sanitizer."""

    def test_unordered_list_preserved(self):
        """Vérifie qu'une liste non ordonnée <ul><li> passe le sanitizer."""
        html = '<ul><li>Premier</li><li>Deuxième</li></ul>'
        result = sanitize_html(html)
        self.assertIn('<ul>', result)
        self.assertIn('<li>', result)
        self.assertIn('Premier', result)

    def test_ordered_list_preserved(self):
        """Vérifie qu'une liste ordonnée <ol><li> passe le sanitizer."""
        html = '<ol><li>Un</li><li>Deux</li></ol>'
        result = sanitize_html(html)
        self.assertIn('<ol>', result)
        self.assertIn('<li>', result)

    def test_list_style_type_disc_preserved(self):
        """Vérifie que list-style-type: disc est conservé (puces rondes pleines •)."""
        html = '<ul style="list-style-type: disc"><li>Item</li></ul>'
        result = sanitize_html(html)
        self.assertIn('list-style-type: disc', result)

    def test_list_style_type_circle_preserved(self):
        """Vérifie que list-style-type: circle est conservé (puces rondes vides ○)."""
        html = '<ul style="list-style-type: circle"><li>Item</li></ul>'
        result = sanitize_html(html)
        self.assertIn('list-style-type: circle', result)

    def test_list_style_type_square_preserved(self):
        """Vérifie que list-style-type: square est conservé (puces carrées ■)."""
        html = '<ul style="list-style-type: square"><li>Item</li></ul>'
        result = sanitize_html(html)
        self.assertIn('list-style-type: square', result)

    def test_list_style_type_decimal_preserved(self):
        """Vérifie que list-style-type: decimal est conservé (liste numérotée 1.)."""
        html = '<ol style="list-style-type: decimal"><li>Item</li></ol>'
        result = sanitize_html(html)
        self.assertIn('list-style-type: decimal', result)

    def test_list_style_type_custom_dash(self):
        """Vérifie que le tiret inséré comme contenu de <li> passe le sanitizer."""
        html = '<ul style="list-style-type: none"><li>— Item avec tiret</li></ul>'
        result = sanitize_html(html)
        self.assertIn('list-style-type: none', result)
        self.assertIn('—', result)


class SanitizeHtmlAttributeTest(TestCase):

    def test_allowed_a_attributes(self):
        html = '<a href="https://example.com" title="Example" target="_blank">Link</a>'
        result = sanitize_html(html)
        self.assertIn('href="https://example.com"', result)
        self.assertIn('title="Example"', result)
        self.assertIn('target="_blank"', result)

    def test_disallowed_attributes_stripped(self):
        html = '<p class="foo" id="bar" data-x="baz">Text</p>'
        result = sanitize_html(html)
        self.assertNotIn('class=', result)
        self.assertNotIn('id=', result)
        self.assertNotIn('data-x=', result)
        self.assertIn('<p>', result)

    def test_img_dimensions_preserved(self):
        html = '<img src="/img.jpg" width="100" height="50">'
        result = sanitize_html(html)
        self.assertIn('width="100"', result)
        self.assertIn('height="50"', result)


class SanitizeHtmlImageResizeTest(TestCase):
    """Tests pour vérifier que les images redimensionnées par les poignées
    conservent leurs dimensions après passage dans le sanitizer."""

    def test_img_inline_style_width_height_preserved(self):
        """Vérifie que width/height en style inline sur img sont conservés."""
        html = '<img src="/media/photo.jpg" style="width: 200px; height: 150px">'
        result = sanitize_html(html)
        self.assertIn('width: 200px', result)
        self.assertIn('height: 150px', result)

    def test_img_max_width_preserved(self):
        """Vérifie que max-width sur img est conservé (responsive)."""
        html = '<img src="/media/photo.jpg" style="max-width: 100%">'
        result = sanitize_html(html)
        self.assertIn('max-width: 100%', result)

    def test_img_resized_with_attributes_and_style(self):
        """Vérifie qu'une image avec width/height en attributs ET en style est préservée."""
        html = '<img src="/media/photo.jpg" width="300" height="200" style="width: 300px; height: 200px">'
        result = sanitize_html(html)
        self.assertIn('width="300"', result)
        self.assertIn('height="200"', result)
        self.assertIn('width: 300px', result)
        self.assertIn('height: 200px', result)
