from django.test import TestCase, override_settings

from textedit import settings as te_settings


class TextEditSettingsTest(TestCase):
    """Tests for textedit.settings defaults and overrides."""

    def test_default_allowed_extensions(self):
        self.assertEqual(
            te_settings.TEXTEDIT_ALLOWED_EXTENSIONS,
            ['jpg', 'jpeg', 'png', 'gif', 'webp']
        )

    def test_default_allowed_mime_types(self):
        self.assertEqual(
            te_settings.TEXTEDIT_ALLOWED_MIME_TYPES,
            ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
        )

    def test_default_max_upload_size(self):
        self.assertEqual(te_settings.TEXTEDIT_MAX_UPLOAD_SIZE, 5 * 1024 * 1024)

    def test_default_upload_dir(self):
        self.assertEqual(te_settings.TEXTEDIT_UPLOAD_DIR, 'textedit_uploads')

    def test_default_allowed_tags(self):
        tags = te_settings.TEXTEDIT_ALLOWED_TAGS
        self.assertIn('p', tags)
        self.assertIn('img', tags)
        self.assertIn('span', tags)
        self.assertIn('em', tags)
        self.assertIn('u', tags)
        self.assertNotIn('script', tags)
        self.assertNotIn('iframe', tags)

    def test_default_allowed_attributes(self):
        attrs = te_settings.TEXTEDIT_ALLOWED_ATTRIBUTES
        self.assertIn('*', attrs)
        self.assertIn('style', attrs['*'])
        self.assertIn('img', attrs)
        self.assertIn('src', attrs['img'])

    def test_default_allowed_css_properties(self):
        css = te_settings.TEXTEDIT_ALLOWED_CSS_PROPERTIES
        self.assertIn('color', css)
        self.assertIn('background-color', css)
        self.assertIn('text-align', css)

    @override_settings(TEXTEDIT_MAX_UPLOAD_SIZE=1024)
    def test_override_max_upload_size(self):
        # Re-import to pick up override
        from importlib import reload
        from textedit import settings as ts
        reload(ts)
        self.assertEqual(ts.TEXTEDIT_MAX_UPLOAD_SIZE, 1024)
        # Restore
        reload(ts)

    @override_settings(TEXTEDIT_ALLOWED_EXTENSIONS=['png'])
    def test_override_allowed_extensions(self):
        from importlib import reload
        from textedit import settings as ts
        reload(ts)
        self.assertEqual(ts.TEXTEDIT_ALLOWED_EXTENSIONS, ['png'])
        reload(ts)
