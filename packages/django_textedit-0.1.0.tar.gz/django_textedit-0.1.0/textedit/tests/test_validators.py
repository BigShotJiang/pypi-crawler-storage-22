import io

from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase

from textedit.validators import (
    sanitize_filename,
    validate_image_extension,
    validate_image_magic_bytes,
    validate_image_mime,
    validate_image_size,
    validate_uploaded_image,
)


class ValidateImageExtensionTest(TestCase):

    def test_valid_jpg(self):
        f = SimpleUploadedFile('photo.jpg', b'data', content_type='image/jpeg')
        validate_image_extension(f)  # Should not raise

    def test_valid_jpeg(self):
        f = SimpleUploadedFile('photo.jpeg', b'data', content_type='image/jpeg')
        validate_image_extension(f)

    def test_valid_png(self):
        f = SimpleUploadedFile('image.png', b'data', content_type='image/png')
        validate_image_extension(f)

    def test_valid_gif(self):
        f = SimpleUploadedFile('anim.gif', b'data', content_type='image/gif')
        validate_image_extension(f)

    def test_valid_webp(self):
        f = SimpleUploadedFile('photo.webp', b'data', content_type='image/webp')
        validate_image_extension(f)

    def test_invalid_svg(self):
        f = SimpleUploadedFile('evil.svg', b'data', content_type='image/svg+xml')
        with self.assertRaises(ValidationError):
            validate_image_extension(f)

    def test_invalid_exe(self):
        f = SimpleUploadedFile('malware.exe', b'data', content_type='application/octet-stream')
        with self.assertRaises(ValidationError):
            validate_image_extension(f)

    def test_invalid_html(self):
        f = SimpleUploadedFile('page.html', b'data', content_type='text/html')
        with self.assertRaises(ValidationError):
            validate_image_extension(f)

    def test_case_insensitive(self):
        f = SimpleUploadedFile('photo.JPG', b'data', content_type='image/jpeg')
        validate_image_extension(f)

    def test_double_extension(self):
        f = SimpleUploadedFile('evil.php.jpg', b'data', content_type='image/jpeg')
        validate_image_extension(f)  # .jpg is the actual extension


class ValidateImageMimeTest(TestCase):

    def test_valid_jpeg_mime(self):
        f = SimpleUploadedFile('p.jpg', b'data', content_type='image/jpeg')
        validate_image_mime(f)

    def test_valid_png_mime(self):
        f = SimpleUploadedFile('p.png', b'data', content_type='image/png')
        validate_image_mime(f)

    def test_valid_gif_mime(self):
        f = SimpleUploadedFile('p.gif', b'data', content_type='image/gif')
        validate_image_mime(f)

    def test_valid_webp_mime(self):
        f = SimpleUploadedFile('p.webp', b'data', content_type='image/webp')
        validate_image_mime(f)

    def test_invalid_svg_mime(self):
        f = SimpleUploadedFile('p.svg', b'data', content_type='image/svg+xml')
        with self.assertRaises(ValidationError):
            validate_image_mime(f)

    def test_invalid_text_mime(self):
        f = SimpleUploadedFile('p.jpg', b'data', content_type='text/html')
        with self.assertRaises(ValidationError):
            validate_image_mime(f)


class ValidateImageMagicBytesTest(TestCase):

    def _make_file(self, name, content, content_type):
        return SimpleUploadedFile(name, content, content_type=content_type)

    def test_valid_jpeg(self):
        content = b'\xff\xd8\xff\xe0' + b'\x00' * 100
        f = self._make_file('p.jpg', content, 'image/jpeg')
        validate_image_magic_bytes(f)

    def test_valid_png(self):
        content = b'\x89PNG\r\n\x1a\n' + b'\x00' * 100
        f = self._make_file('p.png', content, 'image/png')
        validate_image_magic_bytes(f)

    def test_valid_gif87a(self):
        content = b'GIF87a' + b'\x00' * 100
        f = self._make_file('p.gif', content, 'image/gif')
        validate_image_magic_bytes(f)

    def test_valid_gif89a(self):
        content = b'GIF89a' + b'\x00' * 100
        f = self._make_file('p.gif', content, 'image/gif')
        validate_image_magic_bytes(f)

    def test_valid_webp(self):
        content = b'RIFF\x00\x00\x00\x00WEBP' + b'\x00' * 100
        f = self._make_file('p.webp', content, 'image/webp')
        validate_image_magic_bytes(f)

    def test_invalid_fake_jpeg(self):
        content = b'GIF89a' + b'\x00' * 100  # GIF content claimed as JPEG
        f = self._make_file('p.jpg', content, 'image/jpeg')
        with self.assertRaises(ValidationError):
            validate_image_magic_bytes(f)

    def test_invalid_fake_png(self):
        content = b'\xff\xd8\xff\xe0' + b'\x00' * 100  # JPEG content claimed as PNG
        f = self._make_file('p.png', content, 'image/png')
        with self.assertRaises(ValidationError):
            validate_image_magic_bytes(f)

    def test_invalid_webp_wrong_body(self):
        content = b'RIFF\x00\x00\x00\x00FAKE' + b'\x00' * 100
        f = self._make_file('p.webp', content, 'image/webp')
        with self.assertRaises(ValidationError):
            validate_image_magic_bytes(f)

    def test_random_bytes(self):
        content = b'\x00\x01\x02\x03' * 30
        f = self._make_file('p.jpg', content, 'image/jpeg')
        with self.assertRaises(ValidationError):
            validate_image_magic_bytes(f)


class ValidateImageSizeTest(TestCase):

    def test_small_file_ok(self):
        f = SimpleUploadedFile('p.jpg', b'\x00' * 1024, content_type='image/jpeg')
        validate_image_size(f)

    def test_exactly_max_size(self):
        from textedit import settings as te_settings
        max_size = te_settings.TEXTEDIT_MAX_UPLOAD_SIZE
        f = SimpleUploadedFile('p.jpg', b'\x00' * max_size, content_type='image/jpeg')
        validate_image_size(f)

    def test_over_max_size(self):
        from textedit import settings as te_settings
        max_size = te_settings.TEXTEDIT_MAX_UPLOAD_SIZE
        f = SimpleUploadedFile('p.jpg', b'\x00' * (max_size + 1), content_type='image/jpeg')
        with self.assertRaises(ValidationError):
            validate_image_size(f)


class SanitizeFilenameTest(TestCase):

    def test_simple_filename(self):
        result = sanitize_filename('photo.jpg')
        self.assertTrue(result.endswith('_photo.jpg'))
        self.assertEqual(len(result.split('_')[0]), 12)  # UUID hex prefix

    def test_strips_directory_components(self):
        result = sanitize_filename('../../etc/passwd')
        self.assertNotIn('..', result)
        self.assertNotIn('/', result)
        self.assertTrue(result.endswith('_passwd'))

    def test_strips_special_characters(self):
        result = sanitize_filename('hello world!@#$.jpg')
        self.assertNotIn('!', result)
        self.assertNotIn('@', result)
        self.assertNotIn('#', result)
        self.assertNotIn('$', result)
        self.assertNotIn(' ', result)

    def test_windows_path_traversal(self):
        result = sanitize_filename('..\\..\\windows\\system32\\config')
        self.assertNotIn('\\', result)
        self.assertNotIn('..', result)


class ValidateUploadedImageTest(TestCase):

    def test_valid_jpeg_passes_all(self):
        content = b'\xff\xd8\xff\xe0' + b'\x00' * 100
        f = SimpleUploadedFile('photo.jpg', content, content_type='image/jpeg')
        validate_uploaded_image(f)  # Should not raise

    def test_invalid_extension_fails_first(self):
        content = b'\xff\xd8\xff\xe0' + b'\x00' * 100
        f = SimpleUploadedFile('photo.svg', content, content_type='image/jpeg')
        with self.assertRaises(ValidationError):
            validate_uploaded_image(f)
