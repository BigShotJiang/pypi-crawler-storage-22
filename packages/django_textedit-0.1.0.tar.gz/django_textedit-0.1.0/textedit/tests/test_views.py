import os
import shutil
import tempfile

from django.conf import settings
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings

TEMP_MEDIA = tempfile.mkdtemp()


@override_settings(MEDIA_ROOT=TEMP_MEDIA)
class UploadImageViewTest(TestCase):

    url = '/textedit/upload/'

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        shutil.rmtree(TEMP_MEDIA, ignore_errors=True)

    def _make_jpeg(self, name='photo.jpg', size=200):
        content = b'\xff\xd8\xff\xe0' + b'\x00' * size
        return SimpleUploadedFile(name, content, content_type='image/jpeg')

    def _make_png(self, name='photo.png', size=200):
        content = b'\x89PNG\r\n\x1a\n' + b'\x00' * size
        return SimpleUploadedFile(name, content, content_type='image/png')

    def test_get_not_allowed(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 405)

    def test_post_no_file(self):
        response = self.client.post(self.url)
        self.assertEqual(response.status_code, 400)
        data = response.json()
        self.assertIn('error', data)

    def test_successful_jpeg_upload(self):
        f = self._make_jpeg()
        response = self.client.post(self.url, {'image': f})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn('url', data)
        self.assertIn('/media/', data['url'])
        self.assertTrue(data['url'].endswith('.jpg'))

    def test_successful_png_upload(self):
        f = self._make_png()
        response = self.client.post(self.url, {'image': f})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn('url', data)

    def test_file_saved_to_disk(self):
        f = self._make_jpeg()
        response = self.client.post(self.url, {'image': f})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        # Extract filename from URL
        url_path = data['url']
        filename = url_path.split('/')[-1]
        full_path = os.path.join(TEMP_MEDIA, 'textedit_uploads', filename)
        self.assertTrue(os.path.exists(full_path))

    def test_reject_invalid_extension(self):
        content = b'\xff\xd8\xff\xe0' + b'\x00' * 200
        f = SimpleUploadedFile('evil.svg', content, content_type='image/jpeg')
        response = self.client.post(self.url, {'image': f})
        self.assertEqual(response.status_code, 400)

    def test_reject_invalid_mime(self):
        content = b'\xff\xd8\xff\xe0' + b'\x00' * 200
        f = SimpleUploadedFile('file.jpg', content, content_type='text/html')
        response = self.client.post(self.url, {'image': f})
        self.assertEqual(response.status_code, 400)

    def test_reject_fake_magic_bytes(self):
        content = b'GIF89a' + b'\x00' * 200  # GIF content claimed as JPEG
        f = SimpleUploadedFile('fake.jpg', content, content_type='image/jpeg')
        response = self.client.post(self.url, {'image': f})
        self.assertEqual(response.status_code, 400)

    def test_reject_oversized_file(self):
        from textedit import settings as te_settings
        max_size = te_settings.TEXTEDIT_MAX_UPLOAD_SIZE
        content = b'\xff\xd8\xff\xe0' + b'\x00' * max_size
        f = SimpleUploadedFile('big.jpg', content, content_type='image/jpeg')
        response = self.client.post(self.url, {'image': f})
        self.assertEqual(response.status_code, 400)

    def test_filename_sanitized_no_path_traversal(self):
        content = b'\xff\xd8\xff\xe0' + b'\x00' * 200
        f = SimpleUploadedFile('../../etc/passwd.jpg', content, content_type='image/jpeg')
        response = self.client.post(self.url, {'image': f})
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertNotIn('..', data['url'])
