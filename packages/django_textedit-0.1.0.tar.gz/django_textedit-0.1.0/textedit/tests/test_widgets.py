from django.test import TestCase

from textedit.widgets import AdminTextEditWidget, TextEditWidget


class TextEditWidgetTest(TestCase):

    def test_render_contains_container(self):
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('textedit-container', html)

    def test_render_contains_toolbar(self):
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('textedit-toolbar', html)

    def test_render_contains_contenteditable(self):
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('contenteditable="true"', html)

    def test_render_contains_textarea(self):
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('name="content"', html)
        self.assertIn('textedit-textarea', html)

    def test_render_contains_image_modal(self):
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('textedit-image-modal', html)

    def test_render_contains_emoji_modal(self):
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('textedit-emoji-modal', html)

    def test_render_with_initial_value(self):
        widget = TextEditWidget()
        html = widget.render('content', '<p>Hello</p>')
        self.assertIn('<p>Hello</p>', html)

    def test_render_with_none_value(self):
        widget = TextEditWidget()
        html = widget.render('content', None)
        self.assertIn('textedit-container', html)

    def test_render_contains_bold_button(self):
        """Vérifie que la toolbar contient un bouton Gras avec data-action='bold'."""
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('data-action="bold"', html)

    def test_render_contains_uppercase_button(self):
        """Vérifie que la toolbar contient un bouton Majuscule avec data-action='uppercase'."""
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('data-action="uppercase"', html)

    def test_render_contains_bullet_dropdown(self):
        """Vérifie que la toolbar contient le dropdown de puces."""
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('data-dropdown="bullets"', html)

    def test_render_contains_bullet_options(self):
        """Vérifie que le dropdown puces contient les différents types de puces."""
        widget = TextEditWidget()
        html = widget.render('content', '')
        # Vérifie la présence des boutons pour chaque type de puce
        self.assertIn('data-bullet="disc"', html)
        self.assertIn('data-bullet="circle"', html)
        self.assertIn('data-bullet="square"', html)
        self.assertIn('data-bullet="dash"', html)
        self.assertIn('data-bullet="ordered"', html)

    def test_render_contains_upload_url(self):
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('data-upload-url=', html)

    def test_media_css(self):
        widget = TextEditWidget()
        media = widget.media
        css = str(media)
        self.assertIn('textedit.css', css)

    def test_media_js(self):
        widget = TextEditWidget()
        media = widget.media
        js = str(media)
        self.assertIn('textedit.js', js)


class AdminTextEditWidgetTest(TestCase):

    def test_admin_media_includes_admin_css(self):
        widget = AdminTextEditWidget()
        css = str(widget.media)
        self.assertIn('textedit-admin.css', css)
        self.assertIn('textedit.css', css)

    def test_renders_same_template(self):
        widget = AdminTextEditWidget()
        html = widget.render('content', '')
        self.assertIn('textedit-container', html)


class TextEditImageResizerTest(TestCase):
    """Tests pour vérifier que le module inclut le redimensionnement d'image par poignées."""

    def test_css_contains_resize_handle_styles(self):
        """Vérifie que le CSS contient les styles pour les poignées de redimensionnement d'image."""
        import os
        css_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            'static', 'textedit', 'css', 'textedit.css'
        )
        with open(css_path) as f:
            css_content = f.read()
        self.assertIn('textedit-resize-handle', css_content)

    def test_css_contains_resize_wrapper_styles(self):
        """Vérifie que le CSS contient les styles pour le wrapper de redimensionnement."""
        import os
        css_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            'static', 'textedit', 'css', 'textedit.css'
        )
        with open(css_path) as f:
            css_content = f.read()
        self.assertIn('textedit-resize-wrapper', css_content)

    def test_js_contains_image_resizer_class(self):
        """Vérifie que le JS contient la classe TextEditImageResizer."""
        import os
        js_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            'static', 'textedit', 'js', 'textedit.js'
        )
        with open(js_path) as f:
            js_content = f.read()
        self.assertIn('TextEditImageResizer', js_content)


class TextEditEmojiCategoriesTest(TestCase):
    """Tests pour vérifier que les catégories d'emojis et les emojis demandés
    sont bien présents dans le template et le JS."""

    def _read_js(self):
        """Lit le contenu du fichier textedit.js."""
        import os
        js_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            'static', 'textedit', 'js', 'textedit.js'
        )
        with open(js_path) as f:
            return f.read()

    def test_template_contains_food_tab(self):
        """Vérifie que le template contient l'onglet Nourriture."""
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('data-category="food"', html)

    def test_template_contains_travel_tab(self):
        """Vérifie que le template contient l'onglet Voyages."""
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('data-category="travel"', html)

    def test_js_contains_food_category(self):
        """Vérifie que le JS déclare la catégorie food dans EMOJIS."""
        js_content = self._read_js()
        self.assertIn('food:', js_content)

    def test_js_contains_travel_category(self):
        """Vérifie que le JS déclare la catégorie travel dans EMOJIS."""
        js_content = self._read_js()
        self.assertIn('travel:', js_content)

    def test_js_smileys_contains_new_emojis(self):
        """Vérifie que les smileys contiennent les nouveaux emojis demandés :
        choqué, gourmand, vomir, malade, en colère, a chaud, sourire en coin, diable."""
        js_content = self._read_js()
        # choqué 😱
        self.assertIn('\U0001f631', js_content)
        # gourmand 🤤
        self.assertIn('\U0001f924', js_content)
        # vomir 🤮
        self.assertIn('\U0001f92e', js_content)
        # malade 🤒
        self.assertIn('\U0001f912', js_content)
        # en colère 😡
        self.assertIn('\U0001f621', js_content)
        # a chaud 🥵
        self.assertIn('\U0001f975', js_content)
        # sourire en coin 😏
        self.assertIn('\U0001f60f', js_content)
        # diable 😈
        self.assertIn('\U0001f608', js_content)
        # crotte 💩
        self.assertIn('\U0001f4a9', js_content)

    def test_js_gestures_contains_muscle(self):
        """Vérifie que les gestes contiennent le bras musclé 💪."""
        js_content = self._read_js()
        self.assertIn('\U0001f4aa', js_content)

    def test_js_symbols_contains_card_suits(self):
        """Vérifie que les symboles contiennent les 4 enseignes de cartes et stop 🛑."""
        js_content = self._read_js()
        # pique ♠
        self.assertIn('\u2660', js_content)
        # carreau ♦
        self.assertIn('\u2666', js_content)
        # trèfle ♣
        self.assertIn('\u2663', js_content)
        # coeur ♥
        self.assertIn('\u2665', js_content)
        # stop 🛑
        self.assertIn('\U0001f6d1', js_content)

    def test_js_symbols_red_heart_next_to_broken_heart(self):
        """Vérifie que le coeur rouge ❤ est placé juste à côté du coeur brisé 💔."""
        js_content = self._read_js()
        # Le coeur rouge doit apparaître juste avant le coeur brisé dans le tableau
        self.assertIn("'\u2764','\U0001f494'", js_content)

    def test_js_nature_contains_weather_emojis(self):
        """Vérifie que nature contient nuage ☁ et pluie 🌧."""
        js_content = self._read_js()
        # nuage ☁
        self.assertIn('\u2601', js_content)
        # pluie 🌧
        self.assertIn('\U0001f327', js_content)

    def test_js_food_contains_requested_emojis(self):
        """Vérifie que la catégorie food contient couverts 🍽, courgette 🥒,
        pêche 🍑, trinquer 🥂, champagne 🍾, chope de bière 🍺."""
        js_content = self._read_js()
        # couverts 🍽
        self.assertIn('\U0001f37d', js_content)
        # courgette 🥒
        self.assertIn('\U0001f952', js_content)
        # pêche 🍑
        self.assertIn('\U0001f351', js_content)
        # trinquer 🥂
        self.assertIn('\U0001f942', js_content)
        # champagne 🍾
        self.assertIn('\U0001f37e', js_content)
        # chope de bière 🍺
        self.assertIn('\U0001f37a', js_content)

    def test_js_travel_contains_requested_emojis(self):
        """Vérifie que la catégorie travel contient les emojis de transport."""
        js_content = self._read_js()
        # tente ⛺
        self.assertIn('\u26fa', js_content)
        # voiture 🚗
        self.assertIn('\U0001f697', js_content)
        # train 🚆
        self.assertIn('\U0001f686', js_content)
        # avion 🛫 (décollage, remplace l'ancien ✈ jugé laid)
        self.assertIn('\U0001f6eb', js_content)
        # moto 🏍
        self.assertIn('\U0001f3cd', js_content)
        # vélo 🚲
        self.assertIn('\U0001f6b2', js_content)
        # bateau ⛵
        self.assertIn('\u26f5', js_content)
        # fusée 🚀
        self.assertIn('\U0001f680', js_content)
        # palmier 🌴
        self.assertIn('\U0001f334', js_content)

    def test_js_travel_no_old_plane_emoji(self):
        """Vérifie que l'ancien emoji avion ✈ (U+2708) a été remplacé."""
        js_content = self._read_js()
        # L'ancien ✈ ne doit plus être dans le tableau travel
        # On vérifie qu'il n'apparaît pas comme élément de tableau
        self.assertNotIn("'\u2708'", js_content)

    def test_js_symbols_contains_utility_emojis(self):
        """Vérifie que les symboles contiennent enveloppe 📧, crayon 📝,
        loupe 🔍, téléphone fixe ☎, téléphone mobile 📱."""
        js_content = self._read_js()
        # enveloppe 📧 (remplace l'ancien ✉ jugé laid)
        self.assertIn('\U0001f4e7', js_content)
        # crayon 📝 (remplace l'ancien ✏ jugé laid)
        self.assertIn('\U0001f4dd', js_content)
        # loupe 🔍
        self.assertIn('\U0001f50d', js_content)
        # téléphone fixe ☎
        self.assertIn('\u260e', js_content)
        # téléphone mobile 📱
        self.assertIn('\U0001f4f1', js_content)

    def test_js_symbols_no_old_envelope_and_pencil(self):
        """Vérifie que les anciens emojis ✉ (U+2709) et ✏ (U+270F) ont été remplacés."""
        js_content = self._read_js()
        self.assertNotIn("'\u2709'", js_content)
        self.assertNotIn("'\u270f'", js_content)

    def test_js_nature_contains_wheat(self):
        """Vérifie que nature contient l'épi de blé 🌾."""
        js_content = self._read_js()
        # épi de blé 🌾
        self.assertIn('\U0001f33e', js_content)

    def test_js_food_contains_banana_and_pineapple(self):
        """Vérifie que food contient banane 🍌 et ananas 🍍."""
        js_content = self._read_js()
        # banane 🍌
        self.assertIn('\U0001f34c', js_content)
        # ananas 🍍
        self.assertIn('\U0001f34d', js_content)

    def test_js_food_contains_drinks(self):
        """Vérifie que food contient cocktail 🍹, vin rouge 🍷, thé 🍵, whisky 🥃."""
        js_content = self._read_js()
        # cocktail 🍹
        self.assertIn('\U0001f379', js_content)
        # vin rouge 🍷
        self.assertIn('\U0001f377', js_content)
        # thé 🍵
        self.assertIn('\U0001f375', js_content)
        # whisky 🥃
        self.assertIn('\U0001f943', js_content)

    def test_js_food_contains_soft_drinks(self):
        """Vérifie que food contient eau 💧, jus d'orange 🧃, lait 🥛."""
        js_content = self._read_js()
        # eau 💧
        self.assertIn('\U0001f4a7', js_content)
        # jus d'orange 🧃
        self.assertIn('\U0001f9c3', js_content)
        # lait 🥛
        self.assertIn('\U0001f95b', js_content)

    def test_js_food_contains_fruits_and_pastries(self):
        """Vérifie que food contient orange 🍊, citron 🍋, cerise 🍒,
        croissant 🥐, baguette 🥖, cupcake 🧁."""
        js_content = self._read_js()
        # orange 🍊
        self.assertIn('\U0001f34a', js_content)
        # citron 🍋
        self.assertIn('\U0001f34b', js_content)
        # cerise 🍒
        self.assertIn('\U0001f352', js_content)
        # croissant 🥐
        self.assertIn('\U0001f950', js_content)
        # baguette de pain 🥖
        self.assertIn('\U0001f956', js_content)
        # cupcake 🧁
        self.assertIn('\U0001f9c1', js_content)

    def test_js_nature_contains_two_sun_emojis(self):
        """Vérifie que nature contient 2 emojis soleil : 🌞 (soleil visage)
        et 🌅 (lever de soleil), en plus du ☀ déjà présent."""
        js_content = self._read_js()
        # soleil avec visage 🌞
        self.assertIn('\U0001f31e', js_content)
        # lever de soleil 🌅
        self.assertIn('\U0001f305', js_content)

    def test_js_symbols_contains_tombstone_but_no_coffin(self):
        """Vérifie que les symboles contiennent la tombe 🪦 mais PAS le cercueil ⚰."""
        js_content = self._read_js()
        # tombe (pierre tombale) 🪦 toujours présente
        self.assertIn('\U0001faa6', js_content)
        # cercueil ⚰ supprimé
        self.assertNotIn("'\u26b0'", js_content)

    def test_js_nature_contains_fish(self):
        """Vérifie que nature contient le poisson 🐟."""
        js_content = self._read_js()
        # poisson 🐟
        self.assertIn('\U0001f41f', js_content)

    def test_js_smileys_contains_exploding_head(self):
        """Vérifie que les smileys contiennent la tête qui explose 🤯."""
        js_content = self._read_js()
        # tête qui explose 🤯
        self.assertIn('\U0001f92f', js_content)

    def test_template_contains_sport_tab(self):
        """Vérifie que le template contient l'onglet Sport."""
        widget = TextEditWidget()
        html = widget.render('content', '')
        self.assertIn('data-category="sport"', html)

    def test_js_contains_sport_category(self):
        """Vérifie que le JS déclare la catégorie sport dans EMOJIS."""
        js_content = self._read_js()
        self.assertIn('sport:', js_content)

    def test_js_sport_contains_requested_emojis(self):
        """Vérifie que la catégorie sport contient football ⚽, tennis 🎾,
        ping-pong 🏓, basket 🏀, rugby 🏉, boxe 🥊, baseball ⚾,
        formule 1 🏎, pêche 🎣, patin à glace ⛸, patin à roulettes 🛼,
        skate board 🛹."""
        js_content = self._read_js()
        # football ⚽
        self.assertIn('\u26bd', js_content)
        # tennis 🎾
        self.assertIn('\U0001f3be', js_content)
        # ping-pong 🏓
        self.assertIn('\U0001f3d3', js_content)
        # basket-ball 🏀
        self.assertIn('\U0001f3c0', js_content)
        # rugby 🏉
        self.assertIn('\U0001f3c9', js_content)
        # boxe 🥊
        self.assertIn('\U0001f94a', js_content)
        # baseball ⚾
        self.assertIn('\u26be', js_content)
        # formule 1 🏎
        self.assertIn('\U0001f3ce', js_content)
        # pêche 🎣
        self.assertIn('\U0001f3a3', js_content)
        # patin à glace ⛸ (déplacé depuis travel)
        self.assertIn('\u26f8', js_content)
        # patin à roulettes 🛼 (déplacé depuis travel)
        self.assertIn('\U0001f6fc', js_content)
        # skate board 🛹 (déplacé depuis travel)
        self.assertIn('\U0001f6f9', js_content)

    def test_js_sport_contains_additional_emojis(self):
        """Vérifie que la catégorie sport contient golf ⛳, ski ⛷,
        natation 🏊, musculation 🏋, médaille 🏅, trophée 🏆."""
        js_content = self._read_js()
        # golf ⛳
        self.assertIn('\u26f3', js_content)
        # ski ⛷
        self.assertIn('\u26f7', js_content)
        # natation 🏊
        self.assertIn('\U0001f3ca', js_content)
        # musculation 🏋
        self.assertIn('\U0001f3cb', js_content)
        # médaille 🏅
        self.assertIn('\U0001f3c5', js_content)
        # trophée 🏆
        self.assertIn('\U0001f3c6', js_content)

    def test_js_sport_contains_combat_and_outdoor_emojis(self):
        """Vérifie que la catégorie sport contient badminton 🏸, handball 🤾,
        hockey 🏒, escalade 🧗, surf 🏄."""
        js_content = self._read_js()
        # badminton 🏸
        self.assertIn('\U0001f3f8', js_content)
        # handball 🤾
        self.assertIn('\U0001f93e', js_content)
        # hockey 🏒
        self.assertIn('\U0001f3d2', js_content)
        # escalade 🧗
        self.assertIn('\U0001f9d7', js_content)
        # surf 🏄
        self.assertIn('\U0001f3c4', js_content)

    def test_js_sport_contains_precision_emojis(self):
        """Vérifie que la catégorie sport contient fléchettes 🎯, tir à l'arc 🏹,
        bowling 🎳, billard 🎱."""
        js_content = self._read_js()
        # fléchettes 🎯
        self.assertIn('\U0001f3af', js_content)
        # tir à l'arc 🏹
        self.assertIn('\U0001f3f9', js_content)
        # bowling 🎳
        self.assertIn('\U0001f3b3', js_content)
        # billard 🎱
        self.assertIn('\U0001f3b1', js_content)

    def test_js_sport_contains_strategy_games(self):
        """Vérifie que la catégorie sport contient échecs ♟ et poker 🃏."""
        js_content = self._read_js()
        # échecs ♟
        self.assertIn('\u265f', js_content)
        # poker 🃏
        self.assertIn('\U0001f0cf', js_content)

    def test_js_sport_contains_dice_and_videogame(self):
        """Vérifie que la catégorie sport contient dé à jouer 🎲 et jeu vidéo 🎮."""
        js_content = self._read_js()
        # dé à jouer 🎲
        self.assertIn('\U0001f3b2', js_content)
        # jeu vidéo 🎮
        self.assertIn('\U0001f3ae', js_content)

    def test_js_nature_contains_animals(self):
        """Vérifie que nature contient serpent 🐍, chien 🐶, chat 🐱, souris 🐭,
        cheval 🐴, lapin 🐰, lézard 🦎, poule 🐔, vache 🐮, cochon 🐷."""
        js_content = self._read_js()
        # serpent 🐍
        self.assertIn('\U0001f40d', js_content)
        # chien 🐶
        self.assertIn('\U0001f436', js_content)
        # chat 🐱
        self.assertIn('\U0001f431', js_content)
        # souris 🐭
        self.assertIn('\U0001f42d', js_content)
        # cheval 🐴
        self.assertIn('\U0001f434', js_content)
        # lapin 🐰
        self.assertIn('\U0001f430', js_content)
        # lézard 🦎
        self.assertIn('\U0001f98e', js_content)
        # poule 🐔
        self.assertIn('\U0001f414', js_content)
        # vache 🐮
        self.assertIn('\U0001f42e', js_content)
        # cochon 🐷
        self.assertIn('\U0001f437', js_content)

    def test_js_nature_contains_insects(self):
        """Vérifie que nature contient coccinelle 🐞, fourmi 🐜, papillon 🦋, abeille 🐝."""
        js_content = self._read_js()
        # coccinelle 🐞
        self.assertIn('\U0001f41e', js_content)
        # fourmi 🐜
        self.assertIn('\U0001f41c', js_content)
        # papillon 🦋
        self.assertIn('\U0001f98b', js_content)
        # abeille 🐝
        self.assertIn('\U0001f41d', js_content)

    def test_js_nature_contains_potted_plant(self):
        """Vérifie que nature contient la plante en pot 🪴."""
        js_content = self._read_js()
        # plante en pot 🪴
        self.assertIn('\U0001fab4', js_content)

    def test_js_symbols_contains_red_cross(self):
        """Vérifie que les symboles contiennent la croix rouge ➕."""
        js_content = self._read_js()
        # croix rouge ➕
        self.assertIn('\u2795', js_content)

    def test_js_gestures_contains_praying_hands(self):
        """Vérifie que les gestes contiennent les mains qui prient 🙏."""
        js_content = self._read_js()
        # mains qui prient 🙏
        self.assertIn('\U0001f64f', js_content)
