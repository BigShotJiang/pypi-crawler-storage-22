import os
import re
import uuid

from django.core.exceptions import ValidationError

from . import settings as te_settings

# Magic bytes signatures for allowed image formats
MAGIC_BYTES = {
    'image/jpeg': [b'\xff\xd8\xff'],
    'image/png': [b'\x89PNG\r\n\x1a\n'],
    'image/gif': [b'GIF87a', b'GIF89a'],
    'image/webp': [b'RIFF'],  # RIFF....WEBP
}


def validate_image_extension(uploaded_file):
    """Validate that file extension is in the allowed list."""
    name = uploaded_file.name
    ext = os.path.splitext(name)[1].lstrip('.').lower()
    allowed = te_settings.TEXTEDIT_ALLOWED_EXTENSIONS
    if ext not in allowed:
        raise ValidationError(
            f"Extension '{ext}' not allowed. Allowed: {', '.join(allowed)}"
        )


def validate_image_mime(uploaded_file):
    """Validate that the MIME type (content_type) is in the allowed list."""
    mime = uploaded_file.content_type
    allowed = te_settings.TEXTEDIT_ALLOWED_MIME_TYPES
    if mime not in allowed:
        raise ValidationError(
            f"MIME type '{mime}' not allowed. Allowed: {', '.join(allowed)}"
        )


def validate_image_magic_bytes(uploaded_file):
    """Validate file by reading its magic bytes (binary signature)."""
    uploaded_file.seek(0)
    header = uploaded_file.read(12)
    uploaded_file.seek(0)

    mime = uploaded_file.content_type
    signatures = MAGIC_BYTES.get(mime, [])

    if not signatures:
        raise ValidationError(
            f"No magic bytes signature known for MIME type '{mime}'."
        )

    # Special case for WEBP: check RIFF header + WEBP at offset 8
    if mime == 'image/webp':
        if not (header[:4] == b'RIFF' and header[8:12] == b'WEBP'):
            raise ValidationError(
                "File content does not match WEBP format."
            )
        return

    for sig in signatures:
        if header[:len(sig)] == sig:
            return

    raise ValidationError(
        "File content does not match its declared MIME type."
    )


def validate_image_size(uploaded_file):
    """Validate that file size does not exceed the maximum allowed."""
    max_size = te_settings.TEXTEDIT_MAX_UPLOAD_SIZE
    if uploaded_file.size > max_size:
        max_mb = max_size / (1024 * 1024)
        raise ValidationError(
            f"File size ({uploaded_file.size} bytes) exceeds maximum "
            f"allowed size ({max_mb:.1f} MB)."
        )


def sanitize_filename(filename):
    """
    Sanitize filename to prevent path traversal and collisions.
    - Strip directory components
    - Prefix with UUID
    - Remove dangerous characters
    """
    # Normalize Windows separators and strip path components
    filename = filename.replace('\\', '/')
    filename = os.path.basename(filename)
    # Remove dot-dot sequences to prevent path traversal
    filename = filename.replace('..', '')
    # Remove anything that isn't alphanumeric, dot, hyphen, or underscore
    filename = re.sub(r'[^\w.\-]', '_', filename)
    # Prefix with UUID to prevent collisions
    unique = uuid.uuid4().hex[:12]
    return f"{unique}_{filename}"


def validate_uploaded_image(uploaded_file):
    """Run all image validations in sequence."""
    validate_image_extension(uploaded_file)
    validate_image_mime(uploaded_file)
    validate_image_magic_bytes(uploaded_file)
    validate_image_size(uploaded_file)
