import json
import os

from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.http import require_POST

from . import settings as te_settings
from .validators import sanitize_filename, validate_uploaded_image


@require_POST
@csrf_protect
def upload_image(request):
    """Handle image upload from the TextEdit editor."""
    if not request.FILES.get('image'):
        return JsonResponse({'error': 'No image file provided.'}, status=400)

    uploaded_file = request.FILES['image']

    # Run all validations
    try:
        validate_uploaded_image(uploaded_file)
    except Exception as e:
        return JsonResponse({'error': str(e.message if hasattr(e, 'message') else e)}, status=400)

    # Sanitize filename
    safe_name = sanitize_filename(uploaded_file.name)

    # Build upload path
    upload_dir = te_settings.TEXTEDIT_UPLOAD_DIR
    full_dir = os.path.join(settings.MEDIA_ROOT, upload_dir)
    os.makedirs(full_dir, exist_ok=True)

    file_path = os.path.join(full_dir, safe_name)

    # Write file to disk
    with open(file_path, 'wb') as f:
        for chunk in uploaded_file.chunks():
            f.write(chunk)

    # Build URL
    url = f'{settings.MEDIA_URL}{upload_dir}/{safe_name}'

    return JsonResponse({'url': url})
