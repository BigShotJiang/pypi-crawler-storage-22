import uuid

from django import forms
from django.template.loader import render_to_string
from django.urls import reverse
from django.utils.safestring import mark_safe


class TextEditWidget(forms.Textarea):
    """Rich text editor widget using contenteditable + hidden textarea."""

    template_name = 'textedit/textedit_widget.html'

    class Media:
        css = {
            'all': ('textedit/css/textedit.css',),
        }
        js = ('textedit/js/textedit.js',)

    def __init__(self, attrs=None):
        defaults = {'class': 'textedit-textarea'}
        if attrs:
            defaults.update(attrs)
        super().__init__(attrs=defaults)

    def render(self, name, value, attrs=None, renderer=None):
        if value is None:
            value = ''

        widget_id = uuid.uuid4().hex[:8]

        try:
            upload_url = reverse('textedit:upload_image')
        except Exception:
            upload_url = '/textedit/upload/'

        context = {
            'widget_id': widget_id,
            'name': name,
            'value': value,
            'upload_url': upload_url,
            'csrf_cookie_name': 'csrftoken',
            'required': self.is_required if hasattr(self, 'is_required') else False,
        }

        html = render_to_string(self.template_name, context)
        return mark_safe(html)


class AdminTextEditWidget(TextEditWidget):
    """TextEdit widget with additional admin CSS."""

    class Media:
        css = {
            'all': (
                'textedit/css/textedit.css',
                'textedit/css/textedit-admin.css',
            ),
        }
        js = ('textedit/js/textedit.js',)
