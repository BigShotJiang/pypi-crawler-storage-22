# django-unfold-contrib

Community contrib extensions for the Django Unfold admin theme. Each feature is a separate Django app that users opt into via `INSTALLED_APPS`.

## Project Structure

```
src/unfold_contrib/
├── __init__.py              # Exports unfold_action decorator
├── actions.py               # @unfold_action decorator for django-object-actions
├── google_auth/             # Google OAuth login button + allauth integration
│   ├── apps.py
│   ├── views.py             # Clean logout view (clears messages)
│   ├── templates/
│   │   ├── admin/login.html              # Login page with Google button + "or" divider
│   │   ├── allauth/layouts/base.html     # Allauth pages styled with Unfold
│   │   └── components/google_signin_button.html
│   └── static/unfold_contrib/img/google_signin.svg
├── mobile_table/            # Forces table layout on mobile (overrides Unfold card view)
│   ├── apps.py
│   └── static/unfold_contrib/css/mobile-table.css
├── select2_dark/            # Dark mode CSS for Select2 widgets
│   ├── apps.py
│   └── static/unfold_contrib/css/select2-dark.css

└── custom_pages/            # Base template for building custom admin pages
    ├── apps.py
    └── templates/unfold_contrib/base_admin_page.html
```

Other files:
- `pyproject.toml` — Package config, uses hatch for building
- `.build.yml` — SourceHut CI: builds with hatch, publishes if version is new
- `scripts/is_published.py` — Checks if current version exists on PyPI (exit 0 = exists, exit 1 = not found)

## Features (copied from Game-Deals project)

All files were copied (not rewritten) from the Game-Deals project. Each feature is a standalone Django app:

| Feature | App | What it does |
|---|---|---|
| `@unfold_action` decorator | `unfold_contrib` (base) | Styles django-object-actions buttons to match Unfold theme |
| Google OAuth login | `unfold_contrib.google_auth` | Provides templates for integrating django-allauth with Unfold, including a themed login page with a Google sign-in button, and a clean logout view. |
| Mobile table | `unfold_contrib.mobile_table` | CSS override to keep table layout on mobile instead of Unfold's card view |
| Select2 dark mode | `unfold_contrib.select2_dark` | Dark mode CSS for Select2 dropdown widgets |

| Custom pages base | `unfold_contrib.custom_pages` | Base template for custom admin pages with jQuery + Unfold branding |

**Excluded:** The task monitor feature (real-time Celery task badge in header) was intentionally excluded.

## Current State

### Done
- Created package directory structure with hatch build system
- Copied all source files from Game-Deals into feature-specific Django apps
- Created `apps.py` with proper AppConfig for each feature app
- Created `pyproject.toml` with optional dependencies (`google-auth`, `actions`)
- Created `scripts/is_published.py` for PyPI version checking
- Deleted `scripts/publish.py`
- Made `scripts/is_published.py` executable
- Finished `.build.yml`
- Generalized copied files
