#!/usr/bin/env python3
"""Exit 0 if the current version already exists on PyPI, exit 1 if not."""

import tomllib
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import urlopen

PACKAGE = "django-unfold-contrib"


def get_version():
    pyproject = Path(__file__).resolve().parent.parent / "pyproject.toml"
    with open(pyproject, "rb") as f:
        return tomllib.load(f)["project"]["version"]


def main():
    version = get_version()
    url = f"https://pypi.org/pypi/{PACKAGE}/{version}/json"
    try:
        urlopen(url)
        print(f"{PACKAGE} {version} already exists on PyPI.")
        raise SystemExit(0)
    except HTTPError:
        print(f"{PACKAGE} {version} not found on PyPI.")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
