from django.apps import AppConfig


class GoogleAuthConfig(AppConfig):
    name = "unfold_contrib.allauth"
    label = "unfold_contrib_allauth"
    verbose_name = "Unfold Contrib: Allauth"
    default_auto_field = "django.db.models.BigAutoField"
