from django import template
from django.conf import settings

register = template.Library()

@register.simple_tag
def is_google_auth_enabled():
    return getattr(settings, 'UNFOLD_CONTRIB_GOOGLE_AUTH_ENABLED', False)
