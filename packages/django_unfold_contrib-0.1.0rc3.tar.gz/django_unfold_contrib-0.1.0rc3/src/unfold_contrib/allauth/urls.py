"""
URL configuration for allauth app.
"""
from django.urls import path
from . import views

app_name = "unfold_contrib_allauth"

urlpatterns = [
    path("logout/", views.logout_view, name="account_logout"),
]