from django.apps import AppConfig


class CustomPagesConfig(AppConfig):
    name = "unfold_contrib.custom_admin_pages"
    label = "unfold_contrib_custom_admin_pages"
    verbose_name = "Unfold Contrib: Custom Admin Pages"
    default_auto_field = "django.db.models.BigAutoField"
