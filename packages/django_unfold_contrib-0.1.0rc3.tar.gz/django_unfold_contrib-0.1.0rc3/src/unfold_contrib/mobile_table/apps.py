from django.apps import AppConfig


class MobileTableConfig(AppConfig):
    name = "unfold_contrib.mobile_table"
    label = "unfold_contrib_mobile_table"
    verbose_name = "Unfold Contrib: Mobile Table"
    default_auto_field = "django.db.models.BigAutoField"
