from django.apps import AppConfig


class Select2DarkConfig(AppConfig):
    name = "unfold_contrib.select2_dark"
    label = "unfold_contrib_select2_dark"
    verbose_name = "Unfold Contrib: Select2 Dark Mode"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self):
        """Add Select2 dark theme CSS to Unfold settings when app is loaded."""
        from django.conf import settings

        # Get existing UNFOLD configuration
        unfold_config = getattr(settings, "UNFOLD", {})

        # Get or create the STYLES list
        styles = unfold_config.get("STYLES", [])

        # Add select2_dark CSS if not already present
        select2_dark_css = "/static/unfold_contrib/css/select2-dark.css"
        if select2_dark_css not in styles:
            styles.append(select2_dark_css)
            unfold_config["STYLES"] = styles

            # Update the settings
            setattr(settings, "UNFOLD", unfold_config)
