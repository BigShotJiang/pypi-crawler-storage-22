from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import LdapUser

@admin.register(LdapUser)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff')
    
    fieldsets = UserAdmin.fieldsets + (
        ('Informações Adicionais', {'fields': ('seu_campo_extra_1', 'seu_campo_extra_2')}),
    )

    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Informações Adicionais', {'fields': ('seu_campo_extra_1', 'seu_campo_extra_2')}),
    )

    search_fields = ('username', 'first_name', 'last_name', 'email')
    ordering = ('username',)