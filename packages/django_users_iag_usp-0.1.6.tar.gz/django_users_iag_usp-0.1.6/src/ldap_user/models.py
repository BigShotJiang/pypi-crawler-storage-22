from django.contrib.auth.models import AbstractUser
from django.db import models


class LdapUser(AbstractUser):
    pca_groups = models.TextField()
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateField(auto_now=True)

    def get_setor(self):
        groups_striped = self.groups.replace(" ", "")
        groups = groups_striped.split(",")
        return groups

