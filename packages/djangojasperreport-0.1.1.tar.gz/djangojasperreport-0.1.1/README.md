# Django Jasper Report
Easily generate JasperReports from your Django views using the REST API.

## Installation
`pip install djangojasperreport`

## Setup
In `settings.py`:
- `JASPER_SERVER_URL = "http://your-ip:8080"`
- `JASPER_USER = "jasperadmin"`
- `JASPER_PASSWORD = "jasperadmin"`

## 📖 Usage
In your `views.py`:

```python
from jasper_report.client import JasperClient
from rest_framework.views import APIView

class MyReportView(APIView):
    def get(self, request):
        client = JasperClient()
        
        # Path to the report in your JasperServer
        report_path = "/reports/NameOfReport"
        
        # Pass URL parameters directly to the report
        params = request.query_params.dict()
        fmt = params.pop('format', 'pdf')

        return client.generate(report_path, fmt=fmt, params=params)