import requests
from django.conf import settings
from django.http import HttpResponse

class JasperClient:
    def __init__(self):
        # Fetches config from the developer's Django settings
        self.base_url = getattr(settings, 'JASPER_SERVER_URL', 'http://localhost:8080/jasperserver')
        self.user = getattr(settings, 'JASPER_USER', 'jasperadmin')
        self.password = getattr(settings, 'JASPER_PASSWORD', 'jasperadmin')
        self.auth = (self.user, self.password)

    def generate(self, report_path, fmt='pdf', params=None):
        url = f"{self.base_url.rstrip('/')}/rest_v2/reports{report_path}.{fmt}"
        
        try:
            response = requests.get(url, auth=self.auth, params=params, stream=True)
            response.raise_for_status()
            
            content_types = {
                'pdf': 'application/pdf',
                'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'xls': 'application/vnd.ms-excel',
                'csv': 'text/csv'
            }
            
            django_res = HttpResponse(
                response.content, 
                content_type=content_types.get(fmt.lower(), 'application/octet-stream')
            )
            django_res['Content-Disposition'] = f'attachment; filename="report.{fmt}"'
            return django_res
            
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Jasper Server Communication Error: {str(e)}")