# Django REST Report
A versatile Django toolkit for managing reports

## JasperReports
Easily generate JasperReports from your Django views using the JasperReports Server REST API. This package handles authentication, URL construction, and maps Django responses to the correct file types automatically.

### 🛠 Prerequisites
Before using this package, you must have a JasperReports Server instance running.

You can host it yourself or use a cloud instance.

Ensure the REST API is accessible (typically at port 8080).

### 🚀 Installation
```bash
pip install djangorestreport
```

### ⚙️ Setup
Add your JasperServer credentials to your Django `settings.py`.
```python
# settings.py
JASPER_SERVER_URL = "http://server-ip:8080"
JASPER_USER = "username"
JASPER_PASSWORD = "password"
```

### 📄 Supported Formats
Pass these strings into the `fmt` parameter to receive the corresponding file type:

Documents: `pdf`, `docx`, `rtf`, `odt`, `html`, `xml`

Spreadsheets: `xlsx`, `xls`, `csv`, `ods`

Presentations: `pptx`

### 📖 Usage
#### Basic Example (DRF View)
In your `views.py`, you can extract query parameters from the URL and pass them directly to your Jasper report.

```python
from rest_report import JasperReport
from rest_framework.views import APIView
from rest_framework.response import Response

class ReportView(APIView):
    def get(self, request):
        report = JasperReport()

        # 1. Path to the report unit in your JasperServer repository
        report_path = "/organization/reports/NameofReport"

        # 2. Get all query params (e.g., ?id=5&status=active)
        params = request.query_params.dict()

        # 3. Extract the format (default to 'pdf')
        fmt = params.pop("fmt", "pdf")

        # 4. Generate and return the report as a file download
        try:
            return report.generate(report_path, fmt=fmt, params=params)
        except Exception as e:
            return Response({"error": str(e)}, status=400)
```

### 💡 Working with Parameters
The `params` dictionary keys must exactly match the parameter names defined in your `.jrxml` file. For example, if you pass `{"id": 10}`, your Jasper report should have a parameter defined as `$P{id}`.

## ⚖️ License
This project is licensed under the MIT License - see the LICENSE file for details.
