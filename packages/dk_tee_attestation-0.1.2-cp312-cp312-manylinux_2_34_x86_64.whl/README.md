# TEE-License Manager Attestation Library

This repository contains a reference implementation of a **license manager service**
that verifies **TEE-based attestations** and a **TEE client**
that generates and submits attestations to the license server.

The **repository root** is assumed to be:

```
fhenom_tee_attestation/
```

> **Note**  
> Currently, only the attestation mechanism on AMD SEV-SNP is supported.

---

## Repository Overview

- `python_lib/`  
  Core Python library

- `rust_lib/`  
  Rust library (SEV-SNP firmware bindings) exposed to Python via PyO3

- `python_license_manager_example/`  
  License server example (runs on the license server machine)

- `python_sev_snp_tee_example/`  
  TEE client example (runs inside the TEE / confidential VM)
---

## Attestation Library (Build & Interface Overview)

This repository provides a **reusable attestation library** exposing a Python API backed by a Rust implementation, designed to run inside **confidential virtual machines (AMD SEV-SNP)**.

The library can be built and installed **independently of the example applications**, and reused by any Python project that needs to:
- generate a TEE attestation report inside a confidential VM
- verify a TEE attestation report on a verifier / server side

### Build as a reusable Python module

The Rust implementation is compiled into a Python extension module using **maturin**.

From the repository root:

```bash
cd rust_lib/
maturin develop --release
```

This produces and installs a Python module exposing the SEV-SNP firmware bindings into the currently active Python environment.

The module is named **tee_amd_sev_snp_rust_py_wrap** and can be directly imported in any python file.

> **Note**  
> The Rust module must be built in any environment where attestation report
> generation or verification is required (TEE client and verifier).

### Public Python interface (high-level)

The Python interface is intentionally minimal and backend-agnostic.

Attestation engines are instantiated via a **factory**, and all interaction
happens through the abstract `AttestationEngine` interface.

```python
from python_lib import AttestationEngineFactory, AttestationEngineType

engine = AttestationEngineFactory.get(AttestationEngineType.amd_sev_snp)
```

#### Generate an attestation report (inside the TEE)

```python
report = engine.get_report(report_data)
```

- `report_data`: caller-provided nonce / challenge (bytes)
- returns raw attestation report bytes

#### Verify an attestation report (verifier side)

```python
engine.verify_report(report_bytes, expected_report_data)
```

- raises an exception if verification fails
- returns `None` on successful verification

All verification failures are reported via **explicit domain exceptions**.

---

## Environment Setup

Before running anything, follow the appropriate setup guide:

- **License server setup**  
  See:
  ```
  python_license_manager_example/Setup.md
  ```

- **TEE client setup (inside the TEE)**  
  See:
  ```
  python_sev_snp_tee_example/Setup.md
  ```

Each setup guide explains how to:
- create the Python virtual environment
- install dependencies
- prepare the Rust toolchain (maturin)

---

## Start the License Server (License Server Machine)

From the repository root:

```bash
cd python_license_manager_example/
source .license_manager_venv/bin/activate

cd ../rust_lib/
maturin develop --release

cd ..
python -m python_license_manager_example.src.main_license_manager
```

---

## Create a Secure SSH Tunnel (License Server → TEE)

On the **license server machine**, create a secure SSH reverse tunnel to the TEE.
This forwards port `5000` securely to the remote TEE machine.
It assumes the **license server machine public key** is stored inside the .ssh/authorized_keys
inside the **TEE machine**.

```bash
ssh -i ssh-configs/license_manager_priv_key -R 5000:localhost:5000 user@tee_ip_address
```

---

## Start the TEE Client (Inside the TEE / Remote Machine)

From the repository root **on the TEE machine**:

```bash
cd python_sev_snp_tee_example/
source .tee_venv/bin/activate

cd ../rust_lib/
maturin develop --release

cd ..
python -m python_sev_snp_tee_example.src.main_tee_client
```

---

## End-to-End Flow Summary

1. License server starts and listens on port `5000`
2. SSH tunnel securely forwards traffic to the TEE
3. TEE client:
   - generates a keypair
   - generates a SEV-SNP attestation
   - sends the attestation to the license server
4. License server:
   - verifies the attestation
   - validates AMD certificate chain and signature
   - confirms binding between public key and TEE

---

## Notes

- This repository is intended as a **reference / example implementation**
- Error handling is explicit and verification is exception-based
- Rust bindings are required on **both** the server and TEE sides

---

## License

TBD
