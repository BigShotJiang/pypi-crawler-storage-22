from __future__ import annotations
from abc import ABC, abstractmethod


class AttestationEngine(ABC):
    """
    Abstract interface for TEE attestation engines.

    This class defines the contract that all attestation engine implementations
    (e.g., AMD SEV-SNP, Intel TDX) must adhere to.

    The engine will:
    - Produce a platform-specific attestation report binding caller-provided report_data
    - Verify the authenticity, integrity, and report_data binding of a received report
    """


    @abstractmethod
    def get_report(self, report_data: bytes) -> bytes:
        """
        Produce a TEE attestation report binding the provided report_data.

        The report generation will:
        - Use report_data as the caller-provided nonce/challenge
        - Bind report_data into the attestation report according to the platform ABI
        - Return the raw attestation report bytes in the vendor-specific format

        Args:
        - report_data: Nonce/challenge buffer to be cryptographically bound into the report.

        Returns:
        - Raw attestation report bytes produced by the underlying TEE platform.

        Raises:
        - AttestationError: If report generation fails or cannot be completed.
        """
        raise NotImplementedError

    @abstractmethod
    def verify_report(self, report_bytes: bytes, expected_report_data: bytes) -> None:
        """
        Verify a TEE attestation report and its binding to expected_report_data.

        The verification process will:
        - Parse the raw attestation report structure
        - Verify the report signature and trust chain according to platform rules
        - Ensure the report is cryptographically bound to expected_report_data
        - Validate any platform-specific security metadata (e.g., TCB, measurements)

        Args:
        - report_bytes: Raw attestation report bytes to be verified.
        - expected_report_data: Expected nonce/challenge that must be bound in the report.

        Returns:
        - None on successful verification.

        Raises:
        - AttestationError: If the report is invalid, unverifiable, or not correctly bound.
        """
        raise NotImplementedError