from dk_tee_attestation.AttestationEngine import AttestationEngine
from dk_tee_attestation.AttestationExceptions import ReportDataError, ReportBytesError
from dk_tee_attestation.amd_sev_snp_attestation_report_verification_utils import AmdSevSnpVerifier


class AttestationEngineAmdSevSnp(AttestationEngine):
    """
    AMD SEV-SNP attestation engine implementation.

    This engine provides AMD SEV-SNP–specific logic for:
    - Generating attestation reports via the local SEV-SNP firmware interface
    - Verifying the authenticity, integrity, and report_data binding of SEV-SNP reports

    All AMD-specific parsing, certificate handling, and cryptographic verification
    is delegated to the AmdSevSnpVerifier component.
    """


    def get_report(self, report_data: bytes,  msg: int = 1, vmpl: int = 0) -> bytes:
        """
        Produce an AMD SEV-SNP attestation report binding the provided report_data.

        This method will:
        - Validate that report_data is bytes-like
        - Delegate report retrieval to the AMD SEV-SNP verifier wrapper

        Args:
        - report_data: Nonce/challenge buffer to be bound into the attestation report.
        - msg: Message/report version selector forwarded to the firmware interface.
        - vmpl: VM privilege level selector forwarded to the firmware interface.

        Returns:
        - Raw AMD SEV-SNP attestation report bytes.

        Raises:
        - ReportDataError: If report_data is not provided as a bytes-like object.
        """
        if not isinstance(report_data, (bytes, bytearray)):
            raise ReportDataError(f"Report data must be bytes.")
        
        return AmdSevSnpVerifier.get_amd_sev_snp_attestation_report(report_data, msg, vmpl)


    def verify_report(self, report_bytes: bytes, expected_report_data: bytes) -> None:
        """
        Verify an AMD SEV-SNP attestation report against the expected report_data.

        This method will:
        - Validate that report_bytes is bytes-like
        - Validate that expected_report_data is bytes-like
        - Delegate verification to the AMD SEV-SNP verifier wrapper

        Args:
        - report_bytes: Raw AMD SEV-SNP attestation report bytes to verify.
        - expected_report_data: Expected nonce/challenge that must match the report binding.

        Returns:
        - None on successful verification.

        Raises:
        - ReportBytesError: If report_bytes is not provided as a bytes-like object.
        - ReportDataError: If expected_report_data is not provided as a bytes-like object.
        """
        if not isinstance(report_bytes, (bytes, bytearray)):
            raise ReportBytesError("Report_bytes must be bytes")
        
        if not isinstance(expected_report_data, (bytes, bytearray)):
            raise ReportDataError("Expected_report_data must be bytes")

        AmdSevSnpVerifier.verify_amd_sev_snp_attestation_report(report_bytes, expected_report_data)
        
        return None