from typing import Dict, Type


from dk_tee_attestation.AttestationEngine import AttestationEngine
from dk_tee_attestation.AttestationEngineType import AttestationEngineType
from dk_tee_attestation.AttestationEngineAmdSevSnp import AttestationEngineAmdSevSnp
from dk_tee_attestation.AttestationEngineIntelTdx import AttestationEngineIntelTdx
from dk_tee_attestation.AttestationExceptions import UnsupportedEngine


class AttestationEngineFactory:
    """
    Factory for instantiating attestation engine implementations.

    This class provides a centralized mapping between AttestationEngineType
    values and their corresponding concrete AttestationEngine classes.
    """


    _REGISTRY: Dict[AttestationEngineType, Type[AttestationEngine]] = {
        AttestationEngineType.amd_sev_snp: AttestationEngineAmdSevSnp,
        AttestationEngineType.intel_tdx: AttestationEngineIntelTdx,
    }

    @classmethod
    def get(
        cls,
        engine_type: AttestationEngineType,
    ) -> AttestationEngine:
        """
        Instantiate and return an attestation engine for the requested engine_type.

        This method will:
        - Resolve the concrete AttestationEngine class associated with engine_type
        - Instantiate and return the corresponding engine instance

        Args:
        - engine_type: Attestation engine selector identifying the desired TEE backend.

        Returns:
        - An instance of the requested AttestationEngine implementation.

        Raises:
        - UnsupportedEngine: If no attestation engine is registered for engine_type.
        """
        try:
            engine_cls = cls._REGISTRY[engine_type]

        except KeyError as e:
            raise UnsupportedEngine(f"Unsupported engine type: {engine_type}") from e

        return engine_cls()
