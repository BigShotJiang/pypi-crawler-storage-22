from dk_tee_attestation.AttestationEngine import AttestationEngine
from dk_tee_attestation.AttestationExceptions import ReportDataError, ReportBytesError, NotImplementedAttestationEngine


class AttestationEngineIntelTdx(AttestationEngine):
    """
    Intel TDX attestation engine placeholder implementation.

    This engine currently provides input validation only and explicitly signals
    that Intel TDX attestation support is not yet implemented.
    """
    

    def get_report(self, report_data: bytes) -> bytes:
        """
        Attempt to produce an Intel TDX attestation report.

        This method will:
        - Validate that report_data is bytes-like
        - Explicitly signal that Intel TDX attestation is not implemented

        Args:
        - report_data: Nonce/challenge buffer intended to be bound into the report.

        Returns:
        - Never returns.

        Raises:
        - ReportDataError: If report_data is not provided as a bytes-like object.
        - NotImplementedAttestationEngine: If Intel TDX attestation support is not available.
        """
        if not isinstance(report_data, (bytes, bytearray)):
            raise ReportDataError(f"Report data must be bytes.")
        
        raise NotImplementedAttestationEngine("Intel TDX attestation engine not implemented yet.")


    def verify_report(self, report_bytes: bytes, expected_report_data: bytes) -> None:
        """
        Attempt to verify an Intel TDX attestation report.

        This method will:
        - Validate that report_bytes is bytes-like
        - Validate that expected_report_data is bytes-like
        - Explicitly signal that Intel TDX attestation verification is not implemented

        Args:
        - report_bytes: Raw Intel TDX attestation report bytes to verify.
        - expected_report_data: Expected nonce/challenge to be matched against the report.

        Returns:
        - Never returns.

        Raises:
        - ReportBytesError: If report_bytes is not provided as a bytes-like object.
        - ReportDataError: If expected_report_data is not provided as a bytes-like object.
        - NotImplementedAttestationEngine: If Intel TDX attestation support is not available.
        """
        if not isinstance(report_bytes, (bytes, bytearray)):
            raise ReportBytesError("Report_bytes must be bytes")
        
        if not isinstance(expected_report_data, (bytes, bytearray)):
            raise ReportDataError("Expected_report_data must be bytes")
        
        raise NotImplementedAttestationEngine("Intel TDX attestation engine not implemented yet.")