from enum import Enum


class AttestationEngineType(str, Enum):
    """
    Enumeration of supported attestation engine types.

    This enum defines the set of attestation backends that can be selected
    when instantiating an AttestationEngine via the factory.
    """


    amd_sev_snp = "amd_sev_snp"
    intel_tdx = "intel_tdx"