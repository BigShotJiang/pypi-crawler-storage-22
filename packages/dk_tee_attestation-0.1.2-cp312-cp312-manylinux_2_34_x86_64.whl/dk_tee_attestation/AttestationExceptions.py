class AttestationError(Exception):
    """
    Base error for attestation verification failures.

    The verifier will:
    - Raise a subclass of AttestationError when verification cannot be completed
    """
    pass


class ReportDataError(AttestationError):
    """
    Raised when report_data does not match the expected value.

    The verifier will:
    - Raise this when report.report_data is not exactly 64 bytes
    - Raise this when report.report_data differs from the recomputed expected value
    - Raise this when report.report_data are not actual bytes
    """
    pass


class ReportBytesError(AttestationError):
    """
    Raised when report bytes don't match the expected values.

    The verifier will:
    - Raise this when report bytes are not actual bytes
    """
    pass


class KdsFetchError(AttestationError):
    """
    Raised when fetching certificates from AMD KDS fails.

    The verifier will:
    - Raise this when network or HTTP errors prevent retrieving ARK/ASK/VCEK
    """
    pass


class CertChainError(AttestationError):
    """
    Raised when the certificate chain cannot be parsed or validated.

    The verifier will:
    - Raise this when certificate parsing fails
    - Raise this when chain signature verification fails
    """
    pass


class MetadataMismatchError(AttestationError):
    """
    Raised when VCEK metadata does not match the attestation report.

    The verifier will:
    - Raise this when VCEK extension values are inconsistent with reported_tcb or chip_id
    """
    pass


class SignatureError(AttestationError):
    """
    Raised when an ECDSA signature check fails.

    The verifier will:
    - Raise this when r/s components have unexpected size
    - Raise this when report signature verification fails with the VCEK public key
    """
    pass


class UnsupportedChipFamilyError(AttestationError):
    """
    Raised when the CPU family/model is not recognized.

    The verifier will:
    - Raise this when CPUID family/model cannot be mapped to a supported AMD product line
    """
    pass


class FirmwareOpenErrorAmdSevSnp(AttestationError):
    """
    Raised when AMD SEV-SNP firmware cannot be opened.

    The verifier will:
    - Raise this when it is not possible to access the AMD SEV-SNP tee firmware.
    """
    pass


class AttestationParseErrorAmdSevSnp(AttestationError):
    """
    Raised when an AMD SEV-SNP attestation report cannot be parsed.

    The verifier will:
    - Raise this when an AMD SEV-SNP attestation report is structurally invalid or cannot be properly parsed
    """
    pass


class UnsupportedEngine(AttestationError):
    """
    Raised when the instantiation of an unsupported attestation engine is required.

    The verifier will:
    - Raise this when the factory attestation class is unable to instatiate a child attestation class
    """
    pass


class NotImplementedAttestationEngine(AttestationError):
    """
    Raised when a concrete attestation engine is not yet implemented.

    The verifier will:
    - Raise this when a supported attestation engine method gets called but has not been implemented yet
    """
    pass

