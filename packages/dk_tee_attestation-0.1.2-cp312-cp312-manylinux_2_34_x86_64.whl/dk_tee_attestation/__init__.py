"""
FHEnom TEE Attestation Library

This library provides a unified interface for generating and verifying
TEE attestation reports across different platforms (AMD SEV-SNP, Intel TDX).

Main interfaces:
- AttestationEngine: Abstract base class for attestation engines
- AttestationEngineFactory: Factory for creating attestation engines
- AttestationEngineType: Enum of supported TEE platforms

Example usage:
    >>> from dk_tee_attestation import AttestationEngineFactory, AttestationEngineType
    >>> 
    >>> # Create an AMD SEV-SNP attestation engine
    >>> engine = AttestationEngineFactory.get(AttestationEngineType.amd_sev_snp)
    >>> 
    >>> # Generate a report (inside TEE)
    >>> report_data = b"your_nonce_64_bytes_padded" + b"\x00" * 38
    >>> report = engine.get_report(report_data)
    >>> 
    >>> # Verify a report (on verifier side)
    >>> engine.verify_report(report, report_data)
"""

from dk_tee_attestation.AttestationEngine import AttestationEngine
from dk_tee_attestation.AttestationEngineFactory import AttestationEngineFactory
from dk_tee_attestation.AttestationEngineType import AttestationEngineType
from dk_tee_attestation.AttestationEngineAmdSevSnp import AttestationEngineAmdSevSnp
from dk_tee_attestation.AttestationEngineIntelTdx import AttestationEngineIntelTdx
from dk_tee_attestation.AttestationExceptions import (
    AttestationError,
    ReportDataError,
    ReportBytesError,
    KdsFetchError,
    CertChainError,
    MetadataMismatchError,
    SignatureError,
    UnsupportedChipFamilyError,
    UnsupportedEngine,
    FirmwareOpenErrorAmdSevSnp,
    AttestationParseErrorAmdSevSnp,
)

__version__ = "0.1.0"

__all__ = [
    # Core interfaces
    "AttestationEngine",
    "AttestationEngineFactory",
    "AttestationEngineType",
    
    # Implementations
    "AttestationEngineAmdSevSnp",
    "AttestationEngineIntelTdx",
    
    # Exceptions
    "AttestationError",
    "ReportDataError",
    "ReportBytesError",
    "KdsFetchError",
    "CertChainError",
    "MetadataMismatchError",
    "SignatureError",
    "UnsupportedChipFamilyError",
    "UnsupportedEngine",
    "FirmwareOpenErrorAmdSevSnp",
    "AttestationParseErrorAmdSevSnp",
]
