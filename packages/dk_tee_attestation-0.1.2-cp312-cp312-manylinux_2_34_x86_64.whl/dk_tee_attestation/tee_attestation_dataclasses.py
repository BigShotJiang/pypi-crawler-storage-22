from dataclasses import dataclass


@dataclass(frozen=True)
class ReportedTcb:
    """
    Represent the reported Trusted Computing Base (TCB) versions from a TEE.
    """
    bootloader: int             # bootloader security version number (SVN)
    tee: int                    # TEE firmware security version number (SVN)
    snp: int                    # SNP firmware security version number (SVN)
    microcode: int              # CPU microcode security version number (SVN)


@dataclass(frozen=True)
class CpuId:
    """
    Represent CPU identification values reported by the platform.
    """
    fam_id: int                 # CPUID family
    mod_id: int                 # CPUID model
    step: int                   # CPUID stepping (revision)


@dataclass(frozen=True)
class ParsedAttestationReport:
    """
    Represent a parsed AMD SEV-SNP attestation report.
    """
    chip_id: bytes              # unique chip identifier (64 bytes)
    report_data: bytes          # report_data field from SEV-SNP report (64 bytes)
    reported_tcb: ReportedTcb   # reported TCB versions
    cpuid: CpuId                # CPU identification values
    signed_bytes: bytes         # signed report bytes [0x0..0x2A0]
    sig_r: bytes                # ECDSA signature r
    sig_s: bytes                # ECDSA signature s