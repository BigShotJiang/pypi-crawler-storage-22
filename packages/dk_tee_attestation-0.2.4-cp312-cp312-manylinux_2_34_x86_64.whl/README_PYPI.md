# FHEnom TEE Attestation Library

A Python library for generating and verifying TEE (Trusted Execution Environment) attestation reports across different hardware platforms.

[![PyPI version](https://badge.fury.io/py/fhenom-tee-attestation.svg)](https://badge.fury.io/py/fhenom-tee-attestation)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

## Features

- **Multi-Platform Support**: AMD SEV-SNP and Intel TDX
- **Unified API**: Single interface for all TEE platforms
- **Cryptographic Verification**: Full certificate chain validation
- **Production Ready**: Used in FHEnom AI confidential computing platform

## Supported Platforms

- ✅ **AMD SEV-SNP** (Secure Encrypted Virtualization - Secure Nested Paging)
- 🚧 **Intel TDX** (Trust Domain Extensions) - Coming soon

## Installation

### Basic Installation (Python API only)

```bash
pip install fhenom-tee-attestation
```

### With Rust Module (for actual attestation generation/verification)

The Rust module is required for generating reports inside a TEE and verifying reports. It requires Rust toolchain:

```bash
# Install Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Install maturin
pip install maturin

# Clone and build
git clone https://devops.datakrypto.com/DataKrypto/_git/fhenom_tee_attestation
cd fhenom_tee_attestation/rust_lib
maturin develop --release
```

## Quick Start

### Generate an Attestation Report (Inside TEE)

```python
from dk_tee_attestation import AttestationEngineFactory, AttestationEngineType

# Create AMD SEV-SNP engine
engine = AttestationEngineFactory.get(AttestationEngineType.amd_sev_snp)

# Generate report with nonce (must be 64 bytes)
nonce = b"your_nonce_here" + b"\x00" * (64 - len(b"your_nonce_here"))
report_bytes = engine.get_report(nonce)

# Save for verification
with open("attestation_report.bin", "wb") as f:
    f.write(report_bytes)
```

### Verify an Attestation Report (Verifier Side)

```python
from dk_tee_attestation import AttestationEngineFactory, AttestationEngineType

# Create engine
engine = AttestationEngineFactory.get(AttestationEngineType.amd_sev_snp)

# Load report
with open("attestation_report.bin", "rb") as f:
    report_bytes = f.read()

# Verify (raises exception on failure)
nonce = b"your_nonce_here" + b"\x00" * (64 - len(b"your_nonce_here"))
try:
    engine.verify_report(report_bytes, nonce)
    print("✓ Attestation verified successfully!")
except Exception as e:
    print(f"✗ Verification failed: {e}")
```

## API Reference

### Factory Pattern

```python
from dk_tee_attestation import AttestationEngineFactory, AttestationEngineType

# Get AMD SEV-SNP engine
engine = AttestationEngineFactory.get(AttestationEngineType.amd_sev_snp)

# Get Intel TDX engine (when available)
# engine = AttestationEngineFactory.get(AttestationEngineType.intel_tdx)
```

### AttestationEngine Interface

#### `get_report(report_data: bytes) -> bytes`

Generate a TEE attestation report.

**Parameters:**
- `report_data` (bytes): Nonce/challenge, must be exactly 64 bytes

**Returns:**
- Raw attestation report bytes

**Raises:**
- `ReportDataError`: If report_data is invalid
- `FirmwareOpenErrorAmdSevSnp`: If TEE firmware is unavailable

#### `verify_report(report_bytes: bytes, expected_report_data: bytes) -> None`

Verify a TEE attestation report.

**Parameters:**
- `report_bytes` (bytes): Raw attestation report to verify
- `expected_report_data` (bytes): Expected nonce, must be exactly 64 bytes

**Returns:**
- None on successful verification

**Raises:**
- `ReportDataError`: If nonce doesn't match
- `KdsFetchError`: If certificate fetch fails
- `CertChainError`: If certificate chain is invalid
- `SignatureError`: If signature verification fails
- `MetadataMismatchError`: If metadata doesn't match

### Exception Hierarchy

```
AttestationError (base)
├── ReportDataError
├── ReportBytesError
├── KdsFetchError
├── CertChainError
├── MetadataMismatchError
├── SignatureError
├── UnsupportedChipFamilyError
├── UnsupportedEngine
├── FirmwareOpenErrorAmdSevSnp
└── AttestationParseErrorAmdSevSnp
```

## Verification Process

### AMD SEV-SNP Verification Steps

1. **Parse Report**: Extract structured data from raw bytes
2. **Validate Nonce**: Ensure nonce matches expected value
3. **Fetch Certificates**: Retrieve ARK, ASK, and VCEK from AMD KDS
4. **Verify Chain**: Validate certificate chain signatures
5. **Check Metadata**: Ensure TCB and hardware ID match
6. **Verify Signature**: Validate report signature with VCEK

## Integration with FHEnom AI

This library is integrated into the [FHEnom AI SDK](https://pypi.org/project/fhenomai/):

```bash
# Install FHEnom AI with attestation support
pip install fhenomai

# Use via FHEnom AI client
from fhenomai import FHEnomClient

client = FHEnomClient.from_config()
result = client.admin.verify_attestation(report_bytes, nonce_hex)
```

## Requirements

- Python >= 3.8
- cryptography >= 46.0.0
- requests >= 2.32.0

### Optional (for report generation/verification):
- Rust toolchain (for building native module)
- maturin >= 1.11.0

## Platform-Specific Notes

### AMD SEV-SNP

- Requires access to `/dev/sev-guest` device for report generation
- Fetches certificates from AMD Key Distribution Service (KDS)
- Supports Milan, Genoa, and Turin processor families

### Intel TDX

- Coming soon

## Use Cases

- **Remote Attestation**: Prove code runs in genuine TEE
- **Zero-Trust Security**: Establish trust before sensitive operations
- **Compliance**: Demonstrate hardware-backed security
- **Confidential Computing**: Verify encrypted model execution

## Development

### Building from Source

```bash
git clone https://devops.datakrypto.com/DataKrypto/_git/fhenom_tee_attestation
cd fhenom_tee_attestation

# Install in development mode
pip install -e .

# Build Rust module
cd rust_lib
maturin develop --release
```

### Running Examples

See the `python_license_manager_example/` and `python_sev_snp_tee_example/` directories for complete working examples.

## Security Considerations

- **Nonce Generation**: Always use cryptographically secure random nonces
- **Nonce Storage**: Store nonces securely for verification
- **Certificate Validation**: Library automatically validates full certificate chain
- **Network Security**: Certificate fetching uses HTTPS to AMD KDS

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

- **Documentation**: [FHEnom AI Docs](https://docs.datakrypto.ai)
- **Issues**: [GitHub Issues](https://github.com/datakrypto/fhenomai/issues)
- **Email**: support@datakrypto.ai

## Acknowledgments

- AMD for SEV-SNP platform and KDS infrastructure
- Rust cryptography ecosystem
- PyO3 for Python-Rust bindings

## Related Projects

- [FHEnom AI](https://pypi.org/project/fhenomai/) - Confidential AI platform
- [AMD SEV-SNP Documentation](https://www.amd.com/en/developer/sev.html)

---

**Made with ❤️ by DataKrypto**
