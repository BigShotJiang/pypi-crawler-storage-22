"""
Attestation report formatting and visualization.
"""
from __future__ import annotations
import re
from typing import Optional, Dict, Any
from pathlib import Path

from dk_tee_attestation.tee_attestation_dataclasses import ParsedAttestationReport, ReportedTcb, CpuId
from dk_tee_attestation.report_styles import (
    GREEN, CYAN, YELLOW, BLUE, MAGENTA, RESET, BOLD,
    KDS_CERT_SITE, KDS_VCEK_PATH, KDS_CERT_CHAIN_PATH,
    LEGEND, HTML_TEMPLATE, SECTION_COLORS, REPORT_SECTIONS,
    CPUID_FAM_ID_OFF, CPUID_MOD_ID_OFF, CPUID_STEP_OFF,
)

try:
    import tee_amd_sev_snp_rust_py_wrap
except ImportError:
    tee_amd_sev_snp_rust_py_wrap = None


class AttestationReportFormatter:
    """
    Format AMD SEV-SNP attestation reports with visual styling.
    
    Supports multiple output formats:
    - standard: Structured fields (parsed data)
    - detailed: ANSI-colored terminal output with hex dump and highlights
    - html: Standalone HTML file with embedded CSS and dark terminal theme
    - pdf: PDF document generated from HTML
    """
    
    def __init__(self, line_width: int = 64):
        """
        Initialize formatter.
        
        Args:
            line_width: Character width for formatting (default: 64)
        """
        self.line_width = line_width
        self._ansi_re = re.compile(r"\x1b\[[0-9;]*m")
    
    def _parse_report(self, report_bytes: bytes) -> ParsedAttestationReport:
        """
        Parse raw report bytes into structured data.
        
        Args:
            report_bytes: Raw attestation report bytes
            
        Returns:
            ParsedAttestationReport object
            
        Raises:
            ValueError: If parsing fails or rust wrapper not available
        """
        if tee_amd_sev_snp_rust_py_wrap is None:
            raise ValueError("tee_amd_sev_snp_rust_py_wrap module not available")
        
        parsed_report = tee_amd_sev_snp_rust_py_wrap.parse_report(report_bytes)
        
        return ParsedAttestationReport(
            chip_id=parsed_report["chip_id"],
            report_data=parsed_report["report_data"],
            reported_tcb=ReportedTcb(**parsed_report["reported_tcb"]),
            cpuid=CpuId(**parsed_report["cpuid"]),
            signed_bytes=parsed_report["signed_bytes"],
            sig_r=parsed_report["sig_r"],
            sig_s=parsed_report["sig_s"],
        )
    
    def format_standard(
        self,
        report_bytes: bytes,
        verification_result: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Format report as structured fields (standard output).
        
        Args:
            report_bytes: Raw attestation report bytes
            verification_result: Optional verification details
            
        Returns:
            Formatted string with parsed fields
        """
        try:
            parsed = self._parse_report(report_bytes)
        except Exception as e:
            return f"{YELLOW}Warning: Could not parse report: {e}{RESET}\n"
        
        output = []
        output.append(f"\n{BOLD}{GREEN}=== Attestation Report ==={RESET}\n")
        
        # CPU Information
        output.append(f"{BOLD}CPU Information:{RESET}")
        output.append(f"  Family:    {BLUE}0x{parsed.cpuid.fam_id:02x}{RESET}")
        output.append(f"  Model:     {BLUE}0x{parsed.cpuid.mod_id:02x}{RESET}")
        output.append(f"  Stepping:  {BLUE}0x{parsed.cpuid.step:02x}{RESET}\n")
        
        # TCB Versions
        output.append(f"{BOLD}Trusted Computing Base (TCB):{RESET}")
        output.append(f"  Bootloader: {YELLOW}{parsed.reported_tcb.bootloader}{RESET}")
        output.append(f"  TEE:        {YELLOW}{parsed.reported_tcb.tee}{RESET}")
        output.append(f"  SNP:        {YELLOW}{parsed.reported_tcb.snp}{RESET}")
        output.append(f"  Microcode:  {YELLOW}{parsed.reported_tcb.microcode}{RESET}\n")
        
        # Chip ID
        chip_id_hex = parsed.chip_id.hex()
        output.append(f"{BOLD}Chip ID:{RESET}")
        output.append(f"  {CYAN}{chip_id_hex[:64]}{RESET}")
        output.append(f"  {CYAN}{chip_id_hex[64:]}{RESET}\n")
        
        # Report Data (Nonce)
        report_data_hex = parsed.report_data.hex()
        output.append(f"{BOLD}Report Data (Nonce):{RESET}")
        output.append(f"  {CYAN}{report_data_hex[:64]}{RESET}")
        output.append(f"  {CYAN}{report_data_hex[64:]}{RESET}\n")
        
        # Signature
        sig_r_hex = parsed.sig_r.hex()
        sig_s_hex = parsed.sig_s.hex()
        output.append(f"{BOLD}ECDSA Signature:{RESET}")
        output.append(f"  R: {MAGENTA}{sig_r_hex[:64]}{RESET}")
        output.append(f"     {MAGENTA}{sig_r_hex[64:128]}{RESET}")
        output.append(f"     {MAGENTA}{sig_r_hex[128:]}{RESET}")
        output.append(f"  S: {MAGENTA}{sig_s_hex[:64]}{RESET}")
        output.append(f"     {MAGENTA}{sig_s_hex[64:128]}{RESET}")
        output.append(f"     {MAGENTA}{sig_s_hex[128:]}{RESET}\n")
        
        # Verification result
        if verification_result:
            if verification_result.get('verified'):
                output.append(f"{BOLD}{GREEN}✓ Verification: PASSED{RESET}")
            else:
                output.append(f"{BOLD}{YELLOW}✗ Verification: FAILED{RESET}")
                if 'error' in verification_result:
                    output.append(f"  Error: {verification_result['error']}")
        
        return "\n".join(output)
    
    def format_detailed(
        self, 
        report_bytes: bytes, 
        nonce: Optional[bytes] = None,
        verification_result: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Format report with ANSI colors and detailed breakdown.
        
        Args:
            report_bytes: Raw attestation report bytes
            nonce: Optional nonce used for generation (for display)
            verification_result: Optional verification details from verify_attestation
            
        Returns:
            ANSI-colored formatted string
        """
        output = []
        
        # Legend
        output.append(self._format_legend())
        
        # Report hex dump with highlights
        output.append(self._centered_title("Attestation report bytes (hex)"))
        output.append(self._format_hex_dump(report_bytes))
        output.append("-" * self.line_width + "\n")
        
        # CPU family derivation
        cpu_info = self._extract_cpuid(report_bytes)
        output.append(self._centered_title("Deriving CPU family name"))
        cpuid_str = f"{BLUE}{cpu_info['fam_id']:02x}{cpu_info['mod_id']:02x}{cpu_info['step']:02x}{RESET}"
        output.append(self._center_text(f"{cpuid_str} ---> {BLUE}{cpu_info['family']}{RESET}"))
        output.append("-" * self.line_width + "\n")
        
        # AMD KDS URLs
        if verification_result:
            output.append(self._format_verification_steps(report_bytes, cpu_info, verification_result))
        
        return "\n".join(output)
    
    def format_html(
        self, 
        report_bytes: bytes, 
        nonce: Optional[bytes] = None,
        verification_result: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Format report as standalone HTML document.
        
        Args:
            report_bytes: Raw attestation report bytes
            nonce: Optional nonce used for generation
            verification_result: Optional verification details
            
        Returns:
            Complete HTML document as string
        """
        # Generate ANSI-colored content
        ansi_content = self.format_detailed(report_bytes, nonce, verification_result)
        
        # Convert ANSI to HTML spans
        html_content = self._ansi_to_html(ansi_content)
        
        # Wrap in template
        return HTML_TEMPLATE.format(content=html_content)
    
    def format_pdf(
        self, 
        report_bytes: bytes, 
        nonce: Optional[bytes] = None,
        verification_result: Optional[Dict[str, Any]] = None,
        output_path: Optional[str] = None
    ) -> bytes:
        """
        Format report as PDF document.
        
        Args:
            report_bytes: Raw attestation report bytes
            nonce: Optional nonce used for generation
            verification_result: Optional verification details
            output_path: Optional path to save PDF (if None, returns bytes)
            
        Returns:
            PDF bytes if output_path is None, otherwise None
        """
        try:
            from weasyprint import HTML
        except ImportError:
            raise ImportError(
                "PDF generation requires weasyprint. "
                "Install with: pip install weasyprint"
            )
        
        # Generate HTML
        html_content = self.format_html(report_bytes, nonce, verification_result)
        
        # Convert to PDF
        pdf_bytes = HTML(string=html_content).write_pdf()
        
        if output_path:
            Path(output_path).write_bytes(pdf_bytes)
            return None
        else:
            return pdf_bytes
    
    # =========================================================================
    # Private helper methods
    # =========================================================================
    
    def _format_legend(self) -> str:
        """Format color legend."""
        output = []
        output.append(self._centered_title("Colors Legend", fill="-"))
        
        for name, color_key in LEGEND:
            color = SECTION_COLORS[color_key]
            label = f"{color}{name}{RESET}"
            output.append(self._center_text(label))
        
        output.append("-" * self.line_width + "\n")
        return "\n".join(output)
    
    def _format_hex_dump(self, report_bytes: bytes) -> str:
        """Format report bytes as hex dump with color highlights."""
        hex_str = report_bytes.hex()
        output = []
        
        # Build color map by hex offset
        color_map = {}
        for section_name, section_info in REPORT_SECTIONS.items():
            start_offset = section_info['offset'] * 2
            end_offset = (section_info['offset'] + section_info['length']) * 2
            color = SECTION_COLORS[section_info['color']]
            
            for i in range(start_offset, end_offset, 2):
                color_map[i] = color
        
        # Format with colors
        for i in range(0, len(hex_str), self.line_width):
            chunk = hex_str[i:i + self.line_width]
            formatted = []
            
            for j in range(0, len(chunk), 2):
                hex_offset = i + j
                byte_str = chunk[j:j+2]
                
                if hex_offset in color_map:
                    formatted.append(f"{color_map[hex_offset]}{byte_str}{RESET}")
                else:
                    formatted.append(byte_str)
            
            output.append("".join(formatted))
        
        return "\n".join(output)
    
    def _extract_cpuid(self, report_bytes: bytes) -> Dict[str, Any]:
        """Extract CPUID information and derive CPU family name."""
        fam = report_bytes[CPUID_FAM_ID_OFF]
        mod = report_bytes[CPUID_MOD_ID_OFF]
        step = report_bytes[CPUID_STEP_OFF]
        
        # Derive family name
        family = None
        if fam == 0x19:
            family = "Milan" if mod < 0x10 else "Genoa"
        elif fam == 0x1A:
            family = "Turin"
        
        if family is None:
            family = f"Unknown (0x{fam:02x})"
        
        return {
            'family': family,
            'fam_id': fam,
            'mod_id': mod,
            'step': step,
        }
    
    def _format_verification_steps(
        self, 
        report_bytes: bytes, 
        cpu_info: Dict[str, Any],
        verification_result: Dict[str, Any]
    ) -> str:
        """Format verification steps with URLs and results."""
        output = []
        
        # ARK/ASK request
        output.append(self._centered_title("Requesting AMD ARK and ASK certificates"))
        ark_url = f"{KDS_CERT_SITE}{KDS_VCEK_PATH}/{BLUE}{cpu_info['family']}{RESET}/{KDS_CERT_CHAIN_PATH}"
        output.append(self._center_text(ark_url, wrap=True))
        output.append("-" * self.line_width + "\n")
        
        # VCEK request info
        chip_id = report_bytes[0x1A0:0x1A0 + 0x40]
        tcb_bytes = report_bytes[0x180:0x180 + 0x08]
        bl_spl = tcb_bytes[0]
        tee_spl = tcb_bytes[1]
        snp_spl = tcb_bytes[6]
        ucode_spl = tcb_bytes[7]
        
        output.append(self._centered_title("Deriving informations to request VCEK"))
        output.append(self._center_text(f"Family name: {BLUE}{cpu_info['family']}{RESET}"))
        chip_id_hex = binascii.hexlify(chip_id).decode("ascii")
        output.append(self._center_text(f"Chip id: {CYAN}{chip_id_hex[:32]}...{RESET}"))
        output.append(self._center_text("Trusted computing base:"))
        output.append(self._center_text(f"bootloader: {YELLOW}{bl_spl:02}{RESET}"))
        output.append(self._center_text(f"tee: {YELLOW}{tee_spl:02}{RESET}"))
        output.append(self._center_text(f"snp: {YELLOW}{snp_spl:02}{RESET}"))
        output.append(self._center_text(f"microcode: {YELLOW}{ucode_spl:02}{RESET}"))
        output.append("-" * self.line_width + "\n")
        
        # Verification results
        if verification_result.get('verified'):
            output.append(self._centered_title("Verification Result"))
            output.append(self._center_text(f"{GREEN}✓ Attestation verified successfully!{RESET}"))
            output.append(self._center_text(f"Platform: {verification_result.get('platform', 'AMD SEV-SNP')}"))
            output.append("-" * self.line_width + "\n")
        
        return "\n".join(output)
    
    def _ansi_to_html(self, ansi_text: str) -> str:
        """Convert ANSI color codes to HTML spans."""
        import html as html_module
        
        # First escape HTML entities in the text
        escaped = html_module.escape(ansi_text)
        
        # Then replace ANSI codes with actual HTML tags (unescape the markers)
        ansi_to_html_map = {
            '\\033[32m': '<span class="color-green">',
            '\\033[36m': '<span class="color-cyan">',
            '\\033[33m': '<span class="color-yellow">',
            '\\033[34m': '<span class="color-blue">',
            '\\033[35m': '<span class="color-magenta">',
            '\\033[37m': '<span class="color-white">',
            '\\033[0m': '</span>',
            '\\033[1m': '<strong>',
        }
        
        result = escaped
        for ansi_code, html_tag in ansi_to_html_map.items():
            # The escape() turned \033 into literal text, so match that
            result = result.replace(ansi_code.replace('\\033', '\x1b'), html_tag)
        
        # Clean up any remaining ANSI codes  
        result = self._ansi_re.sub('', result)
        
        return result
    
    def _centered_title(self, title: str, fill: str = "-") -> str:
        """Create centered title with fill characters."""
        title = f" {title} "
        if len(title) >= self.line_width:
            return title[:self.line_width]
        return title.center(self.line_width, fill)
    
    def _center_text(self, text: str, wrap: bool = False) -> str:
        """Center text, optionally wrapping long lines."""
        visible_len = len(self._ansi_re.sub('', text))
        
        if wrap and visible_len > self.line_width:
            # Simple wrap for long URLs
            lines = []
            current_line = ""
            for char in text:
                current_line += char
                if len(self._ansi_re.sub('', current_line)) >= self.line_width:
                    lines.append(current_line)
                    current_line = ""
            if current_line:
                lines.append(current_line)
            return "\n".join(self._center_text(line) for line in lines)
        
        pad = self.line_width - visible_len
        if pad <= 0:
            return text
        
        left = pad // 2
        right = pad - left
        return " " * left + text + " " * right
    
    def _strip_ansi(self, text: str) -> str:
        """Remove ANSI escape codes."""
        return self._ansi_re.sub('', text)
