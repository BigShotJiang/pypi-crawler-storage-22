"""
Styling constants and templates for attestation report formatting.
"""

# ANSI color codes for terminal output
BLACK = "\033[30m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"
RESET = "\033[0m"
BOLD = "\033[1m"

# Color mapping for report sections
SECTION_COLORS = {
    'nonce': GREEN,
    'chip_id': CYAN,
    'tcb': YELLOW,
    'cpuid': BLUE,
    'signature': MAGENTA,
}

# AMD SEV-SNP report byte offsets
REPORT_SECTIONS = {
    'report_data': {'offset': 0x50, 'length': 0x40, 'color': 'nonce'},
    'reported_tcb': {'offset': 0x180, 'length': 0x08, 'color': 'tcb'},
    'cpuid': {'offset': 0x188, 'length': 0x03, 'color': 'cpuid'},
    'chip_id': {'offset': 0x1A0, 'length': 0x40, 'color': 'chip_id'},
    'signature': {'offset': 0x2A0, 'length': 0x200, 'color': 'signature'},
}

# Specific field offsets within sections
CPUID_FAM_ID_OFF = 0x188
CPUID_MOD_ID_OFF = 0x189
CPUID_STEP_OFF = 0x18A

# Signature sub-components (ECDSA P-384)
SIG_R_OFF = 0x00
SIG_R_LEN = 0x48  # 72 bytes
SIG_S_OFF = 0x48
SIG_S_LEN = 0x48  # 72 bytes

# Legend for colored output
LEGEND = [
    ("User challenge (nonce)", "nonce"),
    ("Hardware identifier (chip id)", "chip_id"),
    ("Trusted computing base informations (tcb)", "tcb"),
    ("CPU family, model, stepping informations (cpuid)", "cpuid"),
    ("Elliptic Curve Digital Signature Algorithm (ECDSA)", "signature"),
]

# HTML template for report visualization
HTML_TEMPLATE = """<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>AMD SEV-SNP Attestation Report</title>
  <style>
    /* White page background */
    body {{
      margin: 0;
      padding: 24px;
      background: #ffffff;
      color: #111;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
    }}

    /* Header area */
    .meta {{
      max-width: 900px;
      margin: 0 auto 14px auto;
      font-size: 13px;
      line-height: 1.4;
    }}

    .meta-link {{
      text-align: center;
      margin-top: 6px;
    }}
    
    .meta a {{
      color: #0b57d0;
      text-decoration: underline;
      word-break: break-all;
    }}

    /* Terminal "photo" */
    .terminal {{
      width: fit-content;
      max-width: 900px;
      margin: 0 auto;
      background: #0C0C0C;
      border: 1px solid #222;
      border-radius: 12px;
      padding: 16px 18px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.12);
    }}

    /* Pre-formatted terminal output */
    pre {{
      max-width: 100%;
      margin: 0;
      white-space: pre-wrap;
      word-break: break-word;
      font-family: "JetBrains Mono", "Fira Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 9pt;
      line-height: 1.15;
      color: #e6e6e6;
    }}

    /* Color classes matching ANSI codes */
    .color-green  {{ color: rgb(19, 153, 14) !important; }}
    .color-cyan   {{ color: rgb(133, 201, 255) !important; }}
    .color-yellow {{ color: rgb(255, 219, 74) !important; }}
    .color-blue   {{ color: rgb(0, 53, 209) !important; }}
    .color-magenta {{ color: rgb(133, 27, 148) !important; }}
    .color-white  {{ color: rgb(211, 215, 207) !important; }}

    /* Print optimization */
    @media print {{
      body {{
        padding: 0;
      }}
      .terminal {{
        box-shadow: none;
        border: 1px solid #222;
        page-break-inside: avoid;
      }}
    }}

    @page {{
      size: A4;
      margin: 10mm;
    }}
  </style>
</head>

<body>
  <div class="meta">
    <div><strong>AMD SEV-SNP Attestation Report Verification</strong></div>
    <div class="meta-link">
      For more information, see: <a href="https://github.com/virtee/snpguest">https://github.com/virtee/snpguest</a>
    </div>
  </div>

  <div class="terminal">
    <pre>{content}</pre>
  </div>
</body>

</html>
"""

# AMD KDS constants
KDS_CERT_SITE = "https://kdsintf.amd.com"
KDS_VCEK_PATH = "/vcek/v1"
KDS_CERT_CHAIN_PATH = "cert_chain"
