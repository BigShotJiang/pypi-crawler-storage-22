"""
General utility functions.
"""
