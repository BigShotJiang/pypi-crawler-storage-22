"""Data classifications and enumerations."""
