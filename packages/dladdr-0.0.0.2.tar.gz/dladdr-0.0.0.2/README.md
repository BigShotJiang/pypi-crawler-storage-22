## python-dladdr

dladdr binding using ctypes. potentially useful to debug CDLL symbols exporter.

Please **do not run on Windows,** it will not work, even not sure what side effects will happen.

## test status

Has been tested on macOS / Linux / FreeBSD.

Android has been tested using only (my) C implementation, so not sure it works.
