"""
Application Layer

Contains use cases that orchestrate the flow of data and business rules.
This layer depends only on the domain layer.
"""
