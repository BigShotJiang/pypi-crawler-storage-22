"""
Domain Layer

Contains business entities, repository interfaces, and service contracts.
This layer has no dependencies on external frameworks or infrastructure.
"""
