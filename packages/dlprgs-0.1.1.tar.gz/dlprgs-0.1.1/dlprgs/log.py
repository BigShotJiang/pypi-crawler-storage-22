from importlib import resources

def print_file(no: int):
    filename = f"{no}.txt"

    try:
        with resources.files("numbered_printer.data").joinpath(filename).open("r") as f:
            print(f.read())
    except FileNotFoundError:
        raise ValueError(f"No file found for number: {no}")
