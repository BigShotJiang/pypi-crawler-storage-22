import{w as s}from"./svelte-fOWjK6Sw.js";const o=s(null);export{o as s};
