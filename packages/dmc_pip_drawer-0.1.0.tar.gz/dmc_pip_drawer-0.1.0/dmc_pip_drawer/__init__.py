"""dmc-pip-drawer — Glass morphism Drawer + ScrollArea for Dash Mantine Components."""

from pathlib import Path

from .pip_drawer import PipDrawer

__version__ = "0.1.0"


def get_css_path() -> str:
    """Return the absolute path to pip_drawer.css for use with external_stylesheets."""
    return str(Path(__file__).parent / "pip_drawer.css")


def get_css_url() -> str:
    """Return the asset URL path (for use when CSS is in the assets/ folder)."""
    return "/assets/pip_drawer.css"


__all__ = ["PipDrawer", "get_css_path", "get_css_url"]
