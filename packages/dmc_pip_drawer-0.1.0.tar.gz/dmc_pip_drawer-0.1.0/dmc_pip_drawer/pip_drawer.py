"""PipDrawer — A pre-configured DMC Drawer with glass morphism ScrollArea."""

from typing import Any, Optional

import dash_mantine_components as dmc
from dash import html


def PipDrawer(
    id: str,
    children: Any = None,
    title: str = "",
    opened: bool = False,
    position: str = "bottom",
    size: str = "92%",
    scroll_type: str = "auto",
    className: str = "",
    padding: str = "md",
    glass_opacity: float = 0.85,
    **drawer_props: Any,
) -> dmc.Drawer:
    """Create a Drawer with single-scroll-overlay pattern and glass morphism scrollbar.

    Args:
        id: Component ID for use in Dash callbacks (targets `opened` prop).
        children: Content rendered inside the ScrollArea.
        title: Drawer header title text.
        opened: Whether the drawer is open. Control via callback.
        position: Drawer slide direction — "bottom", "top", "left", "right".
        size: Drawer size (height for bottom/top, width for left/right).
        scroll_type: ScrollArea scroll behavior — "auto", "always", "scroll", "hover", "never".
        className: Additional CSS classes appended to "pip-drawer".
        padding: Padding around the content inside ScrollArea.
        glass_opacity: Glass morphism background opacity (0.0 = fully transparent,
            1.0 = fully opaque). Default 0.85. Controls how much content behind
            the drawer is visible through the frosted glass effect.
        **drawer_props: Additional props passed through to dmc.Drawer.

    Returns:
        A configured dmc.Drawer component.
    """
    opacity = max(0.0, min(1.0, glass_opacity))
    classes = f"pip-drawer {className}".strip()

    return dmc.Drawer(
        id=id,
        opened=opened,
        position=position,
        size=size,
        title=title,
        className=classes,
        styles={
            "root": {
                "--pip-drawer-opacity": str(opacity),
            },
            "content": {
                "overflow": "hidden",
            },
            "body": {
                "flex": "1",
                "minHeight": "0",
                "overflow": "hidden",
                "padding": "0",
            },
        },
        children=[
            dmc.ScrollArea(
                offsetScrollbars=True,
                type=scroll_type,
                style={"height": "100%"},
                children=[
                    html.Div(
                        children,
                        style={"padding": f"var(--mantine-spacing-{padding})"},
                    )
                ],
            )
        ],
        **drawer_props,
    )
