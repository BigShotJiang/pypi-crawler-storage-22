# DMG Diagnostic Module: Integração do Agente de Diagnóstico ao Painel Cliente e Admin

## 📌 Visão Geral

O `DMG Diagnostic Module` é um módulo adicional integrado ao sistema existente que permite:

- Receber diagnósticos enviados pelo agente Python.
- Processar e classificar problemas automaticamente.
- Exibir resumo no painel do cliente.
- Desbloquear relatório completo após pagamento.
- Permitir análise e gestão no painel admin.

Este módulo não altera a arquitetura existente, apenas adiciona novas rotas, lógica de negócio e interfaces.

## 🏗️ Arquitetura

O fluxo é dividido em três camadas:

1.  **Agente Python (externo)**
2.  **Backend (integração + processamento)**
3.  **Painéis (Cliente e Admin)**

## 🔄 Fluxo Completo

1.  Cliente executa o agente no servidor.
2.  O agente envia um JSON estruturado para o backend.
3.  O backend valida e armazena o diagnóstico.
4.  O sistema calcula health score e severidade.
5.  O cliente visualiza resumo no painel.
6.  Após pagamento, relatório completo é desbloqueado.
7.  Admin pode visualizar e gerar proposta.

## 🧩 Endpoints Criados

### `POST /api/diagnostic/upload`

Recebe o relatório do agente.

- **Requisitos:**
    - Token obrigatório.
    - Validação da estrutura JSON.
    - Limite de tamanho.
    - Registro de logs.
- **Ações:**
    - Processa relatório.
    - Calcula health score.
    - Classifica severidade.
    - Salva no banco.

### `GET /api/diagnostic/my-reports`

Lista relatórios do cliente autenticado.

- **Retorna:**
    - `id`
    - `data`
    - `score`
    - `severidade`
    - `status` (locked/unlocked)

### `GET /api/diagnostic/:id`

Retorna relatório específico.

- Se não pago → apenas resumo.
- Se pago → relatório completo.

### `GET /api/admin/diagnostic/all`

Lista todos os relatórios (admin).

- **Permite:**
    - Filtro por cliente.
    - Filtro por severidade.
    - Inserção de nota técnica.
    - Geração de proposta.

## 🗄️ Estrutura do Banco

**Tabela:** `diagnostics`

| Campo              | Tipo      | Descrição                       |
| ------------------ | --------- | ------------------------------- |
| `id`               | UUID      | Identificador único             |
| `user_id`          | UUID      | Cliente                         |
| `project_name`     | string    | Nome do projeto                 |
| `scan_type`        | string    | `basic`/`deep`                  |
| `health_score`     | int       | 0–100                           |
| `severity_level`   | string    | `low`/`medium`/`high`/`critical` |
| `summary_json`     | JSON      | Resumo                          |
| `full_report_json` | JSON      | Relatório completo              |
| `is_unlocked`      | boolean   | Liberado após pagamento         |
| `payment_status`   | string    | `pending`/`paid`                |
| `admin_notes`      | text      | Observações internas            |
| `created_at`       | timestamp | Data                            |

## 🧠 Health Score

Score calculado com base em:

- Problemas críticos
- Erros de build
- Falhas SSL
- Vulnerabilidades
- Problemas de configuração

**Exemplo:**
`100 – (10 x críticos) – (5 x altos) – (2 x médios)`

**Classificação:**

- **90–100** → Saudável
- **70–89** → Atenção
- **40–69** → Risco
- **0–39** → Crítico

## 💰 Integração com Pagamento

Quando relatório é criado:

- `status` = `locked`
- Cliente vê apenas resumo.

Após pagamento (Stripe já existente):

- `is_unlocked` = `true`
- `payment_status` = `paid`
- Relatório completo liberado.

## 🖥️ Painel do Cliente

### Nova seção: Diagnóstico Técnico

- **Página Histórico**
    - Lista de relatórios
    - Score visual
    - Status
    - Botão "detalhes"
- **Página Relatório**
    - Se `locked`:
        - Mostrar resumo
        - Botão "desbloquear"
    - Se `unlocked`:
        - Sistema
        - SSL
        - Projeto
        - Build
        - Segurança
        - Recomendações

## 🧑‍💼 Painel Admin

### Nova seção: Diagnostics

- **Funcionalidades:**
    - Ver todos relatórios
    - Filtros
    - Notas técnicas
    - Gerar orçamento
    - Alterar valor manualmente
    - Exportar PDF

## 🔐 Segurança

- Token obrigatório no upload.
- Rate limit.
- Limite de payload.
- Logs de auditoria.
- Relatórios armazenados criptografados.
- Nenhuma modificação no servidor do cliente.

## 📡 Estrutura do JSON Recebido

```json
{
  "agent_version": "1.0.0",
  "scan_type": "deep",
  "system": {},
  "ssl": {},
  "nginx": {},
  "project": {},
  "build": {},
  "security": {},
  "errors_summary": [],
  "timestamp": ""
}
```

## 🚀 Preparado para Expansão SaaS

Estrutura permite:

- Monitoramento recorrente.
- Histórico evolutivo.
- Comparação entre scans.
- Plano mensal.
- Alertas automáticos.

## 📌 Dependências

- Sistema de autenticação já existente.
- Stripe já configurado.
- Banco de dados já ativo.
- Nenhuma refatoração estrutural necessária.

## 🎯 Resultado Final

O sistema passa a oferecer:

- Diagnóstico automatizado.
- Classificação inteligente.
- Monetização integrada.
- Gestão técnica centralizada.
- Base para produto SaaS DevOps.
