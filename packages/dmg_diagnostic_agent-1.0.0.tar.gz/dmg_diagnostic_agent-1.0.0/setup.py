
from setuptools import setup, find_packages

setup(
    name="dmg_diagnostic_agent",
    version="1.0.0",
    author="Tech Lab",
    description="An agent to diagnose and report issues in web servers and projects.",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://github.com/seu-usuario/dmg-diagnostic-agent",  # Altere para a URL real
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        "psutil",
        "requests",
        # Outras dependências, se houver
    ],
    entry_points={
        'console_scripts': [
            'dmg-agent=dmg_diagnostic_agent.cli.main:main',
        ],
    },
)
