import os
import sys
import shutil
import subprocess
import glob

from setuptools import find_packages, setup, Command

NAME = 'dms-influx2'
DESCRIPTION = 'Library to connect and retrieve data from DMS influxdb'
URL = 'https://github.com/belingarb/dms-influx2'
EMAIL = 'bozidar.belingar@gmail.com'
AUTHOR = 'Bozidar Belingar'
REQUIRES_PYTHON = '>=3.8.0'
VERSION = '0.4.4'

# Get required packages from requirements.txt file
with open('requirements/base.txt') as f:
    REQUIRED = f.read().splitlines()

dir_path = os.path.abspath(os.path.dirname(__file__))

long_description = DESCRIPTION

about = {}
if not VERSION:
    project_slug = NAME.lower().replace("-", "_").replace(" ", "_")
    with open(os.path.join(dir_path, project_slug, '__version__.py')) as f:
        exec(f.read(), about)
else:
    about['__version__'] = VERSION


class UploadCommand(Command):
    """Support setup.py upload."""

    description = 'Build and publish the package.'
    user_options = []

    @staticmethod
    def status(s):
        """Prints things in bold."""
        print('\033[1m{0}\033[0m'.format(s))

    def initialize_options(self):
        pass

    def finalize_options(self):
        pass

    def run(self):
        try:
            self.status('Removing previous builds…')
            if os.path.exists(os.path.join(dir_path, 'dist')):
                shutil.rmtree(os.path.join(dir_path, 'dist'))
            if os.path.exists(os.path.join(dir_path, 'build')):
                shutil.rmtree(os.path.join(dir_path, 'build'))
            if os.path.exists(os.path.join(dir_path, f'{NAME}.egg-info')):
                shutil.rmtree(os.path.join(dir_path, f'{NAME}.egg-info'))
        except OSError:
            pass

        self.status('Building Source and Wheel (universal) distribution…')
        try:
            subprocess.check_call([sys.executable, '-m', 'build'])
        except subprocess.CalledProcessError:
            raise
        except Exception:
            subprocess.check_call([sys.executable, 'setup.py', 'sdist', 'bdist_wheel'])

        self.status('Uploading the package to PyPI via Twine…')
        dists = sorted(glob.glob(os.path.join('dist', '*')))
        if not dists:
            raise FileNotFoundError('No distributions found in dist/. Did the build step succeed?')
        subprocess.check_call([sys.executable, '-m', 'twine', 'upload', *dists])

        self.status('Pushing git tags…')
        tag_name = 'v{0}'.format(about['__version__'])
        existing_tag = subprocess.run(
            ['git', 'rev-parse', '-q', '--verify', f'refs/tags/{tag_name}'],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if existing_tag.returncode != 0:
            subprocess.check_call(['git', 'tag', '-a', tag_name, '-m', f'Release {tag_name}'])
        subprocess.check_call(['git', 'push', '--tags'])

        sys.exit()


setup(
    name=NAME,
    version=about['__version__'],
    description=DESCRIPTION,
    long_description=long_description,
    long_description_content_type='text/markdown',
    author=AUTHOR,
    author_email=EMAIL,
    python_requires=REQUIRES_PYTHON,
    url=URL,
    packages=find_packages(exclude=["tests", "*.tests", "*.tests.*", "tests.*", "cli", "venv"]),
    install_requires=REQUIRED,
    include_package_data=True,
    license='MIT',
    classifiers=[
        # Trove classifiers
        # Full list: https://pypi.python.org/pypi?%3Aaction=list_classifiers
         'Programming Language :: Python :: 3.8',
         'Programming Language :: Python :: 3.9',
         'Programming Language :: Python :: 3.10',
         'Programming Language :: Python :: 3.11',
         'Programming Language :: Python :: 3.12',
         'Programming Language :: Python :: Implementation :: PyPy'
     ],
     cmdclass={
         'upload': UploadCommand,
     },
)
