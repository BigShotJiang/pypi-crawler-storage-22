from .cli import dna_methylation_cli

if __name__ == "__main__":
    dna_methylation_cli()