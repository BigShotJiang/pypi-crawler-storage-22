import click

@click.command
def dna_methylation_cli():
    pass