# DNAsight  
Code for DNA and cluster segmentation

To train a model run e.g.
```
python dnasight-cmd.py train --folder "data_location1/" "data_location2/" --save_dir model/ --save_plots
```

Examples:


GAF:
```
python dnasight-cmd.py run \
    --folder "data/" \
    --output "output/" \
    --unet "model/unet.pt" \
    --cluster \
    --cluster_quantification \
    --pixel_size_csv "pixelsize.csv" \
    --coverage_quantification \
    --dna_calibration "path=dna_callibration_data/,dna_bp=1059,pixel_size_nm=4.0,perc_low=20,perc_high=95,dna_calibration_threshold=0.8" \
    --dna_calibration "path=second_calibration/,dna_bp=482,pixel_size_nm=2.5"
```

IHF / POLYAMINES:
```

```

COHESIN CTCF / SMC PROTEINS:
```

```

NUCLEOSOMES:
```

```

Or run GUI version:

```
python dnasight-gui.py
```

and choose options in the UI.

