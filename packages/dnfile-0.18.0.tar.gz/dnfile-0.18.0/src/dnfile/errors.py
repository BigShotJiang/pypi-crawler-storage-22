class dnFormatError(Exception):
    pass


class rsrcFormatError(dnFormatError):
    pass
