from ..core.organism import OrganismManager
from ..core.base import BaseEvolvableModule

def print_organism_status(manager: OrganismManager):
    """
    Visualizes the organism's anatomy in the terminal.
    """
    print("\n" + "="*60)
    print(f"🧬 DNO Organism Status (Step {manager.step_counter})")
    print(f"   Structure: {len(manager.registry)} Layers | Inputs: {len(manager.input_nodes)} | Outputs: {len(manager.output_nodes)}")
    print("-" * 60)
    print(f"{'ID':<10} | {'Type':<15} | {'State':<10} | {'Energy':<8} | {'Utility':<8} | {'Link'}")
    print("-" * 60)
    
    # Iterate roughly in topological order (or just registry listing)
    # Group by inputs first might be nicer, but listing all is fine.
    
    for uuid, module in manager.registry.items():
        short_id = uuid[:8]
        type_name = module.child_module.__class__.__name__
        if hasattr(module, 'child_module') and isinstance(module.child_module, (list, tuple)):
             type_name = "Sequential" # Simplified
             
        # Determine State Icon
        state = "🟢 Alive"
        if module.is_immortal:
            state = "🔒 Core"
        elif module.is_dying:
            state = f"🔴 Dying ({module.grace_period_steps})"
        elif module.is_frozen:
            state = "❄️ Frozen"
            
        # Metrics
        energy = f"{module.energy_score:.2f}"
        utility = f"{module.utility_score:.2f}"
        
        # Connections
        children = manager.adjacency_list.get(uuid, [])
        children_str = f"-> {len(children)}"
        
        print(f"{short_id:<10} | {type_name:<15} | {state:<10} | {energy:<8} | {utility:<8} | {children_str}")
        
    print("="*60 + "\n")
