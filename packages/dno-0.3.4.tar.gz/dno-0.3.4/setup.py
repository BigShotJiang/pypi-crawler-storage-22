from setuptools import setup, find_packages

setup(
    name="dno",
    version="0.3.4",
    author="Uğurhan Çolak",
    author_email="ugurhancolak5544@gmail.com",
    description="Dynamic Neural Organism (DNO): A self-evolving, growing, and pruning neural network framework.",
    long_description=open("README.md").read() if open("README.md") else "DNO Framework",
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/dno",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires='>=3.8',
    install_requires=[
        "torch>=1.9.0",
        "numpy",
    ],
    entry_points={
        'console_scripts': [
            # If we want a CLI tool later
            # 'dno=dno.cli:main', 
        ],
    },
)
