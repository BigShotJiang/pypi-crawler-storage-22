import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from typing import List, Dict, Tuple, Optional, Any
from .manager import OrganismManager
from .base import BaseEvolvableModule
import copy
import uuid
from .blueprints import IdentityWrapper

class GrowthEngine:
    """
    The Evolution & Growth Engine.
    Manages Neurogenesis (Growth), Entropy Monitoring, and Optimizer adjustments.
    """
    def __init__(self, network: Any, config: Any):
        # We accept 'network' which should be DynamicNetwork
        self.network = network
        self.manager = network.manager
        self.config = config
        
        # Use Config Params
        self.entropy_threshold = config.entropy_threshold
        self.growth_cooldown = config.growth_cooldown
        # Phase 5: Dynamic Cooldown
        self.evolution_cooldown_steps = getattr(config, 'evolution_cooldown_steps', config.growth_cooldown)
        self.min_loss_improvement = getattr(config, 'min_loss_improvement', 0.0)
        
        self.last_growth_step = 0
        self.last_mitosis_loss = float('inf')
        self._growth_locked_until = 0  # Explicit lock: step'e kadar buyume YASAK
        self.pending_stabilizations = {} 
        
        # Adaptive Entropy Baseline System
        self._entropy_baseline = None  # Calculated after warmup
        self._entropy_window = []      # Collecting during warmup
        self._baseline_window = getattr(config, 'entropy_baseline_window', 50)
        self._spike_factor = getattr(config, 'entropy_spike_factor', 1.5)

    def check_growth_trigger(self, entropy_history: List[float], current_step: int, current_loss: Optional[float] = None) -> Tuple[bool, str]:
        """
        Adaptive Entropy Growth Trigger:
        1. Warmup: Collect entropy, build baseline, no growth.
        2. Monitor: Growth only if entropy SPIKES above baseline.
        3. Post-Growth: Reset baseline for new expert.
        
        Returns: (is_triggered, trigger_reason)
        """
        # 0. Phase Lock
        if self.config.training_phase == 'scratch':
            return False, 'phase_lock'

        # 1. Explicit Cooldown Lock
        if current_step < self._growth_locked_until:
            return False, 'cooldown'

        # 1b. Legacy cooldown check (yedek)
        if current_step - self.last_growth_step < self.evolution_cooldown_steps:
            return False, 'cooldown'
            
        # 2. Loss Improvement Check
        if current_loss is not None and self.last_mitosis_loss != float('inf'):
             if current_loss > self.last_mitosis_loss - self.min_loss_improvement:
                 return False, 'loss_plateau'
            
        # 3. Hardware Constraints
        if self._check_resource_limits():
            if torch.cuda.is_available():
                vram_gb = torch.cuda.memory_allocated() / 1e9
                print(f"[Growth Blocked] VRAM: {vram_gb:.2f}GB / Limit: {self.config.vram_limit_gb}GB")
            total_p = self.calculate_current_params()
            print(f"[Growth Blocked] Params: {total_p:,} / Limit: {self.config.max_param_count:,}")
            return False, 'resource_limit'
            
        if len(entropy_history) < 3:
            return False, 'insufficient_history'
            
        recent = np.array(entropy_history[-3:])
        mean_entropy = np.mean(recent)
        
        # 4. ADAPTIVE ENTROPY BASELINE SYSTEM
        # Warmup phase: baseline henuz belirlenmedi -> entropy topla
        if self._entropy_baseline is None:
            self._entropy_window.append(mean_entropy)
            
            if len(self._entropy_window) >= self._baseline_window:
                # Warmup tamamlandi -> baseline hesapla
                self._entropy_baseline = np.mean(self._entropy_window)
                spike_threshold = self._entropy_baseline * self._spike_factor
                print(f"[Adaptive Growth] Baseline kuruldu: {self._entropy_baseline:.4f}")
                print(f"[Adaptive Growth] Spike threshold: {spike_threshold:.4f} (baseline x {self._spike_factor})")
                self._entropy_window = []  # Temizle
            else:
                return False, 'baseline_warmup'
        
        # 5. SPIKE DETECTION
        # Entropy, baseline'in spike_factor katinan gecti mi?
        spike_threshold = self._entropy_baseline * self._spike_factor
        is_spike = mean_entropy > spike_threshold
        
        # Fallback: Eger baseline cok dusukse, sabit threshold da kontrol et
        is_above_fixed = mean_entropy > self.config.entropy_threshold
        
        if is_spike:
            # BUYUME TETIKLENDI - Gercek bir spike var
            print(f"[Adaptive Growth] SPIKE! Entropy: {mean_entropy:.4f} > Threshold: {spike_threshold:.4f}")
            print(f"[Adaptive Growth] Baseline: {self._entropy_baseline:.4f} x {self._spike_factor} = {spike_threshold:.4f}")
            
            # Cooldown lock
            self.last_growth_step = current_step
            self._growth_locked_until = current_step + self.evolution_cooldown_steps
            
            # Baseline'i sifirla -> yeni expert icin yeni warmup baslayacak
            self._entropy_baseline = None
            self._entropy_window = []
            
            return True, 'entropy_spike'
        
        return False, 'none'

    def probe_expert_affinity(self, data_batches: list, vocab_size: int = 32000) -> Tuple[Optional[str], Dict[str, float]]:
        """
        Expert Affinity Routing: Tests each expert to find who best understands the data.
        
        For each expert:
        1. Activate ONLY that expert + core
        2. Forward pass probe_steps batches
        3. Calculate mean entropy
        4. Find the expert with LOWEST entropy (best understanding)
        
        Args:
            data_batches: List of input tensors to probe with
            vocab_size: Vocabulary size for entropy calculation
            
        Returns: (best_expert_id, results_dict)
            best_expert_id: UUID of best expert, or None if new expert needed
            results_dict: {expert_id: mean_entropy} for all experts
        """
        probe_steps = getattr(self.config, 'affinity_probe_steps', 10)
        
        # Get all non-general experts
        experts = []
        for uuid, module in self.manager.registry.items():
            tag = getattr(module, 'specialty_tag', 'general')
            if tag != 'general':
                experts.append((uuid, tag))
        
        if not experts:
            print("[Affinity] Expert yok — tüm katmanlar eğitilecek.")
            return None, {}
        
        print(f"\n{'='*60}")
        print(f"EXPERT AFFINITY PROBING — {len(experts)} expert test ediliyor")
        print(f"{'='*60}")
        
        results = {}
        self.network.eval()  # Forward-only, gradient yok
        
        with torch.no_grad():
            for expert_uuid, expert_tag in experts:
                # Sadece bu expert'i aktif et
                self.network.set_active_expert(expert_uuid)
                
                entropies = []
                for i, batch in enumerate(data_batches):
                    if i >= probe_steps:
                        break
                    
                    # Forward pass (sadece core + bu expert)
                    output = self.network(batch, data_type='SFT')
                    
                    # Entropy hesapla
                    if output.dim() >= 2:
                        probs = torch.softmax(output.view(-1, output.size(-1)), dim=-1)
                        log_probs = torch.log(probs + 1e-10)
                        entropy = -(probs * log_probs).sum(dim=-1).mean().item()
                    else:
                        entropy = float('inf')
                    
                    entropies.append(entropy)
                
                mean_ent = np.mean(entropies) if entropies else float('inf')
                results[expert_uuid] = mean_ent
                print(f"  [{expert_tag}] ({expert_uuid[:8]}...): Entropy = {mean_ent:.4f}")
        
        # Normal moda dön
        self.network.clear_active_expert()
        self.network.train()
        
        # En düşük entropili expert'i bul
        best_uuid = min(results, key=results.get)
        best_entropy = results[best_uuid]
        best_tag = next(tag for uid, tag in experts if uid == best_uuid)
        
        # Karar: Bu expert verileri anlıyor mu?
        # Eğer baseline varsa, spike kontrolü yap
        if self._entropy_baseline is not None:
            spike_threshold = self._entropy_baseline * self._spike_factor
        else:
            # Baseline yoksa, fixed threshold kullan
            spike_threshold = self.config.entropy_threshold * 3  # Güvenli üst sınır
        
        if best_entropy < spike_threshold:
            # Bu expert verileri anlıyor — onu seç
            print(f"\n✅ AFFINITY MATCH: [{best_tag}] (Entropy: {best_entropy:.4f} < Threshold: {spike_threshold:.4f})")
            print(f"   → Sadece [{best_tag}] eğitilecek, diğerleri frozen.")
            self.network.set_active_expert(best_uuid)
            return best_uuid, results
        else:
            # Hiçbir expert verileri anlamıyor — yeni expert gerekli
            print(f"\n🆕 AFFINITY MISS: En iyi [{best_tag}] bile yetersiz (Entropy: {best_entropy:.4f} > {spike_threshold:.4f})")
            print(f"   → Yeni expert oluşturulacak (Mitosis gerekli).")
            self.network.clear_active_expert()
            return None, results

    def _check_resource_limits(self) -> bool:
        """Returns True if limits reached (Block growth)."""
        # 1. Param Count Check
        total_params = self.calculate_current_params()
        if total_params >= self.config.max_param_count:
            return True
            
        # 2. VRAM Check (Simplified heuristic or actual)
        if torch.cuda.is_available():
            vram_gb = torch.cuda.memory_allocated() / 1e9
            if vram_gb >= self.config.vram_limit_gb:
                return True
                
        return False
        
    def check_resources(self, current_params: int) -> bool:
        return not self._check_resource_limits()

    def calculate_current_params(self) -> int:
        total = 0
        for mod in self.manager.registry.values():
            for p in mod.parameters():
                total += p.numel()
        return total

    def smart_clone(self, parent_uuid: str, optimizer: Optional[optim.Optimizer], specialty_tag: str = 'general') -> BaseEvolvableModule:
        """
        Mitosis with Variance-Based Noise.
        Returns: New Module (Wrapped in IdentityWrapper with gamma=0.0)
        """
        parent_module = self.manager.get_module(parent_uuid)
        if parent_module is None:
             raise ValueError(f"Parent {parent_uuid} not found")

        # 1. Deep Copy
        new_module = copy.deepcopy(parent_module)
        new_module.dynamic_id = str(uuid.uuid4()) # New soul
        new_module.creation_step = self.manager.step_counter
        new_module.registration_step = self.manager.step_counter
        new_module.reset_stats()
        
        # v0.2.0: Set Specialty
        new_module.set_specialty(specialty_tag)
        
        # 2. Add Smart Noise (Only if optimizer is available)
        if optimizer:
            for (name, child_param), (new_name, new_param) in zip(parent_module.named_parameters(), new_module.named_parameters()):
                # Find stats
                state = optimizer.state.get(child_param, {})
                
                # AdamW second moment 'exp_avg_sq' (v_t)
                if 'exp_avg_sq' in state:
                    # Variance map
                    v_t = state['exp_avg_sq']
                    # Noise std dev proportional to sqrt(v_t)
                    sigma = torch.sqrt(v_t) * 0.1 
                    
                    noise = torch.randn_like(new_param) * sigma
                    with torch.no_grad():
                        new_param.add_(noise)
                else:
                    # Fallback
                    noise = torch.randn_like(new_param) * 0.01
                    with torch.no_grad():
                        new_param.add_(noise)
        else:
            # Fallback noise if no optimizer
             for p in new_module.parameters():
                 with torch.no_grad():
                     p.add_(torch.randn_like(p) * 0.01)

        # 3. Apply Gamma Gating (IdentityWrapper)
        # Ensure the new layer enters as an Identity operation (gamma=0)
        if isinstance(new_module, IdentityWrapper):
            # Already wrapped (parent was wrapped), just reset gamma
            with torch.no_grad():
                new_module.gamma.fill_(0.0)
        else:
            # Wrap it
            new_module = IdentityWrapper(new_module, creation_step=self.manager.step_counter)
            
        # v0.2.0: Ensure wrapper has same specialty as child
        new_module.set_specialty(specialty_tag)

        self.last_growth_step = self.manager.step_counter
        return new_module

    def register_clone_to_optimizer(self, new_module: BaseEvolvableModule, optimizer: optim.Optimizer, base_lr: float):
        """
        Cold Start: Add new params with high LR.
        v0.5.1: Track by module UUID instead of group index to avoid index drift.
        """
        # Add param group
        high_lr = base_lr * 10.0
        
        group_name = f"new_layer_{new_module.dynamic_id}"
        optimizer.add_param_group({
            'params': new_module.parameters(),
            'lr': high_lr,
            'initial_lr': high_lr,
            'name': group_name
        })
        
        # Track for stabilization using group name (stable identifier)
        self.pending_stabilizations[group_name] = {
            'start_step': self.manager.step_counter,
            'target_lr': base_lr,
            'initial_lr': high_lr
        }

    def stabilize_optimizer(self, optimizer: optim.Optimizer):
        """
        Callback to run every step.
        Decays LR of new layers.
        v0.5.1: Uses group name lookup instead of index to avoid drift.
        """
        current_step = self.manager.step_counter
        
        # Build name -> index map
        name_to_idx = {}
        for idx, group in enumerate(optimizer.param_groups):
            name = group.get('name', '')
            if name:
                name_to_idx[name] = idx
        
        # List to remove
        done = []
        
        for group_name, config in self.pending_stabilizations.items():
            idx = name_to_idx.get(group_name)
            if idx is None:
                continue # Group was removed (pruned)
                
            elapsed = current_step - config['start_step']
            
            if elapsed >= self.config.stabilization_steps:
                # Reset to target
                optimizer.param_groups[idx]['lr'] = config['target_lr']
                done.append(group_name)
            else:
                # Linear decay
                progress = elapsed / self.config.stabilization_steps
                diff = config['initial_lr'] - config['target_lr']
                new_lr = config['initial_lr'] - (progress * diff)
                optimizer.param_groups[idx]['lr'] = new_lr
                
        for name in done:
            del self.pending_stabilizations[name]

    def mitosis(self, parent_uuid: str, optimizer: Optional[optim.Optimizer], base_lr: float = 0.01, current_loss: Optional[float] = None, specialty_tag: str = 'general', current_step: int = 0):
        """
        High-level Mitosis: Checks triggers, clones, rewires, and updates optimizer.
        """
        # COOLDOWN RESET: Her mitosis'ten sonra büyüme sayacını sıfırla
        self.last_growth_step = current_step
        
        if current_loss is not None:
             self.last_mitosis_loss = current_loss
             
        # 1. Clone
        print(f"Mitosis: Cloning {parent_uuid} as {specialty_tag}...")
        clone = self.smart_clone(parent_uuid, optimizer, specialty_tag)
        
        # 1.5 Sync Device (Hotfix v0.1.6)
        try:
            parent_module = self.manager.get_module(parent_uuid)
            # Find device from parameters
            device = next(parent_module.parameters()).device
            clone.to(device)
            # Support IdentityWrapper gammas which are buffers/params
            if hasattr(clone, 'gamma'):
                 clone.gamma.data = clone.gamma.data.to(device)
        except Exception as e:
            print(f"[WARNING] Could not sync device for clone: {e}")
        
        # 2. Rewire (Parallel)
        # Get parents of parent
        parents = self.manager.incoming_edges.get(parent_uuid, [])
        
        # Register clone with same parents (Input connection)
        self.manager.register_module(clone, parents)
        
        # Connect to same children (Output connection)
        children = self.manager.adjacency_list.get(parent_uuid, [])
        for child_uuid in children:
            # We need to manually add connection
            self.manager.adjacency_list[clone.dynamic_id].append(child_uuid)
            self.manager.incoming_edges[child_uuid].append(clone.dynamic_id)
            
        # 3. Sync Network Body
        if hasattr(self.network, 'sync_with_registry'):
            self.network.sync_with_registry()
            
        # 4. Optimizer Update
        if optimizer:
            self.register_clone_to_optimizer(clone, optimizer, base_lr)
        
        # 5. Log
        self.manager.log_event("MITOSIS", f"Cloned {parent_uuid} -> {clone.dynamic_id} ({specialty_tag})")
        print(f"Mitosis: Born {clone.dynamic_id} (Parallel) - Tag: {specialty_tag}")

    # --- v0.2.7 Surgical Controls ---
    
    def freeze_all_except(self, target_tag: str):
        """
        Freezes ALL modules except those matching the target_tag.
        Useful for manual training of specific experts.
        """
        count = 0
        for uuid, module in self.manager.registry.items():
            if module.specialty_tag == target_tag:
                 # Unfreeze
                 for p in module.parameters(): p.requires_grad = True
                 module.is_frozen = False
                 count += 1
            else:
                 # Freeze
                 for p in module.parameters(): p.requires_grad = False
                 module.is_frozen = True
                 
        print(f"Surgical Freeze: Active='{target_tag}' ({count} modules). All others frozen.")

    def inject_layer(self, parent_tag_or_uuid: str, new_tag: str, optimizer: Optional[optim.Optimizer] = None, base_lr: float = 0.001):
        """
        Manual Mitosis Trigger.
        Forces a clone of the module identified by parent_tag_or_uuid.
        """
        # Resolve Parent
        parent = self.manager.get_module(parent_tag_or_uuid)
        if not parent:
            print(f"Injection Failed: Parent '{parent_tag_or_uuid}' not found.")
            return
            
        parent_uuid = parent.dynamic_id
        print(f"Surgical Injection: Forcing Mitosis on {parent_uuid} -> {new_tag}")
        
        # Force Mitosis
        self.mitosis(parent_uuid, optimizer, base_lr=base_lr, specialty_tag=new_tag)
