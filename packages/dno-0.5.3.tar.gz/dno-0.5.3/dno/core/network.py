import torch
import torch.nn as nn
import os
import json
import zipfile
import io
from typing import Optional, Dict, Any, List
from .manager import OrganismManager
from .base import BaseEvolvableModule
from .blueprints import GPTModel
from ..config import DnoConfig

class DynamicNetwork(nn.Module):
    """
    The Physical Body. 
    Executes the organism based on the OrganismManager's blueprint.
    """
    def __init__(self, manager: OrganismManager, config: Optional[DnoConfig] = None):
        super().__init__()
        self.manager = manager
        self.config = config or DnoConfig()
        self.modules_dict = nn.ModuleDict()
        
        # Expert Affinity Routing (v0.5.0)
        self._active_expert_id: Optional[str] = None  # None = all active
        
        # v0.5.3: Hybrid Auto-Growth (Affinity + Spike Detection)
        self._hybrid_probe_buffer: List[torch.Tensor] = []  # First 10 batches for affinity
        self._spike_test_buffer: List[float] = []  # 50 entropy values for spike detection
        self._hybrid_phase: str = 'affinity'  # 'affinity' | 'spike_test' | 'done'
        self._current_test_layer: Optional[str] = None  # Layer being spike-tested
        self._tested_layers: List[str] = []  # Layers that already spiked
        self._spike_baseline: Optional[float] = None  # Per-layer baseline
        self._growth_engine_ref = None  # Set externally by GrowthEngine
        
        self.sync_with_registry()
    
    def set_active_expert(self, expert_id: str):
        """Activate ONLY this expert (+ core). Others skipped in forward."""
        self._active_expert_id = expert_id
    
    def clear_active_expert(self):
        """Reactivate all experts (normal mode)."""
        self._active_expert_id = None
    
    def reset_hybrid_growth(self):
        """Reset hybrid growth state. Call this when starting a new SFT training session."""
        self._hybrid_probe_buffer = []
        self._spike_test_buffer = []
        self._hybrid_phase = 'affinity'
        self._current_test_layer = None
        self._tested_layers = []
        self._spike_baseline = None
        self._active_expert_id = None
        print("[Hybrid Growth] Reset. Will start affinity probing on next SFT batch.")
    
    def _run_hybrid_affinity(self):
        """
        v0.5.3 Phase 1: Fast affinity probing (10 batches) to select best starting layer.
        """
        if self._growth_engine_ref is None:
            print("[Hybrid] WARNING: GrowthEngine not set. Skipping.")
            self._hybrid_phase = 'done'
            return
        
        print(f"\n[Hybrid Phase 1/2] Affinity Probing — {len(self._hybrid_probe_buffer)} batch test ediliyor...")
        
        best_id, results = self._growth_engine_ref.probe_expert_affinity(
            data_batches=self._hybrid_probe_buffer,
            include_core=True
        )
        
        self._hybrid_probe_buffer = []  # Free memory
        
        if best_id:
            tag = self.manager.registry[best_id].specialty_tag if best_id in self.manager.registry else '?'
            print(f"[Hybrid] En uygun katman: [{tag}] ({best_id[:8]}...)")
            print(f"[Hybrid Phase 2/2] Spike Detection basliyor — 50 step baseline olusturulacak...")
            self._current_test_layer = best_id
            self._hybrid_phase = 'spike_test'
            self.set_active_expert(best_id)  # Focus training on this layer
        else:
            print(f"[Hybrid] Hicbir katman uygun degil — yeni expert gerekli.")
            self._trigger_mitosis()
    
    def _check_spike(self, current_entropy: float):
        """
        v0.5.3 Phase 2: Spike detection on selected layer (50 batches).
        """
        baseline_window = getattr(self.config, 'entropy_baseline_window', 50)
        spike_factor = getattr(self.config, 'entropy_spike_factor', 1.5)
        
        self._spike_test_buffer.append(current_entropy)
        
        # Build baseline
        if len(self._spike_test_buffer) == baseline_window:
            self._spike_baseline = sum(self._spike_test_buffer) / baseline_window
            spike_threshold = self._spike_baseline * spike_factor
            print(f"[Hybrid] Baseline kuruldu: {self._spike_baseline:.4f}")
            print(f"[Hybrid] Spike threshold: {spike_threshold:.4f} (baseline x {spike_factor})")
        
        # Check for spike
        if self._spike_baseline is not None:
            spike_threshold = self._spike_baseline * spike_factor
            if current_entropy > spike_threshold:
                tag = self.manager.registry[self._current_test_layer].specialty_tag
                print(f"\n[Hybrid] SPIKE! [{tag}] katmani uygun degil (Entropy: {current_entropy:.4f} > {spike_threshold:.4f})")
                self._tested_layers.append(self._current_test_layer)
                self._spike_test_buffer = []
                self._spike_baseline = None
                
                # Try next layer
                remaining = [uid for uid in self.manager.registry.keys() 
                            if uid not in self._tested_layers]
                if remaining:
                    next_layer = remaining[0]
                    next_tag = self.manager.registry[next_layer].specialty_tag
                    print(f"[Hybrid] Sonraki katman test ediliyor: [{next_tag}]")
                    self._current_test_layer = next_layer
                    self.set_active_expert(next_layer)
                else:
                    print(f"[Hybrid] Tum katmanlar spike verdi — MITOSIS tetikleniyor!")
                    self._trigger_mitosis()
    
    def _trigger_mitosis(self):
        """
        v0.5.3: Automatically trigger mitosis when all layers spike or no layer matches.
        """
        if self._growth_engine_ref is None:
            print("[Hybrid] Cannot trigger mitosis: GrowthEngine not set.")
            self._hybrid_phase = 'done'
            return
        
        # Find a parent (prefer last tested layer, fallback to any)
        parent_uuid = self._current_test_layer or list(self.manager.registry.keys())[0]
        parent_tag = self.manager.registry[parent_uuid].specialty_tag
        
        new_tag = f"sft_expert_v{len([m for m in self.manager.registry.values() if getattr(m, 'specialty_tag', 'general') != 'general']) + 1}"
        
        print(f"\n{'='*60}")
        print(f"MITOSIS TETIKLENDI (Hybrid Auto-Growth)")
        print(f"Parent: [{parent_tag}] → Child: [{new_tag}]")
        print(f"{'='*60}")
        
        # Trigger mitosis (GrowthEngine will handle optimizer updates)
        self._growth_engine_ref.mitosis(
            parent_uuid=parent_uuid,
            optimizer=None,  # Will be set by training loop
            specialty_tag=new_tag,
            current_step=self.manager.step_counter
        )
        
        # Activate new expert
        new_uuid = [uid for uid, m in self.manager.registry.items() 
                    if getattr(m, 'specialty_tag', '') == new_tag][0]
        self.set_active_expert(new_uuid)
        self._hybrid_phase = 'done'
        print(f"[Hybrid] Yeni expert [{new_tag}] aktif. Egitim devam ediyor.\n")

    def sync_with_registry(self):
        """Syncs the internal ModuleDict with the Manager's registry."""
        for uuid, module in self.manager.registry.items():
            if uuid not in self.modules_dict:
                self.modules_dict[uuid] = module

    def _detect_novelty(self, x: torch.Tensor) -> str:
        """
        Veri 'Tanıdık' (CPT) mı yoksa 'Yeni/Zor' (SFT) mu?
        """
        # Fix for LongTensor/IntTensor (Token IDs) - Cannot softmax indices
        if x.dtype in [torch.long, torch.int]:
            return 'CPT'

        with torch.no_grad():
            # Basitleştirilmiş entropi hesabı
            if x.dim() > 1:
                probs = torch.softmax(x, dim=-1)
                entropy = -torch.sum(probs * torch.log(probs + 1e-9), dim=-1).mean().item()
            else:
                probs = torch.softmax(x, dim=0)
                entropy = -torch.sum(probs * torch.log(probs + 1e-9)).item()
                
        # Eşik değeri Config'den almak daha sağlıklı olur ama şimdilik hardcoded.
        # Entropi Yüksek -> Model şaşkın -> SFT/Yeni Veri
        if entropy > self.config.entropy_threshold: 
            return 'SFT'
        # Entropi Düşük -> Model emin -> CPT/Tanıdık Veri
        return 'CPT'

    def _apply_gradient_locking(self, data_type: str):
        """
        AKILLI DONDURMA (Smart Freezing):
        - CPT Verisi (Tanıdık): Çekirdek (General) çalışır, Uzmanlar (SFT) donar.
        - SFT Verisi (Yabancı): Çekirdek (General) donar, Uzmanlar (SFT) çalışır.
        
        GÜVENLİK: Eğer henüz Expert lob yoksa, SFT modunda bile
        tüm parametreler serbest kalır (yoksa backward() patlar).
        """
        # Eğer sıfırdan eğitimse (scratch), her şeyi serbest bırak, kilit yok.
        if self.config.training_phase == 'scratch':
            for module in self.modules_dict.values():
                for p in module.parameters(): p.requires_grad = True
                module.is_frozen = False
            return

        # GÜVENLİK KONTROLÜ: Expert lob var mı?
        # Yoksa locking yapma — tüm parametreleri serbest bırak.
        has_experts = any(
            getattr(m, 'specialty_tag', 'general') != 'general'
            for m in self.modules_dict.values()
        )
        
        if not has_experts:
            # Henüz expert yok — her şeyi serbest bırak
            for module in self.modules_dict.values():
                for p in module.parameters(): p.requires_grad = True
                module.is_frozen = False
            return

        # Adaptasyon Modu (Adaptive Mode) — Expert loblar mevcut
        for uuid, module in self.modules_dict.items():
            is_general_core = (getattr(module, 'specialty_tag', 'general') == 'general')
            
            if data_type == 'CPT':
                # Tanıdık veri: Çekirdeği eğit, lobları dondur.
                if is_general_core:
                    for p in module.parameters(): p.requires_grad = True
                    module.is_frozen = False
                else:
                    for p in module.parameters(): p.requires_grad = False
                    module.is_frozen = True
                    
            elif data_type == 'SFT':
                # Yabancı veri: Çekirdeği koru (dondur), lobları eğit.
                if is_general_core:
                    for p in module.parameters(): p.requires_grad = False
                    module.is_frozen = True
                elif self._active_expert_id is not None:
                    # AFFINITY ROUTING: Sadece seçili expert eğitilir
                    if uuid == self._active_expert_id or module.dynamic_id == self._active_expert_id:
                        for p in module.parameters(): p.requires_grad = True
                        module.is_frozen = False
                    else:
                        for p in module.parameters(): p.requires_grad = False
                        module.is_frozen = True
                else:
                    # Affinity yok: Tüm expertler eğitilir (eski davranış)
                    for p in module.parameters(): p.requires_grad = True
                    module.is_frozen = False

    def forward(self, x: torch.Tensor, max_steps: int = 20, saturation_threshold: float = None, past_key_values: Optional[Dict[str, Any]] = None, data_type: Optional[str] = None) -> Any:
        """
        Non-linear execution engine with Cognitive Saturation check.
        Supports KV Cache and Data-Aware Routing (v0.2.0).
        """
        # Use config defaults
        if saturation_threshold is None:
            saturation_threshold = 0.01

        # 0. Data-Aware Routing & Gradient Locking
        if self.training:
            # Force 'CPT' in Scratch Phase (Grow only the Seed Cortex)
            if self.config.training_phase == 'scratch':
                data_type = 'CPT'
            
            if data_type is None:
                data_type = self._detect_novelty(x)
            
            # v0.5.3: Hybrid Auto-Growth (Affinity + Spike Detection)
            if data_type == 'SFT' and self.config.training_phase == 'adaptive':
                if self._hybrid_phase == 'affinity':
                    # Phase 1: Collect batches for affinity probing
                    affinity_steps = getattr(self.config, 'affinity_probe_steps', 10)
                    if len(self._hybrid_probe_buffer) < affinity_steps:
                        self._hybrid_probe_buffer.append(x.detach().clone())
                    else:
                        # Run affinity probe
                        self._run_hybrid_affinity()
                
                elif self._hybrid_phase == 'spike_test':
                    # Phase 2: Spike detection on selected layer
                    # Calculate entropy after forward pass (we'll do this after output is computed)
                    pass  # Entropy calculation happens after forward
            
            self._apply_gradient_locking(data_type)

        # Start at input nodes
        queue = []
        for input_uuid in self.manager.input_nodes:
            queue.append((input_uuid, x, 0, None)) 
        
        final_outputs = []
        current_key_values = {} # To support KV Cache
        
        while queue:
            current_uuid, signal, step, prev_signal = queue.pop(0)
            
            if step > max_steps:
                continue 
                
            if current_uuid not in self.modules_dict:
                continue

            module = self.modules_dict[current_uuid]
            
            # AFFINITY ROUTING: Skip non-active experts in forward pass
            if self._active_expert_id is not None:
                is_general = (getattr(module, 'specialty_tag', 'general') == 'general')
                is_active = (current_uuid == self._active_expert_id or 
                            getattr(module, 'dynamic_id', '') == self._active_expert_id)
                if not is_general and not is_active:
                    # Bu expert aktif değil, atla — çıktılarını yayma
                    continue
            
            # Execute Module with optional KV Cache
            kwargs = {}
            if past_key_values is not None:
                # Only pass past_key_value if it exists for this node
                # This protects generic layers (like Sequential) from crashing
                pk = past_key_values.get(current_uuid)
                if pk is not None:
                    kwargs['past_key_value'] = pk
            
            # Auto-Cast LongTensor/IntTensor to Float if module is NOT Embedding
            # This fixes "mat1 and mat2 must have the same dtype" error for Linear layers receiving token IDs
            # v0.2.6 Check: Look deeply for ANY Embedding layer inside the module (e.g. nested in Sequential/GPT)
            if signal.dtype in [torch.long, torch.int]:
                 has_embedding = False
                 # Deep check: iterate over all submodules
                 # v0.5.1: Safe access via getattr to avoid AttributeError
                 inner = getattr(module, 'child_module', module)
                 for sub in inner.modules():
                     if isinstance(sub, nn.Embedding):
                         has_embedding = True
                         break
                 
                 if not has_embedding:
                     signal = signal.to(torch.float32)

            out_result = module(signal, **kwargs)
            
            # Handle Return (Tuple check)
            if isinstance(out_result, tuple):
                output = out_result[0]
                # Store the new key value for next step
                if len(out_result) > 1:
                     current_key_values[current_uuid] = out_result[1]
            else:
                output = out_result
            
            # Saturation Check Logic
            if prev_signal is not None:
                if signal.shape == output.shape:
                    diff = (output - signal).norm().item()
                    if diff < saturation_threshold:
                        final_outputs.append(output)
                        continue

            # ROUTING
            next_candidates = self.manager.get_forward_candidates(current_uuid)
            
            if not next_candidates:
                final_outputs.append(output)
            else:
                for next_uuid in next_candidates:
                    queue.append((next_uuid, output, step + 1, signal))
        
        # Aggregate Outputs (Smart Aggregation v0.2.0 could happen here too, but mostly in growth/wrapper)
        if not final_outputs:
            final_res = x
        elif len(final_outputs) == 1:
            final_res = final_outputs[0]
        else:
            # v0.5.1: Normalize multi-output aggregation (average instead of sum)
            base = final_outputs[0]
            count = 1
            for o in final_outputs[1:]:
                if base.shape == o.shape:
                    base = base + o
                    count += 1
            final_res = base / count
        
        # v0.5.3: Spike detection entropy calculation
        if self.training and self._hybrid_phase == 'spike_test' and final_res.dim() >= 2:
            with torch.no_grad():
                probs = torch.softmax(final_res.view(-1, final_res.size(-1)), dim=-1)
                log_probs = torch.log(probs + 1e-10)
                entropy = -(probs * log_probs).sum(dim=-1).mean().item()
                self._check_spike(entropy)
            
        # Return with KV Cache if requested
        if past_key_values is not None:
            return final_res, current_key_values
        return final_res

    def add_layer(self, module: BaseEvolvableModule, parents: List[str] = None):
        """Adds a layer to the organism and updates PyTorch registration."""
        self.manager.register_module(module, parents)
        self.sync_with_registry()
        # Log event (Phase 5)
        self.manager.log_event("BIRTH", f"Added layer {module.dynamic_id}")

    def save_dno(self, path: str):
        """
        Fluid Serialization (.dno format).
        Bundles:
        - topology.json
        - weights.pt
        - config.json
        - history.json
        into a ZIP file.
        """
        if not path.endswith('.dno'):
            path += '.dno'
            
        print(f"Fluid Serialization: Saving to {path}...")
        
        # 1. Prepare Data
        topology = self.manager.get_topology_summary()
        topology_json = json.dumps(topology, indent=4)
        
        # Config
        from dataclasses import asdict
        config_json = json.dumps(asdict(self.config), indent=4)
        
        # Weights
        # We save weights to a Buffer
        weights_buffer = io.BytesIO()
        torch.save(self.state_dict(), weights_buffer)
        weights_bytes = weights_buffer.getvalue()
        
        # 2. Write Zip
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as zf:
            zf.writestr('topology.json', topology_json)
            zf.writestr('config.json', config_json)
            zf.writestr('weights.pt', weights_bytes)
            
        print("[OK] Saved successfully.")

    def save_standard(self, path: str):
        """
        Saves the pure state_dict for compatibility with standard PyTorch.
        Does NOT save topology. Use this for checkpoints or export.
        """
        if not path.endswith('.pt') and not path.endswith('.pth'):
            path += '.pt'
        print(f"Standard Save: Saving state_dict to {path}...")
        torch.save(self.state_dict(), path)
        print("[OK] Standard save complete.")

    @classmethod
    def load_dno(cls, path: str, module_factory):
        """
        Loads a .dno file with auto-repair and robust error handling.
        """
        print(f"Fluid Serialization: Loading from {path}...")
        
        try:
            with zipfile.ZipFile(path, 'r') as zf:
                # 1. Load Config
                try:
                    config_data = json.loads(zf.read('config.json').decode('utf-8'))
                    config = DnoConfig(**config_data)
                except Exception as e:
                    print(f"[WARNING] Config load failed: {e}. Using default.")
                    config = DnoConfig()
                
                # 2. Load Topology
                try:
                    topology = json.loads(zf.read('topology.json').decode('utf-8'))
                except KeyError:
                    print(f"[ERROR] topology.json missing in archive!")
                    raise
                
                # 3. Reconstruct Manager
                manager = OrganismManager()
                manager.genome_history = topology.get('history', [])
                manager.step_counter = topology.get('step', 0)
                
                # 4. Reconstruct Network
                network = cls(manager, config)
                
                # 5. Recreate Nodes
                uuid_to_module = {}
                for node_meta in topology['nodes']:
                    child = None
                    # Fallback Attempt 1: Try factory
                    try:
                        child = module_factory(node_meta['type'])
                    except Exception as e:
                        print(f"[WARNING] Factory failed for {node_meta['type']}: {e}")
                    
                    # Fallback Attempt 2: Default GPTModel
                    if child is None:
                        print(f"[REPAIR] Reconstructing {node_meta['uuid']} as default GPTModel.")
                        child = GPTModel(config) # Use the config we loaded
                    
                    # Create Wrapper
                    wrapper = BaseEvolvableModule(child)
                    
                    # Restore metadata
                    wrapper.dynamic_id = node_meta['uuid']
                    wrapper.energy_score = node_meta.get('energy_score', 0.0)
                    wrapper.activation_count = node_meta.get('activation_count', 0)
                    wrapper.creation_step = node_meta.get('creation_step', 0)
                    if 'tag' in node_meta: # Restore tag if available
                        wrapper.specialty_tag = node_meta['tag']

                    # Ensure child_module is set
                    if not hasattr(wrapper, 'child_module') or wrapper.child_module is None:
                         wrapper.child_module = child
                    
                    uuid_to_module[node_meta['uuid']] = wrapper
                    network.modules_dict[node_meta['uuid']] = wrapper
                    
                manager.registry = uuid_to_module
                manager.adjacency_list = topology['edges']
                manager.input_nodes = topology['inputs']
                manager.output_nodes = topology['outputs']
                
                # v0.5.1: Reconstruct incoming_edges from adjacency_list
                manager.incoming_edges = {uid: [] for uid in manager.registry}
                for parent_uid, children in manager.adjacency_list.items():
                    for child_uid in children:
                        if child_uid in manager.incoming_edges:
                            manager.incoming_edges[child_uid].append(parent_uid)
                
                # 6. Load Weights
                try:
                    weights_bytes = zf.read('weights.pt')
                    weights_buffer = io.BytesIO(weights_bytes)
                    # Use proper map_location
                    state_dict = torch.load(weights_buffer, map_location='cpu', weights_only=True) 
                    network.load_state_dict(state_dict, strict=False)
                except Exception as e:
                    print(f"[WARNING] Weights load failed or partial: {e}")
                    print("Attempting auto-repair by ignoring mismatched keys...")
                    print("TIP: If this is a vocab_size mismatch, check your Config!")
                
            # 7. Deep Scan & Repair
            print("Performing Deep Scan & Repair...")
            for uuid, module in list(network.modules_dict.items()):
                if module is None or not hasattr(module, 'child_module') or module.child_module is None:
                    print(f"[ZOMBIE DETECTED] Module {uuid} is broken. Replacing with GPTModel.")
                    new_child = GPTModel(config)
                    new_wrapper = BaseEvolvableModule(new_child)
                    new_wrapper.dynamic_id = uuid
                    network.modules_dict[uuid] = new_wrapper
                    manager.registry[uuid] = new_wrapper

            print("[OK] Organism Resurrected.")
            return network

        except zipfile.BadZipFile:
            print(f"[FATAL] {path} is not a valid zip archive.")
            raise
        except Exception as e:
            print(f"[FATAL] Failed to load DNO: {e}")
            raise
