from dnora.type_manager.dnora_types import DnoraDataType
from typing import Union
from dnora.read.abstract_readers import (
    DataReader,
    SpectralDataReader,
    ReaderFunction,
)
from dnora.type_manager.dnora_objects import DnoraObject, Grid, dnora_objects
import geo_parameters as gp
import pandas as pd
import numpy as np
from dnora.pick import PointPicker, Area, NearestGridPoint
from geo_skeletons import PointSkeleton
from dnora import msg
from dnora.utils.distance import clustered_around_lon180, wrapped_lon_edges
from dnora.utils.grid import cluster_points

from dnora.grid import TriGrid
from dnora.grid.mask import All

def import_data(
    grid: Grid,
    start_time: str,
    end_time: str,
    obj_type: DnoraDataType,
    name,
    dry_run,
    reader,
    expansion_factor: float,
    source,
    folder: str,
    filename: str,
    point_mask=None,
    point_picker=None,
    max_calls: int = None,
    **kwargs,
) -> DnoraObject:
    """Imports data using DataReader and creates and returns a DNORA object"""
    msg.plain("")
    msg.print_line(marker="+")
    msg.plain(f"Starting import of data: {obj_type.name}")
    msg.print_line(marker="+")

    if grid.core.x_str == 'lon' and clustered_around_lon180(grid.lon()):
        lon0 = float(np.min(grid.lon()[grid.lon() > 0]))
        lon1 = float(np.max(grid.lon()[grid.lon() < 0]))
        msg.plain(
        f"Area: {grid.core.x_str}: {(lon0, lon1)}, "
        f"{grid.core.y_str}: {grid.edges('lat',native=True)}"
    )
    else:
        msg.plain(
            f"Area: {grid.core.x_str}: {grid.edges('lon',native=True)}, "
            f"{grid.core.y_str}: {grid.edges('lat',native=True)}"
        )
    
    if max_calls is not None:
        msg.plain(f"Max calls set to {max_calls}. Clustering will be used if needed.")
        clustered_points = cluster_points(lon = grid.lon(), lat = grid.lat(), N_cluster = max_calls)
        msg.plain(f"Number of clusters created: {len(clustered_points)}")
        for i, cluster in enumerate(clustered_points):
            if clustered_around_lon180(cluster[:,0]):
                lon0 = float(np.min(cluster[cluster[:,0] > 0][:,0]))
                lon1 = float(np.max(cluster[cluster[:,0] < 0][:,0]))
                msg.plain(f"Area cluster {i+1} (wrapped): lon: {lon0:.2f} to {lon1:.2f}, lat: {cluster[:,1].min():.2f} to {cluster[:,1].max():.2f}")
            else:   
                msg.plain(f"Area cluster {i+1}: lon: {cluster[:,0].min():.2f} to {cluster[:,0].max():.2f}, lat: {cluster[:,1].min():.2f} to {cluster[:,1].max():.2f}")

    msg.plain(f"{start_time} - {end_time}")

    if dry_run:
        msg.info("Dry run! No data will be imported.")
        return
    if max_calls is not None:
        if dnora_objects.get(obj_type).is_gridded():
            raise ValueError("Cannot use 'max_calls' when importing gridded objects!")

        msg.header(point_picker, "Choosing points to import...")
        msg.plain("Point picking with clustering...")

        obj_list = []
        clustered_points = [clustered_points[-1]]
        for i, cluster in enumerate(clustered_points):
            msg.plain(f"\nPicking points for cluster {i+1}...")
            lon,lat = cluster[:,0], cluster[:,1]
            
            points = TriGrid(lon=lon[:], lat=lat[:], name=f"{grid.name}_cluster_{i}")
            points.set_boundary_points(All())
            inds = pick_points(
                points,
                reader,
                start_time,
                point_picker,
                expansion_factor,
                points.boundary_mask(),
                source,
                folder,
                filename,
                **kwargs,
            )
            if len(inds) < 1:
                msg.warning("PointPicker didn't find any points. Aborting import of data.")
                return

            msg.plain(f"\nImporting data for cluster {i+1}...")
            obj = read_data_and_create_object(
                obj_type,
                reader,
                expansion_factor,
                points,
                start_time,
                end_time,
                name,
                source,
                folder,
                filename,
                inds,
                **kwargs,
            )
            obj_list.append(obj)

        msg.plain("Concatenating data from all clusters...")
        obj = None
        for ob in obj_list:
            if obj is None:
                obj = ob
            else:
                obj = obj.absorb(ob, dim='inds')
        msg.plain("Concatenation done.")


    else:
        if not dnora_objects.get(obj_type).is_gridded():
            msg.header(point_picker, "Choosing points to import...")
            inds = pick_points(
                grid,
                reader,
                start_time,
                point_picker,
                expansion_factor,
                point_mask,
                source,
                folder,
                filename,
                **kwargs,
            )
            if len(inds) < 1:
                msg.warning("PointPicker didn't find any points. Aborting import of data.")
                return
        else:
            inds = np.array([])
        msg.header(reader, f"Importing {obj_type.name}...")
        obj = read_data_and_create_object(
            obj_type,
            reader,
            expansion_factor,
            grid,
            start_time,
            end_time,
            name,
            source,
            folder,
            filename,
            inds,
            **kwargs,
        )
    return obj


def read_data_and_create_object(
    obj_type: DnoraDataType,
    reader: Union[DataReader, SpectralDataReader],
    expansion_factor: float,
    grid: Grid,
    start_time: str,
    end_time: str,
    name: str,
    source: DnoraDataType,
    folder: str,
    filename: str,
    inds: list[int] = None,
    **kwargs,
) -> DnoraObject:
    """Reads data using the reader, creates the objects and sets data and metadata in object"""
    dnora_class = dnora_objects.get(obj_type)

    ds = reader(
        obj_type=obj_type,
        grid=grid,
        start_time=pd.to_datetime(start_time),
        end_time=pd.to_datetime(end_time),
        source=source,
        folder=folder,
        filename=filename,
        inds=inds,
        dnora_class=dnora_class,
        expansion_factor=expansion_factor,
        **kwargs,
    )
    if ds is None:
        raise ValueError("No data found!")

    if not isinstance(ds, tuple):
        obj = dnora_class.from_ds(ds, name=name, dynamic=False)
    else:
        coord_dict, data_dict, meta_dict = ds
        obj = dnora_class(name=name, **coord_dict)
        existing_vars = obj.core.non_coord_objects()

        for key, value in data_dict.items():
            # Give (name[str], parmater[gp]) or (name[str], None) is values is a str
            name, param = gp.decode(key)

            # Only a string identifier was given, e.g. 'hs'
            if name not in existing_vars and param is not None:
                names = obj.core.find_cf(param.standard_name()) + obj.core.find_cf(
                    param.standard_name(alias=True)
                )
                names = list(set(names))  # Remove duplicates

                if len(names) > 1:
                    raise KeyError(
                        f"The standard_name '{param.standard_name()} of class {param.__name__} matches several variables: {names}'. Try specifying with e.g. {param.__name__}('{names[0]}') "
                    )
                elif len(names) < 1:
                    name = 0
                else:
                    name = names[0]

            if name in existing_vars:
                if isinstance(value, tuple):
                    obj.set(name, value[0], coords=value[1])
                else:
                    obj.set(name, value)

        obj.meta.append(meta_dict)
        if (
            meta_dict.get("zone_number") is not None
            and meta_dict.get("zone_letter") is not None
        ):
            obj.utm.set((meta_dict.get("zone_number"), meta_dict.get("zone_letter")))

    try:
        obj._mark_convention(reader.convention())
    except AttributeError:
        pass

    return obj


def pick_points(
    grid: Grid,
    reader: ReaderFunction,
    start_time: str,
    point_picker: PointPicker,
    expansion_factor: float,
    point_mask: np.ndarray[bool],
    source: str,
    folder: str,
    filename: str,
    **kwargs,
):
    """Gets the indeces of the point defined by the logical mask with respect to all points available from the reader function."""
    available_points = reader.get_coordinates(
        grid=grid,
        start_time=start_time,
        source=source,
        folder=folder,
        filename=filename,
        **kwargs,
    )

    all_points = PointSkeleton(
        lon=available_points.get("lon"),
        lat=available_points.get("lat"),
        x=available_points.get("x"),
        y=available_points.get("y"),
    )

    if not np.all(np.logical_not(point_mask)):
        interest_points = PointSkeleton.from_skeleton(grid, mask=point_mask)
        slat = interest_points.edges("lat")
        slon = wrapped_lon_edges(interest_points)
    else:
        interest_points = None
        slat = grid.edges("lat")
        slon = wrapped_lon_edges(grid)
    ## Only take points that are reasonable close to the wanted grid
    ## This speeds up the searcg considerably, especially if we have points over 84 lat
    ## since then the fast cartesian searhc is not possible
    ## Set a limit for angles close to 90 and -90 lat and -180 and 180 longitude
    if isinstance(point_picker, NearestGridPoint):
        eps = 1e-12
        slon = (slon[0] - 6, slon[1] + 6)

        search_grid = Grid(lat=(max(slat[0] - 3, -90 + eps), min(slat[1] + 3, 90 - eps)),
                        lon=(max(slon[0] - 6, -180 + eps), min(slon[1] + 6, 180 - eps))) 
        search_inds = Area()(search_grid, all_points, expansion_factor=1, lon=slon)
    else:
        search_inds = all_points.inds()



    inds = point_picker(
        grid=grid,
        all_points=all_points.sel(inds=search_inds),
        expansion_factor=expansion_factor,
        selected_points=interest_points,
        fast=True,
        **kwargs,
    )
    if len(inds) < 1:
        return np.array([])

    return search_inds[inds]
