from .waveseries import WaveSeries
