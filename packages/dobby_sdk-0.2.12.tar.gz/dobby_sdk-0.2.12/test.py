# import anthropic

# client = anthropic.Anthropic()

# response = client.messages.create(
#     model="claude-sonnet-4-5",
#     max_tokens=1024,
#     tools=[
#         {
#             "name": "get_weather",
#             "description": "Get the current weather in a given location",
#             "input_schema": {
#                 "type": "object",
#                 "properties": {
#                     "location": {
#                         "type": "string",
#                         "description": "The city and state, e.g. San Francisco, CA",
#                     }
#                 },
#                 "required": ["location"],
#             },
#         }
#     ],
#     messages=[{"role": "user", "content": "What's the weather like in San Francisco?"}],
# )
# print(response)

from dobby.tools import Tool


class WeatherTool(Tool):
    name = "end_call"
    description = "Get the current weather in a given location"
    hand_off = True

    async def __call__(self) -> dict:
        return {"type": "end_call"}

print(WeatherTool()("test"))
