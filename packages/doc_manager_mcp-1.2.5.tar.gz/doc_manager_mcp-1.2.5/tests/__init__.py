"""Tests for doc-manager-mcp."""
