"""Documentation for `doccmd`."""
