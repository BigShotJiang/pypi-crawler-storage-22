# doced

**Automate software documentation using AI reasoning.**

doced is a CLI tool that scans your codebase, interviews you with intelligent questions, and generates comprehensive documentation including README, tutorials, architecture diagrams, and PDFs.

## Features

- 🔍 **Smart Codebase Scanning** - Respects `.gitignore` and intelligently filters files
- 🤖 **Multi-AI Approach** - Uses Gemini for architecture mapping and K2 Think for deep reasoning
- 💬 **Interactive Interview** - AI generates targeted questions based on your code
- 📚 **Comprehensive Docs** - Generates README, tutorials, architecture docs, and PDFs
- 🎨 **Customizable Styles** - Choose between Corporate/Creative tones and Brief/Detailed levels
- 📊 **Mermaid Diagrams** - Automatically generates architecture and flow diagrams

## Installation

### Recommended (Auto-handles PATH)
```bash
pip install pipx
pipx install doced
pipx ensurepath
```

### Alternative
```bash
pip install doced
```

### Development Setup

```bash
# Clone the repo
git clone https://github.com/qmamab/doced.git
cd doced

# Install dependencies
pip install -r requirements.txt
```

## Usage

### 1. Initialize (First Time Setup)

```bash
doced init
```
Sometimes that doesnt work on mac's, so try 

```bash
python3 -m doced init
```

You'll be prompted for:
- Gemini API Key
- K2 Think API Key  
- Documentation Style (Corporate/Creative)
- Detail Level (Brief/Detailed)

### 2. Generate Documentation

```bash
# In your project directory
doced create
```

The tool will:
1. Scan your codebase
2. Analyze architecture with Gemini
3. Generate intelligent questions with K2 Think
4. Interview you interactively
5. Create comprehensive documentation in `docs/`
   - `README.md`
   - `TUTORIAL.md`
   - `ARCHITECTURE.md`
   - `Documentation.pdf`

## API Configuration

### Gemini API
- Model: `gemini-2.0-flash-latest`
- Get your key: https://makersuite.google.com/app/apikey

### K2 Think API  
- Model: `MBZUAI-IFM/K2-Think`
- Endpoint: `https://api.k2think.ai/v2/chat/completions`
- Rate Limit: 20 RPM
- Get your key: Contact K2 Think team

## Project Structure

```
doced/
├── pyproject.toml        # Dependencies and metadata
└── src/
    └── doced/
        ├── main.py       # CLI and orchestration
        └── scanner.py    # Code scanning logic
```

## Configuration

Your config is stored at `~/.doced/config.json`. You can re-run `doced init` to update it.

## Troubleshooting

### Import Errors
Make sure you're in the virtual environment:
```bash
source .venv/bin/activate
```

### API Errors
- Verify your API keys are correct
- Check rate limits (K2 Think: 20 RPM)
- Ensure you're using the correct model names

## License

MIT
