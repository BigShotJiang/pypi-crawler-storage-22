from doced.main import app
import sys

if __name__ == "__main__":
    app()
