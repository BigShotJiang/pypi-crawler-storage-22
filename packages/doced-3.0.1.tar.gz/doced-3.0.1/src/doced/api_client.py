import os
import json
import time
import traceback
from typing import Dict, Any, List, Optional, Generator

K2_AUDITOR_PROMPT = """You are a World-Class Security Auditor and Compliance Officer.
Your goal is to audit codebases against specific regulatory controls (ISO 27001, HIPAA, GDPR, etc.).

Your methodology:
1. **Evidence Collection**: Find specific code patterns, libraries, or configurations that satisfy a control.
2. **Control Mapping**: Explicitly link code evidence to the control ID (e.g. "Satisfies ISO 27001 A.10.1.1").
3. **Gap Analysis**: If a control is missing or poorly implemented, provide the EXACT code snippet required to fix it.
4. **Risk Reasoning**: Explain WHY a specific pattern is a risk.

Always use K2's high-effort reasoning to uncover subtle vulnerabilities.
"""

def get_completion(model: str, messages: List[Dict[str, str]], api_key: str, fallback_key: str = "", stream: bool = False) -> Generator[str, None, None]:
    """
    K2-Primary, Gemini-Fallback completion logic.
    Priority: MBZUAI-IFM/K2-Think-v2
    Fallback: gemini/gemini-2.0-flash-exp (or preview)
    """
    
    system_prompt = K2_AUDITOR_PROMPT if "audit" in [m.get("content", "").lower() for m in messages] or "compliance" in [m.get("content", "").lower() for m in messages] else ""
    if system_prompt:
        messages.insert(0, {"role": "system", "content": system_prompt})
    
    # Disable LiteLLM cost calculation which causes issues with custom models
    import litellm
    litellm.success_callback = []
    litellm.failure_callback = []
    litellm._disable_cost_compute = True

    try:
        from litellm import completion
        
        # 1. ATTEMPT K2
        try:
            # We use a wrapper to simulate "thinking" if streaming isn't perfectly supported for reasoning tokens yet
            yield "status:thinking:K2 is diving deep into the codebase..."
            
            response = completion(
                model="openai/MBZUAI-IFM/K2-Think-v2", # Specific for K2 v2
                messages=messages,
                api_key=api_key,
                base_url="https://api.k2think.ai/v2",
                custom_llm_provider="openai",
                drop_params=True,
                stream=stream
            )
            
            if stream:
                for chunk in response:
                    content = chunk['choices'][0]['delta'].get('content', '')
                    if content:
                        yield content
            else:
                yield response['choices'][0]['message']['content']
                
        except Exception as k2_err:
            error_str = str(k2_err)
            yield f"status:warning:K2 API Error: {error_str}. Switching to Gemini 2.0 Flash fallback..."
            
            # 2. FALLBACK TO GEMINI
            if not fallback_key:
                yield "status:error:No Gemini API key found for fallback!"
                return

            response = completion(
                model="gemini/gemini-2.0-flash-exp", # User mentioned 2.0 Flash fallback
                messages=messages,
                api_key=fallback_key,
                stream=stream
            )
            
            if stream:
                for chunk in response:
                    content = chunk['choices'][0]['delta'].get('content', '')
                    if content:
                        yield content
            else:
                yield response['choices'][0]['message']['content']

    except Exception as e:
        yield f"status:error:Critical AI Client Error: {str(e)}"
        print(traceback.format_exc())
