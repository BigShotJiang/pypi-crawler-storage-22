from typing import Dict, List

COMPLIANCE_STANDARDS = {
    "ISO 27001:2022": {
        "description": "The gold standard for Information Security Management Systems (ISMS).",
        "policies": [
            "Information Security Policy",
            "Access Control Policy",
            "Clear Desk and Clear Screen Policy",
            "Mobile Device and Remote Working Policy",
            "Data Classification Policy"
        ],
        "controls": [
            {
                "id": "A.5.1",
                "name": "Policies for Information Security",
                "requirement": "Information security policy and topic-specific policies shall be defined, approved by management, and communicated to employees.",
                "evidence_pattern": "policy.md, security_manual.pdf, README_SECURITY"
            },
            {
                "id": "A.8.1",
                "name": "User Endpoint Devices",
                "requirement": "Information stored on, processed by or accessible via user endpoint devices shall be protected.",
                "evidence_pattern": "mdm, encryption, disk encryption, BYOD"
            },
            {
                "id": "A.8.24",
                "name": "Use of Cryptography",
                "requirement": "Rules for the effective use of cryptography, including key management, shall be defined and implemented.",
                "evidence_pattern": "AES-256, RSA, curves, secrets manager, kms, vault"
            },
            {
                "id": "A.8.28",
                "name": "Secure Coding",
                "requirement": "Secure coding principles shall be applied to software development.",
                "evidence_pattern": "OWASP, input validation, prepared statements, escape_html, sanitation"
            },
            {
                "id": "A.8.15",
                "name": "Logging",
                "requirement": "Events shall be logged and protected from unauthorized access.",
                "evidence_pattern": "logger.info, audit_log, winston, sentry, cloudwatch"
            }
        ]
    },
    "SOC2 Type II (TSC)": {
        "description": "Trust Services Criteria focusing on Security, Availability, Processing Integrity, Confidentiality, and Privacy.",
        "policies": [
            "Risk Management Policy",
            "Incident Response Plan",
            "Change Management Policy",
            "Vendor Management Policy"
        ],
        "controls": [
            {
                "id": "CC6.1",
                "name": "Logical Access Security",
                "requirement": "The entity restricts logical access to confidential information assets to authorized users.",
                "evidence_pattern": "auth0, cognito, passport.js, session_id, multi-factor, MFA"
            },
            {
                "id": "CC7.1",
                "name": "System Operations & Monitoring",
                "requirement": "The entity identifies and manages vulnerabilities in its systems and applications.",
                "evidence_pattern": "snyk, dependabot, sonar, vulnerability_scan"
            },
            {
                "id": "CC8.1",
                "name": "Change Management",
                "requirement": "The entity authorizes, designs, develops, and implements changes to software.",
                "evidence_pattern": "CI/CD, pull request, merge approval, staging, production"
            }
        ]
    },
    "GDPR": {
        "description": "General Data Protection Regulation for EU data privacy and protection.",
        "policies": [
            "Privacy Policy",
            "Data Retention Policy",
            "Data Processing Agreement (DPA)",
            "Subject Access Request (SAR) Procedure"
        ],
        "controls": [
            {
                "id": "Art. 32",
                "name": "Security of Processing",
                "requirement": "Encryption and pseudonymization of personal data.",
                "evidence_pattern": "hash, salt, pii_scanner, data_masking"
            },
            {
                "id": "Art. 17",
                "name": "Right to Erasure",
                "requirement": "Mechanisms for 'Right to be Forgotten'.",
                "evidence_pattern": "delete_user, purge_data, hard_delete"
            },
            {
                "id": "Art. 30",
                "name": "Records of Processing Activities",
                "requirement": "Maintain a record of processing activities.",
                "evidence_pattern": "data_inventory, processing_log.json"
            }
        ]
    },
    "HIPAA (Security Rule)": {
        "description": "Technical safeguards for Protected Health Information (ePHI) in the US.",
        "policies": [
            "Sanctions Policy",
            "Information Access Management",
            "Emergency Plan",
            "Disposal Policy"
        ],
        "controls": [
            {
                "id": "§164.312(a)(2)(iv)",
                "name": "Encryption and Decryption",
                "requirement": "Implement a mechanism to encrypt and decrypt ePHI.",
                "evidence_pattern": "encrypt_phi, decrypt_phi, ssl_required, https-only"
            },
            {
                "id": "§164.312(b)",
                "name": "Audit Controls",
                "requirement": "Implement hardware, software, and/or procedural mechanisms that record and examine activity in information systems.",
                "evidence_pattern": "trail, log_event, accessed_by, db_audit"
            }
        ]
    }
}

def get_controls_for_standard(standard_name: str) -> List[Dict]:
    return COMPLIANCE_STANDARDS.get(standard_name, {}).get("controls", [])
