import streamlit as st
import os
import json
import time
from pathlib import Path
from doced.api_client import get_completion
from doced.scanner import CodeScanner
from doced.utils import convert_charts_to_images
from doced.main import CONFIG_FILE, K2_SYSTEM_PROMPT, generate_pdf_enhanced, generate_pdf_board_ready
from doced.compliance import COMPLIANCE_STANDARDS, get_controls_for_standard

# --- Page Config & Branding ---
st.set_page_config(
    page_title="doced Dashboard | K2 Thinking Mode",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Theme (Emerald & Silver)
st.markdown("""
<style>
    :root {
        --primary-color: #046307;
        --secondary-color: #C0C0C0;
    }
    .main {
        background-color: #0d1117;
        color: #C0C0C0;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 24px;
        background-color: #161b22;
        padding: 10px;
        border-radius: 10px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: transparent;
        color: #C0C0C0;
    }
    .stTabs [aria-selected="true"] {
        color: #046307 !important;
        border-bottom: 2px solid #046307 !important;
    }
    .reasoning-box {
        background-color: #000;
        color: #00ff41;
        font-family: 'Courier New', Courier, monospace;
        padding: 20px;
        border-radius: 5px;
        border: 1px solid #046307;
        max-height: 400px;
        overflow-y: auto;
    }
</style>
""", unsafe_allow_html=True)

# --- State Management ---
if 'config' not in st.session_state:
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, 'r') as f:
            st.session_state.config = json.load(f)
    else:
        st.session_state.config = None

if 'architecture_map' not in st.session_state:
    st.session_state.architecture_map = ""
if 'interview_answers' not in st.session_state:
    st.session_state.interview_answers = {}
if 'compliance_results' not in st.session_state:
    st.session_state.compliance_results = {}
if 'target_standard' not in st.session_state:
    st.session_state.target_standard = "ISO 27001"

# --- Sidebar: Setup ---
with st.sidebar:
    st.image("https://img.icons8.com/nolan/64/brain.png", width=64)
    st.title("doced v2.0.0")
    st.write("The K2-First Intelligence Engine")
    st.divider()
    
    if st.session_state.config:
        st.success("API Keys Loaded")
        if st.button("Reset Config"):
            st.session_state.config = None
            st.rerun()
    else:
        st.warning("Setup Required")
        with st.form("setup_form"):
            k2_key = st.text_input("K2 Think API Key", type="password")
            gemini_key = st.text_input("Gemini API Key", type="password")
            if st.form_submit_button("Save Configuration"):
                new_config = {
                    "k2_key": k2_key,
                    "gemini_key": gemini_key,
                    "style": "Corporate",
                    "primary_color": "#046307",
                    "interactive_mode": True
                }
                Path(CONFIG_FILE).parent.mkdir(parents=True, exist_ok=True)
                with open(CONFIG_FILE, 'w') as f:
                    json.dump(new_config, f)
                st.session_state.config = new_config
                st.rerun()

# --- Main Interface ---
if not st.session_state.config:
    st.info("👋 Hello! Please enter your API keys in the sidebar to begin.")
else:
    tab1, tab2, tab3, tab4, tab5 = st.tabs(["📂 Codebase Scan", "🤝 Interview", "🧠 Deep Thoughts", "📄 Final Docs", "🛡️ Governance"])

    with tab1:
        st.header("Project Scanning")
        root_dir = st.text_input("Project Root Directory", value=os.getcwd())
        if st.button("🚀 Analyze Codebase"):
            scanner = CodeScanner(Path(root_dir))
            with st.spinner("Scanning files..."):
                code_context, stats = scanner.scan()
                st.session_state.code_context = code_context
                st.session_state.stats = stats
            
            st.success(f"Scanned {stats['total_files']} files ({len(code_context)} characters)")
            
            # Architecture Analysis Prompt
            msgs = [
                {"role": "system", "content": "You are a World-Class Software Architect."},
                {"role": "user", "content": f"Analyze this codebase and extract the core architectural patterns: \n\n{code_context[:300000]}"}
            ]
            
            progress_bar = st.progress(0, text="Initiating Deep Thinking...")
            thought_container = st.empty()
            
            full_thought = ""
            for chunk in get_completion("k2think/MBZUAI-IFM/K2-Think-v2", msgs, st.session_state.config['k2_key'], st.session_state.config['gemini_key'], stream=True):
                if chunk.startswith("status:"):
                    progress_bar.progress(50, text=chunk.replace("status:", ""))
                else:
                    full_thought += chunk
                    thought_container.markdown(f'<div class="reasoning-box">{full_thought}</div>', unsafe_allow_html=True)
            
            st.session_state.architecture_map = full_thought
            st.success("Architecture Map Generated!")

    with tab2:
        st.header("K2 Architect Interview")
        if not st.session_state.architecture_map:
            st.info("Run Architecture Analysis first.")
        else:
            st.write("K2 wants to refine the documentation based on your input.")
            # Simple simulation of K2 asking questions if not already populated
            if 'interview_questions' not in st.session_state:
                 st.session_state.interview_questions = [
                     "What is the primary solving problem of this codebase?",
                     "How is state managed across the core components?",
                     "What are the most critical security considerations here?"
                 ]
            
            for i, q in enumerate(st.session_state.interview_questions):
                st.session_state.interview_answers[q] = st.text_area(f"Q{i+1}: {q}", key=f"q_{i}")
            
            if st.button("Submit Answers & Generate Docs"):
                st.session_state.submitted = True
                st.success("Answers recorded. Proceed to Final Docs.")

    with tab3:
        st.header("The Thinking Process")
        if st.session_state.architecture_map:
            st.markdown(f'<div class="reasoning-box">{st.session_state.architecture_map}</div>', unsafe_allow_html=True)
        else:
            st.info("Reasoning tokens will appear here during analysis.")

    with tab4:
        st.header("Generated Documentation Suite")
        if not st.session_state.architecture_map:
            st.info("Analysis required.")
        elif st.button("🛠️ Generate Final Markdowns"):
            docs = ["README.md", "ARCHITECTURE.md", "TUTORIAL.md"]
            for doc in docs:
                with st.spinner(f"Creating {doc}..."):
                    prompt = f"Create a professional {doc} based on this map: {st.session_state.architecture_map} and these answers: {st.session_state.interview_answers}"
                    msgs = [{"role": "system", "content": K2_SYSTEM_PROMPT}, {"role": "user", "content": prompt}]
                    content = "".join([c for c in get_completion("k2think/MBZUAI-IFM/K2-Think-v2", msgs, st.session_state.config['k2_key'], st.session_state.config['gemini_key']) if not c.startswith("status:")])
                    st.session_state.generated_docs[doc] = content
            st.success("Documents Ready!")
        
        for name, content in st.session_state.generated_docs.items():
            with st.expander(f"👁️ Preview: {name}"):
                st.markdown(content)
                if st.button(f"Save {name}", key=f"save_{name}"):
                    Path("docs").mkdir(exist_ok=True)
                    (Path("docs") / name).write_text(content)
                    st.toast(f"Saved to docs/{name}")

    with tab5:
        st.header("Sovereign Governance & Compliance Wizard")
        st.write("Audit your codebase against global regulatory standards using K2 Think v2.")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.session_state.target_standard = st.selectbox(
                "Select Target Certification / Benchmark",
                options=list(COMPLIANCE_STANDARDS.keys()),
                index=0
            )
            st.info(COMPLIANCE_STANDARDS[st.session_state.target_standard]['description'])
            
            with st.expander("📝 Required Policies for this Certification"):
                for policy in COMPLIANCE_STANDARDS[st.session_state.target_standard].get('policies', []):
                    st.write(f"- {policy}")

            if st.button("🏁 Launch Compliance Audit"):
                standard_info = COMPLIANCE_STANDARDS[st.session_state.target_standard]
                controls = standard_info.get("controls", [])
                policies = standard_info.get("policies", [])
                
                code_snippet = st.session_state.get('code_context', '')[:300000]
                
                if not code_snippet:
                    st.error("Please scan the codebase in Tab 1 first.")
                else:
                    audit_results = {}
                    progress_text = st.empty()
                    pbar = st.progress(0)
                    
                    for i, control in enumerate(controls):
                        cid = control['id']
                        progress_text.text(f"Auditing Control {cid}: {control['name']}...")
                        pbar.progress((i + 1) / len(controls))
                        
                        prompt = f"""
                        AUDIT TASK: Evaluate the codebase for compliance with {st.session_state.target_standard} Control {cid} ({control['name']}).
                        REQUIREMENT: {control['requirement']}
                        EVIDENCE HINT: {control['evidence_pattern']}
                        REQUIRED POLICIES: {policies}
                        
                        CODE CONTEXT:
                        {code_snippet}
                        
                        OUTPUT FORMAT:
                        JSON with keys: 'status' (compliant/missing/partial), 'evidence' (line references or snippet names), 'reasoning' (K2's logic), 'remediation' (code snippet if missing).
                        """
                        
                        msgs = [{"role": "user", "content": prompt}]
                        response_text = ""
                        for chunk in get_completion("k2think/MBZUAI-IFM/K2-Think-v2", msgs, st.session_state.config['k2_key'], st.session_state.config['gemini_key'], stream=True):
                            if not chunk.startswith("status:"):
                                response_text += chunk
                        
                        try:
                            # Clean potential markdown wrappers
                            clean_json = response_text.replace("```json", "").replace("```", "").strip()
                            audit_results[cid] = json.loads(clean_json)
                        except:
                            audit_results[cid] = {"status": "error", "reasoning": "K2 output was not valid JSON.", "evidence": "N/A"}
                            
                    st.session_state.compliance_results = audit_results
                    st.success("Audit Complete!")

        with col2:
            st.subheader("Compliance Checklist & Evidence")
            if not st.session_state.compliance_results:
                st.info("Launch the audit to see results.")
            else:
                controls = get_controls_for_standard(st.session_state.target_standard)
                total_controls = len(controls)
                compliant_count = sum(1 for r in st.session_state.compliance_results.values() if r.get('status') == 'compliant')
                
                readiness = int((compliant_count / total_controls) * 100)
                st.metric("Certification Readiness", f"{readiness}%")
                st.progress(readiness / 100)
                
                for control in controls:
                    cid = control['id']
                    result = st.session_state.compliance_results.get(cid, {})
                    status = result.get('status', 'unknown')
                    
                    status_icon = "✅" if status == "compliant" else "⚠️" if status == "partial" else "❌"
                    with st.expander(f"{status_icon} {cid}: {control['name']}"):
                        st.markdown(f"**Requirement:** {control['requirement']}")
                        st.markdown(f"**K2 Reasoning:** {result.get('reasoning')}")
                        st.markdown(f"**Evidence Found:** {result.get('evidence')}")
                        if status != "compliant" and result.get('remediation'):
                            st.info("💡 **Recommended Remediation (K2 Proposed Fix):**")
                            st.code(result.get('remediation'))
                
                st.divider()
                if st.button("📈 Generate Board-Ready Compliance PDF"):
                    with st.spinner("Compiling Board-Ready Report..."):
                        # 1. Generate SSP
                        ssp_prompt = f"Generate a formal System Security Plan (SSP) for this project based on these audit results: {st.session_state.compliance_results}. Include an Executive Summary."
                        msgs = [{"role": "system", "content": K2_AUDITOR_PROMPT}, {"role": "user", "content": ssp_prompt}]
                        ssp_content = "".join([c for c in get_completion("k2think/MBZUAI-IFM/K2-Think-v2", msgs, st.session_state.config['k2_key'], st.session_state.config['gemini_key']) if not c.startswith("status:")])
                        
                        # 2. Generate Data Flow Diagram
                        dfd_prompt = f"Create a detailed Mermaid.js Data Flow Diagram (DFD) for this project based on the architecture: {st.session_state.architecture_map}"
                        msgs = [{"role": "system", "content": K2_SYSTEM_PROMPT}, {"role": "user", "content": dfd_prompt}]
                        dfd_content = "".join([c for c in get_completion("k2think/MBZUAI-IFM/K2-Think-v2", msgs, st.session_state.config['k2_key'], st.session_state.config['gemini_key']) if not c.startswith("status:")])
                        
                        docs_path = Path("docs")
                        docs_path.mkdir(exist_ok=True)
                        (docs_path / "SSP.md").write_text(ssp_content)
                        (docs_path / "DATA_FLOW.md").write_text(f"# Data Flow Analysis\n\n{dfd_content}")
                        
                        # Trigger PDF Generation (Enhanced)
                        try:
                            # We use a specialized function for compliance
                            generate_pdf_board_ready(docs_path, st.session_state.target_standard, readiness)
                            st.success("✅ Board-Ready Compliance PDF Exported to docs/Compliance_Report.pdf")
                            st.balloons()
                        except Exception as e:
                            st.error(f"PDF Export Failed: {e}")
