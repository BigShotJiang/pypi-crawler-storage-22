import typer
import os
import json
import time
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import print as rprint
from InquirerPy import inquirer
# from litellm import completion (Moved to lazy-load inside functions)
from markdown_pdf import MarkdownPdf, Section

from doced.scanner import CodeScanner
from doced.utils import convert_charts_to_images
from doced.video import generate_video_html

app = typer.Typer(help="doced: Automate software documentation.")
console = Console()

def launch_gui():
    """Launch the Streamlit GUI."""
    import subprocess
    import sys
    gui_path = Path(__file__).parent / "gui.py"
    rprint("[bold green]Launching doced Dashboard...[/bold green]")
    try:
        subprocess.run([sys.executable, "-m", "streamlit", "run", str(gui_path)])
    except KeyboardInterrupt:
        rprint("\n[yellow]Dashboard stopped.[/yellow]")

@app.callback(invoke_without_command=True)
def main(ctx: typer.Context):
    """doced: The K2-Powered Documentation Engine."""
    if ctx.invoked_subcommand is None:
        launch_gui()

CONFIG_DIR = Path.home() / ".doced"
CONFIG_FILE = CONFIG_DIR / "config.json"

GLOBAL_K2_FAILED = False

# --- K2 System Prompt ---
K2_SYSTEM_PROMPT = """You are a World-Class Technical Writer and Software Architect.

Your documentation philosophy:
- Start with WHY before diving into HOW
- Use clear structure
- Include real-world examples
- Visualize complex flows with Mermaid.js diagrams (flowchart, sequence, class)
- Write for both beginners and experts

Your specialties:
- Identifying core architectural patterns
- Creating intuitive "Getting Started" guides
- Explaining complex systems clearly
- Generating clean Markdown with diagrams
"""

DEFAULT_QUESTIONS = [
    "What is the high-level goal of this project and who is the target audience?",
    "Are there any specific design patterns or architectural decisions we should highlight?",
    "What are the known limitations, edge cases, or 'gotchas' in the current implementation?",
    "How does a developer set up the environment and run the project (env vars, dependencies)?",
    "What are the future plans or roadmap items for this codebase?"
]

import shutil
import sys
import platform

def check_environment():
    """Detect if doced is in PATH and offer fixes."""
    if shutil.which("doced"):
        return

    # If run via 'python -m doced', they are already seeing this.
    # We offer the permanent fix.
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}"
    user_name = Path.home().name
    
    if platform.system() == "Darwin": # macOS
        path_hint = f'export PATH="$PATH:/Users/{user_name}/Library/Python/{py_ver}/bin"'
        shell_file = "~/.zshrc"
    elif platform.system() == "Linux":
        path_hint = 'export PATH="$PATH:$HOME/.local/bin"'
        shell_file = "~/.bashrc"
    else: # Windows
        path_hint = f'$env:Path += ";$env:APPDATA\\Python\\Python{py_ver.replace(".","")}\\Scripts"'
        shell_file = "PowerShell Profile"

    rprint(Panel(
        f"[bold yellow]⚠️  PATH Configuration Detected[/bold yellow]\n\n"
        f"The [cyan]doced[/cyan] command is installed but not in your shell's PATH.\n\n"
        f"[bold cyan]Recommended Fix (Cleanest):[/bold cyan]\n"
        f"1. [bold]pip3 install pipx[/bold]\n"
        f"2. [bold]pipx install doced[/bold]\n"
        f"3. [bold]pipx ensurepath[/bold]\n\n"
        f"[bold yellow]Manual Fix (Quick):[/bold yellow]\n"
        f"Add this to your [bold]{shell_file}[/bold]:\n"
        f"[bold green]{path_hint}[/bold green]\n\n"
        f"[bold white]Alternatively, keep using:[/bold white] [bold]python3 -m doced[/bold]",
        title="Environment Diagnostic",
        border_style="yellow"
    ))

@app.command()
def init():
    """Setup API keys and Preferences for doced."""
    check_environment()
    rprint(Panel("Welcome to doced Setup", title="doced Init", style="bold blue"))
    
    gemini_key = inquirer.text(message="Enter your Gemini API Key:").execute()
    k2_key = inquirer.text(message="Enter your K2 Think API Key:").execute()
    
    advanced = inquirer.confirm(message="Do you want to configure advanced branding (Logo, Colors)?", default=False).execute()
    
    logo_path = ""
    primary_color = "#007ACC"
    style = "Corporate (Professional, Standard)"
    length = "Detailed (Deep Dive)"
    
    if advanced:
        logo_path = inquirer.text(message="Path to Logo (Absolute Path, optional):").execute()
        primary_color = inquirer.text(message="Primary Color Theme (e.g. #FF5733):", default="#007ACC").execute()
        
        style = inquirer.select(
            message="Select Default Style:",
            choices=["Corporate (Professional, Standard)", "Creative (Pretty, Engaging)"],
            default="Corporate (Professional, Standard)"
        ).execute()
        
        length = inquirer.select(
            message="Select Default Detail Level:",
            choices=["Brief (Executive Summary)", "Detailed (Deep Dive)"],
            default="Detailed (Deep Dive)"
        ).execute()
    
    interactive_mode = inquirer.confirm(message="Enable Interactive Interview Mode (Formulate custom architecture questions)?", default=False).execute()

    config = {
        "gemini_key": gemini_key,
        "k2_key": k2_key,
        "style": style,
        "length": length,
        "logo_path": logo_path,
        "primary_color": primary_color,
        "interactive_mode": interactive_mode
    }
    
    save_config(config)

def save_config(config: Dict[str, str]):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f)
    rprint(f"[green]Configuration saved to {CONFIG_FILE}[/green]")

def load_config() -> Dict[str, str]:
    if not CONFIG_FILE.exists():
        return {}
    with open(CONFIG_FILE, "r") as f:
        try:
            return json.load(f)
        except:
            return {}

GLOBAL_CONFIG = load_config()

def call_ai(model: str, messages: List[Dict[str, str]], api_key: str) -> str:
    global GLOBAL_K2_FAILED
    
    if GLOBAL_K2_FAILED and model.startswith("k2think/"):
        return call_ai_gemini_fallback(messages)

    max_retries = 3
    retry_delay = 2
    
    # Disable LiteLLM cost calculation which causes issues with custom models/Gemini tokens
    import litellm
    litellm.success_callback = []
    litellm.failure_callback = []
    litellm._disable_cost_compute = True # Bypass problematic cost calc

    for attempt in range(max_retries):
        try:
            from litellm import completion
            if model.startswith("k2think/"):
                model_name = model.replace("k2think/", "")
                response = completion(
                    model=model_name,
                    messages=messages,
                    api_key=api_key,
                    base_url="https://api.k2think.ai/v2", # Newer LiteLLM prefers base_url over api_base
                    custom_llm_provider="openai",
                    drop_params=True
                )
            else:
                response = completion(model=model, messages=messages, api_key=api_key)
            return response['choices'][0]['message']['content']
        except Exception as e:
            error_msg = str(e)
            error_str_lower = error_msg.lower()
            
            # Rate Limit Handling (Gemini 429)
            if "429" in error_msg or "resource_exhausted" in error_str_lower:
                rprint(f"[yellow]Rate limit hit. Waiting 60s before retry... (Attempt {attempt+1}/{max_retries})[/yellow]")
                time.sleep(60)
                continue

            if model.startswith("k2think/"):
                rprint(f"[yellow]K2 API failed. Switching to Gemini...[/yellow]")
                GLOBAL_K2_FAILED = True
                return call_ai_gemini_fallback(messages)

            if "busy" in error_str_lower or "503" in error_msg:
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                    retry_delay *= 2
                    continue
            
            rprint(f"[bold red]AI Error ({model}):[/bold red] {error_msg}")
            # Log the full traceback if it's a NameError or serious failure
            if "NameError" in error_msg or "AttributeError" in error_msg:
                 import traceback
                 rprint(f"[dim]{traceback.format_exc()}[/dim]")
            return ""
    return ""

def call_ai_gemini_fallback(messages: List[Dict[str, str]]) -> str:
    try:
        gemini_key = GLOBAL_CONFIG.get("gemini_key")
        if not gemini_key: return ""
        
        # Retry loop for Gemini fallback
        for attempt in range(3):
            try:
                from litellm import completion
                response = completion(
                    model="gemini/gemini-3-flash-preview",
                    messages=messages,
                    api_key=gemini_key
                )
                return response['choices'][0]['message']['content']
            except Exception as e:
                if "429" in str(e) or "resource_exhausted" in str(e).lower():
                    rprint(f"[yellow]Gemini Rate Limit (Fallback). Waiting 60s...[/yellow]")
                    time.sleep(60)
                    continue
                raise e
        return ""
    except Exception:
        return ""

def generate_pdf_enhanced(docs_dir: Path, logo_path: str = "", author: str = "doced User"):
    """Convert generated Markdowns to PDF with specialized styling."""
    pdf = MarkdownPdf(toc_level=0)
    
    # CSS Injection for Premium Feel
    css = """
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
    body { font-family: 'Inter', sans-serif; line-height: 1.6; color: #333; }
    h1, h2, h3 { color: #111; margin-top: 1.5em; }
    code { background: #f4f4f4; padding: 2px 5px; border-radius: 3px; font-family: 'Courier New', monospace; }
    pre { background: #f4f4f4; padding: 10px; border-radius: 5px; overflow-x: auto; }
    img { max-width: 100%; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
    """
    pdf.add_section(Section(f"<style>{css}</style>", toc=False))
    
    project_name = docs_dir.parent.name
    date_str = datetime.now().strftime("%B %d, %Y")
    
    # Pure Markdown Cover Page (Robustness Fix)
    cover_md = f"""
# {project_name}

## Documentation Suite

<br><br><br>

**{date_str}**

*Prepared for {author}*

<br><br><br><br><br>
    """
    
    pdf.add_section(Section(cover_md, toc=False))
    
    files_to_process = ["README.md", "TUTORIAL.md", "ARCHITECTURE.md", "HELP.md", "CONTRIBUTING.md"]
    
    for fname in files_to_process:
        fpath = docs_dir / fname
        if fpath.exists():
            content = fpath.read_text(encoding="utf-8")
            
            # Convert Mermaid to Local Images (Downloaded via utils)
            content = convert_charts_to_images(content, docs_dir)
            
            pdf.add_section(Section(content, toc=False))
    
    output_path = docs_dir / "Documentation_Premium.pdf"
    pdf.save(output_path)
    rprint(f"[green]Premium PDF generated at {output_path}[/green]")

def generate_pdf_board_ready(docs_dir: Path, standard: str, readiness: int):
    """Generate a formal, board-room ready compliance report."""
    pdf = MarkdownPdf(toc_level=0)
    
    css = """
    @import url('https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Inter:wght@400;700&display=swap');
    body { font-family: 'Inter', sans-serif; color: #1a1a1a; padding: 40px; }
    h1 { font-family: 'Libre Baskerville', serif; font-size: 32pt; color: #046307; text-align: center; margin-top: 100px; }
    h2 { border-bottom: 2px solid #046307; padding-bottom: 5px; color: #046307; margin-top: 2em; }
    .stat-box { background: #f0fdf4; border: 1px solid #046307; padding: 20px; border-radius: 10px; text-align: center; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
    th { background: #046307; color: white; }
    """
    pdf.add_section(Section(f"<style>{css}</style>", toc=False))
    
    # Cover Page
    cover = f"""
# {docs_dir.parent.name}
## {standard} Compliance Audit Report

<br><br>

<div class="stat-box">
  <h2 style="margin:0; border:0;">Certification Readiness</h2>
  <h1 style="margin:10px 0; border:0; color:#046307;">{readiness}%</h1>
</div>

<br><br><br>

**Date:** {datetime.now().strftime('%B %d, %Y')}
**Status:** Internal Release / Board-Ready
    """
    pdf.add_section(Section(cover, toc=False))
    
    # Audit Sections
    audit_files = ["SSP.md", "DATA_FLOW.md", "ARCHITECTURE.md"]
    for fname in audit_files:
        fpath = docs_dir / fname
        if fpath.exists():
            content = fpath.read_text(encoding="utf-8")
            content = convert_charts_to_images(content, docs_dir)
            pdf.add_section(Section(content, toc=False))
            
    output_path = docs_dir / "Compliance_Report.pdf"
    pdf.save(output_path)

@app.command()
def create(path: Path = typer.Argument(Path("."), help="Path to the codebase")):
    """Launch the doced Dashboard for this project."""
    launch_gui()
    check_environment()
    config = load_config()
    gemini_key = config.get("gemini_key")
    k2_key = config.get("k2_key")
    logo_path = config.get("logo_path", "")
    primary_color = config.get("primary_color", "#007ACC")
    
    style = config.get("style", "Corporate")
    
    report_type = inquirer.select(
        message="Select Report Type:",
        choices=["Comprehensive (Full Suite)", "Small", "Fun", "Vibe", "Business"],
        default="Comprehensive (Full Suite)"
    ).execute()
    
    author = inquirer.text(message="Author Name (for PDF Cover):", default="Developer").execute()
    
    if not gemini_key or not k2_key:
        rprint("[red]Missing API keys. Run 'doced init'.[/red]")
        raise typer.Exit(code=1)

    scanner = CodeScanner(path)
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True) as progress:
        progress.add_task(description="Scanning codebase...", total=None)
        code_context, stats = scanner.scan()
    
    if not code_context or len(code_context.strip()) < 10:
        rprint("[red]No significant code found! Check your .gitignore or path.[/red]")
        raise typer.Exit(code=1)

    # Project Stats Panel
    ext_list = ", ".join([f"{k} ({v})" for k, v in stats['extensions'].items()])
    rprint(Panel(
        f"📂 [bold cyan]Project:[/bold cyan] {path.resolve().name}\n"
        f"📄 [bold cyan]Files Scanned:[/bold cyan] {stats['total_files']}\n"
        f"📊 [bold cyan]Extensions:[/bold cyan] {ext_list}\n"
        f"📏 [bold cyan]Context Size:[/bold cyan] {len(code_context)} chars",
        title="Project Vital Statistics",
        border_style="blue"
    ))

    console.rule("[bold cyan]Phase 2: Deep Architecture Analysis (K2 Thinking Mode)[/bold cyan]")
    messages = [
        {"role": "system", "content": "You are a World-Class Software Architect. Analyze this codebase and extract the core architectural patterns, data flow, and key components."},
        {"role": "user", "content": f"Codebase:\n{code_context[:500000]}"}
    ]
    with console.status("[bold cyan]K2-v2 is Deep Thinking...[/bold cyan]"):
        architecture_map = call_ai("k2think/MBZUAI-IFM/K2-Think-v2", messages, k2_key)
    
    if not architecture_map:
        rprint("[yellow]K2 Analysis failed. Trying Gemini-Flash as fallback...[/yellow]")
        with console.status("[bold yellow]Gemini Fallback Analysis...[/bold yellow]"):
            architecture_map = call_ai("gemini/gemini-3-flash-preview", messages, gemini_key)
    
    interactive_mode = config.get("interactive_mode", False)
    interview_context = "[No Interview Data - Fully AI Generated]"

    if interactive_mode:
        console.rule("[bold magenta]Phase 3: Intelligent Interview Preparation[/bold magenta]")
        k2_q_prompt = f"Generate 5 high-impact architectural questions based on the analysis. Return as a raw JSON list of strings."
        start_messages = [{"role": "user", "content": f"{architecture_map}\n\n{k2_q_prompt}"}]
        
        with console.status("[bold magenta]K2 v2 is formulating deep questions...[/bold magenta]"):
            questions_json = call_ai("k2think/MBZUAI-IFM/K2-Think-v2", start_messages, k2_key)
            
        try:
            questions_json = questions_json.replace("```json", "").replace("```", "").strip()
            questions = json.loads(questions_json)
        except:
            questions = DEFAULT_QUESTIONS

        console.rule("[bold yellow]Phase 4: Developer Interview[/bold yellow]")
        rprint("[dim italic]Answer these questions to add human context to the documentation.[/dim italic]\n")
        answers = {}
        for i, q in enumerate(questions, 1):
            ans = inquirer.text(message=f"Q{i}: {q}").execute()
            answers[q] = ans
        
        interview_context = "\n".join([f"Q: {q}\nA: {a}" for q, a in answers.items()])
    else:
        rprint("[dim yellow]Note: Interactive Interview Mode is disabled. Documentation will be purely AI-driven.[/dim yellow]\n")

    console.rule("[bold green]Phase 5: High-Fidelity Document Generation[/bold green]")
    docs_path = path / "docs"
    docs_path.mkdir(exist_ok=True)
    
    def generate_doc_file(filename, prompt_focus):
        rprint(f"Generating [cyan]{filename}[/cyan]...")
        time.sleep(1)
        
        prompt = f"""
        Create a professional '{filename}'.
        
        CONTEXT:
        {architecture_map}
        {interview_context}
        
        REQUIREMENTS:
        {prompt_focus}
        
        STYLE:
        - Tone: {style}
        - Brand Color: {primary_color}
        - **Visuals**: Use Mermaid.js diagrams.
        """
        
        msgs = [{"role": "system", "content": K2_SYSTEM_PROMPT}, {"role": "user", "content": prompt}]
        content = call_ai("k2think/MBZUAI-IFM/K2-Think-v2", msgs, k2_key)
        (docs_path / filename).write_text(content, encoding="utf-8")
        rprint(f"[green]✓ {filename}[/green]")

    generate_doc_file("README.md", "Comprehensive README.")
    generate_doc_file("TUTORIAL.md", "Tutorial.")
    generate_doc_file("ARCHITECTURE.md", "Deep dive architecture with Mermaid.")
    generate_doc_file("HELP.md", "FAQ.")
    generate_doc_file("CONTRIBUTING.md", "Contribution guide.")
    generate_doc_file("VIDEO_SCRIPT.md", "30s Promo Script.")

    console.rule("[bold white]Phase 6: Multi-Media Assets[/bold white]")
    script_path = docs_path / "VIDEO_SCRIPT.md"
    if script_path.exists():
        script_content = script_path.read_text()
        video_html_path = docs_path / "PROMO_VIZ.html"
        rprint("Designing Custom Premium Video Page with Gemini...")
        success = generate_video_html(video_html_path, script_content, gemini_key, path.name)
        if success:
            rprint(f"[green]✓ Generated Custom AI Video Page: {video_html_path}[/green]")

    console.rule("[bold red]Phase 7: Premium Export[/bold red]")
    try:
        generate_pdf_enhanced(docs_path, logo_path, author)
    except Exception as e:
        rprint(f"[red]PDF Error: {e}[/red]")

    rprint("\n")
    rprint(Panel(
        f"[bold green]✨ Documentation Generation Complete! ✨[/bold green]\n\n"
        f"📂 [cyan]Location:[/cyan] {docs_path.relative_to(path)}\n"
        f"📝 [cyan]Files:[/cyan] 5 MDs + 1 PDF + 1 AI Video Page\n"
        f"🤖 [cyan]Engine:[/cyan] Powered by K2 Think v2\n\n"
        f"[bold white]Run 'open {docs_path}/Documentation_Premium.pdf' to view.[/bold white]",
        title="[bold green]Success[/bold green]",
        border_style="green",
        expand=False
    ))

if __name__ == "__main__":
    app()
