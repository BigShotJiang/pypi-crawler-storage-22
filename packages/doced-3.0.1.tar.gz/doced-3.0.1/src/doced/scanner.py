import os
from pathlib import Path
from typing import List, Optional
import pathspec

class CodeScanner:
    def __init__(self, root_path: Path):
        self.root_path = root_path
        self.gitignore = self._load_gitignore()

    def _load_gitignore(self) -> Optional[pathspec.PathSpec]:
        gitignore_path = self.root_path / ".gitignore"
        if gitignore_path.exists():
            with open(gitignore_path, "r") as f:
                return pathspec.PathSpec.from_lines("gitwildmatch", f)
        return None

    def should_ignore(self, path: Path) -> bool:
        # Always ignore .git and common venv/cache directories
        # Calculate relative path from root
        try:
            rel_path = path.relative_to(self.root_path)
        except ValueError:
            return True
            
        rel_str = str(rel_path)
        
        # Default ignores
        if ".git" in rel_path.parts:
            return True
        if "__pycache__" in rel_path.parts:
            return True
        if ".venv" in rel_path.parts or "venv" in rel_path.parts:
            return True
        if "node_modules" in rel_path.parts:
            return True
        if path.name == "poetry.lock" or path.name == "package-lock.json":
            return True
        if path.suffix in [".pyc", ".png", ".jpg", ".jpeg", ".svg", ".pdf", ".zip", ".tar", ".gz"]:
            return True

        if self.gitignore:
            return self.gitignore.match_file(rel_str)
        
        return False

    def scan(self):
        code_context = []
        file_count = 0
        extension_stats = {}
        
        for root, dirs, files in os.walk(self.root_path):
            # Modify dirs in-place to skip ignored directories
            # This is an optimization to avoid descending into ignored dirs
            # We need to check the full path of the directory
            dirs[:] = [d for d in dirs if not self.should_ignore(Path(root) / d)]
            
            for file in files:
                file_path = Path(root) / file
                if self.should_ignore(file_path):
                    continue

                try:
                    # Limit file size to avoid blowing up context, e.g. 100KB
                    if file_path.stat().st_size > 100 * 1024:
                        code_context.append(f"--- FILE: {file_path.relative_to(self.root_path)} (SKIPPED: Too large) ---")
                        continue

                    # Attempt to read as text
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    
                    code_context.append(f"--- FILE: {file_path.relative_to(self.root_path)} ---")
                    code_context.append(content)
                    code_context.append("\n")
                    file_count += 1
                    ext = file_path.suffix or "no-ext"
                    extension_stats[ext] = extension_stats.get(ext, 0) + 1
                except Exception as e:
                    code_context.append(f"--- FILE: {file_path.relative_to(self.root_path)} (ERROR: {str(e)}) ---")

        return "\n".join(code_context), {"total_files": file_count, "extensions": extension_stats}
