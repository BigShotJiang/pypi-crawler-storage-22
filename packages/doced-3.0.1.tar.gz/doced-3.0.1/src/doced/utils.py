import re
import base64
import json
import urllib.request
import shutil
import time
from pathlib import Path
from rich import print as rprint

def convert_charts_to_images(content: str, docs_dir: Path) -> str:
    """
    Finds mermaid code blocks, generates mermaid.ink URLs, 
    DOWNLOADS them to docs/assets/, and replaces links with local paths.
    """
    assets_dir = docs_dir / "assets"
    assets_dir.mkdir(exist_ok=True)
    
    pattern = r"```mermaid\n(.*?)\n```"
    
    # Counter for unique filenames
    chart_counter = 0
    
    def replacer(match):
        nonlocal chart_counter
        code = match.group(1)
        
        # 1. Generate URL
        # Use standard base64 encoding (mermaid.ink supports it)
        try:
            state = {
                "code": code,
                "mermaid": {"theme": "default", "format": "png"}
            }
            json_str = json.dumps(state)
            encoded = base64.b64encode(json_str.encode('utf-8')).decode('utf-8')
            url = f"https://mermaid.ink/img/{encoded}?type=png"
            
            # 2. Download Image with Retry (Fix for 503/403)
            filename = f"diagram_{chart_counter}.png"
            filepath = assets_dir / filename
            chart_counter += 1
            
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
                    with urllib.request.urlopen(req, timeout=10) as response, open(filepath, 'wb') as out_file:
                        shutil.copyfileobj(response, out_file)
                    break # Success
                except Exception as e:
                    if attempt < max_retries - 1:
                        # Wait and retry for 503s or network blips
                        time.sleep(2)
                        continue
                    raise e # Re-raise on final failure
                
            return f"![Diagram](assets/{filename})"
            
        except Exception as e:
            # Fallback to code block if download fails
            error_msg = str(e)
            if "HTTP Error 400" in error_msg:
                rprint(f"[yellow]Mermaid Diagram Error (Syntax?): {error_msg}[/yellow]")
            else:
                rprint(f"[yellow]Failed to download diagram: {error_msg}[/yellow]")
            
            return f"*(Diagram download failed: {error_msg})*\n```mermaid\n{code}\n```"
        
    return re.sub(pattern, replacer, content, flags=re.DOTALL)
