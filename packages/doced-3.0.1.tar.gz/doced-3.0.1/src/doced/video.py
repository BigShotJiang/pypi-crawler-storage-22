from pathlib import Path
import json
import re
# from litellm import completion (Lazy loaded inside function)
from rich import print as rprint

def generate_video_html(output_path: Path, script_content: str, api_key: str, project_name: str = "Project"):
    """
    Uses Gemini to generate a custom, premium HTML5 Product Page/Animation.
    """
    # 1. CLEAN SCRIPT
    # Remove lines causing artifacts
    clean_lines = []
    for line in script_content.split('\n'):
        # Remove timestamps |00:02|
        line = re.sub(r'\|[\d:.]+\|', '', line)
        # Remove directions [Scene:...] or (Camera pans...)
        line = re.sub(r'\[.*?\]', '', line)
        line = re.sub(r'\(.*?\)', '', line)
        # Remove markdown bold/italic
        line = line.replace('**', '').replace('*', '').replace('"', '').replace("'", "")
        # Remove Scene headers
        if line.strip().lower().startswith("scene") or line.strip().lower().startswith("visual"):
            continue
        
        if line.strip():
            clean_lines.append(line.strip())
            
    cleaned_script = "\n".join(clean_lines)

    prompt = f"""
    You are a Creative Technologist and Frontend Expert (Three.js/GSAP).
    
    Goal: Create a single-file 'PROMO_VIZ.html' that acts as a High-Tech Product Landing Page & Kinetic Typography Video for the project '{project_name}'.
    
    SCRIPT TO ANIMATE:
    {cleaned_script}
    
    CRITICAL REQUIREMENTS:
    1. **Single File**: Embed ALL CSS/JS. No external files except stable CDNs (GSAP).
    2. **Content**: Animate ONLY the spoken text from the script above. 
    3. **NO ARTIFACTS**: Do NOT animate directions like "Scene 1", "Music", "Camera", etc. Only the copy.
    4. **Visual Style**: Dark mode, Cyberpunk, or Apple-Clean. High-end physics or scrolling effects.
    5. **Ending**: Big Call To Action with project name.
    
    OUTPUT:
    Return ONLY the raw HTML code. Do not wrap in markdown code blocks.
    """
    
    try:
        from litellm import completion
        response = completion(
            model="gemini/gemini-3-flash-preview",
            messages=[{"role": "user", "content": prompt}],
            api_key=api_key
        )
        content = response['choices'][0]['message']['content']
        
        # Clean potential markdown wrappers
        content = content.replace("```html", "").replace("```", "")
        
        output_path.write_text(content, encoding="utf-8")
        return True
    except Exception as e:
        rprint(f"[red]Video Generation Failed: {e}[/red]")
        return False
