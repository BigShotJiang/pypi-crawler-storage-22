#!/usr/bin/env python3
"""
Example demonstrating Go duration parsing in docker-compose models.

This example shows how the GoDuration type automatically converts
Go-style duration strings from docker-compose.yml files into Python
timedelta objects.
"""

from datetime import timedelta

from pydantic import BaseModel

from dcm import GoDuration, parse_compose_files


def example_direct_usage():
    """Example of using GoDuration directly in a Pydantic model."""

    class MyHealthcheck(BaseModel):
        interval: GoDuration
        timeout: GoDuration
        retries: int

    # Parse Go duration strings directly
    hc = MyHealthcheck(interval="30s", timeout="5s", retries=3)

    print("Healthcheck configuration:")
    print(f"  Interval: {hc.interval} ({hc.interval.total_seconds()}s)")
    print(f"  Timeout: {hc.timeout} ({hc.timeout.total_seconds()}s)")
    print(f"  Retries: {hc.retries}")

    # Can also use timedelta directly
    hc2 = MyHealthcheck(
        interval=timedelta(seconds=30), timeout=timedelta(seconds=5), retries=3
    )
    assert hc.interval == hc2.interval


def example_parsing_duration_strings():
    """Example of parsing various Go duration formats."""
    durations = [
        "5s",  # 5 seconds
        "100ms",  # 100 milliseconds
        "1m",  # 1 minute
        "1h30m",  # 1 hour 30 minutes
        "2h30m45s",  # 2 hours, 30 minutes, 45 seconds
        "1.5s",  # 1.5 seconds (decimal)
    ]

    print("\nParsing various Go duration formats:")
    for dur_str in durations:
        parsed = GoDuration.parse_go_duration(dur_str)
        print(f"  '{dur_str}' -> {parsed} ({parsed.total_seconds()}s)")


def example_compose_file_parsing():
    """Example of parsing a docker-compose file with durations."""
    import tempfile

    compose_yaml = """
services:
  web:
    image: nginx:latest
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  db:
    image: postgres:latest
    healthcheck:
      test: ["CMD-SHELL", "pg_isready"]
      interval: 5s
      timeout: 3s
      retries: 5
    deploy:
      restart_policy:
        delay: 5s
        window: 120s
"""

    with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
        f.write(compose_yaml)
        f.flush()

        print("\nParsing docker-compose file with durations:")
        compose = parse_compose_files(f.name)
        print(f"  Successfully parsed {len(compose.services)} services:")
        for service_name in compose.services:
            print(f"    - {service_name}")


if __name__ == "__main__":
    print("=" * 60)
    print("Go Duration Usage Examples")
    print("=" * 60)

    example_direct_usage()
    example_parsing_duration_strings()
    example_compose_file_parsing()

    print("\n" + "=" * 60)
    print("All examples completed successfully!")
    print("=" * 60)
