from docling.pipeline.standard_pdf_pipeline import StandardPdfPipeline


class ThreadedStandardPdfPipeline(StandardPdfPipeline):
    """Backwards compatible import for ThreadedStandardPdfPipeline."""
