"""CLI package for DocSeal."""
