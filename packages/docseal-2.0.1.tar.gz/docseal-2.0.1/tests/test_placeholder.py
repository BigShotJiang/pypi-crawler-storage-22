def test_placeholder():
    """Placeholder test to keep CI green until real tests are added."""
    assert True
