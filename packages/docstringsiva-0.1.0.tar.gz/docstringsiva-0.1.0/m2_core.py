"""
Core module for the Docstring Generator tool.

This module provides functionality to generate, validate, and instrument
Python docstrings according to various documentation styles including
Google, NumPy, and reStructuredText formats.

Features:
- Automatic docstring generation for functions and classes
- PEP-257 compliance validation
- Support for multiple documentation styles
- Coverage and compliance reporting
"""

import ast
import astor
import pydocstyle
import re
import os
import tempfile
import sys
from typing import Dict, List, Tuple, Union, Optional
import json


class DocstringGenerator:
    """
    Main class for generating docstrings for Python code.

    This class analyzes Python AST nodes and generates appropriate docstrings
    in the specified style (Google, NumPy, or reStructuredText).

    Attributes:
        SUPPORTED_STYLES (List[str]): List of supported docstring styles.
        style (str): Current documentation style being used.
    """

    SUPPORTED_STYLES = ['google', 'numpy', 'reST']

    # Common verb mappings for generating descriptive docstrings
    ACTION_VERBS = {
        'get': 'Retrieve',
        'set': 'Set',
        'add': 'Add',
        'remove': 'Remove',
        'update': 'Update',
        'delete': 'Delete',
        'create': 'Create',
        'generate': 'Generate',
        'validate': 'Validate',
        'check': 'Check',
        'process': 'Process',
        'handle': 'Handle',
        'parse': 'Parse',
        'format': 'Format',
        'convert': 'Convert',
        'calculate': 'Calculate',
        'compute': 'Compute',
        'find': 'Find',
        'search': 'Search',
        'build': 'Build',
        'make': 'Make',
        'init': 'Initialize',
        'load': 'Load',
        'save': 'Save',
        'write': 'Write',
        'read': 'Read',
        'copy': 'Copy',
        'move': 'Move',
        'clear': 'Clear',
        'reset': 'Reset',
        'start': 'Start',
        'stop': 'Stop',
        'run': 'Run',
        'execute': 'Execute',
        'perform': 'Perform',
        'apply': 'Apply',
        'filter': 'Filter',
        'map': 'Map',
        'reduce': 'Reduce',
        'transform': 'Transform',
        'extract': 'Extract',
        'insert': 'Insert',
        'replace': 'Replace',
        'match': 'Match',
        'compare': 'Compare',
        'merge': 'Merge',
        'split': 'Split',
        'join': 'Join',
        'sort': 'Sort',
        'order': 'Order',
        'count': 'Count',
        'sum': 'Calculate sum of',
        'average': 'Calculate average of',
        'min': 'Find minimum',
        'max': 'Find maximum',
    }

    # Common type descriptions
    TYPE_DESCRIPTIONS = {
        'str': 'string',
        'int': 'integer',
        'float': 'floating-point number',
        'bool': 'boolean',
        'list': 'list',
        'dict': 'dictionary',
        'set': 'set',
        'tuple': 'tuple',
        'None': 'None',
        'Any': 'any type',
        'object': 'object',
        'bytes': 'bytes',
        'bytearray': 'byte array',
        'range': 'range',
        'map': 'map',
        'filter': 'filter',
        'generator': 'generator',
        'iterator': 'iterator',
        'Path': 'file path',
        'PathLike': 'path-like object',
        'IO': 'I/O object',
        'Callable': 'callable',
        'Type': 'type',
        'Optional': 'optional value',
        'Union': 'union type',
        'List': 'list',
        'Dict': 'dictionary',
        'Set': 'set',
        'Tuple': 'tuple',
    }

    def __init__(self, style: str = 'google'):
        """
        Initialize the docstring generator with the specified style.

        Args:
            style (str): Documentation style to use. Valid options are
                        'google', 'numpy', and 'reST'. Defaults to 'google'.

        Raises:
            ValueError: If an unsupported style is specified.
        """
        if style.lower() not in self.SUPPORTED_STYLES:
            raise ValueError(
                f"Unsupported style: {style}. "
                f"Choose from {self.SUPPORTED_STYLES}"
            )
        self.style = style.lower()

    def _infer_description(self, name: str, is_class: bool = False) -> str:
        """
        Generate a descriptive phrase based on the name of a function or class.

        This method converts snake_case or camelCase names into readable
        descriptions by splitting on underscores/capital letters and mapping
        action verbs to their meanings.

        Args:
            name (str): The name of the function or class.
            is_class (bool): Whether the name is for a class (True) or
                           function (False).

        Returns:
            str: A descriptive phrase suitable for a docstring summary.
        """
        # Split camelCase or snake_case
        words = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z][a-z]|\d|\W)|\d+', name)
        words = [w.lower() for w in words if w]

        if not words:
            description = f"{'Class' if is_class else 'Function'} object" if is_class else f"{name} function"
            return description

        # Check for action verb at the start
        first_word = words[0]
        if first_word in self.ACTION_VERBS:
            action = self.ACTION_VERBS[first_word]
            remaining = ' '.join(words[1:]) if len(words) > 1 else 'item'
            # Clean up the remaining words
            remaining = re.sub(r'[_\-]', ' ', remaining)
            if is_class:
                description = f"{action} {remaining}"
            else:
                description = f"{action} {remaining}"
            # Capitalize first letter
            return description[0].upper() + description[1:] if description else description

        # Generic description
        description = ' '.join(words)
        if is_class:
            # Capitalize and describe as a class
            description = description.title()
            if not description.endswith('er') and not description.endswith('or'):
                description = f"{description} class"
            else:
                description = f"{description} class"
        else:
            # For functions, create a verb phrase
            description = description.replace('_', ' ')
            if not description.endswith('s'):
                description = f"{description} operation"
            else:
                description = f"{description} operation"

        # Capitalize first letter
        if description:
            description = description[0].upper() + description[1:]

        return description

    def _describe_type(self, type_str: str) -> str:
        """
        Generate a human-readable description of a type.

        Args:
            type_str (str): The type annotation as a string.

        Returns:
            str: A human-readable description of the type.
        """
        if not type_str or type_str == 'None':
            return 'None'

        # Clean up the type string
        type_str = type_str.strip()

        # Handle Optional[T]
        if type_str.startswith('Optional['):
            inner = type_str[9:-1]
            return f'optional {self._describe_type(inner)}'

        # Handle Union types
        if type_str.startswith('Union['):
            inner = type_str[6:-1]
            types = inner.split(', ')
            described = [self._describe_type(t.strip()) for t in types]
            return ' or '.join(described)

        # Handle List[T]
        if type_str.startswith('List['):
            inner = type_str[5:-1]
            return f'list of {self._describe_type(inner)}'

        # Handle Dict[K, V]
        if type_str.startswith('Dict['):
            inner = type_str[5:-1]
            parts = inner.split(', ')
            if len(parts) == 2:
                return f'dictionary mapping {self._describe_type(parts[0])} to {self._describe_type(parts[1])}'
            return 'dictionary'

        # Handle Tuple[T, ...]
        if type_str.startswith('Tuple['):
            inner = type_str[6:-1]
            if inner.endswith('...'):
                inner = inner[:-3]
                return f'tuple of {self._describe_type(inner)}'
            return 'tuple'

        # Handle Callable
        if type_str.startswith('Callable['):
            return 'callable'

        # Check for known type descriptions
        base_type = re.sub(r'^(Optional|Union|List|Dict|Tuple|Set)\[.*\]$',
                          lambda m: m.group(1).lower(), type_str)

        return self.TYPE_DESCRIPTIONS.get(base_type, type_str)

    def _describe_parameter(self, param_name: str, type_str: str,
                           default_value: str = None) -> str:
        """
        Generate a description for a function parameter.

        Args:
            param_name (str): The name of the parameter.
            type_str (str): The type annotation of the parameter.
            default_value (str): Default value if any.

        Returns:
            str: A description of the parameter.
        """
        # Clean parameter name
        clean_name = param_name
        if clean_name.startswith('*'):
            clean_name = clean_name[1:]
        if clean_name.startswith('**'):
            clean_name = clean_name[2:]

        # Generate description based on name patterns
        name_lower = clean_name.lower()

        if 'id' in name_lower:
            desc = f'The unique identifier'
        elif 'name' in name_lower:
            desc = f'The name'
        elif 'value' in name_lower:
            desc = f'The value'
        elif 'data' in name_lower:
            desc = f'The data to process'
        elif 'file' in name_lower or 'path' in name_lower:
            desc = f'The file path'
        elif 'index' in name_lower:
            desc = f'The index position'
        elif 'count' in name_lower:
            desc = f'The count'
        elif 'size' in name_lower:
            desc = f'The size'
        elif 'type' in name_lower:
            desc = f'The type'
        elif 'status' in name_lower:
            desc = f'The status'
        elif 'config' in name_lower or 'settings' in name_lower:
            desc = f'The configuration'
        elif 'options' in name_lower or 'params' in name_lower:
            desc = f'The options or parameters'
        elif 'callback' in name_lower:
            desc = f'The callback function'
        elif 'error' in name_lower or 'exception' in name_lower:
            desc = f'The error or exception'
        elif 'message' in name_lower:
            desc = f'The message'
        elif 'response' in name_lower:
            desc = f'The response'
        elif 'request' in name_lower:
            desc = f'The request'
        elif 'user' in name_lower:
            desc = f'The user'
        elif 'result' in name_lower:
            desc = f'The result'
        elif 'output' in name_lower:
            desc = f'The output'
        elif 'input' in name_lower:
            desc = f'The input'
        elif 'key' in name_lower:
            desc = f'The key'
        elif 'content' in name_lower:
            desc = f'The content'
        elif 'mode' in name_lower:
            desc = f'The mode'
        elif 'format' in name_lower:
            desc = f'The format'
        elif 'level' in name_lower:
            desc = f'The level'
        elif 'limit' in name_lower:
            desc = f'The maximum limit'
        elif 'offset' in name_lower or 'skip' in name_lower:
            desc = f'The offset or skip value'
        elif 'order' in name_lower or 'sort' in name_lower:
            desc = f'The sort order'
        elif 'filter' in name_lower:
            desc = f'The filter'
        elif 'condition' in name_lower:
            desc = f'The condition'
        elif 'separator' in name_lower or 'delimiter' in name_lower:
            desc = f'The separator or delimiter'
        elif 'encoding' in name_lower:
            desc = f'The text encoding'
        elif 'timeout' in name_lower:
            desc = f'The timeout value'
        elif 'retry' in name_lower:
            desc = f'The number of retry attempts'
        elif 'prefix' in name_lower:
            desc = f'The prefix'
        elif 'suffix' in name_lower:
            desc = f'The suffix'
        elif 'pattern' in name_lower:
            desc = f'The pattern to match'
        elif 'query' in name_lower or 'search' in name_lower:
            desc = f'The search query'
        elif 'flag' in name_lower or 'option' in name_lower or 'flag' in name_lower:
            desc = f'The flag or option'
        else:
            # Generic description
            desc = f'The {clean_name.replace("_", " ")}'

        # Add type information
        type_desc = self._describe_type(type_str)
        if type_desc and type_desc != 'None':
            if ' or ' in type_desc:
                desc = f'{desc} ({type_desc})'
            else:
                desc = f'{desc} ({type_desc})'

        # Add default value info
        if default_value and default_value not in ['None', '']:
            desc = f'{desc}. Defaults to {default_value}'

        return desc

    def _describe_return(self, return_type: str, yields: bool = False) -> str:
        """
        Generate a description for return values.

        Args:
            return_type (str): The return type annotation.
            yields (bool): Whether this is a yield description.

        Returns:
            str: A description of the return value.
        """
        if return_type == 'None' or not return_type:
            if yields:
                return 'The next value from the generator'
            return None

        type_desc = self._describe_type(return_type)

        if yields:
            return f'{type_desc} - The yielded value'

        # For return values, infer from context
        if 'bool' in return_type:
            return f'{type_desc} - True if successful, False otherwise'
        elif 'list' in return_type.lower() or return_type.startswith('List'):
            return f'{type_desc} - The list of items'
        elif 'dict' in return_type.lower() or return_type.startswith('Dict'):
            return f'{type_desc} - The dictionary of results'
        elif 'str' in return_type:
            return f'{type_desc} - The resulting string'
        elif 'int' in return_type or 'float' in return_type:
            return f'{type_desc} - The calculated value'
        elif 'Path' in return_type or 'str' in return_type:
            return f'{type_desc} - The path to the file or directory'

        return f'{type_desc} - The result'

    def _describe_exception(self, exc_type: str) -> str:
        """
        Generate a description for an exception.

        Args:
            exc_type (str): The exception type name.

        Returns:
            str: A description of when the exception is raised.
        """
        exc_descriptions = {
            'ValueError': 'Raised when the input value is invalid',
            'TypeError': 'Raised when the argument type is incorrect',
            'KeyError': 'Raised when the specified key is not found',
            'IndexError': 'Raised when the index is out of range',
            'AttributeError': 'Raised when the attribute does not exist',
            'RuntimeError': 'Raised when an unexpected error occurs',
            'IOError': 'Raised when an I/O operation fails',
            'FileNotFoundError': 'Raised when the specified file does not exist',
            'PermissionError': 'Raised when permission is denied',
            'TimeoutError': 'Raised when the operation times out',
            'ConnectionError': 'Raised when a connection fails',
            'Exception': 'Raised when an error occurs',
            'Error': 'Raised when an error occurs',
        }

        return exc_descriptions.get(exc_type, f'Raised when {exc_type.lower().replace("error", "an error")} occurs')

    def extract_function_info(self, node: ast.FunctionDef) -> Dict:
        """
        Extract function metadata from an AST node.

        This method analyzes a function definition node and extracts
        information about parameters, return types, exceptions, and
        generator functions.

        Args:
            node (ast.FunctionDef): The AST node representing the function.

        Returns:
            Dict: A dictionary containing function information including
                 name, arguments, return type, raises, and yields.
        """
        args = []

        # Extract regular arguments
        for arg in node.args.args:
            arg_type = ast.unparse(arg.annotation) if arg.annotation else "Any"
            default = None
            if arg.arg in node.args.defaults:
                default = ast.unparse(node.args.defaults[
                    len(node.args.defaults) - 1 - list(node.args.args).index(arg)
                ])
            args.append((arg.arg, arg_type, default))

        # Handle *args
        if node.args.vararg:
            args.append((f"*{node.args.vararg.arg}", "Any", None))

        # Handle **kwargs
        if node.args.kwarg:
            args.append((f"**{node.args.kwarg.arg}", "Any", None))

        # Handle keyword-only arguments
        for kwarg in node.args.kwonlyargs:
            arg_type = ast.unparse(kwarg.annotation) if kwarg.annotation else "Any"
            default = None
            kw_defaults = node.args.kw_defaults
            for i, arg in enumerate(node.args.kwonlyargs):
                if arg.arg == kwarg.arg and i < len(kw_defaults):
                    default = ast.unparse(kw_defaults[i]) if kw_defaults[i] else None
            args.append((kwarg.arg, arg_type, default))

        # Check for return annotation
        returns = ast.unparse(node.returns) if node.returns else "None"

        # Detect raises and yields
        raises = set()
        yields = False
        for stmt in ast.walk(node):
            if isinstance(stmt, ast.Raise) and stmt.exc:
                exc_type = ast.unparse(stmt.exc)
                # Clean up exception type name
                exc_type = re.sub(r'\(.*?\)', '', exc_type)
                exc_type = exc_type.strip()
                if exc_type and exc_type != 'Exception':
                    raises.add(exc_type)
            if isinstance(stmt, (ast.Yield, ast.YieldFrom)):
                yields = True

        return {
            'name': node.name,
            'args': args,
            'returns': returns,
            'raises': list(raises),
            'yields': yields,
            'async': isinstance(node, ast.AsyncFunctionDef)
        }

    def extract_class_info(self, node: ast.ClassDef) -> Dict:
        """
        Extract class metadata from an AST node.

        This method analyzes a class definition node and extracts
        information about attributes, methods, and base classes.

        Args:
            node (ast.ClassDef): The AST node representing the class.

        Returns:
            Dict: A dictionary containing class information including
                 name, attributes, methods, and inheritance.
        """
        attributes = []
        methods = []
        inheritance = []

        # Extract base classes
        for base in node.bases:
            base_name = ast.unparse(base)
            inheritance.append(base_name)

        # Find __init__ method to extract instance attributes
        init_method = None
        for body_item in node.body:
            if isinstance(body_item, ast.FunctionDef) and body_item.name == '__init__':
                init_method = body_item
                break

        if init_method:
            for stmt in ast.walk(init_method):
                if isinstance(stmt, ast.Assign):
                    for target in stmt.targets:
                        if isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name):
                            if target.value.id == 'self':
                                attr_type = "Any"
                                if hasattr(stmt, 'value') and isinstance(stmt.value, ast.Constant):
                                    # Infer type from default value
                                    val = stmt.value.value
                                    if isinstance(val, bool):
                                        attr_type = "bool"
                                    elif isinstance(val, (int, float)):
                                        attr_type = "int"
                                    elif isinstance(val, str):
                                        attr_type = "str"
                                    elif isinstance(val, list):
                                        attr_type = "list"
                                    elif isinstance(val, dict):
                                        attr_type = "dict"
                                elif hasattr(stmt, 'annotation') and stmt.annotation:
                                    attr_type = ast.unparse(stmt.annotation)
                                attributes.append((target.attr, attr_type))

        # Extract public methods (not starting with _)
        for body_item in node.body:
            if isinstance(body_item, ast.FunctionDef) and not body_item.name.startswith('_'):
                methods.append(body_item.name)
            elif isinstance(body_item, ast.AsyncFunctionDef) and not body_item.name.startswith('_'):
                methods.append(body_item.name)

        return {
            'name': node.name,
            'attributes': attributes,
            'methods': methods,
            'inheritance': inheritance
        }

    def generate_docstring(self, node: Union[ast.FunctionDef, ast.ClassDef]) -> str:
        """
        Generate a docstring for the given AST node.

        This method determines the type of node (function or class)
        and generates an appropriate docstring in the configured style.

        Args:
            node (Union[ast.FunctionDef, ast.ClassDef]): The AST node
                                                      to document.

        Returns:
            str: The generated docstring, or empty string if node type
                 is not supported.
        """
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            info = self.extract_function_info(node)
            return self._format_function_docstring(info)
        elif isinstance(node, ast.ClassDef):
            info = self.extract_class_info(node)
            return self._format_class_docstring(info)
        return ""

    def _format_function_docstring(self, info: Dict) -> str:
        """
        Format a function docstring according to the selected style.

        Args:
            info (Dict): Dictionary containing function information.

        Returns:
            str: The formatted docstring.
        """
        # Generate an imperative-style summary line to satisfy D401.
        words = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z][a-z]|\d|\W)|\d+', info['name'])
        base_name = ' '.join(w.lower() for w in words) if words else info['name'].lower()
        if info.get('async', False):
            description = f"Execute the async {base_name} operation."
        else:
            description = f"Perform the {base_name} operation."

        if self.style == 'google':
            return self._format_google_function_docstring(info, description)
        elif self.style == 'numpy':
            return self._format_numpy_function_docstring(info, description)
        else:
            return self._format_rest_function_docstring(info, description)

    def _format_google_function_docstring(self, info: Dict, description: str) -> str:
        """
        Format a function docstring in Google style.

        Args:
            info (Dict): Function information.
            description (str): The generated description.

        Returns:
            str: Google-style formatted docstring.
        """
        # Build sections content first
        section_lines = []

        # Arguments - only add if there are actual args (excluding self)
        args_without_self = [arg for arg in info['args'] if arg[0] != 'self']
        if args_without_self:
            section_lines.append("Args:")
            for arg_name, arg_type, default in args_without_self:
                param_desc = self._describe_parameter(arg_name, arg_type, default)
                section_lines.append(f"    {arg_name} ({arg_type}): {param_desc}")

        # Returns
        if info['yields']:
            section_lines.append("Yields:")
            return_desc = self._describe_return(info['returns'], yields=True)
            if return_desc:
                section_lines.append(f"    {return_desc}")
            else:
                section_lines.append("    The next value from the generator.")
        elif info['returns'] != "None":
            section_lines.append("Returns:")
            return_desc = self._describe_return(info['returns'])
            if return_desc:
                section_lines.append(f"    {return_desc}")
            else:
                section_lines.append(f"    {info['returns']}: The return value.")

        # Raises
        if info['raises']:
            section_lines.append("Raises:")
            for exc in info['raises']:
                exc_desc = self._describe_exception(exc)
                section_lines.append(f"    {exc}: {exc_desc}")

        # Build the complete docstring
        if not section_lines:
            # Single-line docstring
            return f'"""{description}."""'
        else:
            # Multi-line docstring with proper PEP-257 formatting
            # Summary line, blank line, description, blank line, sections
            lines = [f'{description}.', '']
            lines.extend(section_lines)
            # Add blank line before closing quotes for D209 compliance
            lines.append('')
            # Don't add leading newline - docstring starts immediately after """
            return '"""' + '\n' + '\n'.join(lines) + '"""'

    def _format_numpy_function_docstring(self, info: Dict, description: str) -> str:
        """
        Format a function docstring in NumPy style.

        Args:
            info (Dict): Function information.
            description (str): The generated description.

        Returns:
            str: NumPy-style formatted docstring.
        """
        # Build sections content first
        section_lines = []

        # Parameters - only add if there are actual args (excluding self)
        args_without_self = [arg for arg in info['args'] if arg[0] != 'self']
        if args_without_self:
            section_lines.append("Parameters")
            section_lines.append("----------")
            for arg_name, arg_type, default in args_without_self:
                param_desc = self._describe_parameter(arg_name, arg_type, default)
                section_lines.append(f"{arg_name} : {arg_type}")
                section_lines.append(f"    {param_desc}")

        # Returns
        if info['yields']:
            section_lines.append("Yields")
            section_lines.append("------")
            return_desc = self._describe_return(info['returns'], yields=True)
            section_lines.append(f"{info['returns']}")
            section_lines.append(f"    {return_desc}")
        elif info['returns'] != "None":
            section_lines.append("Returns")
            section_lines.append("-------")
            section_lines.append(f"{info['returns']}")
            return_desc = self._describe_return(info['returns'])
            section_lines.append(f"    {return_desc}")

        # Raises
        if info['raises']:
            section_lines.append("Raises")
            section_lines.append("------")
            for exc in info['raises']:
                exc_desc = self._describe_exception(exc)
                section_lines.append(f"{exc}")
                section_lines.append(f"    {exc_desc}")
                section_lines.append("")

        # Build the complete docstring
        if not section_lines:
            # Single-line docstring
            return f'"""{description}."""'
        else:
            # Multi-line docstring with proper PEP-257 formatting
            lines = [description, ""]
            lines.extend(section_lines)
            lines.append("")
            # Don't add leading newline - docstring starts immediately after """
            return '"""' + '\n' + '\n'.join(lines) + '"""'

    def _format_rest_function_docstring(self, info: Dict, description: str) -> str:
        """
        Format a function docstring in reStructuredText style.

        Args:
            info (Dict): Function information.
            description (str): The generated description.

        Returns:
            str: reStructuredText-style formatted docstring.
        """
        # Build sections content first
        section_lines = []

        # Parameters - only add if there are actual args (excluding self)
        args_without_self = [arg for arg in info['args'] if arg[0] != 'self']
        if args_without_self:
            for arg_name, arg_type, default in args_without_self:
                param_desc = self._describe_parameter(arg_name, arg_type, default)
                section_lines.append(f":param {arg_name}: {param_desc}")
                section_lines.append(f":type {arg_name}: {arg_type}")

        # Returns
        if info['yields']:
            return_desc = self._describe_return(info['returns'], yields=True)
            section_lines.append(f":yields: {return_desc}")
            section_lines.append(f":ytype: {info['returns']}")
        elif info['returns'] != "None":
            section_lines.append(f":returns: The return value ({info['returns']})")
            section_lines.append(f":rtype: {info['returns']}")

        # Raises
        if info['raises']:
            for exc in info['raises']:
                exc_desc = self._describe_exception(exc)
                section_lines.append(f":raises {exc}: {exc_desc}")

        # Build the complete docstring
        if not section_lines:
            # Single-line docstring
            return f'"""{description}."""'
        else:
            # Multi-line docstring with proper PEP-257 formatting
            lines = [description, ""]
            lines.extend(section_lines)
            lines.append("")
            # Don't add leading newline - docstring starts immediately after """
            return '"""' + '\n' + '\n'.join(lines) + '"""'

    def _format_class_docstring(self, info: Dict) -> str:
        """
        Format a class docstring according to the selected style.

        Args:
            info (Dict): Dictionary containing class information.

        Returns:
            str: The formatted docstring.
        """
        # Generate an imperative-style summary line to satisfy D401.
        words = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z][a-z]|\d|\W)|\d+', info['name'])
        base_name = ' '.join(w.lower() for w in words) if words else info['name'].lower()
        description = f"Represent the {base_name} class"

        if self.style == 'google':
            return self._format_google_class_docstring(info, description)
        elif self.style == 'numpy':
            return self._format_numpy_class_docstring(info, description)
        else:
            return self._format_rest_class_docstring(info, description)

    def _format_google_class_docstring(self, info: Dict, description: str) -> str:
        """
        Format a class docstring in Google style.

        Args:
            info (Dict): Class information.
            description (str): The generated description.

        Returns:
            str: Google-style formatted docstring.
        """
        # Build sections content first
        section_lines = []

        # Add inheritance info if present
        if info.get('inheritance'):
            section_lines.append(f"This class inherits from: {', '.join(info['inheritance'])}.")

        # Attributes
        if info['attributes']:
            section_lines.append("Attributes:")
            for attr_name, attr_type in info['attributes']:
                attr_desc = f"The {attr_name.replace('_', ' ')} attribute ({attr_type})"
                section_lines.append(f"    {attr_name} ({attr_type}): {attr_desc}")

        # Methods
        if info['methods']:
            section_lines.append("Methods:")
            for method in info['methods']:
                method_desc = f"The {method.replace('_', ' ')} method"
                section_lines.append(f"    {method}(): {method_desc}")

        # Build the complete docstring
        if not section_lines:
            # Single-line docstring
            return f'"""{description}."""'
        else:
            # Multi-line docstring with proper PEP-257 formatting
            # Summary line, blank line, description, blank line, sections
            lines = [f"{description}.", '']
            lines.extend(section_lines)
            # Add blank line before closing quotes for D209 compliance
            lines.append('')
            # Don't add leading newline - docstring starts immediately after """
            return '"""' + '\n' + '\n'.join(lines) + '"""'

    def _format_numpy_class_docstring(self, info: Dict, description: str) -> str:
        """
        Format a class docstring in NumPy style.

        Args:
            info (Dict): Class information.
            description (str): The generated description.

        Returns:
            str: NumPy-style formatted docstring.
        """
        # Build sections content first
        section_lines = []

        # Add inheritance info if present
        if info.get('inheritance'):
            section_lines.append(f"This class inherits from: {', '.join(info['inheritance'])}.")
            section_lines.append("")

        # Attributes
        if info['attributes']:
            section_lines.append("Attributes")
            section_lines.append("----------")
            for attr_name, attr_type in info['attributes']:
                attr_desc = f"The {attr_name.replace('_', ' ')} attribute"
                section_lines.append(f"{attr_name} : {attr_type}")
                section_lines.append(f"    {attr_desc}")
            section_lines.append("")

        # Methods
        if info['methods']:
            section_lines.append("Methods")
            section_lines.append("-------")
            for method in info['methods']:
                section_lines.append(f"{method}()")
                section_lines.append(f"    The {method.replace('_', ' ')} method.")
                section_lines.append("")

        # Build the complete docstring
        if not section_lines or section_lines == [""]:
            # Single-line docstring
            return f'"""{description}."""'
        else:
            # Multi-line docstring with proper PEP-257 formatting
            lines = [description, ""]
            lines.extend(section_lines)
            lines.append("")
            # Don't add leading newline - docstring starts immediately after """
            return '"""' + '\n' + '\n'.join(lines) + '"""'

    def _format_rest_class_docstring(self, info: Dict, description: str) -> str:
        """
        Format a class docstring in reStructuredText style.

        Args:
            info (Dict): Class information.
            description (str): The generated description.

        Returns:
            str: reStructuredText-style formatted docstring.
        """
        # Build sections content first
        section_lines = []

        # Attributes
        if info['attributes']:
            for attr_name, attr_type in info['attributes']:
                attr_desc = f"The {attr_name.replace('_', ' ')} attribute"
                section_lines.append(f":ivar {attr_name}: {attr_desc}")
                section_lines.append(f":vartype {attr_name}: {attr_type}")

        # Methods summary
        if info['methods']:
            section_lines.append("Methods:")
            for method in info['methods']:
                section_lines.append(f"    - {method}()")

        # Build the complete docstring
        if not section_lines:
            # Single-line docstring
            return f'"""{description}."""'
        else:
            # Multi-line docstring with proper PEP-257 formatting
            lines = [description, ""]
            lines.extend(section_lines)
            lines.append("")
            # Don't add leading newline - docstring starts immediately after """
            return '"""' + '\n' + '\n'.join(lines) + '"""'


class DocstringValidator:
    """
    Validator class for checking docstring quality and PEP-257 compliance.

    This class provides static methods to validate docstrings against
    PEP-257 conventions and analyze code documentation coverage.
    """

    @staticmethod
    def validate_file(file_path: str) -> List[Dict]:
        """
        Validate docstrings in a Python file against PEP-257 standards.

        Args:
            file_path (str): Path to the Python file to validate.

        Returns:
            List[Dict]: List of validation results containing line numbers,
                       error codes, and messages for each violation.
        """
        results = []
        for error in pydocstyle.check([file_path]):
            results.append({
                'line': error.line,
                'code': error.code,
                'message': error.message,
                'source': error.source
            })
        return results

    @staticmethod
    def analyze_code_quality(file_content: str) -> Dict:
        """
        Analyze code documentation quality and coverage.

        This method parses the code and calculates metrics including:
        - Total number of functions and classes
        - Number of documented vs undocumented items
        - Documentation coverage percentage
        - PEP-257 compliance metrics

        Args:
            file_content (str): The Python source code to analyze.

        Returns:
            Dict: A dictionary containing various quality metrics and
                 lists of undocumented items.
        """
        tree = ast.parse(file_content)

        # Count functions and classes
        functions = []
        classes = []

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                functions.append(node)
            elif isinstance(node, ast.ClassDef):
                classes.append(node)

        total_functions = len(functions)
        total_classes = len(classes)
        total_items = total_functions + total_classes

        # Get documented items
        documented_functions = 0
        documented_classes = 0
        undocumented_functions = []
        undocumented_classes = []

        for node in functions:
            docstring = ast.get_docstring(node)
            if docstring and len(docstring.strip()) > 0:
                documented_functions += 1
            else:
                undocumented_functions.append(node.name)

        for node in classes:
            docstring = ast.get_docstring(node)
            if docstring and len(docstring.strip()) > 0:
                documented_classes += 1
            else:
                undocumented_classes.append(node.name)

        documented_items = documented_functions + documented_classes
        undocumented_items = (total_functions - documented_functions) + (total_classes - documented_classes)
        coverage_percentage = round(documented_items / total_items * 100, 1) if total_items > 0 else 0

        # Get compliance data - WINDOWS-SAFE TEMP FILE HANDLING
        violations = []
        fd, tmp_path = tempfile.mkstemp(suffix='.py', text=True)
        try:
            # Write content with explicit UTF-8 encoding
            with os.fdopen(fd, 'w', encoding='utf-8') as tmp:
                tmp.write(file_content)
            # File is CLOSED before validation (critical for Windows)
            violations = list(pydocstyle.check([tmp_path]))
        except Exception as e:
            print(f"Warning: Validation error: {e}", file=sys.stderr)
        finally:
            # Always clean up temp file - suppress errors if already gone
            try:
                os.unlink(tmp_path)
            except (OSError, FileNotFoundError):
                pass

        violation_count = len(violations)

        # Calculate compliance percentage based on documented items with violations
        # Only count violations in documented items (items with docstrings)
        items_with_violations = set()
        for violation in violations:
            # Track which line has violations
            items_with_violations.add(violation.line)

        # Calculate compliance: (documented_items - items_with_violations) / documented_items
        # If no documented items, compliance is 100% (nothing to validate)
        if documented_items == 0:
            compliance_percentage = 100.0
        elif violation_count == 0:
            compliance_percentage = 100.0
        else:
            # Estimate items with violations (each violation roughly corresponds to one item)
            # This is approximate but works for most cases
            affected_items = min(len(items_with_violations), documented_items)
            compliant_items = documented_items - affected_items
            compliance_percentage = round((compliant_items / documented_items) * 100, 1)
            # Ensure non-negative
            compliance_percentage = max(0.0, compliance_percentage)

        return {
            'total_functions': total_functions,
            'total_classes': total_classes,
            'documented_items': documented_items,
            'undocumented_items': undocumented_items,
            'documented_functions': documented_functions,
            'undocumented_functions': undocumented_functions,
            'documented_classes': documented_classes,
            'undocumented_classes': undocumented_classes,
            'total_items': total_items,
            'coverage_percentage': coverage_percentage,
            'compliance_percentage': compliance_percentage,
            'violation_count': violation_count,
            'violations': violations
        }


class CodeInstrumentor:
    """
    Class for instrumenting code with generated docstrings.

    This class provides methods to add docstrings to functions and classes
    in Python source code, supporting both single files and entire
    directories.
    """

    @staticmethod
    def add_docstrings(file_content: str, style: str = 'google') -> str:
        """
        Add docstrings to all functions and classes in the code.

        This method parses the code, generates appropriate docstrings
        for undocumented functions and classes, and returns the
        instrumented code.

        Args:
            file_content (str): The Python source code to instrument.
            style (str): The docstring style to use. Defaults to 'google'.

        Returns:
            str: The instrumented code with added docstrings.
        """
        tree = ast.parse(file_content)
        generator = DocstringGenerator(style)

        # Check if module already has a docstring
        has_module_docstring = False
        for node in ast.walk(tree):
            if isinstance(node, ast.Module):
                if node.body and isinstance(node.body[0], ast.Expr):
                    first_stmt = node.body[0]
                    if isinstance(first_stmt.value, ast.Constant):
                        docstring = first_stmt.value.value
                        if isinstance(docstring, str) and docstring.strip():
                            has_module_docstring = True
                break

        # Add module docstring if missing (just at the beginning of file)
        lines = file_content.split('\n')
        first_meaningful_line = 0
        for i, line in enumerate(lines):
            if line.strip() and not line.strip().startswith('#'):
                first_meaningful_line = i
                break

        # Build a map of positions where we need to insert docstrings
        # Key: line_number (1-based index *after* which to insert)
        # Value: (docstring_text, is_class, body_indent)
        docstring_insertions = {}

        # Track offset from module docstring insertion
        module_docstring_offset = 0

        # Add module docstring if needed
        if not has_module_docstring:
            module_doc = '"""Module for processing Python files."""\n'
            if first_meaningful_line > 0:
                lines.insert(first_meaningful_line, module_doc)
            else:
                lines.insert(0, module_doc)
            module_docstring_offset = 1  # Added one line

        # Parse fresh to get original positions BEFORE any insertions
        tree = ast.parse(file_content)

        # Process all TOP-LEVEL functions and classes only
        # We must use tree.body to get ONLY top-level definitions
        def get_top_level_defs(tree):
            """Get top-level function and class definitions only"""
            result = []
            for node in tree.body:
                if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)):
                    result.append(node)
                # Also check for methods within classes
                if isinstance(node, ast.ClassDef):
                    for item in node.body:
                        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            result.append(item)
            return result

        top_level_nodes = get_top_level_defs(tree)

        # Calculate all insertions based on ORIGINAL line numbers
        for node in top_level_nodes:
            # Skip if already has a substantial docstring
            existing_doc = ast.get_docstring(node)
            if existing_doc and len(existing_doc.strip()) > 20:
                continue

            # Generate new docstring
            docstring = generator.generate_docstring(node)
            if docstring:
                # Get the ORIGINAL line number of the definition (1-based)
                def_line_num = node.lineno

                # Get the indentation of the function/class definition
                def_line = file_content.split('\n')[def_line_num - 1]
                base_indent = len(def_line) - len(def_line.lstrip())

                # For functions/classes, body indent = base_indent + 4
                body_indent = base_indent + 4

                # Split docstring and add proper indentation to each line
                doc_lines = docstring.split('\n')
                indented_lines = []
                for doc_line in doc_lines:
                    if doc_line.strip():  # Only indent non-empty lines
                        indented_lines.append(' ' * body_indent + doc_line)
                    else:
                        # Keep empty lines but with proper indent
                        indented_lines.append(' ' * body_indent)

                indented_docstring = '\n'.join(indented_lines)

                # INSERTION POSITION: Right AFTER the definition line (def/class line)
                is_class = isinstance(node, ast.ClassDef)
                docstring_insertions[def_line_num + 1] = (indented_docstring, is_class, body_indent)

        # Apply insertions in reverse order to preserve line numbers
        sorted_lines = sorted(docstring_insertions.keys(), reverse=True)
        for line_num in sorted_lines:
            docstring, is_class, body_indent = docstring_insertions[line_num]

            # Ensure there are no blank lines between the definition and the docstring
            # (fixes D201/D211: no blank lines allowed before function/class docstring).
            while line_num - 1 > 0 and not lines[line_num - 1].strip():
                lines.pop(line_num - 1)
                line_num -= 1

            # Insert docstring right after the (possibly adjusted) definition line
            lines.insert(line_num, docstring)

            next_index = line_num + 1

            if is_class:
                # For classes, ensure exactly one blank line after the docstring
                # before the first real statement (D204).
                if next_index >= len(lines) or lines[next_index].strip():
                    # Insert a properly indented blank line
                    lines.insert(next_index, ' ' * body_indent)
            else:
                # For functions, ensure there is NO blank line after the docstring
                # before the first real statement (D202).
                if next_index < len(lines) and not lines[next_index].strip():
                    lines.pop(next_index)

        return '\n'.join(lines)

    @staticmethod
    def process_directory(directory_path: str, style: str = 'google') -> Dict:
        """
        Process all Python files in a directory.

        This method recursively processes all Python files in a directory
        and its subdirectories, adding docstrings and generating reports.

        Args:
            directory_path (str): Path to the directory to process.
            style (str): The docstring style to use. Defaults to 'google'.

        Returns:
            Dict: A dictionary containing results for each file and
                 summary statistics.
        """
        results = {}
        total_functions = 0
        total_classes = 0
        total_documented = 0
        total_undocumented = 0
        total_items = 0
        total_violations = 0

        original_summary = {
            'total_functions': 0,
            'total_classes': 0,
            'documented_items': 0,
            'undocumented_items': 0,
            'total_items': 0,
            'coverage_percentage': 0,
            'compliance_percentage': 0,
            'violation_count': 0
        }

        for root, _, files in os.walk(directory_path):
            for file in files:
                if file.endswith('.py'):
                    file_path = os.path.join(root, file)
                    # FIXED: Added encoding='utf-8' when reading files
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()

                    # Analyze original code first
                    original_quality = DocstringValidator.analyze_code_quality(content)

                    # Add docstrings
                    instrumented_code = CodeInstrumentor.add_docstrings(content, style)

                    # Analyze instrumented code - WINDOWS-SAFE TEMP FILE HANDLING
                    fd, tmp_path = tempfile.mkstemp(suffix='.py', text=True)
                    try:
                        with os.fdopen(fd, 'w', encoding='utf-8') as tmp:
                            tmp.write(instrumented_code)
                        instrumented_quality = DocstringValidator.analyze_code_quality(instrumented_code)
                        validation_results = DocstringValidator.validate_file(tmp_path)
                    finally:
                        try:
                            os.unlink(tmp_path)
                        except (OSError, FileNotFoundError):
                            pass

                    # Update totals for original code
                    original_summary['total_functions'] += original_quality['total_functions']
                    original_summary['total_classes'] += original_quality['total_classes']
                    original_summary['documented_items'] += original_quality['documented_items']
                    original_summary['undocumented_items'] += original_quality['undocumented_items']
                    original_summary['total_items'] += original_quality['total_items']
                    original_summary['violation_count'] += original_quality['violation_count']

                    # Update totals for instrumented code
                    total_functions += instrumented_quality['total_functions']
                    total_classes += instrumented_quality['total_classes']
                    total_documented += instrumented_quality['documented_items']
                    total_undocumented += instrumented_quality['undocumented_items']
                    total_items += instrumented_quality['total_items']
                    total_violations += instrumented_quality['violation_count']

                    # Collect results
                    results[file_path] = {
                        'original_code': content,
                        'instrumented_code': instrumented_code,
                        'original_quality': original_quality,
                        'instrumented_quality': instrumented_quality,
                        'validation': validation_results,
                        'original_violations': original_quality['violations']
                    }

        # Calculate overall metrics for original code
        if original_summary['total_items'] > 0:
            original_summary['coverage_percentage'] = round(
                original_summary['documented_items'] / original_summary['total_items'] * 100, 1
            )
            original_summary['compliance_percentage'] = round(
                (original_summary['total_items'] - original_summary['violation_count']) /
                original_summary['total_items'] * 100, 1
            )

        # Calculate overall metrics for instrumented code
        overall_coverage = round(total_documented / total_items * 100, 1) if total_items > 0 else 0
        overall_compliance = round((total_items - total_violations) / total_items * 100, 1) if total_items > 0 else 0

        return {
            'file_results': results,
            'original_summary': original_summary,
            'instrumented_summary': {
                'total_functions': total_functions,
                'total_classes': total_classes,
                'documented_items': total_documented,
                'undocumented_items': total_undocumented,
                'total_items': total_items,
                'coverage_percentage': overall_coverage,
                'compliance_percentage': overall_compliance,
                'violation_count': total_violations
            }
        }


# Utility functions

def get_file_content(file_path: str) -> str:
    """
    Read the contents of a file.

    Args:
        file_path (str): Path to the file to read.

    Returns:
        str: The contents of the file.

    Raises:
        IOError: If the file cannot be read.
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()


def save_file(file_path: str, content: str) -> None:
    """
    Write content to a file.

    Args:
        file_path (str): Path to the file to write.
        content (str): The content to write.

    Raises:
        IOError: If the file cannot be written.
    """
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)


def generate_before_coverage_report(quality_report: Dict) -> str:
    """
    Generate a formatted coverage report for original code.

    Args:
        quality_report (Dict): The quality analysis report.

    Returns:
        str: A formatted coverage report string.
    """
    report = f"""
Documentation Coverage Report (Before Instrumentation)
=====================================================

Functions: {quality_report['total_functions']}
  Documented: {quality_report['documented_functions']}
  Undocumented: {quality_report['total_functions'] - quality_report['documented_functions']}
  Undocumented functions: {', '.join(quality_report['undocumented_functions']) if quality_report['undocumented_functions'] else 'None'}

Classes: {quality_report['total_classes']}
  Documented: {quality_report['documented_classes']}
  Undocumented: {quality_report['total_classes'] - quality_report['documented_classes']}
  Undocumented classes: {', '.join(quality_report['undocumented_classes']) if quality_report['undocumented_classes'] else 'None'}

Coverage %: {quality_report['coverage_percentage']}
PEP-257 Compliance %: {quality_report['compliance_percentage']}
PEP-257 Violations: {quality_report['violation_count']}
"""
    return report


def generate_after_coverage_report(quality_report: Dict) -> str:
    """
    Generate a formatted coverage report for instrumented code.

    Args:
        quality_report (Dict): The quality analysis report.

    Returns:
        str: A formatted coverage report string.
    """
    report = f"""
Documentation Coverage Report (After Instrumentation)
====================================================

Functions: {quality_report['total_functions']}
  Documented: {quality_report['documented_items'] - (quality_report['total_classes'] - quality_report['documented_classes'])}
  Undocumented: {quality_report['undocumented_items'] - (quality_report['total_classes'] - quality_report['documented_classes'])}

Classes: {quality_report['total_classes']}
  Documented: {quality_report['documented_classes']}
  Undocumented: {quality_report['total_classes'] - quality_report['documented_classes']}

Coverage %: {quality_report['coverage_percentage']}
PEP-257 Compliance %: {quality_report['compliance_percentage']}
PEP-257 Violations: {quality_report['violation_count']}
"""
    return report


def generate_compliance_report(violations: List, title: str = "PEP-257 Compliance Report") -> str:
    """
    Generate a formatted PEP-257 compliance report.

    Args:
        violations (List): List of compliance violations.
        title (str): The report title. Defaults to "PEP-257 Compliance Report".

    Returns:
        str: A formatted compliance report string.
    """
    if not violations:
        return f"{title}\n{'='*len(title)}\n\nNo compliance issues found!\n"

    report = f"{title}\n{'='*len(title)}\n\n"
    report += f"Found {len(violations)} compliance issues:\n\n"

    for i, issue in enumerate(violations, 1):
        report += f"Issue #{i}:\n"
        report += f"  Line: {issue['line']}\n"
        report += f"  Code: {issue['code']}\n"
        report += f"  Message: {issue['message']}\n"
        if 'source' in issue:
            report += f"  Source: {issue['source']}\n"
        report += "\n"

    return report
