# document-iq-core

Shared contracts, schemas, and utilities for the DocumentIQ platform.
