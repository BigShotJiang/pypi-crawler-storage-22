PROJECT_NAME = "DocumentIQ"
