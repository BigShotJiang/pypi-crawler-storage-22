FEATURE_VERSION = "v1"

EXPECTED_FEATURES = [
    "num_tokens",
    "num_lines",
    "avg_line_length",
    "contains_table"
]
