from document_iq_core.utils.expection import DocumentIQException
from document_iq_core.utils.logger import get_logger

__all__ = [DocumentIQException, get_logger]