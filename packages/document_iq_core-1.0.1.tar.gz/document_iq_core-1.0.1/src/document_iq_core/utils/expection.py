class DocumentIQException(Exception):
    """Base exception for DocumentIQ"""
