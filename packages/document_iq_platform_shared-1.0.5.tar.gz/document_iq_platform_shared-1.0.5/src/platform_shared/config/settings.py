from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):

    # Kafka
    kafka_bootstrap_servers: str

    # Redis
    redis_host: str
    redis_port: int

    # MLflow
    mlflow_tracking_uri: Optional[str] = None
    mlflow_tracking_username: Optional[str] = None
    mlflow_tracking_password: Optional[str] = None

    # Azure OCR
    azure_ocr_endpoint: Optional[str] = None
    azure_ocr_key: Optional[str] = None
    
    # ENV
    env: str = "dev"  # default

    class Config:
        env_prefix = "DOCUMENT_IQ_"
        env_file = ".env"
        extra = "ignore"
