"""
API client handler for Document Management System.

You can find:
- The client handler class under client folder.
- The pydantic models for request/response validation under types folder.

Quickstart:

```python

from document_manager.client import DocumentManagerClient

client = DocumentManagerClient(
    base_url="API_BASE_URL",
    api_key="USER_API_KEY",
)

print(f"Client initialized: {client.health_check()}")
```
"""
