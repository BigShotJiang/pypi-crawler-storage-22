"""API Client Handler for Document Management System."""

from .errors import (
    DocumentManagerClientError,
    APIAuthenticationError,
    APIValidationError,
    APIConnectionError,
)
from .document_manager import DocumentManagerClient
