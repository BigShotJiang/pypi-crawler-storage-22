"""Document Manager API Client Errors"""


class DocumentManagerClientError(Exception):
    """Base exception for API client errors."""

    pass


class APIAuthenticationError(DocumentManagerClientError):
    """Raised when authentication fails."""

    pass


class APIValidationError(DocumentManagerClientError):
    """Raised when request/response validation fails."""

    pass


class APIConnectionError(DocumentManagerClientError):
    """Raised when connection to API fails."""

    pass
