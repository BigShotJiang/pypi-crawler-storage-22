"""Models for search-related API operations."""

from typing import List, Optional

from pydantic import BaseModel, Field


class ArticleSearchRequest(BaseModel):
    """Request model for article search."""

    query: str
    topk: int = Field(default=5, ge=1, le=100)
    min_year: Optional[int] = None
    max_year: Optional[int] = None


class ArticleMetadata(BaseModel):
    """Article metadata model."""

    article_id: str
    file_name: str
    authors: str
    publisher: str
    pub_year: int
    doi: str
    paper_title: str
    abstract: str


class ArticleSearchResult(BaseModel):
    """Article search result model."""

    results: List[ArticleMetadata]
    count: int


class ChunkSearchRequest(BaseModel):
    """Request model for chunk search."""

    query: str
    topk: int = Field(default=5, ge=1, le=100)
    min_year: Optional[int] = None
    max_year: Optional[int] = None
    article_ids: Optional[List[str]] = None


class ChunkMetadata(BaseModel):
    """Chunk search result model."""

    chunk_id: str
    article_id: str
    file_name: str
    pub_year: int
    doi: str
    paper_title: str
    chunk_index: int
    section_index: int
    section_title: str
    content: str


class ChunkSearchResult(BaseModel):
    """Chunk search result model."""

    results: List[ChunkMetadata]
    count: int


class SummarizeRequest(BaseModel):
    """Request model for article summarization."""

    query: str
    article_ids: List[str]
    map_instructions: Optional[str] = None
    reduce_instructions: Optional[str] = None


class ArticleSummary(BaseModel):
    """Article summary model."""

    success: bool
    article_id: str
    title: str
    summary: str


class SummarizeResponse(BaseModel):
    """Response model for article summarization."""

    results: List[ArticleSummary]
    count: int
