"""Models for user-related API operations."""

from typing import List
from pydantic import BaseModel


class UserRequest(BaseModel):
    """Request model for user operations (create, delete, regenerate key)."""

    user_name: str


class UserResponse(BaseModel):
    """Response model for user creation and key regeneration."""

    success: bool
    user_name: str
    api_key: str
    message: str


class DeleteUserResponse(BaseModel):
    """Response model for user deletion."""

    success: bool
    user_name: str
    articles_deleted: int
    chunks_deleted: int


class UserMetadata(BaseModel):
    """User metadata model."""

    user_name: str
    created_at: str
    article_count: int
    chunk_count: int


class ListUsersResponse(BaseModel):
    """Response model for listing users."""

    users: List[UserMetadata]
    count: int
