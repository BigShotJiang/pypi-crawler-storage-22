# Document Manager

A Python library for interacting with the Document Management API. Provides a client for managing users, articles, and performing full-text search operations.

## Installation

```bash
pip install document-manager
```

## Quick Start

```python
from document_manager.client import DocumentManagerClient

client = DocumentManagerClient(
    base_url="https://api.example.com",
    api_key="your-api-key"
)

# Check API health
print(client.health_check())
```

## Features

- **User Management**: Create, list, and delete users
- **Article Management**: Ingest, update, and delete articles
- **Search**: Full-text search on articles and chunks
- **Summarization**: Generate summaries from articles
- **Type Safety**: Pydantic models for request/response validation

## Documentation

See the [client module](src/document_manager/client/) for available methods and [types module](src/document_manager/types/) for data models.

## Requirements

- Python >= 3.12
