"""API Client Handler for Document Management System."""

from .document_manager import DocumentManagerClient
from .errors import (
    APIAuthenticationError,
    APIConnectionError,
    APIValidationError,
    DocumentManagerClientError,
)
