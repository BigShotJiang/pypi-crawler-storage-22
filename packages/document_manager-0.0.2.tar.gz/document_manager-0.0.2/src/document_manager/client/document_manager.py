"""
This module provides a client class to interact with the API
for managing users, articles, and performing searches.
"""

import logging
import warnings
from typing import List, Optional
from urllib.parse import urljoin

import requests

# Hide XML parsing warnings from requests
from bs4 import XMLParsedAsHTMLWarning
from pydantic import ValidationError

from ..types import (
    ArticleResponse,
    ArticleSearchRequest,
    ArticleSearchResult,
    ChunkSearchRequest,
    ChunkSearchResult,
    DeleteArticleRequest,
    DeleteArticleResponse,
    DeleteUserResponse,
    IngestRequest,
    ListArticlesResponse,
    ListUsersResponse,
    SummarizeRequest,
    SummarizeResponse,
    UpdateDoiRequest,
    UserRequest,
    UserResponse,
)
from .errors import (
    APIAuthenticationError,
    APIConnectionError,
    APIValidationError,
    DocumentManagerClientError,
)

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

# Configure module logger
logger = logging.getLogger(__name__)


class DocumentManagerClient:
    """
    Client for interacting with the Document Management API.

    This client provides methods to interact with all API endpoints including
    user management, article operations, and search functionality.

    Attributes:
        base_url: Base URL of the API (e.g., 'https://myapp.azurewebsites.net/api')
        api_key: User API key for authentication (for regular endpoints)
        function_key: Function key for admin endpoints
        timeout: Request timeout in seconds
        session: Requests session for connection pooling

    Example:
        >>> client = DocumentManagerClient(
        ...     base_url='https://myapp.azurewebsites.net/api',
        ...     api_key='user-api-key-123'
        ... )
        >>> articles = client.list_articles()
        >>> print(f"Found {articles.count} articles")
    """

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        function_key: Optional[str] = None,
        timeout: int = 120,
    ):
        """Initialize the API client.

        Args:
            base_url: Base URL of the API (without trailing slash)
            api_key: User API key for authenticated endpoints
            function_key: Function key for admin endpoints
            timeout: Request timeout in seconds (default: 120)
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.function_key = function_key
        self.timeout = timeout
        self.session = requests.Session()

        logger.info(f"Initialized API client for {self.base_url}")

    def _get_url(self, endpoint: str) -> str:
        """Construct full URL for an endpoint.

        Args:
            endpoint: Endpoint path (e.g., 'articles/list')

        Returns:
            Full URL for the endpoint
        """
        return urljoin(self.base_url + "/", endpoint)

    def _get_headers(self, is_admin: bool = False) -> dict:
        """Get request headers including authentication.

        Args:
            is_admin: Whether this is an admin endpoint requiring function key

        Returns:
            Dictionary of HTTP headers

        Raises:
            APIAuthenticationError: If required authentication key is missing
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        if is_admin:
            if not self.function_key:
                raise APIAuthenticationError(
                    "Function key required for admin endpoints but not provided"
                )
            headers["x-functions-key"] = self.function_key
        else:
            if self.api_key:
                headers["x-api-key"] = self.api_key

        return headers

    def _handle_response(self, response: requests.Response, expected_model=None):
        """Handle API response and parse into model.

        Args:
            response: HTTP response object
            expected_model: Pydantic model to parse response into (optional)

        Returns:
            Parsed model instance if expected_model provided, else response text

        Raises:
            APIAuthenticationError: If authentication fails (401, 403)
            APIValidationError: If response validation fails
            DocumentManagerClientError: For other API errors
        """
        # Handle authentication errors
        if response.status_code in (401, 403):
            try:
                error_data = response.json()
                error_msg = error_data.get("error", "Authentication failed")
            except Exception:
                error_msg = "Authentication failed"
            logger.error(f"Authentication error: {error_msg}")
            raise APIAuthenticationError(error_msg)

        # Handle other error status codes
        if not response.ok:
            try:
                error_data = response.json()
                error_msg = error_data.get(
                    "error", f"API error: {response.status_code}"
                )
            except Exception:
                error_msg = f"API error: {response.status_code} - {response.text}"

            logger.error(f"API error (status {response.status_code}): {error_msg}")
            raise DocumentManagerClientError(error_msg)

        # Parse response if model is provided
        if expected_model:
            try:
                response_data = response.json()
                return expected_model(**response_data)
            except ValidationError as e:
                logger.error(f"Response validation error: {e}")
                raise APIValidationError(f"Invalid response format: {e}")
            except Exception as e:
                logger.error(f"Failed to parse response: {e}")
                raise DocumentManagerClientError(f"Failed to parse response: {e}")

        return response.text

    def _request(
        self,
        method: str,
        endpoint: str,
        data=None,
        is_admin: bool = False,
        expected_model=None,
    ):
        """Make HTTP request to API.

        Args:
            method: HTTP method (GET, POST, PATCH, DELETE)
            endpoint: API endpoint path
            data: Request body data (will be serialized to JSON)
            is_admin: Whether this is an admin endpoint
            expected_model: Pydantic model for response parsing

        Returns:
            Parsed response model or text

        Raises:
            APIConnectionError: If connection fails
            APIAuthenticationError: If authentication fails
            APIValidationError: If validation fails
            DocumentManagerClientError: For other errors
        """
        url = self._get_url(endpoint)
        headers = self._get_headers(is_admin=is_admin)

        # Serialize request body if it's a Pydantic model
        json_data = None
        if data:
            if hasattr(data, "model_dump"):
                json_data = data.model_dump()
            else:
                json_data = data

        logger.debug(f"{method} {url}")

        try:
            response = self.session.request(
                method=method,
                url=url,
                headers=headers,
                json=json_data,
                timeout=self.timeout,
            )
            return self._handle_response(response, expected_model=expected_model)

        except requests.exceptions.Timeout:
            logger.error(f"Request timeout after {self.timeout}s: {method} {url}")
            raise APIConnectionError(f"Request timeout after {self.timeout}s")

        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error: {e}")
            raise APIConnectionError(f"Failed to connect to API: {e}")

        except (APIAuthenticationError, APIValidationError, DocumentManagerClientError):
            # Re-raise our custom exceptions
            raise

        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)
            raise DocumentManagerClientError(f"Unexpected error: {e}")

    # -------------------------------------------------------------------------
    # Health Check
    # -------------------------------------------------------------------------

    def health_check(self) -> bool:
        """Check if API is healthy and responding.

        Returns:
            True if API is healthy, False otherwise
        """
        try:
            result = self._request("GET", "health")
            logger.info("Health check: OK")
            return True
        except Exception as e:
            logger.warning(f"Health check failed: {e}")
            return False

    # -------------------------------------------------------------------------
    # Article Endpoints
    # -------------------------------------------------------------------------

    def list_articles(self) -> ListArticlesResponse:
        """List all articles for the authenticated user.

        Returns:
            ListArticlesResponse with articles and count

        Raises:
            APIAuthenticationError: If authentication fails
            DocumentManagerClientError: If request fails
        """
        logger.info("Listing articles")
        return self._request(
            "GET",
            "articles/list",
            expected_model=ListArticlesResponse,
        )

    def ingest_article(
        self,
        file_name: str,
        pdf_base64: str,
    ) -> ArticleResponse:
        """Ingest a PDF article.

        Args:
            file_name: Name of the PDF file
            pdf_base64: Base64-encoded PDF content

        Returns:
            ArticleResponse with ingestion result

        Raises:
            APIAuthenticationError: If authentication fails
            APIValidationError: If request validation fails
            DocumentManagerClientError: If request fails
        """
        logger.info(f"Ingesting article: {file_name}")
        try:
            request = IngestRequest(file_name=file_name, pdf_base64=pdf_base64)
        except ValidationError as e:
            logger.error(f"Request validation error: {e}")
            raise APIValidationError(f"Invalid request data: {e}")

        return self._request(
            "POST",
            "articles/ingest",
            data=request,
            expected_model=ArticleResponse,
        )

    def update_article_doi(
        self,
        file_name: str,
        doi: str,
    ) -> ArticleResponse:
        """Update DOI for an article.

        Args:
            file_name: Name of the article file
            doi: New DOI value

        Returns:
            ArticleResponse with update result

        Raises:
            APIAuthenticationError: If authentication fails
            APIValidationError: If request validation fails
            DocumentManagerClientError: If request fails
        """
        logger.info(f"Updating DOI for article: {file_name}")
        try:
            request = UpdateDoiRequest(file_name=file_name, doi=doi)
        except ValidationError as e:
            logger.error(f"Request validation error: {e}")
            raise APIValidationError(f"Invalid request data: {e}")

        return self._request(
            "PATCH",
            "articles/update-doi",
            data=request,
            expected_model=ArticleResponse,
        )

    def delete_article(self, file_name: str) -> DeleteArticleResponse:
        """Delete an article and its chunks.

        Args:
            file_name: Name of the article file to delete

        Returns:
            DeleteArticleResponse with deletion result

        Raises:
            APIAuthenticationError: If authentication fails
            APIValidationError: If request validation fails
            DocumentManagerClientError: If request fails
        """
        logger.info(f"Deleting article: {file_name}")
        try:
            request = DeleteArticleRequest(file_name=file_name)
        except ValidationError as e:
            logger.error(f"Request validation error: {e}")
            raise APIValidationError(f"Invalid request data: {e}")

        return self._request(
            "DELETE",
            "articles/delete",
            data=request,
            expected_model=DeleteArticleResponse,
        )

    # -------------------------------------------------------------------------
    # Search Endpoints
    # -------------------------------------------------------------------------

    def search_articles(
        self,
        query: str,
        topk: int = 5,
        min_year: Optional[int] = None,
        max_year: Optional[int] = None,
    ) -> ArticleSearchResult:
        """Search for articles with metadata filtering.

        Args:
            query: Search query string
            topk: Number of results to return (1-100, default: 5)
            min_year: Minimum publication year filter (optional)
            max_year: Maximum publication year filter (optional)

        Returns:
            ArticleSearchResult with matching articles

        Raises:
            APIAuthenticationError: If authentication fails
            APIValidationError: If request validation fails
            DocumentManagerClientError: If request fails
        """
        logger.info(f"Searching articles: query='{query}', topk={topk}")
        try:
            request = ArticleSearchRequest(
                query=query,
                topk=topk,
                min_year=min_year,
                max_year=max_year,
            )
        except ValidationError as e:
            logger.error(f"Request validation error: {e}")
            raise APIValidationError(f"Invalid request data: {e}")

        return self._request(
            "POST",
            "search/article",
            data=request,
            expected_model=ArticleSearchResult,
        )

    def search_chunks(
        self,
        query: str,
        topk: int = 5,
        min_year: Optional[int] = None,
        max_year: Optional[int] = None,
        article_ids: Optional[List[str]] = None,
    ) -> ChunkSearchResult:
        """Search for chunks with metadata filtering.

        Args:
            query: Search query string
            topk: Number of results to return (1-100, default: 5)
            min_year: Minimum publication year filter (optional)
            max_year: Maximum publication year filter (optional)
            article_ids: List of article IDs to search within (optional)

        Returns:
            ChunkSearchResult with matching chunks

        Raises:
            APIAuthenticationError: If authentication fails
            APIValidationError: If request validation fails
            DocumentManagerClientError: If request fails
        """
        logger.info(f"Searching chunks: query='{query}', topk={topk}")
        try:
            request = ChunkSearchRequest(
                query=query,
                topk=topk,
                min_year=min_year,
                max_year=max_year,
                article_ids=article_ids,
            )
        except ValidationError as e:
            logger.error(f"Request validation error: {e}")
            raise APIValidationError(f"Invalid request data: {e}")

        return self._request(
            "POST",
            "search/chunk",
            data=request,
            expected_model=ChunkSearchResult,
        )

    def summarize_articles(
        self,
        query: str,
        article_ids: List[str],
        map_instructions: Optional[str] = None,
        reduce_instructions: Optional[str] = None,
    ) -> SummarizeResponse:
        """Summarize articles using LLM.

        Args:
            query: Query/context for summarization
            article_ids: List of article IDs to summarize
            map_instructions: Custom map phase instructions (optional)
            reduce_instructions: Custom reduce phase instructions (optional)

        Returns:
            SummarizeResponse with article summaries

        Raises:
            APIAuthenticationError: If authentication fails
            APIValidationError: If request validation fails
            DocumentManagerClientError: If request fails
        """
        logger.info(f"Summarizing {len(article_ids)} articles with query: '{query}'")
        try:
            request = SummarizeRequest(
                query=query,
                article_ids=article_ids,
                map_instructions=map_instructions,
                reduce_instructions=reduce_instructions,
            )
        except ValidationError as e:
            logger.error(f"Request validation error: {e}")
            raise APIValidationError(f"Invalid request data: {e}")

        return self._request(
            "POST",
            "search/summarize",
            data=request,
            expected_model=SummarizeResponse,
        )

    # -------------------------------------------------------------------------
    # User Management Endpoints (Admin)
    # -------------------------------------------------------------------------

    def list_users(self) -> ListUsersResponse:
        """List all users with their metadata (ADMIN only).

        Returns:
            ListUsersResponse with users and count

        Raises:
            APIAuthenticationError: If authentication fails or function key missing
            DocumentManagerClientError: If request fails
        """
        logger.info("Listing users (admin)")
        return self._request(
            "GET",
            "users/list",
            is_admin=True,
            expected_model=ListUsersResponse,
        )

    def create_user(self, user_name: str) -> UserResponse:
        """Create a new user and generate API key (ADMIN only).

        Args:
            user_name: Username for the new user

        Returns:
            UserResponse with user details and API key

        Raises:
            APIAuthenticationError: If authentication fails or function key missing
            APIValidationError: If request validation fails
            DocumentManagerClientError: If request fails (e.g., user already exists)
        """
        logger.info(f"Creating user: {user_name} (admin)")
        try:
            request = UserRequest(user_name=user_name)
        except ValidationError as e:
            logger.error(f"Request validation error: {e}")
            raise APIValidationError(f"Invalid request data: {e}")

        return self._request(
            "POST",
            "users/create",
            data=request,
            is_admin=True,
            expected_model=UserResponse,
        )

    def delete_user(self, user_name: str) -> DeleteUserResponse:
        """Delete a user and all their data (ADMIN only).

        Args:
            user_name: Username to delete

        Returns:
            DeleteUserResponse with deletion statistics

        Raises:
            APIAuthenticationError: If authentication fails or function key missing
            APIValidationError: If request validation fails
            DocumentManagerClientError: If request fails
        """
        logger.info(f"Deleting user: {user_name} (admin)")
        try:
            request = UserRequest(user_name=user_name)
        except ValidationError as e:
            logger.error(f"Request validation error: {e}")
            raise APIValidationError(f"Invalid request data: {e}")

        return self._request(
            "DELETE",
            "users/delete",
            data=request,
            is_admin=True,
            expected_model=DeleteUserResponse,
        )

    def regenerate_user_key(self, user_name: str) -> UserResponse:
        """Regenerate API key for a user (ADMIN only).

        Args:
            user_name: Username to regenerate key for

        Returns:
            UserResponse with new API key

        Raises:
            APIAuthenticationError: If authentication fails or function key missing
            APIValidationError: If request validation fails
            DocumentManagerClientError: If request fails
        """
        logger.info(f"Regenerating API key for user: {user_name} (admin)")
        try:
            request = UserRequest(user_name=user_name)
        except ValidationError as e:
            logger.error(f"Request validation error: {e}")
            raise APIValidationError(f"Invalid request data: {e}")

        return self._request(
            "POST",
            "users/regenerate-key",
            data=request,
            is_admin=True,
            expected_model=UserResponse,
        )

    def close(self):
        """Close the client session and cleanup resources."""
        logger.info("Closing API client session")
        self.session.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
