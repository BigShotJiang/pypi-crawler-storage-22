"""Models for article-related API operations."""

from typing import List

from pydantic import BaseModel, Field


class ArticleListItem(BaseModel):
    """Article list item model."""

    article_id: str
    file_name: str
    authors: str
    publisher: str
    pub_year: int
    doi: str
    paper_title: str
    abstract: str


class ListArticlesResponse(BaseModel):
    """Response model for listing articles."""

    articles: List[ArticleListItem]
    count: int


class IngestRequest(BaseModel):
    """Request model for PDF ingestion."""

    file_name: str = Field(..., min_length=1, description="Name of the PDF file")
    pdf_base64: str = Field(..., min_length=1, description="Base64-encoded PDF content")


class ArticleResponse(BaseModel):
    """Response model for article operations (ingest, update DOI)."""

    success: bool
    file_name: str
    doi: str
    message: str


class UpdateDoiRequest(BaseModel):
    """Request model for updating article DOI."""

    file_name: str
    doi: str


class DeleteArticleRequest(BaseModel):
    """Request model for deleting an article."""

    file_name: str


class DeleteArticleResponse(BaseModel):
    """Response model for article deletion."""

    success: bool
    file_name: str
    chunks_deleted: int
