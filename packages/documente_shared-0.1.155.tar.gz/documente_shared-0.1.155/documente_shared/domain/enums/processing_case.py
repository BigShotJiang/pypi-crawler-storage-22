from documente_shared.domain.base_enum import BaseEnum


class ProcessingCaseType(BaseEnum):
    BCP_MICROCREDITO = 'BCP_MICROCREDITO'
    UNIVIDA_SOAT = 'UNIVIDA_SOAT'
    AGNOSTIC = 'AGNOSTIC'

    @property
    def is_bcp_microcredito(self):
        return self == ProcessingCaseType.BCP_MICROCREDITO

    @property
    def is_univida_soat(self):
        return self == ProcessingCaseType.UNIVIDA_SOAT

    @property
    def is_agnostic(self):
        return self == ProcessingCaseType.AGNOSTIC




class ProcessingDocumentType(BaseEnum):
    # Default values
    CEDULA_DE_IDENTIDAD = 'CEDULA_DE_IDENTIDAD'
    # For BCP_MICROCREDITO
    REVIEW_CHECKLIST = 'REVISION_CHECKLIST'
    SOLICITUD_DE_CREDITO = 'SOLICITUD_DE_CREDITO'
    RESOLUCION_DE_CREDITO = 'RESOLUCION_DE_CREDITO'
    NIT = 'NIT'
    FICHA_VERIFICACION = 'FICHA_VERIFICACION'
    FACTURA_ELECTRICIDAD = 'FACTURA_ELECTRICIDAD'
    CARTA_CLIENTE = 'CARTA_CLIENTE'
    CHECKLIST = 'CHECKLIST'
    CPOP = 'CPOP'
    SEGIP = 'SEGIP'
    SOLICITUD_DE_CREDITO_CRECER = 'SOLICITUD_DE_CREDITO_CRECER'
    # For UNIVIDA_SOAT
    LICENCIA_DE_CONDUCIR = "LICENCIA_DE_CONDUCIR"
    CERTIFICADO_ACCIDENTE_DE_TRANSITO = "CERTIFICADO_ACCIDENTE_DE_TRANSITO"
    CERTIFICADO_DE_DEFUNCION = "CERTIFICADO_DE_DEFUNCION"
    CERTIFICADO_MEDICO_UNICO_DEFUNCION = "CERTIFICADO_MEDICO_UNICO_DEFUNCION"
    CERTIFICADO_DE_DEFUNCION_FORENSE = "CERTIFICADO_DE_DEFUNCION_FORENSE"
    CERTIFICADO_DEFUNCION_SERECI = "CERTIFICADO_DEFUNCION_SERECI"
    INFORME_MEDICO = "INFORME_MEDICO"
    ALCOHOL_TEST = "ALCOHOL_TEST"
    DECLARACION_JURADA_DE_SALUD = "DECLARACION_JURADA_DE_SALUD"
    DOCUMENTO_COMPLETO = "DOCUMENTO_COMPLETO"
    # For AGNOSTIC
    GIRO_AL_EXTERIOR = "GIRO_AL_EXTERIOR"
    BANCO_DE_CREDITO_TRANSFERENCIA_AL_EXTERIOR = "BANCO_DE_CREDITO_TRANSFERENCIA_AL_EXTERIOR"
    TESTIMONIO_DE_CONSTITUCION_DE_SOCIEDAD = "TESTIMONIO_DE_CONSTITUCION_DE_SOCIEDAD"
    PODER_DE_REPRESENTACION_LEGAL = "PODER_DE_REPRESENTACION_LEGAL"
    CARTA_VISA = "CARTA_VISA"

    @property
    def is_review_checklist(self):
        return self == ProcessingDocumentType.REVIEW_CHECKLIST

    @property
    def is_solicitud_de_credito(self):
        return self == ProcessingDocumentType.SOLICITUD_DE_CREDITO

    @property
    def is_resolucion_de_credito(self):
        return self == ProcessingDocumentType.RESOLUCION_DE_CREDITO

    @property
    def is_cedula_de_identidad(self):
        return self == ProcessingDocumentType.CEDULA_DE_IDENTIDAD

    @property
    def is_nit(self):
        return self == ProcessingDocumentType.NIT

    @property
    def is_ficha_verificacion(self):
        return self == ProcessingDocumentType.FICHA_VERIFICACION

    @property
    def is_factura_electricidad(self):
        return self == ProcessingDocumentType.FACTURA_ELECTRICIDAD

    @property
    def is_carta_cliente(self):
        return self == ProcessingDocumentType.CARTA_CLIENTE

    @property
    def is_checklist(self):
        return self == ProcessingDocumentType.CHECKLIST

    @property
    def is_cpop(self):
        return self == ProcessingDocumentType.CPOP

    @property
    def is_segip(self):
        return self == ProcessingDocumentType.SEGIP

    @property
    def is_solicitud_de_credito_crecer(self):
        return self == ProcessingDocumentType.SOLICITUD_DE_CREDITO_CRECER

    @property
    def is_licencia_de_conducir(self):
        return self == ProcessingDocumentType.LICENCIA_DE_CONDUCIR

    @property
    def is_certificado_accidente_de_transito(self):
        return self == ProcessingDocumentType.CERTIFICADO_ACCIDENTE_DE_TRANSITO

    @property
    def is_certificado_de_defuncion(self):
        return self == ProcessingDocumentType.CERTIFICADO_DE_DEFUNCION

    @property
    def is_certificado_medico_unico_defuncion(self):
        return self == ProcessingDocumentType.CERTIFICADO_MEDICO_UNICO_DEFUNCION

    @property
    def is_certificado_de_defuncion_forense(self):
        return self == ProcessingDocumentType.CERTIFICADO_DE_DEFUNCION_FORENSE

    @property
    def is_certificado_defuncion_sereci(self):
        return self == ProcessingDocumentType.CERTIFICADO_DEFUNCION_SERECI

    @property
    def is_informe_medico(self):
        return self == ProcessingDocumentType.INFORME_MEDICO

    @property
    def is_alcohol_test(self):
        return self == ProcessingDocumentType.ALCOHOL_TEST

    @property
    def is_declaracion_jurada_de_salud(self):
        return self == ProcessingDocumentType.DECLARACION_JURADA_DE_SALUD

    @property
    def is_documento_completo(self):
        return self == ProcessingDocumentType.DOCUMENTO_COMPLETO

    @property
    def is_giro_al_exterior(self):
        return self == ProcessingDocumentType.GIRO_AL_EXTERIOR

    @property
    def is_banco_de_credito_transferencia_al_exterior(self):
        return self == ProcessingDocumentType.BANCO_DE_CREDITO_TRANSFERENCIA_AL_EXTERIOR

    @property
    def is_testimonio_de_constitucion_de_sociedad(self):
        return self == ProcessingDocumentType.TESTIMONIO_DE_CONSTITUCION_DE_SOCIEDAD

    @property
    def is_poder_de_representacion_legal(self):
        return self == ProcessingDocumentType.PODER_DE_REPRESENTACION_LEGAL

    @property
    def is_carta_visa(self):
        return self == ProcessingDocumentType.CARTA_VISA
