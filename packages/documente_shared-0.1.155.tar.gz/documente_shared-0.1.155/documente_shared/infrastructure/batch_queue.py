from dataclasses import dataclass

import boto3

from documente_shared.domain.interfaces.queue import QueueService
from loguru import logger

@dataclass
class BatchQueueService(QueueService):
    job_name: str | None = None
    job_queue_name: str | None = None
    job_definition_name: str | None = None

    def __post_init__(self):
        self._batch_client = boto3.client("batch")

    def send_message(self, payload: dict, **kwargs) -> dict | None:
        if not self._is_sender_valid():
            logger.error(f"Failed to send message. Invalid state")
            return None

        return self._batch_client.submit_job(
            jobName=self.job_name,
            jobQueue=self.job_queue_name,
            jobDefinition=self.job_definition_name,
            parameters=payload,
        )

    def delete_message(self, job_id: str):
        return self._batch_client.cancel_job(
            jobId=job_id,
            reason="cancelling job",
        )

    def fetch_messages(self, job_id: str) -> list[dict]:
        response = self._batch_client.describe_jobs(jobs=[job_id])
        job = response['jobs'][0]
        parameters: dict = job.get('parameters', {})
        return [parameters]

    def _is_sender_valid(self) -> bool:
        return all([self.job_name, self.job_queue_name, self.job_definition_name])
