from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from uuid import UUID

from documente_shared.application.time_utils import get_datetime_from_data


@dataclass
class Workspace(object):
    uuid: UUID
    name: str
    tenant_slug: str
    is_archived: bool = False
    metadata: Optional[dict] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    document_types: Optional[list] = None

    def __post_init__(self):
        self.metadata = self.metadata or {}
        self.document_types = self.document_types or []

    @property
    def to_persist_dict(self) -> dict:
        return {
            "tenant_slug": self.tenant_slug,
            "name": self.name,
            "is_archived": self.is_archived,
            "metadata": self.metadata or {},
        }

    @property
    def to_dict(self) -> dict:
        return {
            "uuid": str(self.uuid),
            "name": self.name,
            "tenant_slug": self.tenant_slug,
            "is_archived": self.is_archived,
            "metadata": self.metadata,
            "created_at": (
                self.created_at.isoformat()
                if self.created_at else None
            ),
            "updated_at": (
                self.updated_at.isoformat()
                if self.updated_at else None
            ),
            "document_types": self.document_types,
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'Workspace':
        return cls(
            uuid=data.get('uuid'),
            name=data.get('name'),
            tenant_slug=data.get('tenant_slug'),
            is_archived=data.get('is_archived', False),
            metadata=data.get('metadata', {}),
            created_at=get_datetime_from_data(input_datetime=data.get('created_at')),
            updated_at=get_datetime_from_data(input_datetime=data.get('updated_at')),
            document_types=data.get('document_types', []),
        )
