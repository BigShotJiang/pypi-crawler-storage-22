from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Optional
from uuid import UUID

from documente_shared.application.time_utils import get_datetime_from_data
from documente_shared.domain.entities.in_memory_document import InMemoryDocument
from documente_shared.domain.enums.common import ProcessingStatus
from documente_shared.domain.enums.workspace import WorkspaceSource
from documente_shared.domain.helpers.values import optional_str


@dataclass
class WorkspaceDocument(object):
    uuid: UUID
    name: str
    status: ProcessingStatus
    tenant_slug: str
    workspace_id: UUID
    digest: Optional[str] = None
    document_type_id: Optional[UUID] = None
    source: Optional[WorkspaceSource] = None
    document: Optional[InMemoryDocument] = None
    document_url: Optional[str] = None
    processing_time: Optional[Decimal] = None
    metadata: Optional[dict] = None
    extraction: Optional[dict] = None
    uploaded_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    failed_at: Optional[datetime] = None

    def __post_init__(self):
        self.metadata = self.metadata or {}
        self.extraction = self.extraction or {}

    @property
    def to_persist_dict(self) -> dict:
        return {
            "tenant_slug": self.tenant_slug,
            "workspace_id": str(self.workspace_id),
            "doctype_id": str(self.document_type_id) if self.document_type_id else None,
            "name": self.name,
            "digest": self.digest,
            "status": str(self.status),
            "source": optional_str(self.source),
            "uploaded_at": self.uploaded_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "failed_at": self.failed_at,
            "processing_time": self.processing_time,
            "metadata": self.metadata or {},
            "extraction": self.extraction or {},
        }

    @property
    def to_dict(self) -> dict:
        return {
            "uuid": str(self.uuid),
            "name": self.name,
            "digest": self.digest,
            "status": str(self.status),
            "tenant_slug": self.tenant_slug,
            "workspace_id": str(self.workspace_id),
            "document_type_id": str(self.document_type_id) if self.document_type_id else None,
            "source": optional_str(self.source),
            "document": (
                self.document.to_dict
                if self.document else None
            ),
            "document_url": self.document_url,
            "processing_time": (
                str(self.processing_time)
                if self.processing_time else None
            ),
            "metadata": self.metadata,
            "extraction": self.extraction,
            "uploaded_at": (
                self.uploaded_at.isoformat()
                if self.uploaded_at else None
            ),
            "created_at": (
                self.created_at.isoformat()
                if self.created_at else None
            ),
            "updated_at": (
                self.updated_at.isoformat()
                if self.updated_at else None
            ),
            "started_at": (
                self.started_at.isoformat()
                if self.started_at else None
            ),
            "completed_at": (
                self.completed_at.isoformat()
                if self.completed_at else None
            ),
            "failed_at": (
                self.failed_at.isoformat()
                if self.failed_at else None
            ),
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'WorkspaceDocument':
        return cls(
            uuid=data.get('uuid'),
            name=data.get('name'),
            digest=data.get('digest'),
            status=ProcessingStatus.from_value(data.get('status')),
            tenant_slug=data.get('tenant_slug'),
            workspace_id=data.get('workspace_id'),
            document_type_id=data.get('document_type_id'),
            source=(
                WorkspaceSource.from_value(data.get('source'))
                if data.get('source') else None
            ),
            document=(
                InMemoryDocument.from_dict(data.get('document'))
                if data.get('document') else None
            ),
            document_url=data.get('document_url'),
            processing_time=(
                Decimal(data.get('processing_time'))
                if data.get('processing_time') else None
            ),
            metadata=data.get('metadata', {}),
            extraction=data.get('extraction', {}),
            uploaded_at=get_datetime_from_data(input_datetime=data.get('uploaded_at')),
            created_at=get_datetime_from_data(input_datetime=data.get('created_at')),
            updated_at=get_datetime_from_data(input_datetime=data.get('updated_at')),
            started_at=get_datetime_from_data(input_datetime=data.get('started_at')),
            completed_at=get_datetime_from_data(input_datetime=data.get('completed_at')),
            failed_at=get_datetime_from_data(input_datetime=data.get('failed_at')),
        )
