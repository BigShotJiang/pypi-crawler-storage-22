from dataclasses import dataclass
from typing import List, Optional
from uuid import UUID

from documente_shared.application.query_params import QueryParams
from documente_shared.domain.enums.common import ProcessingStatus


@dataclass
class WorkspaceDocumentFilters(object):
    workspace_id: Optional[UUID] = None
    sort_order: Optional[str] = None
    search: Optional[str] = None
    digest: Optional[str] = None
    statuses: List[ProcessingStatus] = None

    def __post_init__(self):
        self.statuses = self.statuses or []
        self.sort_order = self.sort_order or "desc"

    @property
    def to_params(self) -> dict:
        params = {
            "workspace_id": str(self.workspace_id) if self.workspace_id else None,
            "sort": self.sort_order,
            "search": self.search,
            "digest": self.digest,
            "statuses": ",".join(str(s) for s in self.statuses) if self.statuses else None,
        }
        return {k: v for k, v in params.items() if v is not None}

    @classmethod
    def from_params(cls, params: QueryParams) -> "WorkspaceDocumentFilters":
        search_term = params.get_str(key="search", default=None)
        return cls(
            workspace_id=params.get_uuid(key="workspace_id", default=None),
            sort_order=params.get(key="sort", default="desc"),
            search=search_term.strip() if search_term else None,
            digest=params.get_str(key="digest", default=None),
            statuses=params.get_enum_list(
                key="statuses",
                enum_class=ProcessingStatus,
                default=None,
            ),
        )
