from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from uuid import UUID

from documente_shared.application.time_utils import get_datetime_from_data
from documente_shared.domain.entities.in_memory_document import InMemoryDocument


@dataclass
class WorkspaceDocumentPage(object):
    uuid: UUID
    tenant_slug: str
    workspace_id: UUID
    workspace_document_id: UUID
    page_number: int
    page_file: Optional[InMemoryDocument] = None
    page_file_url: Optional[str] = None
    created_at: Optional[datetime] = None
    synced_at: Optional[datetime] = None

    @property
    def to_persist_dict(self) -> dict:
        return {
            "tenant_slug": self.tenant_slug,
            "workspace_id": str(self.workspace_id),
            "workspace_document_id": str(self.workspace_document_id),
            "page_number": self.page_number,
            "synced_at": self.synced_at,
        }

    @property
    def to_dict(self) -> dict:
        return {
            "uuid": str(self.uuid),
            "tenant_slug": self.tenant_slug,
            "workspace_id": str(self.workspace_id),
            "workspace_document_id": str(self.workspace_document_id),
            "page_number": self.page_number,
            "page_file": (
                self.page_file.to_dict
                if self.page_file else None
            ),
            "page_file_url": self.page_file_url,
            "created_at": (
                self.created_at.isoformat()
                if self.created_at else None
            ),
            "synced_at": (
                self.synced_at.isoformat()
                if self.synced_at else None
            ),
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'WorkspaceDocumentPage':
        return cls(
            uuid=data.get('uuid'),
            tenant_slug=data.get('tenant_slug'),
            workspace_id=data.get('workspace_id'),
            workspace_document_id=data.get('workspace_document_id'),
            page_number=data.get('page_number'),
            page_file=(
                InMemoryDocument.from_dict(data.get('page_file'))
                if data.get('page_file') else None
            ),
            page_file_url=data.get('page_file_url'),
            created_at=get_datetime_from_data(input_datetime=data.get('created_at')),
            synced_at=get_datetime_from_data(input_datetime=data.get('synced_at')),
        )
