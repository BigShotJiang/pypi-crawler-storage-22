from dataclasses import dataclass
from typing import Optional
from uuid import UUID

from documente_shared.application.query_params import QueryParams


@dataclass
class WorkspaceDocumentPageFilters(object):
    workspace_document_id: Optional[UUID] = None
    sort_order: Optional[str] = None
    page_number: Optional[int] = None

    def __post_init__(self):
        self.sort_order = self.sort_order or "desc"

    @property
    def to_params(self) -> dict:
        params = {
            "workspace_document_id": str(self.workspace_document_id) if self.workspace_document_id else None,
            "sort": self.sort_order,
            "page_number": self.page_number,
        }
        return {k: v for k, v in params.items() if v is not None}

    @classmethod
    def from_params(cls, params: QueryParams) -> "WorkspaceDocumentPageFilters":
        return cls(
            workspace_document_id=params.get_uuid(key="workspace_document_id", default=None),
            sort_order=params.get(key="sort", default="desc"),
            page_number=params.get_int(key="page_number", default=None),
        )
