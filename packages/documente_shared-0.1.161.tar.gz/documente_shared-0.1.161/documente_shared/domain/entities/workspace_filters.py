from dataclasses import dataclass
from typing import Optional

from documente_shared.application.query_params import QueryParams


@dataclass
class WorkspaceFilters(object):
    sort_order: Optional[str] = None
    search: Optional[str] = None
    include_archived: bool = False

    def __post_init__(self):
        self.sort_order = self.sort_order or "desc"

    @property
    def to_params(self) -> dict:
        params = {
            "sort": self.sort_order,
            "search": self.search,
            "include_archived": str(self.include_archived).lower(),
        }
        return {k: v for k, v in params.items() if v is not None}

    @classmethod
    def from_params(cls, params: QueryParams) -> "WorkspaceFilters":
        search_term = params.get_str(key="search", default=None)
        return cls(
            sort_order=params.get(key="sort", default="desc"),
            search=search_term.strip() if search_term else None,
            include_archived=params.get_bool(
                key="include_archived",
                default=False,
            ),
        )
