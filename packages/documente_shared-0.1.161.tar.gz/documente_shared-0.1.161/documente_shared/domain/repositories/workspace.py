from abc import ABC, abstractmethod
from typing import Any, List, Optional
from uuid import UUID

from documente_shared.domain.entities.workspace import Workspace
from documente_shared.domain.entities.workspace_filters import WorkspaceFilters


class WorkspaceRepository(ABC):
    @abstractmethod
    def find(self, uuid: UUID) -> Optional[Workspace]:
        raise NotImplementedError

    @abstractmethod
    def filter(self, filters: WorkspaceFilters) -> List[Workspace]:
        raise NotImplementedError

    @abstractmethod
    def filter_paginated(self, filters: WorkspaceFilters, page_params: Any) -> Any:
        raise NotImplementedError

    @abstractmethod
    def persist(self, instance: Workspace) -> Workspace:
        raise NotImplementedError

    @abstractmethod
    def delete(self, uuid: UUID) -> None:
        raise NotImplementedError
