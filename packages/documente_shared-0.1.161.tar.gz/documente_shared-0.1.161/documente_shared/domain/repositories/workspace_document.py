from abc import ABC, abstractmethod
from typing import Any, List, Optional
from uuid import UUID

from documente_shared.domain.entities.workspace_document import WorkspaceDocument
from documente_shared.domain.entities.workspace_document_filters import WorkspaceDocumentFilters


class WorkspaceDocumentRepository(ABC):
    @abstractmethod
    def find(self, uuid: UUID) -> Optional[WorkspaceDocument]:
        raise NotImplementedError

    @abstractmethod
    def filter(self, filters: WorkspaceDocumentFilters) -> List[WorkspaceDocument]:
        raise NotImplementedError

    @abstractmethod
    def filter_paginated(self, filters: WorkspaceDocumentFilters, page_params: Any) -> Any:
        raise NotImplementedError

    @abstractmethod
    def persist(self, instance: WorkspaceDocument) -> WorkspaceDocument:
        raise NotImplementedError

    @abstractmethod
    def delete(self, uuid: UUID) -> None:
        raise NotImplementedError
