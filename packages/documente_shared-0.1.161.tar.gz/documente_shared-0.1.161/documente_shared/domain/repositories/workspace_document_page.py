from abc import ABC, abstractmethod
from typing import Any, List, Optional
from uuid import UUID

from documente_shared.domain.entities.workspace_document_page import WorkspaceDocumentPage
from documente_shared.domain.entities.workspace_document_page_filters import WorkspaceDocumentPageFilters


class WorkspaceDocumentPageRepository(ABC):
    @abstractmethod
    def find(self, uuid: UUID) -> Optional[WorkspaceDocumentPage]:
        raise NotImplementedError

    @abstractmethod
    def filter(self, filters: WorkspaceDocumentPageFilters) -> List[WorkspaceDocumentPage]:
        raise NotImplementedError

    @abstractmethod
    def filter_paginated(self, filters: WorkspaceDocumentPageFilters, page_params: Any) -> Any:
        raise NotImplementedError

    @abstractmethod
    def persist(self, instance: WorkspaceDocumentPage) -> WorkspaceDocumentPage:
        raise NotImplementedError

    @abstractmethod
    def delete(self, uuid: UUID) -> None:
        raise NotImplementedError
