from dataclasses import dataclass
from typing import Any, List, Optional
from uuid import UUID

from loguru import logger
from requests import Response

from documente_shared.application.payloads import camel_to_snake
from documente_shared.domain.entities.workspace import Workspace
from documente_shared.domain.entities.workspace_filters import WorkspaceFilters
from documente_shared.domain.repositories.workspace import WorkspaceRepository
from documente_shared.infrastructure.documente_client import DocumenteClientMixin


@dataclass
class HttpWorkspaceRepository(
    DocumenteClientMixin,
    WorkspaceRepository,
):
    def find(self, uuid: UUID) -> Optional[Workspace]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspaces/{uuid}/",
        )
        if response.status_code not in [200, 201]:
            return None
        return self._build_workspace(response)

    def filter(self, filters: WorkspaceFilters) -> List[Workspace]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspaces/",
            params=filters.to_params,
        )
        if response.status_code not in [200, 201]:
            return []
        raw_response = response.json()
        return [
            Workspace.from_dict(camel_to_snake(item_data))
            for item_data in raw_response.get('data', [])
        ]

    def filter_paginated(self, filters: WorkspaceFilters, page_params: Any) -> Any:
        params = {**filters.to_params}
        if isinstance(page_params, dict):
            params.update(page_params)
        response = self.session.get(
            url=f"{self.api_url}/v1/workspaces/",
            params=params,
        )
        if response.status_code not in [200, 201]:
            return {"data": [], "count": 0}
        return response.json()

    def persist(self, instance: Workspace) -> Workspace:
        logger.info(f"PERSISTING_WORKSPACE: data={instance.to_persist_dict}")
        response: Response = self.session.post(
            url=f"{self.api_url}/v1/workspaces/",
            json=instance.to_persist_dict,
        )
        if response.status_code not in [200, 201]:
            logger.info(f"PERSISTING_WORKSPACE ERROR: data={response.text}")
            return instance
        return self._build_workspace(response)

    def delete(self, uuid: UUID) -> None:
        self.session.delete(f"{self.api_url}/v1/workspaces/{uuid}/")

    @classmethod
    def _build_workspace(cls, response: Response) -> Workspace:
        response_json = response.json()
        instance_data = response_json.get('data', {})
        return Workspace.from_dict(camel_to_snake(instance_data))
