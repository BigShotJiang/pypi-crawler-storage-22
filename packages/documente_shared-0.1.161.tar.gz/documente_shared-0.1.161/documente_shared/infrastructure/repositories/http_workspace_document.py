from dataclasses import dataclass
from typing import Any, List, Optional
from uuid import UUID

from loguru import logger
from requests import Response

from documente_shared.application.payloads import camel_to_snake
from documente_shared.domain.entities.workspace_document import WorkspaceDocument
from documente_shared.domain.entities.workspace_document_filters import WorkspaceDocumentFilters
from documente_shared.domain.repositories.workspace_document import WorkspaceDocumentRepository
from documente_shared.infrastructure.documente_client import DocumenteClientMixin


@dataclass
class HttpWorkspaceDocumentRepository(
    DocumenteClientMixin,
    WorkspaceDocumentRepository,
):
    def find(self, uuid: UUID) -> Optional[WorkspaceDocument]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspace-documents/{uuid}/",
        )
        if response.status_code not in [200, 201]:
            return None
        return self._build_workspace_document(response)

    def filter(self, filters: WorkspaceDocumentFilters) -> List[WorkspaceDocument]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspaces/{filters.workspace_id}/documents/",
            params=filters.to_params,
        )
        if response.status_code not in [200, 201]:
            return []
        raw_response = response.json()
        return [
            WorkspaceDocument.from_dict(camel_to_snake(item_data))
            for item_data in raw_response.get('data', [])
        ]

    def filter_paginated(self, filters: WorkspaceDocumentFilters, page_params: Any) -> Any:
        params = {**filters.to_params}
        if isinstance(page_params, dict):
            params.update(page_params)
        response = self.session.get(
            url=f"{self.api_url}/v1/workspaces/{filters.workspace_id}/documents/",
            params=params,
        )
        if response.status_code not in [200, 201]:
            return {"data": [], "count": 0}
        return response.json()

    def persist(self, instance: WorkspaceDocument) -> WorkspaceDocument:
        logger.info(f"PERSISTING_WORKSPACE_DOCUMENT: data={instance.to_persist_dict}")
        response: Response = self.session.post(
            url=f"{self.api_url}/v1/workspaces/{instance.workspace_id}/documents/",
            json=instance.to_persist_dict,
        )
        if response.status_code not in [200, 201]:
            logger.info(f"PERSISTING_WORKSPACE_DOCUMENT ERROR: data={response.text}")
            return instance
        return self._build_workspace_document(response)

    def delete(self, uuid: UUID) -> None:
        self.session.delete(f"{self.api_url}/v1/workspace-documents/{uuid}/")

    @classmethod
    def _build_workspace_document(cls, response: Response) -> WorkspaceDocument:
        response_json = response.json()
        instance_data = response_json.get('data', {})
        return WorkspaceDocument.from_dict(camel_to_snake(instance_data))
