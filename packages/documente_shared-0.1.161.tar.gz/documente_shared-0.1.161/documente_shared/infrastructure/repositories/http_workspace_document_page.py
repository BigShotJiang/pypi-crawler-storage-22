from dataclasses import dataclass
from typing import Any, List, Optional
from uuid import UUID

from loguru import logger
from requests import Response

from documente_shared.application.payloads import camel_to_snake
from documente_shared.domain.entities.workspace_document_page import WorkspaceDocumentPage
from documente_shared.domain.entities.workspace_document_page_filters import WorkspaceDocumentPageFilters
from documente_shared.domain.repositories.workspace_document_page import WorkspaceDocumentPageRepository
from documente_shared.infrastructure.documente_client import DocumenteClientMixin


@dataclass
class HttpWorkspaceDocumentPageRepository(
    DocumenteClientMixin,
    WorkspaceDocumentPageRepository,
):
    def find(self, uuid: UUID) -> Optional[WorkspaceDocumentPage]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspace-document-pages/{uuid}/",
        )
        if response.status_code not in [200, 201]:
            return None
        return self._build_workspace_document_page(response)

    def filter(self, filters: WorkspaceDocumentPageFilters) -> List[WorkspaceDocumentPage]:
        response = self.session.get(
            url=f"{self.api_url}/v1/workspace-documents/{filters.workspace_document_id}/pages/",
            params=filters.to_params,
        )
        if response.status_code not in [200, 201]:
            return []
        raw_response = response.json()
        return [
            WorkspaceDocumentPage.from_dict(camel_to_snake(item_data))
            for item_data in raw_response.get('data', [])
        ]

    def filter_paginated(self, filters: WorkspaceDocumentPageFilters, page_params: Any) -> Any:
        params = {**filters.to_params}
        if isinstance(page_params, dict):
            params.update(page_params)
        response = self.session.get(
            url=f"{self.api_url}/v1/workspace-documents/{filters.workspace_document_id}/pages/",
            params=params,
        )
        if response.status_code not in [200, 201]:
            return {"data": [], "count": 0}
        return response.json()

    def persist(self, instance: WorkspaceDocumentPage) -> WorkspaceDocumentPage:
        logger.info(f"PERSISTING_WORKSPACE_DOCUMENT_PAGE: data={instance.to_persist_dict}")
        response: Response = self.session.post(
            url=f"{self.api_url}/v1/workspace-documents/{instance.workspace_document_id}/pages/",
            json=instance.to_persist_dict,
        )
        if response.status_code not in [200, 201]:
            logger.info(f"PERSISTING_WORKSPACE_DOCUMENT_PAGE ERROR: data={response.text}")
            return instance
        return self._build_workspace_document_page(response)

    def delete(self, uuid: UUID) -> None:
        self.session.delete(f"{self.api_url}/v1/workspace-document-pages/{uuid}/")

    @classmethod
    def _build_workspace_document_page(cls, response: Response) -> WorkspaceDocumentPage:
        response_json = response.json()
        instance_data = response_json.get('data', {})
        return WorkspaceDocumentPage.from_dict(camel_to_snake(instance_data))
