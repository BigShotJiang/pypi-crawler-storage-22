from uuid import UUID
from pydantic import Field

from documente_shared.application.query_params import QueryParams
from documente_shared.domain.helpers.dicts import filter_none_values
from documente_shared.domain.pagination.entities import ListFilters


class WorkspaceFilters(ListFilters):
    tenant_ids: list[UUID] | None = Field(default_factory=list)
    search: str | None = Field(default=None)

    @property
    def to_params(self) -> dict:
        return filter_none_values({
            **super().to_dict,
            "tenant_ids": self.tenant_ids,
            "search": self.search,
        })

    @classmethod
    def from_params(cls, params: QueryParams) -> "WorkspaceFilters":
        search_term = params.get_str(key="search", default=None)
        return cls(
            cursor=params.get("cursor", None),
            limit=params.get_int(key="limit", default=None),
            search=search_term.strip() if search_term else None,
        )
