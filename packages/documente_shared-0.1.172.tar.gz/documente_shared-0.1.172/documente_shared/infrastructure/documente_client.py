from typing import Callable, Optional

from requests import Response, Session
from dataclasses import dataclass

from documente_shared.application.payloads import camel_to_snake


@dataclass
class DocumenteClientMixin(object):
    api_url: str
    api_key: str
    tenant: Optional[str] = None
    session: Optional[Session] = None

    def __post_init__(self):
        if self.session is None:
            self.session = Session()
        self.session.headers.update(self.get_common_headers())

    def get_common_headers(self) -> dict:
        common_headers = {
            "X-Api-Key": self.api_key,
            "Content-Type": "application/json"
        }
        if self.tenant:
            common_headers.update({"X-Tenant": self.tenant})
        return common_headers

    @staticmethod
    def _is_success(response: Response) -> bool:
        return response.status_code in [200, 201]

    @staticmethod
    def _parse_instance(response: Response, builder: Callable):
        instance_data = response.json().get('data', {})
        return builder(camel_to_snake(instance_data))

    @staticmethod
    def _parse_list(response: Response, builder: Callable) -> list:
        return [
            builder(camel_to_snake(item))
            for item in response.json().get('data', [])
        ]