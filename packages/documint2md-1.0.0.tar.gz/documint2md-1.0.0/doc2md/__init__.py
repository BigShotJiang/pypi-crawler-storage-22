"""Simple document -> Markdown converter utilities."""
from importlib import metadata

try:
    __version__ = metadata.version("documint2md")
except metadata.PackageNotFoundError:
    __version__ = "0.0.0+local"
from .converter import (
    ConversionError,
    UnsupportedFormatError,
    csv_to_markdown,
    docx_to_markdown,
    image_to_markdown,
    pdf_to_markdown,
)

__all__ = [
    "ConversionError",
    "UnsupportedFormatError",
    "pdf_to_markdown",
    "docx_to_markdown",
    "csv_to_markdown",
    "image_to_markdown",
    "__version__",
]
