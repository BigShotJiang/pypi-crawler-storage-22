from __future__ import annotations

import argparse
import unittest

import doc2md.cli as cli


class UiCommandTest(unittest.TestCase):
    def _make_args(self) -> argparse.Namespace:
        return argparse.Namespace(
            format=None,
            engine="pdfminer",
            output=None,
            theme="auto",
            quiet=True,
            debug=False,
            csv_na="",
            csv_float_format=None,
        )

    def test_ui_builds_and_exits(self) -> None:
        try:
            from prompt_toolkit.input.defaults import create_pipe_input
            from prompt_toolkit.output import DummyOutput
        except Exception:
            self.skipTest("prompt_toolkit not installed")

        args = self._make_args()

        def debug(_msg: str) -> None:
            return

        with create_pipe_input() as pipe_input:
            app, state = cli._build_ui_app(
                args,
                debug,
                input=pipe_input,
                output=DummyOutput(),
            )

            def feed() -> None:
                pipe_input.send_text("\x1b")

            import threading

            thread = threading.Thread(target=feed)
            thread.start()
            app.run()
            thread.join()

        self.assertEqual(state["mode"], "ui")


if __name__ == "__main__":
    unittest.main()
