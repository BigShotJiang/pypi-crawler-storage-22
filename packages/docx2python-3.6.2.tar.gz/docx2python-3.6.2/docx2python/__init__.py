"""Import function docx2python into the docx2python namespace.

:author: Shay Hill
:created: 2023-01-09
"""

from docx2python.main import docx2python

__all__ = ["docx2python"]
