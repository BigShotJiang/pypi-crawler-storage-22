# Changelog

## [0.1.3](https://github.com/balalofernandez/docx-revisions/compare/docx-revisions-v0.1.2...docx-revisions-v0.1.3) (2026-01-31)


### Documentation

* Add ai example ([#4](https://github.com/balalofernandez/docx-revisions/issues/4)) ([521f226](https://github.com/balalofernandez/docx-revisions/commit/521f22678861efb4566e517633005746d5dc4d36))

## [0.1.2](https://github.com/balalofernandez/docx-revisions/compare/docx-revisions-v0.1.1...docx-revisions-v0.1.2) (2026-01-31)


### Features

* Library implementation ([52ed846](https://github.com/balalofernandez/docx-revisions/commit/52ed8468b6e9f54473f22e4574af9a42f5d81091))


### Bug Fixes

* Add badges ([bf69d03](https://github.com/balalofernandez/docx-revisions/commit/bf69d03ce21e28d0ba576fe361261aa8cb13295c))
* Docs in one page ([767863c](https://github.com/balalofernandez/docx-revisions/commit/767863ceb6ec9e476da57c90ae8e000385e9e0f1))
* examples in docs ([7f37ecc](https://github.com/balalofernandez/docx-revisions/commit/7f37ecc7fedea756bb291bc1b94ee11a31c05eb2))

## [0.1.1](https://github.com/balalofernandez/docx-revisions/compare/docx-revisions-v0.1.0...docx-revisions-v0.1.1) (2026-01-28)


### Bug Fixes

* Add CI ([78f2ef4](https://github.com/balalofernandez/docx-revisions/commit/78f2ef4fb2764054f249460c516dc9d18600f4b4))
* Change to mkdocs ([91c96db](https://github.com/balalofernandez/docx-revisions/commit/91c96dbcdb98ffcb6a6481f885c9434d1d227837))
