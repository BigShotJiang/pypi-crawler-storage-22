# Examples

| Example | Description |
|---|---|
| [AI Document Reviewer](ai-chat.md) | A pydantic-ai agent that reviews a Word document and writes edits back as tracked changes. |
