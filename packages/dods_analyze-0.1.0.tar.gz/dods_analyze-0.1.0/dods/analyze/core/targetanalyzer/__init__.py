# dods/analyze/core/targetanalyzer/__init__.py
from .target_analyzer import TargetAnalyzer

__all__ = ["TargetAnalyzer"]
