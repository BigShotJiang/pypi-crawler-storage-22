"""
dods-datagen — config-driven synthetic data generator for the DODS toolkit.

Quick start:
  import dods.datagen as dg
  dg.create_template()        # writes template.yaml
  df = dg.run("template")     # reads template.yaml and writes CSV as configured

Templates:
  dg.list_templates()         # e.g. ['template', 'template_long']
  dg.create_template("template_long", path="template_long.yaml")

Docs:
  dg.help()
  help(dg.create_template)
  help(dg.run)
"""

from .main import run
from .templates import list_templates, create_template

__all__ = ["run", "list_templates", "create_template", "help"]


def help() -> None:
    print(
        "dods-datagen — quick help\n"
        "\n"
        "Run from Notebook:\n"
        "  # Import the module\n"
        "  import dods.datagen as dg\n"
        "\n"
        "  # You need a template YAML file to create a dataset.\n"
        "  # You can either write it yourself, or generate one from built-in templates.\n"
        "\n"
        "  # List available built-in templates\n"
        "  dg.list_templates()                 # e.g. ['template', 'template_long']\n"
        "\n"
        "  # Create a template file\n"
        "  dg.create_template()                # creates: template.yaml\n"
        "  dg.create_template('template_long', path='template_long.yaml')\n"
        "\n"
        "  # Generate a dataset from a template\n"
        "  df = dg.run('template')             # uses: template.yaml\n"
        "  df = dg.run('path/to/template')     # uses: path/to/template.yaml\n"
        "  df = dg.run('config.yaml')          # explicit file\n"
        "\n"
        "  # Output location is defined inside the YAML:\n"
        "  #   output_path: folder\n"
        "  #   filename:   csv file name\n"
        "\n"
        "  # Show detailed docs\n"
        "  help(dg.create_template)\n"
        "  help(dg.run)\n"
    )
