# dods/datagen/__main__.py
import sys
from dods.datagen.main import run

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: datagen <config.yaml>")
        sys.exit(1)
    # -> datagen config.yaml
    path = sys.argv[1] # Works because its installed as package
    df = run(path)
    print("✅ Data generated successfully.")