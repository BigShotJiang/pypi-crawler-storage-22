# datagen/helpers/engine.py
from __future__ import annotations
from typing import Any
from .engines.physics_engine import PhysicsEngine
from .engines.synthetic_engine import SyntheticEngine

class DataScenario:
    """
    Central wrapper for all data generation scenarios.

    Chooses the correct engine (physics / synthetic)
    based on the CONFIG dictionary.

    Example
    -------
    >>> from helpers.engine import DataScenario
    >>> df = DataScenario(CONFIG).generate()
    """

    def __init__(self, config: dict[str, Any]):
        self.config = config
        self.scenario = config.get("scenario", "").lower()

        # Select appropriate engine
        if self.scenario in ("weather", "physics", "physical", "base_weather"):
            self.engine = PhysicsEngine(config)
        elif self.scenario.startswith("synthetic") or self.scenario in ("synthetic", "ml"):
            self.engine = SyntheticEngine(config)
        else:
            raise ValueError(
                f"Unknown scenario type '{self.scenario}'. "
                f"Expected 'weather' or 'synthetic_*'."
            )

    def generate(self):
        """
        Generate the dataset using the appropriate engine.
        """
        print(f"🧩 Generating scenario: {self.scenario}")
        return self.engine.generate()
