"""Parallel task spawning effects.

This module implements Spawn and Task effects for background task execution
as specified in SPEC-EFF-005-concurrency.md.

Design Decisions (from spec):
1. Store semantics: Snapshot at spawn time (isolated - child gets copy)
2. Error handling: Exception stored in Task until join (fire-and-forget friendly)
3. Cancellation: Follow asyncio conventions (cancel() is sync request, CancelledError on join)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Generic, Literal, TypeVar, runtime_checkable, Protocol, cast

import doeff_vm

from ._program_types import ProgramLike
from ._validators import ensure_dict_str_any, ensure_program_like, ensure_str
from .base import Effect, EffectBase, create_effect_with_trace

SpawnBackend = Literal["thread", "process", "ray"]

_VALID_BACKENDS: tuple[SpawnBackend, ...] = ("thread", "process", "ray")

T = TypeVar("T")
T_co = TypeVar("T_co", covariant=True)

_WAITABLE_TYPES: tuple[str, ...] = ("Task", "Promise", "ExternalPromise")
_cancelled_task_ids: set[int] = set()


@runtime_checkable
class Waitable(Protocol[T_co]):
    @property
    def _handle(self) -> Any: ...


@dataclass(frozen=True)
class Future(Generic[T]):
    _handle: Any = field(repr=False)
    _completion_queue: Any | None = field(default=None, repr=False)


@dataclass
class Promise(Generic[T]):
    _promise_handle: Any = field(repr=False)
    _completed: bool = field(default=False, repr=False)
    _value: T | None = field(default=None, repr=False)
    _error: BaseException | None = field(default=None, repr=False)

    @property
    def future(self) -> Future[T]:
        return Future(_handle=self._promise_handle)

    @property
    def is_completed(self) -> bool:
        return self._completed

    @property
    def value(self) -> T | None:
        return self._value

    @property
    def error(self) -> BaseException | None:
        return self._error


class TaskCancelledError(Exception):
    """Raised when joining a cancelled task.

    Following asyncio conventions, this is raised when:
    - cancel() was called on the task
    - The task was awaited via join()
    """


SpawnEffect = doeff_vm.SpawnEffect


@dataclass(frozen=True, eq=False)
class Task(Generic[T]):
    # eq=False: hashable by id since snapshot dicts are unhashable
    backend: SpawnBackend
    _handle: Any = field(repr=False)
    _env_snapshot: dict[Any, Any] = field(default_factory=dict, repr=False, hash=False)
    _state_snapshot: dict[str, Any] = field(default_factory=dict, repr=False, hash=False)

    def __hash__(self) -> int:
        return hash(self._handle)

    def cancel(self):
        """Request cancellation of the task.

        Cancellation is modeled at the Python task-handle layer for scheduler
        interop: subsequent Wait/Gather/Race calls on the cancelled task raise
        TaskCancelledError.
        """
        task_id = task_id_of(self)
        if task_id is not None:
            _cancelled_task_ids.add(task_id)

        from doeff.program import Program

        return Program.pure(task_id is not None)

    def is_done(self) -> Effect:
        """Check if the task has completed (success, error, or cancelled).

        This is a non-blocking check that returns immediately.

        Returns:
            Effect that yields True if the task is done, False otherwise.
        """
        return create_effect_with_trace(TaskIsDoneEffect(task=self), skip_frames=3)


@dataclass(frozen=True)
class TaskCancelEffect(EffectBase):
    """Request cancellation of a spawned Task."""

    task: Task[Any]

    def __post_init__(self) -> None:
        if not isinstance(self.task, Task):
            raise TypeError(f"task must be Task, got {type(self.task).__name__}")


@dataclass(frozen=True)
class TaskIsDoneEffect(EffectBase):
    """Check if a spawned Task has completed."""

    task: Task[Any]

    def __post_init__(self) -> None:
        if not isinstance(self.task, Task):
            raise TypeError(f"task must be Task, got {type(self.task).__name__}")


def _is_handle_dict(value: object) -> bool:
    if not isinstance(value, dict):
        return False
    kind = value.get("type")
    if kind == "Task":
        return isinstance(value.get("task_id"), int)
    if kind in {"Promise", "ExternalPromise"}:
        return isinstance(value.get("promise_id"), int)
    return False


def task_id_of(value: Any) -> int | None:
    handle: Any
    if isinstance(value, Task):
        handle = value._handle
    elif isinstance(value, Future):
        handle = value._handle
    elif _is_handle_dict(value):
        handle = value
    else:
        return None

    if isinstance(handle, dict) and handle.get("type") == "Task":
        raw = handle.get("task_id")
        if isinstance(raw, int):
            return raw
    return None


def promise_id_of(value: Any) -> int | None:
    if isinstance(value, Promise):
        handle = value._promise_handle
    elif isinstance(value, Future):
        handle = value._handle
    elif _is_handle_dict(value):
        handle = value
    else:
        return None

    if isinstance(handle, dict):
        kind = handle.get("type")
        raw = handle.get("promise_id")
        if kind in {"Promise", "ExternalPromise"} and isinstance(raw, int):
            return raw
    return None


def coerce_task_handle(value: Any, preferred_backend: SpawnBackend | None = None) -> Task[Any]:
    if isinstance(value, Task):
        return value
    if _is_handle_dict(value) and value.get("type") == "Task":
        backend: SpawnBackend = cast(
            SpawnBackend,
            preferred_backend if preferred_backend in _VALID_BACKENDS else "thread",
        )
        return Task(backend=backend, _handle=value)
    raise TypeError(f"expected Task handle, got {type(value).__name__}")


def coerce_promise_handle(value: Any) -> Promise[Any]:
    if isinstance(value, Promise):
        return value
    if _is_handle_dict(value) and value.get("type") in {"Promise", "ExternalPromise"}:
        return Promise(_promise_handle=value)
    raise TypeError(f"expected Promise handle, got {type(value).__name__}")


def is_task_cancelled(value: Any) -> bool:
    task_id = task_id_of(value)
    return task_id is not None and task_id in _cancelled_task_ids


def normalize_waitable(value: Any) -> Waitable[Any]:
    if isinstance(value, Waitable):
        return value
    if _is_handle_dict(value):
        if value.get("type") == "Task":
            return coerce_task_handle(value)
        return Future(_handle=value)
    raise TypeError(
        "waitable must be Waitable or scheduler handle dict with type/task_id|promise_id"
    )


def _spawn_program(
    effect: SpawnEffect,
    preferred_backend: SpawnBackend | None,
):
    from doeff import do

    @do
    def _program():
        raw_task = yield effect
        return coerce_task_handle(raw_task, preferred_backend)

    return _program()


def spawn(
    program: ProgramLike,
    *,
    preferred_backend: SpawnBackend | None = None,
    **options: Any,
) -> Any:
    """Spawn a program as a background task.

    Args:
        program: The program to run in the background.
        preferred_backend: Optional backend hint ("thread", "process", or "ray").
        **options: Additional backend-specific options.

    Returns:
        SpawnEffect that yields a Task handle when executed.
    """
    ensure_program_like(program, name="program")
    if preferred_backend is not None:
        ensure_str(preferred_backend, name="preferred_backend")
        if preferred_backend not in _VALID_BACKENDS:
            raise ValueError(
                "preferred_backend must be one of 'thread', 'process', or 'ray', "
                f"got {preferred_backend!r}"
            )
    ensure_dict_str_any(options, name="options")

    effect = create_effect_with_trace(
        SpawnEffect(
            program=program,
            preferred_backend=preferred_backend,
            options=options,
            store_mode="isolated",
        )
    )
    return _spawn_program(effect, preferred_backend)


def Spawn(
    program: ProgramLike,
    *,
    preferred_backend: SpawnBackend | None = None,
    **options: Any,
) -> Any:
    """Spawn a program as a background task (capitalized alias).

    Args:
        program: The program to run in the background.
        preferred_backend: Optional backend hint ("thread", "process", or "ray").
        **options: Additional backend-specific options.

    Returns:
        Effect that yields a Task handle when executed.
    """
    ensure_program_like(program, name="program")
    if preferred_backend is not None:
        ensure_str(preferred_backend, name="preferred_backend")
        if preferred_backend not in _VALID_BACKENDS:
            raise ValueError(
                "preferred_backend must be one of 'thread', 'process', or 'ray', "
                f"got {preferred_backend!r}"
            )
    ensure_dict_str_any(options, name="options")

    effect = create_effect_with_trace(
        SpawnEffect(
            program=program,
            preferred_backend=preferred_backend,
            options=options,
            store_mode="isolated",
        ),
        skip_frames=3,
    )
    return _spawn_program(effect, preferred_backend)


__all__ = [
    "Future",
    "Promise",
    "Spawn",
    "SpawnBackend",
    "SpawnEffect",
    "Task",
    "TaskCancelEffect",
    "TaskCancelledError",
    "TaskIsDoneEffect",
    "Waitable",
    "coerce_promise_handle",
    "coerce_task_handle",
    "is_task_cancelled",
    "promise_id_of",
    "spawn",
    "task_id_of",
]
