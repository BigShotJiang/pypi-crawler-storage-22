"""
Program class for the doeff system.

This module contains the Program wrapper class that represents a lazy computation.
"""

from __future__ import annotations

import inspect
import types
from abc import ABC, ABCMeta
from collections.abc import Callable, Generator, Iterable, Mapping
from dataclasses import dataclass
from typing import (
    TYPE_CHECKING,
    Annotated,
    Any,
    ForwardRef,
    Generic,
    Protocol,
    TypeVar,
    Union,
    get_args,
    get_origin,
    get_type_hints,
    runtime_checkable,
)

if TYPE_CHECKING:
    from doeff.effects._program_types import ProgramLike
    from doeff.types import Effect, Maybe

T = TypeVar("T")
U = TypeVar("U")
V = TypeVar("V")

try:
    import doeff_vm as _doeff_vm

    _RustDoExprBase = _doeff_vm.DoExpr
except Exception:  # pragma: no cover - fallback for docs/type tooling without native module
    _RustDoExprBase = object


def _annotation_text_is_program_kind(annotation_text: str) -> bool:
    if not annotation_text:
        return False
    stripped = annotation_text.strip()
    if not stripped:
        return False
    # Handle quoted strings from __future__ annotations in Python 3.14+
    if (stripped.startswith("'") and stripped.endswith("'")) or (
        stripped.startswith('"') and stripped.endswith('"')
    ):
        stripped = stripped[1:-1]
    if "|" in stripped:
        return any(_annotation_text_is_program_kind(part) for part in stripped.split("|"))
    if stripped.startswith("Optional[") and stripped.endswith("]"):
        return _annotation_text_is_program_kind(stripped[9:-1])
    if stripped.startswith("typing.Optional[") and stripped.endswith("]"):
        return _annotation_text_is_program_kind(stripped[len("typing.Optional[") : -1])
    if stripped.startswith("Annotated[") and stripped.endswith("]"):
        inner = stripped[len("Annotated[") : -1]
        first_part = inner.split(",", 1)[0]
        return _annotation_text_is_program_kind(first_part)
    normalized = stripped.replace(" ", "")
    return (
        normalized == "Program"
        or normalized.startswith("Program[")
        or normalized.startswith("doeff.program.Program")
        or normalized == "ProgramLike"
        or normalized.startswith("ProgramLike[")
        or normalized == "ProgramBase"
        or normalized.startswith("ProgramBase[")
        or normalized == "DoExpr"
        or normalized.startswith("DoExpr[")
    )


def _annotation_text_is_effect_kind(annotation_text: str) -> bool:
    if not annotation_text:
        return False
    stripped = annotation_text.strip()
    if not stripped:
        return False
    # Handle quoted strings from __future__ annotations in Python 3.14+
    if (stripped.startswith("'") and stripped.endswith("'")) or (
        stripped.startswith('"') and stripped.endswith('"')
    ):
        stripped = stripped[1:-1]
    if "|" in stripped:
        return any(_annotation_text_is_effect_kind(part) for part in stripped.split("|"))
    if stripped.startswith("Optional[") and stripped.endswith("]"):
        return _annotation_text_is_effect_kind(stripped[9:-1])
    if stripped.startswith("typing.Optional[") and stripped.endswith("]"):
        return _annotation_text_is_effect_kind(stripped[len("typing.Optional[") : -1])
    if stripped.startswith("Annotated[") and stripped.endswith("]"):
        inner = stripped[len("Annotated[") : -1]
        first_part = inner.split(",", 1)[0]
        return _annotation_text_is_effect_kind(first_part)
    normalized = stripped.replace(" ", "")
    return (
        normalized == "Effect"
        or normalized == "EffectBase"
        or normalized.startswith("Effect[")
        or normalized.startswith("doeff.types.Effect")
        or normalized.startswith("doeff.types.EffectBase")
    )


def _is_program_annotation_kind(annotation: Any) -> bool:
    if annotation is inspect._empty:
        return False

    from doeff.types import EffectBase as EffectBaseType

    program_type = globals().get("Program", ProgramBase)

    if annotation in (program_type, ProgramBase):
        return True
    # Check for subclasses of ProgramBase (excluding EffectBase subclasses)
    if isinstance(annotation, type) and issubclass(annotation, ProgramBase):
        if not issubclass(annotation, EffectBaseType):
            return True
    if isinstance(annotation, ForwardRef):
        return _annotation_text_is_program_kind(annotation.__forward_arg__)
    if isinstance(annotation, str):
        return _annotation_text_is_program_kind(annotation)
    origin = get_origin(annotation)
    if origin in (program_type, ProgramBase):
        return True
    # Check origin for subclasses (e.g., MyProgram[T])
    if isinstance(origin, type) and issubclass(origin, ProgramBase):
        if not issubclass(origin, EffectBaseType):
            return True
    if origin is Annotated:
        args = get_args(annotation)
        if args:
            return _is_program_annotation_kind(args[0])
        return False
    union_type = getattr(types, "UnionType", None)
    if origin is Union or (union_type is not None and origin is union_type):
        return any(_is_program_annotation_kind(arg) for arg in get_args(annotation))
    return False


def _is_effect_annotation_kind(annotation: Any) -> bool:
    if annotation is inspect._empty:
        return False
    from doeff.types import Effect, EffectBase  # Local import to avoid global dependency

    if annotation in (Effect, EffectBase):
        return True
    # Check for subclasses of EffectBase
    if isinstance(annotation, type) and issubclass(annotation, EffectBase):
        return True
    if isinstance(annotation, ForwardRef):
        return _annotation_text_is_effect_kind(annotation.__forward_arg__)
    if isinstance(annotation, str):
        return _annotation_text_is_effect_kind(annotation)
    origin = get_origin(annotation)
    if origin in (Effect, EffectBase):
        return True
    # Check origin for subclasses (e.g., MyEffect[T])
    if isinstance(origin, type) and issubclass(origin, EffectBase):
        return True
    if origin is Annotated:
        args = get_args(annotation)
        if args:
            return _is_effect_annotation_kind(args[0])
        return False
    union_type = getattr(types, "UnionType", None)
    if origin is Union or (union_type is not None and origin is union_type):
        return any(_is_effect_annotation_kind(arg) for arg in get_args(annotation))
    return False


def _safe_get_type_hints(target: Any) -> dict[str, Any]:
    if target is None:
        return {}
    try:
        return get_type_hints(target, include_extras=True)
    except Exception:
        annotations = getattr(target, "__annotations__", None)
        return dict(annotations) if annotations else {}


def _safe_signature(target: Any) -> inspect.Signature | None:
    try:
        return inspect.signature(target)
    except (TypeError, ValueError):
        return None


def _build_auto_unwrap_strategy(kleisli: Any) -> Any:
    class _Strategy:
        __slots__ = ("keyword", "positional", "var_keyword", "var_positional")

        def __init__(self) -> None:
            self.positional: list[bool] = []
            self.var_positional: bool | None = None
            self.keyword: dict[str, bool] = {}
            self.var_keyword: bool | None = None

        def should_unwrap_positional(self, index: int) -> bool:
            if index < len(self.positional):
                return self.positional[index]
            if self.var_positional is not None:
                return self.var_positional
            return True

        def should_unwrap_keyword(self, name: str) -> bool:
            if name in self.keyword:
                return self.keyword[name]
            if self.var_keyword is not None:
                return self.var_keyword
            return True

    strategy = _Strategy()
    signature = getattr(kleisli, "__signature__", None)
    if signature is None:
        signature = _safe_signature(getattr(kleisli, "func", None))
    metadata_source = getattr(kleisli, "_metadata_source", None)
    type_hints = _safe_get_type_hints(metadata_source)
    if not type_hints:
        type_hints = _safe_get_type_hints(getattr(kleisli, "func", None))
    if signature is None:
        return strategy
    for param in signature.parameters.values():
        annotation = type_hints.get(param.name, param.annotation)
        is_program = _is_program_annotation_kind(annotation)
        is_effect = _is_effect_annotation_kind(annotation)
        should_unwrap = not (is_program or is_effect)
        if param.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            strategy.positional.append(should_unwrap)
            if param.kind == inspect.Parameter.POSITIONAL_OR_KEYWORD:
                strategy.keyword[param.name] = should_unwrap
        elif param.kind == inspect.Parameter.KEYWORD_ONLY:
            strategy.keyword[param.name] = should_unwrap
        elif param.kind == inspect.Parameter.VAR_POSITIONAL:
            strategy.var_positional = should_unwrap
        elif param.kind == inspect.Parameter.VAR_KEYWORD:
            strategy.var_keyword = should_unwrap
    return strategy


class DoExpr(_RustDoExprBase, ABC, Generic[T]):
    """Universal base for all doeff programs (pure data or computation)."""

    def __class_getitem__(cls, item):
        return super().__class_getitem__(item)


class DoCtrl(DoExpr[T]):
    """VM control primitives."""

    pass


def _is_rust_program_subclass(subclass: type[Any]) -> bool:
    try:
        import doeff_vm
    except ImportError:
        return False

    try:
        return issubclass(subclass, (doeff_vm.DoExpr, doeff_vm.KleisliProgramCall))
    except TypeError:
        return False


class _ProgramBaseMeta(ABCMeta):
    def __subclasscheck__(cls, subclass: type[Any]) -> bool:
        program_base = globals().get("ProgramBase")
        if program_base is not None and cls is program_base and _is_rust_program_subclass(subclass):
            return True
        return super().__subclasscheck__(subclass)

    def __instancecheck__(cls, instance: Any) -> bool:
        return cls.__subclasscheck__(instance.__class__) or super().__instancecheck__(instance)


def _make_generator_program(
    factory: Callable[[], Generator[Effect | Program, Any, T]],
) -> GeneratorProgram[T]:
    return _GenProgramThunk(factory)


class ProgramBase(DoExpr[T], metaclass=_ProgramBaseMeta):
    """Runtime base class for all doeff programs (effects and Kleisli calls)."""

    def __class_getitem__(cls, item):
        """Allow ``Program[T]`` generic-style annotations."""
        return super().__class_getitem__(item)

    def __getattr__(self, name: str) -> Program[Any]:
        """Lazily project an attribute from the eventual program result."""

        if name.startswith("__"):
            raise AttributeError(name)
        if name == "to_generator":
            # Preserve generator-detection semantics: objects without a real
            # to_generator method must not fabricate one via projection.
            raise AttributeError(name)

        def mapper(value: Any) -> Any:
            try:
                return getattr(value, name)
            except AttributeError as exc:  # pragma: no cover - re-raise with context
                raise AttributeError(
                    f"{type(value).__name__} object has no attribute '{name}'"
                ) from exc

        return self.map(mapper)

    def __getitem__(self, key: Any) -> Program[Any]:
        """Lazily project an item from the eventual program result."""

        return self.map(lambda value: value[key])

    def __call__(self, *args: Any, **kwargs: Any) -> Program[Any]:
        """Invoke the eventual callable result with the provided arguments."""

        def invoke_callable(func: Any) -> Program[Any]:
            if not callable(func):
                raise TypeError(f"Program result {func!r} is not callable")
            arg_programs = [ProgramBase.lift(arg) for arg in args]
            kw_programs = {name: ProgramBase.lift(value) for name, value in kwargs.items()}

            from doeff.effects import gather

            def gather_inputs() -> Generator[
                Effect | Program, Any, tuple[list[Any], dict[str, Any]]
            ]:
                resolved_args = yield gather(*arg_programs)
                kw_keys = list(kw_programs.keys())
                kw_values = yield gather(*kw_programs.values())
                resolved_kwargs = dict(zip(kw_keys, kw_values, strict=False))
                return list(resolved_args), resolved_kwargs

            def call_program() -> Generator[Effect | Program, Any, Any]:
                from doeff.types import EffectBase

                resolved_args, resolved_kwargs = yield _make_generator_program(gather_inputs)
                result = func(*resolved_args, **resolved_kwargs)
                if isinstance(result, (ProgramBase, EffectBase)):
                    return (yield result)
                return result

            return _make_generator_program(call_program)

        return self.flat_map(invoke_callable)

    def map(self, f: Callable[[T], U]) -> Program[U]:
        """Map a function over this program's result."""

        if not callable(f):
            raise TypeError("mapper must be callable")
        from doeff_vm import Map

        return Map(self, f)

    def flat_map(self, f: Callable[[T], Program[U]]) -> Program[U]:
        """Monadic bind operation."""

        if not callable(f):
            raise TypeError("binder must be callable returning a Program")
        from doeff_vm import FlatMap

        return FlatMap(self, f)

    def and_then_k(self, binder: Callable[[T], Program[U]]) -> Program[U]:
        """Alias for flat_map for Kleisli-style composition."""

        return self.flat_map(binder)

    @staticmethod
    def pure(value: T) -> Program[T]:
        from doeff_vm import Pure

        return Pure(value=value)

    @staticmethod
    def of(value: T) -> Program[T]:
        return ProgramBase.pure(value)

    @staticmethod
    def lift(value: Program[U] | U) -> Program[U]:
        from doeff.types import EffectBase
        from doeff_vm import DoExpr

        if isinstance(value, ProgramBase):
            return value  # type: ignore[return-value]
        if isinstance(value, DoExpr):
            return value  # type: ignore[return-value]
        if isinstance(value, EffectBase):
            from doeff.rust_vm import Perform

            return Perform(value)  # type: ignore[return-value]
        return ProgramBase.pure(value)  # type: ignore[return-value]

    @staticmethod
    def first_some(*programs: ProgramLike[V]) -> Program[Maybe[V]]:
        if not programs:
            raise ValueError("Program.first_some requires at least one program")

        from doeff.types import EffectBase, Maybe

        def first_some_generator():
            for candidate in programs:
                if isinstance(candidate, (ProgramBase, EffectBase)):
                    normalized = candidate
                else:
                    raise TypeError("Program.first_some expects Program or Effect candidates")
                value = yield normalized

                maybe = value if isinstance(value, Maybe) else Maybe.from_optional(value)

                if maybe.is_some():
                    return maybe

            return Maybe.from_optional(None)

        return _make_generator_program(first_some_generator)

    @staticmethod
    def sequence(programs: list[Program[T]]) -> Program[list[T]]:
        from doeff.effects import gather

        def sequence_generator():
            effect = gather(*programs)
            results = yield effect
            return list(results)

        return _make_generator_program(sequence_generator)

    @staticmethod
    def traverse(
        items: list[T],
        func: Callable[[T], Program[U]],
    ) -> Program[list[U]]:
        programs = [func(item) for item in items]
        return ProgramBase.sequence(programs)

    @staticmethod
    def list(*values: Program[U] | U) -> Program[list[U]]:
        programs = [ProgramBase.lift(value) for value in values]
        return ProgramBase.sequence(programs)

    @staticmethod
    def tuple(*values: Program[U] | U) -> Program[tuple[U, ...]]:
        return ProgramBase.list(*values).map(lambda items: tuple(items))

    @staticmethod
    def set(*values: Program[U] | U) -> Program[set[U]]:
        return ProgramBase.list(*values).map(lambda items: set(items))

    @staticmethod
    def dict(
        *mapping: Mapping[Any, Program[V] | V] | Iterable[tuple[Any, Program[V] | V]],
        **kwargs: Program[V] | V,
    ) -> Program[dict[Any, V]]:
        raw = dict(*mapping, **kwargs)

        from doeff.effects import gather

        def dict_generator():
            program_map = {key: ProgramBase.lift(value) for key, value in raw.items()}
            keys = list(program_map.keys())
            values = yield gather(*program_map.values())
            return dict(zip(keys, values, strict=False))

        return _make_generator_program(dict_generator)


@dataclass
class _GenProgramThunk(ProgramBase[T]):
    """Program backed by a generator factory."""

    factory: Callable[[], Generator[Effect | Program, Any, T]]
    created_at: Any | None = None

    def to_generator(self) -> Generator[Effect | Program, Any, T]:
        return self.factory()


@runtime_checkable
class ProgramProtocol(Protocol[T]):
    """
    Protocol for all executable computations in doeff.

    This protocol defines the core interface that both Effects and KleisliProgramCalls
    implement, allowing them to be composed uniformly.
    """

    def map(self, f: Callable[[T], U]) -> ProgramProtocol[U]:
        """Map a function over the result of this program (functor map)."""
        ...

    def flat_map(self, f: Callable[[T], ProgramProtocol[U]]) -> ProgramProtocol[U]:
        """Monadic bind operation - chain programs sequentially."""
        ...


from doeff_vm import KleisliProgramCall as KleisliProgramCall


class _CompatDataclassField:
    __slots__ = ("name",)

    def __init__(self, name: str) -> None:
        self.name = name


def _format_kpc_args_repr(kleisli: Any, args: tuple[Any, ...], kwargs: dict[str, Any]) -> str | None:
    target = getattr(kleisli, "original_func", None) or getattr(kleisli, "func", None) or kleisli
    try:
        signature = inspect.signature(target)
    except (TypeError, ValueError):
        signature = None

    if signature is not None:
        try:
            bound = signature.bind_partial(*args, **kwargs)
            parts = [f"{name}={value!r}" for name, value in bound.arguments.items()]
            return ", ".join(parts) if parts else None
        except TypeError:
            pass

    parts: list[str] = [repr(value) for value in args]
    parts.extend(f"{key}={value!r}" for key, value in kwargs.items())
    return ", ".join(parts) if parts else None


def _kpc_create_from_kleisli(
    cls: type[Any],
    kleisli: Any,
    args: tuple,
    kwargs: dict[str, Any],
    function_name: str,
    created_at: Any = None,
) -> Any:
    return cls(
        kleisli_source=kleisli,
        args=tuple(args),
        kwargs=dict(kwargs),
        function_name=function_name,
        execution_kernel=getattr(kleisli, "func", None),
        created_at=created_at,
        args_repr=_format_kpc_args_repr(kleisli, args, kwargs),
    )


def _kpc_and_then_k(self: Any, f: Callable[[T], ProgramProtocol[U]]) -> Program[U]:
    if not callable(f):
        raise TypeError("binder must be callable returning Program/Effect")
    from doeff_vm import FlatMap

    return FlatMap(self, f)


setattr(KleisliProgramCall, "create_from_kleisli", classmethod(_kpc_create_from_kleisli))
setattr(KleisliProgramCall, "and_then_k", _kpc_and_then_k)
if not hasattr(KleisliProgramCall, "__dataclass_fields__"):
    setattr(
        KleisliProgramCall,
        "__dataclass_fields__",
        {
            "kleisli_source": _CompatDataclassField("kleisli_source"),
            "args": _CompatDataclassField("args"),
            "kwargs": _CompatDataclassField("kwargs"),
            "function_name": _CompatDataclassField("function_name"),
            "args_repr": _CompatDataclassField("args_repr"),
            "execution_kernel": _CompatDataclassField("execution_kernel"),
            "created_at": _CompatDataclassField("created_at"),
        },
    )

Program = ProgramBase
GeneratorProgram = _GenProgramThunk

__all__ = [
    "DoCtrl",
    "DoExpr",
    "GeneratorProgram",
    "KleisliProgramCall",
    "Program",
    "ProgramProtocol",
]
