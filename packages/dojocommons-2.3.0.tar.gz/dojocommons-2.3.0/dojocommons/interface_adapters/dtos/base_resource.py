from enum import Enum


class BaseResource(Enum):
    pass
