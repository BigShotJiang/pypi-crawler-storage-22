def salom():
    return "Assalomu alaykum, Doliyev kutubxonasi ishga tushdi 😎"