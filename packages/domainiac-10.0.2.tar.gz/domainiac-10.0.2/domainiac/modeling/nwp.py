from dataclasses import dataclass
from enum import Enum


class NWPParameter(Enum):
    SOLAR = "solar"
    WIND = "wind"
    TEMPERATURE = "temperature"


class NWPProvider(Enum):
    ECMWF = "ecmwf"
    CONWX = "conwx"
    DMI = "dmi"


@dataclass(frozen=True)
class Coordinate:
    latitude: float
    longitude: float
    altitude: float


@dataclass(frozen=True)
class Neighborhood:
    coordinate: Coordinate
    num_neighbors: int
