# Bazowa klasa parsera
"""
base.py
"""
