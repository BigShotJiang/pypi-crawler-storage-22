"""Base parser module for the domd package."""

from domd.core.parsing.base import BaseParser

__all__ = ["BaseParser"]
