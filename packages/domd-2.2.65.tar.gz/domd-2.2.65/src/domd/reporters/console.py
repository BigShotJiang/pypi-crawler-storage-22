# Reporter konsolowy
"""
console.py
"""
