"""
test_console.py
"""
