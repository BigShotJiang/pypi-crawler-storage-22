# Wykonywanie komend
"""
command_runner.py
"""
