# Narzędzia do plików
"""
file_utils.py
"""
