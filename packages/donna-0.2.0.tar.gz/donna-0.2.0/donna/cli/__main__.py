from donna.cli.application import app  # noqa: F401
from donna.cli.commands import artifacts  # noqa: F401
from donna.cli.commands import projects  # noqa: F401
from donna.cli.commands import sessions  # noqa: F401

app()
