"""Shared source constructor instances for default configuration."""

from donna.world.sources.markdown import MarkdownSourceConstructor

markdown = MarkdownSourceConstructor()
