"""Helpers for constructing artifacts from different source types."""
