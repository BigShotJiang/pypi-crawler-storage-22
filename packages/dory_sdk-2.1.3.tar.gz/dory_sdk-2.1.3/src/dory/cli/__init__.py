"""Dory SDK CLI tools."""

from dory.cli.main import main

__all__ = ["main"]
