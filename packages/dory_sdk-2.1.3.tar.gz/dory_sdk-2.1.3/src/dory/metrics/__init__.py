"""Prometheus metrics collection."""

from dory.metrics.collector import MetricsCollector

__all__ = [
    "MetricsCollector",
]
