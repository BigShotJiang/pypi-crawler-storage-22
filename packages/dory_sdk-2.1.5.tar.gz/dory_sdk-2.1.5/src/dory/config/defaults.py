"""Default configuration values for Dory SDK."""

from dory.types import StateBackend, LogFormat

# Default configuration dictionary
DEFAULT_CONFIG = {
    # Lifecycle timeouts
    "startup_timeout_sec": 30,
    "shutdown_timeout_sec": 30,
    "health_check_interval_sec": 10,

    # Health server
    "health_port": 8080,
    "health_path": "/healthz",
    "ready_path": "/ready",
    "metrics_path": "/metrics",

    # State management
    "state_backend": StateBackend.CONFIGMAP.value,
    "state_pvc_mount": "/data",
    "state_s3_bucket": None,
    "state_s3_prefix": "dory-state",

    # State transfer timeouts (aligned with Orchestrator's 30s default)
    "state_capture_timeout_sec": 25,  # Must be < Orchestrator's 30s timeout
    "state_restore_timeout_sec": 25,  # Must be < Orchestrator's 30s timeout
    "state_max_size_bytes": 8 * 1024 * 1024,  # 8MB (Orchestrator limit is 10MB)
    "state_size_warn_threshold": 0.75,  # Warn at 75% of max size

    # Recovery
    "max_restart_attempts": 3,
    "restart_backoff_sec": 10,
    "golden_image_threshold": 3,

    # Logging
    "log_level": "INFO",
    "log_format": LogFormat.JSON.value,

    # Metrics
    "metrics_enabled": True,
    "metrics_prefix": "dory",
}


def get_default(key: str, default=None):
    """
    Get a default configuration value.

    Args:
        key: Configuration key
        default: Value to return if key not found

    Returns:
        Default value for the key
    """
    return DEFAULT_CONFIG.get(key, default)
