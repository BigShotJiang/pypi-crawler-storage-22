"""Edge node support for Dory SDK.

Provides fencing, failover coordination, and split-brain prevention
for edge nodes with intermittent connectivity.
"""

from dory.edge.fencing import (
    FencingManager,
    FencingConfig,
    FencingToken,
    FencingError,
    FenceViolation,
    StaleEpochError,
)
from dory.edge.role import (
    ProcessorRole,
    RoleManager,
    RoleTransition,
)
from dory.edge.heartbeat import (
    HeartbeatManager,
    HeartbeatConfig,
    HeartbeatPayload,
    HeartbeatResponse,
    ConnectivityStatus,
    ConnectivityMetrics,
    EdgeHealthReporter,
)
from dory.edge.detector import (
    WorkloadDetector,
    WorkloadContext,
    NodeType,
    is_edge_node,
    is_cloud_node,
    is_migrated_workload,
    get_workload_context,
    get_node_type,
    get_recommended_env_vars,
    get_pod_spec_yaml_snippet,
)
from dory.edge.adaptive import (
    AdaptiveProcessor,
    AdaptiveConfig,
    EdgeConfig,
    OperationMode,
    create_adaptive_processor,
    get_location_aware_settings,
)

__all__ = [
    # Fencing
    "FencingManager",
    "FencingConfig",
    "FencingToken",
    "FencingError",
    "FenceViolation",
    "StaleEpochError",
    # Role management
    "ProcessorRole",
    "RoleManager",
    "RoleTransition",
    # Heartbeat and connectivity
    "HeartbeatManager",
    "HeartbeatConfig",
    "HeartbeatPayload",
    "HeartbeatResponse",
    "ConnectivityStatus",
    "ConnectivityMetrics",
    "EdgeHealthReporter",
    # Workload detection
    "WorkloadDetector",
    "WorkloadContext",
    "NodeType",
    "is_edge_node",
    "is_cloud_node",
    "is_migrated_workload",
    "get_workload_context",
    "get_node_type",
    "get_recommended_env_vars",
    "get_pod_spec_yaml_snippet",
    # Adaptive processor
    "AdaptiveProcessor",
    "AdaptiveConfig",
    "EdgeConfig",
    "OperationMode",
    "create_adaptive_processor",
    "get_location_aware_settings",
]
