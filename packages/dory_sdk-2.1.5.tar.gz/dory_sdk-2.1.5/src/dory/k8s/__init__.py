"""Kubernetes integration utilities."""

from dory.k8s.client import K8sClient
from dory.k8s.pod_metadata import PodMetadata
from dory.k8s.annotation_watcher import AnnotationWatcher
from dory.k8s.labels import (
    # Label keys
    LABEL_MANAGED_BY,
    LABEL_APP_NAME,
    LABEL_PROCESSOR_ID,
    LABEL_WORKLOAD_TYPE,
    LABEL_WORKLOAD_LOCATION,
    LABEL_NODE_TYPE,
    LABEL_MIGRATED_FROM_EDGE,
    LABEL_ORIGINAL_NODE,
    # Label values
    VALUE_ORCHESTRATOR_NAME,
    VALUE_EDGE,
    VALUE_MANAGED,
    # Enums
    WorkloadLocation,
    NodeType,
    # Builder
    DoryLabels,
    # Utilities
    get_label,
    get_app_name,
    get_processor_id,
    get_workload_location,
    is_managed_by_dory,
    is_edge_workload,
    is_migrated_from_edge,
    get_original_node,
    detect_workload_context,
    edge_node_selector,
    managed_node_selector,
    edge_toleration,
    get_contract_documentation,
    CONTRACT_VERSION,
)

__all__ = [
    # Core
    "K8sClient",
    "PodMetadata",
    "AnnotationWatcher",
    # Label keys
    "LABEL_MANAGED_BY",
    "LABEL_APP_NAME",
    "LABEL_PROCESSOR_ID",
    "LABEL_WORKLOAD_TYPE",
    "LABEL_WORKLOAD_LOCATION",
    "LABEL_NODE_TYPE",
    "LABEL_MIGRATED_FROM_EDGE",
    "LABEL_ORIGINAL_NODE",
    # Label values
    "VALUE_ORCHESTRATOR_NAME",
    "VALUE_EDGE",
    "VALUE_MANAGED",
    # Enums
    "WorkloadLocation",
    "NodeType",
    # Builder
    "DoryLabels",
    # Utilities
    "get_label",
    "get_app_name",
    "get_processor_id",
    "get_workload_location",
    "is_managed_by_dory",
    "is_edge_workload",
    "is_migrated_from_edge",
    "get_original_node",
    "detect_workload_context",
    "edge_node_selector",
    "managed_node_selector",
    "edge_toleration",
    "get_contract_documentation",
    "CONTRACT_VERSION",
]
