"""Tests for adaptive edge/cloud processor behavior."""

import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from dory.edge.adaptive import (
    AdaptiveProcessor,
    AdaptiveConfig,
    EdgeConfig,
    OperationMode,
    create_adaptive_processor,
    get_location_aware_settings,
)
from dory.edge.detector import WorkloadContext, NodeType
from dory.edge.heartbeat import ConnectivityStatus
from dory.edge.role import ProcessorRole
from dory.k8s.labels import WorkloadLocation


class TestEdgeConfig:
    """Tests for EdgeConfig."""

    def test_default_values(self):
        """Test default configuration values."""
        config = EdgeConfig()

        # Edge heartbeat is more aggressive
        assert config.edge_heartbeat_interval_sec < config.cloud_heartbeat_interval_sec
        assert config.edge_max_missed_heartbeats >= config.cloud_max_missed_heartbeats

        # Edge checkpoints more frequently
        assert config.edge_checkpoint_interval_sec < config.cloud_checkpoint_interval_sec

        # Edge has smaller batches due to resource constraints
        assert config.edge_max_batch_size < config.cloud_max_batch_size
        assert config.edge_max_concurrent < config.cloud_max_concurrent

    def test_custom_values(self):
        """Test custom configuration."""
        config = EdgeConfig(
            edge_heartbeat_interval_sec=2.0,
            cloud_heartbeat_interval_sec=30.0,
            offline_buffer_max_size_mb=50,
        )

        assert config.edge_heartbeat_interval_sec == 2.0
        assert config.cloud_heartbeat_interval_sec == 30.0
        assert config.offline_buffer_max_size_mb == 50


class TestAdaptiveConfig:
    """Tests for AdaptiveConfig."""

    def test_creation(self):
        """Test config creation."""
        config = AdaptiveConfig(
            app_name="my-app",
            processor_id="proc-1",
            orchestrator_url="http://orchestrator:8080",
        )

        assert config.app_name == "my-app"
        assert config.processor_id == "proc-1"
        assert config.orchestrator_url == "http://orchestrator:8080"
        assert config.edge_config is not None

    def test_with_custom_edge_config(self):
        """Test with custom edge config."""
        edge_config = EdgeConfig(edge_max_batch_size=50)
        config = AdaptiveConfig(
            app_name="my-app",
            processor_id="proc-1",
            edge_config=edge_config,
        )

        assert config.edge_config.edge_max_batch_size == 50


class TestOperationMode:
    """Tests for OperationMode enum."""

    def test_values(self):
        """Test enum values."""
        assert OperationMode.EDGE_CONNECTED.value == "edge_connected"
        assert OperationMode.EDGE_OFFLINE.value == "edge_offline"
        assert OperationMode.CLOUD_NORMAL.value == "cloud_normal"
        assert OperationMode.CLOUD_FAILOVER.value == "cloud_failover"
        assert OperationMode.DEGRADED.value == "degraded"


class TestAdaptiveProcessor:
    """Tests for AdaptiveProcessor."""

    @pytest.fixture
    def edge_context(self):
        """Create edge workload context."""
        return WorkloadContext(
            node_type=NodeType.EDGE,
            workload_location=WorkloadLocation.EDGE,
            is_edge=True,
            is_migrated=False,
            original_node=None,
            node_name="edge-node-1",
            pod_name="my-pod",
            detection_method="environment",
            confidence="high",
        )

    @pytest.fixture
    def cloud_context(self):
        """Create cloud workload context."""
        return WorkloadContext(
            node_type=NodeType.CLOUD,
            workload_location=WorkloadLocation.MANAGED,
            is_edge=False,
            is_migrated=False,
            original_node=None,
            node_name="cloud-node-1",
            pod_name="my-pod",
            detection_method="environment",
            confidence="high",
        )

    @pytest.fixture
    def migrated_context(self):
        """Create migrated (failover) workload context."""
        return WorkloadContext(
            node_type=NodeType.CLOUD,
            workload_location=WorkloadLocation.EDGE,
            is_edge=False,
            is_migrated=True,
            original_node="edge-node-1",
            node_name="cloud-node-1",
            pod_name="failover-pod",
            detection_method="environment",
            confidence="high",
        )

    @pytest.fixture
    def processor_config(self):
        """Create processor config."""
        return AdaptiveConfig(
            app_name="test-app",
            processor_id="proc-1",
            orchestrator_url="http://orchestrator:8080",
        )

    def test_initial_state(self, processor_config):
        """Test processor initial state."""
        processor = AdaptiveProcessor(processor_config)

        assert processor.context is None
        assert processor.mode == OperationMode.DEGRADED
        assert processor.is_edge is False
        assert processor.is_cloud is True
        assert processor.is_migrated is False

    def test_get_heartbeat_config_edge(self, processor_config, edge_context):
        """Test heartbeat config for edge."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = edge_context

        config = processor.get_heartbeat_config()

        assert config.interval_sec == processor_config.edge_config.edge_heartbeat_interval_sec
        assert config.timeout_sec == processor_config.edge_config.edge_heartbeat_timeout_sec

    def test_get_heartbeat_config_cloud(self, processor_config, cloud_context):
        """Test heartbeat config for cloud."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = cloud_context

        config = processor.get_heartbeat_config()

        assert config.interval_sec == processor_config.edge_config.cloud_heartbeat_interval_sec
        assert config.timeout_sec == processor_config.edge_config.cloud_heartbeat_timeout_sec

    def test_get_batch_size_edge(self, processor_config, edge_context):
        """Test batch size for edge."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = edge_context

        batch_size = processor.get_max_batch_size()

        assert batch_size == processor_config.edge_config.edge_max_batch_size

    def test_get_batch_size_cloud(self, processor_config, cloud_context):
        """Test batch size for cloud."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = cloud_context

        batch_size = processor.get_max_batch_size()

        assert batch_size == processor_config.edge_config.cloud_max_batch_size

    def test_get_concurrent_edge(self, processor_config, edge_context):
        """Test concurrency for edge."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = edge_context

        concurrent = processor.get_max_concurrent()

        assert concurrent == processor_config.edge_config.edge_max_concurrent

    def test_get_concurrent_cloud(self, processor_config, cloud_context):
        """Test concurrency for cloud."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = cloud_context

        concurrent = processor.get_max_concurrent()

        assert concurrent == processor_config.edge_config.cloud_max_concurrent

    def test_determine_mode_edge_connected(self, processor_config, edge_context):
        """Test mode determination for connected edge."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = edge_context

        # Mock heartbeat as connected
        mock_heartbeat = MagicMock()
        mock_heartbeat.is_connected.return_value = True
        processor._heartbeat = mock_heartbeat

        mode = processor._determine_mode()

        assert mode == OperationMode.EDGE_CONNECTED

    def test_determine_mode_edge_offline(self, processor_config, edge_context):
        """Test mode determination for offline edge."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = edge_context

        # Mock heartbeat as disconnected
        mock_heartbeat = MagicMock()
        mock_heartbeat.is_connected.return_value = False
        processor._heartbeat = mock_heartbeat

        mode = processor._determine_mode()

        assert mode == OperationMode.EDGE_OFFLINE

    def test_determine_mode_cloud_normal(self, processor_config, cloud_context):
        """Test mode determination for normal cloud."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = cloud_context

        mode = processor._determine_mode()

        assert mode == OperationMode.CLOUD_NORMAL

    def test_determine_mode_cloud_failover(self, processor_config, migrated_context):
        """Test mode determination for failover cloud."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = migrated_context

        mode = processor._determine_mode()

        assert mode == OperationMode.CLOUD_FAILOVER

    def test_state_management(self, processor_config):
        """Test state get/set."""
        processor = AdaptiveProcessor(processor_config)

        processor.set_state({"counter": 42, "name": "test"})
        state = processor.get_state()

        assert state["counter"] == 42
        assert state["name"] == "test"

        # Verify it's a copy
        state["counter"] = 100
        assert processor.get_state()["counter"] == 42

    @pytest.mark.asyncio
    async def test_restore_state(self, processor_config):
        """Test state restoration."""
        processor = AdaptiveProcessor(processor_config)

        await processor.restore_state({"key": "value", "num": 123})

        state = processor.get_state()
        assert state["key"] == "value"
        assert state["num"] == 123

    def test_buffer_state_edge(self, processor_config, edge_context):
        """Test state buffering for offline edge."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = edge_context

        processor._buffer_state({"checkpoint": 1})
        processor._buffer_state({"checkpoint": 2})

        assert len(processor._offline_buffer) == 2

    def test_is_offline_property(self, processor_config, edge_context):
        """Test is_offline property."""
        processor = AdaptiveProcessor(processor_config)
        processor._context = edge_context
        processor._mode = OperationMode.EDGE_OFFLINE

        assert processor.is_offline is True

        processor._mode = OperationMode.EDGE_CONNECTED
        assert processor.is_offline is False

    def test_connectivity_status(self, processor_config):
        """Test connectivity status property."""
        processor = AdaptiveProcessor(processor_config)

        # No heartbeat manager
        assert processor.connectivity_status == ConnectivityStatus.UNKNOWN

        # With heartbeat manager
        mock_heartbeat = MagicMock()
        mock_heartbeat.get_status.return_value = ConnectivityStatus.CONNECTED
        processor._heartbeat = mock_heartbeat

        assert processor.connectivity_status == ConnectivityStatus.CONNECTED


class TestAdaptiveProcessorLifecycle:
    """Tests for AdaptiveProcessor lifecycle methods."""

    @pytest.fixture
    def mock_detector(self):
        """Create mock detector."""
        detector = MagicMock()
        detector.detect.return_value = WorkloadContext(
            node_type=NodeType.EDGE,
            workload_location=WorkloadLocation.EDGE,
            is_edge=True,
            is_migrated=False,
            original_node=None,
            node_name="edge-1",
            pod_name="pod-1",
            detection_method="test",
            confidence="high",
        )
        return detector

    @pytest.mark.asyncio
    async def test_start_edge(self, mock_detector):
        """Test starting processor on edge."""
        config = AdaptiveConfig(
            app_name="test-app",
            processor_id="proc-1",
            custom_detector=mock_detector,
        )

        processor = AdaptiveProcessor(config)

        with patch.object(processor, '_checkpoint_loop', new_callable=AsyncMock), \
             patch.object(processor, '_flush_loop', new_callable=AsyncMock), \
             patch('dory.edge.adaptive.FencingManager'), \
             patch('dory.edge.adaptive.RoleManager') as mock_role_cls:

            mock_role = AsyncMock()
            mock_role.start = AsyncMock()
            mock_role_cls.return_value = mock_role

            mode = await processor.start()

            assert processor.is_edge is True
            assert processor._running is True
            mock_detector.detect.assert_called_once()

    @pytest.mark.asyncio
    async def test_start_migrated(self, mock_detector):
        """Test starting migrated processor triggers callback."""
        mock_detector.detect.return_value = WorkloadContext(
            node_type=NodeType.CLOUD,
            workload_location=WorkloadLocation.EDGE,
            is_edge=False,
            is_migrated=True,
            original_node="edge-1",
            node_name="cloud-1",
            pod_name="failover-pod",
            detection_method="test",
            confidence="high",
        )

        config = AdaptiveConfig(
            app_name="test-app",
            processor_id="proc-1",
            custom_detector=mock_detector,
        )

        processor = AdaptiveProcessor(config)
        failover_callback = AsyncMock()
        processor.on_failover(failover_callback)

        with patch.object(processor, '_checkpoint_loop', new_callable=AsyncMock), \
             patch('dory.edge.adaptive.FencingManager'), \
             patch('dory.edge.adaptive.RoleManager') as mock_role_cls:

            mock_role = AsyncMock()
            mock_role.start = AsyncMock()
            mock_role_cls.return_value = mock_role

            await processor.start()

            failover_callback.assert_called_once_with("edge-1")

    @pytest.mark.asyncio
    async def test_stop(self, mock_detector):
        """Test stopping processor."""
        config = AdaptiveConfig(
            app_name="test-app",
            processor_id="proc-1",
            custom_detector=mock_detector,
        )

        processor = AdaptiveProcessor(config)
        processor._running = True

        mock_role = AsyncMock()
        mock_role.stop = AsyncMock()
        processor._role_manager = mock_role

        await processor.stop("test-shutdown")

        assert processor._running is False
        mock_role.stop.assert_called_once_with("test-shutdown")


class TestAdaptiveProcessorCallbacks:
    """Tests for callback registration."""

    def test_on_mode_change(self):
        """Test mode change callback registration."""
        config = AdaptiveConfig(app_name="test", processor_id="proc-1")
        processor = AdaptiveProcessor(config)

        callback = AsyncMock()
        processor.on_mode_change(callback)

        assert processor._on_mode_change is callback

    def test_on_connectivity_change(self):
        """Test connectivity change callback registration."""
        config = AdaptiveConfig(app_name="test", processor_id="proc-1")
        processor = AdaptiveProcessor(config)

        callback = AsyncMock()
        processor.on_connectivity_change(callback)

        assert processor._on_connectivity_change is callback

    def test_on_failover(self):
        """Test failover callback registration."""
        config = AdaptiveConfig(app_name="test", processor_id="proc-1")
        processor = AdaptiveProcessor(config)

        callback = AsyncMock()
        processor.on_failover(callback)

        assert processor._on_failover is callback

    def test_on_failback(self):
        """Test failback callback registration."""
        config = AdaptiveConfig(app_name="test", processor_id="proc-1")
        processor = AdaptiveProcessor(config)

        callback = AsyncMock()
        processor.on_failback(callback)

        assert processor._on_failback is callback


class TestConvenienceFunctions:
    """Tests for convenience functions."""

    def test_create_adaptive_processor(self):
        """Test create_adaptive_processor function."""
        processor = create_adaptive_processor(
            app_name="my-app",
            processor_id="proc-1",
            orchestrator_url="http://orchestrator:8080",
        )

        assert isinstance(processor, AdaptiveProcessor)
        assert processor.config.app_name == "my-app"
        assert processor.config.processor_id == "proc-1"

    def test_create_adaptive_processor_with_custom_config(self):
        """Test create_adaptive_processor with custom edge config."""
        processor = create_adaptive_processor(
            app_name="my-app",
            processor_id="proc-1",
            edge_max_batch_size=50,
            edge_max_concurrent=1,
        )

        assert processor.config.edge_config.edge_max_batch_size == 50
        assert processor.config.edge_config.edge_max_concurrent == 1

    def test_get_location_aware_settings_edge(self):
        """Test get_location_aware_settings for edge."""
        with patch('dory.edge.adaptive.get_workload_context') as mock_ctx:
            mock_ctx.return_value = MagicMock(is_edge=True)

            settings = get_location_aware_settings()

            assert settings["offline_buffer_enabled"] is True
            assert settings["max_batch_size"] == EdgeConfig().edge_max_batch_size
            assert settings["max_concurrent"] == EdgeConfig().edge_max_concurrent

    def test_get_location_aware_settings_cloud(self):
        """Test get_location_aware_settings for cloud."""
        with patch('dory.edge.adaptive.get_workload_context') as mock_ctx:
            mock_ctx.return_value = MagicMock(is_edge=False)

            settings = get_location_aware_settings()

            assert settings["offline_buffer_enabled"] is False
            assert settings["max_batch_size"] == EdgeConfig().cloud_max_batch_size
            assert settings["max_concurrent"] == EdgeConfig().cloud_max_concurrent


class TestEdgeVsCloudBehavior:
    """Integration tests comparing edge vs cloud behavior."""

    def test_edge_has_smaller_batches(self):
        """Verify edge uses smaller batch sizes."""
        config = EdgeConfig()
        assert config.edge_max_batch_size < config.cloud_max_batch_size

    def test_edge_has_lower_concurrency(self):
        """Verify edge uses lower concurrency."""
        config = EdgeConfig()
        assert config.edge_max_concurrent < config.cloud_max_concurrent

    def test_edge_has_more_frequent_heartbeats(self):
        """Verify edge sends heartbeats more frequently."""
        config = EdgeConfig()
        assert config.edge_heartbeat_interval_sec < config.cloud_heartbeat_interval_sec

    def test_edge_has_more_frequent_checkpoints(self):
        """Verify edge checkpoints more frequently."""
        config = EdgeConfig()
        assert config.edge_checkpoint_interval_sec < config.cloud_checkpoint_interval_sec

    def test_edge_has_more_retries(self):
        """Verify edge has more retries (for intermittent connectivity)."""
        config = EdgeConfig()
        assert config.edge_max_retries > config.cloud_max_retries

    def test_only_edge_has_offline_buffer(self):
        """Verify offline buffer is edge-only."""
        config = EdgeConfig()
        assert config.offline_buffer_enabled is True

        # Cloud settings disable it
        with patch('dory.edge.adaptive.get_workload_context') as mock_ctx:
            mock_ctx.return_value = MagicMock(is_edge=False)
            settings = get_location_aware_settings()
            assert settings["offline_buffer_enabled"] is False
