"""Tests for edge/cloud workload detection."""

import pytest
from unittest.mock import MagicMock, patch

from dory.edge.detector import (
    WorkloadDetector,
    WorkloadContext,
    NodeType,
    is_edge_node,
    is_cloud_node,
    is_migrated_workload,
    get_workload_context,
    get_node_type,
    get_recommended_env_vars,
    get_pod_spec_yaml_snippet,
)
from dory.k8s.labels import WorkloadLocation


class TestNodeType:
    """Tests for NodeType enum."""

    def test_values(self):
        """Test enum values."""
        assert NodeType.EDGE.value == "edge"
        assert NodeType.CLOUD.value == "cloud"
        assert NodeType.UNKNOWN.value == "unknown"


class TestWorkloadContext:
    """Tests for WorkloadContext."""

    def test_creation(self):
        """Test context creation."""
        context = WorkloadContext(
            node_type=NodeType.EDGE,
            workload_location=WorkloadLocation.EDGE,
            is_edge=True,
            is_migrated=False,
            original_node=None,
            node_name="edge-node-1",
            pod_name="my-pod",
            detection_method="environment",
            confidence="high",
        )

        assert context.is_edge is True
        assert context.node_type == NodeType.EDGE

    def test_to_dict(self):
        """Test context serialization."""
        context = WorkloadContext(
            node_type=NodeType.CLOUD,
            workload_location=WorkloadLocation.MANAGED,
            is_edge=False,
            is_migrated=True,
            original_node="edge-1",
            node_name="cloud-node",
            pod_name="migrated-pod",
            detection_method="pod_labels",
            confidence="high",
        )

        data = context.to_dict()

        assert data["node_type"] == "cloud"
        assert data["is_migrated"] is True
        assert data["original_node"] == "edge-1"


class TestWorkloadDetector:
    """Tests for WorkloadDetector."""

    @pytest.fixture
    def detector(self):
        """Create detector instance."""
        return WorkloadDetector()

    def test_detect_from_env_edge(self, detector):
        """Test edge detection from environment."""
        env = {
            "DORY_WORKLOAD_LOCATION": "edge",
            "NODE_NAME": "edge-node-1",
            "POD_NAME": "my-pod",
        }

        with patch.dict("os.environ", env, clear=True):
            detector.clear_cache()
            context = detector.detect()

            assert context.is_edge is True
            assert context.workload_location == WorkloadLocation.EDGE
            assert context.detection_method == "environment"
            assert context.confidence == "high"

    def test_detect_from_env_cloud(self, detector):
        """Test cloud detection from environment."""
        env = {
            "DORY_WORKLOAD_LOCATION": "managed",
            "DORY_NODE_TYPE": "cloud",
            "NODE_NAME": "cloud-node-1",
            "POD_NAME": "my-pod",
        }

        with patch.dict("os.environ", env, clear=True):
            detector.clear_cache()
            context = detector.detect()

            assert context.is_edge is False
            assert context.node_type == NodeType.CLOUD
            assert context.workload_location == WorkloadLocation.MANAGED

    def test_detect_from_env_node_type(self, detector):
        """Test detection from NODE_TYPE env var (Downward API)."""
        env = {
            "NODE_TYPE": "edge",
            "NODE_NAME": "my-edge",
        }

        with patch.dict("os.environ", env, clear=True):
            detector.clear_cache()
            context = detector.detect()

            assert context.node_type == NodeType.EDGE
            assert context.is_edge is True

    def test_detect_migrated_workload(self, detector):
        """Test detection of migrated workload."""
        env = {
            "DORY_WORKLOAD_LOCATION": "edge",
            "DORY_MIGRATED_FROM_EDGE": "true",
            "DORY_ORIGINAL_NODE": "edge-node-1",
            "NODE_NAME": "cloud-node-1",
            "POD_NAME": "migrated-pod",
        }

        with patch.dict("os.environ", env, clear=True):
            detector.clear_cache()
            context = detector.detect()

            assert context.is_migrated is True
            assert context.original_node == "edge-node-1"
            # Migrated pods are edge workloads but NOT on edge
            assert context.is_edge is False
            assert context.workload_location == WorkloadLocation.EDGE

    def test_detect_from_node_name_edge_pattern(self, detector):
        """Test edge detection from node name pattern."""
        env = {
            "NODE_NAME": "edge-us-west-1",
            "POD_NAME": "my-pod",
        }

        with patch.dict("os.environ", env, clear=True):
            detector.clear_cache()
            context = detector.detect()

            assert context.is_edge is True
            assert context.detection_method == "node_name_pattern"
            assert context.confidence == "low"

    def test_detect_from_node_name_cloud_pattern(self, detector):
        """Test cloud detection from node name pattern (AWS)."""
        env = {
            "NODE_NAME": "ip-172-31-45-123.ec2.internal",
            "POD_NAME": "my-pod",
        }

        with patch.dict("os.environ", env, clear=True):
            detector.clear_cache()
            context = detector.detect()

            assert context.is_edge is False
            assert context.node_type == NodeType.CLOUD

    def test_detect_from_node_name_gke_pattern(self, detector):
        """Test cloud detection from GKE node name."""
        env = {
            "NODE_NAME": "gke-my-cluster-default-pool-abc123",
            "POD_NAME": "my-pod",
        }

        with patch.dict("os.environ", env, clear=True):
            detector.clear_cache()
            context = detector.detect()

            assert context.is_edge is False
            assert context.node_type == NodeType.CLOUD

    def test_detect_default_unknown(self, detector):
        """Test default when no detection method works."""
        with patch.dict("os.environ", {}, clear=True):
            detector.clear_cache()
            context = detector.detect()

            assert context.node_type == NodeType.UNKNOWN
            assert context.is_edge is False  # Default to cloud behavior
            assert context.detection_method == "default"
            assert context.confidence == "none"

    def test_cache(self, detector):
        """Test detection caching."""
        env = {
            "DORY_WORKLOAD_LOCATION": "edge",
            "NODE_NAME": "edge-1",
        }

        with patch.dict("os.environ", env, clear=True):
            detector.clear_cache()
            context1 = detector.detect()
            context2 = detector.detect()

            # Should return same cached object
            assert context1 is context2

    def test_clear_cache(self, detector):
        """Test cache clearing."""
        env = {"DORY_WORKLOAD_LOCATION": "edge"}

        with patch.dict("os.environ", env, clear=True):
            detector.clear_cache()
            context1 = detector.detect()
            detector.clear_cache()
            context2 = detector.detect()

            # Should be different objects after cache clear
            assert context1 is not context2

    def test_custom_patterns(self):
        """Test custom node name patterns."""
        detector = WorkloadDetector(
            edge_patterns=[r"^myedge-"],
            cloud_patterns=[r"^mycloud-"],
        )

        # Edge pattern
        with patch.dict("os.environ", {"NODE_NAME": "myedge-001"}, clear=True):
            detector.clear_cache()
            context = detector.detect()
            assert context.is_edge is True

        # Cloud pattern
        with patch.dict("os.environ", {"NODE_NAME": "mycloud-001"}, clear=True):
            detector.clear_cache()
            context = detector.detect()
            assert context.is_edge is False


class TestConvenienceFunctions:
    """Tests for convenience functions."""

    def test_is_edge_node(self):
        """Test is_edge_node function."""
        env = {"DORY_WORKLOAD_LOCATION": "edge"}

        with patch.dict("os.environ", env, clear=True):
            # Clear the global detector cache
            from dory.edge import detector
            detector._default_detector = None

            assert is_edge_node() is True

    def test_is_cloud_node(self):
        """Test is_cloud_node function."""
        env = {"DORY_WORKLOAD_LOCATION": "managed"}

        with patch.dict("os.environ", env, clear=True):
            from dory.edge import detector
            detector._default_detector = None

            assert is_cloud_node() is True

    def test_is_migrated_workload(self):
        """Test is_migrated_workload function."""
        env = {
            "DORY_WORKLOAD_LOCATION": "edge",
            "DORY_MIGRATED_FROM_EDGE": "true",
        }

        with patch.dict("os.environ", env, clear=True):
            from dory.edge import detector
            detector._default_detector = None

            assert is_migrated_workload() is True

    def test_get_node_type(self):
        """Test get_node_type function."""
        env = {"DORY_NODE_TYPE": "edge"}

        with patch.dict("os.environ", env, clear=True):
            from dory.edge import detector
            detector._default_detector = None

            assert get_node_type() == NodeType.EDGE


class TestPodSpecHelpers:
    """Tests for pod spec helpers."""

    def test_get_recommended_env_vars(self):
        """Test recommended env vars."""
        env_vars = get_recommended_env_vars()

        assert len(env_vars) > 0

        # Check for key variables
        names = [e["name"] for e in env_vars]
        assert "POD_NAME" in names
        assert "NODE_NAME" in names
        assert "DORY_WORKLOAD_LOCATION" in names

    def test_get_pod_spec_yaml_snippet(self):
        """Test YAML snippet generation."""
        yaml_str = get_pod_spec_yaml_snippet()

        assert "POD_NAME" in yaml_str
        assert "NODE_NAME" in yaml_str
        assert "DORY_WORKLOAD_LOCATION" in yaml_str
        assert "fieldRef" in yaml_str


class TestIntegrationScenarios:
    """Integration tests for common scenarios."""

    def test_edge_processor_on_edge_node(self):
        """Test edge processor running on edge node."""
        env = {
            "DORY_WORKLOAD_LOCATION": "edge",
            "DORY_NODE_TYPE": "edge",
            "NODE_NAME": "edge-us-west-1",
            "POD_NAME": "edge-processor-abc",
        }

        with patch.dict("os.environ", env, clear=True):
            from dory.edge import detector
            detector._default_detector = None

            context = get_workload_context()

            assert context.is_edge is True
            assert context.node_type == NodeType.EDGE
            assert context.is_migrated is False
            assert context.node_name == "edge-us-west-1"

    def test_edge_processor_failed_over_to_cloud(self):
        """Test edge processor after failover to cloud."""
        env = {
            "DORY_WORKLOAD_LOCATION": "edge",  # Still edge workload
            "DORY_MIGRATED_FROM_EDGE": "true",
            "DORY_ORIGINAL_NODE": "edge-us-west-1",
            "DORY_NODE_TYPE": "cloud",
            "NODE_NAME": "ip-172-31-1-1.ec2.internal",
            "POD_NAME": "edge-processor-failover",
        }

        with patch.dict("os.environ", env, clear=True):
            from dory.edge import detector
            detector._default_detector = None

            context = get_workload_context()

            assert context.is_edge is False  # NOT on edge anymore
            assert context.is_migrated is True
            assert context.original_node == "edge-us-west-1"
            assert context.workload_location == WorkloadLocation.EDGE

    def test_cloud_processor_on_cloud_node(self):
        """Test cloud processor on cloud node."""
        env = {
            "DORY_WORKLOAD_LOCATION": "managed",
            "DORY_NODE_TYPE": "cloud",
            "NODE_NAME": "gke-cluster-pool-123",
            "POD_NAME": "cloud-processor-xyz",
        }

        with patch.dict("os.environ", env, clear=True):
            from dory.edge import detector
            detector._default_detector = None

            context = get_workload_context()

            assert context.is_edge is False
            assert context.node_type == NodeType.CLOUD
            assert context.workload_location == WorkloadLocation.MANAGED
            assert context.is_migrated is False
