"""Tests for edge fencing and split-brain prevention."""

import asyncio
import pytest
import time
from unittest.mock import AsyncMock, MagicMock, patch

from dory.edge.fencing import (
    FencingConfig,
    FencingToken,
    FencingManager,
    FencingError,
    FenceViolation,
    StaleEpochError,
    InMemoryFencingBackend,
)
from dory.edge.role import (
    ProcessorRole,
    RoleManager,
    RoleTransition,
)


class TestFencingToken:
    """Tests for FencingToken."""

    def test_token_creation(self):
        """Test basic token creation."""
        token = FencingToken(
            processor_id="test-processor",
            node_id="node-1",
            epoch=5,
        )

        assert token.processor_id == "test-processor"
        assert token.node_id == "node-1"
        assert token.epoch == 5
        assert token.acquired_at > 0
        assert len(token.token_id) == 16  # 8 hex bytes

    def test_token_validity(self):
        """Test token validity checking."""
        token = FencingToken(
            processor_id="test",
            node_id="node",
            epoch=5,
        )

        # Token is valid if epoch >= current
        assert token.is_valid(current_epoch=5) is True
        assert token.is_valid(current_epoch=4) is True
        assert token.is_valid(current_epoch=6) is False

    def test_token_serialization(self):
        """Test token to/from dict."""
        token = FencingToken(
            processor_id="test",
            node_id="node",
            epoch=10,
        )

        data = token.to_dict()
        assert data["processor_id"] == "test"
        assert data["epoch"] == 10

        restored = FencingToken.from_dict(data)
        assert restored.processor_id == token.processor_id
        assert restored.epoch == token.epoch


class TestFencingConfig:
    """Tests for FencingConfig."""

    def test_default_config(self):
        """Test default configuration."""
        config = FencingConfig()

        assert config.acquire_timeout_sec == 10.0
        assert config.lock_ttl_sec == 60.0
        assert config.refresh_interval_sec == 15.0
        assert config.backend == "redis"

    def test_validation_refresh_interval(self):
        """Test that refresh interval must be less than TTL."""
        with pytest.raises(ValueError) as exc_info:
            FencingConfig(
                lock_ttl_sec=30.0,
                refresh_interval_sec=35.0,
            )

        assert "refresh_interval_sec" in str(exc_info.value)

    def test_redis_url_from_env(self):
        """Test Redis URL from environment."""
        with patch.dict("os.environ", {"DORY_REDIS_URL": "redis://custom:6379"}):
            config = FencingConfig(backend="redis", redis_url=None)
            assert config.redis_url == "redis://custom:6379"


class TestInMemoryFencingBackend:
    """Tests for InMemoryFencingBackend."""

    @pytest.mark.asyncio
    async def test_acquire_epoch(self):
        """Test epoch acquisition and increment."""
        backend = InMemoryFencingBackend()

        epoch1 = await backend.acquire_epoch("proc-1", "node-1")
        assert epoch1 == 1

        epoch2 = await backend.acquire_epoch("proc-1", "node-2")
        assert epoch2 == 2

        # Different processor starts at 1
        epoch3 = await backend.acquire_epoch("proc-2", "node-1")
        assert epoch3 == 1

    @pytest.mark.asyncio
    async def test_get_current_epoch(self):
        """Test getting current epoch."""
        backend = InMemoryFencingBackend()

        # Non-existent processor returns 0
        epoch = await backend.get_current_epoch("unknown")
        assert epoch == 0

        await backend.acquire_epoch("proc-1", "node-1")
        epoch = await backend.get_current_epoch("proc-1")
        assert epoch == 1

    @pytest.mark.asyncio
    async def test_validate_epoch(self):
        """Test epoch validation."""
        backend = InMemoryFencingBackend()

        await backend.acquire_epoch("proc-1", "node-1")  # epoch = 1
        await backend.acquire_epoch("proc-1", "node-2")  # epoch = 2

        # Current and future epochs are valid
        assert await backend.validate_epoch("proc-1", 2) is True
        assert await backend.validate_epoch("proc-1", 3) is True

        # Past epoch is invalid
        assert await backend.validate_epoch("proc-1", 1) is False

    @pytest.mark.asyncio
    async def test_release(self):
        """Test lock release."""
        backend = InMemoryFencingBackend()

        await backend.acquire_epoch("proc-1", "node-1")
        await backend.release("proc-1", "node-1")

        # Should be able to acquire again
        epoch = await backend.acquire_epoch("proc-1", "node-2")
        assert epoch == 2  # Epoch still increments


class TestFencingManager:
    """Tests for FencingManager."""

    @pytest.mark.asyncio
    async def test_acquire_token(self):
        """Test acquiring fencing token."""
        config = FencingConfig(backend="memory")
        manager = FencingManager(config)

        try:
            token = await manager.acquire("proc-1", "node-1")

            assert token.processor_id == "proc-1"
            assert token.node_id == "node-1"
            assert token.epoch == 1
        finally:
            await manager.close()

    @pytest.mark.asyncio
    async def test_validate_token(self):
        """Test token validation."""
        config = FencingConfig(backend="memory")
        manager = FencingManager(config)

        try:
            token = await manager.acquire("proc-1", "node-1")
            assert await manager.validate(token) is True

            # Acquire new epoch (simulates another instance taking over)
            await manager._backend.acquire_epoch("proc-1", "node-2")

            # Original token is now stale
            assert await manager.validate(token) is False
        finally:
            await manager.close()

    @pytest.mark.asyncio
    async def test_validate_or_raise(self):
        """Test validate_or_raise raises on stale token."""
        config = FencingConfig(backend="memory")
        manager = FencingManager(config)

        try:
            token = await manager.acquire("proc-1", "node-1")

            # Validate should pass
            await manager.validate_or_raise(token)

            # Acquire new epoch
            await manager._backend.acquire_epoch("proc-1", "node-2")

            # Now should raise
            with pytest.raises(StaleEpochError):
                await manager.validate_or_raise(token)
        finally:
            await manager.close()

    @pytest.mark.asyncio
    async def test_release_token(self):
        """Test releasing fencing token."""
        config = FencingConfig(backend="memory")
        manager = FencingManager(config)

        try:
            token = await manager.acquire("proc-1", "node-1")
            assert manager.get_active_token("proc-1") is not None

            await manager.release(token)
            assert manager.get_active_token("proc-1") is None
        finally:
            await manager.close()

    @pytest.mark.asyncio
    async def test_get_current_epoch(self):
        """Test getting current epoch."""
        config = FencingConfig(backend="memory")
        manager = FencingManager(config)

        try:
            # Initially 0
            epoch = await manager.get_current_epoch("proc-1")
            assert epoch == 0

            await manager.acquire("proc-1", "node-1")
            epoch = await manager.get_current_epoch("proc-1")
            assert epoch == 1
        finally:
            await manager.close()

    @pytest.mark.asyncio
    async def test_acquire_timeout(self):
        """Test acquisition timeout."""
        config = FencingConfig(backend="memory")
        manager = FencingManager(config)

        # Mock a slow backend
        async def slow_acquire(*args):
            await asyncio.sleep(5.0)
            return 1

        manager._backend.acquire_epoch = slow_acquire

        try:
            with pytest.raises(FencingError) as exc_info:
                await manager.acquire("proc-1", "node-1", timeout_sec=0.1)

            assert "Failed to acquire" in str(exc_info.value)
        finally:
            await manager.close()


class TestProcessorRole:
    """Tests for ProcessorRole enum."""

    def test_can_process(self):
        """Test can_process for different roles."""
        assert ProcessorRole.PRIMARY.can_process() is True
        assert ProcessorRole.STANDBY.can_process() is False
        assert ProcessorRole.DRAINING.can_process() is False
        assert ProcessorRole.FENCED.can_process() is False

    def test_can_write_state(self):
        """Test can_write_state for different roles."""
        assert ProcessorRole.PRIMARY.can_write_state() is True
        assert ProcessorRole.DRAINING.can_write_state() is True
        assert ProcessorRole.STANDBY.can_write_state() is False
        assert ProcessorRole.FENCED.can_write_state() is False

    def test_is_terminal(self):
        """Test terminal state detection."""
        assert ProcessorRole.STOPPED.is_terminal() is True
        assert ProcessorRole.FENCED.is_terminal() is True
        assert ProcessorRole.PRIMARY.is_terminal() is False


class TestRoleTransition:
    """Tests for RoleTransition."""

    def test_transition_creation(self):
        """Test transition record creation."""
        transition = RoleTransition(
            from_role=ProcessorRole.INITIALIZING,
            to_role=ProcessorRole.PRIMARY,
            reason="Acquired fencing token",
            epoch=1,
            node_id="node-1",
        )

        assert transition.from_role == ProcessorRole.INITIALIZING
        assert transition.to_role == ProcessorRole.PRIMARY
        assert transition.epoch == 1

    def test_transition_serialization(self):
        """Test transition to dict."""
        transition = RoleTransition(
            from_role=ProcessorRole.PRIMARY,
            to_role=ProcessorRole.FENCED,
            reason="Lost token",
        )

        data = transition.to_dict()
        assert data["from_role"] == "primary"
        assert data["to_role"] == "fenced"


class TestRoleManager:
    """Tests for RoleManager."""

    @pytest.mark.asyncio
    async def test_start_as_primary(self):
        """Test starting as PRIMARY."""
        fencing_config = FencingConfig(backend="memory")
        manager = RoleManager(
            processor_id="proc-1",
            node_id="node-1",
            fencing_config=fencing_config,
        )

        try:
            role = await manager.start()

            assert role == ProcessorRole.PRIMARY
            assert manager.can_process() is True
            assert manager.fencing_token is not None
            assert manager.fencing_token.epoch == 1
        finally:
            await manager.stop()

    @pytest.mark.asyncio
    async def test_start_as_standby(self):
        """Test starting as STANDBY."""
        fencing_config = FencingConfig(backend="memory")
        manager = RoleManager(
            processor_id="proc-1",
            node_id="node-1",
            fencing_config=fencing_config,
            start_as_standby=True,
        )

        try:
            role = await manager.start()

            assert role == ProcessorRole.STANDBY
            assert manager.can_process() is False
            assert manager.fencing_token is None
        finally:
            await manager.stop()

    @pytest.mark.asyncio
    async def test_promote_to_primary(self):
        """Test promotion from STANDBY to PRIMARY."""
        fencing_config = FencingConfig(backend="memory")
        manager = RoleManager(
            processor_id="proc-1",
            node_id="cloud-1",
            fencing_config=fencing_config,
            start_as_standby=True,
        )

        try:
            await manager.start()
            assert manager.role == ProcessorRole.STANDBY

            # Promote to PRIMARY
            success = await manager.promote_to_primary()

            assert success is True
            assert manager.role == ProcessorRole.PRIMARY
            assert manager.fencing_token is not None
        finally:
            await manager.stop()

    @pytest.mark.asyncio
    async def test_demote_to_standby(self):
        """Test demotion from PRIMARY to STANDBY."""
        fencing_config = FencingConfig(backend="memory")
        manager = RoleManager(
            processor_id="proc-1",
            node_id="node-1",
            fencing_config=fencing_config,
        )

        try:
            await manager.start()
            assert manager.role == ProcessorRole.PRIMARY

            await manager.demote_to_standby(reason="Test demotion")

            assert manager.role == ProcessorRole.STANDBY
            assert manager.fencing_token is None
        finally:
            await manager.stop()

    @pytest.mark.asyncio
    async def test_role_change_callback(self):
        """Test role change callbacks are called."""
        fencing_config = FencingConfig(backend="memory")
        manager = RoleManager(
            processor_id="proc-1",
            node_id="node-1",
            fencing_config=fencing_config,
        )

        transitions = []

        async def callback(transition: RoleTransition):
            transitions.append(transition)

        manager.add_role_change_callback(callback)

        try:
            await manager.start()
            await manager.stop()

            # Should have: INIT->PRIMARY, PRIMARY->DRAINING, DRAINING->STOPPED
            assert len(transitions) >= 2
            assert transitions[0].to_role == ProcessorRole.PRIMARY
        finally:
            pass  # Already stopped

    @pytest.mark.asyncio
    async def test_fencing_validation(self):
        """Test fencing validation during PRIMARY role."""
        fencing_config = FencingConfig(backend="memory")
        manager = RoleManager(
            processor_id="proc-1",
            node_id="node-1",
            fencing_config=fencing_config,
        )

        try:
            await manager.start()

            # Should be valid
            assert await manager.validate_fencing() is True

            # Simulate another instance acquiring (incrementing epoch)
            await manager._fencing_manager._backend.acquire_epoch(
                "proc-1", "node-2"
            )

            # Now should be invalid
            assert await manager.validate_fencing() is False
        finally:
            await manager.stop()

    @pytest.mark.asyncio
    async def test_validate_fencing_or_fence(self):
        """Test automatic fencing on stale token."""
        fencing_config = FencingConfig(backend="memory")
        manager = RoleManager(
            processor_id="proc-1",
            node_id="edge-1",
            fencing_config=fencing_config,
        )

        try:
            await manager.start()
            assert manager.role == ProcessorRole.PRIMARY

            # Simulate cloud taking over
            await manager._fencing_manager._backend.acquire_epoch(
                "proc-1", "cloud-1"
            )

            # This should transition to FENCED
            result = await manager.validate_fencing_or_fence()

            assert result is False
            assert manager.role == ProcessorRole.FENCED
        finally:
            await manager.stop()

    @pytest.mark.asyncio
    async def test_get_status(self):
        """Test status dictionary."""
        fencing_config = FencingConfig(backend="memory")
        manager = RoleManager(
            processor_id="proc-1",
            node_id="node-1",
            fencing_config=fencing_config,
        )

        try:
            await manager.start()

            status = manager.get_status()

            assert status["processor_id"] == "proc-1"
            assert status["role"] == "primary"
            assert status["can_process"] is True
            assert status["fencing_epoch"] == 1
            assert status["is_running"] is True
        finally:
            await manager.stop()

    @pytest.mark.asyncio
    async def test_role_history(self):
        """Test role transition history tracking."""
        fencing_config = FencingConfig(backend="memory")
        manager = RoleManager(
            processor_id="proc-1",
            node_id="node-1",
            fencing_config=fencing_config,
        )

        try:
            await manager.start()
            await manager.demote_to_standby()
            await manager.promote_to_primary()

            history = manager.get_role_history()

            # Should have multiple transitions
            assert len(history) >= 3
            roles = [t.to_role for t in history]
            assert ProcessorRole.PRIMARY in roles
            assert ProcessorRole.STANDBY in roles
        finally:
            await manager.stop()


class TestSplitBrainScenario:
    """Integration tests for split-brain prevention scenarios."""

    @pytest.mark.asyncio
    async def test_edge_cloud_failover(self):
        """Test edge-to-cloud failover scenario."""
        fencing_config = FencingConfig(backend="memory")

        # Edge processor starts as PRIMARY
        edge = RoleManager(
            processor_id="shared-proc",
            node_id="edge-1",
            fencing_config=fencing_config,
        )

        # Cloud replica starts as STANDBY
        cloud = RoleManager(
            processor_id="shared-proc",
            node_id="cloud-1",
            fencing_config=fencing_config,
            start_as_standby=True,
        )

        # Share the same backend for testing
        cloud._fencing_manager._backend = edge._fencing_manager._backend

        try:
            # Both start
            await edge.start()
            await cloud.start()

            assert edge.role == ProcessorRole.PRIMARY
            assert cloud.role == ProcessorRole.STANDBY

            # Cloud promotes (simulating edge failure detected)
            success = await cloud.promote_to_primary()
            assert success is True
            assert cloud.role == ProcessorRole.PRIMARY
            assert cloud.fencing_token.epoch == 2

            # Edge's token is now stale
            assert await edge.validate_fencing() is False

            # Edge detects it's fenced
            await edge.validate_fencing_or_fence()
            assert edge.role == ProcessorRole.FENCED

        finally:
            await edge.stop()
            await cloud.stop()

    @pytest.mark.asyncio
    async def test_no_dual_write(self):
        """Test that fencing prevents dual writes."""
        fencing_config = FencingConfig(backend="memory")

        edge = RoleManager(
            processor_id="proc",
            node_id="edge",
            fencing_config=fencing_config,
        )

        cloud = RoleManager(
            processor_id="proc",
            node_id="cloud",
            fencing_config=fencing_config,
            start_as_standby=True,
        )
        cloud._fencing_manager._backend = edge._fencing_manager._backend

        writes = []

        async def write_state(manager: RoleManager, data: str):
            """Simulated state write with fencing check."""
            if manager.can_write_state():
                if await manager.validate_fencing():
                    writes.append((manager.node_id, data))
                    return True
            return False

        try:
            await edge.start()
            await cloud.start()

            # Edge writes successfully
            assert await write_state(edge, "edge-data-1") is True

            # Cloud promotes
            await cloud.promote_to_primary()

            # Cloud writes successfully
            assert await write_state(cloud, "cloud-data-1") is True

            # Edge tries to write but fails fencing check
            assert await write_state(edge, "edge-data-2") is False

            # Only valid writes recorded
            assert len(writes) == 2
            assert writes[0] == ("edge", "edge-data-1")
            assert writes[1] == ("cloud", "cloud-data-1")

        finally:
            await edge.stop()
            await cloud.stop()
