"""Tests for edge heartbeat and connectivity monitoring."""

import asyncio
import pytest
import time
from unittest.mock import AsyncMock, MagicMock, patch
from aiohttp import ClientError

from dory.edge.heartbeat import (
    HeartbeatConfig,
    HeartbeatManager,
    HeartbeatPayload,
    HeartbeatResponse,
    ConnectivityStatus,
    ConnectivityMetrics,
    EdgeHealthReporter,
)
from dory.edge.role import ProcessorRole
from dory.edge.fencing import FencingToken


class TestHeartbeatConfig:
    """Tests for HeartbeatConfig."""

    def test_default_config(self):
        """Test default configuration values."""
        config = HeartbeatConfig()

        assert config.interval_sec == 10.0
        assert config.timeout_sec == 5.0
        assert config.missed_threshold == 3
        assert config.recovery_threshold == 2
        assert config.latency_threshold_ms == 500.0
        assert config.auto_demote_on_disconnect is True
        assert config.demote_grace_period_sec == 30.0

    def test_orchestrator_url_from_env(self):
        """Test Orchestrator URL from environment."""
        with patch.dict("os.environ", {"DORY_ORCHESTRATOR_URL": "http://custom:9090"}):
            config = HeartbeatConfig(orchestrator_url=None)
            assert config.orchestrator_url == "http://custom:9090"

    def test_custom_config(self):
        """Test custom configuration values."""
        config = HeartbeatConfig(
            orchestrator_url="http://test:8080",
            interval_sec=5.0,
            missed_threshold=5,
        )

        assert config.orchestrator_url == "http://test:8080"
        assert config.interval_sec == 5.0
        assert config.missed_threshold == 5


class TestHeartbeatPayload:
    """Tests for HeartbeatPayload."""

    def test_payload_creation(self):
        """Test payload creation."""
        payload = HeartbeatPayload(
            processor_id="proc-1",
            node_id="edge-1",
            role="primary",
            epoch=5,
            last_state_sync=1234567890.0,
            state_size_bytes=1024,
            uptime_sec=3600.0,
        )

        assert payload.processor_id == "proc-1"
        assert payload.node_id == "edge-1"
        assert payload.role == "primary"
        assert payload.epoch == 5

    def test_payload_to_dict(self):
        """Test payload serialization."""
        payload = HeartbeatPayload(
            processor_id="proc-1",
            node_id="edge-1",
            role="primary",
            epoch=5,
        )

        data = payload.to_dict()
        assert data["processor_id"] == "proc-1"
        assert data["role"] == "primary"
        assert "timestamp" in data


class TestHeartbeatResponse:
    """Tests for HeartbeatResponse."""

    def test_response_from_dict(self):
        """Test response deserialization."""
        data = {
            "acknowledged": True,
            "orchestrator_time": 1234567890.0,
            "directive": "continue",
            "message": "OK",
        }

        response = HeartbeatResponse.from_dict(data)

        assert response.acknowledged is True
        assert response.directive == "continue"
        assert response.message == "OK"

    def test_response_defaults(self):
        """Test response with minimal data."""
        data = {"acknowledged": False}
        response = HeartbeatResponse.from_dict(data)

        assert response.acknowledged is False
        assert response.directive is None


class TestConnectivityMetrics:
    """Tests for ConnectivityMetrics."""

    def test_initial_state(self):
        """Test initial metrics state."""
        metrics = ConnectivityMetrics()

        assert metrics.total_heartbeats == 0
        assert metrics.successful_heartbeats == 0
        assert metrics.failed_heartbeats == 0
        assert metrics.get_success_rate() == 0.0

    def test_record_success(self):
        """Test recording successful heartbeat."""
        metrics = ConnectivityMetrics()

        metrics.record_success(latency_ms=100.0)

        assert metrics.total_heartbeats == 1
        assert metrics.successful_heartbeats == 1
        assert metrics.consecutive_successes == 1
        assert metrics.consecutive_failures == 0
        assert metrics.last_latency_ms == 100.0
        assert metrics.get_success_rate() == 1.0

    def test_record_failure(self):
        """Test recording failed heartbeat."""
        metrics = ConnectivityMetrics()

        metrics.record_failure()

        assert metrics.total_heartbeats == 1
        assert metrics.failed_heartbeats == 1
        assert metrics.consecutive_failures == 1
        assert metrics.consecutive_successes == 0
        assert metrics.get_success_rate() == 0.0

    def test_consecutive_tracking(self):
        """Test consecutive success/failure tracking."""
        metrics = ConnectivityMetrics()

        # 3 successes
        metrics.record_success(100.0)
        metrics.record_success(100.0)
        metrics.record_success(100.0)
        assert metrics.consecutive_successes == 3

        # 1 failure resets successes
        metrics.record_failure()
        assert metrics.consecutive_successes == 0
        assert metrics.consecutive_failures == 1

        # 2 more failures
        metrics.record_failure()
        metrics.record_failure()
        assert metrics.consecutive_failures == 3

        # 1 success resets failures
        metrics.record_success(100.0)
        assert metrics.consecutive_failures == 0
        assert metrics.consecutive_successes == 1

    def test_latency_stats(self):
        """Test latency statistics."""
        metrics = ConnectivityMetrics()

        metrics.record_success(100.0)
        metrics.record_success(200.0)
        metrics.record_success(300.0)

        assert metrics.max_latency_ms == 300.0
        assert metrics.last_latency_ms == 300.0
        # Average uses EMA, so won't be exact arithmetic mean


class TestHeartbeatManager:
    """Tests for HeartbeatManager."""

    @pytest.fixture
    def config(self):
        """Create test config."""
        return HeartbeatConfig(
            orchestrator_url="http://test-orchestrator:8080",
            interval_sec=1.0,
            timeout_sec=1.0,
            missed_threshold=3,
        )

    def test_initial_state(self, config):
        """Test initial manager state."""
        manager = HeartbeatManager(config)

        assert manager.status == ConnectivityStatus.UNKNOWN
        assert not manager.is_connected()
        assert not manager.is_disconnected()

    def test_set_processor_info(self, config):
        """Test setting processor info."""
        manager = HeartbeatManager(config)

        token = FencingToken(
            processor_id="proc-1",
            node_id="edge-1",
            epoch=5,
        )

        manager.set_processor_info(
            processor_id="proc-1",
            node_id="edge-1",
            role=ProcessorRole.PRIMARY,
            fencing_token=token,
        )

        status = manager.get_status_dict()
        assert status["processor_id"] == "proc-1"
        assert status["node_id"] == "edge-1"
        assert status["role"] == "primary"
        assert status["fencing_epoch"] == 5

    def test_update_role(self, config):
        """Test updating processor role."""
        manager = HeartbeatManager(config)
        manager.set_processor_info("proc", "node")

        manager.update_role(ProcessorRole.STANDBY)

        status = manager.get_status_dict()
        assert status["role"] == "standby"

    def test_record_state_sync(self, config):
        """Test recording state sync."""
        manager = HeartbeatManager(config)

        manager.record_state_sync(size_bytes=1024)

        status = manager.get_status_dict()
        assert status["last_state_sync"] is not None

    @pytest.mark.asyncio
    async def test_start_stop(self, config):
        """Test starting and stopping service."""
        manager = HeartbeatManager(config)
        manager.set_processor_info("proc", "node")

        await manager.start()
        assert manager._running is True
        assert manager._session is not None

        await manager.stop()
        assert manager._running is False
        assert manager._session is None

    @pytest.mark.asyncio
    async def test_send_heartbeat_success(self, config):
        """Test successful heartbeat send."""
        manager = HeartbeatManager(config)
        manager.set_processor_info("proc", "node")

        # Create a proper async context manager mock
        mock_response = MagicMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(return_value={
            "acknowledged": True,
            "orchestrator_time": time.time(),
            "directive": "continue",
        })

        # Create context manager that returns the response
        mock_context = AsyncMock()
        mock_context.__aenter__.return_value = mock_response
        mock_context.__aexit__.return_value = None

        mock_session = MagicMock()
        mock_session.post.return_value = mock_context

        manager._session = mock_session

        response = await manager.send_heartbeat()

        assert response is not None
        assert response.acknowledged is True
        assert response.directive == "continue"
        assert manager.metrics.successful_heartbeats == 1

    @pytest.mark.asyncio
    async def test_send_heartbeat_failure(self, config):
        """Test failed heartbeat send."""
        manager = HeartbeatManager(config)
        manager.set_processor_info("proc", "node")

        # Create context manager that raises on enter
        mock_context = AsyncMock()
        mock_context.__aenter__.side_effect = ClientError("Connection refused")

        mock_session = MagicMock()
        mock_session.post.return_value = mock_context

        manager._session = mock_session

        response = await manager.send_heartbeat()

        assert response is None
        assert manager.metrics.failed_heartbeats == 1
        assert manager.metrics.consecutive_failures == 1

    @pytest.mark.asyncio
    async def test_connectivity_status_transitions(self, config):
        """Test connectivity status transitions."""
        manager = HeartbeatManager(config)
        manager.set_processor_info("proc", "node")

        # Simulate connected state
        manager._metrics.record_success(100.0)
        await manager._update_status(100.0)
        assert manager.status == ConnectivityStatus.CONNECTED

        # Simulate high latency (degraded)
        await manager._update_status(1000.0)  # > 500ms threshold
        assert manager.status == ConnectivityStatus.DEGRADED

        # Simulate failures (disconnected after threshold)
        for _ in range(config.missed_threshold):
            manager._metrics.record_failure()
            await manager._update_status(None)

        assert manager.status == ConnectivityStatus.DISCONNECTED

    @pytest.mark.asyncio
    async def test_connectivity_callback(self, config):
        """Test connectivity change callback."""
        manager = HeartbeatManager(config)
        manager.set_processor_info("proc", "node")

        status_changes = []

        async def on_change(old: ConnectivityStatus, new: ConnectivityStatus):
            status_changes.append((old, new))

        manager.add_connectivity_callback(on_change)

        # Trigger status change
        manager._metrics.record_success(100.0)
        await manager._update_status(100.0)

        assert len(status_changes) == 1
        assert status_changes[0] == (ConnectivityStatus.UNKNOWN, ConnectivityStatus.CONNECTED)

    def test_should_demote(self, config):
        """Test should_demote logic."""
        manager = HeartbeatManager(config)

        # Not disconnected - should not demote
        manager._status = ConnectivityStatus.CONNECTED
        assert manager.should_demote() is False

        # Disconnected but no time tracked
        manager._status = ConnectivityStatus.DISCONNECTED
        manager._disconnect_time = None
        assert manager.should_demote() is False

        # Disconnected but within grace period
        manager._disconnect_time = time.time()
        assert manager.should_demote() is False

        # Disconnected and past grace period
        manager._disconnect_time = time.time() - config.demote_grace_period_sec - 1
        assert manager.should_demote() is True


class TestEdgeHealthReporter:
    """Tests for EdgeHealthReporter."""

    @pytest.fixture
    def mock_heartbeat(self):
        """Create mock heartbeat manager."""
        mock = MagicMock()
        mock.status = ConnectivityStatus.CONNECTED
        mock.is_connected.return_value = True
        mock.metrics = ConnectivityMetrics()
        mock.metrics.record_success(100.0)
        return mock

    @pytest.fixture
    def mock_role_manager(self):
        """Create mock role manager."""
        mock = MagicMock()
        mock.role = ProcessorRole.PRIMARY
        mock.can_process.return_value = True
        mock.fencing_token = FencingToken(
            processor_id="proc",
            node_id="node",
            epoch=5,
        )
        return mock

    def test_get_health_status(self, mock_heartbeat, mock_role_manager):
        """Test health status reporting."""
        reporter = EdgeHealthReporter(
            heartbeat_manager=mock_heartbeat,
            role_manager=mock_role_manager,
        )

        status = reporter.get_health_status()

        assert status["is_edge"] is True
        assert status["connectivity"] == "connected"
        assert status["is_connected"] is True
        assert status["role"] == "primary"
        assert status["can_process"] is True
        assert status["fencing_epoch"] == 5
        assert "heartbeat" in status

    @pytest.mark.asyncio
    async def test_check_health_connected(self, mock_heartbeat, mock_role_manager):
        """Test health check when connected."""
        reporter = EdgeHealthReporter(
            heartbeat_manager=mock_heartbeat,
            role_manager=mock_role_manager,
        )

        status, message = await reporter.check_health()

        assert status == "healthy"
        assert "Connected" in message

    @pytest.mark.asyncio
    async def test_check_health_degraded(self, mock_heartbeat, mock_role_manager):
        """Test health check when degraded."""
        mock_heartbeat.status = ConnectivityStatus.DEGRADED

        reporter = EdgeHealthReporter(
            heartbeat_manager=mock_heartbeat,
            role_manager=mock_role_manager,
        )

        status, message = await reporter.check_health()

        assert status == "degraded"
        assert "Degraded" in message

    @pytest.mark.asyncio
    async def test_check_health_disconnected(self, mock_heartbeat, mock_role_manager):
        """Test health check when disconnected."""
        mock_heartbeat.status = ConnectivityStatus.DISCONNECTED

        reporter = EdgeHealthReporter(
            heartbeat_manager=mock_heartbeat,
            role_manager=mock_role_manager,
        )

        status, message = await reporter.check_health()

        assert status == "unhealthy"
        assert "Disconnected" in message


class TestHeartbeatIntegration:
    """Integration tests for heartbeat with role management."""

    @pytest.mark.asyncio
    async def test_heartbeat_role_integration(self):
        """Test heartbeat updates with role changes."""
        config = HeartbeatConfig(
            orchestrator_url="http://test:8080",
            interval_sec=1.0,
        )
        manager = HeartbeatManager(config)

        # Set initial info
        manager.set_processor_info(
            processor_id="proc-1",
            node_id="edge-1",
            role=ProcessorRole.PRIMARY,
        )

        # Update role
        manager.update_role(ProcessorRole.DRAINING)

        status = manager.get_status_dict()
        assert status["role"] == "draining"

    @pytest.mark.asyncio
    async def test_heartbeat_fencing_integration(self):
        """Test heartbeat updates with fencing token."""
        config = HeartbeatConfig(
            orchestrator_url="http://test:8080",
            interval_sec=1.0,
        )
        manager = HeartbeatManager(config)

        manager.set_processor_info(
            processor_id="proc-1",
            node_id="edge-1",
        )

        # Update fencing token
        token = FencingToken(
            processor_id="proc-1",
            node_id="edge-1",
            epoch=10,
        )
        manager.update_fencing_token(token)

        status = manager.get_status_dict()
        assert status["fencing_epoch"] == 10

    @pytest.mark.asyncio
    async def test_connectivity_change_triggers_callback(self):
        """Test that connectivity changes trigger callbacks."""
        config = HeartbeatConfig(
            orchestrator_url="http://test:8080",
            interval_sec=1.0,
            missed_threshold=2,
        )
        manager = HeartbeatManager(config)
        manager.set_processor_info("proc", "node")

        demote_triggered = []

        async def on_disconnect(old: ConnectivityStatus, new: ConnectivityStatus):
            if new == ConnectivityStatus.DISCONNECTED:
                demote_triggered.append(True)

        manager.add_connectivity_callback(on_disconnect)

        # Simulate going connected first
        manager._metrics.record_success(100.0)
        await manager._update_status(100.0)

        # Simulate disconnect (2 failures = threshold)
        manager._metrics.record_failure()
        await manager._update_status(None)
        manager._metrics.record_failure()
        await manager._update_status(None)

        assert len(demote_triggered) == 1
        assert manager.status == ConnectivityStatus.DISCONNECTED
