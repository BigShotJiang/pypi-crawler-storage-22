"""Tests for Kubernetes label contract."""

import pytest
from unittest.mock import patch

from dory.k8s.labels import (
    # Label keys
    LABEL_MANAGED_BY,
    LABEL_APP_NAME,
    LABEL_PROCESSOR_ID,
    LABEL_WORKLOAD_LOCATION,
    LABEL_MIGRATED_FROM_EDGE,
    LABEL_ORIGINAL_NODE,
    LABEL_NODE_TYPE,
    LABEL_WORKLOAD_TYPE,
    # Label values
    VALUE_ORCHESTRATOR_NAME,
    VALUE_EDGE,
    VALUE_MANAGED,
    VALUE_APPLICATION,
    # Enums
    WorkloadLocation,
    NodeType,
    # Builder
    DoryLabels,
    # Utilities
    get_label,
    get_app_name,
    get_processor_id,
    get_workload_location,
    is_managed_by_dory,
    is_edge_workload,
    is_migrated_from_edge,
    get_original_node,
    detect_workload_context,
    edge_node_selector,
    managed_node_selector,
    edge_toleration,
    get_contract_documentation,
    CONTRACT_VERSION,
)


class TestLabelConstants:
    """Tests for label constants matching Orchestrator."""

    def test_identity_labels(self):
        """Test identity label keys."""
        assert LABEL_MANAGED_BY == "managed-by"
        assert LABEL_APP_NAME == "app"
        assert LABEL_PROCESSOR_ID == "processor-id"

    def test_workload_labels(self):
        """Test workload label keys."""
        assert LABEL_WORKLOAD_TYPE == "workload-type"
        assert LABEL_WORKLOAD_LOCATION == "workload-location"
        assert LABEL_NODE_TYPE == "node-type"

    def test_migration_labels(self):
        """Test migration label keys."""
        assert LABEL_MIGRATED_FROM_EDGE == "migrated-from-edge"
        assert LABEL_ORIGINAL_NODE == "original-edge-node"

    def test_label_values(self):
        """Test label values match Orchestrator."""
        assert VALUE_ORCHESTRATOR_NAME == "dory-orchestrator"
        assert VALUE_EDGE == "edge"
        assert VALUE_MANAGED == "managed"
        assert VALUE_APPLICATION == "application"


class TestWorkloadLocation:
    """Tests for WorkloadLocation enum."""

    def test_edge_value(self):
        """Test edge workload location."""
        assert WorkloadLocation.EDGE.value == "edge"

    def test_managed_value(self):
        """Test managed workload location."""
        assert WorkloadLocation.MANAGED.value == "managed"


class TestNodeType:
    """Tests for NodeType enum."""

    def test_node_types(self):
        """Test node type values."""
        assert NodeType.EDGE.value == "edge"
        assert NodeType.SYSTEM.value == "system"
        assert NodeType.APPLICATION.value == "application"


class TestDoryLabels:
    """Tests for DoryLabels builder."""

    def test_basic_labels(self):
        """Test basic label creation."""
        labels = DoryLabels(
            app_name="my-app",
            processor_id="proc-123",
        )

        result = labels.to_dict()

        assert result[LABEL_MANAGED_BY] == VALUE_ORCHESTRATOR_NAME
        assert result[LABEL_APP_NAME] == "my-app"
        assert result[LABEL_PROCESSOR_ID] == "proc-123"
        assert result[LABEL_WORKLOAD_LOCATION] == VALUE_MANAGED

    def test_edge_workload(self):
        """Test edge workload labels."""
        labels = DoryLabels(
            app_name="edge-app",
            workload_location=WorkloadLocation.EDGE,
        )

        result = labels.to_dict()

        assert result[LABEL_WORKLOAD_LOCATION] == VALUE_EDGE
        assert labels.is_edge_workload() is True

    def test_migrated_labels(self):
        """Test migrated pod labels."""
        labels = DoryLabels(
            app_name="my-app",
            workload_location=WorkloadLocation.EDGE,
            migrated_from_edge=True,
            original_node="edge-node-1",
        )

        result = labels.to_dict()

        assert result[LABEL_MIGRATED_FROM_EDGE] == "true"
        assert result[LABEL_ORIGINAL_NODE] == "edge-node-1"
        assert labels.is_migrated() is True

    def test_custom_labels(self):
        """Test custom labels."""
        labels = DoryLabels(
            app_name="my-app",
            custom_labels={"team": "backend", "env": "prod"},
        )

        result = labels.to_dict()

        assert result["team"] == "backend"
        assert result["env"] == "prod"

    def test_from_dict(self):
        """Test creating from existing labels."""
        existing = {
            LABEL_MANAGED_BY: VALUE_ORCHESTRATOR_NAME,
            LABEL_APP_NAME: "restored-app",
            LABEL_PROCESSOR_ID: "proc-456",
            LABEL_WORKLOAD_LOCATION: VALUE_EDGE,
            LABEL_MIGRATED_FROM_EDGE: "true",
            LABEL_ORIGINAL_NODE: "edge-1",
        }

        labels = DoryLabels.from_dict(existing)

        assert labels.app_name == "restored-app"
        assert labels.processor_id == "proc-456"
        assert labels.workload_location == WorkloadLocation.EDGE
        assert labels.migrated_from_edge is True
        assert labels.original_node == "edge-1"

    def test_roundtrip(self):
        """Test labels survive roundtrip."""
        original = DoryLabels(
            app_name="test-app",
            processor_id="p-123",
            workload_location=WorkloadLocation.EDGE,
            migrated_from_edge=True,
            original_node="node-1",
        )

        dict_form = original.to_dict()
        restored = DoryLabels.from_dict(dict_form)

        assert restored.app_name == original.app_name
        assert restored.processor_id == original.processor_id
        assert restored.workload_location == original.workload_location
        assert restored.migrated_from_edge == original.migrated_from_edge
        assert restored.original_node == original.original_node


class TestLabelUtilities:
    """Tests for label utility functions."""

    def test_get_label(self):
        """Test get_label function."""
        labels = {"app": "test", "team": "backend"}

        assert get_label(labels, "app") == "test"
        assert get_label(labels, "missing") == ""
        assert get_label(labels, "missing", "default") == "default"
        assert get_label(None, "app") == ""

    def test_get_app_name(self):
        """Test get_app_name function."""
        labels = {LABEL_APP_NAME: "my-app"}
        assert get_app_name(labels) == "my-app"
        assert get_app_name(None) == ""

    def test_get_processor_id(self):
        """Test get_processor_id function."""
        labels = {LABEL_PROCESSOR_ID: "proc-123"}
        assert get_processor_id(labels) == "proc-123"
        assert get_processor_id({}) == ""

    def test_get_workload_location(self):
        """Test get_workload_location function."""
        assert get_workload_location({LABEL_WORKLOAD_LOCATION: "edge"}) == WorkloadLocation.EDGE
        assert get_workload_location({LABEL_WORKLOAD_LOCATION: "managed"}) == WorkloadLocation.MANAGED
        assert get_workload_location({LABEL_WORKLOAD_LOCATION: "unknown"}) is None
        assert get_workload_location({}) is None

    def test_is_managed_by_dory(self):
        """Test is_managed_by_dory function."""
        assert is_managed_by_dory({LABEL_MANAGED_BY: VALUE_ORCHESTRATOR_NAME}) is True
        assert is_managed_by_dory({LABEL_MANAGED_BY: "other"}) is False
        assert is_managed_by_dory({}) is False
        assert is_managed_by_dory(None) is False

    def test_is_edge_workload(self):
        """Test is_edge_workload function."""
        assert is_edge_workload({LABEL_WORKLOAD_LOCATION: VALUE_EDGE}) is True
        assert is_edge_workload({LABEL_WORKLOAD_LOCATION: VALUE_MANAGED}) is False
        assert is_edge_workload({}) is False

    def test_is_migrated_from_edge(self):
        """Test is_migrated_from_edge function."""
        assert is_migrated_from_edge({LABEL_MIGRATED_FROM_EDGE: "true"}) is True
        assert is_migrated_from_edge({LABEL_MIGRATED_FROM_EDGE: "false"}) is False
        assert is_migrated_from_edge({}) is False

    def test_get_original_node(self):
        """Test get_original_node function."""
        labels = {LABEL_ORIGINAL_NODE: "edge-node-1"}
        assert get_original_node(labels) == "edge-node-1"
        assert get_original_node({}) == ""


class TestNodeSelectors:
    """Tests for node selector builders."""

    def test_edge_node_selector(self):
        """Test edge node selector."""
        selector = edge_node_selector()
        assert selector == {LABEL_NODE_TYPE: "edge"}

    def test_managed_node_selector(self):
        """Test managed node selector."""
        selector = managed_node_selector()
        assert selector == {LABEL_WORKLOAD_TYPE: VALUE_APPLICATION}

    def test_edge_toleration(self):
        """Test edge toleration."""
        toleration = edge_toleration()

        assert toleration["key"] == "edge-node"
        assert toleration["operator"] == "Equal"
        assert toleration["value"] == "true"
        assert toleration["effect"] == "NoSchedule"


class TestEnvironmentDetection:
    """Tests for environment-based detection."""

    def test_detect_workload_context_empty(self):
        """Test context detection with no env vars."""
        with patch.dict("os.environ", {}, clear=True):
            context = detect_workload_context()

            assert context["pod_name"] is None
            assert context["is_kubernetes"] is False
            assert context["is_edge"] is False

    def test_detect_workload_context_kubernetes(self):
        """Test context detection in Kubernetes."""
        env = {
            "POD_NAME": "my-pod-123",
            "POD_NAMESPACE": "default",
            "POD_IP": "10.0.0.1",
            "NODE_NAME": "node-1",
            "DORY_APP_NAME": "my-app",
            "DORY_PROCESSOR_ID": "proc-123",
            "DORY_WORKLOAD_LOCATION": "edge",
        }

        with patch.dict("os.environ", env, clear=True):
            context = detect_workload_context()

            assert context["pod_name"] == "my-pod-123"
            assert context["pod_namespace"] == "default"
            assert context["node_name"] == "node-1"
            assert context["app_name"] == "my-app"
            assert context["workload_location"] == WorkloadLocation.EDGE
            assert context["is_kubernetes"] is True
            assert context["is_edge"] is True

    def test_detect_workload_context_managed(self):
        """Test context detection for managed workload."""
        env = {
            "POD_NAME": "my-pod",
            "POD_NAMESPACE": "prod",
            "DORY_WORKLOAD_LOCATION": "managed",
        }

        with patch.dict("os.environ", env, clear=True):
            context = detect_workload_context()

            assert context["workload_location"] == WorkloadLocation.MANAGED
            assert context["is_edge"] is False


class TestContractDocumentation:
    """Tests for contract documentation."""

    def test_contract_version(self):
        """Test contract version is defined."""
        assert CONTRACT_VERSION == "1.0"

    def test_get_contract_documentation(self):
        """Test documentation is available."""
        docs = get_contract_documentation()

        assert "Label Contract" in docs
        assert "managed-by" in docs
        assert "workload-location" in docs
        assert "edge" in docs
        assert "Orchestrator" in docs


class TestOrchestratorCompatibility:
    """Tests verifying compatibility with Orchestrator constants."""

    def test_label_keys_match_orchestrator(self):
        """Test that SDK label keys match Orchestrator's k8s.go.

        These values MUST match the Go constants in:
        orchestrator/orchestrator/pkg/utils/k8s.go
        """
        # From orchestrator/pkg/utils/k8s.go
        expected_labels = {
            "LabelManagedBy": "managed-by",
            "LabelAppName": "app",
            "LabelProcessorID": "processor-id",
            "LabelWorkloadType": "workload-type",
            "LabelWorkloadLocation": "workload-location",
            "LabelNodeType": "node-type",
            "LabelMigratedFromEdge": "migrated-from-edge",
            "LabelOriginalNode": "original-edge-node",
        }

        assert LABEL_MANAGED_BY == expected_labels["LabelManagedBy"]
        assert LABEL_APP_NAME == expected_labels["LabelAppName"]
        assert LABEL_PROCESSOR_ID == expected_labels["LabelProcessorID"]
        assert LABEL_WORKLOAD_TYPE == expected_labels["LabelWorkloadType"]
        assert LABEL_WORKLOAD_LOCATION == expected_labels["LabelWorkloadLocation"]
        assert LABEL_NODE_TYPE == expected_labels["LabelNodeType"]
        assert LABEL_MIGRATED_FROM_EDGE == expected_labels["LabelMigratedFromEdge"]
        assert LABEL_ORIGINAL_NODE == expected_labels["LabelOriginalNode"]

    def test_label_values_match_orchestrator(self):
        """Test that SDK label values match Orchestrator's k8s.go."""
        # From orchestrator/pkg/utils/k8s.go
        assert VALUE_ORCHESTRATOR_NAME == "dory-orchestrator"
        assert VALUE_EDGE == "edge"
        assert VALUE_MANAGED == "managed"
        assert VALUE_APPLICATION == "application"

    def test_selectors_match_orchestrator(self):
        """Test that selectors match Orchestrator's k8s.go."""
        # From orchestrator/pkg/utils/k8s.go
        from dory.k8s.labels import (
            SELECTOR_EDGE_NODES,
            SELECTOR_MANAGED_NODES,
            SELECTOR_MANAGED_PODS,
        )

        assert SELECTOR_EDGE_NODES == "node-type=edge"
        assert SELECTOR_MANAGED_NODES == "workload-type=application"
        assert SELECTOR_MANAGED_PODS == "managed-by=dory-orchestrator"


class TestMigrationScenarios:
    """Tests for migration label scenarios."""

    def test_edge_pod_labels(self):
        """Test labels for pod running on edge."""
        labels = DoryLabels(
            app_name="edge-processor",
            processor_id="ep-001",
            workload_location=WorkloadLocation.EDGE,
        ).to_dict()

        assert is_managed_by_dory(labels)
        assert is_edge_workload(labels)
        assert not is_migrated_from_edge(labels)

    def test_failover_pod_labels(self):
        """Test labels after failover from edge to managed."""
        # Original edge labels
        original = DoryLabels(
            app_name="edge-processor",
            processor_id="ep-001",
            workload_location=WorkloadLocation.EDGE,
        )

        # After failover (Orchestrator adds migration labels)
        failover_labels = DoryLabels(
            app_name=original.app_name,
            processor_id=original.processor_id,
            workload_location=WorkloadLocation.EDGE,  # preserved
            migrated_from_edge=True,  # added
            original_node="edge-node-1",  # added
        ).to_dict()

        assert is_managed_by_dory(failover_labels)
        assert is_edge_workload(failover_labels)  # workload type preserved
        assert is_migrated_from_edge(failover_labels)
        assert get_original_node(failover_labels) == "edge-node-1"

    def test_failback_pod_labels(self):
        """Test labels after failback to edge."""
        # After failback, migration labels are removed
        failback_labels = DoryLabels(
            app_name="edge-processor",
            processor_id="ep-001",
            workload_location=WorkloadLocation.EDGE,
            # No migration labels
        ).to_dict()

        assert is_edge_workload(failback_labels)
        assert not is_migrated_from_edge(failback_labels)
        assert get_original_node(failback_labels) == ""
