"""Tests for S3 state storage backend."""

import json
import os
import pytest
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch, AsyncMock

from dory.migration.s3_store import S3Store, S3Config, OfflineBuffer
from dory.utils.errors import DoryStateError

# Create mock ClientError for tests
class MockClientError(Exception):
    """Mock ClientError for testing without botocore."""
    def __init__(self, error_response, operation_name):
        self.response = error_response
        self.operation_name = operation_name
        super().__init__(f"{operation_name}: {error_response}")


class TestS3Config:
    """Tests for S3Config."""

    def test_from_env_requires_bucket(self, monkeypatch):
        """Test that DORY_S3_BUCKET is required."""
        monkeypatch.delenv("DORY_S3_BUCKET", raising=False)

        with pytest.raises(DoryStateError) as exc_info:
            S3Config.from_env()

        assert "DORY_S3_BUCKET" in str(exc_info.value)

    def test_from_env_with_bucket(self, monkeypatch):
        """Test config from environment with just bucket."""
        monkeypatch.setenv("DORY_S3_BUCKET", "my-bucket")
        monkeypatch.delenv("DORY_S3_PREFIX", raising=False)
        monkeypatch.delenv("DORY_S3_REGION", raising=False)

        config = S3Config.from_env()

        assert config.bucket == "my-bucket"
        assert config.prefix == "dory-state"  # default

    def test_from_env_with_all_options(self, monkeypatch):
        """Test config from environment with all options."""
        monkeypatch.setenv("DORY_S3_BUCKET", "my-bucket")
        monkeypatch.setenv("DORY_S3_PREFIX", "custom-prefix")
        monkeypatch.setenv("DORY_S3_REGION", "us-west-2")
        monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIATEST")
        monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "secret123")
        monkeypatch.setenv("DORY_S3_ROLE_ARN", "arn:aws:iam::123456789:role/test")

        config = S3Config.from_env()

        assert config.bucket == "my-bucket"
        assert config.prefix == "custom-prefix"
        assert config.region == "us-west-2"
        assert config.access_key_id == "AKIATEST"
        assert config.secret_access_key == "secret123"
        assert config.role_arn == "arn:aws:iam::123456789:role/test"

    def test_default_values(self):
        """Test default config values."""
        config = S3Config(bucket="test-bucket")

        assert config.prefix == "dory-state"
        assert config.enable_offline_buffer is True
        assert config.max_retries == 3
        assert config.retry_delay_seconds == 1.0


class TestOfflineBuffer:
    """Tests for OfflineBuffer."""

    @pytest.fixture
    def temp_db(self):
        """Create a temporary database file."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            yield f.name
        # Cleanup
        Path(f.name).unlink(missing_ok=True)

    def test_save_and_load(self, temp_db):
        """Test saving and loading state."""
        buffer = OfflineBuffer(temp_db, temp_db)

        state_json = '{"counter": 42}'
        buffer.save("processor-1", state_json)

        loaded = buffer.load("processor-1")
        assert loaded == state_json

        buffer.close()

    def test_load_nonexistent(self, temp_db):
        """Test loading nonexistent state returns None."""
        buffer = OfflineBuffer(temp_db, temp_db)

        loaded = buffer.load("nonexistent")
        assert loaded is None

        buffer.close()

    def test_mark_synced(self, temp_db):
        """Test marking state as synced."""
        buffer = OfflineBuffer(temp_db, temp_db)

        buffer.save("processor-1", '{"test": true}')

        # Should be in unsynced list
        unsynced = buffer.get_unsynced()
        assert len(unsynced) == 1
        assert unsynced[0][0] == "processor-1"

        # Mark as synced
        buffer.mark_synced("processor-1")

        # Should no longer be in unsynced list
        unsynced = buffer.get_unsynced()
        assert len(unsynced) == 0

        buffer.close()

    def test_delete(self, temp_db):
        """Test deleting state."""
        buffer = OfflineBuffer(temp_db, temp_db)

        buffer.save("processor-1", '{"test": true}')
        assert buffer.load("processor-1") is not None

        deleted = buffer.delete("processor-1")
        assert deleted is True

        assert buffer.load("processor-1") is None

        # Delete nonexistent
        deleted = buffer.delete("processor-1")
        assert deleted is False

        buffer.close()

    def test_get_unsynced_order(self, temp_db):
        """Test unsynced states are returned in order."""
        buffer = OfflineBuffer(temp_db, temp_db)

        buffer.save("processor-1", '{"order": 1}')
        buffer.save("processor-2", '{"order": 2}')
        buffer.save("processor-3", '{"order": 3}')

        unsynced = buffer.get_unsynced()
        assert len(unsynced) == 3
        assert unsynced[0][0] == "processor-1"
        assert unsynced[1][0] == "processor-2"
        assert unsynced[2][0] == "processor-3"

        buffer.close()

    def test_fallback_path(self, tmp_path):
        """Test fallback path is used when primary is not writable."""
        # Use non-existent primary path
        primary = "/nonexistent/path/buffer.db"
        fallback = str(tmp_path / "fallback.db")

        buffer = OfflineBuffer(primary, fallback)
        buffer.save("test", '{"data": true}')

        # Should use fallback
        assert buffer._db_path == fallback
        assert buffer.load("test") == '{"data": true}'

        buffer.close()


class TestS3Store:
    """Tests for S3Store."""

    @pytest.fixture
    def mock_boto3(self):
        """Mock boto3 for testing without AWS."""
        with patch("dory.migration.s3_store.BOTO3_AVAILABLE", True):
            with patch("dory.migration.s3_store.boto3") as mock:
                # Setup mock session and client
                mock_client = MagicMock()
                mock_session = MagicMock()
                mock_session.client.return_value = mock_client
                mock.Session.return_value = mock_session

                yield mock, mock_client

    @pytest.fixture
    def s3_config(self, tmp_path):
        """Create test S3 config."""
        return S3Config(
            bucket="test-bucket",
            prefix="test-prefix",
            region="us-east-1",
            access_key_id="AKIATEST",
            secret_access_key="secret123",
            enable_offline_buffer=True,
            buffer_path=str(tmp_path / "buffer.db"),
            buffer_path_fallback=str(tmp_path / "buffer-fallback.db"),
        )

    def test_s3_key_format(self, mock_boto3, s3_config):
        """Test S3 key format."""
        mock, client = mock_boto3
        store = S3Store(config=s3_config)
        store._ensure_initialized()

        key = store._s3_key("my-processor")
        assert key == "test-prefix/my-processor/state.json"

    @pytest.mark.asyncio
    async def test_save_success(self, mock_boto3, s3_config):
        """Test successful save to S3."""
        mock, client = mock_boto3
        store = S3Store(config=s3_config)

        await store.save("processor-1", '{"counter": 42}')

        # Verify put_object was called
        client.put_object.assert_called_once()
        call_kwargs = client.put_object.call_args[1]
        assert call_kwargs["Bucket"] == "test-bucket"
        assert call_kwargs["Key"] == "test-prefix/processor-1/state.json"
        assert call_kwargs["Body"] == b'{"counter": 42}'

    @pytest.mark.asyncio
    async def test_save_with_buffer_on_failure(self, mock_boto3, s3_config):
        """Test save falls back to buffer on S3 failure."""
        mock, client = mock_boto3

        # Make S3 fail
        client.put_object.side_effect = MockClientError(
            {"Error": {"Code": "ServiceUnavailable"}},
            "PutObject"
        )

        store = S3Store(config=s3_config)

        # Should not raise - buffers locally
        await store.save("processor-1", '{"counter": 42}')

        # Verify buffered locally
        assert store._buffer.load("processor-1") == '{"counter": 42}'

    @pytest.mark.asyncio
    async def test_load_success(self, mock_boto3, s3_config):
        """Test successful load from S3."""
        mock, client = mock_boto3

        # Mock response
        mock_body = MagicMock()
        mock_body.read.return_value = b'{"counter": 42}'
        client.get_object.return_value = {"Body": mock_body}

        store = S3Store(config=s3_config)
        result = await store.load("processor-1")

        assert result == '{"counter": 42}'

    @pytest.mark.asyncio
    async def test_load_not_found(self, mock_boto3, s3_config):
        """Test load returns None when not found."""
        mock, client = mock_boto3

        client.get_object.side_effect = MockClientError(
            {"Error": {"Code": "NoSuchKey"}},
            "GetObject"
        )

        store = S3Store(config=s3_config)
        result = await store.load("nonexistent")

        assert result is None

    @pytest.mark.asyncio
    async def test_load_from_buffer_on_failure(self, mock_boto3, s3_config):
        """Test load falls back to buffer on S3 failure."""
        mock, client = mock_boto3

        client.get_object.side_effect = MockClientError(
            {"Error": {"Code": "ServiceUnavailable"}},
            "GetObject"
        )

        store = S3Store(config=s3_config)

        # Pre-populate buffer
        store._buffer.save("processor-1", '{"buffered": true}')

        result = await store.load("processor-1")
        assert result == '{"buffered": true}'

    @pytest.mark.asyncio
    async def test_delete_success(self, mock_boto3, s3_config):
        """Test successful delete from S3."""
        mock, client = mock_boto3

        store = S3Store(config=s3_config)
        result = await store.delete("processor-1")

        assert result is True
        client.delete_object.assert_called_once()

    @pytest.mark.asyncio
    async def test_sync_buffer(self, mock_boto3, s3_config):
        """Test syncing buffered states to S3."""
        mock, client = mock_boto3

        store = S3Store(config=s3_config)
        # Initialize the client
        store._ensure_initialized()

        # Buffer some states
        store._buffer.save("processor-1", '{"data": 1}')
        store._buffer.save("processor-2", '{"data": 2}')

        # Sync
        synced = await store.sync_buffer()

        assert synced == 2
        assert client.put_object.call_count == 2

        # Should be marked as synced
        assert len(store._buffer.get_unsynced()) == 0

    def test_no_boto3_raises_error(self):
        """Test that missing boto3 raises appropriate error."""
        with patch("dory.migration.s3_store.BOTO3_AVAILABLE", False):
            with pytest.raises(DoryStateError) as exc_info:
                S3Store(config=S3Config(bucket="test"))

            assert "boto3" in str(exc_info.value)


class TestStateManagerS3Integration:
    """Tests for StateManager with S3 backend."""

    @pytest.fixture
    def mock_s3_store(self):
        """Mock S3Store for StateManager tests."""
        with patch("dory.migration.state_manager.S3Store") as mock_cls:
            mock_store = MagicMock()
            mock_store.save = AsyncMock()
            mock_store.load = AsyncMock(return_value=None)
            mock_store.delete = AsyncMock(return_value=True)
            mock_store.sync_buffer = AsyncMock(return_value=0)
            mock_cls.return_value = mock_store
            yield mock_store

    @pytest.mark.asyncio
    async def test_save_to_s3(self, mock_s3_store):
        """Test saving state via StateManager to S3."""
        from dory.migration.state_manager import StateManager
        from dory.types import StateBackend

        manager = StateManager(backend=StateBackend.S3)
        await manager.save_state("processor-1", {"counter": 42})

        mock_s3_store.save.assert_called_once()
        call_args = mock_s3_store.save.call_args
        assert call_args[0][0] == "processor-1"
        # state_json is serialized
        assert "counter" in call_args[0][1]

    @pytest.mark.asyncio
    async def test_load_from_s3(self, mock_s3_store):
        """Test loading state via StateManager from S3."""
        from dory.migration.state_manager import StateManager
        from dory.migration.serialization import StateSerializer
        from dory.types import StateBackend

        # Use the actual serializer to create properly formatted state
        serializer = StateSerializer()
        serialized_state = serializer.serialize(
            state={"counter": 42},
            processor_id="processor-1",
            pod_name="test-pod",
            restart_count=0,
        )

        mock_s3_store.load.return_value = serialized_state

        manager = StateManager(backend=StateBackend.S3)
        state = await manager.load_state("processor-1")

        mock_s3_store.load.assert_called_once_with("processor-1")
        assert state == {"counter": 42}

    @pytest.mark.asyncio
    async def test_delete_from_s3(self, mock_s3_store):
        """Test deleting state via StateManager from S3."""
        from dory.migration.state_manager import StateManager
        from dory.types import StateBackend

        manager = StateManager(backend=StateBackend.S3)
        result = await manager.delete_state("processor-1")

        mock_s3_store.delete.assert_called_once_with("processor-1")
        assert result is True

    @pytest.mark.asyncio
    async def test_sync_buffer(self, mock_s3_store):
        """Test syncing S3 buffer via StateManager."""
        from dory.migration.state_manager import StateManager
        from dory.types import StateBackend

        mock_s3_store.sync_buffer.return_value = 5

        manager = StateManager(backend=StateBackend.S3)
        synced = await manager.sync_s3_buffer()

        assert synced == 5
        mock_s3_store.sync_buffer.assert_called_once()
