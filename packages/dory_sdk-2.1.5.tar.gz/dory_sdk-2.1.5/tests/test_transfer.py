"""Tests for state transfer timeout and size validation."""

import pytest
import time
from unittest.mock import MagicMock, patch, AsyncMock

from dory.migration.transfer import (
    TransferConfig,
    TransferMetrics,
    validate_state_size,
    StateSizeExceeded,
    StateTransferTimeout,
    StateCaptureGuard,
    with_timeout,
    async_with_timeout,
    ORCHESTRATOR_STATE_TIMEOUT_SEC,
    ORCHESTRATOR_MAX_STATE_SIZE,
)


class TestTransferConfig:
    """Tests for TransferConfig."""

    def test_default_values(self):
        """Test default configuration values."""
        config = TransferConfig()

        assert config.capture_timeout_sec == 25  # 5s buffer before Orchestrator's 30s
        assert config.restore_timeout_sec == 25
        assert config.max_size_bytes == 8 * 1024 * 1024  # 8MB
        assert config.size_warn_threshold == 0.75

    def test_validates_against_orchestrator_limits(self):
        """Test that config validates against Orchestrator limits."""
        # Timeout too high - should be reduced
        config = TransferConfig(capture_timeout_sec=35)
        assert config.capture_timeout_sec == ORCHESTRATOR_STATE_TIMEOUT_SEC - 5

        # Size too high - should be reduced
        config = TransferConfig(max_size_bytes=15 * 1024 * 1024)
        assert config.max_size_bytes == ORCHESTRATOR_MAX_STATE_SIZE

    def test_custom_values(self):
        """Test custom configuration values."""
        config = TransferConfig(
            capture_timeout_sec=15,
            restore_timeout_sec=20,
            max_size_bytes=5 * 1024 * 1024,
            size_warn_threshold=0.5,
        )

        assert config.capture_timeout_sec == 15
        assert config.restore_timeout_sec == 20
        assert config.max_size_bytes == 5 * 1024 * 1024
        assert config.size_warn_threshold == 0.5


class TestValidateStateSize:
    """Tests for validate_state_size function."""

    def test_small_state_passes(self):
        """Test that small state passes validation."""
        state_json = '{"counter": 42}'
        metrics = validate_state_size(state_json, max_size=1024)

        assert metrics.size_bytes == len(state_json.encode("utf-8"))
        assert metrics.size_exceeded is False
        assert metrics.timed_out is False

    def test_large_state_raises(self):
        """Test that state exceeding max size raises error."""
        state_json = "x" * 1000  # 1000 bytes

        with pytest.raises(StateSizeExceeded) as exc_info:
            validate_state_size(state_json, max_size=500)

        assert exc_info.value.metrics.size_exceeded is True
        assert exc_info.value.metrics.size_bytes == 1000

    def test_warning_threshold(self, caplog):
        """Test that warning is logged at threshold."""
        import logging
        caplog.set_level(logging.WARNING)

        state_json = "x" * 800  # 800 bytes
        metrics = validate_state_size(
            state_json,
            max_size=1000,
            warn_threshold=0.75,  # 750 bytes
        )

        assert metrics.size_ratio == 0.8
        assert "State size" in caplog.text
        assert "80.0%" in caplog.text

    def test_unicode_size(self):
        """Test that unicode characters are counted correctly."""
        # Unicode characters take more bytes
        state_json = '{"emoji": "🎉🎉🎉"}'
        metrics = validate_state_size(state_json, max_size=1024)

        # Each emoji is 4 bytes in UTF-8
        assert metrics.size_bytes == len(state_json.encode("utf-8"))


class TestWithTimeout:
    """Tests for with_timeout decorator."""

    def test_fast_function_succeeds(self):
        """Test that fast function completes within timeout."""
        @with_timeout(timeout_sec=1.0, operation_name="test")
        def fast_func():
            return "result"

        result = fast_func()
        assert result == "result"

    def test_slow_function_times_out(self):
        """Test that slow function times out."""
        @with_timeout(timeout_sec=0.1, operation_name="slow_test")
        def slow_func():
            time.sleep(1.0)
            return "result"

        with pytest.raises(StateTransferTimeout) as exc_info:
            slow_func()

        assert exc_info.value.metrics.timed_out is True
        assert "timed out" in str(exc_info.value)


class TestAsyncWithTimeout:
    """Tests for async_with_timeout function."""

    @pytest.mark.asyncio
    async def test_fast_coro_succeeds(self):
        """Test that fast coroutine completes within timeout."""
        async def fast_coro():
            return "async_result"

        result = await async_with_timeout(
            fast_coro(),
            timeout_sec=1.0,
            operation_name="test",
        )
        assert result == "async_result"

    @pytest.mark.asyncio
    async def test_slow_coro_times_out(self):
        """Test that slow coroutine times out."""
        import asyncio

        async def slow_coro():
            await asyncio.sleep(1.0)
            return "result"

        with pytest.raises(StateTransferTimeout) as exc_info:
            await async_with_timeout(
                slow_coro(),
                timeout_sec=0.1,
                operation_name="slow_test",
            )

        assert exc_info.value.metrics.timed_out is True


class TestStateCaptureGuard:
    """Tests for StateCaptureGuard context manager."""

    def test_successful_capture(self):
        """Test successful state capture within limits."""
        config = TransferConfig(
            capture_timeout_sec=5.0,
            max_size_bytes=1024,
        )

        with StateCaptureGuard(config) as guard:
            state_json = '{"counter": 42}'
            metrics = guard.validate(state_json)

        assert metrics.timed_out is False
        assert metrics.size_exceeded is False
        assert metrics.size_bytes == len(state_json.encode("utf-8"))

    def test_capture_timeout(self):
        """Test that slow capture is detected."""
        config = TransferConfig(capture_timeout_sec=0.01)  # 10ms

        with StateCaptureGuard(config) as guard:
            time.sleep(0.05)  # 50ms - exceeds timeout
            with pytest.raises(StateTransferTimeout):
                guard.validate('{"data": true}')

    def test_capture_size_exceeded(self):
        """Test that large state is rejected."""
        config = TransferConfig(max_size_bytes=100)

        with StateCaptureGuard(config) as guard:
            large_state = "x" * 200
            with pytest.raises(StateSizeExceeded):
                guard.validate(large_state)


class TestOrchestratorConstants:
    """Tests for Orchestrator alignment constants."""

    def test_orchestrator_timeout(self):
        """Test Orchestrator timeout constant."""
        # Matches transfer.go DefaultHTTPTimeout
        assert ORCHESTRATOR_STATE_TIMEOUT_SEC == 30

    def test_orchestrator_max_size(self):
        """Test Orchestrator max size constant."""
        # Matches transfer.go MaxResponseBodySize
        assert ORCHESTRATOR_MAX_STATE_SIZE == 10 * 1024 * 1024


class TestHealthServerTimeoutIntegration:
    """Tests for HealthServer timeout integration."""

    @pytest.fixture
    def mock_transfer_config(self):
        """Create a test transfer config."""
        return TransferConfig(
            capture_timeout_sec=25,
            restore_timeout_sec=25,
            max_size_bytes=8 * 1024 * 1024,
        )

    def test_health_server_accepts_transfer_config(self, mock_transfer_config):
        """Test that HealthServer accepts TransferConfig."""
        from dory.health.server import HealthServer

        server = HealthServer(transfer_config=mock_transfer_config)
        assert server._transfer_config == mock_transfer_config

    def test_health_server_default_transfer_config(self):
        """Test that HealthServer creates default TransferConfig."""
        from dory.health.server import HealthServer

        server = HealthServer()
        assert server._transfer_config is not None
        assert server._transfer_config.capture_timeout_sec == 25

    @pytest.mark.asyncio
    async def test_state_get_validates_size(self):
        """Test that GET /state validates state size."""
        from dory.health.server import HealthServer
        from aiohttp.test_utils import TestClient, TestServer

        # Create large state getter
        def large_state_getter():
            return {"data": "x" * 100}  # Small state

        config = TransferConfig(max_size_bytes=50)  # Very small limit
        server = HealthServer(
            state_getter=large_state_getter,
            transfer_config=config,
        )

        server._app = __import__("aiohttp").web.Application()
        server._setup_routes()

        async with TestClient(TestServer(server._app)) as client:
            resp = await client.get("/state")
            assert resp.status == 413  # Payload Too Large
            data = await resp.json()
            assert data.get("size_exceeded") is True

    @pytest.mark.asyncio
    async def test_state_post_validates_size(self):
        """Test that POST /state validates incoming state size."""
        from dory.health.server import HealthServer
        from aiohttp.test_utils import TestClient, TestServer
        import json

        async def state_restorer(state):
            pass

        config = TransferConfig(max_size_bytes=50)  # Very small limit
        server = HealthServer(
            state_restorer=state_restorer,
            transfer_config=config,
        )

        server._app = __import__("aiohttp").web.Application()
        server._setup_routes()

        async with TestClient(TestServer(server._app)) as client:
            large_state = {"data": "x" * 100}
            resp = await client.post("/state", json=large_state)
            assert resp.status == 413
            data = await resp.json()
            assert data.get("size_exceeded") is True
