"""Tests for state format version negotiation."""

import json
import pytest
import time

from dory.migration.versioning import (
    StateFormatVersion,
    StateMetadata,
    VersionedState,
    VersionNegotiator,
    StateSerializerV1,
    StateSerializerV2,
    detect_format_version,
    get_sdk_version,
    get_supported_versions,
    is_version_supported,
    serialize_state,
    deserialize_state,
    get_version_info,
    SDK_STATE_VERSION,
    MIN_SUPPORTED_VERSION,
)
from dory.utils.errors import DoryStateError


class TestStateFormatVersion:
    """Tests for StateFormatVersion enum."""

    def test_version_values(self):
        """Test version enum values."""
        assert StateFormatVersion.V1_0.value == "1.0"
        assert StateFormatVersion.V2_0.value == "2.0"

    def test_latest(self):
        """Test latest version."""
        assert StateFormatVersion.latest() == StateFormatVersion.V2_0

    def test_from_string(self):
        """Test parsing version strings."""
        assert StateFormatVersion.from_string("1.0") == StateFormatVersion.V1_0
        assert StateFormatVersion.from_string("2.0") == StateFormatVersion.V2_0
        assert StateFormatVersion.from_string("v1.0") == StateFormatVersion.V1_0
        assert StateFormatVersion.from_string(" 2.0 ") == StateFormatVersion.V2_0

    def test_from_string_invalid(self):
        """Test parsing invalid version strings."""
        with pytest.raises(ValueError):
            StateFormatVersion.from_string("3.0")
        with pytest.raises(ValueError):
            StateFormatVersion.from_string("invalid")

    def test_compatibility(self):
        """Test version compatibility checks."""
        # V2.0 can read all versions
        assert StateFormatVersion.V2_0.is_compatible_with(StateFormatVersion.V1_0)
        assert StateFormatVersion.V2_0.is_compatible_with(StateFormatVersion.V2_0)

        # V1.0 can only read V1.0
        assert StateFormatVersion.V1_0.is_compatible_with(StateFormatVersion.V1_0)
        assert not StateFormatVersion.V1_0.is_compatible_with(StateFormatVersion.V2_0)


class TestStateMetadata:
    """Tests for StateMetadata."""

    def test_default_metadata(self):
        """Test default metadata creation."""
        metadata = StateMetadata()

        assert metadata.timestamp > 0
        assert metadata.timestamp_iso != ""
        assert metadata.format_version == SDK_STATE_VERSION.value

    def test_metadata_with_values(self):
        """Test metadata with custom values."""
        metadata = StateMetadata(
            processor_id="proc-123",
            pod_name="pod-abc",
            app_name="my-app",
            restart_count=3,
            uptime_seconds=3600.0,
        )

        assert metadata.processor_id == "proc-123"
        assert metadata.pod_name == "pod-abc"
        assert metadata.app_name == "my-app"
        assert metadata.restart_count == 3
        assert metadata.uptime_seconds == 3600.0

    def test_metadata_to_dict(self):
        """Test metadata serialization."""
        metadata = StateMetadata(
            processor_id="proc-1",
            pod_name="pod-1",
        )

        data = metadata.to_dict()

        assert data["processor_id"] == "proc-1"
        assert data["pod_name"] == "pod-1"
        assert "timestamp" in data
        assert "format_version" in data

    def test_metadata_from_dict(self):
        """Test metadata deserialization."""
        data = {
            "processor_id": "proc-2",
            "pod_name": "pod-2",
            "restart_count": 5,
            "format_version": "1.0",
        }

        metadata = StateMetadata.from_dict(data)

        assert metadata.processor_id == "proc-2"
        assert metadata.restart_count == 5
        assert metadata.format_version == "1.0"


class TestVersionedState:
    """Tests for VersionedState."""

    def test_state_creation(self):
        """Test state creation."""
        state = VersionedState(
            data={"counter": 42},
            metadata=StateMetadata(processor_id="proc"),
        )

        assert state.data == {"counter": 42}
        assert state.checksum != ""

    def test_checksum_validation(self):
        """Test checksum validation."""
        state = VersionedState(
            data={"value": 123},
            metadata=StateMetadata(),
        )

        assert state.validate_checksum() is True

        # Tamper with data
        state.data["value"] = 456
        assert state.validate_checksum() is False

    def test_format_version_property(self):
        """Test format_version property."""
        state = VersionedState(
            data={},
            metadata=StateMetadata(format_version="2.0"),
        )

        assert state.format_version == StateFormatVersion.V2_0


class TestStateSerializerV1:
    """Tests for V1.0 serializer."""

    def test_serialize(self):
        """Test V1.0 serialization."""
        state = VersionedState(
            data={"key": "value"},
            metadata=StateMetadata(
                processor_id="proc-1",
                pod_name="pod-1",
            ),
        )

        json_str = StateSerializerV1.serialize(state)
        parsed = json.loads(json_str)

        assert "payload" in parsed
        assert "metadata" in parsed
        assert "checksum" in parsed
        assert parsed["payload"]["key"] == "value"

    def test_deserialize(self):
        """Test V1.0 deserialization."""
        v1_json = json.dumps({
            "payload": {"counter": 42},
            "metadata": {
                "timestamp": 1234567890.0,
                "processor_id": "proc-1",
                "pod_name": "pod-1",
            },
            "checksum": "abc123",
        })

        state = StateSerializerV1.deserialize(v1_json)

        assert state.data["counter"] == 42
        assert state.metadata.processor_id == "proc-1"
        assert state.format_version == StateFormatVersion.V1_0

    def test_deserialize_invalid(self):
        """Test V1.0 deserialization with invalid data."""
        with pytest.raises(DoryStateError):
            StateSerializerV1.deserialize("invalid json")

        with pytest.raises(DoryStateError):
            StateSerializerV1.deserialize(json.dumps({"no_payload": True}))


class TestStateSerializerV2:
    """Tests for V2.0 serializer."""

    def test_serialize(self):
        """Test V2.0 serialization."""
        state = VersionedState(
            data={"key": "value"},
            metadata=StateMetadata(
                processor_id="proc-1",
                pod_name="pod-1",
                app_name="my-app",
            ),
            metrics={"requests": 100.0},
            active_sessions=5,
        )

        json_str = StateSerializerV2.serialize(state)
        parsed = json.loads(json_str)

        # V2 format fields
        assert parsed["pod_name"] == "pod-1"
        assert parsed["app_name"] == "my-app"
        assert parsed["state_version"] == "2.0"
        assert parsed["data"]["key"] == "value"
        assert parsed["metrics"]["requests"] == 100.0
        assert parsed["active_sessions"] == 5

        # SDK metadata for round-trip
        assert "_sdk_metadata" in parsed

    def test_deserialize(self):
        """Test V2.0 deserialization."""
        v2_json = json.dumps({
            "pod_name": "pod-1",
            "app_name": "my-app",
            "captured_at": "2024-01-15T10:30:00Z",
            "state_version": "2.0",
            "data": {"counter": 42},
            "metrics": {"cpu": 0.5},
            "connections": ["conn1", "conn2"],
            "active_sessions": 3,
            "session_data": {"session1": "data1"},
            "uptime_seconds": 3600.0,
            "request_count": 1000,
        })

        state = StateSerializerV2.deserialize(v2_json)

        assert state.data["counter"] == 42
        assert state.metadata.pod_name == "pod-1"
        assert state.metadata.app_name == "my-app"
        assert state.metrics["cpu"] == 0.5
        assert state.connections == ["conn1", "conn2"]
        assert state.active_sessions == 3
        assert state.format_version == StateFormatVersion.V2_0

    def test_roundtrip(self):
        """Test V2.0 serialization roundtrip."""
        original = VersionedState(
            data={"important": "data"},
            metadata=StateMetadata(
                processor_id="proc-x",
                pod_name="pod-x",
                app_name="app-x",
                restart_count=2,
            ),
            metrics={"metric1": 1.0},
            active_sessions=10,
        )

        json_str = StateSerializerV2.serialize(original)
        restored = StateSerializerV2.deserialize(json_str)

        assert restored.data == original.data
        assert restored.metadata.processor_id == original.metadata.processor_id
        assert restored.metrics == original.metrics
        assert restored.active_sessions == original.active_sessions


class TestDetectFormatVersion:
    """Tests for format version detection."""

    def test_detect_v1(self):
        """Test detecting V1.0 format."""
        v1_data = {
            "payload": {"key": "value"},
            "metadata": {"timestamp": 123},
            "checksum": "abc",
        }

        version = detect_format_version(v1_data)
        assert version == StateFormatVersion.V1_0

    def test_detect_v2(self):
        """Test detecting V2.0 format."""
        v2_data = {
            "state_version": "2.0",
            "data": {"key": "value"},
            "pod_name": "pod",
        }

        version = detect_format_version(v2_data)
        assert version == StateFormatVersion.V2_0

    def test_detect_v2_by_structure(self):
        """Test detecting V2.0 by structure."""
        v2_data = {
            "data": {"key": "value"},
            "pod_name": "pod",
            "app_name": "app",
        }

        version = detect_format_version(v2_data)
        assert version == StateFormatVersion.V2_0


class TestVersionNegotiator:
    """Tests for VersionNegotiator."""

    @pytest.fixture
    def negotiator(self):
        """Create negotiator instance."""
        return VersionNegotiator()

    def test_sdk_version(self, negotiator):
        """Test SDK version property."""
        assert negotiator.sdk_version == SDK_STATE_VERSION

    def test_supported_versions(self, negotiator):
        """Test supported versions."""
        versions = negotiator.supported_versions
        assert StateFormatVersion.V1_0 in versions
        assert StateFormatVersion.V2_0 in versions

    def test_negotiate_read_no_peer(self, negotiator):
        """Test read negotiation without peer version."""
        result = negotiator.negotiate_read(None)

        assert result.is_compatible is True
        assert result.agreed_version == SDK_STATE_VERSION

    def test_negotiate_read_compatible(self, negotiator):
        """Test read negotiation with compatible version."""
        result = negotiator.negotiate_read("1.0")

        assert result.is_compatible is True
        assert result.peer_version == StateFormatVersion.V1_0

    def test_negotiate_read_same_version(self, negotiator):
        """Test read negotiation with same version."""
        result = negotiator.negotiate_read("2.0")

        assert result.is_compatible is True
        assert result.migration_required is False

    def test_negotiate_read_invalid(self, negotiator):
        """Test read negotiation with invalid version."""
        result = negotiator.negotiate_read("99.0")

        assert result.is_compatible is False

    def test_negotiate_write_default(self, negotiator):
        """Test write negotiation with default version."""
        result = negotiator.negotiate_write(None)

        assert result.is_compatible is True
        assert result.agreed_version == SDK_STATE_VERSION

    def test_negotiate_write_v1(self, negotiator):
        """Test write negotiation for V1.0."""
        result = negotiator.negotiate_write("1.0")

        assert result.is_compatible is True
        assert result.agreed_version == StateFormatVersion.V1_0
        assert result.migration_required is True

    def test_serialize_v1(self, negotiator):
        """Test serialization to V1.0."""
        state = VersionedState(
            data={"test": True},
            metadata=StateMetadata(processor_id="p1"),
        )

        json_str = negotiator.serialize(state, StateFormatVersion.V1_0)
        parsed = json.loads(json_str)

        assert "payload" in parsed  # V1 format

    def test_serialize_v2(self, negotiator):
        """Test serialization to V2.0."""
        state = VersionedState(
            data={"test": True},
            metadata=StateMetadata(processor_id="p1"),
        )

        json_str = negotiator.serialize(state, StateFormatVersion.V2_0)
        parsed = json.loads(json_str)

        assert "state_version" in parsed  # V2 format
        assert parsed["state_version"] == "2.0"

    def test_deserialize_auto_detect(self, negotiator):
        """Test deserialization with auto-detection."""
        # V1 format
        v1_json = json.dumps({
            "payload": {"v1": True},
            "metadata": {"processor_id": "p1"},
            "checksum": "x",
        })

        state = negotiator.deserialize(v1_json)
        assert state.data["v1"] is True

        # V2 format
        v2_json = json.dumps({
            "state_version": "2.0",
            "data": {"v2": True},
            "pod_name": "pod",
        })

        state = negotiator.deserialize(v2_json)
        assert state.data["v2"] is True

    def test_migrate(self, negotiator):
        """Test state migration."""
        state = VersionedState(
            data={"value": 123},
            metadata=StateMetadata(
                processor_id="p1",
                format_version="1.0",
            ),
        )

        migrated = negotiator.migrate(state, StateFormatVersion.V2_0)

        assert migrated.data == state.data
        assert migrated.metadata.format_version == "2.0"


class TestConvenienceFunctions:
    """Tests for convenience functions."""

    def test_get_sdk_version(self):
        """Test get_sdk_version function."""
        version = get_sdk_version()
        assert version == SDK_STATE_VERSION.value

    def test_get_supported_versions(self):
        """Test get_supported_versions function."""
        versions = get_supported_versions()
        assert "1.0" in versions
        assert "2.0" in versions

    def test_is_version_supported(self):
        """Test is_version_supported function."""
        assert is_version_supported("1.0") is True
        assert is_version_supported("2.0") is True
        assert is_version_supported("99.0") is False

    def test_serialize_state(self):
        """Test serialize_state convenience function."""
        json_str = serialize_state(
            data={"counter": 42},
            processor_id="proc-1",
            pod_name="pod-1",
            target_version="2.0",
        )

        parsed = json.loads(json_str)
        assert parsed["data"]["counter"] == 42
        assert parsed["state_version"] == "2.0"

    def test_deserialize_state(self):
        """Test deserialize_state convenience function."""
        json_str = json.dumps({
            "state_version": "2.0",
            "data": {"counter": 42},
            "pod_name": "pod-1",
            "_sdk_metadata": {"processor_id": "proc-1"},
        })

        data, metadata = deserialize_state(json_str)

        assert data["counter"] == 42
        assert metadata.processor_id == "proc-1"

    def test_get_version_info(self):
        """Test get_version_info function."""
        info = get_version_info()

        assert "state_format_version" in info
        assert "supported_versions" in info
        assert "min_supported_version" in info
        assert "latest_version" in info
        assert info["latest_version"] == StateFormatVersion.latest().value


class TestOrchestratorCompatibility:
    """Tests for Orchestrator compatibility."""

    def test_v2_matches_orchestrator_applicationstate(self):
        """Test V2.0 format matches Orchestrator's ApplicationState structure."""
        state = VersionedState(
            data={"app_data": "value"},
            metadata=StateMetadata(
                processor_id="my-processor",
                pod_name="pod-abc-123",
                app_name="my-app",
                uptime_seconds=3600.0,
                request_count=1000,
            ),
            metrics={"cpu": 0.5, "memory": 0.7},
            connections=["conn1", "conn2"],
            active_sessions=5,
            session_data={"sess1": "data1"},
        )

        json_str = StateSerializerV2.serialize(state)
        parsed = json.loads(json_str)

        # Check Orchestrator ApplicationState fields
        assert "pod_name" in parsed
        assert "app_name" in parsed
        assert "captured_at" in parsed
        assert "state_version" in parsed
        assert "data" in parsed
        assert "metrics" in parsed
        assert "connections" in parsed
        assert "active_sessions" in parsed
        assert "session_data" in parsed
        assert "uptime_seconds" in parsed
        assert "request_count" in parsed
        assert "last_health_time" in parsed

    def test_parse_orchestrator_state(self):
        """Test parsing state from Orchestrator."""
        # Simulate state from Orchestrator (Go's ApplicationState)
        orchestrator_state = {
            "pod_name": "my-pod-123",
            "app_name": "my-app",
            "captured_at": "2024-01-15T12:00:00Z",
            "state_version": "2.0",
            "data": {"key": "value"},
            "metrics": {"requests_per_sec": 100.0},
            "connections": [],
            "active_sessions": 10,
            "session_data": {},
            "uptime_seconds": 7200.0,
            "request_count": 50000,
            "last_health_time": "2024-01-15T12:00:00Z",
        }

        json_str = json.dumps(orchestrator_state)
        state = StateSerializerV2.deserialize(json_str)

        assert state.data["key"] == "value"
        assert state.metadata.pod_name == "my-pod-123"
        assert state.metadata.app_name == "my-app"
        assert state.active_sessions == 10
        assert state.metrics["requests_per_sec"] == 100.0

    def test_v1_to_v2_migration(self):
        """Test migrating V1.0 state to V2.0."""
        # Old V1.0 state
        v1_json = json.dumps({
            "payload": {"legacy_data": "value"},
            "metadata": {
                "timestamp": 1705320000.0,
                "processor_id": "old-processor",
                "pod_name": "old-pod",
                "restart_count": 3,
            },
            "checksum": "abc123",
        })

        negotiator = VersionNegotiator()

        # Deserialize V1 format
        state = negotiator.deserialize(v1_json)
        assert state.format_version == StateFormatVersion.V1_0

        # Migrate to V2
        migrated = negotiator.migrate(state, StateFormatVersion.V2_0)
        assert migrated.format_version == StateFormatVersion.V2_0
        assert migrated.data["legacy_data"] == "value"

        # Serialize as V2
        v2_json = negotiator.serialize(migrated, StateFormatVersion.V2_0)
        parsed = json.loads(v2_json)

        assert parsed["state_version"] == "2.0"
        assert parsed["data"]["legacy_data"] == "value"
