"""
Dory Middleware

Automatic bookkeeping middleware for request tracking, connection management,
and observability.
"""

from dory.middleware.request_tracker import (
    RequestTracker,
    track_request,
    RequestMetrics,
    RequestInfo,
    RequestStatus,
)
from dory.middleware.request_id import (
    RequestIdMiddleware,
    with_request_id,
    get_current_request_id,
    set_request_id,
    generate_request_id,
)
from dory.middleware.connection_tracker import (
    ConnectionTracker,
    track_connection,
    ConnectionInfo,
    ConnectionStatus,
    ConnectionType,
)

__all__ = [
    "RequestTracker",
    "track_request",
    "RequestMetrics",
    "RequestInfo",
    "RequestStatus",
    "RequestIdMiddleware",
    "with_request_id",
    "get_current_request_id",
    "set_request_id",
    "generate_request_id",
    "ConnectionTracker",
    "track_connection",
    "ConnectionInfo",
    "ConnectionStatus",
    "ConnectionType",
]
