"""
Tests for golden snapshot manager.
"""

import asyncio
import pytest
from typing import Any, Dict, Optional
from unittest.mock import AsyncMock, MagicMock

from dory.recovery.golden_snapshot import (
    GoldenSnapshotManager,
    Snapshot,
    SnapshotMetadata,
    SnapshotStorageError,
    SnapshotValidationError,
)


class MockStateManager:
    """Mock StateManager for testing GoldenSnapshotManager."""

    def __init__(self):
        self._storage: Dict[str, Dict[str, Any]] = {}
        self._backend = "mock"

    async def save_state(
        self,
        processor_id: str,
        state: Dict[str, Any],
        restart_count: int = 0,
    ) -> None:
        """Save state to in-memory storage."""
        self._storage[processor_id] = state

    async def load_state(self, processor_id: str) -> Optional[Dict[str, Any]]:
        """Load state from in-memory storage."""
        return self._storage.get(processor_id)

    async def delete_state(self, processor_id: str) -> bool:
        """Delete state from in-memory storage."""
        if processor_id in self._storage:
            del self._storage[processor_id]
            return True
        return False


@pytest.fixture
def mock_state_manager():
    """Create a mock StateManager for testing."""
    return MockStateManager()


@pytest.mark.asyncio
class TestGoldenSnapshotManager:
    """Test GoldenSnapshotManager functionality."""

    async def test_capture_snapshot(self, mock_state_manager):
        """Test capturing a snapshot."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        state_data = {"counter": 42, "status": "active", "data": [1, 2, 3]}

        snapshot = await manager.capture_snapshot(
            processor_id="test-processor",
            state_data=state_data,
            tags={"version": "1.0"},
        )

        assert snapshot.metadata.processor_id == "test-processor"
        assert snapshot.metadata.checksum is not None
        assert snapshot.metadata.size_bytes > 0
        assert snapshot.state_data == state_data
        assert snapshot.metadata.tags["version"] == "1.0"

    async def test_capture_with_compression(self, mock_state_manager):
        """Test snapshot capture with compression."""
        manager = GoldenSnapshotManager(
            state_manager=mock_state_manager,
            compression_enabled=True,
        )

        state_data = {"key": "value" * 1000}  # Larger data

        snapshot = await manager.capture_snapshot(
            processor_id="test-processor",
            state_data=state_data,
        )

        assert snapshot.metadata.compressed is True
        assert snapshot.metadata.size_bytes > 0

    async def test_restore_snapshot(self, mock_state_manager):
        """Test restoring from a snapshot."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        original_state = {"counter": 42, "status": "active"}

        # Capture
        snapshot = await manager.capture_snapshot(
            processor_id="test-processor",
            state_data=original_state,
        )

        # Restore
        restored_state = await manager.restore_snapshot(snapshot.metadata.snapshot_id)

        assert restored_state == original_state

    async def test_restore_with_checksum_validation(self, mock_state_manager):
        """Test restore with checksum validation."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        state_data = {"key": "value"}

        # Capture
        snapshot = await manager.capture_snapshot(
            processor_id="test-processor",
            state_data=state_data,
        )

        # Restore with validation
        restored_state = await manager.restore_snapshot(
            snapshot.metadata.snapshot_id,
            validate_checksum=True,
        )

        assert restored_state == state_data

    async def test_restore_nonexistent_snapshot(self, mock_state_manager):
        """Test restoring nonexistent snapshot raises error."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        with pytest.raises(SnapshotStorageError):
            await manager.restore_snapshot("nonexistent_123456789")

    async def test_list_snapshots(self, mock_state_manager):
        """Test listing snapshots."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        # Create multiple snapshots for processor-1
        await manager.capture_snapshot(
            processor_id="processor-1",
            state_data={"data": 1},
        )
        await manager.capture_snapshot(
            processor_id="processor-1",
            state_data={"data": 2},
        )

        # List for specific processor
        proc1_snapshots = await manager.list_snapshots(processor_id="processor-1")
        assert len(proc1_snapshots) == 2

    async def test_list_snapshots_requires_processor_id(self, mock_state_manager):
        """Test that list_snapshots requires processor_id."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        with pytest.raises(ValueError, match="processor_id is required"):
            await manager.list_snapshots()

    async def test_list_snapshots_with_limit(self, mock_state_manager):
        """Test listing snapshots with limit."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        # Create multiple snapshots
        for i in range(5):
            await manager.capture_snapshot(
                processor_id="test-processor",
                state_data={"data": i},
            )

        # List with limit
        snapshots = await manager.list_snapshots(processor_id="test-processor", limit=3)
        assert len(snapshots) == 3

    async def test_delete_snapshot(self, mock_state_manager):
        """Test deleting a snapshot."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        # Create snapshot
        snapshot = await manager.capture_snapshot(
            processor_id="test-processor",
            state_data={"data": "test"},
        )

        # Delete
        result = await manager.delete_snapshot(snapshot.metadata.snapshot_id)
        assert result is True

        # Verify deleted
        snapshots = await manager.list_snapshots(processor_id="test-processor")
        assert len(snapshots) == 0

    async def test_get_latest_snapshot(self, mock_state_manager):
        """Test getting latest snapshot."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        # Create snapshots
        await manager.capture_snapshot(
            processor_id="test-processor",
            state_data={"version": 1},
        )
        await asyncio.sleep(0.01)  # Ensure different timestamps
        snapshot2 = await manager.capture_snapshot(
            processor_id="test-processor",
            state_data={"version": 2},
        )

        # Get latest
        latest = await manager.get_latest_snapshot("test-processor")
        assert latest is not None
        assert latest.snapshot_id == snapshot2.metadata.snapshot_id

    async def test_auto_cleanup(self, mock_state_manager):
        """Test automatic cleanup of old snapshots."""
        manager = GoldenSnapshotManager(
            state_manager=mock_state_manager,
            max_snapshots_per_processor=3,
            auto_cleanup=True,
        )

        # Create more than max snapshots
        for i in range(5):
            await manager.capture_snapshot(
                processor_id="test-processor",
                state_data={"version": i},
            )
            await asyncio.sleep(0.01)

        # Should only have 3 snapshots (most recent)
        snapshots = await manager.list_snapshots(processor_id="test-processor")
        assert len(snapshots) == 3

    async def test_snapshot_metadata_updates(self, mock_state_manager):
        """Test that metadata is updated on restore."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        # Create snapshot
        snapshot = await manager.capture_snapshot(
            processor_id="test-processor",
            state_data={"data": "test"},
        )

        assert snapshot.metadata.restore_count == 0
        assert snapshot.metadata.last_restored_at is None

        # Restore
        await manager.restore_snapshot(
            snapshot.metadata.snapshot_id,
            update_metadata=True,
        )

        # Check updated metadata
        snapshots = await manager.list_snapshots(processor_id="test-processor")
        assert snapshots[0].restore_count == 1
        assert snapshots[0].last_restored_at is not None

    async def test_capture_invalid_state(self, mock_state_manager):
        """Test capturing invalid state data."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        # Non-serializable data
        class NonSerializable:
            pass

        with pytest.raises(SnapshotValidationError):
            await manager.capture_snapshot(
                processor_id="test-processor",
                state_data={"obj": NonSerializable()},
            )

    async def test_capture_callback(self, mock_state_manager):
        """Test capture callback is called."""
        captured_snapshots = []

        def on_capture(snapshot):
            captured_snapshots.append(snapshot)

        manager = GoldenSnapshotManager(
            state_manager=mock_state_manager,
            on_capture=on_capture,
        )

        await manager.capture_snapshot(
            processor_id="test-processor",
            state_data={"data": "test"},
        )

        assert len(captured_snapshots) == 1

    async def test_restore_callback(self, mock_state_manager):
        """Test restore callback is called."""
        restored_snapshots = []

        def on_restore(snapshot):
            restored_snapshots.append(snapshot)

        manager = GoldenSnapshotManager(
            state_manager=mock_state_manager,
            on_restore=on_restore,
        )

        # Capture
        snapshot = await manager.capture_snapshot(
            processor_id="test-processor",
            state_data={"data": "test"},
        )

        # Restore
        await manager.restore_snapshot(snapshot.metadata.snapshot_id)

        assert len(restored_snapshots) == 1

    async def test_get_stats(self, mock_state_manager):
        """Test getting manager statistics."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        # Capture and restore
        snapshot = await manager.capture_snapshot(
            processor_id="test-processor",
            state_data={"data": "test"},
        )
        await manager.restore_snapshot(snapshot.metadata.snapshot_id)

        stats = manager.get_stats()
        assert stats["capture_count"] == 1
        assert stats["restore_count"] == 1
        assert stats["validation_failures"] == 0
        assert stats["storage_backend"] == "mock"

    async def test_delete_all_snapshots(self, mock_state_manager):
        """Test deleting all snapshots for a processor."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        # Create snapshots
        for i in range(3):
            await manager.capture_snapshot(
                processor_id="test-processor",
                state_data={"data": i},
            )

        # Delete all
        count = await manager.delete_all_snapshots("test-processor")
        assert count == 3

        # Verify deleted
        snapshots = await manager.list_snapshots(processor_id="test-processor")
        assert len(snapshots) == 0

    async def test_clear_cache(self, mock_state_manager):
        """Test clearing the snapshot cache."""
        manager = GoldenSnapshotManager(state_manager=mock_state_manager)

        # Create snapshot to populate cache
        await manager.capture_snapshot(
            processor_id="test-processor",
            state_data={"data": "test"},
        )

        # Verify cache is populated
        assert "test-processor" in manager._snapshot_cache

        # Clear cache for specific processor
        manager.clear_cache("test-processor")
        assert "test-processor" not in manager._snapshot_cache

        # Create again
        await manager.capture_snapshot(
            processor_id="test-processor",
            state_data={"data": "test"},
        )

        # Clear all cache
        manager.clear_cache()
        assert len(manager._snapshot_cache) == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
