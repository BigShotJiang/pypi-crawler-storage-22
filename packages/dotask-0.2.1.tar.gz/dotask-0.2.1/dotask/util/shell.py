import threading
from dotask.util import logger
import subprocess
from typing import Optional,Callable

class Shell:
    def __init__(self,max_concurrent:int):
        self.max_concurrent = max_concurrent
        self.shell_semaphore = threading.Semaphore(max_concurrent)

    def set_max_concurrent(self,new_max:int) -> None:
        if new_max <= 0:
            raise ValueError("最大并发数必须大于0")
        self.max_concurrent = new_max
        self.shell_semaphore = threading.Semaphore(new_max)
        logger.debug(f"最大并发数已更新为:{new_max}")

    def local_shell_execute(self,cmd:str,callback: Optional[Callable[[bool, str], None]] = None) -> bool:
        def execute_and_wait():
            # 关键：信号量放在线程内，覆盖整个命令执行周期
            with self.shell_semaphore:
                logger.debug(f"剩余并发名额: {self.shell_semaphore._value} | 开始执行命令: {cmd[:50]}")
                proc = None
                try:
                    # 创建并执行命令
                    proc = subprocess.Popen(
                        cmd,
                        shell=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        encoding='utf-8',
                    )
                    # 等待命令完成（阻塞，直到命令执行结束）
                    stdout, stderr = proc.communicate()

                    # 处理结果
                    if proc.returncode == 0:
                        logger.debug(f"命令执行成功: {cmd[:50]}")
                        self._callback(callback,success=True, result=stdout.strip())
                    else:
                        error_msg = f"返回码：{proc.returncode}，错误信息：{stderr.strip()[:200]}"
                        logger.error(f"命令执行失败: {cmd[:50]} → {error_msg}")
                        self._callback(callback,success=False, result=error_msg)

                except Exception as ex:
                    logger.error(f"命令执行失败: {cmd[:50]} → {str(ex)}")
                    self._callback(callback,success=False, result=str(ex))
                finally:
                    if proc is not None:
                        if proc.poll() is None:
                            proc.kill()
                            proc.communicate()
                        # 关闭管道，释放资源
                        proc.stdout.close()
                        proc.stderr.close()

        try:
            # 启动线程执行命令（守护线程，不阻塞主线程）
            safe_cmd_name = cmd[:20].replace(' ', '_').replace('/', '_').replace('\\', '_').replace('|', '_')
            exec_thread = threading.Thread(
                target=execute_and_wait,
                daemon=True,
                name=f"CmdExecutor-{safe_cmd_name}"
            )
            exec_thread.start()
            logger.debug(f"任务已提交: {cmd[:50]}")
            return True
        except Exception as e:
            logger.error(f"任务提交失败: {cmd[:50]} → {str(e)}")
            self._callback(callback,success=False,result=str(e))
            return False

    @staticmethod
    def _callback(callback: Optional[Callable[[bool, str], None]],success:bool,result:str) -> None:
        if callback:
            try:
                callback(success, result)
            except Exception as ex:
                logger.error(f"回调函数执行失败: {str(ex)}")

