## 0.1.0
- 在方法上添加@task就可以直接开启一个线程执行任务
- 常用参数：
  - 生产者: role="producer",topic="自定义"
  - 消费者: role="consumer",subscribe="自定义",publish_after="自定义"
- 说明:
  - role: 用于区分上下游 producer/consumer
  - topic: 发布的主题
  - subscribe: 对哪些主题感兴趣
  - publish_after: 消费完后继续发布新主题
- 特别的：方法的返回值可以进行传递,若没有返回值则不会发布新主题（只针对消费者和消费者之间）
## 0.2.0
1. dotask暴露topic_manager=>可以更好的管理生产消费者 
2. 迁移logger至util包下
3. 添加本地调用shell工具函数->可以很好的适配@task消费者
   1. max_concurrent:控制并发执行的shell数量
   2. 引入dotask.Shell 调用Shell(max_concurrent=?).local_shell_execute(cmd,callback)来使用
