import threading
from dotask.util import logger
import subprocess
from typing import Optional,Callable

class Shell:
    _shell_semaphore:threading.Semaphore = None
    _semaphore_lock = threading.Lock()

    def __init__(self,max_concurrent:int,global_sem=False):
        self.global_sem = global_sem
        if global_sem:
            if max_concurrent <= 0:
                raise ValueError("最大并发数必须大于0")
            self._shell_semaphore = threading.Semaphore(max_concurrent)
            self._max_concurrent = max_concurrent
        else:
            with Shell._semaphore_lock:
                if Shell._shell_semaphore is None:
                    if max_concurrent <= 0:
                        raise ValueError("最大并发数必须大于0")
                    Shell._shell_semaphore = threading.Semaphore(max_concurrent)
                    self._max_concurrent = max_concurrent
                else:
                    if Shell._shell_semaphore._value != max_concurrent:
                        logger.warning(f"全局信号量已存在（并发数：{Shell._shell_semaphore._value}），忽略传入的max_concurrent={max_concurrent}")
                    self._max_concurrent = Shell._shell_semaphore._value

    def local_shell_execute(self,cmd:str,callback: Optional[Callable[[bool, str], None]] = None) -> bool:
        def execute_and_wait():
            semaphore = self._shell_semaphore if self.global_sem else Shell._shell_semaphore

            with semaphore:
                logger.debug(f"实例:{id(self)}-剩余并发名额: {semaphore._value} | 开始执行命令: {cmd[:50]}")
                proc = None
                try:
                    # 创建并执行命令
                    proc = subprocess.Popen(
                        cmd,
                        shell=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        encoding='utf-8',
                    )
                    # 等待命令完成（阻塞，直到命令执行结束）
                    stdout, stderr = proc.communicate()

                    # 处理结果
                    if proc.returncode == 0:
                        logger.debug(f"命令执行成功: {cmd[:50]}")
                        self._callback(callback,success=True, result=stdout.strip())
                    else:
                        error_msg = f"返回码：{proc.returncode}，错误信息：{stderr.strip()[:200]}"
                        logger.error(f"命令执行失败: {cmd[:50]} → {error_msg}")
                        self._callback(callback,success=False, result=error_msg)

                except Exception as ex:
                    logger.error(f"命令执行失败: {cmd[:50]} → {str(ex)}")
                    self._callback(callback,success=False, result=str(ex))
                finally:
                    if proc is not None:
                        if proc.poll() is None:
                            proc.kill()
                            proc.communicate()
                        # 关闭管道，释放资源
                        proc.stdout.close()
                        proc.stderr.close()

        try:
            # 启动线程执行命令（守护线程，不阻塞主线程）
            safe_cmd_name = cmd[:20].replace(' ', '_').replace('/', '_').replace('\\', '_').replace('|', '_')
            exec_thread = threading.Thread(
                target=execute_and_wait,
                daemon=True,
                name=f"CmdExecutor-{safe_cmd_name}"
            )
            exec_thread.start()
            logger.debug(f"任务已提交: {cmd[:50]}")
            return True
        except Exception as e:
            logger.error(f"任务提交失败: {cmd[:50]} → {str(e)}")
            self._callback(callback,success=False,result=str(e))
            return False

    @staticmethod
    def _callback(callback: Optional[Callable[[bool, str], None]],success:bool,result:str) -> None:
        if callback:
            try:
                callback(success, result)
            except Exception as ex:
                logger.error(f"回调函数执行失败: {str(ex)}")

