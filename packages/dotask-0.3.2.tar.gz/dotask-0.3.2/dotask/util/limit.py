import time
from threading import Lock


class TokenBucket:
    """
    令牌桶限流
    - capacity: 令牌桶最大容量
    - rate: 令牌生成速率 (每秒生成多少个令牌)
    """
    def __init__(self,capacity:int,rate:float):
        self.capacity = max(1,capacity)
        self.rate = max(0.0001,rate)
        # 当前令牌数量
        self.tokens = capacity
        # 上次填充令牌的时间
        self.last_refill_time = time.time()
        self.lock = Lock()

    def get_token(self,block:bool=False) -> bool:
        """
        获取令牌
        :param block: 是否阻塞等待令牌(True：阻塞直到获取到令牌，Flase：非阻塞，获取不到直接返回False)
        :return: 是否成功获取令牌
        """
        with self.lock:
            # 1.填充令牌（根据上次填充时间和速率计算应该补充的令牌数）
            now = time.time()
            time_elapsed = now - self.last_refill_time
            # 新生成令牌数=时间间隔*令牌生成速率
            new_tokens = time_elapsed * self.rate
            # 取最小，防止令牌数超过桶的最大容量(防止超发)
            self.tokens = min(self.capacity,self.tokens+new_tokens)
            self.last_refill_time = now

            # 2.尝试获取令牌
            if self.tokens >= 1:
                self.tokens -= 1
                return True
            elif block:
                # 计算需要等待的时间
                # 需要等待的时间=（需要的令牌数-当前令牌数）/令牌生成速率
                wait_time = (1-self.tokens)/self.rate
                time.sleep(wait_time)
                # 安全消耗1个令牌,避免令牌数为负
                self.tokens = max(0,self.tokens-1)
                return True
            else:
                return False




















