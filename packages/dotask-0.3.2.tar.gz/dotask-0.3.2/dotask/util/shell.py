import threading
from dotask.util import logger
import subprocess
from typing import Optional,Callable

class Shell:
    # _shell_semaphore:threading.Semaphore = None
    # _semaphore_lock = threading.Lock()

    def __init__(self,max_concurrent:int=1):
        if max_concurrent <= 0:
            raise ValueError("Maximum concurrency must be greater than 0")
        self._shell_semaphore = threading.Semaphore(max_concurrent)
        self._max_concurrent = max_concurrent

    def local_shell_execute(self,cmd:str,callback: Optional[Callable[[bool, str], None]] = None) -> bool:
        def execute_and_wait():
            with self._shell_semaphore:
                truncated_cmd = cmd[:50] + "..." if len(cmd) > 50 else cmd
                logger.debug(f"Instance {id(self)}: Remaining concurrency quota {self._shell_semaphore._value} | Executing command: {truncated_cmd}")
                proc = None
                try:
                    # 创建并执行命令
                    proc = subprocess.Popen(
                        cmd,
                        shell=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        encoding='utf-8',
                    )
                    # 等待命令完成（阻塞，直到命令执行结束）
                    stdout, stderr = proc.communicate()

                    # 处理结果
                    if proc.returncode == 0:
                        logger.debug(f"Command Succeeded: {truncated_cmd}")
                        self._callback(callback,success=True, result=stdout.strip())
                    else:
                        error_msg = f"Code：{proc.returncode}，Error_msg：{stderr.strip()}"
                        logger.error(f"Command Failed: {truncated_cmd} → {error_msg}")
                        self._callback(callback,success=False, result=error_msg)

                except Exception as ex:
                    logger.error(f"Command Failed: {truncated_cmd} → {str(ex)}")
                    self._callback(callback,success=False, result=str(ex))
                finally:
                    if proc is not None:
                        if proc.poll() is None:
                            proc.kill()
                            proc.communicate()
                        # 关闭管道，释放资源
                        proc.stdout.close()
                        proc.stderr.close()

        try:
            # 启动线程执行命令（守护线程，不阻塞主线程）
            safe_cmd_name = cmd[:20].replace(' ', '_').replace('/', '_').replace('\\', '_').replace('|', '_')+ "..." if len(cmd) > 20 else cmd
            exec_thread = threading.Thread(
                target=execute_and_wait,
                daemon=True,
                name=f"CmdExecutor-{safe_cmd_name}"
            )
            exec_thread.start()
            logger.debug(f"Task submitted: {safe_cmd_name}")
            return True
        except Exception as e:
            logger.error(f"Task submission failed: {cmd} → {str(e)}")
            self._callback(callback,success=False,result=str(e))
            return False

    @staticmethod
    def _callback(callback: Optional[Callable[[bool, str], None]],success:bool,result:str) -> None:
        if callback:
            try:
                callback(success, result)
            except Exception as ex:
                logger.error(f"Callback function execution failed: {str(ex)}")

