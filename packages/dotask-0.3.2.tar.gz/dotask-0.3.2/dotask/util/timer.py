import threading
from dotask.util import logger

class Timer:
    def __init__(self,interval:float,task):
        self.interval = interval
        self.task = task
        # 存储定时对象
        self.timer = None
        # 标记定时器是否运行
        self.is_running = False
    def _run_task(self):
        """
        内部方法:执行任务并重启定时器
        """
        self.is_running = True
        try:
            self.task()
        finally:
            # 任务完毕后，重新创建定时器
            self.timer = threading.Timer(self.interval, self._run_task)
            self.timer.start()
    def start(self):
        if not self.is_running:
            self.timer = threading.Timer(self.interval, self._run_task)
            self.timer.start()
            logger.info(f"Timer started,runs every {self.interval} seconds")
    def stop(self):
        if self.timer and self.is_running:
            self.timer.cancel()
            self.is_running = False
            logger.info(f"Timer stopped")