# Changelog

## 0.1.0
- Initial release: upward root discovery, Next.js-style env layering, helpful missing-var errors, CLI.
