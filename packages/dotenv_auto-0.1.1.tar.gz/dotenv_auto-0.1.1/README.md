# dotenv-auto — “the .env that just works”

`dotenv-auto` auto-loads `.env` files with sensible precedence (Next.js-style layering) by walking up your
directory tree, and gives you **excellent** error messages when required variables are missing.

## Install

```bash
pip install dotenv-auto
```

## Quickstart

```python
from dotenv_auto import load, require

load()
require("DATABASE_URL")
```

## File layering (Next.js-style)

Project root discovery: walk upward from `cwd` until one of these exists: `.git/`, `pyproject.toml`,
`setup.cfg`, `setup.py`, or `.envroot`.

Load order (low → high precedence; later overrides earlier):

- env=development (default): `.env` → `.env.development` → `.env.local` → `.env.development.local`
- env=test: `.env` → `.env.test` → `.env.test.local` (note: `.env.local` is NOT loaded)
- env=production: `.env` → `.env.production` → `.env.local` → `.env.production.local`

Select env via:
- `load(env="production")`
- `DOTENV_AUTO_ENV=production`
- `NODE_ENV=production`

## CLI

```bash
dotenv-auto --env production --require DATABASE_URL --print
```

## License

MIT — see `LICENSE`.
