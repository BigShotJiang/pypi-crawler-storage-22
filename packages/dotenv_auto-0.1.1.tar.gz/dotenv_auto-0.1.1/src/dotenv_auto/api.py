from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, TypeVar, overload

from .discovery import candidate_env_files, find_project_root, select_hint_file
from .errors import MissingEnvVarError
from .parser import parse_dotenv_lines
from .report import LoadReport

_T = TypeVar("_T")


def _default_env() -> str:
    return (
        os.environ.get("DOTENV_AUTO_ENV")
        or os.environ.get("NODE_ENV")
        or os.environ.get("ENV")
        or "development"
    ).strip() or "development"


def load(
    *,
    env: str | None = None,
    start_dir: str | os.PathLike[str] | None = None,
    root: str | os.PathLike[str] | None = None,
    override: bool = False,
    verbose: bool = False,
) -> LoadReport:
    resolved_env = (env or _default_env()).strip() or "development"

    if root is not None:
        project_root = Path(root).expanduser().resolve()
    else:
        sd = Path(start_dir).expanduser().resolve() if start_dir else Path.cwd().resolve()
        project_root = find_project_root(sd)

    loaded: list[Path] = []
    applied: dict[str, str] = {}
    skipped_existing: list[str] = []

    if project_root is None:
        return LoadReport(env=resolved_env, project_root=None, loaded_files=tuple(), applied={}, skipped_existing=tuple())

    for f in candidate_env_files(project_root, resolved_env):
        if not f.exists() or not f.is_file():
            continue

        text = f.read_text(encoding="utf-8", errors="replace")
        parsed = parse_dotenv_lines(text.splitlines(True), filename=str(f))

        if verbose and parsed.warnings:
            for wmsg in parsed.warnings:
                print(f"[dotenv-auto] warning: {wmsg}")

        for k, v in parsed.items.items():
            if not override and k in os.environ:
                skipped_existing.append(k)
                continue
            os.environ[k] = v
            applied[k] = v

        loaded.append(f)
        if verbose:
            print(f"[dotenv-auto] loaded: {f}")

    return LoadReport(
        env=resolved_env,
        project_root=project_root,
        loaded_files=tuple(loaded),
        applied=applied,
        skipped_existing=tuple(skipped_existing),
    )


def require(*names: str, env: str | None = None) -> None:
    missing = tuple(n for n in names if not os.environ.get(n))
    if not missing:
        return

    resolved_env = (env or _default_env()).strip() or "development"
    project_root = find_project_root(Path.cwd())
    loaded_files: list[str] = []
    if project_root is not None:
        for f in candidate_env_files(project_root, resolved_env):
            if f.exists() and f.is_file():
                loaded_files.append(str(f))

    hint = select_hint_file(project_root, resolved_env) if project_root else None
    raise MissingEnvVarError(
        missing=missing,
        env=resolved_env,
        project_root=str(project_root) if project_root else None,
        loaded_files=tuple(loaded_files),
        hint_file=hint,
        extra=(
            "Tip: call dotenv_auto.load() early (before importing modules that read env vars).\n"
            "If you're running tests, set DOTENV_AUTO_ENV=test to enable .env.test layering."
        ),
    )


@overload
def get(name: str, default: None = None, *, cast: None = None) -> str | None: ...
@overload
def get(name: str, default: str, *, cast: None = None) -> str: ...
@overload
def get(name: str, default: _T, *, cast: Callable[[str], _T]) -> _T: ...


def get(name: str, default: _T | None = None, *, cast: Callable[[str], _T] | None = None):
    val = os.environ.get(name)
    if val is None or val == "":
        return default
    if cast is None:
        return val
    return cast(val)
