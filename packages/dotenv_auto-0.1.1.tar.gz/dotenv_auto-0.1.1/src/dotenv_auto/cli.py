from __future__ import annotations

import argparse
import json
import sys

from .api import load, require


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="dotenv-auto",
        description="Auto-load layered .env files with sane precedence and helpful diagnostics.",
    )
    p.add_argument("--env", default=None, help="Environment name (development/test/production/...)")
    p.add_argument("--start-dir", default=None, help="Where to start root discovery (default: cwd)")
    p.add_argument("--root", default=None, help="Explicit project root (skip discovery)")
    p.add_argument("--override", action="store_true", help="Override existing os.environ values")
    p.add_argument("--verbose", action="store_true", help="Print loaded files and parse warnings")
    p.add_argument("--require", nargs="*", default=[], help="Require variables after loading (missing -> exit 2)")
    p.add_argument("--print", dest="do_print", action="store_true", help="Print JSON of vars loaded by dotenv-auto")
    args = p.parse_args(argv)

    report = load(env=args.env, start_dir=args.start_dir, root=args.root, override=args.override, verbose=args.verbose)

    if args.require:
        try:
            require(*args.require, env=args.env)
        except Exception as e:
            print(str(e), file=sys.stderr)
            return 2

    if args.do_print:
        print(json.dumps(report.applied, indent=2, sort_keys=True))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
