from __future__ import annotations

from pathlib import Path

_ROOT_MARKERS = (".envroot", "pyproject.toml", "setup.cfg", "setup.py")


def find_project_root(start_dir: Path) -> Path | None:
    cur = start_dir.resolve()
    if cur.is_file():
        cur = cur.parent

    for p in [cur, *cur.parents]:
        if (p / ".git").exists():
            return p
        for marker in _ROOT_MARKERS:
            if (p / marker).exists():
                return p
    return None


def candidate_env_files(root: Path, env: str) -> tuple[Path, ...]:
    env = env.strip() or "development"
    files: list[Path] = [root / ".env", root / f".env.{env}"]
    if env != "test":
        files.append(root / ".env.local")
    files.append(root / f".env.{env}.local")
    return tuple(files)


def select_hint_file(root: Path | None, env: str) -> str | None:
    if root is None:
        return None

    env = env.strip() or "development"
    if env == "test":
        candidates = [root / ".env.test.local", root / ".env.test", root / ".env"]
    else:
        candidates = [root / ".env.local", root / f".env.{env}.local", root / f".env.{env}", root / ".env"]

    for c in candidates:
        if c.exists():
            return str(c)
    return str(candidates[0]) if candidates else str(root / ".env")
