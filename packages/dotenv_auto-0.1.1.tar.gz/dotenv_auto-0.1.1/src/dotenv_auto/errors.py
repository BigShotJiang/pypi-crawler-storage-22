from __future__ import annotations

from dataclasses import dataclass


class DotenvAutoError(RuntimeError):
    """Base error type for dotenv-auto."""


@dataclass(frozen=True)
class MissingEnvVarError(DotenvAutoError):
    missing: tuple[str, ...]
    env: str
    project_root: str | None
    loaded_files: tuple[str, ...]
    hint_file: str | None
    extra: str | None = None

    def __str__(self) -> str:
        missing_list = ", ".join(self.missing)
        lines: list[str] = []
        lines.append(f"Missing required environment variable(s): {missing_list}")
        lines.append("")
        lines.append(f"Detected env: {self.env!r}")
        lines.append(f"Project root: {self.project_root or '(not detected)'}")
        lines.append("")

        if self.loaded_files:
            lines.append("Loaded .env files (in order):")
            for f in self.loaded_files:
                lines.append(f"  - {f}")
        else:
            lines.append("Loaded .env files: (none found)")
        lines.append("")

        if self.hint_file:
            lines.append("Fix:")
            lines.append(f"  Add the missing value(s) to: {self.hint_file}")
            lines.append("  Example:")
            for k in self.missing:
                lines.append(f"    {k}=...")
            lines.append("")
        if self.extra:
            lines.append(self.extra.rstrip())
        return "\n".join(lines)
