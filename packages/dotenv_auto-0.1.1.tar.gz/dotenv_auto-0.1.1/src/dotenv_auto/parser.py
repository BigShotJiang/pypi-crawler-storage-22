from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable

# Very small, dependency-free dotenv parser.
#
# Supported:
#   KEY=value
#   KEY="value with spaces"
#   KEY='single-quoted'
#   export KEY=value
# Comments:
#   For unquoted values, trailing " # ..." is stripped.
# Escapes:
#   For double-quoted values, \n and \t and \" are interpreted.

_LINE_RE = re.compile(r'^\s*(?:export\s+)?(?P<key>[A-Za-z_][A-Za-z0-9_\.]*)\s*=\s*(?P<val>.*?)\s*$')
_COMMENT_SPLIT_RE = re.compile(r'(?P<val>.*?)(?P<comment>\s+#.*)?$')


@dataclass(frozen=True)
class ParsedEnv:
    items: dict[str, str]
    warnings: tuple[str, ...]


def _unquote(v: str) -> str:
    if len(v) >= 2 and ((v[0] == v[-1] == '"') or (v[0] == v[-1] == "'")):
        inner = v[1:-1]
        if v[0] == '"':
            inner = (
                inner.replace(r"\n", "\n".encode("utf-8").decode("unicode_escape"))
                .replace(r"\t", "\t".encode("utf-8").decode("unicode_escape"))
                .replace(r"\\", "\\")
                .replace(r"\"", '"')
            )
        return inner
    return v


def parse_dotenv_lines(lines: Iterable[str], *, filename: str = "<string>") -> ParsedEnv:
    items: dict[str, str] = {}
    warnings: list[str] = []

    for idx, raw in enumerate(lines, start=1):
        line = raw.rstrip("\n")
        stripped = line.strip()

        if not stripped or stripped.startswith("#"):
            continue

        m = _LINE_RE.match(line)
        if not m:
            warnings.append(f"{filename}:{idx}: could not parse line: {line!r}")
            continue

        key = m.group("key")
        val = m.group("val").strip()

        if val == "":
            items[key] = ""
            continue

        if (val.startswith('"') and val.endswith('"')) or (val.startswith("'") and val.endswith("'")):
            items[key] = _unquote(val)
        else:
            cm = _COMMENT_SPLIT_RE.match(val)
            assert cm is not None
            v2 = cm.group("val").rstrip()
            items[key] = _unquote(v2)

    return ParsedEnv(items=items, warnings=tuple(warnings))
