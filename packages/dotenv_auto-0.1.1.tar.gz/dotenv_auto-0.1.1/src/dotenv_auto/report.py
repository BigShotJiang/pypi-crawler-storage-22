from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class LoadReport:
    env: str
    project_root: Path | None
    loaded_files: tuple[Path, ...]
    applied: dict[str, str]
    skipped_existing: tuple[str, ...]
