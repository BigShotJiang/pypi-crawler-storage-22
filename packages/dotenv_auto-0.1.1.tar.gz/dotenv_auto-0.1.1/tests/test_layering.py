from __future__ import annotations

import os
from pathlib import Path

import pytest

from dotenv_auto import load


def write(p: Path, s: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(s, encoding="utf-8")


@pytest.fixture(autouse=True)
def clean_env(monkeypatch: pytest.MonkeyPatch):
    for k in list(os.environ.keys()):
        if k in {"A", "B", "C", "D", "NODE_ENV", "ENV", "DOTENV_AUTO_ENV"}:
            monkeypatch.delenv(k, raising=False)


def test_development_layering(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    root = tmp_path / "proj"
    (root / ".git").mkdir(parents=True)
    write(root / ".env", "A=base\nB=base\n")
    write(root / ".env.development", "B=dev\nC=dev\n")
    write(root / ".env.local", "C=local\nD=local\n")
    write(root / ".env.development.local", "D=devlocal\n")

    monkeypatch.chdir(root)
    report = load(env="development")

    assert os.environ["A"] == "base"
    assert os.environ["B"] == "dev"
    assert os.environ["C"] == "local"
    assert os.environ["D"] == "devlocal"
    assert [p.name for p in report.loaded_files] == [
        ".env",
        ".env.development",
        ".env.local",
        ".env.development.local",
    ]


def test_test_layering_skips_env_local(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    root = tmp_path / "proj"
    (root / ".git").mkdir(parents=True)
    write(root / ".env", "A=base\nB=base\n")
    write(root / ".env.local", "B=local_should_not_load\n")
    write(root / ".env.test", "B=test\nC=test\n")
    write(root / ".env.test.local", "C=testlocal\n")

    monkeypatch.chdir(root)
    report = load(env="test")

    assert os.environ["A"] == "base"
    assert os.environ["B"] == "test"
    assert os.environ["C"] == "testlocal"
    assert ".env.local" not in [p.name for p in report.loaded_files]
