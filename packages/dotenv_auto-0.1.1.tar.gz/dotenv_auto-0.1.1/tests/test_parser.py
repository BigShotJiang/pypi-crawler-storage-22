from __future__ import annotations

from dotenv_auto.parser import parse_dotenv_lines


def test_parser_basic_and_comments():
    parsed = parse_dotenv_lines(
        [
            "A=1\n",
            "B=hello # trailing comment\n",
            "C='x # not comment'\n",
            'D="y\\nline"\n',
            "export E=ok\n",
            "BROKEN LINE\n",
        ],
        filename="x.env",
    )

    assert parsed.items["A"] == "1"
    assert parsed.items["B"] == "hello"
    assert parsed.items["C"] == "x # not comment"
    assert parsed.items["D"] == "y\nline"
    assert parsed.items["E"] == "ok"
    assert parsed.warnings
