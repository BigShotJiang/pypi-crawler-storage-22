from __future__ import annotations

from pathlib import Path

import pytest

from dotenv_auto import MissingEnvVarError, load, require


def write(p: Path, s: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(s, encoding="utf-8")


def test_require_message_contains_context(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    root = tmp_path / "proj"
    (root / ".git").mkdir(parents=True)
    write(root / ".env", "A=base\n")
    monkeypatch.chdir(root)
    load(env="development")

    with pytest.raises(MissingEnvVarError) as ei:
        require("A", "MISSING_ONE", "MISSING_TWO", env="development")

    msg = str(ei.value)
    assert "Missing required environment variable(s)" in msg
    assert "MISSING_ONE" in msg and "MISSING_TWO" in msg
    assert ".env" in msg
