def main():
    print("Hello from doxastic!")


if __name__ == "__main__":
    main()
