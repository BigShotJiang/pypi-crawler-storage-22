"""Configuration module."""

from dpbench.config.prompts import TEMPLATE_VARIABLES, get_template_variables

__all__ = ["TEMPLATE_VARIABLES", "get_template_variables"]
