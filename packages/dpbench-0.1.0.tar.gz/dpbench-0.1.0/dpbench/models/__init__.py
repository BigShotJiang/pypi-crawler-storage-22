"""Model interface."""

from dpbench.models.base import ModelFunction, validate_model_function

__all__ = ["ModelFunction", "validate_model_function"]
