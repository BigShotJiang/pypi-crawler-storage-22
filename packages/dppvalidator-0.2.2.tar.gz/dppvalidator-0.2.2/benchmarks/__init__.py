"""Performance benchmarks for dppvalidator."""
