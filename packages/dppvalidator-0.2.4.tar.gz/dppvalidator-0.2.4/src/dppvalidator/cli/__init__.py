"""Command-line interface for dppvalidator."""

from dppvalidator.cli.main import cli, main

__all__ = ["cli", "main"]
