=====
Usage
=====

To use dq db manager in a project::

    import dq_db_manager
