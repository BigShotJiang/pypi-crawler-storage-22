"""Top-level package for dq db manager."""

__author__ = """shiva kharbanda"""
__email__ = 'shivakharbanda21@gmail.com'
__version__ = '0.2.0'
