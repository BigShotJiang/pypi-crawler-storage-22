# SQLite handler module
