#!/usr/bin/env python

"""Tests for `dq_db_manager` package."""


import unittest

from dq_db_manager import dq_db_manager


class TestDq_db_manager(unittest.TestCase):
    """Tests for `dq_db_manager` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
