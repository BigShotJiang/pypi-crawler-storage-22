"""Pytest configuration for dqlite-dbapi tests."""
