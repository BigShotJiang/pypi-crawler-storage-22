"""Primitive type encoding/decoding for dqlite wire protocol.

All multi-byte integers are little-endian.
Text is null-terminated UTF-8, padded to 8-byte boundary.
"""

import struct
from typing import Any

from dqlitewire.constants import WORD_SIZE, ValueType
from dqlitewire.exceptions import DecodeError, EncodeError


def encode_uint64(value: int) -> bytes:
    """Encode an unsigned 64-bit integer (little-endian)."""
    if not 0 <= value < 2**64:
        raise EncodeError(f"Value {value} out of range for uint64")
    return struct.pack("<Q", value)


def decode_uint64(data: bytes) -> int:
    """Decode an unsigned 64-bit integer (little-endian)."""
    if len(data) < 8:
        raise DecodeError(f"Need 8 bytes for uint64, got {len(data)}")
    result: int = struct.unpack("<Q", data[:8])[0]
    return result


def encode_int64(value: int) -> bytes:
    """Encode a signed 64-bit integer (little-endian)."""
    if not -(2**63) <= value < 2**63:
        raise EncodeError(f"Value {value} out of range for int64")
    return struct.pack("<q", value)


def decode_int64(data: bytes) -> int:
    """Decode a signed 64-bit integer (little-endian)."""
    if len(data) < 8:
        raise DecodeError(f"Need 8 bytes for int64, got {len(data)}")
    result: int = struct.unpack("<q", data[:8])[0]
    return result


def encode_uint32(value: int) -> bytes:
    """Encode an unsigned 32-bit integer (little-endian)."""
    if not 0 <= value < 2**32:
        raise EncodeError(f"Value {value} out of range for uint32")
    return struct.pack("<I", value)


def decode_uint32(data: bytes) -> int:
    """Decode an unsigned 32-bit integer (little-endian)."""
    if len(data) < 4:
        raise DecodeError(f"Need 4 bytes for uint32, got {len(data)}")
    result: int = struct.unpack("<I", data[:4])[0]
    return result


def encode_double(value: float) -> bytes:
    """Encode a 64-bit floating point number (little-endian)."""
    return struct.pack("<d", value)


def decode_double(data: bytes) -> float:
    """Decode a 64-bit floating point number (little-endian)."""
    if len(data) < 8:
        raise DecodeError(f"Need 8 bytes for double, got {len(data)}")
    result: float = struct.unpack("<d", data[:8])[0]
    return result


def pad_to_word(size: int) -> int:
    """Calculate padding needed to align to word boundary."""
    remainder = size % WORD_SIZE
    if remainder == 0:
        return 0
    return WORD_SIZE - remainder


def encode_text(value: str) -> bytes:
    """Encode text as null-terminated UTF-8, padded to 8-byte boundary."""
    encoded = value.encode("utf-8") + b"\x00"
    padding = pad_to_word(len(encoded))
    return encoded + (b"\x00" * padding)


def decode_text(data: bytes) -> tuple[str, int]:
    """Decode null-terminated UTF-8 text.

    Returns the decoded string and the number of bytes consumed (including padding).
    """
    # Find null terminator
    try:
        null_pos = data.index(b"\x00")
    except ValueError as e:
        raise DecodeError("Text not null-terminated") from e

    text = data[:null_pos].decode("utf-8")
    # Calculate total size including padding
    total_size = null_pos + 1 + pad_to_word(null_pos + 1)
    return text, total_size


def encode_blob(value: bytes) -> bytes:
    """Encode a blob (length-prefixed binary data, padded to 8-byte boundary).

    Format: uint64 length + data + padding
    """
    length = len(value)
    padding = pad_to_word(length)
    return encode_uint64(length) + value + (b"\x00" * padding)


def decode_blob(data: bytes) -> tuple[bytes, int]:
    """Decode a blob.

    Returns the blob data and the number of bytes consumed.
    """
    if len(data) < 8:
        raise DecodeError("Not enough data for blob length")

    length = decode_uint64(data[:8])
    total_size = 8 + length + pad_to_word(length)

    if len(data) < total_size:
        raise DecodeError(f"Not enough data for blob: need {total_size}, got {len(data)}")

    return data[8 : 8 + length], total_size


def encode_value(value: Any, value_type: ValueType | None = None) -> tuple[bytes, ValueType]:
    """Encode a Python value to wire format.

    If value_type is not provided, it's inferred from the Python type.
    Returns (encoded_data, value_type).
    """
    if value is None:
        return b"\x00" * 8, ValueType.NULL

    if value_type is None:
        if isinstance(value, bool):
            value_type = ValueType.BOOLEAN
        elif isinstance(value, int):
            value_type = ValueType.INTEGER
        elif isinstance(value, float):
            value_type = ValueType.FLOAT
        elif isinstance(value, str):
            value_type = ValueType.TEXT
        elif isinstance(value, bytes):
            value_type = ValueType.BLOB
        else:
            raise EncodeError(f"Cannot infer type for value: {type(value)}")

    if value_type in (ValueType.INTEGER, ValueType.UNIXTIME, ValueType.BOOLEAN):
        if isinstance(value, bool):
            value = 1 if value else 0
        return encode_int64(value), value_type
    elif value_type == ValueType.FLOAT:
        return encode_double(value), value_type
    elif value_type in (ValueType.TEXT, ValueType.ISO8601):
        return encode_text(value), value_type
    elif value_type == ValueType.BLOB:
        return encode_blob(value), value_type
    elif value_type == ValueType.NULL:
        return b"\x00" * 8, value_type
    else:
        raise EncodeError(f"Unknown value type: {value_type}")


def decode_value(data: bytes, value_type: ValueType) -> tuple[Any, int]:
    """Decode a value from wire format.

    Returns (value, bytes_consumed).
    """
    if value_type in (ValueType.INTEGER, ValueType.UNIXTIME, ValueType.BOOLEAN):
        value = decode_int64(data)
        if value_type == ValueType.BOOLEAN:
            value = bool(value)
        return value, 8
    elif value_type == ValueType.FLOAT:
        return decode_double(data), 8
    elif value_type in (ValueType.TEXT, ValueType.ISO8601):
        return decode_text(data)
    elif value_type == ValueType.BLOB:
        return decode_blob(data)
    elif value_type == ValueType.NULL:
        return None, 8
    else:
        raise DecodeError(f"Unknown value type: {value_type}")
