"""Pytest configuration for dqlite-wire tests."""
