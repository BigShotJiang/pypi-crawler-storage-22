# DreaminAI

AI-powered creative platform for image and video generation with powerful capabilities.

## Official Website

Visit: [https://dreaminai.net](https://dreaminai.net)

## Features

- AI-driven image generation
- AI-powered video creation
- Fast and efficient processing
- Rich creative possibilities
- Easy to integrate

## Installation

```bash
pip install dreaminai
```

## Usage

```python
from dreaminai import get_info, get_platform_url

# Get platform information
info = get_info()
print(info)

# Get the official website URL
url = get_platform_url()
print(url)  # https://dreaminai.net
```

## Documentation

Full documentation available at: [https://dreaminai.net](https://dreaminai.net)

## Links

- Website: [https://dreaminai.net](https://dreaminai.net)
- PyPI: [https://pypi.org/project/dreaminai/](https://pypi.org/project/dreaminai/)

## License

MIT License - see LICENSE file for details.
