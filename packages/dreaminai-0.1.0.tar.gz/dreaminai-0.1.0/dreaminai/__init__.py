"""
DreaminAI - AI-powered creative platform for image and video generation.

Official Website: https://dreaminai.net

An innovative AI creative tool with powerful image and video generation capabilities.
"""

__version__ = "0.1.0"
__website__ = "https://dreaminai.net"

VERSION = __version__
WEBSITE = __website__


def get_info():
    """
    Get package information.

    Returns:
        dict: Package information including name, version, and website.
    """
    return {
        "name": "DreaminAI",
        "version": VERSION,
        "website": WEBSITE,
        "description": "AI-powered creative platform for image and video generation"
    }


def get_platform_url():
    """
    Get the official platform URL.

    Returns:
        str: The official website URL.
    """
    return WEBSITE


def get_version():
    """
    Get the current version.

    Returns:
        str: Version string.
    """
    return VERSION


if __name__ == "__main__":
    print("DreaminAI - AI-powered creative platform")
    print(f"Website: {WEBSITE}")
    print(f"Version: {VERSION}")
