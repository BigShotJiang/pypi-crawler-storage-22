"""TUI Catalog Explorer package."""
