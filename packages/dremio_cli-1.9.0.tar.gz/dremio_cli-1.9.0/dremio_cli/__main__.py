"""Main entry point for the Dremio CLI."""

from dremio_cli.cli import main

if __name__ == "__main__":
    main()
