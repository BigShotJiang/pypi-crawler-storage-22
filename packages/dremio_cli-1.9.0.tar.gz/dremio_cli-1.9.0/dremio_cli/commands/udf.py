"""udf commands."""

import click

@click.group()
def udf() -> None:
    """Udf operations."""
    pass

