"""
Dremio-as-Code (DAC) module.
"""
