"""
Drevoid - A terminal-based LAN chat application with rooms and private messaging.
"""

__version__ = "1.0.1"
__author__ = "Drevoid Team"
__license__ = "MIT"

from drevoid.core.protocol import (
    MessageType,
    UserRole,
    RoomType,
    create_message,
    serialize_message,
    deserialize_message,
)

__all__ = [
    "MessageType",
    "UserRole",
    "RoomType",
    "create_message",
    "serialize_message",
    "deserialize_message",
]
