"""
Main chat client implementation.
"""

import threading
from drevoid.core.protocol import MessageType, create_message, Colors, colorize
from drevoid.client.connection import ConnectionManager, MessageBuffer
from drevoid.client.room_manager import RoomManager
from drevoid.client.flag_detector import FlagDetector
from drevoid.client.message_handler import MessageHandler
from drevoid.utils.notifications import NotificationManager


class ChatClient:
    def __init__(self):
        self.connection_manager = ConnectionManager()
        self.room_manager = RoomManager(self.connection_manager)
        self.flag_detector = FlagDetector()
        self.notification_manager = NotificationManager()
        self.message_handler = MessageHandler(self.flag_detector, self.connection_manager, self.notification_manager)
        self.message_buffer = MessageBuffer()
        self.shell = None
        self.receive_thread = None

    @property
    def connected(self) -> bool:
        return self.connection_manager.connected

    @property
    def username(self) -> str:
        return self.connection_manager.username

    @property
    def current_room(self) -> str:
        return self.room_manager.current_room

    def connect(self, host: str = 'localhost', port: int = 12345, username: str = '') -> bool:
        if not self.connection_manager.connect(host, port):
            return False

        self.connection_manager.username = username
        self.message_handler.set_username(username)

        self.receive_thread = threading.Thread(target=self._receive_loop, daemon=True)
        self.receive_thread.start()

        if username:
            connect_msg = create_message(MessageType.CONNECT, {"username": username})
            self.connection_manager.send_data(connect_msg)

        return True

    def disconnect(self):
        if self.connected:
            try:
                disconnect_msg = create_message(MessageType.DISCONNECT, {})
                self.connection_manager.send_data(disconnect_msg)
            except:
                pass
            self.connection_manager.disconnect()
            print(f"{colorize('👋 Disconnected from server', Colors.YELLOW)}")

    def send_message(self, content: str) -> bool:
        if not self.connected:
            return False
        message = create_message(MessageType.MESSAGE, {"content": content})
        return self.connection_manager.send_data(message)

    def send_private_message(self, target_user: str, content: str) -> bool:
        if not self.connected:
            return False
        message = create_message(MessageType.PRIVATE_MESSAGE, {
            "target": target_user,
            "content": content
        })
        return self.connection_manager.send_data(message)

    def kick_user(self, username: str) -> bool:
        if not self.connected:
            return False
        message = create_message(MessageType.KICK_USER, {"username": username})
        return self.connection_manager.send_data(message)

    def ban_user(self, username: str) -> bool:
        if not self.connected:
            return False
        message = create_message(MessageType.BAN_USER, {"username": username})
        return self.connection_manager.send_data(message)

    def _receive_loop(self):
        while self.connected:
            data = self.connection_manager.receive_data()
            if data is None:
                break

            self.message_buffer.add_data(data)
            while True:
                message, has_message = self.message_buffer.get_message()
                if not has_message:
                    break
                self.message_handler.handle(message, self.current_room)
                if self.shell:
                    self.shell.show_prompt()

        self.connection_manager.disconnect()
        if self.shell:
            print(f"\n{colorize('Connection lost. Type connect to reconnect.', Colors.RED)}")

    def display_flags(self):
        message = create_message(MessageType.FLAG_REQUEST, {})
        self.connection_manager.send_data(message)


class ModerationCommands:
    def __init__(self, client: ChatClient):
        self.client = client

    def kick(self, username: str) -> bool:
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return False
        return self.client.kick_user(username)

    def ban(self, username: str) -> bool:
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return False
        return self.client.ban_user(username)
