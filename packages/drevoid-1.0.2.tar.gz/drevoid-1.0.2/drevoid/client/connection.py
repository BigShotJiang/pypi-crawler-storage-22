"""
Connection management for the chat client.
"""

import socket
from typing import Optional
from drevoid.core.protocol import serialize_message, deserialize_message, Colors, colorize


class ConnectionManager:
    def __init__(self):
        self.socket = None
        self.connected = False
        self.username = None

    def connect(self, host: str, port: int) -> bool:
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((host, port))
            self.connected = True
            return True
        except Exception as e:
            print(f"{colorize('❌ Connection failed:', Colors.RED)} {e}")
            self.connected = False
            return False

    def disconnect(self):
        if self.connected and self.socket:
            try:
                self.socket.close()
            except:
                pass
            self.connected = False

    def send_data(self, message: dict) -> bool:
        if not self.connected:
            return False
        try:
            data = serialize_message(message)
            self.socket.send(data)
            return True
        except Exception as e:
            print(f"{colorize('❌ Send error:', Colors.RED)} {e}")
            self.connected = False
            return False

    def receive_data(self, buffer_size: int = 4096) -> Optional[bytes]:
        if not self.connected:
            return None
        try:
            data = self.socket.recv(buffer_size)
            if not data:
                return None
            return data
        except Exception as e:
            if self.connected:
                print(f"{colorize('❌ Receive error:', Colors.RED)} {e}")
            return None


class MessageBuffer:
    def __init__(self):
        self.buffer = b''

    def add_data(self, data: bytes):
        self.buffer += data

    def get_message(self) -> tuple:
        message, self.buffer = deserialize_message(self.buffer)
        return message, message is not None

    def is_empty(self) -> bool:
        return len(self.buffer) == 0
