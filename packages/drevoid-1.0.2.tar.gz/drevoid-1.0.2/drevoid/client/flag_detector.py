"""
CTF flag detection and tracking.
"""

import re
import time
from enum import Enum
from dataclasses import dataclass
from typing import Dict, List


class FlagPattern(Enum):
    BRACE_FLAG = r'flag\{[^}]+\}'
    BRACE_FLAG_UPPER = r'FLAG\{[^}]+\}'
    BRACE_CTF = r'CTF\{[^}]+\}'
    BRACE_CTF_LOWER = r'ctf\{[^}]+\}'
    COLON_FLAG = r'flag:[A-Za-z0-9_\-]+'
    COLON_FLAG_UPPER = r'FLAG:[A-Za-z0-9_\-]+'
    MD5_HASH = r'[a-f0-9]{32}(?![a-f0-9])'
    SHA1_HASH = r'[a-f0-9]{40}(?![a-f0-9])'
    SHA256_HASH = r'[a-f0-9]{64}(?![a-f0-9])'


@dataclass
class Flag:
    content: str
    finder: str
    room: str
    timestamp: float
    message_preview: str


class FlagDetector:
    def __init__(self):
        self.flags_found: Dict[str, Flag] = {}
        self.patterns = [pattern.value for pattern in FlagPattern]

    def detect(self, content: str) -> List[str]:
        matches = []
        for pattern in self.patterns:
            found = re.findall(pattern, content, re.IGNORECASE)
            matches.extend(found)
        return list(set(matches))

    def store_flag(self, flag_content: str, finder: str, room: str, message_preview: str):
        if flag_content not in self.flags_found:
            self.flags_found[flag_content] = Flag(
                content=flag_content,
                finder=finder,
                room=room,
                timestamp=time.time(),
                message_preview=message_preview
            )
            return True
        return False

    def get_all_flags(self) -> List[Flag]:
        return list(self.flags_found.values())
