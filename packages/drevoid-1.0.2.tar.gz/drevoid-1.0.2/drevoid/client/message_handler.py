"""
Message handling and display for the chat client.
"""

import time
from typing import List
from drevoid.core.protocol import MessageType, create_message, Colors, colorize, format_timestamp
from drevoid.client.flag_detector import FlagDetector
from drevoid.client.connection import ConnectionManager
from drevoid.utils.notifications import NotificationManager
from drevoid.utils.emojis import EmojiAliasesInstance as EmojiAliases


class MessageHandler:
    def __init__(self, flag_detector: FlagDetector, connection_manager: ConnectionManager, notification_manager: NotificationManager):
        self.flag_detector = flag_detector
        self.connection_manager = connection_manager
        self.notification_manager = notification_manager
        self.username = None
        self.callbacks: List[callable] = []

    def set_username(self, username: str):
        self.username = username

    def subscribe(self, callback: callable):
        self.callbacks.append(callback)

    def _display_message(self, text: str):
        for callback in self.callbacks:
            callback(text)

    def _highlight_flags(self, content: str) -> str:
        highlighted = content
        flags = self.flag_detector.detect(content)
        for flag in flags:
            highlighted = highlighted.replace(
                flag,
                f"{colorize(flag, Colors.HIGHLIGHT + Colors.GREEN)}"
            )
        return highlighted

    def handle(self, message: dict, current_room: str):
        msg_type = message.get("type")
        data = message.get("data", {})
        timestamp = message.get("timestamp", time.time())
        time_str = format_timestamp(timestamp)

        if msg_type == MessageType.MESSAGE.value:
            self._handle_room_message(data, time_str)
        elif msg_type == MessageType.PRIVATE_MESSAGE.value:
            self._handle_private_message(data, time_str)
        elif msg_type == MessageType.NOTIFICATION.value:
            self._handle_notification(data, time_str)
        elif msg_type == MessageType.FLAG_RESPONSE.value:  
            self._handle_flag_response(data, time_str)
        elif msg_type == MessageType.SUCCESS.value:
            self._handle_success(data, time_str)
        elif msg_type == MessageType.ERROR.value:
            self._handle_error(data, time_str)

    def _handle_flag_response(self, data: dict, time_str: str):
        """Display flags received from server"""
        flags = data.get('flags', [])
        if not flags:
            display = f"{colorize('No flags found yet.', Colors.GRAY)}"
            self._display_message(display)
            return

        display = f"\n{colorize('🚩 Captured Flags:', Colors.BOLD + Colors.YELLOW)}"
        self._display_message(display)
        
        for idx, flag_info in enumerate(flags, 1):
            flag_timestamp = flag_info.get('timestamp', time.time())
            time_str = format_timestamp(flag_timestamp)
            
            display = f"  {idx}. {colorize(flag_info['content'], Colors.HIGHLIGHT + Colors.GREEN)}"
            self._display_message(display)
            
            display = f"     Found by: {colorize(flag_info['finder'], Colors.GREEN)} in #{colorize(flag_info['room'], Colors.BLUE)}"
            self._display_message(display)
            
            display = f"     Time: {colorize(time_str, Colors.GRAY)}"
            self._display_message(display)
            
            display = f"     Context: {flag_info['message_preview'][:60]}..."
            self._display_message(display)
            
            self._display_message("")  # Empty line for spacing

    def _handle_room_message(self, data: dict, time_str: str):
        username = data.get("username", "Unknown")
        content = data.get("content", "")
        room = data.get("room", "")

        content = EmojiAliases.replace(content)
        flags = self.flag_detector.detect(content)
        if flags:
            for flag in flags:
                self.flag_detector.store_flag(flag, username, room, content[:50])
                self.notification_manager.notify_flag_found(
                    self.flag_detector.flags_found[flag],
                    username
                )
                
                flag_submit_msg = create_message(MessageType.FLAG_SUBMIT, {
                    'content': flag,
                    'finder': username,
                    'room': room,
                    'message_preview': content[:50]
                })
                self.connection_manager.send_data(flag_submit_msg)

        if username == self.username:
            return

        highlighted_content = self._highlight_flags(content)
        display = f"\n{colorize(f'[{time_str}]', Colors.GRAY)} {colorize(f'{username}', Colors.CYAN)} in {colorize(f'#{room}', Colors.BLUE)}: {highlighted_content}"
        self._display_message(display)

    def _handle_private_message(self, data: dict, time_str: str):
        from_user = data.get("from", "Unknown")
        content = data.get("content", "")
        content = EmojiAliases.replace(content)
        highlighted_content = self._highlight_flags(content)
        display = f"\n{colorize(f'📩 [{time_str}] Private from {from_user}:', Colors.PURPLE)} {highlighted_content}"
        self._display_message(display)

    def _handle_notification(self, data: dict, time_str: str):
        message_text = data.get("message", "")
        display = f"\n{colorize(f'📢 [{time_str}]', Colors.YELLOW)} {message_text}"
        self._display_message(display)

    def _handle_success(self, data: dict, time_str: str):
        message_text = data.get("message", "")
        rooms = data.get("rooms", [])
        users = data.get("users", [])
        stats = data.get("stats", {})

        display = f"\n{colorize('✅', Colors.GREEN)} {message_text}"
        self._display_message(display)

        if rooms:
            display = f"\n{colorize('🏠 Available Rooms:', Colors.BOLD)}"
            self._display_message(display)
            for room in rooms:
                protection = "🔒" if room["password_protected"] else "🔓"
                room_type = f"({room['type']})"
                users_info = f"{room['users']}/{room['max_users']}"
                display = f"  {protection} {colorize(room['name'], Colors.CYAN)} {room_type} - {users_info} users"
                self._display_message(display)

        if users:
            display = f"\n{colorize('👥 Users in room:', Colors.BOLD)}"
            self._display_message(display)
            for user in users:
                role_color = Colors.RED if user["role"] == "admin" else Colors.YELLOW if user["is_moderator"] else Colors.WHITE
                role_symbol = "👑" if user["role"] == "admin" else "⭐" if user["is_moderator"] else "👤"
                display = f"  {role_symbol} {colorize(user['username'], role_color)}"
                self._display_message(display)

        if stats:
            uptime = stats.get("uptime", 0)
            hours = int(uptime // 3600)
            minutes = int((uptime % 3600) // 60)
            display = f"\n{colorize('📊 Server Stats:', Colors.BOLD)}"
            self._display_message(display)
            display = f"  Users: {stats.get('connected_users', 0)}"
            self._display_message(display)
            display = f"  Rooms: {stats.get('active_rooms', 0)}"
            self._display_message(display)
            display = f"  Uptime: {hours:02d}:{minutes:02d}"
            self._display_message(display)

    def _handle_error(self, data: dict, time_str: str):
        message_text = data.get("message", "")
        display = f"\n{colorize('❌ Error:', Colors.RED)} {message_text}"
        self._display_message(display)
