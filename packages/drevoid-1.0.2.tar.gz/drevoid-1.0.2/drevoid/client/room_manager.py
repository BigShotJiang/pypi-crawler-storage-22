"""
Room management for the chat client.
"""

from drevoid.core.protocol import MessageType, create_message
from drevoid.client.connection import ConnectionManager


class RoomManager:
    def __init__(self, connection_manager: ConnectionManager):
        self.connection_manager = connection_manager
        self.current_room = None

    def join(self, room_name: str, password: str = "") -> bool:
        message = create_message(MessageType.JOIN_ROOM, {
            "room_name": room_name,
            "password": password
        })
        if self.connection_manager.send_data(message):
            self.current_room = room_name
            return True
        return False

    def leave(self) -> bool:
        if not self.current_room:
            return False
        message = create_message(MessageType.LEAVE_ROOM, {})
        if self.connection_manager.send_data(message):
            self.current_room = None
            return True
        return False

    def create(self, room_name: str, room_type: str = "public", password: str = "") -> bool:
        message = create_message(MessageType.CREATE_ROOM, {
            "room_name": room_name,
            "room_type": room_type,
            "password": password
        })
        return self.connection_manager.send_data(message)

    def list_rooms(self) -> bool:
        message = create_message(MessageType.LIST_ROOMS, {})
        return self.connection_manager.send_data(message)

    def list_users(self) -> bool:
        message = create_message(MessageType.LIST_USERS, {})
        return self.connection_manager.send_data(message)
