"""
Interactive command shell for the chat client.
"""

import cmd
import os
import sys
from drevoid.core.protocol import Colors, colorize
from drevoid.client.chat_client import ChatClient, ModerationCommands
from drevoid.utils.emojis import EmojiAliasesInstance as EmojiAliases


class ChatShell(cmd.Cmd):
    def __init__(self, client: ChatClient):
        super().__init__()
        self.client = client
        self.moderation = ModerationCommands(client)
        self.setup_message_display()
        self.update_prompt()

    def setup_message_display(self):
        def display_callback(text: str):
            print(text)

        self.client.message_handler.subscribe(display_callback)

    def update_prompt(self):
        if self.client.connected and self.client.username:
            room_info = f"#{self.client.current_room}" if self.client.current_room else "#no-room"
            self.prompt = f"{colorize(self.client.username, Colors.CYAN)}{colorize(room_info, Colors.BLUE)} > "
        else:
            self.prompt = f"{colorize('Not connected', Colors.RED)} > "

    def show_prompt(self):
        self.update_prompt()
        if hasattr(self, 'stdout'):
            self.stdout.write(self.prompt)
            self.stdout.flush()

    def emptyline(self):
        pass

    def default(self, line):
        if not self.client.connected:
            print(f"{colorize('❌ Not connected. Use connect command first.', Colors.RED)}")
            return
        if not self.client.current_room:
            print(f"{colorize('❌ Not in any room. Use join command first.', Colors.RED)}")
            return
        if line.strip():
            self.client.send_message(line.strip())

    def do_help(self, arg):
        print(f"\n{colorize('🎯 Drevoid LAN Chat Commands:', Colors.BOLD)}")
        print(f"\n{colorize('Connection Commands:', Colors.YELLOW)}")
        print(f"  {colorize('connect [host] [port] [username]', Colors.CYAN)} - Connect to server")
        print(f"  {colorize('disconnect', Colors.CYAN)} - Disconnect from server")
        print(f"  {colorize('quit/exit', Colors.CYAN)} - Exit the application")

        print(f"\n{colorize('Room Commands:', Colors.YELLOW)}")
        print(f"  {colorize('join <room_name> [password]', Colors.CYAN)} - Join a room")
        print(f"  {colorize('leave', Colors.CYAN)} - Leave current room")
        print(f"  {colorize('create <room_name> [private] [password]', Colors.CYAN)} - Create a room")
        print(f"  {colorize('rooms', Colors.CYAN)} - List available rooms")
        print(f"  {colorize('users', Colors.CYAN)} - List users in current room")

        print(f"\n{colorize('Messaging Commands:', Colors.YELLOW)}")
        print(f"  {colorize('msg <username> <message>', Colors.CYAN)} - Send private message")
        print(f"  {colorize('pm <username> <message>', Colors.CYAN)} - Send private message (alias)")
        print(f"  {colorize('<message>', Colors.CYAN)} - Send message to current room")

        print(f"\n{colorize('CTF & Flag Commands:', Colors.YELLOW)}")
        print(f"  {colorize('flags', Colors.CYAN)} - Display all captured flags")
        print(f"  {colorize('flag-count', Colors.CYAN)} - Show total flags found")

        print(f"\n{colorize('Emoji Commands:', Colors.YELLOW)}")
        print(f"  {colorize('emojis', Colors.CYAN)} - Display all emoji aliases")

        print(f"\n{colorize('Moderation Commands:', Colors.YELLOW)}")
        print(f"  {colorize('kick <username>', Colors.CYAN)} - Kick user from room (moderators only)")
        print(f"  {colorize('ban <username>', Colors.CYAN)} - Ban user from room (moderators only)")

        print(f"\n{colorize('Other Commands:', Colors.YELLOW)}")
        print(f"  {colorize('status', Colors.CYAN)} - Show connection status")
        print(f"  {colorize('clear', Colors.CYAN)} - Clear screen")
        print(f"  {colorize('help', Colors.CYAN)} - Show this help\n")

    def do_connect(self, args):
        if self.client.connected:
            print(f"{colorize('❌ Already connected. Disconnect first.', Colors.RED)}")
            return

        parts = args.split()
        host = parts[0] if parts else input(f"{colorize('Enter server host (localhost):', Colors.CYAN)} ").strip() or 'localhost'

        try:
            port = int(parts[1]) if len(parts) > 1 else int(input(f"{colorize('Enter server port (12345):', Colors.CYAN)} ").strip() or '12345')
        except ValueError:
            print(f"{colorize('❌ Invalid port number', Colors.RED)}")
            return

        username = parts[2] if len(parts) > 2 else input(f"{colorize('Enter username:', Colors.CYAN)} ").strip()

        if not username:
            print(f"{colorize('❌ Username is required', Colors.RED)}")
            return

        print(f"{colorize('🔄 Connecting to', Colors.YELLOW)} {host}:{port} {colorize('as', Colors.YELLOW)} {username}...")

        if self.client.connect(host, port, username):
            print(f"{colorize('✅ Connected successfully!', Colors.GREEN)}")
            self.update_prompt()
        else:
            print(f"{colorize('❌ Connection failed', Colors.RED)}")

    def do_disconnect(self, args):
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return
        self.client.disconnect()
        self.update_prompt()

    def do_join(self, args):
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return

        parts = args.split(None, 1)
        if not parts:
            print(f"{colorize('❌ Usage: join <room_name> [password]', Colors.RED)}")
            return

        room_name = parts[0]
        password = parts[1] if len(parts) > 1 else ""

        if self.client.room_manager.join(room_name, password):
            self.update_prompt()

    def do_leave(self, args):
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return
        if not self.client.current_room:
            print(f"{colorize('❌ Not in any room', Colors.RED)}")
            return
        if self.client.room_manager.leave():
            self.update_prompt()

    def do_create(self, args):
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return

        parts = args.split()
        if not parts:
            print(f"{colorize('❌ Usage: create <room_name> [private] [password]', Colors.RED)}")
            return

        room_name = parts[0]
        room_type = "private" if len(parts) > 1 and parts[1].lower() == "private" else "public"
        password = parts[2] if len(parts) > 2 else ""

        self.client.room_manager.create(room_name, room_type, password)

    def do_rooms(self, args):
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return
        self.client.room_manager.list_rooms()

    def do_users(self, args):
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return
        if not self.client.current_room:
            print(f"{colorize('❌ Not in any room', Colors.RED)}")
            return
        self.client.room_manager.list_users()

    def do_msg(self, args):
        self._send_private_message(args)

    def do_pm(self, args):
        self._send_private_message(args)

    def do_emojis(self, args):
        print(f"\n{colorize('😊 Emoji Aliases', Colors.BOLD + Colors.YELLOW)}")
        print(f"{colorize('Use these secret phrases to add emojis to your messages:', Colors.GRAY)}\n")
        print(EmojiAliases.list_aliases())
        print(f"\n{colorize('Example:', Colors.YELLOW)} I love this :heart: :fire: :rocket:\n")

    def _send_private_message(self, args):
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return

        parts = args.split(None, 1)
        if len(parts) < 2:
            print(f"{colorize('❌ Usage: msg <username> <message>', Colors.RED)}")
            return

        target_user = parts[0]
        content = parts[1]
        self.client.send_private_message(target_user, content)

    def do_kick(self, args):
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return
        if not args.strip():
            print(f"{colorize('❌ Usage: kick <username>', Colors.RED)}")
            return
        self.moderation.kick(args.strip())

    def do_ban(self, args):
        if not self.client.connected:
            print(f"{colorize('❌ Not connected', Colors.RED)}")
            return
        if not args.strip():
            print(f"{colorize('❌ Usage: ban <username>', Colors.RED)}")
            return
        self.moderation.ban(args.strip())

    def do_flags(self, args):
        self.client.display_flags()

    def do_flag_count(self, args):
        count = len(self.client.flag_detector.get_all_flags())
        print(f"{colorize(f'🚩 Total flags captured: {count}', Colors.BOLD + Colors.YELLOW)}")

    def do_status(self, args):
        if self.client.connected:
            print(f"{colorize('✅ Connected as:', Colors.GREEN)} {self.client.username}")
            print(f"{colorize('🏠 Current room:', Colors.CYAN)} {self.client.current_room or 'None'}")
        else:
            print(f"{colorize('❌ Not connected', Colors.RED)}")

    def do_clear(self, args):
        os.system('cls' if os.name == 'nt' else 'clear')

    def do_quit(self, args):
        return self.do_exit(args)

    def do_exit(self, args):
        if self.client.room_manager.leave():
            self.update_prompt()
        if self.client.connected:
            self.client.disconnect()
        print(f"{colorize('👋 Goodbye!', Colors.GREEN)}")
        return True


def show_banner():
    banner = f"""
{colorize('╔══════════════════════════════════════════════════════════╗', Colors.CYAN)}
{colorize('║', Colors.CYAN)} {colorize('🚀 Drevoid LAN Chat Client', Colors.BOLD + Colors.WHITE)} {' ' * 23} {colorize('║', Colors.CYAN)}
{colorize('║', Colors.CYAN)} {colorize('Terminal-based chat with rooms & private messaging', Colors.WHITE)} {' ' * 7} {colorize('║', Colors.CYAN)}
{colorize('╚══════════════════════════════════════════════════════════╝', Colors.CYAN)}

{colorize('💡 Quick Start:', Colors.YELLOW)}
  1. Type '{colorize('connect', Colors.CYAN)}' to connect to a server
  2. Type '{colorize('help', Colors.CYAN)}' for all available commands
  3. Start chatting in rooms or send private messages!

{colorize('🎯 Pro Tips:', Colors.YELLOW)}
  • Use '{colorize('join general', Colors.CYAN)}' to join the default room
  • Use '{colorize('msg username message', Colors.CYAN)}' for private messages
  • Use '{colorize('create myroom private password123', Colors.CYAN)}' for private rooms
  • Use '{colorize('flags', Colors.CYAN)}' to view all captured CTF flags
"""
    print(banner)


def main():
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
        show_banner()

        client = ChatClient()
        shell = ChatShell(client)
        client.shell = shell

        if len(sys.argv) >= 4:
            host = sys.argv[1]
            try:
                port = int(sys.argv[2])
                username = sys.argv[3]

                print(f"{colorize('🔄 Auto-connecting...', Colors.YELLOW)}")
                if client.connect(host, port, username):
                    print(f"{colorize('✅ Connected successfully!', Colors.GREEN)}")
                    shell.update_prompt()
                else:
                    print(f"{colorize('❌ Auto-connect failed', Colors.RED)}")
            except ValueError:
                print(f"{colorize('❌ Invalid port in arguments', Colors.RED)}")

        try:
            shell.cmdloop()
        except KeyboardInterrupt:
            print(f"\n{colorize('👋 Interrupted by user', Colors.YELLOW)}")

    except Exception as e:
        print(f"{colorize('❌ Application error:', Colors.RED)} {e}")

    finally:
        if 'client' in locals() and client.connected:
            client.disconnect()


if __name__ == "__main__":
    main()
