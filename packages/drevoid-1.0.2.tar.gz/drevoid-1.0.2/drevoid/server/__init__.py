"""
Server-side modules for the Drevoid chat application.
"""

from drevoid.server.chat_server import main as run_server

__all__ = [
    "run_server",
]
