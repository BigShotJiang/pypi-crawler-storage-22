"""
Utility modules for emoji and notification support.
"""

from drevoid.utils.emojis import EmojiAliases, EmojiAliasesInstance
from drevoid.utils.notifications import NotificationManager

__all__ = [
    "EmojiAliases",
    "EmojiAliasesInstance",
    "NotificationManager",
]
