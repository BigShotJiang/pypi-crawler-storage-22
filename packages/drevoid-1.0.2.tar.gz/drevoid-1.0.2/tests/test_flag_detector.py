"""
Test cases for the flag detector.
"""

import unittest
from drevoid.client.flag_detector import FlagDetector, FlagPattern


class TestFlagDetector(unittest.TestCase):
    def setUp(self):
        self.detector = FlagDetector()

    def test_detect_flag_formats(self):
        # Test various flag formats
        test_cases = [
            ("flag{test123}", ["flag{test123}"]),
            ("FLAG{TEST}", ["FLAG{TEST}"]),
            ("CTF{example}", ["CTF{example}"]),
            ("flag:abc123", ["flag:abc123"]),
            ("5d41402abc4b2a76b9719d911017c592", ["5d41402abc4b2a76b9719d911017c592"]),  # MD5
        ]
        
        for content, expected in test_cases:
            with self.subTest(content=content):
                result = self.detector.detect(content)
                self.assertEqual(result, expected)

    def test_store_flag(self):
        flag = "flag{test}"
        result = self.detector.store_flag(flag, "user1", "general", "test message")
        self.assertTrue(result)
        
        # Try storing same flag again
        result = self.detector.store_flag(flag, "user2", "general", "another message")
        self.assertFalse(result)

    def test_get_all_flags(self):
        self.detector.store_flag("flag{1}", "user1", "room1", "msg1")
        self.detector.store_flag("flag{2}", "user2", "room2", "msg2")
        
        flags = self.detector.get_all_flags()
        self.assertEqual(len(flags), 2)


if __name__ == "__main__":
    unittest.main()
