"""
Test cases for the protocol module.
"""

import unittest
from drevoid.core.protocol import (
    MessageType,
    create_message,
    serialize_message,
    deserialize_message,
    hash_password,
)


class TestProtocol(unittest.TestCase):
    def test_create_message(self):
        msg = create_message(MessageType.MESSAGE, {"content": "Hello"})
        self.assertEqual(msg["type"], "message")
        self.assertIn("timestamp", msg)
        self.assertEqual(msg["data"]["content"], "Hello")

    def test_serialize_deserialize(self):
        original = create_message(MessageType.MESSAGE, {"content": "Test"})
        serialized = serialize_message(original)
        deserialized, remaining = deserialize_message(serialized)
        
        self.assertEqual(deserialized["type"], original["type"])
        self.assertEqual(deserialized["data"], original["data"])
        self.assertEqual(remaining, b'')

    def test_hash_password(self):
        password = "test123"
        hashed1 = hash_password(password)
        hashed2 = hash_password(password)
        
        self.assertEqual(hashed1, hashed2)
        self.assertNotEqual(hashed1, password)
        self.assertEqual(len(hashed1), 64)  # SHA-256 hex digest


if __name__ == "__main__":
    unittest.main()
