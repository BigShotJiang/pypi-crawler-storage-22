import inspect
import sys
from django.db import models
from rest_framework import serializers

from . import utils


class TypeScriptGenerator:
    """
    Generates TypeScript interfaces from DRF Serializers.
    """

    # Mapping DRF Fields to TypeScript types
    TYPE_MAPPING = {
        serializers.BooleanField: "boolean",
        serializers.CharField: "string",
        serializers.EmailField: "string",
        serializers.RegexField: "string",
        serializers.SlugField: "string",
        serializers.URLField: "string",
        serializers.UUIDField: "string",
        serializers.FilePathField: "string",
        serializers.IPAddressField: "string",
        serializers.IntegerField: "number",
        serializers.FloatField: "number",
        serializers.DecimalField: "string",  # DRF defaults Decimals to strings to preserve precision
        serializers.DateField: "string",  # ISO Date string
        serializers.DateTimeField: "string",  # ISO DateTime string
        serializers.TimeField: "string",
        serializers.DurationField: "string",
        serializers.JSONField: "any",  # Or 'Record<string, any>'
    }

    def __init__(self):
        self.dependencies = set()  # Stores (app_label, model_name) tuples
        self.enums = {}  # Stores generated enums: {EnumName: definition_string}
        self.enum_labels = {}  # Stores {EnumName: {value: label}}

    def _find_matching_enum(self, model, field_choices):
        """
        Heuristic to find the original Enum class (IntegerChoices or TextChoices)
        that matches the field choices.
        """
        if not model:
            return None

        # Normalize field_choices to list of tuples for comparison
        # field.choices is an OrderedDict
        target_choices = list(field_choices.items())

        candidates = []

        # 1. Search in Model attributes
        for key, val in model.__dict__.items():
            if isinstance(val, type) and issubclass(val, models.Choices):
                candidates.append(val)

        # 2. Search in Model attributes' module
        try:
            mod = sys.modules[model.__module__]
            for key, val in mod.__dict__.items():
                if isinstance(val, type) and issubclass(val, models.Choices):
                    candidates.append(val)
        except:
            pass

        for candidate in candidates:
            # Candidate.choices might be a property returning list of tuples
            if list(candidate.choices) == target_choices:
                return candidate

        return None

    def get_ts_type(self, field, field_name, model_name, model=None):
        """
        Determines the TS type for a specific field instance.
        """
        # 1. Handle Choices (Enum generation)
        # Only process actual ChoiceFields. RelatedFields also have a 'choices' property
        # but accessing it triggers a DB lookup of all records, which we want to avoid.
        if isinstance(field, serializers.ChoiceField) and field.choices:
            enum_name = f"{model_name}{utils.to_pascal_case(field_name)}Enum"

            # Try to recover original Enum names
            original_enum = self._find_matching_enum(model, field.choices)

            # Generate Enum definition
            enum_values = []
            labels_map = {}

            if original_enum:
                # Use the original names from the Enum class
                for member in original_enum:
                    member_name = member.name
                    value = member.value
                    label = member.label

                    labels_map[value] = label

                    if isinstance(value, (int, float)):
                        value_str = f"{value}"
                    else:
                        value_str = f"'{value}'"

                    enum_values.append(f"  {member_name} = {value_str},")
            else:
                # Fallback to generating names from values
                for k, v in field.choices.items():
                    # Sanitize key for use as enum member name if necessary
                    # Ideally, keys are strings. If int, we might need a prefix.
                    valid_key = str(k)
                    labels_map[k] = v

                    # Check if key is a valid identifier, if not (e.g. starts with number), format it
                    member_name = valid_key.upper().replace(" ", "_").replace("-", "_")

                    # Cannot start with a number
                    if member_name and member_name[0].isdigit():
                        member_name = f"_{member_name}"

                    if not member_name.isidentifier():
                        member_name = member_name.replace("'", "\\'")
                        member_name = f"'{member_name}'"

                    # Handle value type
                    if isinstance(k, (int, float)):
                        value_str = f"{k}"
                    else:
                        value_str = f"'{k}'"

                    enum_values.append(f"  {member_name} = {value_str},")

            enum_def = f"export enum {enum_name} {{\n" + "\n".join(enum_values) + "\n}"
            self.enums[enum_name] = enum_def
            self.enum_labels[enum_name] = labels_map

            # Return the enum name as type
            return enum_name

        # 2. Handle Nested Serializers (Recursion/Import)
        if isinstance(field, serializers.Serializer):
            if hasattr(field, "Meta") and hasattr(field.Meta, "model"):
                # It's a ModelSerializer, link to the Model interface
                related_model = field.Meta.model
                self.dependencies.add(
                    (related_model._meta.app_label, related_model.__name__)
                )
                return related_model.__name__
            else:
                # Standard serializer, treat as generic object or specific name if available
                return "any"

        # 3. Handle Lists (Many=True)
        if isinstance(field, serializers.ListSerializer) or getattr(
            field, "many", False
        ):
            # Recurse to find the child type
            child = getattr(field, "child", None)
            child_type = (
                self.get_ts_type(child, field_name, model_name, model=model)
                if child
                else "any"
            )
            return f"{child_type}[]"

        # 4. Standard Field Mapping
        for cls, ts_type in self.TYPE_MAPPING.items():
            if isinstance(field, cls):
                return ts_type

        # 5. Handle Related Fields (Foreign Keys)
        # User requested to interpret these as the Related Model Type, even if serializer might return PK.
        # This is useful for potentially expanded responses or frontend models that hydrate relations.
        if isinstance(field, serializers.RelatedField):
            # Try to find the related model
            related_model = None
            if hasattr(field, "queryset") and hasattr(field.queryset, "model"):
                related_model = field.queryset.model
            elif hasattr(field, "related_model"):
                related_model = field.related_model

            if related_model:
                if (
                    related_model._meta.app_label == "auth"
                    and related_model.__name__ in ["Group", "Permission"]
                ):
                    return "any"
                return related_model.__name__

        # 6. Fallback
        return "any"

    def generate_interface(self, viewset):
        """
        Main entry point: Generates the interface string for a ViewSet.
        """
        if not hasattr(viewset, "get_serializer"):
            return None

        try:
            serializer_instance = viewset.get_serializer()
        except:
            return None

        model = getattr(getattr(serializer_instance, "Meta", None), "model", None)
        if not model:
            # If it's a viewset without a model, we skip or name it based on ViewName
            return None

        interface_name = model.__name__
        fields_str = []

        for field_name, field in serializer_instance.get_fields().items():
            # Skip hidden fields
            if isinstance(field, serializers.HiddenField):
                continue

            ts_type = self.get_ts_type(field, field_name, interface_name, model=model)

            # Handle Nullable
            is_nullable = getattr(field, "allow_null", False)
            if is_nullable:
                ts_type += " | null"

            # Handle Optional (Required=False)
            # In TS, optional properties are denoted by `name?: type`
            is_required = getattr(field, "required", True)

            # Remove the automatic required=True of reverse related objects:
            if isinstance(field, serializers.ManyRelatedField):
                is_required = False

            key_suffix = "" if is_required else "?"

            fields_str.append(f"  {field_name}{key_suffix}: {ts_type};")

        return f"export interface {interface_name} {{\n" + "\n".join(fields_str) + "\n}"
