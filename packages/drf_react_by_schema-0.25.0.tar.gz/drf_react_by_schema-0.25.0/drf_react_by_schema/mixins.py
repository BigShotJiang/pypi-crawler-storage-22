import logging
import time


class GlobalETagMixin:
    """
    Mixin that provides a SINGLE global ETag version across ALL ViewSets.
    Uses Redis atomic operations if available.
    """

    # Cache key for the global ETag version
    GLOBAL_ETAG_CACHE_KEY = "global_etag_version"

    @classmethod
    def _get_cache(cls):
        """
        Lazy cache import
        """
        from django.core.cache import cache as django_cache

        return django_cache

    @classmethod
    def _get_global_etag_version(cls):
        """
        Get the global ETag version from cache.
        If not exists, initialize to 1.
        """
        cache = cls._get_cache()
        version = cache.get(cls.GLOBAL_ETAG_CACHE_KEY)
        if version is None:
            version = 1
            cache.set(cls.GLOBAL_ETAG_CACHE_KEY, version, timeout=None)
        return version

    @classmethod
    def _increment_global_etag_version(cls):
        """
        Increment the global ETag version atomically.
        Uses Redis incr if available, otherwise lock.
        """
        cache = cls._get_cache()
        try:
            # Try Redis atomic increment (works across processes)
            new_version = cache.incr(cls.GLOBAL_ETAG_CACHE_KEY)
            return new_version
        except (ValueError, AttributeError, TypeError):
            # Fallback to thread lock (single process only)
            import threading

            lock = threading.Lock()
            with lock:
                current = cls._get_global_etag_version()
                new_version = current + 1
                cache.set(cls.GLOBAL_ETAG_CACHE_KEY, new_version, timeout=None)
                return new_version

    @classmethod
    def get_etag(cls, request, *args, **kwargs):
        """
        Returns the GLOBAL ETag version as string.
        Same for ALL ViewSets.
        """
        return str(cls._get_global_etag_version())


class LoggingMixin:
    """
    Provides full logging of requests and responses
    """

    initial_time = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.logger = logging.getLogger("django.request")

    def initial(self, request, *args, **kwargs):
        self.initial_time = time.time()
        super().initial(request, *args, **kwargs)

    def finalize_response(self, request, response, *args, **kwargs):
        from . import settings

        if settings.get("DEBUG", True):
            try:
                time_delta_ms = (time.time() - self.initial_time) * 1000
                self.logger.debug(
                    {
                        # "request_data": request.data,
                        "request_method": request.method,
                        "request_endpoint": request.path,
                        "response_status_code": response.status_code,
                        "time_delta_request_to_response": "{0:.2f}ms".format(
                            time_delta_ms
                        ),
                    }
                )
            except Exception:
                self.logger.exception("Error logging request")
        return super().finalize_response(request, response, *args, **kwargs)
