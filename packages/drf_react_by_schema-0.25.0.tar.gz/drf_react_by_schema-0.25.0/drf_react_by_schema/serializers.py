import traceback
from django.apps import apps
from rest_framework.utils import model_meta
from rest_framework.serializers import ManyRelatedField, SerializerMetaclass
from django.db import models
from . import settings, autocomplete_serializers
from .utils import update_related_fields


class GenericSerializerMetaclass(SerializerMetaclass):
    """
    Metaclass that automatically populates related fields with autocomplete serializers
    at class creation time (not instance creation time).

    This ensures:
    1. Better performance - logic runs once per class, not per instance
    2. Explicitly defined fields are never overwritten
    3. Clearer precedence - class-level definitions always win
    """

    def __new__(mcs, name, bases, attrs):
        # First, let DRF's SerializerMetaclass do its work
        new_class = super().__new__(mcs, name, bases, attrs)

        # Only process if this class has a Meta with a model
        if hasattr(new_class, "Meta") and hasattr(new_class.Meta, "model"):
            mcs._populate_related_fields(new_class)

        return new_class

    @staticmethod
    def _populate_related_fields(cls):
        """
        Populate related fields with autocomplete serializers and build update_related list.
        This runs once at class creation time.
        """
        model = cls.Meta.model
        model_fields = model._meta.get_fields()

        # Initialize update_related as a fresh list for this class
        # We check if it's explicitly defined in this class (not inherited)
        if "update_related" not in cls.__dict__ or cls.update_related is None:
            cls.update_related = []

        # Store model_fields as class attribute for later use
        cls.model_fields = model_fields

        for field in model_fields:
            field_class_name = field.__class__.__name__

            # Handle related fields
            if hasattr(field, "related_model") and field.related_model:
                # Get the autocomplete serializer for this related model
                serializer = getattr(
                    autocomplete_serializers,
                    f"{field.related_model.__name__}Serializer",
                    None,
                )

                # Only add the field if it  hasn't been explicitly defined in the class
                should_define_related_serializer = (
                    serializer and field.name not in cls._declared_fields
                )

                if should_define_related_serializer:
                    # Basic null handling
                    allows_null = getattr(field, "null", False)

                    # Default value
                    default_value = getattr(field, "default", None)
                    has_default = default_value is not None

                    # Required/blank mapping (blank=False on model = required=True on serializer)
                    # Note: For related fields, blank is usually the same as null in forms
                    is_blank_allowed = getattr(field, "blank", True)
                    is_required = not (allows_null or is_blank_allowed or has_default)

                    is_read_only = True

                    # Help text and label
                    help_text = getattr(field, "help_text", "")
                    verbose_name = getattr(field, "verbose_name", "")

                    # Reverse relations don't use null/blank the same way
                    if field_class_name in [
                        "OneToOneRel",
                        "ManyToOneRel",
                        "ManyToManyRel",
                    ]:
                        allows_null = True
                        is_required = False

                    # Build serializer kwargs
                    serializer_kwargs = {
                        "label": verbose_name
                        or getattr(
                            field.related_model._meta,
                            "verbose_name",
                            field.related_model.__name__,
                        ),
                        "help_text": help_text,
                        "read_only": is_read_only,
                        "allow_null": allows_null,
                    }

                    # Only set required if it's meaningful (not read-only and no default)
                    if not is_read_only and not has_default:
                        serializer_kwargs["required"] = is_required

                    # Add default if it exists
                    if has_default and not is_read_only:
                        serializer_kwargs["default"] = default_value

                # Handle different field types
                if field_class_name == "OneToOneField":
                    cls.update_related.append(field.name)
                    if should_define_related_serializer:
                        cls._declared_fields[field.name] = serializer(
                            **serializer_kwargs
                        )

                elif field_class_name == "OneToOneRel":
                    # Note: OneToOneRel is not added to update_related
                    if should_define_related_serializer:
                        cls._declared_fields[field.name] = serializer(
                            **serializer_kwargs
                        )

                elif field_class_name == "ForeignKey":
                    if getattr(field, "related_editable", False):
                        cls.update_related.append((field.name, "creatable"))
                    else:
                        cls.update_related.append(field.name)

                    if should_define_related_serializer:
                        cls._declared_fields[field.name] = serializer(
                            **serializer_kwargs
                        )

                elif field_class_name == "ManyToManyField":
                    cls.update_related.append((field.name, "many"))
                    if should_define_related_serializer:
                        serializer_kwargs["many"] = True
                        cls._declared_fields[field.name] = serializer(
                            **serializer_kwargs
                        )

                # I still think that ManyToOneRel is not necessary to be populated
                # with serializer


class GenericSerializer(
    autocomplete_serializers.GenericAutocompleteSerializer,
    metaclass=GenericSerializerMetaclass,
):
    """
    Base serializer that automatically handles related fields.

    Related fields are automatically populated with autocomplete serializers
    (showing only id and label) unless explicitly overridden in the subclass.
    """

    update_related = None
    model_fields = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Handle SlugField special case - make blank slug fields not required
        # This needs to be in __init__ because it modifies instance-level field properties
        if self.model_fields:
            for field in self.model_fields:
                if (
                    isinstance(field, models.SlugField)
                    and field.blank
                    and field.name in self.fields
                ):
                    self.fields[field.name].required = False

    def to_internal_value(self, data):
        data = data.copy()

        # Clean empty RELATED fields that are not in data
        for field_name, field in self.fields.items():
            if isinstance(field, ManyRelatedField) and (
                field_name not in data or data[field_name] is None
            ):
                data[field_name] = []

        return super().to_internal_value(data)

    def create(self, validated_data, *args, **kwargs):
        # raise_errors_on_nested_writes("create", self, validated_data)

        ModelClass = self.Meta.model

        # Remove many-to-many relationships from validated_data.
        # They are not valid arguments to the default `.create()` method,
        # as they require that the instance has already been saved.
        info = model_meta.get_field_info(ModelClass)
        many_to_many = {}
        for field_name, relation_info in info.relations.items():
            if relation_info.to_many and (field_name in validated_data):
                many_to_many[field_name] = validated_data.pop(field_name)

        try:
            instance = ModelClass._default_manager.create(**validated_data)
        except TypeError:
            tb = traceback.format_exc()
            msg = (
                "Got a `TypeError` when calling `%s.%s.create()`. "
                "This may be because you have a writable field on the "
                "serializer class that is not a valid argument to "
                "`%s.%s.create()`. You may need to make the field "
                "read-only, or override the %s.create() method to handle "
                "this correctly.\nOriginal exception was:\n %s"
                % (
                    ModelClass.__name__,
                    ModelClass._default_manager.name,
                    ModelClass.__name__,
                    ModelClass._default_manager.name,
                    self.__class__.__name__,
                    tb,
                )
            )
            raise TypeError(msg)

        # Save many-to-many relationships after the instance is created.
        # if many_to_many:
        #     for field_name, value in many_to_many.items():
        #         field = getattr(instance, field_name)
        #         field.set(value)

        instance = update_related_fields(
            instance=instance,
            request_data=self.context["normalized_raw_data"],
            update_related=self.update_related,
            model_fields=self.model_fields,
        )
        instance.save()

        return instance

    def update(self, instance, validated_data, *args, **kwargs):
        instance = update_related_fields(
            instance=instance,
            request_data=self.context["normalized_raw_data"],
            update_related=self.update_related,
            model_fields=self.model_fields,
        )

        return super().update(instance, validated_data)

    class Meta:
        fields = "__all__"


######################


for app in settings["APPS"]:
    for name, model in apps.all_models[app].items():
        model_name = model.__name__
        if isinstance(model, type):
            serializer_list_name = f"{model_name}ListSerializer"
            serializer_name = f"{model_name}Serializer"
            if not serializer_name in dir():
                meta = type("Meta", (), {"fields": "__all__", "model": model})
                generated_class = type(
                    serializer_list_name,
                    (GenericSerializer,),
                    {
                        "Meta": meta,
                    },
                )
                globals()[serializer_list_name] = generated_class

                generated_class = type(
                    serializer_name, (GenericSerializer,), {"Meta": meta}
                )
                globals()[serializer_name] = generated_class

                # Generate serializers for nested viewsets:
                # for field in model._meta.get_fields():
                #     if field.__class__.__name__ == 'ManyToOneRel':
                #         related_serializer_name = f"{model_name}Related{related_model_name}Serializer"
                #         related_model_name = field.related_model.__name__
                #         related_meta = type("Meta",(),{
                #             'fields':'__all__',
                #             'model':field.related_model
                #         })
                #         generated_class = type(serializer_name, (GenericSerializer,), {
                #             'Meta': related_meta
                #         })
                #         globals()[related_serializer_name] = generated_class
