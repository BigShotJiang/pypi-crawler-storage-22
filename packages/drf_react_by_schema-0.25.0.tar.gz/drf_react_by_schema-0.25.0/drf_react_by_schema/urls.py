from django.urls import path, include
from rest_framework_nested import routers
import importlib
import traceback

from . import settings
from .utils import camel_to_snake
from .viewsets import __nested_viewsets__

router = routers.SimpleRouter()
autocomplete_router = routers.SimpleRouter()
nested_routers = {}

modules = []
autocomplete_modules = []
for app in settings["APPS"]:
    modules.append(f"{app}.viewsets")
    autocomplete_modules.append(f"{app}.autocomplete_viewsets")
modules.append("drf_react_by_schema.viewsets")
autocomplete_modules.append("drf_react_by_schema.autocomplete_viewsets")


# Main routes:
def register_viewsets_routers(modules):
    global router
    global nested_routers

    registered_router_basenames = set()

    for module_str in modules:
        try:
            module = importlib.import_module(module_str)
            for viewset_name, viewset in module.__dict__.items():
                if isinstance(viewset, type):
                    for parent in viewset.mro():
                        if "ViewSet" in parent.__name__:
                            router_basename = camel_to_snake(viewset_name, "ViewSet")
                            if router_basename in registered_router_basenames:
                                continue

                            router.register(
                                f"{router_basename}", viewset, basename=router_basename
                            )
                            registered_router_basenames.add(router_basename)
                            break
        except ImportError:
            # There is no viewsets in module {module_str}
            pass
        except Exception as e:
            print(f"--- Error loading module: {module_str} ---")
            traceback.print_exc()

    # Nested routes:
    for module_str in modules:
        try:
            module = importlib.import_module(module_str)
            nested_viewsets = (
                __nested_viewsets__
                if not "__nested_viewsets__" in dir(module)
                else __nested_viewsets__ + module.__nested_viewsets__
            )
            for item in nested_viewsets:
                if not isinstance(item, str):
                    key = item[0]
                    ViewSet = getattr(module, item[1], None)
                    if ViewSet:
                        router_basename = camel_to_snake(
                            ViewSet.__name__, "ViewSet"
                        ).removeprefix(f"{key}_related_")
                        if not key in nested_routers:
                            nested_routers[key] = routers.NestedSimpleRouter(
                                router, key, lookup=key
                            )
                        nested_routers[key].register(
                            f"{router_basename}",
                            ViewSet,
                            basename=f"{key}-{router_basename}",
                        )
        except ImportError:
            # There is no nested_viewsets in module {module_str}
            pass
        except Exception as e:
            print(f"--- Error loading module: {module_str} ---")
            traceback.print_exc()


# Autocomplete routes:
def register_autocomplete_viewsets_routers(modules):
    global autocomplete_router

    registered_router_basenames = set()

    for module_str in modules:
        try:
            module = importlib.import_module(module_str)
            for viewset_name, viewset in module.__dict__.items():
                if isinstance(viewset, type):
                    for parent in viewset.mro():
                        if "ViewSet" in parent.__name__:
                            router_basename = camel_to_snake(viewset_name, "ViewSet")
                            if router_basename in registered_router_basenames:
                                continue

                            autocomplete_router.register(
                                f"{router_basename}", viewset, basename=router_basename
                            )
                            registered_router_basenames.add(router_basename)
                            break
        except ImportError:
            # There is no autocomplete_viewsets in module {module_str}
            pass
        except Exception as e:
            print(f"--- Error loading module: {module_str} ---")
            traceback.print_exc()


#################

register_viewsets_routers(modules)
register_autocomplete_viewsets_routers(autocomplete_modules)

#################
urlpatterns = [
    path("api/", include(router.urls)),
    path("autocomplete/", include(autocomplete_router.urls)),
]

#################

for nested_router in nested_routers.values():
    urlpatterns.append(
        path("api/", include(nested_router.urls)),
    )
