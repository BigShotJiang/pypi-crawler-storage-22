from functools import wraps


def lazy_cache_page(timeout):
    """
    Returns a decorator that applies cache_page at runtime.
    Use with @method_decorator(lazy_cache_page(300))
    """

    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            # Import cache_page at runtime
            from django.views.decorators.cache import cache_page

            # Apply cache_page to the view function
            return cache_page(timeout)(view_func)(request, *args, **kwargs)

        return _wrapped_view

    return decorator
