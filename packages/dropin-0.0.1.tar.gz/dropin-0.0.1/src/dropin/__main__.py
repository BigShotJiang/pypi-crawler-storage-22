from ._core import sum_as_string

def main():
    print(sum_as_string(1, 2))
    
    
if __name__ == "__main__":
    main()