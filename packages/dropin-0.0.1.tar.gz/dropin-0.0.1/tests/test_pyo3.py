from pyo3_template._core import sum_as_string

if __name__ == "__main__":
    print(sum_as_string(1, 2))