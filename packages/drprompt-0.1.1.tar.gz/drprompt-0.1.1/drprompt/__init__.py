"""
Dr-Prompt Python SDK

A Python client for the Dr-Prompt API - manage and use your prompts programmatically.
"""

from .client import DrPrompt
from .models import Prompt, PromptVersion, Collection, UsageStats
from .exceptions import DrPromptError, AuthenticationError, NotFoundError, APIError

__version__ = "0.1.1"
__all__ = [
    "DrPrompt",
    "Prompt",
    "PromptVersion",
    "Collection",
    "UsageStats",
    "DrPromptError",
    "AuthenticationError",
    "NotFoundError",
    "APIError",
]
