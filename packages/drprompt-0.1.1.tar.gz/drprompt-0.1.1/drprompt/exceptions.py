"""Dr-Prompt SDK Exceptions."""


class DrPromptError(Exception):
    """Base exception for Dr-Prompt SDK."""

    def __init__(self, message: str, status_code: int = None):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class AuthenticationError(DrPromptError):
    """Raised when authentication fails."""

    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message, status_code=401)


class NotFoundError(DrPromptError):
    """Raised when a resource is not found."""

    def __init__(self, message: str = "Resource not found"):
        super().__init__(message, status_code=404)


class APIError(DrPromptError):
    """Raised when the API returns an error."""

    pass
