"""Tests for Dr-Prompt SDK client."""

import pytest
from unittest.mock import Mock, patch
from drprompt import DrPrompt, Prompt, AuthenticationError, NotFoundError


class TestDrPromptClient:
    """Test cases for DrPrompt client."""

    def test_init(self):
        """Test client initialization."""
        client = DrPrompt("https://example.com")
        assert client.base_url == "https://example.com"
        assert client.api_url == "https://example.com/api"
        assert client.token is None

    def test_init_with_api_key(self):
        """Test client initialization with API key."""
        client = DrPrompt("https://example.com", api_key="drp_test_key")
        assert client.token == "drp_test_key"

    def test_init_with_token(self):
        """Test client initialization with token."""
        client = DrPrompt("https://example.com", token="test-token")
        assert client.token == "test-token"

    def test_init_api_key_takes_precedence(self):
        """Test that api_key takes precedence over token."""
        client = DrPrompt("https://example.com", api_key="drp_key", token="jwt-token")
        assert client.token == "drp_key"

    def test_init_strips_trailing_slash(self):
        """Test that trailing slash is stripped from base_url."""
        client = DrPrompt("https://example.com/")
        assert client.base_url == "https://example.com"

    def test_set_token(self):
        """Test setting token."""
        client = DrPrompt("https://example.com")
        client.set_token("new-token")
        assert client.token == "new-token"

    def test_get_headers_without_token(self):
        """Test headers without authentication."""
        client = DrPrompt("https://example.com")
        headers = client._get_headers()
        assert "Authorization" not in headers
        assert headers["Content-Type"] == "application/json"

    def test_get_headers_with_token(self):
        """Test headers with authentication."""
        client = DrPrompt("https://example.com", token="test-token")
        headers = client._get_headers()
        assert headers["Authorization"] == "Bearer test-token"

    def test_get_headers_with_api_key(self):
        """Test headers with API key."""
        client = DrPrompt("https://example.com", api_key="drp_test_key")
        headers = client._get_headers()
        assert headers["Authorization"] == "Bearer drp_test_key"


class TestPromptModel:
    """Test cases for Prompt model."""

    def test_render_without_variables(self):
        """Test rendering prompt without variables."""
        prompt = Prompt(
            id=1,
            uid="test-uid",
            name="Test",
            description=None,
            current_version=1,
            current_content="Hello, world!",
            created_at=Mock(),
            updated_at=Mock(),
        )
        assert prompt.render() == "Hello, world!"

    def test_render_with_variables(self):
        """Test rendering prompt with variables."""
        prompt = Prompt(
            id=1,
            uid="test-uid",
            name="Test",
            description=None,
            current_version=1,
            current_content="Hello, {{name}}! Welcome to {{place}}.",
            created_at=Mock(),
            updated_at=Mock(),
        )
        rendered = prompt.render({"name": "Alice", "place": "Wonderland"})
        assert rendered == "Hello, Alice! Welcome to Wonderland."

    def test_get_variables(self):
        """Test extracting variables from prompt."""
        prompt = Prompt(
            id=1,
            uid="test-uid",
            name="Test",
            description=None,
            current_version=1,
            current_content="Hello, {{name}}! You are a {{role}} expert in {{topic}}.",
            created_at=Mock(),
            updated_at=Mock(),
        )
        variables = prompt.get_variables()
        assert set(variables) == {"name", "role", "topic"}

    def test_get_variables_empty(self):
        """Test extracting variables from prompt without variables."""
        prompt = Prompt(
            id=1,
            uid="test-uid",
            name="Test",
            description=None,
            current_version=1,
            current_content="Hello, world!",
            created_at=Mock(),
            updated_at=Mock(),
        )
        variables = prompt.get_variables()
        assert variables == []
