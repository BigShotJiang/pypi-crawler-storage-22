# Dryft Python client

Same CLI as the Node client, installable via **pip** per the PRD:

```bash
pip install dryft
dryft init
dryft start
```

From source (repo root):

```bash
pip install -e ./client-py
```

Commands: `init`, `start`, `stop`, `status`, `config`, `push-notify`. Implementation follows the same phases as the Node client in `client/`.
