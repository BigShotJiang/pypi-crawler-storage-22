"""
Build context payload for POST and render/write .dryft/context.md from GET response.
PRD §7.1: template with Last synced, Project, Last Activity, Guidelines, severity; §7.4: ~200 line cap.
"""

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

CONTEXT_LINE_CAP = 200  # PRD §7.4, §17.4

GUIDELINES_BLOCK = """
## Guidelines for AI Agent

### Before Starting Any Task
- Read this entire file.
- Check if any files you plan to modify are listed under "Currently Active Changes" or "Files They Plan to Modify Next."
- If overlap exists, inform your developer immediately before proceeding.

### If You Share a File With the Other Agent
- Read "What they changed" to understand exactly which functions/sections they are modifying.
- Work in DIFFERENT functions or sections of the same file where possible.
- If you must modify the SAME function they are working on, STOP and inform your developer — this is a high-conflict risk.
- Do not change function signatures, interfaces, or exports that the other agent's code depends on.

### During Work
- If this file updates with a new warning, pause and inform your developer.
- If the other developer completes changes to files you depend on, suggest pulling latest.
- Keep your .dryft/intent.md updated after every file modification so the other agent can see your progress.
""".strip()


def _one_line_summary(dev: dict) -> str:
    """One-line progress summary for another dev: task + modified files + next planned file."""
    intent = dev.get("intent") or {}
    task = intent.get("current_task")
    task_str = (str(task).split("\n")[0].strip()[:80] if task else "—") or "—"
    changes = dev.get("active_changes") or []
    files_str = ", ".join(c.get("file", "?") for c in changes) if changes else "—"
    planned = intent.get("planned_files") or []
    next_str = planned[0] if planned else "—"
    if not task_str or task_str == "—":
        if files_str == "—" and next_str == "—":
            return "No current task or changes reported."
    return f"Working on {task_str}. Modified: {files_str}. Next: {next_str}"


def _time_ago(iso: str) -> str:
    try:
        then = datetime.fromisoformat(iso.replace("Z", "+00:00")).timestamp()
        sec = int(datetime.now(timezone.utc).timestamp() - then)
        if sec < 60:
            return "just now"
        if sec < 3600:
            return f"{sec // 60} min ago"
        if sec < 86400:
            return f"{sec // 3600} h ago"
        return f"{sec // 86400} d ago"
    except (ValueError, TypeError):
        return ""


def build_payload(
    developer: str,
    git_changes: list[dict],
    intent: dict | None,
    project_id: str | None = None,
) -> dict:
    structured = intent and intent.get("activeChangesStructured")
    has_structured = bool(structured and len(structured) > 0)
    if has_structured:
        active_changes = []
        for c in structured:
            entry: dict[str, Any] = {"file": c["file"]}
            if c.get("functionComponentClass"):
                entry["function_component_class"] = c["functionComponentClass"]
            if c.get("exportsImports"):
                entry["exports_imports"] = c["exportsImports"]
            if c.get("interfacesTypes"):
                entry["interfaces_types"] = c["interfacesTypes"]
            active_changes.append(entry)
    else:
        active_changes = [
            {
                "file": c["file"],
                "functions_modified": c.get("functionsModified", []),
                "change_type": c.get("changeType", "modification"),
            }
            for c in git_changes
        ]
    payload: dict[str, Any] = {
        "developer": developer,
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "active_changes": active_changes,
    }
    if intent and intent.get("dependencies"):
        payload["dependencies_affected"] = intent["dependencies"]
    ct = intent.get("completedTask") if intent else None
    if ct and (ct.get("summary") or (ct.get("files") or [])):
        payload["completed_work"] = {
            "summary": ct.get("summary") or "(no summary)",
            "files": ct.get("files") or [],
        }
    if intent:
        payload["intent"] = {}
        if intent.get("plannedFiles"):
            payload["intent"]["planned_files"] = intent["plannedFiles"]
        if intent.get("currentTask"):
            payload["intent"]["current_task"] = intent["currentTask"]
        if intent.get("dependencies"):
            payload["intent"]["dependencies"] = intent["dependencies"]
    if project_id:
        payload["project_id"] = project_id
    return payload


def render_context_md(server_state: dict, my_developer_id: str) -> str:
    developers = server_state.get("developers") or {}
    warnings = server_state.get("warnings") or []
    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    project_id = server_state.get("project_id") or ""

    lines = [
        "# Dryft — Shared Development Context",
        "",
        f"> Last synced: {now}",
    ]
    if project_id:
        lines.append(f"> Project: {project_id}")
    lines.append("")

    others = [(k, v) for k, v in developers.items() if k != my_developer_id]
    if not others:
        lines.append("> No other developers in context yet.")
    else:
        for dev_id, dev in others:
            lines.append(f"## Other Developer Activity ({dev_id})")
            lines.append("")
            lines.append(f"**Summary:** {_one_line_summary(dev)}")
            lines.append("")
            if dev.get("last_update"):
                ago = _time_ago(dev["last_update"])
                if ago:
                    lines.append("### Last Activity")
                    lines.append("")
                    lines.append(f"{dev_id} last active — {ago}")
                    lines.append("")
            planned = dev.get("intent") or {}
            if planned.get("current_task"):
                lines.append("### Current Task")
                lines.append("")
                lines.append(str(planned["current_task"]))
                lines.append("")
            changes = dev.get("active_changes") or []
            if changes:
                lines.append("### Currently Active Changes")
                lines.append("")
                for c in changes:
                    has_granular = (
                        c.get("function_component_class") is not None
                        or c.get("exports_imports") is not None
                        or c.get("interfaces_types") is not None
                    )
                    if has_granular:
                        lines.append(f"- **{c.get('file', '?')}**:")
                        if c.get("function_component_class"):
                            lines.append(f"  - function/component/class: {c['function_component_class']}")
                        if c.get("exports_imports"):
                            lines.append(f"  - exports/imports: {c['exports_imports']}")
                        if c.get("interfaces_types"):
                            lines.append(f"  - interfaces/types: {c['interfaces_types']}")
                    else:
                        funcs = c.get("functions_modified") or []
                        func_str = f" — {', '.join(funcs)}" if funcs else ""
                        lines.append(f"- **{c.get('file', '?')}** — {c.get('change_type', 'change')}{func_str}")
                        if c.get("summary"):
                            lines.append(f"  - Why: {c['summary']}")
                lines.append("")
            planned_files = planned.get("planned_files") or []
            if planned_files:
                lines.append("### Files They Plan to Modify Next")
                lines.append("")
                for f in planned_files:
                    lines.append(f"- {f}")
                lines.append("")
            cw = dev.get("completed_work")
            if cw and (cw.get("summary") or (cw.get("files") or [])):
                if cw.get("pushed"):
                    lines.append("### Completed work (pushed)")
                    lines.append("")
                    lines.append(cw.get("summary", ""))
                    lines.append("")
                    for f in cw.get("files") or []:
                        lines.append(f"- {f}")
                    lines.append("")
                    lines.append("Tell your developer to **pull** to get these changes.")
                    lines.append("")
                else:
                    lines.append("### Completed work (not yet pushed)")
                    lines.append("")
                    lines.append(cw.get("summary", ""))
                    lines.append("")
                    for f in cw.get("files") or []:
                        lines.append(f"- {f}")
                    lines.append("")
                    lines.append("Work is done locally but not pushed yet.")
                    lines.append("")
            deps = dev.get("dependencies_affected") or []
            if deps:
                lines.append("### Dependencies (What They Rely On)")
                lines.append("")
                for d in deps:
                    lines.append(f"- {d}")
                lines.append("")
    if warnings:
        lines.append("---")
        lines.append("")
        lines.append("## Warnings")
        lines.append("")
        for w in warnings:
            severity = "WARNING" if w.get("type") == "overlap" else "INFO"
            detail = w.get("detail") or ", ".join(w.get("developers") or [])
            lines.append(f"- **{severity}** — {w.get('file', '?')}: {detail}")
        lines.append("")
    last_push = server_state.get("last_push")
    if last_push and last_push.get("at"):
        lines.append("---")
        lines.append("")
        dev = last_push.get("developer")
        lines.append(f"**Last push:** {last_push['at']}" + (f" by {dev}" if dev else ""))
        lines.append("")
    lines.append("---")
    lines.append("")
    lines.append(GUIDELINES_BLOCK)

    out = "\n".join(lines)
    line_list = out.split("\n")
    if len(line_list) > CONTEXT_LINE_CAP:
        kept = line_list[: CONTEXT_LINE_CAP - 2]
        kept.append("")
        kept.append("... (context truncated to 200 lines)")
        return "\n".join(kept)
    return out


def write_context_file(cwd: str, content: str) -> None:
    path = Path(cwd) / ".dryft" / "context.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
