"""
Read and parse .dryft/intent.md (agent-declared plan, expected files, dependencies).
"""

import re
from pathlib import Path
from typing import TypedDict

INTENT_FILENAME = Path(".dryft") / "intent.md"


def _parse_list_lines(text: str) -> list[str]:
    out = []
    for line in text.split("\n"):
        line = re.sub(r"^\s*[-*]\s+", "", re.sub(r"^\s*\d+\.\s*", "", line)).strip()
        if line:
            out.append(line)
    return out


def _extract_section(content: str, heading: str) -> str:
    pattern = re.compile(
        r"##\s+" + re.escape(heading) + r"\s*\n([\s\S]*?)(?=##\s|$)",
        re.IGNORECASE,
    )
    m = pattern.search(content)
    return m.group(1).strip() if m else ""


def _parse_structured_key(line: str) -> tuple[str, str] | None:
    trimmed = re.sub(r"^\s*[-*]\s*", "", line).strip()
    m = re.match(
        r"^(function/component/class|exports/imports|interfaces/types):\s*(.*)$",
        trimmed,
        re.IGNORECASE,
    )
    if not m:
        return None
    key_map = {
        "function/component/class": "functionComponentClass",
        "exports/imports": "exportsImports",
        "interfaces/types": "interfacesTypes",
    }
    norm = m.group(1).lower().replace(" ", "")
    key = key_map.get(norm)
    if not key:
        return None
    return (key, m.group(2).strip())


def _parse_active_changes_structured(block: str) -> list[dict]:
    result: list[dict] = []
    lines = block.split("\n")
    current: dict = {}
    for line in lines:
        file_match = re.match(r"^\s*-\s+(?:\*\*)?([^*\n]+?)(?:\*\*)?\s*:\s*$", line)
        if file_match:
            if current.get("file"):
                result.append({k: v for k, v in current.items() if v})
            current = {"file": file_match.group(1).strip()}
            continue
        structured = _parse_structured_key(line)
        if structured and current.get("file"):
            key, value = structured
            current[key] = value
    if current.get("file"):
        result.append({k: v for k, v in current.items() if v})
    return result


def _parse_completed_task(block: str) -> dict | None:
    t = block.strip()
    if not t:
        return None
    lines = t.split("\n")
    summary_lines: list[str] = []
    file_lines: list[str] = []
    in_list = False
    for line in lines:
        bullet = re.match(r"^\s*[-*]\s+(.+)$", line)
        if bullet:
            in_list = True
            file_lines.append(bullet.group(1).strip())
        elif not in_list and line.strip():
            summary_lines.append(line.strip())
    summary = " ".join(summary_lines).strip()
    files = [f for f in file_lines if f]
    if not summary and not files:
        return None
    return {"summary": summary or "(no summary)", "files": files}


class IntentData(TypedDict, total=False):
    currentTask: str
    plannedFiles: list[str]
    dependencies: list[str]
    activeChanges: str
    activeChangesStructured: list[dict]
    completedTask: dict
    notes: str


def read_intent(cwd: str) -> IntentData | None:
    path = Path(cwd) / INTENT_FILENAME
    try:
        content = path.read_text(encoding="utf-8")
    except OSError:
        return None
    current_task = _extract_section(content, "Current Task")
    planned_files_text = _extract_section(content, "Planned Files")
    dependencies_text = (
        _extract_section(content, "Dependencies")
        or _extract_section(content, "Dependencies (What I Rely On)")
    )
    active_changes = _extract_section(content, "Active Changes")
    completed_task_block = _extract_section(content, "Completed Task")
    notes = _extract_section(content, "Notes")
    planned = _parse_list_lines(planned_files_text)
    deps = _parse_list_lines(dependencies_text)
    active_changes_structured = (
        _parse_active_changes_structured(active_changes) if active_changes and active_changes.strip() else []
    )
    completed_task = _parse_completed_task(completed_task_block) if completed_task_block else None
    out: IntentData = {}
    if current_task:
        out["currentTask"] = current_task
    if planned:
        out["plannedFiles"] = planned
    if deps:
        out["dependencies"] = deps
    if active_changes:
        out["activeChanges"] = active_changes
    if active_changes_structured:
        out["activeChangesStructured"] = active_changes_structured
    if completed_task:
        out["completedTask"] = completed_task
    if notes:
        out["notes"] = notes
    return out if out else None
