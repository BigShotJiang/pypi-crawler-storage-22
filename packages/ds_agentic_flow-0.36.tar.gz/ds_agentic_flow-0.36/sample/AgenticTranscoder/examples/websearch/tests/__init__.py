"""Tests for websearch agent."""
