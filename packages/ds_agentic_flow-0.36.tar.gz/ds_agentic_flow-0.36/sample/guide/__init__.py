"""AF Guide - Documentation assistant."""
