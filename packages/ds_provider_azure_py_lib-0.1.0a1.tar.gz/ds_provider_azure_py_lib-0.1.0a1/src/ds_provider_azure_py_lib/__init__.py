"""
**File:** ``__init__.py``
**Region:** ``ds-provider-azure-py-lib``

Description
-----------
A Python package from the ds-provider-azure-py-lib library.

Example
-------
.. code-block:: python

    from ds_provider_azure_py_lib import __version__

    print(f"Package version: {__version__}")
"""

from importlib.metadata import version

from .dataset import AzureBlob, AzureBlobDatasetSettings, AzureTable, AzureTableDatasetSettings
from .linked_service import AzureLinkedService, AzureLinkedServiceSettings

PACKAGE_NAME = "ds-provider-azure-py-lib"
__version__ = version(PACKAGE_NAME)

__all__ = [
    "AzureBlob",
    "AzureBlobDatasetSettings",
    "AzureLinkedService",
    "AzureLinkedServiceSettings",
    "AzureTable",
    "AzureTableDatasetSettings",
    "__version__",
]
