# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

`dsar` is a Python package for computing **Displacement Seismic Amplitude Ratio (DSAR)** values from miniSEED seismic data stored in SeisComP Data Structure (SDS) directories. It is used in volcanology to detect changes in seismic character related to volcanic unrest.

## Development Commands

This project uses `uv` as the package manager.

```bash
# Install dependencies
uv sync

# Run the example notebook
jupyter notebook example.ipynb

# Build the package
uv build

# Install locally in editable mode
uv pip install -e .
```

There is no test suite. Functionality is validated via `example.ipynb` and the `examples/` directory.

## Architecture

**Source layout:** `src/dsar/` (PEP 517 layout with hatchling build backend)

### Core Classes (exported from `src/dsar/__init__.py`)

| Class | Module | Purpose |
|---|---|---|
| `DSAR` | `core.py` | Main calculation engine — loads data, filters, integrates, computes ratios, saves CSV |
| `SDS` | `sds.py` | Reads miniSEED files from an SDS directory structure via ObsPy |
| `FrequencyBands` | `frequency_bands.py` | Defines LF and HF frequency band triplets `[low_cut, high_cut_lf, high_cut_hf]` |
| `PlotDsar` | `plot.py` | Loads output CSVs and renders/saves DSAR time-series plots |

### Data Pipeline

1. **`SDS.get()`** — reads miniSEED for a date range into an ObsPy Stream
2. **`DSAR.process()`** (static) — detrends, filters, integrates to displacement
3. **`DSAR.calculate()`** — computes LF/HF displacement amplitude ratio per resample interval
4. **`DSAR.save()`** — writes daily CSVs including 6h and 24h rolling medians
5. **`PlotDsar.plot()`** — renders scatter + smoothed median lines from combined CSVs

### Output Directory Structure

```
output/dsar/{NSLC}/{RESAMPLE}/
    {NSLC}_{DATE}.csv          # daily output
    combined_{RESAMPLE}_{NSLC}.csv  # auto-combined on plot
output/figures/dsar/{NSLC}/
    {NSLC}_{RESAMPLE}_{START}_{END}.jpg
```

### Key Design Notes

- `dsar_dev.py` in the repo root is a legacy monolithic version; the active code is in `src/dsar/`.
- Default frequency bands: LF = 0.1–4.5 Hz, HF = 0.1–16.0 Hz (with bandpass corners defined as triplets).
- Resampling interval defaults to `"10T"` (10 minutes, pandas offset alias).
- ObsPy is the core dependency for seismic I/O and signal processing (filtering, integration).
