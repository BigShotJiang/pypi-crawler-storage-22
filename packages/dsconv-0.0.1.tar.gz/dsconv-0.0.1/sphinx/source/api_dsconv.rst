Signal module
-------------

.. automodule:: dsconv

Preamble
~~~~~~~~

This module provides a function to compute ``F`` down-sampled convolutions using Numba.

List of functions
~~~~~~~~~~~~~~~~~

.. autofunction:: dsconv
