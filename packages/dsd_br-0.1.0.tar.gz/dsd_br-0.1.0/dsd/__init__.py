"""
DSD - Ferramentas para extração e processamento de dados do STF

Este pacote fornece funções para fazer web scraping e processamento de dados
do portal do Supremo Tribunal Federal (STF) do Brasil.
"""

__version__ = "0.1.0"
__author__ = "Alexandre Araújo Costa"
__email__ = "alexandre.araujo.costa@gmail.com"
__maintainer__ = "Alexandre Araújo Costa, Henrique Araújo Costa"

# Importar funções principais para facilitar o uso
from .dsd import (
    # Funções de requisição HTTP
    get,
    get_json,
    get_response,

    # Funções de extração de texto
    extract,
    extrair,
    clext,

    # Funções de limpeza
    clean,
    limpar,
    limpar_para_csv,

    # Funções de arquivo
    carregar_arquivo,
    gravar,

    # Funções de CSV
    csv_to_list,
    write_csv_header,
    write_csv_row,

    # Funções de processamento
    extrair_partes,
    extrair_andamentos,
    listar_partes,

    # Funções de estados
    limpa_estado,
    estado_nome_completo,
    siglas,

    # Funções de data
    date,
    ajustar_mes,
)

__all__ = [
    # HTTP
    'get',
    'get_json',
    'get_response',

    # Extração
    'extract',
    'extrair',
    'clext',

    # Limpeza
    'clean',
    'limpar',
    'limpar_para_csv',

    # Arquivo
    'carregar_arquivo',
    'gravar',

    # CSV
    'csv_to_list',
    'write_csv_header',
    'write_csv_row',

    # Processamento
    'extrair_partes',
    'extrair_andamentos',
    'listar_partes',

    # Estados
    'limpa_estado',
    'estado_nome_completo',
    'siglas',

    # Data
    'date',
    'ajustar_mes',
]
