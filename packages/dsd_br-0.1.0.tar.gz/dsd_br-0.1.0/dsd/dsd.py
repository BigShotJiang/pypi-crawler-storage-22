import csv
import requests
import time
import os
from unicodedata import normalize
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
import time
from selenium.webdriver.chrome.options import Options
import json
from typing import Any, Optional


# Constante global para estados brasileiros
ESTADOS_BRASILEIROS = [
    ['ACRE', '/AC'],
    ['ALAGOAS', '/AL'],
    ['AMAPA', '/AP'],
    ['AMAZONAS', '/AM'],
    ['BAHIA', '/BA'],
    ['CEARA', '/CE'],
    ['DISTRITO FEDERAL', '/DF'],
    ['ESPIRITO SANTO', '/ES'],
    ['GOIAS', '/GO'],
    ['MARANHAO', '/MA'],
    ['MATO GROSSO DO SUL', '/MS'],
    ['MATO GROSSO', '/MT'],
    ['MINAS GERAIS', '/MG'],
    ['PARAIBA', '/PB'],
    ['PARANA', '/PR'],
    ['PERNAMBUCO', '/PE'],
    ['PIAUI', '/PI'],
    ['RIO DE JANEIRO', '/RJ'],
    ['RIO GRANDE DO NORTE', '/RN'],
    ['RIO GRANDE DO SUL', '/RS'],
    ['RONDONIA', '/RO'],
    ['RORAIMA', '/RR'],
    ['SANTA CATARINA', '/SC'],
    ['SAO PAULO', '/SP'],
    ['SERGIPE', '/SE'],
    ['PARA', '/PA'],
    ['TOCANTINS', '/TO']
]


def adicionar(nomedoarquivo: str, dados: str) -> None:
    """Adiciona dados ao final de um arquivo.
    
    Args:
        nomedoarquivo: Parâmetro de entrada.
        dados: Parâmetro de entrada.
    """
    arquivo = open(nomedoarquivo, 'a', encoding='utf-8')
    arquivo.write(dados)
    arquivo.close()

def ajusta_requerentes(string: str) -> str:
    """Ajusta nomes de requerentes específicos.
    
    Args:
        string: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    string = string.replace('FERNANDO AFFONSO COLLOR DE MELLO','ALAGOAS')
    string = string.replace('ADVOGADO GERAL DA UNIAO','PRESIDENTE DA REPUBLICA')
    string = string.replace('FENABAN ', '')
    string = string.replace('SINDICATO D','SIND. D')
    

    governadores = ['ACRE',
                     'ALAGOAS',
                     'AMAPA',
                     'AMAZONAS',
                     'BAHIA',
                     'CEARA',
                     'ESPIRITO SANTO',
                     'GOIAS',
                     'MARANHAO',
                     'MATO GROSSO',
                     'MATO GROSSO DO SUL',
                     'MINAS GERAIS',
                     'PARA',
                     'PARAIBA',
                     'PARANA',
                     'PARANA',
                     'PERNAMBUCO',
                     'PIAUI',
                     'PROC.GERAL DO AMAPA',
                     'RIO DE JANEIRO',
                     'RIO GRANDE DO NORTE',
                     'RIO GRANDE DO SUL',
                     'RONDONIA',
                     'RORAIMA',
                     'SANTA CATARINA',
                     'SAO PAULO',
                     'SERGIPE',
                     'TOCANTINS',
                     'TOCANTINSMATO GROSSO']
    for item in governadores:
        if string == item:
            string = 'GOV./' + item

    
    return string

def ajustar_mes(string: str) -> str:
    """Converte abreviações de meses para números (JAN->01, etc).
    
    Args:
        string: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    string = string.replace('JAN','01')
    string = string.replace('FEV','02')
    string = string.replace('MAR','03')
    string = string.replace('ABR','04')
    string = string.replace('MAI','05')
    string = string.replace('JUN','06')
    string = string.replace('JUL','07')
    string = string.replace('AGO','08')
    string = string.replace('SET','09')
    string = string.replace('OUT','10')
    string = string.replace('NOV','11')
    string = string.replace('DEZ','12')

    return string
    

def ajustar_nome(string: str) -> str:
    """Ajusta e padroniza nomes de partes processuais.
    
    Args:
        string: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    string.strip()
    
    trocar1 =[['ASSOC ','ASSOCIACAO '],
            ['GONGRESSO NACIONAL','CONGRESSO NACIONAL'],
            ['REPUBICA','REPUBLICA'],
            ['PROCURADOR GERAL','PROCURADOR-GERAL'],
            ['REUBLICA','REPUBLICA'],
            ['GONGRESSO','CONGRESSO'],
            ['(','- '],
            [')',''],
            ['  ',' '],
            ['MINISTRA','MINISTRO'],
            ['PRO-BELEZA','PROBELEZA'],
            ['VICE-GOV','V.GOV'],
            ['VICE PRESIDENTE','VICE-PRESIDENTE'],
            ['VICE-PRE','V.PRE'],
            ['CORREGEDOR-GERAL','CORR.GERAL'],
            ['CORREGEDORIA-GERAL','CORR.GERAL'],
            ['CORREGEDORIAGERAL','CORR.GERAL'],
            ['CORREGEDORIADA','CORR.GERAL DA'],
            ['ARCO-IRIS','ARCOIRIS'],
            ['TRT - ','TRT '],
            ['REGIAO -','REGIAO'],
            ['MATO-GROSSENSE','MATOGROSSENSE'],
            ['TRT - ','TRT '],
            ['CONSTAS ','CONTAS'],
            ['J.G.A.C.','JOSE GABRIEL AVILA CAMPELLO'],
            ['/DO ','/'],
            ['-',' - '],
            ['  ',' '],
            ['  ',' '],
            [']',''],
            
            ['- ME',''],
            ['S/A','S.A.'],
            ['LTDA.','LTDA'],
            ['PREFEITA','PREFEITO'],
            ['PREFEITO DO MUNICIPIO','PREFEITO'],
            ['PREFEITO D', 'PREF. D'],
            ['PREFEITO MUNICIPAL D','PREF. D'],
            ['PREFEITURA D','PREF. D'],
            ['PREFEITURA MUNICIPAL','PREF.'],
            ['MUNICIPIO D','MUN. D'],
            ['MINISTRO D','MIN. D'],
            ['MINISTERIO D','MIN. D'],
            ['MESA DIRETIVA','MESA DIRETORA'],
            ['MESA DIRETORA','M.D.'],
            ['MESA DA','M.D. DA'],
            ['SENADO FEDERAL','SENADO'],
            ['JUIZ DE DIREITO','JUIZ'],
            ['CORREGEDOR ','CORREGEDORIA'],
            ['CORREGEDORIA ','CORREG. '],
            ['CAMARA DE VEREADORES','CAMARA MUNICIPAL'],
            ['CAMARA MUNICIPAL','C.MUN.'],
            ['C.MUN. DO MUNICIPIO','C.MUN.'],
            ['CAMPINHAS','CAMPINAS'],
            ['DE TOCANTINS','DO TOCANTINS'],
            ['LEGISLTATIVA','LEGISLATIVA'],
            ['PRO TESTE','PROTESTE'],
            ['E TV ABERT','E TELEVISAO ABERT'],
            ['EMPRESARIOS DE RADIO','EMPRESAS DE RADIO'],
            ['ADEPOL/BRASIL','ADEPOL'],
            ['MAGISTRADOS DO BRASIL AMB','MAGISTRADOS BRASILEIROS AMB'],
            ['ANOREG/BR','ANOREG'],
            ['ANADEP A','ANADEP'],
            ['DAS DEFENSORAS E DEFENSORES','DAS DEFENSORAS E DOS DEFENSORES'],
            ['URBANOS NTU','URBANOS'],
            ['D.G. DA ',''],
            ['D.G. DO ',''],
            ['DIRETOR DA ',''],
            ['DIRETOR DO ',''],
            
            [',',''],
            ['DP DA UNIAO','DPU'],
            ['DPU DPU','DPU'],
            ['DP GERAL','DP.GERAL'],
            ['DP.GERAL','DP'],
            ['FED NAC','FED.NAC.'],
            ['AUXI LIARES','AUXILIARES'],
            
            
            ['/ACRE', '/AC'],
            ['/ALAGOAS', '/AL'],
            ['/AMAPA', '/AP'],
            ['/AMAZONAS', '/AM'],
            ['/BAHIA', '/BA'],
            ['/CEARA', '/CE'],
            ['/DISTRITO FEDERAL', '/DF'],
            ['/ESPIRITO SANTO', '/ES'],
            ['/GOIAS', '/GO'],
            ['/MARANHAO', '/MA'],
            ['/MATO GROSSO DO SUL', '/MS'],
            ['/MATO GROSSO', '/MT'],
            ['/MINAS GERAIS', '/MG'],
            ['/PARAIBA', '/PB'],
            ['/PARANA', '/PR'],
            ['/PERNAMBUCO', '/PE'],
            ['/PIAUI', '/PI'],
            ['/RIO DE JANEIRO', '/RJ'],
            ['/RIO GRANDE DO NORTE', '/RN'],
            ['/RIO GRANDE DO SUL', '/RS'],
            ['/RONDONIA', '/RO'],
            ['/RORAIMA', '/RR'],
            ['/SANTA CATARINA', '/SC'],
            ['/SAO PAULO', '/SP'],
            ['/SERGIPE', '/SE'],
            ['/PARA', '/PA'],
            ['/TOCANTINS', '/TO'],
            ['/ACRE','/AC'],
            ['/RIO DE JANEIRO','/RJ']
            ]
    for item in trocar1:
        string = string.replace(item[0],item[1])
        
        
    if 'DEMOCRATAS' in string and 'DEM ' in string:
        string = 'DEM/PFL'
    if 'DEMOCRATAS -' in string:
        string = 'DEM/PFL'
    if 'DEMOCRATAS' == string:
        string = 'DEM/PFL'
        
    if ' SINDICATO ' in string:
        string = string[string.find(' SINDICATO ')+1:] + ' ' + string[:string.find(' SINDICATO ')]
        
    if ' SOCIEDADE BRASILEIRA ' in string:
        string = string[string.find(' SOCIEDADE BRASILEIRA ')+1:] + ' ' + string[:string.find(' SOCIEDADE BRASILEIRA ')]
    
    substituir = [
              ['PROCURADOR - GERAL DA REPUBLICA','PGR'],
              ['PROCURADOR GERAL DA REPUBLICA','PGR'],
              ['PROCURADORA - GERAL DA REPUBLICA','PGR'],
              ['PROCURADORIA - GERAL DA REPUBLICA','PGR'],
              ['CONSELHO FEDERAL DA ORDEM DOS ADVOGADOS DO BRASIL','OAB'],
              ['PARTIDO PROGRESSISTA','PP'],
              ['PARTIDO COMUNISTA DO BRASIL','PC DO B'],
              ['PARTIDO COMUNISTA BRASILEIRO','PCB'],
              ['PARTIDO DA FRENTE LIBERAL','DEM/PFL'],
              ['PARTIDO DA MOBILIZACAO NACIONAL','PMN'],
              ['PARTIDO DA MULHER BRASILEIRA','PMB'],
              ['REEDIFICACAO DA ORDEM NACIONAL','PRONA'],
              ['PARTIDO DA REPUBLICA','PR'],
              ['DEMOCRACIA BRASILEIRA','PSDB'],
              ['PSDB','PSDB'],
              ['DEMOCRATA CRISTAO','PDC'],
              ['PARTIDO DEMOCRATICO TRABALHISTA','PDT'],
              ['PARTIDO DO MOVIMENTO DEMOCRATICO','PMDB'],
              ['TRABALHADORES DO BRASIL','PT DO B'],
              ['PARTIDO TRABALHISTA DO BRASIL','PT DO B'],
              ['PARTIDO DOS TRABALHADORES','PT'],
              ['PARTIDO HUMANISTA DA SOLIDARIEDADE','PHS'],
              ['PARTIDO LIBERAL','PL'],
              ['PARTIDO POPULAR SOCIAL','PPS'],
              ['PARTIDO PROGRESSISTA BRASILEIRO','PPB'],
              ['PARTIDO PROGRESSISTA REFORMADOR','PPR'],
              ['PARTIDO PROGRESSISTA','PP'],
              ['RENOVADOR TRABALHISTA BRASILEIRO','PRTB'],
              ['PARTIDO REPUBLICANO BRASILEIRO','PRB'],
              ['REPUBLICANO DA ORDEM SOCIAL','PROS'],
              ['PARTIDO REPUBLICANO PROGRESSISTA','PRP'],
              ['PARTIDO SOCIAL CRISTAO','PSC'],
              ['PARTIDO SOCIAL DEMOCRATA CRISTAO','PSDC'],
              ['PARTIDO SOCIAL DEMOCRATICO','PSD'],
              ['PARTIDO SOCIAL LIBERAL','PSL'],
              ['PARTIDO SOCIAL TRABALHISTA','PST'],
              ['SOCIALISMO E LIBERDADE','PSOL'],
              ['PARTIDO SOCIALISTA BRASILEIRO','PSB'],
              ['PARTIDO SOCIALISTA DO BRASIL','PSB'],
              ['PARTIDO SOCIALISTA DOS TRABALHADORES UNIFICADO','PSTU'],
              ['PARTIDO TRABALHISTA BRASILEIRO','PTB'],
              ['PARTIDO TRABALHISTA CRISTAO','PTC'],
              ['PARTIDO TRABALHISTA NACIONAL','PTN'],
              ['PARTIDO TRABALHISTA RENOVADOR','PTR'],
              ['PARTIDO MUNICIPALISTA BRASILEIRO','PMB'],
              ['PARTIDO NACIONAL DOS APOSENTADOS','PNA'],
              ['PARTIDO VERDE','PV'],
              ['PODEMOS','PODEMOS'],
              ['CONS.NAC. DE JUSTICA','CNJ'],
              ['CONGRESSO NACIONAL','CN'],
              ['TRIBUNAL SUPERIOR ELEITORAL','TSE'],
              ['SOLIDARIEDADE -','SOLIDARIEDADE'],
              ['PARTIDO NOVO','PARTIDO NOVO'],
              ['SUPREMO TRIBUNAL FEDERAL','STF'],
              # ['^',''],
              ['TRIBUNAL SUPERIOR DO TRABALHO','TST'],
              ['DIRETOR DA RECEITA FEDERAL','RECEITA FEDERAL'],
              ['DEPARTAMENTO DA RECEITA FEDERAL','RECEITA FEDERAL'],
              ['SINDIFISCO NACIONAL','SIND.NAC. AUDITORES FISCAIS DA RECEITA FEDERAL DO BRASIL SINDIFISCO NACIONAL'],
              ['UNIAO GERAL DOS TRABALHADORES','UNIAO GERAL DOS TRABALHADORES UGT'],
              ['UNIAO NACIONAL DAS INSTITUICOES DE AUTOGESTAO EM SAUDE','UNIAO NACIONAL DAS INSTITUICOES DE AUTOGESTAO EM SAUDE UNIDAS'],
              ['AL/SAO PAULO ADI 2476 EM APENSO','AL/SAO PAULO'],
              ['ARTIGO 19 BRASIL','ASSOC. ARTIGO 19 BRASIL'],
              ['EDUCAFRO','ASSOC. EDUCACAO E CIDADANIA DE AFRO DESCENDENTES E CARENTES EDUCAFRO'],
              ['TJ DO RIO DE JANEIRO','TJ DO RIO DE JANEIRO'],
              ['TJ DE SAO PAULO','TJ DE SAO PAULO'],
              ['TJ DE SANTA CATARINA','TJ DE SANTA CATARINA'],
              ['TRT 22REG.','TRT 22REG.'],
              ['OAB','OAB'],
              ['ABRAMED','ASSOC. BRASILEIRA DE MEDICINA DIAGNOSTICA ABRAMED']
                         
              ]
    
    for item in substituir:
        if item[0] in string:
            string = item[1]
    
    if string.find('ASSOCIACAO') > 0 and string.find('-') < 20:
        string = string.replace('-','')
        string = string.replace('  ',' ')
        string = string.replace('  ',' ')
        string = string[string.find('ASSOCIACAO'):] + ' - ' + string[:string.find('ASSOCIACAO')]
        
    if string.find('UNIAO D') > 0 and string.find('-') < 20:
        string = string.replace('-','')
        string = string.replace('  ',' ')
        string = string.replace('  ',' ')
        string = string[string.find('UNIAO'):] + ' - ' + string[:string.find('UNIAO')]
        
    if string.find('CONFEDERACAO') > 0 and string.find('-') < 20:
        string = string.replace('-','')
        string = string.replace('  ',' ')
        string = string.replace('  ',' ')
        string = string[string.find('CONFEDERACAO'):] + ' - ' + string[:string.find('CONFEDERACAO')]
        
    if string.find('FEDERACAO') > 0 and string.find('-') < 20 and 'CONFEDERACAO' not in string:
        string = string.replace('-','')
        string = string.replace('  ',' ')
        string = string.replace('  ',' ')
        string = string[string.find('FEDERACAO'):] + ' - ' + string[:string.find('FEDERACAO')]
        
    if string.find('CONSELHO') > 0 and string.find('-') < 20:
        string = string.replace('-','')
        string = string.replace('  ',' ')
        string = string.replace('  ',' ')
        string = string[string.find('CONSELHO'):] + ' - ' + string[:string.find('CONSELHO')]
        
    if 'ESTADO DO ' in string[0:12]:
        string.replace('ESTADO DO ','')
    
    if 'ESTADO DE ' in string[0:12]:
        string.replace('ESTADO DE ','')
        
    if 'ESTADO DA ' in string[0:12]:
        string.replace('ESTADO DA ','')
        
            
    string = estado_nome_completo(string)

    trocar = [['ASSEMBLEIA LEGISLATIVA DO ESTADO DE ', 'AL/'],
             ['ASSEMBLEIA LEGISLATIVA DO ESTADO DA ', 'AL/'],
             ['ASSEMBLEIA LEGISLATIVA DO ESTADO DO ', 'AL/'],
             ['ASSEMBLEIA LEGISLATIVA DO ESTADO ', 'AL/'],
             ['ASSEMBLEIA LEGISLATIVA DO ','AL/'],
             ['ASSEMBLEIA LEGISLATIVA DE ','AL/'],
             ['ASSEMBLEIA LEGISLATIVA DA ','AL/'],
             ['ASSEMBLEIA LEGISLATIVA','AL/'],
             ['CONSELHO FEDERAL', 'CONS.FED'],
             ['CONSELHO', 'CONS.'],
             ['TRIBUNAL REGIONAL ELEITORAL','TRE'],
             ['MINISTERIO PUBLICO','MP'],
             ['ASSOCIACAO NACIONAL', 'ASSOC.NAC.'],
             ['ASSOCIACAO', 'ASSOC.'],
             ['CONFEDERACAO NACIONAL', 'CONF.NAC.'],
             ['CONFEDERACAO BRASILEIRA', 'CONF.BRAS.'],
             ['CONFEDERACAO', 'CONF.'],
             ['DO ESTADO ',''],
             ['GOVERNADORA','GOVERNADOR'],
             ['GOVERNADOR DE ','GOV./ '],
             ['GOVERNADOR DO ','GOV./ '],
             ['GOVERNADOR DA ','GOV./ '],
             ['GOVERNADOR E AL/','GOV./'],
             ['SECRETARIO','SECRETARIA'],
             ['(0','('],
             ['(0','('],
             ['TRIBUNAL REGIONAL DO TRABALHO','TRT'],
             ['TRIBUNAL REGIONAL FEDERAL','TRF'],
             ['TRIBUNAL DE JUSTICA','TJ'],
             ['PROCURADORA','PROCURADOR'],
             ['PROCURADOR-GERAL DE ','PG/'],
             ['PROCURADOR-GERAL DO ','PG/'],
             ['PROCURADOR-GERAL DA ','PG/'],
             ['DF/DF','/DF'],
             ['PRESIDENTA','PRESIDENTE'],
             ['SANTANA CATARINA','SANTA CATARINA'],
             ['MINAS DE GERAIS','MINAS GERAIS'],
             ['A REGIAO','REG.'],
             ['A. REGIAO','REG.'],
             ['TRT DA','TRT'],
             ['TRF DA','TRT'],
             ['SECRETARIA DE FAZENDA','SEC.FAZ.'],
             ['SECRETARIA DA FAZENDA','SEC.FAZ.'],
             ['PRESIDENTE DO','PRES.'],
             ['PRESIDENTE DA','PRES.'],
             ['PRESIDENTE ','PRES.'],
             ['TRIBUNAL DE CONTAS DO','TC/'],
             ['TRIBUNAL DE CONTAS DE','TC/'],
             ['TRIBUNAL DE CONTAS DA','TC/'],
             ['TRIBUNAL DE CONTAS','TC'],
             ['/ ','/'],
             [' /','/'],
             ['//','/'],
             ['DEFENSORIA PUBLICA','DP'],
             ['DEFENSOR PUBLICO GERAL', 'DP.GERAL'],
             ['DEFENSOR PUBLICO-GERAL', 'DP.GERAL'],
             ['ESTADO/',''],
             ['ESTADO DE',''],
             ['JUIZ DO TRABALHO','JUIZ'],
             ['E OUTROS',''],
             ['E OUTRO',''],
             ['E OUTRA',''],
             ['E OUTRAS',''],
             ['MINISTRO DE ESTADO','MINISTRO'],
             ['SECRETARIA DE ESTADO','SECRETARIA'],
             ['SINDICADO DOS EMPREGADOS','SIND.EMPREG.'],
             ['DE MATO GROSSO DO SUL','DO MATO GROSSO DO SUL'],
             ['CONS. DA MAGISTRATURA','CONS.MAGIST.'],
             ['CONS. ESTADUAL','CONS.ESTAD.'],
             ['CONS. NACIONAL','CONS.NAC.'],
             ['CONS. REGIONAL','CONS.REG.'],
             ['CONS. SUPERIOR','CONS.SUP.'],
             ['CORREGEDORIAGERAL','CORR.GERAL'],
             ['CORREG. GERAL','CORR.GERAL'],
             ['DEFENSOR PUBLICO - GERAL','DP.GERAL'],
             ['DIRETOR - GERAL','D.G.'],
             ['FEDERACAO BRASILEIRA','FED.BRAS.'],
             ['FEDERACAO DAS ASSOCIACOES','FED.ASSOC.'],
             ['FEDERACAO NACIONAL DOS SERVIDORES','FED.NAC.SERV.'],
             ['FEDERACAO NACIONAL DOS TRABALHADORES','FED.NAC.TRAB.'],
             ['FEDERACAO NACIONAL','FED.NAC.'],
             ['INSTITUTO BRASILEIRO','INST.BRAS.'],
             ['ORGAO ESPECIAL DO',''],
             ['SINDICATO NACIONAL DE','SIND.NAC.'],
             ['SINDICATO NACIONAL DOS','SIND.NAC.'],
             ['SINDICATO NACIONAL DAS','SIND.NAC.'],
             ['SINDICATO NACIONAL','SIND.NAC.'],
             ['MIN. DE ESTADO','MIN.'],
             ['ORDEM DOS ADVOGADOS DO BRASIL','OAB'],
             ['PROCURADOR - GERAL','PROC.GERAL'],
             ['PROCURADOR GERAL DA REPUBLICA','PGR'],
             ['PROCURADOR GERAL','PROC.GERAL'],
             ['PROCURADORIA GERAL','PROC.GERAL'],
             ['SUPERIOR TJ','STJ'],
             [' AMPCON',''],
             ['C.MUN. DO MUN.','C.MUN.'],
             ['DO UNIAO','DA UNIAO'],
             ['FECOMERCIO PR',''],
             [' 0AB',''],
             ['PRES. BRASIL','PRES. REPUBLICA'],
             ['GOVERNO DE',''],
             ['GOVERNO DO',''],
             ['PRES. REPUBLICA','PRESIDENTE DA REPUBLICA'],
             ['PRESIDENCIA DA REPUBLICA','PRESIDENTE DA REPUBLICA'],
             ['EM EXERCICIO',''],
             ['PRES. ',''],
             ['PATRIOTA PATRI','PARTIDO PATRIOTA'],
             ['M.D. DA AL','AL'],
             ['-',''],
             ['  ',' '],
             ['  ',' '],
             ['FEDERACAO D','FED. D'],
             ['FEDERACAO INTERESTADUAL','FED.INTEREST.'],
             ['FEDERACAO NAC ','FED.NAC. '],
             ['NEOTV ', 'NEO TV'],
             ['MUNICIPAIS ANMP','MUNICIPAIS ANPM'],
             ['DIRETORIO NACIONAL DO',''],
             ['DIRETORIO NACIONAL',''],
             ['FORCA SINDICAL FS','FORCA SINDICAL'],
             ['FRENTE NACIONAL','FRENTE.NAC.'],
             ['/S ','/ '],
             ['MP FEDERAL','PGR'],
             ['DP DA UNIAO','DPU'],
             ['DP DA UNIAO DPU','DPU'],
             ['DP.GERAL','DP '],
             [' S A ',' S.A.'],
             ['FEDERACAO','FED.'],
             ['CORREGEDORIAREGIONAL','CORREG.REG.'],
             ['AL./DO ','AL./'],
             ['D.G. DA A','A'],
             ['DIRETOR AGENCIA','AGENCIA'],
             ['DIRETORIA COLEGIADA DA AGENCIA','AGENCIA'],
             ['SECRETARIA DA RECEITA FEDERAL DO BRASIL', 'RECEITA FEDERAL'],
             ['SECRETARIA DE SEGURANCA PUBLICA','SSP'],
             ['TCDO','TC/ '],
             ['CNPGEDF','CONPEG'],
             ['DE DIREITO FUNDAMENTAIS','DE DIREITOS FUNDAMENTAIS'],
             ['CONF NACIONAL','CONF.NAC.'],
             ['DPU DPU','DPU']
             
             
             ]
    
    for item in trocar:
        string = string.replace(item[0],item[1])
    
    if string[:2] == 'A ':
        string = string[2:]
        
    if string[:8] == 'ESTADO D':
        string = string[10:]
    
    if string[0:2] == 'O ':
        string = string[2:]
    
    string.strip(',')
    string.strip()
    
    return string

def carregar_arquivo(nomedoarquivo: str) -> str:
    """Carrega e retorna o conteúdo de um arquivo.
    
    Args:
        nomedoarquivo: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    arquivo = open(nomedoarquivo, 'r', encoding='utf-8')
    html = arquivo.read()
    arquivo.close()
    return html

def carregar_arquivo_composto(classe: str, numero: str, path: str) -> tuple[str, str]:
    """Carrega arquivo HTML composto por classe e número.
    
    Args:
        classe: Parâmetro de entrada.
        numero: Parâmetro de entrada.
        path: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    nomedoarquivo = (path + classe + str(0)*(4-len(numero)) + numero + '.html')
    arquivoaberto = (classe +  str(0)*(4-len(numero)) + numero + '.html')
    print (nomedoarquivo)
    arquivo = open(nomedoarquivo, 'r', encoding='utf-8')
    html = arquivo.read()
    arquivo.close()
    return arquivoaberto, html

def clean(source: str) -> str:
    """Remove espaços, quebras de linha e caracteres especiais de uma string.
    
    Args:
        source: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    source = source.replace('\n',' ')
    source = source.replace('  ',' ')
    source = source.replace('  ',' ')
    source = source.lstrip(' ')
    source = source.lstrip(' ')
    source = source.lstrip(' ')
    source = source.lstrip(' ')
    source = source.lstrip(' ')
    source = source.lstrip(' ')
    source = source.lstrip('"')
    source = source.lstrip('>')
    source = source.replace('  ',' ')
    source = source.replace('\t', '')
    source = source.replace('/#','')
    source = source.strip(' ')
    source = source.strip(' ')       
    source = source.strip('-')
    source = source.strip(' ')       
    source = source.strip(' ')       
    source = source.strip(' ')
    return source


def clext(source: str, start_at: str, end_at: str) -> str:
    """Extrai e limpa texto entre dois delimitadores.
    
    Args:
        source: Parâmetro de entrada.
        start_at: Parâmetro de entrada.
        end_at: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    # this function extracts a text
    if start_at not in source:
        return 'NA'
    else:
        start = source.find(start_at) + len(start_at)
        end = source.find(end_at, start)
        if  end_at == '' or end == -1:
            return source[start:]
        elif start_at == '':
            return source[:end]
        else:
            return clean(source[start:end])

def consolida_partes(lista: list) -> list:
    """Consolida informações de partes processuais.
    
    Args:
        lista: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    for item in lista:
        processo_parte = (item[1],item[2])
        item.append([processo_parte])
        item.pop(1)
        item.pop(1)
    return lista

def consolidar_entradas(lista: list) -> list:
    """Consolida entradas duplicadas em lista.
    
    Args:
        lista: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    partes_unicas = []
    contador = 0
    if len(lista) > 0:
        contador = contador +1
        for n in range(len(lista)-1):
            print ('Consolidando entradas: ' + str(contador) + ' de ' + str(len(lista)*2))
            if lista[n][0] == lista[n+1][0]:
                lista[n+1][2].extend(lista[n][2])
                lista[n][2] = lista[n+1][2]
                
            
        for n in range(len(lista)-1):
            contador = contador + 1
            print ('Consolidando entradas: ' + str(contador) + ' de ' + str(len(lista)*2))
            if lista[n][0] != lista[n+1][0]:
                partes_unicas.append(lista[n])
        if lista[-1][0] != lista[-2][0]:
            partes_unicas.append(lista[-1])
        
        
    partes_unicas.sort()
    return (partes_unicas)

def converter_csv_excel(arquivo: str) -> str:
    """Converte formato CSV para Excel.
    
    Args:
        arquivo: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    
    dados = carregar_arquivo(arquivo)
    
    dados = dados.replace(';[',';"[')
    dados = dados.replace('];',']";')
    dados = dados.replace(';',',')
    
    return (dados)

def csv_to_list(file: str) -> list:
    """Converte arquivo CSV em lista Python.
    
    Args:
        file: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    csv.field_size_limit(16777216)

    lista = []
    with open(file, encoding='utf-8') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            for n in range(len(row)):
                if type(row[n]) == str:
                    row[n] = row[n].replace('|','\n')
            lista.append(row)

    return (lista)

def csv_to_list_general(file: str) -> list:
    """Converte arquivo CSV em lista (versão geral).
    
    Args:
        file: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    csv.field_size_limit(16777216)

    lista = []
    with open(file) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            lista.append(row)

    return (lista)

def csv_to_list_titles(file: str) -> list:
    """Converte CSV em lista e extrai títulos das colunas.
    
    Args:
        file: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    csv.field_size_limit(16777216)

    lista = []
    with open(file, encoding='utf-8') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            lista.append(row)

        n_campos = len(lista[0])
        
        for campo in range (n_campos):
            tipo = str(campo) + ':string:'
            integral = 0
            amostra = len(lista)//10
            for n in range (amostra):
            
                objeto = lista[n][campo]
                
                if objeto != '' and objeto[0] == '[':
                    tipo = str(campo) + ':lista:'
                    if objeto[1] == '[':
                        tipo = str(campo) + ':lista2:'
                    
                try:
                        int(objeto)
                except ValueError:
                        integral = integral + 1
                    
            if integral == 1:
                tipo = str(campo) + ':int:'
                
            lista[0][campo] = tipo + str(lista[0][campo])
            print (f'Campo {campo} = {str(lista[0][campo])}')
             
        for campo in range (n_campos):
            for linha in lista[1:]:
                if 'int:' in lista[0][campo]:
                    linha[campo] = int(linha[campo])
                if 'lista:' in lista[0][campo]:
                    linha[campo] = linha[campo][1:-1]
                    # linha[campo] = linha[campo][',']
                if 'lista2:' in lista[0][campo]:
                    linha[campo] = linha[campo][2:-2]
                    
                    linha[campo] = linha[campo].split('], [')
                    
                    for n in range (len(linha[campo])):
                        linha[campo][n] = linha[campo][n].replace("'",'')
                        linha[campo][n] = linha[campo][n].replace(", ",',')
                        linha[campo][n] = linha[campo][n].split(',')

    return (lista)

def date(string: str) -> str:
    """Converte data do formato DD/MM/YYYY para YYYY-MM-DD.
    
    Args:
        string: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    elementos_data = string.split('/')
    if len(elementos_data) == 3:
        ano = elementos_data[2]
        mes = elementos_data[1]
        dia = elementos_data[0]
        data = f'{ano}-{mes}-{dia}'
        return data
    else:
        return string

def esperar(segundos: int, ciclos: int, variavel0: int) -> None:
    """Aguarda tempo especificado com contador regressivo.
    
    Args:
        segundos: Parâmetro de entrada.
        ciclos: Parâmetro de entrada.
        variavel0: Parâmetro de entrada.
    """
    if variavel0%ciclos == 0 and variavel0 != 0:
        print ('espera ' + str(variavel0))
        time.sleep(segundos)

#repetido

def estado_nome_completo(string: str) -> str:
    """Converte sigla de estado para nome completo.
    
    Args:
        string: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    for item in ESTADOS_BRASILEIROS:
        string = string.replace(item[1], item[0])
    return string

def extract(source: str, start_at: str, end_at: str) -> str:
    """Extrai texto entre dois delimitadores.
    
    Args:
        source: Parâmetro de entrada.
        start_at: Parâmetro de entrada.
        end_at: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    # this function extracts a text
    if start_at not in source:
        return 'NA'
    else:
        start = source.find(start_at) + len(start_at)
        end = source.find(end_at, start)
        if  end_at == '' or end == -1:
            return source[start:]
        elif start_at == '':
            return source[:end]
        else:
            return source[start:end]

def extrai_acordaos_da_string(arquivo_a_extrair: str, path: str) -> tuple:
    """Extrai acórdãos de uma string HTML.
    
    Args:
        arquivo_a_extrair: Parâmetro de entrada.
        path: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """

    if arquivo_a_extrair in os.listdir(path):
        nome_do_arquivo = str(path+arquivo_a_extrair)

        acordaos = carregar_arquivo (nome_do_arquivo)
        # print (arquivo_a_extrair)

        n_acordaos = extrair(acordaos,'Documentos encontrados: ','</td>')
        acordaos_publicados = []

        adi_decisao = 'NA'
        acordaos_publicados = []
        acordaos_adi = []
        acordaos_agr = []
        acordaos_emb = []
        acordaos_qo = []
        acordaos_outros = []

        if "Nenhum registro encontrado" in acordaos:
            decisao_colegiada = []

        else:
            decisao_colegiada = []

            for decisoes in range (int(n_acordaos)):


                acordaos_adi    = []
                acordaos_emb    = []
                acordaos_agr    = []
                acordaos_qo     = []
                acordaos_outros = []
                lista_processos_citados = []
                lista_procesoss_citados_com_tema = []
                acordao_tipo = 'NA'
                processo_juris = 'NA'
                relator_juris = 'NA'
                data_acordao = 'NA'
                orgao_julgador_acordao = 'NA'
                publicacao_acordao = 'NA'
                ementa = 'NA'
                decisao_juris = 'NA'
                legislacao = 'NA'
                observacao = 'NA'
                doutrina = 'NA'

                acordaos = acordaos.replace ('/n/n','/n')
                acordaos = acordaos.replace ('/t','')


                processo_juris = extrair(acordaos,'''<!-- Término do trecho que passa informações para o QueryString (Pesquisa Simultânea de Jurisprudência) --''', '<br />').upper()
                processo_juris = processo_juris.replace('AÇÃO DIRETA DE INCONSTITUCIONALIDADE', 'ADI')
                processo_juris = processo_juris.replace('ACAO DIRETA DE INCONSTITUCIONALIDADE', 'ADI')
                if 'ADI' in arquivo_a_extrair:
                    processo_juris = processo_juris.replace('AÇÃO DECLARATÓRIA DE CONSTITUCIONALIDADE', 'ADI')
                processo_juris = processo_juris.replace('MEDIDA CAUTELAR', 'MC')
                processo_juris = processo_juris.replace('\n', '')
                processo_juris = processo_juris.replace('\t', '')
                processo_juris = processo_juris.replace('>', '')
                processo_juris = processo_juris.replace('REFERENDO NA MC','MC (REFERENDO)')
                processo_juris = processo_juris.replace('REFERENDO NOS EMB.DECL.','EMB.DECL. (REFERENDO)')
                processo_juris = processo_juris.replace('REFERENDO NO AG.REG.','AG.REG (REFERENDO)')
                processo_juris = processo_juris.replace('SEGUNDOS ','')
                processo_juris = processo_juris.replace('SEGUNDO','')
                processo_juris = processo_juris.replace('TERCEIROS','')

                acordao_tipo = 'NA'

                if processo_juris[0:3] == "MC ":
                    acordao_tipo = "MC"
                elif processo_juris[0:3] == "EMB":
                    acordao_tipo = 'EMBARGOS'
                elif processo_juris[0:2] == "AG":
                    acordao_tipo = 'AGRAVO'
                elif processo_juris[0:3] == "QUE":
                    acordao_tipo = 'QO'
                elif processo_juris[0:3] == "ADI":
                    acordao_tipo = 'PRINCIPAL'
                else:
                    acordao_tipo = 'OUTROS'


                relator_juris = extrair(acordaos, 'Relator(a):&nbsp ', '<br />').upper()
                relator_juris = relator_juris.lstrip(' ')
                relator_juris = relator_juris.lstrip('MIN.')
                relator_juris = relator_juris.lstrip(' ')
                relator_juris = remover_acentos(relator_juris)

                data_acordao = extrair(acordaos, 'Julgamento:&nbsp', '&nbsp')
                data_acordao = data_acordao.replace('\t','')

                orgao_julgador_acordao = extrair(acordaos, 'Órgão Julgador:&nbsp', '<br />')

                publicacao_acordao = extrair (acordaos, '''<PRE><span style='font-family:tahoma, verdana, arial, sans-serif;font-size:1.1 em;font-weight:bold'>''', '</PRE>')

                ementa = extrair (acordaos, '''<p><div style="line-height: 150%;text-align: justify;">''', '</div>')

                decisao_juris = extrair (acordaos, '''<p><div style="text-align:justify; color: #385260; font-weight: normal; font-size: 11px">''', '</div>')

                legislacao = extrair (acordaos, '''Legislação</strong></p>''', '</PRE>')
                legislacao = legislacao.replace('\t','')
                legislacao = legislacao.replace('\n','')

                observacao =  extrair (acordaos, '''<p><strong>Observação</strong></p>''', '</PRE>')
                if 'Acórdão(s) citado(s)' in acordaos and 'Nenhum registro encontrado' not in acordaos and 'AGUARDANDO INDEXAÇÃO' not in acordaos:
                    observacao = observacao.replace ('(s)','')
                    observacao = observacao.replace ('(2ªT)','')
                    observacao = observacao.replace ('(1ªT)','')
                    observacao = observacao.replace ('(TP)','')
                    n_cit = observacao.count('href')
                    for links in range (n_cit):
                        inicio = observacao.find ('href')
                        fim = observacao.find ('>',inicio)
                        retirar = observacao[inicio:fim]
                        observacao = observacao.replace(retirar,'')

                    observacao = observacao.replace('\n','')
                    observacao = observacao.replace('<a>','')
                    observacao = observacao.replace('<a >','')
                    observacao = observacao.replace('</a>','')
                    observacao = observacao.replace(' ,',',')
                    observacao = observacao.replace(' .','.')
                    observacao = observacao.replace('.','')


                    observacao = observacao.split('(')[1:]
                    if  observacao != [] and 'Número de páginas' in observacao[-1]:
                        observacao[-1] = extrair (observacao[-1],'','Número de páginas')
                    lista_processos_citados = []
                    lista_procesoss_citados_com_tema = []
                    for obs in range (len(observacao)):
                        elemento = observacao[obs]
                        elemento = elemento.split(')')
                        tema = [elemento.pop(0)]
                        elemento = str(elemento).split(',')
                        for item in range (len(elemento)):
                            processo_citado = elemento[item]
                            processo_citado = processo_citado.lstrip('[')
                            processo_citado = processo_citado.lstrip("]")
                            processo_citado = processo_citado.lstrip(' ')
                            processo_citado = processo_citado.lstrip("'")

                            processo_citado_e_tema = processo_citado + ',' + str(tema)
                            lista_processos_citados.append(processo_citado)
                            lista_procesoss_citados_com_tema.append(processo_citado_e_tema)


                doutrina = extrair(acordaos, '''<p><strong>Doutrina</strong></p>''', '</PRE>')



                decisao_colegiada = [arquivo_a_extrair, acordao_tipo, processo_juris, relator_juris, data_acordao, orgao_julgador_acordao, publicacao_acordao, ementa, decisao_juris, legislacao, observacao, lista_processos_citados, lista_procesoss_citados_com_tema, doutrina]
                # print (decisao_colegiada)

                acordaos_publicados.append(decisao_colegiada)
                if acordao_tipo == 'PRINCIPAL':
                    acordaos_adi.append(decisao_colegiada)
                    adi_decisao = decisao_juris
                if acordao_tipo == 'EMB':
                    acordaos_emb.append(decisao_colegiada)
                if acordao_tipo == 'AGR':
                    acordaos_agr.append(decisao_colegiada)
                if acordao_tipo == 'QO':
                    acordaos_qo.append(decisao_colegiada)
                if acordao_tipo == 'OUTROS':
                    acordaos_outros.append(decisao_colegiada)




            recortar = acordaos.find('<!-- Término do trecho que passa informações para o QueryString (Pesquisa Simultânea de Jurisprudência) --')
            acordaos = acordaos[recortar+len('<!-- Término do trecho que passa informações para o QueryString (Pesquisa Simultânea de Jurisprudência) --'):]
        return (arquivo_a_extrair,
                adi_decisao,
                acordaos_publicados,
                acordaos_adi,
                acordaos_agr,
                acordaos_emb,
                acordaos_qo,
                acordaos_outros)
    else:
        return ([], 'NA', [], [], [], [], [], [])


def extrai_mono_da_string(arquivo_a_extrair: str, path: str) -> tuple:
    """Extrai decisões monocráticas de uma string HTML.
    
    Args:
    arquivo_a_extrair: Parâmetro de entrada.
    path: Parâmetro de entrada.
    
    Returns:
    Valor processado.
    """

    if arquivo_a_extrair in os.listdir(path):
            
            nome_do_arquivo = str(path+arquivo_a_extrair)

            monocraticas = carregar_arquivo (nome_do_arquivo)
            # print (arquivo_a_extrair)

            # n_monocraticas = extrair(monocraticas,'Documentos encontrados: ','</td>')


            n_monocraticas = monocraticas.count('img src="imagem/bt_imprimirpopup.gif" alt="Imprimir" style="position:relative;left:490px;top:-38px;margin-bottom:-55px;')

            adi_decisao_mono = 'NA'
            monocraticas_publicadas = []
            monocraticas_adi = []
            monocraticas_agr = []
            monocraticas_emb = []
            monocraticas_qo = []
            monocraticas_outros = []
            monocraticas_amicus = []
            monocraticas_mc = []
            monocraticas_publicadas = []
            processo_juris = 'NA'


            if "Nenhum registro encontrado" in monocraticas:
                decisao_monocratica = []

            else:
                decisao_monocratica = []

                for decisoes in range (int(n_monocraticas)):


                    monocraticas_adi    = []
                    monocraticas_emb    = []
                    monocraticas_agr    = []
                    monocraticas_qo     = []
                    monocraticas_outros = []

                    acordao_tipo = 'NA'
                    processo_juris = 'NA'
                    relator_juris = 'NA'
                    data_acordao = 'NA'
                    orgao_julgador_acordao = 'NA'
                    decisao_juris = 'NA'
                    legislacao = 'NA'
                    observacao = 'NA'


                    monocraticas = monocraticas.replace ('/n/n','/n')
                    monocraticas = monocraticas.replace ('/t','')


                    processo_juris = extrair(monocraticas,'''<img src="imagem/bt_imprimirpopup.gif" alt="Imprimir" style="position:relative;left:490px;top:-38px;margin-bottom:-55px;" />''', '<br />').upper()

                    processo_juris = processo_juris.replace('AÇÃO DIRETA DE INCONSTITUCIONALIDADE', 'ADI')
                    processo_juris = processo_juris.replace('ACAO DIRETA DE INCONSTITUCIONALIDADE', 'ADI')
                    processo_juris = processo_juris.replace('MEDIDA CAUTELAR', 'MC')
                    processo_juris = processo_juris.replace('\n', '')
                    processo_juris = processo_juris.replace('\t', '')
                    processo_juris = processo_juris.split('<STRONG>')[1]

                    acordao_tipo = 'na'

                    if "AMICUS" in processo_juris:
                        moocratica_tipo = "AMICUS"
                    elif 'MC' in processo_juris or 'CAUT' in processo_juris:
                        moocratica_tipo = "CAUT"
                    elif 'EMB.' in processo_juris:
                        moocratica_tipo = 'EMB'
                    elif 'AG.REG' in processo_juris:
                        moocratica_tipo = 'AGR'
                    elif 'ORDEM' in processo_juris or 'QO' in processo_juris:
                        moocratica_tipo = 'QO'
                    elif processo_juris[0:3] == "ADI":
                        moocratica_tipo = 'PRINCIPAL'
                    else:
                        moocratica_tipo = 'OUTROS'


                    relator_juris = extrair(monocraticas, 'Relator(a):&nbsp ', '<br />').upper()
                    relator_juris = relator_juris.lstrip(' ')
                    relator_juris = relator_juris.lstrip('MIN.')
                    relator_juris = relator_juris.lstrip(' ')
                    relator_juris = remover_acentos(relator_juris)

                    data_acordao = extrair(monocraticas, 'Julgamento:&nbsp', '&nbsp')
                    data_acordao = data_acordao.replace('\t','')

                    orgao_julgador_acordao = relator_juris

                    publicacao_monocratica = extrair (monocraticas, '''<pre><span style='font-family:tahoma, verdana, arial, sans-serif;font-size:1.1 em;font-weight:bold'>''', '</pre>')


                    decisao_juris = extrair (monocraticas, '''Decisão</strong></p>''', '</pre>')
                    if '<pre>' in decisao_juris:
                        decisao_juris = decisao_juris.split('<pre>')[1]
                    decisao_juris = limpar(decisao_juris)
                    decisao_juris = decisao_juris.replace('\n\n','\n')



                    legislacao = extrair (monocraticas, '''Legislação</strong></p>''', '</pre>')
                    legislacao = legislacao.replace('\t','')
                    legislacao = legislacao.replace('\n','')

                    observacao =  extrair (monocraticas, '''<p><strong>observação</strong></p>''', '</pre>')



                    decisao_monocratica = [arquivo_a_extrair, acordao_tipo, processo_juris, relator_juris, data_acordao, orgao_julgador_acordao, publicacao_monocratica, decisao_juris, legislacao, observacao]
                    # print (decisao_monocratica)

                    monocraticas_publicadas.append(decisao_monocratica)
                    if moocratica_tipo == 'PRINCIPAL':
                        monocraticas_adi.append(decisao_monocratica)
                        adi_decisao_mono = decisao_juris
                    if moocratica_tipo == 'EMB':
                        monocraticas_emb.append(decisao_monocratica)
                    if moocratica_tipo == 'AGR':
                        monocraticas_agr.append(decisao_monocratica)
                    if moocratica_tipo == 'QO':
                        monocraticas_qo.append(decisao_monocratica)
                    if moocratica_tipo == 'OUTROS':
                        monocraticas_outros.append(decisao_monocratica)
                    if moocratica_tipo == 'AMICUS':
                        monocraticas_amicus.append(decisao_monocratica)
                    if moocratica_tipo == 'MC':
                        monocraticas_mc.append(decisao_monocratica)



                recortar = monocraticas.find('''<img src="imagem/bt_imprimirpopup.gif" alt="Imprimir" style="position:relative;left:490px;top:-38px;margin-bottom:-55px;" />''')
                monocraticas = monocraticas[recortar+len('''<img src="imagem/bt_imprimirpopup.gif" alt="Imprimir" style="position:relative;left:490px;top:-38px;margin-bottom:-55px;" />'''):]
            return (processo_juris,
                    arquivo_a_extrair,
                    adi_decisao_mono,
                    monocraticas_publicadas,
                    monocraticas_adi,
                    monocraticas_mc,
                    monocraticas_agr,
                    monocraticas_emb,
                    monocraticas_qo,
                    monocraticas_amicus,
                    monocraticas_outros)
    else:
            return ([], 'NA', [], [], [], [], [], [], [],[], [])
    

def extrair(source: str, start_at: str, end_at: str) -> str:
    """Extrai texto entre dois delimitadores (retorna "na" se não encontrar).
    
    Args:
        source: Parâmetro de entrada.
        start_at: Parâmetro de entrada.
        end_at: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    # this function extracts a text
    if start_at not in source:
        return 'na'
    else:
        start = source.find(start_at) + len(start_at)
        end = source.find(end_at, start)
        if  end_at == '' or end == -1:
            return source[start:]
        elif start_at == '':
            return source[:end]
        else:
            return source[start:end]

def extrair_andamentos(string: str) -> list:
    """Extrai andamentos processuais do HTML.
    
    Args:
        string: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    string = remover_acentos(string)
    string = limpar(limpar(string))
    andamentos = string.split('<div class="andamento-item">')
    
    n= len(andamentos)
    lista_andamentos = []
    
    for andamento in andamentos[1:]:
        data = 'NA'
        nome = 'NA'
        complemento = 'NA',
        docs = 'NA'
        julgador = 'NA'
        
        # com esse formato, os andamentos indevidos não são incorporados, pois a classe deles envolve 'andamento indevido', para gerar o taxado
        n = n-1
        ordem = str(n).zfill(4)
        andamento = andamento.replace('"col-md-9 p-0 "','"col-md-9 p-0"')
        data = extrair(andamento, '<div class="andamento-data ">','</div>').upper()
        nome = extrair(andamento, '<h5 class="andamento-nome ">','</h5>').upper()
        
        complemento = extrair(andamento, '<div class="col-md-9 p-0">','</div>').upper()
        if complemento == ' ' or complemento == '':
            complemento = 'NA'
            
        docs = extrair(andamento, '"col-md-4 andamento-docs">','</div>')
        if docs == ' ' or docs == '':
            docs = 'NA'
        if 'href=' in docs:
            docs = extrair(docs,'href="', '"')
        julgador = extrair(andamento, 'julgador badge bg-info ">','</span>').upper()
        #print ([ordem, data, nome, complemento, docs, julgador])
        
        lista_andamentos.append([ordem, data, nome, complemento, docs, julgador])
        
    return lista_andamentos

def extrair_campo_lista(string: str, split: str, lista_inicio_fim: list) -> str:
    """Extrai campos específicos de uma string usando delimitadores.
    
    Args:
        string: Parâmetro de entrada.
        split: Parâmetro de entrada.
        lista_inicio_fim: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    # define o número de elementos a serem extraídos
    n_elementos= string.count(split)

    # cria uma lista (dados) com os dados da string, segmentada no split
    elementos = string.split(split)
    elementos = elementos[1:]

    # imprime o número de elementos a serem extraídos
    # print (str(n_elementos) + ' elementos')

    #define a lista que será retornada como resultado
    campo_lista = []

    # iteração sobre cada um dos n elementos
    for item in range(n_elementos):

        # carrega na variável campo um elemento de cada vez
        campo = elementos[item]
        # print (campo)
        # redefine a lista elemento_lista
        elemento_lista = []

        # insere no elemento o número de ordem, iniciando em 1
        elemento_lista.append(['ORDEM', str(item+1)])

        # identifica os atributos de cada elemento
        for elemento in range(len(lista_inicio_fim)):
            # extrai os marcadores da lista
            marcadores = lista_inicio_fim[elemento]
            atributo = marcadores[0].upper()
            inicio = marcadores[1]
            fim = marcadores[2]

            # extrai o atributo a partir dos marcadores
            dado = ''
            dado = extrair(campo, inicio, fim)
            dado = limpar(dado)
            dado = limpar(dado)
            dado = remover_acentos(dado)

            elemento_lista.append([atributo, dado.upper()])
        # acrescenta o elemento extraído na lista que compõe o campo
        campo_lista.append(elemento_lista)

    # retorna a lista de elementos como resultado função
    return campo_lista

def extrair_da_lista(relacao_de_arquivos: list, path: str) -> tuple[str, str]:
    """Extrai e remove o último elemento de uma lista de arquivos.
    
    Args:
        relacao_de_arquivos: Parâmetro de entrada.
        path: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    nomedoarquivo = relacao_de_arquivos.pop()
    arquivo = open(path + nomedoarquivo, 'r', encoding='utf-8')
    html = arquivo.read()
    arquivo.close()
    return nomedoarquivo, html

def extrair_partes(string: str) -> str:
    """Extrai informações de partes processuais do HTML.
    
    Args:
        string: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    string = remover_acentos(string)
    
    partes = string.split('<div class="processo-partes lista-dados m-l-16 p-t-0">')
    # print (partes)
    
    n=0
    lista_partes = []
    
    for parte in partes[1:]:
        n = n+1
        ordem = n
        tipo = extrair(parte, 'detalhe-parte">', '<').upper()
        tipo = tipo.replace('REQTE.(S)','REQTE')
        tipo = tipo.replace('INTDO.(A/S)','INTDO')
        tipo = tipo.replace('ADV.(A/S)','ADV')
        tipo = tipo.replace('AM. CURIAE.','AMICUS')
        nome = extrair(parte, '"nome-parte">', '<').upper()
        nome = ajustar_nome(nome)
        if tipo == 'ADV':
            if "(" in nome:
                nome = extrair(nome, '', '(')
        if tipo == 'RQTE':
            lista_partes.append([ordem, tipo, nome])
        
    return lista_partes

def gerador_de_lista(path: str, classe: str, numeroinicial: int, numerofinal: int) -> list:
    """Gera lista de arquivos HTML existentes no diretório.
    
    Args:
        path: Parâmetro de entrada.
        classe: Parâmetro de entrada.
        numeroinicial: Parâmetro de entrada.
        numerofinal: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    lista = []
    for n in range (int(numerofinal) - int(numeroinicial) + 1):
        numero = numerofinal-n
        nomedoarquivo = (path + classe + str(0)*(4-len(str(numero))) + str(numero) + '.html')
        if nomedoarquivo in os.listdir(path):
            lista.append(nomedoarquivo)
    return lista

def gerar_lista(classe: str, numeroinicial: int, numerofinal: int, path: str) -> list:
    """Gera lista de nomes de arquivos HTML.
    
    Args:
        classe: Parâmetro de entrada.
        numeroinicial: Parâmetro de entrada.
        numerofinal: Parâmetro de entrada.
        path: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    lista = []
    for item in range(int(numerofinal) - int(numeroinicial) +1):
        nomedoarquivo = (path + classe + ('0')*(4-len(str(item))) + str(item) + '.html')
        print (nomedoarquivo)
        lista.append(nomedoarquivo)
    return (lista)

def gerar_nome_arquivo(classe: str, numero: str, path: str) -> str:
    """Gera nome de arquivo baseado em classe e número.
    
    Args:
        classe: Parâmetro de entrada.
        numero: Parâmetro de entrada.
        path: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    nomedoarquivo = (path + classe + str(0)*(4-len(numero)) + numero + '.html')
    return (nomedoarquivo)

def get(url: str) -> str:
    """Faz requisição HTTP GET e retorna o conteúdo como texto.
    
    Args:
        url: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    header = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,"
              "image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "pt-PT,pt;q=0.9",
    "DNT": "1",
    "Priority": "u=0, i",
    "Sec-CH-UA": '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    "Sec-CH-UA-Mobile": "?0",
    "Sec-CH-UA-Platform": '"Windows"',
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
}

    # html = requests.get(url, headers = user_agent)
    html = requests.get(url, headers = header, verify=False)
    html.encoding = 'utf-8'
    html = html.text
    if 'CAPTCHA' in html:
        for n in range(300):
            time.sleep(1)
            print ('espera de '+ str(300-n) + ' segundos')
        html = requests.get(url, headers = header, verify=False)
        html.encoding = 'utf-8'
        html = html.text
        if 'CAPTCHA' in html:
            for n in range(600):
                time.sleep(1)
                print ('espera de '+ str(600-n) + ' segundos')
            html = requests.get(url, headers = header, verify=False)
            html.encoding = 'utf-8'
            html = html.text
    return html

def get2(url: str) -> str:
    """Faz requisição HTTP GET simples sem headers customizados.
    
    Args:
        url: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    # user_agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'}
    html = requests.get(url)
    # html.encoding = 'utf-8'
    html = html.text
    return html

def get3(url: str) -> requests.Response:
    """Faz requisição HTTP GET e retorna o objeto response.
    
    Args:
        url: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    user_agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'}
    
    # html = requests.get(url, headers = user_agent)
    html = requests.get(url, headers = user_agent, verify=False)
    
    if 'CAPTCHA' in html:
        for n in range(300):
            time.sleep(1)
            print ('espera de '+ str(300-n) + ' segundos')
        html = requests.get(url, headers = user_agent, verify=False)
        if 'CAPTCHA' in html:
            for n in range(600):
                time.sleep(1)
                print ('espera de '+ str(600-n) + ' segundos')
            html = requests.get(url, headers = user_agent, verify=False)
    return html


def get_CC(url: str) -> str:
    """Faz requisição HTTP para URL do STF.
    
    Args:
        url: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    user_agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'}
    html = requests.get(url, headers = user_agent)
    html.encoding = 'utf-8'
    html = html.text
    html = extrair (html,
                   '<div class="titulo-formulario">',
                   '<section id="mapa-do-site">')
    return html

def get_contents(url: str) -> bytes:
    """Faz requisição HTTP GET e retorna o conteúdo.
    
    Args:
        url: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    user_agent = {'user-agent': 'mozilla/5.0 (windows nt 10.0; win64; x64) applewebkit/537.36 (khtml, like gecko) chrome/119.0.0.0 safari/537.36'}
  
    # html = requests.get(url, headers = user_agent)
    html = requests.get(url, headers = user_agent, verify=False)
    html.encoding = 'utf-8'
    html = html.contents
    if 'captcha' in html:
        for n in range(300):
            time.sleep(1)
            print ('espera de '+ str(300-n) + ' segundos')
        html = requests.get(url, headers = user_agent, verify=False)
        html.encoding = 'utf-8'
        html = html.contents
        if 'captcha' in html:
            for n in range(600):
                time.sleep(1)
                print ('espera de '+ str(600-n) + ' segundos')
            html = requests.get(url, headers = user_agent, verify=False)
            html.encoding = 'utf-8'
            html = html.contents
    return html

def get_json(url: str) -> dict:
    """Faz requisição HTTP GET e retorna JSON.
    
    Args:
        url: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    user_agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'}
  
    # html = requests.get(url, headers = user_agent)
    html = requests.get(url, headers = user_agent, verify=False)
    html.encoding = 'utf-8'
    html = html.json()
    if 'CAPTCHA' in html:
        for n in range(300):
            time.sleep(1)
            print ('espera de '+ str(300-n) + ' segundos')
        html = requests.get(url, headers = user_agent, verify=False)
        html.encoding = 'utf-8'
        html = html.json()
        if 'CAPTCHA' in html:
            for n in range(600):
                time.sleep(1)
                print ('espera de '+ str(600-n) + ' segundos')
            html = requests.get(url, headers = user_agent, verify=False)
            html.encoding = 'utf-8'
            html = html.json()
    return html

def get_response(url: str) -> requests.Response:
    """Faz requisição HTTP GET e retorna o objeto response.
    
    Args:
        url: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    header = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,"
              "image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "pt-PT,pt;q=0.9",
    "DNT": "1",
    "Priority": "u=0, i",
    "Sec-CH-UA": '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    "Sec-CH-UA-Mobile": "?0",
    "Sec-CH-UA-Platform": '"Windows"',
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
}

    # html = requests.get(url, headers = user_agent)
    html = requests.get(url, headers = header, verify=False)
    html.encoding = 'utf-8'
    html = html
    if 'CAPTCHA' in html:
        for n in range(300):
            time.sleep(1)
            print ('espera de '+ str(300-n) + ' segundos')
        html = requests.get(url, headers = header, verify=False)
        html.encoding = 'utf-8'
        html = html
        if 'CAPTCHA' in html:
            for n in range(600):
                time.sleep(1)
                print ('espera de '+ str(600-n) + ' segundos')
            html = requests.get(url, headers = header, verify=False)
            html.encoding = 'utf-8'
    return html

def get_utf8(url: str) -> str:
    """Faz requisição HTTP GET com encoding UTF-8.
    
    Args:
        url: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    user_agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'}
    html = requests.get(url, headers = user_agent)
    html.encoding = 'utf-8'
    html = html.text
    return html
        

def gravar(nomedoarquivo: str, dados: str) -> None:
    """Grava dados em um arquivo.
    
    Args:
        nomedoarquivo: Parâmetro de entrada.
        dados: Parâmetro de entrada.
    """
    arquivo = open(nomedoarquivo, 'w', encoding='utf-8')
    arquivo.write(dados)
    arquivo.close()

def gravar_dados_no_arquivo(classe: str, numero: str, path: str, dados: str) -> None:
    """Grava dados em arquivo com nome baseado em classe e número.
    
    Args:
        classe: Parâmetro de entrada.
        numero: Parâmetro de entrada.
        path: Parâmetro de entrada.
        dados: Parâmetro de entrada.
    """
    nomedoarquivo = (path + classe + str(0)*(4-len(numero)) + numero + '.txt')
    arquivo = open(nomedoarquivo, 'w', encoding='utf-8')
    arquivo.write(dados)
    arquivo.close()()

#repetido

def gravar_dados_no_arquivo_nome(nomedoarquivo: str, dados: str) -> None:
    """Grava dados em arquivo com nome especificado.
    
    Args:
        nomedoarquivo: Parâmetro de entrada.
        dados: Parâmetro de entrada.
    """
    arquivo = open(nomedoarquivo, 'w', encoding='utf-8')
    arquivo.write(dados)
    arquivo.close()


def igualar_entradas_identicas_partes(lista: list, iguais: list) -> list:
    """Iguala entradas idênticas de partes.
    
    Args:
        lista: Parâmetro de entrada.
        iguais: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    
    lista.sort(reverse = True, key = lambda elem: elem[0])
    for i in range(len(lista)-1):
        item1 = lista[i]
        item2 = lista[i+1]
        if item2[0] == item1[0][:len(item2[0])]:
            if (item1[0] != item2[0] 
                and len(item2[0]) > 18 
                and '/' not in item1[0] 
                and '.' not in item1[0]):
                #mantém o que tem mais entradas
                if lista[i+1][1] > lista[i][1]:
                    iguais.append((lista[i+1][0], lista[i+1][1],lista[i+1][0],lista[i][1]))
                    lista[i+1][0] = lista[i][0]
                else:
                    iguais.append((lista[i][0],lista[i][1],lista[i+1][0],lista[i+1][1]))
                    lista[i+1][0] = lista[i][0]
            elif (item2[0] == 'CIDADANIA' or
                  'OAB' in item2[0] or
                  'SIND.' in item2[0] or
                  'MP DO TRABALHO' in item2[0] or
                  'RECEITA FEDERAL' in item2[0] or 
                  'CONS.NAC.' in item2[0]
                  ):
                #mantém o que tem mais entradas
                if lista[i+1][1] > lista[i][1]:
                    iguais.append((lista[i+1][0], lista[i+1][1],lista[i+1][0],lista[i][1]))
                    lista[i+1][0] = lista[i][0]
                else:
                    iguais.append((lista[i][0],lista[i][1],lista[i+1][0],lista[i+1][1]))
                    lista[i+1][0] = lista[i][0]
    lista.sort()
    return lista,iguais

def igualar_entradas_identicas_partes_advogados(lista: list, iguais: list) -> list:
    """Iguala entradas idênticas de partes e advogados.
    
    Args:
        lista: Parâmetro de entrada.
        iguais: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    
    lista.sort(reverse = False, key = lambda elem: elem[0])
    for i in range(len(lista)-1):
        item1 = lista[i]
        item2 = lista[i+1]
        if (item1[0] == item2[0][:len(item1[0])] 
            and item1[0] != item2[0] 
            and len(item2[0]) > 18 
            and '/' not in item1[0] 
            and '.' not in item1[0] 
            and 'CLAUDIO SANTOS' not in item1[0]):
            if lista[i+1][1] > lista[i][1]:
                iguais.append((lista[i+1][0], lista[i+1][1],lista[i+1][0],lista[i][1]))
                lista[i+1][0] = lista[i][0]
            else:
                iguais.append((lista[i][0],lista[i][1],lista[i+1][0],lista[i+1][1]))
                lista[i+1][0] = lista[i][0]          
    lista.sort()
    return lista,iguais

def inserir_ocorrencias(lista: list) -> list:
    """Insere ocorrências em lista.
    
    Args:
        lista: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """

    contador = 0
    for item in lista:
        contador = contador + 1
        ocorrencias_item = str(lista).count("'" + item[0] + "'")
        item.insert(1,ocorrencias_item)
        print ('Inserindo número de ocorrências: ' + str(contador) + ' de ' + str(len(lista)))
    # return lista.sort()

def js(object: object) -> str:
    """Converte um objeto Python para string JSON.
    
    Args:
        object: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    string = json.dumps(object, ensure_ascii= False)
    return (string)

def limpa_estado(string: str) -> str:
    """Converte nome completo de estado para sigla.
    
    Args:
        string: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    for item in ESTADOS_BRASILEIROS:
        string = string.replace(item[0], item[1])
    return string

def limpar(fonte: str) -> str:
    """Remove caracteres especiais e normaliza texto.
    
    Args:
        fonte: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    fonte = fonte.replace('\n',' ')
    fonte = fonte.replace('  ',' ')
    fonte = fonte.replace('  ',' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip('"')
    fonte = fonte.lstrip('>')
    fonte = fonte.replace('  ',' ')
    fonte = fonte.replace('\t', '')
    fonte = fonte.replace('/#','')
    fonte = fonte.strip(' ')
    fonte = fonte.strip(' ')       
    fonte = fonte.strip('-')
    fonte = fonte.strip(' ')       
    fonte = fonte.strip(' ')       
    fonte = fonte.strip(' ')
    return fonte

def limpar_arquivo(nomedoarquivo: str) -> str:
    """Limpa conteúdo de um arquivo.
    
    Args:
        nomedoarquivo: Parâmetro de entrada.
    """
    arquivoaberto =     open(nomedoarquivo, mode='w',
                             encoding="utf-8", newline='')
    arquivoaberto.close()





def limpar_classe(string: str) -> str:
    """Padroniza e abrevia classes processuais.
    
    Args:
        string: Parâmetro de entrada.
    """
    string = limpar(string)
    string = string.replace('ACAO DIRETA DE INCONSTITUCIONALIDADE','ADI')
    string = string.replace('ACAO DIRETA DE INCONSTITUCI0NALIDADE','ADI')
    string = string.replace('7CAO DIRETA DE INCONSTITUCIONALIDADE','ADI')
    string = string.replace('01CAO DIRETA DE INCONSTITUCIONALIDADE','ADI')
    string = string.replace('CAO DIRETA DE INCONSTITUCIONALIDADE','ADI')
    string = string.replace('PACAO DIRETA DE INCONSTITUCIONALIDADE','ADI')
    string = string.replace('sACAO DIRETA DE INCONSTITUCIONALIDADE','ADI')
    string = string.replace('ARGUICAO DE DESCUMPRIMENTO DE PRECEITO FUNDAMENTAL','ADPF')
    
            

def limpar_cln(string: str) -> str:
    """Limpa e padroniza string CLN.
    
    Args:
        string: Parâmetro de entrada.
    """
    string = string.upper()
    string = remover_acentos(string)
    string = string.replace ('( MED','(MED')
    string = string.replace ('E(MED','E (MED')
    string = string.replace ('(LIMINAR)','(MED. LIMINAR)')
    string = string.replace ('E MED.','E (MED')
    string = string.replace ('CAUTELAR','LIMINAR')
    

def limpar_decisao(string: str) -> str:
    """Limpa e padroniza texto de decisão.
    
    Args:
        string: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    string = string.replace('\n','')
    string = string.replace('\t','')
    string = string.replace('     ','')
    string = string.replace('  ',' ')
    string = string.upper()
    string = remover_acentos(string)
    return string

def limpar_numero(numero: str) -> str:
    """Limpa e padroniza número de processo.
    
    Args:
        numero: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    numero = numero.replace('<FONT COLOR=RED><B>','')
    numero = numero.replace('</B></FONT>','')
    numero = "0"*(4-len(numero))+numero
    return numero

def limpar_para_csv(fonte: str) -> str:
    """Limpa texto para exportação CSV.
    
    Args:
        fonte: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    if type(fonte) == str:
        fonte = fonte.replace('\n','|')
        fonte = fonte.replace('  ',' ')
        fonte = fonte.replace('  ',' ')
        fonte = fonte.lstrip(' ')
        fonte = fonte.lstrip(' ')
        fonte = fonte.lstrip(' ')
        fonte = fonte.lstrip(' ')
        fonte = fonte.lstrip(' ')
        fonte = fonte.lstrip(' ')
        fonte = fonte.lstrip('"')
        fonte = fonte.lstrip('>')
        fonte = fonte.replace('  ',' ')
        fonte = fonte.replace('\t', '')
        fonte = fonte.replace('/#','')
        fonte = fonte.strip(' ')
        fonte = fonte.strip(' ')       
        fonte = fonte.strip('-')
        fonte = fonte.strip(' ')       
        fonte = fonte.strip(' ')       
        fonte = fonte.strip(' ')
        fonte = fonte.replace('\r','|')
        fonte = fonte.replace('|||||','|')
        fonte = fonte.replace('||||','|')
        fonte = fonte.replace('|||','|')
        fonte = fonte.replace('||','|')
        fonte = fonte.strip('|')
    
    return (fonte)

def limpar_tudo(fonte: str) -> str:
    """Limpeza completa de texto removendo vários caracteres especiais.
    
    Args:
        fonte: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    fonte = fonte.replace('\n',' ')
    fonte = fonte.replace('  ',' ')
    fonte = fonte.replace('  ',' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip(' ')
    fonte = fonte.lstrip('"')
    fonte = fonte.lstrip('>')
    fonte = fonte.replace('  ',' ')
    fonte = fonte.replace('\t', '')
    fonte = fonte.replace('/#','')
    fonte = fonte.strip(' ')
    fonte = fonte.strip(' ')       
    fonte = fonte.strip('-')
    fonte = fonte.strip(' ')       
    fonte = fonte.strip(' ')       
    fonte = fonte.strip(' ')
    fonte = fonte.replace('\r','|')
    fonte = fonte.replace('|||||','|')
    fonte = fonte.replace('||||','|')
    fonte = fonte.replace('|||','|')
    fonte = fonte.replace('||','|')
    fonte = fonte.strip('|')
    
    
    fonte = fonte.replace('&Ccedil;','Ç')
    fonte = fonte.replace('&ccedil;','ç')
    fonte = fonte.replace('&Atilde;','Ã')
    fonte = fonte.replace('&atilde;','ã')
    fonte = fonte.replace('&Otilde;','Õ')
    fonte = fonte.replace('&otilde;','õ')
    
    fonte = fonte.replace('&Eacute;','É')
    fonte = fonte.replace('&eacute;','é')
    fonte = fonte.replace('&Aacute;','Á')
    fonte = fonte.replace('&aacute;','á')
    fonte = fonte.replace('&Iacute;','Í')
    fonte = fonte.replace('&iacute;','í')
    fonte = fonte.replace('&Oacute;','Ó')
    fonte = fonte.replace('&oacute;','ó')
    fonte = fonte.replace('&Uacute;','Ú')
    fonte = fonte.replace('&uacute;','ú')
    
    fonte = fonte.replace('&Ecirc;','Ê')
    fonte = fonte.replace('&ecirc;','ê')
    fonte = fonte.replace('&Acirc;','Â')
    fonte = fonte.replace('&acirc;','â')
    fonte = fonte.replace('&Ocirc;','Ô')
    fonte = fonte.replace('&ocirc;','ô')
    fonte = fonte.replace('&ordm;','º')
    fonte = fonte.replace('&sect; ','§')
    fonte = fonte.replace('&Agrave;','À')
    fonte = fonte.replace('&agrave;','à')
    fonte = fonte.replace('&ldquo;','"')
    
    fonte = fonte.strip('\r\n')
    fonte = fonte.strip(',')
    fonte = fonte.strip('null\n')
    
    fonte = re.sub('<[^<]+?>', '', fonte)
    fonte = fonte.replace('&nbsp; ','')
    fonte = fonte.replace('&nbsp;','')
    
    fonte = fonte.strip('"')
    fonte = fonte.strip('\r\n')
    fonte = fonte.strip(',')
    fonte = fonte.strip('null\n')
    fonte = fonte.strip('.')
    fonte = fonte.strip('null\n')
    
    fonte = fonte.replace('\r\n',' ')
    fonte = fonte.replace('  ',' ')
    fonte = fonte.replace('  ',' ')
    fonte = fonte.replace('  ',' ')
    
    return fonte



def listar_partes(string: str, processo: str) -> list:
    """Lista todas as partes de um processo.
    
    Args:
        string: Parâmetro de entrada.
        processo: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    string = remover_acentos(string)
    
    partes = string.split('<div class="processo-partes lista-dados m-l-16 p-t-0">')
    
    lista_partes = []
    
    for parte in partes[1:]:
        tipo = extrair(parte, 'detalhe-parte">', '<').upper()
        tipo = tipo.replace('REQTE.(S)','REQTE')
        tipo = tipo.replace('INTDO.(A/S)','INTDO')
        tipo = tipo.replace('REQDO.(A/S)','INTDO')
        tipo = tipo.replace('ADV.(A/S)','ADV')
        tipo = tipo.replace('AM. CURIAE.','AMICUS')
        tipo = tipo.replace('PROC.(A/S)(ES)','ADV/PUB')
        tipo = limpar(tipo)
        nome = extrair(parte, '"nome-parte">', '<').upper()
        nome = ajustar_nome(nome)
        if tipo == 'ADV' or tipo == 'ADV/PUB':
            if "(" in nome:
                nome = extrair(nome, '', '(')
        nome = nome.strip()
        nome = nome.replace('  ',' ')
        lista_partes.append([nome, tipo, processo])
        
    return lista_partes


def origem_ato(origem_sigla: str, intdos: str) -> str:
    """Identifica e retorna a origem de um ato processual.
    
    Args:
        origem_sigla: Parâmetro de entrada.
        intdos: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    
    ato_impugnado_origem = origem_sigla
    if ('PRESIDENTE DA REPUBLICA' in intdos 
            or 'CN;' in intdos 
            or 'SENADO' in intdos
            or 'CAMARA DOS DEPUTADOS' in intdos
            or 'AGENCIA NACIONAL' in intdos
            or 'MIN.' in intdos[:4]
            or 'CNJ' in intdos
            or 'BANCO CENTRAL' in intdos
            or 'CONS.' in intdos[:6]
            or 'TSE' in intdos):
            ato_impugnado_origem = 'FEDERAL'
            
    if ato_impugnado_origem == 'DF' and 'DISTRITO' not in intdos:
            ato_impugnado_origem = 'FEDERAL?'
    
    if intdos == 'ALALAGOAS;':
        origem_sigla == 'AL'
        ato_impugnado_origem = 'AL'
    
    intdos_resumo = intdos.replace('GOV.','')
    intdos_resumo = intdos_resumo.replace(';AL',';')
    intdos_resumo = intdos_resumo.replace(';AGOAS','ALAGOAS')
    if intdos_resumo[:2] == 'AL' and intdos_resumo[2:5] != 'AGO':
        intdos_resumo = intdos_resumo[2:]
    intdos_resumo = intdos_resumo.replace(';TC',';')
    if intdos_resumo[:2] == 'TC':
        intdos_resumo = intdos_resumo[2:]
    intdos_resumo = intdos_resumo.replace('ALAGOASALAGOAS','ALAGOAS')
    

    intdos_resumo = intdos_resumo.replace('PRESIDENTE DA REPUBLICA','FEDERAL')
    intdos_resumo = intdos_resumo.replace('CN;','FEDERAL;')
    intdos_resumo = intdos_resumo.split(';')
    
    if len(intdos_resumo) > 1:
        if intdos_resumo[0] == intdos_resumo[1]:
            intdos_resumo.pop(0)
        if len(intdos_resumo) > 1:
            if intdos_resumo[0] == intdos_resumo[1]:
                intdos_resumo.pop(0)
        intdos_resumo.pop()
        if len(intdos_resumo) == 1:
            intdos_resumo = intdos_resumo[0]
        if intdos_resumo[0] == 'FEDERAL':
            intdos_resumo = 'FEDERAL'
            
    if intdos == '':
        intdos_resumo == ''  
        
#corrige problemas na origem

    
    if origem_sigla == 'AC':
        if 'GOV.ALAGOAS' in intdos:
            ato_impugnado_origem = 'AL'  
    
    if 'TRE DE GOIAS;' in intdos and ato_impugnado_origem == 'FEDERAL?':
        ato_impugnado_origem = 'GO'
    
    lista_orgaos_federais = [
            'OAB',
            'TSE',
            'TST',
            'TC/UNIAO',
            'INSS',
            'CORREGEDORIANACIONAL',
            '/UNIAO',
            'STF',
            'MIN. D',
            'TRT',
            'TRF',
            'STJ',
            'STM',
            'TST',
            'TRE',
            'RECEITA FEDERAL',
            'IBAMA',
            'POLICIA FEDERAL',
            'SECRETARIA DA RECEITA PREVIDENCIARIA',
            'SECRETARIA DO PATRIMONIO DA UNIAO'
            ]
    
    for item in lista_orgaos_federais:
        if intdos[:len(item)] == item:
            ato_impugnado_origem = 'FEDERAL'
            
    if ato_impugnado_origem == 'FEDERAL?':

        
        for item in lista_orgaos_federais:
            if item in intdos:
                ato_impugnado_origem = 'FEDERAL'
                
    if ato_impugnado_origem == 'FEDERAL?' and intdos[:2] == 'AL':
        intdos_resumo = limpar(extrair(intdos, 'AL',';'))
        ato_impugnado_origem = limpa_estado(intdos_resumo).strip('/')
        
    if ato_impugnado_origem == 'FEDERAL?' and intdos[:2] == 'TC':
        intdos_resumo = limpar(extrair(intdos, 'TC',';'))
        ato_impugnado_origem = limpa_estado(intdos_resumo).strip('/')
        
        
    if ato_impugnado_origem == 'FEDERAL?' and intdos[:4] == 'GOV.':
        intdos_resumo = limpar(extrair(intdos, 'GOV.',';'))
        ato_impugnado_origem = limpa_estado(intdos_resumo).strip('/')
        
    if ato_impugnado_origem == 'FEDERAL?':
        for item in ['MP DE',
                     'TJ DE']:
            if intdos_resumo[:len(item)] == item:                
                intdos_resumo == intdos_resumo.replace(item,'')
                intdos_resumo =  limpa_estado(intdos_resumo).strip('/')
                
        if len(intdos_resumo) == 2:
            ato_impugnado_origem == intdos_resumo
            
    origem_ato_extraido_intdos = limpa_estado(str(intdos_resumo)).replace('/','')
    origem_ato_extraido_intdos = origem_ato_extraido_intdos.replace('TJ DE ','')
    origem_ato_extraido_intdos = origem_ato_extraido_intdos.replace('CORR.GERAL DA JUSTICA DO ','')
    origem_ato_extraido_intdos = origem_ato_extraido_intdos.replace('PREF. DO MUN. DE ','')
     
    if len(origem_ato_extraido_intdos) == 2:
        ato_impugnado_origem = origem_ato_extraido_intdos
        intdos_resumo = origem_ato_extraido_intdos
               
    if 'ACRE;ALAGOAS' in intdos or 'GOV.ACRE;GOV.AMAPA' in intdos:
        ato_impugnado_origem = 'MULTIPLA'
        
    return ato_impugnado_origem

def position1(list: list) -> str:
    """Retorna o primeiro elemento de uma lista.
    
    Args:
        list: Parâmetro de entrada.
    """
    return(list[1])



def processar_andamentos(andamentos: list) -> tuple:
    """Processa e categoriza andamentos processuais.
    
    Args:
        andamentos: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    
    a_analisar = []
    andamentos_excluidos = []
    andamentos_filtrados = []
    interlocutorias = []
    atas = []
    virtual = []
    redistribui = []
    embargos = []
    despachos = []
    agravos = []
    pautas = []
    pedidos = []
    baixadoem = 'NA'
    primeirorelator = 'NA'
    prevencao = 'NA'
    ministroexcluido = 'NA'
    protocolado = 'NA'
    autuado = 'NA'
    processofindo = 'NA'
    ritoart12 = 'NA'
    transitoemjulgado = 'NA'
    orgaojulg = 'NA'
    conexo = 'NA'
    

    autuacao_retificada = 'NA'

    # TODO: Implementar lógica de processamento de andamentos
    return (andamentos_filtrados, andamentos_excluidos, a_analisar, autuacao_retificada)

def remover_acentos(txt: Any) -> str:
    """Remove acentuação de uma string.
    
    Args:
        txt: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    return normalize('NFKD', txt).encode('ASCII', 'ignore').decode('utf-8')



def siglas() -> list[str]:
    """Retorna lista de siglas dos estados brasileiros.
    
    Returns:
        Valor processado.
    """
    return ['AC',
 'AL',
 'AP',
 'AM',
 'BA',
 'CE',
 'DF',
 'ES',
 'GO',
 'MA',
 'MS',
 'MT',
 'MG',
 'PB',
 'PR',
 'PE',
 'PI',
 'RJ',
 'RN',
 'RS',
 'RO',
 'RR',
 'SC',
 'SP',
 'SE',
 'PA',
 'TO']      
 
#   funções de limpeza


def solicitar_dados(dominio: str, path: str, querry: str) -> str:
    """Faz requisição HTTP para domínio especificado.
    
    Args:
        dominio: Parâmetro de entrada.
        path: Parâmetro de entrada.
        querry: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    user_agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'}
    html = requests.get(dominio+path+querry, headers = user_agent)
    html.encoding = 'utf-8'
    html = html.text
    return html

def solicitar_dados_AP(classe: str, numero: str) -> str:
    """Solicita dados de processo do portal STF.
    
    Args:
        classe: Parâmetro de entrada.
        numero: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    url = ('http://portal.stf.jus.br/processos/listarProcessos.asp?classe='
           + classe
           + '&numeroProcesso='
           + numero)
    print ('url: ' + url)
    user_agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'}
    string = requests.get(url, headers = user_agent)
    
    string.encoding = 'utf-8'
    htmlfonte = string.text
    htmlfonte = extrair(htmlfonte,
                        '<div class="processo-titulo m-b-8">',
                        '<div class="p-l-0" id="resumo-partes">')
    return (url + ">>>>> \n" + htmlfonte)

def solicitar_dados_CC(classe: str, numero: str) -> str:
    """Solicita dados de petição inicial do portal STF.
    
    Args:
        classe: Parâmetro de entrada.
        numero: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    url = ('http://www.stf.jus.br/portal/peticaoInicial/verPeticaoInicial.asp?base='
    # url = ('http://www.stf.jus.br/portal/peticaoInicial/verPeticaoInicial.asp?base='

           + classe
           + '&documento=&s1=1&numProcesso='
           + numero)
    print (url)
    # Módulo básico de extração
    user_agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'}
    string = requests.get(url, headers = user_agent).text
    inicio = string.find('processo/verProcessoAndamento.asp?')
    return (url + ">>>>> \n" + string[inicio:])


url = 'http://www.stf.jus.br/portal/pauta/listarCalendario.asp?data=03/03/2021'
html = requests.head

def solicitar_dados_Juris(classe: str, numero: str) -> str:
    """Solicita dados de jurisprudência do portal STF.
    
    Args:
        classe: Parâmetro de entrada.
        numero: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    url = ('http://portal.stf.jus.br/processos/listarProcessos.asp?classe='
           + classe
           +'&numeroProcesso='
           + numero)

    print (url)
    # Módulo básico de extração
    string = requests.get(url).text
    inicio = string.find('<a href="#" id="imprimir" onclick="sysImprimir(); return false;">Imprimir</a>')
    return (url + ">>>>> \n" + string[inicio:])

def solicitar_dados_mono(classe: str, numero: str) -> str:
    """Solicita dados de decisão monocrática do portal STF.
    
    Args:
        classe: Parâmetro de entrada.
        numero: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    url = ('http://stf.jus.br/portal/jurisprudencia/listarJurisprudencia.asp?s1=%28'
           + classe
           +'%24%2ESCLA%2E+E+'
           + numero
           + '%2ENUME%2E%29+NAO+S%2EPRES%2E&base=baseMonocraticas')

    print (url)
    # Módulo básico de extração
    user_agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'}
    string = requests.get(url, headers = user_agent).text
    inicio = string.find('<a href="#" id="imprimir" onclick="sysImprimir(); return false;">Imprimir</a>')
    return (url + ">>>>> \n" + string[inicio:])

def substituir_data(string: str) -> str:
    """Substitui formato de data em string.
    
    Args:
        string: Parâmetro de entrada.
    """
    string = string.lower()
    string = string.replace('jan','01')
    string = string.replace('fev','02')
    string = string.replace('mar','03')
    string = string.replace('abr','04')
    string = string.replace('mai','05')
    string = string.replace('jun','06')
    string = string.replace('jul','07')
    string = string.replace('ago','08')
    string = string.replace('set','09')
    string = string.replace('out','10')
    string = string.replace('nov','11')
    string = string.replace('dez','11')
    
    return(string)

def trim(source: str, start_at: str, end_at: str) -> str:
    """Remove texto antes e depois de delimitadores.
    
    Args:
        source: Parâmetro de entrada.
        start_at: Parâmetro de entrada.
        end_at: Parâmetro de entrada.
    
    Returns:
        Valor processado.
    """
    if source.find(start_at) == -1:
        start = 0
    else:
        start = source.find(start_at) + len(start_at)
        
    end = source.find(end_at, start)
    if  end_at == '' or end == -1:
        return source[start:]
    elif start_at == '':
        return source[:end]
    else:
        return source[start:end]

###rever

def write_csv_header(nomedoarquivo: str, string_campos: str) -> None:
    """Escreve cabeçalho em arquivo CSV.
    
    Args:
        nomedoarquivo: Parâmetro de entrada.
        string_campos: Parâmetro de entrada.
    """
    string_campos = string_campos.replace('\n','')
    string_campos = limpar(string_campos)
    string_campos = string_campos.replace('  ',' ')
    string_campos = string_campos.replace(', ',',')
    lista_de_campos = string_campos.split(',')
    if nomedoarquivo in os.listdir():
        arquivoaberto = open(nomedoarquivo, mode='r+',
                                 encoding="utf-8", newline='')
        html = arquivoaberto.read()
        arquivoaberto.close()

        
        if lista_de_campos[0] not in html[:100]:
            arquivoaberto = open(nomedoarquivo, mode='w',
                                 encoding="utf-8", newline='')
            arquivoaberto_csv = csv.writer(arquivoaberto, delimiter=',')
            arquivoaberto_csv.writerow(lista_de_campos)
            arquivoaberto.close()
    else:
            arquivoaberto = open(nomedoarquivo, mode='w',
                                 encoding="utf-8", newline='')
            arquivoaberto_csv = csv.writer(arquivoaberto, delimiter=',')
            arquivoaberto_csv.writerow(lista_de_campos)
            arquivoaberto.close()
            

def write_csv_line(nomedoarquivo: str, dados: str) -> None:
    """Escreve uma linha em arquivo CSV.
    
    Args:
        nomedoarquivo: Parâmetro de entrada.
        dados: Parâmetro de entrada.
    """
    if dados != []:
        arquivoaberto = open(nomedoarquivo, mode='a+', encoding="utf-8", newline='')
        arquivoaberto_csv = csv.writer(arquivoaberto, delimiter=',', quotechar = '"')
        arquivoaberto_csv.writerow(dados)
        arquivoaberto.close()
        

def write_csv_lines(nomedoarquivo: str, dados: str) -> None:
    """Escreve múltiplas linhas em arquivo CSV.
    
    Args:
        nomedoarquivo: Parâmetro de entrada.
        dados: Parâmetro de entrada.
    """
    if dados != []:
        arquivoaberto = open(nomedoarquivo, mode='a+',
                             encoding="utf-8", newline='')
        arquivoaberto_csv = csv.writer(arquivoaberto, delimiter=',', quotechar = '"')
        arquivoaberto_csv.writerows(dados)
        arquivoaberto.close()
        


def write_csv_row(nomedoarquivo: str, dados: str) -> None:
    """Escreve uma linha em arquivo CSV.
    
    Args:
        nomedoarquivo: Parâmetro de entrada.
        dados: Parâmetro de entrada.
    """
    for n in range(len(dados)):
        dados[n] = limpar_para_csv(dados[n])
    if dados != []:
        arquivoaberto = open(nomedoarquivo, mode='a+', encoding="utf-8", newline='')
        arquivoaberto_csv = csv.writer(arquivoaberto, delimiter=',', quotechar = '"')
        arquivoaberto_csv.writerow(dados)
        arquivoaberto.close()
    else:
        print ('Dados a serem escritos devem ser inseridos com formato lista')
        

def write_csv_rows(nomedoarquivo: str, dados: str) -> None:
    """Escreve múltiplas linhas em arquivo CSV.
    
    Args:
        nomedoarquivo: Parâmetro de entrada.
        dados: Parâmetro de entrada.
    """
    if dados != []:
        arquivoaberto = open(nomedoarquivo, mode='a+',
                             encoding="utf-8", newline='')
        print ('gravando')
        arquivoaberto_csv = csv.writer(arquivoaberto, delimiter=',', quotechar = '"')
        arquivoaberto_csv.writerows(dados)
        arquivoaberto.close()
        