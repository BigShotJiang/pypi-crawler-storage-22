"""Setup configuration for dsd"""

from setuptools import setup, find_packages
import pathlib

# Ler README
here = pathlib.Path(__file__).parent.resolve()
long_description = (here / "README.md").read_text(encoding="utf-8")

setup(
    name="dsd-br",
    version="0.1.0",
    description="Ferramentas para extração e processamento de dados do STF (Supremo Tribunal Federal do Brasil)",
    long_description=long_description,
    long_description_content_type="text/markdown",

    # Informações do autor
    author="Alexandre Araújo Costa",
    author_email="alexandre.araujo.costa@gmail.com",
    maintainer="Alexandre Araújo Costa, Henrique Araújo Costa",

    # URLs do projeto
    url="https://github.com/AlexandreAraujoCosta/DSD",
    project_urls={
        "Bug Reports": "https://github.com/AlexandreAraujoCosta/DSD/issues",
        "Source": "https://github.com/AlexandreAraujoCosta/DSD",
    },

    # Classificadores (ajudam usuários a encontrar seu projeto)
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Legal Industry",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],

    # Palavras-chave
    keywords="stf, scraping, web scraping, supremo tribunal federal, brasil, jurisprudencia, direito",

    # Pacotes a incluir
    packages=find_packages(exclude=["tests", "tests.*"]),

    # Versão mínima do Python
    python_requires=">=3.7",

    # Dependências
    install_requires=[
        "requests>=2.31.0",
        "selenium>=4.0.0",
    ],

    # Dependências extras (opcional)
    extras_require={
        "dev": [
            "pytest>=7.0",
            "black>=22.0",
            "flake8>=5.0",
            "mypy>=0.990",
        ],
    },

    # Scripts de linha de comando (se houver)
    # entry_points={
    #     "console_scripts": [
    #         "dsd=dsd.cli:main",
    #     ],
    # },
)
