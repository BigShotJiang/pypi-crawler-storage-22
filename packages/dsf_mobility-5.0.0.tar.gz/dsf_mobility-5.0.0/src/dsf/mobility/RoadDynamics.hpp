/// @file       /src/dsf/headers/RoadDynamics.hpp
/// @brief      Defines the RoadDynamics class.
///
/// @details    This file contains the definition of the RoadDynamics class.
///             The RoadDynamics class represents the dynamics of the network. It is templated by the type
///             of the graph's id and the type of the graph's capacity.
///             The graph's id and capacity must be unsigned integral types.

#pragma once

#include <algorithm>
#include <atomic>
#include <cassert>
#include <cmath>
#include <concepts>
#include <exception>
#include <format>
#include <fstream>
#include <iomanip>
#include <numeric>
#include <optional>
#include <random>
#include <span>
#include <sstream>
#include <iostream>
#include <thread>
#include <unordered_map>
#include <variant>
#include <vector>

#include <tbb/tbb.h>
#include <spdlog/spdlog.h>

#include "../base/Dynamics.hpp"
#include "Agent.hpp"
#include "Itinerary.hpp"
#include "RoadNetwork.hpp"
#include "../utility/Typedef.hpp"

static constexpr auto CACHE_FOLDER = "./.dsfcache/";
static constexpr auto U_TURN_PENALTY_FACTOR = 0.1;

namespace dsf::mobility {
  /// @brief The RoadDynamics class represents the dynamics of the network.
  /// @tparam delay_t The type of the agent's delay
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  class RoadDynamics : public Dynamics<RoadNetwork> {
    std::vector<Id> m_nodeIndices;
    std::vector<std::unique_ptr<Agent>> m_agents;
    std::unordered_map<Id, std::shared_ptr<Itinerary>> m_itineraries;
    std::unordered_map<Id, double> m_originNodes;
    std::unordered_map<Id, double> m_destinationNodes;
    tbb::concurrent_unordered_map<Id, std::size_t> m_originCounts;
    tbb::concurrent_unordered_map<Id, std::size_t> m_destinationCounts;
    std::atomic<std::size_t> m_nAgents{0}, m_nAddedAgents{0}, m_nInsertedAgents{0},
        m_nKilledAgents{0}, m_nArrivedAgents{0};

  protected:
    std::unordered_map<Id, std::unordered_map<Id, size_t>> m_turnCounts;
    std::unordered_map<Id, std::array<long, 4>> m_turnMapping;
    tbb::concurrent_unordered_map<Id, std::unordered_map<Direction, double>>
        m_queuesAtTrafficLights;
    tbb::concurrent_vector<std::pair<double, double>> m_travelDTs;
    std::time_t m_previousOptimizationTime{0};

  protected:
    std::function<double(std::unique_ptr<Street> const&)> m_weightFunction;
    std::optional<double> m_errorProbability{std::nullopt};
    std::optional<double> m_passageProbability{std::nullopt};
    std::optional<double> m_meanTravelDistance{std::nullopt};
    std::optional<std::time_t> m_meanTravelTime{std::nullopt};
    std::optional<delay_t> m_dataUpdatePeriod;
    bool m_bCacheEnabled;
    PathWeight m_pathWeight = PathWeight::TRAVELTIME;
    double m_weightTreshold;
    std::optional<double> m_timeToleranceFactor{std::nullopt};
    bool m_forcePriorities{false};
    // Saving variables
    std::time_t m_savingInterval{0};
    bool m_bSaveStreetData{false};
    bool m_bSaveTravelData{false};
    bool m_bSaveAverageStats{false};

  private:
    /// @brief Kill an agent
    /// @param pAgent A std::unique_ptr to the agent to kill
    std::unique_ptr<Agent> m_killAgent(std::unique_ptr<Agent> pAgent);
    /// @brief Update the path of a single itinerary using Dijsktra's algorithm
    /// @param pItinerary An std::shared_ptr to the itinerary
    void m_updatePath(std::shared_ptr<Itinerary> const& pItinerary);

    /// @brief Get the next street id
    /// @param pAgent A std::unique_ptr to the agent
    /// @param pNode A std::unique_ptr to the current node
    /// @return Id The id of the randomly selected next street
    std::optional<Id> m_nextStreetId(const std::unique_ptr<Agent>& pAgent,
                                     const std::unique_ptr<RoadJunction>& pNode);
    /// @brief Evolve a street
    /// @param pStreet A std::unique_ptr to the street
    /// @param reinsert_agents If true, the agents are reinserted in the simulation after they reach their destination
    /// @details If possible, removes the first agent of the street's queue, putting it in the destination node.
    /// If the agent is going into the destination node, it is removed from the simulation (and then reinserted if reinsert_agents is true)
    void m_evolveStreet(std::unique_ptr<Street> const& pStreet, bool reinsert_agents);
    /// @brief If possible, removes one agent from the node, putting it on the next street.
    /// @param pNode A std::unique_ptr to the node
    void m_evolveNode(const std::unique_ptr<RoadJunction>& pNode);
    /// @brief Evolve the agents.
    /// @details Puts all new agents on a street, if possible, decrements all delays
    /// and increments all travel times.
    void m_evolveAgents();

    void m_trafficlightSingleTailOptimizer(double const& beta,
                                           std::optional<std::ofstream>& logStream);

    virtual double m_speedFactor(double const& density) const = 0;
    virtual double m_streetEstimatedTravelTime(
        std::unique_ptr<Street> const& pStreet) const = 0;

    /// @brief Initialize the street data table.
    /// This table contains the data of each street. Columns are:
    ///
    /// - id: The entry id (auto-incremented)
    ///
    /// - simulation_id: The simulation id
    ///
    /// - datetime: The datetime of the data entry
    ///
    /// - time_step: The time step of the data entry
    ///
    /// - street_id: The id of the street
    ///
    /// - coil: The name of the coil on the street (can be null)
    ///
    /// - density_vpk: The density in vehicles per kilometer
    ///
    /// - avg_speed_kph: The average speed in kilometers per hour
    ///
    /// - std_speed_kph: The standard deviation of the speed in kilometers per hour
    ///
    /// - counts: The counts of the coil sensor (can be null)
    ///
    /// - queue_length: The length of the queue on the street
    void m_initStreetTable() const;
    /// @brief Initialize the average stats table.
    /// This table contains the average stats of the simulation at each time step. Columns are:
    ///
    /// - id: The entry id (auto-incremented)
    ///
    /// - simulation_id: The simulation id
    ///
    /// - datetime: The datetime of the data entry
    ///
    /// - time_step: The time step of the data entry
    ///
    /// - n_ghost_agents: The number of ghost agents
    ///
    /// - n_agents: The number of agents
    ///
    /// - mean_speed_kph: The mean speed of the agents in kilometers per hour
    ///
    /// - std_speed_kph: The standard deviation of the speed of the agents in kilometers per hour
    ///
    /// - mean_density_vpk: The mean density of the streets in vehicles per kilometer
    ///
    /// - std_density_vpk: The standard deviation of the density of the streets in vehicles per kilometer
    void m_initAvgStatsTable() const;
    /// @brief Initialize the travel data table.
    /// This table contains the travel data of the agents. Columns are:
    ///
    /// - id: The entry id (auto-incremented)
    ///
    /// - simulation_id: The simulation id
    ///
    /// - datetime: The datetime of the data entry
    ///
    /// - time_step: The time step of the data entry
    ///
    /// - distance_m: The distance travelled by the agent in meters
    ///
    /// - travel_time_s: The travel time of the agent in seconds
    void m_initTravelDataTable() const;

    virtual void m_dumpSimInfo() const = 0;

    void m_dumpNetwork() const;

  public:
    /// @brief Construct a new RoadDynamics object
    /// @param graph The graph representing the network
    /// @param useCache If true, the cache is used (default is false)
    /// @param seed The seed for the random number generator (default is std::nullopt)
    /// @param weightFunction The dsf::PathWeight function to use for the pathfinding (default is dsf::PathWeight::TRAVELTIME)
    /// @param weightTreshold The weight treshold for updating the paths (default is std::nullopt)
    RoadDynamics(RoadNetwork& graph,
                 bool useCache = false,
                 std::optional<unsigned int> seed = std::nullopt,
                 PathWeight const weightFunction = PathWeight::TRAVELTIME,
                 std::optional<double> weightTreshold =
                     std::nullopt);  // 60 seconds thresholds for paths

    /// @brief Set the error probability
    /// @param errorProbability The error probability
    /// @throw std::invalid_argument If the error probability is not between 0 and 1
    void setErrorProbability(double errorProbability);
    /// @brief Set the passage probability
    /// @param passageProbability The passage probability
    /// @details The passage probability is the probability of passing through a node
    ///   It is useful in the case of random agents
    void setPassageProbability(double passageProbability);
    /// @brief Set the time tolerance factor for killing stagnant agents.
    ///   An agent will be considered stagnant if it has not moved for timeToleranceFactor * std::ceil(street_length / street_maxSpeed) time units.
    /// @param timeToleranceFactor The time tolerance factor
    /// @throw std::invalid_argument If the time tolerance factor is not positive
    void killStagnantAgents(double timeToleranceFactor = 3.);
    /// @brief Set the weight function
    /// @param pathWeight The dsf::PathWeight function to use for the pathfinding
    /// @param weightThreshold The weight threshold for updating the paths (default is std::nullopt)
    void setWeightFunction(PathWeight const pathWeight,
                           std::optional<double> weightThreshold = std::nullopt);
    /// @brief Set the force priorities flag
    /// @param forcePriorities The flag
    /// @details If true, if an agent cannot move to the next street, the whole node is skipped
    inline void setForcePriorities(bool forcePriorities) noexcept {
      m_forcePriorities = forcePriorities;
    }
    /// @brief Set the data update period.
    /// @param dataUpdatePeriod delay_t, The period
    /// @details Some data, i.e. the street queue lengths, are stored only after a fixed amount of time which is represented by this variable.
    inline void setDataUpdatePeriod(delay_t dataUpdatePeriod) noexcept {
      m_dataUpdatePeriod = dataUpdatePeriod;
    }
    /// @brief Set the mean distance travelled by a random agent. The distance will be sampled from an exponential distribution with this mean.
    /// @param meanTravelDistance The mean distance
    /// @throw std::invalid_argument If the mean distance is negative
    inline void setMeanTravelDistance(double const meanTravelDistance) {
      meanTravelDistance > 0. ? m_meanTravelDistance = meanTravelDistance
                              : throw std::invalid_argument(
                                    "RoadDynamics::setMeanTravelDistance: "
                                    "meanTravelDistance must be positive");
    };
    /// @brief Set the mean travel time for random agents. The travel time will be sampled from an exponential distribution with this mean.
    /// @param meanTravelTime The mean travel time
    inline void setMeanTravelTime(std::time_t const meanTravelTime) noexcept {
      m_meanTravelTime = meanTravelTime;
    };
    /// @brief Set the origin nodes. If the provided map is empty, the origin nodes are set using the streets' stationary weights.
    /// NOTE: the default stationary weights are 1.0 so, if not set, this is equivalent to setting uniform weights.
    /// @param originNodes The origin nodes
    void setOriginNodes(std::unordered_map<Id, double> const& originNodes = {});
    /// @brief Set the destination nodes
    /// @param destinationNodes The destination nodes
    void setDestinationNodes(std::unordered_map<Id, double> const& destinationNodes);
    /// @brief Set the destination nodes
    /// @param destinationNodes The destination nodes (as an initializer list)
    void setDestinationNodes(std::initializer_list<Id> destinationNodes);
    /// @brief Set the destination nodes
    /// @param destinationNodes A container of destination nodes ids
    /// @details The container must have a value_type convertible to Id and begin() and end() methods
    template <typename TContainer>
      requires(std::is_convertible_v<typename TContainer::value_type, Id>)
    void setDestinationNodes(TContainer const& destinationNodes);

    virtual void setAgentSpeed(std::unique_ptr<Agent> const& pAgent) = 0;
    /// @brief Initialize the turn counts map
    /// @throws std::runtime_error if the turn counts map is already initialized
    void initTurnCounts();
    /// @brief Reset the turn counts map values to zero
    /// @throws std::runtime_error if the turn counts map is not initialized
    void resetTurnCounts();

    void saveData(std::time_t const savingInterval,
                  bool const saveAverageStats = false,
                  bool const saveStreetData = false,
                  bool const saveTravelData = false);

    /// @brief Update the paths of the itineraries based on the given weight function
    /// @param throw_on_empty If true, throws an exception if an itinerary has an empty path (default is true)
    /// If false, removes the itinerary with empty paths and the associated node from the origin/destination nodes
    /// @throws std::runtime_error if throw_on_empty is true and an itinerary has an empty path
    void updatePaths(bool const throw_on_empty = true);
    /// @brief Add agents uniformly on the road network
    /// @param nAgents The number of agents to add
    /// @param itineraryId The id of the itinerary to use (default is std::nullopt)
    /// @throw std::runtime_error If there are no itineraries
    void addAgentsUniformly(Size nAgents, std::optional<Id> itineraryId = std::nullopt);

    template <typename TContainer>
      requires(std::is_same_v<TContainer, std::unordered_map<Id, double>> ||
               std::is_same_v<TContainer, std::map<Id, double>>)
    void addRandomAgents(std::size_t nAgents, TContainer const& spawnWeights);

    void addRandomAgents(std::size_t nAgents);
    /// @brief Add a set of agents to the simulation
    /// @param nAgents The number of agents to add
    /// @param src_weights The weights of the source nodes
    /// @param dst_weights The weights of the destination nodes
    /// @throw std::invalid_argument If the source and destination nodes are the same
    template <typename TContainer>
      requires(std::is_same_v<TContainer, std::unordered_map<Id, double>> ||
               std::is_same_v<TContainer, std::map<Id, double>>)
    void addAgentsRandomly(Size nAgents,
                           const TContainer& src_weights,
                           const TContainer& dst_weights);

    void addAgentsRandomly(Size nAgents);

    /// @brief Add an agent to the simulation
    /// @param agent std::unique_ptr to the agent
    void addAgent(std::unique_ptr<Agent> agent);

    template <typename... TArgs>
      requires(std::is_constructible_v<Agent, Id, std::time_t, TArgs...>)
    void addAgent(TArgs&&... args);

    template <typename... TArgs>
      requires(std::is_constructible_v<Agent, Id, std::time_t, TArgs...>)
    void addAgents(std::size_t const nAgents, TArgs&&... args);

    /// @brief Add an itinerary
    /// @param ...args The arguments to construct the itinerary
    /// @details The arguments must be compatible with any constructor of the Itinerary class
    template <typename... TArgs>
      requires(std::is_constructible_v<Itinerary, TArgs...>)
    void addItinerary(TArgs&&... args);
    /// @brief Add an itinerary
    /// @param itinerary std::unique_ptr to the itinerary
    /// @throws std::invalid_argument If the itinerary already exists
    /// @throws std::invalid_argument If the itinerary's destination is not a node of the graph
    void addItinerary(std::shared_ptr<Itinerary> itinerary);

    /// @brief Evolve the simulation
    /// @details Evolve the simulation by moving the agents and updating the travel times.
    /// In particular:
    /// - Move the first agent of each street queue, if possible, putting it in the next node
    /// - Move the agents from each node, if possible, putting them in the next street and giving them a speed.
    /// If the error probability is not zero, the agents can move to a random street.
    /// If the agent is in the destination node, it is removed from the simulation (and then reinserted if reinsert_agents is true)
    /// - Cycle over agents and update their times
    /// @param reinsert_agents If true, the agents are reinserted in the simulation after they reach their destination
    void evolve(bool reinsert_agents = false);
    /// @brief Optimize the traffic lights by changing the green and red times
    /// @param optimizationType TrafficLightOptimization, The type of optimization. Default is DOUBLE_TAIL
    /// @param logFile The file into which write the logs (default is empty, meaning no logging)
    /// @param percentage double, the maximum amount (percentage) of the green time to change (default is 0.3)
    /// @param threshold double, The ratio between the self-density and neighbour density to trigger the non-local optimization (default is 1.3)
    /// @details The local optimization is done by changing the green time of each traffic light, trying to make it proportional to the
    ///    queue lengths at each phase. The non-local optimization is done by synchronizing the traffic lights which are congested over threshold.
    void optimizeTrafficLights(
        TrafficLightOptimization optimizationType = TrafficLightOptimization::DOUBLE_TAIL,
        const std::string& logFile = std::string(),
        double const percentage = 0.3,
        double const threshold = 1.3);

    /// @brief Get the itineraries
    /// @return const std::unordered_map<Id, Itinerary>&, The itineraries
    inline auto const& itineraries() const noexcept { return m_itineraries; }
    /// @brief Get the origin nodes of the graph
    /// @return std::unordered_map<Id, double> const& The origin nodes of the graph
    inline std::unordered_map<Id, double> const& originNodes() const noexcept {
      return m_originNodes;
    }
    /// @brief Get the origin nodes of the graph
    /// @return std::unordered_map<Id, double>& The origin nodes of the graph
    inline std::unordered_map<Id, double>& originNodes() noexcept {
      return m_originNodes;
    }
    /// @brief Get the destination nodes of the graph
    /// @return std::unordered_map<Id, double> const& The destination nodes of the graph
    inline std::unordered_map<Id, double> const& destinationNodes() const noexcept {
      return m_destinationNodes;
    }
    /// @brief Get the destination nodes of the graph
    /// @return std::unordered_map<Id, double>& The destination nodes of the graph
    inline std::unordered_map<Id, double>& destinationNodes() noexcept {
      return m_destinationNodes;
    }
    /// @brief Get the agents
    /// @return const std::unordered_map<Id, Agent<Id>>&, The agents
    inline const std::vector<std::unique_ptr<Agent>>& agents() const noexcept {
      return m_agents;
    }
    /// @brief Get the number of agents currently in the simulation
    /// @return Size The number of agents
    Size nAgents() const;

    /// @brief Get the mean travel time of the agents in \f$s\f$
    /// @param clearData If true, the travel times are cleared after the computation
    /// @return Measurement<double> The mean travel time of the agents and the standard deviation
    Measurement<double> meanTravelTime(bool clearData = false);
    /// @brief Get the mean travel distance of the agents in \f$m\f$
    /// @param clearData If true, the travel distances are cleared after the computation
    /// @return Measurement<double> The mean travel distance of the agents and the standard deviation
    Measurement<double> meanTravelDistance(bool clearData = false);
    /// @brief Get the mean travel speed of the agents in \f$m/s\f$
    /// @param clearData If true, the travel times and distances are cleared after the computation
    /// @return Measurement<double> The mean travel speed of the agents and the standard deviation
    Measurement<double> meanTravelSpeed(bool clearData = false);
    /// @brief Get the turn counts of the agents
    /// @return const std::unordered_map<Id, std::unordered_map<Id, size_t>>& The turn counts. The outer map's key is the street id, the inner map's key is the next street id and the value is the number of counts
    inline std::unordered_map<Id, std::unordered_map<Id, size_t>> const& turnCounts()
        const noexcept {
      return m_turnCounts;
    };
    /// @brief Get the normalized turn counts of the agents
    /// @return const std::unordered_map<Id, std::unordered_map<Id, double>>& The normalized turn counts. The outer map's key is the street id, the inner map's key is the next street id and the value is the normalized number of counts
    std::unordered_map<Id, std::unordered_map<Id, double>> const normalizedTurnCounts()
        const noexcept;

    std::unordered_map<Id, std::array<long, 4>> turnMapping() const {
      return m_turnMapping;
    }

    /// @brief Get the origin counts of the agents
    /// @param bReset If true, the origin counts are cleared (default is true)
    tbb::concurrent_unordered_map<Id, std::size_t> originCounts(
        bool const bReset = true) noexcept;
    /// @brief Get the destination counts of the agents
    /// @param bReset If true, the destination counts are cleared (default is true)
    tbb::concurrent_unordered_map<Id, std::size_t> destinationCounts(
        bool const bReset = true) noexcept;

    /// @brief Get the mean density of the streets in \f$m^{-1}\f$
    /// @return Measurement<double> The mean density of the streets and the standard deviation
    Measurement<double> streetMeanDensity(bool normalized = false) const;
    /// @brief Get the mean flow of the streets in \f$s^{-1}\f$
    /// @return Measurement<double> The mean flow of the streets and the standard deviation
    Measurement<double> streetMeanFlow() const;
    /// @brief Get the mean flow of the streets in \f$s^{-1}\f$
    /// @param threshold The density threshold to consider
    /// @param above If true, the function returns the mean flow of the streets with a density above the threshold, otherwise below
    /// @return Measurement<double> The mean flow of the streets and the standard deviation
    Measurement<double> streetMeanFlow(double threshold, bool above) const;

    /// @brief Print a summary of the dynamics to an output stream
    /// @param os The output stream to write to (default is std::cout)
    /// @details The summary includes:
    /// - The RoadNetwork description (nodes, edges, capacity, intersections, traffic lights, roundabouts, coil sensors)
    /// - Number of inserted agents
    /// - Number of added agents
    /// - Number of arrived agents
    /// - Number of killed agents
    /// - Current number of agents in the simulation
    void summary(std::ostream& os = std::cout) const;
  };

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  RoadDynamics<delay_t>::RoadDynamics(RoadNetwork& graph,
                                      bool useCache,
                                      std::optional<unsigned int> seed,
                                      PathWeight const weightFunction,
                                      std::optional<double> weightTreshold)
      : Dynamics<RoadNetwork>(graph, seed), m_bCacheEnabled{useCache} {
    this->setWeightFunction(weightFunction, weightTreshold);
    if (m_bCacheEnabled) {
      if (!std::filesystem::exists(CACHE_FOLDER)) {
        std::filesystem::create_directory(CACHE_FOLDER);
      }
      spdlog::info("Cache enabled (default folder is {})", CACHE_FOLDER);
    }
    for (auto const& [nodeId, pNode] : this->graph().nodes()) {
      m_nodeIndices.push_back(nodeId);
    }
    for (auto const& [nodeId, weight] : this->m_destinationNodes) {
      m_itineraries.emplace(nodeId, std::make_shared<Itinerary>(nodeId, nodeId));
    }
    std::for_each(
        this->graph().edges().cbegin(),
        this->graph().edges().cend(),
        [this](auto const& pair) {
          auto const& pEdge{pair.second};
          auto const edgeId{pair.first};
          // fill turn mapping as [pair.first, [left street Id, straight street Id, right street Id, U self street Id]]
          m_turnMapping.emplace(edgeId, std::array<long, 4>{-1, -1, -1, -1});
          // Turn mappings
          const auto& srcNodeId = pEdge->target();
          for (auto const& outEdgeId : this->graph().node(srcNodeId)->outgoingEdges()) {
            auto const& pStreet{this->graph().edge(outEdgeId)};
            auto const previousStreetId = pStreet->id();
            auto const& delta{pEdge->deltaAngle(pStreet->angle())};
            if (std::abs(delta) < std::numbers::pi) {
              if (delta < 0.) {
                m_turnMapping[edgeId][dsf::Direction::RIGHT] = previousStreetId;  // right
              } else if (delta > 0.) {
                m_turnMapping[edgeId][dsf::Direction::LEFT] = previousStreetId;  // left
              } else {
                m_turnMapping[edgeId][dsf::Direction::STRAIGHT] =
                    previousStreetId;  // straight
              }
            } else {
              m_turnMapping[edgeId][dsf::Direction::UTURN] = previousStreetId;  // U
            }
          }
        });
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  std::unique_ptr<Agent> RoadDynamics<delay_t>::m_killAgent(
      std::unique_ptr<Agent> pAgent) {
    spdlog::trace("Killing agent {}", *pAgent);
    m_travelDTs.push_back({pAgent->distance(),
                           static_cast<double>(this->time_step() - pAgent->spawnTime())});
    --m_nAgents;
    auto const& streetId = pAgent->streetId();
    if (streetId.has_value()) {
      auto const& pStreet{this->graph().edge(streetId.value())};
      auto const& pNode{this->graph().node(pStreet->target())};
      auto [it, bInserted] = m_destinationCounts.insert({pNode->id(), 1});
      if (!bInserted) {
        ++it->second;
      }
    }
    return pAgent;
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::m_updatePath(std::shared_ptr<Itinerary> const& pItinerary) {
    if (m_bCacheEnabled) {
      auto const& file = std::format("{}{}.ity", CACHE_FOLDER, pItinerary->id());
      if (std::filesystem::exists(file)) {
        pItinerary->load(file);
        spdlog::debug("Loaded cached path for itinerary {}", pItinerary->id());
        return;
      }
    }
    auto const oldSize{pItinerary->path().size()};

    auto const& path{this->graph().allPathsTo(
        pItinerary->destination(), m_weightFunction, m_weightTreshold)};
    pItinerary->setPath(path);
    auto const newSize{pItinerary->path().size()};
    if (oldSize > 0 && newSize != oldSize) {
      spdlog::debug("Path for itinerary {} changed size from {} to {}",
                    pItinerary->id(),
                    oldSize,
                    newSize);
    }
    if (m_bCacheEnabled) {
      pItinerary->save(std::format("{}{}.ity", CACHE_FOLDER, pItinerary->id()));
      spdlog::debug("Saved path in cache for itinerary {}", pItinerary->id());
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  std::optional<Id> RoadDynamics<delay_t>::m_nextStreetId(
      const std::unique_ptr<Agent>& pAgent, const std::unique_ptr<RoadJunction>& pNode) {
    spdlog::trace("Computing m_nextStreetId for {}", *pAgent);
    auto const& outgoingEdges = pNode->outgoingEdges();

    // Get current street information
    std::optional<Id> previousNodeId = std::nullopt;
    std::set<Id> forbiddenTurns;
    double speedCurrent = 1.0;
    double stationaryWeightCurrent = 1.0;
    if (pAgent->streetId().has_value()) {
      auto const& pStreetCurrent{this->graph().edge(pAgent->streetId().value())};
      previousNodeId = pStreetCurrent->source();
      forbiddenTurns = pStreetCurrent->forbiddenTurns();
      speedCurrent = pStreetCurrent->maxSpeed();
      stationaryWeightCurrent = pStreetCurrent->stationaryWeight();
    }

    // Get path targets for non-random agents
    std::vector<Id> pathTargets;
    if (!pAgent->isRandom()) {
      pathTargets = pAgent->itinerary()->path().at(pNode->id());
    }

    // Calculate transition probabilities for all valid outgoing edges
    std::unordered_map<Id, double> transitionProbabilities;
    double cumulativeProbability = 0.0;

    for (const auto outEdgeId : outgoingEdges) {
      auto const& pStreetOut{this->graph().edge(outEdgeId)};

      // Check if this is a valid path target for non-random agents
      bool bIsPathTarget = false;
      if (!pathTargets.empty()) {
        bIsPathTarget =
            std::find(pathTargets.cbegin(), pathTargets.cend(), pStreetOut->target()) !=
            pathTargets.cend();
      }

      if (forbiddenTurns.contains(outEdgeId) && !bIsPathTarget) {
        continue;
      }

      if (!pathTargets.empty()) {
        if (!this->m_errorProbability.has_value() && !bIsPathTarget) {
          continue;
        }
      }

      // Calculate base probability
      auto const speedNext{pStreetOut->maxSpeed()};
      double const stationaryWeightNext = pStreetOut->stationaryWeight();
      auto const weightRatio{stationaryWeightNext /
                             stationaryWeightCurrent};  // SQRT (p_i / p_j)
      double probability = speedCurrent * speedNext * std::sqrt(weightRatio);

      // Apply error probability for non-random agents
      if (this->m_errorProbability.has_value() && !pathTargets.empty()) {
        probability *=
            (bIsPathTarget
                 ? (1. - this->m_errorProbability.value())
                 : this->m_errorProbability.value() /
                       static_cast<double>(outgoingEdges.size() - pathTargets.size()));
      }

      // Handle U-turns
      if (previousNodeId.has_value() && pStreetOut->target() == previousNodeId.value()) {
        if (pNode->isRoundabout()) {
          probability *= U_TURN_PENALTY_FACTOR;
        } else if (!bIsPathTarget) {
          continue;  // No U-turns allowed
        }
      }

      transitionProbabilities[pStreetOut->id()] = probability;
      cumulativeProbability += probability;
    }

    // Select street based on weighted probabilities
    if (transitionProbabilities.empty()) {
      spdlog::debug("No valid transitions found for {} at {}", *pAgent, *pNode);
      return std::nullopt;
    }
    if (transitionProbabilities.size() == 1) {
      auto const& onlyStreetId = transitionProbabilities.cbegin()->first;
      spdlog::debug("Only one valid transition for {} at {}: street {}",
                    *pAgent,
                    *pNode,
                    onlyStreetId);
      return onlyStreetId;
    }

    std::uniform_real_distribution<double> uniformDist{0., cumulativeProbability};
    auto const randValue = uniformDist(this->m_generator);
    Id fallbackStreetId;
    double accumulated = 0.0;
    for (const auto& [targetStreetId, probability] : transitionProbabilities) {
      accumulated += probability;
      fallbackStreetId = targetStreetId;
      if (randValue < accumulated) {
        return targetStreetId;
      }
    }
    // Return last one as fallback
    spdlog::debug(
        "Fallback selection for {} at {}: street {}", *pAgent, *pNode, fallbackStreetId);
    return fallbackStreetId;
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::m_evolveStreet(const std::unique_ptr<Street>& pStreet,
                                             bool reinsert_agents) {
    auto const nLanes = pStreet->nLanes();
    // Enqueue moving agents if their free time is up
    while (!pStreet->movingAgents().empty()) {
      auto const& pAgent{pStreet->movingAgents().top()};
      if (pAgent->freeTime() < this->time_step()) {
        break;
      }
      pAgent->setSpeed(0.);
      bool bArrived{false};
      if (!pAgent->isRandom()) {
        if (pAgent->itinerary()->destination() == pStreet->target()) {
          pAgent->updateItinerary();
        }
        if (pAgent->itinerary()->destination() == pStreet->target()) {
          bArrived = true;
        }
      }
      if (bArrived) {
        std::uniform_int_distribution<size_t> laneDist{0,
                                                       static_cast<size_t>(nLanes - 1)};
        pStreet->enqueue(laneDist(this->m_generator));
        continue;
      }
      auto const nextStreetId =
          this->m_nextStreetId(pAgent, this->graph().node(pStreet->target()));
      if (!nextStreetId.has_value()) {
        spdlog::debug(
            "No next street found for agent {} at node {}", *pAgent, pStreet->target());
        if (pAgent->isRandom()) {
          std::uniform_int_distribution<size_t> laneDist{0,
                                                         static_cast<size_t>(nLanes - 1)};
          pStreet->enqueue(laneDist(this->m_generator));
          continue;
        }
        throw std::runtime_error(std::format(
            "No next street found for agent {} at node {}", *pAgent, pStreet->target()));
      }
      auto const& pNextStreet{this->graph().edge(nextStreetId.value())};
      pAgent->setNextStreetId(pNextStreet->id());
      if (nLanes == 1) {
        pStreet->enqueue(0);
        continue;
      }
      auto const direction{pNextStreet->turnDirection(pStreet->angle())};
      switch (direction) {
        case Direction::UTURN:
        case Direction::LEFT:
          pStreet->enqueue(nLanes - 1);
          break;
        case Direction::RIGHT:
          pStreet->enqueue(0);
          break;
        default:
          std::vector<double> weights;
          for (auto const& queue : pStreet->exitQueues()) {
            weights.push_back(1. / (queue.size() + 1));
          }
          // If all weights are the same, make the last 0
          if (std::all_of(weights.begin(), weights.end(), [&](double w) {
                return std::abs(w - weights.front()) <
                       std::numeric_limits<double>::epsilon();
              })) {
            weights.back() = 0.;
            if (nLanes > 2) {
              weights.front() = 0.;
            }
          }
          // Normalize the weights
          auto const sum = std::accumulate(weights.begin(), weights.end(), 0.);
          for (auto& w : weights) {
            w /= sum;
          }
          std::discrete_distribution<size_t> laneDist{weights.begin(), weights.end()};
          pStreet->enqueue(laneDist(this->m_generator));
      }
    }
    auto const& transportCapacity{pStreet->transportCapacity()};
    std::uniform_real_distribution<double> uniformDist{0., 1.};
    for (auto i = 0; i < std::ceil(transportCapacity); ++i) {
      if (i == std::ceil(transportCapacity) - 1) {
        double integral;
        double fractional = std::modf(transportCapacity, &integral);
        if (fractional != 0. && uniformDist(this->m_generator) > fractional) {
          spdlog::trace("Skipping due to fractional capacity {:.2f} < random value",
                        fractional);
          continue;
        }
      }
      for (auto queueIndex = 0; queueIndex < nLanes; ++queueIndex) {
        if (pStreet->queue(queueIndex).empty()) {
          continue;
        }
        // Logger::debug("Taking temp agent");
        auto const& pAgentTemp{pStreet->queue(queueIndex).front()};
        if (pAgentTemp->freeTime() > this->time_step()) {
          spdlog::trace("Skipping due to time {} < free time {}",
                        this->time_step(),
                        pAgentTemp->freeTime());
          continue;
        }

        if (m_timeToleranceFactor.has_value()) {
          auto const timeDiff{this->time_step() - pAgentTemp->freeTime()};
          auto const timeTolerance{m_timeToleranceFactor.value() *
                                   std::ceil(pStreet->length() / pStreet->maxSpeed())};
          if (timeDiff > timeTolerance) {
            spdlog::debug(
                "Time-step {} - {} currently on {} ({} turn - Traffic Light? {}), "
                "has been still for more than {} seconds ({} seconds). Killing it.",
                this->time_step(),
                *pAgentTemp,
                *pStreet,
                directionToString.at(pStreet->laneMapping().at(queueIndex)),
                this->graph().node(pStreet->target())->isTrafficLight(),
                timeTolerance,
                timeDiff);
            // Kill the agent
            this->m_killAgent(pStreet->dequeue(queueIndex, this->time_step()));
            ++m_nKilledAgents;
            continue;
          }
        }
        pAgentTemp->setSpeed(0.);
        const auto& destinationNode{this->graph().node(pStreet->target())};
        if (destinationNode->isFull()) {
          spdlog::trace("Skipping due to full destination node {}", *destinationNode);
          continue;
        }
        if (destinationNode->isTrafficLight()) {
          auto& tl = dynamic_cast<TrafficLight&>(*destinationNode);
          auto const direction{pStreet->laneMapping().at(queueIndex)};
          if (!tl.isGreen(pStreet->id(), direction)) {
            spdlog::trace("Skipping due to red light on street {} and direction {}",
                          pStreet->id(),
                          directionToString.at(direction));
            continue;
          }
          spdlog::debug("Green light on street {} and direction {}",
                        pStreet->id(),
                        directionToString.at(direction));
        } else if (destinationNode->isIntersection() &&
                   pAgentTemp->nextStreetId().has_value()) {
          auto& intersection = static_cast<Intersection&>(*destinationNode);
          bool bCanPass{true};
          if (!intersection.streetPriorities().empty()) {
            spdlog::debug("Checking priorities for street {} -> {}",
                          pStreet->source(),
                          pStreet->target());
            auto const& thisDirection{this->graph()
                                          .edge(pAgentTemp->nextStreetId().value())
                                          ->turnDirection(pStreet->angle())};
            if (!intersection.streetPriorities().contains(pStreet->id())) {
              // I have to check if the agent has right of way
              auto const& inNeighbours{destinationNode->ingoingEdges()};
              for (auto const& inEdgeId : inNeighbours) {
                auto const& pStreetTemp{this->graph().edge(inEdgeId)};
                if (pStreetTemp->id() == pStreet->id()) {
                  continue;
                }
                if (pStreetTemp->nExitingAgents() == 0) {
                  continue;
                }
                if (intersection.streetPriorities().contains(pStreetTemp->id())) {
                  spdlog::debug(
                      "Skipping agent emission from street {} -> {} due to right of way.",
                      pStreet->source(),
                      pStreet->target());
                  bCanPass = false;
                  break;
                } else if (thisDirection >= Direction::LEFT) {
                  // Check if the agent has right of way using direction
                  // The problem arises only when you have to turn left
                  for (auto i{0}; i < pStreetTemp->nLanes(); ++i) {
                    // check queue is not empty and take the top agent
                    if (pStreetTemp->queue(i).empty()) {
                      continue;
                    }
                    auto const& pAgentTemp2{pStreetTemp->queue(i).front()};
                    if (!pAgentTemp2->nextStreetId().has_value()) {
                      continue;
                    }
                    auto const& otherDirection{
                        this->graph()
                            .edge(pAgentTemp2->nextStreetId().value())
                            ->turnDirection(this->graph()
                                                .edge(pAgentTemp2->streetId().value())
                                                ->angle())};
                    if (otherDirection < Direction::LEFT) {
                      spdlog::debug(
                          "Skipping agent emission from street {} -> {} due to right of "
                          "way with other agents.",
                          pStreet->source(),
                          pStreet->target());
                      bCanPass = false;
                      break;
                    }
                  }
                }
              }
            } else if (thisDirection >= Direction::LEFT) {
              for (auto const& streetId : intersection.streetPriorities()) {
                if (streetId == pStreet->id()) {
                  continue;
                }
                auto const& pStreetTemp{this->graph().edge(streetId)};
                for (auto i{0}; i < pStreetTemp->nLanes(); ++i) {
                  // check queue is not empty and take the top agent
                  if (pStreetTemp->queue(i).empty()) {
                    continue;
                  }
                  auto const& pAgentTemp2{pStreetTemp->queue(i).front()};
                  if (!pAgentTemp2->streetId().has_value()) {
                    continue;
                  }
                  auto const& otherDirection{
                      this->graph()
                          .edge(pAgentTemp2->nextStreetId().value())
                          ->turnDirection(this->graph()
                                              .edge(pAgentTemp2->streetId().value())
                                              ->angle())};
                  if (otherDirection < thisDirection) {
                    spdlog::debug(
                        "Skipping agent emission from street {} -> {} due to right of "
                        "way with other agents.",
                        pStreet->source(),
                        pStreet->target());
                    bCanPass = false;
                    break;
                  }
                }
              }
            }
          }
          if (!bCanPass) {
            spdlog::debug(
                "Skipping agent emission from street {} -> {} due to right of way",
                pStreet->source(),
                pStreet->target());
            continue;
          }
        }
        bool bArrived{false};
        if (!(uniformDist(this->m_generator) <
              m_passageProbability.value_or(std::numeric_limits<double>::max()))) {
          if (pAgentTemp->isRandom()) {
            bArrived = true;
          } else {
            spdlog::debug(
                "Skipping agent emission from street {} -> {} due to passage "
                "probability",
                pStreet->source(),
                pStreet->target());
            continue;
          }
        }
        if (!pAgentTemp->isRandom()) {
          if (destinationNode->id() == pAgentTemp->itinerary()->destination()) {
            bArrived = true;
            spdlog::debug("Agent {} has arrived at destination node {}",
                          pAgentTemp->id(),
                          destinationNode->id());
          }
        } else {
          if (!pAgentTemp->nextStreetId().has_value()) {
            bArrived = true;
            spdlog::debug("Random agent {} has arrived at destination node {}",
                          pAgentTemp->id(),
                          destinationNode->id());
          } else if (pAgentTemp->hasArrived(this->time_step())) {
            bArrived = true;
          }
        }
        if (bArrived) {
          auto pAgent =
              this->m_killAgent(pStreet->dequeue(queueIndex, this->time_step()));
          ++m_nArrivedAgents;
          if (reinsert_agents) {
            // reset Agent's values
            pAgent->reset(this->time_step());
            this->addAgent(std::move(pAgent));
          }
          continue;
        }
        if (!pAgentTemp->streetId().has_value()) {
          spdlog::error("{} has no street id", *pAgentTemp);
        }
        auto const& nextStreet{this->graph().edge(pAgentTemp->nextStreetId().value())};
        if (nextStreet->isFull()) {
          spdlog::debug(
              "Skipping agent emission from street {} -> {} due to full "
              "next street: {}",
              pStreet->source(),
              pStreet->target(),
              *nextStreet);
          continue;
        }
        auto pAgent{pStreet->dequeue(queueIndex, this->time_step())};
        spdlog::debug(
            "{} at time {} has been dequeued from street {} and enqueued on street {} "
            "with free time {}.",
            *pAgent,
            this->time_step(),
            pStreet->id(),
            nextStreet->id(),
            pAgent->freeTime());
        assert(destinationNode->id() == nextStreet->source());
        if (destinationNode->isIntersection()) {
          auto& intersection = dynamic_cast<Intersection&>(*destinationNode);
          auto const delta{nextStreet->deltaAngle(pStreet->angle())};
          intersection.addAgent(delta, std::move(pAgent));
        } else if (destinationNode->isRoundabout()) {
          auto& roundabout = dynamic_cast<Roundabout&>(*destinationNode);
          roundabout.enqueue(std::move(pAgent));
        }
      }
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::m_evolveNode(const std::unique_ptr<RoadJunction>& pNode) {
    auto const transportCapacity{pNode->transportCapacity()};
    for (auto i{0}; i < std::ceil(transportCapacity); ++i) {
      if (i == std::ceil(transportCapacity) - 1) {
        std::uniform_real_distribution<double> uniformDist{0., 1.};
        double integral;
        double fractional = std::modf(transportCapacity, &integral);
        if (fractional != 0. && uniformDist(this->m_generator) > fractional) {
          spdlog::debug("Skipping dequeue from node {} due to transport capacity {}",
                        pNode->id(),
                        transportCapacity);
          return;
        }
      }
      if (pNode->isIntersection()) {
        auto& intersection = dynamic_cast<Intersection&>(*pNode);
        if (intersection.agents().empty()) {
          return;
        }
        for (auto it{intersection.agents().begin()}; it != intersection.agents().end();) {
          auto& pAgent{it->second};
          auto const& nextStreet{this->graph().edge(pAgent->nextStreetId().value())};
          if (nextStreet->isFull()) {
            spdlog::debug("Next street is full: {}", *nextStreet);
            if (m_forcePriorities) {
              spdlog::debug("Forcing priority from {} on {}", *pNode, *nextStreet);
              return;
            }
            ++it;
            continue;
          }
          if (!m_turnCounts.empty() && pAgent->streetId().has_value()) {
            ++m_turnCounts[*(pAgent->streetId())][nextStreet->id()];
          }
          pAgent->setStreetId();
          this->setAgentSpeed(pAgent);
          pAgent->setFreeTime(this->time_step() +
                              std::ceil(nextStreet->length() / pAgent->speed()));
          spdlog::debug(
              "{} at time {} has been dequeued from intersection {} and "
              "enqueued on street {} with free time {}.",
              *pAgent,
              this->time_step(),
              pNode->id(),
              nextStreet->id(),
              pAgent->freeTime());
          nextStreet->addAgent(std::move(pAgent), this->time_step());
          it = intersection.agents().erase(it);
          break;
        }
      } else if (pNode->isRoundabout()) {
        auto& roundabout = dynamic_cast<Roundabout&>(*pNode);
        if (roundabout.agents().empty()) {
          return;
        }
        auto const& pAgentTemp{roundabout.agents().front()};
        auto const& nextStreet{this->graph().edge(pAgentTemp->nextStreetId().value())};
        if (!(nextStreet->isFull())) {
          if (!m_turnCounts.empty() && pAgentTemp->streetId().has_value()) {
            ++m_turnCounts[*(pAgentTemp->streetId())][nextStreet->id()];
          }
          auto pAgent{roundabout.dequeue()};
          pAgent->setStreetId();
          this->setAgentSpeed(pAgent);
          pAgent->setFreeTime(this->time_step() +
                              std::ceil(nextStreet->length() / pAgent->speed()));
          spdlog::debug(
              "An agent at time {} has been dequeued from roundabout {} and "
              "enqueued on street {} with free time {}: {}",
              this->time_step(),
              pNode->id(),
              nextStreet->id(),
              pAgent->freeTime(),
              *pAgent);
          nextStreet->addAgent(std::move(pAgent), this->time_step());
        } else {
          return;
        }
      }
    }
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::m_evolveAgents() {
    if (m_agents.empty()) {
      spdlog::trace("No agents to process.");
      return;
    }
    std::uniform_int_distribution<Id> nodeDist{
        0, static_cast<Id>(this->graph().nNodes() - 1)};
    spdlog::debug("Processing {} agents", m_agents.size());
    for (auto itAgent{m_agents.begin()}; itAgent != m_agents.end();) {
      auto& pAgent{*itAgent};
      if (!pAgent->srcNodeId().has_value()) {
        auto nodeIt{this->graph().nodes().begin()};
        std::advance(nodeIt, nodeDist(this->m_generator));
        pAgent->setSrcNodeId(nodeIt->second->id());
      }
      auto const& pSourceNode{this->graph().node(*(pAgent->srcNodeId()))};
      if (pSourceNode->isFull()) {
        spdlog::debug("Skipping {} due to full source {}", *pAgent, *pSourceNode);
        ++itAgent;
        continue;
      }
      if (!pAgent->nextStreetId().has_value()) {
        spdlog::debug("No next street id, generating a random one");
        auto const nextStreetId{this->m_nextStreetId(pAgent, pSourceNode)};
        if (!nextStreetId.has_value()) {
          spdlog::debug(
              "No next street found for agent {} at node {}", *pAgent, pSourceNode->id());
          itAgent = m_agents.erase(itAgent);
          continue;
        }
        pAgent->setNextStreetId(nextStreetId.value());
      }
      // spdlog::debug("Checking next street {}", pAgent->nextStreetId().value());
      auto const& nextStreet{
          this->graph().edge(pAgent->nextStreetId().value())};  // next street
      if (nextStreet->isFull()) {
        ++itAgent;
        spdlog::debug("Skipping {} due to full input {}", *pAgent, *nextStreet);
        continue;
      }
      // spdlog::debug("Adding agent on the source node");
      if (pSourceNode->isIntersection()) {
        auto& intersection = dynamic_cast<Intersection&>(*pSourceNode);
        intersection.addAgent(0., std::move(pAgent));
      } else if (pSourceNode->isRoundabout()) {
        auto& roundabout = dynamic_cast<Roundabout&>(*pSourceNode);
        roundabout.enqueue(std::move(pAgent));
      }
      itAgent = m_agents.erase(itAgent);
    }
    spdlog::debug("There are {} agents left in the list.", m_agents.size());
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::m_initStreetTable() const {
    if (!this->database()) {
      throw std::runtime_error(
          "No database connected. Call connectDataBase() before saving data.");
    }
    // Create table if it doesn't exist
    this->database()->exec(
        "CREATE TABLE IF NOT EXISTS road_data ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "simulation_id INTEGER NOT NULL, "
        "datetime TEXT NOT NULL, "
        "time_step INTEGER NOT NULL, "
        "street_id INTEGER NOT NULL, "
        "coil TEXT, "
        "density_vpk REAL, "
        "avg_speed_kph REAL, "
        "std_speed_kph REAL, "
        "counts INTEGER, "
        "queue_length INTEGER)");

    spdlog::info("Initialized road_data table in the database.");
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::m_initAvgStatsTable() const {
    if (!this->database()) {
      throw std::runtime_error(
          "No database connected. Call connectDataBase() before saving data.");
    }
    // Create table if it doesn't exist
    this->database()->exec(
        "CREATE TABLE IF NOT EXISTS avg_stats ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "simulation_id INTEGER NOT NULL, "
        "datetime TEXT NOT NULL, "
        "time_step INTEGER NOT NULL, "
        "n_ghost_agents INTEGER NOT NULL, "
        "n_agents INTEGER NOT NULL, "
        "mean_speed_kph REAL, "
        "std_speed_kph REAL, "
        "mean_density_vpk REAL NOT NULL, "
        "std_density_vpk REAL NOT NULL)");

    spdlog::info("Initialized avg_stats table in the database.");
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::m_initTravelDataTable() const {
    if (!this->database()) {
      throw std::runtime_error(
          "No database connected. Call connectDataBase() before saving data.");
    }
    // Create table if it doesn't exist
    this->database()->exec(
        "CREATE TABLE IF NOT EXISTS travel_data ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "simulation_id INTEGER NOT NULL, "
        "datetime TEXT NOT NULL, "
        "time_step INTEGER NOT NULL, "
        "distance_m REAL NOT NULL, "
        "travel_time_s REAL NOT NULL)");

    spdlog::info("Initialized travel_data table in the database.");
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::m_dumpNetwork() const {
    if (!this->database()) {
      throw std::runtime_error(
          "No database connected. Call connectDataBase() before saving data.");
    }
    // Check if edges and nodes tables already exists
    SQLite::Statement edgesQuery(
        *this->database(),
        "SELECT name FROM sqlite_master WHERE type='table' AND name='edges';");
    SQLite::Statement nodesQuery(
        *this->database(),
        "SELECT name FROM sqlite_master WHERE type='table' AND name='nodes';");
    bool edgesTableExists = edgesQuery.executeStep();
    bool nodesTableExists = nodesQuery.executeStep();
    if (edgesTableExists && nodesTableExists) {
      spdlog::info(
          "Edges and nodes tables already exist in the database. Skipping network dump.");
      return;
    }

    // Create edges table
    this->database()->exec(
        "CREATE TABLE IF NOT EXISTS edges ("
        "id INTEGER PRIMARY KEY, "
        "source INTEGER NOT NULL, "
        "target INTEGER NOT NULL, "
        "length REAL NOT NULL, "
        "maxspeed REAL NOT NULL, "
        "name TEXT, "
        "nlanes INTEGER NOT NULL, "
        "geometry TEXT NOT NULL)");
    // Create nodes table
    this->database()->exec(
        "CREATE TABLE IF NOT EXISTS nodes ("
        "id INTEGER PRIMARY KEY, "
        "type TEXT, "
        "geometry TEXT)");

    // Insert edges
    SQLite::Statement insertEdgeStmt(*this->database(),
                                     "INSERT INTO edges (id, source, target, length, "
                                     "maxspeed, name, nlanes, geometry) "
                                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?);");
    for (const auto& [edgeId, pEdge] : this->graph().edges()) {
      insertEdgeStmt.bind(1, static_cast<std::int64_t>(edgeId));
      insertEdgeStmt.bind(2, static_cast<std::int64_t>(pEdge->source()));
      insertEdgeStmt.bind(3, static_cast<std::int64_t>(pEdge->target()));
      insertEdgeStmt.bind(4, pEdge->length());
      insertEdgeStmt.bind(5, pEdge->maxSpeed());
      insertEdgeStmt.bind(6, pEdge->name());
      insertEdgeStmt.bind(7, pEdge->nLanes());
      insertEdgeStmt.bind(8, std::format("{}", pEdge->geometry()));
      insertEdgeStmt.exec();
      insertEdgeStmt.reset();
    }
    // Insert nodes
    SQLite::Statement insertNodeStmt(
        *this->database(), "INSERT INTO nodes (id, type, geometry) VALUES (?, ?, ?);");
    for (const auto& [nodeId, pNode] : this->graph().nodes()) {
      insertNodeStmt.bind(1, static_cast<std::int64_t>(nodeId));
      if (pNode->isTrafficLight()) {
        insertNodeStmt.bind(2, "traffic_light");
      } else if (pNode->isRoundabout()) {
        insertNodeStmt.bind(2, "roundabout");
      } else {
        insertNodeStmt.bind(2);
      }
      if (pNode->geometry().has_value()) {
        insertNodeStmt.bind(3, std::format("{}", *pNode->geometry()));
      } else {
        insertNodeStmt.bind(3);
      }
      insertNodeStmt.exec();
      insertNodeStmt.reset();
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::setErrorProbability(double errorProbability) {
    if (errorProbability < 0. || errorProbability > 1.) {
      throw std::invalid_argument(
          std::format("The error probability ({}) must be in [0, 1]", errorProbability));
    }
    m_errorProbability = errorProbability;
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::setPassageProbability(double passageProbability) {
    if (passageProbability < 0. || passageProbability > 1.) {
      throw std::invalid_argument(std::format(
          "The passage probability ({}) must be in [0, 1]", passageProbability));
    }
    m_passageProbability = passageProbability;
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::killStagnantAgents(double timeToleranceFactor) {
    if (timeToleranceFactor <= 0.) {
      throw std::invalid_argument(std::format(
          "The time tolerance factor ({}) must be positive", timeToleranceFactor));
    }
    m_timeToleranceFactor = timeToleranceFactor;
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::setWeightFunction(PathWeight const pathWeight,
                                                std::optional<double> weightTreshold) {
    m_pathWeight = pathWeight;
    switch (pathWeight) {
      case PathWeight::LENGTH:
        m_weightFunction = [](std::unique_ptr<Street> const& pStreet) {
          return pStreet->length();
        };
        m_weightTreshold = weightTreshold.value_or(1.);
        break;
      case PathWeight::TRAVELTIME:
        m_weightFunction = [this](std::unique_ptr<Street> const& pStreet) {
          return this->m_streetEstimatedTravelTime(pStreet);
        };
        m_weightTreshold = weightTreshold.value_or(0.0069);
        break;
      case PathWeight::WEIGHT:
        m_weightFunction = [](std::unique_ptr<Street> const& pStreet) {
          return pStreet->weight();
        };
        m_weightTreshold = weightTreshold.value_or(1.);
        break;
      default:
        spdlog::error("Invalid weight function. Defaulting to traveltime");
        m_weightFunction = [this](std::unique_ptr<Street> const& pStreet) {
          return this->m_streetEstimatedTravelTime(pStreet);
        };
        m_weightTreshold = weightTreshold.value_or(0.0069);
        break;
    }
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::setOriginNodes(
      std::unordered_map<Id, double> const& originNodes) {
    m_originNodes.clear();
    m_originNodes.reserve(originNodes.size());
    if (originNodes.empty()) {
      // If no origin nodes are provided, try to set origin nodes basing on streets' stationary weights
      double totalStationaryWeight = 0.0;
      for (auto const& [edgeId, pEdge] : this->graph().edges()) {
        auto const& weight = pEdge->stationaryWeight();
        m_originNodes[pEdge->source()] += weight;
        totalStationaryWeight += weight;
      }
      for (auto& [nodeId, weight] : m_originNodes) {
        weight /= totalStationaryWeight;
      }
      return;
    }
    auto const sumWeights = std::accumulate(
        originNodes.begin(), originNodes.end(), 0., [](double sum, auto const& pair) {
          return sum + pair.second;
        });
    if (sumWeights == 1.) {
      m_originNodes = originNodes;
      return;
    }
    for (auto const& [nodeId, weight] : originNodes) {
      m_originNodes[nodeId] = weight / sumWeights;
    }
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::setDestinationNodes(
      std::unordered_map<Id, double> const& destinationNodes) {
    m_itineraries.clear();
    m_destinationNodes.clear();
    m_destinationNodes.reserve(destinationNodes.size());
    auto sumWeights{0.};
    std::for_each(destinationNodes.begin(),
                  destinationNodes.end(),
                  [this, &sumWeights](auto const& pair) -> void {
                    sumWeights += pair.second;
                    this->addItinerary(pair.first, pair.first);
                  });
    if (sumWeights == 1.) {
      m_destinationNodes = destinationNodes;
      return;
    }
    for (auto const& [nodeId, weight] : destinationNodes) {
      m_destinationNodes[nodeId] = weight / sumWeights;
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::initTurnCounts() {
    if (!m_turnCounts.empty()) {
      throw std::runtime_error("Turn counts have already been initialized.");
    }
    for (auto const& [edgeId, pEdge] : this->graph().edges()) {
      auto const& pTargetNode{this->graph().node(pEdge->target())};
      for (auto const& nextEdgeId : pTargetNode->outgoingEdges()) {
        spdlog::debug("Initializing turn count for edge {} -> {}", edgeId, nextEdgeId);
        m_turnCounts[edgeId][nextEdgeId] = 0;
      }
    }
  }
  // You may wonder why not just use one function...
  // Never trust the user!
  // Jokes aside, the init is necessary because it allocates the memory for the first time and
  // turn counts are not incremented if the map is empty for performance reasons.
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::resetTurnCounts() {
    if (m_turnCounts.empty()) {
      throw std::runtime_error("Turn counts have not been initialized.");
    }
    for (auto const& [edgeId, pEdge] : this->graph().edges()) {
      auto const& pTargetNode{this->graph().node(pEdge->target())};
      for (auto const& nextEdgeId : pTargetNode->outgoingEdges()) {
        m_turnCounts[edgeId][nextEdgeId] = 0;
      }
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::saveData(std::time_t const savingInterval,
                                       bool const saveAverageStats,
                                       bool const saveStreetData,
                                       bool const saveTravelData) {
    m_savingInterval = savingInterval;
    m_bSaveAverageStats = saveAverageStats;
    m_bSaveStreetData = saveStreetData;
    m_bSaveTravelData = saveTravelData;

    // Initialize the required tables
    if (saveStreetData) {
      m_initStreetTable();
    }
    if (saveAverageStats) {
      m_initAvgStatsTable();
    }
    if (saveTravelData) {
      m_initTravelDataTable();
    }

    this->m_dumpSimInfo();
    this->m_dumpNetwork();

    spdlog::info(
        "Data saving configured: interval={}s, avg_stats={}, street_data={}, "
        "travel_data={}",
        savingInterval,
        saveAverageStats,
        saveStreetData,
        saveTravelData);
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::setDestinationNodes(
      std::initializer_list<Id> destinationNodes) {
    m_itineraries.clear();
    auto const numNodes{destinationNodes.size()};
    m_destinationNodes.clear();
    m_destinationNodes.reserve(numNodes);
    std::for_each(destinationNodes.begin(),
                  destinationNodes.end(),
                  [this, &numNodes](auto const& nodeId) -> void {
                    this->m_destinationNodes[nodeId] = 1. / numNodes;
                    this->addItinerary(nodeId, nodeId);
                  });
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  template <typename TContainer>
    requires(std::is_convertible_v<typename TContainer::value_type, Id>)
  void RoadDynamics<delay_t>::setDestinationNodes(TContainer const& destinationNodes) {
    m_itineraries.clear();
    auto const numNodes{destinationNodes.size()};
    m_destinationNodes.clear();
    m_destinationNodes.reserve(numNodes);
    std::for_each(destinationNodes.begin(),
                  destinationNodes.end(),
                  [this, &numNodes](auto const& nodeId) -> void {
                    this->m_destinationNodes[nodeId] = 1. / numNodes;
                    this->addItinerary(nodeId, nodeId);
                  });
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::updatePaths(bool const throw_on_empty) {
    spdlog::debug("Init updating paths...");
    tbb::concurrent_vector<Id> emptyItineraries;
    tbb::parallel_for_each(
        this->itineraries().cbegin(),
        this->itineraries().cend(),
        [this, throw_on_empty, &emptyItineraries](auto const& pair) -> void {
          auto const& pItinerary{pair.second};
          this->m_updatePath(pItinerary);
          if (pItinerary->empty()) {
            if (!throw_on_empty) {
              spdlog::warn("No path found for itinerary {} with destination node {}",
                           pItinerary->id(),
                           pItinerary->destination());
              emptyItineraries.push_back(pItinerary->id());
              return;
            }
            throw std::runtime_error(
                std::format("No path found for itinerary {} with destination node {}",
                            pItinerary->id(),
                            pItinerary->destination()));
          }
        });
    if (!emptyItineraries.empty()) {
      spdlog::warn("Removing {} itineraries with no valid path from the dynamics.",
                   emptyItineraries.size());
      for (auto const& id : emptyItineraries) {
        auto const destination = m_itineraries.at(id)->destination();
        m_destinationNodes.erase(destination);
        m_originNodes.erase(destination);
        m_itineraries.erase(id);
      }
    }
    spdlog::debug("End updating paths.");
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::addAgentsUniformly(Size nAgents,
                                                 std::optional<Id> optItineraryId) {
    m_nAddedAgents += nAgents;
    if (m_timeToleranceFactor.has_value() && !m_agents.empty()) {
      auto const nStagnantAgents{m_agents.size()};
      spdlog::debug(
          "Removing {} stagnant agents that were not inserted since the previous call to "
          "addAgentsUniformly().",
          nStagnantAgents);
      m_agents.clear();
      m_nAgents -= nStagnantAgents;
    }
    if (optItineraryId.has_value() && !this->itineraries().contains(*optItineraryId)) {
      throw std::invalid_argument(
          std::format("No itineraries available. Cannot add agents with itinerary id {}",
                      optItineraryId.value()));
    }
    bool const bRandomItinerary{!optItineraryId.has_value() &&
                                !this->itineraries().empty()};
    std::shared_ptr<Itinerary> pItinerary;
    std::uniform_int_distribution<Size> itineraryDist{
        0, static_cast<Size>(this->itineraries().size() - 1)};
    std::uniform_int_distribution<Size> streetDist{
        0, static_cast<Size>(this->graph().nEdges() - 1)};
    if (this->nAgents() + nAgents > this->graph().capacity()) {
      throw std::overflow_error(std::format(
          "Cannot add {} agents. The graph has currently {} with a maximum capacity of "
          "{}.",
          nAgents,
          this->nAgents(),
          this->graph().capacity()));
    }
    for (Size i{0}; i < nAgents; ++i) {
      if (bRandomItinerary) {
        auto itineraryIt{this->itineraries().cbegin()};
        std::advance(itineraryIt, itineraryDist(this->m_generator));
        pItinerary = itineraryIt->second;
      }
      auto streetIt = this->graph().edges().begin();
      while (true) {
        Size step = streetDist(this->m_generator);
        std::advance(streetIt, step);
        if (!(streetIt->second->isFull())) {
          break;
        }
        streetIt = this->graph().edges().begin();
      }
      auto const& street{streetIt->second};
      this->addAgent(pItinerary, street->source());
      auto& pAgent{this->m_agents.back()};
      pAgent->setStreetId(street->id());
      this->setAgentSpeed(pAgent);
      pAgent->setFreeTime(this->time_step() +
                          std::ceil(street->length() / pAgent->speed()));
      street->addAgent(std::move(pAgent), this->time_step());
      this->m_agents.pop_back();
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  template <typename TContainer>
    requires(std::is_same_v<TContainer, std::unordered_map<Id, double>> ||
             std::is_same_v<TContainer, std::map<Id, double>>)
  void RoadDynamics<delay_t>::addRandomAgents(std::size_t nAgents,
                                              TContainer const& spawnWeights) {
    m_nAddedAgents += nAgents;
    std::uniform_real_distribution<double> uniformDist{0., 1.};
    std::exponential_distribution<double> distDist{1. /
                                                   m_meanTravelDistance.value_or(1.)};
    std::exponential_distribution<double> timeDist{1. / m_meanTravelTime.value_or(1.)};
    auto const bUniformSpawn{spawnWeights.empty()};
    auto const bSingleSource{spawnWeights.size() == 1};
    while (nAgents--) {
      if (bUniformSpawn) {
        this->addAgent();
      } else if (bSingleSource) {
        this->addAgent(nullptr, spawnWeights.begin()->first);
      } else {
        auto const randValue{uniformDist(this->m_generator)};
        double cumulativeWeight{0.};
        for (auto const& [spawnNodeId, weight] : spawnWeights) {
          cumulativeWeight += weight;
          if (randValue <= cumulativeWeight) {
            this->addAgent(nullptr, spawnNodeId);
            break;
          }
        }
      }
      if (m_meanTravelDistance.has_value()) {
        auto const& pAgent{this->m_agents.back()};
        pAgent->setMaxDistance(distDist(this->m_generator));
      }
      if (m_meanTravelTime.has_value()) {
        auto const& pAgent{this->m_agents.back()};
        pAgent->setMaxTime(timeDist(this->m_generator));
      }
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::addRandomAgents(std::size_t nAgents) {
    addRandomAgents(nAgents, this->m_originNodes);
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  template <typename TContainer>
    requires(std::is_same_v<TContainer, std::unordered_map<Id, double>> ||
             std::is_same_v<TContainer, std::map<Id, double>>)
  void RoadDynamics<delay_t>::addAgentsRandomly(Size nAgents,
                                                const TContainer& src_weights,
                                                const TContainer& dst_weights) {
    m_nAddedAgents += nAgents;
    if (m_timeToleranceFactor.has_value() && !m_agents.empty()) {
      auto const nStagnantAgents{m_agents.size()};
      spdlog::debug(
          "Removing {} stagnant agents that were not inserted since the previous call to "
          "addAgentsRandomly().",
          nStagnantAgents);
      m_agents.clear();
      m_nAgents -= nStagnantAgents;
    }
    auto const& nSources{src_weights.size()};
    auto const& nDestinations{dst_weights.size()};
    spdlog::debug("Init addAgentsRandomly for {} agents from {} nodes to {} nodes.",
                  nAgents,
                  nSources,
                  nDestinations);
    if (nSources == 1 && nDestinations == 1 &&
        src_weights.begin()->first == dst_weights.begin()->first) {
      throw std::invalid_argument(
          std::format("The only source node {} is also the only destination node.",
                      src_weights.begin()->first));
    }
    auto const srcSum{std::accumulate(
        src_weights.begin(),
        src_weights.end(),
        0.,
        [](double sum, const std::pair<Id, double>& p) {
          if (p.second < 0.) {
            throw std::invalid_argument(std::format(
                "Negative weight ({}) for source node {}.", p.second, p.first));
          }
          return sum + p.second;
        })};
    auto const dstSum{std::accumulate(
        dst_weights.begin(),
        dst_weights.end(),
        0.,
        [](double sum, const std::pair<Id, double>& p) {
          if (p.second < 0.) {
            throw std::invalid_argument(std::format(
                "Negative weight ({}) for destination node {}.", p.second, p.first));
          }
          return sum + p.second;
        })};
    std::uniform_int_distribution<size_t> nodeDist{
        0, static_cast<size_t>(this->graph().nNodes() - 1)};
    std::uniform_real_distribution<double> srcUniformDist{0., srcSum};
    std::uniform_real_distribution<double> dstUniformDist{0., dstSum};
    spdlog::debug("Adding {} agents at time {}.", nAgents, this->time_step());
    while (nAgents > 0) {
      std::optional<Id> srcId{std::nullopt}, dstId{std::nullopt};

      // Select source using weighted random selection
      if (nSources == 1) {
        srcId = src_weights.begin()->first;
      } else {
        double dRand = srcUniformDist(this->m_generator);
        double sum = 0.;
        for (const auto& [id, weight] : src_weights) {
          sum += weight;
          if (dRand < sum) {
            srcId = id;
            break;
          }
        }
      }

      // Select destination using weighted random selection
      if (nDestinations == 1) {
        dstId = dst_weights.begin()->first;
      } else {
        double dRand = dstUniformDist(this->m_generator);
        double sum = 0.;
        for (const auto& [id, weight] : dst_weights) {
          sum += weight;
          if (dRand < sum) {
            dstId = id;
            break;
          }
        }
      }

      // Fallback to random nodes if selection failed
      if (!srcId.has_value()) {
        auto nodeIt{this->graph().nodes().begin()};
        std::advance(nodeIt, nodeDist(this->m_generator));
        srcId = nodeIt->first;
      }
      if (!dstId.has_value()) {
        auto nodeIt{this->graph().nodes().begin()};
        std::advance(nodeIt, nodeDist(this->m_generator));
        dstId = nodeIt->first;
      }

      // Find the itinerary with the given destination
      auto itineraryIt{std::find_if(this->itineraries().cbegin(),
                                    this->itineraries().cend(),
                                    [dstId](const auto& itinerary) {
                                      return itinerary.second->destination() == *dstId;
                                    })};
      if (itineraryIt == this->itineraries().cend()) {
        spdlog::error("Itinerary with destination {} not found. Skipping agent.", *dstId);
        --nAgents;
        continue;
      }

      // Check if destination is reachable from source
      auto const& itinerary = itineraryIt->second;
      if (!itinerary->path().contains(*srcId)) {
        spdlog::debug("Destination {} not reachable from source {}. Skipping agent.",
                      *dstId,
                      *srcId);
        --nAgents;
        continue;
      }

      this->addAgent(itineraryIt->second, *srcId);
      --nAgents;
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::addAgentsRandomly(Size nAgents) {
    addAgentsRandomly(nAgents, this->m_originNodes, this->m_destinationNodes);
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::addAgent(std::unique_ptr<Agent> pAgent) {
    m_agents.push_back(std::move(pAgent));
    ++m_nAgents;
    ++m_nInsertedAgents;
    spdlog::trace("Added {}", *m_agents.back());
    auto const& optNodeId{m_agents.back()->srcNodeId()};
    if (optNodeId.has_value()) {
      auto [it, bInserted] = m_originCounts.insert({*optNodeId, 1});
      if (!bInserted) {
        ++it->second;
      }
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  template <typename... TArgs>
    requires(std::is_constructible_v<Agent, Id, std::time_t, TArgs...>)
  void RoadDynamics<delay_t>::addAgent(TArgs&&... args) {
    addAgent(std::make_unique<Agent>(
        this->m_nInsertedAgents, this->time_step(), std::forward<TArgs>(args)...));
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  template <typename... TArgs>
    requires(std::is_constructible_v<Agent, Id, std::time_t, TArgs...>)
  void RoadDynamics<delay_t>::addAgents(std::size_t const nAgents, TArgs&&... args) {
    for (size_t i{0}; i < nAgents; ++i) {
      addAgent(std::make_unique<Agent>(
          this->m_nInsertedAgents, this->time_step(), std::forward<TArgs>(args)...));
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  template <typename... TArgs>
    requires(std::is_constructible_v<Itinerary, TArgs...>)
  void RoadDynamics<delay_t>::addItinerary(TArgs&&... args) {
    addItinerary(std::make_shared<Itinerary>(std::forward<TArgs>(args)...));
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::addItinerary(std::shared_ptr<Itinerary> itinerary) {
    if (m_itineraries.contains(itinerary->id())) {
      throw std::invalid_argument(
          std::format("Itinerary with id {} already exists.", itinerary->id()));
    }
    m_itineraries.emplace(itinerary->id(), std::move(itinerary));
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::evolve(bool reinsert_agents) {
    std::atomic<double> mean_speed{0.}, mean_density{0.};
    std::atomic<double> std_speed{0.}, std_density{0.};
    std::atomic<std::size_t> nValidEdges{0};
    bool const bComputeStats = this->database() != nullptr && m_savingInterval > 0 &&
                               this->time_step() % m_savingInterval == 0;

    // Struct to collect street data for batch insert after parallel section
    struct StreetDataRecord {
      Id streetId;
      std::optional<std::string> coilName;
      double density;
      std::optional<double> avgSpeed;
      std::optional<double> stdSpeed;
      std::optional<std::size_t> counts;
      std::size_t queueLength;
    };
    tbb::concurrent_vector<StreetDataRecord> streetDataRecords;

    spdlog::debug("Init evolve at time {}", this->time_step());
    // move the first agent of each street queue, if possible, putting it in the next node
    bool const bUpdateData = m_dataUpdatePeriod.has_value() &&
                             this->time_step() % m_dataUpdatePeriod.value() == 0;
    auto const numNodes{this->graph().nNodes()};
    auto const numEdges{this->graph().nEdges()};

    const unsigned int concurrency = std::thread::hardware_concurrency();
    // Calculate a grain size to partition the nodes into roughly "concurrency" blocks
    const size_t grainSize = std::max(size_t(1), numNodes / concurrency);
    this->m_taskArena.execute([&] {
      tbb::parallel_for(
          tbb::blocked_range<std::size_t>(0, numNodes, grainSize),
          [&](const tbb::blocked_range<std::size_t>& range) {
            for (std::size_t i = range.begin(); i != range.end(); ++i) {
              auto const& pNode = this->graph().node(m_nodeIndices[i]);
              for (auto const& inEdgeId : pNode->ingoingEdges()) {
                auto const& pStreet{this->graph().edge(inEdgeId)};
                if (bUpdateData && pNode->isTrafficLight()) {
                  if (!m_queuesAtTrafficLights.contains(inEdgeId)) {
                    auto& tl = dynamic_cast<TrafficLight&>(*pNode);
                    assert(!tl.cycles().empty());
                    for (auto const& [id, pair] : tl.cycles()) {
                      for (auto const& [direction, cycle] : pair) {
                        m_queuesAtTrafficLights[id].emplace(direction, 0.);
                      }
                    }
                  }
                  for (auto& [direction, value] : m_queuesAtTrafficLights.at(inEdgeId)) {
                    value += pStreet->nExitingAgents(direction, true);
                  }
                }
                m_evolveStreet(pStreet, reinsert_agents);
                if (bComputeStats) {
                  auto const& density{pStreet->density() * 1e3};

                  auto const speedMeasure = pStreet->meanSpeed(true);
                  if (speedMeasure.is_valid) {
                    auto const speed = speedMeasure.mean * 3.6;  // to kph
                    auto const speed_std = speedMeasure.std * 3.6;
                    if (m_bSaveAverageStats) {
                      mean_speed.fetch_add(speed, std::memory_order_relaxed);
                      std_speed.fetch_add(speed * speed + speed_std * speed_std,
                                          std::memory_order_relaxed);

                      ++nValidEdges;
                    }
                  }
                  if (m_bSaveAverageStats) {
                    mean_density.fetch_add(density, std::memory_order_relaxed);
                    std_density.fetch_add(density * density, std::memory_order_relaxed);
                  }

                  if (m_bSaveStreetData) {
                    // Collect data for batch insert after parallel section
                    StreetDataRecord record;
                    record.streetId = pStreet->id();
                    record.density = density;
                    if (pStreet->hasCoil()) {
                      record.coilName = pStreet->counterName();
                      record.counts = pStreet->counts();
                      pStreet->resetCounter();
                    }
                    if (speedMeasure.is_valid) {
                      record.avgSpeed = speedMeasure.mean * 3.6;  // to kph
                      record.stdSpeed = speedMeasure.std * 3.6;
                    }
                    record.queueLength = pStreet->nExitingAgents();
                    streetDataRecords.push_back(record);
                  }
                }
              }
            }
          });
    });
    spdlog::debug("Pre-nodes");
    // Move transport capacity agents from each node
    this->m_taskArena.execute([&] {
      tbb::parallel_for(tbb::blocked_range<size_t>(0, numNodes, grainSize),
                        [&](const tbb::blocked_range<size_t>& range) {
                          for (size_t i = range.begin(); i != range.end(); ++i) {
                            const auto& pNode = this->graph().node(m_nodeIndices[i]);
                            m_evolveNode(pNode);
                            if (pNode->isTrafficLight()) {
                              auto& tl = dynamic_cast<TrafficLight&>(*pNode);
                              ++tl;
                            }
                          }
                        });
    });
    this->m_evolveAgents();

    if (bComputeStats) {
      // Batch insert street data collected during parallel section
      if (m_bSaveStreetData) {
        SQLite::Transaction transaction(*this->database());
        SQLite::Statement insertStmt(
            *this->database(),
            "INSERT INTO road_data (datetime, time_step, simulation_id, street_id, "
            "coil, density_vpk, avg_speed_kph, std_speed_kph, counts, queue_length) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        for (auto const& record : streetDataRecords) {
          insertStmt.bind(1, this->strDateTime());
          insertStmt.bind(2, static_cast<std::int64_t>(this->time_step()));
          insertStmt.bind(3, static_cast<std::int64_t>(this->id()));
          insertStmt.bind(4, static_cast<std::int64_t>(record.streetId));
          if (record.coilName.has_value()) {
            insertStmt.bind(5, record.coilName.value());
          } else {
            insertStmt.bind(5);
          }
          insertStmt.bind(6, record.density);
          if (record.avgSpeed.has_value()) {
            insertStmt.bind(7, record.avgSpeed.value());
            insertStmt.bind(8, record.stdSpeed.value());
          } else {
            insertStmt.bind(7);
            insertStmt.bind(8);
          }
          if (record.counts.has_value()) {
            insertStmt.bind(9, static_cast<std::int64_t>(record.counts.value()));
          } else {
            insertStmt.bind(9);
          }
          insertStmt.bind(10, static_cast<std::int64_t>(record.queueLength));
          insertStmt.exec();
          insertStmt.reset();
        }
        transaction.commit();
      }

      if (m_bSaveTravelData) {  // Begin transaction for better performance
        SQLite::Transaction transaction(*this->database());
        SQLite::Statement insertStmt(*this->database(),
                                     "INSERT INTO travel_data (datetime, time_step, "
                                     "simulation_id, distance_m, travel_time_s) "
                                     "VALUES (?, ?, ?, ?, ?)");

        for (auto const& [distance, time] : m_travelDTs) {
          insertStmt.bind(1, this->strDateTime());
          insertStmt.bind(2, static_cast<int64_t>(this->time_step()));
          insertStmt.bind(3, static_cast<int64_t>(this->id()));
          insertStmt.bind(4, distance);
          insertStmt.bind(5, time);
          insertStmt.exec();
          insertStmt.reset();
        }
        transaction.commit();
        m_travelDTs.clear();
      }

      if (m_bSaveAverageStats) {  // Average Stats Table
        mean_speed.store(mean_speed.load() / nValidEdges.load());
        mean_density.store(mean_density.load() / numEdges);
        {
          double std_speed_val = std_speed.load();
          double mean_speed_val = mean_speed.load();
          std_speed.store(std::sqrt(std_speed_val / nValidEdges.load() -
                                    mean_speed_val * mean_speed_val));
        }
        {
          double std_density_val = std_density.load();
          double mean_density_val = mean_density.load();
          std_density.store(std::sqrt(std_density_val / numEdges -
                                      mean_density_val * mean_density_val));
        }
        SQLite::Statement insertStmt(
            *this->database(),
            "INSERT INTO avg_stats ("
            "simulation_id, datetime, time_step, n_ghost_agents, n_agents, "
            "mean_speed_kph, std_speed_kph, mean_density_vpk, std_density_vpk) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        insertStmt.bind(1, static_cast<std::int64_t>(this->id()));
        insertStmt.bind(2, this->strDateTime());
        insertStmt.bind(3, static_cast<std::int64_t>(this->time_step()));
        insertStmt.bind(4, static_cast<std::int64_t>(m_agents.size()));
        insertStmt.bind(5, static_cast<std::int64_t>(this->nAgents()));
        if (nValidEdges.load() > 0) {
          insertStmt.bind(6, mean_speed);
          insertStmt.bind(7, std_speed);
        } else {
          insertStmt.bind(6);
          insertStmt.bind(7);
        }
        insertStmt.bind(8, mean_density);
        insertStmt.bind(9, std_density);
        insertStmt.exec();
      }
    }

    Dynamics<RoadNetwork>::m_evolve();
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::m_trafficlightSingleTailOptimizer(
      double const& beta, std::optional<std::ofstream>& logStream) {
    assert(beta >= 0. && beta <= 1.);
    if (logStream.has_value()) {
      *logStream << std::format(
          "Init Traffic Lights optimization (SINGLE TAIL) - Time {} - Alpha {}\n",
          this->time_step(),
          beta);
    }
    for (auto const& [nodeId, pNode] : this->graph().nodes()) {
      if (!pNode->isTrafficLight()) {
        continue;
      }
      auto& tl = dynamic_cast<TrafficLight&>(*pNode);

      auto const& inNeighbours{pNode->ingoingEdges()};

      // Default is RIGHTANDSTRAIGHT - LEFT phases for both priority and non-priority
      std::array<double, 2> inputPrioritySum{0., 0.}, inputNonPrioritySum{0., 0.};
      bool isPrioritySinglePhase{false}, isNonPrioritySinglePhase{false};

      for (const auto& streetId : inNeighbours) {
        if (tl.cycles().at(streetId).contains(Direction::ANY)) {
          tl.streetPriorities().contains(streetId) ? isPrioritySinglePhase = true
                                                   : isNonPrioritySinglePhase = true;
        }
      }
      if (isPrioritySinglePhase && logStream.has_value()) {
        *logStream << "\tFound a single phase for priority streets.\n";
      }
      if (isNonPrioritySinglePhase && logStream.has_value()) {
        *logStream << "\tFound a single phase for non-priority streets.\n";
      }

      for (const auto& streetId : inNeighbours) {
        for (auto const& [direction, tail] : m_queuesAtTrafficLights.at(streetId)) {
          if (tl.streetPriorities().contains(streetId)) {
            if (isPrioritySinglePhase) {
              inputPrioritySum[0] += tail;
            } else {
              if (direction == Direction::LEFT ||
                  direction == Direction::LEFTANDSTRAIGHT) {
                inputPrioritySum[1] += tail;
              } else {
                inputPrioritySum[0] += tail;
              }
            }
          } else {
            if (isNonPrioritySinglePhase) {
              inputNonPrioritySum[0] += tail;
            } else {
              if (direction == Direction::LEFT ||
                  direction == Direction::LEFTANDSTRAIGHT) {
                inputNonPrioritySum[1] += tail;
              } else {
                inputNonPrioritySum[0] += tail;
              }
            }
          }
        }
      }
      {
        // Sum normalization
        auto const sum{inputPrioritySum[0] + inputPrioritySum[1] +
                       inputNonPrioritySum[0] + inputNonPrioritySum[1]};
        if (sum == 0.) {
          continue;
        }
        inputPrioritySum[0] /= sum;
        inputPrioritySum[1] /= sum;
        inputNonPrioritySum[0] /= sum;
        inputNonPrioritySum[1] /= sum;

        // int const cycleTime{(1. - alpha) * tl.cycleTime()};

        inputPrioritySum[0] *= beta;
        inputPrioritySum[1] *= beta;
        inputNonPrioritySum[0] *= beta;
        inputNonPrioritySum[1] *= beta;
      }

      if (logStream.has_value()) {
        *logStream << std::format(
            "\tInput cycle queue ratios are {:.2f} {:.2f} - {:.2f} {:.2f}\n",
            inputPrioritySum[0],
            inputPrioritySum[1],
            inputNonPrioritySum[0],
            inputNonPrioritySum[1]);
      }

      tl.resetCycles();
      auto cycles{tl.cycles()};
      std::array<int, 4> n{0, 0, 0, 0};
      std::array<double, 4> greenTimes{0., 0., 0., 0.};

      for (auto const& [streetId, pair] : cycles) {
        for (auto const& [direction, cycle] : pair) {
          if (tl.streetPriorities().contains(streetId)) {
            if (isPrioritySinglePhase) {
              greenTimes[0] += cycle.greenTime();
              ++n[0];
            } else {
              if (direction == Direction::LEFT ||
                  direction == Direction::LEFTANDSTRAIGHT) {
                greenTimes[1] += cycle.greenTime();
                ++n[1];
              } else {
                greenTimes[0] += cycle.greenTime();
                ++n[0];
              }
            }
          } else {
            if (isNonPrioritySinglePhase) {
              greenTimes[2] += cycle.greenTime();
              ++n[2];
            } else {
              if (direction == Direction::LEFT ||
                  direction == Direction::LEFTANDSTRAIGHT) {
                greenTimes[3] += cycle.greenTime();
                ++n[3];
              } else {
                greenTimes[2] += cycle.greenTime();
                ++n[2];
              }
            }
          }
        }
      }

      if (logStream.has_value()) {
        *logStream << std::format("\tGreen times are {} {} - {} {}\n",
                                  greenTimes[0],
                                  greenTimes[1],
                                  greenTimes[2],
                                  greenTimes[3]);
      }

      for (auto i{0}; i < 4; ++i) {
        if (n[i] > 1) {
          greenTimes[i] /= n[i];
        }
      }

      {
        auto sum{0.};
        for (auto const& greenTime : greenTimes) {
          sum += greenTime;
        }
        if (sum == 0.) {
          continue;
        }
        for (auto& greenTime : greenTimes) {
          greenTime /= sum;
        }
      }
      for (auto& el : greenTimes) {
        el *= (1. - beta);
      }

      int inputPriorityR{static_cast<int>(
          std::floor((inputPrioritySum[0] + greenTimes[0]) * tl.cycleTime()))};
      int inputPriorityS{inputPriorityR};
      int inputPriorityL{static_cast<int>(
          std::floor((inputPrioritySum[1] + greenTimes[1]) * tl.cycleTime()))};

      int inputNonPriorityR{static_cast<int>(
          std::floor((inputNonPrioritySum[0] + greenTimes[2]) * tl.cycleTime()))};
      int inputNonPriorityS{inputNonPriorityR};
      int inputNonPriorityL{static_cast<int>(
          std::floor((inputNonPrioritySum[1] + greenTimes[3]) * tl.cycleTime()))};

      {
        // Adjust phases to have the sum equal to the cycle time
        // To do this, first add seconds to the priority streets, then to the
        // non-priority streets
        auto total{static_cast<Delay>(inputPriorityR + inputPriorityL +
                                      inputNonPriorityR + inputNonPriorityL)};
        size_t idx{0};
        while (total < tl.cycleTime()) {
          switch (idx % 4) {
            case 0:
              ++inputPriorityR;
              ++inputPriorityS;
              break;
            case 1:
              ++inputPriorityL;
              break;
            case 2:
              ++inputNonPriorityR;
              ++inputNonPriorityS;
              break;
            case 3:
              ++inputNonPriorityL;
              break;
          }
          ++idx;
          ++total;
        }
      }

      if (isPrioritySinglePhase) {
        inputPriorityR = 0;
        inputPriorityL = 0;
      }
      if (isNonPrioritySinglePhase) {
        inputNonPriorityR = 0;
        inputNonPriorityL = 0;
      }

      // Logger::info(std::format(
      //     "Cycle time: {} - Current sum: {}",
      //     tl.cycleTime(),
      //     inputPriorityRS + inputPriorityL + inputNonPriorityRS + inputNonPriorityL));
      assert(inputPriorityS + inputPriorityL + inputNonPriorityS + inputNonPriorityL ==
             tl.cycleTime());

      std::unordered_map<Direction, TrafficLightCycle> priorityCycles;
      priorityCycles.emplace(Direction::RIGHT,
                             TrafficLightCycle{static_cast<Delay>(inputPriorityR), 0});
      priorityCycles.emplace(Direction::STRAIGHT,
                             TrafficLightCycle{static_cast<Delay>(inputPriorityS), 0});
      priorityCycles.emplace(Direction::RIGHTANDSTRAIGHT,
                             TrafficLightCycle{static_cast<Delay>(inputPriorityS), 0});
      priorityCycles.emplace(
          Direction::ANY,
          TrafficLightCycle{static_cast<Delay>(inputPriorityS + inputPriorityL), 0});
      priorityCycles.emplace(Direction::LEFT,
                             TrafficLightCycle{static_cast<Delay>(inputPriorityL),
                                               static_cast<Delay>(inputPriorityS)});

      std::unordered_map<Direction, TrafficLightCycle> nonPriorityCycles;
      nonPriorityCycles.emplace(
          Direction::RIGHT,
          TrafficLightCycle{static_cast<Delay>(inputNonPriorityR),
                            static_cast<Delay>(inputPriorityS + inputPriorityL)});
      nonPriorityCycles.emplace(
          Direction::STRAIGHT,
          TrafficLightCycle{static_cast<Delay>(inputNonPriorityS),
                            static_cast<Delay>(inputPriorityS + inputPriorityL)});
      nonPriorityCycles.emplace(
          Direction::RIGHTANDSTRAIGHT,
          TrafficLightCycle{static_cast<Delay>(inputNonPriorityS),
                            static_cast<Delay>(inputPriorityS + inputPriorityL)});
      nonPriorityCycles.emplace(
          Direction::ANY,
          TrafficLightCycle{static_cast<Delay>(inputNonPriorityS + inputNonPriorityL),
                            static_cast<Delay>(inputPriorityS + inputPriorityL)});
      nonPriorityCycles.emplace(
          Direction::LEFT,
          TrafficLightCycle{
              static_cast<Delay>(inputNonPriorityL),
              static_cast<Delay>(inputPriorityS + inputPriorityL + inputNonPriorityS)});
      nonPriorityCycles.emplace(
          Direction::LEFTANDSTRAIGHT,
          TrafficLightCycle{
              static_cast<Delay>(inputNonPriorityL + inputNonPriorityS),
              static_cast<Delay>(inputPriorityS + inputPriorityL + inputNonPriorityR)});

      std::vector<Id> streetIds;
      std::set<Id> forbiddenLeft;

      for (auto const& pair : cycles) {
        streetIds.push_back(pair.first);
      }
      for (auto const streetId : streetIds) {
        auto const& pStreet{this->graph().edge(streetId)};
        if (tl.streetPriorities().contains(streetId)) {
          for (auto& [dir, cycle] : cycles.at(streetId)) {
            if (isPrioritySinglePhase) {
              cycle = priorityCycles.at(Direction::STRAIGHT);
            } else {
              cycle = priorityCycles.at(dir);
            }
          }
          if (cycles.at(streetId).contains(Direction::RIGHT) &&
              cycles.at(streetId).contains(Direction::STRAIGHT)) {
            TrafficLightCycle freecycle{
                static_cast<Delay>(inputPriorityS + inputPriorityL), 0};
            // Logger::info(std::format("Free cycle (RIGHT) for {} -> {}: {} {}",
            //                          pStreet->source(),
            //                          pStreet->target(),
            //                          freecycle.greenTime(),
            //                          freecycle.phase()));
            cycles.at(streetId).at(Direction::RIGHT) = freecycle;
          }
        } else {
          for (auto& [dir, cycle] : cycles.at(streetId)) {
            if (isNonPrioritySinglePhase) {
              cycle = nonPriorityCycles.at(Direction::STRAIGHT);
            } else {
              cycle = nonPriorityCycles.at(dir);
            }
          }
          if (cycles.at(streetId).contains(Direction::RIGHT) &&
              cycles.at(streetId).contains(Direction::STRAIGHT)) {
            TrafficLightCycle freecycle{
                static_cast<Delay>(inputNonPriorityS + inputNonPriorityL),
                static_cast<Delay>(inputPriorityS + inputPriorityL)};
            // Logger::info(std::format("Free cycle (RIGHT) for {} -> {}: {} {}",
            //                          pStreet->source(),
            //                          pStreet->target(),
            //                          freecycle.greenTime(),
            //                          freecycle.phase()));
            cycles.at(streetId).at(Direction::RIGHT) = freecycle;
          }
        }
        bool found{false};
        for (auto const dir : pStreet->laneMapping()) {
          if (dir == Direction::LEFT || dir == Direction::LEFTANDSTRAIGHT ||
              dir == Direction::ANY) {
            found = true;
            break;
          }
        }
        if (!found) {
          forbiddenLeft.insert(streetId);
          // Logger::info(std::format("Street {} -> {} has forbidden left turn.",
          //                          pStreet->source(),
          //                          pStreet->target()));
        }
      }
      for (auto const forbiddenLeftStreetId : forbiddenLeft) {
        for (auto const streetId : streetIds) {
          if (streetId == forbiddenLeftStreetId) {
            continue;
          }
          if (tl.streetPriorities().contains(streetId) &&
              tl.streetPriorities().contains(forbiddenLeftStreetId)) {
            TrafficLightCycle freecycle{
                static_cast<Delay>(inputPriorityS + inputPriorityL), 0};
            for (auto& [direction, cycle] : cycles.at(streetId)) {
              if (direction == Direction::RIGHT || direction == Direction::STRAIGHT ||
                  direction == Direction::RIGHTANDSTRAIGHT) {
                auto const& pStreet{this->graph().edge(streetId)};
                if (logStream.has_value()) {
                  *logStream << std::format("\tFree cycle for {} -> {}: dir {} - {}\n",
                                            pStreet->source(),
                                            pStreet->target(),
                                            directionToString[direction],
                                            freecycle);
                }
                cycle = freecycle;
              }
            }
          } else if (!tl.streetPriorities().contains(streetId) &&
                     !tl.streetPriorities().contains(forbiddenLeftStreetId)) {
            TrafficLightCycle freecycle{
                static_cast<Delay>(inputNonPriorityS + inputNonPriorityL),
                static_cast<Delay>(inputPriorityS + inputPriorityL)};
            for (auto& [direction, cycle] : cycles.at(streetId)) {
              if (direction == Direction::RIGHT || direction == Direction::STRAIGHT ||
                  direction == Direction::RIGHTANDSTRAIGHT) {
                auto const& pStreet{this->graph().edge(streetId)};
                if (logStream.has_value()) {
                  *logStream << std::format("Free cycle ({}) for {} -> {}: {} {}\n",
                                            directionToString[direction],
                                            pStreet->source(),
                                            pStreet->target(),
                                            freecycle.greenTime(),
                                            freecycle.phase());
                }
                cycle = freecycle;
              }
            }
          }
        }
      }

      tl.setCycles(cycles);
      if (logStream.has_value()) {
        *logStream << std::format("\nNew cycles for {}", tl);
      }
    }
    if (logStream.has_value()) {
      *logStream << std::format("End Traffic Lights optimization - Time {}\n",
                                this->time_step());
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::optimizeTrafficLights(
      TrafficLightOptimization const optimizationType,
      const std::string& logFile,
      double const percentage,
      double const threshold) {
    std::optional<std::ofstream> logStream;
    if (!logFile.empty()) {
      logStream.emplace(logFile, std::ios::app);
      if (!logStream->is_open()) {
        spdlog::error("Could not open log file: {}", logFile);
      }
    }
    this->m_trafficlightSingleTailOptimizer(percentage, logStream);
    if (optimizationType == TrafficLightOptimization::DOUBLE_TAIL) {
      // Try to synchronize congested traffic lights
      std::unordered_map<Id, double> densities;
      for (auto const& [nodeId, pNode] : this->graph().nodes()) {
        if (!pNode->isTrafficLight()) {
          continue;
        }
        double density{0.}, n{0.};
        auto const& inNeighbours{pNode->ingoingEdges()};
        for (auto const& inEdgeId : inNeighbours) {
          auto const& pStreet{this->graph().edge(inEdgeId)};
          auto const& pSourceNode{this->graph().node(pStreet->source())};
          if (!pSourceNode->isTrafficLight()) {
            continue;
          }
          density += pStreet->density(true);
          ++n;
        }
        density /= n;
        densities[nodeId] = density;
      }
      // Sort densities map from big to small values
      std::vector<std::pair<Id, double>> sortedDensities(densities.begin(),
                                                         densities.end());

      // Sort by density descending
      std::sort(sortedDensities.begin(),
                sortedDensities.end(),
                [](auto const& a, auto const& b) { return a.second > b.second; });
      std::unordered_set<Id> optimizedNodes;

      for (auto const& [nodeId, density] : sortedDensities) {
        auto const& inNeighbours{this->graph().node(nodeId)->ingoingEdges()};
        for (auto const& inEdgeId : inNeighbours) {
          auto const& pStreet{this->graph().edge(inEdgeId)};
          auto const& sourceId{pStreet->source()};
          if (!densities.contains(sourceId) || optimizedNodes.contains(sourceId)) {
            continue;
          }
          auto const& neighbourDensity{densities.at(sourceId)};
          if (neighbourDensity < threshold * density) {
            continue;
          }
          // Try to green-wave the situation
          auto& tl{dynamic_cast<TrafficLight&>(*this->graph().node(sourceId))};
          tl.increasePhases(pStreet->length() /
                            (pStreet->maxSpeed() * (1. - 0.6 * pStreet->density(true))));
          optimizedNodes.insert(sourceId);
          if (logStream.has_value()) {
            *logStream << std::format("\nNew cycles for {}", tl);
          }
        }
      }
    }
    // Cleaning variables
    for (auto& [streetId, pair] : m_queuesAtTrafficLights) {
      for (auto& [direction, value] : pair) {
        value = 0.;
      }
    }
    m_previousOptimizationTime = this->time_step();
    if (logStream.has_value()) {
      logStream->close();
    }
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  Size RoadDynamics<delay_t>::nAgents() const {
    return m_nAgents;
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  Measurement<double> RoadDynamics<delay_t>::meanTravelTime(bool clearData) {
    std::vector<double> travelTimes;
    if (!m_travelDTs.empty()) {
      travelTimes.reserve(m_travelDTs.size());
      for (auto const& [distance, time] : m_travelDTs) {
        travelTimes.push_back(time);
      }
      if (clearData) {
        m_travelDTs.clear();
      }
    }
    return Measurement<double>(travelTimes);
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  Measurement<double> RoadDynamics<delay_t>::meanTravelDistance(bool clearData) {
    if (m_travelDTs.empty()) {
      return Measurement(0., 0.);
    }
    std::vector<double> travelDistances;
    travelDistances.reserve(m_travelDTs.size());
    for (auto const& [distance, time] : m_travelDTs) {
      travelDistances.push_back(distance);
    }
    if (clearData) {
      m_travelDTs.clear();
    }
    return Measurement<double>(travelDistances);
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  Measurement<double> RoadDynamics<delay_t>::meanTravelSpeed(bool clearData) {
    std::vector<double> travelSpeeds;
    travelSpeeds.reserve(m_travelDTs.size());
    for (auto const& [distance, time] : m_travelDTs) {
      travelSpeeds.push_back(distance / time);
    }
    if (clearData) {
      m_travelDTs.clear();
    }
    return Measurement<double>(travelSpeeds);
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  std::unordered_map<Id, std::unordered_map<Id, double>> const
  RoadDynamics<delay_t>::normalizedTurnCounts() const noexcept {
    std::unordered_map<Id, std::unordered_map<Id, double>> normalizedTurnCounts;
    for (auto const& [fromId, map] : m_turnCounts) {
      auto const sum{
          std::accumulate(map.begin(), map.end(), 0., [](auto const sum, auto const& p) {
            return sum + static_cast<double>(p.second);
          })};
      for (auto const& [toId, count] : map) {
        normalizedTurnCounts[fromId][toId] =
            sum == 0. ? 0. : static_cast<double>(count) / sum;
      }
    }
    return normalizedTurnCounts;
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  tbb::concurrent_unordered_map<Id, std::size_t> RoadDynamics<delay_t>::originCounts(
      bool const bReset) noexcept {
    if (!bReset) {
      return m_originCounts;
    }
    auto const tempCounts{std::move(m_originCounts)};
    m_originCounts.clear();
    return tempCounts;
  }
  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  tbb::concurrent_unordered_map<Id, std::size_t> RoadDynamics<delay_t>::destinationCounts(
      bool const bReset) noexcept {
    if (!bReset) {
      return m_destinationCounts;
    }
    auto const tempCounts{std::move(m_destinationCounts)};
    m_destinationCounts.clear();
    return tempCounts;
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  Measurement<double> RoadDynamics<delay_t>::streetMeanDensity(bool normalized) const {
    if (this->graph().edges().empty()) {
      return Measurement(0., 0.);
    }
    std::vector<double> densities;
    densities.reserve(this->graph().nEdges());
    if (normalized) {
      for (const auto& [streetId, pStreet] : this->graph().edges()) {
        densities.push_back(pStreet->density(true));
      }
    } else {
      double sum{0.};
      for (const auto& [streetId, pStreet] : this->graph().edges()) {
        densities.push_back(pStreet->density(false) * pStreet->length());
        sum += pStreet->length();
      }
      if (sum == 0) {
        return Measurement(0., 0.);
      }
      auto meanDensity{std::accumulate(densities.begin(), densities.end(), 0.) / sum};
      return Measurement(meanDensity, 0.);
    }
    return Measurement<double>(densities);
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  Measurement<double> RoadDynamics<delay_t>::streetMeanFlow() const {
    std::vector<double> flows;
    flows.reserve(this->graph().nEdges());
    for (const auto& [streetId, pStreet] : this->graph().edges()) {
      auto const speedMeasure = pStreet->meanSpeed();
      if (speedMeasure.is_valid) {
        flows.push_back(pStreet->density() * speedMeasure.mean);
      }
    }
    return Measurement<double>(flows);
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  Measurement<double> RoadDynamics<delay_t>::streetMeanFlow(double threshold,
                                                            bool above) const {
    std::vector<double> flows;
    flows.reserve(this->graph().nEdges());
    for (const auto& [streetId, pStreet] : this->graph().edges()) {
      auto const speedMeasure = pStreet->meanSpeed();
      if (!speedMeasure.is_valid) {
        continue;
      }
      if (above && (pStreet->density(true) > threshold)) {
        flows.push_back(pStreet->density() * speedMeasure.mean);
      } else if (!above && (pStreet->density(true) < threshold)) {
        flows.push_back(pStreet->density() * speedMeasure.mean);
      }
    }
    return Measurement<double>(flows);
  }

  template <typename delay_t>
    requires(is_numeric_v<delay_t>)
  void RoadDynamics<delay_t>::summary(std::ostream& os) const {
    os << "RoadDynamics Summary:\n";
    this->graph().describe(os);
    os << "\nNumber of added agents: " << m_nAddedAgents << '\n'
       << "Number of inserted agents: " << m_nInsertedAgents << '\n'
       << "Number of arrived agents: " << m_nArrivedAgents << '\n'
       << "Number of killed agents: " << m_nKilledAgents << '\n'
       << "Current number of agents: " << this->nAgents() << '\n';
  }
}  // namespace dsf::mobility
