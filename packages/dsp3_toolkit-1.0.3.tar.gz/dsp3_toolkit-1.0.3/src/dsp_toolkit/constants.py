# List of characters that are reserved for special use in a URI, as per RFC 3986
# see: https://datatracker.ietf.org/doc/html/rfc3986.html#section-2.2
URI_RESERVED_CHARACTERS = " :/?#[]@!$&'()*+,;+"
