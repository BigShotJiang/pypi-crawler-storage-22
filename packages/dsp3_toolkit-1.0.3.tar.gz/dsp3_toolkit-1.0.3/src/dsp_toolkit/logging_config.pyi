# Stub file for dsp_toolkit.logging_config
from typing import Any

class Logger:
    def error(self, msg: str, *args: Any, **kwargs: Any) -> None: ...
    def info(self, msg: str, *args: Any, **kwargs: Any) -> None: ...

logger: Logger
