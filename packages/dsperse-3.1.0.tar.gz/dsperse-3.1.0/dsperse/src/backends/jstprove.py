"""
JSTprove backend for zero-knowledge proof generation.
"""
import importlib.metadata
import json
import os
import tempfile
import torch
import logging
import onnx
from pathlib import Path
from typing import Optional, Tuple, Dict, Any, Union, List

from python.core.circuit_models.generic_onnx import GenericModelONNX
from python.core.utils.helper_functions import CircuitExecutionConfig, RunType, read_from_json
from python.frontend.commands.base import BaseCommand
from python.frontend.commands.batch import _run_witness_chunk_piped

from dsperse.src.backends.utils.jstprove_utils import JSTproveUtils, JSTPROVE_SUPPORTED_OPS

logger = logging.getLogger(__name__)


class JSTprove:
    """JSTprove backend for zero-knowledge proof generation."""

    SUPPORTED_OPS = JSTPROVE_SUPPORTED_OPS

    @staticmethod
    def is_compatible(model_path: Union[str, Path]) -> Tuple[bool, set]:
        """Check if an ONNX model contains only JSTprove-supported operations."""
        return JSTproveUtils.is_compatible(model_path)

    def __init__(self, model_directory: Optional[str] = None) -> None:
        self.env = os.environ.copy()
        self.model_directory = Path(model_directory) if model_directory else None
        self._witness_format = "jstprove"
        self._circuit_cache: Dict[str, GenericModelONNX] = {}

    def _build_circuit(self, model_path):
        circuit = BaseCommand._build_circuit(Path(model_path).stem)
        circuit.model_file_name = str(model_path)
        circuit.onnx_path = str(model_path)
        circuit.model_path = str(model_path)
        return circuit

    def _get_circuit(self, circuit_path: Path) -> GenericModelONNX:
        key = str(circuit_path)
        if key in self._circuit_cache:
            return self._circuit_cache[key]
        circuit = GenericModelONNX("_")
        quantized_path = circuit_path.parent / f"{circuit_path.stem}_quantized_model.onnx"
        if not quantized_path.exists():
            raise FileNotFoundError(f"Quantized model not found: {quantized_path}")
        circuit.load_quantized_model(str(quantized_path))
        self._circuit_cache[key] = circuit
        return circuit

    def _resolve_circuit_path(self, model_path: Path) -> Path:
        circuit_path = model_path
        onnx_model_path = None
        if circuit_path.exists() and circuit_path.suffix == '.onnx':
            onnx_model_path = circuit_path
            circuit_path = circuit_path.parent / f"{circuit_path.stem}_jstprove_circuit.txt"
        if onnx_model_path and not circuit_path.exists():
            ok, err = self.compile_circuit(onnx_model_path, circuit_path)
            if not ok:
                raise RuntimeError(f"Circuit compilation failed: {err}")
        elif not circuit_path.exists():
            raise FileNotFoundError(f"Circuit file not found: {circuit_path}")
        return circuit_path

    def _process_inputs(self, circuit: GenericModelONNX, inputs: dict) -> Tuple[dict, dict]:
        scaled = circuit.scale_inputs_only(inputs)
        inference_inputs = circuit.reshape_inputs_for_inference(scaled)
        circuit_inputs = circuit.reshape_inputs_for_circuit(scaled)
        outputs = circuit.get_outputs(inference_inputs)
        formatted = circuit.format_outputs(outputs)
        return circuit_inputs, formatted

    def generate_witness(
        self,
        input_file: Union[str, Path],
        model_path: Union[str, Path],
        output_file: Union[str, Path],
        vk_path: Optional[Union[str, Path]] = None,
        settings_path: Optional[Union[str, Path]] = None
    ) -> Tuple[bool, Any]:
        input_file, output_file = Path(input_file), Path(output_file)
        circuit_path = self._resolve_circuit_path(Path(model_path))
        witness_path = output_file.parent / f"{output_file.stem}_witness.bin"

        if not input_file.exists():
            raise FileNotFoundError(f"Input file not found: {input_file}")

        output_file.parent.mkdir(parents=True, exist_ok=True)
        witness_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            circuit = self._get_circuit(circuit_path)
            inputs = read_from_json(str(input_file))
            circuit_inputs, formatted = self._process_inputs(circuit, inputs)

            metadata_path = str(circuit_path.parent / f"{circuit_path.stem}_metadata.json")
            _run_witness_chunk_piped(
                binary_name=circuit.name,
                circuit_path=str(circuit_path),
                metadata_path=metadata_path,
                chunk_jobs=[{
                    "_circuit_inputs": circuit_inputs,
                    "_circuit_outputs": formatted,
                    "witness": str(witness_path),
                }],
            )

            with open(output_file, "w") as f:
                json.dump(formatted, f)

            return True, self.process_witness_output(formatted)
        except Exception as e:
            logger.error(f"Witness generation failed: {e}")
            return False, str(e)

    def generate_witness_batch(
        self,
        circuit_path: Union[str, Path],
        jobs: List[Dict[str, str]],
        manifest_dir: Optional[Union[str, Path]] = None,
    ) -> List[Tuple[bool, Any]]:
        circuit_path = self._resolve_circuit_path(Path(circuit_path))

        for job in jobs:
            Path(job["output"]).parent.mkdir(parents=True, exist_ok=True)
            Path(job["witness"]).parent.mkdir(parents=True, exist_ok=True)

        try:
            circuit = self._get_circuit(circuit_path)
            metadata_path = str(circuit_path.parent / f"{circuit_path.stem}_metadata.json")

            piped_jobs = []
            per_job_formatted = []
            for job in jobs:
                inputs = read_from_json(job["input"])
                circuit_inputs, formatted = self._process_inputs(circuit, inputs)
                piped_jobs.append({
                    "_circuit_inputs": circuit_inputs,
                    "_circuit_outputs": formatted,
                    "witness": job["witness"],
                })
                per_job_formatted.append(formatted)

            _run_witness_chunk_piped(
                binary_name=circuit.name,
                circuit_path=str(circuit_path),
                metadata_path=metadata_path,
                chunk_jobs=piped_jobs,
            )

            results = []
            for job, formatted in zip(jobs, per_job_formatted):
                with open(job["output"], "w") as f:
                    json.dump(formatted, f)
                results.append((True, self.process_witness_output(formatted)))

            return results
        except Exception as e:
            logger.error(f"Batch witness generation failed: {e}")
            return [(False, str(e)) for _ in jobs]

    def generate_witness_batch_from_tensors(
        self,
        circuit_path: Union[str, Path],
        jobs: List[Dict[str, Any]],
        manifest_dir: Optional[Union[str, Path]] = None,
        workers: int = 1,
    ) -> List[Tuple[bool, Any]]:
        circuit_path = self._resolve_circuit_path(Path(circuit_path))

        for job in jobs:
            Path(job["output"]).parent.mkdir(parents=True, exist_ok=True)
            Path(job["witness"]).parent.mkdir(parents=True, exist_ok=True)

        try:
            circuit = self._get_circuit(circuit_path)
            metadata_path = str(circuit_path.parent / f"{circuit_path.stem}_metadata.json")

            piped_jobs = []
            per_job_formatted = []
            for job in jobs:
                inputs = job.get("_tensor_inputs") or job.get("input")
                if isinstance(inputs, str):
                    inputs = read_from_json(inputs)
                circuit_inputs, formatted = self._process_inputs(circuit, inputs)
                piped_jobs.append({
                    "_circuit_inputs": circuit_inputs,
                    "_circuit_outputs": formatted,
                    "witness": job["witness"],
                })
                per_job_formatted.append(formatted)

            chunk_size = max(1, len(piped_jobs) // max(1, workers)) if workers > 1 else 0
            if chunk_size <= 0:
                chunks = [piped_jobs]
            else:
                chunks = [piped_jobs[i:i + chunk_size] for i in range(0, len(piped_jobs), chunk_size)]

            for chunk in chunks:
                _run_witness_chunk_piped(
                    binary_name=circuit.name,
                    circuit_path=str(circuit_path),
                    metadata_path=metadata_path,
                    chunk_jobs=chunk,
                )

            results = []
            for job, formatted in zip(jobs, per_job_formatted):
                with open(job["output"], "w") as f:
                    json.dump(formatted, f)
                results.append((True, self.process_witness_output(formatted)))

            return results
        except Exception as e:
            logger.error(f"Batch witness generation failed: {e}")
            return [(False, str(e)) for _ in jobs]

    def prove(
        self,
        witness_path: Union[str, Path],
        circuit_path: Union[str, Path],
        proof_path: Union[str, Path],
        pk_path: Optional[Union[str, Path]] = None,
        check_mode: str = "unsafe",
        settings_path: Optional[Union[str, Path]] = None
    ) -> Tuple[bool, Union[str, Path]]:
        witness_path = Path(witness_path)
        circuit_path = Path(circuit_path)
        proof_path = Path(proof_path)

        if not witness_path.exists():
            raise FileNotFoundError(f"Witness file not found: {witness_path}")
        if not circuit_path.exists():
            raise FileNotFoundError(f"Circuit file not found: {circuit_path}")

        proof_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            circuit = self._build_circuit("cli")
            circuit.base_testing(CircuitExecutionConfig(
                run_type=RunType.PROVE_WITNESS,
                circuit_path=str(circuit_path),
                witness_file=str(witness_path),
                proof_file=str(proof_path),
                ecc=False,
            ))
        except Exception as e:
            error_msg = f"Proof generation failed: {e}"
            logger.error(error_msg)
            return False, error_msg

        return True, proof_path

    def verify(
        self,
        proof_path: Union[str, Path],
        circuit_path: Union[str, Path],
        input_path: Union[str, Path],
        output_path: Union[str, Path],
        witness_path: Union[str, Path],
        settings_path: Optional[Union[str, Path]] = None,
        vk_path: Optional[Union[str, Path]] = None
    ) -> bool:
        proof_path = Path(proof_path)
        circuit_path = Path(circuit_path)
        input_path = Path(input_path)
        output_path = Path(output_path)
        witness_path = Path(witness_path)

        required_files = [proof_path, circuit_path, input_path, output_path, witness_path]
        for file_path in required_files:
            if not file_path.exists():
                raise FileNotFoundError(f"Required file not found: {file_path}")

        veri_output_path = self._prepare_verification_output(circuit_path, output_path)

        try:
            circuit = self._build_circuit("cli")
            circuit.base_testing(CircuitExecutionConfig(
                run_type=RunType.GEN_VERIFY,
                circuit_path=str(circuit_path),
                input_file=str(input_path),
                output_file=str(veri_output_path),
                witness_file=str(witness_path),
                proof_file=str(proof_path),
                ecc=False,
            ))
            return True
        except Exception as e:
            logger.error(f"Proof verification failed: {e}")
            return False

    @staticmethod
    def _prepare_verification_output(circuit_path: Path, output_path: Path) -> Path:
        with open(output_path, "r") as f:
            output_data = json.load(f)

        raw_output = output_data.get("raw_output")
        if raw_output is not None:
            veri_path = output_path.parent / "output_veri.json"
            with open(veri_path, "w") as f:
                json.dump({"output": raw_output}, f)
            return veri_path

        metadata_path = circuit_path.with_name(circuit_path.stem + "_metadata.json")
        if not metadata_path.exists():
            return output_path

        with open(metadata_path, "r") as f:
            metadata = json.load(f)

        scale_base = metadata.get("scale_base")
        scale_exponent = metadata.get("scale_exponent")
        if scale_base is None or scale_exponent is None:
            return output_path

        output_values = output_data.get("output")
        if output_values is None:
            return output_path

        flat = torch.tensor(output_values).flatten()

        if flat.is_floating_point():
            scale = scale_base ** scale_exponent
            flat = torch.round(flat * scale).long()

        scaled = flat.long().tolist()

        veri_path = output_path.parent / "output_veri.json"
        with open(veri_path, "w") as f:
            json.dump({"output": scaled}, f)

        return veri_path

    def compile_circuit(
        self,
        model_path: Union[str, Path],
        circuit_path: Union[str, Path],
        settings_path: Optional[Union[str, Path]] = None
    ) -> Tuple[bool, Optional[str]]:
        model_path = Path(model_path)
        circuit_path = Path(circuit_path)

        if not model_path.exists():
            raise FileNotFoundError(f"Model file not found: {model_path}")

        circuit_path.parent.mkdir(parents=True, exist_ok=True)

        model = onnx.load(str(model_path))
        model = JSTproveUtils.add_zero_bias_to_conv(model)

        fd, preprocessed_path = tempfile.mkstemp(suffix=".onnx")
        os.close(fd)
        try:
            onnx.save(model, preprocessed_path)
            circuit = self._build_circuit(preprocessed_path)
            circuit.base_testing(CircuitExecutionConfig(
                run_type=RunType.COMPILE_CIRCUIT,
                circuit_path=str(circuit_path),
            ))
            if not circuit_path.exists():
                return False, f"Rust binary exited successfully but did not produce circuit file at {circuit_path}"
            return True, None
        except Exception as e:
            error_msg = f"Circuit compilation failed: {e}"
            logger.error(error_msg)
            return False, error_msg
        finally:
            if os.path.exists(preprocessed_path):
                os.remove(preprocessed_path)

    def circuitization_pipeline(
        self,
        model_path: Union[str, Path],
        output_path: Union[str, Path],
        input_file_path: Optional[Union[str, Path]] = None,
        segment_details: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Run the JSTprove circuitization pipeline."""
        # --- Validation & Normalization ---
        model_path, output_path = Path(model_path), Path(output_path)
        if not model_path.exists():
            raise FileNotFoundError(f"Model file not found: {model_path}")
        output_path.mkdir(parents=True, exist_ok=True)

        # --- Artifact Preparation ---
        artifacts = JSTproveUtils.initialize_circuitization_artifacts(model_path, output_path, str(input_file_path) if input_file_path else None)
        circuit_path = artifacts["paths"]["circuit"]
        settings_path = artifacts["paths"]["settings"]
        circuitization_data = artifacts["data"]

        # --- Circuit Compilation ---
        try:
            logger.info(f"Compiling circuit for {model_path.stem}")
            ok, err = self.compile_circuit(model_path=model_path, circuit_path=circuit_path)
            
            if not ok:
                logger.warning(f"Failed to compile circuit: {err}")
                circuitization_data["compile_error"] = err
                return circuitization_data

            quantized_model_path = artifacts["paths"]["quantized_model"]
            if not Path(quantized_model_path).exists():
                alt_path = circuit_path.parent / f"{circuit_path.stem}_quantized_model.onnx"
                if alt_path.exists():
                    circuitization_data["quantized_model"] = str(alt_path)
                else:
                    logger.warning(f"Quantized model not found after compilation: {quantized_model_path}")
                    circuitization_data["compile_error"] = f"Missing quantized model at {quantized_model_path}"
                    return circuitization_data
            dummy_settings = JSTproveUtils.create_dummy_settings(model_path, circuit_path, output_path)
            with open(settings_path, 'w') as f:
                json.dump(dummy_settings, f, indent=2)
            
            logger.info(f"Circuitization pipeline completed for {model_path}")
        except Exception as e:
            error_msg = f"Error during circuitization: {str(e)}"
            logger.exception(error_msg)
            circuitization_data["error"] = error_msg

        return circuitization_data

    # Alias for backward compatibility with EZKL interface
    compilation_pipeline = circuitization_pipeline

    def process_witness_output(self, witness_data: Any) -> Optional[Dict[str, Any]]:
        """Process the witness output data to get prediction results."""
        try:
            # --- JSTprove Dict Format ---
            if isinstance(witness_data, dict) and "rescaled_output" in witness_data:
                self._witness_format = "jstprove_dict"
                logger.debug("Using rescaled outputs from output.json (not witness binary).")
                return {"logits": JSTproveUtils.convert_to_logits(witness_data["rescaled_output"])}
            
            # --- Raw Array Format ---
            elif isinstance(witness_data, list):
                self._witness_format = "jstprove_list"
                return {"logits": JSTproveUtils.convert_to_logits(witness_data)}
            
            # --- EZKL Fallback Format ---
            else:
                self._witness_format = "ezkl_compat"
                rescaled = witness_data["pretty_elements"]["rescaled_outputs"][0]
                return {"logits": JSTproveUtils.convert_to_logits(rescaled)}
        except (KeyError, TypeError) as e:
            logger.error(f"Could not process witness data: {e}")
            return None

    @classmethod
    def get_version(cls) -> Optional[str]:
        try:
            return importlib.metadata.version("jstprove")
        except Exception as e:
            logger.debug(f"Could not get JSTprove version: {e}")
        return None

    def __repr__(self) -> str:
        return f"JSTprove(version={self.get_version()})"
