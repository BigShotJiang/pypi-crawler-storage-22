"""Streamlit UI for STCC Triage Agent."""

__all__ = []
