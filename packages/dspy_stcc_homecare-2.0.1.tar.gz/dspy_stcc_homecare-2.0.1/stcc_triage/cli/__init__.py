"""CLI commands for STCC Triage."""

__all__ = []
