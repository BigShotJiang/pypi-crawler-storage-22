"""
UI Components for Streamlit application.
"""
