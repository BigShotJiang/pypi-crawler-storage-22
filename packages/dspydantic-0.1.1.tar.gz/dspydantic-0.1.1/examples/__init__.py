"""Example scripts for dspydantic."""

