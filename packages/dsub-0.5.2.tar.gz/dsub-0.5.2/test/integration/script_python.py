#!/usr/bin/python
"""Minimal Python script."""

from __future__ import print_function


def run():
  print("Hello world!")


if __name__ == "__main__":
  run()
