# Generated file
# - do not overwrite
# - do not include in git
from collections import namedtuple

BuildInfo = namedtuple(
    'BuildInfo',
    ['version', 'built_at', 'sha', 'branch', 'tag'],
)

BUILD_INFO = BuildInfo(
    version='v4.27.0~8ec71bd',
    built_at='2026-02-03 08:44:06Z',
    sha='8ec71bd85dfbea66adedb6590f7d76ae5143bbaa',
    branch='HEAD',
    tag='v4.27.0',
)
