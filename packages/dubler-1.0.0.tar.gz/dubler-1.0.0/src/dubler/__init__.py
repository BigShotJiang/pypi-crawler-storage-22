"""Dubler - Directory synchronization tool."""

from dubler._version import __version__

__all__ = ["__version__"]
