from duck_domain.core.crud.dtos.update_dto import UpdateDto
from duck_domain.core.crud.dtos.where_dto import WhereDto

__all__ = ['UpdateDto', 'WhereDto']
