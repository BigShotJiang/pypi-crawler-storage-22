# Ducky-Python-Module
A collection of tools for python  
Still in progress but it will be releasing fully soon  
Credit:  
Turtle library has been used and modified. I did not make it and I did include the text from the original library explaining rights to the Turtle program which I am not allowed to remove.
Nltk has been imported but not modified.
And a few other libraries which I'll mention when this is complete
