from .main import *
try:
    nltk.download('punkt', quiet=True)
except Exception:
    pass
