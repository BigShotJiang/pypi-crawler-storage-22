"""Subcommands for dtc

Each module implements a subcommand. To add a new subcommand, add a
module with the following attributes:

- `cli`: a `click.command`
- `subcommand_name`: the name of the subcommand

The following example shows the implementation of the subcommand `demo`


```python
import click

@click.command()
@click.pass_obj
def cli(obj):
    click.echo(f'demo with custom object: {obj}')

subcommand_name = 'demo'
```

The parameter `obj` will contain a token --if given by the user-- or `None`.
"""
