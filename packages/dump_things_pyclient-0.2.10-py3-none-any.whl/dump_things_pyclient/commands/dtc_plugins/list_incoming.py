import json

import rich_click as click

from ...communicate import (
    HTTPError,
    incoming_read_labels,
    incoming_read_records,
)


subcommand_name = 'list-incoming'


@click.command(short_help='List inboxes of a dump-things collection')
@click.pass_obj
@click.argument(
    'service_url',
    metavar='SERVICE_URL',
)
@click.argument(
    'collection',
    metavar='COLLECTION',
)
@click.option(
    '--show-records', '-s',
    default=False,
    is_flag=True,
    help='list records in inboxes',
)
def cli(
        obj,
        service_url,
        collection,
        show_records,
):
    """List labels of incoming areas of a collection on a dump-things-service

    This command lists the labels of the incoming areas of the collection
    COLLECTION on the dump-things service given by SERVICE_URL.

    A token with curator rights has to be provided.
    """
    try:
        return list_incoming(
            obj,
            service_url,
            collection,
            show_records,
        )
    except HTTPError as e:
        click.echo(f'ERROR: {e}: {e.response.text}', err=True)
    return 1


def list_incoming(
        obj,
        service_url,
        collection,
        show_records,
):
    token = obj
    if token is None:
        click.echo('ERROR: token not provided', err=True)
        return 1

    result = {}
    for label in incoming_read_labels(
            service_url=service_url,
            collection=collection,
            token=token,
    ):
        result[label] = []
        if show_records:
            for record, _, _, _, _ in incoming_read_records(
                    service_url=service_url,
                    collection=collection,
                    label=label,
                    token=token,
            ):
                result[label].append(record)

    if show_records is False:
        result = list(result)
    click.echo(json.dumps(result, indent=2, ensure_ascii=False))
    return 0
