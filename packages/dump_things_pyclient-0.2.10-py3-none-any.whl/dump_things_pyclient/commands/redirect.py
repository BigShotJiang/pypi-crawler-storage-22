import sys
from pathlib import Path

import rich_click as click


def main():
    command_name = Path(sys.argv[0]).name
    click.echo(f'Note: `{command_name}` is now a subcommand of `dtc`, please use the command `dtc {command_name} ...`.', err=True)
    return 1
