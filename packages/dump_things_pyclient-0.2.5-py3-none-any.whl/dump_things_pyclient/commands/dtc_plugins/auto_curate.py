import json
import logging
import re
import sys
from itertools import (
    count,
    chain,
)
from typing import (
    cast,
    Iterable,
)

import rich_click as click
from rich import print as rprint
from rich.console import Console
from rich.progress import track

from ...communicate import (
    HTTPError,
    curated_write_record,
    incoming_delete_record,
    incoming_read_labels,
    incoming_read_records,
)


logger = logging.getLogger('auto-curate')

console = Console(file=sys.stderr)
stl_info = False


@click.command(short_help='Move records from inbox to curate area of a collection')
@click.pass_obj
@click.argument(
    'service_url',
    metavar='SERVICE_URL',
)
@click.argument(
    'collection',
    metavar='COLLECTION',
)
@click.option(
    '--destination-service-url',
    metavar='DEST_SERVICE_URL',
    help='select a different dump-thing-service, i.e. not SERVICE_URL, as destination for auto-curated records (the default is SERVICE_URL)',
)
@click.option(
    '--destination-collection',
    metavar='DEST_COLLECTION',
    help='select a different collection, i.e. not COLLECTION, as destination for auto-curated records',
)
@click.option(
    '--destination-token',
    metavar='DEST_TOKEN',
    help='if provided, this token will be used the authenticate against DEST_SERVICE_URL, which defaults to SERVICE_URL (the default is the token provided via --token)',
)
@click.option(
    '--pid', '-p',
    metavar='PID',
    help='if provided, process only records that match the given PIDs. NOTE: matching does not involve CURIE-resolution',
)
@click.option(
    '--exclude', '-e',
    help='exclude an inbox on the source collection (repeatable)',
    multiple=True,
)
@click.option(
    '--include', '-i',
    help='process only the given inbox, all other inboxes are ignored (repeatable, -e/--exclude is applied after inclusion)',
    multiple=True,
)
@click.option(
    '--list-labels', '-l',
    help='list the inbox labels of the given source collection, do not perform any curation',
    default=False,
    is_flag=True,
)
@click.option(
    '--list-records', '-r',
    help='list records in the inboxes of the given source collection, do not perform any curation',
    default=False,
    is_flag=True,
)
@click.option(
    '--dry-run', '-d',
    help='if provided, do not alter any data, instead print what would be done',
    default=False,
    is_flag=True,
)
def cli(
        obj,
        service_url,
        collection,
        destination_service_url,
        destination_collection,
        destination_token,
        pid,
        exclude,
        include,
        list_labels,
        list_records,
        dry_run,
):
    """Automatically move records from the incoming areas of the collection
    COLLECTION in the service SERVICE_URL to the curated area of the same
    collection, or to the curated area of another collection, possibly on
    another service.

    A token is required and will be used to authenticate the requests.
    The token must have curator-rights."""
    try:
        return auto_curate(
            obj,
            service_url,
            collection,
            destination_service_url,
            destination_collection,
            destination_token,
            pid,
            exclude,
            include,
            list_labels,
            list_records,
            dry_run,
        )
    except HTTPError as e:
        rprint(
            f'[red]Error[/red]: {e}: {e.response.text}',
            file=sys.stderr,
            flush=True,
        )
    return 1


def auto_curate(
        obj,
        service_url,
        collection,
        destination_service_url,
        destination_collection,
        destination_token,
        pid,
        exclude,
        include,
        list_labels,
        list_records,
        dry_run,
):
    curator_token = obj

    if curator_token is None:
        console.print(f'[red]Error[/red]: no token was provided (use --token or DTC_TOKEN environment variable)')
        return 1

    if destination_service_url is None:
        destination_service_url = service_url

    if destination_token is None:
        destination_token = curator_token

    output = None

    # If --list-labels and --list-records are provided, keep only the latter,
    # because it includes listing of labels
    if list_records:
        if list_labels:
            logger.warning('`-l/--list-labels` and `-r/--list-records` defined, ignoring `-l/--list-labels`')
            list_labels = False
        output = {}

    if list_labels:
        output = []

    all_labels = incoming_read_labels(
        service_url=service_url,
        collection=collection,
        token=obj,
    )
    for label in all_labels:
        if include and label not in include:
            logger.debug('ignoring non-included incoming label: %s', label)
            continue

        if label in exclude:
            logger.debug('ignoring excluded incoming label: %s', label)
            continue

        if list_labels:
            output.append(label)
            continue

        if list_records:
            output[label] = []

        # Get the total number of entries for the
        record_source = incoming_read_records(
            service_url=service_url,
            collection=collection,
            label=label,
            token=obj,
        )

        # Get the first entry to find the total number of records
        try:
            first_record, _, _, _, total = next(record_source)
        except StopIteration:
            console.print(f'no records in incoming area [green]{label}[/green], skipping it')
            continue

        # Get the first entry an all other entries
        for index, (record, _, _, _, total) in track(
                zip(
                    count(),
                    chain(
                        [(first_record, None, None, None, None)],
                        cast(Iterable, record_source),
                    ),
                ),
                description=f'processing [green]{label}[/green]',
                total=total,
                console=console,
        ):
            if list_records:
                output[label].append(record)
                continue

            if pid:
                if record['pid'] not in pid:
                    logger.debug(
                        'ignoring record with non-matching pid: %s',
                        record['pid'])
                    continue

            # Get the class name from the `schema_type` attribute. This requires
            # that the schema type is either stored in the record or that the
            # store has a "Schema Type Layer", i.e., the store type is
            # `record_dir+stl`, or `sqlite+stl`.
            try:
                class_name = re.search('([_A-Za-z0-9]*$)', record['schema_type']).group(0)
            except (IndexError, KeyError):
                global stl_info
                console.print(f'[yellow]Warning[/yellow]: ignoring record with pid {record["pid"]} because `schema_type` attribute is missing.')
                if not stl_info:
                    console.print(
                        '         Please ensure that `schema_type` is stored in the records '
                        'or that the associated incoming area store has a backend with a '
                        '"Schema Type Layer", i.e., "record_dir+stl" or "sqlite+stl"."',
                    )
                    stl_info = True
                continue

            if dry_run:
                console.print(f'WRITE record [green]"{record["pid"]}"[/green] of class "{class_name}" to "{destination_collection}@{destination_service_url}"')
                console.print(f'DELETE record [green]"{record["pid"]}"[/green] from inbox "{label}" of "{collection}@{service_url}"')
                continue

            # Store record in destination collection
            try:
                curated_write_record(
                    service_url=destination_service_url,
                    collection=destination_collection,
                    class_name=class_name,
                    record=record,
                    token=destination_token,
                )
            except HTTPError as e:
                console.print(
                    f'[red]Error[/red]: writing record with pid {record["pid"]} failed: {e}: {e.response.text}',
                )
                raise

            # Delete record from incoming area
            try:
                incoming_delete_record(
                    service_url=service_url,
                    collection=collection,
                    label=label,
                    pid=record['pid'],
                    token=curator_token,
                )
            except HTTPError as e:
                console.print(
                    f'[red]ERROR[/red]: deleting record with pid {record["pid"]} failed: {e}: {e.response.text}',
                )
                raise

    if output is not None:
        rprint(json.dumps(output, ensure_ascii=False))

    return 0


subcommand_name = 'auto-curate'
