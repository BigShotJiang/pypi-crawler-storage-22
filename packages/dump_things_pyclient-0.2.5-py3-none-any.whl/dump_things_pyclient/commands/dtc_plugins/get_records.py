import json
from functools import partial

import rich_click as click

from ...communicate import (
    HTTPError,
    collection_read_records,
    collection_read_record_with_pid,
    collection_read_records_of_class,
    curated_read_records,
    curated_read_records_of_class,
    curated_read_record_with_pid,
    incoming_read_labels,
    incoming_read_records,
    incoming_read_records_of_class,
    incoming_read_record_with_pid,
)


subcommand_name = 'get-records'


@click.command(short_help='Get records from a dump-things collection')
@click.pass_obj
@click.argument(
    'service_url',
    metavar='SERVICE_URL',
)
@click.argument(
    'collection',
    metavar='COLLECTION',
)
@click.option(
    '--class', '-C', 'cls',
    help='only read records of this class, ignored if "--pid" is provided',
)
@click.option(
    '--format', '-f', 'format_',
    type=click.Choice(('json', 'ttl'), case_sensitive=False),
    default='json',
    help='request records in a specific format. (NOTE: not all endpoints support the "format"-parameter)',
)
@click.option(
    '--pid', '-p',
    help='the pid of the record that should be read',
)
@click.option(
    '--incoming', '-i',
    metavar='LABEL',
    help='read from the collection\'s inbox with label LABEL, if LABEL is "-", return labels of all collection inboxes and exit',
)
@click.option(
    '--curated', '-c',
    default=False,
    is_flag=True,
    help='read from the curated area of the collection. (Note: requires a token with curator rights)',
)
@click.option(
    '--matching', '-m',
    help='return only records that have a matching value (use % as wildcard). Ignored if "--pid" is provided. (Note: not all endpoints and backends support matching)',
)
@click.option(
    '--page-size', '-s',
    type=click.IntRange(1, 100),
    default=100,
    help='set the page size (default: 100). (ignored if "--pid" is provided)'
)
@click.option(
    '--first-page', '-F',
    type=click.INT,
    default=1,
    help='the first page to return (default: 1). (ignored if "--pid" is provided)'
)
@click.option(
    '--last-page', '-l',
    type=click.INT,
    help='the last page to return, if not given, all pages will be returned. (ignored if "--pid" is provided)',
    default=None,
)
@click.option(
    '--stats',
    default=False,
    is_flag=True,
    help='show the number of records and pages and exit. (ignored if "--pid" is provided)',
)
@click.option(
    '--pagination', '-P',
    default=False,
    is_flag=True,
    help='show pagination information (each record from an paginated endpoint is returned as [<record>, <current page number>, <total number of pages>, <page size>, <total number of items>]. (ignored if "--pid" is provided)',
)
def cli(
        obj,
        service_url,
        collection,
        cls,
        format_,
        pid,
        incoming,
        curated,
        matching,
        page_size,
        first_page,
        last_page,
        stats,
        pagination,
):
    """Get records from a collection on a dump-things-service

    This command lists records that are stored in collection COLLECTION of the
    dump-things service SERVICE_URL. By
    default, all records that are readable with the given token, or the default
    token, will be displayed. The output format is JSONL (JSON lines), where
    every line contains a record or a record with paging information.  If `ttl`
    is chosen as format of the output records, the record content will be a string
    that contains a TTL-documents.

    The command supports reading from the curated area only, reading from incoming
    areas, or reading a record with a given PID.

    Pagination information is returned for paginated results, when requested with
    `-P/--pagination`. All results are paginated except "get a record with a given PID"
    and "get the list of incoming zone labels".

    For reading from curated or incoming areas, a token with curator rights has
    to be provided.
    """
    try:
        return get_records(
            obj,
            service_url,
            collection,
            cls,
            format_,
            pid,
            incoming,
            curated,
            matching,
            page_size,
            first_page,
            last_page,
            stats,
            pagination,
        )
    except HTTPError as e:
        click.echo(f'ERROR: {e}: {e.response.text}', err=True)
    return 1


def get_records(
        obj,
        service_url,
        collection,
        cls,
        format_,
        pid,
        incoming,
        curated,
        matching,
        page_size,
        first_page,
        last_page,
        stats,
        pagination,
):
    token = obj

    if token is None:
        click.echo(f'WARNING: no token provided', err=True)

    if incoming and curated:
        click.echo(
            'ERROR: -i/--incoming and -c/--curated are mutually exclusive',
            err=True,
        )
        return 1

    kwargs = dict(
        service_url=service_url,
        collection=collection,
        token=token,
    )

    if incoming == '-':
        result = incoming_read_labels(**kwargs)
        click.echo('\n'.join(
            map(
                partial(json.dumps, ensure_ascii=False),
                result)))
        return 0

    elif pid:
        for argument_value, argument_name in (
                (matching, '-m/--matching'),
                (page_size, '-s/--page_size'),
                (first_page, '-f/--first_page'),
                (last_page, '-l/--last_page'),
                (stats, '--stats'),
                (cls, '-c/--class'),
        ):
            if argument_value:
                click.echo(
                    f'WARNING: {argument_name} ignored because "-p/--pid" is provided',
                    err=True,
                )

        kwargs['pid'] = pid
        if curated:
            result = curated_read_record_with_pid(**kwargs)
        elif incoming:
            kwargs['label'] = incoming
            result = incoming_read_record_with_pid(**kwargs)
        else:
            kwargs['format'] = format_
            result = collection_read_record_with_pid(**kwargs)
        print(json.dumps(result, ensure_ascii=False))
        return 0

    elif cls:
        kwargs.update(dict(
            class_name=cls,
            matching=matching,
            page=first_page,
            size=page_size,
            last_page=last_page,
        ))
        if curated:
            result = curated_read_records_of_class(**kwargs)
        elif incoming:
            kwargs['label'] = incoming
            result = incoming_read_records_of_class(**kwargs)
        else:
            kwargs['format'] = format_
            result = collection_read_records_of_class(**kwargs)
    else:
        kwargs.update(dict(
            matching=matching,
            page=first_page,
            size=page_size or 100,
            last_page=last_page,
        ))
        if curated:
            result = curated_read_records(**kwargs)
        elif incoming:
            kwargs['label'] = incoming
            result = incoming_read_records(**kwargs)
        else:
            kwargs['format'] = format_
            result = collection_read_records(**kwargs)

    if pagination:
        for record in result:
            print(json.dumps(record, ensure_ascii=False))
    else:
        for record in result:
            print(json.dumps(record[0], ensure_ascii=False))
    return 0
