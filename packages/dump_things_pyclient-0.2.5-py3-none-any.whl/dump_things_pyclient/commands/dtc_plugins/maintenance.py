import logging

import rich_click as click

from ...communicate import (
    HTTPError,
    maintenance as communicate_maintenance,
)


logger = logging.getLogger('maintenance')

subcommand_name = 'maintenance'


@click.command(short_help='Activate or deactivate maintenance mode on a collection')
@click.pass_obj
@click.argument(
    'service_url',
    metavar='SERVICE_URL',
)
@click.argument(
    'collection',
    metavar='COLLECTION',
)
@click.argument(
    'active',
    metavar='ACTIVE',
    type=click.Choice(['On', 'Off'], case_sensitive=False),
)
def cli(
        obj,
        service_url: str,
        collection: str,
        active: bool,
):
    """Activate or deactivate maintenance mode on collection COLLECTION on the
    service SERVICE_URL. The argument ACTIVE should be either `On` or `Off`
    (case-insensitive).

    A token with curator rights is required.

    This command expects a server version >= 5.4.0"""
    try:
        return maintenance(
            obj,
            service_url,
            collection,
            active,
        )
    except HTTPError as e:
        click.echo(f'ERROR: {e}: {e.response.text}', err=True)
    return 1


def maintenance(
        obj: str,
        service_url: str,
        collection: str,
        active: bool,
):
    token = obj
    if token is None:
        click.echo('ERROR: no token provided', err=True)
        return 1

    communicate_maintenance(
        service_url=service_url,
        collection=collection,
        active=active,
        token=token,
    )
    return 0
