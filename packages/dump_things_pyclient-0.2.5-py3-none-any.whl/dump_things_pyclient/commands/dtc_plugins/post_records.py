import json
import logging
import sys

import rich_click as click

from ...communicate import (
    HTTPError,
    curated_write_record,
    collection_write_record,
)


logger = logging.getLogger('post-records')


@click.command(short_help='Post records to an inbox or the curated area of a dump-things collection')
@click.pass_obj
@click.argument(
    'service_url',
    metavar='SERVICE_URL',
)
@click.argument(
    'collection',
    metavar='COLLECTION',
)
@click.argument(
    'cls',
    metavar='CLASS',
)
@click.option(
    '--curated',
    default=False,
    is_flag=True,
    help='store record directly in curated area instead of an inbox. (Note: requires a token with curator rights)'
)
def cli(
        obj,
        service_url,
        collection,
        cls,
        curated,
):
    """Read records of class CLASS from standard input and store them in
    the collection COLLECTION on the service SERVICE_URL. Records should be
    provided in JSON-lines format. Note: all records are assumed to be of class
    CLASS. To submit records of multiple classes, the subcommand has to be
    invoked multiple times, once for each class.

    If the `--curated`-option is provided, the records will be stored directly
    in the curated area of the collection without any alterations, i.e, no
    annotations will be added.

    If no `--curated`-option is provided, the record will be stored in the
    inbox of the user that is associated with the token, and the record will be
    annotated with the submission time and the user that performed
    the submission.

    A token is required and will be used to authenticate the requests.
    If the `--curated`-option is provided, the token must have
    curator-rights."""
    try:
        return post_records(
            obj,
            service_url,
            collection,
            cls,
            curated,
        )
    except HTTPError as e:
        click.echo(f'ERROR: {e}: {e.response.text}', err=True)
    return 1


def post_records(
        obj,
        service_url,
        collection,
        cls,
        curated,
):
    token = obj
    if token is None:
        click.echo('ERROR: no token provided', err=True)
        return 1

    if curated:
        write_record = curated_write_record
    else:
        write_record = collection_write_record

    posted = False
    for line in sys.stdin:
        record = json.loads(line)
        try:
            write_record(
                service_url=service_url,
                collection=collection,
                class_name=cls,
                record=record,
                token=token,
            )
        except Exception as e:
            click.echo(f'ERROR: {e}', err=True)
        else:
            posted = True
            click.echo('.', nl=False)

    if posted:
        # echo a final newline
        click.echo('')

    return 0


subcommand_name = 'post-records'
