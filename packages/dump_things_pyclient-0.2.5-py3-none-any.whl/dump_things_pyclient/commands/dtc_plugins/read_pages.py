import json
import logging

import rich_click as click

from ...communicate import (
    HTTPError,
    get_paginated,
)


logger = logging.getLogger('read-pages')


@click.command(short_help='Read records from paginated dump-things endpoints')
@click.pass_obj
@click.argument(
    'url',
    metavar='URL',
)
@click.option(
    '--page-size', '-s',
    type=click.INT,
    default=100,
    help='set the page size (1 - 100) (default: 100)'
)
@click.option(
    '--first-page', '-F',
    type=click.INT,
    default=1,
    help='the first page to return (default: 1)'
)
@click.option(
    '--last-page', '-l',
    type=click.INT,
    help='the last page to return (default: None (return all pages)',
)
@click.option(
    '--stats',
    is_flag=True,
    default=False,
    help='show information about  the number of records and pages and exit, the format is  is returned as [<total number of pages>, <page size>, <total number of items>]',
)
@click.option(
    '--format', '-f', 'format_',
    type=click.Choice(('json', 'ttl'), case_sensitive=False),
    default='json',
    help='request output records in a specific format. (NOTE: not all endpoints support the "format"-parameter)',
)
@click.option(
    '--matching', '-m',
    help='return only records that have a matching value (use % as wildcard). (NOTE: not all endpoints and storage-backends support matching.)',
)
@click.option(
    '--pagination', '-P',
    is_flag=True,
    help='show pagination information (each record from an paginated endpoint is returned as [<record>, <current page number>, <total number of pages>, <page size>, <total number of items>]',
)
def cli(
        obj,
        url,
        page_size,
        first_page,
        last_page,
        stats,
        format_,
        matching,
        pagination,
):
    """Read paginated endpoint

    This command lists all records that are available via a paginated endpoints from
    a dump-things-service, e.g., given by URL

      https://<service-location>/<collection>/records/p/

    """
    try:
        return read_pages(
            obj,
            url,
            page_size,
            first_page,
            last_page,
            stats,
            format_,
            matching,
            pagination,
        )
    except HTTPError as e:
        click.echo(f'ERROR: {e}: {e.response.text}', err=True)
    return 1


def read_pages(
        obj,
        url,
        page_size,
        first_page,
        last_page,
        stats,
        format_,
        matching,
        pagination,
):
    token = obj

    if token is None:
        click.echo(f'WARNING: no token provided', err=True)

    result = get_paginated(
        url=url,
        token=token,
        first_page=first_page,
        page_size=page_size,
        last_page=last_page,
        parameters={
            'format': format_,
            **(
                {'matching': matching}
                if matching is not None
                else {}
            ),
        }
    )

    if stats:
        record = next(result)
        click.echo(json.dumps(record[2:], ensure_ascii=False))
        return 0

    if pagination:
        for record in result:
            click.echo(json.dumps(record, ensure_ascii=False))
    else:
        for record in result:
            click.echo(json.dumps(record[0], ensure_ascii=False))
    return 0


subcommand_name = 'read-pages'
