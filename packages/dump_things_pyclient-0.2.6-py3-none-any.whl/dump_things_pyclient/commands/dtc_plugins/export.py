import json
import sys
from collections import defaultdict
from itertools import count
from pathlib import Path
from typing import (
    Any,
    Iterable,
)

import rich_click as click
from rich.console import Console
from rich.progress import track

from ...communicate import (
    HTTPError,
    curated_read_records,
    get_session,
    incoming_read_labels,
    incoming_read_records,
    server,
)


subcommand_name = 'export'

console = Console(file=sys.stderr)


@click.command(short_help='Export a collection to the file system')
@click.pass_obj
@click.argument(
    'service_url',
    metavar='SERVICE_URL',
)
@click.argument(
    'collection',
    metavar='COLLECTION',
)
@click.argument(
    'destination',
    type=click.Path(
        exists=False,
        file_okay=False,
        dir_okay=True,
        writable=True,
        allow_dash=False,
        path_type=Path,
    ),
    metavar='DESTINATION_DIR',
)
@click.option(
    '--ignore-errors',
    default=False,
    is_flag=True,
    help='ignore records with missing `schema_type` instead of raising an error',
)
def cli(
        obj: Any,
        service_url: str,
        collection: str,
        destination: Path,
        ignore_errors,
):
    """Export a collection to disk

    This command exports all records that are stored in curated area and in the
    incoming areas of collection COLLECTION of the dump-things service
    SERVICE_URL.

    Exported records are written to the directory DESTINATION_DIR.
    DESTINATION_DIR must not exist, `export` will create it.

    A token with curator rights has to be provided.
    """
    try:
        return export(
            obj,
            service_url,
            collection,
            destination,
            ignore_errors,
        )
    except HTTPError as e:
        console.print(f'[red]Error[/red]: {e}: {e.response.text}')
    except ValueError as e:
        console.print(f'[red]Error[/red]: {e}')
    return 1


def export(
        obj: Any,
        service_url: str,
        collection: str,
        destination: Path,
        ignore_errors: bool,
):
    token = obj

    if token is None:
        console.print(f'[red]Error[/red]: no token provided')
        return 1

    session = get_session()
    server_info = server(service_url, session=session)
    collection_info = ([c for c in server_info['collections'] if c['name'] == collection] or None)[0]

    if not collection_info:
        console.print(f'[red]Error[/red]: no collection {collection} on service')
        return 1

    description = {
        'name': collection,
        'schema': collection_info['schema'],
    }

    destination.mkdir(parents=True, exist_ok=False)
    (destination / 'description.json').write_text(
        json.dumps(description, ensure_ascii=False),
    )

    # Store the curated records
    curated_destination = destination / 'curated'
    curated_destination.mkdir()

    console.print('Exporting records from curated area')
    _store_records(
        map(
            lambda x: x[0],
            curated_read_records(
                service_url=service_url,
                collection=collection,
                token=token,
                session=session,
            )
        ),
        curated_destination,
        ignore_errors,
    )

    # Store the incoming records
    for label in incoming_read_labels(
            service_url=service_url,
            collection=collection,
            token=token,
            session=session,
    ):
        console.print(f'Exporting records from incoming area: {label}')
        incoming_destination = destination / 'incoming' / label
        incoming_destination.mkdir(parents=True, exist_ok=False)
        _store_records(
            map(
                lambda x: x[0],
                incoming_read_records(
                    service_url=service_url,
                    collection=collection,
                    label=label,
                    token=token,
                    session=session,
                )
            ),
            incoming_destination,
            ignore_errors,
        )

    return 0


def _store_records(
        source: Iterable,
        destination: Path,
        ignore_errors: bool = False,
):
    created_dirs = set()
    class_counters = defaultdict(count)

    for record in track(source, console=console):
        class_name = _de_prefix(record.get('schema_type', None))
        if class_name is None:
            if ignore_errors:
                console.print(f'[red]Error[/red]: no `schema type` in record {record["pid"]}')
                continue
            msg = f'no `schema_type` in record {record["pid"]}'
            raise ValueError(msg)

        next_name_for_class = f'{next(class_counters[class_name]):09d}.json'
        file_dir, file_name = (
            destination / class_name / next_name_for_class[:3],
            next_name_for_class[3:]
        )
        if file_dir not in created_dirs:
            file_dir.mkdir(parents=True, exist_ok=False)
            created_dirs.add(file_dir)

        (file_dir / file_name).write_text(
            json.dumps(record, indent=2, ensure_ascii=False),
        )


def _de_prefix(
        name: str,
):
    return name.split(':', 1)[-1]
