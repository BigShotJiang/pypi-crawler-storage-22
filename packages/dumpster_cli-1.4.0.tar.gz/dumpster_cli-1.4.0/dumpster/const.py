FILE_SEPARATOR = "# ---- file:"

DEFAULT_TEXT_EXTENSIONS = {
    ".py",
    ".pyi",
    ".md",
    ".yaml",
    ".yml",
    ".toml",
    ".json",
    ".txt",
    ".rst",
    ".ini",
}
