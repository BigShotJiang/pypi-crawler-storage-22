import logging
from logging import getLogger, basicConfig

basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
