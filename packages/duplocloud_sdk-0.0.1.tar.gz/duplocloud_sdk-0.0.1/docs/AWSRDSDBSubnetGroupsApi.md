# duplocloud_sdk.AWSRDSDBSubnetGroupsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**rds_api_db_subnet_groups**](AWSRDSDBSubnetGroupsApi.md#rds_api_db_subnet_groups) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/dbSubnetGroups | 


# **rds_api_db_subnet_groups**
> List[DBSubnetGroup] rds_api_db_subnet_groups(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.db_subnet_group import DBSubnetGroup
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSDBSubnetGroupsApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_db_subnet_groups(subscription_id)
        print("The response of AWSRDSDBSubnetGroupsApi->rds_api_db_subnet_groups:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSDBSubnetGroupsApi->rds_api_db_subnet_groups: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**List[DBSubnetGroup]**](DBSubnetGroup.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

