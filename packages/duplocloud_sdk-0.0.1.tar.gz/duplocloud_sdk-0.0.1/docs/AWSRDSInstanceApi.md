# duplocloud_sdk.AWSRDSInstanceApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**rds_api_instance_get3**](AWSRDSInstanceApi.md#rds_api_instance_get3) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/groupDetails | 
[**rds_api_instance_post10**](AWSRDSInstanceApi.md#rds_api_instance_post10) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/restorePointInTime | 
[**rds_api_instance_post6**](AWSRDSInstanceApi.md#rds_api_instance_post6) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/reboot | 
[**rds_api_instance_post7**](AWSRDSInstanceApi.md#rds_api_instance_post7) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/start | 
[**rds_api_instance_post8**](AWSRDSInstanceApi.md#rds_api_instance_post8) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/stop | 


# **rds_api_instance_get3**
> DBInstanceWithReplicas rds_api_instance_get3(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.db_instance_with_replicas import DBInstanceWithReplicas
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSInstanceApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_get3(subscription_id, id)
        print("The response of AWSRDSInstanceApi->rds_api_instance_get3:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSInstanceApi->rds_api_instance_get3: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**DBInstanceWithReplicas**](DBInstanceWithReplicas.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post10**
> rds_api_instance_post10(subscription_id, id, rds_point_in_time_restore_request=rds_point_in_time_restore_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rds_point_in_time_restore_request import RdsPointInTimeRestoreRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSInstanceApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rds_point_in_time_restore_request = duplocloud_sdk.RdsPointInTimeRestoreRequest() # RdsPointInTimeRestoreRequest |  (optional)

    try:
        api_instance.rds_api_instance_post10(subscription_id, id, rds_point_in_time_restore_request=rds_point_in_time_restore_request)
    except Exception as e:
        print("Exception when calling AWSRDSInstanceApi->rds_api_instance_post10: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rds_point_in_time_restore_request** | [**RdsPointInTimeRestoreRequest**](RdsPointInTimeRestoreRequest.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post6**
> rds_api_instance_post6(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSInstanceApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_instance_post6(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSRDSInstanceApi->rds_api_instance_post6: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post7**
> rds_api_instance_post7(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSInstanceApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_instance_post7(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSRDSInstanceApi->rds_api_instance_post7: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post8**
> rds_api_instance_post8(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSInstanceApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_instance_post8(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSRDSInstanceApi->rds_api_instance_post8: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

