# duplocloud_sdk.AWSUpdateRdsPayloadApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**rds_api_instance_put2**](AWSUpdateRdsPayloadApi.md#rds_api_instance_put2) | **PUT** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/updatePayload | 


# **rds_api_instance_put2**
> rds_api_instance_put2(subscription_id, id, update_rds_instance_request=update_rds_instance_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.update_rds_instance_request import UpdateRdsInstanceRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSUpdateRdsPayloadApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    update_rds_instance_request = duplocloud_sdk.UpdateRdsInstanceRequest() # UpdateRdsInstanceRequest |  (optional)

    try:
        api_instance.rds_api_instance_put2(subscription_id, id, update_rds_instance_request=update_rds_instance_request)
    except Exception as e:
        print("Exception when calling AWSUpdateRdsPayloadApi->rds_api_instance_put2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **update_rds_instance_request** | [**UpdateRdsInstanceRequest**](UpdateRdsInstanceRequest.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

