# Action


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authenticate_cognito_config** | [**AuthenticateCognitoActionConfig**](AuthenticateCognitoActionConfig.md) |  | [optional] 
**authenticate_oidc_config** | [**AuthenticateOidcActionConfig**](AuthenticateOidcActionConfig.md) |  | [optional] 
**fixed_response_config** | [**FixedResponseActionConfig**](FixedResponseActionConfig.md) |  | [optional] 
**forward_config** | [**ForwardActionConfig**](ForwardActionConfig.md) |  | [optional] 
**order** | **int** |  | [optional] 
**redirect_config** | [**RedirectActionConfig**](RedirectActionConfig.md) |  | [optional] 
**target_group_arn** | **str** |  | [optional] 
**type** | [**ActionTypeEnum**](ActionTypeEnum.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.action import Action

# TODO update the JSON string below
json = "{}"
# create an instance of Action from a JSON string
action_instance = Action.from_json(json)
# print the JSON string representation of the object
print(Action.to_json())

# convert the object into a dict
action_dict = action_instance.to_dict()
# create an instance of Action from a dict
action_from_dict = Action.from_dict(action_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


