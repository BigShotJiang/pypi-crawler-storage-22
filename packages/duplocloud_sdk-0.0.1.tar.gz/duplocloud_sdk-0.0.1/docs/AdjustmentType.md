# AdjustmentType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.adjustment_type import AdjustmentType

# TODO update the JSON string below
json = "{}"
# create an instance of AdjustmentType from a JSON string
adjustment_type_instance = AdjustmentType.from_json(json)
# print the JSON string representation of the object
print(AdjustmentType.to_json())

# convert the object into a dict
adjustment_type_dict = adjustment_type_instance.to_dict()
# create an instance of AdjustmentType from a dict
adjustment_type_from_dict = AdjustmentType.from_dict(adjustment_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


