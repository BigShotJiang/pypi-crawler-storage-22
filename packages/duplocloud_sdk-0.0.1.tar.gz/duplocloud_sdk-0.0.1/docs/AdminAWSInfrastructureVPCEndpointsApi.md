# duplocloud_sdk.AdminAWSInfrastructureVPCEndpointsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v3_admin_infrastructure_api_create_aws_vpc_endpoint_by_id**](AdminAWSInfrastructureVPCEndpointsApi.md#v3_admin_infrastructure_api_create_aws_vpc_endpoint_by_id) | **POST** /v3/admin/infrastructure/{name}/vpcEndpoints | 
[**v3_admin_infrastructure_api_delete_aws_vpc_endpoint_by_id**](AdminAWSInfrastructureVPCEndpointsApi.md#v3_admin_infrastructure_api_delete_aws_vpc_endpoint_by_id) | **DELETE** /v3/admin/infrastructure/{name}/vpcEndpoints/{id} | 
[**v3_admin_infrastructure_api_get_aws_vpc_endpoint_by_id**](AdminAWSInfrastructureVPCEndpointsApi.md#v3_admin_infrastructure_api_get_aws_vpc_endpoint_by_id) | **GET** /v3/admin/infrastructure/{name}/vpcEndpoints/{id} | 
[**v3_admin_infrastructure_api_get_aws_vpc_endpoint_services**](AdminAWSInfrastructureVPCEndpointsApi.md#v3_admin_infrastructure_api_get_aws_vpc_endpoint_services) | **GET** /v3/admin/infrastructure/{name}/vpcEndpointServices | 
[**v3_admin_infrastructure_api_get_aws_vpc_endpoints**](AdminAWSInfrastructureVPCEndpointsApi.md#v3_admin_infrastructure_api_get_aws_vpc_endpoints) | **GET** /v3/admin/infrastructure/{name}/vpcEndpoints | 


# **v3_admin_infrastructure_api_create_aws_vpc_endpoint_by_id**
> VpcEndpoint v3_admin_infrastructure_api_create_aws_vpc_endpoint_by_id(name, create_vpc_endpoint_request=create_vpc_endpoint_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.create_vpc_endpoint_request import CreateVpcEndpointRequest
from duplocloud_sdk.models.vpc_endpoint import VpcEndpoint
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminAWSInfrastructureVPCEndpointsApi(api_client)
    name = 'name_example' # str | 
    create_vpc_endpoint_request = duplocloud_sdk.CreateVpcEndpointRequest() # CreateVpcEndpointRequest |  (optional)

    try:
        api_response = api_instance.v3_admin_infrastructure_api_create_aws_vpc_endpoint_by_id(name, create_vpc_endpoint_request=create_vpc_endpoint_request)
        print("The response of AdminAWSInfrastructureVPCEndpointsApi->v3_admin_infrastructure_api_create_aws_vpc_endpoint_by_id:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminAWSInfrastructureVPCEndpointsApi->v3_admin_infrastructure_api_create_aws_vpc_endpoint_by_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 
 **create_vpc_endpoint_request** | [**CreateVpcEndpointRequest**](CreateVpcEndpointRequest.md)|  | [optional] 

### Return type

[**VpcEndpoint**](VpcEndpoint.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_delete_aws_vpc_endpoint_by_id**
> v3_admin_infrastructure_api_delete_aws_vpc_endpoint_by_id(name, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminAWSInfrastructureVPCEndpointsApi(api_client)
    name = 'name_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.v3_admin_infrastructure_api_delete_aws_vpc_endpoint_by_id(name, id)
    except Exception as e:
        print("Exception when calling AdminAWSInfrastructureVPCEndpointsApi->v3_admin_infrastructure_api_delete_aws_vpc_endpoint_by_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_get_aws_vpc_endpoint_by_id**
> VpcEndpoint v3_admin_infrastructure_api_get_aws_vpc_endpoint_by_id(name, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.vpc_endpoint import VpcEndpoint
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminAWSInfrastructureVPCEndpointsApi(api_client)
    name = 'name_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.v3_admin_infrastructure_api_get_aws_vpc_endpoint_by_id(name, id)
        print("The response of AdminAWSInfrastructureVPCEndpointsApi->v3_admin_infrastructure_api_get_aws_vpc_endpoint_by_id:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminAWSInfrastructureVPCEndpointsApi->v3_admin_infrastructure_api_get_aws_vpc_endpoint_by_id: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**VpcEndpoint**](VpcEndpoint.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_get_aws_vpc_endpoint_services**
> List[ServiceDetail] v3_admin_infrastructure_api_get_aws_vpc_endpoint_services(name)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.service_detail import ServiceDetail
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminAWSInfrastructureVPCEndpointsApi(api_client)
    name = 'name_example' # str | 

    try:
        api_response = api_instance.v3_admin_infrastructure_api_get_aws_vpc_endpoint_services(name)
        print("The response of AdminAWSInfrastructureVPCEndpointsApi->v3_admin_infrastructure_api_get_aws_vpc_endpoint_services:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminAWSInfrastructureVPCEndpointsApi->v3_admin_infrastructure_api_get_aws_vpc_endpoint_services: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 

### Return type

[**List[ServiceDetail]**](ServiceDetail.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_get_aws_vpc_endpoints**
> List[VpcEndpoint] v3_admin_infrastructure_api_get_aws_vpc_endpoints(name)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.vpc_endpoint import VpcEndpoint
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminAWSInfrastructureVPCEndpointsApi(api_client)
    name = 'name_example' # str | 

    try:
        api_response = api_instance.v3_admin_infrastructure_api_get_aws_vpc_endpoints(name)
        print("The response of AdminAWSInfrastructureVPCEndpointsApi->v3_admin_infrastructure_api_get_aws_vpc_endpoints:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminAWSInfrastructureVPCEndpointsApi->v3_admin_infrastructure_api_get_aws_vpc_endpoints: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 

### Return type

[**List[VpcEndpoint]**](VpcEndpoint.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

