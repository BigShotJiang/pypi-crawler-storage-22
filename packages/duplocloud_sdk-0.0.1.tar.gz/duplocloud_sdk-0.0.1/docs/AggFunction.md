# AggFunction


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.agg_function import AggFunction

# TODO update the JSON string below
json = "{}"
# create an instance of AggFunction from a JSON string
agg_function_instance = AggFunction.from_json(json)
# print the JSON string representation of the object
print(AggFunction.to_json())

# convert the object into a dict
agg_function_dict = agg_function_instance.to_dict()
# create an instance of AggFunction from a dict
agg_function_from_dict = AggFunction.from_dict(agg_function_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


