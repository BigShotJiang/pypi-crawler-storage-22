# Aggregate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aggs** | [**List[AggregateOperation]**](AggregateOperation.md) |  | [optional] 
**groups** | **List[List[str]]** |  | [optional] 
**inputs** | **List[str]** |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aggregate import Aggregate

# TODO update the JSON string below
json = "{}"
# create an instance of Aggregate from a JSON string
aggregate_instance = Aggregate.from_json(json)
# print the JSON string representation of the object
print(Aggregate.to_json())

# convert the object into a dict
aggregate_dict = aggregate_instance.to_dict()
# create an instance of Aggregate from a dict
aggregate_from_dict = Aggregate.from_dict(aggregate_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


