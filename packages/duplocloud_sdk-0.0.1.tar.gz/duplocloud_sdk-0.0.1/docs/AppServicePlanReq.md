# AppServicePlanReq


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**kind** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**properties_worker_tier_name** | **str** |  | [optional] 
**properties_status** | [**AzureStatusOptions**](AzureStatusOptions.md) |  | [optional] 
**properties_subscription** | **str** |  | [optional] 
**properties_hosting_environment_profile** | [**AzureHostingEnvironmentProfile**](AzureHostingEnvironmentProfile.md) |  | [optional] 
**properties_maximum_number_of_workers** | **int** |  | [optional] 
**properties_geo_region** | **str** |  | [optional] 
**properties_per_site_scaling** | **bool** |  | [optional] 
**properties_maximum_elastic_worker_count** | **int** |  | [optional] 
**properties_number_of_sites** | **int** |  | [optional] 
**properties_is_spot** | **bool** |  | [optional] 
**properties_spot_expiration_time** | **datetime** |  | [optional] 
**properties_free_offer_expiration_time** | **datetime** |  | [optional] 
**properties_resource_group** | **str** |  | [optional] 
**properties_reserved** | **bool** |  | [optional] 
**properties_is_xenon** | **bool** |  | [optional] 
**properties_hyper_v** | **bool** |  | [optional] 
**properties_target_worker_count** | **int** |  | [optional] 
**properties_target_worker_size_id** | **int** |  | [optional] 
**properties_provisioning_state** | [**AzureProvisioningState**](AzureProvisioningState.md) |  | [optional] 
**sku** | [**AzureSkuDescription**](AzureSkuDescription.md) |  | [optional] 
**name_ex** | **str** |  | [optional] 
**is_update** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.app_service_plan_req import AppServicePlanReq

# TODO update the JSON string below
json = "{}"
# create an instance of AppServicePlanReq from a JSON string
app_service_plan_req_instance = AppServicePlanReq.from_json(json)
# print the JSON string representation of the object
print(AppServicePlanReq.to_json())

# convert the object into a dict
app_service_plan_req_dict = app_service_plan_req_instance.to_dict()
# create an instance of AppServicePlanReq from a dict
app_service_plan_req_from_dict = AppServicePlanReq.from_dict(app_service_plan_req_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


