# AuthenticateCognitoActionConditionalBehaviorEnum


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.authenticate_cognito_action_conditional_behavior_enum import AuthenticateCognitoActionConditionalBehaviorEnum

# TODO update the JSON string below
json = "{}"
# create an instance of AuthenticateCognitoActionConditionalBehaviorEnum from a JSON string
authenticate_cognito_action_conditional_behavior_enum_instance = AuthenticateCognitoActionConditionalBehaviorEnum.from_json(json)
# print the JSON string representation of the object
print(AuthenticateCognitoActionConditionalBehaviorEnum.to_json())

# convert the object into a dict
authenticate_cognito_action_conditional_behavior_enum_dict = authenticate_cognito_action_conditional_behavior_enum_instance.to_dict()
# create an instance of AuthenticateCognitoActionConditionalBehaviorEnum from a dict
authenticate_cognito_action_conditional_behavior_enum_from_dict = AuthenticateCognitoActionConditionalBehaviorEnum.from_dict(authenticate_cognito_action_conditional_behavior_enum_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


