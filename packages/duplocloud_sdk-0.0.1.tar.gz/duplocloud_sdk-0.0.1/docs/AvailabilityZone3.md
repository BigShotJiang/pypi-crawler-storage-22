# AvailabilityZone3


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.availability_zone3 import AvailabilityZone3

# TODO update the JSON string below
json = "{}"
# create an instance of AvailabilityZone3 from a JSON string
availability_zone3_instance = AvailabilityZone3.from_json(json)
# print the JSON string representation of the object
print(AvailabilityZone3.to_json())

# convert the object into a dict
availability_zone3_dict = availability_zone3_instance.to_dict()
# create an instance of AvailabilityZone3 from a dict
availability_zone3_from_dict = AvailabilityZone3.from_dict(availability_zone3_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


