# AwsAdvancedConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alternate_target_group_arn** | **str** |  | [optional] 
**production_listener_rule** | **str** |  | [optional] 
**role_arn** | **str** |  | [optional] 
**test_listener_rule** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_advanced_configuration import AwsAdvancedConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAdvancedConfiguration from a JSON string
aws_advanced_configuration_instance = AwsAdvancedConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsAdvancedConfiguration.to_json())

# convert the object into a dict
aws_advanced_configuration_dict = aws_advanced_configuration_instance.to_dict()
# create an instance of AwsAdvancedConfiguration from a dict
aws_advanced_configuration_from_dict = AwsAdvancedConfiguration.from_dict(aws_advanced_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


