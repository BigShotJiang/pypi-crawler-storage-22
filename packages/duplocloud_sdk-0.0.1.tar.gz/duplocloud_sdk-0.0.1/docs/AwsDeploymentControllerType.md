# AwsDeploymentControllerType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_deployment_controller_type import AwsDeploymentControllerType

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDeploymentControllerType from a JSON string
aws_deployment_controller_type_instance = AwsDeploymentControllerType.from_json(json)
# print the JSON string representation of the object
print(AwsDeploymentControllerType.to_json())

# convert the object into a dict
aws_deployment_controller_type_dict = aws_deployment_controller_type_instance.to_dict()
# create an instance of AwsDeploymentControllerType from a dict
aws_deployment_controller_type_from_dict = AwsDeploymentControllerType.from_dict(aws_deployment_controller_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


