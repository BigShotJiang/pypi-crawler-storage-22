# AwsDeploymentRolloutState


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_deployment_rollout_state import AwsDeploymentRolloutState

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDeploymentRolloutState from a JSON string
aws_deployment_rollout_state_instance = AwsDeploymentRolloutState.from_json(json)
# print the JSON string representation of the object
print(AwsDeploymentRolloutState.to_json())

# convert the object into a dict
aws_deployment_rollout_state_dict = aws_deployment_rollout_state_instance.to_dict()
# create an instance of AwsDeploymentRolloutState from a dict
aws_deployment_rollout_state_from_dict = AwsDeploymentRolloutState.from_dict(aws_deployment_rollout_state_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


