# AwsEnvironmentFileType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_environment_file_type import AwsEnvironmentFileType

# TODO update the JSON string below
json = "{}"
# create an instance of AwsEnvironmentFileType from a JSON string
aws_environment_file_type_instance = AwsEnvironmentFileType.from_json(json)
# print the JSON string representation of the object
print(AwsEnvironmentFileType.to_json())

# convert the object into a dict
aws_environment_file_type_dict = aws_environment_file_type_instance.to_dict()
# create an instance of AwsEnvironmentFileType from a dict
aws_environment_file_type_from_dict = AwsEnvironmentFileType.from_dict(aws_environment_file_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


