# AwsFirelensConfigurationType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_firelens_configuration_type import AwsFirelensConfigurationType

# TODO update the JSON string below
json = "{}"
# create an instance of AwsFirelensConfigurationType from a JSON string
aws_firelens_configuration_type_instance = AwsFirelensConfigurationType.from_json(json)
# print the JSON string representation of the object
print(AwsFirelensConfigurationType.to_json())

# convert the object into a dict
aws_firelens_configuration_type_dict = aws_firelens_configuration_type_instance.to_dict()
# create an instance of AwsFirelensConfigurationType from a dict
aws_firelens_configuration_type_from_dict = AwsFirelensConfigurationType.from_dict(aws_firelens_configuration_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


