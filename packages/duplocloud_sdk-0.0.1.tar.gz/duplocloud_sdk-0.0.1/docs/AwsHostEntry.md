# AwsHostEntry


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hostname** | **str** |  | [optional] 
**ip_address** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_host_entry import AwsHostEntry

# TODO update the JSON string below
json = "{}"
# create an instance of AwsHostEntry from a JSON string
aws_host_entry_instance = AwsHostEntry.from_json(json)
# print the JSON string representation of the object
print(AwsHostEntry.to_json())

# convert the object into a dict
aws_host_entry_dict = aws_host_entry_instance.to_dict()
# create an instance of AwsHostEntry from a dict
aws_host_entry_from_dict = AwsHostEntry.from_dict(aws_host_entry_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


