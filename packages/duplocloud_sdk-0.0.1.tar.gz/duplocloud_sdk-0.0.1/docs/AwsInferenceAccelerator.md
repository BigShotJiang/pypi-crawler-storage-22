# AwsInferenceAccelerator


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**device_name** | **str** |  | [optional] 
**device_type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_inference_accelerator import AwsInferenceAccelerator

# TODO update the JSON string below
json = "{}"
# create an instance of AwsInferenceAccelerator from a JSON string
aws_inference_accelerator_instance = AwsInferenceAccelerator.from_json(json)
# print the JSON string representation of the object
print(AwsInferenceAccelerator.to_json())

# convert the object into a dict
aws_inference_accelerator_dict = aws_inference_accelerator_instance.to_dict()
# create an instance of AwsInferenceAccelerator from a dict
aws_inference_accelerator_from_dict = AwsInferenceAccelerator.from_dict(aws_inference_accelerator_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


