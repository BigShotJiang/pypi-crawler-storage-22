# AwsKeyValuePair


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_key_value_pair import AwsKeyValuePair

# TODO update the JSON string below
json = "{}"
# create an instance of AwsKeyValuePair from a JSON string
aws_key_value_pair_instance = AwsKeyValuePair.from_json(json)
# print the JSON string representation of the object
print(AwsKeyValuePair.to_json())

# convert the object into a dict
aws_key_value_pair_dict = aws_key_value_pair_instance.to_dict()
# create an instance of AwsKeyValuePair from a dict
aws_key_value_pair_from_dict = AwsKeyValuePair.from_dict(aws_key_value_pair_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


