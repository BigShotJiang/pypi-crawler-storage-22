# AwsManagedAgentName


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_managed_agent_name import AwsManagedAgentName

# TODO update the JSON string below
json = "{}"
# create an instance of AwsManagedAgentName from a JSON string
aws_managed_agent_name_instance = AwsManagedAgentName.from_json(json)
# print the JSON string representation of the object
print(AwsManagedAgentName.to_json())

# convert the object into a dict
aws_managed_agent_name_dict = aws_managed_agent_name_instance.to_dict()
# create an instance of AwsManagedAgentName from a dict
aws_managed_agent_name_from_dict = AwsManagedAgentName.from_dict(aws_managed_agent_name_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


