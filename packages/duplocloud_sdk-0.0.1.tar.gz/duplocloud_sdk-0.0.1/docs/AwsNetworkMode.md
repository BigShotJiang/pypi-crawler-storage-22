# AwsNetworkMode


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_network_mode import AwsNetworkMode

# TODO update the JSON string below
json = "{}"
# create an instance of AwsNetworkMode from a JSON string
aws_network_mode_instance = AwsNetworkMode.from_json(json)
# print the JSON string representation of the object
print(AwsNetworkMode.to_json())

# convert the object into a dict
aws_network_mode_dict = aws_network_mode_instance.to_dict()
# create an instance of AwsNetworkMode from a dict
aws_network_mode_from_dict = AwsNetworkMode.from_dict(aws_network_mode_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


