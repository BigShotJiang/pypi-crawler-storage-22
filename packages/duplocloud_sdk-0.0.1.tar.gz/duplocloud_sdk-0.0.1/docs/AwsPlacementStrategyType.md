# AwsPlacementStrategyType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_placement_strategy_type import AwsPlacementStrategyType

# TODO update the JSON string below
json = "{}"
# create an instance of AwsPlacementStrategyType from a JSON string
aws_placement_strategy_type_instance = AwsPlacementStrategyType.from_json(json)
# print the JSON string representation of the object
print(AwsPlacementStrategyType.to_json())

# convert the object into a dict
aws_placement_strategy_type_dict = aws_placement_strategy_type_instance.to_dict()
# create an instance of AwsPlacementStrategyType from a dict
aws_placement_strategy_type_from_dict = AwsPlacementStrategyType.from_dict(aws_placement_strategy_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


