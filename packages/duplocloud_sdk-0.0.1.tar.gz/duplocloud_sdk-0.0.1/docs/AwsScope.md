# AwsScope


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_scope import AwsScope

# TODO update the JSON string below
json = "{}"
# create an instance of AwsScope from a JSON string
aws_scope_instance = AwsScope.from_json(json)
# print the JSON string representation of the object
print(AwsScope.to_json())

# convert the object into a dict
aws_scope_dict = aws_scope_instance.to_dict()
# create an instance of AwsScope from a dict
aws_scope_from_dict = AwsScope.from_dict(aws_scope_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


