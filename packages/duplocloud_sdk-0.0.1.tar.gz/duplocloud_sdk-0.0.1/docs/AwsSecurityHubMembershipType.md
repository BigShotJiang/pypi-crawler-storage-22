# AwsSecurityHubMembershipType



## Enum

* `Standalone` (value: `0`)

* `AdministratorAccount` (value: `1`)

* `MemberAccount` (value: `2`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


