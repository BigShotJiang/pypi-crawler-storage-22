# AwsSecurityLogBucketType



## Enum

* `Standard` (value: `0`)

* `CentralCurrentAccount` (value: `1`)

* `CentralOtherAccount` (value: `2`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


