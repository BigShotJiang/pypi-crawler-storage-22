# AwsServiceConnectServiceResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**discovery_arn** | **str** |  | [optional] 
**discovery_name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_connect_service_resource import AwsServiceConnectServiceResource

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceConnectServiceResource from a JSON string
aws_service_connect_service_resource_instance = AwsServiceConnectServiceResource.from_json(json)
# print the JSON string representation of the object
print(AwsServiceConnectServiceResource.to_json())

# convert the object into a dict
aws_service_connect_service_resource_dict = aws_service_connect_service_resource_instance.to_dict()
# create an instance of AwsServiceConnectServiceResource from a dict
aws_service_connect_service_resource_from_dict = AwsServiceConnectServiceResource.from_dict(aws_service_connect_service_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


