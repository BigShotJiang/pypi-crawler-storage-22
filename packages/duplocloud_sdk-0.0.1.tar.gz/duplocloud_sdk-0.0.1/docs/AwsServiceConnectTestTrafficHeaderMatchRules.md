# AwsServiceConnectTestTrafficHeaderMatchRules


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exact** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_connect_test_traffic_header_match_rules import AwsServiceConnectTestTrafficHeaderMatchRules

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceConnectTestTrafficHeaderMatchRules from a JSON string
aws_service_connect_test_traffic_header_match_rules_instance = AwsServiceConnectTestTrafficHeaderMatchRules.from_json(json)
# print the JSON string representation of the object
print(AwsServiceConnectTestTrafficHeaderMatchRules.to_json())

# convert the object into a dict
aws_service_connect_test_traffic_header_match_rules_dict = aws_service_connect_test_traffic_header_match_rules_instance.to_dict()
# create an instance of AwsServiceConnectTestTrafficHeaderMatchRules from a dict
aws_service_connect_test_traffic_header_match_rules_from_dict = AwsServiceConnectTestTrafficHeaderMatchRules.from_dict(aws_service_connect_test_traffic_header_match_rules_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


