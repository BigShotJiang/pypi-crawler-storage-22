# AwsServiceConnectTestTrafficHeaderRules


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**value** | [**AwsServiceConnectTestTrafficHeaderMatchRules**](AwsServiceConnectTestTrafficHeaderMatchRules.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_connect_test_traffic_header_rules import AwsServiceConnectTestTrafficHeaderRules

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceConnectTestTrafficHeaderRules from a JSON string
aws_service_connect_test_traffic_header_rules_instance = AwsServiceConnectTestTrafficHeaderRules.from_json(json)
# print the JSON string representation of the object
print(AwsServiceConnectTestTrafficHeaderRules.to_json())

# convert the object into a dict
aws_service_connect_test_traffic_header_rules_dict = aws_service_connect_test_traffic_header_rules_instance.to_dict()
# create an instance of AwsServiceConnectTestTrafficHeaderRules from a dict
aws_service_connect_test_traffic_header_rules_from_dict = AwsServiceConnectTestTrafficHeaderRules.from_dict(aws_service_connect_test_traffic_header_rules_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


