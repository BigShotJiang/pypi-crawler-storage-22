# AwsTag


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **str** |  | [optional] 
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_tag import AwsTag

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTag from a JSON string
aws_tag_instance = AwsTag.from_json(json)
# print the JSON string representation of the object
print(AwsTag.to_json())

# convert the object into a dict
aws_tag_dict = aws_tag_instance.to_dict()
# create an instance of AwsTag from a dict
aws_tag_from_dict = AwsTag.from_dict(aws_tag_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


