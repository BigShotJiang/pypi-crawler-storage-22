# AwsTaskDefinitionStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_task_definition_status import AwsTaskDefinitionStatus

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTaskDefinitionStatus from a JSON string
aws_task_definition_status_instance = AwsTaskDefinitionStatus.from_json(json)
# print the JSON string representation of the object
print(AwsTaskDefinitionStatus.to_json())

# convert the object into a dict
aws_task_definition_status_dict = aws_task_definition_status_instance.to_dict()
# create an instance of AwsTaskDefinitionStatus from a dict
aws_task_definition_status_from_dict = AwsTaskDefinitionStatus.from_dict(aws_task_definition_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


