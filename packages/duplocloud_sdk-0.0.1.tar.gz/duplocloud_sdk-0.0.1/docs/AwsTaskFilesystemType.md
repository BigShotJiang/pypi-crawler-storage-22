# AwsTaskFilesystemType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_task_filesystem_type import AwsTaskFilesystemType

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTaskFilesystemType from a JSON string
aws_task_filesystem_type_instance = AwsTaskFilesystemType.from_json(json)
# print the JSON string representation of the object
print(AwsTaskFilesystemType.to_json())

# convert the object into a dict
aws_task_filesystem_type_dict = aws_task_filesystem_type_instance.to_dict()
# create an instance of AwsTaskFilesystemType from a dict
aws_task_filesystem_type_from_dict = AwsTaskFilesystemType.from_dict(aws_task_filesystem_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


