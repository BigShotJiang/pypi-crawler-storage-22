# AzureAction

Defines values for Action.

## Enum

* `Allow` (value: `'Allow'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


