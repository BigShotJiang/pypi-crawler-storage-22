# AzureApiManagementConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_api_management_config import AzureApiManagementConfig

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApiManagementConfig from a JSON string
azure_api_management_config_instance = AzureApiManagementConfig.from_json(json)
# print the JSON string representation of the object
print(AzureApiManagementConfig.to_json())

# convert the object into a dict
azure_api_management_config_dict = azure_api_management_config_instance.to_dict()
# create an instance of AzureApiManagementConfig from a dict
azure_api_management_config_from_dict = AzureApiManagementConfig.from_dict(azure_api_management_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


