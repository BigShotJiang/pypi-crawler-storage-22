# AzureApplicationSecurityGroup


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**properties_resource_guid** | **str** |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_application_security_group import AzureApplicationSecurityGroup

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApplicationSecurityGroup from a JSON string
azure_application_security_group_instance = AzureApplicationSecurityGroup.from_json(json)
# print the JSON string representation of the object
print(AzureApplicationSecurityGroup.to_json())

# convert the object into a dict
azure_application_security_group_dict = azure_application_security_group_instance.to_dict()
# create an instance of AzureApplicationSecurityGroup from a dict
azure_application_security_group_from_dict = AzureApplicationSecurityGroup.from_dict(azure_application_security_group_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


