# AzureAzureFileVolume

The properties of the Azure File volume. Azure File shares are mounted as volumes.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**share_name** | **str** | Gets or sets the name of the Azure File share to be mounted as a volume. | [optional] 
**read_only** | **bool** | Gets or sets the flag indicating whether the Azure File shared mounted as a volume is read-only. | [optional] 
**storage_account_name** | **str** | Gets or sets the name of the storage account that contains the Azure File share. | [optional] 
**storage_account_key** | **str** | Gets or sets the storage account access key used to access the Azure File share. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_azure_file_volume import AzureAzureFileVolume

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAzureFileVolume from a JSON string
azure_azure_file_volume_instance = AzureAzureFileVolume.from_json(json)
# print the JSON string representation of the object
print(AzureAzureFileVolume.to_json())

# convert the object into a dict
azure_azure_file_volume_dict = azure_azure_file_volume_instance.to_dict()
# create an instance of AzureAzureFileVolume from a dict
azure_azure_file_volume_from_dict = AzureAzureFileVolume.from_dict(azure_azure_file_volume_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


