# AzureBillingProfile

Specifies the billing related details of a Azure Spot VM or VMSS. <br><br>Minimum api-version: 2019-03-01.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max_price** | **float** | Gets or sets specifies the maximum price you are willing to pay for a Azure Spot VM/VMSS. This price is in US Dollars. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; This price will be compared with the current Azure Spot price for the VM size. Also, the prices are compared at the time of create/update of Azure Spot VM/VMSS and the operation will only succeed if  the maxPrice is greater than the current Azure Spot price. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; The maxPrice will also be used for evicting a Azure Spot VM/VMSS if the current Azure Spot price goes beyond the maxPrice after creation of VM/VMSS. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Possible values are: &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; - Any decimal value greater than zero. Example: 0.01538 &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; -1 – indicates default price to be up-to on-demand. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; You can set the maxPrice to -1 to indicate that the Azure Spot VM/VMSS should not be evicted for price reasons. Also, the default max price is -1 if it is not provided by you. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt;Minimum api-version: 2019-03-01. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_billing_profile import AzureBillingProfile

# TODO update the JSON string below
json = "{}"
# create an instance of AzureBillingProfile from a JSON string
azure_billing_profile_instance = AzureBillingProfile.from_json(json)
# print the JSON string representation of the object
print(AzureBillingProfile.to_json())

# convert the object into a dict
azure_billing_profile_dict = azure_billing_profile_instance.to_dict()
# create an instance of AzureBillingProfile from a dict
azure_billing_profile_from_dict = AzureBillingProfile.from_dict(azure_billing_profile_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


