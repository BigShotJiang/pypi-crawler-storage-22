# AzureBlobEncryptionPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | [**AzureIKey**](AzureIKey.md) |  | [optional] 
**key_resolver** | **object** | Interface for key resolvers. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_blob_encryption_policy import AzureBlobEncryptionPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of AzureBlobEncryptionPolicy from a JSON string
azure_blob_encryption_policy_instance = AzureBlobEncryptionPolicy.from_json(json)
# print the JSON string representation of the object
print(AzureBlobEncryptionPolicy.to_json())

# convert the object into a dict
azure_blob_encryption_policy_dict = azure_blob_encryption_policy_instance.to_dict()
# create an instance of AzureBlobEncryptionPolicy from a dict
azure_blob_encryption_policy_from_dict = AzureBlobEncryptionPolicy.from_dict(azure_blob_encryption_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


