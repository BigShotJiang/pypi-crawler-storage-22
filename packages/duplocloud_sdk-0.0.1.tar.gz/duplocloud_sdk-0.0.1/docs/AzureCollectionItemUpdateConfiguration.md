# AzureCollectionItemUpdateConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**azure_virtual_machines** | **List[str]** |  | [optional] 
**duration** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_collection_item_update_configuration import AzureCollectionItemUpdateConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzureCollectionItemUpdateConfiguration from a JSON string
azure_collection_item_update_configuration_instance = AzureCollectionItemUpdateConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzureCollectionItemUpdateConfiguration.to_json())

# convert the object into a dict
azure_collection_item_update_configuration_dict = azure_collection_item_update_configuration_instance.to_dict()
# create an instance of AzureCollectionItemUpdateConfiguration from a dict
azure_collection_item_update_configuration_from_dict = AzureCollectionItemUpdateConfiguration.from_dict(azure_collection_item_update_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


