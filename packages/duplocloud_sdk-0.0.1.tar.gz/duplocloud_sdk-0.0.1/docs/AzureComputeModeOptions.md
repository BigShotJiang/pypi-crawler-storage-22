# AzureComputeModeOptions



## Enum

* `Shared` (value: `'Shared'`)

* `Dedicated` (value: `'Dedicated'`)

* `Dynamic` (value: `'Dynamic'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


