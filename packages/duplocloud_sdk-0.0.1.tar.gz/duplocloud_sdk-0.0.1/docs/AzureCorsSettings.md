# AzureCorsSettings


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allowed_origins** | **List[str]** |  | [optional] 
**support_credentials** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_cors_settings import AzureCorsSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzureCorsSettings from a JSON string
azure_cors_settings_instance = AzureCorsSettings.from_json(json)
# print the JSON string representation of the object
print(AzureCorsSettings.to_json())

# convert the object into a dict
azure_cors_settings_dict = azure_cors_settings_instance.to_dict()
# create an instance of AzureCorsSettings from a dict
azure_cors_settings_from_dict = AzureCorsSettings.from_dict(azure_cors_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


