# AzureDatabase2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets fully qualified resource ID for the resource. Ex - /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/{resourceProviderNamespace}/{resourceType}/{resourceName} | [optional] 
**name** | **str** | Gets the name of the resource | [optional] 
**type** | **str** | Gets the type of the resource. E.g. \&quot;Microsoft.Compute/virtualMachines\&quot; or \&quot;Microsoft.Storage/storageAccounts\&quot; | [optional] 
**properties_charset** | **str** | Gets or sets the charset of the database. | [optional] 
**properties_collation** | **str** | Gets or sets the collation of the database. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_database2 import AzureDatabase2

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDatabase2 from a JSON string
azure_database2_instance = AzureDatabase2.from_json(json)
# print the JSON string representation of the object
print(AzureDatabase2.to_json())

# convert the object into a dict
azure_database2_dict = azure_database2_instance.to_dict()
# create an instance of AzureDatabase2 from a dict
azure_database2_from_dict = AzureDatabase2.from_dict(azure_database2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


