# AzureElasticPoolPerDatabaseMaxPerformanceLevelCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limit** | **float** |  | [optional] 
**unit** | **str** |  | [optional] 
**supported_per_database_min_performance_levels** | [**List[AzureElasticPoolPerDatabaseMinPerformanceLevelCapability]**](AzureElasticPoolPerDatabaseMinPerformanceLevelCapability.md) |  | [optional] 
**status** | [**AzureCapabilityStatus**](AzureCapabilityStatus.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_elastic_pool_per_database_max_performance_level_capability import AzureElasticPoolPerDatabaseMaxPerformanceLevelCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureElasticPoolPerDatabaseMaxPerformanceLevelCapability from a JSON string
azure_elastic_pool_per_database_max_performance_level_capability_instance = AzureElasticPoolPerDatabaseMaxPerformanceLevelCapability.from_json(json)
# print the JSON string representation of the object
print(AzureElasticPoolPerDatabaseMaxPerformanceLevelCapability.to_json())

# convert the object into a dict
azure_elastic_pool_per_database_max_performance_level_capability_dict = azure_elastic_pool_per_database_max_performance_level_capability_instance.to_dict()
# create an instance of AzureElasticPoolPerDatabaseMaxPerformanceLevelCapability from a dict
azure_elastic_pool_per_database_max_performance_level_capability_from_dict = AzureElasticPoolPerDatabaseMaxPerformanceLevelCapability.from_dict(azure_elastic_pool_per_database_max_performance_level_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


