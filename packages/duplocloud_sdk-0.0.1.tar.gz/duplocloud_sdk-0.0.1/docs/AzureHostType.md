# AzureHostType



## Enum

* `Standard` (value: `'Standard'`)

* `Repository` (value: `'Repository'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


