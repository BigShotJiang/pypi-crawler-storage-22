# AzureIaaSVMProtectionPolicySimple


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**properties** | **object** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_iaa_svm_protection_policy_simple import AzureIaaSVMProtectionPolicySimple

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIaaSVMProtectionPolicySimple from a JSON string
azure_iaa_svm_protection_policy_simple_instance = AzureIaaSVMProtectionPolicySimple.from_json(json)
# print the JSON string representation of the object
print(AzureIaaSVMProtectionPolicySimple.to_json())

# convert the object into a dict
azure_iaa_svm_protection_policy_simple_dict = azure_iaa_svm_protection_policy_simple_instance.to_dict()
# create an instance of AzureIaaSVMProtectionPolicySimple from a dict
azure_iaa_svm_protection_policy_simple_from_dict = AzureIaaSVMProtectionPolicySimple.from_dict(azure_iaa_svm_protection_policy_simple_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


