# AzureIpSecurityRestriction


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ip_address** | **str** |  | [optional] 
**subnet_mask** | **str** |  | [optional] 
**vnet_subnet_resource_id** | **str** |  | [optional] 
**vnet_traffic_tag** | **int** |  | [optional] 
**subnet_traffic_tag** | **int** |  | [optional] 
**action** | **str** |  | [optional] 
**tag** | [**AzureIpFilterTag**](AzureIpFilterTag.md) |  | [optional] 
**priority** | **int** |  | [optional] 
**name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_ip_security_restriction import AzureIpSecurityRestriction

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIpSecurityRestriction from a JSON string
azure_ip_security_restriction_instance = AzureIpSecurityRestriction.from_json(json)
# print the JSON string representation of the object
print(AzureIpSecurityRestriction.to_json())

# convert the object into a dict
azure_ip_security_restriction_dict = azure_ip_security_restriction_instance.to_dict()
# create an instance of AzureIpSecurityRestriction from a dict
azure_ip_security_restriction_from_dict = AzureIpSecurityRestriction.from_dict(azure_ip_security_restriction_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


