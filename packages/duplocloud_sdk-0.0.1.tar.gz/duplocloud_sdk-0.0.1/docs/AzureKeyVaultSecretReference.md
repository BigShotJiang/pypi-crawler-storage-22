# AzureKeyVaultSecretReference

Describes a reference to Key Vault Secret

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**secret_url** | **str** | Gets or sets the URL referencing a secret in a Key Vault. | [optional] 
**source_vault** | [**AzureSubResource2**](AzureSubResource2.md) | Gets or sets the relative URL of the Key Vault containing the secret. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_key_vault_secret_reference import AzureKeyVaultSecretReference

# TODO update the JSON string below
json = "{}"
# create an instance of AzureKeyVaultSecretReference from a JSON string
azure_key_vault_secret_reference_instance = AzureKeyVaultSecretReference.from_json(json)
# print the JSON string representation of the object
print(AzureKeyVaultSecretReference.to_json())

# convert the object into a dict
azure_key_vault_secret_reference_dict = azure_key_vault_secret_reference_instance.to_dict()
# create an instance of AzureKeyVaultSecretReference from a dict
azure_key_vault_secret_reference_from_dict = AzureKeyVaultSecretReference.from_dict(azure_key_vault_secret_reference_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


