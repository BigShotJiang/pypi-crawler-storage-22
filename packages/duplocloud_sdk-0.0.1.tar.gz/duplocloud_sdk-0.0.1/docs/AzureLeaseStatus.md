# AzureLeaseStatus



## Enum

* `Unspecified` (value: `0`)

* `Locked` (value: `1`)

* `Unlocked` (value: `2`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


