# AzureLicenseTypeCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**status** | [**AzureCapabilityStatus**](AzureCapabilityStatus.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_license_type_capability import AzureLicenseTypeCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureLicenseTypeCapability from a JSON string
azure_license_type_capability_instance = AzureLicenseTypeCapability.from_json(json)
# print the JSON string representation of the object
print(AzureLicenseTypeCapability.to_json())

# convert the object into a dict
azure_license_type_capability_dict = azure_license_type_capability_instance.to_dict()
# create an instance of AzureLicenseTypeCapability from a dict
azure_license_type_capability_from_dict = AzureLicenseTypeCapability.from_dict(azure_license_type_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


