# AzureLogSizeCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limit** | **int** |  | [optional] 
**unit** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_log_size_capability import AzureLogSizeCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureLogSizeCapability from a JSON string
azure_log_size_capability_instance = AzureLogSizeCapability.from_json(json)
# print the JSON string representation of the object
print(AzureLogSizeCapability.to_json())

# convert the object into a dict
azure_log_size_capability_dict = azure_log_size_capability_instance.to_dict()
# create an instance of AzureLogSizeCapability from a dict
azure_log_size_capability_from_dict = AzureLogSizeCapability.from_dict(azure_log_size_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


