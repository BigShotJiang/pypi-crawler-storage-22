# AzureManagedInstanceEditionCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**supported_families** | [**List[AzureManagedInstanceFamilyCapability]**](AzureManagedInstanceFamilyCapability.md) |  | [optional] 
**status** | [**AzureCapabilityStatus**](AzureCapabilityStatus.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_managed_instance_edition_capability import AzureManagedInstanceEditionCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureManagedInstanceEditionCapability from a JSON string
azure_managed_instance_edition_capability_instance = AzureManagedInstanceEditionCapability.from_json(json)
# print the JSON string representation of the object
print(AzureManagedInstanceEditionCapability.to_json())

# convert the object into a dict
azure_managed_instance_edition_capability_dict = azure_managed_instance_edition_capability_instance.to_dict()
# create an instance of AzureManagedInstanceEditionCapability from a dict
azure_managed_instance_edition_capability_from_dict = AzureManagedInstanceEditionCapability.from_dict(azure_managed_instance_edition_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


