# AzureManagedInstanceVcoresCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**value** | **int** |  | [optional] 
**status** | [**AzureCapabilityStatus**](AzureCapabilityStatus.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_managed_instance_vcores_capability import AzureManagedInstanceVcoresCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureManagedInstanceVcoresCapability from a JSON string
azure_managed_instance_vcores_capability_instance = AzureManagedInstanceVcoresCapability.from_json(json)
# print the JSON string representation of the object
print(AzureManagedInstanceVcoresCapability.to_json())

# convert the object into a dict
azure_managed_instance_vcores_capability_dict = azure_managed_instance_vcores_capability_instance.to_dict()
# create an instance of AzureManagedInstanceVcoresCapability from a dict
azure_managed_instance_vcores_capability_from_dict = AzureManagedInstanceVcoresCapability.from_dict(azure_managed_instance_vcores_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


