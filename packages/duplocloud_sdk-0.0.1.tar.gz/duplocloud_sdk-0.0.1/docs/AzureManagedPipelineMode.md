# AzureManagedPipelineMode



## Enum

* `Integrated` (value: `'Integrated'`)

* `Classic` (value: `'Classic'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


