# AzureMaxSizeRangeCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min_value** | [**AzureMaxSizeCapability**](AzureMaxSizeCapability.md) |  | [optional] 
**max_value** | [**AzureMaxSizeCapability**](AzureMaxSizeCapability.md) |  | [optional] 
**scale_size** | [**AzureMaxSizeCapability**](AzureMaxSizeCapability.md) |  | [optional] 
**log_size** | [**AzureLogSizeCapability**](AzureLogSizeCapability.md) |  | [optional] 
**status** | [**AzureCapabilityStatus**](AzureCapabilityStatus.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_max_size_range_capability import AzureMaxSizeRangeCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureMaxSizeRangeCapability from a JSON string
azure_max_size_range_capability_instance = AzureMaxSizeRangeCapability.from_json(json)
# print the JSON string representation of the object
print(AzureMaxSizeRangeCapability.to_json())

# convert the object into a dict
azure_max_size_range_capability_dict = azure_max_size_range_capability_instance.to_dict()
# create an instance of AzureMaxSizeRangeCapability from a dict
azure_max_size_range_capability_from_dict = AzureMaxSizeRangeCapability.from_dict(azure_max_size_range_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


