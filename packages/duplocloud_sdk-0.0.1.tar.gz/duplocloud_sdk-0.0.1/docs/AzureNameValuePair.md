# AzureNameValuePair


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_name_value_pair import AzureNameValuePair

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNameValuePair from a JSON string
azure_name_value_pair_instance = AzureNameValuePair.from_json(json)
# print the JSON string representation of the object
print(AzureNameValuePair.to_json())

# convert the object into a dict
azure_name_value_pair_dict = azure_name_value_pair_instance.to_dict()
# create an instance of AzureNameValuePair from a dict
azure_name_value_pair_from_dict = AzureNameValuePair.from_dict(azure_name_value_pair_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


