# AzureNatGatewaySku


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_nat_gateway_sku import AzureNatGatewaySku

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNatGatewaySku from a JSON string
azure_nat_gateway_sku_instance = AzureNatGatewaySku.from_json(json)
# print the JSON string representation of the object
print(AzureNatGatewaySku.to_json())

# convert the object into a dict
azure_nat_gateway_sku_dict = azure_nat_gateway_sku_instance.to_dict()
# create an instance of AzureNatGatewaySku from a dict
azure_nat_gateway_sku_from_dict = AzureNatGatewaySku.from_dict(azure_nat_gateway_sku_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


