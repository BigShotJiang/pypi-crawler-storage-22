# AzureNetworkSecurityGroup


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**properties_flush_connection** | **bool** |  | [optional] 
**properties_security_rules** | [**List[AzureSecurityRule]**](AzureSecurityRule.md) |  | [optional] 
**properties_default_security_rules** | [**List[AzureSecurityRule]**](AzureSecurityRule.md) |  | [optional] 
**properties_network_interfaces** | [**List[AzureNetworkInterface]**](AzureNetworkInterface.md) |  | [optional] 
**properties_subnets** | [**List[AzureSubnet]**](AzureSubnet.md) |  | [optional] 
**properties_flow_logs** | [**List[AzureFlowLog]**](AzureFlowLog.md) |  | [optional] 
**properties_resource_guid** | **str** |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_security_group import AzureNetworkSecurityGroup

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkSecurityGroup from a JSON string
azure_network_security_group_instance = AzureNetworkSecurityGroup.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkSecurityGroup.to_json())

# convert the object into a dict
azure_network_security_group_dict = azure_network_security_group_instance.to_dict()
# create an instance of AzureNetworkSecurityGroup from a dict
azure_network_security_group_from_dict = AzureNetworkSecurityGroup.from_dict(azure_network_security_group_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


