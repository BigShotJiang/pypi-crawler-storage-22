# AzureOperatingSystemTypes

Defines values for OperatingSystemTypes.

## Enum

* `Windows` (value: `'Windows'`)

* `Linux` (value: `'Linux'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


