# AzurePrivateEndpoint3

The Private Endpoint resource.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets the ARM identifier for Private Endpoint | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint3 import AzurePrivateEndpoint3

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpoint3 from a JSON string
azure_private_endpoint3_instance = AzurePrivateEndpoint3.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpoint3.to_json())

# convert the object into a dict
azure_private_endpoint3_dict = azure_private_endpoint3_instance.to_dict()
# create an instance of AzurePrivateEndpoint3 from a dict
azure_private_endpoint3_from_dict = AzurePrivateEndpoint3.from_dict(azure_private_endpoint3_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


