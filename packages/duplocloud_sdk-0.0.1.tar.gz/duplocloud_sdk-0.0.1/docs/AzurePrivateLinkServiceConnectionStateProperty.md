# AzurePrivateLinkServiceConnectionStateProperty


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**actions_required** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_link_service_connection_state_property import AzurePrivateLinkServiceConnectionStateProperty

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateLinkServiceConnectionStateProperty from a JSON string
azure_private_link_service_connection_state_property_instance = AzurePrivateLinkServiceConnectionStateProperty.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateLinkServiceConnectionStateProperty.to_json())

# convert the object into a dict
azure_private_link_service_connection_state_property_dict = azure_private_link_service_connection_state_property_instance.to_dict()
# create an instance of AzurePrivateLinkServiceConnectionStateProperty from a dict
azure_private_link_service_connection_state_property_from_dict = AzurePrivateLinkServiceConnectionStateProperty.from_dict(azure_private_link_service_connection_state_property_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


