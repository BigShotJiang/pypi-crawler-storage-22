# AzurePrivateLinkServicePropertiesVisibility


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptions** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_link_service_properties_visibility import AzurePrivateLinkServicePropertiesVisibility

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateLinkServicePropertiesVisibility from a JSON string
azure_private_link_service_properties_visibility_instance = AzurePrivateLinkServicePropertiesVisibility.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateLinkServicePropertiesVisibility.to_json())

# convert the object into a dict
azure_private_link_service_properties_visibility_dict = azure_private_link_service_properties_visibility_instance.to_dict()
# create an instance of AzurePrivateLinkServicePropertiesVisibility from a dict
azure_private_link_service_properties_visibility_from_dict = AzurePrivateLinkServicePropertiesVisibility.from_dict(azure_private_link_service_properties_visibility_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


