# AzureProtectionPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**protected_items_count** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_protection_policy import AzureProtectionPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of AzureProtectionPolicy from a JSON string
azure_protection_policy_instance = AzureProtectionPolicy.from_json(json)
# print the JSON string representation of the object
print(AzureProtectionPolicy.to_json())

# convert the object into a dict
azure_protection_policy_dict = azure_protection_policy_instance.to_dict()
# create an instance of AzureProtectionPolicy from a dict
azure_protection_policy_from_dict = AzureProtectionPolicy.from_dict(azure_protection_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


