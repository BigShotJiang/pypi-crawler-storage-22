# AzureProtocolTypes

Defines values for ProtocolTypes.

## Enum

* `Http` (value: `'Http'`)

* `Https` (value: `'Https'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


