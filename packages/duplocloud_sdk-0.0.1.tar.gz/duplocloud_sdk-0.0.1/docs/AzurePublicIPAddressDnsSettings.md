# AzurePublicIPAddressDnsSettings


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domain_name_label** | **str** |  | [optional] 
**fqdn** | **str** |  | [optional] 
**reverse_fqdn** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_public_ip_address_dns_settings import AzurePublicIPAddressDnsSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePublicIPAddressDnsSettings from a JSON string
azure_public_ip_address_dns_settings_instance = AzurePublicIPAddressDnsSettings.from_json(json)
# print the JSON string representation of the object
print(AzurePublicIPAddressDnsSettings.to_json())

# convert the object into a dict
azure_public_ip_address_dns_settings_dict = azure_public_ip_address_dns_settings_instance.to_dict()
# create an instance of AzurePublicIPAddressDnsSettings from a dict
azure_public_ip_address_dns_settings_from_dict = AzurePublicIPAddressDnsSettings.from_dict(azure_public_ip_address_dns_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


