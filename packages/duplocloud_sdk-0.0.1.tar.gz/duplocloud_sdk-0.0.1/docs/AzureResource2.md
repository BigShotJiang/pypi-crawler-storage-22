# AzureResource2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource2 import AzureResource2

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResource2 from a JSON string
azure_resource2_instance = AzureResource2.from_json(json)
# print the JSON string representation of the object
print(AzureResource2.to_json())

# convert the object into a dict
azure_resource2_dict = azure_resource2_instance.to_dict()
# create an instance of AzureResource2 from a dict
azure_resource2_from_dict = AzureResource2.from_dict(azure_resource2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


