# AzureResource7


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource7 import AzureResource7

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResource7 from a JSON string
azure_resource7_instance = AzureResource7.from_json(json)
# print the JSON string representation of the object
print(AzureResource7.to_json())

# convert the object into a dict
azure_resource7_dict = azure_resource7_instance.to_dict()
# create an instance of AzureResource7 from a dict
azure_resource7_from_dict = AzureResource7.from_dict(azure_resource7_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


