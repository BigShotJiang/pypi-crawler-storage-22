# AzureResourceIdentity

Azure Active Directory identity configuration for a resource.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**principal_id** | **str** | Gets the Azure Active Directory principal id. | [optional] 
**type** | **str** | Gets or sets the identity type. Set this to &#39;SystemAssigned&#39; in order to automatically create and assign an Azure Active Directory principal for the resource. Possible values include: &#39;SystemAssigned&#39; | [optional] 
**tenant_id** | **str** | Gets the Azure Active Directory tenant id. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource_identity import AzureResourceIdentity

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResourceIdentity from a JSON string
azure_resource_identity_instance = AzureResourceIdentity.from_json(json)
# print the JSON string representation of the object
print(AzureResourceIdentity.to_json())

# convert the object into a dict
azure_resource_identity_dict = azure_resource_identity_instance.to_dict()
# create an instance of AzureResourceIdentity from a dict
azure_resource_identity_from_dict = AzureResourceIdentity.from_dict(azure_resource_identity_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


