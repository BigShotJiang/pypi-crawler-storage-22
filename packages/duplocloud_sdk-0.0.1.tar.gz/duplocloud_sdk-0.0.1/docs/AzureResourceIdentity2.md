# AzureResourceIdentity2

Azure Active Directory identity configuration for a resource.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**principal_id** | **str** | Gets the Azure Active Directory principal id. | [optional] 
**type** | **str** | Gets or sets the identity type. Set this to &#39;SystemAssigned&#39; in order to automatically create and assign an Azure Active Directory principal for the resource. Possible values include: &#39;SystemAssigned&#39; | [optional] 
**tenant_id** | **str** | Gets the Azure Active Directory tenant id. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource_identity2 import AzureResourceIdentity2

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResourceIdentity2 from a JSON string
azure_resource_identity2_instance = AzureResourceIdentity2.from_json(json)
# print the JSON string representation of the object
print(AzureResourceIdentity2.to_json())

# convert the object into a dict
azure_resource_identity2_dict = azure_resource_identity2_instance.to_dict()
# create an instance of AzureResourceIdentity2 from a dict
azure_resource_identity2_from_dict = AzureResourceIdentity2.from_dict(azure_resource_identity2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


