# AzureResourceIdentity3


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**principal_id** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**tenant_id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource_identity3 import AzureResourceIdentity3

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResourceIdentity3 from a JSON string
azure_resource_identity3_instance = AzureResourceIdentity3.from_json(json)
# print the JSON string representation of the object
print(AzureResourceIdentity3.to_json())

# convert the object into a dict
azure_resource_identity3_dict = azure_resource_identity3_instance.to_dict()
# create an instance of AzureResourceIdentity3 from a dict
azure_resource_identity3_from_dict = AzureResourceIdentity3.from_dict(azure_resource_identity3_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


