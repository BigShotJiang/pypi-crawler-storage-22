# AzureResourceIdentityType2

Defines values for ResourceIdentityType.

## Enum

* `SystemAssigned` (value: `'SystemAssigned'`)

* `UserAssigned` (value: `'UserAssigned'`)

* `SystemAssignedUserAssigned` (value: `'SystemAssigned, UserAssigned'`)

* `NONE_` (value: `'None'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


