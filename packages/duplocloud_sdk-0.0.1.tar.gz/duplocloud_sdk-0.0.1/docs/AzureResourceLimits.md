# AzureResourceLimits

The resource limits.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memory_in_gb** | **float** | Gets or sets the memory limit in GB of this container instance. | [optional] 
**cpu** | **float** | Gets or sets the CPU limit of this container instance. | [optional] 
**gpu** | [**AzureGpuResource**](AzureGpuResource.md) | Gets or sets the GPU limit of this container instance. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource_limits import AzureResourceLimits

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResourceLimits from a JSON string
azure_resource_limits_instance = AzureResourceLimits.from_json(json)
# print the JSON string representation of the object
print(AzureResourceLimits.to_json())

# convert the object into a dict
azure_resource_limits_dict = azure_resource_limits_instance.to_dict()
# create an instance of AzureResourceLimits from a dict
azure_resource_limits_from_dict = AzureResourceLimits.from_dict(azure_resource_limits_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


