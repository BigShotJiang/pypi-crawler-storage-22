# AzureResourceNavigationLink


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_linked_resource_type** | **str** |  | [optional] 
**properties_link** | **str** |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource_navigation_link import AzureResourceNavigationLink

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResourceNavigationLink from a JSON string
azure_resource_navigation_link_instance = AzureResourceNavigationLink.from_json(json)
# print the JSON string representation of the object
print(AzureResourceNavigationLink.to_json())

# convert the object into a dict
azure_resource_navigation_link_dict = azure_resource_navigation_link_instance.to_dict()
# create an instance of AzureResourceNavigationLink from a dict
azure_resource_navigation_link_from_dict = AzureResourceNavigationLink.from_dict(azure_resource_navigation_link_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


