from .core import Scanner

__version__ = "1.0.0"

def scan_text(text):
    engine = Scanner()
    return engine.scan_code(text) # Use scan_code if that's the method name