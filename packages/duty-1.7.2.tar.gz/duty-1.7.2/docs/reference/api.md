---
title: API reference
hide:
- navigation
---

# ::: duty
    options:
        show_submodules: true
