"""Configuration for the pytest test suite."""
