from duty import duty


@duty
def hello(ctx):
    pass
