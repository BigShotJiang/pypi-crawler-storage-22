from duty import duty


@duty
def tong(ctx):
    """Tong..."""


@duty
def deum(ctx):
    """DEUM!"""
