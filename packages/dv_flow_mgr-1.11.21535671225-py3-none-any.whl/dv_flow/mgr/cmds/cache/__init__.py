# Cache management commands
