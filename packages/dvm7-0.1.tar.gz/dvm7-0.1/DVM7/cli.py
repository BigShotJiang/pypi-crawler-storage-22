import sys
import time
from .proxy import start_bot


def run():
    if "--START" in sys.argv:
        print("Server is starting, please wait...")
        print("Developer: DV M7")
        print("* Connecting vpn / proxy")
        time.sleep(2)

        start_bot()   # ← تشغيل البروكسي الحقيقي

    else:
        print("Use: DV --START")
