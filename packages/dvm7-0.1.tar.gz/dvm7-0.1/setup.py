from setuptools import setup, find_packages

setup(
    name="DVM7",
    version="0.1",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        "console_scripts": [
            "DV=DVM7.cli:run",
        ],
    },
    author="DV M7",
    description="SOCKS5 Proxy Tool",
    license="MIT",
)
