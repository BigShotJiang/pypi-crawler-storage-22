import runpy
import os

SITE_PACKAGES = "/data/data/com.termux/files/usr/lib/python3.12/site-packages"

def find_dv_pyc(start_dir):
    for root, dirs, files in os.walk(start_dir):
        if "DV.pyc" in files:
            return os.path.join(root, "DV.pyc")
    return None

def start():
    print("✅ DV PROXY STARTED")

    # 1️⃣ نفس مجلد runner.py (أفضل حالة)
    base = os.path.dirname(__file__)
    local_pyc = os.path.join(base, "DV.pyc")

    if os.path.exists(local_pyc):
        runpy.run_path(local_pyc, run_name="__main__")
        return

    # 2️⃣ البحث داخل site-packages فقط
    print("🔍 Searching in site-packages...")
    pyc = find_dv_pyc(SITE_PACKAGES)

    if pyc:
        print(f"✅ Found DV.pyc at: {pyc}")
        runpy.run_path(pyc, run_name="__main__")
        return

    raise FileNotFoundError("❌ DV.pyc not found in runner directory or site-packages")
