from setuptools import setup, find_packages

setup(
    name="DVM7",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "flask",
        "requests"
    ],
    entry_points={
        "console_scripts": [
            "DV--START-PROXY=dvm7.runner:start"
        ]
    }
)
