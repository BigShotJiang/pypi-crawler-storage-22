from .get_resolve import GetResolve

__version__ = "0.2.0"
__release_date__ = "2026-01-30"
__author__ = "LoveinYuu"
