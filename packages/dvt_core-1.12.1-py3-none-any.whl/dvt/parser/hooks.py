import os
from dataclasses import dataclass
from typing import Iterable, Iterator, List, Tuple, Union

from dvt.config.project import get_project_yml_path
from dvt.context.context_config import ContextConfig
from dvt.contracts.files import FilePath
from dvt.contracts.graph.nodes import HookNode
from dvt.node_types import NodeType, RunHookType
from dvt.parser.base import SimpleParser
from dvt.parser.search import FileBlock
from dvt.utils import get_pseudo_hook_path
from dbt_common.exceptions import DbtInternalError


@dataclass
class HookBlock(FileBlock):
    project: str
    value: str
    index: int
    hook_type: RunHookType

    @property
    def contents(self):
        return self.value

    @property
    def name(self):
        return "{}-{!s}-{!s}".format(self.project, self.hook_type, self.index)


class HookSearcher(Iterable[HookBlock]):
    def __init__(self, project, source_file, hook_type) -> None:
        self.project = project
        self.source_file = source_file
        self.hook_type = hook_type

    def _hook_list(self, hooks: Union[str, List[str], Tuple[str, ...]]) -> List[str]:
        if isinstance(hooks, tuple):
            hooks = list(hooks)
        elif not isinstance(hooks, list):
            hooks = [hooks]
        return hooks

    def get_hook_defs(self) -> List[str]:
        if self.hook_type == RunHookType.Start:
            hooks = self.project.on_run_start
        elif self.hook_type == RunHookType.End:
            hooks = self.project.on_run_end
        else:
            raise DbtInternalError(
                'hook_type must be one of "{}" or "{}" (got {})'.format(
                    RunHookType.Start, RunHookType.End, self.hook_type
                )
            )
        return self._hook_list(hooks)

    def __iter__(self) -> Iterator[HookBlock]:
        hooks = self.get_hook_defs()
        for index, hook in enumerate(hooks):
            yield HookBlock(
                file=self.source_file,
                project=self.project.project_name,
                value=hook,
                index=index,
                hook_type=self.hook_type,
            )


class HookParser(SimpleParser[HookBlock, HookNode]):

    # Hooks are only in the project yml file (dbt_project.yml or dvt_project.yml for adapter packages)
    def get_path(self) -> FilePath:
        # There ought to be an existing file object for this, but
        # until that is implemented use a dummy modification time
        project_yml_full = get_project_yml_path(self.project.project_root)
        relative_path = os.path.basename(project_yml_full)
        path = FilePath(
            project_root=self.project.project_root,
            searched_path=".",
            relative_path=relative_path,
            modification_time=0.0,
        )
        return path

    def parse_from_dict(self, dct, validate=True) -> HookNode:
        if validate:
            HookNode.validate(dct)
        return HookNode.from_dict(dct)

    @classmethod
    def get_compiled_path(cls, block: HookBlock):
        return get_pseudo_hook_path(block.name)

    def _create_parsetime_node(
        self,
        block: HookBlock,
        path: str,
        config: ContextConfig,
        fqn: List[str],
        name=None,
        **kwargs,
    ) -> HookNode:

        return super()._create_parsetime_node(
            block=block,
            path=path,
            config=config,
            fqn=fqn,
            index=block.index,
            name=name,
            tags=[str(block.hook_type)],
        )

    @property
    def resource_type(self) -> NodeType:
        return NodeType.Operation

    def parse_file(self, block: FileBlock) -> None:
        for hook_type in RunHookType:
            for hook in HookSearcher(self.project, block.file, hook_type):
                self.parse_node(hook)
