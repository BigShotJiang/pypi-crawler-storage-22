# src/dworshak_prompt/dworshak_prompt.py
from __future__ import annotations
from typing import Any

from .multiplexer import ask as _ask
from .obtain import obtain as _obtain

class DworshakPrompt:
    def __init__(
        self,
        *,
        config_path: str | None = None,
        secret_path: str | None = None,
        default_priority=None,
        default_avoid=None,
    ):
        self.config_path = config_path
        self.secret_path = secret_path
        self.default_priority = default_priority
        self.default_avoid = default_avoid

    def ask(self, *args, **kwargs):
        return _ask(
            *args,
            priority=kwargs.get("priority", self.default_priority),
            avoid=kwargs.get("avoid", self.default_avoid),
            **kwargs,
        )

    def obtain(
        self,
        *,
        service: str,
        item: str,
        store: str = "config",
        overwrite: bool = False,
        forget: bool = False,
        **prompt_kwargs,
    ) -> str | None:
        return _obtain(
            prompt=self,
            config_path=self.config_path,
            secret_path=self.secret_path,
            service=service,
            item=item,
            store=store,
            overwrite=overwrite,
            forget=forget,
            **prompt_kwargs,
        )


def dworshak_ask(
    message: str = "Enter value",
    suggestion: str | None = None,
    default: Any | None = None,
    **kwargs: Any
) -> str | None:
    """
    Convenience function to prompt the user for input using the Dworshak Multiplexer.
    Automatically handles fallback between Console, GUI, and Web modes.
    """
    return DworshakPrompt().ask(
        message=message,
        suggestion=suggestion,
        default=default,
        **kwargs
    )

def main():
    DworshakPrompt().ask(
        "What is your name?",
        suggestion="George",
        debug=True,
    )

