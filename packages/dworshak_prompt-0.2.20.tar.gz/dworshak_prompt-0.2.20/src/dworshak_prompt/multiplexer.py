# src/dworshak_prompt/multiplexer.py
from __future__ import annotations
import pyhabitat as ph
from enum import Enum
from typing import Set, Any
import threading
import traceback
import sys
import logging

try:
    from .console_prompt import console_get_input
except ImportError:
    from .console_prompt_stdlib import console_get_input_stdlib as console_get_input
    
if ph.tkinter_is_available():
    from .gui_prompt import gui_get_input
else:
    gui_get_input = None
from .web_prompt import browser_get_input
from .keyboard_interrupt import PromptCancelled
from .server import stop_prompt_server
from .prompt_manager import PromptManager
    
# Setup logger
logger = logging.getLogger("dworshak_prompt")
# Default to INFO to hide diagnostics; change to DEBUG to see them
#logger.setLevel(logging.INFO) 
logger.setLevel(logging.WARNING) 
if not logger.handlers:
    _handler = logging.StreamHandler(sys.stdout)
    _handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(_handler)


class PromptMode(Enum):
    CONSOLE = "console"
    GUI = "gui"
    WEB = "web"

class DworshakPrompt: 
    def __init__(self,
        config_path: str | None = None,
        secret_path: str | None = None,
        default_priority: list[PromptMode] | None = None,
        default_avoid: set[PromptMode] | None =None,
    ):
        self.config_path = config_path
        self.secret_path = secret_path
        self.default_priority = default_priority
        self.default_avoid = default_avoid

    def ask(
        self,
        message: str = "Enter value",
        suggestion: str | None = None,
        default: Any | None = None,
        hide_input: bool = False,
        priority: list[PromptMode] | None = None,
        avoid: set[PromptMode] | None = None,
        interrupt_event: threading.Event | None = None,
        debug: bool = False,  # Added a flag to toggle at runtime
        timeout: int | float | None = None,
    ) -> str | None:

        if priority is None:
            priority = self.default_priority
        if avoid is None:
            avoid = self.default_avoid

        # Use existing interrupt_event or create a local one for this call
        if interrupt_event is None:
            interrupt_event = threading.Event()

        if debug:
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.WARNING)

        # 1. CI/Headless Detection
        # If we aren't in a TTY and aren't on a system that can spawn a GUI/Web window,
        # return the default immediately to avoid the "Time Bomb."
        if ph.is_likely_ci_or_non_interactive():
            logger.debug("[DIAGNOSTIC] CI/Non-interactive environment. Returning default.")
            return default

        if not ph.interactive_terminal_is_available() and \
        not ph.tkinter_is_available() and \
        not ph.is_browser_available(): # Hypothetical pyhabitat check
            logger.debug("[DIAGNOSTIC] Non-interactive environment detected. Using default.")
            return default

        avoid = avoid or set()
        if ph.on_wsl():
            avoid.add(PromptMode.GUI)

        default_order = [PromptMode.CONSOLE, PromptMode.GUI, PromptMode.WEB]
        if priority:
            # User choice first, followed by everything else as a safety net
            effective_priority = priority + [m for m in default_order if m not in priority]
        else:
            effective_priority = default_order

        if timeout:
            # A background timer to fire the interrupt signal
            timer = threading.Timer(timeout, lambda: interrupt_event.set())
            timer.start()

        for mode in effective_priority:
            if mode in avoid:
                logger.debug(f"[DIAGNOSTIC] Skipping {mode} (avoided)")
                continue

            logger.debug(f"\n[DIAGNOSTIC] === Entering Mode: {mode} ===")
            
            try:
                if mode == PromptMode.CONSOLE:
                    if not ph.interactive_terminal_is_available():
                        logger.debug(f"[DIAGNOSTIC] {mode} skipped: No interactive terminal.")
                        continue
                    
                    val = console_get_input(message = message, suggestion = suggestion, hide_input = hide_input)
                    logger.debug(f"[DIAGNOSTIC] SUCCESS: {mode} returned: {repr(val)}")
                    return val

                elif mode == PromptMode.GUI:
                    if not ph.tkinter_is_available():
                        logger.debug(f"[DIAGNOSTIC] {mode} skipped: Tkinter unavailable.")
                        continue
                        
                    val = gui_get_input(message = message, suggestion = suggestion, hide_input = hide_input)
                    if val is not None:
                        logger.debug(f"[DIAGNOSTIC] SUCCESS: {mode} returned: {repr(val)}")
                        return val
                    
                    logger.debug(f"[DIAGNOSTIC] GUI cancelled. Raising PromptCancelled.")
                    raise PromptCancelled()

                elif mode == PromptMode.WEB:
                    local_manager = PromptManager()
                    try:
                        val = browser_get_input(
                            message, 
                            suggestion, 
                            hide_input, 
                            manager = local_manager, 
                            stop_event = interrupt_event
                            )
                        if val is not None:
                            logger.debug(f"[DIAGNOSTIC] SUCCESS: {mode} returned: {repr(val)}")
                            return val
                        logger.debug(f"[DIAGNOSTIC] WEB returned None. Raising PromptCancelled.")
                        raise PromptCancelled()
                    finally:
                        stop_prompt_server()

            except BaseException as e:
                exc_type = type(e)
                exc_name = exc_type.__name__
                exc_module = exc_type.__module__
                
                logger.debug(f"[DIAGNOSTIC] !!! EXCEPTION TRIGGERED !!!")
                logger.debug(f"[DIAGNOSTIC] Class Name: {exc_name}")
                logger.debug(f"[DIAGNOSTIC] Full Path:  {exc_module}.{exc_name}")
                logger.debug(f"[DIAGNOSTIC] Repr:       {repr(e)}")
                logger.debug(f"[DIAGNOSTIC] Args:       {e.args}")

                stop_signals = {"KeyboardInterrupt", "Abort", "SystemExit", "EOFError", "PromptCancelled"}
                
                if exc_name in stop_signals or isinstance(e, (KeyboardInterrupt, PromptCancelled)):
                    logger.debug(f"[DIAGNOSTIC] >>> MATCHED STOP SIGNAL: {exc_name}. EXITING FUNCTION.")
                    if interrupt_event:
                        interrupt_event.set()
                    return None

                # For technical failures, we log the traceback at DEBUG level
                logger.debug(f"[DIAGNOSTIC] >>> TECHNICAL FAILURE detected. Investigating traceback...")
                if logger.isEnabledFor(logging.DEBUG):
                    traceback.print_exc(file=sys.stdout)
                
                logger.debug(f"[DIAGNOSTIC] Continuing to fallback mode...")
                continue


        logger.debug("[DIAGNOSTIC] All modes exhausted.")
        raise RuntimeError("No input method succeeded.")

def dworshak_ask(
    message: str = "Enter value",
    suggestion: str | None = None,
    default: Any | None = None,
    **kwargs: Any
) -> str | None:
    """
    Convenience function to prompt the user for input using the Dworshak Multiplexer.
    Automatically handles fallback between Console, GUI, and Web modes.
    """
    return DworshakPrompt().ask(
        message=message,
        suggestion=suggestion,
        default=default,
        **kwargs
    )


def main():
    DworshakPrompt().ask(
        "What is your name?",
        suggestion="George",
        debug=True,
    )