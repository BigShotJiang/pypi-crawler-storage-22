import requests
import pandas as pd
from .util import get_response_json_with_check
from ..enums import PenetrateType, WeightType

field_mapping = {
    'date': 'date',
    'assetCategory': 'asset_type',
    'weight': 'weight',
    'marketValue': 'position_market_value'
}


def get_post_investment_product_asset_allocation(client,
                                                 post_investment_product_id,
                                                 start_date=None,
                                                 end_date=None,
                                                 date=None,
                                                 asset_class="交易属性",
                                                 penetrate_type=PenetrateType.NO_PENETRATE,
                                                 level=1,
                                                 weight_types=WeightType.TOTAL_FILTERED,
                                                 asset_sceening=[]):

    if date:
        start_date = date
        end_date = date
    elif not start_date or not end_date:
        raise ValueError("start_date and end_date are required")

    if isinstance(penetrate_type, PenetrateType):
        penetrate_type_value = penetrate_type.name
    elif isinstance(penetrate_type, str):
        if penetrate_type not in PenetrateType._member_names_:
            raise ValueError("不支持的穿透方式")
        penetrate_type_value = penetrate_type
    else:
        penetrate_type_value = PenetrateType.NO_PENETRATE.name

    if isinstance(weight_types, WeightType):
        weight_types_value = weight_types.name
    elif isinstance(weight_types, str):
        if weight_types not in WeightType._member_names_:
            raise ValueError("不支持的权重类型")
        weight_types_value = weight_types
    else:
        weight_types_value = WeightType.TOTAL_FILTERED.name

    url = f"{client.base_url}/lib/portfolio/v1/positionDistribution"
    data = {
        'accountCode': post_investment_product_id,
        'startDate': start_date,
        'endDate': end_date,
        'penetrateWay': penetrate_type_value,
        'level': level,
        'assetCategoryName': asset_class,
        'ratioAssetType': weight_types_value,
        'securityTypes': [security_type.name for security_type in asset_sceening]
    }
    headers = client.get_headers()
    try:
        response = requests.post(url, headers=headers, json=data)
        r = get_response_json_with_check(response)

        rows = []
        for item in r.get('list'):
            row = {}
            for api_field, our_field in field_mapping.items():
                row[our_field] = item.get(api_field, None)
            rows.append(row)

        df = pd.DataFrame(rows)
        return df
    except Exception as e:
        raise e
