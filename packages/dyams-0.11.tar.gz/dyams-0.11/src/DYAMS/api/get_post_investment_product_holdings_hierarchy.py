import requests
from .util import get_response_json_with_check


def get_post_investment_product_holdings_hierarchy(client,
                                                   post_investment_product_id,
                                                   date):

    url = f"{client.base_url}/lib/portfolio/v1/positionHierarchy"
    data = {
        'accountCode': post_investment_product_id,
        'date': date
    }
    headers = client.get_headers()
    try:
        response = requests.post(url, headers=headers, json=data)
        r = get_response_json_with_check(response)

        return r
    except Exception as e:
        raise e
