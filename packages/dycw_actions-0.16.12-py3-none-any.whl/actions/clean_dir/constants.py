from __future__ import annotations

CLEAN_DIR_DOCSTRING = "Clean a directory"
CLEAN_DIR_SUB_CMD = "clean-dir"


__all__ = ["CLEAN_DIR_DOCSTRING", "CLEAN_DIR_SUB_CMD"]
