from __future__ import annotations

PUBLISH_PACKAGE_DOCSTRING = "Build and publish the package"
PUBLISH_PACKAGE_SUB_CMD = "publish-package"


__all__ = ["PUBLISH_PACKAGE_DOCSTRING", "PUBLISH_PACKAGE_SUB_CMD"]
