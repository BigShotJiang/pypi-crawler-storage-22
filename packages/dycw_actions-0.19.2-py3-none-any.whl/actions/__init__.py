from __future__ import annotations

__version__ = "0.19.2"
