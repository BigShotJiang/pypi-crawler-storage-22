from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Self, assert_never

from utilities.constants import SYSTEM, USER, Sentinel, sentinel
from utilities.core import (
    duration_to_seconds,
    normalize_str,
    replace_non_sentinel,
    substitute,
    to_logger,
)
from utilities.subprocess import chmod, chown, tee

from actions.constants import SUDO
from actions.set_up_cron.constants import (
    KILL_AFTER,
    LOGS_KEEP,
    PATH_CONFIGS,
    SCHEDULE,
    TIMEOUT,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from utilities.types import Duration, PathLike, StrStrMapping


_LOGGER = to_logger(__name__)


def set_up_cron(
    job: Job,
    /,
    *jobs: Job,
    cron_name: str | None = None,
    prepend_path: Sequence[PathLike] | None = None,
    env_vars: StrStrMapping | None = None,
    sudo: bool = False,
    logs_keep: int = LOGS_KEEP,
) -> None:
    """Set up a cronjob & logrotate."""
    _LOGGER.info("Setting up 'cron' job(s)...")
    if SYSTEM != "linux":
        msg = f"System must be 'linux'; got {SYSTEM!r}"
        raise TypeError(msg)
    match cron_name, len(jobs):
        case None, 0:
            name_use = job.name
        case None, _:
            msg = "'cron_name' must be given if there are multiple jobs"
            raise ValueError(msg)
        case str() as name_use, _:
            ...
        case never:
            assert_never(never)
    text = _get_crontab(
        job, *jobs, family=name_use, prepend_path=prepend_path, env_vars=env_vars
    )
    _tee_and_perms(Path("/etc/cron.d", name_use), text, sudo=sudo)
    _tee_and_perms(
        Path("/etc/logrotate.d", name_use),
        _get_logrotate(name_use, logs_keep=logs_keep),
        sudo=sudo,
    )
    _LOGGER.info("Finished setting up 'cron' job(s)")


def _get_crontab(
    job: Job,
    /,
    *jobs: Job,
    family: str | None = None,
    prepend_path: Sequence[PathLike] | None = None,
    env_vars: StrStrMapping | None = None,
) -> str:
    all_jobs = [job, *jobs]
    if family is not None:
        all_jobs = [j.replace(family=family) for j in all_jobs]
    text = substitute(
        PATH_CONFIGS / "cron.tmpl",
        PREPEND_PATH=""
        if prepend_path is None
        else "".join(f"{p}:" for p in prepend_path),
        PATH_ENV_VARS_NEW_LINE="" if env_vars is None else "\n",
        ENV_VARS=""
        if env_vars is None
        else "\n".join(f"{k}={v}" for k, v in env_vars.items()),
        JOBS="".join(j.text for j in all_jobs),
    )
    return normalize_str(text)


def _get_logrotate(name: str, /, *, logs_keep: int = LOGS_KEEP) -> str:
    return substitute(PATH_CONFIGS / "logrotate.tmpl", NAME=name, ROTATE=logs_keep)


def _tee_and_perms(path: PathLike, text: str, /, *, sudo: bool = False) -> None:
    tee(path, text, sudo=sudo)
    chown(path, sudo=sudo, owner="root", group="root")
    chmod(path, "u=rw,g=r,o=r", sudo=sudo)


##


@dataclass(order=True, unsafe_hash=True, slots=True)
class Job:
    name: str
    command: str
    schedule: str = field(default=SCHEDULE, kw_only=True)
    user: str = field(default=USER, kw_only=True)
    timeout: Duration = field(default=TIMEOUT, kw_only=True)
    kill_after: Duration = field(default=KILL_AFTER, kw_only=True)
    sudo: bool = field(default=SUDO, kw_only=True)
    args: list[str] | None = field(default=None, kw_only=True)
    family: str | None = field(default=None, kw_only=True)

    @property
    def family_use(self) -> str:
        return self.name if self.family is None else self.family

    def replace(
        self,
        *,
        name: str | Sentinel = sentinel,
        command: str | Sentinel = sentinel,
        schedule: str | Sentinel = sentinel,
        user: str | Sentinel = sentinel,
        timeout: Duration | Sentinel = sentinel,
        kill_after: Duration | Sentinel = sentinel,
        sudo: bool | Sentinel = sentinel,
        args: list[str] | None | Sentinel = sentinel,
        family: str | None | Sentinel = sentinel,
    ) -> Self:
        return replace_non_sentinel(
            self,
            name=name,
            command=command,
            schedule=schedule,
            user=user,
            timeout=timeout,
            kill_after=kill_after,
            sudo=sudo,
            args=args,
            family=family,
        )

    @property
    def text(self) -> str:
        return substitute(
            PATH_CONFIGS / "job.tmpl",
            SCHEDULE=self.schedule,
            USER=self.user,
            NAME=self.name,
            TIMEOUT=round(duration_to_seconds(self.timeout)),
            FAMILY=self.family_use,
            KILL_AFTER=round(duration_to_seconds(self.kill_after)),
            COMMAND=self.command,
            COMMAND_ARGS_SPACE=" "
            if (self.args is not None) and (len(self.args) >= 1)
            else "",
            SUDO="sudo" if self.sudo else "",
            SUDO_TEE_SPACE=" " if self.sudo else "",
            ARGS="" if self.args is None else " ".join(self.args),
        )


__all__ = ["Job", "set_up_cron"]
