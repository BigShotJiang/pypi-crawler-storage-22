from __future__ import annotations

from typing import TYPE_CHECKING

import utilities.click
from click import argument, option
from utilities.click import Str
from utilities.core import is_pytest
from utilities.logging import basic_config

from installer.click import logger_option
from installer.clone.constants import GIT_CLONE_HOST
from installer.clone.lib import git_clone

if TYPE_CHECKING:
    from utilities.types import LoggerLike, PathLike


@argument("key", type=utilities.click.Path(exist="existing file"))
@argument("owner", type=Str())
@argument("repo", type=Str())
@logger_option
@option("--host", type=Str(), default=GIT_CLONE_HOST, help="Repository host")
@option("--port", type=int, default=None, help="Repository port")
@option(
    "--dest",
    type=utilities.click.Path(exist="dir if exists"),
    default=None,
    help="Path to clone to",
)
@option("--branch", type=Str(), default=None, help="Branch to check out")
def git_clone_sub_cmd(
    *,
    key: PathLike,
    owner: str,
    repo: str,
    logger: LoggerLike | None,
    host: str,
    port: int | None,
    dest: PathLike,
    branch: str | None,
) -> None:
    if is_pytest():
        return
    basic_config(obj=logger)
    git_clone(
        key, owner, repo, logger=logger, host=host, port=port, dest=dest, branch=branch
    )


__all__ = ["git_clone_sub_cmd"]
