from __future__ import annotations

GIT_CLONE_HOST = "github.com"


__all__ = ["GIT_CLONE_HOST"]
