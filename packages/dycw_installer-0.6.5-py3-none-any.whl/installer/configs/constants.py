from __future__ import annotations

from pathlib import Path

FILE_SYSTEM_ROOT = Path("/")


__all__ = ["FILE_SYSTEM_ROOT"]
