from __future__ import annotations

from typing import TYPE_CHECKING

from click import command
from utilities.click import CONTEXT_SETTINGS
from utilities.core import is_pytest, set_up_logging, to_logger

from postgres import __version__
from postgres._click import stanza_option, user_option
from postgres._utilities import run_or_as_user

if TYPE_CHECKING:
    from collections.abc import Callable

    from click import Command


_LOGGER = to_logger(__name__)


##


def stop(*, stanza: str | None = None, user: str | None = None) -> None:
    _LOGGER.info("Stopping 'pgbackrest'...")
    args: list[str] = ["pgbackrest"]
    if stanza is None:
        args.append(f"--stanza={stanza}")
    args.append("stop")
    run_or_as_user(*args, user=user, print=True, logger=_LOGGER)
    _LOGGER.info("Finished stopping 'pgbackrest'")


##


def make_stop_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @stanza_option
    @user_option
    def func(*, stanza: str | None, user: str | None) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        stop(stanza=stanza, user=user)

    return cli(
        name=name, help="Stop pgBackRest processes from running", **CONTEXT_SETTINGS
    )(func)


__all__ = ["make_stop_cmd", "stop"]
