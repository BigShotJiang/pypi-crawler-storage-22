from __future__ import annotations

from logging import getLogger

LOGGER = getLogger("restic")


__all__ = ["LOGGER"]
