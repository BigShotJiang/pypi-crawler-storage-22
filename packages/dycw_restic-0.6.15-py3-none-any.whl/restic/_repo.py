from __future__ import annotations

from contextlib import contextmanager, suppress
from dataclasses import dataclass
from io import StringIO
from pathlib import Path
from re import search
from typing import TYPE_CHECKING, Self, assert_never, override

from dotenv import dotenv_values
from pydantic import BaseModel, SecretStr, ValidationError
from utilities.core import (
    ExtractGroupError,
    ExtractGroupsError,
    extract_group,
    extract_groups,
    get_class_name,
    get_env,
    normalize_str,
    read_text_if_existing_file,
    repr_str,
    yield_temp_environ,
)
from utilities.pydantic import ensure_secret
from utilities.types import PathLike

from restic._constants import (
    BACKBLAZE_APPLICATION_KEY,
    BACKBLAZE_APPLICATION_KEY_ENV_VAR,
    BACKBLAZE_KEY_ID,
    BACKBLAZE_KEY_ID_ENV_VAR,
    RESTIC_REPOSITORY_ENV_VAR,
)

if TYPE_CHECKING:
    from collections.abc import Iterator

    from utilities.types import PathLike, SecretLike


type Repo = Backblaze | BackblazeJob | Local | SFTP
type RepoLike = Repo | str


##


@dataclass(repr=False, order=True, frozen=True, slots=True)
class Backblaze:
    """A Backblaze repo."""

    bucket: str
    path: Path
    key_id: SecretStr
    application_key: SecretStr

    @override
    def __repr__(self) -> str:
        url = f"{self.bucket}:{self.path}"
        return f"{get_class_name(self)}({repr_str(url)})"

    @classmethod
    def parse(
        cls,
        text: str,
        /,
        *,
        key_id: SecretLike | None = BACKBLAZE_KEY_ID,
        application_key: SecretLike | None = BACKBLAZE_APPLICATION_KEY,
    ) -> Self:
        """Parse a string into a Backblaze Repo."""
        match key_id, get_env(BACKBLAZE_KEY_ID_ENV_VAR, nullable=True):
            case SecretStr() | str() as key_id_use, _:
                ...
            case None, str() as key_id_use:
                ...
            case None, None:
                raise BackblazeKeyIdMissingError from None
        match (
            application_key,
            get_env(BACKBLAZE_APPLICATION_KEY_ENV_VAR, nullable=True),
        ):
            case SecretStr() | str() as application_key_use, _:
                ...
            case None, str() as application_key_use:
                ...
            case None, None:
                raise BackblazeApplicationKeyMissingError from None
        pattern = r"^b2:([^@:]+):([^@+]+)$"
        try:
            bucket, path = extract_groups(pattern, text)
        except ExtractGroupsError:
            raise BackblazeInvalidStrError(pattern=pattern, text=text) from None
        return cls(
            bucket=bucket,
            path=Path(path),
            key_id=ensure_secret(key_id_use),
            application_key=ensure_secret(application_key_use),
        )

    @property
    def repository(self) -> str:
        return f"b2:{self.bucket}:{self.path}"

    @contextmanager
    def yield_env(self, env_var: str = RESTIC_REPOSITORY_ENV_VAR, /) -> Iterator[None]:
        with yield_temp_environ(
            {env_var: self.repository},
            B2_ACCOUNT_ID=self.key_id.get_secret_value(),
            B2_ACCOUNT_KEY=self.application_key.get_secret_value(),
        ):
            yield


@dataclass(order=True, unsafe_hash=True, kw_only=True, slots=True)
class BackblazeParseError(Exception): ...


@dataclass(order=True, unsafe_hash=True, kw_only=True, slots=True)
class BackblazeKeyIdMissingError(BackblazeParseError):
    @override
    def __str__(self) -> str:
        return f"Key ID missing; use env var {BACKBLAZE_KEY_ID_ENV_VAR!r}"


@dataclass(order=True, unsafe_hash=True, kw_only=True, slots=True)
class BackblazeApplicationKeyMissingError(BackblazeParseError):
    @override
    def __str__(self) -> str:
        return f"Application key missing; use env var {BACKBLAZE_APPLICATION_KEY_ENV_VAR!r}"


@dataclass(order=True, unsafe_hash=True, kw_only=True, slots=True)
class BackblazeInvalidStrError(BackblazeParseError):
    pattern: str
    text: str

    @override
    def __str__(self) -> str:
        return f"Text must be of the form {self.pattern!r}; got {self.text!r}"


##


@dataclass(repr=False, order=True, frozen=True, slots=True)
class BackblazeJob(Backblaze):
    """A backblaze repo with its purge policy."""

    keep_last: int | None = None
    keep_hourly: int | None = None
    keep_daily: int | None = None
    keep_weekly: int | None = None
    keep_monthly: int | None = None
    keep_yearly: int | None = None
    keep_within: str | None = None
    keep_within_hourly: str | None = None
    keep_within_daily: str | None = None
    keep_within_weekly: str | None = None
    keep_within_monthly: str | None = None
    keep_within_yearly: str | None = None

    def dump(self) -> str:
        lines: list[str] = [
            f"BUCKET={self.bucket}",
            f"PATH={self.path}",
            f"APPLICATION_KEY={self.application_key.get_secret_value()}",
            f"KEY_ID={self.key_id.get_secret_value()}",
        ]
        if self.keep_last is not None:
            lines.append(f"KEEP_LAST={self.keep_last}")
        if self.keep_hourly is not None:
            lines.append(f"KEEP_HOURLY={self.keep_hourly}")
        if self.keep_daily is not None:
            lines.append(f"KEEP_DAILY={self.keep_daily}")
        if self.keep_weekly is not None:
            lines.append(f"KEEP_WEEKLY={self.keep_weekly}")
        if self.keep_monthly is not None:
            lines.append(f"KEEP_MONTHLY={self.keep_monthly}")
        if self.keep_yearly is not None:
            lines.append(f"KEEP_YEARLY={self.keep_yearly}")
        if self.keep_within is not None:
            lines.append(f"KEEP_WITHIN={self.keep_within}")
        if self.keep_within_hourly is not None:
            lines.append(f"KEEP_WITHIN_HOURLY={self.keep_within_hourly}")
        if self.keep_within_daily is not None:
            lines.append(f"KEEP_WITHIN_DAILY={self.keep_within_daily}")
        if self.keep_within_weekly is not None:
            lines.append(f"KEEP_WITHIN_WEEKLY={self.keep_within_weekly}")
        if self.keep_within_monthly is not None:
            lines.append(f"KEEP_WITHIN_MONTHLY={self.keep_within_monthly}")
        if self.keep_within_yearly is not None:
            lines.append(f"KEEP_WITHIN_YEARLY={self.keep_within_yearly}")
        return normalize_str("\n".join(lines))

    @classmethod
    @override
    def parse(
        cls,
        path_or_text: PathLike,
        /,
        *,
        key_id: SecretLike | None = BACKBLAZE_KEY_ID,
        application_key: SecretLike | None = BACKBLAZE_APPLICATION_KEY,
    ) -> Self:
        class Dummy(BaseModel):
            """A backblaze repo with its purge policy."""

            bucket: str
            path: Path
            key_id: SecretStr | None = None
            application_key: SecretStr | None = None
            keep_last: int | None = None
            keep_hourly: int | None = None
            keep_daily: int | None = None
            keep_weekly: int | None = None
            keep_monthly: int | None = None
            keep_yearly: int | None = None
            keep_within: str | None = None
            keep_within_hourly: str | None = None
            keep_within_daily: str | None = None
            keep_within_weekly: str | None = None
            keep_within_monthly: str | None = None
            keep_within_yearly: str | None = None

        text = read_text_if_existing_file(path_or_text)
        values = dotenv_values(stream=StringIO(text))
        try:
            dummy = Dummy.model_validate({k.lower(): v for k, v in values.items()})
        except ValidationError as error:
            raise BackblazeJobError(
                path_or_text=path_or_text, validation_error=error
            ) from None
        match key_id, dummy.key_id:
            case SecretStr() | str() as key_id_use, _:
                ...
            case None, SecretStr() | str() as key_id_use:
                ...
            case None, None:
                raise BackblazeKeyIdMissingError from None
        match application_key, dummy.application_key:
            case SecretStr() | str() as application_key_use, _:
                ...
            case None, SecretStr() | str() as application_key_use:
                ...
            case None, None:
                raise BackblazeApplicationKeyMissingError from None
        return cls(
            bucket=dummy.bucket,
            path=dummy.path,
            key_id=ensure_secret(key_id_use),
            application_key=ensure_secret(application_key_use),
            keep_last=dummy.keep_last,
            keep_hourly=dummy.keep_hourly,
            keep_daily=dummy.keep_daily,
            keep_weekly=dummy.keep_weekly,
            keep_monthly=dummy.keep_monthly,
            keep_yearly=dummy.keep_yearly,
            keep_within=dummy.keep_within,
            keep_within_hourly=dummy.keep_within_hourly,
            keep_within_daily=dummy.keep_within_daily,
            keep_within_weekly=dummy.keep_within_weekly,
            keep_within_monthly=dummy.keep_within_monthly,
            keep_within_yearly=dummy.keep_within_yearly,
        )


@dataclass(order=True, unsafe_hash=True, kw_only=True, slots=True)
class BackblazeJobError(Exception):
    path_or_text: PathLike
    validation_error: ValidationError


##


@dataclass(repr=False, order=True, frozen=True, slots=True)
class Local:
    """A local repo."""

    path: Path

    @override
    def __repr__(self) -> str:
        return f"{get_class_name(self)}({repr_str(self.path)})"

    @classmethod
    def parse(cls, text: str, /) -> Self:
        """Parse a string into a local Repo."""
        pattern = r"^local:([^@:]+)$"
        try:
            path = extract_group(pattern, text)
        except ExtractGroupError:
            raise LocalParseError(pattern=pattern, text=text) from None
        return cls(Path(path))

    @property
    def repository(self) -> str:
        return f"local:{self.path}"

    @contextmanager
    def yield_env(self, env_var: str = RESTIC_REPOSITORY_ENV_VAR, /) -> Iterator[None]:
        with yield_temp_environ({env_var: self.repository}):
            yield


@dataclass(order=True, unsafe_hash=True, kw_only=True, slots=True)
class LocalParseError(Exception):
    pattern: str
    text: str

    @override
    def __str__(self) -> str:
        return f"Text must be of the form {self.pattern!r}; got {self.text!r}"


##


@dataclass(order=True, unsafe_hash=True, slots=True)
class SFTP:
    """An SFTP repo."""

    user: str
    hostname: str
    path: Path

    @override
    def __repr__(self) -> str:
        url = f"{self.user}@{self.hostname}:{self.path}"
        return f"{get_class_name(self)}({repr_str(url)})"

    @classmethod
    def parse(cls, text: str, /) -> Self:
        """Parse a string into an SFTP Repo."""
        pattern = r"^sftp:([^@:]+)@([^@:]+):([^@:]+)$"
        try:
            user, hostname, path = extract_groups(pattern, text)
        except ExtractGroupsError:
            raise SFTPParseError(pattern=pattern, text=text) from None
        return cls(user, hostname, Path(path))

    @property
    def repository(self) -> str:
        return f"sftp:{self.user}@{self.hostname}:{self.path}"

    @contextmanager
    def yield_env(self, env_var: str = RESTIC_REPOSITORY_ENV_VAR, /) -> Iterator[None]:
        with yield_temp_environ({env_var: self.repository}):
            yield


@dataclass(order=True, unsafe_hash=True, kw_only=True, slots=True)
class SFTPParseError(Exception):
    pattern: str
    text: str

    @override
    def __str__(self) -> str:
        return f"Text must be of the form {self.pattern!r}; got {self.text!r}"


##


def parse_repo(path_or_text: PathLike, /) -> Repo:
    """Parse a string into a Repo."""
    match path_or_text:
        case Path() as path:
            try:
                return BackblazeJob.parse(path)
            except BackblazeJobError:
                return Local(path)
        case str() as text:
            with suppress(BackblazeJobError):
                return BackblazeJob.parse(text)
            try:
                return Backblaze.parse(text)
            except BackblazeParseError as error:
                if search("b2", text):
                    raise ParseRepoBackblazeError(text=str(error)) from None
            with suppress(LocalParseError):
                return Local.parse(text)
            with suppress(SFTPParseError):
                return SFTP.parse(text)
            return parse_repo(Path(text))
        case never:
            assert_never(never)


@dataclass(order=True, unsafe_hash=True, kw_only=True, slots=True)
class ParseRepoBackblazeError(Exception):
    text: str

    @override
    def __str__(self) -> str:
        return self.text


##


__all__ = [
    "SFTP",
    "Backblaze",
    "BackblazeApplicationKeyMissingError",
    "BackblazeInvalidStrError",
    "BackblazeJob",
    "BackblazeJobError",
    "BackblazeKeyIdMissingError",
    "BackblazeParseError",
    "Local",
    "LocalParseError",
    "ParseRepoBackblazeError",
    "Repo",
    "RepoLike",
    "SFTPParseError",
    "parse_repo",
]
