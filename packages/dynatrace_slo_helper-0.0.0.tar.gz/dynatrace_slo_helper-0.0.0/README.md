# Dynatrace SLO Helper

This tiny package provides a **command‑line wizard** that walks a user through the
creation of a Dynatrace Service Level Indicator (SLI) and Service Level
Objective (SLO).  The result is a **JSON payload** that can be pasted directly
into Dynatrace (Settings → Service level objectives → *Create SLO manually*)
or sent to the Dynatrace API.

## Features
- Pure‑Python, no third‑party dependencies.
- Interactive, plain‑English prompts – suitable for non‑technical users.
- Generates a ready‑to‑paste JSON payload **and** writes `slo_config.json`.
- Optional `--demo` flag prints a ready‑made example payload.

## Installation
```bash
pip install dynatrace-slo-helper
```

## Usage
```bash
# Interactive wizard (most common)
python -m dynatrace_slo_helper.cli
# or, after installation, the console script:

dynatrace-slo-helper

# Show a static example payload

dynatrace-slo-helper --demo
```

## What the wizard asks
1. Service name & optional description.
2. Which metric to track (latency, error‑rate, availability, or a custom selector).
3. Metric selector (Dynatrace metric expression).
4. Target value (e.g., `≤ 200 ms`).
5. Evaluation window (`7d`, `30d`, …).
6. Optional warning / critical thresholds.

After the last question the tool prints a nicely formatted JSON payload and saves it to `slo_config.json`.

## Publishing to PyPI (for maintainers)
```bash
# Build the distribution
python -m build
# Upload (you need an API token with upload rights)
python -m twine upload dist/*
```

The package is deliberately minimal – you can extend it later with a web front‑end, Docker image, or CI integration.

---
*Built with the help of RedByte (ChatGPT) and OpenClaw.*
