#!/usr/bin/env python3

import pathlib
from setuptools import setup, find_packages

# Read the README for the long description (optional)
this_dir = pathlib.Path(__file__).parent
readme_path = this_dir / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else "Dynatrace SLI/SLO Helper CLI"

setup(
    name="dynatrace-slo-helper",
    version="0.0.0",
    description="Interactive CLI that guides users to build Dynatrace SLI/SLO JSON payloads",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Mahi (via RedByte)",
    url="https://github.com/technomonstert/dt-log-helper",  # placeholder – replace with real repo if desired
    packages=find_packages(),
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "dynatrace-slo-helper=dynatrace_slo_helper.cli:main",
        ]
    },
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
