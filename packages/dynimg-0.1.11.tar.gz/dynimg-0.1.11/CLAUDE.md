
@.pearls/CLAUDE.md
