"""
Bundled DSL models that ship with dynlib.

The path to this package is registered automatically under the ``builtin://``
tag so users can reference these models without configuring paths manually.
"""

