"""
Network configuration helpers for E2B sandboxes.
"""

"""
CIDR range that represents all traffic.
"""
ALL_TRAFFIC = "0.0.0.0/0"
