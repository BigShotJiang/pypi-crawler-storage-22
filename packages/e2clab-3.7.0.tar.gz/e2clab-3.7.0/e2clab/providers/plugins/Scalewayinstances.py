from typing import Optional
from uuid import UUID

import enoslib as en

from e2clab.errors import E2clabDependencyError

try:
    from enos_scalewayinstances import Configuration, ScalewayInstancesProvider
except ImportError:
    raise E2clabDependencyError(
        "Error importing Scaleway support. "
        "You need to install the specific dependencies: 'pip install e2clab[scaleway]'"
    )

import e2clab.constants.default as default
from e2clab.constants.layers_services import (
    NAME,
    QUANTITY,
    SCALEWAY_INSTANCES,
    SERVICES,
)
from e2clab.log import get_logger
from e2clab.providers import Provider, ProviderConfig

logger = get_logger(__name__, ["ScalewayInstance"])


class SIConfig(ProviderConfig):
    def __init__(self, data):
        super().__init__(data)

        # parsing data
        self.config_file = self.env.get("config_file")
        self.profile = self.env.get("profile")
        self.region = self.env.get("region")
        self.architecture = self.env.get("architecture", default.ARCHITECTURE)
        self.ipv6 = self.env.get("ipv6")
        self.zone = self.env.get("zone")
        self.gateway_type = self.env.get("gateway_type")
        self.image = self.env.get("image")
        self.commercial_type = self.env.get("commercial_type")
        self.ports_to_open = self.env.get("ports_to_open", None)

    def init(self, optimization_id: Optional[int] = None) -> None:
        kwargs = {
            "config_file": self.config_file,
            "architecture": self.architecture,
            "profile": self.profile,
            "region": self.region,
            "gateway_type": self.gateway_type,
            "ports_to_open": self.ports_to_open,
            "enable_ipv6": self.ipv6,
        }
        filtered_kwargs = {k: v for k, v in kwargs.items() if v is not None}
        self.config = Configuration.from_settings(**filtered_kwargs)

    def config_monitoring(self):
        # TODO
        pass

    def config_provenance(self):
        # TODO
        pass

    def config_resources(self):
        for layer in self.layers:
            for service in layer[SERVICES]:
                roles = self.get_service_roles(layer[NAME], service)
                commercial_type = service.get("commercial_type", self.commercial_type)
                image = service.get("image", self.image)
                number = service.get(QUANTITY, default.NODE_QUANTITY)
                kwargs = {
                    "roles": roles,
                    "number": number,
                    "image": image,
                    "commercial_type": commercial_type,
                }
                kwargs = {k: v for k, v in kwargs.items() if v is not None}

                self.config.add_machine(**kwargs)

    def finalize(self):
        self.config = self.config.finalize()
        logger.debug(f"Provider conf = {self.config.to_dict()}")
        provider = ScalewayInstancesProvider(self.config)
        return provider, self.monitoring_provider, self.provenance_provider


class Scalewayinstances(Provider):
    # def __init__(self, infra_config: InfrastructureConfig, optimization_id=None):
    def __init__(self, infra_config, optimization_id=None):
        super().__init__(infra_config, optimization_id)
        self.infra_config.refine_to_environment(SCALEWAY_INSTANCES)
        self.config = SIConfig(self.infra_config)

    def init(self):
        self.provider = self._provider_scaleway(self.optimization_id)

        roles, networks = self.provider.init()

        roles = en.sync_info(roles, networks)

        self.roles = roles
        self.networks = networks

        self.log_roles_networks(SCALEWAY_INSTANCES)

        return roles, networks

    def destroy(self):
        self.provider.destroy()

    def _provider_scaleway(
        self, optimization_id: Optional[UUID]
    ) -> ScalewayInstancesProvider:
        self.config.init(optimization_id=optimization_id)
        self.config.config_provenance()
        self.config.config_monitoring()
        self.config.config_resources()
        provider, monitoring_provider, provenance_provider = self.config.finalize()
        self.monitoring_provider = monitoring_provider
        self.provenance_provider = provenance_provider
        return provider
