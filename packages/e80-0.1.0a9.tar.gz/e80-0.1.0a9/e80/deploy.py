from math import ceil
import math
import click
from e80.archive import archive_project
from e80.create_project import create_project
from e80.lib.context import E80ContextObject
from e80.lib.project import ProjectFiles
from e80.lib.platform import PlatformClient, UploadArtifactMetadata
from e80.lib.user import get_auth_info
from e80.lib.constants import E80_COMMAND
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

_UPLOAD_CHUNK_SIZE = 100 * 1024 * 1024  # 100 mb

progress = Progress(
    TextColumn("[bold blue]{task.fields[title]}", justify="right"),
    BarColumn(bar_width=None),
    "[progress.percentage]{task.percentage:>3.1f}%",
    "•",
    DownloadColumn(),
    "•",
    TransferSpeedColumn(),
    "•",
    TimeRemainingColumn(),
)


def deploy_project(
    ctx_obj: E80ContextObject, artifact_id: str | None, force_build: bool
) -> None:
    create_project(ctx_obj)

    project_files = ProjectFiles(ctx_obj)

    config = project_files.read_project_config()

    auth_info = get_auth_info(ctx_obj)
    if auth_info is None:
        raise click.UsageError(
            f"You are not logged in! Please run '{E80_COMMAND} login'."
        )
    pc = PlatformClient(ctx_obj, api_key=auth_info.auth_token)

    artifact_id_to_deploy: str | None = None
    if artifact_id is not None:
        artifact_id_to_deploy = artifact_id
        click.echo(f"Deploying artifact ID '{artifact_id}'")
        deploy_resp = pc.deploy_artifact(config, artifact_id=artifact_id_to_deploy)
    else:
        archive_project(ctx_obj, force_build)

        artifact_metadata = project_files.read_artifact_metadata()
        if artifact_metadata is None:
            raise Exception(
                "Artifact metadata was not created. This is a bug, please report."
            )

        if artifact_metadata.artifact_id is not None:
            click.echo(
                f"Archive was already deployed as '{artifact_metadata.artifact_id}'. Pass --force to force rebuilding and deployment"
            )
            return

        archive = project_files.get_artifact_path()
        if not archive.exists():
            raise Exception("Archive was not created. This is a bug, please report.")

        with progress:
            if archive.stat().st_size > _UPLOAD_CHUNK_SIZE:
                progress.console.log(
                    f"Archive is {math.floor(archive.stat().st_size / (1024 * 1024))}mb. Uploading in parts."
                )
                chunks = ceil(archive.stat().st_size / _UPLOAD_CHUNK_SIZE)
                start = pc.start_upload_artifact_part(
                    config,
                    UploadArtifactMetadata(
                        python_version=artifact_metadata.python_version
                    ),
                )
                progress.console.log(
                    f"Starting multipart upload for artifact ID: {start.artifact_id}"
                )
                with archive.open("rb") as f:
                    for i in range(1, chunks + 1):
                        task_id = progress.add_task(
                            "download",
                            title=f"Chunk {i}/{chunks}",
                            total=min(
                                _UPLOAD_CHUNK_SIZE,
                                archive.stat().st_size - (i * _UPLOAD_CHUNK_SIZE),
                            ),
                        )
                        pc.upload_artifact_part(
                            config,
                            artifact_id=start.artifact_id,
                            part_num=i,
                            part=f.read(_UPLOAD_CHUNK_SIZE),
                            callback=lambda num: progress.update(task_id, advance=num),
                        )
                pc.finish_upload_artifact_part(config, start.artifact_id)
                artifact_id_to_deploy = start.artifact_id

            else:
                with archive.open("rb") as f:
                    task_id = progress.add_task(
                        "download", title="Artifact", total=archive.stat().st_size
                    )
                    resp = pc.upload_artifact(
                        config,
                        UploadArtifactMetadata(
                            python_version=artifact_metadata.python_version
                        ),
                        f,
                        callback=lambda num: progress.update(task_id, advance=num),
                    )
                    artifact_id_to_deploy = resp.artifact_id
            progress.console.log(f"Uploading artifact '{resp.artifact_id}' finished.")
            deploy_resp = pc.deploy_artifact(config, artifact_id=artifact_id_to_deploy)

            artifact_metadata.artifact_id = artifact_id_to_deploy
            project_files.write_artifact_metadata(artifact_metadata)

    if deploy_resp.deployment_id is None:
        click.echo("No change detected")
    else:
        click.echo(
            f"Deploy started! Follow along: {ctx_obj.platform_host}/o/{config.organization_slug}/p/{config.project_slug}/edge/deployment/{deploy_resp.deployment_id}"
        )
