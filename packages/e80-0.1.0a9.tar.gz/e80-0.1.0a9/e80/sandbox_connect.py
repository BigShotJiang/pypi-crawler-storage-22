import asyncio
import base64
import json
import os
import select
import shutil
import signal
import sys
import termios
import time
import tty
import websockets
from websockets.asyncio.client import ClientConnection

# Escape sequence: ~ followed by . (like SSH)
ESCAPE_CHAR = ord("~")
DISCONNECT_CHAR = ord(".")


class ConnectionFailedError(Exception):
    """Raised when the initial WebSocket connection fails."""

    pass


class ServerConnectionError(Exception):
    """Raised when the server reports a connection error (e.g., sandbox not ready)."""

    pass


async def connect_to_sandbox(
    platform_host: str,
    org_slug: str,
    project_slug: str,
    sandbox_id: str,
    auth_token: str,
) -> int:
    """
    Connect to a sandbox via WebSocket and provide an SSH-like terminal experience.

    Args:
        platform_host: The platform host URL (e.g., https://app.8080.io)
        org_slug: Organization slug
        project_slug: Project slug
        sandbox_id: The sandbox run ID to connect to
        auth_token: User's auth token for Authorization header

    Returns the exit code from the remote shell.

    Escape sequences (like SSH):
    - ~. : Disconnect from the sandbox
    - ~~ : Send a literal ~
    """
    # Ensure we have a TTY
    if not sys.stdin.isatty():
        print("Error: stdin is not a TTY", file=sys.stderr)
        return 1

    # Save original terminal settings
    old_settings = termios.tcgetattr(sys.stdin)

    # Build the websocket URL
    ws_host = platform_host.rstrip("/")
    if ws_host.startswith("https://"):
        ws_host = "wss://" + ws_host[8:]
    elif ws_host.startswith("http://"):
        ws_host = "ws://" + ws_host[7:]
    elif not ws_host.startswith("ws://") and not ws_host.startswith("wss://"):
        ws_host = "wss://" + ws_host
    ws_url = f"{ws_host}/api/sandbox/{org_slug}/{project_slug}/{sandbox_id}/connect"

    exit_code = 0
    force_disconnect = asyncio.Event()

    def handle_interrupt(signum: int, frame: object) -> None:
        """Handle SIGINT/SIGTERM to force disconnect."""
        force_disconnect.set()

    # Set up interrupt handlers before connecting
    old_sigint = signal.signal(signal.SIGINT, handle_interrupt)
    old_sigterm = signal.signal(signal.SIGTERM, handle_interrupt)

    try:
        # Try to establish connection first (before entering raw mode)
        headers = {"Authorization": f"Bearer {auth_token}"}
        try:
            ws = await websockets.connect(ws_url, additional_headers=headers)
        except Exception as e:
            # Connection failed - raise specific error for retry logic
            raise ConnectionFailedError(f"Failed to connect: {e}") from e

        # Connection established - now enter raw mode
        try:
            tty.setraw(sys.stdin.fileno())

            # Send initial terminal size
            size = shutil.get_terminal_size()
            await ws.send(
                json.dumps(
                    {"type": "resize", "cols": size.columns, "rows": size.lines}
                )
            )

            # Set up resize handler
            resize_queue: asyncio.Queue[tuple[int, int]] = asyncio.Queue()

            def handle_resize(signum: int, frame: object) -> None:
                size = shutil.get_terminal_size()
                # Queue the resize event (can't await in signal handler)
                try:
                    resize_queue.put_nowait((size.columns, size.lines))
                except asyncio.QueueFull:
                    pass

            old_sigwinch = signal.signal(signal.SIGWINCH, handle_resize)

            try:
                exit_code = await _run_terminal_session(
                    ws, resize_queue, force_disconnect
                )
            finally:
                signal.signal(signal.SIGWINCH, old_sigwinch)

        except ServerConnectionError:
            # Let this propagate up for retry logic
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
            raise
        except websockets.exceptions.ConnectionClosed as e:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
            print(f"\nConnection closed: {e}", file=sys.stderr)
            return 1
        except Exception as e:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
            print(f"\nError: {e}", file=sys.stderr)
            return 1
        finally:
            # Restore terminal settings
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
            await ws.close()

    finally:
        signal.signal(signal.SIGINT, old_sigint)
        signal.signal(signal.SIGTERM, old_sigterm)

    return exit_code


async def _run_terminal_session(
    ws: ClientConnection,
    resize_queue: asyncio.Queue[tuple[int, int]],
    force_disconnect: asyncio.Event,
) -> int:
    """Run the terminal session, handling input/output/resize concurrently.

    Supports escape sequences:
    - ~. : Disconnect
    - ~~ : Send literal ~
    """
    exit_code = 0
    stop_event = asyncio.Event()

    async def read_stdin() -> str | None:
        """Read from stdin and send to websocket.

        Returns a disconnect reason if user requested disconnect, None otherwise.
        """
        loop = asyncio.get_event_loop()
        stdin_fd = sys.stdin.fileno()
        after_newline = True  # Start as if after newline for first escape
        escape_pending = False

        while not stop_event.is_set():
            # Check for force disconnect (from signal handler)
            if force_disconnect.is_set():
                return "interrupted"

            # Use select to check if stdin has data (with timeout for checking stop_event)
            readable, _, _ = await loop.run_in_executor(
                None, lambda: select.select([stdin_fd], [], [], 0.05)
            )

            if readable:
                try:
                    data = os.read(stdin_fd, 1024)
                    if not data:
                        continue

                    # Process escape sequences byte by byte
                    output_data = bytearray()
                    for byte in data:
                        if escape_pending:
                            escape_pending = False
                            if byte == DISCONNECT_CHAR:
                                # ~. = disconnect
                                return "escape"
                            elif byte == ESCAPE_CHAR:
                                # ~~ = send literal ~
                                output_data.append(ESCAPE_CHAR)
                            else:
                                # Not a recognized escape, send both ~ and this char
                                output_data.append(ESCAPE_CHAR)
                                output_data.append(byte)
                        elif after_newline and byte == ESCAPE_CHAR:
                            # Start of potential escape sequence
                            escape_pending = True
                        else:
                            output_data.append(byte)

                        # Track newlines for escape detection
                        after_newline = byte in (ord("\r"), ord("\n"))

                    if output_data:
                        encoded = base64.b64encode(bytes(output_data)).decode("ascii")
                        await ws.send(json.dumps({"type": "input", "data": encoded}))
                except OSError:
                    break
        return None

    async def read_output() -> int:
        """Read from websocket and write to stdout."""
        nonlocal exit_code
        received_output = False
        try:
            async for message in ws:
                if stop_event.is_set():
                    break
                msg = json.loads(message)
                msg_type = msg.get("type")

                if msg_type == "output":
                    received_output = True
                    data = base64.b64decode(msg.get("data", ""))
                    os.write(sys.stdout.fileno(), data)

                elif msg_type == "exit":
                    exit_code = msg.get("code", 0)
                    return exit_code

                elif msg_type == "error":
                    error_msg = msg.get("message", "Unknown error")
                    if not received_output:
                        # Error before any output - sandbox may not be ready
                        raise ServerConnectionError(error_msg)
                    # Error after receiving output - print and exit
                    print(f"\nServer error: {error_msg}", file=sys.stderr)
                    return 1
        except websockets.exceptions.ConnectionClosed:
            pass
        return exit_code

    async def handle_resize() -> None:
        """Handle terminal resize events."""
        while not stop_event.is_set():
            try:
                cols, rows = await asyncio.wait_for(resize_queue.get(), timeout=0.1)
                await ws.send(json.dumps({"type": "resize", "cols": cols, "rows": rows}))
            except asyncio.TimeoutError:
                continue
            except Exception:
                break

    async def watch_force_disconnect() -> str:
        """Watch for force disconnect signal."""
        while not force_disconnect.is_set():
            await asyncio.sleep(0.05)
        return "interrupted"

    # Run all tasks concurrently
    input_task = asyncio.create_task(read_stdin())
    output_task = asyncio.create_task(read_output())
    resize_task = asyncio.create_task(handle_resize())
    disconnect_task = asyncio.create_task(watch_force_disconnect())

    disconnect_reason = None

    try:
        # Wait for any task to complete
        done, pending = await asyncio.wait(
            [input_task, output_task, resize_task, disconnect_task],
            return_when=asyncio.FIRST_COMPLETED,
        )

        # Check results - re-raise exceptions from output task
        if output_task in done:
            # This will re-raise ServerConnectionError if it occurred
            exit_code = output_task.result()
        if input_task in done:
            disconnect_reason = input_task.result()
        if disconnect_task in done:
            disconnect_reason = disconnect_task.result()

    except ServerConnectionError:
        # Re-raise for retry logic - cleanup will happen in finally
        raise

    finally:
        # Signal all tasks to stop
        stop_event.set()
        force_disconnect.set()  # Also trigger this to unblock the watcher

        # Cancel pending tasks
        for task in [input_task, output_task, resize_task, disconnect_task]:
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

    if disconnect_reason == "escape":
        # Print on new line since we're in raw mode
        os.write(sys.stdout.fileno(), b"\r\nConnection closed.\r\n")
    elif disconnect_reason == "interrupted":
        os.write(sys.stdout.fileno(), b"\r\nInterrupted.\r\n")

    return exit_code


def run_connect(
    platform_host: str,
    org_slug: str,
    project_slug: str,
    sandbox_id: str,
    auth_token: str,
) -> int:
    """Synchronous wrapper for connect_to_sandbox."""
    return asyncio.run(
        connect_to_sandbox(platform_host, org_slug, project_slug, sandbox_id, auth_token)
    )


def run_connect_with_retry(
    platform_host: str,
    org_slug: str,
    project_slug: str,
    sandbox_id: str,
    auth_token: str,
    timeout: float = 30.0,
    retry_interval: float = 1.0,
) -> int:
    """
    Connect to sandbox with retry logic for initial connection failures.

    Retries connection attempts for up to `timeout` seconds if the sandbox
    is not yet ready.

    Args:
        platform_host: The platform host URL
        org_slug: Organization slug
        project_slug: Project slug
        sandbox_id: The sandbox run ID
        auth_token: User's auth token
        timeout: Maximum time to retry in seconds (default 30s)
        retry_interval: Time between retries in seconds (default 2s)

    Returns:
        Exit code from the shell session
    """
    start_time = time.time()
    last_error: Exception | None = None

    while time.time() - start_time < timeout:
        try:
            return asyncio.run(
                connect_to_sandbox(
                    platform_host, org_slug, project_slug, sandbox_id, auth_token
                )
            )
        except (ConnectionFailedError, ServerConnectionError) as e:
            last_error = e
            elapsed = time.time() - start_time
            remaining = timeout - elapsed
            if remaining > retry_interval:
                time.sleep(retry_interval)
            else:
                break

    print(f"Failed to connect after {int(timeout)}s: {last_error}", file=sys.stderr)
    return 1
