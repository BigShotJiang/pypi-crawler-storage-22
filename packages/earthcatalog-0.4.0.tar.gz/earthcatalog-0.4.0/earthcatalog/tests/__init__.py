# Test package for STAC ingestion pipeline
