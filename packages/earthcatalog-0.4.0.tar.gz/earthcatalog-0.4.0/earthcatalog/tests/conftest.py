"""Pytest configuration and fixtures for EarthCatalog tests.

This module provides:
- Custom command-line options for e2e tests
- Shared fixtures across test modules
- Pytest hooks for test collection and configuration
"""


def pytest_addoption(parser):
    """Add custom command-line options for e2e tests."""
    # Data generation options
    parser.addoption(
        "--e2e-items",
        action="store",
        default="100",
        help="Number of synthetic STAC items to generate for e2e tests",
    )
    parser.addoption(
        "--e2e-outlier-tiny",
        action="store",
        default="5",
        help="Percentage of tiny geometry outliers (0-100)",
    )
    parser.addoption(
        "--e2e-outlier-huge",
        action="store",
        default="5",
        help="Percentage of huge geometry outliers (0-100)",
    )
    parser.addoption(
        "--e2e-seed",
        action="store",
        default=None,
        help="Random seed for reproducibility",
    )

    # Grid configuration options
    parser.addoption(
        "--e2e-grid",
        action="store",
        default="h3",
        help="Grid system to use: h3, s2, mgrs, latlon, geojson (default: h3)",
    )
    parser.addoption(
        "--e2e-grid-level",
        action="store",
        default="2",
        help="Grid resolution/level (default: 2 for H3)",
    )
    parser.addoption(
        "--e2e-temporal",
        action="store",
        default="month",
        help="Temporal binning: year, month, day (default: month)",
    )

    # Query performance profiling options
    parser.addoption(
        "--e2e-profile-queries",
        action="store_true",
        default=False,
        help="Enable query performance profiling",
    )
    parser.addoption(
        "--e2e-query-iterations",
        action="store",
        default="10",
        help="Number of query iterations for profiling (default: 10)",
    )
    parser.addoption(
        "--e2e-query-engines",
        action="store",
        default="duckdb,rustac",
        help="Comma-separated query engines to profile: duckdb, rustac (default: duckdb,rustac)",
    )
