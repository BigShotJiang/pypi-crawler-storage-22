#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
SM4 国密对称加密算法，对标 AES
支持 CBC 和 GCM 模式
"""
from __future__ import annotations

import base64
import os
from typing import Tuple

import click
from cryptography.hazmat.primitives import padding

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import random_str
from easy_encryption_tool import command_perf

try:
    from easy_gmssl import EasySm4CBC, EasySm4GCM
    from easy_gmssl.gmssl import SM4_BLOCK_SIZE, SM4_CBC_IV_SIZE, SM4_GCM_DEFAULT_IV_SIZE
    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False

algorithm: str = 'sm4'

sm4_key_len: int = 16  # 16字节
sm4_iv_len: int = 16  # CBC 模式 16 字节
sm4_nonce_len: int = 12  # GCM 模式 12 字节

sm4_cbc_mode: str = 'cbc'
sm4_gcm_mode: str = 'gcm'

sm4_encrypt_action = 'encrypt'
sm4_decrypt_action = 'decrypt'

sm4_gcm_tag_len = SM4_BLOCK_SIZE if EASY_GMSSL_AVAILABLE else 16

sm4_file_read_block = 16


def _check_gmssl():
    if not EASY_GMSSL_AVAILABLE:
        click.echo('SM4 需要 easy_gmssl 库，请执行: pip install easy_gmssl')
        return False
    return True


def generate_random_key() -> str:
    return random_str.generate_random_str(sm4_key_len)


def generate_random_iv_nonce(mode: str) -> str:
    if mode == sm4_cbc_mode:
        return random_str.generate_random_str(sm4_iv_len)
    elif mode == sm4_gcm_mode:
        return random_str.generate_random_str(sm4_nonce_len)


def process_key_iv(is_random: bool, key: str, iv: str, mode: str) -> Tuple[str, str]:
    if is_random:
        return generate_random_key(), generate_random_iv_nonce(mode)
    else:
        key_len = len(key)
        if key_len > sm4_key_len:
            key = key[:sm4_key_len]
        else:
            key = key + random_str.generate_random_str(sm4_key_len - key_len)
        if mode == sm4_cbc_mode:
            if len(iv) > sm4_iv_len:
                iv = iv[:sm4_iv_len]
            elif len(iv) < sm4_iv_len:
                iv = iv + random_str.generate_random_str(sm4_iv_len - len(iv))
        elif mode == sm4_gcm_mode:
            if len(iv) > sm4_nonce_len:
                iv = iv[:sm4_nonce_len]
            elif len(iv) < sm4_nonce_len:
                iv = iv + random_str.generate_random_str(sm4_nonce_len - len(iv))
        return key, iv


def padding_data(data: bytes) -> bytes:
    padder = padding.PKCS7(128).padder()
    return padder.update(data) + padder.finalize()


def remove_padding_data(data: bytes) -> bytes:
    if data is None or len(data) == 0:
        return b''
    unpadder = padding.PKCS7(128).unpadder()
    return unpadder.update(data) + unpadder.finalize()


def check_gcm_tag(gcm_tag: str) -> bool:
    if gcm_tag is None:
        click.echo('expected a gcm tag(16 Bytes)')
        return False
    valid, input_raw_tag = common.check_b64_data(gcm_tag)
    if not valid:
        click.echo('invalid b64 encoded tag data:{}'.format(gcm_tag))
        return False
    if len(input_raw_tag) != sm4_gcm_tag_len:
        click.echo('invalid tag data length:{}, expected:{}'.format(len(input_raw_tag), sm4_gcm_tag_len))
        return False
    return True


def check_b64_input_data(input_data: str, input_limit: int) -> bool:
    if input_data is None:
        click.echo('need input data')
        return False
    valid, input_raw_bytes = common.check_b64_data(input_data)
    if not valid:
        click.echo('invalid b64 encoded data:{}'.format(input_data))
        return False
    if len(input_raw_bytes) > input_limit * 1024 * 1024:
        click.echo(
            'the data exceeds the maximum bytes limit, limited to:{}Bytes, now:{}Bytes'.format(
                input_limit * 1024 * 1024, len(input_raw_bytes)))
        return False
    if len(input_raw_bytes) <= 0:
        click.echo('need plain data but now got empty after base64 decoded')
        return False
    return True


@click.command(name='sm4', short_help='sm4国密对称加解密工具，支持 sm4-cbc 和 sm4-gcm')
@click.option('-m', '--mode',
              required=False,
              type=click.Choice([sm4_cbc_mode, sm4_gcm_mode]),
              default='cbc',
              show_default=True,
              help='sm4 模式，默认为 cbc，可选 cbc 或 gcm')
@click.option('-k', '--key',
              required=False,
              type=click.STRING,
              default=cipherhub_defaults.DEFAULT_KEY_16,
              help='key 默认 16 字节，与 CipherHUB 兼容，长度不够则自动补齐，长度超出则自动截取',
              show_default=True)
@click.option('-v', '--iv-nonce',
              required=False,
              type=click.STRING,
              default=cipherhub_defaults.DEFAULT_IV_16,
              help='cbc 模式下 iv 默认 16 字节，gcm 模式下 nonce 默认 12 字节，与 CipherHUB 兼容，'
                   '长度不够则自动补齐，长度超出则自动截取',
              show_default=True)
@click.option('--aad',
              required=False,
              type=click.STRING,
              default=cipherhub_defaults.DEFAULT_AAD,
              help='gcm 模式下的关联认证数据 AAD，与 CipherHUB 默认一致',
              show_default=True)
@click.option('-r', '--random-key-iv',
              required=False,
              type=click.BOOL,
              is_flag=True,
              default=False,
              help='是否自动生成随机的密钥和 iv/nonce')
@click.option('-a', '--action',
              required=False,
              type=click.Choice([sm4_encrypt_action, sm4_decrypt_action]),
              default='encrypt',
              show_default=True,
              help='加密（encrypt）或 解密（decrypt），加密后输出 base64 编码的字符串')
@click.option('-i', '--input-data',
              required=True,
              type=click.STRING,
              help='输入数据，加密时允许输入：字符串、base64 编码数据、文件路径，'
                   '解密时允许输入：base64 编码数据、文件路径')
@click.option('-e', '--is-base64-encoded',
              required=False,
              type=click.BOOL,
              is_flag=True,
              default=False,
              show_default=True,
              help='如果 -i/--input-data 的值被 base64 编码过，则需要带上 -e 参数，-e 与 -f 互斥')
@click.option('-f', '--is-a-file',
              required=False,
              type=click.BOOL,
              is_flag=True,
              default=False,
              show_default=False,
              help='如果 -i/--input-data 的值是一个文件，则需要带上 -f 参数，-e 与 -f 互斥')
@click.option('-l', '--input-limit',
              required=False,
              type=click.INT,
              default=1,
              show_default=True,
              help='输入内容最大长度，单位为 MB，默认为 1MB，在 -i 为非文件时生效')
@click.option('-o', '--output-file',
              required=False,
              type=click.STRING,
              default='',
              help='指定输出文件，当输入时指定了文件，则输出时必须指定')
@click.option('-t', '--gcm-tag',
              required=False,
              type=click.STRING,
              help='gcm 模式解密时可选；不填则从密文末尾解析 tag（密文格式为 base64(cipher||tag)）')
@command_perf.timing_decorator
def sm4_command(mode: str, key: str, iv_nonce: str,
                random_key_iv: bool, action: str,
                input_data: str, is_base64_encoded: bool,
                is_a_file: bool, input_limit: int,
                output_file: str, gcm_tag: str, aad: str):
    """SM4 国密对称加解密，支持 CBC 和 GCM 模式"""
    if not _check_gmssl():
        return

    key, iv_nonce = process_key_iv(random_key_iv, key, iv_nonce, mode)

    if len(input_data) <= 0:
        click.echo('no input data, it is required')
        return

    if is_base64_encoded and is_a_file:
        click.echo('the input data cannot be used as both a file and base64 encoded data')
        return

    input_raw_bytes = b''
    input_raw_tag = b''

    if mode == sm4_gcm_mode and action == sm4_decrypt_action and gcm_tag and len(gcm_tag.strip()) > 0:
        if not check_gcm_tag(gcm_tag):
            return
        input_raw_tag = common.decode_b64_data(gcm_tag)

    if is_base64_encoded:
        if not check_b64_input_data(input_data, input_limit):
            return
        input_raw_bytes = common.decode_b64_data(input_data)
        if mode == sm4_gcm_mode and action == sm4_decrypt_action and len(input_raw_tag) == 0:
            if len(input_raw_bytes) < sm4_gcm_tag_len:
                click.echo('invalid cipher: too short for gcm tag (need at least {} bytes)'.format(sm4_gcm_tag_len))
                return
            input_raw_tag = input_raw_bytes[-sm4_gcm_tag_len:]
            input_raw_bytes = input_raw_bytes[:-sm4_gcm_tag_len]

    input_from_file = None
    output_to_file = None
    if is_a_file:
        try:
            input_from_file = common.read_from_file(input_data)
        except BaseException:
            click.echo('{} may not exist or may be unreadable'.format(input_data))
            return
        else:
            if len(output_file) <= 0:
                click.echo('need a output file specified and writable')
                return

    if not is_base64_encoded and not is_a_file:
        if len(input_data) > input_limit * 1024 * 1024:
            click.echo(
                'the data exceeds the maximum bytes limit, limited to:{}Bytes, now:{}Bytes'.format(
                    input_limit * 1024 * 1024, len(input_data)))
            return
        input_raw_bytes = input_data.encode('utf-8')

    file_gcm_cipher_bytes = None
    if is_a_file and mode == sm4_gcm_mode and action == sm4_decrypt_action and len(input_raw_tag) == 0:
        file_size_for_read = os.stat(input_data).st_size
        if file_size_for_read < sm4_gcm_tag_len:
            click.echo('invalid cipher file: too short for gcm tag')
            return
        file_content = input_from_file.read_n_bytes(file_size_for_read)
        input_raw_tag = file_content[-sm4_gcm_tag_len:]
        file_gcm_cipher_bytes = file_content[:-sm4_gcm_tag_len]

    if mode == sm4_gcm_mode and action == sm4_decrypt_action and len(input_raw_tag) == 0:
        click.echo('gcm mode decrypt requires -t/--gcm-tag or cipher in base64(cipher||tag) format')
        return

    if len(output_file) > 0:
        try:
            output_to_file = common.write_to_file(output_file)
        except BaseException:
            click.echo('{} may not exist or may not writable'.format(output_file))
            return

    key_bytes = key.encode('utf-8')
    iv_bytes = iv_nonce.encode('utf-8')
    if mode == sm4_gcm_mode:
        auth_data = (aad or cipherhub_defaults.DEFAULT_AAD).encode('utf-8')
        sm4_op = EasySm4GCM(key=key_bytes, iv=iv_bytes, aad=auth_data, do_encrypt=(action == sm4_encrypt_action))
    else:
        sm4_op = EasySm4CBC(key=key_bytes, iv=iv_bytes, do_encrypt=(action == sm4_encrypt_action))

    if not is_a_file and input_from_file is None:
        if action == sm4_encrypt_action:
            padded_raw_bytes = padding_data(input_raw_bytes)
            cipher = sm4_op.Update(padded_raw_bytes) + sm4_op.Finish()
            if mode == sm4_gcm_mode:
                ret_tags = cipher[-sm4_gcm_tag_len:]
                all_cipher = cipher[:-sm4_gcm_tag_len]
                cipher_with_tag = all_cipher + ret_tags
                if not common.validate_gcm_cipher_format(cipher_with_tag, sm4_gcm_tag_len):
                    click.echo('invalid gcm cipher format: cipher_with_tag length < tag_len')
                    return
                all_cipher_str = base64.b64encode(cipher_with_tag).decode('utf-8')
                click.echo(
                    'plain size:{}\nkey:{}\niv:{}\ncipher size:{}\ncipher:{}'.format(
                        len(input_raw_bytes), key, iv_nonce,
                        len(cipher_with_tag), all_cipher_str))
                if output_to_file is not None and not output_to_file.write_bytes(cipher_with_tag):
                    return
            else:
                all_cipher = cipher
                all_cipher_str = base64.b64encode(all_cipher).decode('utf-8')
                click.echo(
                    'plain size:{}\nkey:{}\niv:{}\ncipher size:{}\ncipher:{}'.format(
                        len(input_raw_bytes), key, iv_nonce,
                        len(all_cipher), all_cipher_str))
                if output_to_file is not None and not output_to_file.write_bytes(all_cipher):
                    return
        if action == sm4_decrypt_action:
            try:
                if mode == sm4_gcm_mode:
                    cipher_with_tag = input_raw_bytes + input_raw_tag
                    plain = sm4_op.Update(cipher_with_tag) + sm4_op.Finish()
                    plain = remove_padding_data(plain)
                else:
                    plain = sm4_op.Update(input_raw_bytes) + sm4_op.Finish()
                    plain = remove_padding_data(plain)
            except BaseException as e:
                click.echo('decrypt {} failed:{}'.format(input_data, e))
                return
            be_str, ret = common.bytes_to_str(plain)
            if be_str:
                click.echo('cipher size:{}\nplain size:{}\nstr plain:{}'.format(
                    len(input_raw_bytes), len(plain), ret))
            else:
                click.echo('cipher size:{}\nplain size:{}\nb64 encoded plain:{}'.format(
                    len(input_raw_bytes), len(plain), ret))
            if output_to_file is not None and not output_to_file.write_bytes(plain):
                return

    if is_a_file and input_from_file is not None and output_to_file is not None:
        read_size = (sm4_file_read_block ** 5) * 64
        file_size = os.stat(input_data).st_size
        output_size = 0
        click.echo('input file size:{}'.format(file_size))
        if action == sm4_encrypt_action:
            while True:
                chunk = input_from_file.read_n_bytes(read_size)
                file_size -= len(chunk)
                if file_size <= 0:
                    chunk = padding_data(chunk)
                    cipher = sm4_op.Update(chunk) + sm4_op.Finish()
                    if mode == sm4_gcm_mode:
                        tag = cipher[-sm4_gcm_tag_len:]
                        cipher = cipher[:-sm4_gcm_tag_len]
                        cipher_with_tag = cipher + tag
                        if not common.validate_gcm_cipher_format(cipher_with_tag, sm4_gcm_tag_len):
                            click.echo('invalid gcm cipher format: cipher_with_tag length < tag_len')
                            return
                        output_size += len(cipher_with_tag)
                        if not output_to_file.write_bytes(cipher_with_tag):
                            return
                        click.echo('cipher size:{}\nkey:{}\niv:{}\ncipher:{}'.format(
                            output_size, key, iv_nonce,
                            base64.b64encode(cipher_with_tag).decode('utf-8')))
                    else:
                        output_size += len(cipher)
                        if not output_to_file.write_bytes(cipher):
                            return
                        click.echo('cipher size:{}\nkey:{}\niv:{}'.format(
                            output_size, key, iv_nonce))
                    break
                cipher = sm4_op.Update(chunk)
                output_size += len(cipher)
                if not output_to_file.write_bytes(cipher):
                    return
        if action == sm4_decrypt_action:
            try:
                if mode == sm4_gcm_mode and file_gcm_cipher_bytes is not None:
                    plain = sm4_op.Update(file_gcm_cipher_bytes + input_raw_tag) + sm4_op.Finish()
                    plain = remove_padding_data(plain)
                    if not output_to_file.write_bytes(plain):
                        return
                    click.echo('decrypt {} success\nwrite to {}\nplain size:{}'.format(
                        input_data, output_file, len(plain)))
                elif mode == sm4_gcm_mode:
                    all_cipher = input_from_file.read_n_bytes(file_size)
                    cipher_with_tag = all_cipher + input_raw_tag
                    plain = sm4_op.Update(cipher_with_tag) + sm4_op.Finish()
                    plain = remove_padding_data(plain)
                    if not output_to_file.write_bytes(plain):
                        return
                    click.echo('decrypt {} success\nwrite to {}\nplain size:{}'.format(
                        input_data, output_file, len(plain)))
                else:
                    if file_size < sm4_file_read_block or file_size % sm4_file_read_block != 0:
                        click.echo('invalid cipher file size:{} Bytes'.format(file_size))
                        return
                    while True:
                        chunk = input_from_file.read_n_bytes(read_size)
                        file_size -= len(chunk)
                        plain = sm4_op.Update(chunk)
                        if file_size == 0:
                            plain = plain + sm4_op.Finish()
                            plain = remove_padding_data(plain)
                            output_size += len(plain)
                            if not output_to_file.write_bytes(plain):
                                return
                            click.echo('decrypt {} success\nwrite to {}\nplain size:{}'.format(
                                input_data, output_file, output_size))
                            return
                        output_size += len(plain)
                        if not output_to_file.write_bytes(plain):
                            return
            except BaseException as e:
                click.echo('decrypt {} failed:{}'.format(input_data, e))
                return


if __name__ == '__main__':
    sm4_command()
