#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
ZUC 祖冲之流密码算法，用于流式加解密
密钥和 IV 均为 16 字节
"""
from __future__ import annotations

import base64
import os

import click

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import random_str
from easy_encryption_tool import command_perf

try:
    from easy_gmssl import EasyZuc
    from easy_gmssl.gmssl import ZUC_KEY_SIZE, ZUC_IV_SIZE
    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False
    ZUC_KEY_SIZE = 16
    ZUC_IV_SIZE = 16


def _check_gmssl():
    if not EASY_GMSSL_AVAILABLE:
        click.echo('ZUC 需要 easy_gmssl 库，请执行: pip install easy_gmssl')
        return False
    return True


def process_key_iv(is_random: bool, key: str, iv: str) -> tuple:
    if is_random:
        return random_str.generate_random_str(ZUC_KEY_SIZE), random_str.generate_random_str(ZUC_IV_SIZE)
    key_len = len(key)
    if key_len > ZUC_KEY_SIZE:
        key = key[:ZUC_KEY_SIZE]
    else:
        key = key + random_str.generate_random_str(ZUC_KEY_SIZE - key_len)
    if len(iv) > ZUC_IV_SIZE:
        iv = iv[:ZUC_IV_SIZE]
    elif len(iv) < ZUC_IV_SIZE:
        iv = iv + random_str.generate_random_str(ZUC_IV_SIZE - len(iv))
    return key, iv


@click.command(name='zuc', short_help='ZUC祖冲之流密码加解密工具')
@click.option('-k', '--key',
              required=False,
              type=click.STRING,
              default=cipherhub_defaults.DEFAULT_ZUC_KEY,
              help='密钥 16 字节，与 CipherHUB 兼容，不足补齐、超出截取')
@click.option('-v', '--iv',
              required=False,
              type=click.STRING,
              default=cipherhub_defaults.DEFAULT_ZUC_IV,
              help='IV 16 字节，与 CipherHUB 兼容，不足补齐、超出截取')
@click.option('-r', '--random-key-iv',
              required=False,
              type=click.BOOL,
              is_flag=True,
              default=False,
              help='随机生成密钥和 IV')
@click.option('-a', '--action',
              required=False,
              type=click.Choice(['encrypt', 'decrypt']),
              default='encrypt',
              show_default=True,
              help='加密或解密')
@click.option('-i', '--input-data',
              required=True,
              type=click.STRING,
              help='输入数据：字符串、base64 编码、文件路径')
@click.option('-e', '--is-base64-encoded',
              required=False,
              type=click.BOOL,
              is_flag=True,
              default=False,
              help='输入为 base64 编码，-e 与 -f 互斥')
@click.option('-f', '--is-a-file',
              required=False,
              type=click.BOOL,
              is_flag=True,
              default=False,
              help='输入为文件，-e 与 -f 互斥')
@click.option('-l', '--input-limit',
              required=False,
              type=click.INT,
              default=1,
              show_default=True,
              help='输入最大长度（MB），非文件时生效')
@click.option('-o', '--output-file',
              required=False,
              type=click.STRING,
              default='',
              help='输出文件，文件输入时必须指定')
@command_perf.timing_decorator
def zuc_command(key: str, iv: str, random_key_iv: bool, action: str,
                input_data: str, is_base64_encoded: bool, is_a_file: bool,
                input_limit: int, output_file: str):
    """ZUC 流密码加解密，密文与明文等长"""
    if not _check_gmssl():
        return

    key, iv = process_key_iv(random_key_iv, key, iv)

    if len(input_data) <= 0:
        click.echo('no input data, it is required')
        return

    if is_base64_encoded and is_a_file:
        click.echo('the input data cannot be used as both a file and base64 encoded data')
        return

    input_raw_bytes = b''
    input_from_file = None
    output_to_file = None

    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            click.echo('invalid b64 encoded data:{}'.format(e))
            return
        if len(input_raw_bytes) > input_limit * 1024 * 1024:
            click.echo('input exceeds limit:{} MB'.format(input_limit))
            return

    if is_a_file:
        try:
            input_from_file = common.read_from_file(input_data)
        except BaseException:
            click.echo('{} may not exist or may be unreadable'.format(input_data))
            return
        if len(output_file) <= 0:
            click.echo('need a output file specified and writable')
            return

    if not is_base64_encoded and not is_a_file:
        if len(input_data) > input_limit * 1024 * 1024:
            click.echo('input exceeds limit:{} MB'.format(input_limit))
            return
        input_raw_bytes = input_data.encode('utf-8')

    if len(output_file) > 0:
        try:
            output_to_file = common.write_to_file(output_file)
        except BaseException:
            click.echo('{} may not exist or may not writable'.format(output_file))
            return

    key_bytes = key.encode('utf-8')
    iv_bytes = iv.encode('utf-8')
    zuc_op = EasyZuc(key=key_bytes, iv=iv_bytes)

    if not is_a_file:
        result = zuc_op.Update(input_raw_bytes) + zuc_op.Finish()
        if action == 'encrypt':
            result_str = base64.b64encode(result).decode('utf-8')
            click.echo('key:{}\niv:{}\ninput_size:{}\noutput_size:{}\ncipher:{}'.format(
                key, iv, len(input_raw_bytes), len(result), result_str))
        else:
            be_str, ret = common.bytes_to_str(result)
            if be_str:
                click.echo('key:{}\niv:{}\ninput_size:{}\noutput_size:{}\nplain:{}'.format(
                    key, iv, len(input_raw_bytes), len(result), ret))
            else:
                click.echo('key:{}\niv:{}\ninput_size:{}\noutput_size:{}\nb64_plain:{}'.format(
                    key, iv, len(input_raw_bytes), len(result), ret))
        if output_to_file is not None and not output_to_file.write_bytes(result):
            return
    else:
        file_size = os.stat(input_data).st_size
        click.echo('input file size:{}'.format(file_size))
        output_size = 0
        while True:
            chunk = input_from_file.read_n_bytes(64 * 1024)
            if not chunk:
                break
            out_chunk = zuc_op.Update(chunk)
            output_size += len(out_chunk)
            if output_to_file and not output_to_file.write_bytes(out_chunk):
                return
        final = zuc_op.Finish()
        if final:
            output_size += len(final)
            if output_to_file and not output_to_file.write_bytes(final):
                return
        click.echo('output size:{}\nkey:{}\niv:{}'.format(output_size, key, iv))


if __name__ == '__main__':
    zuc_command()
