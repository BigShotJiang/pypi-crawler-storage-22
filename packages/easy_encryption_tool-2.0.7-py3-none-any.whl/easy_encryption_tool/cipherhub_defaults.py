#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
CipherHUB 兼容性默认参数
与 CipherHUB web_app 及 API 的默认值保持一致，确保相同算法、模式、输入参数下
easy_encryption_tool 与 CipherHUB 可相互加解密、签名验签，或得到一致的 hash/hmac
"""
from __future__ import annotations

# 默认明文（与 CipherHUB web_app 一致）
DEFAULT_PLAINTEXT = "你好，密码学人 CipherHUB!"

# 块密码 CBC 模式默认值（AES128/AES256/SM4）
DEFAULT_KEY_32 = "".join(
    [str(i % 10) for i in range(32)]
)  # 01234567890123456789012345678901
DEFAULT_KEY_16 = "".join([str(i % 10) for i in range(16)])  # 0123456789012345
DEFAULT_IV_16 = "".join([str(i % 10) for i in range(16)])  # 0123456789012345

# 流密码 GCM 模式默认值（AES256GCM/ChaCha20Poly1305/SM4GCM）
DEFAULT_NONCE_12 = "".join([str(i % 10) for i in range(12)])  # 012345678901234567890123
DEFAULT_AAD = "密码学人 CipherHUB 默认 AAD 数据"

# ZUC 默认值（key 和 iv 均为 16 字节）
DEFAULT_ZUC_KEY = DEFAULT_KEY_16
DEFAULT_ZUC_IV = DEFAULT_IV_16

# HMAC 默认 key（32 字节）
DEFAULT_HMAC_KEY = DEFAULT_KEY_32

# SM2 签名/验签默认用户标识（与 CipherHUB 一致，参与 Z 值计算）
DEFAULT_SM2_SIGNER_ID = "1234567812345678"

# ECC 密钥交换默认参数（与 CipherHUB api/ecc_key_exchange.py 一致）
DEFAULT_ECC_SALT = "密码学人【CipherHUB】"
DEFAULT_ECC_ADDITIONAL_INFO = """
    Serious Cryptography
    Creative Solutions
    Mapping Digital Trust
"""
DEFAULT_ECC_DERIVED_KEY_LENGTH = 32
DEFAULT_ECC_HASH = "sha512"  # CipherHUB ECC 默认 Sha512
