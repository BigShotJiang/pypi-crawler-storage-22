#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-01 09:11:56
from __future__ import annotations

import base64
import binascii
import os
import os.path
import sys
import tempfile
from typing import Tuple

import click
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization

from easy_encryption_tool import random_str


def decode_b64_data(data: str) -> bytes:
    """Base64 解码，严格模式：拒绝非法字符"""
    if len(data) <= 0:
        return bytes()
    # 严格模式：仅允许标准 base64 字符
    if sys.version_info >= (3, 11):
        try:
            return base64.b64decode(data, validate=True)
        except binascii.Error as e:
            raise ValueError("base64 解码失败（非法字符或格式错误）") from e
    else:
        allowed = set(
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\n\r "
        )
        if not all(c in allowed for c in data):
            raise ValueError("base64 输入包含非法字符")
        try:
            return base64.b64decode(data)
        except binascii.Error as e:
            raise ValueError("base64 解码失败") from e


def check_is_file_readable(input_data: str) -> bool:
    """检查文件是否存在以及是否可读"""
    return (
        os.path.exists(input_data)
        and os.access(input_data, mode=os.R_OK)
        and os.path.isfile(input_data)
    )


def check_is_file_writable(input_data: str, force: bool = True) -> bool:
    """
    检查路径是否可写。若文件已存在，force=True 时覆盖，force=False 时返回 False。
    默认 force=True 与 cp 等工具行为一致；显式传 force=False 可避免意外覆盖。
    """
    if not os.path.exists(input_data):
        try:
            with open(input_data, "w") as _:
                pass
            return True
        except OSError:
            return False
    if not os.path.isfile(input_data) or not os.access(input_data, os.W_OK):
        return False
    if not force:
        return False  # 已存在且未强制覆盖
    with open(input_data, "w") as file:
        file.truncate(0)
    return True


def process_key_iv(
    is_random: bool,
    key: str,
    iv: str,
    key_len: int,
    iv_len: int,
    nonce_len: int | None = None,
    mode: str | None = None,
) -> Tuple[str, str]:
    """
    统一密钥/IV 处理：随机生成或按长度补齐/截取（使用密码学安全随机补齐）。
    mode 为 'gcm' 时 iv 长度用 nonce_len，否则用 iv_len。
    """
    if is_random:
        key = random_str.generate_random_str(key_len)
        nlen = nonce_len if (mode == "gcm" and nonce_len is not None) else iv_len
        iv = random_str.generate_random_str(nlen)
        return key, iv
    # 截取或补齐
    if len(key) > key_len:
        key = key[:key_len]
    elif len(key) < key_len:
        key = key + random_str.generate_random_str(key_len - len(key))
    nlen = nonce_len if (mode == "gcm" and nonce_len is not None) else iv_len
    if len(iv) > nlen:
        iv = iv[:nlen]
    elif len(iv) < nlen:
        iv = iv + random_str.generate_random_str(nlen - len(iv))
    return key, iv


def validate_gcm_cipher_format(cipher_with_tag: bytes, tag_len: int) -> bool:
    """
    校验 GCM 密文格式是否符合标准（NIST SP 800-38D: ciphertext || tag）
    :param cipher_with_tag: 密文+tag 的完整字节流
    :param tag_len: tag 长度（通常 16 字节）
    :return: True 表示格式有效
    """
    if cipher_with_tag is None or len(cipher_with_tag) < tag_len:
        return False
    return True


def check_b64_data(input_data: str) -> Tuple[bool, bytes]:
    if len(input_data) <= 0:
        return False, b""
    try:
        ret = decode_b64_data(input_data)
    except (binascii.Error, ValueError):
        return False, b""
    else:
        if len(ret) <= 0:
            return False, b""
        return True, ret


class read_from_file:
    """支持 context manager 的文件读取，确保句柄正确关闭"""

    def __init__(self, file_path: str):
        self._opened = False
        self._path = file_path
        if not check_is_file_readable(file_path):
            raise OSError("read from file {} error".format(file_path))
        self._file = open(file_path, "rb")
        self._opened = True

    def read_n_bytes(self, n: int) -> bytes:
        return self._file.read(n)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def close(self):
        if self._opened:
            self._file.close()
            self._opened = False

    def __del__(self):
        self.close()


def _check_can_write_atomic(file_path: str, force: bool) -> bool:
    """检查路径是否可写（用于原子写入，不创建/截断目标文件）"""
    if os.path.exists(file_path):
        if not os.path.isfile(file_path) or not os.access(file_path, os.W_OK):
            return False
        if not force:
            return False
    else:
        parent = os.path.dirname(file_path)
        if parent and not os.path.exists(parent):
            return False
        if parent and not os.access(parent, os.W_OK):
            return False
    return True


class write_to_file:
    """支持 context manager 的文件写入，原子写入后 rename，避免部分写入"""

    def __init__(self, file_path: str, force: bool = True):
        self._opened = False
        self._path = os.path.abspath(file_path)
        if not _check_can_write_atomic(file_path, force=force):
            raise OSError("write to file {} error".format(file_path))
        parent_dir = os.path.dirname(self._path) or "."
        fd, self._temp_path = tempfile.mkstemp(
            dir=parent_dir, prefix=".tmp_", suffix=""
        )
        try:
            self._file = os.fdopen(fd, "wb")
        except BaseException:
            os.unlink(self._temp_path)
            raise
        self._opened = True

    def write_bytes(self, data: bytes) -> bool:
        try:
            if len(data) > 0:
                self._file.write(data)
                self._file.flush()
        except BaseException as e:
            click.echo("write to {} failed\n{}\n".format(self._path, e))
            return False
        return True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def close(self):
        if not self._opened:
            return
        self._opened = False
        try:
            self._file.close()
        finally:
            try:
                os.replace(self._temp_path, self._path)
            except OSError as e:
                click.echo("atomic rename to {} failed: {}".format(self._path, e))
            finally:
                if os.path.exists(self._temp_path):
                    try:
                        os.unlink(self._temp_path)
                    except OSError:
                        pass

    def __del__(self):
        self.close()


encoding_maps = {
    "pem": serialization.Encoding.PEM,
    "der": serialization.Encoding.DER,
    # 'ssh': serialization.Encoding.OpenSSH,
    # 'raw': serialization.Encoding.Raw,
    # 'smime': serialization.Encoding.SMIME,
    # 'x962': serialization.Encoding.X962,
}


def private_key_password(is_random: bool, password: str | None):
    enc = serialization.NoEncryption()
    if is_random:
        password = random_str.generate_random_str(32)
    if (
        password is not None and len(password) > 0
    ):  # 如果传入了密码，则在生成私钥文件时需要对私钥做加密
        enc = serialization.BestAvailableEncryption(password.encode("utf-8"))
    return password, enc


def load_public_key(encoding: str, file_path: str):
    try:
        pub_key = None
        with open(file_path, "rb") as key_file:
            if encoding == "pem":
                pub_key = serialization.load_pem_public_key(
                    key_file.read(), backend=default_backend()
                )
            if encoding == "der":
                pub_key = serialization.load_der_public_key(
                    key_file.read(), backend=default_backend()
                )
    except BaseException as e:
        click.echo("load public key:{} failed\nERROR:{}".format(file_path, e))
        return None
    else:
        return pub_key


def load_private_key(encoding: str, file_path: str, password_bytes: bytes):
    pri_key = None
    try:  # 读取私钥
        with open(file_path, "rb") as key_file:
            if encoding == "pem":
                pri_key = serialization.load_pem_private_key(
                    key_file.read(), backend=default_backend(), password=password_bytes
                )
            if encoding == "der":
                pri_key = serialization.load_der_private_key(
                    key_file.read(), backend=default_backend(), password=password_bytes
                )
    except BaseException as e:
        click.echo("load private key:{} failed:{}".format(file_path, e))
        return None
    else:
        return pri_key


def bytes_to_str(data: bytes) -> Tuple[bool, str]:
    if data is None:
        return False, ""
    try:
        ret = data.decode("utf-8")
    except BaseException:
        return False, base64.b64encode(data).decode("utf-8")
    else:
        return True, ret


def write_asymmetric_key(
    file_name_prefix: str,
    asymmetric_type: str,
    encoding_type: str,
    is_private_encrypted: bool,
    private_password: str,
    public_data: bytes,
    private_data: bytes,
) -> bool:
    if file_name_prefix is None or len(file_name_prefix) <= 0:
        return False

    if len(file_name_prefix) > 0:
        public_file = "{}_{}_public.{}".format(
            file_name_prefix, asymmetric_type, encoding_type
        )
        private_file = "{}_{}_private.{}".format(
            file_name_prefix, asymmetric_type, encoding_type
        )
        if (
            is_private_encrypted
            and private_password is not None
            and len(private_password) > 0
        ):
            private_file = "{}_{}_private_cipher.{}".format(
                file_name_prefix, asymmetric_type, encoding_type
            )
        for i in [public_file, private_file]:
            try:
                f = write_to_file(i)
            except BaseException as e:
                click.echo("write to {} failed:{}".format(i, e))
                return False
            else:
                if i == public_file:
                    if not f.write_bytes(public_data):
                        return False
                elif i == private_file:
                    if not f.write_bytes(private_data):
                        return False
                    if (
                        is_private_encrypted
                        and private_password is not None
                        and len(private_password) > 0
                    ):
                        click.echo("private key password:{}".format(private_password))
        click.echo("generate {}/{} success".format(public_file, private_file))
        return True
