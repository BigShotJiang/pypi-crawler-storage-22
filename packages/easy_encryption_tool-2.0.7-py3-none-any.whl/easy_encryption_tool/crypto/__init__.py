#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
密码学核心逻辑模块（预留扩展）
当前从 common 复用 process_key_iv 等，便于未来将 aes_operator、rsa_ops 等迁入
"""
from __future__ import annotations

from easy_encryption_tool.common import process_key_iv

__all__ = ["process_key_iv"]
