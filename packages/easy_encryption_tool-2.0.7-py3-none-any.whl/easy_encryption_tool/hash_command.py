#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
统一哈希命令，支持国密 SM3 及国际算法 SHA256、SHA384、SHA512
"""
from __future__ import annotations

import hashlib

import click

from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import command_perf
from easy_encryption_tool import validators

try:
    from easy_gmssl import EasySM3Digest

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False

hash_alg_map = {
    "sha256": hashlib.sha256,
    "sha384": hashlib.sha384,
    "sha512": hashlib.sha512,
}
if EASY_GMSSL_AVAILABLE:
    hash_alg_map["sm3"] = "sm3"


def _compute_hash_fixed(alg: str, data: bytes) -> bytes:
    if alg == "sm3":
        return EasySM3Digest.Hash(data)
    h = hash_alg_map[alg]()
    h.update(data)
    return h.digest()


@click.command(name="hash", short_help="哈希摘要工具，支持 SM3、SHA256、SHA384、SHA512")
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="输入数据，允许：字符串、base64 编码数据、文件路径",
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="输入被 base64 编码过，-e 与 -f 互斥",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=False,
    help="输入为文件路径，-e 与 -f 互斥",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    type=click.Choice(list(hash_alg_map.keys())),
    default="sha256",
    show_default=True,
    help="哈希算法",
)
@command_perf.timing_decorator
def hash_command(
    input_data: str, is_base64_encoded: bool, is_a_file: bool, hash_alg: str
):
    """计算哈希摘要。默认 -i 为 UTF-8 明文；-e 表示 base64；-f 表示文件。"""
    if hash_alg == "sm3" and not EASY_GMSSL_AVAILABLE:
        hints.hint_missing_gmssl("SM3")
        return

    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "hash")
    if not ok:
        click.echo(err)
        hints.hint_input_file_or_b64_conflict()
        return

    input_raw_bytes = b""
    if not is_a_file:
        if not is_base64_encoded:
            input_raw_bytes = input_data.encode("utf-8")
        else:
            try:
                input_raw_bytes = common.decode_b64_data(input_data)
            except BaseException as e:
                click.echo("invalid b64 encoded data:{}".format(e))
                hints.hint_invalid_b64("hash")
                return
        digest = _compute_hash_fixed(hash_alg, input_raw_bytes)
        click.echo(
            "hash_alg:{}\ndata_size:{}Bytes\nhash:{}".format(
                hash_alg, len(input_raw_bytes), digest.hex()
            )
        )
    else:
        try:
            with common.read_from_file(input_data) as input_file:
                if hash_alg == "sm3":
                    ctx = EasySM3Digest()
                    data_len = 0
                    while True:
                        chunk = input_file.read_n_bytes(4096)
                        if not chunk:
                            break
                        ctx.UpdateData(chunk)
                        data_len += len(chunk)
                    digest, _, _ = ctx.GetHash()
                else:
                    h = hash_alg_map[hash_alg]()
                    data_len = 0
                    while True:
                        chunk = input_file.read_n_bytes(4096)
                        if not chunk:
                            break
                        h.update(chunk)
                        data_len += len(chunk)
                    digest = h.digest()
                click.echo(
                    "hash_alg:{}\nfile_size:{}Bytes\nhash:{}".format(
                        hash_alg, data_len, digest.hex()
                    )
                )
        except OSError:
            click.echo("file {} may not exist or readable".format(input_data))
            return


if __name__ == "__main__":
    hash_command()
