#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
统一智能提示模块，用于依赖缺失、参数错误等场景的友好提示
"""

import click


def hint_missing_gmssl(feature: str) -> None:
    """
    统一格式的国密依赖缺失提示
    :param feature: 功能名称，如 "SM3"、"SM4"、"SM2"、"ZUC"、"国密证书解析"
    """
    click.echo(click.style(f"⚠ {feature} 需要 easy_gmssl 库", fg="yellow"))
    click.echo("  安装命令: pip install easy_gmssl")
    click.echo("  或: pip install easy-encryption-tool[gmssl]")


def hint_invalid_b64(context: str = "") -> None:
    """base64 解码失败时的示例提示"""
    prefix = f"  {context}：" if context else "  "
    click.echo(
        click.style(
            f"{prefix}解密时 -i 应为 base64 密文，可加 -e 表示输入已 base64 编码",
            fg="yellow",
        )
    )
    click.echo("  示例: easy_encryption_tool aes -a decrypt -i '密文...' -e")


def hint_input_file_or_b64_conflict() -> None:
    """-e 与 -f 互斥时的提示"""
    click.echo(
        click.style("  -e 与 -f 互斥：输入不能同时作为文件和 base64 数据", fg="yellow")
    )
    click.echo("  -e: 表示 -i 的值为 base64 编码；-f: 表示 -i 的值为文件路径")
