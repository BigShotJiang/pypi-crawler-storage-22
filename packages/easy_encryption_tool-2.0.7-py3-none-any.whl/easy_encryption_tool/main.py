#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-03-30 15:41:41

import difflib

import click

from easy_encryption_tool import (
    aes_command,
    cert_parse,
    ecc_command,
    hash_command,
    hmac_command,
    random_str,
    rsa_command,
    sm2_command,
    sm4_command,
    tool_version,
    zuc_command,
)

class SmartGroup(click.Group):
    """支持相似命令建议的 Group"""

    def resolve_command(self, ctx, args):
        cmd_name = args[0] if args else None
        try:
            return super().resolve_command(ctx, args)
        except click.UsageError as e:
            msg = str(e).lower()
            if cmd_name and ("no such command" in msg or "unknown command" in msg):
                suggestions = difflib.get_close_matches(
                    cmd_name, self.list_commands(ctx), n=3, cutoff=0.4
                )
                if suggestions:
                    click.echo(str(e))
                    click.echo(
                        click.style(
                            "  您是否想输入: " + ", ".join(suggestions) + " ?",
                            fg="yellow",
                        )
                    )
            raise


def _show_welcome():
    """无子命令时显示引导提示"""
    click.echo(click.style("易加密小工具 - 常用命令示例:", fg="cyan"))
    click.echo("  AES 加解密:    easy_encryption_tool aes -a encrypt -i 'hello'")
    click.echo("  生成随机串:    easy_encryption_tool random-str -l 32")
    click.echo("  哈希摘要:      easy_encryption_tool hash -i 'data' -a sha256")
    click.echo("  查看帮助:      easy_encryption_tool --help")


@click.group(
    name="easy_encryption_tool",
    short_help="易加密小工具",
    invoke_without_command=True,
    cls=SmartGroup,
)
@click.pass_context
def encryption_tool(ctx):
    """主入口：无子命令时显示引导，有子命令时由 Click 自动调用"""
    if ctx.invoked_subcommand is None:
        _show_welcome()
        return
    # 有子命令时由 Group 自动 invoke，此处无需手动调用


encryption_tool.add_command(tool_version.show_version)
encryption_tool.add_command(aes_command.aes_command)
encryption_tool.add_command(sm4_command.sm4_command)
encryption_tool.add_command(random_str.get_random_str)

encryption_tool.add_command(hash_command.hash_command)
encryption_tool.add_command(hmac_command.hmac_command)

rsa_command.rsa_group.add_command(rsa_command.generate_key_pair)
rsa_command.rsa_group.add_command(rsa_command.rsa_encrypt)
rsa_command.rsa_group.add_command(rsa_command.rsa_decrypt)
rsa_command.rsa_group.add_command(rsa_command.rsa_sign)
rsa_command.rsa_group.add_command(rsa_command.rsa_verify)
encryption_tool.add_command(rsa_command.rsa_group)

ecc_command.ecc_group.add_command(ecc_command.generate)
ecc_command.ecc_group.add_command(ecc_command.key_exchange)
ecc_command.ecc_group.add_command(ecc_command.ecc_sign)
ecc_command.ecc_group.add_command(ecc_command.ecc_verify)
encryption_tool.add_command(ecc_command.ecc_group)

encryption_tool.add_command(sm2_command.sm2_group)

encryption_tool.add_command(zuc_command.zuc_command)

encryption_tool.add_command(cert_parse.parse_x509_cert_file)


if __name__ == "__main__":
    encryption_tool()
