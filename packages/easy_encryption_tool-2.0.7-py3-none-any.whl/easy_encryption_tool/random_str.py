#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-01 09:04:43
"""
密码学安全随机数生成：使用 secrets 模块（CSPRNG）
"""
import secrets
import string
import sys

import click

from easy_encryption_tool import command_perf, common

special_characters = "&=!@#$%^*()_+`"
characters: str = (
    string.ascii_lowercase + string.ascii_uppercase + string.digits + special_characters
)


def generate_random_str(length: int) -> str:
    """使用 secrets 生成密码学安全随机字符串"""
    return "".join(secrets.choice(characters) for _ in range(length))


def generate_random_bytes(length: int) -> bytes:
    """生成密码学安全随机字节，用于密钥/IV 补齐等"""
    return secrets.token_bytes(length)


@click.command(name="random-str", short_help="随机字符串生成器")
@click.option(
    "-l",
    "--length",
    required=False,
    type=click.IntRange(min=1, max=sys.maxsize),
    default=32,
    show_default=True,
    help="最小生成一个字节字符串，最大长度由系统最大整型值决定",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="指定输出的文件，文件需要具有可写权限",
)
@click.option("--no-force", is_flag=True, default=False, help="不覆盖已存在的输出文件")
@command_perf.timing_decorator
def get_random_str(length: int, output_file: click.STRING, no_force: bool = False):
    write_to_output = None
    if output_file is not None and len(output_file) > 0:
        try:
            write_to_output = common.write_to_file(output_file, force=not no_force)
        except OSError as e:
            click.echo("try write to {} failed".format(output_file))
            return

    # 每次只生成 32 字节，避免字符串过长导致内存占用太多
    block_size = 32
    for i in range(0, length // block_size + 1):
        if length <= 0:
            break
        chunk_len = min(block_size, length)
        tmp = generate_random_str(chunk_len)
        if write_to_output is not None:
            if not write_to_output.write_bytes(tmp.encode("utf-8")):
                return
        else:
            click.echo(tmp, nl=False)
        length -= chunk_len
    if write_to_output is not None:
        click.echo("write to {} success".format(output_file))
    else:
        click.echo(nl=True)


if __name__ == "__main__":
    get_random_str()
