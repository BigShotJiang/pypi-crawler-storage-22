#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-02 12:48:05
import base64

import click
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa, utils as asym_utils

from easy_encryption_tool import command_perf, common

rsa_key_size = ["2048", "3072", "4096"]
rsa_encryption_mode = ["oaep", "pkcs1v15"]
rsa_sign_mode = ["pss", "pkcs1v15"]

rsa_hash_map = {
    hashes.SHA1().name: hashes.SHA1,
    hashes.SHA224().name: hashes.SHA224,
    hashes.SHA256().name: hashes.SHA256,
    hashes.SHA384().name: hashes.SHA384,
    hashes.SHA512().name: hashes.SHA512,
}

rsa_digest_size_map = {
    hashes.SHA1().name: hashes.SHA1().digest_size,
    hashes.SHA224().name: hashes.SHA224().digest_size,
    hashes.SHA256().name: hashes.SHA256().digest_size,
    hashes.SHA384().name: hashes.SHA384().digest_size,
    hashes.SHA512().name: hashes.SHA512().digest_size,
}

# CipherHUB 模式名称映射（RSAES_OAEP_SHA_256 -> oaep+sha256）
CIPHERHUB_RSA_ENC_MODE_MAP = {
    "RSAES_PKCS1_V1_5": "pkcs1v15",
    "RSAES_OAEP_SHA_1": "oaep",
    "RSAES_OAEP_SHA_224": "oaep",
    "RSAES_OAEP_SHA_256": "oaep",
    "RSAES_OAEP_SHA_384": "oaep",
    "RSAES_OAEP_SHA_512": "oaep",
}
CIPHERHUB_RSA_ENC_HASH_MAP = {
    "RSAES_OAEP_SHA_1": "sha1",
    "RSAES_OAEP_SHA_224": "sha224",
    "RSAES_OAEP_SHA_256": "sha256",
    "RSAES_OAEP_SHA_384": "sha384",
    "RSAES_OAEP_SHA_512": "sha512",
}


@click.group(name="rsa", short_help="rsa加解密和签名验签工具")
def rsa_group():
    pass


@click.command(name="generate")
@click.option(
    "-s",
    "--size",
    type=click.Choice(list(rsa_key_size)),
    required=False,
    default="2048",
    show_default=True,
    help="密钥位数",
)
@click.option(
    "-e",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="密钥格式",
)
@click.option(
    "-f",
    "--file-name",
    required=True,
    type=click.STRING,
    default="demo",
    show_default=True,
    help="输出密钥对的文件名前缀，最终写入数据时会创建文件并加上文件名后缀",
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    help="私钥密码，使用私钥时需要输入正确的密码",
)
@click.option(
    "-r",
    "--random-password",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="生成随机私钥密码（32字节），指定时 -p 可省略；私钥本身始终随机生成",
)
@command_perf.timing_decorator
def generate_key_pair(
    size: click.STRING,
    encoding: click.STRING,
    file_name: click.STRING,
    password: click.STRING,
    random_password: click.BOOL,
):
    password, enc = common.private_key_password(random_password, password)

    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=int(size),
    )
    public_key = private_key.public_key()
    private_encoding = private_key.private_bytes(
        encoding=common.encoding_maps[encoding],
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=enc,
    )
    public_encoding = public_key.public_bytes(
        encoding=common.encoding_maps[encoding],
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    if not common.write_asymmetric_key(
        file_name_prefix=file_name,
        asymmetric_type="rsa",
        encoding_type=encoding,
        is_private_encrypted=(password is not None and len(password) > 0),
        private_password=password,
        public_data=public_encoding,
        private_data=private_encoding,
    ):
        click.echo("rsa generated failed")
        return


def combine_if_not_empty(hash_mode: str, mode: str) -> str:
    if len(hash_mode) <= 0:
        return mode
    return "{}-{}".format(mode, hash_mode)


def get_encryption_max_plain_length(
    mode: str, key_length: int, hash_length: int
) -> int:
    """
    对于 OAEP（Optimal Asymmetric Encryption Padding）填充方案，
    如果使用的是 SHA-256 哈希函数，那么明文的最大长度等于密钥长度减去 2 倍的哈希长度再减去 2。
    例如，如果你使用的是 2048 位的 RSA 密钥，那么明文的最大长度就是 256 字节（2048 位）减去 2*32 字节（SHA-256 的输出长度）再减去 2，即 190 字节。
    对于 PKCS#1 v1.5 填充方案，明文的最大长度等于密钥长度减去 11 字节（这是为了留出足够的空间来存放必要的填充数据）。
    例如，如果你使用的是 2048 位的 RSA 密钥，那么明文的最大长度就是 256 字节（2048 位）减去 11 字节，即 245 字节。
    """
    if mode == "oaep":
        return key_length - 2 * hash_length - 2
    if mode == "pkcs1v15":
        return key_length - 11
    pass


@click.command(name="encrypt")
@click.option(
    "-f", "--public-key", required=True, type=click.STRING, help="公钥文件路径"
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="输入数据，可以直接为字符串，也可以为 base64编码的数据，base64编码的数据需要带上标识 -c",
)
@click.option(
    "-e",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="密钥格式",
)
@click.option(
    "-c",
    "--b64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入数据是否被 base64 编码过",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="输入内容最大长度，单位为 MB，默认为 1MB，非对称不适合直接加密过长的数据",
)
@click.option(
    "-m",
    "--mode",
    required=False,
    default="oaep",
    show_default=True,
    type=click.Choice(rsa_encryption_mode),
    help="加密时的填充模式，默认 oaep",
)
@click.option(
    "-h",
    "--hash-mode",
    required=False,
    default="sha256",
    show_default=True,
    type=click.Choice(list(rsa_hash_map.keys())),
    help="此参数仅在-m为 oaep 时生效",
)
@command_perf.timing_decorator
def rsa_encrypt(
    public_key: click.STRING,
    encoding: click.STRING,
    input_data: click.STRING,
    b64_encoded: click.STRING,
    input_limit: click.INT,
    hash_mode: click.STRING,
    mode: click.STRING,
):
    if b64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            click.echo(
                "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
            )
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    if len(input_raw_bytes) > input_limit * 1024 * 1024:
        click.echo(
            "the data exceeds the maximum bytes limit, limited to:{}Bytes, now:{}Bytes".format(
                input_limit * 1024 * 1024, len(input_raw_bytes)
            )
        )
        return

    pub_key = common.load_public_key(encoding=encoding, file_path=public_key)
    if pub_key is None:
        return
    max_plain_size = get_encryption_max_plain_length(
        mode, pub_key.key_size // 8, rsa_digest_size_map[hash_mode]
    )
    click.echo(
        "rsa key size:{} bytes, hash digest size:{} bytes, allowed max plain size:{} bytes, input plain:{} bytes".format(
            pub_key.key_size,
            rsa_digest_size_map[hash_mode],
            max_plain_size,
            len(input_raw_bytes),
        )
    )
    if len(input_raw_bytes) > max_plain_size:
        click.echo(
            "plain size:{} exceeds max allowed:{} bytes for mode {}".format(
                len(input_raw_bytes),
                max_plain_size,
                combine_if_not_empty(hash_mode, mode),
            )
        )
        return
    cipher = None
    if mode == "oaep":
        rsa_oaep_padding = padding.OAEP(
            mgf=padding.MGF1(algorithm=rsa_hash_map[hash_mode]()),
            algorithm=rsa_hash_map[hash_mode](),
            label=None,
        )
        cipher = pub_key.encrypt(plaintext=input_raw_bytes, padding=rsa_oaep_padding)
    if mode == "pkcs1v15":
        hash_mode = ""
        cipher = pub_key.encrypt(plaintext=input_raw_bytes, padding=padding.PKCS1v15())
    click.echo(
        "padding mode:{}\ncipher:{}".format(
            combine_if_not_empty(hash_mode, mode),
            base64.b64encode(cipher).decode("utf-8"),
        )
    )
    return


@click.command(name="decrypt")
@click.option(
    "-f", "--private-key", required=True, type=click.STRING, help="私钥文件路径"
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="输入的密文数据， 必须为base64编码的数据",
)
@click.option(
    "-e",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="密钥格式",
)
@click.option(
    "-m",
    "--mode",
    required=False,
    default="oaep",
    show_default=True,
    type=click.Choice(rsa_encryption_mode),
    help="加密时的填充模式，默认 oaep",
)
@click.option(
    "-h",
    "--hash-mode",
    required=False,
    default="sha256",
    show_default=True,
    type=click.Choice(list(rsa_hash_map.keys())),
    help="此参数仅在-m为 oaep 时生效",
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default="",
    help="私钥密码，使用私钥时需要输入正确的密码",
)
@command_perf.timing_decorator
def rsa_decrypt(
    private_key: click.STRING,
    input_data: click.STRING,
    encoding: click.STRING,
    mode: click.STRING,
    hash_mode: click.STRING,
    password: click.STRING,
):
    if password is not None and len(password) > 0:
        password_bytes = password.encode("utf-8")
    else:
        password_bytes = None
    plain = None
    try:  # 密文解码
        input_raw_bytes = common.decode_b64_data(input_data)
    except BaseException as e:
        click.echo(
            "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
        )
        return
    else:
        pri_key = common.load_private_key(
            encoding=encoding, file_path=private_key, password_bytes=password_bytes
        )
        if pri_key is None:
            return
        try:  # 使用私钥根据加密模式解密数据
            if mode == "oaep":
                rsa_oaep_padding = padding.OAEP(
                    mgf=padding.MGF1(algorithm=rsa_hash_map[hash_mode]()),
                    algorithm=rsa_hash_map[hash_mode](),
                    label=None,
                )
                plain = pri_key.decrypt(input_raw_bytes, rsa_oaep_padding)
            if mode == "pkcs1v15":
                hash_mode = ""
                plain = pri_key.decrypt(input_raw_bytes, padding.PKCS1v15())
        except BaseException:
            click.echo(
                "decrypt failed (invalid ciphertext or key/mode mismatch)\nmode: {}".format(
                    combine_if_not_empty(hash_mode, mode)
                )
            )
            return
        else:  # 判断解密的明文是否为字符串
            padding_mode = combine_if_not_empty(hash_mode, mode)
            click.echo("key size: {}".format(pri_key.key_size))
            be_str, ret = common.bytes_to_str(plain)
            if not be_str:
                click.echo(
                    "padding mode:{}\nb64 encoded plain (base64):{}".format(padding_mode, ret)
                )
                return
            else:
                click.echo("padding mode:{}\norigin plain (original):{}".format(padding_mode, ret))
                return


@click.command(name="sign")
@click.option(
    "-f", "--private-key", required=True, type=click.STRING, help="私钥文件路径"
)
@click.option(
    "-e",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="密钥格式",
)
@click.option(
    "-m",
    "--mode",
    required=True,
    default="pss",
    show_default=True,
    type=click.Choice(rsa_sign_mode),
    help="签名时的填充模式",
)
@click.option(
    "-h",
    "--hash-mode",
    required=False,
    default="sha256",
    show_default=True,
    type=click.Choice(list(rsa_hash_map.keys())),
    help="签名时的哈希算法",
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default="",
    help="私钥密码，使用私钥时需要输入正确的密码",
)
@click.option(
    "-i", "--input-data", required=True, type=click.STRING, help="需要被签名的数据"
)
@click.option(
    "-c",
    "--b64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入数据是否被 base64 编码过",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入为预计算的摘要值（非原始数据），需与 -h 指定的哈希算法长度一致",
)
@command_perf.timing_decorator
def rsa_sign(
    private_key: click.STRING,
    input_data: click.STRING,
    mode: click.STRING,
    hash_mode: click.STRING,
    password: click.STRING,
    encoding: click.STRING,
    b64_encoded: click.BOOL,
    input_is_digest: click.BOOL,
):
    password_bytes = None
    if password is not None and len(password) > 0:
        password_bytes = password.encode("utf-8")
    else:
        password_bytes = None

    if b64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            click.echo(
                "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
            )
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    digest_size = rsa_digest_size_map[hash_mode]
    if input_is_digest:
        if len(input_raw_bytes) != digest_size:
            click.echo(
                "input-is-digest 模式下，输入长度必须为 {} 字节（{} 摘要长度），当前: {} 字节".format(
                    digest_size, hash_mode, len(input_raw_bytes)
                )
            )
            return

    pri_key = common.load_private_key(
        encoding=encoding, file_path=private_key, password_bytes=password_bytes
    )
    if pri_key is None:
        return
    # 使用私钥根据签名填充模式进行签名（区分原始数据与预计算摘要）
    try:
        signature = b""
        hash_alg = rsa_hash_map[hash_mode]()
        sign_algorithm = asym_utils.Prehashed(hash_alg) if input_is_digest else hash_alg
        if mode == "pss":
            rsa_pss_padding = padding.PSS(
                mgf=padding.MGF1(algorithm=hash_alg), salt_length=padding.PSS.MAX_LENGTH
            )
            signature = pri_key.sign(
                input_raw_bytes,
                rsa_pss_padding,
                sign_algorithm,
            )
        if mode == "pkcs1v15":
            signature = pri_key.sign(
                input_raw_bytes,
                padding.PKCS1v15(),
                sign_algorithm,
            )
    except BaseException as e:
        click.echo(
            "sign failed: {}\nmode: {}".format(
                e, combine_if_not_empty(hash_mode, mode)
            )
        )
    else:
        click.echo(
            "key size:{}\nsignature:{}\n{}\nbase64 encoded:{}\nmode:{}".format(
                pri_key.key_size,
                signature.hex(),
                "-" * 16,
                base64.b64encode(signature).decode("utf-8"),
                combine_if_not_empty(hash_mode, mode),
            )
        )


@click.command(name="verify")
@click.option(
    "-f", "--public-key", required=True, type=click.STRING, help="公钥文件路径"
)
@click.option(
    "-e",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="密钥格式",
)
@click.option(
    "-m",
    "--mode",
    required=True,
    default="pss",
    show_default=True,
    type=click.Choice(rsa_sign_mode),
    help="签名时的填充模式",
)
@click.option(
    "-h",
    "--hash-mode",
    required=False,
    default="sha256",
    show_default=True,
    type=click.Choice(list(rsa_hash_map.keys())),
    help="签名时的哈希算法",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="需要被验签的数据（原始数据或摘要值，由 -d 区分）",
)
@click.option(
    "-c",
    "--b64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入数据是否被 base64 编码过",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入为预计算的摘要值（非原始数据），需与 -h 指定的哈希算法长度一致",
)
@click.option(
    "-s", "--signature", required=True, type=click.STRING, help="base64 编码过的签名值"
)
@command_perf.timing_decorator
def rsa_verify(
    public_key: click.STRING,
    input_data: click.STRING,
    b64_encoded: click.BOOL,
    signature: click.STRING,
    mode: click.STRING,
    hash_mode: click.STRING,
    encoding: click.STRING,
    input_is_digest: click.BOOL,
):
    if not signature or len(signature.strip()) <= 0:
        click.echo("signature 不能为空")
        return
    if b64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            click.echo(
                "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
            )
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    digest_size = rsa_digest_size_map[hash_mode]
    if input_is_digest:
        if len(input_raw_bytes) != digest_size:
            click.echo(
                "input-is-digest 模式下，输入长度必须为 {} 字节（{} 摘要长度），当前: {} 字节".format(
                    digest_size, hash_mode, len(input_raw_bytes)
                )
            )
            return

    try:
        signature_raw_bytes = common.decode_b64_data(signature)
    except BaseException as e:
        click.echo("invalid b64 encoded signature, decoded failed:{}".format(e))
        return
    if len(signature_raw_bytes) <= 0:
        click.echo("signature 解码后为空")
        return

    pub_key = common.load_public_key(encoding=encoding, file_path=public_key)
    if pub_key is None:
        return
    # 使用公钥根据签名验证（区分原始数据与预计算摘要）
    hash_alg = rsa_hash_map[hash_mode]()
    verify_algorithm = asym_utils.Prehashed(hash_alg) if input_is_digest else hash_alg
    try:
        if mode == "pss":
            rsa_pss_padding = padding.PSS(
                mgf=padding.MGF1(algorithm=hash_alg), salt_length=padding.PSS.MAX_LENGTH
            )
            pub_key.verify(
                signature_raw_bytes,
                input_raw_bytes,
                rsa_pss_padding,
                verify_algorithm,
            )
        if mode == "pkcs1v15":
            pub_key.verify(
                signature_raw_bytes,
                input_raw_bytes,
                padding.PKCS1v15(),
                verify_algorithm,
            )
    except InvalidSignature as e:
        click.echo(
            "{}\nInvalidSignature!\nkey size:{}\nmode:{}".format(
                "-" * 16, pub_key.key_size, combine_if_not_empty(hash_mode, mode)
            )
        )
    else:
        click.echo(
            "verify success\nkey size:{}\nmode:{}".format(
                pub_key.key_size, combine_if_not_empty(hash_mode, mode)
            )
        )


if __name__ == "__main__":
    rsa_group.add_command(generate_key_pair)
    rsa_group.add_command(rsa_encrypt)
    rsa_group.add_command(rsa_decrypt)
    rsa_group.add_command(rsa_sign)
    rsa_group.add_command(rsa_verify)
    rsa_group()
