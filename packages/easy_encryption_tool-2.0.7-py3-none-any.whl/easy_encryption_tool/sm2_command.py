#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
SM2 国密非对称算法，对标 RSA
支持加解密（多种密文格式）和签名验签（多种签名值格式）
"""
from __future__ import annotations

import base64

import click

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import command_perf
from easy_encryption_tool import common
from easy_encryption_tool import hints

try:
    from easy_gmssl import (
        EasySm2EncryptionKey,
        EasySM2SignKey,
        EasySM2VerifyKey,
        SM2CipherMode,
        SM2CipherFormat,
        SignatureMode,
    )
    from easy_gmssl.gmssl import SM2_DEFAULT_ID, SM3_DIGEST_SIZE

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False
    SM3_DIGEST_SIZE = 32  # SM3 摘要固定 32 字节

sm2_cipher_modes = ["C1C3C2_ASN1", "C1C3C2", "C1C2C3_ASN1", "C1C2C3"]
sm2_cipher_format_choices = ["base64", "hex"]
sm2_signature_modes = ["RS_ASN1", "RS"]


def _check_gmssl():
    if not EASY_GMSSL_AVAILABLE:
        hints.hint_missing_gmssl("SM2")
        return False
    return True


def _cipher_mode_from_str(s: str) -> SM2CipherMode:
    return SM2CipherMode(s)


def _cipher_format_from_str(s: str) -> SM2CipherFormat:
    return SM2CipherFormat.Base64Str if s == "base64" else SM2CipherFormat.HexStr


def _signature_mode_from_str(s: str) -> SignatureMode:
    return SignatureMode.RS_ASN1 if s == "RS_ASN1" else SignatureMode.RS


def _format_sm2_signature(sig_asn1: bytes, signature_mode: str) -> bytes:
    """将 SignDigest 返回的 ASN1 签名按 signature_mode 格式化"""
    if signature_mode == "RS_ASN1":
        return sig_asn1
    # RS 格式：解析 ASN1 得到 r||s (各 32 字节)
    from pyasn1.codec.der import decoder
    from easy_gmssl import SM2_RS_ASN1_Signature

    decoded, _ = decoder.decode(sig_asn1, asn1Spec=SM2_RS_ASN1_Signature())
    r_int, s_int = int(decoded["r"]), int(decoded["s"])
    return r_int.to_bytes(32, "big") + s_int.to_bytes(32, "big")


def _normalize_hex_input(s: str) -> str:
    """去除 hex 字符串的 0x/0X 前缀及首尾空白，便于 bytes.fromhex 解析"""
    s = s.strip()
    if s.lower().startswith("0x"):
        s = s[2:].strip()
    return s


def _sig_bytes_to_asn1_for_verify(sig_bytes: bytes, signature_mode: str) -> bytes:
    """验签前将 RS 格式签名转为 ASN1（VerifyDigestSignature 需要 ASN1）"""
    if signature_mode == "RS_ASN1":
        return sig_bytes
    if len(sig_bytes) != 64:
        raise ValueError("RS 格式签名必须为 64 字节")
    from pyasn1.codec.der import encoder
    from easy_gmssl import SM2_RS_ASN1_Signature

    r_int = int.from_bytes(sig_bytes[:32], "big")
    s_int = int.from_bytes(sig_bytes[32:], "big")
    sig_obj = SM2_RS_ASN1_Signature()
    sig_obj.setComponentByName("r", r_int)
    sig_obj.setComponentByName("s", s_int)
    return encoder.encode(sig_obj)


@click.group(name="sm2", short_help="sm2国密加解密和签名验签工具")
def sm2_group():
    pass


@click.command(name="generate")
@click.option(
    "-f",
    "--file-name",
    required=True,
    type=click.STRING,
    default="demo",
    show_default=True,
    help="输出密钥对的文件名前缀",
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default=None,
    help="私钥密码，SM2 私钥必须加密存储，长度 1-32 字节；指定 -r 时可省略",
)
@click.option(
    "-r",
    "--random-password",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="生成随机私钥密码（32 字节），指定时 -p 可省略",
)
@command_perf.timing_decorator
def sm2_generate(file_name: str, password: str, random_password: bool):
    """生成 SM2 密钥对（私钥随机生成，-r 时额外生成随机密码）"""
    if not _check_gmssl():
        return
    if random_password:
        from easy_encryption_tool import random_str

        password = random_str.generate_random_str(32)
    if password is None or len(password) <= 0 or len(password) > 32:
        click.echo("SM2 私钥密码长度需在 1-32 字节之间（指定 -r 可自动生成随机密码）")
        return
    try:
        key = EasySm2EncryptionKey()
        key.NewKey()
        key.ExportToPemFile(file_name_prefix=file_name, pri_key_password=password)
        click.echo(
            "generate {}_sm2_public.pem / {}_sm2_private.pem success".format(
                file_name, file_name
            )
        )
        if random_password:
            click.echo("private key password:{}".format(password))
    except BaseException as e:
        click.echo("sm2 generate failed:{}".format(e))


@click.command(name="encrypt")
@click.option(
    "-f",
    "--public-key",
    required=True,
    type=click.STRING,
    help="公钥文件路径（PEM 格式）",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="输入数据，可直接为字符串或 base64 编码（需 -c）",
)
@click.option(
    "-c",
    "--b64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入数据是否 base64 编码",
)
@click.option(
    "-m",
    "--cipher-mode",
    required=False,
    type=click.Choice(sm2_cipher_modes),
    default="C1C3C2_ASN1",
    show_default=True,
    help="密文格式",
)
@click.option(
    "-o",
    "--output-format",
    required=False,
    type=click.Choice(sm2_cipher_format_choices),
    default="base64",
    show_default=True,
    help="输出格式：base64 或 hex",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="输入最大长度（MB）",
)
@command_perf.timing_decorator
def sm2_encrypt(
    public_key: str,
    input_data: str,
    b64_encoded: bool,
    cipher_mode: str,
    output_format: str,
    input_limit: int,
):
    """SM2 公钥加密"""
    if not _check_gmssl():
        return
    if b64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            click.echo("invalid b64 encoded data:{}".format(e))
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")
    if len(input_raw_bytes) > input_limit * 1024 * 1024:
        click.echo("input exceeds limit:{} MB".format(input_limit))
        return
    try:
        enc_key = EasySm2EncryptionKey()
        enc_key.LoadSm2PubKey(public_key)
        cipher = enc_key.Encrypt(
            plain_data=input_raw_bytes,
            cipher_mode=_cipher_mode_from_str(cipher_mode),
            cipher_format=_cipher_format_from_str(output_format),
        )
        click.echo(
            "cipher_mode:{}\noutput_format:{}\ncipher:{}".format(
                cipher_mode, output_format, cipher
            )
        )
    except BaseException as e:
        click.echo("sm2 encrypt failed:{}".format(e))


@click.command(name="decrypt")
@click.option(
    "-f",
    "--private-key",
    required=True,
    type=click.STRING,
    help="私钥文件路径（PEM 格式）",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="密文数据，需 base64 或 hex 编码",
)
@click.option(
    "-x",
    "--hex-input",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入为 hex 编码（默认 base64）",
)
@click.option(
    "-m",
    "--cipher-mode",
    required=False,
    type=click.Choice(sm2_cipher_modes),
    default="C1C3C2_ASN1",
    show_default=True,
    help="密文格式，需与加密时一致",
)
@click.option("-p", "--password", required=True, type=click.STRING, help="私钥密码")
@command_perf.timing_decorator
def sm2_decrypt(
    private_key: str, input_data: str, hex_input: bool, cipher_mode: str, password: str
):
    """SM2 私钥解密"""
    if not _check_gmssl():
        return
    try:
        if hex_input:
            cipher_bytes = bytes.fromhex(_normalize_hex_input(input_data))
        else:
            cipher_bytes = common.decode_b64_data(input_data)
    except ValueError as e:
        click.echo("invalid input data (hex 需偶数长度且仅含 0-9a-fA-F): {}".format(e))
        return
    except BaseException as e:
        click.echo("invalid input data: {}".format(e))
        return
    try:
        dec_key = EasySm2EncryptionKey()
        dec_key.LoadSm2PrivateKey(pri_key_file=private_key, password=password)
        plain = dec_key.Decrypt(
            cipher_data=cipher_bytes,
            cipher_mode=_cipher_mode_from_str(cipher_mode),
        )
        be_str, ret = common.bytes_to_str(plain)
        if be_str:
            click.echo("cipher_mode:{}\nplain (original):{}".format(cipher_mode, ret))
        else:
            click.echo("cipher_mode:{}\nb64_plain (base64):{}".format(cipher_mode, ret))
    except BaseException as e:
        click.echo("sm2 decrypt failed:{}".format(e))


@click.command(name="sign")
@click.option(
    "-f", "--private-key", required=True, type=click.STRING, help="私钥文件路径"
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="待签名数据（原始数据或 SM3 摘要，由 -d 区分）",
)
@click.option(
    "-c",
    "--b64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入数据 base64 编码",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入为 SM3 预计算摘要（32 字节），非原始数据；与 CipherHUB sign_raw_data_mode=False 一致",
)
@click.option(
    "-m",
    "--signature-mode",
    required=False,
    type=click.Choice(sm2_signature_modes),
    default="RS_ASN1",
    show_default=True,
    help="签名值格式：RS_ASN1(DER) 或 RS(64字节 r||s)",
)
@click.option("-p", "--password", required=True, type=click.STRING, help="私钥密码")
@click.option(
    "--signer-id",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_SM2_SIGNER_ID,
    show_default=True,
    help="SM2 签名用户标识，与 CipherHUB 默认一致",
)
@command_perf.timing_decorator
def sm2_sign(
    private_key: str,
    input_data: str,
    b64_encoded: bool,
    signature_mode: str,
    password: str,
    signer_id: str,
    input_is_digest: bool,
):
    """SM2 私钥签名（支持原始数据与 SM3 摘要，参考 CipherHUB）"""
    if not _check_gmssl():
        return
    if b64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            click.echo("invalid b64 encoded data:{}".format(e))
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    if input_is_digest:
        if len(input_raw_bytes) != SM3_DIGEST_SIZE:
            click.echo(
                "input-is-digest 模式下，输入必须为 SM3 摘要（{} 字节），当前: {} 字节".format(
                    SM3_DIGEST_SIZE, len(input_raw_bytes)
                )
            )
            return

    try:
        if input_is_digest:
            # 对摘要签名：使用 EasySm2EncryptionKey.SignDigest，与 CipherHUB 一致
            key = EasySm2EncryptionKey()
            key.LoadSm2PrivateKey(pri_key_file=private_key, password=password)
            sig_asn1 = key.SignDigest(input_raw_bytes)
            sig = _format_sm2_signature(sig_asn1, signature_mode)
        else:
            # 对原始数据签名：使用 EasySM2SignKey
            sign_key = EasySM2SignKey(
                signer_id=signer_id,
                pem_private_key_file=private_key,
                password=password,
            )
            sign_key.UpdateData(input_raw_bytes)
            sig = sign_key.GetSignValue(
                signature_mode=_signature_mode_from_str(signature_mode)
            )
        click.echo(
            "signature_mode:{}\nsignature_hex:{}\nsignature_b64:{}".format(
                signature_mode, sig.hex(), base64.b64encode(sig).decode("utf-8")
            )
        )
    except BaseException as e:
        click.echo("sm2 sign failed:{}".format(e))


@click.command(name="verify")
@click.option(
    "-f", "--public-key", required=True, type=click.STRING, help="公钥文件路径"
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="被验签的数据（原始数据或 SM3 摘要，由 -d 区分）",
)
@click.option(
    "-c",
    "--b64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入数据 base64 编码",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="输入为 SM3 预计算摘要（32 字节），非原始数据；与 CipherHUB sign_raw_data_mode=False 一致",
)
@click.option(
    "-s",
    "--signature",
    required=True,
    type=click.STRING,
    help="签名值，base64 或 hex 编码（不能为空）",
)
@click.option(
    "-m",
    "--signature-mode",
    required=False,
    type=click.Choice(sm2_signature_modes),
    default="RS_ASN1",
    show_default=True,
    help="签名值格式",
)
@click.option("--sig-b64/--sig-hex", default=True, help="签名值为 base64（默认）或 hex")
@click.option(
    "--signer-id",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_SM2_SIGNER_ID,
    show_default=True,
    help="SM2 签名用户标识，与 CipherHUB 默认一致",
)
@command_perf.timing_decorator
def sm2_verify(
    public_key: str,
    input_data: str,
    b64_encoded: bool,
    signature: str,
    signature_mode: str,
    sig_b64: bool,
    signer_id: str,
    input_is_digest: bool,
):
    """SM2 公钥验签（支持原始数据与 SM3 摘要，参考 CipherHUB）"""
    if not _check_gmssl():
        return
    if not signature or len(signature.strip()) <= 0:
        click.echo("signature 不能为空")
        return
    if b64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            click.echo("invalid b64 encoded data:{}".format(e))
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    if input_is_digest:
        if len(input_raw_bytes) != SM3_DIGEST_SIZE:
            click.echo(
                "input-is-digest 模式下，输入必须为 SM3 摘要（{} 字节），当前: {} 字节".format(
                    SM3_DIGEST_SIZE, len(input_raw_bytes)
                )
            )
            return

    try:
        if sig_b64:
            sig_bytes = common.decode_b64_data(signature)
        else:
            sig_bytes = bytes.fromhex(_normalize_hex_input(signature))
    except ValueError as e:
        click.echo("invalid signature (hex 需偶数长度且仅含 0-9a-fA-F): {}".format(e))
        return
    except BaseException as e:
        click.echo("invalid signature: {}".format(e))
        return
    if len(sig_bytes) <= 0:
        click.echo("signature 解码后为空")
        return
    try:
        if input_is_digest:
            # 对摘要验签：使用 EasySm2EncryptionKey.VerifyDigestSignature
            key = EasySm2EncryptionKey()
            key.LoadSm2PubKey(public_key)
            sig_asn1 = _sig_bytes_to_asn1_for_verify(sig_bytes, signature_mode)
            ok = key.VerifyDigestSignature(input_raw_bytes, sig_asn1)
        else:
            verify_key = EasySM2VerifyKey(
                signer_id=signer_id,
                pem_public_key_file=public_key,
            )
            verify_key.UpdateData(input_raw_bytes)
            ok = verify_key.VerifySignature(
                signature_data=sig_bytes,
                signature_mode=_signature_mode_from_str(signature_mode),
            )
        if ok:
            click.echo("verify success\nsignature_mode:{}".format(signature_mode))
        else:
            click.echo("verify failed\nsignature_mode:{}".format(signature_mode))
    except BaseException as e:
        click.echo("sm2 verify failed:{}".format(e))


sm2_group.add_command(sm2_generate)
sm2_group.add_command(sm2_encrypt)
sm2_group.add_command(sm2_decrypt)
sm2_group.add_command(sm2_sign)
sm2_group.add_command(sm2_verify)
