#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
集中化参数校验模块
- -e (base64) 与 -f (文件) 互斥
- 文件输入时必须指定输出文件
- 输入来源校验与提示
"""
from __future__ import annotations

import re
from typing import Callable, Optional, Tuple

import click


def validate_b64_or_file(
    is_base64: bool,
    is_file: bool,
    context: str = "",
) -> Tuple[bool, Optional[str]]:
    """
    校验 -e (base64) 与 -f (文件) 互斥。
    :return: (是否通过, 错误信息)
    """
    if is_base64 and is_file:
        msg = "输入不能同时作为 base64 编码和文件路径，-e 与 -f 互斥"
        if context:
            msg = f"{context}: {msg}"
        return False, msg
    return True, None


def validate_file_output_required(
    is_file: bool,
    output_file: str,
    context: str = "",
) -> Tuple[bool, Optional[str]]:
    """
    校验：当输入为文件时，必须指定输出文件。
    """
    if is_file and (not output_file or len(output_file.strip()) == 0):
        msg = "输入为文件时必须指定输出文件 (-o/--output-file)"
        if context:
            msg = f"{context}: {msg}"
        return False, msg
    return True, None


def looks_like_base64(s: str) -> bool:
    """简单启发式：字符串是否可能为 base64 编码"""
    if not s or len(s) < 16:
        return False
    s_clean = s.replace("\n", "").replace("\r", "").replace(" ", "")
    if len(s_clean) % 4 not in (0, 2):  # base64 长度通常为 4 的倍数
        return False
    return bool(re.match(r"^[A-Za-z0-9+/]+=*$", s_clean))


def hint_decrypt_maybe_b64(input_preview: str, context: str = "解密") -> str:
    """
    当解密失败且输入可能为 base64 时，返回提示信息。
    """
    if looks_like_base64(input_preview[:64] if len(input_preview) > 64 else input_preview):
        return f"  {context}时 -i 应为 base64 密文，请加 -e 表示输入已 base64 编码"
    return ""


# 统一 base64 参数名：推荐使用 -e/--is-base64-encoded 或 -c/--b64-encoded
# RSA/ECC 使用 -c/--b64-encoded，AES/SM4/ZUC/HMAC/Hash 使用 -e/--is-base64-encoded
# 为保持兼容，不强制统一，但在 help 中说明两者等价含义
