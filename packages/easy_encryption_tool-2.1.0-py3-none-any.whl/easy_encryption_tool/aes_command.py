#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-03-30 15:53:00
from __future__ import annotations

import base64
import json
import os
from typing import Tuple

import click
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import algorithms, Cipher, modes

from cryptography.exceptions import InvalidTag

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import random_str
from easy_encryption_tool import command_perf
from easy_encryption_tool import validators

algorithm: str = "aes"

aes_block_in_bytes = algorithms.AES.block_size // 8

aes_key_len_256: int = 32  # 32 bytes
aes_iv_len_128: int = 16  # 16 bytes
aes_nonce_len_128: int = 12  # 12 bytes

aes_cbc_mode: str = "cbc"
aes_gcm_mode: str = "gcm"

aes_encrypt_action = "encrypt"
aes_decrypt_action = "decrypt"

aes_gcm_tag_len = aes_block_in_bytes

aes_file_read_block = aes_block_in_bytes


def generate_random_key() -> str:
    return random_str.generate_random_str(aes_key_len_256)


def generate_random_iv_nonce(mode: str) -> str:
    if mode == aes_cbc_mode:
        return random_str.generate_random_str(aes_iv_len_128)
    elif mode == aes_gcm_mode:
        return random_str.generate_random_str(aes_nonce_len_128)


def process_key_iv(is_random: bool, key: str, iv: str, mode: str) -> Tuple[str, str]:
    return common.process_key_iv(
        is_random,
        key,
        iv,
        key_len=aes_key_len_256,
        iv_len=aes_iv_len_128,
        nonce_len=aes_nonce_len_128,
        mode=mode,
    )


def padding_data(data: bytes) -> bytes:
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()
    return padded_data


def remove_padding_data(data: bytes) -> bytes:
    # For empty byte stream, return empty directly
    if data is None or len(data) == 0:
        return b""
    unpadder = padding.PKCS7(128).unpadder()
    decrypted_data = unpadder.update(data) + unpadder.finalize()
    return decrypted_data


class aes_operator(object):
    def __init__(
        self,
        mode: str,
        action: str,
        key: bytes,
        iv: bytes,
        tags: bytes,
        aad: bytes = None,
    ):
        """
        :param mode: cbc or gcm
        :param action: encrypt or decrypt
        :param key: 32 bytes
        :param iv:  16 bytes (cbc) or 12 bytes (gcm nonce)
        :param tags:  required for gcm decrypt
        :param aad:   GCM additional authenticated data, CipherHUB compatible by default
        """
        self.__mode = mode
        self.__action = action
        self.__tags = tags
        self.__key = key
        self.__iv = iv
        if mode == aes_cbc_mode:
            self.__aes_cbc_obj = Cipher(
                algorithms.AES(self.__key),
                modes.CBC(self.__iv),
                backend=default_backend(),
            )
            if action == aes_encrypt_action:
                self.__aes_cbc_enc_op = self.__aes_cbc_obj.encryptor()
            if action == aes_decrypt_action:
                self.__aes_cbc_dec_op = self.__aes_cbc_obj.decryptor()
        if mode == aes_gcm_mode:
            self.__auth_data = (
                aad
                if aad is not None
                else cipherhub_defaults.DEFAULT_AAD.encode("utf-8")
            )
            if action == aes_encrypt_action:
                self.__aes_gcm_obj = Cipher(
                    algorithms.AES(self.__key),
                    modes.GCM(self.__iv),
                    backend=default_backend(),
                )
                self.__aes_gcm_enc_op = self.__aes_gcm_obj.encryptor()
                self.__aes_gcm_enc_op.authenticate_additional_data(self.__auth_data)
            if action == aes_decrypt_action:
                self.__aes_gcm_obj = Cipher(
                    algorithms.AES(self.__key),
                    modes.GCM(self.__iv, self.__tags),
                    backend=default_backend(),
                )
                self.__aes_gcm_dec_op = self.__aes_gcm_obj.decryptor()
                self.__aes_gcm_dec_op.authenticate_additional_data(self.__auth_data)

    def process_data(self, data: bytes) -> bytes:
        if self.__mode == aes_cbc_mode:
            if self.__action == aes_encrypt_action:
                return self.__aes_cbc_enc_op.update(data)
            if self.__action == aes_decrypt_action:
                return self.__aes_cbc_dec_op.update(data)
        if self.__mode == aes_gcm_mode:
            if self.__action == aes_encrypt_action:
                return self.__aes_gcm_enc_op.update(data)
            if self.__action == aes_decrypt_action:
                return self.__aes_gcm_dec_op.update(data)

    def finalize(self) -> Tuple[bytes, bytes]:
        """
        GCM encrypt returns ciphertext and tag.
        GCM decrypt requires tag.
        """
        if self.__mode == aes_cbc_mode:
            if self.__action == aes_encrypt_action:
                return self.__aes_cbc_enc_op.finalize(), b""
            if self.__action == aes_decrypt_action:
                return self.__aes_cbc_dec_op.finalize(), b""
        if self.__mode == aes_gcm_mode:
            if self.__action == aes_encrypt_action:
                return self.__aes_gcm_enc_op.finalize(), self.__aes_gcm_enc_op.tag
            if self.__action == aes_decrypt_action:
                return self.__aes_gcm_dec_op.finalize(), b""

    @property
    def mode(self) -> str:
        return self.__mode

    @property
    def action(self) -> str:
        return self.__action

    @property
    def key(self) -> bytes:
        return self.__key

    @property
    def iv_nonce(self) -> bytes:
        return self.__iv


def check_b64_input_data(input_data: str, input_limit: int) -> bool:
    if input_data is None:
        click.echo("need input data")
        return False
    valid, input_raw_bytes = common.check_b64_data(input_data)
    if not valid:
        click.echo("invalid b64 encoded data:{}".format(input_data))
        hints.hint_invalid_b64("AES")
        return False
    if len(input_raw_bytes) > input_limit * 1024 * 1024:
        click.echo(
            "the data exceeds the maximum bytes limit, limited to:{}Bytes, now:{}Bytes".format(
                input_limit * 1024 * 1024, len(input_raw_bytes)
            )
        )
        return False
    if len(input_raw_bytes) <= 0:
        click.echo("need plain data but now got empty after base64 decoded")
        return False
    return True


@click.command(
    name="aes", short_help="AES encrypt/decrypt, supports aes-cbc-256 and aes-gcm-256"
)
@click.option(
    "-m",
    "--mode",
    required=False,
    type=click.Choice([aes_cbc_mode, aes_gcm_mode]),
    default="cbc",
    show_default=True,
    help="AES mode: cbc or gcm, default cbc",
    is_flag=False,
    multiple=False,
)
@click.option(
    "-k",
    "--key",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_KEY_32,
    help="Key 32 bytes (256-bit), CipherHUB compatible; pad or truncate as needed",
    show_default=True,
    is_flag=False,
    multiple=False,
)
@click.option(
    "-v",
    "--iv-nonce",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_IV_16,
    help="CBC: iv 16 bytes; GCM: nonce 12 bytes. CipherHUB compatible; pad or truncate as needed",
    show_default=True,
    is_flag=False,
    multiple=False,
)
@click.option(
    "--aad",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_AAD,
    help='GCM additional authenticated data (AAD), default: "{}"'.format(
        cipherhub_defaults.DEFAULT_AAD
    ),
    show_default=True,
    is_flag=False,
    multiple=False,
)
@click.option(
    "-r",
    "--random-key-iv",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Auto-generate random key and iv/nonce (key 32 bytes, iv 16 bytes, nonce 12 bytes)",
    multiple=False,
)
@click.option(
    "-A",
    "--action",
    required=False,
    type=click.Choice([aes_encrypt_action, aes_decrypt_action]),
    default="encrypt",
    show_default=True,
    help="encrypt or decrypt; encrypt outputs base64-encoded string",
    is_flag=False,
    multiple=False,
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input data: encrypt accepts string/base64/file; decrypt accepts base64/file",
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="Input is base64-encoded; -e and -f are mutually exclusive",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=False,
    help="Input is a file path; -e and -f are mutually exclusive",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="Max input length in MB (default 1), applies when -i is not a file",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file path; required when input is a file",
)
@click.option(
    "--no-force",
    is_flag=True,
    default=False,
    help="Do not overwrite existing output file (default: overwrite)",
)
@click.option(
    "--gcm-pad",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="[GCM only] PKCS#7 pad plaintext before encrypt, unpad after decrypt. Default: no padding (CipherHUB compatible); "
    "encrypt and decrypt must both use or both omit --gcm-pad",
)
@command_perf.timing_decorator
def aes_command(
    mode: click.STRING,
    key: click.STRING,
    iv_nonce: click.STRING,
    random_key_iv: click.BOOL,
    action: click.STRING,
    input_data: click.STRING,
    is_base64_encoded: click.BOOL,
    is_a_file: click.BOOL,
    input_limit: click.INT,
    output_file: click.STRING,
    aad: click.STRING,
    no_force: bool,
    gcm_pad: bool = False,
):
    """
    Encrypt: plaintext/base64(-e)/file(-f). Decrypt: base64(-e)/file(-f).
    Default -i is UTF-8 plaintext; -e means base64; -f means file path.
    """
    key, iv_nonce = process_key_iv(random_key_iv, key, iv_nonce, mode)

    if len(input_data) <= 0:
        click.echo("no input data, it is required")
        return

    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "AES")
    if not ok:
        click.echo(err)
        hints.hint_input_file_or_b64_conflict()
        return

    ok, err = validators.validate_file_output_required(is_a_file, output_file, "AES")
    if not ok:
        click.echo(err)
        return

    input_raw_bytes = b""
    input_raw_tag = b""

    # If input is base64-encoded
    if is_base64_encoded:
        if not check_b64_input_data(input_data, input_limit):
            return
        input_raw_bytes = common.decode_b64_data(input_data)
        # GCM decrypt: cipher format is cipher||tag, split from end
        if mode == aes_gcm_mode and action == aes_decrypt_action:
            if len(input_raw_bytes) < aes_gcm_tag_len:
                click.echo(
                    "invalid cipher: too short for gcm tag (need at least {} bytes)".format(
                        aes_gcm_tag_len
                    )
                )
                return
            input_raw_tag = input_raw_bytes[-aes_gcm_tag_len:]
            input_raw_bytes = input_raw_bytes[:-aes_gcm_tag_len]

    input_from_file = None
    output_to_file = None

    # Neither base64 nor file: treat as UTF-8 plaintext string
    if not is_base64_encoded and not is_a_file:
        if len(input_data) > input_limit * 1024 * 1024:
            click.echo(
                "the data exceeds the maximum bytes limit, limited to:{}Bytes, now:{}Bytes".format(
                    input_limit * 1024 * 1024, len(input_data)
                )
            )
            return
        try:
            input_raw_bytes = input_data.encode("utf-8")
        except UnicodeEncodeError:
            click.echo("input contains invalid UTF-8 characters")
            return

    file_gcm_cipher_bytes = None

    if len(output_file) > 0:
        try:
            output_to_file = common.write_to_file(output_file, force=not no_force)
        except OSError:
            click.echo(
                "{} may not exist or may not writable (use --no-force to avoid overwrite)".format(
                    output_file
                )
            )
            return

    # GCM decrypt needs tag (parsed from cipher end, format cipher||tag)
    if (
        mode == aes_gcm_mode
        and action == aes_decrypt_action
        and len(input_raw_tag) == 0
    ):
        click.echo("gcm mode decrypt requires cipher in base64(cipher||tag) format")
        return

    def _make_aes_op(tag: bytes):
        return aes_operator(
            mode=mode,
            action=action,
            key=key.encode("utf-8"),
            iv=iv_nonce.encode("utf-8"),
            tags=tag,
            aad=aad.encode("utf-8") if aad else None,
        )

    # --gcm-pad only applies in GCM mode; CBC always pads
    use_gcm_pad = mode == aes_gcm_mode and gcm_pad

    if not is_a_file:
        aes_op = _make_aes_op(input_raw_tag)
        if action == aes_encrypt_action:
            if mode == aes_cbc_mode:
                padded_raw_bytes = padding_data(input_raw_bytes)
            else:
                # GCM: no padding by default; pad only when --gcm-pad
                padded_raw_bytes = (
                    padding_data(input_raw_bytes) if use_gcm_pad else input_raw_bytes
                )
            cipher = aes_op.process_data(padded_raw_bytes)
            cipher_last_block, ret_tags = aes_op.finalize()
            all_cipher = cipher + cipher_last_block
            if mode == aes_gcm_mode:
                # GCM: output single base64 cipher (cipher||tag, NIST SP 800-38D format)
                cipher_with_tag = all_cipher + ret_tags
                if not common.validate_gcm_cipher_format(
                    cipher_with_tag, aes_gcm_tag_len
                ):
                    click.echo(
                        "invalid gcm cipher format: cipher_with_tag length < tag_len"
                    )
                    return
                all_cipher_str = base64.b64encode(cipher_with_tag).decode("utf-8")
                click.echo(
                    "plain size:{}\nkey:{}\niv:{}\ncipher size:{}\ncipher:{}".format(
                        len(input_raw_bytes),
                        key,
                        iv_nonce,
                        len(cipher_with_tag),
                        all_cipher_str,
                    )
                )
                if output_to_file is not None and not output_to_file.write_bytes(
                    cipher_with_tag
                ):
                    return
            else:
                all_cipher_str = base64.b64encode(all_cipher).decode("utf-8")
                click.echo(
                    "plain size:{}\nkey:{}\niv:{}\ncipher size:{}\ncipher:{}".format(
                        len(input_raw_bytes),
                        key,
                        iv_nonce,
                        len(all_cipher),
                        all_cipher_str,
                    )
                )
                if output_to_file is not None and not output_to_file.write_bytes(
                    all_cipher
                ):
                    return
        if action == aes_decrypt_action:
            try:
                plain = aes_op.process_data(input_raw_bytes)
                plain_last_block, ret_tags = aes_op.finalize()
                raw_plain = plain + plain_last_block
                if mode == aes_cbc_mode:
                    origin_plain = remove_padding_data(raw_plain)
                else:
                    # GCM: remove PKCS#7 padding only when --gcm-pad
                    origin_plain = (
                        remove_padding_data(raw_plain) if use_gcm_pad else raw_plain
                    )
            except InvalidTag:
                click.echo(
                    "decrypt failed: GCM authentication tag verification failed (cipher may be tampered)"
                )
                hint = validators.hint_decrypt_maybe_b64(input_data, "AES decrypt")
                if hint:
                    click.echo(hint)
                return
            except ValueError as e:
                err_msg = str(e).lower()
                if "padding" in err_msg or "pkcs7" in err_msg:
                    click.echo(
                        "decrypt failed: PKCS#7 unpad error. If cipher was GCM-encrypted without padding, retry without --gcm-pad"
                    )
                else:
                    click.echo("decrypt failed: {}".format(e))
                hint = validators.hint_decrypt_maybe_b64(input_data, "AES decrypt")
                if hint:
                    click.echo(hint)
                return
            except BaseException as e:
                click.echo("decrypt failed: {}".format(e))
                hint = validators.hint_decrypt_maybe_b64(input_data, "AES decrypt")
                if hint:
                    click.echo(hint)
                return
            else:  # If decrypt succeeds, try UTF-8 decode; if ok print directly, else print base64
                be_str, ret = common.bytes_to_str(origin_plain)
                if be_str:
                    click.echo(
                        "cipher size:{}\nplain size:{}\nstr plain (original):{}".format(
                            len(input_raw_bytes), len(origin_plain), ret
                        )
                    )
                else:
                    click.echo(
                        "cipher size:{}\nplain size:{}\nb64 encoded plain (base64):{}".format(
                            len(input_raw_bytes), len(origin_plain), ret
                        )
                    )
                if output_to_file is not None and not output_to_file.write_bytes(
                    origin_plain
                ):
                    return

    if is_a_file and output_to_file is not None:
        try:
            with common.read_from_file(input_data) as input_from_file:
                if mode == aes_gcm_mode and action == aes_decrypt_action:
                    file_size_for_read = os.stat(input_data).st_size
                    if file_size_for_read < aes_gcm_tag_len:
                        click.echo("invalid cipher file: too short for gcm tag")
                        return
                    file_content = input_from_file.read_n_bytes(file_size_for_read)
                    input_raw_tag = file_content[-aes_gcm_tag_len:]
                    file_gcm_cipher_bytes = file_content[:-aes_gcm_tag_len]

                aes_op = _make_aes_op(input_raw_tag)
                read_size = (aes_file_read_block**5) * 64  # Read 64MB per chunk
                file_size = os.stat(input_data).st_size
                output_size = 0
                click.echo("input file size:{}".format(file_size))

                if action == aes_encrypt_action:
                    while True:
                        chunk = input_from_file.read_n_bytes(read_size)
                        file_size -= len(chunk)
                        if file_size <= 0:
                            if mode == aes_cbc_mode:
                                chunk = padding_data(chunk)
                            else:
                                chunk = padding_data(chunk) if use_gcm_pad else chunk
                            cipher = aes_op.process_data(chunk)
                            output_size += len(cipher)
                            cipher_last_block, tag = aes_op.finalize()
                            output_size += len(cipher_last_block)
                            if mode == aes_gcm_mode:
                                cipher_with_tag = cipher + cipher_last_block + tag
                                if not common.validate_gcm_cipher_format(
                                    cipher_with_tag, aes_gcm_tag_len
                                ):
                                    click.echo(
                                        "invalid gcm cipher format: cipher_with_tag length < tag_len"
                                    )
                                    return
                                if not output_to_file.write_bytes(cipher_with_tag):
                                    return
                                click.echo(
                                    "cipher size:{}\nkey:{}\niv:{}\ncipher:{}".format(
                                        output_size + len(tag),
                                        key,
                                        iv_nonce,
                                        base64.b64encode(cipher_with_tag).decode(
                                            "utf-8"
                                        ),
                                    )
                                )
                            else:
                                if not output_to_file.write_bytes(cipher):
                                    return
                                if not output_to_file.write_bytes(cipher_last_block):
                                    return
                                click.echo(
                                    "cipher size:{}\nkey:{}\niv:{}".format(
                                        output_size, key, iv_nonce
                                    )
                                )
                            break
                        cipher = aes_op.process_data(chunk)
                        output_size += len(cipher)
                        if not output_to_file.write_bytes(cipher):
                            return

                if action == aes_decrypt_action:
                    try:
                        if mode == aes_gcm_mode and file_gcm_cipher_bytes is not None:
                            plain = aes_op.process_data(file_gcm_cipher_bytes)
                            plain_last_block, _ = aes_op.finalize()
                            raw_plain = plain + plain_last_block
                            origin_plain = (
                                remove_padding_data(raw_plain)
                                if use_gcm_pad
                                else raw_plain
                            )
                            output_size = len(origin_plain)
                            if not output_to_file.write_bytes(origin_plain):
                                return
                            click.echo(
                                "decrypt {} success\nwrite to {}\nplain size:{}".format(
                                    input_data, output_file, output_size
                                )
                            )
                        else:
                            if mode == aes_cbc_mode and (
                                file_size < aes_file_read_block
                                or file_size % aes_file_read_block != 0
                            ):
                                click.echo(
                                    "invalid cipher file size:{} Bytes".format(
                                        file_size
                                    )
                                )
                                return
                            while True:
                                chunk = input_from_file.read_n_bytes(read_size)
                                file_size -= len(chunk)
                                plain = aes_op.process_data(chunk)
                                if file_size == 0:
                                    plain = remove_padding_data(plain)
                                    output_size += len(plain)
                                    if not output_to_file.write_bytes(plain):
                                        return
                                    click.echo(
                                        "decrypt {} success\nwrite to {}\nplain size:{}".format(
                                            input_data, output_file, output_size
                                        )
                                    )
                                    return
                                output_size += len(plain)
                                if not output_to_file.write_bytes(plain):
                                    return
                    except InvalidTag:
                        click.echo(
                            "decrypt failed: GCM authentication tag verification failed"
                        )
                        return
                    except ValueError as e:
                        err_msg = str(e).lower()
                        if "padding" in err_msg or "pkcs7" in err_msg:
                            click.echo(
                                "decrypt failed: PKCS#7 unpad error. If cipher was GCM-encrypted without padding, retry without --gcm-pad"
                            )
                        else:
                            click.echo("decrypt {} failed: {}".format(input_data, e))
                        return
                    except BaseException as e:
                        click.echo("decrypt {} failed: {}".format(input_data, e))
                        return
        except OSError:
            click.echo("{} may not exist or may be unreadable".format(input_data))


if __name__ == "__main__":
    aes_command()
