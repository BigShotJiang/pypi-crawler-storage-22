#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-03 23:05:39
import base64

import click
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, utils as asym_utils
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import command_perf
from easy_encryption_tool import common

ecc_map = {
    ec.SECP256R1().name: ec.SECP256R1,
    ec.SECP384R1().name: ec.SECP384R1,
    ec.SECP521R1().name: ec.SECP521R1,
    ec.SECP256K1().name: ec.SECP256K1,
}

ecc_hash_map = {
    hashes.SHA1().name: hashes.SHA1,
    hashes.SHA224().name: hashes.SHA224,
    hashes.SHA256().name: hashes.SHA256,
    hashes.SHA384().name: hashes.SHA384,
    hashes.SHA512().name: hashes.SHA512,
    hashes.SHA3_224().name: hashes.SHA3_224,
    hashes.SHA3_256().name: hashes.SHA3_256,
    hashes.SHA3_384().name: hashes.SHA3_384,
    hashes.SHA3_512().name: hashes.SHA3_512,
}

ecc_digest_size_map = {k: v().digest_size for k, v in ecc_hash_map.items()}

# Hash for ECC key exchange (CipherHUB supports SHA1-SHA512, no SHA3)
ecc_kex_hash_map = {
    hashes.SHA1().name: hashes.SHA1,
    hashes.SHA224().name: hashes.SHA224,
    hashes.SHA256().name: hashes.SHA256,
    hashes.SHA384().name: hashes.SHA384,
    hashes.SHA512().name: hashes.SHA512,
}


@click.group(name="ecc", short_help="ECC sign/verify and key exchange")
def ecc_group():
    pass


@click.command(name="generate")
@click.option(
    "-c",
    "--curve",
    required=False,
    type=click.Choice(list(ecc_map.keys())),
    default=ec.SECP256K1().name,
    show_default=True,
    help="ECC curve type",
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-f",
    "--file-name",
    required=False,
    type=click.STRING,
    default="demo",
    show_default=True,
    help="Output file name prefix for key pair",
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    help="Private key password",
)
@click.option(
    "-r",
    "--random-password",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Generate random private key password (32 bytes); omit -p when used",
)
@command_perf.timing_decorator
def generate(
    curve: click.STRING,
    encoding: click.STRING,
    file_name: click.STRING,
    password: click.STRING,
    random_password: click.BOOL,
):
    password, enc = common.private_key_password(random_password, password)
    ecc_private_key = ec.generate_private_key(ecc_map[curve](), default_backend())
    ecc_public_key = ecc_private_key.public_key()
    private_key_encoding = ecc_private_key.private_bytes(
        encoding=common.encoding_maps[encoding],
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=enc,
    )
    public_key_encoding = ecc_public_key.public_bytes(
        encoding=common.encoding_maps[encoding],
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    if not common.write_asymmetric_key(
        file_name_prefix=file_name,
        asymmetric_type="ecc",
        encoding_type=encoding,
        is_private_encrypted=(password is not None and len(password) > 0),
        private_password=password,
        public_data=public_key_encoding,
        private_data=private_key_encoding,
    ):
        click.echo("ecc generated failed")
    return


@click.command(name="ecdh")
@click.option(
    "-a",
    "--alice-pub-key",
    required=True,
    type=click.STRING,
    help="Your public key file path, e.g. ./alice_public.pem",
)
@click.option(
    "-k",
    "--alice-pri-key",
    required=True,
    type=click.STRING,
    help="Your private key file path, e.g. ./alice_private.pem",
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default="",
    help="Your private key password (required if key was created with password)",
)
@click.option(
    "-b",
    "--bob-pub-key",
    required=True,
    type=click.STRING,
    help="Peer's public key file path, e.g. ./bob_public.pem",
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-l",
    "--length",
    required=False,
    type=click.IntRange(16, 64),
    default=cipherhub_defaults.DEFAULT_ECC_DERIVED_KEY_LENGTH,
    show_default=True,
    help="Derived key length, CipherHUB compatible default",
)
@click.option(
    "-H",
    "--hash-alg",
    required=False,
    type=click.Choice(list(ecc_kex_hash_map.keys())),
    default=cipherhub_defaults.DEFAULT_ECC_HASH,
    show_default=True,
    help="HKDF hash algorithm, CipherHUB compatible",
)
@click.option(
    "-s",
    "--salt",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_ECC_SALT,
    show_default=True,
    help="HKDF salt, CipherHUB default compatible",
)
@click.option(
    "-c",
    "--context",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_ECC_ADDITIONAL_INFO,
    show_default=True,
    help="HKDF additional_info, CipherHUB default compatible",
)
@command_perf.timing_decorator
def key_exchange(
    alice_pub_key: click.STRING,
    alice_pri_key: click.STRING,
    password: click.STRING,
    bob_pub_key: click.STRING,
    encoding: click.STRING,
    length: click.INT,
    hash_alg: click.STRING,
    salt: click.STRING,
    context: click.STRING,
):
    if password is not None and len(password) > 0:
        password_bytes = password.encode("utf-8")
    else:
        password_bytes = None
    alice_pub = common.load_public_key(encoding=encoding, file_path=alice_pub_key)
    if alice_pub is None:
        return
    alice_pri = common.load_private_key(
        encoding=encoding, file_path=alice_pri_key, password_bytes=password_bytes
    )
    if alice_pri is None:
        return
    bob_pub = common.load_public_key(encoding=encoding, file_path=bob_pub_key)
    if bob_pub is None:
        return
    salt_bytes = salt.encode("utf-8") if salt else None
    context_bytes = context.encode("utf-8") if context else None
    shared_secret_alice = alice_pri.exchange(ec.ECDH(), bob_pub)
    derived_key = HKDF(
        algorithm=ecc_kex_hash_map[hash_alg](),
        length=length,
        salt=salt_bytes,
        info=context_bytes,
        backend=default_backend(),
    ).derive(shared_secret_alice)
    click.echo(
        "curve name:{}\nderived key:{}\nlength:{}".format(
            alice_pri.curve.name,
            base64.b64encode(derived_key).decode("utf-8"),
            len(derived_key),
        )
    )


@click.command(name="sign")
@click.option(
    "-f",
    "--private-key",
    required=True,
    type=click.STRING,
    help="Private key file path",
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    default=cipherhub_defaults.DEFAULT_ECC_HASH,
    show_default=True,
    type=click.Choice(list(ecc_hash_map.keys())),
    help="Signature hash algorithm, CipherHUB compatible default",
)
@click.option(
    "-p",
    "--password",
    required=False,
    type=click.STRING,
    default="",
    help="Private key password (required if key was created with password)",
)
@click.option(
    "-i", "--input-data", required=True, type=click.STRING, help="Data to sign"
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is base64-encoded",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is pre-computed digest (not raw); must match -a hash-alg length",
)
@command_perf.timing_decorator
def ecc_sign(
    private_key: click.STRING,
    input_data: click.STRING,
    hash_alg: click.STRING,
    password: click.STRING,
    encoding: click.STRING,
    is_base64_encoded: click.BOOL,
    input_is_digest: click.BOOL,
):
    if password is not None and len(password) > 0:
        password_bytes = password.encode("utf-8")
    else:
        password_bytes = None

    if b64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            click.echo(
                "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
            )
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    digest_size = ecc_digest_size_map[hash_alg]
    if input_is_digest:
        if len(input_raw_bytes) != digest_size:
            click.echo(
                "input-is-digest mode requires {} bytes ({} digest length), got: {} bytes".format(
                    digest_size, hash_alg, len(input_raw_bytes)
                )
            )
            return

    pri_key = common.load_private_key(
        encoding=encoding, file_path=private_key, password_bytes=password_bytes
    )
    if pri_key is None:
        return

    try:
        hash_alg_obj = ecc_hash_map[hash_alg]()
        sign_algorithm = (
            ec.ECDSA(asym_utils.Prehashed(hash_alg_obj))
            if input_is_digest
            else ec.ECDSA(hash_alg_obj)
        )
        signature = pri_key.sign(input_raw_bytes, sign_algorithm)
        click.echo(
            "curve name:{}\nkey size:{}\nsignature:{}\nbase64 encoded:{}\nmode:{}".format(
                pri_key.curve.name,
                pri_key.key_size,
                signature.hex(),
                base64.b64encode(signature).decode("utf-8"),
                ec.ECDSA.__name__,
            )
        )
    except BaseException as e:
        click.echo(
            "sign failed:{}\nprivate key:{}\npassword:{}\nmode:{}".format(
                e, private_key, password, ec.ECDSA.__name__
            )
        )


@click.command(name="verify")
@click.option(
    "-f", "--public-key", required=True, type=click.STRING, help="Public key file path"
)
@click.option(
    "-E",
    "--encoding",
    type=click.Choice(list(common.encoding_maps.keys())),
    default="pem",
    show_default=True,
    help="Key encoding format",
)
@click.option(
    "-a",
    "--hash-alg",
    required=False,
    default=cipherhub_defaults.DEFAULT_ECC_HASH,
    show_default=True,
    type=click.Choice(list(ecc_hash_map.keys())),
    help="Signature hash algorithm, CipherHUB compatible default",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Data to verify (raw or digest, use -d for digest)",
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is base64-encoded",
)
@click.option(
    "-d",
    "--input-is-digest",
    required=False,
    type=click.BOOL,
    is_flag=True,
    help="Input is pre-computed digest (not raw); must match -a hash-alg length",
)
@click.option(
    "-s",
    "--signature",
    required=True,
    type=click.STRING,
    help="Base64-encoded signature",
)
@command_perf.timing_decorator
def ecc_verify(
    public_key: click.STRING,
    input_data: click.STRING,
    is_base64_encoded: click.BOOL,
    signature: click.STRING,
    hash_alg: click.STRING,
    encoding: click.STRING,
    input_is_digest: click.BOOL,
):
    if not signature or len(signature.strip()) <= 0:
        click.echo("signature cannot be empty")
        return
    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            click.echo(
                "invalid b64 encoded data:{}, decoded failed:{}".format(input_data, e)
            )
            return
    else:
        input_raw_bytes = input_data.encode("utf-8")

    digest_size = ecc_digest_size_map[hash_alg]
    if input_is_digest:
        if len(input_raw_bytes) != digest_size:
            click.echo(
                "input-is-digest mode requires {} bytes ({} digest length), got: {} bytes".format(
                    digest_size, hash_alg, len(input_raw_bytes)
                )
            )
            return

    try:
        signature_raw_bytes = common.decode_b64_data(signature)
    except BaseException as e:
        click.echo("invalid b64 encoded signature, decoded failed:{}".format(e))
        return
    if len(signature_raw_bytes) <= 0:
        click.echo("signature is empty after decode")
        return

    pub_key = common.load_public_key(encoding=encoding, file_path=public_key)
    if pub_key is None:
        return

    # Verify with public key (raw vs pre-computed digest)
    hash_alg_obj = ecc_hash_map[hash_alg]()
    verify_algorithm = (
        ec.ECDSA(asym_utils.Prehashed(hash_alg_obj))
        if input_is_digest
        else ec.ECDSA(hash_alg_obj)
    )
    try:
        pub_key.verify(signature_raw_bytes, input_raw_bytes, verify_algorithm)
    except InvalidSignature as e:
        click.echo(
            "InvalidSignature!\nkey size:{}\nmode:{}".format(
                pub_key.key_size, ec.ECDSA.__name__
            )
        )
    else:
        click.echo(
            "curve name:{}\nverify success\nkey size:{}\nmode:{}".format(
                pub_key.curve.name, pub_key.key_size, ec.ECDSA.__name__
            )
        )


if __name__ == "__main__":
    ecc_group.add_command(generate)
    ecc_group.add_command(key_exchange)
    ecc_group.add_command(ecc_sign)
    ecc_group.add_command(ecc_verify)
    ecc_group()
