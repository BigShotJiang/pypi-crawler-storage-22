#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Unified hint module for dependency missing, parameter errors, etc.
"""

import click


def hint_missing_gmssl(feature: str) -> None:
    """
    Hint when GM/T (Chinese standard) crypto dependency is missing.
    :param feature: Feature name, e.g. "SM3", "SM4", "SM2", "ZUC", "GM cert parse"
    """
    click.echo(click.style(f"⚠ {feature} requires easy_gmssl", fg="yellow"))
    click.echo("  Install: pip install easy_gmssl")
    click.echo("  Or: pip install easy-encryption-tool[gmssl]")


def hint_invalid_b64(context: str = "") -> None:
    """Hint when base64 decode fails"""
    prefix = f"  {context}: " if context else "  "
    click.echo(
        click.style(
            f"{prefix}For decrypt, -i should be base64 cipher; add -e if input is base64-encoded",
            fg="yellow",
        )
    )
    click.echo("  Example: easy_encryption_tool aes -a decrypt -i 'cipher...' -e")


def hint_input_file_or_b64_conflict() -> None:
    """Hint when -e and -f conflict"""
    click.echo(
        click.style(
            "  -e and -f are mutually exclusive: input cannot be both file and base64",
            fg="yellow",
        )
    )
    click.echo("  -e: -i is base64-encoded; -f: -i is file path")
