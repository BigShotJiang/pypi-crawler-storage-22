#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-03-30 22:02:07

import platform
import sys
from typing import Dict

import click

from easy_encryption_tool import __version__, command_perf


def sys_info() -> Dict[str, str]:
    return {
        "PythonVersion": sys.version,
        "ApiVersion": sys.api_version,
        "OSPlatform": sys.platform,
        "OSProcessor": platform.platform(),
        "BytesEndian": sys.byteorder,
    }


# Get version from package, keep in sync with setup.py
tool_version_info = (
    __version__ if str(__version__).startswith("v") else "v{}".format(__version__)
)
info = sys_info()


# Author website and tagline (from https://cipherhub.cloud/about)
CIPHERHUB_WEBSITE = "https://cipherhub.cloud"
CIPHERHUB_TAGLINE = "Serious Cryptography · Creative Solutions · Mapping Digital Trust"


@click.command(name="version", short_help="Show version and runtime info")
@command_perf.timing_decorator
def show_version():
    click.echo(
        "tool-version:{}\npython:{}\nos:{}\nchip:{}\nbyte-order:{}\nwebsite:{}\ntagline:{}".format(
            tool_version_info,
            info["PythonVersion"],
            info["OSPlatform"],
            info["OSProcessor"],
            info["BytesEndian"],
            CIPHERHUB_WEBSITE,
            CIPHERHUB_TAGLINE,
        )
    )
