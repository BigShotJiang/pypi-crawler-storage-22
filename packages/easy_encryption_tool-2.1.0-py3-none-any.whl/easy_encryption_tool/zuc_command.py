#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
ZUC stream cipher for encrypt/decrypt.
Key and IV are both 16 bytes.
"""
from __future__ import annotations

import base64
import os

import click

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import random_str
from easy_encryption_tool import command_perf
from easy_encryption_tool import validators

try:
    from easy_gmssl import EasyZuc
    from easy_gmssl.gmssl import ZUC_KEY_SIZE, ZUC_IV_SIZE

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False
    ZUC_KEY_SIZE = 16
    ZUC_IV_SIZE = 16


def _check_gmssl():
    if not EASY_GMSSL_AVAILABLE:
        hints.hint_missing_gmssl("ZUC")
        return False
    return True


def process_key_iv(is_random: bool, key: str, iv: str) -> tuple:
    return common.process_key_iv(
        is_random,
        key,
        iv,
        key_len=ZUC_KEY_SIZE,
        iv_len=ZUC_IV_SIZE,
        mode=None,
    )


@click.command(name="zuc", short_help="ZUC stream cipher encrypt/decrypt")
@click.option(
    "-k",
    "--key",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_ZUC_KEY,
    help="Key 16 bytes, CipherHUB compatible; pad or truncate as needed",
)
@click.option(
    "-v",
    "--iv",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_ZUC_IV,
    help="IV 16 bytes, CipherHUB compatible; pad or truncate as needed",
)
@click.option(
    "-r",
    "--random-key-iv",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Auto-generate random key and IV",
)
@click.option(
    "-A",
    "--action",
    required=False,
    type=click.Choice(["encrypt", "decrypt"]),
    default="encrypt",
    show_default=True,
    help="encrypt or decrypt",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input data: string, base64, or file path",
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Input is base64-encoded; -e and -f are mutually exclusive",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Input is a file path; -e and -f are mutually exclusive",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="Max input length in MB, applies when input is not a file",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file path; required when input is a file",
)
@click.option(
    "--no-force",
    is_flag=True,
    default=False,
    help="Do not overwrite existing output file",
)
@command_perf.timing_decorator
def zuc_command(
    key: str,
    iv: str,
    random_key_iv: bool,
    action: str,
    input_data: str,
    is_base64_encoded: bool,
    is_a_file: bool,
    input_limit: int,
    output_file: str,
    no_force: bool = False,
):
    """ZUC stream cipher encrypt/decrypt, cipher length equals plain length. Default -i is UTF-8 plaintext; -e means base64; -f means file."""
    if not _check_gmssl():
        return

    key, iv = process_key_iv(random_key_iv, key, iv)

    if len(input_data) <= 0:
        click.echo("no input data, it is required")
        return

    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "ZUC")
    if not ok:
        click.echo(err)
        hints.hint_input_file_or_b64_conflict()
        return

    ok, err = validators.validate_file_output_required(is_a_file, output_file, "ZUC")
    if not ok:
        click.echo(err)
        return

    input_raw_bytes = b""
    input_from_file = None
    output_to_file = None

    if is_base64_encoded:
        try:
            input_raw_bytes = common.decode_b64_data(input_data)
        except BaseException as e:
            click.echo("invalid b64 encoded data:{}".format(e))
            hints.hint_invalid_b64("ZUC")
            return
        if len(input_raw_bytes) > input_limit * 1024 * 1024:
            click.echo("input exceeds limit:{} MB".format(input_limit))
            return

    if not is_base64_encoded and not is_a_file:
        if len(input_data) > input_limit * 1024 * 1024:
            click.echo("input exceeds limit:{} MB".format(input_limit))
            return
        try:
            input_raw_bytes = input_data.encode("utf-8")
        except UnicodeEncodeError:
            click.echo("input contains invalid UTF-8 characters")
            return

    if len(output_file) > 0:
        try:
            output_to_file = common.write_to_file(output_file, force=not no_force)
        except OSError:
            click.echo(
                "{} may not exist or may not writable (use --no-force to avoid overwrite)".format(
                    output_file
                )
            )
            return

    key_bytes = key.encode("utf-8")
    iv_bytes = iv.encode("utf-8")
    zuc_op = EasyZuc(key=key_bytes, iv=iv_bytes)

    if not is_a_file:
        result = zuc_op.Update(input_raw_bytes) + zuc_op.Finish()
        if action == "encrypt":
            result_str = base64.b64encode(result).decode("utf-8")
            click.echo(
                "key:{}\niv:{}\ninput_size:{}\noutput_size:{}\ncipher:{}".format(
                    key, iv, len(input_raw_bytes), len(result), result_str
                )
            )
        else:
            be_str, ret = common.bytes_to_str(result)
            if be_str:
                click.echo(
                    "key:{}\niv:{}\ninput_size:{}\noutput_size:{}\nplain (original):{}".format(
                        key, iv, len(input_raw_bytes), len(result), ret
                    )
                )
            else:
                click.echo(
                    "key:{}\niv:{}\ninput_size:{}\noutput_size:{}\nb64_plain (base64):{}".format(
                        key, iv, len(input_raw_bytes), len(result), ret
                    )
                )
        if output_to_file is not None and not output_to_file.write_bytes(result):
            return
    else:
        if output_to_file is None:
            click.echo("output file is required for file input (-o/--output-file)")
            return
        try:
            with common.read_from_file(input_data) as input_from_file:
                file_size = os.stat(input_data).st_size
                click.echo("input file size:{}".format(file_size))
                output_size = 0
                while True:
                    chunk = input_from_file.read_n_bytes(64 * 1024)
                    if not chunk:
                        break
                    out_chunk = zuc_op.Update(chunk)
                    output_size += len(out_chunk)
                    if not output_to_file.write_bytes(out_chunk):
                        return
                final = zuc_op.Finish()
                if final:
                    output_size += len(final)
                    if not output_to_file.write_bytes(final):
                        return
                click.echo("output size:{}\nkey:{}\niv:{}".format(output_size, key, iv))
        except OSError:
            click.echo("{} may not exist or may be unreadable".format(input_data))


if __name__ == "__main__":
    zuc_command()
