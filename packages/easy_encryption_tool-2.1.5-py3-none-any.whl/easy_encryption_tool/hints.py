#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Unified hint module for dependency missing, parameter errors, etc.
"""

from easy_encryption_tool.rich_ui import hint, warning


def hint_missing_gmssl(feature: str) -> None:
    """
    Hint when GM/T (Chinese standard) crypto dependency is missing.
    :param feature: Feature name, e.g. "SM3", "SM4", "SM2", "ZUC", "GM cert parse"
    """
    warning(f"{feature} 需要 easy_gmssl")
    hint("安装: pip install easy_gmssl")
    hint("或: pip install easy-encryption-tool[gmssl]")


def hint_invalid_b64(context: str = "") -> None:
    """Hint when base64 decode fails"""
    prefix = f"{context}: " if context else ""
    hint(
        f"{prefix}解密时 -i 应为 base64 密文；若输入已是 base64，请加 -e"
    )
    hint("示例: easy_encryption_tool aes -A decrypt -i 'cipher...' -e")


def hint_input_file_or_b64_conflict() -> None:
    """Hint when -e and -f conflict"""
    warning("-e 与 -f 互斥：输入不能同时为文件和 base64")
    hint("-e: -i 为 base64 编码；-f: -i 为文件路径")
