#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Shell 补全辅助模块：为各子命令提供 tab 补全逻辑。
- 文件路径补全（依赖 shell 的 path 补全）
- 条件补全：当 -f 指定输入为文件时，-i 才补全文件路径
- 满足实际使用的依赖关系
"""
from __future__ import annotations

import click
from click.shell_completion import CompletionItem


def complete_file_path(ctx: click.Context, param: click.Parameter, incomplete: str):
    """
    文件路径补全：返回 type='file' 让 shell 执行路径补全。
    用于 -o/--output-file、-f/--public-key、-f/--private-key、-f/--cert-file 等。
    """
    return [CompletionItem(incomplete, type="file")]


def complete_file_path_if_input_is_file(
    ctx: click.Context,
    param: click.Parameter,
    incomplete: str,
    file_flag_param: str = "is_a_file",
):
    """
    条件文件路径补全：仅当 file_flag_param 为 True 时补全文件路径。
    用于 -i/--input-data：当用户已指定 -f（输入为文件）时，才补全文件路径；
    否则 -i 为明文/base64，不补全。
    """
    if ctx.params.get(file_flag_param):
        return [CompletionItem(incomplete, type="file")]
    return []


def complete_dir_path(ctx: click.Context, param: click.Parameter, incomplete: str):
    """目录路径补全"""
    return [CompletionItem(incomplete, type="dir")]
