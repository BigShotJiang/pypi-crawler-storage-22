#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-03-30 22:02:07

import platform
import sys
from typing import Dict

import click

from easy_encryption_tool import __version__, command_perf
from easy_encryption_tool.rich_ui import result_table


def sys_info() -> Dict[str, str]:
    return {
        "PythonVersion": sys.version,
        "ApiVersion": sys.api_version,
        "OSPlatform": sys.platform,
        "OSProcessor": platform.platform(),
        "BytesEndian": sys.byteorder,
    }


# Get version from package, keep in sync with setup.py
tool_version_info = (
    __version__ if str(__version__).startswith("v") else "v{}".format(__version__)
)
info = sys_info()


# Author website and tagline (from https://cipherhub.cloud/about)
CIPHERHUB_WEBSITE = "https://cipherhub.cloud"
CIPHERHUB_TAGLINE = "Serious Cryptography · Creative Solutions · Mapping Digital Trust"


@click.command(name="version", short_help="Show version and runtime info")
@command_perf.timing_decorator
def show_version():
    result_table(
        {
            "tool-version": tool_version_info,
            "python": info["PythonVersion"],
            "os": info["OSPlatform"],
            "chip": info["OSProcessor"],
            "byte-order": info["BytesEndian"],
            "website": CIPHERHUB_WEBSITE,
            "tagline": CIPHERHUB_TAGLINE,
        },
        title="Version",
    )
