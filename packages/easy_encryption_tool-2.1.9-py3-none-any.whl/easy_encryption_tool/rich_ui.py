#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
统一 Rich 命令行输出模块。
提供 success/error/warning/info/hint 等风格化输出，以及 result_table、result_panel 等结构化展示。
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, Sequence

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

# 统一主题：子命令、参数、成功、错误、警告、提示 风格一致
EET_THEME = Theme(
    {
        "cmd": "bold cyan",
        "param": "dim cyan",
        "success": "bold green",
        "error": "bold red",
        "warning": "bold yellow",
        "info": "dim white",
        "hint": "italic yellow",
        "key": "bold blue",
        "value": "white",
        "muted": "dim",
    }
)

console = Console(theme=EET_THEME, force_terminal=True)


def echo(text: str = "", **kwargs) -> None:
    """普通输出，兼容 click.echo"""
    console.print(text, **kwargs)


def success(msg: str, **kwargs) -> None:
    """成功信息"""
    console.print(f"[success]✓[/] {msg}", **kwargs)


def error(msg: str, **kwargs) -> None:
    """错误信息"""
    console.print(f"[error]✗[/] {msg}", **kwargs)


def warning(msg: str, **kwargs) -> None:
    """警告信息"""
    console.print(f"[warning]⚠[/] {msg}", **kwargs)


def info(msg: str, **kwargs) -> None:
    """普通信息"""
    console.print(f"[info]ℹ[/] {msg}", **kwargs)


def hint(msg: str, **kwargs) -> None:
    """提示信息"""
    console.print(f"[hint]→[/] {msg}", **kwargs)


def result_table(
    rows: Dict[str, Any],
    title: Optional[str] = None,
    show_header: bool = False,
    expand: bool = False,
) -> None:
    """
    输出 key-value 表格，用于 AES/Hash/HMAC 等结构化结果。
    :param rows: {"plain size": 5, "key": "xxx", ...}
    :param title: 可选面板标题
    :param show_header: 是否显示表头
    :param expand: 是否展开（长内容换行）
    """
    table = Table(show_header=show_header, box=None, padding=(0, 2), expand=expand)
    if show_header:
        table.add_column("Key", style="key")
        table.add_column("Value", style="value")
    for k, v in rows.items():
        str_val = str(v)
        if show_header:
            table.add_row(k, str_val)
        else:
            table.add_row(f"[key]{k}[/]:", str_val)
    if title:
        console.print(Panel(table, title=f" [cmd]{title}[/] ", border_style="dim"))
    else:
        console.print(table)


def result_panel(
    content: str | Table,
    title: str,
    border_style: str = "dim",
) -> None:
    """带标题的面板输出"""
    console.print(Panel(content, title=f" [cmd]{title}[/] ", border_style=border_style))


def result_simple(rows: Dict[str, Any]) -> None:
    """
    简单 key: value 输出，保持与原有格式兼容（便于脚本解析）。
    当需要纯文本输出时使用。
    """
    for k, v in rows.items():
        console.print(f"[key]{k}[/]: [value]{v}[/]")


def timing_begin(flag: str, now: str) -> None:
    """性能计时开始"""
    console.print(f"[muted]⏱ {flag} begin @ {now}[/]")


def timing_end(flag: str, ms: float) -> None:
    """性能计时结束"""
    console.print(f"[muted]⏱ {flag} took {ms:.3f} ms[/]")


def welcome_panel(commands: Sequence[tuple[str, str]]) -> None:
    """Welcome panel showing common command examples"""
    table = Table(show_header=True, box=None, padding=(0, 2))
    table.add_column("Command", style="cmd")
    table.add_column("Example", style="param")
    for cmd, example in commands:
        table.add_row(cmd, example)
    console.print(
        Panel(
            table,
            title=" [bold]easy_encryption_tool[/] · Common Command Examples ",
            border_style="cyan",
        )
    )


def suggestion_panel(suggestions: Iterable[str]) -> None:
    """命令纠错建议"""
    console.print(
        Panel(
            ", ".join(suggestions),
            title=" [warning]Did you mean?[/] ",
            border_style="yellow",
        )
    )
