#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
SM4 symmetric encryption (Chinese standard, similar to AES).
Supports CBC and GCM modes.
"""
from __future__ import annotations

import base64
import os
from typing import Tuple

import click
from cryptography.hazmat.primitives import padding

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import shell_completion
from easy_encryption_tool import random_str
from easy_encryption_tool import command_perf
from easy_encryption_tool import validators
from easy_encryption_tool.rich_ui import error, hint, result_table

try:
    from easy_gmssl import EasySm4CBC, EasySm4GCM
    from easy_gmssl.gmssl import (
        SM4_BLOCK_SIZE,
        SM4_CBC_IV_SIZE,
        SM4_GCM_DEFAULT_IV_SIZE,
    )

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False

algorithm: str = "sm4"

sm4_key_len: int = 16  # 16 bytes
sm4_iv_len: int = 16  # CBC mode 16 bytes
sm4_nonce_len: int = 12  # GCM mode 12 bytes

sm4_cbc_mode: str = "cbc"
sm4_gcm_mode: str = "gcm"

sm4_encrypt_action = "encrypt"
sm4_decrypt_action = "decrypt"

sm4_gcm_tag_len = SM4_BLOCK_SIZE if EASY_GMSSL_AVAILABLE else 16

sm4_file_read_block = 16


def _check_gmssl():
    if not EASY_GMSSL_AVAILABLE:
        hints.hint_missing_gmssl("SM4")
        return False
    return True


def generate_random_key() -> str:
    return random_str.generate_random_str(sm4_key_len)


def generate_random_iv_nonce(mode: str) -> str:
    if mode == sm4_cbc_mode:
        return random_str.generate_random_str(sm4_iv_len)
    elif mode == sm4_gcm_mode:
        return random_str.generate_random_str(sm4_nonce_len)


def process_key_iv(is_random: bool, key: str, iv: str, mode: str) -> Tuple[str, str]:
    return common.process_key_iv(
        is_random,
        key,
        iv,
        key_len=sm4_key_len,
        iv_len=sm4_iv_len,
        nonce_len=sm4_nonce_len,
        mode=mode,
    )


def padding_data(data: bytes) -> bytes:
    padder = padding.PKCS7(128).padder()
    return padder.update(data) + padder.finalize()


def remove_padding_data(data: bytes) -> bytes:
    if data is None or len(data) == 0:
        return b""
    unpadder = padding.PKCS7(128).unpadder()
    return unpadder.update(data) + unpadder.finalize()


def check_b64_input_data(input_data: str, input_limit: int) -> Tuple[bool, bytes]:
    """Validate and decode base64 input. Returns (success, decoded_bytes)."""
    if input_data is None:
        error("need input data")
        return False, b""
    valid, input_raw_bytes = common.check_b64_data(input_data)
    if not valid:
        error("invalid b64 encoded data")
        hints.hint_invalid_b64("SM4")
        return False, b""
    if len(input_raw_bytes) > input_limit * 1024 * 1024:
        error(
            "data exceeds limit: {} Bytes (max {} Bytes)".format(
                len(input_raw_bytes), input_limit * 1024 * 1024
            )
        )
        return False, b""
    if len(input_raw_bytes) <= 0:
        error("got empty after base64 decode")
        return False, b""
    return True, input_raw_bytes


@click.command(
    name="sm4", short_help="SM4 encrypt/decrypt, supports sm4-cbc and sm4-gcm"
)
@click.option(
    "-m",
    "--mode",
    required=False,
    type=click.Choice([sm4_cbc_mode, sm4_gcm_mode]),
    default="cbc",
    show_default=True,
    help="SM4 mode: cbc or gcm, default cbc",
)
@click.option(
    "-k",
    "--key",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_KEY_16,
    help="Key 16 bytes, CipherHUB compatible; pad or truncate as needed",
    show_default=True,
)
@click.option(
    "-v",
    "--iv-nonce",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_IV_16,
    help="CBC: iv 16 bytes; GCM: nonce 12 bytes. CipherHUB compatible; pad or truncate as needed",
    show_default=True,
)
@click.option(
    "--aad",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_AAD,
    help='GCM additional authenticated data (AAD), default: "{}"'.format(
        cipherhub_defaults.DEFAULT_AAD
    ),
    show_default=True,
)
@click.option(
    "-r",
    "--random-key-iv",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Auto-generate random key and iv/nonce",
)
@click.option(
    "-A",
    "--action",
    required=False,
    type=click.Choice([sm4_encrypt_action, sm4_decrypt_action]),
    default="encrypt",
    show_default=True,
    help="encrypt or decrypt; encrypt outputs base64-encoded string",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input data: encrypt accepts string/base64/file; decrypt accepts base64/file",
    shell_complete=shell_completion.complete_file_path_if_input_is_file,
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="Input is base64-encoded; -e and -f are mutually exclusive",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=False,
    help="Input is a file path; -e and -f are mutually exclusive",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="Max input length in MB (default 1), applies when -i is not a file",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file path; required when input is a file",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "--no-force",
    is_flag=True,
    default=False,
    help="Do not overwrite existing output file (default: overwrite)",
)
@click.option(
    "--gcm-pad",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="[GCM only] PKCS#7 pad plaintext before encrypt, unpad after decrypt. Default: no padding (CipherHUB compatible); "
    "encrypt and decrypt must both use or both omit --gcm-pad",
)
@command_perf.timing_decorator
def sm4_command(
    mode: str,
    key: str,
    iv_nonce: str,
    random_key_iv: bool,
    action: str,
    input_data: str,
    is_base64_encoded: bool,
    is_a_file: bool,
    input_limit: int,
    output_file: str,
    aad: str,
    no_force: bool = False,
    gcm_pad: bool = False,
):
    """SM4 symmetric encrypt/decrypt, CBC and GCM modes. Default -i is UTF-8 plaintext; -e means base64; -f means file."""
    if not _check_gmssl():
        return

    key, iv_nonce = process_key_iv(random_key_iv, key, iv_nonce, mode)

    if len(input_data) <= 0:
        error("no input data, it is required")
        return

    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "SM4")
    if not ok:
        error(err or "")
        hints.hint_input_file_or_b64_conflict()
        return

    ok, err = validators.validate_file_output_required(is_a_file, output_file, "SM4")
    if not ok:
        error(err or "")
        return

    if (
        action == sm4_decrypt_action
        and not is_base64_encoded
        and not is_a_file
    ):
        error("decrypt requires base64 cipher or file; use -e for base64 input")
        hints.hint_invalid_b64("SM4")
        return

    input_raw_bytes = b""
    input_raw_tag = b""

    if is_base64_encoded:
        ok, input_raw_bytes = check_b64_input_data(input_data, input_limit)
        if not ok:
            return
        # GCM decrypt: cipher format is cipher||tag, split from end
        if mode == sm4_gcm_mode and action == sm4_decrypt_action:
            if len(input_raw_bytes) < sm4_gcm_tag_len:
                error(
                    "invalid cipher: too short for gcm tag (need at least {} bytes)".format(
                        sm4_gcm_tag_len
                    )
                )
                return
            input_raw_tag = input_raw_bytes[-sm4_gcm_tag_len:]
            input_raw_bytes = input_raw_bytes[:-sm4_gcm_tag_len]

    input_from_file = None
    output_to_file = None
    if not is_base64_encoded and not is_a_file:
        if len(input_data) > input_limit * 1024 * 1024:
            error(
                "data exceeds limit: {} Bytes (max {} Bytes)".format(
                    len(input_data), input_limit * 1024 * 1024
                )
            )
            return
        try:
            input_raw_bytes = input_data.encode("utf-8")
        except UnicodeEncodeError:
            error("input contains invalid UTF-8 characters")
            return

    file_gcm_cipher_bytes = None
    if is_a_file and mode == sm4_gcm_mode and action == sm4_decrypt_action:
        try:
            with common.read_from_file(input_data) as input_from_file:
                file_size_for_read = os.stat(input_data).st_size
                if file_size_for_read < sm4_gcm_tag_len:
                    error("invalid cipher file: too short for gcm tag")
                    return
                file_content = input_from_file.read_n_bytes(file_size_for_read)
                input_raw_tag = file_content[-sm4_gcm_tag_len:]
                file_gcm_cipher_bytes = file_content[:-sm4_gcm_tag_len]
        except OSError:
            error("{} may not exist or may be unreadable".format(input_data))
            return

    if (
        mode == sm4_gcm_mode
        and action == sm4_decrypt_action
        and len(input_raw_tag) == 0
    ):
        error("gcm mode decrypt requires cipher in base64(cipher||tag) format")
        return

    # --gcm-pad only applies in GCM mode; CBC always pads
    use_gcm_pad = mode == sm4_gcm_mode and gcm_pad

    if len(output_file) > 0:
        try:
            output_to_file = common.write_to_file(output_file, force=not no_force)
        except OSError:
            error(
                "{} may not exist or may not be writable (use --no-force to avoid overwrite)".format(
                    output_file
                )
            )
            return

    key_bytes = key.encode("utf-8")
    iv_bytes = iv_nonce.encode("utf-8")
    if mode == sm4_gcm_mode:
        auth_data = (aad or cipherhub_defaults.DEFAULT_AAD).encode("utf-8")
        sm4_op = EasySm4GCM(
            key=key_bytes,
            iv=iv_bytes,
            aad=auth_data,
            do_encrypt=(action == sm4_encrypt_action),
        )
    else:
        sm4_op = EasySm4CBC(
            key=key_bytes, iv=iv_bytes, do_encrypt=(action == sm4_encrypt_action)
        )

    if not is_a_file:
        if action == sm4_encrypt_action:
            if mode == sm4_cbc_mode:
                padded_raw_bytes = padding_data(input_raw_bytes)
            else:
                padded_raw_bytes = (
                    padding_data(input_raw_bytes) if use_gcm_pad else input_raw_bytes
                )
            cipher = sm4_op.Update(padded_raw_bytes) + sm4_op.Finish()
            if mode == sm4_gcm_mode:
                ret_tags = cipher[-sm4_gcm_tag_len:]
                all_cipher = cipher[:-sm4_gcm_tag_len]
                cipher_with_tag = all_cipher + ret_tags
                if not common.validate_gcm_cipher_format(
                    cipher_with_tag, sm4_gcm_tag_len
                ):
                    error(
                        "invalid gcm cipher format: cipher_with_tag length < tag_len"
                    )
                    return
                all_cipher_str = base64.b64encode(cipher_with_tag).decode("utf-8")
                result_table(
                    {
                        "plain size": len(input_raw_bytes),
                        "key": key,
                        "iv": iv_nonce,
                        "cipher size": len(cipher_with_tag),
                        "cipher": all_cipher_str,
                    },
                    title="SM4-GCM Encrypt",
                )
                if output_to_file is not None and not output_to_file.write_bytes(
                    cipher_with_tag
                ):
                    return
            else:
                all_cipher = cipher
                all_cipher_str = base64.b64encode(all_cipher).decode("utf-8")
                result_table(
                    {
                        "plain size": len(input_raw_bytes),
                        "key": key,
                        "iv": iv_nonce,
                        "cipher size": len(all_cipher),
                        "cipher": all_cipher_str,
                    },
                    title="SM4-CBC Encrypt",
                )
                if output_to_file is not None and not output_to_file.write_bytes(
                    all_cipher
                ):
                    return
        if action == sm4_decrypt_action:
            try:
                if mode == sm4_gcm_mode:
                    cipher_with_tag = input_raw_bytes + input_raw_tag
                    plain = sm4_op.Update(cipher_with_tag) + sm4_op.Finish()
                    plain = remove_padding_data(plain) if use_gcm_pad else plain
                else:
                    plain = sm4_op.Update(input_raw_bytes) + sm4_op.Finish()
                    plain = remove_padding_data(plain)
            except ValueError as e:
                err_msg = str(e).lower()
                if "padding" in err_msg or "pkcs7" in err_msg:
                    error(
                        "decrypt failed: PKCS#7 unpad error. If cipher was GCM-encrypted without padding, retry without --gcm-pad"
                    )
                else:
                    error("decrypt {} failed: {}".format(input_data, e))
                return
            except BaseException as e:
                error("decrypt {} failed: {}".format(input_data, e))
                return
            be_str, ret = common.bytes_to_str(plain)
            rows = {
                "cipher size": len(input_raw_bytes),
                "plain size": len(plain),
            }
            rows["str plain (original)" if be_str else "b64 plain (base64)"] = ret
            result_table(rows, title="SM4 Decrypt")
            if output_to_file is not None and not output_to_file.write_bytes(plain):
                return

    if is_a_file and output_to_file is not None:
        if (
            mode == sm4_gcm_mode
            and action == sm4_decrypt_action
            and file_gcm_cipher_bytes is not None
        ):
            try:
                plain = (
                    sm4_op.Update(file_gcm_cipher_bytes + input_raw_tag)
                    + sm4_op.Finish()
                )
                plain = remove_padding_data(plain) if use_gcm_pad else plain
                if not output_to_file.write_bytes(plain):
                    return
                result_table(
                    {
                        "decrypt": input_data,
                        "write to": output_file,
                        "plain size": len(plain),
                    },
                    title="SM4-GCM File Decrypt",
                )
            except ValueError as e:
                err_msg = str(e).lower()
                if "padding" in err_msg or "pkcs7" in err_msg:
                    error(
                        "decrypt failed: PKCS#7 unpad error. If cipher was GCM-encrypted without padding, retry without --gcm-pad"
                    )
                else:
                    error("decrypt {} failed: {}".format(input_data, e))
            except BaseException as e:
                error("decrypt {} failed: {}".format(input_data, e))
        else:
            try:
                with common.read_from_file(input_data) as input_from_file:
                    read_size = (sm4_file_read_block**5) * 64
                    file_size = os.stat(input_data).st_size
                    output_size = 0
                    result_table({"input file size": file_size}, title="SM4 File")
                    if action == sm4_encrypt_action:
                        while True:
                            chunk = input_from_file.read_n_bytes(read_size)
                            file_size -= len(chunk)
                            if file_size <= 0:
                                if mode == sm4_cbc_mode:
                                    chunk = padding_data(chunk)
                                else:
                                    chunk = (
                                        padding_data(chunk) if use_gcm_pad else chunk
                                    )
                                cipher = sm4_op.Update(chunk) + sm4_op.Finish()
                                if mode == sm4_gcm_mode:
                                    tag = cipher[-sm4_gcm_tag_len:]
                                    cipher = cipher[:-sm4_gcm_tag_len]
                                    cipher_with_tag = cipher + tag
                                    if not common.validate_gcm_cipher_format(
                                        cipher_with_tag, sm4_gcm_tag_len
                                    ):
                                        error(
                                            "invalid gcm cipher format: cipher_with_tag length < tag_len"
                                        )
                                        return
                                    output_size += len(cipher_with_tag)
                                    if not output_to_file.write_bytes(cipher_with_tag):
                                        return
                                    result_table(
                                        {
                                            "cipher size": output_size,
                                            "key": key,
                                            "iv": iv_nonce,
                                            "cipher": base64.b64encode(
                                                cipher_with_tag
                                            ).decode("utf-8"),
                                        },
                                        title="SM4-GCM File Encrypt",
                                    )
                                else:
                                    output_size += len(cipher)
                                    if not output_to_file.write_bytes(cipher):
                                        return
                                    result_table(
                                        {
                                            "cipher size": output_size,
                                            "key": key,
                                            "iv": iv_nonce,
                                        },
                                        title="SM4-CBC File Encrypt",
                                    )
                                break
                            cipher = sm4_op.Update(chunk)
                            output_size += len(cipher)
                            if not output_to_file.write_bytes(cipher):
                                return
                    if action == sm4_decrypt_action:
                        try:
                            if (
                                file_size < sm4_file_read_block
                                or file_size % sm4_file_read_block != 0
                            ):
                                error(
                                    "invalid cipher file size: {} Bytes".format(
                                        file_size
                                    )
                                )
                                return
                            while True:
                                chunk = input_from_file.read_n_bytes(read_size)
                                file_size -= len(chunk)
                                plain = sm4_op.Update(chunk)
                                if file_size == 0:
                                    plain = plain + sm4_op.Finish()
                                    plain = remove_padding_data(plain)
                                    output_size += len(plain)
                                    if not output_to_file.write_bytes(plain):
                                        return
                                    result_table(
                                        {
                                            "decrypt": input_data,
                                            "write to": output_file,
                                            "plain size": output_size,
                                        },
                                        title="SM4-CBC File Decrypt",
                                    )
                                    return
                                output_size += len(plain)
                                if not output_to_file.write_bytes(plain):
                                    return
                        except BaseException as e:
                            error("decrypt {} failed: {}".format(input_data, e))
            except OSError:
                error("{} may not exist or may be unreadable".format(input_data))


if __name__ == "__main__":
    sm4_command()
