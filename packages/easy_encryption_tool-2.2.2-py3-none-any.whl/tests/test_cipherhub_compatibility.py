#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
easy_encryption_tool 与 CipherHUB 兼容性测试
验证在相同算法、模式、输入参数下，两者可相互加解密或得到一致的 hash/hmac
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import sys
import subprocess

# 添加项目根目录和 CipherHUB 到 path
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)
_CIPHERHUB_ROOT = os.path.join(os.path.dirname(_PROJECT_ROOT), "CipherHUB")
sys.path.insert(0, _PROJECT_ROOT)
sys.path.insert(0, _CIPHERHUB_ROOT)

from easy_encryption_tool import cipherhub_defaults

# CipherHUB 默认明文
PLAINTEXT = cipherhub_defaults.DEFAULT_PLAINTEXT
PLAINTEXT_BYTES = PLAINTEXT.encode("utf-8")
PLAINTEXT_HEX = PLAINTEXT_BYTES.hex()

# 测试结果收集
RESULTS = []


def _record(name: str, passed: bool, detail: str = ""):
    RESULTS.append({"name": name, "passed": passed, "detail": detail})
    status = "✓ PASS" if passed else "✗ FAIL"
    print(f"  {status}: {name}" + (f" - {detail}" if detail else ""))


def test_block_cipher_aes256_cbc():
    """块密码 AES256-CBC：easy_encryption_tool 加密 -> CipherHUB 解密"""
    try:
        from handlers.block_cipher import (
            block_cipher_process,
            CBCAlgorithm,
            ProcessType,
        )
    except ImportError as e:
        _record(
            "Block Cipher AES256-CBC (enc->dec)", False, f"CipherHUB import failed: {e}"
        )
        return

    key_bytes = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
    iv_bytes = cipherhub_defaults.DEFAULT_IV_16.encode("utf-8")

    # 使用 easy_encryption_tool 加密（通过 CLI）
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "aes",
            "-m",
            "cbc",
            "-a",
            "encrypt",
            "-k",
            cipherhub_defaults.DEFAULT_KEY_32,
            "-v",
            cipherhub_defaults.DEFAULT_IV_16,
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("Block Cipher AES256-CBC (enc)", False, proc.stderr or proc.stdout)
        return

    # 解析输出获取 cipher (base64)，格式为 "cipher:xxx"（区别于 "cipher size:"）
    cipher_b64 = None
    for line in proc.stdout.split("\n"):
        if line.strip().startswith("cipher:") and not line.strip().startswith(
            "cipher size:"
        ):
            cipher_b64 = line.split("cipher:", 1)[1].strip()
            break
    if not cipher_b64:
        _record(
            "Block Cipher AES256-CBC (parse)",
            False,
            "could not parse cipher from output",
        )
        return

    cipher_bytes = base64.b64decode(cipher_b64)
    decrypted = block_cipher_process(
        cipher_bytes,
        key_bytes,
        iv_bytes,
        ProcessType.Decrypt,
        CBCAlgorithm.AES256,
    )
    passed = decrypted == PLAINTEXT_BYTES
    _record("Block Cipher AES256-CBC (easy_enc->CipherHUB_dec)", passed)


def test_block_cipher_aes256_cbc_reverse():
    """块密码 AES256-CBC：CipherHUB 加密 -> easy_encryption_tool 解密"""
    try:
        from handlers.block_cipher import (
            block_cipher_process,
            CBCAlgorithm,
            ProcessType,
        )
    except ImportError:
        _record(
            "Block Cipher AES256-CBC (CipherHUB_enc->dec)",
            False,
            "CipherHUB import failed",
        )
        return

    key_bytes = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
    iv_bytes = cipherhub_defaults.DEFAULT_IV_16.encode("utf-8")
    cipher_bytes = block_cipher_process(
        PLAINTEXT_BYTES,
        key_bytes,
        iv_bytes,
        ProcessType.Encrypt,
        CBCAlgorithm.AES256,
    )
    cipher_b64 = base64.b64encode(cipher_bytes).decode("utf-8")

    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "aes",
            "-m",
            "cbc",
            "-a",
            "decrypt",
            "-k",
            cipherhub_defaults.DEFAULT_KEY_32,
            "-v",
            cipherhub_defaults.DEFAULT_IV_16,
            "-i",
            cipher_b64,
            "-e",
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record(
            "Block Cipher AES256-CBC (CipherHUB_enc->easy_dec)",
            False,
            proc.stderr or proc.stdout,
        )
        return

    decrypted = None
    for line in proc.stdout.split("\n"):
        if "str plain (original):" in line:
            decrypted = line.split("str plain (original):", 1)[1].strip()
            break
        elif "b64 encoded plain (base64):" in line:
            decrypted = line.split("b64 encoded plain (base64):", 1)[1].strip()
            break
    passed = decrypted == PLAINTEXT
    _record("Block Cipher AES256-CBC (CipherHUB_enc->easy_dec)", passed)


def test_stream_cipher_aes256_gcm():
    """流密码 AES256-GCM：双向加解密兼容"""
    try:
        from handlers.stream_cipher import (
            stream_cipher_process,
            StreamAlgorithm,
            ProcessType,
        )
    except ImportError as e:
        _record("Stream Cipher AES256-GCM", False, f"CipherHUB import failed: {e}")
        return

    key_bytes = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
    nonce_bytes = cipherhub_defaults.DEFAULT_NONCE_12.encode("utf-8")
    aad_bytes = cipherhub_defaults.DEFAULT_AAD.encode("utf-8")

    # CipherHUB 加密
    cipher_from_ch = stream_cipher_process(
        PLAINTEXT_BYTES,
        key_bytes,
        nonce_bytes,
        aad_bytes,
        ProcessType.Encrypt,
        StreamAlgorithm.AES256GCM,
    )
    cipher_b64 = base64.b64encode(cipher_from_ch).decode("utf-8")

    # easy_encryption_tool 解密：支持 base64(cipher||tag) 不分离格式
    cipher_b64 = base64.b64encode(cipher_from_ch).decode("utf-8")

    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "aes",
            "-m",
            "gcm",
            "-a",
            "decrypt",
            "-k",
            cipherhub_defaults.DEFAULT_KEY_32,
            "-v",
            cipherhub_defaults.DEFAULT_NONCE_12,
            "--aad",
            cipherhub_defaults.DEFAULT_AAD,
            "-i",
            cipher_b64,
            "-e",
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record(
            "Stream Cipher AES256-GCM (CipherHUB_enc->easy_dec)",
            False,
            proc.stderr or proc.stdout,
        )
        return

    decrypted = None
    for line in proc.stdout.split("\n"):
        if "str plain (original):" in line:
            decrypted = line.split("str plain (original):", 1)[1].strip()
            break
        elif "b64 encoded plain (base64):" in line:
            decrypted = line.split("b64 encoded plain (base64):", 1)[1].strip()
            break
    passed = decrypted == PLAINTEXT
    _record("Stream Cipher AES256-GCM (CipherHUB_enc->easy_dec)", passed)


def test_hash_sha256():
    """Hash SHA256：两者结果一致"""
    expected = hashlib.sha256(PLAINTEXT_BYTES).hexdigest()
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "hash",
            "-a",
            "sha256",
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("Hash SHA256", False, proc.stderr or proc.stdout)
        return
    got = None
    for line in proc.stdout.split("\n"):
        if line.startswith("hash:"):
            got = line.split(":", 1)[1].strip()
            break
    passed = got == expected
    _record("Hash SHA256", passed)


def test_hash_sm3():
    """Hash SM3：两者结果一致（需 easy_gmssl）"""
    try:
        from easy_gmssl import EasySM3Digest
    except ImportError:
        _record("Hash SM3", False, "easy_gmssl not installed")
        return
    h = EasySM3Digest()
    h.UpdateData(PLAINTEXT_BYTES)
    expected = h.GetHash()[0].hex()
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "hash",
            "-a",
            "sm3",
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("Hash SM3", False, proc.stderr or proc.stdout)
        return
    got = None
    for line in proc.stdout.split("\n"):
        if line.startswith("hash:"):
            got = line.split(":", 1)[1].strip()
            break
    passed = got == expected
    _record("Hash SM3", passed)


def test_hmac_sha256():
    """HMAC SHA256：两者结果一致"""
    key_bytes = cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8")
    expected = hmac.new(key_bytes, PLAINTEXT_BYTES, hashlib.sha256).hexdigest()
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "hmac",
            "-a",
            "sha256",
            "-k",
            cipherhub_defaults.DEFAULT_HMAC_KEY,
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("HMAC SHA256", False, proc.stderr or proc.stdout)
        return
    got = None
    for line in proc.stdout.split("\n"):
        if line.startswith("hmac:"):
            got = line.split(":", 1)[1].strip()
            break
    passed = got == expected
    _record("HMAC SHA256", passed)


def test_hmac_sm3():
    """HMAC SM3：两者结果一致（需 easy_gmssl）"""
    try:
        from easy_gmssl import EasySM3Hmac
    except ImportError:
        _record("HMAC SM3", False, "easy_gmssl not installed")
        return
    key_bytes = cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8")
    h = EasySM3Hmac(key_bytes)
    h.UpdateData(PLAINTEXT_BYTES)
    expected = h.GetHmac()[0].hex()
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "hmac",
            "-a",
            "sm3",
            "-k",
            cipherhub_defaults.DEFAULT_HMAC_KEY,
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("HMAC SM3", False, proc.stderr or proc.stdout)
        return
    got = None
    for line in proc.stdout.split("\n"):
        if line.startswith("hmac:"):
            got = line.split(":", 1)[1].strip()
            break
    passed = got == expected
    _record("HMAC SM3", passed)


def test_zuc():
    """ZUC：easy_encryption_tool 加密 -> CipherHUB 解密"""
    try:
        from handlers.zuc_cipher import zuc_processing
    except ImportError:
        _record("ZUC (enc->dec)", False, "CipherHUB import failed")
        return
    try:
        from easy_gmssl import EasyZuc
    except ImportError:
        _record("ZUC", False, "easy_gmssl not installed")
        return

    key_bytes = cipherhub_defaults.DEFAULT_ZUC_KEY.encode("utf-8")
    iv_bytes = cipherhub_defaults.DEFAULT_ZUC_IV.encode("utf-8")

    # easy_encryption_tool 加密
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "zuc",
            "-a",
            "encrypt",
            "-k",
            cipherhub_defaults.DEFAULT_ZUC_KEY,
            "-v",
            cipherhub_defaults.DEFAULT_ZUC_IV,
            "-i",
            PLAINTEXT,
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("ZUC (easy_enc)", False, proc.stderr or proc.stdout)
        return
    cipher_b64 = None
    for line in proc.stdout.split("\n"):
        if line.startswith("cipher:"):
            cipher_b64 = line.split(":", 1)[1].strip()
            break
    if not cipher_b64:
        _record("ZUC (parse)", False, "could not parse cipher")
        return

    cipher_bytes = base64.b64decode(cipher_b64)
    decrypted = zuc_processing(cipher_bytes, key_bytes, iv_bytes)
    passed = decrypted == PLAINTEXT_BYTES
    _record("ZUC (easy_enc->CipherHUB_dec)", passed)


def test_sm4_cbc():
    """SM4-CBC：双向加解密兼容"""
    try:
        from handlers.block_cipher import (
            block_cipher_process,
            CBCAlgorithm,
            ProcessType,
        )
    except ImportError:
        _record("SM4-CBC", False, "CipherHUB import failed")
        return
    try:
        from easy_gmssl import EasySm4CBC
    except ImportError:
        _record("SM4-CBC", False, "easy_gmssl not installed")
        return

    key_bytes = cipherhub_defaults.DEFAULT_KEY_16.encode("utf-8")
    iv_bytes = cipherhub_defaults.DEFAULT_IV_16.encode("utf-8")

    # CipherHUB 加密
    cipher_bytes = block_cipher_process(
        PLAINTEXT_BYTES,
        key_bytes,
        iv_bytes,
        ProcessType.Encrypt,
        CBCAlgorithm.SM4,
    )
    cipher_b64 = base64.b64encode(cipher_bytes).decode("utf-8")

    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "easy_encryption_tool.main",
            "sm4",
            "-m",
            "cbc",
            "-a",
            "decrypt",
            "-k",
            cipherhub_defaults.DEFAULT_KEY_16,
            "-v",
            cipherhub_defaults.DEFAULT_IV_16,
            "-i",
            cipher_b64,
            "-e",
        ],
        cwd=_PROJECT_ROOT,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        _record("SM4-CBC (CipherHUB_enc->easy_dec)", False, proc.stderr or proc.stdout)
        return
    decrypted = None
    for line in proc.stdout.split("\n"):
        if "str plain (original):" in line:
            decrypted = line.split("str plain (original):", 1)[1].strip()
            break
        elif "b64 encoded plain (base64):" in line:
            decrypted = line.split("b64 encoded plain (base64):", 1)[1].strip()
            break
    passed = decrypted == PLAINTEXT
    _record("SM4-CBC (CipherHUB_enc->easy_dec)", passed)


def run_all():
    print("=" * 60)
    print("easy_encryption_tool <-> CipherHUB 兼容性测试")
    print("=" * 60)
    print(f"明文: {PLAINTEXT}")
    print()

    test_block_cipher_aes256_cbc()
    test_block_cipher_aes256_cbc_reverse()
    test_stream_cipher_aes256_gcm()
    test_hash_sha256()
    test_hash_sm3()
    test_hmac_sha256()
    test_hmac_sm3()
    test_zuc()
    test_sm4_cbc()

    passed = sum(1 for r in RESULTS if r["passed"])
    total = len(RESULTS)
    print()
    print("=" * 60)
    print(f"结果: {passed}/{total} 通过")
    print("=" * 60)
    return passed == total


if __name__ == "__main__":
    ok = run_all()
    sys.exit(0 if ok else 1)
