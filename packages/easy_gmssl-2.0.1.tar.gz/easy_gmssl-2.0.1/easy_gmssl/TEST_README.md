# easy_gmssl 单元测试说明

## 一、测试结构

| 测试文件 | 被测模块 | 测试数量 | 说明 |
|----------|----------|----------|------|
| `easy_sm2_key_test.py` | EasySm2Key, EasySm2EncryptionKey | 17 | SM2 密钥与加解密 |
| `easy_sm2_sign_test.py` | EasySM2SignKey, EasySM2VerifyKey | 6 | SM2 签名验签 |
| `easy_sm2_certificate_test.py` | EasySm2Certificate | 4 | SM2 证书解析与验证 |
| `easy_sm3_key_test.py` | EasySM3Digest, EasySM3Hmac, EasySM3Kdf, EasySM3Pbkdf2 | 14 | SM3 哈希与密钥派生 |
| `easy_sm4_test.py` | EasySm4CBC, EasySm4CTR, EasySm4GCM | 11 | SM4 对称加密 |
| `easy_sm9_test.py` | EasySM9Enc*, EasySM9Sign*, EasySM9VerifyKey | 11 | SM9 标识密码加密与签名 |
| `easy_zuc_test.py` | EasyZuc | 4 | 祖冲之序列密码 |
| `easy_random_data_test.py` | EasyRandomData | 5 | 随机数生成 |

## 二、运行方式

### 方式一：pytest（推荐）

```bash
cd /path/to/easy_gmssl
python -m pytest easy_gmssl/ -v
```

### 方式二：unittest

```bash
cd /path/to/easy_gmssl
python -m unittest discover -s easy_gmssl -p '*_test.py' -v
```

### 方式三：脚本

```bash
cd /path/to/easy_gmssl
bash easy_gmssl/run_unittest.sh
```

## 三、测试目标与参数边界

### SM2 (easy_sm2_key_test)

| 测试用例 | 测试目标 | 参数边界 | 预期 |
|----------|----------|----------|------|
| test_new_sm2_key | 密钥生成、ResetKey/NewKey | - | 公钥私钥非空，ResetKey 后密钥变化 |
| test_key_export | PEM 导出导入 | 密码 1~32 字节 | 仅公钥时私钥为空 |
| test_key_import_invalid | 无效导入 | 空密码、错误密码、过长密码 | ValueError/TypeError |
| test_get_z | 计算 z 值 GetZ | 需公钥 | 返回 32 字节 |
| test_valid_encrypt_decrypt | 四种密文模式 | 明文 1~255 字节 | 加解密往返一致 |
| test_encrypt_too_long_plain | 明文超长 | 256 字节 | ValueError |
| test_decrypt_too_long_cipher | 密文超长 | 367 字节 | ValueError |

### SM3 (easy_sm3_key_test)

| 测试用例 | 参数边界 | 预期 |
|----------|----------|------|
| test_sm3_hmac_key_boundary | 密钥 15/16/64/65 字节 | 15、65 拒绝 |
| test_sm3_pbkdf2_salt_too_long | salt 65 字节 | ValueError |
| test_sm3_pbkdf2_iter_too_small | iter=9999 | ValueError |
| test_sm3_pbkdf2_keylen_boundary | keylen=1 或 257 | 1 接受，257 拒绝 |

### SM4 (easy_sm4_test)

| 测试用例 | 参数边界 | 预期 |
|----------|----------|------|
| test_easy_sm4_gcm_iv_boundary | iv 长度 0/1/64/65 | 0、65 拒绝 |
| test_easy_sm4_gcm_tag_len_boundary | tag_len 0/17 | ValueError |
| test_sm4_ctr_invalid_key/iv | key/iv 15 字节 | ValueError |

### ZUC (easy_zuc_test)

| 测试用例 | 参数边界 | 预期 |
|----------|----------|------|
| test_zuc_invalid_key_size | key 15 字节 | ValueError |
| test_zuc_invalid_iv_size | iv 15 字节 | ValueError |

### Random (easy_random_data_test)

| 测试用例 | 参数边界 | 预期 |
|----------|----------|------|
| test_random_length_zero | length=0 | ValueError |
| test_random_length_negative | length=-1 | ValueError |

## 四、前置条件

- `easy_gmssl/test_keys/` 目录需包含：
  - `tmp_test_sm2_public.pem`
  - `tmp_test_sm2_private.pem`（密码 123456）
  - `kms_sm2.pem`（可选，用于测试切换公钥）
- 首次运行前可通过 `test_key_export` 生成 `tmp_test_*` 密钥对
