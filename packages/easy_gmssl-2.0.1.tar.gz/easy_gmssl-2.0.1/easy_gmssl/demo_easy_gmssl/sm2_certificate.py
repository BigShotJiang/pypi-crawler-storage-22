#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-15
"""
SM2 证书解析与验证 Demo

演示流程：
1. 从 PEM 文件加载 SM2 证书
2. 解析证书序列号、颁发者、主体、有效期
3. 获取证书主体公钥
4. 使用 CA 证书验证（若存在 CA 证书）
5. 使用证书公钥验签

前置条件：需有 SM2 格式的 X.509 证书文件。
可使用 gmssl certgen 生成：gmssl certgen -C CN -ST Beijing -L Haidian -O Test -OU Unit -CN TestCA -days 365 -key key.pem -pass 1234 -out cert.pem -ca
"""

from __future__ import annotations

import os
import subprocess
import tempfile

from easy_gmssl import EasySm2Certificate
from easy_gmssl.gmssl import SM2_DEFAULT_ID


def generate_test_cert(tmp_dir):
    """使用 gmssl 生成自签名测试证书"""
    key_path = os.path.join(tmp_dir, 'cakey.pem')
    cert_path = os.path.join(tmp_dir, 'cacert.pem')
    subprocess.run(
        ['gmssl', 'sm2keygen', '-pass', '1234', '-out', key_path],
        check=True, capture_output=True, timeout=10
    )
    subprocess.run(
        ['gmssl', 'certgen', '-C', 'CN', '-ST', 'Beijing', '-L', 'Haidian',
         '-O', 'Test', '-OU', 'Unit', '-CN', 'TestCA', '-days', '365',
         '-key', key_path, '-pass', '1234', '-out', cert_path, '-ca'],
        check=True, capture_output=True, timeout=10
    )
    return cert_path


def main():
    tmp_dir = tempfile.mkdtemp()
    try:
        cert_path = generate_test_cert(tmp_dir)
    except (subprocess.CalledProcessError, FileNotFoundError):
        print('gmssl CLI not available, using placeholder demo')
        print('To run full demo: pip install easy_gmssl, ensure gmssl in PATH')
        return

    # 1. 加载证书
    cert = EasySm2Certificate(pem_file=cert_path)
    print('Certificate loaded:', cert_path)

    # 2. 解析证书信息
    serial = cert.GetSerialNumber()
    print('Serial number (hex):', serial.hex())

    issuer = cert.GetIssuer()
    print('Issuer:', {k: v for k, v in issuer.items() if k != 'raw_data'})

    subject = cert.GetSubject()
    print('Subject:', {k: v for k, v in subject.items() if k != 'raw_data'})

    validity = cert.GetValidity()
    print('Validity: {} - {}'.format(validity.not_before, validity.not_after))

    # 3. 获取主体公钥
    pub_key = cert.GetSubjectPublicKey()
    print('Has public key:', pub_key.has_public_key())

    # 4. CA 验证（自签名证书用自身验证）
    ok = cert.VerifyByCaCertificate(cert, SM2_DEFAULT_ID)
    print('CA verify (self-signed):', ok)

    # 5. 使用证书公钥验签（需有对应私钥签名）
    from easy_gmssl import EasySM3Digest, EasySm2Key

    key_path = os.path.join(tmp_dir, 'cakey.pem')
    sm2_key = EasySm2Key()
    sm2_key.LoadSm2PrivateKey(key_path, '1234')
    msg = b'test message'
    h = EasySM3Digest.Hash(msg)
    sig = sm2_key.SignDigest(h)

    ok2 = cert.VerifyDigestWithSubjectKey(h, sig)
    print('Verify digest with subject key:', ok2)

    # 清理
    for f in os.listdir(tmp_dir):
        os.remove(os.path.join(tmp_dir, f))
    os.rmdir(tmp_dir)
    print('SM2 certificate demo OK')


if __name__ == '__main__':
    main()
