#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SM3 KDF 与 PBKDF2-HMAC-SM3 密钥派生示例
"""

from __future__ import annotations

from easy_gmssl import EasySM3Kdf, EasySM3Pbkdf2, EasyRandomData, RandomMode
from easy_gmssl.gmssl import SM3_PBKDF2_MIN_ITER


def demo_sm3_kdf():
    """SM3 KDF：从共享秘密派生密钥"""
    print("=== SM3 KDF 示例 ===")
    # 模拟共享秘密（如 ECDH 协商结果）
    shared_secret = b"12345678123456781234567812345678"
    kdf = EasySM3Kdf(outlen=16)
    kdf.UpdateData(shared_secret)
    derived_key, _ = kdf.GetKey()
    print("派生密钥 (hex):", derived_key.hex())


def demo_pbkdf2():
    """PBKDF2-HMAC-SM3：从密码派生密钥"""
    print("\n=== PBKDF2-HMAC-SM3 示例 ===")
    password = "my_secret_password"
    salt = EasyRandomData(RandomMode.RandomBytes).GetRandomData(16)
    print("盐值 (hex):", salt.hex())
    key = EasySM3Pbkdf2.DeriveKey(
        password=password,
        salt=salt,
        iterations=SM3_PBKDF2_MIN_ITER,
        keylen=32,
    )
    print("派生密钥长度:", len(key), "字节")


if __name__ == "__main__":
    demo_sm3_kdf()
    demo_pbkdf2()
