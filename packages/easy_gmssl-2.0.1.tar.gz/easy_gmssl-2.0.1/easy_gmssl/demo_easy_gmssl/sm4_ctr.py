#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SM4-CTR 模式加解密示例
CTR 模式密文与明文等长，无需填充，适合流式加密
"""

from __future__ import annotations

from easy_gmssl import EasySm4CTR, EasyRandomData, RandomMode
from easy_gmssl.gmssl import SM4_BLOCK_SIZE, SM4_CTR_IV_SIZE


def main():
    # 生成随机密钥和 IV
    rng = EasyRandomData(RandomMode.RandomBytes)
    key = rng.GetRandomData(SM4_BLOCK_SIZE)
    iv = rng.GetRandomData(SM4_CTR_IV_SIZE)

    plain = "Hello, SM4-CTR! 这是一段测试数据。".encode("utf-8")

    # 加密
    enc = EasySm4CTR(key, iv)
    cipher = enc.Update(plain) + enc.Finish()
    print("明文长度:", len(plain), "密文长度:", len(cipher))
    assert len(cipher) == len(plain), "CTR 模式密文应与明文等长"

    # 解密（CTR 加解密使用相同逻辑）
    dec = EasySm4CTR(key, iv)
    decrypted = dec.Update(cipher) + dec.Finish()
    print("解密结果:", decrypted.decode("utf-8", errors="replace"))
    assert decrypted == plain


if __name__ == "__main__":
    main()
