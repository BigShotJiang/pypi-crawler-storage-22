#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-15
"""
SM9 标识密码 - 加解密 Demo

演示流程：
1. KGC 生成加密主密钥
2. KGC 根据用户标识提取用户私钥
3. 发送方使用主密钥公钥对指定标识加密
4. 接收方使用自己的私钥解密
"""

from __future__ import annotations

import os
import tempfile

from easy_gmssl import EasySM9EncKey, EasySM9EncMasterKey


def main():
    tmp_dir = tempfile.mkdtemp()
    identity = 'alice@example.com'
    password = '123456'

    # 1. KGC 生成加密主密钥
    master = EasySM9EncMasterKey()
    master.GenerateMasterKey()
    master.ExportToPemFile(os.path.join(tmp_dir, 'sm9_enc_master'), password)

    # 2. KGC 为 alice 提取私钥
    user_key = master.ExtractKey(identity)
    user_key.ExportToPemFile(os.path.join(tmp_dir, 'alice_sm9_enc.pem'), password)

    # 3. 发送方（仅需主密钥公钥）对 alice 加密
    master_prefix = os.path.join(tmp_dir, 'sm9_enc_master')
    master_pub = EasySM9EncMasterKey(
        pem_public_key_file=master_prefix + '_sm9_enc_master_public.pem'
    )
    plain = b'Hello, SM9 identity-based encryption!'
    cipher = master_pub.Encrypt(plain, identity)
    print('Cipher hex:', cipher.hex()[:64] + '...')

    # 4. alice 使用私钥解密
    alice_key = EasySM9EncKey(
        identity=identity,
        pem_file=os.path.join(tmp_dir, 'alice_sm9_enc.pem'),
        password=password,
    )
    decrypted = alice_key.Decrypt(cipher)
    print('Decrypted:', decrypted.decode('utf-8'))
    assert decrypted == plain

    # 清理
    for f in os.listdir(tmp_dir):
        os.remove(os.path.join(tmp_dir, f))
    os.rmdir(tmp_dir)
    print('SM9 encryption demo OK')


if __name__ == '__main__':
    main()
