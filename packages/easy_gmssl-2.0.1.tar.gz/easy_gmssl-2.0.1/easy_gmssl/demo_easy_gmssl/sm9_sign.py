#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-15
"""
SM9 标识密码 - 签名验签 Demo

演示流程：
1. KGC 生成签名主密钥
2. KGC 根据用户标识提取用户签名私钥
3. 用户使用私钥对数据签名
4. 验签方使用主密钥公钥与签名者标识验签
"""

from __future__ import annotations

import os
import tempfile

from easy_gmssl import EasySM9SignKey, EasySM9SignMasterKey, EasySM9VerifyKey


def main():
    tmp_dir = tempfile.mkdtemp()
    identity = 'bob@example.com'
    password = '123456'

    # 1. KGC 生成签名主密钥
    master = EasySM9SignMasterKey()
    master.GenerateMasterKey()
    master.ExportToPemFile(os.path.join(tmp_dir, 'sm9_sign_master'), password)
    master.ExportPublicKeyToPem(os.path.join(tmp_dir, 'sm9_sign_public.pem'))

    # 2. KGC 为 bob 提取签名私钥
    sign_key = master.ExtractKey(identity)
    sign_key.ExportToPemFile(os.path.join(tmp_dir, 'bob_sm9_sign.pem'), password)

    # 3. bob 对数据签名（一次性）
    data = b'Important document to sign'
    sig = sign_key.Sign(data)
    print('Signature hex:', sig.hex()[:64] + '...')

    # 4. 验签方使用主密钥公钥验签
    verify_key = EasySM9VerifyKey(identity, os.path.join(tmp_dir, 'sm9_sign_public.pem'))
    ok = verify_key.Verify(data, sig)
    print('Verify result:', ok)
    assert ok

    # 流式签名示例
    sign_loaded = EasySM9SignKey(
        identity=identity,
        pem_file=os.path.join(tmp_dir, 'bob_sm9_sign.pem'),
        password=password,
    )
    sign_loaded.UpdateData(b'part1')
    sign_loaded.UpdateData(b'part2')
    sig2 = sign_loaded.GetSignValue()
    verify_key2 = EasySM9VerifyKey(identity, os.path.join(tmp_dir, 'sm9_sign_public.pem'))
    verify_key2.UpdateData(b'part1')
    verify_key2.UpdateData(b'part2')
    assert verify_key2.VerifySignature(sig2)

    # 清理
    for f in os.listdir(tmp_dir):
        os.remove(os.path.join(tmp_dir, f))
    os.rmdir(tmp_dir)
    print('SM9 sign demo OK')


if __name__ == '__main__':
    main()
