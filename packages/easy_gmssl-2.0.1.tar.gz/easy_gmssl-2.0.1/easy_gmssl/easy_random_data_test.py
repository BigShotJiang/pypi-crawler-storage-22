#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
随机数生成模块单元测试

测试目标：
  - EasyRandomData: RandomBytes 返回 bytes，RandomStr 返回可打印字符串

参数边界：
  - length: 必须 >= 1
  - RandomStr 字符集: ascii_letters + digits + 特殊字符

运行预期：
  - length=1 返回 1 字节/字符
  - length=0 或负数抛出 ValueError
  - 多次调用结果不同（随机性）
"""

import string
import unittest

from .easy_random_data import EasyRandomData, RandomMode


class RandomDataTestCase(unittest.TestCase):
    def test_random_bytes_length(self):
        """
        测试目标：RandomBytes 模式返回指定长度 bytes
        参数边界：length=1, 20, 256
        运行预期：len(ret)==length
        """
        rng = EasyRandomData(RandomMode.RandomBytes)
        for n in (1, 20, 256):
            ret = rng.GetRandomData(n)
            self.assertEqual(len(ret), n)
            self.assertIsInstance(ret, bytes)

    def test_random_str_length(self):
        """
        测试目标：RandomStr 模式返回指定长度字符串
        参数边界：length=1, 64
        运行预期：len(ret)==length，字符在允许集合内
        """
        allowed = set(string.ascii_letters + string.digits + "'\"{}[]\\!@#$%^&*()_+|:")
        rng = EasyRandomData(RandomMode.RandomStr)
        ret = rng.GetRandomData(64)
        self.assertEqual(len(ret), 64)
        for c in ret:
            self.assertIn(c, allowed)

    def test_random_length_zero(self):
        """
        测试目标：length=0 应抛出 ValueError
        参数边界：length=0
        运行预期：ValueError
        """
        rng = EasyRandomData()
        with self.assertRaises(ValueError):
            rng.GetRandomData(0)

    def test_random_length_negative(self):
        """
        测试目标：length<0 应抛出 ValueError
        参数边界：length=-1
        运行预期：ValueError
        """
        rng = EasyRandomData()
        with self.assertRaises(ValueError):
            rng.GetRandomData(-1)

    def test_random_uniqueness(self):
        """
        测试目标：多次调用结果不同（统计上）
        运行预期：连续多次 GetRandomData 结果不全相同
        """
        rng = EasyRandomData(RandomMode.RandomBytes)
        results = [rng.GetRandomData(32) for _ in range(10)]
        self.assertGreater(len(set(results)), 1, "随机数应有差异")
