#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-15

"""
SM2 证书（X.509）封装

支持 SM2 算法的 X.509 证书解析与验证，适用于 PKI 场景。
提供：证书导入导出、序列号/颁发者/主体/公钥/有效期读取、CA 验证。
"""

from __future__ import annotations

from typing import Any, Dict

from .gmssl import NativeError, SM3_DIGEST_SIZE, Sm2Certificate, Sm2Key


class EasySm2Certificate(object):
    """
    SM2 X.509 证书封装
    支持从 PEM 文件加载、解析证书信息、使用 CA 证书验证
    """

    def __init__(self, pem_file: str = ''):
        self._cert = Sm2Certificate()
        if pem_file:
            self.ImportPem(pem_file)

    def ImportPem(self, path: str) -> EasySm2Certificate:
        """从 PEM 文件加载证书"""
        try:
            self._cert.import_pem(path)
        except NativeError as e:
            raise ValueError('invalid sm2 certificate file: {}'.format(e))
        return self

    def ExportPem(self, path: str):
        """导出证书到 PEM 文件"""
        self._cert.export_pem(path)

    def GetSerialNumber(self) -> bytes:
        """获取证书序列号（原始字节）"""
        return self._cert.get_serial_number()

    def GetIssuer(self) -> Dict[str, Any]:
        """
        获取颁发者信息
        返回包含 OID 名称到值的映射，如 commonName、countryName 等
        """
        return self._cert.get_issuer()

    def GetSubject(self) -> Dict[str, Any]:
        """
        获取主体信息
        返回包含 OID 名称到值的映射
        """
        return self._cert.get_subject()

    def GetSubjectPublicKey(self) -> Sm2Key:
        """
        获取证书主体的 SM2 公钥（gmssl.Sm2Key）
        可用于验签等操作，如 sm2_key.verify(digest, signature)
        """
        return self._cert.get_subject_public_key()

    def GetValidity(self):
        """
        获取证书有效期
        返回 Validity 对象，含 not_before、not_after（datetime）
        """
        return self._cert.get_validity()

    def VerifyByCaCertificate(self, ca_cert: 'EasySm2Certificate', sm2_id: str) -> bool:
        """
        使用 CA 证书验证本证书
        sm2_id: SM2 签名用的标识，通常为默认 '1234567812345678'
        """
        return self._cert.verify_by_ca_certificate(ca_cert._cert, sm2_id)

    def VerifyDigestWithSubjectKey(self, digest: bytes, signature: bytes) -> bool:
        """
        使用证书主体公钥验证 SM2 签名
        digest: SM3 摘要，必须 32 字节
        signature: SM2 签名值
        """
        if len(digest) != SM3_DIGEST_SIZE:
            raise ValueError('invalid digest size, expected {} bytes'.format(SM3_DIGEST_SIZE))
        sm2_key = self._cert.get_subject_public_key()
        return sm2_key.verify(digest, signature)
