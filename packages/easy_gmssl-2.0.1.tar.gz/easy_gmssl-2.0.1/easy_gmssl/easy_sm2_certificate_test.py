#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SM2 证书模块单元测试

测试目标：
  - EasySm2Certificate: ImportPem、ExportPem、GetSerialNumber、GetIssuer、GetSubject、
    GetSubjectPublicKey、GetValidity、VerifyByCaCertificate、VerifyDigestWithSubjectKey

前置条件：
  - 若存在 test_keys/sm2_root_ca.pem 等证书文件，则执行完整测试
  - 否则仅执行无效文件导入等基础测试
"""

import os
import shutil
import subprocess
import tempfile
import unittest

from .easy_sm2_certificate import EasySm2Certificate
from .easy_sm2_key import EasySm2Key
from .gmssl import SM2_DEFAULT_ID, SM3_DIGEST_SIZE


def _try_generate_test_certs(tmp_dir):
    """尝试使用 gmssl 命令行生成测试证书，成功返回 (ca_cert_path, cert_path) 或 None"""
    try:
        key_path = os.path.join(tmp_dir, 'cakey.pem')
        cert_path = os.path.join(tmp_dir, 'cacert.pem')
        subprocess.run(
            ['gmssl', 'sm2keygen', '-pass', '1234', '-out', key_path],
            check=True, capture_output=True, timeout=10
        )
        subprocess.run(
            ['gmssl', 'certgen', '-C', 'CN', '-ST', 'Beijing', '-L', 'Haidian',
             '-O', 'Test', '-OU', 'Unit', '-CN', 'TestCA', '-days', '365',
             '-key', key_path, '-pass', '1234', '-out', cert_path, '-ca'],
            check=True, capture_output=True, timeout=10
        )
        return cert_path, cert_path  # 自签名，CA 与证书相同
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return None


class SM2CertificateCase(unittest.TestCase):
    def setUp(self):
        self.current_dir = os.path.dirname(os.path.abspath(__file__))
        self.test_keys_dir = os.path.join(self.current_dir, 'test_keys') + os.sep
        self.tmp_dir = tempfile.mkdtemp()

    def tearDown(self):
        if os.path.exists(self.tmp_dir):
            shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_import_invalid_file(self):
        """无效证书文件应抛出 ValueError"""
        with self.assertRaises(ValueError):
            EasySm2Certificate(pem_file=self.test_keys_dir + 'nonexistent.pem')

        with self.assertRaises(ValueError):
            EasySm2Certificate(pem_file=self.test_keys_dir + 'tmp_test_sm2_public.pem')

    def test_import_empty_path(self):
        """空路径构造后需 ImportPem"""
        cert = EasySm2Certificate()
        with self.assertRaises(ValueError):
            cert.ImportPem(self.test_keys_dir + 'nonexistent.pem')

    def test_cert_with_gmssl_generated(self):
        """使用 gmssl 生成的证书进行解析与验签测试（若 gmssl 可用）"""
        result = _try_generate_test_certs(self.tmp_dir)
        if result is None:
            self.skipTest('gmssl CLI not available, skip cert parse test')
            return

        ca_cert_path, cert_path = result
        cert = EasySm2Certificate(pem_file=cert_path)

        serial = cert.GetSerialNumber()
        self.assertIsInstance(serial, bytes)
        self.assertGreater(len(serial), 0)

        issuer = cert.GetIssuer()
        self.assertIsInstance(issuer, dict)
        self.assertIn('raw_data', issuer)

        subject = cert.GetSubject()
        self.assertIsInstance(subject, dict)

        validity = cert.GetValidity()
        self.assertIsNotNone(validity.not_before)
        self.assertIsNotNone(validity.not_after)

        pub_key = cert.GetSubjectPublicKey()
        self.assertTrue(pub_key.has_public_key())
        self.assertFalse(pub_key.has_private_key())

        # 自签名证书用自身验证
        self.assertTrue(cert.VerifyByCaCertificate(cert, SM2_DEFAULT_ID))

        # 导出后重新加载
        export_path = os.path.join(self.tmp_dir, 'exported.pem')
        cert.ExportPem(export_path)
        cert2 = EasySm2Certificate(pem_file=export_path)
        self.assertEqual(cert2.GetSerialNumber(), serial)

    def test_verify_digest_invalid_size(self):
        """VerifyDigestWithSubjectKey 摘要长度非 32 应失败"""
        result = _try_generate_test_certs(self.tmp_dir)
        if result is None:
            self.skipTest('gmssl CLI not available')
            return

        _, cert_path = result
        cert = EasySm2Certificate(pem_file=cert_path)
        with self.assertRaises(ValueError):
            cert.VerifyDigestWithSubjectKey(bytes(16), bytes(64))


if __name__ == '__main__':
    unittest.main()
