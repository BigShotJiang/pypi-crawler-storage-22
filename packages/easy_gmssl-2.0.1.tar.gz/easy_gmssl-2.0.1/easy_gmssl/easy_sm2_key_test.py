#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SM2 密钥与加解密模块单元测试

测试目标：
  - EasySm2Key: 密钥生成、PEM 导入导出、公钥/私钥 hex 读取、GetZ、SignDigest、VerifyDigestSignature
  - EasySm2EncryptionKey: 四种密文模式加解密、Base64/Hex 输出格式、参数边界校验

参数边界：
  - 明文: 1 ~ 255 字节 (SM2_MAX_PLAINTEXT_SIZE)
  - 密文: 45 ~ 366 字节 (SM2_MIN/MAX_CIPHERTEXT_SIZE)
  - 私钥密码: 1 ~ 32 字节
  - 签名: 最大 72 字节 (SM2_MAX_SIGNATURE_SIZE)

运行预期：
  - 正常路径：加解密往返一致、签名验签通过、密钥导出导入一致
  - 异常路径：超长明文/密文、错误密码、无效模式/格式、无私钥解密 等应抛出明确异常
"""

import base64
import os
import random
import unittest

from easy_gmssl import EasySM3Digest
from .easy_sm2_key import (
    EasySm2EncryptionKey,
    EasySm2Key,
    SM2CipherFormat,
    SM2CipherMode,
)
from .gmssl import (
    SM2_MAX_CIPHERTEXT_SIZE,
    SM2_MAX_PLAINTEXT_SIZE,
    SM2_MAX_SIGNATURE_SIZE,
    SM3_DIGEST_SIZE,
)


class SM2KeyCase(unittest.TestCase):
    def setUp(self):
        self.current_dir = os.path.dirname(os.path.abspath(__file__))
        self.full_target_dir = os.path.join(self.current_dir, "test_keys") + "/"

    def test_new_sm2_key(self):
        """
        测试目标：验证 EasySm2Key 密钥生成后公钥、私钥、点坐标均不为空
        参数边界：无
        运行预期：NewKey() 后 GetSm2PublicKeyInHex/GetSm2PrivateKeyInHex 非空，
                 GetPointInHex 含 X/Y；ResetKey() + NewKey() 后密钥对变化
        """
        test1 = EasySm2Key()
        self.assertTrue(test1.GetSm2PublicKeyInHex() != "")
        self.assertTrue(test1.GetSm2PrivateKeyInHex() != "")
        self.assertIn("X", test1.GetPointInHex())
        self.assertIn("Y", test1.GetPointInHex())
        self.assertTrue(test1.GetPointInHex()["X"] != "")
        self.assertTrue(test1.GetPointInHex()["Y"] != "")

        pub_before = test1.GetSm2PublicKeyInHex()
        pri_before = test1.GetSm2PrivateKeyInHex()
        test1.ResetKey()
        test1.NewKey()
        self.assertTrue(test1.GetSm2PublicKeyInHex() != pub_before)
        self.assertTrue(test1.GetSm2PrivateKeyInHex() != pri_before)

    def test_key_export(self):
        """
        测试目标：验证 PEM 导出、公钥/私钥分别导入后行为正确
        参数边界：文件名前缀非空，私钥密码 1~32 字节
        运行预期：导出后仅加载公钥时私钥为空；加载私钥后公钥私钥恢复一致
        """
        test = EasySm2Key()
        pub_key = test.GetSm2PublicKeyInHex()
        pri_key = test.GetSm2PrivateKeyInHex()
        test.ExportToPemFile(self.full_target_dir + "tmp_test", "123456")

        test.LoadSm2PubKey(self.full_target_dir + "tmp_test_sm2_public.pem")
        self.assertEqual(test.GetSm2PublicKeyInHex(), pub_key)
        self.assertEqual(test.GetSm2PrivateKeyInHex(), "", "仅加载公钥时私钥应为空")

        test.LoadSm2PrivateKey(
            self.full_target_dir + "tmp_test_sm2_private.pem", "123456"
        )
        self.assertEqual(test.GetSm2PublicKeyInHex(), pub_key)
        self.assertEqual(test.GetSm2PrivateKeyInHex(), pri_key)

        test.LoadSm2PubKey(self.full_target_dir + "kms_sm2.pem")
        self.assertNotEqual(test.GetSm2PublicKeyInHex(), pub_key)

    def test_key_import_invalid(self):
        """
        测试目标：验证无效公钥文件、空密码、错误密码、过长密码等异常处理
        参数边界：密码为空、长度=33 等越界
        运行预期：均抛出 ValueError 或 TypeError
        """
        test = EasySm2Key()
        with self.assertRaises(Exception):
            test.LoadSm2PubKey(self.full_target_dir + "invalid_pub_key.pem")

        with self.assertRaises(Exception):
            test.LoadSm2PrivateKey(
                self.full_target_dir + "tmp_test_sm2_private.pem", ""
            )

        with self.assertRaises(Exception):
            test.LoadSm2PrivateKey(
                self.full_target_dir + "tmp_test_sm2_private.pem", "1" * 32
            )

        with self.assertRaises(Exception):
            test.LoadSm2PrivateKey(
                self.full_target_dir + "tmp_test_sm2_private.pem", "1" * 33
            )

    def test_export_to_pem_empty_prefix(self):
        """
        测试目标：验证 ExportToPemFile 文件名前缀为空时抛出异常
        参数边界：file_name_prefix 为空字符串
        运行预期：ValueError
        """
        test = EasySm2Key()
        with self.assertRaises(ValueError):
            test.ExportToPemFile("", "123456")

    def test_get_z(self):
        """
        测试目标：验证 EasySm2Key.GetZ() 计算 SM2 签名用 z 值
        参数边界：需有公钥
        运行预期：返回 32 字节 (SM3_DIGEST_SIZE)
        """
        test = EasySm2Key()
        test.LoadSm2PubKey(self.full_target_dir + "tmp_test_sm2_public.pem")
        z = test.GetZ()
        self.assertEqual(len(z), SM3_DIGEST_SIZE)

    def test_get_z_without_public_key(self):
        """
        测试目标：无公钥时调用 GetZ 应抛出异常
        运行预期：ValueError
        """
        test = EasySm2Key()
        test.ResetKey()
        with self.assertRaises(ValueError):
            test.GetZ()

    def test_valid_encrypt_decrypt(self):
        """
        测试目标：验证四种密文模式与两种输出格式下加解密往返一致
        参数边界：明文长度 1~255 字节
        运行预期：每种模式加密后解密得到原文
        """
        test = EasySm2EncryptionKey()
        plain = bytes([random.randint(1, 255) for _ in range(SM2_MAX_PLAINTEXT_SIZE)])
        for mode in SM2CipherMode:
            cipher_b64 = test.Encrypt(
                plain, cipher_mode=mode, cipher_format=SM2CipherFormat.Base64Str
            )
            decrypted = test.Decrypt(base64.b64decode(cipher_b64), cipher_mode=mode)
            self.assertEqual(decrypted, plain)

            cipher_hex = test.Encrypt(
                plain, cipher_mode=mode, cipher_format=SM2CipherFormat.HexStr
            )
            decrypted = test.Decrypt(bytes.fromhex(cipher_hex), cipher_mode=mode)
            self.assertEqual(decrypted, plain)

    def test_encrypt_too_long_plain(self):
        """
        测试目标：明文超过 255 字节时加密应失败
        参数边界：明文长度 = 256
        运行预期：ValueError
        """
        test = EasySm2EncryptionKey()
        plain = bytes([1] * (SM2_MAX_PLAINTEXT_SIZE + 1))
        with self.assertRaises(Exception):
            test.Encrypt(plain)

    def test_decrypt_too_long_cipher(self):
        """
        测试目标：密文超过 366 字节时解密应失败
        参数边界：密文长度 = 367
        运行预期：ValueError
        """
        test = EasySm2EncryptionKey()
        cipher = bytes([1] * (SM2_MAX_CIPHERTEXT_SIZE + 1))
        with self.assertRaises(Exception):
            test.Decrypt(cipher)

    def test_invalid_cipher_mode(self):
        """
        测试目标：传入无效 cipher_mode 时应抛出 TypeError
        运行预期：TypeError
        """
        test = EasySm2EncryptionKey()
        plain = bytes([1] * SM2_MAX_PLAINTEXT_SIZE)
        with self.assertRaises(Exception):
            test.Encrypt(plain, cipher_mode="abc")

    def test_invalid_cipher_format(self):
        """
        测试目标：传入无效 cipher_format 时应抛出 TypeError
        运行预期：TypeError
        """
        test = EasySm2EncryptionKey()
        plain = bytes([1] * SM2_MAX_PLAINTEXT_SIZE)
        with self.assertRaises(Exception):
            test.Encrypt(plain, cipher_format="abc")

    def test_encrypt_without_public_key(self):
        """
        测试目标：仅加载公钥时加密应成功；仅 reset 无公钥时加密应失败
        运行预期：无公钥时 Encrypt 抛出 ValueError
        """
        test = EasySm2EncryptionKey()
        test.ResetKey()
        with self.assertRaises(ValueError):
            test.Encrypt(b"hello")

    def test_has_no_private_key_decrypt(self):
        """
        测试目标：仅加载公钥时解密应失败
        运行预期：Decrypt 抛出 TypeError 或 ValueError
        """
        test = EasySm2EncryptionKey()
        test.LoadSm2PubKey(self.full_target_dir + "tmp_test_sm2_public.pem")
        cipher = bytes([1] * SM2_MAX_CIPHERTEXT_SIZE)
        with self.assertRaises(Exception):
            test.Decrypt(cipher)

    def test_digest_signature(self):
        """
        测试目标：验证 SignDigest 与 VerifyDigestSignature 流程
        参数边界：digest 必须为 32 字节
        运行预期：正确签名验签通过；错误 digest 验签失败
        """
        test = EasySm2Key()
        test.LoadSm2PrivateKey(
            self.full_target_dir + "tmp_test_sm2_private.pem", "123456"
        )
        plain = b"hello,world"
        ctx = EasySM3Digest()
        ctx.UpdateData(plain)
        h, h_len, plain_len = ctx.GetHash()
        self.assertEqual(h_len, SM3_DIGEST_SIZE)
        self.assertEqual(plain_len, len(plain))

        signature = test.SignDigest(digest=h)
        self.assertLessEqual(len(signature), SM2_MAX_SIGNATURE_SIZE)

        verify = EasySm2Key()
        verify.LoadSm2PubKey(self.full_target_dir + "tmp_test_sm2_public.pem")
        self.assertTrue(verify.VerifyDigestSignature(digest=h, signature=signature))
        self.assertFalse(
            verify.VerifyDigestSignature(digest=bytes(32), signature=signature)
        )

    def test_sign_digest_invalid_size(self):
        """
        测试目标：digest 长度非 32 字节时 SignDigest 应失败
        参数边界：digest 长度非 SM3_DIGEST_SIZE
        运行预期：ValueError
        """
        test = EasySm2Key()
        test.LoadSm2PrivateKey(
            self.full_target_dir + "tmp_test_sm2_private.pem", "123456"
        )
        with self.assertRaises(ValueError):
            test.SignDigest(digest=bytes(16))


if __name__ == "__main__":
    unittest.main()
