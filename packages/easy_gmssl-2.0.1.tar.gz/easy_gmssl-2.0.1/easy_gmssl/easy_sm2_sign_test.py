#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SM2 签名验签模块单元测试

测试目标：
  - EasySM2SignKey: 从 PEM 加载私钥、UpdateData、GetSignValue(RS/RS_ASN1)
  - EasySM2VerifyKey: 从 PEM 加载公钥、UpdateData、VerifySignature

参数边界：
  - signer_id: 字符串，用于 SM2 签名 Z 值计算
  - 签名 RS_ASN1: 可变长，最大 72 字节
  - 签名 RS: 固定 64 字节 (r||s 各 32 字节)

运行预期：
  - RS_ASN1/RS 两种模式签名验签均通过
  - 无效 signature_mode、超长签名、RS 模式长度非 64 应抛出异常
"""

import os
import random
import unittest

from .gmssl import SM2_MAX_SIGNATURE_SIZE
from .easy_sm2_sign_key import EasySM2SignKey, EasySM2VerifyKey, SignatureMode


class SM2SignTestCase(unittest.TestCase):
    def setUp(self):
        self.current_dir = os.path.dirname(os.path.abspath(__file__))
        self.full_target_dir = os.path.join(self.current_dir, "test_keys") + "/"

    def test_sign_verify_rs_asn1(self):
        """
        测试目标：RS_ASN1 模式签名验签完整流程
        参数边界：默认 SignatureMode.RS_ASN1，签名长度 64~72 字节
        运行预期：签名成功，验签通过
        """
        signer_id = "test_signer"
        plain = bytes([random.randint(0, 255) for _ in range(64)])

        signer = EasySM2SignKey(
            signer_id=signer_id,
            pem_private_key_file=self.full_target_dir + "tmp_test_sm2_private.pem",
            password="123456",
        )
        signer.UpdateData(plain)
        sig = signer.GetSignValue()
        self.assertLessEqual(len(sig), SM2_MAX_SIGNATURE_SIZE)
        self.assertGreaterEqual(len(sig), 64)

        verifier = EasySM2VerifyKey(
            signer_id=signer_id,
            pem_public_key_file=self.full_target_dir + "tmp_test_sm2_public.pem",
        )
        verifier.UpdateData(plain)
        self.assertTrue(verifier.VerifySignature(sig))

    def test_sign_verify_rs_mode(self):
        """
        测试目标：RS 模式签名验签，签名为 r||s 原始 64 字节
        参数边界：SignatureMode.RS，签名固定 64 字节
        运行预期：签名长度=64，验签通过
        """
        signer_id = "test_signer"
        plain = bytes([random.randint(0, 255) for _ in range(64)])

        signer = EasySM2SignKey(
            signer_id=signer_id,
            pem_private_key_file=self.full_target_dir + "tmp_test_sm2_private.pem",
            password="123456",
        )
        signer.UpdateData(plain)
        sig = signer.GetSignValue(signature_mode=SignatureMode.RS)
        self.assertEqual(len(sig), 64)

        verifier = EasySM2VerifyKey(
            signer_id=signer_id,
            pem_public_key_file=self.full_target_dir + "tmp_test_sm2_public.pem",
        )
        verifier.UpdateData(plain)
        self.assertTrue(verifier.VerifySignature(sig, signature_mode=SignatureMode.RS))

    def test_invalid_sign_mode(self):
        """
        测试目标：传入无效 SignatureMode 时 GetSignValue 应失败
        参数边界：SignatureMode('abc') 非法枚举值
        运行预期：ValueError
        """
        signer = EasySM2SignKey(
            signer_id="test",
            pem_private_key_file=self.full_target_dir + "tmp_test_sm2_private.pem",
            password="123456",
        )
        signer.UpdateData(b"x" * 64)
        with self.assertRaises(Exception):
            signer.GetSignValue(signature_mode=SignatureMode("abc"))

    def test_verify_rs_asn1_signature_too_long(self):
        """
        测试目标：RS_ASN1 模式下签名超过 72 字节时 VerifySignature 应失败
        参数边界：签名长度 = 73
        运行预期：ValueError
        """
        verifier = EasySM2VerifyKey(
            signer_id="test",
            pem_public_key_file=self.full_target_dir + "tmp_test_sm2_public.pem",
        )
        verifier.UpdateData(b"x" * 64)
        bad_sig = bytes([0] * (SM2_MAX_SIGNATURE_SIZE + 1))
        with self.assertRaises(Exception):
            verifier.VerifySignature(bad_sig)

    def test_verify_rs_mode_wrong_length(self):
        """
        测试目标：RS 模式下签名长度非 64 字节时应失败
        参数边界：签名长度 = 65
        运行预期：ValueError
        """
        verifier = EasySM2VerifyKey(
            signer_id="test",
            pem_public_key_file=self.full_target_dir + "tmp_test_sm2_public.pem",
        )
        verifier.UpdateData(b"x" * 64)
        bad_sig = bytes([0] * 65)
        with self.assertRaises(Exception):
            verifier.VerifySignature(bad_sig, signature_mode=SignatureMode.RS)

    def test_verify_wrong_signature(self):
        """
        测试目标：正确长度但错误的签名值应验签失败
        运行预期：VerifySignature 返回 False（不抛异常）
        """
        verifier = EasySM2VerifyKey(
            signer_id="test",
            pem_public_key_file=self.full_target_dir + "tmp_test_sm2_public.pem",
        )
        plain = b"x" * 64
        verifier.UpdateData(plain)
        wrong_sig = bytes([0xFF] * 64)
        self.assertFalse(
            verifier.VerifySignature(wrong_sig, signature_mode=SignatureMode.RS)
        )


if __name__ == "__main__":
    unittest.main()
