#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-12-23 14:10:41

from __future__ import annotations

from typing import Tuple

from .gmssl import (
    SM3_DIGEST_SIZE,
    SM3_HMAC_MAX_KEY_SIZE,
    SM3_HMAC_MIN_KEY_SIZE,
    SM3_HMAC_SIZE,
    SM3_PBKDF2_DEFAULT_SALT_SIZE,
    SM3_PBKDF2_MAX_KEY_SIZE,
    SM3_PBKDF2_MAX_SALT_SIZE,
    SM3_PBKDF2_MAX_ITER,
    SM3_PBKDF2_MIN_ITER,
    Sm3,
    Sm3Hmac,
    Sm3Kdf,
    sm3_pbkdf2,
)


class EasySM3Digest(object):
    """
    EasySM3Digest 对象非线程安全，同一个对象不可并发执行写操作
    """

    def __init__(self):
        self._raw_sm3_key = Sm3()
        self._data_length: int = 0

    def UpdateData(self, data: bytes):
        self._raw_sm3_key.update(data)
        self._data_length += len(data)

    def Reset(self):
        self._raw_sm3_key.reset()
        self._data_length = 0

    def GetHash(self) -> Tuple[bytes, int, int]:
        """
        返回：哈希十六进制串、哈希值长度、明文数据长度
        """
        hash_bytes = self._raw_sm3_key.digest()
        assert len(hash_bytes) == SM3_DIGEST_SIZE
        return hash_bytes, len(hash_bytes), self._data_length

    @staticmethod
    def Hash(data: bytes) -> bytes:
        """
        一次性计算数据的 SM3 哈希值（便捷方法）

        :param data: 待哈希的字节数据
        :return: 32 字节的 SM3 摘要
        """
        ctx = Sm3()
        ctx.update(data)
        return ctx.digest()


class EasySM3Hmac(object):
    def __init__(self, key: bytes):
        if len(key) > SM3_HMAC_MAX_KEY_SIZE:
            raise ValueError(
                "invalid key, maximum key size limit to:{} bytes".format(
                    SM3_HMAC_MAX_KEY_SIZE
                )
            )
        if len(key) < SM3_HMAC_MIN_KEY_SIZE:
            raise ValueError(
                "invalid key, minimum key size required at least:{} bytes".format(
                    SM3_HMAC_MIN_KEY_SIZE
                )
            )
        self._raw_sm3_hmac = Sm3Hmac(key)
        self._key: bytes = key
        self._plain_length: int = 0

    def UpdateData(self, data: bytes):
        self._raw_sm3_hmac.update(data)
        self._plain_length += len(data)

    def Reset(self):
        self._raw_sm3_hmac.reset(self._key)
        self._plain_length = 0

    def GetHmac(self) -> Tuple[bytes, int, int]:
        """
        返回：HMAC十六进制字符串、HMAC值长度、明文数据长度
        """
        hmac_bytes = self._raw_sm3_hmac.generate_mac()
        assert len(hmac_bytes) == SM3_HMAC_SIZE
        return hmac_bytes, len(hmac_bytes), self._plain_length


class EasySM3Kdf(object):
    """
    SM3 密钥派生函数 (KDF) 封装。
    用于从共享秘密等输入派生指定长度的密钥材料，符合国密标准。
    """

    def __init__(self, outlen: int):
        """
        :param outlen: 期望输出的密钥长度（字节），需为正整数
        """
        if outlen < 1:
            raise ValueError("invalid outlen:{}, required >= 1".format(outlen))
        self._kdf = Sm3Kdf(outlen)
        self._outlen = outlen
        self._data_length = 0

    def UpdateData(self, data: bytes):
        self._kdf.update(data)
        self._data_length += len(data)

    def GetKey(self) -> Tuple[bytes, int]:
        """
        返回：(派生密钥字节, 输入数据长度)
        """
        key_bytes = self._kdf.finish()
        return key_bytes, self._data_length


class EasySM3Pbkdf2(object):
    """
    PBKDF2-HMAC-SM3 密钥派生封装。
    用于从密码和盐派生密钥，适用于密码存储、密钥加密等场景。
    迭代次数建议 >= 10000 以提高安全性。
    """

    @staticmethod
    def DeriveKey(
        password: str,
        salt: bytes,
        iterations: int = SM3_PBKDF2_MIN_ITER,
        keylen: int = 32,
    ) -> bytes:
        """
        从密码派生密钥。

        :param password: 用户密码字符串
        :param salt: 盐值，建议 8-16 字节随机数据
        :param iterations: 迭代次数，建议 >= 10000
        :param keylen: 输出密钥长度（字节），最大 256
        :return: 派生得到的密钥字节
        """
        if len(salt) > SM3_PBKDF2_MAX_SALT_SIZE:
            raise ValueError(
                "invalid salt length:{}, max:{}".format(
                    len(salt), SM3_PBKDF2_MAX_SALT_SIZE
                )
            )
        if iterations < SM3_PBKDF2_MIN_ITER or iterations > SM3_PBKDF2_MAX_ITER:
            raise ValueError(
                "invalid iterations:{}, required:[{},{}]".format(
                    iterations, SM3_PBKDF2_MIN_ITER, SM3_PBKDF2_MAX_ITER
                )
            )
        if keylen < 1 or keylen > SM3_PBKDF2_MAX_KEY_SIZE:
            raise ValueError(
                "invalid keylen:{}, required:[1,{}]".format(
                    keylen, SM3_PBKDF2_MAX_KEY_SIZE
                )
            )
        return sm3_pbkdf2(password, salt, iterations, keylen)
