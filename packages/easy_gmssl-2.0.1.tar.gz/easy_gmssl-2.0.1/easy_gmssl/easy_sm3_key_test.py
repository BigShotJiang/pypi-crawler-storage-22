#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SM3 哈希、HMAC、KDF、PBKDF2 模块单元测试

测试目标：
  - EasySM3Digest: 流式哈希、Reset、GetHash、hash() 一次性哈希
  - EasySM3Hmac: 密钥 HMAC，密钥长度 16~64 字节
  - EasySM3Kdf: 密钥派生，outlen 为正整数
  - EasySM3Pbkdf2: 从密码派生，salt/iter/keylen 边界

参数边界：
  - SM3 摘要: 32 字节
  - HMAC 密钥: 16~64 字节
  - PBKDF2: salt≤64, iter∈[10000,16777216], keylen∈[1,256]

运行预期：
  - 相同输入产生相同输出
  - 边界外参数抛出 ValueError
"""

import random
import unittest

from .easy_sm3_key import EasySM3Digest, EasySM3Hmac, EasySM3Kdf, EasySM3Pbkdf2
from .gmssl import (
    SM3_DIGEST_SIZE,
    SM3_HMAC_MAX_KEY_SIZE,
    SM3_HMAC_MIN_KEY_SIZE,
    SM3_HMAC_SIZE,
    SM3_PBKDF2_MAX_ITER,
    SM3_PBKDF2_MAX_KEY_SIZE,
    SM3_PBKDF2_MAX_SALT_SIZE,
    SM3_PBKDF2_MIN_ITER,
)


class SM3KeyTestCase(unittest.TestCase):
    def test_sm3_hash_stream(self):
        """
        测试目标：验证流式 UpdateData + GetHash 与一次性输入结果一致
        参数边界：任意长度数据
        运行预期：分块 update 与一次性 update 结果相同，摘要长度 32
        """
        plain1 = b"hello,world"
        plain2 = b"1234567890"
        ctx = EasySM3Digest()
        ctx.UpdateData(plain1)
        ctx.UpdateData(plain2)
        h1, h_len, total_len = ctx.GetHash()
        self.assertEqual(h_len, SM3_DIGEST_SIZE)
        self.assertEqual(total_len, len(plain1) + len(plain2))

        ctx.Reset()
        ctx.UpdateData(plain1 + plain2)
        h2, _, _ = ctx.GetHash()
        self.assertEqual(h1, h2)

    def test_sm3_hash_one_shot(self):
        """
        测试目标：EasySM3Digest.Hash() 与流式结果一致
        参数边界：任意 bytes
        运行预期：Hash(data) 与 UpdateData(data)+GetHash 结果相同
        """
        data = b"hello,world"
        h1 = EasySM3Digest.Hash(data)
        self.assertEqual(len(h1), SM3_DIGEST_SIZE)
        ctx = EasySM3Digest()
        ctx.UpdateData(data)
        h2, _, _ = ctx.GetHash()
        self.assertEqual(h1, h2)

    def test_sm3_hash_empty(self):
        """
        测试目标：空数据哈希
        参数边界：空 bytes
        运行预期：返回 32 字节摘要（SM3 支持空输入）
        """
        h = EasySM3Digest.Hash(b"")
        self.assertEqual(len(h), SM3_DIGEST_SIZE)

    def test_sm3_hmac_key_boundary(self):
        """
        测试目标：HMAC 密钥长度边界校验
        参数边界：长度 15 拒绝，16/64 接受，65 拒绝
        运行预期：长度 15、65 抛出 ValueError；16、64 正常
        """
        with self.assertRaises(ValueError):
            EasySM3Hmac(bytes(SM3_HMAC_MIN_KEY_SIZE - 1))
        with self.assertRaises(ValueError):
            EasySM3Hmac(bytes(SM3_HMAC_MAX_KEY_SIZE + 1))
        EasySM3Hmac(bytes(SM3_HMAC_MIN_KEY_SIZE))
        EasySM3Hmac(bytes(SM3_HMAC_MAX_KEY_SIZE))

    def test_sm3_hmac_value(self):
        """
        测试目标：HMAC 计算正确性
        参数边界：密钥 16~64 字节
        运行预期：返回 32 字节 HMAC，plain_len 正确
        """
        key = bytes([random.randint(0, 255) for _ in range(SM3_HMAC_MAX_KEY_SIZE)])
        plain = b"hello,world"
        ctx = EasySM3Hmac(key)
        ctx.UpdateData(plain)
        hmac_bytes, hmac_len, plain_len = ctx.GetHmac()
        self.assertEqual(hmac_len, SM3_HMAC_SIZE)
        self.assertEqual(plain_len, len(plain))

    def test_sm3_hmac_reset(self):
        """
        测试目标：Reset 后 HMAC 可重新计算
        运行预期：Reset 后再次 UpdateData+GetHmac 结果与新建实例一致
        """
        key = bytes(16)
        ctx = EasySM3Hmac(key)
        ctx.UpdateData(b"first")
        h1, _, _ = ctx.GetHmac()
        ctx.Reset()
        ctx.UpdateData(b"first")
        h2, _, _ = ctx.GetHmac()
        self.assertEqual(h1, h2)

    def test_sm3_kdf(self):
        """
        测试目标：SM3 KDF 派生指定长度密钥
        参数边界：outlen 为正整数
        运行预期：输出长度=outlen，相同输入产生相同输出
        """
        kdf = EasySM3Kdf(16)
        kdf.UpdateData(b"12345678" * 4)
        key, data_len = kdf.GetKey()
        self.assertEqual(len(key), 16)
        self.assertEqual(data_len, 32)
        kdf2 = EasySM3Kdf(16)
        kdf2.UpdateData(b"12345678" * 4)
        key2, _ = kdf2.GetKey()
        self.assertEqual(key, key2)

    def test_sm3_kdf_invalid_outlen(self):
        """
        测试目标：outlen=0 应抛出 ValueError
        参数边界：outlen < 1
        运行预期：ValueError
        """
        with self.assertRaises(ValueError):
            EasySM3Kdf(0)

    def test_sm3_kdf_large_outlen(self):
        """
        测试目标：较大 outlen 能正常派生
        参数边界：outlen=64
        运行预期：返回 64 字节
        """
        kdf = EasySM3Kdf(64)
        kdf.UpdateData(b"seed")
        key, _ = kdf.GetKey()
        self.assertEqual(len(key), 64)

    def test_sm3_pbkdf2(self):
        """
        测试目标：PBKDF2 从密码派生密钥
        参数边界：iter=10000, keylen=32
        运行预期：输出 32 字节，相同参数相同输出
        """
        salt = b"randomsalt12"
        dk = EasySM3Pbkdf2.DeriveKey("password", salt, SM3_PBKDF2_MIN_ITER, 32)
        self.assertEqual(len(dk), 32)
        dk2 = EasySM3Pbkdf2.DeriveKey("password", salt, SM3_PBKDF2_MIN_ITER, 32)
        self.assertEqual(dk, dk2)

    def test_sm3_pbkdf2_salt_too_long(self):
        """
        测试目标：salt 超过 64 字节应失败
        参数边界：len(salt)=65
        运行预期：ValueError
        """
        with self.assertRaises(ValueError):
            EasySM3Pbkdf2.DeriveKey("pwd", bytes(65), SM3_PBKDF2_MIN_ITER, 32)

    def test_sm3_pbkdf2_iter_too_small(self):
        """
        测试目标：iter < 10000 应失败
        参数边界：iter=9999
        运行预期：ValueError
        """
        with self.assertRaises(ValueError):
            EasySM3Pbkdf2.DeriveKey("pwd", b"salt", 9999, 32)

    def test_sm3_pbkdf2_iter_too_large(self):
        """
        测试目标：iter > 16777216 应失败
        参数边界：iter=16777217
        运行预期：ValueError
        """
        with self.assertRaises(ValueError):
            EasySM3Pbkdf2.DeriveKey("pwd", b"salt", SM3_PBKDF2_MAX_ITER + 1, 32)

    def test_sm3_pbkdf2_keylen_boundary(self):
        """
        测试目标：keylen 边界 1 和 256
        参数边界：keylen=1 接受，keylen=257 拒绝
        运行预期：keylen=1 返回 1 字节；keylen=257 抛出 ValueError
        """
        dk = EasySM3Pbkdf2.DeriveKey("pwd", b"salt", SM3_PBKDF2_MIN_ITER, 1)
        self.assertEqual(len(dk), 1)
        with self.assertRaises(ValueError):
            EasySM3Pbkdf2.DeriveKey(
                "pwd", b"salt", SM3_PBKDF2_MIN_ITER, SM3_PBKDF2_MAX_KEY_SIZE + 1
            )


if __name__ == "__main__":
    unittest.main()
