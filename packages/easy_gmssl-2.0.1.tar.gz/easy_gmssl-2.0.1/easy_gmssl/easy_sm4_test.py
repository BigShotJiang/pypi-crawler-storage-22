#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SM4 对称加密模块单元测试

测试目标：
  - EasySm4CBC: key/iv 均为 16 字节，CBC 加解密
  - EasySm4GCM: key 16 字节，iv 1~64 字节，tag_len 1~16
  - EasySm4CTR: key/iv 均为 16 字节，流式加解密

参数边界：
  - SM4 key/iv(CBC/CTR): 16 字节
  - GCM iv: 1~64 字节
  - GCM tag_len: 1~16 字节

运行预期：
  - 加解密往返得到原文
  - 越界参数抛出 ValueError
"""

import unittest

from .easy_sm4_key import EasySm4CBC, EasySm4CTR, EasySm4GCM
from .gmssl import (
    SM4_BLOCK_SIZE,
    SM4_CBC_IV_SIZE,
    SM4_CTR_IV_SIZE,
    SM4_GCM_DEFAULT_TAG_SIZE,
    SM4_GCM_MAX_IV_SIZE,
    SM4_GCM_MIN_IV_SIZE,
    Sm4Cbc,
)


class SM4TestCase(unittest.TestCase):
    def test_sm4_cbc_encrypt_decrypt(self):
        """
        测试目标：Sm4Cbc 底层加解密
        参数边界：key=iv=16 字节
        运行预期：密文长度为块对齐，解密得原文
        """
        key = b"x" * SM4_BLOCK_SIZE
        iv = b"y" * SM4_CBC_IV_SIZE
        plain = b"hello,world1234567890"
        enc = Sm4Cbc(key, iv, True)
        cipher = enc.update(plain) + enc.finish()
        self.assertEqual(len(cipher) % SM4_BLOCK_SIZE, 0)
        dec = Sm4Cbc(key, iv, False)
        decrypted = dec.update(cipher) + dec.finish()
        self.assertEqual(decrypted, plain)

    def test_sm4_cbc_invalid_key_len(self):
        """
        测试目标：key 长度非 16 应失败
        参数边界：len(key)=15
        运行预期：ValueError
        """
        with self.assertRaises(Exception):
            Sm4Cbc(b"x" * (SM4_BLOCK_SIZE - 1), b"y" * SM4_CBC_IV_SIZE, True)

    def test_sm4_cbc_invalid_iv_len(self):
        """
        测试目标：iv 长度非 16 应失败
        参数边界：len(iv)=15
        运行预期：ValueError
        """
        with self.assertRaises(Exception):
            Sm4Cbc(b"x" * SM4_BLOCK_SIZE, b"y" * (SM4_CBC_IV_SIZE - 1), True)

    def test_easy_sm4_cbc(self):
        """
        测试目标：EasySm4CBC 加解密
        参数边界：key=iv=16
        运行预期：Update+Finish 密文块对齐，解密得原文
        """
        key = b"x" * SM4_BLOCK_SIZE
        iv = b"y" * SM4_CBC_IV_SIZE
        plain = b"hello,world1234567890"
        enc = EasySm4CBC(key, iv, True)
        cipher = enc.Update(plain) + enc.Finish()
        self.assertEqual(len(cipher) % SM4_BLOCK_SIZE, 0)
        dec = EasySm4CBC(key, iv, False)
        decrypted = dec.Update(cipher) + dec.Finish()
        self.assertEqual(decrypted, plain)

    def test_easy_sm4_gcm(self):
        """
        测试目标：EasySm4GCM 认证加密
        参数边界：iv=16, tag_len=8
        运行预期：密文含 tag，解密得原文
        """
        key = b"x" * SM4_BLOCK_SIZE
        iv = b"y" * SM4_CBC_IV_SIZE
        aad = b"a" * 32
        tag_len = 8
        plain = b"hello,world1234567890"
        enc = EasySm4GCM(key, iv, aad, tag_len, True)
        cipher = enc.Update(plain) + enc.Finish()
        self.assertEqual(len(cipher) - tag_len, len(plain))
        dec = EasySm4GCM(key, iv, aad, tag_len, False)
        decrypted = dec.Update(cipher) + dec.Finish()
        self.assertEqual(decrypted, plain)

    def test_easy_sm4_gcm_iv_boundary(self):
        """
        测试目标：GCM iv 边界 1 和 64 字节
        参数边界：iv 长度 1、64 接受；0、65 拒绝
        运行预期：iv=1 和 iv=64 正常；iv=0 或 65 抛出 ValueError
        """
        key = b"x" * SM4_BLOCK_SIZE
        with self.assertRaises(ValueError):
            EasySm4GCM(key, b"", tag_len=16, do_encrypt=True)
        EasySm4GCM(key, b"\x00", tag_len=16, do_encrypt=True)
        EasySm4GCM(key, b"\x00" * SM4_GCM_MAX_IV_SIZE, tag_len=16, do_encrypt=True)
        with self.assertRaises(ValueError):
            EasySm4GCM(
                key, b"\x00" * (SM4_GCM_MAX_IV_SIZE + 1), tag_len=16, do_encrypt=True
            )

    def test_easy_sm4_gcm_tag_len_boundary(self):
        """
        测试目标：GCM tag_len 边界 1 和 16
        参数边界：tag_len 1~16 接受；0、17 拒绝
        运行预期：tag_len=0 或 17 抛出 ValueError
        """
        key = b"x" * SM4_BLOCK_SIZE
        iv = b"y" * 12
        with self.assertRaises(ValueError):
            EasySm4GCM(key, iv, tag_len=0, do_encrypt=True)
        with self.assertRaises(ValueError):
            EasySm4GCM(key, iv, tag_len=17, do_encrypt=True)

    def test_easy_sm4_ctr(self):
        """
        测试目标：SM4-CTR 加解密，密文与明文等长
        参数边界：key=iv=16
        运行预期：加密后解密得原文
        """
        key = b"x" * SM4_BLOCK_SIZE
        iv = b"y" * SM4_CTR_IV_SIZE
        plain = b"hello world 12345"
        enc = EasySm4CTR(key, iv)
        cipher = enc.Update(plain) + enc.Finish()
        dec = EasySm4CTR(key, iv)
        decrypted = dec.Update(cipher) + dec.Finish()
        self.assertEqual(decrypted, plain)

    def test_sm4_ctr_invalid_key(self):
        """
        测试目标：CTR key 长度非 16 应失败
        参数边界：len(key)=15
        运行预期：ValueError
        """
        with self.assertRaises(ValueError):
            EasySm4CTR(b"x" * (SM4_BLOCK_SIZE - 1), b"y" * SM4_CTR_IV_SIZE)

    def test_sm4_ctr_invalid_iv(self):
        """
        测试目标：CTR iv 长度非 16 应失败
        参数边界：len(iv)=15
        运行预期：ValueError
        """
        with self.assertRaises(ValueError):
            EasySm4CTR(b"x" * SM4_BLOCK_SIZE, b"y" * (SM4_CTR_IV_SIZE - 1))


if __name__ == "__main__":
    unittest.main()
