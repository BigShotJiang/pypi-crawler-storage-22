#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-15

"""
SM9 标识密码算法封装

SM9 是基于标识的密码算法（IBC），支持加密与签名两种应用：
- 加密：主密钥生成、用户密钥提取、加解密
- 签名：主密钥生成、用户密钥提取、签名验签

标识（identity）最大 63 字节，明文最大 255 字节。
"""

from __future__ import annotations

from typing import Literal

from .gmssl import (
    NativeError,
    SM9_MAX_CIPHERTEXT_SIZE,
    SM9_MAX_ID_SIZE,
    SM9_MAX_PLAINTEXT_SIZE,
    SM9_SIGNATURE_SIZE,
    Sm9EncKey,
    Sm9EncMasterKey,
    Sm9Signature,
    Sm9SignKey,
    Sm9SignMasterKey,
)


def __check_sm9_password__(password: str):
    """校验 SM9 密钥密码：非空，最长 32 字节"""
    if len(password) <= 0:
        raise ValueError('empty password for sm9 key')
    if len(password) > 32:
        raise ValueError('sm9 key password too long')


def __check_sm9_identity__(identity: str):
    """校验 SM9 标识长度"""
    id_bytes = identity.encode('utf-8')
    if len(id_bytes) > SM9_MAX_ID_SIZE:
        raise ValueError('sm9 identity too long, max {} bytes'.format(SM9_MAX_ID_SIZE))
    if len(id_bytes) <= 0:
        raise ValueError('empty sm9 identity')


# ============ SM9 加密 ============


class EasySM9EncMasterKey(object):
    """
    SM9 加密主密钥（密钥生成中心 KGC 持有）
    支持：主密钥生成、用户密钥提取、加密、PEM 导入导出
    """

    def __init__(self, pem_master_key_file: str = '', password: str = '', pem_public_key_file: str = ''):
        self._master_key = Sm9EncMasterKey()
        if pem_public_key_file:
            self._master_key.import_public_master_key_pem(pem_public_key_file)
        elif pem_master_key_file and password:
            __check_sm9_password__(password)
            self._master_key.import_encrypted_master_key_info_pem(pem_master_key_file, password)
        # 空构造则需后续调用 GenerateMasterKey()

    def GenerateMasterKey(self) -> EasySM9EncMasterKey:
        """生成新的 SM9 加密主密钥对"""
        self._master_key.generate_master_key()
        return self

    def ExtractKey(self, identity: str) -> 'EasySM9EncKey':
        """根据标识提取用户加密私钥"""
        __check_sm9_identity__(identity)
        key = self._master_key.extract_key(identity)
        return EasySM9EncKey(identity=identity, _raw_key=key)

    def Encrypt(self, plaintext: bytes, to_identity: str) -> bytes:
        """使用主密钥公钥对指定标识的用户加密"""
        __check_sm9_identity__(to_identity)
        if len(plaintext) > SM9_MAX_PLAINTEXT_SIZE:
            raise ValueError('plaintext too long, max {} bytes'.format(SM9_MAX_PLAINTEXT_SIZE))
        if len(plaintext) <= 0:
            raise ValueError('empty plaintext')
        return self._master_key.encrypt(plaintext, to_identity)

    def ExportToPemFile(self, file_name_prefix: str, master_key_password: str):
        """
        导出主密钥到 PEM 文件
        生成：{prefix}_sm9_enc_master_private.pem, {prefix}_sm9_enc_master_public.pem
        """
        if len(file_name_prefix) <= 0:
            raise ValueError('empty file name prefix')
        __check_sm9_password__(master_key_password)
        self._master_key.export_encrypted_master_key_info_pem(
            file_name_prefix + '_sm9_enc_master_private.pem', master_key_password
        )
        self._master_key.export_public_master_key_pem(file_name_prefix + '_sm9_enc_master_public.pem')

    def ExportPublicKeyToPem(self, path: str):
        """仅导出主密钥公钥"""
        self._master_key.export_public_master_key_pem(path)

    def HasMasterKey(self) -> bool:
        return self._master_key._has_private_key

    def HasPublicKey(self) -> bool:
        return self._master_key._has_public_key


class EasySM9EncKey(object):
    """
    SM9 用户加密私钥（由 KGC 根据用户标识提取）
    支持：解密、PEM 导入导出
    """

    def __init__(self, identity: str = '', pem_file: str = '', password: str = '', _raw_key: Sm9EncKey = None):
        if _raw_key is not None:
            self._identity = identity
            self._enc_key = _raw_key
        elif pem_file and password:
            __check_sm9_identity__(identity)
            __check_sm9_password__(password)
            self._identity = identity
            self._enc_key = Sm9EncKey(identity)
            try:
                self._enc_key.import_encrypted_private_key_info_pem(pem_file, password)
            except NativeError as e:
                raise ValueError('invalid sm9 enc key file or password: {}'.format(e))
        else:
            raise ValueError('must provide (identity, pem_file, password) or (identity, _raw_key)')

    def Decrypt(self, ciphertext: bytes) -> bytes:
        """解密"""
        if len(ciphertext) > SM9_MAX_CIPHERTEXT_SIZE:
            raise ValueError('ciphertext too long')
        return self._enc_key.decrypt(ciphertext)

    def ExportToPemFile(self, path: str, password: str):
        """导出用户加密私钥到 PEM"""
        __check_sm9_password__(password)
        self._enc_key.export_encrypted_private_key_info_pem(path, password)

    def GetIdentity(self) -> str:
        return self._identity

    def HasPrivateKey(self) -> bool:
        return self._enc_key.has_private_key()


# ============ SM9 签名 ============


class EasySM9SignMasterKey(object):
    """
    SM9 签名主密钥（KGC 持有）
    支持：主密钥生成、用户签名密钥提取、PEM 导入导出
    """

    def __init__(self, pem_master_key_file: str = '', password: str = '', pem_public_key_file: str = ''):
        self._master_key = Sm9SignMasterKey()
        if pem_public_key_file:
            self._master_key.import_public_master_key_pem(pem_public_key_file)
        elif pem_master_key_file and password:
            __check_sm9_password__(password)
            self._master_key.import_encrypted_master_key_info_pem(pem_master_key_file, password)
        # 空构造则需后续调用 GenerateMasterKey()

    def GenerateMasterKey(self) -> EasySM9SignMasterKey:
        """生成新的 SM9 签名主密钥对"""
        self._master_key.generate_master_key()
        return self

    def ExtractKey(self, identity: str) -> 'EasySM9SignKey':
        """根据标识提取用户签名私钥"""
        __check_sm9_identity__(identity)
        key = self._master_key.extract_key(identity)
        return EasySM9SignKey(identity=identity, _raw_key=key)

    def ExportToPemFile(self, file_name_prefix: str, master_key_password: str):
        """
        导出主密钥到 PEM 文件
        生成：{prefix}_sm9_sign_master_private.pem, {prefix}_sm9_sign_master_public.pem
        """
        if len(file_name_prefix) <= 0:
            raise ValueError('empty file name prefix')
        __check_sm9_password__(master_key_password)
        self._master_key.export_encrypted_master_key_info_pem(
            file_name_prefix + '_sm9_sign_master_private.pem', master_key_password
        )
        self._master_key.export_public_master_key_pem(file_name_prefix + '_sm9_sign_master_public.pem')

    def ExportPublicKeyToPem(self, path: str):
        """仅导出主密钥公钥"""
        self._master_key.export_public_master_key_pem(path)

    def HasMasterKey(self) -> bool:
        return self._master_key._has_private_key

    def HasPublicKey(self) -> bool:
        return self._master_key._has_public_key

    def GetRawMasterKey(self):
        """供验签使用，返回底层 Sm9SignMasterKey"""
        return self._master_key


class EasySM9SignKey(object):
    """
    SM9 用户签名私钥（由 KGC 根据用户标识提取）
    支持：签名、PEM 导入导出
    """

    def __init__(self, identity: str = '', pem_file: str = '', password: str = '', _raw_key: Sm9SignKey = None):
        self._ctx = None
        if _raw_key is not None:
            self._identity = identity
            self._sign_key = _raw_key
        elif pem_file and password:
            __check_sm9_identity__(identity)
            __check_sm9_password__(password)
            self._identity = identity
            self._sign_key = Sm9SignKey(identity)
            try:
                self._sign_key.import_encrypted_private_key_info_pem(pem_file, password)
            except NativeError as e:
                raise ValueError('invalid sm9 sign key file or password: {}'.format(e))
        else:
            raise ValueError('must provide (identity, pem_file, password) or (identity, _raw_key)')

    def UpdateData(self, data: bytes):
        """追加待签名数据（流式）"""
        self._sign_ctx.update(data)

    def GetSignValue(self) -> bytes:
        """完成签名并返回签名值"""
        ret = self._sign_ctx.sign(self._sign_key)
        self._ctx = None  # 下次 UpdateData 将重新创建上下文
        return ret

    def Sign(self, data: bytes) -> bytes:
        """一次性对完整数据签名"""
        ctx = Sm9Signature(sign=True)
        ctx.update(data)
        return ctx.sign(self._sign_key)

    def ExportToPemFile(self, path: str, password: str):
        """导出用户签名私钥到 PEM"""
        __check_sm9_password__(password)
        self._sign_key.export_encrypted_private_key_info_pem(path, password)

    def GetIdentity(self) -> str:
        return self._identity

    def HasPrivateKey(self) -> bool:
        return self._sign_key.has_private_key()

    @property
    def _sign_ctx(self) -> Sm9Signature:
        """延迟初始化签名上下文，支持流式 UpdateData"""
        if not hasattr(self, '_ctx') or self._ctx is None:
            self._ctx = Sm9Signature(sign=True)
        return self._ctx


class EasySM9VerifyKey(object):
    """
    SM9 验签（仅需主密钥公钥与签名者标识）
    """

    def __init__(self, signer_id: str, pem_public_master_key_file: str):
        __check_sm9_identity__(signer_id)
        self._signer_id = signer_id
        self._master_key = Sm9SignMasterKey()
        self._master_key.import_public_master_key_pem(pem_public_master_key_file)
        self._ctx = None

    def UpdateData(self, data: bytes):
        """追加待验签数据（流式）"""
        self._verify_ctx.update(data)

    def VerifySignature(self, signature: bytes) -> bool:
        """验证签名"""
        if len(signature) > SM9_SIGNATURE_SIZE:
            raise ValueError('signature too long')
        ret = self._verify_ctx.verify(signature, self._master_key, self._signer_id)
        self._ctx = None  # 下次 UpdateData 将重新创建上下文
        return ret

    def Verify(self, data: bytes, signature: bytes) -> bool:
        """一次性对完整数据验签"""
        ctx = Sm9Signature(sign=False)
        ctx.update(data)
        return ctx.verify(signature, self._master_key, self._signer_id)

    @property
    def _verify_ctx(self) -> Sm9Signature:
        if not hasattr(self, '_ctx') or self._ctx is None:
            self._ctx = Sm9Signature(sign=False)
        return self._ctx
