#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SM9 标识密码模块单元测试

测试目标：
  - EasySM9EncMasterKey / EasySM9EncKey: 主密钥生成、密钥提取、加解密、PEM 导入导出
  - EasySM9SignMasterKey / EasySM9SignKey / EasySM9VerifyKey: 主密钥生成、密钥提取、签名验签

参数边界：
  - 标识: 1 ~ 63 字节 (SM9_MAX_ID_SIZE)
  - 明文: 1 ~ 255 字节 (SM9_MAX_PLAINTEXT_SIZE)
  - 密码: 1 ~ 32 字节
"""

import os
import random
import tempfile
import unittest

from .easy_sm9_key import (
    EasySM9EncKey,
    EasySM9EncMasterKey,
    EasySM9SignKey,
    EasySM9SignMasterKey,
    EasySM9VerifyKey,
)
from .gmssl import SM9_MAX_PLAINTEXT_SIZE


class SM9EncCase(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.identity = 'test_user_001'
        self.password = '123456'

    def tearDown(self):
        import shutil
        if os.path.exists(self.tmp_dir):
            shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_enc_master_key_generate_and_extract(self):
        """主密钥生成、用户密钥提取、加解密往返"""
        master = EasySM9EncMasterKey()
        master.GenerateMasterKey()
        self.assertTrue(master.HasMasterKey())
        self.assertTrue(master.HasPublicKey())

        user_key = master.ExtractKey(self.identity)
        self.assertEqual(user_key.GetIdentity(), self.identity)
        self.assertTrue(user_key.HasPrivateKey())

        plain = b'hello, SM9 encryption!'
        cipher = master.Encrypt(plain, self.identity)
        self.assertIsInstance(cipher, bytes)
        self.assertGreater(len(cipher), 0)

        decrypted = user_key.Decrypt(cipher)
        self.assertEqual(decrypted, plain)

    def test_enc_export_import_roundtrip(self):
        """主密钥与用户密钥 PEM 导出导入往返"""
        master = EasySM9EncMasterKey()
        master.GenerateMasterKey()
        master_prefix = os.path.join(self.tmp_dir, 'sm9_enc_master')
        master.ExportToPemFile(master_prefix, self.password)

        user_key = master.ExtractKey(self.identity)
        user_pem = os.path.join(self.tmp_dir, 'sm9_enc_user.pem')
        user_key.ExportToPemFile(user_pem, self.password)

        # 从文件加载主密钥公钥（仅加密）
        master_pub = EasySM9EncMasterKey(pem_public_key_file=master_prefix + '_sm9_enc_master_public.pem')
        cipher = master_pub.Encrypt(b'test', self.identity)

        # 从文件加载用户私钥解密
        user_loaded = EasySM9EncKey(identity=self.identity, pem_file=user_pem, password=self.password)
        decrypted = user_loaded.Decrypt(cipher)
        self.assertEqual(decrypted, b'test')

    def test_enc_plaintext_boundary(self):
        """明文长度边界：1 字节、255 字节"""
        master = EasySM9EncMasterKey()
        master.GenerateMasterKey()
        user_key = master.ExtractKey(self.identity)

        plain1 = b'x'
        cipher1 = master.Encrypt(plain1, self.identity)
        self.assertEqual(user_key.Decrypt(cipher1), plain1)

        plain255 = bytes([random.randint(0, 255) for _ in range(SM9_MAX_PLAINTEXT_SIZE)])
        cipher255 = master.Encrypt(plain255, self.identity)
        self.assertEqual(user_key.Decrypt(cipher255), plain255)

    def test_enc_plaintext_too_long(self):
        """明文超长应失败"""
        master = EasySM9EncMasterKey()
        master.GenerateMasterKey()
        with self.assertRaises(ValueError):
            master.Encrypt(bytes(256), self.identity)

    def test_enc_empty_plaintext(self):
        """空明文应失败"""
        master = EasySM9EncMasterKey()
        master.GenerateMasterKey()
        with self.assertRaises(ValueError):
            master.Encrypt(b'', self.identity)

    def test_enc_identity_too_long(self):
        """标识超长应失败"""
        master = EasySM9EncMasterKey()
        master.GenerateMasterKey()
        with self.assertRaises(ValueError):
            master.ExtractKey('x' * 64)

    def test_enc_password_empty(self):
        """空密码应失败"""
        master = EasySM9EncMasterKey()
        master.GenerateMasterKey()
        with self.assertRaises(ValueError):
            master.ExportToPemFile(self.tmp_dir + '/x', '')


class SM9SignCase(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.identity = 'signer_alice'
        self.password = '123456'

    def tearDown(self):
        import shutil
        if os.path.exists(self.tmp_dir):
            shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_sign_master_key_generate_and_extract(self):
        """主密钥生成、用户签名密钥提取、签名验签"""
        master = EasySM9SignMasterKey()
        master.GenerateMasterKey()
        self.assertTrue(master.HasMasterKey())
        self.assertTrue(master.HasPublicKey())

        sign_key = master.ExtractKey(self.identity)
        self.assertEqual(sign_key.GetIdentity(), self.identity)
        self.assertTrue(sign_key.HasPrivateKey())

        data = b'hello, SM9 signature!'
        sig = sign_key.Sign(data)

        master.ExportPublicKeyToPem(self.tmp_dir + '/pub.pem')
        verify_key = EasySM9VerifyKey(self.identity, self.tmp_dir + '/pub.pem')
        self.assertTrue(verify_key.Verify(data, sig))

    def test_sign_streaming_update(self):
        """流式 UpdateData + GetSignValue"""
        master = EasySM9SignMasterKey()
        master.GenerateMasterKey()
        sign_key = master.ExtractKey(self.identity)
        master.ExportPublicKeyToPem(self.tmp_dir + '/pub.pem')

        sign_key.UpdateData(b'part1')
        sign_key.UpdateData(b'part2')
        sig = sign_key.GetSignValue()

        verify_key = EasySM9VerifyKey(self.identity, self.tmp_dir + '/pub.pem')
        verify_key.UpdateData(b'part1')
        verify_key.UpdateData(b'part2')
        self.assertTrue(verify_key.VerifySignature(sig))

    def test_sign_export_import_roundtrip(self):
        """签名密钥 PEM 导出导入"""
        master = EasySM9SignMasterKey()
        master.GenerateMasterKey()
        master.ExportToPemFile(os.path.join(self.tmp_dir, 'sm9_sign_master'), self.password)

        sign_key = master.ExtractKey(self.identity)
        sign_pem = os.path.join(self.tmp_dir, 'sm9_sign_user.pem')
        sign_key.ExportToPemFile(sign_pem, self.password)

        master.ExportPublicKeyToPem(os.path.join(self.tmp_dir, 'pub.pem'))

        sign_loaded = EasySM9SignKey(identity=self.identity, pem_file=sign_pem, password=self.password)
        data = b'test data'
        sig = sign_loaded.Sign(data)

        verify_key = EasySM9VerifyKey(self.identity, os.path.join(self.tmp_dir, 'pub.pem'))
        self.assertTrue(verify_key.Verify(data, sig))

    def test_sign_verify_wrong_data_fails(self):
        """错误数据验签应失败"""
        master = EasySM9SignMasterKey()
        master.GenerateMasterKey()
        sign_key = master.ExtractKey(self.identity)
        master.ExportPublicKeyToPem(self.tmp_dir + '/pub.pem')

        sig = sign_key.Sign(b'correct')
        verify_key = EasySM9VerifyKey(self.identity, self.tmp_dir + '/pub.pem')
        self.assertFalse(verify_key.Verify(b'wrong', sig))


if __name__ == '__main__':
    unittest.main()
