#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
祖冲之 (ZUC) 序列密码模块单元测试

测试目标：
  - EasyZuc: 密钥和 IV 均为 16 字节，流式加解密

参数边界：
  - key: 16 字节
  - iv: 16 字节
  - 输出与输入等长（序列密码特性）

运行预期：
  - 加密后解密得原文
  - key/iv 长度错误抛出 ValueError
"""

import unittest

from .easy_random_data import EasyRandomData, RandomMode
from .easy_zuc import EasyZuc
from .gmssl import ZUC_IV_SIZE, ZUC_KEY_SIZE


class ZucTestCase(unittest.TestCase):
    def test_zuc_encrypt_decrypt(self):
        """
        测试目标：ZUC 加解密往返
        参数边界：key=iv=16 字节
        运行预期：密文总长=明文总长，解密得原文
        """
        key = EasyRandomData(RandomMode.RandomBytes).GetRandomData(ZUC_KEY_SIZE)
        iv = EasyRandomData(RandomMode.RandomBytes).GetRandomData(ZUC_IV_SIZE)
        plain1 = b"hello,world"
        plain2 = b"1234567890"

        enc = EasyZuc(key, iv)
        c1 = enc.Update(plain1)
        c2 = enc.Update(plain2)
        c3 = enc.Finish()
        cipher = c1 + c2 + c3
        self.assertEqual(len(cipher), len(plain1) + len(plain2))

        dec = EasyZuc(key, iv)
        d1 = dec.Update(c1)
        d2 = dec.Update(c2)
        d3 = dec.Update(c3)
        d4 = dec.Finish()
        self.assertEqual(d1 + d2 + d3 + d4, plain1 + plain2)

    def test_zuc_invalid_key_size(self):
        """
        测试目标：key 长度非 16 应失败
        参数边界：len(key)=15
        运行预期：ValueError
        """
        with self.assertRaises(ValueError):
            EasyZuc(bytes(ZUC_KEY_SIZE - 1), bytes(ZUC_IV_SIZE))

    def test_zuc_invalid_iv_size(self):
        """
        测试目标：iv 长度非 16 应失败
        参数边界：len(iv)=15
        运行预期：ValueError
        """
        with self.assertRaises(ValueError):
            EasyZuc(bytes(ZUC_KEY_SIZE), bytes(ZUC_IV_SIZE - 1))

    def test_zuc_empty_input(self):
        """
        测试目标：空输入时 Update 返回空，Finish 可能返回空
        运行预期：不抛异常，解密得空
        """
        key = bytes(ZUC_KEY_SIZE)
        iv = bytes(ZUC_IV_SIZE)
        enc = EasyZuc(key, iv)
        c1 = enc.Update(b"")
        c2 = enc.Finish()
        dec = EasyZuc(key, iv)
        d1 = dec.Update(c1)
        d2 = dec.Update(c2)
        d3 = dec.Finish()
        self.assertEqual(d1 + d2 + d3, b"")


if __name__ == "__main__":
    unittest.main()
