#!/bin/bash
# easy_gmssl 单元测试运行脚本
# 用法: ./run_unittest.sh 或 bash run_unittest.sh
# 依赖: Python 3.10+, easy_gmssl 依赖已安装 (pyasn1 等)

set -e
cd "$(dirname "$0")/.."
echo "=== easy_gmssl 单元测试 ==="

# 优先使用 pytest，否则使用 unittest discover
if python3 -m pytest --version &>/dev/null; then
    python3 -m pytest easy_gmssl/ -v
else
    python3 -m unittest discover -s easy_gmssl -p '*_test.py' -v
fi

echo "=== 全部测试通过 ==="
