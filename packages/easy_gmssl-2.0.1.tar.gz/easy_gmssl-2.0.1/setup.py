#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-12-22 10:34:03

from __future__ import annotations

import os
import shutil
import subprocess

from setuptools import Extension, find_packages, setup
from setuptools.command.build_ext import build_ext

# GmSSL 3.1.1 固定版本，easy_gmssl 是对该执行版本的封装
# 安装目录名需与 gmssl.py 中加载动态库的路径一致
_GMSSL_VERSION = "3.1.1"
_GMSSL_INSTALL_DIR = ".gmssl_3.1.1_install"


def _get_project_root():
    """获取项目根目录，确保无论从何处执行 setup.py 路径都正确"""
    return os.path.dirname(os.path.abspath(__file__))


def _get_gmssl_source_dir():
    """获取 GmSSL 源码目录路径"""
    return os.path.join(
        _get_project_root(), "easy_gmssl", "Core", f"GmSSL-{_GMSSL_VERSION}"
    )


def _get_install_dir():
    """获取 GmSSL 安装目录（与 gmssl.py 加载路径一致）"""
    home = os.path.expanduser("~")
    if not home:
        raise RuntimeError(
            "无法获取用户主目录 (HOME 未设置)。请设置 HOME 环境变量后再安装。"
        )
    return os.path.join(home, _GMSSL_INSTALL_DIR)


def _ensure_cmake_available():
    """检查 cmake 是否可用，安装前给出明确提示"""
    if shutil.which("cmake") is None:
        raise RuntimeError(
            "未找到 cmake。安装 easy_gmssl 需要 cmake 来编译底层 GmSSL C 库。\n"
            "请先安装 cmake：\n"
            "  - macOS: brew install cmake\n"
            "  - Ubuntu/Debian: sudo apt install cmake\n"
            "  - Windows: 从 https://cmake.org/download/ 下载安装"
        )


def _ensure_gmssl_source_exists(source_dir: str):
    """检查 GmSSL 源码目录是否存在，缺失时给出明确提示"""
    if not os.path.isdir(source_dir):
        raise RuntimeError(
            f"未找到 GmSSL 源码目录: {source_dir}\n"
            f"请确保 easy_gmssl 子模块已正确初始化：\n"
            "  git submodule update --init --recursive"
        )
    cmake_lists = os.path.join(source_dir, "CMakeLists.txt")
    if not os.path.isfile(cmake_lists):
        raise RuntimeError(
            f"GmSSL 源码目录不完整，缺少 CMakeLists.txt: {source_dir}\n"
            "请检查子模块或源码是否完整。"
        )


def _ensure_install_dir_writable(install_dir: str):
    """检查安装目录是否可写，必要时创建父目录"""
    parent = os.path.dirname(install_dir)
    if not os.path.exists(parent):
        try:
            os.makedirs(parent, exist_ok=True)
        except OSError as e:
            raise RuntimeError(
                f"无法创建安装目录的父目录 {parent}: {e}\n" "请检查磁盘空间与权限。"
            )
    # 若目录已存在则检查可写；若不存在则检查父目录可写（后续 cmake install 会创建）
    check_dir = install_dir if os.path.exists(install_dir) else parent
    if not os.access(check_dir, os.W_OK):
        raise RuntimeError(
            f"目录不可写: {check_dir}\n" "请检查权限或选择其他安装位置。"
        )


def _get_parallel_jobs():
    """获取并行构建的 job 数，默认使用 CPU 核心数"""
    try:
        return os.cpu_count() or 4
    except (AttributeError, TypeError):
        return 4


class CMakeExtension(Extension):
    def __init__(self, name, source_dir=""):
        Extension.__init__(self, name, sources=[])
        self.source_dir = os.path.abspath(source_dir)


class CMakeBuild(build_ext):
    def run(self):
        for ext in self.extensions:
            self.build_extension(ext)

    def build_extension(self, ext: CMakeExtension):
        _ensure_cmake_available()

        source_dir = ext.source_dir
        _ensure_gmssl_source_exists(source_dir)

        install_dir = _get_install_dir()
        _ensure_install_dir_writable(install_dir)

        # CMAKE_INSTALL_PREFIX: 安装到用户目录，避免污染系统路径
        # BUILD_SHARED_LIBS: 构建动态库供 Python ctypes 加载
        # CMAKE_BUILD_TYPE: 单配置生成器(Unix Makefiles/Ninja)需要，否则默认空/Debug
        cfg = "Debug" if self.debug else "Release"
        cmake_args = [
            f"-DCMAKE_INSTALL_PREFIX={install_dir}",
            "-DBUILD_SHARED_LIBS=ON",
            f"-DCMAKE_BUILD_TYPE={cfg}",
        ]

        if not os.path.exists(self.build_temp):
            os.makedirs(self.build_temp)

        # 配置阶段
        config_cmd = ["cmake", source_dir] + cmake_args
        if self.verbose:
            print(f"运行: {' '.join(config_cmd)}")
        result = subprocess.run(
            config_cmd, cwd=self.build_temp, capture_output=True, text=True
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"cmake 配置失败 (exit {result.returncode}):\n"
                f"命令: {' '.join(config_cmd)}\n"
                f"工作目录: {self.build_temp}\n"
                f"stderr:\n{result.stderr or '(无)'}\n"
                f"stdout:\n{result.stdout or '(无)'}"
            )

        # 构建并安装阶段
        # --config 仅对多配置生成器(MSVC/Xcode)有效，单配置生成器会忽略
        # --parallel 加速构建（单配置生成器支持）
        build_cmd = [
            "cmake",
            "--build",
            ".",
            "--target",
            "install",
            "--config",
            cfg,
            "--parallel",
            str(_get_parallel_jobs()),
        ]
        if self.verbose:
            print(f"运行: {' '.join(build_cmd)}")
        result = subprocess.run(
            build_cmd, cwd=self.build_temp, capture_output=True, text=True
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"cmake 构建/安装失败 (exit {result.returncode}):\n"
                f"命令: {' '.join(build_cmd)}\n"
                f"工作目录: {self.build_temp}\n"
                f"stderr:\n{result.stderr or '(无)'}\n"
                f"stdout:\n{result.stdout or '(无)'}"
            )


def _read_long_description():
    """安全读取 long_description，避免路径依赖 cwd"""
    readme_path = os.path.join(_get_project_root(), "README.md")
    if os.path.isfile(readme_path):
        with open(readme_path, encoding="utf-8") as f:
            return f.read()
    return ""


setup(
    name="easy_gmssl",
    version="2.0.1",
    description="easy gmssl for python",
    long_description=_read_long_description(),
    long_description_content_type="text/markdown",
    author="bowenerchen",
    author_email="bowenerchen@foxmail.com",
    url="https://cipherhub.cloud",
    packages=find_packages(),
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",
    ],
    python_requires=">=3.10",
    # install_requires = [
    #     'cmake >= 3.0'
    # ],
    ext_modules=[
        CMakeExtension("GmSSL", _get_gmssl_source_dir()),
    ],
    cmdclass=dict(build_ext=CMakeBuild),
    zip_safe=False,
)
