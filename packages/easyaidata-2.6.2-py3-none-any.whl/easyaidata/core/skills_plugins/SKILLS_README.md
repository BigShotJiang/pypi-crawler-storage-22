# Skills README

This file contains information about the skills system.