"""
扩展加载器
功能：加载同目录下的RiskWarningTool.pyd和Medwise.py扩展
"""

import os
import importlib.util

# 扩展信息
extension_info = {
    'name': '器械扩展加载工具',
    'version': '1.0.1',
    'description': '加载几个器械扩展',
    'category': '工具扩展'
}

def init_extension(app):
    """
    初始化扩展
    :param app: 主应用程序对象
    """
    try:
        # 获取当前文件所在目录（同目录）
        current_dir = None
        
        # 方法1: 使用__file__变量获取当前文件所在目录
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            print(f"[扩展加载器] 使用同目录: {current_dir}")
        except NameError:
            print(f"[扩展加载器] __file__未定义")
        
        # 方法2: 直接从app对象的loaded_extensions中获取ExtensionLoader的路径
        if not current_dir:
            try:
                if hasattr(app, 'loaded_extensions'):
                    # 检查已加载的扩展，查找ExtensionLoader
                    for ext_path in app.loaded_extensions:
                        if 'ExtensionLoader' in ext_path:
                            current_dir = os.path.dirname(os.path.abspath(ext_path))
                            print(f"[扩展加载器] 从已加载扩展中获取目录: {current_dir}")
                            break
            except Exception as e:
                print(f"[扩展加载器] 从已加载扩展获取目录失败: {str(e)}")
        
        # 方法3: 从调用栈中获取信息
        if not current_dir:
            try:
                import inspect
                # 获取调用栈
                stack = inspect.stack()
                if stack:
                    # 查找可能的扩展文件路径
                    for frame in stack:
                        frame_info = frame[0]
                        # 检查帧中是否有文件路径相关信息
                        if 'file_path' in frame_info.f_locals:
                            # 这可能是在load_extension方法中
                            ext_path = frame_info.f_locals['file_path']
                            if 'ExtensionLoader' in ext_path:
                                current_dir = os.path.dirname(os.path.abspath(ext_path))
                                print(f"[扩展加载器] 从调用栈获取目录: {current_dir}")
                                break
            except Exception as e:
                print(f"[扩展加载器] 从调用栈获取目录失败: {str(e)}")
        
        # 方法4: 如果无法获取目录，使用extensions目录
        if not current_dir:
            # 尝试使用与app.py同目录的extensions目录
            try:
                # 获取当前工作目录
                cwd = os.getcwd()
                # 检查当前目录是否有extensions子目录
                current_dir = os.path.join(cwd, 'extensions')
                if os.path.exists(current_dir):
                    print(f"[扩展加载器] 使用当前目录下的extensions目录: {current_dir}")
                else:
                    # 检查temp目录下的extensions目录
                    current_dir = os.path.join(cwd, 'temp', 'extensions')
                    if os.path.exists(current_dir):
                        print(f"[扩展加载器] 使用默认目录: {current_dir}")
                    else:
                        # 如果temp/extensions目录不存在，使用当前工作目录
                        current_dir = cwd
                        print(f"[扩展加载器] temp/extensions目录不存在，使用当前工作目录: {current_dir}")
            except Exception as e:
                # 如果所有方法都失败，使用当前工作目录
                current_dir = os.getcwd()
                print(f"[扩展加载器] 获取目录失败，使用当前工作目录: {current_dir}")
        
        # 加载扩展
        loaded_files = []

        # 加载VisualizationTool.py
        VisualizationTool_path = os.path.join(current_dir, 'VisualizationTool.pyd')
        if os.path.exists(VisualizationTool_path):
            print(f"[扩展加载器] 尝试加载: {VisualizationTool_path}")
            load_py_extension(app, VisualizationTool_path)
            loaded_files.append(VisualizationTool_path)
        else:
            print(f"[扩展加载器] 未找到: {VisualizationTool_path}")

        # 加载RiskWarningTool.pyd
        risk_warning_path = os.path.join(current_dir, 'RiskWarningTool.pyd')
        if os.path.exists(risk_warning_path):
            print(f"[扩展加载器] 尝试加载: {risk_warning_path}")
            load_pyd_extension(app, risk_warning_path)
            loaded_files.append(risk_warning_path)
        else:
            print(f"[扩展加载器] 未找到: {risk_warning_path}")
        
        # 加载Medwise.py
        medwise_path = os.path.join(current_dir, 'Medwise.pyd')
        if os.path.exists(medwise_path):
            print(f"[扩展加载器] 尝试加载: {medwise_path}")
            load_py_extension(app, medwise_path)
            loaded_files.append(medwise_path)
        else:
            print(f"[扩展加载器] 未找到: {medwise_path}")
        
        # 输出加载结果
        if loaded_files:
            print(f"[扩展加载器] 成功加载了 {len(loaded_files)} 个扩展文件")
            for file_path in loaded_files:
                print(f"[扩展加载器] - {os.path.basename(file_path)}")
        else:
            print(f"[扩展加载器] 未加载任何扩展文件")
        
        print("[扩展加载器] 加载完成")
        
    except Exception as e:
        print(f"[扩展加载器] 加载失败: {str(e)}")
        import traceback
        traceback.print_exc()

def load_pyd_extension(app, extension_path):
    """
    加载.pyd扩展
    :param app: 主应用程序对象
    :param extension_path: 扩展文件路径
    """
    try:
        module_name = os.path.basename(extension_path).replace('.pyd', '')
        spec = importlib.util.spec_from_file_location(module_name, extension_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        if hasattr(module, 'init_extension'):
            module.init_extension(app)
            print(f"[扩展加载器] 成功加载: {module_name}")
        else:
            print(f"[扩展加载器] {module_name} 缺少init_extension函数")
    except Exception as e:
        print(f"[扩展加载器] 加载{extension_path}失败: {str(e)}")

def load_py_extension(app, extension_path):
    """
    加载.py扩展
    :param app: 主应用程序对象
    :param extension_path: 扩展文件路径
    """
    try:
        # 读取扩展文件内容
        with open(extension_path, 'r', encoding='utf-8') as f:
            extension_code = f.read()
        
        # 检查是否包含init_extension函数定义
        if 'def init_extension' not in extension_code:
            print(f"[扩展加载器] {extension_path} 缺少init_extension函数定义")
            return
        
        # 准备执行环境
        extension_globals = {
            'self': app,
            'tk': __import__('tkinter'),
            'ttk': __import__('tkinter.ttk'),
            'pd': __import__('pandas'),
            'np': __import__('numpy')
        }
        
        # 执行扩展代码
        exec(extension_code, extension_globals)
        
        # 检查是否有初始化函数
        if 'init_extension' in extension_globals:
            extension_globals['init_extension'](app)
            print(f"[扩展加载器] 成功加载: {os.path.basename(extension_path)}")
        else:
            print(f"[扩展加载器] {extension_path} 执行后未找到init_extension函数")
    except Exception as e:
        print(f"[扩展加载器] 加载{extension_path}失败: {str(e)}")
        import traceback
        traceback.print_exc()
