from setuptools import setup
import os

# Define version directly to avoid importing load.py during build
current_version = "2.6.2"

# 获取项目根目录
project_root = os.path.abspath(os.path.dirname(__file__))

# 定义需要包含的非Python文件
package_data = {
    'easyaidata': [
        'ico/*',
        'extensions/*',
        'core/*.pyd',
        'core/skills_plugins/*',
        '*.pyd',
        '*.py',  # 包含所有Python文件
        'core/*.py',
        'core/skills_plugins/*.py',
        'README.md',
        'LICENSE.txt'
    ],
}

# 从app.py和core文件夹中提取所有依赖
install_requires = [
    'pandas',
    'numpy',
    'Pillow',
    'tksheet',
    'polars>=0.0.1',
    'pyarrow>=0.0.1',
    'requests',
    'python-docx',
    'pydantic',
    'matplotlib',
    # tkinter是Python标准库，不需要单独安装
    # os, sys, threading, sqlite3等都是标准库，不需要单独安装
]

# 读取README.md文件内容作为long_description
with open(os.path.join(project_root, 'README.md'), 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='easyaidata',
    version=current_version,
    description='A easy-to-use data processing tool with GUI',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='sysucai',
    author_email='411703730@qq.com',
    url='https://pypi.org/project/easyaidata/',
    packages=['easyaidata'],
    package_dir={'easyaidata': '.'},
    package_data=package_data,
    install_requires=install_requires,
    entry_points={
        'console_scripts': [
            'easyaidata=easyaidata.load:main',
        ],
    },
    platforms=['Windows'],
    license='Proprietary Non-Commercial',
    data_files=[('', ['LICENSE.txt', 'README.md'])],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Intended Audience :: End Users/Desktop',
        'Topic :: Scientific/Engineering :: Information Analysis',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: Python :: 3.14',
        'Operating System :: Microsoft :: Windows',
    ],
    python_requires='>=3.8',
)
