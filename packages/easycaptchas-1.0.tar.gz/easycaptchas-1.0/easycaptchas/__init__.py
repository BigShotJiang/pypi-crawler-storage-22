from .onyxsolver import OnyxSolver
from .voidsolver import VoidSolver
from .teamaisolver import TeamAISolver
from .utils import print_banner, eg, get_api_key, error_payload, color_warn, color_ok
from .tester import testsolvers

__version__ = "1.0"
__author__ = "DraxonV1"

class CaptchaSolver:
    def __init__(self, config=None):
        self.solvers = []

        priority = ["onyx", "void", "teamai"]
        default_solver = (config or {}).get("default", "onyx").lower()
        order = [default_solver] + [name for name in priority if name != default_solver]

        for name in order:
            key = config.get(f"{name}_key") if config else None
            if not key: key = get_api_key(name)
            if key:
                if name == "onyx":
                    devid = config.get("onyx_devid") if config else None
                    self.solvers.append(("Onyx", OnyxSolver(key, devid=devid)))
                elif name == "void": self.solvers.append(("Void", VoidSolver(key)))
                elif name == "teamai": self.solvers.append(("TeamAI", TeamAISolver(key)))

    def solve(self, sitekey, siteurl, captcha_details, proxy=None):
        if not sitekey:
            return error_payload("sitekey is required", provider="CaptchaSolver")
        if not siteurl:
            return error_payload("siteurl is required", provider="CaptchaSolver")
        if not isinstance(captcha_details, dict) or not captcha_details:
            return error_payload("captcha_details must be a non-empty dict", provider="CaptchaSolver")
        if not self.solvers:
            return error_payload("No solvers configured", provider="CaptchaSolver")

        failures = []
        for name, solver in self.solvers:
            try:
                res = solver.solve(sitekey, siteurl, captcha_details, proxy)
            except Exception as exc:
                res = error_payload(f"{name} crashed during solve", provider=name, detail=exc)

            if res.get("success"):
                return {
                    "success": True, "token": res.get("token"),
                    "rqtoken": res.get("rqtoken", ""), "user_agent": res.get("user_agent", ""),
                    "solver": name,
                    "message": res.get("message") or color_ok(f"Solved with {name}"),
                }
            failures.append(res)

        return error_payload(
            "All solvers failed",
            provider="CaptchaSolver",
            detail=failures,
        )

def help():
    print_banner()
    print(eg.color("Documentation and API keys:", "#00FFFF"))
    print(eg.color("1. Onyx: https://onyxsolver.com", "#FFFFFF"))
    print(eg.color("2. Void: https://voidsolver.tech", "#FFFFFF"))
    print(eg.color("3. TeamAI: discord.com/recaptcha", "#FFFFFF"))
    print(color_warn("\nUse easycaptchas.testsolvers() to check configuration."))
    print(color_warn("Solve signature: solve(sitekey, siteurl, captcha_details, proxy=None)"))
