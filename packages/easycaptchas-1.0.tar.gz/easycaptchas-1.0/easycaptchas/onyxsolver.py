import httpx
import time
from .utils import get_api_key, error_payload, color_ok


class OnyxSolver:
    def __init__(self, api_key=None, devid=None, timeout=120, poll_interval=3):
        self.api_key = (api_key or get_api_key("ONYX") or "").strip()
        self.devid = devid or get_api_key("ONYX_DEVID")
        self.base_url = "https://onyxsolver.com"
        self.timeout = timeout
        self.poll_interval = poll_interval

    def solve(self, sitekey, siteurl, captcha_details, proxy=None):
        endpoint = f"{self.base_url}/api/createTask"
        task_type = "PopularCaptchaTask" if proxy else "PopularCaptchaTaskProxyless"
        
        task = {
            "type": task_type,
            "websiteURL": siteurl,
            "websiteKey": sitekey,
        }
        
        if self.devid:
            task["devid"] = self.devid
        
        rqdata = (captcha_details or {}).get("rqdata") or (captcha_details or {}).get("rqd")
        if rqdata:
            task["rqdata"] = rqdata
        
        if proxy:
            task["proxy"] = proxy
        
        payload = {
            "clientKey": self.api_key,
            "task": task
        }
        
        try:
            with httpx.Client(timeout=30) as client:
                response = client.post(endpoint, json=payload)
                result = response.json()
            
            if result.get("errorId", 0) != 0:
                error_desc = result.get("errorDescription") or result.get("errorCode") or "Unknown Onyx Error"
                return error_payload(f"Onyx Error {result.get('errorId')}: {error_desc}", provider="Onyx", raw_response=result)
            
            task_id = result.get("taskId")
            if not task_id:
                return error_payload("No task ID returned by Onyx", provider="Onyx", raw_response=result)
                
            return self.get_task_result(task_id)
        except Exception as e:
            return error_payload(f"Onyx Connection Error: {str(e)}", provider="Onyx")

    def get_task_result(self, task_id):
        endpoint = f"{self.base_url}/api/getTaskResult"
        payload = {
            "clientKey": self.api_key,
            "taskId": task_id
        }
        
        start_time = time.time()
        while True:
            if time.time() - start_time > self.timeout:
                return error_payload("Onyx Timeout", provider="Onyx")
            
            try:
                with httpx.Client(timeout=30) as client:
                    response = client.post(endpoint, json=payload)
                    result = response.json()
                
                if result.get("errorId", 0) != 0:
                    error_desc = result.get("errorDescription") or result.get("errorCode") or "Unknown Onyx Error"
                    return error_payload(f"Onyx Error {result.get('errorId')}: {error_desc}", provider="Onyx", raw_response=result)
                
                status = result.get("status", "")
                if status == "ready":
                    solution = result.get("solution", {})
                    captcha_key = solution.get("gRecaptchaResponse") or solution.get("text")
                    if captcha_key:
                        return {
                            "success": True,
                            "token": captcha_key,
                            "rqtoken": "",
                            "user_agent": solution.get("userAgent", ""),
                            "task_id": task_id,
                            "message": color_ok("Solved with Onyx")
                        }
                    else:
                        return error_payload(f"Onyx ready but no solution", provider="Onyx", raw_response=result)
                elif status == "processing":
                    time.sleep(self.poll_interval)
                    continue
                else:
                    return error_payload(f"Onyx Unknown status: {status}", provider="Onyx", raw_response=result)
            except Exception as e:
                return error_payload(f"Onyx Result Error: {str(e)}", provider="Onyx")

    def get_balance(self):
        try:
            with httpx.Client(timeout=10) as client:
                response = client.post(
                    f"{self.base_url}/api/getBalance",
                    json={"clientKey": self.api_key}
                )
            if response.status_code == 200:
                data = response.json()
                if data.get("errorId") == 0:
                    return data
            return error_payload("Onyx balance check failed", provider="Onyx", raw_response=response.text if response else None)
        except Exception as e:
            return error_payload(str(e), provider="Onyx")


def solve(sitekey, siteurl, captcha_details, proxy=None, api_key=None):
    return OnyxSolver(api_key).solve(sitekey, siteurl, captcha_details, proxy)
