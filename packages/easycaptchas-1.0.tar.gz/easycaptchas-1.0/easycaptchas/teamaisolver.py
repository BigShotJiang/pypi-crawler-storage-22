import httpx
from .utils import get_api_key, error_payload, color_ok


class TeamAISolver:
    def __init__(self, api_key=None):
        self.api_key = (api_key or get_api_key("TEAMAI") or "").strip()
        self.base_url = "http://captcha.aiclientz.com:1234"

    def solve(self, sitekey, siteurl, captcha_details, proxy=None):
        if not self.api_key:
            return error_payload("TeamAI API key missing", provider="TeamAI")
            
        payload = {
            "site_key": sitekey,
            "site_url": siteurl,
            "rqd": (captcha_details or {}).get("rqdata") or (captcha_details or {}).get("rqd") or "",
            "proxy": proxy if proxy else "",
            "key": self.api_key
        }
        
        try:
            with httpx.Client(timeout=30) as client:
                response = client.post(
                    f"{self.base_url}/solve_basic",
                    json=payload
                )
            
            if 200 <= response.status_code <= 204:
                data = response.json()
                captcha_key = data.get("captcha") or data.get("captcha_key") or data.get("key")
                
                if captcha_key:
                    return {
                        "success": True,
                        "token": captcha_key,
                        "rqtoken": data.get("rqtoken", ""),
                        "user_agent": "",
                        "message": color_ok("Solved with TeamAI")
                    }
                else:
                    return error_payload(f"No captcha in response", provider="TeamAI", raw_response=data)
            else:
                return error_payload(f"TeamAI HTTP {response.status_code}", provider="TeamAI", raw_response=response.text)
        except Exception as e:
            return error_payload(str(e), provider="TeamAI")

    def check_balance(self):
        try:
            with httpx.Client(timeout=10) as client:
                response = client.post(
                    f"{self.base_url}/check",
                    json={"key": self.api_key}
                )
            
            if response.status_code == 200:
                return response.json()
            return error_payload(f"TeamAI balance check HTTP {response.status_code}", provider="TeamAI", raw_response=response.text if response else None)
        except Exception as e:
            return error_payload(str(e), provider="TeamAI")


def solve(sitekey, siteurl, captcha_details, proxy=None, api_key=None):
    return TeamAISolver(api_key).solve(sitekey, siteurl, captcha_details, proxy)
