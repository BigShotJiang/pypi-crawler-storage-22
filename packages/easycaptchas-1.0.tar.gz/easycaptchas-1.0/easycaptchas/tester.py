from . import onyxsolver, voidsolver, teamaisolver
from .utils import get_api_key, eg, color_ok, color_err, color_warn

def testsolvers():
    print(eg.gradient("--- EasyCaptchas Solver Test ---", ["#00FFFF", "#FF00FF"]))
    
    solvers = [
        ("ONYX", onyxsolver.OnyxSolver, "#00FFFF"),
        ("VOID", voidsolver.VoidSolver, "#FF00FF"),
        ("TEAMAI", teamaisolver.TeamAISolver, "#FFFF00")
    ]

    for name, solver_cls, col in solvers:
        key = get_api_key(name)
        status = f"[{name}Solver] Key found: {key[:10]}..." if key else f"[{name}Solver] No key found"
        print(eg.color("\n" + status, col))
        
        if key:
            try:
                solver = solver_cls(key)
                if name == "ONYX":
                    res = solver.get_balance()
                    if res.get("errorId") == 0:
                        print(color_ok(f"  Success! Balance: ${res.get('balance')}"))
                    else:
                        print(color_err(f"  Failed: {res.get('errorDescription') or res.get('error')}"))
                elif name == "VOID":
                    print(color_ok("  Initialized successfully."))
                elif name == "TEAMAI":
                    res = solver.check_balance()
                    if res and not res.get("success", True):
                        print(color_warn(f"  Balance check returned error: {res.get('error')}"))
                    elif res and res.get("code") == "200":
                        print(color_ok(f"  Success! Credits left: {res.get('credit_left')}"))
                    else:
                        print(color_err(f"  Failed: {res}"))
            except Exception as e:
                print(color_err(f"  Error: {e}"))

    print(eg.gradient("\n--- Test Complete ---", ["#FF00FF", "#00FFFF"]))
