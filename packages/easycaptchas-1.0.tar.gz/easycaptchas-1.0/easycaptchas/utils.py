import os
import json

# Discord Defaults for the lazy ones lol
DISCORD_SITEKEY = "a9b5fb07-92ff-493f-86fe-352a2803b3df"
DISCORD_URL = "https://discord.com"

try:
    import easygradients as eg
except ImportError:
    class eg:
        @staticmethod
        def color(text, hex_val): return text
        @staticmethod
        def gradient(text, colors): return text


def color_ok(text):
    return eg.color(text, "#00FF88")


def color_warn(text):
    return eg.color(text, "#FFCC00")


def color_err(text):
    return eg.color(text, "#FF4D4D")


def error_payload(message, provider=None, detail=None, raw_response=None):
    base = {
        "success": False,
        "error": str(message),
    }
    if provider:
        base["provider"] = provider
    if detail:
        base["detail"] = str(detail)
    if raw_response:
        base["raw_response"] = raw_response
    base["pretty_error"] = color_err(f"[{provider or 'Solver'}] {message}")
    return base

def get_api_key(service):
    service = service.lower()
    env_var = f"{service.upper()}_API_KEY"
    if os.getenv(env_var): return os.getenv(env_var)
    
    if os.path.exists(".env"):
        with open(".env", "r") as f:
            for line in f:
                if line.startswith(env_var):
                    return line.split("=")[1].strip().strip('"').strip("'")

    config_paths = ["config.json", "config.local.json", "config.toml", "config.yaml", "config.yml"]
    for path in config_paths:
        if not os.path.exists(path): continue
        try:
            if path.endswith(".json"):
                with open(path, "r") as f:
                    data = json.load(f)
                    key = data.get(f"{service}_key") or data.get(env_var) or \
                          data.get("captcha_solver", {}).get(f"{service}_key")
                    if key: return key
            elif path.endswith(".toml"):
                import toml
                data = toml.load(path)
                key = data.get(service, {}).get("api_key") or data.get("captcha_solver", {}).get(f"{service}_key")
                if key: return key
            elif path.endswith(".yaml") or path.endswith(".yml"):
                import yaml
                with open(path, "r") as f:
                    data = yaml.safe_load(f)
                    key = data.get("captcha_solver", {}).get(f"{service}_key") or data.get(service, {}).get("api_key")
                    if key: return key
        except: pass
    return None

def print_banner():
    banner = r"""
  ______                      _____            _       _                 
 |  ____|                    / ____|          | |     | |                
 | |__   __ _ ___ _   _     | |     __ _ _ __ | |_ ___| |__   __ _ ___ 
 |  __| / _` / __| | | |    | |    / _` | '_ \| __/ __| '_ \ / _` / __|
 | |___| (_| \__ \ |_| |    | |___| (_| | |_) | || (__| | | | (_| \__ \
 |______\__,_|___/\__, |     \_____\__,_| .__/ \__\___|_| |_|\__,_|___/
                   __/ |                | |                              
                  |___/                 |_|                              
    """
    print(eg.gradient(banner, ["#00FFFF", "#FF00FF"]))
    print(eg.color("  Advanced Solver Engine v1.0", "#00FF00"))
    print()
