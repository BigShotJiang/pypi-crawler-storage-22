import httpx
import time
from .utils import get_api_key, error_payload, color_ok


class VoidSolver:
    def __init__(self, api_key=None, timeout=120, poll_interval=3):
        self.api_key = (api_key or get_api_key("VOID") or "").strip()
        self.base_url = "https://api.voidsolver.tech"
        self.timeout = timeout
        self.poll_interval = poll_interval

    def solve(self, sitekey, siteurl, captcha_details, proxy=None):
        endpoint = f"{self.base_url}/api/createtask"
        payload = {
            "site_url": siteurl,
            "site_key": sitekey,
        }
        
        rqdata = (captcha_details or {}).get("rqdata") or (captcha_details or {}).get("rqd")
        if rqdata:
            payload["rqdata"] = rqdata
        
        if proxy:
            payload["proxy"] = proxy
            
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        try:
            with httpx.Client(timeout=30, follow_redirects=True) as client:
                response = client.post(endpoint, json=payload, headers=headers)
                if response.status_code != 200:
                    if response.status_code == 404:
                        response = client.post(f"{self.base_url}/createtask", json=payload, headers=headers)
                    
                    if response.status_code != 200:
                        return error_payload(f"Void HTTP {response.status_code}", provider="Void", raw_response=response.text)
                
                data = response.json()
                task_id = data.get("taskId")
                if not task_id:
                    return error_payload("No task ID returned by Void", provider="Void", raw_response=data)
                    
                return self.get_task_result(task_id)
        except Exception as e:
            return error_payload(str(e), provider="Void")

    def get_task_result(self, task_id):
        endpoint = f"{self.base_url}/api/gettaskresult"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json"
        }
        
        start_time = time.time()
        while True:
            if time.time() - start_time > self.timeout:
                return error_payload("Void Timeout", provider="Void")
            
            try:
                with httpx.Client(timeout=30, follow_redirects=True) as client:
                    response = client.get(f"{endpoint}?taskid={task_id}", headers=headers)
                    if response.status_code == 404:
                         response = client.get(f"{self.base_url}/gettaskresult?taskid={task_id}", headers=headers)
                    
                    if response.status_code != 200:
                        return error_payload(f"Void HTTP {response.status_code}", provider="Void", raw_response=response.text)
                        
                    result = response.json()
                    status = result.get("status", "")
                    
                    if status == "success":
                        return {
                            "success": True,
                            "token": result.get("solvedToken"),
                            "rqtoken": "",
                            "user_agent": "",
                            "task_id": task_id,
                            "message": color_ok("Solved with Void")
                        }
                    elif status in ["processing", "pending", "solving"]:
                        time.sleep(self.poll_interval)
                        continue
                    elif status == "failed":
                        return error_payload(result.get("error") or "Void solve failed", provider="Void", raw_response=result)
                    else:
                        return error_payload(f"Void Unknown status: {status}", provider="Void", raw_response=result)
            except Exception as e:
                return error_payload(str(e), provider="Void")

    def get_balance(self):
        try:
            with httpx.Client(timeout=10, follow_redirects=True) as client:
                response = client.get(
                    f"{self.base_url}/api/balance",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Accept": "application/json"
                    }
                )
            if response.status_code == 200:
                return response.json()
            return error_payload("Void balance check failed", provider="Void", raw_response=response.text if response else None)
        except Exception as e:
            return error_payload(str(e), provider="Void")


def solve(sitekey, siteurl, captcha_details, proxy=None, api_key=None):
    return VoidSolver(api_key).solve(sitekey, siteurl, captcha_details, proxy)
