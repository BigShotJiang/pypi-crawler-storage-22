from .detrend_spatial import *
from .seasonstat import *
from .monthstat import *
from .yearstat import *
