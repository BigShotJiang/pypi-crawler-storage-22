"""
This module calculates statistical values over timesteps of the same season
"""

from __future__ import annotations
import xarray as xr

__all__ = []
