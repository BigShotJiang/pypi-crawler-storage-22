# src/easyclimate/version.py
__version__ = "2026.2.0"


def show_versions() -> str:
    return __version__
