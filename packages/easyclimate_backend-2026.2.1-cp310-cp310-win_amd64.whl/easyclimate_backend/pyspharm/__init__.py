from .spharm import __doc__
from .spharm import __version__
from .spharm import *
