# easyclimate_backend/version.py
__version__ = "2026.2.1"
