"""Implementation of the regridding methods."""
# Note: this file is only required due to sphinx autoapi
#  https://github.com/readthedocs/sphinx-autoapi/issues/298
