from .detection import MeanAveragePrecision
