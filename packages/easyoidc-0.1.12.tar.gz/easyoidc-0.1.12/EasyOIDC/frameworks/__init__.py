SESSION_STATE_VAR_NAME = 'easyoidc-session-state'
REFERRER_VAR_NAME = 'easyoidc-referrer_path'