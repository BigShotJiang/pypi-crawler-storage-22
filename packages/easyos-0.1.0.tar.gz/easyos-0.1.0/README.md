---

<img src="easyos.webp" width="120" align="center">

> **Simple. Powerful. Pythonic.**
> High-level OS, Process, Disk, System & Network utilities built on top of Python standard libraries.

---

## 🔥 About EasyOS

**EasyOS** is a lightweight Python library that simplifies working with:

* 🧠 Processes
* 💾 Disk & FileSystem
* 🖥 System information
* 🌐 Network utilities

It wraps complex low-level operations into clean, reusable, and developer-friendly methods.

Instead of fighting with `os`, `shutil`, `subprocess`, `psutil`, and other low-level tools — you use **EasyOS**.

---

## 🚀 Why EasyOS?

Because working with system-level Python APIs often feels:

* Verbose
* Inconsistent
* Hard to reuse
* Overcomplicated for common tasks

EasyOS fixes that.

You get:

* Clean abstractions
* Clear error handling
* Reusable static methods
* Consistent API
* Production-ready logic

---

# 📦 Installation

```bash
pip install easyos
```

Or clone manually:

```bash
git clone https://github.com/justKirwl/Easy-Os-Python.git
```

---

# 🧠 Modules Overview

---

## 🟢 Process

Manage system processes easily.

### Features

* `Process.wait(pid, timeout)`
* `Process.is_running(pid)`
* `Process.safe_kill(pid, timeout)`
* `Process.restart(pid)`
* `run_in_multipool()`
* `multi_kill_or_terminate()`

### Example

```python
from easyos import Process

if Process.is_running(1234):
    Process.safe_kill(1234, timeout=3)
```

---

## 💾 Disk

Simplified filesystem operations.

### Features

* `Disk.move(src, dst, overwrite=False)`
* `Disk.size(path, recursive=True)`
* `Disk.info(path)`
* (and more…)

### Example

```python
from easyos import Disk

size = Disk.size("my_folder")
print(f"Folder size: {size} bytes")
```

---

## 🖥 System

Access system information easily.

### Example Capabilities

* CPU info
* Memory usage
* Platform details
* Environment access

```python
from easyos import System

print(System.user())
```

---

## 🌐 Network

Work with network information and utilities.

### Example Capabilities

* Get local IP
* Network interfaces
* Connectivity checks
* Network statistics

```python
from easyos import Network

print(Network.ip())
```

---

# 🎯 Philosophy

EasyOS follows three core principles:

1. **Simplicity over complexity**
2. **Abstraction without losing power**
3. **Clean code first**

The goal is not to replace Python's standard library —
but to make it easier and more developer-friendly.

---

# 🛠 Built With

* `os`
* `shutil`
* `subprocess`
* `pathlib`
* `psutil`
* `socket`
* and other standard modules

Wrapped. Simplified. Enhanced.

---

# 📈 Roadmap

* [ ] Async support
* [ ] Better cross-platform handling
* [ ] Extended Network utilities
* [ ] Performance improvements
* [ ] Documentation expansion

---

# 🤝 Contributing

Pull requests are welcome.

If you're a Python developer and want to improve system-level tooling — join the project.

---

# ⚡ Author

Built with passion by a developer who enjoys diving into documentation, reading source code, and turning complex APIs into simple tools.

---

# 🧩 Final Words

EasyOS is not just a wrapper.

It’s a cleaner way to interact with your system in Python.

> Work smart. Automate everything. Build powerful tools.

---