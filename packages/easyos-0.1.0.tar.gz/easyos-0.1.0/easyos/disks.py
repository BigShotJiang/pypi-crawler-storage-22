import shutil
import psutil

from pathlib import Path
import os
import glob

from typing import Union, Any

class Disk:
    """
    The `Disk` class provides utility methods for working with files and directories.
    It includes functionality for checking system paths, verifying permissions,
    copying files or directories, and safely deleting resources.
    """

    SYSTEM_DIRS = ["C:\\windows", "C:\\program files", "/usr", "/bin", "/etc", "/sbin"]

    @staticmethod
    def is_in_system_dir(path: str) -> bool:
        """
        Checks if the given `path` belongs to a system directory.

        Args:
            path (`str`): The file or directory path to check.

        Returns:
            `bool`: `True` if the path is inside a system directory, otherwise `False`.
        """

        if not path:
            raise ValueError("Method 'is_in_system_dir()' from class 'Disk' gave error of given not valid parameter: 'path'")

        path = os.path.abspath(path).lower()

        return any(Path(path).resolve().is_relative_to(Path(d)) for d in Disk.SYSTEM_DIRS)
    
    @staticmethod
    def has_rights(path: str) -> bool:
        """
        Returns:
            `bool`: `True` if the copy operation succeeds.
        Checks if the current user has write and execute permissions
        for the parent directory of the given `path`.

        Args:
            path (`str`): The file or directory path to check.

        Returns:
            `bool`: `True` if permissions are sufficient, otherwise `False`.
        """

        if not path:
            raise ValueError("Method 'has_rights()' from class 'Disk' gave error of given not valid parameter: 'path'")

        if not os.path.exists(path):
            return False
        
        PARENT_DIR = os.path.dirname(os.path.abspath(path))

        return os.access(PARENT_DIR, os.W_OK | os.X_OK)

    @staticmethod
    def copy(src: str, dst: str, overwrite: bool = False) -> None:
        """
        Copies a file or directory from `src` to `dst`.

        Args:
            src (`str`): Source path.
            dst (`str`): Destination path.
            overwrite (`bool`, optional): If `True`, allows overwriting existing files
            or directories. Defaults to `False`.

        Raises:
            `FileNotFoundError`: If the source path does not exist.
            `FileExistsError`: If the destination exists and `overwrite` is `False`.
            `RuntimeError`: If unsupported paths are provided.
        """

        if not src or not dst:
            raise ValueError(f"Method 'copy()' from class 'Disk' gave error of given not valid parameter: {"'src'" if not src else "'dst'"}")

        path_src = Path(src)
        path_dst = Path(dst)

        if not path_src.exists():
            raise FileNotFoundError("Method 'copy()' from class 'Disk' gave error of 'src' parameter path is not exists")
        
        if path_dst.exists():
            if not overwrite:
                raise FileExistsError("Method 'copy()' from class 'Disk' gave error of 'dst' parameter path is exists, while 'overwrite' parameter is False")
            
            Disk.safe_delete(dst)
            
        if path_src.is_file():
            shutil.copy(src, dst)
            
        elif path_src.is_dir():
            # this will copy 'src' directory to 'dst' directory, if 'overwrite' parameter is True,
            # then it will overwrite recursively every directory
            # and file in 'dst' until full copy will be completed
            shutil.copytree(src, dst, copy_function=shutil.copy2)

        else:
            raise RuntimeError("Method 'copy()' from class 'Disk' gave error because given unsupported 'src' and 'dst' parameters")
        
    @staticmethod
    def safe_delete(path: str) -> None:
        """
        Safely deletes a file or directory at the given `path`.

        Args:
            path (`str`): The file or directory path to delete.

        Raises:
            `FileNotFoundError`: If the path does not exist.
            `PermissionError`: If the path is inside a system directory or
            insufficient permissions are detected.
        """

        if not path:
            raise ValueError("Method 'safe_delete()' from class 'Disk' gave error of given not valid parameter: 'path'")

        PATH = Path(path)

        if not PATH.exists():
            raise FileNotFoundError("Method 'safe_delete()' from class 'Disk' gave error of 'path' parameter path is not exists")
        
        if Disk.is_in_system_dir(path) or not Disk.has_rights(path) or PATH.resolve() in (Path('/'), Path('C:\\')):
            raise PermissionError(f"Method 'safe_delete()' from class 'Disk' gave error because not enough permission to delete given path: {path}")
        
        os.remove(path) if PATH.is_file() else shutil.rmtree(path)

    @staticmethod
    def exists(path: str, follow_symlinks: bool = True) -> bool:
        """
        Checks if the given `path` exists in the filesystem.

        Args:
            path (`str`): The file or directory path to check.
            follow_symlinks (`bool`, optional): If `True`, follows symbolic links.
            Defaults to `True`.

        Returns:
            `bool`: `True` if the path exists, otherwise `False`.

        Raises:
            `ValueError`: If `path` is not provided.
        """

        if not path:
            raise ValueError("Method 'exists()' from class 'Disk' gave error of given not valid parameter: 'path'")
        
        PATH = Path(path)

        return PATH.exists(follow_symlinks=follow_symlinks)
    
    @staticmethod
    def is_dir(path: str, follow_symlinks: bool = True) -> bool:
        """
        Checks if the given `path` is a directory.

        Args:
            path (`str`): The path to check.
            follow_symlinks (`bool`, optional): If `True`, follows symbolic links.
            Defaults to `True`.

        Returns:
            `bool`: `True` if the path is a directory, otherwise `False`.

        Raises:
            `ValueError`: If `path` is not provided.
        """

        if not path:
            raise ValueError("Method 'is_dir()' from class 'Disk' gave error of given not valid parameter: 'path'")

        PATH = Path(path)

        return PATH.is_dir(follow_symlinks=follow_symlinks)
    
    @staticmethod
    def is_file(path: str, follow_symlinks: bool = True) -> bool:
        """
        Checks if the given `path` is a file.

        Args:
            path (`str`): The path to check.
            follow_symlinks (`bool`, optional): If `True`, follows symbolic links.
            Defaults to `True`.

        Returns:
            `bool`: `True` if the path is a file, otherwise `False`.

        Raises:
            `ValueError`: If `path` is not provided.
        """

        if not path:
            raise ValueError("Method 'is_file()' from class 'Disk' gave error of given not valid parameter: 'path'")

        PATH = Path(path)

        return PATH.is_file(follow_symlinks=follow_symlinks)
    
    @staticmethod
    def find(pattern: str, root: str, recursive: bool = True, include_hidden: bool = False) -> list[str]:
        """
        Finds files or directories under the given `root` path that match a `pattern`.

        Args:
            pattern (`str`): The search pattern (e.g., `"*.txt"`).
            root (`str`): The root directory to search in.
            recursive (`bool`, optional): If `True`, searches recursively. Defaults to `True`.
            include_hidden (`bool`, optional): If `True`, includes hidden files. Defaults to `False`.

        Returns:
            `list[str]`: A list of absolute paths matching the pattern.

        Raises:
            `ValueError`: If `pattern` or `root` is not provided.
        """

        if not pattern or not root:
            raise ValueError(f"Method 'find()' from class 'Disk' gave error of given not valid parameters: {"'pattern'" if not pattern else "'root'"}")
        
        if recursive and not pattern.startswith('**/'):
            pattern = os.path.join('**', pattern)

        found_paths = glob.glob(pathname=os.path.join(root, pattern), recursive=recursive, include_hidden=include_hidden)

        safe_results = []
        for path in found_paths:
            abs_path = os.path.abspath(path)

            if os.path.commonpath([root]) == os.path.commonpath([root, abs_path]):

                if os.access(abs_path, os.R_OK):
                    safe_results.append(abs_path)

        return safe_results
    
    @staticmethod
    def read_file(path: str, encoding: str = 'utf-8', binary_mode: bool = False) -> Union[Any, bytes]:
        """
        Reads the contents of a file.

        Args:
            path (`str`): The file path to read.
            encoding (`str`, optional): Text encoding used when reading in text mode.
            Defaults to `'utf-8'`.
            binary_mode (`bool`, optional): If `True`, reads the file in binary mode.
            Defaults to `False`.

        Returns:
            `Any | bytes`: File contents as `str` in text mode or `bytes` in binary mode.

        Raises:
            `FileNotFoundError`: If the file does not exist.
            `RuntimeError`: If decoding fails with the given `encoding`.
        """

        PATH = Path(path)

        if not PATH.exists():
            raise FileNotFoundError("Method 'read_file()' from class 'Disk' gave error of 'path' parameter path is not exists")

        try:
            with open(path, mode='rb') if binary_mode else open(path, mode='r', encoding=encoding) as f:
                data = f.read()
        except UnicodeDecodeError:
            raise RuntimeError("Method 'read_file()' from class 'Disk' gave error because type of decoding that was given into 'encoding' parameter couldn't be decoded")

        return data
    
    @staticmethod
    def write_file(path: str, data: Union[str, bytes], encoding: str = 'utf-8', overwrite: bool = False) -> None:
        """
        Writes data to a file. Creates parent directories if they do not exist.

        Args:
            path (`str`): The file path to write to.
            data (`Union[str, bytes]`): The content to write.
            encoding (`str`, optional): Text encoding used when writing in text mode.
            Defaults to `'utf-8'`.
            overwrite (`bool`, optional): If `True`, overwrites the file. If `False`,
            appends to the file. Defaults to `False`.

        Raises:
            `PermissionError`: If insufficient permissions exist for the path.
            `RuntimeError`: If encoding fails with the given `encoding`.
        """

        PATH = Path(path)

        PARENT_DIR = PATH.parent

        if not PATH.exists():
            PARENT_DIR.mkdir(parents=True, exist_ok=True)

        if PATH.exists() and not Disk.has_rights(path):
            raise PermissionError(f"Method 'write_file()' from class 'Disk' gave error because not enough permission to change given path: {path}")

        mode = ''

        if overwrite:
            mode = mode + 'w'
        else:
            mode = mode + 'a'

        if isinstance(data, bytes):
            mode = mode + 'b'
        
        try:
            with open(path, mode=mode) if isinstance(data, bytes) else open(path, mode=mode, encoding=encoding) as f:
                f.write(data)
        except UnicodeEncodeError:
            raise RuntimeError("Method 'read_file()' from class 'Disk' gave error because type of decoding that was given into 'encoding' parameter couldn't be encoded")
    
    @staticmethod
    def disk_partitions(all: bool = False) -> list[dict[str, str]]:
        """
        Retrieves information about mounted disk partitions.

        Args:
            all (`bool`, optional): If `True`, returns all partitions including
            those without a mount point. Defaults to `False`.

        Returns:
            `list[dict[str, str]]`: A list of dictionaries containing details
            about each partition (`device`, `mountpoint`, `fstype`, `opts`).
        """
        
        return [{'device': p.device, 'mountpoint': p.mountpoint, 'fstype': p.fstype, 'opts': p.opts} for p in psutil.disk_partitions(all=all)]
    
    @staticmethod
    def disk_usage(path: str) -> dict[str, Any]:
        """
        Retrieves disk usage statistics for the given `path`.

        Args:
            path (`str`): The file system path to check.

        Returns:
        
            `dict[str, Any]`: A dictionary containing usage statistics such as
            `total`, `used`, `free`, and `percent`.

        Raises:
            `FileNotFoundError`: If the given `path` does not exist.
        """

        try:
            USAGE = psutil.disk_usage(path)
        except OSError:
            raise FileNotFoundError("Method 'disk_usage()' from class 'Disk' gave error of 'path' parameter path is not exists")
        
        return {usage_type: value for usage_type, value in USAGE._asdict().items() if not usage_type.startswith('_')}
    
    @staticmethod
    def move(src: str, dst: str, overwrite: bool = False) -> None:
        """
        Moves a file or directory from `src` to `dst`.

        Args:
            src (`str`): Source path.
            dst (`str`): Destination path.
            overwrite (`bool`, optional): If `True`, creates parent directories
            for `dst` if they do not exist. Defaults to `False`.

        Raises:
            `FileNotFoundError`: If the source path does not exist.
            `FileNotFoundError`: If the destination path does not exist and `overwrite` is `False`.
        """

        path_src = Path(src)
        path_dst = Path(dst)

        if not path_src.exists():
            raise FileNotFoundError("Method 'move()' from class 'Disk' gave error of 'src' parameter path is not exists")
        
        if not path_dst.exists():
            if not overwrite:
                raise FileNotFoundError("Method 'move()' from class 'Disk' gave error of 'dst' parameter path is not exists")

            path_dst.parent.mkdir(parents=True, exist_ok=True)

        if path_dst.exists() and overwrite:
            Disk.safe_delete(dst)

        shutil.move(src, dst, copy_function=shutil.copy2)

    @staticmethod
    def size(path: str, recursive: bool = True) -> int:
        """
        Calculates the size of a file or directory.

        Args:
            path (`str`): The file or directory path.
            recursive (`bool`, optional): If `True`, calculates the size of all
            files within the directory recursively. Defaults to `True`.

        Returns:
            `int`: The total size in bytes.

        Raises:
            `FileNotFoundError`: If the given path does not exist.
        """

        PATH = Path(path)

        if not PATH.exists():
            raise FileNotFoundError("Method 'size()' from class 'Disk' gave error of 'path' parameter path is not exists")

        total_size = 0

        if os.path.isfile(path) or not recursive:
            return os.path.getsize(path)
        
        for dirpath, _, filenames in os.walk(path):
            for f in filenames:
                fp = os.path.join(dirpath, f)

                if not os.path.islink(fp):
                    total_size += os.path.getsize(fp)
        
        return total_size
    
    @staticmethod
    def info(path: str) -> dict[str, Any]:
        """
        Retrieves detailed filesystem information about the given `path`.

        Args:
            path (`str`): The file or directory path to inspect.

        Returns:

            `dict[str, Any]`: A dictionary containing metadata attributes from
            `os.stat()` such as `st_size`, `st_mode`, `st_uid`, `st_gid`,
            `st_atime`, `st_mtime`, and `st_ctime`.

        Raises:
            `FileNotFoundError`: If the given `path` does not exist.
        """

        PATH = Path(path)

        if not PATH.exists():
            raise FileNotFoundError("Method 'info()' from class 'Disk' gave error of 'path' parameter path is not exists")
        
        STAT_INFO = PATH.stat()

        return {k: getattr(STAT_INFO, k) for k in dir(STAT_INFO) if k.startswith('st_')}