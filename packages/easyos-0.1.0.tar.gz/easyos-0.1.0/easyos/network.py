import psutil
import subprocess

import socket
import requests

from dns import resolver
from dns.nameserver import Nameserver

import os

from typing import Any, Sequence

class Network:
    """
    The `Network` class provides utility methods for retrieving network-related
    information such as interfaces, MAC addresses, DNS servers, IP addresses,
    connections, and performing basic reachability checks.
    """

    @staticmethod
    def net_io_counters(pernic: bool = True, nowrap: bool = True) -> dict[str, dict[str, Any]]:
        """
        Retrieves network I/O statistics.

        Args:
            pernic (`bool`, optional): If `True`, returns stats per network interface.
            Defaults to `True`.
            nowrap (`bool`, optional): If `True`, prevents values from wrapping around.
            Defaults to `True`.

        Returns:
            `dict[str, dict[str, Any]]`: A dictionary mapping interface names to
            their I/O counters (bytes sent/received, packets sent/received, errors, drops).
        """

        return {NET_TYPE: SNETIO._asdict() for NET_TYPE, SNETIO in psutil.net_io_counters(pernic, nowrap).items()}
    
    @staticmethod
    def interfaces() -> dict[str, list[dict[str, Any]]]:
        """
        Retrieves network interface addresses.

        **Returning**:
            `dict[str, list[dict[str, Any]]]`: A dictionary mapping interface names
            to a list of address details (IP, family, netmask, broadcast).
        """

        return {ADDR_TYPE: [S._asdict() for S in SNICADDR] for ADDR_TYPE, SNICADDR in psutil.net_if_addrs().items()}
    
    @staticmethod
    def interfaces_state() -> dict[str, dict[str, Any]]:
        """
        Retrieves network interface states.

        **Returning**:
            `dict[str, dict[str, Any]]`: A dictionary mapping interface names to
            their state details (isup, duplex, speed, mtu).
        """

        return {NIC_TYPE: SNICSTATS._asdict() for NIC_TYPE, SNICSTATS in psutil.net_if_stats().items()}

    @staticmethod
    def ip(public: bool = False) -> str:
        """
        Retrieves the local or public IP address.

        Args:
            public (`bool`, optional): If `True`, returns the public IP address.
            If `False`, returns the local IP. Defaults to `False`.

        Returns:
            `str`: The IP address.
        """

        if not public:
            HOSTNAME = socket.gethostname()
            LOCAL_IP = socket.gethostbyname(HOSTNAME)

            return LOCAL_IP
        
        PUBLIC_IP = requests.get('https://api.ipify.org').text

        return PUBLIC_IP
    
    @staticmethod
    def interfaces_mac() -> dict[str, list[str]]:
        """
        Retrieves MAC addresses of network interfaces.

        **Returning**:
            `dict[str, list[str]]`: A dictionary mapping interface names to
            their MAC addresses.
        """

        mac_addresses = {}

        for ADDR_TYPE, SNICSTATS in Network.interfaces().items():
            for SNICSTAT in SNICSTATS:

                if SNICSTAT.get('family') == psutil.AF_LINK:
                    if not ADDR_TYPE in mac_addresses:
                        mac_addresses[ADDR_TYPE] = []
                    
                    mac_addresses[ADDR_TYPE].append(SNICSTAT.get('address'))
        
        return mac_addresses
    
    @staticmethod
    def dns() -> Sequence[str | Nameserver]:
        """
        Retrieves configured DNS nameservers.

        **Returning**:
            `Sequence[str | Nameserver]`: A list of DNS server addresses.
        """
        
        return resolver.Resolver().nameservers
    
    @staticmethod
    def ping(target: str = '127.0.0.1') -> dict[str, float]:
        """
        Sends a single ping request to the target host.

        Args:
            target (`str`, optional): The target IP or hostname. Defaults to `'127.0.0.1'`.

        **Returning**:
            `dict[str, float]`: A dictionary containing ping statistics such as
            `bytes_sent`, `bytes_received`, `time_ms`, `packets_transmitted`,
            `packets_received`, and `packet_loss_percent`.
        """

        PING = subprocess.run(['ping', target, '-n 1' if os.name == 'nt' else '-c 1'], capture_output=True, text=True)

        stdout = PING.stdout

        RESULT = {
            'bytes_sent': stdout.splitlines()[0].split()[3].split('(')[0],
            'bytes_received': stdout.splitlines()[1].split()[0],
            'time_ms': stdout.splitlines()[1].split()[6].split('=')[1],
            'packets_transmitted': stdout.splitlines()[4].split()[0],
            'packets_received': stdout.splitlines()[4].split()[3],
            'packet_loss_percent': stdout.splitlines()[4].split()[5].split('%')[0]
        }

        return {RESULT_TYPE: float(RESULT_VALUE) for RESULT_TYPE, RESULT_VALUE in RESULT.items()}
    
    @staticmethod
    def is_reachable(target: str = '127.0.0.1') -> bool:
        """
        Checks if the target host is reachable via ping.

        Args:
            target (`str`, optional): The target IP or hostname. Defaults to `'127.0.0.1'`.

        Returns:
            `bool`: `True` if the target responds to ping, otherwise `False`.
        """

        return isinstance(Network.ping(target), dict)
    
    @staticmethod
    def connections() -> list[dict[str, Any]]:
        """
        Retrieves active network connections.

        **Returning**:
            `list[dict[str, Any]]`: A list of dictionaries containing connection details
            such as `PID`, `status`, `local`, and `remote` addresses.
        """
        
        CONNECTIONS = psutil.net_connections('all')

        return [{'PID': conn.pid, 'status': conn.status, 'local': conn.laddr, 'remote': conn.raddr} for conn in CONNECTIONS]