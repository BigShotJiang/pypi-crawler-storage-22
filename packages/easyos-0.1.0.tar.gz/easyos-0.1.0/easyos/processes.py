import psutil
import multiprocessing
import subprocess

from multiprocessing.pool import AsyncResult

import inspect

import time

from typing import Callable, Any, Union
from typing_extensions import deprecated

class Process:
    """
    The Process class is designed to simplify working with system processes.
    It provides convenient methods to retrieve information about currently
    running processes in the operating system.
    """

    @staticmethod
    def list_processes(data_structure: list[str] | None = None) -> list[dict[str, str | int]]:
        """
        Returns a list of active processes.

        Args:
            data_structure (`list[str]`): A list of keys specifying which
            attributes to retrieve for each process (e.g., `['pid', 'name', 'username']`).

        Returns:
            `list[dict[str, str | int]]`: A list of dictionaries containing
            process information.
        """

        if not data_structure:
            data_structure = ['pid', 'name']

        return [p.info for p in psutil.process_iter(data_structure)]
    
    @staticmethod
    def run_in_process(callback: Callable[..., Any], func_arguments: list[Any] = None, wait_to_finish: bool = True, timeout_to_wait: float = 5) -> Union[Any, tuple[multiprocessing.Process, multiprocessing.Queue]]:
        """
        Executes a given `callback` function inside a separate `multiprocessing.Process`.

        Args:
            callback (`Callable[..., Any]`): The function to be executed in a new process.
            func_arguments (`list[Any]`, optional): Arguments passed to the `callback`.
            wait_to_finish (`bool`, optional): If `True`, waits until the process finishes
            and returns the result. Defaults to `True`.
            timeout_to_wait (`float | None`, optional): Maximum time to wait for the process
            to finish. If `None`, waits indefinitely. Defaults to 5.

        Returns:
            - If `wait_to_finish` is `True`: returns the result of the `callback` (`Any`).
            - If `wait_to_finish` is `False`: returns a tuple (`multiprocessing.Process`, `multiprocessing.Queue`)
            so the caller can manage the process and retrieve results manually.

        Raises:
            `TypeError`: If `callback` is not provided or if arguments do not match the function signature.
        """

        if not callback:
            raise TypeError("Method 'run_in_process()' from class 'Process' missing 1 required positional argument: 'callback'")
        
        if timeout_to_wait <= 0:
            raise ValueError("Method 'run_in_process()' from class 'Process' gave error of given parameter 'timeout_to_wait' must be at least 1")

        sig = inspect.signature(callback)

        if func_arguments is None:
            func_arguments = []

        try:
            sig.bind(*func_arguments)
        except TypeError as e:
            raise TypeError(f"Method 'run_in_process()' from class 'Process' raised error: {e}")
        
        result_queue = multiprocessing.Queue()

        def wrapper(*args):
            try:
                result_queue.put((True, callback(*args)))
            except Exception as e:
                result_queue.put((False, repr(e)))

        p = multiprocessing.Process(target=wrapper, args=func_arguments)
        p.start()

        if wait_to_finish:
            p.join(timeout_to_wait)

            if p.is_alive():
                raise TimeoutError("Method 'run_in_process()' from class 'Process' exceeded given timeout and gave error")
            
            status, data = result_queue.get()

            if not status:
                raise RuntimeError(f"Method 'run_in_process()' from class 'Process' gave function callback error: {data}")
            
            if not result_queue.empty():
                raise RuntimeError("Method 'run_in_process()' from class 'Process' callback process finished but gave no result")
            
            return data
        
        return p, result_queue
    
    @staticmethod
    @deprecated("This method is deprecated, use 'run_in_multipool' instead.")
    def run_in_pool(callback: Callable[..., Any], func_arguments: list[Any] = None, wait_for_result: bool = True, timeout_to_wait: float = 5) -> Union[Any, AsyncResult]:
        """
        Executes a given `callback` function inside a `multiprocessing.Pool`.

        Args:
            callback (`Callable[..., Any]`): The function to be executed in the pool.
            func_arguments (`list[Any]`, optional): Arguments passed to the `callback`.
            wait_for_result (`bool`, optional): If `True`, waits until the function finishes
            and returns the result. Defaults to `True`.
            timeout_to_wait (`float | None`, optional): Maximum time to wait for the result.
            If `None`, waits indefinitely. Defaults to `5`.

        Returns:
            - If `wait_for_result` is `True`: returns the result of the `callback` (`Any`).
            - If `wait_for_result` is `False`: returns an `AsyncResult` object for manual
            result handling.

        Raises:
            `TypeError`: If arguments do not match the function signature.
        """
        
        sig = inspect.signature(callback)

        if func_arguments is None:
            func_arguments = []

        if timeout_to_wait <= 0:
            raise ValueError("Method 'run_in_pool()' from class 'Process' gave error of given parameter 'timeout_to_wait' must be at least 1")

        try:
            sig.bind(*func_arguments)
        except TypeError as e:
            raise TypeError(f"Method 'run_in_pool()' from class 'Process' raised error: {e}")

        with multiprocessing.Pool(processes=1) as pool:
            res = pool.apply_async(callback, args=func_arguments)

            if wait_for_result:
                try:
                    result = res.get(timeout_to_wait)
                except TimeoutError:
                    raise TimeoutError("Method 'run_in_pool()' from class 'Process' exceeded given timeout of callback and gave error")
                
                return result
            
            return res
        
    @staticmethod
    def run_in_multipool(callbacks: tuple[tuple[Callable[..., Any], tuple[Any, ...]], ...], workers: int = 4, wait_for_result: bool = True, timeout_to_wait: float = 5) -> Union[list[Any], list[AsyncResult]]:
        """
        Executes multiple `callback` functions concurrently using a `multiprocessing.Pool`.

        Args:
            callbacks (`tuple[tuple[Callable[..., Any], tuple]]`): A tuple of pairs,
            where each pair consists of a `callback` function and its `tuple` of arguments.
            workers (`int`, optional): Number of worker processes in the pool. Defaults to `4`.
            wait_for_result (`bool`, optional): If `True`, waits until all functions finish
            and returns their results. Defaults to `True`.
            timeout_to_wait (`float | None`, optional): Maximum time to wait for each result.
            If `None`, waits indefinitely. Defaults to `5`.

        Returns:
            - If `wait_for_result` is `True`: returns a `list[Any]` containing results of all callbacks.
            - If `wait_for_result` is `False`: returns a `list[AsyncResult]` objects for manual
            result handling.

        Raises:
            `TimeoutError`: If any of the callbacks exceed the given timeout.
        """

        if not callbacks:
            raise ValueError(f"Method 'run_in_multipool()' from class 'Process' gave error for not providing valid data for parameter 'callbacks'")
        
        if timeout_to_wait <= 0:
            raise ValueError("Method 'run_in_multipool()' from class 'Process' gave error of given parameter 'timeout_to_wait' must be at least 1")
        
        for callback in callbacks:
            sig = inspect.signature(callback[0])

            if len(list(sig.parameters.keys())) > 0:
                try:
                    sig.bind(*callback[1])
                except TypeError as e:
                    raise TypeError(f"Method 'run_in_multipool()' from class 'Process' raised error: {e}")

        with multiprocessing.Pool(processes=workers) as pool:
            multiple_results = [pool.apply_async(callback[0], args=callback[1] if len(callback) >= 2 else ()) for callback in callbacks]

            if wait_for_result:
                results = []

                try:
                    for result in multiple_results:
                        results.append(result.get(timeout=timeout_to_wait))
                except TimeoutError as e:
                    raise TimeoutError(f"Method 'run_in_multipool()' from class 'Process' exceeded given timeout of one of the callbacks: {e}")
                except RuntimeError as e:
                    raise RuntimeError(f"Method 'run_in_multipool()' from class 'Process' gave error with one of callback: {e}")

                return results
            
            return multiple_results
        
    @staticmethod
    def multi_kill_or_terminate(procs: tuple[Union[multiprocessing.Process, int]], kill: bool = False) -> None:
        """
        Terminates or kills multiple processes provided either as `multiprocessing.Process`
        objects or as process IDs (`int`).

        Args:
            procs (`tuple[Union[multiprocessing.Process, int]]`): A tuple containing
            either `multiprocessing.Process` instances or process IDs (`int`) to be
            terminated or killed.
            kill (`bool`, optional): If `True`, processes are forcefully killed using
            `kill()`. If `False`, processes are gracefully terminated using `terminate()`.
            Defaults to `False`.

        Raises:
            `ValueError`: If no valid `procs` are provided.
            `Exception`: If retrieving a process by PID fails unexpectedly.
        """

        if not procs:
            raise ValueError(f"Method 'multi_kill_or_terminate()' from class 'Process' gave error for not providing valid data for parameter 'procs'")
        
        for proc in procs:
            if isinstance(proc, multiprocessing.Process):
                proc.kill() if kill else proc.terminate()
            
            elif isinstance(proc, int):
                try:
                    process = psutil.Process(proc)
                except Exception as e:
                    raise Exception(f"Method 'multi_kill_or_terminate()' from class 'Process' gave unexpected error with getting process {proc} pid: {e}")

                process.kill() if kill else process.terminate()

    @staticmethod
    def get_proc_by_name(name: str | None = None) -> Union[dict[str, str | int], str]:
        """
        Retrieves process information by its `name`.

        Args:
            name (`str | None`, optional): The name of the process to search for.
            Must not be `None`.

        Returns:
            - If a process with the given `name` is found: returns a `dict[str, str | int]`
            containing process details (`pid`, `name`, `username`).
            - If no process is found: returns the provided `name` (`str`).

        Raises:
            `ValueError`: If `name` is not provided.
        """

        if not name:
            raise ValueError(f"Method 'get_proc_by_name()' from class 'Process' gave error for not providing valid data for parameter 'name'")
        
        for proc in Process.list_processes(['pid', 'name', 'username']):
            if proc['name'] == name:
                return proc
        
        return name
    
    @staticmethod
    def get_proc_by_pid(pid: int | None = None) -> Union[dict[str, str | int], int]:
        """
        Retrieves process information by its `pid`.

        Args:
            pid (`int | None`, optional): The process ID to search for.
            Must not be `None`.

        Returns:
            - If a process with the given `pid` is found: returns a `dict[str, str | int]`
            containing process details (`pid`, `name`, `username`).
            - If no process is found: returns the provided `pid` (`int`).

        Raises:
            `ValueError`: If `pid` is not provided.
        """

        if not pid:
            raise ValueError(f"Method 'get_proc_by_pid()' from class 'Process' gave error for not providing valid data for parameter 'pid'")
        
        for proc in Process.list_processes(['pid', 'name', 'username']):
            if proc['pid'] == pid:
                return proc
        
        return pid
    
    @staticmethod
    def is_running(pid: int | None = None) -> bool:
        """
        Checks if a process with the given `pid` is currently running.

        Args:
            pid (`int | None`, optional): The process ID to check. Must not be `None`.

        Returns:
            `bool`: `True` if the process is running, `False` if it does not exist.
        """

        if pid is None:
            raise ValueError(f"Method 'is_running()' from class 'Process' gave error for not providing valid data for parameter 'pid'")

        try:
            proc = psutil.Process(pid)

            return proc.is_running()
        except psutil.NoSuchProcess:
            return False
        
    @staticmethod
    def wait(pid: int | None = None, timeout_to_wait: float = 5) -> bool:
        """
        Waits for a process with the given `pid` to terminate within the specified timeout.

        Args:
            pid (`int | None`, optional): The process ID to wait for. Must not be `None`.
            timeout_to_wait (`int`, optional): Maximum time in seconds to wait for termination.
            Defaults to `5`.

        Returns:
            `bool`: `True` if the process terminated within the timeout, `False` otherwise.

        Raises:
            `RuntimeError`: If the process with the given `pid` does not exist.
        """

        if pid is None:
            raise ValueError(f"Method 'wait()' from class 'Process' gave error for not providing valid data for parameter 'pid'")
        
        if timeout_to_wait <= 0:
            raise ValueError("Method 'wait()' from class 'Process' gave error of given parameter 'timeout_to_wait' must be at least 1")
        
        start_time = time.monotonic()

        while Process.is_running(pid):
            if (time.monotonic() - start_time) > timeout_to_wait:
                return False
            
            time.sleep(0.1)

        return True
    
    @staticmethod
    def safe_kill(proc: Union[psutil.Process, multiprocessing.Process, int, None] = None, timeout_to_wait: float = 5) -> bool:
        """
        Safely terminates or kills a process. Attempts graceful termination first,
        then forcefully kills the process if it does not exit within the timeout.

        Args:
            proc (`Union[psutil.Process, multiprocessing.Process, int, None]`, optional):
            The process to terminate or kill. Can be a `psutil.Process` object,
            a `multiprocessing.Process` object, or a process ID (`int`). Must not be `None`.
            timeout_to_wait (`int`, optional): Maximum time in seconds to wait for termination
            before attempting to kill. Defaults to `5`.

        Returns:
            `bool`: `True` if the process was successfully terminated or killed.

        Raises:
            `ValueError`: If no valid `proc` is provided.
            `RuntimeError`: If the process cannot be found or could not be killed.
        """

        if proc is None:
            raise ValueError(f"Method 'safe_kill()' from class 'Process' gave error for not providing valid data for parameter 'proc'")
        
        if timeout_to_wait <= 0:
            raise ValueError("Method 'safe_kill()' from class 'Process' gave error of given parameter 'timeout_to_wait' must be at least 1")
        
        if isinstance(proc, int):
            try:
                p = psutil.Process(proc)
            except psutil.NoSuchProcess:
                raise RuntimeError(f"Method 'safe_kill()' from class 'Process' can't find such process with given '{proc}' pid")
            
            p.terminate()
            terminated = Process.wait(p.pid, timeout_to_wait)

            if not terminated:
                p.kill()
                terminated = Process.wait(p.pid)

                if not terminated:
                    raise RuntimeError(f"Method 'safe_kill()' from class 'Process' couldn't kill the process with '{proc}' pid")
                
        elif isinstance(proc, (psutil.Process, multiprocessing.Process)):
            proc.terminate()
            terminated = Process.wait(proc.pid, timeout_to_wait)

            if not terminated:
                proc.kill()
                terminated = Process.wait(proc.pid)

                if not terminated:
                    raise RuntimeError(f"Method 'safe_kill()' from class 'Process' couldn't kill the process with '{proc.pid}' pid")
                
        return True
    
    @staticmethod
    def restart_process(proc: Union[psutil.Process, int, None] = None, timeout_to_wait: float = 5, fallback: bool = False) -> Union[bool, int]:
        """
        Restarts a given process by terminating it and starting a new instance
        with the same command-line arguments, environment, and working directory.

        Args:
            proc (`Union[psutil.Process, int, None]`, optional): The process to restart.
            Can be a `psutil.Process` object or a process ID (`int`). Must not be `None`.
            timeout_to_wait (`float`, optional): Maximum time in seconds to wait for termination
            before attempting to kill. Must be greater than `0`. Defaults to `5`.
            fallback (`bool`, optional): If `True`, raises exceptions when restart fails.
            If `False`, returns `False` instead. Defaults to `False`.

        Returns:
            - If restart succeeds: returns the new process ID (`int`).
            - If restart fails and `fallback` is `False`: returns `False`.
            - If restart fails and `fallback` is `True`: raises an exception.

        Raises:
            `ValueError`: If no valid `proc` is provided or if `timeout_to_wait` is less than `1`.
            `RuntimeError`: If the process cannot be found or restarted when `fallback` is `True`.
            `Exception`: If retrieving process details (`cmdline`, `environ`, `cwd`) fails and `fallback` is `True`.
        """

        if proc is None:
            raise ValueError(f"Method 'restart_process()' from class 'Process' gave error for not providing valid data for parameter 'proc'")
        
        if timeout_to_wait <= 0:
            raise ValueError("Method 'restart_process()' from class 'Process' gave error of given parameter 'timeout_to_wait' must be at least 1")
        
        try:
            p = psutil.Process(proc) if isinstance(proc, int) else proc
        except psutil.NoSuchProcess:
            if fallback:
                raise RuntimeError(f"Method 'restart_process()' from class 'Process' can't find such process with given '{proc}' pid")
            
            return False
        
        try:
            PROC_ARGS = p.cmdline()
            PROC_ENVIRON = p.environ()
            PROC_PATH = p.cwd()
        except Exception as e:
            if fallback:
                raise e
            
            return False
        
        Process.safe_kill(p, timeout_to_wait)

        process = subprocess.Popen(PROC_ARGS, env=PROC_ENVIRON, cwd=PROC_PATH, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True, start_new_session=True)

        return process.pid