import platform
import os
import psutil
import getpass

import subprocess
import shlex

import re

from typing import Any

class System:
    """
    The `System` class provides utility methods for retrieving system,
    user, and environment information, as well as managing environment variables.
    """

    @staticmethod
    def info(raw_data: bool = False) -> dict[str, Any]:
        """
        Retrieves system information including OS, CPU, memory, and disk usage.

        Args:
            raw_data (`bool`, optional): If `True`, returns raw numeric values
            for memory statistics. If `False`, returns human-readable values
            (e.g., in GB). Defaults to `False`.

        Returns:
            `dict[str, Any]`: A dictionary containing system details such as
            `system`, `release`, `machine`, `processor`, `architecture`,
            `cpu_cores`, `cpu_utilization`, `total_memory`, `free_memory`,
            `used_memory`, and `disk_usage`.
        """

        SYSTEM_INFO = {
            'system': platform.system(),
            'release': platform.release(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'architecture': platform.architecture(),
            'cpu_cores': os.cpu_count(),
            'cpu_utilization': psutil.cpu_percent(interval=1),
            'total_memory': f'{psutil.virtual_memory().total if raw_data else f'{psutil.virtual_memory().total / (1024**3):.2f} GB'}',
            'free_memory': f'{psutil.virtual_memory().available if raw_data else f'{psutil.virtual_memory().available / (1024**3):.2f} GB'}',
            'used_memory': f'{psutil.virtual_memory().used if raw_data else f'{psutil.virtual_memory().used / (1024**3):.2f} GB'}',
            'disk_usage': f'{psutil.disk_usage('/').percent}%'
        }

        return SYSTEM_INFO
    
    @staticmethod
    def user() -> dict[str, Any]:
        """
        Retrieves information about the current user.

        Returns:

            `dict[str, Any]`: A dictionary containing user details such as
            `username`, `id`, and `home_dir`.
        """

        USER_INFO = {
            'username': getpass.getuser(),
            'id': os.getuid() if os.name == 'posix' else subprocess.check_output('whoami /user', shell=True).decode('cp866').splitlines()[-1].split()[-1],
            'home_dir': os.path.expanduser('~')
        }

        return USER_INFO
    
    @staticmethod
    def env() -> dict[str, str]:
        """
        Retrieves all environment variables.

        Returns:

            `dict[str, str]`: A dictionary of environment variables and their values.
        """

        return {environ_type: environ_value for environ_type, environ_value in os.environ.items()}
    
    @staticmethod
    def get_env(name: str, fallback_value: str = None) -> str | None:
        """
        Retrieves the value of a specific environment variable.

        Args:
            name (`str`): The name of the environment variable.
            fallback_value (`str`, optional): A fallback value if the variable
            does not exist. Defaults to `None`.

        Returns:
            `str | None`: The value of the environment variable or the fallback value.
        """
        
        return os.environ.get(name, fallback_value)
    
    @staticmethod
    def set_env(name: str, value: str) -> None:
        """
        Sets or updates an environment variable for the current user.

        **May be not stable.**

        Args:
            name (`str`): The name of the environment variable.
            value (`str`): The value to assign to the environment variable.

        Notes:
            - On Windows (`nt`), uses `setx` to persist the variable.
            - On POSIX systems, updates the user's shell configuration file
              (`.bashrc` or `.zshrc`) with an `export` statement.
        """
        
        if os.name == 'nt':
            subprocess.run(['setx', f'USER_{name}', value], check=True)
        
        elif os.name == 'posix':
            shell_config = os.path.expanduser('~/.bashrc')

            if 'zsh' in os.environ.get('SHELL', ''):
                shell_config = os.path.expanduser('~/.zshrc')

            line = f'export USER_{name}={shlex.quote(value)}\n'

            lines = []
            if os.path.exists(shell_config):
                with open(shell_config, 'r') as f:
                    lines = f.readlines()

            pattern = re.compile(rf'^export\s+USER_{name}=.*') 
            lines = [l for l in lines if pattern.match(l.strip())]

            content = ''.join(lines).rstrip() + f'\n{line}\n'

            with open(shell_config, 'w') as f:
                f.write(content)