import json
from pathlib import Path
from unittest import TestCase

from easys_ordermanager.v3.serializer import OrderLineEmailSerializer, Serializer


class OrderLineEmailSerializerTest(TestCase):
    def test_rejects_duplicated_included_address(self):
        s = OrderLineEmailSerializer(data={"included_addresses": ["donald@trump.gov", "donald@trump.gov"]})

        self.assertFalse(s.is_valid())

    def test_rejects_duplicated_additional_address(self):
        s = OrderLineEmailSerializer(data={"additional_addresses": ["donald@trump.gov", "donald@trump.gov"]})

        self.assertFalse(s.is_valid())

    def test_rejects_duplicated_address_across_fields(self):
        data = {"included_addresses": ["donald@trump.gov"], "additional_addresses": ["donald@trump.gov"]}
        s = OrderLineEmailSerializer(data=data)

        self.assertFalse(s.is_valid())

    def test_accepts_non_duplicated_email_addresses(self):
        data = {
            "included_addresses": ["donald@trump.gov", "eric@trump.gov"],
            "additional_addresses": ["melania@trump.gov", "elon@musk.gov"],
        }
        s = OrderLineEmailSerializer(data=data)

        self.assertTrue(s.is_valid())


class SerializerV3TestCase(TestCase):
    def test_validate_data(self):
        example_path = Path(__file__).parent / "example.json"
        with example_path.open() as f:
            fixture = json.load(f)
        s = Serializer(data=fixture)
        self.assertTrue(s.is_valid(raise_exception=True))

    def test_validate_existing_stroer_lp_example(self):
        example_path = Path(__file__).parent / "existing_stroer_lp_example.json"
        with example_path.open() as file:
            fixture = json.load(file)
            serializer = Serializer(data=fixture)
            self.assertTrue(serializer.is_valid(raise_exception=True))
