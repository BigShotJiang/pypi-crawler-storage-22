from setuptools import setup, find_packages

setup(
    name="EasyUI-python",
    version="1.0.0",
    entry_points={
        'console_scripts': [
            'EasyUI-designer=EasyUI.library:run_designer',
        ],
    },
    author="kdh",
    description="간편한 파이썬 GUI 디자이너 및 라이브러리",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "Pillow",
        "tkinterdnd2"
    ],
    python_requires='>=3.6',
)