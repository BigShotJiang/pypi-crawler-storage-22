
🚀EasyUI-python
EasyUI is the most intuitive and lightweight library for Python Tkinter development. It is designed to save you from tedious coordinate calculations and cluttered widget configuration code by providing a visual designer and a fluent chaining API.

✨ Key Features
Visual Designer: Launch the EasyUI-designer from your terminal to design your UI with drag-and-drop ease.

Fluent Chaining API: Configure widgets in a single line: .set.pos(x, y).size(w, h).color(bg="blue").

Smart Form Validation: Built-in logic for mandatory fields using .required() and simple .submit() handlers.

Modern Enhancements: Supports Entry Placeholders, Image Drag-and-Drop, and interactive Hover Animations out of the box.

📦 Installation
You can install EasyUI directly from PyPI:

_______________________________________________________
pip install EasyUI-python
🛠 Using the Visual Designer
_______________________________________________________
After installation, you can launch the designer directly from your terminal to create and save styles:
_______________________________________________________

EasyUI-designer
_______________________________________________________
Design: Drag and drop widgets to your preferred locations.

Save: Save the layout as a style JSON file.

Apply: Use the style name in your code to instantly apply coordinates and aesthetics.

💻 Quick Start Example
The syntax is designed to be expressive, clean, and fast.

_______________________________________________________
from EasyUI import create

def on_success():
    name = name_input.text
    create.alert("Success", f"Welcome to EasyUI, {name}!")

# 1. Initialize Window
create.window("EasyUI Quickstart", "400x500")

# 2. Create and Place Widgets with Chaining API
create.label("Username").set.pos(50, 50).bold()

name_input = create.textbox().required()
name_input.set.pos(50, 80).size(300, 35)
name_input.set_placeholder("Enter your name here...")

# 3. Add Interactive Buttons
submit_btn = create.button("Submit")
submit_btn.set.pos(50, 150).size(300, 45).color(bg="#28a745", fg="white")
submit_btn.set.hover(bg="#218838") # Darker green on hover

# 4. Connect Logic via Form
form = create.form(name_input)
form.submit(submit_btn, on_success)

create.start()

_______________________________________________________
📄 License
This project is licensed under the MIT License.

🤝 Contributing
Contributions, issues, and feature requests are welcome! Feel free to check the issues page on our GitHub repository.