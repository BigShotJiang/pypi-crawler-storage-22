.. EC Toolkit documentation master file, created by
   sphinx-quickstart on Tue Jul 22 09:24:09 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

EC Toolkit documentation
========================


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   api/modules
   tutorials/quickstart

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
