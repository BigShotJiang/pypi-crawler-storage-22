Installation
============

Install **EC Toolkit**:

.. code-block:: console

   pip install ec-toolkit

Requirements
------------

- **Python** ≥ 3.8  
- **NumPy**  
- **ASE**  
- **Astropy**  

These will be pulled in automatically when you install via pip.

Quick Check
-----------

Verify the installation by importing the package and printing its version:

.. code-block:: python

   >>> import ec_toolkit
   >>> ec_toolkit.__version__
   '0.1.0'

