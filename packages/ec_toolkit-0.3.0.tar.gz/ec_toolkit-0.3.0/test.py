from ec_toolkit.io.outcar import OutcarParser
from pathlib import Path


def my_zpe_locator(wd: Path, step: str) -> Path:
    return (wd / step).parent / "zpe_calculation" / "OUTCAR"


workdir = Path(
    "/Users/noel/cluster_backup/wedau/nmarks/masterarbeit/SAC-V4C3-MXene"
).expanduser()
steps = [
    Path("Bare/energy_calculation"),
    Path("O/V1/energy_calculation"),
    Path("OH/V2/energy_calculation"),
    Path("OOH/V3/energy_calculation"),
]
OutcarParser.enable_logging()
edfts, corr, conv_list = OutcarParser.auto_read(
    workdir, steps, calc_tds=True, check_structure=True, zpe_locator=my_zpe_locator
)
