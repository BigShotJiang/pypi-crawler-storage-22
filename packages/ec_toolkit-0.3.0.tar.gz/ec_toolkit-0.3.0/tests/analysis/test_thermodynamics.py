import numpy as np
import pytest

from ec_toolkit.analysis.thermodynamics import compute_eta_td, compute_g_max


class DummyMechanism:
    """Minimal duck-typed Mechanism for tests."""

    def __init__(
        self, rif, el_steps, eq_pot=0.0, is_oxidation=True, sym_fac=1, ref_el="RHE"
    ):
        """
        rif : sequence of length N+1 (reaction intermediate free energies)
        el_steps : sequence of length N (bool mask)
        eq_pot : float
        is_oxidation : bool
        """
        self._rif = np.asarray(rif, dtype=float)
        self.el_steps = list(el_steps)
        self.eq_pot = float(eq_pot)
        self.is_oxidation_reaction = bool(is_oxidation)
        self.sym_fac = sym_fac
        self.ref_el = ref_el

    def reaction_intermediate_free_energies(self, sym_fac=None):
        # ignore sym_fac for dummy
        return self._rif


def _bruteforce_gmax_from_biased(bm, el_mask):
    """
    Brute-force reference for G_max:
      G_max = max_{s in electrochemical steps} max_{t >= s+1} (bm[t] - bm[s])
    returns (Gmax, (start_1based, end_1based))
    tie-breaking: earliest start s wins (lowest s), and for equal t choose earliest t.
    """
    N_plus_1 = len(bm)
    N = N_plus_1 - 1
    best_val = -np.inf
    best_pair = (None, None)
    for s in range(N):
        if not el_mask[s]:
            continue
        for t in range(s + 1, N_plus_1):
            val = float(bm[t] - bm[s])
            # prefer earlier s (outer loop) — only update on strictly larger val
            if val > best_val:
                best_val = val
                best_pair = (s + 1, t + 1)  # convert to 1-based as compute_g_max does
    return best_val, best_pair


def test_compute_eta_td_with_dummy_mechanism():
    # want to reproduce the simple example where shifted deltas are [2.23, 3.23]
    # build rif such that deltas (biased at eq_pot) equal [2.23, 3.23]
    # choose rif_zero = [0.0, 1.0, 3.0], el_steps = [True, True], eq_pot = 1.23,
    # is_oxidation_reaction = False => biased_eq = rif_zero + eq_pot * n_e_up_to
    mech = DummyMechanism(
        rif=[0.0, 1.0, 3.0], el_steps=[True, True], eq_pot=1.23, is_oxidation=False
    )

    eta, idx = compute_eta_td(mech)
    # biased_eq = [0.0, 2.23, 5.46] -> deltas [2.23, 3.23] => max 3.23 at step 2
    assert pytest.approx(eta, rel=1e-12) == 3.23
    assert idx == 2


def test_compute_g_max_scalar_op():
    # construct intermediates from per-step dg example:
    # If stepwise dg = [1.0, -0.2, 0.5] then intermediates rif = cumulative starting at 0:
    # rif = [0.0, 1.0, 0.8, 1.3]
    rif = [0.0, 1.0, 0.8, 1.3]
    el = [False, True, True]  # length N = 3
    mech = DummyMechanism(rif=rif, el_steps=el, eq_pot=0.0, is_oxidation=True)

    op = 0.3
    Gmax, (i, j), biased_profile, op_returned = compute_g_max(mech, op, sym_fac=None)

    # compute biased intermediates the same way the function should:
    # is_oxid True => eq_eff = eq_pot + op = op
    n_e_up_to = np.empty(len(rif), dtype=int)
    n_e_up_to[0] = 0
    n_e_up_to[1:] = np.cumsum(el, dtype=int)
    eq_eff = mech.eq_pot + op
    bias = eq_eff * n_e_up_to
    bm = np.asarray(rif, dtype=float) - bias  # oxidation subtracts bias

    # reference brute-force
    expected_val, expected_pair = _bruteforce_gmax_from_biased(
        bm, np.asarray(el, dtype=bool)
    )

    assert pytest.approx(float(Gmax), rel=1e-12) == expected_val
    assert (i, j) == expected_pair
    # biased_profile should match bm
    assert np.allclose(biased_profile, bm)
    # op_returned should be the scalar op we passed
    assert float(op_returned) == pytest.approx(op)


def test_compute_g_max_array_op_vectorized():
    # same rif and el as previous test but provide vector op array
    rif = [0.0, 1.0, 0.8, 1.3]
    el = [False, True, True]
    mech = DummyMechanism(rif=rif, el_steps=el, eq_pot=0.0, is_oxidation=True)

    ops = np.array([0.0, 0.3, 0.6])
    G_list, idx_pairs, biased_matrix, op_returned = compute_g_max(
        mech, ops, sym_fac=None
    )

    assert isinstance(G_list, np.ndarray)
    assert isinstance(idx_pairs, np.ndarray)
    assert isinstance(biased_matrix, np.ndarray)
    assert isinstance(op_returned, np.ndarray)
    assert op_returned.shape == ops.shape

    # check each row against brute-force reference
    for r, op_val in enumerate(op_returned):
        eq_eff = mech.eq_pot + float(op_val)
        n_e_up_to = np.empty(len(rif), dtype=int)
        n_e_up_to[0] = 0
        n_e_up_to[1:] = np.cumsum(el, dtype=int)
        bm = np.asarray(rif, dtype=float) - eq_eff * n_e_up_to
        expected_val, expected_pair = _bruteforce_gmax_from_biased(
            bm, np.asarray(el, dtype=bool)
        )
        assert pytest.approx(float(G_list[r]), rel=1e-12) == expected_val
        assert tuple(idx_pairs[r].tolist()) == expected_pair
        assert np.allclose(biased_matrix[r], bm)
