import pytest
from pathlib import Path

POSCAR_MINIMAL = """Comment line
1.0
1.0 0.0 0.0
0.0 1.0 0.0
0.0 0.0 1.0
H
1
Direct
0.0 0.0 0.0
"""

# A minimal OUTCAR with one POSITION block and one 'sigma' line
OUTCAR_MINIMAL = """some header
POSITION                                       TOTAL-FORCE (eV/Angst)
------------------------------------------------------
  0.100  0.200  0.300   0.0  0.0  0.0
total drift: 0 0 0
 some other
 sigma  1.2345
reached required accuracy - stopping structural energy minimisation
"""


@pytest.fixture
def tmp_vasp_dir(tmp_path):
    # write POSCAR
    pos = tmp_path / "POSCAR"
    pos.write_text(POSCAR_MINIMAL)
    # write OUTCAR and zpe/OUTCAR subfolder
    out = tmp_path / "OUTCAR"
    out.write_text(OUTCAR_MINIMAL)
    (tmp_path / "zpe").mkdir()
    (tmp_path / "zpe" / "OUTCAR").write_text(OUTCAR_MINIMAL)
    return tmp_path
