# tests/io/test_outcar.py
import pytest
from ec_toolkit.io.outcar import OutcarParser


def test_read_edft(tmp_vasp_dir):
    e = OutcarParser.read_edft(tmp_vasp_dir / "OUTCAR")
    assert pytest.approx(e, rel=1e-6) == 1.2345


def test_read_converged(tmp_vasp_dir):
    assert OutcarParser.read_converged(tmp_vasp_dir / "OUTCAR")


def test_read_zpe_tds(tmp_vasp_dir):
    # default TDS off, just ZPE from our dummy = 0 / 2000 = 0
    zpe, tds, has_imag = OutcarParser.read_zpe_tds(
        tmp_vasp_dir / "zpe" / "OUTCAR", calc_tds=False
    )
    assert pytest.approx(zpe) == 0.0
    # ensure the file does not report imaginary modes in the minimal test file
    assert has_imag is False

    # with TDS on, still 0 in this minimal file
    zpe2, tds2, has_imag2 = OutcarParser.read_zpe_tds(
        tmp_vasp_dir / "zpe" / "OUTCAR", calc_tds=True
    )
    assert pytest.approx(tds2) == 0.0
    assert has_imag2 is False


def test_auto_read(tmp_vasp_dir):
    edfts, zpes, tdss, convs = OutcarParser.auto_read(
        tmp_vasp_dir, ["."], calc_tds=True, check_structure=True
    )
    assert len(edfts) == 1
    assert convs == [True]


def test_auto_read_warns_for_missing_zpe(tmp_vasp_dir, caplog):
    # remove the zpe folder so it’s “missing”
    zdir = tmp_vasp_dir / "zpe"
    if zdir.exists():
        for f in zdir.iterdir():
            f.unlink()
        zdir.rmdir()

    with pytest.warns(UserWarning, match="No ZPE/TdS OUTCAR found"):
        ed, zp, td = OutcarParser.auto_read(tmp_vasp_dir, ["."], calc_tds=True)[:3]
    # ZPE and TDS should be zero
    assert zp == [0.0] and td == [0.0]
