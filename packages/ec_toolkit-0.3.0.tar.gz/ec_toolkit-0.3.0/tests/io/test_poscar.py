import pytest
from ec_toolkit.io.poscar import PoscarParser


def test_poscar_basic(tmp_vasp_dir):
    p = PoscarParser(tmp_vasp_dir / "POSCAR")
    # lattice is identity
    assert p.lattice.shape == (3, 3)
    assert p.species == ["H"]
    assert p.species_counts == {"H": 1}
    # coords_direct should be exactly [[0,0,0]]
    assert pytest.approx(p.coords_direct[0]) == [0.0, 0.0, 0.0]
    # no selective dynamics in this minimal file
    assert p.selective_dynamics is None
    # write and re-read should round-trip
    newpath = tmp_vasp_dir / "POSCAR2"
    p.write(newpath)
    p2 = PoscarParser(newpath)
    assert pytest.approx(p2.coords_direct[0]) == [0.0, 0.0, 0.0]
