import pytest
import numpy as np
from ec_toolkit.models.classes import (
    Compound,
)


def test_compound_energy_and_stability():
    c = Compound(
        formula="H2O",
        reference_energies={"dft": -14.0, "zpe": 0.56, "tds": 0.23},
        converged=True,
        convergence_info={"max_force": 0.01, "force_threshold": 0.05},
    )

    assert c.energy("dft") == -14.0
    assert c.energy("zpe") == 0.56
    assert c.is_stable() is True
    assert repr(c) == "H2O(dft=-14.000, zpe=0.560, tds=0.230, status=OK)"
