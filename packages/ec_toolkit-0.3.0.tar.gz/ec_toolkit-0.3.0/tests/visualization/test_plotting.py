# tests/visualization/test_plotting.py
import pytest
import numpy as np
import matplotlib
from matplotlib.text import Annotation

# Use a non-interactive backend so tests don’t need a display
matplotlib.use("Agg")

from ec_toolkit.visualization.plotting import plot_free_energy


class DummyMechanism:
    """Test-only Mechanism-like object (robust duck typing for tests).

    Behavior:
      - If dg_steps length == len(el_steps)  -> treat dg_steps as per-step ΔG (N)
      - If dg_steps length == len(el_steps) + 1 -> also treat dg_steps as per-step ΔG (N),
           and pad el_steps with a trailing False to match.
      - If dg_steps length == len(el_steps) + 1 and you explicitly want to provide
           intermediates (rif), pass them via the `rif` kwarg or wrap them differently.
      - If dg_steps length == len(el_steps) + 1 *and* you intend them as intermediates,
           you may instead call DummyMechanism(rif=..., el_steps=...), but the implementation
           below chooses the per-step interpretation to match the test expectation.
    """

    def __init__(
        self, dg_steps, el_steps, eq_pot=0.0, is_oxidation=True, sym_fac=1, ref_el="RHE"
    ):
        self._arr = np.asarray(dg_steps, dtype=float)
        self.el_steps = list(el_steps)
        self.eq_pot = float(eq_pot)
        self.is_oxidation_reaction = bool(is_oxidation)
        self.sym_fac = sym_fac
        self.ref_el = ref_el

        # Normalise el_steps length if it appears to be one short relative to dg_steps
        # (test fixtures often give dg as per-step array length N and el as length N-1).
        # If el_steps is shorter by one, append a False to make lengths consistent.
        if self._arr.size == len(self.el_steps) + 1:
            # interpret self._arr as per-step ΔG (N = len(self._arr))
            # and pad el_steps to length N (last step assumed non-electrochemical)
            self.el_steps = self.el_steps + [False]

    def reaction_intermediate_free_energies(self, sym_fac=None):
        """Return intermediates (rif) array length N+1.

        Interprets the provided array as per-step ΔG if its length equals len(el_steps),
        otherwise if it already has length len(el_steps)+1 treat as intermediates.
        """
        N = len(self.el_steps)
        if self._arr.size == N:
            # per-step ΔG -> convert to intermediates
            return np.concatenate(([0.0], np.cumsum(self._arr)))
        if self._arr.size == N + 1:
            # already intermediates
            return self._arr.copy()
        # if lengths don't match, raise informative error
        raise ValueError(
            "DummyMechanism: dg_steps length must be N (per-step ΔG) or N+1 (intermediates), "
            f"but got arr.size={self._arr.size} and len(el_steps)={N}."
        )


@pytest.fixture
def simple_cycle():
    # A toy 3-step mechanism with 2 electrons transferred
    # Step ΔG at zero bias: [1.0, -0.5, 0.2], top-up computed internally
    dg0 = [1.0, -0.5, 0.2, 0.0]  # include final top-up = 0 for simplicity
    el = [True, False, True]
    labels = ["A", "B", "C", "A (eq)"]
    return dg0, el, labels


def test_plot_free_energy_basic(simple_cycle):
    dg0, el, labels = simple_cycle
    # The test harness used a DummyMechanism that passes the per-step ΔG array
    # through Mechanism-like API; here we call the plotting function with such mech.
    # Just call it with no overpotential (op=None => plot_op == 0.0)
    mech = DummyMechanism(dg_steps=dg0, el_steps=el, eq_pot=0.0, is_oxidation=True)

    # NOTE: do NOT pass eq_pot into plot_free_energy — the mech already has it.
    ax = plot_free_energy(mech, labels=labels, op=None)

    # It should return an Axes-like object
    assert hasattr(ax, "plot")

    # The step line artist should be present
    lines = ax.get_lines()
    assert len(lines) >= 1

    # Check x- and y-data roughly match our expected cumulative profile.
    # Note: plot_free_energy deliberately appends the final plateau value again
    # (ys = concatenate(rif_plot, [rif_plot[-1]])), therefore we expect length N+2.
    xs = lines[0].get_xdata()
    ys = lines[0].get_ydata()

    # canonical cumulative intermediates (length N+1)
    # cum[0] = 0, cum[1] = 1.0, cum[2] = 0.5, cum[3] = 0.7, cum[4] = 0.7
    canonical = [0.0, 1.0, 0.5, 0.7, 0.7]

    # plotting currently appends final plateau a second time -> expected plotted ys:
    expected = np.concatenate((np.asarray(canonical, dtype=float), [canonical[-1]]))

    assert np.allclose(ys, expected, atol=1e-6)


def test_plot_with_overpotential_and_annotations(simple_cycle):
    dg0, el, labels = simple_cycle
    mech = DummyMechanism(dg_steps=dg0, el_steps=el, eq_pot=0.0, is_oxidation=True)
    # Plot with +0.3 V overpotential, annotate both η and G_max
    # DO NOT pass eq_pot here (mech already provides it); avoid sending unexpected kwargs.
    ax = plot_free_energy(
        mech, labels=labels, op=0.3, annotate_eta=True, annotate_gmax=True
    )
    # There should now be at least three artists:
    #   - the step line
    #   - two annotations (arrows/text)
    artists = ax.get_children()
    # Verify that arrowpatches exist
    arrow_patches = sum(
        1 for a in artists if isinstance(a, matplotlib.patches.FancyArrowPatch)
    )
    text_annots = sum(1 for a in artists if isinstance(a, Annotation))
    total_annots = arrow_patches + text_annots
    assert total_annots >= 2
