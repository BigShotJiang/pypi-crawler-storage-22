
## 日志


```py

pip install confluent-kafka



import json
import logging
import socket
import traceback
from datetime import datetime
from confluent_kafka import Producer


class KafkaLoggingHandler(logging.Handler):
    def __init__(
        self,
        *,
        brokers: str,
        topic: str,
        client_id: str = "python-logger",
        acks: str = "1",
        linger_ms: int = 50,
        batch_size: int = 16384,
        enable_idempotence: bool = False,
        extra_producer_config: dict | None = None,
    ):
        super().__init__()

        conf = {
            "bootstrap.servers": brokers,
            "client.id": client_id,
            "acks": acks,
            "linger.ms": linger_ms,
            "batch.size": batch_size,
            "enable.idempotence": enable_idempotence,
        }

        if extra_producer_config:
            conf.update(extra_producer_config)

        self.topic = topic
        self.hostname = socket.gethostname()
        self.producer = Producer(conf)

    def emit(self, record: logging.LogRecord):
        try:
            payload = self._format_record(record)

            self.producer.produce(
                topic=self.topic,
                value=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                key=record.name,
                on_delivery=self._delivery_report,
            )

            # 非阻塞轮询（触发回调）
            self.producer.poll(0)

        except Exception:
            self.handleError(record)

    def _format_record(self, record: logging.LogRecord) -> dict:
        data = {
            "timestamp": datetime.utcfromtimestamp(record.created).isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "file": record.pathname,
            "line": record.lineno,
            "function": record.funcName,
            "process": record.process,
            "thread": record.threadName,
            "host": self.hostname,
        }

        if record.exc_info:
            data["exception"] = "".join(traceback.format_exception(*record.exc_info))

        return data

    @staticmethod
    def _delivery_report(err, msg):
        if err:
            # ⚠️ 生产环境可打到 stderr 或 fallback 文件
            print(f"[KafkaLogError] {err} -> {msg.topic()}")

    def close(self):
        self.producer.flush(timeout=5)
        super().close()




=========================================================
快速接入 logging（最小示例）
import logging

logger = logging.getLogger("app")
logger.setLevel(logging.INFO)

kafka_handler = KafkaLoggingHandler(
    brokers="localhost:9092",
    topic="python-logs",
    client_id="my-service",
)

logger.addHandler(kafka_handler)

logger.info("service started")
logger.error("something failed", exc_info=True)







=========================================================
生产级 logging 配置（推荐）
logging.config.dictConfig
LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "kafka": {
            "()": "your_module.KafkaLoggingHandler",
            "brokers": "kafka01:9092,kafka02:9092",
            "topic": "python-logs",
            "client_id": "order-service",
            "acks": "all",
            "linger_ms": 100,
        }
    },
    "root": {
        "level": "INFO",
        "handlers": ["kafka"],
    },
}

import logging.config
logging.config.dictConfig(LOGGING_CONFIG)

```







```

pip install kafka-logging-handler==0.2.5


import logging
from kafka_logger.handlers import KafkaLoggingHandler

KAFKA_BOOTSTRAP_SERVER = ('<hostname:port>')
KAFKA_CA = '<path_to_ca_cert>'
TOPIC = '<publish_topic>'

logger = logging.getLogger('MyCoolProject')

# Instantiate your kafka logging handler object
kafka_handler_obj = KafkaLoggingHandler(KAFKA_BOOTSTRAP_SERVER,
                                        TOPIC,
                                        ssl_cafile=KAFKA_CA)

logger.addHandler(kafka_handler_obj)
# Set logging level
logger.setLevel(logging.DEBUG)

logger.info('Happy Logging!')
Troubleshooting
If you see the following error when running on macOS:

Traceback (most recent call last):
  File "/path/to/kafka-logging-handler/kafka_logger/handlers.py", line 109, in __init__
    'host_ip': socket.gethostbyname(socket.gethostname())
socket.gaierror: [Errno 8] nodename nor servname provided, or not known
The issues is that socket.gethostname() resolves to a name that is not available in /etc/hosts. First run python3 -c "import socket; print(socket.gethostname())" to get the name (e.g. MacBook-Pro). Then fix it with sudo echo 127.0.0.1 MacBook-Pro >> /etc/hosts, where MacBook-Pro is your computer name. There won't be OS-specific fix for it in the library.


```





> https://stackoverflow.com/questions/21102293/how-to-write-to-kafka-from-python-logging-module

```py

# Source - https://stackoverflow.com/a/21122445
# Posted by Wildfire
# Retrieved 2026-02-11, License - CC BY-SA 3.0

from kafka.client import KafkaClient
from kafka.producer import SimpleProducer,KeyedProducer
import logging,sys

class KafkaLoggingHandler(logging.Handler):

    def __init__(self, host, port, topic, key=None):
        logging.Handler.__init__(self)
        self.kafka_client = KafkaClient(host, port)
        self.key = key
        if key is None:
            self.producer = SimpleProducer(self.kafka_client, topic)
        else:
            self.producer = KeyedProducer(self.kafka_client, topic)

    def emit(self, record):
        #drop kafka logging to avoid infinite recursion
        if record.name == 'kafka':
            return
        try:
            #use default formatting
            msg = self.format(record)
            #produce message
            if self.key is None:
                self.producer.send_messages(msg)
            else:
                self.producer.send(self.key, msg)
        except:
            import traceback
            ei = sys.exc_info()
            traceback.print_exception(ei[0], ei[1], ei[2], None, sys.stderr)
            del ei

    def close(self):
        self.producer.stop()
        logging.Handler.close(self)

kh = KafkaLoggingHandler("localhost", 9092, "test_log")
#OR
#kh = KafkaLoggingHandler("localhost", 9092, "test_log", "key1")

logger = logging.getLogger("")
logger.setLevel(logging.DEBUG)
logger.addHandler(kh)
logger.info("The %s boxing wizards jump %s", 5, "quickly")
logger.debug("The quick brown %s jumps over the lazy %s", "fox",  "dog")
try:
    import math
    math.exp(1000)
except:
    logger.exception("Problem with %s", "math.exp")




# The handler uses this Kafka client: https://github.com/mumrah/kafka-python

```


### 2

```py

# Source - https://stackoverflow.com/a/50489652
# Posted by sebito91, modified by community. See post 'Timeline' for change history
# Retrieved 2026-02-11, License - CC BY-SA 4.0

# -*- coding: utf-8 -*-
"""Module to test out logging to kafka."""

import json
import logging

from utils.kafka_handler import KafkaHandler
from kafka import KafkaProducer


def run_it(logger=None):
    """Run the actual connections."""

    logger = logging.getLogger(__name__)
    # enable the debug logger if you want to see ALL of the lines
    #logging.basicConfig(level=logging.DEBUG)
    logger.setLevel(logging.DEBUG)

    kh = KafkaHandler(['localhost:9092'], 'sebtest')
    logger.addHandler(kh)

    logger.info("I'm a little logger, short and stout")
    logger.debug("Don't tase me bro!")


if __name__ == "__main__":
    run_it()




# Source - https://stackoverflow.com/a/50489652
# Posted by sebito91, modified by community. See post 'Timeline' for change history
# Retrieved 2026-02-11, License - CC BY-SA 4.0

# -*- coding: utf-8 -*-
"""Module to provide kafka handlers for internal logging facility."""

import json
import logging
import sys

from kafka import KafkaProducer


class KafkaHandler(logging.Handler):
    """Class to instantiate the kafka logging facility."""

    def __init__(self, hostlist, topic='corp_it_testing', tls=None):
        """Initialize an instance of the kafka handler."""
        logging.Handler.__init__(self)
        self.producer = KafkaProducer(bootstrap_servers=hostlist,
                                      value_serializer=lambda v: json.dumps(v).encode('utf-8'),
                                      linger_ms=10)
        self.topic = topic

    def emit(self, record):
        """Emit the provided record to the kafka_client producer."""
        # drop kafka logging to avoid infinite recursion
        if 'kafka.' in record.name:
            return

        try:
            # apply the logger formatter
            msg = self.format(record)
            self.producer.send(self.topic, {'message': msg})
            self.flush(timeout=1.0)
        except Exception:
            logging.Handler.handleError(self, record)

    def flush(self, timeout=None):
        """Flush the objects."""
        self.producer.flush(timeout=timeout)

    def close(self):
        """Close the producer and clean up."""
        self.acquire()
        try:
            if self.producer:
                self.producer.close()

            logging.Handler.close(self)
        finally:
            self.release()

```



