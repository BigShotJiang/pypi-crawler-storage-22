## one

```python

print("one")


```
