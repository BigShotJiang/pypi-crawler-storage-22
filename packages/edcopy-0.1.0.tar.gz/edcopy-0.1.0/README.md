## edcopy

`edcopy` est un petit outil CLI pour préparer un `prompt.md` à partir de fichiers sélectionnés dans un TUI.

### Installation (global)

Depuis ce dossier:

```bash
uv tool install .
```

Puis:

```bash
edcopy
```

### Usage rapide

Dans le TUI:

- Tape une ligne contenant un ou plusieurs chemins de fichiers (ex: `src/main.py README.md`)
- Utilise `Tab` pour autocompléter les fichiers (scan récursif depuis le dossier courant)
- Si tu tapes un chemin partiel (ex: `test1`) puis `Entrée`, `edcopy` prend automatiquement le meilleur match
- `Ctrl+C` termine la sélection et génère `prompt.md`
- `Entrée` sur une ligne vide génère aussi `prompt.md`
- Au lancement, un `prompt.md` existant est supprimé

Commandes disponibles:

- `@list` pour voir la sélection actuelle
- `@undo` pour enlever le dernier fichier ajouté
- `@clear` pour vider la sélection
- `@rescan` pour rescanner les fichiers
- `@done` pour générer
- `@quit` pour quitter sans générer

### Exemple de sortie

````md
## Fichier 1: `file.py`
Chemin: `/abs/path/to/file.py`

```python
1 | print("hello")
2 | print("world")
```

---

## Fichier 2: `file2.py`
Chemin: `/abs/path/to/file2.py`
````
