from __future__ import annotations

import argparse
import os
import re
import sys
from collections import OrderedDict
from pathlib import Path
from typing import Iterable

from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion

IGNORED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
}

TOKEN_PATTERN = re.compile(r"[^\s,;]+")


class MentionCompleter(Completer):
    def __init__(self, files: list[str]) -> None:
        self.files = files

    def set_files(self, files: list[str]) -> None:
        self.files = files

    def _match_rank(self, query: str, rel_path: str) -> int | None:
        rel_lower = rel_path.lower()
        basename_lower = Path(rel_path).name.lower()

        if rel_lower.startswith(query):
            return 0
        if basename_lower.startswith(query):
            return 1
        if f"/{query}" in rel_lower:
            return 2
        if query in rel_lower:
            return 3
        return None

    def ranked_matches(self, query: str) -> list[str]:
        q = query.lower().strip()
        ranked_matches: list[tuple[int, str]] = []
        for rel_path in self.files:
            if not q:
                ranked_matches.append((0, rel_path))
                continue
            rank = self._match_rank(q, rel_path)
            if rank is None:
                continue
            ranked_matches.append((rank, rel_path))

        ranked_matches.sort(key=lambda item: (item[0], len(item[1]), item[1]))
        return [path for _, path in ranked_matches]

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor
        match = re.search(r"(^|[\s,;])([^\s,;]*)$", text)
        if not match:
            return

        raw_prefix = match.group(2)
        query = raw_prefix[1:] if raw_prefix.startswith("@") else raw_prefix
        start_position = -len(raw_prefix)

        for count, rel_path in enumerate(self.ranked_matches(query)):
            yield Completion(
                text=rel_path,
                start_position=start_position,
                display=rel_path,
            )
            if count >= 199:
                return


def discover_files(root: Path) -> list[str]:
    discovered: list[str] = []
    for current, dirs, files in os.walk(root, topdown=True):
        dirs[:] = [d for d in dirs if d not in IGNORED_DIRS]
        current_path = Path(current)
        for filename in files:
            path = current_path / filename
            try:
                rel = path.relative_to(root).as_posix()
            except ValueError:
                continue
            discovered.append(rel)
    discovered.sort()
    return discovered


def extract_candidates(line: str) -> list[str]:
    candidates: list[str] = []
    for token in TOKEN_PATTERN.findall(line):
        value = token[1:] if token.startswith("@") else token
        if value:
            candidates.append(value)
    return candidates


def resolve_mentions(root: Path, mentions: Iterable[str]) -> list[Path]:
    resolved: list[Path] = []
    for mention in mentions:
        path = Path(mention)
        if not path.is_absolute():
            path = (root / path).resolve()
        else:
            path = path.resolve()
        resolved.append(path)
    return resolved


def format_numbered_lines(content: str) -> str:
    lines = content.splitlines()
    if not lines:
        return "1 | "
    return "\n".join(f"{idx} | {line}" for idx, line in enumerate(lines, start=1))


def read_file_content(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def language_from_suffix(path: Path) -> str:
    mapping = {
        ".py": "python",
        ".js": "javascript",
        ".ts": "typescript",
        ".tsx": "tsx",
        ".jsx": "jsx",
        ".json": "json",
        ".md": "markdown",
        ".yml": "yaml",
        ".yaml": "yaml",
        ".sh": "bash",
        ".toml": "toml",
        ".html": "html",
        ".css": "css",
        ".sql": "sql",
        ".go": "go",
        ".rs": "rust",
        ".java": "java",
        ".c": "c",
        ".cpp": "cpp",
    }
    return mapping.get(path.suffix.lower(), "text")


def format_file_section(index: int, file_path: Path, content: str) -> str:
    language = language_from_suffix(file_path)
    numbered = format_numbered_lines(content)
    return "\n".join(
        [
            f"## Fichier {index}: `{file_path.name}`",
            f"Chemin: `{file_path}`",
            "",
            f"```{language}",
            numbered,
            "```",
        ]
    )


def write_prompt(selected_files: list[Path], output: Path) -> None:
    if not selected_files:
        output.write_text("", encoding="utf-8")
        return

    sections: list[str] = []
    for index, file_path in enumerate(selected_files, start=1):
        try:
            content = read_file_content(file_path)
        except OSError as exc:
            sections.append(
                "\n".join(
                    [
                        f"## Fichier {index}: `{file_path.name}`",
                        f"Chemin: `{file_path}`",
                        "",
                        f"[ERROR] Unable to read file: {exc}",
                    ]
                )
            )
            continue

        sections.append(format_file_section(index, file_path, content))

    output.write_text("\n\n---\n\n".join(sections) + "\n", encoding="utf-8")


def run_tui(root: Path, output: Path) -> int:
    if output.exists():
        try:
            output.unlink()
            print(f"Sortie précédente supprimée: {output}")
        except OSError as exc:
            print(f"[WARN] Impossible de supprimer {output}: {exc}")

    file_index = discover_files(root)
    completer = MentionCompleter(file_index)
    session = PromptSession(completer=completer, complete_while_typing=True)

    selected: OrderedDict[Path, None] = OrderedDict()

    print(f"edcopy - root: {root}")
    print(f"Sortie: {output}")
    print("Ajoute des fichiers en tapant leur chemin puis Entrée.")
    print("Commandes: @list, @undo, @clear, @rescan, @done, @quit")
    print("Ligne vide => @done | Ctrl+C => terminer et générer")

    while True:
        try:
            line = session.prompt("edcopy> ")
        except KeyboardInterrupt:
            print("\nFin de sélection (Ctrl+C).")
            break
        except EOFError:
            print()
            break

        stripped = line.strip()
        if stripped == "":
            break
        if stripped == "@quit":
            print("Aucun fichier généré.")
            return 0
        if stripped == "@done":
            break
        if stripped == "@clear":
            selected.clear()
            print("Sélection vidée.")
            continue
        if stripped == "@list":
            if not selected:
                print("Aucun fichier sélectionné.")
            else:
                print("Fichiers sélectionnés:")
                for item in selected:
                    print(f"- {item}")
            continue
        if stripped == "@undo":
            if not selected:
                print("Aucun fichier à retirer.")
                continue
            removed, _ = selected.popitem(last=True)
            print(f"Retiré: {removed}")
            continue
        if stripped == "@rescan":
            file_index = discover_files(root)
            completer.set_files(file_index)
            print(f"Rescan terminé: {len(file_index)} fichiers indexés.")
            continue
        if stripped.startswith("/"):
            print("Commande invalide. Utilise le préfixe @ (ex: @list).")
            continue

        candidates = extract_candidates(line)
        if not candidates:
            print("Aucun chemin détecté.")
            continue

        for raw_candidate in candidates:
            candidate = resolve_mentions(root, [raw_candidate])[0]
            auto_label = ""
            if not candidate.exists() and not Path(raw_candidate).is_absolute():
                matches = completer.ranked_matches(raw_candidate)
                if matches:
                    matched_rel = matches[0]
                    candidate = (root / matched_rel).resolve()
                    auto_label = f"[AUTO] {raw_candidate} -> {matched_rel} | "

            if not candidate.exists():
                print(f"[WARN] Introuvable: {raw_candidate}")
                continue
            if not candidate.is_file():
                print(f"[WARN] Pas un fichier: {candidate}")
                continue
            if candidate in selected:
                print(f"[SKIP] Déjà ajouté: {candidate}")
                continue
            selected[candidate] = None
            print(f"{auto_label}[OK] Ajouté: {candidate}")

    write_prompt(list(selected.keys()), output)
    print(f"prompt généré: {output} ({len(selected)} fichiers)")
    return 0


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="edcopy",
        description="Collect files from a TUI and build a numbered prompt.md",
    )
    parser.add_argument(
        "-o",
        "--output",
        default="prompt.md",
        help="Chemin de sortie (défaut: prompt.md)",
    )
    parser.add_argument(
        "-f",
        "--file",
        action="append",
        default=[],
        help="Ajoute un fichier directement (peut être répété).",
    )
    return parser.parse_args(argv)


def run_non_interactive(root: Path, files: list[str], output: Path) -> int:
    selected: OrderedDict[Path, None] = OrderedDict()
    for item in files:
        mention = item[1:] if item.startswith("@") else item
        candidate = Path(mention)
        if not candidate.is_absolute():
            candidate = (root / candidate).resolve()
        else:
            candidate = candidate.resolve()

        if not candidate.exists():
            print(f"[WARN] Introuvable: {candidate}")
            continue
        if not candidate.is_file():
            print(f"[WARN] Pas un fichier: {candidate}")
            continue
        selected[candidate] = None

    if not selected:
        print("Aucun fichier valide fourni.")
        return 1

    write_prompt(list(selected.keys()), output)
    print(f"prompt généré: {output} ({len(selected)} fichiers)")
    return 0


def main() -> int:
    args = parse_args(sys.argv[1:])
    root = Path.cwd()
    output = Path(args.output)
    if not output.is_absolute():
        output = (root / output).resolve()

    if args.file:
        return run_non_interactive(root, args.file, output)
    return run_tui(root, output)


if __name__ == "__main__":
    raise SystemExit(main())
