# Edcopy changelog
version = "0.1.5"

Changements: Ajout du support pour le presse-papiers, multiplateforme. 