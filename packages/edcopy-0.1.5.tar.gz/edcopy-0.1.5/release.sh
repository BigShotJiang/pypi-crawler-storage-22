#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

if ! command -v uv >/dev/null 2>&1; then
  echo "Erreur: 'uv' n'est pas installé ou introuvable dans PATH."
  exit 1
fi

if [[ ! -f "pyproject.toml" ]]; then
  echo "Erreur: pyproject.toml introuvable dans $ROOT_DIR"
  exit 1
fi

VERSION="$(sed -n 's/^version = "\(.*\)"/\1/p' pyproject.toml | head -n1)"
if [[ -z "${VERSION}" ]]; then
  echo "Erreur: impossible de lire la version dans pyproject.toml"
  exit 1
fi

echo "Release edcopy v${VERSION}"
echo "1) Nettoyage dist/"
rm -rf dist

echo "2) Build"
uv build

echo "3) Artefacts générés:"
ls -1 dist

echo
read -r -p "Publier sur PyPI maintenant ? [y/N] " reply
if [[ ! "${reply}" =~ ^[Yy]$ ]]; then
  echo "Publication annulée. Build conservé dans dist/."
  exit 0
fi

echo "4) Publish"
uv publish

echo "Terminé: edcopy v${VERSION} publié."
