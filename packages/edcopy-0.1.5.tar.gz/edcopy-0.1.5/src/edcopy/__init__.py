"""edcopy package."""

