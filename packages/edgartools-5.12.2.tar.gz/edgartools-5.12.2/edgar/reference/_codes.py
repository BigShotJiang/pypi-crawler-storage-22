from functools import lru_cache
from typing import Optional

from edgar.reference.data.common import read_csv_from_package


@lru_cache(maxsize=1)
def _load_place_codes() -> dict:
    """Load place codes from CSV file."""
    df = read_csv_from_package('place_codes.csv')
    # Create mapping from code to (place_name, type)
    return {row['Code']: (row['Place'].title(), row['Type']) for _, row in df.iterrows()}


def get_place_name(code: str) -> Optional[str]:
    """
    Get the full place name for a state/country code.

    Args:
        code: The SEC place code (e.g., 'DE', 'CA', 'X0')

    Returns:
        The full place name in title case (e.g., 'Delaware', 'California', 'United Kingdom')
        or None if not found
    """
    place_codes = _load_place_codes()
    result = place_codes.get(code)
    return result[0] if result else None


def get_place_type(code: str) -> Optional[str]:
    """
    Get the type (US, CANADIAN, FOREIGN, UNKNOWN) for a place code.

    Args:
        code: The SEC place code (e.g., 'DE', 'CA', 'K3')

    Returns:
        'US', 'CANADIAN', 'FOREIGN', or 'UNKNOWN', or None if code not found
    """
    place_codes = _load_place_codes()
    result = place_codes.get(code)
    return result[1] if result else None


def get_filer_type(state_code: str) -> Optional[str]:
    """
    Get the filer type based on state of incorporation.

    Args:
        state_code: The SEC state/country code (e.g., 'DE', 'CA', 'A6')

    Returns:
        'Domestic' - Incorporated in US
        'Canadian' - Incorporated in Canada
        'Foreign' - Incorporated elsewhere
        None - Unknown or code not found
    """
    place_type = get_place_type(state_code)
    if place_type == 'US':
        return 'Domestic'
    elif place_type == 'CANADIAN':
        return 'Canadian'
    elif place_type == 'FOREIGN':
        return 'Foreign'
    return None


def is_us_company(state_code: str) -> bool:
    """
    Determine if a company is a US company based on its state of incorporation.

    Args:
        state_code: The SEC state/country code (e.g., 'DE', 'CA', 'K3')

    Returns:
        True if the company is incorporated in a US state or territory, False otherwise
    """
    place_type = get_place_type(state_code)
    return place_type == 'US'


def is_foreign_company(state_code: str) -> bool:
    """
    Determine if a company is a foreign company based on its state of incorporation.

    Args:
        state_code: The SEC state/country code (e.g., 'DE', 'CA', 'K3')

    Returns:
        True if the company is incorporated in a foreign country, False otherwise
    """
    place_type = get_place_type(state_code)
    return place_type == 'FOREIGN'


def is_canadian_company(state_code: str) -> bool:
    """
    Determine if a company is a Canadian company based on its state of incorporation.

    Args:
        state_code: The SEC state/country code (e.g., 'A6', 'A0', 'Z4')

    Returns:
        True if the company is incorporated in a Canadian province or territory, False otherwise
    """
    place_type = get_place_type(state_code)
    return place_type == 'CANADIAN'


ACRONYMS = {
    "CCC": "CIK Confirmation Code",
    "CIK": "Central Index Key",
    "EDGAR": "Electronic Data Gathering, Analysis, and Retrieval",
    "SEC": "Securities and Exchange Commission",
}

INVESTMENT_CATEGORIES = {
    "ABS": "Asset-backed securities",
    "ACMO": "Agency collateralized mortgage obligations",
    "ACMBS": "Agency debentures and agency strips",
    "AMBS": "Agency mortgage-backed securities",
    "UST": " U.S. Treasuries (including strips)",
    "N/A": "Not applicable"
}

ISO_STATES_AND_OUTLYING_AREAS = {
    "US-AL": "ALABAMA",
    "US-AK": "ALASKA",
    "US-AZ": "ARIZONA",
    "US-AR": "ARKANSAS",
    "US-CA": "CALIFORNIA",
    "US-CO": "COLORADO",
    "US-CT": "CONNECTICUT",
    "US-DE": "DELAWARE",
    "US-DC": "DISTRICT OF COLUMBIA",

}

ISO_COUNTRY_CODES = {
    "AF": " AFGHANISTAN",
    "AX": "ALAND ISLANDS",
    "AL": "ALBANIA",
    "DZ": "ALGERIA",
    "AS": "AMERICAN SAMOA",
    "AD": "ANDORRA",
    "AO": "ANGOLA",
    "AI": "ANGUILLA",
    "AQ": "ANTARCTICA",
    "AG": "ANTIGUA AND BARBUDA",
    "AR": "ARGENTINA",
    "AM": "ARMENIA",
    "AW": "ARUBA",
    "AU": "AUSTRALIA",
    "AT": "AUSTRIA",
    "AZ": "AZERBAIJAN",
    "BS": "BAHAMAS",
    "BH": "BAHRAIN",
    "BD": "BANGLADESH",
    "BB": "BARBADOS",
    "BY": "BELARUS",
    "BE": "BELGIUM",
    "BZ": "BELIZE",
    "BJ": "BENIN",
    "BM": "BERMUDA",
    "BT": "BHUTAN",
    "BO": "BOLIVIA (PLURINATIONAL STATE OF)",
    "BQ": "BONAIRE, SINT EUSTATIUS AND SABA",
    "BA": "BOSNIA AND HERZEGOVINA",
    "BW": "BOTSWANA",
    "BV": "BOUVET ISLAND",
    "BR": "BRAZIL",
    "IO": "BRITISH INDIAN OCEAN TERRITORY",
    "BN": "BRUNEI DARUSSALAM",
    "BG": "BULGARIA",
    "BF": "BURKINA FASO",
    "BI": "BURUNDI",
    "CV": "CABO VERDE",
    "KH": "CAMBODIA",
    "CM": "CAMEROON",
    "CA": "CANADA",
    "KY": "CAYMAN ISLANDS",
    "CF": "CENTRAL AFRICAN REPUBLIC",
    "TD": "CHAD",
    "CL": "CHILE",
    "CN": "CHINA",
    "CX": "CHRISTMAS ISLAND",
    "CC": "COCOS (KEELING) ISLANDS",
    "CO": "COLOMBIA",
    "KM": "COMOROS",
    "CG": "CONGO",
    "CD": "COOK ISLANDS",
    "CR": "COSTA RICA",
    "CI": "COTE D'IVOIRE",
    "HR": "CROATIA",
    "CU": "CUBA",
    "CW": "CURACAO",
    "CY": "CYPRUS",
    "CZ": "CZECHIA",
    "DK": "DENMARK",
    "DJ": "DJIBOUTI",
    "DM": "DOMINICA",
    "DO": "DOMINICAN REPUBLIC",
    "EC": "ECUADOR",
    "EG": "EGYPT",
    "SV": "EL SALVADOR",
    "GQ": "EQUATORIAL GUINEA",
    "ER": "ERITREA",
    "EE": "ESTONIA",
    "ET": "ETHIOPIA",
    "FK": "FALKLAND ISLANDS (MALVINAS)",
    "FO": "FAROE ISLANDS",
    "FJ": "FIJI",
    "FI": "FINLAND",
    "FR": "FRANCE",
    "GF": "FRENCH GUIANA",
    "PF": "FRENCH POLYNESIA",
    "TF": "FRENCH SOUTHERN TERRITORIES",
    "GA": "GABON",
    "GM": "GAMBIA",
}
