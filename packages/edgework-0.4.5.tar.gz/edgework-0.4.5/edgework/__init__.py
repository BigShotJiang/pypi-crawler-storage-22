"""Edgework NHL API Client - Version 0.4.5"""

__version__ = "0.4.5"

from .edgework import Edgework

__all__ = ["Edgework", "__version__"]
