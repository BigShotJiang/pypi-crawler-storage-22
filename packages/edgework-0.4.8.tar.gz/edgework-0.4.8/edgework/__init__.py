"""Edgework NHL API Client - Version 0.4.7"""

__version__ = "0.4.8"

from .edgework import Edgework

__all__ = ["Edgework", "__version__"]
