# Games

Game-related functionality in Edgework.

## Game Events

::: edgework.models.game_events.GameEvent

::: edgework.models.game_events.GameLog

## Game Client

::: edgework.clients.game_client.GameClient
