"""Edgework NHL API Client - Version 0.4.8"""

__version__ = "0.4.9"

from .edgework import Edgework

__all__ = ["Edgework", "__version__"]
