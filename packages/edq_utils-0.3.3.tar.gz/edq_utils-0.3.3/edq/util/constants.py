DEFAULT_ENCODING: str = 'utf-8'
""" The default encoding that will be used when reading and writing. """
