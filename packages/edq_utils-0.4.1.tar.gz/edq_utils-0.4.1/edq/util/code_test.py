import os

import edq.testing.unittest
import edq.util.code

THIS_DIR = os.path.abspath(os.path.dirname(os.path.realpath(__file__)))
DATA_DIR = os.path.join(THIS_DIR, 'testdata', 'code')

class TestCode(edq.testing.unittest.BaseTest):
    """
    Test the utilities for importing code.
    """

    def test_extract_base(self):
        """ Test extracting code. """

        for ext in ['py', 'ipynb']:
            path = os.path.join(DATA_DIR, 'simple.' + ext)
            source_code = edq.util.code.extract_code(path)
            self.assertEqual(source_code, "SOME_CONSTANT = 1")

    def test_sanitize_import_base(self):
        """ Test sanitizing code. """

        for ext in ['py', 'ipynb']:
            for basename in ['base', 'base_with_raise']:
                path = os.path.join(DATA_DIR, basename + '.' + ext)
                module = edq.util.code.sanitize_and_import_path(path)

                self.assertEqual(module.SOME_CONSTANT, 1)
                self.assertIn('random', dir(module))
                self.assertNotIn('some_int', dir(module))
                self.assertIn('some_function', dir(module))
