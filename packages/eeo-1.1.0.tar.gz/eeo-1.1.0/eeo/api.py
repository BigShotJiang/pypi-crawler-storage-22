# -*- coding: utf-8 -*-
"""
@Author   : 清澈
@Time     :2026/1/15
@File     :api.py
@IDE      :PyCharm
"""
import json
import requests

from typing import Dict, List, Any, Optional
from .urls import ApiUrls
from .utils import SignatureUtils, RequestUtils


class ClassInAPI:
    """
    ClassIn API客户端

    如果你有任何疑问，可以通过eeoapisupport@eeoa.com联系我们
    If you have any questions you can contact us at eeoapisupport@eeoa.com
    ClassIn APIDoc：https://docs.eeo.cn/api/
    """

    def __init__(self, school_uid: int, school_secret: str, domain: str = 'https://api.eeo.cn'):
        """
        初始化ClassIn API客户端

        Args:
            school_uid: eeo 学校账号UID
            school_secret: 密钥
            domain: API域名，默认为 https://api.eeo.cn
        """
        self.SID = school_uid
        self.secret = school_secret
        self.urls = ApiUrls(domain)
        self.session = requests.Session()

    def _get_safe_key(self) -> tuple:
        """获取安全密钥"""
        return SignatureUtils.generate_safe_key(self.secret)

    def _create_v2_headers(self, payload: Dict[str, Any]) -> Dict[str, str]:
        """
        创建v2接口的请求头

        Args:
            payload: 请求数据

        Returns:
            Dict: 请求头
        """
        return SignatureUtils.generate_v2_signature(payload, self.SID, self.secret)

    def _make_request(self, url: str, **kwargs) -> Dict[str, Any]:
        """
        发送HTTP POST请求

        Args:
            url: 请求URL
            **kwargs: 请求参数

        Returns:
            Dict: 响应数据
        """
        try:
            response = self.session.request('POST', url, **kwargs)
            response.raise_for_status()
            return RequestUtils.validate_response(response)
        except requests.RequestException as e:
            raise Exception(f"请求失败: {e}")

    # =============== 用户相关接口 ===============

    def register(self, account: str, password: str, nickname: Optional[str] = None,
                 addToSchoolMember: Optional[int] = None) -> Dict[str, Any]:
        """
        注册用户

        Args:
            account: 用户手机号或邮箱
            nickname: eeo.cn姓名，如用户是首次注册，将同步姓名信息至客户端昵称，非首次注册则不修改用户当前昵称
            password: 密码
            addToSchoolMember: 1学生 2老师

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        base_data = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'password': password,
            'nickname': nickname,
            'addToSchoolMember': addToSchoolMember
        }

        if '@' in account:
            base_data['email'] = account
        else:
            base_data['telephone'] = account

        data = RequestUtils.prepare_request_data(base_data)
        return self._make_request(self.urls.register, data=data)

    def register_multiple(self, userJson: List[Dict]) -> Dict[str, Any]:
        """
        批量注册用户

        Args:
            userJson: 用户信息列表，格式示例：
                [
                    {"telephone":"xxxx","nickname":"xxxx","password":"xxxx"},
                    {"email":"xxxx","nickname":"xxxx","password":"xxxx"}
                ]

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        data = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'userJson': json.dumps(userJson)
        }

        return self._make_request(self.urls.registerMultiple, data=data)

    def modify_password(self, uid: int, oldMd5pass: str, password: Optional[str] = None,
                        md5pass: Optional[str] = None) -> Dict[str, Any]:
        """
        修改用户密码

        Args:
            uid: 用户UID
            oldMd5pass: 32位小写 原MD5密码
            password: 6-20位密码，如果都传以md5pass为准
            md5pass: 32位MD5小写密码

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'uid': uid,
            'oldMd5pass': oldMd5pass,
            'password': password,
            'md5pass': md5pass,
        }

        data = RequestUtils.prepare_request_data(payload)
        return self._make_request(self.urls.modifyPassword, data=data)

    def add_teacher(self, teacherAccount: str, teacherName: str) -> Dict[str, Any]:
        """
        添加学校老师

        Args:
            teacherAccount: 老师账号
            teacherName: 老师姓名

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'teacherAccount': teacherAccount,
            'teacherName': teacherName
        }

        return self._make_request(self.urls.addTeacher, data=payload)

    def edit_teacher(self, teacherUid: int, teacherName: str) -> Dict[str, Any]:
        """
        编辑老师信息

        Args:
            teacherUid: 用户UID
            teacherName: 老师姓名

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'teacherUid': teacherUid,
            'teacherName': teacherName
        }

        return self._make_request(self.urls.editTeacher, data=payload)

    def stop_using_teacher(self, teacherUid: int) -> Dict[str, Any]:
        """
        停用老师

        Args:
            teacherUid: 用户UID

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'teacherUid': teacherUid,
        }

        return self._make_request(self.urls.stopUsingTeacher, data=payload)

    def restart_using_teacher(self, teacherUid: int) -> Dict[str, Any]:
        """
        启用老师

        Args:
            teacherUid: 用户UID

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'teacherUid': teacherUid,
        }

        return self._make_request(self.urls.restartUsingTeacher, data=payload)

    def add_school_student(self, studentAccount: str, studentName: str) -> Dict[str, Any]:
        """
        添加学校学生

        Args:
            studentAccount: 学生账号
            studentName: 学生姓名

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'studentAccount': studentAccount,
            'studentName': studentName
        }

        return self._make_request(self.urls.addSchoolStudent, data=payload)

    def edit_school_student(self, studentUid: int, studentName: str) -> Dict[str, Any]:
        """
        编辑学校学生信息

        Args:
            studentUid: 用户UID
            studentName: 学生姓名

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'studentUid': studentUid,
            'studentName': studentName
        }

        return self._make_request(self.urls.editSchoolStudent, data=payload)

    # =============== 课程相关接口 ===============

    def add_course(self, courseName: str, **kwargs) -> Dict[str, Any]:
        """
        创建课程

        Args:
            courseName: 课程名
            **kwargs: 其他参数
                folderId: 授权云盘文件夹ID
                expiryTime: 时间戳，课程有效期，默认空永久有效
                mainTeacherUid: 班主任uid，默认空
                subjectId: 课程学科分类
                allowAddFriend: 是否允许班级成员在群里互相添加好友，0=不允许，1=允许
                allowStudentModifyNickname: 是否允许学生在群里修改其班级昵称，0=不允许，1=允许
                notAllowDeleteCourseStudentReplay: 是否不允许离开班级的学生或班级解散后，可查看课程内容 0=否（允许），1=是（不允许）
                courseUniqueIdentity: 机构唯一标识

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        base_data = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseName': courseName
        }

        data = RequestUtils.prepare_request_data(base_data, **kwargs)
        return self._make_request(self.urls.addCourse, data=data)

    def edit_course(self, courseId: int, **kwargs) -> Dict[str, Any]:
        """
        编辑课程

        Args:
            courseId: 课程ID
            **kwargs: 其他参数
                courseName: 课程名
                folderId: 授权云盘文件夹ID
                expiryTime: 时间戳，课程有效期，默认空永久有效
                mainTeacherUid: 班主任uid，默认空
                subjectId: 课程学科分类
                allowAddFriend: 是否允许班级成员在群里互相添加好友，0=不允许，1=允许
                allowStudentModifyNickname: 是否允许学生在群里修改其班级昵称，0=不允许，1=允许
                notAllowDeleteCourseStudentReplay: 是否不允许离开班级的学生或班级解散后，可查看课程内容 0=否（允许），1=是（不允许）
                courseUniqueIdentity: 机构唯一标识

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        base_data = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId
        }

        data = RequestUtils.prepare_request_data(base_data, **kwargs)
        return self._make_request(self.urls.editCourse, data=data)

    def end_course(self, courseId: int) -> Dict[str, Any]:
        """
        结束课程

        Args:
            courseId: 课程ID

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
        }

        return self._make_request(self.urls.endCourse, data=payload)

    # =============== 课节相关接口 ===============

    def add_course_class(self, courseId: int, className: str, teacherUid: int, beginTime: int, endTime: int,
                         **kwargs) -> Dict[str, Any]:
        """
        创建课节

        Args:
            courseId: 课程ID
            className: 课节名称
            beginTime: 开始时间
            endTime: 结束时间
            teacherUid: 老师UID
            **kwargs: 其他参数
                assistantUids: 助教UID列表 [123,456]
                seatNum: 上台人数
                isHd: 是否高清，0=非高清，1=高清，2=全高清
                isDc: 双摄模式，是否开启副摄像头，0=不开启，3=开启全高清副摄像头
                teachMode: 教学模式，1=在线教室，2=智慧教室
                isAutoOnstage: 学生进入教室时是否自动上台 0=自动，1=不自动
                record: 录课(0 关闭，1 开启)
                recordScene: 录制现场(0 关闭，1 开启)
                live: 直播(0 关闭，1 开启)
                replay: 回放(0 关闭，1 开启)
                watchByLogin: 只允许登录ClassIn账号后才可观看，未登录不可观看，0=未开启，1=开启
                allowUnloggedChat: 允许未登录用户参与直播聊天和点赞，0=不允许，1=允许

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        base_data = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'className': className,
            'teacherUid': teacherUid,
            'beginTime': beginTime,
            'endTime': endTime
        }

        # 处理assistantUids参数
        if 'assistantUids' in kwargs and isinstance(kwargs['assistantUids'], list):
            kwargs['assistantUids'] = json.dumps(kwargs['assistantUids'])

        data = RequestUtils.prepare_request_data(base_data, **kwargs)
        return self._make_request(self.urls.addCourseClass, data=data)

    def edit_course_class(self, courseId: int, classId: int, **kwargs) -> Dict[str, Any]:
        """
        编辑课节

        Args:
            courseId: 课程ID
            classId: 课节ID
            **kwargs: 其他参数
                className: 课节名称
                beginTime: 开始时间
                endTime: 结束时间
                teacherUid: 老师UID
                assistantUids: 助教UID列表 [123,456]
                teachMode: 教学模式，1=在线教室，2=智慧教室
                isAutoOnstage: 学生进入教室时是否自动上台 0=自动，1=不自动
                record: 录课(0 关闭，1 开启)
                recordScene: 录制现场(0 关闭，1 开启)
                live: 直播(0 关闭，1 开启)
                replay: 回放(0 关闭，1 开启)
                watchByLogin: 只允许登录ClassIn账号后才可观看，未登录不可观看，0=未开启，1=开启
                allowUnloggedChat: 允许未登录用户参与直播聊天和点赞，0=不允许，1=允许

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        base_data = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'classId': classId
        }

        if 'assistantUids' in kwargs and isinstance(kwargs['assistantUids'], list):
            kwargs['assistantUids'] = json.dumps(kwargs['assistantUids'])

        data = RequestUtils.prepare_request_data(base_data, **kwargs)
        return self._make_request(self.urls.editCourseClass, data=data)

    def del_course_class(self, courseId: int, classId: int) -> Dict[str, Any]:
        """
        删除课节

        Args:
            courseId: 课程ID
            classId: 课节ID

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'classId': classId,
        }

        return self._make_request(self.urls.delCourseClass, data=payload)

    # =============== 课程学生管理接口 ===============

    def add_course_student(self, courseId: int, studentUid: int, identity: int = 1) -> Dict[str, Any]:
        """
        添加课程学生

        Args:
            courseId: 课程ID
            studentUid: 用户UID
            identity: 学生和旁听的识别(1 为学生,2 为旁听)

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'studentUid': studentUid,
            'identity': identity
        }

        return self._make_request(self.urls.addCourseStudent, data=payload)

    def add_course_student_multiple(self, courseId: int, user_list: List[Dict], identity: int = 1) -> Dict[str, Any]:
        """
        批量添加课程学生

        Args:
            courseId: 课程ID
            user_list: 用户列表，格式：[{'uid':123},{'uid':456}]
            identity: 学生和旁听的识别(1 为学生,2 为旁听)

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'identity': identity,
            'studentJson': json.dumps(user_list)
        }

        return self._make_request(self.urls.addCourseStudentMultiple, data=payload)

    def del_course_student(self, courseId: int, studentUid: int, identity: int = 1) -> Dict[str, Any]:
        """
        删除课程学生

        Args:
            courseId: 课程ID
            studentUid: 用户UID
            identity: 学生和旁听的识别(1 为学生,2 为旁听)

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'identity': identity,
            'studentUid': studentUid
        }

        return self._make_request(self.urls.delCourseStudent, data=payload)

    def del_course_student_multiple(self, courseId: int, user_list: List[int], identity: int = 1) -> Dict[str, Any]:
        """
        批量删除课程学生

        Args:
            courseId: 课程ID
            user_list: 用户UID列表，格式：['123', ..., '456']
            identity: 学生和旁听的识别(1 为学生,2 为旁听)

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'identity': identity,
            'studentUidJson': json.dumps(user_list)
        }

        return self._make_request(self.urls.delCourseStudentMultiple, data=payload)

    def add_class_student_multiple(self, courseId: int, classId: int, studentJson: List[Dict],
                                   identity: int = 1) -> Dict[str, Any]:
        """
        课节批量添加学生

        Args:
            courseId: 课程ID
            classId: 课节ID
            studentJson: 学生信息列表，格式：[{uid:123,name:xxxx}]
            identity: 学生和旁听的识别(1 为学生,2 为旁听)

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'classId': classId,
            'identity': identity,
            'studentJson': json.dumps(studentJson)
        }

        return self._make_request(self.urls.addClassStudentMultiple, data=payload)

    def del_class_student_multiple(self, courseId: int, classId: int, studentUidJson: List[int],
                                   identity: int = 1) -> Dict[str, Any]:
        """
        课节批量删除学生

        Args:
            courseId: 课程ID
            classId: 课节ID
            studentUidJson: 学生UID列表，格式：[123,456]
            identity: 学生和旁听的识别(1 为学生,2 为旁听)

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'classId': classId,
            'identity': identity,
            'studentUidJson': json.dumps(studentUidJson)
        }

        return self._make_request(self.urls.delClassStudentMultiple, data=payload)

    def modify_class_seatNum(self, courseId: int, classId: int, seatNum: int, **kwargs) -> Dict[str, Any]:
        """
        修改课节上台人数及清晰度

        Args:
            courseId: 课程ID
            classId: 课节ID
            seatNum: 上台人数
            **kwargs: 其他参数
                isHd: 是否高清(0=非高清，1=高清，2=全高清)
                isDc: 双摄模式，是否开启副摄像头，0=不开启，3=开启全高清副摄像头
        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'classId': classId,
            'seatNum': seatNum
        }
        data = RequestUtils.prepare_request_data(payload, **kwargs)
        return self._make_request(self.urls.modifyClassSeatNum, data=data)

    def modify_course_teacher(self, courseId: int, teacherUid: int) -> Dict[str, Any]:
        """
        更换课程老师

        Args:
            courseId: 课程ID
            teacherUid: 老师UID

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'teacherUid': teacherUid
        }

        return self._make_request(self.urls.modifyCourseTeacher, data=payload)

    def remove_course_teacher(self, courseId: int, teacherUid: int) -> Dict[str, Any]:
        """
        移除课程老师

        Args:
            courseId: 课程ID
            teacherUid: 老师UID

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'teacherUid': teacherUid
        }

        return self._make_request(self.urls.removeCourseTeacher, data=payload)

    # =============== 广播/录播接口 ===============

    def set_class_video_multiple(self, courseId: int, classJson: str) -> Dict[str, Any]:
        """
        课节设置录课、直播、回放（多个）

        Args:
            courseId: 课程ID
            classJson: 课节JSON字符串

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'classJson': classJson
        }

        return self._make_request(self.urls.setClassVideoMultiple, data=payload)

    def delete_class_video(self, classId: int, **kwargs) -> Dict[str, Any]:
        """
        删除单个课节视频

        Args:
            classId: 课节ID
            **kwargs: 其他参数
                fileId: 文件ID

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'classId': classId
        }
        data = RequestUtils.prepare_request_data(payload, **kwargs)
        return self._make_request(self.urls.deleteClassVideo, data=data)

    def get_webcast_url(self, courseId: int, classId: int) -> Dict[str, Any]:
        """
        获取直播URL

        Args:
            courseId: 课程ID
            classId: 课节ID

        Returns:
            Dict: 响应数据
        """
        timeStamp, safeKey = self._get_safe_key()

        payload = {
            'SID': self.SID,
            'timeStamp': timeStamp,
            'safeKey': safeKey,
            'courseId': courseId,
            'classId': classId
        }

        return self._make_request(self.urls.getWebcastUrl, data=payload)

    # =============== LMS相关接口 ===============

    def add_course_teacher(self, courseId: int, teacherUids: List[int]) -> Dict[str, Any]:
        """
        添加班级老师

        Args:
            courseId: 课程ID
            teacherUids: 老师UID列表，例如：[123, 456]

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'teacherUids': teacherUids
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.addCourseTeacher, data=json.dumps(payload), headers=headers)

    def create_unit(self, courseId: int, unitName: str, **kwargs) -> Dict[str, Any]:
        """
        创建LMS单元

        Args:
            courseId: 课程ID
            unitName: 单元名称-50字符，超出截断
            **kwargs: 其他参数
                content: 单元描述
                publishFlag: 发布状态 0=草稿,1=隐藏,2=显示

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'name': unitName,
            **kwargs
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.createUnit, data=json.dumps(payload), headers=headers)

    def update_unit(self, courseId: int, unitId: int, unitName: str, **kwargs) -> Dict[str, Any]:
        """
        编辑单元信息

        Args:
            courseId: 课程ID
            unitId: 单元ID
            unitName: 单元名称-50字符，超出截断
            **kwargs: 其他参数
                content: 单元描述
                publishFlag: 发布状态 0=草稿,1=隐藏,2=显示

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'unitId': unitId,
            'name': unitName,
            **kwargs
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.updateUnit, data=json.dumps(payload), headers=headers)

    def delete_unit(self, courseId: int, unitId: int) -> Dict[str, Any]:
        """
        删除单元

        Args:
            courseId: 课程ID
            unitId: 单元ID

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'unitId': unitId,
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.deleteUnit, data=json.dumps(payload), headers=headers)

    def move_unit(self, courseId: int, unitId: int, toUnitId: int) -> Dict[str, Any]:
        """
        移动单元下活动

        Args:
            courseId: 课程ID
            unitId: 单元ID
            toUnitId: 目标单元ID

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'unitId': unitId,
            'toUnitId': toUnitId,
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.moveUnit, data=json.dumps(payload), headers=headers)

    def release_activity(self, courseId: int, activityId: int) -> Dict[str, Any]:
        """
        发布活动

        Args:
            courseId: 课程ID
            activityId: 活动ID

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'activityId': activityId,
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.releaseActivity, data=json.dumps(payload), headers=headers)

    def delete_activity(self, courseId: int, activityId: int) -> Dict[str, Any]:
        """
        删除活动

        Args:
            courseId: 课程ID
            activityId: 活动ID

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'activityId': activityId,
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.deleteActivity, data=json.dumps(payload), headers=headers)

    def add_activity_student(self, courseId: int, activityId: int, studentUids: List[int]) -> Dict[str, Any]:
        """
        添加活动学生，包括课堂

        Args:
            courseId: 课程ID
            activityId: 活动ID
            studentUids: 学生UID列表

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'activityId': activityId,
            'studentUids': studentUids,
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.activity_addStudent, data=json.dumps(payload), headers=headers)

    def delete_activity_student(self, courseId: int, activityId: int, studentUids: List[int]) -> Dict[str, Any]:
        """
        删除活动学生，包括课堂

        Args:
            courseId: 课程ID
            activityId: 活动ID
            studentUids: 学生UID列表

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'activityId': activityId,
            'studentUids': studentUids,
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.activity_deleteStudent, data=json.dumps(payload), headers=headers)

    def create_lms_lesson(self, courseId: int, lessonName: str, teacherUid: int, startTime: int, endTime: int,
                          **kwargs) -> Dict[str, Any]:
        """
        V2创建课堂

        Args:
            courseId: 课程ID
            lessonName: 课节名称
            teacherUid: 老师UID
            startTime: 开始时间戳
            endTime: 结束时间戳
            **kwargs: 其他参数
                assistantUids: 助教UID列表，例如：[1000082,1000083]
                unitId: 单元ID
                seatNum: 上台人数，默认1V6
                isHd: 0=非高清，1=高清，2=全高清
                cameraHide: 是否隐藏坐席区，0=否（显示坐席区），1=是（隐藏坐席区）
                isAutoOnstage: 0=不自动，1=自动
                liveState: 是否直播 0=不直播 1=直播
                openState: 是否公开回放 0=不公开 1=公开
                recordState: 是否录课 0=不录课，1=录课
                recordType: 录课类型 0=录教室 1=录老师 2=两个都录
                isAllowCheck: 是否允许互相查看学习报告和评分，0=不允许 1=允许
                uniqueIdentity: 唯一标识

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'name': lessonName,
            'teacherUid': teacherUid,
            'startTime': startTime,
            'endTime': endTime,
            **kwargs
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.createClass, data=json.dumps(payload), headers=headers)

    def update_lms_lesson(self, courseId: int, activityId: int, **kwargs) -> Dict[str, Any]:
        """
        V2 编辑课堂

        Args:
            courseId: 课程ID
            activityId: 活动ID
            **kwargs: 其他参数
                unitId: 单元ID
                lessonName: 课节名称
                teacherUid: 老师UID
                assistantUids: 助教UID列表
                startTime: 开始时间戳
                endTime: 结束时间戳
                seatNum: 上台人数
                isHd: 是否高清
                cameraHide: 是否隐藏坐席区
                isAutoOnstage: 是否自动上台
                liveState: 是否直播
                openState: 是否公开回放
                recordState: 是否录课
                recordType: 录课类型
                isAllowCheck: 是否允许互相查看学习报告和评分
                uniqueIdentity: 唯一标识

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'activityId': activityId,
            **kwargs
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.updateClass, data=json.dumps(payload), headers=headers)

    # =============== 在线双师接口 ===============

    def add_newDoubleTeacher_lesson(self, mainCourseId: int, mainClassId: int,
                                    subClassJson: List[Dict]) -> Dict[str, Any]:
        """
        创建在线双师课堂

        Args:
            mainCourseId: 主课程ID
            mainClassId: 主课节ID
            subClassJson: 子课节信息列表

        Returns:
            Dict: 响应数据
        """
        payload = {
            'mainCourseId': mainCourseId,
            'mainClassId': mainClassId,
            'subClassJson': subClassJson
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.onlineDoubleTeacher_addClass, data=json.dumps(payload),
                                  headers=headers)

    def edit_newDoubleTeacher_lesson(self, courseId: int, classId: int, **kwargs) -> \
            Dict[str, Any]:
        """
        编辑在线双师课堂

        Args:
            courseId: 课程ID
            classId: 课节ID
            **kwargs: 其他参数
                className: 课节名称
                teacherUid: 老师UID
                assistantUids: 助教UID列表
                startTime: 开始时间戳
                endTime: 结束时间戳
                seatNum: 上台人数
                isHd: 是否高清
                cameraHide: 是否隐藏坐席区
                isAutoOnstage: 是否自动上台
                useCoMainRecord: 使用主课节的录课回放；1=使用，0=不使用（仅支持子课使用）
                recordState: 是否录课
                recordType: 录课类型
                liveState: 是否直播
                openState: 是否公开回放

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'classId': classId,
            **kwargs
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.onlineDoubleTeacher_editClass, data=json.dumps(payload),
                                  headers=headers)

    def del_newDoubleTeacher_lesson(self, courseId: int, classId: int) -> Dict[str, Any]:
        """
        删除在线双师课堂

        Args:
            courseId: 课程ID
            classId: 课节ID

        Returns:
            Dict: 响应数据
        """
        payload = {
            'courseId': courseId,
            'classId': classId
        }

        headers = self._create_v2_headers(payload)
        return self._make_request(self.urls.onlineDoubleTeacher_deleteClass, data=json.dumps(payload),
                                  headers=headers)

    # =============== 其他方法 ===============

    def close(self):
        """关闭会话"""
        if self.session:
            self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
