# Package data for bundled VS Code extension (.vsix).
