"""EggDB — read and query compressed .egg database files."""

from eggdb._eggdb import EggFile, open

__all__ = ["EggFile", "open"]
__version__ = "0.1.0"
