# 2026 Jan Sechovec from Revolgy and Remangu
"""Configuration management for Egnyte Desktop Client"""

import os
import json
import re
from pathlib import Path
from typing import Dict, Optional
import keyring


class Config:
    """Manages application configuration"""
    
    CONFIG_DIR = Path.home() / ".config" / "egnyte-desktop"
    CONFIG_FILE = CONFIG_DIR / "config.json"
    TOKEN_FILE = CONFIG_DIR / "tokens.json"
    
    # Default API endpoints
    API_BASE_URL = "https://{domain}.egnyte.com"
    AUTH_URL = "https://{domain}.egnyte.com/puboauth/token"
    AUTHORIZE_URL = "https://{domain}.egnyte.com/puboauth/authorize"
    
    # Rate limiting (2 QPS default)
    RATE_LIMIT_QPS = 2
    RATE_LIMIT_DAILY = 1000
    
    def __init__(self):
        """Initialize configuration"""
        self.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self._config = self._load_config()
    
    def _load_config(self) -> Dict:
        """Load configuration from file"""
        if self.CONFIG_FILE.exists():
            try:
                with open(self.CONFIG_FILE, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return {}
    
    def _save_config(self):
        """Save configuration to file"""
        with open(self.CONFIG_FILE, 'w') as f:
            json.dump(self._config, f, indent=2)
        try:
            os.chmod(self.CONFIG_FILE, 0o600)
        except Exception:
            pass
    
    def get(self, key: str, default=None):
        """Get configuration value"""
        return self._config.get(key, default)
    
    def set(self, key: str, value):
        """Set configuration value"""
        self._config[key] = value
        self._save_config()
    
    def get_domain(self) -> Optional[str]:
        """Get Egnyte domain"""
        return self.get('domain')
    
    def set_domain(self, domain: str):
        """Set Egnyte domain"""
        if not re.match(r'^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]$', domain):
            raise ValueError("Invalid domain format")
        self.set('domain', domain)
    
    def get_client_id(self) -> Optional[str]:
        """Get OAuth client ID"""
        return self.get('client_id')
    
    def set_client_id(self, client_id: str):
        """Set OAuth client ID"""
        self.set('client_id', client_id)
    
    def get_client_secret(self) -> Optional[str]:
        """Get OAuth client secret"""
        try:
            secret = keyring.get_password("egnyte-desktop", "client_secret")
            if secret:
                return secret
        except Exception:
            secret = None

        legacy_secret = self.get('client_secret')
        if legacy_secret:
            try:
                keyring.set_password("egnyte-desktop", "client_secret", legacy_secret)
                self._config.pop('client_secret', None)
                self._save_config()
            except Exception:
                return legacy_secret
            return legacy_secret

        return None
    
    def set_client_secret(self, client_secret: str):
        """Set OAuth client secret (stored securely in keyring)"""
        keyring.set_password("egnyte-desktop", "client_secret", client_secret)
        if 'client_secret' in self._config:
            self._config.pop('client_secret', None)
            self._save_config()
    
    def get_redirect_uri(self) -> str:
        """Get OAuth redirect URI
        
        Note: Egnyte requires HTTPS redirect URIs. For localhost development,
        you may need to use a tool like ngrok or manually enter the auth code.
        """
        return self.get('redirect_uri', 'https://localhost:8080/callback')
    
    def set_redirect_uri(self, redirect_uri: str):
        """Set OAuth redirect URI"""
        self.set('redirect_uri', redirect_uri)
    
    def get_sync_paths(self) -> Dict[str, str]:
        """Get configured sync paths (local -> remote)"""
        sync_paths = self.get('sync_paths', {})
        # Backwards compatibility: values may be remote string or entry dict
        result: Dict[str, str] = {}
        for local_path, value in sync_paths.items():
            if isinstance(value, dict):
                result[local_path] = value.get('remote', '')
            else:
                result[local_path] = value
        return result

    def get_sync_entries(self) -> Dict[str, Dict]:
        """Get sync entries (local -> {remote, policy})"""
        sync_paths = self.get('sync_paths', {})
        entries: Dict[str, Dict] = {}
        for local_path, value in sync_paths.items():
            if isinstance(value, dict):
                remote = value.get('remote', '')
                policy = value.get('policy', {}) or {}
            else:
                remote = value
                policy = {}
            entries[local_path] = {'remote': remote, 'policy': policy}
        return entries

    def get_sync_conflict_policy(self) -> str:
        """Get conflict policy: newest | local | remote"""
        return self.get('sync_conflict_policy', 'newest')

    def get_delete_local_on_remote_missing(self) -> bool:
        """Delete local file if removed remotely"""
        return bool(self.get('sync_delete_local_on_remote_missing', False))

    def get_delete_remote_on_local_missing(self) -> bool:
        """Delete remote file if removed locally"""
        return bool(self.get('sync_delete_remote_on_local_missing', False))
    
    def add_sync_path(self, local_path: str, remote_path: str):
        """Add a sync path"""
        sync_paths = self.get('sync_paths', {})
        sync_paths[local_path] = {'remote': remote_path, 'policy': {}}
        self.set('sync_paths', sync_paths)
    
    def remove_sync_path(self, local_path: str):
        """Remove a sync path"""
        sync_paths = self.get('sync_paths', {})
        sync_paths.pop(local_path, None)
        self.set('sync_paths', sync_paths)

    def set_sync_path_policy(self, local_path: str, policy: Dict):
        """Update policy for a sync path"""
        sync_paths = self.get('sync_paths', {})
        entry = sync_paths.get(local_path, {})
        if isinstance(entry, dict):
            entry.setdefault('remote', '')
            entry['policy'] = policy
            sync_paths[local_path] = entry
        else:
            sync_paths[local_path] = {'remote': entry, 'policy': policy}
        self.set('sync_paths', sync_paths)

