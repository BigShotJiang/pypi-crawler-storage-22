# EgoGym

EgoGym is a lightweight benchmark suite for egocentric robot policies

```python
env = gym.make(
    "Egogym-Pick-v0",           # Options: "Egogym-Pick-v0", "Egogym-Open-v0", "Egogym-Close-v0"
    robot="rum",                # Options: "rum", "droid"
    action_space="delta",       # Options: "delta", "absolute"
    num_objs=5,                 # Options: 1-5
)
```

**Actions (17-dim):**
- `[0-15]`: flattened 4x4 transformation
- `[16]`: continuous gripper (0=open, 1=close)

**Coordinate Frame:**
- **x**: Right of camera
- **y**: Up of camera
- **z**: Backward of camera
