from .robot import Robot
from .grippers import FloatingGripper, RUMGripper
from .arms import Arm, DroidArm

ROBOT_REGISTRY = {
    "rum": RUMGripper,
    "droid": DroidArm,
}

__all__ = ["Robot", "FloatingGripper", "RUMGripper", "Arm", "DroidArm", "ROBOT_REGISTRY"]