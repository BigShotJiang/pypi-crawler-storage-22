import numpy as np

from egogym.components import Object


class TexturesManager:
    def __init__(self, textures_list, np_random):
        self.textures_list = textures_list
        self.np_random = np_random
        sorted_textures = sorted(textures_list)
        self.np_random.shuffle(sorted_textures)
        self.textures_list = sorted_textures
        self.index = -1

    def sample(self, random=False):
        if random:
            index = self.np_random.integers(len(self.textures_list))
        else:
            self.index = (self.index + 1) % len(self.textures_list)
            index = self.index
        return self.textures_list[index]
