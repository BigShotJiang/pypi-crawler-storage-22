from abc import ABC, abstractmethod

class BasePolicy(ABC):
    
    def __init__(self):
        self.name = "base"
        
    @abstractmethod
    def get_action(self, obs):
        pass
    
    def reset(self):
        pass
