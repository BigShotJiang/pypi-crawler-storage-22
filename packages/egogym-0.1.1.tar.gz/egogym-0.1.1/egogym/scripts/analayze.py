import os
import sys
import re
import pandas as pd
import yaml
import webbrowser
import numpy as np
from datetime import datetime


def determine_grasp_type(gripper_pose_str):
    try:
        if isinstance(gripper_pose_str, np.ndarray):
            gripper_pose = gripper_pose_str.reshape(4, 4)
        elif isinstance(gripper_pose_str, str):
            gripper_pose = np.array(eval(gripper_pose_str)).reshape(4, 4)
        else:
            return "Unknown"
        
        z_axis = gripper_pose[:3, 2]
        z_axis = z_axis / np.linalg.norm(z_axis)
        
        down_direction = np.array([0, 0, 1])
        cos_angle = np.dot(z_axis, down_direction)
        
        if cos_angle > 0.7:
            return "Top-down"
        else:
            return "Side"
    except Exception as e:
        return "Unknown"


def analyze_logs(log_folder):
    log_file_path = os.path.join(log_folder, "log.csv")
    if not os.path.exists(log_file_path):
        log_file_path = os.path.join(log_folder, "logs.txt")
        if not os.path.exists(log_file_path):
            print(f"Log file not found: {log_file_path}")
            return

    task_name = "pick"

    analysis_folder = os.path.join(log_folder, "analysis")
    os.makedirs(analysis_folder, exist_ok=True)

    print(f"Reading logs from {log_file_path}...")
    try:
        df = pd.read_csv(log_file_path, sep="\t", on_bad_lines='skip')
    except pd.errors.ParserError as e:
        print(f"Error reading log file: {e}")
        return

    run_folder_name = os.path.basename(log_folder)
    date_str = ""

    if run_folder_name.startswith("run_") or run_folder_name.startswith("evaluation_"):
        match = re.search(r"(\d{8})|(\d{10})", run_folder_name)
        if match:
            date_raw = match.group(0)
            try:
                if len(date_raw) == 10:
                    timestamp = int(date_raw)
                    date_obj = datetime.fromtimestamp(timestamp)
                    date_str = date_obj.strftime("%Y-%m-%d")
                else:
                    year = date_raw[0:4]
                    month = date_raw[4:6]
                    day = date_raw[6:8]
                    date_str = f"{year}-{month}-{day}"
            except Exception:
                date_str = date_raw

    title = f"RUM-{task_name} Analysis {date_str}"
    
    is_open_task = task_name.lower() == "open"

    if is_open_task:

        success_rate = df["success"].mean() * 100
        threshold_text = "Opened more than 50%"
        
        def parse_joint_value(val):
            try:
                if isinstance(val, str):
                    val = val.strip('"[]')
                return float(val)
            except:
                return 0.0
        
        df["max_normalized_joint_parsed"] = df["max_normalized_joint"].apply(parse_joint_value)
        
        bins = [0, 0.1, 0.2, 0.3, 0.4, 0.5]
        hist_counts, bin_edges = np.histogram(df["max_normalized_joint_parsed"].clip(0, 0.5), bins=bins)
        histogram_data = list(zip([f"{bins[i]:.1f}-{bins[i+1]:.1f}" for i in range(len(bins)-1)], hist_counts.tolist()))
        max_count = max(hist_counts) if len(hist_counts) > 0 else 1
        
        handle_success = (
            df.groupby("handle_type")
            .apply(lambda x: x["success"].mean() * 100)
            .reset_index()
        )
        handle_success.columns = ["handle_type", "success_rate"]
        handle_success = handle_success.sort_values("success_rate", ascending=False)
        
        handle_counts = df["handle_type"].value_counts().reset_index()
        handle_counts.columns = ["handle_type", "count"]
        
        handle_data = pd.merge(handle_success, handle_counts, on="handle_type")
        
        door_type_data = None
        if "is_double_door" in df.columns:
            df["door_type"] = df["is_double_door"].apply(lambda x: "Double Door" if x else "Single Door")
            door_success = (
                df.groupby("door_type")
                .apply(lambda x: x["success"].mean() * 100)
                .reset_index()
            )
            door_success.columns = ["door_type", "success_rate"]
            door_counts = df["door_type"].value_counts().reset_index()
            door_counts.columns = ["door_type", "count"]
            door_type_data = pd.merge(door_success, door_counts, on="door_type")
        
        hinge_side_data = None
        if "hinge_side" in df.columns:
            hinge_success = (
                df.groupby("hinge_side")
                .apply(lambda x: x["success"].mean() * 100)
                .reset_index()
            )
            hinge_success.columns = ["hinge_side", "success_rate"]
            hinge_counts = df["hinge_side"].value_counts().reset_index()
            hinge_counts.columns = ["hinge_side", "count"]
            hinge_side_data = pd.merge(hinge_success, hinge_counts, on="hinge_side")
        
        html_path = os.path.join(analysis_folder, "analysis_report.html")
        results_csv = df.to_csv(index=False)
        handle_csv = handle_data.to_csv(index=False)
        
        def escape_csv_for_js(csv_str):
            return (
                csv_str.replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
            )
        
        results_csv_js = escape_csv_for_js(results_csv)
        handle_csv_js = escape_csv_for_js(handle_csv)
        
        js_script = """
        function downloadCSV(filename, csvContent) {
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', filename);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        }
        """
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>{title}</title>
            <meta charset="utf-8">
            <script>
            {js_script}
            </script>
            <style>
                body {{
                    font-family: 'Verdana', 'Arial', sans-serif;
                    margin: 20px;
                    background-color: #ffffff;
                    color: #000000;
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 10px;
                    font-size: 12px;
                    line-height: 1.3;
                }}
                .download-btn {{
                    display: inline-block;
                    padding: 1px 3px;
                    background-color: transparent;
                    color: #555;
                    font-size: 10px;
                    text-decoration: underline;
                    cursor: pointer;
                    font-weight: normal;
                    text-align: left;
                    margin-top: 2px;
                    margin-bottom: 10px;
                }}
                .download-btn:hover {{
                    color: #000;
                }}
                h1 {{
                    color: #000080;
                    font-size: 18px;
                    border-bottom: 1px solid #cccccc;
                    padding-bottom: 5px;
                    margin-top: 15px;
                }}
                h2 {{
                    color: #000080;
                    font-size: 16px;
                    margin-top: 15px;
                    border-bottom: 1px solid #eeeeee;
                    padding-bottom: 3px;
                }}
                h3 {{
                    color: #000080;
                    font-size: 14px;
                    margin-top: 10px;
                }}
                .timestamp {{
                    color: #666666;
                    font-size: 11px;
                    margin-bottom: 15px;
                }}
                .success-rate {{
                    font-size: 32px;
                    font-weight: bold;
                    color: #008000;
                    text-align: center;
                    margin: 15px 0;
                }}
                .threshold {{
                    text-align: center;
                    color: #666666;
                    margin-bottom: 15px;
                    font-size: 11px;
                }}
                table {{
                    border-collapse: collapse;
                    width: 100%;
                    border: 1px solid #cccccc;
                    margin: 15px 0;
                }}
                th, td {{
                    text-align: left;
                    padding: 5px;
                    border: 1px solid #cccccc;
                    font-size: 12px;
                }}
                th {{
                    background-color: #eeeeee;
                }}
                ul {{
                    margin: 10px 0;
                    padding-left: 20px;
                    list-style-type: square;
                }}
                li {{
                    margin-bottom: 5px;
                }}
                .info-box {{
                    border: 1px solid #cccccc;
                    background-color: #f5f5f5;
                    padding: 10px;
                    margin: 15px 0;
                }}
                .section {{
                    margin-bottom: 20px;
                }}
                .histogram {{
                    display: flex;
                    align-items: flex-end;
                    height: 120px;
                    gap: 8px;
                    padding: 10px 20px;
                }}
                .histogram-bar-label {{
                    text-align: center;
                    font-size: 10px;
                    margin-top: 5px;
                    color: #333;
                }}
                .histogram-bar-count {{
                    text-align: center;
                    font-size: 10px;
                    margin-bottom: 3px;
                    color: #333;
                    font-weight: bold;
                }}
                .histogram-container {{
                    margin: 20px 0;
                }}
                .histogram-title {{
                    text-align: center;
                    margin-top: 15px;
                    font-size: 11px;
                    color: #666;
                }}
                .histogram-bar-wrapper {{
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    flex: 1;
                }}
                .histogram-bar-inner {{
                    width: 100%;
                    background-color: #4a90d9;
                }}
                .histogram-bar-inner.success {{
                    background-color: #2e7d32;
                }}
            </style>
        </head>
        <body>
            <h1>{title}</h1>
            <div class="timestamp">Generated on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</div>
            
            <div class="section">
                <div class="success-rate">{success_rate:.2f}%</div>
                <div class="threshold">{threshold_text}</div>
                
                <div class="info-box">
                    <h3>Summary Statistics</h3>
                    <ul>
                        <li>Total episodes: {len(df)}</li>
                    </ul>
                </div>
            </div>
            
            <div class="section">
                <h2>Success Rate by Handle Type</h2>
                <table>
                    <tr>
                        <th>Handle Type</th>
                        <th>Success Rate (%)</th>
                        <th>Count</th>
                    </tr>
                    {"".join([f"<tr><td>{row.handle_type}</td><td>{row.success_rate:.2f}</td><td>{row['count']}</td></tr>" for _, row in handle_data.iterrows()])}
                </table>
                <span class="download-btn" onclick="downloadCSV('handle_types.csv', '{handle_csv_js}')">Save CSV</span>
            </div>
            
            {"" if door_type_data is None else f'''
            <div class="section">
                <h2>Success Rate by Door Type</h2>
                <table>
                    <tr>
                        <th>Door Type</th>
                        <th>Success Rate (%)</th>
                        <th>Count</th>
                    </tr>
                    {"".join([f"<tr><td>{row.door_type}</td><td>{row.success_rate:.2f}</td><td>{row['count']}</td></tr>" for _, row in door_type_data.iterrows()])}
                </table>
            </div>
            '''}
            
            {"" if hinge_side_data is None else f'''
            <div class="section">
                <h2>Success Rate by Hinge Side</h2>
                <table>
                    <tr>
                        <th>Hinge Side</th>
                        <th>Success Rate (%)</th>
                        <th>Count</th>
                    </tr>
                    {"".join([f"<tr><td>{row.hinge_side}</td><td>{row.success_rate:.2f}</td><td>{row['count']}</td></tr>" for _, row in hinge_side_data.iterrows()])}
                </table>
            </div>
            '''}
            
            <div class="section">
                <h2>Max Normalized Joint Distribution</h2>
                <div class="histogram-container">
                    <div class="histogram">
                        {"".join([f'<div class="histogram-bar-wrapper"><div class="histogram-bar-count">{count}</div><div class="histogram-bar-inner {"success" if float(label.split("-")[1]) >= 0.5 else ""}" style="height: {(count / max_count * 100) if max_count > 0 else 0}px; max-height: 100px;"></div><div class="histogram-bar-label">{label}</div></div>' for label, count in histogram_data])}
                    </div>
                    <div class="histogram-title">Max Normalized Joint Value (green = success at 0.5)</div>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 20px; margin-bottom: 10px;">
                <span class="download-btn" style="margin: 0; text-align: center; font-size: 12px; padding: 2px 4px;" onclick="downloadCSV('all_results.csv', '{results_csv_js}')">Download All Results as CSV</span>
            </div>
        </body>
        </html>
        """
        
        with open(html_path, "w") as f:
            f.write(html_content)
        
        print(f"HTML report generated at {html_path}")
        print("Opening report in browser...")
        webbrowser.open("file://" + os.path.abspath(html_path))
        return

    # For non-open tasks (pick, etc.)
    lift_threshold = 0.03
    lift_success = (df["max_reward"] > lift_threshold).mean() * 100

    df["object_category"] = df["object_name"].apply(
        lambda x: re.sub(r"[^a-zA-Z]", "", x)
    )

    category_success = (
        df.groupby("object_category", group_keys=False)
        .apply(lambda x: (x["max_reward"] > lift_threshold).mean() * 100, include_groups=False)
        .reset_index()
    )
    category_success.columns = ["object_category", "success_rate"]

    category_success = category_success.sort_values("success_rate", ascending=False)

    category_counts = df["object_category"].value_counts().reset_index()
    category_counts.columns = ["object_category", "count"]

    category_data = pd.merge(category_success, category_counts, on="object_category")
    print(f"success rate all: {lift_success:.2f}%")
    print("Determining grasp types...")
    df["grasp_type"] = df["gripper_current_position"].apply(determine_grasp_type)

    successful_df = df[df["max_reward"] > lift_threshold].copy()
    grasp_type_by_category = (
        successful_df.groupby(["object_category", "grasp_type"]).size().reset_index()
    )
    grasp_type_by_category.columns = ["object_category", "grasp_type", "count"]

    category_total = (
        grasp_type_by_category.groupby("object_category")["count"].sum().reset_index()
    )
    category_total.columns = ["object_category", "total"]

    grasp_type_by_category = pd.merge(
        grasp_type_by_category, category_total, on="object_category"
    )
    grasp_type_by_category["percentage"] = (
        grasp_type_by_category["count"] / grasp_type_by_category["total"]
    ) * 100

    grasp_pivot = grasp_type_by_category.pivot_table(
        index="object_category", columns="grasp_type", values="percentage", fill_value=0
    ).reset_index()

    category_data = pd.merge(
        category_data, grasp_pivot, on="object_category", how="left"
    )

    if "Side" not in category_data.columns:
        category_data["Side"] = 0
    if "Top-down" not in category_data.columns:
        category_data["Top-down"] = 0
    if "Unknown" not in category_data.columns:
        category_data["Unknown"] = 0

    texture_success = (
        df.groupby("texture_name", group_keys=False)
        .apply(lambda x: (x["max_reward"] > lift_threshold).mean() * 100, include_groups=False)
        .reset_index()
    )
    texture_success.columns = ["texture_name", "success_rate"]

    texture_success = texture_success.sort_values("success_rate", ascending=False)

    texture_counts = df["texture_name"].value_counts().reset_index()
    texture_counts.columns = ["texture_name", "count"]

    texture_data = pd.merge(texture_success, texture_counts, on="texture_name")

    # Add object-specific success rates (not just categories)
    object_success = (
        df.groupby("object_name", group_keys=False)
        .apply(lambda x: (x["max_reward"] > lift_threshold).mean() * 100, include_groups=False)
        .reset_index()
    )
    object_success.columns = ["object_name", "success_rate"]

    object_counts = df["object_name"].value_counts().reset_index()
    object_counts.columns = ["object_name", "count"]

    object_data = pd.merge(object_success, object_counts, on="object_name")
    object_data = object_data.sort_values("success_rate", ascending=False)

    def get_failure_mode(row):
        if row["max_reward"] > lift_threshold:
            return None

        bodies_contacted = str(row.get("grasped_bodies", ""))
        object_name = str(row.get("object_name", ""))
        grasping_object = row.get("grasping_object", False)
        is_grasping = row.get("is_grasping", False)


        if object_name in bodies_contacted:
            if grasping_object:
                return "did not lift enough"
            else:
                return "object fell/slipped"
        else:
            if "object" in bodies_contacted and is_grasping and "left" not in bodies_contacted and "right" not in bodies_contacted:
                return "picked wrong object"
            else:
                if "left" in bodies_contacted or "right" in bodies_contacted:
                    return "Empty Grasp"
                else:
                    return "did not grasp"

    df["failure_mode"] = df.apply(get_failure_mode, axis=1)

    failure_modes = {
        "Did not lift enough": 0,
        "Object grasped but slipped": 0,
        "Picked wrong object": 0,
        "Empty Grasp": 0,
        "Did not grasp": 0,
    }

    failure_condition = df["max_reward"] <= lift_threshold

    for idx, row in df[failure_condition].iterrows():
        mode = row["failure_mode"]
        if mode == "did not lift enough":
            failure_modes["Did not lift enough"] += 1
        elif mode == "object fell/slipped":
            failure_modes["Object grasped but slipped"] += 1
        elif mode == "picked wrong object":
            failure_modes["Picked wrong object"] += 1
        elif mode == "Empty Grasp":
            failure_modes["Empty Grasp"] += 1
        elif mode == "did not grasp":
            failure_modes["Did not grasp"] += 1

    failure_modes_data = pd.DataFrame(
        {
            "failure_mode": list(failure_modes.keys()),
            "count": list(failure_modes.values()),
        }
    )
    failure_modes_data = failure_modes_data.sort_values("count", ascending=False)

    # Calculate percentage of failures
    total_failures = sum(failure_modes.values())
    if total_failures > 0:
        failure_modes_data["percentage"] = (
            failure_modes_data["count"] / total_failures * 100
        )
    else:
        failure_modes_data["percentage"] = 0

    print("Texture data:")
    print(texture_data.head())
    print(f"Texture data shape: {texture_data.shape}")
    print("Failure modes:")
    print(failure_modes_data)
    html_path = os.path.join(analysis_folder, "analysis_report.html")

    # Create CSV strings for embedding in HTML
    category_csv = category_data.to_csv(index=False)
    texture_csv = texture_data.to_csv(index=False)
    failure_csv = failure_modes_data.to_csv(index=False)
    results_csv = df.to_csv(index=False)
    object_csv = object_data.to_csv(index=False)

    # Function to escape CSV data for JavaScript
    def escape_csv_for_js(csv_str):
        return (
            csv_str.replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
        )

    # Escape CSV content for JavaScript
    category_csv_js = escape_csv_for_js(category_csv)
    texture_csv_js = escape_csv_for_js(texture_csv)
    failure_csv_js = escape_csv_for_js(failure_csv)
    results_csv_js = escape_csv_for_js(results_csv)
    object_csv_js = escape_csv_for_js(object_csv)

    # JavaScript for downloading CSV
    js_script = """
    function downloadCSV(filename, csvContent) {
        // Create a blob with the CSV data
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        
        // Create a temporary URL for the blob
        const url = URL.createObjectURL(blob);
        
        // Create a temporary link element
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', filename);
        
        // Append to the body, click it, and remove it
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Clean up the URL
        URL.revokeObjectURL(url);
    }
    """

    if is_open_task:
        additional_sections = ""
        threshold_text = "Opened more than 50%"
    else:
        threshold_text = f"Lifted above {lift_threshold * 100:.0f} cm"
        additional_sections = f"""
        <div class="section">
            <h2>Failure Modes</h2>
            <table>
                <tr>
                    <th>Failure Mode</th>
                    <th>Count</th>
                    <th>Percentage of Failures</th>
                </tr>
                {"".join([f"<tr><td>{row.failure_mode}</td><td>{row['count']}</td><td>{(row['count'] / sum(failure_modes.values()) * 100):.2f}%</td></tr>" for _, row in failure_modes_data.iterrows() if sum(failure_modes.values()) > 0])}
            </table>
            <span class="download-btn" onclick="downloadCSV('failure_modes.csv', '{failure_csv_js}')">Save CSV</span>
        </div>
        
        <div class="section">
            <h2>Success Rate by Table Texture</h2>
            <table>
                <tr>
                    <th>Table Texture</th>
                    <th>Success Rate (%)</th>
                    <th>Count</th>
                </tr>
                {"".join([f"<tr><td>{row.texture_name}</td><td>{row.success_rate:.2f}</td><td>{row['count']}</td></tr>" for _, row in texture_data.iterrows()])}
            </table>
            <span class="download-btn" onclick="downloadCSV('textures.csv', '{texture_csv_js}')">Save CSV</span>
        </div>
        
        <div class="section">
            <h2>Success Rate by Object Name</h2>
            <table>
                <tr>
                    <th>Object Name</th>
                    <th>Success Rate (%)</th>
                    <th>Count</th>
                    <th>Grasp Types (%)</th>
                </tr>
                {"".join([f'<tr><td>{row.object_category}</td><td>{row.success_rate:.2f}</td><td>{row["count"]}</td><td><span style="color: {"#000000" if row.get("Top-down", 0) >= row.get("Side", 0) else "#888888"}">Top-down ({row.get("Top-down", 0):.1f})</span> / <span style="color: {"#000000" if row.get("Side", 0) >= row.get("Top-down", 0) else "#888888"}">Side ({row.get("Side", 0):.1f})</span></td></tr>' for _, row in category_data.iterrows()])}
            </table>
            <span class="download-btn" onclick="downloadCSV('object_categories.csv', '{category_csv_js}')">Save CSV</span>
        </div>
        
        <div class="section">
            <h2>Success Rate by Individual Object</h2>
            <table>
                <tr>
                    <th>Object Name</th>
                    <th>Success Rate (%)</th>
                    <th>Count</th>
                </tr>
                {"".join([f"<tr><td>{row.object_name}</td><td>{row.success_rate:.2f}</td><td>{row['count']}</td></tr>" for _, row in object_data.iterrows()])}
            </table>
            <span class="download-btn" onclick="downloadCSV('individual_objects.csv', '{object_csv_js}')">Save CSV</span>
        </div>
        """

    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>{title}</title>
        <meta charset="utf-8">
        <script>
        {js_script}
        </script>
        <style>
            body {{
                font-family: 'Verdana', 'Arial', sans-serif;
                margin: 20px;
                background-color: #ffffff;
                color: #000000;
                max-width: 800px;
                margin: 0 auto;
                padding: 10px;
                font-size: 12px;
                line-height: 1.3;
            }}
            
            .download-btn {{
                display: inline-block;
                padding: 1px 3px;
                background-color: transparent;
                color: #555;
                font-size: 10px;
                text-decoration: underline;
                cursor: pointer;
                font-weight: normal;
                text-align: left;
                margin-top: 2px;
                margin-bottom: 10px;
            }}
            
            .download-btn:hover {{
                color: #000;
            }}
            
            h1 {{
                color: #000080;
                font-size: 18px;
                border-bottom: 1px solid #cccccc;
                padding-bottom: 5px;
                margin-top: 15px;
            }}
            
            h2 {{
                color: #000080;
                font-size: 16px;
                margin-top: 15px;
                border-bottom: 1px solid #eeeeee;
                padding-bottom: 3px;
            }}
            
            h3 {{
                color: #000080;
                font-size: 14px;
                margin-top: 10px;
            }}
            
            .timestamp {{
                color: #666666;
                font-size: 11px;
                margin-bottom: 15px;
            }}
            
            .success-rate {{
                font-size: 32px;
                font-weight: bold;
                color: #008000;
                text-align: center;
                margin: 15px 0;
            }}
            
            .threshold {{
                text-align: center;
                color: #666666;
                margin-bottom: 15px;
                font-size: 11px;
            }}
            
            table {{
                border-collapse: collapse;
                width: 100%;
                border: 1px solid #cccccc;
                margin: 15px 0;
            }}
            
            th, td {{
                text-align: left;
                padding: 5px;
                border: 1px solid #cccccc;
                font-size: 12px;
            }}
            
            th {{
                background-color: #eeeeee;
            }}
            
            ul {{
                margin: 10px 0;
                padding-left: 20px;
                list-style-type: square;
            }}
            
            li {{
                margin-bottom: 5px;
            }}
            
            .info-box {{
                border: 1px solid #cccccc;
                background-color: #f5f5f5;
                padding: 10px;
                margin: 15px 0;
            }}
            
            .section {{
                margin-bottom: 20px;
            }}
        </style>
    </head>
    <body>
        <h1>{title}</h1>
        <div class="timestamp">Generated on {
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }</div>
        
        <div class="section">
            <div class="success-rate">{lift_success:.2f}%</div>
            <div class="threshold">{threshold_text}</div>
            
            <div class="info-box">
                <h3>Summary Statistics</h3>
                <ul>
                    <li>Total episodes: {len(df)}</li>
                </ul>
            </div>
        </div>
        
        {additional_sections}
        
        <div style="text-align: center; margin-top: 20px; margin-bottom: 10px;">
            <span class="download-btn" style="margin: 0; text-align: center; font-size: 12px; padding: 2px 4px;" onclick="downloadCSV('all_results.csv', '{
        results_csv_js
    }')">Download All Results as CSV</span>
        </div>
    </body>
    </html>
    """

    with open(html_path, "w") as f:
        f.write(html_content)

    print(f"HTML report generated at {html_path}")

    print("Opening report in browser...")
    webbrowser.open("file://" + os.path.abspath(html_path))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python analyze.py <log_folder>")
        sys.exit(1)

    log_folder = sys.argv[1]
    if not os.path.exists(log_folder):
        print(f"Log folder not found: {log_folder}")
        sys.exit(1)

    analyze_logs(log_folder)