
import numpy as np
import pandas as pd
import altair as alt

# Register custom font for export
alt.themes.register('custom_theme', lambda: {
    'config': {
        'title': {'font': 'Produkt'},
        'axis': {'labelFont': 'Produkt', 'titleFont': 'Produkt'},
        'legend': {'labelFont': 'Produkt', 'titleFont': 'Produkt'},
        'mark': {'font': 'Produkt'},
        'text': {'font': 'Produkt'},
    }
})
alt.themes.enable('custom_theme')

# Hardcoded data from experiments
CHECKPOINT_DATA = {
    "CAP-A": {
        "total": 5000,
        "outcomes": {
            "Success": 1001,
            "Did not lift enough": 677,
            "Object touched but not grasped": 1295,
            "Picked wrong object": 337,
            "Empty Grasp": 1690,
            "Did not grasp": 0,
        }
    },
    "CAP-B": {
        "total": 5000,
        "outcomes": {
            "Success": 1847,
            "Did not lift enough": 995,
            "Object touched but not grasped": 1213,
            "Picked wrong object": 208,
            "Empty Grasp": 737,
            "Did not grasp": 0,
        }
    },
    "CAP-C": {
        "total": 5000,
        "outcomes": {
            "Success": 3137,
            "Did not lift enough": 263,
            "Object touched but not grasped": 597,
            "Picked wrong object": 110,
            "Empty Grasp": 893,
            "Did not grasp": 0,
        }
    },
    "CAP-D": {
        "total": 5000,
        "outcomes": {
            "Success": 3994,
            "Did not lift enough": 139,
            "Object touched but not grasped": 362,
            "Picked wrong object": 59,
            "Empty Grasp": 446,
            "Did not grasp": 0,
        }
    }
}


def plot_failure_modes():
    checkpoint_order = ["CAP-A", "CAP-B", "CAP-C", "CAP-D"]
    
    # Print results to terminal
    print("\n" + "="*80)
    print("FAILURE MODE ANALYSIS BY CHECKPOINT")
    print("="*80)
    for checkpoint in checkpoint_order:
        data = CHECKPOINT_DATA[checkpoint]
        total = data["total"]
        print(f"\n{checkpoint} (n={total}):")
        print("-" * 60)
        for outcome, count in data["outcomes"].items():
            percentage = (count / total * 100) if total > 0 else 0
            print(f"  {outcome:40s}: {count:3d} ({percentage:5.1f}%)")
    print("\n" + "="*80 + "\n")
    
    outcome_order = [
        "Success",
        "Did not lift enough",
        "Object touched but not grasped",
        "Picked wrong object",
        "Empty Grasp",
        "Did not grasp",
    ]
    
    colors = {
        "Success": "#388038",  # Green
        "Did not lift enough": "#F7D45B",  # Yellow
        "Object touched but not grasped": "#66ACF7",  # Blue
        "Picked wrong object": "#F0529C",  # Pink
        "Empty Grasp": "#9B66BB",  # Purple
        "Did not grasp": "#870927",  # Dark red
    }
    
    # Calculate average percentage for each outcome to sort by size
    outcome_totals = {}
    for checkpoint in checkpoint_order:
        data = CHECKPOINT_DATA[checkpoint]
        total = data["total"] or 1
        for outcome in outcome_order:
            count = data["outcomes"].get(outcome, 0)
            percentage = count / total * 100
            if outcome not in outcome_totals:
                outcome_totals[outcome] = 0
            outcome_totals[outcome] += percentage
    
    # Sort outcomes by total percentage (largest first), excluding Success
    failure_modes = [o for o in outcome_order if o != "Success"]
    sorted_failures = sorted(failure_modes, key=lambda x: outcome_totals.get(x, 0), reverse=True)
    
    # Build stacking order: Success at bottom, then failures from largest to smallest going up
    stacking_order = ["Success"] + sorted_failures
    
    chart_data = []
    for checkpoint in checkpoint_order:
        data = CHECKPOINT_DATA[checkpoint]
        total = data["total"] or 1
        for outcome in stacking_order:
            count = data["outcomes"].get(outcome, 0)
            percentage = count / total * 100
            if percentage > 0:  # Only include non-zero values
                chart_data.append({
                    'Policy': checkpoint,
                    'Outcome': outcome,
                    'Percentage': percentage,
                    'Color': colors.get(outcome, "#999999")
                })
    
    df = pd.DataFrame(chart_data)
    
    # Get only outcomes that actually appear in the data
    outcomes_in_data = df['Outcome'].unique().tolist()
    
    # Filter stacking_order to only include outcomes present in data
    filtered_stacking_order = [o for o in stacking_order if o in outcomes_in_data]
    
    # Add sort index to control stacking order
    outcome_to_index = {outcome: i for i, outcome in enumerate(filtered_stacking_order)}
    df['sort_index'] = df['Outcome'].map(outcome_to_index)
    
    # Create color scale only for outcomes in data
    color_scale = alt.Scale(
        domain=filtered_stacking_order,
        range=[colors[o] for o in filtered_stacking_order]
    )
    
    # Create stacked bar chart
    chart = alt.Chart(df).mark_bar(
        stroke='white',
        strokeWidth=1
    ).encode(
        x=alt.X('Policy:N', title=None, axis=alt.Axis(labelFontSize=18, labelAngle=0)),
        y=alt.Y('Percentage:Q', title='Share of Episodes (%)', axis=alt.Axis(labelFontSize=18, titleFontSize=20)).scale(domain=[0, 100]),
        color=alt.Color('Outcome:N', scale=color_scale, sort=filtered_stacking_order, legend=alt.Legend(
            title=None,
            labelFontSize=16,
            symbolSize=200,
            orient="bottom",
            direction="horizontal",
            labelLimit=0,
            columns=3
        )),
        order=alt.Order('sort_index:Q'),
        tooltip=['Policy', 'Outcome', alt.Tooltip('Percentage:Q', format='.1f')]
    ).properties(
        width=400,
        height=400,
        title={
            'text': '       EgoGym-Pick Failure Modes by Policy',
            'fontSize': 22,
            'anchor': 'start',
            'dx': 60,
            'dy': -20
        },
        padding={"left": 5, "right": 5, "top": 20, "bottom": 40}
    ).configure_view(
        strokeWidth=0
    )
    
    # Save chart
    chart.save("failure_modes_by_checkpoint.html")
    chart.save("failure_modes_by_checkpoint.pdf", scale_factor=3)
    chart.save("failure_modes_by_checkpoint.png", scale_factor=3)
    print("\nPlot saved to: failure_modes_by_checkpoint.html and failure_modes_by_checkpoint.png")


if __name__ == "__main__":
    plot_failure_modes()
