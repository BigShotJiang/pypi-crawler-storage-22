#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" Constants declarations """

# These get overwritten at build time. See build.sh
VERSION = '1.2.6'
BUILD = '2328001608'
NAME = 'egos-helpers'
