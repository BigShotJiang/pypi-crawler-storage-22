# egyop

OpenVPN config hardener that converts standard UDP-based client configs into TCP 443 with `tls-crypt` to better mimic generic HTTPS traffic.

## Features
- Converts `proto udp` → `proto tcp`
- Forces remote port to `443`
- Switches `<tls-auth>` to `<tls-crypt>`
- Comments out `key-direction` and `explicit-exit-notify` where applicable

## Install
```bash
pip3 install egyop
```

## Usage
```bash
egyop /path/to/config.ovpn
```
Outputs a new file alongside the original: `*_hardened.ovpn`.

### Example
```bash
egyop /Users/you/vpn/machines_us-6.ovpn
sudo openvpn --config /Users/you/vpn/machines_us-6_hardened.ovpn
```

## CLI Flags
No extra flags needed. It validates the input path and performs the hardening steps automatically.

## Requirements
- Python 3.8+
- OpenVPN available if you plan to connect using the hardened config

## License
MIT
