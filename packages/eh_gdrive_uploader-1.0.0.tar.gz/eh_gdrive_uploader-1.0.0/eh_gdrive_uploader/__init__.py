"""EH Google Drive Uploader - Cross-platform CLI tool."""

from .gdrive_upload import main, upload_file, list_files, create_folder

__version__ = '1.0.0'
__author__ = 'Esmail Ebrahim Hamza'
__email__ = 'esmailebraheem771@gmail.com'

__all__ = ['main', 'upload_file', 'list_files', 'create_folder']
