#!/usr/bin/env python3
"""
EH Google Drive Uploader - Cross-platform CLI tool
Upload files to Google Drive with OAuth2 authentication
"""

import os
import sys
import pickle
import argparse
from pathlib import Path
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from googleapiclient.errors import HttpError

# Configuration
SCOPES = ['https://www.googleapis.com/auth/drive']
CONFIG_DIR = Path.home() / '.gdrive_uploader'
TOKEN_FILE = CONFIG_DIR / 'token.pickle'
CREDENTIALS_FILE = CONFIG_DIR / 'credentials.json'
VERSION = '1.0.0'


def ensure_config_dir():
    """Create config directory if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def get_credentials():
    """Authenticate and return credentials."""
    creds = None
    
    # Load existing token
    if TOKEN_FILE.exists():
        with open(TOKEN_FILE, 'rb') as token:
            creds = pickle.load(token)
    
    # Refresh or create new credentials
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not CREDENTIALS_FILE.exists():
                print(f"❌ Error: credentials.json not found at {CREDENTIALS_FILE}")
                print("\n📋 Setup Instructions:")
                print("1. Go to https://console.cloud.google.com/")
                print("2. Create a new project or select existing one")
                print("3. Enable Google Drive API")
                print("4. Create OAuth 2.0 credentials (Desktop application)")
                print("5. Download client configuration and save as:")
                print(f"   {CREDENTIALS_FILE}")
                sys.exit(1)
            
            try:
                flow = InstalledAppFlow.from_client_secrets_file(
                    str(CREDENTIALS_FILE), SCOPES)
                creds = flow.run_local_server(port=0)
            except Exception as e:
                if "access_denied" in str(e) or "403" in str(e):
                    print("\n" + "="*60)
                    print("❌ GOOGLE ACCESS DENIED")
                    print("="*60)
                    print("\nThis app is in 'Testing' mode. You need to:")
                    print("1. Go to https://console.cloud.google.com/")
                    print("2. Select your project")
                    print("3. APIs & Services → OAuth consent screen")
                    print("4. Under 'Test users', click 'Add users'")
                    print(f"   Add your Gmail address")
                    print("\nThen run this script again.")
                    print("="*60)
                    sys.exit(1)
                raise
            
        with open(TOKEN_FILE, 'wb') as token:
            pickle.dump(creds, token)
    
    return creds


def get_drive_service():
    """Build and return Drive service."""
    creds = get_credentials()
    return build('drive', 'v3', credentials=creds, static_discovery=False)


def upload_file(service, file_path, folder_id=None, rename=None):
    """
    Upload a single file to Google Drive.
    
    Args:
        service: Google Drive service instance
        file_path: Path to file to upload
        folder_id: Optional folder ID to upload into
        rename: Optional new name for the file
    
    Returns:
        dict: Uploaded file metadata
    """
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    
    file_metadata = {'name': rename or file_path.name}
    
    if folder_id:
        file_metadata['parents'] = [folder_id]
    
    media = MediaFileUpload(str(file_path), resumable=True)
    
    file_size = file_path.stat().st_size
    size_mb = file_size / 1024 / 1024
    print(f"📤 Uploading: {file_path.name} ({size_mb:.2f} MB)")
    
    try:
        file = service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id, name, webViewLink'
        ).execute()
        
        print(f"✅ Uploaded successfully!")
        print(f"   📄 Name: {file.get('name')}")
        print(f"   🔗 Link: {file.get('webViewLink')}")
        print(f"   🆔 ID: {file.get('id')}")
        
        return file
        
    except HttpError as e:
        print(f"❌ Upload failed: {e}")
        raise


def list_files(service, page_size=10):
    """List recent files in Drive."""
    results = service.files().list(
        pageSize=page_size,
        fields="nextPageToken, files(id, name, modifiedTime)"
    ).execute()
    
    items = results.get('files', [])
    
    if not items:
        print("No files found.")
    else:
        print("Recent files:")
        for item in items:
            mod_time = item.get('modifiedTime', 'Unknown')[:10]
            print(f"  {item['name']:<30} {mod_time} ({item['id']})")


def create_folder(service, folder_name, parent_id=None):
    """Create a folder in Google Drive."""
    metadata = {
        'name': folder_name,
        'mimeType': 'application/vnd.google-apps.folder'
    }
    
    if parent_id:
        metadata['parents'] = [parent_id]
    
    folder = service.files().create(body=metadata, fields='id, name').execute()
    print(f"📁 Created folder: {folder['name']} (ID: {folder['id']})")
    return folder


def main():
    parser = argparse.ArgumentParser(
        description='EH Google Drive Uploader - Upload files to Google Drive',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  eh-gdrive-uploader myfile.zip                 # Upload to root
  eh-gdrive-uploader myfile.zip -f FOLDER_ID    # Upload to specific folder
  eh-gdrive-uploader myfile.zip -n newname.zip  # Rename on upload
  eh-gdrive-uploader --list                     # List recent files
  eh-gdrive-uploader --setup                    # Show setup instructions
        """
    )
    
    parser.add_argument('file', nargs='?', help='File to upload')
    parser.add_argument('-f', '--folder', help='Destination folder ID')
    parser.add_argument('-n', '--name', help='Rename file on Drive')
    parser.add_argument('--list', action='store_true', help='List recent files')
    parser.add_argument('--setup', action='store_true', help='Show setup help')
    parser.add_argument('--version', action='version', version=f'%(prog)s {VERSION}')
    
    args = parser.parse_args()
    
    if args.setup:
        print(f"""
EH Google Drive Uploader v{VERSION} Setup

1. Go to https://console.cloud.google.com/
2. Create a new project (top-left dropdown)
3. Enable the Google Drive API:
   - Navigation menu → APIs & Services → Library
   - Search "Google Drive API" → Click Enable
4. Create credentials:
   - APIs & Services → Credentials
   - Create Credentials → OAuth client ID
   - Application type: Desktop application
   - Name: EH Drive Uploader
   - Download JSON
5. Create directory: {CONFIG_DIR}
6. Move downloaded file to: {CREDENTIALS_FILE}
7. Run: eh-gdrive-uploader yourfile.zip

First run opens browser for authorization.
Token saved automatically for subsequent runs.
        """)
        return
    
    ensure_config_dir()
    service = get_drive_service()
    
    if args.list:
        list_files(service)
        return
    
    if not args.file:
        parser.print_help()
        sys.exit(1)
    
    try:
        upload_file(service, args.file, args.folder, args.name)
    except KeyboardInterrupt:
        print("\n\n⚠️ Upload cancelled by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
