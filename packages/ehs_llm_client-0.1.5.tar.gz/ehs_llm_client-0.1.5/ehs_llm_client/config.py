import os
import configparser
from typing import Any
from .exceptions import LLMConfigError


def load_llm_config(
    section_name: str,
    config_file_path: str | None = None,
    config_dict: dict | None = None,
) -> dict[str, Any]:
    """
    Load LLM configuration from:
      1. Explicit config dict
      2. Explicit config file path
      3. Environment variables fallback
    """

    parser = configparser.ConfigParser()

    if config_dict:
        parser.read_dict(config_dict)

    elif config_file_path:
        if not os.path.exists(config_file_path):
            raise LLMConfigError(f"Config file not found: {config_file_path}")
        parser.read(config_file_path)

    else:
        # ENV fallback (minimal but safe)
        provider = os.getenv("LLM_PROVIDER")
        model = os.getenv("LLM_MODEL")

        if not provider or not model:
            raise LLMConfigError(
                "No config provided. Set config_file_path, config dict, "
                "or env vars LLM_PROVIDER and LLM_MODEL."
            )

        return {
            "provider": provider,
            "model": model,
            "model_batch": os.getenv("LLM_MODEL_BATCH"),
            "base_url": os.getenv("LLM_BASE_URL"),
            "api_version": os.getenv("LLM_API_VERSION"),
        }

    if not parser.has_section(section_name):
        raise LLMConfigError(f"Config section '{section_name}' not found")

    defaults = (
        dict(parser.items("default_settings"))
        if parser.has_section("default_settings")
        else {}
    )

    section = dict(parser.items(section_name))

    return {**defaults, **section}
