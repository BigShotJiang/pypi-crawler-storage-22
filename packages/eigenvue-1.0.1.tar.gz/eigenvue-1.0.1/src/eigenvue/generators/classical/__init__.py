"""Classical algorithm generators."""
