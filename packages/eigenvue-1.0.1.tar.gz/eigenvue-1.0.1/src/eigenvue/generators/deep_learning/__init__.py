"""Deep learning algorithm generators."""
