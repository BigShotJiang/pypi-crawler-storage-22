"""
Detection heads for object detection tasks.
Implements YOLO-style detection head that works with adapter networks.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import logging

logger = logging.getLogger(__name__)


class YOLODetectionHead(nn.Module):
    """
    YOLO-style detection head for object detection.

    Predicts bounding boxes, objectness scores, and class probabilities on a grid.
    Each grid cell can predict multiple anchors.

    Output format: [batch, num_anchors * (5 + num_classes), H, W]
    where 5 = (x, y, w, h, objectness)
    """

    def __init__(self, in_channels, num_classes, num_anchors=3, grid_size=7):
        """
        Args:
            in_channels: Number of input channels from backbone/adapter
            num_classes: Number of object classes
            num_anchors: Number of anchor boxes per grid cell
            grid_size: Size of prediction grid (e.g., 7 means 7x7 grid)
        """
        super(YOLODetectionHead, self).__init__()

        self.in_channels = in_channels
        self.num_classes = num_classes
        self.num_anchors = num_anchors
        self.grid_size = grid_size

        # Number of predictions per anchor: 4 (bbox) + 1 (objectness) + num_classes
        self.num_predictions = 5 + num_classes

        # Detection layers
        # Reduce channels first for efficiency
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels, 512, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.1, inplace=True)
        )

        self.conv2 = nn.Sequential(
            nn.Conv2d(512, 256, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.1, inplace=True)
        )

        # Final prediction layer
        self.pred_conv = nn.Conv2d(
            256,
            num_anchors * self.num_predictions,
            kernel_size=1
        )

        # Adaptive pooling to ensure output is correct grid size
        self.adaptive_pool = nn.AdaptiveAvgPool2d((grid_size, grid_size))

        self._initialize_weights()

        logger.info(f"YOLODetectionHead initialized: {num_anchors} anchors, "
                   f"{num_classes} classes, {grid_size}x{grid_size} grid")

    def _initialize_weights(self):
        """Initialize weights for detection head."""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        """
        Args:
            x: Input features of shape (batch, in_channels, H, W)

        Returns:
            predictions: Tensor of shape (batch, num_anchors, grid_size, grid_size, 5 + num_classes)
                where last dim is [x, y, w, h, objectness, class_probs...]
        """
        # Apply detection layers
        x = self.conv1(x)
        x = self.conv2(x)

        # Ensure correct spatial size
        if x.size(2) != self.grid_size or x.size(3) != self.grid_size:
            x = F.interpolate(x, size=(self.grid_size, self.grid_size),
                            mode='bilinear', align_corners=False)

        # Prediction layer
        predictions = self.pred_conv(x)

        # Reshape: [batch, num_anchors * predictions, H, W]
        #       -> [batch, num_anchors, predictions, H, W]
        #       -> [batch, num_anchors, H, W, predictions]
        batch_size = predictions.size(0)
        predictions = predictions.view(
            batch_size,
            self.num_anchors,
            self.num_predictions,
            self.grid_size,
            self.grid_size
        )
        predictions = predictions.permute(0, 1, 3, 4, 2).contiguous()

        # predictions shape: [batch, num_anchors, grid_size, grid_size, 5 + num_classes]
        return predictions


class MultiScaleDetectionHead(nn.Module):
    """
    Multi-scale detection head with predictions at multiple resolutions.
    Similar to YOLOv3/v4 multi-scale approach.
    """

    def __init__(self, in_channels, num_classes, num_anchors=3, grid_sizes=[7, 14]):
        """
        Args:
            in_channels: Number of input channels from backbone/adapter
            num_classes: Number of object classes
            num_anchors: Number of anchor boxes per grid cell
            grid_sizes: List of grid sizes for multi-scale predictions
        """
        super(MultiScaleDetectionHead, self).__init__()

        self.in_channels = in_channels
        self.num_classes = num_classes
        self.num_anchors = num_anchors
        self.grid_sizes = grid_sizes

        # Create detection head for each scale
        self.detection_heads = nn.ModuleList([
            YOLODetectionHead(in_channels, num_classes, num_anchors, grid_size)
            for grid_size in grid_sizes
        ])

        logger.info(f"MultiScaleDetectionHead initialized with scales: {grid_sizes}")

    def forward(self, x):
        """
        Args:
            x: Input features of shape (batch, in_channels, H, W)

        Returns:
            predictions: List of tensors, one per scale
                Each tensor has shape [batch, num_anchors, grid_size, grid_size, 5 + num_classes]
        """
        predictions = []
        for head in self.detection_heads:
            pred = head(x)
            predictions.append(pred)

        return predictions


def decode_predictions(predictions, conf_threshold=0.5, grid_size=7):
    """
    Decode raw predictions to actual bounding boxes.

    Args:
        predictions: Tensor of shape [batch, num_anchors, grid_size, grid_size, 5 + num_classes]
        conf_threshold: Confidence threshold for filtering predictions
        grid_size: Size of the prediction grid

    Returns:
        boxes: List of tensors, one per image in batch
            Each tensor has shape [N, 4] with boxes in format [x_center, y_center, w, h] (normalized)
        scores: List of tensors, one per image
            Each tensor has shape [N] with objectness * class_prob scores
        labels: List of tensors, one per image
            Each tensor has shape [N] with predicted class indices
    """
    batch_size = predictions.size(0)
    num_anchors = predictions.size(1)

    # Apply sigmoid to objectness and class predictions
    # predictions[..., :4] are bbox coords (will apply sigmoid)
    # predictions[..., 4] is objectness
    # predictions[..., 5:] are class logits

    pred_boxes = torch.sigmoid(predictions[..., :4])  # [batch, anchors, H, W, 4]
    pred_obj = torch.sigmoid(predictions[..., 4])     # [batch, anchors, H, W]
    pred_cls = predictions[..., 5:]                    # [batch, anchors, H, W, num_classes]

    # Apply softmax to class predictions
    pred_cls = F.softmax(pred_cls, dim=-1)

    # Get class scores and labels
    class_scores, class_labels = torch.max(pred_cls, dim=-1)  # [batch, anchors, H, W]

    # Combine objectness and class confidence
    confidence = pred_obj * class_scores  # [batch, anchors, H, W]

    # Decode boxes for each image in batch
    batch_boxes = []
    batch_scores = []
    batch_labels = []

    for b in range(batch_size):
        # Get predictions above threshold
        mask = confidence[b] > conf_threshold

        if mask.sum() == 0:
            # No detections
            batch_boxes.append(torch.zeros((0, 4), device=predictions.device))
            batch_scores.append(torch.zeros((0,), device=predictions.device))
            batch_labels.append(torch.zeros((0,), dtype=torch.long, device=predictions.device))
            continue

        # Get valid predictions
        valid_boxes = pred_boxes[b][mask]  # [N, 4]
        valid_scores = confidence[b][mask]  # [N]
        valid_labels = class_labels[b][mask]  # [N]

        # Convert grid-relative coordinates to image-relative
        # Note: pred_boxes are already in [0, 1] range due to sigmoid
        # They represent offsets within grid cells, so we need to adjust

        batch_boxes.append(valid_boxes)
        batch_scores.append(valid_scores)
        batch_labels.append(valid_labels)

    return batch_boxes, batch_scores, batch_labels


def non_max_suppression(boxes, scores, labels, iou_threshold=0.4):
    """
    Apply Non-Maximum Suppression to remove duplicate detections.

    Args:
        boxes: Tensor of shape [N, 4] in format [x_center, y_center, w, h]
        scores: Tensor of shape [N]
        labels: Tensor of shape [N]
        iou_threshold: IoU threshold for NMS

    Returns:
        keep_indices: Tensor of indices to keep
    """
    if len(boxes) == 0:
        return torch.tensor([], dtype=torch.long, device=boxes.device)

    # Convert center format to corner format for NMS
    # [x_center, y_center, w, h] -> [x1, y1, x2, y2]
    x_center, y_center, w, h = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    x1 = x_center - w / 2
    y1 = y_center - h / 2
    x2 = x_center + w / 2
    y2 = y_center + h / 2
    boxes_corners = torch.stack([x1, y1, x2, y2], dim=1)

    # Apply NMS per class
    keep_indices = []
    unique_labels = labels.unique()

    for label in unique_labels:
        label_mask = labels == label
        label_boxes = boxes_corners[label_mask]
        label_scores = scores[label_mask]
        label_indices = torch.where(label_mask)[0]

        # Use torchvision NMS
        keep = torch.ops.torchvision.nms(label_boxes, label_scores, iou_threshold)
        keep_indices.append(label_indices[keep])

    if len(keep_indices) > 0:
        keep_indices = torch.cat(keep_indices)
    else:
        keep_indices = torch.tensor([], dtype=torch.long, device=boxes.device)

    return keep_indices


def build_detection_head(head_type, in_channels, num_classes, **kwargs):
    """
    Factory function to build detection head.

    Args:
        head_type: Type of detection head ('yolo' or 'multiscale')
        in_channels: Number of input channels
        num_classes: Number of object classes
        **kwargs: Additional arguments for the head

    Returns:
        Detection head module
    """
    if head_type == 'yolo':
        return YOLODetectionHead(
            in_channels=in_channels,
            num_classes=num_classes,
            num_anchors=kwargs.get('num_anchors', 3),
            grid_size=kwargs.get('grid_size', 7)
        )
    elif head_type == 'multiscale':
        return MultiScaleDetectionHead(
            in_channels=in_channels,
            num_classes=num_classes,
            num_anchors=kwargs.get('num_anchors', 3),
            grid_sizes=kwargs.get('grid_sizes', [7, 14])
        )
    else:
        raise ValueError(f"Unknown detection head type: {head_type}")
