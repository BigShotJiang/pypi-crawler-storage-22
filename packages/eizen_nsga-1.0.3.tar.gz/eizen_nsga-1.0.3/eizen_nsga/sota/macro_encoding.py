# Macro Search Space Encoding for YOLO Adapter
# Search for connectivity pattern in phases (Genetic CNN style)
# Based on NSGA-Net reference implementation

import numpy as np
from collections import namedtuple

# MacroGenotype: List of DAG matrices per phase
MacroGenotype = namedtuple('MacroGenotype', 'ops')

def phase_dencode(phase_bit_string):
    """
    Convert flat connectivity bits to adjacency structure.
    Returns a list of lists where genome[i] contains connections for node i.
    """
    # Calculate number of nodes from bit length
    # Length L = n*(n+1)/2 + 1
    # 2*L = n^2 + n + 2
    # n^2 + n + (2 - 2L) = 0
    # n = (-1 + sqrt(1 - 4(2-2L)))/2 = (-1 + sqrt(8L - 7))/2
    # This formula from reference: n = int(np.sqrt(2 * len(phase_bit_string) - 7/4) - 1/2) 
    # seems to correspond to L = n(n+1)/2 + 1.
    
    n = int(np.sqrt(2 * len(phase_bit_string) - 7/4) - 1/2)
    genome = []
    
    # For each node i (0 to n-1)
    for i in range(n):
        operator = []
        # Check connections from all previous nodes 0 to i
        # Triangular number indexing
        for j in range(i + 1):
            idx = int(i * (i + 1) / 2 + j)
            operator.append(phase_bit_string[idx])
        genome.append(operator)
        
    # Last bit is residual skip for the whole phase
    genome.append([phase_bit_string[-1]])
    return genome


def convert(bit_string, n_phases=3):
    """
    Convert flat integer array to list of phase bit-strings
    """
    # Assumes bit_string is a np array
    if bit_string.shape[0] % n_phases != 0:
        # If mismatch (e.g. during initialization before bound setup fix), try to infer
        n_phases = len(bit_string) // (len(bit_string) // n_phases)
        
    phase_length = bit_string.shape[0] // n_phases
    genome = []
    for i in range(0, bit_string.shape[0], phase_length):
        sub_genome = bit_string[i:i+phase_length]
        genome.append(sub_genome.tolist())

    return genome


def decode(genome):
    """
    Decode list of phase bit-strings into Genotype structure (adjacency lists)
    """
    genotype = []
    for gene in genome:
        genotype.append(phase_dencode(gene))

    return MacroGenotype(ops=genotype)


def get_search_space_bounds(n_nodes=4, n_phases=3):
    """
    Get bounds for macro search space (Binary encoding)
    
    Args:
        n_nodes: number of nodes inside each phase
        n_phases: number of phases to stack
        
    Returns:
        n_var: number of bits
        lb: lower bounds (all 0)
        ub: upper bounds (all 1)
    """
    # Calculate bits per phase
    # n_nodes nodes. 
    # Node 1 inputs: 1 bit (from Input)
    # Node 2 inputs: 2 bits (from Input, Node 1)
    # ...
    # Node n inputs: n bits
    # Total connection bits = n*(n+1)/2
    # Plus 1 bit for global skip connection
    
    bits_per_phase = int(n_nodes * (n_nodes + 1) / 2 + 1)
    n_var = bits_per_phase * n_phases
    
    lb = np.zeros(n_var)
    ub = np.ones(n_var) # Binary encoding
    
    return n_var, lb, ub

