# Macro Adapter Models for YOLO Fine-tuning
# Stack of phases with Genetic CNN style connectivity
# Based on NSGA-Net reference implementation

import torch
import torch.nn as nn
from .micro_operations import Identity

class ResidualNode(nn.Module):
    """
    Basic computation unit: Conv -> BN -> ReLU
    """
    def __init__(self, in_channels, out_channels, stride=1,
                 kernel_size=3, padding=1, bias=False):
        super(ResidualNode, self).__init__()
        self.model = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=bias),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.model(x)


class ResidualPhase(nn.Module):
    """
    Residual Genome Phase (One DAG-structured block)
    """
    def __init__(self, gene, in_channels, out_channels, idx):
        """
        Args:
            gene: list of lists describing connectivity (from phase_dencode)
            in_channels: input channels
            out_channels: output channels
            idx: index of this phase in network
        """
        super(ResidualPhase, self).__init__()
        
        self.channel_flag = in_channels != out_channels
        # First conv adapts channels/feature map size if needed? 
        # In this simplified version, we assume stride=1.
        self.first_conv = nn.Conv2d(in_channels, out_channels, 
                                    kernel_size=1 if idx != 0 else 3, 
                                    stride=1, bias=False)
                                    
        self.dependency_graph = ResidualPhase.build_dependency_graph(gene)
        
        # Build Nodes
        nodes = []
        # Gene has n entries for n nodes.
        for i in range(len(gene)-1): # Last entry is residual bit
            if len(self.dependency_graph[i + 1]) > 0:
                nodes.append(ResidualNode(out_channels, out_channels))
            else:
                nodes.append(None)
                
        self.nodes = nn.ModuleList(nodes)
        
        # Build 1x1 convs for merging dependencies
        conv1x1s = [Identity(out_channels)] + [Identity(out_channels) for _ in range(max(self.dependency_graph.keys()))]
        for node_idx, dependencies in self.dependency_graph.items():
            if len(dependencies) > 1:
                conv1x1s[node_idx] = nn.Conv2d(
                    len(dependencies) * out_channels, out_channels, kernel_size=1, bias=False)
                    
        self.processors = nn.ModuleList(conv1x1s)
        self.out = nn.Sequential(
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
        
    @staticmethod
    def build_dependency_graph(gene):
        """Builder dependency graph from genotype list"""
        graph = {}
        # Last gene element is [residual_bit]
        residual = gene[-1][0] == 1
        
        # gene structure:
        # 0: [bit] -> Node 1 inputs
        # 1: [bit, bit] -> Node 2 inputs
        # ...
        
        # Graph keys = node indices. 0 is Input. 1..N are Nodes. N+1 is Output.
        # Gene length = N (nodes) + 1 (residual bit holder ?)
        # Wait, phase_dencode returns: [ [..], [..], .. , [residual] ]
        # Length is N + 1.
        
        num_nodes = len(gene) - 1
        
        graph[1] = [] # Node 1 inputs
        
        for i in range(num_nodes):
            # i=0 -> Node 1 connection bits (from Node 0) ?
            # Wait, reference:
            # graph[i+2] = [j+1 for j ... if gene[i][j]==1]
            # This implies gene[0] describes Node 2 inputs? No.
            # Let's verify reference logic.
            pass
            
        # Re-implementing strictly following reference logic:
        # Reference: graph[1] = [] ... loop len(gene)-1 ... graph[i+2]
        # Reference gene format coming from phase_dencode:
        # [ [conn_to_node1_from_0], [conn_to_node2_from_0, conn_to_node2_from_1], ... ]
        # Wait, reference phase_dencode returns list of lists.
        
        graph[1] = [] 
        # i goes from 0 to N-1
        for i in range(len(gene) - 1):
             # Node index is i+2 because:
             # Node 0: Input
             # Node 1: Fixed? No.
             # In reference, Nodes start at 1?
             # Reference: nodes = [ResidualNode...]. nodes[0] is Node 1.
             # Input is 0.
             
             # gene[i] contains connections for Node i+1 ?
             # In phase_dencode: genome.append(operator) for i in range(n)
             # i=0: [bit] (conn from 0). This is for Node 1.
             
             # Reference build_graph:
             # graph[1] = [] ??
             # for i in range(len(gene)-1):
             #    graph[i+2] = [...]
             # This implies Node 1 has NO inputs in graph mapping?
             # Ah, `graph` stores inputs or outputs?
             # Reference comment: "adjacency list... skip connections are only listed in the receiving nodes"
             
             # But look at reference: graph[1] = []
             # Loop starts i=0. graph[2] = [j+1 ...]
             # It seems Node 1 is treated specially or implicitly connected to 0?
             # Wait, `ResidualPhase` code: 
             # outputs = [x] (index 0)
             # Loop i from 1 to len(self.nodes) + 1
             # If graph[i] is empty -> output is None?
             # If Node 1 (i=1) has graph[1]=[], then it gets None?
             # But `phase_dencode` produces input for Node 1.
             
             target_node = i + 1 # 1-based index (1..N)
             connections = []
             # gene[i] is list of bits for Node i+1.
             # j iterates 0..i.
             # j=0 is Node 0? j=1 is Node 1?
             # In phase_dencode: j goes 0..i.
             # j corresponds to source node index 0..i
             
             for j, connected in enumerate(gene[i]):
                 if connected == 1:
                     connections.append(j)
                     
             graph[target_node] = connections
             
        # Output node
        output_node_idx = len(gene)
        graph[output_node_idx] = [0] if residual else []
        
        # Repairs (Standard logic)
        # 1. No inputs -> Connect to 0
        # 2. No outputs -> Connect to Output Node
        
        all_nodes = list(range(1, num_nodes + 1))
        
        # Check inputs
        for n in all_nodes:
            if n not in graph or len(graph[n]) == 0:
                 if n not in graph: graph[n] = []
                 graph[n].append(0)
                 
        # Check outputs
        # Who connects to Output?
        # graph[output_node_idx] (initially only 0 if residual)
        
        # We need to see if node n is used by anyone (n+1 ... Output)
        for n in all_nodes:
            has_output = False
            # Check usage in subsequent nodes
            for target in range(n + 1, num_nodes + 1):
                if target in graph and n in graph[target]:
                    has_output = True
                    break
            
            # Check usage in final output
            if not has_output:
                if output_node_idx in graph and n in graph[output_node_idx]:
                    has_output = True 
            
            # If not connected to anything, connect to output
            if not has_output:
                graph[output_node_idx].append(n)
                
        # Final check: if output has no inputs, connect to 0
        if len(graph[output_node_idx]) == 0:
            graph[output_node_idx].append(0)
            
        return graph

    def forward(self, x):
        if self.channel_flag:
            x = self.first_conv(x)
            
        outputs = [x] # Node 0
        
        # Iterate through nodes 1..N
        for i in range(1, len(self.nodes) + 1):
             # Check if node exists (active)
             if self.nodes[i-1] is None:
                 outputs.append(None)
             else:
                 # Process dependencies
                 deps = self.process_dependencies(i, outputs)
                 out = self.nodes[i-1](deps)
                 outputs.append(out)
                 
        # Output node
        return self.out(self.process_dependencies(len(self.nodes) + 1, outputs))
        
    def process_dependencies(self, node_idx, outputs):
        idxs = self.dependency_graph[node_idx]
        valid_inputs = [outputs[i] for i in idxs if outputs[i] is not None]
        
        if len(valid_inputs) == 0:
            # Should be handled by repair logic, but fallback
            return torch.zeros_like(outputs[0]) 
            
        return self.processors[node_idx](torch.cat(valid_inputs, dim=1))


class MacroAdapterNetwork(nn.Module):
    """
    YOLO + Macro Adapter (DAG Implementation)
    """
    def __init__(self, genotype, backbone_name='yolov8n', num_classes=10, 
                 init_channels=None, num_cells=2, pretrained=True,
                 freeze_backbone=True, unfreeze_last_n_layers=0):
        super(MacroAdapterNetwork, self).__init__()
        
        from .model_registry import get_backbone, get_model_family
        
        self.num_classes = num_classes
        self.backbone_name = backbone_name
        
        # Load backbone
        self.backbone, backbone_channels = get_backbone(backbone_name, pretrained=pretrained)
        
        # Use backbone channels if init_channels not specified
        C = init_channels if init_channels is not None else backbone_channels
        
        # Channel adapter
        if C != backbone_channels:
            self.channel_adapter_in = nn.Sequential(
                nn.Conv2d(backbone_channels, C, 1, bias=False),
                nn.BatchNorm2d(C),
                nn.ReLU(inplace=True)
            )
        else:
            self.channel_adapter_in = nn.Identity()
            C = backbone_channels
            
        # Build Phases
        # genotype.ops is a list of lists (one per phase)
        phases = []
        current_C = C
        
        # We need to map genotype phases to num_cells.
        # If genotype has fewer phases than num_cells, we repeat?
        # Genotype from decode should have 3 phases (n_phases default).
        # We assume genotype covers the structure.
        
        for idx, gene in enumerate(genotype.ops):
            # We maintain same channels for now, or could expand
            phases.append(ResidualPhase(gene, current_C, current_C, idx))
            # Optional: Add pooling between phases if desired (like reference)
            # For now, keeping spatial dims same to match original adapter logic
            # unless user wants downsampling. user diagram shows Pooling.
            # But YOLO adapters usually attach to specific feature map.
            # We will add MaxPool if idx < len - 1
            if idx < len(genotype.ops) - 1:
                 pass # User diagram shows Pooling. But if we pool, we lose resolution.
                 # YOLO backbone feature map is usually 1/32 or 1/16.
                 # If we pool further, it might be too small.
                 # Adapters often maintain resolution.
                 # Reference uses MaxPool (32->16->8).
                 # We will skip Pooling for now to be safe, or add stride=1
                 
        self.adapter = nn.Sequential(*phases)
        
        # Global Pool & Classifier (Only for classification)
        # Global Pool & Classifier (Only for classification)
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Sequential(
            nn.Dropout(0.0),
            nn.Linear(C, num_classes)
        )
        
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False
                
    def forward(self, x):
        out = self.backbone(x)
        if isinstance(out, (list, tuple)): out = out[-1]
        
        out = self.channel_adapter_in(out)
        out = self.adapter(out)
        
        out = self.global_pool(out)
        out = out.view(out.size(0), -1)
        out = self.classifier(out)
        
        return out, None

