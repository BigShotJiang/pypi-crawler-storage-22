# Adapter Search Space Encoding for YOLO Fine-tuning
# The adapter maintains input/output dimensions (channel-preserving)
# File naming kept same as original NSGA-NET for easy tracing

import numpy as np
from collections import namedtuple

import torch
import torch.nn as nn

# Adapter Genotype - single cell that preserves dimensions
AdapterGenotype = namedtuple('AdapterGenotype', 'ops ops_concat')

# Operations that preserve spatial dimensions (stride=1, appropriate padding)
# These are designed to maintain both channel and spatial dimensions
PRIMITIVES = [
    'none',              # Zero operation (skip)
    'skip_connect',      # Identity connection
    'conv_1x1',          # 1x1 convolution (channel mixing)
    'sep_conv_3x3',      # Depthwise separable 3x3
    'sep_conv_5x5',      # Depthwise separable 5x5
    'dil_conv_3x3',      # Dilated 3x3 (dilation=2, padding=2)
    'avg_pool_3x3',      # Average pooling with padding (maintains size)
    'max_pool_3x3',      # Max pooling with padding (maintains size)
    'channel_attention', # SE-style channel attention
    'spatial_attention', # Spatial attention module
]

NUM_OPS = len(PRIMITIVES)


def convert_cell(cell_bit_string):
    """
    Convert cell bit-string to block structure
    
    Input: [3, 0, 3, 1, 3, 0, 3, 1, ...]
    Output: [[[3, 0], [3, 1]], [[3, 0], [3, 1]], ...]
    """
    tmp = [cell_bit_string[i:i + 2] for i in range(0, len(cell_bit_string), 2)]
    return [tmp[i:i + 2] for i in range(0, len(tmp), 2)]


def convert(bit_string):
    """
    Convert bit-string to adapter genome
    
    For adapter: We use a single cell (no normal/reduce distinction)
    Each block has: [op_idx, input_idx, op2_idx, input2_idx]
    
    Args:
        bit_string: flat array of integers
    
    Returns:
        genome: list of blocks, each block is [[op1, in1], [op2, in2]]
    """
    # For adapter, we treat the entire bit_string as a single cell
    genome = convert_cell(list(bit_string))
    return genome


def decode(genome):
    """
    Decode genome to AdapterGenotype
    
    Args:
        genome: list of blocks from convert()
    
    Returns:
        AdapterGenotype with operation names and concat indices
    """
    ops = []
    ops_concat = list(range(2, len(genome) + 2))  # All intermediate outputs
    
    for block in genome:
        for unit in block:
            op_idx = int(unit[0])
            input_idx = int(unit[1])
            ops.append((PRIMITIVES[op_idx], input_idx))
            # Remove used inputs from concat (outputs that are consumed internally)
            if input_idx in ops_concat:
                ops_concat.remove(input_idx)
    
    return AdapterGenotype(ops=ops, ops_concat=ops_concat)


def get_search_space_bounds(n_blocks=4):
    """
    Get the lower and upper bounds for the adapter search space
    
    Args:
        n_blocks: number of blocks in the adapter
    
    Returns:
        n_var: number of variables
        lb: lower bounds array
        ub: upper bounds array
    """
    n_var = n_blocks * 4  # Each block has 4 values: [op1, in1, op2, in2]
    lb = np.zeros(n_var)
    ub = np.zeros(n_var)
    
    h = 1
    for b in range(0, n_var, 4):
        # Operation indices (0 to NUM_OPS-1)
        ub[b] = NUM_OPS - 1      # op1
        ub[b + 1] = h            # input1: can select from previous outputs (0, 1, ..., h)
        ub[b + 2] = NUM_OPS - 1  # op2
        ub[b + 3] = h            # input2
        h += 1
    
    return n_var, lb, ub


def compare_cell(cell_string1, cell_string2):
    """Compare two cell genomes for equivalence"""
    cell_genome1 = convert_cell(cell_string1)
    cell_genome2 = convert_cell(cell_string2)
    cell1, cell2 = cell_genome1[:], cell_genome2[:]
    
    for block1 in cell1:
        for block2 in cell2:
            if block1 == block2 or block1 == block2[::-1]:
                cell2.remove(block2)
                break
    
    return len(cell2) == 0


def compare(string1, string2):
    """Check if two genomes represent the same architecture"""
    return compare_cell(string1, string2)


if __name__ == "__main__":
    # Test the encoding
    n_blocks = 4
    n_var, lb, ub = get_search_space_bounds(n_blocks)
    print(f"Number of variables: {n_var}")
    print(f"Lower bounds: {lb}")
    print(f"Upper bounds: {ub}")
    
    # Random test
    np.random.seed(42)
    bit_string = []
    h = 1
    for b in range(n_blocks):
        bit_string.extend([
            np.random.randint(0, NUM_OPS),
            np.random.randint(0, h + 1),
            np.random.randint(0, NUM_OPS),
            np.random.randint(0, h + 1)
        ])
        h += 1
    
    print(f"\nBit string: {bit_string}")
    genome = convert(bit_string)
    print(f"Genome: {genome}")
    genotype = decode(genome)
    print(f"Genotype: {genotype}")
