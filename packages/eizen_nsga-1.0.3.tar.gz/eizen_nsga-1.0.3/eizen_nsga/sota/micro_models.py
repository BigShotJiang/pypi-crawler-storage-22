# Adapter Models for YOLO Fine-tuning
# The adapter is inserted between YOLO backbone and classification head
# Input/Output dimensions are preserved

import torch
import torch.nn as nn
import numpy as np

from .micro_operations import OPS, Identity


class AdapterCell(nn.Module):
    """
    A single adapter cell that preserves input dimensions
    
    The cell consists of multiple blocks, each block having two operations
    that take inputs from previous states and sum their outputs.
    
    Similar to NASNet cell but simplified for adapter use case.
    """
    
    def __init__(self, genotype, C, affine=True):
        """
        Args:
            genotype: AdapterGenotype with ops and ops_concat
            C: number of channels (preserved throughout)
            affine: whether to use affine params in BatchNorm
        """
        super(AdapterCell, self).__init__()
        
        self.C = C
        op_names, indices = zip(*genotype.ops)
        self._concat = genotype.ops_concat
        self._compile(C, op_names, indices, affine)
    
    def _compile(self, C, op_names, indices, affine):
        """Build the operation modules"""
        assert len(op_names) == len(indices)
        self._steps = len(op_names) // 2  # Number of blocks
        self.multiplier = len(self._concat)  # Output channel multiplier
        
        self._ops = nn.ModuleList()
        for name, index in zip(op_names, indices):
            # All operations use stride=1 to preserve dimensions
            op = OPS[name](C, stride=1, affine=affine)
            self._ops.append(op)
        self._indices = list(indices)


    
    def forward(self, x, drop_prob=0.0):
        """
        Forward pass through the adapter cell
        
        Args:
            x: input tensor of shape (B, C, H, W)
            drop_prob: drop path probability for regularization
        
        Returns:
            output tensor of shape (B, C * multiplier, H, W)
            If multiplier > 1, channels are concatenated
        """
        # Initial states: s0 = s1 = input (for compatibility with NASNet structure)
        states = [x, x]
        
        # Execute each block
        for i in range(self._steps):
            h1 = states[self._indices[2 * i]]
            h2 = states[self._indices[2 * i + 1]]
            op1 = self._ops[2 * i]
            op2 = self._ops[2 * i + 1]
            
            h1 = op1(h1)
            h2 = op2(h2)
            
            # Drop path regularization
            if self.training and drop_prob > 0.:
                if not isinstance(op1, Identity):
                    h1 = self._drop_path(h1, drop_prob)
                if not isinstance(op2, Identity):
                    h2 = self._drop_path(h2, drop_prob)
            
            s = h1 + h2
            states.append(s)
        
        # Concatenate selected outputs
        out = torch.cat([states[i] for i in self._concat], dim=1)
        return out
    
    def _drop_path(self, x, drop_prob):
        """Drop path regularization"""
        if drop_prob <= 0.:
            return x
        keep_prob = 1. - drop_prob
        mask = torch.cuda.FloatTensor(x.size(0), 1, 1, 1).bernoulli_(keep_prob)
        x = x / keep_prob * mask
        return x


class ChannelReducer(nn.Module):
    """
    Reduces channel dimension back to original after concatenation
    Used when adapter cell concatenates multiple outputs
    """
    def __init__(self, C_in, C_out, affine=True):
        super(ChannelReducer, self).__init__()
        self.conv = nn.Sequential(
            nn.ReLU(inplace=False),
            nn.Conv2d(C_in, C_out, 1, bias=False),
            nn.BatchNorm2d(C_out, affine=affine)
        )
    
    def forward(self, x):
        return self.conv(x)


class YOLOAdapter(nn.Module):
    """
    Complete adapter module for YOLO fine-tuning
    
    This adapter:
    1. Takes features from YOLO backbone
    2. Processes through searched adapter cells
    3. Outputs features with same dimensions as input
    
    Architecture:
        Input (B, C, H, W) -> AdapterCell(s) -> ChannelReducer -> Output (B, C, H, W)
    """
    
    def __init__(self, genotype, in_channels, num_cells=1, affine=True):
        """
        Args:
            genotype: AdapterGenotype defining the cell architecture
            in_channels: number of input channels from YOLO backbone
            num_cells: number of adapter cells to stack
            affine: whether to use affine params in BatchNorm
        """
        super(YOLOAdapter, self).__init__()
        
        self.in_channels = in_channels
        self.num_cells = num_cells
        self.droprate = 0.0  # Can be set during training
        
        # Build adapter cells
        self.cells = nn.ModuleList()
        self.reducers = nn.ModuleList()
        
        C = in_channels
        for i in range(num_cells):
            cell = AdapterCell(genotype, C, affine=affine)
            self.cells.append(cell)
            
            # If cell concatenates multiple outputs, reduce channels back
            if cell.multiplier > 1:
                reducer = ChannelReducer(C * cell.multiplier, C, affine=affine)
                self.reducers.append(reducer)
            else:
                self.reducers.append(nn.Identity())
        
        # Optional: Add residual connection around entire adapter
        self.use_residual = True
    
    def forward(self, x):
        """
        Forward pass through the adapter
        
        Args:
            x: input features from YOLO backbone, shape (B, C, H, W)
        
        Returns:
            adapted features, shape (B, C, H, W) - same as input
        """
        identity = x
        
        out = x
        for cell, reducer in zip(self.cells, self.reducers):
            out = cell(out, self.droprate)
            out = reducer(out)
        
        # Residual connection
        if self.use_residual:
            out = out + identity
        
        return out


class YOLOWithAdapter(nn.Module):
    """
    Complete YOLO model with NAS-searched adapter
    
    Structure:
        YOLO Backbone (frozen) -> Adapter (trainable) -> YOLO Head (frozen/trainable)
    """
    
    def __init__(self, yolo_model, genotype, adapter_layer_idx=-1, 
                 num_adapter_cells=1, freeze_backbone=True, freeze_head=True):
        """
        Args:
            yolo_model: pretrained YOLO model
            genotype: AdapterGenotype for the adapter architecture
            adapter_layer_idx: which layer to insert adapter after (-1 = before head)
            num_adapter_cells: number of adapter cells to use
            freeze_backbone: whether to freeze YOLO backbone
            freeze_head: whether to freeze YOLO head
        """
        super(YOLOWithAdapter, self).__init__()
        
        self.yolo = yolo_model
        self.adapter_layer_idx = adapter_layer_idx
        self.freeze_backbone = freeze_backbone
        self.freeze_head = freeze_head
        
        # Freeze layers as specified
        if freeze_backbone:
            self._freeze_backbone()
        if freeze_head:
            self._freeze_head()
        
        # Create adapter - we'll determine channels dynamically
        # For now, placeholder - actual initialization happens in forward or setup
        self.adapter = None
        self.genotype = genotype
        self.num_adapter_cells = num_adapter_cells
        self._adapter_initialized = False
    
    def _freeze_backbone(self):
        """Freeze YOLO backbone parameters"""
        # This depends on YOLO model structure
        # For ultralytics YOLO:
        if hasattr(self.yolo, 'model'):
            for i, layer in enumerate(self.yolo.model):
                if hasattr(layer, 'parameters'):
                    for param in layer.parameters():
                        param.requires_grad = False
    
    def _freeze_head(self):
        """Freeze YOLO head parameters"""
        # Implementation depends on YOLO version
        pass
    
    def _init_adapter(self, channels):
        """Initialize adapter with correct channel dimension"""
        self.adapter = YOLOAdapter(
            self.genotype, 
            in_channels=channels,
            num_cells=self.num_adapter_cells
        )
        self._adapter_initialized = True
        
        # Move adapter to same device as model
        if next(self.yolo.parameters()).is_cuda:
            self.adapter = self.adapter.cuda()
    
    def forward(self, x):
        """
        Forward pass with adapter
        
        This is a simplified version - actual implementation depends on
        specific YOLO version (v5, v8, etc.)
        """
        # This needs to be customized based on YOLO architecture
        # Placeholder implementation:
        return self.yolo(x)
    
    def get_trainable_params(self):
        """Get only trainable parameters (adapter params)"""
        if self.adapter is not None:
            return self.adapter.parameters()
        return iter([])


class SimpleAdapterNetwork(nn.Module):
    """
    Adapter network using Ultralytics YOLO classification model as backbone
    
    Architecture:
        Input -> YOLO Backbone (frozen) -> Adapter Cells (trainable) -> YOLO Classifier
    
    The stem is replaced with the entire YOLO model (minus the last classifier layer).
    The classifier is the YOLO's own classification head.
    Adapter cells from NAS are inserted between backbone and classifier.
    """
    
    def __init__(self, genotype, in_channels=3, num_classes=10, 
                 init_channels=64, num_cells=3, yolo_model_name='yolov8n-cls.pt',
                 freeze_backbone=True, unfreeze_last_n_layers=0):
        """
        Args:
            genotype: AdapterGenotype
            in_channels: input image channels (3 for RGB) - not used, YOLO expects 3
            num_classes: number of output classes
            init_channels: initial channel dimension for adapter cells
            num_cells: number of adapter cells
            yolo_model_name: name of the YOLO classification model to load
            freeze_backbone: whether to freeze the YOLO backbone
            unfreeze_last_n_layers: number of last backbone layers to unfreeze (0 = all frozen)
            task: 'classification' or 'detection'
        """
        super(SimpleAdapterNetwork, self).__init__()
        
        self.droprate = 0.0
        self.num_classes = num_classes

        
        # Load YOLO classification model
        from ultralytics import YOLO
        yolo = YOLO(yolo_model_name)
        
        # Get the underlying PyTorch model
        # YOLO classification model structure: model.model is a Sequential
        # containing backbone layers and the final Classify layer
        yolo_model = yolo.model.model
        
        # Extract backbone (all layers except the last classifier)
        # The last layer is typically the Classify head
        self.backbone = nn.Sequential(*list(yolo_model.children())[:-1])
        
        # Get the classifier layer from YOLO
        yolo_classifier = list(yolo_model.children())[-1]
        
        # Determine the feature dimension from YOLO backbone
        # We need to run a dummy forward pass to get the output channels
        with torch.no_grad():
            dummy_input = torch.randn(1, 3, 224, 224)  # YOLO cls typically uses 224x224
            dummy_output = self.backbone(dummy_input)
            if isinstance(dummy_output, (list, tuple)):
                dummy_output = dummy_output[-1] if len(dummy_output) > 0 else dummy_output[0]
            backbone_channels = dummy_output.shape[1]
        
        # Use backbone output channels for adapter cells
        C = backbone_channels if init_channels == 64 else init_channels
        
        # Channel adapter to match backbone output to adapter cells if needed
        if C != backbone_channels:
            self.channel_adapter_in = nn.Sequential(
                nn.Conv2d(backbone_channels, C, 1, bias=False),
                nn.BatchNorm2d(C),
                nn.ReLU(inplace=True)
            )
        else:
            self.channel_adapter_in = nn.Identity()
            C = backbone_channels
        
        # Adapter cells (NAS-searched architecture)
        self.cells = nn.ModuleList()
        self.reducers = nn.ModuleList()
        
        for i in range(num_cells):
            cell = AdapterCell(genotype, C, affine=True)
            self.cells.append(cell)
            
            if cell.multiplier > 1:
                reducer = ChannelReducer(C * cell.multiplier, C, affine=True)
                self.reducers.append(reducer)
            else:
                self.reducers.append(nn.Identity())
        
        # Extract classifier components from YOLO's Classify head
        # YOLO Classify head structure: conv -> pool -> drop -> linear
        # We'll recreate a similar structure but adapt to our adapter output
        # Final classifier - use YOLO-style classifier structure
        # Final classifier - use YOLO-style classifier structure
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Sequential(
            nn.Dropout(p=0.0, inplace=True),
            nn.Linear(C, num_classes)
        )
        
        # Freeze backbone if specified
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False
            
            # Unfreeze last N layers if specified
            if unfreeze_last_n_layers > 0:
                backbone_layers = list(self.backbone.children())
                num_layers = len(backbone_layers)
                layers_to_unfreeze = backbone_layers[-unfreeze_last_n_layers:]
                
                print(f"YOLO Backbone has {num_layers} layers")
                print(f"Unfreezing last {unfreeze_last_n_layers} layers:")
                
                for i, layer in enumerate(layers_to_unfreeze):
                    layer_idx = num_layers - unfreeze_last_n_layers + i
                    print(f"  - Layer {layer_idx}: {type(layer).__name__}")
                    for param in layer.parameters():
                        param.requires_grad = True
    
    def forward(self, x):
        """Forward pass"""
        # Pass through YOLO backbone
        out = self.backbone(x)
        
        # Handle if backbone returns a list/tuple (some YOLO versions do)
        if isinstance(out, (list, tuple)):
            out = out[-1] if len(out) > 0 else out[0]
        
        # Adapt channels if needed
        out = self.channel_adapter_in(out)
        
        # Pass through adapter cells
        for cell, reducer in zip(self.cells, self.reducers):
            out = cell(out, self.droprate)
            out = reducer(out)
        
        # Global pooling and classifier
        # Global pooling and classifier
        # Global pooling and classifier
        out = self.global_pool(out)
        out = out.view(out.size(0), -1)
        out = self.classifier(out)
        
        # Return (logits, aux_logits) for compatibility with train_search
        return out, None
    
    def get_trainable_params(self):
        """Get only trainable parameters (adapter + classifier params)"""
        trainable = []
        for name, param in self.named_parameters():
            if param.requires_grad:
                trainable.append(param)
        return iter(trainable)


class GeneralAdapterNetwork(nn.Module):
    """
    General Adapter Network that supports any CNN backbone from the model registry.
    
    Supported backbones:
    - YOLOv8 (nano, small, medium, large, xlarge)
    - ResNet (18, 34, 50, 101, 152)
    - EfficientNet (B0-B7)
    - MobileNet (V2, V3-Small, V3-Large)
    - VGG (11, 13, 16, 19, with/without BatchNorm)
    - DenseNet (121, 161, 169, 201)
    """
    
    def __init__(self, genotype, backbone_name='resnet50', num_classes=10, 
                 init_channels=None, num_cells=2, pretrained=True,
                 freeze_backbone=True, unfreeze_last_n_layers=0):

        super(GeneralAdapterNetwork, self).__init__()
        
        from .model_registry import get_backbone, get_input_size, get_model_family
        
        self.droprate = 0.0
        self.num_classes = num_classes
        self.backbone_name = backbone_name
        self.backbone_family = get_model_family(backbone_name)
        self.input_size = get_input_size(backbone_name)
        
        # Load backbone from registry
        self.backbone, backbone_channels = get_backbone(backbone_name, pretrained=pretrained)
        
        print(f"Loaded backbone: {backbone_name}")
        print(f"  Family: {self.backbone_family}")
        print(f"  Output channels: {backbone_channels}")
        
        # Use backbone channels if init_channels not specified
        C = init_channels if init_channels is not None else backbone_channels
        
        # Channel adapter if needed
        if C != backbone_channels:
            self.channel_adapter_in = nn.Sequential(
                nn.Conv2d(backbone_channels, C, 1, bias=False),
                nn.BatchNorm2d(C),
                nn.ReLU(inplace=True)
            )
        else:
            self.channel_adapter_in = nn.Identity()
            C = backbone_channels
        
        # Adapter cells
        self.cells = nn.ModuleList()
        self.reducers = nn.ModuleList()
        
        for i in range(num_cells):
            cell = AdapterCell(genotype, C, affine=True)
            self.cells.append(cell)
            
            if cell.multiplier > 1:
                reducer = ChannelReducer(C * cell.multiplier, C, affine=True)
                self.reducers.append(reducer)
            else:
                self.reducers.append(nn.Identity())
        
        # Global pooling and classifier
        # Global pooling and classifier
        # Global pooling and classifier
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Sequential(
            nn.Dropout(p=0.0, inplace=True),
            nn.Linear(C, num_classes)
        )
        
        # Freeze backbone
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False
            
            if unfreeze_last_n_layers > 0:
                backbone_layers = list(self.backbone.children())
                num_layers = len(backbone_layers)
                layers_to_unfreeze = backbone_layers[-unfreeze_last_n_layers:]
                
                print(f"Backbone has {num_layers} layers")
                print(f"Unfreezing last {unfreeze_last_n_layers} layers:")
                
                for i, layer in enumerate(layers_to_unfreeze):
                    layer_idx = num_layers - unfreeze_last_n_layers + i
                    print(f"  - Layer {layer_idx}: {type(layer).__name__}")
                    for param in layer.parameters():
                        param.requires_grad = True
    
    def forward(self, x):
        out = self.backbone(x)
        
        if isinstance(out, (list, tuple)):
            out = out[-1] if len(out) > 0 else out[0]
        
        out = self.channel_adapter_in(out)
        
        for cell, reducer in zip(self.cells, self.reducers):
            out = cell(out, self.droprate)
            out = reducer(out)
        
        out = self.global_pool(out)
        out = out.view(out.size(0), -1)
        out = self.classifier(out)
        
        return out, None
    
    def get_trainable_params(self):
        trainable = []
        for name, param in self.named_parameters():
            if param.requires_grad:
                trainable.append(param)
        return iter(trainable)





def count_parameters(model):
    """Count trainable parameters in MB"""
    return sum(p.numel() for p in model.parameters() if p.requires_grad) / 1e6


if __name__ == "__main__":
    from search.micro_encoding import convert, decode, get_search_space_bounds
    
    # Test adapter model
    print("Testing Adapter Models...")
    
    # Create a random genotype
    n_blocks = 4
    n_var, lb, ub = get_search_space_bounds(n_blocks)
    
    np.random.seed(42)
    bit_string = []
    h = 1
    for b in range(n_blocks):
        bit_string.extend([
            np.random.randint(0, 12),  # NUM_OPS = 12
            np.random.randint(0, h + 1),
            np.random.randint(0, 12),
            np.random.randint(0, h + 1)
        ])
        h += 1
    
    genome = convert(bit_string)
    genotype = decode(genome)
    print(f"Genotype: {genotype}")
    
    # Test SimpleAdapterNetwork with YOLO backbone
    print("\n--- Testing SimpleAdapterNetwork with YOLO Backbone ---")
    print("Loading YOLO classification model (yolov8n-cls)...")
    model = SimpleAdapterNetwork(
        genotype, 
        in_channels=3, 
        num_classes=10, 
        init_channels=64,  # Will use backbone's output channels by default
        num_cells=2,
        yolo_model_name='yolov8n-cls.pt',
        freeze_backbone=True
    )
    
    total_params = sum(p.numel() for p in model.parameters()) / 1e6
    trainable_params = count_parameters(model)
    print(f"\nSimpleAdapterNetwork total parameters: {total_params:.4f} MB")
    print(f"SimpleAdapterNetwork trainable parameters: {trainable_params:.4f} MB")
    print(f"Frozen backbone parameters: {total_params - trainable_params:.4f} MB")
    
    # YOLO classification models typically use 224x224 input
    x = torch.randn(2, 3, 224, 224)
    out, _ = model(x)
    print(f"\nInput shape: {x.shape}")
    print(f"Output shape: {out.shape}")
    
    # Test YOLOAdapter standalone
    print("\n\nTesting YOLOAdapter standalone...")
    adapter = YOLOAdapter(genotype, in_channels=256, num_cells=1)
    adapter_input = torch.randn(2, 256, 20, 20)
    adapter_output = adapter(adapter_input)
    print(f"Adapter input shape: {adapter_input.shape}")
    print(f"Adapter output shape: {adapter_output.shape}")
    print(f"Shapes match: {adapter_input.shape == adapter_output.shape}")
