# Adapter Operations for YOLO Fine-tuning
# All operations preserve spatial dimensions (stride=1)
# Channel dimensions are also preserved (in_channels = out_channels)

import torch
import torch.nn as nn


class Identity(nn.Module):
    """Skip connection - identity mapping"""
    def __init__(self, C, stride=1, affine=True):
        super(Identity, self).__init__()
        # If stride is applied elsewhere, this just passes through
        
    def forward(self, x):
        return x


class Zero(nn.Module):
    """Zero operation - returns zeros of same shape"""
    def __init__(self, C, stride=1, affine=True):
        super(Zero, self).__init__()
        
    def forward(self, x):
        return x * 0


class ReLUConvBN(nn.Module):
    """ReLU -> Conv -> BatchNorm"""
    def __init__(self, C_in, C_out, kernel_size, stride, padding, affine=True):
        super(ReLUConvBN, self).__init__()
        self.op = nn.Sequential(
            nn.ReLU(inplace=False),
            nn.Conv2d(C_in, C_out, kernel_size, stride=stride, padding=padding, bias=False),
            nn.BatchNorm2d(C_out, affine=affine)
        )

    def forward(self, x):
        return self.op(x)


class Conv1x1(nn.Module):
    """1x1 Convolution for channel mixing"""
    def __init__(self, C, stride=1, affine=True):
        super(Conv1x1, self).__init__()
        self.op = nn.Sequential(
            nn.ReLU(inplace=False),
            nn.Conv2d(C, C, 1, stride=1, padding=0, bias=False),
            nn.BatchNorm2d(C, affine=affine)
        )

    def forward(self, x):
        return self.op(x)


class Conv3x3(nn.Module):
    """3x3 Convolution with padding=1 to preserve spatial dims"""
    def __init__(self, C, stride=1, affine=True):
        super(Conv3x3, self).__init__()
        self.op = nn.Sequential(
            nn.ReLU(inplace=False),
            nn.Conv2d(C, C, 3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(C, affine=affine)
        )

    def forward(self, x):
        return self.op(x)


class Conv5x5(nn.Module):
    """5x5 Convolution with padding=2 to preserve spatial dims"""
    def __init__(self, C, stride=1, affine=True):
        super(Conv5x5, self).__init__()
        self.op = nn.Sequential(
            nn.ReLU(inplace=False),
            nn.Conv2d(C, C, 5, stride=1, padding=2, bias=False),
            nn.BatchNorm2d(C, affine=affine)
        )

    def forward(self, x):
        return self.op(x)


class SepConv(nn.Module):
    """Depthwise Separable Convolution"""
    def __init__(self, C, kernel_size, stride=1, padding=1, affine=True):
        super(SepConv, self).__init__()
        self.op = nn.Sequential(
            nn.ReLU(inplace=False),
            # Depthwise
            nn.Conv2d(C, C, kernel_size, stride=1, padding=padding, groups=C, bias=False),
            # Pointwise
            nn.Conv2d(C, C, 1, padding=0, bias=False),
            nn.BatchNorm2d(C, affine=affine),
            nn.ReLU(inplace=False),
            # Second depthwise
            nn.Conv2d(C, C, kernel_size, stride=1, padding=padding, groups=C, bias=False),
            nn.Conv2d(C, C, 1, padding=0, bias=False),
            nn.BatchNorm2d(C, affine=affine),
        )

    def forward(self, x):
        return self.op(x)


class SepConv3x3(SepConv):
    """Depthwise Separable 3x3 Convolution"""
    def __init__(self, C, stride=1, affine=True):
        super(SepConv3x3, self).__init__(C, kernel_size=3, stride=1, padding=1, affine=affine)


class SepConv5x5(SepConv):
    """Depthwise Separable 5x5 Convolution"""
    def __init__(self, C, stride=1, affine=True):
        super(SepConv5x5, self).__init__(C, kernel_size=5, stride=1, padding=2, affine=affine)


class DilConv(nn.Module):
    """Dilated Convolution"""
    def __init__(self, C, kernel_size, stride=1, padding=2, dilation=2, affine=True):
        super(DilConv, self).__init__()
        self.op = nn.Sequential(
            nn.ReLU(inplace=False),
            nn.Conv2d(C, C, kernel_size, stride=1, padding=padding, 
                      dilation=dilation, groups=C, bias=False),
            nn.Conv2d(C, C, 1, padding=0, bias=False),
            nn.BatchNorm2d(C, affine=affine),
        )

    def forward(self, x):
        return self.op(x)


class DilConv3x3(DilConv):
    """Dilated 3x3 Convolution"""
    def __init__(self, C, stride=1, affine=True):
        super(DilConv3x3, self).__init__(C, kernel_size=3, stride=1, padding=2, dilation=2, affine=affine)


class DilConv5x5(DilConv):
    """Dilated 5x5 Convolution"""
    def __init__(self, C, stride=1, affine=True):
        super(DilConv5x5, self).__init__(C, kernel_size=5, stride=1, padding=4, dilation=2, affine=affine)


class AvgPool3x3(nn.Module):
    """Average Pooling 3x3 that preserves spatial dimensions"""
    def __init__(self, C, stride=1, affine=True):
        super(AvgPool3x3, self).__init__()
        self.op = nn.AvgPool2d(3, stride=1, padding=1, count_include_pad=False)

    def forward(self, x):
        return self.op(x)


class MaxPool3x3(nn.Module):
    """Max Pooling 3x3 that preserves spatial dimensions"""
    def __init__(self, C, stride=1, affine=True):
        super(MaxPool3x3, self).__init__()
        self.op = nn.MaxPool2d(3, stride=1, padding=1)

    def forward(self, x):
        return self.op(x)


class ChannelAttention(nn.Module):
    """
    Squeeze-and-Excitation style channel attention
    Learns channel-wise importance weights
    """
    def __init__(self, C, stride=1, affine=True, reduction=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        
        # Shared MLP
        reduced_channels = max(C // reduction, 8)
        self.fc = nn.Sequential(
            nn.Linear(C, reduced_channels, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(reduced_channels, C, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        b, c, _, _ = x.size()
        
        # Average pooling path
        avg_out = self.avg_pool(x).view(b, c)
        avg_out = self.fc(avg_out)
        
        # Max pooling path
        max_out = self.max_pool(x).view(b, c)
        max_out = self.fc(max_out)
        
        # Combine and apply attention
        attention = self.sigmoid(avg_out + max_out).view(b, c, 1, 1)
        return x * attention


class SpatialAttention(nn.Module):
    """
    CBAM-style spatial attention
    Learns spatial importance weights
    """
    def __init__(self, C, stride=1, affine=True, kernel_size=7):
        super(SpatialAttention, self).__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # Channel-wise statistics
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        
        # Concatenate and convolve
        combined = torch.cat([avg_out, max_out], dim=1)
        attention = self.sigmoid(self.conv(combined))
        
        return x * attention


# Operation dictionary mapping names to classes
OPS = {
    'none': lambda C, stride, affine: Zero(C, stride, affine),
    'skip_connect': lambda C, stride, affine: Identity(C, stride, affine),
    'conv_1x1': lambda C, stride, affine: Conv1x1(C, stride, affine),
    'conv_3x3': lambda C, stride, affine: Conv3x3(C, stride, affine),
    'conv_5x5': lambda C, stride, affine: Conv5x5(C, stride, affine),
    'sep_conv_3x3': lambda C, stride, affine: SepConv3x3(C, stride, affine),
    'sep_conv_5x5': lambda C, stride, affine: SepConv5x5(C, stride, affine),
    'dil_conv_3x3': lambda C, stride, affine: DilConv3x3(C, stride, affine),
    'dil_conv_5x5': lambda C, stride, affine: DilConv5x5(C, stride, affine),
    'avg_pool_3x3': lambda C, stride, affine: AvgPool3x3(C, stride, affine),
    'max_pool_3x3': lambda C, stride, affine: MaxPool3x3(C, stride, affine),
    'channel_attention': lambda C, stride, affine: ChannelAttention(C, stride, affine),
    'spatial_attention': lambda C, stride, affine: SpatialAttention(C, stride, affine),
}


if __name__ == "__main__":
    # Test all operations
    print("Testing all adapter operations...")
    C = 64  # Test with 64 channels
    x = torch.randn(2, C, 32, 32)  # Batch=2, C=64, H=W=32
    
    for name, op_fn in OPS.items():
        op = op_fn(C, stride=1, affine=True)
        out = op(x)
        print(f"{name:20s}: input={tuple(x.shape)} -> output={tuple(out.shape)}")
        assert out.shape == x.shape, f"Shape mismatch for {name}!"
    
    print("\nAll operations preserve dimensions correctly!")
