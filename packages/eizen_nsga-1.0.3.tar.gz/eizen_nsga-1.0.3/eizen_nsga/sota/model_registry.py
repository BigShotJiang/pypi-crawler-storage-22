"""
Model Registry for NAS Adapter Search
======================================
Registry for mapping backbone model IDs to their internal structures.
This allows the generic NAS to handle different CNN architectures.

Supported Families:
- YOLOv8 (nano, small, medium, large, xlarge)
- ResNet (18, 34, 50, 101, 152)
- EfficientNet (B0-B7)
- MobileNet (V2, V3-Small, V3-Large)
- VGG (11, 13, 16, 19, with/without BatchNorm)
- DenseNet (121, 161, 169, 201)

Usage:
    from config.model_registry import get_model_metadata, get_backbone
    
    # Get full configuration for a model
    config = get_model_metadata('resnet50')
    
    # Get backbone directly
    backbone, channels = get_backbone('resnet50', pretrained=True)
"""

import torch
import torch.nn as nn
from typing import Tuple, Dict, Any


# =========================================================================================================
# Default Configurations
# =========================================================================================================

DEFAULT_BACKBONE = {
    "pretrained": True,
    "freeze_backbone": True,
    "unfreeze_last_n_layers": 0,
}

DEFAULT_TRAINING = {
    "learning_rate": 0.025,
    "momentum": 0.9,
    "weight_decay": 3e-4,
    "optimizer": "sgd",  # Options: sgd, adamw
    "scheduler": "cosine",  # Options: cosine, step
    "grad_clip": 5.0,
}

DEFAULT_ADAPTER = {
    "num_cells": 2,
    "init_channels": None,  # None = use backbone output channels
    "drop_path_prob": 0.0,
}

DEFAULT_DATA = {
    "input_size": 224,
    "batch_size": 128,
    "num_workers": 4,
    "cutout": True,
    "cutout_length": 16,
}

DEFAULT_DETECTION = {
    "num_anchors": 3,
    "grid_size": 7,
    "anchor_scales": [[10, 13], [16, 30], [33, 23]],  # Default YOLO anchors
    "conf_threshold": 0.5,
    "nms_threshold": 0.4,
    "lambda_box": 5.0,  # Bounding box loss weight
    "lambda_obj": 1.0,  # Objectness loss weight
    "lambda_cls": 1.0,  # Classification loss weight
    "iou_mode": "giou",  # IoU loss mode: 'iou', 'giou', 'ciou'
}


# =========================================================================================================
# Model Configurations
# =========================================================================================================

MODEL_CONFIGS = {
    # ---- YOLOv8 Classification Models ----
    "yolov8n": {
        "family": "yolo",
        "type": "classification",
        "model_file": "yolov8n-cls.pt",
        "output_channels": 1280,  # Approximate, determined at runtime
        "backbone": {
            "freeze_backbone": True,
            "unfreeze_last_n_layers": 2,  # Recommended for YOLO
        },
        "data": {
            "input_size": 224,
        },
    },
    "yolov8s": {
        "family": "yolo",
        "type": "classification",
        "model_file": "yolov8s-cls.pt",
        "output_channels": 1280,
        "backbone": {
            "freeze_backbone": True,
            "unfreeze_last_n_layers": 2,
        },
        "data": {"input_size": 224},
    },
    "yolov8m": {
        "family": "yolo",
        "type": "classification",
        "model_file": "yolov8m-cls.pt",
        "output_channels": 1280,
        "backbone": {"unfreeze_last_n_layers": 2},
        "data": {"input_size": 224},
    },
    "yolov8l": {
        "family": "yolo",
        "type": "classification",
        "model_file": "yolov8l-cls.pt",
        "output_channels": 1280,
        "backbone": {"unfreeze_last_n_layers": 2},
        "data": {"input_size": 224},
    },
    "yolov8x": {
        "family": "yolo",
        "type": "classification",
        "model_file": "yolov8x-cls.pt",
        "output_channels": 1280,
        "backbone": {"unfreeze_last_n_layers": 2},
        "data": {"input_size": 224},
    },
    
    # ---- ResNet Models ----
    "resnet18": {
        "family": "resnet",
        "type": "classification",
        "output_channels": 512,
        "torchvision_name": "resnet18",
        "weights_class": "ResNet18_Weights",
        "training": {
            "learning_rate": 0.01,  # Lower LR for ResNet
        },
        "data": {"input_size": 224},
    },
    "resnet34": {
        "family": "resnet",
        "type": "classification",
        "output_channels": 512,
        "torchvision_name": "resnet34",
        "weights_class": "ResNet34_Weights",
        "data": {"input_size": 224},
    },
    "resnet50": {
        "family": "resnet",
        "type": "classification",
        "output_channels": 2048,
        "torchvision_name": "resnet50",
        "weights_class": "ResNet50_Weights",
        "adapter": {
            "init_channels": 256,  # Reduce channels for efficiency
        },
        "data": {"input_size": 224},
    },
    "resnet101": {
        "family": "resnet",
        "type": "classification",
        "output_channels": 2048,
        "torchvision_name": "resnet101",
        "weights_class": "ResNet101_Weights",
        "adapter": {"init_channels": 256},
        "data": {"input_size": 224},
    },
    "resnet152": {
        "family": "resnet",
        "type": "classification",
        "output_channels": 2048,
        "torchvision_name": "resnet152",
        "weights_class": "ResNet152_Weights",
        "adapter": {"init_channels": 256},
        "data": {"input_size": 224},
    },
    
    # ---- EfficientNet Models ----
    "efficientnet_b0": {
        "family": "efficientnet",
        "type": "classification",
        "output_channels": 1280,
        "torchvision_name": "efficientnet_b0",
        "weights_class": "EfficientNet_B0_Weights",
        "training": {"learning_rate": 0.01},
        "data": {"input_size": 224},
    },
    "efficientnet_b1": {
        "family": "efficientnet",
        "type": "classification",
        "output_channels": 1280,
        "torchvision_name": "efficientnet_b1",
        "weights_class": "EfficientNet_B1_Weights",
        "data": {"input_size": 240},
    },
    "efficientnet_b2": {
        "family": "efficientnet",
        "type": "classification",
        "output_channels": 1408,
        "torchvision_name": "efficientnet_b2",
        "weights_class": "EfficientNet_B2_Weights",
        "data": {"input_size": 260},
    },
    "efficientnet_b3": {
        "family": "efficientnet",
        "type": "classification",
        "output_channels": 1536,
        "torchvision_name": "efficientnet_b3",
        "weights_class": "EfficientNet_B3_Weights",
        "data": {"input_size": 300},
    },
    "efficientnet_b4": {
        "family": "efficientnet",
        "type": "classification",
        "output_channels": 1792,
        "torchvision_name": "efficientnet_b4",
        "weights_class": "EfficientNet_B4_Weights",
        "data": {"input_size": 380, "batch_size": 64},
    },
    "efficientnet_b5": {
        "family": "efficientnet",
        "type": "classification",
        "output_channels": 2048,
        "torchvision_name": "efficientnet_b5",
        "weights_class": "EfficientNet_B5_Weights",
        "data": {"input_size": 456, "batch_size": 32},
    },
    "efficientnet_b6": {
        "family": "efficientnet",
        "type": "classification",
        "output_channels": 2304,
        "torchvision_name": "efficientnet_b6",
        "weights_class": "EfficientNet_B6_Weights",
        "data": {"input_size": 528, "batch_size": 16},
    },
    "efficientnet_b7": {
        "family": "efficientnet",
        "type": "classification",
        "output_channels": 2560,
        "torchvision_name": "efficientnet_b7",
        "weights_class": "EfficientNet_B7_Weights",
        "data": {"input_size": 600, "batch_size": 8},
    },
    
    # ---- MobileNet Models ----
    "mobilenet_v2": {
        "family": "mobilenet",
        "type": "classification",
        "output_channels": 1280,
        "torchvision_name": "mobilenet_v2",
        "weights_class": "MobileNet_V2_Weights",
        "backbone": {"unfreeze_last_n_layers": 3},
        "data": {"input_size": 224},
    },
    "mobilenet_v3_small": {
        "family": "mobilenet",
        "type": "classification",
        "output_channels": 576,
        "torchvision_name": "mobilenet_v3_small",
        "weights_class": "MobileNet_V3_Small_Weights",
        "data": {"input_size": 224},
    },
    "mobilenet_v3_large": {
        "family": "mobilenet",
        "type": "classification",
        "output_channels": 960,
        "torchvision_name": "mobilenet_v3_large",
        "weights_class": "MobileNet_V3_Large_Weights",
        "data": {"input_size": 224},
    },
    
    # ---- VGG Models ----
    "vgg11": {
        "family": "vgg",
        "type": "classification",
        "output_channels": 512,
        "torchvision_name": "vgg11",
        "weights_class": "VGG11_Weights",
        "training": {"learning_rate": 0.01},
        "data": {"input_size": 224},
    },
    "vgg13": {
        "family": "vgg",
        "type": "classification",
        "output_channels": 512,
        "torchvision_name": "vgg13",
        "weights_class": "VGG13_Weights",
        "data": {"input_size": 224},
    },
    "vgg16": {
        "family": "vgg",
        "type": "classification",
        "output_channels": 512,
        "torchvision_name": "vgg16",
        "weights_class": "VGG16_Weights",
        "data": {"input_size": 224},
    },
    "vgg19": {
        "family": "vgg",
        "type": "classification",
        "output_channels": 512,
        "torchvision_name": "vgg19",
        "weights_class": "VGG19_Weights",
        "data": {"input_size": 224},
    },
    "vgg16_bn": {
        "family": "vgg",
        "type": "classification",
        "output_channels": 512,
        "torchvision_name": "vgg16_bn",
        "weights_class": "VGG16_BN_Weights",
        "data": {"input_size": 224},
    },
    "vgg19_bn": {
        "family": "vgg",
        "type": "classification",
        "output_channels": 512,
        "torchvision_name": "vgg19_bn",
        "weights_class": "VGG19_BN_Weights",
        "data": {"input_size": 224},
    },
    
    # ---- DenseNet Models ----
    "densenet121": {
        "family": "densenet",
        "type": "classification",
        "output_channels": 1024,
        "torchvision_name": "densenet121",
        "weights_class": "DenseNet121_Weights",
        "data": {"input_size": 224},
    },
    "densenet161": {
        "family": "densenet",
        "type": "classification",
        "output_channels": 2208,
        "torchvision_name": "densenet161",
        "weights_class": "DenseNet161_Weights",
        "adapter": {"init_channels": 256},
        "data": {"input_size": 224},
    },
    "densenet169": {
        "family": "densenet",
        "type": "classification",
        "output_channels": 1664,
        "torchvision_name": "densenet169",
        "weights_class": "DenseNet169_Weights",
        "data": {"input_size": 224},
    },
    "densenet201": {
        "family": "densenet",
        "type": "classification",
        "output_channels": 1920,
        "torchvision_name": "densenet201",
        "weights_class": "DenseNet201_Weights",
        "data": {"input_size": 224},
    },
}


# =========================================================================================================
# Backbone Loaders (Internal)
# =========================================================================================================

def _load_yolo_backbone(config: Dict, pretrained: bool = True) -> Tuple[nn.Module, int]:
    """Load YOLOv8 classification backbone."""
    from ultralytics import YOLO
    
    yolo = YOLO(config['model_file'])
    yolo_model = yolo.model.model
    backbone = nn.Sequential(*list(yolo_model.children())[:-1])
    
    # Determine actual output channels
    with torch.no_grad():
        dummy = torch.randn(1, 3, 224, 224)
        out = backbone(dummy)
        if isinstance(out, (list, tuple)):
            out = out[-1] if len(out) > 0 else out[0]
        out_channels = out.shape[1]
    
    return backbone, out_channels


def _load_torchvision_backbone(config: Dict, pretrained: bool = True) -> Tuple[nn.Module, int]:
    """Load torchvision backbone (ResNet, EfficientNet, MobileNet, VGG, DenseNet)."""
    import torchvision.models as models
    
    family = config['family']
    model_name = config['torchvision_name']
    weights_class = config['weights_class']
    out_channels = config['output_channels']
    
    # Get model function and weights
    model_fn = getattr(models, model_name)
    weights = getattr(models, weights_class).IMAGENET1K_V1 if pretrained else None
    
    model = model_fn(weights=weights)
    
    # Extract backbone based on family
    if family == 'resnet':
        backbone = nn.Sequential(*list(model.children())[:-2])
    elif family in ['efficientnet', 'mobilenet']:
        backbone = model.features
    elif family == 'vgg':
        backbone = model.features
    elif family == 'densenet':
        backbone = model.features
    else:
        raise ValueError(f"Unknown family: {family}")
    
    return backbone, out_channels


# =========================================================================================================
# Public API
# =========================================================================================================

def get_model_metadata(model_id: str) -> Dict[str, Any]:
    """
    Get full configuration for a model with defaults merged.
    
    Args:
        model_id: Model identifier (e.g., 'resnet50', 'yolov8n')
    
    Returns:
        Complete configuration dictionary with all defaults applied
    """
    if model_id not in MODEL_CONFIGS:
        raise ValueError(f"Unknown model: {model_id}. Available: {list(MODEL_CONFIGS.keys())}")
    
    metadata = MODEL_CONFIGS[model_id].copy()
    
    # Merge with defaults
    # 1. Backbone settings
    backbone_config = DEFAULT_BACKBONE.copy()
    if "backbone" in metadata:
        backbone_config.update(metadata["backbone"])
    metadata["backbone"] = backbone_config
    
    # 2. Training settings
    training_config = DEFAULT_TRAINING.copy()
    if "training" in metadata:
        training_config.update(metadata["training"])
    metadata["training"] = training_config
    
    # 3. Adapter settings
    adapter_config = DEFAULT_ADAPTER.copy()
    if "adapter" in metadata:
        adapter_config.update(metadata["adapter"])
    metadata["adapter"] = adapter_config
    
    # 4. Data settings
    data_config = DEFAULT_DATA.copy()
    if "data" in metadata:
        data_config.update(metadata["data"])
    metadata["data"] = data_config

    # 5. Detection settings
    detection_config = DEFAULT_DETECTION.copy()
    if "detection" in metadata:
        detection_config.update(metadata["detection"])
    metadata["detection"] = detection_config

    return metadata


def get_backbone(model_id: str, pretrained: bool = True) -> Tuple[nn.Module, int]:
    """
    Get a backbone model from the registry.
    
    Args:
        model_id: Model identifier (e.g., 'resnet50', 'yolov8n')
        pretrained: Whether to load pretrained weights
    
    Returns:
        backbone: nn.Module (the feature extractor)
        out_channels: int (number of output channels)
    """
    if model_id not in MODEL_CONFIGS:
        raise ValueError(f"Unknown model: {model_id}. Available: {list(MODEL_CONFIGS.keys())}")
    
    config = MODEL_CONFIGS[model_id]
    
    if config['family'] == 'yolo':
        return _load_yolo_backbone(config, pretrained)
    else:
        return _load_torchvision_backbone(config, pretrained)


def get_input_size(model_id: str) -> int:
    """Get the recommended input size for a model."""
    metadata = get_model_metadata(model_id)
    return metadata['data']['input_size']


def get_model_family(model_id: str) -> str:
    """Get the family of a model."""
    if model_id not in MODEL_CONFIGS:
        raise ValueError(f"Unknown model: {model_id}")
    return MODEL_CONFIGS[model_id]['family']


def list_available_models() -> Dict[str, list]:
    """List all available models grouped by family."""
    families = {}
    for name, config in MODEL_CONFIGS.items():
        family = config['family']
        if family not in families:
            families[family] = []
        families[family].append(name)
    return families


def list_model_names() -> list:
    """Get a flat list of all available model names."""
    return list(MODEL_CONFIGS.keys())


# =========================================================================================================
# Demo
# =========================================================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("Model Registry Demo")
    print("=" * 60)
    
    # List all models
    print("\nAvailable Models by Family:")
    print("-" * 40)
    families = list_available_models()
    for family, models in families.items():
        print(f"\n{family.upper()}:")
        for model in models:
            metadata = get_model_metadata(model)
            print(f"  - {model}")
            print(f"      Input: {metadata['data']['input_size']}x{metadata['data']['input_size']}")
            print(f"      Output channels: {metadata['output_channels']}")
    
    # Test loading a model
    print("\n" + "=" * 60)
    print("Testing Model Loading: resnet18")
    print("=" * 60)
    
    config = get_model_metadata('resnet18')
    print(f"\nFull Config:")
    for key, value in config.items():
        print(f"  {key}: {value}")
    
    print("\nLoading backbone...")
    backbone, channels = get_backbone('resnet18', pretrained=True)
    print(f"  ✓ Loaded successfully")
    print(f"  Output channels: {channels}")
    print(f"  Parameters: {sum(p.numel() for p in backbone.parameters()) / 1e6:.2f}M")
