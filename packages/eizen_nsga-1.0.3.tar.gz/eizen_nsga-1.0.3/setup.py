"""
Setup script for eizen-nsga-inference package
"""
from setuptools import setup, find_packages

setup(
    name="eizen_nsga",
    version="1.0.3",
    author="Eizen.ai Team",
    author_email="support@eizen.ai",
    description="Simple inference package for NSGA-Net trained models",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/eizen-ai/nsga-net",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "torch>=1.9.0",
        "torchvision>=0.10.0",
        "numpy>=1.19.0",
        "pillow>=8.0.0",
    ],
    extras_require={
        "sota": ["ultralytics>=8.0.0"],
        "nn": ["pandas>=1.0.0", "scikit-learn>=0.24.0"],
        "transformer": ["transformers>=4.0.0", "tokenizers>=0.10.0"],
        "all": [
            "ultralytics>=8.0.0",
            "pandas>=1.0.0",
            "scikit-learn>=0.24.0",
            "transformers>=4.0.0",
            "tokenizers>=0.10.0",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    license="MIT",
)
