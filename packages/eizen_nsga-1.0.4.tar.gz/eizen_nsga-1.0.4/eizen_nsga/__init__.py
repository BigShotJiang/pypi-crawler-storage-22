"""
eizen-nsga: Simple inference package for NSGA-Net trained models

Usage:
    from eizen_nsga import NASModel

    model = NASModel("trained_model.zip")
    result = model.predict("image.jpg")
"""

__version__ = "1.0.4"

from .model import NASModel

__all__ = ['NASModel']
