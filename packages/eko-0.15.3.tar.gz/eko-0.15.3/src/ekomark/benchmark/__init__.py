"""Benchmark implementation for EKO."""
