"""The polarized |OME|."""
