"""The unpolarized |OME|."""
