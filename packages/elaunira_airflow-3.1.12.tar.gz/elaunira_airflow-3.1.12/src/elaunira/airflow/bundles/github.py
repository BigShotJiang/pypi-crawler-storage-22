"""DAG bundle that auto-discovers repos via GitHub App installations."""

from __future__ import annotations

import json
import logging
import shutil
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path

import jwt

from airflow.dag_processing.bundles.base import BaseDagBundle

log = logging.getLogger(__name__)

# Refresh installation tokens 5 minutes before expiry
_TOKEN_MARGIN_SECONDS = 300


class GitHubAppDagBundle(BaseDagBundle):
    """Auto-discovers GitHub repos via GitHub App installations and serves their DAGs.

    Reads installation-id-* files from a secret volume to discover orgs,
    lists repos the app can access via GitHub API, filters by topic,
    and clones/fetches matching repos.

    Git auth is handled by the credential helper configured via GIT_CONFIG_* env vars.
    """

    supports_versioning = False

    def __init__(
        self,
        *,
        secret_dir: str,
        subdir: str = "workflows",
        topic: str = "airflow-dags",
        tracking_ref: str = "main",
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._secret_dir = Path(secret_dir)
        self._subdir = subdir
        self._topic = topic
        self._tracking_ref = tracking_ref
        self._repos_dir = self.base_dir / "repos"
        self._token_cache: dict[str, dict] = {}

    def initialize(self):
        self._repos_dir.mkdir(parents=True, exist_ok=True)
        self.refresh()
        super().initialize()

    @property
    def path(self) -> Path:
        return self._repos_dir

    def get_current_version(self) -> str | None:
        return None

    def refresh(self):
        with self.lock():
            repos = self._discover_repos()
            for org, repo_name, clone_url in repos:
                self._sync_repo(org, repo_name, clone_url)
            self._cleanup_stale_repos(repos)
            self._update_sys_path(repos)

    # -- Secret helpers --

    def _read_secret(self, name: str) -> str:
        return (self._secret_dir / name).read_text().strip()

    def _discover_installation_ids(self) -> dict[str, str]:
        """Return {org: installation_id} from installation-id-* files."""
        mapping = {}
        for entry in self._secret_dir.iterdir():
            if entry.name.startswith("installation-id-"):
                org = entry.name[len("installation-id-"):]
                mapping[org] = entry.read_text().strip()
        return mapping

    # -- GitHub API helpers --

    def _get_installation_token(self, org: str, installation_id: str) -> str:
        """Get an installation access token, using cache when possible."""
        cached = self._token_cache.get(org)
        if cached and time.time() < cached["expires_at"] - _TOKEN_MARGIN_SECONDS:
            return cached["token"]

        app_id = self._read_secret("app-id")
        private_key = self._read_secret("private-key")

        now = int(time.time())
        jwt_token = jwt.encode(
            {"iat": now - 60, "exp": now + 10 * 60, "iss": app_id},
            private_key,
            algorithm="RS256",
        )

        url = f"https://api.github.com/app/installations/{installation_id}/access_tokens"
        req = urllib.request.Request(
            url,
            method="POST",
            headers={
                "Authorization": f"Bearer {jwt_token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read())

        expires_at = datetime.fromisoformat(
            data["expires_at"].replace("Z", "+00:00")
        ).timestamp()

        self._token_cache[org] = {"token": data["token"], "expires_at": expires_at}
        return data["token"]

    def _discover_repos(self) -> list[tuple[str, str, str]]:
        """Discover repos across all installations, filtered by topic.

        Returns list of (org, repo_name, clone_url) tuples.
        """
        repos: list[tuple[str, str, str]] = []
        installation_ids = self._discover_installation_ids()

        for org, installation_id in installation_ids.items():
            token = self._get_installation_token(org, installation_id)
            page = 1
            while True:
                org_repos, has_next = self._list_installation_repos(token, page)
                for repo in org_repos:
                    topics = repo.get("topics", [])
                    if self._topic in topics:
                        repos.append((
                            repo["owner"]["login"],
                            repo["name"],
                            repo["clone_url"],
                        ))
                if not has_next:
                    break
                page += 1

        log.info(
            "Discovered %d repo(s) with topic '%s': %s",
            len(repos),
            self._topic,
            ", ".join(f"{org}/{name}" for org, name, _ in repos),
        )
        return repos

    def _list_installation_repos(
        self, token: str, page: int = 1, per_page: int = 100
    ) -> tuple[list[dict], bool]:
        """List repos for an installation token. Returns (repos, has_next_page)."""
        url = (
            f"https://api.github.com/installation/repositories"
            f"?per_page={per_page}&page={page}"
        )
        req = urllib.request.Request(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read())

        repositories = data.get("repositories", [])
        total_count = data.get("total_count", 0)
        has_next = page * per_page < total_count
        return repositories, has_next

    # -- Git operations --

    def _sync_repo(self, org: str, repo_name: str, clone_url: str):
        """Clone or update a repo."""
        org_dir = self._repos_dir / org
        repo_dir = org_dir / repo_name

        try:
            if not repo_dir.exists():
                org_dir.mkdir(parents=True, exist_ok=True)
                log.info("Cloning %s/%s", org, repo_name)
                subprocess.run(
                    [
                        "git", "clone",
                        "--branch", self._tracking_ref,
                        "--single-branch",
                        "--depth", "1",
                        clone_url,
                        str(repo_dir),
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
            else:
                log.debug("Fetching updates for %s/%s", org, repo_name)
                subprocess.run(
                    ["git", "fetch", "origin", self._tracking_ref],
                    cwd=str(repo_dir),
                    check=True,
                    capture_output=True,
                    text=True,
                )
                subprocess.run(
                    ["git", "reset", "--hard", f"origin/{self._tracking_ref}"],
                    cwd=str(repo_dir),
                    check=True,
                    capture_output=True,
                    text=True,
                )
        except subprocess.CalledProcessError as e:
            log.error(
                "Git operation failed for %s/%s: %s", org, repo_name, e.stderr
            )
            raise

    def _update_sys_path(self, repos: list[tuple[str, str, str]]):
        """Add each repo root to sys.path so DAGs can use absolute imports."""
        for org, repo_name, _ in repos:
            repo_root = str(self._repos_dir / org / repo_name)
            if repo_root not in sys.path:
                sys.path.insert(0, repo_root)

    def _cleanup_stale_repos(self, discovered_repos: list[tuple[str, str, str]]):
        """Remove repo directories that are no longer in the discovered set."""
        discovered = {(org, name) for org, name, _ in discovered_repos}

        if not self._repos_dir.exists():
            return

        for org_dir in self._repos_dir.iterdir():
            if not org_dir.is_dir():
                continue
            for repo_dir in org_dir.iterdir():
                if not repo_dir.is_dir():
                    continue
                if (org_dir.name, repo_dir.name) not in discovered:
                    log.info(
                        "Removing stale repo %s/%s", org_dir.name, repo_dir.name
                    )
                    shutil.rmtree(repo_dir)
            # Remove empty org directories
            if not any(org_dir.iterdir()):
                org_dir.rmdir()
