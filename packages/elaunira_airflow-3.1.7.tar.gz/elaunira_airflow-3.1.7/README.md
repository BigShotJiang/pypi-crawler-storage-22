# elaunira-airflow

Airflow operators and hooks for R2Index file operations.

## Installation

```bash
pip install elaunira-airflow

# With OpenBao/Vault support
pip install elaunira-airflow[openbao]
```

## Configuration

Configuration is loaded from Airflow connections, with environment variables as fallback.

### Option 1: Vault/OpenBao (recommended)

Create one Vault connection per service, then reference it from R2Index connections.

**Step 1: Setup OpenBao AppRoles**

Run the setup script to create an `airflow` AppRole in each service namespace:

```bash
./scripts/setup-openbao-approle.sh
```

This creates in each service namespace (ipregistry, noticeable, etc.):
- AppRole: `airflow`
- Policy: `airflow` (read access to `kv/data/*` in namespace and sub-namespaces)

To retrieve credentials later:

```bash
# Get role_id (can be read anytime)
bao read -namespace="ipregistry" -field=role_id auth/approle/role/airflow/role-id

# Generate new secret_id (cannot retrieve existing)
bao write -namespace="ipregistry" -field=secret_id -f auth/approle/role/airflow/secret-id
```

**Step 2: Create Vault connection (one per service)**

| Field | Value |
|-------|-------|
| Connection ID | `openbao-ipregistry` |
| Connection Type | `HashiCorp Vault` |
| Host | `bao.elaunira.com` |
| Schema | `https` |
| Login | AppRole role_id |
| Password | AppRole secret_id |
| Extra | `{"auth_type": "approle", "auth_mount_point": "approle", "namespace": "ipregistry"}` |

**Step 3: Create R2Index connection(s)**

| Field | Value |
|-------|-------|
| Connection ID | `r2index-ipregistry-prod` |
| Connection Type | `Generic` |
| Extra | JSON (see below) |

```json
{
  "vault_conn_id": "openbao-ipregistry",
  "vault_namespace": "ipregistry/production",
  "vault_secrets": {
    "r2index_api_url": "cloudflare/r2index#api-url",
    "r2index_api_token": "cloudflare/r2index#api-token",
    "r2_access_key_id": "cloudflare/r2/airflow#access-key-id",
    "r2_secret_access_key": "cloudflare/r2/airflow#secret-access-key",
    "r2_endpoint_url": "cloudflare/r2/airflow#endpoint-url"
  }
}
```

- `vault_conn_id`: references the Vault connection for the service
- `vault_namespace`: target namespace (e.g., `ipregistry/production`)
- `vault_secrets`: mapping of config key to secret path
  - Format: `"path#key"` or `"path"` (uses config key as secret key)
  - Secrets at the same path are fetched once and cached

Required keys in `vault_secrets`:
- `r2index_api_url`
- `r2index_api_token`
- `r2_access_key_id`
- `r2_secret_access_key`
- `r2_endpoint_url`

### Option 2: Direct Credentials

Store credentials directly in the Airflow connection:

| Field | Value |
|-------|-------|
| Connection ID | `r2index_default` |
| Host | R2Index API URL |
| Password | R2Index API token |
| Extra | JSON (see below) |

```json
{
  "r2_access_key_id": "your-access-key",
  "r2_secret_access_key": "your-secret-key",
  "r2_endpoint_url": "https://your-account.r2.cloudflarestorage.com"
}
```

### Option 3: Environment Variables (fallback)

If no connection is found:

```bash
export R2INDEX_API_URL="https://r2index.elaunira.com"
export R2INDEX_API_TOKEN="your-token"
export R2_ACCESS_KEY_ID="your-access-key"
export R2_SECRET_ACCESS_KEY="your-secret-key"
export R2_ENDPOINT_URL="https://your-account.r2.cloudflarestorage.com"
```

## Usage

### Upload files

```python
from elaunira.airflow.operators import R2IndexUploadOperator, UploadItem

# Single file
upload = R2IndexUploadOperator(
    task_id="upload_file",
    bucket="my-bucket",
    items=UploadItem(
        source="/tmp/data.csv",
        category="acme",
        entity="acme-data",
        extension="csv",
        media_type="text/csv",
        destination_path="acme/data",
        destination_filename="data.csv",
        destination_version="{{ ds }}",
    ),
)

# Multiple files (parallel)
upload_batch = R2IndexUploadOperator(
    task_id="upload_batch",
    bucket="my-bucket",
    items=[
        UploadItem(
            source="/tmp/file1.csv",
            category="acme",
            entity="acme-data",
            extension="csv",
            media_type="text/csv",
            destination_path="acme/data",
            destination_filename="file1.csv",
            destination_version="{{ ds }}",
        ),
        UploadItem(
            source="/tmp/file2.csv",
            category="acme",
            entity="acme-data",
            extension="csv",
            media_type="text/csv",
            destination_path="acme/data",
            destination_filename="file2.csv",
            destination_version="{{ ds }}",
        ),
    ],
)
```

### Download files

```python
from elaunira.airflow.operators import R2IndexDownloadOperator, DownloadItem

# Single file
download = R2IndexDownloadOperator(
    task_id="download_file",
    bucket="my-bucket",
    items=DownloadItem(
        source_path="acme/data",
        source_filename="data.csv",
        source_version="{{ ds }}",
        destination="/tmp/downloaded.csv",
    ),
)

# Multiple files (parallel)
download_batch = R2IndexDownloadOperator(
    task_id="download_batch",
    bucket="my-bucket",
    items=[
        DownloadItem(
            source_path="acme/data",
            source_filename="file1.csv",
            source_version="{{ ds }}",
            destination="/tmp/file1.csv",
        ),
        DownloadItem(
            source_path="acme/data",
            source_filename="file2.csv",
            source_version="{{ ds }}",
            destination="/tmp/file2.csv",
        ),
    ],
)
```

### Template fields

The following fields support Jinja templating:

- `items` (including nested `source`, `destination_*`, `source_*` fields)

Common template variables:
- `{{ ds }}` - Logical date (YYYY-MM-DD)
- `{{ ds_nodash }}` - Logical date without dashes
- `{{ data_interval_start }}` - Start of data interval

## TaskFlow API

Use decorators for a more Pythonic approach:

```python
from airflow.decorators import task
from elaunira.airflow.operators import UploadItem, DownloadItem

@task.r2index_upload(bucket="my-bucket")
def prepare_upload() -> UploadItem:
    # Dynamic logic to prepare the upload
    return UploadItem(
        source="/tmp/data.csv",
        category="acme",
        entity="acme-data",
        extension="csv",
        media_type="text/csv",
        destination_path="acme/data",
        destination_filename="data.csv",
        destination_version="2024-01-01",
    )

@task.r2index_download(bucket="my-bucket")
def prepare_download() -> DownloadItem:
    return DownloadItem(
        source_path="acme/data",
        source_filename="data.csv",
        source_version="2024-01-01",
        destination="/tmp/downloaded.csv",
    )

# In your DAG
with DAG(...) as dag:
    upload_result = prepare_upload()
    download_result = prepare_download()
```

Return a list of items for parallel transfers:

```python
@task.r2index_upload(bucket="my-bucket")
def prepare_batch_upload() -> list[UploadItem]:
    return [
        UploadItem(source="/tmp/file1.csv", ...),
        UploadItem(source="/tmp/file2.csv", ...),
    ]
```

## Parallel execution

When multiple items are provided, all transfers run concurrently using asyncio within the worker process. This is efficient for I/O-bound operations like file transfers.
