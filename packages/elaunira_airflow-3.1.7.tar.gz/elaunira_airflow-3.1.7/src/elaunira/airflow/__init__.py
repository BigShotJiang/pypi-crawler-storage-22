"""Elaunira Airflow operators and hooks for R2Index."""

from importlib.metadata import version

__version__ = version("elaunira-airflow")
