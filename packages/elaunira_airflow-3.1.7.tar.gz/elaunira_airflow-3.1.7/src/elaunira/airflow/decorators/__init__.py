"""Elaunira Airflow TaskFlow decorators."""

from elaunira.airflow.decorators.r2index import r2index_download, r2index_upload

__all__ = ["r2index_upload", "r2index_download"]
