"""Elaunira Airflow hooks."""

from elaunira.airflow.provider.r2index.hooks import R2IndexHook

__all__ = ["R2IndexHook"]
