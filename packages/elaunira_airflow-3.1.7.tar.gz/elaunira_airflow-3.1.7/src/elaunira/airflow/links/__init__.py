"""Elaunira Airflow operator extra links."""

from elaunira.airflow.links.r2index import R2IndexFileLink

__all__ = ["R2IndexFileLink"]
