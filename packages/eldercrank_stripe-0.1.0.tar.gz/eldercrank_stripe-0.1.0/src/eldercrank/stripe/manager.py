"""
StripeManager class for handling all Stripe data operations.
This class focuses solely on data operations and does not handle webhooks.
"""

from typing import Any, Callable, Dict, List, Optional
import stripe
import logging
from .models import StripeEvent


class StripeManager:
    """
    A manager class focused on Stripe data operations.
    This class handles all Stripe API interactions except webhook processing.
    """

    def __init__(self, api_key: str, logger: Optional[logging.Logger] = None) -> None:
        """
        Initialize the StripeManager with the necessary keys.

        Args:
            api_key: The Stripe API key (secret key).
            logger: Optional logger instance to use for logging.
        """
        self.api_key = api_key
        stripe.api_key = self.api_key
        self.logger = logger or self._setup_default_logger()
        self._webhook_handlers: Dict[str, Callable[[Dict[str, Any]], None]] = {}

    def _setup_default_logger(self) -> logging.Logger:
        """Sets up a basic console logger if none is provided."""
        logger = logging.getLogger("eldercrank.stripe.manager")
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger

    def add_webhook_handler(
        self, event_name: str, handler: Callable[[Dict[str, Any]], None]
    ) -> None:
        """
        Registers a function to handle a specific Stripe webhook event.

        Args:
            event_name: The name of the Stripe event (e.g., 'customer.subscription.created').
            handler: A function reference that will be called when the event occurs.
        """
        self._webhook_handlers[event_name] = handler
        self.logger.info(f"Added webhook handler for event: {event_name}")

    def remove_webhook_handler(self, event_name: str) -> None:
        """
        Removes a registered function for a specific Stripe webhook event.

        Args:
            event_name: The name of the Stripe event to remove.
        """
        if event_name in self._webhook_handlers:
            del self._webhook_handlers[event_name]
            self.logger.info(f"Removed webhook handler for event: {event_name}")
        else:
            self.logger.warning(f"No webhook handler found for event: {event_name}")

    def process_webhook_payload(
        self, payload: str, sig_header: str, webhook_secret: str
    ) -> Optional[StripeEvent]:
        """
        Verifies the webhook signature and processes the payload.

        Args:
            payload: Raw webhook payload from Stripe
            sig_header: Signature header from Stripe
            webhook_secret: Secret used to verify the webhook

        Returns:
            StripeEvent object if processing is successful
        """
        try:
            event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
            self.logger.info(f"Received Stripe event: {event['type']} [{event['id']}]")
        except (ValueError, stripe.error.SignatureVerificationError) as e:
            self.logger.error(f"Webhook signature verification failed: {str(e)}")
            raise e

        # Dispatch to handlers
        event_model = StripeEvent(**event)
        event_type = event_model.type
        handlers = self._webhook_handlers.get(event_type, [])

        if not handlers:
            self.logger.warning(f"No handlers registered for event: {event_type}")

        # Also support a catch-all '*' handler
        handlers += self._webhook_handlers.get("*", [])

        for handler in handlers:
            try:
                handler(event_model.event_object)
                self.logger.debug(
                    f"Handler {handler.__name__} executed successfully for {event_type}"
                )
            except Exception as e:
                self.logger.exception(
                    f"Error in handler {handler.__name__} for event {event_type}: {str(e)}"
                )

        return event_model

    # PRODUCT OPERATIONS
    def create_product(
        self,
        name: str,
        description: Optional[str] = None,
        active: bool = True,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Create a new product in Stripe.

        Args:
            name: Name of the product
            description: Optional description of the product
            active: Whether the product is active
            metadata: Optional metadata to attach to the product

        Returns:
            Dictionary containing product information
        """
        try:
            product = stripe.Product.create(
                name=name,
                description=description,
                active=active,
                metadata=metadata or {},
            )
            self.logger.info(f"Created product: {product.id}")
            return {
                "id": product.id,
                "name": product.name,
                "description": product.description,
                "active": product.active,
                "created": product.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(f"Error creating product: {str(e)}")
            raise e

    def retrieve_product(self, product_id: str) -> Dict[str, Any]:
        """
        Retrieve a product from Stripe.

        Args:
            product_id: ID of the product to retrieve

        Returns:
            Dictionary containing product information
        """
        try:
            product = stripe.Product.retrieve(product_id)
            return {
                "id": product.id,
                "name": product.name,
                "description": product.description,
                "active": product.active,
                "created": product.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(f"Error retrieving product {product_id}: {str(e)}")
            raise e

    def update_product(
        self,
        product_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        active: Optional[bool] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Update an existing product in Stripe.

        Args:
            product_id: ID of the product to update
            name: New name for the product (optional)
            description: New description for the product (optional)
            active: New active status for the product (optional)
            metadata: New metadata to attach to the product (optional)

        Returns:
            Dictionary containing updated product information
        """
        try:
            update_params = {}
            if name is not None:
                update_params["name"] = name
            if description is not None:
                update_params["description"] = description
            if active is not None:
                update_params["active"] = active
            if metadata is not None:
                update_params["metadata"] = metadata

            product = stripe.Product.modify(product_id, **update_params)
            self.logger.info(f"Updated product: {product.id}")
            return {
                "id": product.id,
                "name": product.name,
                "description": product.description,
                "active": product.active,
                "created": product.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(f"Error updating product {product_id}: {str(e)}")
            raise e

    def delete_product(self, product_id: str) -> Dict[str, Any]:
        """
        Delete a product in Stripe (actually sets it as inactive).

        Args:
            product_id: ID of the product to delete

        Returns:
            Dictionary containing deletion result
        """
        try:
            # Stripe doesn't fully delete products, only deactivates them
            product = stripe.Product.modify(product_id, active=False)
            self.logger.info(f"Deactivated product: {product.id}")
            return {"id": product.id, "deleted": True, "active": product.active}
        except stripe.error.StripeError as e:
            self.logger.error(f"Error deleting product {product_id}: {str(e)}")
            raise e

    def list_products(
        self, active: Optional[bool] = None, limit: int = 10
    ) -> List[Dict[str, Any]]:
        """
        List products in Stripe.

        Args:
            active: Filter by active status (optional)
            limit: Maximum number of products to return (default 10)

        Returns:
            List of dictionaries containing product information
        """
        try:
            params = {"limit": limit}
            if active is not None:
                params["active"] = active

            products = stripe.Product.list(**params)
            result = []
            for product in products:
                result.append(
                    {
                        "id": product.id,
                        "name": product.name,
                        "description": product.description,
                        "active": product.active,
                        "created": product.created,
                    }
                )
            return result
        except stripe.error.StripeError as e:
            self.logger.error(f"Error listing products: {str(e)}")
            raise e

    # PRICE OPERATIONS
    def create_price(
        self,
        product_id: str,
        unit_amount: int,
        currency: str = "usd",
        recurring: Optional[Dict[str, str]] = None,
        nickname: Optional[str] = None,
        active: bool = True,
    ) -> Dict[str, Any]:
        """
        Create a new price in Stripe.

        Args:
            product_id: ID of the product this price is for
            unit_amount: Price in cents (e.g., 1000 for $10.00)
            currency: Currency for the price (default 'usd')
            recurring: Recurring details for subscription prices (optional)
            nickname: Optional nickname for the price
            active: Whether the price is active (default True)

        Returns:
            Dictionary containing price information
        """
        try:
            price_data = {
                "product": product_id,
                "unit_amount": unit_amount,
                "currency": currency,
                "active": active,
            }

            if recurring:
                price_data["recurring"] = recurring
            if nickname:
                price_data["nickname"] = nickname

            price = stripe.Price.create(**price_data)
            self.logger.info(f"Created price: {price.id}")
            return {
                "id": price.id,
                "product_id": price.product,
                "unit_amount": price.unit_amount,
                "currency": price.currency,
                "recurring": price.recurring,
                "active": price.active,
                "created": price.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(f"Error creating price: {str(e)}")
            raise e

    def retrieve_price(self, price_id: str) -> Dict[str, Any]:
        """
        Retrieve a price from Stripe.

        Args:
            price_id: ID of the price to retrieve

        Returns:
            Dictionary containing price information
        """
        try:
            price = stripe.Price.retrieve(price_id)
            return {
                "id": price.id,
                "product_id": price.product,
                "unit_amount": price.unit_amount,
                "currency": price.currency,
                "recurring": price.recurring,
                "active": price.active,
                "created": price.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(f"Error retrieving price {price_id}: {str(e)}")
            raise e

    def update_price(
        self,
        price_id: str,
        active: Optional[bool] = None,
        nickname: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Update an existing price in Stripe.

        Args:
            price_id: ID of the price to update
            active: New active status for the price (optional)
            nickname: New nickname for the price (optional)

        Returns:
            Dictionary containing updated price information
        """
        try:
            update_params = {}
            if active is not None:
                update_params["active"] = active
            if nickname is not None:
                update_params["nickname"] = nickname

            price = stripe.Price.modify(price_id, **update_params)
            self.logger.info(f"Updated price: {price.id}")
            return {
                "id": price.id,
                "product_id": price.product,
                "unit_amount": price.unit_amount,
                "currency": price.currency,
                "recurring": price.recurring,
                "active": price.active,
                "created": price.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(f"Error updating price {price_id}: {str(e)}")
            raise e

    def delete_price(self, price_id: str) -> Dict[str, Any]:
        """
        Delete a price in Stripe (actually sets it as inactive).

        Args:
            price_id: ID of the price to delete

        Returns:
            Dictionary containing deletion result
        """
        try:
            # Stripe doesn't fully delete prices, only deactivates them
            price = stripe.Price.modify(price_id, active=False)
            self.logger.info(f"Deactivated price: {price.id}")
            return {"id": price.id, "deleted": True, "active": price.active}
        except stripe.error.StripeError as e:
            self.logger.error(f"Error deleting price {price_id}: {str(e)}")
            raise e

    def list_prices(
        self,
        active: Optional[bool] = None,
        product_id: Optional[str] = None,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """
        List prices in Stripe.

        Args:
            active: Filter by active status (optional)
            product_id: Filter by product ID (optional)
            limit: Maximum number of prices to return (default 10)

        Returns:
            List of dictionaries containing price information
        """
        try:
            params = {"limit": limit}
            if active is not None:
                params["active"] = active
            if product_id is not None:
                params["product"] = product_id

            prices = stripe.Price.list(**params)
            result = []
            for price in prices:
                result.append(
                    {
                        "id": price.id,
                        "product_id": price.product,
                        "unit_amount": price.unit_amount,
                        "currency": price.currency,
                        "recurring": price.recurring,
                        "active": price.active,
                        "created": price.created,
                    }
                )
            return result
        except stripe.error.StripeError as e:
            self.logger.error(f"Error listing prices: {str(e)}")
            raise e

    # CUSTOMER OPERATIONS
    def create_customer(
        self,
        name: Optional[str] = None,
        email: Optional[str] = None,
        description: Optional[str] = None,
        phone: Optional[str] = None,
        address: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Create a new customer in Stripe.

        Args:
            name: Customer's full name (optional)
            email: Customer's email address (optional)
            description: An arbitrary string attached to the object (optional)
            phone: Customer's phone number (optional)
            address: Customer's address as a dictionary (optional)
            metadata: Set of key-value pairs for storing additional info (optional)

        Returns:
            Dictionary containing customer information
        """
        try:
            customer_data = {}
            if name:
                customer_data["name"] = name
            if email:
                customer_data["email"] = email
            if description:
                customer_data["description"] = description
            if phone:
                customer_data["phone"] = phone
            if address:
                customer_data["address"] = address
            if metadata:
                customer_data["metadata"] = metadata

            customer = stripe.Customer.create(**customer_data)
            self.logger.info(f"Created customer: {customer.id}")
            return {
                "id": customer.id,
                "name": customer.name,
                "email": customer.email,
                "description": customer.description,
                "phone": customer.phone,
                "address": customer.address,
                "created": customer.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(f"Error creating customer: {str(e)}")
            raise e

    def retrieve_customer(self, customer_id: str) -> Dict[str, Any]:
        """
        Retrieve a customer from Stripe.

        Args:
            customer_id: ID of the customer to retrieve

        Returns:
            Dictionary containing customer information
        """
        try:
            customer = stripe.Customer.retrieve(customer_id)
            return {
                "id": customer.id,
                "name": customer.name,
                "email": customer.email,
                "description": customer.description,
                "phone": customer.phone,
                "address": customer.address,
                "created": customer.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(f"Error retrieving customer {customer_id}: {str(e)}")
            raise e

    def update_customer(
        self,
        customer_id: str,
        name: Optional[str] = None,
        email: Optional[str] = None,
        description: Optional[str] = None,
        phone: Optional[str] = None,
        address: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Update an existing customer in Stripe.

        Args:
            customer_id: ID of the customer to update
            name: New name for the customer (optional)
            email: New email for the customer (optional)
            description: New description for the customer (optional)
            phone: New phone number for the customer (optional)
            address: New address for the customer (optional)
            metadata: New metadata for the customer (optional)

        Returns:
            Dictionary containing updated customer information
        """
        try:
            update_params = {}
            if name is not None:
                update_params["name"] = name
            if email is not None:
                update_params["email"] = email
            if description is not None:
                update_params["description"] = description
            if phone is not None:
                update_params["phone"] = phone
            if address is not None:
                update_params["address"] = address
            if metadata is not None:
                update_params["metadata"] = metadata

            customer = stripe.Customer.modify(customer_id, **update_params)
            self.logger.info(f"Updated customer: {customer.id}")
            return {
                "id": customer.id,
                "name": customer.name,
                "email": customer.email,
                "description": customer.description,
                "phone": customer.phone,
                "address": customer.address,
                "created": customer.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(f"Error updating customer {customer_id}: {str(e)}")
            raise e

    def delete_customer(self, customer_id: str) -> Dict[str, Any]:
        """
        Delete a customer in Stripe.

        Args:
            customer_id: ID of the customer to delete

        Returns:
            Dictionary containing deletion result
        """
        try:
            customer = stripe.Customer.delete(customer_id)
            self.logger.info(f"Deleted customer: {customer.id}")
            return {"id": customer.id, "deleted": customer.deleted}
        except stripe.error.StripeError as e:
            self.logger.error(f"Error deleting customer {customer_id}: {str(e)}")
            raise e

    def list_customers(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        List customers in Stripe.

        Args:
            limit: Maximum number of customers to return (default 10)

        Returns:
            List of dictionaries containing customer information
        """
        try:
            customers = stripe.Customer.list(limit=limit)
            result = []
            for customer in customers:
                result.append(
                    {
                        "id": customer.id,
                        "name": customer.name,
                        "email": customer.email,
                        "description": customer.description,
                        "phone": customer.phone,
                        "address": customer.address,
                        "created": customer.created,
                    }
                )
            return result
        except stripe.error.StripeError as e:
            self.logger.error(f"Error listing customers: {str(e)}")
            raise e

    # SUBSCRIPTION OPERATIONS
    def create_subscription(
        self,
        customer_id: str,
        price_id: str,
        trial_period_days: Optional[int] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Create a new subscription in Stripe.

        Args:
            customer_id: ID of the customer subscribing
            price_id: ID of the price to subscribe to
            trial_period_days: Number of trial days (optional)
            metadata: Set of key-value pairs for storing additional info (optional)

        Returns:
            Dictionary containing subscription information
        """
        try:
            subscription_data = {
                "customer": customer_id,
                "items": [{"price": price_id}],
            }

            if trial_period_days:
                subscription_data["trial_period_days"] = trial_period_days
            if metadata:
                subscription_data["metadata"] = metadata

            subscription = stripe.Subscription.create(**subscription_data)
            self.logger.info(f"Created subscription: {subscription.id}")
            return {
                "id": subscription.id,
                "customer_id": subscription.customer,
                "status": subscription.status,
                "current_period_start": subscription.current_period_start,
                "current_period_end": subscription.current_period_end,
                "created": subscription.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(f"Error creating subscription: {str(e)}")
            raise e

    def retrieve_subscription(self, subscription_id: str) -> Dict[str, Any]:
        """
        Retrieve a subscription from Stripe.

        Args:
            subscription_id: ID of the subscription to retrieve

        Returns:
            Dictionary containing subscription information
        """
        try:
            subscription = stripe.Subscription.retrieve(subscription_id)
            return {
                "id": subscription.id,
                "customer_id": subscription.customer,
                "status": subscription.status,
                "current_period_start": subscription.current_period_start,
                "current_period_end": subscription.current_period_end,
                "created": subscription.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(
                f"Error retrieving subscription {subscription_id}: {str(e)}"
            )
            raise e

    def update_subscription(
        self,
        subscription_id: str,
        price_id: Optional[str] = None,
        proration_behavior: str = "create_prorations",
        metadata: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Update an existing subscription in Stripe.

        Args:
            subscription_id: ID of the subscription to update
            price_id: New price ID for the subscription (optional)
            proration_behavior: How to handle prorations (default "create_prorations")
            metadata: New metadata for the subscription (optional)

        Returns:
            Dictionary containing updated subscription information
        """
        try:
            update_params = {"proration_behavior": proration_behavior}

            if price_id:
                # First retrieve the subscription to get the existing item ID
                existing_subscription = stripe.Subscription.retrieve(subscription_id)
                if existing_subscription.items.data:
                    item_id = existing_subscription.items.data[0].id
                    update_params["items"] = [{"id": item_id, "price": price_id}]
            if metadata is not None:
                update_params["metadata"] = metadata

            subscription = stripe.Subscription.modify(subscription_id, **update_params)
            self.logger.info(f"Updated subscription: {subscription.id}")
            return {
                "id": subscription.id,
                "customer_id": subscription.customer,
                "status": subscription.status,
                "current_period_start": subscription.current_period_start,
                "current_period_end": subscription.current_period_end,
                "created": subscription.created,
            }
        except stripe.error.StripeError as e:
            self.logger.error(
                f"Error updating subscription {subscription_id}: {str(e)}"
            )
            raise e

    def cancel_subscription(
        self, subscription_id: str, at_period_end: bool = False
    ) -> Dict[str, Any]:
        """
        Cancel a subscription in Stripe.

        Args:
            subscription_id: ID of the subscription to cancel
            at_period_end: Whether to cancel at the end of the current period (default False)

        Returns:
            Dictionary containing cancellation result
        """
        try:
            if at_period_end:
                # Cancel at the end of the current period
                subscription = stripe.Subscription.modify(
                    subscription_id, cancel_at_period_end=True
                )
                return {
                    "id": subscription.id,
                    "status": subscription.status,
                    "cancel_at_period_end": subscription.cancel_at_period_end,
                }
            else:
                # Cancel immediately
                subscription = stripe.Subscription.delete(subscription_id)
                self.logger.info(f"Cancelled subscription: {subscription.id}")
                return {
                    "id": subscription.id,
                    "status": subscription.status,
                    "canceled_at": subscription.canceled_at,
                }
        except stripe.error.StripeError as e:
            self.logger.error(
                f"Error canceling subscription {subscription_id}: {str(e)}"
            )
            raise e

    def list_subscriptions(
        self,
        customer_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """
        List subscriptions in Stripe.

        Args:
            customer_id: Filter by customer ID (optional)
            status: Filter by subscription status (optional)
            limit: Maximum number of subscriptions to return (default 10)

        Returns:
            List of dictionaries containing subscription information
        """
        try:
            params = {"limit": limit}
            if customer_id:
                params["customer"] = customer_id
            if status:
                params["status"] = status

            subscriptions = stripe.Subscription.list(**params)
            result = []
            for subscription in subscriptions:
                result.append(
                    {
                        "id": subscription.id,
                        "customer_id": subscription.customer,
                        "status": subscription.status,
                        "current_period_start": subscription.current_period_start,
                        "current_period_end": subscription.current_period_end,
                        "created": subscription.created,
                    }
                )
            return result
        except stripe.error.StripeError as e:
            self.logger.error(f"Error listing subscriptions: {str(e)}")
            raise e
