from pydantic import BaseModel, Field
from pydantic.config import ConfigDict
from typing import Any, Dict, Optional, List


class StripeEvent(BaseModel):
    id: str
    type: str
    data: Dict[str, Any]  # The 'object' inside data
    api_version: Optional[str] = None

    @property
    def event_object(self):
        return self.data.get("object", {})


class PriceModel(BaseModel):
    id: str
    unit_amount: int
    currency: str
    recurring_interval: Optional[str] = Field(None, alias="interval")

    model_config = ConfigDict(populate_by_name=True)


class ProductModel(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    active: bool
    prices: List[PriceModel] = []
