This repository is a personal clone of Pyrogram, created specifically for my project and modified to suit my needs. It is intended for personal use only. 

Please understand that any issues, modifications, or deviations from the original project are solely my responsibility. Do not hold me accountable for any problems or discrepancies that may arise from using this repository.

Thank you for your understanding.


## Recent activity [![Time period](https://images.repography.com/58464391/AeonOrg/Electrogram/recent-activity/gf9SHLZa6sqXRpReIT2U07ZtsB7JysNRXMyhy4b2tgE/9c16LtrRR82Ubh9Kw6CMclKpbhDemGuBCxkZUuGJjts_badge.svg)](https://repography.com)
[![Timeline graph](https://images.repography.com/58464391/AeonOrg/Electrogram/recent-activity/gf9SHLZa6sqXRpReIT2U07ZtsB7JysNRXMyhy4b2tgE/9c16LtrRR82Ubh9Kw6CMclKpbhDemGuBCxkZUuGJjts_timeline.svg)](https://github.com/AeonOrg/Electrogram/commits)
