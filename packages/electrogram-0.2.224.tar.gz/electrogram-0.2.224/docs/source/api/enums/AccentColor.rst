AccentColor
===========

.. autoclass:: pyrogram.enums.AccentColor()
    :members:

.. raw:: html
    :file: ./cleanup.html