ChatEventAction
===============

.. autoclass:: pyrogram.enums.ChatEventAction()
    :members:

.. raw:: html
    :file: ./cleanup.html