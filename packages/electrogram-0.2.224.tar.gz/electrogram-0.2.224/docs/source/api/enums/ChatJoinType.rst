ChatJoinType
============

.. autoclass:: pyrogram.enums.ChatJoinType()
    :members:

.. raw:: html
    :file: ./cleanup.html