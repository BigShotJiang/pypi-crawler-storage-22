ListenerTypes
=============

.. autoclass:: pyrogram.enums.ListenerTypes()
    :members:

.. raw:: html
    :file: ./cleanup.html
