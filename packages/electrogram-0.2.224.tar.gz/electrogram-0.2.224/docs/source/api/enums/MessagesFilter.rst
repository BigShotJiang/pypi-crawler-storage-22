MessagesFilter
==============

.. autoclass:: pyrogram.enums.MessagesFilter()
    :members:

.. raw:: html
    :file: ./cleanup.html