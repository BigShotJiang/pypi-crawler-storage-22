StoryPrivacy
============

.. autoclass:: pyrogram.enums.StoryPrivacy()
    :members:

.. raw:: html
    :file: ./cleanup.html
