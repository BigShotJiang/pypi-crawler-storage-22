Update Filters
==============

Filters are objects that can be used to filter the content of incoming updates.
:doc:`Read more about how filters work <../topics/use-filters>`.

Details
-------

.. automodule:: pyrogram.filters
    :members:
