Support Electrogram
===================

.. raw:: html

    <script async defer src="https://buttons.github.io/buttons.js"></script>

    <div style="float: right; margin-bottom: 10px">
        <a class="github-button"
           href="https://github.com/5hojib/Electrogram"
           data-color-scheme="no-preference: light; light: light; dark: dark;"
           data-icon="octicon-star" data-size="large" data-show-count="true"
           aria-label="Star 5hojib/Electrogram on GitHub">Star</a>

        <a class="github-button"
           href="https://github.com/5hojib/Electrogram/fork"
           data-color-scheme="no-preference: light; light: light; dark: dark;"
           data-icon="octicon-repo-forked" data-size="large"
           data-show-count="true" aria-label="Fork 5hojib/Electrogram on GitHub">Fork</a>
    </div>

    <br style="clear: both"/>

Electrogram is a free and open source project.
If you enjoy Electrogram and would like to show your appreciation, consider donating or becoming
a sponsor of the project. You can support Electrogram via the ways shown below:

-----

GitHub Sponsor
--------------

`Become a GitHub sponsor <https://github.com/sponsors/5hojib>`_.

.. raw:: html

    <a class="github-button"
       href="https://github.com/sponsors/5hojib"
       data-color-scheme="no-preference: light; light: light; dark: dark;"
       data-icon="octicon-heart" data-size="large"
       aria-label="Sponsor @5hojib on GitHub">Sponsor</a>

-----
