from __future__ import annotations

from .parser import Parser

__all__ = ["Parser"]
