from __future__ import annotations

from typing import TYPE_CHECKING

import pyrogram
from pyrogram import raw, types

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator


class GetChatAdminInviteLinks:
    async def get_chat_admin_invite_links(
        self: pyrogram.Client,
        chat_id: int | str,
        admin_id: int | str,
        revoked: bool = False,
        limit: int = 0,
    ) -> AsyncGenerator[types.ChatInviteLink, None] | None:
        """Get the invite links created by an administrator in a chat.

        .. note::

            As an administrator you can only get your own links you have exported.
            As the chat or channel owner you can get everyones links.

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier for the target chat or username of the target channel/supergroup
                (in the format @username).
                You can also use chat public link in form of *t.me/<username>* (str).

            admin_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target user.
                For you yourself you can simply use "me" or "self".
                For a contact that exists in your Telegram address book you can use his phone number (str).
                You can also use user profile link in form of *t.me/<username>* (str).

            revoked (``bool``, *optional*):
                True, if you want to get revoked links instead.
                Defaults to False (get active links only).

            limit (``int``, *optional*):
                Limits the number of invite links to be retrieved.
                By default, no limit is applied and all invite links are returned.

        Returns:
            ``Generator``: A generator yielding :obj:`~pyrogram.types.ChatInviteLink` objects.

        Yields:
            :obj:`~pyrogram.types.ChatInviteLink` objects.
        """
        current = 0
        total = abs(limit) or (1 << 31) - 1
        limit = min(100, total)

        offset_date = None
        offset_link = None

        while True:
            r = await self.invoke(
                raw.functions.messages.GetExportedChatInvites(
                    peer=await self.resolve_peer(chat_id),
                    admin_id=await self.resolve_peer(admin_id),
                    limit=limit,
                    revoked=revoked,
                    offset_date=offset_date,
                    offset_link=offset_link,
                ),
            )

            if not r.invites:
                break

            users = {i.id: i for i in r.users}

            offset_date = r.invites[-1].date
            offset_link = r.invites[-1].link

            for i in r.invites:
                yield types.ChatInviteLink._parse(self, i, users)

                current += 1

                if current >= total:
                    return
