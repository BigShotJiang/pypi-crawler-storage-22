from argparse import _SubParsersAction, ArgumentParser

type ParentParser = _SubParsersAction[ArgumentParser]
