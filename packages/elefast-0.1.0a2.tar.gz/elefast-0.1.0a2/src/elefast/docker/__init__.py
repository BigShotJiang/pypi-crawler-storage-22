"""
This module is part of the 'docker' extra and needs to be explicitly installed
before it is safe to use!
"""

from elefast.docker.integration import postgres

__all__ = ["postgres"]
