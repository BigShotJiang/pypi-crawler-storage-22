"""EleutherIA CLI - Command-line interface for the EleutherIA project."""

__version__ = "1.1.3"
