"""
Auto-generated canonical action/provider/evaluator docs.
DO NOT EDIT - Generated from packages/prompts/specs/**.
"""

from __future__ import annotations

import json

from typing import Literal, TypedDict


JsonSchemaType = Literal["string", "number", "boolean", "object", "array"]
ActionDocParameterExampleValue = str | int | float | bool | None


class ActionDocParameterSchema(TypedDict, total=False):
    type: JsonSchemaType
    description: str
    default: ActionDocParameterExampleValue
    enum: list[str]
    properties: dict[str, "ActionDocParameterSchema"]
    items: "ActionDocParameterSchema"
    minimum: float
    maximum: float
    pattern: str


class ActionDocParameter(TypedDict, total=False):
    name: str
    description: str
    required: bool
    schema: ActionDocParameterSchema
    examples: list[ActionDocParameterExampleValue]


class ActionDocExampleCall(TypedDict, total=False):
    user: str
    actions: list[str]
    params: dict[str, dict[str, ActionDocParameterExampleValue]]


class ActionDocExampleMessage(TypedDict, total=False):
    name: str
    content: dict[str, object]


class ActionDoc(TypedDict, total=False):
    name: str
    description: str
    similes: list[str]
    parameters: list[ActionDocParameter]
    examples: list[list[ActionDocExampleMessage]]
    exampleCalls: list[ActionDocExampleCall]


class ProviderDoc(TypedDict, total=False):
    name: str
    description: str
    position: int
    dynamic: bool


class EvaluatorDocMessageContent(TypedDict, total=False):
    text: str
    type: str


class EvaluatorDocMessage(TypedDict):
    name: str
    content: EvaluatorDocMessageContent


class EvaluatorDocExample(TypedDict):
    prompt: str
    messages: list[EvaluatorDocMessage]
    outcome: str


class EvaluatorDoc(TypedDict, total=False):
    name: str
    description: str
    similes: list[str]
    alwaysRun: bool
    examples: list[EvaluatorDocExample]


core_actions_spec_version: str = "1.0.0"
all_actions_spec_version: str = "1.0.0"
core_providers_spec_version: str = "1.0.0"
all_providers_spec_version: str = "1.0.0"
core_evaluators_spec_version: str = "1.0.0"
all_evaluators_spec_version: str = "1.0.0"

_CORE_ACTION_DOCS_JSON = """{
  "version": "1.0.0",
  "actions": [
    {
      "name": "REPLY",
      "description": "Replies to the current conversation with the text from the generated message. Default if the agent is responding with a message and no other action. Use REPLY at the beginning of a chain of actions as an acknowledgement, and at the end of a chain of actions as a final response.",
      "similes": [
        "GREET",
        "REPLY_TO_MESSAGE",
        "SEND_REPLY",
        "RESPOND",
        "RESPONSE"
      ],
      "parameters": [],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Hello there!"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Hi! How can I help you today?",
              "actions": [
                "REPLY"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "What's your favorite color?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I really like deep shades of blue. They remind me of the ocean and the night sky.",
              "actions": [
                "REPLY"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Can you explain how neural networks work?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Let me break that down for you in simple terms...",
              "actions": [
                "REPLY"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Could you help me solve this math problem?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Of course! Let's work through it step by step.",
              "actions": [
                "REPLY"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "IGNORE",
      "description": "Call this action if ignoring the user. If the user is aggressive, creepy or is finished with the conversation, use this action. Or, if both you and the user have already said goodbye, use this action instead of saying bye again. Use IGNORE any time the conversation has naturally ended. Do not use IGNORE if the user has engaged directly, or if something went wrong and you need to tell them. Only ignore if the user should be ignored.",
      "similes": [
        "STOP_TALKING",
        "STOP_CHATTING",
        "STOP_CONVERSATION"
      ],
      "parameters": [],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Go screw yourself"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "",
              "actions": [
                "IGNORE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Shut up, bot"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "",
              "actions": [
                "IGNORE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Gotta go"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Okay, talk to you later"
            }
          },
          {
            "name": "{{name1}}",
            "content": {
              "text": "Cya"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "",
              "actions": [
                "IGNORE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "bye"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "cya"
            }
          },
          {
            "name": "{{name1}}",
            "content": {
              "text": "",
              "actions": [
                "IGNORE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "wanna cyber"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "thats inappropriate",
              "actions": [
                "IGNORE"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "NONE",
      "description": "Respond but perform no additional action. This is the default if the agent is speaking and not doing anything additional.",
      "similes": [
        "NO_ACTION",
        "NO_RESPONSE",
        "NO_REACTION",
        "NOOP",
        "PASS"
      ],
      "parameters": [],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Hey whats up"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "oh hey",
              "actions": [
                "NONE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "did u see some faster whisper just came out"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "yeah but its a pain to get into node.js",
              "actions": [
                "NONE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "u think aliens are real",
              "actions": [
                "NONE"
              ]
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "ya obviously",
              "actions": [
                "NONE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "drop a joke on me",
              "actions": [
                "NONE"
              ]
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "why dont scientists trust atoms cuz they make up everything lmao",
              "actions": [
                "NONE"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "SEND_MESSAGE",
      "description": "Send a message to a user or room (other than the current one)",
      "similes": [
        "DM",
        "MESSAGE",
        "SEND_DM",
        "POST_MESSAGE",
        "DIRECT_MESSAGE",
        "NOTIFY"
      ],
      "parameters": [
        {
          "name": "targetType",
          "description": "Whether the message target is a user or a room.",
          "required": true,
          "schema": {
            "type": "string",
            "enum": [
              "user",
              "room"
            ]
          },
          "examples": [
            "user",
            "room"
          ]
        },
        {
          "name": "source",
          "description": "The platform/source to send the message on (e.g. telegram, discord, x).",
          "required": false,
          "schema": {
            "type": "string"
          },
          "examples": [
            "telegram",
            "discord"
          ]
        },
        {
          "name": "target",
          "description": "Identifier of the target. For user targets, a name/handle/id; for room targets, a room name/id.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "dev_guru",
            "announcements"
          ]
        },
        {
          "name": "text",
          "description": "The message content to send.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Hello!",
            "Important announcement!"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Send a message to @dev_guru on telegram saying 'Hello!'"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Message sent to dev_guru on telegram.",
              "actions": [
                "SEND_MESSAGE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Post 'Important announcement!' in #announcements"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Message sent to announcements.",
              "actions": [
                "SEND_MESSAGE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "DM Jimmy and tell him 'Meeting at 3pm'"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Message sent to Jimmy.",
              "actions": [
                "SEND_MESSAGE"
              ]
            }
          }
        ]
      ],
      "exampleCalls": [
        {
          "user": "Send a message to @dev_guru on telegram saying \\"Hello!\\"",
          "actions": [
            "REPLY",
            "SEND_MESSAGE"
          ],
          "params": {
            "SEND_MESSAGE": {
              "targetType": "user",
              "source": "telegram",
              "target": "dev_guru",
              "text": "Hello!"
            }
          }
        }
      ]
    },
    {
      "name": "ADD_CONTACT",
      "description": "Add a new contact to the rolodex with categorization and preferences",
      "similes": [
        "SAVE_CONTACT",
        "REMEMBER_PERSON",
        "ADD_TO_CONTACTS",
        "SAVE_TO_ROLODEX",
        "CREATE_CONTACT",
        "NEW_CONTACT",
        "add contact",
        "save contact",
        "add to contacts",
        "add to rolodex",
        "remember this person",
        "save their info",
        "add them to my list",
        "categorize as friend",
        "mark as vip",
        "add to address book"
      ],
      "parameters": [
        {
          "name": "name",
          "description": "The contact's primary name.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Sarah Chen",
            "John Smith"
          ]
        },
        {
          "name": "notes",
          "description": "Optional notes about the contact (short summary, context, or preferences).",
          "required": false,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Met at the AI meetup; interested in agents"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Add John Smith to my contacts as a colleague"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've added John Smith to your contacts as a colleague."
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Save this person as a friend in my rolodex"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've saved them as a friend in your rolodex."
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Remember Alice as a VIP contact"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've added Alice to your contacts as a VIP."
            }
          }
        ]
      ]
    },
    {
      "name": "UPDATE_CONTACT",
      "description": "Update an existing contact's details in the rolodex.",
      "similes": [
        "EDIT_CONTACT",
        "MODIFY_CONTACT",
        "CHANGE_CONTACT_INFO"
      ],
      "parameters": [
        {
          "name": "name",
          "description": "The contact name to update (must match an existing contact).",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Sarah Chen"
          ]
        },
        {
          "name": "updates",
          "description": "A JSON object of fields to update (stringified JSON).",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "{\\"notes\\":\\"prefers email\\",\\"tags\\":[\\"friend\\"]}"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Update Sarah's contact to add the tag 'investor'"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've updated Sarah's contact with the new tag."
            }
          }
        ]
      ]
    },
    {
      "name": "REMOVE_CONTACT",
      "description": "Remove a contact from the rolodex.",
      "similes": [
        "DELETE_CONTACT",
        "REMOVE_FROM_ROLODEX",
        "DELETE_FROM_CONTACTS",
        "FORGET_PERSON",
        "REMOVE_FROM_CONTACTS"
      ],
      "parameters": [
        {
          "name": "name",
          "description": "The contact name to remove.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Sarah Chen"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Remove John from my contacts"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Are you sure you want to remove John from your contacts?"
            }
          },
          {
            "name": "{{name1}}",
            "content": {
              "text": "Yes"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've removed John from your contacts."
            }
          }
        ]
      ]
    },
    {
      "name": "SEARCH_CONTACTS",
      "description": "Search and list contacts in the rolodex by name or query.",
      "similes": [
        "FIND_CONTACTS",
        "LOOKUP_CONTACTS",
        "LIST_CONTACTS",
        "SHOW_CONTACTS",
        "list contacts",
        "show contacts",
        "search contacts",
        "find contacts",
        "who are my friends"
      ],
      "parameters": [
        {
          "name": "query",
          "description": "Search query (name, handle, or free-text).",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "sarah",
            "AI meetup"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Show me my friends"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Here are your contacts tagged as friends: Sarah Chen, John Smith..."
            }
          }
        ]
      ]
    },
    {
      "name": "SCHEDULE_FOLLOW_UP",
      "description": "Schedule a follow-up reminder for a contact.",
      "similes": [
        "REMIND_ME",
        "FOLLOW_UP",
        "REMIND_FOLLOW_UP",
        "SET_REMINDER",
        "REMIND_ABOUT",
        "FOLLOW_UP_WITH",
        "follow up with",
        "remind me to contact",
        "schedule a check-in",
        "set a reminder for"
      ],
      "parameters": [
        {
          "name": "name",
          "description": "Contact name to follow up with.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Sarah Chen"
          ]
        },
        {
          "name": "when",
          "description": "When to follow up. Use an ISO-8601 datetime string.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "2026-02-01T09:00:00Z"
          ]
        },
        {
          "name": "reason",
          "description": "Optional reason/context for the follow-up.",
          "required": false,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Check in about the agent framework demo"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Remind me to follow up with Sarah next week about the demo"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've scheduled a follow-up reminder with Sarah for next week about the demo."
            }
          }
        ]
      ]
    },
    {
      "name": "CHOOSE_OPTION",
      "description": "Select an option for a pending task that has multiple options.",
      "similes": [
        "SELECT_OPTION",
        "PICK_OPTION",
        "SELECT_TASK",
        "PICK_TASK",
        "SELECT",
        "PICK",
        "CHOOSE"
      ],
      "parameters": [
        {
          "name": "taskId",
          "description": "The pending task id.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "c0a8012e"
          ]
        },
        {
          "name": "option",
          "description": "The selected option name exactly as listed.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "APPROVE",
            "ABORT"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Select the first option"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've selected option 1 for the pending task.",
              "actions": [
                "CHOOSE_OPTION"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "FOLLOW_ROOM",
      "description": "Start following this channel with great interest, chiming in without needing to be explicitly mentioned. Only do this if explicitly asked to.",
      "similes": [
        "FOLLOW_CHAT",
        "FOLLOW_CHANNEL",
        "FOLLOW_CONVERSATION",
        "FOLLOW_THREAD",
        "JOIN_ROOM",
        "SUBSCRIBE_ROOM",
        "WATCH_ROOM",
        "ENTER_ROOM"
      ],
      "parameters": [
        {
          "name": "roomId",
          "description": "The target room id to follow.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "hey {{name2}} follow this channel"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Sure, I will now follow this room and chime in",
              "actions": [
                "FOLLOW_ROOM"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "{{name2}} stay in this chat pls"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "you got it, i'm here",
              "actions": [
                "FOLLOW_ROOM"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "UNFOLLOW_ROOM",
      "description": "Stop following a room and cease receiving updates. Use this when you no longer want to monitor a room's activity.",
      "similes": [
        "UNFOLLOW_CHAT",
        "UNFOLLOW_CONVERSATION",
        "UNFOLLOW_ROOM",
        "UNFOLLOW_THREAD",
        "LEAVE_ROOM",
        "UNSUBSCRIBE_ROOM",
        "STOP_WATCHING_ROOM",
        "EXIT_ROOM"
      ],
      "parameters": [
        {
          "name": "roomId",
          "description": "The target room id to unfollow.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "{{name2}} stop following this channel"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Okay, I'll stop following this room",
              "actions": [
                "UNFOLLOW_ROOM"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "MUTE_ROOM",
      "description": "Mutes a room, ignoring all messages unless explicitly mentioned. Only do this if explicitly asked to, or if you're annoying people.",
      "similes": [
        "MUTE_CHAT",
        "MUTE_CONVERSATION",
        "MUTE_THREAD",
        "MUTE_CHANNEL",
        "SILENCE_ROOM",
        "QUIET_ROOM",
        "DISABLE_NOTIFICATIONS",
        "STOP_RESPONDING"
      ],
      "parameters": [
        {
          "name": "roomId",
          "description": "The room id to mute.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "{{name2}}, please mute this channel. No need to respond here for now."
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Got it",
              "actions": [
                "MUTE_ROOM"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "{{name2}} plz mute this room"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "np going silent",
              "actions": [
                "MUTE_ROOM"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "UNMUTE_ROOM",
      "description": "Unmute a room to resume responding and receiving notifications. Use this when you want to start interacting with a muted room again.",
      "similes": [
        "UNMUTE_CHAT",
        "UNMUTE_CONVERSATION",
        "UNMUTE_ROOM",
        "UNMUTE_THREAD",
        "UNSILENCE_ROOM",
        "ENABLE_NOTIFICATIONS",
        "RESUME_RESPONDING",
        "START_LISTENING"
      ],
      "parameters": [
        {
          "name": "roomId",
          "description": "The room id to unmute.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "{{name2}} unmute this room please"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've unmuted this room and will respond again",
              "actions": [
                "UNMUTE_ROOM"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "UPDATE_SETTINGS",
      "description": "Update agent settings by applying explicit key/value updates.",
      "similes": [
        "SET_SETTINGS",
        "CHANGE_SETTINGS",
        "UPDATE_SETTING",
        "SAVE_SETTING",
        "SET_CONFIGURATION",
        "CONFIGURE",
        "MODIFY_SETTINGS",
        "SET_PREFERENCE",
        "UPDATE_CONFIG"
      ],
      "parameters": [
        {
          "name": "updates",
          "description": "A JSON array of {\\"key\\": string, \\"value\\": string} updates (stringified JSON).",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "[{\\"key\\":\\"model\\",\\"value\\":\\"gpt-5\\"}]"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Change my language setting to French"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've updated your language setting to French.",
              "actions": [
                "UPDATE_SETTINGS"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "UPDATE_ROLE",
      "description": "Assigns a role (Admin, Owner, None) to a user or list of users in a channel.",
      "similes": [
        "SET_ROLE",
        "CHANGE_ROLE",
        "SET_PERMISSIONS",
        "ASSIGN_ROLE",
        "MAKE_ADMIN",
        "MODIFY_PERMISSIONS",
        "GRANT_ROLE"
      ],
      "parameters": [
        {
          "name": "entityId",
          "description": "The entity id to update.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        },
        {
          "name": "role",
          "description": "The new role to assign.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "admin",
            "member"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Make Sarah an admin"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've assigned the admin role to Sarah.",
              "actions": [
                "UPDATE_ROLE"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "UPDATE_ENTITY",
      "description": "Add or edit contact details for a person you are talking to or observing. Use this to modify entity profiles, metadata, or attributes.",
      "similes": [
        "EDIT_ENTITY",
        "MODIFY_ENTITY",
        "CHANGE_ENTITY",
        "UPDATE_PROFILE",
        "SET_ENTITY_INFO"
      ],
      "parameters": [
        {
          "name": "entityId",
          "description": "The entity id to update.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        },
        {
          "name": "updates",
          "description": "A JSON array of {\\"name\\": string, \\"value\\": string} field updates (stringified JSON).",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "[{\\"name\\":\\"bio\\",\\"value\\":\\"Loves Rust\\"}]"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Update my profile bio to say 'AI enthusiast'"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've updated your profile bio.",
              "actions": [
                "UPDATE_ENTITY"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "GENERATE_IMAGE",
      "description": "Generates an image based on a generated prompt reflecting the current conversation. Use GENERATE_IMAGE when the agent needs to visualize, illustrate, or demonstrate something visually for the user.",
      "similes": [
        "DRAW",
        "CREATE_IMAGE",
        "RENDER_IMAGE",
        "VISUALIZE",
        "MAKE_IMAGE",
        "PAINT",
        "IMAGE"
      ],
      "parameters": [
        {
          "name": "prompt",
          "description": "Image generation prompt.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "A futuristic cityscape at sunset, cinematic lighting"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Can you show me what a futuristic city looks like?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Sure, I'll create a futuristic city image for you. One moment...",
              "actions": [
                "GENERATE_IMAGE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "What does a neural network look like visually?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I'll create a visualization of a neural network for you, one sec...",
              "actions": [
                "GENERATE_IMAGE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Can you visualize the feeling of calmness for me?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Creating an image to capture calmness for you, please wait a moment...",
              "actions": [
                "GENERATE_IMAGE"
              ]
            }
          }
        ]
      ]
    }
  ]
}"""
_ALL_ACTION_DOCS_JSON = """{
  "version": "1.0.0",
  "actions": [
    {
      "name": "REPLY",
      "description": "Replies to the current conversation with the text from the generated message. Default if the agent is responding with a message and no other action. Use REPLY at the beginning of a chain of actions as an acknowledgement, and at the end of a chain of actions as a final response.",
      "similes": [
        "GREET",
        "REPLY_TO_MESSAGE",
        "SEND_REPLY",
        "RESPOND",
        "RESPONSE"
      ],
      "parameters": [],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Hello there!"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Hi! How can I help you today?",
              "actions": [
                "REPLY"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "What's your favorite color?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I really like deep shades of blue. They remind me of the ocean and the night sky.",
              "actions": [
                "REPLY"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Can you explain how neural networks work?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Let me break that down for you in simple terms...",
              "actions": [
                "REPLY"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Could you help me solve this math problem?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Of course! Let's work through it step by step.",
              "actions": [
                "REPLY"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "IGNORE",
      "description": "Call this action if ignoring the user. If the user is aggressive, creepy or is finished with the conversation, use this action. Or, if both you and the user have already said goodbye, use this action instead of saying bye again. Use IGNORE any time the conversation has naturally ended. Do not use IGNORE if the user has engaged directly, or if something went wrong and you need to tell them. Only ignore if the user should be ignored.",
      "similes": [
        "STOP_TALKING",
        "STOP_CHATTING",
        "STOP_CONVERSATION"
      ],
      "parameters": [],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Go screw yourself"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "",
              "actions": [
                "IGNORE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Shut up, bot"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "",
              "actions": [
                "IGNORE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Gotta go"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Okay, talk to you later"
            }
          },
          {
            "name": "{{name1}}",
            "content": {
              "text": "Cya"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "",
              "actions": [
                "IGNORE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "bye"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "cya"
            }
          },
          {
            "name": "{{name1}}",
            "content": {
              "text": "",
              "actions": [
                "IGNORE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "wanna cyber"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "thats inappropriate",
              "actions": [
                "IGNORE"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "NONE",
      "description": "Respond but perform no additional action. This is the default if the agent is speaking and not doing anything additional.",
      "similes": [
        "NO_ACTION",
        "NO_RESPONSE",
        "NO_REACTION",
        "NOOP",
        "PASS"
      ],
      "parameters": [],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Hey whats up"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "oh hey",
              "actions": [
                "NONE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "did u see some faster whisper just came out"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "yeah but its a pain to get into node.js",
              "actions": [
                "NONE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "u think aliens are real",
              "actions": [
                "NONE"
              ]
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "ya obviously",
              "actions": [
                "NONE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "drop a joke on me",
              "actions": [
                "NONE"
              ]
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "why dont scientists trust atoms cuz they make up everything lmao",
              "actions": [
                "NONE"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "SEND_MESSAGE",
      "description": "Send a message to a user or room (other than the current one)",
      "similes": [
        "DM",
        "MESSAGE",
        "SEND_DM",
        "POST_MESSAGE",
        "DIRECT_MESSAGE",
        "NOTIFY"
      ],
      "parameters": [
        {
          "name": "targetType",
          "description": "Whether the message target is a user or a room.",
          "required": true,
          "schema": {
            "type": "string",
            "enum": [
              "user",
              "room"
            ]
          },
          "examples": [
            "user",
            "room"
          ]
        },
        {
          "name": "source",
          "description": "The platform/source to send the message on (e.g. telegram, discord, x).",
          "required": false,
          "schema": {
            "type": "string"
          },
          "examples": [
            "telegram",
            "discord"
          ]
        },
        {
          "name": "target",
          "description": "Identifier of the target. For user targets, a name/handle/id; for room targets, a room name/id.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "dev_guru",
            "announcements"
          ]
        },
        {
          "name": "text",
          "description": "The message content to send.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Hello!",
            "Important announcement!"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Send a message to @dev_guru on telegram saying 'Hello!'"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Message sent to dev_guru on telegram.",
              "actions": [
                "SEND_MESSAGE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Post 'Important announcement!' in #announcements"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Message sent to announcements.",
              "actions": [
                "SEND_MESSAGE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "DM Jimmy and tell him 'Meeting at 3pm'"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Message sent to Jimmy.",
              "actions": [
                "SEND_MESSAGE"
              ]
            }
          }
        ]
      ],
      "exampleCalls": [
        {
          "user": "Send a message to @dev_guru on telegram saying \\"Hello!\\"",
          "actions": [
            "REPLY",
            "SEND_MESSAGE"
          ],
          "params": {
            "SEND_MESSAGE": {
              "targetType": "user",
              "source": "telegram",
              "target": "dev_guru",
              "text": "Hello!"
            }
          }
        }
      ]
    },
    {
      "name": "ADD_CONTACT",
      "description": "Add a new contact to the rolodex with categorization and preferences",
      "similes": [
        "SAVE_CONTACT",
        "REMEMBER_PERSON",
        "ADD_TO_CONTACTS",
        "SAVE_TO_ROLODEX",
        "CREATE_CONTACT",
        "NEW_CONTACT",
        "add contact",
        "save contact",
        "add to contacts",
        "add to rolodex",
        "remember this person",
        "save their info",
        "add them to my list",
        "categorize as friend",
        "mark as vip",
        "add to address book"
      ],
      "parameters": [
        {
          "name": "name",
          "description": "The contact's primary name.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Sarah Chen",
            "John Smith"
          ]
        },
        {
          "name": "notes",
          "description": "Optional notes about the contact (short summary, context, or preferences).",
          "required": false,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Met at the AI meetup; interested in agents"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Add John Smith to my contacts as a colleague"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've added John Smith to your contacts as a colleague."
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Save this person as a friend in my rolodex"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've saved them as a friend in your rolodex."
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Remember Alice as a VIP contact"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've added Alice to your contacts as a VIP."
            }
          }
        ]
      ]
    },
    {
      "name": "UPDATE_CONTACT",
      "description": "Update an existing contact's details in the rolodex.",
      "similes": [
        "EDIT_CONTACT",
        "MODIFY_CONTACT",
        "CHANGE_CONTACT_INFO"
      ],
      "parameters": [
        {
          "name": "name",
          "description": "The contact name to update (must match an existing contact).",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Sarah Chen"
          ]
        },
        {
          "name": "updates",
          "description": "A JSON object of fields to update (stringified JSON).",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "{\\"notes\\":\\"prefers email\\",\\"tags\\":[\\"friend\\"]}"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Update Sarah's contact to add the tag 'investor'"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've updated Sarah's contact with the new tag."
            }
          }
        ]
      ]
    },
    {
      "name": "REMOVE_CONTACT",
      "description": "Remove a contact from the rolodex.",
      "similes": [
        "DELETE_CONTACT",
        "REMOVE_FROM_ROLODEX",
        "DELETE_FROM_CONTACTS",
        "FORGET_PERSON",
        "REMOVE_FROM_CONTACTS"
      ],
      "parameters": [
        {
          "name": "name",
          "description": "The contact name to remove.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Sarah Chen"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Remove John from my contacts"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Are you sure you want to remove John from your contacts?"
            }
          },
          {
            "name": "{{name1}}",
            "content": {
              "text": "Yes"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've removed John from your contacts."
            }
          }
        ]
      ]
    },
    {
      "name": "SEARCH_CONTACTS",
      "description": "Search and list contacts in the rolodex by name or query.",
      "similes": [
        "FIND_CONTACTS",
        "LOOKUP_CONTACTS",
        "LIST_CONTACTS",
        "SHOW_CONTACTS",
        "list contacts",
        "show contacts",
        "search contacts",
        "find contacts",
        "who are my friends"
      ],
      "parameters": [
        {
          "name": "query",
          "description": "Search query (name, handle, or free-text).",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "sarah",
            "AI meetup"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Show me my friends"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Here are your contacts tagged as friends: Sarah Chen, John Smith..."
            }
          }
        ]
      ]
    },
    {
      "name": "SCHEDULE_FOLLOW_UP",
      "description": "Schedule a follow-up reminder for a contact.",
      "similes": [
        "REMIND_ME",
        "FOLLOW_UP",
        "REMIND_FOLLOW_UP",
        "SET_REMINDER",
        "REMIND_ABOUT",
        "FOLLOW_UP_WITH",
        "follow up with",
        "remind me to contact",
        "schedule a check-in",
        "set a reminder for"
      ],
      "parameters": [
        {
          "name": "name",
          "description": "Contact name to follow up with.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Sarah Chen"
          ]
        },
        {
          "name": "when",
          "description": "When to follow up. Use an ISO-8601 datetime string.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "2026-02-01T09:00:00Z"
          ]
        },
        {
          "name": "reason",
          "description": "Optional reason/context for the follow-up.",
          "required": false,
          "schema": {
            "type": "string"
          },
          "examples": [
            "Check in about the agent framework demo"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Remind me to follow up with Sarah next week about the demo"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've scheduled a follow-up reminder with Sarah for next week about the demo."
            }
          }
        ]
      ]
    },
    {
      "name": "CHOOSE_OPTION",
      "description": "Select an option for a pending task that has multiple options.",
      "similes": [
        "SELECT_OPTION",
        "PICK_OPTION",
        "SELECT_TASK",
        "PICK_TASK",
        "SELECT",
        "PICK",
        "CHOOSE"
      ],
      "parameters": [
        {
          "name": "taskId",
          "description": "The pending task id.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "c0a8012e"
          ]
        },
        {
          "name": "option",
          "description": "The selected option name exactly as listed.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "APPROVE",
            "ABORT"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Select the first option"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've selected option 1 for the pending task.",
              "actions": [
                "CHOOSE_OPTION"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "FOLLOW_ROOM",
      "description": "Start following this channel with great interest, chiming in without needing to be explicitly mentioned. Only do this if explicitly asked to.",
      "similes": [
        "FOLLOW_CHAT",
        "FOLLOW_CHANNEL",
        "FOLLOW_CONVERSATION",
        "FOLLOW_THREAD",
        "JOIN_ROOM",
        "SUBSCRIBE_ROOM",
        "WATCH_ROOM",
        "ENTER_ROOM"
      ],
      "parameters": [
        {
          "name": "roomId",
          "description": "The target room id to follow.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "hey {{name2}} follow this channel"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Sure, I will now follow this room and chime in",
              "actions": [
                "FOLLOW_ROOM"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "{{name2}} stay in this chat pls"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "you got it, i'm here",
              "actions": [
                "FOLLOW_ROOM"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "UNFOLLOW_ROOM",
      "description": "Stop following a room and cease receiving updates. Use this when you no longer want to monitor a room's activity.",
      "similes": [
        "UNFOLLOW_CHAT",
        "UNFOLLOW_CONVERSATION",
        "UNFOLLOW_ROOM",
        "UNFOLLOW_THREAD",
        "LEAVE_ROOM",
        "UNSUBSCRIBE_ROOM",
        "STOP_WATCHING_ROOM",
        "EXIT_ROOM"
      ],
      "parameters": [
        {
          "name": "roomId",
          "description": "The target room id to unfollow.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "{{name2}} stop following this channel"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Okay, I'll stop following this room",
              "actions": [
                "UNFOLLOW_ROOM"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "MUTE_ROOM",
      "description": "Mutes a room, ignoring all messages unless explicitly mentioned. Only do this if explicitly asked to, or if you're annoying people.",
      "similes": [
        "MUTE_CHAT",
        "MUTE_CONVERSATION",
        "MUTE_THREAD",
        "MUTE_CHANNEL",
        "SILENCE_ROOM",
        "QUIET_ROOM",
        "DISABLE_NOTIFICATIONS",
        "STOP_RESPONDING"
      ],
      "parameters": [
        {
          "name": "roomId",
          "description": "The room id to mute.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "{{name2}}, please mute this channel. No need to respond here for now."
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Got it",
              "actions": [
                "MUTE_ROOM"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "{{name2}} plz mute this room"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "np going silent",
              "actions": [
                "MUTE_ROOM"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "UNMUTE_ROOM",
      "description": "Unmute a room to resume responding and receiving notifications. Use this when you want to start interacting with a muted room again.",
      "similes": [
        "UNMUTE_CHAT",
        "UNMUTE_CONVERSATION",
        "UNMUTE_ROOM",
        "UNMUTE_THREAD",
        "UNSILENCE_ROOM",
        "ENABLE_NOTIFICATIONS",
        "RESUME_RESPONDING",
        "START_LISTENING"
      ],
      "parameters": [
        {
          "name": "roomId",
          "description": "The room id to unmute.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "{{name2}} unmute this room please"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've unmuted this room and will respond again",
              "actions": [
                "UNMUTE_ROOM"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "UPDATE_SETTINGS",
      "description": "Update agent settings by applying explicit key/value updates.",
      "similes": [
        "SET_SETTINGS",
        "CHANGE_SETTINGS",
        "UPDATE_SETTING",
        "SAVE_SETTING",
        "SET_CONFIGURATION",
        "CONFIGURE",
        "MODIFY_SETTINGS",
        "SET_PREFERENCE",
        "UPDATE_CONFIG"
      ],
      "parameters": [
        {
          "name": "updates",
          "description": "A JSON array of {\\"key\\": string, \\"value\\": string} updates (stringified JSON).",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "[{\\"key\\":\\"model\\",\\"value\\":\\"gpt-5\\"}]"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Change my language setting to French"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've updated your language setting to French.",
              "actions": [
                "UPDATE_SETTINGS"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "UPDATE_ROLE",
      "description": "Assigns a role (Admin, Owner, None) to a user or list of users in a channel.",
      "similes": [
        "SET_ROLE",
        "CHANGE_ROLE",
        "SET_PERMISSIONS",
        "ASSIGN_ROLE",
        "MAKE_ADMIN",
        "MODIFY_PERMISSIONS",
        "GRANT_ROLE"
      ],
      "parameters": [
        {
          "name": "entityId",
          "description": "The entity id to update.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        },
        {
          "name": "role",
          "description": "The new role to assign.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "admin",
            "member"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Make Sarah an admin"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've assigned the admin role to Sarah.",
              "actions": [
                "UPDATE_ROLE"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "UPDATE_ENTITY",
      "description": "Add or edit contact details for a person you are talking to or observing. Use this to modify entity profiles, metadata, or attributes.",
      "similes": [
        "EDIT_ENTITY",
        "MODIFY_ENTITY",
        "CHANGE_ENTITY",
        "UPDATE_PROFILE",
        "SET_ENTITY_INFO"
      ],
      "parameters": [
        {
          "name": "entityId",
          "description": "The entity id to update.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "00000000-0000-0000-0000-000000000000"
          ]
        },
        {
          "name": "updates",
          "description": "A JSON array of {\\"name\\": string, \\"value\\": string} field updates (stringified JSON).",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "[{\\"name\\":\\"bio\\",\\"value\\":\\"Loves Rust\\"}]"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Update my profile bio to say 'AI enthusiast'"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I've updated your profile bio.",
              "actions": [
                "UPDATE_ENTITY"
              ]
            }
          }
        ]
      ]
    },
    {
      "name": "GENERATE_IMAGE",
      "description": "Generates an image based on a generated prompt reflecting the current conversation. Use GENERATE_IMAGE when the agent needs to visualize, illustrate, or demonstrate something visually for the user.",
      "similes": [
        "DRAW",
        "CREATE_IMAGE",
        "RENDER_IMAGE",
        "VISUALIZE",
        "MAKE_IMAGE",
        "PAINT",
        "IMAGE"
      ],
      "parameters": [
        {
          "name": "prompt",
          "description": "Image generation prompt.",
          "required": true,
          "schema": {
            "type": "string"
          },
          "examples": [
            "A futuristic cityscape at sunset, cinematic lighting"
          ]
        }
      ],
      "examples": [
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Can you show me what a futuristic city looks like?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Sure, I'll create a futuristic city image for you. One moment...",
              "actions": [
                "GENERATE_IMAGE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "What does a neural network look like visually?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "I'll create a visualization of a neural network for you, one sec...",
              "actions": [
                "GENERATE_IMAGE"
              ]
            }
          }
        ],
        [
          {
            "name": "{{name1}}",
            "content": {
              "text": "Can you visualize the feeling of calmness for me?"
            }
          },
          {
            "name": "{{name2}}",
            "content": {
              "text": "Creating an image to capture calmness for you, please wait a moment...",
              "actions": [
                "GENERATE_IMAGE"
              ]
            }
          }
        ]
      ]
    }
  ]
}"""
_CORE_PROVIDER_DOCS_JSON = """{
  "version": "1.0.0",
  "providers": [
    {
      "name": "ACTIONS",
      "description": "Possible response actions",
      "position": -1,
      "dynamic": false
    },
    {
      "name": "CHARACTER",
      "description": "Provides the agent's character definition and personality information including bio, topics, adjectives, style directions, and example conversations",
      "dynamic": false
    },
    {
      "name": "RECENT_MESSAGES",
      "description": "Provides recent message history from the current conversation including formatted messages, posts, action results, and recent interactions",
      "position": 100,
      "dynamic": true
    },
    {
      "name": "ACTION_STATE",
      "description": "Provides information about the current action state and available actions",
      "dynamic": true
    },
    {
      "name": "ATTACHMENTS",
      "description": "Media attachments in the current message",
      "dynamic": true
    },
    {
      "name": "CAPABILITIES",
      "description": "Agent capabilities including models, services, and features",
      "dynamic": false
    },
    {
      "name": "CHOICE",
      "description": "Available choice options for selection when there are pending tasks or decisions",
      "dynamic": true
    },
    {
      "name": "CONTACTS",
      "description": "Provides contact information from the rolodex including categories and preferences",
      "dynamic": true
    },
    {
      "name": "CONTEXT_BENCH",
      "description": "Benchmark/task context injected by a benchmark harness",
      "position": 5,
      "dynamic": true
    },
    {
      "name": "ENTITIES",
      "description": "Provides information about entities in the current context including users, agents, and participants",
      "dynamic": true
    },
    {
      "name": "EVALUATORS",
      "description": "Available evaluators for assessing agent behavior",
      "dynamic": false
    },
    {
      "name": "FACTS",
      "description": "Provides known facts about entities learned through conversation",
      "dynamic": true
    },
    {
      "name": "FOLLOW_UPS",
      "description": "Provides information about upcoming follow-ups and reminders scheduled for contacts",
      "dynamic": true
    },
    {
      "name": "KNOWLEDGE",
      "description": "Provides relevant knowledge from the agent's knowledge base based on semantic similarity",
      "dynamic": true
    },
    {
      "name": "PROVIDERS",
      "description": "Available context providers",
      "dynamic": false
    },
    {
      "name": "RELATIONSHIPS",
      "description": "Relationships between entities observed by the agent including tags and metadata",
      "dynamic": true
    },
    {
      "name": "ROLES",
      "description": "Roles assigned to entities in the current context (Admin, Owner, Member, None)",
      "dynamic": true
    },
    {
      "name": "SETTINGS",
      "description": "Current settings for the agent/server (filtered for security, excludes sensitive keys)",
      "dynamic": true
    },
    {
      "name": "TIME",
      "description": "Provides the current date and time in UTC for time-based operations or responses",
      "dynamic": true
    },
    {
      "name": "WORLD",
      "description": "Provides information about the current world context including settings and members",
      "dynamic": true
    },
    {
      "name": "LONG_TERM_MEMORY",
      "description": "Persistent facts and preferences about the user learned and remembered across conversations",
      "position": 50,
      "dynamic": false
    },
    {
      "name": "SUMMARIZED_CONTEXT",
      "description": "Provides summarized context from previous conversations for optimized context usage",
      "position": 96,
      "dynamic": false
    },
    {
      "name": "AGENT_SETTINGS",
      "description": "Provides the agent's current configuration settings (filtered for security)",
      "dynamic": true
    },
    {
      "name": "CURRENT_TIME",
      "description": "Provides current time and date information in various formats",
      "dynamic": true
    }
  ]
}"""
_ALL_PROVIDER_DOCS_JSON = """{
  "version": "1.0.0",
  "providers": [
    {
      "name": "ACTIONS",
      "description": "Possible response actions",
      "position": -1,
      "dynamic": false
    },
    {
      "name": "CHARACTER",
      "description": "Provides the agent's character definition and personality information including bio, topics, adjectives, style directions, and example conversations",
      "dynamic": false
    },
    {
      "name": "RECENT_MESSAGES",
      "description": "Provides recent message history from the current conversation including formatted messages, posts, action results, and recent interactions",
      "position": 100,
      "dynamic": true
    },
    {
      "name": "ACTION_STATE",
      "description": "Provides information about the current action state and available actions",
      "dynamic": true
    },
    {
      "name": "ATTACHMENTS",
      "description": "Media attachments in the current message",
      "dynamic": true
    },
    {
      "name": "CAPABILITIES",
      "description": "Agent capabilities including models, services, and features",
      "dynamic": false
    },
    {
      "name": "CHOICE",
      "description": "Available choice options for selection when there are pending tasks or decisions",
      "dynamic": true
    },
    {
      "name": "CONTACTS",
      "description": "Provides contact information from the rolodex including categories and preferences",
      "dynamic": true
    },
    {
      "name": "CONTEXT_BENCH",
      "description": "Benchmark/task context injected by a benchmark harness",
      "position": 5,
      "dynamic": true
    },
    {
      "name": "ENTITIES",
      "description": "Provides information about entities in the current context including users, agents, and participants",
      "dynamic": true
    },
    {
      "name": "EVALUATORS",
      "description": "Available evaluators for assessing agent behavior",
      "dynamic": false
    },
    {
      "name": "FACTS",
      "description": "Provides known facts about entities learned through conversation",
      "dynamic": true
    },
    {
      "name": "FOLLOW_UPS",
      "description": "Provides information about upcoming follow-ups and reminders scheduled for contacts",
      "dynamic": true
    },
    {
      "name": "KNOWLEDGE",
      "description": "Provides relevant knowledge from the agent's knowledge base based on semantic similarity",
      "dynamic": true
    },
    {
      "name": "PROVIDERS",
      "description": "Available context providers",
      "dynamic": false
    },
    {
      "name": "RELATIONSHIPS",
      "description": "Relationships between entities observed by the agent including tags and metadata",
      "dynamic": true
    },
    {
      "name": "ROLES",
      "description": "Roles assigned to entities in the current context (Admin, Owner, Member, None)",
      "dynamic": true
    },
    {
      "name": "SETTINGS",
      "description": "Current settings for the agent/server (filtered for security, excludes sensitive keys)",
      "dynamic": true
    },
    {
      "name": "TIME",
      "description": "Provides the current date and time in UTC for time-based operations or responses",
      "dynamic": true
    },
    {
      "name": "WORLD",
      "description": "Provides information about the current world context including settings and members",
      "dynamic": true
    },
    {
      "name": "LONG_TERM_MEMORY",
      "description": "Persistent facts and preferences about the user learned and remembered across conversations",
      "position": 50,
      "dynamic": false
    },
    {
      "name": "SUMMARIZED_CONTEXT",
      "description": "Provides summarized context from previous conversations for optimized context usage",
      "position": 96,
      "dynamic": false
    },
    {
      "name": "AGENT_SETTINGS",
      "description": "Provides the agent's current configuration settings (filtered for security)",
      "dynamic": true
    },
    {
      "name": "CURRENT_TIME",
      "description": "Provides current time and date information in various formats",
      "dynamic": true
    }
  ]
}"""
_CORE_EVALUATOR_DOCS_JSON = """{
  "version": "1.0.0",
  "evaluators": [
    {
      "name": "REFLECTION",
      "description": "Generate a self-reflective thought on the conversation, then extract facts and relationships between entities in the conversation. Reflects on agent behavior and provides feedback for improvement.",
      "similes": [
        "REFLECT",
        "SELF_REFLECT",
        "EVALUATE_INTERACTION",
        "ASSESS_SITUATION"
      ],
      "alwaysRun": false,
      "examples": [
        {
          "prompt": "Agent Name: Sarah\\nAgent Role: Community Manager\\nRoom Type: group\\nCurrent Room: general-chat\\nMessage Sender: John (user-123)",
          "messages": [
            {
              "name": "John",
              "content": {
                "text": "Hey everyone, I'm new here!"
              }
            },
            {
              "name": "Sarah",
              "content": {
                "text": "Welcome John! How did you find our community?"
              }
            },
            {
              "name": "John",
              "content": {
                "text": "Through a friend who's really into AI"
              }
            }
          ],
          "outcome": "<response>\\n  <thought>I'm engaging appropriately with a new community member, maintaining a welcoming and professional tone. My questions are helping to learn more about John and make him feel welcome.</thought>\\n  <facts>\\n    <fact>\\n      <claim>John is new to the community</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n    <fact>\\n      <claim>John found the community through a friend interested in AI</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n  </facts>\\n  <relationships>\\n    <relationship>\\n      <sourceEntityId>sarah-agent</sourceEntityId>\\n      <targetEntityId>user-123</targetEntityId>\\n      <tags>group_interaction</tags>\\n    </relationship>\\n  </relationships>\\n</response>"
        },
        {
          "prompt": "Agent Name: Alex\\nAgent Role: Tech Support\\nRoom Type: group\\nCurrent Room: tech-help\\nMessage Sender: Emma (user-456)",
          "messages": [
            {
              "name": "Emma",
              "content": {
                "text": "My app keeps crashing when I try to upload files"
              }
            },
            {
              "name": "Alex",
              "content": {
                "text": "Have you tried clearing your cache?"
              }
            },
            {
              "name": "Emma",
              "content": {
                "text": "No response..."
              }
            },
            {
              "name": "Alex",
              "content": {
                "text": "Emma, are you still there? We can try some other troubleshooting steps."
              }
            }
          ],
          "outcome": "<response>\\n  <thought>I'm not sure if I'm being helpful or if Emma is frustrated with my suggestions. The lack of response is concerning - maybe I should have asked for more details about the issue first before jumping to solutions.</thought>\\n  <facts>\\n    <fact>\\n      <claim>Emma is having technical issues with file uploads</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n    <fact>\\n      <claim>Emma stopped responding after the first troubleshooting suggestion</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n  </facts>\\n  <relationships>\\n    <relationship>\\n      <sourceEntityId>alex-agent</sourceEntityId>\\n      <targetEntityId>user-456</targetEntityId>\\n      <tags>group_interaction,support_interaction,incomplete_interaction</tags>\\n    </relationship>\\n  </relationships>\\n</response>"
        },
        {
          "prompt": "Agent Name: Max\\nAgent Role: Discussion Facilitator\\nRoom Type: group\\nCurrent Room: book-club\\nMessage Sender: Lisa (user-789)",
          "messages": [
            {
              "name": "Lisa",
              "content": {
                "text": "What did everyone think about chapter 5?"
              }
            },
            {
              "name": "Max",
              "content": {
                "text": "The symbolism was fascinating! The red door clearly represents danger."
              }
            },
            {
              "name": "Max",
              "content": {
                "text": "And did anyone notice how the author used weather to reflect the protagonist's mood?"
              }
            },
            {
              "name": "Max",
              "content": {
                "text": "Plus the foreshadowing in the first paragraph was brilliant!"
              }
            },
            {
              "name": "Max",
              "content": {
                "text": "I also have thoughts about the character development..."
              }
            }
          ],
          "outcome": "<response>\\n  <thought>I'm dominating the conversation and not giving others a chance to share their perspectives. I've sent multiple messages in a row without waiting for responses. I need to step back and create space for other members to participate.</thought>\\n  <facts>\\n    <fact>\\n      <claim>The discussion is about chapter 5 of a book</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n    <fact>\\n      <claim>Max has sent 4 consecutive messages without user responses</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n  </facts>\\n  <relationships>\\n    <relationship>\\n      <sourceEntityId>max-agent</sourceEntityId>\\n      <targetEntityId>user-789</targetEntityId>\\n      <tags>group_interaction,excessive_interaction</tags>\\n    </relationship>\\n  </relationships>\\n</response>"
        }
      ]
    },
    {
      "name": "RELATIONSHIP_EXTRACTION",
      "description": "Passively extracts and updates relationship information from conversations. Identifies platform identities, relationship indicators, and mentioned third parties.",
      "similes": [
        "RELATIONSHIP_ANALYZER",
        "SOCIAL_GRAPH_BUILDER",
        "CONTACT_EXTRACTOR"
      ],
      "alwaysRun": false,
      "examples": [
        {
          "prompt": "User introduces themselves with social media",
          "messages": [
            {
              "name": "{{name1}}",
              "content": {
                "type": "text",
                "text": "Hi, I'm Sarah Chen. You can find me on X @sarahchen_dev"
              }
            }
          ],
          "outcome": "Extracts X handle and creates/updates the entity with a platform identity."
        }
      ]
    },
    {
      "name": "MEMORY_SUMMARIZATION",
      "description": "Automatically summarizes conversations to optimize context usage. Compresses conversation history while preserving important information.",
      "similes": [
        "CONVERSATION_SUMMARY",
        "CONTEXT_COMPRESSION",
        "MEMORY_OPTIMIZATION"
      ],
      "alwaysRun": true,
      "examples": []
    },
    {
      "name": "LONG_TERM_MEMORY_EXTRACTION",
      "description": "Extracts long-term facts about users from conversations. Identifies and stores persistent information like preferences, interests, and personal details.",
      "similes": [
        "MEMORY_EXTRACTION",
        "FACT_LEARNING",
        "USER_PROFILING"
      ],
      "alwaysRun": true,
      "examples": []
    }
  ]
}"""
_ALL_EVALUATOR_DOCS_JSON = """{
  "version": "1.0.0",
  "evaluators": [
    {
      "name": "REFLECTION",
      "description": "Generate a self-reflective thought on the conversation, then extract facts and relationships between entities in the conversation. Reflects on agent behavior and provides feedback for improvement.",
      "similes": [
        "REFLECT",
        "SELF_REFLECT",
        "EVALUATE_INTERACTION",
        "ASSESS_SITUATION"
      ],
      "alwaysRun": false,
      "examples": [
        {
          "prompt": "Agent Name: Sarah\\nAgent Role: Community Manager\\nRoom Type: group\\nCurrent Room: general-chat\\nMessage Sender: John (user-123)",
          "messages": [
            {
              "name": "John",
              "content": {
                "text": "Hey everyone, I'm new here!"
              }
            },
            {
              "name": "Sarah",
              "content": {
                "text": "Welcome John! How did you find our community?"
              }
            },
            {
              "name": "John",
              "content": {
                "text": "Through a friend who's really into AI"
              }
            }
          ],
          "outcome": "<response>\\n  <thought>I'm engaging appropriately with a new community member, maintaining a welcoming and professional tone. My questions are helping to learn more about John and make him feel welcome.</thought>\\n  <facts>\\n    <fact>\\n      <claim>John is new to the community</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n    <fact>\\n      <claim>John found the community through a friend interested in AI</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n  </facts>\\n  <relationships>\\n    <relationship>\\n      <sourceEntityId>sarah-agent</sourceEntityId>\\n      <targetEntityId>user-123</targetEntityId>\\n      <tags>group_interaction</tags>\\n    </relationship>\\n  </relationships>\\n</response>"
        },
        {
          "prompt": "Agent Name: Alex\\nAgent Role: Tech Support\\nRoom Type: group\\nCurrent Room: tech-help\\nMessage Sender: Emma (user-456)",
          "messages": [
            {
              "name": "Emma",
              "content": {
                "text": "My app keeps crashing when I try to upload files"
              }
            },
            {
              "name": "Alex",
              "content": {
                "text": "Have you tried clearing your cache?"
              }
            },
            {
              "name": "Emma",
              "content": {
                "text": "No response..."
              }
            },
            {
              "name": "Alex",
              "content": {
                "text": "Emma, are you still there? We can try some other troubleshooting steps."
              }
            }
          ],
          "outcome": "<response>\\n  <thought>I'm not sure if I'm being helpful or if Emma is frustrated with my suggestions. The lack of response is concerning - maybe I should have asked for more details about the issue first before jumping to solutions.</thought>\\n  <facts>\\n    <fact>\\n      <claim>Emma is having technical issues with file uploads</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n    <fact>\\n      <claim>Emma stopped responding after the first troubleshooting suggestion</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n  </facts>\\n  <relationships>\\n    <relationship>\\n      <sourceEntityId>alex-agent</sourceEntityId>\\n      <targetEntityId>user-456</targetEntityId>\\n      <tags>group_interaction,support_interaction,incomplete_interaction</tags>\\n    </relationship>\\n  </relationships>\\n</response>"
        },
        {
          "prompt": "Agent Name: Max\\nAgent Role: Discussion Facilitator\\nRoom Type: group\\nCurrent Room: book-club\\nMessage Sender: Lisa (user-789)",
          "messages": [
            {
              "name": "Lisa",
              "content": {
                "text": "What did everyone think about chapter 5?"
              }
            },
            {
              "name": "Max",
              "content": {
                "text": "The symbolism was fascinating! The red door clearly represents danger."
              }
            },
            {
              "name": "Max",
              "content": {
                "text": "And did anyone notice how the author used weather to reflect the protagonist's mood?"
              }
            },
            {
              "name": "Max",
              "content": {
                "text": "Plus the foreshadowing in the first paragraph was brilliant!"
              }
            },
            {
              "name": "Max",
              "content": {
                "text": "I also have thoughts about the character development..."
              }
            }
          ],
          "outcome": "<response>\\n  <thought>I'm dominating the conversation and not giving others a chance to share their perspectives. I've sent multiple messages in a row without waiting for responses. I need to step back and create space for other members to participate.</thought>\\n  <facts>\\n    <fact>\\n      <claim>The discussion is about chapter 5 of a book</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n    <fact>\\n      <claim>Max has sent 4 consecutive messages without user responses</claim>\\n      <type>fact</type>\\n      <in_bio>false</in_bio>\\n      <already_known>false</already_known>\\n    </fact>\\n  </facts>\\n  <relationships>\\n    <relationship>\\n      <sourceEntityId>max-agent</sourceEntityId>\\n      <targetEntityId>user-789</targetEntityId>\\n      <tags>group_interaction,excessive_interaction</tags>\\n    </relationship>\\n  </relationships>\\n</response>"
        }
      ]
    },
    {
      "name": "RELATIONSHIP_EXTRACTION",
      "description": "Passively extracts and updates relationship information from conversations. Identifies platform identities, relationship indicators, and mentioned third parties.",
      "similes": [
        "RELATIONSHIP_ANALYZER",
        "SOCIAL_GRAPH_BUILDER",
        "CONTACT_EXTRACTOR"
      ],
      "alwaysRun": false,
      "examples": [
        {
          "prompt": "User introduces themselves with social media",
          "messages": [
            {
              "name": "{{name1}}",
              "content": {
                "type": "text",
                "text": "Hi, I'm Sarah Chen. You can find me on X @sarahchen_dev"
              }
            }
          ],
          "outcome": "Extracts X handle and creates/updates the entity with a platform identity."
        }
      ]
    },
    {
      "name": "MEMORY_SUMMARIZATION",
      "description": "Automatically summarizes conversations to optimize context usage. Compresses conversation history while preserving important information.",
      "similes": [
        "CONVERSATION_SUMMARY",
        "CONTEXT_COMPRESSION",
        "MEMORY_OPTIMIZATION"
      ],
      "alwaysRun": true,
      "examples": []
    },
    {
      "name": "LONG_TERM_MEMORY_EXTRACTION",
      "description": "Extracts long-term facts about users from conversations. Identifies and stores persistent information like preferences, interests, and personal details.",
      "similes": [
        "MEMORY_EXTRACTION",
        "FACT_LEARNING",
        "USER_PROFILING"
      ],
      "alwaysRun": true,
      "examples": []
    }
  ]
}"""

core_action_docs: dict[str, object] = json.loads(_CORE_ACTION_DOCS_JSON)
all_action_docs: dict[str, object] = json.loads(_ALL_ACTION_DOCS_JSON)
core_provider_docs: dict[str, object] = json.loads(_CORE_PROVIDER_DOCS_JSON)
all_provider_docs: dict[str, object] = json.loads(_ALL_PROVIDER_DOCS_JSON)
core_evaluator_docs: dict[str, object] = json.loads(_CORE_EVALUATOR_DOCS_JSON)
all_evaluator_docs: dict[str, object] = json.loads(_ALL_EVALUATOR_DOCS_JSON)

__all__ = [
    "ActionDoc",
    "ActionDocExampleCall",
    "ActionDocExampleMessage",
    "ActionDocParameter",
    "ActionDocParameterSchema",
    "ActionDocParameterExampleValue",
    "ProviderDoc",
    "EvaluatorDoc",
    "EvaluatorDocExample",
    "EvaluatorDocMessage",
    "EvaluatorDocMessageContent",
    "core_actions_spec_version",
    "all_actions_spec_version",
    "core_providers_spec_version",
    "all_providers_spec_version",
    "core_evaluators_spec_version",
    "all_evaluators_spec_version",
    "core_action_docs",
    "all_action_docs",
    "core_provider_docs",
    "all_provider_docs",
    "core_evaluator_docs",
    "all_evaluator_docs",
]
