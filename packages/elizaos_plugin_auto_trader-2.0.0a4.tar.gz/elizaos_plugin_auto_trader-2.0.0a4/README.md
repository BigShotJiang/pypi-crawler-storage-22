# elizaos-plugin-auto-trader

elizaOS Auto Trader Plugin - automated trading strategies

## Installation

```bash
pip install elizaos-plugin-auto-trader
```

## Part of elizaOS

This is a Python plugin for the [elizaOS](https://github.com/elizaos/eliza) AI agent framework.

## License

MIT
