# elizaos-plugin-blooio

elizaOS Blooio Plugin - messaging via Blooio platform

## Installation

```bash
pip install elizaos-plugin-blooio
```

## Part of elizaOS

This is a Python plugin for the [elizaOS](https://github.com/elizaos/eliza) AI agent framework.

## License

MIT
