# elizaos-plugin-directives

elizaOS Directives Plugin - parse and manage agent directives

## Installation

```bash
pip install elizaos-plugin-directives
```

## Part of elizaOS

This is a Python plugin for the [elizaOS](https://github.com/elizaos/eliza) AI agent framework.

## License

MIT
