"""
ElizaOS Social Alpha Plugin — Python Implementation

Tracks token recommendations (shills/FUD) from users, builds trust scores
based on whether following their calls would have been profitable, and
exposes a Social Alpha Provider with win rate, rank, and analytics.
"""

from .plugin import social_alpha_plugin
from .types import (
    Conviction,
    RecommendationType,
    SupportedChain,
    Recommendation,
    UserTrustProfile,
    RecommendationMetric,
    LeaderboardEntry,
)

__version__ = "1.0.0"
__all__ = [
    "social_alpha_plugin",
    "Conviction",
    "RecommendationType",
    "SupportedChain",
    "Recommendation",
    "UserTrustProfile",
    "RecommendationMetric",
    "LeaderboardEntry",
]
