"""
Social Alpha Plugin — Main plugin export.

Registers the plugin with ElizaOS: service, provider, events.
"""

from __future__ import annotations

from .providers.social_alpha_provider import social_alpha_provider


# Plugin definition (duck-typed for now; will use elizaos.types.Plugin when available)
social_alpha_plugin = {
    "name": "social-alpha",
    "description": (
        "Tracks token shills and FUD, builds trust scores based on P&L outcomes, "
        "and provides a Social Alpha Provider with win rate, rank, and recommender analytics."
    ),
    "config": {
        "BIRDEYE_API_KEY": "",
        "DEXSCREENER_API_KEY": "",
        "HELIUS_API_KEY": "",
        "PROCESS_TRADE_DECISION_INTERVAL_HOURS": "1",
        "METRIC_REFRESH_INTERVAL_HOURS": "24",
        "USER_TRADE_COOLDOWN_HOURS": "12",
        "SCAM_PENALTY": "-100",
        "SCAM_CORRECT_CALL_BONUS": "100",
        "MAX_RECOMMENDATIONS_IN_PROFILE": "50",
    },
    "providers": [social_alpha_provider],
}
