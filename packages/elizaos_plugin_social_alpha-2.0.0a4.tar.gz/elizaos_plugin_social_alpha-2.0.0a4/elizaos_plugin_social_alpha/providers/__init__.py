"""Social Alpha providers."""

from .social_alpha_provider import social_alpha_provider

__all__ = ["social_alpha_provider"]
