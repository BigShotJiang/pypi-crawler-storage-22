"""
Social Alpha Provider — Python implementation.

Injects trust-score intelligence into agent context: win rate, rank,
P&L history, scam detection stats for each message sender.

Mirrors the TypeScript provider in
../typescript/src/providers/socialAlphaProvider.ts
"""

from __future__ import annotations

from ..types import (
    LeaderboardEntry,
    Recommendation,
    RecommendationType,
    UserTrustProfile,
)


def compute_recommender_stats(recommendations: list[Recommendation]) -> dict:
    """Compute summary stats for a set of recommendations."""
    total = len(recommendations)
    buy_calls = sum(1 for r in recommendations if r.recommendation_type == RecommendationType.BUY)
    sell_calls = total - buy_calls
    profitable = 0
    total_profit = 0.0
    scams_caught = 0
    rugs_promoted = 0
    best_call: dict | None = None
    worst_call: dict | None = None

    for rec in recommendations:
        if not rec.metrics:
            continue

        profit = rec.metrics.potential_profit_percent or rec.metrics.avoided_loss_percent or 0.0
        total_profit += profit
        if profit > 0:
            profitable += 1

        if rec.metrics.is_scam_or_rug:
            if rec.recommendation_type == RecommendationType.SELL:
                scams_caught += 1
            else:
                rugs_promoted += 1

        label = rec.token_ticker or rec.token_address[:8]
        if best_call is None or profit > best_call["profit"]:
            best_call = {"token": label, "profit": profit}
        if worst_call is None or profit < worst_call["profit"]:
            worst_call = {"token": label, "profit": profit}

    evaluated = sum(1 for r in recommendations if r.metrics is not None)
    win_rate = profitable / evaluated if evaluated > 0 else 0.0
    avg_profit = total_profit / evaluated if evaluated > 0 else 0.0

    return {
        "total_calls": total,
        "buy_calls": buy_calls,
        "sell_calls": sell_calls,
        "profitable_calls": profitable,
        "win_rate": win_rate,
        "average_profit": avg_profit,
        "best_call": best_call,
        "worst_call": worst_call,
        "scams_caught": scams_caught,
        "rugs_promoted": rugs_promoted,
    }


def format_leaderboard_entry(entry: LeaderboardEntry, detailed: bool = False) -> str:
    """Format a single leaderboard entry into readable text."""
    stats = compute_recommender_stats(entry.recommendations)
    win_pct = f"{stats['win_rate'] * 100:.1f}"
    avg_str = f"{stats['average_profit']:+.1f}%"
    name = entry.username or entry.user_id[:8]

    line = (
        f"#{entry.rank or '?'} {name} — Trust: {entry.trust_score:.1f} | "
        f"Win Rate: {win_pct}% | Avg P&L: {avg_str} | Calls: {stats['total_calls']}"
    )

    if detailed:
        parts = [
            f"  Buys: {stats['buy_calls']}, Sells/FUD: {stats['sell_calls']}",
            f"  Profitable: {stats['profitable_calls']}/{stats['total_calls']}",
        ]
        if stats["scams_caught"] > 0:
            parts.append(f"  Scams caught: {stats['scams_caught']}")
        if stats["rugs_promoted"] > 0:
            parts.append(f"  Rugs promoted: {stats['rugs_promoted']}")
        if stats["best_call"]:
            bp = stats["best_call"]
            parts.append(f"  Best: {bp['token']} ({bp['profit']:+.1f}%)")
        if stats["worst_call"]:
            wp = stats["worst_call"]
            parts.append(f"  Worst: {wp['token']} ({wp['profit']:+.1f}%)")
        line += "\n" + "\n".join(parts)

    return line


def social_alpha_provider(
    sender_profile: UserTrustProfile | None,
    leaderboard: list[LeaderboardEntry],
    sender_id: str,
) -> dict:
    """
    Generate provider output for injection into agent context.

    Args:
        sender_profile: Current speaker's trust profile (if they have one)
        leaderboard: Full leaderboard data
        sender_id: ID of the current message sender

    Returns:
        dict with "text" (human-readable) and "values" (structured data)
    """
    sections: list[str] = []
    values: dict[str, str] = {}

    # --- Sender's Trust Profile ---
    if sender_profile and sender_profile.recommendations:
        stats = compute_recommender_stats(sender_profile.recommendations)
        win_pct = f"{stats['win_rate'] * 100:.1f}"
        avg_str = f"{stats['average_profit']:+.1f}%"

        section = (
            f"[Current Speaker's Trust Profile]\n"
            f"Trust Score: {sender_profile.trust_score:.1f}/100\n"
            f"Win Rate: {win_pct}% ({stats['profitable_calls']}/{stats['total_calls']} calls)\n"
            f"Avg P&L: {avg_str}\n"
            f"Buy calls: {stats['buy_calls']} | Sell/FUD calls: {stats['sell_calls']}"
        )
        if stats["scams_caught"] > 0:
            section += f"\nScams correctly identified: {stats['scams_caught']}"
        if stats["rugs_promoted"] > 0:
            section += f"\nRugs promoted (trust penalty): {stats['rugs_promoted']}"
        sections.append(section)

        values["senderTrustScore"] = f"{sender_profile.trust_score:.1f}"
        values["senderTotalCalls"] = str(stats["total_calls"])
        values["senderWinRate"] = win_pct
        values["senderAvgProfit"] = f"{stats['average_profit']:.1f}"

    # --- Leaderboard Summary ---
    if leaderboard:
        top = leaderboard[:5]
        bottom = leaderboard[-3:] if len(leaderboard) > 5 else []

        top_lines = [format_leaderboard_entry(e) for e in top]
        lb_text = f"[Social Alpha Leaderboard — {len(leaderboard)} tracked]\n"
        lb_text += "Top Callers:\n" + "\n".join(top_lines)

        if bottom:
            bottom_lines = [format_leaderboard_entry(e) for e in bottom]
            lb_text += "\n\nLowest Trust:\n" + "\n".join(bottom_lines)

        # Find sender's rank
        for entry in leaderboard:
            if entry.user_id == sender_id and entry.rank:
                lb_text += f"\n\nCurrent speaker's rank: #{entry.rank} of {len(leaderboard)}"
                break

        sections.append(lb_text)

    values["trackedRecommenders"] = str(len(leaderboard))

    return {
        "text": "\n\n".join(sections) if sections else "",
        "values": values,
    }
