"""
Balanced Trust Score Calculator — Python implementation.

Mirrors the TypeScript BalancedTrustScoreCalculator in
../typescript/src/services/balancedTrustScoreCalculator.ts

Multi-component scoring: profit, win rate, Sharpe, alpha, consistency, quality.
Archetype-based scaling and volume adjustment.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class TrustScoreMetrics:
    """Input metrics for the trust score calculator."""
    total_calls: int
    profitable_calls: int
    average_profit: float
    win_rate: float
    sharpe_ratio: float
    alpha: float
    volume_penalty: float
    consistency: float


@dataclass
class BalancedTrustScoreParams:
    """Tunable parameters for the balanced trust score algorithm."""
    # Base weights (must sum to 1.0)
    profit_weight: float = 0.25
    win_rate_weight: float = 0.25
    sharpe_weight: float = 0.15
    alpha_weight: float = 0.10
    consistency_weight: float = 0.10
    quality_weight: float = 0.15

    # Volume thresholds
    normal_volume_threshold: int = 100
    high_volume_threshold: int = 300
    extreme_volume_threshold: int = 500

    # Archetype-specific volume multipliers
    volume_tolerance_by_archetype: dict[str, float] = field(default_factory=lambda: {
        "elite_analyst": 2.0,
        "skilled_trader": 1.5,
        "technical_analyst": 1.3,
        "contrarian": 1.0,
        "newbie": 0.8,
        "fomo_trader": 0.6,
        "pump_chaser": 0.5,
        "bot_spammer": 0.3,
        "rug_promoter": 0.3,
    })


# Archetype base scores
_ARCHETYPE_BASES: dict[str, float] = {
    "elite_analyst": 85,
    "skilled_trader": 65,
    "technical_analyst": 55,
    "contrarian": 50,
    "newbie": 35,
    "fomo_trader": 25,
    "pump_chaser": 20,
    "bot_spammer": 10,
    "rug_promoter": 5,
}

# Archetype performance scaling
_ARCHETYPE_SCALING: dict[str, float] = {
    "elite_analyst": 1.15,
    "skilled_trader": 1.10,
    "technical_analyst": 1.05,
    "contrarian": 1.0,
    "newbie": 0.95,
    "fomo_trader": 0.85,
    "pump_chaser": 0.75,
    "bot_spammer": 0.6,
    "rug_promoter": 0.5,
}


def _profit_component(avg_profit: float) -> float:
    if avg_profit > 50:
        return 90 + min(10, (avg_profit - 50) * 0.1)
    elif avg_profit > 20:
        return 70 + (avg_profit - 20) * 0.67
    elif avg_profit > 0:
        return 50 + avg_profit
    elif avg_profit > -30:
        return 30 + (avg_profit / 30) * 20
    else:
        return max(0, 30 + avg_profit * 0.3)


def _win_rate_component(win_rate: float) -> float:
    if win_rate >= 0.8:
        return 85 + (win_rate - 0.8) * 75
    elif win_rate >= 0.6:
        return 70 + (win_rate - 0.6) * 75
    elif win_rate >= 0.5:
        return 50 + (win_rate - 0.5) * 200
    elif win_rate >= 0.3:
        return 20 + (win_rate - 0.3) * 150
    else:
        return win_rate * 66.67


def _sharpe_component(sharpe: float) -> float:
    if sharpe > 1.5:
        return 90 + min(10, (sharpe - 1.5) * 10)
    elif sharpe > 0.5:
        return 60 + (sharpe - 0.5) * 30
    elif sharpe > 0:
        return 50 + sharpe * 20
    elif sharpe > -1:
        return 30 + sharpe * 20
    else:
        return max(0, 30 + sharpe * 10)


def _alpha_component(alpha: float) -> float:
    if alpha > 20:
        return 80 + min(20, (alpha - 20) * 0.5)
    elif alpha > 0:
        return 50 + alpha * 1.5
    elif alpha > -20:
        return 50 + alpha * 1.5
    else:
        return max(0, 50 + alpha * 0.5)


def _quality_component(rug_promotions: int, good_calls: int, total_calls: int) -> float:
    if total_calls == 0:
        return 50.0
    good_ratio = good_calls / total_calls
    rug_ratio = rug_promotions / total_calls
    quality = good_ratio * 100 - rug_ratio * 200
    if good_ratio > 0.5:
        quality += 20
    return max(0, min(100, quality))


def calculate_balanced_trust_score(
    metrics: TrustScoreMetrics,
    archetype: str,
    rug_promotions: int,
    good_calls: int,
    total_calls: int,
    params: BalancedTrustScoreParams | None = None,
) -> float:
    """
    Calculate a balanced trust score from 0-100.

    This is a direct port of the TypeScript BalancedTrustScoreCalculator.
    """
    if params is None:
        params = BalancedTrustScoreParams()

    # 1. Base score from archetype (40% weight)
    archetype_base = _ARCHETYPE_BASES.get(archetype, 30)

    # 2. Performance components
    components = {
        "profit": _profit_component(metrics.average_profit) * params.profit_weight,
        "win_rate": _win_rate_component(metrics.win_rate) * params.win_rate_weight,
        "sharpe": _sharpe_component(metrics.sharpe_ratio) * params.sharpe_weight,
        "alpha": _alpha_component(metrics.alpha) * params.alpha_weight,
        "consistency": metrics.consistency * 100 * params.consistency_weight,
        "quality": _quality_component(rug_promotions, good_calls, total_calls) * params.quality_weight,
    }

    # 3. Sum performance score
    performance_score = sum(components.values())

    # 4. Apply archetype scaling
    scaling = _ARCHETYPE_SCALING.get(archetype, 0.9)
    scaled_performance = performance_score * scaling

    # 5. Volume adjustment
    tolerance = params.volume_tolerance_by_archetype.get(archetype, 1.0)
    adj_normal = params.normal_volume_threshold * tolerance
    adj_high = params.high_volume_threshold * tolerance
    adj_extreme = params.extreme_volume_threshold * tolerance

    if total_calls <= adj_normal:
        volume_adj = 1.0
    elif total_calls <= adj_high:
        ratio = (total_calls - adj_normal) / (adj_high - adj_normal)
        volume_adj = 1.0 - ratio * 0.2
    elif total_calls <= adj_extreme:
        ratio = (total_calls - adj_high) / (adj_extreme - adj_high)
        volume_adj = 0.8 - ratio * 0.3
    else:
        volume_adj = 0.5

    # 6. Combine
    final_score = archetype_base * 0.4 + scaled_performance * 0.6
    final_score *= volume_adj

    # 7. Data sufficiency adjustment
    if total_calls < 5:
        final_score *= 0.8
    elif total_calls < 10:
        final_score *= 0.9

    return min(100, max(0, final_score))
