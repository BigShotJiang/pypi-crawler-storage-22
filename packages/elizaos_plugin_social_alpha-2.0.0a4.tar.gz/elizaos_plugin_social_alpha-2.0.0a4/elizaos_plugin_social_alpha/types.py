"""
Type definitions for the Social Alpha Plugin.

These types mirror the TypeScript definitions in ../typescript/src/types.ts
and the Rust definitions in ../rust/src/types.rs.
"""

from __future__ import annotations

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field


class Conviction(str, Enum):
    """Conviction levels for recommendations."""
    NONE = "NONE"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    VERY_HIGH = "VERY_HIGH"
    NEUTRAL = "NEUTRAL"


class RecommendationType(str, Enum):
    """Types of trading recommendations."""
    BUY = "BUY"
    DONT_BUY = "DONT_BUY"
    SELL = "SELL"
    DONT_SELL = "DONT_SELL"
    NONE = "NONE"
    HOLD = "HOLD"


class SupportedChain(str, Enum):
    """Supported cryptocurrency chains."""
    SOLANA = "SOLANA"
    ETHEREUM = "ETHEREUM"
    BASE = "BASE"
    UNKNOWN = "UNKNOWN"


class RecommendationMetric(BaseModel):
    """Metrics calculated after observing a recommendation's market performance."""
    potential_profit_percent: Optional[float] = None
    avoided_loss_percent: Optional[float] = None
    is_scam_or_rug: Optional[bool] = None
    evaluation_timestamp: int = 0
    notes: Optional[str] = None


class Recommendation(BaseModel):
    """A single recommendation or criticism made by a user."""
    id: str
    user_id: str
    message_id: str
    timestamp: int
    token_ticker: Optional[str] = None
    token_address: str
    chain: SupportedChain = SupportedChain.UNKNOWN
    recommendation_type: RecommendationType = RecommendationType.BUY
    conviction: Conviction = Conviction.MEDIUM
    raw_message_quote: str = ""
    price_at_recommendation: Optional[float] = None
    metrics: Optional[RecommendationMetric] = None
    processed_for_trade_decision: bool = False


class UserTrustProfile(BaseModel):
    """Data structure for the component stored on an Entity."""
    version: str = "1.0.0"
    user_id: str
    trust_score: float = 0.0
    last_trust_score_calculation_timestamp: int = 0
    last_trade_decision_made_timestamp: Optional[int] = None
    recommendations: list[Recommendation] = Field(default_factory=list)


class LeaderboardEntry(BaseModel):
    """Data structure for frontend leaderboard entries."""
    rank: Optional[int] = None
    user_id: str
    username: Optional[str] = None
    trust_score: float
    recommendations: list[Recommendation] = Field(default_factory=list)


class TokenAPIData(BaseModel):
    """Structure for data fetched from external token APIs."""
    name: Optional[str] = None
    symbol: Optional[str] = None
    current_price: Optional[float] = None
    ath: Optional[float] = None
    atl: Optional[float] = None
    price_history: list[dict[str, float]] = Field(default_factory=list)
    liquidity: Optional[float] = None
    market_cap: Optional[float] = None
    is_known_scam: Optional[bool] = None


class MessageRecommendation(BaseModel):
    """Message recommendation extracted from text."""
    token_mentioned: str
    is_ticker: bool
    sentiment: str  # "positive" | "negative" | "neutral"
    conviction: str  # "NONE" | "LOW" | "MEDIUM" | "HIGH"
    quote: str
