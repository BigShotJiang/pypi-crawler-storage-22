"""Tests for the balanced trust score calculator."""

import pytest
from elizaos_plugin_social_alpha.trust_score import (
    BalancedTrustScoreParams,
    TrustScoreMetrics,
    calculate_balanced_trust_score,
)


def _make_metrics(**overrides) -> TrustScoreMetrics:
    defaults = {
        "total_calls": 20,
        "profitable_calls": 12,
        "average_profit": 15.0,
        "win_rate": 0.60,
        "sharpe_ratio": 0.8,
        "alpha": 10.0,
        "volume_penalty": 0.0,
        "consistency": 0.7,
    }
    defaults.update(overrides)
    return TrustScoreMetrics(**defaults)


class TestBalancedTrustScore:
    def test_elite_analyst_gets_high_score(self):
        metrics = _make_metrics(win_rate=0.75, average_profit=35.0, sharpe_ratio=1.5)
        score = calculate_balanced_trust_score(
            metrics, archetype="elite_analyst", rug_promotions=0, good_calls=15, total_calls=20
        )
        assert score > 70, f"Elite analyst should score >70, got {score:.1f}"

    def test_rug_promoter_gets_low_score(self):
        metrics = _make_metrics(win_rate=0.20, average_profit=-30.0, sharpe_ratio=-0.5)
        score = calculate_balanced_trust_score(
            metrics, archetype="rug_promoter", rug_promotions=8, good_calls=2, total_calls=20
        )
        assert score < 30, f"Rug promoter should score <30, got {score:.1f}"

    def test_newbie_with_few_calls_gets_reduced_score(self):
        metrics = _make_metrics(total_calls=3, win_rate=0.67, average_profit=20.0)
        score = calculate_balanced_trust_score(
            metrics, archetype="newbie", rug_promotions=0, good_calls=2, total_calls=3
        )
        # 20% reduction for < 5 calls
        full_score = calculate_balanced_trust_score(
            _make_metrics(total_calls=20, win_rate=0.67, average_profit=20.0),
            archetype="newbie", rug_promotions=0, good_calls=13, total_calls=20
        )
        assert score < full_score, "Newbie with few calls should score lower"

    def test_score_is_bounded_0_to_100(self):
        # Extreme positive
        metrics_high = _make_metrics(win_rate=1.0, average_profit=100.0, sharpe_ratio=3.0, alpha=50.0, consistency=1.0)
        score_high = calculate_balanced_trust_score(
            metrics_high, "elite_analyst", 0, 20, 20
        )
        assert 0 <= score_high <= 100

        # Extreme negative
        metrics_low = _make_metrics(win_rate=0.0, average_profit=-100.0, sharpe_ratio=-3.0, alpha=-50.0, consistency=0.0)
        score_low = calculate_balanced_trust_score(
            metrics_low, "rug_promoter", 20, 0, 20
        )
        assert 0 <= score_low <= 100

    def test_high_volume_reduces_score(self):
        metrics = _make_metrics(total_calls=600)
        score_normal = calculate_balanced_trust_score(
            _make_metrics(total_calls=50), "skilled_trader", 0, 30, 50
        )
        score_spam = calculate_balanced_trust_score(
            metrics, "skilled_trader", 0, 360, 600
        )
        assert score_spam < score_normal, "High volume should reduce score"

    def test_custom_params(self):
        metrics = _make_metrics()
        params = BalancedTrustScoreParams(profit_weight=0.50, win_rate_weight=0.50,
                                           sharpe_weight=0, alpha_weight=0,
                                           consistency_weight=0, quality_weight=0)
        score = calculate_balanced_trust_score(
            metrics, "skilled_trader", 0, 12, 20, params=params
        )
        assert 0 <= score <= 100


class TestProviderStats:
    def test_compute_stats_empty(self):
        from elizaos_plugin_social_alpha.providers.social_alpha_provider import compute_recommender_stats
        stats = compute_recommender_stats([])
        assert stats["total_calls"] == 0
        assert stats["win_rate"] == 0.0

    def test_compute_stats_with_recommendations(self):
        from elizaos_plugin_social_alpha.providers.social_alpha_provider import compute_recommender_stats
        from elizaos_plugin_social_alpha.types import Recommendation, RecommendationMetric

        recs = [
            Recommendation(
                id="r1", user_id="u1", message_id="m1", timestamp=1000,
                token_address="addr1", recommendation_type="BUY",
                metrics=RecommendationMetric(potential_profit_percent=25.0, evaluation_timestamp=2000),
            ),
            Recommendation(
                id="r2", user_id="u1", message_id="m2", timestamp=1001,
                token_address="addr2", recommendation_type="BUY",
                metrics=RecommendationMetric(potential_profit_percent=-15.0, evaluation_timestamp=2001),
            ),
        ]
        stats = compute_recommender_stats(recs)
        assert stats["total_calls"] == 2
        assert stats["profitable_calls"] == 1
        assert stats["win_rate"] == 0.5
        assert stats["average_profit"] == 5.0  # (25 + -15) / 2
