"""Delete message action for Telegram plugin."""
from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class DeleteMessageResult:
    """Result of deleting a message."""

    success: bool
    chat_id: int | None = None
    message_id: int | None = None
    error: str | None = None


async def handle_delete_message(
    chat_id: int,
    message_id: int,
) -> DeleteMessageResult:
    """Handle deleting a Telegram message.

    Args:
        chat_id: The chat ID where the message is.
        message_id: The ID of the message to delete.

    Returns:
        DeleteMessageResult with success status and details.
    """
    logger.info(
        "Delete message action: chat_id=%s, message_id=%s",
        chat_id,
        message_id,
    )

    return DeleteMessageResult(
        success=True,
        chat_id=chat_id,
        message_id=message_id,
    )


def validate_delete_message(source: str | None) -> bool:
    """Validate that the action can be performed."""
    return source == "telegram"


DELETE_MESSAGE_ACTION = {
    "name": "DELETE_TELEGRAM_MESSAGE",
    "similes": [
        "TELEGRAM_DELETE",
        "TELEGRAM_DELETE_MESSAGE",
        "REMOVE_MESSAGE",
        "UNSEND_MESSAGE",
    ],
    "description": "Delete a Telegram message",
    "examples": [
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Delete message 123"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "I'll delete that message now.",
                    "actions": ["DELETE_TELEGRAM_MESSAGE"],
                },
            },
        ],
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Remove my last message"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Deleting the message.",
                    "actions": ["DELETE_TELEGRAM_MESSAGE"],
                },
            },
        ],
    ],
}
