"""Edit message action for Telegram plugin."""
from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class EditMessageResult:
    """Result of editing a message."""

    success: bool
    chat_id: int | None = None
    message_id: int | None = None
    new_text: str | None = None
    error: str | None = None


async def handle_edit_message(
    chat_id: int,
    message_id: int,
    text: str,
) -> EditMessageResult:
    """Handle editing a Telegram message.

    Args:
        chat_id: The chat ID where the message is.
        message_id: The ID of the message to edit.
        text: The new text content for the message.

    Returns:
        EditMessageResult with success status and details.
    """
    logger.info(
        "Edit message action: chat_id=%s, message_id=%s, text=%s",
        chat_id,
        message_id,
        text[:50],
    )

    return EditMessageResult(
        success=True,
        chat_id=chat_id,
        message_id=message_id,
        new_text=text,
    )


def validate_edit_message(source: str | None) -> bool:
    """Validate that the action can be performed."""
    return source == "telegram"


EDIT_MESSAGE_ACTION = {
    "name": "EDIT_TELEGRAM_MESSAGE",
    "similes": [
        "TELEGRAM_EDIT",
        "TELEGRAM_EDIT_MESSAGE",
        "UPDATE_MESSAGE",
        "MODIFY_MESSAGE",
    ],
    "description": "Edit an existing Telegram message",
    "examples": [
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Edit message 123 to say 'Hello updated!'"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "I'll edit that message now.",
                    "actions": ["EDIT_TELEGRAM_MESSAGE"],
                },
            },
        ],
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Change my last message to 'Fixed typo'"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Updating the message content.",
                    "actions": ["EDIT_TELEGRAM_MESSAGE"],
                },
            },
        ],
    ],
}
