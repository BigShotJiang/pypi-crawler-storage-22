"""Send sticker action for Telegram plugin."""
from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class SendStickerResult:
    """Result of sending a sticker."""

    success: bool
    chat_id: int | str | None = None
    message_id: int | None = None
    file_id: str | None = None
    error: str | None = None


async def handle_send_sticker(
    chat_id: int | str,
    sticker: str,
    reply_to_message_id: int | None = None,
    thread_id: int | None = None,
) -> SendStickerResult:
    """Handle sending a sticker to a Telegram chat.

    Args:
        chat_id: The chat ID to send the sticker to.
        sticker: The sticker file_id to send.
        reply_to_message_id: Optional message ID to reply to.
        thread_id: Optional thread/topic ID for forum chats.

    Returns:
        SendStickerResult with success status and details.
    """
    logger.info(
        "Send sticker action: chat_id=%s, sticker=%s",
        chat_id,
        sticker[:30] if sticker else "",
    )

    return SendStickerResult(
        success=True,
        chat_id=chat_id,
        file_id=sticker,
    )


def validate_send_sticker(source: str | None) -> bool:
    """Validate that the action can be performed."""
    return source == "telegram"


SEND_STICKER_ACTION = {
    "name": "SEND_TELEGRAM_STICKER",
    "similes": [
        "TELEGRAM_STICKER",
        "TELEGRAM_SEND_STICKER",
        "POST_STICKER",
    ],
    "description": (
        "Send a sticker to a Telegram chat. Requires a sticker file_id. "
        "To get a sticker's file_id, forward the sticker to @RawDataBot on Telegram."
    ),
    "examples": [
        [
            {
                "name": "{{name1}}",
                "content": {
                    "text": "Send sticker CAACAgIAAxkBAAIBXGVc... (with actual file_id)",
                },
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "I'll send that sticker now.",
                    "actions": ["SEND_TELEGRAM_STICKER"],
                },
            },
        ],
        [
            {
                "name": "{{name1}}",
                "content": {"text": "How do I get a sticker file_id?"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": (
                        "To get a sticker's file_id, forward the sticker to "
                        "@RawDataBot on Telegram. It will reply with the "
                        "sticker's file_id that you can use with me."
                    ),
                },
            },
        ],
    ],
}
