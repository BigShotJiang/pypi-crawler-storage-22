# elizaos-plugin-tlon

Tlon/Urbit plugin for elizaOS - Python implementation with SSE support

## Installation

```bash
pip install elizaos-plugin-tlon
```

## Part of elizaOS

This is a Python plugin for the [elizaOS](https://github.com/elizaos/eliza) AI agent framework.

## License

MIT
