"""Tests for Tlon plugin actions."""

from __future__ import annotations

import pytest

from elizaos_plugin_tlon.actions import (
    SEND_MESSAGE_ACTION,
    SendMessageResult,
    handle_send_message,
    validate_send_message,
)


# ---------------------------------------------------------------------------
# SEND_MESSAGE_ACTION metadata
# ---------------------------------------------------------------------------
class TestSendMessageActionMetadata:
    def test_action_name(self) -> None:
        assert SEND_MESSAGE_ACTION["name"] == "SEND_TLON_MESSAGE"

    def test_has_8_similes_with_key_aliases(self) -> None:
        similes = SEND_MESSAGE_ACTION["similes"]
        assert len(similes) == 8
        for expected in ["TLON_SEND_MESSAGE", "SEND_TLON", "URBIT_SEND_MESSAGE", "SEND_URBIT"]:
            assert expected in similes

    def test_description_mentions_tlon_or_urbit(self) -> None:
        desc = SEND_MESSAGE_ACTION["description"].lower()
        assert "tlon" in desc or "urbit" in desc

    def test_examples_have_paired_messages(self) -> None:
        examples = SEND_MESSAGE_ACTION["examples"]
        assert len(examples) >= 2
        for example in examples:
            assert len(example) == 2
            assert "SEND_TLON_MESSAGE" in example[1]["content"]["actions"]


# ---------------------------------------------------------------------------
# validate_send_message
# ---------------------------------------------------------------------------
class TestValidateSendMessage:
    @pytest.mark.parametrize("source,expected", [
        ("tlon", True),
        ("urbit", True),
        ("discord", False),
        ("telegram", False),
        (None, False),
        ("", False),
    ])
    def test_source_validation(self, source, expected: bool) -> None:
        assert validate_send_message(source) is expected


# ---------------------------------------------------------------------------
# SendMessageResult dataclass
# ---------------------------------------------------------------------------
class TestSendMessageResult:
    def test_success_result(self) -> None:
        result = SendMessageResult(
            success=True, text="Hello",
            message_id="msg-123", target="sampel-palnet",
        )
        assert result.success is True
        assert result.text == "Hello"
        assert result.message_id == "msg-123"
        assert result.target == "sampel-palnet"
        assert result.error is None

    def test_failure_result(self) -> None:
        result = SendMessageResult(success=False, text="", error="Something went wrong")
        assert result.success is False
        assert result.error == "Something went wrong"
        assert result.message_id is None

    def test_defaults_are_none(self) -> None:
        result = SendMessageResult(success=True, text="hi")
        assert result.message_id is None
        assert result.target is None
        assert result.error is None


# ---------------------------------------------------------------------------
# handle_send_message
# ---------------------------------------------------------------------------
class TestHandleSendMessage:
    @pytest.mark.asyncio()
    async def test_returns_success_result(self) -> None:
        result = await handle_send_message(target="sampel-palnet", text="Hello from test")
        assert result.success is True
        assert result.text == "Hello from test"
        assert result.target == "sampel-palnet"

    @pytest.mark.asyncio()
    async def test_dm_flag_does_not_change_success(self) -> None:
        result = await handle_send_message(target="sampel-palnet", text="DM test", is_dm=True)
        assert result.success is True

    @pytest.mark.asyncio()
    async def test_reply_to_id_is_accepted(self) -> None:
        result = await handle_send_message(
            target="chat/~host/channel", text="Thread reply",
            is_dm=False, reply_to_id="parent-id",
        )
        assert result.success is True
        assert result.target == "chat/~host/channel"

    @pytest.mark.asyncio()
    async def test_long_text_is_preserved(self) -> None:
        long_text = "A" * 5000
        result = await handle_send_message(target="ship", text=long_text)
        assert result.text == long_text
