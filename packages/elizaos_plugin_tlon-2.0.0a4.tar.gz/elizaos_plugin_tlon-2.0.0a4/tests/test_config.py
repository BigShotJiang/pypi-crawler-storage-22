"""Tests for Tlon plugin configuration and error types."""

from __future__ import annotations

import os
from unittest import mock

import pytest
from pydantic import ValidationError

from elizaos_plugin_tlon.config import (
    TlonConfig,
    build_channel_nest,
    format_ship,
    normalize_ship,
    parse_channel_nest,
)
from elizaos_plugin_tlon.error import (
    AuthenticationError,
    ClientNotInitializedError,
    ConfigError,
    ConnectionError,
    MessageSendError,
    PokeError,
    ScryError,
    SubscribeError,
    TlonError,
)


# ---------------------------------------------------------------------------
# normalize_ship / format_ship
# ---------------------------------------------------------------------------
class TestNormalizeShip:
    @pytest.mark.parametrize("input_val,expected", [
        ("~sampel-palnet", "sampel-palnet"),
        ("sampel-palnet", "sampel-palnet"),
        ("~~double", "double"),
        ("", ""),
    ])
    def test_normalize(self, input_val: str, expected: str) -> None:
        assert normalize_ship(input_val) == expected


class TestFormatShip:
    @pytest.mark.parametrize("input_val,expected", [
        ("sampel-palnet", "~sampel-palnet"),
        ("~sampel-palnet", "~sampel-palnet"),
        ("", "~"),
    ])
    def test_format(self, input_val: str, expected: str) -> None:
        assert format_ship(input_val) == expected


# ---------------------------------------------------------------------------
# parse_channel_nest / build_channel_nest
# ---------------------------------------------------------------------------
class TestParseChannelNest:
    def test_valid_nest(self) -> None:
        kind, host, name = parse_channel_nest("chat/~host-ship/channel-name")
        assert (kind, host, name) == ("chat", "host-ship", "channel-name")

    def test_normalizes_host_ship(self) -> None:
        assert parse_channel_nest("diary/~my-ship/notes")[1] == "my-ship"

    @pytest.mark.parametrize("nest", ["single", "only/two", "a/b/c/d", "//", "/host/name"])
    def test_returns_none_for_invalid(self, nest: str) -> None:
        assert parse_channel_nest(nest) is None


class TestBuildChannelNest:
    @pytest.mark.parametrize("host", ["host-ship", "~host-ship"])
    def test_builds_correct_string(self, host: str) -> None:
        assert build_channel_nest("chat", host, "general") == "chat/~host-ship/general"


# ---------------------------------------------------------------------------
# TlonConfig
# ---------------------------------------------------------------------------
class TestTlonConfig:
    def test_creation_normalizes_and_strips(self) -> None:
        config = TlonConfig(
            ship="~sampel-palnet",
            url="https://sampel-palnet.tlon.network/",
            code="lidlut-tabwed",
        )
        assert config.ship == "sampel-palnet"
        assert config.url == "https://sampel-palnet.tlon.network"
        assert config.code == "lidlut-tabwed"

    def test_defaults(self) -> None:
        config = TlonConfig(ship="ship", url="https://example.com", code="code")
        assert config.enabled is True
        assert config.group_channels == []
        assert config.dm_allowlist == []
        assert config.auto_discover_channels is True

    def test_url_strips_multiple_trailing_slashes(self) -> None:
        config = TlonConfig(ship="s", url="https://x.com///", code="c")
        assert not config.url.endswith("/")

    def test_dm_allowlist_normalized(self) -> None:
        config = TlonConfig(
            ship="s", url="https://x.com", code="c",
            dm_allowlist=["~ship-a", "ship-b"],
        )
        assert config.dm_allowlist == ["ship-a", "ship-b"]

    def test_formatted_ship(self) -> None:
        config = TlonConfig(ship="sampel-palnet", url="https://x.com", code="c")
        assert config.formatted_ship() == "~sampel-palnet"


class TestTlonConfigDmAllowed:
    def test_empty_allowlist_allows_all(self) -> None:
        config = TlonConfig(ship="s", url="https://x.com", code="c")
        assert config.is_dm_allowed("any-ship") is True

    @pytest.mark.parametrize("ship,allowed,expected", [
        ("allowed-ship", ["allowed-ship"], True),
        ("random-ship", ["allowed-ship"], False),
        ("~allowed-ship", ["allowed-ship"], True),
    ])
    def test_allowlist_check(self, ship: str, allowed: list, expected: bool) -> None:
        config = TlonConfig(ship="s", url="https://x.com", code="c", dm_allowlist=allowed)
        assert config.is_dm_allowed(ship) is expected


class TestTlonConfigFromEnv:
    def test_loads_required_vars(self) -> None:
        env = {
            "TLON_SHIP": "~sampel-palnet",
            "TLON_URL": "https://example.com",
            "TLON_CODE": "secret-code",
        }
        with mock.patch.dict(os.environ, env, clear=False):
            config = TlonConfig.from_env()
        assert config.ship == "sampel-palnet"
        assert config.url == "https://example.com"
        assert config.code == "secret-code"
        assert config.enabled is True

    @pytest.mark.parametrize("missing,env", [
        ("TLON_SHIP", {"TLON_URL": "https://example.com", "TLON_CODE": "code"}),
        ("TLON_URL", {"TLON_SHIP": "ship", "TLON_CODE": "code"}),
        ("TLON_CODE", {"TLON_SHIP": "ship", "TLON_URL": "https://example.com"}),
    ])
    def test_raises_for_missing_required(self, missing: str, env: dict) -> None:
        with mock.patch.dict(os.environ, env, clear=True), pytest.raises(ValueError, match=missing):
            TlonConfig.from_env()

    def test_parses_optional_enabled_false(self) -> None:
        env = {
            "TLON_SHIP": "ship", "TLON_URL": "https://example.com",
            "TLON_CODE": "code", "TLON_ENABLED": "false",
        }
        with mock.patch.dict(os.environ, env, clear=False):
            assert TlonConfig.from_env().enabled is False

    def test_parses_group_channels_json(self) -> None:
        env = {
            "TLON_SHIP": "ship", "TLON_URL": "https://example.com",
            "TLON_CODE": "code",
            "TLON_GROUP_CHANNELS": '["chat/~host/general","chat/~host/random"]',
        }
        with mock.patch.dict(os.environ, env, clear=False):
            assert TlonConfig.from_env().group_channels == [
                "chat/~host/general", "chat/~host/random",
            ]

    def test_invalid_json_for_channels_yields_empty(self) -> None:
        env = {
            "TLON_SHIP": "ship", "TLON_URL": "https://example.com",
            "TLON_CODE": "code", "TLON_GROUP_CHANNELS": "not-json",
        }
        with mock.patch.dict(os.environ, env, clear=False):
            assert TlonConfig.from_env().group_channels == []

    def test_auto_discover_false(self) -> None:
        env = {
            "TLON_SHIP": "ship", "TLON_URL": "https://example.com",
            "TLON_CODE": "code", "TLON_AUTO_DISCOVER_CHANNELS": "false",
        }
        with mock.patch.dict(os.environ, env, clear=False):
            assert TlonConfig.from_env().auto_discover_channels is False


# ---------------------------------------------------------------------------
# Error types
# ---------------------------------------------------------------------------
class TestErrorHierarchy:
    def test_tlon_error_is_exception(self) -> None:
        assert issubclass(TlonError, Exception)

    @pytest.mark.parametrize("cls,msg", [
        (ConfigError, "bad config"),
        (AuthenticationError, "auth failed"),
        (ConnectionError, "conn failed"),
        (SubscribeError, "sub failed"),
        (PokeError, "poke failed"),
        (ScryError, "scry failed"),
    ])
    def test_subclass_is_tlon_error(self, cls, msg: str) -> None:
        err = cls(msg)
        assert isinstance(err, TlonError)
        assert msg in str(err)

    def test_client_not_initialized_default_message(self) -> None:
        err = ClientNotInitializedError()
        assert isinstance(err, TlonError)
        assert str(err) == "Tlon client is not initialized"

    def test_message_send_error_attributes(self) -> None:
        err = MessageSendError("sampel-palnet")
        assert isinstance(err, TlonError)
        assert "sampel-palnet" in str(err)
        assert err.target == "sampel-palnet"
        assert err.cause is None

    def test_message_send_error_with_cause(self) -> None:
        cause = RuntimeError("network timeout")
        err = MessageSendError("chat/~host/ch", cause)
        assert "network timeout" in str(err)
        assert err.cause is cause

    def test_message_send_error_catchable_as_tlon_error(self) -> None:
        with pytest.raises(TlonError):
            raise MessageSendError("target", RuntimeError("boom"))
