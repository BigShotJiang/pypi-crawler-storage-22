"""
Action-Level Instrumentation.

Wraps actions and providers with trajectory logging so every handler
invocation is automatically recorded as a trajectory step.
"""

from __future__ import annotations

import copy
import json
import logging
import time
import uuid
from dataclasses import dataclass
from typing import Any

from elizaos_plugin_trajectory_logger.service import TrajectoryLoggerService
from elizaos_plugin_trajectory_logger.types import (
    ActionAttempt,
    LLMCall,
    ProviderAccess,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Trajectory context management
# ---------------------------------------------------------------------------


@dataclass
class TrajectoryContext:
    """Associates a trajectory id with a logger service for a given runtime."""

    trajectory_id: str
    logger_service: TrajectoryLoggerService


# Keyed by ``id(runtime)`` – callers must invoke ``clear_trajectory_context``
# when the runtime is no longer in use to prevent stale entries.
_trajectory_contexts: dict[int, TrajectoryContext] = {}


def set_trajectory_context(
    runtime: Any,
    trajectory_id: str,
    trajectory_logger: TrajectoryLoggerService,
) -> None:
    """Bind a trajectory context to a runtime object."""
    _trajectory_contexts[id(runtime)] = TrajectoryContext(
        trajectory_id=trajectory_id,
        logger_service=trajectory_logger,
    )


def get_trajectory_context(runtime: Any) -> TrajectoryContext | None:
    """Retrieve the trajectory context bound to *runtime*, if any."""
    return _trajectory_contexts.get(id(runtime))


def clear_trajectory_context(runtime: Any) -> None:
    """Remove the trajectory context for *runtime*."""
    _trajectory_contexts.pop(id(runtime), None)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _safe_snapshot(obj: Any) -> Any:
    """Return a JSON-safe deep copy, falling back to ``str()`` on failure."""
    try:
        return json.loads(json.dumps(obj, default=str))
    except (TypeError, ValueError, OverflowError):
        return str(obj)


def _extract_message_text(message: Any) -> str:
    """Best-effort extraction of the text payload from a message object."""
    content = getattr(message, "content", None)
    if content is None:
        return ""
    if isinstance(content, dict):
        return str(content.get("text", ""))
    return str(getattr(content, "text", "") or "")


# ---------------------------------------------------------------------------
# Action wrapping
# ---------------------------------------------------------------------------


class WrappedAction:
    """Wraps an action handler to log trajectory steps on success/failure.

    All original attributes (``name``, ``description``, ``validate``,
    ``examples``, ``similes``, …) are preserved; only the ``handler`` is
    overridden.
    """

    def __init__(self, original: Any, service: TrajectoryLoggerService) -> None:
        self._original = original
        self._service = service

        # Mirror public attributes from the original action.
        self.name: str = getattr(original, "name", "")
        self.description: str = getattr(original, "description", "")
        for attr in ("validate", "examples", "similes"):
            if hasattr(original, attr):
                setattr(self, attr, getattr(original, attr))

    async def handler(
        self,
        runtime: Any,
        message: Any,
        state: Any | None = None,
        options: Any | None = None,
        callback: Any | None = None,
    ) -> Any:
        """Wrapped handler that logs trajectory steps around the original call."""
        context = get_trajectory_context(runtime)
        if context is None:
            return await self._original.handler(runtime, message, state, options, callback)

        trajectory_id = context.trajectory_id
        svc = context.logger_service
        step_id = svc.get_current_step_id(trajectory_id)

        if step_id is None:
            logger.warning(
                "No active step for action execution: action=%s trajectory=%s",
                self.name,
                trajectory_id,
            )
            return await self._original.handler(runtime, message, state, options, callback)

        try:
            result = await self._original.handler(runtime, message, state, options, callback)
            self._complete_success(svc, trajectory_id, step_id, message, state)
            return result
        except Exception as exc:
            self._complete_error(svc, trajectory_id, step_id, message, state, exc)
            raise

    # -- private helpers ---------------------------------------------------

    def _complete_success(
        self,
        svc: TrajectoryLoggerService,
        trajectory_id: str,
        step_id: str,
        message: Any,
        state: Any,
    ) -> None:
        state_snapshot = _safe_snapshot(state) if state is not None else None
        message_text = _extract_message_text(message)

        svc.complete_step(
            trajectory_id,
            step_id,
            action=ActionAttempt(
                attempt_id=str(uuid.uuid4()),
                timestamp=int(time.time() * 1000),
                action_type=self.name,
                action_name=self.name,
                parameters={
                    "message": message_text,
                    "state": state_snapshot,
                },
                reasoning=f"Action {self.name} executed via {self.description or 'handler'}",
                success=True,
                result={"executed": True},
            ),
            reward=0.1,
        )

    def _complete_error(
        self,
        svc: TrajectoryLoggerService,
        trajectory_id: str,
        step_id: str,
        message: Any,
        state: Any,
        error: Exception,
    ) -> None:
        error_msg = str(error)
        logger.error(
            "Action execution failed: action=%s trajectory=%s error=%s",
            self.name,
            trajectory_id,
            error_msg,
        )
        state_snapshot = _safe_snapshot(state) if state is not None else None
        message_text = _extract_message_text(message)

        svc.complete_step(
            trajectory_id,
            step_id,
            action=ActionAttempt(
                attempt_id=str(uuid.uuid4()),
                timestamp=int(time.time() * 1000),
                action_type=self.name,
                action_name=self.name,
                parameters={
                    "message": message_text,
                    "state": state_snapshot,
                },
                reasoning=f"Action {self.name} failed: {error_msg}",
                success=False,
                result={"error": error_msg},
            ),
            reward=-0.1,
        )


def wrap_action_with_logging(
    action: Any,
    service: TrajectoryLoggerService,
) -> WrappedAction:
    """Wrap a single action's handler to log trajectory steps."""
    return WrappedAction(action, service)


def wrap_plugin_actions(plugin: Any, service: TrajectoryLoggerService) -> Any:
    """Return a copy of *plugin* with all actions wrapped for trajectory logging.

    If the plugin has no actions the original object is returned unchanged.
    """
    actions = getattr(plugin, "actions", None)
    if not actions:
        return plugin

    wrapped = copy.copy(plugin)
    wrapped.actions = [wrap_action_with_logging(a, service) for a in actions]
    return wrapped


# ---------------------------------------------------------------------------
# Provider wrapping
# ---------------------------------------------------------------------------


class WrappedProvider:
    """Wraps a provider's ``get()`` method to log provider accesses.

    All original attributes are preserved; only ``get`` is overridden.
    """

    def __init__(self, original: Any, service: TrajectoryLoggerService) -> None:
        self._original = original
        self._service = service

        self.name: str = getattr(original, "name", "")
        self.description: str = getattr(original, "description", "")
        for attr in ("position",):
            if hasattr(original, attr):
                setattr(self, attr, getattr(original, attr))

    async def get(
        self,
        runtime: Any,
        message: Any,
        state: Any,
    ) -> Any:
        """Wrapped ``get()`` that records the provider access."""
        context = get_trajectory_context(runtime)
        original_get = getattr(self._original, "get", None)

        if context is None:
            if original_get:
                return await original_get(runtime, message, state)
            return {"text": ""}

        trajectory_id = context.trajectory_id
        svc = context.logger_service
        step_id = svc.get_current_step_id(trajectory_id)

        if step_id is None:
            logger.warning(
                "No active step for provider access: provider=%s trajectory=%s",
                self.name,
                trajectory_id,
            )
            if original_get:
                return await original_get(runtime, message, state)
            return {"text": ""}

        result = await original_get(runtime, message, state) if original_get else {"text": ""}

        # Extract result text
        if isinstance(result, dict):
            result_text = str(result.get("text", ""))
        else:
            result_text = str(getattr(result, "text", "") or "")

        state_snapshot = _safe_snapshot(state) if state is not None else None
        message_text = _extract_message_text(message)

        svc.log_provider_access(
            step_id,
            ProviderAccess(
                provider_id=str(uuid.uuid4()),
                provider_name=self.name,
                timestamp=int(time.time() * 1000),
                data={
                    "text": result_text,
                    "success": True,
                },
                purpose=f"Provider {self.name} accessed for context",
                query={
                    "message": message_text,
                    "state": state_snapshot,
                },
            ),
        )

        return result


def wrap_provider_with_logging(
    provider: Any,
    service: TrajectoryLoggerService,
) -> WrappedProvider:
    """Wrap a single provider's ``get()`` to log provider access."""
    return WrappedProvider(provider, service)


def wrap_plugin_providers(plugin: Any, service: TrajectoryLoggerService) -> Any:
    """Return a copy of *plugin* with all providers wrapped for trajectory logging.

    If the plugin has no providers the original object is returned unchanged.
    """
    providers = getattr(plugin, "providers", None)
    if not providers:
        return plugin

    wrapped = copy.copy(plugin)
    wrapped.providers = [wrap_provider_with_logging(p, service) for p in providers]
    return wrapped


# ---------------------------------------------------------------------------
# Standalone logging helpers for use within action handlers
# ---------------------------------------------------------------------------


def log_llm_call_from_action(
    service: TrajectoryLoggerService,
    trajectory_id: str,
    action_context: dict[str, Any],
) -> None:
    """Log an LLM call from within an action handler.

    *action_context* is a dict with keys matching :class:`LLMCall` fields
    (``model``, ``system_prompt``, ``user_prompt``, ``response``, …).
    """
    step_id = service.get_current_step_id(trajectory_id)
    if step_id is None:
        logger.warning(
            "No active step for LLM call from action: trajectory=%s",
            trajectory_id,
        )
        return

    service.log_llm_call(
        step_id,
        LLMCall(
            call_id=str(uuid.uuid4()),
            timestamp=int(time.time() * 1000),
            model=action_context.get("model", "unknown"),
            system_prompt=action_context.get("system_prompt", ""),
            user_prompt=action_context.get("user_prompt", ""),
            response=action_context.get("response", ""),
            reasoning=action_context.get("reasoning"),
            temperature=action_context.get("temperature", 0.7),
            max_tokens=action_context.get("max_tokens", 8192),
            purpose=action_context.get("purpose", "action"),
            action_type=action_context.get("action_type"),
            prompt_tokens=action_context.get("prompt_tokens"),
            completion_tokens=action_context.get("completion_tokens"),
            latency_ms=action_context.get("latency_ms"),
        ),
    )


def log_provider_from_action(
    service: TrajectoryLoggerService,
    trajectory_id: str,
    action_context: dict[str, Any],
) -> None:
    """Log a provider access from within an action handler.

    *action_context* is a dict with keys ``provider_name``, ``data``,
    ``purpose``, and optionally ``query``.
    """
    step_id = service.get_current_step_id(trajectory_id)
    if step_id is None:
        logger.warning(
            "No active step for provider access from action: trajectory=%s",
            trajectory_id,
        )
        return

    service.log_provider_access(
        step_id,
        ProviderAccess(
            provider_id=str(uuid.uuid4()),
            provider_name=action_context.get("provider_name", "unknown"),
            timestamp=int(time.time() * 1000),
            data=action_context.get("data", {}),
            purpose=action_context.get("purpose", "action"),
            query=action_context.get("query"),
        ),
    )
