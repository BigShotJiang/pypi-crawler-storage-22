"""Tests for the action_interceptor module."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

import pytest

from elizaos_plugin_trajectory_logger.action_interceptor import (
    WrappedAction,
    WrappedProvider,
    clear_trajectory_context,
    get_trajectory_context,
    log_llm_call_from_action,
    log_provider_from_action,
    set_trajectory_context,
    wrap_action_with_logging,
    wrap_plugin_actions,
    wrap_plugin_providers,
    wrap_provider_with_logging,
)
from elizaos_plugin_trajectory_logger.service import TrajectoryLoggerService
from elizaos_plugin_trajectory_logger.types import EnvironmentState


# ---------------------------------------------------------------------------
# Mock types
# ---------------------------------------------------------------------------


@dataclass
class MockContent:
    text: str = "hello world"


@dataclass
class MockMessage:
    content: MockContent = field(default_factory=MockContent)


@dataclass
class MockState:
    values: dict[str, Any] = field(default_factory=dict)


class MockRuntime:
    """Simulates an elizaOS agent runtime."""

    def __init__(self, agent_id: str = "test-agent") -> None:
        self.agent_id = agent_id


class MockAction:
    """Simulates an elizaOS action with an async handler."""

    def __init__(self, name: str = "TEST_ACTION", *, should_fail: bool = False) -> None:
        self.name = name
        self.description = f"Test action: {name}"
        self.handler_called = False
        self._should_fail = should_fail

    async def handler(
        self,
        runtime: Any,
        message: Any,
        state: Any = None,
        options: Any = None,
        callback: Any = None,
    ) -> dict[str, Any]:
        self.handler_called = True
        if self._should_fail:
            raise ValueError("Action failed intentionally")
        return {"success": True}


class MockProvider:
    """Simulates an elizaOS provider with an async get()."""

    def __init__(self, name: str = "TEST_PROVIDER") -> None:
        self.name = name
        self.description = f"Test provider: {name}"
        self.get_called = False

    async def get(self, runtime: Any, message: Any, state: Any) -> dict[str, str]:
        self.get_called = True
        return {"text": f"Data from {self.name}"}


@dataclass
class MockPlugin:
    name: str = "test-plugin"
    description: str = "Test plugin"
    actions: list[Any] = field(default_factory=list)
    providers: list[Any] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_env() -> EnvironmentState:
    return EnvironmentState(
        timestamp=int(time.time() * 1000),
        agent_balance=0.0,
        agent_points=0.0,
        agent_pnl=0.0,
        open_positions=0,
    )


def _setup_trajectory(
    svc: TrajectoryLoggerService, runtime: MockRuntime
) -> tuple[str, str]:
    """Start a trajectory + step and bind the context.  Returns (trajectory_id, step_id)."""
    trajectory_id = svc.start_trajectory(runtime.agent_id)
    step_id = svc.start_step(trajectory_id, _make_env())
    set_trajectory_context(runtime, trajectory_id, svc)
    return trajectory_id, step_id


# ---------------------------------------------------------------------------
# Tests: trajectory context management
# ---------------------------------------------------------------------------


def test_set_get_clear_trajectory_context() -> None:
    runtime = MockRuntime()
    svc = TrajectoryLoggerService()
    trajectory_id = svc.start_trajectory("agent-1")

    assert get_trajectory_context(runtime) is None

    set_trajectory_context(runtime, trajectory_id, svc)
    ctx = get_trajectory_context(runtime)
    assert ctx is not None
    assert ctx.trajectory_id == trajectory_id
    assert ctx.logger_service is svc

    clear_trajectory_context(runtime)
    assert get_trajectory_context(runtime) is None


# ---------------------------------------------------------------------------
# Tests: wrap_action_with_logging
# ---------------------------------------------------------------------------


async def test_wrap_action_no_context_passthrough() -> None:
    """Without trajectory context, wrapped action just calls the original."""
    action = MockAction()
    svc = TrajectoryLoggerService()
    wrapped = wrap_action_with_logging(action, svc)

    runtime = MockRuntime()
    result = await wrapped.handler(runtime, MockMessage())

    assert action.handler_called
    assert result == {"success": True}


async def test_wrap_action_logs_success() -> None:
    action = MockAction("GREET")
    svc = TrajectoryLoggerService()
    runtime = MockRuntime()
    trajectory_id, _step_id = _setup_trajectory(svc, runtime)

    wrapped = wrap_action_with_logging(action, svc)
    result = await wrapped.handler(runtime, MockMessage(), MockState())

    assert action.handler_called
    assert result == {"success": True}

    traj = svc.get_active_trajectory(trajectory_id)
    assert traj is not None
    assert len(traj.steps) == 1

    step = traj.steps[0]
    assert step.action.action_name == "GREET"
    assert step.action.success is True
    assert step.reward == pytest.approx(0.1)

    clear_trajectory_context(runtime)


async def test_wrap_action_logs_failure() -> None:
    action = MockAction("FAIL_ACTION", should_fail=True)
    svc = TrajectoryLoggerService()
    runtime = MockRuntime()
    trajectory_id, _step_id = _setup_trajectory(svc, runtime)

    wrapped = wrap_action_with_logging(action, svc)
    with pytest.raises(ValueError, match="Action failed intentionally"):
        await wrapped.handler(runtime, MockMessage(), MockState())

    traj = svc.get_active_trajectory(trajectory_id)
    assert traj is not None

    step = traj.steps[0]
    assert step.action.action_name == "FAIL_ACTION"
    assert step.action.success is False
    assert step.reward == pytest.approx(-0.1)
    assert "failed" in (step.action.reasoning or "")

    clear_trajectory_context(runtime)


async def test_wrap_action_no_active_step_passthrough() -> None:
    """If there is context but no active step, handler should still run."""
    action = MockAction()
    svc = TrajectoryLoggerService()
    runtime = MockRuntime()
    trajectory_id = svc.start_trajectory(runtime.agent_id)
    # Intentionally do NOT start a step.
    set_trajectory_context(runtime, trajectory_id, svc)

    wrapped = wrap_action_with_logging(action, svc)
    result = await wrapped.handler(runtime, MockMessage())

    assert action.handler_called
    assert result == {"success": True}

    clear_trajectory_context(runtime)


def test_wrap_action_preserves_attributes() -> None:
    action = MockAction("MY_ACTION")
    action.examples = [{"input": "hi", "output": "hello"}]  # type: ignore[attr-defined]
    action.similes = ["GREET"]  # type: ignore[attr-defined]
    svc = TrajectoryLoggerService()

    wrapped = wrap_action_with_logging(action, svc)
    assert wrapped.name == "MY_ACTION"
    assert wrapped.description == "Test action: MY_ACTION"
    assert wrapped.examples == [{"input": "hi", "output": "hello"}]  # type: ignore[attr-defined]
    assert wrapped.similes == ["GREET"]  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Tests: wrap_plugin_actions
# ---------------------------------------------------------------------------


async def test_wrap_plugin_actions() -> None:
    a1 = MockAction("A1")
    a2 = MockAction("A2")
    plugin = MockPlugin(actions=[a1, a2])
    svc = TrajectoryLoggerService()

    wrapped_plugin = wrap_plugin_actions(plugin, svc)
    assert len(wrapped_plugin.actions) == 2
    assert isinstance(wrapped_plugin.actions[0], WrappedAction)
    assert isinstance(wrapped_plugin.actions[1], WrappedAction)
    assert wrapped_plugin.actions[0].name == "A1"
    assert wrapped_plugin.actions[1].name == "A2"

    # Original plugin unchanged.
    assert plugin.actions[0] is a1


def test_wrap_plugin_actions_no_actions() -> None:
    plugin = MockPlugin(actions=[])
    svc = TrajectoryLoggerService()
    result = wrap_plugin_actions(plugin, svc)
    assert result is plugin  # returns the same object


# ---------------------------------------------------------------------------
# Tests: wrap_provider_with_logging
# ---------------------------------------------------------------------------


async def test_wrap_provider_no_context_passthrough() -> None:
    provider = MockProvider()
    svc = TrajectoryLoggerService()
    wrapped = wrap_provider_with_logging(provider, svc)

    runtime = MockRuntime()
    result = await wrapped.get(runtime, MockMessage(), MockState())

    assert provider.get_called
    assert result == {"text": "Data from TEST_PROVIDER"}


async def test_wrap_provider_logs_access() -> None:
    provider = MockProvider("MARKET_DATA")
    svc = TrajectoryLoggerService()
    runtime = MockRuntime()
    trajectory_id, _step_id = _setup_trajectory(svc, runtime)

    wrapped = wrap_provider_with_logging(provider, svc)
    result = await wrapped.get(runtime, MockMessage(), MockState())

    assert provider.get_called
    assert result == {"text": "Data from MARKET_DATA"}

    traj = svc.get_active_trajectory(trajectory_id)
    assert traj is not None

    step = traj.steps[0]
    assert len(step.provider_accesses) == 1

    access = step.provider_accesses[0]
    assert access.provider_name == "MARKET_DATA"
    assert access.data["success"] is True

    clear_trajectory_context(runtime)


async def test_wrap_provider_no_active_step_passthrough() -> None:
    provider = MockProvider()
    svc = TrajectoryLoggerService()
    runtime = MockRuntime()
    trajectory_id = svc.start_trajectory(runtime.agent_id)
    set_trajectory_context(runtime, trajectory_id, svc)

    wrapped = wrap_provider_with_logging(provider, svc)
    result = await wrapped.get(runtime, MockMessage(), MockState())

    assert provider.get_called
    assert result == {"text": "Data from TEST_PROVIDER"}

    clear_trajectory_context(runtime)


# ---------------------------------------------------------------------------
# Tests: wrap_plugin_providers
# ---------------------------------------------------------------------------


def test_wrap_plugin_providers() -> None:
    p1 = MockProvider("P1")
    p2 = MockProvider("P2")
    plugin = MockPlugin(providers=[p1, p2])
    svc = TrajectoryLoggerService()

    wrapped_plugin = wrap_plugin_providers(plugin, svc)
    assert len(wrapped_plugin.providers) == 2
    assert isinstance(wrapped_plugin.providers[0], WrappedProvider)
    assert isinstance(wrapped_plugin.providers[1], WrappedProvider)


def test_wrap_plugin_providers_no_providers() -> None:
    plugin = MockPlugin(providers=[])
    svc = TrajectoryLoggerService()
    result = wrap_plugin_providers(plugin, svc)
    assert result is plugin


# ---------------------------------------------------------------------------
# Tests: log_llm_call_from_action
# ---------------------------------------------------------------------------


def test_log_llm_call_from_action() -> None:
    svc = TrajectoryLoggerService()
    trajectory_id = svc.start_trajectory("agent-1")
    svc.start_step(trajectory_id, _make_env())

    log_llm_call_from_action(svc, trajectory_id, {
        "model": "gpt-4",
        "system_prompt": "You are helpful.",
        "user_prompt": "What is 2+2?",
        "response": "4",
        "temperature": 0.5,
        "max_tokens": 100,
        "purpose": "action",
    })

    traj = svc.get_active_trajectory(trajectory_id)
    assert traj is not None

    step = traj.steps[0]
    assert len(step.llm_calls) == 1

    call = step.llm_calls[0]
    assert call.model == "gpt-4"
    assert call.system_prompt == "You are helpful."
    assert call.response == "4"
    assert call.temperature == pytest.approx(0.5)
    assert call.max_tokens == 100


def test_log_llm_call_no_active_step() -> None:
    svc = TrajectoryLoggerService()
    trajectory_id = svc.start_trajectory("agent-1")
    # No step started – should not raise.
    log_llm_call_from_action(svc, trajectory_id, {"model": "test"})


# ---------------------------------------------------------------------------
# Tests: log_provider_from_action
# ---------------------------------------------------------------------------


def test_log_provider_from_action() -> None:
    svc = TrajectoryLoggerService()
    trajectory_id = svc.start_trajectory("agent-1")
    svc.start_step(trajectory_id, _make_env())

    log_provider_from_action(svc, trajectory_id, {
        "provider_name": "market-data",
        "data": {"price": 100.0},
        "purpose": "get market state",
        "query": {"symbol": "BTC"},
    })

    traj = svc.get_active_trajectory(trajectory_id)
    assert traj is not None

    step = traj.steps[0]
    assert len(step.provider_accesses) == 1

    access = step.provider_accesses[0]
    assert access.provider_name == "market-data"
    assert access.data["price"] == 100.0


def test_log_provider_no_active_step() -> None:
    svc = TrajectoryLoggerService()
    trajectory_id = svc.start_trajectory("agent-1")
    # No step started – should not raise.
    log_provider_from_action(svc, trajectory_id, {"provider_name": "test"})


# ---------------------------------------------------------------------------
# Integration: full wrapped plugin flow
# ---------------------------------------------------------------------------


async def test_full_wrapped_plugin_flow() -> None:
    """End-to-end: wrap a plugin, execute provider + action, verify logging."""
    action = MockAction("TRADE")
    provider = MockProvider("BALANCE")
    plugin = MockPlugin(actions=[action], providers=[provider])

    svc = TrajectoryLoggerService()
    runtime = MockRuntime("trader-agent")

    wrapped_plugin = wrap_plugin_actions(plugin, svc)
    wrapped_plugin = wrap_plugin_providers(wrapped_plugin, svc)

    trajectory_id, _step_id = _setup_trajectory(svc, runtime)

    # Access provider, then execute action.
    provider_result = await wrapped_plugin.providers[0].get(
        runtime, MockMessage(), MockState()
    )
    assert provider_result == {"text": "Data from BALANCE"}

    action_result = await wrapped_plugin.actions[0].handler(
        runtime, MockMessage(), MockState()
    )
    assert action_result == {"success": True}

    traj = svc.get_active_trajectory(trajectory_id)
    assert traj is not None

    step = traj.steps[0]
    assert len(step.provider_accesses) == 1
    assert step.action.action_name == "TRADE"
    assert step.action.success is True
    assert step.reward == pytest.approx(0.1)

    clear_trajectory_context(runtime)


async def test_multiple_actions_sequential() -> None:
    """Wrap two actions and execute them sequentially on separate steps."""
    a1 = MockAction("ANALYZE")
    a2 = MockAction("EXECUTE")
    svc = TrajectoryLoggerService()
    runtime = MockRuntime()

    w1 = wrap_action_with_logging(a1, svc)
    w2 = wrap_action_with_logging(a2, svc)

    trajectory_id = svc.start_trajectory(runtime.agent_id)

    # Step 1
    svc.start_step(trajectory_id, _make_env())
    set_trajectory_context(runtime, trajectory_id, svc)
    await w1.handler(runtime, MockMessage(), MockState())

    # Step 2
    svc.start_step(trajectory_id, _make_env())
    await w2.handler(runtime, MockMessage(), MockState())

    traj = svc.get_active_trajectory(trajectory_id)
    assert traj is not None
    assert len(traj.steps) == 2
    assert traj.steps[0].action.action_name == "ANALYZE"
    assert traj.steps[1].action.action_name == "EXECUTE"
    assert traj.total_reward == pytest.approx(0.2)

    clear_trajectory_context(runtime)
