"""
Trust plugin actions.

Actions define what the agent can do with the trust system.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol, TypeAlias

from elizaos_plugin_trust.actions.evaluate_trust import EvaluateTrustAction
from elizaos_plugin_trust.actions.record_trust_interaction import (
    RecordTrustInteractionAction,
)
from elizaos_plugin_trust.actions.request_elevation import RequestElevationAction
from elizaos_plugin_trust.actions.roles import ManageRolesAction
from elizaos_plugin_trust.actions.settings import TrustSettingsAction

if TYPE_CHECKING:
    from elizaos_plugin_trust.services import TrustServices

ScalarValue: TypeAlias = str | int | float | bool | None
ActionDataValue: TypeAlias = ScalarValue | list[ScalarValue] | dict[str, ScalarValue]
ActionData: TypeAlias = dict[str, ActionDataValue]


@dataclass(frozen=True)
class ActionContext:
    """Context provided to trust actions."""

    entity_id: str
    action_name: str = ""
    resource: str = ""
    environment: str = "default"
    message_content: str = ""
    data: dict[str, str | int | float | bool] = field(default_factory=dict)


@dataclass
class ActionResult:
    """Result of executing an action."""

    success: bool
    response: str | None = None
    data: ActionData | None = None

    @classmethod
    def success_result(
        cls,
        response: str,
        data: ActionData | None = None,
    ) -> ActionResult:
        return cls(success=True, response=response, data=data)

    @classmethod
    def failure_result(cls, message: str) -> ActionResult:
        return cls(success=False, response=message)


class TrustAction(Protocol):
    """Protocol that all trust actions must satisfy.

    ``validate`` and ``handler`` are async to support actions that perform
    I/O (LLM calls, database writes).  Implementations backed by in-memory
    services may execute synchronously within the async wrapper.
    """

    @property
    def name(self) -> str: ...

    @property
    def description(self) -> str: ...

    @property
    def similes(self) -> list[str]: ...

    async def validate(self, context: ActionContext) -> bool: ...

    async def handler(
        self,
        context: ActionContext,
        services: TrustServices,
    ) -> ActionResult: ...


def get_all_actions() -> list[TrustAction]:
    """Get all available trust actions."""
    return [
        EvaluateTrustAction(),
        RecordTrustInteractionAction(),
        RequestElevationAction(),
        ManageRolesAction(),
        TrustSettingsAction(),
    ]


__all__ = [
    "ActionContext",
    "ActionResult",
    "ActionData",
    "TrustAction",
    "EvaluateTrustAction",
    "RecordTrustInteractionAction",
    "RequestElevationAction",
    "ManageRolesAction",
    "TrustSettingsAction",
    "get_all_actions",
]
