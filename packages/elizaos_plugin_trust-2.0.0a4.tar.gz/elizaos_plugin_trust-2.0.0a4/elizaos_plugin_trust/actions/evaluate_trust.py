"""Evaluate trust action."""

from __future__ import annotations

from typing import TYPE_CHECKING

from elizaos_plugin_trust.types.trust import TrustContext

if TYPE_CHECKING:
    from elizaos_plugin_trust.actions import ActionContext, ActionResult
    from elizaos_plugin_trust.services import TrustServices


class EvaluateTrustAction:
    """Evaluates the trust profile for a given entity."""

    @property
    def name(self) -> str:
        return "EVALUATE_TRUST"

    @property
    def description(self) -> str:
        return (
            "Evaluates the multi-dimensional trust profile for an entity, "
            "returning scores for reliability, competence, integrity, "
            "benevolence, and transparency."
        )

    @property
    def similes(self) -> list[str]:
        return [
            "CHECK_TRUST",
            "GET_TRUST_SCORE",
            "TRUST_CHECK",
            "ASSESS_TRUST",
            "TRUST_EVALUATION",
        ]

    async def validate(self, context: ActionContext) -> bool:
        return bool(context.entity_id)

    async def handler(
        self,
        context: ActionContext,
        services: TrustServices,
    ) -> ActionResult:
        from elizaos_plugin_trust.actions import ActionResult

        trust_context = TrustContext(
            entity_id=context.entity_id,
            action=context.action_name,
            resource=context.resource,
            environment=context.environment,
        )

        profile = services.trust_engine.calculate_trust(
            context.entity_id, trust_context
        )

        dims = profile.dimensions.as_dict()

        return ActionResult.success_result(
            f"Trust evaluation for '{context.entity_id}': "
            f"overall={profile.overall_score:.3f}, "
            f"confidence={profile.confidence:.3f}, "
            f"trend={profile.trend.value}",
            data={
                "entity_id": profile.entity_id,
                "overall_score": profile.overall_score,
                "confidence": profile.confidence,
                "evidence_count": profile.evidence_count,
                "trend": profile.trend.value,
                "dimensions": dims,
            },
        )
