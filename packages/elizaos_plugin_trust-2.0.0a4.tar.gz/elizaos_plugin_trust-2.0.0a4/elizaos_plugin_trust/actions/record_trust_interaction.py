"""Record trust interaction action."""

from __future__ import annotations

from typing import TYPE_CHECKING

from elizaos_plugin_trust.types.trust import TrustEvidence, TrustEvidenceType

if TYPE_CHECKING:
    from elizaos_plugin_trust.actions import ActionContext, ActionResult
    from elizaos_plugin_trust.services import TrustServices


class RecordTrustInteractionAction:
    """Records a piece of trust evidence for an entity."""

    @property
    def name(self) -> str:
        return "RECORD_TRUST_INTERACTION"

    @property
    def description(self) -> str:
        return (
            "Records a trust-relevant interaction as evidence, "
            "which will be factored into future trust evaluations."
        )

    @property
    def similes(self) -> list[str]:
        return [
            "LOG_TRUST_EVENT",
            "ADD_TRUST_EVIDENCE",
            "RECORD_EVIDENCE",
            "TRUST_FEEDBACK",
        ]

    async def validate(self, context: ActionContext) -> bool:
        if not context.entity_id:
            return False
        evidence_type_str = context.data.get("evidence_type", "")
        if not isinstance(evidence_type_str, str) or not evidence_type_str:
            return False
        try:
            TrustEvidenceType(evidence_type_str)
        except ValueError:
            return False
        value = context.data.get("value")
        if not isinstance(value, (int, float)):
            return False
        return 0.0 <= float(value) <= 1.0

    async def handler(
        self,
        context: ActionContext,
        services: TrustServices,
    ) -> ActionResult:
        from elizaos_plugin_trust.actions import ActionResult

        evidence_type = TrustEvidenceType(str(context.data["evidence_type"]))
        value = float(context.data["value"])
        weight_raw = context.data.get("weight", 1.0)
        weight = float(weight_raw) if isinstance(weight_raw, (int, float)) else 1.0
        source = str(context.data.get("source", "action"))
        ctx_desc = str(context.data.get("context", ""))

        evidence = TrustEvidence(
            entity_id=context.entity_id,
            evidence_type=evidence_type,
            value=value,
            weight=weight,
            source=source,
            context=ctx_desc,
        )

        services.trust_engine.record_evidence(evidence)

        return ActionResult.success_result(
            f"Recorded {evidence_type.value} evidence for '{context.entity_id}' "
            f"with value={value:.3f}",
            data={
                "evidence_id": evidence.id,
                "entity_id": evidence.entity_id,
                "evidence_type": evidence.evidence_type.value,
                "value": evidence.value,
                "weight": evidence.weight,
            },
        )
