"""Request elevation action."""

from __future__ import annotations

from typing import TYPE_CHECKING

from elizaos_plugin_trust.types.permissions import (
    ElevationRequest,
    PermissionContext,
)

if TYPE_CHECKING:
    from elizaos_plugin_trust.actions import ActionContext, ActionResult
    from elizaos_plugin_trust.services import TrustServices


class RequestElevationAction:
    """Requests temporary permission elevation for an entity."""

    @property
    def name(self) -> str:
        return "REQUEST_ELEVATION"

    @property
    def description(self) -> str:
        return (
            "Requests temporary elevation of permissions to a higher role. "
            "The request is evaluated based on the entity's trust profile "
            "and the role hierarchy."
        )

    @property
    def similes(self) -> list[str]:
        return [
            "ELEVATE_PERMISSIONS",
            "REQUEST_ROLE_UPGRADE",
            "SUDO",
            "ESCALATE_PRIVILEGES",
        ]

    async def validate(self, context: ActionContext) -> bool:
        if not context.entity_id:
            return False
        requested_role = context.data.get("requested_role", "")
        if not isinstance(requested_role, str) or not requested_role:
            return False
        reason = context.data.get("reason", "")
        if not isinstance(reason, str) or not reason:
            return False
        duration = context.data.get("duration_minutes", 0)
        if not isinstance(duration, (int, float)):
            return False
        return int(duration) >= 1

    async def handler(
        self,
        context: ActionContext,
        services: TrustServices,
    ) -> ActionResult:
        from elizaos_plugin_trust.actions import ActionResult

        requested_role = str(context.data["requested_role"])
        reason = str(context.data["reason"])
        duration = int(context.data["duration_minutes"])
        current_role = services.permission_system.get_entity_role(context.entity_id)

        perm_context = PermissionContext(
            entity_id=context.entity_id,
            role=current_role.name,
            resource=context.resource or "*",
            action=context.action_name or "elevate",
            environment=context.environment,
        )

        elevation_request = ElevationRequest(
            entity_id=context.entity_id,
            current_role=current_role.name,
            requested_role=requested_role,
            reason=reason,
            duration_minutes=duration,
            context=perm_context,
        )

        result = services.permission_system.request_elevation(elevation_request)

        if result.approved:
            return ActionResult.success_result(
                f"Elevation approved: '{context.entity_id}' elevated to "
                f"'{result.granted_role}'",
                data={
                    "approved": True,
                    "granted_role": result.granted_role or "",
                    "expires_at": result.expires_at.isoformat() if result.expires_at else "",
                    "audit_log_id": result.audit_log_id,
                },
            )
        return ActionResult.failure_result(
            f"Elevation denied: {result.denial_reason or 'Unknown reason'}"
        )
