"""Manage roles action."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from elizaos_plugin_trust.actions import ActionContext, ActionResult
    from elizaos_plugin_trust.services import TrustServices


class ManageRolesAction:
    """Manages role assignments for entities."""

    @property
    def name(self) -> str:
        return "MANAGE_ROLES"

    @property
    def description(self) -> str:
        return (
            "Manages role assignments: assign a role, revoke elevation, "
            "or list available roles and an entity's current role."
        )

    @property
    def similes(self) -> list[str]:
        return [
            "ASSIGN_ROLE",
            "SET_ROLE",
            "LIST_ROLES",
            "GET_ROLE",
            "REVOKE_ELEVATION",
        ]

    async def validate(self, context: ActionContext) -> bool:
        sub = context.data.get("sub_action", "")
        if not isinstance(sub, str):
            return False
        return sub in ("assign", "revoke", "list", "get")

    async def handler(
        self,
        context: ActionContext,
        services: TrustServices,
    ) -> ActionResult:
        from elizaos_plugin_trust.actions import ActionResult

        sub = str(context.data.get("sub_action", "list"))
        ps = services.permission_system

        if sub == "assign":
            role_name = str(context.data.get("role_name", ""))
            target = str(context.data.get("target_entity_id", context.entity_id))
            if not role_name:
                return ActionResult.failure_result("Missing 'role_name'")
            if role_name not in ps.roles:
                return ActionResult.failure_result(f"Unknown role: {role_name}")
            ps.assign_role(target, role_name)
            return ActionResult.success_result(
                f"Role '{role_name}' assigned to '{target}'",
                data={"entity_id": target, "role": role_name},
            )

        if sub == "revoke":
            target = str(context.data.get("target_entity_id", context.entity_id))
            revoked = ps.revoke_elevation(target)
            if revoked:
                return ActionResult.success_result(
                    f"Elevation revoked for '{target}'",
                    data={"entity_id": target, "revoked": True},
                )
            return ActionResult.failure_result(f"No active elevation for '{target}'")

        if sub == "get":
            target = str(context.data.get("target_entity_id", context.entity_id))
            role = ps.get_entity_role(target)
            return ActionResult.success_result(
                f"Entity '{target}' has role '{role.name}' (level {role.level})",
                data={
                    "entity_id": target,
                    "role_name": role.name,
                    "level": role.level,
                    "description": role.description,
                },
            )

        # sub == "list"
        role_list = {
            name: {
                "level": r.level,
                "description": r.description,
                "parent": r.parent_role or "",
            }
            for name, r in sorted(ps.roles.items(), key=lambda kv: kv[1].level)
        }
        return ActionResult.success_result(
            f"Available roles: {', '.join(role_list.keys())}",
            data={"roles": role_list},
        )
