"""Trust settings action."""

from __future__ import annotations

from typing import TYPE_CHECKING

from elizaos_plugin_trust.types.trust import TrustCalculationConfig

if TYPE_CHECKING:
    from elizaos_plugin_trust.actions import ActionContext, ActionResult
    from elizaos_plugin_trust.services import TrustServices


class TrustSettingsAction:
    """Gets or updates trust calculation settings."""

    @property
    def name(self) -> str:
        return "TRUST_SETTINGS"

    @property
    def description(self) -> str:
        return (
            "View or update trust calculation configuration such as "
            "decay rate, evidence window, dimension weights, and thresholds."
        )

    @property
    def similes(self) -> list[str]:
        return [
            "GET_TRUST_CONFIG",
            "SET_TRUST_CONFIG",
            "TRUST_CONFIGURATION",
            "CONFIGURE_TRUST",
        ]

    async def validate(self, context: ActionContext) -> bool:
        sub = context.data.get("sub_action", "")
        if not isinstance(sub, str):
            return False
        return sub in ("get", "set")

    async def handler(
        self,
        context: ActionContext,
        services: TrustServices,
    ) -> ActionResult:
        from elizaos_plugin_trust.actions import ActionResult

        sub = str(context.data.get("sub_action", "get"))
        engine = services.trust_engine

        if sub == "get":
            cfg = engine.config
            return ActionResult.success_result(
                "Current trust configuration",
                data={
                    "decay_rate": cfg.decay_rate,
                    "evidence_window_days": cfg.evidence_window_days,
                    "minimum_evidence_count": cfg.minimum_evidence_count,
                    "confidence_threshold": cfg.confidence_threshold,
                    "default_score": cfg.default_score,
                    "dimension_weights": cfg.dimension_weights,
                },
            )

        # sub == "set"
        updates: dict[str, float | int | dict[str, float]] = {}
        for key in (
            "decay_rate",
            "evidence_window_days",
            "minimum_evidence_count",
            "confidence_threshold",
            "default_score",
        ):
            val = context.data.get(key)
            if val is not None and isinstance(val, (int, float)):
                updates[key] = val

        current = engine.config.model_dump()
        current.update(updates)
        new_config = TrustCalculationConfig(**current)

        # Replace the engine's config (re-initialise internal state)
        engine._config = new_config  # noqa: SLF001

        return ActionResult.success_result(
            "Trust configuration updated",
            data={
                "decay_rate": new_config.decay_rate,
                "evidence_window_days": new_config.evidence_window_days,
                "minimum_evidence_count": new_config.minimum_evidence_count,
                "confidence_threshold": new_config.confidence_threshold,
                "default_score": new_config.default_score,
            },
        )
