"""Trust plugin error types."""


class TrustError(Exception):
    """Base class for Trust plugin errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)

    def is_retryable(self) -> bool:
        return False


class EntityNotFoundError(TrustError):
    """Entity not found in the trust system."""

    def __init__(self, entity_id: str) -> None:
        self.entity_id = entity_id
        super().__init__(f"Entity not found: {entity_id}")


class InsufficientEvidenceError(TrustError):
    """Not enough evidence to make a trust decision."""

    def __init__(self, entity_id: str, have: int, need: int) -> None:
        self.entity_id = entity_id
        self.have = have
        self.need = need
        super().__init__(
            f"Insufficient evidence for entity '{entity_id}': "
            f"have {have}, need {need}"
        )


class TrustThresholdError(TrustError):
    """Trust score does not meet the required threshold."""

    def __init__(self, entity_id: str, score: float, required: float) -> None:
        self.entity_id = entity_id
        self.score = score
        self.required = required
        super().__init__(
            f"Trust threshold not met for '{entity_id}': "
            f"score {score:.3f} < required {required:.3f}"
        )


class SecurityViolationError(TrustError):
    """A security threat was detected."""

    def __init__(self, threat_type: str, detail: str) -> None:
        self.threat_type = threat_type
        self.detail = detail
        super().__init__(f"Security violation [{threat_type}]: {detail}")


class PermissionDeniedError(TrustError):
    """Permission check failed."""

    def __init__(self, entity_id: str, resource: str, action: str) -> None:
        self.entity_id = entity_id
        self.resource = resource
        self.action = action
        super().__init__(
            f"Permission denied: entity '{entity_id}' cannot "
            f"'{action}' on resource '{resource}'"
        )


class RoleNotFoundError(TrustError):
    """Requested role does not exist."""

    def __init__(self, role_name: str) -> None:
        self.role_name = role_name
        super().__init__(f"Role not found: {role_name}")


class ElevationDeniedError(TrustError):
    """Elevation request was denied."""

    def __init__(self, entity_id: str, requested_role: str, reason: str) -> None:
        self.entity_id = entity_id
        self.requested_role = requested_role
        self.reason = reason
        super().__init__(
            f"Elevation denied for '{entity_id}' to role "
            f"'{requested_role}': {reason}"
        )


class CredentialExposureError(TrustError):
    """Credentials were detected in content that should not contain them."""

    def __init__(self, credential_types: list[str]) -> None:
        self.credential_types = credential_types
        super().__init__(
            f"Credential exposure detected: {', '.join(credential_types)}"
        )


class ConfigurationError(TrustError):
    """Invalid configuration."""

    def __init__(self, message: str) -> None:
        super().__init__(f"Configuration error: {message}")


class ValidationError(TrustError):
    """Action validation failed."""

    def __init__(self, reason: str) -> None:
        super().__init__(f"Validation failed: {reason}")
