"""
Trust plugin evaluators.

``SecurityPreEvaluator`` runs with ``phase="pre"`` — it intercepts messages
before they are saved to memory and can block prompt injections, social
engineering, credential theft, and other adversarial inputs.

Purely heuristic-based — no LLM calls in the pre-phase.
"""

from elizaos_plugin_trust.evaluators.reflection import ReflectionEvaluator
from elizaos_plugin_trust.evaluators.security_evaluator import (
    SecurityPreEvaluator,
    make_security_evaluator_definition,
)
from elizaos_plugin_trust.evaluators.trust_change_evaluator import (
    TrustChangeEvaluator,
)

__all__ = [
    "ReflectionEvaluator",
    "SecurityPreEvaluator",
    "TrustChangeEvaluator",
    "make_security_evaluator_definition",
]
