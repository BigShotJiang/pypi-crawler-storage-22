"""
Reflection evaluator.

Performs self-reflection on past trust decisions to identify patterns,
biases, and areas for recalibration.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from elizaos_plugin_trust.services.trust_engine import TrustEngine
from elizaos_plugin_trust.types.trust import TrustEvidence, TrustTrend


class ReflectionResult:
    """Result of a reflection analysis."""

    __slots__ = (
        "entity_id",
        "evidence_count",
        "avg_value",
        "value_std_dev",
        "trend",
        "dominant_evidence_type",
        "suggestions",
    )

    def __init__(
        self,
        entity_id: str,
        evidence_count: int,
        avg_value: float,
        value_std_dev: float,
        trend: TrustTrend,
        dominant_evidence_type: str,
        suggestions: list[str],
    ) -> None:
        self.entity_id = entity_id
        self.evidence_count = evidence_count
        self.avg_value = avg_value
        self.value_std_dev = value_std_dev
        self.trend = trend
        self.dominant_evidence_type = dominant_evidence_type
        self.suggestions = suggestions


class ReflectionEvaluator:
    """Analyses past trust evidence to find patterns and suggest recalibration."""

    def __init__(self, trust_engine: TrustEngine) -> None:
        self._engine = trust_engine

    def reflect(
        self,
        entity_id: str,
        window_days: int = 30,
    ) -> ReflectionResult:
        """Perform a reflection analysis on an entity's trust evidence."""
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(days=window_days)

        all_evidence = self._engine.get_evidence(entity_id)
        recent = [e for e in all_evidence if e.timestamp >= cutoff]

        if not recent:
            return ReflectionResult(
                entity_id=entity_id,
                evidence_count=0,
                avg_value=0.5,
                value_std_dev=0.0,
                trend=TrustTrend.INSUFFICIENT_DATA,
                dominant_evidence_type="none",
                suggestions=["Insufficient evidence for reflection"],
            )

        avg_value = sum(e.value for e in recent) / len(recent)
        variance = sum((e.value - avg_value) ** 2 for e in recent) / len(recent)
        std_dev = variance ** 0.5

        # Determine dominant evidence type
        type_counts: dict[str, int] = {}
        for e in recent:
            t = e.evidence_type.value
            type_counts[t] = type_counts.get(t, 0) + 1
        dominant = max(type_counts, key=lambda k: type_counts[k])

        # Build trend
        profile = self._engine.calculate_trust(entity_id)
        trend = profile.trend

        # Generate suggestions
        suggestions = self._generate_suggestions(
            recent, avg_value, std_dev, trend, type_counts
        )

        return ReflectionResult(
            entity_id=entity_id,
            evidence_count=len(recent),
            avg_value=round(avg_value, 3),
            value_std_dev=round(std_dev, 3),
            trend=trend,
            dominant_evidence_type=dominant,
            suggestions=suggestions,
        )

    def reflect_all(self, window_days: int = 30) -> list[ReflectionResult]:
        """Perform reflection analysis on all known entities."""
        return [
            self.reflect(eid, window_days)
            for eid in self._engine.get_all_entity_ids()
        ]

    def _generate_suggestions(
        self,
        evidence: list[TrustEvidence],
        avg_value: float,
        std_dev: float,
        trend: TrustTrend,
        type_counts: dict[str, int],
    ) -> list[str]:
        suggestions: list[str] = []

        if std_dev > 0.25:
            suggestions.append(
                "High variability in evidence values detected. "
                "Consider investigating inconsistent behavior."
            )

        if trend == TrustTrend.DECREASING:
            suggestions.append(
                "Trust is trending downward. Review recent negative "
                "evidence for actionable patterns."
            )
        elif trend == TrustTrend.VOLATILE:
            suggestions.append(
                "Trust scores are volatile. Consider increasing "
                "the evidence window or adjusting the decay rate."
            )

        if avg_value < 0.3:
            suggestions.append(
                "Average evidence value is low. Consider restricting "
                "permissions until trust improves."
            )
        elif avg_value > 0.8:
            suggestions.append(
                "Consistently high trust evidence. Entity may be "
                "eligible for elevated permissions."
            )

        total = sum(type_counts.values())
        for etype, count in type_counts.items():
            if count / total > 0.6:
                suggestions.append(
                    f"Evidence is heavily concentrated in '{etype}' ({count}/{total}). "
                    f"Seek evidence across more dimensions for balanced scoring."
                )
                break

        if len(evidence) < 5:
            suggestions.append(
                "Limited evidence available. Confidence in trust "
                "scores may be low."
            )

        return suggestions
