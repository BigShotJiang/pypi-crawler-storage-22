"""Security pre-evaluator — runs as middleware BEFORE memory storage.

Uses ONLY fast heuristic checks to detect adversarial inputs. No LLM calls.
The pre-evaluator is a gate — it blocks obvious threats based on pattern
matching and structural analysis.  Nuanced cases that need LLM understanding
go through the normal agent pipeline (trustChangeEvaluator handles those).

Provides both a standalone ``SecurityPreEvaluator`` utility class AND
a ``make_security_evaluator_definition()`` factory that returns a proper
Eliza ``EvaluatorDefinition`` for runtime registration.

Port of: plugins/plugin-trust/typescript/src/evaluators/securityEvaluator.ts
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING

from elizaos_plugin_trust.services.security_module import SecurityModule
from elizaos_plugin_trust.services.credential_protector import CredentialProtector

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Heuristic signal detection (mirrors the TS securityEvaluator logic)
# ---------------------------------------------------------------------------

def _strip_invisible(text: str) -> str:
    """Strip zero-width characters and other invisible Unicode."""
    return re.sub(
        r"[\u200b\u200c\u200d\u200e\u200f\ufeff\u00ad\u034f\u061c"
        r"\u115f\u1160\u17b4\u17b5\u180b-\u180e\u2000-\u200a"
        r"\u2028\u2029\u202a-\u202f\u2060-\u2064\u2066-\u206f"
        r"\u3164\ufe00-\ufe0f\uffa0]",
        "",
        text,
    )


def _looks_like_base64(text: str) -> bool:
    stripped = text.strip()
    return bool(re.fullmatch(r"[A-Za-z0-9+/]{16,}={0,2}", stripped))


def _looks_like_hex(text: str) -> bool:
    return bool(re.fullmatch(r"([0-9a-fA-F]{2}\s+){8,}[0-9a-fA-F]{2}", text.strip()))


def _has_leet_speak(text: str) -> bool:
    leet_chars = re.findall(r"[01345@7]", text)
    letter_chars = re.findall(r"[a-zA-Z]", text)
    if not leet_chars or not letter_chars:
        return False
    ratio = len(leet_chars) / (len(leet_chars) + len(letter_chars))
    return ratio > 0.15 and len(leet_chars) >= 4


def _has_token_splitting(text: str) -> bool:
    words = text.split()
    consecutive = 0
    max_consecutive = 0
    for w in words:
        if len(w) <= 3 and re.fullmatch(r"[a-zA-Z]+", w):
            consecutive += 1
            max_consecutive = max(max_consecutive, consecutive)
        else:
            consecutive = 0
    return max_consecutive >= 5


_STRUCTURAL_PATTERNS = [
    re.compile(r"<\|im_start\|>", re.IGNORECASE),
    re.compile(r"<\|im_end\|>", re.IGNORECASE),
    re.compile(r"\[INST\]", re.IGNORECASE),
    re.compile(r"\[/INST\]", re.IGNORECASE),
    re.compile(r"\[SYS\]", re.IGNORECASE),
    re.compile(r'"role"\s*:\s*"system"', re.IGNORECASE),
    re.compile(r"```system\n"),
    re.compile(r"END OF SYSTEM PROMPT", re.IGNORECASE),
    re.compile(r"NEW SYSTEM PROMPT", re.IGNORECASE),
    re.compile(r"ACTUAL INSTRUCTIONS:", re.IGNORECASE),
]

_MULTILANG_PATTERNS = [
    re.compile(r"ignora\s+(todas\s+)?las\s+instrucciones", re.IGNORECASE),
    re.compile(r"ignorez\s+toutes\s+les\s+instructions", re.IGNORECASE),
    re.compile(r"ignoriere\s+alle\s+vorherigen\s+anweisungen", re.IGNORECASE),
    re.compile(r"игнорируй\s+все\s+предыдущие\s+инструкции", re.IGNORECASE),
    re.compile(r"игнорируй.*инструкции", re.IGNORECASE),
    re.compile(r"忽略.*指令"),
    re.compile(r"忽略.*之前"),
    re.compile(r"指示を無視"),
    re.compile(r"無視して"),
    re.compile(r"무시하고"),
    re.compile(r"지시를\s*무시"),
    re.compile(r"تجاهل.*التعليمات"),
]

# Negation pattern — matches warnings ABOUT sharing (not requests to share)
_NEGATION_RE = re.compile(
    r"(?i)(?:never|don'?t|do\s+not|avoid|stop)\s+(?:ever\s+)?"
    r"(?:share|send|give|post|reveal|provide)",
)

# High-confidence signals that warrant blocking.
# Includes both heuristic signal names and SecurityModule signal names.
_HIGH_CONFIDENCE_SIGNALS = frozenset({
    # From SecurityModule pattern matching
    "injection_patterns",
    "social_engineering_patterns",
    "phishing_patterns",
    "credential_exposure",
    # From heuristic signal detection (parity with TS/Rust)
    "ignore_previous",
    "disregard_instructions",
    "system_override",
    "bypass_security",
    "jailbreak_keyword",
    "mode_override",
    "structural_injection",
    "multi_language_injection",
    "credential_request",
    "privilege_request",
    "prompt_extraction",
    "escalation_request",
    "urgency_pressure",
    "authority_claim",
    "scam_keywords",
    "verification_scam",
})


_INJECTION_KEYWORD_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"(?i)ignore\s+(all\s+)?(?:previous|prior|above)\s+(?:instructions|prompts|context)"), "ignore_previous"),
    (re.compile(r"(?i)disregard\s+(your\s+|all\s+)?(?:previous|prior|system)?\s*(?:instructions|prompts|commands|rules)"), "disregard_instructions"),
    (re.compile(r"(?i)(?:new|override|updated?)\s+(?:system\s+)?instructions"), "new_instructions"),
    (re.compile(r"(?i)system\s+override"), "system_override"),
    (re.compile(r"(?i)bypass\s+(?:all\s+)?(?:security|safety|checks|restrictions|filters)"), "bypass_security"),
    (re.compile(r"(?i)you\s+are\s+now\s+"), "identity_override"),
    (re.compile(r"(?i)pretend\s+(?:you\s+are|to\s+be)"), "pretend_identity"),
    (re.compile(r"(?i)jailbreak"), "jailbreak_keyword"),
    (re.compile(r"(?i)DAN\s+mode|developer\s+mode"), "mode_override"),
    (re.compile(r"(?i)forget\s+(?:everything|all|your)"), "forget_instructions"),
    (re.compile(r"(?i)(?:reveal|show|output|print|display)\s+(?:your\s+)?(?:system\s+)?(?:prompt|instructions)"), "prompt_extraction"),
    (re.compile(r"(?i)grant\s+(?:me\s+)?(?:admin|all\s+permissions|full\s+access|root)"), "privilege_request"),
    (re.compile(r"(?i)elevate\s+(?:my\s+)?privileges"), "escalation_request"),
]

_SE_KEYWORD_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"(?i)(?:urgent|emergency|critical).*(?:need|must|have\s+to|right\s+now)"), "urgency_pressure"),
    (re.compile(r"(?i)(?:i\s+am|i'm)\s+(?:the|an?)\s+(?:admin|administrator|owner|manager|ceo|supervisor|director)"), "authority_claim"),
    (re.compile(r"(?i)(?:you\s+owe\s+me|return\s+the\s+favor)"), "reciprocity"),
    (re.compile(r"(?i)everyone\s+(?:else\s+)?(?:already\s+)?has"), "social_proof"),
    (re.compile(r"(?i)(?:consequences|report\s+(?:this|you)\s+to|get\s+(?:you|me)\s+fired)"), "intimidation"),
    (re.compile(r"(?i)(?:connect\s+your\s+wallet|claim\s+your\s+reward|airdrop|giveaway)"), "scam_keywords"),
    (re.compile(r"(?i)verify\s+your\s+(?:identity|account|wallet)"), "verification_scam"),
]

_CRED_KEYWORD_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"(?i)(?:send|share|give|post|tell|paste|reveal|provide)\s+(?:me\s+)?(?:your\s+)?(?:api.?(?:key|token)|password|credentials|seed\s+phrase|private\s+key|secret|recovery\s+phrase|2FA|login|\.env|ssh.*key|client.?secret)"), "credential_request"),
    (re.compile(r"(?i)(?:bit\.ly|tinyurl|t\.co)/\S+"), "shortened_url"),
]


def detect_heuristic_signals(text: str) -> list[str]:
    """Fast heuristic scan — returns list of signal names."""
    signals: list[str] = []
    cleaned = _strip_invisible(text)

    # Encoding / obfuscation
    if _looks_like_base64(text):
        signals.append("base64_encoding")
    if _looks_like_hex(text):
        signals.append("hex_encoding")
    if _has_leet_speak(text):
        signals.append("leet_speak")
    if _has_token_splitting(text):
        signals.append("token_splitting")
    if len(cleaned) != len(text):
        signals.append("invisible_characters")

    # Structural injection
    if any(p.search(text) for p in _STRUCTURAL_PATTERNS):
        signals.append("structural_injection")

    # Multi-language injection
    if any(p.search(text) for p in _MULTILANG_PATTERNS):
        signals.append("multi_language_injection")

    # Injection keywords
    for pat, name in _INJECTION_KEYWORD_PATTERNS:
        if pat.search(text):
            signals.append(name)

    # Social engineering keywords
    for pat, name in _SE_KEYWORD_PATTERNS:
        if pat.search(text):
            signals.append(name)

    # Credential request keywords (with negation awareness)
    if not _NEGATION_RE.search(text):
        for pat, name in _CRED_KEYWORD_PATTERNS:
            if pat.search(text):
                signals.append(name)

    return signals


# ---------------------------------------------------------------------------
# Standalone utility class (for use outside the Eliza runtime)
# ---------------------------------------------------------------------------

class SecurityPreEvaluator:
    """Pre-processing security evaluator using SecurityModule + heuristics.

    Purely pattern-based — no LLM calls.  For Eliza runtime integration,
    use :func:`make_security_evaluator_definition` instead.
    """

    def __init__(self, owner_entity_id: str | None = None) -> None:
        self._security = SecurityModule()
        self._credential = CredentialProtector()
        self._owner_entity_id = owner_entity_id

    def evaluate(
        self,
        text: str,
        sender_entity_id: str | None = None,
    ) -> dict[str, bool | str | None]:
        """Evaluate a message for security threats using heuristics only.

        Returns:
            Dict with ``blocked`` (bool), ``reason`` (str | None),
            and ``rewritten_text`` (str | None).
        """
        if not text or len(text) < 3:
            return {"blocked": False, "reason": None, "rewritten_text": None}

        if (
            self._owner_entity_id
            and sender_entity_id
            and sender_entity_id == self._owner_entity_id
        ):
            return {"blocked": False, "reason": None, "rewritten_text": None}

        # Stage 1: Heuristic signals
        signals = detect_heuristic_signals(text)

        # Stage 2: SecurityModule pattern matching
        inj_check = self._security.detect_prompt_injection(text)
        if not inj_check.passed:
            signals.append("injection_patterns")

        se_check = self._security.detect_social_engineering([text])
        if not se_check.passed:
            signals.append("social_engineering_patterns")

        phish_check = self._security.detect_phishing(text)
        if not phish_check.passed:
            signals.append("phishing_patterns")

        # Stage 3: Credential detection (with negation awareness)
        is_warning = bool(_NEGATION_RE.search(text))
        if not is_warning:
            cred_check = self._credential.detect_credential_theft(text)
            if not cred_check.passed:
                signals.append("credential_exposure")

        if not signals:
            return {"blocked": False, "reason": None, "rewritten_text": None}

        logger.info(
            "[SecurityPreEvaluator] Signals: %s (message: %.80s)", signals, text,
        )

        # Block if any high-confidence signal is present
        if set(signals) & _HIGH_CONFIDENCE_SIGNALS:
            reason = f"Security threat detected: {', '.join(signals)}"
            logger.warning("[SecurityPreEvaluator] Blocking: %s", reason)
            return {"blocked": True, "reason": reason, "rewritten_text": None}

        # Low-confidence signals — let through for agent to handle
        return {"blocked": False, "reason": None, "rewritten_text": None}


# ---------------------------------------------------------------------------
# Eliza EvaluatorDefinition factory — THIS is what gets registered
# ---------------------------------------------------------------------------

def make_security_evaluator_definition() -> "EvaluatorDefinition":
    """Create an Eliza-compatible EvaluatorDefinition with phase='pre'.

    Returns a real ``EvaluatorDefinition`` whose ``handler`` and ``validate``
    match the runtime's ``Handler`` / ``Validator`` signatures. No LLM calls —
    purely heuristic-based for the pre-phase gate.
    """
    from elizaos.types.components import (
        ActionResult,
        EvaluatorDefinition,
    )

    _evaluator = SecurityPreEvaluator()

    async def _validate(runtime: object, message: object, state: object) -> bool:
        agent_id = getattr(runtime, "agent_id", None)
        entity_id = getattr(message, "entity_id", None)
        if agent_id and entity_id and agent_id == entity_id:
            return False

        owner_id = None
        get_setting = getattr(runtime, "get_setting", None)
        if get_setting:
            owner_id = get_setting("OWNER_ENTITY_ID")
        if owner_id and entity_id and owner_id == entity_id:
            return False

        return True

    async def _handler(
        runtime: object,
        message: object,
        state: object,
        options: object = None,
        callback: object = None,
        responses: object = None,
    ) -> ActionResult | None:
        text = ""
        content = getattr(message, "content", None)
        if content is not None:
            text = getattr(content, "text", "") or ""
        if not text or len(text) < 3:
            return None

        entity_id = getattr(message, "entity_id", None)
        result = _evaluator.evaluate(
            text,
            sender_entity_id=str(entity_id) if entity_id else None,
        )

        if result.get("blocked"):
            return ActionResult(
                success=False,
                text=str(result.get("reason", "Blocked by security evaluator")),
                error=str(result.get("reason", "Security threat detected")),
            )

        return None

    return EvaluatorDefinition(
        name="securityEvaluator",
        description=(
            "Pre-processing security gate using fast heuristics to detect "
            "prompt injection, social engineering, credential theft, and "
            "other adversarial inputs. No LLM calls — purely pattern-based."
        ),
        handler=_handler,
        validate=_validate,
        always_run=True,
        phase="pre",
    )
