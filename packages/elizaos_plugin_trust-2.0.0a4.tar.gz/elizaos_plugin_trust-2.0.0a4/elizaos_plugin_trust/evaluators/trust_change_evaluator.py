"""
Trust change evaluator.

Detects significant trust score changes and threshold crossings,
and triggers notifications or actions when they occur.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from elizaos_plugin_trust.services.trust_engine import TrustEngine
from elizaos_plugin_trust.types.trust import TrustTrend


@dataclass(frozen=True)
class TrustChangeEvent:
    """Represents a detected trust change event."""

    entity_id: str
    event_type: str  # "threshold_crossed", "significant_change", "trend_shift"
    previous_score: float
    current_score: float
    delta: float
    threshold: float | None
    direction: str  # "up" or "down"
    description: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(frozen=True)
class TrustChangeConfig:
    """Configuration for the trust change evaluator."""

    significant_change_threshold: float = 0.1
    check_interval_hours: int = 1
    trust_thresholds: list[float] = field(
        default_factory=lambda: [0.3, 0.5, 0.7, 0.9]
    )


class TrustChangeEvaluator:
    """Monitors trust scores for significant changes and threshold crossings."""

    def __init__(
        self,
        trust_engine: TrustEngine,
        config: TrustChangeConfig | None = None,
    ) -> None:
        self._engine = trust_engine
        self._config = config or TrustChangeConfig()
        self._previous_scores: dict[str, float] = {}
        self._previous_trends: dict[str, TrustTrend] = {}
        self._event_history: list[TrustChangeEvent] = []

    @property
    def config(self) -> TrustChangeConfig:
        return self._config

    def evaluate(self, entity_id: str) -> list[TrustChangeEvent]:
        """Evaluate a single entity for trust changes.

        Compares the current trust score against the previously recorded
        score and detects threshold crossings, significant deltas, and
        trend shifts.
        """
        profile = self._engine.calculate_trust(entity_id)
        current_score = profile.overall_score
        current_trend = profile.trend

        previous_score = self._previous_scores.get(entity_id)
        previous_trend = self._previous_trends.get(entity_id)

        events: list[TrustChangeEvent] = []

        if previous_score is not None:
            delta = current_score - previous_score
            abs_delta = abs(delta)
            direction = "up" if delta >= 0 else "down"

            # Check significant change
            if abs_delta >= self._config.significant_change_threshold:
                events.append(TrustChangeEvent(
                    entity_id=entity_id,
                    event_type="significant_change",
                    previous_score=previous_score,
                    current_score=current_score,
                    delta=round(delta, 4),
                    threshold=None,
                    direction=direction,
                    description=(
                        f"Trust score changed by {delta:+.3f} "
                        f"({previous_score:.3f} -> {current_score:.3f})"
                    ),
                ))

            # Check threshold crossings
            for threshold in self._config.trust_thresholds:
                crossed_up = previous_score < threshold <= current_score
                crossed_down = previous_score >= threshold > current_score
                if crossed_up:
                    events.append(TrustChangeEvent(
                        entity_id=entity_id,
                        event_type="threshold_crossed",
                        previous_score=previous_score,
                        current_score=current_score,
                        delta=round(delta, 4),
                        threshold=threshold,
                        direction="up",
                        description=(
                            f"Trust score crossed above threshold {threshold:.2f} "
                            f"({previous_score:.3f} -> {current_score:.3f})"
                        ),
                    ))
                elif crossed_down:
                    events.append(TrustChangeEvent(
                        entity_id=entity_id,
                        event_type="threshold_crossed",
                        previous_score=previous_score,
                        current_score=current_score,
                        delta=round(delta, 4),
                        threshold=threshold,
                        direction="down",
                        description=(
                            f"Trust score dropped below threshold {threshold:.2f} "
                            f"({previous_score:.3f} -> {current_score:.3f})"
                        ),
                    ))

        # Detect trend shift
        if (
            previous_trend is not None
            and current_trend != previous_trend
            and current_trend != TrustTrend.INSUFFICIENT_DATA
        ):
            events.append(TrustChangeEvent(
                entity_id=entity_id,
                event_type="trend_shift",
                previous_score=previous_score or current_score,
                current_score=current_score,
                delta=0.0,
                threshold=None,
                direction="up" if current_trend == TrustTrend.INCREASING else "down",
                description=(
                    f"Trust trend changed from '{previous_trend.value}' "
                    f"to '{current_trend.value}'"
                ),
            ))

        # Update tracking state
        self._previous_scores[entity_id] = current_score
        self._previous_trends[entity_id] = current_trend
        self._event_history.extend(events)

        return events

    def evaluate_all(self) -> list[TrustChangeEvent]:
        """Evaluate all known entities for trust changes."""
        all_events: list[TrustChangeEvent] = []
        for entity_id in self._engine.get_all_entity_ids():
            all_events.extend(self.evaluate(entity_id))
        return all_events

    def get_event_history(
        self,
        entity_id: str | None = None,
        limit: int = 100,
    ) -> list[TrustChangeEvent]:
        """Retrieve past trust change events."""
        events = self._event_history
        if entity_id is not None:
            events = [e for e in events if e.entity_id == entity_id]
        return events[-limit:]

    def get_entities_below_threshold(self, threshold: float) -> list[str]:
        """Return entity IDs whose current score is below the given threshold."""
        return [
            eid
            for eid, score in self._previous_scores.items()
            if score < threshold
        ]

    def get_entities_above_threshold(self, threshold: float) -> list[str]:
        """Return entity IDs whose current score is at or above the given threshold."""
        return [
            eid
            for eid, score in self._previous_scores.items()
            if score >= threshold
        ]
