"""
Trust plugin providers.

Providers supply contextual information for agent decision-making.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, Union

from elizaos_plugin_trust.providers.roles import RolesProvider
from elizaos_plugin_trust.providers.security_status import SecurityStatusProvider
from elizaos_plugin_trust.providers.settings import TrustSettingsProvider
from elizaos_plugin_trust.providers.trust_profile import TrustProfileProvider

if TYPE_CHECKING:
    from elizaos_plugin_trust.services import TrustServices


@dataclass(frozen=True)
class ProviderContext:
    """Context provided to trust providers."""

    entity_id: str
    channel: str = "default"
    environment: str = "default"


class TrustProvider(Protocol):
    """Protocol that all trust providers must satisfy.

    The ``get`` method is async to support providers that perform I/O
    (database queries, API calls).  Implementations backed by in-memory
    services may execute synchronously within the async wrapper.
    """

    @property
    def name(self) -> str: ...

    @property
    def description(self) -> str: ...

    async def get(
        self,
        context: ProviderContext,
        services: TrustServices,
    ) -> dict[str, Union[str, int, float, bool, list, dict]]: ...


def get_all_providers() -> list[TrustProvider]:
    """Get all available trust providers."""
    return [
        TrustProfileProvider(),
        SecurityStatusProvider(),
        RolesProvider(),
        TrustSettingsProvider(),
    ]


__all__ = [
    "ProviderContext",
    "TrustProvider",
    "TrustProfileProvider",
    "SecurityStatusProvider",
    "RolesProvider",
    "TrustSettingsProvider",
    "get_all_providers",
]
