"""Roles provider."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from elizaos_plugin_trust.providers import ProviderContext
    from elizaos_plugin_trust.services import TrustServices


class RolesProvider:
    """Provides role information for the current entity."""

    @property
    def name(self) -> str:
        return "roles"

    @property
    def description(self) -> str:
        return (
            "Provides the current entity's role, permissions summary, "
            "and available roles in the system."
        )

    async def get(
        self,
        context: ProviderContext,
        services: TrustServices,
    ) -> dict[str, str | int | float | bool | list | dict]:
        ps = services.permission_system
        current_role = ps.get_entity_role(context.entity_id)

        permissions_summary: list[dict[str, str | int]] = []
        for perm in current_role.permissions:
            permissions_summary.append({
                "resource": perm.resource,
                "flags": perm.flags,
                "flags_str": perm.permission_flags.to_unix_string(),
            })

        available_roles: list[dict[str, str | int]] = []
        for name, role in sorted(ps.roles.items(), key=lambda kv: kv[1].level):
            available_roles.append({
                "name": name,
                "level": role.level,
                "description": role.description,
            })

        return {
            "entity_id": context.entity_id,
            "current_role": current_role.name,
            "role_level": current_role.level,
            "role_description": current_role.description,
            "permissions": permissions_summary,
            "available_roles": available_roles,
        }
