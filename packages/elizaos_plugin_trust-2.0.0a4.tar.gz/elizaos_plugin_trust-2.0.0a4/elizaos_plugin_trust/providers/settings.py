"""Trust settings provider."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from elizaos_plugin_trust.providers import ProviderContext
    from elizaos_plugin_trust.services import TrustServices


class TrustSettingsProvider:
    """Provides current trust calculation settings."""

    @property
    def name(self) -> str:
        return "trust_settings"

    @property
    def description(self) -> str:
        return (
            "Provides the current trust calculation configuration "
            "including decay rate, evidence window, and dimension weights."
        )

    async def get(
        self,
        context: ProviderContext,
        services: TrustServices,
    ) -> dict[str, str | int | float | bool | list | dict]:
        cfg = services.trust_engine.config
        return {
            "decay_rate": cfg.decay_rate,
            "evidence_window_days": cfg.evidence_window_days,
            "minimum_evidence_count": cfg.minimum_evidence_count,
            "confidence_threshold": cfg.confidence_threshold,
            "default_score": cfg.default_score,
            "dimension_weights": cfg.dimension_weights,
        }
