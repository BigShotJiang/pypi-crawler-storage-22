"""Trust profile provider."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from elizaos_plugin_trust.providers import ProviderContext
    from elizaos_plugin_trust.services import TrustServices


class TrustProfileProvider:
    """Provides the current trust profile for an entity."""

    @property
    def name(self) -> str:
        return "trust_profile"

    @property
    def description(self) -> str:
        return (
            "Provides multi-dimensional trust profile information "
            "for the current entity, including dimension scores, "
            "trend, and confidence."
        )

    async def get(
        self,
        context: ProviderContext,
        services: TrustServices,
    ) -> dict[str, str | int | float | bool | list | dict]:
        profile = services.trust_engine.calculate_trust(context.entity_id)
        dims = profile.dimensions.as_dict()

        return {
            "entity_id": profile.entity_id,
            "overall_score": profile.overall_score,
            "confidence": profile.confidence,
            "evidence_count": profile.evidence_count,
            "trend": profile.trend.value,
            "dimensions": dims,
            "first_interaction": profile.first_interaction.isoformat(),
            "last_interaction": profile.last_interaction.isoformat(),
        }
