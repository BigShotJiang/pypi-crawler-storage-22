"""
Trust plugin services.

Core service implementations for trust scoring, security detection,
permission management, credential protection, and LLM evaluation.
"""

from dataclasses import dataclass, field

from elizaos_plugin_trust.services.contextual_permission_system import (
    ContextualPermissionSystem,
)
from elizaos_plugin_trust.services.credential_protector import CredentialProtector
from elizaos_plugin_trust.services.llm_evaluator import LLMEvaluator
from elizaos_plugin_trust.services.security_module import SecurityModule
from elizaos_plugin_trust.services.trust_engine import TrustEngine


@dataclass
class TrustServices:
    """Container holding all trust-related service instances."""

    trust_engine: TrustEngine = field(default_factory=TrustEngine)
    security_module: SecurityModule = field(default_factory=SecurityModule)
    permission_system: ContextualPermissionSystem = field(
        default_factory=ContextualPermissionSystem
    )
    credential_protector: CredentialProtector = field(default_factory=CredentialProtector)
    llm_evaluator: LLMEvaluator = field(default_factory=LLMEvaluator)


__all__ = [
    "TrustEngine",
    "SecurityModule",
    "ContextualPermissionSystem",
    "CredentialProtector",
    "LLMEvaluator",
    "TrustServices",
]
