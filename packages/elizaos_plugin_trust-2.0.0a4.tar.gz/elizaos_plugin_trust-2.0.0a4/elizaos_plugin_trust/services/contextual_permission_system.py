"""
Contextual permission system service.

Manages roles, permissions, and elevation requests with
Unix-style bitmask operations and hierarchy checking.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from uuid import uuid4

from elizaos_plugin_trust.types.permissions import (
    ContextualRole,
    ElevationRequest,
    ElevationResult,
    Permission,
    PermissionContext,
    PermissionDecision,
    PermissionFlag,
)

# Default role hierarchy
_DEFAULT_ROLES: list[ContextualRole] = [
    ContextualRole(
        name="guest",
        level=0,
        permissions=[Permission(resource="*", flags=int(PermissionFlag.READ))],
        description="Unauthenticated or minimal-trust entity",
    ),
    ContextualRole(
        name="user",
        level=10,
        permissions=[
            Permission(resource="*", flags=int(PermissionFlag.READ)),
            Permission(resource="messages", flags=int(PermissionFlag.READ_WRITE)),
            Permission(resource="own_profile", flags=int(PermissionFlag.READ_WRITE)),
        ],
        parent_role="guest",
        description="Standard authenticated entity",
    ),
    ContextualRole(
        name="moderator",
        level=50,
        permissions=[
            Permission(resource="*", flags=int(PermissionFlag.READ_WRITE)),
            Permission(resource="users", flags=int(PermissionFlag.READ_WRITE)),
            Permission(resource="messages", flags=int(PermissionFlag.ALL)),
        ],
        parent_role="user",
        description="Entity with moderation capabilities",
    ),
    ContextualRole(
        name="admin",
        level=90,
        permissions=[Permission(resource="*", flags=int(PermissionFlag.ALL))],
        parent_role="moderator",
        description="Administrative entity with full access",
        max_delegation_depth=3,
    ),
    ContextualRole(
        name="system",
        level=100,
        permissions=[Permission(resource="*", flags=int(PermissionFlag.ALL))],
        parent_role="admin",
        description="System-level access",
        max_delegation_depth=5,
    ),
]


class ContextualPermissionSystem:
    """Manages contextual roles, permissions, and temporary elevation."""

    def __init__(self, roles: list[ContextualRole] | None = None) -> None:
        self._roles: dict[str, ContextualRole] = {}
        self._entity_roles: dict[str, str] = {}
        self._active_elevations: dict[str, tuple[str, datetime]] = {}
        self._audit_log: list[dict[str, str | bool | int | float]] = []

        for role in (roles or _DEFAULT_ROLES):
            self._roles[role.name] = role

    @property
    def roles(self) -> dict[str, ContextualRole]:
        """All registered roles."""
        return dict(self._roles)

    def register_role(self, role: ContextualRole) -> None:
        """Register or overwrite a role."""
        self._roles[role.name] = role

    def assign_role(self, entity_id: str, role_name: str) -> None:
        """Assign a role to an entity."""
        if role_name not in self._roles:
            raise ValueError(f"Unknown role: {role_name}")
        self._entity_roles[entity_id] = role_name
        self._audit_log.append({
            "action": "assign_role",
            "entity_id": entity_id,
            "role": role_name,
        })

    def get_entity_role(self, entity_id: str) -> ContextualRole:
        """Get the effective role (includes active elevations)."""
        if entity_id in self._active_elevations:
            elevated_role, expires = self._active_elevations[entity_id]
            if datetime.now(timezone.utc) < expires:
                return self._roles[elevated_role]
            del self._active_elevations[entity_id]

        role_name = self._entity_roles.get(entity_id, "guest")
        return self._roles.get(role_name, self._roles["guest"])

    def check_permission(self, context: PermissionContext) -> PermissionDecision:
        """Check if an entity has the required permission."""
        role = self.get_entity_role(context.entity_id)
        required_flag = context.required_flag
        constraints_applied: list[str] = []
        audit_id = uuid4().hex

        granted, reason = self._check_role_permissions(
            role, context.resource, required_flag, constraints_applied
        )

        if not granted and role.parent_role:
            granted, reason = self._check_hierarchy(
                role.parent_role, context.resource, required_flag, constraints_applied
            )

        self._audit_log.append({
            "action": "check_permission",
            "entity_id": context.entity_id,
            "role": role.name,
            "resource": context.resource,
            "requested_action": context.action,
            "granted": granted,
            "audit_id": audit_id,
        })

        return PermissionDecision(
            granted=granted,
            role=role.name,
            permission_flags=int(required_flag),
            reason=reason,
            constraints_applied=constraints_applied,
            audit_log_id=audit_id,
        )

    def request_elevation(self, request: ElevationRequest) -> ElevationResult:
        """Process a temporary permission elevation request."""
        audit_id = uuid4().hex
        now = datetime.now(timezone.utc)

        if request.requested_role not in self._roles:
            return ElevationResult(
                approved=False,
                denial_reason=f"Unknown role: {request.requested_role}",
                audit_log_id=audit_id,
            )

        current_role = self.get_entity_role(request.entity_id)
        requested_role = self._roles[request.requested_role]

        if requested_role.level <= current_role.level:
            return ElevationResult(
                approved=False,
                denial_reason=(
                    f"Requested role '{request.requested_role}' (level {requested_role.level}) "
                    f"is not above current role '{current_role.name}' (level {current_role.level})"
                ),
                audit_log_id=audit_id,
            )

        max_elevation_level = current_role.level + (current_role.max_delegation_depth * 20)
        if requested_role.level > max_elevation_level:
            return ElevationResult(
                approved=False,
                denial_reason=(
                    f"Requested role level {requested_role.level} exceeds maximum "
                    f"elevation from '{current_role.name}' (max: {max_elevation_level})"
                ),
                audit_log_id=audit_id,
            )

        max_duration = min(request.duration_minutes, 480)
        expires_at = now + timedelta(minutes=max_duration)

        self._active_elevations[request.entity_id] = (request.requested_role, expires_at)

        conditions: list[str] = [
            f"Elevated to '{request.requested_role}' for {max_duration} minutes",
            f"Expires at {expires_at.isoformat()}",
        ]
        if max_duration < request.duration_minutes:
            conditions.append(
                f"Duration capped from {request.duration_minutes} to {max_duration} minutes"
            )

        self._audit_log.append({
            "action": "elevation_granted",
            "entity_id": request.entity_id,
            "from_role": current_role.name,
            "to_role": request.requested_role,
            "reason": request.reason,
            "audit_id": audit_id,
        })

        return ElevationResult(
            approved=True,
            granted_role=request.requested_role,
            expires_at=expires_at,
            conditions=conditions,
            audit_log_id=audit_id,
        )

    def revoke_elevation(self, entity_id: str) -> bool:
        """Revoke an active elevation. Returns True if one was active."""
        if entity_id in self._active_elevations:
            del self._active_elevations[entity_id]
            self._audit_log.append({"action": "elevation_revoked", "entity_id": entity_id})
            return True
        return False

    def get_audit_log(
        self,
        entity_id: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, str | bool | int | float]]:
        """Retrieve audit log entries, optionally filtered by entity."""
        entries = self._audit_log
        if entity_id is not None:
            entries = [e for e in entries if e.get("entity_id") == entity_id]
        return entries[-limit:]

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _check_role_permissions(
        self,
        role: ContextualRole,
        resource: str,
        required: PermissionFlag,
        constraints_applied: list[str],
    ) -> tuple[bool, str]:
        for perm in role.permissions:
            if perm.resource == resource or perm.resource == "*":
                if perm.allows(required):
                    valid, msg = perm.constraint.check_all()
                    constraints_applied.append(msg)
                    if valid:
                        return True, f"Granted by role '{role.name}' on resource '{perm.resource}'"
        return False, f"No matching permission in role '{role.name}' for '{resource}'"

    def _check_hierarchy(
        self,
        parent_name: str,
        resource: str,
        required: PermissionFlag,
        constraints_applied: list[str],
        depth: int = 0,
    ) -> tuple[bool, str]:
        if depth > 10:
            return False, "Maximum hierarchy depth exceeded"
        parent = self._roles.get(parent_name)
        if parent is None:
            return False, f"Parent role '{parent_name}' not found"
        granted, reason = self._check_role_permissions(parent, resource, required, constraints_applied)
        if granted:
            return True, f"{reason} (inherited)"
        if parent.parent_role:
            return self._check_hierarchy(parent.parent_role, resource, required, constraints_applied, depth + 1)
        return False, f"Permission not found in hierarchy up to '{parent.name}'"
