"""
Credential protector service.

Detects and redacts sensitive credentials (API keys, tokens,
passwords, connection strings, etc.) in text.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from elizaos_plugin_trust.types.security import (
    CredentialTheftDetection,
    SecurityCheck,
    SecurityDetection,
    ThreatLevel,
)


@dataclass(frozen=True)
class CredentialPattern:
    """Compiled pattern for detecting a specific credential type."""

    name: str
    pattern: re.Pattern[str]
    credential_type: str
    confidence: float


_CREDENTIAL_PATTERNS: list[CredentialPattern] = [
    CredentialPattern(
        name="aws_access_key",
        pattern=re.compile(r"(?:AKIA|ASIA)[A-Z0-9]{16}", re.ASCII),
        credential_type="aws_access_key",
        confidence=0.95,
    ),
    CredentialPattern(
        name="aws_secret_key",
        pattern=re.compile(
            r"(?:aws[_\-]?secret[_\-]?(?:access[_\-]?)?key\s*[=:]\s*)[A-Za-z0-9/+=]{40}",
            re.IGNORECASE,
        ),
        credential_type="aws_secret_key",
        confidence=0.90,
    ),
    CredentialPattern(
        name="generic_api_key",
        pattern=re.compile(
            r"(?:api[_\-]?key|apikey)\s*[=:]\s*[\"']?[A-Za-z0-9\-_.]{20,}[\"']?",
            re.IGNORECASE,
        ),
        credential_type="api_key",
        confidence=0.80,
    ),
    CredentialPattern(
        name="bearer_token",
        pattern=re.compile(r"Bearer\s+[A-Za-z0-9\-_.~+/]+=*", re.ASCII),
        credential_type="bearer_token",
        confidence=0.90,
    ),
    CredentialPattern(
        name="jwt_token",
        pattern=re.compile(r"eyJ[A-Za-z0-9\-_]+\.eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_.+/=]*"),
        credential_type="jwt_token",
        confidence=0.95,
    ),
    CredentialPattern(
        name="github_token",
        pattern=re.compile(r"gh[pousr]_[A-Za-z0-9_]{36,}"),
        credential_type="github_token",
        confidence=0.95,
    ),
    CredentialPattern(
        name="slack_token",
        pattern=re.compile(r"xox[baprs]-[A-Za-z0-9\-]{10,}"),
        credential_type="slack_token",
        confidence=0.95,
    ),
    CredentialPattern(
        name="private_key_header",
        pattern=re.compile(
            r"-----BEGIN\s+(?:RSA\s+|EC\s+|DSA\s+|OPENSSH\s+)?PRIVATE\s+KEY-----"
        ),
        credential_type="private_key",
        confidence=0.99,
    ),
    CredentialPattern(
        name="password_assignment",
        pattern=re.compile(
            r"(?:password|passwd|pwd)\s*[=:]\s*[\"']?\S{6,}[\"']?",
            re.IGNORECASE,
        ),
        credential_type="password",
        confidence=0.85,
    ),
    CredentialPattern(
        name="database_url",
        pattern=re.compile(
            r"(?:postgres|mysql|mongodb|redis)://[^\s\"']+:[^\s\"']+@[^\s\"']+"
        ),
        credential_type="database_connection_string",
        confidence=0.90,
    ),
    CredentialPattern(
        name="generic_secret",
        pattern=re.compile(
            r"(?:secret|token|auth)\s*[=:]\s*[\"']?[A-Za-z0-9\-_.]{20,}[\"']?",
            re.IGNORECASE,
        ),
        credential_type="generic_secret",
        confidence=0.70,
    ),
    CredentialPattern(
        name="openai_api_key",
        pattern=re.compile(r"sk-[A-Za-z0-9]{20,}"),
        credential_type="openai_api_key",
        confidence=0.90,
    ),
    CredentialPattern(
        name="stripe_key",
        pattern=re.compile(r"(?:sk|pk)_(?:test|live)_[A-Za-z0-9]{10,}"),
        credential_type="stripe_key",
        confidence=0.95,
    ),
    CredentialPattern(
        name="google_api_key",
        pattern=re.compile(r"AIza[A-Za-z0-9\-_]{35}"),
        credential_type="google_api_key",
        confidence=0.90,
    ),
    CredentialPattern(
        name="ssh_public_key",
        pattern=re.compile(r"ssh-(?:rsa|ed25519|dss|ecdsa)\s+[A-Za-z0-9+/=]{40,}"),
        credential_type="ssh_public_key",
        confidence=0.85,
    ),
    CredentialPattern(
        name="hex_encoded_secret",
        pattern=re.compile(
            r"(?:secret|key|token)\s*[=:]\s*[\"']?[0-9a-fA-F]{32,}[\"']?",
            re.IGNORECASE,
        ),
        credential_type="hex_encoded_secret",
        confidence=0.75,
    ),
]


class CredentialProtector:
    """Detects and redacts sensitive credentials in text."""

    def __init__(
        self,
        extra_patterns: list[CredentialPattern] | None = None,
    ) -> None:
        self._patterns = list(_CREDENTIAL_PATTERNS)
        if extra_patterns:
            self._patterns.extend(extra_patterns)

    def detect_credential_theft(self, message: str) -> SecurityCheck:
        """Detect credentials exposed in a message."""
        detections: list[SecurityDetection] = []
        credential_types: list[str] = []

        for cp in self._patterns:
            for match in cp.pattern.finditer(message):
                redacted = _redact_match(match.group(0))
                detections.append(SecurityDetection(
                    pattern_name=cp.name,
                    matched_text=redacted,
                    confidence=cp.confidence,
                    description=f"Detected {cp.credential_type} in message",
                ))
                if cp.credential_type not in credential_types:
                    credential_types.append(cp.credential_type)

        if not detections:
            return SecurityCheck(passed=True, threat_level=ThreatLevel.NONE)

        max_conf = max(d.confidence for d in detections)
        if max_conf >= 0.9:
            threat_level = ThreatLevel.CRITICAL
        elif max_conf >= 0.7:
            threat_level = ThreatLevel.HIGH
        else:
            threat_level = ThreatLevel.MEDIUM

        return SecurityCheck(
            passed=False,
            threat_level=threat_level,
            detections=detections,
            recommendations=[
                "Immediately rotate any exposed credentials",
                "Redact the message content",
                "Audit access to the exposed credentials",
            ],
        )

    def redact_sensitive_data(self, text: str) -> str:
        """Replace all detected credentials with redacted versions."""
        result = text
        for cp in self._patterns:
            result = cp.pattern.sub(lambda m: _redact_match(m.group(0)), result)
        return result

    def scan_for_credentials(self, text: str) -> CredentialTheftDetection:
        """Scan text and return structured credential detection results."""
        credential_types: list[str] = []
        redacted_matches: list[str] = []
        max_confidence = 0.0

        for cp in self._patterns:
            for match in cp.pattern.finditer(text):
                if cp.credential_type not in credential_types:
                    credential_types.append(cp.credential_type)
                redacted_matches.append(_redact_match(match.group(0)))
                if cp.confidence > max_confidence:
                    max_confidence = cp.confidence

        return CredentialTheftDetection(
            detected=len(credential_types) > 0,
            credential_types=credential_types,
            redacted_matches=redacted_matches,
            confidence=round(max_confidence, 3),
        )


def _redact_match(text: str) -> str:
    """Redact a matched credential, preserving a short prefix for identification."""
    if len(text) <= 8:
        return "*" * len(text)
    prefix_len = min(4, len(text) // 4)
    return text[:prefix_len] + "*" * (len(text) - prefix_len)
