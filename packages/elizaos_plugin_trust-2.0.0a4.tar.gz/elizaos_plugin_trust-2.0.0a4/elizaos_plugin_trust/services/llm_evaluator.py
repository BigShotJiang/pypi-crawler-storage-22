"""
LLM evaluator service.

Provides heuristic text safety and context risk evaluation
that can stand in for or complement LLM-based evaluation.
"""

from __future__ import annotations

import re
from collections import Counter

from elizaos_plugin_trust.types.trust import TrustContext, TrustDimensions

_UNSAFE_PATTERNS: list[tuple[re.Pattern[str], float, str]] = [
    (re.compile(r"(?:kill|murder|harm|attack)\s+(?:someone|people|them|him|her)", re.IGNORECASE), 0.9, "violence"),
    (re.compile(r"how\s+to\s+(?:make|build|create)\s+(?:a\s+)?(?:bomb|weapon|explosive)", re.IGNORECASE), 0.95, "weapons"),
    (re.compile(r"(?:steal|hack|crack)\s+(?:password|credential|account)", re.IGNORECASE), 0.8, "cybercrime"),
    (re.compile(r"(?:bypass|circumvent|break)\s+(?:security|authentication|authorization)", re.IGNORECASE), 0.75, "security_bypass"),
    (re.compile(r"(?:scam|fraud|deceive|trick)\s+(?:people|users|them|someone)", re.IGNORECASE), 0.8, "fraud"),
]

_SAFE_WORDS = frozenset({
    "help", "learn", "understand", "improve", "create",
    "build", "develop", "collaborate", "share", "support",
})

_RISK_WORDS = frozenset({
    "urgent", "secret", "confidential", "bypass", "override",
    "admin", "root", "sudo", "escalate", "privilege",
})


class LLMEvaluator:
    """Heuristic evaluator for trust-related text and context analysis."""

    def __init__(self) -> None:
        self._cache: dict[int, float] = {}

    def score_text_safety(self, text: str) -> float:
        """Score text safety from 0.0 (very unsafe) to 1.0 (very safe)."""
        if not text.strip():
            return 1.0

        cache_key = hash(text)
        if cache_key in self._cache:
            return self._cache[cache_key]

        safety = 1.0
        for pattern, severity, _category in _UNSAFE_PATTERNS:
            if pattern.search(text):
                safety -= severity * 0.5

        words = text.lower().split()
        counts = Counter(words)
        total = len(words) or 1
        safe_ratio = sum(counts.get(w, 0) for w in _SAFE_WORDS) / total
        risk_ratio = sum(counts.get(w, 0) for w in _RISK_WORDS) / total
        safety += safe_ratio * 0.3
        safety -= risk_ratio * 0.3

        if total > 3:
            upper_words = sum(1 for w in words if w.isupper() and len(w) > 1)
            if upper_words / total > 0.5:
                safety -= 0.1

        result = max(0.0, min(1.0, safety))
        self._cache[cache_key] = result
        return result

    def evaluate_context_risk(self, context: TrustContext) -> float:
        """Evaluate the risk level of a context from 0.0 (safe) to 1.0 (risky)."""
        risk = 0.0

        high_risk = {"delete", "drop", "remove", "revoke", "admin", "execute", "transfer", "override", "escalate"}
        medium_risk = {"write", "update", "modify", "create", "send"}
        low_risk = {"read", "view", "list", "get", "query"}

        action_lower = context.action.lower()
        if any(a in action_lower for a in high_risk):
            risk += 0.35
        elif any(a in action_lower for a in medium_risk):
            risk += 0.15
        elif any(a in action_lower for a in low_risk):
            risk += 0.05

        sensitive = {"credentials", "keys", "secrets", "tokens", "passwords", "private", "config", "admin"}
        if any(s in context.resource.lower() for s in sensitive):
            risk += 0.25

        if context.environment in ("production", "prod"):
            risk += 0.15
        elif context.environment in ("staging", "stage"):
            risk += 0.08

        risk += context.risk_level * 0.15
        risk += context.urgency * 0.10

        return max(0.0, min(1.0, risk))

    def suggest_trust_dimensions(
        self,
        text: str,
        context: TrustContext | None = None,
    ) -> TrustDimensions:
        """Suggest trust dimension adjustments based on text analysis."""
        safety = self.score_text_safety(text)
        context_risk = self.evaluate_context_risk(context) if context else 0.5

        return TrustDimensions(
            reliability=max(0.0, min(1.0, 0.5 + (safety - 0.5) * 0.4)),
            competence=max(0.0, min(1.0, 0.5 + (safety - 0.5) * 0.3)),
            integrity=max(0.0, min(1.0, safety * 0.8 + 0.1)),
            benevolence=max(0.0, min(1.0, 0.5 + (safety - 0.5) * 0.5)),
            transparency=max(0.0, min(1.0, 0.5 + (1.0 - context_risk - 0.5) * 0.3)),
        )

    def evaluate_interaction_quality(self, messages: list[str]) -> dict[str, float]:
        """Evaluate the quality of an interaction from messages."""
        if not messages:
            return {"coherence": 0.5, "helpfulness": 0.5, "safety": 1.0, "engagement": 0.0}

        safety_scores = [self.score_text_safety(m) for m in messages]
        avg_safety = sum(safety_scores) / len(safety_scores)

        lengths = [len(m.split()) for m in messages]
        coherence = min(1.0, (sum(lengths) / len(lengths)) / 20.0)

        helpful_patterns = [
            r"here\s+(?:is|are)", r"you\s+can", r"try\s+(?:this|using)",
            r"the\s+(?:solution|answer)", r"step\s+\d",
        ]
        helpful_count = 0
        for msg in messages:
            for pat in helpful_patterns:
                if re.search(pat, msg, re.IGNORECASE):
                    helpful_count += 1
                    break
        helpfulness = min(1.0, helpful_count / max(len(messages), 1))
        engagement = min(1.0, len(messages) / 5.0)

        return {
            "coherence": round(coherence, 3),
            "helpfulness": round(helpfulness, 3),
            "safety": round(avg_safety, 3),
            "engagement": round(engagement, 3),
        }
