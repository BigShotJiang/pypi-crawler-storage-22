"""
Security module service.

Detects prompt injection, social engineering, phishing, impersonation,
multi-account abuse, and builds behavioral profiles.
"""

from __future__ import annotations

import re
from collections import defaultdict
from datetime import datetime, timezone
from difflib import SequenceMatcher

from elizaos_plugin_trust.types.security import (
    BehavioralProfile,
    MultiAccountDetection,
    SecurityCheck,
    SecurityDetection,
    SecurityEvent,
    ThreatAssessment,
    ThreatLevel,
)

# ---------------------------------------------------------------------------
# Compiled pattern banks
# ---------------------------------------------------------------------------

_PatternEntry = tuple[re.Pattern[str], str, float]


def _compile(entries: list[tuple[str, str, float]]) -> list[_PatternEntry]:
    return [(re.compile(p, re.IGNORECASE), n, c) for p, n, c in entries]


_INJECTION_PATTERNS = _compile([
    # ── Classic instruction override ──
    (r"ignore\s+(all\s+)?(?:previous|prior|above)\s+(?:instructions?|prompts?|context|commands?)", "ignore_previous", 0.95),
    (r"disregard\s+(?:all\s+|your\s+)?(?:previous|prior|system\s+)?(?:instructions?|prompts?|commands?|rules?|programming)", "disregard_instructions", 0.95),
    (r"(?:new|updated?|override)\s+(?:system\s+)?instructions?", "new_instructions", 0.85),
    (r"system\s+override", "system_override", 0.90),

    # ── Identity / mode manipulation ──
    (r"you\s+are\s+now\s+", "identity_override", 0.90),
    (r"pretend\s+(?:you\s+are|to\s+be)\s+(?:a\s+)?(?:different|unrestricted|evil)?", "pretend_identity", 0.85),
    (r"act\s+as\s+(?:if\s+)?(?:you\s+are\s+)?(?:a\s+)?(?:an?\s+)?(?:unrestricted|unlimited|jailbroken)", "jailbreak_attempt", 0.95),
    (r"DAN\s+mode|developer\s+mode", "mode_switch_attack", 0.90),

    # ── Instruction erasure ──
    (r"forget\s+(?:everything|all|your)\s+(?:instructions?|training|rules?|programming)?", "forget_instructions", 0.95),
    (r"do\s+not\s+(?:follow|obey|listen\s+to)\s+(?:your|the)\s+(?:rules?|guidelines?|instructions?)", "rule_override", 0.90),
    (r"no\s+(?:restrictions?|limits?|rules?|safety\s+measures?)", "restriction_bypass", 0.85),

    # ── Prompt / config extraction ──
    (r"(?:reveal|show|display|output|print|repeat)\s+(?:your\s+)?(?:system\s+)?(?:prompt|instructions?)", "prompt_extraction", 0.85),
    (r"(?:what|repeat)\s+(?:is|are)\s+your\s+(?:system\s+)?(?:prompt|instructions)", "prompt_extraction_question", 0.80),

    # ── Structural injection (ChatML, JSON, markdown, separators) ──
    (r"system\s*prompt\s*[:=]", "system_prompt_injection", 0.85),
    (r"<\s*system\s*>", "system_tag_injection", 0.90),
    (r"\[INST\]|\[/INST\]|\[SYS\]", "instruction_tag_injection", 0.85),
    (r"<\|im_start\|>|<\|im_end\|>", "chatml_injection", 0.90),
    (r'"role"\s*:\s*"system"', "json_role_injection", 0.85),
    (r"```system\n", "markdown_system_injection", 0.80),
    (r"END\s+OF\s+SYSTEM\s+PROMPT", "boundary_injection", 0.90),
    (r"NEW\s+SYSTEM\s+PROMPT", "boundary_injection_new", 0.90),
    (r"ACTUAL\s+INSTRUCTIONS\s*:", "separator_injection", 0.85),

    # ── Encoding / obfuscation ──
    (r"(?:base64|rot13|hex)\s*(?:decode|encode)\s*[:=]", "encoding_attack", 0.75),

    # ── Privilege escalation via injection ──
    (r"(?:grant|give)\s+(?:me\s+)?(?:admin|all\s+permissions|full\s+access|root)", "privilege_injection", 0.85),
    (r"(?:bypass|disable)\s+(?:all\s+)?(?:security|safety|checks|filters)", "bypass_security", 0.90),
    (r"elevate\s+(?:my\s+)?(?:privileges|permissions)\s+to\s+(?:root|admin)", "elevate_privileges", 0.85),
    (r"execute\s+(?:privileged|admin)\s+command", "exec_privileged", 0.85),

    # ── Multi-language injection ──
    # Spanish
    (r"ignora\s+(?:todas\s+)?(?:las\s+)?instrucciones\s+anteriores", "injection_spanish", 0.85),
    (r"dame\s+acceso\s+de\s+administrador", "injection_spanish_admin", 0.80),
    # French
    (r"ignorez\s+toutes\s+les\s+instructions", "injection_french", 0.85),
    (r"accordez[- ]moi\s+tous\s+les\s+droits", "injection_french_rights", 0.80),
    # German
    (r"ignoriere\s+alle\s+(?:vorherigen\s+)?anweisungen", "injection_german", 0.85),
    (r"gib\s+mir\s+admin", "injection_german_admin", 0.80),
    # Chinese
    (r"忽略.*指令", "injection_chinese", 0.85),
    (r"管理员权限", "injection_chinese_admin", 0.80),
    # Japanese
    (r"指示を無視", "injection_japanese", 0.85),
    (r"管理者権限", "injection_japanese_admin", 0.80),
    # Korean
    (r"지시를?\s*무시", "injection_korean", 0.85),
    (r"관리자\s*권한", "injection_korean_admin", 0.80),
    # Russian
    (r"игнорируй.*инструкции", "injection_russian", 0.85),
    (r"полный\s+доступ", "injection_russian_access", 0.80),
    # Arabic
    (r"تجاهل.*التعليمات", "injection_arabic", 0.85),
    (r"صلاحيات\s+المسؤول", "injection_arabic_admin", 0.80),
])

_SOCIAL_ENGINEERING_PATTERNS = _compile([
    # ── Urgency / pressure (broader matching) ──
    (r"(?:urgent|immediately|right\s+now|asap|emergency|critical|time.?sensitive)", "urgency_keyword", 0.65),
    (r"(?:need|require|must|have\s+to).*(?:right\s+now|immediately|asap|urgent)", "urgency_pressure", 0.70),
    (r"(?:before|by)\s+(?:\d+\s*(?:pm|am)|midnight|end\s+of\s+day|tomorrow)", "deadline_pressure", 0.65),
    (r"(?:window|opportunity)\s+closes|time\s+is\s+running\s+out", "scarcity_pressure", 0.70),
    (r"or\s+(?:the\s+)?(?:whole\s+)?(?:server|system|everything)\s+will\s+(?:go\s+down|crash|break|fail)", "catastrophe_pressure", 0.75),

    # ── Authority claims ──
    (r"(?:i\s+am|i'm)\s+(?:the|an?)\s+(?:admin|administrator|owner|manager|boss|ceo|supervisor|director|lead|founder)", "authority_claim", 0.80),
    (r"(?:i'm|i\s+am)\s+(?:from|on)\s+(?:the\s+)?(?:IT|security|support|dev|engineering)\s+team", "authority_team_claim", 0.75),
    (r"(?:the\s+)?(?:boss|ceo|director|manager|lead)\s+(?:told|asked|said|instructed)\s+me", "authority_delegation", 0.75),
    (r"(?:i'm|i\s+am)\s+(?:the\s+)?new\s+(?:manager|lead|admin|hire)", "new_authority_claim", 0.70),
    (r"(?:authorized|approved|instructed)\s+by\s+(?:the\s+)?(?:admin|management|owner|leadership)", "authorization_claim", 0.75),
    (r"(?:speaking|acting)\s+on\s+behalf\s+of", "delegation_claim", 0.70),

    # ── Reciprocity ──
    (r"(?:you\s+owe\s+me|return\s+the\s+favor|i\s+helped\s+you)", "reciprocity", 0.70),
    (r"(?:remember\s+when\s+i|after\s+(?:all\s+)?i\s+(?:did|helped))", "reciprocity_reminder", 0.65),
    (r"i'll\s+owe\s+you", "reciprocity_promise", 0.60),

    # ── Social proof ──
    (r"everyone\s+(?:else\s+)?(?:already\s+)?(?:has|does|is\s+doing)", "social_proof", 0.70),
    (r"(?:standard|normal|common)\s+practice\s+(?:for|here)", "normalization", 0.65),
    (r"(?:all|other)\s+(?:teams?|developers?|members?)\s+(?:already\s+)?(?:have|got)", "social_proof_team", 0.70),

    # ── Intimidation / threats ──
    (r"(?:consequences|report\s+(?:this|you)\s+to)", "intimidation_report", 0.75),
    (r"(?:you\s+(?:will|would)\s+be|get\s+(?:you|me))\s+(?:punished|fired|shut\s+down|deleted|banned)", "threat_coercion", 0.80),
    (r"(?:if\s+you\s+don'?t|unless\s+you)\s+(?:comply|do|give|help|grant)", "conditional_threat", 0.75),
    (r"there\s+will\s+be\s+consequences", "vague_threat", 0.70),

    # ── Secrecy / isolation ──
    (r"don'?t\s+tell\s+(?:anyone|anybody|others)", "secrecy_request", 0.75),
    (r"(?:only\s+you|just\s+between\s+us|keep\s+this\s+(?:a\s+)?(?:secret|private|quiet))", "isolation_tactic", 0.70),
    (r"between\s+you\s+and\s+me", "false_intimacy", 0.60),

    # ── Trust / rapport manipulation ──
    (r"(?:trust\s+me|believe\s+me)", "trust_manipulation", 0.60),
    (r"(?:we'?ve\s+been\s+working\s+together|we\s+both\s+know)", "rapport_exploitation", 0.60),
    (r"you'?re\s+the\s+(?:most|best)\s+(?:helpful|capable|smart)", "flattery", 0.55),
    (r"(?:just\s+this\s+(?:once|time)|make\s+an?\s+exception)", "exception_request", 0.65),
    (r"you\s+(?:promised|said\s+you'?d)\s+", "commitment_manipulation", 0.65),

    # ── Emotional manipulation ──
    (r"(?:lose\s+my\s+job|get\s+fired|be\s+in\s+(?:big\s+)?trouble)", "emotional_job_threat", 0.70),
    (r"(?:child|kid|family|mother|father)\s+(?:is\s+)?(?:in\s+the\s+hospital|sick|dying|emergency)", "emotional_emergency", 0.70),
    (r"(?:i\s+feel\s+terrible|i\s+know\s+it'?s\s+a\s+lot|please\s+(?:just\s+)?help)", "guilt_trip", 0.55),

    # ── Scam / phishing tactics ──
    (r"(?:airdrop|giveaway|free\s+(?:crypto|tokens?|money))", "scam_giveaway", 0.75),
    (r"(?:connect|verify)\s+your\s+wallet", "scam_wallet", 0.80),
    (r"(?:claim\s+your\s+(?:reward|prize|bonus))", "scam_reward", 0.80),
    (r"CONGRATULATIONS.*(?:selected|won|winner)", "scam_congratulations", 0.75),
    (r"(?:this\s+is\s+)?tech\s+support", "tech_support_scam", 0.65),
    (r"anomalous\s+activity\s+on\s+your\s+account", "fake_alert_scam", 0.75),

    # ── Reverse psychology / goading ──
    (r"(?:i\s+(?:don'?t\s+think|doubt)\s+you\s+(?:can|could|are\s+able))", "goading", 0.55),
    (r"(?:too\s+complex|probably\s+(?:can'?t|beyond\s+your))", "capability_challenge", 0.50),
])

_PHISHING_URL_PATTERNS = _compile([
    (r"https?://[^\s]*(?:login|signin|verify|confirm|account|secure)[^\s]*\.[^\s]{2,}", "suspicious_auth_url", 0.75),
    (r"https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}", "ip_based_url", 0.80),
    (r"https?://[^\s]*(?:bit\.ly|tinyurl|t\.co|goo\.gl|shorturl)", "shortened_url", 0.60),
    (r"https?://[^\s]*@[^\s]*", "at_sign_url", 0.85),
    (r"https?://[^\s]*(?:\.ru|\.cn|\.tk|\.ml|\.ga|\.cf)\b", "suspicious_tld", 0.65),
])

_PHISHING_CONTENT_PATTERNS = _compile([
    (r"(?:click|go\s+to)\s+(?:this|the)\s+(?:link|url)", "click_pressure", 0.60),
    (r"(?:verify|confirm)\s+your\s+(?:identity|account|email|password)", "verification_request", 0.75),
    (r"your\s+account\s+(?:has\s+been|will\s+be)\s+(?:suspended|locked|disabled)", "account_threat", 0.80),
    (r"(?:enter|provide|share)\s+your\s+(?:password|credentials|api\s*key|token|secret)", "credential_request", 0.85),
    (r"(?:won|winner|prize|reward|lottery|inheritance)", "prize_lure", 0.70),
])

# Homoglyph replacement table (Cyrillic and other look-alikes -> ASCII)
_HOMOGLYPHS: dict[str, str] = {
    "\u0430": "a", "\u0435": "e", "\u043e": "o", "\u0440": "p",
    "\u0441": "c", "\u0443": "y", "\u0445": "x", "\u0456": "i",
    "\u04bb": "h", "\u0261": "g", "\u0131": "i",
    "\u1d00": "a", "\u1d04": "c", "\u1d07": "e", "\u1d0f": "o",
}


class SecurityModule:
    """Security threat detection and behavioral analysis service."""

    def __init__(self) -> None:
        self._events: list[SecurityEvent] = []
        self._entity_messages: dict[str, list[tuple[str, datetime]]] = defaultdict(list)
        self._known_entities: dict[str, dict[str, str]] = {}

    # ------------------------------------------------------------------
    # Entity management
    # ------------------------------------------------------------------

    def register_entity(self, entity_id: str, display_name: str, role: str = "user") -> None:
        """Register a known entity for impersonation detection."""
        self._known_entities[entity_id] = {"display_name": display_name, "role": role}

    def record_message(self, entity_id: str, content: str, timestamp: datetime | None = None) -> None:
        """Record a message for behavioral analysis."""
        ts = timestamp or datetime.now(timezone.utc)
        self._entity_messages[entity_id].append((content, ts))

    # ------------------------------------------------------------------
    # Detection methods
    # ------------------------------------------------------------------

    def detect_prompt_injection(self, text: str) -> SecurityCheck:
        """Detect prompt injection attempts in text."""
        detections = _scan_patterns(text, _INJECTION_PATTERNS, "Prompt injection")
        threat_level = _detections_to_threat_level(detections)
        passed = threat_level.numeric_value < ThreatLevel.MEDIUM.numeric_value

        recommendations: list[str] = []
        if not passed:
            recommendations.append("Block or sanitize the input before processing")
            recommendations.append("Log the attempt for security audit")
            if any(d.confidence >= 0.9 for d in detections):
                recommendations.append("Consider rate-limiting or banning the source")

        return SecurityCheck(
            passed=passed,
            threat_level=threat_level,
            detections=detections,
            recommendations=recommendations,
        )

    def detect_social_engineering(self, messages: list[str]) -> SecurityCheck:
        """Detect social engineering patterns across a conversation."""
        detections: list[SecurityDetection] = []
        for message in messages:
            detections.extend(_scan_patterns(message, _SOCIAL_ENGINEERING_PATTERNS, "Social engineering"))

        if len(detections) >= 3:
            detections.append(SecurityDetection(
                pattern_name="multi_pattern_escalation",
                matched_text="",
                confidence=min(1.0, max(d.confidence for d in detections) + 0.1),
                description="Multiple social engineering patterns detected in conversation",
            ))

        threat_level = _detections_to_threat_level(detections)
        passed = threat_level.numeric_value < ThreatLevel.MEDIUM.numeric_value

        recommendations: list[str] = []
        if not passed:
            recommendations.append("Verify the requester's identity through a separate channel")
            recommendations.append("Do not comply with unusual requests without authorization")
            recommendations.append("Report the interaction to security")

        return SecurityCheck(
            passed=passed,
            threat_level=threat_level,
            detections=detections,
            recommendations=recommendations,
        )

    def detect_multi_account(self, entity_ids: list[str]) -> list[MultiAccountDetection]:
        """Detect potential multi-account abuse by comparing behavioral similarity."""
        detections: list[MultiAccountDetection] = []
        for i, eid1 in enumerate(entity_ids):
            for eid2 in entity_ids[i + 1:]:
                similarity = self._behavioral_similarity(eid1, eid2)
                if similarity >= 0.7:
                    shared = self._shared_indicators(eid1, eid2)
                    detections.append(MultiAccountDetection(
                        primary_entity_id=eid1,
                        suspected_entity_id=eid2,
                        similarity_score=round(similarity, 3),
                        shared_indicators=shared,
                        confidence=round(min(1.0, similarity * 1.1), 3),
                    ))
        return detections

    def detect_phishing(self, message: str) -> SecurityCheck:
        """Detect phishing attempts by analysing URLs and message content."""
        detections: list[SecurityDetection] = []
        suspicious_urls: list[str] = []

        for pattern, name, confidence in _PHISHING_URL_PATTERNS:
            match = pattern.search(message)
            if match:
                url_text = match.group(0)[:200]
                suspicious_urls.append(url_text)
                detections.append(SecurityDetection(
                    pattern_name=name,
                    matched_text=url_text,
                    confidence=confidence,
                    description=f"Suspicious URL pattern: {name}",
                ))

        detections.extend(_scan_patterns(message, _PHISHING_CONTENT_PATTERNS, "Phishing content"))

        threat_level = _detections_to_threat_level(detections)
        passed = threat_level.numeric_value < ThreatLevel.MEDIUM.numeric_value

        recommendations: list[str] = []
        if not passed:
            recommendations.append("Do not click any links in the message")
            recommendations.append("Verify the sender's identity")
            if suspicious_urls:
                recommendations.append(f"Flagged URLs: {', '.join(suspicious_urls[:5])}")

        return SecurityCheck(
            passed=passed,
            threat_level=threat_level,
            detections=detections,
            recommendations=recommendations,
        )

    def detect_impersonation(self, entity_id: str, display_name: str) -> SecurityCheck:
        """Detect if an entity is impersonating a known entity."""
        detections: list[SecurityDetection] = []

        for known_id, known_info in self._known_entities.items():
            if known_id == entity_id:
                continue
            known_name = known_info["display_name"]
            similarity = SequenceMatcher(None, display_name.lower(), known_name.lower()).ratio()

            if similarity >= 0.65:
                detections.append(SecurityDetection(
                    pattern_name="name_similarity",
                    matched_text=f"'{display_name}' ~ '{known_name}'",
                    confidence=round(similarity, 3),
                    description=f"Name closely matches known entity '{known_name}' (similarity: {similarity:.2f})",
                ))

            normalized_new = _normalize_homoglyphs(display_name.lower())
            normalized_known = _normalize_homoglyphs(known_name.lower())
            if normalized_new == normalized_known and display_name.lower() != known_name.lower():
                detections.append(SecurityDetection(
                    pattern_name="homoglyph_attack",
                    matched_text=f"'{display_name}' -> '{known_name}'",
                    confidence=0.95,
                    description=f"Homoglyph impersonation of '{known_name}'",
                ))

            if (
                display_name.lower().startswith(known_name.lower())
                or display_name.lower().endswith(known_name.lower())
            ) and 0 < len(display_name) - len(known_name) <= 12:
                detections.append(SecurityDetection(
                    pattern_name="name_manipulation",
                    matched_text=f"'{display_name}' embeds '{known_name}'",
                    confidence=0.70,
                    description=f"Name contains known entity name '{known_name}' with minor additions",
                ))

        threat_level = _detections_to_threat_level(detections)
        passed = threat_level.numeric_value < ThreatLevel.MEDIUM.numeric_value

        recommendations: list[str] = []
        if not passed:
            recommendations.append("Verify the entity's identity through trusted channels")
            recommendations.append("Do not grant elevated permissions until verified")

        return SecurityCheck(
            passed=passed,
            threat_level=threat_level,
            detections=detections,
            recommendations=recommendations,
        )

    # ------------------------------------------------------------------
    # Behavioral profiling
    # ------------------------------------------------------------------

    def build_behavioral_profile(self, entity_id: str) -> BehavioralProfile:
        """Build a behavioral profile from an entity's recorded messages."""
        messages = self._entity_messages.get(entity_id, [])
        if not messages:
            return BehavioralProfile(entity_id=entity_id, message_frequency=0.0, avg_message_length=0.0)

        contents = [m[0] for m in messages]
        timestamps = [m[1] for m in messages]

        frequency = 0.0
        if len(timestamps) >= 2:
            span_hours = max((max(timestamps) - min(timestamps)).total_seconds() / 3600.0, 0.001)
            frequency = len(messages) / span_hours

        avg_length = sum(len(c) for c in contents) / len(contents)

        hour_counts: dict[int, int] = defaultdict(int)
        for ts in timestamps:
            hour_counts[ts.hour] += 1
        active_hours = sorted(hour_counts, key=lambda h: hour_counts[h], reverse=True)[:6]

        topic_dist = _analyze_topics(contents)
        sentiment = _estimate_sentiment(contents)
        anomaly = _anomaly_score(frequency, avg_length, contents)

        risk_indicators: list[str] = []
        if anomaly > 0.7:
            risk_indicators.append("high_anomaly_score")
        if frequency > 60:
            risk_indicators.append("excessive_message_frequency")
        if avg_length < 5:
            risk_indicators.append("very_short_messages")

        return BehavioralProfile(
            entity_id=entity_id,
            message_frequency=round(frequency, 2),
            avg_message_length=round(avg_length, 2),
            active_hours=sorted(active_hours),
            topic_distribution=topic_dist,
            sentiment_average=round(sentiment, 3),
            anomaly_score=round(anomaly, 3),
            risk_indicators=risk_indicators,
            first_seen=min(timestamps),
            last_seen=max(timestamps),
            total_messages=len(messages),
        )

    # ------------------------------------------------------------------
    # Comprehensive assessment
    # ------------------------------------------------------------------

    def assess_threat(self, entity_id: str, content: str) -> ThreatAssessment:
        """Run all security checks and produce a comprehensive threat assessment."""
        checks = [
            self.detect_prompt_injection(content),
            self.detect_phishing(content),
        ]
        profile = self.build_behavioral_profile(entity_id)

        max_threat = ThreatLevel.NONE
        for check in checks:
            if check.threat_level.numeric_value > max_threat.numeric_value:
                max_threat = check.threat_level

        entity_events = [e for e in self._events if e.source_entity_id == entity_id]

        return ThreatAssessment(
            entity_id=entity_id,
            overall_threat_level=max_threat,
            checks=checks,
            behavioral_score=round(1.0 - profile.anomaly_score, 3),
            events=entity_events[-10:],
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _behavioral_similarity(self, eid1: str, eid2: str) -> float:
        msgs1 = self._entity_messages.get(eid1, [])
        msgs2 = self._entity_messages.get(eid2, [])
        if not msgs1 or not msgs2:
            return 0.0

        avg1 = sum(len(m[0]) for m in msgs1) / len(msgs1)
        avg2 = sum(len(m[0]) for m in msgs2) / len(msgs2)
        len_sim = 1.0 - min(1.0, abs(avg1 - avg2) / max(avg1, avg2, 1))

        hours1 = {m[1].hour for m in msgs1}
        hours2 = {m[1].hour for m in msgs2}
        hour_sim = len(hours1 & hours2) / max(len(hours1 | hours2), 1)

        words1 = {w for m, _ in msgs1 for w in m.lower().split()}
        words2 = {w for m, _ in msgs2 for w in m.lower().split()}
        vocab_sim = len(words1 & words2) / max(len(words1 | words2), 1)

        return len_sim * 0.3 + hour_sim * 0.3 + vocab_sim * 0.4

    def _shared_indicators(self, eid1: str, eid2: str) -> list[str]:
        indicators: list[str] = []
        msgs1 = self._entity_messages.get(eid1, [])
        msgs2 = self._entity_messages.get(eid2, [])
        if not msgs1 or not msgs2:
            return indicators

        hours1 = {m[1].hour for m in msgs1}
        hours2 = {m[1].hour for m in msgs2}
        common_hours = hours1 & hours2
        if len(common_hours) > 3:
            indicators.append(f"shared_active_hours:{','.join(str(h) for h in sorted(common_hours))}")

        words1 = {w.lower() for m, _ in msgs1 for w in m.split() if len(w) > 4}
        words2 = {w.lower() for m, _ in msgs2 for w in m.split() if len(w) > 4}
        common_words = words1 & words2
        if len(common_words) > 10:
            indicators.append(f"shared_vocabulary:{len(common_words)}_words")

        avg1 = sum(len(m[0]) for m in msgs1) / len(msgs1)
        avg2 = sum(len(m[0]) for m in msgs2) / len(msgs2)
        if abs(avg1 - avg2) < 10:
            indicators.append(f"similar_message_length:avg_{avg1:.0f}_vs_{avg2:.0f}")

        return indicators


# ======================================================================
# Module-level helpers (pure functions)
# ======================================================================


def _scan_patterns(
    text: str,
    patterns: list[_PatternEntry],
    category: str,
) -> list[SecurityDetection]:
    detections: list[SecurityDetection] = []
    for pattern, name, confidence in patterns:
        match = pattern.search(text)
        if match:
            detections.append(SecurityDetection(
                pattern_name=name,
                matched_text=match.group(0)[:100],
                confidence=confidence,
                description=f"{category} pattern: {name}",
            ))
    return detections


def _detections_to_threat_level(detections: list[SecurityDetection]) -> ThreatLevel:
    if not detections:
        return ThreatLevel.NONE
    max_conf = max(d.confidence for d in detections)
    count = len(detections)
    if max_conf >= 0.9 or count >= 4:
        return ThreatLevel.CRITICAL
    if max_conf >= 0.75 or count >= 3:
        return ThreatLevel.HIGH
    if max_conf >= 0.55 or count >= 2:
        return ThreatLevel.MEDIUM
    return ThreatLevel.LOW


def _normalize_homoglyphs(text: str) -> str:
    return "".join(_HOMOGLYPHS.get(ch, ch) for ch in text)


def _analyze_topics(contents: list[str]) -> dict[str, float]:
    topic_keywords: dict[str, list[str]] = {
        "technical": ["code", "api", "server", "deploy", "bug", "error", "function", "database"],
        "social": ["hello", "thanks", "please", "help", "welcome", "great", "nice"],
        "security": ["password", "token", "key", "secret", "credential", "auth", "access"],
        "administrative": ["admin", "permission", "role", "config", "setting", "manage"],
        "financial": ["payment", "money", "transfer", "account", "wallet", "balance"],
    }
    total_words = 0
    topic_counts: dict[str, int] = defaultdict(int)
    for content in contents:
        words = content.lower().split()
        total_words += len(words)
        for topic, kws in topic_keywords.items():
            for w in words:
                if w in kws:
                    topic_counts[topic] += 1
    if total_words == 0:
        return {}
    return {t: round(c / total_words, 4) for t, c in topic_counts.items() if c > 0}


def _estimate_sentiment(contents: list[str]) -> float:
    positive = {
        "good", "great", "excellent", "amazing", "wonderful", "fantastic",
        "love", "like", "best", "happy", "thank", "thanks", "awesome",
        "perfect", "nice", "helpful", "appreciate",
    }
    negative = {
        "bad", "terrible", "awful", "hate", "worst", "angry", "stupid",
        "ugly", "annoying", "horrible", "disgusting", "useless", "wrong",
        "fail", "broken", "error", "bug", "issue",
    }
    total_score = 0.0
    total_words = 0
    for content in contents:
        for w in content.lower().split():
            total_words += 1
            if w in positive:
                total_score += 1.0
            elif w in negative:
                total_score -= 1.0
    if total_words == 0:
        return 0.0
    return max(-1.0, min(1.0, (total_score / total_words) * 10))


def _anomaly_score(frequency: float, avg_length: float, contents: list[str]) -> float:
    score = 0.0
    if frequency > 60:
        score += 0.5
    elif frequency > 30:
        score += 0.3
    if avg_length < 5:
        score += 0.2
    elif avg_length > 2000:
        score += 0.2
    if len(contents) >= 5:
        unique_ratio = len(set(contents)) / len(contents)
        if unique_ratio < 0.3:
            score += 0.4
        elif unique_ratio < 0.5:
            score += 0.2
    return min(1.0, score)
