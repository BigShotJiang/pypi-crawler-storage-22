"""
Trust engine service.

Calculates multi-dimensional trust scores with exponential decay
on evidence, trend analysis, and contextual adjustments.
"""

from __future__ import annotations

import math
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from elizaos_plugin_trust.types.trust import (
    EVIDENCE_DIMENSION_MAP,
    TrustCalculationConfig,
    TrustContext,
    TrustDecision,
    TrustDimensions,
    TrustEvidence,
    TrustProfile,
    TrustRequirements,
    TrustTrend,
)


class TrustEngine:
    """Multi-dimensional trust scoring engine with exponential decay."""

    def __init__(self, config: TrustCalculationConfig | None = None) -> None:
        self._config = config or TrustCalculationConfig()
        self._evidence_store: dict[str, list[TrustEvidence]] = defaultdict(list)
        self._profile_cache: dict[str, TrustProfile] = {}

    @property
    def config(self) -> TrustCalculationConfig:
        """Current calculation configuration."""
        return self._config

    def record_evidence(self, evidence: TrustEvidence) -> None:
        """Record a new piece of trust evidence for an entity."""
        self._evidence_store[evidence.entity_id].append(evidence)
        self._profile_cache.pop(evidence.entity_id, None)

    def calculate_trust(
        self,
        entity_id: str,
        context: TrustContext | None = None,
    ) -> TrustProfile:
        """Calculate a comprehensive trust profile for an entity.

        Applies exponential decay to evidence, calculates dimension scores,
        determines overall score, trend, and confidence.
        """
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(days=self._config.evidence_window_days)

        all_evidence = self._evidence_store.get(entity_id, [])
        relevant = [e for e in all_evidence if e.timestamp >= cutoff]

        if not relevant:
            return self._default_profile(entity_id, now)

        dimensions = self._calculate_dimensions(relevant, now)
        overall = dimensions.weighted_average(self._config.dimension_weights)

        if context is not None:
            overall = self._apply_context_adjustment(overall, context)

        confidence = self._calculate_confidence(len(relevant))
        trend = self._calculate_trend(entity_id, now)

        first_interaction = min(e.timestamp for e in all_evidence)
        last_interaction = max(e.timestamp for e in relevant)

        profile = TrustProfile(
            entity_id=entity_id,
            dimensions=dimensions,
            overall_score=min(1.0, max(0.0, overall)),
            evidence_count=len(relevant),
            first_interaction=first_interaction,
            last_interaction=last_interaction,
            trend=trend,
            confidence=confidence,
        )
        self._profile_cache[entity_id] = profile
        return profile

    def evaluate_decision(
        self,
        context: TrustContext,
        requirements: TrustRequirements,
    ) -> TrustDecision:
        """Evaluate whether an entity meets trust requirements for an action."""
        profile = self.calculate_trust(context.entity_id, context)

        reasons: list[str] = []
        conditions: list[str] = []
        allowed = True

        if profile.overall_score < requirements.minimum_overall_score:
            allowed = False
            reasons.append(
                f"Overall score {profile.overall_score:.3f} below "
                f"minimum {requirements.minimum_overall_score:.3f}"
            )

        if profile.evidence_count < requirements.minimum_evidence_count:
            allowed = False
            reasons.append(
                f"Evidence count {profile.evidence_count} below "
                f"minimum {requirements.minimum_evidence_count}"
            )

        if profile.confidence < requirements.minimum_confidence:
            allowed = False
            reasons.append(
                f"Confidence {profile.confidence:.3f} below "
                f"minimum {requirements.minimum_confidence:.3f}"
            )

        if requirements.minimum_dimensions is not None:
            min_dims = requirements.minimum_dimensions.as_dict()
            actual_dims = profile.dimensions.as_dict()
            for dim_name, min_val in min_dims.items():
                actual_val = actual_dims.get(dim_name, 0.0)
                if actual_val < min_val:
                    allowed = False
                    reasons.append(
                        f"Dimension '{dim_name}' score {actual_val:.3f} "
                        f"below minimum {min_val:.3f}"
                    )

        if requirements.required_trend is not None:
            if profile.trend != requirements.required_trend:
                conditions.append(
                    f"Trend is '{profile.trend.value}' but "
                    f"'{requirements.required_trend.value}' preferred"
                )

        if allowed:
            reasoning = "Trust requirements met"
            if conditions:
                reasoning += f" with notes: {'; '.join(conditions)}"
        else:
            reasoning = "Trust requirements not met: " + "; ".join(reasons)

        return TrustDecision(
            allowed=allowed,
            trust_score=profile.overall_score,
            required_score=requirements.minimum_overall_score,
            confidence=profile.confidence,
            reasoning=reasoning,
            conditions=conditions,
            dimension_scores=profile.dimensions,
        )

    def get_trust_trend(
        self,
        entity_id: str,
        window_days: int = 30,
    ) -> list[float]:
        """Get daily trust scores over a time window for trend analysis."""
        now = datetime.now(timezone.utc)
        all_evidence = self._evidence_store.get(entity_id, [])
        if not all_evidence:
            return []

        scores: list[float] = []
        for days_ago in range(window_days, -1, -1):
            ref_date = now - timedelta(days=days_ago)
            cutoff = ref_date - timedelta(days=self._config.evidence_window_days)
            relevant = [e for e in all_evidence if cutoff <= e.timestamp <= ref_date]
            if relevant:
                dims = self._calculate_dimensions(relevant, ref_date)
                score = dims.weighted_average(self._config.dimension_weights)
                scores.append(min(1.0, max(0.0, score)))
        return scores

    def get_evidence(self, entity_id: str) -> list[TrustEvidence]:
        """Get all stored evidence for an entity."""
        return list(self._evidence_store.get(entity_id, []))

    def clear_evidence(self, entity_id: str) -> int:
        """Clear all evidence for an entity. Returns the number removed."""
        count = len(self._evidence_store.get(entity_id, []))
        self._evidence_store.pop(entity_id, None)
        self._profile_cache.pop(entity_id, None)
        return count

    def get_all_entity_ids(self) -> list[str]:
        """Return all entity IDs that have recorded evidence."""
        return list(self._evidence_store.keys())

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _calculate_dimensions(
        self,
        evidence_list: list[TrustEvidence],
        reference_time: datetime,
    ) -> TrustDimensions:
        """Calculate trust dimensions from evidence with exponential decay."""
        dim_values: dict[str, list[tuple[float, float]]] = {
            "reliability": [],
            "competence": [],
            "integrity": [],
            "benevolence": [],
            "transparency": [],
        }

        for evidence in evidence_list:
            affected_dims = EVIDENCE_DIMENSION_MAP.get(evidence.evidence_type, [])
            decayed_w = evidence.decayed_weight(self._config.decay_rate, reference_time)
            for dim_name in affected_dims:
                if dim_name in dim_values:
                    dim_values[dim_name].append((evidence.value, decayed_w))

        calculated: dict[str, float] = {}
        for dim_name, pairs in dim_values.items():
            if not pairs:
                calculated[dim_name] = self._config.default_score
                continue
            total_weight = sum(w for _, w in pairs)
            if total_weight == 0.0:
                calculated[dim_name] = self._config.default_score
                continue
            weighted_sum = sum(v * w for v, w in pairs)
            calculated[dim_name] = min(1.0, max(0.0, weighted_sum / total_weight))

        return TrustDimensions(**calculated)

    def _calculate_confidence(self, evidence_count: int) -> float:
        """Calculate confidence based on the amount of available evidence."""
        if evidence_count == 0:
            return 0.0
        min_count = self._config.minimum_evidence_count
        if min_count <= 0:
            return 1.0
        ratio = evidence_count / min_count
        return min(1.0, 1.0 - math.exp(-1.5 * ratio))

    def _calculate_trend(self, entity_id: str, now: datetime) -> TrustTrend:
        """Determine the trust score trend (increasing/decreasing/stable/volatile)."""
        all_evidence = self._evidence_store.get(entity_id, [])
        if len(all_evidence) < 3:
            return TrustTrend.INSUFFICIENT_DATA

        midpoint = now - timedelta(days=self._config.evidence_window_days // 2)
        recent = [e for e in all_evidence if e.timestamp >= midpoint]
        older = [e for e in all_evidence if e.timestamp < midpoint]

        if not recent or not older:
            return TrustTrend.INSUFFICIENT_DATA

        recent_avg = sum(e.value for e in recent) / len(recent)
        older_avg = sum(e.value for e in older) / len(older)

        # Detect volatility in recent evidence
        if len(recent) >= 3:
            variance = sum((e.value - recent_avg) ** 2 for e in recent) / len(recent)
            if variance > 0.04:
                return TrustTrend.VOLATILE

        diff = recent_avg - older_avg
        if diff > 0.05:
            return TrustTrend.INCREASING
        elif diff < -0.05:
            return TrustTrend.DECREASING
        return TrustTrend.STABLE

    def _apply_context_adjustment(self, score: float, context: TrustContext) -> float:
        """Adjust trust score based on context risk and urgency."""
        risk_penalty = context.risk_level * 0.15
        urgency_bonus = context.urgency * 0.05
        return min(1.0, max(0.0, score - risk_penalty + urgency_bonus))

    def _default_profile(self, entity_id: str, now: datetime) -> TrustProfile:
        """Create a default profile for an entity with no evidence."""
        return TrustProfile(
            entity_id=entity_id,
            dimensions=TrustDimensions(),
            overall_score=self._config.default_score,
            evidence_count=0,
            first_interaction=now,
            last_interaction=now,
            trend=TrustTrend.INSUFFICIENT_DATA,
            confidence=0.0,
        )
