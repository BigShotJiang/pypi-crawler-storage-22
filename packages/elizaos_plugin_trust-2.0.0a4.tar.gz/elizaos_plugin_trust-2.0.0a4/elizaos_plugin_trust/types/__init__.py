"""
Trust plugin type definitions.

Re-exports all types from sub-modules for convenient access.
"""

from elizaos_plugin_trust.types.permissions import (
    ContextualRole,
    ElevationRequest,
    ElevationResult,
    Permission,
    PermissionConstraint,
    PermissionContext,
    PermissionDecision,
    PermissionFlag,
    TimeWindow,
)
from elizaos_plugin_trust.types.security import (
    BehavioralProfile,
    CoordinationDetection,
    CredentialTheftDetection,
    ImpersonationDetection,
    MultiAccountDetection,
    PhishingDetection,
    PhishingIndicator,
    SecurityCheck,
    SecurityContext,
    SecurityDetection,
    SecurityEvent,
    SecurityEventType,
    ThreatAssessment,
    ThreatLevel,
)
from elizaos_plugin_trust.types.trust import (
    ALL_DIMENSIONS,
    EVIDENCE_DIMENSION_MAP,
    TrustCalculationConfig,
    TrustContext,
    TrustDecision,
    TrustDimensions,
    TrustEvidence,
    TrustEvidenceType,
    TrustProfile,
    TrustRequirements,
    TrustTrend,
)

__all__ = [
    # Trust types
    "TrustDimensions",
    "TrustEvidence",
    "TrustEvidenceType",
    "TrustProfile",
    "TrustContext",
    "TrustDecision",
    "TrustRequirements",
    "TrustCalculationConfig",
    "TrustTrend",
    "EVIDENCE_DIMENSION_MAP",
    "ALL_DIMENSIONS",
    # Security types
    "ThreatLevel",
    "SecurityEventType",
    "SecurityDetection",
    "SecurityCheck",
    "SecurityContext",
    "SecurityEvent",
    "ThreatAssessment",
    "MultiAccountDetection",
    "PhishingIndicator",
    "PhishingDetection",
    "ImpersonationDetection",
    "CoordinationDetection",
    "CredentialTheftDetection",
    "BehavioralProfile",
    # Permission types
    "PermissionFlag",
    "TimeWindow",
    "PermissionConstraint",
    "Permission",
    "ContextualRole",
    "PermissionContext",
    "PermissionDecision",
    "ElevationRequest",
    "ElevationResult",
]
