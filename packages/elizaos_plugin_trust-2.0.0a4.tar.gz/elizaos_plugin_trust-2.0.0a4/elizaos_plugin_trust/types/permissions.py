"""
Permission-related type definitions.

Unix-style permissions with bitmask operations and contextual roles.
"""

from __future__ import annotations

from datetime import datetime, time, timezone
from enum import IntFlag
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field


class PermissionFlag(IntFlag):
    """Unix-style permission flags using bitmask operations."""

    NONE = 0
    EXECUTE = 1   # 0b001
    WRITE = 2     # 0b010
    READ = 4      # 0b100
    READ_WRITE = READ | WRITE              # 6
    READ_EXECUTE = READ | EXECUTE          # 5
    WRITE_EXECUTE = WRITE | EXECUTE        # 3
    ALL = READ | WRITE | EXECUTE           # 7

    def has_read(self) -> bool:
        """Check if READ flag is set."""
        return bool(self & PermissionFlag.READ)

    def has_write(self) -> bool:
        """Check if WRITE flag is set."""
        return bool(self & PermissionFlag.WRITE)

    def has_execute(self) -> bool:
        """Check if EXECUTE flag is set."""
        return bool(self & PermissionFlag.EXECUTE)

    def to_unix_string(self) -> str:
        """Convert to rwx string representation."""
        r = "r" if self.has_read() else "-"
        w = "w" if self.has_write() else "-"
        x = "x" if self.has_execute() else "-"
        return f"{r}{w}{x}"

    @classmethod
    def from_unix_string(cls, s: str) -> PermissionFlag:
        """Parse 'rwx' string into PermissionFlag."""
        if len(s) != 3:
            raise ValueError(f"Expected 3-character permission string, got '{s}'")
        flags = cls.NONE
        if s[0] == "r":
            flags |= cls.READ
        elif s[0] != "-":
            raise ValueError(f"Invalid read character: '{s[0]}', expected 'r' or '-'")
        if s[1] == "w":
            flags |= cls.WRITE
        elif s[1] != "-":
            raise ValueError(f"Invalid write character: '{s[1]}', expected 'w' or '-'")
        if s[2] == "x":
            flags |= cls.EXECUTE
        elif s[2] != "-":
            raise ValueError(f"Invalid execute character: '{s[2]}', expected 'x' or '-'")
        return flags

    @classmethod
    def from_octal(cls, value: int) -> PermissionFlag:
        """Create from octal integer (0-7)."""
        if not 0 <= value <= 7:
            raise ValueError(f"Octal permission must be 0-7, got {value}")
        return cls(value)


class TimeWindow(BaseModel):
    """Time-of-day window during which a permission is valid."""

    model_config = ConfigDict(frozen=True)

    start: time
    end: time

    def contains(self, t: time) -> bool:
        """Check if a time falls within this window (handles midnight crossings)."""
        if self.start <= self.end:
            return self.start <= t <= self.end
        # Crosses midnight: e.g. 22:00 -> 06:00
        return t >= self.start or t <= self.end


class PermissionConstraint(BaseModel):
    """Constraints on a permission grant."""

    model_config = ConfigDict(frozen=True)

    time_window: TimeWindow | None = None
    ip_whitelist: list[str] = Field(default_factory=list)
    max_uses: int | None = Field(default=None, ge=1)
    current_uses: int = Field(default=0, ge=0)
    requires_mfa: bool = False
    expires_at: datetime | None = None
    cooldown_seconds: int | None = Field(default=None, ge=0)
    last_used_at: datetime | None = None

    def is_expired(self, now: datetime | None = None) -> bool:
        """Check if the permission has expired."""
        ref = now or datetime.now(timezone.utc)
        if self.expires_at is not None and ref >= self.expires_at:
            return True
        return False

    def is_exhausted(self) -> bool:
        """Check if maximum uses have been reached."""
        if self.max_uses is not None and self.current_uses >= self.max_uses:
            return True
        return False

    def is_within_time_window(self, now: datetime | None = None) -> bool:
        """Check if the current time is within the allowed time window."""
        if self.time_window is None:
            return True
        ref = now or datetime.now(timezone.utc)
        return self.time_window.contains(ref.time())

    def is_within_cooldown(self, now: datetime | None = None) -> bool:
        """Check if the permission is within its cooldown period."""
        if self.cooldown_seconds is None or self.last_used_at is None:
            return False
        ref = now or datetime.now(timezone.utc)
        elapsed = (ref - self.last_used_at).total_seconds()
        return elapsed < self.cooldown_seconds

    def check_all(self, now: datetime | None = None) -> tuple[bool, str]:
        """Check all constraints. Returns (passed, message)."""
        if self.is_expired(now):
            return False, "Permission has expired"
        if self.is_exhausted():
            return False, f"Maximum uses ({self.max_uses}) exhausted"
        if not self.is_within_time_window(now):
            return False, "Outside allowed time window"
        if self.is_within_cooldown(now):
            return False, "Within cooldown period"
        return True, "All constraints satisfied"


class Permission(BaseModel):
    """A permission grant for a specific resource."""

    model_config = ConfigDict(frozen=True)

    resource: str
    flags: int = Field(default=int(PermissionFlag.NONE), ge=0, le=7)
    constraint: PermissionConstraint = Field(default_factory=PermissionConstraint)

    @property
    def permission_flags(self) -> PermissionFlag:
        """Get the flags as a PermissionFlag enum."""
        return PermissionFlag(self.flags)

    def allows(self, requested: PermissionFlag) -> bool:
        """Check if this permission grants the requested flags."""
        return (self.permission_flags & requested) == requested


class ContextualRole(BaseModel):
    """A role with contextual permissions and hierarchy support."""

    model_config = ConfigDict(frozen=True)

    name: str
    level: int = Field(ge=0, description="Higher level = more authority")
    permissions: list[Permission] = Field(default_factory=list)
    parent_role: str | None = None
    description: str = ""
    max_delegation_depth: int = Field(
        default=1, ge=0, description="How deep this role can delegate"
    )

    def has_permission(
        self, resource: str, required: PermissionFlag, now: datetime | None = None
    ) -> bool:
        """Check if this role directly grants the required permission."""
        for perm in self.permissions:
            if perm.resource == resource or perm.resource == "*":
                if perm.allows(required):
                    valid, _ = perm.constraint.check_all(now)
                    if valid:
                        return True
        return False

    def outranks(self, other: ContextualRole) -> bool:
        """Return True if this role's level exceeds the other's."""
        return self.level > other.level


class PermissionContext(BaseModel):
    """Context for a permission check request."""

    model_config = ConfigDict(frozen=True)

    entity_id: str
    role: str
    resource: str
    action: str  # "read", "write", "execute"
    environment: str = Field(default="default")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict[str, str | int | float | bool] = Field(default_factory=dict)

    @property
    def required_flag(self) -> PermissionFlag:
        """Map action string to the corresponding PermissionFlag."""
        mapping: dict[str, PermissionFlag] = {
            "read": PermissionFlag.READ,
            "write": PermissionFlag.WRITE,
            "execute": PermissionFlag.EXECUTE,
        }
        return mapping.get(self.action, PermissionFlag.NONE)


class PermissionDecision(BaseModel):
    """Result of a permission check."""

    model_config = ConfigDict(frozen=True)

    granted: bool
    role: str
    permission_flags: int = Field(ge=0, le=7)
    reason: str
    constraints_applied: list[str] = Field(default_factory=list)
    audit_log_id: str = Field(default_factory=lambda: uuid4().hex)


class ElevationRequest(BaseModel):
    """Request to temporarily elevate permissions."""

    model_config = ConfigDict(frozen=True)

    entity_id: str
    current_role: str
    requested_role: str
    reason: str
    duration_minutes: int = Field(ge=1, le=1440)
    context: PermissionContext


class ElevationResult(BaseModel):
    """Result of an elevation request."""

    model_config = ConfigDict(frozen=True)

    approved: bool
    granted_role: str | None = None
    expires_at: datetime | None = None
    conditions: list[str] = Field(default_factory=list)
    audit_log_id: str = Field(default_factory=lambda: uuid4().hex)
    denial_reason: str | None = None
