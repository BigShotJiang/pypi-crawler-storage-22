"""
Security-related type definitions.

Threat detection, behavioral analysis, and security event types.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field


class ThreatLevel(str, Enum):
    """Severity level of a security threat."""

    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @property
    def numeric_value(self) -> int:
        """Integer severity for comparison (0-4)."""
        _mapping: dict[str, int] = {
            "none": 0,
            "low": 1,
            "medium": 2,
            "high": 3,
            "critical": 4,
        }
        return _mapping[self.value]

    def at_least(self, other: ThreatLevel) -> bool:
        """Return True if this threat level is >= other."""
        return self.numeric_value >= other.numeric_value

    def exceeds(self, other: ThreatLevel) -> bool:
        """Return True if this threat level is strictly > other."""
        return self.numeric_value > other.numeric_value


class SecurityEventType(str, Enum):
    """Types of security events."""

    PROMPT_INJECTION = "prompt_injection"
    SOCIAL_ENGINEERING = "social_engineering"
    CREDENTIAL_THEFT = "credential_theft"
    PHISHING_ATTEMPT = "phishing_attempt"
    IMPERSONATION = "impersonation"
    MULTI_ACCOUNT_ABUSE = "multi_account_abuse"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    DATA_EXFILTRATION = "data_exfiltration"
    RATE_LIMIT_ABUSE = "rate_limit_abuse"
    BEHAVIORAL_ANOMALY = "behavioral_anomaly"


class SecurityDetection(BaseModel):
    """A single detection within a security check."""

    model_config = ConfigDict(frozen=True)

    pattern_name: str
    matched_text: str = Field(default="")
    confidence: float = Field(ge=0.0, le=1.0)
    description: str


class SecurityCheck(BaseModel):
    """Result of a security check."""

    model_config = ConfigDict(frozen=True)

    passed: bool
    threat_level: ThreatLevel = ThreatLevel.NONE
    detections: list[SecurityDetection] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
    checked_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class SecurityContext(BaseModel):
    """Context for a security evaluation."""

    model_config = ConfigDict(frozen=True)

    source_entity_id: str
    target_entity_id: str | None = None
    channel: str = Field(default="default")
    action: str = Field(default="")
    content: str = Field(default="")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict[str, str | int | float | bool] = Field(default_factory=dict)


class SecurityEvent(BaseModel):
    """A recorded security event."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(default_factory=lambda: uuid4().hex)
    event_type: SecurityEventType
    severity: ThreatLevel
    source_entity_id: str
    target_entity_id: str | None = None
    description: str
    evidence: dict[str, str | int | float | bool] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    resolved: bool = False


class ThreatAssessment(BaseModel):
    """Comprehensive threat assessment for an entity."""

    model_config = ConfigDict(frozen=True)

    entity_id: str
    overall_threat_level: ThreatLevel
    checks: list[SecurityCheck] = Field(default_factory=list)
    behavioral_score: float = Field(
        ge=0.0, le=1.0, description="0 = highly suspicious, 1 = normal"
    )
    events: list[SecurityEvent] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class MultiAccountDetection(BaseModel):
    """Detection of potential multi-account abuse."""

    model_config = ConfigDict(frozen=True)

    primary_entity_id: str
    suspected_entity_id: str
    similarity_score: float = Field(ge=0.0, le=1.0)
    shared_indicators: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)


class PhishingIndicator(BaseModel):
    """Single indicator of a phishing attempt."""

    model_config = ConfigDict(frozen=True)

    indicator_type: str
    value: str
    risk_score: float = Field(ge=0.0, le=1.0)


class PhishingDetection(BaseModel):
    """Detection of a phishing attempt."""

    model_config = ConfigDict(frozen=True)

    detected: bool
    confidence: float = Field(ge=0.0, le=1.0)
    indicators: list[PhishingIndicator] = Field(default_factory=list)
    suspicious_urls: list[str] = Field(default_factory=list)


class ImpersonationDetection(BaseModel):
    """Detection of an impersonation attempt."""

    model_config = ConfigDict(frozen=True)

    detected: bool
    impersonated_entity_id: str | None = None
    similarity_score: float = Field(ge=0.0, le=1.0)
    indicators: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)


class CoordinationDetection(BaseModel):
    """Detection of coordinated behavior across entities."""

    model_config = ConfigDict(frozen=True)

    detected: bool
    entity_ids: list[str] = Field(default_factory=list)
    coordination_score: float = Field(ge=0.0, le=1.0)
    shared_patterns: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)


class CredentialTheftDetection(BaseModel):
    """Detection of credential theft attempt."""

    model_config = ConfigDict(frozen=True)

    detected: bool
    credential_types: list[str] = Field(default_factory=list)
    redacted_matches: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)


class BehavioralProfile(BaseModel):
    """Behavioral profile for an entity built from message history."""

    model_config = ConfigDict(frozen=True)

    entity_id: str
    message_frequency: float = Field(ge=0.0, description="Messages per hour")
    avg_message_length: float = Field(ge=0.0)
    active_hours: list[int] = Field(
        default_factory=list, description="Hours (0-23) when entity is most active"
    )
    topic_distribution: dict[str, float] = Field(default_factory=dict)
    sentiment_average: float = Field(default=0.0, ge=-1.0, le=1.0)
    anomaly_score: float = Field(
        default=0.0, ge=0.0, le=1.0, description="0 = normal, 1 = highly anomalous"
    )
    risk_indicators: list[str] = Field(default_factory=list)
    first_seen: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_seen: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    total_messages: int = Field(default=0, ge=0)
