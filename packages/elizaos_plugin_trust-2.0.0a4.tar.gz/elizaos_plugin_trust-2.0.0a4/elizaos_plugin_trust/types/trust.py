"""
Trust-related type definitions.

Multi-dimensional trust scoring types using Pydantic v2.
"""

from __future__ import annotations

import math
from datetime import datetime, timezone
from enum import Enum
from typing import TypeAlias
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator


class TrustTrend(str, Enum):
    """Direction of trust score changes over time."""

    INCREASING = "increasing"
    DECREASING = "decreasing"
    STABLE = "stable"
    VOLATILE = "volatile"
    INSUFFICIENT_DATA = "insufficient_data"


class TrustEvidenceType(str, Enum):
    """Types of evidence that affect trust scoring."""

    TASK_COMPLETION = "task_completion"
    COMMUNICATION_QUALITY = "communication_quality"
    COMMITMENT_FOLLOW_THROUGH = "commitment_follow_through"
    ERROR_RECOVERY = "error_recovery"
    KNOWLEDGE_SHARING = "knowledge_sharing"
    BOUNDARY_RESPECT = "boundary_respect"
    CONSISTENCY = "consistency"
    CONFLICT_RESOLUTION = "conflict_resolution"
    RESOURCE_SHARING = "resource_sharing"
    VULNERABILITY_HANDLING = "vulnerability_handling"


DimensionName: TypeAlias = str

# Maps each evidence type to the trust dimensions it primarily affects.
EVIDENCE_DIMENSION_MAP: dict[TrustEvidenceType, list[DimensionName]] = {
    TrustEvidenceType.TASK_COMPLETION: ["competence", "reliability"],
    TrustEvidenceType.COMMUNICATION_QUALITY: ["transparency", "competence"],
    TrustEvidenceType.COMMITMENT_FOLLOW_THROUGH: ["reliability", "integrity"],
    TrustEvidenceType.ERROR_RECOVERY: ["competence", "reliability"],
    TrustEvidenceType.KNOWLEDGE_SHARING: ["benevolence", "transparency"],
    TrustEvidenceType.BOUNDARY_RESPECT: ["integrity", "benevolence"],
    TrustEvidenceType.CONSISTENCY: ["reliability", "integrity"],
    TrustEvidenceType.CONFLICT_RESOLUTION: ["benevolence", "competence"],
    TrustEvidenceType.RESOURCE_SHARING: ["benevolence", "transparency"],
    TrustEvidenceType.VULNERABILITY_HANDLING: ["integrity", "benevolence"],
}

ALL_DIMENSIONS: list[DimensionName] = [
    "reliability",
    "competence",
    "integrity",
    "benevolence",
    "transparency",
]


class TrustDimensions(BaseModel):
    """Multi-dimensional trust scores.

    Each dimension ranges from 0.0 (no trust) to 1.0 (full trust).
    """

    model_config = ConfigDict(frozen=True)

    reliability: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Consistency and dependability"
    )
    competence: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Ability to perform tasks effectively"
    )
    integrity: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Adherence to moral and ethical principles"
    )
    benevolence: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Genuine concern for others' wellbeing"
    )
    transparency: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Openness and honesty in communication"
    )

    def weighted_average(self, weights: dict[str, float] | None = None) -> float:
        """Calculate weighted average across all dimensions."""
        default_weights = {
            "reliability": 0.25,
            "competence": 0.20,
            "integrity": 0.25,
            "benevolence": 0.15,
            "transparency": 0.15,
        }
        w = weights or default_weights
        total_weight = sum(w.values())
        if total_weight == 0.0:
            return 0.0
        score = (
            self.reliability * w.get("reliability", 0.0)
            + self.competence * w.get("competence", 0.0)
            + self.integrity * w.get("integrity", 0.0)
            + self.benevolence * w.get("benevolence", 0.0)
            + self.transparency * w.get("transparency", 0.0)
        )
        return min(1.0, max(0.0, score / total_weight))

    def as_dict(self) -> dict[str, float]:
        """Return dimensions as a plain dictionary."""
        return {
            "reliability": self.reliability,
            "competence": self.competence,
            "integrity": self.integrity,
            "benevolence": self.benevolence,
            "transparency": self.transparency,
        }

    def distance_to(self, other: TrustDimensions) -> float:
        """Euclidean distance to another TrustDimensions vector."""
        return math.sqrt(
            (self.reliability - other.reliability) ** 2
            + (self.competence - other.competence) ** 2
            + (self.integrity - other.integrity) ** 2
            + (self.benevolence - other.benevolence) ** 2
            + (self.transparency - other.transparency) ** 2
        )


class TrustEvidence(BaseModel):
    """A piece of evidence that affects trust scoring."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(default_factory=lambda: uuid4().hex)
    entity_id: str
    evidence_type: TrustEvidenceType
    value: float = Field(ge=0.0, le=1.0, description="Evidence value between 0 and 1")
    weight: float = Field(default=1.0, ge=0.0, le=10.0, description="Importance weight")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    context: str = Field(default="", description="Description of the context")
    source: str = Field(default="system", description="Source of the evidence")
    metadata: dict[str, str | int | float | bool] = Field(default_factory=dict)

    def decayed_weight(self, decay_rate: float, reference_time: datetime | None = None) -> float:
        """Calculate weight after exponential time-decay."""
        ref = reference_time or datetime.now(timezone.utc)
        days_old = max(0.0, (ref - self.timestamp).total_seconds() / 86400.0)
        return self.weight * math.exp(-decay_rate * days_old)

    def decayed_contribution(
        self, decay_rate: float, reference_time: datetime | None = None
    ) -> float:
        """Calculate the decayed value contribution (value * decayed_weight)."""
        return self.value * self.decayed_weight(decay_rate, reference_time)


class TrustProfile(BaseModel):
    """Complete trust profile for an entity."""

    model_config = ConfigDict(frozen=True)

    entity_id: str
    dimensions: TrustDimensions
    overall_score: float = Field(ge=0.0, le=1.0)
    evidence_count: int = Field(ge=0)
    first_interaction: datetime
    last_interaction: datetime
    trend: TrustTrend = TrustTrend.INSUFFICIENT_DATA
    confidence: float = Field(ge=0.0, le=1.0, description="Confidence in the trust score")


class TrustContext(BaseModel):
    """Context for a trust evaluation request."""

    model_config = ConfigDict(frozen=True)

    entity_id: str
    action: str = Field(default="", description="Action being evaluated")
    resource: str = Field(default="", description="Resource being accessed")
    environment: str = Field(default="default", description="Environment context")
    urgency: float = Field(default=0.5, ge=0.0, le=1.0)
    risk_level: float = Field(default=0.5, ge=0.0, le=1.0)


class TrustRequirements(BaseModel):
    """Requirements that must be met for a trust decision."""

    model_config = ConfigDict(frozen=True)

    minimum_overall_score: float = Field(default=0.5, ge=0.0, le=1.0)
    minimum_dimensions: TrustDimensions | None = None
    minimum_evidence_count: int = Field(default=1, ge=0)
    minimum_confidence: float = Field(default=0.3, ge=0.0, le=1.0)
    required_trend: TrustTrend | None = None


class TrustDecision(BaseModel):
    """Result of a trust-based decision."""

    model_config = ConfigDict(frozen=True)

    allowed: bool
    trust_score: float = Field(ge=0.0, le=1.0)
    required_score: float = Field(ge=0.0, le=1.0)
    confidence: float = Field(ge=0.0, le=1.0)
    reasoning: str
    conditions: list[str] = Field(default_factory=list)
    expires_at: datetime | None = None
    dimension_scores: TrustDimensions | None = None


class TrustCalculationConfig(BaseModel):
    """Configuration for trust score calculation."""

    model_config = ConfigDict(frozen=True)

    decay_rate: float = Field(
        default=0.05, ge=0.0, le=1.0, description="Exponential decay rate per day"
    )
    evidence_window_days: int = Field(
        default=90, ge=1, description="How far back to consider evidence"
    )
    dimension_weights: dict[str, float] = Field(
        default_factory=lambda: {
            "reliability": 0.25,
            "competence": 0.20,
            "integrity": 0.25,
            "benevolence": 0.15,
            "transparency": 0.15,
        }
    )
    minimum_evidence_count: int = Field(
        default=3, ge=0, description="Minimum evidence for confident scoring"
    )
    confidence_threshold: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Threshold for confident decisions"
    )
    default_score: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Default trust score for new entities"
    )

    @field_validator("dimension_weights")
    @classmethod
    def validate_dimension_weights(cls, v: dict[str, float]) -> dict[str, float]:
        valid_dims = set(ALL_DIMENSIONS)
        for key in v:
            if key not in valid_dims:
                raise ValueError(f"Invalid dimension: {key}. Valid: {valid_dims}")
        for key, val in v.items():
            if val < 0.0:
                raise ValueError(f"Weight for '{key}' must be non-negative, got {val}")
        return v
