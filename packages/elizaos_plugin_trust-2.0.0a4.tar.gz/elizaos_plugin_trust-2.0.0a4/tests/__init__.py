"""Tests for the elizaOS Trust plugin."""
