"""Pytest configuration and fixtures for Trust plugin tests."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from elizaos_plugin_trust.services import TrustServices
from elizaos_plugin_trust.services.contextual_permission_system import (
    ContextualPermissionSystem,
)
from elizaos_plugin_trust.services.credential_protector import CredentialProtector
from elizaos_plugin_trust.services.llm_evaluator import LLMEvaluator
from elizaos_plugin_trust.services.security_module import SecurityModule
from elizaos_plugin_trust.services.trust_engine import TrustEngine
from elizaos_plugin_trust.types.trust import (
    TrustCalculationConfig,
    TrustEvidence,
    TrustEvidenceType,
)


@pytest.fixture
def trust_config() -> TrustCalculationConfig:
    """Provide a default trust calculation configuration."""
    return TrustCalculationConfig()


@pytest.fixture
def trust_engine(trust_config: TrustCalculationConfig) -> TrustEngine:
    """Provide a fresh TrustEngine instance."""
    return TrustEngine(config=trust_config)


@pytest.fixture
def security_module() -> SecurityModule:
    """Provide a fresh SecurityModule instance."""
    return SecurityModule()


@pytest.fixture
def permission_system() -> ContextualPermissionSystem:
    """Provide a fresh ContextualPermissionSystem instance."""
    return ContextualPermissionSystem()


@pytest.fixture
def credential_protector() -> CredentialProtector:
    """Provide a fresh CredentialProtector instance."""
    return CredentialProtector()


@pytest.fixture
def llm_evaluator() -> LLMEvaluator:
    """Provide a fresh LLMEvaluator instance."""
    return LLMEvaluator()


@pytest.fixture
def trust_services(
    trust_engine: TrustEngine,
    security_module: SecurityModule,
    permission_system: ContextualPermissionSystem,
    credential_protector: CredentialProtector,
    llm_evaluator: LLMEvaluator,
) -> TrustServices:
    """Provide a TrustServices container with all services wired."""
    return TrustServices(
        trust_engine=trust_engine,
        security_module=security_module,
        permission_system=permission_system,
        credential_protector=credential_protector,
        llm_evaluator=llm_evaluator,
    )


@pytest.fixture
def sample_evidence() -> list[TrustEvidence]:
    """Provide a list of sample evidence entries for testing."""
    now = datetime.now(timezone.utc)
    return [
        TrustEvidence(
            entity_id="entity-001",
            evidence_type=TrustEvidenceType.TASK_COMPLETION,
            value=0.9,
            weight=1.0,
            timestamp=now - timedelta(days=1),
            context="Completed task successfully",
            source="test",
        ),
        TrustEvidence(
            entity_id="entity-001",
            evidence_type=TrustEvidenceType.COMMUNICATION_QUALITY,
            value=0.8,
            weight=1.0,
            timestamp=now - timedelta(days=2),
            context="Clear and helpful communication",
            source="test",
        ),
        TrustEvidence(
            entity_id="entity-001",
            evidence_type=TrustEvidenceType.COMMITMENT_FOLLOW_THROUGH,
            value=0.85,
            weight=1.0,
            timestamp=now - timedelta(days=3),
            context="Delivered on promise",
            source="test",
        ),
        TrustEvidence(
            entity_id="entity-001",
            evidence_type=TrustEvidenceType.INTEGRITY,
            value=0.95,
            weight=1.5,
            timestamp=now - timedelta(hours=12),
            context="Honest about limitations",
            source="test",
        ) if False else TrustEvidence(
            entity_id="entity-001",
            evidence_type=TrustEvidenceType.BOUNDARY_RESPECT,
            value=0.95,
            weight=1.5,
            timestamp=now - timedelta(hours=12),
            context="Respected boundaries",
            source="test",
        ),
        TrustEvidence(
            entity_id="entity-001",
            evidence_type=TrustEvidenceType.KNOWLEDGE_SHARING,
            value=0.7,
            weight=0.8,
            timestamp=now - timedelta(days=5),
            context="Shared useful knowledge",
            source="test",
        ),
    ]


@pytest.fixture
def seeded_trust_engine(
    trust_engine: TrustEngine,
    sample_evidence: list[TrustEvidence],
) -> TrustEngine:
    """Provide a TrustEngine pre-loaded with sample evidence."""
    for evidence in sample_evidence:
        trust_engine.record_evidence(evidence)
    return trust_engine
