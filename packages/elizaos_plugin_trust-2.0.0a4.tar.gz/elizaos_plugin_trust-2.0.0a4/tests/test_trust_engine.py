"""Tests for the TrustEngine service."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from elizaos_plugin_trust.services.trust_engine import TrustEngine
from elizaos_plugin_trust.types.trust import (
    TrustCalculationConfig,
    TrustContext,
    TrustDecision,
    TrustDimensions,
    TrustEvidence,
    TrustEvidenceType,
    TrustProfile,
    TrustRequirements,
    TrustTrend,
)


class TestTrustDimensions:
    """Tests for TrustDimensions model."""

    def test_default_values(self) -> None:
        dims = TrustDimensions()
        assert dims.reliability == 0.5
        assert dims.competence == 0.5
        assert dims.integrity == 0.5
        assert dims.benevolence == 0.5
        assert dims.transparency == 0.5

    def test_weighted_average_default_weights(self) -> None:
        dims = TrustDimensions(
            reliability=1.0,
            competence=1.0,
            integrity=1.0,
            benevolence=1.0,
            transparency=1.0,
        )
        assert dims.weighted_average() == pytest.approx(1.0)

    def test_weighted_average_custom_weights(self) -> None:
        dims = TrustDimensions(
            reliability=1.0,
            competence=0.0,
            integrity=0.0,
            benevolence=0.0,
            transparency=0.0,
        )
        weights = {
            "reliability": 1.0,
            "competence": 0.0,
            "integrity": 0.0,
            "benevolence": 0.0,
            "transparency": 0.0,
        }
        assert dims.weighted_average(weights) == pytest.approx(1.0)

    def test_as_dict(self) -> None:
        dims = TrustDimensions(reliability=0.1, competence=0.2)
        d = dims.as_dict()
        assert d["reliability"] == 0.1
        assert d["competence"] == 0.2
        assert len(d) == 5

    def test_distance_to(self) -> None:
        a = TrustDimensions(
            reliability=0.0, competence=0.0, integrity=0.0,
            benevolence=0.0, transparency=0.0,
        )
        b = TrustDimensions(
            reliability=1.0, competence=1.0, integrity=1.0,
            benevolence=1.0, transparency=1.0,
        )
        assert a.distance_to(b) == pytest.approx(5 ** 0.5, rel=1e-3)

    def test_frozen(self) -> None:
        dims = TrustDimensions()
        with pytest.raises(Exception):
            dims.reliability = 0.9  # type: ignore[misc]


class TestTrustEvidence:
    """Tests for TrustEvidence model."""

    def test_creation(self) -> None:
        ev = TrustEvidence(
            entity_id="e1",
            evidence_type=TrustEvidenceType.TASK_COMPLETION,
            value=0.8,
        )
        assert ev.entity_id == "e1"
        assert ev.value == 0.8
        assert ev.weight == 1.0
        assert len(ev.id) == 32

    def test_decayed_weight_recent(self) -> None:
        now = datetime.now(timezone.utc)
        ev = TrustEvidence(
            entity_id="e1",
            evidence_type=TrustEvidenceType.CONSISTENCY,
            value=0.9,
            weight=2.0,
            timestamp=now,
        )
        # No decay at t=0
        assert ev.decayed_weight(0.05, now) == pytest.approx(2.0, rel=1e-3)

    def test_decayed_weight_old(self) -> None:
        now = datetime.now(timezone.utc)
        ev = TrustEvidence(
            entity_id="e1",
            evidence_type=TrustEvidenceType.CONSISTENCY,
            value=0.9,
            weight=2.0,
            timestamp=now - timedelta(days=30),
        )
        decayed = ev.decayed_weight(0.05, now)
        assert decayed < 2.0
        assert decayed > 0.0

    def test_value_validation(self) -> None:
        with pytest.raises(Exception):
            TrustEvidence(
                entity_id="e1",
                evidence_type=TrustEvidenceType.TASK_COMPLETION,
                value=1.5,
            )


class TestTrustEngine:
    """Tests for the TrustEngine service."""

    def test_default_profile_for_unknown_entity(
        self, trust_engine: TrustEngine
    ) -> None:
        profile = trust_engine.calculate_trust("unknown-entity")
        assert profile.entity_id == "unknown-entity"
        assert profile.overall_score == 0.5
        assert profile.confidence == 0.0
        assert profile.evidence_count == 0
        assert profile.trend == TrustTrend.INSUFFICIENT_DATA

    def test_record_and_calculate(
        self, trust_engine: TrustEngine
    ) -> None:
        trust_engine.record_evidence(TrustEvidence(
            entity_id="e1",
            evidence_type=TrustEvidenceType.TASK_COMPLETION,
            value=0.9,
        ))
        trust_engine.record_evidence(TrustEvidence(
            entity_id="e1",
            evidence_type=TrustEvidenceType.COMMUNICATION_QUALITY,
            value=0.8,
        ))

        profile = trust_engine.calculate_trust("e1")
        assert profile.entity_id == "e1"
        assert profile.evidence_count == 2
        assert 0.0 <= profile.overall_score <= 1.0
        assert profile.overall_score > 0.5

    def test_calculate_with_seeded_data(
        self, seeded_trust_engine: TrustEngine
    ) -> None:
        profile = seeded_trust_engine.calculate_trust("entity-001")
        assert profile.evidence_count == 5
        assert profile.overall_score > 0.5
        assert profile.confidence > 0.0
        dims = profile.dimensions
        assert 0.0 <= dims.reliability <= 1.0
        assert 0.0 <= dims.competence <= 1.0

    def test_evaluate_decision_allowed(
        self, seeded_trust_engine: TrustEngine
    ) -> None:
        context = TrustContext(entity_id="entity-001", action="read")
        requirements = TrustRequirements(
            minimum_overall_score=0.3,
            minimum_evidence_count=2,
            minimum_confidence=0.1,
        )
        decision = seeded_trust_engine.evaluate_decision(context, requirements)
        assert decision.allowed is True
        assert "met" in decision.reasoning.lower()

    def test_evaluate_decision_denied(
        self, seeded_trust_engine: TrustEngine
    ) -> None:
        context = TrustContext(entity_id="entity-001", action="admin")
        requirements = TrustRequirements(
            minimum_overall_score=0.99,
            minimum_evidence_count=100,
        )
        decision = seeded_trust_engine.evaluate_decision(context, requirements)
        assert decision.allowed is False
        assert "not met" in decision.reasoning.lower()

    def test_get_trust_trend(
        self, seeded_trust_engine: TrustEngine
    ) -> None:
        scores = seeded_trust_engine.get_trust_trend("entity-001", window_days=10)
        assert isinstance(scores, list)
        for score in scores:
            assert 0.0 <= score <= 1.0

    def test_clear_evidence(self, seeded_trust_engine: TrustEngine) -> None:
        count = seeded_trust_engine.clear_evidence("entity-001")
        assert count == 5
        profile = seeded_trust_engine.calculate_trust("entity-001")
        assert profile.evidence_count == 0

    def test_context_risk_adjustment(
        self, seeded_trust_engine: TrustEngine
    ) -> None:
        low_risk = TrustContext(
            entity_id="entity-001", risk_level=0.1, urgency=0.1
        )
        high_risk = TrustContext(
            entity_id="entity-001", risk_level=0.9, urgency=0.1
        )
        low_profile = seeded_trust_engine.calculate_trust("entity-001", low_risk)
        high_profile = seeded_trust_engine.calculate_trust("entity-001", high_risk)
        assert low_profile.overall_score >= high_profile.overall_score

    def test_config_validation(self) -> None:
        with pytest.raises(Exception):
            TrustCalculationConfig(
                dimension_weights={"invalid_dimension": 1.0}
            )

    def test_get_all_entity_ids(
        self, seeded_trust_engine: TrustEngine
    ) -> None:
        ids = seeded_trust_engine.get_all_entity_ids()
        assert "entity-001" in ids
