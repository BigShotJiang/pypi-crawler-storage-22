# elizaos-plugin-tts

elizaOS TTS Plugin - text-to-speech coordinator with multi-provider support

## Installation

```bash
pip install elizaos-plugin-tts
```

## Part of elizaOS

This is a Python plugin for the [elizaOS](https://github.com/elizaos/eliza) AI agent framework.

## License

MIT
