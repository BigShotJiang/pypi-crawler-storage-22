"""TTS coordinator - multi-provider synthesis orchestration.

Provides a unified interface for:
- Checking provider availability based on API keys
- Auto-selecting the best available provider
- Synthesizing text to speech
- Conditionally applying TTS to replies
"""

from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable

from elizaos_plugin_tts.config_manager import get_tts_config, should_apply_tts
from elizaos_plugin_tts.directive_parser import get_tts_text, parse_tts_directive
from elizaos_plugin_tts.error import TtsRuntimeUnsupportedError, TtsSynthesisError
from elizaos_plugin_tts.text_processor import process_text_for_tts
from elizaos_plugin_tts.types import (
    TTS_PROVIDER_API_KEYS,
    TTS_PROVIDER_PRIORITY,
    TtsConfig,
    TtsProvider,
    TtsRequest,
    TtsResult,
)

logger = logging.getLogger("plugin-tts")


@runtime_checkable
class TtsRuntime(Protocol):
    """Minimal runtime interface consumed by TTS operations."""

    def get_setting(self, key: str) -> str | None: ...
    async def use_model(self, model_type: str, params: dict[str, object]) -> object: ...


def is_provider_available(runtime: TtsRuntime, provider: TtsProvider) -> bool:
    """Check if a provider is available (has required API keys)."""
    if provider == TtsProvider.AUTO:
        return True

    required_keys = TTS_PROVIDER_API_KEYS[provider]
    if not required_keys:
        return True

    get_setting = getattr(runtime, "get_setting", None)
    if get_setting is None:
        return False

    return any(
        (value := get_setting(key)) and str(value).strip() != ""
        for key in required_keys
    )


def get_best_provider(
    runtime: TtsRuntime,
    preferred: TtsProvider | None = None,
) -> TtsProvider:
    """Get the best available provider."""
    if (
        preferred is not None
        and preferred != TtsProvider.AUTO
        and is_provider_available(runtime, preferred)
    ):
        return preferred

    for provider in TTS_PROVIDER_PRIORITY:
        if is_provider_available(runtime, provider):
            return provider

    return TtsProvider.SIMPLE_VOICE


async def synthesize(runtime: TtsRuntime, request: TtsRequest) -> TtsResult:
    """Synthesize text to speech."""
    provider = get_best_provider(runtime, request.provider)

    logger.debug("[TTS] Synthesizing with provider: %s", provider.value)

    params = {
        "text": request.text,
        "voice": request.voice,
        "model": request.model,
        "speed": request.speed,
        "provider": provider.value,
    }

    try:
        use_model = getattr(runtime, "use_model", None)
        if use_model is None:
            raise TtsRuntimeUnsupportedError()

        audio = await use_model("TEXT_TO_SPEECH", params)
        audio_bytes = audio if isinstance(audio, bytes) else bytes(audio)

        return TtsResult(
            audio=audio_bytes,
            format=request.format or "mp3",
            provider=provider,
        )
    except TtsRuntimeUnsupportedError:
        raise
    except Exception as exc:
        logger.error("[TTS] Synthesis failed with %s: %s", provider.value, exc)
        raise TtsSynthesisError(provider.value, str(exc)) from exc


async def maybe_apply_tts(
    runtime: TtsRuntime,
    room_id: str,
    text: str,
    *,
    inbound_audio: bool = False,
    kind: str | None = None,
) -> bytes | None:
    """Apply TTS to a reply text if configured.

    Returns the audio bytes if TTS was applied, or None otherwise.
    """
    config = get_tts_config(room_id)
    directive = parse_tts_directive(text)
    has_directive = directive is not None

    if not should_apply_tts(config, inbound_audio=inbound_audio, has_directive=has_directive):
        return None

    tts_text = get_tts_text(text, directive)

    processed = await process_text_for_tts(
        runtime,
        tts_text,
        max_length=config.max_length,
        summarize=config.summarize,
    )

    if not processed:
        logger.debug("[TTS] Text too short or invalid for TTS")
        return None

    try:
        result = await synthesize(
            runtime,
            TtsRequest(
                text=processed,
                provider=directive.provider if directive else config.provider,
                voice=(directive.voice if directive else None) or config.voice,
                model=(directive.model if directive else None) or config.model,
                speed=directive.speed if directive else config.speed,
            ),
        )
        return result.audio
    except Exception:
        logger.exception("[TTS] Failed to apply TTS")
        return None


def format_tts_config(config: TtsConfig) -> str:
    """Format TTS configuration for display."""
    lines = [
        f"Auto: {config.auto.value}",
        f"Provider: {config.provider.value}",
        f"Max length: {config.max_length}",
        f"Summarize: {'yes' if config.summarize else 'no'}",
    ]
    if config.voice:
        lines.append(f"Voice: {config.voice}")
    return "\n".join(lines)
