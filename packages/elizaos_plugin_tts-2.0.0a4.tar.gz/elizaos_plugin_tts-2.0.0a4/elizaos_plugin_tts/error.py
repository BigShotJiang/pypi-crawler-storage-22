"""Error types for the TTS plugin."""

from __future__ import annotations


class TtsError(Exception):
    """Base error for TTS operations."""


class TtsSynthesisError(TtsError):
    """The text-to-speech synthesis failed."""

    def __init__(self, provider: str, message: str) -> None:
        self.provider = provider
        super().__init__(f"TTS synthesis failed with {provider}: {message}")


class TtsNoProviderError(TtsError):
    """No TTS provider is available."""

    def __init__(self) -> None:
        super().__init__("No TTS provider available")


class TtsRuntimeUnsupportedError(TtsError):
    """The runtime does not support the required model."""

    def __init__(self) -> None:
        super().__init__("Runtime does not support use_model")


class TtsTextTooShortError(TtsError):
    """The text is too short for TTS."""

    def __init__(self, length: int, minimum: int) -> None:
        self.length = length
        self.minimum = minimum
        super().__init__(f"Text too short for TTS (length {length}, minimum {minimum})")


class TtsConfigError(TtsError):
    """Configuration error."""

    def __init__(self, message: str) -> None:
        super().__init__(f"Configuration error: {message}")
