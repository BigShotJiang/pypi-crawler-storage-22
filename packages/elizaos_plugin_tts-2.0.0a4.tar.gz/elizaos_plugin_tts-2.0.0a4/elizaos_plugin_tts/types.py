"""TTS system types."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal


class TtsProvider(str, Enum):
    """Supported TTS providers."""

    ELEVENLABS = "elevenlabs"
    OPENAI = "openai"
    EDGE = "edge"
    SIMPLE_VOICE = "simple-voice"
    AUTO = "auto"


class TtsAutoMode(str, Enum):
    """When to automatically apply TTS."""

    OFF = "off"
    ALWAYS = "always"
    INBOUND = "inbound"
    TAGGED = "tagged"


TtsApplyKind = Literal["tool", "block", "final"]

TtsAudioFormat = Literal["mp3", "opus", "wav"]


@dataclass(slots=True)
class TtsConfig:
    """Full TTS configuration (defaults + session overrides merged)."""

    provider: TtsProvider = TtsProvider.AUTO
    auto: TtsAutoMode = TtsAutoMode.OFF
    max_length: int = 1500
    summarize: bool = True
    voice: str | None = None
    model: str | None = None
    speed: float | None = None


@dataclass(slots=True)
class TtsDirective:
    """Parsed [[tts]] directive options."""

    provider: TtsProvider | None = None
    voice: str | None = None
    model: str | None = None
    speed: float | None = None
    text: str | None = None


@dataclass(slots=True)
class TtsRequest:
    """Request for TTS synthesis."""

    text: str
    provider: TtsProvider | None = None
    voice: str | None = None
    model: str | None = None
    speed: float | None = None
    format: TtsAudioFormat = "mp3"


@dataclass(frozen=True, slots=True)
class TtsResult:
    """Result of TTS synthesis."""

    audio: bytes
    format: str
    provider: TtsProvider
    duration: float | None = None


@dataclass(slots=True)
class TtsSessionConfig:
    """Per-session TTS overrides (all optional)."""

    auto: TtsAutoMode | None = None
    provider: TtsProvider | None = None
    voice: str | None = None
    max_length: int | None = None
    summarize: bool | None = None


DEFAULT_TTS_CONFIG = TtsConfig()

# Provider priority for auto-selection
TTS_PROVIDER_PRIORITY: list[TtsProvider] = [
    TtsProvider.ELEVENLABS,
    TtsProvider.OPENAI,
    TtsProvider.EDGE,
    TtsProvider.SIMPLE_VOICE,
]

# API key environment variable names for each provider
TTS_PROVIDER_API_KEYS: dict[TtsProvider, list[str]] = {
    TtsProvider.ELEVENLABS: ["ELEVENLABS_API_KEY", "XI_API_KEY"],
    TtsProvider.OPENAI: ["OPENAI_API_KEY"],
    TtsProvider.EDGE: [],
    TtsProvider.SIMPLE_VOICE: [],
    TtsProvider.AUTO: [],
}
