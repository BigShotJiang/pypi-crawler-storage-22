"""Tests for TTS directive parsing — mirrors TypeScript test coverage."""

from __future__ import annotations

import pytest

from elizaos_plugin_tts.directive_parser import (
    get_tts_text,
    has_tts_directive,
    normalize_provider,
    parse_json_voice_directive,
    parse_tts_directive,
    strip_tts_directives,
)
from elizaos_plugin_tts.types import TtsDirective, TtsProvider


# =========================================================================
# hasTtsDirective
# =========================================================================


class TestHasTtsDirective:
    def test_detects_tts_directive(self) -> None:
        assert has_tts_directive("Hello [[tts]] world") is True

    def test_detects_tts_with_options(self) -> None:
        assert has_tts_directive("[[tts:provider=elevenlabs]] Hello") is True

    def test_detects_tts_text_blocks(self) -> None:
        assert has_tts_directive("[[tts:text]]Hello[[/tts:text]]") is True

    def test_returns_false_for_plain_text(self) -> None:
        assert has_tts_directive("No directive here") is False

    def test_returns_false_for_similar_but_invalid_patterns(self) -> None:
        assert has_tts_directive("[[not-tts]]") is False
        assert has_tts_directive("[tts]") is False

    def test_detects_case_insensitive(self) -> None:
        assert has_tts_directive("[[TTS]] Hello") is True
        assert has_tts_directive("[[Tts:provider=openai]] Hello") is True


# =========================================================================
# parseTtsDirective
# =========================================================================


class TestParseTtsDirective:
    def test_returns_none_for_text_without_directives(self) -> None:
        assert parse_tts_directive("Plain text") is None

    def test_parses_simple_tts_directive(self) -> None:
        directive = parse_tts_directive("[[tts]] Hello")
        assert directive is not None

    def test_parses_provider_option(self) -> None:
        directive = parse_tts_directive("[[tts:provider=elevenlabs]]")
        assert directive is not None
        assert directive.provider == TtsProvider.ELEVENLABS

    def test_parses_voice_option(self) -> None:
        directive = parse_tts_directive("[[tts:voice=alloy]]")
        assert directive is not None
        assert directive.voice == "alloy"

    def test_parses_speed_option(self) -> None:
        directive = parse_tts_directive("[[tts:speed=1.5]]")
        assert directive is not None
        assert directive.speed == 1.5

    def test_parses_multiple_options(self) -> None:
        directive = parse_tts_directive(
            "[[tts:provider=openai voice=nova speed=1.2]]"
        )
        assert directive is not None
        assert directive.provider == TtsProvider.OPENAI
        assert directive.voice == "nova"
        assert directive.speed == 1.2

    def test_parses_text_block(self) -> None:
        directive = parse_tts_directive(
            "Before [[tts:text]]Custom TTS text[[/tts:text]] after"
        )
        assert directive is not None
        assert directive.text == "Custom TTS text"

    def test_normalizes_provider_names(self) -> None:
        assert (
            parse_tts_directive("[[tts:provider=eleven]]")
        ).provider == TtsProvider.ELEVENLABS  # type: ignore[union-attr]
        assert (
            parse_tts_directive("[[tts:provider=oai]]")
        ).provider == TtsProvider.OPENAI  # type: ignore[union-attr]
        assert (
            parse_tts_directive("[[tts:provider=microsoft]]")
        ).provider == TtsProvider.EDGE  # type: ignore[union-attr]
        assert (
            parse_tts_directive("[[tts:provider=sam]]")
        ).provider == TtsProvider.SIMPLE_VOICE  # type: ignore[union-attr]

    def test_parses_model_option(self) -> None:
        directive = parse_tts_directive("[[tts:model=tts-1-hd]]")
        assert directive is not None
        assert directive.model == "tts-1-hd"


# =========================================================================
# stripTtsDirectives
# =========================================================================


class TestStripTtsDirectives:
    def test_strips_tts_directive(self) -> None:
        assert strip_tts_directives("Hello [[tts]] world") == "Hello world"

    def test_strips_tts_with_options(self) -> None:
        assert strip_tts_directives("[[tts:provider=elevenlabs]] Hello") == "Hello"

    def test_strips_tts_text_blocks(self) -> None:
        assert (
            strip_tts_directives(
                "Before [[tts:text]]TTS text[[/tts:text]] after"
            )
            == "Before after"
        )

    def test_strips_multiple_directives(self) -> None:
        assert (
            strip_tts_directives("[[tts]] Hello [[tts:voice=alloy]] world")
            == "Hello world"
        )


# =========================================================================
# getTtsText
# =========================================================================


class TestGetTtsText:
    def test_returns_directive_text_if_present(self) -> None:
        text = "Message [[tts:text]]Custom[[/tts:text]]"
        directive = parse_tts_directive(text)
        assert get_tts_text(text, directive) == "Custom"

    def test_returns_cleaned_text_if_no_directive_text(self) -> None:
        text = "[[tts]] Message"
        directive = parse_tts_directive(text)
        assert get_tts_text(text, directive) == "Message"

    def test_returns_original_text_if_no_directive(self) -> None:
        assert get_tts_text("Plain message", None) == "Plain message"


# =========================================================================
# parseJsonVoiceDirective
# =========================================================================


class TestParseJsonVoiceDirective:
    def test_returns_none_for_single_line(self) -> None:
        assert parse_json_voice_directive("No newline") is None

    def test_returns_none_for_non_json_first_line(self) -> None:
        assert parse_json_voice_directive("Not JSON\nSecond line") is None

    def test_returns_none_for_json_without_voice_keys(self) -> None:
        assert parse_json_voice_directive('{"unrelated": true}\nText') is None

    def test_parses_voice_directive(self) -> None:
        result = parse_json_voice_directive('{"voice": "abc123"}\nHello world')
        assert result is not None
        assert result.directive.voice == "abc123"
        assert result.cleaned_text == "Hello world"

    def test_parses_model_directive(self) -> None:
        result = parse_json_voice_directive('{"model": "tts-1"}\nHello')
        assert result is not None
        assert result.directive.model == "tts-1"

    def test_parses_speed_directive(self) -> None:
        result = parse_json_voice_directive('{"speed": 1.5}\nHello')
        assert result is not None
        assert result.directive.speed == 1.5

    def test_parses_rate_as_speed(self) -> None:
        result = parse_json_voice_directive('{"rate": 0.8}\nHello')
        assert result is not None
        assert result.directive.speed == 0.8


# =========================================================================
# DEEP TESTS — Malformed directives
# =========================================================================


class TestMalformedDirectives:
    def test_parse_directive_empty_params(self) -> None:
        """[[tts:]] — colon with no content does not match the directive regex."""
        assert parse_tts_directive("[[tts:]]") is None

    def test_parse_directive_key_no_value(self) -> None:
        """[[tts:provider=]] — key present but value empty; no kv pair parsed."""
        directive = parse_tts_directive("[[tts:provider=]]")
        assert directive is not None
        assert directive.provider is None
        assert directive.voice is None
        assert directive.model is None
        assert directive.speed is None
        assert directive.text is None

    def test_parse_directive_no_key(self) -> None:
        """[[tts:=elevenlabs]] — equals sign with no preceding key."""
        directive = parse_tts_directive("[[tts:=elevenlabs]]")
        assert directive is not None
        assert directive.provider is None
        assert directive.voice is None

    def test_parse_directive_unclosed_brackets(self) -> None:
        """[[tts:provider=openai — missing closing brackets."""
        assert parse_tts_directive("[[tts:provider=openai") is None

    def test_parse_directive_unclosed_text_block(self) -> None:
        """[[tts:text]]hello without end tag — text block not captured."""
        directive = parse_tts_directive("[[tts:text]]hello without end tag")
        assert directive is not None
        # No closing [[/tts:text]], so text is not captured
        assert directive.text is None
        # "text" inside params has no key=value, so no fields set
        assert directive.provider is None
        assert directive.voice is None

    def test_parse_directive_closing_without_opening(self) -> None:
        """[[/tts:text]] alone — closing tag with no opening is not a directive."""
        assert parse_tts_directive("[[/tts:text]]") is None


# =========================================================================
# DEEP TESTS — Unicode and special characters
# =========================================================================


class TestUnicodeAndSpecialChars:
    def test_parse_directive_unicode_text(self) -> None:
        directive = parse_tts_directive(
            "[[tts:text]]こんにちは世界[[/tts:text]]"
        )
        assert directive is not None
        assert directive.text == "こんにちは世界"

    def test_parse_directive_unicode_voice(self) -> None:
        directive = parse_tts_directive("[[tts:voice=日本語]]")
        assert directive is not None
        assert directive.voice == "日本語"

    def test_parse_directive_emoji_text(self) -> None:
        directive = parse_tts_directive(
            "[[tts:text]]Hello 🌍[[/tts:text]]"
        )
        assert directive is not None
        assert directive.text == "Hello 🌍"


# =========================================================================
# DEEP TESTS — Boundary conditions
# =========================================================================


class TestBoundaryConditions:
    def test_parse_directive_only_directive(self) -> None:
        """Directive alone with no surrounding text."""
        directive = parse_tts_directive("[[tts:provider=openai]]")
        assert directive is not None
        assert directive.provider == TtsProvider.OPENAI
        assert directive.text is None

    def test_parse_directive_at_start(self) -> None:
        directive = parse_tts_directive("[[tts]] rest of message")
        assert directive is not None
        assert directive.provider is None
        assert strip_tts_directives("[[tts]] rest of message") == "rest of message"

    def test_parse_directive_at_end(self) -> None:
        directive = parse_tts_directive("message [[tts]]")
        assert directive is not None
        assert directive.provider is None
        assert strip_tts_directives("message [[tts]]") == "message"

    def test_parse_multiple_text_blocks(self) -> None:
        """Only the first [[tts:text]] block is captured."""
        text = "[[tts:text]]first[[/tts:text]] middle [[tts:text]]second[[/tts:text]]"
        directive = parse_tts_directive(text)
        assert directive is not None
        assert directive.text == "first"

    def test_parse_speed_zero(self) -> None:
        directive = parse_tts_directive("[[tts:speed=0]]")
        assert directive is not None
        assert directive.speed == 0.0

    def test_parse_speed_negative(self) -> None:
        directive = parse_tts_directive("[[tts:speed=-1.5]]")
        assert directive is not None
        assert directive.speed == -1.5

    def test_parse_speed_invalid(self) -> None:
        """Non-numeric speed is silently ignored; speed stays None."""
        directive = parse_tts_directive("[[tts:speed=abc]]")
        assert directive is not None
        assert directive.speed is None

    def test_strip_multiple_directives_normalizes_whitespace(self) -> None:
        text = "Hello  [[tts]]  [[tts:voice=alloy]]  world"
        assert strip_tts_directives(text) == "Hello world"


# =========================================================================
# DEEP TESTS — JSON voice directive edge cases
# =========================================================================


class TestJsonVoiceDirectiveDeep:
    def test_json_voice_directive_voice_id_key(self) -> None:
        result = parse_json_voice_directive('{"voice_id": "v-abc"}\nHello')
        assert result is not None
        assert result.directive.voice == "v-abc"
        assert result.cleaned_text == "Hello"

    def test_json_voice_directive_voiceId_camel_key(self) -> None:
        result = parse_json_voice_directive('{"voiceId": "v-camel"}\nHello')
        assert result is not None
        assert result.directive.voice == "v-camel"
        assert result.cleaned_text == "Hello"

    def test_json_voice_directive_model_id_key(self) -> None:
        result = parse_json_voice_directive('{"model_id": "tts-1-hd"}\nHello')
        assert result is not None
        assert result.directive.model == "tts-1-hd"
        assert result.cleaned_text == "Hello"

    def test_json_voice_directive_modelId_camel_key(self) -> None:
        result = parse_json_voice_directive('{"modelId": "tts-1-hd"}\nHello')
        assert result is not None
        assert result.directive.model == "tts-1-hd"
        assert result.cleaned_text == "Hello"

    def test_json_voice_directive_speed_and_rate_priority(self) -> None:
        """When both speed and rate are present, speed takes priority."""
        result = parse_json_voice_directive('{"speed": 2.0, "rate": 0.5}\nText')
        assert result is not None
        assert result.directive.speed == 2.0

    def test_json_voice_directive_malformed_json(self) -> None:
        assert parse_json_voice_directive("{not valid json}\nText") is None

    def test_json_voice_directive_non_string_voice(self) -> None:
        """Non-string voice value (e.g. integer) is ignored."""
        result = parse_json_voice_directive('{"voice": 123}\nHello world')
        assert result is not None
        assert result.directive.voice is None
        assert result.cleaned_text == "Hello world"


# =========================================================================
# DEEP TESTS — normalize_provider
# =========================================================================


class TestNormalizeProvider:
    def test_normalize_provider_known_values(self) -> None:
        assert normalize_provider("openai") == TtsProvider.OPENAI
        assert normalize_provider("elevenlabs") == TtsProvider.ELEVENLABS
        assert normalize_provider("edge") == TtsProvider.EDGE
        assert normalize_provider("simple") == TtsProvider.SIMPLE_VOICE

    def test_normalize_provider_unknown_returns_none(self) -> None:
        assert normalize_provider("foobar") is None
        assert normalize_provider("unknown") is None
        assert normalize_provider("") is None

    def test_normalize_provider_whitespace_padded(self) -> None:
        assert normalize_provider("  openai  ") == TtsProvider.OPENAI
        assert normalize_provider(" elevenlabs ") == TtsProvider.ELEVENLABS

    def test_normalize_provider_case_insensitive(self) -> None:
        assert normalize_provider("OPENAI") == TtsProvider.OPENAI
        assert normalize_provider("ElevenLabs") == TtsProvider.ELEVENLABS
        assert normalize_provider("EDGE") == TtsProvider.EDGE
        assert normalize_provider("Simple-Voice") == TtsProvider.SIMPLE_VOICE


# =========================================================================
# DEEP TESTS — get_tts_text edge cases
# =========================================================================


class TestGetTtsTextDeep:
    def test_get_tts_text_empty_directive_text(self) -> None:
        """Empty string is falsy in Python; falls through to strip."""
        directive = TtsDirective()
        directive.text = ""
        result = get_tts_text("[[tts]] Hello world", directive)
        assert result == "Hello world"

    def test_get_tts_text_whitespace_only(self) -> None:
        """Whitespace-only string is truthy; returned as-is."""
        directive = TtsDirective()
        directive.text = "   "
        result = get_tts_text("[[tts]] Hello world", directive)
        assert result == "   "
