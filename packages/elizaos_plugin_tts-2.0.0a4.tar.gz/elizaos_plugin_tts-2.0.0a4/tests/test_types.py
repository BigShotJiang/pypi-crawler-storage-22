"""Tests for TTS types — enum values, dataclass defaults, and type correctness."""

from __future__ import annotations

import pytest
from dataclasses import asdict

from elizaos_plugin_tts.types import (
    DEFAULT_TTS_CONFIG,
    TTS_PROVIDER_API_KEYS,
    TTS_PROVIDER_PRIORITY,
    TtsApplyKind,
    TtsAutoMode,
    TtsConfig,
    TtsDirective,
    TtsProvider,
    TtsRequest,
    TtsResult,
    TtsSessionConfig,
)


# =========================================================================
# TtsProvider enum
# =========================================================================


class TestTtsProvider:
    def test_has_all_providers(self) -> None:
        assert TtsProvider.ELEVENLABS.value == "elevenlabs"
        assert TtsProvider.OPENAI.value == "openai"
        assert TtsProvider.EDGE.value == "edge"
        assert TtsProvider.SIMPLE_VOICE.value == "simple-voice"
        assert TtsProvider.AUTO.value == "auto"

    def test_provider_count(self) -> None:
        assert len(TtsProvider) == 5

    def test_provider_is_string_enum(self) -> None:
        # TtsProvider inherits from str so values can be used as strings
        assert isinstance(TtsProvider.ELEVENLABS, str)
        assert TtsProvider.ELEVENLABS == "elevenlabs"


# =========================================================================
# TtsAutoMode enum
# =========================================================================


class TestTtsAutoMode:
    def test_has_all_modes(self) -> None:
        assert TtsAutoMode.OFF.value == "off"
        assert TtsAutoMode.ALWAYS.value == "always"
        assert TtsAutoMode.INBOUND.value == "inbound"
        assert TtsAutoMode.TAGGED.value == "tagged"

    def test_mode_count(self) -> None:
        assert len(TtsAutoMode) == 4

    def test_mode_is_string_enum(self) -> None:
        assert isinstance(TtsAutoMode.OFF, str)
        assert TtsAutoMode.OFF == "off"


# =========================================================================
# TtsConfig
# =========================================================================


class TestTtsConfig:
    def test_default_values(self) -> None:
        config = TtsConfig()
        assert config.provider == TtsProvider.AUTO
        assert config.auto == TtsAutoMode.OFF
        assert config.max_length == 1500
        assert config.summarize is True
        assert config.voice is None
        assert config.model is None
        assert config.speed is None

    def test_custom_values(self) -> None:
        config = TtsConfig(
            provider=TtsProvider.OPENAI,
            auto=TtsAutoMode.ALWAYS,
            max_length=2000,
            summarize=False,
            voice="nova",
            model="tts-1-hd",
            speed=1.5,
        )
        assert config.provider == TtsProvider.OPENAI
        assert config.auto == TtsAutoMode.ALWAYS
        assert config.max_length == 2000
        assert config.summarize is False
        assert config.voice == "nova"
        assert config.model == "tts-1-hd"
        assert config.speed == 1.5

    def test_serializable_via_asdict(self) -> None:
        config = TtsConfig()
        d = asdict(config)
        assert "provider" in d
        assert "auto" in d
        assert "max_length" in d


# =========================================================================
# TtsDirective
# =========================================================================


class TestTtsDirective:
    def test_default_values(self) -> None:
        directive = TtsDirective()
        assert directive.provider is None
        assert directive.voice is None
        assert directive.model is None
        assert directive.speed is None
        assert directive.text is None

    def test_with_values(self) -> None:
        directive = TtsDirective(
            provider=TtsProvider.ELEVENLABS,
            voice="alloy",
            speed=1.2,
            text="Hello world",
        )
        assert directive.provider == TtsProvider.ELEVENLABS
        assert directive.voice == "alloy"
        assert directive.speed == 1.2
        assert directive.text == "Hello world"


# =========================================================================
# TtsSessionConfig
# =========================================================================


class TestTtsSessionConfig:
    def test_all_optional(self) -> None:
        config = TtsSessionConfig()
        assert config.auto is None
        assert config.provider is None
        assert config.voice is None
        assert config.max_length is None
        assert config.summarize is None

    def test_partial_values(self) -> None:
        config = TtsSessionConfig(auto=TtsAutoMode.ALWAYS, provider=TtsProvider.EDGE)
        assert config.auto == TtsAutoMode.ALWAYS
        assert config.provider == TtsProvider.EDGE
        assert config.voice is None


# =========================================================================
# DEFAULT_TTS_CONFIG
# =========================================================================


class TestDefaultTtsConfig:
    def test_default_config_matches_typescript(self) -> None:
        """Verify defaults match the TypeScript DEFAULT_TTS_CONFIG."""
        assert DEFAULT_TTS_CONFIG.provider == TtsProvider.AUTO
        assert DEFAULT_TTS_CONFIG.auto == TtsAutoMode.OFF
        assert DEFAULT_TTS_CONFIG.max_length == 1500
        assert DEFAULT_TTS_CONFIG.summarize is True


# =========================================================================
# TTS_PROVIDER_PRIORITY
# =========================================================================


class TestProviderPriority:
    def test_priority_order(self) -> None:
        assert TTS_PROVIDER_PRIORITY == [
            TtsProvider.ELEVENLABS,
            TtsProvider.OPENAI,
            TtsProvider.EDGE,
            TtsProvider.SIMPLE_VOICE,
        ]


# =========================================================================
# TTS_PROVIDER_API_KEYS
# =========================================================================


class TestProviderApiKeys:
    def test_elevenlabs_keys(self) -> None:
        keys = TTS_PROVIDER_API_KEYS[TtsProvider.ELEVENLABS]
        assert "ELEVENLABS_API_KEY" in keys
        assert "XI_API_KEY" in keys

    def test_openai_keys(self) -> None:
        keys = TTS_PROVIDER_API_KEYS[TtsProvider.OPENAI]
        assert "OPENAI_API_KEY" in keys

    def test_edge_no_keys(self) -> None:
        assert TTS_PROVIDER_API_KEYS[TtsProvider.EDGE] == []

    def test_simple_voice_no_keys(self) -> None:
        assert TTS_PROVIDER_API_KEYS[TtsProvider.SIMPLE_VOICE] == []

    def test_auto_no_keys(self) -> None:
        assert TTS_PROVIDER_API_KEYS[TtsProvider.AUTO] == []


# =========================================================================
# shouldApplyTts — all 4 modes (tested via config_manager but verified
# at the type level here to ensure TtsConfig works with the function)
# =========================================================================


class TestShouldApplyTtsWithTypes:
    """Verify that TtsConfig with each TtsAutoMode value is accepted by
    should_apply_tts and produces the correct boolean."""

    def test_off_mode(self) -> None:
        from elizaos_plugin_tts.config_manager import should_apply_tts
        config = TtsConfig(auto=TtsAutoMode.OFF)
        assert should_apply_tts(config) is False

    def test_always_mode(self) -> None:
        from elizaos_plugin_tts.config_manager import should_apply_tts
        config = TtsConfig(auto=TtsAutoMode.ALWAYS)
        assert should_apply_tts(config) is True

    def test_inbound_mode_without_audio(self) -> None:
        from elizaos_plugin_tts.config_manager import should_apply_tts
        config = TtsConfig(auto=TtsAutoMode.INBOUND)
        assert should_apply_tts(config) is False
        assert should_apply_tts(config, inbound_audio=True) is True

    def test_tagged_mode_without_directive(self) -> None:
        from elizaos_plugin_tts.config_manager import should_apply_tts
        config = TtsConfig(auto=TtsAutoMode.TAGGED)
        assert should_apply_tts(config) is False
        assert should_apply_tts(config, has_directive=True) is True
