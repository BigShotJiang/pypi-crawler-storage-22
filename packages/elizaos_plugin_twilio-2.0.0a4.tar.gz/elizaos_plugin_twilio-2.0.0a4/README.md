# elizaos-plugin-twilio

Twilio plugin for elizaOS - Python implementation for SMS, MMS, and voice calls

## Installation

```bash
pip install elizaos-plugin-twilio
```

## Part of elizaOS

This is a Python plugin for the [elizaOS](https://github.com/elizaos/eliza) AI agent framework.

## License

MIT
