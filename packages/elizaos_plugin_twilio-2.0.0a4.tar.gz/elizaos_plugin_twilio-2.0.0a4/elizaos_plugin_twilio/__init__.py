"""elizaos-plugin-twilio: Twilio plugin for elizaOS."""

__version__ = "2.0.0"

from elizaos_plugin_twilio.actions import (
    MakeCallAction,
    SendMmsAction,
    SendSmsAction,
    make_call_action,
    send_mms_action,
    send_sms_action,
)
from elizaos_plugin_twilio.call_manager import CallManager, CallManagerSettings
from elizaos_plugin_twilio.config import TWILIO_SERVICE_NAME
from elizaos_plugin_twilio.error import (
    TwilioApiError,
    TwilioCallError,
    TwilioConfigError,
    TwilioError,
    TwilioValidationError,
)
from elizaos_plugin_twilio.plugin import TwilioPlugin, twilio_plugin
from elizaos_plugin_twilio.providers import (
    CallStateProvider,
    ConversationHistoryProvider,
    call_state_provider,
    conversation_history_provider,
)
from elizaos_plugin_twilio.service import TwilioService
from elizaos_plugin_twilio.types import (
    CallDirection,
    CallMode,
    CallRecord,
    CallState,
    NormalizedEvent,
    TranscriptEntry,
    TwilioCall,
    TwilioConfig,
    TwilioEventType,
    TwilioMedia,
    TwilioMessage,
)
from elizaos_plugin_twilio.utils import (
    chunk_text_for_sms,
    extract_phone_number,
    format_phone_number,
    generate_twiml,
    get_webhook_url,
    parse_media_from_webhook,
    validate_messaging_address,
    validate_phone_number,
)

__all__ = [
    "__version__",
    # Plugin
    "TwilioPlugin",
    "twilio_plugin",
    # Service
    "TwilioService",
    "TWILIO_SERVICE_NAME",
    # Call Manager
    "CallManager",
    "CallManagerSettings",
    # Actions
    "SendSmsAction",
    "send_sms_action",
    "MakeCallAction",
    "make_call_action",
    "SendMmsAction",
    "send_mms_action",
    # Providers
    "CallStateProvider",
    "call_state_provider",
    "ConversationHistoryProvider",
    "conversation_history_provider",
    # Types
    "TwilioConfig",
    "TwilioMessage",
    "TwilioMedia",
    "TwilioCall",
    "TwilioEventType",
    "CallState",
    "CallDirection",
    "CallMode",
    "CallRecord",
    "TranscriptEntry",
    "NormalizedEvent",
    # Errors
    "TwilioError",
    "TwilioConfigError",
    "TwilioValidationError",
    "TwilioApiError",
    "TwilioCallError",
    # Utils
    "validate_phone_number",
    "validate_messaging_address",
    "format_phone_number",
    "extract_phone_number",
    "chunk_text_for_sms",
    "generate_twiml",
    "parse_media_from_webhook",
    "get_webhook_url",
]
