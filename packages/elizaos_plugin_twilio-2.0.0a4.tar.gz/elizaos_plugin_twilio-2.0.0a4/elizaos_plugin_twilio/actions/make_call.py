"""MAKE_CALL action - Make a phone call via Twilio."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

from elizaos_plugin_twilio.config import TWILIO_SERVICE_NAME
from elizaos_plugin_twilio.utils import (
    extract_phone_number,
    generate_twiml,
    validate_phone_number,
)

logger = logging.getLogger(__name__)


@dataclass
class MakeCallAction:
    """Action to make a phone call via Twilio with a message or custom TwiML."""

    name: str = "MAKE_CALL"
    description: str = "Make a phone call via Twilio with a message or custom TwiML"
    similes: list[str] = field(
        default_factory=lambda: [
            "make call",
            "phone call",
            "call phone",
            "dial number",
            "voice call",
            "ring phone",
        ]
    )
    examples: list[list[dict[str, object]]] = field(
        default_factory=lambda: [
            [
                {
                    "name": "user",
                    "content": {
                        "text": "Call +18885551234 and say 'This is an important reminder about your appointment tomorrow at 3pm'"
                    },
                },
                {
                    "name": "assistant",
                    "content": {
                        "text": "I'll place that call with your reminder message.",
                        "action": "MAKE_CALL",
                    },
                },
            ],
            [
                {
                    "name": "user",
                    "content": {
                        "text": "Phone +15555551234 with an automated message about the meeting cancellation"
                    },
                },
                {
                    "name": "assistant",
                    "content": {
                        "text": "Initiating the call with the cancellation message.",
                        "action": "MAKE_CALL",
                    },
                },
            ],
        ]
    )

    def validate(self, runtime: object, message: object, state: object = None) -> bool:
        """Validate that the action can be performed."""
        twilio_service = runtime.get_service(TWILIO_SERVICE_NAME)
        if not twilio_service:
            logger.error("Twilio service not found")
            return False

        text = getattr(message.content, "text", "") or ""
        phone_number = extract_phone_number(text)
        text_lower = text.lower()
        has_call_intent = any(
            keyword in text_lower for keyword in ("call", "phone", "dial")
        )

        return bool(phone_number) and has_call_intent

    async def handler(
        self,
        runtime: object,
        message: object,
        state: object = None,
        options: object = None,
        callback: object = None,
    ) -> None:
        """Handle the MAKE_CALL action."""
        try:
            twilio_service = runtime.get_service(TWILIO_SERVICE_NAME)
            if not twilio_service:
                raise RuntimeError("Twilio service not available")

            text = getattr(message.content, "text", "") or ""

            phone_number = extract_phone_number(text)
            if not phone_number:
                raise ValueError("No phone number found in message")

            # Extract call message content
            call_message = text.replace(phone_number, "")
            for pattern in [
                r"call|phone|dial",
                r"and\s*say",
                r"with\s*(the\s*)?(message|saying)",
            ]:
                call_message = re.sub(pattern, "", call_message, flags=re.IGNORECASE)
            call_message = re.sub(r'^["\']|["\']$', "", call_message.strip()).strip()

            if not call_message:
                call_message = "Hello, this is an automated call from your AI assistant."

            if not validate_phone_number(phone_number):
                raise ValueError("Invalid phone number format")

            twiml = generate_twiml.say(call_message)
            call = await twilio_service.make_call(phone_number, twiml)
            logger.info("Call initiated to %s, Call SID: %s", phone_number, call.sid)

            if callback:
                callback({
                    "text": f"Call initiated successfully to {phone_number}. Call ID: {call.sid}",
                    "success": True,
                })

        except Exception as exc:
            logger.error("Error making call: %s", exc)
            if callback:
                callback({
                    "text": f"Failed to make call: {exc}",
                    "success": False,
                })


make_call_action = MakeCallAction()
