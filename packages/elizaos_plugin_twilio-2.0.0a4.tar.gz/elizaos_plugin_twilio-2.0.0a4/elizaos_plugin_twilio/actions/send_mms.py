"""SEND_MMS action - Send a multimedia message via Twilio."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

from elizaos_plugin_twilio.config import TWILIO_SERVICE_NAME
from elizaos_plugin_twilio.utils import extract_phone_number, validate_messaging_address

logger = logging.getLogger(__name__)

URL_PATTERN = re.compile(r"https?://[^\s]+")


@dataclass
class SendMmsAction:
    """Action to send an MMS (multimedia message) via Twilio."""

    name: str = "SEND_MMS"
    description: str = (
        "Send an MMS (multimedia message) with images, audio, or video via Twilio"
    )
    similes: list[str] = field(
        default_factory=lambda: [
            "send mms",
            "send picture",
            "send photo",
            "send image",
            "send video",
            "send media",
            "picture message",
            "photo message",
        ]
    )
    examples: list[list[dict[str, object]]] = field(
        default_factory=lambda: [
            [
                {
                    "name": "user",
                    "content": {
                        "text": "Send a picture to +18885551234 with the image from https://example.com/photo.jpg saying 'Check out this photo!'"
                    },
                },
                {
                    "name": "assistant",
                    "content": {
                        "text": "I'll send that photo with your message.",
                        "action": "SEND_MMS",
                    },
                },
            ],
            [
                {
                    "name": "user",
                    "content": {
                        "text": "Send an MMS to +15555551234 with the video at https://example.com/video.mp4"
                    },
                },
                {
                    "name": "assistant",
                    "content": {
                        "text": "Sending the video message now.",
                        "action": "SEND_MMS",
                    },
                },
            ],
        ]
    )

    def validate(self, runtime: object, message: object, state: object = None) -> bool:
        """Validate that the action can be performed."""
        twilio_service = runtime.get_service(TWILIO_SERVICE_NAME)
        if not twilio_service:
            logger.error("Twilio service not found")
            return False

        text = getattr(message.content, "text", "") or ""
        phone_number = extract_phone_number(text)
        text_lower = text.lower()
        media_intent = any(
            keyword in text_lower
            for keyword in ("image", "photo", "picture", "video", "media", "mms")
        )

        return bool(phone_number) and (media_intent or bool(URL_PATTERN.search(text)))

    async def handler(
        self,
        runtime: object,
        message: object,
        state: object = None,
        options: object = None,
        callback: object = None,
    ) -> None:
        """Handle the SEND_MMS action."""
        try:
            twilio_service = runtime.get_service(TWILIO_SERVICE_NAME)
            if not twilio_service:
                raise RuntimeError("Twilio service not available")

            text = getattr(message.content, "text", "") or ""

            phone_number = extract_phone_number(text)
            if not phone_number:
                raise ValueError("No phone number found in message")

            # Extract media URLs
            media_urls: list[str] = URL_PATTERN.findall(text) or [
                "https://demo.twilio.com/owl.png"
            ]

            # Extract message content
            message_content = text.replace(phone_number, "")
            for pattern in [
                r"send\s*(an?\s*)?(mms|picture|photo|image|video|media)\s*(to\s*)?",
                r"with\s*(the\s*)?(image|photo|picture|video|media|mms)",
                r"at|from",
                r"saying|with\s*(the\s*)?(message|text)",
            ]:
                message_content = re.sub(pattern, "", message_content, flags=re.IGNORECASE)
            message_content = URL_PATTERN.sub("", message_content)
            message_content = re.sub(r'^["\']|["\']$', "", message_content.strip()).strip()

            if not message_content:
                message_content = "Here's the media you requested"

            if not validate_messaging_address(phone_number):
                raise ValueError("Invalid phone number format")

            await twilio_service.send_sms(phone_number, message_content, media_urls)
            logger.info(
                "MMS sent to %s with %d media attachment(s)",
                phone_number,
                len(media_urls),
            )

            if callback:
                callback({
                    "text": (
                        f"MMS sent successfully to {phone_number} "
                        f"with {len(media_urls)} media attachment(s)"
                    ),
                    "success": True,
                })

        except Exception as exc:
            logger.error("Error sending MMS: %s", exc)
            if callback:
                callback({
                    "text": f"Failed to send MMS: {exc}",
                    "success": False,
                })


send_mms_action = SendMmsAction()
