"""SEND_SMS action - Send an SMS message via Twilio."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

from elizaos_plugin_twilio.config import TWILIO_SERVICE_NAME
from elizaos_plugin_twilio.utils import (
    chunk_text_for_sms,
    extract_phone_number,
    validate_messaging_address,
)

logger = logging.getLogger(__name__)


@dataclass
class SendSmsAction:
    """Action to send an SMS message to a phone number via Twilio."""

    name: str = "SEND_SMS"
    description: str = "Send an SMS message to a phone number via Twilio"
    similes: list[str] = field(
        default_factory=lambda: [
            "send sms",
            "send text",
            "text message",
            "sms to",
            "text to",
            "message phone",
        ]
    )
    examples: list[list[dict[str, object]]] = field(
        default_factory=lambda: [
            [
                {
                    "name": "user",
                    "content": {
                        "text": "Send an SMS to +18885551234 saying 'Hello from AI assistant!'"
                    },
                },
                {
                    "name": "assistant",
                    "content": {
                        "text": "I'll send that SMS message for you.",
                        "action": "SEND_SMS",
                    },
                },
            ],
            [
                {
                    "name": "user",
                    "content": {
                        "text": "Text +15555551234 with the message 'Meeting confirmed for 3pm tomorrow'"
                    },
                },
                {
                    "name": "assistant",
                    "content": {
                        "text": "Sending the meeting confirmation SMS now.",
                        "action": "SEND_SMS",
                    },
                },
            ],
        ]
    )

    def validate(self, runtime: object, message: object, state: object = None) -> bool:
        """Validate that the action can be performed."""
        twilio_service = runtime.get_service(TWILIO_SERVICE_NAME)
        if not twilio_service:
            logger.error("Twilio service not found")
            return False

        text = getattr(message.content, "text", "") or ""
        phone_number = extract_phone_number(text)
        text_lower = text.lower()
        has_sms_intent = any(
            keyword in text_lower for keyword in ("sms", "text", "message")
        )

        return bool(phone_number) and has_sms_intent

    async def handler(
        self,
        runtime: object,
        message: object,
        state: object = None,
        options: object = None,
        callback: object = None,
    ) -> None:
        """Handle the SEND_SMS action."""
        try:
            twilio_service = runtime.get_service(TWILIO_SERVICE_NAME)
            if not twilio_service:
                raise RuntimeError("Twilio service not available")

            text = getattr(message.content, "text", "") or ""

            phone_number = extract_phone_number(text)
            if not phone_number:
                raise ValueError("No phone number found in message")

            # Extract message content: remove phone number and command keywords
            message_content = text.replace(phone_number, "")
            message_content = re.sub(
                r"^(send\s*(an?\s*)?(sms|text|message)\s*(to\s*)?|text\s+)",
                "",
                message_content,
                flags=re.IGNORECASE,
            )
            message_content = re.sub(
                r"\b(saying|with\s*(the\s*)?(message|text))\b",
                "",
                message_content,
                flags=re.IGNORECASE,
            )
            message_content = re.sub(r'^["\']|["\']$', "", message_content.strip()).strip()

            if not message_content:
                message_content = "Hello from your AI assistant!"

            if not validate_messaging_address(phone_number):
                raise ValueError("Invalid phone number format")

            # Handle long messages by chunking
            for chunk in chunk_text_for_sms(message_content):
                await twilio_service.send_sms(phone_number, chunk)
                logger.info("SMS sent to %s: %s...", phone_number, chunk[:50])

            if callback:
                callback({
                    "text": f"SMS message sent successfully to {phone_number}",
                    "success": True,
                })

        except Exception as exc:
            logger.error("Error sending SMS: %s", exc)
            if callback:
                callback({
                    "text": f"Failed to send SMS: {exc}",
                    "success": False,
                })


send_sms_action = SendSmsAction()
