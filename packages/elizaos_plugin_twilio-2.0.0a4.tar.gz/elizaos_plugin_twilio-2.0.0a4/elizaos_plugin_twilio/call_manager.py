"""CallManager - Manages call lifecycle, state machine, and transcript tracking."""

from __future__ import annotations

import time
import uuid

from elizaos_plugin_twilio.types import (
    CONVERSATION_STATES,
    STATE_ORDER,
    TERMINAL_STATES,
    CallRecord,
    CallState,
    NormalizedEvent,
    TranscriptEntry,
)


class CallManagerSettings:
    """Settings for the CallManager."""

    def __init__(
        self,
        *,
        provider: str = "twilio",
        from_number: str = "",
        max_concurrent_calls: int = 10,
        max_duration_seconds: int = 3600,
        transcript_timeout_ms: int = 30000,
        inbound_policy: str = "open",
        allow_from: list[str] | None = None,
        inbound_greeting: str = "Hello! How can I help you today?",
        default_mode: str = "notify",
    ) -> None:
        self.provider = provider
        self.from_number = from_number
        self.max_concurrent_calls = max_concurrent_calls
        self.max_duration_seconds = max_duration_seconds
        self.transcript_timeout_ms = transcript_timeout_ms
        self.inbound_policy = inbound_policy
        self.allow_from = allow_from or []
        self.inbound_greeting = inbound_greeting
        self.default_mode = default_mode


class CallManager:
    """Manages call lifecycle, state machine, persistence, and history.

    Handles:
    - Creating outbound/inbound call records
    - State machine transitions
    - Transcript tracking
    - Event processing from webhooks
    - Call history
    """

    def __init__(self, settings: CallManagerSettings) -> None:
        self._settings = settings
        self._active_calls: dict[str, CallRecord] = {}
        self._call_history: list[CallRecord] = []
        self._provider_call_id_map: dict[str, str] = {}
        self._processed_event_ids: set[str] = set()
        self._webhook_url: str | None = None

    def initialize(self, webhook_url: str) -> None:
        """Initialize the call manager with a webhook URL."""
        self._webhook_url = webhook_url

    @property
    def webhook_url(self) -> str | None:
        """Get the webhook URL."""
        return self._webhook_url

    def create_outbound_call(
        self,
        to: str,
        *,
        message: str | None = None,
        mode: str | None = None,
    ) -> tuple[str, CallRecord]:
        """Create a new outbound call record.

        Returns:
            Tuple of (call_id, CallRecord).
        """
        call_id = str(uuid.uuid4())
        effective_mode = mode or self._settings.default_mode

        metadata: dict[str, object] = {"mode": effective_mode}
        if message:
            metadata["initialMessage"] = message

        record = CallRecord(
            call_id=call_id,
            provider=self._settings.provider,
            direction="outbound",
            state=CallState.INITIATED.value,
            **{"from": self._settings.from_number},
            to=to,
            started_at=time.time() * 1000,
            transcript=[],
            processed_event_ids=[],
            metadata=metadata,
        )

        self._active_calls[call_id] = record
        return call_id, record

    def create_inbound_call(
        self,
        provider_call_id: str,
        from_number: str,
        to_number: str,
    ) -> CallRecord:
        """Create a new inbound call record."""
        call_id = str(uuid.uuid4())

        record = CallRecord(
            call_id=call_id,
            provider_call_id=provider_call_id,
            provider=self._settings.provider,
            direction="inbound",
            state=CallState.RINGING.value,
            **{"from": from_number},
            to=to_number,
            started_at=time.time() * 1000,
            transcript=[],
            processed_event_ids=[],
            metadata={"initialMessage": self._settings.inbound_greeting},
        )

        self._active_calls[call_id] = record
        self._provider_call_id_map[provider_call_id] = call_id
        return record

    def update_provider_call_id(self, call_id: str, provider_call_id: str) -> None:
        """Update a call's provider call ID."""
        if call := self._active_calls.get(call_id):
            if call.provider_call_id:
                self._provider_call_id_map.pop(call.provider_call_id, None)
            call.provider_call_id = provider_call_id
            self._provider_call_id_map[provider_call_id] = call_id

    def get_call(self, call_id: str) -> CallRecord | None:
        """Get a call by internal ID."""
        return self._active_calls.get(call_id)

    def get_call_by_provider_id(self, provider_call_id: str) -> CallRecord | None:
        """Get a call by provider call ID."""
        if call_id := self._provider_call_id_map.get(provider_call_id):
            return self._active_calls.get(call_id)
        # Fallback: linear search
        return next(
            (c for c in self._active_calls.values() if c.provider_call_id == provider_call_id),
            None,
        )

    def get_active_calls(self) -> list[CallRecord]:
        """Get all active calls."""
        return list(self._active_calls.values())

    def is_at_max_concurrent_calls(self) -> bool:
        """Check if at maximum concurrent calls."""
        return len(self._active_calls) >= self._settings.max_concurrent_calls

    def update_state(self, call_id: str, new_state: str) -> None:
        """Update call state via state machine."""
        if call := self._active_calls.get(call_id):
            self._transition_state(call, new_state)

    def add_transcript_entry(
        self,
        call_id: str,
        speaker: str,
        text: str,
    ) -> None:
        """Add a transcript entry to a call."""
        if call := self._active_calls.get(call_id):
            call.transcript.append(TranscriptEntry(
                timestamp=time.time() * 1000,
                speaker=speaker,
                text=text,
                is_final=True,
            ))

    def mark_answered(self, call_id: str) -> None:
        """Mark a call as answered."""
        if call := self._active_calls.get(call_id):
            call.answered_at = time.time() * 1000
            self._transition_state(call, CallState.ANSWERED.value)

    def mark_ended(self, call_id: str, reason: str) -> None:
        """Mark a call as ended and move to history."""
        if not (call := self._active_calls.get(call_id)):
            return

        call.ended_at = time.time() * 1000
        call.end_reason = reason
        self._transition_state(call, reason)

        # Move to history
        self._call_history.append(call.model_copy())
        self._active_calls.pop(call_id, None)
        if call.provider_call_id:
            self._provider_call_id_map.pop(call.provider_call_id, None)

    def process_event(self, event: NormalizedEvent) -> CallRecord | None:
        """Process a webhook event and update call state.

        Returns:
            The updated CallRecord or None if event was skipped.
        """
        if event.id in self._processed_event_ids:
            return None
        self._processed_event_ids.add(event.id)

        call = self._find_call(event.call_id)

        # Handle inbound calls
        if not call and event.direction == "inbound" and event.provider_call_id:
            if not self._should_accept_inbound(event.from_):
                return None
            call = self.create_inbound_call(
                event.provider_call_id,
                event.from_ or "unknown",
                event.to or self._settings.from_number,
            )

        if not call:
            return None

        # Update provider call ID
        if event.provider_call_id and event.provider_call_id != call.provider_call_id:
            self.update_provider_call_id(call.call_id, event.provider_call_id)

        call.processed_event_ids.append(event.id)

        # Process based on event type
        _EVENT_STATE_MAP = {
            "call.initiated": CallState.INITIATED,
            "call.ringing": CallState.RINGING,
            "call.active": CallState.ACTIVE,
            "call.speaking": CallState.SPEAKING,
        }

        if event.type in _EVENT_STATE_MAP:
            self._transition_state(call, _EVENT_STATE_MAP[event.type].value)
        elif event.type == "call.answered":
            call.answered_at = event.timestamp
            self._transition_state(call, CallState.ANSWERED.value)
        elif event.type == "call.speech":
            if event.is_final and event.transcript:
                self.add_transcript_entry(call.call_id, "user", event.transcript)
            self._transition_state(call, CallState.LISTENING.value)
        elif event.type == "call.ended":
            self.mark_ended(call.call_id, event.reason or "completed")
        elif event.type == "call.error":
            if not event.retryable:
                self.mark_ended(call.call_id, CallState.ERROR.value)

        return call

    def get_call_history(self, limit: int = 50) -> list[CallRecord]:
        """Get call history (completed calls), most recent first."""
        return list(reversed(self._call_history[-limit:]))

    # --- Private helpers ---

    def _find_call(self, call_id_or_provider: str) -> CallRecord | None:
        """Find a call by internal ID or provider call ID."""
        if direct := self._active_calls.get(call_id_or_provider):
            return direct
        return self.get_call_by_provider_id(call_id_or_provider)

    def _should_accept_inbound(self, from_number: str | None) -> bool:
        """Determine if an inbound call should be accepted."""
        policy = self._settings.inbound_policy

        if policy == "disabled":
            return False
        if policy == "open":
            return True
        if policy in ("allowlist", "pairing"):
            return bool(from_number) and any(
                from_number.endswith(allowed) or allowed.endswith(from_number)
                for allowed in self._settings.allow_from
            )
        return False

    def _transition_state(self, call: CallRecord, new_state: str) -> None:
        """Apply state machine transition rules.

        Rules:
        - Don't transition if already in the same state
        - Don't transition from terminal states
        - Allow transitions to terminal states from any non-terminal state
        - Allow free transitions between conversation states (speaking, listening)
        - Otherwise only allow forward transitions in the state order
        """
        if call.state == new_state:
            return

        try:
            current_cs = CallState(call.state)
        except ValueError:
            return
        try:
            new_cs = CallState(new_state)
        except ValueError:
            return

        # Don't move from terminal states
        if current_cs in TERMINAL_STATES:
            return

        # Allow transitions to terminal states
        if new_cs in TERMINAL_STATES:
            call.state = new_state
            return

        # Allow free movement between conversation states
        if current_cs in CONVERSATION_STATES and new_cs in CONVERSATION_STATES:
            call.state = new_state
            return

        # Only allow forward transitions
        current_idx = STATE_ORDER.index(current_cs) if current_cs in STATE_ORDER else -1
        new_idx = STATE_ORDER.index(new_cs) if new_cs in STATE_ORDER else -1
        if new_idx > current_idx:
            call.state = new_state
