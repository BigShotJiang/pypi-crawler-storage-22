"""Configuration constants for the Twilio plugin."""

from __future__ import annotations

# Service name
TWILIO_SERVICE_NAME = "twilio"

# Message limits
SMS_MAX_LENGTH = 1600
MMS_MAX_MEDIA_SIZE = 5_242_880  # 5MB
MMS_MAX_MEDIA_COUNT = 10

# Voice constants
DEFAULT_VOICE = "alice"
DEFAULT_LANGUAGE = "en-US"
VOICE_STREAM_TIMEOUT = 300_000  # 5 minutes in ms

# API endpoints
API_BASE_URL = "https://api.twilio.com"

# Webhook paths
WEBHOOK_PATH_SMS = "/webhooks/twilio/sms"
WEBHOOK_PATH_VOICE = "/webhooks/twilio/voice"
WEBHOOK_PATH_STATUS = "/webhooks/twilio/status"
WEBHOOK_PATH_VOICE_STREAM = "/webhooks/twilio/voice-stream"

# TwiML templates
DEFAULT_VOICE_RESPONSE = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    "<Response>\n"
    '    <Say voice="alice">Hello from Eliza AI assistant. How can I help you today?</Say>\n'
    '    <Pause length="1"/>\n'
    "</Response>"
)

# Rate limits
RATE_LIMIT_SMS_PER_SECOND = 1
RATE_LIMIT_CALLS_PER_SECOND = 1
WEBHOOK_TIMEOUT = 15_000  # 15 seconds in ms

# Cache TTL (seconds)
CACHE_TTL_CONVERSATION = 3600  # 1 hour
CACHE_TTL_MEDIA = 86400  # 24 hours
CACHE_TTL_CALL_STATE = 1800  # 30 minutes

# Audio formats
AUDIO_FORMAT_INPUT = "audio/x-mulaw"
AUDIO_FORMAT_OUTPUT = "audio/x-mulaw"
AUDIO_SAMPLE_RATE = 8000
AUDIO_CHANNELS = 1

# Supported media types
SUPPORTED_MEDIA_TYPES = (
    "image/jpeg",
    "image/png",
    "image/gif",
    "audio/mpeg",
    "audio/ogg",
    "audio/wav",
    "video/mp4",
)

# Error messages
ERROR_INVALID_PHONE_NUMBER = (
    "Invalid phone number format. Please use E.164 format (e.g., +18885551212)"
)
ERROR_MISSING_CREDENTIALS = "Twilio credentials not configured"
ERROR_WEBHOOK_VALIDATION_FAILED = "Failed to validate Twilio webhook signature"
ERROR_RATE_LIMIT_EXCEEDED = "Rate limit exceeded. Please try again later."
ERROR_MEDIA_TOO_LARGE = "Media file too large. Maximum size is 5MB"
ERROR_UNSUPPORTED_MEDIA_TYPE = "Unsupported media type"

# Max conversation history
MAX_CONVERSATION_HISTORY = 50
