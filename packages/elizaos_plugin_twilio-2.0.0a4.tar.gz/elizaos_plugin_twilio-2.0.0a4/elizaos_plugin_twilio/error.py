"""Error types for the Twilio plugin."""

from __future__ import annotations


class TwilioError(Exception):
    """Base error for Twilio operations."""

    def __init__(
        self,
        message: str,
        code: int | None = None,
        twilio_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.twilio_code = twilio_code

    def __repr__(self) -> str:
        parts = [f"TwilioError({self.args[0]!r}"]
        if self.code is not None:
            parts.append(f", code={self.code}")
        if self.twilio_code is not None:
            parts.append(f", twilio_code={self.twilio_code!r}")
        parts.append(")")
        return "".join(parts)


class TwilioConfigError(TwilioError):
    """Configuration error."""


class TwilioValidationError(TwilioError):
    """Validation error for phone numbers, messages, etc."""


class TwilioApiError(TwilioError):
    """Error from Twilio API calls."""


class TwilioCallError(TwilioError):
    """Error related to voice call operations."""
