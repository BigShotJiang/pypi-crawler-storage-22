"""Twilio plugin definition for elizaOS."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from elizaos_plugin_twilio.actions import make_call_action, send_mms_action, send_sms_action
from elizaos_plugin_twilio.providers import call_state_provider, conversation_history_provider
from elizaos_plugin_twilio.service import TwilioService

logger = logging.getLogger(__name__)


@dataclass
class TwilioPlugin:
    """Twilio plugin for bidirectional voice and text messaging integration.

    Provides:
    - 3 actions: SEND_SMS, MAKE_CALL, SEND_MMS
    - 2 providers: callState, conversationHistory
    - TwilioService for SMS, MMS, and voice calls
    """

    name: str = "twilio"
    description: str = (
        "Twilio plugin for bidirectional voice and text messaging integration "
        "with advanced voice call lifecycle management"
    )
    actions: list[object] = field(
        default_factory=lambda: [send_sms_action, make_call_action, send_mms_action]
    )
    providers: list[object] = field(
        default_factory=lambda: [conversation_history_provider, call_state_provider]
    )
    services: list[type] = field(default_factory=lambda: [TwilioService])

    def init(self, config: dict[str, str], runtime: object) -> None:
        """Initialize the plugin.

        Validates that required settings are present and logs warnings
        for missing optional settings.
        """
        account_sid = runtime.get_setting("TWILIO_ACCOUNT_SID") or ""
        auth_token = runtime.get_setting("TWILIO_AUTH_TOKEN") or ""
        phone_number = runtime.get_setting("TWILIO_PHONE_NUMBER") or ""
        webhook_url = runtime.get_setting("TWILIO_WEBHOOK_URL") or ""

        for field_name, value in [
            ("Account SID", account_sid),
            ("Auth Token", auth_token),
            ("Phone Number", phone_number),
        ]:
            if not value.strip():
                logger.warning(
                    "Twilio %s not provided - "
                    "Twilio plugin is loaded but will not be functional",
                    field_name,
                )
                return

        if not webhook_url.strip():
            logger.warning(
                "Twilio Webhook URL not provided - "
                "Twilio will not be able to receive incoming messages or calls"
            )

        logger.info("Twilio plugin initialized successfully")


twilio_plugin = TwilioPlugin()
