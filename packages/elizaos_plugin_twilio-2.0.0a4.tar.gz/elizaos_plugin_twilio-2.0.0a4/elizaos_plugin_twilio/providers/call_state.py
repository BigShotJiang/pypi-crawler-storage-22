"""Call state provider - Provides information about active voice calls."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from elizaos_plugin_twilio.config import TWILIO_SERVICE_NAME

logger = logging.getLogger(__name__)


@dataclass
class CallStateProvider:
    """Provides information about active voice calls and streams."""

    name: str = "twilioCallState"
    description: str = "Provides information about active voice calls and streams"

    def get(self, runtime: object, message: object, state: object = None) -> dict[str, object]:
        """Get active call state information."""
        try:
            twilio_service = runtime.get_service(TWILIO_SERVICE_NAME)
            if not twilio_service:
                return {
                    "text": "No Twilio call state available - service not initialized",
                }

            active_streams = getattr(twilio_service, "voice_streams", None)

            if not active_streams:
                return {
                    "text": "No active voice calls",
                    "data": {"activeCallCount": 0},
                }

            call_info: list[str] = []
            call_data: list[dict[str, str]] = []

            for call_sid, stream in active_streams.items():
                stream_sid = getattr(stream, "stream_sid", stream.get("streamSid", ""))
                from_ = getattr(stream, "from_", stream.get("from", ""))
                to = getattr(stream, "to", stream.get("to", ""))

                call_info.append(f"Call {call_sid}: {from_} -> {to}")
                call_data.append({
                    "callSid": call_sid,
                    "streamSid": stream_sid,
                    "from": from_,
                    "to": to,
                })

            count = len(active_streams)
            return {
                "text": f"Active voice calls ({count}):\n" + "\n".join(call_info),
                "data": {
                    "activeCallCount": count,
                    "calls": call_data,
                },
            }

        except Exception as exc:
            logger.error("Error in callStateProvider: %s", exc)
            return {"text": "Error retrieving call state"}


call_state_provider = CallStateProvider()
