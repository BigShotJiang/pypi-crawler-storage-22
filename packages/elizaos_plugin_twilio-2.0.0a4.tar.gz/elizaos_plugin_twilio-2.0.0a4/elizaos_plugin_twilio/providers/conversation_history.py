"""Conversation history provider - Provides recent SMS/MMS conversation history."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime

from elizaos_plugin_twilio.config import TWILIO_SERVICE_NAME

logger = logging.getLogger(__name__)


@dataclass
class ConversationHistoryProvider:
    """Provides recent SMS/MMS conversation history with a phone number."""

    name: str = "twilioConversationHistory"
    description: str = "Provides recent SMS/MMS conversation history with a phone number"

    def get(self, runtime: object, message: object, state: object = None) -> dict[str, object]:
        """Get conversation history for the phone number in context."""
        try:
            twilio_service = runtime.get_service(TWILIO_SERVICE_NAME)
            if not twilio_service:
                return {
                    "text": "No Twilio conversation history available - service not initialized",
                }

            # Check if content is a string (edge case)
            content = message.content
            if isinstance(content, str):
                return {"text": "No phone number found in context"}

            # Extract phone number from content
            phone_number = getattr(content, "phoneNumber", None) or getattr(
                content, "phone_number", None
            )
            if not phone_number:
                text = getattr(content, "text", "") or ""
                if match := re.search(r"\+?\d{10,15}", text):
                    phone_number = match.group(0)

            if not phone_number or not isinstance(phone_number, str):
                return {"text": "No phone number found in context"}

            history = twilio_service.get_conversation_history(phone_number, 10)

            if not history:
                return {"text": f"No recent conversation history with {phone_number}"}

            # Format conversation history
            lines: list[str] = []
            for msg in history:
                direction_label = (
                    "From" if getattr(msg, "direction", "") == "inbound" else "To"
                )
                date_created = getattr(msg, "date_created", None)
                time_str = (
                    date_created.strftime("%Y-%m-%d %H:%M:%S")
                    if isinstance(date_created, datetime)
                    else str(date_created) if date_created else "unknown"
                )
                body = getattr(msg, "body", "")
                lines.append(f"[{time_str}] {direction_label} {phone_number}: {body}")

            return {
                "text": f"Recent SMS conversation with {phone_number}:\n" + "\n".join(lines),
                "data": {
                    "phoneNumber": phone_number,
                    "messageCount": len(history),
                    "lastMessage": history[-1],
                },
            }

        except Exception as exc:
            logger.error("Error in conversationHistoryProvider: %s", exc)
            return {"text": "Error retrieving conversation history"}


conversation_history_provider = ConversationHistoryProvider()
