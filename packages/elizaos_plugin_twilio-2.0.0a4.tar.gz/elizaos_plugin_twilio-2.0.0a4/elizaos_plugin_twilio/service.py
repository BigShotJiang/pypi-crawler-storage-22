"""TwilioService - Core service for SMS, MMS, and voice call operations."""

from __future__ import annotations

import logging
import time
from datetime import datetime

from elizaos_plugin_twilio.config import (
    CACHE_TTL_CALL_STATE,
    CACHE_TTL_CONVERSATION,
    ERROR_INVALID_PHONE_NUMBER,
    ERROR_MISSING_CREDENTIALS,
    MAX_CONVERSATION_HISTORY,
    TWILIO_SERVICE_NAME,
    WEBHOOK_PATH_STATUS,
)
from elizaos_plugin_twilio.error import TwilioApiError, TwilioConfigError, TwilioError
from elizaos_plugin_twilio.types import (
    CacheKeys,
    TwilioCall,
    TwilioConfig,
    TwilioEventType,
    TwilioMessage,
)
from elizaos_plugin_twilio.utils import (
    format_messaging_address,
    is_whatsapp_address,
    strip_whatsapp_prefix,
    validate_messaging_address,
    validate_phone_number,
)

logger = logging.getLogger(__name__)


class SimpleCache:
    """Simple in-memory cache with TTL support."""

    def __init__(self, default_ttl: int = 600) -> None:
        self._store: dict[str, tuple[object, float]] = {}
        self._default_ttl = default_ttl

    def get(self, key: str) -> object | None:
        if (entry := self._store.get(key)) is None:
            return None
        value, expires_at = entry
        if time.time() > expires_at:
            del self._store[key]
            return None
        return value

    def set(self, key: str, value: object, ttl: int | None = None) -> None:
        effective_ttl = ttl if ttl is not None else self._default_ttl
        self._store[key] = (value, time.time() + effective_ttl)

    def flush_all(self) -> None:
        self._store.clear()


class TwilioService:
    """Core Twilio service for sending SMS, MMS, and making voice calls.

    This service wraps the Twilio REST API client and manages:
    - Sending/receiving SMS and MMS messages
    - Making outbound voice calls
    - Conversation history caching
    - Call state caching
    """

    service_type: str = TWILIO_SERVICE_NAME

    def __init__(self) -> None:
        self._config: TwilioConfig | None = None
        self._client: object | None = None
        self._cache = SimpleCache(default_ttl=600)
        self._is_initialized = False
        self._voice_streams: dict[str, object] = {}

    async def initialize(self, config: TwilioConfig, client: object | None = None) -> None:
        """Initialize the service with configuration and optional pre-built client.

        Args:
            config: Twilio configuration.
            client: Optional pre-built Twilio REST client (for testing).
        """
        if self._is_initialized:
            logger.warning("TwilioService already initialized")
            return

        self._config = config

        if not config.account_sid or not config.auth_token or not config.phone_number:
            raise TwilioConfigError(ERROR_MISSING_CREDENTIALS)

        if client is not None:
            self._client = client
        else:
            from twilio.rest import Client

            self._client = Client(config.account_sid, config.auth_token)

        self._is_initialized = True
        logger.info("TwilioService initialized successfully")

    async def send_sms(
        self,
        to: str,
        body: str,
        media_url: list[str] | None = None,
        from_override: str | None = None,
    ) -> TwilioMessage:
        """Send an SMS or MMS message.

        Args:
            to: The destination phone number or WhatsApp address.
            body: The message body.
            media_url: Optional list of media URLs for MMS.
            from_override: Optional override for the sender number.

        Returns:
            The sent TwilioMessage.

        Raises:
            TwilioError: If the phone number is invalid or the API call fails.
        """
        assert self._config is not None

        normalized_to = format_messaging_address(to)
        if not normalized_to or not validate_messaging_address(normalized_to):
            raise TwilioError(ERROR_INVALID_PHONE_NUMBER)

        normalized_from = format_messaging_address(
            from_override or self._config.phone_number
        )
        if not normalized_from:
            raise TwilioError(ERROR_INVALID_PHONE_NUMBER)

        # Match WhatsApp prefix if recipient is WhatsApp
        from_number = (
            f"whatsapp:{strip_whatsapp_prefix(normalized_from)}"
            if is_whatsapp_address(normalized_to)
            else strip_whatsapp_prefix(normalized_from)
        )

        try:
            create_kwargs: dict[str, object] = {
                "from_": from_number,
                "to": normalized_to,
                "body": body,
            }
            if media_url:
                create_kwargs["media_url"] = media_url
            if self._config.webhook_url:
                create_kwargs["status_callback"] = (
                    f"{self._config.webhook_url}{WEBHOOK_PATH_STATUS}"
                )

            message = self._client.messages.create(**create_kwargs)

            twilio_message = TwilioMessage(
                sid=message.sid,
                **{"from": getattr(message, "from_", from_number)},
                to=message.to,
                body=message.body,
                direction="outbound",
                status=message.status,
                date_created=message.date_created or datetime.now(),
                date_sent=getattr(message, "date_sent", None),
            )

            # Cache the message in conversation history
            conversation_key = CacheKeys.conversation(normalized_to)
            history: list[TwilioMessage] = self._cache.get(conversation_key) or []
            history.append(twilio_message)
            if len(history) > MAX_CONVERSATION_HISTORY:
                history = history[-MAX_CONVERSATION_HISTORY:]
            self._cache.set(conversation_key, history, CACHE_TTL_CONVERSATION)

            return twilio_message

        except TwilioError:
            raise
        except Exception as exc:
            raise TwilioApiError(
                f"Failed to send SMS: {exc}",
                code=getattr(exc, "code", None),
                twilio_code=getattr(exc, "more_info", None),
            ) from exc

    async def make_call(
        self,
        to: str,
        twiml: str | None = None,
        url: str | None = None,
    ) -> TwilioCall:
        """Make a voice call.

        Args:
            to: Destination phone number in E.164 format.
            twiml: Optional TwiML to execute during the call.
            url: Optional URL returning TwiML instructions.

        Returns:
            The initiated TwilioCall.

        Raises:
            TwilioError: If the phone number is invalid or the API call fails.
        """
        assert self._config is not None

        if not validate_phone_number(to):
            raise TwilioError(ERROR_INVALID_PHONE_NUMBER)

        try:
            call_params: dict[str, object] = {
                "from_": self._config.phone_number,
                "to": to,
                "status_callback_event": ["initiated", "ringing", "answered", "completed"],
            }
            if self._config.webhook_url:
                call_params["status_callback"] = (
                    f"{self._config.webhook_url}{WEBHOOK_PATH_STATUS}"
                )

            if twiml:
                call_params["twiml"] = twiml
            elif url:
                call_params["url"] = url
            else:
                from elizaos_plugin_twilio.config import DEFAULT_VOICE_RESPONSE

                call_params["twiml"] = DEFAULT_VOICE_RESPONSE

            call = self._client.calls.create(**call_params)

            twilio_call = TwilioCall(
                sid=call.sid,
                **{"from": getattr(call, "from_", self._config.phone_number)},
                to=call.to,
                status=call.status,
                direction="outbound",
                date_created=call.date_created or datetime.now(),
            )

            # Cache call state
            self._cache.set(
                CacheKeys.call_state(call.sid),
                twilio_call,
                CACHE_TTL_CALL_STATE,
            )

            return twilio_call

        except TwilioError:
            raise
        except Exception as exc:
            raise TwilioApiError(
                f"Failed to make call: {exc}",
                code=getattr(exc, "code", None),
                twilio_code=getattr(exc, "more_info", None),
            ) from exc

    def get_conversation_history(
        self,
        phone_number: str,
        limit: int = 10,
    ) -> list[TwilioMessage]:
        """Get cached conversation history for a phone number.

        Args:
            phone_number: The phone number to look up.
            limit: Maximum number of messages to return.

        Returns:
            List of TwilioMessage objects.
        """
        cache_key = CacheKeys.conversation(phone_number)
        messages = self._cache.get(cache_key)
        if not messages or not isinstance(messages, list):
            return []
        return messages[-limit:]

    def get_call_state(self, call_sid: str) -> TwilioCall | None:
        """Get cached call state by call SID.

        Args:
            call_sid: The Twilio call SID.

        Returns:
            The TwilioCall or None if not found.
        """
        cache_key = CacheKeys.call_state(call_sid)
        return self._cache.get(cache_key)

    async def cleanup(self) -> None:
        """Clean up resources."""
        self._voice_streams.clear()
        self._cache.flush_all()
        self._is_initialized = False
        logger.info("TwilioService cleaned up")

    @property
    def is_connected(self) -> bool:
        """Whether the service is initialized and connected."""
        return self._is_initialized

    @property
    def phone_number(self) -> str:
        """The configured phone number."""
        return self._config.phone_number if self._config else ""

    @property
    def voice_streams(self) -> dict[str, object]:
        """Active voice streams."""
        return self._voice_streams
