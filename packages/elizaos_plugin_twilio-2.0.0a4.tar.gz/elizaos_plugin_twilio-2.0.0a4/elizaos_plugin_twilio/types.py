"""Type definitions for the Twilio plugin."""

from __future__ import annotations

import re
from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field, field_validator


# --- Regex patterns ---

E164_REGEX = re.compile(r"^\+[1-9]\d{1,14}$")
MESSAGING_REGEX = re.compile(r"^(whatsapp:)?\+[1-9]\d{1,14}$")


# --- Message types ---


class TwilioMedia(BaseModel):
    """Media attachment in a Twilio message."""

    content_type: str
    url: str
    sid: str


class TwilioMessage(BaseModel):
    """A Twilio SMS/MMS message."""

    sid: str
    from_: str = Field(alias="from")
    to: str
    body: str
    media: list[TwilioMedia] | None = None
    direction: str  # "inbound" | "outbound"
    status: str
    date_created: datetime
    date_sent: datetime | None = None

    model_config = {"populate_by_name": True}


class TwilioCall(BaseModel):
    """A Twilio voice call."""

    sid: str
    from_: str = Field(alias="from")
    to: str
    status: str
    direction: str  # "inbound" | "outbound"
    duration: int | None = None
    date_created: datetime
    date_ended: datetime | None = None

    model_config = {"populate_by_name": True}


# --- Voice stream ---


class TwilioVoiceStream(BaseModel):
    """WebSocket connection for voice streaming."""

    stream_sid: str
    call_sid: str
    from_: str = Field(alias="from")
    to: str
    socket: object | None = None

    model_config = {"populate_by_name": True, "arbitrary_types_allowed": True}


# --- Webhook types ---


class TwilioSmsWebhook(BaseModel):
    """Incoming SMS webhook payload."""

    MessageSid: str
    From: str
    To: str
    Body: str
    NumMedia: str | None = None
    # Additional MediaUrl0..N and MediaContentType0..N are handled dynamically


class TwilioVoiceWebhook(BaseModel):
    """Incoming voice webhook payload."""

    CallSid: str
    From: str
    To: str
    CallStatus: str
    Direction: str | None = None


class TwilioStatusWebhook(BaseModel):
    """Status callback webhook payload."""

    MessageSid: str | None = None
    MessageStatus: str | None = None
    SmsStatus: str | None = None
    CallSid: str | None = None
    CallStatus: str | None = None
    ErrorCode: str | None = None
    ErrorMessage: str | None = None
    To: str | None = None
    From: str | None = None
    MessagingServiceSid: str | None = None
    AccountSid: str | None = None
    ApiVersion: str | None = None


# --- Configuration ---


class TwilioConfig(BaseModel):
    """Twilio service configuration."""

    account_sid: str
    auth_token: str
    phone_number: str
    webhook_url: str = ""
    webhook_port: int = 3000


# --- Validation schemas ---


class SendSmsParams(BaseModel):
    """Parameters for sending an SMS."""

    to: str
    message: str = Field(min_length=1, max_length=1600)
    media_url: list[str] | None = None

    @field_validator("to")
    @classmethod
    def validate_to(cls, v: str) -> str:
        if not MESSAGING_REGEX.match(v):
            raise ValueError("Invalid messaging address format")
        return v


class MakeCallParams(BaseModel):
    """Parameters for making a call."""

    to: str
    message: str | None = None
    url: str | None = None

    @field_validator("to")
    @classmethod
    def validate_to(cls, v: str) -> str:
        if not E164_REGEX.match(v):
            raise ValueError("Invalid phone number format (E.164 required)")
        return v


class SendMmsParams(BaseModel):
    """Parameters for sending an MMS."""

    to: str
    message: str = Field(min_length=1, max_length=1600)
    media_url: list[str] = Field(min_length=1)

    @field_validator("to")
    @classmethod
    def validate_to(cls, v: str) -> str:
        if not MESSAGING_REGEX.match(v):
            raise ValueError("Invalid messaging address format")
        return v


# --- Cache keys ---


class CacheKeys:
    """Cache key generators."""

    @staticmethod
    def conversation(phone_number: str) -> str:
        return f"twilio:conversation:{phone_number}"

    @staticmethod
    def call_state(call_sid: str) -> str:
        return f"twilio:call:{call_sid}"

    @staticmethod
    def media(media_sid: str) -> str:
        return f"twilio:media:{media_sid}"


# --- Event types ---


class TwilioEventType(str, Enum):
    """Twilio event types."""

    SMS_RECEIVED = "sms:received"
    SMS_SENT = "sms:sent"
    CALL_RECEIVED = "call:received"
    CALL_ENDED = "call:ended"
    VOICE_STREAM_STARTED = "voice:stream:started"
    VOICE_STREAM_ENDED = "voice:stream:ended"


# --- Call Manager types ---


class CallState(str, Enum):
    """Call lifecycle states."""

    # Non-terminal states
    INITIATED = "initiated"
    RINGING = "ringing"
    ANSWERED = "answered"
    ACTIVE = "active"
    SPEAKING = "speaking"
    LISTENING = "listening"
    # Terminal states
    COMPLETED = "completed"
    HANGUP_USER = "hangup-user"
    HANGUP_BOT = "hangup-bot"
    TIMEOUT = "timeout"
    ERROR = "error"
    FAILED = "failed"
    NO_ANSWER = "no-answer"
    BUSY = "busy"
    VOICEMAIL = "voicemail"


TERMINAL_STATES: frozenset[CallState] = frozenset({
    CallState.COMPLETED,
    CallState.HANGUP_USER,
    CallState.HANGUP_BOT,
    CallState.TIMEOUT,
    CallState.ERROR,
    CallState.FAILED,
    CallState.NO_ANSWER,
    CallState.BUSY,
    CallState.VOICEMAIL,
})

CONVERSATION_STATES: frozenset[CallState] = frozenset({
    CallState.SPEAKING,
    CallState.LISTENING,
})

STATE_ORDER: list[CallState] = [
    CallState.INITIATED,
    CallState.RINGING,
    CallState.ANSWERED,
    CallState.ACTIVE,
    CallState.SPEAKING,
    CallState.LISTENING,
]


class CallDirection(str, Enum):
    """Call direction."""

    OUTBOUND = "outbound"
    INBOUND = "inbound"


class CallMode(str, Enum):
    """Call mode."""

    NOTIFY = "notify"
    CONVERSATION = "conversation"


class TranscriptEntry(BaseModel):
    """A single transcript entry in a call."""

    timestamp: float
    speaker: str  # "bot" | "user"
    text: str
    is_final: bool = True


class CallRecord(BaseModel):
    """Complete call record."""

    call_id: str
    provider_call_id: str | None = None
    provider: str = "twilio"
    direction: str  # "outbound" | "inbound"
    state: str = "initiated"
    from_: str = Field(alias="from", default="")
    to: str = ""
    session_key: str | None = None
    started_at: float = 0.0
    answered_at: float | None = None
    ended_at: float | None = None
    end_reason: str | None = None
    transcript: list[TranscriptEntry] = Field(default_factory=list)
    processed_event_ids: list[str] = Field(default_factory=list)
    metadata: dict[str, object] | None = None

    model_config = {"populate_by_name": True}


class NormalizedEvent(BaseModel):
    """Normalized call event from webhooks."""

    id: str
    type: str
    call_id: str
    provider_call_id: str | None = None
    timestamp: float
    direction: str | None = None
    from_: str | None = Field(alias="from", default=None)
    to: str | None = None
    # Additional fields depending on type
    text: str | None = None
    transcript: str | None = None
    is_final: bool | None = None
    confidence: float | None = None
    duration_ms: int | None = None
    digits: str | None = None
    reason: str | None = None
    error: str | None = None
    retryable: bool | None = None

    model_config = {"populate_by_name": True}
