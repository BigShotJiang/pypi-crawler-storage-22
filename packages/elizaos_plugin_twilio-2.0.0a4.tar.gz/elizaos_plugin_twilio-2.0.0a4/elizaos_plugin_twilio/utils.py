"""Utility functions for the Twilio plugin.

Includes phone validation, formatting, TwiML generation, SMS chunking,
and phone number extraction.
"""

from __future__ import annotations

import re


# --- Phone number validation ---


def validate_phone_number(phone_number: str) -> bool:
    """Validate a phone number in E.164 format.

    E.164 format: +[country code][area code][phone number]
    Example: +18885551212
    """
    e164_regex = re.compile(r"^\+[1-9]\d{1,14}$")
    return bool(e164_regex.match(phone_number))


def validate_messaging_address(address: str) -> bool:
    """Validate a messaging address for SMS/WhatsApp.

    Accepts E.164 or WhatsApp-prefixed addresses.
    """
    messaging_regex = re.compile(r"^(whatsapp:)?\+[1-9]\d{1,14}$")
    return bool(messaging_regex.match(address))


def is_whatsapp_address(address: str) -> bool:
    """Determine if an address is a WhatsApp address."""
    return address.startswith("whatsapp:")


def strip_whatsapp_prefix(address: str) -> str:
    """Remove WhatsApp prefix if present."""
    if is_whatsapp_address(address):
        return address[len("whatsapp:"):]
    return address


def format_messaging_address(
    address: str,
    default_country_code: str = "+1",
) -> str | None:
    """Format a messaging address, preserving WhatsApp prefix if provided."""
    has_prefix = is_whatsapp_address(address)
    formatted = format_phone_number(strip_whatsapp_prefix(address), default_country_code)
    if not formatted:
        return None
    return f"whatsapp:{formatted}" if has_prefix else formatted


def format_phone_number(
    phone_number: str,
    default_country_code: str = "+1",
) -> str | None:
    """Format a phone number to E.164 format if possible.

    Args:
        phone_number: The phone number to format.
        default_country_code: The default country code to use if not provided.

    Returns:
        The formatted phone number or None if invalid.
    """
    # Remove all non-numeric characters except +
    cleaned = re.sub(r"[^\d+]", "", phone_number)

    # If it doesn't start with +, add the default country code
    if not cleaned.startswith("+"):
        if cleaned.startswith("1") and len(cleaned) == 11:
            cleaned = "+" + cleaned
        elif len(cleaned) == 10:
            cleaned = default_country_code + cleaned
        else:
            return None

    if validate_phone_number(cleaned):
        return cleaned

    return None


# --- TwiML generation ---


def _escape_xml(text: str) -> str:
    """Escape XML special characters."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


class GenerateTwiML:
    """TwiML generation utilities."""

    @staticmethod
    def say(message: str, voice: str = "alice") -> str:
        """Generate TwiML for a simple voice response."""
        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            "<Response>\n"
            f'    <Say voice="{voice}">{_escape_xml(message)}</Say>\n'
            "</Response>"
        )

    @staticmethod
    def gather(
        prompt: str,
        *,
        num_digits: int = 1,
        timeout: int = 5,
        action: str = "",
        method: str = "POST",
    ) -> str:
        """Generate TwiML for gathering input."""
        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            "<Response>\n"
            f'    <Gather numDigits="{num_digits}" timeout="{timeout}" '
            f'action="{action}" method="{method}">\n'
            f"        <Say>{_escape_xml(prompt)}</Say>\n"
            "    </Gather>\n"
            "</Response>"
        )

    @staticmethod
    def stream(
        stream_url: str,
        custom_parameters: dict[str, str] | None = None,
    ) -> str:
        """Generate TwiML for starting a media stream."""
        params = ""
        if custom_parameters:
            params = "\n".join(
                f'            <Parameter name="{key}" value="{_escape_xml(value)}" />'
                for key, value in custom_parameters.items()
            )

        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            "<Response>\n"
            "    <Start>\n"
            f'        <Stream url="{stream_url}">\n'
            f"            {params}\n"
            "        </Stream>\n"
            "    </Start>\n"
            "    <Say>Please wait while I connect you to the AI assistant.</Say>\n"
            '    <Pause length="60"/>\n'
            "</Response>"
        )

    @staticmethod
    def record(
        *,
        max_length: int = 3600,
        timeout: int = 5,
        transcribe: bool = False,
        action: str = "",
    ) -> str:
        """Generate TwiML for recording a call."""
        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            "<Response>\n"
            f'    <Record maxLength="{max_length}" timeout="{timeout}" '
            f'transcribe="{str(transcribe).lower()}" action="{action}" />\n'
            "</Response>"
        )

    @staticmethod
    def hangup() -> str:
        """Generate TwiML to hang up."""
        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            "<Response>\n"
            "    <Hangup />\n"
            "</Response>"
        )


generate_twiml = GenerateTwiML()


# --- Media parsing ---


def parse_media_from_webhook(
    webhook_data: dict[str, str],
    num_media: int,
) -> list[dict[str, str]]:
    """Parse media URLs from webhook data.

    Args:
        webhook_data: The webhook data dictionary.
        num_media: The number of media items.

    Returns:
        List of media objects with url, contentType, and sid.
    """
    media: list[dict[str, str]] = []
    for i in range(num_media):
        url = webhook_data.get(f"MediaUrl{i}")
        content_type = webhook_data.get(f"MediaContentType{i}", "unknown")
        if url:
            media.append({
                "url": url,
                "contentType": content_type,
                "sid": f"media_{i}",
            })
    return media


# --- Phone number extraction ---


def extract_phone_number(input_text: str) -> str | None:
    """Extract phone number from various formats in text.

    Args:
        input_text: The input string that may contain a phone number.

    Returns:
        The extracted phone number in E.164 format or None.
    """
    wants_whatsapp = "whatsapp:" in input_text.lower()

    patterns = [
        r"\+\d{1,15}",           # E.164 format
        r"\(\d{3}\)\s*\d{3}-\d{4}",  # (555) 555-5555
        r"\d{3}-\d{3}-\d{4}",   # 555-555-5555
        r"\d{10,15}",           # Just digits
    ]

    for pattern in patterns:
        match = re.search(pattern, input_text)
        if match:
            formatted = format_phone_number(match.group(0))
            if formatted:
                return f"whatsapp:{formatted}" if wants_whatsapp else formatted

    return None


# --- SMS chunking ---


def chunk_text_for_sms(text: str, max_length: int = 160) -> list[str]:
    """Chunk text for SMS messages respecting word boundaries.

    Args:
        text: The text to chunk.
        max_length: Maximum length per chunk (default: 160).

    Returns:
        List of text chunks.
    """
    if len(text) <= max_length:
        return [text]

    chunks: list[str] = []
    words = text.split(" ")
    current_chunk = ""

    for word in words:
        candidate = f"{current_chunk} {word}".strip() if current_chunk else word
        if len(candidate) <= max_length:
            current_chunk = candidate
        else:
            if current_chunk:
                chunks.append(current_chunk)
            current_chunk = word

    if current_chunk:
        chunks.append(current_chunk)

    return chunks


# --- Webhook URL generation ---


def get_webhook_url(base_url: str, path: str) -> str:
    """Generate a webhook URL for a specific path.

    Args:
        base_url: The base webhook URL.
        path: The path to append.

    Returns:
        The full webhook URL.
    """
    clean_base = base_url.rstrip("/")
    clean_path = path if path.startswith("/") else f"/{path}"
    return clean_base + clean_path
