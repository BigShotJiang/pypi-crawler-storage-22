"""Shared test fixtures for the Twilio plugin test suite."""
