"""Tests for Twilio plugin actions."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from elizaos_plugin_twilio.actions.make_call import MakeCallAction
from elizaos_plugin_twilio.actions.send_mms import SendMmsAction
from elizaos_plugin_twilio.actions.send_sms import SendSmsAction


def _make_runtime(service: MagicMock | None = None) -> MagicMock:
    runtime = MagicMock()
    runtime.get_service = MagicMock(return_value=service)
    return runtime


def _make_message(text: str) -> MagicMock:
    msg = MagicMock()
    msg.content.text = text
    return msg


def _make_twilio_service() -> MagicMock:
    service = MagicMock()
    service.send_sms = AsyncMock(
        return_value=MagicMock(
            sid="SM123",
            from_="+18885550000",
            to="+18885551234",
            body="Test",
            status="sent",
        )
    )
    service.make_call = AsyncMock(
        return_value=MagicMock(sid="CA123")
    )
    return service


# --- SendSmsAction tests ---


class TestSendSmsAction:
    """Tests for SEND_SMS action."""

    def test_metadata(self) -> None:
        action = SendSmsAction()
        assert action.name == "SEND_SMS"
        assert action.description == "Send an SMS message to a phone number via Twilio"
        assert "send sms" in action.similes
        assert "send text" in action.similes
        assert len(action.examples) > 0

    def test_validate_returns_true(self) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message("Send SMS to +18885551234")
        assert SendSmsAction().validate(runtime, message) is True

    def test_validate_returns_false_no_service(self) -> None:
        runtime = _make_runtime(None)
        message = _make_message("Send SMS to +18885551234")
        assert SendSmsAction().validate(runtime, message) is False

    def test_validate_returns_false_no_phone(self) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message("Send an SMS message")
        assert SendSmsAction().validate(runtime, message) is False

    @pytest.mark.parametrize("text", [
        "Text +18885551234",
        "SMS +18885551234",
        "Message +18885551234",
        "Send text to +18885551234",
    ])
    def test_validate_various_formats(self, text: str) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message(text)
        assert SendSmsAction().validate(runtime, message) is True

    @pytest.mark.asyncio
    async def test_handler_sends_sms(self) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message("Send SMS to +18885551234 saying 'Hello!'")
        callback = MagicMock()

        await SendSmsAction().handler(runtime, message, callback=callback)

        service.send_sms.assert_called_once()
        callback.assert_called_once()
        assert callback.call_args[0][0]["success"] is True

    @pytest.mark.asyncio
    async def test_handler_error_no_service(self) -> None:
        runtime = _make_runtime(None)
        message = _make_message("Send SMS to +18885551234")
        callback = MagicMock()

        await SendSmsAction().handler(runtime, message, callback=callback)

        callback.assert_called_once()
        assert callback.call_args[0][0]["success"] is False
        assert "not available" in callback.call_args[0][0]["text"]

    @pytest.mark.asyncio
    async def test_handler_api_error(self) -> None:
        service = _make_twilio_service()
        service.send_sms = AsyncMock(side_effect=Exception("API Error"))
        runtime = _make_runtime(service)
        message = _make_message("Send SMS to +18885551234 saying 'Test'")
        callback = MagicMock()

        await SendSmsAction().handler(runtime, message, callback=callback)

        callback.assert_called_once()
        assert callback.call_args[0][0]["success"] is False


# --- MakeCallAction tests ---


class TestMakeCallAction:
    """Tests for MAKE_CALL action."""

    def test_metadata(self) -> None:
        action = MakeCallAction()
        assert action.name == "MAKE_CALL"
        assert "make call" in action.similes
        assert len(action.examples) > 0

    def test_validate_returns_true(self) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message("Call +18885551234")
        assert MakeCallAction().validate(runtime, message) is True

    def test_validate_returns_false_no_service(self) -> None:
        runtime = _make_runtime(None)
        message = _make_message("Call +18885551234")
        assert MakeCallAction().validate(runtime, message) is False

    def test_validate_returns_false_no_call_intent(self) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message("SMS +18885551234")
        assert MakeCallAction().validate(runtime, message) is False

    @pytest.mark.asyncio
    async def test_handler_makes_call(self) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message("Call +18885551234 and say 'Hello!'")
        callback = MagicMock()

        await MakeCallAction().handler(runtime, message, callback=callback)

        service.make_call.assert_called_once()
        callback.assert_called_once()
        assert callback.call_args[0][0]["success"] is True

    @pytest.mark.asyncio
    async def test_handler_error(self) -> None:
        service = _make_twilio_service()
        service.make_call = AsyncMock(side_effect=Exception("API Error"))
        runtime = _make_runtime(service)
        message = _make_message("Call +18885551234")
        callback = MagicMock()

        await MakeCallAction().handler(runtime, message, callback=callback)

        callback.assert_called_once()
        assert callback.call_args[0][0]["success"] is False


# --- SendMmsAction tests ---


class TestSendMmsAction:
    """Tests for SEND_MMS action."""

    def test_metadata(self) -> None:
        action = SendMmsAction()
        assert action.name == "SEND_MMS"
        assert "send mms" in action.similes
        assert len(action.examples) > 0

    def test_validate_with_media_intent(self) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message("Send image to +18885551234")
        assert SendMmsAction().validate(runtime, message) is True

    def test_validate_with_url(self) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message("Send +18885551234 https://example.com/photo.jpg")
        assert SendMmsAction().validate(runtime, message) is True

    def test_validate_returns_false_no_media_intent(self) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message("Text +18885551234 hello")
        assert SendMmsAction().validate(runtime, message) is False

    @pytest.mark.asyncio
    async def test_handler_sends_mms(self) -> None:
        service = _make_twilio_service()
        runtime = _make_runtime(service)
        message = _make_message(
            "Send MMS to +18885551234 with https://example.com/photo.jpg"
        )
        callback = MagicMock()

        await SendMmsAction().handler(runtime, message, callback=callback)

        service.send_sms.assert_called_once()
        call_args = service.send_sms.call_args
        assert "https://example.com/photo.jpg" in call_args[0][2]  # media_urls
        callback.assert_called_once()
        assert callback.call_args[0][0]["success"] is True
