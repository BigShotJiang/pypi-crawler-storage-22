"""Tests for CallManager state machine and lifecycle management."""

from __future__ import annotations

import pytest

from elizaos_plugin_twilio.call_manager import CallManager, CallManagerSettings
from elizaos_plugin_twilio.types import CallState, NormalizedEvent


def _make_settings(**overrides: object) -> CallManagerSettings:
    defaults = {
        "provider": "twilio",
        "from_number": "+18885550000",
        "max_concurrent_calls": 10,
        "max_duration_seconds": 3600,
        "transcript_timeout_ms": 30000,
        "inbound_policy": "open",
    }
    defaults.update(overrides)
    return CallManagerSettings(**defaults)


def _make_event(
    event_id: str = "evt1",
    event_type: str = "call.initiated",
    call_id: str = "call-1",
    **kwargs: object,
) -> NormalizedEvent:
    import time

    defaults: dict[str, object] = {
        "id": event_id,
        "type": event_type,
        "call_id": call_id,
        "timestamp": time.time() * 1000,
    }
    defaults.update(kwargs)
    return NormalizedEvent(**defaults)


class TestCallManagerCreateOutboundCall:
    """Tests for creating outbound calls."""

    def test_creates_outbound_call(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, record = mgr.create_outbound_call("+18885551234")

        assert call_id is not None
        assert record.direction == "outbound"
        assert record.state == "initiated"
        assert record.to == "+18885551234"
        assert record.from_ == "+18885550000"

    def test_creates_with_message(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, record = mgr.create_outbound_call("+18885551234", message="Hello")
        assert record.metadata is not None
        assert record.metadata.get("initialMessage") == "Hello"

    def test_creates_with_mode(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, record = mgr.create_outbound_call(
            "+18885551234", mode="conversation"
        )
        assert record.metadata is not None
        assert record.metadata.get("mode") == "conversation"


class TestCallManagerCreateInboundCall:
    """Tests for creating inbound calls."""

    def test_creates_inbound_call(self) -> None:
        mgr = CallManager(_make_settings())
        record = mgr.create_inbound_call("PROV123", "+18885551234", "+18885550000")

        assert record.direction == "inbound"
        assert record.state == "ringing"
        assert record.provider_call_id == "PROV123"

    def test_inbound_call_accessible_by_provider_id(self) -> None:
        mgr = CallManager(_make_settings())
        record = mgr.create_inbound_call("PROV123", "+18885551234", "+18885550000")

        found = mgr.get_call_by_provider_id("PROV123")
        assert found is not None
        assert found.call_id == record.call_id


class TestCallManagerStateMachine:
    """Tests for state machine transitions."""

    def test_forward_transition(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, record = mgr.create_outbound_call("+18885551234")

        mgr.update_state(call_id, "ringing")
        assert mgr.get_call(call_id).state == "ringing"

        mgr.update_state(call_id, "answered")
        assert mgr.get_call(call_id).state == "answered"

    def test_no_backward_transition(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        mgr.update_state(call_id, "answered")
        mgr.update_state(call_id, "ringing")  # Should not go backwards
        assert mgr.get_call(call_id).state == "answered"

    def test_conversation_state_transitions(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        mgr.update_state(call_id, "speaking")
        assert mgr.get_call(call_id).state == "speaking"

        mgr.update_state(call_id, "listening")
        assert mgr.get_call(call_id).state == "listening"

        mgr.update_state(call_id, "speaking")
        assert mgr.get_call(call_id).state == "speaking"

    def test_terminal_state_is_final(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        mgr.update_state(call_id, "answered")
        mgr.mark_ended(call_id, "completed")

        # Call should be in history now, not active
        assert mgr.get_call(call_id) is None
        history = mgr.get_call_history()
        assert len(history) == 1
        assert history[0].state == "completed"

    def test_transition_to_terminal_from_any_state(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")
        mgr.update_state(call_id, "ringing")
        mgr.mark_ended(call_id, "failed")

        assert mgr.get_call(call_id) is None
        history = mgr.get_call_history()
        assert history[0].end_reason == "failed"


class TestCallManagerTranscript:
    """Tests for transcript tracking."""

    def test_add_transcript_entry(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        mgr.add_transcript_entry(call_id, "bot", "Hello!")
        mgr.add_transcript_entry(call_id, "user", "Hi there")

        call = mgr.get_call(call_id)
        assert len(call.transcript) == 2
        assert call.transcript[0].speaker == "bot"
        assert call.transcript[0].text == "Hello!"
        assert call.transcript[1].speaker == "user"


class TestCallManagerConcurrency:
    """Tests for concurrent call limits."""

    def test_max_concurrent_calls(self) -> None:
        mgr = CallManager(_make_settings(max_concurrent_calls=2))

        mgr.create_outbound_call("+18885551111")
        mgr.create_outbound_call("+18885552222")

        assert mgr.is_at_max_concurrent_calls() is True

    def test_not_at_max(self) -> None:
        mgr = CallManager(_make_settings(max_concurrent_calls=10))
        mgr.create_outbound_call("+18885551111")
        assert mgr.is_at_max_concurrent_calls() is False


class TestCallManagerEventProcessing:
    """Tests for webhook event processing."""

    def test_process_initiated_event(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        event = _make_event(call_id=call_id, event_type="call.initiated")
        result = mgr.process_event(event)

        assert result is not None
        assert result.state == "initiated"

    def test_deduplicate_events(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        event = _make_event(event_id="evt1", call_id=call_id)
        result1 = mgr.process_event(event)
        result2 = mgr.process_event(event)

        assert result1 is not None
        assert result2 is None  # Deduplicated

    def test_process_speech_event(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        event = _make_event(
            call_id=call_id,
            event_type="call.speech",
            is_final=True,
            transcript="Hello there",
        )
        result = mgr.process_event(event)

        assert result is not None
        assert len(result.transcript) == 1
        assert result.transcript[0].text == "Hello there"

    def test_process_ended_event(self) -> None:
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        event = _make_event(
            call_id=call_id,
            event_type="call.ended",
            reason="completed",
        )
        mgr.process_event(event)

        assert mgr.get_call(call_id) is None
        history = mgr.get_call_history()
        assert len(history) == 1

    def test_process_inbound_call_event(self) -> None:
        mgr = CallManager(_make_settings())

        event = _make_event(
            call_id="new-inbound",
            event_type="call.initiated",
            direction="inbound",
            provider_call_id="PROV_IN_1",
            **{"from": "+18885559999"},
            to="+18885550000",
        )
        result = mgr.process_event(event)

        assert result is not None
        assert result.direction == "inbound"

    def test_inbound_rejected_when_disabled(self) -> None:
        mgr = CallManager(_make_settings(inbound_policy="disabled"))

        event = _make_event(
            call_id="new-inbound",
            event_type="call.initiated",
            direction="inbound",
            provider_call_id="PROV_IN_2",
        )
        result = mgr.process_event(event)
        assert result is None


class TestCallManagerHistory:
    """Tests for call history."""

    def test_get_call_history(self) -> None:
        mgr = CallManager(_make_settings())

        for i in range(3):
            call_id, _ = mgr.create_outbound_call(f"+1888555{i:04d}")
            mgr.mark_ended(call_id, "completed")

        history = mgr.get_call_history()
        assert len(history) == 3
        # Most recent first
        assert history[0].to.endswith("0002")

    def test_history_limited(self) -> None:
        mgr = CallManager(_make_settings())

        for i in range(5):
            call_id, _ = mgr.create_outbound_call(f"+1888555{i:04d}")
            mgr.mark_ended(call_id, "completed")

        history = mgr.get_call_history(limit=2)
        assert len(history) == 2

    def test_get_active_calls(self) -> None:
        mgr = CallManager(_make_settings())
        mgr.create_outbound_call("+18885551111")
        mgr.create_outbound_call("+18885552222")

        active = mgr.get_active_calls()
        assert len(active) == 2


# ---------------------------------------------------------------------------
# Deep tests: Untested State Transitions
# ---------------------------------------------------------------------------


class TestCallManagerStateTransitionsDeep:
    """Deep tests for state transition edge cases."""

    def test_backward_state_transition_blocked(self) -> None:
        """speaking -> ringing must be blocked (backward transition)."""
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        mgr.update_state(call_id, "speaking")
        assert mgr.get_call(call_id).state == "speaking"

        # Attempt backward transition: speaking (idx 4) -> ringing (idx 1)
        mgr.update_state(call_id, "ringing")
        assert mgr.get_call(call_id).state == "speaking"  # unchanged

    def test_active_to_speaking_transition(self) -> None:
        """active -> speaking is a valid forward transition."""
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        mgr.update_state(call_id, "active")
        assert mgr.get_call(call_id).state == "active"

        mgr.update_state(call_id, "speaking")
        assert mgr.get_call(call_id).state == "speaking"

    def test_mark_answered_sets_timestamp(self) -> None:
        """mark_answered must set answered_at and transition to 'answered'."""
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        assert mgr.get_call(call_id).answered_at is None

        mgr.mark_answered(call_id)
        call = mgr.get_call(call_id)

        assert call.state == "answered"
        assert call.answered_at is not None
        assert isinstance(call.answered_at, float)
        assert call.answered_at > 0

    def test_update_provider_call_id_removes_old_mapping(self) -> None:
        """Updating provider call ID must evict the old ID from the lookup map."""
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        mgr.update_provider_call_id(call_id, "PROV_OLD")
        assert mgr.get_call_by_provider_id("PROV_OLD") is not None
        assert mgr.get_call_by_provider_id("PROV_OLD").call_id == call_id

        mgr.update_provider_call_id(call_id, "PROV_NEW")

        # Old mapping gone
        assert mgr.get_call_by_provider_id("PROV_OLD") is None
        # New mapping works
        assert mgr.get_call_by_provider_id("PROV_NEW") is not None
        assert mgr.get_call_by_provider_id("PROV_NEW").call_id == call_id
        assert mgr.get_call(call_id).provider_call_id == "PROV_NEW"


# ---------------------------------------------------------------------------
# Deep tests: Boundary Conditions
# ---------------------------------------------------------------------------


class TestCallManagerBoundaryConditions:
    """Boundary condition tests for CallManager."""

    def test_transcript_with_empty_text(self) -> None:
        """Adding a transcript entry with empty text must still be recorded."""
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        mgr.add_transcript_entry(call_id, "user", "")

        call = mgr.get_call(call_id)
        assert len(call.transcript) == 1
        assert call.transcript[0].text == ""
        assert call.transcript[0].speaker == "user"
        assert call.transcript[0].is_final is True

    def test_transcript_on_nonexistent_call(self) -> None:
        """Adding a transcript to a nonexistent call must be a silent no-op."""
        mgr = CallManager(_make_settings())

        # Should not raise
        mgr.add_transcript_entry("nonexistent-id", "bot", "Hello")

        assert mgr.get_call("nonexistent-id") is None
        assert len(mgr.get_active_calls()) == 0

    def test_mark_ended_on_already_ended_call(self) -> None:
        """Ending an already-ended call must be a no-op (no duplicate history)."""
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        mgr.mark_ended(call_id, "completed")
        assert mgr.get_call(call_id) is None
        assert len(mgr.get_call_history()) == 1

        # Second call is a no-op — call is no longer in _active_calls
        mgr.mark_ended(call_id, "failed")
        assert len(mgr.get_call_history()) == 1
        assert mgr.get_call_history()[0].end_reason == "completed"

    def test_concurrent_calls_at_max_then_end_one(self) -> None:
        """Ending one call at max capacity must decrease active count."""
        mgr = CallManager(_make_settings(max_concurrent_calls=2))

        call_id1, _ = mgr.create_outbound_call("+18885551111")
        call_id2, _ = mgr.create_outbound_call("+18885552222")

        assert mgr.is_at_max_concurrent_calls() is True
        assert len(mgr.get_active_calls()) == 2

        mgr.mark_ended(call_id1, "completed")

        assert mgr.is_at_max_concurrent_calls() is False
        assert len(mgr.get_active_calls()) == 1
        assert mgr.get_call(call_id2) is not None
        assert mgr.get_call(call_id1) is None


# ---------------------------------------------------------------------------
# Deep tests: Event Processing
# ---------------------------------------------------------------------------


class TestCallManagerEventProcessingDeep:
    """Deep tests for event processing paths."""

    def test_process_event_call_active(self) -> None:
        """call.active event must transition to 'active' state."""
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        event = _make_event(
            event_id="evt-active",
            call_id=call_id,
            event_type="call.active",
        )
        result = mgr.process_event(event)

        assert result is not None
        assert result.state == "active"
        assert mgr.get_call(call_id).state == "active"

    def test_process_event_call_ringing(self) -> None:
        """call.ringing event must transition to 'ringing' state."""
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        event = _make_event(
            event_id="evt-ring",
            call_id=call_id,
            event_type="call.ringing",
        )
        result = mgr.process_event(event)

        assert result is not None
        assert result.state == "ringing"
        assert mgr.get_call(call_id).state == "ringing"

    def test_process_event_call_speaking(self) -> None:
        """call.speaking event must transition to 'speaking' state."""
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        event = _make_event(
            event_id="evt-speak",
            call_id=call_id,
            event_type="call.speaking",
        )
        result = mgr.process_event(event)

        assert result is not None
        assert result.state == "speaking"
        assert mgr.get_call(call_id).state == "speaking"

    def test_process_event_call_error_retryable(self) -> None:
        """Retryable error must NOT end the call."""
        mgr = CallManager(_make_settings())
        call_id, _ = mgr.create_outbound_call("+18885551234")

        event = _make_event(
            event_id="evt-err-retry",
            call_id=call_id,
            event_type="call.error",
            retryable=True,
            error="Temporary network failure",
        )
        result = mgr.process_event(event)

        assert result is not None
        # Call must still be active, not moved to history
        assert mgr.get_call(call_id) is not None
        assert mgr.get_call(call_id).state == "initiated"
        assert len(mgr.get_call_history()) == 0
        assert "evt-err-retry" in result.processed_event_ids

    def test_process_event_unknown_call_id(self) -> None:
        """Event for an unknown call (non-inbound) must return None."""
        mgr = CallManager(_make_settings())

        event = _make_event(
            event_id="evt-unknown",
            call_id="nonexistent-call-id",
            event_type="call.active",
        )
        result = mgr.process_event(event)

        assert result is None
        assert len(mgr.get_active_calls()) == 0


# ---------------------------------------------------------------------------
# Deep tests: Inbound Policy
# ---------------------------------------------------------------------------


class TestCallManagerPolicyDeep:
    """Deep tests for inbound call acceptance policies."""

    def test_should_accept_inbound_pairing_policy(self) -> None:
        """Pairing policy must accept calls from numbers in allow_from."""
        mgr = CallManager(_make_settings(
            inbound_policy="pairing",
            allow_from=["+18885551234"],
        ))

        event = _make_event(
            event_id="evt-pair",
            call_id="inbound-pair",
            event_type="call.initiated",
            direction="inbound",
            provider_call_id="PROV_PAIR_1",
            **{"from": "+18885551234"},
            to="+18885550000",
        )
        result = mgr.process_event(event)

        assert result is not None
        assert result.direction == "inbound"
        assert result.from_ == "+18885551234"

    def test_should_accept_inbound_partial_matching(self) -> None:
        """Pairing policy must accept via suffix-based partial matching."""
        mgr = CallManager(_make_settings(
            inbound_policy="pairing",
            allow_from=["+18885551234"],
        ))

        # From number without country-code prefix — allowed because
        # "+18885551234".endswith("8885551234") is True
        event = _make_event(
            event_id="evt-partial",
            call_id="inbound-partial",
            event_type="call.initiated",
            direction="inbound",
            provider_call_id="PROV_PART_1",
            **{"from": "8885551234"},
            to="+18885550000",
        )
        result = mgr.process_event(event)

        assert result is not None
        assert result.direction == "inbound"
        assert result.from_ == "8885551234"
