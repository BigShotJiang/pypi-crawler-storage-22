"""Tests for Twilio plugin providers."""

from __future__ import annotations

from datetime import datetime
from unittest.mock import MagicMock

from elizaos_plugin_twilio.providers.call_state import CallStateProvider
from elizaos_plugin_twilio.providers.conversation_history import ConversationHistoryProvider


def _make_runtime(service: MagicMock | None) -> MagicMock:
    runtime = MagicMock()
    runtime.get_service = MagicMock(return_value=service)
    return runtime


def _make_message(text: str = "test", phone_number: str | None = None) -> MagicMock:
    msg = MagicMock()
    msg.content.text = text
    msg.content.phoneNumber = phone_number
    msg.content.phone_number = phone_number
    return msg


# --- CallStateProvider tests ---


class TestCallStateProvider:
    """Tests for call state provider."""

    def test_metadata(self) -> None:
        provider = CallStateProvider()
        assert provider.name == "twilioCallState"
        assert "active voice calls" in provider.description.lower()

    def test_active_calls(self) -> None:
        service = MagicMock()
        service.voice_streams = {
            "CA123": {"streamSid": "ST123", "from": "+18885551234", "to": "+18885555678"},
            "CA456": {"streamSid": "ST456", "from": "+18885555678", "to": "+18885551234"},
        }
        runtime = _make_runtime(service)
        message = _make_message()

        result = CallStateProvider().get(runtime, message)
        assert "Active voice calls (2):" in result["text"]
        assert "CA123" in result["text"]
        assert result["data"]["activeCallCount"] == 2

    def test_no_active_calls(self) -> None:
        service = MagicMock()
        service.voice_streams = {}
        runtime = _make_runtime(service)
        message = _make_message()

        result = CallStateProvider().get(runtime, message)
        assert result["text"] == "No active voice calls"
        assert result["data"]["activeCallCount"] == 0

    def test_service_not_initialized(self) -> None:
        runtime = _make_runtime(None)
        message = _make_message()

        result = CallStateProvider().get(runtime, message)
        assert "not initialized" in result["text"]

    def test_error_handling(self) -> None:
        service = MagicMock()
        type(service).voice_streams = property(
            lambda self: (_ for _ in ()).throw(RuntimeError("fail"))
        )
        runtime = _make_runtime(service)
        message = _make_message()

        result = CallStateProvider().get(runtime, message)
        assert result["text"] == "Error retrieving call state"


# --- ConversationHistoryProvider tests ---


class TestConversationHistoryProvider:
    """Tests for conversation history provider."""

    def test_metadata(self) -> None:
        provider = ConversationHistoryProvider()
        assert provider.name == "twilioConversationHistory"
        assert "conversation history" in provider.description.lower()

    def test_returns_history(self) -> None:
        msg1 = MagicMock(
            direction="inbound",
            date_created=datetime(2024, 1, 1, 10, 0, 0),
            body="Hello",
        )
        msg2 = MagicMock(
            direction="outbound",
            date_created=datetime(2024, 1, 1, 10, 1, 0),
            body="Hi there",
        )
        service = MagicMock()
        service.get_conversation_history = MagicMock(return_value=[msg1, msg2])
        runtime = _make_runtime(service)
        message = _make_message(phone_number="+18885551234")

        result = ConversationHistoryProvider().get(runtime, message)
        assert "Recent SMS conversation with +18885551234:" in result["text"]
        assert "From +18885551234: Hello" in result["text"]
        assert "To +18885551234: Hi there" in result["text"]
        assert result["data"]["messageCount"] == 2

    def test_extracts_phone_from_text(self) -> None:
        service = MagicMock()
        service.get_conversation_history = MagicMock(return_value=[])
        runtime = _make_runtime(service)
        message = _make_message(text="Show me messages with +18885551234")

        result = ConversationHistoryProvider().get(runtime, message)
        assert "No recent conversation history with +18885551234" in result["text"]
        service.get_conversation_history.assert_called_with("+18885551234", 10)

    def test_service_not_initialized(self) -> None:
        runtime = _make_runtime(None)
        message = _make_message(phone_number="+18885551234")

        result = ConversationHistoryProvider().get(runtime, message)
        assert "not initialized" in result["text"]

    def test_string_content(self) -> None:
        service = MagicMock()
        runtime = _make_runtime(service)
        msg = MagicMock()
        msg.content = "Just a string"

        result = ConversationHistoryProvider().get(runtime, msg)
        assert result["text"] == "No phone number found in context"

    def test_no_phone_number(self) -> None:
        service = MagicMock()
        runtime = _make_runtime(service)
        message = _make_message(text="No phone number here")

        result = ConversationHistoryProvider().get(runtime, message)
        assert result["text"] == "No phone number found in context"

    def test_empty_history(self) -> None:
        service = MagicMock()
        service.get_conversation_history = MagicMock(return_value=[])
        runtime = _make_runtime(service)
        message = _make_message(phone_number="+18885551234")

        result = ConversationHistoryProvider().get(runtime, message)
        assert "No recent conversation history" in result["text"]

    def test_error_handling(self) -> None:
        service = MagicMock()
        service.get_conversation_history = MagicMock(side_effect=RuntimeError("fail"))
        runtime = _make_runtime(service)
        message = _make_message(phone_number="+18885551234")

        result = ConversationHistoryProvider().get(runtime, message)
        assert result["text"] == "Error retrieving conversation history"
