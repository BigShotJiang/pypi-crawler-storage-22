"""Tests for TwilioService (mock Twilio SDK)."""

from __future__ import annotations

from datetime import datetime
from unittest.mock import MagicMock

import pytest

from elizaos_plugin_twilio.error import TwilioApiError, TwilioConfigError, TwilioError
from elizaos_plugin_twilio.service import TwilioService
from elizaos_plugin_twilio.types import TwilioConfig


def _make_config(**overrides: str) -> TwilioConfig:
    defaults = {
        "account_sid": "AC123",
        "auth_token": "auth123",
        "phone_number": "+18885550000",
        "webhook_url": "https://example.com",
        "webhook_port": 3000,
    }
    defaults.update(overrides)
    return TwilioConfig(**defaults)


def _mock_twilio_client() -> MagicMock:
    client = MagicMock()
    client.messages = MagicMock()
    client.calls = MagicMock()
    return client


class TestTwilioServiceInitialization:
    """Tests for TwilioService initialization."""

    @pytest.mark.asyncio
    async def test_initialize_successfully(self) -> None:
        service = TwilioService()
        mock_client = _mock_twilio_client()
        await service.initialize(_make_config(), client=mock_client)
        assert service.is_connected is True
        assert service.phone_number == "+18885550000"

    @pytest.mark.asyncio
    async def test_throw_error_missing_credentials(self) -> None:
        service = TwilioService()
        with pytest.raises(TwilioConfigError):
            await service.initialize(
                _make_config(account_sid=""),
                client=_mock_twilio_client(),
            )

    @pytest.mark.asyncio
    async def test_duplicate_initialization(self) -> None:
        service = TwilioService()
        mock_client = _mock_twilio_client()
        await service.initialize(_make_config(), client=mock_client)
        await service.initialize(_make_config(), client=mock_client)
        assert service.is_connected is True

    @pytest.mark.asyncio
    async def test_missing_phone_number(self) -> None:
        service = TwilioService()
        with pytest.raises(TwilioConfigError):
            await service.initialize(
                _make_config(phone_number=""),
                client=_mock_twilio_client(),
            )


class TestTwilioServiceSendSms:
    """Tests for TwilioService.send_sms."""

    @pytest.fixture
    async def service(self) -> TwilioService:
        svc = TwilioService()
        mock_client = _mock_twilio_client()
        mock_client.messages.create.return_value = MagicMock(
            sid="SM123",
            from_="+18885550000",
            to="+18885551234",
            body="Test message",
            status="sent",
            date_created=datetime.now(),
            date_sent=None,
        )
        await svc.initialize(_make_config(), client=mock_client)
        return svc

    @pytest.mark.asyncio
    async def test_send_sms_successfully(self, service: TwilioService) -> None:
        result = await service.send_sms("+18885551234", "Test message")
        assert result.sid == "SM123"
        assert result.body == "Test message"

    @pytest.mark.asyncio
    async def test_send_mms_with_media(self, service: TwilioService) -> None:
        result = await service.send_sms(
            "+18885551234",
            "Test MMS",
            media_url=["https://example.com/image.jpg"],
        )
        assert result.sid == "SM123"

    @pytest.mark.asyncio
    async def test_invalid_phone_number(self, service: TwilioService) -> None:
        with pytest.raises(TwilioError):
            await service.send_sms("invalid", "Test")

    @pytest.mark.asyncio
    async def test_api_error(self) -> None:
        svc = TwilioService()
        mock_client = _mock_twilio_client()
        mock_client.messages.create.side_effect = Exception("API Error")
        await svc.initialize(_make_config(), client=mock_client)
        with pytest.raises(TwilioApiError):
            await svc.send_sms("+18885551234", "Test")


class TestTwilioServiceMakeCall:
    """Tests for TwilioService.make_call."""

    @pytest.fixture
    async def service(self) -> TwilioService:
        svc = TwilioService()
        mock_client = _mock_twilio_client()
        mock_client.calls.create.return_value = MagicMock(
            sid="CA123",
            from_="+18885550000",
            to="+18885551234",
            status="initiated",
            date_created=datetime.now(),
        )
        await svc.initialize(_make_config(), client=mock_client)
        return svc

    @pytest.mark.asyncio
    async def test_make_call_with_twiml(self, service: TwilioService) -> None:
        twiml = "<Response><Say>Hello</Say></Response>"
        result = await service.make_call("+18885551234", twiml)
        assert result.sid == "CA123"

    @pytest.mark.asyncio
    async def test_make_call_default_twiml(self, service: TwilioService) -> None:
        result = await service.make_call("+18885551234")
        assert result.sid == "CA123"

    @pytest.mark.asyncio
    async def test_make_call_invalid_number(self, service: TwilioService) -> None:
        with pytest.raises(TwilioError):
            await service.make_call("invalid")

    @pytest.mark.asyncio
    async def test_make_call_api_error(self) -> None:
        svc = TwilioService()
        mock_client = _mock_twilio_client()
        mock_client.calls.create.side_effect = Exception("API Error")
        await svc.initialize(_make_config(), client=mock_client)
        with pytest.raises(TwilioApiError):
            await svc.make_call("+18885551234")


class TestTwilioServiceConversationHistory:
    """Tests for conversation history caching."""

    @pytest.fixture
    async def service(self) -> TwilioService:
        svc = TwilioService()
        mock_client = _mock_twilio_client()
        mock_client.messages.create.return_value = MagicMock(
            sid="SM123",
            from_="+18885550000",
            to="+18885551234",
            body="Test",
            status="sent",
            date_created=datetime.now(),
            date_sent=None,
        )
        await svc.initialize(_make_config(), client=mock_client)
        return svc

    @pytest.mark.asyncio
    async def test_returns_conversation_history(self, service: TwilioService) -> None:
        await service.send_sms("+18885551234", "Test")
        history = service.get_conversation_history("+18885551234")
        assert len(history) == 1
        assert history[0].body == "Test"

    def test_returns_empty_for_no_history(self) -> None:
        svc = TwilioService()
        history = svc.get_conversation_history("+18885559999")
        assert history == []

    @pytest.mark.asyncio
    async def test_limits_history(self, service: TwilioService) -> None:
        for i in range(5):
            service._client.messages.create.return_value = MagicMock(
                sid=f"SM{i}",
                from_="+18885550000",
                to="+18885551234",
                body=f"Message {i}",
                status="sent",
                date_created=datetime.now(),
                date_sent=None,
            )
            await service.send_sms("+18885551234", f"Message {i}")

        history = service.get_conversation_history("+18885551234", 3)
        assert len(history) == 3
        assert history[0].body == "Message 2"


class TestTwilioServiceCallState:
    """Tests for call state caching."""

    @pytest.fixture
    async def service(self) -> TwilioService:
        svc = TwilioService()
        mock_client = _mock_twilio_client()
        mock_client.calls.create.return_value = MagicMock(
            sid="CA123",
            from_="+18885550000",
            to="+18885551234",
            status="initiated",
            date_created=datetime.now(),
        )
        await svc.initialize(_make_config(), client=mock_client)
        return svc

    @pytest.mark.asyncio
    async def test_returns_call_state(self, service: TwilioService) -> None:
        await service.make_call("+18885551234")
        call_state = service.get_call_state("CA123")
        assert call_state is not None
        assert call_state.sid == "CA123"

    def test_returns_none_for_unknown_call(self) -> None:
        svc = TwilioService()
        assert svc.get_call_state("CA999") is None


class TestTwilioServiceCleanup:
    """Tests for TwilioService cleanup."""

    @pytest.mark.asyncio
    async def test_cleanup_resources(self) -> None:
        service = TwilioService()
        await service.initialize(_make_config(), client=_mock_twilio_client())
        await service.cleanup()
        assert service.is_connected is False
