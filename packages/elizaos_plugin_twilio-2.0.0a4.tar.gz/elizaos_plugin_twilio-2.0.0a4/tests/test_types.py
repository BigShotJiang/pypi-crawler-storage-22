"""Tests for Twilio plugin type construction and validation."""

from __future__ import annotations

from datetime import datetime

import pytest
from pydantic import ValidationError

from elizaos_plugin_twilio.types import (
    CONVERSATION_STATES,
    STATE_ORDER,
    TERMINAL_STATES,
    CacheKeys,
    CallDirection,
    CallMode,
    CallRecord,
    CallState,
    E164_REGEX,
    MESSAGING_REGEX,
    MakeCallParams,
    NormalizedEvent,
    SendMmsParams,
    SendSmsParams,
    TranscriptEntry,
    TwilioCall,
    TwilioConfig,
    TwilioEventType,
    TwilioMedia,
    TwilioMessage,
    TwilioSmsWebhook,
    TwilioStatusWebhook,
    TwilioVoiceStream,
    TwilioVoiceWebhook,
)


# --- Regex patterns ---


class TestRegexPatterns:
    """Tests for E164 and messaging regex patterns."""

    @pytest.mark.parametrize("number", ["+18885551234", "+442071234567", "+12", "+123456789012345"])
    def test_e164_regex_valid(self, number: str) -> None:
        assert E164_REGEX.match(number)

    @pytest.mark.parametrize("number", [
        "18885551234", "+0123456789", "+1234567890123456", "", "whatsapp:+18885551234",
    ])
    def test_e164_regex_invalid(self, number: str) -> None:
        assert not E164_REGEX.match(number)

    def test_messaging_regex_valid(self) -> None:
        assert MESSAGING_REGEX.match("+18885551234")
        assert MESSAGING_REGEX.match("whatsapp:+18885551234")

    def test_messaging_regex_invalid(self) -> None:
        assert not MESSAGING_REGEX.match("8885551234")
        assert not MESSAGING_REGEX.match("whatsapp:8885551234")
        assert not MESSAGING_REGEX.match("+0123456789")


# --- TwilioMedia ---


class TestTwilioMedia:
    """Tests for TwilioMedia model."""

    def test_construct_media(self) -> None:
        media = TwilioMedia(
            content_type="image/jpeg",
            url="https://example.com/photo.jpg",
            sid="ME001",
        )
        assert media.content_type == "image/jpeg"
        assert media.url == "https://example.com/photo.jpg"
        assert media.sid == "ME001"

    def test_construct_from_dict(self) -> None:
        data = {"content_type": "video/mp4", "url": "https://x.com/v.mp4", "sid": "ME002"}
        media = TwilioMedia(**data)
        assert media.content_type == "video/mp4"


# --- TwilioMessage ---


class TestTwilioMessage:
    """Tests for TwilioMessage model."""

    def test_construct_minimal(self) -> None:
        msg = TwilioMessage(
            sid="SM001",
            **{"from": "+18885551234"},
            to="+18885550000",
            body="Hello",
            direction="inbound",
            status="received",
            date_created=datetime(2025, 1, 1),
        )
        assert msg.sid == "SM001"
        assert msg.from_ == "+18885551234"
        assert msg.to == "+18885550000"
        assert msg.body == "Hello"
        assert msg.direction == "inbound"
        assert msg.media is None
        assert msg.date_sent is None

    def test_construct_with_media(self) -> None:
        media = TwilioMedia(content_type="image/png", url="https://x.com/img.png", sid="ME1")
        msg = TwilioMessage(
            sid="SM002",
            **{"from": "+18885550000"},
            to="+18885551234",
            body="See attached",
            media=[media],
            direction="outbound",
            status="sent",
            date_created=datetime(2025, 1, 1),
            date_sent=datetime(2025, 1, 1, 0, 0, 1),
        )
        assert len(msg.media) == 1
        assert msg.media[0].content_type == "image/png"
        assert msg.date_sent is not None

    def test_populate_by_name(self) -> None:
        """Test that from_ field works with populate_by_name."""
        msg = TwilioMessage(
            sid="SM003",
            from_="+18885551111",
            to="+18885552222",
            body="Test",
            direction="outbound",
            status="sent",
            date_created=datetime(2025, 1, 1),
        )
        assert msg.from_ == "+18885551111"


# --- TwilioCall ---


class TestTwilioCall:
    """Tests for TwilioCall model."""

    def test_construct_outbound_call(self) -> None:
        call = TwilioCall(
            sid="CA001",
            **{"from": "+18885550000"},
            to="+18885551234",
            status="initiated",
            direction="outbound",
            date_created=datetime(2025, 1, 1),
        )
        assert call.sid == "CA001"
        assert call.from_ == "+18885550000"
        assert call.direction == "outbound"
        assert call.duration is None
        assert call.date_ended is None

    def test_construct_with_duration(self) -> None:
        call = TwilioCall(
            sid="CA002",
            **{"from": "+18885551234"},
            to="+18885550000",
            status="completed",
            direction="inbound",
            duration=120,
            date_created=datetime(2025, 1, 1),
            date_ended=datetime(2025, 1, 1, 0, 2, 0),
        )
        assert call.duration == 120
        assert call.date_ended is not None

    def test_populate_by_name(self) -> None:
        call = TwilioCall(
            sid="CA003",
            from_="+18885550000",
            to="+18885551234",
            status="ringing",
            direction="outbound",
            date_created=datetime(2025, 1, 1),
        )
        assert call.from_ == "+18885550000"


# --- TwilioVoiceStream ---


class TestTwilioVoiceStream:
    """Tests for TwilioVoiceStream model."""

    def test_construct_voice_stream(self) -> None:
        stream = TwilioVoiceStream(
            stream_sid="MZ001",
            call_sid="CA001",
            **{"from": "+18885551234"},
            to="+18885550000",
        )
        assert stream.stream_sid == "MZ001"
        assert stream.call_sid == "CA001"
        assert stream.from_ == "+18885551234"
        assert stream.socket is None


# --- Webhook types ---


class TestWebhookTypes:
    """Tests for webhook payload models."""

    def test_sms_webhook(self) -> None:
        webhook = TwilioSmsWebhook(
            MessageSid="SM001",
            From="+18885551234",
            To="+18885550000",
            Body="Hello",
            NumMedia="2",
        )
        assert webhook.MessageSid == "SM001"
        assert webhook.NumMedia == "2"

    def test_sms_webhook_no_media(self) -> None:
        webhook = TwilioSmsWebhook(
            MessageSid="SM002",
            From="+18885551234",
            To="+18885550000",
            Body="Hi",
        )
        assert webhook.NumMedia is None

    def test_voice_webhook(self) -> None:
        webhook = TwilioVoiceWebhook(
            CallSid="CA001",
            From="+18885551234",
            To="+18885550000",
            CallStatus="ringing",
        )
        assert webhook.CallSid == "CA001"
        assert webhook.CallStatus == "ringing"
        assert webhook.Direction is None

    def test_voice_webhook_with_direction(self) -> None:
        webhook = TwilioVoiceWebhook(
            CallSid="CA002",
            From="+18885551234",
            To="+18885550000",
            CallStatus="in-progress",
            Direction="inbound",
        )
        assert webhook.Direction == "inbound"

    def test_status_webhook_sms(self) -> None:
        webhook = TwilioStatusWebhook(
            MessageSid="SM001",
            MessageStatus="delivered",
            To="+18885551234",
            From="+18885550000",
        )
        assert webhook.MessageSid == "SM001"
        assert webhook.MessageStatus == "delivered"
        assert webhook.CallSid is None

    def test_status_webhook_call(self) -> None:
        webhook = TwilioStatusWebhook(
            CallSid="CA001",
            CallStatus="completed",
        )
        assert webhook.CallSid == "CA001"
        assert webhook.CallStatus == "completed"
        assert webhook.MessageSid is None

    def test_status_webhook_error(self) -> None:
        webhook = TwilioStatusWebhook(
            MessageSid="SM001",
            ErrorCode="30007",
            ErrorMessage="Message filtering",
        )
        assert webhook.ErrorCode == "30007"
        assert webhook.ErrorMessage == "Message filtering"

    def test_status_webhook_empty(self) -> None:
        webhook = TwilioStatusWebhook()
        assert webhook.MessageSid is None
        assert webhook.CallSid is None


# --- TwilioConfig ---


class TestTwilioConfig:
    """Tests for TwilioConfig model."""

    def test_construct_full(self) -> None:
        config = TwilioConfig(
            account_sid="AC123",
            auth_token="token",
            phone_number="+18885550000",
            webhook_url="https://example.com",
            webhook_port=8080,
        )
        assert config.account_sid == "AC123"
        assert config.webhook_port == 8080

    def test_defaults(self) -> None:
        config = TwilioConfig(
            account_sid="AC123",
            auth_token="token",
            phone_number="+18885550000",
        )
        assert config.webhook_url == ""
        assert config.webhook_port == 3000


# --- Validation schemas ---


class TestSendSmsParams:
    """Tests for SendSmsParams validation."""

    def test_valid_params(self) -> None:
        params = SendSmsParams(to="+18885551234", message="Hello")
        assert params.to == "+18885551234"
        assert params.message == "Hello"
        assert params.media_url is None

    def test_valid_with_media(self) -> None:
        params = SendSmsParams(
            to="+18885551234",
            message="See photo",
            media_url=["https://example.com/img.jpg"],
        )
        assert len(params.media_url) == 1

    def test_valid_whatsapp_to(self) -> None:
        params = SendSmsParams(to="whatsapp:+18885551234", message="Hello WhatsApp")
        assert params.to == "whatsapp:+18885551234"

    def test_invalid_to(self) -> None:
        with pytest.raises(ValidationError):
            SendSmsParams(to="invalid", message="Hello")

    def test_empty_message(self) -> None:
        with pytest.raises(ValidationError):
            SendSmsParams(to="+18885551234", message="")

    def test_message_too_long(self) -> None:
        with pytest.raises(ValidationError):
            SendSmsParams(to="+18885551234", message="x" * 1601)


class TestMakeCallParams:
    """Tests for MakeCallParams validation."""

    def test_valid_params(self) -> None:
        params = MakeCallParams(to="+18885551234")
        assert params.to == "+18885551234"
        assert params.message is None
        assert params.url is None

    def test_valid_with_message(self) -> None:
        params = MakeCallParams(to="+18885551234", message="Hello from call")
        assert params.message == "Hello from call"

    def test_invalid_to(self) -> None:
        with pytest.raises(ValidationError):
            MakeCallParams(to="not-a-phone")

    def test_whatsapp_rejected(self) -> None:
        """MakeCallParams requires E.164 only, no whatsapp: prefix."""
        with pytest.raises(ValidationError):
            MakeCallParams(to="whatsapp:+18885551234")


class TestSendMmsParams:
    """Tests for SendMmsParams validation."""

    def test_valid_params(self) -> None:
        params = SendMmsParams(
            to="+18885551234",
            message="Photo time",
            media_url=["https://example.com/img.jpg"],
        )
        assert len(params.media_url) == 1

    def test_multiple_media(self) -> None:
        params = SendMmsParams(
            to="+18885551234",
            message="Photos",
            media_url=["https://a.com/1.jpg", "https://a.com/2.jpg"],
        )
        assert len(params.media_url) == 2

    def test_empty_media_url_rejected(self) -> None:
        with pytest.raises(ValidationError):
            SendMmsParams(to="+18885551234", message="Photo", media_url=[])

    def test_invalid_to(self) -> None:
        with pytest.raises(ValidationError):
            SendMmsParams(
                to="invalid",
                message="Photo",
                media_url=["https://example.com/img.jpg"],
            )


# --- CacheKeys ---


class TestCacheKeys:
    """Tests for CacheKeys generators."""

    def test_conversation_key(self) -> None:
        key = CacheKeys.conversation("+18885551234")
        assert key == "twilio:conversation:+18885551234"

    def test_call_state_key(self) -> None:
        key = CacheKeys.call_state("CA001")
        assert key == "twilio:call:CA001"

    def test_media_key(self) -> None:
        key = CacheKeys.media("ME001")
        assert key == "twilio:media:ME001"

    def test_different_numbers_different_keys(self) -> None:
        assert CacheKeys.conversation("+11111111111") != CacheKeys.conversation("+12222222222")


# --- TwilioEventType ---


class TestTwilioEventType:
    """Tests for TwilioEventType enum."""

    @pytest.mark.parametrize("member,value", [
        (TwilioEventType.SMS_RECEIVED, "sms:received"),
        (TwilioEventType.SMS_SENT, "sms:sent"),
        (TwilioEventType.CALL_RECEIVED, "call:received"),
        (TwilioEventType.CALL_ENDED, "call:ended"),
        (TwilioEventType.VOICE_STREAM_STARTED, "voice:stream:started"),
        (TwilioEventType.VOICE_STREAM_ENDED, "voice:stream:ended"),
    ])
    def test_all_event_types(self, member: TwilioEventType, value: str) -> None:
        assert member == value

    def test_event_type_is_string(self) -> None:
        assert isinstance(TwilioEventType.SMS_RECEIVED, str)

    def test_event_type_from_value(self) -> None:
        assert TwilioEventType("sms:received") == TwilioEventType.SMS_RECEIVED


# --- CallState ---


class TestCallState:
    """Tests for CallState enum and state sets."""

    def test_non_terminal_states(self) -> None:
        non_terminal = {
            CallState.INITIATED,
            CallState.RINGING,
            CallState.ANSWERED,
            CallState.ACTIVE,
            CallState.SPEAKING,
            CallState.LISTENING,
        }
        for state in non_terminal:
            assert state not in TERMINAL_STATES

    def test_terminal_states(self) -> None:
        expected_terminal = {
            CallState.COMPLETED,
            CallState.HANGUP_USER,
            CallState.HANGUP_BOT,
            CallState.TIMEOUT,
            CallState.ERROR,
            CallState.FAILED,
            CallState.NO_ANSWER,
            CallState.BUSY,
            CallState.VOICEMAIL,
        }
        assert TERMINAL_STATES == expected_terminal

    def test_conversation_states(self) -> None:
        assert CONVERSATION_STATES == {CallState.SPEAKING, CallState.LISTENING}

    def test_state_order(self) -> None:
        assert STATE_ORDER[0] == CallState.INITIATED
        assert STATE_ORDER[-1] == CallState.LISTENING
        assert len(STATE_ORDER) == 6

    def test_call_state_values(self) -> None:
        assert CallState.INITIATED.value == "initiated"
        assert CallState.COMPLETED.value == "completed"
        assert CallState.HANGUP_USER.value == "hangup-user"


# --- CallDirection and CallMode ---


class TestCallDirectionAndMode:
    """Tests for CallDirection and CallMode enums."""

    def test_call_direction(self) -> None:
        assert CallDirection.OUTBOUND == "outbound"
        assert CallDirection.INBOUND == "inbound"

    def test_call_mode(self) -> None:
        assert CallMode.NOTIFY == "notify"
        assert CallMode.CONVERSATION == "conversation"


# --- TranscriptEntry ---


class TestTranscriptEntry:
    """Tests for TranscriptEntry model."""

    def test_construct_entry(self) -> None:
        entry = TranscriptEntry(
            timestamp=1700000000.0,
            speaker="user",
            text="Hello there",
        )
        assert entry.speaker == "user"
        assert entry.text == "Hello there"
        assert entry.is_final is True  # default

    def test_non_final_entry(self) -> None:
        entry = TranscriptEntry(
            timestamp=1700000000.0,
            speaker="bot",
            text="Partial...",
            is_final=False,
        )
        assert entry.is_final is False


# --- CallRecord ---


class TestCallRecord:
    """Tests for CallRecord model."""

    def test_construct_outbound(self) -> None:
        record = CallRecord(
            call_id="uuid-1234",
            provider="twilio",
            direction="outbound",
            state="initiated",
            **{"from": "+18885550000"},
            to="+18885551234",
            started_at=1700000000.0,
        )
        assert record.call_id == "uuid-1234"
        assert record.direction == "outbound"
        assert record.from_ == "+18885550000"
        assert record.transcript == []
        assert record.processed_event_ids == []
        assert record.metadata is None
        assert record.provider_call_id is None

    def test_construct_with_metadata(self) -> None:
        record = CallRecord(
            call_id="uuid-5678",
            direction="outbound",
            **{"from": "+18885550000"},
            to="+18885551234",
            started_at=1700000000.0,
            metadata={"mode": "conversation", "initialMessage": "Hello"},
        )
        assert record.metadata["mode"] == "conversation"
        assert record.metadata["initialMessage"] == "Hello"

    def test_construct_with_transcript(self) -> None:
        entry = TranscriptEntry(timestamp=1700000000.0, speaker="bot", text="Hi")
        record = CallRecord(
            call_id="uuid-9999",
            direction="inbound",
            **{"from": "+18885551234"},
            to="+18885550000",
            started_at=1700000000.0,
            transcript=[entry],
        )
        assert len(record.transcript) == 1
        assert record.transcript[0].speaker == "bot"

    def test_defaults(self) -> None:
        record = CallRecord(call_id="uuid-0000", direction="outbound", started_at=0.0)
        assert record.provider == "twilio"
        assert record.state == "initiated"
        assert record.from_ == ""
        assert record.to == ""
        assert record.session_key is None
        assert record.answered_at is None
        assert record.ended_at is None
        assert record.end_reason is None

    def test_model_copy(self) -> None:
        """Test that model_copy produces an independent copy."""
        record = CallRecord(
            call_id="uuid-copy",
            direction="outbound",
            **{"from": "+18885550000"},
            to="+18885551234",
            started_at=1700000000.0,
        )
        copied = record.model_copy()
        copied.state = "completed"
        assert record.state == "initiated"
        assert copied.state == "completed"


# --- NormalizedEvent ---


class TestNormalizedEvent:
    """Tests for NormalizedEvent model."""

    def test_construct_minimal(self) -> None:
        event = NormalizedEvent(
            id="evt-001",
            type="call.initiated",
            call_id="call-001",
            timestamp=1700000000.0,
        )
        assert event.id == "evt-001"
        assert event.type == "call.initiated"
        assert event.call_id == "call-001"
        assert event.provider_call_id is None
        assert event.direction is None
        assert event.text is None

    def test_construct_speech_event(self) -> None:
        event = NormalizedEvent(
            id="evt-002",
            type="call.speech",
            call_id="call-001",
            timestamp=1700000001.0,
            transcript="Hello there",
            is_final=True,
            confidence=0.95,
        )
        assert event.transcript == "Hello there"
        assert event.is_final is True
        assert event.confidence == 0.95

    def test_construct_error_event(self) -> None:
        event = NormalizedEvent(
            id="evt-003",
            type="call.error",
            call_id="call-001",
            timestamp=1700000002.0,
            error="Connection failed",
            retryable=True,
        )
        assert event.error == "Connection failed"
        assert event.retryable is True

    def test_construct_ended_event(self) -> None:
        event = NormalizedEvent(
            id="evt-004",
            type="call.ended",
            call_id="call-001",
            timestamp=1700000003.0,
            reason="hangup-user",
            duration_ms=45000,
        )
        assert event.reason == "hangup-user"
        assert event.duration_ms == 45000

    def test_from_alias(self) -> None:
        event = NormalizedEvent(
            id="evt-005",
            type="call.initiated",
            call_id="call-001",
            timestamp=1700000000.0,
            **{"from": "+18885551234"},
        )
        assert event.from_ == "+18885551234"

    def test_populate_by_name(self) -> None:
        event = NormalizedEvent(
            id="evt-006",
            type="call.initiated",
            call_id="call-001",
            timestamp=1700000000.0,
            from_="+18885551234",
        )
        assert event.from_ == "+18885551234"
