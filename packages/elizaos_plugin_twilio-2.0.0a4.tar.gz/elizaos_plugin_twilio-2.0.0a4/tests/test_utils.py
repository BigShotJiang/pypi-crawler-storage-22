"""Tests for Twilio plugin utility functions."""

from __future__ import annotations

import pytest

from elizaos_plugin_twilio.utils import (
    chunk_text_for_sms,
    extract_phone_number,
    format_messaging_address,
    format_phone_number,
    generate_twiml,
    get_webhook_url,
    is_whatsapp_address,
    parse_media_from_webhook,
    strip_whatsapp_prefix,
    validate_messaging_address,
    validate_phone_number,
)


class TestValidatePhoneNumber:
    """Tests for validate_phone_number."""

    @pytest.mark.parametrize("number", ["+18885551234", "+442071234567", "+1234567890123"])
    def test_valid_e164_numbers(self, number: str) -> None:
        assert validate_phone_number(number) is True

    @pytest.mark.parametrize("number", [
        "8885551234", "+0123456789", "++18885551234",
        "+188855512345678901", "not a number", "",
    ])
    def test_invalid_numbers(self, number: str) -> None:
        assert validate_phone_number(number) is False


class TestValidateMessagingAddress:
    """Tests for validate_messaging_address."""

    def test_valid_addresses(self) -> None:
        assert validate_messaging_address("+18885551234") is True
        assert validate_messaging_address("whatsapp:+18885551234") is True

    def test_invalid_addresses(self) -> None:
        assert validate_messaging_address("8885551234") is False
        assert validate_messaging_address("whatsapp:8885551234") is False
        assert validate_messaging_address("") is False


class TestWhatsAppHelpers:
    """Tests for WhatsApp address helpers."""

    def test_is_whatsapp_address(self) -> None:
        assert is_whatsapp_address("whatsapp:+18885551234") is True
        assert is_whatsapp_address("+18885551234") is False

    def test_strip_whatsapp_prefix(self) -> None:
        assert strip_whatsapp_prefix("whatsapp:+18885551234") == "+18885551234"
        assert strip_whatsapp_prefix("+18885551234") == "+18885551234"


class TestFormatPhoneNumber:
    """Tests for format_phone_number."""

    @pytest.mark.parametrize("input_num,expected", [
        ("8885551234", "+18885551234"),
        ("18885551234", "+18885551234"),
        ("+18885551234", "+18885551234"),
        ("(888) 555-1234", "+18885551234"),
    ])
    def test_format_us_numbers(self, input_num: str, expected: str) -> None:
        assert format_phone_number(input_num) == expected

    def test_custom_country_code(self) -> None:
        assert format_phone_number("7071234567", "+44") == "+447071234567"

    def test_returns_none_for_invalid(self) -> None:
        assert format_phone_number("123") is None
        assert format_phone_number("") is None


class TestFormatMessagingAddress:
    """Tests for format_messaging_address."""

    def test_preserves_whatsapp_prefix(self) -> None:
        result = format_messaging_address("whatsapp:+18885551234")
        assert result == "whatsapp:+18885551234"

    def test_formats_plain_number(self) -> None:
        result = format_messaging_address("+18885551234")
        assert result == "+18885551234"

    def test_returns_none_for_invalid(self) -> None:
        assert format_messaging_address("invalid") is None


class TestGenerateTwiML:
    """Tests for TwiML generation."""

    def test_say_basic(self) -> None:
        twiml = generate_twiml.say("Hello world")
        assert '<Say voice="alice">Hello world</Say>' in twiml
        assert '<?xml version="1.0" encoding="UTF-8"?>' in twiml

    def test_say_escapes_xml(self) -> None:
        twiml = generate_twiml.say("Hello & <world>")
        assert "Hello &amp; &lt;world&gt;" in twiml

    def test_say_custom_voice(self) -> None:
        twiml = generate_twiml.say("Hello", "man")
        assert '<Say voice="man">Hello</Say>' in twiml

    def test_gather_defaults(self) -> None:
        twiml = generate_twiml.gather("Press 1")
        assert 'numDigits="1"' in twiml
        assert 'timeout="5"' in twiml
        assert "<Say>Press 1</Say>" in twiml

    def test_gather_custom_options(self) -> None:
        twiml = generate_twiml.gather(
            "Enter PIN",
            num_digits=4,
            timeout=10,
            action="/process",
            method="GET",
        )
        assert 'numDigits="4"' in twiml
        assert 'timeout="10"' in twiml
        assert 'action="/process"' in twiml
        assert 'method="GET"' in twiml

    def test_stream(self) -> None:
        twiml = generate_twiml.stream("wss://example.com/stream")
        assert '<Stream url="wss://example.com/stream">' in twiml
        assert "<Start>" in twiml

    def test_stream_with_parameters(self) -> None:
        twiml = generate_twiml.stream(
            "wss://example.com",
            {"callSid": "CA123", "from": "+18885551234"},
        )
        assert '<Parameter name="callSid" value="CA123"' in twiml
        assert '<Parameter name="from" value="+18885551234"' in twiml

    def test_record_defaults(self) -> None:
        twiml = generate_twiml.record()
        assert 'maxLength="3600"' in twiml
        assert 'timeout="5"' in twiml
        assert 'transcribe="false"' in twiml

    def test_record_custom_options(self) -> None:
        twiml = generate_twiml.record(
            max_length=60,
            transcribe=True,
            action="/recording",
        )
        assert 'maxLength="60"' in twiml
        assert 'transcribe="true"' in twiml
        assert 'action="/recording"' in twiml

    def test_hangup(self) -> None:
        twiml = generate_twiml.hangup()
        assert "<Hangup />" in twiml


class TestParseMediaFromWebhook:
    """Tests for parse_media_from_webhook."""

    def test_parses_media_urls(self) -> None:
        webhook_data = {
            "MediaUrl0": "https://example.com/image1.jpg",
            "MediaContentType0": "image/jpeg",
            "MediaUrl1": "https://example.com/image2.png",
            "MediaContentType1": "image/png",
        }
        media = parse_media_from_webhook(webhook_data, 2)
        assert len(media) == 2
        assert media[0] == {
            "url": "https://example.com/image1.jpg",
            "contentType": "image/jpeg",
            "sid": "media_0",
        }
        assert media[1] == {
            "url": "https://example.com/image2.png",
            "contentType": "image/png",
            "sid": "media_1",
        }

    def test_handles_missing_content_type(self) -> None:
        webhook_data = {"MediaUrl0": "https://example.com/file"}
        media = parse_media_from_webhook(webhook_data, 1)
        assert media[0]["contentType"] == "unknown"


class TestExtractPhoneNumber:
    """Tests for extract_phone_number."""

    def test_extracts_e164(self) -> None:
        assert extract_phone_number("Call +18885551234 now") == "+18885551234"

    def test_extracts_and_formats_us_numbers(self) -> None:
        assert extract_phone_number("My number is (888) 555-1234") == "+18885551234"
        assert extract_phone_number("Call 888-555-1234") == "+18885551234"
        assert extract_phone_number("Phone: 8885551234") == "+18885551234"

    def test_returns_none_when_not_found(self) -> None:
        assert extract_phone_number("No number here") is None
        assert extract_phone_number("") is None

    def test_whatsapp_prefix(self) -> None:
        result = extract_phone_number("whatsapp: Send to +18885551234")
        assert result == "whatsapp:+18885551234"


class TestChunkTextForSms:
    """Tests for chunk_text_for_sms."""

    def test_short_message_not_chunked(self) -> None:
        text = "Hello world"
        chunks = chunk_text_for_sms(text)
        assert len(chunks) == 1
        assert chunks[0] == text

    def test_long_message_chunked_at_word_boundaries(self) -> None:
        text = "a" * 50 + " " + "b" * 50 + " " + "c" * 50 + " " + "d" * 50
        chunks = chunk_text_for_sms(text, 160)
        assert len(chunks) > 1
        for chunk in chunks:
            assert len(chunk) <= 160

    def test_custom_max_length(self) -> None:
        text = "word1 word2 word3 word4 word5"
        chunks = chunk_text_for_sms(text, 10)
        assert len(chunks) > 1
        for chunk in chunks:
            assert len(chunk) <= 10


class TestGetWebhookUrl:
    """Tests for get_webhook_url."""

    @pytest.mark.parametrize("base,path", [
        ("https://example.com", "/webhook"),
        ("https://example.com/", "/webhook"),
        ("https://example.com", "webhook"),
        ("https://example.com/", "webhook"),
    ])
    def test_combines_url_and_path(self, base: str, path: str) -> None:
        assert get_webhook_url(base, path) == "https://example.com/webhook"


# ---------------------------------------------------------------------------
# Deep tests: International Numbers
# ---------------------------------------------------------------------------


class TestValidateInternationalNumbers:
    """Tests for international E.164 phone number validation."""

    def test_validate_kenya_number(self) -> None:
        """Kenya country code +254 with subscriber number."""
        assert validate_phone_number("+254712345678") is True

    def test_validate_japan_number(self) -> None:
        """Japan country code +81 with mobile number."""
        assert validate_phone_number("+819012345678") is True

    def test_validate_brazil_number(self) -> None:
        """Brazil country code +55 with area code and mobile."""
        assert validate_phone_number("+5511987654321") is True

    def test_validate_australia_number(self) -> None:
        """Australia country code +61 with mobile number."""
        assert validate_phone_number("+61412345678") is True

    def test_validate_shortest_e164(self) -> None:
        """Shortest valid E.164: +[1-9][0-9] (2 digits after +)."""
        assert validate_phone_number("+10") is True

    def test_validate_longest_e164(self) -> None:
        """Longest valid E.164: 15 digits after + (ITU-T E.164 max)."""
        assert validate_phone_number("+123456789012345") is True
        # 16 digits after + must fail
        assert validate_phone_number("+1234567890123456") is False


# ---------------------------------------------------------------------------
# Deep tests: Boundary Conditions
# ---------------------------------------------------------------------------


class TestChunkTextBoundary:
    """Boundary condition tests for SMS text chunking."""

    def test_chunk_exactly_160_chars(self) -> None:
        """Exactly 160 chars must produce a single chunk."""
        text = "a" * 160
        chunks = chunk_text_for_sms(text)
        assert len(chunks) == 1
        assert chunks[0] == text
        assert len(chunks[0]) == 160

    def test_chunk_161_chars(self) -> None:
        """161 chars with a word boundary must split into 2 chunks."""
        text = "a" * 80 + " " + "b" * 80  # 161 chars total
        chunks = chunk_text_for_sms(text, 160)
        assert len(chunks) == 2
        assert chunks[0] == "a" * 80
        assert chunks[1] == "b" * 80

    def test_chunk_empty_text(self) -> None:
        """Empty text returns a single empty-string chunk."""
        chunks = chunk_text_for_sms("")
        assert len(chunks) == 1
        assert chunks[0] == ""

    def test_chunk_whitespace_only(self) -> None:
        """Whitespace-only text within limit returns a single chunk unchanged."""
        text = "   "
        chunks = chunk_text_for_sms(text)
        assert len(chunks) == 1
        assert chunks[0] == "   "

    def test_chunk_single_word_exceeds_max(self) -> None:
        """A single word exceeding max length cannot be split; returned as-is."""
        text = "a" * 200
        chunks = chunk_text_for_sms(text, 160)
        assert len(chunks) == 1
        assert chunks[0] == "a" * 200
        assert len(chunks[0]) == 200  # exceeds max but unsplittable

    def test_extract_phone_multiple_numbers_in_text(self) -> None:
        """Only the first phone number in text is extracted."""
        result = extract_phone_number("Call +18885551234 or +442071234567")
        assert result == "+18885551234"


# ---------------------------------------------------------------------------
# Deep tests: Security (TwiML XSS / Injection)
# ---------------------------------------------------------------------------


class TestTwiMLSecurity:
    """Security tests for TwiML generation — XSS and injection prevention."""

    def test_twiml_say_xss_injection(self) -> None:
        """Script tags in <Say> text must be XML-escaped."""
        twiml = generate_twiml.say('<script>alert("xss")</script>')

        assert "&lt;script&gt;" in twiml
        assert "&lt;/script&gt;" in twiml
        assert 'alert(&quot;xss&quot;)' in twiml
        # Literal <script> must NOT appear in message content
        assert "<script>" not in twiml

    def test_twiml_gather_action_xss(self) -> None:
        """Quotes/tags in the action URL are not escaped (documents current behaviour)."""
        twiml = generate_twiml.gather(
            "Enter code",
            action='/hook"><script>alert(1)</script>',
        )
        # The prompt IS properly escaped
        assert "<Say>Enter code</Say>" in twiml
        # The action value is embedded raw — not XML-escaped
        assert "<script>alert(1)</script>" in twiml

    def test_twiml_stream_parameter_injection(self) -> None:
        """Stream parameter values must be XML-escaped."""
        twiml = generate_twiml.stream(
            "wss://example.com/stream",
            {"payload": '<img src=x onerror="alert(1)">'},
        )
        # Parameter values go through _escape_xml
        assert "&lt;img" in twiml
        assert "&quot;alert(1)&quot;" in twiml
        # Literal unescaped tag must not appear
        assert 'onerror="alert(1)"' not in twiml

    def test_twiml_null_and_control_characters(self) -> None:
        """Null and control characters pass through _escape_xml unfiltered."""
        twiml = generate_twiml.say("Hello\x00World\x07End")

        # Control characters are not stripped by _escape_xml
        assert "\x00" in twiml
        assert "\x07" in twiml
        assert "Hello" in twiml
        assert "End" in twiml


# ---------------------------------------------------------------------------
# Deep tests: Error Handling
# ---------------------------------------------------------------------------


class TestUtilsErrors:
    """Error handling tests for utility functions."""

    def test_format_phone_invalid_country_code(self) -> None:
        """Country code without '+' prefix produces None (invalid E.164)."""
        result = format_phone_number("1234567890", "99")
        assert result is None

    def test_parse_media_webhook_zero_media(self) -> None:
        """Zero media count returns an empty list."""
        result = parse_media_from_webhook({"Body": "hello", "From": "+1234"}, 0)
        assert result == []
        assert len(result) == 0

    def test_extract_phone_from_url_with_port(self) -> None:
        """Port numbers in URLs must not be mistaken for phone numbers."""
        result = extract_phone_number("Visit http://example.com:8080/path")
        assert result is None
