# elizaos-plugin-twitch

Twitch chat integration plugin for ElizaOS agents

## Installation

```bash
pip install elizaos-plugin-twitch
```

## Part of elizaOS

This is a Python plugin for the [elizaOS](https://github.com/elizaos/eliza) AI agent framework.

## License

MIT
