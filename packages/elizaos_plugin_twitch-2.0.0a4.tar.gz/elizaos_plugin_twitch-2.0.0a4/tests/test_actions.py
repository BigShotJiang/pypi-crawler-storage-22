"""Tests for all 4 Twitch plugin actions."""

import pytest

from elizaos_plugin_twitch.actions.send_message import send_message_action, validate as sm_validate, handler as sm_handler
from elizaos_plugin_twitch.actions.join_channel import join_channel_action, validate as jc_validate, handler as jc_handler
from elizaos_plugin_twitch.actions.leave_channel import leave_channel_action, validate as lc_validate, handler as lc_handler
from elizaos_plugin_twitch.actions.list_channels import list_channels_action, validate as ls_validate, handler as ls_handler


# ===========================================================================
# Action metadata (consolidated across all 4 actions)
# ===========================================================================

_ALL_ACTIONS = [send_message_action, join_channel_action, leave_channel_action, list_channels_action]
_ALL_NAMES = ["TWITCH_SEND_MESSAGE", "TWITCH_JOIN_CHANNEL", "TWITCH_LEAVE_CHANNEL", "TWITCH_LIST_CHANNELS"]


@pytest.mark.parametrize("action,expected_name", zip(_ALL_ACTIONS, _ALL_NAMES))
def test_action_name(action, expected_name):
    assert action["name"] == expected_name


@pytest.mark.parametrize("action", _ALL_ACTIONS)
def test_action_has_examples(action):
    assert len(action["examples"]) > 0


def test_send_message_similes():
    similes = send_message_action["similes"]
    assert len(similes) == 4
    for s in ["SEND_TWITCH_MESSAGE", "TWITCH_CHAT", "CHAT_TWITCH", "SAY_IN_TWITCH"]:
        assert s in similes


def test_join_channel_similes():
    similes = join_channel_action["similes"]
    assert len(similes) == 3
    for s in ["JOIN_TWITCH_CHANNEL", "ENTER_CHANNEL", "CONNECT_CHANNEL"]:
        assert s in similes


def test_leave_channel_similes():
    similes = leave_channel_action["similes"]
    assert len(similes) == 4
    for s in ["LEAVE_TWITCH_CHANNEL", "EXIT_CHANNEL", "PART_CHANNEL", "DISCONNECT_CHANNEL"]:
        assert s in similes


def test_list_channels_similes():
    similes = list_channels_action["similes"]
    assert len(similes) == 4
    for s in ["LIST_TWITCH_CHANNELS", "SHOW_CHANNELS", "GET_CHANNELS", "CURRENT_CHANNELS"]:
        assert s in similes


# ===========================================================================
# Validation (all 4 actions share the same accept/reject pattern)
# ===========================================================================


@pytest.mark.parametrize("validate_fn", [sm_validate, jc_validate, lc_validate, ls_validate])
@pytest.mark.asyncio
async def test_validate_accepts_twitch(validate_fn, mock_runtime, twitch_message):
    assert await validate_fn(mock_runtime(), twitch_message(source="twitch")) is True


@pytest.mark.parametrize("validate_fn,source", [
    (sm_validate, "discord"),
    (sm_validate, ""),
    (jc_validate, "discord"),
    (jc_validate, "telegram"),
    (lc_validate, "discord"),
    (ls_validate, "slack"),
])
@pytest.mark.asyncio
async def test_validate_rejects_non_twitch(validate_fn, source, mock_runtime, twitch_message):
    assert await validate_fn(mock_runtime(), twitch_message(source=source)) is False


# ===========================================================================
# Handler: service unavailable (all 4 actions)
# ===========================================================================


@pytest.mark.parametrize("handler_fn", [sm_handler, jc_handler, lc_handler, ls_handler])
@pytest.mark.asyncio
async def test_handler_error_when_service_unavailable(handler_fn, mock_runtime, twitch_message):
    runtime = mock_runtime(service=None)
    callback_payloads = []

    async def callback(resp):
        callback_payloads.append(resp)

    result = await handler_fn(runtime, twitch_message(), {}, {}, callback)
    assert result["success"] is False
    assert result["error"] == "Twitch service not available"
    assert callback_payloads[0]["text"] == "Twitch service is not available."


# ===========================================================================
# Handler: service disconnected
# ===========================================================================


@pytest.mark.asyncio
async def test_send_message_error_when_disconnected(mock_runtime, mock_service, twitch_message):
    service = mock_service(connected=False)
    runtime = mock_runtime(service=service)
    callback_payloads = []

    async def callback(resp):
        callback_payloads.append(resp)

    result = await sm_handler(runtime, twitch_message(), {}, {}, callback)
    assert result["success"] is False
    assert "not available" in result["error"]


@pytest.mark.parametrize("handler_fn", [jc_handler, lc_handler])
@pytest.mark.asyncio
async def test_handler_error_when_disconnected(handler_fn, mock_runtime, mock_service, twitch_message):
    service = mock_service(connected=False)
    runtime = mock_runtime(service=service)
    result = await handler_fn(runtime, twitch_message(), {})
    assert result["success"] is False


# ===========================================================================
# Handler: list_channels specific behavior
# ===========================================================================


class TestListChannelsHandler:
    @pytest.mark.asyncio
    async def test_returns_channel_list(self, mock_runtime, mock_service, twitch_message):
        service = mock_service(
            connected=True,
            primary_channel="mainchannel",
            joined_channels=["mainchannel", "otherchannel"],
        )
        runtime = mock_runtime(service=service)
        callback_payloads = []

        async def callback(resp):
            callback_payloads.append(resp)

        result = await ls_handler(runtime, twitch_message(), {}, {}, callback)
        assert result["success"] is True
        assert result["data"]["channel_count"] == 2
        assert result["data"]["channels"] == ["mainchannel", "otherchannel"]
        assert result["data"]["primary_channel"] == "mainchannel"
        assert "2 channel(s)" in callback_payloads[0]["text"]
        assert "#mainchannel (primary)" in callback_payloads[0]["text"]

    @pytest.mark.asyncio
    async def test_returns_empty_for_no_channels(self, mock_runtime, mock_service, twitch_message):
        service = mock_service(connected=True, primary_channel="main", joined_channels=[])
        runtime = mock_runtime(service=service)
        callback_payloads = []

        async def callback(resp):
            callback_payloads.append(resp)

        result = await ls_handler(runtime, twitch_message(), {}, {}, callback)
        assert result["success"] is True
        assert result["data"]["channel_count"] == 0
        assert callback_payloads[0]["text"] == "Not currently in any channels."
