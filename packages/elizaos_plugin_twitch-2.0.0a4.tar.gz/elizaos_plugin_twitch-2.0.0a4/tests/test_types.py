"""Tests for Twitch plugin types, constants, utility functions, and custom errors."""

import pytest

from elizaos_plugin_twitch.types import (
    MAX_TWITCH_MESSAGE_LENGTH,
    TWITCH_SERVICE_NAME,
    TwitchApiError,
    TwitchConfigurationError,
    TwitchEventTypes,
    TwitchMessage,
    TwitchMessageSendOptions,
    TwitchNotConnectedError,
    TwitchPluginError,
    TwitchSendResult,
    TwitchServiceNotInitializedError,
    TwitchSettings,
    TwitchUserInfo,
    format_channel_for_display,
    get_twitch_user_display_name,
    normalize_channel,
    split_message_for_twitch,
    strip_markdown_for_twitch,
)


# ===========================================================================
# Constants & Event Types
# ===========================================================================


class TestConstants:
    def test_max_message_length(self):
        assert MAX_TWITCH_MESSAGE_LENGTH == 500

    def test_service_name(self):
        assert TWITCH_SERVICE_NAME == "twitch"


class TestTwitchEventTypes:
    @pytest.mark.parametrize("member,expected", [
        (TwitchEventTypes.MESSAGE_RECEIVED, "TWITCH_MESSAGE_RECEIVED"),
        (TwitchEventTypes.MESSAGE_SENT, "TWITCH_MESSAGE_SENT"),
        (TwitchEventTypes.JOIN_CHANNEL, "TWITCH_JOIN_CHANNEL"),
        (TwitchEventTypes.LEAVE_CHANNEL, "TWITCH_LEAVE_CHANNEL"),
        (TwitchEventTypes.CONNECTION_READY, "TWITCH_CONNECTION_READY"),
        (TwitchEventTypes.CONNECTION_LOST, "TWITCH_CONNECTION_LOST"),
    ])
    def test_event_values(self, member, expected):
        assert member.value == expected

    def test_all_are_strings(self):
        for event in TwitchEventTypes:
            assert isinstance(event.value, str)

    def test_count(self):
        assert len(TwitchEventTypes) == 6


# ===========================================================================
# Dataclass Construction
# ===========================================================================


class TestTwitchSettings:
    def test_minimal_construction(self):
        settings = TwitchSettings(
            username="bot", client_id="cid", access_token="tok", channel="main",
        )
        assert settings.username == "bot"
        assert settings.client_secret is None
        assert settings.additional_channels == []
        assert settings.require_mention is False
        assert settings.allowed_roles == ["all"]
        assert settings.enabled is True

    def test_full_construction(self):
        settings = TwitchSettings(
            username="bot", client_id="cid", access_token="tok", channel="main",
            client_secret="secret", refresh_token="refresh",
            additional_channels=["extra1", "extra2"],
            require_mention=True, allowed_roles=["moderator", "owner"],
            allowed_user_ids=["uid1"], enabled=False,
        )
        assert settings.client_secret == "secret"
        assert settings.additional_channels == ["extra1", "extra2"]
        assert settings.require_mention is True
        assert settings.enabled is False


class TestTwitchUserInfo:
    def test_default_values(self):
        user = TwitchUserInfo(user_id="1", username="alice", display_name="Alice")
        assert user.is_moderator is False
        assert user.is_broadcaster is False
        assert user.is_vip is False
        assert user.is_subscriber is False
        assert user.color is None
        assert user.badges == {}

    def test_with_roles(self):
        user = TwitchUserInfo(
            user_id="2", username="bob", display_name="Bob",
            is_moderator=True, is_vip=True, color="#00FF00",
            badges={"moderator": "1", "premium": "1"},
        )
        assert user.is_moderator is True
        assert user.color == "#00FF00"
        assert user.badges["moderator"] == "1"


class TestTwitchMessage:
    def test_construction(self):
        user = TwitchUserInfo(user_id="1", username="u", display_name="U")
        msg = TwitchMessage(
            id="msg-1", channel="test", text="hello world",
            user=user, timestamp=1234567890.0,
        )
        assert msg.id == "msg-1"
        assert msg.is_action is False
        assert msg.reply_to is None

    def test_with_reply(self):
        user = TwitchUserInfo(user_id="1", username="u", display_name="U")
        msg = TwitchMessage(
            id="msg-2", channel="test", text="reply", user=user, timestamp=0,
            reply_to={"message_id": "parent", "user_id": "2", "username": "other", "text": "original"},
        )
        assert msg.reply_to["message_id"] == "parent"


class TestTwitchMessageSendOptions:
    def test_defaults(self):
        opts = TwitchMessageSendOptions()
        assert opts.channel is None
        assert opts.reply_to is None

    def test_with_values(self):
        opts = TwitchMessageSendOptions(channel="test", reply_to="msg-1")
        assert opts.channel == "test"


class TestTwitchSendResult:
    def test_success(self):
        result = TwitchSendResult(success=True, message_id="abc")
        assert result.success is True
        assert result.error is None

    def test_failure(self):
        result = TwitchSendResult(success=False, error="not connected")
        assert result.success is False
        assert result.message_id is None


# ===========================================================================
# Custom Errors
# ===========================================================================


class TestCustomErrors:
    def test_plugin_error_base(self):
        err = TwitchPluginError("base error")
        assert isinstance(err, Exception)
        assert str(err) == "base error"

    @pytest.mark.parametrize("err,expected_substr", [
        (TwitchServiceNotInitializedError(), "not initialized"),
        (TwitchServiceNotInitializedError("custom"), "custom"),
        (TwitchNotConnectedError(), "not connected"),
    ])
    def test_default_errors(self, err, expected_substr):
        assert isinstance(err, TwitchPluginError)
        assert expected_substr in str(err)

    def test_configuration_error(self):
        err = TwitchConfigurationError("bad config", "MY_SETTING")
        assert isinstance(err, TwitchPluginError)
        assert str(err) == "bad config"
        assert err.setting_name == "MY_SETTING"

    def test_configuration_error_no_setting(self):
        assert TwitchConfigurationError("missing").setting_name is None

    def test_api_error(self):
        err = TwitchApiError("api fail", 401)
        assert isinstance(err, TwitchPluginError)
        assert err.status_code == 401

    def test_api_error_no_status(self):
        assert TwitchApiError("error").status_code is None


# ===========================================================================
# Utility Functions
# ===========================================================================


class TestNormalizeChannel:
    @pytest.mark.parametrize("input_val,expected", [
        ("#mychannel", "mychannel"),
        ("mychannel", "mychannel"),
        ("", ""),
        ("##double", "double"),
        ("my#channel", "my#channel"),
    ])
    def test_normalize(self, input_val, expected):
        assert normalize_channel(input_val) == expected


class TestFormatChannelForDisplay:
    @pytest.mark.parametrize("input_val,expected", [
        ("mychannel", "#mychannel"),
        ("#mychannel", "#mychannel"),
    ])
    def test_format(self, input_val, expected):
        assert format_channel_for_display(input_val) == expected


class TestGetTwitchUserDisplayName:
    @pytest.mark.parametrize("display_name,username,expected", [
        ("Alice_Cool", "alice", "Alice_Cool"),
        ("", "bob", "bob"),
    ])
    def test_display_name(self, display_name, username, expected):
        user = TwitchUserInfo(user_id="1", username=username, display_name=display_name)
        assert get_twitch_user_display_name(user) == expected


class TestStripMarkdownForTwitch:
    @pytest.mark.parametrize("input_val,expected", [
        ("**bold text**", "bold text"),
        ("__bold text__", "bold text"),
        ("*italic*", "italic"),
        ("_italic_", "italic"),
        ("~~strikethrough~~", "strikethrough"),
        ("`code`", "code"),
        ("[click](https://example.com)", "click"),
        ("## Header", "Header"),
        ("> quoted", "quoted"),
        ("- item", "• item"),
        ("1. item", "• item"),
        ("a\n\n\n\nb", "a\n\nb"),
        ("plain text", "plain text"),
        ("  hello  ", "hello"),
    ])
    def test_strip_markdown(self, input_val, expected):
        assert strip_markdown_for_twitch(input_val) == expected

    def test_code_blocks(self):
        result = strip_markdown_for_twitch("before ```code``` after")
        assert "code" in result
        result2 = strip_markdown_for_twitch("```js\ncode\n```")
        assert len(result2) > 0


class TestSplitMessageForTwitch:
    def test_short_message_single_chunk(self):
        assert split_message_for_twitch("Hello world") == ["Hello world"]

    def test_long_message_splits(self):
        chunks = split_message_for_twitch("A" * 600)
        assert len(chunks) > 1
        for chunk in chunks:
            assert len(chunk) <= MAX_TWITCH_MESSAGE_LENGTH

    def test_respects_custom_max_length(self):
        assert len(split_message_for_twitch("A" * 30, max_length=10)) == 3

    def test_sentence_boundary_split(self):
        prefix = "A" * 300
        text = prefix + ". " + "B" * 250
        chunks = split_message_for_twitch(text, max_length=500)
        assert len(chunks) == 2
        assert chunks[0] == prefix
        assert "B" in chunks[1]

    def test_word_boundary_split(self):
        words = " ".join(["word"] * 60)
        chunks = split_message_for_twitch(words, max_length=50)
        assert len(chunks) > 1

    def test_exact_max_length(self):
        text = "A" * 500
        assert split_message_for_twitch(text, max_length=500) == [text]
