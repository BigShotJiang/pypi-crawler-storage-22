# elizaos-plugin-webhooks

HTTP webhook ingress plugin for ElizaOS

## Installation

```bash
pip install elizaos-plugin-webhooks
```

## Part of elizaOS

This is a Python plugin for the [elizaOS](https://github.com/elizaos/eliza) AI agent framework.

## License

MIT
