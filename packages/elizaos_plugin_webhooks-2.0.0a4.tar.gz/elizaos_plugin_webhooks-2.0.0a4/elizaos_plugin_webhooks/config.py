"""Configuration constants and resolution for the webhooks plugin.

Handles reading hooks configuration from character settings and applying
preset mappings (e.g. Gmail).
"""

from __future__ import annotations

import logging
from typing import Any

from .types import HookMapping, HookMatch, HooksConfig

logger = logging.getLogger("elizaos.plugin.webhooks")

# ── Defaults ──────────────────────────────────────────────────────────────

DEFAULT_TIMEOUT_SECONDS: int = 300
"""Default timeout for agent turns (5 minutes)."""

DEFAULT_CHANNEL: str = "last"
"""Default delivery channel (resolves to most recent non-internal room)."""

DEFAULT_WAKE_MODE: str = "now"
"""Default wake mode (trigger heartbeat immediately)."""

# ── Preset mappings ───────────────────────────────────────────────────────

GMAIL_PRESET_MAPPING = HookMapping(
    match=HookMatch(path="gmail"),
    action="agent",
    name="Gmail",
    session_key="hook:gmail:{{messages[0].id}}",
    message_template=(
        "New email from {{messages[0].from}}\n"
        "Subject: {{messages[0].subject}}\n"
        "{{messages[0].snippet}}\n"
        "{{messages[0].body}}"
    ),
    wake_mode="now",
    deliver=True,
    channel="last",
)

PRESET_MAPPINGS: dict[str, HookMapping] = {
    "gmail": GMAIL_PRESET_MAPPING,
}
"""Registry of built-in preset mappings keyed by preset name."""


# ── Config resolution ─────────────────────────────────────────────────────


def resolve_hooks_config(settings: dict[str, Any]) -> HooksConfig | None:
    """Resolve hooks configuration from character settings.

    Reads the ``hooks`` key from *settings*, validates the token, parses
    mapping dicts into :class:`HookMapping` instances, and applies any
    configured presets.

    Args:
        settings: The character settings dict (from
            ``runtime.get_character_settings()``).

    Returns:
        A :class:`HooksConfig` if hooks are enabled and a token is set,
        otherwise ``None``.
    """
    hooks: dict[str, Any] = settings.get("hooks", {})

    if hooks.get("enabled") is False:
        return None

    token = hooks.get("token", "")
    if not isinstance(token, str) or not token.strip():
        return None
    token = token.strip()

    raw_mappings = hooks.get("mappings", [])
    mappings: list[HookMapping] = []
    if isinstance(raw_mappings, list):
        for m in raw_mappings:
            if isinstance(m, dict):
                mappings.append(HookMapping.from_dict(m))

    presets: list[str] = []
    raw_presets = hooks.get("presets", [])
    if isinstance(raw_presets, list):
        presets = [p for p in raw_presets if isinstance(p, str)]

    # Apply presets
    for preset_name in presets:
        if preset_name in PRESET_MAPPINGS:
            has_existing = any(
                m.match and m.match.path == preset_name for m in mappings
            )
            if not has_existing:
                mappings.append(PRESET_MAPPINGS[preset_name])

    return HooksConfig(token=token, mappings=mappings, presets=presets)
