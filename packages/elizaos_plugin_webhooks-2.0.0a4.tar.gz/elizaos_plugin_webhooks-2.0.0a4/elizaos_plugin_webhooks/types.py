"""Type definitions for the webhooks plugin.

Mirrors the TypeScript HookMapping interface and related types.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass(slots=True)
class HookMatch:
    """Match criteria for a hook mapping."""

    path: str | None = None
    source: str | None = None


@dataclass(slots=True)
class HookMapping:
    """Configuration for how a webhook payload is mapped to an action.

    Attributes:
        match: Criteria to match incoming webhooks (by path or source).
        action: Whether to trigger a 'wake' or 'agent' action.
        wake_mode: Timing for the heartbeat wake ('now' or 'next-heartbeat').
        name: Display name for the hook.
        session_key: Template string for deriving a session key (supports ``{{placeholders}}``).
        message_template: Template for the agent message body.
        text_template: Template for wake text (falls back to message_template).
        deliver: Whether to deliver the agent response to a channel.
        channel: Target channel identifier (e.g. 'discord', 'last').
        to: Specific channel/room target (e.g. 'channel:123456789').
        model: Override model for the agent turn.
        thinking: Thinking mode configuration.
        timeout_seconds: Max seconds for the agent turn.
        allow_unsafe_external_content: If True, skip sanitisation of external content.
    """

    match: HookMatch | None = None
    action: Literal["wake", "agent"] | None = None
    wake_mode: Literal["now", "next-heartbeat"] | None = None
    name: str | None = None
    session_key: str | None = None
    message_template: str | None = None
    text_template: str | None = None
    deliver: bool | None = None
    channel: str | None = None
    to: str | None = None
    model: str | None = None
    thinking: str | None = None
    timeout_seconds: int | None = None
    allow_unsafe_external_content: bool | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HookMapping:
        """Create a HookMapping from a dict, supporting both camelCase and snake_case keys."""
        match_data = data.get("match")
        match = HookMatch(**match_data) if isinstance(match_data, dict) else None

        def _get(camel: str, snake: str | None = None) -> Any:
            return data.get(camel) if data.get(camel) is not None else data.get(snake or camel)

        return cls(
            match=match,
            action=_get("action"),
            wake_mode=_get("wakeMode", "wake_mode"),
            name=_get("name"),
            session_key=_get("sessionKey", "session_key"),
            message_template=_get("messageTemplate", "message_template"),
            text_template=_get("textTemplate", "text_template"),
            deliver=_get("deliver"),
            channel=_get("channel"),
            to=_get("to"),
            model=_get("model"),
            thinking=_get("thinking"),
            timeout_seconds=_get("timeoutSeconds", "timeout_seconds"),
            allow_unsafe_external_content=_get("allowUnsafeExternalContent", "allow_unsafe_external_content"),
        )


@dataclass(slots=True)
class HooksConfig:
    """Resolved hooks configuration from character settings."""

    token: str
    mappings: list[HookMapping] = field(default_factory=list)
    presets: list[str] = field(default_factory=list)


@dataclass(slots=True)
class AppliedMapping:
    """Result of applying a mapping to a webhook payload."""

    action: Literal["wake", "agent"]
    text: str | None = None
    message: str | None = None
    name: str | None = None
    session_key: str | None = None
    wake_mode: Literal["now", "next-heartbeat"] = "now"
    deliver: bool | None = None
    channel: str | None = None
    to: str | None = None
    model: str | None = None
    thinking: str | None = None
    timeout_seconds: int | None = None


# Type alias for JSON-like payload dicts
Payload = dict[str, Any]
