"""Tests for elizaos_plugin_webhooks.types – type construction and from_dict."""

from elizaos_plugin_webhooks.types import (
    AppliedMapping,
    HookMapping,
    HookMatch,
    HooksConfig,
)


class TestHookMatch:
    def test_default_construction(self) -> None:
        match = HookMatch()
        assert match.path is None
        assert match.source is None

    def test_construction_with_values(self) -> None:
        match = HookMatch(path="gmail", source="google")
        assert match.path == "gmail"
        assert match.source == "google"


class TestHookMapping:
    def test_default_construction(self) -> None:
        mapping = HookMapping()
        assert mapping.match is None
        assert mapping.action is None
        assert mapping.wake_mode is None
        assert mapping.name is None
        assert mapping.session_key is None
        assert mapping.message_template is None
        assert mapping.text_template is None
        assert mapping.deliver is None
        assert mapping.channel is None
        assert mapping.to is None
        assert mapping.model is None
        assert mapping.thinking is None
        assert mapping.timeout_seconds is None
        assert mapping.allow_unsafe_external_content is None

    def test_construction_with_values(self) -> None:
        mapping = HookMapping(
            match=HookMatch(path="test"),
            action="agent",
            wake_mode="now",
            name="Test Hook",
            session_key="hook:test:123",
            message_template="Hello {{name}}",
            deliver=True,
            channel="discord",
            to="channel:123",
            model="gpt-4",
            timeout_seconds=60,
        )
        assert mapping.match is not None
        assert mapping.match.path == "test"
        assert mapping.action == "agent"
        assert mapping.name == "Test Hook"
        assert mapping.deliver is True
        assert mapping.timeout_seconds == 60

    def test_from_dict_camel_case(self) -> None:
        data = {
            "match": {"path": "gmail"},
            "action": "agent",
            "name": "Gmail",
            "sessionKey": "hook:gmail:{{id}}",
            "messageTemplate": "Email from {{from}}",
            "textTemplate": "Wake: {{subject}}",
            "wakeMode": "now",
            "deliver": True,
            "channel": "discord",
            "to": "channel:123",
            "model": "gpt-4",
            "thinking": "enabled",
            "timeoutSeconds": 120,
            "allowUnsafeExternalContent": False,
        }
        mapping = HookMapping.from_dict(data)
        assert mapping.match is not None
        assert mapping.match.path == "gmail"
        assert mapping.action == "agent"
        assert mapping.name == "Gmail"
        assert mapping.session_key == "hook:gmail:{{id}}"
        assert mapping.message_template == "Email from {{from}}"
        assert mapping.text_template == "Wake: {{subject}}"
        assert mapping.wake_mode == "now"
        assert mapping.deliver is True
        assert mapping.channel == "discord"
        assert mapping.to == "channel:123"
        assert mapping.model == "gpt-4"
        assert mapping.thinking == "enabled"
        assert mapping.timeout_seconds == 120
        assert mapping.allow_unsafe_external_content is False

    def test_from_dict_snake_case(self) -> None:
        data = {
            "match": {"path": "test"},
            "action": "wake",
            "wake_mode": "next-heartbeat",
            "session_key": "hook:test",
            "message_template": "Hello",
            "text_template": "Wake up",
            "timeout_seconds": 30,
            "allow_unsafe_external_content": True,
        }
        mapping = HookMapping.from_dict(data)
        assert mapping.action == "wake"
        assert mapping.wake_mode == "next-heartbeat"
        assert mapping.session_key == "hook:test"
        assert mapping.timeout_seconds == 30
        assert mapping.allow_unsafe_external_content is True

    def test_from_dict_minimal(self) -> None:
        mapping = HookMapping.from_dict({})
        assert mapping.match is None
        assert mapping.action is None
        assert mapping.name is None

    def test_from_dict_with_nested_match(self) -> None:
        mapping = HookMapping.from_dict({"match": {"source": "stripe"}})
        assert mapping.match is not None
        assert mapping.match.source == "stripe"
        assert mapping.match.path is None

    def test_from_dict_ignores_unknown_keys(self) -> None:
        mapping = HookMapping.from_dict({"name": "Test", "unknownKey": "val"})
        assert mapping.name == "Test"


class TestHooksConfig:
    def test_construction(self) -> None:
        config = HooksConfig(
            token="secret",
            mappings=[HookMapping(name="test")],
            presets=["gmail"],
        )
        assert config.token == "secret"
        assert len(config.mappings) == 1
        assert config.presets == ["gmail"]

    def test_default_lists(self) -> None:
        config = HooksConfig(token="secret")
        assert config.mappings == []
        assert config.presets == []


class TestAppliedMapping:
    def test_wake_construction(self) -> None:
        applied = AppliedMapping(
            action="wake",
            text="Hello",
            wake_mode="now",
        )
        assert applied.action == "wake"
        assert applied.text == "Hello"
        assert applied.wake_mode == "now"
        assert applied.message is None

    def test_agent_construction(self) -> None:
        applied = AppliedMapping(
            action="agent",
            message="Process this",
            name="Test",
            session_key="hook:test:123",
            wake_mode="now",
            deliver=True,
            channel="discord",
            to="channel:123",
        )
        assert applied.action == "agent"
        assert applied.message == "Process this"
        assert applied.name == "Test"
        assert applied.deliver is True
        assert applied.text is None

    def test_default_wake_mode(self) -> None:
        applied = AppliedMapping(action="agent")
        assert applied.wake_mode == "now"
