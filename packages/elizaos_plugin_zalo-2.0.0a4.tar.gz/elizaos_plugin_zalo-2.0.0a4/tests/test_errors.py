"""Tests for plugin-zalo error module."""

import pytest

from elizaos_plugin_zalo.error import (
    ApiError,
    ClientNotInitializedError,
    ConfigError,
    MessageSendError,
    TokenRefreshError,
    UserNotFoundError,
    ZaloError,
)


class TestErrorHierarchy:
    @pytest.mark.parametrize("err", [
        ApiError("test"),
        ConfigError("test"),
        ClientNotInitializedError(),
        MessageSendError("user1"),
        TokenRefreshError("test"),
        UserNotFoundError("user1"),
    ])
    def test_inherits_from_zalo_error(self, err) -> None:
        assert isinstance(err, ZaloError)


class TestErrorMessages:
    def test_api_error_with_code(self) -> None:
        err = ApiError("Bad request", error_code=400)
        assert "Bad request" in str(err)
        assert err.error_code == 400

    def test_api_error_default_code_is_none(self) -> None:
        assert ApiError("err").error_code is None

    def test_client_not_initialized(self) -> None:
        assert "not initialized" in str(ClientNotInitializedError())

    def test_message_send_error(self) -> None:
        err = MessageSendError("user-42")
        assert "user-42" in str(err)
        assert err.user_id == "user-42"
        assert err.cause is None

    def test_message_send_error_with_cause(self) -> None:
        cause = RuntimeError("network")
        err = MessageSendError("user-1", cause=cause)
        assert err.cause is cause

    def test_user_not_found(self) -> None:
        err = UserNotFoundError("user-99")
        assert "user-99" in str(err)
        assert err.user_id == "user-99"
