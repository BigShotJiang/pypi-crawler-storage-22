"""Check status action for Zalo User."""

from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)

CHECK_STATUS_ACTION = "ZALOUSER_CHECK_STATUS"

CHECK_STATUS_SIMILES = [
    "ZALOUSER_STATUS",
    "ZALO_STATUS",
    "ZALO_CHECK_AUTH",
    "ZALO_CONNECTION_STATUS",
    "ZALO_IS_CONNECTED",
]

CHECK_STATUS_DESCRIPTION = (
    "Check the authentication and connection status of the Zalo personal account"
)


@dataclass
class CheckStatusActionResult:
    """Result of check status action."""

    success: bool
    action: str
    connected: bool = False
    running: bool = False
    user_display_name: str | None = None
    user_id: str | None = None
    latency_ms: int | None = None
    error: str | None = None


async def handle_check_status() -> CheckStatusActionResult:
    """Handle check status action.

    Note: This is a placeholder that should be called through the service.
    """
    logger.info("Check status action")

    return CheckStatusActionResult(
        success=True,
        action=CHECK_STATUS_ACTION,
        connected=False,
    )


def validate_check_status(service_available: bool) -> bool:
    """Validate that this action can run (service must be available)."""
    return service_available


# Action metadata for registration
CHECK_STATUS_ACTION_META = {
    "name": CHECK_STATUS_ACTION,
    "similes": CHECK_STATUS_SIMILES,
    "description": CHECK_STATUS_DESCRIPTION,
    "examples": [
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Is Zalo connected?"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Let me check the Zalo connection status.",
                    "actions": [CHECK_STATUS_ACTION],
                },
            },
        ],
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Check Zalo auth status"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Checking Zalo authentication status.",
                    "actions": [CHECK_STATUS_ACTION],
                },
            },
        ],
    ],
}
