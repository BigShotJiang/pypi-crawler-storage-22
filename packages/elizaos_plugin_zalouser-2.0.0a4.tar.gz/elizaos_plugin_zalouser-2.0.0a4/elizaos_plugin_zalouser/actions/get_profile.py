"""Get profile action for Zalo User."""

from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)

GET_PROFILE_ACTION = "ZALOUSER_GET_PROFILE"

GET_PROFILE_SIMILES = [
    "ZALOUSER_ME",
    "ZALOUSER_PROFILE",
    "ZALO_ME",
    "ZALO_PROFILE",
    "ZALO_WHO_AM_I",
    "ZALO_MY_INFO",
]

GET_PROFILE_DESCRIPTION = (
    "Get the authenticated Zalo personal account profile information"
)


@dataclass
class GetProfileActionResult:
    """Result of get profile action."""

    success: bool
    action: str
    user_id: str | None = None
    display_name: str | None = None
    avatar: str | None = None
    phone_number: str | None = None
    error: str | None = None


async def handle_get_profile() -> GetProfileActionResult:
    """Handle get profile action.

    Note: This is a placeholder that should be called through the service.
    """
    logger.info("Get profile action")

    return GetProfileActionResult(
        success=True,
        action=GET_PROFILE_ACTION,
    )


def validate_get_profile(service_available: bool) -> bool:
    """Validate that this action can run (service must be available)."""
    return service_available


# Action metadata for registration
GET_PROFILE_ACTION_META = {
    "name": GET_PROFILE_ACTION,
    "similes": GET_PROFILE_SIMILES,
    "description": GET_PROFILE_DESCRIPTION,
    "examples": [
        [
            {
                "name": "{{name1}}",
                "content": {"text": "What's my Zalo profile?"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Here's your Zalo profile information.",
                    "actions": [GET_PROFILE_ACTION],
                },
            },
        ],
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Who am I on Zalo?"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Let me check your Zalo account.",
                    "actions": [GET_PROFILE_ACTION],
                },
            },
        ],
    ],
}
