"""List friends action for Zalo User."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

LIST_FRIENDS_ACTION = "ZALOUSER_LIST_FRIENDS"

LIST_FRIENDS_SIMILES = [
    "ZALOUSER_FRIENDS",
    "ZALO_LIST_FRIENDS",
    "ZALO_FRIENDS",
    "ZALO_SEARCH_FRIENDS",
    "ZALO_FIND_FRIEND",
]

LIST_FRIENDS_DESCRIPTION = "List or search friends on the Zalo personal account"


@dataclass
class FriendInfo:
    """Friend information."""

    user_id: str
    display_name: str
    phone_number: str | None = None


@dataclass
class ListFriendsActionResult:
    """Result of list friends action."""

    success: bool
    action: str
    count: int = 0
    query: str | None = None
    friends: list[FriendInfo] = field(default_factory=list)
    error: str | None = None


async def handle_list_friends(
    query: str | None = None,
) -> ListFriendsActionResult:
    """Handle list friends action.

    Note: This is a placeholder that should be called through the service.
    """
    logger.info("List friends action: query=%s", query)

    return ListFriendsActionResult(
        success=True,
        action=LIST_FRIENDS_ACTION,
        count=0,
        query=query,
        friends=[],
    )


def validate_list_friends(service_available: bool) -> bool:
    """Validate that this action can run (service must be available)."""
    return service_available


# Action metadata for registration
LIST_FRIENDS_ACTION_META = {
    "name": LIST_FRIENDS_ACTION,
    "similes": LIST_FRIENDS_SIMILES,
    "description": LIST_FRIENDS_DESCRIPTION,
    "examples": [
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Show me my Zalo friends"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Here are your Zalo friends.",
                    "actions": [LIST_FRIENDS_ACTION],
                },
            },
        ],
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Search for a friend named Minh on Zalo"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Searching for friends matching that name.",
                    "actions": [LIST_FRIENDS_ACTION],
                },
            },
        ],
    ],
}
