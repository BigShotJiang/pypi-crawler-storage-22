"""List groups action for Zalo User."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

LIST_GROUPS_ACTION = "ZALOUSER_LIST_GROUPS"

LIST_GROUPS_SIMILES = [
    "ZALOUSER_GROUPS",
    "ZALO_LIST_GROUPS",
    "ZALO_GROUPS",
    "ZALO_SHOW_GROUPS",
]

LIST_GROUPS_DESCRIPTION = "List groups the Zalo personal account is a member of"


@dataclass
class GroupInfo:
    """Group information."""

    group_id: str
    name: str
    member_count: int | None = None


@dataclass
class ListGroupsActionResult:
    """Result of list groups action."""

    success: bool
    action: str
    count: int = 0
    groups: list[GroupInfo] = field(default_factory=list)
    error: str | None = None


async def handle_list_groups() -> ListGroupsActionResult:
    """Handle list groups action.

    Note: This is a placeholder that should be called through the service.
    """
    logger.info("List groups action")

    return ListGroupsActionResult(
        success=True,
        action=LIST_GROUPS_ACTION,
        count=0,
        groups=[],
    )


def validate_list_groups(service_available: bool) -> bool:
    """Validate that this action can run (service must be available)."""
    return service_available


# Action metadata for registration
LIST_GROUPS_ACTION_META = {
    "name": LIST_GROUPS_ACTION,
    "similes": LIST_GROUPS_SIMILES,
    "description": LIST_GROUPS_DESCRIPTION,
    "examples": [
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Show me my Zalo groups"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Here are your Zalo groups.",
                    "actions": [LIST_GROUPS_ACTION],
                },
            },
        ],
    ],
}
