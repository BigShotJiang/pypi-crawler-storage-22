"""Send image action for Zalo User."""

from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)

SEND_IMAGE_ACTION = "SEND_ZALOUSER_IMAGE"

SEND_IMAGE_SIMILES = [
    "ZALOUSER_SEND_IMAGE",
    "ZALOUSER_IMAGE",
    "ZALO_SEND_IMAGE",
    "ZALO_IMAGE",
    "ZALO_SEND_PHOTO",
]

SEND_IMAGE_DESCRIPTION = "Send an image to a Zalo chat via personal account"


@dataclass
class SendImageActionResult:
    """Result of send image action."""

    success: bool
    action: str
    thread_id: str
    image_url: str
    message_id: str | None = None
    error: str | None = None


async def handle_send_image(
    thread_id: str,
    image_url: str,
    caption: str = "",
    is_group: bool = False,
) -> SendImageActionResult:
    """Handle send image action.

    Note: This is a placeholder that should be called through the service.
    """
    logger.info(
        "Send image action: thread_id=%s, image_url=%s...",
        thread_id,
        image_url[:50],
    )

    return SendImageActionResult(
        success=True,
        action=SEND_IMAGE_ACTION,
        thread_id=thread_id,
        image_url=image_url,
    )


def validate_send_image(source: str | None) -> bool:
    """Validate that this action should handle the message."""
    return source == "zalouser"


# Action metadata for registration
SEND_IMAGE_ACTION_META = {
    "name": SEND_IMAGE_ACTION,
    "similes": SEND_IMAGE_SIMILES,
    "description": SEND_IMAGE_DESCRIPTION,
    "examples": [
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Send this photo to the Zalo chat"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Sending the image now.",
                    "actions": [SEND_IMAGE_ACTION],
                },
            },
        ],
    ],
}
