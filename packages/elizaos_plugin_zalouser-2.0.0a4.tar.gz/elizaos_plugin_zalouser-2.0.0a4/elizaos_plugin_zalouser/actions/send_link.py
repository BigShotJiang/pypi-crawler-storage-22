"""Send link action for Zalo User."""

from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)

SEND_LINK_ACTION = "SEND_ZALOUSER_LINK"

SEND_LINK_SIMILES = [
    "ZALOUSER_SEND_LINK",
    "ZALOUSER_LINK",
    "ZALO_SEND_LINK",
    "ZALO_LINK",
    "ZALO_SHARE_URL",
]

SEND_LINK_DESCRIPTION = "Send a link/URL to a Zalo chat via personal account"


@dataclass
class SendLinkActionResult:
    """Result of send link action."""

    success: bool
    action: str
    thread_id: str
    url: str
    message_id: str | None = None
    error: str | None = None


async def handle_send_link(
    thread_id: str,
    url: str,
    is_group: bool = False,
) -> SendLinkActionResult:
    """Handle send link action.

    Note: This is a placeholder that should be called through the service.
    """
    logger.info("Send link action: thread_id=%s, url=%s...", thread_id, url[:50])

    return SendLinkActionResult(
        success=True,
        action=SEND_LINK_ACTION,
        thread_id=thread_id,
        url=url,
    )


def validate_send_link(source: str | None) -> bool:
    """Validate that this action should handle the message."""
    return source == "zalouser"


# Action metadata for registration
SEND_LINK_ACTION_META = {
    "name": SEND_LINK_ACTION,
    "similes": SEND_LINK_SIMILES,
    "description": SEND_LINK_DESCRIPTION,
    "examples": [
        [
            {
                "name": "{{name1}}",
                "content": {"text": "Share this link in the Zalo chat"},
            },
            {
                "name": "{{agentName}}",
                "content": {
                    "text": "Sharing the link now.",
                    "actions": [SEND_LINK_ACTION],
                },
            },
        ],
    ],
}
