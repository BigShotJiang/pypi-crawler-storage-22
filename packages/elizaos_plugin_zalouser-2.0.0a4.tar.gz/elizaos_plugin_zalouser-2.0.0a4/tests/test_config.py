"""Tests for plugin-zalouser config module."""

import pytest

from elizaos_plugin_zalouser.config import (
    DEFAULT_PROFILE,
    DEFAULT_TIMEOUT_MS,
    MAX_MESSAGE_LENGTH,
    ZaloUserConfig,
    _parse_allowed_threads,
)


class TestZaloUserConfigCreation:
    """Test ZaloUserConfig construction and defaults."""

    def test_defaults(self) -> None:
        config = ZaloUserConfig()
        assert config.enabled is True
        assert config.default_profile == DEFAULT_PROFILE
        assert config.listen_timeout == DEFAULT_TIMEOUT_MS
        assert config.dm_policy == "pairing"
        assert config.group_policy == "disabled"
        assert config.allowed_threads == []
        assert config.cookie_path is None
        assert config.imei is None
        assert config.user_agent is None

    def test_custom_settings(self) -> None:
        config = ZaloUserConfig(
            cookie_path="/tmp/cookie",
            imei="test-imei",
            dm_policy="open",
            group_policy="open",
        )
        assert config.cookie_path == "/tmp/cookie"
        assert config.imei == "test-imei"
        assert config.dm_policy == "open"
        assert config.group_policy == "open"


class TestConstants:
    @pytest.mark.parametrize("const,expected", [
        (DEFAULT_PROFILE, "default"),
        (DEFAULT_TIMEOUT_MS, 30000),
        (MAX_MESSAGE_LENGTH, 2000),
    ])
    def test_values(self, const, expected) -> None:
        assert const == expected


class TestIsThreadAllowed:
    def test_empty_list_allows_all(self) -> None:
        config = ZaloUserConfig()
        assert config.is_thread_allowed("any") is True

    def test_allowed_thread(self) -> None:
        config = ZaloUserConfig(allowed_threads=["t1", "t2"])
        assert config.is_thread_allowed("t1") is True

    def test_disallowed_thread(self) -> None:
        config = ZaloUserConfig(allowed_threads=["t1", "t2"])
        assert config.is_thread_allowed("t3") is False


class TestValidateConfig:
    def test_valid_default(self) -> None:
        config = ZaloUserConfig()
        config.validate_config()  # Should not raise

    def test_disabled_raises(self) -> None:
        config = ZaloUserConfig(enabled=False)
        with pytest.raises(ValueError, match="disabled"):
            config.validate_config()


class TestParseAllowedThreads:
    @pytest.mark.parametrize("input_val,expected", [
        (None, []),
        ("", []),
        ("   ", []),
        ('["a", "b", "c"]', ["a", "b", "c"]),
        ("a, b, c", ["a", "b", "c"]),
        ("a,,b,,", ["a", "b"]),
    ])
    def test_parse(self, input_val, expected) -> None:
        assert _parse_allowed_threads(input_val) == expected

    def test_invalid_json_falls_through(self) -> None:
        assert isinstance(_parse_allowed_threads("[invalid json"), list)


class TestFromEnv:
    def test_defaults(self, monkeypatch: pytest.MonkeyPatch) -> None:
        for key in [
            "ZALOUSER_COOKIE_PATH", "ZALOUSER_IMEI", "ZALOUSER_USER_AGENT",
            "ZALOUSER_ENABLED", "ZALOUSER_DEFAULT_PROFILE", "ZALOUSER_LISTEN_TIMEOUT",
            "ZALOUSER_ALLOWED_THREADS", "ZALOUSER_DM_POLICY", "ZALOUSER_GROUP_POLICY",
        ]:
            monkeypatch.delenv(key, raising=False)

        config = ZaloUserConfig.from_env()
        assert config.enabled is True
        assert config.default_profile == "default"

    def test_custom_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ZALOUSER_ENABLED", "false")
        monkeypatch.setenv("ZALOUSER_DM_POLICY", "open")
        monkeypatch.setenv("ZALOUSER_ALLOWED_THREADS", "t1,t2")

        config = ZaloUserConfig.from_env()
        assert config.enabled is False
        assert config.dm_policy == "open"
        assert config.allowed_threads == ["t1", "t2"]
