"""Tests for plugin-zalouser error module."""

import pytest

from elizaos_plugin_zalouser.error import (
    AlreadyRunningError,
    ApiError,
    ChatNotFoundError,
    ClientNotInitializedError,
    CommandError,
    InvalidArgumentError,
    InvalidConfigError,
    NotAuthenticatedError,
    NotRunningError,
    SendError,
    TimeoutError,
    UserNotFoundError,
    ZaloUserError,
    ZcaNotInstalledError,
)


class TestErrorHierarchy:
    @pytest.mark.parametrize("err", [
        ZcaNotInstalledError(),
        NotAuthenticatedError(),
        InvalidConfigError("bad"),
        AlreadyRunningError(),
        NotRunningError(),
        ClientNotInitializedError(),
        CommandError("fail"),
        TimeoutError(5000),
        ApiError("rate limit"),
        SendError("network"),
        ChatNotFoundError("t1"),
        UserNotFoundError("u1"),
        InvalidArgumentError("empty"),
    ])
    def test_inherits_from_zalouser_error(self, err) -> None:
        assert isinstance(err, ZaloUserError)


class TestErrorMessages:
    def test_zca_not_installed(self) -> None:
        err = ZcaNotInstalledError()
        assert "npm install" in str(err)
        assert "zca-cli" in str(err)

    def test_not_authenticated_default(self) -> None:
        err = NotAuthenticatedError()
        assert "Not authenticated" in str(err)
        assert "zca auth login" in str(err)

    def test_not_authenticated_with_profile(self) -> None:
        assert "work" in str(NotAuthenticatedError(profile="work"))

    @pytest.mark.parametrize("err,expected", [
        (InvalidConfigError("missing field"), "missing field"),
        (AlreadyRunningError(), "already running"),
        (NotRunningError(), "not running"),
        (ClientNotInitializedError(), "not initialized"),
        (CommandError("segfault"), "segfault"),
        (ApiError("rate limit exceeded"), "rate limit"),
        (SendError("network error"), "network error"),
        (InvalidArgumentError("empty text"), "empty text"),
        (TimeoutError(30000), "30000"),
        (ChatNotFoundError("thread-42"), "thread-42"),
        (UserNotFoundError("user-99"), "user-99"),
    ])
    def test_message_contains_expected_text(self, err, expected: str) -> None:
        assert expected in str(err)
