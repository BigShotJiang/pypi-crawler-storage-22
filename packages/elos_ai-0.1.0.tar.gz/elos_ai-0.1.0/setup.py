from setuptools import setup, find_packages

setup(
    name="elos_ai",
    version="0.1.0",
    author="Hesham",
    description="Simple AI wrapper for Gemini and GPT3",
    packages=find_packages(),
    install_requires=[
        "requests"
    ],
    python_requires=">=3.8",
)