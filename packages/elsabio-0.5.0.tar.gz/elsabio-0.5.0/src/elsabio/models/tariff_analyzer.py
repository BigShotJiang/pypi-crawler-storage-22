# ElSabio
# Copyright (C) 2025-present Anton Lydell
# SPDX-License-Identifier: GPL-3.0-or-later
# See the LICENSE file in the project root for details.

r"""The data models of the Tariff Analyzer module."""

# Standard library
from enum import StrEnum
from typing import ClassVar

# Local
from elsabio.models.core import BaseDataFrameModel, ColumnList, DtypeMapping

# DuckDB column data types
FACILITY_ID_DTYPE = 'UINTEGER'
DATE_ID_DTYPE = 'DATE'
TARIFF_ID_DTYPE = 'USMALLINT'
TARIFF_COST_GROUP_ID_DTYPE = 'USMALLINT'
CUSTOMER_GROUP_ID_DTYPE = 'USMALLINT'
TARIFF_COMPONENT_TYPE_ID_DTYPE = 'USMALLINT'
TARIFF_COMPONENT_ID_DTYPE = 'UINTEGER'
TARIFF_PRICE_DTYPE = 'DECIMAL(20, 6)'
TARIFF_VALUE_DTYPE = 'DECIMAL(20, 3)'
SERIE_VALUE_DTYPE = 'DECIMAL(20, 3)'


class FacilityTypeEnum(StrEnum):
    r"""The available types of facilities.

    Members
    -------
    CONSUMPTION
        A consumption facility.

    PRODUCTION
        A production facility.
    """

    CONSUMPTION = 'consumption'
    PRODUCTION = 'production'


class CustomerTypeEnum(StrEnum):
    r"""The available types of customers.

    Members
    -------
    PRIVATE_PERSON
        A private person customer.

    COMPANY
        A company customer.
    """

    PRIVATE_PERSON = 'private_person'
    COMPANY = 'company'


class CustomerGroupMappingStrategyEnum(StrEnum):
    r"""The available types of customer group mapping strategies.

    Members
    -------
    FUSE_SIZE
        Map facilities to customer groups based on their contracted fuse size.

    SUBSCRIBED_POWER
        Map facilities to customer groups based on their subscribed power.

    CONNECTION_POWER
        Map facilities to customer groups based on their connection power.

    PRODUCT
        Map facilities to customer groups based on the product of their facility contract.
    """

    FUSE_SIZE = 'fuse_size'
    SUBSCRIBED_POWER = 'subscribed_power'
    CONNECTION_POWER = 'connection_power'
    PRODUCT = 'product'


class CalcStrategyEnum(StrEnum):
    r"""The available calculation strategies for tariff component types.

    Members
    -------
    FIXED
        A fixed price tariff component type without an associated meter data serie.

    PER_UNIT
        A tariff component type that is calculated per unit of a meter data serie
        e.g. energy or power.

    SUBSCRIBED_POWER
        A tariff component type that is calculated as a price multiplied by the
        subscribed power.

    CONNECTION_POWER
        A tariff component type that is calculated as a price multiplied by the
        connection power.

    OVERSHOOT_SUBSCRIBED_POWER
        A tariff component type where the configured meter data serie is compared
        to see if it exceeds the subscribed power.

    OVERSHOOT_CONNECTION_POWER
        A tariff component type where the configured meter data serie is compared
        to see if it exceeds the connection power.

    OVERSHOOT_COMPARISON_METER_DATA_SERIE
        A tariff component type where the configured meter data serie is compared
        to see if it exceeds its comparison meter data serie.
    """

    FIXED = 'fixed'
    PER_UNIT = 'per_unit'
    SUBSCRIBED_POWER = 'subscribed_power'
    CONNECTION_POWER = 'connection_power'
    OVERSHOOT_SUBSCRIBED_POWER = 'overshoot_subscribed_power'
    OVERSHOOT_CONNECTION_POWER = 'overshoot_connection_power'
    OVERSHOOT_COMPARISON_METER_DATA_SERIE = 'overshoot_comparison_meter_data_serie'


class PeriodizeStrategyEnum(StrEnum):
    r"""The available periodization strategies for tariff component types.

    Periodization means how to periodize a calculated revenue/cost into a
    monthly resolution.

    Members
    -------
    PER_MONTH
        A tariff component type with a price defined per month.

    PER_YEAR_DIVIDE_BY_12
        A tariff component type with a price defined per year where the resulting
        revenue/cost should be periodized per month by dividing by 12.

    PER_YEAR_PERIODIZE_OVER_MONTH_LENGTH
        A tariff component type with a price defined per year where the resulting
        revenue/cost should be periodized per month based on the length
        of the month in proportion to the year.
    """

    PER_MONTH = 'per_month'
    PER_YEAR_DIVIDE_BY_12 = 'per_year_divide_by_12'
    PER_YEAR_PERIODIZE_OVER_MONTH_LENGTH = 'per_year_periodize_over_month_length'


class FacilityTypeMappingDataFrameModel(BaseDataFrameModel):
    r"""A model of the facility types for mapping `code` to `facility_type_id`.

    Parameters
    ----------
    facility_type_id : int
        The unique ID of the facility type.

    code : str
        The unique code of the facility type.
    """

    c_facility_type_id: ClassVar[str] = 'facility_type_id'
    c_code: ClassVar[str] = 'code'

    dtypes: ClassVar[DtypeMapping] = {
        c_facility_type_id: 'uint32[pyarrow]',
        c_code: 'string[pyarrow]',
    }


class CustomerTypeMappingDataFrameModel(BaseDataFrameModel):
    r"""A model of the customer types for mapping `code` to `customer_type_id`.

    Parameters
    ----------
    customer_type_id : int
        The unique ID of the customer type.

    code : str
        The unique code of the customer type.
    """

    c_customer_type_id: ClassVar[str] = 'customer_type_id'
    c_code: ClassVar[str] = 'code'

    dtypes: ClassVar[DtypeMapping] = {
        c_customer_type_id: 'uint32[pyarrow]',
        c_code: 'string[pyarrow]',
    }


class FacilityMappingDataFrameModel(BaseDataFrameModel):
    r"""A model of the facilities for mapping `ean` to `facility_id`.

    Parameters
    ----------
    facility_id : int
        The unique ID of the facility.

    ean : int
        The unique EAN code of the facility.
    """

    c_facility_id: ClassVar[str] = 'facility_id'
    c_ean: ClassVar[str] = 'ean'

    dtypes: ClassVar[DtypeMapping] = {c_facility_id: 'uint32[pyarrow]', c_ean: 'uint64[pyarrow]'}


class FacilityImportDataFrameModel(BaseDataFrameModel):
    r"""A model of facilities to import to the database.

    Parameters
    ----------
    ean : int
        The unique EAN code of the facility.

    ean_prod : int or None
        The EAN code of the related production facility if the facility has one.

    facility_type_code : str
        The unique code of the type of facility.

    name : str or None
        A descriptive name of the facility.

    description : str or None
        A description of the facility.
    """

    c_ean: ClassVar[str] = 'ean'
    c_ean_prod: ClassVar[str] = 'ean_prod'
    c_facility_type_code: ClassVar[str] = 'facility_type_code'
    c_name: ClassVar[str] = 'name'
    c_description: ClassVar[str] = 'description'

    dtypes: ClassVar[DtypeMapping] = {
        c_ean: 'uint64[pyarrow]',
        c_ean_prod: 'uint64[pyarrow]',
        c_facility_type_code: 'string[pyarrow]',
        c_name: 'string[pyarrow]',
        c_description: 'string[pyarrow]',
    }


class FacilityDataFrameModel(BaseDataFrameModel):
    r"""A model of the facilities represented as a DataFrame.

    Parameters
    ----------
    facility_id : int
        The unique ID of the facility.

    ean : int
        The unique EAN code of the facility.

    ean_prod : int or None
        The EAN code of the related production facility if the facility has one.

    facility_type_id : int
        The type of facility.

    name : str or None
        A descriptive name of the facility.

    description : str or None
        A description of the facility.
    """

    c_facility_id: ClassVar[str] = 'facility_id'
    c_ean: ClassVar[str] = 'ean'
    c_ean_prod: ClassVar[str] = 'ean_prod'
    c_facility_type_id: ClassVar[str] = 'facility_type_id'
    c_name: ClassVar[str] = 'name'
    c_description: ClassVar[str] = 'description'

    dtypes: ClassVar[DtypeMapping] = {
        c_facility_id: 'uint32[pyarrow]',
        c_ean: 'uint64[pyarrow]',
        c_ean_prod: 'uint64[pyarrow]',
        c_facility_type_id: 'uint8[pyarrow]',
        c_name: 'string[pyarrow]',
        c_description: 'string[pyarrow]',
    }


class ProductMappingDataFrameModel(BaseDataFrameModel):
    r"""A model of the products for mapping `external_id` to `product_id`.

    Parameters
    ----------
    product_id : int
        The unique ID of the product.

    external_id : str
        The unique ID of the product in the parent system.
    """

    c_product_id: ClassVar[str] = 'product_id'
    c_external_id: ClassVar[str] = 'external_id'

    dtypes: ClassVar[DtypeMapping] = {
        c_product_id: 'uint16[pyarrow]',
        c_external_id: 'string[pyarrow]',
    }


class ProductImportDataFrameModel(BaseDataFrameModel):
    r"""A model of products to import to the database.

    Parameters
    ----------
    external_id : str
        The unique ID of the product in the parent system.

    name : str
        The unique name of the product.

    description : str or None
        A description of the product.
    """

    c_external_id: ClassVar[str] = 'external_id'
    c_name: ClassVar[str] = 'name'
    c_description: ClassVar[str] = 'description'

    dtypes: ClassVar[DtypeMapping] = {
        c_external_id: 'string[pyarrow]',
        c_name: 'string[pyarrow]',
        c_description: 'string[pyarrow]',
    }


class ProductDataFrameModel(BaseDataFrameModel):
    r"""Products that can be associated with facility contracts.

    Parameters
    ----------
    product_id : int
        The unique ID of the product.

    external_id : str
        The unique ID of the product in the parent system.

    name : str
        The unique name of the product.

    description : str or None
        A description of the product.
    """

    c_product_id: ClassVar[str] = 'product_id'
    c_external_id: ClassVar[str] = 'external_id'
    c_name: ClassVar[str] = 'name'
    c_description: ClassVar[str] = 'description'

    dtypes: ClassVar[DtypeMapping] = {
        c_product_id: 'uint16[pyarrow]',
        c_external_id: 'string[pyarrow]',
        c_name: 'string[pyarrow]',
        c_description: 'string[pyarrow]',
    }


class FacilityContractMappingDataFrameModel(BaseDataFrameModel):
    r"""A model for determining existing facility contracts by primary key.

    Parameters
    ----------
    facility_id : int
        The unique ID of the facility.

    date_id : datetime.date
        The month the contract data is valid for represented as the first
        day of the month in the configured business timezone of the app.
    """

    c_facility_id: ClassVar[str] = 'facility_id'
    c_date_id: ClassVar[str] = 'date_id'

    dtypes: ClassVar[DtypeMapping] = {c_facility_id: 'uint32[pyarrow]'}

    parse_dates: ClassVar[ColumnList] = [c_date_id]


class FacilityContractImportDataFrameModel(BaseDataFrameModel):
    r"""Contract related information of a facility to import to the database.

    Parameters
    ----------
    ean : int
        The unique EAN code of the facility.

    date_id : datetime.date
        The month the contract data is valid for represented as the first day of the month in
        in the configured business timezone of the app.

    fuse_size : int or None
        The contracted fuse size [A].

    subscribed_power : float or None
        The subscribed power [kW].

    connection_power : float or None
        The connection power of the facility [kW].

    account_nr : int or None
        The bookkeeping account of the facility contract.

    customer_type_code : str
        The unique code of the type of customer associated with the facility contract.

    ext_product_id : int or None
        The external ID of the product that the facility contract belongs to. The ID
        is external from the perspective of ElSabio and internal to the parent system.
    """

    c_ean: ClassVar[str] = 'ean'
    c_date_id: ClassVar[str] = 'date_id'
    c_fuse_size: ClassVar[str] = 'fuse_size'
    c_subscribed_power: ClassVar[str] = 'subscribed_power'
    c_connection_power: ClassVar[str] = 'connection_power'
    c_account_nr: ClassVar[str] = 'account_nr'
    c_customer_type_code: ClassVar[str] = 'customer_type_code'
    c_ext_product_id: ClassVar[str] = 'ext_product_id'

    dtypes: ClassVar[DtypeMapping] = {
        c_ean: 'uint64[pyarrow]',
        c_fuse_size: 'uint16[pyarrow]',
        c_subscribed_power: 'float64[pyarrow]',
        c_connection_power: 'float64[pyarrow]',
        c_account_nr: 'uint16[pyarrow]',
        c_customer_type_code: 'string[pyarrow]',
        c_ext_product_id: 'string[pyarrow]',
    }

    parse_dates: ClassVar[list[str]] = [c_date_id]


class FacilityContractDataFrameModel(BaseDataFrameModel):
    r"""Contract related information of a facility valid per month.

    Parameters
    ----------
    facility_id : int
        The unique ID of the facility.

    date_id : datetime.date
        The month the contract data is valid for represented as the first day of the month in
        in the configured business timezone of the app.

    fuse_size : int or None
        The contracted fuse size [A].

    subscribed_power : float or None
        The subscribed power [kW].

    connection_power : float or None
        The connection power of the facility [kW].

    account_nr : int or None
        The bookkeeping account of the facility contract.

    customer_type_id : int
        The ID of the type of customer associated with the facility contract.

    product_id : int or None
        The ID of the product associated with the facility contract.
    """

    c_facility_id: ClassVar[str] = 'facility_id'
    c_date_id: ClassVar[str] = 'date_id'
    c_fuse_size: ClassVar[str] = 'fuse_size'
    c_subscribed_power: ClassVar[str] = 'subscribed_power'
    c_connection_power: ClassVar[str] = 'connection_power'
    c_account_nr: ClassVar[str] = 'account_nr'
    c_customer_type_id: ClassVar[str] = 'customer_type_id'
    c_product_id: ClassVar[str] = 'product_id'

    dtypes: ClassVar[DtypeMapping] = {
        c_facility_id: 'uint32[pyarrow]',
        c_fuse_size: 'uint16[pyarrow]',
        c_subscribed_power: 'float64[pyarrow]',
        c_connection_power: 'float64[pyarrow]',
        c_account_nr: 'uint16[pyarrow]',
        c_customer_type_id: 'uint16[pyarrow]',
        c_product_id: 'uint16[pyarrow]',
    }

    parse_dates: ClassVar[list[str]] = [c_date_id]


class FacilityContractExtendedDataFrameModel(FacilityContractDataFrameModel):
    r""":class:`FacilityContractDataFrameModel` with extended information.

    Parameters
    ----------
    facility_type_id : int
        The unique ID of the type of facility associated with the contract.
    """

    c_facility_type_id: ClassVar[str] = 'facility_type_id'

    dtypes: ClassVar[DtypeMapping] = FacilityContractDataFrameModel.dtypes | {
        c_facility_type_id: 'uint8[pyarrow]'
    }


class SerieValueImportDataFrameModel(BaseDataFrameModel):
    r"""The values of a meter data serie to import to the parquet hive.

    Parameters
    ----------
    serie_type_code : str
        The unique code of the type of serie the meter data represents.

    ean : int
        The unique EAN code of the facility.

    date_id : datetime.date
        The month the meter data covers represented as the first day of the month
        in the configured business timezone of the app.

    serie_value : float
        The meter data value.

    status_id : str
        The status value of `serie_value`.
    """

    c_serie_type_code: ClassVar[str] = 'serie_type_code'
    c_ean: ClassVar[str] = 'ean'
    c_date_id: ClassVar[str] = 'date_id'
    c_serie_value: ClassVar[str] = 'serie_value'
    c_status_id: ClassVar[str] = 'status_id'

    dtypes: ClassVar[DtypeMapping] = {
        c_serie_type_code: 'string[pyarrow]',
        c_ean: 'uint64[pyarrow]',
        c_serie_value: 'float64[pyarrow]',
        c_status_id: 'string[pyarrow]',
    }

    parse_dates: ClassVar[list[str]] = [c_date_id]


class SerieValueDataFrameModel(BaseDataFrameModel):
    r"""The values of a meter data serie.

    Parameters
    ----------
    serie_type_code : str
        The unique code of the type of serie the meter data represents.

    facility_id : int
        The unique ID of the facility that the serie values belong to.

    ean : int
        The unique EAN code of the facility.

    date_id : datetime.date
        The month the meter data covers represented as the first day of the month
        in the configured business timezone of the app.

    serie_value : float
        The meter data value.

    status_id : str
        The status value of `serie_value`.
    """

    c_serie_type_code: ClassVar[str] = 'serie_type_code'
    c_facility_id: ClassVar[str] = 'facility_id'
    c_ean: ClassVar[str] = 'ean'
    c_date_id: ClassVar[str] = 'date_id'
    c_serie_value: ClassVar[str] = 'serie_value'
    c_status_id: ClassVar[str] = 'status_id'

    dtypes: ClassVar[DtypeMapping] = {
        c_serie_type_code: 'string[pyarrow]',
        c_facility_id: 'uint32[pyarrow]',
        c_ean: 'uint64[pyarrow]',
        c_serie_value: 'float64[pyarrow]',
        c_status_id: 'string[pyarrow]',
    }

    parse_dates: ClassVar[list[str]] = [c_date_id]


class CustomerGroupDataFrameModel(BaseDataFrameModel):
    r"""A facility is part of a customer group based on its facility contract information.

    Parameters
    ----------
    customer_group_id : int
       The unique ID of the customer group.

    code : str
        The unique code of the customer group.

    name : str
        The name of the customer group.

    min_fuse_size : int or None
        The minimum fuse size [A] of the customer group.

    max_fuse_size : int or None
        The maximum fuse size [A] of the customer group.

    min_subscribed_power : float or None
        The minimum subscribed power of the customer group [kW].

    max_subscribed_power : float or None
        The maximum subscribed power of the customer group [kW].

    min_connection_power : float or None
        The minimum connection power of the customer group [kW].

    max_connection_power : float or None
        The maximum connection power of the customer group [kW].

    min_bound_included : bool, default True
        True if the minimum bound is included in the range when applying the customer
        group mapping strategy from `mapping_strategy_id` and False to exclude it.

    max_bound_included : bool, default True
        True if the maximum bound is included in the range when applying the customer
        group mapping strategy from `mapping_strategy_id` and False to exclude it.

    facility_type_id : int
        The type of facility that can be associated with the customer group.

    customer_type_id : int or None
        The type of customer that can be associated with the customer group.

    product_id : int or None
        The product of a facility contract associated with the customer group. Used
        for mapping facilities to a customer group based on the product of a facility
        contract.

    not_product_id : int or None
        The product of a facility contract to not associate with the customer group. Used
        for mapping facilities to a customer group based on a facility contract not having
        the specified product.

    mapping_strategy_id : int
        The ID of the customer group mapping strategy to apply to map facilities to a customer
        group.

    mapping_strategy_code : str
        The unique code of the customer group mapping strategy to apply to map facilities to a
        customer group.
    """

    c_customer_group_id: ClassVar[str] = 'customer_group_id'
    c_code: ClassVar[str] = 'code'
    c_name: ClassVar[str] = 'name'
    c_min_fuse_size: ClassVar[str] = 'min_fuse_size'
    c_max_fuse_size: ClassVar[str] = 'max_fuse_size'
    c_min_subscribed_power: ClassVar[str] = 'min_subscribed_power'
    c_max_subscribed_power: ClassVar[str] = 'max_subscribed_power'
    c_min_connection_power: ClassVar[str] = 'min_connection_power'
    c_max_connection_power: ClassVar[str] = 'max_connection_power'
    c_min_bound_included: ClassVar[str] = 'min_bound_included'
    c_max_bound_included: ClassVar[str] = 'max_bound_included'
    c_facility_type_id: ClassVar[str] = 'facility_type_id'
    c_customer_type_id: ClassVar[str] = 'customer_type_id'
    c_product_id: ClassVar[str] = 'product_id'
    c_not_product_id: ClassVar[str] = 'not_product_id'
    c_mapping_strategy_id: ClassVar[str] = 'mapping_strategy_id'
    c_mapping_strategy_code: ClassVar[str] = 'mapping_strategy_code'

    dtypes: ClassVar[DtypeMapping] = {
        c_customer_group_id: 'uint16[pyarrow]',
        c_code: 'string[pyarrow]',
        c_name: 'string[pyarrow]',
        c_min_fuse_size: 'uint16[pyarrow]',
        c_max_fuse_size: 'uint16[pyarrow]',
        c_min_subscribed_power: 'float64[pyarrow]',
        c_max_subscribed_power: 'float64[pyarrow]',
        c_min_connection_power: 'float64[pyarrow]',
        c_max_connection_power: 'float64[pyarrow]',
        c_min_bound_included: 'bool[pyarrow]',
        c_max_bound_included: 'bool[pyarrow]',
        c_facility_type_id: 'uint8[pyarrow]',
        c_customer_type_id: 'uint16[pyarrow]',
        c_product_id: 'uint16[pyarrow]',
        c_not_product_id: 'uint16[pyarrow]',
        c_mapping_strategy_id: 'uint8[pyarrow]',
        c_mapping_strategy_code: 'string[pyarrow]',
    }


class FacilityCustomerGroupLinkDataFrameModel(BaseDataFrameModel):
    r"""The link between a facility and a customer group.

    Parameters
    ----------
    facility_id : int
        The unique ID of the facility.

    date_id : datetime.date
        The month the link is valid for represented as the first day of the month in the
        configured business timezone of the app.

    customer_group_id : int
        The unique ID of the customer group the facility is part of.
    """

    c_facility_id: ClassVar[str] = 'facility_id'
    c_date_id: ClassVar[str] = 'date_id'
    c_customer_group_id: ClassVar[str] = 'customer_group_id'

    dtypes: ClassVar[DtypeMapping] = {
        c_facility_id: 'uint32[pyarrow]',
        c_customer_group_id: 'uint16[pyarrow]',
    }

    parse_dates: ClassVar[list[str]] = [c_date_id]


class TariffCalculationDataFrameModel(BaseDataFrameModel):
    r"""The model of the input dataset to the tariff calculations.

    Parameters
    ----------
    facility_id : int
        The unique ID of the facility the tariff value references.

    date_id : datetime.date
        The month the tariff value is valid for represented as the first day of
        the month in in the configured business timezone of the app.

    tariff_id : int
        The unique ID of the tariff that the computed value is associated with.

    tariff_cost_group_id : int
        The unique ID of the tariff cost group that the facility belongs to.

    customer_group_id : int
        The unique ID of the customer group that the facility belongs to.

    tariff_component_type_id : int
        The unique ID of type of tariff component that the tariff value is calculated from.

    tariff_component_id : int
        The unique ID of the tariff component that the tariff value is calculated from.

    calc_strategy_code : str
        The unique code of the calculation strategy to apply to the tariff calculations.

    periodize_strategy_code : str
        The unique code of the periodization strategy to to periodize the calculated tariff value
        to a monthly resolution.

    total_price : float
        The total price of the tariff component that was used in the tariff value calculation.
        The total price is the sum of `price` and `authority_fee`.

    price : float
        The price of the tariff component that was used in the tariff value calculation.

    authority_fee : float
        The authority fee of the tariff component that was used in the tariff value calculation.

    subscribed_power : float
        The subscribed power from the contract of the facility [kW].

    connection_power : float
        The connection power from the contract of the facility [kW].

    serie_type_code : str
        The unique code of the meter data serie to use in the calculation of a tariff component.

    comparison_serie_type_code : str
        The unique code of the meter data serie to compare against `serie_type_code` in
        tariff calculations for overshoot components.

    overshoot_limit : float
        The allowed limit of an overshoot component. in relation to `subscribed_power`,
        `connection_power` or `comparison_serie_value`.
    """

    c_facility_id: ClassVar[str] = 'facility_id'
    c_date_id: ClassVar[str] = 'date_id'

    c_tariff_id: ClassVar[str] = 'tariff_id'
    c_tariff_cost_group_id: ClassVar[str] = 'tariff_cost_group_id'
    c_customer_group_id: ClassVar[str] = 'customer_group_id'
    c_tariff_component_type_id: ClassVar[str] = 'tariff_component_type_id'
    c_tariff_component_id: ClassVar[str] = 'tariff_component_id'

    c_calc_strategy_code: ClassVar[str] = 'calc_strategy_code'
    c_periodize_strategy_code: ClassVar[str] = 'periodize_strategy_code'

    c_total_price: ClassVar[str] = 'total_price'
    c_price: ClassVar[str] = 'price'
    c_authority_fee: ClassVar[str] = 'authority_fee'

    c_subscribed_power: ClassVar[str] = 'subscribed_power'
    c_connection_power: ClassVar[str] = 'connection_power'
    c_serie_type_code: ClassVar[str] = 'serie_type_code'
    c_comparison_serie_type_code: ClassVar[str] = 'comparison_serie_type_code'
    c_overshoot_limit: ClassVar[str] = 'overshoot_limit'

    duckdb_dtypes: ClassVar[DtypeMapping] = {
        c_facility_id: FACILITY_ID_DTYPE,
        c_date_id: DATE_ID_DTYPE,
        c_tariff_id: TARIFF_ID_DTYPE,
        c_tariff_cost_group_id: TARIFF_COST_GROUP_ID_DTYPE,
        c_customer_group_id: CUSTOMER_GROUP_ID_DTYPE,
        c_tariff_component_type_id: TARIFF_COMPONENT_TYPE_ID_DTYPE,
        c_tariff_component_id: TARIFF_COMPONENT_ID_DTYPE,
        c_calc_strategy_code: 'VARCHAR',
        c_periodize_strategy_code: 'VARCHAR',
        c_total_price: TARIFF_PRICE_DTYPE,
        c_price: TARIFF_PRICE_DTYPE,
        c_authority_fee: TARIFF_PRICE_DTYPE,
        c_overshoot_limit: 'DECIMAL(9, 6)',
        c_subscribed_power: SERIE_VALUE_DTYPE,
        c_connection_power: SERIE_VALUE_DTYPE,
        c_serie_type_code: 'VARCHAR',
        c_comparison_serie_type_code: 'VARCHAR',
    }

    parse_dates: ClassVar[list[str]] = [c_date_id]


class TariffCalculationExtendedDataFrameModel(TariffCalculationDataFrameModel):
    r"""The extended dataset of input data to the tariff calculations.

    Parameters
    ----------
    periodization_factor : float
        The multiplication factor to periodize a tariff value into monthly resolution.

    total_value : float
        The total tariff value of the tariff component.
        The total value is the sum of `price_value` and `authority_fee_value`.

    price_value : float
        The tariff value of the price part of the tariff component.

    authority_fee_value : float
        The tariff value of the authority fee part of the tariff component.
    """

    c_periodization_factor: ClassVar[str] = 'periodization_factor'
    c_total_value: ClassVar[str] = 'total_value'
    c_price_value: ClassVar[str] = 'price_value'
    c_authority_fee_value: ClassVar[str] = 'authority_fee_value'
    c_serie_value: ClassVar[str] = 'serie_value'
    c_comparison_serie_value: ClassVar[str] = 'comparison_serie_value'
    c_overshoot_value: ClassVar[str] = 'overshoot_value'

    duckdb_dtypes: ClassVar[DtypeMapping] = TariffCalculationDataFrameModel.duckdb_dtypes | {
        c_periodization_factor: 'DOUBLE',
        c_total_value: TARIFF_VALUE_DTYPE,
        c_price_value: TARIFF_VALUE_DTYPE,
        c_authority_fee_value: TARIFF_VALUE_DTYPE,
        c_serie_value: SERIE_VALUE_DTYPE,
        c_comparison_serie_value: SERIE_VALUE_DTYPE,
        c_overshoot_value: SERIE_VALUE_DTYPE,
    }


class TariffValueFacilityDataFrameModel(BaseDataFrameModel):
    r"""The tariff value (revenue/cost) per facility and tariff component.

    Parameters
    ----------
    facility_id : int
        The unique ID of the facility the tariff value references.

    date_id : datetime.date
        The month the tariff value is valid for represented as the first day of the month in
        in the configured business timezone of the app.

    tariff_id : int
        The unique ID of the tariff that the computed value is associated with.

    tariff_cost_group_id : int
        The unique ID of the tariff cost group that the facility belongs to.

    customer_group_id : int
        The unique ID of the customer group that the facility belongs to.

    tariff_component_type_id : int
        The unique ID of type of tariff component that the tariff value is calculated from.

    tariff_component_id : int
        The unique ID of the tariff component that the tariff value is calculated from.

    total_price : float
        The total price of the tariff component that was used in the tariff value calculation.
        The total price is the sum of `price` and `authority_fee`.

    total_value : float
        The total tariff value of the tariff component.
        The total value is the sum of `price_value` and `authority_fee_value`.

    price : float
        The price of the tariff component that was used in the tariff value calculation.

    price_value : float
        The tariff value of the price part of the tariff component.

    authority_fee : float
        The authority fee of the tariff component that was used in the tariff value calculation.

    authority_fee_value : float
        The tariff value of the authority fee part of the tariff component.

    serie_value : float
        The meter data serie, subscribed power or connection power that was used in
        the tariff value calculation.

    comparison_serie_value : float
        The meter data serie, subscribed power or connection power that was compared
        against `serie_value` in the tariff value calculation.

    overshoot_value : float or None
        The calculated overshoot value for overshoot components.
    """

    c_facility_id: ClassVar[str] = 'facility_id'
    c_date_id: ClassVar[str] = 'date_id'
    c_tariff_id: ClassVar[str] = 'tariff_id'
    c_tariff_cost_group_id: ClassVar[str] = 'tariff_cost_group_id'
    c_customer_group_id: ClassVar[str] = 'customer_group_id'
    c_tariff_component_type_id: ClassVar[str] = 'tariff_component_type_id'
    c_tariff_component_id: ClassVar[str] = 'tariff_component_id'

    c_total_price: ClassVar[str] = 'total_price'
    c_total_value: ClassVar[str] = 'total_value'
    c_price: ClassVar[str] = 'price'
    c_price_value: ClassVar[str] = 'price_value'
    c_authority_fee: ClassVar[str] = 'authority_fee'
    c_authority_fee_value: ClassVar[str] = 'authority_fee_value'

    c_serie_value: ClassVar[str] = 'serie_value'
    c_comparison_serie_value: ClassVar[str] = 'comparison_serie_value'
    c_overshoot_value: ClassVar[str] = 'overshoot_value'

    duckdb_dtypes: ClassVar[DtypeMapping] = {
        c_facility_id: FACILITY_ID_DTYPE,
        c_date_id: DATE_ID_DTYPE,
        c_tariff_id: TARIFF_ID_DTYPE,
        c_tariff_cost_group_id: TARIFF_COST_GROUP_ID_DTYPE,
        c_customer_group_id: CUSTOMER_GROUP_ID_DTYPE,
        c_tariff_component_type_id: TARIFF_COMPONENT_TYPE_ID_DTYPE,
        c_tariff_component_id: TARIFF_COMPONENT_ID_DTYPE,
        c_total_price: TARIFF_PRICE_DTYPE,
        c_total_value: TARIFF_VALUE_DTYPE,
        c_price: TARIFF_PRICE_DTYPE,
        c_price_value: TARIFF_VALUE_DTYPE,
        c_authority_fee: TARIFF_PRICE_DTYPE,
        c_authority_fee_value: TARIFF_VALUE_DTYPE,
        c_serie_value: SERIE_VALUE_DTYPE,
        c_comparison_serie_value: SERIE_VALUE_DTYPE,
        c_overshoot_value: SERIE_VALUE_DTYPE,
    }

    parse_dates: ClassVar[list[str]] = [c_date_id]


class TariffValueTotalDataFrameModel(BaseDataFrameModel):
    r"""The total tariff value (revenue/cost) per tariff component.

    Parameters
    ----------
    tariff_id : int
        The unique ID of the tariff that the computed value is associated with.

    date_id : datetime.date
        The month the tariff value is valid for represented as the first day of the month in
        in the configured business timezone of the app.

    tariff_cost_group_id : int
        The unique ID of the tariff cost group associated with the tariff value.

    customer_group_id : int
        The unique ID of the customer group associated with the tariff value.

    tariff_component_type_id : int
        The unique ID of type of tariff component that the tariff value is calculated from.

    tariff_component_id : int
        The unique ID of the tariff component that the tariff value is calculated from.

    total_value : float
        The total tariff value of the tariff component.
        The total value is the sum of `price_value` and `authority_fee_value`.

    price_value : float
        The tariff value of the price part of the tariff component.

    authority_fee_value : float
        The tariff value of the authority fee part of the tariff component.
    """

    c_tariff_id: ClassVar[str] = 'tariff_id'
    c_date_id: ClassVar[str] = 'date_id'
    c_tariff_cost_group_id: ClassVar[str] = 'tariff_cost_group_id'
    c_customer_group_id: ClassVar[str] = 'customer_group_id'
    c_tariff_component_type_id: ClassVar[str] = 'tariff_component_type_id'
    c_tariff_component_id: ClassVar[str] = 'tariff_component_id'
    c_total_value: ClassVar[str] = 'total_value'
    c_price_value: ClassVar[str] = 'price_value'
    c_authority_fee_value: ClassVar[str] = 'authority_fee_value'

    duckdb_dtypes: ClassVar[DtypeMapping] = {
        c_tariff_id: TARIFF_ID_DTYPE,
        c_date_id: DATE_ID_DTYPE,
        c_tariff_cost_group_id: TARIFF_COST_GROUP_ID_DTYPE,
        c_customer_group_id: CUSTOMER_GROUP_ID_DTYPE,
        c_tariff_component_type_id: TARIFF_COMPONENT_TYPE_ID_DTYPE,
        c_tariff_component_id: TARIFF_COMPONENT_ID_DTYPE,
        c_total_value: TARIFF_VALUE_DTYPE,
        c_price_value: TARIFF_VALUE_DTYPE,
        c_authority_fee_value: TARIFF_VALUE_DTYPE,
    }

    parse_dates: ClassVar[list[str]] = [c_date_id]
