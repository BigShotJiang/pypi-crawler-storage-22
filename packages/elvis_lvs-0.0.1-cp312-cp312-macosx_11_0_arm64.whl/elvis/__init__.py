import json
import os
import sys
import tempfile

from elvis._elvis import (
    DEFAULT_TOLERANCE_NM,
)
from elvis._elvis import (
    cli as _cli_inner,
)
from elvis._elvis import (
    convert as _convert,
)
from elvis._elvis import (
    extract_netlist as _extract_netlist,
)
from elvis._elvis import (
    extract_ports as _extract_ports,
)
from elvis._elvis import (
    lvs as _lvs,
)
from elvis._elvis import (
    lvs_ok as _lvs_ok,
)


def _cli():
    """Entry point for the ``elvis`` console script."""
    _cli_inner(sys.argv)


def extract_netlist(gds_path, tolerance_nm=None):
    """Extract netlist from a GDS file.

    Args:
        gds_path: Path to the GDS file.
        tolerance_nm: Port matching tolerance in nanometers (default: from config or 1).

    Returns:
        dict with keys: instances, nets, ports.
    """
    if tolerance_nm is None:
        tolerance_nm = DEFAULT_TOLERANCE_NM
    return json.loads(
        _extract_netlist(gds_path, format="json", tolerance_nm=tolerance_nm)
    )


def extract_ports(gds_path):
    """Extract component port table from a GDS file.

    Returns a mapping of component name to list of port names,
    as parsed from the GDS cell metadata (kfactory port properties).

    Args:
        gds_path: Path to the GDS file.

    Returns:
        dict mapping component name to list of port names.
    """
    return json.loads(_extract_ports(gds_path, format="json"))


def convert(input_path):
    """Convert a GDSFactory netlist (.pic.yml) to elvis-netlist format.

    Args:
        input_path: Path to the input netlist (.pic.yml).

    Returns:
        dict with keys: instances, nets, ports.
    """
    return json.loads(_convert(input_path, format="json"))


def lvs_ok(schematic_path, layout_path, tolerance_nm=None):
    """Check if LVS passes between a schematic and layout.

    Convenience function that returns a boolean instead of a full report.

    Args:
        schematic_path: Path to schematic netlist (.pic.yml or extracted .yml).
        layout_path: Path to layout GDS file.
        tolerance_nm: Port matching tolerance in nanometers (default: from config or 1).

    Returns:
        True if LVS passes (no errors), False otherwise.
    """
    return _lvs_ok(schematic_path, layout_path, tolerance_nm=tolerance_nm)


def lvs_rdb(
    schematic_path,
    layout_path,
    tolerance_nm=None,
    short_layers=None,
    connected_layers=None,
    equivalent_ports=None,
    top_cell=None,
):
    """Run LVS comparison between a schematic and layout.

    Args:
        schematic_path: Path to schematic netlist (.pic.yml or extracted .yml).
        layout_path: Path to layout GDS file.
        tolerance_nm: Port matching tolerance in nanometers (default: from config or 1).
        short_layers: List of (layer, datatype) tuples to check for shorts.
        connected_layers: List of ((l1, d1), (l2, d2)) tuples for cross-layer short detection.
        equivalent_ports: List of (component, [port1, port2, ...]) tuples for port grouping.
        top_cell: Override top cell name for hierarchical schematics.

    Returns:
        klayout.rdb.ReportDatabase with LVS results.

    Raises:
        ImportError: If klayout is not installed (pip install elvis[klayout]).
    """
    try:
        import klayout.rdb as rdb
    except ImportError:
        raise ImportError(
            "klayout is required for elvis.lvs(). "
            "Install it with: pip install elvis[klayout]"
        ) from None

    lyrdb_str = _lvs(
        schematic_path,
        layout_path,
        format="lyrdb",
        tolerance_nm=tolerance_nm,
        short_layers=short_layers,
        connected_layers=connected_layers,
        equivalent_ports=equivalent_ports,
        top_cell=top_cell,
    )
    db = rdb.ReportDatabase("")
    with tempfile.NamedTemporaryFile(suffix=".lyrdb", delete=False, mode="w") as f:
        f.write(lyrdb_str)
        tmp_path = f.name
    try:
        db.load(tmp_path)
    finally:
        os.unlink(tmp_path)
    return db


def lvs(
    schematic_path,
    layout_path,
    tolerance_nm=None,
    short_layers=None,
    connected_layers=None,
    equivalent_ports=None,
    top_cell=None,
):
    """Run LVS comparison between a schematic and layout.

    Same as lvs() but returns a dict instead of a klayout ReportDatabase.

    Args:
        schematic_path: Path to schematic netlist (.pic.yml or extracted .yml).
        layout_path: Path to layout GDS file.
        tolerance_nm: Port matching tolerance in nanometers (default: from config or 1).
        short_layers: List of (layer, datatype) tuples to check for shorts.
        connected_layers: List of ((l1, d1), (l2, d2)) tuples for cross-layer short detection.
        equivalent_ports: List of (component, [port1, port2, ...]) tuples for port grouping.
        top_cell: Override top cell name for hierarchical schematics.

    Returns:
        dict with keys: ok, error_count, instance_errors, net_errors, port_errors,
        open_errors, short_errors.
    """
    return json.loads(
        _lvs(
            schematic_path,
            layout_path,
            format="json",
            tolerance_nm=tolerance_nm,
            short_layers=short_layers,
            connected_layers=connected_layers,
            equivalent_ports=equivalent_ports,
            top_cell=top_cell,
        )
    )
