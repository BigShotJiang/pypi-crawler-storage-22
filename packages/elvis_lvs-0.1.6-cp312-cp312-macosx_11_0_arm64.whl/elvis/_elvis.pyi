# flake8: noqa: PYI021
def cli(args):
    """Run the elvis CLI with the given arguments.

    This is used by the `elvis` console script entry point.
    Pass `sys.argv` to get the same behavior as running the
    Rust binary directly.

    Args:
        args: Command-line arguments (e.g. sys.argv)

    """

def convert(netlist_json, format="json"):
    """Convert a GDSFactory netlist to elvis-netlist format.

    Args:
        netlist_json: JSON string of the netlist (flat or recursive GDSFactory format)
        format: Output format, either "yaml" (default) or "json"

    Returns:
        The converted netlist as a string in the specified format

    """

def extract_netlist(gds_path, format="yaml", tolerance_nm=...):
    """Extract a netlist from a GDS file.

    Args:
        gds_path: Path to the GDS file
        format: Output format, either "yaml" (default) or "json"
        tolerance_nm: Port matching tolerance in nanometers (default: 1)

    Returns:
        The extracted netlist as a string in the specified format

    """

def extract_ports(gds_path, format="yaml"):
    """Extract component port table from a GDS file.

    Returns a mapping of component name → list of port names, as parsed from
    the GDS cell metadata (kfactory port properties).

    Args:
        gds_path: Path to the GDS file
        format: Output format, either "yaml" (default) or "json"

    Returns:
        The component port table as a string in the specified format

    """

def load_schematics(paths):
    """Load one or more schematic files (.pic.yml) and return the merged
    GDSFactory netlist as a JSON string.

    Each entry can be a plain path or `"name:path"` to override the
    component name used for flat netlists.

    Args:
        paths: List of paths or "name:path" strings

    Returns:
        JSON string of the recursive GDSFactory netlist

    """

def lvs(
    layout_path,
    schematic_json,
    format="yaml",
    tolerance_nm=None,
    short_layers=None,
    connected_layers=None,
    equivalent_ports=None,
    top_cell=None,
):
    """Run LVS comparison between a schematic and layout.

    Args:
        layout_path: Path to layout GDS file
        schematic_json: JSON string of schematic (recursive GDSFactory netlist)
        format: Output format - "yaml" (default), "json", or "lyrdb"
        tolerance_nm: Port matching tolerance in nanometers (default: 1)
        short_layers: List of (layer, datatype) tuples to check for shorts (default: None)
        connected_layers: List of ((l1, d1), (l2, d2)) tuples for cross-layer short detection (default: None)
        equivalent_ports: List of (component, [port1, port2, ...]) tuples for port grouping (default: None)
        top_cell: Override top cell name for hierarchical schematics (default: None)

    Returns:
        The LVS report as a string in the specified format

    """

def lvs_ok(layout_path, schematic_json, tolerance_nm=None):
    """Check if LVS passes between a schematic and layout.

    This is a convenience function that returns a boolean instead of a report.

    Args:
        layout_path: Path to layout GDS file
        schematic_json: JSON string of schematic (recursive GDSFactory netlist)
        tolerance_nm: Port matching tolerance in nanometers (default: 1)

    Returns:
        True if LVS passes (no errors), False otherwise

    """

def simplify(netlist_json, remove_twoports, format="json"):
    """Simplify a netlist by removing 2-port routing instances.

    Args:
        netlist_json: JSON string of the netlist (flat or recursive GDSFactory format)
        remove_twoports: Filter for which 2-port instances to remove.
            Use ["all"] to remove all 2-port instances, or a list of component
            names (e.g. ["straight", "bend_euler"]) to remove only those types.
        format: Output format, either "yaml" (default) or "json"

    Returns:
        The simplified netlist as a string in the specified format

    """
