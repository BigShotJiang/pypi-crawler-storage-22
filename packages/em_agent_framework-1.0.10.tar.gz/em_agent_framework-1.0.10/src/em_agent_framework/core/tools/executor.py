"""
Tool executor with support for parallel execution and context injection.
"""

import asyncio
import inspect
from typing import Any, Callable, Dict, List, Optional, Tuple

from .utils import coerce_types


class ToolExecutor:
    """
    Executes tools (functions) with context injection, type coercion, and parallel execution.
    """

    def __init__(
        self,
        tools: List[Callable],
        complementary_tools: Optional[List[Callable]] = None,
        context: Optional[dict] = None,
        enable_parallel: bool = True,
        max_parallel: int = 5,
    ):
        """
        Initialize the ToolExecutor.

        Args:
            tools: List of active tools
            complementary_tools: List of tools not in context by default
            context: Context dictionary to inject into function calls
            enable_parallel: Whether to enable parallel execution
            max_parallel: Maximum number of parallel executions
        """
        self.tools = {tool.__name__: tool for tool in tools}
        self.complementary_tools = complementary_tools or []
        self.complementary_tool_names = {tool.__name__ for tool in self.complementary_tools}
        self.context = context or {}
        self.enable_parallel = enable_parallel
        self.max_parallel = max_parallel

    def add_tool(self, tool: Callable) -> None:
        """Add a tool to the active tools."""
        self.tools[tool.__name__] = tool

    def remove_tool(self, tool_name: str) -> None:
        """Remove a tool from active tools."""
        if tool_name in self.tools:
            del self.tools[tool_name]

    def get_tool(self, tool_name: str) -> Optional[Callable]:
        """Get a tool by name."""
        return self.tools.get(tool_name)

    async def execute(self, function_name: str, args: Dict[str, Any]) -> Any:
        """
        Execute a single function with context injection and type coercion.

        Args:
            function_name: Name of the function to execute
            args: Arguments to pass to the function

        Returns:
            Function execution result

        Raises:
            ValueError: If function is not found or is a complementary tool not activated
        """
        # Debug: Print function name and parameters
        print(f"[ToolExecutor] Executing function: {function_name}")
        print(f"[ToolExecutor] Parameters: {args}")

        # Check if function exists
        if function_name not in self.tools:
            if function_name in self.complementary_tool_names:
                raise ValueError(
                    f"Complementary tool '{function_name}' not active. "
                    f"Use search_tool to add it first."
                )
            raise ValueError(f"Unknown function: {function_name}")


        func = self.tools[function_name]

        # Coerce argument types
        args = coerce_types(func, args)

        # Inject context if function expects it
        sig = inspect.signature(func)
        if "context" in sig.parameters and self.context is not None:
            args["context"] = self.context

        # Execute function (async or sync)
        if asyncio.iscoroutinefunction(func):
            result = await func(**args)
        else:
            result = func(**args)

        return result

    async def execute_parallel(
        self, function_calls: List[Dict[str, Any]]
    ) -> List[Tuple[str, Dict[str, Any]]]:
        """
        Execute multiple function calls in parallel (where possible).

        Args:
            function_calls: List of dicts with 'name' and 'args' keys

        Returns:
            List of tuples: (function_name, result_dict)
            result_dict has either 'result' or 'error' key
        """
        if not self.enable_parallel or len(function_calls) <= 1:
            # Execute sequentially
            return await self._execute_sequential(function_calls)

        # Analyze dependencies to determine what can run in parallel
        batches = self._create_execution_batches(function_calls)

        all_results = []
        for batch in batches:
            batch_results = await self._execute_batch(batch)
            all_results.extend(batch_results)

        return all_results

    async def _execute_sequential(
        self, function_calls: List[Dict[str, Any]]
    ) -> List[Tuple[str, Dict[str, Any]]]:
        """Execute function calls sequentially."""
        results = []
        for fc in function_calls:
            function_name = fc["name"]
            args = fc["args"]
            fc_id = fc.get("id")
            result = await self._safe_execute(function_name, args)
            if fc_id:
                result["id"] = fc_id
            results.append((function_name, result))
        return results

    async def _execute_batch(
        self, function_calls: List[Dict[str, Any]]
    ) -> List[Tuple[str, Dict[str, Any]]]:
        """Execute a batch of independent function calls in parallel."""
        tasks = []
        for fc in function_calls:
            task = self._safe_execute(fc["name"], fc["args"])
            tasks.append(task)

        # Execute all tasks in parallel (up to max_parallel limit)
        if len(tasks) > self.max_parallel:
            # Execute in chunks
            results = []
            for i in range(0, len(tasks), self.max_parallel):
                chunk = tasks[i : i + self.max_parallel]
                chunk_results = await asyncio.gather(*chunk)
                results.extend(chunk_results)
        else:
            results = await asyncio.gather(*tasks)

        # Combine with function names and preserve ids
        combined_results = []
        for fc, result in zip(function_calls, results):
            if fc.get("id"):
                result["id"] = fc["id"]
            combined_results.append((fc["name"], result))
        return combined_results

    async def _safe_execute(self, function_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """
        Safely execute a function, catching exceptions.

        Args:
            function_name: Name of the function
            args: Arguments to pass

        Returns:
            Dict with either 'result' or 'error' key
        """
        try:
            result = await self.execute(function_name, args)
            return {"result": str(result)}
        except Exception as e:
            error_msg = f"Error executing {function_name}: {str(e)}"
            return {"error": error_msg}

    def _create_execution_batches(
        self, function_calls: List[Dict[str, Any]]
    ) -> List[List[Dict[str, Any]]]:
        """
        Create batches of function calls that can be executed in parallel.

        For now, we use a simple heuristic:
        - All function calls in the same batch are independent (can run in parallel)
        - We could enhance this with dependency analysis in the future

        Args:
            function_calls: List of function calls

        Returns:
            List of batches (each batch is a list of function calls)
        """
        # Simple strategy: treat all as independent unless we detect obvious dependencies
        # Future enhancement: analyze function signatures and outputs to detect dependencies

        # For now, put all in one batch (all execute in parallel)
        # This is safe because LLM should not generate dependent calls in same turn
        return [function_calls]

    def update_context(self, context: dict) -> None:
        """Update the execution context."""
        self.context = context
