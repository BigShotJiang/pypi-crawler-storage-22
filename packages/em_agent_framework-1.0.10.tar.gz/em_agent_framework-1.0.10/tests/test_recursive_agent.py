"""
Tests for recursive agent call functionality.
"""

import json
import sys
from pathlib import Path

import pytest

from em_agent_framework.config.settings import AgentConfig, ModelConfig
from em_agent_framework.core.agent import Agent
from em_agent_framework.core.tools.decorators import tool


# Define simple math tools for testing
@tool(description="Add two numbers")
def add(a: float, b: float) -> float:
    """Add two numbers."""
    return a + b


@tool(description="Multiply two numbers")
def multiply(a: float, b: float) -> float:
    """Multiply two numbers."""
    return a * b


@tool(description="Subtract two numbers")
def subtract(a: float, b: float) -> float:
    """Subtract b from a."""
    return a - b


@tool(description="Divide two numbers")
def divide(a: float, b: float) -> float:
    """Divide a by b."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


class TestRecursiveAgent:
    """Tests for recursive agent call functionality."""

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration with recursion support."""
        return AgentConfig(
            max_turns=10,
            max_retries_per_model=2,
            verbose=True,
            enable_recursive_agents=True,
            max_recursion_depth=3,
        )

    @pytest.fixture
    def model_configs(self):
        """Create test model configurations."""
        return [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=30.0),
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=30.0),
        ]

    @pytest.mark.asyncio
    async def test_agent_has_id_and_depth(self, agent_config, model_configs):
        """Test that agents have unique IDs and track recursion depth."""
        agent = Agent(
            name="test_agent",
            system_instruction="You are a test assistant.",
            tools=[add, multiply],
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
        )

        # Check agent has ID
        assert agent.id is not None
        assert isinstance(agent.id, str)
        assert len(agent.id) > 0

        # Check recursion depth is 0 for top-level agent
        assert agent.recursion_depth == 0

        # Check parent_agent_id is None for top-level agent
        assert agent.parent_agent_id is None

        print(f"\nAgent ID: {agent.id}")
        print(f"Recursion depth: {agent.recursion_depth}")

    @pytest.mark.asyncio
    async def test_agent_has_recursive_call_tool(self, agent_config, model_configs):
        """Test that agents automatically have recursive_agent_call tool."""
        agent = Agent(
            name="test_agent",
            system_instruction="You are a test assistant.",
            tools=[add, multiply],
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
        )

        # Check recursive_agent_call is in tools
        tool_names = [tool.__name__ for tool in agent.tools]
        assert "recursive_agent_call" in tool_names

        print(f"\nAvailable tools: {tool_names}")

    @pytest.mark.asyncio
    async def test_agent_without_recursive_call_tool(self, model_configs):
        """Test that agents don't have recursive_agent_call tool when disabled."""
        agent_config_disabled = AgentConfig(
            max_turns=10,
            max_retries_per_model=2,
            verbose=True,
            enable_recursive_agents=False,  # Disabled
            max_recursion_depth=3,
        )

        agent = Agent(
            name="test_agent",
            system_instruction="You are a test assistant.",
            tools=[add, multiply],
            model_configs=model_configs,
            agent_config=agent_config_disabled,
            project_id="nsi-dev",
        )

        # Check recursive_agent_call is NOT in tools
        tool_names = [tool.__name__ for tool in agent.tools]
        assert "recursive_agent_call" not in tool_names

        print(f"\nAvailable tools (recursive disabled): {tool_names}")

    @pytest.mark.asyncio
    async def test_simple_recursive_call(self, agent_config, model_configs):
        """Test basic recursive agent call for a simple subtask."""
        agent = Agent(
            name="math_agent",
            system_instruction=(
                "You are a math assistant. Use tools for calculations. "
                "If you receive a complex task with multiple independent calculations, "
                "you can use recursive_agent_call to spawn sub-agents for each calculation."
            ),
            tools=[add, multiply, subtract],
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
        )

        # Ask agent to delegate a simple calculation
        response = await agent.send_message(
            "Use recursive_agent_call to calculate 15 + 27 as a subtask."
        )

        print(f"\nResponse: {response}")

        # Response should contain reference to the subtask or result
        assert isinstance(response, str)
        assert len(response) > 0

    @pytest.mark.asyncio
    async def test_parallel_recursive_calls(self, agent_config, model_configs):
        """Test agent can spawn multiple sub-agents for parallel execution."""
        agent = Agent(
            name="parallel_math_agent",
            system_instruction=(
                "You are a math assistant. When given multiple independent calculations, "
                "use recursive_agent_call to spawn sub-agents for each calculation in parallel. "
                "Always use the tools provided for calculations."
            ),
            tools=[add, multiply, subtract, divide],
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
        )

        # Ask agent to perform three independent calculations
        response = await agent.send_message(
            "Calculate these three values using recursive_agent_call: "
            "1) 25 + 13, 2) 8 * 6, 3) 100 - 45. "
            "Spawn a sub-agent for each calculation."
        )

        print(f"\nParallel response: {response}")

        # Response should reference all three calculations
        assert isinstance(response, str)
        assert len(response) > 0

    @pytest.mark.asyncio
    async def test_recursion_depth_limit(self, agent_config, model_configs):
        """Test that recursion depth limit is enforced."""
        # Create agent with depth limit of 2
        limited_config = AgentConfig(
            max_turns=10,
            max_retries_per_model=2,
            verbose=True,
            max_recursion_depth=2,
        )

        agent = Agent(
            name="depth_test_agent",
            system_instruction="You are a test assistant.",
            tools=[add],
            model_configs=model_configs,
            agent_config=limited_config,
            project_id="nsi-dev",
        )

        # Manually create a deeply nested agent to test depth limit
        sub_agent_1 = Agent(
            name="sub_agent_1",
            system_instruction="You are a test assistant.",
            tools=[add],
            model_configs=model_configs,
            agent_config=limited_config,
            project_id="nsi-dev",
            parent_agent_id=agent.id,
            recursion_depth=1,
        )

        sub_agent_2 = Agent(
            name="sub_agent_2",
            system_instruction="You are a test assistant.",
            tools=[add],
            model_configs=model_configs,
            agent_config=limited_config,
            project_id="nsi-dev",
            parent_agent_id=sub_agent_1.id,
            recursion_depth=2,
        )

        # Try to spawn from depth 2 (should hit limit)
        response = await sub_agent_2.send_message(
            "Use recursive_agent_call to calculate 5 + 3."
        )

        print(f"\nDepth limit response: {response}")

        # Response should indicate depth limit reached or agent should handle gracefully
        assert isinstance(response, str)

    @pytest.mark.asyncio
    async def test_sub_agent_metadata(self, agent_config, model_configs):
        """Test that sub-agent metadata is properly tracked."""
        parent_agent = Agent(
            name="parent_agent",
            system_instruction="You are a parent agent.",
            tools=[add, multiply],
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
        )

        # Create child agent manually
        child_agent = Agent(
            name="child_agent",
            system_instruction="You are a child agent.",
            tools=[add, multiply],
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
            parent_agent_id=parent_agent.id,
            recursion_depth=1,
        )

        # Check child has correct metadata
        assert child_agent.parent_agent_id == parent_agent.id
        assert child_agent.recursion_depth == 1
        assert child_agent.id != parent_agent.id

        print(f"\nParent ID: {parent_agent.id}")
        print(f"Child ID: {child_agent.id}")
        print(f"Child parent_id: {child_agent.parent_agent_id}")
        print(f"Child depth: {child_agent.recursion_depth}")

    @pytest.mark.asyncio
    async def test_complex_task_decomposition(self, agent_config, model_configs):
        """Test agent can decompose complex task into subtasks."""
        agent = Agent(
            name="complex_math_agent",
            system_instruction=(
                "You are a math assistant that can break down complex calculations. "
                "When you receive a complex multi-step problem, use recursive_agent_call "
                "to delegate independent sub-calculations to sub-agents. "
                "Always use the provided tools for calculations."
            ),
            tools=[add, multiply, subtract, divide],
            model_configs=model_configs,
            agent_config=agent_config,
            project_id="nsi-dev",
        )

        # Ask agent to solve a complex problem
        response = await agent.send_message(
            "Calculate (25 + 15) * (10 - 3). "
            "Use recursive_agent_call to calculate (25 + 15) and (10 - 3) as separate subtasks, "
            "then multiply the results."
        )

        print(f"\nComplex task response: {response}")

        # Should get a response
        assert isinstance(response, str)
        assert len(response) > 0

    @pytest.mark.asyncio
    async def test_recursive_call_with_different_models(self, agent_config, model_configs):
        """Test recursive calls work with different model configurations."""
        # Use both Claude and Gemini
        multi_model_config = [
            ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=30.0),
            ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=30.0),
        ]

        agent = Agent(
            name="multi_model_agent",
            system_instruction=(
                "You are a math assistant. Use recursive_agent_call for subtasks when appropriate."
            ),
            tools=[add, multiply],
            model_configs=multi_model_config,
            agent_config=agent_config,
            project_id="nsi-dev",
        )

        response = await agent.send_message(
            "Use recursive_agent_call to calculate 50 + 25 as a subtask."
        )

        print(f"\nMulti-model response: {response}")

        assert isinstance(response, str)
        assert len(response) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
