"""
EM Agent Framework

A production-ready AI agent framework for Vertex AI with Gemini and Anthropic support.
"""

from em_agent_framework.__version__ import __version__
from em_agent_framework.core.agent import Agent
from em_agent_framework.core.conversation import ConversationManager
from em_agent_framework.core.metrics import AgentMetrics
from em_agent_framework.config.settings import AgentConfig, ModelConfig

__all__ = [
    "__version__",
    "Agent",
    "ConversationManager",
    "AgentMetrics",
    "AgentConfig",
    "ModelConfig",
]
