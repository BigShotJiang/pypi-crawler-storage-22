"""
Enhanced GroupChatManager with multiple routing strategies.
"""

from typing import Any, Callable, Dict, List, Optional, Union

from google.genai import types

from .strategies import (
    CustomStrategy,
    LLMBasedStrategy,
    RoundRobinStrategy,
    SkillBasedStrategy,
    TransitionStrategy,
)


class GroupChatManager:
    """
    Manages group chat conversations between multiple agents with intelligent routing.

    Features:
    - Multiple routing strategies (round-robin, skill-based, LLM-based, custom)
    - Termination conditions
    - Shared conversation history
    - Context management
    - Metrics and observability
    """

    def __init__(
        self,
        agents: List[Any],
        strategy: Union[str, TransitionStrategy, Callable] = "round_robin",
        terminate_func: Optional[Callable] = None,
        max_total_turns: int = 50,
        verbose: bool = True,
        context: Optional[Dict[str, Any]] = None,
        project_id: Optional[str] = None,
        location: str = "global",
    ):
        """
        Initialize GroupChatManager.

        Args:
            agents: List of Agent instances
            strategy: Routing strategy - can be:
                - "round_robin": Simple round-robin
                - "skill_based": Route based on agent descriptions
                - "llm_based": Use LLM to select next speaker
                - TransitionStrategy instance: Custom strategy object
                - Callable: Custom transition function
            terminate_func: Optional function(current_agent, history, agents, context) -> bool
            max_total_turns: Maximum number of turns before stopping
            verbose: Whether to print detailed logs
            context: Shared context dictionary
            project_id: Google Cloud project ID (for LLM-based routing)
            location: Google Cloud location
        """
        self.agents = {agent.name: agent for agent in agents}
        self.agent_list = agents
        self.terminate_func = terminate_func
        self.max_total_turns = max_total_turns
        self.verbose = verbose
        self.context = context or {}
        self.project_id = project_id
        self.location = location

        # Initialize routing strategy
        self.strategy = self._initialize_strategy(strategy)

        # State
        self.conversation_history: List[types.Content] = []
        self.turn_count = 0

        if self.verbose:
            print(f"[GroupChatManager] Initialized with {len(agents)} agents")
            print(f"[GroupChatManager] Routing strategy: {type(self.strategy).__name__}")
            for agent in agents:
                desc = getattr(agent, "agent_description", "N/A")
                print(f"  - {agent.name}: {desc}")

    def _initialize_strategy(
        self, strategy: Union[str, TransitionStrategy, Callable]
    ) -> TransitionStrategy:
        """
        Initialize routing strategy from various input types.

        Args:
            strategy: Strategy specification

        Returns:
            TransitionStrategy instance
        """
        if isinstance(strategy, TransitionStrategy):
            return strategy

        if callable(strategy):
            return CustomStrategy(strategy)

        if isinstance(strategy, str):
            strategy = strategy.lower()

            if strategy == "round_robin":
                return RoundRobinStrategy()

            elif strategy == "skill_based":
                return SkillBasedStrategy(verbose=self.verbose)

            elif strategy == "llm_based":
                return LLMBasedStrategy(
                    project_id=self.project_id, location=self.location, verbose=self.verbose
                )

            else:
                raise ValueError(f"Unknown strategy: {strategy}")

        raise ValueError(f"Invalid strategy type: {type(strategy)}")

    async def initiate_conversation(
        self, query: str, first_agent: Optional[Any] = None, max_turns: Optional[int] = None
    ) -> List[types.Content]:
        """
        Initiate a group chat conversation.

        Args:
            query: Initial query/message
            first_agent: Optional agent to start (if None, strategy selects)
            max_turns: Optional override for max_total_turns

        Returns:
            Complete conversation history
        """
        max_turns = max_turns or self.max_total_turns
        self.conversation_history = []
        self.turn_count = 0

        if self.verbose:
            print("\n" + "=" * 70)
            print("GROUP CHAT STARTED")
            print("=" * 70)
            print(f"Initial query: {query}")
            print("=" * 70)

        # Add initial user message
        self.conversation_history.append(types.Content(role="user", parts=[types.Part(text=query)]))

        # Select first agent
        current_agent = first_agent
        if current_agent is None:
            current_agent = self.strategy.select_next_agent(
                current_agent=None,
                agents=self.agent_list,
                conversation_history=self.conversation_history,
                context=self.context,
            )

        if current_agent is None:
            if self.verbose:
                print("[GroupChatManager] No agent selected to start conversation")
            return self.conversation_history

        if self.verbose:
            print(f"First agent: {current_agent.name}\n")

        current_message = query

        # Conversation loop
        while self.turn_count < max_turns:
            self.turn_count += 1

            if self.verbose:
                print(f"\n{'='*70}")
                print(f"TURN {self.turn_count}: {current_agent.name}")
                print(f"{'='*70}")

            # Get agent response
            try:
                response = await current_agent.send_message(current_message)

                # Add response to history
                self.conversation_history.append(
                    types.Content(role="model", parts=[types.Part(text=response)])
                )

                if self.verbose:
                    print(f"\n[{current_agent.name}] {response}")

            except Exception as e:
                error_msg = f"Error from {current_agent.name}: {str(e)}"
                if self.verbose:
                    print(f"\n[ERROR] {error_msg}")

                self.conversation_history.append(
                    types.Content(role="model", parts=[types.Part(text=f"[ERROR] {error_msg}")])
                )
                break

            # Check termination condition
            if self.terminate_func:
                should_terminate = self.terminate_func(
                    current_agent, self.conversation_history, self.agent_list, self.context
                )
                if should_terminate:
                    if self.verbose:
                        print(f"\n{'='*70}")
                        print("CONVERSATION ENDED: Termination condition met")
                        print(f"{'='*70}")
                    break

            # Select next agent
            next_agent = self.strategy.select_next_agent(
                current_agent=current_agent,
                agents=self.agent_list,
                conversation_history=self.conversation_history,
                context=self.context,
            )

            if next_agent is None:
                if self.verbose:
                    print(f"\n{'='*70}")
                    print("CONVERSATION ENDED: No next agent selected")
                    print(f"{'='*70}")
                break

            if next_agent not in self.agent_list:
                if self.verbose:
                    print(f"\n[WARNING] Invalid agent returned: {next_agent}")
                break

            # Prepare context message for next agent
            current_message = self._prepare_context_message(next_agent)
            current_agent = next_agent

        if self.turn_count >= max_turns and self.verbose:
            print(f"\n{'='*70}")
            print(f"CONVERSATION ENDED: Max turns ({max_turns}) reached")
            print(f"{'='*70}")

        return self.conversation_history

    def _prepare_context_message(self, next_agent: Any) -> str:
        """
        Prepare context message for next agent.

        Args:
            next_agent: Agent that will receive the message

        Returns:
            Context message
        """
        # Get last few messages
        recent_messages = self.conversation_history[-3:]

        context_parts = ["Here's the recent conversation context:"]

        for content in recent_messages:
            if hasattr(content, "role") and hasattr(content, "parts"):
                role = content.role
                text = ""
                for part in content.parts:
                    if hasattr(part, "text") and part.text:
                        text += part.text

                if text:
                    context_parts.append(f"\n{role.upper()}: {text}")

        context_parts.append(
            f"\n\nYou are {next_agent.name}. Please respond based on this context."
        )

        return "\n".join(context_parts)

    def get_conversation_summary(self) -> str:
        """
        Get a summary of the conversation.

        Returns:
            Formatted conversation summary
        """
        summary = [f"Conversation Summary ({len(self.conversation_history)} messages):\n"]

        for i, content in enumerate(self.conversation_history, 1):
            if hasattr(content, "role") and hasattr(content, "parts"):
                role = content.role
                text = ""
                for part in content.parts:
                    if hasattr(part, "text") and part.text:
                        text += part.text[:100]  # Truncate

                if text:
                    summary.append(f"{i}. {role.upper()}: {text}")

        return "\n".join(summary)

    def reset(self) -> None:
        """Reset conversation state."""
        self.conversation_history = []
        self.turn_count = 0
        if self.verbose:
            print("[GroupChatManager] Conversation reset")

    def set_strategy(self, strategy: Union[str, TransitionStrategy, Callable]) -> None:
        """
        Change routing strategy.

        Args:
            strategy: New strategy
        """
        self.strategy = self._initialize_strategy(strategy)
        if self.verbose:
            print(f"[GroupChatManager] Strategy changed to: {type(self.strategy).__name__}")
