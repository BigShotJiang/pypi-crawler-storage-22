"""
Improved Agent with provider abstraction, parallel tool execution, and robust fallback.
"""

import asyncio
import json
import sys
import time
import traceback
import uuid
from typing import Any, Callable, Dict, List, Optional

from google.genai import types

from em_agent_framework.config.settings import AgentConfig, ModelConfig
from em_agent_framework.core.conversation import ConversationManager
from em_agent_framework.core.metrics import AgentMetrics
from em_agent_framework.core.models import VertexAIProvider
from em_agent_framework.core.models.anthropic_provider import AnthropicProvider
from em_agent_framework.core.models.provider import ModelProvider
from em_agent_framework.core.tools import ToolExecutor, ToolRegistry, create_function_declaration
from em_agent_framework.core.tools.decorators import get_tool_short_description
from em_agent_framework.core.tools.registry import InstructionLibrary


class FunctionCallWithId:
    """
    Wrapper class for FunctionCall that preserves Claude's tool_use_id.

    This class mimics the interface of google.genai.types.FunctionCall but allows
    storing additional metadata (id and raw) needed for Claude conversation tracking.
    """

    def __init__(self, name: str, args: Dict[str, Any], id: Optional[str] = None, raw: Any = None):
        self.name = name
        self.args = args
        self.id = id
        self.raw = raw


def _safe_print(message: str) -> None:
    """
    Print with fallback for Unicode encoding issues on Windows.

    Args:
        message: Message to print
    """
    try:
        print(message)
    except UnicodeEncodeError:
        # Fallback: replace problematic Unicode characters
        safe_message = message.encode(sys.stdout.encoding, errors="replace").decode(
            sys.stdout.encoding
        )
        print(safe_message)


class Agent:
    """
    AI Agent with function calling, provider abstraction, and seamless model fallback.

    Features:
    - Supports both Gemini and Anthropic (Claude) models via Vertex AI
    - Automatic fallback across multiple models on failure
    - Parallel function execution
    - Dynamic tool loading (search_tool and load_instructions)
    - Automatic conversation summarization
    - Metrics and observability
    """

    def __init__(
        self,
        name: str,
        system_instruction: str,
        tools: Optional[List[Callable]] = None,
        complementary_tools: Optional[List[Callable]] = None,
        context: Optional[Dict[str, Any]] = None,
        model_configs: Optional[List[ModelConfig]] = None,
        agent_config: Optional[AgentConfig] = None,
        project_id: Optional[str] = None,
        location: str = "global",
        instructions_file: Optional[str] = None,
        terminate_func: Optional[Callable] = None,
        update_tools_func: Optional[Callable] = None,
        friendly_name: Optional[str] = None,
        agent_description: Optional[str] = None,
        parent_agent_id: Optional[str] = None,
        recursion_depth: int = 0,
    ):
        """
        Initialize the Agent.

        Args:
            name: Agent name
            system_instruction: System instruction/prompt
            tools: List of callable tools
            complementary_tools: Tools not in context by default (loaded via search_tool)
            context: Shared context dictionary
            model_configs: List of model configurations (fallback chain)
            agent_config: Agent configuration
            project_id: Google Cloud project ID
            location: Default Google Cloud location (e.g., 'us-central1', 'europe-west1').
                     Can be overridden per model in ModelConfig.location.
            instructions_file: Path to JSON file with instruction templates
            terminate_func: Optional termination function
            update_tools_func: Optional function to update tools dynamically
            friendly_name: User-friendly display name
            agent_description: Description of agent's purpose
            parent_agent_id: ID of parent agent if this is a recursive call
            recursion_depth: Current recursion depth (0 for top-level agent)
        """
        # Basic attributes
        self.id = str(uuid.uuid4())
        self.name = name
        self.friendly_name = friendly_name or name
        self.agent_description = agent_description
        self.system_instruction = system_instruction
        self.context = context or {}
        self.project_id = project_id
        self.location = location
        self.parent_agent_id = parent_agent_id
        self.recursion_depth = recursion_depth

        # Configuration
        self.agent_config = agent_config or AgentConfig()
        self.model_configs = model_configs or []
        if not self.model_configs:
            from config.settings import config

            self.model_configs = config.default_models

        # Functions
        self.terminate_func = terminate_func
        self.update_tools_func = update_tools_func

        # Tools setup
        self.tools = tools or []
        self.complementary_tools = complementary_tools or []
        self.function_declarations = []

        # Initialize LLM call logging
        self.llm_call_counter = 0
        self.log_file = None
        if agent_config.verbose and agent_config.log_llm_calls:
            log_path = agent_config.log_file_path or "llm_calls.log"
            self.log_file = open(log_path, "a", encoding="utf-8")
            print(f"[{name}] Logging LLM calls to: {log_path}")

        # Initialize instruction library and tool registry
        if agent_config.verbose:
            if instructions_file:
                print(f"[{name}] Instruction file: {instructions_file}")
            else:
                print(f"[{name}] No instruction file provided")

        self.instruction_library = (
            InstructionLibrary(instructions_file) if instructions_file else None
        )
        self.tool_registry = ToolRegistry(self.instruction_library)

        # Add default tools
        self._add_default_tools()

        # Initialize tool executor
        self.executor = ToolExecutor(
            tools=self.tools,
            complementary_tools=self.complementary_tools,
            context=self.context,
            enable_parallel=self.agent_config.enable_parallel_tools,
            max_parallel=self.agent_config.max_parallel_tools,
        )

        # Create function declarations for tools
        self.function_declarations = [create_function_declaration(tool) for tool in self.tools]

        # Initialize conversation manager
        self.conversation = ConversationManager(
            token_threshold=self.agent_config.token_threshold,
            model_name=self.model_configs[0].name,
            verbose=self.agent_config.verbose,
            project_id=self.project_id,
            location=self.location,
        )

        # Initialize metrics
        self.metrics = AgentMetrics(agent_name=self.name)

        # Initialize provider (starts with first model in config)
        self.current_model_index = 0
        self.provider = self._create_provider(self.model_configs[0])
        self.provider.initialize_chat([], self.function_declarations)

        if self.agent_config.verbose:
            print(
                f"[Agent] {self.name} initialized with {len(self.model_configs)} models in fallback chain"
            )
            for i, mc in enumerate(self.model_configs):
                print(f"  [{i}] {mc.name} ({mc.provider})")

    def __del__(self):
        """Cleanup resources when agent is destroyed."""
        if hasattr(self, 'log_file') and self.log_file:
            try:
                self.log_file.close()
            except:
                pass  # Ignore errors during cleanup

    def _add_default_tools(self) -> None:
        """Add default tools (search_tool, load_instructions, and recursive_agent_call)."""
        # Add search_tool if complementary tools exist
        if self.complementary_tools:
            # Collect short descriptions of complementary tools for LLM context
            complementary_short_descriptions = []
            for tool in self.complementary_tools:
                short_desc = get_tool_short_description(tool)
                if short_desc:
                    complementary_short_descriptions.append(f"  - {tool.__name__}: {short_desc}")

            # Add short descriptions to system instruction if any exist
            if complementary_short_descriptions:
                descriptions_text = "\n".join([
                    "\nAvailable complementary tools (use search_tool to load):"
                ] + complementary_short_descriptions)
                self.system_instruction += f"\n{descriptions_text}"

            search_tool = self.tool_registry.create_search_tool(
                complementary_tools=self.complementary_tools,
                add_tool_callback=self._add_tool_to_active,
            )
            self.tools.append(search_tool)
            self.tool_registry.register_default_tool("search_tool", search_tool)

        # Add load_instructions if instruction library exists
        if self.instruction_library:
            # Add short descriptions to system instruction
            descriptions = self.instruction_library.get_short_descriptions()
            if self.agent_config.verbose:
                print(f"[{self.name}] Adding instruction library descriptions to system prompt:")
                print(f"[{self.name}] Descriptions length: {len(descriptions)} characters")
                print(f"[{self.name}] Descriptions:\n{descriptions}")

            self.system_instruction += f"\n\n{descriptions}"

            load_instructions_tool = self.tool_registry.create_load_instructions_tool(
                update_system_instruction_callback=self._append_to_system_instruction
            )
            self.tools.append(load_instructions_tool)
            self.tool_registry.register_default_tool("load_instructions", load_instructions_tool)

        # Add recursive_agent_call tool for spawning sub-agents (if enabled)
        if self.agent_config.enable_recursive_agents:
            recursive_call_tool = self.tool_registry.create_recursive_agent_call_tool(
                agent_instance=self
            )
            self.tools.append(recursive_call_tool)
            self.tool_registry.register_default_tool("recursive_agent_call", recursive_call_tool)

    def _add_tool_to_active(self, tool: Callable) -> None:
        """
        Add a complementary tool to active tools.

        Args:
            tool: Tool to add
        """
        if tool not in self.tools:
            self.tools.append(tool)
            self.executor.add_tool(tool)

            # Recreate function declarations and reinitialize provider
            self.function_declarations = [create_function_declaration(t) for t in self.tools]
            history = self.provider.get_chat_history()
            self.provider.initialize_chat(history, self.function_declarations)

            if self.agent_config.verbose:
                print(f"[{self.name}] Added complementary tool: {tool.__name__}")

    def _append_to_system_instruction(self, instruction_text: str) -> None:
        """
        Append instruction to system instruction and reinitialize provider.

        Args:
            instruction_text: Instruction to append
        """
        if self.agent_config.verbose:
            print(f"[{self.name}] Appending to system instruction:")
            print(f"[{self.name}] Added length: {len(instruction_text)} characters")
            print(f"[{self.name}] Added content: {instruction_text[:500]}")
            if len(instruction_text) > 500:
                print(f"[{self.name}] ... (truncated, full length: {len(instruction_text)} chars)")

        self.system_instruction += f"\n\n{instruction_text}"

        # Reinitialize provider with new system instruction
        history = self.provider.get_chat_history()
        self.provider.update_system_instruction(self.system_instruction, history)

        if self.agent_config.verbose:
            print(f"[{self.name}] System instruction updated successfully")
            print(f"[{self.name}] Total system instruction length: {len(self.system_instruction)} characters")

    def _log_llm_call(self, call_type: str, message: str = "", history: Optional[List] = None):
        """
        Log LLM call with conversation history to file.

        Args:
            call_type: Type of call ('send_message' or 'send_function_response')
            message: User message (for send_message calls)
            history: Conversation history
        """
        if not (self.agent_config.verbose and self.agent_config.log_llm_calls and self.log_file):
            return

        self.llm_call_counter += 1
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")

        self.log_file.write(f"\n{'='  * 100}\n")
        self.log_file.write(f"LLM CALL #{self.llm_call_counter} - {timestamp}\n")
        self.log_file.write(f"Agent: {self.name} | Model: {self.provider.model_name} | Type: {call_type}\n")
        self.log_file.write(f"{'=' * 100}\n\n")

        # Log system instruction
        self.log_file.write(f"SYSTEM INSTRUCTION:\n{'-' * 100}\n")
        self.log_file.write(f"{self.system_instruction}\n\n")

        # Log conversation history
        if history:
            self.log_file.write(f"CONVERSATION HISTORY ({len(history)} turns):\n{'-' * 100}\n")
            for idx, content in enumerate(history, 1):
                role = content.role.upper()
                self.log_file.write(f"\n[{idx}] {role}:\n")
                for part in content.parts:
                    if hasattr(part, "text") and part.text:
                        self.log_file.write(f"  TEXT: {part.text}\n")
                    elif hasattr(part, "function_call") and part.function_call:
                        self.log_file.write(f"  FUNCTION_CALL: {part.function_call.name}({dict(part.function_call.args)})\n")
                    elif hasattr(part, "function_response") and part.function_response:
                        self.log_file.write(f"  FUNCTION_RESPONSE: {part.function_response.name} -> {part.function_response.response}\n")

        # Log new message if provided
        if message:
            self.log_file.write(f"\nNEW MESSAGE:\n{'-' * 100}\n")
            self.log_file.write(f"{message}\n")

        self.log_file.write(f"\n{'=' * 100}\n")
        self.log_file.flush()

    def _create_provider(self, model_config: ModelConfig) -> ModelProvider:
        """
        Create a provider instance.

        Args:
            model_config: Model configuration

        Returns:
            ModelProvider instance (either VertexAIProvider for Gemini or AnthropicProvider for Claude)
        """
        # Use model-specific location if provided, otherwise use agent's default location
        location = model_config.location if model_config.location else self.location

        # Check if this is a Claude model
        is_claude = "claude" in model_config.name.lower()

        if is_claude:
            # Use Anthropic Vertex SDK for Claude models
            return AnthropicProvider(
                model_config=model_config,
                system_instruction=self.system_instruction,
                project_id=self.project_id,
                location=location,
                timeout=model_config.timeout,
            )
        else:
            # Use google-genai SDK for Gemini models
            return VertexAIProvider(
                model_config=model_config,
                system_instruction=self.system_instruction,
                project_id=self.project_id,
                location=location,
                timeout=model_config.timeout,
            )

    async def send_message(self, message: str) -> str:
        """
        Send a message to the agent.

        Args:
            message: User message

        Returns:
            Agent response
        """
        if self.agent_config.verbose:
            _safe_print(f"\n🧑 User: {message}")

        # Check and summarize if needed
        await self.conversation.check_and_summarize_if_needed(
            client=self.provider._client,
            model_name=self.provider.model_name,
            tools=self.function_declarations,
            new_message=message,
        )

        # Prepend summary if exists
        if self.conversation.has_summary():
            message = self.conversation.prepend_summary_to_message(message)

        # Update tools if dynamic update function provided
        if self.update_tools_func:
            updated_tools = self.update_tools_func(self.conversation.get_history(), self.tools)
            if updated_tools is not None and updated_tools != self.tools:
                self.tools = updated_tools
                self.function_declarations = [create_function_declaration(t) for t in self.tools]
                self.executor.tools = {t.__name__: t for t in self.tools}
                history = self.provider.get_chat_history()
                self.provider.initialize_chat(history, self.function_declarations)

        # Get initial response with fallback
        try:
            response = await self._send_with_fallback(message)
        except Exception as e:
            self.metrics.record_error("send_message", str(e))
            if self.agent_config.verbose:
                print(f"[{self.name}] All models failed: {e}")
                traceback.print_exc()
            return f"I'm sorry, I encountered an error: {e}"

        # Add user message to conversation history
        self.conversation.add_content(types.Content(role="user", parts=[types.Part(text=message)]))

        # Store model response to history (including text)
        # Function calls will be stored later after deduplication in _handle_function_calling_loop
        if response.text and not response.has_function_calls():
            # Simple text response - store immediately
            self.conversation.add_content(types.Content(role="model", parts=[types.Part(text=response.text)]))

        self.metrics.record_message()

        # Check termination
        if self.terminate_func and self.terminate_func(self.conversation.get_history()):
            if self.agent_config.verbose:
                print(f"\n[{self.name}] ⛔ Termination condition met - stopping conversation")
            return response.text

        # Handle function calling loop
        return await self._handle_function_calling_loop(response)

    async def _send_with_fallback(self, message: str, start_index: int = 0) -> Any:
        """
        Send message with cascading fallback through model chain.

        Args:
            message: Message to send
            start_index: Starting model index

        Returns:
            Provider response
        """
        for model_idx in range(start_index, len(self.model_configs)):
            model_config = self.model_configs[model_idx]

            # Switch model if needed
            if model_idx != self.current_model_index:
                if self.agent_config.verbose:
                    print(f"[{self.name}] Falling back to: {model_config.name}")

                self.metrics.record_model_switch(
                    from_model=self.model_configs[self.current_model_index].name,
                    to_model=model_config.name,
                    reason="Previous model failed",
                )

                self._switch_to_model(model_idx)

            # Retry with current model
            for attempt in range(self.agent_config.max_retries_per_model):
                try:
                    if self.agent_config.verbose and attempt > 0:
                        print(
                            f"[{self.name}] Retry {attempt + 1}/{self.agent_config.max_retries_per_model}"
                        )

                    # Log LLM call
                    self._log_llm_call("send_message", message=message, history=self.conversation.get_history())

                    # Send message
                    response = await self.provider.send_message(
                        message=message,
                        history=self.conversation.get_history(),
                        tools=self.function_declarations,
                    )

                    # Check if response is malformed
                    if self.provider.is_malformed_response(response.raw_response):
                        if self.agent_config.verbose:
                            print(f"[{self.name}] Malformed response detected")
                        raise ValueError("Malformed response")

                    # Success
                    if self.agent_config.verbose and (attempt > 0 or model_idx > 0):
                        print(f"[{self.name}] Success with {model_config.name}")

                    return response

                except asyncio.TimeoutError:
                    if self.agent_config.verbose:
                        print(
                            f"[{self.name}] Timeout on {model_config.name} (attempt {attempt + 1})"
                        )
                    self.metrics.record_error(
                        "timeout", f"{model_config.name} attempt {attempt + 1}"
                    )

                    if attempt < self.agent_config.max_retries_per_model - 1:
                        await asyncio.sleep(self.agent_config.retry_delay * (attempt + 1))
                    continue

                except Exception as e:
                    if self.agent_config.verbose:
                        print(f"[{self.name}] Error on {model_config.name}: {e}")
                        traceback.print_exc()
                    self.metrics.record_error(
                        type(e).__name__, str(e), {"model": model_config.name}
                    )

                    if attempt < self.agent_config.max_retries_per_model - 1:
                        await asyncio.sleep(self.agent_config.retry_delay * (attempt + 1))
                    else:
                        break

        raise Exception(
            f"All {len(self.model_configs)} models failed after {self.agent_config.max_retries_per_model} retries each"
        )

    async def _handle_function_calling_loop(self, response: Any) -> str:
        """
        Handle function calling loop with parallel execution.

        Args:
            response: Initial provider response

        Returns:
            Final text response
        """
        turn_count = 0
        is_first_iteration = True  # Track if this is the first iteration

        while turn_count < self.agent_config.max_turns:
            turn_count += 1

            # Check if response has function calls
            if not response.has_function_calls():
                if self.agent_config.verbose:
                    print(f"[{self.name}] ✓ No more function calls - conversation complete")
                break

            # Update context with chat_history (merge, don't replace)
            # Use the executor's context directly to maintain reference continuity
            self.executor.context["chat_history"] = self.conversation.get_history()
            # Sync any new keys from self.context that aren't in executor.context
            for key, value in self.context.items():
                if key not in self.executor.context:
                    self.executor.context[key] = value

            # Prepare function calls - include id for proper conversation tracking
            function_calls = [
                {
                    "name": fc["name"],
                    "args": fc["args"],
                    "id": fc["raw"].id if hasattr(fc["raw"], "id") else None,
                }
                for fc in response.function_calls
            ]

            # Deduplicate identical function calls (same name + same args)
            # This prevents redundant execution and keeps conversation history clean
            unique_calls = []
            call_signature_map = {}  # Maps signature -> index in unique_calls
            duplicate_map = {}  # Maps unique_index -> list of original indices

            for idx, fc in enumerate(function_calls):
                # Create signature from name + args (use sorted json for consistent hashing)
                signature = f"{fc['name']}::{json.dumps(fc['args'], sort_keys=True)}"

                if signature in call_signature_map:
                    # Duplicate found - map to existing unique call
                    unique_idx = call_signature_map[signature]
                    duplicate_map[unique_idx].append(idx)
                else:
                    # New unique call
                    unique_idx = len(unique_calls)
                    call_signature_map[signature] = unique_idx
                    duplicate_map[unique_idx] = [idx]
                    unique_calls.append(fc)

            num_duplicates = len(function_calls) - len(unique_calls)

            if self.agent_config.verbose:
                # Combine turn counter with separator line
                dup_msg = f" ({num_duplicates} duplicate(s) removed)" if num_duplicates > 0 else ""
                print(f"\n[{self.name}] 🔄 Turn {turn_count}/{self.agent_config.max_turns}{dup_msg}")
                print(f"{'─' * 80}")
                # Print unique tool calls with better formatting
                for idx, fc in enumerate(unique_calls, 1):
                    print(f"  [{idx}] {fc['name']}")
                    _safe_print(f"      └─ {fc['args']}")
                print(f"{'─' * 80}")

            # Store model response with UNIQUE function calls to conversation history
            # This keeps history clean while we still send ALL responses to the API
            # CRITICAL: Only add to history on first iteration (initial response)
            # On subsequent iterations, the response was already added at the end of the previous turn
            if is_first_iteration:
                model_parts = []
                if response.text:
                    model_parts.append(types.Part(text=response.text))

                # Add unique function calls to history
                for fc in [response.function_calls[duplicate_map[i][0]] for i in range(len(unique_calls))]:
                    # Get the first occurrence of each unique call
                    if hasattr(self.provider, 'is_anthropic_model') and self.provider.is_anthropic_model():
                        # CRITICAL: Use fc["id"] which was extracted in _parse_response, not fc["raw"].id
                        tool_use_id = fc.get("id")
                        func_call = FunctionCallWithId(
                            name=fc["name"],
                            args=fc["args"],
                            id=tool_use_id,
                            raw=fc["raw"]
                        )
                        model_parts.append(types.Part(function_call=func_call))
                    else:
                        # Use raw part directly to preserve all Gemini-specific attributes like thought_signature
                        model_parts.append(fc["raw"])

                self.conversation.add_content(types.Content(role="model", parts=model_parts))
                is_first_iteration = False  # Mark that we've added the initial response

            # Execute only unique functions (in parallel if enabled)
            start_time = time.time()
            unique_results = await self.executor.execute_parallel(unique_calls)
            execution_time = time.time() - start_time

            # Expand results to include duplicates (reuse result for identical calls)
            results = []
            for unique_idx, (name, result_dict) in enumerate(unique_results):
                # Add result for each original call (including duplicates)
                for original_idx in duplicate_map[unique_idx]:
                    # Preserve the original call's id
                    result_copy = result_dict.copy()
                    if function_calls[original_idx].get("id"):
                        result_copy["id"] = function_calls[original_idx]["id"]
                    results.append((name, result_copy))

            # Sync context changes from executor back to agent
            # Tools may have modified the context during execution
            self.context.update(self.executor.context)

            # Record metrics and print responses
            if self.agent_config.verbose:
                print(f"\n✅ Tool Responses:")
                print(f"{'─' * 80}")

            response_idx = 1
            for func_name, result_dict in results:
                self.metrics.record_function_call(func_name, execution_time / len(results))

                if self.agent_config.verbose:
                    if "result" in result_dict:
                        print(f"  [{response_idx}] {func_name}:")
                        _safe_print(f"      └─ {result_dict['result']}")
                    else:
                        print(f"  [{response_idx}] {func_name}: ❌ ERROR")
                        _safe_print(f"      └─ {result_dict.get('error', 'Unknown error')}")
                    response_idx += 1

            if self.agent_config.verbose and results:
                print(f"{'─' * 80}")

            # Send function responses back to model
            # IMPORTANT: Must send responses for ALL calls (including duplicates) to satisfy LLM requirements
            # Gemini requires: number of function_response parts == number of function_call parts
            function_response_parts = []
            for name, result_dict in results:
                # FunctionResponse expects a dictionary, not a string
                # Wrap the result in a dict if needed
                if "result" in result_dict:
                    response_value = {"result": result_dict["result"]}
                elif "error" in result_dict:
                    response_value = {"error": result_dict["error"]}
                else:
                    response_value = {"result": "Unknown result"}

                # Create FunctionResponse - preserve id if available for Claude conversation tracking
                func_response = types.FunctionResponse(name=name, response=response_value)
                if "id" in result_dict:
                    func_response.id = result_dict["id"]

                function_response_parts.append(types.Part(function_response=func_response))

            # Build unique function response parts for conversation history
            # Only store responses for unique calls to keep history clean
            # CRITICAL: Must include IDs from the first occurrence of each unique call
            unique_function_response_parts = []
            for unique_idx, (name, result_dict) in enumerate(unique_results):
                if "result" in result_dict:
                    response_value = {"result": result_dict["result"]}
                elif "error" in result_dict:
                    response_value = {"error": result_dict["error"]}
                else:
                    response_value = {"result": "Unknown result"}

                func_response = types.FunctionResponse(name=name, response=response_value)
                # Get ID from the first occurrence of this unique call
                first_original_idx = duplicate_map[unique_idx][0]
                if function_calls[first_original_idx].get("id"):
                    func_response.id = function_calls[first_original_idx]["id"]
                unique_function_response_parts.append(types.Part(function_response=func_response))

            # Add only unique function responses to conversation history
            self.conversation.add_content(types.Content(role="user", parts=unique_function_response_parts))

            # CRITICAL: For Claude/Anthropic, send UNIQUE responses only (matches by ID)
            # For Gemini, send ALL responses (requires count to match function calls)
            if hasattr(self.provider, 'is_anthropic_model') and self.provider.is_anthropic_model():
                parts_to_send = unique_function_response_parts
            else:
                parts_to_send = function_response_parts

            try:
                response = await self._send_function_response_with_fallback(parts_to_send)
            except Exception as e:
                self.metrics.record_error("function_response", str(e))
                if self.agent_config.verbose:
                    print(f"[{self.name}] Function response failed: {e}")
                    traceback.print_exc()

                # Graceful degradation
                last_result = results[-1][1] if results else {}
                if (
                    last_result.get("result")
                    and "error" not in last_result.get("result", "").lower()
                ):
                    return f"I completed the requested operation. {last_result['result']}"
                return f"I executed the functions but encountered an error: {e}"

            # Add to history
            if response.text or response.has_function_calls():
                parts = []
                if response.text:
                    parts.append(types.Part(text=response.text))
                if response.has_function_calls():
                    for fc in response.function_calls:
                        # For Anthropic/Claude: use wrapper class to preserve tool_use_id
                        # For Gemini: use raw part to preserve thought_signature and other metadata
                        if hasattr(self.provider, 'is_anthropic_model') and self.provider.is_anthropic_model():
                            tool_use_id = fc["raw"].id if hasattr(fc["raw"], "id") else None
                            func_call = FunctionCallWithId(
                                name=fc["name"],
                                args=fc["args"],
                                id=tool_use_id,
                                raw=fc["raw"]
                            )
                            parts.append(types.Part(function_call=func_call))
                        else:
                            # Use raw part directly to preserve all Gemini-specific attributes like thought_signature
                            if hasattr(fc["raw"], "function_call"):
                                parts.append(types.Part(function_call=fc["raw"].function_call))
                            else:
                                # Fallback: create from parsed data
                                parts.append(types.Part(function_call=types.FunctionCall(
                                    name=fc["name"],
                                    args=fc["args"]
                                )))
                self.conversation.add_content(types.Content(role="model", parts=parts))

            # Check termination
            if self.terminate_func and self.terminate_func(self.conversation.get_history()):
                if self.agent_config.verbose:
                    print(f"\n[{self.name}] ⛔ Termination condition met - stopping conversation")
                return response.text

        # Check if loop ended due to max turns
        if turn_count >= self.agent_config.max_turns:
            if self.agent_config.verbose:
                print(f"\n[{self.name}] ⚠️  Maximum turns ({self.agent_config.max_turns}) reached - stopping conversation")

        # Return final response
        if response.text:
            if self.agent_config.verbose:
                _safe_print(f"\n🤖 {self.name}: {response.text}")
            return response.text

        return "Maximum conversation turns reached."

    async def _send_function_response_with_fallback(
        self, function_response_parts: List[Any], start_index: int = 0
    ) -> Any:
        """Send function response with fallback."""
        for model_idx in range(start_index, len(self.model_configs)):
            model_config = self.model_configs[model_idx]

            if model_idx != self.current_model_index:
                if self.agent_config.verbose:
                    print(f"[{self.name}] Falling back to: {model_config.name}")
                self._switch_to_model(model_idx)

            for attempt in range(self.agent_config.max_retries_per_model):
                try:
                    # Log LLM call
                    self._log_llm_call("send_function_response", history=self.conversation.get_history())

                    response = await self.provider.send_function_response(
                        function_response_parts=function_response_parts,
                        history=self.conversation.get_history(),
                    )

                    if self.provider.is_malformed_response(response.raw_response):
                        raise ValueError("Malformed response")

                    return response

                except Exception as e:
                    if self.agent_config.verbose:
                        print(f"[{self.name}] Error on LLM call (attempt {attempt + 1}/{self.agent_config.max_retries_per_model}): {type(e).__name__}: {e}")
                        traceback.print_exc()
                    if attempt < self.agent_config.max_retries_per_model - 1:
                        await asyncio.sleep(self.agent_config.retry_delay * (attempt + 1))
                    else:
                        break

        raise Exception("All models failed for function response")

    def _switch_to_model(self, model_index: int) -> None:
        """
        Switch to a different model while preserving history.

        Args:
            model_index: Index of model in model_configs
        """
        # Get current history
        history = self.conversation.get_history()

        # Update current model index
        self.current_model_index = model_index

        # Create new provider
        self.provider = self._create_provider(self.model_configs[model_index])
        self.provider.initialize_chat(history, self.function_declarations)

    def clear_history(self) -> None:
        """Clear conversation history."""
        self.conversation.clear_history()
        self.provider.initialize_chat([], self.function_declarations)

    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get metrics summary."""
        return self.metrics.get_summary()

    def print_metrics(self) -> None:
        """Print metrics summary."""
        self.metrics.print_summary()
