"""
Vertex AI provider supporting both Gemini and Anthropic (Claude) models.
"""

import asyncio
from typing import Any, Dict, List, Optional

from google import genai
from google.genai import types

from em_agent_framework.config.settings import ModelConfig

from .provider import ModelProvider, ProviderResponse


class VertexAIProvider(ModelProvider):
    """
    Unified provider for Vertex AI supporting both Gemini and Anthropic models.

    Uses the google.genai.Client API which supports the global endpoint for
    higher availability and reduced rate limiting.
    """

    def __init__(
        self,
        model_config: ModelConfig,
        system_instruction: str,
        project_id: Optional[str] = None,
        location: str = "global",
        timeout: float = 10.0,
    ):
        """
        Initialize Vertex AI provider.

        Args:
            model_config: Configuration for the model
            system_instruction: System instruction/prompt
            project_id: Google Cloud project ID
            location: Google Cloud location (supports "global")
            timeout: Request timeout in seconds
        """
        self.model_config = model_config
        self.system_instruction = system_instruction
        self.project_id = project_id
        self.location = location
        self.timeout = timeout
        self._client = None
        self._tools = None
        self._history = []
        self._last_input_tokens = 0  # Track input tokens from latest response
        self._last_output_tokens = 0  # Track output tokens from latest response

        # Initialize genai client with Vertex AI backend
        # This supports the global endpoint for Generative AI
        self._client = genai.Client(
            vertexai=True,
            project=project_id,
            location=location,
        )

    @property
    def model_name(self) -> str:
        """Get the current model name."""
        return self.model_config.name

    @property
    def provider_type(self) -> str:
        """Get the provider type."""
        return self.model_config.provider

    def is_anthropic_model(self) -> bool:
        """Check if current model is an Anthropic (Claude) model."""
        return "claude" in self.model_config.name.lower()

    def is_gemini_model(self) -> bool:
        """Check if current model is a Gemini model."""
        return "gemini" in self.model_config.name.lower()

    def _compress_history_for_gemini(self, history: List[types.Content]) -> List[types.Content]:
        """
        Compress conversation history for Gemini when it contains incompatible function calls.

        When switching from Claude to Gemini, Claude's function calls don't have thought_signature
        which Gemini requires. Instead of trying to fix each function call, we summarize the entire
        history into a single user message.

        Args:
            history: Original conversation history

        Returns:
            Compressed history as a single user turn with summary
        """
        if not history:
            return []

        # Check if history has any function calls without thought_signature
        has_incompatible_calls = False
        for content in history:
            for part in content.parts:
                if hasattr(part, 'function_call') and part.function_call:
                    if not hasattr(part.function_call, 'thought_signature'):
                        has_incompatible_calls = True
                        break
            if has_incompatible_calls:
                break

        # If no incompatible calls, return history as-is
        if not has_incompatible_calls:
            return history

        # Compress history into a summary
        summary_parts = ["Previous conversation summary:"]

        for content in history:
            role_label = "User" if content.role == "user" else "Assistant"

            for part in content.parts:
                if hasattr(part, 'text') and part.text:
                    summary_parts.append(f"{role_label}: {part.text}")
                elif hasattr(part, 'function_call') and part.function_call:
                    summary_parts.append(
                        f"{role_label} called tool '{part.function_call.name}' "
                        f"with args: {dict(part.function_call.args)}"
                    )
                elif hasattr(part, 'function_response') and part.function_response:
                    summary_parts.append(
                        f"Tool '{part.function_response.name}' returned: "
                        f"{part.function_response.response}"
                    )

        summary_text = "\n".join(summary_parts)

        # Return as single user message
        return [types.Content(role="user", parts=[types.Part(text=summary_text)])]

    def initialize_chat(
        self, history: List[types.Content], tools: Optional[List[Any]] = None
    ) -> None:
        """
        Initialize or reinitialize the chat session.

        Args:
            history: Initial conversation history
            tools: Optional tools available to the model
        """
        self._tools = tools
        self._history = history or []

    async def send_message(
        self, message: str, history: List[types.Content], tools: Optional[List[Any]] = None
    ) -> ProviderResponse:
        """
        Send a message to the model.

        Args:
            message: The message to send
            history: Current conversation history
            tools: Optional tools available to the model

        Returns:
            ProviderResponse with model output
        """
        # Update internal state
        if tools != self._tools:
            self._tools = tools
        self._history = history or []

        # Build generation config
        generation_config = types.GenerateContentConfig(
            temperature=self.model_config.temperature,
            system_instruction=self.system_instruction,
        )

        if self.model_config.max_output_tokens:
            generation_config.max_output_tokens = self.model_config.max_output_tokens

        # Add tools if provided
        if tools:
            tool_declarations = [
                types.FunctionDeclaration(
                    name=tool.name,
                    description=tool.description,
                    parameters=tool.parameters,
                )
                for tool in tools
            ]
            generation_config.tools = [types.Tool(function_declarations=tool_declarations)]

        # Compress history if Gemini and history contains incompatible function calls
        processed_history = history
        if self.is_gemini_model() and history:
            processed_history = self._compress_history_for_gemini(history)

        # Build contents: history + new message
        contents = list(processed_history) if processed_history else []
        contents.append(types.Content(role="user", parts=[types.Part(text=message)]))

        # Send message with timeout
        response = await asyncio.wait_for(
            self._client.aio.models.generate_content(
                model=self.model_config.name,
                contents=contents,
                config=generation_config,
            ),
            timeout=self.timeout,
        )

        # Update history with the response
        if response.candidates:
            candidate = response.candidates[0]
            if candidate.content:
                self._history.append(types.Content(role="user", parts=[types.Part(text=message)]))
                self._history.append(candidate.content)

        return self._parse_response(response)

    async def send_function_response(
        self, function_response_parts: List[Any], history: List[types.Content]
    ) -> ProviderResponse:
        """
        Send function execution results back to the model.

        Args:
            function_response_parts: List of function response parts
            history: Current conversation history

        Returns:
            ProviderResponse with model's next response
        """
        self._history = history or []

        # Build generation config
        generation_config = types.GenerateContentConfig(
            temperature=self.model_config.temperature,
            system_instruction=self.system_instruction,
        )

        if self.model_config.max_output_tokens:
            generation_config.max_output_tokens = self.model_config.max_output_tokens

        # Add tools if we have them
        if self._tools:
            tool_declarations = [
                types.FunctionDeclaration(
                    name=tool.name,
                    description=tool.description,
                    parameters=tool.parameters,
                )
                for tool in self._tools
            ]
            generation_config.tools = [types.Tool(function_declarations=tool_declarations)]

        # Compress history if Gemini and history contains incompatible function calls
        processed_history = history
        if self.is_gemini_model() and history:
            processed_history = self._compress_history_for_gemini(history)

        # Build contents: history + function responses
        contents = list(processed_history) if processed_history else []
        contents.append(types.Content(role="function", parts=function_response_parts))

        # Send function responses with timeout
        response = await asyncio.wait_for(
            self._client.aio.models.generate_content(
                model=self.model_config.name,
                contents=contents,
                config=generation_config,
            ),
            timeout=self.timeout,
        )

        # Update history
        if response.candidates:
            candidate = response.candidates[0]
            if candidate.content:
                self._history.append(
                    types.Content(role="function", parts=function_response_parts)
                )
                self._history.append(candidate.content)

        return self._parse_response(response)

    def _parse_response(self, response: types.GenerateContentResponse) -> ProviderResponse:
        """
        Parse raw response into standardized ProviderResponse.

        Args:
            response: Raw response from genai Client

        Returns:
            Standardized ProviderResponse
        """
        text_parts = []
        function_calls = []
        finish_reason = None

        if response and response.candidates:
            candidate = response.candidates[0]

            # Extract finish reason
            if hasattr(candidate, "finish_reason"):
                finish_reason = str(candidate.finish_reason)

            # Extract and track token usage from latest call
            if hasattr(response, "usage_metadata"):
                self._last_input_tokens = getattr(response.usage_metadata, "prompt_token_count", 0)
                self._last_output_tokens = getattr(response.usage_metadata, "candidates_token_count", 0)

            # Extract content parts
            if candidate.content and candidate.content.parts:
                for part in candidate.content.parts:
                    # Extract text
                    if hasattr(part, "text") and part.text:
                        text_parts.append(part.text)

                    # Extract function calls
                    if hasattr(part, "function_call") and part.function_call:
                        function_calls.append(
                            {
                                "name": part.function_call.name,
                                "args": dict(part.function_call.args),
                                "raw": part,
                            }
                        )

        return ProviderResponse(
            text="\n".join(text_parts),
            function_calls=function_calls,
            raw_response=response,
            finish_reason=finish_reason,
        )

    def is_malformed_response(self, response: Any) -> bool:
        """
        Check if response is malformed.

        Args:
            response: Response to check

        Returns:
            True if response is malformed
        """
        if not response or not response.candidates:
            return True

        candidate = response.candidates[0]

        # Check for malformed function call or empty content with error message
        return (
            hasattr(candidate, "finish_reason")
            and "MALFORMED_FUNCTION_CALL" in str(candidate.finish_reason)
        ) or (
            hasattr(candidate, "content")
            and candidate.content
            and not candidate.content.parts
            and hasattr(candidate, "finish_message")
            and candidate.finish_message
            and "malformed" in str(candidate.finish_message).lower()
        )

    def count_tokens(
        self, messages: List[Dict[str, Any]], tools: Optional[List[Any]] = None
    ) -> int:
        """
        Count tokens based on actual usage from the latest response.

        This returns the total token count (input + output) from the most
        recent Gemini API call.

        Args:
            messages: List of messages (not used, kept for interface compatibility)
            tools: Optional tools (not used, kept for interface compatibility)

        Returns:
            Total token count from latest API call (input_tokens + output_tokens)
        """
        return self._last_input_tokens + self._last_output_tokens

    def get_chat_history(self) -> List[types.Content]:
        """Get current chat history."""
        return self._history

    def get_last_input_tokens(self) -> int:
        """Get input tokens from the latest API call."""
        return self._last_input_tokens

    def get_last_output_tokens(self) -> int:
        """Get output tokens from the latest API call."""
        return self._last_output_tokens

    def update_system_instruction(
        self, new_instruction: str, history: List[types.Content]
    ) -> None:
        """
        Update system instruction and reinitialize chat.

        Args:
            new_instruction: New system instruction
            history: Current conversation history to preserve
        """
        self.system_instruction = new_instruction
        self.initialize_chat(history, self._tools)
