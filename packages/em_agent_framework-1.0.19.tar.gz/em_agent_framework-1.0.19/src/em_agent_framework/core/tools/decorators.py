"""
Tool decorators for defining LLM-friendly tool descriptions.

This module provides decorators to separate LLM-facing descriptions from
developer-facing docstrings.
"""

import asyncio
from functools import wraps
from typing import Callable, Optional


def tool(description: str, category: Optional[str] = None, short_description: Optional[str] = None):
    """
    Decorator to mark functions as tools with LLM-friendly descriptions.

    This decorator separates concerns:
    - Decorator description: What the LLM sees (usage-focused)
    - Docstring: What developers see (implementation-focused)
    - Short description: Brief description for complementary tools (shown in LLM context even when not loaded)

    Args:
        description: LLM-friendly description of what the tool does.
                    Should be clear, concise, and action-oriented.
        category: Optional category for organizing tools (e.g., "arithmetic", "statistics")
        short_description: Optional brief description for complementary tools.
                          This will be shown in LLM context even when the tool is not loaded.

    Raises:
        ValueError: If description is empty or too short

    Example:
        @tool(
            description="Add two numbers together and return their sum",
            category="arithmetic",
            short_description="Add two numbers"
        )
        def add(a: float, b: float) -> str:
            \"\"\"Implementation notes for developers.\"\"\"
            return str(a + b)
    """
    # Validate description at decoration time
    if not description:
        raise ValueError("Tool description cannot be empty")

    if not isinstance(description, str):
        raise ValueError(f"Tool description must be a string, got {type(description)}")

    # Check for common mistakes (before length check)
    if description.strip().endswith(".py"):
        raise ValueError(
            "Tool description looks like a filename. " "Did you forget the description parameter?"
        )

    if len(description.strip()) < 10:
        raise ValueError(f"Tool description too short (minimum 10 characters): '{description}'")

    def decorator(func: Callable) -> Callable:
        """Apply the decorator to the function."""
        # Store metadata as function attributes
        func.__tool_description__ = description.strip()
        func.__tool_category__ = category
        func.__tool_short_description__ = short_description.strip() if short_description else None
        func.__is_tool__ = True

        # Preserve function metadata and handle async/sync functions properly
        if asyncio.iscoroutinefunction(func):

            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                return await func(*args, **kwargs)

            # Copy tool attributes to wrapper
            async_wrapper.__tool_description__ = func.__tool_description__
            async_wrapper.__tool_category__ = func.__tool_category__
            async_wrapper.__tool_short_description__ = func.__tool_short_description__
            async_wrapper.__is_tool__ = func.__is_tool__

            return async_wrapper
        else:

            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            # Copy tool attributes to wrapper
            sync_wrapper.__tool_description__ = func.__tool_description__
            sync_wrapper.__tool_category__ = func.__tool_category__
            sync_wrapper.__tool_short_description__ = func.__tool_short_description__
            sync_wrapper.__is_tool__ = func.__is_tool__

            return sync_wrapper

    return decorator


def is_tool(func: Callable) -> bool:
    """
    Check if a function is decorated with @tool.

    Args:
        func: Function to check

    Returns:
        True if function is a tool, False otherwise
    """
    return getattr(func, "__is_tool__", False)


def get_tool_description(func: Callable) -> Optional[str]:
    """
    Get the tool description from a decorated function.

    Args:
        func: Function to get description from

    Returns:
        Tool description if available, None otherwise
    """
    return getattr(func, "__tool_description__", None)


def get_tool_category(func: Callable) -> Optional[str]:
    """
    Get the tool category from a decorated function.

    Args:
        func: Function to get category from

    Returns:
        Tool category if available, None otherwise
    """
    return getattr(func, "__tool_category__", None)


def get_tool_short_description(func: Callable) -> Optional[str]:
    """
    Get the tool short description from a decorated function.

    Args:
        func: Function to get short description from

    Returns:
        Tool short description if available, None otherwise
    """
    return getattr(func, "__tool_short_description__", None)


def validate_tool(func: Callable) -> None:
    """
    Validate that a function is properly decorated as a tool.

    Args:
        func: Function to validate

    Raises:
        ValueError: If function is not properly decorated or missing required metadata
    """
    if not is_tool(func):
        raise ValueError(
            f"Function '{func.__name__}' is not decorated with @tool. "
            f"Add @tool(description='...') decorator."
        )

    description = get_tool_description(func)
    if not description:
        raise ValueError(
            f"Tool '{func.__name__}' is missing description. "
            f"This should not happen - decorator validation failed."
        )
