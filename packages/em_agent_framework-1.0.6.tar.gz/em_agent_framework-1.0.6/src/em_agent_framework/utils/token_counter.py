"""
Utilities for counting tokens in Vertex AI/Gemini requests.

This module provides accurate token counting for Vertex AI using the
google.genai Client API which works for all Gemini models.
"""

from typing import Any, Dict, List, Optional

from google import genai
from google.genai import types


def count_tokens_in_messages(
    client: genai.Client,
    model_name: str,
    messages: List[Dict[str, Any]],
    tools: Optional[List[Any]] = None,
    fallback_model_name: Optional[str] = None,
) -> int:
    """
    Count tokens in messages using genai Client's count_tokens API.

    This works for all Gemini models including experimental ones by using
    the genai.Client API.

    Note: Token counting is not available for Anthropic/Claude models.

    Args:
        client: The genai.Client instance
        model_name: The model name to use for counting
        messages: List of message dicts in format [{'role': 'user', 'parts': [{'text': '...'}]}, ...]
        tools: Optional list of tool objects
        fallback_model_name: Optional fallback model name if primary fails

    Returns:
        Total token count, or -1 if counting fails
    """
    # Check if this is an Anthropic/Claude model - token counting not supported
    if "claude" in model_name.lower():
        return -1

    try:
        # Convert messages to Content format
        contents = []
        for msg in messages:
            if isinstance(msg, types.Content):
                contents.append(msg)
            elif isinstance(msg, dict):
                # Convert dict to Content
                role = msg.get("role", "user")
                parts = []
                for part_data in msg.get("parts", []):
                    if isinstance(part_data, dict):
                        if "text" in part_data:
                            parts.append(types.Part(text=part_data["text"]))
                    else:
                        parts.append(types.Part(text=str(part_data)))
                contents.append(types.Content(role=role, parts=parts))

        # Build config with tools if provided
        config = None
        if tools:
            tool_declarations = [
                types.FunctionDeclaration(
                    name=tool.name,
                    description=tool.description,
                    parameters=tool.parameters,
                )
                for tool in tools
            ]
            config = types.CountTokensConfig(
                tools=[types.Tool(function_declarations=tool_declarations)]
            )

        # Count tokens
        try:
            response = client.models.count_tokens(
                model=model_name,
                contents=contents,
                config=config,
            )

            # Extract token count
            if hasattr(response, "total_tokens"):
                return response.total_tokens

        except Exception as e:
            # If primary model fails and we have a fallback, try with fallback
            if fallback_model_name and fallback_model_name != model_name:
                try:
                    response = client.models.count_tokens(
                        model=fallback_model_name,
                        contents=contents,
                        config=config,
                    )

                    if hasattr(response, "total_tokens"):
                        return response.total_tokens
                except Exception:
                    pass

            print(f"[TOKEN_COUNT] Warning: Failed to count tokens: {e}")

    except Exception as e:
        # If all methods fail, return -1 to indicate error
        print(f"[TOKEN_COUNT] Warning: Failed to count tokens: {e}")

    # If we reach here, all methods failed
    return -1


def count_tokens_in_text(client: genai.Client, model_name: str, text: str) -> int:
    """
    Count tokens in a single text string.

    Args:
        client: The genai.Client instance
        model_name: The model name to use for counting
        text: Text string to count

    Returns:
        Token count, or -1 if counting fails
    """
    return count_tokens_in_messages(
        client, model_name, [{"role": "user", "parts": [{"text": text}]}]
    )
