"""
Configuration settings for the Agent framework.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class ModelConfig:
    """Configuration for a specific model."""

    name: str
    provider: str  # 'gemini' or 'anthropic'
    temperature: float = 0.1
    max_output_tokens: Optional[int] = None
    timeout: float = 10.0
    location: Optional[str] = None  # Override default location for this specific model


@dataclass
class AgentConfig:
    """Configuration for Agent behavior."""

    max_turns: int = 100
    max_retries_per_model: int = 3
    retry_delay: float = 1.0
    token_threshold: int = 100000
    verbose: bool = True
    enable_parallel_tools: bool = True
    max_parallel_tools: int = 5
    enable_recursive_agents: bool = False  # Enable recursive_agent_call tool by default
    max_recursion_depth: int = 2  # Maximum depth for recursive agent calls (2 = parent + 1 level of children)


@dataclass
class VertexAIConfig:
    """Configuration for Vertex AI."""

    project_id: Optional[str] = None
    location: str = "global"  # Global endpoint for Generative AI (higher availability)


@dataclass
class Config:
    """Main configuration object."""

    vertex_ai: VertexAIConfig = field(default_factory=VertexAIConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)

    # Default model fallback chain: Gemini 2.5 Flash -> Gemini 1.5 Pro -> Claude 3.5 Sonnet
    default_models: List[ModelConfig] = field(
        default_factory=lambda: [
            ModelConfig(name="gemini-2.5-flash", provider="gemini"),
            ModelConfig(name="gemini-1.5-pro", provider="gemini"),
            ModelConfig(name="claude-3-5-sonnet-v2@20241022", provider="anthropic"),
        ]
    )


# Global configuration instance
config = Config()
