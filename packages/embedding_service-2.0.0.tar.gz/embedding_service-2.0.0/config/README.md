# Configuration

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  

The project uses **two** configuration files only.

## Configs

### 1. **local_http.json** — local development (HTTP)

- **Use:** Run on host, HTTP, API key auth.
- **Port:** 8010 (configurable via `server.port`).
- **Features:** HTTP, no TLS, `embedding.cache_dir`, `embedding.max_texts_per_batch`, queue, no proxy registration.

**Run:**
```bash
python -m embed.main --config config/local_http.json
```

### 2. **container_mtls.json** — container / mTLS

- **Use:** Run in container with mTLS.
- **Port:** 8011 (configurable).
- **Features:** mTLS (server + client certs), same embedding/queue options as local. For deployment, set `server.host` (e.g. `0.0.0.0`) and certificate paths (e.g. `/etc/embedding-service/certs/...`).

**Run (in container):**
```bash
python -m embed.main --config config/container_mtls.json
```

## Generate / validate

```bash
python -m embed.cli.config_cli generate -o config/local_http.json --set server.port=8010
python -m embed.cli.config_cli validate -c config/local_http.json
python -m embed.cli.config_cli help
```

See [CONFIG_OPERATION_LIMITS.md](../docs/CONFIG_OPERATION_LIMITS.md) and [CONFIG_DEPENDENCIES.md](../docs/CONFIG_DEPENDENCIES.md) for limits and dependencies.
