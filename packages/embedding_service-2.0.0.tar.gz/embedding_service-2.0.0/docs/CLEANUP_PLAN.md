# Cleanup plan: remove duplicate code, use adapter only

**Author:** Vasiliy Zdanovskiy  
**email:** vasilyvz@gmail.com

This document is a step-by-step, file-by-file plan. Execute in order. Do not change code outside this plan.

---

## Part 1: Adapter config capabilities (reference)

Use only these; do not invent own loaders or path lists.

### 1.1 ConfigLoader (mcp_proxy_adapter.core.config.config_loader)

- **Import:** `from mcp_proxy_adapter.core.config.config_loader import ConfigLoader`
- **API:**
  - `ConfigLoader()` — constructor.
  - `load_from_file(config_path: str | Path) -> dict` — reads JSON file, returns dict. Raises `FileNotFoundError` if file missing, `json.JSONDecodeError` if invalid JSON.
- **Use:** Single source for reading config file. Path must come from `CONFIG_FILE` env (set by embed main before adapter runs).

### 1.2 Config (mcp_proxy_adapter.core.config.config / mcp_proxy_adapter.config)

- **Import:** `from mcp_proxy_adapter.config import Config` or `from mcp_proxy_adapter.core.config import Config`
- **API:**
  - `Config(config_path: Optional[str] = None, validate_on_load: bool = False)` — loads from file (default `./config.json`), optionally from env; stores in `config_data`.
  - `config_data: Dict[str, Any]` — full config dict.
  - `get(key: str, default: Any = None) -> Any` — dot notation, e.g. `get("embedding.model_name", "all-MiniLM-L6-v2")`.
  - `get_all() -> Dict[str, Any]` — returns `config_data`.
  - `load_from_file(path)` — not on Config; Config loads in `__init__` via `load_config()` which uses `self.loader.load_from_file(self.config_path)`.
- **Use:** Adapter app factory uses `Config(config_path=...)` and `config_instance.config_data`. In embed we must not create a second Config with a different path; we use one path: `CONFIG_FILE`.

### 1.3 Global config (mcp_proxy_adapter.config)

- **Import:** `from mcp_proxy_adapter.config import get_config`
- **API:** `get_config() -> Config` — returns global singleton Config (default path `./config.json` if never set). Adapter app factory does not set this global; it uses `load_and_validate_config(config_path)` and passes dict to `create_app(app_config=...)`. So in embed the global Config may not have our config_path. Therefore embed must not rely on `get_config()` for the application config file; only on `CONFIG_FILE` + ConfigLoader (or our wrapper that uses them).

### 1.4 App factory config loading (mcp_proxy_adapter.core.app_factory.config_loader)

- **Function:** `load_and_validate_config(config_path: Optional[str]) -> Dict[str, Any]`
- **Behaviour:** If `config_path` given and file exists: creates `Config(config_path=str(config_file))`, gets `config_instance.config_data`, runs validators (UUID, SSL, security), returns dict. If no path: uses `config.config_data` (defaults). On validation errors: `sys.exit(1)`.
- **Use:** Called by `create_and_run_server(config_path=...)`. Embed main sets `os.environ["CONFIG_FILE"] = str(args.config)` and passes `args.config` to `create_and_run_server`. So the same path is used by adapter and must be the only path used by embed for that process.

### 1.5 Embed’s existing wrapper (embed.config.embed_config_loader)

- **Purpose:** Single place that uses adapter ConfigLoader + `CONFIG_FILE`; cache by path+mtime.
- **API:**
  - `get_config_dict() -> Optional[Dict[str, Any]]` — from `CONFIG_FILE` env, uses `ConfigLoader().load_from_file(path)`; returns None if env unset or file missing/invalid; caches by path+mtime.
  - `get_coalescing_config() -> Optional[CoalescingConfig]` — from `get_config_dict()`, parses to ConfigModel, returns coalescing section.
  - `get_embedding_section() -> Dict[str, Any]` — from `get_config_dict()`, returns `data.get("embedding", {})` or `{}`.
- **Use:** All embed code that needs config must use this module (or the same contract: CONFIG_FILE + ConfigLoader). No hardcoded paths, no SimpleConfig, no legacy Config in embed.

---

## Part 2: What to remove (step-by-step, by file)

### Step 1: Remove permissions middleware (already done in a previous session; if not, do this)

| # | File | Action |
|---|------|--------|
| 1.1 | `embed/middleware/permissions_middleware.py` | **DELETE** the file. It duplicates adapter security; adapter owns all network and auth. |
| 1.2 | `embed/middleware/__init__.py` | **REPLACE** content: remove `from .permissions_middleware import PermissionsMiddleware` and `__all__ = ["PermissionsMiddleware"]`. Leave empty package: e.g. docstring + `__all__: list[str] = []`. |
| 1.3 | `mypy.ini` | **REMOVE** the section `[mypy-embed.middleware.permissions_middleware]` (and its `disable_error_code` line). |
| 1.4 | `docker/embed/middleware/permissions_middleware.py` | **DELETE** (mirror of embed). |
| 1.5 | `docker/embed/middleware/__init__.py` | **REPLACE** same as 1.2: no PermissionsMiddleware, empty `__all__` or no export. |
| 1.6 | `docs/COALESCING_ANALYSIS.md` | **EDIT** any sentence that says "Only PermissionsMiddleware exists" or similar; replace with note that middleware/security is handled by adapter. |

---

### Step 2: Rewrite embedding_initializer to use only adapter config

Single source of config: `CONFIG_FILE` via adapter reader. Use `embed_config_loader.get_config_dict()` and from it take `embedding` and `queue_manager`; no SimpleConfig, no legacy Config, no hardcoded list of paths.

| # | File | Action |
|---|------|--------|
| 2.1 | `embed/services/embedding_initializer.py` | **REWRITE** config loading block (from start of `try` until after `get_config_value` / application of config to `service`). **REMOVE:** all imports of `SimpleConfig`, `SimpleConfigValidator`, `Config as MCPConfig`, `config as global_config`; the whole loop over `config_paths`; the merge from `merge_path` and `/etc/embedding-service/`; both fallback blocks that use `MCPConfig` and `docker_config_path`. **REPLACE WITH:** 1) `from embed.config.embed_config_loader import get_config_dict` (and optionally `get_embedding_section` if you prefer). 2) `config_data = get_config_dict() or {}`. 3) Helper `get_config_value(key, default)` that works on `config_data` with dot notation (same as now). 4) If `config_data` is empty, use defaults for `service.model_name`, `service.device`, etc. (same default values as today). 5) Keep the rest of the function unchanged: timing_recorder setup, queue_manager max_concurrent_jobs from config, model cache dirs, `load_sentence_transformer_with_auto_device`, dimension detection, logging. **DO NOT** add new dependencies on SimpleConfig or adapter Config class; only ConfigLoader via embed_config_loader. |

---

### Step 3: Ensure no other code uses removed or duplicate config logic

| # | File | Action |
|---|------|--------|
| 3.1 | `embed/config/embed_config_loader.py` | **CHECK** only: must use only `mcp_proxy_adapter.core.config.config_loader.ConfigLoader` and `os.environ.get("CONFIG_FILE")`. No changes if already so. |
| 3.2 | `embed/main.py` | **CHECK** only: `os.environ["CONFIG_FILE"] = str(args.config)` is set before `create_and_run_server(config_path=args.config)`. No other config paths. No changes if already so. |
| 3.3 | Any file that imported `PermissionsMiddleware` or `embed.middleware.permissions_middleware` | **SEARCH** repo for `PermissionsMiddleware`, `permissions_middleware`, `embed.middleware`. **REMOVE** or **REPLACE** imports/usages. If nothing found, skip. |

---

### Step 4: Tests and code analysis

| # | File / Command | Action |
|---|----------------|--------|
| 4.1 | Tests that reference `PermissionsMiddleware` or embed middleware | **GREP** tests for `permissions_middleware`, `PermissionsMiddleware`. **EDIT** or remove those tests; or adjust to “no custom middleware”. |
| 4.2 | `code_mapper` | Run after all file changes: `code_mapper` (or project’s equivalent). |
| 4.3 | Linters | Run `black`, `flake8`, `mypy` on changed files and fix reported issues. |

---

## Part 3: Order of execution (summary)

1. **Step 1** — Remove middleware: delete both `permissions_middleware.py` (embed + docker), update both `__init__.py`, fix `mypy.ini`, fix `docs/COALESCING_ANALYSIS.md`.
2. **Step 2** — In `embedding_initializer.py` only: replace config loading with `get_config_dict()` (and optional `get_embedding_section()`), dot-notation helper on returned dict, same defaults when dict is empty; remove all SimpleConfig/legacy Config and hardcoded path list.
3. **Step 3** — Verify embed_config_loader and main.py; search and fix any remaining references to PermissionsMiddleware/middleware.
4. **Step 4** — Tests, code_mapper, black, flake8, mypy.

Do not add new middleware, new config loaders, or new path lists. Use only CONFIG_FILE + adapter ConfigLoader (via embed_config_loader) and this plan.

---

## Part 4: Other "gifts" (queue, commands, config duality, scripts)

These are additional places that duplicate logic, use wrong config source, or diverge from the single-entry (main.py + CONFIG_FILE + adapter) model. They are **not only** "reading and initialisation"; they affect queue, commands, and scripts.

### 4.1 Queue

| Where | Issue | Recommendation |
|-------|--------|----------------|
| `embed/main.py` — `initialize_queue_manager()` | Comment says "We need to read config to check queue_manager.enabled" but code does **not** read config; it only calls `init_global_queue_manager()`. Adapter decides internally. | **Doc only:** Fix comment: e.g. "Adapter's init_global_queue_manager() reads queue_manager.enabled from its config; we only trigger init." No code change if adapter indeed reads config. |
| `embed/commands/embed_router.py` | Lazy import: `await __import__(...)` for `get_global_queue_manager`. | **Refactor:** Use normal top-level import (as in `embed_job_status_command.py`). Remove dynamic import. |
| `embed/commands/embed_job_status_command.py` | Uses `registry.get_command("queue_get_job_status")` — adapter's command. Correct. | No change. |

Queue **registration** and **queue commands** are done by the adapter when `queue_manager.enabled: true`; embed only calls `init_global_queue_manager()` in an after_init hook and uses `get_global_queue_manager()` in router and job-status command. No duplicate queue implementation in embed.

### 4.2 Commands

| Where | Issue | Recommendation |
|-------|--------|----------------|
| `embed/main.py` | Registers commands via `register_custom_commands_hook(register_embedding_commands)`. Adapter calls the hook; same commands are auto-imported in spawn via `register_auto_import_module("embed.commands")`. | No change. |
| `embed/commands/__init__.py` | `_auto_register_commands()` runs on import (for spawn/queue workers). Duplicates the same list of commands as main's hook. | Acceptable: required for child processes. No change. |
| `scripts/run_local_server.py` | **Different entry point:** uses `create_app(..., app_config=None, config_path=args.config)` **without** app_factory. Registers only `EmbedCommand`, `ModelsCommand`, `EmbedJobStatusCommand` — **no** `EmbedRouterCommand`, **no** `embed_execute`. Reads config again with `open(config_path)` + `json.load` for SSL. Does **not** set `CONFIG_FILE`. So when `EmbeddingService.get_instance()` runs, initializer may see no CONFIG_FILE and use fallback mess. | **Gift:** Either (a) **Deprecate** run_local_server and document "use main.py with --config" for local run, or (b) **Fix:** set `os.environ["CONFIG_FILE"] = str(args.config)` before any embed code; register same commands as main (EmbedRouterCommand, embed_execute, etc.); use adapter or embed_config_loader for SSL instead of manual json load. Prefer (a) if this script is legacy. |
| `tests/conftest.py` | Uses `create_app(app_config=test_config)` and sets `CONFIG_FILE`/`MCP_CONFIG_FILE` to temp file. Manually registers `EmbedRouterCommand` if `registry.get_command("embed")` fails. | Acceptable for tests. Optionally: ensure CONFIG_FILE is set before any embed code that reads config. |

### 4.3 Config: two entry points (ConfigManager vs embed_config_loader)

| Where | Issue | Recommendation |
|-------|--------|----------------|
| `embed/config/embed_config_loader.py` | Single source for **runtime**: CONFIG_FILE + ConfigLoader, cache by path+mtime. Used by router, embed_command_helpers, and (after Step 2) embedding_initializer. | Keep as is. |
| `embed/config/config_manager.py` | **Second** API: `ConfigManager(config_path?).load_from_file(path)` → ConfigModel; `get_queue_manager_config()`, `get_coalescing_config()`, `get_embedding_config()`. Used in **tests** and in `embed/config/test_config_manager.py`. Not used by runtime embed code (router, initializer, helpers use embed_config_loader). | **Clarify:** Runtime must use only CONFIG_FILE via embed_config_loader. ConfigManager is for tests and tools that need an **explicit path** and full ConfigModel; it already uses ConfigLoader inside. Add one sentence in config_manager docstring: "For runtime config use embed_config_loader (CONFIG_FILE). This class is for tests and CLI tools with explicit path." |

So: **reading and initialisation** are covered by Part 2 (initializer → embed_config_loader). **Queue** and **commands** are mostly correct; the "gifts" are run_local_server (incomplete commands + no CONFIG_FILE + duplicate config read) and embed_router's lazy import.

### 4.4 Docker and test "config" usage

| Where | Issue | Recommendation |
|-------|--------|----------------|
| `docker/embed/` | Copies of embed code (e.g. config_manager, commands). Must stay in sync with embed/ after Step 1–2 (e.g. no permissions_middleware; no duplicate config logic in any copied initializer). | After Step 2, **sync** docker/embed with embed/ (middleware already in Step 1; if docker has its own embedding_initializer or embedding_service that does legacy config, align with embed). |
| `tests/test_protocol_*.py`, `test_config_debug.py`, `test_adapter_example.py`, `test_global_protocol_manager.py` | They call `config.load_from_file(...)` — that is **adapter's** global config, not embed's. | No change in this plan; they test adapter behaviour. |

### 4.5 Summary of "gifts" to fix (in addition to Part 2)

1. **Step 2 (already in plan):** embedding_initializer — only CONFIG_FILE via embed_config_loader; remove SimpleConfig, legacy Config, multiple paths.
2. **embed_router.py:** Replace dynamic import of `get_global_queue_manager` with normal top-level import.
3. **main.py:** Fix comment in `initialize_queue_manager()` (adapter reads config, we do not).
4. **run_local_server.py:** Either deprecate or fix: set CONFIG_FILE, register full command set, avoid duplicate config read.
5. **config_manager.py:** Add docstring note that runtime uses embed_config_loader; ConfigManager for tests/tools with explicit path.
6. **docker/embed:** Keep in sync with embed after Steps 1–2.
