# Embedding Client Developer Guide

## Overview

The `EmbeddingClient` provides a high-level interface for interacting with the embedding service API. The client handles queue management, job polling, and result retrieval automatically.

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

## Key Features

1. **Automatic Queue Polling**: The client automatically polls the queue for job completion
2. **Flexible Timeout Control**: Support for timeout limits or unlimited waiting
3. **Async/Await Support**: Fully asynchronous API using Python's `asyncio`
4. **Error Handling**: Comprehensive error handling with clear error messages

## Recent Changes

### Queue-Based Processing

**Important**: The embedding service now uses a **single unified command** `embed` that works exclusively through the queue system.

#### What Changed

1. **Removed**: Multiple embedding commands (`embed_queue`, `embed_direct`, etc.)
2. **Unified**: Single `embed` command with `use_queue=True`
3. **Client Behavior**: Client automatically polls the queue when `wait=True`

#### Migration Guide

**Before** (old API):
```python
# Old way - multiple commands
response = await client.jsonrpc_call("embed_queue", {...})
```

**After** (new API):
```python
# New way - single embed command
result = await client.embed(texts=["Hello"], wait=True)
```

## Client Initialization

```python
from embed.client.embedding_client import EmbeddingClient

# HTTP connection
client = EmbeddingClient(
    protocol="http",
    host="127.0.0.1",
    port=8000
)

# HTTPS with mTLS
client = EmbeddingClient(
    protocol="https",
    host="127.0.0.1",
    port=8001,
    cert="/path/to/client.crt",
    key="/path/to/client.key",
    ca="/path/to/ca.crt"
)
```

## Embedding Generation

### Basic Usage

```python
# Submit job and get job_id immediately
result = await client.embed(
    texts=["Hello, world!", "Привет, мир!"],
    wait=False
)
job_id = result["job_id"]
print(f"Job submitted: {job_id}")
```

### Waiting for Results

The client **automatically polls the queue** when `wait=True`:

```python
# Wait for completion with default timeout (60 seconds)
result = await client.embed(
    texts=["Hello, world!"],
    wait=True
)

# Access results
for item in result["results"]:
    print(f"Text: {item['body']}")
    print(f"Embedding: {item['embedding'][:5]}...")  # First 5 values
```

### Timeout Control

#### Limited Timeout

```python
# Wait up to 120 seconds
result = await client.embed(
    texts=["Long processing text..."],
    wait=True,
    wait_timeout=120  # 2 minutes
)
```

#### Unlimited Waiting

Set `wait_timeout=0` to wait indefinitely:

```python
# Wait indefinitely (no timeout)
result = await client.embed(
    texts=["Very long processing..."],
    wait=True,
    wait_timeout=0  # Wait forever
)
```

**Use Case**: When you need to process very large batches or have no time constraints.

### Custom Poll Interval

Adjust how often the client checks the queue:

```python
# Check queue every 0.5 seconds (faster polling)
result = await client.embed(
    texts=["Hello"],
    wait=True,
    wait_timeout=60,
    poll_interval=0.5  # Check every 0.5 seconds
)

# Check queue every 2 seconds (slower polling, less server load)
result = await client.embed(
    texts=["Hello"],
    wait=True,
    wait_timeout=60,
    poll_interval=2.0  # Check every 2 seconds
)
```

## Queue Polling Details

### How It Works

1. **Job Submission**: Client submits job to `embed` command
2. **Job ID Return**: Server returns `job_id` immediately
3. **Automatic Polling**: If `wait=True`, client starts polling:
   - Calls `queue_get_job_status` or `embed_job_status`
   - Checks job status: `pending`, `running`, `completed`, `failed`
   - Waits `poll_interval` seconds between checks
   - Continues until job completes, fails, or timeout reached

### Polling Flow

```
Client                    Server
  |                         |
  |-- embed(texts) -------->|
  |<-- job_id --------------|
  |                         |
  |-- job_status(job_id) -->|  (poll_interval = 1.0s)
  |<-- status: pending -----|
  |   [wait 1.0s]           |
  |-- job_status(job_id) -->|
  |<-- status: running -----|
  |   [wait 1.0s]           |
  |-- job_status(job_id) -->|
  |<-- status: completed ---|
  |   [return results]      |
```

### Status Values

- `pending`: Job is queued, waiting to start
- `running`: Job is currently being processed
- `completed`: Job finished successfully
- `failed`: Job failed with error

## Manual Job Status Checking

You can also check job status manually:

```python
# Submit job
result = await client.embed(["Hello"], wait=False)
job_id = result["job_id"]

# Check status manually
status = await client.job_status(job_id)
print(f"Status: {status['status']}")
print(f"Done: {status['done']}")

# Wait for completion manually
if not status['done']:
    result = await client.wait_for_job(job_id, timeout=60)
```

## Error Handling

### Timeout Errors

```python
try:
    result = await client.embed(
        texts=["Very long text..."],
        wait=True,
        wait_timeout=10  # 10 seconds
    )
except TimeoutError as e:
    print(f"Job timed out: {e}")
    # Job is still running on server, you can check status later
```

### Job Failure

```python
try:
    result = await client.embed(
        texts=["Invalid text..."],
        wait=True
    )
except RuntimeError as e:
    print(f"Job failed: {e}")
    # Error details are in the exception message
```

### Job Not Found

```python
try:
    status = await client.job_status("invalid-job-id")
except RuntimeError as e:
    print(f"Job not found: {e}")
```

## Complete Example

```python
import asyncio
from embed.client.embedding_client import EmbeddingClient

async def main():
    # Initialize client
    client = EmbeddingClient(
        protocol="http",
        host="127.0.0.1",
        port=8000
    )
    
    # Check server health
    health = await client.health()
    print(f"Server health: {health}")
    
    # Generate embeddings with automatic polling
    try:
        result = await client.embed(
            texts=[
                "Hello, world!",
                "Привет, мир!",
                "Machine learning is fascinating."
            ],
            wait=True,
            wait_timeout=120,  # Wait up to 2 minutes
            poll_interval=1.0  # Check every second
        )
        
        print(f"Model: {result['model']}")
        print(f"Dimension: {result['dimension']}")
        print(f"Results: {len(result['results'])} texts processed")
        
        for i, item in enumerate(result['results'], 1):
            print(f"\n{i}. Text: {item['body'][:50]}...")
            print(f"   Embedding size: {len(item['embedding'])}")
            print(f"   Tokens: {len(item['tokens'])}")
            
    except TimeoutError:
        print("Job timed out - it may still be processing")
    except RuntimeError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(main())
```

## API Reference

### `embed()` Method

```python
async def embed(
    texts: List[str],
    model: Optional[str] = None,
    dimension: Optional[int] = None,
    job_id: Optional[str] = None,
    wait: bool = False,
    wait_timeout: int = 60,
    poll_interval: float = 1.0,
) -> Dict[str, Any]
```

**Parameters:**
- `texts` (required): List of texts to embed
- `model` (optional): Model name to use
- `dimension` (optional): Expected vector dimension
- `job_id` (optional): Custom job ID
- `wait` (default: `False`): If `True`, wait for completion (auto-polling)
- `wait_timeout` (default: `60`): Max wait time in seconds. `0` = unlimited
- `poll_interval` (default: `1.0`): Seconds between queue checks

**Returns:**
- If `wait=False`: `{"job_id": "...", "status": "pending", ...}`
- If `wait=True`: `{"results": [...], "model": "...", "dimension": 384}`

**Raises:**
- `RuntimeError`: Request failed or job failed
- `TimeoutError`: Timeout reached (only if `wait_timeout > 0`)

### `wait_for_job()` Method

```python
async def wait_for_job(
    job_id: str,
    timeout: int = 60,
    poll_interval: float = 1.0
) -> Dict[str, Any]
```

**Parameters:**
- `job_id` (required): Job ID to wait for
- `timeout` (default: `60`): Max wait time in seconds. `0` = unlimited
- `poll_interval` (default: `1.0`): Seconds between queue checks

**Returns:** Complete job results with embeddings

**Raises:**
- `TimeoutError`: Timeout reached (only if `timeout > 0`)
- `RuntimeError`: Job failed or not found

### `job_status()` Method

```python
async def job_status(job_id: str) -> Dict[str, Any]
```

**Parameters:**
- `job_id` (required): Job ID to check

**Returns:** Job status information:
```python
{
    "exists": True,
    "status": "completed|running|pending|failed",
    "done": True|False,
    "result": {...}  # Only if completed
}
```

## Best Practices

1. **Use Appropriate Timeouts**: Set reasonable timeouts based on expected processing time
2. **Adjust Poll Interval**: Use shorter intervals for faster feedback, longer for less server load
3. **Handle Errors**: Always wrap calls in try/except blocks
4. **Check Health**: Verify server health before submitting large batches
5. **Monitor Job Status**: For long-running jobs, consider checking status manually

## Troubleshooting

### Job Takes Too Long

- Increase `wait_timeout` or set to `0` for unlimited waiting
- Check server logs for errors
- Verify queue is processing jobs (`max_concurrent_jobs` setting)

### Frequent Timeout Errors

- Increase `wait_timeout` value
- Check if server is overloaded
- Consider processing smaller batches

### Connection Errors

- Verify server is running and accessible
- Check network connectivity
- Verify SSL certificates (for HTTPS/mTLS)

## See Also

- [Queue Configuration Guide](./QUEUE_GPU_OVERLOAD_EXPLANATION.md)
- [Configuration Limits](./CONFIG_OPERATION_LIMITS.md)
- [Docker Queue Setup](./DOCKER_QUEUE_CONFIG.md)

