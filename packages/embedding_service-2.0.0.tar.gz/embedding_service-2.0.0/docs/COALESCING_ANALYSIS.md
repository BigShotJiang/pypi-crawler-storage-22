# Request coalescing / dynamic batching — code analysis and conclusions

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  
**Date:** 2026-02  
**Audience:** Server (embed) developers

---

## 1. Purpose

This document analyses the current embedding server codebase in the context of the [Request coalescing / dynamic batching proposal](COALESCING_PROPOSAL.md) and provides conclusions on feasibility, placement, and implementation notes. Step-by-step implementation plan: [docs/coalescing_plan/00_overview.md](coalescing_plan/00_overview.md).

---

## 2. Current architecture (findings)

### 2.1 Request path

- **Entry:** HTTP/JSON-RPC requests are handled by **mcp_proxy_adapter** (`create_and_run_server` in `embed/main.py`). The adapter dispatches methods to registered commands.
- **Embed command:** `EmbedCommand` is registered with `use_queue = True` (see `embed/commands/embed_command.py`). The adapter therefore:
  1. Creates **one queue job per incoming embed request**.
  2. Returns **one `job_id`** to the client immediately (no blocking).
  3. Runs `EmbedCommand.execute(**params)` **inside a worker process** (spawn mode) when the job is dequeued.

- **Queue:** Queue manager lives in **mcp_proxy_adapter** (`queuemgr_integration`). The embed app only initializes it via `initialize_queue_manager()` in `embed/main.py` and reads config (`queue_manager.enabled`, `max_concurrent_jobs`, etc.) via `ConfigManager.get_queue_manager_config()`. Job submission and worker loop are **outside this repository**.

- **Request shape:** The adapter delivers **one complete RPC** per call: the full `params` (including the full `texts` list) are available at once. There is **no per-text streaming** at the API boundary — we do not receive “one text, then another”. So coalescing is **per request** (merge multiple full requests into one batch), not “enqueue as each text arrives”. To support “as soon as we got a text, put it in the queue” would require a separate streaming input protocol (e.g. client sends texts incrementally); that is out of scope for the current design.

- **Model server:** Communication with the model server uses a stream socket (asyncio `StreamReader`/`StreamWriter`), but the **application protocol** is full request / full response: one JSON message with the whole batch is sent, one JSON response is read. So we do not stream texts one-by-one to the model server either.

### 2.2 Embed execution

- **File:** `embed/commands/embed_command.py`.
- **Flow:** `execute()` receives a single request’s params (`texts`, `model`, `dimension`, `error_policy`, `device`). It uses either **ModelClient** (model server) or **EmbeddingService** (direct). It returns a **SuccessResult** with:
  - `data.embeddings`: list of vectors (one per text).
  - `data.results`: list of `{body, embedding, tokens, bm25_tokens, error}` (one per text).
  - `data.model`, `data.dimension`, `data.device`.

- **Result shape:** The number of elements in `results` / `embeddings` equals `len(texts)`. Slicing by `[offset:offset+count]` is enough to get the slice for one logical request.

### 2.3 Configuration

- **Queue:** `embed/config/config_manager.py` defines `QueueManagerConfig`: `enabled`, `in_memory`, `max_concurrent_jobs`, `completed_job_retention_seconds`. No coalescing options yet.
- **Embedding:** `EmbeddingConfig` holds `batch_size`, `max_batch_size`, `max_text_length`, etc. No coalescing here either.
- **Middleware:** Only `PermissionsMiddleware` exists; there is no request-level coalescing or batching layer.

### 2.4 Job status and client behaviour

- **Status:** Clients get a `job_id` and poll via `embed_job_status` (or adapter’s `queue_get_job_status`). `embed/commands/embed_job_status_command.py` delegates to the adapter’s queue command and returns the **full** job result.
- **Client:** `embed/client/embedding_client.py` sends one request per call and polls by `job_id` until completion.

---

## 3. Chosen architecture: single queue handler (accumulation procedure)

The only queue handler from the adapter’s perspective is an **accumulation procedure** that:

1. **Accumulates** incoming embed requests (optional short time window to merge near-simultaneous requests; hard limit on max batch size).
2. **Forms a batch** of logical jobs and builds one merged payload (merged `texts` + slice metadata).
3. **Submits one batch job** to the worker (one queue entry, one physical job).
4. **Worker** processes the batch (single `embed()` call) and returns the combined result.
5. **Handler** (same accumulation layer), on batch completion:
   - **Distributes** the response: slices the combined result by the stored mapping.
   - **Assigns** each slice to the corresponding logical job.
   - **Sets status** (and result) for each of the N jobs so that clients polling by `job_id` get their slice.

So: one component does accumulation → one batch to worker → worker returns → same component distributes answers and sets status per job. No other queue handler; the adapter’s queue is fed only by this procedure (one physical job per batch).

**Flush policy (no artificial delay):** Coalescing is for speed, not for slowing down. Submit to the queue as soon as there is something to send: one request → submit one job (batch of 1) immediately; two requests arrived together → submit a batch of 2; N requests collected within the window → submit one batch of N. The only constraint is not exceeding the allowed batch size (`coalescing_max_texts`). The time window is used only to merge requests that arrive close together; a single request is never held waiting for the window.

**Batch size when flushing:** When a flush is triggered, take from the buffer the **maximum possible number of texts** that fit within `coalescing_max_texts`: drain requests from the buffer (in order, whole requests only — do not split a request across batches) until adding the next request would exceed the limit, or until the buffer is empty. So each batch is as large as the limit allows (or smaller if the buffer has fewer texts).

### 3.1 Queue distribution across parallel processes (config-driven)

The queue must support **distribution across parallel processes** as defined by the existing config.

- **Config:** `queue_manager.max_concurrent_jobs` (see `QueueManagerConfig` in `embed/config/config_manager.py`) — maximum number of jobs run **concurrently** (i.e. number of worker processes that can each take a job from the queue).
- **Behaviour:**
  - The accumulation procedure submits **batch jobs** (one queue entry per batch). The queue may hold **several** such batch jobs at once.
  - The queue manager runs up to **P** worker processes in parallel (P = `max_concurrent_jobs`). Each process dequeues **one** job (one batch), runs `EmbedCommand.execute()` for that batch, and returns the result.
  - When a batch job completes, the handler (accumulation layer) distributes the result to the corresponding logical jobs and sets their status, as in §3.
- **Design requirement:** The implementation must **preserve** this semantics: coalescing produces one physical job per batch; the adapter’s queue and worker pool (driven by `max_concurrent_jobs`) distribute these batch jobs across parallel processes. No change to the existing queue config contract; only the *content* of each job becomes a coalesced batch instead of a single request.
- **GPU note:** If each worker process loads its own model (no model server), `max_concurrent_jobs > 1` implies multiple model copies in memory and possible GPU contention — as in `QUEUE_GPU_OVERLOAD_EXPLANATION.md`. With coalescing, fewer, larger jobs may allow keeping `max_concurrent_jobs = 1` while still improving throughput; if resources allow, raising `max_concurrent_jobs` distributes batches across processes as per config.

---

## 4. Conclusions on proposal

### 4.1 Option A — Coalescer as single queue handler (recommended)

- **Feasibility:** **Yes**, entirely within the embed repo, without changing the adapter’s worker loop.
- **Idea:** This is the “single queue handler” from §3: the accumulation procedure is the only component that feeds the queue and handles completion.
  1. **Coalescer** (accumulation procedure) accepts embed requests and does **not** submit one job per request immediately.
  2. It buffers requests only to merge near-simultaneous ones (short optional window); flushes immediately when there is a single request (batch of 1) or when total texts reach `coalescing_max_texts`. No artificial delay: one request → one job submitted right away.
  3. It merges `texts` into one list and keeps a mapping: for each original request, `(num_texts_i, result_offset)` (or just `num_texts_i` and compute offsets).
  4. It submits **one** job to the existing queue with params: e.g. `texts=merged_texts`, same `model`/`dimension`/`error_policy`/`device`, plus internal metadata for slicing (e.g. `_coalesced_slices: [n1, n2, ...]`). The adapter sees one normal embed job.
  5. When that job completes, the coalescer gets one big result, slices it by the mapping, and **resolves N logical jobs** (one per original request). Clients that poll by their **logical `job_id`** get “pending” until the physical job completes, then receive only their slice.

- **Requirements:**
  - **Logical job IDs:** The coalescer must issue and track logical `job_id`s and map them to the single physical job and to `(start_index, count)` in the merged result. So we need a small store: `logical_job_id -> (physical_job_id, start_index, count)` and, when the physical job completes, `physical_job_id -> full_result`.
  - **Status endpoint:** `embed_job_status` (or a thin wrapper) must resolve logical `job_id`: if the physical job is still running, return “pending”; if completed, return the slice `results[start_index:start_index+count]` (and the same slice of `embeddings`) so the response shape is unchanged for the client.
  - **Only one physical job per batch:** So we do **one** `embed()` call per coalesced batch; GPU and model usage stay as today (one model, one forward per batch).

- **Compatibility:** Clients still send one request per logical call and poll one `job_id`; they receive the same response shape (their slice of `results`/`embeddings`). No client change.

### 4.2 Option B — Coalescing inside the worker

- **Feasibility:** **Not** in this repo alone. The worker loop and dequeue policy live in mcp_proxy_adapter. To “merge several small jobs in the worker” we would need either:
  - A **batch dequeue** API (get several jobs at once), or
  - A custom worker loop that peeks and groups embed jobs.
- Both imply **adapter changes**. Option B is therefore out of scope for an embed-only implementation.

### 4.3 Where to implement Option A

- **Best place:** A **coalescing layer in front of the queue**:
  - Either a dedicated **middleware** that intercepts “embed” before the adapter creates a job (if the adapter exposes such a hook), or
  - A **wrapper command** (e.g. “embed” implemented as a coalescing facade that buffers, then submits one job with merged payload and implements logical job_id handling and status resolution).
- The current codebase does **not** show an adapter hook for “before job submit”. So the practical approach is:
  - Implement a **coalescing embed facade** that:
    - Handles the “embed” method when coalescing is enabled.
    - Buffers requests (time window + max texts), merges params, submits one job with merged `texts` and slice metadata.
    - Returns a **logical** `job_id` per request and keeps the mapping.
  - **embed_job_status** (or a wrapper) resolves logical `job_id` from the coalescer store and returns the slice when the physical job is done.
- This can be done in the embed repo without modifying mcp_proxy_adapter, as long as we can **register** this coalescing behaviour (e.g. by registering a different command that handles “embed” when coalescing is on, or by wrapping the way “embed” is invoked). Exact wiring depends on how the adapter exposes “execute command” vs “submit job” (not visible in this repo).

### 4.4 Configuration

- **Existing (unchanged):** `queue_manager.max_concurrent_jobs` — number of parallel worker processes that consume from the queue. Coalescing does not replace this; batch jobs are distributed across these processes as today (see §3.1).
- **Suggested location for coalescing:** New section **`coalescing`** (or under **`queue_manager`**) in the same config model used by `ConfigManager`.
- **Suggested parameters (coalescing):**
  - `coalescing_enabled`: bool, default `False`.
  - `coalescing_window_sec`: float (e.g. 0.02–0.05).
  - `coalescing_max_texts`: int (e.g. 32, 64).
  - Optional: `coalescing_max_wait_sec` per request (max wait for a single request if no other requests arrive).
- **Config code:** Extend `embed/config/config_manager.py` (new model or new fields) and load these in the coalescer. Defaults keep current behaviour when coalescing is off.

### 4.5 Batch homogeneity

- Coalescing only makes sense if the single `embed()` call can serve all texts in the batch. So we should **only merge requests that share**:
  - `model`
  - `dimension`
  - `error_policy`
  - `device`
- If the proposal allows different `model`/`dimension` per request, we would need to split batches by these keys and only coalesce within each group (same as in the proposal’s “single embed call” assumption).

### 4.6 Error handling (aligned with proposal)

- **fail_fast:** If the single batch call fails, the whole physical job fails; all N logical requests get the same error (e.g. “batch failed”).
- **continue:** If the server supports per-item errors, the merged result already has per-item `error` in `results[i]`. When splitting, each logical request gets its slice; per-item errors in that slice are preserved. No extra mapping beyond the slice indices.

### 4.7 Mapping and splitting (already supported by result shape)

- **Stored per logical request:** `(num_texts_i, result_offset)` or just `num_texts_i` and offsets as cumulative sum.
- **After embed() returns:** `data.results` and `data.embeddings` are lists; slice `[offset:offset+num_texts_i]` gives the result for request `i`. Existing `EmbedCommand` already returns one entry per text; no change needed inside `execute()` for slicing, only in the coalescer and in status resolution.

---

## 5. Open points (from proposal and analysis)

1. **Exact placement:** Implement as a coalescing “embed” facade + logical job store + embed_job_status resolution. The exact hook (middleware vs command registration) depends on the adapter’s public API for “embed” and job submission (not fully visible in this repo).
2. **Adapter contract:** Confirm that we can submit one job with a custom payload (merged `texts` + internal slice metadata) and that the adapter stores the full result under one physical `job_id` so we can slice and assign to logical jobs.
3. **job_id and retention:** Logical job_ids should be resolved from the coalescer store; physical job retention remains as today (`completed_job_retention_seconds`). Decide how long to keep logical job metadata (e.g. same as retention, or separate TTL).
4. **Metrics:** Add optional metrics (e.g. coalesced_batch_size, coalescing_wait_sec per request) to tune window and max_texts; can be a follow-up.
5. **Scope:** Limit coalescing to the “embed” command unless we later add other heavy commands that benefit from the same pattern.

---

## 6. Summary

| Topic | Conclusion |
|-------|------------|
| **Single queue handler (Option A)** | One accumulation procedure: accumulates → forms batch → one job to worker → distributes responses and sets status per logical job. |
| **Option B (inside worker)** | Requires adapter support (batch dequeue or custom worker loop); not in scope for embed-only. |
| **Config** | Add coalescing section (or under queue_manager) with enabled, window_sec, max_texts, optional max_wait_sec. |
| **Parallel processes** | Queue distribution by existing `queue_manager.max_concurrent_jobs`: batch jobs are processed by up to P worker processes; design must preserve this. |
| **Batch homogeneity** | Only coalesce requests with same model, dimension, error_policy, device. |
| **Result shape** | Current `results`/`embeddings` per text allow simple slicing; no change inside EmbedCommand.execute() for coalescing. |
| **Compatibility** | Clients unchanged; API remains one request → one job_id → poll → same response shape (per-request slice). |

The proposal is consistent with the current codebase. Recommended direction: implement **Option A** (coalescer in front of the queue, logical job_ids, slice-based status) and add the suggested config and homogeneity rules; keep Option B for future adapter-level work if needed.
