# Proposal: Request coalescing / dynamic batching on the embedding server

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  
**Date:** 2026-02  
**Audience:** Server (embed) developers

---

## Summary

Add a **request coalescing** (dynamic batching) layer: collect multiple incoming embed requests over a short time window, merge their texts into a single batch, run one `embed` call, then split the result and respond to each original request. This improves throughput and GPU utilization without increasing the number of model copies in memory.

## Motivation

- **Current:** Each embed job is processed independently; with `max_concurrent_jobs=1`, jobs run one after another. Many small requests lead to long queue wait.
- **Constraint:** GPU memory is limited; increasing `max_concurrent_jobs` would roughly double model memory per extra worker.
- **Goal:** One model instance, one forward pass to serve multiple logical requests by batching them, then splitting the output.

## Proposed behaviour

1. **Input:** Embed requests arrive; optionally a short time window (e.g. 20–50 ms) is used to merge requests that arrive close together; batch size is capped (e.g. 32 or 64 texts).
2. **Flush policy (no delay):** One request → submit one job (batch of 1) immediately. Two requests at once → submit one batch of 2. N requests within the window → submit one batch of N. Goal is speed; the only constraint is not exceeding the allowed batch size.
3. **Batch size:** When flushing, take from the buffer the **maximum possible number of texts** (whole requests only, in order) up to the batch size limit; do not split a request across batches.
4. **Coalescing:** Collect requests, merge `texts`, keep mapping `(request_id, start_index, count)`.
5. **Single embed call:** One `embed(texts=merged_texts)` per batch; one job, one forward pass.
6. **Split:** Slice returned `results`/`embeddings` by the mapping; each request receives its slice.
7. **Responses:** Each client gets its response when the batch completes; API unchanged (request/response per call).

## Configuration (suggested)

- `coalescing_enabled`: bool (default `false`).
- `coalescing_window_sec`: float (e.g. 0.02–0.05).
- `coalescing_max_texts`: int (e.g. 32, 64).
- Optional: `coalescing_max_wait_sec` per request.

## Error handling

- **fail_fast:** Whole batch fails; all coalesced requests get the same error.
- **continue:** Per-item errors in result; map each item back to the correct request.

## Compatibility

- Clients do not change: one request per call; only server internals change when coalescing is enabled.
- Default: coalescing off (opt-in via config).

## References

- [COALESCING_ANALYSIS.md](COALESCING_ANALYSIS.md) — code analysis and conclusions.
- [coalescing_plan/](coalescing_plan/00_overview.md) — step-by-step implementation plan.
