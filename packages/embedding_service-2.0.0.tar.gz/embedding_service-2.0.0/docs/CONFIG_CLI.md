# Single config generator, validator, and CLI

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

The project has **one** config generator, **one** config validator, and **one** CLI that uses both.

## Modules

- **Validator:** `embed.config.config_validator` — `validate_config(data) -> List[str]`  
  - Required sections: `server`, `security`, `embedding`.  
  - Unknown top-level or section keys → error.  
  - Rules from [CONFIG_DEPENDENCIES.md](CONFIG_DEPENDENCIES.md): security mode, coalescing ⇒ queue_manager, embedding timing.

- **Generator:** `embed.config.config_generator` — `get_default_config()`, `generate_config(overrides=None)`.  
  - Builds config from defaults, merges overrides, **validates** before return. Raises `ValueError` on validation errors.

- **CLI:** `embed.cli.config_cli` (entry point: `embed-config`).

## CLI usage

```bash
# Generate config (validated)
embed-config generate -o path/to/config.json

# Override any setting (repeatable)
embed-config generate -o config.json --set server.port=9000 --set security.mode=http --set embedding.model_name=all-MiniLM-L6-v2

# Validate existing file (fails on unknown keys or missing required)
embed-config validate -c path/to/config.json
```

Values for `--set`: string, number, `true`/`false`, or list as `[a,b,c]`.

## Python usage

```python
from embed.config import validate_config, generate_config

# Validate
errors = validate_config(config_dict)
if errors:
    print(errors)
else:
    print("OK")

# Generate (validated)
config = generate_config({"server": {"port": 9000}})
```

No other config generators or validators exist in the project; all validation and generation go through these modules and the CLI.
