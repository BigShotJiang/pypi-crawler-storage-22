# Configuration dependency graph and validator behaviour

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  
**Date:** 2026-02

This document defines dependencies between configuration sections and fields, and how the validator must react: the same setting can be **optional**, **required**, or **invalid** depending on the current combination of other settings.

---

## 1. Dependency graph (overview)

```
                    ┌─────────────────┐
                    │     server      │  (always required)
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │    security     │  (always required)
                    │  mode → certs  │  mode determines cert/key/ca requirements
                    └────────┬────────┘
                             │
         ┌───────────────────┼───────────────────┐
         │                   │                   │
┌────────▼────────┐  ┌───────▼───────┐  ┌───────▼───────┐
│   embedding      │  │ queue_manager │  │  coalescing   │
│ (always present) │  │  (optional)   │  │  (optional)   │
└────────┬─────────┘  └───────┬───────┘  └───────┬───────┘
         │                    │                  │
         │ timing_registration│ enabled           │ enabled
         │     → timing_file  │                  │
         │     → max_bytes    │     ◄────────────┘
         │                    │     coalescing.enabled
         │                    │     REQUIRES queue_manager.enabled
         └────────────────────┴─────────────────────────────
```

**Key dependency:** `coalescing.enabled = true` **requires** `queue_manager.enabled = true`. Otherwise the configuration is invalid (validator must report an error).

---

## 2. Sections and their contexts

### 2.1 Top-level sections

| Section           | When required | When optional | Notes |
|-------------------|---------------|---------------|--------|
| `server`          | Always        | —             | Required by ConfigModel. |
| `security`        | Always        | —             | Required by ConfigModel. |
| `embedding`       | Always        | —             | Required; has defaults. |
| `protocols`       | Always (list) | —             | Can be empty list. |
| `queue_manager`   | —             | Always        | If missing → use defaults (e.g. enabled=True). |
| `coalescing`      | —             | Always        | If missing → coalescing off (defaults). |
| `commands_directory` | —         | Always        | Has default. |
| `log_level`       | —             | Always        | Has default. |

---

### 2.2 Security section — dependency on `security.mode`

| Field        | mode = "http"     | mode = "https"      | mode = "mtls"        |
|-------------|-------------------|---------------------|----------------------|
| `mode`      | **required**      | **required**        | **required**         |
| `cert_file` | optional          | **required** (TLS)  | **required**         |
| `key_file`  | optional          | **required** (TLS)  | **required**         |
| `ca_file`   | optional          | optional            | **required** (client verification) |
| `verify_ssl`| optional          | optional            | optional             |
| `token_file`| optional          | optional            | optional             |
| `roles_file`| optional          | optional            | optional             |

**Validator reaction:**
- If `security` section is missing → error (section required).
- If `security.mode` is missing or not one of `"http"`, `"https"`, `"mtls"` → error.
- If `mode == "https"` and (`cert_file` or `key_file`) is missing or empty → error.
- If `mode == "mtls"` and (`cert_file` or `key_file` or `ca_file`) is missing or empty → error (adjust per actual mtls requirements).
- Otherwise → valid.

---

### 2.3 Embedding section — dependency on `timing_registration`

Operation limits (`max_batch_size`, `max_text_length`, `max_texts_per_batch`) are optional; see [CONFIG_OPERATION_LIMITS.md](CONFIG_OPERATION_LIMITS.md).

| Field                  | timing_registration = false | timing_registration = true |
|------------------------|------------------------------|-----------------------------|
| `model_name`           | **required** (or default)    | **required** (or default)  |
| `timing_registration`  | **required** (bool)          | **required** (bool)        |
| `timing_file`          | optional (ignored)           | optional (default path used if null) |
| `timing_file_max_bytes`| optional (ignored)           | optional; if set must be int > 0     |

**Validator reaction:**
- If `embedding` section is missing → error.
- If `embedding.timing_registration` is `true` and `timing_file` is present and not null: must be non-empty string.
- If `embedding.timing_registration` is `true` and `timing_file_max_bytes` is present and not null: must be positive integer.
- Otherwise → valid.

---

### 2.4 Queue manager section

| Field                           | Section absent | Section present, enabled = false | Section present, enabled = true |
|---------------------------------|----------------|----------------------------------|----------------------------------|
| `queue_manager` (section)       | optional       | optional                         | optional                         |
| `queue_manager.enabled`         | —              | **required** (bool)             | **required** (bool)             |
| `queue_manager.max_concurrent_jobs` | —          | optional (validated if present)  | **required** (or default); must be int > 0 |
| `queue_manager.in_memory`       | —              | optional                         | optional                         |
| `queue_manager.completed_job_retention_seconds` | — | optional    | optional                         |

**Validator reaction:**
- If `queue_manager` is missing → no error (section optional).
- If `queue_manager` present: `enabled` must be bool; `max_concurrent_jobs` if present must be int > 0; same for other fields per schema.

---

### 2.5 Coalescing section — dependency on `queue_manager.enabled`

| Field                     | coalescing section absent | coalescing.enabled = false | coalescing.enabled = true |
|---------------------------|---------------------------|----------------------------|----------------------------|
| `coalescing` (section)    | optional                  | optional                   | optional                   |
| `coalescing.enabled`      | —                         | **required** (bool)        | **required** (bool)       |
| `coalescing_window_sec`   | —                         | optional (validated if present) | **required** (or default); must be > 0 |
| `coalescing_max_texts`    | —                         | optional (validated if present) | **required** (or default); must be int > 0 |
| `coalescing_max_wait_sec` | —                         | optional                   | optional; if set must be >= 0 |

**Cross-condition:** When `coalescing.enabled == true`:
- **Requirement:** `queue_manager` must be present and `queue_manager.enabled` must be `true`.
- **Validator reaction:** If `coalescing.enabled` is `true` and (`queue_manager` is missing or `queue_manager.enabled` is not `true`) → **error**: e.g. `"coalescing requires queue_manager.enabled to be true"`.

So:
- **coalescing** section: optional at top level.
- **coalescing** fields: when section is present, validate types and bounds; when `coalescing.enabled` is true, additionally require `queue_manager.enabled` true and treat `coalescing_window_sec` / `coalescing_max_texts` as required (or defaulted).

---

## 3. Validator reaction summary

| Condition | Validator action |
|-----------|------------------|
| Required section missing | **Error** (e.g. `server`, `security`, `embedding`). |
| Optional section missing | **OK** (e.g. `queue_manager`, `coalescing`). |
| Optional section present, field invalid type/bound | **Error** for that field. |
| `coalescing.enabled == true` and `queue_manager.enabled != true` | **Error**: coalescing requires queue enabled. |
| `security.mode == "https"` and (cert_file or key_file) missing | **Error**. |
| `security.mode == "mtls"` and required cert/ca missing | **Error**. |
| `embedding.timing_registration == true` and `timing_file` set to empty string | **Error**. |
| `embedding.timing_registration == true` and `timing_file_max_bytes` set to non-positive | **Error**. |

---

## 4. Validation order (recommended)

To apply dependency-based rules, the validator should:

1. **Phase 1 — Presence and types**
   - Check required top-level sections: `server`, `security`, `embedding`.
   - Validate each present section’s field types and bounds (including optional sections when present).

2. **Phase 2 — Security mode**
   - From `security.mode`, require cert/key/ca as per table in §2.2.

3. **Phase 3 — Embedding timing**
   - If `embedding.timing_registration` is true, validate `timing_file` and `timing_file_max_bytes` when present.

4. **Phase 4 — Cross-section: coalescing vs queue**
   - If `coalescing` is present and `coalescing.enabled` is true:
     - Require `queue_manager` present and `queue_manager.enabled` true; otherwise report error.

---

## 5. Where to implement

- **Pydantic (ConfigModel):** Model-level validators can enforce:
  - `coalescing_window_sec` / `coalescing_max_texts` > 0; `coalescing_max_wait_sec` >= 0 when set.
  - Cross-field: if `coalescing.enabled` then `queue_manager.enabled` must be true (root validator or validator on ConfigModel that has access to both sections).
- **Script validators** (`scripts/validate_all_configs.py`, `scripts/test_config_validation.py`, `tests/test_config_validation.py`): Implement the same rules in Phase 1–4 so that JSON configs are validated consistently even without loading via ConfigModel (e.g. adapter configs that may have a different schema but same embed-related sections).

---

## 6. References

- [COALESCING_ANALYSIS.md](COALESCING_ANALYSIS.md) — §4.4 Configuration, §4.5 Batch homogeneity.
- [coalescing_plan/09_embed_command_routing.md](coalescing_plan/09_embed_command_routing.md) — edge case: coalescing enabled but queue disabled is invalid.
- `embed/config/config_manager.py` — ConfigModel, SecurityConfig, EmbeddingConfig, QueueManagerConfig.

---

## 7. Required code changes in validators

When implementing or updating validators, apply the following changes so that behaviour matches this document. Order of execution in code should follow §4 (Phase 1 → Phase 4).

### 7.1 `scripts/validate_all_configs.py` — function `validate_json_structure()`

| # | Change | Detail |
|---|--------|--------|
| 1 | Required sections | Add `"security"` to `required_sections` (so `required_sections = ["server", "security", "embedding"]`). If this script is also used for configs that do not have a `security` block (e.g. adapter-only), make `security` optional and run Phase 2 only when `"security" in config_data`. |
| 2 | Phase 2 — Security mode | After validating required sections, if `security` is present: require `security.mode` in `("http", "https", "mtls")`. If `mode == "https"`: require `cert_file` and `key_file` to be non-empty strings. If `mode == "mtls"`: require `cert_file`, `key_file`, and `ca_file` to be non-empty strings. Append one error per missing/invalid field. |
| 3 | Coalescing section | When `"coalescing" in config_data`: require `enabled` to be bool; `coalescing_window_sec` to be int or float and > 0; `coalescing_max_texts` to be int and > 0; `coalescing_max_wait_sec` if present to be int or float and >= 0. Append errors for type/bound violations. |
| 4 | Phase 4 — Cross-check | When `"coalescing" in config_data` and `config_data["coalescing"].get("enabled") is True`: require `"queue_manager" in config_data` and `config_data["queue_manager"].get("enabled") is True`. Otherwise append error: `"coalescing requires queue_manager.enabled to be true"`. |
| 5 | Embedding timing | Already implemented (timing_registration, timing_file, timing_file_max_bytes). Ensure that when `timing_registration` is true, empty `timing_file` string is rejected. |

### 7.2 `scripts/test_config_validation.py` — function `validate_config_structure()`

| # | Change | Detail |
|---|--------|--------|
| 1 | Required sections | Add `"security"` to `required_sections` unless this script targets adapter configs only; then validate security only when present. |
| 2 | Phase 2 — Security mode | Same as in §7.1 item 2: when `security` present, validate `mode` and cert/key/ca by mode. |
| 3 | Embedding timing | Add the same embedding timing rules as in `validate_all_configs.py`: when `timing_registration` is true and `timing_file` or `timing_file_max_bytes` present, validate non-empty string and positive int respectively. |
| 4 | Coalescing section | Same as §7.1 item 3: when `coalescing` present, validate field types and bounds. |
| 5 | Phase 4 — Cross-check | Same as §7.1 item 4: coalescing.enabled true ⇒ queue_manager.enabled true. |

### 7.3 `tests/test_config_validation.py` — method `validate_json_structure()`

| # | Change | Detail |
|---|--------|--------|
| 1 | Required sections | Add `"security"` to `required_sections` (or validate security only when present, depending on which configs the tests load). |
| 2 | Phase 2 — Security mode | When `security` in config_data: validate mode and cert/key/ca as in §7.1. |
| 3 | Embedding timing | Add timing_registration / timing_file / timing_file_max_bytes validation when embedding section present (align with validate_all_configs). |
| 4 | Coalescing section | When `coalescing` in config_data: validate enabled, coalescing_window_sec, coalescing_max_texts, coalescing_max_wait_sec. |
| 5 | Phase 4 — Cross-check | When coalescing.enabled is true, require queue_manager.enabled true; else append error. |
| 6 | New test | Add test (e.g. `test_coalescing_requires_queue_enabled`): config with `coalescing.enabled: true` and `queue_manager.enabled: false` (or `queue_manager` missing) must produce at least one validation error containing "queue_manager" or "coalescing". |
| 7 | New test | Add test (e.g. `test_coalescing_section_valid`): config with valid optional `coalescing` section (enabled false or true with queue enabled) passes validation. |
| 8 | New test | Add test (e.g. `test_coalescing_invalid_values`): config with `coalescing_window_sec: -0.1` or `coalescing_max_texts: 0` produces validation errors. |

### 7.4 Pydantic `ConfigModel` (`embed/config/config_manager.py`)

| # | Change | Detail |
|---|--------|--------|
| 1 | CoalescingConfig validators | Add `@model_validator` or `@field_validator` so that `coalescing_window_sec` and `coalescing_max_texts` are > 0 when set; `coalescing_max_wait_sec` >= 0 when set. |
| 2 | Root validator (cross-check) | Add a `@model_validator(mode="after")` on `ConfigModel`: if `self.coalescing` is not None and `self.coalescing.enabled` is True, then `self.queue_manager` must be not None and `self.queue_manager.enabled` must be True; otherwise raise `ValueError("coalescing requires queue_manager.enabled to be true")`. |

### 7.5 Optional: single shared validation function

To avoid duplication, consider implementing one function (e.g. in `embed/config/config_validator.py` or in a shared test helper) that runs Phase 1–4 and returns `List[str]` of errors, and call it from:

- `scripts/validate_all_configs.validate_json_structure()`
- `scripts/test_config_validation.validate_config_structure()`
- `tests.test_config_validation.TestConfigValidation.validate_json_structure()`

Then all three stay in sync with CONFIG_DEPENDENCIES. This is optional and can be a follow-up.
