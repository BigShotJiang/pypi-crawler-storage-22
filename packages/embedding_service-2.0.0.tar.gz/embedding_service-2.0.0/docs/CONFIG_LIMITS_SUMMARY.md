# Сводка: Лимиты операций в конфиге

## ✅ Выполнено

Все максимальные лимиты операций теперь настраиваются через конфигурационный файл.

## Лимиты в конфиге

### 1. Queue Manager

```json
{
  "queue_manager": {
    "max_concurrent_jobs": 1  // Максимум параллельных задач
  }
}
```

### 2. Embedding Service

```json
{
  "embedding": {
    "max_batch_size": 512,      // Максимум текстов в батче
    "max_text_length": 1000000  // Максимальная длина текста
  }
}
```

## Где используются

- `max_concurrent_jobs` - контролирует параллелизм обработки задач
- `max_batch_size` - ограничивает размер батча в одном запросе
- `max_text_length` - ограничивает длину одного текста

## Значения по умолчанию

Если параметры не указаны в конфиге:
- `max_concurrent_jobs`: 1
- `max_batch_size`: 512
- `max_text_length`: 1,000,000

## Изменения в коде

1. **embed/services/embedding_initializer.py** - читает лимиты из конфига
2. **embed/services/embedding_service.py** - использует лимиты из конфига
3. **embed.cli.config_cli generate -o config/local_http.json** - генерирует конфиг с лимитами

## Документация

- [Подробная документация по лимитам](./CONFIG_OPERATION_LIMITS.md)

