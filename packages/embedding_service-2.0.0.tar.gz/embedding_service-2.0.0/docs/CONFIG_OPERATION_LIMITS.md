# Конфигурация лимитов операций

Все максимальные лимиты операций вынесены в конфигурационный файл для гибкой настройки.

## Лимиты в конфиге

### 1. Queue Manager (Очередь задач)

```json
{
  "queue_manager": {
    "enabled": true,
    "in_memory": true,
    "max_concurrent_jobs": 1,  // ← Максимум параллельных задач
    "completed_job_retention_seconds": 3600
  }
}
```

**Параметры:**
- `max_concurrent_jobs` (int): Максимальное количество задач, обрабатываемых параллельно
  - **Для GPU операций:** рекомендуется `1` (последовательная обработка)
  - **С Model Server:** можно `10` (Model Server сериализует GPU запросы)
  - **Только CPU:** можно больше (зависит от CPU)

### 2. Embedding Service (Лимиты обработки)

```json
{
  "embedding": {
    "model_name": "all-MiniLM-L6-v2",
    "device": "auto",
    "max_batch_size": 512,        // ← Максимум текстов в одном запросе (request-level)
    "max_text_length": 1000000,   // ← Максимальная длина одного текста (символов)
    "max_texts_per_batch": 0       // ← Максимум текстов за один encode(); 0 = только по GPU
  }
}
```

**Параметры:**
- `max_batch_size` (int): Максимальное количество текстов в одном запросе (лимит на входе; запрос с большим числом текстов отклоняется)
  - По умолчанию: `512`
  - Рекомендуется: `32-512` (зависит от GPU памяти)
  - Не влияет на размещение модели (CPU/GPU)

- `max_text_length` (int): Максимальная длина одного текста в символах
  - По умолчанию: `1,000,000`
  - Ограничивает размер одного текста для предотвращения переполнения памяти

- `max_texts_per_batch` (int): Максимальное количество текстов, передаваемых в один вызов `encode()` внутри воркера (батчинг при кодировании)
  - По умолчанию: `0`
  - `0`: лимит только по свободной GPU-памяти (без ограничения из конфига)
  - `> 0`: используется минимум из этого значения и лимита по GPU-памяти
  - Не влияет на размещение модели (CPU/GPU) и не ослабляет лимит запроса `max_batch_size`

## Значения по умолчанию

Если параметры не указаны в конфиге, используются значения по умолчанию:

```python
MAX_BATCH_SIZE = 512
MAX_TEXT_LENGTH = 1_000_000
max_texts_per_batch = 0   # encode batch; 0 = only GPU memory
max_concurrent_jobs = 1
```

## Рекомендации по настройке

### Для GPU операций (без Model Server)

```json
{
  "queue_manager": {
    "max_concurrent_jobs": 1  // Обязательно 1 для безопасности GPU
  },
  "embedding": {
    "max_batch_size": 32,     // Меньше для экономии GPU памяти
    "max_text_length": 1000000,
    "max_texts_per_batch": 0  // 0 = только по GPU
  }
}
```

### Для GPU операций (с Model Server)

```json
{
  "queue_manager": {
    "max_concurrent_jobs": 10  // Можно больше, Model Server сериализует
  },
  "embedding": {
    "max_batch_size": 512,    // Можно больше
    "max_text_length": 1000000,
    "max_texts_per_batch": 0
  }
}
```

### Для CPU операций

```json
{
  "queue_manager": {
    "max_concurrent_jobs": 4   // Можно больше для CPU
  },
  "embedding": {
    "max_batch_size": 128,     // Меньше для CPU (медленнее)
    "max_text_length": 1000000,
    "max_texts_per_batch": 0
  }
}
```

## Проверка текущих лимитов

Лимиты логируются при инициализации сервиса:

```
Loaded settings - model: all-MiniLM-L6-v2, device: cuda:0, max_batch_size: 512, max_text_length: 1000000, max_texts_per_batch: 0
Queue manager settings - max_concurrent_jobs: 1
```

## Изменение лимитов

### 1. Изменить в конфиге

Отредактировать `config/local_http.json` (или другой конфиг):

```json
{
  "queue_manager": {
    "max_concurrent_jobs": 2  // Изменить значение
  },
  "embedding": {
    "max_batch_size": 256,    // Изменить значение
    "max_text_length": 500000,
    "max_texts_per_batch": 0  // при необходимости задать лимит на encode
  }
}
```

### 2. Перезапустить сервис

После изменения конфига необходимо перезапустить сервис:

```bash
# Остановить сервис
# Затем запустить снова
python -m embed.main --config config/local_http.json
```

## Влияние лимитов на производительность

### max_concurrent_jobs

- **Меньше значение** → Безопаснее для GPU, но медленнее
- **Больше значение** → Быстрее, но риск перегрузки GPU

### max_batch_size

- **Меньше значение** → Меньше GPU памяти, но больше запросов
- **Больше значение** → Эффективнее, но требует больше памяти

### max_text_length

- **Меньше значение** → Защита от очень больших текстов
- **Больше значение** → Разрешает большие тексты, но риск OOM

## Примеры конфигураций

### Минимальная (безопасная для GPU)

```json
{
  "queue_manager": {
    "max_concurrent_jobs": 1
  },
  "embedding": {
    "max_batch_size": 16,
    "max_text_length": 100000,
    "max_texts_per_batch": 0
  }
}
```

### Оптимальная (с Model Server)

```json
{
  "queue_manager": {
    "max_concurrent_jobs": 10
  },
  "embedding": {
    "max_batch_size": 512,
    "max_text_length": 1000000,
    "max_texts_per_batch": 0
  }
}
```

### Высокая нагрузка (CPU)

```json
{
  "queue_manager": {
    "max_concurrent_jobs": 8
  },
  "embedding": {
    "max_batch_size": 64,
    "max_text_length": 1000000,
    "max_texts_per_batch": 0
  }
}
```

## Связанная документация

- [Объяснение проблемы перегрузки GPU](./QUEUE_GPU_OVERLOAD_EXPLANATION.md)
- [Руководство по нагрузочному тестированию](./LOAD_TESTING_GUIDE.md)

