# Настройка очереди для Docker контейнера

## ✅ Выполнено

Настроены Docker конфиги для последовательной обработки заданий (по одному).

## Изменения в Docker конфигах

### 1. `config/container_mtls.json`

**Изменено:**
```json
{
  "queue_manager": {
    "enabled": true,
    "in_memory": true,
    "max_concurrent_jobs": 1,  // ← Изменено с 10 на 1
    "completed_job_retention_seconds": 3600
  },
  "embedding": {
    "model_name": "sentence-transformers/all-MiniLM-L6-v2",
    "device": "auto",
    "max_batch_size": 512,      // ← Добавлено
    "max_text_length": 1000000  // ← Добавлено
  }
}
```

### 2. `config/local_http.json` (для локального HTTP)

**Добавлено:**
```json
{
  "queue_manager": {
    "enabled": true,
    "in_memory": true,
    "max_concurrent_jobs": 1,  // ← Добавлено (по умолчанию 1)
    "completed_job_retention_seconds": 3600
  },
  "embedding": {
    "model_name": "sentence-transformers/all-MiniLM-L6-v2",
    "device": "auto",
    "max_batch_size": 512,      // ← Добавлено
    "max_text_length": 1000000  // ← Добавлено
  }
}
```

## Почему max_concurrent_jobs: 1?

### Проблема
При `max_concurrent_jobs: 10` до 10 процессов могут одновременно обращаться к GPU, что вызывает:
- Перегрузку GPU
- Ошибки CUDA: "unspecified launch failure"
- Исчерпание GPU памяти
- Долгие таймауты (300+ секунд)

### Решение
`max_concurrent_jobs: 1` гарантирует:
- ✅ Последовательную обработку заданий
- ✅ Один процесс использует GPU в каждый момент времени
- ✅ Нет перегрузки GPU
- ✅ Быстрая обработка без ошибок CUDA

## Использование в Docker

### 1. Использование готового конфига

Конфиг монтируется в контейнер:
```yaml
volumes:
  - ./data/config:/etc/embedding-service
```

Убедитесь, что в `/etc/embedding-service/config.json` установлено:
```json
{
  "queue_manager": {
    "max_concurrent_jobs": 1
  }
}
```

### 2. Проверка конфига перед запуском

```bash
# Проверить Docker конфиги
python scripts/verify_configs_work.py --file config/local_http.json
python scripts/verify_configs_work.py --file config/container_mtls.json
```

### 3. Запуск контейнера

```bash
cd docker
docker-compose up -d
```

### 4. Проверка работы

После запуска проверьте логи:
```bash
docker-compose logs -f embedding-service | grep -i "max_concurrent_jobs\|queue"
```

Должно быть:
```
Queue manager settings - max_concurrent_jobs: 1
```

## Альтернатива: Model Server

Если нужна параллельная обработка других операций, можно использовать Model Server:

1. **Model Server сериализует GPU запросы** через Unix socket
2. **Можно оставить `max_concurrent_jobs: 10`** для других операций
3. **GPU запросы автоматически обрабатываются последовательно**

Подробнее: [Model Server Architecture](../embed/services/README_MODEL_SERVER.md)

## Проверка настроек

### В контейнере

```bash
# Войти в контейнер
docker exec -it embedding-service bash

# Проверить конфиг
cat /etc/embedding-service/config.json | grep -A 5 queue_manager

# Должно быть:
# "max_concurrent_jobs": 1
```

### Через API

```bash
# Проверить health endpoint
curl https://localhost:8001/health

# Проверить логи
docker-compose logs embedding-service | grep "max_concurrent_jobs"
```

## Важные замечания

1. **Перезапуск контейнера** требуется после изменения конфига
2. **Проверьте монтирование** конфига в docker-compose.yml
3. **Логи покажут** текущее значение max_concurrent_jobs при старте

## Связанная документация

- [Объяснение проблемы перегрузки GPU](./QUEUE_GPU_OVERLOAD_EXPLANATION.md)
- [Конфигурация лимитов операций](./CONFIG_OPERATION_LIMITS.md)

