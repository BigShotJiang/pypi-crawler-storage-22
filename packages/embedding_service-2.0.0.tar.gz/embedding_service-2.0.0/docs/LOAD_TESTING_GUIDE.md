# Руководство по нагрузочному тестированию

## Быстрый старт

### 1. Генерация конфига для локального тестирования

```bash
python -m embed.cli.config_cli generate -o config/local_http.json
```

Или используйте `config/local_http.json` с:
- Свободным портом (автоматически найденным)
- `max_concurrent_jobs: 1` (безопасно для GPU)
- Настройками для локального тестирования

### 2. Запуск сервера

```bash
python -m embed.main --config config/local_http.json
```

Сервер будет доступен на `http://127.0.0.1:<port>` (порт будет показан при генерации конфига).

### 3. Запуск тестов

```bash
# Все тесты
python tests/test_load_stress.py --url http://127.0.0.1:8000

# Конкретный тест
python tests/test_load_stress.py --test sequential --num-requests 20
python tests/test_load_stress.py --test load --num-requests 50 --concurrent 5
python tests/test_load_stress.py --test device
python tests/test_load_stress.py --test batch
python tests/test_load_stress.py --test fallback
```

## Доступные тесты

### 1. Sequential Processing (Последовательная обработка)

Проверяет, что запросы обрабатываются последовательно при `max_concurrent_jobs: 1`.

```bash
python tests/test_load_stress.py --test sequential --num-requests 10
```

**Что проверяет:**
- ✅ Запросы обрабатываются один за другим
- ✅ Нет параллельного доступа к GPU
- ✅ Отсутствие ошибок CUDA

### 2. Device Auto-Detection (Автоопределение устройства)

Проверяет правильное определение устройства для каждого запроса.

```bash
python tests/test_load_stress.py --test device
```

**Что проверяет:**
- ✅ `device="auto"` правильно определяет GPU/CPU
- ✅ `device="cpu"` принудительно использует CPU
- ✅ `device="cuda"` принудительно использует GPU (если доступен)
- ✅ Информация об устройстве возвращается в результате

### 3. High Load (Высокая нагрузка)

Тестирует систему под высокой нагрузкой с множеством запросов.

```bash
python tests/test_load_stress.py --test load --num-requests 50 --concurrent 5
```

**Что проверяет:**
- ✅ Система обрабатывает много запросов
- ✅ Запросы корректно ставятся в очередь
- ✅ Последовательная обработка (даже при concurrent отправке)
- ✅ Производительность и стабильность

### 4. Batch Processing (Пакетная обработка)

Тестирует обработку батчей разного размера.

```bash
python tests/test_load_stress.py --test batch
```

**Что проверяет:**
- ✅ Обработка батчей разного размера (1, 5, 10, 20 текстов)
- ✅ Производительность (время на текст)
- ✅ Корректность результатов

### 5. GPU Fallback (Откат на CPU)

Проверяет автоматический откат на CPU при проблемах с GPU.

```bash
python tests/test_load_stress.py --test fallback
```

**Что проверяет:**
- ✅ При ошибке GPU автоматически переключается на CPU
- ✅ Запрос успешно обрабатывается на CPU
- ✅ Информация об устройстве корректна

## Параметры тестов

### Общие параметры

- `--url`: URL сервера (по умолчанию: `http://127.0.0.1:8000`)
- `--test`: Тест для запуска (`all`, `sequential`, `device`, `load`, `batch`, `fallback`)
- `--num-requests`: Количество запросов для load/sequential тестов
- `--concurrent`: Количество параллельных запросов для load теста

### Примеры

```bash
# Тест последовательной обработки с 20 запросами
python tests/test_load_stress.py --test sequential --num-requests 20

# Тест высокой нагрузки: 100 запросов, 10 параллельных
python tests/test_load_stress.py --test load --num-requests 100 --concurrent 10

# Все тесты на другом порту
python tests/test_load_stress.py --url http://127.0.0.1:37311 --test all
```

## Интерпретация результатов

### Успешный тест

```
TEST 1: Sequential Processing (max_concurrent_jobs=1)
============================================================
Sending 10 requests sequentially...
  Request 1/10: ✅ 2.34s
  Request 2/10: ✅ 2.12s
  ...

Results:
  Total time: 25.67s
  Success rate: 100.0%
  Avg time per request: 2.57s
  Device usage: {'cuda:0': 10}
```

**Хорошие показатели:**
- ✅ Success rate: 100%
- ✅ Стабильное время обработки
- ✅ Правильное использование устройства

### Проблемы

**Низкий success rate:**
- Проверить, что сервер запущен
- Проверить логи сервера на ошибки
- Проверить доступность GPU

**Ошибки CUDA:**
- Убедиться, что `max_concurrent_jobs: 1` в конфиге
- Проверить доступную GPU память
- Рассмотреть использование Model Server

**Медленная обработка:**
- Нормально для GPU операций (2-5 секунд на запрос)
- Если очень медленно, проверить использование CPU вместо GPU
- Проверить размер батчей

## Мониторинг во время тестов

### Логи сервера

Следить за логами сервера во время тестов:

```bash
# В отдельном терминале
tail -f logs/mcp_proxy_adapter.log
```

**Что искать:**
- `Device selection: cuda:0` или `Device selection: cpu`
- `CUDA error detected` - проблемы с GPU
- `CPU fallback successful` - успешный откат на CPU
- `Encoding completed on cuda:0` - успешная обработка на GPU

### GPU мониторинг

```bash
# В отдельном терминале
watch -n 1 nvidia-smi
```

**Что проверять:**
- Использование памяти GPU (не должно превышать доступную)
- Загрузка GPU (должна быть последовательной, не параллельной)
- Температура (не должна быть критической)

## Рекомендации по конфигурации

### Для тестирования

```json
{
  "queue_manager": {
    "enabled": true,
    "in_memory": true,
    "max_concurrent_jobs": 1,  // ← Безопасно для GPU
    "completed_job_retention_seconds": 3600
  },
  "embedding": {
    "model_name": "all-MiniLM-L6-v2",
    "device": "auto"  // ← Автоматическое определение
  }
}
```

### Для продакшена

**Вариант 1: Model Server (рекомендуется)**
```json
{
  "queue_manager": {
    "enabled": true,
    "in_memory": true,
    "max_concurrent_jobs": 10,  // ← Можно больше, Model Server сериализует
    "completed_job_retention_seconds": 3600
  }
}
```

**Вариант 2: Без Model Server**
```json
{
  "queue_manager": {
    "enabled": true,
    "in_memory": true,
    "max_concurrent_jobs": 1,  // ← Обязательно 1 для GPU
    "completed_job_retention_seconds": 3600
  }
}
```

## Устранение проблем

### Проблема: Тесты не запускаются

**Решение:**
1. Проверить, что сервер запущен: `curl http://127.0.0.1:8000/health`
2. Проверить URL в параметрах теста
3. Проверить, что порт свободен

### Проблема: Ошибки CUDA во время тестов

**Решение:**
1. Убедиться, что `max_concurrent_jobs: 1` в конфиге
2. Проверить доступную GPU память: `nvidia-smi`
3. Использовать Model Server для сериализации запросов
4. Рассмотреть использование CPU: `"device": "cpu"`

### Проблема: Медленная обработка

**Решение:**
1. Проверить, что используется GPU, а не CPU
2. Проверить размер батчей (больше текстов = эффективнее)
3. Проверить, что модель загружена (не перезагружается каждый раз)
4. Использовать Model Server для избежания перезагрузки модели

### Проблема: Тесты падают с timeout

**Решение:**
1. Увеличить timeout в тестах (по умолчанию 300s)
2. Проверить логи сервера на ошибки
3. Проверить, что GPU доступен и работает
4. Рассмотреть использование CPU для тестов

## Дополнительная информация

- [Объяснение проблемы перегрузки GPU](./QUEUE_GPU_OVERLOAD_EXPLANATION.md)
- [Model Server Architecture](../embed/services/README_MODEL_SERVER.md)

