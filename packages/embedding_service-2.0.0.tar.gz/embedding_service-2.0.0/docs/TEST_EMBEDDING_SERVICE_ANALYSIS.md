# Test run and analysis: scripts/test_embedding_service.py

**Author:** Vasiliy Zdanovskiy  
**email:** vasilyvz@gmail.com  
**Date:** 2026-02-13

## Test run summary

| Check | Result | Notes |
|-------|--------|--------|
| health | OK | ~132–368 ms |
| models | **FAIL** | Internal server error |
| list_commands | OK | ~66 ms |
| timing_stats | OK | ~11 ms (timing enabled) |
| embed_parallel_20 | **FAIL** | 20 jobs submitted; all "Job not found" when polling |
| embed_batch_20 | **FAIL** | Job not found when waiting |

## 1. models — Internal server error

- **Observed:** Client receives `Models list failed: Internal server error`.
- **Code path:** `ModelsCommand.execute()` → `EmbeddingService.get_instance()` → `get_available_models()` → `get_available_models_info()`.
- **Possible causes:**
  - `EmbeddingService.get_instance()` fails (e.g. `_create_async()` raises): config load, model server connection, or init in the process that serves the `models` call.
  - If `models` is ever executed in a worker process (e.g. via queue), the worker may not have `EmbeddingService` initialized, leading to init errors or missing state.
- **Recommendation:** Add logging in `ModelsCommand.execute()` and in `EmbeddingService.get_instance()` / `_create_async()` to log the exact exception; ensure `models` is only invoked in the main process where the embedding service is initialized.

## 2. embed jobs — "Job not found"

- **Observed:** `embed` returns `job_id`; later `queue_get_job_status(job_id)` or `embed_job_status(job_id)` returns "Job not found".
- **Logs:** Server logs show `CommandExecutionJob <job_id>: Starting command execution` and repeated worker startup (Hypercorn, queue commands registration), i.e. each job runs in a **separate worker process**.
- **Mechanism:** `embed_router` submits via `queue_manager.add_job(CommandExecutionJob, job_id, job_params)` and `_start_job_background(queue_manager, job_id)` → `queue_manager.start_job(job_id)`. The adapter runs the job in a worker; the client then polls the **main** process with `queue_get_job_status` / `embed_job_status`.
- **Likely cause:** Job state (and result) lives in the worker or in a store that the main process does not query. The main process’ queue registry may not be updated with results from workers, or job IDs may refer to worker-side jobs that the main process does not know about. So from the client’s point of view the job is "not found" when polling the main process.
- **Recommendation:** Verify in the adapter how worker job results are propagated to the main process and how `queue_get_job_status` / `embed_job_status` resolve `job_id`. Ensure the main process either holds the job metadata and receives results from workers, or that the client polls an endpoint that sees worker-completed jobs.

## 3. CUDA errors in logs

- **Observed:** `CUBLAS_STATUS_ALLOC_FAILED` when calling `cublasCreate(handle)` during encode.
- **Impact:** Embedding requests that use GPU can fail; workers may crash or return errors. This can also affect stability when many parallel jobs run (e.g. 20 parallel embeds).
- **Recommendation:** Reduce concurrent GPU load (e.g. `queue_manager.max_concurrent_jobs`), or run with `device: "cpu"` for stability; ensure GPU memory is not exhausted by multiple worker processes.

## 4. What works

- **health:** Service is up and responsive.
- **list_commands:** Command list is returned.
- **timing_stats:** Returns successfully; timing is enabled and the timing file is configured.
- **embed submit:** Submission of embed jobs returns `job_id` without error; failure is only when polling for status/results.

## 5. Next steps (concise)

1. **models:** Log and fix the exception in `get_instance()` / `get_available_models()` (and ensure `models` runs only where the service is initialized).
2. **embed job status:** Align adapter’s queue design with status polling (main process must know about job IDs and receive worker results, or expose a single place to poll).
3. **CUDA:** Tune concurrency and/or use CPU to avoid CUBLAS allocation failures under load.
