# Полный список всех настроек конфигурации MCP Proxy Adapter

## Основные секции конфигурации

### 1. server
- `host` (string): Хост сервера (по умолчанию: "0.0.0.0")
- `port` (integer): Порт сервера (по умолчанию: 8000)
- `protocol` (string): Протокол ("http", "https", "mtls")
- `debug` (boolean): Режим отладки (по умолчанию: false)
- `log_level` (string): Уровень логирования ("DEBUG", "INFO", "WARNING", "ERROR")

### 2. logging
- `level` (string): Уровень логирования
- `file` (string|null): Файл лога
- `log_dir` (string): Директория логов (по умолчанию: "./logs")
- `log_file` (string): Имя файла лога
- `error_log_file` (string): Имя файла ошибок
- `access_log_file` (string): Имя файла доступа
- `max_file_size` (string): Максимальный размер файла (по умолчанию: "10MB")
- `backup_count` (integer): Количество резервных копий (по умолчанию: 5)
- `format` (string): Формат лога
- `date_format` (string): Формат даты
- `console_output` (boolean): Вывод в консоль (по умолчанию: true)
- `file_output` (boolean): Вывод в файл (по умолчанию: true)

### 3. commands
- `auto_discovery` (boolean): Автообнаружение команд (по умолчанию: true)
- `commands_directory` (string): Директория команд (по умолчанию: "./commands")
- `catalog_directory` (string): Директория каталога (по умолчанию: "./catalog")
- `plugin_servers` (array): Список серверов плагинов
- `auto_install_dependencies` (boolean): Автоустановка зависимостей (по умолчанию: true)
- `enabled_commands` (array): Включенные команды
- `disabled_commands` (array): Отключенные команды
- `custom_commands_path` (string): Путь к пользовательским командам

### 4. transport
- `type` (string): Тип транспорта ("http", "https", "mtls")
- `port` (integer|null): Порт транспорта
- `verify_client` (boolean): Проверка клиента
- `chk_hostname` (boolean): Проверка имени хоста

### 5. proxy_registration
- `enabled` (boolean): Включена ли регистрация в прокси
- `proxy_url` (string): URL прокси
- `server_id` (string): ID сервера
- `server_name` (string): Имя сервера
- `description` (string): Описание сервера
- `version` (string): Версия сервера
- `registration_timeout` (integer): Таймаут регистрации
- `retry_attempts` (integer): Количество попыток повтора
- `retry_delay` (integer): Задержка между попытками
- `auto_register_on_startup` (boolean): Авторегистрация при запуске
- `auto_unregister_on_shutdown` (boolean): Автоотмена регистрации при остановке

### 6. debug
- `enabled` (boolean): Включен ли режим отладки
- `level` (string): Уровень отладки

### 7. security
- `enabled` (boolean): Включена ли безопасность
- `tokens` (object): Токены
  - `admin` (string): Токен администратора
  - `user` (string): Токен пользователя
  - `readonly` (string): Токен только для чтения
- `roles` (object): Роли
  - `admin` (array): Роль администратора
  - `user` (array): Роль пользователя
  - `readonly` (array): Роль только для чтения
- `roles_file` (string|null): Файл ролей

### 8. roles
- `enabled` (boolean): Включены ли роли
- `config_file` (string|null): Файл конфигурации ролей
- `default_policy` (object): Политика по умолчанию
  - `deny_by_default` (boolean): Запрещать по умолчанию
  - `require_role_match` (boolean): Требовать соответствие роли
  - `case_sensitive` (boolean): Учитывать регистр
  - `allow_wildcard` (boolean): Разрешать подстановочные знаки
- `auto_load` (boolean): Автозагрузка
- `validation_enabled` (boolean): Включена ли валидация

## Поддерживаемые протоколы
- HTTP
- HTTPS
- mTLS

## Поддерживаемые методы аутентификации
- none (без аутентификации)
- token (токен)
- certificate (сертификат)
- basic (базовая)
- oauth2 (OAuth2)

## Поддерживаемые методы регистрации в прокси
- none (без регистрации)
- token (токен)
- certificate (сертификат)
- api_key (API ключ)