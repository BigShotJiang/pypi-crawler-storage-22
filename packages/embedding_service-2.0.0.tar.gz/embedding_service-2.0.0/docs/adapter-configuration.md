# Configuration Guide

**Author**: Vasiliy Zdanovskiy  
**Email**: vasilyvz@gmail.com

This document describes the configuration options for MCP Proxy Adapter with unified security framework integration.

## Overview

The MCP Proxy Adapter uses a unified configuration system that integrates with the `mcp_security_framework` for comprehensive security management. All security features are now managed through a single `security` section in the configuration.

## Configuration Structure

### Basic Configuration
```json
{
  "server": {
    "host": "0.0.0.0",
    "port": 8000,
    "debug": false,
    "log_level": "INFO"
  },
  "security": {
    "enabled": true,
    "auth": {
      "enabled": true,
      "methods": ["api_key"],
      "api_keys": {
        "admin": "admin_key_123",
        "user": "user_key_456"
      }
    },
    "ssl": {
      "enabled": false
    },
    "permissions": {
      "enabled": true,
      "roles_file": "roles.json",
      "default_role": "user"
    },
    "rate_limit": {
      "enabled": true,
      "requests_per_minute": 60
    }
  }
}
```

## Security Configuration

### Authentication (`security.auth`)

#### API Key Authentication
```json
{
  "security": {
    "auth": {
      "enabled": true,
      "methods": ["api_key"],
      "api_keys": {
        "admin": "admin_key_123",
        "user": "user_key_456"
      }
    }
  }
}
```

#### JWT Authentication
```json
{
  "security": {
    "auth": {
      "enabled": true,
      "methods": ["jwt"],
      "jwt_secret": "your-secret-key",
      "jwt_algorithm": "HS256"
    }
  }
}
```

#### Certificate Authentication
```json
{
  "security": {
    "auth": {
      "enabled": true,
      "methods": ["certificate"],
      "ca_cert": "certs/ca.crt"
    }
  }
}
```

#### Multiple Authentication Methods
```json
{
  "security": {
    "auth": {
      "enabled": true,
      "methods": ["api_key", "jwt", "certificate"],
      "api_keys": {
        "admin": "admin_key_123"
      },
      "jwt_secret": "your-secret-key",
      "ca_cert": "certs/ca.crt"
    }
  }
}
```

### SSL/TLS Configuration (`security.ssl`)

#### Basic SSL
```json
{
  "security": {
    "ssl": {
      "enabled": true,
      "cert_file": "certs/server.crt",
      "key_file": "certs/server.key",
      "min_tls_version": "TLSv1.2"
    }
  }
}
```

#### mTLS (Mutual TLS)
```json
{
  "security": {
    "ssl": {
      "enabled": true,
      "cert_file": "certs/server.crt",
      "key_file": "certs/server.key",
      "ca_cert": "certs/ca.crt",
      "verify_client": true,
      "client_cert_required": true,
      "min_tls_version": "TLSv1.2"
    }
  }
}
```

### Permissions (`security.permissions`)

#### Basic Role-Based Access Control
```json
{
  "security": {
    "permissions": {
      "enabled": true,
      "roles_file": "roles.json",
      "default_role": "user",
      "deny_by_default": true
    }
  }
}
```

#### Roles File Structure
```json
{
  "roles": {
    "admin": {
      "permissions": ["*"],
      "description": "Full access"
    },
    "user": {
      "permissions": ["read", "write"],
      "description": "Standard user access"
    },
    "guest": {
      "permissions": ["read"],
      "description": "Read-only access"
    }
  }
}
```

### Rate Limiting (`security.rate_limit`)

#### Basic Rate Limiting
```json
{
  "security": {
    "rate_limit": {
      "enabled": true,
      "requests_per_minute": 60,
      "requests_per_hour": 1000,
      "burst_limit": 10
    }
  }
}
```

#### Advanced Rate Limiting
```json
{
  "security": {
    "rate_limit": {
      "enabled": true,
      "requests_per_minute": 60,
      "requests_per_hour": 1000,
      "burst_limit": 10,
      "by_ip": true,
      "by_user": true,
      "exempt_roles": ["admin"]
    }
  }
}
```

## Public Paths

Configure paths that don't require authentication:

```json
{
  "security": {
    "public_paths": [
      "/health",
      "/docs",
      "/redoc",
      "/openapi.json"
    ]
  }
}
```

## Environment Variables

You can override configuration using environment variables:

```bash
# Server configuration
export SERVICE_SERVER_HOST=0.0.0.0
export SERVICE_SERVER_PORT=8000

# Security configuration
export SERVICE_SECURITY_ENABLED=true
export SERVICE_SECURITY_AUTH_ENABLED=true
export SERVICE_SECURITY_AUTH_METHODS=api_key,jwt
export SERVICE_SECURITY_RATE_LIMIT_ENABLED=true
export SERVICE_SECURITY_RATE_LIMIT_REQUESTS_PER_MINUTE=60
```

## Configuration Validation

The configuration is automatically validated using Pydantic schemas from `mcp_security_framework`. Invalid configurations will result in startup errors with detailed error messages.

### Common Validation Errors

1. **Invalid TLS Version**: Must be one of `TLSv1.0`, `TLSv1.1`, `TLSv1.2`, `TLSv1.3`
2. **Missing Certificate Files**: Certificate files must exist when SSL is enabled
3. **Invalid JWT Algorithm**: Must be a supported algorithm (HS256, HS384, HS512, RS256, etc.)
4. **Invalid Rate Limit Values**: Must be positive integers

## Migration from Legacy Configuration

### Old Configuration Structure
```json
{
  "ssl": {
    "api_keys": {
      "admin": "admin_key_123"
    }
  },
  "roles": {
    "enabled": true,
    "config_file": "roles.json"
  },
  "rate_limit": {
    "enabled": true,
    "requests_per_minute": 60
  }
}
```

### New Configuration Structure
```json
{
  "security": {
    "enabled": true,
    "auth": {
      "enabled": true,
      "methods": ["api_key"],
      "api_keys": {
        "admin": "admin_key_123"
      }
    },
    "permissions": {
      "enabled": true,
      "roles_file": "roles.json"
    },
    "rate_limit": {
      "enabled": true,
      "requests_per_minute": 60
    }
  }
}
```

## Configuration Examples

### Development Configuration
```json
{
  "server": {
    "host": "localhost",
    "port": 8000,
    "debug": true
  },
  "security": {
    "enabled": true,
    "auth": {
      "enabled": true,
      "methods": ["api_key"],
      "api_keys": {
        "dev": "dev_key_123"
      }
    },
    "permissions": {
      "enabled": false
    },
    "rate_limit": {
      "enabled": false
    }
  }
}
```

### Production Configuration
```json
{
  "server": {
    "host": "0.0.0.0",
    "port": 8000,
    "debug": false
  },
  "security": {
    "enabled": true,
    "auth": {
      "enabled": true,
      "methods": ["api_key", "jwt"],
      "api_keys": {
        "admin": "admin_key_123",
        "user": "user_key_456"
      },
      "jwt_secret": "your-secret-key",
      "jwt_algorithm": "HS256"
    },
    "ssl": {
      "enabled": true,
      "cert_file": "certs/server.crt",
      "key_file": "certs/server.key",
      "min_tls_version": "TLSv1.2"
    },
    "permissions": {
      "enabled": true,
      "roles_file": "roles.json",
      "default_role": "user",
      "deny_by_default": true
    },
    "rate_limit": {
      "enabled": true,
      "requests_per_minute": 60,
      "requests_per_hour": 1000,
      "burst_limit": 10,
      "by_ip": true,
      "by_user": true
    },
    "public_paths": [
      "/health",
      "/docs"
    ]
  }
}
```

## Troubleshooting

### Common Issues

1. **Configuration Not Loading**: Check file permissions and JSON syntax
2. **SSL Certificate Errors**: Verify certificate file paths and formats
3. **Authentication Failures**: Check API keys and JWT configuration
4. **Rate Limiting Issues**: Verify rate limit configuration values

### Debug Mode

Enable debug mode for detailed configuration information:

```json
{
  "server": {
    "debug": true
  }
}
```

This will log detailed information about configuration loading and validation.
