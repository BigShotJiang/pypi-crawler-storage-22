# Batch worker plan: inventory and algorithm

**Author:** Vasiliy Zdanovskiy  
**email:** vasilyvz@gmail.com  

**Part of:** [Batch worker plan](README.md) (index).  
**This file:** code inventory and detailed algorithm. Implementation steps: [Step 1 Config](01_step_config.md) → [Step 2 Helper](02_step_batch_size_helper.md) → [Step 3 Encode chunking](03_step_encode_chunking.md) → [Step 4 Tests & docs](04_step_tests_docs.md).

---

## 1. Inventory

### 1.1 Queue and adapter (do not change)

- **Adapter queue:** Internal queue stores job id; client polls status by id. `embed_job_status` resolves logical id → physical id + slice, then gets result from adapter (queue_get_job_status / store). We do not change the queue or status flow.
- **Job payload:** Main submits job with `job_params = { "command": "embed_execute", "params": payload, ... }`. `payload` = embed params: `texts`, `model`, `dimension`, `error_policy`, `device`; coalesced jobs also have `_coalesced_slices`.
- **Worker:** Adapter invokes command `embed_execute` with `params`; same handler as `EmbedCommand` (see `embed/commands/__init__.py`). One process per worker; `max_concurrent_jobs` = number of worker processes.

### 1.2 Entry points and execution path

- **Router:** `embed/commands/embed_router.py` — coalescing path or single-job path. Single-job: `_queue_submit_embed(params)` → one job with full params. Coalescing: buffer → `submit_batch` → one job with merged `texts` and `_coalesced_slices`.
- **Worker execution:** Adapter calls `EmbedExecuteCommand.execute()` (same as `EmbedCommand`). `embed/commands/embed_command.py`: `execute()` validates, then calls `run_embed_execute(rpc_start, service_init_time_ref, validated_params)` in `embed_command_executor.py`.
- **Executor:** `run_embed_execute` — model server vs direct service; gets `texts`, `model`, `dimension`, `device`; calls `service.get_embeddings(texts, model, dimension, device)` or model_client.encode. Returns `SuccessResult(data={ results, model, dimension, ... })`. That result is stored by adapter for the job id.
- **Encode:** `embedding_service.get_embeddings()` → `run_encode_flow(service, texts, device)` in `embedding_encode.py`. `run_encode_flow` calls `service.model.encode(texts)` once (via executor). No chunking today.

### 1.3 Config and memory (do not mix)

- **Embedding config:** `embed/config/config_schema.py` — `EmbeddingConfig`: `model_name`, `device`, `max_batch_size` (512), `max_text_length`, etc. `embedding_initializer` sets `service.MAX_BATCH_SIZE` from `embedding.max_batch_size`. Validator: `embedding.max_batch_size` must be positive integer if present (`config_validator.py`).
- **Model placement memory:** `estimate_model_load_memory_requirement_mb(model)` and `determine_device_for_request(..., required_mb)` in `model_device_manager` / `gpu_utils` — used only for “place model on CPU vs GPU”. Do not use for batch size.
- **Encode memory:** `embed/utils/gpu_memory_estimator.py` — `estimate_memory_requirement(texts, model_dimension)` returns MB for one forward pass over `texts`. Use this for “how many texts fit in GPU for encode”. `get_gpu_info()` in `gpu_utils` gives `memory_free` (bytes).

### 1.4 Existing helpers

- `embed/utils/text_utils.py` — `batch_texts(texts, max_batch_size)` splits list into sublists of length ≤ max_batch_size.
- `embed/commands/embed_runtime.py` — uses `service.MAX_BATCH_SIZE` to reject requests that exceed batch size (validation only).

---

## 2. Algorithm (detailed)

### 2.0 Two-channel scheme (minimizes latency)

The design is **two-channel**:

- **Channel main → worker:** Requests (texts + job id) are put into the adapter queue and passed to the worker. The main process does not wait for the result; it only enqueues and returns the job id to the client. So the client gets a fast response (job_id) and no blocking on encode.
- **Channel worker → main:** When the worker finishes, it sends the result and job id back; the adapter stores the result so that the client can retrieve it by id (e.g. `embed_job_status`). The client polls by id until the result is ready.

Because the main process never blocks on encode and the worker returns results asynchronously over the second channel, end-to-end latency for “job submitted” is minimal, and throughput is decoupled from request handling. Batching (chunking by `max_texts_per_batch` / GPU) happens inside the worker and does not add round-trips between main and worker.

### 2.1 Semantics

- **Max texts per encode:** Config parameter (e.g. `embedding.max_texts_per_batch`): maximum number of texts passed to the model in a single `encode()` call within one job.
- **If 0 or not set:** No config cap; worker decides batch size only by available GPU memory (encode memory estimate), so that one `encode(batch)` does not exceed free VRAM.
- **If > 0:** Worker uses min(config_cap, gpu_based_limit) as the chunk size. So: config caps, GPU memory can further reduce.

### 2.2 Data flow (unchanged at adapter level)

1. Request(s) arrive → router puts job(s) in adapter queue (id in queue; payload = texts + metadata). Coalescing can merge several requests into one job with many texts and `_coalesced_slices`.
2. Worker receives one job with `params` (e.g. `texts`, `model`, `dimension`, `device`, optional `_coalesced_slices`).
3. Worker must return one result per job: `{ results, model, dimension, ... }` with `len(results)` = `len(texts)`. Adapter stores this by job id; status/result commands deliver it to the client.

### 2.3 Worker-side batching (within one job)

1. **Input:** `validated_params` with `texts` (list of N texts), `model`, `dimension`, `device`, and optional `_coalesced_slices`.
2. **Effective chunk size:**  
   - If config `max_texts_per_batch` > 0: cap = `max_texts_per_batch`.  
   - If config is 0 or absent: cap = no limit from config.  
   - GPU-based limit: using `get_gpu_info()` and `estimate_memory_requirement(texts, dimension)` (or a small sample / per-text heuristic), compute the maximum number of texts K such that estimated MB for K texts ≤ free_mb (with a small safety margin).  
   - Effective batch size = min(cap, gpu_based_limit) if cap is set, else gpu_based_limit. If no GPU or estimation fails, fallback to a safe default (e.g. 32 or current MAX_BATCH_SIZE).  
   - **Recompute before each chunk:** GPU free memory is dynamic (e.g. after `empty_cache()`, other processes). Do not use one value for all chunks; re-query and recompute as in the Encode step below.
3. **Chunking:** Split `texts` into chunks of size ≤ effective batch size (reuse or mirror `batch_texts` logic). Chunk boundaries may be re-evaluated before each encode (see Encode step below).
4. **Encode:** **Before each chunk:** (re)query GPU free memory and (re)compute effective batch size so the next batch does not exceed *current* free VRAM—especially when memory is tight. Then send to encode only up to that many texts (slice the pre-planned chunk if needed). For each chunk in order: call the existing encode path — **direct service:** `run_encode_flow(service, chunk, device)` or `service.get_embeddings(chunk, ...)`; **model server:** `model_client.encode(chunk, model, device=...)` (worker sends one request per chunk; model server API is unchanged). Collect embedding lists (or minimal result data). **Immediately after each chunk:** release memory used for that batch — do not keep references to chunk tensors; if the model runs on GPU, call `torch.cuda.empty_cache()`. This keeps peak VRAM low and reduces OOM risk for the next chunk.
5. **Chunk failure:** If one chunk fails (e.g. OOM, encode exception), do not fail the whole job. For that chunk’s indices, put an error object (and no vector) in the result: same shape as today’s per-item errors (e.g. `{ "code": "...", "message": "..." }`). Remaining chunks are still processed. Final result has `len(results)` = `len(texts)`; failed positions contain the error description instead of an embedding vector (client gets error in that slot when polling by id).
6. **Merge:** Concatenate all chunk results in order into one `results` list and one `embeddings` list. Build the single job result: `{ results, embeddings, model, dimension, device }` so that `len(results)` = `len(texts)`.
7. Return this result to the adapter. No change to job id or status flow.

### 2.4 Nuances

- **Coalesced jobs:** Job may contain `_coalesced_slices`; slicing of the final merged result for logical jobs is already done in `embed_job_status` (physical result sliced by `start_index`, `count`). So worker still returns one physical result for the whole `texts`; slicing stays in status command.
- **Model server path:** If worker uses model server (HTTP), the chunking and multiple encode calls happen in the worker; model server receives one request per chunk (or we add batch endpoint; current design: worker chunks and calls encode per chunk).
- **Direct service path:** Same: worker has one process, one EmbeddingService (or gets it per job). Chunking in executor or in get_embeddings: split texts → encode chunk by chunk → concatenate.
- **Memory estimation:** Use only `estimate_memory_requirement(texts, dimension)` and `get_gpu_info()["memory_free"]`. Do not use `estimate_model_load_memory_requirement_mb` or device-selection logic for batch size.
- **Check memory before each batch:** GPU free memory is dynamic and may not match the value from the previous chunk (e.g. after `empty_cache()`, other processes, fragmentation). **Re-query `get_gpu_info()` and recompute effective batch size (or call the helper) before each send to the GPU**, not only once at job start. Especially important when VRAM is low.
- **Free memory after each batch:** After the model processes each chunk, clear memory used for that chunk: avoid holding references to batch tensors; on CUDA call `torch.cuda.empty_cache()`. This is possible and recommended to lower peak VRAM and avoid OOM on subsequent chunks.
- **Request-level limit (unchanged):** `embed_runtime` and service validation continue to use `MAX_BATCH_SIZE` to reject a single request that exceeds the limit. Chunking applies only inside the worker for an already accepted job (including coalesced jobs); the per-request cap is not relaxed.
- **Dimension for memory estimate:** The helper `get_effective_encode_batch_size(..., dimension, ...)` needs the model’s embedding dimension (e.g. 384, 768) for `estimate_memory_requirement(texts, model_dimension)`. At the executor call site, take `dimension` from `validated_params.get("dimension")` (same as for encode). If absent, use a fallback (e.g. service default or 384) so the estimate is still meaningful. Do not mix with “model placement” logic.
- **Chunked-encode logging:** Log chunked encode details (e.g. number of chunks, sizes) only when timing is enabled; write to the same separate timing file used by the project (see existing timing/profiling mechanism in the codebase), with a timestamp. No extra logging to the main log when timing is off.
- **Per-item error shape:** Use the same structure as existing per-item errors: `{"code": "<string or int>", "message": "<string>"}` (see `embed/commands/embed_runtime.py` and result `error` field in `embed_command_executor.py`). Client-facing result shape stays unchanged.
- **Chunk failure:** One failed chunk → error object in that result slot (and no vector); job completes with N slots, failed slots contain error description. No whole-job failure for a single chunk error.

---

## 3. What changes (summary)

- **External API:** Unchanged. Request/response schemas, JSON-RPC methods, job submit/status/result contracts, and the shape of embed results (including per-item errors) remain the same. Clients are not affected.
- **Config:** New key `max_texts_per_batch` (max texts per encode; 0 = only GPU). Added in [Step 1](01_step_config.md).
- **Generator / validator / CLI:** Support the new key (int ≥ 0). See [01_step_config.md](01_step_config.md).
- **Worker execution path:** Effective batch size (helper from [Step 2](02_step_batch_size_helper.md)), split into chunks, encode per chunk, merge; see [Step 3](03_step_encode_chunking.md).
- **Queue, adapter, status, id, coalescing contract:** Unchanged.

**See also:** [README](README.md) | [Step 1](01_step_config.md) | [Step 2](02_step_batch_size_helper.md) | [Step 3](03_step_encode_chunking.md) | [Step 4](04_step_tests_docs.md)
