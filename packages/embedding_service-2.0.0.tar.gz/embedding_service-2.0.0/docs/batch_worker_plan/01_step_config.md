# Step 1: Config — max texts per encode

**Author:** Vasiliy Zdanovskiy  
**email:** vasilyvz@gmail.com  

**Part of:** [Batch worker plan](README.md). **Step 1 of 4.** Context: [Inventory and algorithm](00_inventory_and_algorithm.md) (§1.3 Config, §2.1 Semantics). **Next:** [Step 2 — Helper](02_step_batch_size_helper.md) (uses this config value as `config_cap`).

This step: add configuration for maximum number of texts per encode (batch).

---

## Goal

- Add a config key that limits how many texts are sent to the model in one `encode()` call.
- If the key is 0 or not set: no config cap; only GPU free memory is used to decide batch size (handled in a later step).
- Do not change existing “model placement” memory logic.

---

## Tasks

1. **Schema** (`embed/config/config_schema.py`): In `EmbeddingConfig`, add a field, e.g. `max_texts_per_batch: int = Field(0, description="Max texts per encode; 0 = use only GPU memory")`. Default 0 so that by default behaviour is “only GPU memory”.
2. **Defaults** (`embed/config/config_defaults.py`): Set the new field to 0 in the default embedding config.
3. **Validator** (`embed/config/config_validator.py`): For the new key (e.g. `embedding.max_texts_per_batch`), allow non-negative integer (0 or positive). If present and not int or &lt; 0, add validation error.
4. **Generator** (`embed/config/config_generator.py`): Include the new key in the generated embedding section (e.g. `"max_texts_per_batch": 0` with a short comment).
5. **CLI:** The config CLI already supports generic `--set section.key=value`; `--set embedding.max_texts_per_batch=N` will work once the key exists in schema and validator. No CLI code change required; document the key in Step 4 if desired.
6. **Embedding initializer** (`embed/services/embedding_initializer.py`): Read the new value (e.g. `get_config_value("embedding.max_texts_per_batch", 0)`) and set on the service (e.g. `service.max_texts_per_batch = ...`). Ensure it is available to the executor/worker path.
7. **EmbeddingService** (`embed/services/embedding_service.py`): Add an instance attribute (e.g. `self.max_texts_per_batch = 0`) so executor/encode path can read it.

---

## Acceptance

- Config file can set `embedding.max_texts_per_batch` to 0 or a positive integer.
- Validation accepts 0 and positive integers; rejects negative or non-integer.
- Generator includes the key; CLI supports it via existing `--set embedding.*`.
- Service instance exposes the value for use in the next step.
- No change to external API or request/response shape.

**See also:** [README](README.md) | [00 Inventory](00_inventory_and_algorithm.md) | [Step 2](02_step_batch_size_helper.md) (helper uses `service.max_texts_per_batch`) | [Step 4](04_step_tests_docs.md) (document this key)
