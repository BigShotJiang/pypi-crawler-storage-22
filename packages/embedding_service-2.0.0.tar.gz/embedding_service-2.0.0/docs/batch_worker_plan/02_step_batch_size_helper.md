# Step 2: Helper — effective batch size from config and GPU

**Author:** Vasiliy Zdanovskiy  
**email:** vasilyvz@gmail.com  

**Part of:** [Batch worker plan](README.md). **Step 2 of 4.** Context: [Inventory and algorithm](00_inventory_and_algorithm.md) (§1.3 Config and memory, §2.3 Worker-side batching). **Depends on:** [Step 1](01_step_config.md) (`config_cap` = `service.max_texts_per_batch`). **Used by:** [Step 3](03_step_encode_chunking.md) (encode path calls this before each chunk).

This step: implement a helper that returns the effective batch size (config cap and GPU memory).

---

## Goal

- Compute the maximum number of texts to send in one `encode()` call: config cap (if &gt; 0) and GPU-based limit.
- Use only encode memory estimation (`estimate_memory_requirement`) and `get_gpu_info()["memory_free"]`. Do not use model placement helpers.

---

## Tasks

1. **Place:** Add the helper in a module used by the worker/encode path. Recommended: `embed/utils/gpu_memory_estimator.py` (already has `estimate_memory_requirement`). Alternative: `embed/utils/gpu_utils.py`. Do not add to model placement or device-selection code.
2. **Signature:** e.g. `def get_effective_encode_batch_size(config_cap: int, dimension: int, texts_sample: Optional[List[str]] = None) -> int`.  
   - `config_cap`: from `service.max_texts_per_batch` (0 = no cap).  
   - `dimension`: **model embedding dimension** (e.g. 384, 768) — used by `estimate_memory_requirement(texts, model_dimension)` to compute MB for the forward pass. The caller (executor) passes `validated_params.get("dimension")`; if None, use a fallback (e.g. 384) so the estimate is still valid.  
   - `texts_sample`: optional list used to estimate average text size; if None, use a conservative default (e.g. assume some average length for per-text estimate).
3. **Logic:**  
   - If `config_cap > 0`, set upper_bound = config_cap; else upper_bound = a large number (e.g. 10_000 or existing MAX_BATCH_SIZE).  
   - Get GPU free memory (e.g. `get_gpu_info()` → `memory_free` in bytes → free_mb). If no GPU or missing info, return min(upper_bound, safe_default). Safe default: e.g. 32 or `service.MAX_BATCH_SIZE` if available, for consistency.  
   - Using `estimate_memory_requirement(texts, dimension)` (or a per-text approximation if you have only dimension), find the largest N such that estimated MB for N texts ≤ free_mb (minus a small safety margin, e.g. 50 MB).  
   - Return min(upper_bound, N) or min(upper_bound, safe_default).
4. **Docstring:** Explain that this is for encode batch size only, not for model placement. Document parameters and return value.
5. **Per-chunk usage:** The encode path will call this helper (or re-query GPU and recompute) **before each chunk** sent to the GPU, because free memory is dynamic. The helper must use current `get_gpu_info()` at call time; no caching of “effective size” across chunks.

---

## Acceptance

- Helper returns a positive integer.
- When config_cap = 0, result is limited only by GPU memory (or safe default when no GPU).
- When config_cap &gt; 0, result never exceeds config_cap and may be further reduced by GPU memory.
- No use of `estimate_model_load_memory_requirement_mb` or device-selection logic in this helper.
- Safe default when no GPU / estimation fails: e.g. 32 or existing MAX_BATCH_SIZE for consistency.
- Caller will invoke the helper before each chunk; helper uses current GPU state at call time (no cross-chunk caching of batch size).

**See also:** [README](README.md) | [00 Inventory](00_inventory_and_algorithm.md) | [Step 1](01_step_config.md) | [Step 3](03_step_encode_chunking.md) (caller) | [Step 4](04_step_tests_docs.md) (tests for this helper)
