# Step 3: Encode path — chunk texts and merge results

**Author:** Vasiliy Zdanovskiy  
**email:** vasilyvz@gmail.com  

**Part of:** [Batch worker plan](README.md). **Step 3 of 4.** Context: [Inventory and algorithm](00_inventory_and_algorithm.md) (§1.2 Entry points, §2.3 Worker-side batching, §2.4 Nuances). **Depends on:** [Step 1](01_step_config.md) (config + service attribute), [Step 2](02_step_batch_size_helper.md) (effective batch size helper). **Next:** [Step 4](04_step_tests_docs.md) (tests and docs for this behaviour).

This step: in the worker execution path, split texts into chunks, encode each chunk, merge results.

---

## Goal

- When the worker runs embed (embed_execute), do not pass all texts to a single `encode()` call when there are many texts.
- Use effective batch size (from Step 2); split texts into chunks; call encode per chunk; concatenate results and return one result for the job (same shape as today).

---

## Tasks

1. **Where to chunk:** Prefer a single place so both “direct service” and “model server” paths benefit. Options:  
   - (A) In `embed_command_executor.run_embed_execute`: before calling `service.get_embeddings(texts, ...)` or `model_client.encode`, compute effective batch size, split `texts` into chunks, loop: get embeddings for each chunk, concatenate `results` and `embeddings`; then pass the merged result to the rest of the flow.  
   - (B) Inside `EmbeddingService.get_embeddings`: before `run_encode_flow(service, texts, device)`, split texts using effective batch size, call `run_encode_flow` (or internal encode) per chunk, merge.  
   Choose one and stick to it so that embed_execute (worker) always goes through it.
2. **Effective batch size:** Call the helper from [Step 2](02_step_batch_size_helper.md) with `service.max_texts_per_batch` (or config), **dimension** from `validated_params.get("dimension")` (same as passed to encode; if None, use service default or 384 for the memory estimate), and optionally `texts` (or a sample) for GPU estimate. Ensure service is initialized so config is available.
3. **Splitting:** Use existing `batch_texts(texts, max_batch_size)` from `embed/utils/text_utils.py` or equivalent so that each chunk has length ≤ effective_batch_size. Chunk sizes may be refined per iteration (see next task).
4. **Check memory before each chunk:** **Before sending each chunk to the GPU**, (re)query GPU free memory and (re)compute effective batch size (call the [Step 2](02_step_batch_size_helper.md) helper again, or equivalent with current `get_gpu_info()`). Do not assume the size computed at job start is valid for all chunks—VRAM is dynamic (e.g. after `empty_cache()`, other processes), especially when memory is low. Use the current effective size to limit the next batch: either take the next chunk of size ≤ current effective size, or re-slice remaining texts by current effective size. Then encode only that batch.
5. **Encode per chunk:** For each chunk (possibly smaller after memory check), call the same encode path that is used today for one batch (e.g. `get_embeddings(service, chunk, ...)` or `run_encode_flow(service, chunk, device)`). Collect list of result lists (e.g. list of `results` and list of `embeddings`). **If a chunk fails** (exception, OOM): for that chunk’s indices, fill the result with an error object; use the **same per-item error shape as elsewhere in the codebase** (e.g. `code`, `message`—verify in existing embed result format). **After each chunk:** free memory used for that batch — do not keep references to the chunk’s tensors; if using GPU, call `torch.cuda.empty_cache()` so the next chunk has more free VRAM and to reduce OOM risk.
6. **Merge:** Concatenate `results` and `embeddings` in order so that the final `results` and `embeddings` correspond 1:1 to the original `texts`. Failed positions contain the error object (no embedding). Build the same result shape as today: `{ results, model, dimension, embeddings?, device? }`.
7. **Coalesced jobs:** Jobs with `_coalesced_slices` already expect one physical result for the full `texts`; `embed_job_status` slices by slice. So merged result must have `len(results)` = `len(texts)`; no change to slice handling.
8. **Edge cases:** If effective batch size is 0 or 1, still run encode (single text or tiny batch). If no texts, return empty results without calling encode.
9. **Request-level limit (unchanged):** Do not change `embed_runtime` or `MAX_BATCH_SIZE` validation. A single request (or per-request limit) is still rejected if it exceeds `MAX_BATCH_SIZE`; chunking applies only inside the worker for an already accepted job.
10. **Logging:** Log chunked-encode details (e.g. number of chunks, batch sizes) only when timing is enabled; write to the project’s **same timing file/path** as the rest of the project (locate via existing timing or profiling code), with a timestamp. No such logging to the main log when timing is off.

**Notes:** Model server: chunk in executor, loop `model_client.encode(chunk, ...)`, concatenate; API unchanged. error_policy continue: chunking at least for fail_fast and model server paths.

---

## Acceptance

- Worker receives one job with N texts; response has exactly N result items and N embeddings (failed slots contain error object instead of vector).
- Internally, encode is called in chunks of size ≤ effective_batch_size (config and GPU).
- **GPU memory is checked before each chunk** (re-query and recompute effective size); no single batch size assumed for all chunks.
- **If one chunk fails:** that chunk’s indices get an error object in the result; job still completes with N slots; client sees error in that slot when polling by id. Error shape matches existing per-item errors in the codebase.
- **After processing each batch, memory for that batch is cleared** (no lingering references; on GPU, `torch.cuda.empty_cache()` is called).
- Chunked-encode logging only when timing is on; output to the project’s existing timing file with timestamp.
- Request-level validation (MAX_BATCH_SIZE) is unchanged; chunking does not relax per-request limit.
- Coalesced jobs and embed_job_status slicing behave as before.
- No change to adapter queue, job id, or status/result API; external API and result shape unchanged ([README](README.md)).
- **error_policy:** When `error_policy == "continue"`, the current code uses `generate_embeddings_continue` (per-item). Chunking in this step applies at least to the single-call path (fail_fast and model server). If continue mode is left as-is, chunking does not apply there; otherwise the chunked path can fill failed chunk slots with the same per-item error shape.

**See also:** [README](README.md) | [00 Inventory & algorithm](00_inventory_and_algorithm.md) | [Step 1](01_step_config.md) | [Step 2](02_step_batch_size_helper.md) | [Step 4](04_step_tests_docs.md)
