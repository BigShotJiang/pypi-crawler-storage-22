# Step 4: Tests and documentation

**Author:** Vasiliy Zdanovskiy  
**email:** vasilyvz@gmail.com  

**Part of:** [Batch worker plan](README.md). **Step 4 of 4.** Context: [Inventory and algorithm](00_inventory_and_algorithm.md). **Covers:** [Step 1](01_step_config.md) (config tests), [Step 2](02_step_batch_size_helper.md) (helper tests), [Step 3](03_step_encode_chunking.md) (chunked encode and failure tests), plus project docs (e.g. [CONFIG_OPERATION_LIMITS.md](../CONFIG_OPERATION_LIMITS.md)).

This step: tests and doc updates for the batch worker behaviour.

---

## Goal

- Add or adjust tests for config, effective batch size helper, and chunked encode behaviour.
- Update project documentation that describes embedding config or queue/worker behaviour so that max texts per encode and GPU-based batching are reflected.

---

## Tasks

1. **Config** ([Step 1](01_step_config.md)): Unit test that `embedding.max_texts_per_batch` is validated (0 and positive allowed; negative or non-int rejected). Test that generator produces the key and that initializer sets it on the service.
2. **Helper** ([Step 2](02_step_batch_size_helper.md)): Unit test for `get_effective_encode_batch_size`: with config_cap=0 and mock GPU (e.g. free_mb), result is limited by memory; with config_cap=10, result ≤ 10; with no GPU, result is safe default or config cap.
3. **Chunked encode** ([Step 3](03_step_encode_chunking.md)): Integration or unit test: call embed path with more texts than effective batch size; assert result has correct length and structure (e.g. one job returns N results for N texts, and embeddings are in order). Optionally assert that encode was called more than once when texts are many. **Chunk failure:** test that when one chunk fails (e.g. mock OOM on second chunk), the job still returns N slots with error object in the failed chunk’s positions and valid embeddings in the rest. **Memory checked per chunk:** when feasible (mocks or timing), assert that GPU memory (or `get_effective_encode_batch_size` / `get_gpu_info`) is queried **before each chunk**, not only once—e.g. mock `get_gpu_info` to return different `free_mb` on the second call and assert the second batch size respects the new limit.
4. **Request-level limit:** Test or document that a single request with texts count &gt; `MAX_BATCH_SIZE` is still rejected at entry (`embed_runtime` / validation); chunking does not relax this ([00 §2.4 Nuances](00_inventory_and_algorithm.md#24-nuances)).
5. **Docs:** In docs that list embedding config, add `max_texts_per_batch`: meaning (max texts per encode; 0 = only GPU memory), default 0, and that it does not affect model placement logic. Primary target: [CONFIG_OPERATION_LIMITS.md](../CONFIG_OPERATION_LIMITS.md) (embedding section). If the project has CONFIG_DEPENDENCIES or a single “embedding config” section, update those too.

---

## Acceptance

- New or updated tests pass.
- **External API unchanged:** Tests and docs assume request/response and job/status contracts are unchanged; no client-facing breaking changes.
- Test or doc confirms request-level limit (MAX_BATCH_SIZE) is unchanged.
- Optional test confirms GPU memory is re-checked before each chunk when mocks allow.
- Documentation clearly states the new option and that batch size is for encode only, not for model placement.

**See also:** [README](README.md) | [00 Inventory](00_inventory_and_algorithm.md) | [Step 1](01_step_config.md) | [Step 2](02_step_batch_size_helper.md) | [Step 3](03_step_encode_chunking.md)
