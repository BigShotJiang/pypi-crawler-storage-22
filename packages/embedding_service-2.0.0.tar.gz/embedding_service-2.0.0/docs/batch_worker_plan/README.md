# Batch worker plan

**Author:** Vasiliy Zdanovskiy  
**email:** vasilyvz@gmail.com  

This is the **index** of the batch worker plan. Each linked document is self-contained; use the links below for full context.

**Summary:** Worker-side batching for embed (max texts per encode; GPU-based limit). **Core idea: two-channel scheme** — main→worker (submit job, return id) and worker→main (result by id) — **minimizes latency** (no blocking on encode; client gets id immediately and polls for result). Adapter queue and status flow unchanged.

**Constraint: external API must not change.** Request/response schemas, JSON-RPC method names, job submission and status/result retrieval contracts, and the shape of embed results (including per-item errors) stay as they are. All changes are internal (config, worker-side chunking, merge).

| Document | Content |
|----------|---------|
| [00_inventory_and_algorithm.md](00_inventory_and_algorithm.md) | Code inventory, [algorithm (§2)](00_inventory_and_algorithm.md#2-algorithm-detailed), [what changes (§3)](00_inventory_and_algorithm.md#3-what-changes-summary) |
| [01_step_config.md](01_step_config.md) | Step 1: Config `max_texts_per_batch`, generator, validator, CLI |
| [02_step_batch_size_helper.md](02_step_batch_size_helper.md) | Step 2: Helper for effective batch size (config + GPU memory) |
| [03_step_encode_chunking.md](03_step_encode_chunking.md) | Step 3: Chunk texts in worker, encode per chunk, merge results |
| [04_step_tests_docs.md](04_step_tests_docs.md) | Step 4: Tests and documentation |

**Implementation order:** [01](01_step_config.md) → [02](02_step_batch_size_helper.md) → [03](03_step_encode_chunking.md) → [04](04_step_tests_docs.md) (each step depends on the previous).

**Documentation language:** English (code, comments, docstrings, and plan docs).
