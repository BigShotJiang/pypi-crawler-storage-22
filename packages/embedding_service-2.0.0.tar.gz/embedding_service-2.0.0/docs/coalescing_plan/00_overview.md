# Coalescing implementation plan — overview

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  
**Date:** 2026-02

---

## Purpose

Step-by-step technical specification for implementing request coalescing (dynamic batching) on the embedding server. Each step is described in a separate file in this directory. Implementation order: execute steps in numerical order (01 → 10).

## Autonomy of steps

Each step file is **self-contained**: it includes a **Context** section with references to:

- [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — architecture, single queue handler, parallel processes.
- Previous step files (e.g. [01_config_schema.md](01_config_schema.md)) where relevant.
- Relevant code: `embed/config/config_manager.py`, `embed/commands/embed_command.py`, `embed/commands/embed_job_status_command.py`, etc.

Read the Context section at the start of each step to form the correct context before implementation.

## Code principles (обязательно)

- **No backward compatibility.** Do not support old formats, old APIs, or missing fields. Current schema and contract only.
- **No fallbacks to old code.** No legacy paths, no "if missing then assume X". One clear code path per feature.
- **Client is the single interface.** For the external world, the client hides implementation details; no bypassing the client contract.
- **No stats DB yet.** There is no separate database for statistics; code stays clean and minimal. When analytics are needed, they use the current schema only (e.g. JSONL timing file with current record shape).
- **Clean code.** No optional/legacy branches; no "treat missing as Y" logic.

## End of each step: code_mapper

**At the end of every step** (after all code changes and tests), run the project’s **code_mapper** command to update indices in `code_analysis/` (file/method index, descriptions, issues). This is mandatory regardless of which files were touched.

**Command (from project root, with .venv activated):**
```bash
code_mapper -r embed/
```
Output: `code_analysis/code_map.yaml`, `code_analysis/code_issues.yaml`, `code_analysis/method_index.yaml`.

## Completion metric (общая для всех шагов)

Each step file defines a **Completion metric (Метрика завершения)**. In addition to step-specific criteria, the following must be satisfied before the step is considered done:

1. **Static checks (zero errors):**
   - **black** — run from project root (e.g. `black embed/ tests/`); no formatting errors; fix or accept formatting for the whole project as per project rules.
   - **mypy** — no errors in the project (run from project root; fix any reported errors even if they are in files not modified in this step).
   - **flake8** — no errors (same: fix all, not only in changed files).
   - **code_mapper** — run `code_mapper -r embed/`; no errors; indices in `code_analysis/` updated and consistent.

2. **All tests passing:**
   - Run the **full test suite** (e.g. `pytest tests/` or project’s standard test command). **All** tests must pass, not only the tests added or touched for this step. Fix any failing test before closing the step.

3. **Real server tests:**
   - At least one test (or a dedicated script) must run against a **real running server**: start the embedding service on a **different port** (e.g. 8001 or 9000 so as not to conflict with a default 8000), run the test(s), then stop the server. Use the project’s standard ASGI server (**hypercorn**); do not use uvicorn. The step document specifies what “real server” scenario is required (e.g. config load, health, embed without coalescing). Server must be started and stopped programmatically within the test or script (no manual start/stop for acceptance).

4. **Step-specific tests:**
   - **Unit tests** that cover the code added or changed in this step (as listed in the step’s “Completion metric”).
   - **Integration tests** that cover the step’s integration points (if any), as listed in the step.

5. **Coverage (per file, project-wide):**
   - **Upon completion of the step**, each file of the project (existing and new) must have test coverage **≥ 90%** (e.g. `pytest --cov=embed --cov-report=term-missing`). Add or adjust tests so that no project file is below 90% when the step is done. Applies to both old and new code.

6. **Commit after step (mandatory):**
   - After the step is complete and all of the above are satisfied, **commit** the changes (e.g. `git add ... && git commit -m "Step N: ..."`). This is **mandatory** for each step. Push only on explicit user request.

7. **Feature success (final metric):**
   - Besides all commands and mechanisms working, the feature is complete only when: (1) **Successful auto-registration on the proxy** is verified: the embedding service (when started with config that enables proxy registration) registers with the proxy and is visible/healthy from the proxy (e.g. proxy list or health check confirms the server). (2) **All MCP commands work through the proxy**: every command (health, echo, help, config, models, embed, embed_job_status, timing_stats, and any other MCP/adapter commands) must succeed when the client calls the **proxy** (proxy forwards to the embedding server); no scenario may require a direct connection to the server for success. Real-server or integration test must assert both; see step 10 and step 12 pipeline.

Details (exact commands, port, which tests) are in each step file’s **Completion metric** section.

## Test refactoring (рефакторинг тестов)

Each step that changes behaviour or interfaces must include **explicit refactoring of affected tests**. The table below maps existing test assets to the steps that affect them; each step document lists concrete refactoring tasks in its **Completion metric**.

| Test file / asset | What it tests | Affected steps | Refactoring focus |
|------------------|---------------|----------------|-------------------|
| `tests/test_config_validation.py` | JSON config structure | 01 | Add coalescing validation tests; keep example/main config tests passing. |
| `tests/unit/test_coalescing_config.py` | CoalescingConfig, ConfigModel.coalescing | 01, 02 | Step 01: add tests; Step 02: tests for get_coalescing_config(), create_default_config(). |
| `embed/config/test_config_manager.py` | ConfigManager load/save, getters | 02 | create_default_config() and load_from_dict() with/without coalescing; get_coalescing_config(). |
| `tests/conftest.py` | Fixtures: client, embedding_service | 02, 09 | Step 09: set coalescing disabled in test config so existing tests keep inline result or one job_id. |
| `tests/unit/test_commands.py` | EmbedCommand, EmbedJobStatusCommand | 06, 08, 09 | Step 08: unit tests for embed_job_status (logical vs physical job_id). Step 09: mock coalescing disabled or cover both paths. |
| `tests/test_embedding_basic.py` | EmbeddingService, EmbedCommand execute | 09 | Config with coalescing disabled so immediate result; or adapt to job_id + poll. |
| `tests/test_embedding_advanced.py` | Multilingual embed via client | 09 | Client fixture coalescing off; or add coalescing-on tests. |
| `tests/test_error_handling.py` | Embed/embed_job_status errors via HTTP | 08, 09 | Step 08: embed_job_status (logical not found, physical error). Step 09: coalescing disabled for immediate error tests. |
| `tests/integration/test_api.py` | Embed, models, health JSON-RPC | 09 | Config coalescing disabled for inline embed result; or add job_id + embed_job_status tests. |
| `tests/test_load_stress.py` | Stress: embed → job_id → embed_job_status | 06–09 | Step 08: logical job_id resolves to slice. Step 09: stress with coalescing off and on. |
| `tests/test_integration_simple.py`, `test_integration.py`, `test_real_integration.py` | Integration flows | 09, 10 | Step 09: coalescing disabled by default; or add coalescing-on scenario. Step 10: consolidate. |
| `tests/test_http_endpoints.py`, `test_basic_mode.py`, `test_single_config.py` | HTTP/health/config | 01, 02 | Configs include valid coalescing or omit (default off). |
| New unit tests (store, buffer, payload, coalescer, routing) | Steps 03–07, 09 | 03–07, 09 | Each step adds unit tests; per-file coverage ≥ 90% (old and new). |
| `tests/integration/test_coalescing_*.py` (step 10) | Coalescing E2E, real server | 10 | New files; full suite and real server pass. |
| Tests for EmbedCommand timing + timing_stats | record_timing entry with _coalesced_slices; _compute_stats coalesced_batch_count | 11 | Step 11: unit test execute() with _coalesced_slices → entry has coalesced_batch, logical_request_count; unit test timing_stats on records with current schema only (no old-format/missing-key tests). |
| Real-server pipeline CLI (optional pytest) | scripts/embed_pipeline_cli --profile quick against live server | 12 | Step 12: optional integration test that starts server (hypercorn) and runs CLI; or document manual run only. |

**Rules:** (1) Each step's Completion metric must include a **Test refactoring** subsection with test files and concrete actions. (2) Tests assuming "embed returns inline result" must run with coalescing disabled unless testing coalescing path. (3) After refactoring, all existing tests must pass.

**Common mocks and fixtures:** See [TEST_ANALYSIS_FIXTURES_MOCKS.md](../TEST_ANALYSIS_FIXTURES_MOCKS.md) for analysis of duplicated mocks/fixtures (client, test config, mock EmbeddingService, JSON-RPC bodies). Refactoring may introduce shared helpers (e.g. `tests/helpers/mock_embedding_service.py`, minimal test config in conftest) so that steps 08–10 and existing tests use one client, one config source, and one mock factory.

## Code standards (apply to all steps)

- **File header docstrings:** Every new production code file must include a module-level docstring with: `Author: Vasiliy Zdanovskiy`, `email: vasilyvz@gmail.com` (as per project rules).
- **File size:** Keep new code files under 350–400 lines; split into smaller modules or facade if larger.
- **Commit after step (mandatory):** After the step is complete and the completion metric is satisfied, commit the changes (e.g. `git add ... && git commit -m "Step N: ..."`). Push only on explicit user request.

## Deferred / open points (not forgotten, follow-up or later)

- **Logical job store TTL/retention:** How long to keep logical job metadata (e.g. align with `completed_job_retention_seconds` or separate TTL); optional cleanup to avoid unbounded growth (see step 03 and COALESCING_ANALYSIS §5).
- **Metrics:** Optional metrics (coalesced_batch_size, coalescing_wait_sec) for tuning; can be added after main flow works (see COALESCING_ANALYSIS §5).
- **Adapter contract:** Confirm queue submit API and result storage for one physical job (see COALESCING_ANALYSIS §5); document in step 06.

## Steps (one file per step)

| Step | File | Summary |
|------|------|---------|
| 1 | [01_config_schema.md](01_config_schema.md) | Coalescing config schema (model and fields). |
| 2 | [02_config_integration.md](02_config_integration.md) | Integrate coalescing config into ConfigManager. |
| 3 | [03_logical_job_store.md](03_logical_job_store.md) | Logical job store: structure and API. |
| 4 | [04_coalescer_buffer.md](04_coalescer_buffer.md) | Coalescer: buffer and accumulation logic. |
| 5 | [05_coalescer_payload.md](05_coalescer_payload.md) | Build merged payload and slice metadata. |
| 6 | [06_coalescer_submit.md](06_coalescer_submit.md) | Submit one batch job to queue; register logical jobs. |
| 7 | [07_coalescer_completion.md](07_coalescer_completion.md) | On batch completion: distribute results and set status. |
| 8 | [08_embed_job_status.md](08_embed_job_status.md) | Resolve logical job_id in embed_job_status. |
| 9 | [09_embed_command_routing.md](09_embed_command_routing.md) | Route embed requests: coalescing path vs current path. |
| 10 | [10_tests_validation.md](10_tests_validation.md) | Test plan and acceptance criteria. |
| 11 | [11_timing_and_timing_stats.md](11_timing_and_timing_stats.md) | Timing record structure and timing_stats command for coalesced batches. |
| 12 | [12_real_server_test_pipeline_cli.md](12_real_server_test_pipeline_cli.md) | Real-server test pipeline CLI: all commands, text sizes, load patterns; mcp_proxy_adapter client. |

## Dependencies

- Steps 1–2: config (no dependency on coalescer).
- Step 3: store used by 4, 6, 7, 8.
- Steps 4–5: coalescer buffer and payload (input to 6).
- Step 6: uses store and queue; triggers 7 on completion.
- Step 8: uses store to resolve logical job_id.
- Step 9: wires coalescing vs non-coalescing; depends on 4–8.
- Step 10: validates full flow.
- Step 11: timing and timing_stats; depends on 5 (payload with _coalesced_slices) and 7 (batch execution); implement after 9 so execute() path is final.
- Step 12: real-server pipeline CLI; depends on 10 (test approach); uses mcp_proxy_adapter client only; does not start/stop server.

## Out of scope (this plan)

- Changes inside mcp_proxy_adapter (queue manager, worker loop).
- Metrics (coalesced_batch_size, coalescing_wait_sec) — can be added later.

## Completeness checklist (всё ли учтено)

Use this to verify nothing is forgotten across the plan and analysis:

| Area | Where | Status |
|------|--------|--------|
| **Proposal** | [COALESCING_PROPOSAL.md](../COALESCING_PROPOSAL.md) | Motivation, config, error handling, client contract. |
| **Analysis** | [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) | Architecture, single handler, parallel processes, config, homogeneity, errors, open points. |
| **Config schema** | Step 01 | CoalescingConfig: enabled, window_sec, max_texts, max_wait_sec. |
| **Config generator** | Step 01 | scripts/generate_configs.py: template includes coalescing section. |
| **Config validators** | Step 01 | validate_all_configs.py, test_config_validation.py, tests/test_config_validation.py: optional coalescing validation when section present; cross-checks per [CONFIG_DEPENDENCIES.md](../CONFIG_DEPENDENCIES.md). |
| **Validator code changes** | Step 01 | Concrete edits per file: [CONFIG_DEPENDENCIES.md §7](../CONFIG_DEPENDENCIES.md#7-required-code-changes-in-validators) (required_sections, Phase 2 security, coalescing + Phase 4, tests). |
| **Config loading** | Step 02 | get_coalescing_config(); create_default_config() includes coalescing. |
| **Logical job store** | Step 03 | register/get/set_physical_result|error; TTL deferred. |
| **Buffer + homogeneity** | Step 04 | (model, dimension, error_policy, device), window, max_texts. |
| **Payload + _coalesced_slices** | Step 05 | build_batch_payload; EmbedCommand contract. |
| **Submit + register** | Step 06 | One job to queue, register_logical_jobs, return N logical_job_ids. |
| **Completion** | Step 07 | set_physical_result/error; callback or lazy. |
| **Error handling** | Steps 07–08 | fail_fast: batch fail → same error for all; continue: per-item errors preserved in slice (ANALYSIS §4.6). |
| **embed_job_status** | Step 08 | Resolve logical job_id → pending or slice or error. |
| **Routing** | Step 09 | coalescing_enabled → coalescer else current path; max_concurrent_jobs unchanged. |
| **Tests** | Step 10 | Unit, integration, real server on alternate port (start with **hypercorn**), full suite pass. |
| **Timing and timing_stats** | Step 11 | Timing record: coalesced_batch, logical_request_count when _coalesced_slices present; timing_stats: coalesced_batch_count, non_coalesced_count, optional breakdown. |
| **Real-server pipeline CLI** | Step 12 | CLI utility (scripts/embed_pipeline_cli) using mcp_proxy_adapter client; all commands; small/medium/large texts; single, batch, many single, mixed; profiles quick/full/stress; JSON report. |
| **Proxy auto-registration** | Step 10, 12 | Successful auto-registration on the proxy when server starts with registration enabled; verified in real-server test or pipeline (proxy lists server / health confirms). |
| **All MCP commands via proxy** | Step 10, 12 | All MCP commands (health, echo, help, config, models, embed, embed_job_status, timing_stats, etc.) work when client calls the proxy (proxy forwards to embedding server); verified in real-server test or pipeline; no direct-to-server-only path for success. |
| **Static checks** | All steps | **black**, mypy, flake8, code_mapper — zero errors project-wide. |
| **Code standards** | 00 | File header docstrings (Author, email); file size ≤400 lines; commit after step. |
| **Deferred** | 00, 03 | TTL/retention for logical jobs; metrics; adapter contract documented in 06. |
