# Step 1: Coalescing config schema

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §3 (single queue handler), §4.4 (Configuration: coalescing section, parameters).
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric.
- **Code:** `embed/config/config_manager.py` — existing `QueueManagerConfig`, `ConfigModel`, `EmbeddingConfig`; add `CoalescingConfig` and `coalescing` field in the same style.
- **Dependencies:** [CONFIG_DEPENDENCIES.md](../CONFIG_DEPENDENCIES.md) — dependency graph and validator behaviour; coalescing.enabled=true requires queue_manager.enabled=true.
- **No prior steps** — this is the first step.

---

## Goal

Define the configuration model and fields for request coalescing. One place to extend: config schema only; no loading or usage in this step.

## Tasks

1. **Add `CoalescingConfig` model** (new Pydantic model in the same module as `QueueManagerConfig`).
   - **File:** `embed/config/config_manager.py` (or a new file `embed/config/coalescing_config.py` if you prefer to keep config_manager small; then import into ConfigModel).
   - **Fields:**
     - `enabled: bool = False` — enable coalescing (default off).
     - `coalescing_window_sec: float = 0.03` — max time (seconds) to wait for more requests before sending the batch (e.g. 0.02–0.05).
     - `coalescing_max_texts: int = 64` — flush when merged batch reaches this many texts even if window has not expired.
     - `coalescing_max_wait_sec: Optional[float] = 0.1` — optional; max time a single request may wait if no other requests arrive (if None, only window and max_texts apply).
   - **Descriptions:** Add Field(..., description="...") for each so config is self-explanatory.

2. **Add coalescing to main config model.**
   - In `ConfigModel` (or equivalent), add:
     - `coalescing: Optional[CoalescingConfig] = Field(default_factory=lambda: CoalescingConfig(...), description="Request coalescing (batching) for embed command")`.
   - Defaults must yield coalescing disabled (`enabled=False`) so existing configs behave unchanged.

3. **Validation (optional in this step).**
   - If present: `coalescing_window_sec` and `coalescing_max_texts` must be positive; `coalescing_max_wait_sec` if set must be >= 0 and typically >= coalescing_window_sec (document or validate). Pydantic validators on the model can enforce this.

4. **Config generator (must be updated in the same step).**
   - **File:** `scripts/generate_configs.py`. The template in `_get_template_config()` must include a `coalescing` section so that generated config files contain the new block. Add: `"coalescing": {"enabled": False, "coalescing_window_sec": 0.03, "coalescing_max_texts": 64, "coalescing_max_wait_sec": 0.1}` to the template (same defaults as CoalescingConfig). All config types generated from this template will then include coalescing with safe defaults.

5. **Config validators (must be updated in the same step).**
   - Follow the **exact code-change checklist** in [CONFIG_DEPENDENCIES.md §7](../CONFIG_DEPENDENCIES.md#7-required-code-changes-in-validators):
     - **scripts/validate_all_configs.py** (§7.1): add `security` to required_sections (or validate when present); Phase 2 security.mode and cert/key/ca; coalescing section (types and bounds); Phase 4 cross-check coalescing.enabled ⇒ queue_manager.enabled.
     - **scripts/test_config_validation.py** (§7.2): same required_sections and Phase 2; embedding timing; coalescing section and cross-check.
     - **tests/test_config_validation.py** (§7.3): same logic in `validate_json_structure()`; add tests `test_coalescing_requires_queue_enabled`, `test_coalescing_section_valid`, `test_coalescing_invalid_values`.
   - Optional: add Pydantic validators and root validator in ConfigModel (§7.4). Optional follow-up: single shared validation function (§7.5).

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **embed/config/coalescing_config.py** | **ADD** (or keep if exists) | New module. Define class `CoalescingConfig(BaseModel)` with fields: `enabled: bool = False`, `coalescing_window_sec: float = 0.03`, `coalescing_max_texts: int = 64`, `coalescing_max_wait_sec: Optional[float] = 0.1`. Add `Field(..., description="...")` for each. Add `@field_validator` for `coalescing_window_sec` (must be > 0), `coalescing_max_texts` (must be > 0), `coalescing_max_wait_sec` (if set must be >= 0). Module docstring with Author/email. |
| **embed/config/config_manager.py** | **CHANGE** | Add `from embed.config.coalescing_config import CoalescingConfig` and `from pydantic import ..., model_validator`. In `ConfigModel`: add field `coalescing: Optional[CoalescingConfig] = Field(default_factory=lambda: CoalescingConfig(enabled=False, ...), description="...")`. Add `@model_validator(mode="after")` method `coalescing_requires_queue_enabled`: if `self.coalescing` and `self.coalescing.enabled`, require `self.queue_manager` and `self.queue_manager.enabled`, else raise `ValueError("coalescing requires queue_manager.enabled to be true")`. |
| **scripts/generate_configs.py** | **CHANGE** | In `_get_template_config()` dict, after the `"queue_manager"` key and before `"embedding"`, add key `"coalescing"` with value `{"enabled": False, "coalescing_window_sec": 0.03, "coalescing_max_texts": 64, "coalescing_max_wait_sec": 0.1}`. |
| **scripts/validate_all_configs.py** | **CHANGE** | In `validate_json_structure()`: (1) Optionally add `"security"` to required_sections or validate security when present (Phase 2: if `"security"` in config and has `"mode"`, validate mode in http/https/mtls and cert/key/ca). (2) After queue_manager block, add block: if `"coalescing"` in config_data, validate `enabled` is bool; `coalescing_window_sec` is number > 0; `coalescing_max_texts` is int > 0; `coalescing_max_wait_sec` if present is number >= 0. (3) Phase 4: if `config_data["coalescing"].get("enabled") is True`, require `"queue_manager"` in config_data and `config_data["queue_manager"].get("enabled") is True`, else append error `"coalescing requires queue_manager.enabled to be true"`. |
| **scripts/test_config_validation.py** | **CHANGE** | In `validate_config_structure()`: same coalescing validation as in validate_all_configs (coalescing section types/bounds, Phase 4 cross-check). Add embedding timing validation when timing_registration true (timing_file non-empty string, timing_file_max_bytes positive int when set). |
| **tests/test_config_validation.py** | **CHANGE** | In `validate_json_structure()`: add same coalescing validation (enabled, window_sec, max_texts, max_wait_sec types/bounds; Phase 4: coalescing.enabled true ⇒ queue_manager.enabled true). **ADD** three test methods: `test_coalescing_requires_queue_enabled` (config with coalescing.enabled true and queue_manager.enabled false must produce validation error); `test_coalescing_section_valid` (valid coalescing section passes); `test_coalescing_invalid_values` (coalescing_window_sec < 0 or coalescing_max_texts == 0 produce errors). |
| **tests/unit/test_coalescing_config.py** | **ADD** | New file. Tests: `CoalescingConfig` defaults; valid custom values; invalid window_sec/max_texts/max_wait_sec raise ValidationError. `ConfigModel` without coalescing key yields default CoalescingConfig (enabled=False); with coalescing section parses correctly; coalescing.enabled true + queue_manager.enabled false raises. Optional: `ConfigManager.load_from_dict` with/without coalescing. Module docstring with Author/email. |

## Deliverables

- `CoalescingConfig` class with the four fields and defaults as above.
- `ConfigModel` (or main config) extended with `coalescing: Optional[CoalescingConfig]`.
- **Generator:** `scripts/generate_configs.py` template includes `coalescing` with defaults.
- **Validators:** `scripts/validate_all_configs.py`, `scripts/test_config_validation.py`, `tests/test_config_validation.py` validate optional `coalescing` section when present.
- No behaviour change yet: no code reads this config in this step.

## End of step: code_mapper

After all code changes and tests, run the project’s **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

The step is complete only when all of the following hold.

### Step-specific

- `CoalescingConfig` class exists with fields: `enabled`, `coalescing_window_sec`, `coalescing_max_texts`, `coalescing_max_wait_sec` and defaults as specified.
- `ConfigModel` has `coalescing: Optional[CoalescingConfig]` with default (enabled=False).
- Config without `coalescing` section loads without error and yields default CoalescingConfig (enabled=False).
- Config with `"coalescing": {"enabled": true, "coalescing_window_sec": 0.05, ...}` loads and validates.
- Generated configs (from `scripts/generate_configs.py`) include `coalescing` section with defaults; validation scripts accept valid `coalescing` and reject invalid values (e.g. negative window_sec).

### Static checks (zero errors, project-wide)

- **black:** Run from project root (e.g. `black embed/ tests/`); no formatting errors.
- **mypy:** Run from project root (e.g. `mypy embed/` or project’s mypy config). There must be **no** mypy errors in the project; fix any errors even if not in files changed in this step.
- **flake8:** Run from project root (e.g. `flake8 embed/` or project’s flake8 config). There must be **no** flake8 errors; fix all reported errors.
- **code_mapper:** Run the project’s code_mapper command. It must complete **without errors**; indices in `code_analysis/` must be updated. Fix any code_mapper-reported issues.

### All tests passing

- Run the **full** test suite (e.g. `pytest tests/` or the project’s standard test command). **All** tests must pass, not only config-related ones. Fix any failing test before considering the step done.

### Real server test

- At least one test or script must run against a **real running server**: start the embedding service on a **different port** (e.g. 8001) with **hypercorn**, run a minimal check (e.g. load config that includes optional `coalescing` section and start server, then health or config endpoint), then stop the server. Start and stop must be done programmatically in the test or script (no manual only). If the project already has a “start server on alternate port and run test” pattern, use it and ensure one such run includes config that has a `coalescing` section.

### Step-specific tests

- **Unit:** Tests that load `ConfigModel` with and without `coalescing` and assert default or parsed values (e.g. in `tests/unit/test_config_manager.py` or new `tests/unit/test_coalescing_config.py`).
- **Integration:** Optional for step 1; if there is an existing “start server with config file” test, add or run one that uses a config file containing a `coalescing` block and assert server starts and responds (e.g. health).

### Test refactoring

- **tests/test_config_validation.py:** Add coalescing validation and cross-check tests; ensure `validate_json_structure()` validates optional `coalescing` when present. Keep example/main config tests passing.
- **tests/unit/test_coalescing_config.py:** Add unit tests for `CoalescingConfig` and `ConfigModel` with/without coalescing; test coalescing.enabled ⇒ queue_manager.enabled.
- **tests/test_http_endpoints.py**, **test_basic_mode.py**, **test_single_config.py:** If they load configs with embedding/queue, ensure configs have valid coalescing or omit (default off).
- **Coverage:** See “Coverage (per file, project-wide)” below.

### Coverage (per file, project-wide)

- **Upon completion of the step**, each file of the project (existing and new) must have coverage **≥ 90%**. Run e.g. `pytest --cov=embed --cov-report=term-missing`; add or fix tests so that no project file is below 90% when the step is done.

### Commit after step (mandatory)

- After the step is complete and the completion metric is satisfied, **commit** (e.g. `git add ... && git commit -m "Step 1: coalescing config schema"`). **Mandatory.** Push only on request.
