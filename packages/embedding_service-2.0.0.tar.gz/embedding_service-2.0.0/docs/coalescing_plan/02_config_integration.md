# Step 2: Coalescing config integration in ConfigManager

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §4.4 (Configuration, getter for coalescing).
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric.
- **Previous step:** [01_config_schema.md](01_config_schema.md) — `CoalescingConfig`, `ConfigModel.coalescing`.
- **Code:** `embed/config/config_manager.py` — `ConfigManager`, `get_queue_manager_config()`; add `get_coalescing_config()` in the same style; `create_default_config()` if present.

---

## Goal

Expose coalescing configuration to the rest of the application via ConfigManager. No coalescing logic yet; only config access.

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **embed/config/config_manager.py** | **CHANGE** | Add method `get_coalescing_config(self) -> Optional[CoalescingConfig]`: if not `self._loaded` or `self.config is None` raise `ValueError("No configuration loaded")`; return `self.config.coalescing`. Add parameter `coalescing=CoalescingConfig(enabled=False, coalescing_window_sec=0.03, coalescing_max_texts=64, coalescing_max_wait_sec=0.1)` to the `ConfigModel(...)` call inside `create_default_config()` (so default config includes coalescing with safe defaults). |
| **embed/config/test_config_manager.py** | **CHANGE** | In tests that build config dict, optionally add `"coalescing": {"enabled": False, ...}` so load_from_dict does not rely on default only. Add or extend test: after `create_default_config()` or `load_from_dict(...)`, assert `config.coalescing` is not None and `config.coalescing.enabled is False`. If ConfigManager exposes get_coalescing_config, add test that it returns the same as config.coalescing. |
| **tests/unit/test_coalescing_config.py** | **CHANGE** | Add test class or methods: (1) `ConfigManager().load_from_dict(minimal_config)` then assert `manager.get_config().coalescing` is not None and has expected defaults. (2) Load dict with `"coalescing": {"enabled": False, "coalescing_window_sec": 0.05, ...}` and assert `get_coalescing_config()` returns matching values. (3) Test that `create_default_config()` result includes `coalescing` with `enabled=False`. |

## Prerequisites

- Step 1 done: `CoalescingConfig` and `ConfigModel.coalescing` exist.

## Tasks

1. **Add getter in ConfigManager.**
   - **File:** `embed/config/config_manager.py`.
   - **Method:** `get_coalescing_config(self) -> Optional[CoalescingConfig]`.
   - Return `self.config.coalescing` when config is loaded; return `None` or a default (enabled=False) when no config / no coalescing section, consistently with existing getters (e.g. `get_queue_manager_config`).

2. **Default in create_default_config (mandatory).**
   - **File:** `embed/config/config_manager.py`. The method `create_default_config()` explicitly constructs `ConfigModel(...)` with every section. Add `coalescing=CoalescingConfig(enabled=False, coalescing_window_sec=0.03, coalescing_max_texts=64, coalescing_max_wait_sec=0.1)` (or equivalent) so that the default config includes coalescing with safe defaults. This is required for consistency with step 1; the generator in `scripts/generate_configs.py` was already updated in step 1.

3. **Document in config comments / schema (optional).**
   - If there is generated or static config documentation, add a short note that `coalescing` controls request batching for the embed command and refer to COALESCING_ANALYSIS.md.

## Deliverables

- `ConfigManager.get_coalescing_config()` implemented.
- `create_default_config()` in `embed/config/config_manager.py` includes `coalescing` with safe defaults (step 1 already updated the script generator; ConfigManager default must match).
- No new behaviour: no component calls this getter in this step.

## End of step: code_mapper

After all code changes and tests, run the project’s **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

The step is complete only when all of the following hold.

### Step-specific

- `ConfigManager.get_coalescing_config()` implemented; returns `self.config.coalescing` when config is loaded; returns default (enabled=False) or None when no coalescing section, consistent with e.g. `get_queue_manager_config`.
- Default config (if `create_default_config` exists) includes `coalescing` with safe defaults.

### Static checks (zero errors, project-wide)

- **black:** No formatting errors (run black on project).
- **mypy:** No errors in the project; fix any errors even if not in files changed in this step.
- **flake8:** No errors in the project; fix all reported errors.
- **code_mapper:** Run code_mapper; it must complete without errors; indices updated.

### All tests passing

- Run the **full** test suite. **All** tests must pass, not only step 2 tests.

### Real server test

- At least one test runs against a **real running server** on a **different port** (e.g. 8001): start server with **hypercorn** (e.g. with config that has `coalescing`), call an endpoint that indirectly uses config (e.g. health or a command that reads `get_coalescing_config()`), then stop the server. Start/stop programmatic.

### Step-specific tests

- **Unit:** Tests that load config with and without `coalescing` and assert `get_coalescing_config()` returns expected type and values (e.g. default enabled=False, or parsed values when section present).
- **Integration:** If applicable, test that a running server can serve a request that depends on config (e.g. embed with coalescing disabled); server started on alternate port, then stopped after test.

### Test refactoring

- **tests/unit/test_coalescing_config.py:** Add tests for `ConfigManager.get_coalescing_config()` (returns default when no coalescing section, returns parsed values when section present); test `create_default_config()` includes coalescing with safe defaults.
- **embed/config/test_config_manager.py:** Ensure `create_default_config()` and `load_from_dict()` with/without `coalescing` key pass; add or extend assertions for `get_coalescing_config()` if present.
- **tests/conftest.py:** No change required for step 2; fixture config may omit coalescing (default off).

### Coverage (per file, project-wide)

- **Upon completion of the step**, each file of the project (existing and new) must have coverage **≥ 90%**. Run e.g. `pytest --cov=embed --cov-report=term-missing`; add or fix tests so that no project file is below 90% when the step is done.

### Commit after step (mandatory)

- After the step is complete and the completion metric is satisfied, **commit** (e.g. `git add ... && git commit -m "Step 2: config integration get_coalescing_config"`). **Mandatory.** Push only on request.
