# Step 3: Logical job store

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §4.1 (logical job IDs, store: logical_job_id -> (physical_job_id, start_index, count), set_physical_result).
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric.
- **Code:** New module e.g. `embed/coalescing/logical_job_store.py` (or `embed/queue/coalescing_store.py`). Result shape from `embed/commands/embed_command.py`: SuccessResult `data` has `embeddings`, `results`, `model`, `dimension`, `device`.

---

## Goal

Implement a store that maps logical job IDs (returned to clients) to physical job ID and slice information, and holds full result for a physical job when it completes. Used by the coalescer (submit, completion) and by embed_job_status (resolution).

## Prerequisites

- None (standalone component).

## Tasks

1. **Define data structures.**
   - **Logical job entry:** For each logical job we need at least:
     - `logical_job_id: str` (generated, unique).
     - `physical_job_id: str` (queue’s job_id for the batch).
     - `start_index: int` — start index in the merged result list for this request’s slice.
     - `count: int` — number of texts (length of slice).
     - Optional: `created_at` for TTL/cleanup.
   - **Physical job result:** When a physical job completes we need to store:
     - `physical_job_id: str`
     - Full result dict (e.g. `data` from SuccessResult: `embeddings`, `results`, `model`, `dimension`, `device`).
     - Optional: `error` if the batch failed (then all logical jobs in that batch get the same error).

2. **Implement store API (single module or class).**
   - **File:** e.g. `embed/coalescing/logical_job_store.py` (or `embed/queue/coalescing_store.py` — choose one place and keep it).
   - **Operations:**
     - `register_logical_jobs(physical_job_id: str, slices: List[Tuple[int, int]]) -> List[str]`  
       Registers N logical jobs for one physical job; `slices` is a list of `(start_index, count)` per logical job. Returns list of N logical_job_ids (generated UUIDs or unique strings). Thread-safe / async-safe if the app uses async.
     - `get_logical_job(logical_job_id: str) -> Optional[LogicalJobEntry]`  
       Returns the entry (physical_job_id, start_index, count) or None if unknown.
     - `set_physical_result(physical_job_id: str, result: Dict[str, Any]) -> None`  
       Stores the full result for the physical job (success).
     - `set_physical_error(physical_job_id: str, error: Dict[str, Any]) -> None`  
       Stores error for the physical job (batch failed); logical jobs will expose this error.
     - `get_physical_result(physical_job_id: str) -> Optional[Dict[str, Any]]`  
       Returns stored result or None if not yet completed.
     - `get_physical_error(physical_job_id: str) -> Optional[Dict[str, Any]]`  
       Returns stored error or None.
   - **Storage:** In-memory dict(s) keyed by logical_job_id and physical_job_id. **Deferred:** TTL/cleanup for logical job metadata (see COALESCING_ANALYSIS §5 Open points and plan 00_overview “Deferred / open points”); for this step a simple in-memory implementation is enough. Document that retention/TTL can be added later (e.g. align with `completed_job_retention_seconds`).

3. **Thread/async safety.**
   - Ensure the store is safe for concurrent access (e.g. one writer from coalescer completion, multiple readers from embed_job_status). Use locks or a thread-safe structure as appropriate for the rest of the app (asyncio vs threads).

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **embed/coalescing/__init__.py** | **ADD** | New package. Export `LogicalJobStore`, `LogicalJobEntry` (if a named tuple or dataclass), and optionally `register_logical_jobs`, `get_logical_job`, etc. if they are module-level functions. Minimal content: docstring (Author/email), `from embed.coalescing.logical_job_store import LogicalJobStore, ...`. |
| **embed/coalescing/logical_job_store.py** | **ADD** | New module. Define `LogicalJobEntry` (e.g. dataclass or NamedTuple) with `logical_job_id: str`, `physical_job_id: str`, `start_index: int`, `count: int`. Define class `LogicalJobStore` (or singleton/get_instance if preferred): in-memory dicts `_logical: Dict[str, LogicalJobEntry]`, `_physical_results: Dict[str, Dict]`, `_physical_errors: Dict[str, Dict]`; use `threading.Lock()` or `asyncio.Lock()` for concurrent access. Implement: `register_logical_jobs(physical_job_id: str, slices: List[Tuple[int, int]]) -> List[str]` (generate UUID per slice, store entry, return list of logical_job_ids in order); `get_logical_job(logical_job_id: str) -> Optional[LogicalJobEntry]`; `set_physical_result(physical_job_id: str, result: Dict[str, Any]) -> None`; `set_physical_error(physical_job_id: str, error: Dict[str, Any]) -> None`; `get_physical_result(physical_job_id: str) -> Optional[Dict[str, Any]]`; `get_physical_error(physical_job_id: str) -> Optional[Dict[str, Any]]`. Docstrings for module and each function/class. |
| **tests/unit/test_logical_job_store.py** | **ADD** | New file. Tests: register_logical_jobs(physical_id, [(0,2), (2,3)]) returns list of 2 UUIDs; get_logical_job for each returns correct (physical_id, start_index, count); set_physical_result(physical_id, full_result); get_physical_result returns it; get_physical_error returns None. set_physical_error(physical_id, err); get_physical_error returns err; get_physical_result returns None or previous. Concurrent access test if applicable. Module docstring Author/email. |

## Deliverables

- New module with `LogicalJobStore` (or equivalent) and the operations above.
- Clear docstrings: purpose, parameters, return values, and that it is used for coalescing logical/physical job mapping.

## End of step: code_mapper

After all code changes and tests, run the project’s **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

The step is complete only when all of the following hold.

### Step-specific

- Store module with `LogicalJobStore` (or equivalent) and API: `register_logical_jobs`, `get_logical_job`, `set_physical_result`, `set_physical_error`, `get_physical_result`, `get_physical_error`.
- Thread- or async-safe for concurrent access.
- Unit tests: register N logical jobs for one physical job; set physical result/error; get_logical_job and get_physical_result/get_physical_error return correct data.

### Static checks (zero errors, project-wide)

- **black:** No formatting errors (run black on project).
- **mypy:** No errors in the project; fix any errors even if not in files changed in this step.
- **flake8:** No errors; fix all reported errors.
- **code_mapper:** Run code_mapper; complete without errors; indices updated.

### All tests passing

- Run the **full** test suite. **All** tests must pass.

### Real server test

- At least one test runs against a **real running server** on a **different port**: start server with **hypercorn**, run a minimal flow (e.g. health or one embed request) to ensure the new module does not break startup or request handling, then stop the server. Start/stop programmatic.

### Step-specific tests

- **Unit:** register_logical_jobs(physical_id, [(0,2), (2,3)]) returns two logical_job_ids; get_logical_job for each returns correct (physical_id, start_index, count); set_physical_result / get_physical_result; set_physical_error / get_physical_error; idempotency if applicable.
- **Integration:** Optional for step 3: if the store is injectable or used by a test harness, integration test that submits a “fake” physical result and resolves logical jobs (or defer to step 8).

### Test refactoring

- **New unit tests** in e.g. `tests/unit/test_logical_job_store.py`: cover all store API (register, get, set_physical_result/error, get_physical_result/error); concurrent access if applicable.
- **tests/unit/test_commands.py:** No change in step 3; EmbedJobStatusCommand tests that depend on store are refactored in step 8.
### Coverage (per file, project-wide)

- **Upon completion of the step**, each file of the project (existing and new) must have coverage **≥ 90%**. Run e.g. `pytest --cov=embed --cov-report=term-missing`; add or fix tests so that no project file is below 90% when the step is done.

### Commit after step (mandatory)

- After the step is complete, **commit** (e.g. `git add ... && git commit -m "Step 3: logical job store"`). **Mandatory.** Push only on request.
