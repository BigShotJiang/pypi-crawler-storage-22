# Step 4: Coalescer buffer and accumulation logic

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §3 (accumulation, time window, max batch size), §4.5 (batch homogeneity: model, dimension, error_policy, device).
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric.
- **Previous steps:** [02_config_integration.md](02_config_integration.md) (get_coalescing_config), [03_logical_job_store.md](03_logical_job_store.md) (store; this step only produces BatchDescriptor, no store calls).
- **Code:** `embed/config/config_manager.py` (get_coalescing_config); new module e.g. `embed/coalescing/coalescer_buffer.py` or `embed/coalescing/coalescer.py`.

---

## Goal

Implement the accumulation logic: collect incoming embed requests in a buffer, with time window and max-texts limits, and group only requests that are homogeneous (same model, dimension, error_policy, device).

## Prerequisites

- Step 2: `get_coalescing_config()` available.
- Step 3: logical job store exists (used in next steps; this step only produces “ready batch” data).

## Tasks

1. **Define buffer entry.**
   - For each buffered request store: `texts`, `model`, `dimension`, `error_policy`, `device`, and a way to identify the “logical request” (e.g. future/callback or placeholder for logical_job_id to be filled at submit time). Optional: request_id or creation time for max_wait_sec.

2. **Implement buffer / bucket by homogeneity key.**
   - **File:** e.g. `embed/coalescing/coalescer_buffer.py` or part of a single `Coalescer` class in `embed/coalescing/coalescer.py`.
   - **Homogeneity key:** `(model, dimension, error_policy, device)`. Only requests with the same key can be merged into one batch.
   - **Operations:**
     - `add_request(texts, model, dimension, error_policy, device, ...) -> Optional[BatchDescriptor]`  
       Add one request to the buffer. Flush (return a `BatchDescriptor`) when: (a) total texts >= coalescing_max_texts, or (b) buffer has exactly one request — **flush immediately**, no delay (coalescing is for speed), or (c) buffer has 2+ requests and the time window (window_sec) has elapsed, or (d) optional: oldest request has waited > max_wait_sec. Otherwise return None.
     - **On flush:** take from the buffer the **maximum possible number of texts** within `coalescing_max_texts`: drain requests in order, **whole requests only** (do not split a request across batches), until the next request would exceed the limit or the buffer is empty. So each batch is as large as the limit allows.
     - No artificial delay: one request → flush immediately (batch of 1); window is only to merge near-simultaneous requests.
   - **BatchDescriptor:** Immutable value object: merged `texts` (list), list of per-request `(num_texts,)` for slice metadata, and homogeneity key. No job_ids yet; those are assigned at submit (step 6).

3. **Config.**
   - Read coalescing config (window_sec, max_texts, max_wait_sec) from ConfigManager at start or per flush. Use defaults if config is disabled or missing.

4. **Thread/async safety.**
   - Buffer may be accessed from multiple concurrent embed requests. Use locks or async-safe structures so that add_request and timer callbacks do not corrupt the buffer.

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **embed/coalescing/coalescer_buffer.py** | **ADD** | New module (or add to existing coalescing package). Define `BatchDescriptor` (dataclass or NamedTuple): `merged_texts: List[str]`, `counts: List[int]` (per-request text counts), `key: Tuple` (model, dimension, error_policy, device). Define class `CoalescerBuffer`: __init__(self, window_sec, max_texts, max_wait_sec optional) from config or defaults; internal buffer per homogeneity key: e.g. `_buckets: Dict[Tuple, List[BufferEntry]]` where BufferEntry has texts, model, dimension, error_policy, device, timestamp. Method `add_request(texts, model, dimension, error_policy, device) -> Optional[BatchDescriptor]`: compute key, append entry; if total texts >= max_texts, or current bucket has 1 request (flush immediately), or bucket has 2+ and oldest entry older than window_sec (or max_wait_sec), then drain bucket (whole requests only, up to max_texts), build BatchDescriptor(merged_texts, counts, key), return it; else return None. Use Lock for thread safety. Docstrings Author/email. |
| **embed/coalescing/__init__.py** | **CHANGE** | Add exports for `CoalescerBuffer`, `BatchDescriptor` from coalescer_buffer. |
| **tests/unit/test_coalescer_buffer.py** | **ADD** | New file. Tests: add_request with same key, trigger flush by max_texts or window; returned BatchDescriptor has correct merged_texts length and counts; add_request with different key goes to different bucket; single request flushes immediately (BatchDescriptor of 1). Module docstring Author/email. |

## Deliverables

- Buffer implementation that groups by (model, dimension, error_policy, device).
- Flush conditions: total texts >= max_texts, or single request (flush immediately), or 2+ requests and window_sec elapsed (and optionally max_wait_sec for oldest). No delay for a single request.
- When flushing: take from the buffer the **maximum possible number of texts** (whole requests only, in order) up to max_texts; do not split a request across batches.
- Output: BatchDescriptor with merged texts and slice counts (and key). No queue or store calls in this step; only “produce a batch when ready.”

## End of step: code_mapper

After all code changes and tests, run the project’s **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

The step is complete only when all of the following hold.

### Step-specific

- Buffer groups by (model, dimension, error_policy, device). Flush: (1) total texts >= max_texts, (2) single request → flush immediately (no delay), (3) 2+ requests and window_sec elapsed (and optionally max_wait_sec). On flush: take from buffer the maximum possible number of texts (whole requests only, in order) up to max_texts.
- BatchDescriptor with merged texts, slice counts, homogeneity key.
- No queue or store calls in this step.

### Static checks (zero errors, project-wide)

- **black:** No formatting errors (run black on project).
- **mypy:** No errors in the project; fix any errors even if not in files changed in this step.
- **flake8:** No errors; fix all reported errors.
- **code_mapper:** Run code_mapper; complete without errors; indices updated.

### All tests passing

- Run the **full** test suite. **All** tests must pass.

### Real server test

- At least one test runs against a **real running server** on a **different port**: start server with **hypercorn** (with coalescing enabled or disabled), run a minimal flow to ensure buffer/coalescer code does not break startup, then stop the server. Start/stop programmatic.

### Step-specific tests

- **Unit:** Add N requests with same key; when window or max_texts triggers, get one BatchDescriptor with correct merged texts and list of counts; add requests with different key -> separate buckets, no mixing.
- **Integration:** Optional: run server, send several embed requests (same key) in quick succession and assert they are buffered / batch formed (e.g. by observing one physical job if step 6 is done, or by mocking submit).

### Test refactoring

- **New unit tests** in e.g. `tests/unit/test_coalescer_buffer.py`: buffer add/flush, BatchDescriptor shape, homogeneity keys, window/max_texts/max_wait triggers.
### Coverage (per file, project-wide)

- **Upon completion of the step**, each file of the project (existing and new) must have coverage **≥ 90%**. Run e.g. `pytest --cov=embed --cov-report=term-missing`; add or fix tests so that no project file is below 90% when the step is done.

### Commit after step (mandatory)

- After the step is complete, **commit** (e.g. `git add ... && git commit -m "Step 4: coalescer buffer"`). **Mandatory.** Push only on request.
