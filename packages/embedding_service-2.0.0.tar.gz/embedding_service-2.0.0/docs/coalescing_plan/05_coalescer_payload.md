# Step 5: Build merged payload and slice metadata

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §4.1 (merged payload, _coalesced_slices), §4.7 (mapping and splitting).
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric.
- **Previous steps:** [04_coalescer_buffer.md](04_coalescer_buffer.md) (BatchDescriptor).
- **Code:** `embed/commands/embed_command.py` — EmbedCommand.validate_params, execute(**kwargs) (texts, model, dimension, error_policy, device); payload must be valid for execute() and may include _coalesced_slices (ignored or stripped in validate_params).

---

## Goal

From a BatchDescriptor (merged texts + slice counts + homogeneity key), build the exact payload that will be submitted as one queue job. This payload must be acceptable to the existing EmbedCommand.execute() and contain internal metadata for slicing the result later.

## Prerequisites

- Step 4: BatchDescriptor with merged texts, list of counts per request, and (model, dimension, error_policy, device).

## Tasks

1. **Payload shape.**
   - The queue job’s params must be the same as what EmbedCommand.execute(**kwargs) expects, so that the worker runs one embed call without special cases. Required keys: `texts` (list of str), optional `model`, `dimension`, `error_policy`, `device`.
   - **Merged payload:**
     - `texts`: merged list of all texts (from BatchDescriptor).
     - `model`, `dimension`, `error_policy`, `device`: from the homogeneity key (same for all requests in the batch).
     - **Internal slice metadata:** Add a key that the coalescer uses for distribution but that EmbedCommand does not need to interpret (e.g. `_coalesced_slices: [n1, n2, ...]` where n_i is the number of texts for the i-th logical request). EmbedCommand.execute() can ignore this key; it just returns one result with len(results) == len(texts). The completion handler (step 7) will use `_coalesced_slices` to split the result.

2. **Implement payload builder.**
   - **File:** same as step 4 or 6 (e.g. inside Coalescer).
   - **Function or method:** `build_batch_payload(descriptor: BatchDescriptor) -> Dict[str, Any]`.
   - Returns the dict to be passed as the single job’s params (including `_coalesced_slices`). Do not include any keys that EmbedCommand.validate_params() would reject; if needed, document that EmbedCommand must ignore or allow `_coalesced_slices` (e.g. strip it in validate_params or leave it as optional extra).

3. **EmbedCommand contract.**
   - Ensure EmbedCommand.execute() does not require changes: it receives `texts`, model, dimension, error_policy, device, and optionally `_coalesced_slices`. It must only use `texts` and the embed params; it can ignore `_coalesced_slices`. If validate_params is strict, add a single line to strip or allow `_coalesced_slices` so the job payload is valid.

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **embed/coalescing/coalescer_buffer.py** or **embed/coalescing/payload_builder.py** | **ADD** (or **CHANGE**) | Add function `build_batch_payload(descriptor: BatchDescriptor) -> Dict[str, Any]`: return dict with `texts=descriptor.merged_texts`, `model`, `dimension`, `error_policy`, `device` from descriptor.key, and `_coalesced_slices=descriptor.counts`. Ensure sum(descriptor.counts) == len(descriptor.merged_texts). |
| **embed/commands/embed_command.py** | **CHANGE** (optional) | In `validate_params()`, after normalizing params, if strict schema rejects unknown keys: strip or allow `_coalesced_slices` (e.g. `params.pop("_coalesced_slices", None)` so it is not passed to base validation, or add to allowed extra). Ensure execute() does not depend on _coalesced_slices (it already uses only texts and embed params). |
| **embed/coalescing/__init__.py** | **CHANGE** | Export `build_batch_payload` if in separate module. |
| **tests/unit/test_coalescer_payload.py** | **ADD** | New file. Tests: build_batch_payload(descriptor) returns dict with texts, _coalesced_slices, key fields; len(texts)==sum(_coalesced_slices); EmbedCommand.validate_params(build_batch_payload(descriptor)) does not raise. Module docstring Author/email. |

## Deliverables

- `build_batch_payload(descriptor)` returning the job params dict.
- Slice metadata `_coalesced_slices` present and consistent with BatchDescriptor (list of counts; sum equals len(texts)).
- No queue submission in this step; only payload construction.

## End of step: code_mapper

After all code changes and tests, run the project’s **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

The step is complete only when all of the following hold.

### Step-specific

- `build_batch_payload(descriptor)` returns params dict with `texts`, `_coalesced_slices`, and homogeneity key fields; sum(_coalesced_slices) == len(texts).
- EmbedCommand.validate_params(build_batch_payload(descriptor)) does not raise (allow or strip _coalesced_slices if needed).

### Static checks (zero errors, project-wide)

- **black:** No formatting errors (run black on project).
- **mypy:** No errors in the project; fix any errors even if not in files changed in this step.
- **flake8:** No errors; fix all reported errors.
- **code_mapper:** Run code_mapper; complete without errors; indices updated.

### All tests passing

- Run the **full** test suite. **All** tests must pass.

### Real server test

- At least one test runs against a **real running server** on a **different port**: start server with **hypercorn**, run a request that could use a batch payload (e.g. embed with multiple texts) to ensure EmbedCommand still accepts params, then stop the server. Start/stop programmatic.

### Step-specific tests

- **Unit:** Given BatchDescriptor with merged texts length M and counts [c1, c2, ...] (sum=M), build_batch_payload yields params with len(params["texts"])==M and params["_coalesced_slices"]==[c1, c2, ...]; validate_params does not raise.
- **Integration:** Optional: run server, submit one job with payload built by build_batch_payload (e.g. via queue or test client) and assert job completes successfully.

### Test refactoring

- **New unit tests** in e.g. `tests/unit/test_coalescer_payload.py`: build_batch_payload(descriptor) shape, _coalesced_slices sum, EmbedCommand.validate_params acceptance.
### Coverage (per file, project-wide)

- **Upon completion of the step**, each file of the project (existing and new) must have coverage **≥ 90%**. Run e.g. `pytest --cov=embed --cov-report=term-missing`; add or fix tests so that no project file is below 90% when the step is done.

### Commit after step (mandatory)

- After the step is complete, **commit** (e.g. `git add ... && git commit -m "Step 5: coalescer payload"`). **Mandatory.** Push only on request.
