# Step 6: Submit one batch job to queue and register logical jobs

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §3 (submit one batch job), §3.1 (queue distribution, max_concurrent_jobs), §4.1 (register logical jobs, return logical_job_id per request).
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric.
- **Previous steps:** [03_logical_job_store.md](03_logical_job_store.md) (register_logical_jobs), [05_coalescer_payload.md](05_coalescer_payload.md) (build_batch_payload), [04_coalescer_buffer.md](04_coalescer_buffer.md) (BatchDescriptor).
- **Code:** `embed/main.py` (initialize_queue_manager, adapter); mcp_proxy_adapter queue submit API (document or discover how to submit job and get physical job_id); `embed/coalescing/` (coalescer that calls store and queue).

---

## Goal

When the buffer produces a batch (BatchDescriptor), build the payload, submit a single job to the adapter’s queue, register all logical jobs in the store with the physical job_id and slice indices, and return a logical job_id to each original request (or to the component that will respond to the N clients).

## Prerequisites

- Step 3: logical job store with `register_logical_jobs(physical_job_id, slices)` returning list of logical_job_ids.
- Step 5: `build_batch_payload(descriptor)`.
- Adapter queue API: ability to submit a job with command name and params and get back a physical `job_id` (exact API depends on mcp_proxy_adapter; this step describes the intended behaviour).

## Tasks

1. **Compute slices from BatchDescriptor.**
   - From the list of counts `[n1, n2, ...]` compute `slices = [(start_i, count_i)]` where start_i is the cumulative sum of n1..n_{i-1} and count_i = n_i. Pass `slices` to the store’s `register_logical_jobs(physical_job_id, slices)`.

2. **Submit job to queue.**
   - Call the adapter’s queue submit API with:
     - Command: embed (or the same command name used for embed).
     - Params: result of `build_batch_payload(descriptor)`.
   - Obtain the physical `job_id` returned by the queue.

3. **Register logical jobs.**
   - Call `register_logical_jobs(physical_job_id, slices)` and obtain the list of logical_job_ids (one per request in the batch). Order must match the order of requests in the batch so that logical_job_id[i] corresponds to slice (start_i, count_i).

4. **Return logical job_id per request.**
   - The coalescer entry point (called for each of the N requests that formed the batch) must return the corresponding logical_job_id to each caller. So the component that added the N requests to the buffer must get back N responses (each with one logical_job_id). This may require: (a) the coalescer to return a list of logical_job_ids when it flushes, and the routing layer (step 9) to match them back to the N waiting requests by order or by a temporary token; or (b) each of the N requests to be associated with a position in the batch when they are added, and when the batch is submitted, each is resolved to its logical_job_id. Design choice: keep a clear mapping “position in batch i -> logical_job_id[i]” and ensure the N callers receive their job_ids in the same order they were added.

5. **Error handling.**
   - If queue submit fails, do not call register_logical_jobs; report failure to all N waiting requests (same error for each). Optionally retry or surface a single “batch submit failed” error.

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **embed/coalescing/coalescer_submit.py** (or extend coalescer module) | **ADD** | New module or add to existing. Function or class method `submit_batch(descriptor: BatchDescriptor, store: LogicalJobStore) -> Tuple[List[str], Optional[Dict]]`: (1) Compute slices from descriptor.counts: `slices = [(sum(counts[:i]), counts[i]) for i in range(len(counts))]`. (2) Build payload via `build_batch_payload(descriptor)`. (3) Call adapter queue submit API (e.g. get queue manager from mcp_proxy_adapter, submit job with command "embed" and payload; obtain physical job_id). If submit raises or fails, return ([], error_dict). (4) Call `store.register_logical_jobs(physical_job_id, slices)` → list of logical_job_ids. (5) Return (logical_job_ids, None). Document in module/docstring the exact adapter call used. |
| **embed/coalescing/__init__.py** | **CHANGE** | Export `submit_batch` (or the class that holds it). |
| **embed/coalescing/coalescer.py** (optional facade) | **ADD** or **CHANGE** | If using a single Coalescer class: add method that on flush calls build_batch_payload, submit_batch, and returns the list of logical_job_ids (order matches N requests). Otherwise leave submit in coalescer_submit and have routing (step 9) call buffer + payload + submit. |
| **tests/unit/test_coalescer_submit.py** | **ADD** | Mock queue submit (return fixed physical_job_id), mock store.register_logical_jobs; call submit_batch with descriptor of 2 requests; assert submit called once with correct payload, register_logical_jobs called with physical_job_id and slices [(0,n1),(n1,n2)], return value is list of 2 logical_job_ids. Test submit failure: mock submit to raise; assert register_logical_jobs not called, return error. |

## Deliverables

- Coalescer (or dedicated “submit” function) that: given a BatchDescriptor, builds payload, submits one job, registers logical jobs, returns list of N logical_job_ids in order.
- Integration with adapter’s submit API (exact call depends on repo; document the assumed API or adapter interface used).

## End of step: code_mapper

After all code changes and tests, run the project’s **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

The step is complete only when all of the following hold.

### Step-specific

- Given BatchDescriptor: build payload, submit one job to queue, obtain physical_job_id; register_logical_jobs(physical_job_id, slices); return N logical_job_ids in order. On submit failure, do not register; report error to callers.
- Slices computed from BatchDescriptor counts (cumulative start_index, count per request).

### Static checks (zero errors, project-wide)

- **black:** No formatting errors (run black on project).
- **mypy:** No errors in the project; fix any errors even if not in files changed in this step.
- **flake8:** No errors; fix all reported errors.
- **code_mapper:** Run code_mapper; complete without errors; indices updated.

### All tests passing

- Run the **full** test suite. **All** tests must pass.

### Real server test

- At least one test runs against a **real running server** on a **different port**: start server with **hypercorn** (with coalescing enabled and queue enabled), trigger a batch flush (e.g. send N embed requests that get coalesced), verify one physical job is enqueued and N logical_job_ids returned, then stop the server. Start/stop programmatic.

### Step-specific tests

- **Unit:** Given a BatchDescriptor and mocked queue submit: submit called once with correct payload; register_logical_jobs called with correct slices; returned logical_job_ids count equals N; order matches slice order.
- **Integration:** Run server on alternate port; send multiple embed requests (same key) within window; assert response contains job_ids; assert store has N logical jobs for one physical_job_id (or assert via embed_job_status in step 8).

### Test refactoring

- **New unit tests** for submit path: mocked queue submit, register_logical_jobs, returned logical_job_ids count and order.
- **tests/unit/test_commands.py:** Ensure EmbedCommand tests that assume “one job” still pass (mock coalescing disabled or current path); prepare for step 09 routing.
- **tests/test_load_stress.py:** When run with coalescing (after step 09), ensure stress scenario still passes (multiple job_ids, each poll returns correct result/slice).
### Coverage (per file, project-wide)

- **Upon completion of the step**, each file of the project (existing and new) must have coverage **≥ 90%**. Run e.g. `pytest --cov=embed --cov-report=term-missing`; add or fix tests so that no project file is below 90% when the step is done.

### Commit after step (mandatory)

- After the step is complete, **commit** (e.g. `git add ... && git commit -m "Step 6: coalescer submit"`). **Mandatory.** Push only on request.
