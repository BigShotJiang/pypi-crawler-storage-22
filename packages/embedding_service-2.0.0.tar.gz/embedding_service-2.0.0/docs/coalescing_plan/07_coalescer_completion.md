# Step 7: On batch completion — distribute results and set status

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §3 (handler distributes response, sets status), §4.1 (resolve N logical jobs), §4.6 (error handling: batch fail -> same error for all).
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric.
- **Previous steps:** [03_logical_job_store.md](03_logical_job_store.md) (set_physical_result, set_physical_error), [06_coalescer_submit.md](06_coalescer_submit.md) (physical job submitted, logical jobs registered).
- **Code:** `embed/commands/embed_command.py` — SuccessResult `data` (embeddings, results, model, dimension, device); ErrorResult for batch failure; adapter queue completion callback or status API.

---

## Goal

When a physical (batch) job completes, the handler must: obtain the full result (or error), store it in the logical job store, and make the result available per logical job so that embed_job_status can return the correct slice (or error) for each logical job_id. Optionally: if the adapter supports a completion callback or a “job completed” hook, use it; otherwise this step may be implemented by “embed_job_status fetches physical job result and slices it” (lazy resolution). This step defines both options; choose one per adapter capabilities.

## Prerequisites

- Step 3: store has `set_physical_result`, `set_physical_error`, and logical job entries with (physical_job_id, start_index, count).
- Step 6: physical job was submitted and logical jobs registered.

## Tasks

1. **Obtain physical job result.**
   - When the physical job completes, the adapter typically stores the result under the physical job_id. Either:
     - **Option A (callback):** The queue or adapter calls a completion callback with (physical_job_id, result_or_error). In that callback: call set_physical_result(physical_job_id, result) or set_physical_error(physical_job_id, error). No polling.
     - **Option B (lazy):** There is no callback. Then “completion handling” is done inside embed_job_status: when a client polls a logical_job_id, we resolve to physical_job_id and (start_index, count); we ask the queue for the physical job status; if completed, we get the full result, store it once in the store (set_physical_result), then slice and return the slice for this logical job. Subsequent polls for other logical jobs in the same batch will find the result already in the store and only slice. So “distribute and set status” is implicit: we store the full result by physical_job_id and slice on read (step 8). Prefer Option B if the adapter does not expose a completion callback.

2. **Store full result or error.**
   - **Success:** Full result is the `data` dict from EmbedCommand’s SuccessResult: `embeddings`, `results`, `model`, `dimension`, `device`. Call `set_physical_result(physical_job_id, data)`.
   - **Failure:** If the batch job failed (exception or ErrorResult), call `set_physical_error(physical_job_id, error_dict)`. error_dict should have at least a message and optionally code/details so that embed_job_status can return an error for every logical job in that batch.

3. **No per-logical-job status in queue.**
   - The adapter’s queue has one status per physical job. We do not “set status” for each logical job inside the queue; we only store the physical result/error in our store. Each logical job’s “status” is derived in embed_job_status: if physical is pending -> logical is pending; if physical completed -> logical completed with sliced result; if physical failed -> logical failed with same error.

4. **Idempotency.**
   - If Option A is used and the callback can fire more than once, or if Option B stores the result on first read, ensure set_physical_result/set_physical_error are idempotent (overwrite is fine).

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **embed/coalescing/completion.py** or **embed/commands/embed_job_status_command.py** | **ADD** or **CHANGE** | **Option A (callback):** New module `embed/coalescing/completion.py`: function `on_physical_job_completed(physical_job_id: str, result: Dict[str, Any] | None, error: Dict[str, Any] | None, store: LogicalJobStore) -> None`. If result, call `store.set_physical_result(physical_job_id, result)`; if error, call `store.set_physical_error(physical_job_id, error)`. Register this callback with the adapter queue if it supports completion hooks (document where). **Option B (lazy):** No new completion module. In step 8, inside `embed_job_status_command.execute()`: when resolving logical → physical, if physical job is completed (from queue_get_job_status) and store does not yet have get_physical_result(physical_id), get full result from queue, call store.set_physical_result(physical_id, result), then slice and return. So this step is "implement Option B in step 8" or "add Option A here and document registration". |
| **embed/coalescing/__init__.py** | **CHANGE** | If Option A: export `on_physical_job_completed`. |
| **embed/main.py** (if Option A) | **CHANGE** | After queue manager init, register completion callback that calls on_physical_job_completed with store instance. (Only if adapter supports it.) |
| **tests/unit/test_coalescer_completion.py** or in store tests | **ADD** | Test: set_physical_result(physical_id, full_result); get_physical_result returns same; set_physical_error(physical_id, err); get_physical_error returns err. If Option A: test that callback invokes set_physical_result/set_physical_error correctly. |

## Deliverables

- Completion path implemented: either (A) callback that calls set_physical_result/set_physical_error, or (B) no separate completion step and distribution done on first embed_job_status read (step 8) with a one-time store of the full result.
- Document which option is used and how the adapter is integrated (callback registration vs lazy in status).

## End of step: code_mapper

After all code changes and tests, run the project’s **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

The step is complete only when all of the following hold.

### Step-specific

- Completion path implemented: either (A) callback that calls set_physical_result/set_physical_error when physical job completes, or (B) lazy: first embed_job_status read gets full result from queue, stores it, then slices. Document which option is used.
- Success: full result (embeddings, results, model, dimension, device) stored by physical_job_id. Failure: error dict stored by physical_job_id.

### Static checks (zero errors, project-wide)

- **black:** No formatting errors (run black on project).
- **mypy:** No errors in the project; fix any errors even if not in files changed in this step.
- **flake8:** No errors; fix all reported errors.
- **code_mapper:** Run code_mapper; complete without errors; indices updated.

### All tests passing

- Run the **full** test suite. **All** tests must pass.

### Real server test

- At least one test runs against a **real running server** on a **different port**: start server with **hypercorn**, submit a batch job (e.g. via coalescing path), wait for completion (or poll embed_job_status until completed), verify result is stored (e.g. all N logical jobs can resolve to sliced result or error), then stop the server. Start/stop programmatic.

### Step-specific tests

- **Unit:** With store and mocked queue result: when physical job “completes” (callback or simulated), set_physical_result called with correct data; get_physical_result returns it; or simulate first status read and assert set_physical_result called then slice returned.
- **Integration:** Run server; trigger one batch; after completion, poll embed_job_status for each logical_job_id and assert each gets correct slice (or same error if batch failed).

### Test refactoring

- **New unit tests** for completion path: set_physical_result/error, slice distribution (or lazy on first status read).
- **tests/test_load_stress.py:** After completion flow is wired, stress test (embed → job_id → poll) must pass; each logical_job_id resolves to correct slice.
### Coverage (per file, project-wide)

- **Upon completion of the step**, each file of the project (existing and new) must have coverage **≥ 90%**. Run e.g. `pytest --cov=embed --cov-report=term-missing`; add or fix tests so that no project file is below 90% when the step is done.

### Commit after step (mandatory)

- After the step is complete, **commit** (e.g. `git add ... && git commit -m "Step 7: coalescer completion"`). **Mandatory.** Push only on request.
