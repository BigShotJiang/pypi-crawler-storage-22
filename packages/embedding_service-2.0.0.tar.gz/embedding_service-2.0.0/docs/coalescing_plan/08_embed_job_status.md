# Step 8: Resolve logical job_id in embed_job_status

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §4.1 (embed_job_status resolves logical job_id, return pending or slice), §4.7 (slicing results/embeddings).
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric.
- **Previous steps:** [03_logical_job_store.md](03_logical_job_store.md) (get_logical_job, get_physical_result, get_physical_error), [07_coalescer_completion.md](07_coalescer_completion.md) (result/error stored).
- **Code:** `embed/commands/embed_job_status_command.py` — current execute(), delegation to queue_get_job_status; `embed/coalescing/logical_job_store.py` (or store module); adapter queue_get_job_status(physical_job_id).

---

## Goal

When a client calls embed_job_status(job_id), the server must recognize whether job_id is a logical job_id (issued by the coalescer) or a physical job_id (direct queue job, non-coalesced path). For logical job_id: resolve to (physical_job_id, start_index, count); then return either “pending” or the sliced result (or error) for that logical job. API response shape must match the current embed_job_status response so clients need no change.

## Prerequisites

- Step 3: store with get_logical_job, get_physical_result, get_physical_error.
- Step 7: physical results/errors are stored when batch completes (or on first read if lazy).

## Tasks

1. **Detect logical vs physical job_id.**
   - **Option A:** All coalescer-issued job_ids use a fixed prefix or format (e.g. UUID), and physical job_ids from the queue use another format. Then: if job_id looks like a logical id, try get_logical_job(job_id); if found, it’s logical; otherwise treat as physical (existing behaviour).
   - **Option B:** Always try get_logical_job(job_id) first; if not found, treat as physical and delegate to the existing queue_get_job_status (current embed_job_status behaviour). Prefer Option B so we don’t depend on format.

2. **Logical job_id resolution.**
   - Call `entry = get_logical_job(logical_job_id)`. If None, proceed with existing flow (physical job_id).
   - If entry exists: get physical_job_id, start_index, count.

3. **Physical job status.**
   - Query the queue for physical job status (adapter’s queue_get_job_status(physical_job_id)). If “pending” or “running”, return the same for the logical job (e.g. status: pending, no result).
   - If physical job “completed”: get full result. If not yet in our store (lazy path), call set_physical_result(physical_job_id, full_result); then get_physical_result(physical_job_id). Slice: result_slice = { "embeddings": full["embeddings"][start_index:start_index+count], "results": full["results"][start_index:start_index+count], "model": full["model"], "dimension": full["dimension"], "device": full["device"] }. Return this as the success result for the logical job.
   - If physical job “failed”: get error (or from store get_physical_error). If lazy: store error with set_physical_error once. Return the same error for this logical job (and for all others in the batch when they poll).

4. **Response shape.**
   - The response for a completed logical job must match what the client expects: same structure as a single-request embed result (embeddings list of length count, results list of length count, model, dimension, device). No extra fields that would break existing clients.

5. **File / entry point.**
   - Implement in `embed/commands/embed_job_status_command.py`: at the start of execute(), check logical job store; if logical, run the resolution above and return; otherwise delegate to existing queue_get_job_status as today.

## Deliverables

- embed_job_status: logical job_id -> pending or sliced result or error; physical job_id -> unchanged current behaviour.
- Same response schema for logical completed job as for a single embed job.

## End of step: code_mapper

After all code changes and tests, run the project’s **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

The step is complete only when all of the following hold.

### Step-specific

- embed_job_status: if job_id is logical (get_logical_job found), resolve to physical job; if physical pending -> return pending; if physical completed -> return sliced result (embeddings, results, model, dimension, device) or store result on first read (lazy) then slice; if physical failed -> return same error. If job_id not logical, delegate to existing queue_get_job_status (unchanged behaviour).
- Response shape for completed logical job matches single-request embed result (same schema).

### Static checks (zero errors, project-wide)

- **black:** No formatting errors (run black on project).
- **mypy:** No errors in the project; fix any errors even if not in files changed in this step.
- **flake8:** No errors; fix all reported errors.
- **code_mapper:** Run code_mapper; complete without errors; indices updated.

### All tests passing

- Run the **full** test suite. **All** tests must pass.

### Real server test

- At least one test runs against a **real running server** on a **different port**: start server with **hypercorn** (coalescing enabled), send embed requests to get logical_job_ids, poll embed_job_status for each logical_job_id until completed, assert response is sliced correctly (correct number of embeddings/results, correct content for that request’s texts); then stop the server. Also run one request with non-coalesced path (or coalescing disabled) and assert physical job_id still works via embed_job_status. Start/stop programmatic.

### Step-specific tests

- **Unit:** For logical_job_id with physical pending -> status “pending”; with physical result stored -> return slice of correct length and structure; with physical error stored -> return same error. For unknown job_id -> delegate to queue (mock).
- **Integration:** Run server on alternate port; coalescing path: multiple requests -> N logical_job_ids -> poll each -> each gets correct slice. Non-coalesced path: one request -> one job_id -> poll -> full result unchanged.

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **embed/commands/embed_job_status_command.py** | **CHANGE** | At start of `execute()`, after validating job_id: (1) Get logical job store (singleton or from app context). (2) Call `store.get_logical_job(job_id)`. If entry is found (logical job): (a) physical_id = entry.physical_job_id, start_index = entry.start_index, count = entry.count. (b) Check store.get_physical_error(physical_id); if present, return SuccessResult(data={..., "exists": True, "status": "failed", "done": True, "result": None or error payload}) or ErrorResult as appropriate so client sees failure. (c) Check store.get_physical_result(physical_id). If None: call queue_get_job_status(physical_id). If queue says pending/running, return SuccessResult(data={"exists": True, "status": "pending"/"running", "done": False}). If queue says completed: get full result from queue, call store.set_physical_result(physical_id, result), then slice. (d) Slice: result_slice = { "embeddings": result["embeddings"][start_index:start_index+count], "results": result["results"][start_index:start_index+count], "model": result["model"], "dimension": result["dimension"], "device": result.get("device") }. Return SuccessResult(data={"exists": True, "status": "completed", "done": True, "result": {"success": True, "data": result_slice}}). If get_logical_job returns None (physical job_id): delegate to current implementation (queue_manager, queue_get_job_status) and return its result unchanged. |
| **embed/main.py** or **embed/commands/embed_job_status_command.py** | **CHANGE** | Ensure LogicalJobStore is obtainable in embed_job_status_command (e.g. global singleton get_logical_job_store() in embed/coalescing/__init__.py, or inject via context). If store is created in main.py at startup, pass or register it so embed_job_status can access it. |
| **embed/coalescing/__init__.py** | **CHANGE** | Expose get_logical_job_store() or LogicalJobStore singleton so embed_job_status_command can import and use it. |
| **tests/unit/test_commands.py** | **CHANGE** | Add tests for EmbedJobStatusCommand with mocked store: logical_job_id with physical pending → status pending; with physical result stored → return sliced result (correct length); with physical error stored → return error; unknown job_id (not in store) → delegate to queue (mock queue_get_job_status). |
| **tests/test_error_handling.py** | **CHANGE** | Add or adjust test: embed_job_status with logical job_id that has physical error returns error to client. |

### Test refactoring

- **tests/unit/test_commands.py:** Add or refactor unit tests for EmbedJobStatusCommand: (1) job_id is logical and physical pending -> status “pending”; (2) job_id is logical and physical completed -> return sliced result (correct length/structure); (3) job_id is logical and physical failed -> return same error; (4) job_id not in store (physical only) -> delegate to queue_get_job_status (unchanged). Mock store and queue as needed.
- **tests/test_error_handling.py:** Add or adjust tests for embed_job_status: logical job not found / invalid job_id; physical job failed (error propagated). Ensure config uses coalescing disabled where tests expect immediate embed error response.
- **tests/test_load_stress.py:** Ensure stress run (embed → job_id → embed_job_status poll) passes with logical job_ids: each poll returns correct slice for that request.
### Coverage (per file, project-wide)

- **Upon completion of the step**, each file of the project (existing and new) must have coverage **≥ 90%**. Run e.g. `pytest --cov=embed --cov-report=term-missing`; add or fix tests so that no project file is below 90% when the step is done.

### Commit after step (mandatory)

- After the step is complete, **commit** (e.g. `git add ... && git commit -m "Step 8: embed_job_status logical resolution"`). **Mandatory.** Push only on request.
