# Step 9: Route embed requests — coalescing path vs current path

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §3 (single queue handler), §3.1 (max_concurrent_jobs unchanged), §4.1 (coalescing path vs current), §4.3 (where to implement: wrapper or middleware).
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric.
- **Previous steps:** [02_config_integration.md](02_config_integration.md) (get_coalescing_config), [04_coalescer_buffer.md](04_coalescer_buffer.md)–[06_coalescer_submit.md](06_coalescer_submit.md) (buffer, payload, submit), [08_embed_job_status.md](08_embed_job_status.md) (status resolution).
- **Code:** `embed/main.py` (register_embedding_commands, adapter); where adapter invokes “embed” (command dispatch); `embed/commands/embed_command.py` (use_queue=True); config: queue_manager.enabled, coalescing.enabled.

---

## Goal

When an embed request arrives, the server must choose: (1) coalescing path — add to buffer and eventually return a logical job_id (and rely on step 6–8 for submit and status); or (2) current path — submit one job per request to the queue and return physical job_id as today. The choice is driven by config: coalescing_enabled. Parallel processes (max_concurrent_jobs) are unchanged: both paths submit jobs to the same queue, which distributes work across P workers.

## Prerequisites

- Step 2: get_coalescing_config().
- Steps 4–6: buffer, payload, submit; coalescer can add request and on flush submit and return logical_job_ids.
- Step 8: embed_job_status resolves logical job_id.

## Tasks

1. **Entry point for embed.**
   - Identify where the adapter invokes the embed command (or where “embed” method is handled). This may be inside the adapter; in that case we need a way to “intercept” or “replace” the default behaviour when coalescing is enabled. Options:
     - **A:** Register a wrapper command that handles “embed” when coalescing_enabled: it adds the request to the coalescer buffer; if the coalescer returns immediately with a logical_job_id (e.g. single-request flush or already had a batch), return that job_id; if the coalescer defers (request buffered), wait for flush (with timeout) and then return the logical_job_id for this request. Ensure the coalescer returns one logical_job_id per request in order when a batch is submitted (step 6).
     - **B:** Middleware or hook that runs before the adapter’s queue submit: if coalescing_enabled, redirect to coalescer (buffer + flush logic) and return response with job_id; else let the adapter do the usual one-job-per-request.
   - Implement the chosen option so that when coalescing is disabled, behaviour is exactly as today (one request -> one queue job -> one job_id).

2. **Coalescing path.**
   - Read coalescing config. If disabled, skip coalescer and use current path.
   - If enabled: pass request params (texts, model, dimension, error_policy, device) to the coalescer. Coalescer adds to buffer; if buffer flushes (window or max_texts or max_wait), it submits one job and returns N logical_job_ids. The current request must receive the logical_job_id that corresponds to its position in the batch. If the request was buffered and flush happens asynchronously, the request must be woken or notified with its logical_job_id (e.g. future, callback, or wait on a condition with timeout).
   - Response: return the same shape as today (e.g. { "job_id": "<logical_job_id>", "status": "pending", ... }) so the client cannot tell the difference.

3. **Preserve max_concurrent_jobs.**
   - Do not change how the queue or workers are configured. Coalescing only changes what is submitted (one job per batch instead of one per request). The queue manager still runs up to P workers (max_concurrent_jobs); each worker still takes one job (now possibly a batch job). No code change in queue_manager config or worker count.

4. **Edge cases.**
   - Single request and coalescing enabled: **flush immediately** (batch of 1). No artificial delay; coalescing is for speed.
   - Coalescing enabled but queue disabled: invalid; either disable coalescing when queue is disabled or document that coalescing requires queue_manager.enabled.

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **embed/coalescing/embed_router.py** or **embed/commands/embed_command_router.py** | **ADD** | New module. Function or class `handle_embed_request(params: Dict, config_manager) -> Dict`: (1) Call config_manager.get_coalescing_config() (or get from app context). If not loaded or coalescing is None or coalescing.enabled is False: return None (meaning "use current path"). (2) If enabled: get buffer/store from coalescing package. Call buffer.add_request(texts, model, dimension, error_policy, device). If add_request returns BatchDescriptor: call submit_batch(descriptor, store), get (logical_job_ids, error). If error: return error response for this request (and for others in batch if applicable). Otherwise the current request must receive logical_job_id at its position: either add_request returns (descriptor, position) and we wait for flush and get logical_job_ids[position], or flush is synchronous and we have logical_job_ids; return response with job_id=logical_job_ids[position]. (3) Single request: add_request returns descriptor (batch of 1); submit_batch returns 1 id; return it immediately. Document how the adapter invokes this (wrapper command vs middleware). |
| **embed/main.py** | **CHANGE** | Where embed command is registered or where the adapter dispatches "embed": if coalescing enabled, call handle_embed_request first; if it returns a response (job_id), return that to the client without submitting one job via adapter queue. Otherwise (coalescing disabled or handle_embed_request returns None) proceed with current flow (adapter queues one job per request). Ensure ConfigManager is available (e.g. load config in main and pass or use global) so get_coalescing_config() can be called. |
| **embed/commands/embed_command.py** | **CHANGE** (optional) | No change if routing is entirely in main/adapter layer. If routing is implemented inside a wrapper that replaces EmbedCommand when coalescing on: the wrapper receives params, calls coalescer path or delegates to original embed command (queue path). |
| **tests/conftest.py** | **CHANGE** | In the test config dict used by client fixture, add `"coalescing": {"enabled": False}` (and ensure queue_manager is present if needed) so that all tests that assume one request → one job_id or inline result keep current behaviour. |
| **tests/unit/test_commands.py** | **CHANGE** | EmbedCommand tests: mock get_coalescing_config to return enabled=False (or None) so routing uses current path; or add parametrized test with coalescing enabled and mock coalescer returning logical_job_id. |
| **tests/test_embedding_basic.py**, **tests/test_embedding_advanced.py**, **tests/integration/test_api.py** | **CHANGE** | Ensure client fixture uses config with coalescing disabled so response shape (inline embeddings or one job_id) unchanged. Optionally add new test that enables coalescing and sends K requests, asserts K logical_job_ids and each poll returns correct slice. |

## Deliverables

- Embed request routing: coalescing_enabled -> coalescer (buffer, submit on flush, return logical_job_id); else current path (one job per request, physical job_id).
- Same response format for both paths (job_id, status, ...).
- max_concurrent_jobs unchanged; batch jobs are processed by the same worker pool.

## End of step: code_mapper

After all code changes and tests, run the project’s **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

The step is complete only when all of the following hold.

### Step-specific

- When coalescing_enabled=false: embed uses current path (one request -> one queue job -> one physical job_id); behaviour identical to today.
- When coalescing_enabled=true: embed uses coalescer (add to buffer, on flush submit batch, return logical_job_id per request); response shape same (job_id, status, ...). max_concurrent_jobs unchanged; batch jobs consumed by same worker pool.
- Edge: coalescing enabled but queue disabled -> document or disable coalescing.

### Static checks (zero errors, project-wide)

- **black:** No formatting errors (run black on project).
- **mypy:** No errors in the project; fix any errors even if not in files changed in this step.
- **flake8:** No errors; fix all reported errors.
- **code_mapper:** Run code_mapper; complete without errors; indices updated.

### All tests passing

- Run the **full** test suite. **All** tests must pass.

### Real server test

- **Coalescing disabled:** Start server with **hypercorn** on **different port** (e.g. 8001) with coalescing_enabled=false; send one embed request; get one job_id; poll embed_job_status until completed; assert result matches single request; stop server. Programmatic start/stop.
- **Coalescing enabled:** Start server with **hypercorn** on **different port** with coalescing_enabled=true and queue enabled; send K embed requests (same model/dimension/device) within window; get K logical_job_ids; poll each until completed; assert each gets correct slice; stop server. Programmatic start/stop.
- Optionally: send more requests than one batch; assert two or more batch jobs; with max_concurrent_jobs=2 verify two batches can run in parallel.

### Step-specific tests

- **Unit:** With mocked config: coalescing_enabled=false -> routing calls current path (one job submit); coalescing_enabled=true -> routing calls coalescer add_request and returns logical_job_id when flush returns.
- **Integration:** Full flow with real server (see Real server test): coalescing off -> one job_id, one result; coalescing on -> K logical_job_ids, K sliced results; all tests pass.

### Test refactoring

- **tests/conftest.py:** Explicitly set coalescing disabled (and queue disabled if embed uses queue for test client) in the test config fixture so existing tests that assume “embed returns inline result” or “one request → one job_id” keep current behaviour.
- **tests/unit/test_commands.py:** EmbedCommand tests: either mock get_coalescing_config() to return enabled=False so routing uses current path, or add tests for coalescing path (logical_job_id return). Ensure all existing EmbedCommand unit tests still pass.
- **tests/test_embedding_basic.py**, **tests/test_embedding_advanced.py:** Ensure client/config uses coalescing disabled so tests that expect immediate embeddings or single job_id continue to pass; or add separate tests for coalescing-on path (multiple requests → multiple logical_job_ids → poll each for slice).
- **tests/test_error_handling.py:** Keep embed validation error tests; ensure test config has coalescing disabled so immediate error response shape is unchanged.
- **tests/integration/test_api.py:** Ensure test config has coalescing disabled so “embed” returns inline data (or adapt tests to accept job_id + embed_job_status when queue/coalescing path is used). Optionally add tests for coalescing path.
- **tests/test_load_stress.py:** Run stress with coalescing disabled and with coalescing enabled; both must pass (multiple job_ids, each poll returns correct result/slice when coalescing on).
- **tests/test_integration_simple.py**, **test_integration.py**, **test_real_integration.py:** Set coalescing disabled in config by default so existing flows unchanged; or add dedicated coalescing-on scenario.
### Coverage (per file, project-wide)

- **Upon completion of the step**, each file of the project (existing and new) must have coverage **≥ 90%**. Run e.g. `pytest --cov=embed --cov-report=term-missing`; add or fix tests so that no project file is below 90% when the step is done.

### Commit after step (mandatory)

- After the step is complete, **commit** (e.g. `git add ... && git commit -m "Step 9: embed command routing coalescing"`). **Mandatory.** Push only on request.
