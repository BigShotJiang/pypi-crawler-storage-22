# Step 10: Test plan and acceptance criteria

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §6 (Summary), acceptance criteria; full coalescing flow.
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric (static checks, all tests, real server, step-specific tests).
- **Previous steps:** [01_config_schema.md](01_config_schema.md)–[09_embed_command_routing.md](09_embed_command_routing.md) — each step has its own unit/integration and real-server requirements; this step consolidates and adds any missing coverage. Step 11 (timing and timing_stats) has its own tests; see [11_timing_and_timing_stats.md](11_timing_and_timing_stats.md).
- **Code:** `tests/` layout; existing pytest config; how to start server on alternate port (e.g. `embed/main.py` or scripts). Use **hypercorn** as the ASGI server when starting the server in tests (project standard; do not use uvicorn).

---

## Goal

Define tests and validation steps to ensure coalescing works correctly and does not break existing behaviour. One file per step (this file covers overall flow and acceptance). Step 10 also ensures the **completion metric** is fully satisfied for the whole feature: static checks, all tests, real server tests, and step-specific unit/integration tests are in place and documented.

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **tests/unit/test_coalescing_config.py** | **CHANGE** (if gaps) | Ensure coverage: get_coalescing_config(), create_default_config() with coalescing, load without coalescing section. |
| **tests/unit/test_logical_job_store.py** | **CHANGE** (if gaps) | Ensure all store operations and edge cases (concurrent, idempotency) are covered. |
| **tests/unit/test_coalescer_buffer.py** | **CHANGE** (if gaps) | Ensure flush conditions (max_texts, window, single request, max_wait_sec) and homogeneity buckets are covered. |
| **tests/unit/test_coalescer_payload.py** | **CHANGE** (if gaps) | build_batch_payload shape, _coalesced_slices sum, validate_params acceptance. |
| **tests/unit/test_coalescer_submit.py** | **CHANGE** (if gaps) | submit_batch success and failure, order of logical_job_ids. |
| **tests/unit/test_commands.py** | **CHANGE** | EmbedJobStatusCommand: logical job_id → pending / sliced result / error; physical job_id → delegate to queue (unchanged). |
| **tests/integration/test_coalescing_embed.py** | **ADD** | New file. End-to-end: send K embed requests (coalescing enabled, same key), receive K logical_job_ids; poll embed_job_status for each until done; assert each result has correct number of embeddings/results and content matches that request's texts. |
| **tests/integration/test_coalescing_server.py** | **ADD** | New file. Start real server with hypercorn on alternate port (e.g. 8001); run tests: health, config with coalescing section, embed with coalescing disabled (one job_id, poll, full result), embed with coalescing enabled (multiple requests, K logical_job_ids, poll each, sliced results); stop server programmatically. Document command (e.g. `pytest tests/integration/test_coalescing_server.py -v`) and port. |
| **tests/test_embedding_basic.py**, **tests/test_embedding_advanced.py**, **tests/test_error_handling.py**, **tests/integration/test_api.py**, **tests/test_load_stress.py** | **CHANGE** (if not done in 08–09) | Ensure all use coalescing-disabled config where they assume inline result or one job_id; fix any failing tests after routing and embed_job_status changes. |
| **docs/coalescing_plan/10_tests_validation.md** or **README** | **CHANGE** | Document: how to run full test suite; how to run real-server coalescing test (command, port, hypercorn). |

## Scope

- Unit tests for new modules (config, store, buffer, payload builder).
- Integration tests: coalescing path end-to-end (embed -> logical job_id -> status -> sliced result).
- Regression: non-coalescing path unchanged.
- Config and parallel processes: max_concurrent_jobs still applies to batch jobs.

## Test plan

### 1. Config (steps 1–2)

- **Unit:** Load config without `coalescing` section -> get_coalescing_config() returns default (enabled=False).
- **Unit:** Load config with `coalescing.enabled: true`, window_sec, max_texts -> get_coalescing_config() returns correct values.
- **Unit:** Invalid values (e.g. negative window_sec) -> validation error or safe default.

### 2. Logical job store (step 3)

- **Unit:** register_logical_jobs(physical_id, [(0,2), (2,3)]) returns two logical_job_ids; get_logical_job each returns correct (physical_id, start_index, count).
- **Unit:** set_physical_result(physical_id, full_result); get_physical_result(physical_id) returns full_result; get_physical_error(physical_id) returns None.
- **Unit:** set_physical_error(physical_id, err); get_physical_error returns err; get_physical_result returns None or previous state as designed.

### 3. Buffer and payload (steps 4–5)

- **Unit:** Add requests with same (model, dimension, error_policy, device); when window or max_texts triggers, get one BatchDescriptor; merged texts length = sum of request text counts; counts list matches.
- **Unit:** Add requests with different model (or dimension, etc.) -> separate buckets; no cross-batch mixing.
- **Unit:** build_batch_payload(descriptor) yields params with texts and _coalesced_slices; sum(slices) == len(texts); EmbedCommand.validate_params accepts (after allowing _coalesced_slices if needed).

### 4. Submit and completion (steps 6–7)

- **Unit or integration:** Flush a batch of N requests -> one queue job submitted; store has N logical jobs with correct slices; N logical_job_ids returned in order.
- **Integration:** Submit batch job; worker runs EmbedCommand.execute() with merged payload; on completion, set_physical_result called (or lazy store on first status read). All N logical jobs can later resolve to correct sliced result.

### 5. embed_job_status (step 8)

- **Unit:** For logical_job_id with physical job pending -> status “pending”.
- **Unit:** For logical_job_id with physical job completed and result stored -> return slice: embeddings and results of length count, correct content for that request’s texts.
- **Unit:** For logical_job_id with physical job failed -> return same error.
- **Regression:** For physical job_id (non-coalesced) -> unchanged behaviour (delegate to queue_get_job_status).

### 6. Routing (step 9)

- **Integration, coalescing disabled:** One embed request -> one job_id (physical); poll -> full result for that one request. Same as current behaviour.
- **Integration, coalescing enabled:** Send K embed requests (same model/dimension/device) within window; receive K logical job_ids; poll each -> each gets correct slice (correct number of embeddings/results, matching their input texts).
- **Integration, coalescing enabled, parallel:** Send more requests than one batch; two or more batch jobs enqueued; with max_concurrent_jobs=2, two batches can run in parallel; each batch’s logical jobs resolve correctly.

### 7. Edge cases and errors

- **Batch of 1:** Coalescing enabled, single request -> submit immediately, one logical_job_id; poll -> get result for that one request (no delay).
- **Batch failure:** If the batch job fails (e.g. invalid text with fail_fast), all N logical jobs get the same error when polled.
- **max_wait_sec (optional):** When 2+ requests are in the buffer, flush if the oldest has waited > max_wait_sec. Single request is always flushed immediately.

## Acceptance criteria (summary)

| Criterion | Check |
|-----------|--------|
| Coalescing disabled | Behaviour identical to current: one request -> one job -> one job_id -> one result. |
| Coalescing enabled | Multiple requests (same key) -> one batch job -> N logical_job_ids -> each poll returns correct slice. |
| Response shape | Sliced result has same schema as single-request embed result (embeddings, results, model, dimension, device). |
| Homogeneity | Requests with different model/dimension/device do not share a batch. |
| Parallel processes | max_concurrent_jobs still limits concurrent batch jobs; no regression. |
| Errors | Batch failure -> all logical jobs in batch get same error. |
| Config | Default config -> coalescing off; valid coalescing section -> enabled and params applied. |
| Proxy auto-registration | When server runs with proxy registration enabled, it successfully auto-registers on the proxy and is visible/healthy from the proxy (e.g. proxy list or health confirms). |
| All MCP commands via proxy | All MCP commands (health, echo, help, config, models, embed, embed_job_status, timing_stats, and any adapter commands) succeed when the client calls the proxy and the proxy forwards to the embedding server; no scenario requires direct connection to the server for success. |

## End of step: code_mapper

After all test additions and any code fixes, run the project’s **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

Step 10 is complete only when the **full feature** satisfies the completion metric and the following hold. The **final success metric** includes: all commands and mechanisms working **and** **successful auto-registration on the proxy** **and** **all MCP commands working through the proxy** (client -> proxy -> embedding server; every command succeeds via this path; verified in real-server test or pipeline).

### Step-specific (test coverage)

- All test plan items (Config, Store, Buffer/Payload, Submit/Completion, embed_job_status, Routing, Edge cases) have corresponding tests that pass.
- Acceptance criteria table (Coalescing disabled, Coalescing enabled, Response shape, Homogeneity, Parallel processes, Errors, Config, Proxy auto-registration, All MCP commands via proxy) are covered by tests or real-server runs.

### Static checks (zero errors, project-wide)

- **black:** Run from project root; no formatting errors.
- **mypy:** Run from project root; **no** mypy errors in the project; fix any remaining errors.
- **flake8:** Run from project root; **no** flake8 errors; fix all.
- **code_mapper:** Run code_mapper; **no** errors; indices in `code_analysis/` updated and consistent.

### All tests passing

- Run the **full** test suite (e.g. `pytest tests/` or project’s standard command). **All** tests must pass, including all new coalescing tests and all pre-existing tests (no regression).

### Real server tests (mandatory for step 10)

- At least one **dedicated** test or script that:
  1. Starts the embedding service on a **different port** (e.g. 8001 or 9000, not the default 8000) using **hypercorn** (project standard; do not use uvicorn).
  2. Runs tests against the running server (e.g. coalescing disabled: one embed -> one job_id -> poll -> result; coalescing enabled: multiple embeds -> logical_job_ids -> poll each -> sliced results; health; config).
  3. Verifies **successful auto-registration on the proxy**: when config enables proxy registration, the server registers with the proxy and is visible/healthy from the proxy (e.g. proxy list or health check confirms).
  4. Verifies **all MCP commands work through the proxy**: client connects to the proxy (not directly to the embedding server); runs all commands (health, echo, help, config, models, embed, embed_job_status, timing_stats, etc.) via the proxy; all must succeed (proxy forwards to the server).
  5. Stops the server after the run.
- Start and stop must be **programmatic** (no manual “start server in one terminal, run test in another” as the only way to satisfy acceptance). Document the command to run this test (e.g. `pytest tests/integration/test_coalescing_server.py -v`).

### Step-specific tests (step 10)

- **Unit (consolidation):** Any unit tests not yet added in steps 1–9 that cover the test plan (e.g. edge cases: batch of 1, batch failure, max_wait_sec).
- **Integration:** End-to-end coalescing path: embed (coalescing on) -> multiple requests -> N logical_job_ids -> poll each -> correct slices; end-to-end non-coalescing: embed (coalescing off) -> one request -> one job_id -> poll -> full result. These may be in one or more files; they must run against a **real server** started on an alternate port with **hypercorn** (see Real server tests above).

### Test refactoring

- **Consolidate and document:** Ensure all test plan items (Config, Store, Buffer/Payload, Submit/Completion, embed_job_status, Routing, Edge cases) have corresponding tests; acceptance criteria table is covered. Fix any remaining gaps from steps 1–9.
- **tests/unit/test_coalescing_config.py**, **test_logical_job_store.py**, **test_coalescer_buffer.py**, **test_coalescer_payload.py:** Present and passing.
- **tests/integration/test_coalescing_embed.py** (or equivalent): End-to-end coalescing path and status resolution; **tests/integration/test_coalescing_server.py** (or equivalent): real server on alternate port (hypercorn), start programmatically, run tests (coalescing off/on), stop programmatically. Document command and port.
- **Regression:** Run full suite; all pre-existing tests (embedding_basic, embedding_advanced, error_handling, integration/test_api, load_stress, etc.) must still pass. No test assumes coalescing-on unless explicitly testing that path.
- **Common mocks/fixtures (optional but recommended):** Per [TEST_ANALYSIS_FIXTURES_MOCKS.md](../TEST_ANALYSIS_FIXTURES_MOCKS.md), consider extracting shared client fixture, minimal test config, mock EmbeddingService factory, and optional JSON-RPC request helpers so that all tests (including new coalescing tests) use one client, one config source, and one mock pattern.

### Coverage (per file, project-wide)

- **Upon completion of the step**, each file of the project (existing and new) must have coverage **≥ 90%**. Run e.g. `pytest --cov=embed --cov-report=term-missing`; add or fix tests so that no project file is below 90% when the step is done.

### Commit after step (mandatory)

- After the step is complete, **commit** (e.g. `git add ... && git commit -m "Step 10: tests and validation"`). **Mandatory.** Push only on request.

---

## Deliverables

- Unit tests for store, buffer, payload, config (as per steps 1–9 and this plan).
- Integration test(s) for coalescing path and non-coalescing path (with real server on alternate port).
- Regression: existing embed tests still pass.
- Document: how to run full test suite, how to run real-server integration test (command, port, and that the server is started with **hypercorn**).

## How to run (commands)

- **Full test suite:** From project root, with `.venv` activated:
  ```bash
  pytest tests/ -v
  ```
- **Real-server coalescing tests:** The server is started **programmatically** by pytest (via `embed.main`, which uses **hypercorn**). Port **8001** is used so as not to conflict with default 8000.
  ```bash
  pytest tests/integration/test_coalescing_server.py -v
  ```
  The test module starts the embedding service with `python -m embed.main --config <temp_config> --port 8001 --host 127.0.0.1` (hypercorn is used by the adapter's `create_and_run_server`). Health, embed (coalescing off), and embed (coalescing on) with multiple requests and slice checks are run, then the server is stopped.
- **Coalescing E2E (client-only):**
  ```bash
  pytest tests/integration/test_coalescing_embed.py -v
  ```
- **Real-server pipeline CLI (Step 12):** Does not start the server; run against an already-running server (or proxy). Uses mcp_proxy_adapter JsonRpcClient only. From project root with `.venv` activated:
  ```bash
  python -m scripts.embed_pipeline_cli --host 127.0.0.1 --port 8080 --profile quick
  python -m scripts.embed_pipeline_cli --host 127.0.0.1 --port 8080 --profile full --output report.json
  ```
  Profiles: `quick` (health, echo, help, config, models, embed single/batch small), `full` (all commands, all text bands, many single, mixed), `stress` (larger N/M). To run via proxy, pass the proxy host and port. Optional: `--skip timing_stats` if timing is disabled.

## File layout (suggested)

- `tests/unit/test_coalescing_config.py` — config and get_coalescing_config.
- `tests/unit/test_logical_job_store.py` — store operations.
- `tests/unit/test_coalescer_buffer.py` — buffer and BatchDescriptor.
- `tests/unit/test_coalescer_payload.py` — build_batch_payload.
- `tests/integration/test_coalescing_embed.py` — end-to-end coalescing path and status resolution (or under `tests/` if no integration subdir).
- `tests/integration/test_coalescing_server.py` (or equivalent) — **real server** on alternate port: start server with **hypercorn**, run tests, stop server. Document port and command.
- Existing embed tests still pass (no regression).
