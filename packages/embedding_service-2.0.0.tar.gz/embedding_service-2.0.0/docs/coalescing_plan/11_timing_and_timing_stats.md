# Step 11: Timing structure and timing_stats command for coalescing

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Architecture:** [COALESCING_ANALYSIS.md](../COALESCING_ANALYSIS.md) — §3 (one physical job per batch), §5 (optional metrics: coalesced_batch_size).
- **Plan:** [00_overview.md](00_overview.md) — autonomy, code_mapper, completion metric.
- **Previous steps:** [05_coalescer_payload.md](05_coalescer_payload.md) (payload with `_coalesced_slices`), [07_coalescer_completion.md](07_coalescer_completion.md) (batch completion). EmbedCommand.execute() runs in the worker with merged payload; it already writes one timing record per physical job (one line in JSONL). With coalescing, that record corresponds to a **coalesced batch** (N logical requests).
- **Code:** `embed/commands/embed_command.py` (where `record_timing(entry)` is called), `embed/utils/timing_recorder.py` (record format), `embed/commands/timing_stats_command.py` (reads JSONL, computes stats: batch_vs_single, by_device, etc.).

---

## Goal

Extend the timing record structure so that coalesced batches are identifiable and the number of logical requests per batch is recorded. Update the timing_stats command so that analytics can report by coalesced vs non-coalesced and by logical request count (e.g. coalesced_batch_count, logical_requests_per_batch distribution). **No backward compatibility:** every timing record must have the new fields (coalesced_batch, and logical_request_count when coalesced); timing_stats expects the current schema only. No fallbacks to old format.

## Prerequisites

- Step 5: EmbedCommand.execute() may receive params with `_coalesced_slices` (list of counts). When present, this run is a coalesced batch.
- Step 7: Physical job completion is in place (one record per physical job execution).

## Tasks

1. **Extend timing record (one record per physical job).**
   - When EmbedCommand.execute() writes a timing record and the validated params contain `_coalesced_slices`:
     - Add `coalesced_batch: true` to the entry.
     - Add `logical_request_count: len(_coalesced_slices)` (number of logical requests in this batch).
   - When there is no `_coalesced_slices` (non-coalesced or single-request path):
     - Add `coalesced_batch: false` to the entry (always set; no omission).
   - Do not change the existing fields (is_batch, text_count, encode_seconds, etc.); they still describe the physical job (merged texts). Document in timing_recorder docstring: every record must include `coalesced_batch` (bool); `logical_request_count` (int) when coalesced_batch is True.

2. **Update timing_stats command.**
   - Records are expected to have the current schema: every record has `coalesced_batch` (bool). No support for old-format records; no fallbacks.
   - Add to the computed stats:
     - `coalesced_batch_count`: number of records with coalesced_batch true.
     - `non_coalesced_count`: number of records with coalesced_batch false.
     - Optionally: `logical_request_count_per_record`: stats (median, quantiles, min, max) over `logical_request_count` for coalesced records.
     - Optionally: a subsection `coalesced_vs_non_coalesced` with encode_seconds / rpc_seconds broken down by coalesced_batch.

## Deliverables

- Timing record: every record has coalesced_batch (true/false); when coalesced, logical_request_count=N. No optional/legacy fields.
- timing_stats: aggregates coalesced_batch_count, non_coalesced_count; optional logical_request_count stats and coalesced_vs_non_coalesced breakdown. Expects current schema only; no fallbacks.
- Docstrings updated (timing_recorder, timing_stats_command): required fields documented.

## End of step: code_mapper

After all code changes and tests, run the project's **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

- When a coalesced batch job runs (payload has _coalesced_slices), the timing record contains coalesced_batch true and logical_request_count equal to the number of logical requests. Non-coalesced records always have coalesced_batch false.
- timing_stats command runs on files with the current schema only (every record has coalesced_batch). Output includes coalesced_batch_count and non_coalesced_count (and optional breakdown). No handling of legacy/missing fields.
- All tests pass; coverage and static checks as per overview.

### Test refactoring

- **Unit:** Test that when execute() is called with params including _coalesced_slices=[2, 3], the timing entry passed to record_timing includes coalesced_batch=True and logical_request_count=2 (number of logical requests = len(_coalesced_slices)).
- **Unit:** timing_stats _compute_stats() with records that all have coalesced_batch true or false returns coalesced_batch_count and non_coalesced_count correctly. No tests for "missing key" or old format.
- **Coverage (per file, project-wide):** Upon completion, each file has coverage ≥ 90%.

### Commit after step (mandatory)

- After the step is complete, **commit** (e.g. `git add ... && git commit -m "Step 11: timing coalesced_batch and timing_stats"`). **Mandatory.** Push only on request.

---

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **embed/commands/embed_command.py** | **CHANGE** | Where `record_timing({...})` is called (after successful embed): obtain `slices = validated_params.get("_coalesced_slices")`. If `slices` is present and is a list: set `coalesced_batch: True` and `logical_request_count: len(slices)` in the entry dict. Otherwise set `coalesced_batch: False`. Every record must include coalesced_batch. In `_record_timing_on_error`, set `coalesced_batch: False` for failed requests. |
| **embed/utils/timing_recorder.py** | **CHANGE** | In the docstring of `record(entry)`: document that every record must contain `coalesced_batch: bool`; when True, `logical_request_count: int` is required. No legacy/optional handling. |
| **embed/commands/timing_stats_command.py** | **CHANGE** | In `_compute_stats(records)`: (1) Assume every record has `coalesced_batch` (bool). (2) `coalesced_records = [r for r in records if r["coalesced_batch"] is True]`, `non_coalesced_records = [r for r in records if r["coalesced_batch"] is False]`. (3) Add `"coalesced_batch_count"`, `"non_coalesced_count"`. (4) Optional: logical_request_count stats for coalesced_records; optional coalesced_vs_non_coalesced breakdown. No fallback for missing keys. |
| **tests/unit/** (e.g. test_commands or test_timing_stats) | **CHANGE** / **ADD** | Test: execute() with _coalesced_slices → entry has coalesced_batch=True and logical_request_count=2. Test: _compute_stats() with records that all have coalesced_batch true/false returns correct coalesced_batch_count and non_coalesced_count. No tests for missing or old-format fields. |
