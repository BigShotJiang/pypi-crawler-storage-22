# Step 12: Real-server test pipeline CLI

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

---

## Context (form correct context before implementation)

- **Plan:** [00_overview.md](00_overview.md) — completion metric, code_mapper, commit after step.
- **Previous steps:** [10_tests_validation.md](10_tests_validation.md) (test plan, real-server tests), [11_timing_and_timing_stats.md](11_timing_and_timing_stats.md) (timing_stats command). This step adds a **standalone CLI utility** that runs a detailed, repeatable test pipeline against a **live** embedding server to validate all commands and load patterns without starting the server from the test process.
- **Client:** Use **mcp_proxy_adapter** JSON-RPC client for all server communication. Import from the project virtualenv: `mcp_proxy_adapter.client.jsonrpc_client` — class `JsonRpcClient` (protocol, host, port, cert, key, ca, timeout). Methods: `health()`, `execute_command(command, params)` / `jsonrpc_call(method, params)`, `execute_command_unified(command, params, ...)` for queued commands with optional auto-poll. See: `.venv/lib/python3.12/site-packages/mcp_proxy_adapter/client/jsonrpc_client/client.py`, `command_api.py`, `transport.py`.
- **mTLS certificates:** For mTLS, the project uses the **mtls_certificates** directory at project root (see `config/container_mtls.json`). Client certs for the pipeline CLI: `mtls_certificates/client/embedding-service.crt`, `mtls_certificates/client/embedding-service.key`, `mtls_certificates/ca/ca.crt`. When `--protocol mtls` (or https with client auth), `--cert`, `--key`, `--ca` should point to these paths (or equivalents). The directory is created by docker scripts and is in `.gitignore`; for local runs, generate or copy certs into `mtls_certificates/` as per project docs.
- **Server commands to cover:** All commands exposed by the embed application on the real server:
  - **Built-in (adapter):** `health` (GET /health or JSON-RPC), `echo`, `help`, `config` (get_config).
  - **Embed-specific:** `models`, `embed`, `embed_job_status`, `timing_stats`.
  - **Optional (if queue enabled):** `queue_health`, `queue_get_job_status` (physical job_id); the pipeline focuses on embed + embed_job_status as the main flow.

---

## Goal

Implement a **CLI utility** that runs a **detailed real-server test pipeline** covering **all** embed-related and adapter commands, with explicit scenarios for **text sizes** (small, medium, large) and **load patterns** (many single requests, large batches, mixed). The tool must use **only** the **mcp_proxy_adapter client** for connection and must be runnable from the command line (e.g. `python -m scripts.embed_pipeline_cli --host 127.0.0.1 --port 8080`). Output: human-readable summary and optional JSON report (passed/failed per scenario, timings, error messages).

---

## Prerequisites

- Step 10: Test plan and real-server test approach are defined.
- A running embedding server (started manually or by CI) on a known host/port; the CLI **does not** start or stop the server.
- Virtualenv with `mcp_proxy_adapter` and project dependencies; CLI is run with project `.venv` so the adapter client is available.

---

## Commands to test (exhaustive list)

| Command | Params | Expected | Notes |
|---------|--------|----------|--------|
| **health** | — | HTTP 200, JSON with e.g. `status`, `version` | Via client `health()` (GET /health). |
| **echo** | `message` (optional) | `result` contains echoed message | Sanity check JSON-RPC. |
| **help** | `command` (optional) | List or command-specific help | No side effects. |
| **config** | — | Config object (embedding, coalescing, etc.) | `execute_command("config", {})` or adapter `get_config()`. |
| **models** | — | `models` list with name, dimension, etc. | Embed-specific. |
| **embed** | `texts`, optional `model`, `device`, `error_policy` | Either inline `results` or `job_id` (when coalescing/queue) | Core command; test with 1 text, N texts, various sizes. |
| **embed_job_status** | `job_id` | `exists`, `status`, `done`, optional `result` | Poll until `done` or error; validate result shape. |
| **timing_stats** | optional `file_path` | Stats object (e.g. total_count, by_device) or error if file missing | Only when timing_registration enabled; CLI may skip or expect optional failure. |

Optional (if queue enabled): `queue_health`, `queue_get_job_status` (for physical job_id); document in CLI `--help` that these are optional.

---

## Text size bands (definitions)

Use fixed or generated samples so results are reproducible.

| Band | Approx. length (chars) | Example use |
|------|--------------------------|-------------|
| **Small** | 10–100 | Single short sentence. |
| **Medium** | 500–2_000 | Paragraph (e.g. 2–5 sentences, ~100–400 words). |
| **Large** | 5_000–50_000 | Long document (e.g. 1–10 pages of text). |

Implementation: provide constants or a small generator (e.g. lorem or fixed strings) in the CLI or a shared data module (e.g. `scripts/pipeline_data.py`) so that "small", "medium", "large" batches are deterministic.

---

## Load patterns (scenarios)

| Scenario | Description | Pass criteria |
|----------|-------------|---------------|
| **Single small** | 1× embed with 1 small text | Success; result has one embedding; or job_id + embed_job_status returns one result. |
| **Single medium** | 1× embed with 1 medium text | Success; one embedding or job_id → one result. |
| **Single large** | 1× embed with 1 large text | Success; one embedding or job_id → one result (may be slow). |
| **Batch small** | 1× embed with N small texts (e.g. N=20–50) | Success; N embeddings or one job_id → N results. |
| **Batch medium** | 1× embed with N medium texts (e.g. N=5–15) | Success; N results. |
| **Batch large** | 1× embed with N large texts (e.g. N=2–5) | Success; N results (stress). |
| **Many single small** | M× embed with 1 small text each (e.g. M=30–100) | All succeed; each returns result or job_id; if job_id, poll each until done. |
| **Many single medium** | M× embed with 1 medium text each (e.g. M=10–20) | All succeed. |
| **Mixed** | Several single embeds + one batch embed (e.g. 5 single + 1 batch of 10) | All succeed; no cross-contamination of results. |

Exact counts (N, M) can be configurable via CLI (e.g. `--batch-size`, `--single-count`) or profiles (see below).

---

## CLI specification

- **Entry point:** Runnable as a module or script, e.g. `python -m scripts.embed_pipeline_cli` or `scripts/embed_pipeline_cli.py`, from project root with `.venv` activated.
- **Connection (use mcp_proxy_adapter client only):**
  - `--host` (default `127.0.0.1`), `--port` (default `8080`), `--protocol` (default `http`; `https` / `mtls` for TLS). When connecting **via proxy**, pass the proxy's host and port; the client then sends all MCP commands to the proxy (proxy forwards to the embedding server). All commands must work in this mode for the final success metric.
  - For mTLS: `--cert`, `--key`, `--ca` — paths to client certificate, key, and CA. Project standard: **mtls_certificates** directory (client: `mtls_certificates/client/embedding-service.crt`, `.key`; CA: `mtls_certificates/ca/ca.crt`). `--no-verify-hostname` if needed.
  - `--timeout` (float, seconds; applied to client timeout).
- **Pipeline control:**
  - `--profile` one of: `quick` (health, echo, help, config, models, one embed single small, one embed batch small), `full` (all commands + all text bands + batch + many single), `stress` (full + larger N/M and optional repeat).
  - Optional: `--commands C1,C2,...` to restrict to specific commands (e.g. `embed,embed_job_status,models`).
  - `--skip timing_stats` or `--skip queue_health` to avoid failures when timing/queue not enabled.
- **Output:**
  - `--output FILE` write JSON report to FILE (scenarios run, passed/failed, duration, error messages).
  - Always print to stdout a short summary: total scenarios, passed, failed, list of failed with reason.
- **Behaviour:**
  - Create one `JsonRpcClient` instance with given connection args; use it for all calls.
  - For `embed` returning `job_id`, use `execute_command_unified` with auto_poll or manually call `embed_job_status` in a loop until `done` or timeout; record success/failure per scenario.
  - Do not start or stop the server; assume server is already running.

---

## File-by-file actions (детально до файла)

| File | Action | What to do |
|------|--------|------------|
| **scripts/embed_pipeline_cli.py** (or **scripts/real_server_pipeline.py**) | **ADD** | New CLI module. (1) Parse argparse: host, port, protocol, cert, key, ca, timeout, profile, output, skip. (2) Instantiate `JsonRpcClient(protocol=..., host=..., port=..., cert=..., key=..., ca=..., timeout=...)`. (3) Run scenarios by profile: call `client.health()`, `client.execute_command("echo", {...})`, `client.execute_command("help", {})`, `client.execute_command("config", {})`, `client.execute_command("models", {})`, then embed scenarios (single small/medium/large, batch small/medium/large, many single small/medium, mixed). For embed use `execute_command("embed", {"texts": [...]})`; if result has `job_id`, poll `embed_job_status` until done. (4) Optionally call `execute_command("timing_stats", {})` if not skipped. (5) Collect results per scenario (name, passed, duration, error); print summary; if `--output` write JSON. (6) Exit code 0 if all passed, non-zero if any failed. Docstring: Author, email. Keep file under 400 lines; if needed split scenario runners into a second module (e.g. `scripts/pipeline_scenarios.py`). |
| **scripts/pipeline_data.py** (optional) | **ADD** | Constants or helpers for text samples: e.g. `SMALL_TEXTS`, `MEDIUM_TEXTS`, `LARGE_TEXTS` (list of strings by band) or `generate_text(band, length_hint)` so pipeline uses deterministic data. If all samples are inlined in the CLI, this file can be omitted but is recommended for clarity. |
| **scripts/pipeline_scenarios.py** (optional) | **ADD** | If CLI file grows: move scenario definitions (list of scenario names, text bands, batch sizes) and run_one_scenario(client, scenario_name, options) here; CLI only parses args and calls run_all(client, profile, options). |
| **docs/coalescing_plan/12_real_server_test_pipeline_cli.md** | (this file) | Document pipeline design, CLI options, and file-by-file actions. |
| **README or docs** | **CHANGE** | Add short section: how to run the real-server pipeline (e.g. start server, then `python -m scripts.embed_pipeline_cli --host 127.0.0.1 --port 8080 --profile full`). |

---

## Implementation notes

- **Import client:** `from mcp_proxy_adapter.client.jsonrpc_client import JsonRpcClient` (or equivalent from `mcp_proxy_adapter.client.jsonrpc_client.client`). Ensure the project run uses the venv where mcp_proxy_adapter is installed.
- **Embed + job_id:** When server returns `job_id` (e.g. coalescing or queue path), poll `embed_job_status` with a reasonable interval (e.g. 0.5–1 s) and timeout (e.g. 120 s per job); mark scenario failed on timeout or error response.
- **Idempotency:** Pipeline does not modify server state beyond sending requests; safe to run repeatedly.
- **Optional commands:** If `timing_stats` returns an error (e.g. file not found), pipeline can record "skipped" or "optional_fail" so that `--profile full` still passes when timing is disabled.

---

## Deliverables

- CLI script runnable with `python -m scripts.embed_pipeline_cli` (or equivalent) with documented options.
- All server commands (health, echo, help, config, models, embed, embed_job_status, timing_stats [optional]) exercised in at least one profile.
- Text bands (small, medium, large) and load patterns (single, batch, many single, mixed) implemented and run in `full` profile.
- JSON report (optional) and exit code reflecting overall pass/fail.
- Brief documentation in README or docs on how to run the pipeline.

---

## End of step: code_mapper

After all code changes, run the project **code_mapper** command to update `code_analysis/` indices. Mandatory for this step.

---

## Completion metric (Метрика завершения)

- Running `python -m scripts.embed_pipeline_cli --host 127.0.0.1 --port 8080 --profile quick` against a live server completes and reports pass/fail for health, echo, help, config, models, and at least one embed (single small) and, if applicable, embed_job_status.
- Running `--profile full` runs all commands and all text-band and load-pattern scenarios; summary and optional JSON report are produced; exit code 0 only when all scenarios pass.
- **Final success metric** (with all commands and mechanisms working) includes: (1) **Successful auto-registration on the proxy** (server registered and visible/healthy on the proxy). (2) **All MCP commands work through the proxy**: the pipeline must support connecting to the **proxy** (not directly to the embedding server); when run in proxy mode, every command (health, echo, help, config, models, embed, embed_job_status, timing_stats, etc.) must succeed via proxy -> server. Document how to run the pipeline in proxy mode and assert all commands via proxy.
- CLI uses **only** the mcp_proxy_adapter `JsonRpcClient` for server communication (no raw httpx/requests for JSON-RPC).
- **Coverage (per file, project-wide):** New pipeline files have tests or are exercised by the pipeline itself; project coverage remains ≥ 90% for modified files.

### Commit after step (mandatory)

- After the step is complete, **commit** (e.g. `git add ... && git commit -m "Step 12: real-server test pipeline CLI"`). **Mandatory.** Push only on request.

### Test refactoring

- No pytest change required for existing tests; the pipeline is a standalone CLI. Optional: add a small test that runs the CLI with `--profile quick` against a mock or a subprocess-started server (could be in step 10 or a separate integration test); if added, document in step 10.

---

## Summary table: scenarios by profile

| Profile | Commands | Text bands | Load patterns |
|---------|----------|------------|---------------|
| **quick** | health, echo, help, config, models, embed, embed_job_status (if job_id) | small only | 1× single small, 1× batch small (e.g. 5 texts) |
| **full** | All of quick + timing_stats (or skip) | small, medium, large | Single small/medium/large; batch small/medium/large; many single small (e.g. 30); many single medium (e.g. 10); mixed (5 single + 1 batch 10) |
| **stress** | Same as full | small, medium, large | Larger N/M (e.g. batch 100, many single 100); optionally repeat mixed 2–3 times |

Exact numbers (e.g. 30, 100) can be defined as constants in the CLI or pipeline_data and overridable via CLI args (e.g. `--batch-size 100`, `--single-count 50`) for CI or manual runs.
