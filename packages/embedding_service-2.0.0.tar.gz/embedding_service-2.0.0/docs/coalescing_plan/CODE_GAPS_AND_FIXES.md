# Coalescing implementation — code gaps and fixes

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  
**Date:** 2026-02-13

Step-by-step review of created/changed code for the coalescing plan. Gaps found and fixes applied.

---

## Summary

| Severity | Count | Status |
|----------|--------|--------|
| **Fixed** | 1 | Futures not set on batch submit error (router) |
| **Optional / deferred** | 4 | TTL, config caching, timing step 11, malformed result |
| **Intentional** | 1 | `pass` in embed_command validate_params (both text/texts) |

---

## Step-by-step review

### Step 1 — Config schema

- **embed/config/coalescing_config.py:** Complete. All fields, validators, docstrings.
- **embed/config/config_manager.py:** ConfigModel.coalescing, model_validator coalescing_requires_queue.
- **scripts/generate_configs.py:** Coalescing section with defaults.
- **scripts/validate_all_configs.py**, **tests/test_config_validation.py:** Coalescing validation and Phase 4 (coalescing ⇒ queue_manager).

**Gaps:** None.

---

### Step 2 — Config integration

- **ConfigManager.get_coalescing_config(), create_default_config():** Implemented and tested.

**Gaps:** None.

---

### Step 3 — Logical job store

- **embed/coalescing/logical_job_store.py:** All API methods, thread-safe, docstrings.

**Gaps (deferred):**

- **TTL/retention:** Store never removes old logical/physical entries. Plan defers to “align with completed_job_retention_seconds or separate TTL”. Optional cleanup can be added later.

---

### Step 4 — Coalescer buffer

- **embed/coalescing/coalescer_buffer.py:** CoalescerBuffer, BatchDescriptor, add_request, flush conditions (max_texts, single request, window, max_wait_sec), homogeneity key.

**Gaps:** None.

---

### Step 5 — Coalescer payload

- **embed/coalescing/payload_builder.py:** build_batch_payload, _coalesced_slices.
- **embed/commands/embed_command.py:** validate_params strips _coalesced_slices (line 161) before schema validation; line 156–158: if both `text` and `texts` provided, prefer `texts` — branch uses `pass` (no-op, correct).

**Gaps:** None.

---

### Step 6 — Coalescer submit

- **embed/coalescing/coalescer_submit.py:** submit_batch builds payload, calls queue_submit, register_logical_jobs, returns (logical_ids, None) or ([], error_dict). Exception from queue_submit caught and returned as error.

**Gaps:** None.

---

### Step 7 — Coalescer completion

- **embed/commands/embed_job_status_command.py:** Option B (lazy): on first status read for a logical job, queue_get_job_status(physical_id); when completed, get full result, set_physical_result(physical_id, embed_data), then _slice_result and return.

**Gaps (optional):**

- **Malformed physical result:** If queue returns status "completed" but result is missing or not dict, code uses `embed_data = {}` and still calls set_physical_result(physical_id, {}). Clients get empty slice. Optionally could call set_physical_error instead when result shape is invalid.

---

### Step 8 — embed_job_status

- **embed/commands/embed_job_status_command.py:** execute() gets store, get_logical_job(job_id); if entry → _resolve_logical_job (pending/slice/error); else _delegate_physical_job. _slice_result, _delegate_physical_job for unknown/queue errors.

**Gaps:** None. Edge (queue returns unexpected type) handled by fallback to "not found".

---

### Step 9 — Embed command routing

- **embed/commands/embed_router.py:** _get_coalescing_config(), _get_buffer(), _queue_submit_embed, _start_job_background; EmbedRouterCommand.execute() routes to _execute_coalescing or _execute_single_job. When coalescing: add_request, on descriptor submit_batch, set futures with logical_ids, return job_id.

**Gap (fixed):**

- **Futures not set on submit error:** When submit_batch returned err, the code returned ErrorResult for the current request but did not set descriptor.futures. Other requests in the same batch would wait until timeout. **Fix:** On err is not None, set all descriptor.futures with set_exception(RuntimeError(...)) so all waiters get the error immediately.

**Optional:**

- **_get_coalescing_config()** creates ConfigManager and load_from_file on every call. Could cache config (e.g. by config file mtime) to avoid repeated I/O. Not required by plan.

---

### Step 10 — Tests and validation

- **tests/integration/test_coalescing_embed.py**, **test_coalescing_server.py:** Added. Real server uses temp config, port 8001, programmatic start/stop.
- **docs/coalescing_plan/10_tests_validation.md:** Run commands documented.

**Gaps:** None in code. Test environment (adapter config API) may cause conftest/client fixture to fail; see STEPS_VERIFICATION_REPORT.md.

---

### Step 11 — Timing and timing_stats (not implemented)

- **embed/commands/embed_command.py:** record_timing(entry) is called but entry does **not** include `coalesced_batch` or `logical_request_count` (Step 11 not done).
- **embed/commands/timing_stats_command.py:** No coalesced_batch_count / non_coalesced_count (Step 11 not done).

**Gap:** Step 11 is planned but not implemented. To complete: add coalesced_batch and logical_request_count to timing entry when _coalesced_slices present; extend timing_stats as in 11_timing_and_timing_stats.md.

---

## Other files checked

- **embed/main.py:** Registers EmbedRouterCommand as "embed", EmbedExecuteCommand as "embed_execute". Line 26 `pass` is inside try/except for multiprocessing.set_start_method — intentional.
- **embed/commands/__init__.py:** Auto-registers embed_execute, models, embed_job_status, timing_stats in child processes. Does not register "embed" (router only in main process) — correct.
- **embed/coalescing/__init__.py:** Exports store, buffer types, build_batch_payload, submit_batch, get/set_logical_job_store. Complete.

---

## Verification after fix

- **embed_router.py:** On submit_batch error, all descriptor.futures are now set with set_exception so waiters fail fast instead of timing out.
- Run: `pytest tests/unit/test_coalescer_submit.py tests/unit/test_commands.py -v` (and coalescing unit tests) to ensure no regressions.
