# Logical duplicates, project-rule and plan deviations

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  
**Date:** 2026-02-13

Report of logical duplicates in the codebase and deviations from project rules and the coalescing plan (`docs/coalescing_plan/`).

**Methodology:** Duplicates were identified using the **code_mapper** indices in `code_analysis/`:
- **code_map.yaml** — classes, methods, and standalone functions with file path, line, and docstring; used to find same-name methods and similar docstrings (e.g. "Load config from CONFIG_FILE", "Validate and normalize command parameters").
- **method_index.yaml** — method names grouped by class; used to see which classes implement `validate_params`, `load_from_file`, `get_*_config`, etc.
- **code_issues.yaml** — current issue counts (files_too_large, docstrings, etc.); no duplicate detection, used for rule compliance.

Search approach: grep in code_map.yaml for `load_from_file`, `get_coalescing_config`, `ensure_timing_config_loaded`, `validate_params`, `texts_from_kwargs`, `record_timing`; then for `validate_*`, `get_config` to find validation and config getters; method_index to list all classes with `validate_params` (EmbedCommand, EmbedJobStatusCommand, EmbedRouterCommand, TimingStatsCommand) and ConfigManager methods (load_from_file, get_coalescing_config).

---

## 1. Logical duplicates (from code_mapper indices)

### 1.1 Config loading from CONFIG_FILE (two different mechanisms)

**Index references (code_map.yaml):**
- `embed/commands/embed_router.py:_get_coalescing_config` — docstring: "Load config from CONFIG_FILE and return coalescing config if present."
- `embed/commands/embed_command_helpers.py:ensure_timing_config_loaded` — docstring: "In spawn/worker process, load timing config from CONFIG_FILE if not set."
- `embed/config/config_manager.py:load_from_file` — used by _get_coalescing_config; no direct use in helpers.

**Implementation:**
- **embed/commands/embed_router.py:** `_get_coalescing_config()` uses `ConfigManager()` + `load_from_file(config_file)` to read `CONFIG_FILE` and return coalescing config. Called on every coalescing path (execute, buffer creation, wait timeout).
- **embed/commands/embed_command_helpers.py:** `ensure_timing_config_loaded()` reads `CONFIG_FILE` via manual `open` + `json.load`, then takes only `embedding` section for timing config.

**Effect:** Two different ways to read the same config file; no shared loader. Plan (CODE_GAPS_AND_FIXES) already notes that `_get_coalescing_config()` could be cached (e.g. by file mtime); optional. Unifying config read (e.g. one place that loads once or with cache) would remove duplication.

### 1.2 Default `error_policy = "fail_fast"` in several places

**Index references (method_index.yaml):** EmbedCommand, EmbedRouterCommand; coalescer_buffer and payload_builder use `error_policy` in key/params. code_map lists embed_command_executor as separate module (no method_index entry for it; it’s in the same flow).

**Implementation (grep / code):**
- **embed/commands/embed_command.py:** `error_policy = validated_params.get("error_policy") or "fail_fast"`
- **embed/commands/embed_router.py:** `error_policy = params.get("error_policy") or "fail_fast"`
- **embed/commands/embed_command_executor.py:** `error_policy = validated_params.get("error_policy") or "fail_fast"`

**Effect:** Same default repeated in three files. Low risk; could be a single constant (e.g. in `embed_command_schema.py` or a small constants module) for consistency.

### 1.3 Normalization of `text` → `texts` vs extraction for timing

**Index references (code_map.yaml):**
- `embed/commands/embed_command.py:validate_params` — "Validate and normalize command parameters"; normalizes text/texts inside.
- `embed/commands/embed_command_helpers.py:texts_from_kwargs` — docstring: "Extract list of texts from command kwargs (texts or text)."

**Implementation:**
- **embed/commands/embed_command.py:** In `validate_params()`, if `"text" in params and "texts" not in params` then `params["texts"] = [params["text"]]`; if both present, `text` is popped so schema sees only `texts`.
- **embed/commands/embed_command_helpers.py:** `texts_from_kwargs(kwargs)` returns `kwargs["texts"]` if list, else `[kwargs["text"]]` if `text` is str, else None.

**Effect:** Two places encode the rule “single text can be passed as `text`, multiple as `texts`”. Logic is aligned but duplicated; a single helper used by both validation and timing would avoid drift.

### 1.4 validate_params across commands (from method_index / code_map)

**Index references (method_index.yaml):** EmbedCommand, EmbedJobStatusCommand, EmbedRouterCommand, TimingStatsCommand each list `validate_params`. code_map.yaml docstrings:
- **embed/commands/embed_command.py:validate_params** — "Validate and normalize command parameters. Args: params: Raw parameters from request Returns: Dict[str, Any]: Validated and normalized parameters"
- **embed/commands/embed_job_status_command.py:validate_params** — same wording (job_id-specific logic).
- **embed/commands/embed_router.py:validate_params** — "Reuse EmbedCommand validation." (delegation, not duplicate.)
- **embed/commands/timing_stats_command.py:validate_params** — "Validate timing_stats params: optional file_path must be non-empty string."

**Conclusion:** EmbedCommand and EmbedJobStatusCommand share the same docstring pattern but different validation logic (embed vs job_id). No code duplicate; only the pattern is repeated. Router correctly delegates; timing_stats has its own rules.

### 1.5 validate_* in embedding_service vs embedding_validation (from code_map)

**Index references (code_map.yaml):**
- **embed/services/embedding_service.py:** validate_dimension, validate_model, validate_texts — docstrings state "delegates to embedding_validation".
- **embed/services/embedding_validation.py:** validate_dimension, validate_model, validate_texts — actual validation logic.

**Conclusion:** Not duplicates; EmbeddingService is a facade that delegates to embedding_validation. method_index shows both modules listing these methods; code_map confirms delegation in docstrings.

---

## 2. Deviations from plan (docs/coalescing_plan)

### 2.1 Backward compatibility (plan: “No backward compatibility”)

**Plan (00_overview.md):** “No backward compatibility. Do not support old formats, old APIs, or missing fields. Current schema and contract only.”

**Code:** `embed/commands/embed_command.py` line 76:

```python
# Support both 'text' and 'texts' parameters for backward compatibility
if "text" in params and "texts" not in params:
    params["texts"] = [params["text"]]
```

**Deviation:** The comment explicitly mentions “backward compatibility”. The plan forbids supporting old formats. If the current API contract is “only `texts`”, then accepting `text` is backward compat and should be removed or the contract/doc updated. If the contract is “we accept both `text` and `texts`”, then the comment should be rephrased (e.g. “Support both 'text' and 'texts' per API contract”) and the plan clarified.

**Recommendation:** Either drop support for `text` and use only `texts`, or keep both but remove the “backward compatibility” wording and document as current contract.

### 2.2 Legacy / fallback code (plan: “No fallbacks to old code”)

**Plan (00_overview.md):** “No fallbacks to old code. No legacy paths, no 'if missing then assume X'. One clear code path per feature.”

**Code:** `embed/services/embedding_initializer.py`:

- Lines 51–52: “Try to load SimpleConfig first (new format), fallback to legacy Config”.
- Lines 140–167: “if not simple_config_loaded: Fallback to legacy Config”, MCP Config, Docker path, “Fallback to global config”.
- Lines 168–188: On exception, again “Fallback to legacy Config”, Docker path, global config.

**Deviation:** Multiple fallbacks and legacy Config paths. Plan requires one clear path and no legacy branches.

**Recommendation:** Align with plan: single config source (e.g. CONFIG_FILE / ConfigManager or agreed simple format); remove or clearly scope legacy/MCP/Docker fallbacks, or document an explicit exception in the plan.

### 2.3 Conftest: coalescing disabled in test config (plan Step 09)

**Plan (00_overview.md, Test refactoring):** “Step 09: set coalescing disabled in test config so existing tests keep inline result or one job_id.”

**Code:** `tests/conftest.py`: Test config does not include a `coalescing` section. When `embed_router` runs, it reads CONFIG_FILE (temp test config); ConfigModel default for `coalescing` is `enabled=False`, so coalescing is effectively off.

**Deviation:** Plan asks to “set coalescing disabled” explicitly. Relying on default is acceptable behaviour but not an explicit “coalescing disabled” in test config.

**Recommendation:** Add to test config: `"coalescing": {"enabled": false, ...}` (with plan defaults) so the intent is explicit and robust to future default changes.

### 2.4 Client “fallback” wording

**Code:** `embed/client/embedding_client.py` line 289: “Fallback to embed_job_status for custom queue commands”.

**Note:** This is a reserve path when `queue_get_job_status` is not available (e.g. custom queue), not a legacy API. Plan discourages “fallback” in general; the behaviour may be correct but the wording could be clarified (e.g. “Use embed_job_status when queue does not provide queue_get_job_status”).

---

## 3. Deviations from project rules

### 3.1 Static checks and code_mapper

**Rules:** After production code, run black, flake8, mypy; fix all errors. Run code_mapper after each block of changes.

**Current state (as of this report):**

- black: not re-run in this session; STEPS_VERIFICATION_REPORT mentions black ✅.
- flake8: `flake8 embed/ tests/ --max-line-length=100` — **0 errors** (previously report mentioned ~152 lines project-wide; may be fixed).
- mypy: `mypy embed/` — **Success: no issues** (previously report mentioned 1 error in `embed/__init__.py`; may be fixed).
- code_analysis/code_issues.yaml: **0 issues** (files_too_large, docstrings, etc. clean).

So static checks and code_mapper currently comply; any remaining gaps are from the verification report (e.g. tests failing in test_commands.py, coverage not re-run).

### 3.2 File size and docstrings

**Rules:** File size ≤ 350–400 lines; one class per file where applicable; file/class/method docstrings with Author/email in file header.

**Current state:** code_issues.yaml reports no files_too_large, no missing docstrings. All embed production files checked have Author/email in header. No deviation identified.

### 3.3 Imports and server

**Rules:** Imports only at top (except lazy load); only hypercorn (no uvicorn).

**Note:** No uvicorn usage found; hypercorn used for real-server tests. Imports in the reviewed files are at top. No deviation identified.

---

## 4. Summary table

| Category                    | Item                                      | Severity   | Action |
|----------------------------|-------------------------------------------|------------|--------|
| Duplicate                   | Config load: router vs timing helper      | Low        | Optional: unify or cache. |
| Duplicate                   | error_policy default in 3 places          | Low        | Optional: single constant. |
| Duplicate                   | text/texts handling in 2 places           | Low        | Optional: single helper. |
| Plan                       | “Backward compatibility” for `text`       | Medium     | Remove wording or drop `text`; align with plan. |
| Plan                       | Legacy/fallback in embedding_initializer  | High       | Single config path or document exception. |
| Plan                       | Conftest coalescing explicit off          | Low        | Add `coalescing.enabled: false` to test config. |
| Plan                       | Client “fallback” wording                 | Low        | Clarify comment. |
| Project rules               | Static checks / code_mapper / file size   | —          | Currently compliant. |

---

## 5. References

**Plan and verification:**
- Plan overview: `docs/coalescing_plan/00_overview.md`
- Verification: `docs/coalescing_plan/STEPS_VERIFICATION_REPORT.md`
- Gaps and fixes: `docs/coalescing_plan/CODE_GAPS_AND_FIXES.md`

**code_mapper indices (used for duplicate search):**
- `code_analysis/code_map.yaml` — classes, methods, functions with file, line, docstring.
- `code_analysis/method_index.yaml` — method names by class (e.g. validate_params, load_from_file, get_coalescing_config).
- `code_analysis/code_issues.yaml` — issue counts (files_too_large, docstrings, etc.).

**Update indices after code changes:** from project root with `.venv` activated:
`PYTHONPATH=<project_root> code_mapper -r embed/`

---

## 6. Fixes applied (2026-02-13)

- **Config loading:** Added `embed/config/embed_config_loader.py` using `mcp_proxy_adapter.core.config.config_loader.ConfigLoader`; single cache by path+mtime. `get_coalescing_config()` and `get_embedding_section()` used by router and timing helper. `ConfigManager.load_from_file()` now uses adapter ConfigLoader instead of local `open`+`json.load`.
- **Backward compatibility wording:** Replaced with “Normalize text/texts to texts (single helper for API contract)”; `validate_params` uses `texts_from_kwargs(params)` and sets `params["texts"]`.
- **error_policy default:** `DEFAULT_ERROR_POLICY = "fail_fast"` in `embed_command_schema.py`; used in `embed_command.py`, `embed_router.py`, `embed_command_executor.py`.
- **Conftest:** Added explicit `"coalescing": {"enabled": false, ...}` to test config.
- **Client comment:** Reworded to “Use embed_job_status when queue does not provide queue_get_job_status”.
