# Coalescing plan — verification of completion metrics (Steps 1–9)

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com  
**Date:** 2026-02-13

This document records the result of checking each step's completion metric against the current codebase.

---

## Summary table

| Step | Step-specific | Static checks | All tests | Real server test | Overall |
|------|---------------|---------------|-----------|------------------|---------|
| 01   | ✅            | ⚠️            | ⚠️        | ✅ (Step 10)     | **Partial** |
| 02   | ✅            | ⚠️            | ⚠️        | ✅ (Step 10)     | **Partial** |
| 03   | ✅            | ⚠️            | ⚠️        | ✅ (Step 10)     | **Partial** |
| 04   | ✅            | ⚠️            | ⚠️        | ✅ (Step 10)     | **Partial** |
| 05   | ✅            | ⚠️            | ⚠️        | ✅ (Step 10)     | **Partial** |
| 06   | ✅            | ⚠️            | ⚠️        | ✅ (Step 10)     | **Partial** |
| 07   | ✅            | ⚠️            | ⚠️        | ✅ (Step 10)     | **Partial** |
| 08   | ✅            | ⚠️            | ⚠️        | ✅ (Step 10)     | **Partial** |
| 09   | ✅            | ⚠️            | ⚠️        | ✅ (Step 10)     | **Partial** |
| 11   | ✅            | ⚠️            | ⚠️        | —                | **Partial** |

**Common gaps (project-wide):**

- **Static checks:** black ✅; flake8 ⚠️ (~152 lines, many in files unrelated to coalescing); mypy ⚠️ (1 error: `embed/__init__.py` duplicate module path).
- **All tests passing:** ⚠️ — 2 failures in `tests/unit/test_commands.py` (mock `device` argument in EmbedCommand tests), not caused by coalescing code.
- **Coverage ≥ 90%:** Not re-run for this verification; plan requires it per step.

---

## Step 1: Config schema

### Step-specific ✅

- **CoalescingConfig** (`embed/config/coalescing_config.py`): `enabled`, `coalescing_window_sec`, `coalescing_max_texts`, `coalescing_max_wait_sec` with defaults and validators.
- **ConfigModel** has `coalescing: Optional[CoalescingConfig]` with default (enabled=False) in `config_manager.py`.
- Config without `coalescing` loads (default); config with `"coalescing": {"enabled": true, ...}` validated.
- **scripts/generate_configs.py:** includes `coalescing` section with defaults (lines 216–221).
- **tests/test_config_validation.py** and **scripts/validate_all_configs.py:** validate optional `coalescing`, reject invalid values (e.g. negative window_sec), Phase 4 coalescing ⇒ queue_manager.

### Static checks ⚠️

- black: ✅ (--check passed).
- flake8: ⚠️ many errors project-wide (not only in step 1 files).
- mypy: ⚠️ 1 error (embed package path), blocks full check.
- code_mapper: ✅ (indices present in `code_analysis/`).

### Tests ⚠️

- **tests/unit/test_coalescing_config.py:** present and passing (14 tests).
- Full suite: 2 failures in `test_commands.py` (unrelated to coalescing).

### Real server test ✅

- Covered by Step 10: `tests/integration/test_coalescing_server.py` starts server with config that includes `coalescing` (on/off) on port 8001.

---

## Step 2: Config integration

### Step-specific ✅

- **ConfigManager.get_coalescing_config()** in `config_manager.py` (returns Optional[CoalescingConfig]).
- **create_default_config()** includes `coalescing` with safe defaults in `config_manager.py`.
- **tests/unit/test_coalescing_config.py:** `get_coalescing_config_after_load`, `get_coalescing_config_raises_when_not_loaded`, `create_default_config_includes_coalescing`, load with/without coalescing section.

### Static checks / All tests / Real server

- Same as Step 1 (⚠️ static/tests; ✅ real server via Step 10).

---

## Step 3: Logical job store

### Step-specific ✅

- **LogicalJobStore** (`embed/coalescing/logical_job_store.py`): `register_logical_jobs`, `get_logical_job`, `set_physical_result`, `set_physical_error`, `get_physical_result`, `get_physical_error`.
- Thread-safe (`threading.Lock()`).
- **tests/unit/test_logical_job_store.py:** register N logical jobs; set/get physical result and error; get_logical_job; concurrent test.

### Static checks / All tests / Real server

- Same pattern: ✅ step-specific unit tests (9 tests); ⚠️ static; ⚠️ 2 failures elsewhere; ✅ real server (Step 10).

---

## Step 4: Coalescer buffer

### Step-specific ✅

- **CoalescerBuffer** and **BatchDescriptor** in `embed/coalescing/coalescer_buffer.py`: merged texts, counts, homogeneity key, futures.
- **tests/unit/test_coalescer_buffer.py:** single-request flush, max_texts flush, window flush, homogeneity buckets (7 tests).

### Static checks / All tests / Real server

- Same: ✅ step-specific; ⚠️ static/suite; ✅ real server.

---

## Step 5: Coalescer payload

### Step-specific ✅

- **build_batch_payload(descriptor)** in `embed/coalescing/payload_builder.py`: returns params with `texts` and `_coalesced_slices`; sum(slices) = len(texts).
- **EmbedCommand** accepts `_coalesced_slices` (strip in validate_params, see `embed_command.py` line 161).
- **tests/unit/test_coalescer_payload.py:** payload shape, _coalesced_slices, validate_params acceptance (3 tests).

### Static checks / All tests / Real server

- Same pattern.

---

## Step 6: Coalescer submit

### Step-specific ✅

- **submit_batch** in `embed/coalescing/coalescer_submit.py`: build payload, queue_submit, register_logical_jobs, return N logical_job_ids in order; on failure no register, return error.
- Slices from BatchDescriptor counts (cumulative start_index, count).
- **tests/unit/test_coalescer_submit.py:** submit_batch success (two logical ids, single request), submit failure returns error (3 tests).

### Static checks / All tests / Real server

- Same pattern.

---

## Step 7: Coalescer completion

### Step-specific ✅

- **Option B (lazy):** Implemented in `embed/commands/embed_job_status_command.py`. For a logical job_id, first read calls `queue_get_job_status(physical_id)`; when status is completed, code gets full result, calls `store.set_physical_result(physical_id, embed_data)`, then slices and returns. No separate completion module.
- Success: full result (embeddings, results, model, dimension, device) stored by physical_job_id. Failure: `set_physical_error(physical_id, error_info)`.

### Static checks / All tests / Real server

- Same pattern; completion covered by Step 8 unit tests and Step 10 real-server test.

---

## Step 8: embed_job_status logical resolution

### Step-specific ✅

- **EmbedJobStatusCommand.execute():** gets store via `get_logical_job_store()`; `get_logical_job(job_id)`; if logical entry: physical_id, start_index, count; check get_physical_error / get_physical_result; if result missing, call queue_get_job_status, on completed call set_physical_result then slice; return pending/slice/error. If not logical, delegate to `_delegate_physical_job`.
- **tests/unit/test_commands.py** class **TestEmbedJobStatusCommand:** logical job with result in store returns slice; logical job with physical error returns error; (and other cases).
- **get_logical_job_store** exposed in `embed/coalescing/__init__.py`.

### Static checks / All tests / Real server

- Same; ✅ step-specific tests; ⚠️ 2 failures in TestEmbedCommand (mock signature).

---

## Step 9: Embed command routing

### Step-specific ✅

- **EmbedRouterCommand** in `embed/commands/embed_router.py`: when coalescing_enabled and queue_manager present → `_execute_coalescing` (buffer, submit_batch, return logical_job_id); else `_execute_single_job` (one queue job, physical job_id). Response shape same (job_id, status, ...).
- Edge: coalescing enabled but queue disabled → `use_coalescing` is False (queue_manager is None), so single-job path used; no crash.
- **embed/main.py** registers **EmbedRouterCommand** as "embed" (router), and **EmbedExecuteCommand** (EmbedCommand) as "embed_execute" for queue workers.

### Static checks / All tests / Real server

- Same; ✅ real server in Step 10 (coalescing off: one job_id, poll, result; coalescing on: K requests, K logical_job_ids, poll each, slices).

---

## Step 11: Timing and timing_stats

### Step-specific ✅

- **Timing record:** When payload has `_coalesced_slices`, the record written by `run_embed_execute` (in `embed/commands/embed_command_executor.py`) includes `coalesced_batch: True` and `logical_request_count: len(slices)`. Otherwise `coalesced_batch: False`. Failed requests (`record_timing_on_error` in `embed_command_helpers.py`) always set `coalesced_batch: False`. Implementation is in the executor (success path) and helpers (error path); the plan referred to `embed_command.py` before the executor split.
- **timing_recorder.record():** Docstring documents required `coalesced_batch: bool` and `logical_request_count: int` when coalesced. No legacy handling.
- **timing_stats _compute_stats:** Every record assumed to have `coalesced_batch` (bool). Output includes `coalesced_batch_count`, `non_coalesced_count`, and `logical_request_count_per_record` (stats over coalesced records). No fallback for missing keys.

### Test refactoring ✅

- **Unit:** `tests/unit/test_timing_stats.py`: (1) When `run_embed_execute` is called with `_coalesced_slices=[2, 3]`, the captured timing entry has `coalesced_batch=True` and `logical_request_count=2`. (2) When `_coalesced_slices` is absent, entry has `coalesced_batch=False` and no `logical_request_count`. (3) `_compute_stats(records)` with records that have `coalesced_batch` true/false returns correct `coalesced_batch_count` and `non_coalesced_count`; empty records; all coalesced; all non-coalesced. No tests for missing key or old format.

### Static checks ⚠️

- **black:** ✅ (`black embed/ tests/ --check` passed).
- **flake8:** ⚠️ Project-wide errors remain (unrelated to Step 11 files). Step 11–touched files: executor, helpers, timing_stats_command, timing_recorder, test_timing_stats — clean.
- **mypy:** ⚠️ One project-wide error (`embed/__init__.py` duplicate module). Step 11 modules not checked in isolation.
- **code_mapper:** ✅ `PYTHONPATH=<root> code_mapper -r embed/` → 0 issues.

### All tests / Coverage ⚠️

- **Step 11 tests:** ✅ All 6 tests in `tests/unit/test_timing_stats.py` pass. Related unit tests (test_coalescing_config, test_results, test_config_manager) pass.
- **Full suite:** ⚠️ Collection errors in other tests (missing adapter example path, Config/ProtocolManager API, embed.server missing, conftest/torch docstring). Not caused by Step 11.
- **Coverage ≥ 90%:** Not re-run; full suite does not complete due to collection errors. Step 11–specific code is covered by the 6 unit tests.

### Commit ✅

- Step 11 committed: `Step 11: timing coalesced_batch and timing_stats`.

### Real server test (Step 11)

- Step 11 does not add a new real-server scenario; timing is observed when coalesced batches run (Step 10 real-server tests cover that flow). No separate “real server for timing_stats” requirement in the step.

---

## Recommendations

1. **Static checks:** Fix mypy `embed/__init__.py` duplicate module (e.g. `--explicit-package-bases` or MYPYPATH). Fix or exclude flake8 errors in non-coalescing files so project meets “zero errors” per plan.
2. **Tests:** Fix 2 failing tests in `tests/unit/test_commands.py` (EmbedCommand mock: add `device` argument to mock_get_embeddings or adjust caller).
3. **Coverage:** Run `pytest --cov=embed --cov-report=term-missing` and bring any file below 90% up (per step completion metric).
4. **Conftest:** Plan Step 9 asks for coalescing disabled in test config; conftest currently does not set it (adapter config API differs). When adapter supports it, add `coalescing.enabled: false` (and queue_manager if needed) so tests that assume inline result or one job_id remain valid.

---

## Code_mapper issues

The `code_analysis/code_issues.yaml` file lists all findings. **Run code_mapper with PYTHONPATH** so that `embed` is importable and invalid_imports disappear:

```bash
cd /home/vasilyvz/projects/embed && source .venv/bin/activate && PYTHONPATH=/home/vasilyvz/projects/embed code_mapper -r embed/
```

Summary (after docstring fixes and PYTHONPATH run):

| Category | Count | Action |
|----------|--------|--------|
| **invalid_imports** | 0 | Use `PYTHONPATH=<project_root>` when running code_mapper. |
| **files_too_large** | 0 | **Fixed.** service_manager split into constants, checker, main; embedding_service into validation + encode; embed_command into helpers + executor. All files ≤400 lines. |
| **classes_without_docstrings** | 0 | Fixed for coalescing and touched files. |
| **files_without_docstrings** | 0 | Fixed (e.g. service_manager.py). |
| **methods_without_docstrings** | 0 | Fixed for touched files (signal_handler, encode_wrapper, _median, etc.). |

**Done in first pass:** Docstrings; config split (config_schema, config_defaults); model_server CLI (model_server_main.py). **Done in second pass:** service_manager, embedding_service, embed_command split. Code_mapper with PYTHONPATH yields 0 issues.

**Done (second pass):** Split service_manager (constants, checker, main), embedding_service (validation, encode), embed_command (helpers, executor). Code_mapper reports 0 issues when run with PYTHONPATH.

---

## Verification command reference

Run from project root with `.venv` activated:

- **Black:** `black embed/ tests/ --check`
- **Flake8:** `flake8 embed/ tests/ --max-line-length=100`
- **Mypy:** `mypy embed/`
- **Code_mapper (mandatory at end of each step):** `code_mapper -r embed/`  
  Updates `code_analysis/code_map.yaml`, `code_analysis/code_issues.yaml`, `code_analysis/method_index.yaml`.
- Coalescing-related tests:  
  `pytest tests/unit/test_coalescing_config.py tests/unit/test_logical_job_store.py tests/unit/test_coalescer_buffer.py tests/unit/test_coalescer_payload.py tests/unit/test_coalescer_submit.py tests/unit/test_commands.py tests/test_config_validation.py -v`
- Real-server coalescing tests:  
  `pytest tests/integration/test_coalescing_server.py -v`  
  (Server started programmatically on port 8001 via `python -m embed.main`.)
