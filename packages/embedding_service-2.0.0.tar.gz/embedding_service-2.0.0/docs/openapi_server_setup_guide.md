# OpenAPI Server Setup Guide

**Author:** Vasiliy Zdanovskiy  
**Email:** vasilyvz@gmail.com

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Basic Configuration](#basic-configuration)
4. [Security Profiles](#security-profiles)
5. [mTLS Configuration](#mtls-configuration)
6. [Proxy Registration](#proxy-registration)
7. [Certificate Management](#certificate-management)
8. [Troubleshooting](#troubleshooting)
9. [Examples](#examples)
10. [Best Practices](#best-practices)

## Overview

This guide provides comprehensive instructions for setting up an OpenAPI server that can register with the MCP Proxy Adapter. The server supports various security profiles including HTTP, HTTPS, and mTLS authentication.

## Prerequisites

- Python 3.8+
- Virtual environment activated
- MCP Proxy Adapter installed
- SSL certificates (for HTTPS/mTLS profiles)
- Docker (for containerized deployment)

## Basic Configuration

### 1. Minimal Configuration

Create a basic configuration file `config/openapi_server_minimal.json`:

```json
{
  "uuid": "openapi-server-minimal-001",
  "server": {
    "host": "0.0.0.0",
    "port": 6001,
    "debug": false,
    "log_level": "INFO"
  },
  "logging": {
    "level": "INFO",
    "console_output": true,
    "file_output": false
  },
  "interfaces": {
    "openapi": {
      "enabled": true,
      "host": "0.0.0.0",
      "port": 6001,
      "protocol": "https",
      "description": "OpenAPI server with mTLS for proxy registration",
      "security": {
        "enabled": true,
        "auth": {
          "enabled": true,
          "methods": ["certificate"],
          "certificate": {
            "enabled": true,
            "ca_cert": "mtls-certs/mtls_certificates/ca/ca.crt",
            "verify_client": true
          }
        },
        "ssl": {
          "enabled": true,
          "cert_file": "mtls-certs/mtls_certificates/server/primitive-server.pem",
          "key_file": "mtls-certs/mtls_certificates/server/primitive-server.key",
          "ca_cert": "mtls-certs/mtls_certificates/ca/ca.crt",
          "verify_client": true,
          "client_cert_required": true,
          "min_tls_version": "TLSv1.2"
        },
        "permissions": {
          "enabled": false
        },
        "rate_limit": {
          "enabled": false
        },
        "public_paths": [
          "/health"
        ]
      }
    }
  },
  "proxy_registration": {
    "enabled": true,
    "auth_method": "mtls",
    "server_url": "https://localhost:3004",
    "mtls": {
      "enabled": true,
      "client_cert": "mtls-certs/mtls_certificates/client/primitive-server.pem",
      "client_key": "mtls-certs/mtls_certificates/client/primitive-server.key",
      "ca_cert": "mtls-certs/mtls_certificates/ca/ca.crt",
      "verify_server": true
    },
    "proxy_info": {
      "name": "openapi_server_minimal",
      "capabilities": [
        "openapi",
        "mtls_auth"
      ],
      "endpoints": {
        "openapi": "https://172.20.0.1:6001"
      }
    },
    "heartbeat": {
      "enabled": true,
      "interval": 30
    }
  }
}
```



### 2. Key Configuration Parameters

#### Server Configuration
- `host`: Server bind address (use `0.0.0.0` for all interfaces)
- `port`: Server port number
- `debug`: Enable debug mode
- `log_level`: Logging level (DEBUG, INFO, WARNING, ERROR)

#### Interface Configuration
- `enabled`: Enable the interface
- `protocol`: Protocol type (http, https)
- `security.enabled`: Enable security features
- `security.ssl.enabled`: Enable SSL/TLS
- `security.auth.enabled`: Enable authentication

#### Proxy Registration
- `enabled`: Enable proxy registration
- `auth_method`: Authentication method (token, mtls)
- `server_url`: Proxy server URL
- `heartbeat.enabled`: Enable heartbeat
- `heartbeat.interval`: Heartbeat interval in seconds

## Security Profiles

### 1. HTTP (No Security)

```json
{
  "interfaces": {
    "openapi": {
      "protocol": "http",
      "security": {
        "enabled": false
      }
    }
  },
  "proxy_registration": {
    "auth_method": "none"
  }
}
```



### 2. HTTPS (Server Certificate Only)

```json
{
  "interfaces": {
    "openapi": {
      "protocol": "https",
      "security": {
        "enabled": true,
        "ssl": {
          "enabled": true,
          "cert_file": "certs/server.crt",
          "key_file": "certs/server.key",
          "verify_client": false
        }
      }
    }
  }
}
```



### 3. mTLS (Mutual TLS)

```json
{
  "interfaces": {
    "openapi": {
      "protocol": "https",
      "security": {
        "enabled": true,
        "ssl": {
          "enabled": true,
          "cert_file": "certs/server.crt",
          "key_file": "certs/server.key",
          "ca_cert": "certs/ca.crt",
          "verify_client": true,
          "client_cert_required": true
        }
      }
    }
  },
  "proxy_registration": {
    "auth_method": "mtls",
    "mtls": {
      "enabled": true,
      "client_cert": "certs/client.crt",
      "client_key": "certs/client.key",
      "ca_cert": "certs/ca.crt"
    }
  }
}
```



## mTLS Configuration

### 1. Certificate Requirements
For mTLS to work properly, you need:

- **CA Certificate**: Root certificate authority
- **Server Certificate**: Signed by CA, for server authentication
- **Client Certificate**: Signed by CA, for client authentication
- **Private Keys**: Corresponding private keys for certificates

### 2. Certificate Paths
Ensure certificate paths are correct in your configuration:

```json
{
  "security": {
    "ssl": {
      "cert_file": "mtls-certs/mtls_certificates/server/primitive-server.pem",
      "key_file": "mtls-certs/mtls_certificates/server/primitive-server.key",
      "ca_cert": "mtls-certs/mtls_certificates/ca/ca.crt"
    }
  },
  "proxy_registration": {
    "mtls": {
      "client_cert": "mtls-certs/mtls_certificates/client/primitive-server.pem",
      "client_key": "mtls-certs/mtls_certificates/client/primitive-server.key",
      "ca_cert": "mtls-certs/mtls_certificates/ca/ca.crt"
    }
  }
}
```



### 3. Certificate Validation
The server validates client certificates against the CA certificate. Ensure:

- Client certificates are signed by the same CA
- Certificates are not expired
- Certificate chain is complete
- Private keys match the certificates

## Proxy Registration

### 1. Registration Process
The server automatically registers with the proxy on startup:

1. **Health Check**: Proxy checks server health at `/health`
2. **Registration**: Server sends registration data to proxy
3. **Heartbeat**: Server sends periodic heartbeat signals
4. **Deregistration**: Server deregisters on shutdown

### 2. Registration Data
```json
{
  "server_id": "openapi_server_minimal",
  "server_url": "https://172.20.0.1:6001",
  "name": "openapi_server_minimal",
  "capabilities": ["openapi", "mtls_auth"],
  "endpoints": {
    "openapi": "https://172.20.0.1:6001"
  }
}
```



### 3. Network Configuration
#### Docker Environment

- **Proxy URL**: `https://localhost:3004` (mapped port)
- **Server URL**: `https://172.20.0.1:6001` (host IP in Docker network)

#### Local Environment

- **Proxy URL**: `https://localhost:3004`
- **Server URL**: `https://localhost:6001`

## Certificate Management

### 1. Certificate Generation
Use the provided certificate generation scripts:

```bash
# Generate CA certificate
./scripts/generate_test_certs.sh

# Or use Python script
python scripts/generate_certificates.py
```



### 2. Certificate Types
- **CA Certificate**: Root authority certificate
- **Server Certificate**: For server authentication
- **Client Certificate**: For client authentication
- **Combined Certificate**: Server certificate with private key

### 3. Certificate Formats
- **PEM Format**: Base64 encoded certificates
- **CRT Format**: Certificate files
- **KEY Format**: Private key files

## Troubleshooting

### 1. Common Issues
#### Certificate Errors

```


SSL: CERTIFICATE_VERIFY_FAILED
```


**Solution**: Check certificate paths and validity

#### Connection Refused

```


Connection refused to proxy
```


**Solution**: Verify proxy is running and accessible

#### mTLS Handshake Failed

```


TLSV1_ALERT_CERTIFICATE_REQUIRED
```


**Solution**: Ensure client certificates are provided

### 2. Debug Mode
Enable debug mode for detailed logging:

```json
{
  "server": {
    "debug": true,
    "log_level": "DEBUG"
  }
}
```



### 3. Network Testing
Test connectivity manually:

```bash
# Test health endpoint
curl -k https://localhost:6001/health

# Test with client certificate
curl -k --cert client.crt --key client.key --cacert ca.crt https://localhost:6001/health

# Test proxy registration
curl -k --cert client.crt --key client.key --cacert ca.crt https://localhost:3004/proxy/discover
```



## Examples

### 1. Simple HTTP Server
```python
#!/usr/bin/env python3
"""
Simple OpenAPI server for testing
Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import http.server
import socketserver
import json
import ssl
import argparse
import logging
from pathlib import Path

class SimpleOpenAPIHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/health':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            response = {
                'status': 'healthy',
                'server': 'simple_openapi',
                'timestamp': time.time()
            }
            self.wfile.write(json.dumps(response).encode())
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == '/echo':
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            response = {
                'echo': post_data.decode(),
                'timestamp': time.time()
            }
            self.wfile.write(json.dumps(response).encode())
        else:
            self.send_response(404)
            self.end_headers()

def main():
    parser = argparse.ArgumentParser(description='Simple OpenAPI Server')
    parser.add_argument('--port', type=int, default=6001, help='Port number')
    parser.add_argument('--config', type=str, help='Configuration file')
    args = parser.parse_args()

    with socketserver.TCPServer(("", args.port), SimpleOpenAPIHandler) as httpd:
        print(f"Server running on port {args.port}")
        httpd.serve_forever()

if __name__ == "__main__":
    main()
```



### 2. mTLS Server
```python
def configure_ssl(server, cert_file, key_file, ca_file=None):
    """Configure SSL for HTTPS/mTLS"""
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(cert_file, key_file)
    
    if ca_file:
        context.load_verify_locations(ca_file)
        context.verify_mode = ssl.CERT_REQUIRED
    
    server.socket = context.wrap_socket(server.socket, server_side=True)
```



### 3. Proxy Registration
```python
def register_with_proxy(proxy_url, server_data, client_cert=None, client_key=None, ca_cert=None):
    """Register server with proxy"""
    import requests
    
    cert = None
    if client_cert and client_key:
        cert = (client_cert, client_key)
    
    verify = ca_cert if ca_cert else False
    
    response = requests.post(
        f"{proxy_url}/proxy/register",
        json=server_data,
        cert=cert,
        verify=verify,
        timeout=10
    )
    
    return response.status_code == 200
```



## Best Practices

### 1. Security
- Use strong TLS versions (TLSv1.2+)
- Implement proper certificate validation
- Use secure random number generation
- Implement rate limiting
- Log security events

### 2. Configuration
- Use environment-specific configurations
- Validate configuration on startup
- Use relative paths for certificates
- Implement configuration hot-reload

### 3. Monitoring
- Implement health checks
- Monitor certificate expiration
- Log registration events
- Track heartbeat status

### 4. Error Handling
- Graceful error handling
- Proper HTTP status codes
- Detailed error messages
- Retry mechanisms

### 5. Performance
- Connection pooling
- Async operations
- Resource cleanup
- Memory management

## Conclusion

This guide provides comprehensive instructions for setting up an OpenAPI server with the MCP Proxy Adapter. Follow the examples and best practices to ensure a secure and reliable implementation.

For additional support, refer to the project documentation or contact the development team.
