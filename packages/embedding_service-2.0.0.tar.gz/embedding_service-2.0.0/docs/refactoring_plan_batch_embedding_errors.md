<!--
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
-->

## Batch embedding error handling – refactoring plan

### 1. Context and goals

- **Current integration**: SVO Chunker uses the `embed` JSON‑RPC command via `EmbeddingProcessor.get_embeddings_batch(texts: List[str])` and expects:
  - `data.embeddings: List[List[float]]`
  - `data.results: List[{ body, embedding, tokens, bm25_tokens, ... }]`
  - order of outputs matches input `texts`.
- **Problem**: if *any* text in a batch is rejected as invalid / non‑embeddable, the current implementation returns a top‑level error (`ErrorResult` / `result.success = false`) and the whole batch must be retried or degraded to per‑item calls.
- **Goal**: introduce a robust, **per‑item error model** for batch embedding, while still supporting the strict “all‑or‑nothing” behaviour for existing clients.

### 2. Target semantics: blocks + error policy

We want to treat the batch as an ordered list of **blocks**, where for each input
`texts[i]` мы строим один результатный блок `results[i]` с одинаковым индексом.

- Блок всегда содержит:
  - входной текст (`body`),
  - `embedding` (вектор или `null`),
  - `tokens`, `bm25_tokens` (списки токенов или `null`),
  - информацию об ошибке (`error`), если текст не удалось векторизовать.
- Поведение сервиса при возникновении ошибки в одном из блоков определяется
  **политикой ошибок**, передаваемой в запросе.

Планируется ввести параметр:

- `error_policy: "fail_fast" | "continue"` в `params` команды `embed`.

Семантика:

1. **`"fail_fast"` (старое поведение, используется по умолчанию)**:
   - При первой контентной ошибке (слишком длинный текст, только спецсимволы, и т.п.)
     выполнение останавливается.
   - Клиент получает **только** верхнеуровневую ошибку (`ErrorResult` /
     `result.success = false`), как сейчас; никаких `results` не возвращается.
2. **`"continue"` (новое поведение)**:
   - Сервис проходит по всем текстам, и для каждого строит блок:
     - либо с валидным `embedding` / токенами,
     - либо с `embedding = null`, `tokens = null`, `bm25_tokens = null`
       и заполненным `error = {code, message}`.
   - Верхнеуровневый ответ при этом **успешный** (`SuccessResult`), если:
     - JSON/параметры валидны,
     - модель/инфраструктура отработали корректно (ошибки только на уровне отдельных блоков).
   - Верхнеуровневая `"error"` / `result.success = false` остаётся только для
     действительно фатальных ситуаций:
     - невалидный JSON,
     - отсутствует/неверного типа `texts`,
     - внутренние ошибки сервера (модель не загрузилась и т.п.).

**Совместимость**:

- `data.embeddings` остаётся как производное поле:
  - в режиме `fail_fast` (старое поведение) — список списков `float`;
  - в режиме `continue` — список, в котором отдельные элементы могут быть `null`
    для неуспешных блоков.
- Старые клиенты, которые смотрят только на `data.embeddings`, в режиме
  `fail_fast` получают прежнюю семантику. В режиме `continue` им придётся
  научиться игнорировать элементы `null` (это уже задача интеграции).

### 3. API surface – how the policy is selected

Поведение управляется **только параметром запроса**, без скрытых конфигов:

- Новый необязательный параметр команды `embed`:
  - `error_policy: "fail_fast" | "continue"`.
- Если параметр не указан, используется `"fail_fast"` (полное сохранение старой
  семантики для существующих клиентов).
- Любое другое значение приводит к `InvalidParamsError` с понятным сообщением.

### 4. Current implementation snapshot (after file split)

The refactoring done before this plan:

- `embed/commands/embed_command.py`:
  - Reduced to a ~360‑line file focused on:
    - parameter validation,
    - queue semantics,
    - model‑server vs direct service selection,
    - orchestration of embedding generation and tokenization.
  - Heavy schemas and metadata moved to `embed/commands/embed_command_schema.py`.
- `embed/services/embedding_service.py`:
  - Now ~380 lines, focused on:
    - singleton lifecycle,
    - model info/status,
    - high‑level validation methods,
    - `get_embeddings` and `get_available_models`.
  - Heavy async initialization moved to `embed/services/embedding_initializer.py`.
- All tests and Docker image have been re‑run after the split; some pre‑existing tests/pipelines still fail due to upstream `mcp_proxy_adapter` API drift and missing example files, but **no new regressions related to the split were introduced**.

This structure is the baseline for the next refactoring steps.

### 5. Validation layers and error classification

Нужно чётко разделить два слоя валидации:

- **Валидация запроса** (форма `params`):
  - Остаётся в `EmbedCommand.validate_params` и базовом `Command.validate_params`.
  - Продолжает отвечать за:
    - наличие `texts`,
    - то, что `texts` — список,
    - то, что каждый элемент списка — строка.
  - Ошибки этого уровня **всегда** приводят к верхнеуровневому `InvalidParamsError`
    (независимо от `error_policy`), потому что сам запрос некорректен.
- **Контентная валидация** (качество текста, длина, состав символов, размер батча):
  - Логика уже реализована в `EmbeddingService.validate_texts` (ограничения
    `MAX_BATCH_SIZE`, `MAX_TEXT_LENGTH`, проверка на только спецсимволы и т.п.).
  - В режиме `fail_fast` мы продолжаем опираться на это поведение как на
    источник `ValidationError` при первой проблеме.
  - В режиме `continue` нам нужно **перевести те же правила** в
    по‑элементную модель: для каждого индекса иметь информацию
    `ok / error{code, message}`.

Упрощённый подход:

- В `EmbedCommand` реализуем простой цикл по текстам в режиме `"continue"`:
  - при необходимости предварительно проверяем глобальные ограничения
    (например, `MAX_BATCH_SIZE`) и выставляем соответствующий код ошибки
    всем блокам;
  - для каждого текста пробуем получить вектор через `EmbeddingService`
    (одиночный вызов) и:
    - либо получаем успешный результат,
    - либо ловим `ValidationError` и преобразуем его в структурированный
      `{code, message}` для конкретного блока.
- Для режима `"fail_fast"` оставляем текущий батчевый путь с прежней
  семантикой (первая `ValidationError` → верхнеуровневая ошибка).

### 6. Execution flow in `EmbedCommand`

В `EmbedCommand.execute` реализуем следующую логику:

1. **Определение политики**:
   - Считываем `error_policy` из `params` (если нет — `"fail_fast"`).
   - Валидируем значение (`"fail_fast"` или `"continue"`), иначе — `InvalidParamsError`.
2. **Быстрая валидация запроса**:
   - Как сейчас: наличие `texts`, тип `list`, элементы типа `str`, не пустые/не `whitespace`.
3. **Выбор бэкенда модели**:
   - Сохраняем текущую логику:
     - сначала пытаемся использовать `ModelClient` (model server),
     - при недоступности — падаем обратно на `EmbeddingService`.
   - Для режима `"continue"` можем при необходимости принудительно использовать
     локальный `EmbeddingService`, чтобы проще реализовать по‑элементную
     обработку и работу с `ValidationError`.
4. **Ветка `"fail_fast"` (по умолчанию)**:
   - Оставляем текущую реализацию:
     - один батчевый вызов к model server или `EmbeddingService.get_embeddings`,
     - при любой `ValidationError`/`InternalError` — верхнеуровневый `ErrorResult`,
       без частичных `results`.
5. **Ветка `"continue"`**:
   - Простой алгоритм:
     - при превышении `MAX_BATCH_SIZE` — помечаем все блоки ошибкой
       `batch_limit_exceeded`, не вызывая модель;
     - в противном случае:
       - итерируемся по текстам по одному,
       - для каждого:
         - пытаемся получить embedding через `EmbeddingService.get_embeddings([text])`;
         - при успехе:
           - записываем нормальный блок (`embedding`, `tokens`, `bm25_tokens`, `error = null`);
         - при `ValidationError`:
           - конвертируем её в `{code, message}` и сохраняем в `error`,
           - оставляем `embedding`/токены `null` для этого блока.
   - Верхнеуровневый результат всегда `SuccessResult`, если сама модель работает
     (ошибки только на уровне отдельных блоков). Фатальные ошибки модели/
     инфраструктуры по‑прежнему дают верхнеуровневый `ErrorResult`.

### 7. Data shape and error codes

Структура блока `results[i]` в режиме `"continue"`:

```json
{
  "body": "original text",
  "embedding": [0.1, 0.2, ...] | null,
  "tokens": ["..."] | null,
  "bm25_tokens": ["..."] | null,
  "error": null | {
    "code": "too_short | invalid_type | only_special_chars | too_long | batch_limit_exceeded | invalid_characters | validation_error",
    "message": "Human readable explanation"
  }
}
```

Error code mapping (initial proposal):

- `invalid_type` – item is not a string.
- `too_short` – text length below minimal threshold (to be defined; likely 1–2 non‑whitespace chars).
- `too_long` – exceeds `MAX_TEXT_LENGTH`.
- `only_special_chars` – no letters or digits (as already checked by `regex`).
- `batch_limit_exceeded` – corresponds to `MAX_BATCH_SIZE` violation; all items get the same error.
- `validation_error` – generic fallback when a `ValidationError` is raised without a more specific classification.

### 8. Tests to add / update

We will extend the existing test suite as follows:

1. **New unit tests for `EmbedCommand`** (`tests/unit/test_commands.py`):
   - Строгий режим (`error_policy="fail_fast"` / по умолчанию):
     - Behaviour identical to current tests (top‑level `ErrorResult` for invalid texts).
   - Режим `"continue"`:
   - Запрос с смешанным набором текстов (валидные + "плохие") и `error_policy="continue"`:
     - `SuccessResult`.
     - `len(data["results"]) == len(texts)`.
     - Для валидных индексов — нормальный вектор и `error is None`.
     - Для невалидных — `embedding is None`, `tokens/bm25_tokens is None`,
       и структурированная ошибка в `error`.
     - `data.embeddings[i]` дублирует `results[i].embedding` (включая `null`).
2. **Integration tests** (`tests/test_embedding_basic.py`, `tests/test_embedding_edge_cases.py` or new dedicated file):
   - JSON‑RPC round‑trip tests that:
     - send `embed` with `error_mode="per_item"` and mixed inputs,
     - verify the exact shape of `results` and `embeddings`,
     - verify top‑level `success`/`error` semantics.

### 9. Backwards compatibility and rollout strategy

- **По умолчанию**:
  - Если `error_policy` не указан, используется `"fail_fast"` — поведение
    полностью совпадает с текущим (верхнеуровневая ошибка, без `results`).
  - SVO Chunker и другие новые клиенты смогут явно передавать
    `error_policy="continue"`, чтобы получать по‑элементные ошибки.
- **Неразрушающие изменения**:
  - Существующие поля (`embeddings`, `results`, `model`, `dimension`) не удаляются.
  - Внутри `results[i]` будет добавлено новое поле `error`, а в будущем при
    необходимости можно добавить и явный `status`.
  - `EmbedResult` в `embed/results.py` по‑прежнему будет возвращать те же поля;
    по‑элементные ошибки будут просто дополнительной информацией в `results[i]`.
- **Документация**:
  - Обновить/добавить публичный документ по API, описывающий:
    - параметр `error_policy`,
    - структуру блоков `results[i]`,
    - возможные коды ошибок,
    - рекомендации по обработке `null`‑векторов в `data.embeddings`.

### 10. Implementation order

1. **Command‑level changes**:
   - Добавить параметр `error_policy` в схему/метаданные и обработку в `EmbedCommand`.
   - Реализовать ветки `"fail_fast"` и `"continue"` в `execute` с по‑элементной
     обработкой в последнем случае.
   - Добавить в блоки `results[i]` поле `error`.
2. **Tests and pipelines**:
   - Extend unit tests and selected integration tests as described above.
   - Re‑run pytest and existing test pipelines.
3. **Documentation**:
   - Update / create a public API doc file that describes the new semantics (this refactoring plan is internal; a user‑facing spec will be shorter and focused on behaviour, not implementation).

