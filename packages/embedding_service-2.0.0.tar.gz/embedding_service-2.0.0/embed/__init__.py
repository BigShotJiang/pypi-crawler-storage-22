"""
Embedding service module.

Provides embedding generation using ML models.
Constants: embed.constants
Exceptions: embed.exceptions
"""

__version__ = "2.0.0"
