"""
CLI interface for embedding service.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from embed.cli.main import main

__all__ = ["main"]
