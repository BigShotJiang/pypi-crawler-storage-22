#!/usr/bin/env python3
"""
Single CLI for embedding service config: generate and validate.

Uses embed.config.config_generator and embed.config.config_validator.
All config settings can be set via --set section.key=value (or section.sub.key=value).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, cast

from embed.config.config_generator import (
    _REQUIRED_CONTAINER_PARAMS,
    generate_config,
    generate_container_config,
)
from embed.config.config_validator import validate_config


def _coerce_value(value: str) -> Any:
    """Coerce string to int, float, bool, or keep string."""
    v = value.strip()
    if v.lower() == "true":
        return True
    if v.lower() == "false":
        return False
    if v.isdigit():
        return int(v)
    try:
        return float(v)
    except ValueError:
        pass
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        if not inner:
            return []
        return [_coerce_value(x.strip()) for x in inner.split(",")]
    return value


def _parse_set_args(set_args: List[str]) -> Dict[str, Any]:
    """Parse --set key=value into nested dict (e.g. section.key or section.sub.key)."""
    overrides: Dict[str, Any] = {}
    for s in set_args:
        if "=" not in s:
            print(f"Invalid --set: {s!r} (expected key=value)", file=sys.stderr)
            sys.exit(2)
        key_part, _, value_part = s.partition("=")
        key_path = [k.strip() for k in key_part.strip().split(".")]
        value = _coerce_value(value_part)
        if not key_path:
            continue
        current = overrides
        for i, seg in enumerate(key_path):
            if i == len(key_path) - 1:
                current[seg] = value
            else:
                if seg not in current:
                    current[seg] = {}
                current = current[seg]
    return overrides


def cmd_generate(args: argparse.Namespace) -> int:
    """Generate config file from overrides (--set); validate before write."""
    overrides = _parse_set_args(args.set or [])
    config_path = getattr(args, "config_path", None) or str(args.output)
    try:
        config = generate_config(overrides, config_path=config_path)
    except ValueError as e:
        print(f"Validation error:\n{e}", file=sys.stderr)
        return 1
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    print(f"Config written to {out}")
    container_out = getattr(args, "container_output", None)
    if container_out:
        cpath = Path(container_out)
        missing = [
            f"--{n.replace('_', '-')}"
            for n in _REQUIRED_CONTAINER_PARAMS
            if getattr(args, n, None) is None
        ]
        if missing:
            print(
                "When using --container-output the following are required: "
                + ", ".join(sorted(missing)),
                file=sys.stderr,
            )
            return 1
        container_params = {n: getattr(args, n) for n in _REQUIRED_CONTAINER_PARAMS}
        for opt in (
            "server_ssl_dir_validate",
            "registration_ssl_dir_validate",
            "timing_file_validate",
        ):
            if getattr(args, opt, None) is not None:
                container_params[opt] = getattr(args, opt)
        try:
            container_config = generate_container_config(
                config_path=str(cpath), **container_params
            )
        except ValueError as e:
            print(f"Container config error: {e}", file=sys.stderr)
            return 1
        cpath.parent.mkdir(parents=True, exist_ok=True)
        with open(cpath, "w", encoding="utf-8") as f:
            json.dump(container_config, f, indent=2, ensure_ascii=False)
        print(f"Container config written to {cpath}")
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    """Validate config file; exit 1 on errors or unknown keys."""
    path = Path(args.config)
    if not path.exists():
        print(f"File not found: {path}", file=sys.stderr)
        return 1
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    errors = validate_config(data, config_path=str(path))
    if not errors:
        print("OK")
        return 0
    print(f"Validation failed ({len(errors)} error(s)):", file=sys.stderr)
    for e in errors:
        print(f"  - {e}", file=sys.stderr)
    return 1


def cmd_help(args: argparse.Namespace) -> int:
    """Print extended help: usage, examples, and config key reference."""
    # Ensure we have a project root to resolve docs (relative to embed package).
    _ = args  # unused
    help_text = r"""
Config CLI — generate or validate embedding service configuration.

Usage:
  python -m embed.cli.config_cli <command> [options]
  python -m embed.cli.config_cli --help
  python -m embed.cli.config_cli generate --help
  python -m embed.cli.config_cli validate --help
  python -m embed.cli.config_cli help

Commands:
  generate    Write a valid config JSON from defaults and optional overrides.
  validate    Check an existing config file (required sections, no unknown keys).
  help        Show this help and key reference.

Examples:

  Generate default config:
    python -m embed.cli.config_cli generate -o config/local.json

  Generate with overrides (--set section.key=value, repeatable):
    python -m embed.cli.config_cli generate -o config/local.json \
      --set server.port=9000 \
      --set embedding.model_name=all-MiniLM-L6-v2 \
      --set embedding.max_batch_size=32 \
      --set embedding.max_texts_per_batch=0 \
      --set queue_manager.max_concurrent_jobs=1

  Validate a config file:
    python -m embed.cli.config_cli validate -c config/local.json

Key reference (embedding limits, see docs/CONFIG_OPERATION_LIMITS.md):
  embedding.max_batch_size          Max texts per request (default 512).
  embedding.max_text_length         Max chars per text (default 1000000).
  embedding.max_texts_per_batch     Max texts per encode(); 0 = GPU (default 0).
  queue_manager.max_concurrent_jobs Max parallel jobs (default 1).

Dependencies (see docs/CONFIG_DEPENDENCIES.md):
  coalescing.enabled requires queue_manager.enabled.
  security.mode (http|https|mtls) determines cert/key requirements.
"""
    print(help_text.strip())
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Embedding service config: generate or validate "
            "(single generator and validator)."
        )
    )
    sub = parser.add_subparsers(dest="command", required=True)

    gen = sub.add_parser("generate", help="Generate config file (validated)")
    gen.add_argument("-o", "--output", required=True, help="Output JSON path")
    gen.add_argument(
        "--config-path",
        help="Resolve relative paths from this path in validation (default: -o)",
    )
    gen.add_argument(
        "--container-output",
        help="Also write container config (e.g. docker.json)",
    )
    gen.add_argument(
        "--registration-host",
        help="Registration proxy host (required if --container-output)",
    )
    gen.add_argument(
        "--registration-port",
        type=int,
        help="Registration proxy port (required if --container-output)",
    )
    gen.add_argument(
        "--registration-protocol",
        choices=("http", "https", "mtls"),
        help="Registration protocol (required if --container-output)",
    )
    gen.add_argument(
        "--server-port",
        type=int,
        help="Server port in container (required if --container-output)",
    )
    gen.add_argument(
        "--server-host",
        help="Server bind host in container (required if --container-output)",
    )
    gen.add_argument(
        "--service-name",
        help="Service name and advertised_host (required if --container-output)",
    )
    gen.add_argument(
        "--server-ssl-dir",
        help="Server SSL cert dir in container (required if --container-output)",
    )
    gen.add_argument(
        "--registration-ssl-dir",
        help="Registration client cert dir (required if --container-output)",
    )
    gen.add_argument(
        "--timing-file",
        help="Timing file path in container (required if --container-output)",
    )
    gen.add_argument(
        "--timing-file-max-bytes",
        type=int,
        help="Timing file max bytes (required if --container-output)",
    )
    gen.add_argument(
        "--server-ssl-dir-validate",
        help="Server cert dir for validation on host (optional, container config)",
    )
    gen.add_argument(
        "--registration-ssl-dir-validate",
        help="Client cert dir for validation on host (optional, container config)",
    )
    gen.add_argument(
        "--timing-file-validate",
        help="Timing file path for validation on host (optional, container config)",
    )
    gen.add_argument(
        "--set",
        action="append",
        metavar="KEY=VALUE",
        help=(
            "Override: section.key=value (repeatable). "
            "Value: string, number, true/false, or [a,b,c]"
        ),
    )
    gen.set_defaults(func=cmd_generate)

    val = sub.add_parser(
        "validate",
        help=("Validate config file " "(fails on unknown keys or missing required)"),
    )
    val.add_argument("-c", "--config", required=True, help="Config JSON path")
    val.set_defaults(func=cmd_validate)

    sub.add_parser(
        "help",
        help="Show extended help, examples, and config key reference",
    ).set_defaults(func=cmd_help)

    return parser


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()
    return cast(int, args.func(args))


if __name__ == "__main__":
    sys.exit(main())
