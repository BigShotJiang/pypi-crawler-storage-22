#!/usr/bin/env python3
"""
CLI interface for embedding service.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse
import asyncio
import json
import sys
from pathlib import Path
from typing import List

from embed.client.embedding_client import EmbeddingClient


def print_json(data: dict, indent: int = 2) -> None:
    """Print data as formatted JSON."""
    print(json.dumps(data, indent=indent, ensure_ascii=False))


async def cmd_health(client: EmbeddingClient, args: argparse.Namespace) -> int:
    """Check server health."""
    try:
        health = await client.health()
        print("✅ Server is healthy")
        print_json(health)
        return 0
    except Exception as e:
        print(f"❌ Health check failed: {e}", file=sys.stderr)
        return 1


async def cmd_embed(client: EmbeddingClient, args: argparse.Namespace) -> int:
    """Generate embeddings for texts."""
    try:
        # Read texts from file or use provided texts
        texts: List[str] = []
        if args.file:
            file_path = Path(args.file)
            if not file_path.exists():
                print(f"❌ File not found: {args.file}", file=sys.stderr)
                return 1
            with open(file_path, "r", encoding="utf-8") as f:
                texts = [line.strip() for line in f if line.strip()]
        elif args.texts:
            texts = args.texts
        else:
            print("❌ No texts provided. Use --texts or --file", file=sys.stderr)
            return 1

        if not texts:
            print("❌ Empty texts list", file=sys.stderr)
            return 1

        print(f"📤 Generating embeddings for {len(texts)} text(s)...")
        if args.verbose:
            for i, text in enumerate(texts, 1):
                preview = text[:50] + "..." if len(text) > 50 else text
                print(f"   {i}. {preview}")

        result = await client.embed(
            texts=texts,
            model=args.model,
            dimension=args.dimension,
            job_id=args.job_id,
            wait=args.wait,
            wait_timeout=args.timeout,
        )

        if args.wait:
            print("✅ Embeddings generated successfully")
            if args.output:
                output_path = Path(args.output)
                with open(output_path, "w", encoding="utf-8") as f:
                    json.dump(result, f, indent=2, ensure_ascii=False)
                print(f"📄 Results saved to: {output_path}")
            else:
                print_json(result)
        else:
            print("✅ Job queued successfully")
            print_json(result)
            if args.verbose:
                print(f"\n💡 Use 'embed-cli status {result['job_id']}' to check status")

        return 0
    except Exception as e:
        print(f"❌ Embedding failed: {e}", file=sys.stderr)
        if args.verbose:
            import traceback

            traceback.print_exc()
        return 1


async def cmd_status(client: EmbeddingClient, args: argparse.Namespace) -> int:
    """Check job status."""
    try:
        status = await client.job_status(args.job_id)

        if not status.get("exists"):
            print(f"❌ Job {args.job_id} not found", file=sys.stderr)
            return 1

        print(f"📊 Job Status: {args.job_id}")
        print_json(status)

        if status.get("done"):
            if status.get("status") == "completed":
                print("\n✅ Job completed successfully")
            elif status.get("status") == "failed":
                print(f"\n❌ Job failed: {status.get('error', 'Unknown error')}")
                return 1
        else:
            print(f"\n⏳ Job is {status.get('status', 'unknown')}")

        return 0
    except Exception as e:
        print(f"❌ Status check failed: {e}", file=sys.stderr)
        if args.verbose:
            import traceback

            traceback.print_exc()
        return 1


async def cmd_models(client: EmbeddingClient, args: argparse.Namespace) -> int:
    """List available models."""
    try:
        models = await client.models()
        print("📋 Available Models:")
        print_json(models)
        return 0
    except Exception as e:
        print(f"❌ Failed to list models: {e}", file=sys.stderr)
        return 1


async def cmd_list(client: EmbeddingClient, args: argparse.Namespace) -> int:
    """List available commands."""
    try:
        commands = await client.list_commands()
        print("📋 Available Commands:")
        print_json(commands)
        return 0
    except Exception as e:
        print(f"❌ Failed to list commands: {e}", file=sys.stderr)
        return 1


def create_parser() -> argparse.ArgumentParser:
    """Create CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="embed-cli",
        description="CLI client for embedding service",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # Global options
    parser.add_argument(
        "--protocol",
        choices=["http", "https", "mtls"],
        default="http",
        help="Transport protocol (default: http)",
    )
    parser.add_argument(
        "--host", default="127.0.0.1", help="Server hostname (default: 127.0.0.1)"
    )
    parser.add_argument(
        "--port", type=int, default=8080, help="Server port (default: 8080)"
    )
    parser.add_argument("--cert", help="Path to client certificate file (for mTLS)")
    parser.add_argument("--key", help="Path to client private key file (for mTLS)")
    parser.add_argument("--ca", help="Path to CA certificate file (for mTLS)")
    parser.add_argument(
        "--check-hostname",
        action="store_true",
        help="Verify hostname in SSL connections",
    )
    parser.add_argument("--token", help="Authentication token")
    parser.add_argument(
        "--token-header",
        default="X-API-Key",
        help="Header name for authentication token (default: X-API-Key)",
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")

    # Subcommands
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Health command
    subparsers.add_parser("health", help="Check server health")

    # Embed command
    embed_parser = subparsers.add_parser("embed", help="Generate embeddings")
    embed_parser.add_argument(
        "--texts",
        nargs="+",
        help="Texts to create embeddings for",
    )
    embed_parser.add_argument("--file", "-f", help="File with texts (one per line)")
    embed_parser.add_argument("--model", help="Model name to use")
    embed_parser.add_argument("--dimension", type=int, help="Expected vector dimension")
    embed_parser.add_argument("--job-id", help="Custom job ID")
    embed_parser.add_argument(
        "--wait", "-w", action="store_true", help="Wait for job completion"
    )
    embed_parser.add_argument(
        "--timeout",
        "--wait-timeout",
        type=int,
        default=60,
        help="Timeout for waiting (seconds, default: 60). Use 0 for unlimited waiting.",
    )
    embed_parser.add_argument("--output", "-o", help="Output file for results (JSON)")

    # Status command
    status_parser = subparsers.add_parser("status", help="Check job status")
    status_parser.add_argument("job_id", help="Job ID to check")

    # Models command
    subparsers.add_parser("models", help="List available models")

    # List command
    subparsers.add_parser("list", help="List available commands")

    return parser


async def main_async() -> int:
    """Main async entry point."""
    parser = create_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    # Create client
    client = EmbeddingClient(
        protocol=args.protocol,
        host=args.host,
        port=args.port,
        cert=args.cert,
        key=args.key,
        ca=args.ca,
        check_hostname=args.check_hostname,
        token=args.token,
        token_header=args.token_header,
    )

    # Execute command
    if args.command == "health":
        return await cmd_health(client, args)
    elif args.command == "embed":
        return await cmd_embed(client, args)
    elif args.command == "status":
        return await cmd_status(client, args)
    elif args.command == "models":
        return await cmd_models(client, args)
    elif args.command == "list":
        return await cmd_list(client, args)
    else:
        print(f"❌ Unknown command: {args.command}", file=sys.stderr)
        return 1


def main() -> int:
    """Main entry point."""
    return asyncio.run(main_async())


if __name__ == "__main__":
    sys.exit(main())
