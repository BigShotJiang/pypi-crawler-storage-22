"""
Embedding service client package.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from embed.client.embedding_client import EmbeddingClient

__all__ = ["EmbeddingClient"]
