"""
Embedding service client for interacting with embedding service API.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio
import logging
import time
from typing import Any, Dict, List, Optional

from mcp_proxy_adapter.client.jsonrpc_client import JsonRpcClient

from embed.constants import EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY
from embed.exceptions import EmbedClientError

logger = logging.getLogger(__name__)


class EmbeddingClient:
    """
    Client for embedding service API.

    Provides high-level interface for:
    - Generating embeddings (via queue)
    - Checking job status
    - Listing available models
    - Health checks
    """

    def __init__(
        self,
        protocol: str = "http",
        host: str = "127.0.0.1",
        port: int = 8080,
        cert: Optional[str] = None,
        key: Optional[str] = None,
        ca: Optional[str] = None,
        check_hostname: bool = False,
        token: Optional[str] = None,
        token_header: Optional[str] = None,
    ):
        """
        Initialize embedding client.

        Args:
            protocol: Transport protocol (http, https, mtls)
            host: Server hostname
            port: Server port
            cert: Path to client certificate file (for mTLS)
            key: Path to client private key file (for mTLS)
            ca: Path to CA certificate file (for mTLS)
            check_hostname: Whether to verify hostname in SSL connections
            token: Authentication token
            token_header: Header name for authentication token
        """
        self.client = JsonRpcClient(
            protocol=protocol,
            host=host,
            port=port,
            cert=cert,
            key=key,
            ca=ca,
            check_hostname=check_hostname,
            token=token,
            token_header=token_header,
        )
        self.protocol = protocol
        self.host = host
        self.port = port
        self._cert = cert
        self._key = key
        self._ca = ca
        self._token = token
        self._token_header = token_header or "X-API-Key"

    async def health(self) -> Dict[str, Any]:
        """
        Check server health.

        Returns:
            Health status information
        """
        return await self.client.health()

    async def embed(
        self,
        texts: List[str],
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        job_id: Optional[str] = None,
        error_policy: Optional[str] = None,
        device: Optional[str] = None,
        wait: bool = False,
        wait_timeout: int = 60,
        poll_interval: float = 1.0,
        use_push: bool = False,
    ) -> Dict[str, Any]:
        """
        Generate embeddings for texts (via queue).

        Parameters match server embed command schema: texts, model, dimension,
        error_policy, device. When wait=True, completion can be via polling or
        push (WebSocket). use_push=True uses the /ws channel to avoid poll delay.

        Args:
            texts: List of texts to create embeddings for
            model: Optional model name
            dimension: Optional expected vector dimension
            job_id: Optional custom job ID (server may ignore and generate own)
            error_policy: 'fail_fast' or 'continue'; default from server
            device: 'auto', 'cpu', 'cuda', 'cuda:0'; default from server
            wait: If True, wait for job completion and return results.
            wait_timeout: Max time to wait (seconds); 0 = no timeout.
            poll_interval: Time between queue status checks (seconds); used if
                wait=True and use_push=False.
            use_push: If True and wait=True, wait via WebSocket push instead of
                polling (lower latency, fewer round-trips). Requires server /ws.

        Returns:
            If wait=False: {"job_id", "status", "message"}.
            If wait=True: {"results": [...], "model", "dimension"} (and optional
            "device"), matching server embed result data.

        Raises:
            EmbedClientError: If embedding request or job fails.
            TimeoutError: If wait_timeout > 0 and job does not complete in time.

        Example:
            # Submit job and get job_id immediately
            result = await client.embed(["Hello, world!"], wait=False)
            job_id = result["job_id"]

            # Wait for completion with timeout
            result = await client.embed(
                ["Hello, world!"],
                wait=True,
                wait_timeout=120  # Wait up to 2 minutes
            )

            # With error_policy and device (match server schema)
            result = await client.embed(
                ["Hello!"], error_policy="continue", device="cpu", wait=True
            )
        """
        # Params match server embed schema (texts required; rest optional)
        params: Dict[str, Any] = {"texts": texts}
        if model is not None:
            params["model"] = model
        if dimension is not None:
            params["dimension"] = dimension
        if job_id is not None:
            params["job_id"] = job_id
        if error_policy is not None:
            params["error_policy"] = error_policy
        else:
            params["error_policy"] = EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY
        if device is not None:
            params["device"] = device

        response = await self.client.jsonrpc_call("embed", params)

        # Extract result
        if "error" in response:
            raise EmbedClientError(f"Embedding failed: {response['error']}")

        result = response.get("result", {})
        if not result.get("success"):
            error = result.get("error", {})
            raise EmbedClientError(
                f"Embedding failed: {error.get('message', 'Unknown error')}"
            )

        # Extract data - server may return full result (sync) or job_id (async queue)
        data = result.get("data", {})
        job_id = data.get("job_id") or result.get("job_id")

        # Sync response: full result in one response (no job_id)
        if not job_id and isinstance(data.get("results"), list):
            return data

        if not job_id:
            raise EmbedClientError("No job_id or results returned from server")

        if not wait:
            return {
                "job_id": job_id,
                "status": data.get("status") or result.get("status", "pending"),
                "message": data.get("message")
                or result.get("message", "Job queued successfully"),
            }

        if use_push:
            return await self._wait_for_job_via_ws(job_id, timeout=wait_timeout)
        return await self.wait_for_job(
            job_id, timeout=wait_timeout, poll_interval=poll_interval
        )

    async def wait_for_job(
        self, job_id: str, timeout: int = 60, poll_interval: float = 1.0
    ) -> Dict[str, Any]:
        """
        Wait for job completion by polling the queue.

        Polls until job completes, fails, or timeout. Return shape matches
        server embed result data: results, model, dimension (optional device).

        Args:
            job_id: Job ID to wait for
            timeout: Max wait (seconds); 0 = no timeout
            poll_interval: Seconds between status checks

        Returns:
            {"results": [...], "model": str, "dimension": int} (and optional "device")

        Raises:
            EmbedClientError: If job not found or job failed
            TimeoutError: If timeout > 0 and job does not complete in time
        """
        start_time = time.time()

        while timeout == 0 or (time.time() - start_time < timeout):
            status = await self.job_status(job_id)

            if not status.get("exists"):
                raise EmbedClientError(f"Job {job_id} not found")

            done = status.get("done", False) or status.get("status") in (
                "completed",
                "failed",
                "error",
            )

            if done:
                job_status = status.get("status", "")
                if job_status in ("completed", "success"):
                    # result/data contains { results, model, dimension }
                    inner = status.get("result") or status.get("data") or status
                    if isinstance(inner, dict):
                        data = inner.get("data")
                        if data is not None:
                            return data
                    return inner if isinstance(inner, dict) else {}
                if job_status in ("failed", "error"):
                    error = status.get("error") or status.get(
                        "message", "Unknown error"
                    )
                    raise EmbedClientError(f"Job failed: {error}")
                raise EmbedClientError(
                    f"Job completed with unexpected status: {job_status}"
                )

            await asyncio.sleep(poll_interval)

        raise TimeoutError(f"Job {job_id} did not complete within {timeout} seconds")

    async def _wait_for_job_via_ws(
        self, job_id: str, timeout: int = 60
    ) -> Dict[str, Any]:
        """
        Wait for job completion via WebSocket push (no polling).

        Connects to server /ws, subscribes to job_id, returns result when
        job_completed is received. Raises on job_failed or timeout.
        """
        try:
            import websockets
        except ImportError as e:
            raise EmbedClientError(
                "use_push=True requires the 'websockets' package"
            ) from e
        scheme = "wss" if self.protocol in ("https", "mtls") else "ws"
        ws_url = f"{scheme}://{self.host}:{self.port}/ws"
        ssl_ctx = None
        if self.protocol in ("https", "mtls") and (self._ca or self._cert):
            import ssl

            ssl_ctx = ssl.create_default_context(cafile=self._ca)
            if self._cert and self._key:
                ssl_ctx.load_cert_chain(self._cert, self._key)
        timeout_sec = float(timeout) if timeout > 0 else None
        extra_headers = None
        if getattr(self, "_token", None) and getattr(self, "_token_header", None):
            extra_headers = {self._token_header: self._token}

        async def _receive() -> Dict[str, Any]:
            async with websockets.connect(
                ws_url,
                ssl=ssl_ctx,
                close_timeout=2.0,
                open_timeout=10.0,
                additional_headers=extra_headers,
            ) as ws:
                await ws.send(
                    __import__("json").dumps({"action": "subscribe", "job_id": job_id})
                )
                while True:
                    raw = await asyncio.wait_for(ws.recv(), timeout=timeout_sec)
                    msg = __import__("json").loads(raw)
                    ev = msg.get("event")
                    if ev == "job_completed" and msg.get("job_id") == job_id:
                        return msg.get("result") or {}
                    if ev == "job_failed" and msg.get("job_id") == job_id:
                        err = msg.get("error", "Unknown error")
                        raise EmbedClientError(f"Job failed: {err}")

        if timeout_sec is not None:
            return await asyncio.wait_for(_receive(), timeout=timeout_sec)
        return await _receive()

    async def job_status(self, job_id: str) -> Dict[str, Any]:
        """
        Get job status (shape matches server embed_job_status result.data).

        Tries queue_get_job_status first, then embed_job_status. Returns dict
        with exists, status, done, and when completed: result (with success/data).

        Args:
            job_id: Job ID to check

        Returns:
            Server job status data (exists, status, done, result?).

        Raises:
            EmbedClientError: If status request fails
        """
        # Try built-in queue command first (for commands with use_queue=True)
        try:
            response = await self.client.jsonrpc_call(
                "queue_get_job_status", {"job_id": job_id}
            )
            if "error" not in response:
                result = response.get("result", {})
                if result.get("success"):
                    return result.get("data", {})
        except Exception as e:
            logger.debug(
                "queue_get_job_status not available (%s), using embed_job_status",
                e,
            )

        # Use embed_job_status when queue does not provide queue_get_job_status
        try:
            response = await self.client.jsonrpc_call(
                "embed_job_status", {"job_id": job_id}
            )

            if "error" in response:
                raise EmbedClientError(f"Status check failed: {response['error']}")

            result = response.get("result", {})
            if not result.get("success"):
                error = result.get("error", {})
                raise EmbedClientError(
                    f"Status check failed: {error.get('message', 'Unknown error')}"
                )

            return result.get("data", {})
        except Exception as e:
            raise EmbedClientError(f"Status check failed: {e}") from e

    async def models(self) -> Dict[str, Any]:
        """
        List available models (shape matches server models command result.data).

        Returns:
            {"models": [...]} with name, dimension, supported_dimensions, max_tokens.

        Raises:
            EmbedClientError: If models request fails
        """
        response = await self.client.jsonrpc_call("models", {})

        if "error" in response:
            raise EmbedClientError(f"Models list failed: {response['error']}")

        result = response.get("result", {})
        if not result.get("success"):
            error = result.get("error", {})
            raise EmbedClientError(
                f"Models list failed: {error.get('message', 'Unknown error')}"
            )

        return result.get("data", {})

    async def list_commands(self) -> Dict[str, Any]:
        """
        List available commands.

        Returns:
            Available commands information
        """
        # Try different command names
        for cmd_name in ["list", "help", "commands"]:
            try:
                response = await self.client.jsonrpc_call(cmd_name, {})
                if "error" not in response:
                    result = response.get("result", {})
                    return result.get("data", result)
            except Exception:
                continue

        # If all fail, return empty dict
        return {}

    def __repr__(self) -> str:
        """String representation of client."""
        return f"EmbeddingClient({self.protocol}://{self.host}:{self.port})"
