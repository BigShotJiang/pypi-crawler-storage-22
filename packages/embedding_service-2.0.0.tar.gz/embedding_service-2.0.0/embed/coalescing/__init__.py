"""
Coalescing (request batching) support for embed command.

Maps logical job IDs to physical batch jobs and slice metadata.
See docs/COALESCING_PROPOSAL.md and docs/coalescing_plan/.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import Optional

from embed.coalescing.coalescer_buffer import (
    BatchDescriptor,
    BufferEntry,
    CoalescerBuffer,
)
from embed.coalescing.logical_job_store import (
    LogicalJobEntry,
    LogicalJobStore,
)
from embed.coalescing.payload_builder import build_batch_payload
from embed.coalescing.coalescer_submit import submit_batch

# Singleton store for logical job resolution (used by embed_job_status and coalescer).
_logical_job_store: Optional[LogicalJobStore] = None


def get_logical_job_store() -> LogicalJobStore:
    """Return the global logical job store; create if not set."""
    global _logical_job_store
    if _logical_job_store is None:
        _logical_job_store = LogicalJobStore()
    return _logical_job_store


def set_logical_job_store(store: LogicalJobStore) -> None:
    """Set the global logical job store (e.g. from main at startup)."""
    global _logical_job_store
    _logical_job_store = store


__all__ = [
    "BatchDescriptor",
    "BufferEntry",
    "CoalescerBuffer",
    "LogicalJobEntry",
    "LogicalJobStore",
    "build_batch_payload",
    "get_logical_job_store",
    "set_logical_job_store",
    "submit_batch",
]
