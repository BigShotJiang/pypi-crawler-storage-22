"""
Coalescer buffer: accumulate embed requests by homogeneity key, flush on conditions.

Groups requests by (model, dimension, error_policy, device). Returns BatchDescriptor
when flush is triggered (max_texts, single request, or window/max_wait elapsed).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import threading

# Homogeneity key: (model, dimension, error_policy, device)
CoalescerKey = Tuple[str, Optional[int], str, str]


@dataclass
class BufferEntry:
    """Buffer entry: texts, homogeneity params, optional future for result."""

    texts: List[str]
    model: str
    dimension: Optional[int]
    error_policy: str
    device: str
    timestamp: float = field(default_factory=time.monotonic)
    result_future: Optional[Any] = None  # asyncio.Future for logical_job_id


@dataclass
class BatchDescriptor:
    """
    Ready batch: merged texts and per-request counts for slicing.

    futures: list of Future, one per request, set with logical_job_id.
    """

    merged_texts: List[str]
    counts: List[int]
    key: CoalescerKey
    futures: List[Any] = field(
        default_factory=list
    )  # asyncio.Future[str], same order as counts


class CoalescerBuffer:
    """
    Buffer that groups embed requests by homogeneity key and flushes on conditions.

    Thread-safe. Flush: (1) total texts >= max_texts, (2) single request
    (immediate), (3) 2+ requests and window_sec or max_wait_sec elapsed.
    """

    def __init__(
        self,
        window_sec: float = 0.03,
        max_texts: int = 64,
        max_wait_sec: Optional[float] = 0.1,
    ) -> None:
        """
        Initialize buffer with flush limits.

        Args:
            window_sec: Max time to wait for more requests before flushing.
            max_texts: Flush when merged texts reach this count.
            max_wait_sec: Optional; flush if oldest request waited longer.
        """
        self._window_sec = window_sec
        self._max_texts = max_texts
        self._max_wait_sec = max_wait_sec
        self._lock = threading.Lock()
        self._buckets: Dict[CoalescerKey, List[BufferEntry]] = {}

    def _key(
        self,
        model: str,
        dimension: Optional[int],
        error_policy: str,
        device: str,
    ) -> CoalescerKey:
        """Build homogeneity key (model, dimension, error_policy, device)."""
        return (model, dimension, error_policy, device)

    def add_request(
        self,
        texts: List[str],
        model: str,
        dimension: Optional[int],
        error_policy: str,
        device: str,
        result_future: Optional[Any] = None,
    ) -> Optional[BatchDescriptor]:
        """
        Add one request to the buffer. Return BatchDescriptor when flush triggered.

        Flush when: (1) total texts >= max_texts, (2) bucket had 1 entry
        (flush immediately), (3) bucket has 2+ and window or max_wait elapsed.
        On flush: drain whole requests only, up to max_texts, in order.
        If result_future is provided, it is included in descriptor.futures so the
        router can set the logical_job_id when the batch is submitted.

        Returns:
            BatchDescriptor if flush happened, else None.
        """
        key = self._key(model, dimension, error_policy, device)
        entry = BufferEntry(
            texts=texts,
            model=model,
            dimension=dimension,
            error_policy=error_policy,
            device=device,
            result_future=result_future,
        )
        with self._lock:
            if key not in self._buckets:
                self._buckets[key] = []
            bucket = self._buckets[key]
            bucket.append(entry)

            total = sum(len(e.texts) for e in bucket)
            now = time.monotonic()
            oldest_ts = bucket[0].timestamp if bucket else now

            should_flush = False
            if total >= self._max_texts:
                should_flush = True
            elif len(bucket) == 1:
                should_flush = True
            elif len(bucket) >= 2:
                if (now - oldest_ts) >= self._window_sec:
                    should_flush = True
                elif (
                    self._max_wait_sec is not None
                    and (now - oldest_ts) >= self._max_wait_sec
                ):
                    should_flush = True

            if not should_flush:
                return None

            merged: List[str] = []
            counts: List[int] = []
            futures: List[Any] = []
            taken = 0
            while bucket:
                e = bucket[0]
                n = len(e.texts)
                if taken > 0 and taken + n > self._max_texts:
                    break
                merged.extend(e.texts)
                counts.append(n)
                if e.result_future is not None:
                    futures.append(e.result_future)
                taken += n
                bucket.pop(0)

            if not bucket:
                del self._buckets[key]

            return BatchDescriptor(
                merged_texts=merged,
                counts=counts,
                key=key,
                futures=futures,
            )
