"""
Submit one coalesced batch job to the queue and register logical jobs.

Builds payload from BatchDescriptor, submits via adapter queue (callable),
registers logical jobs in the store, returns logical_job_ids in order.
Adapter integration: caller provides queue_submit(payload) -> physical_job_id.
See docs/coalescing_plan/06_coalescer_submit.md.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

from embed.coalescing.coalescer_buffer import BatchDescriptor
from embed.coalescing.logical_job_store import LogicalJobStore
from embed.coalescing.payload_builder import build_batch_payload
from embed.exceptions import EmbedQueueError


async def submit_batch(
    descriptor: BatchDescriptor,
    store: LogicalJobStore,
    queue_submit: Callable[[Dict[str, Any]], Awaitable[str]],
) -> Tuple[List[str], Optional[Dict[str, Any]]]:
    """
    Build payload, submit one batch job to the queue, register logical jobs.

    Caller must provide queue_submit(payload) which submits the job (command
    "embed", params=payload) to the adapter queue and returns the physical
    job_id. If the adapter uses CommandExecutionJob, queue_submit should
    call queue_manager.add_job(CommandExecutionJob, job_id, job_params) and
    queue_manager.start_job(job_id), then return job_id.

    Args:
        descriptor: Batch with merged_texts, counts, and key.
        store: Logical job store for register_logical_jobs.
        queue_submit: Async callable that accepts embed params dict and
            returns physical job_id (or raises on failure).

    Returns:
        (logical_job_ids, None) on success, or ([], error_dict) on submit failure.
    """
    counts = descriptor.counts
    slices: List[Tuple[int, int]] = [
        (sum(counts[:i]), counts[i]) for i in range(len(counts))
    ]
    payload = build_batch_payload(descriptor)
    try:
        physical_job_id = await queue_submit(payload)
    except EmbedQueueError as e:
        return ([], {"message": e.message, "code": -32603})
    except (OSError, RuntimeError, ValueError) as e:
        return ([], {"message": str(e), "code": -32603})
    except Exception as e:
        return ([], {"message": str(e), "code": -32603})
    logical_ids = store.register_logical_jobs(physical_job_id, slices)
    return (logical_ids, None)
