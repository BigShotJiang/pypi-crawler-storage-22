"""
Logical job store: maps logical job IDs to physical job and slice metadata.

Used by coalescer (submit, completion) and embed_job_status for resolution.
Retention/TTL for logical job metadata can be added later (e.g. align with
completed_job_retention_seconds).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import threading


@dataclass
class LogicalJobEntry:
    """
    Single logical job: one client request within a coalesced batch.

    Attributes:
        logical_job_id: Unique id returned to the client.
        physical_job_id: Queue job_id for the whole batch.
        start_index: Start index in the merged result list for this request's slice.
        count: Number of texts (length of slice).
    """

    logical_job_id: str
    physical_job_id: str
    start_index: int
    count: int


class LogicalJobStore:
    """
    In-memory store mapping logical job IDs to physical job and slice info.

    Thread-safe. Used when coalescing is enabled: one physical job serves
    N logical requests; each logical job gets a slice of the physical result.
    """

    def __init__(self) -> None:
        """Initialize empty store with lock for concurrent access."""
        self._lock = threading.Lock()
        self._logical: Dict[str, LogicalJobEntry] = {}
        self._physical_results: Dict[str, Dict[str, Any]] = {}
        self._physical_errors: Dict[str, Dict[str, Any]] = {}

    def register_logical_jobs(
        self,
        physical_job_id: str,
        slices: List[Tuple[int, int]],
    ) -> List[str]:
        """
        Register N logical jobs for one physical job.

        Args:
            physical_job_id: Queue job_id for the batch.
            slices: List of (start_index, count) per logical job, in order.

        Returns:
            List of N logical_job_ids (UUIDs) in the same order as slices.
        """
        logical_ids: List[str] = []
        with self._lock:
            for start_index, count in slices:
                logical_job_id = str(uuid.uuid4())
                entry = LogicalJobEntry(
                    logical_job_id=logical_job_id,
                    physical_job_id=physical_job_id,
                    start_index=start_index,
                    count=count,
                )
                self._logical[logical_job_id] = entry
                logical_ids.append(logical_job_id)
        return logical_ids

    def get_logical_job(self, logical_job_id: str) -> Optional[LogicalJobEntry]:
        """
        Return the entry for a logical job, or None if unknown.

        Args:
            logical_job_id: Client-facing job id.

        Returns:
            LogicalJobEntry or None.
        """
        with self._lock:
            return self._logical.get(logical_job_id)

    def set_physical_result(
        self,
        physical_job_id: str,
        result: Dict[str, Any],
    ) -> None:
        """
        Store the full result for a completed physical job (success).

        Args:
            physical_job_id: Batch job id from queue.
            result: Full result dict (e.g. data with embeddings, results,
                model, dimension, device).
        """
        with self._lock:
            self._physical_results[physical_job_id] = result
            self._physical_errors.pop(physical_job_id, None)

    def set_physical_error(
        self,
        physical_job_id: str,
        error: Dict[str, Any],
    ) -> None:
        """
        Store error for a failed physical job; all logical jobs in batch get this error.

        Args:
            physical_job_id: Batch job id from queue.
            error: Error dict to return to clients.
        """
        with self._lock:
            self._physical_errors[physical_job_id] = error
            self._physical_results.pop(physical_job_id, None)

    def get_physical_result(
        self,
        physical_job_id: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Return stored result for a physical job, or None if not completed.

        Args:
            physical_job_id: Batch job id.

        Returns:
            Full result dict or None.
        """
        with self._lock:
            return self._physical_results.get(physical_job_id)

    def get_physical_error(
        self,
        physical_job_id: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Return stored error for a physical job, or None.

        Args:
            physical_job_id: Batch job id.

        Returns:
            Error dict or None.
        """
        with self._lock:
            return self._physical_errors.get(physical_job_id)
