"""
Build merged payload and slice metadata for coalesced embed batch jobs.

From BatchDescriptor produces params for one queue job, including
_coalesced_slices. See docs/coalescing_plan/05_coalescer_payload.md.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import Any, Dict

from embed.coalescing.coalescer_buffer import BatchDescriptor


def build_batch_payload(descriptor: BatchDescriptor) -> Dict[str, Any]:
    """
    Build the params dict for a single coalesced batch job.

    Result is valid for EmbedCommand.execute(): texts, model, dimension,
    error_policy, device, plus _coalesced_slices for slicing.
    sum(_coalesced_slices) must equal len(texts).

    Args:
        descriptor: Batch with merged_texts, counts, and homogeneity key.

    Returns:
        Dict with keys: texts, model, dimension, error_policy, device,
        _coalesced_slices (list of counts per logical request).
    """
    model, dimension, error_policy, device = descriptor.key
    payload: Dict[str, Any] = {
        "texts": list(descriptor.merged_texts),
        "model": model,
        "dimension": dimension,
        "error_policy": error_policy,
        "device": device,
        "_coalesced_slices": list(descriptor.counts),
    }
    return payload
