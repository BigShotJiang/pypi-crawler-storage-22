"""
Embedding service commands module.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

This module exports command classes and provides module-level auto-registration
for spawn mode compatibility (required for CUDA). Commands are registered both:
1. Via hooks in main process (register_custom_commands_hook)
2. At module level for child processes (auto-registration on import)
"""

import os
import sys

# Export command classes for direct import
from embed.commands.embed_command import EmbedCommand
from embed.commands.embed_router import EmbedRouterCommand
from embed.commands.models_command import ModelsCommand
from embed.commands.embed_job_status_command import EmbedJobStatusCommand
from embed.commands.timing_stats_command import TimingStatsCommand

__all__ = [
    "EmbedCommand",
    "EmbedRouterCommand",
    "ModelsCommand",
    "EmbedJobStatusCommand",
    "TimingStatsCommand",
]


def _auto_register_commands():
    """
    Auto-register commands at module level for spawn mode compatibility.

    This function is called when the module is imported, ensuring commands
    are registered in child processes spawned by the queue manager.
    This is required for CUDA compatibility (spawn mode).
    """
    try:
        from mcp_proxy_adapter.commands.command_registry import registry
        from mcp_proxy_adapter.core.logging import get_global_logger

        logger = get_global_logger()
        logger.info(
            "🔁 [EMBED] Auto-registration triggered (pid=%s, module=%s, cwd=%s)",
            os.getpid(),
            __name__,
            os.getcwd(),
        )

        # Idempotent registration - same set as main's register_embedding_commands
        commands_registered = 0

        try:
            registry.get_command("embed")
        except (KeyError, AttributeError):
            registry.register(EmbedRouterCommand, "custom")
            commands_registered += 1
            logger.info("🔁 [EMBED] Registered 'embed' (router) in auto-registration")

        # embed_execute: queue workers (router submits jobs with command=embed_execute)
        try:
            registry.get_command("embed_execute")
        except (KeyError, AttributeError):

            class EmbedExecuteCommand(EmbedCommand):
                """Embed for queue workers (spawn); same as EmbedCommand."""

                name = "embed_execute"

            registry.register(EmbedExecuteCommand, "custom")
            commands_registered += 1
            logger.info("🔁 [EMBED] Registered 'embed_execute' in auto-registration")

        try:
            registry.get_command("models")
        except (KeyError, AttributeError):
            registry.register(ModelsCommand, "custom")
            commands_registered += 1
            logger.info("🔁 [EMBED] Registered 'models' in auto-registration flow")

        try:
            registry.get_command("embed_job_status")
        except (KeyError, AttributeError):
            registry.register(EmbedJobStatusCommand, "custom")
            commands_registered += 1
            logger.info("🔁 [EMBED] Registered 'embed_job_status' in auto-registration")

        try:
            registry.get_command("timing_stats")
        except (KeyError, AttributeError):
            registry.register(TimingStatsCommand, "custom")
            commands_registered += 1
            logger.info("🔁 [EMBED] Registered 'timing_stats' in auto-registration")

        if commands_registered == 0:
            logger.info("ℹ️ [EMBED] Auto-registration: all commands already set")
        else:
            logger.info(
                "✅ [EMBED] Auto-registration done, new commands: %s",
                commands_registered,
            )
    except Exception as e:
        try:
            from mcp_proxy_adapter.core.logging import get_global_logger

            logger = get_global_logger()
            logger.warning(
                "⚠️ [EMBED] Auto-registration failed in pid=%s, reason=%s",
                os.getpid(),
                e,
            )
        except Exception:
            msg = f"[EMBED][AUTO-REGISTER] Failed (pid={os.getpid()}): {e}"
            print(msg, file=sys.stderr)


# Execute auto-registration when module is imported
# This ensures commands are available in child processes (spawn mode)
_auto_register_commands()
