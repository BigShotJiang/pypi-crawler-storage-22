"""
Command for embedding texts using the embedding service.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import time
from typing import Any, Dict, List, cast

from mcp_proxy_adapter.commands.base import Command
from mcp_proxy_adapter.core.errors import (
    InternalError,
    InvalidParamsError,
    ValidationError,
)
from mcp_proxy_adapter.core.logging import logger
from mcp_proxy_adapter.commands.result import ErrorResult, SuccessResult

from embed.results import EmbedResult
from embed.commands.embed_command_schema import (
    EMBED_COMMAND_METADATA,
    EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY,
    get_embed_params_schema,
    get_embed_result_schema,
    get_embed_error_schema,
    get_embed_metadata,
)
from embed.commands.embed_command_executor import run_embed_execute
from embed.commands.embed_command_helpers import (
    record_timing_on_error,
    texts_from_kwargs,
)
from embed.utils.gpu_utils import get_gpu_info, is_cuda_error


class EmbedCommand(Command):
    """
    Command for generating embeddings for texts with tokens.

    This command is executed asynchronously via the internal queue
    (`use_queue = True`). The immediate response contains a `job_id`
    and status information; the actual embeddings must be retrieved
    later using the `embed_job_status` (or `queue_get_job_status`)
    command.

    Parameters:
        - texts (List[str], required): Input texts to embed.
        - model (str, optional): Model name to use.
        - dimension (int, optional): Expected vector dimension.

    The final result (when the job is completed) contains:
        - results: Per-text objects with original body, embedding,
          tokens and bm25_tokens.
        - model: Name of the model used.
        - dimension: Dimension of the generated vectors.
    """

    name = "embed"
    result_class = EmbedResult
    # Always execute via queue for async processing of large data volumes
    use_queue = True

    # Lightweight metadata for documentation and discovery
    metadata: Dict[str, Any] = EMBED_COMMAND_METADATA

    def validate_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate and normalize command parameters.

        Args:
            params: Raw parameters from request

        Returns:
            Dict[str, Any]: Validated and normalized parameters
        """
        # Normalize text/texts to texts (single helper for API contract)
        texts = texts_from_kwargs(params)
        if texts is not None:
            params["texts"] = texts
        if "text" in params:
            params.pop("text", None)

        # Coalesced batch jobs carry internal slice metadata; strip so schema accepts
        params.pop("_coalesced_slices", None)

        # Call parent validation
        return cast(Dict[str, Any], super().validate_params(params))

    async def execute(self, context=None, **kwargs) -> SuccessResult:
        """
        Execute the embed command.

        Args:
            **kwargs: Command parameters

        Returns:
            SuccessResult: Command result with embeddings data
        """
        rpc_start = time.time()
        service_init_time_ref: List[float] = [0.0]

        try:
            validated_params = self.validate_params(kwargs)
            texts = validated_params.get("texts")
            dimension = validated_params.get("dimension")
            error_policy = (
                validated_params.get("error_policy")
                or EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY
            )
            device = validated_params.get("device", "auto")

            if texts is None:
                raise InvalidParamsError("Parameter 'texts' is required")
            if not isinstance(texts, list):
                raise InvalidParamsError("Parameter 'texts' must be a list")
            if len(texts) == 0:
                raise InvalidParamsError("Empty texts list provided")

            for i, text in enumerate(texts):
                if not isinstance(text, str):
                    raise InvalidParamsError(f"Text at index {i} must be a string")
                if error_policy != "continue" and not text.strip():
                    raise InvalidParamsError(
                        f"Text at index {i} cannot be empty or whitespace"
                    )

            if error_policy not in ("fail_fast", "continue"):
                raise InvalidParamsError(
                    "Parameter 'error_policy' must be 'fail_fast' or 'continue'"
                )

            valid_devices = ("auto", "cpu", "cuda", "cuda:0")
            if device not in valid_devices and not (
                isinstance(device, str) and device.startswith("cuda:")
            ):
                raise InvalidParamsError(
                    f"Parameter 'device' must be one of {valid_devices} "
                    f"or 'cuda:N' (got: {device})"
                )

            if dimension is not None:
                if not isinstance(dimension, int) or dimension <= 0:
                    raise InvalidParamsError(
                        "Parameter 'dimension' must be a positive integer"
                    )

            return await run_embed_execute(
                rpc_start, service_init_time_ref, validated_params
            )

        except (InvalidParamsError, ValidationError) as e:
            logger.error("Validation error in embed command: %s", e)
            record_timing_on_error(rpc_start, texts_from_kwargs(kwargs), 0.0, str(e))
            return ErrorResult(
                message=str(e), code=e.code, details={"original_error": str(e)}
            )
        except InternalError as e:
            logger.error("Internal error in embed command: %s", e)
            error_details: Dict[str, Any] = {"original_error": str(e)}
            if is_cuda_error(e):
                gpu_info = get_gpu_info()
                if gpu_info:
                    error_details["gpu_info"] = gpu_info
                    error_details["error_type"] = "cuda_error"
            record_timing_on_error(
                rpc_start,
                texts_from_kwargs(kwargs),
                service_init_time_ref[0],
                str(e),
            )
            return ErrorResult(message=str(e), code=e.code, details=error_details)
        except Exception as e:
            logger.exception("Unexpected error in embed command: %s", e, exc_info=True)
            error_details_ex: Dict[str, Any] = {"original_error": str(e)}
            if is_cuda_error(e):
                gpu_info = get_gpu_info()
                if gpu_info:
                    error_details_ex["gpu_info"] = gpu_info
                    error_details_ex["error_type"] = "cuda_error"
            record_timing_on_error(
                rpc_start,
                texts_from_kwargs(kwargs),
                service_init_time_ref[0],
                str(e),
            )
            return ErrorResult(
                message="Internal server error",
                code=-32603,
                details=error_details_ex,
            )

    @classmethod
    def get_schema(cls) -> Dict[str, Any]:
        """
        Get JSON schema for command parameters

        Returns:
            JSON schema with examples
        """
        return get_embed_params_schema()

    @classmethod
    def get_result_schema(cls) -> Dict[str, Any]:
        """
        Get JSON schema for successful result structure

        Returns:
            JSON schema for success response
        """
        return get_embed_result_schema()

    @classmethod
    def get_error_schema(cls) -> Dict[str, Any]:
        """
        Get JSON schema for error result structure

        Returns:
            JSON schema for error response
        """
        return get_embed_error_schema()

    @classmethod
    def get_metadata(cls) -> dict:
        """
        Get complete metadata for the command

        Returns:
            Complete command metadata
        """
        return get_embed_metadata(name=cls.name, description=cls.__doc__ or "")
