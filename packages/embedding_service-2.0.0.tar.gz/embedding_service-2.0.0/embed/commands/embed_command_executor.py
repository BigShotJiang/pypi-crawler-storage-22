"""
Core execution logic for embed command (model server vs direct service, encode, result).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import time
from typing import Any, Dict, List, Optional, Tuple

from mcp_proxy_adapter.core.errors import InvalidParamsError, InternalError
from mcp_proxy_adapter.core.logging import logger
from mcp_proxy_adapter.commands.result import SuccessResult

from embed.services.embedding_service import EmbeddingService
from embed.services.model_client import get_model_client
from embed.commands.embed_command_helpers import ensure_timing_config_loaded
from embed.commands.embed_command_schema import (
    EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY,
)
from embed.commands.embed_runtime import (
    split_into_tokens,
    get_bm25_tokens,
    generate_embeddings_continue,
)
from embed.exceptions import EmbedServiceError
from embed.utils.gpu_utils import get_gpu_info, is_cuda_error
from embed.utils.timing_recorder import is_enabled, record as record_timing
from embed.utils.gpu_memory_estimator import get_effective_encode_batch_size


def _get_config_cap_for_encode() -> int:
    """Read max_texts_per_batch from config (for model-server path)."""
    from embed.config.embed_config_loader import get_config_dict

    data = get_config_dict() or {}
    emb = data.get("embedding") or {}
    return int(emb.get("max_texts_per_batch", 0))


def _empty_cuda_cache_if_needed(service: Optional[Any]) -> None:
    """Call torch.cuda.empty_cache() when model is on GPU."""
    try:
        from embed.utils.torch_utils import import_torch

        torch = import_torch()
        if (
            torch is not None
            and torch.cuda.is_available()
            and service is not None
            and getattr(service, "model", None) is not None
        ):
            if str(service.model.device).startswith("cuda"):
                torch.cuda.empty_cache()
    except (RuntimeError, OSError):
        # Best-effort cache clear; do not fail the job on cache cleanup failure.
        pass


async def _run_chunked_encode(
    texts: List[str],
    config_cap: int,
    dimension: int,
    use_model_server: bool,
    model_client: Any,
    service: Optional[Any],
    model: Optional[str],
    device: str,
) -> Tuple[List[Any], List[Any]]:
    """
    Encode texts in chunks (effective batch size from config and GPU memory).
    Returns (embeddings, per_item_errors) with len(embeddings) == len(texts).
    Failed chunk positions get error object in per_item_errors and None in embeddings.
    """
    n = len(texts)
    embeddings: List[Any] = [None] * n
    per_item_errors: List[Any] = [None] * n
    start_idx = 0
    remaining = list(texts)
    chunk_sizes: List[int] = []

    while remaining:
        # Recompute effective batch size before each chunk (GPU memory is dynamic).
        effective = get_effective_encode_batch_size(
            config_cap, dimension, remaining[:1] if remaining else None
        )
        effective = max(1, effective)
        chunk = remaining[:effective]
        remaining = remaining[effective:]
        chunk_sizes.append(len(chunk))

        try:
            if use_model_server and model_client is not None:
                chunk_emb = await model_client.encode(chunk, model, device=device)
            else:
                assert service is not None
                chunk_emb = await service.get_embeddings(
                    chunk, model, dimension=dimension, device=device
                )
            for i, emb in enumerate(chunk_emb):
                embeddings[start_idx + i] = emb
        except Exception as e:
            err = {"code": "encode_error", "message": str(e)}
            for i in range(len(chunk)):
                per_item_errors[start_idx + i] = err
        finally:
            if not use_model_server:
                _empty_cuda_cache_if_needed(service)
        start_idx += len(chunk)

    if is_enabled() and len(chunk_sizes) > 1:
        record_timing(
            {
                "chunked_encode": True,
                "chunk_count": len(chunk_sizes),
                "chunk_sizes": chunk_sizes,
                "timestamp": time.time(),
            }
        )
    return embeddings, per_item_errors


async def run_embed_execute(
    rpc_start: float,
    service_init_time_ref: List[float],
    validated_params: Dict[str, Any],
) -> SuccessResult:
    """
    Run the embed pipeline: timing config, model server or service, encode, result.

    Sets service_init_time_ref[0] when EmbeddingService is used.
    Raises InvalidParamsError or InternalError on failure.
    """
    texts = validated_params["texts"]
    model = validated_params.get("model")
    dimension = validated_params.get("dimension")
    error_policy = (
        validated_params.get("error_policy")
        or EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY
    )
    device = validated_params.get("device", "auto")

    ensure_timing_config_loaded()

    use_model_server = False
    model_client = None

    try:
        model_client = get_model_client()
        if model_client.is_available():
            health_check_start = time.time()
            health = await model_client.health()
            health_check_time = time.time() - health_check_start
            logger.info(
                "Model server health check: %.3fs",
                health_check_time,
            )
            if health.get("success") and health.get("status") == "ready":
                use_model_server = True
                logger.info("Using model server (persistent model, no reload needed)")
            else:
                logger.warning("Model server not ready: %s", health)
    except (
        OSError,
        EmbedServiceError,
        ConnectionError,
        TimeoutError,
        ValueError,
        KeyError,
    ) as e:
        logger.warning(
            "Model server not available: %s, falling back to direct service",
            e,
        )

    if error_policy == "continue" and use_model_server:
        logger.info(
            "error_policy='continue': using direct EmbeddingService "
            "instead of model server for per-item error reporting"
        )
        use_model_server = False

    service = None
    service_init_time = 0.0

    if not use_model_server:
        service_init_start = time.time()
        try:
            if hasattr(EmbeddingService, "_instance"):
                logger.warning(
                    "Resetting EmbeddingService singleton - model will be reloaded!"
                )
                EmbeddingService._instance = None
            logger.info("Getting EmbeddingService instance...")
            service = await EmbeddingService.get_instance()
            service_init_time = time.time() - service_init_start
            service_init_time_ref[0] = service_init_time
            logger.info(
                "EmbeddingService instance obtained in %.3fs",
                service_init_time,
            )
            if service_init_time > 1.0:
                logger.warning(
                    "Service initialization took %.3fs - consider model server.",
                    service_init_time,
                )
        except Exception as e:
            logger.error("Failed to get embedding service instance: %s", e)
            raise InternalError(f"Service initialization failed: {str(e)}") from e

    embedding_start = time.time()
    model_name_for_result = None
    dimension_for_result = None
    device_info = None

    try:
        if use_model_server and model_client is not None:
            logger.info(
                "Generating embeddings via model server for %s text(s)...",
                len(texts),
            )
            config_cap = _get_config_cap_for_encode()
            dim = dimension if dimension is not None else 384
            embeddings, per_item_errors = await _run_chunked_encode(
                texts=texts,
                config_cap=config_cap,
                dimension=dim,
                use_model_server=True,
                model_client=model_client,
                service=None,
                model=model,
                device=device,
            )
            health = await model_client.health()
            model_name_for_result = health.get("model")
            dimension_for_result = health.get("dimension")
            device_info = health.get("device")
        else:
            assert service is not None
            if not service.is_model_ready():
                model_status = service.get_model_status()
                return SuccessResult(data=model_status)
            if dimension is not None and dimension != service.dimension:
                raise InvalidParamsError(
                    f"Requested dimension {dimension} does not match "
                    f"model dimension {service.dimension}"
                )
            if error_policy == "continue":
                logger.info(
                    "Generating embeddings with per-item error handling "
                    "for %s text(s)...",
                    len(texts),
                )
                embeddings, per_item_errors = await generate_embeddings_continue(
                    service=service,
                    texts=texts,
                    model=model,
                    dimension=dimension,
                    device=device,
                )
            else:
                logger.info(
                    "Generating embeddings for %s text(s)...",
                    len(texts),
                )
                config_cap = getattr(service, "max_texts_per_batch", 0) or 0
                dim = dimension if dimension is not None else service.dimension
                embeddings, per_item_errors = await _run_chunked_encode(
                    texts=texts,
                    config_cap=config_cap,
                    dimension=dim,
                    use_model_server=False,
                    model_client=None,
                    service=service,
                    model=model,
                    device=device,
                )
            model_name_for_result = service.model_name
            dimension_for_result = service.dimension
            device_info = str(service.model.device) if service.model else None

        embedding_time = time.time() - embedding_start
        logger.info(
            "Embeddings generated in %.3fs (%s texts)",
            embedding_time,
            len(texts),
        )
    except Exception as e:
        embedding_time = time.time() - embedding_start
        error_msg = str(e)
        is_cuda = is_cuda_error(e)
        logger.error(
            "Failed to generate embeddings after %.3fs: %s",
            embedding_time,
            error_msg,
        )
        gpu_info = get_gpu_info() if is_cuda else None
        if is_cuda and gpu_info:
            logger.error("CUDA error: %s. GPU info: %s", error_msg, gpu_info)
        full_error_msg = f"Embedding generation failed: {error_msg}"
        if gpu_info:
            free_mb = gpu_info.get("memory_free", 0) / (1024 * 1024)
            full_error_msg += (
                f" (GPU: {gpu_info.get('device_name', 'unknown')}, "
                f"memory_free: {free_mb:.1f}MB)"
            )
        raise InternalError(full_error_msg) from e

    tokenization_start = time.time()
    results: List[Dict[str, Any]] = []
    for i, text in enumerate(texts):
        tokens = split_into_tokens(text)
        bm25_tokens = get_bm25_tokens(text)
        results.append(
            {
                "body": text,
                "embedding": embeddings[i],
                "tokens": tokens,
                "bm25_tokens": bm25_tokens,
                "error": per_item_errors[i],
            }
        )
    tokenization_time = time.time() - tokenization_start
    logger.info("Tokenization completed in %.3fs", tokenization_time)

    rpc_seconds = time.time() - rpc_start
    if is_enabled():
        text_lens = [len(t) for t in texts]
        slices = validated_params.get("_coalesced_slices")
        if slices is not None and isinstance(slices, list):
            coalesced_batch = True
            logical_request_count = len(slices)
        else:
            coalesced_batch = False
            logical_request_count = None
        entry = {
            "is_batch": len(texts) > 1,
            "text_count": len(texts),
            "total_text_len": sum(text_lens),
            "min_text_len": min(text_lens),
            "max_text_len": max(text_lens),
            "device": (
                (device_info or "unknown").split(":")[0] if device_info else "unknown"
            ),
            "model_loaded_this_request": (
                not use_model_server and service_init_time > 1.0
            ),
            "model_load_seconds": (
                service_init_time
                if (not use_model_server and service_init_time > 0)
                else None
            ),
            "encode_seconds": embedding_time,
            "rpc_seconds": rpc_seconds,
            "tokenization_seconds": tokenization_time,
            "error": None,
            "coalesced_batch": coalesced_batch,
        }
        if coalesced_batch:
            entry["logical_request_count"] = logical_request_count
        record_timing(entry)

    return SuccessResult(
        data={
            "embeddings": embeddings,
            "results": results,
            "model": (
                model_name_for_result or (service.model_name if service else "unknown")
            ),
            "dimension": (
                dimension_for_result or (service.dimension if service else None)
            ),
            "device": device_info,
        }
    )
