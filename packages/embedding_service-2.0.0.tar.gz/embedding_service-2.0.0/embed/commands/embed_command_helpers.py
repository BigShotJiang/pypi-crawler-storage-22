"""
Helper functions for embed command (timing config, kwargs, error timing).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import time
from typing import Any, Dict, List, Optional

from mcp_proxy_adapter.core.logging import logger

from embed.config.embed_config_loader import get_embedding_section
from embed.exceptions import EmbedConfigError
from embed.utils.timing_recorder import (
    is_enabled,
    record as record_timing,
    set_config as set_timing_config,
)


def ensure_timing_config_loaded() -> None:
    """
    In spawn/worker process, load timing config from CONFIG_FILE if not set.
    Uses shared embed_config_loader (adapter ConfigLoader + cache).
    """
    try:
        emb = get_embedding_section()
        if not emb:
            return
        enabled = emb.get("timing_registration", False)
        timing_file = emb.get("timing_file")
        max_bytes = emb.get("timing_file_max_bytes")
        set_timing_config(enabled, timing_file, max_bytes)
    except (EmbedConfigError, ValueError, OSError) as e:
        logger.debug("Could not load timing config from CONFIG_FILE: %s", e)
    except Exception as e:
        logger.debug("Could not load timing config from CONFIG_FILE: %s", e)


def texts_from_kwargs(kwargs: Dict[str, Any]) -> Optional[List[str]]:
    """Extract list of texts from command kwargs (texts or text)."""
    if "texts" in kwargs and isinstance(kwargs["texts"], list):
        return kwargs["texts"]
    if "text" in kwargs and isinstance(kwargs["text"], str):
        return [kwargs["text"]]
    return None


def record_timing_on_error(
    rpc_start: float,
    texts: Optional[List[str]],
    service_init_time: float,
    error_msg: str,
) -> None:
    """Write a timing record for a failed request when timing is enabled."""
    if not is_enabled():
        return
    rpc_seconds = time.time() - rpc_start
    entry = {
        "is_batch": False,
        "text_count": 0,
        "total_text_len": 0,
        "min_text_len": 0,
        "max_text_len": 0,
        "device": "unknown",
        "model_loaded_this_request": service_init_time > 1.0,
        "model_load_seconds": (service_init_time if service_init_time > 0 else None),
        "encode_seconds": None,
        "rpc_seconds": rpc_seconds,
        "tokenization_seconds": None,
        "error": error_msg,
        "coalesced_batch": False,
    }
    if texts:
        lens = [len(t) for t in texts]
        entry["text_count"] = len(texts)
        entry["is_batch"] = len(texts) > 1
        entry["total_text_len"] = sum(lens)
        entry["min_text_len"] = min(lens) if lens else 0
        entry["max_text_len"] = max(lens) if lens else 0
    record_timing(entry)
