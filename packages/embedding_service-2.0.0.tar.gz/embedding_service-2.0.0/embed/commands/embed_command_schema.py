"""
Schemas and metadata helpers for the embed command.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import Dict, Any

from embed.constants import EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY  # noqa: F401


def get_embed_params_schema() -> Dict[str, Any]:
    """
    Get JSON schema for embed command parameters.

    Returns:
        JSON schema with examples for the embed command parameters.
    """
    return {
        "type": "object",
        "properties": {
            "texts": {
                "type": "array",
                "description": "List of texts to create embeddings for",
                "items": {"type": "string"},
                "examples": [["This is a sample text for embedding generation"]],
            },
            "model": {
                "type": "string",
                "description": "Model name to use (optional)",
                "example": "paraphrase-multilingual-MiniLM-L12-v2",
            },
            "dimension": {
                "type": "integer",
                "description": "Optional expected vector dimension",
                "example": 384,
            },
            "error_policy": {
                "type": "string",
                "description": (
                    "Error handling policy for batch embedding. "
                    "'fail_fast' stops on first content error and returns "
                    "a top-level error (legacy behaviour). 'continue' records "
                    "per-item errors in results[i].error and continues "
                    "processing the rest of the batch."
                ),
                "enum": ["fail_fast", "continue"],
                "example": "continue",
            },
            "device": {
                "type": "string",
                "description": (
                    "Device: 'auto' (detection), 'cpu', 'cuda' or 'cuda:0'. "
                    "When 'auto', GPU is used if available and has enough memory."
                ),
                "enum": ["auto", "cpu", "cuda", "cuda:0"],
                "example": "auto",
                "default": "auto",
            },
        },
        "required": ["texts"],
        "additionalProperties": False,
        "example": {
            "texts": ["This is a sample text for embedding generation"],
            "model": "paraphrase-multilingual-MiniLM-L12-v2",
            "dimension": 384,
            "device": "auto",
        },
        "description": (
            "Command for creating vector embeddings from input texts with "
            "corresponding tokens. Executed asynchronously via queue and "
            "returns a job_id that should be polled via 'embed_job_status'."
        ),
    }


def get_embed_result_schema() -> Dict[str, Any]:
    """
    Get JSON schema for successful embed command result.

    Returns:
        JSON schema describing the success response structure.
    """
    return {
        "type": "object",
        "properties": {
            "success": {"type": "boolean", "const": True},
            "data": {
                "type": "object",
                "properties": {
                    "results": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "body": {
                                    "type": "string",
                                    "description": "Original source text",
                                },
                                "embedding": {
                                    "type": "array",
                                    "items": {"type": "number"},
                                    "description": "Vector representation of the text",
                                },
                                "tokens": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                    "description": "Text split into tokens",
                                },
                                "bm25_tokens": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                    "description": (
                                        "BM25-compatible tokens (lowercase, filtered)"
                                    ),
                                },
                                "error": {
                                    "type": ["object", "null"],
                                    "description": (
                                        "Per-item error (when embedding failed "
                                        "for this text)."
                                    ),
                                    "properties": {
                                        "code": {
                                            "type": "string",
                                            "description": "Error code",
                                        },
                                        "message": {
                                            "type": "string",
                                            "description": "Human-readable message",
                                        },
                                    },
                                },
                            },
                            "required": ["body", "embedding", "tokens", "bm25_tokens"],
                        },
                    },
                    "model": {
                        "type": "string",
                        "description": "Model used for embeddings",
                    },
                    "dimension": {
                        "type": "integer",
                        "description": "Vector dimension",
                    },
                    "device": {
                        "type": "string",
                        "description": (
                            "Device used for processing (cpu, cuda, cuda:0, etc.)"
                        ),
                    },
                },
                "required": ["results", "model", "dimension"],
            },
        },
        "required": ["success", "data"],
    }


def get_embed_error_schema() -> Dict[str, Any]:
    """
    Get JSON schema for error result structure.

    Returns:
        JSON schema describing the error response structure.
    """
    return {
        "type": "object",
        "properties": {
            "success": {"type": "boolean", "const": False},
            "error": {
                "type": "object",
                "properties": {
                    "code": {
                        "type": "integer",
                        "enum": [-32602, -32603],
                        "description": "Error code",
                    },
                    "message": {
                        "type": "string",
                        "description": "Error message",
                    },
                    "data": {
                        "type": "object",
                        "properties": {
                            "original_error": {"type": "string"},
                        },
                    },
                },
                "required": ["code", "message"],
            },
        },
        "required": ["success", "error"],
    }


def get_embed_metadata(name: str, description: str) -> Dict[str, Any]:
    """
    Build complete metadata for the embed command.

    Args:
        name: Command name.
        description: Command description (usually class docstring).

    Returns:
        Complete command metadata dictionary.
    """
    return {
        "name": name,
        "description": description,
        "params": get_embed_params_schema(),
        "result_schema": get_embed_result_schema(),
        "error_schema": get_embed_error_schema(),
        "error_codes": [
            {
                "code": -32602,
                "description": "Invalid parameters",
                "when": "Missing/invalid parameters",
            },
            {
                "code": -32603,
                "description": "Internal error",
                "when": "Service failures",
            },
        ],
        "examples": {
            "success": {
                "success": True,
                "data": {
                    "results": [
                        {
                            "body": "Hello, world!",
                            "embedding": [0.1, 0.2, 0.3],
                            "tokens": ["Hello", ",", "world", "!"],
                            "bm25_tokens": ["hello", "world"],
                        }
                    ],
                    "model": "all-MiniLM-L6-v2",
                    "dimension": 384,
                },
            },
            "error_validation": {
                "success": False,
                "error": {
                    "code": -32602,
                    "message": "Invalid params: Empty texts list provided",
                    "data": {
                        "original_error": "Empty texts list provided",
                    },
                },
            },
            "error_internal": {
                "success": False,
                "error": {
                    "code": -32603,
                    "message": "Internal server error",
                    "data": {
                        "original_error": "Service unavailable",
                    },
                },
            },
        },
    }


EMBED_COMMAND_METADATA: Dict[str, Any] = {
    "description": (
        "Generate embeddings for texts with corresponding tokens. "
        "This command automatically uses queue for async processing and "
        "returns a job_id that can be monitored via 'embed_job_status'."
    ),
    "examples": [
        {
            "description": "Generate embeddings for a single text (async via queue)",
            "request": {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Hello, world!"]},
                "id": 1,
            },
        },
        {
            "description": "Generate embeddings for multiple texts (async via queue)",
            "request": {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Hello, world!", "Привет, мир!"]},
                "id": 1,
            },
        },
    ],
    "returns": {
        "success": {
            "results": (
                "Array of objects with body, embedding, tokens and "
                "bm25_tokens for each text"
            ),
            "model": "Name of the model used",
            "dimension": "Dimension of the generated vectors",
        },
        "error": {
            "code": "Error code according to JSON-RPC spec",
            "message": "Human readable error message",
            "data": {
                "original_error": "Original error message",
            },
        },
    },
}
