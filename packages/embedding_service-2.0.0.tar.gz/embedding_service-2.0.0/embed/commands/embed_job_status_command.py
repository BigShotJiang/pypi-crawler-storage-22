"""
Command for checking embedding job status.

Resolves logical job_id (coalesced slice) via LogicalJobStore; physical
job_id delegated to queue_get_job_status. See docs/coalescing_plan/08.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import Any, Dict

from mcp_proxy_adapter.commands.base import Command
from mcp_proxy_adapter.core.errors import InvalidParamsError
from mcp_proxy_adapter.core.logging import logger
from mcp_proxy_adapter.commands.result import ErrorResult, SuccessResult
from mcp_proxy_adapter.integrations.queuemgr_integration import get_global_queue_manager
from mcp_proxy_adapter.commands.command_registry import registry

from embed.coalescing import get_logical_job_store
from embed.coalescing.logical_job_store import LogicalJobStore


class EmbedJobStatusCommand(Command):
    """
    Command for checking status of embedding job and retrieving result.

    Parameters:
        job_id (str, required): Job identifier to check status for.

    Returns:
        Success:
            {
                "success": true,
                "data": {
                    "exists": true,
                    "status": "completed|running|pending|failed",
                    "done": true|false,
                    "result": {
                        "success": true,
                        "data": {
                            "results": [...],
                            "model": "...",
                            "dimension": 384
                        }
                    }  # Only present if job is completed
                }
            }
        Error:
            {
                "success": false,
                "error": {
                    "code": -32602,
                    "message": "Error description",
                    "data": {"original_error": "..."}
                }
            }

    Error codes:
        | Code  | Description              | When
        |-------|--------------------------|---------------------------
        | -32602| Invalid params           | Missing/invalid job_id
        | -32603| Internal error           | Queue manager unavailable

    Examples:
        Request:
            {
                "jsonrpc": "2.0",
                "method": "embed_job_status",
                "params": {
                    "job_id": "97c1ce57-4b39-4534-bcca-601431cbbe49"
                },
                "id": 1
            }

        Response (completed):
            {
                "jsonrpc": "2.0",
                "result": {
                    "success": true,
                    "data": {
                        "exists": true,
                        "status": "completed",
                        "done": true,
                        "result": {
                            "success": true,
                            "data": {
                                "results": [
                                    {
                                        "body": "Hello, world!",
                                        "embedding": [0.1, 0.2, 0.3, ...],
                                        "tokens": ["Hello", ",", "world", "!"],
                                        "bm25_tokens": ["hello", "world"]
                                    }
                                ],
                                "model": "all-MiniLM-L6-v2",
                                "dimension": 384
                            }
                        }
                    }
                },
                "id": 1
            }

        Response (running):
            {
                "jsonrpc": "2.0",
                "result": {
                    "success": true,
                    "data": {
                        "exists": true,
                        "status": "running",
                        "done": false
                    }
                },
                "id": 1
            }

        Response (not found):
            {
                "jsonrpc": "2.0",
                "result": {
                    "success": true,
                    "data": {
                        "exists": false,
                        "job_id": "97c1ce57-4b39-4534-bcca-601431cbbe49",
                        "message": "Job not found"
                    }
                },
                "id": 1
            }
    """

    name = "embed_job_status"

    def validate_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate and normalize command parameters.

        Args:
            params: Raw parameters from request

        Returns:
            Dict[str, Any]: Validated and normalized parameters
        """
        if "job_id" not in params:
            raise InvalidParamsError("Parameter 'job_id' is required")

        job_id = params["job_id"]
        if not isinstance(job_id, str) or not job_id.strip():
            raise InvalidParamsError("Parameter 'job_id' must be a non-empty string")

        return {"job_id": job_id.strip()}

    async def execute(self, context=None, **kwargs) -> SuccessResult:
        """
        Execute the embed_job_status command.

        If job_id is a logical job (coalesced batch slice), resolve via store:
        pending/slice/error. Otherwise delegate to queue_get_job_status.
        """
        try:
            validated_params = self.validate_params(kwargs)
            job_id = validated_params["job_id"]

            store = get_logical_job_store()
            entry = store.get_logical_job(job_id)
            if entry is not None:
                return await self._resolve_logical_job(
                    job_id=job_id,
                    physical_id=entry.physical_job_id,
                    start_index=entry.start_index,
                    count=entry.count,
                    store=store,
                    context=context,
                )

            return await self._delegate_physical_job(job_id, context)

        except InvalidParamsError as e:
            logger.error(f"Validation error in embed_job_status command: {e}")
            return ErrorResult(
                message=str(e), code=e.code, details={"original_error": str(e)}
            )
        except Exception as e:
            logger.exception(
                "Unexpected error in embed_job_status command: %s",
                e,
                exc_info=True,
            )
            return ErrorResult(
                message="Internal server error",
                code=-32603,
                details={"original_error": str(e)},
            )

    async def _resolve_logical_job(
        self,
        job_id: str,
        physical_id: str,
        start_index: int,
        count: int,
        store: LogicalJobStore,
        context: Any,
    ) -> SuccessResult:
        """Resolve logical job: store then queue; return pending or sliced result."""
        err = store.get_physical_error(physical_id)
        if err is not None:
            return SuccessResult(
                data={
                    "exists": True,
                    "status": "failed",
                    "done": True,
                    "result": None,
                    "error": err,
                }
            )
        full = store.get_physical_result(physical_id)
        if full is not None:
            slice_data = self._slice_result(full, start_index, count)
            return SuccessResult(
                data={
                    "exists": True,
                    "status": "completed",
                    "done": True,
                    "result": {"success": True, "data": slice_data},
                }
            )
        queue_manager = await get_global_queue_manager()
        if queue_manager is None:
            return SuccessResult(
                data={
                    "exists": True,
                    "status": "pending",
                    "done": False,
                }
            )
        queue_cmd_class = registry.get_command("queue_get_job_status")
        if queue_cmd_class is None:
            return SuccessResult(
                data={"exists": True, "status": "pending", "done": False}
            )
        queue_cmd = queue_cmd_class()
        queue_result = await queue_cmd.execute(context=context, job_id=physical_id)
        from mcp_proxy_adapter.commands.result import (
            SuccessResult as QueueSuccessResult,
        )

        if not isinstance(queue_result, QueueSuccessResult):
            return SuccessResult(
                data={"exists": True, "status": "pending", "done": False}
            )
        qdata = queue_result.data or {}
        status = qdata.get("status", "pending")
        if status in ("pending", "running"):
            return SuccessResult(data={"exists": True, "status": status, "done": False})
        if status == "failed":
            error_info = qdata.get("error") or {"message": "Job failed"}
            store.set_physical_error(physical_id, error_info)
            return SuccessResult(
                data={
                    "exists": True,
                    "status": "failed",
                    "done": True,
                    "result": None,
                    "error": error_info,
                }
            )
        if status == "completed":
            raw_result = qdata.get("result")
            if isinstance(raw_result, dict) and raw_result.get("success"):
                embed_data = raw_result.get("data") or raw_result
            else:
                embed_data = raw_result if isinstance(raw_result, dict) else {}
            store.set_physical_result(physical_id, embed_data)
            slice_data = self._slice_result(embed_data, start_index, count)
            return SuccessResult(
                data={
                    "exists": True,
                    "status": "completed",
                    "done": True,
                    "result": {"success": True, "data": slice_data},
                }
            )
        return SuccessResult(data={"exists": True, "status": "pending", "done": False})

    @staticmethod
    def _slice_result(
        full: Dict[str, Any], start_index: int, count: int
    ) -> Dict[str, Any]:
        """Slice embeddings and results by [start_index:start_index+count]."""
        end = start_index + count
        embeddings = full.get("embeddings") or []
        results = full.get("results") or []
        return {
            "embeddings": embeddings[start_index:end],
            "results": results[start_index:end],
            "model": full.get("model"),
            "dimension": full.get("dimension"),
            "device": full.get("device"),
        }

    async def _delegate_physical_job(self, job_id: str, context: Any) -> SuccessResult:
        """Delegate to queue_get_job_status for physical job_id."""
        queue_manager = await get_global_queue_manager()
        if queue_manager is None:
            logger.error("Queue manager is not available")
            return ErrorResult(
                message="Queue manager is not available",
                code=-32603,
                details={"original_error": "Queue manager not initialized"},
            )
        queue_cmd_class = registry.get_command("queue_get_job_status")
        if queue_cmd_class is None:
            logger.error("queue_get_job_status command not found")
            return ErrorResult(
                message="Queue status command not available",
                code=-32603,
                details={"original_error": "queue_get_job_status not registered"},
            )
        queue_cmd = queue_cmd_class()
        queue_result = await queue_cmd.execute(context=context, job_id=job_id)
        from mcp_proxy_adapter.commands.result import (
            SuccessResult as QueueSuccessResult,
            ErrorResult as QueueErrorResult,
        )

        if isinstance(queue_result, QueueSuccessResult):
            return SuccessResult(data=queue_result.data)
        if isinstance(queue_result, QueueErrorResult):
            return SuccessResult(
                data={
                    "exists": False,
                    "job_id": job_id,
                    "message": f"Job {job_id} not found",
                }
            )
        logger.warning(
            "Unexpected result type from queue_get_job_status: %s",
            type(queue_result),
        )
        return SuccessResult(
            data={
                "exists": False,
                "job_id": job_id,
                "message": f"Job {job_id} not found",
            }
        )

    @classmethod
    def get_schema(cls) -> Dict[str, Any]:
        """
        Get JSON schema for command parameters.

        Returns:
            JSON schema
        """
        return {
            "type": "object",
            "properties": {
                "job_id": {
                    "type": "string",
                    "description": "Job identifier to check status for",
                    "example": "97c1ce57-4b39-4534-bcca-601431cbbe49",
                }
            },
            "required": ["job_id"],
            "additionalProperties": False,
        }
