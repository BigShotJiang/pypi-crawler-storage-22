"""
Embed command router: immediate enqueue or sync.

Request is never buffered. When queue is enabled, the job is put in the
adapter queue immediately and the client receives job_id. Worker forms
batches by GPU memory or config (embed_command_executor chunked encode);
result is stored with the same job_id for embed_job_status.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import uuid
from typing import Any, Dict

from mcp_proxy_adapter.commands.base import Command
from mcp_proxy_adapter.commands.result import ErrorResult, SuccessResult
from mcp_proxy_adapter.core.logging import logger
from mcp_proxy_adapter.integrations.queuemgr_integration import (
    QueueJobError,
    get_global_queue_manager,
)

from embed.commands.embed_command import EmbedCommand
from embed.exceptions import EmbedError, EmbedQueueError, EmbedServiceError


async def _queue_submit_embed(payload: Dict[str, Any]) -> str:
    """Submit one embed job to the adapter queue; return physical job_id."""
    from mcp_proxy_adapter.commands.queue.jobs import CommandExecutionJob

    queue_manager = await get_global_queue_manager()
    if queue_manager is None:
        raise EmbedQueueError("Queue manager is not initialized")
    job_id = str(uuid.uuid4())
    job_params = {
        "command": "embed_execute",
        "params": payload,
        "context": None,
        "auto_import_modules": ["embed.commands"],
    }
    await queue_manager.add_job(CommandExecutionJob, job_id, job_params)
    try:
        await queue_manager.start_job(job_id)
    except (EmbedQueueError, EmbedServiceError, OSError) as e:
        logger.warning("start_job %s failed: %s", job_id, e)
        raise
    return job_id


class EmbedRouterCommand(Command):
    """
    Router for embed: immediate enqueue (return job_id) or sync execute.

    When queue_manager is enabled, every request is enqueued immediately;
    client gets job_id and polls embed_job_status. Batching is done only
    in the worker (GPU/config) when processing.
    """

    name = "embed"

    def __init__(self) -> None:
        """Init router; delegate validation/execute to EmbedCommand."""
        super().__init__()
        self._embed_command = EmbedCommand()

    def validate_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Reuse EmbedCommand validation."""
        return self._embed_command.validate_params(params)

    async def execute(self, context=None, **kwargs) -> SuccessResult:
        """Enqueue immediately if queue enabled, else sync; return job_id or result."""
        try:
            validated = self.validate_params(kwargs)
        except (ValueError, EmbedError) as e:
            logger.warning("Embed validation error: %s", e)
            return ErrorResult(
                message=str(e),
                code=getattr(e, "code", -32602),
                details={"original_error": str(e)},
            )
        except Exception as e:
            logger.exception("Embed validation error: %s", e, exc_info=True)
            return ErrorResult(
                message=str(e),
                code=getattr(e, "code", -32602),
                details={"original_error": str(e)},
            )
        try:
            queue_manager = await get_global_queue_manager()
        except QueueJobError:
            queue_manager = None
        if queue_manager is not None:
            job_id = await _queue_submit_embed(validated)
            return SuccessResult(
                data={
                    "job_id": job_id,
                    "status": "pending",
                    "message": "Job queued successfully",
                }
            )
        return await self._embed_command.execute(context=context, **validated)
