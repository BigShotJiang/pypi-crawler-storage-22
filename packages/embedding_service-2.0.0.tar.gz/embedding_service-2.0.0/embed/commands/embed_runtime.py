"""
Runtime helpers for EmbedCommand: tokenization and per-item embedding logic.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import Any, List, Tuple

from mcp_proxy_adapter.core.errors import (
    ValidationError as CoreValidationError,
)
from mcp_proxy_adapter.core.logging import logger

from embed.services.bm25_service import BM25Service
from embed.services.embedding_service import EmbeddingService


def split_into_tokens(text: str) -> List[str]:
    """
    Split text into simple word-based tokens.

    This is a thin wrapper over the regex-based tokenizer previously used
    inside EmbedCommand.
    """
    import re

    tokens = re.findall(r"\\w+|[^\\w\\s]", text)
    return [token for token in tokens if token.strip()]


def get_bm25_tokens(text: str) -> List[str]:
    """
    Get BM25 tokens for text using BM25Service.
    """
    try:
        bm25_service = BM25Service()
        return bm25_service.get_bm25_tokens(text)
    except Exception as exc:  # pragma: no cover - defensive logging
        logger.warning("Failed to generate BM25 tokens: %s", exc)
        return []


async def generate_embeddings_continue(
    service: EmbeddingService,
    texts: List[str],
    model: Any,
    dimension: Any,
    device: str = "auto",
) -> Tuple[List[Any], List[Any]]:
    """
    Generate embeddings in per-item mode, capturing ValidationError as
    per-item error objects instead of failing the whole batch.

    Args:
        service: EmbeddingService instance
        texts: List of texts to embed
        model: Optional model name
        dimension: Optional dimension
        device: Device to use ("auto", "cpu", "cuda", etc.)
    """
    # Handle batch size limit up front
    max_batch_size = getattr(service, "MAX_BATCH_SIZE", None)
    if max_batch_size is not None and len(texts) > max_batch_size:
        message = (
            f"Batch size {len(texts)} exceeds the maximum allowed "
            f"({max_batch_size})"
        )
        error_obj = {"code": "batch_limit_exceeded", "message": message}
        return [None] * len(texts), [error_obj] * len(texts)

    embeddings: List[Any] = []
    per_item_errors: List[Any] = []

    for i, text in enumerate(texts):
        try:
            single_embeddings = await service.get_embeddings(
                [text],
                model,
                dimension,
                device=device,
            )
            embedding_vector = single_embeddings[0]
            embeddings.append(embedding_vector)
            per_item_errors.append(None)
        # content-level problem for this text
        except CoreValidationError as ve:
            msg = str(ve)
            lower_msg = msg.lower()
            if "too long" in lower_msg:
                code = "too_long"
            elif "only special characters" in lower_msg:
                code = "only_special_chars"
            elif "invalid characters" in lower_msg:
                code = "invalid_characters"
            elif "empty text" in lower_msg:
                code = "too_short"
            elif "batch size" in lower_msg:
                code = "batch_limit_exceeded"
            else:
                code = "validation_error"

            embeddings.append(None)
            per_item_errors.append({"code": code, "message": msg})
        # Any other error (model failure, etc.) is considered fatal
        except Exception:
            raise

    return embeddings, per_item_errors
