"""
Models command.

Provides information about available embedding models.
"""

from typing import Dict, Any

from mcp_proxy_adapter.commands.base import Command
from mcp_proxy_adapter.core.errors import InternalError
from mcp_proxy_adapter.core.logging import logger
from mcp_proxy_adapter.commands.result import ErrorResult, SuccessResult
from embed.services.embedding_service import EmbeddingService


class ModelsCommand(Command):
    """Command for getting available embedding models"""

    name = "models"
    result_class = SuccessResult

    # Command metadata
    metadata = {
        "description": "Get list of available embedding models",
        "examples": [
            {
                "request": {"jsonrpc": "2.0", "method": "models", "id": 1},
                "response": {
                    "jsonrpc": "2.0",
                    "result": {
                        "models": [
                            {
                                "name": "all-MiniLM-L6-v2",
                                "dimension": 384,
                                "supported_dimensions": [384],
                                "max_tokens": 128,
                            }
                        ]
                    },
                    "id": 1,
                },
            },
            {
                "description": "Error response example",
                "request": {"jsonrpc": "2.0", "method": "models", "id": 1},
                "response": {
                    "jsonrpc": "2.0",
                    "error": {
                        "code": -32603,
                        "message": "Internal error: Failed to get models",
                        "data": {"original_error": "Service unavailable"},
                    },
                    "id": 1,
                },
            },
        ],
        "returns": {
            "success": {
                "models": (
                    "List of model information including name, dimension, "
                    "supported dimensions, and max tokens"
                )
            },
            "error": {
                "code": "Error code according to JSON-RPC spec",
                "message": "Human readable error message",
                "data": {"original_error": "Original error message"},
            },
        },
    }

    async def execute(self, context=None, **kwargs) -> SuccessResult:
        """
        Execute the command.
        Uses EmbeddingService.get_instance() when available; otherwise returns
        static MODEL_DIMENSIONS list so the command works before init or in workers.
        """
        try:
            service = await EmbeddingService.get_instance()
            models = await service.get_available_models()
            return SuccessResult(data={"models": models})
        except InternalError as e:
            logger.warning("Models from instance failed (%s), using static list", e)
        except Exception as e:
            logger.warning(
                "Models from instance failed (%s), using static list", e, exc_info=False
            )
        try:
            models = EmbeddingService.get_available_models_info()
            return SuccessResult(data={"models": models})
        except Exception as e:
            logger.exception("Models command failed: %s", e, exc_info=True)
            return ErrorResult(
                message="Internal server error",
                code=-32603,
                details={"original_error": str(e)},
            )

    @classmethod
    def get_schema(cls) -> Dict[str, Any]:
        """
        Get JSON schema for command parameters

        Returns:
            JSON schema with examples
        """
        return {
            "type": "object",
            "properties": {},
            "additionalProperties": False,
            "description": """
Command for retrieving information about available embedding models.

Example:
```json
{
    "jsonrpc": "2.0",
    "method": "models",
    "id": 1
}
```

Response:
```json
{
    "jsonrpc": "2.0",
    "result": {
        "models": [
            {
                "id": "paraphrase-multilingual-MiniLM-L12-v2",
                "dimensions": 384
            }
        ]
    },
    "id": 1
}
```

Error response:
```json
{
    "jsonrpc": "2.0",
    "error": {
        "code": -32603,
        "message": "Command execution error: ...",
        "data": {
            "original_error": "..."
        }
    },
    "id": 1
}
```
""",
        }
