"""
Command to read timing records and compute statistical analytics.

Reads the JSONL timing file (when timing_registration is enabled), computes
quantiles, medians, and aggregates by batch/single and device. Includes
time taken to compute the statistics.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from mcp_proxy_adapter.commands.base import Command
from mcp_proxy_adapter.core.errors import InvalidParamsError, InternalError
from mcp_proxy_adapter.core.logging import logger
from mcp_proxy_adapter.commands.result import SuccessResult

from embed.utils.timing_recorder import get_config


def _quantiles(
    values: List[float], levels: Optional[List[float]] = None
) -> Dict[str, float]:
    """Compute quantiles for given levels (default 0.25..0.99)."""
    if not values:
        return {}
    if levels is None:
        levels = [0.25, 0.5, 0.75, 0.9, 0.95, 0.99]
    sorted_v = sorted(values)
    k = len(sorted_v)
    result = {}
    for q in levels:
        if q <= 0 or q >= 1:
            continue
        idx = (k - 1) * q
        lo = int(idx)
        frac = idx - lo
        if lo + 1 < k:
            val = sorted_v[lo] + frac * (sorted_v[lo + 1] - sorted_v[lo])
        else:
            val = sorted_v[lo]
        result[f"q{int(q*100)}"] = round(val, 6)
    return result


def _median(values: List[float]) -> Optional[float]:
    """Return median of values; None if empty. Rounded to 6 decimal places."""
    if not values:
        return None
    sorted_v = sorted(values)
    k = len(sorted_v)
    mid = k // 2
    if k % 2 == 1:
        return round(sorted_v[mid], 6)
    return round((sorted_v[mid - 1] + sorted_v[mid]) / 2, 6)


def _read_records(file_path: str) -> List[Dict[str, Any]]:
    """Read JSONL file and return list of records. Skips invalid lines."""
    records: List[Dict[str, Any]] = []
    path = Path(file_path)
    if not path.exists():
        return records
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return records


def _compute_stats(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Compute full statistics from timing records.

    Expects current schema only: every record has coalesced_batch (bool).
    When coalesced_batch is True, record has logical_request_count (int).
    No fallback for missing keys.
    """
    if not records:
        return {
            "total_requests": 0,
            "calculation_time_seconds": 0,
            "message": "No records in file or file empty",
        }

    # Coalesced vs non-coalesced (every record has coalesced_batch)
    coalesced_records = [r for r in records if r["coalesced_batch"] is True]
    non_coalesced_records = [r for r in records if r["coalesced_batch"] is False]

    # Separate by batch vs single and by device
    success_records = [r for r in records if not r.get("error")]
    error_records = [r for r in records if r.get("error")]
    batch_records = [r for r in records if r.get("is_batch") is True]
    single_records = [r for r in records if r.get("is_batch") is False]
    batch_success = [r for r in success_records if r.get("is_batch") is True]
    single_success = [r for r in success_records if r.get("is_batch") is False]

    def _series(key: str) -> List[float]:
        """Float values for key from success_records (skip missing/None)."""
        return [r[key] for r in success_records if key in r and r[key] is not None]

    encode_sec = _series("encode_seconds")
    rpc_sec = _series("rpc_seconds")
    total_len = _series("total_text_len")
    max_len = _series("max_text_len")
    text_count = _series("text_count")
    _ = _series("model_load_seconds")
    token_sec = _series("tokenization_seconds")

    def _stats(name: str, values: List[float]) -> Dict[str, Any]:
        """Compute count, median, quantiles, min, max, mean for a series of floats."""
        if not values:
            return {"count": 0, "median": None, "quantiles": {}}
        return {
            "count": len(values),
            "median": _median(values),
            "quantiles": _quantiles(values),
            "min": round(min(values), 6),
            "max": round(max(values), 6),
            "mean": round(sum(values) / len(values), 6),
        }

    by_device: Dict[str, List[Dict[str, Any]]] = {}
    for r in success_records:
        dev = r.get("device") or "unknown"
        by_device.setdefault(dev, []).append(r)

    device_stats = {}
    for dev, recs in by_device.items():
        enc = [x["encode_seconds"] for x in recs if x.get("encode_seconds") is not None]
        rpc = [x["rpc_seconds"] for x in recs if x.get("rpc_seconds") is not None]
        device_stats[dev] = {
            "request_count": len(recs),
            "encode_seconds": _stats("encode_seconds", enc),
            "rpc_seconds": _stats("rpc_seconds", rpc),
        }

    model_loaded_count = sum(
        1 for r in success_records if r.get("model_loaded_this_request") is True
    )
    model_load_total = sum(
        r.get("model_load_seconds") or 0
        for r in success_records
        if r.get("model_load_seconds") is not None
    )

    # Optional: logical_request_count stats for coalesced records
    logical_counts = [
        r["logical_request_count"]
        for r in coalesced_records
        if "logical_request_count" in r and r["logical_request_count"] is not None
    ]
    logical_request_stats = _stats("logical_request_count", logical_counts)

    return {
        "total_requests": len(records),
        "success_count": len(success_records),
        "error_count": len(error_records),
        "coalesced_batch_count": len(coalesced_records),
        "non_coalesced_count": len(non_coalesced_records),
        "logical_request_count_per_record": logical_request_stats,
        "batch_requests_count": len(batch_records),
        "single_requests_count": len(single_records),
        "encode_seconds": _stats("encode_seconds", encode_sec),
        "rpc_seconds": _stats("rpc_seconds", rpc_sec),
        "total_text_len": _stats("total_text_len", total_len),
        "max_text_len_per_request": _stats("max_text_len", max_len),
        "text_count_per_request": _stats("text_count", text_count),
        "tokenization_seconds": _stats("tokenization_seconds", token_sec),
        "model_load": {
            "requests_with_model_load": model_loaded_count,
            "total_model_load_seconds": round(model_load_total, 6),
            "model_loaded_each_time_ratio": (
                round(model_loaded_count / len(success_records), 4)
                if success_records
                else None
            ),
        },
        "by_device": device_stats,
        "batch_vs_single": {
            "batch": {
                "count": len(batch_records),
                "encode_seconds": _stats(
                    "encode_seconds",
                    [
                        r["encode_seconds"]
                        for r in batch_success
                        if r.get("encode_seconds") is not None
                    ],
                ),
                "rpc_seconds": _stats(
                    "rpc_seconds",
                    [
                        r["rpc_seconds"]
                        for r in batch_success
                        if r.get("rpc_seconds") is not None
                    ],
                ),
            },
            "single": {
                "count": len(single_records),
                "encode_seconds": _stats(
                    "encode_seconds",
                    [
                        r["encode_seconds"]
                        for r in single_success
                        if r.get("encode_seconds") is not None
                    ],
                ),
                "rpc_seconds": _stats(
                    "rpc_seconds",
                    [
                        r["rpc_seconds"]
                        for r in single_success
                        if r.get("rpc_seconds") is not None
                    ],
                ),
            },
        },
    }


class TimingStatsCommand(Command):
    """
    Read timing log file and return statistical analytics.

    Parameters:
        - file_path (str, optional): Path to JSONL timing file. If omitted,
          uses the path from config (embedding.timing_file) or default
          ./logs/embed_timings.jsonl.

    Returns:
        - total_requests, success_count, error_count
        - batch_requests_count, single_requests_count
        - encode_seconds, rpc_seconds: median, quantiles, min, max, mean
        - total_text_len, max_text_len_per_request, text_count_per_request
        - model_load: requests_with_model_load, total_model_load_seconds,
          model_loaded_each_time_ratio
        - by_device: per-device request count and timing stats
        - batch_vs_single: stats broken down by batch vs single requests
        - calculation_time_seconds: time taken to compute this result
    """

    name = "timing_stats"
    result_class = SuccessResult

    def validate_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Validate timing_stats params: optional file_path must be non-empty string."""
        if not isinstance(params, dict):
            raise InvalidParamsError("Params must be an object")
        file_path = params.get("file_path")
        if file_path is not None and (
            not isinstance(file_path, str) or not file_path.strip()
        ):
            raise InvalidParamsError(
                "file_path must be a non-empty string when provided"
            )
        return params

    async def execute(self, context=None, **kwargs) -> SuccessResult:
        calc_start = time.time()
        file_path = (kwargs.get("file_path") or "").strip()
        if not file_path:
            _, file_path, _ = get_config()
            if not file_path:
                file_path = "./logs/embed_timings.jsonl"

        try:
            records = _read_records(file_path)
            stats = _compute_stats(records)
            stats["calculation_time_seconds"] = round(time.time() - calc_start, 6)
            stats["file_path"] = file_path
            stats["records_read"] = len(records)
            return SuccessResult(data=stats)
        except Exception as e:
            logger.exception("Failed to compute timing stats: %s", e, exc_info=True)
            raise InternalError(f"Failed to compute timing statistics: {str(e)}") from e
