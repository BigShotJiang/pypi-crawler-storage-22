"""
Configuration management module for embedding service.

Provides: ConfigManager, config_validator (validate_config), config_generator
(generate_config). Use embed.config.config_validator and config_generator
for all validation and generation in the project.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

from .config_manager import ConfigManager
from .config_validator import validate_config
from .config_generator import generate_config, get_default_config

__all__ = [
    "ConfigManager",
    "validate_config",
    "generate_config",
    "get_default_config",
]
