"""
Coalescing (request batching) configuration model.

Request coalescing merges multiple embed requests over a short time window
into a single batch for one forward pass. See docs/COALESCING_PROPOSAL.md.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import Optional

from pydantic import BaseModel, Field, field_validator


class CoalescingConfig(BaseModel):
    """
    Request coalescing (dynamic batching) configuration.

    When enabled, multiple embed requests that arrive within the time window
    are merged into one batch job; results are split back per request.
    """

    enabled: bool = Field(
        False,
        description="Enable request coalescing (default off).",
    )
    coalescing_window_sec: float = Field(
        0.03,
        description="Seconds to wait before sending batch (e.g. 0.02–0.05).",
    )
    coalescing_max_texts: int = Field(
        64,
        description="Flush when batch reaches this many texts.",
    )
    coalescing_max_wait_sec: Optional[float] = Field(
        0.1,
        description="Max wait per request (None = window/max_texts).",
    )

    @field_validator("coalescing_window_sec")
    @classmethod
    def window_positive(cls, v: float) -> float:
        """Ensure coalescing_window_sec is positive."""
        if v <= 0:
            raise ValueError("coalescing_window_sec must be positive")
        return v

    @field_validator("coalescing_max_texts")
    @classmethod
    def max_texts_positive(cls, v: int) -> int:
        """Ensure coalescing_max_texts is positive."""
        if v <= 0:
            raise ValueError("coalescing_max_texts must be positive")
        return v

    @field_validator("coalescing_max_wait_sec")
    @classmethod
    def max_wait_non_negative(cls, v: Optional[float]) -> Optional[float]:
        """Ensure coalescing_max_wait_sec is >= 0 when set."""
        if v is not None and v < 0:
            raise ValueError("coalescing_max_wait_sec must be >= 0 when set")
        return v
