"""
Default configuration builder for embedding service.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from embed.config.coalescing_config import CoalescingConfig
from embed.config.config_schema import (
    ConfigModel,
    EmbeddingConfig,
    ProtocolConfig,
    QueueManagerConfig,
    SecurityConfig,
    ServerConfig,
)


def build_default_config() -> ConfigModel:
    """
    Build and return the default ConfigModel instance.

    Returns:
        Default configuration model.
    """
    return ConfigModel(
        server=ServerConfig(host="0.0.0.0", port=8000, workers=1, timeout=30),
        security=SecurityConfig(
            mode="http",
            cert_file=None,
            key_file=None,
            ca_file=None,
            verify_ssl=True,
            token_file=None,
            roles_file=None,
        ),
        protocols=[ProtocolConfig(name="embedding", version="1.0", enabled=True)],
        embedding=EmbeddingConfig(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            device="cpu",
            max_length=512,
            batch_size=32,
            max_batch_size=512,
            max_text_length=1_000_000,
            max_texts_per_batch=0,
            timing_registration=False,
            timing_file=None,
            timing_file_max_bytes=None,
        ),
        queue_manager=QueueManagerConfig(
            enabled=True,
            in_memory=True,
            max_concurrent_jobs=1,
            completed_job_retention_seconds=3600,
        ),
        coalescing=CoalescingConfig(
            enabled=False,
            coalescing_window_sec=0.03,
            coalescing_max_texts=64,
            coalescing_max_wait_sec=0.1,
        ),
        commands_directory="./commands",
        log_level="INFO",
    )
