"""
Configuration generator for embedding service.

Built on top of mcp_proxy_adapter SimpleConfigGenerator. Produces adapter-compatible
base (server, client, registration, auth, queue_manager, server_validation) then
merges embed-specific sections (embedding, coalescing, protocols, commands, logging,
transport, ssl, security). Validates with adapter + embed validator before return.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import copy
import json
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional, cast

from embed.config.config_validator import validate_config


def _embed_only_defaults() -> Dict[str, Any]:
    """Default values for embed-specific sections (not produced by adapter)."""
    return {
        "transport": {
            "type": "http",
            "port": None,
            "verify_client": False,
            "chk_hostname": False,
        },
        "ssl": {
            "enabled": False,
            "cert_file": None,
            "key_file": None,
            "ca_cert": None,
            "verify_client": False,
            "client_cert_required": False,
        },
        "security": {
            "enabled": True,
            "mode": "http",
            "auth": {
                "enabled": True,
                "methods": ["api_key"],
                "api_keys": {
                    "embed-admin-token": "admin",
                    "embed-user-token": "user",
                    "embed-readonly-token": "readonly",
                },
            },
            "permissions": {"enabled": True, "roles_file": None},
        },
        "embedding": {
            "model_name": "all-MiniLM-L6-v2",
            "device": "auto",
            "use_cache": True,
            "cache_dir": None,
            "max_batch_size": 512,
            "max_text_length": 1_000_000,
            "max_texts_per_batch": 0,
            "timing_registration": False,
            "timing_file": None,
            "timing_file_max_bytes": None,
        },
        "coalescing": {
            "enabled": False,
            "coalescing_window_sec": 0.03,
            "coalescing_max_texts": 64,
            "coalescing_max_wait_sec": 0.1,
        },
        "protocols": {
            "enabled": True,
            "allowed_protocols": ["http"],
            "default_protocol": "http",
            "strict_mode": False,
        },
        "commands": {
            "enabled": True,
            "auto_discover": True,
            "custom_commands": ["embed", "models", "health"],
            "command_timeout": 30,
        },
        "logging": {
            "level": "INFO",
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            "console_output": True,
            "file_output": False,
            "file_path": None,
        },
    }


def _client_cert_path_from_server_path(server_path: Optional[str]) -> Optional[str]:
    """
    Derive client cert path from server cert path (proxy expects client certs for
    registration, same pattern as svo-chunker). Replaces /server/ with /client/.
    """
    if not server_path or "/server/" not in server_path:
        return None
    return server_path.replace("/server/", "/client/", 1)


def _service_name_from_cert_path(cert_path: Optional[str]) -> Optional[str]:
    """Extract service name from cert path (e.g. .../server/embedding-service.crt)."""
    if not cert_path:
        return None
    base = Path(cert_path).stem
    return base if base else None


def _adapter_base_from_generator(overrides: Dict[str, Any]) -> Dict[str, Any]:
    """
    Produce adapter-compatible config dict using mcp_proxy_adapter
    SimpleConfigGenerator. Writes to a temp file and reads back (file-based API).
    For mTLS + proxy registration uses client certs (not server) unless overridden.
    """
    server = overrides.get("server") or {}
    registration = overrides.get("registration") or {}
    protocol = server.get("protocol", "http")
    with_proxy = registration.get("enabled", False)
    server_port = server.get("port") or 8000
    server_host = server.get("host", "127.0.0.1")

    # Registration proxy URL: derive host/port from register_url if present
    register_url = registration.get("register_url") or ""
    reg_host: Optional[str] = None
    reg_port: Optional[int] = None
    if register_url and register_url.startswith(("http://", "https://")):
        try:
            from urllib.parse import urlparse

            parsed = urlparse(register_url)
            if parsed.hostname:
                reg_host = parsed.hostname
            if parsed.port is not None:
                reg_port = parsed.port
        except Exception:
            pass
    if with_proxy and (reg_host is None or reg_port is None):
        raise ValueError(
            "registration.register_url (with host and port) is required when "
            "registration.enabled is true"
        )
    if reg_host is None:
        reg_host = "localhost"
    if reg_port is None:
        reg_port = 3005

    # Cert paths for mtls/https (server.ssl, overrides.ssl, or security)
    server_ssl = server.get("ssl") or {}
    ssl_over = overrides.get("ssl") or {}
    sec_over = overrides.get("security") or {}
    server_ca = (
        server.get("ca_cert_file")
        or server_ssl.get("ca")
        or ssl_over.get("ca_cert")
        or sec_over.get("ca_file")
    )
    server_cert = (
        server.get("cert_file")
        or server_ssl.get("cert")
        or ssl_over.get("cert_file")
        or sec_over.get("cert_file")
    )
    server_key = (
        server.get("key_file")
        or server_ssl.get("key")
        or ssl_over.get("key_file")
        or sec_over.get("key_file")
    )
    reg_ssl = registration.get("ssl") or {}
    # For mTLS proxy registration use client certs (like svo-chunker) unless overridden
    reg_protocol = registration.get("protocol") or protocol
    if reg_ssl.get("cert") or reg_ssl.get("cert_file"):
        reg_cert = reg_ssl.get("cert") or reg_ssl.get("cert_file")
        reg_key = reg_ssl.get("key") or reg_ssl.get("key_file") or server_key
    elif reg_protocol in ("https", "mtls") and server_cert and server_key:
        client_cert = _client_cert_path_from_server_path(server_cert)
        client_key = _client_cert_path_from_server_path(server_key)
        reg_cert = client_cert if client_cert else server_cert
        reg_key = client_key if client_key else server_key
    else:
        reg_cert = server_cert
        reg_key = server_key
    reg_ca = reg_ssl.get("ca") or reg_ssl.get("ca_cert") or server_ca

    reg_server_id = registration.get("server_id")
    reg_server_name = registration.get("server_name")
    if with_proxy and reg_server_id is None:
        reg_server_id = server.get("advertised_host") or _service_name_from_cert_path(
            server_cert
        )
        if reg_server_id is None:
            raise ValueError(
                "registration.server_id or server.advertised_host is required "
                "when registration.enabled is true"
            )
    if with_proxy and reg_server_name is None and reg_server_id:
        reg_server_name = reg_server_id.replace("-", " ").title()

    from mcp_proxy_adapter.core.config.simple_config_generator import (
        SimpleConfigGenerator,
    )

    gen = SimpleConfigGenerator()
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False, encoding="utf-8"
    ) as f:
        tmp_path = f.name
    try:
        gen.generate(
            protocol=protocol,
            with_proxy=with_proxy,
            out_path=tmp_path,
            server_host=server_host,
            server_port=server_port,
            server_ca_cert_file=server_ca,
            server_cert_file=server_cert,
            server_key_file=server_key,
            registration_cert_file=reg_cert,
            registration_key_file=reg_key,
            registration_ca_cert_file=reg_ca,
            registration_host=reg_host,
            registration_port=reg_port,
            registration_protocol=reg_protocol,
            registration_server_id=reg_server_id,
            registration_server_name=reg_server_name,
            instance_uuid=registration.get("instance_uuid"),
        )
        with open(tmp_path, "r", encoding="utf-8") as f:
            return cast(Dict[str, Any], json.load(f))
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> None:
    """Merge override into base in-place (nested dicts merged)."""
    for k, v in override.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _deep_merge(base[k], v)
        else:
            base[k] = copy.deepcopy(v)


# Keys in queue_manager that older mcp_proxy_adapter may not accept (container image).
# Stripping them keeps generated config loadable by both old and new adapter.
_QUEUE_MANAGER_OPTIONAL_KEYS = ("default_poll_interval", "default_max_wait_time")


def _strip_optional_queue_manager_keys(config_dict: Dict[str, Any]) -> None:
    """Remove optional queue_manager keys for older adapter compatibility (in-place)."""
    qm = config_dict.get("queue_manager")
    if isinstance(qm, dict):
        for key in _QUEUE_MANAGER_OPTIONAL_KEYS:
            qm.pop(key, None)


def generate_config(
    overrides: Optional[Dict[str, Any]] = None,
    config_path: Optional[str] = None,
    skip_file_checks: bool = False,
    validate: bool = True,
) -> Dict[str, Any]:
    """
    Generate configuration dict from adapter generator + embed sections and overrides.

    Uses mcp_proxy_adapter SimpleConfigGenerator for server, client, registration,
    auth, queue_manager, server_validation. Adds embed-only sections (embedding,
    coalescing, protocols, commands, logging, transport, ssl, security). Then
    applies overrides and optionally validates with adapter-based validator.

    Args:
        overrides: Optional nested dict to merge last (e.g. {"server": {"port": 9000}}).
        config_path: If set, passed to validator so relative paths (e.g. certs) are
            resolved from this path's directory (for local config with local paths).
        skip_file_checks: If True, validator skips adapter file-existence checks
            (for container config whose paths are valid only in container).
        validate: If False, return merged config without running validation.

    Returns:
        Configuration dict (valid if validate=True).

    Raises:
        ValueError: If validation fails when validate=True.
    """
    if overrides is None:
        overrides = {}

    base: Dict[str, Any] = _adapter_base_from_generator(overrides)
    embed_defaults = _embed_only_defaults()
    _deep_merge(base, embed_defaults)
    _deep_merge(base, copy.deepcopy(overrides))
    _strip_optional_queue_manager_keys(base)

    # Align server.advertised_host with registration.server_id when not set
    # (container/svo pattern)
    if isinstance(base.get("server"), dict) and isinstance(
        base.get("registration"), dict
    ):
        reg_id = base["registration"].get("server_id")
        if reg_id and not base["server"].get("advertised_host"):
            base["server"]["advertised_host"] = reg_id

    if validate:
        errors = validate_config(
            base,
            config_path=config_path,
            skip_file_checks=skip_file_checks,
        )
        if errors:
            raise ValueError(
                "Configuration validation failed:\n  - " + "\n  - ".join(errors)
            )
    return base


_REQUIRED_CONTAINER_PARAMS = (
    "registration_host",
    "registration_port",
    "registration_protocol",
    "server_port",
    "server_host",
    "service_name",
    "server_ssl_dir",
    "registration_ssl_dir",
    "timing_file",
    "timing_file_max_bytes",
)


def build_container_overrides(
    *,
    registration_host: str,
    registration_port: int,
    registration_protocol: str,
    server_port: int,
    server_host: str,
    service_name: str,
    server_ssl_dir: str,
    registration_ssl_dir: str,
    timing_file: str,
    timing_file_max_bytes: int,
) -> Dict[str, Any]:
    """
    Build container overrides dict from parameters. No defaults.

    All parameters are required. Caller (CLI or script) must pass every value.
    """
    scheme = "https" if registration_protocol in ("https", "mtls") else "http"
    register_url = f"{scheme}://{registration_host}:{registration_port}/register"
    unregister_url = f"{scheme}://{registration_host}:{registration_port}/unregister"
    heartbeat_url = (
        f"{scheme}://{registration_host}:{registration_port}/proxy/heartbeat"
    )
    server_name = service_name.replace("-", " ").title()
    return {
        "server": {
            "host": server_host,
            "port": server_port,
            "protocol": registration_protocol,
            "advertised_host": service_name,
            "ssl": {
                "cert": f"{server_ssl_dir}/server/{service_name}.crt",
                "key": f"{server_ssl_dir}/server/{service_name}.key",
                "ca": f"{server_ssl_dir}/ca/ca.crt",
            },
        },
        "registration": {
            "enabled": True,
            "protocol": registration_protocol,
            "register_url": register_url,
            "unregister_url": unregister_url,
            "heartbeat": {"url": heartbeat_url, "interval": 30},
            "server_id": service_name,
            "server_name": server_name,
            "ssl": {
                "cert": f"{registration_ssl_dir}/client/{service_name}.crt",
                "key": f"{registration_ssl_dir}/client/{service_name}.key",
                "ca": f"{registration_ssl_dir}/ca/ca.crt",
            },
        },
        "ssl": {
            "enabled": True,
            "cert_file": f"{server_ssl_dir}/server/{service_name}.crt",
            "key_file": f"{server_ssl_dir}/server/{service_name}.key",
            "ca_cert": f"{server_ssl_dir}/ca/ca.crt",
            "verify_client": True,
            "client_cert_required": True,
        },
        "transport": {
            "type": registration_protocol,
            "port": server_port,
            "verify_client": True,
            "chk_hostname": False,
        },
        "security": {
            "mode": registration_protocol,
            "cert_file": f"{server_ssl_dir}/server/{service_name}.crt",
            "key_file": f"{server_ssl_dir}/server/{service_name}.key",
            "ca_file": f"{server_ssl_dir}/ca/ca.crt",
        },
        "protocols": {
            "allowed_protocols": [registration_protocol, "http"],
            "default_protocol": registration_protocol,
        },
        "embedding": {
            "timing_registration": True,
            "timing_file": timing_file,
            "timing_file_max_bytes": timing_file_max_bytes,
        },
    }


_VALIDATION_PATH_PARAMS = (
    "server_ssl_dir_validate",
    "registration_ssl_dir_validate",
    "timing_file_validate",
)


def generate_container_config(
    config_path: Optional[str] = None,
    **container_params: Any,
) -> Dict[str, Any]:
    """
    Generate config for container from parameters. No defaults.

    Every container parameter must be passed; missing param raises ValueError.
    Optional validation path params (server_ssl_dir_validate,
    registration_ssl_dir_validate, timing_file_validate): when provided,
    validation runs using these paths (e.g. host); output keeps container paths.
    """
    missing = [k for k in _REQUIRED_CONTAINER_PARAMS if k not in container_params]
    if missing:
        raise ValueError(
            f"Missing required container parameters: {', '.join(sorted(missing))}"
        )
    overrides = build_container_overrides(
        **{k: v for k, v in container_params.items() if k in _REQUIRED_CONTAINER_PARAMS}
    )
    validation_paths = {
        k: container_params[k]
        for k in _VALIDATION_PATH_PARAMS
        if k in container_params and container_params[k] is not None
    }
    if validation_paths:
        server_ssl = (
            container_params.get("server_ssl_dir_validate")
            or container_params["server_ssl_dir"]
        )
        reg_ssl = (
            container_params.get("registration_ssl_dir_validate")
            or container_params["registration_ssl_dir"]
        )
        timing = (
            container_params.get("timing_file_validate")
            or container_params["timing_file"]
        )
        validation_overrides = build_container_overrides(
            registration_host=container_params["registration_host"],
            registration_port=container_params["registration_port"],
            registration_protocol=container_params["registration_protocol"],
            server_port=container_params["server_port"],
            server_host=container_params["server_host"],
            service_name=container_params["service_name"],
            server_ssl_dir=server_ssl,
            registration_ssl_dir=reg_ssl,
            timing_file=timing,
            timing_file_max_bytes=container_params["timing_file_max_bytes"],
        )
        generate_config(
            validation_overrides,
            config_path=config_path,
            skip_file_checks=False,
            validate=True,
        )
        return generate_config(
            overrides,
            config_path=config_path,
            validate=False,
        )
    return generate_config(
        overrides,
        config_path=config_path,
        skip_file_checks=False,
        validate=True,
    )


def get_default_config() -> Dict[str, Any]:
    """
    Return default configuration (adapter base + embed sections, no overrides).
    Convenience wrapper around generate_config().
    """
    return generate_config(overrides=None)
