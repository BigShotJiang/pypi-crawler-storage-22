"""
Configuration manager for embedding service.

This module provides configuration loading, validation, and management
for tests and CLI tools that need an explicit config path and full ConfigModel.
For runtime config (main process, commands, initializer) use embed_config_loader
with CONFIG_FILE only. File loading uses mcp_proxy_adapter ConfigLoader.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from pydantic import ValidationError

from embed.config.coalescing_config import CoalescingConfig
from embed.config.config_defaults import build_default_config
from embed.config.config_schema import (
    ConfigModel,
    EmbeddingConfig,
    ProtocolConfig,
    QueueManagerConfig,
    SecurityConfig,
    ServerConfig,
)

logger = logging.getLogger(__name__)


class ConfigManager:
    """
    Configuration manager for embedding service.

    This class handles loading, validation, and management of configuration
    files for the embedding service.
    """

    def __init__(self, config_path: Optional[Union[str, Path]] = None):
        """
        Initialize configuration manager.

        Args:
            config_path: Path to configuration file
        """
        self.config_path = Path(config_path) if config_path else None
        self.config: Optional[ConfigModel] = None
        self._loaded = False

    def load_from_file(self, config_path: Union[str, Path]) -> ConfigModel:
        """
        Load configuration from file.

        Args:
            config_path: Path to configuration file

        Returns:
            Loaded configuration model

        Raises:
            FileNotFoundError: If configuration file not found
            ValidationError: If configuration is invalid
            json.JSONDecodeError: If JSON is malformed
        """
        config_path = Path(config_path)

        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")

        try:
            from mcp_proxy_adapter.core.config.config_loader import ConfigLoader

            config_data = ConfigLoader().load_from_file(config_path)
            self.config = ConfigModel(**config_data)
            self.config_path = config_path
            self._loaded = True

            logger.info(f"Configuration loaded from: {config_path}")
            return self.config

        except json.JSONDecodeError as e:
            raise json.JSONDecodeError(
                f"Invalid JSON in configuration file: {e}", e.doc, e.pos
            )
        except ValidationError as e:
            raise e

    def load_from_dict(self, config_data: Dict[str, Any]) -> ConfigModel:
        """
        Load configuration from dictionary.

        Args:
            config_data: Configuration data dictionary

        Returns:
            Loaded configuration model

        Raises:
            ValidationError: If configuration is invalid
        """
        try:
            self.config = ConfigModel(**config_data)
            self._loaded = True

            logger.info("Configuration loaded from dictionary")
            return self.config

        except ValidationError as e:
            raise e

    def save_to_file(self, config_path: Optional[Union[str, Path]] = None) -> None:
        """
        Save configuration to file.

        Args:
            config_path: Path to save configuration (uses current path if None)

        Raises:
            ValueError: If no configuration is loaded
            OSError: If file cannot be written
        """
        if not self._loaded or self.config is None:
            raise ValueError("No configuration loaded")

        save_path = Path(config_path) if config_path else self.config_path

        if save_path is None:
            raise ValueError("No save path specified")

        try:
            # Create directory if it doesn't exist
            save_path.parent.mkdir(parents=True, exist_ok=True)

            with open(save_path, "w", encoding="utf-8") as f:
                json.dump(self.config.model_dump(), f, indent=2, ensure_ascii=False)

            logger.info(f"Configuration saved to: {save_path}")

        except OSError as e:
            raise OSError(f"Failed to save configuration: {e}")

    def get_config(self) -> ConfigModel:
        """
        Get current configuration.

        Returns:
            Current configuration model

        Raises:
            ValueError: If no configuration is loaded
        """
        if not self._loaded or self.config is None:
            raise ValueError("No configuration loaded")

        return self.config

    def update_config(self, updates: Dict[str, Any]) -> ConfigModel:
        """
        Update configuration with new values.

        Args:
            updates: Dictionary with configuration updates

        Returns:
            Updated configuration model

        Raises:
            ValueError: If no configuration is loaded
            ValidationError: If updates are invalid
        """
        if not self._loaded or self.config is None:
            raise ValueError("No configuration loaded")

        try:
            current_data = self.config.model_dump()
            current_data.update(updates)

            self.config = ConfigModel(**current_data)
            logger.info("Configuration updated")
            return self.config

        except ValidationError as e:
            raise e

    def validate_config(self) -> bool:
        """
        Validate current configuration.

        Returns:
            True if configuration is valid

        Raises:
            ValueError: If no configuration is loaded
        """
        if not self._loaded or self.config is None:
            raise ValueError("No configuration loaded")

        try:
            # Validate by creating a new instance
            ConfigModel(**self.config.model_dump())
            logger.info("Configuration validation passed")
            return True

        except ValidationError as e:
            logger.error(f"Configuration validation failed: {e}")
            return False

    def get_server_config(self) -> ServerConfig:
        """
        Get server configuration.

        Returns:
            Server configuration

        Raises:
            ValueError: If no configuration is loaded
        """
        if not self._loaded or self.config is None:
            raise ValueError("No configuration loaded")

        return self.config.server

    def get_security_config(self) -> SecurityConfig:
        """
        Get security configuration.

        Returns:
            Security configuration

        Raises:
            ValueError: If no configuration is loaded
        """
        if not self._loaded or self.config is None:
            raise ValueError("No configuration loaded")

        return self.config.security

    def get_embedding_config(self) -> EmbeddingConfig:
        """
        Get embedding configuration.

        Returns:
            Embedding configuration

        Raises:
            ValueError: If no configuration is loaded
        """
        if not self._loaded or self.config is None:
            raise ValueError("No configuration loaded")

        return self.config.embedding

    def get_protocols(self) -> List[ProtocolConfig]:
        """
        Get protocol configurations.

        Returns:
            List of protocol configurations

        Raises:
            ValueError: If no configuration is loaded
        """
        if not self._loaded or self.config is None:
            raise ValueError("No configuration loaded")

        return self.config.protocols

    def get_queue_manager_config(self) -> Optional[QueueManagerConfig]:
        """
        Get queue manager configuration.

        Returns:
            Queue manager configuration or None if not set

        Raises:
            ValueError: If no configuration is loaded
        """
        if not self._loaded or self.config is None:
            raise ValueError("No configuration loaded")

        return self.config.queue_manager

    def get_coalescing_config(self) -> Optional[CoalescingConfig]:
        """
        Get coalescing configuration.

        Returns:
            Coalescing configuration or None if not set

        Raises:
            ValueError: If no configuration is loaded
        """
        if not self._loaded or self.config is None:
            raise ValueError("No configuration loaded")

        return self.config.coalescing

    def is_loaded(self) -> bool:
        """
        Check if configuration is loaded.

        Returns:
            True if configuration is loaded
        """
        return self._loaded

    def reload(self) -> ConfigModel:
        """
        Reload configuration from file.

        Returns:
            Reloaded configuration model

        Raises:
            ValueError: If no file path is set
            FileNotFoundError: If configuration file not found
        """
        if self.config_path is None:
            raise ValueError("No configuration file path set")

        return self.load_from_file(self.config_path)

    def create_default_config(self) -> ConfigModel:
        """
        Create default configuration.

        Returns:
            Default configuration model
        """
        self.config = build_default_config()
        self._loaded = True
        logger.info("Default configuration created")
        return self.config
