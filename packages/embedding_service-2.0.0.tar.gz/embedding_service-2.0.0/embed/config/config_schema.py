"""
Pydantic models for embedding service configuration.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import List, Optional

from pydantic import BaseModel, Field, model_validator

from embed.config.coalescing_config import CoalescingConfig


class SecurityConfig(BaseModel):
    """Security configuration model."""

    mode: str = Field(..., description="Security mode: http, https, mtls")
    cert_file: Optional[str] = Field(None, description="Certificate file path")
    key_file: Optional[str] = Field(None, description="Private key file path")
    ca_file: Optional[str] = Field(None, description="CA certificate file path")
    verify_ssl: bool = Field(True, description="Verify SSL certificates")
    token_file: Optional[str] = Field(None, description="Token file path")
    roles_file: Optional[str] = Field(None, description="Roles file path")


class ProtocolConfig(BaseModel):
    """Protocol configuration model."""

    name: str = Field(..., description="Protocol name")
    version: str = Field("1.0", description="Protocol version")
    enabled: bool = Field(True, description="Protocol enabled")


class ServerConfig(BaseModel):
    """Server configuration model."""

    host: str = Field("0.0.0.0", description="Server host")
    port: int = Field(8000, description="Server port")
    workers: int = Field(1, description="Number of workers")
    timeout: int = Field(30, description="Request timeout")


class EmbeddingConfig(BaseModel):
    """Embedding service configuration model."""

    model_name: str = Field(
        "sentence-transformers/all-MiniLM-L6-v2", description="Model name"
    )
    device: str = Field("cpu", description="Device to use: cpu, cuda, mps")
    max_length: int = Field(512, description="Maximum sequence length")
    batch_size: int = Field(32, description="Batch size for processing")
    max_batch_size: int = Field(512, description="Maximum number of texts in one batch")
    max_text_length: int = Field(
        1_000_000, description="Maximum length of a single text in characters"
    )
    max_texts_per_batch: int = Field(
        0,
        description="Max texts per encode; 0 = use only GPU memory",
    )
    timing_registration: bool = Field(
        False,
        description="Enable writing timing records to a file for analytics",
    )
    timing_file: Optional[str] = Field(
        None,
        description="Timing log path (JSONL). Default: ./logs/embed_timings.jsonl",
    )
    timing_file_max_bytes: Optional[int] = Field(
        None,
        description="Max timing file size (bytes) before rotation. None = no rotation.",
    )


class QueueManagerConfig(BaseModel):
    """Queue manager configuration model."""

    enabled: bool = Field(True, description="Enable queue manager")
    in_memory: bool = Field(True, description="Use in-memory queue")
    max_concurrent_jobs: int = Field(1, description="Maximum number of concurrent jobs")
    completed_job_retention_seconds: int = Field(
        3600, description="Retention time for completed jobs"
    )


class ConfigModel(BaseModel):
    """Main configuration model."""

    server: ServerConfig = Field(
        default_factory=lambda: ServerConfig(
            host="0.0.0.0", port=8000, workers=1, timeout=30
        ),
        description="Server configuration",
    )
    security: SecurityConfig = Field(..., description="Security configuration")
    protocols: List[ProtocolConfig] = Field(
        default_factory=list, description="Protocol configurations"
    )
    embedding: EmbeddingConfig = Field(
        default_factory=lambda: EmbeddingConfig(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            device="cpu",
            max_length=512,
            batch_size=32,
            max_batch_size=512,
            max_text_length=1_000_000,
            max_texts_per_batch=0,
            timing_registration=False,
            timing_file=None,
            timing_file_max_bytes=None,
        ),
        description="Embedding configuration",
    )
    queue_manager: Optional[QueueManagerConfig] = Field(
        default_factory=lambda: QueueManagerConfig(
            enabled=True,
            in_memory=True,
            max_concurrent_jobs=1,
            completed_job_retention_seconds=3600,
        ),
        description="Queue manager configuration",
    )
    coalescing: Optional[CoalescingConfig] = Field(
        default_factory=lambda: CoalescingConfig(
            enabled=False,
            coalescing_window_sec=0.03,
            coalescing_max_texts=64,
            coalescing_max_wait_sec=0.1,
        ),
        description="Request coalescing (batching) for embed command.",
    )
    commands_directory: str = Field("./commands", description="Commands directory path")
    log_level: str = Field("INFO", description="Logging level")

    @model_validator(mode="after")
    def coalescing_requires_queue_enabled(self) -> "ConfigModel":
        """Require queue_manager.enabled when coalescing.enabled is True."""
        if self.coalescing is not None and self.coalescing.enabled:
            if self.queue_manager is None or not self.queue_manager.enabled:
                raise ValueError("coalescing requires queue_manager.enabled to be true")
        return self
