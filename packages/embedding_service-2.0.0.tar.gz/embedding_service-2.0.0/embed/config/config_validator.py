"""
Configuration validator for embedding service.

Built on top of mcp_proxy_adapter: validates adapter sections (server, client,
registration, auth, queue_manager, server_validation) via SimpleConfig.load() and
SimpleConfigValidator. Adds embed-specific rules (embedding required, coalescing
vs queue_manager, timing) per docs/CONFIG_DEPENDENCIES.md.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import json
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

# Top-level sections: adapter (SimpleConfig) + embed-only. Reject any other key.
_ALLOWED_TOP_LEVEL = frozenset(
    {
        "server",
        "client",
        "registration",
        "server_validation",
        "auth",
        "queue_manager",  # adapter
        "transport",
        "ssl",
        "security",
        "embedding",
        "coalescing",
        "protocols",
        "commands",
        "logging",  # embed
    }
)


def _validate_top_level_keys(config_data: Dict[str, Any]) -> List[str]:
    """Reject unknown top-level keys (adapter + embed sections only)."""
    errors: List[str] = []
    for key in config_data:
        if key not in _ALLOWED_TOP_LEVEL:
            errors.append(f"Unknown top-level key: '{key}'")
    return errors


def _validate_via_adapter(
    config_data: Dict[str, Any],
    config_path: Optional[str] = None,
    skip_file_checks: bool = False,
) -> List[str]:
    """
    Validate config via mcp_proxy_adapter SimpleConfig load + SimpleConfigValidator.
    Writes config to a temp file (adapter API is file-based). When config_path is
    given, the adapter resolves relative file paths from that path's directory.
    When skip_file_checks is True (e.g. for container config), only load structure
    is validated; cert/file existence is not checked.
    Returns list of error strings.
    """
    errors: List[str] = []
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False, encoding="utf-8"
    ) as f:
        json.dump(config_data, f, indent=2, ensure_ascii=False)
        tmp_path = f.name
    try:
        from mcp_proxy_adapter.core.config.simple_config import SimpleConfig
        from mcp_proxy_adapter.core.config.simple_config_validator import (
            SimpleConfigValidator,
        )

        scfg = SimpleConfig(tmp_path)
        try:
            model = scfg.load()
        except (ValueError, TypeError, KeyError) as e:
            errors.append(f"Adapter config load failed: {e}")
            return errors
        if skip_file_checks:
            return errors
        # Use config_path for file resolution so relative paths (e.g. certs) are correct
        resolve_path = config_path if config_path else tmp_path
        validator = SimpleConfigValidator(config_path=resolve_path)
        adapter_errors = validator.validate(model)
        for err in adapter_errors:
            msg = getattr(err, "message", str(err))
            errors.append(f"Adapter: {msg}")
    except ImportError as e:
        errors.append(f"Adapter validation unavailable: {e}")
    finally:
        Path(tmp_path).unlink(missing_ok=True)
    return errors


def _validate_embed_sections(config_data: Dict[str, Any]) -> List[str]:
    """Embed-specific validation: embedding, coalescing, timing, dependencies."""
    errors: List[str] = []

    if "embedding" not in config_data:
        errors.append("Missing required section: 'embedding'")
        return errors

    emb = config_data.get("embedding")
    if not isinstance(emb, dict):
        errors.append("embedding must be an object")
        return errors

    if "model_name" not in emb:
        errors.append("embedding.model_name is required")
    if emb.get("max_batch_size") is not None:
        v = emb["max_batch_size"]
        if not isinstance(v, int) or v <= 0:
            errors.append(
                f"embedding.max_batch_size must be positive integer, got: {v!r}"
            )
    if emb.get("max_text_length") is not None:
        v = emb["max_text_length"]
        if not isinstance(v, int) or v <= 0:
            errors.append(
                f"embedding.max_text_length must be positive integer, got: {v!r}"
            )
    if emb.get("max_texts_per_batch") is not None:
        v = emb["max_texts_per_batch"]
        if not isinstance(v, int) or v < 0:
            errors.append(
                "embedding.max_texts_per_batch must be non-negative integer, "
                f"got: {v!r}"
            )
    if emb.get("timing_registration") is True:
        if emb.get("timing_file") is not None:
            tf = emb["timing_file"]
            if not isinstance(tf, str) or not tf.strip():
                errors.append("embedding.timing_file must be non-empty string when set")
        if emb.get("timing_file_max_bytes") is not None:
            v = emb["timing_file_max_bytes"]
            if not isinstance(v, int) or v <= 0:
                errors.append(
                    "embedding.timing_file_max_bytes must be positive integer when set"
                )

    coalescing = config_data.get("coalescing")
    if isinstance(coalescing, dict):
        if coalescing.get("coalescing_window_sec") is not None:
            w = coalescing["coalescing_window_sec"]
            if not isinstance(w, (int, float)) or w <= 0:
                errors.append(
                    "coalescing.coalescing_window_sec must be positive number"
                )
        if coalescing.get("coalescing_max_texts") is not None:
            m = coalescing["coalescing_max_texts"]
            if not isinstance(m, int) or m <= 0:
                errors.append(
                    "coalescing.coalescing_max_texts must be positive integer"
                )
        if coalescing.get("enabled") is True:
            qm = config_data.get("queue_manager")
            if not isinstance(qm, dict):
                errors.append("coalescing requires queue_manager section when enabled")
            elif qm.get("enabled") is not True:
                errors.append("coalescing requires queue_manager.enabled to be true")

    if "queue_manager" in config_data and isinstance(
        config_data["queue_manager"], dict
    ):
        qm = config_data["queue_manager"]
        if qm.get("max_concurrent_jobs") is not None:
            v = qm["max_concurrent_jobs"]
            if not isinstance(v, int) or v <= 0:
                errors.append(
                    "queue_manager.max_concurrent_jobs must be positive "
                    f"integer, got: {v!r}"
                )

    if "security" in config_data and isinstance(config_data["security"], dict):
        sec = config_data["security"]
        mode = sec.get("mode")
        if mode is not None and mode not in ("http", "https", "mtls"):
            errors.append("security.mode must be one of: http, https, mtls")
        elif mode == "https":
            if not (sec.get("cert_file") and sec.get("key_file")):
                errors.append(
                    "security: cert_file and key_file required when mode is https"
                )
        elif mode == "mtls":
            if not (
                sec.get("cert_file") and sec.get("key_file") and sec.get("ca_file")
            ):
                errors.append(
                    "security: cert_file, key_file, ca_file required when mode is mtls"
                )

    return errors


def validate_config(
    config_data: Dict[str, Any],
    config_path: Optional[str] = None,
    skip_file_checks: bool = False,
) -> List[str]:
    """
    Validate configuration dict using adapter validator + embed-specific rules.

    - Adapter: server, client, registration, auth, queue_manager, server_validation
      via mcp_proxy_adapter SimpleConfig.load() and SimpleConfigValidator.
    - Embed: embedding.model_name required, embedding types, coalescing vs
      queue_manager, security.mode requirements (see CONFIG_DEPENDENCIES.md).

    When config_path is set, relative paths in the config (e.g. cert files) are
    resolved from that path's directory (for file-existence checks).
    When skip_file_checks is True, adapter file-existence checks are skipped
    (for container config whose paths are valid only inside the container).

    Returns:
        List of error messages (empty if valid).
    """
    if not isinstance(config_data, dict):
        return ["Configuration must be a JSON object"]

    errors: List[str] = []
    errors.extend(_validate_top_level_keys(config_data))
    errors.extend(
        _validate_via_adapter(
            config_data,
            config_path=config_path,
            skip_file_checks=skip_file_checks,
        )
    )
    errors.extend(_validate_embed_sections(config_data))
    return errors


def is_config_valid(config_data: Dict[str, Any]) -> bool:
    """Return True if config is valid (no errors)."""
    return len(validate_config(config_data)) == 0
