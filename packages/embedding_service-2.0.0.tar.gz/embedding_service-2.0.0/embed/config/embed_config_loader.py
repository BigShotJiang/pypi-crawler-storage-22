"""
Shared config loading for embed: uses mcp_proxy_adapter ConfigLoader, single cache.

Coalescing and timing code use this module instead of loading CONFIG_FILE
separately. ConfigManager.load_from_file also uses the adapter loader to avoid
duplicate file read logic.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import os
from pathlib import Path
from typing import Any, Dict, Optional, cast

from mcp_proxy_adapter.core.config.config_loader import ConfigLoader
from mcp_proxy_adapter.core.logging import logger

from embed.config.coalescing_config import CoalescingConfig
from embed.config.config_schema import ConfigModel

# Cache by path + mtime so we reload when file changes.
_cached_path: Optional[Path] = None
_cached_mtime: Optional[float] = None
_cached_dict: Optional[Dict[str, Any]] = None
_cached_coalescing: Optional[CoalescingConfig] = None


def get_config_dict() -> Optional[Dict[str, Any]]:
    """
    Load config from CONFIG_FILE using adapter ConfigLoader; cache by path+mtime.

    Returns:
        Config dict or None if CONFIG_FILE unset/missing/invalid.
    """
    global _cached_path, _cached_mtime, _cached_dict, _cached_coalescing
    config_file = os.environ.get("CONFIG_FILE")
    if not config_file:
        return None
    path = Path(config_file)
    if not path.exists():
        return None
    try:
        mtime = path.stat().st_mtime
        if _cached_path == path and _cached_mtime == mtime and _cached_dict is not None:
            return _cached_dict
        loader = ConfigLoader()
        data = dict(loader.load_from_file(path))
        _cached_path = path
        _cached_mtime = mtime
        _cached_dict = cast(Dict[str, Any], data)
        _cached_coalescing = None
        return _cached_dict
    except (FileNotFoundError, OSError, ValueError, TypeError) as e:
        logger.debug("Could not load config from CONFIG_FILE: %s", e)
        return None
    except Exception as e:
        logger.debug("Could not load config from CONFIG_FILE: %s", e)
        return None


def get_coalescing_config() -> Optional[CoalescingConfig]:
    """
    Return coalescing config from CONFIG_FILE; uses shared loader and cache.

    Returns:
        CoalescingConfig if section valid, else None.
    """
    global _cached_coalescing
    data = get_config_dict()
    if not data:
        return None
    if _cached_coalescing is not None and _cached_dict is data:
        return _cached_coalescing
    try:
        model = ConfigModel(**data)
        _cached_coalescing = model.coalescing
        return _cached_coalescing
    except (ValueError, TypeError) as e:
        logger.debug("Could not parse coalescing config: %s", e)
        return None
    except Exception as e:
        logger.debug("Could not parse coalescing config: %s", e)
        return None


def get_embedding_section() -> Dict[str, Any]:
    """
    Return embedding section from CONFIG_FILE for timing/config; uses shared loader.

    Returns:
        Dict embedding subsection or {}.
    """
    data = get_config_dict()
    if not data:
        return {}
    emb = data.get("embedding")
    return emb if isinstance(emb, dict) else {}
