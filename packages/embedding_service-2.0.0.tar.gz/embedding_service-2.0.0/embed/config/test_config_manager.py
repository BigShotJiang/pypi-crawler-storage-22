"""
Test configuration manager functionality.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import json
import tempfile
from pathlib import Path
from unittest import TestCase

from pydantic import ValidationError

from .config_manager import (
    ConfigManager,
    ConfigModel,
    SecurityConfig,
    ServerConfig,
    EmbeddingConfig,
)


class TestConfigManager(TestCase):
    """Test cases for ConfigManager."""

    def setUp(self):
        """Set up test fixtures."""
        self.config_manager = ConfigManager()
        self.test_config_data = {
            "server": {"host": "127.0.0.1", "port": 9000, "workers": 2, "timeout": 60},
            "security": {
                "mode": "https",
                "cert_file": "/path/to/cert.pem",
                "key_file": "/path/to/key.pem",
                "verify_ssl": True,
            },
            "protocols": [{"name": "embedding", "version": "1.0", "enabled": True}],
            "embedding": {
                "model_name": "test-model",
                "device": "cpu",
                "max_length": 256,
                "batch_size": 16,
                "max_batch_size": 256,
                "max_text_length": 500000,
            },
            "queue_manager": {
                "enabled": True,
                "in_memory": True,
                "max_concurrent_jobs": 2,
                "completed_job_retention_seconds": 1800,
            },
            "commands_directory": "/test/commands",
            "log_level": "DEBUG",
        }

    def test_create_default_config(self):
        """Test creating default configuration."""
        config = self.config_manager.create_default_config()

        self.assertIsInstance(config, ConfigModel)
        self.assertEqual(config.server.host, "0.0.0.0")
        self.assertEqual(config.server.port, 8000)
        self.assertEqual(config.security.mode, "http")
        self.assertEqual(config.log_level, "INFO")
        self.assertIsNotNone(config.coalescing)
        self.assertFalse(config.coalescing.enabled)

    def test_load_from_dict(self):
        """Test loading configuration from dictionary."""
        config = self.config_manager.load_from_dict(self.test_config_data)

        self.assertIsInstance(config, ConfigModel)
        self.assertEqual(config.server.host, "127.0.0.1")
        self.assertEqual(config.server.port, 9000)
        self.assertEqual(config.security.mode, "https")
        self.assertEqual(config.embedding.model_name, "test-model")

    def test_load_from_file(self):
        """Test loading configuration from file."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(self.test_config_data, f)
            temp_file = f.name

        try:
            config = self.config_manager.load_from_file(temp_file)

            self.assertIsInstance(config, ConfigModel)
            self.assertEqual(config.server.host, "127.0.0.1")
            self.assertEqual(config.security.mode, "https")
        finally:
            Path(temp_file).unlink()

    def test_save_to_file(self):
        """Test saving configuration to file."""
        self.config_manager.create_default_config()

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            temp_file = f.name

        try:
            self.config_manager.save_to_file(temp_file)

            # Verify file was created and contains valid JSON
            with open(temp_file, "r") as f:
                saved_data = json.load(f)

            self.assertIn("server", saved_data)
            self.assertIn("security", saved_data)
            self.assertIn("embedding", saved_data)
        finally:
            Path(temp_file).unlink()

    def test_validate_config(self):
        """Test configuration validation."""
        self.config_manager.create_default_config()

        self.assertTrue(self.config_manager.validate_config())

    def test_get_config_sections(self):
        """Test getting configuration sections."""
        self.config_manager.load_from_dict(self.test_config_data)

        server_config = self.config_manager.get_server_config()
        self.assertIsInstance(server_config, ServerConfig)
        self.assertEqual(server_config.host, "127.0.0.1")

        security_config = self.config_manager.get_security_config()
        self.assertIsInstance(security_config, SecurityConfig)
        self.assertEqual(security_config.mode, "https")

        embedding_config = self.config_manager.get_embedding_config()
        self.assertIsInstance(embedding_config, EmbeddingConfig)
        self.assertEqual(embedding_config.model_name, "test-model")
        self.assertEqual(embedding_config.max_batch_size, 256)
        self.assertEqual(embedding_config.max_text_length, 500000)

        queue_config = self.config_manager.get_queue_manager_config()
        self.assertIsNotNone(queue_config)
        self.assertEqual(queue_config.max_concurrent_jobs, 2)

    def test_update_config(self):
        """Test updating configuration."""
        self.config_manager.create_default_config()

        updates = {
            "server": {"host": "192.168.1.1", "port": 9999},
            "log_level": "ERROR",
        }

        updated_config = self.config_manager.update_config(updates)

        self.assertEqual(updated_config.server.host, "192.168.1.1")
        self.assertEqual(updated_config.server.port, 9999)
        self.assertEqual(updated_config.log_level, "ERROR")

    def test_invalid_config_validation(self):
        """Test validation of invalid configuration."""
        invalid_data = {
            "server": {"host": "127.0.0.1", "port": "invalid_port"},  # Should be int
            "security": {"mode": "invalid_mode"},  # Invalid mode
        }

        with self.assertRaises(ValidationError):
            self.config_manager.load_from_dict(invalid_data)

    def test_file_not_found(self):
        """Test handling of non-existent file."""
        with self.assertRaises(FileNotFoundError):
            self.config_manager.load_from_file("/non/existent/file.json")

    def test_no_config_loaded_errors(self):
        """Test errors when no configuration is loaded."""
        empty_manager = ConfigManager()

        with self.assertRaises(ValueError):
            empty_manager.get_config()

        with self.assertRaises(ValueError):
            empty_manager.get_server_config()

        with self.assertRaises(ValueError):
            empty_manager.validate_config()

    def test_is_loaded(self):
        """Test is_loaded method."""
        self.assertFalse(self.config_manager.is_loaded())

        self.config_manager.create_default_config()
        self.assertTrue(self.config_manager.is_loaded())


if __name__ == "__main__":
    import unittest

    unittest.main()
