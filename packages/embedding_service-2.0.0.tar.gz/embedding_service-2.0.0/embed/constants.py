"""
Project-wide constants for the embedding service.

All literal constants used across embed package are defined here
to ensure unique names and single source of truth.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from pathlib import Path
from typing import Union

# ---------------------------------------------------------------------------
# Embed command (schema, default policy)
# ---------------------------------------------------------------------------
EMBED_COMMAND_SCHEMA_DEFAULT_ERROR_POLICY = "fail_fast"

# ---------------------------------------------------------------------------
# Service manager (health, container, paths)
# ---------------------------------------------------------------------------
EMBED_SERVICE_MANAGER_SERVICE_NAME = "embedding-service"
EMBED_SERVICE_MANAGER_SERVICE_PORT = 8001
EMBED_SERVICE_MANAGER_SERVICE_HOST = "localhost"
EMBED_SERVICE_MANAGER_SERVICE_URL = (
    f"https://{EMBED_SERVICE_MANAGER_SERVICE_HOST}:"
    f"{EMBED_SERVICE_MANAGER_SERVICE_PORT}"
)
EMBED_SERVICE_MANAGER_HEALTH_ENDPOINT = f"{EMBED_SERVICE_MANAGER_SERVICE_URL}/health"
EMBED_SERVICE_MANAGER_CONFIG_PATH = "/etc/embedding-service/config/config.json"
EMBED_SERVICE_MANAGER_LOG_DIR = "/var/log/embedding-service"
EMBED_SERVICE_MANAGER_CERT_PATH = "/etc/ssl/embedding-service/fullchain.pem"
EMBED_SERVICE_MANAGER_CONTAINER_NAME = "embedding-service"
EMBED_SERVICE_MANAGER_TIMEOUT = 5


def get_embed_project_root(module_file: Union[str, Path]) -> Path:
    """
    Return project root (parent of parent of the given module file).

    Use from main or CLI: get_embed_project_root(__file__).

    Args:
        module_file: __file__ of the calling module.

    Returns:
        Path to project root directory.
    """
    return Path(module_file).resolve().parent.parent
