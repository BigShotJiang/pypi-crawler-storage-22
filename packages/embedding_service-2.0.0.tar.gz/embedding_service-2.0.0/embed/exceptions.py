"""
Project-wide custom exceptions for the embedding service.

Use these instead of generic Exception or RuntimeError so callers
can handle specific failure types (config, queue, client, service).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""


class EmbedError(Exception):
    """Base exception for all embed package errors."""

    def __init__(self, message: str, *args: object, **kwargs: object) -> None:
        super().__init__(message, *args, **kwargs)
        self.message = message


class EmbedConfigError(EmbedError):
    """Config load, parse or validation failure."""


class EmbedQueueError(EmbedError):
    """Queue not initialized, submit failed, or job not found in queue."""


class EmbedClientError(EmbedError):
    """
    Client-facing failure: embed failed, job not found, status check failed,
    or models list failed.
    """


class EmbedServiceError(EmbedError):
    """Generic service or runtime failure (e.g. model load, encode, I/O)."""


class ModelServerUnavailableError(EmbedError):
    """Model server health check failed or connection error; use direct service."""
