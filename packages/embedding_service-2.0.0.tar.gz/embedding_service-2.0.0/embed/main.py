#!/usr/bin/env python3
"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Embedding Service Application
Simple application using MCP Proxy Adapter framework with custom embedding commands.
"""
import json
import sys
import argparse
from pathlib import Path
import multiprocessing
import os

# Set multiprocessing start method to 'spawn' for CUDA compatibility
# This must be done before any CUDA operations or imports that use CUDA
# CUDA cannot be re-initialized in forked subprocesses, so we use 'spawn' instead
# In spawn mode, each child process starts fresh, so CUDA can be initialized there
if __name__ == "__main__":
    try:
        multiprocessing.set_start_method("spawn", force=True)
        # Ensure CUDA init in child processes
        os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:512"
    except RuntimeError:
        # Already set, ignore
        pass

# Project root for sys.path (same as get_embed_project_root; cannot import embed yet)
_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from mcp_proxy_adapter.core.app_factory import create_and_run_server  # noqa: E402
from mcp_proxy_adapter.core.logging import get_global_logger  # noqa: E402
from mcp_proxy_adapter.api import app as adapter_app_module  # noqa: E402
from mcp_proxy_adapter.commands.hooks import (  # noqa: E402
    register_custom_commands_hook,
    register_auto_import_module,
    register_after_init_hook,
)

# Import version, project root, exceptions, and config validator (after path setup)
from embed import __version__  # noqa: E402
from embed.constants import get_embed_project_root  # noqa: E402
from embed.exceptions import EmbedServiceError  # noqa: E402
from embed.config.config_validator import validate_config  # noqa: E402

EMBED_MAIN_PROJECT_ROOT = get_embed_project_root(__file__)


def _validate_config_and_exit(config_path: Path) -> None:
    """
    Load config file, validate with embed.config.config_validator.
    On any validation error: log and exit (do not start server).
    """
    logger = get_global_logger()
    if not config_path.exists():
        logger.error("Config file not found: %s", config_path)
        print(f"❌ Config file not found: {config_path}", file=sys.stderr)
        sys.exit(1)
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config_data = json.load(f)
    except json.JSONDecodeError as e:
        logger.exception("Invalid JSON in config %s: %s", config_path, e)
        print(f"❌ Invalid JSON in config: {e}", file=sys.stderr)
        sys.exit(1)
    except OSError as e:
        logger.exception("Cannot read config %s: %s", config_path, e)
        print(f"❌ Cannot read config: {e}", file=sys.stderr)
        sys.exit(1)
    errors = validate_config(config_data, config_path=str(config_path))
    if errors:
        for err in errors:
            logger.error("Config validation: %s", err)
        print("❌ Config validation failed:", file=sys.stderr)
        for err in errors:
            print(f"   - {err}", file=sys.stderr)
        sys.exit(1)


# Note: Queue commands are automatically registered by the adapter
# when queue_manager.enabled: true in configuration. No manual registration needed.


def register_embedding_commands(registry):
    """Register custom embedding commands with the framework.

    This function is called by the adapter via register_custom_commands_hook().
    Commands are also auto-registered at module level (embed/commands/__init__.py)
    for spawn mode compatibility (required for CUDA).

    The adapter automatically:
    1. Executes this hook in the main process
    2. Imports embed.commands module in child processes (spawn mode)
    3. Reconstructs hooks from module paths if needed
    """
    from mcp_proxy_adapter.core.logging import get_global_logger

    logger = get_global_logger()

    try:
        logger.info("🔄 [REGISTRATION] Starting command registration...")

        from embed.commands.embed_command import EmbedCommand
        from embed.commands.embed_router import EmbedRouterCommand
        from embed.commands.models_command import ModelsCommand
        from embed.commands.embed_job_status_command import EmbedJobStatusCommand
        from embed.commands.timing_stats_command import TimingStatsCommand

        # embed: router (use_queue=False) handles coalescing or single-job submit
        try:
            registry.get_command("embed")
            logger.info("✅ [REGISTRATION] Embed router already registered")
        except (KeyError, AttributeError):
            logger.info("🔄 [REGISTRATION] Registering Embed router...")
            registry.register(EmbedRouterCommand, "custom")
            logger.info("✅ [REGISTRATION] Embed router registered")

        # embed_execute: run by queue workers (same as EmbedCommand)
        try:
            registry.get_command("embed_execute")
            logger.info("✅ [REGISTRATION] embed_execute already registered")
        except (KeyError, AttributeError):

            class EmbedExecuteCommand(EmbedCommand):
                """Embed for queue workers; same as EmbedCommand, name=embed_execute."""

                name = "embed_execute"

            logger.info(
                "🔄 [REGISTRATION] Registering EmbedCommand as embed_execute..."
            )
            registry.register(EmbedExecuteCommand, "custom")
            logger.info("✅ [REGISTRATION] embed_execute registered")

        try:
            registry.get_command("models")
            logger.info("✅ [REGISTRATION] ModelsCommand already registered")
        except (KeyError, AttributeError):
            logger.info("🔄 [REGISTRATION] Registering ModelsCommand...")
            registry.register(ModelsCommand, "custom")
            logger.info("✅ [REGISTRATION] ModelsCommand registered")

        try:
            registry.get_command("embed_job_status")
            logger.info("✅ [REGISTRATION] EmbedJobStatusCommand already registered")
        except (KeyError, AttributeError):
            logger.info("🔄 [REGISTRATION] Registering EmbedJobStatusCommand...")
            registry.register(EmbedJobStatusCommand, "custom")
            logger.info("✅ [REGISTRATION] EmbedJobStatusCommand registered")

        try:
            registry.get_command("timing_stats")
            logger.info("✅ [REGISTRATION] TimingStatsCommand already registered")
        except (KeyError, AttributeError):
            logger.info("🔄 [REGISTRATION] Registering TimingStatsCommand...")
            registry.register(TimingStatsCommand, "custom")
            logger.info("✅ [REGISTRATION] TimingStatsCommand registered")

        logger.info("✅ [REGISTRATION] Custom embedding commands registered")
        print("✅ Custom embedding commands registered")
    except ImportError as e:
        logger.error(f"⚠️ [REGISTRATION] Could not import custom commands: {e}")
        print(f"⚠️ Could not import custom commands: {e}")
    except Exception as e:
        logger.exception("❌ [REGISTRATION] Error during command registration: %s", e)
        raise EmbedServiceError(f"Command registration failed: {e}") from e


async def start_model_server(
    socket_path: str = "/tmp/embedding_model_server.sock",
    host: str = "127.0.0.1",
    port: int = 9001,
    use_unix_socket: bool = True,
) -> None:
    """
    Start model server as background task.

    Args:
        socket_path: Path to Unix socket (if use_unix_socket=True)
        host: TCP host (if use_unix_socket=False)
        port: TCP port (if use_unix_socket=False)
        use_unix_socket: Whether to use Unix socket or TCP
    """
    from mcp_proxy_adapter.core.logging import get_global_logger

    logger = get_global_logger()

    try:
        from embed.services.model_server import ModelServer

        logger.info("🔄 [MODEL_SERVER] Starting model server...")
        server = ModelServer(
            socket_path=socket_path,
            host=host,
            port=port,
            use_unix_socket=use_unix_socket,
        )

        # Start server as background task
        addr = (
            f"Unix socket: {socket_path}" if use_unix_socket else f"TCP {host}:{port}"
        )
        logger.info(f"✅ [MODEL_SERVER] Model server starting on {addr}")
        print(f"✅ Model server starting on {addr}")

        # Run server in background (non-blocking)
        async def run_server():
            try:
                await server.start()
            except (OSError, EmbedServiceError) as e:
                logger.error("❌ [MODEL_SERVER] Model server crashed: %s", e)
            except Exception as e:
                logger.exception(
                    "❌ [MODEL_SERVER] Model server crashed: %s", e, exc_info=True
                )

        asyncio.create_task(run_server())

        # Give server a moment to start
        await asyncio.sleep(0.1)

    except (ImportError, OSError, EmbedServiceError) as e:
        logger.exception(
            "⚠️ [MODEL_SERVER] Failed to start model server: %s", e, exc_info=True
        )
        print(f"⚠️ Failed to start model server: {e}")
        # Don't fail main server startup if model server fails
    except Exception as e:
        logger.exception(
            "⚠️ [MODEL_SERVER] Failed to start model server: %s", e, exc_info=True
        )
        print(f"⚠️ Failed to start model server: {e}")


async def initialize_queue_manager():
    """Initialize queue manager if enabled in configuration."""
    from mcp_proxy_adapter.core.logging import get_global_logger
    from mcp_proxy_adapter.integrations.queuemgr_integration import (
        init_global_queue_manager,
        get_global_queue_manager,
    )

    logger = get_global_logger()

    try:
        # Adapter's init_global_queue_manager() reads queue_manager.enabled from
        # its config; we only trigger init. If already initialized, skip.
        queue_manager = await get_global_queue_manager()
        if queue_manager is not None:
            logger.info("✅ [QUEUE] Queue manager already initialized")
            return

        logger.info("🔄 [QUEUE] Initializing queue manager...")
        await init_global_queue_manager()
        queue_manager = await get_global_queue_manager()
        if queue_manager is not None:
            logger.info("✅ [QUEUE] Queue manager initialized successfully")
        else:
            logger.warning("⚠️ [QUEUE] Queue manager initialization returned None")
    except Exception as e:
        logger.exception(
            "⚠️ [QUEUE] Failed to initialize queue manager: %s", e, exc_info=True
        )
        # Don't fail startup if queue manager init fails - it might be disabled
        logger.warning(
            "⚠️ [QUEUE] Continuing without queue manager (may be disabled in config)"
        )


async def initialize_embedding_service():
    """Initialize embedding service and preload the model."""
    import time
    from mcp_proxy_adapter.core.logging import get_global_logger

    logger = get_global_logger()

    try:
        logger.info("🔄 [INIT] Starting embedding service initialization...")
        start_time = time.time()
        print("🔄 Preloading embedding model...")

        logger.info("🔄 [INIT] Importing EmbeddingService...")
        from embed.services.embedding_service import EmbeddingService

        logger.info("✅ [INIT] EmbeddingService imported")

        logger.info("🔄 [INIT] Getting EmbeddingService instance (may load model)...")
        service = await EmbeddingService.get_instance()
        logger.info("✅ [INIT] EmbeddingService instance obtained")

        logger.info(
            f"🔄 [INIT] Model: {service.model_name}, Dimension: {service.dimension}"
        )
        elapsed = time.time() - start_time
        logger.info(
            f"✅ [INIT] Model preloaded in {elapsed:.3f}s: "
            f"{service.model_name} (dimension: {service.dimension})"
        )
        print(
            f"✅ Model preloaded: {service.model_name} (dimension: {service.dimension})"
        )
    except Exception as e:
        logger.exception("⚠️ [INIT] Failed to preload model: %s", e, exc_info=True)
        print(f"⚠️ Failed to preload model: {e}")


def parse_args():
    """Build argument parser and return parsed args (for CLI and tests)."""
    parser = argparse.ArgumentParser(description="Embedding Service Application")
    parser.add_argument(
        "--config", "-c", required=True, help="Path to configuration file"
    )
    parser.add_argument("--host", help="Server host")
    parser.add_argument("--port", type=int, help="Server port")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument(
        "--no-model-server",
        action="store_true",
        help="Disable model server (use direct EmbeddingService)",
    )
    parser.add_argument(
        "--model-server-socket",
        default="/tmp/embedding_model_server.sock",
        help="Model server Unix socket path",
    )
    parser.add_argument(
        "--model-server-host",
        default="127.0.0.1",
        help="Model server TCP host (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--model-server-port",
        type=int,
        default=9001,
        help="Model server TCP port (default: 9001)",
    )
    parser.add_argument(
        "--model-server-tcp",
        action="store_true",
        help="Use TCP socket for model server instead of Unix socket",
    )
    return parser.parse_args()


async def main():
    """Main entry point for the embedding service application."""
    import asyncio

    args = parse_args()

    # Validate config before starting anything; log and exit on error
    _validate_config_and_exit(Path(args.config))

    # Commands registered by adapter; adapter stores module path for auto-import
    register_custom_commands_hook(register_embedding_commands)
    # Spawn mode: commands available in child processes (CUDA)
    register_auto_import_module("embed.commands")
    # Adapter does not init queue manager; app must call init_global_queue_manager
    register_after_init_hook(initialize_queue_manager)

    # Override configuration if specified
    config_overrides = {}
    if args.host:
        config_overrides["host"] = args.host
    if args.port:
        config_overrides["port"] = args.port
    if args.debug:
        config_overrides["debug"] = True

    # Expose config path for coalescing router and timing (embed commands)
    os.environ["CONFIG_FILE"] = str(args.config)

    print("🚀 Starting Embedding Service")
    print(f"📋 Configuration: {args.config}")
    print(f"🔧 Version: {__version__}")
    print("=" * 50)

    # Start model server if enabled
    if not args.no_model_server:
        await start_model_server(
            socket_path=args.model_server_socket,
            host=args.model_server_host,
            port=args.model_server_port,
            use_unix_socket=not args.model_server_tcp,
        )
        # Give model server a moment to start and load model
        await asyncio.sleep(1.0)
    else:
        from mcp_proxy_adapter.core.logging import get_global_logger

        logger = get_global_logger()
        logger.info(
            "⚠️ [MODEL_SERVER] Model server disabled, using direct EmbeddingService"
        )
        print("⚠️ Model server disabled, using direct EmbeddingService")

    # Preload the model before starting the server (for fallback if model server fails)
    await initialize_embedding_service()

    # Inject WebSocket for push-based job completion (two-channel)
    _orig_create_app = adapter_app_module.create_app

    def _create_app_with_ws(*args, **kwargs):
        app = _orig_create_app(*args, **kwargs)
        from embed.ws import register_job_completion_websocket

        register_job_completion_websocket(app)
        return app

    adapter_app_module.create_app = _create_app_with_ws

    # Use the factory method to create and run the server
    await create_and_run_server(
        config_path=args.config,
        title="Embedding Service",
        description="MCP Proxy Adapter with custom embedding commands",
        version=__version__,
        host=config_overrides.get("host", "0.0.0.0"),
        log_level="debug" if config_overrides.get("debug", False) else "info",
    )


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
