"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Middleware package for embedding service.
"""

from .permissions_middleware import PermissionsMiddleware

__all__ = ["PermissionsMiddleware"]
