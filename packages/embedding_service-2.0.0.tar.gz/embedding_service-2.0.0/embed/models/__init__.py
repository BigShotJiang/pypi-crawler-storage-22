"""
Models package.

Contains data models and schemas for the embedding service.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from .embedding_models import EmbeddingRequest, EmbeddingResponse, ModelInfo

__all__ = ["EmbeddingRequest", "EmbeddingResponse", "ModelInfo"]
