"""
Data models for embedding service.
Contains Pydantic models for request/response validation and serialization.
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import List, Optional, Dict, Any, Union
from pydantic import BaseModel, Field, validator
import numpy as np


class ModelInfo(BaseModel):
    """Model information for embedding models"""

    name: str = Field(..., description="Model name")
    dimension: int = Field(..., description="Vector dimension")
    description: str = Field(..., description="Model description")
    max_tokens: int = Field(..., description="Maximum tokens supported")
    supported_dimensions: List[int] = Field(..., description="Supported dimensions")

    @validator("dimension")
    def validate_dimension(cls, v):
        """Validate dimension is positive"""
        if v <= 0:
            raise ValueError("Dimension must be positive")
        return v

    @validator("max_tokens")
    def validate_max_tokens(cls, v):
        """Validate max_tokens is positive"""
        if v <= 0:
            raise ValueError("Max tokens must be positive")
        return v

    @validator("supported_dimensions")
    def validate_supported_dimensions(cls, v):
        """Validate supported dimensions are positive"""
        if not v:
            raise ValueError("Supported dimensions cannot be empty")
        for dim in v:
            if dim <= 0:
                raise ValueError("All supported dimensions must be positive")
        return v


class EmbeddingRequest(BaseModel):
    """Request model for embedding generation"""

    texts: List[str] = Field(..., description="List of texts to embed")
    model: Optional[str] = Field(None, description="Model name to use")
    dimension: Optional[int] = Field(None, description="Expected vector dimension")

    @validator("texts")
    def validate_texts(cls, v):
        """Validate texts list"""
        if not v:
            raise ValueError("Texts list cannot be empty")
        if len(v) > 1000:  # Reasonable limit
            raise ValueError("Too many texts in request (max 1000)")
        return v

    @validator("texts", each_item=True)
    def validate_text_items(cls, v):
        """Validate each text item"""
        if not isinstance(v, str):
            raise ValueError("All texts must be strings")
        if not v.strip():
            raise ValueError("Texts cannot be empty or whitespace")
        if len(v) > 1000000:  # 1MB limit
            raise ValueError("Text too long (max 1MB)")
        return v.strip()

    @validator("dimension")
    def validate_dimension(cls, v):
        """Validate dimension if provided"""
        if v is not None and v <= 0:
            raise ValueError("Dimension must be positive")
        return v

    class Config:
        """Pydantic configuration"""

        schema_extra = {
            "example": {
                "texts": ["Hello, world!", "Привет, мир!"],
                "model": "all-MiniLM-L6-v2",
                "dimension": 384,
            }
        }


class EmbeddingResult(BaseModel):
    """Individual embedding result"""

    body: str = Field(..., description="Original source text")
    embedding: List[float] = Field(..., description="Vector representation")
    tokens: List[str] = Field(..., description="Text tokens")
    bm25_tokens: List[str] = Field(..., description="BM25 tokens")

    @validator("embedding")
    def validate_embedding(cls, v):
        """Validate embedding vector"""
        if not v:
            raise ValueError("Embedding cannot be empty")
        if not all(isinstance(x, (int, float)) for x in v):
            raise ValueError("All embedding values must be numbers")
        return v

    @validator("tokens")
    def validate_tokens(cls, v):
        """Validate tokens list"""
        if not isinstance(v, list):
            raise ValueError("Tokens must be a list")
        return v

    @validator("bm25_tokens")
    def validate_bm25_tokens(cls, v):
        """Validate BM25 tokens list"""
        if not isinstance(v, list):
            raise ValueError("BM25 tokens must be a list")
        return v

    class Config:
        """Pydantic configuration"""

        schema_extra = {
            "example": {
                "body": "Hello, world!",
                "embedding": [0.1, 0.2, 0.3, 0.4, 0.5],
                "tokens": ["Hello", ",", "world", "!"],
                "bm25_tokens": ["hello", "world"],
            }
        }


class EmbeddingResponse(BaseModel):
    """Response model for embedding generation"""

    success: bool = Field(..., description="Success status")
    data: Optional[Dict[str, Any]] = Field(None, description="Response data")
    error: Optional[Dict[str, Any]] = Field(None, description="Error information")

    @validator("data", "error")
    def validate_mutual_exclusivity(cls, v, values):
        """Validate that data and error are mutually exclusive"""
        if "data" in values and "error" in values:
            if values["data"] is not None and values["error"] is not None:
                raise ValueError("Cannot have both data and error")
        return v

    @classmethod
    def success_response(
        cls, results: List[EmbeddingResult], model: str, dimension: int
    ):
        """Create success response"""
        return cls(
            success=True,
            data={
                "results": [result.dict() for result in results],
                "model": model,
                "dimension": dimension,
            },
            error=None,
        )

    @classmethod
    def error_response(
        cls, code: int, message: str, details: Optional[Dict[str, Any]] = None
    ):
        """Create error response"""
        return cls(
            success=False,
            data=None,
            error={"code": code, "message": message, "data": details or {}},
        )

    class Config:
        """Pydantic configuration"""

        schema_extra = {
            "example": {
                "success": True,
                "data": {
                    "results": [
                        {
                            "body": "Hello, world!",
                            "embedding": [0.1, 0.2, 0.3],
                            "tokens": ["Hello", ",", "world", "!"],
                            "bm25_tokens": ["hello", "world"],
                        }
                    ],
                    "model": "all-MiniLM-L6-v2",
                    "dimension": 384,
                },
            }
        }


class HealthResponse(BaseModel):
    """Health check response model"""

    status: str = Field(..., description="Service status")
    version: str = Field(..., description="Service version")
    uptime: float = Field(..., description="Service uptime in seconds")
    model_info: Optional[ModelInfo] = Field(None, description="Current model info")
    timestamp: str = Field(..., description="Response timestamp")

    class Config:
        """Pydantic configuration"""

        schema_extra = {
            "example": {
                "status": "healthy",
                "version": "1.0.0",
                "uptime": 3600.5,
                "model_info": {
                    "name": "all-MiniLM-L6-v2",
                    "dimension": 384,
                    "description": "Multilingual model",
                    "max_tokens": 512,
                    "supported_dimensions": [384],
                },
                "timestamp": "2024-01-01T12:00:00Z",
            }
        }


class ConfigResponse(BaseModel):
    """Configuration response model"""

    server: Dict[str, Any] = Field(..., description="Server configuration")
    ssl: Dict[str, Any] = Field(..., description="SSL configuration")
    security: Dict[str, Any] = Field(..., description="Security configuration")
    logging: Dict[str, Any] = Field(..., description="Logging configuration")
    commands: Dict[str, Any] = Field(..., description="Commands configuration")
    protocols: Dict[str, Any] = Field(..., description="Protocols configuration")

    class Config:
        """Pydantic configuration"""

        schema_extra = {
            "example": {
                "server": {"host": "127.0.0.1", "port": 10001, "debug": False},
                "ssl": {"enabled": False, "cert_file": None},
                "security": {"enabled": False, "framework": "mcp_security_framework"},
                "logging": {"level": "INFO", "console_output": True},
                "commands": {
                    "auto_discovery": True,
                    "commands_directory": "./embed/commands",
                },
                "protocols": {"enabled": True, "allowed_protocols": ["http"]},
            }
        }


# Utility functions for model conversion
def numpy_to_list(embedding: Union[np.ndarray, List[float]]) -> List[float]:
    """Convert numpy array to list of floats"""
    if isinstance(embedding, np.ndarray):
        result: List[float] = embedding.tolist()
        return result
    elif isinstance(embedding, list):
        return [float(x) for x in embedding]
    else:
        raise ValueError(f"Unsupported embedding type: {type(embedding)}")


def list_to_numpy(embedding: Union[List[float], np.ndarray]) -> np.ndarray:
    """Convert list of floats to numpy array"""
    if isinstance(embedding, list):
        result: np.ndarray = np.array(embedding, dtype=np.float32)
        return result
    elif isinstance(embedding, np.ndarray):
        result_arr: np.ndarray = embedding.astype(np.float32)
        return result_arr
    else:
        raise ValueError(f"Unsupported embedding type: {type(embedding)}")


def validate_embedding_dimension(
    embedding: Union[List[float], np.ndarray], expected_dim: int
) -> bool:
    """Validate embedding dimension"""
    if isinstance(embedding, list):
        result: bool = len(embedding) == expected_dim
        return result
    elif isinstance(embedding, np.ndarray):
        result_arr: bool = embedding.shape[0] == expected_dim
        return result_arr
    else:
        return False


def normalize_embedding(embedding: Union[List[float], np.ndarray]) -> np.ndarray:
    """Normalize embedding vector to unit length"""
    if isinstance(embedding, list):
        arr = list_to_numpy(embedding)
    else:
        arr_conv: np.ndarray = embedding.astype(np.float32)
        arr = arr_conv
    norm = np.linalg.norm(arr)
    if norm > 0:
        result: np.ndarray = arr / norm
        return result
    return arr
