"""
Result classes for embedding service.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import List, Dict, Any


class EmbedResult:
    """
    Result class for embedding operations.

    Attributes:
        embeddings: List of embedding vectors
        model: Model name used for embedding
        dimension: Vector dimension
        results: List of detailed results with tokens and BM25 tokens
    """

    def __init__(
        self,
        embeddings: List[List[float]],
        model: str,
        dimension: int,
        results: List[Dict[str, Any]],
    ):
        """
        Initialize EmbedResult.

        Args:
            embeddings: List of embedding vectors
            model: Model name used for embedding
            dimension: Vector dimension
            results: List of detailed results with tokens and BM25 tokens
        """
        self.embeddings = embeddings
        self.model = model
        self.dimension = dimension
        self.results = results

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert result to dictionary.

        Returns:
            Dictionary representation of the result
        """
        return {
            "embeddings": self.embeddings,
            "model": self.model,
            "dimension": self.dimension,
            "results": self.results,
        }


class ModelsResult:
    """
    Result class for models listing operations.

    Attributes:
        models: List of available models with their properties
    """

    def __init__(self, models: List[Dict[str, Any]]):
        """
        Initialize ModelsResult.

        Args:
            models: List of available models with their properties
        """
        self.models = models

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert result to dictionary.

        Returns:
            Dictionary representation of the result
        """
        return {"models": self.models}
