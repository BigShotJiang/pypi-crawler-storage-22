"""
BM25 tokenization service for generating BM25-compatible tokens from text.
"""

from typing import List
import re
from rank_bm25 import BM25Okapi
from mcp_proxy_adapter.core.logging import logger


class BM25Service:
    """Service for generating BM25 tokens from text"""

    def __init__(self):
        """Initialize BM25 service"""
        self.tokenizer = self._create_tokenizer()

    def _create_tokenizer(self):
        """
        Create a tokenizer function for BM25 processing
        Returns:
            Function that tokenizes text into BM25-compatible tokens
        """

        def tokenize(text: str) -> List[str]:
            """
            Tokenize text for BM25 processing
            Args:
                text: Input text to tokenize
            Returns:
                List of tokens suitable for BM25
            """
            # Convert to lowercase
            text = text.lower()
            # Remove special characters but keep alphanumeric and spaces
            text = re.sub(r"[^\w\s]", " ", text)
            # Split by whitespace and filter out empty tokens
            tokens = [token.strip() for token in text.split() if token.strip()]
            # Filter out very short tokens (less than 2 characters)
            tokens = [token for token in tokens if len(token) >= 2]
            return tokens

        return tokenize

    def get_bm25_tokens(self, text: str) -> List[str]:
        """
        Generate BM25 tokens from text
        Args:
            text: Input text to tokenize
        Returns:
            List of BM25 tokens
        """
        try:
            tokens: List[str] = self.tokenizer(text)
            logger.debug(
                f"Generated {len(tokens)} BM25 tokens for text: {text[:50]}..."
            )
            return tokens
        except (ValueError, TypeError) as e:
            logger.error("Error generating BM25 tokens: %s", e)
            return []
        except Exception as e:
            logger.exception("Error generating BM25 tokens: %s", e, exc_info=True)
            return []

    def get_bm25_tokens_batch(self, texts: List[str]) -> List[List[str]]:
        """
        Generate BM25 tokens for multiple texts
        Args:
            texts: List of texts to tokenize
        Returns:
            List of token lists for each text
        """
        try:
            token_lists = []
            for text in texts:
                tokens = self.get_bm25_tokens(text)
                token_lists.append(tokens)
            logger.debug(f"Generated BM25 tokens for {len(texts)} texts")
            return token_lists
        except (ValueError, TypeError) as e:
            logger.error("Error generating BM25 tokens batch: %s", e)
            return [[] for _ in texts]
        except Exception as e:
            logger.exception("Error generating BM25 tokens batch: %s", e, exc_info=True)
            return [[] for _ in texts]

    def get_bm25_scores(self, query: str, documents: List[str]) -> List[float]:
        """
        Calculate BM25 scores for query against documents
        Args:
            query: Query text
            documents: List of document texts
        Returns:
            List of BM25 scores for each document
        """
        try:
            # Tokenize documents
            tokenized_docs = self.get_bm25_tokens_batch(documents)
            # Create BM25 model
            bm25 = BM25Okapi(tokenized_docs)
            # Tokenize query
            query_tokens = self.get_bm25_tokens(query)
            # Calculate scores
            scores = bm25.get_scores(query_tokens)
            logger.debug(
                f"Calculated BM25 scores for query against {len(documents)} documents"
            )
            # BM25Okapi can yield negative scores (e.g. when IDF is negative);
            # clamp to non-negative for consistent API contract.
            result: List[float] = [max(0.0, float(s)) for s in scores.tolist()]
            return result
        except (ValueError, TypeError) as e:
            logger.error("Error calculating BM25 scores: %s", e)
            return [0.0] * len(documents)
        except Exception as e:
            logger.exception("Error calculating BM25 scores: %s", e, exc_info=True)
            return [0.0] * len(documents)
