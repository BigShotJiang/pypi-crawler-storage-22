"""
Encode flow: device selection, model reload, and embedding generation.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio
import time
from typing import Any, List

from sentence_transformers import SentenceTransformer

from mcp_proxy_adapter.core.errors import InternalError
from mcp_proxy_adapter.core.logging import logger

from embed.utils.gpu_utils import (
    get_gpu_info,
    wrap_cuda_operation,
    estimate_memory_requirement,
    determine_device_for_request,
)


async def run_encode_flow(
    service: Any,
    texts: List[str],
    device: str = "auto",
) -> List[List[float]]:
    """
    Run device selection, optional reload, encode, and optional CPU fallback.

    Updates service.model, service.is_loading, service.loading_error,
    service._last_timing. Caller must ensure service is ready and validated.

    Args:
        service: EmbeddingService instance (model loaded).
        texts: Texts to encode.
        device: Device hint: "auto", "cpu", "cuda", "cuda:0".

    Returns:
        List of embedding vectors.

    Raises:
        InternalError: On encode or reload failure.
    """
    estimated_memory = estimate_memory_requirement(texts, service.dimension)
    target_device, device_reason = determine_device_for_request(
        device, estimated_memory
    )

    if device_reason:
        logger.info(
            "Device selection: %s (reason: %s)",
            target_device,
            device_reason,
        )
    else:
        logger.info("Device selection: %s", target_device)

    current_device = str(service.model.device) if service.model else None
    need_reload = False

    if target_device == "cpu" and current_device and "cuda" in current_device:
        logger.info("Switching from GPU to CPU for this request")
        need_reload = True
    elif target_device.startswith("cuda") and current_device == "cpu":
        logger.info(
            "Switching from CPU to %s for this request",
            target_device,
        )
        need_reload = True
    elif (
        target_device.startswith("cuda")
        and current_device
        and target_device != current_device
    ):
        logger.info(
            "Switching GPU device from %s to %s",
            current_device,
            target_device,
        )
        need_reload = True

    loop = asyncio.get_running_loop()

    if need_reload:
        logger.info("Reloading model on %s...", target_device)
        service.is_loading = True
        try:
            service.model = await loop.run_in_executor(
                None,
                lambda: SentenceTransformer(service.model_name, device=target_device),
            )
            logger.info("Model reloaded on %s", target_device)
        except Exception as e:
            service.is_loading = False
            service.loading_error = str(e)
            logger.error("Failed to reload model on %s: %s", target_device, e)
            if target_device.startswith("cuda"):
                logger.warning("GPU reload failed, falling back to CPU")
                try:
                    service.model = await loop.run_in_executor(
                        None,
                        lambda: SentenceTransformer(service.model_name, device="cpu"),
                    )
                    target_device = "cpu"
                    logger.info("Model loaded on CPU (fallback)")
                except Exception as e2:
                    raise InternalError(
                        f"Failed to load model on CPU: {str(e2)}"
                    ) from e2
            else:
                raise InternalError(f"Failed to reload model: {str(e)}") from e
        service.is_loading = False
        service.loading_error = None

    encode_start = time.time()
    logger.info(
        "Encoding %s text(s) on %s (async)...",
        len(texts),
        target_device,
    )

    try:

        def encode_wrapper():
            """Run model.encode via wrap_cuda_operation for CUDA errors."""
            return wrap_cuda_operation(service.model.encode, texts)

        loop = asyncio.get_running_loop()
        embeddings = await loop.run_in_executor(None, encode_wrapper)
        encode_time = time.time() - encode_start
        logger.info(
            "Encoding completed on %s: %.3fs (%s texts, %.3fs per text)",
            target_device,
            encode_time,
            len(texts),
            encode_time / len(texts),
        )
    except RuntimeError as e:
        encode_time = time.time() - encode_start
        error_msg = str(e)

        if target_device.startswith("cuda") and device == "auto":
            logger.warning(
                "CUDA error on %s after %.3fs, trying CPU fallback: %s",
                target_device,
                encode_time,
                error_msg,
            )
            try:
                logger.info("Reloading model on CPU for fallback...")
                loop = asyncio.get_running_loop()
                service.model = await loop.run_in_executor(
                    None,
                    lambda: SentenceTransformer(service.model_name, device="cpu"),
                )
                fallback_start = time.time()
                embeddings = await loop.run_in_executor(
                    None,
                    lambda: service.model.encode(texts),
                )
                fallback_time = time.time() - fallback_start
                encode_time = fallback_time
                target_device = "cpu"
                logger.info(
                    "CPU fallback successful: %.3fs (%s texts)",
                    fallback_time,
                    len(texts),
                )
            except Exception as fallback_error:
                logger.error("CPU fallback also failed: %s", fallback_error)
                gpu_info = get_gpu_info()
                gpu_info_str = f"GPU info: {gpu_info}" if gpu_info else ""
                raise InternalError(
                    f"CUDA error and CPU fallback failed: {error_msg}. "
                    f"CPU error: {str(fallback_error)}. {gpu_info_str}"
                ) from fallback_error
        else:
            logger.error(
                "CUDA error after %.3fs: %s",
                encode_time,
                error_msg,
            )
            gpu_info = get_gpu_info()
            gpu_info_str = f"GPU info: {gpu_info}" if gpu_info else ""
            raise InternalError(
                f"CUDA error during embedding generation: {error_msg}. "
                f"{gpu_info_str}"
            ) from e

    result: List[List[float]] = embeddings.tolist()
    service._last_timing = {
        "encode_seconds": encode_time,
        "device": target_device,
    }
    return result
