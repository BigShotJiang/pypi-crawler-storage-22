"""
Async initialization logic for EmbeddingService.

This module contains the heavy-weight initialization routine that loads
configuration, prepares model cache and loads the embedding model itself.
Configuration is read only from CONFIG_FILE via embed_config_loader
(adapter ConfigLoader); no hardcoded paths or legacy loaders.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import os
import time
from typing import Any, Dict

from mcp_proxy_adapter.core.errors import ConfigurationError, InternalError
from mcp_proxy_adapter.core.logging import logger

from embed.config.embed_config_loader import get_config_dict
from embed.services.model_device_manager import (
    load_sentence_transformer_with_auto_device,
)
from embed.utils.gpu_utils import get_gpu_info


def _get_config_value(config_data: Dict[str, Any], key: str, default: Any) -> Any:
    """Get config value from dict using dot notation (e.g. embedding.model_name)."""
    value: Any = config_data
    for part in key.split("."):
        if isinstance(value, dict) and part in value:
            value = value[part]
        else:
            return default
    return value


async def initialize_embedding_service(service: Any) -> None:
    """
    Initialize an EmbeddingService instance asynchronously.

    Loads configuration from CONFIG_FILE via embed_config_loader (single source),
    configures model cache and device, loads the sentence-transformers model,
    detects dimension and updates service state.

    Args:
        service: EmbeddingService instance to initialize.

    Raises:
        ConfigurationError: If configuration or model loading fails.
        InternalError: For any other initialization error.
    """
    try:
        config_data = get_config_dict() or {}

        def get_config_value(key: str, default: Any) -> Any:
            return _get_config_value(config_data, key, default)

        # Get embedding settings from config
        service.model_name = get_config_value(
            "embedding.model_name",
            "all-MiniLM-L6-v2",
        )
        service.use_cache = get_config_value("embedding.use_cache", True)
        service.cache_dir = get_config_value("embedding.cache_dir", ".model_cache")
        service.device = get_config_value("embedding.device", "auto")

        # Get operation limits from config
        service.MAX_BATCH_SIZE = get_config_value("embedding.max_batch_size", 512)
        service.MAX_TEXT_LENGTH = get_config_value(
            "embedding.max_text_length", 1_000_000
        )
        service.max_texts_per_batch = get_config_value(
            "embedding.max_texts_per_batch", 0
        )

        # Timing registration for analytics (writes to JSONL file when enabled)
        timing_registration = get_config_value("embedding.timing_registration", False)
        timing_file = get_config_value("embedding.timing_file", None)
        timing_file_max_bytes = get_config_value(
            "embedding.timing_file_max_bytes", None
        )
        try:
            from embed.utils.timing_recorder import set_config as set_timing_config

            set_timing_config(timing_registration, timing_file, timing_file_max_bytes)
            if timing_registration:
                logger.info(
                    "Timing registration enabled; records will be written to: %s%s",
                    timing_file or "./logs/embed_timings.jsonl",
                    (
                        f" (rotate at {timing_file_max_bytes} bytes)"
                        if timing_file_max_bytes
                        else ""
                    ),
                )
        except Exception as exc:
            logger.warning(
                "Could not configure timing recorder: %s", exc, exc_info=True
            )

        # Get queue manager settings for concurrent operations
        service.max_concurrent_jobs = get_config_value(
            "queue_manager.max_concurrent_jobs", 1
        )

        logger.info(
            "Loaded settings - model: %s, device: %s, max_batch_size: %s, "
            "max_text_length: %s, max_texts_per_batch: %s",
            service.model_name,
            service.device,
            service.MAX_BATCH_SIZE,
            service.MAX_TEXT_LENGTH,
            service.max_texts_per_batch,
        )

        logger.info(
            "Queue manager settings - max_concurrent_jobs: %s",
            service.max_concurrent_jobs,
        )

        # Configure model caching
        if service.use_cache:
            try:
                # Create cache directory for models if it does not exist
                if not os.path.exists(service.cache_dir):
                    os.makedirs(service.cache_dir, exist_ok=True)
                    logger.info("Created model cache directory: %s", service.cache_dir)

                # Configure cache-related environment variables
                os.environ["TORCH_HOME"] = service.cache_dir
                os.environ["TRANSFORMERS_CACHE"] = service.cache_dir
                os.environ["HF_HOME"] = service.cache_dir
                os.environ["SENTENCE_TRANSFORMERS_HOME"] = service.cache_dir
                logger.info("Model caching enabled. Path: %s", service.cache_dir)
            except Exception as exc:
                raise ConfigurationError(
                    f"Failed to setup model cache: {str(exc)}"
                ) from exc

        # Initialize model
        model_load_start = time.time()
        logger.info("🔄 [TIMING] Starting model load: %s", service.model_name)
        service.is_loading = True

        try:
            service.model = await load_sentence_transformer_with_auto_device(
                model_name=service.model_name,
                requested_device=service.device,
            )

            # Log final device mode
            final_device = str(service.model.device)
            mode = "GPU (CUDA)" if "cuda" in final_device else "CPU"
            total_load_time = time.time() - model_load_start

            # Get and log GPU info if using CUDA
            gpu_info = None
            if "cuda" in final_device:
                gpu_info = get_gpu_info()

            logger.info("=" * 50)
            logger.info("🎯 FINAL DEVICE MODE: %s", mode)
            logger.info("🔧 Device: %s", final_device)
            if gpu_info:
                logger.info(
                    "🖥️  GPU Info: %s (memory_total: %.1fMB, memory_free: %.1fMB, "
                    "memory_free_percent: %.1f%%)",
                    gpu_info.get("device_name", "unknown"),
                    gpu_info.get("memory_total", 0) / (1024 * 1024),
                    gpu_info.get("memory_free", 0) / (1024 * 1024),
                    gpu_info.get("memory_free_percent", 0),
                )
            logger.info("⏱️ [TIMING] Total model load time: %.3fs", total_load_time)
            logger.info("=" * 50)

            logger.info("✅ Model loaded successfully")

            # Detect embedding dimension
            dimension_start = time.time()
            dimension_result: int = service.model.get_sentence_embedding_dimension()
            service.dimension = dimension_result
            dimension_time = time.time() - dimension_start
            logger.info(
                "⏱️ [TIMING] Dimension detection: %.3fs -> %s",
                dimension_time,
                service.dimension,
            )

            # Update status flags
            service.is_loading = False
            service.loading_error = None

            if total_load_time > 5.0:
                logger.warning(
                    "⚠️ [TIMING] Model load took %.3fs - "
                    "consider using persistent model server to avoid reloads!",
                    total_load_time,
                )

        except Exception as exc:
            service.is_loading = False
            service.loading_error = str(exc)
            logger.error(
                "Failed to load model %s: %s",
                service.model_name,
                exc,
            )
            raise ConfigurationError(
                f"Failed to load model {service.model_name}: {str(exc)}"
            ) from exc

    except ConfigurationError:
        # Propagate configuration errors as-is to caller
        raise
    except Exception as exc:
        raise InternalError(
            f"Failed to initialize embedding service: {str(exc)}"
        ) from exc
