"""
Embedding service using SentenceTransformers.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio
from typing import Any, Dict, List, Optional

from sentence_transformers import SentenceTransformer

from mcp_proxy_adapter.core.errors import (
    ConfigurationError,
    InternalError,
    ValidationError,
)
from mcp_proxy_adapter.core.logging import logger

from embed.services.embedding_encode import run_encode_flow
from embed.services.embedding_initializer import initialize_embedding_service
from embed.services.embedding_validation import (
    validate_dimension,
    validate_model,
    validate_texts,
)
from embed.utils.gpu_utils import get_gpu_info, is_cuda_error


class EmbeddingService:
    """Сервис для генерации эмбеддингов на основе sentence-transformers"""

    _instance = None

    # Стандартные размерности для популярных моделей
    MODEL_DIMENSIONS = {
        "all-MiniLM-L6-v2": 384,
        "all-mpnet-base-v2": 768,
        "all-MiniLM-L12-v2": 384,
        "multi-qa-mpnet-base-dot-v1": 768,
        "paraphrase-multilingual-mpnet-base-v2": 768,
        "paraphrase-multilingual-MiniLM-L12-v2": 384,
        "distiluse-base-multilingual-cased-v2": 512,
        "paraphrase-multilingual-MiniLM-L6-v2": 384,
    }

    # Validation constants (can be overridden from config)
    MAX_BATCH_SIZE = 512  # Default, can be overridden from config
    MAX_TEXT_LENGTH = 1_000_000  # Default, can be overridden from config

    @classmethod
    async def get_instance(cls):
        """
        Получение синглтон-экземпляра сервиса (асинхронно)

        Returns:
            EmbeddingService: Экземпляр сервиса

        Raises:
            ConfigurationError: Если не удалось загрузить конфигурацию
            InternalError: Если произошла внутренняя ошибка при инициализации
        """
        try:
            if cls._instance is None:
                # Создаем экземпляр асинхронно
                cls._instance = await cls._create_async()
            return cls._instance
        except ConfigurationError:
            raise
        except Exception as e:
            raise InternalError(
                f"Failed to initialize embedding service: {str(e)}"
            ) from e

    @classmethod
    async def _create_async(cls):
        """
        Асинхронное создание экземпляра сервиса

        Returns:
            EmbeddingService: Новый экземпляр сервиса
        """
        instance = cls.__new__(cls)
        await instance._async_init()
        return instance

    def __init__(self):
        """
        Инициализация сервиса эмбеддингов (синхронная часть)

        Raises:
            ConfigurationError: Если не удалось загрузить конфигурацию или модель
            InternalError: Если произошла внутренняя ошибка при инициализации
        """
        self.model = None
        self.model_name = None
        self.dimension = None
        self.is_loading = False
        self.loading_error = None
        # These will be set from config during _async_init
        self.max_concurrent_jobs = 1
        self.max_texts_per_batch = 0  # Max texts per encode; 0 = only GPU memory

    async def _async_init(self) -> None:
        """
        Асинхронная инициализация сервиса эмбеддингов.

        Вся тяжелая логика загрузки конфигурации, подготовки кеша и
        инициализации модели вынесена в отдельный модуль
        :mod:`embed.services.embedding_initializer` для уменьшения
        размера файла и упрощения структуры кода.

        Raises:
            ConfigurationError: Если не удалось загрузить конфигурацию или модель.
            InternalError: Если произошла внутренняя ошибка при инициализации.
        """
        await initialize_embedding_service(self)

    def get_model_dimension(self) -> int:
        """
        Получить размерность текущей модели

        Returns:
            int: Размерность вектора эмбеддинга
        """
        result: int = self.dimension
        return result

    def get_model_info(self) -> Dict[str, Any]:
        """
        Получить информацию о текущей модели

        Returns:
            Dict[str, Any]: Информация о модели
        """
        return {
            "name": self.model_name,
            "dimension": self.dimension,
            "device": str(self.model.device) if self.model else "unknown",
            "description": "Multilingual model for text embeddings",
            "max_tokens": 512,  # Standard max tokens for most transformer models
            "supported_dimensions": (
                [self.dimension] if self.dimension else []
            ),  # Текущая модель поддерживает только свою размерность
            "is_loaded": self.model is not None,
            "is_loading": self.is_loading,
            "loading_error": self.loading_error,
        }

    def is_model_ready(self) -> bool:
        """
        Проверить, готова ли модель к использованию

        Returns:
            bool: True если модель загружена и готова, False иначе
        """
        return (
            self.model is not None
            and not self.is_loading
            and self.loading_error is None
        )

    def get_model_status(self) -> Dict[str, Any]:
        """
        Получить статус модели

        Returns:
            Dict[str, Any]: Статус модели
        """
        if self.is_loading:
            return {
                "status": "loading",
                "message": "Model is being loaded, please try again in a few seconds",
                "model": self.model_name,
            }
        elif self.loading_error:
            return {
                "status": "error",
                "message": f"Model loading failed: {self.loading_error}",
                "model": self.model_name,
            }
        elif self.model is None:
            return {
                "status": "not_loaded",
                "message": "Model is not loaded",
                "model": self.model_name,
            }
        else:
            return {
                "status": "ready",
                "message": "Model is ready for use",
                "model": self.model_name,
            }

    @classmethod
    def get_available_models_info(cls) -> List[Dict[str, Any]]:
        """
        Получить информацию о всех доступных моделях

        Returns:
            List[Dict[str, Any]]: Список информации о моделях
        """
        return [
            {
                "name": model_name,
                "dimension": dimension,
                "description": "Multilingual model for text embeddings",
                "max_tokens": 512,
                "supported_dimensions": [
                    dimension
                ],  # Каждая модель поддерживает только свою размерность
            }
            for model_name, dimension in cls.MODEL_DIMENSIONS.items()
        ]

    def validate_texts(self, texts: List[str]) -> None:
        """Validate input texts (delegates to embedding_validation)."""
        validate_texts(texts, self.MAX_BATCH_SIZE, self.MAX_TEXT_LENGTH)

    def validate_model(self, model: Optional[str]) -> None:
        """Validate model name (delegates to embedding_validation)."""
        validate_model(model, self.MODEL_DIMENSIONS)

    def validate_dimension(self, dimension: Optional[int], model_name: str) -> None:
        """Validate dimension against model (delegates to embedding_validation)."""
        validate_dimension(dimension, model_name, self.MODEL_DIMENSIONS)

    async def get_embeddings(
        self,
        texts: List[str],
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        device: str = "auto",
    ) -> List[List[float]]:
        """
        Асинхронное получение эмбеддингов для списка текстов

        Args:
            texts: Список текстов для обработки
            model: Имя модели для использования (опционально)
            dimension: Ожидаемая размерность вектора (опционально)
            device: "auto", "cpu", "cuda", "cuda:0". При "auto" - по GPU;
                   при ошибках GPU - fallback на CPU.

        Returns:
            Список эмбеддингов (векторных представлений) для каждого текста

        Raises:
            ValidationError: Если входные данные некорректны
            InternalError: Если произошла ошибка при генерации эмбеддингов
        """
        try:
            # Check if model is ready
            if not self.is_model_ready():
                status = self.get_model_status()
                raise InternalError(f"Model is not ready: {status['message']}")

            # Validate inputs
            self.validate_texts(texts)
            self.validate_model(model)

            # Проверка и загрузка модели если указана
            if model is not None:
                if model != self.model_name:
                    logger.info(f"Switching model from {self.model_name} to {model}")
                    self.is_loading = True
                    try:
                        # Загружаем модель асинхронно
                        loop = asyncio.get_running_loop()
                        self.model = await loop.run_in_executor(
                            None, SentenceTransformer, model
                        )
                        self.model_name = model
                        dimension_result_2: int = (
                            self.model.get_sentence_embedding_dimension()
                        )
                        self.dimension = dimension_result_2
                        self.is_loading = False
                        self.loading_error = None
                        logger.info(f"Model {model} loaded successfully")
                    except Exception as e:
                        self.is_loading = False
                        self.loading_error = str(e)
                        logger.exception(
                            "Failed to load model %s: %s", model, e, exc_info=True
                        )
                        raise InternalError(
                            f"Failed to load model {model}: {str(e)}"
                        ) from e

            # Validate dimension
            self.validate_dimension(dimension, self.model_name)

            return await run_encode_flow(self, texts, device)

        except ValidationError:
            raise
        except InternalError:
            raise  # Re-raise InternalError
        except Exception as e:
            if is_cuda_error(e):
                logger.error("CUDA error in get_embeddings: %s", e)
                gpu_info = get_gpu_info()
                gpu_info_str = f"GPU info: {gpu_info}" if gpu_info else ""
                raise InternalError(
                    f"CUDA error during embedding generation: {str(e)}. "
                    f"{gpu_info_str}"
                ) from e
            logger.exception("Failed to generate embeddings: %s", e, exc_info=True)
            raise InternalError(f"Failed to generate embeddings: {str(e)}") from e

    async def get_available_models(self) -> List[dict]:
        """
        Асинхронно получить список доступных моделей

        Returns:
            List of model information dictionaries

        Raises:
            InternalError: Если произошла ошибка при получении информации о моделях
        """
        try:
            return self.get_available_models_info()
        except Exception as e:
            raise InternalError(f"Failed to get available models: {str(e)}") from e
