"""
Validation helpers for embedding service inputs.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from typing import Dict, List, Optional

import regex

from mcp_proxy_adapter.core.errors import ValidationError


def validate_texts(
    texts: List[str],
    max_batch_size: int,
    max_text_length: int,
) -> None:
    """
    Validate input texts list.

    Args:
        texts: List of texts to validate.
        max_batch_size: Maximum allowed batch size.
        max_text_length: Maximum length per text.

    Raises:
        ValidationError: If validation fails.
    """
    if not texts:
        raise ValidationError("Empty texts list provided")

    if not isinstance(texts, list):
        raise ValidationError("'texts' must be a list")

    if not all(isinstance(text, str) for text in texts):
        raise ValidationError("All texts must be strings")

    for i, text in enumerate(texts):
        if not text:
            raise ValidationError(f"Empty text at index {i}")
        if len(text) >= max_text_length:
            raise ValidationError(
                f"Text at index {i} is too long (max {max_text_length} characters)"
            )
        try:
            text.encode("utf-8")
        except UnicodeEncodeError:
            raise ValidationError(f"Text at index {i} contains invalid characters")
        if not regex.search(r"[\p{L}\p{N}]", text):
            raise ValidationError(f"Text at index {i} contains only special characters")

    if len(texts) > max_batch_size:
        raise ValidationError(
            f"Batch size {len(texts)} exceeds the maximum allowed ({max_batch_size})"
        )


def validate_model(
    model: Optional[str],
    model_dimensions: Dict[str, int],
) -> None:
    """
    Validate model name.

    Args:
        model: Model name to validate.
        model_dimensions: Map of model name -> dimension.

    Raises:
        ValidationError: If model is not supported.
    """
    if model is not None and model not in model_dimensions:
        raise ValidationError(f"Model {model} is not supported")


def validate_dimension(
    dimension: Optional[int],
    model_name: str,
    model_dimensions: Dict[str, int],
) -> None:
    """
    Validate dimension against model.

    Args:
        dimension: Dimension to validate.
        model_name: Name of the model.
        model_dimensions: Map of model name -> dimension.

    Raises:
        ValidationError: If dimension does not match model.
    """
    if dimension is not None:
        if model_name not in model_dimensions:
            raise ValidationError(f"Model {model_name} is not supported")
        model_dim = model_dimensions[model_name]
        if dimension != model_dim:
            raise ValidationError(
                f"Requested dimension {dimension} is not supported by model "
                f"{model_name}. Model dimension is {model_dim}"
            )
