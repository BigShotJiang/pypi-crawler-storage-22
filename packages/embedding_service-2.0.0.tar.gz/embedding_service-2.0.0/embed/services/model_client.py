"""
Client for model server.

This client communicates with the persistent model server to avoid
reloading models in each worker process.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio
import json
import os
from typing import List, Optional, Dict, Any

from mcp_proxy_adapter.core.logging import logger

from embed.exceptions import EmbedServiceError


class ModelClient:
    """
    Client for communicating with model server.

    Connects to Unix socket or TCP socket to request embeddings
    without loading models locally.
    """

    def __init__(
        self,
        socket_path: Optional[str] = None,
        host: str = "127.0.0.1",
        port: int = 9001,
        use_unix_socket: bool = True,
        timeout: float = 30.0,
    ):
        """
        Initialize model client.

        Args:
            socket_path: Path to Unix socket (if use_unix_socket=True)
            host: TCP host (if use_unix_socket=False)
            port: TCP port (if use_unix_socket=False)
            use_unix_socket: Whether to use Unix socket or TCP
            timeout: Request timeout in seconds
        """
        self.socket_path = socket_path or "/tmp/embedding_model_server.sock"
        self.host = host
        self.port = port
        self.use_unix_socket = use_unix_socket
        self.timeout = timeout

    async def _send_request(
        self, method: str, params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Send request to model server with proper timeout handling.

        Args:
            method: Method name (encode, health)
            params: Method parameters

        Returns:
            Response dictionary
        """
        request = {"method": method, "params": params}

        try:
            # Connection timeout (shorter than total timeout)
            connection_timeout = min(5.0, self.timeout * 0.1)

            if self.use_unix_socket:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_unix_connection(self.socket_path),
                    timeout=connection_timeout,
                )
            else:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(self.host, self.port),
                    timeout=connection_timeout,
                )

            try:
                # Send request with timeout
                request_data = json.dumps(request).encode("utf-8")
                writer.write(request_data)
                await asyncio.wait_for(
                    writer.drain(), timeout=min(5.0, self.timeout * 0.1)
                )

                # Read response with full timeout (remaining time)
                # Use the full timeout for the actual operation
                response_data = await asyncio.wait_for(
                    reader.read(1024 * 1024), timeout=self.timeout  # 1MB max
                )

                if not response_data:
                    raise ConnectionError("Empty response from model server")

                response = json.loads(response_data.decode("utf-8"))

                # Check if response indicates CUDA error - these should be fast
                if not response.get("success") and response.get("error"):
                    error_msg = response.get("error", "")
                    if "CUDA" in error_msg or "cuda" in error_msg.lower():
                        logger.warning(
                            f"CUDA error from model server (fast-fail): {error_msg}"
                        )

                return response

            finally:
                writer.close()
                try:
                    await asyncio.wait_for(writer.wait_closed(), timeout=2.0)
                except asyncio.TimeoutError:
                    pass  # Ignore timeout on close

        except asyncio.TimeoutError as e:
            raise TimeoutError(
                f"Request to model server timed out after {self.timeout}s. "
                f"This may indicate a CUDA error or GPU issue."
            ) from e
        except FileNotFoundError:
            addr = (
                f"Unix socket: {self.socket_path}"
                if self.use_unix_socket
                else f"TCP {self.host}:{self.port}"
            )
            raise ConnectionError(
                f"Model server not found at {addr}. Start the model server first."
            )
        except Exception as e:
            raise ConnectionError(
                f"Failed to communicate with model server: {e}"
            ) from e

    async def encode(
        self, texts: List[str], model: Optional[str] = None, device: str = "auto"
    ) -> List[List[float]]:
        """
        Encode texts using model server.

        Args:
            texts: List of texts to encode
            model: Optional model name
            device: Device to use (auto, cpu, cuda)

        Returns:
            List of embedding vectors
        """
        params = {"texts": texts, "device": device}
        if model:
            params["model"] = model

        response = await self._send_request("encode", params)

        if not response.get("success"):
            error = response.get("error", "Unknown error")
            gpu_info = response.get("gpu_info")

            # Build error message with GPU info if available
            error_msg = f"Model server error: {error}"
            if gpu_info:
                error_msg += (
                    f" (GPU: {gpu_info.get('device_name', 'unknown')}, "
                    f"memory_free: {gpu_info.get('memory_free', 0)/(1024*1024):.1f}MB)"
                )

            raise EmbedServiceError(error_msg)

        return response.get("embeddings", [])

    async def health(self) -> Dict[str, Any]:
        """
        Check model server health.

        Returns:
            Health status dictionary
        """
        return await self._send_request("health", {})

    def is_available(self) -> bool:
        """
        Check if model server is available (synchronous check).

        Returns:
            True if server socket exists, False otherwise
        """
        if self.use_unix_socket:
            return os.path.exists(self.socket_path)
        else:
            # For TCP, we can't check synchronously without connecting
            # Return True and let async methods handle connection errors
            return True


# Global client instance
_client_instance: Optional[ModelClient] = None


def get_model_client() -> ModelClient:
    """
    Get global model client instance.

    Returns:
        ModelClient instance
    """
    global _client_instance

    if _client_instance is None:
        # Try to detect socket type from environment
        use_unix = os.getenv("MODEL_SERVER_USE_TCP", "false").lower() != "true"
        socket_path = os.getenv(
            "MODEL_SERVER_SOCKET", "/tmp/embedding_model_server.sock"
        )
        host = os.getenv("MODEL_SERVER_HOST", "127.0.0.1")
        port = int(os.getenv("MODEL_SERVER_PORT", "9001"))

        _client_instance = ModelClient(
            socket_path=socket_path, host=host, port=port, use_unix_socket=use_unix
        )

    return _client_instance
