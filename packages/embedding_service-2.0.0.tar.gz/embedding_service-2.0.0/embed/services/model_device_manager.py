"""
Model device placement helper for EmbeddingService initialization.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from sentence_transformers import SentenceTransformer

from mcp_proxy_adapter.core.logging import logger
from embed.utils.gpu_utils import determine_device_for_request, get_gpu_info
from embed.utils.gpu_memory_estimator import estimate_model_load_memory_requirement_mb


async def load_sentence_transformer_with_auto_device(
    model_name: str,
    requested_device: str,
) -> tuple[Any, bool]:
    """
    Load SentenceTransformer with safe device selection.

    Strategy:
    - Decide initial device using CUDA availability heuristics.
    - If CUDA is desired, preload model on CPU first, estimate VRAM requirement,
      then decide whether to move to CUDA or remain on CPU.

    Args:
        model_name: SentenceTransformer model name.
        requested_device: "auto" | "cpu" | "cuda" | "cuda:<idx>".

    Returns:
        Tuple of (model, gpu_placement_failed). gpu_placement_failed is True
        when GPU was requested but model stayed on CPU (e.g. OOM); caller
        should avoid retrying GPU for this process/session.
    """
    loop = asyncio.get_running_loop()

    # First pass: decide whether CUDA is requested/available.
    target_device = requested_device
    if requested_device == "auto":
        try:
            import torch  # type: ignore

            target_device = "cuda" if torch.cuda.is_available() else "cpu"
        except Exception:
            target_device = "cpu"

    # If we plan to use CUDA, preload on CPU to estimate size safely.
    load_device = "cpu" if str(target_device).startswith("cuda") else str(target_device)
    if str(target_device).startswith("cuda"):
        logger.info(
            "Preloading model on CPU to estimate GPU memory before using %s",
            target_device,
        )

    model_load_start = time.time()
    model = await loop.run_in_executor(
        None, lambda: SentenceTransformer(model_name, device=load_device)
    )
    model_load_time = time.time() - model_load_start
    logger.info(
        "⏱️ [TIMING] Model loaded in executor: %.3fs on %s",
        model_load_time,
        load_device,
    )

    if str(target_device).startswith("cuda") and load_device == "cpu":
        required_mb = estimate_model_load_memory_requirement_mb(model)
        chosen_device, reason = determine_device_for_request(
            requested_device, required_mb
        )
        if reason:
            logger.info(
                "Device selection for model placement: %s (reason: %s)",
                chosen_device,
                reason,
            )
        else:
            logger.info("Device selection for model placement: %s", chosen_device)

        if str(chosen_device).startswith("cuda"):
            move_start = time.time()

            def _move_model():
                """Move model to chosen device (sync, for run_in_executor)."""
                model.to(chosen_device)
                return model

            try:
                model = await loop.run_in_executor(None, _move_model)
                move_time = time.time() - move_start
                logger.info(
                    "✅ [TIMING] Model moved to %s in %.3fs", chosen_device, move_time
                )
            except Exception as exc:
                gpu_info = get_gpu_info()
                free_mb = (
                    gpu_info["memory_free"] / (1024 * 1024)
                    if gpu_info and "memory_free" in gpu_info
                    else None
                )
                logger.warning(
                    "Failed to move model to %s, keeping CPU: %s (required_mb=%.1f, free_mb=%s)",
                    chosen_device,
                    exc,
                    required_mb,
                    f"{free_mb:.1f}" if free_mb is not None else "?",
                )

    return model
