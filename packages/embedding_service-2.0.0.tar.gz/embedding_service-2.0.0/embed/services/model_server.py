"""
Model server for persistent model loading.

This server runs in a separate process and keeps models loaded in memory.
Main server communicates with it via Unix socket or TCP socket to avoid
reloading models in each worker process.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio
import json
import logging
import os
import signal
import sys
import time
from typing import Any, Dict, Optional

from mcp_proxy_adapter.core.logging import logger

from embed.exceptions import EmbedServiceError
from embed.utils.gpu_utils import (
    get_gpu_info,
    is_cuda_error,
    wrap_cuda_operation,
    estimate_memory_requirement,
    determine_device_for_request,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


class ModelServer:
    """
    Server that keeps embedding models loaded in memory.

    Listens on Unix socket or TCP socket and processes embedding requests.
    This avoids reloading models in each worker process.
    """

    def __init__(
        self,
        socket_path: Optional[str] = None,
        host: str = "127.0.0.1",
        port: int = 9001,
        use_unix_socket: bool = True,
    ):
        """
        Initialize model server.

        Args:
            socket_path: Path to Unix socket (if use_unix_socket=True)
            host: TCP host (if use_unix_socket=False)
            port: TCP port (if use_unix_socket=False)
            use_unix_socket: Whether to use Unix socket or TCP
        """
        self.socket_path = socket_path or "/tmp/embedding_model_server.sock"
        self.host = host
        self.port = port
        self.use_unix_socket = use_unix_socket

        self.model = None
        self.model_name = None
        self.dimension = None
        self.is_loading = False
        self.server = None

        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    def _signal_handler(self, signum, frame):
        """Handle shutdown signals."""
        logger.info(f"Received signal {signum}, shutting down...")
        if self.server:
            self.server.close()
        sys.exit(0)

    async def _load_model(self, model_name: str, device: str = "auto") -> None:
        """
        Load embedding model.

        Args:
            model_name: Name of the model to load
            device: Device to load model on (auto, cpu, cuda)
        """
        if self.is_loading:
            logger.warning("Model is already loading, waiting...")
            while self.is_loading:
                await asyncio.sleep(0.1)
            return

        if self.model_name == model_name and self.model is not None:
            logger.info(f"Model {model_name} is already loaded")
            return

        load_start = time.time()
        logger.info(f"🔄 [TIMING] Loading model: {model_name}")
        self.is_loading = True

        try:
            from sentence_transformers import SentenceTransformer
            import torch

            # Determine device
            target_device = None
            if device == "auto":
                target_device = "cuda" if torch.cuda.is_available() else "cpu"
            elif device == "cpu":
                target_device = "cpu"
            elif device.startswith("cuda"):
                target_device = device if torch.cuda.is_available() else "cpu"
            else:
                target_device = "cuda" if torch.cuda.is_available() else "cpu"

            logger.info(f"🔄 [TIMING] Loading model on {target_device}...")

            # Load model in executor
            loop = asyncio.get_running_loop()
            self.model = await loop.run_in_executor(
                None, lambda: SentenceTransformer(model_name, device=target_device)
            )

            self.model_name = model_name
            self.dimension = self.model.get_sentence_embedding_dimension()

            load_time = time.time() - load_start
            logger.info(
                f"✅ [TIMING] Model loaded in {load_time:.3f}s: "
                f"{model_name} (dimension: {self.dimension}, device: {target_device})"
            )

            self.is_loading = False

        except Exception as e:
            self.is_loading = False
            logger.exception("❌ Failed to load model %s: %s", model_name, e)
            raise EmbedServiceError(f"Failed to load model {model_name}: {e}") from e

    async def _handle_encode_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle encode request.

        Args:
            request: Request dictionary with 'texts' and optional 'model'

        Returns:
            Response dictionary with 'embeddings' and metadata
        """
        try:
            texts = request.get("texts", [])
            model_name = request.get("model")
            device = request.get("device", "auto")

            if not texts:
                return {"success": False, "error": "No texts provided"}

            # Определяем устройство для обработки запроса
            estimated_memory = estimate_memory_requirement(texts, self.dimension or 384)
            target_device, device_reason = determine_device_for_request(
                device, estimated_memory
            )

            if device_reason:
                logger.info(
                    f"Device selection: {target_device} (reason: {device_reason})"
                )
            else:
                logger.info(f"Device selection: {target_device}")

            # Load model if needed
            if model_name and model_name != self.model_name:
                await self._load_model(model_name, target_device)
            elif self.model is None:
                # Load default model
                default_model = "all-MiniLM-L6-v2"
                await self._load_model(default_model, target_device)

            if self.model is None:
                return {"success": False, "error": "Model not loaded"}

            # Если модель на другом устройстве, перезагружаем на нужном
            current_device = str(self.model.device) if self.model else None
            if target_device != current_device:
                logger.info(
                    f"Model is on {current_device}, reloading on {target_device}..."
                )
                await self._load_model(self.model_name, target_device)

            # Encode texts with CUDA error detection
            encode_start = time.time()
            logger.info(f"🔄 [TIMING] Encoding {len(texts)} text(s)...")

            try:
                # Wrap encode operation to detect CUDA errors immediately
                def encode_wrapper():
                    """Run model.encode via wrap_cuda_operation for CUDA errors."""
                    return wrap_cuda_operation(self.model.encode, texts)

                loop = asyncio.get_running_loop()
                embeddings = await loop.run_in_executor(None, encode_wrapper)
                embeddings_list = embeddings.tolist()

                encode_time = time.time() - encode_start
                logger.info(
                    f"⏱️ [TIMING] Encoding completed: {encode_time:.3f}s "
                    f"({len(texts)} texts, "
                    f"{encode_time/len(texts):.3f}s per text)"
                )

                return {
                    "success": True,
                    "embeddings": embeddings_list,
                    "model": self.model_name,
                    "dimension": self.dimension,
                    "device": str(self.model.device) if self.model else "unknown",
                    "encode_time": encode_time,
                }

            except RuntimeError as e:
                # CUDA errors are caught immediately by wrap_cuda_operation
                encode_time = time.time() - encode_start
                error_msg = str(e)

                logger.error(
                    f"❌ [TIMING] CUDA error after {encode_time:.3f}s: {error_msg}"
                )

                # Get GPU info for error context
                gpu_info = get_gpu_info()

                return {
                    "success": False,
                    "error": f"CUDA error: {error_msg}",
                    "gpu_info": gpu_info,
                    "encode_time": encode_time,
                }

        except (OSError, ValueError, RuntimeError) as e:
            if is_cuda_error(e):
                logger.error("CUDA error in encode request: %s", e)
                gpu_info = get_gpu_info()
                return {
                    "success": False,
                    "error": f"CUDA error: {str(e)}",
                    "gpu_info": gpu_info,
                }
            logger.error("Error handling encode request: %s", e)
            return {"success": False, "error": str(e)}
        except Exception as e:
            if is_cuda_error(e):
                logger.error("CUDA error in encode request: %s", e)
                gpu_info = get_gpu_info()
                return {
                    "success": False,
                    "error": f"CUDA error: {str(e)}",
                    "gpu_info": gpu_info,
                }
            logger.exception("Error handling encode request: %s", e, exc_info=True)
            return {"success": False, "error": str(e)}

    async def _handle_health_request(self) -> Dict[str, Any]:
        """Handle health check request."""
        gpu_info = get_gpu_info()
        return {
            "success": True,
            "status": "ready" if self.model is not None else "not_loaded",
            "model": self.model_name,
            "dimension": self.dimension,
            "device": str(self.model.device) if self.model else "unknown",
            "is_loading": self.is_loading,
            "gpu_info": gpu_info,
        }

    async def _handle_request(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        """
        Handle incoming request.

        Args:
            reader: Stream reader
            writer: Stream writer
        """
        try:
            # Read request
            data = await reader.read(1024 * 1024)  # 1MB max
            if not data:
                return

            request = json.loads(data.decode("utf-8"))
            method = request.get("method")

            # Process request
            if method == "encode":
                response = await self._handle_encode_request(request.get("params", {}))
            elif method == "health":
                response = await self._handle_health_request()
            else:
                response = {"success": False, "error": f"Unknown method: {method}"}

            # Send response
            response_data = json.dumps(response).encode("utf-8")
            writer.write(response_data)
            await writer.drain()

        except (OSError, ValueError, json.JSONDecodeError) as e:
            logger.error("Error handling request: %s", e)
            error_response = {"success": False, "error": str(e)}
            try:
                writer.write(json.dumps(error_response).encode("utf-8"))
                await writer.drain()
            except (OSError, ConnectionError, BrokenPipeError):
                pass  # Best-effort send error; ignore send failures on close
        except Exception as e:
            logger.exception("Error handling request: %s", e, exc_info=True)
            error_response = {"success": False, "error": str(e)}
            try:
                writer.write(json.dumps(error_response).encode("utf-8"))
                await writer.drain()
            except (OSError, ConnectionError, BrokenPipeError):
                pass  # Best-effort send error response
        finally:
            writer.close()
            await writer.wait_closed()

    async def start(self) -> None:
        """Start the model server (non-blocking, runs in background)."""
        try:
            if self.use_unix_socket:
                # Remove existing socket file
                if os.path.exists(self.socket_path):
                    os.unlink(self.socket_path)

                logger.info(
                    f"🚀 Starting model server on Unix socket: {self.socket_path}"
                )
                self.server = await asyncio.start_unix_server(
                    self._handle_request, path=self.socket_path
                )
            else:
                logger.info(f"🚀 Starting model server on {self.host}:{self.port}")
                self.server = await asyncio.start_server(
                    self._handle_request, host=self.host, port=self.port
                )

            logger.info("✅ Model server started, loading default model...")

            # Log GPU info on startup
            gpu_info = get_gpu_info()
            if gpu_info:
                logger.info(
                    "🖥️  GPU Info on startup: %s (memory_total: %.1fMB, "
                    "memory_free: %.1fMB, memory_free_percent: %.1f%%)",
                    gpu_info.get("device_name", "unknown"),
                    gpu_info.get("memory_total", 0) / (1024 * 1024),
                    gpu_info.get("memory_free", 0) / (1024 * 1024),
                    gpu_info.get("memory_free_percent", 0),
                )
            else:
                logger.info("🖥️  GPU: Not available (using CPU)")

            # Load default model
            try:
                await self._load_model("all-MiniLM-L6-v2", "auto")
                logger.info("✅ Default model loaded in model server")

                # Log GPU info after model load
                gpu_info_after = get_gpu_info()
                if gpu_info_after:
                    logger.info(
                        "🖥️  GPU Info after model load: memory_free: %.1fMB, "
                        "memory_free_percent: %.1f%%",
                        gpu_info_after.get("memory_free", 0) / (1024 * 1024),
                        gpu_info_after.get("memory_free_percent", 0),
                    )
            except Exception as e:
                logger.warning(
                    "⚠️ Failed to load default model in model server: %s",
                    e,
                    exc_info=True,
                )

            # Start serving in background
            async with self.server:
                await self.server.serve_forever()

        except Exception as e:
            logger.exception("Failed to start model server: %s", e, exc_info=True)
            raise EmbedServiceError(f"Failed to start model server: {e}") from e

    def run(self) -> None:
        """Run the model server (blocking)."""
        try:
            asyncio.run(self.start())
        except KeyboardInterrupt:
            logger.info("Shutting down model server...")
        finally:
            if self.use_unix_socket and os.path.exists(self.socket_path):
                os.unlink(self.socket_path)


if __name__ == "__main__":
    from embed.services.model_server_main import main

    main()
