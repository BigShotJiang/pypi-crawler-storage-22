"""
CLI entry point for the model server.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import argparse

from embed.services.model_server import ModelServer


def main() -> None:
    """Parse args and run model server (blocking)."""
    parser = argparse.ArgumentParser(description="Model server for embedding service")
    parser.add_argument(
        "--socket-path",
        default="/tmp/embedding_model_server.sock",
        help="Path to Unix socket (default: /tmp/embedding_model_server.sock)",
    )
    parser.add_argument(
        "--host", default="127.0.0.1", help="TCP host (default: 127.0.0.1)"
    )
    parser.add_argument(
        "--port", type=int, default=9001, help="TCP port (default: 9001)"
    )
    parser.add_argument(
        "--tcp", action="store_true", help="Use TCP socket instead of Unix socket"
    )

    args = parser.parse_args()

    server = ModelServer(
        socket_path=args.socket_path,
        host=args.host,
        port=args.port,
        use_unix_socket=not args.tcp,
    )

    server.run()


if __name__ == "__main__":
    main()
