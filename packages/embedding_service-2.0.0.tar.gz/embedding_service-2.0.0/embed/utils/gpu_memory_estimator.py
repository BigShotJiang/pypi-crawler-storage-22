"""
GPU memory estimation helpers.

These heuristics are intended for *pre-flight* device selection (CPU vs CUDA).
They prefer safety over precision to reduce the probability of CUDA OOM.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from typing import Any, Iterable, List, Optional

from embed.utils.torch_utils import import_torch

# Safe default when no GPU or estimation fails (used for encode batch size only).
_SAFE_ENCODE_BATCH_DEFAULT = 32
# Safety margin (MB) subtracted from free GPU memory before computing batch size.
_GPU_SAFETY_MARGIN_MB = 50.0


def _sum_tensor_bytes(tensors: Iterable[Any]) -> int:
    """Sum tensor footprint in bytes (best-effort)."""
    total = 0
    for t in tensors:
        try:
            total += int(t.nelement()) * int(t.element_size())
        except (AttributeError, TypeError, ValueError):
            continue
    return total


def estimate_memory_requirement(texts: list, model_dimension: int = 384) -> float:
    """
    Estimate GPU memory requirement for embedding generation.

    Args:
        texts: List of texts to embed.
        model_dimension: Model embedding dimension (used as a proxy for hidden size).

    Returns:
        Estimated memory requirement in MB.
    """
    # Conservative heuristic for pre-flight checks.
    # Approx tokens ~ chars/4 (common for BPE-like tokenizers).
    approx_tokens = 0
    for t in texts:
        approx_tokens += max(1, int(len(t) / 4))

    bytes_per_float = 4
    hidden_size = max(128, int(model_dimension))

    # Temporary buffers scale with tokens * hidden size.
    # Multiplier is intentionally high.
    activation_multiplier = 12.0
    activation_bytes = int(
        approx_tokens * hidden_size * bytes_per_float * activation_multiplier
    )
    activation_mb = activation_bytes / (1024 * 1024)

    # Output embeddings (float32)
    output_mb = (len(texts) * model_dimension * bytes_per_float) / (1024 * 1024)

    # Model weights + runtime overhead tiers (heuristic).
    if hidden_size <= 384:
        model_overhead_mb = 700.0
    elif hidden_size <= 512:
        model_overhead_mb = 900.0
    elif hidden_size <= 768:
        model_overhead_mb = 1400.0
    else:
        model_overhead_mb = 1800.0

    # Safety buffer for fragmentation/allocator behavior.
    safety_mb = 256.0

    return float(model_overhead_mb + activation_mb + output_mb + safety_mb)


def get_effective_encode_batch_size(
    config_cap: int,
    dimension: int,
    texts_sample: Optional[List[str]] = None,
    safe_default: int = _SAFE_ENCODE_BATCH_DEFAULT,
) -> int:
    """
    Compute effective encode batch size from config cap and current GPU memory.

    Used only for limiting the number of texts per encode() call (worker-side
    batching). Not used for model placement or device selection.

    Args:
        config_cap: Max texts per batch from config (0 = no config limit).
        dimension: Model embedding dimension (e.g. 384, 768) for memory estimate.
        texts_sample: Optional list to estimate average text length; if None,
            a conservative default length is used.
        safe_default: Fallback batch size when GPU is unavailable or estimate
            fails.

    Returns:
        Positive integer: min(config_cap, gpu_based_limit) when config_cap > 0,
        else gpu_based_limit; never exceeds config_cap when config_cap > 0.
    """
    upper_bound = config_cap if config_cap > 0 else 10_000
    dim = max(128, int(dimension))

    # Lazy import to avoid circular dependency with gpu_utils.
    from embed.utils.gpu_utils import get_gpu_info

    gpu_info = get_gpu_info()
    if gpu_info is None:
        return min(upper_bound, safe_default)

    memory_free_bytes = gpu_info.get("memory_free", 0)
    free_mb = memory_free_bytes / (1024 * 1024)
    available_mb = max(0.0, free_mb - _GPU_SAFETY_MARGIN_MB)

    if available_mb <= 0:
        return min(upper_bound, safe_default)

    # Average character length for dummy texts in memory estimate.
    if texts_sample and len(texts_sample) > 0:
        avg_len = sum(len(t) for t in texts_sample) // len(texts_sample)
        avg_len = max(1, min(avg_len, 10000))
    else:
        avg_len = 100

    # Binary search for largest N such that estimate_memory_requirement <= available_mb.
    low, high = 1, upper_bound
    while low < high:
        mid = (low + high + 1) // 2
        dummy_texts = ["x" * avg_len] * mid
        try:
            req_mb = estimate_memory_requirement(dummy_texts, dim)
        except (TypeError, ValueError, ZeroDivisionError):
            high = mid - 1
            continue
        if req_mb <= available_mb:
            low = mid
        else:
            high = mid - 1

    n = low
    if n <= 0:
        return min(upper_bound, safe_default)
    return min(upper_bound, n)


def estimate_model_load_memory_requirement_mb(model: Any) -> float:
    """
    Estimate VRAM required to place the given model on GPU.

    This function measures parameter + buffer sizes and adds a safety margin.
    It is intended for pre-flight checks prior to moving/loading a model onto CUDA.

    Args:
        model: A torch.nn.Module-like object (e.g., SentenceTransformer).

    Returns:
        Estimated memory requirement in MB.
    """
    torch = import_torch()
    if torch is None:
        return 0.0

    params = []
    buffers = []
    try:
        if hasattr(model, "parameters"):
            params = list(model.parameters())
        if hasattr(model, "buffers"):
            buffers = list(model.buffers())
    except (AttributeError, TypeError, RuntimeError):
        params = []
        buffers = []

    weights_bytes = _sum_tensor_bytes(params) + _sum_tensor_bytes(buffers)
    weights_mb = weights_bytes / (1024 * 1024)

    # Conservative safety margin.
    safety_mb = max(256.0, weights_mb * 0.25)
    return float(weights_mb + safety_mb)
