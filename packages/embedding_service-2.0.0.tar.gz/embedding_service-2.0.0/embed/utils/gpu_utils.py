"""
GPU utility functions for CUDA error detection and GPU health monitoring.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

from mcp_proxy_adapter.core.logging import logger

from embed.exceptions import EmbedServiceError
from embed.utils.gpu_memory_estimator import (  # noqa: F401
    estimate_memory_requirement,
    estimate_model_load_memory_requirement_mb,
)
from embed.utils.torch_utils import get_cuda_mem_info, import_torch


def get_gpu_info() -> Optional[Dict[str, Any]]:
    """
    Get GPU information including memory usage.

    Returns:
        Dictionary with GPU info or None if CUDA is not available
    """
    torch = import_torch()
    if torch is None:
        return None
    if not torch.cuda.is_available():
        return None

    try:
        device = int(torch.cuda.current_device())
        props = torch.cuda.get_device_properties(device)
        allocated = int(torch.cuda.memory_allocated(device))
        reserved = int(torch.cuda.memory_reserved(device))

        # Prefer global free memory reported by the CUDA driver.
        mem_info = get_cuda_mem_info(torch, device)
        if mem_info is not None:
            free_global, total = mem_info
        else:
            total = int(props.total_memory)
            # Fallback: this is process-local and can be misleading,
            # but better than nothing.
            free_global = max(0, total - reserved)

        return {
            "device_name": props.name,
            "device_index": device,
            "cuda_version": torch.version.cuda,
            "memory_total": total,
            "memory_allocated": allocated,
            "memory_reserved": reserved,
            "memory_free": free_global,
            "memory_free_percent": (free_global / total * 100) if total > 0 else 0,
            # Process-local estimate (useful for debugging allocator behavior)
            "memory_free_process_estimate": max(0, total - reserved),
        }
    except (OSError, RuntimeError) as e:
        logger.warning("Failed to get GPU info: %s", e)
        return None
    except Exception as e:
        logger.warning("Failed to get GPU info: %s", e, exc_info=True)
        return None


def check_gpu_memory_available(
    estimated_required_mb: float = 100.0,
) -> Tuple[bool, Optional[str]]:
    """
    Check if GPU has sufficient memory available.

    Args:
        estimated_required_mb: Estimated memory requirement in MB

    Returns:
        Tuple of (is_available, error_message)
    """
    torch = import_torch()
    if torch is None:
        return True, None  # CPU-only / torch not installed
    if not torch.cuda.is_available():
        return True, None  # CPU mode, no memory check needed

    try:
        gpu_info = get_gpu_info()
        if gpu_info is None:
            return False, "Failed to get GPU information"

        free_mb = gpu_info["memory_free"] / (1024 * 1024)
        required_mb = estimated_required_mb

        if free_mb < required_mb:
            return False, (
                f"Insufficient GPU memory: {free_mb:.1f}MB free, "
                f"{required_mb:.1f}MB required"
            )

        # Check if memory is critically low (< 5% free)
        if gpu_info["memory_free_percent"] < 5.0:
            free_percent = float(gpu_info["memory_free_percent"])
            logger.warning("GPU memory critically low: %.1f%% free", free_percent)

        return True, None

    except (OSError, RuntimeError) as e:
        logger.warning("Error checking GPU memory: %s", e)
        return True, None
    except Exception as e:
        logger.warning("Error checking GPU memory: %s", e, exc_info=True)
        return True, None


def is_cuda_error(error: Exception) -> bool:
    """
    Check if an exception is a CUDA-related error.

    Args:
        error: Exception to check

    Returns:
        True if error is CUDA-related
    """
    error_str = str(error).lower()
    error_type = type(error).__name__

    # Check for CUDA-related keywords
    cuda_keywords = [
        "cuda",
        "gpu",
        "device-side assertion",
        "unspecified launch failure",
        "out of memory",
        "cublas",
        "cudnn",
    ]

    if any(keyword in error_str for keyword in cuda_keywords):
        return True

    # Check for PyTorch CUDA errors
    if "RuntimeError" in error_type and "cuda" in error_str:
        return True

    return False


def wrap_cuda_operation(operation, *args, **kwargs):
    """
    Wrap a CUDA operation with error detection and fast-fail.

    This function executes the operation and immediately detects CUDA errors,
    allowing for fast-fail instead of waiting for timeout.

    Args:
        operation: Callable to execute
        *args: Positional arguments for operation
        **kwargs: Keyword arguments for operation

    Returns:
        Result of operation

    Raises:
        RuntimeError: If CUDA error is detected
    """
    try:
        result = operation(*args, **kwargs)
        return result
    except Exception as e:
        if is_cuda_error(e):
            # Get GPU info for error context
            gpu_info = get_gpu_info()
            error_msg = f"CUDA error detected: {str(e)}"

            if gpu_info:
                error_msg += (
                    f"\nGPU Info: device={gpu_info['device_name']}, "
                    f"memory_free={gpu_info['memory_free']/(1024*1024):.1f}MB, "
                    f"memory_free_percent={gpu_info['memory_free_percent']:.1f}%"
                )

            logger.error("%s", error_msg)
            raise EmbedServiceError(error_msg) from e
        raise


def determine_device_for_request(
    requested_device: str = "auto",
    estimated_memory_mb: float = 100.0,
    min_free_memory_percent: float = 10.0,
) -> Tuple[str, Optional[str]]:
    """
    Determine target device for a request based on GPU availability and memory.

    Args:
        requested_device: Requested device ("auto", "cpu", "cuda", "cuda:0", etc.)
        estimated_memory_mb: Estimated required memory in MB
        min_free_memory_percent: Minimum global free memory percent to allow GPU usage

    Returns:
        Tuple of (target_device, reason)
        - target_device: "cpu" or "cuda[:index]"
        - reason: Selection reason (None if OK)
    """
    torch = import_torch()
    if torch is None:
        return "cpu", "torch not installed"

    # Если явно запрошен CPU, используем его
    if requested_device == "cpu":
        return "cpu", None

    # Если явно запрошен CUDA, проверяем доступность
    if requested_device.startswith("cuda"):
        if not torch.cuda.is_available():
            logger.warning("CUDA requested but not available, falling back to CPU")
            return "cpu", "CUDA not available"
        # Even for explicit CUDA, avoid obvious OOM by validating free memory.
        try:
            gpu_info = get_gpu_info()
            if gpu_info is None:
                return "cpu", "GPU info unavailable"

            free_percent = float(gpu_info.get("memory_free_percent", 0))
            free_mb = float(gpu_info.get("memory_free", 0)) / (1024 * 1024)

            if free_percent < min_free_memory_percent:
                logger.warning(f"GPU memory low ({free_percent:.1f}% free), using CPU")
                return "cpu", f"GPU memory low ({free_percent:.1f}% free)"

            if free_mb < float(estimated_memory_mb):
                logger.warning(
                    f"GPU memory insufficient ({free_mb:.1f}MB free, "
                    f"{estimated_memory_mb:.1f}MB required), using CPU"
                )
                return "cpu", (
                    f"GPU memory insufficient ({free_mb:.1f}MB free, "
                    f"{estimated_memory_mb:.1f}MB required)"
                )
        except (OSError, RuntimeError, ValueError) as e:
            logger.debug("GPU memory check failed: %s", e)
            return requested_device, None
        except Exception:
            return requested_device, None

        return requested_device, None

    # Для "auto" определяем автоматически
    if requested_device == "auto":
        if not torch.cuda.is_available():
            return "cpu", None

        # Проверяем состояние GPU
        try:
            gpu_info = get_gpu_info()
            if gpu_info is None:
                logger.warning("Failed to get GPU info, using CPU")
                return "cpu", "GPU info unavailable"

            # Проверяем свободную память
            free_percent = gpu_info.get("memory_free_percent", 0)
            free_mb = gpu_info.get("memory_free", 0) / (1024 * 1024)

            # Если памяти недостаточно, используем CPU
            if free_percent < min_free_memory_percent:
                logger.warning(f"GPU memory low ({free_percent:.1f}% free), using CPU")
                return "cpu", f"GPU memory low ({free_percent:.1f}% free)"

            if free_mb < estimated_memory_mb:
                logger.warning(
                    f"GPU memory insufficient ({free_mb:.1f}MB free, "
                    f"{estimated_memory_mb:.1f}MB required), using CPU"
                )
                return "cpu", (
                    f"GPU memory insufficient ({free_mb:.1f}MB free, "
                    f"{estimated_memory_mb:.1f}MB required)"
                )

            # GPU доступен и имеет достаточно памяти
            device_index = gpu_info.get("device_index", 0)
            return f"cuda:{device_index}", None

        except (OSError, RuntimeError) as e:
            logger.warning("Error checking GPU status: %s, using CPU", e)
            return "cpu", f"GPU check failed: {str(e)}"
        except Exception as e:
            logger.warning("Error checking GPU status: %s, using CPU", e, exc_info=True)
            return "cpu", f"GPU check failed: {str(e)}"

    # Неизвестное значение, используем auto
    logger.warning(f"Unknown device '{requested_device}', using auto")
    return determine_device_for_request(
        "auto", estimated_memory_mb, min_free_memory_percent
    )
