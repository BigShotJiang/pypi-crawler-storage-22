#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Service manager utilities: health checks, monitoring, and process management.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import json
import os
import signal
import ssl
import subprocess
import sys
import time
from datetime import datetime, timedelta

import urllib.error
import urllib.request

from embed.exceptions import EmbedServiceError
from embed.utils.service_manager_checker import MCPVectorSearchChecker
from embed.utils.service_manager_constants import (
    EMBED_SERVICE_MANAGER_CERT_PATH,
    EMBED_SERVICE_MANAGER_CONFIG_PATH,
    EMBED_SERVICE_MANAGER_CONTAINER_NAME,
    EMBED_SERVICE_MANAGER_HEALTH_ENDPOINT,
    EMBED_SERVICE_MANAGER_SERVICE_HOST,
    EMBED_SERVICE_MANAGER_SERVICE_NAME,
    EMBED_SERVICE_MANAGER_SERVICE_PORT,
    EMBED_SERVICE_MANAGER_TIMEOUT,
    logger,
)


class ServiceManager:
    """Manages embedding-service: health checks, diagnostics, lifecycle."""

    def __init__(self):
        """Initialize the service manager."""
        self.mcp_checker = MCPVectorSearchChecker()

    def check_health(self):
        """Check service health via HTTP request to /health endpoint."""
        try:
            ctx = ssl.create_default_context()
            if os.path.exists(EMBED_SERVICE_MANAGER_CERT_PATH):
                ctx.load_verify_locations(cafile=EMBED_SERVICE_MANAGER_CERT_PATH)
            else:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                logger.warning(
                    "Certificate not found at %s, SSL verification disabled",
                    EMBED_SERVICE_MANAGER_CERT_PATH,
                )

            request = urllib.request.Request(EMBED_SERVICE_MANAGER_HEALTH_ENDPOINT)
            start_time = time.time()
            with urllib.request.urlopen(
                request, timeout=EMBED_SERVICE_MANAGER_TIMEOUT, context=ctx
            ) as response:
                elapsed = time.time() - start_time
                if response.status == 200:
                    data = json.loads(response.read().decode("utf-8"))
                    logger.info(
                        "Service OK, response in %.2fs",
                        elapsed,
                    )
                    return True, data
                else:
                    logger.warning(f"Service returned status code {response.status}")
                    return False, {
                        "status": "unhealthy",
                        "status_code": response.status,
                    }
        except urllib.error.URLError as e:
            logger.error("Service connection error: %s", e)
            return False, {"status": "error", "error": str(e)}
        except (OSError, ssl.SSLError, ValueError) as e:
            logger.error("Error checking service health: %s", e)
            return False, {"status": "error", "error": str(e)}
        except Exception as e:
            logger.exception("Error checking service health: %s", e, exc_info=True)
            return False, {"status": "error", "error": str(e)}

    def check_port(self):
        """Check whether the service port is reachable."""
        return self.mcp_checker.check_network(
            EMBED_SERVICE_MANAGER_SERVICE_HOST,
            EMBED_SERVICE_MANAGER_SERVICE_PORT,
        )

    def check_container(self):
        """Check Docker container status."""
        try:
            result = subprocess.run(
                [
                    "docker",
                    "container",
                    "inspect",
                    EMBED_SERVICE_MANAGER_CONTAINER_NAME,
                    "--format",
                    "{{.State.Status}}",
                ],
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode == 0:
                status = result.stdout.strip()
                logger.info(
                    "Container %s status: %s",
                    EMBED_SERVICE_MANAGER_CONTAINER_NAME,
                    status,
                )
                return True, {"status": status}
            else:
                logger.warning(
                    "Container %s not found or unreachable",
                    EMBED_SERVICE_MANAGER_CONTAINER_NAME,
                )
                return False, {"status": "not_found", "error": result.stderr.strip()}
        except (OSError, FileNotFoundError) as e:
            logger.error("Error checking container: %s", e)
            return False, {"status": "error", "error": str(e)}
        except Exception as e:
            logger.exception("Error checking container: %s", e, exc_info=True)
            return False, {"status": "error", "error": str(e)}

    def restart_service(self):
        """Restart service via systemctl."""
        try:
            logger.info("Restarting service %s...", EMBED_SERVICE_MANAGER_SERVICE_NAME)
            result = subprocess.run(
                ["sudo", "systemctl", "restart", EMBED_SERVICE_MANAGER_SERVICE_NAME],
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode == 0:
                logger.info(
                    "Service %s restarted successfully",
                    EMBED_SERVICE_MANAGER_SERVICE_NAME,
                )
                return True, {"status": "restarted"}
            else:
                logger.error("Service restart failed: %s", result.stderr.strip())
                return False, {"status": "error", "error": result.stderr.strip()}
        except (OSError, FileNotFoundError) as e:
            logger.error("Exception during service restart: %s", e)
            return False, {"status": "error", "error": str(e)}
        except Exception as e:
            logger.exception("Exception during service restart: %s", e, exc_info=True)
            return False, {"status": "error", "error": str(e)}

    def stop_service(self):
        """Stop the service."""
        try:
            logger.info("Stopping service %s...", EMBED_SERVICE_MANAGER_SERVICE_NAME)
            result = subprocess.run(
                ["sudo", "systemctl", "stop", EMBED_SERVICE_MANAGER_SERVICE_NAME],
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode == 0:
                logger.info(
                    "Service %s stopped successfully",
                    EMBED_SERVICE_MANAGER_SERVICE_NAME,
                )
                return True, {"status": "stopped"}
            else:
                logger.error("Service stop failed: %s", result.stderr.strip())
                return False, {"status": "error", "error": result.stderr.strip()}
        except (OSError, FileNotFoundError) as e:
            logger.error("Exception during service stop: %s", e)
            return False, {"status": "error", "error": str(e)}
        except Exception as e:
            logger.exception("Exception during service stop: %s", e, exc_info=True)
            return False, {"status": "error", "error": str(e)}

    def start_service(self):
        """Start the service."""
        try:
            logger.info("Starting service %s...", EMBED_SERVICE_MANAGER_SERVICE_NAME)
            result = subprocess.run(
                ["sudo", "systemctl", "start", EMBED_SERVICE_MANAGER_SERVICE_NAME],
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode == 0:
                logger.info(
                    "Service %s started successfully",
                    EMBED_SERVICE_MANAGER_SERVICE_NAME,
                )
                return True, {"status": "started"}
            else:
                logger.error("Service start failed: %s", result.stderr.strip())
                return False, {"status": "error", "error": result.stderr.strip()}
        except (OSError, FileNotFoundError) as e:
            logger.error("Exception during service start: %s", e)
            return False, {"status": "error", "error": str(e)}
        except Exception as e:
            logger.exception("Exception during service start: %s", e, exc_info=True)
            return False, {"status": "error", "error": str(e)}

    def get_logs(self, lines=100):
        """Retrieve logs from the Docker container."""
        try:
            logger.info("Fetching last %s log lines...", lines)
            result = subprocess.run(
                [
                    "docker",
                    "logs",
                    "--tail",
                    str(lines),
                    EMBED_SERVICE_MANAGER_CONTAINER_NAME,
                ],
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode == 0:
                logger.info(
                    "Logs retrieved successfully (%s lines)",
                    len(result.stdout.splitlines()),
                )
                return True, {"logs": result.stdout}
            else:
                logger.error("Failed to get logs: %s", result.stderr.strip())
                return False, {"status": "error", "error": result.stderr.strip()}
        except (OSError, FileNotFoundError) as e:
            logger.error("Exception while getting logs: %s", e)
            return False, {"status": "error", "error": str(e)}
        except Exception as e:
            logger.exception("Exception while getting logs: %s", e, exc_info=True)
            return False, {"status": "error", "error": str(e)}

    def check_config(self):
        """Check the configuration file."""
        try:
            logger.info("Checking config file: %s", EMBED_SERVICE_MANAGER_CONFIG_PATH)

            if not os.path.exists(EMBED_SERVICE_MANAGER_CONFIG_PATH):
                logger.error(
                    "Config file not found: %s", EMBED_SERVICE_MANAGER_CONFIG_PATH
                )
                return False, {
                    "status": "not_found",
                    "path": EMBED_SERVICE_MANAGER_CONFIG_PATH,
                }

            with open(EMBED_SERVICE_MANAGER_CONFIG_PATH, "r") as f:
                first_line = f.readline().strip()
                if first_line.startswith("{"):
                    logger.info("Configuration file found and has correct JSON format")
                    return True, {
                        "status": "ok",
                        "path": EMBED_SERVICE_MANAGER_CONFIG_PATH,
                    }
                else:
                    logger.error("Configuration file has incorrect format")
                    return False, {
                        "status": "invalid_format",
                        "path": EMBED_SERVICE_MANAGER_CONFIG_PATH,
                    }
        except (OSError, ValueError, json.JSONDecodeError) as e:
            logger.error("Error checking config file: %s", e)
            return False, {"status": "error", "error": str(e)}
        except Exception as e:
            logger.exception("Error checking config file: %s", e, exc_info=True)
            return False, {"status": "error", "error": str(e)}

    def reload_config(self, config_path=None):
        """Reload configuration."""
        return self.mcp_checker.reload_config(config_path)

    def run_detailed_health_check(self):
        """Run detailed health check."""
        return self.check_health()

    def diagnose(self):
        """Run full service diagnostics."""
        logger.info("Running full service diagnostics...")

        results = {}

        # Проверка конфигурации
        config_status, config_data = self.check_config()
        results["config"] = {"success": config_status, "data": config_data}

        # Проверка порта
        port_status, port_data = self.check_port()
        results["port"] = {"success": port_status, "data": port_data}

        # Проверка контейнера
        container_status, container_data = self.check_container()
        results["container"] = {"success": container_status, "data": container_data}

        # Проверка здоровья
        health_status, health_data = self.check_health()
        results["health"] = {"success": health_status, "data": health_data}

        # Детальная проверка здоровья
        detailed_status, detailed_data = self.run_detailed_health_check()
        results["detailed_health"] = {"success": detailed_status, "data": detailed_data}

        # Общий статус
        results["overall"] = all(
            [
                config_status,
                port_status,
                container_status,
                health_status,
                detailed_status,
            ]
        )

        status = "OK" if results["overall"] else "ERROR"
        logger.info("Diagnostics complete. Overall status: %s", status)

        return results

    def monitor(self, interval=60, duration=None, auto_restart=False):
        """Monitor the service in real time."""
        restart_text = "Yes" if auto_restart else "No"
        logger.info(
            "Starting service monitoring (interval: %ss, auto_restart: %s)",
            interval,
            restart_text,
        )

        start_time = datetime.now()
        end_time = start_time + timedelta(seconds=duration) if duration else None

        # Handle SIGINT for graceful monitoring exit
        def signal_handler(sig, frame):
            """Handle SIGINT: log and exit monitoring loop gracefully."""
            logger.info("Shutdown signal received. Monitoring stopped.")
            print("\nMonitoring stopped.")
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)

        try:
            while True:
                current_time = datetime.now()

                # Check duration
                if end_time and current_time >= end_time:
                    logger.info("Monitoring finished after %ss", duration)
                    break

                # Check service health
                health_status, health_data = self.check_health()

                if health_status:
                    logger.info(
                        "[%s] Service is healthy",
                        current_time.isoformat(),
                    )
                else:
                    logger.warning(
                        "[%s] Service issue: %s",
                        current_time.isoformat(),
                        health_data,
                    )

                    if auto_restart:
                        logger.warning("Auto-restarting service...")
                        restart_status, restart_data = self.restart_service()

                        if restart_status:
                            logger.info("Service restarted successfully")
                        else:
                            logger.error("Service restart failed: %s", restart_data)

                # Wait until next check
                time.sleep(interval)

                # If duration set, compute remaining wait
                if end_time:
                    remaining = (end_time - datetime.now()).total_seconds()
                    if remaining <= 0:
                        break
                    interval = min(interval, remaining)

        except Exception as e:
            logger.exception("Error during monitoring: %s", e, exc_info=True)
            raise EmbedServiceError(f"Monitoring failed: {e}") from e


if __name__ == "__main__":
    from embed.utils.service_manager_main import main

    main()
