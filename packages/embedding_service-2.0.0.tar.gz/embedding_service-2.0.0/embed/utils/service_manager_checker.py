"""
MCP Vector Search health and network checker.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import json
import os
import socket
import ssl
import time
import urllib.error
import urllib.request
from datetime import datetime
from typing import Any, Dict, Optional, Tuple

from embed.utils.service_manager_constants import (
    EMBED_SERVICE_MANAGER_CERT_PATH,
    EMBED_SERVICE_MANAGER_HEALTH_ENDPOINT,
    EMBED_SERVICE_MANAGER_TIMEOUT,
    logger,
)


class MCPVectorSearchChecker:
    """Checker for MCP Vector Search service health and network."""

    def check_health(self, check_type: str = "basic") -> Tuple[bool, Dict[str, Any]]:
        """Check service health via health endpoint."""
        try:
            ctx = ssl.create_default_context()
            if os.path.exists(EMBED_SERVICE_MANAGER_CERT_PATH):
                ctx.load_verify_locations(cafile=EMBED_SERVICE_MANAGER_CERT_PATH)
            else:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                logger.warning(
                    "Certificate not found at %s, SSL verification disabled",
                    EMBED_SERVICE_MANAGER_CERT_PATH,
                )

            request = urllib.request.Request(EMBED_SERVICE_MANAGER_HEALTH_ENDPOINT)
            start_time = time.time()
            with urllib.request.urlopen(
                request, timeout=EMBED_SERVICE_MANAGER_TIMEOUT, context=ctx
            ) as response:
                elapsed = time.time() - start_time
                if response.status == 200:
                    data = json.loads(response.read().decode("utf-8"))
                    logger.info(
                        "Service healthy, response in %.2fs",
                        elapsed,
                    )
                    return True, data
                logger.warning("Service returned status code %s", response.status)
                return False, {
                    "status": "unhealthy",
                    "status_code": response.status,
                }
        except urllib.error.URLError as e:
            logger.error("Service connection error: %s", e)
            return False, {"status": "error", "error": str(e)}
        except (OSError, ValueError) as e:
            logger.error("Error checking service health: %s", e)
            return False, {"status": "error", "error": str(e)}
        except Exception as e:
            logger.exception("Error checking service health: %s", e, exc_info=True)
            return False, {"status": "error", "error": str(e)}

    def check_network(
        self, host: str, port: int, timeout: float = 5.0
    ) -> Tuple[bool, Dict[str, Any]]:
        """Check network connection to host:port."""
        try:
            logger.info(
                "Checking connection to %s:%s (timeout: %ss)", host, port, timeout
            )
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            sock.close()

            if result == 0:
                logger.info("Connection to %s:%s established", host, port)
                return True, {"status": "connected"}
            logger.warning(
                "Failed to connect to %s:%s (code: %s)",
                host,
                port,
                result,
            )
            return False, {"status": "error", "error_code": result}
        except OSError as e:
            logger.error("Error checking network connection: %s", e)
            return False, {"status": "error", "error": str(e)}
        except Exception as e:
            logger.exception("Error checking network connection: %s", e, exc_info=True)
            return False, {"status": "error", "error": str(e)}

    def reload_config(
        self, config_path: Optional[str] = None
    ) -> Tuple[bool, Dict[str, Any]]:
        """
        Reload configuration. This checker does not hold config state;
        reload is a no-op and always returns success.
        """
        logger.debug(
            "reload_config called (config_path=%s); checker has no config state",
            config_path,
        )
        return True, {
            "status": "no_op",
            "message": "Checker has no config to reload",
            "timestamp": datetime.now().isoformat(),
        }
