"""
Constants and logging for service manager utilities.

Re-exports constants from embed.constants; configures logging for this module.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import logging
import os
import sys

from embed.constants import (
    EMBED_SERVICE_MANAGER_CERT_PATH,
    EMBED_SERVICE_MANAGER_CONFIG_PATH,
    EMBED_SERVICE_MANAGER_CONTAINER_NAME,
    EMBED_SERVICE_MANAGER_HEALTH_ENDPOINT,
    EMBED_SERVICE_MANAGER_LOG_DIR,
    EMBED_SERVICE_MANAGER_SERVICE_HOST,
    EMBED_SERVICE_MANAGER_SERVICE_NAME,
    EMBED_SERVICE_MANAGER_SERVICE_PORT,
    EMBED_SERVICE_MANAGER_SERVICE_URL,
    EMBED_SERVICE_MANAGER_TIMEOUT,
)

__all__ = [
    "EMBED_SERVICE_MANAGER_CERT_PATH",
    "EMBED_SERVICE_MANAGER_CONFIG_PATH",
    "EMBED_SERVICE_MANAGER_CONTAINER_NAME",
    "EMBED_SERVICE_MANAGER_HEALTH_ENDPOINT",
    "EMBED_SERVICE_MANAGER_LOG_DIR",
    "EMBED_SERVICE_MANAGER_SERVICE_HOST",
    "EMBED_SERVICE_MANAGER_SERVICE_NAME",
    "EMBED_SERVICE_MANAGER_SERVICE_PORT",
    "EMBED_SERVICE_MANAGER_SERVICE_URL",
    "EMBED_SERVICE_MANAGER_TIMEOUT",
    "logger",
]

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(
            os.path.join(EMBED_SERVICE_MANAGER_LOG_DIR, "service_manager.log")
            if os.path.exists(EMBED_SERVICE_MANAGER_LOG_DIR)
            else "service_manager.log"
        ),
    ],
)
logger = logging.getLogger(__name__)
