"""
CLI entry point for service manager.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import json
import sys

from embed.utils.service_manager import ServiceManager
from embed.utils.service_manager_constants import logger


def main() -> None:
    """Run service manager CLI (parse args and execute command)."""
    import argparse

    parser = argparse.ArgumentParser(description="Manage MCP Vector Search service")
    commands = parser.add_subparsers(dest="command", help="Command to run")

    health_parser = commands.add_parser("health", help="Check service health")
    health_parser.add_argument("--type", choices=["basic", "detailed"], default="basic")

    network_parser = commands.add_parser("network", help="Check network")
    network_parser.add_argument("--host", required=True)
    network_parser.add_argument("--port", type=int, required=True)
    network_parser.add_argument("--timeout", type=float, default=5.0)

    reload_parser = commands.add_parser("reload-config", help="Reload config")
    reload_parser.add_argument("--config", help="Config file path")

    commands.add_parser("start", help="Start service")
    commands.add_parser("stop", help="Stop service")
    commands.add_parser("restart", help="Restart service")
    commands.add_parser("check-port", help="Check port")
    commands.add_parser("check-container", help="Check container")
    commands.add_parser("check-config", help="Check config")
    commands.add_parser("diagnose", help="Full diagnosis")

    logs_parser = commands.add_parser("logs", help="Get logs")
    logs_parser.add_argument("--lines", type=int, default=100)

    monitor_parser = commands.add_parser("monitor", help="Monitor service")
    monitor_parser.add_argument("--interval", type=int, default=60)
    monitor_parser.add_argument("--duration", type=int)
    monitor_parser.add_argument("--auto-restart", action="store_true")

    parser.add_argument("--json", action="store_true", help="Output JSON")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    manager = ServiceManager()

    try:
        status = False
        data = None

        if args.command == "health":
            status, data = manager.mcp_checker.check_health(args.type)
        elif args.command == "network":
            status, data = manager.mcp_checker.check_network(
                args.host, args.port, args.timeout
            )
        elif args.command == "reload-config":
            status, data = manager.reload_config(args.config)
        elif args.command == "start":
            status, data = manager.start_service()
        elif args.command == "stop":
            status, data = manager.stop_service()
        elif args.command == "restart":
            status, data = manager.restart_service()
        elif args.command == "check-port":
            status, data = manager.check_port()
        elif args.command == "check-container":
            status, data = manager.check_container()
        elif args.command == "logs":
            status, data = manager.get_logs(args.lines)
        elif args.command == "check-config":
            status, data = manager.check_config()
        elif args.command == "diagnose":
            data = manager.diagnose()
            status = data.get("overall", False)
        elif args.command == "monitor":
            manager.monitor(args.interval, args.duration, args.auto_restart)
            return

        if args.json:
            print(json.dumps({"success": status, "data": data}))
        else:
            if status:
                print("OK")
                if isinstance(data, dict) and data.get("logs"):
                    print(data["logs"])
                else:
                    print(data)
            else:
                print("Error")
                print(data)
                sys.exit(1)

    except Exception as e:
        logger.exception("Unhandled error: %s", e)
        if args.json:
            print(json.dumps({"success": False, "error": str(e)}))
        else:
            print("Error:", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
