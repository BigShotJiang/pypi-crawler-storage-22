"""
Text utilities for the embedding service.
Contains utility functions for text processing, tokenization, and validation.
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import re
import unicodedata
from typing import List, Optional, Dict, Any


class TextUtils:
    """Utility class for text processing operations"""

    @staticmethod
    def normalize_text(text: str) -> str:
        """
        Normalize text by removing extra whitespace and normalizing unicode.
        Args:
            text: Input text to normalize
        Returns:
            Normalized text
        """
        if not text:
            return ""
        # Normalize unicode
        text = unicodedata.normalize("NFKC", text)
        # Remove extra whitespace
        text = re.sub(r"\s+", " ", text)
        # Strip leading/trailing whitespace
        text = text.strip()
        return text

    @staticmethod
    def clean_text(text: str, remove_special_chars: bool = False) -> str:
        """
        Clean text by removing unwanted characters.
        Args:
            text: Input text to clean
            remove_special_chars: Whether to remove special characters
        Returns:
            Cleaned text
        """
        if not text:
            return ""
        # Normalize text first
        text = TextUtils.normalize_text(text)
        if remove_special_chars:
            # Remove special characters but keep alphanumeric and spaces
            text = re.sub(r"[^\w\s]", " ", text)
            # Remove extra whitespace again
            text = re.sub(r"\s+", " ", text).strip()
        return text

    @staticmethod
    def split_into_sentences(text: str) -> List[str]:
        """
        Split text into sentences.
        Args:
            text: Input text to split
        Returns:
            List of sentences
        """
        if not text:
            return []
        # Simple sentence splitting by common sentence endings
        sentences = re.split(r"[.!?]+", text)
        # Clean and filter empty sentences
        sentences = [s.strip() for s in sentences if s.strip()]
        return sentences

    @staticmethod
    def split_into_paragraphs(text: str) -> List[str]:
        """
        Split text into paragraphs.
        Args:
            text: Input text to split
        Returns:
            List of paragraphs
        """
        if not text:
            return []
        # Split by double newlines or multiple whitespace
        paragraphs = re.split(r"\n\s*\n", text)
        # Clean and filter empty paragraphs
        paragraphs = [p.strip() for p in paragraphs if p.strip()]
        return paragraphs

    @staticmethod
    def tokenize_text(text: str, method: str = "simple") -> List[str]:
        """
        Tokenize text into tokens.
        Args:
            text: Input text to tokenize
            method: Tokenization method ("simple", "word", "sentence")
        Returns:
            List of tokens
        """
        if not text:
            return []
        text = TextUtils.normalize_text(text)
        if method == "simple":
            # Simple word-based tokenization
            tokens = re.findall(r"\w+", text.lower())
        elif method == "word":
            # Word tokenization with punctuation
            tokens = re.findall(r"\w+|[^\w\s]", text)
        elif method == "sentence":
            # Sentence-based tokenization
            tokens = TextUtils.split_into_sentences(text)
        else:
            raise ValueError(f"Unknown tokenization method: {method}")
        return tokens

    @staticmethod
    def validate_text(text: str, max_length: Optional[int] = None) -> bool:
        """
        Validate text input.
        Args:
            text: Text to validate
            max_length: Maximum allowed length
        Returns:
            True if text is valid, False otherwise
        """
        if not isinstance(text, str):
            return False
        if not text.strip():
            return False
        if max_length and len(text) > max_length:
            return False
        return True

    @staticmethod
    def get_text_statistics(text: str) -> Dict[str, Any]:
        """
        Get statistics about text.
        Args:
            text: Input text
        Returns:
            Dictionary with text statistics
        """
        if not text:
            return {
                "length": 0,
                "words": 0,
                "sentences": 0,
                "paragraphs": 0,
                "characters": 0,
            }

        normalized_text = TextUtils.normalize_text(text)
        words = len(normalized_text.split())
        sentences = len(TextUtils.split_into_sentences(text))
        paragraphs = len(TextUtils.split_into_paragraphs(text))
        characters = len(normalized_text)

        return {
            "length": len(text),
            "words": words,
            "sentences": sentences,
            "paragraphs": paragraphs,
            "characters": characters,
        }

    @staticmethod
    def truncate_text(text: str, max_length: int, suffix: str = "...") -> str:
        """
        Truncate text to specified length.
        Args:
            text: Input text
            max_length: Maximum length
            suffix: Suffix to add if truncated
        Returns:
            Truncated text
        """
        if not text or len(text) <= max_length:
            return text

        # Calculate available length for text (excluding suffix)
        available_length = max_length - len(suffix)
        if available_length <= 0:
            return suffix

        # Truncate text
        truncated = text[:available_length]
        # Try to break at word boundary
        last_space = truncated.rfind(" ")
        if (
            last_space > available_length * 0.8
        ):  # Only break at word if it's not too far back
            truncated = truncated[:last_space]

        return truncated + suffix

    @staticmethod
    def remove_duplicates(texts: List[str]) -> List[str]:
        """
        Remove duplicate texts while preserving order.
        Args:
            texts: List of texts
        Returns:
            List with duplicates removed
        """
        seen = set()
        result = []
        for text in texts:
            normalized = TextUtils.normalize_text(text)
            if normalized not in seen:
                seen.add(normalized)
                result.append(text)
        return result

    @staticmethod
    def batch_texts(texts: List[str], max_batch_size: int) -> List[List[str]]:
        """
        Split texts into batches.
        Args:
            texts: List of texts
            max_batch_size: Maximum size of each batch
        Returns:
            List of text batches
        """
        if not texts:
            return []

        batches = []
        current_batch = []

        for text in texts:
            current_batch.append(text)
            if len(current_batch) >= max_batch_size:
                batches.append(current_batch)
                current_batch = []

        # Add remaining texts
        if current_batch:
            batches.append(current_batch)

        return batches
