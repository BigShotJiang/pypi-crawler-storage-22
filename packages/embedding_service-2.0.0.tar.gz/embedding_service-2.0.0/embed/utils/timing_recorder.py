"""
Timing recorder for embedding requests.

Writes one JSON record per line (JSONL) to a file when timing_registration
is enabled. Records allow analysis of bottlenecks, text length vs time,
model load frequency, RPC time, and computation of quantiles/medians.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from mcp_proxy_adapter.core.logging import logger

_DEFAULT_FILE = "./logs/embed_timings.jsonl"
_enabled = False
_file_path: str = _DEFAULT_FILE
_max_bytes: Optional[int] = None
_lock = threading.Lock()


def set_config(
    enabled_flag: bool,
    file_path: Optional[str] = None,
    max_bytes: Optional[int] = None,
) -> None:
    """
    Configure timing registration.

    Args:
        enabled_flag: If True, records will be written to the timing file.
        file_path: Path to JSONL file. If None and enabled_flag is True,
            uses default ./logs/embed_timings.jsonl.
        max_bytes: Max file size in bytes before rotation. When set, the file
            is renamed to <path>.1 and a new file is started. None = no rotation.
    """
    global _enabled, _file_path, _max_bytes
    with _lock:
        _enabled = bool(enabled_flag)
        _file_path = (file_path or _DEFAULT_FILE).strip() or _DEFAULT_FILE
        _max_bytes = int(max_bytes) if max_bytes is not None and max_bytes > 0 else None


def get_config() -> tuple[bool, str, Optional[int]]:
    """
    Return current (enabled, file_path, max_bytes).

    Returns:
        Tuple (enabled, file_path, max_bytes for rotation or None).
    """
    with _lock:
        return _enabled, _file_path, _max_bytes


def is_enabled() -> bool:
    """Return whether timing registration is enabled."""
    with _lock:
        return _enabled


def _rotate_if_needed(p: Path, max_bytes: Optional[int]) -> None:
    """If file exists and size >= max_bytes, rotate to .1 (one backup kept)."""
    if not max_bytes or not p.exists():
        return
    try:
        if p.stat().st_size >= max_bytes:
            backup = Path(str(p) + ".1")
            if backup.exists():
                backup.unlink()
            p.rename(backup)
    except OSError as exc:
        logger.warning("Timing file rotation failed for %s: %s", p, exc)


def record(entry: Dict[str, Any]) -> None:
    """
    Append one timing record to the configured file (if enabled).

    When timing_file_max_bytes is set, the file is rotated automatically
    when its size reaches the limit (current file is renamed to <path>.1).

    Every record must include:
    - coalesced_batch: bool (True if this record is for a coalesced batch
      of logical requests, False otherwise).
    - logical_request_count: int (required when coalesced_batch is True;
      number of logical requests in this batch).

    Record should also contain at least:
    - ts_iso: ISO timestamp
    - is_batch: bool (True if more than one text)
    - text_count: int
    - total_text_len: int (sum of character lengths)
    - min_text_len, max_text_len: int
    - device: str ("cuda" or "cpu" or "cuda:0" etc.)
    - model_loaded_this_request: bool
    - model_load_seconds: float or null
    - encode_seconds: float
    - rpc_seconds: float
    - tokenization_seconds: float (optional)
    - error: str or null (optional)

    Args:
        entry: Dictionary with timing fields (will be serialized as one JSON line).
    """
    if not is_enabled():
        return
    enabled, path, max_bytes = get_config()
    try:
        entry.setdefault("ts_iso", datetime.now(tz=timezone.utc).isoformat())
        line = json.dumps(entry, ensure_ascii=False) + "\n"
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with _lock:
            _rotate_if_needed(p, max_bytes)
            with open(p, "a", encoding="utf-8") as f:
                f.write(line)
        logger.info("Timing record written to %s", path)
    except (OSError, PermissionError) as exc:
        logger.warning("Failed to write timing record to %s: %s", path, exc)
    except Exception as exc:
        logger.warning(
            "Failed to write timing record to %s: %s", path, exc, exc_info=True
        )
