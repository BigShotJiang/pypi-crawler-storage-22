"""
Torch import and CUDA driver helpers.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations

from typing import Optional, Tuple, Any


def import_torch():
    """
    Import torch lazily.

    The project supports a CPU-only configuration (e.g. requirements-no-torch).
    Utility modules must degrade gracefully when torch is not installed.

    Returns:
        The torch module, or None if it cannot be imported.
    """
    try:
        import torch  # type: ignore

        return torch
    except (ImportError, AttributeError):
        return None
    except Exception:
        return None


def get_cuda_mem_info(torch: Any, device_index: int) -> Optional[Tuple[int, int]]:
    """
    Get global CUDA memory info from the driver (best-effort).

    Returns:
        Tuple (free_bytes, total_bytes) or None if not available.
    """
    try:
        if not hasattr(torch.cuda, "mem_get_info"):
            return None
        free_b, total_b = torch.cuda.mem_get_info(device_index)
        return int(free_b), int(total_b)
    except (AttributeError, RuntimeError, OSError):
        return None
    except Exception:
        return None
