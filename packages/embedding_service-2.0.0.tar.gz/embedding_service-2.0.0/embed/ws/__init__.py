"""
WebSocket support for push-based job completion.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from embed.ws.job_completion_ws import register_job_completion_websocket

__all__ = ["register_job_completion_websocket"]
