"""
WebSocket endpoint for push-based job completion.

Client subscribes with {"action": "subscribe", "job_id": "..."}. Server polls
embed_job_status and pushes {"event": "job_completed", "job_id", "result"} or
{"event": "job_failed", "job_id", "error"} when done. Eliminates client poll wait.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio
import json
from typing import Any, Dict, Set

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from mcp_proxy_adapter.commands.command_registry import registry
from mcp_proxy_adapter.core.logging import get_global_logger

logger = get_global_logger()

# Poll interval for checking job status (server-side)
WS_JOB_POLL_INTERVAL = 0.05


async def _get_embed_job_status(job_id: str) -> Dict[str, Any]:
    """Call embed_job_status and return result data or status dict."""
    cmd_class = registry.get_command("embed_job_status")
    if cmd_class is None:
        return {"exists": False, "done": False}
    cmd = cmd_class()
    try:
        result = await cmd.execute(context=None, job_id=job_id)
    except Exception as e:
        logger.warning("embed_job_status %s failed: %s", job_id, e)
        return {"exists": False, "done": False}
    from mcp_proxy_adapter.commands.result import SuccessResult

    if not isinstance(result, SuccessResult):
        return {"exists": False, "done": False}
    return result.data or {}


async def _job_completion_poll_loop(
    websocket: WebSocket,
    subscribed: Set[str],
    stop: asyncio.Event,
) -> None:
    """Poll subscribed job_ids and push completion events; remove when done."""
    while not stop.is_set():
        await asyncio.sleep(WS_JOB_POLL_INTERVAL)
        if not subscribed:
            continue
        done_ids = []
        for job_id in list(subscribed):
            try:
                status = await _get_embed_job_status(job_id)
            except Exception:
                continue
            if not status.get("exists"):
                continue
            if not status.get("done", False):
                continue
            done_ids.append(job_id)
            event: Dict[str, Any]
            if status.get("status") in ("completed", "success"):
                inner = status.get("result") or status.get("data") or status
                if isinstance(inner, dict) and inner.get("success"):
                    data = inner.get("data") or inner
                else:
                    data = inner if isinstance(inner, dict) else {}
                event = {
                    "event": "job_completed",
                    "job_id": job_id,
                    "result": data,
                }
            else:
                event = {
                    "event": "job_failed",
                    "job_id": job_id,
                    "error": status.get("error") or status.get("message", "Unknown"),
                }
            try:
                await websocket.send_json(event)
            except Exception as e:
                logger.warning("WS send for job_id %s failed: %s", job_id, e)
        for j in done_ids:
            subscribed.discard(j)


def register_job_completion_websocket(app: FastAPI) -> None:
    """Register WebSocket route /ws for job completion push."""

    @app.websocket("/ws")
    async def job_completion_ws(websocket: WebSocket) -> None:
        await websocket.accept()
        subscribed: Set[str] = set()
        stop = asyncio.Event()
        poll_task = asyncio.create_task(
            _job_completion_poll_loop(websocket, subscribed, stop)
        )
        try:
            while True:
                try:
                    raw = await websocket.receive_text()
                except WebSocketDisconnect:
                    break
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    await websocket.send_json(
                        {"error": "invalid_json", "message": "Expected JSON"}
                    )
                    continue
                action = msg.get("action")
                job_id = msg.get("job_id")
                if action == "subscribe" and job_id:
                    subscribed.add(job_id)
                    await websocket.send_json({"event": "subscribed", "job_id": job_id})
                elif action == "unsubscribe" and job_id:
                    subscribed.discard(job_id)
                    await websocket.send_json(
                        {"event": "unsubscribed", "job_id": job_id}
                    )
                elif action == "ping":
                    await websocket.send_json({"event": "pong"})
                else:
                    await websocket.send_json(
                        {"error": "unknown_action", "message": str(msg)}
                    )
        finally:
            stop.set()
            poll_task.cancel()
            try:
                await poll_task
            except asyncio.CancelledError:
                pass
            subscribed.clear()

    logger.info("Job completion WebSocket registered at /ws")
