#!/usr/bin/env python3
"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Test script for adapter example.
"""

import sys
import os

# Add adapter examples to path
adapter_examples_path = (
    ".venv/lib/python3.12/site-packages/mcp_proxy_adapter/examples/basic_server"
)
sys.path.insert(0, adapter_examples_path)

# Change to adapter examples directory
os.chdir(adapter_examples_path)

print(f"Working directory: {os.getcwd()}")
print(f"Config file exists: {os.path.exists('config_ssl.json')}")

# Import global protocol manager BEFORE loading config
from mcp_proxy_adapter.core.protocol_manager import (  # noqa: E402
    protocol_manager as _global_protocol_manager,
    ProtocolManager,
)

# Ensure we have a usable protocol manager instance even if global is None
protocol_manager = _global_protocol_manager or ProtocolManager()

print("=== BEFORE LOADING CONFIG ===")
print(f"Global protocol manager enabled: {protocol_manager.enabled}")
print(
    f"Global protocol manager allowed_protocols: {protocol_manager.allowed_protocols}"
)
print(f"Global protocol manager protocols_config: {protocol_manager.protocols_config}")

# Load configuration from adapter example if present
from mcp_proxy_adapter.config import config  # noqa: E402

if os.path.exists("config_ssl.json"):
    config.load_from_file("config_ssl.json")
    print("\n✅ Loaded configuration from: config_ssl.json")
else:
    print("\n⚠️ config_ssl.json not found in example directory; skipping config load")

print("\n=== AFTER LOADING CONFIG ===")
print(f"Global protocol manager enabled: {protocol_manager.enabled}")
print(
    f"Global protocol manager allowed_protocols: {protocol_manager.allowed_protocols}"
)
print(f"Global protocol manager protocols_config: {protocol_manager.protocols_config}")

# Check if protocols config exists
protocols_config = config.get("protocols", {})
print("\nConfig protocols:", protocols_config)

# Test protocol validation
print("\n=== PROTOCOL VALIDATION ===")
print(f"HTTPS allowed: {protocol_manager.is_protocol_allowed('https')}")
print(f"HTTP allowed: {protocol_manager.is_protocol_allowed('http')}")

# Create new protocol manager instance
from mcp_proxy_adapter.core.protocol_manager import ProtocolManager  # noqa: E402

new_protocol_manager = ProtocolManager()

print("\n=== NEW PROTOCOL MANAGER ===")
print(f"New protocol manager enabled: {new_protocol_manager.enabled}")
print(
    f"New protocol manager allowed_protocols: {new_protocol_manager.allowed_protocols}"
)
print(f"New protocol manager protocols_config: {new_protocol_manager.protocols_config}")
print(f"HTTPS allowed: {new_protocol_manager.is_protocol_allowed('https')}")
print(f"HTTP allowed: {new_protocol_manager.is_protocol_allowed('http')}")
