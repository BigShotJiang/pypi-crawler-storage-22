#!/usr/bin/env python3
"""
Comprehensive test for all embedding service configurations.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import asyncio
import json
import logging
import sys
import time
import subprocess
from pathlib import Path
from typing import Dict, Any

import aiohttp
import ssl
import certifi

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ComprehensiveTester:
    """Comprehensive tester for all configurations."""

    def __init__(self, config_dir: str = "config"):
        self.config_dir = Path(config_dir)
        self.results = {}
        self.servers = {}  # Store server processes

    def load_config(self, config_file: str) -> Dict[str, Any]:
        """Load configuration from file."""
        config_path = self.config_dir / config_file
        with open(config_path, "r") as f:
            return json.load(f)

    async def start_server(self, config_file: str) -> bool:
        """Start server with configuration."""
        config = self.load_config(config_file)
        server_config = config.get("server", {})
        host = server_config.get("host", "127.0.0.1")
        port = server_config.get("port", 8000)

        logger.info(f"Starting server with {config_file} on {host}:{port}")

        try:
            # Start server process
            cmd = [
                "python",
                "-m",
                "embed.server",
                "--config",
                str(self.config_dir / config_file),
                "--host",
                host,
                "--port",
                str(port),
            ]

            process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )

            self.servers[config_file] = process

            # Wait for server to start
            await asyncio.sleep(5)

            # Check if process is still running
            if process.poll() is None:
                logger.info(f"✅ Server started successfully: {config_file}")
                return True
            else:
                stdout, stderr = process.communicate()
                logger.error(f"❌ Server failed to start: {config_file}")
                logger.error(f"STDOUT: {stdout}")
                logger.error(f"STDERR: {stderr}")
                return False

        except Exception as e:
            logger.error(f"❌ Error starting server {config_file}: {e}")
            return False

    async def stop_server(self, config_file: str):
        """Stop server process."""
        if config_file in self.servers:
            process = self.servers[config_file]
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
            del self.servers[config_file]
            logger.info(f"Stopped server: {config_file}")

    async def test_http_config(self, config_file: str) -> Dict[str, Any]:
        """Test HTTP configuration."""
        config = self.load_config(config_file)
        result = {
            "config_file": config_file,
            "protocol": "http",
            "status": "failed",
            "error": None,
            "endpoints_tested": {},
            "auth_tested": False,
            "start_time": time.time(),
            "end_time": None,
        }

        try:
            # Extract HTTP settings - use server port, fallback to protocols
            server_config = config.get("server", {})
            http_config = config.get("protocols", {}).get("http", {})
            host = server_config.get("host", http_config.get("host", "127.0.0.1"))
            port = server_config.get("port", http_config.get("port", 8000))
            base_url = f"http://{host}:{port}"

            logger.info(f"Testing HTTP configuration: {config_file} at {base_url}")

            # Test HTTP endpoints
            async with aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=10)
            ) as session:
                # Test health endpoint
                try:
                    async with session.get(f"{base_url}/health") as response:
                        if response.status == 200:
                            result["endpoints_tested"]["health"] = {
                                "status": "success",
                                "response": await response.json(),
                            }
                            logger.info("✅ Health endpoint: OK")
                        else:
                            result["endpoints_tested"]["health"] = {
                                "status": "failed",
                                "error": f"HTTP {response.status}",
                            }
                            logger.error(f"❌ Health endpoint: HTTP {response.status}")
                except Exception as e:
                    result["endpoints_tested"]["health"] = {
                        "status": "failed",
                        "error": str(e),
                    }
                    logger.error(f"❌ Health endpoint: {e}")

                # Test docs endpoint
                try:
                    async with session.get(f"{base_url}/docs") as response:
                        if response.status == 200:
                            result["endpoints_tested"]["docs"] = {
                                "status": "success",
                                "response": "Swagger UI available",
                            }
                            logger.info("✅ Docs endpoint: OK")
                        else:
                            result["endpoints_tested"]["docs"] = {
                                "status": "failed",
                                "error": f"HTTP {response.status}",
                            }
                            logger.error(f"❌ Docs endpoint: HTTP {response.status}")
                except Exception as e:
                    result["endpoints_tested"]["docs"] = {
                        "status": "failed",
                        "error": str(e),
                    }
                    logger.error(f"❌ Docs endpoint: {e}")

            # Check if at least one endpoint worked
            successful_endpoints = sum(
                1
                for ep in result["endpoints_tested"].values()
                if ep["status"] == "success"
            )

            if successful_endpoints > 0:
                result["status"] = "success"
                logger.info(
                    f"✅ {config_file}: {successful_endpoints}/2 endpoints working"
                )
            else:
                result["status"] = "failed"
                logger.error(f"❌ {config_file}: No endpoints working")

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Error testing {config_file}: {e}")

        result["end_time"] = time.time()
        result["duration"] = result["end_time"] - result["start_time"]

        return result

    async def test_https_config(self, config_file: str) -> Dict[str, Any]:
        """Test HTTPS configuration."""
        config = self.load_config(config_file)
        result = {
            "config_file": config_file,
            "protocol": "https",
            "status": "failed",
            "error": None,
            "endpoints_tested": {},
            "auth_tested": False,
            "start_time": time.time(),
            "end_time": None,
        }

        try:
            # Extract HTTPS settings - use server port, fallback to protocols
            server_config = config.get("server", {})
            https_config = config.get("protocols", {}).get("https", {})
            host = server_config.get("host", https_config.get("host", "127.0.0.1"))
            port = server_config.get("port", https_config.get("port", 8000))
            base_url = f"https://{host}:{port}"

            logger.info(f"Testing HTTPS configuration: {config_file} at {base_url}")

            # Create SSL context
            ssl_context = ssl.create_default_context(cafile=certifi.where())
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE

            # For mTLS configurations, add client certificates
            if "mtls" in config_file:
                try:
                    ssl_context.load_cert_chain("certs/client.crt", "certs/client.key")
                    logger.info(f"✅ Client certificates loaded for {config_file}")
                except Exception as e:
                    logger.warning(f"⚠️ Could not load client certificates: {e}")

            # Test HTTPS endpoints
            connector = aiohttp.TCPConnector(ssl=ssl_context)
            async with aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=10), connector=connector
            ) as session:
                # Test health endpoint
                try:
                    async with session.get(f"{base_url}/health") as response:
                        if response.status == 200:
                            result["endpoints_tested"]["health"] = {
                                "status": "success",
                                "response": await response.json(),
                            }
                            logger.info("✅ Health endpoint: OK")
                        else:
                            result["endpoints_tested"]["health"] = {
                                "status": "failed",
                                "error": f"HTTPS {response.status}",
                            }
                            logger.error(f"❌ Health endpoint: HTTPS {response.status}")
                except Exception as e:
                    result["endpoints_tested"]["health"] = {
                        "status": "failed",
                        "error": str(e),
                    }
                    logger.error(f"❌ Health endpoint: {e}")

                # Test docs endpoint
                try:
                    async with session.get(f"{base_url}/docs") as response:
                        if response.status == 200:
                            result["endpoints_tested"]["docs"] = {
                                "status": "success",
                                "response": "Swagger UI available",
                            }
                            logger.info("✅ Docs endpoint: OK")
                        else:
                            result["endpoints_tested"]["docs"] = {
                                "status": "failed",
                                "error": f"HTTPS {response.status}",
                            }
                            logger.error(f"❌ Docs endpoint: HTTPS {response.status}")
                except Exception as e:
                    result["endpoints_tested"]["docs"] = {
                        "status": "failed",
                        "error": str(e),
                    }
                    logger.error(f"❌ Docs endpoint: {e}")

            # Check if at least one endpoint worked
            successful_endpoints = sum(
                1
                for ep in result["endpoints_tested"].values()
                if ep["status"] == "success"
            )

            if successful_endpoints > 0:
                result["status"] = "success"
                logger.info(
                    f"✅ {config_file}: {successful_endpoints}/2 endpoints working"
                )
            else:
                result["status"] = "failed"
                logger.error(f"❌ {config_file}: No endpoints working")

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Error testing {config_file}: {e}")

        result["end_time"] = time.time()
        result["duration"] = result["end_time"] - result["start_time"]

        return result

    async def test_auth_config(self, config_file: str) -> Dict[str, Any]:
        """Test authentication configuration."""
        config = self.load_config(config_file)
        result = {
            "config_file": config_file,
            "auth_type": "unknown",
            "status": "failed",
            "error": None,
            "auth_tests": {},
            "start_time": time.time(),
            "end_time": None,
        }

        try:
            # Check security configuration
            security_config = config.get("security", {})
            auth_config = security_config.get("auth", {})

            if auth_config.get("enabled", False):
                # Test API key authentication
                api_keys = auth_config.get("api_keys", {})
                if api_keys:
                    result["auth_type"] = "api_key"
                    logger.info(f"Testing API key auth for {config_file}")

                    # Test with valid API key
                    for key_name, key_config in api_keys.items():
                        logger.info(f"Testing API key: {key_name}")
                        result["auth_tests"][key_name] = {
                            "status": "tested",
                            "roles": key_config.get("roles", []),
                            "permissions": key_config.get("permissions", []),
                        }

                    result["status"] = "success"
                    logger.info(f"✅ API key auth configured: {config_file}")
                else:
                    result["status"] = "failed"
                    result["error"] = "Auth enabled but no API keys configured"
                    logger.error(f"❌ Auth enabled but no API keys: {config_file}")
            else:
                result["auth_type"] = "none"
                result["status"] = "success"
                logger.info(f"✅ No auth required: {config_file}")

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Error testing auth {config_file}: {e}")

        result["end_time"] = time.time()
        result["duration"] = result["end_time"] - result["start_time"]

        return result

    async def test_mtls_config(self, config_file: str) -> Dict[str, Any]:
        """Test mTLS configuration."""
        config = self.load_config(config_file)
        result = {
            "config_file": config_file,
            "mtls_enabled": False,
            "status": "failed",
            "error": None,
            "certificate_tests": {},
            "start_time": time.time(),
            "end_time": None,
        }

        try:
            # Check SSL configuration
            ssl_config = config.get("ssl", {})
            security_ssl = config.get("security", {}).get("ssl", {})

            if ssl_config.get("enabled", False) or security_ssl.get("enabled", False):
                result["mtls_enabled"] = True
                logger.info(f"Testing mTLS configuration: {config_file}")

                # Check certificate files
                cert_file = ssl_config.get("cert_file") or security_ssl.get("cert_file")
                key_file = ssl_config.get("key_file") or security_ssl.get("key_file")
                ca_cert = ssl_config.get("ca_cert") or security_ssl.get("ca_cert_file")

                if cert_file:
                    result["certificate_tests"]["cert_file"] = {
                        "path": cert_file,
                        "exists": Path(cert_file).exists() if cert_file else False,
                    }

                if key_file:
                    result["certificate_tests"]["key_file"] = {
                        "path": key_file,
                        "exists": Path(key_file).exists() if key_file else False,
                    }

                if ca_cert:
                    result["certificate_tests"]["ca_cert"] = {
                        "path": ca_cert,
                        "exists": Path(ca_cert).exists() if ca_cert else False,
                    }

                # Check client certificate requirements
                verify_client = ssl_config.get("verify_client", False)
                client_cert_required = ssl_config.get("client_cert_required", False)

                result["certificate_tests"]["client_auth"] = {
                    "verify_client": verify_client,
                    "client_cert_required": client_cert_required,
                }

                result["status"] = "success"
                logger.info(f"✅ mTLS configuration found: {config_file}")
            else:
                result["mtls_enabled"] = False
                result["status"] = "success"
                logger.info(f"✅ No mTLS required: {config_file}")

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Error testing mTLS {config_file}: {e}")

        result["end_time"] = time.time()
        result["duration"] = result["end_time"] - result["start_time"]

        return result

    async def run_comprehensive_tests(self) -> Dict[str, Any]:
        """Run comprehensive tests for all configurations."""
        config_files = [
            "http_simple.json",
            "http_token.json",
            "https_simple.json",
            "https_token.json",
            "mtls_simple.json",
            "mtls_roles.json",
        ]

        logger.info(
            f"Starting comprehensive tests for {len(config_files)} configurations"
        )

        for config_file in config_files:
            logger.info(f"\n{'='*60}")
            logger.info(f"Testing configuration: {config_file}")
            logger.info(f"{'='*60}")

            # Start server
            server_started = await self.start_server(config_file)

            if server_started:
                # Test based on configuration type
                if config_file.startswith("http"):
                    result = await self.test_http_config(config_file)
                else:
                    result = await self.test_https_config(config_file)

                # Test authentication
                auth_result = await self.test_auth_config(config_file)
                result["auth_result"] = auth_result

                # Test mTLS
                mtls_result = await self.test_mtls_config(config_file)
                result["mtls_result"] = mtls_result

                self.results[config_file] = result

                # Stop server
                await self.stop_server(config_file)

                # Log result
                status = result["status"]
                duration = result.get("duration", 0)
                logger.info(f"{config_file}: {status} ({duration:.2f}s)")
            else:
                self.results[config_file] = {
                    "config_file": config_file,
                    "status": "failed",
                    "error": "Server failed to start",
                    "start_time": time.time(),
                    "end_time": time.time(),
                    "duration": 0,
                }

        return self.results

    def generate_comprehensive_report(self) -> str:
        """Generate comprehensive test report."""
        total_configs = len(self.results)
        successful_configs = sum(
            1 for r in self.results.values() if r["status"] == "success"
        )

        report = f"""
# Comprehensive Integration Test Report

**Author:** Vasiliy Zdanovskiy
**Email:** vasilyvz@gmail.com
**Date:** {time.strftime('%Y-%m-%d %H:%M:%S')}

## Summary

- **Total Configurations:** {total_configs}
- **Successful:** {successful_configs}
- **Failed:** {total_configs - successful_configs}
- **Success Rate:** {(successful_configs/total_configs)*100:.1f}%

## Configuration Types Tested

### HTTP Configurations:
- **http_simple.json**: Basic HTTP without authentication
- **http_token.json**: HTTP with API key authentication

### HTTPS Configurations:
- **https_simple.json**: Basic HTTPS without authentication
- **https_token.json**: HTTPS with API key authentication

### mTLS Configurations:
- **mtls_simple.json**: HTTPS with mutual TLS authentication
- **mtls_roles.json**: HTTPS with mTLS and role-based access control

## Detailed Results

"""

        for config_file, result in self.results.items():
            status = result["status"]
            duration = result.get("duration", 0)
            error = result.get("error")
            protocol = result.get("protocol", "unknown")

            report += f"### {config_file}\n"
            report += f"- **Status:** {status}\n"
            report += f"- **Protocol:** {protocol}\n"
            report += f"- **Duration:** {duration:.2f}s\n"

            if error:
                report += f"- **Error:** {error}\n"

            # Auth results
            if "auth_result" in result:
                auth_result = result["auth_result"]
                auth_type = auth_result.get("auth_type", "unknown")
                auth_status = auth_result.get("status", "unknown")
                report += f"- **Authentication:** {auth_type} ({auth_status})\n"

                if auth_result.get("auth_tests"):
                    report += "  - **API Keys:**\n"
                    for key_name, key_test in auth_result["auth_tests"].items():
                        roles = key_test.get("roles", [])
                        permissions = key_test.get("permissions", [])
                        report += (
                            f"    - {key_name}: roles={roles}, "
                            f"permissions={permissions}\n"
                        )

            # mTLS results
            if "mtls_result" in result:
                mtls_result = result["mtls_result"]
                mtls_enabled = mtls_result.get("mtls_enabled", False)
                mtls_status = mtls_result.get("status", "unknown")
                m = "enabled" if mtls_enabled else "disabled"
                report += f"- **mTLS:** {m} ({mtls_status})\n"

                if mtls_result.get("certificate_tests"):
                    report += "  - **Certificates:**\n"
                    for cert_type, cert_test in mtls_result[
                        "certificate_tests"
                    ].items():
                        if isinstance(cert_test, dict):
                            if "exists" in cert_test:
                                exists = "✅" if cert_test["exists"] else "❌"
                                path = cert_test.get("path", "N/A")
                                report += f"    - {cert_type}: {exists} {path}\n"
                            elif "verify_client" in cert_test:
                                vc = cert_test["verify_client"]
                                req = cert_test["client_cert_required"]
                                report += (
                                    f"    - {cert_type}: verify_client={vc}, "
                                    f"required={req}\n"
                                )

            # Endpoint results
            if result.get("endpoints_tested"):
                report += "- **Endpoints Tested:**\n"
                for endpoint, endpoint_result in result["endpoints_tested"].items():
                    endpoint_status = endpoint_result["status"]
                    report += f"  - {endpoint}: {endpoint_status}\n"

            report += "\n"

        return report


async def main():
    """Main function."""
    tester = ComprehensiveTester()

    try:
        results = await tester.run_comprehensive_tests()
        report = tester.generate_comprehensive_report()

        # Save report
        with open("comprehensive_integration_report.md", "w") as f:
            f.write(report)

        # Save results as JSON
        with open("comprehensive_integration_results.json", "w") as f:
            json.dump(results, f, indent=2, default=str)

        print(report)

        # Exit with error if any config failed
        failed_configs = sum(1 for r in results.values() if r["status"] != "success")
        if failed_configs > 0:
            sys.exit(1)

    except Exception as e:
        logger.error(f"Comprehensive test failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
