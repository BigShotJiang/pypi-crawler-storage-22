#!/usr/bin/env python3
"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Authentication mode integration test for embedding service.
Tests token authentication and role-based access control.
"""

import json
import requests
import subprocess
import time
import signal
import os
import sys
from typing import Optional


class AuthModeTest:
    """
    Test class for authentication mode functionality.
    """

    def __init__(self):
        """Initialize test environment."""
        # Read port from config
        try:
            with open("config/token_config.json", "r") as f:
                config_data = json.load(f)
            port = config_data.get("server", {}).get("port", 10001)
        except Exception:
            port = 10001

        self.base_url = f"http://127.0.0.1:{port}"
        self.session = requests.Session()
        self.server_process: Optional[subprocess.Popen] = None
        self.test_results = []

        # Test tokens
        self.admin_token = "admin-secret-key-12345"
        self.user_token = "user-secret-key-67890"
        self.readonly_token = "readonly-secret-key-11111"
        self.invalid_token = "invalid-token-99999"

        print("🔧 Test Configuration:")
        print(f"   • Base URL: {self.base_url}")
        print("   • Config: config/token_config.json")
        print(f"   • Admin Token: {self.admin_token[:10]}...")
        print(f"   • User Token: {self.user_token[:10]}...")
        print(f"   • Readonly Token: {self.readonly_token[:10]}...")
        print()

    def log_test(self, test_name: str, success: bool, message: str):
        """Log test result."""
        self.test_results.append(
            {"test": test_name, "success": success, "message": message}
        )
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")

    def wait_for_server(self, timeout: int = 30) -> bool:
        """
        Wait for server to become ready.

        Args:
            timeout: Maximum time to wait in seconds

        Returns:
            True if server is ready
        """
        print("⏳ Waiting for server to start...")
        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                response = requests.get(f"{self.base_url}/health", timeout=5)
                if response.status_code == 200:
                    print(f"✅ Server is ready after {time.time() - start_time:.1f}s")
                    return True
            except requests.exceptions.RequestException:
                pass

            time.sleep(1)

        print(f"❌ Server not ready after {timeout}s")
        return False

    def start_server(self) -> bool:
        """
        Start server in background process.

        Returns:
            True if server started successfully
        """
        try:
            # Kill any existing server processes
            subprocess.run(
                ["pkill", "-f", "python -m embed.server"],
                capture_output=True,
                check=False,
            )
            time.sleep(2)

            # Read port from config
            try:
                with open("config/token_config.json", "r") as f:
                    config_data = json.load(f)
                port = config_data.get("server", {}).get("port", 10001)
            except Exception:
                port = 10001

            print(f"🚀 Starting server on port {port}...")

            # Start server in background
            cmd = [
                "bash",
                "-c",
                (
                    "source .venv/bin/activate && python -m embed.server "
                    f"--config config/token_config.json --host 127.0.0.1 "
                    f"--port {port} --debug"
                ),
            ]

            self.server_process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                preexec_fn=os.setsid,  # Create new process group
            )

            # Wait for server to be ready
            if self.wait_for_server():
                self.log_test("Server Start", True, f"Server started on port {port}")
                return True
            else:
                self.log_test("Server Start", False, "Server failed to start")
                return False

        except Exception as e:
            self.log_test("Server Start", False, f"Failed to start server: {e}")
            return False

    def stop_server(self):
        """Stop the running server."""
        if self.server_process:
            try:
                # Kill the entire process group
                os.killpg(os.getpgid(self.server_process.pid), signal.SIGTERM)
                self.server_process.wait(timeout=5)
            except (subprocess.TimeoutExpired, ProcessLookupError):
                # Force kill if graceful shutdown fails
                try:
                    os.killpg(os.getpgid(self.server_process.pid), signal.SIGKILL)
                except ProcessLookupError:
                    pass
            finally:
                self.server_process = None
                print("🛑 Server stopped")

    def make_request(self, method: str, params: dict = None, token: str = None) -> dict:
        """
        Make authenticated JSON-RPC request.

        Args:
            method: JSON-RPC method
            params: Method parameters
            token: Authentication token

        Returns:
            Response data
        """
        payload = {"jsonrpc": "2.0", "method": method, "params": params or {}, "id": 1}

        headers = {}
        if token:
            headers["X-API-Key"] = token

        response = self.session.post(
            f"{self.base_url}/cmd", json=payload, headers=headers
        )
        return (
            response.json()
            if response.status_code == 200
            else {"error": f"HTTP {response.status_code}"}
        )

    def test_no_auth_denied(self) -> bool:
        """
        Test that requests without authentication are denied.

        Returns:
            True if test passed
        """
        try:
            data = self.make_request("help")
            if "error" in data and "401" in str(data["error"]):
                self.log_test(
                    "No Auth Denied", True, "Unauthenticated requests properly denied"
                )
                return True
            else:
                self.log_test(
                    "No Auth Denied",
                    False,
                    f"Should deny unauthenticated requests: {data}",
                )
                return False
        except Exception as e:
            self.log_test("No Auth Denied", False, f"Error: {e}")
            return False

    def test_admin_access(self) -> bool:
        """
        Test admin role access.

        Returns:
            True if test passed
        """
        try:
            # Test help command
            data = self.make_request("help", token=self.admin_token)
            if "result" in data:
                self.log_test("Admin Help", True, "Admin can access help command")
            else:
                self.log_test("Admin Help", False, f"Admin denied help: {data}")
                return False

            # Test embed command
            data = self.make_request(
                "embed", {"texts": ["Test text"]}, token=self.admin_token
            )
            if "result" in data and data["result"].get("success"):
                embeddings = data["result"].get("data", {}).get("embeddings", [])
                if embeddings and len(embeddings[0]) > 0:
                    self.log_test("Admin Embed", True, "Admin can access embed command")
                else:
                    self.log_test("Admin Embed", False, f"Admin embed failed: {data}")
                    return False
            else:
                self.log_test("Admin Embed", False, f"Admin denied embed: {data}")
                return False

            # Test models command
            data = self.make_request("models", token=self.admin_token)
            if "result" in data and data["result"].get("success"):
                models = data["result"].get("data", {}).get("models", [])
                if isinstance(models, list) and len(models) > 0:
                    self.log_test(
                        "Admin Models", True, "Admin can access models command"
                    )
                    return True
                else:
                    self.log_test("Admin Models", False, f"Admin models failed: {data}")
                    return False
            else:
                self.log_test("Admin Models", False, f"Admin denied models: {data}")
                return False

        except Exception as e:
            self.log_test("Admin Access", False, f"Error: {e}")
            return False

    def test_user_access(self) -> bool:
        """
        Test user role access.

        Returns:
            True if test passed
        """
        try:
            # Test help command
            data = self.make_request("help", token=self.user_token)
            if "result" in data:
                self.log_test("User Help", True, "User can access help command")
            else:
                self.log_test("User Help", False, f"User denied help: {data}")
                return False

            # Test embed command
            data = self.make_request(
                "embed", {"texts": ["Test text"]}, token=self.user_token
            )
            if "result" in data and data["result"].get("success"):
                embeddings = data["result"].get("data", {}).get("embeddings", [])
                if embeddings and len(embeddings[0]) > 0:
                    self.log_test("User Embed", True, "User can access embed command")
                else:
                    self.log_test("User Embed", False, f"User embed failed: {data}")
                    return False
            else:
                self.log_test("User Embed", False, f"User denied embed: {data}")
                return False

            # Test models command
            data = self.make_request("models", token=self.user_token)
            if "result" in data and data["result"].get("success"):
                models = data["result"].get("data", {}).get("models", [])
                if isinstance(models, list) and len(models) > 0:
                    self.log_test("User Models", True, "User can access models command")
                    return True
                else:
                    self.log_test("User Models", False, f"User models failed: {data}")
                    return False
            else:
                self.log_test("User Models", False, f"User denied models: {data}")
                return False

        except Exception as e:
            self.log_test("User Access", False, f"Error: {e}")
            return False

    def test_readonly_access(self) -> bool:
        """
        Test readonly role access.

        Returns:
            True if test passed
        """
        try:
            # Test help command
            data = self.make_request("help", token=self.readonly_token)
            if "result" in data:
                self.log_test("Readonly Help", True, "Readonly can access help command")
            else:
                self.log_test("Readonly Help", False, f"Readonly denied help: {data}")
                return False

            # Test models command (should be allowed)
            data = self.make_request("models", token=self.readonly_token)
            if "result" in data and data["result"].get("success"):
                models = data["result"].get("data", {}).get("models", [])
                if isinstance(models, list) and len(models) > 0:
                    self.log_test(
                        "Readonly Models", True, "Readonly can access models command"
                    )
                else:
                    self.log_test(
                        "Readonly Models", False, f"Readonly models failed: {data}"
                    )
                    return False
            else:
                self.log_test(
                    "Readonly Models", False, f"Readonly denied models: {data}"
                )
                return False

            # Test embed command (should be denied)
            data = self.make_request(
                "embed", {"texts": ["Test text"]}, token=self.readonly_token
            )
            if "error" in data and "403" in str(data["error"]):
                self.log_test(
                    "Readonly Embed Denied",
                    True,
                    "Readonly properly denied embed command",
                )
                return True
            else:
                self.log_test(
                    "Readonly Embed Denied",
                    False,
                    f"Readonly should be denied embed: {data}",
                )
                return False

        except Exception as e:
            self.log_test("Readonly Access", False, f"Error: {e}")
            return False

    def test_invalid_token(self) -> bool:
        """
        Test invalid token handling.

        Returns:
            True if test passed
        """
        try:
            data = self.make_request("help", token=self.invalid_token)
            if "error" in data and "401" in str(data["error"]):
                self.log_test("Invalid Token", True, "Invalid token properly rejected")
                return True
            else:
                self.log_test(
                    "Invalid Token", False, f"Should reject invalid token: {data}"
                )
                return False
        except Exception as e:
            self.log_test("Invalid Token", False, f"Error: {e}")
            return False

    def run_all_tests(self) -> bool:
        """
        Run all authentication mode tests.

        Returns:
            True if all tests passed
        """
        print("=" * 80)
        print("🔐 AUTHENTICATION MODE INTEGRATION TEST")
        print("=" * 80)

        try:
            # Start server
            if not self.start_server():
                return False

            # Run tests
            tests = [
                self.test_no_auth_denied,
                self.test_admin_access,
                self.test_user_access,
                self.test_readonly_access,
                self.test_invalid_token,
            ]

            all_passed = True
            for test in tests:
                if not test():
                    all_passed = False

            return all_passed

        finally:
            # Always stop server
            self.stop_server()

    def print_summary(self):
        """Print test summary."""
        print("\n" + "=" * 80)
        print("📊 TEST SUMMARY")
        print("=" * 80)

        passed = sum(1 for result in self.test_results if result["success"])
        total = len(self.test_results)

        print(f"Total tests: {total}")
        print(f"Passed: {passed}")
        print(f"Failed: {total - passed}")
        print(f"Success rate: {(passed/total)*100:.1f}%")

        if passed == total:
            print("\n🎉 ALL TESTS PASSED!")
        else:
            print("\n❌ SOME TESTS FAILED:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"   • {result['test']}: {result['message']}")


def main():
    """Main test runner."""
    test = AuthModeTest()

    try:
        success = test.run_all_tests()
        test.print_summary()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n🛑 Test interrupted by user")
        test.stop_server()
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Test failed with error: {e}")
        test.stop_server()
        sys.exit(1)


if __name__ == "__main__":
    main()
