"""
Tests for BM25 service functionality.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

from embed.services.bm25_service import BM25Service


class TestBM25Service:
    """Test cases for BM25Service."""

    def setup_method(self):
        """Setup test method."""
        self.bm25_service = BM25Service()

    def test_tokenize_simple_text(self):
        """Test tokenization of simple text."""
        text = "Hello world"
        tokens = self.bm25_service.get_bm25_tokens(text)
        expected = ["hello", "world"]
        assert tokens == expected

    def test_tokenize_text_with_punctuation(self):
        """Test tokenization of text with punctuation."""
        text = "Hello, world! How are you?"
        tokens = self.bm25_service.get_bm25_tokens(text)
        expected = ["hello", "world", "how", "are", "you"]
        assert tokens == expected

    def test_tokenize_text_with_numbers(self):
        """Test tokenization of text with numbers."""
        text = "Version 2.1.0 is released"
        tokens = self.bm25_service.get_bm25_tokens(text)
        expected = ["version", "is", "released"]
        assert tokens == expected

    def test_tokenize_text_with_special_characters(self):
        """Test tokenization of text with special characters."""
        text = "Email: test@example.com & phone: +1-555-1234"
        tokens = self.bm25_service.get_bm25_tokens(text)
        expected = ["email", "test", "example", "com", "phone", "555", "1234"]
        assert tokens == expected

    def test_tokenize_empty_text(self):
        """Test tokenization of empty text."""
        text = ""
        tokens = self.bm25_service.get_bm25_tokens(text)
        assert tokens == []

    def test_tokenize_whitespace_only(self):
        """Test tokenization of whitespace-only text."""
        text = "   \n\t   "
        tokens = self.bm25_service.get_bm25_tokens(text)
        assert tokens == []

    def test_tokenize_single_character(self):
        """Test tokenization of single character (should be filtered out)."""
        text = "a"
        tokens = self.bm25_service.get_bm25_tokens(text)
        assert tokens == []

    def test_tokenize_batch(self):
        """Test batch tokenization."""
        texts = ["Hello world", "Test text", "Another example"]
        token_lists = self.bm25_service.get_bm25_tokens_batch(texts)
        expected = [["hello", "world"], ["test", "text"], ["another", "example"]]
        assert token_lists == expected

    def test_bm25_scores(self):
        """Test BM25 score calculation."""
        query = "hello world"
        documents = ["Hello world example", "Another test document", "Hello world test"]
        scores = self.bm25_service.get_bm25_scores(query, documents)

        # Should return 3 scores
        assert len(scores) == 3
        # All scores should be floats
        assert all(isinstance(score, float) for score in scores)
        # All scores should be non-negative
        assert all(score >= 0.0 for score in scores)
        # BM25 scores can be 0.0 for documents without matching tokens
        # This is normal behavior for BM25 algorithm

    def test_bm25_scores_empty_query(self):
        """Test BM25 scores with empty query."""
        query = ""
        documents = ["Hello world", "Test text"]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert scores == [0.0, 0.0]

    def test_bm25_scores_empty_documents(self):
        """Test BM25 scores with empty documents list."""
        query = "hello world"
        documents = []
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert scores == []

    def test_bm25_scores_single_document(self):
        """Test BM25 scores with single document."""
        query = "hello world"
        documents = ["Hello world example"]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert len(scores) == 1
        assert isinstance(scores[0], float)
        # BM25 scores can be negative, just check it's a valid float
        assert isinstance(scores[0], float)

    def test_bm25_scores_no_matches(self):
        """Test BM25 scores when query has no matches in documents."""
        query = "xyz abc"
        documents = ["Hello world", "Test text", "Another example"]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert len(scores) == 3
        # All scores should be 0.0 when no matches
        assert all(score == 0.0 for score in scores)

    def test_bm25_scores_partial_matches(self):
        """Test BM25 scores with partial matches."""
        query = "hello test"
        documents = ["Hello world example", "Test document", "Another example"]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert len(scores) == 3
        # Documents with matches should have non-negative score
        assert scores[0] >= 0.0 and scores[1] >= 0.0
        # Third document should have 0.0 score (no matches)
        assert scores[2] == 0.0

    def test_bm25_scores_case_insensitive(self):
        """Test that BM25 scores are case insensitive."""
        query = "HELLO WORLD"
        documents = ["hello world example"]
        scores_upper = self.bm25_service.get_bm25_scores(query, documents)

        query = "hello world"
        scores_lower = self.bm25_service.get_bm25_scores(query, documents)

        assert scores_upper == scores_lower

    def test_bm25_scores_with_punctuation(self):
        """Test BM25 scores with punctuation in query and documents."""
        query = "hello, world!"
        documents = ["Hello world example", "Another test"]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert len(scores) == 2
        assert all(s >= 0.0 for s in scores)
        # First document should have same or higher score (hello world match)
        assert scores[0] >= scores[1]

    def test_bm25_scores_with_numbers(self):
        """Test BM25 scores with numbers in query and documents."""
        query = "version 2.1"
        documents = ["Version 2.1.0 is released", "Another version"]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert len(scores) == 2
        # Tokenizer drops single-char tokens (e.g. "2", "1"); "version" matches both
        assert scores[0] >= scores[1]
        assert all(s >= 0.0 for s in scores)

    def test_bm25_scores_with_special_characters(self):
        """Test BM25 scores with special characters."""
        query = "test@example.com"
        documents = [
            "Email: test@example.com",
            "Contact: admin@site.com",
            "Another document",
        ]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert len(scores) == 3
        # First document should have highest score
        assert scores[0] > scores[1]
        assert scores[0] > scores[2]

    def test_bm25_scores_ranking(self):
        """Test that BM25 scores provide proper ranking."""
        query = "machine learning"
        documents = [
            "Machine learning algorithms",
            "Deep learning with neural networks",
            "Artificial intelligence and machine learning",
            "Basic programming concepts",
        ]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert len(scores) == 4
        assert all(s >= 0.0 for s in scores)
        # Documents with both terms should rank above document with no matches
        assert scores[3] == 0.0
        assert (
            scores[0] >= scores[3] and scores[1] >= scores[3] and scores[2] >= scores[3]
        )

    def test_bm25_scores_with_duplicate_terms(self):
        """Test BM25 scores with duplicate terms in documents."""
        query = "test"
        documents = [
            "Test test test",  # Multiple occurrences
            "Test document",  # Single occurrence
            "Another document",  # No occurrences
        ]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert len(scores) == 3
        assert all(s >= 0.0 for s in scores)
        # Document 2 should have 0.0 score (no "test" occurrences)
        assert scores[2] == 0.0
        # Documents 0 and 1 should have same or higher score than document 2
        assert scores[0] >= scores[2] and scores[1] >= scores[2]

    def test_bm25_scores_with_long_documents(self):
        """Test BM25 scores with longer documents."""
        query = "artificial intelligence"
        documents = [
            "Artificial intelligence is a field of computer science.",
            "This is a very long document about many different topics "
            "including machine learning, data science, and artificial "
            "intelligence. It contains many sentences and paragraphs.",
            "Short document about AI.",
        ]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert len(scores) == 3
        assert all(s >= 0.0 for s in scores)
        # At least one document should have a positive score (contains terms)
        assert sum(1 for s in scores if s > 0) >= 1

    def test_bm25_scores_with_empty_strings(self):
        """Test BM25 scores with empty strings in documents."""
        query = "test"
        documents = ["", "Test document", "   "]
        scores = self.bm25_service.get_bm25_scores(query, documents)
        assert len(scores) == 3

        # Empty documents should have 0.0 score
        assert scores[0] == 0.0
        assert scores[2] == 0.0

        # Document with content should have some score
        assert scores[1] > 0.0

    def test_bm25_scores_consistency(self):
        """Test that BM25 scores are consistent across multiple calls."""
        query = "hello world"
        documents = ["Hello world example", "Another test document"]
        scores1 = self.bm25_service.get_bm25_scores(query, documents)
        scores2 = self.bm25_service.get_bm25_scores(query, documents)
        assert scores1 == scores2

    def test_bm25_scores_different_queries(self):
        """Test BM25 scores with different queries on same documents."""
        documents = ["Hello world example", "Test document"]
        query1 = "hello"
        query2 = "world"
        query3 = "test"

        scores1 = self.bm25_service.get_bm25_scores(query1, documents)
        scores2 = self.bm25_service.get_bm25_scores(query2, documents)
        scores3 = self.bm25_service.get_bm25_scores(query3, documents)

        assert len(scores1) == len(scores2) == len(scores3) == 2
        assert all(s >= 0.0 for s in scores1 + scores2 + scores3)

        # Query 1 (hello): document 0 should have same or higher score
        assert scores1[0] >= scores1[1]
        # Query 2 (world): document 0 should have same or higher score
        assert scores2[0] >= scores2[1]
        # Query 3 (test): document 1 should have same or higher score
        assert scores3[1] >= scores3[0]
