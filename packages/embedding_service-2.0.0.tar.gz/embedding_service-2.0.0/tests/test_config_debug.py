#!/usr/bin/env python3
"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Test script for configuration debugging.
"""

import sys
from pathlib import Path

# Add parent directory to import path
sys.path.insert(0, str(Path(__file__).parent))

# Load configuration
from mcp_proxy_adapter.config import config  # noqa: E402

config.load_from_file("config/ssl_config.json")
print("✅ Loaded configuration from: config/ssl_config.json")

# Check all configuration sections
print("\n=== CONFIGURATION SECTIONS ===")
all_config = config.get_all()
for key, value in all_config.items():
    print(f"{key}: {value}")

# Check roles configuration specifically
print("\n=== ROLES CONFIGURATION ===")
roles_config = config.get("roles", {})
print(f"Roles config: {roles_config}")
print(f"Roles enabled: {roles_config.get('enabled', False)}")

# Check if roles section exists in config
print(f"\nRoles section exists: {'roles' in all_config}")

# Check security configuration
print("\n=== SECURITY CONFIGURATION ===")
security_config = config.get("security", {})
print(f"Security config: {security_config}")
print(f"Security enabled: {security_config.get('enabled', False)}")
print(f"Auth enabled: {security_config.get('auth_enabled', False)}")

# Check permissions configuration
permissions_config = security_config.get("permissions", {})
print(f"Permissions config: {permissions_config}")
print(f"Permissions enabled: {permissions_config.get('enabled', False)}")

# Check if there's a default roles configuration somewhere
print("\n=== CHECKING FOR DEFAULT ROLES ===")
if "roles" not in all_config:
    print("No 'roles' section in config")
else:
    print("'roles' section found in config")
