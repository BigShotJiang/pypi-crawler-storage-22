#!/usr/bin/env python3
"""
Test configuration validation (single validator: embed.config.config_validator).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import unittest
from pathlib import Path
from typing import Dict, Any

from embed.config.config_validator import validate_config
from embed.config.config_generator import generate_config, get_default_config


def _minimal_valid_config(overrides: Dict[str, Any] = None) -> Dict[str, Any]:
    """Adapter-compatible config from generator; apply overrides for tests."""
    import copy

    c = get_default_config()
    if overrides:
        for k, v in overrides.items():
            if isinstance(v, dict) and k in c and isinstance(c[k], dict):
                c[k] = {**c[k], **copy.deepcopy(v)}
            else:
                c[k] = copy.deepcopy(v)
    return c


class TestConfigValidation(unittest.TestCase):
    """Test configuration validation (single validator)."""

    @classmethod
    def setUpClass(cls):
        cls.project_root = Path(__file__).parent.parent
        cls.config_examples_dir = cls.project_root / "config" / "examples"
        cls.config_dir = cls.project_root / "embed" / "config"

    def test_default_config_valid(self):
        """Default generator output passes validation."""
        config = get_default_config()
        errors = validate_config(config)
        self.assertEqual(errors, [], f"Default config should be valid: {errors}")

    def test_generate_config_valid(self):
        """generate_config() returns valid config."""
        config = generate_config({"server": {"port": 9000}})
        self.assertEqual(config["server"]["port"], 9000)
        errors = validate_config(config)
        self.assertEqual(errors, [])

    def test_missing_required_section(self):
        """Missing required section (e.g. embedding) produces error."""
        config = get_default_config()
        del config["embedding"]
        errors = validate_config(config)
        self.assertTrue(
            any("embedding" in e.lower() and "required" in e.lower() for e in errors),
            f"Expected missing required section error: {errors}",
        )

    def test_unknown_top_level_key(self):
        """Unknown top-level key produces error."""
        config = _minimal_valid_config()
        config["unknown_section"] = {}
        errors = validate_config(config)
        self.assertTrue(
            any("Unknown top-level" in e or "unknown" in e.lower() for e in errors),
            f"Expected unknown key error: {errors}",
        )

    def test_unknown_nested_key(self):
        """Unknown key in section produces error (adapter rejects extra server keys)."""
        config = _minimal_valid_config()
        config["server"]["unknown_option"] = 1
        errors = validate_config(config)
        self.assertTrue(
            any(
                "server" in e.lower() or "unknown" in e.lower() or "Adapter" in e
                for e in errors
            ),
            f"Expected server/unknown/Adapter error: {errors}",
        )

    def test_coalescing_requires_queue_enabled(self):
        """coalescing.enabled true with queue_manager disabled must fail."""
        config = _minimal_valid_config(
            {
                "queue_manager": {"enabled": False, "max_concurrent_jobs": 1},
                "coalescing": {
                    "enabled": True,
                    "coalescing_window_sec": 0.03,
                    "coalescing_max_texts": 64,
                },
            }
        )
        errors = validate_config(config)
        self.assertTrue(
            any("queue_manager" in e or "coalescing" in e for e in errors),
            f"Expected coalescing/queue error: {errors}",
        )

    def test_coalescing_section_valid(self):
        """Valid coalescing (enabled=false or queue enabled) passes."""
        config = _minimal_valid_config(
            {
                "queue_manager": {"enabled": True, "max_concurrent_jobs": 1},
                "coalescing": {
                    "enabled": False,
                    "coalescing_window_sec": 0.05,
                    "coalescing_max_texts": 32,
                    "coalescing_max_wait_sec": 0.1,
                },
            }
        )
        errors = validate_config(config)
        self.assertEqual(errors, [], f"Valid coalescing should pass: {errors}")
        config["coalescing"]["enabled"] = True
        errors2 = validate_config(config)
        self.assertEqual(
            errors2, [], f"Coalescing+queue enabled should pass: {errors2}"
        )

    def test_coalescing_invalid_values(self):
        """Invalid coalescing_window_sec / coalescing_max_texts produce errors."""
        config = _minimal_valid_config(
            {
                "queue_manager": {"enabled": True, "max_concurrent_jobs": 1},
                "coalescing": {
                    "enabled": False,
                    "coalescing_window_sec": -0.1,
                    "coalescing_max_texts": 64,
                },
            }
        )
        errors = validate_config(config)
        self.assertTrue(len(errors) > 0, f"Expected errors: {errors}")
        self.assertTrue(any("coalescing" in e for e in errors))
        config["coalescing"]["coalescing_window_sec"] = 0.03
        config["coalescing"]["coalescing_max_texts"] = 0
        errors2 = validate_config(config)
        self.assertTrue(len(errors2) > 0)
        self.assertTrue(any("coalescing" in e for e in errors2))

    def test_generate_rejects_invalid_coalescing(self):
        """generate_config raises when overrides produce invalid config."""
        with self.assertRaises(ValueError) as ctx:
            generate_config(
                {
                    "coalescing": {"enabled": True},
                    "queue_manager": {"enabled": False},
                }
            )
        self.assertIn("queue_manager", str(ctx.exception))

    def test_max_texts_per_batch_valid_zero(self):
        """embedding.max_texts_per_batch=0 is valid (no config cap; GPU only)."""
        config = _minimal_valid_config({"embedding": {"max_texts_per_batch": 0}})
        errors = validate_config(config)
        self.assertEqual(errors, [], f"max_texts_per_batch=0 should be valid: {errors}")

    def test_max_texts_per_batch_valid_positive(self):
        """embedding.max_texts_per_batch positive integer is valid."""
        config = _minimal_valid_config({"embedding": {"max_texts_per_batch": 64}})
        errors = validate_config(config)
        self.assertEqual(
            errors, [], f"max_texts_per_batch=64 should be valid: {errors}"
        )

    def test_max_texts_per_batch_invalid_negative(self):
        """embedding.max_texts_per_batch negative is rejected."""
        config = _minimal_valid_config({"embedding": {"max_texts_per_batch": -1}})
        errors = validate_config(config)
        self.assertTrue(
            any("max_texts_per_batch" in e and "non-negative" in e for e in errors),
            f"Expected validation error for negative: {errors}",
        )

    def test_max_texts_per_batch_invalid_non_int(self):
        """embedding.max_texts_per_batch non-integer is rejected."""
        config = _minimal_valid_config({"embedding": {"max_texts_per_batch": "64"}})
        errors = validate_config(config)
        self.assertTrue(
            any("max_texts_per_batch" in e for e in errors),
            f"Expected validation error for non-int: {errors}",
        )

    def test_generator_includes_max_texts_per_batch(self):
        """Generated config includes embedding.max_texts_per_batch key."""
        config = get_default_config()
        self.assertIn("embedding", config)
        self.assertIn("max_texts_per_batch", config["embedding"])
        self.assertIsInstance(config["embedding"]["max_texts_per_batch"], int)
        self.assertGreaterEqual(config["embedding"]["max_texts_per_batch"], 0)

    def test_initializer_sets_max_texts_per_batch_on_service(self):
        """Embedding initializer sets service.max_texts_per_batch from config."""
        import asyncio
        from unittest.mock import AsyncMock, MagicMock, patch

        from embed.services.embedding_initializer import initialize_embedding_service

        mock_service = MagicMock()
        mock_model = MagicMock()
        mock_model.get_sentence_embedding_dimension.return_value = 384
        mock_model.device = "cpu"
        config_with_batch = {
            "embedding": {
                "model_name": "all-MiniLM-L6-v2",
                "max_batch_size": 512,
                "max_text_length": 1_000_000,
                "max_texts_per_batch": 64,
                "use_cache": False,
                "device": "auto",
            },
            "queue_manager": {"max_concurrent_jobs": 1},
        }

        async def run_init():
            with patch(
                "embed.services.embedding_initializer.get_config_dict",
                return_value=config_with_batch,
            ), patch(
                "embed.services.embedding_initializer."
                "load_sentence_transformer_with_auto_device",
                new_callable=AsyncMock,
                return_value=mock_model,
            ):
                await initialize_embedding_service(mock_service)

        asyncio.run(run_init())
        self.assertEqual(
            mock_service.max_texts_per_batch,
            64,
            "Initializer must set max_texts_per_batch from config",
        )


if __name__ == "__main__":
    unittest.main()
