#!/usr/bin/env python3
"""
Test script to check CUDA autodetection in the embedding service.
"""

import asyncio
from embed.services.embedding_service import EmbeddingService


async def test_cuda_detection():
    """Test CUDA autodetection in embedding service"""
    print("Testing CUDA autodetection...")

    # Get service instance
    service = await EmbeddingService.get_instance()

    # Check model device
    print(f"Model device: {service.model.device}")
    print(f"CUDA available: {service.model.device.type == 'cuda'}")
    print(f"Device type: {service.model.device.type}")

    # Test embedding generation
    texts = ["Hello world", "Test text"]
    embeddings = await service.get_embeddings(texts)

    print(f"Generated {len(embeddings)} embeddings")
    print(f"First embedding shape: {len(embeddings[0])}")
    print(f"Model dimension: {service.dimension}")

    return service


if __name__ == "__main__":
    asyncio.run(test_cuda_detection())
