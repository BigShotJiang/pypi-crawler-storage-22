#!/usr/bin/env python3
"""
Test script to check device configuration.
"""

import asyncio
from embed.services.embedding_service import EmbeddingService


async def test_device_config():
    """Test device configuration"""
    print("Testing device configuration...")

    # Get service instance
    service = await EmbeddingService.get_instance()

    # Check device setting
    print(f"Device setting: {service.device}")
    print(f"Model device: {service.model.device}")

    return service


if __name__ == "__main__":
    asyncio.run(test_device_config())
