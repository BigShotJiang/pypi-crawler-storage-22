"""
Advanced embedding tests for multilingual and semantic analysis.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import numpy as np


def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between vectors."""
    dot_product = np.dot(vec1, vec2)
    norm_a = np.linalg.norm(vec1)
    norm_b = np.linalg.norm(vec2)
    return dot_product / (norm_a * norm_b)


class TestMultilingualEmbeddings:
    """Tests for multilingual embeddings."""

    def test_russian_embeddings(self, client, programming_texts_ru):
        """Test embeddings for Russian programming texts."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": programming_texts_ru},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()

        assert "result" in result
        assert "data" in result["result"]
        assert "embeddings" in result["result"]["data"]
        embeddings = result["result"]["data"]["embeddings"]
        assert len(embeddings) == len(programming_texts_ru)

        # Check embedding dimensions
        for embedding in embeddings:
            assert len(embedding) == 384

        # Check that embeddings for different texts are different
        embeddings_array = np.array(embeddings)
        for i in range(len(embeddings_array)):
            for j in range(i + 1, len(embeddings_array)):
                cos_sim = cosine_similarity(embeddings_array[i], embeddings_array[j])
                # Embeddings should be different (not identical)
                assert cos_sim < 0.99

    def test_english_embeddings(self, client, programming_texts_en):
        """Test embeddings for English programming texts."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": programming_texts_en},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()

        assert "result" in result
        assert "data" in result["result"]
        assert "embeddings" in result["result"]["data"]
        embeddings = result["result"]["data"]["embeddings"]
        assert len(embeddings) == len(programming_texts_en)

        # Check embedding dimensions
        for embedding in embeddings:
            assert len(embedding) == 384

        # Check that embeddings for different texts are different
        embeddings_array = np.array(embeddings)
        for i in range(len(embeddings_array)):
            for j in range(i + 1, len(embeddings_array)):
                cos_sim = cosine_similarity(embeddings_array[i], embeddings_array[j])
                # Embeddings should be different (not identical)
                assert cos_sim < 0.99

    def test_bilingual_comparison(self, client):
        """Test comparison of embeddings for same texts in different languages."""
        bilingual_pairs = [
            # Python syntax
            (
                "Python использует отступы для обозначения блоков кода",
                "Python uses indentation to denote code blocks",
            ),
            # JavaScript and async
            (
                "Асинхронное программирование в JavaScript",
                "Asynchronous programming in JavaScript",
            ),
            # Object-oriented programming
            (
                "Классы в объектно-ориентированном программировании",
                "Classes in object-oriented programming",
            ),
        ]

        for ru_text, en_text in bilingual_pairs:
            # Get embeddings for both languages
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": [ru_text, en_text]},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()

            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            embeddings = result["result"]["data"]["embeddings"]
            assert len(embeddings) == 2

            # Calculate similarity between Russian and English embeddings
            ru_embedding = np.array(embeddings[0])
            en_embedding = np.array(embeddings[1])
            similarity = cosine_similarity(ru_embedding, en_embedding)

            # Similar texts in different languages should have high similarity
            assert similarity > 0.5

    def test_semantic_similarity(self, client):
        """Test semantic similarity between related texts."""
        similar_pairs = [
            # Programming concepts
            ("Variables store data in programs", "Program variables hold information"),
            # Algorithm concepts
            (
                "Sorting algorithms arrange data in order",
                "Algorithms that sort organize information",
            ),
            # Function concepts
            (
                "Functions are reusable code blocks",
                "Reusable code blocks are called functions",
            ),
        ]

        for text1, text2 in similar_pairs:
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": [text1, text2]},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()

            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            embeddings = result["result"]["data"]["embeddings"]
            assert len(embeddings) == 2

            # Calculate similarity
            emb1 = np.array(embeddings[0])
            emb2 = np.array(embeddings[1])
            similarity = cosine_similarity(emb1, emb2)

            # Semantically similar texts should have high similarity
            assert similarity > 0.6

    def test_different_topics(self, client):
        """Test that different topics have low similarity."""
        different_pairs = [
            # Programming vs cooking
            ("Variables store data in programs", "Cooking requires fresh ingredients"),
            # Algorithms vs gardening
            ("Sorting algorithms arrange data", "Plants need sunlight and water"),
            # Functions vs sports
            ("Functions are reusable code blocks", "Sports require physical activity"),
        ]

        for text1, text2 in different_pairs:
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": [text1, text2]},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()

            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            embeddings = result["result"]["data"]["embeddings"]
            assert len(embeddings) == 2

            # Calculate similarity
            emb1 = np.array(embeddings[0])
            emb2 = np.array(embeddings[1])
            similarity = cosine_similarity(emb1, emb2)

            # Different topics should have lower similarity
            assert similarity < 0.8

    def test_code_samples_embeddings(self, client, programming_code_samples):
        """Test embeddings for code samples."""
        for language, samples in programming_code_samples.items():
            for sample in samples[:2]:  # Test first 2 samples per language
                response = client.post(
                    "/api/jsonrpc",
                    json={
                        "jsonrpc": "2.0",
                        "method": "embed",
                        "params": {"texts": [sample]},
                        "id": 1,
                    },
                )

                assert response.status_code == 200
                result = response.json()

                assert "result" in result
                assert "data" in result["result"]
                assert "embeddings" in result["result"]["data"]
                embeddings = result["result"]["data"]["embeddings"]
                assert len(embeddings) == 1
                assert len(embeddings[0]) == 384

    def test_embedding_normalization(self, client):
        """Test that embeddings are properly normalized."""
        texts = ["Test text 1", "Test text 2", "Test text 3"]

        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": texts},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()

        assert "result" in result
        assert "data" in result["result"]
        assert "embeddings" in result["result"]["data"]
        embeddings = result["result"]["data"]["embeddings"]

        # Check that embeddings are normalized (magnitude close to 1)
        for embedding in embeddings:
            magnitude = np.linalg.norm(embedding)
            assert abs(magnitude - 1.0) < 0.01

    def test_embedding_consistency(self, client):
        """Test that embeddings are consistent for the same input."""
        text = "Consistency test text"
        embeddings = []

        # Get embeddings multiple times
        for _ in range(5):
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": [text]},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()

            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            embeddings.append(result["result"]["data"]["embeddings"][0])

        # Compare all embeddings
        for i in range(1, len(embeddings)):
            similarity = cosine_similarity(embeddings[0], embeddings[i])
            # Embeddings should be very similar (almost identical)
            assert similarity > 0.999

    def test_batch_processing(self, client):
        """Test batch processing of embeddings."""
        texts = [f"Batch test text {i}" for i in range(10)]

        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": texts},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()

        assert "result" in result
        assert "data" in result["result"]
        assert "embeddings" in result["result"]["data"]
        embeddings = result["result"]["data"]["embeddings"]

        assert len(embeddings) == len(texts)
        for embedding in embeddings:
            assert len(embedding) == 384

        # Check that all embeddings are different
        embeddings_array = np.array(embeddings)
        for i in range(len(embeddings_array)):
            for j in range(i + 1, len(embeddings_array)):
                similarity = cosine_similarity(embeddings_array[i], embeddings_array[j])
                # Different texts should have different embeddings
                assert similarity < 0.99
