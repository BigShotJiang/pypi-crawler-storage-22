"""
Basic tests for embedding functionality.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import pytest
import pytest_asyncio
from typing import AsyncGenerator

from embed.services.embedding_service import EmbeddingService
from embed.commands.embed_command import EmbedCommand
from embed.commands.models_command import ModelsCommand
from mcp_proxy_adapter.commands.result import SuccessResult, ErrorResult


class TestEmbeddingService:
    """Tests for EmbeddingService."""

    @pytest_asyncio.fixture
    async def service(self) -> AsyncGenerator[EmbeddingService, None]:
        """Create service instance."""
        service = await EmbeddingService.get_instance()
        yield service

    @pytest.mark.asyncio
    async def test_get_embeddings(self, service: EmbeddingService) -> None:
        """Test basic embedding generation."""
        texts = ["Hello, world!", "Test text"]
        embeddings = await service.get_embeddings(texts)

        assert isinstance(embeddings, list)
        assert len(embeddings) == 2
        assert all(isinstance(emb, list) for emb in embeddings)
        assert all(isinstance(v, float) for emb in embeddings for v in emb)
        expected_dimension = service.get_model_dimension()
        assert all(len(emb) == expected_dimension for emb in embeddings)

    @pytest.mark.asyncio
    async def test_get_embeddings_with_dimension(
        self, service: EmbeddingService
    ) -> None:
        """Test embedding generation with dimension check."""
        texts = ["Hello, world!"]
        dimension = service.get_model_dimension()

        # Test with correct dimension
        embeddings = await service.get_embeddings(texts, dimension=dimension)
        assert len(embeddings[0]) == dimension

        # Test with incorrect dimension
        with pytest.raises(Exception) as exc_info:
            await service.get_embeddings(texts, dimension=dimension + 1)
        assert "dimension" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_get_available_models(self, service: EmbeddingService) -> None:
        """Test getting available models information."""
        models = await service.get_available_models()

        assert isinstance(models, list)
        assert len(models) > 0

        for model in models:
            assert isinstance(model, dict)
            assert "name" in model
            assert "dimension" in model
            assert "supported_dimensions" in model
            assert isinstance(model["name"], str)
            assert isinstance(model["dimension"], int)
            assert isinstance(model["supported_dimensions"], list)
            assert all(isinstance(d, int) for d in model["supported_dimensions"])
            assert model["dimension"] in model["supported_dimensions"]

    @pytest.mark.asyncio
    async def test_get_model_info(self, service: EmbeddingService) -> None:
        """Test getting current model information."""
        model_info = service.get_model_info()

        assert isinstance(model_info, dict)
        assert "name" in model_info
        assert "dimension" in model_info
        assert "supported_dimensions" in model_info
        assert isinstance(model_info["name"], str)
        assert isinstance(model_info["dimension"], int)
        assert isinstance(model_info["supported_dimensions"], list)
        assert all(isinstance(d, int) for d in model_info["supported_dimensions"])
        expected_dimension = service.get_model_dimension()
        assert model_info["dimension"] == expected_dimension
        assert model_info["dimension"] in model_info["supported_dimensions"]


class TestEmbedCommand:
    """Tests for EmbedCommand."""

    @pytest.fixture
    def command(self) -> EmbedCommand:
        """Create command instance."""
        return EmbedCommand()

    @pytest.mark.asyncio
    async def test_execute_basic(self, command: EmbedCommand) -> None:
        """Test basic command execution."""
        command.params = {"texts": ["Hello, world!"]}
        result = await command.execute(**command.params)

        assert isinstance(result, SuccessResult)
        data = result.data
        assert "embeddings" in data
        assert "results" in data
        assert "model" in data
        assert "dimension" in data

        embeddings = data["embeddings"]
        assert isinstance(embeddings, list)
        assert len(embeddings) == 1
        assert all(isinstance(emb, list) for emb in embeddings)
        assert all(isinstance(v, float) for emb in embeddings for v in emb)

        results = data["results"]
        assert isinstance(results, list)
        assert len(results) == 1
        result_item = results[0]
        assert "body" in result_item
        assert "embedding" in result_item
        assert "tokens" in result_item
        assert "bm25_tokens" in result_item

    @pytest.mark.asyncio
    async def test_execute_multiple_texts(self, command: EmbedCommand) -> None:
        """Test command execution with multiple texts."""
        command.params = {"texts": ["Hello", "World", "Test"]}
        result = await command.execute(**command.params)

        assert isinstance(result, SuccessResult)
        data = result.data
        embeddings = data["embeddings"]
        assert len(embeddings) == 3

        results = data["results"]
        assert len(results) == 3
        for i, result_item in enumerate(results):
            assert result_item["body"] == command.params["texts"][i]

    @pytest.mark.asyncio
    async def test_execute_with_dimension(self, command: EmbedCommand) -> None:
        """Test command execution with dimension parameter."""
        command.params = {"texts": ["Hello, world!"], "dimension": 384}
        result = await command.execute(**command.params)

        assert isinstance(result, SuccessResult)
        data = result.data
        embeddings = data["embeddings"]
        assert len(embeddings[0]) == 384

    @pytest.mark.asyncio
    async def test_execute_validation_errors(self, command: EmbedCommand) -> None:
        """Test command execution with validation errors."""
        # Test empty texts
        command.params = {"texts": []}
        result = await command.execute(**command.params)
        assert isinstance(result, ErrorResult)
        assert "empty" in result.message.lower()

        # Test invalid texts type
        command.params = {"texts": "not a list"}
        result = await command.execute(**command.params)
        assert isinstance(result, ErrorResult)
        assert "list" in result.message.lower()

        # Test empty text
        command.params = {"texts": [""]}
        result = await command.execute(**command.params)
        assert isinstance(result, ErrorResult)
        assert "empty" in result.message.lower()


class TestModelsCommand:
    """Tests for ModelsCommand."""

    @pytest.fixture
    def command(self) -> ModelsCommand:
        """Create command instance."""
        return ModelsCommand()

    @pytest.mark.asyncio
    async def test_execute_basic(self, command: ModelsCommand) -> None:
        """Test basic command execution."""
        result = await command.execute()

        assert isinstance(result, SuccessResult)
        data = result.data
        assert "models" in data

        models = data["models"]
        assert isinstance(models, list)
        assert len(models) > 0

        for model in models:
            assert isinstance(model, dict)
            assert "name" in model
            assert "dimension" in model
            assert "description" in model
            assert "max_tokens" in model
            assert isinstance(model["name"], str)
            assert isinstance(model["dimension"], int)
            assert isinstance(model["description"], str)
            assert isinstance(model["max_tokens"], int)

    @pytest.mark.asyncio
    async def test_execute_model_structure(self, command: ModelsCommand) -> None:
        """Test model structure in response."""
        result = await command.execute()

        assert isinstance(result, SuccessResult)
        data = result.data
        models = data["models"]

        # Check that at least one model has required fields
        model = models[0]
        assert "name" in model
        assert "dimension" in model
        assert "description" in model
        assert "max_tokens" in model

        # Check data types
        assert isinstance(model["name"], str)
        assert isinstance(model["dimension"], int)
        assert isinstance(model["description"], str)
        assert isinstance(model["max_tokens"], int)

        # Check reasonable values
        assert len(model["name"]) > 0
        assert model["dimension"] > 0
        assert len(model["description"]) > 0
        assert model["max_tokens"] > 0
