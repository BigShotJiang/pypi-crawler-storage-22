"""
Edge cases tests for embedding functionality.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import pytest
import pytest_asyncio
from typing import AsyncGenerator

from embed.services.embedding_service import EmbeddingService
from embed.commands.embed_command import EmbedCommand
from embed.commands.models_command import ModelsCommand
from mcp_proxy_adapter.commands.result import SuccessResult


class TestEdgeCases:
    """Tests for edge cases in embedding functionality."""

    @pytest_asyncio.fixture
    async def service(self) -> AsyncGenerator[EmbeddingService, None]:
        """Create service instance."""
        service = await EmbeddingService.get_instance()
        yield service

    @pytest.mark.asyncio
    async def test_special_characters(self, service: EmbeddingService) -> None:
        """Test embedding generation with special characters."""
        texts = ["!@#$%^&*()_+{}|:<>?~`-=[]\\;',./"]
        with pytest.raises(Exception) as excinfo:
            await service.get_embeddings(texts)
        assert "contains only special characters" in str(excinfo.value)

    @pytest.mark.asyncio
    async def test_long_texts(self, service: EmbeddingService) -> None:
        """Test embedding generation with long texts."""
        texts = ["a" * 1000, "b" * 2000]
        embeddings = await service.get_embeddings(texts)

        assert isinstance(embeddings, list)
        assert len(embeddings) == 2
        assert all(isinstance(emb, list) for emb in embeddings)
        assert all(isinstance(v, float) for emb in embeddings for v in emb)
        expected_dimension = service.get_model_dimension()
        assert all(len(emb) == expected_dimension for emb in embeddings)

    @pytest.mark.asyncio
    async def test_unicode_texts(self, service: EmbeddingService) -> None:
        """Test embedding generation with Unicode texts."""
        texts = [
            "Привет, мир!",  # Russian
            "你好，世界！",  # Chinese
            "こんにちは世界！",  # Japanese
            "안녕하세요 세계!",  # Korean
            "مرحبا بالعالم!",  # Arabic
            "नमस्ते दुनिया!",  # Hindi
            "สวัสดีชาวโลก!",  # Thai
            "Γεια σου κόσμε!",  # Greek
            "¡Hola mundo!",  # Spanish
            "Hello, world!",  # English
        ]

        embeddings = await service.get_embeddings(texts)

        assert isinstance(embeddings, list)
        assert len(embeddings) == len(texts)
        assert all(isinstance(emb, list) for emb in embeddings)
        assert all(isinstance(v, float) for emb in embeddings for v in emb)
        expected_dimension = service.get_model_dimension()
        assert all(len(emb) == expected_dimension for emb in embeddings)

    @pytest.mark.asyncio
    async def test_mixed_content(self, service: EmbeddingService) -> None:
        """Test embedding generation with mixed content."""
        texts = [
            "Hello, world!",  # Plain text
            "Hello, world! 123",  # Text with numbers
            "Hello, world! @#$%",  # Text with special characters
            "Hello, world! Привет!",  # Mixed languages
            "Hello, world! 你好!",  # Mixed scripts
            "Hello, world! 🌍",  # Text with emoji
            "Hello, world! \n\t\r",  # Text with whitespace
            "Hello, world! " * 10,  # Repeated text
        ]

        embeddings = await service.get_embeddings(texts)

        assert isinstance(embeddings, list)
        assert len(embeddings) == len(texts)
        assert all(isinstance(emb, list) for emb in embeddings)
        assert all(isinstance(v, float) for emb in embeddings for v in emb)
        expected_dimension = service.get_model_dimension()
        assert all(len(emb) == expected_dimension for emb in embeddings)

    @pytest.mark.asyncio
    async def test_command_edge_cases(self, monkeypatch) -> None:
        """Test edge cases in command execution."""
        command = EmbedCommand()

        # Mock the embedding service for successful cases
        async def mock_get_instance():
            service = EmbeddingService()
            service.model_name = "test-model"
            service.dimension = 384

            async def mock_get_embeddings(
                texts, model=None, dimension=None, device="auto"
            ):
                return [[0.1] * 384 for _ in texts]

            service.get_embeddings = mock_get_embeddings  # type: ignore[assignment]
            service.is_model_ready = lambda: True  # type: ignore[assignment]
            service.get_model_status = lambda: {
                "status": "ready",
                "model": service.model_name,
            }  # type: ignore[assignment]
            return service

        monkeypatch.setattr(EmbeddingService, "get_instance", mock_get_instance)

        # Test with various edge cases
        test_cases = [
            ["Single text"],
            ["Text with numbers 123"],
            ["Text with special chars @#$%"],
            ["Text with unicode Привет"],
            ["Text with emoji 🌍"],
            ["Text with whitespace \n\t\r"],
            ["Repeated text " * 5],
        ]

        for texts in test_cases:
            result = await command.execute(texts=texts)
            assert isinstance(result, SuccessResult)
            data = result.data
            assert "embeddings" in data
            assert "results" in data
            assert len(data["embeddings"]) == len(texts)

    @pytest.mark.asyncio
    async def test_models_command_edge_cases(self, monkeypatch) -> None:
        """Test edge cases in models command execution."""
        command = ModelsCommand()

        # Mock the embedding service
        async def mock_get_instance():
            service = EmbeddingService()
            service.model_name = "test-model"
            service.dimension = 384

            async def mock_get_available_models():
                return [
                    {
                        "name": "test-model",
                        "dimension": 384,
                        "description": "Test model",
                        "max_tokens": 512,
                    }
                ]

            service.get_available_models = mock_get_available_models
            return service

        monkeypatch.setattr(EmbeddingService, "get_instance", mock_get_instance)

        result = await command.execute()
        assert isinstance(result, SuccessResult)
        data = result.data
        assert "models" in data
        assert len(data["models"]) > 0

    @pytest.mark.asyncio
    async def test_empty_text_validation(self, service: EmbeddingService) -> None:
        """Test validation of empty texts."""
        from mcp_proxy_adapter.core.errors import ValidationError

        empty_texts = ["", "   ", "\n\t\r"]
        for text in empty_texts:
            with pytest.raises(ValidationError) as excinfo:
                await service.get_embeddings([text])
            msg = str(excinfo.value).lower()
            # Depending on input, message may mention "empty" or "special characters"
            assert ("empty" in msg) or ("special characters" in msg)

    @pytest.mark.asyncio
    async def test_very_long_text(self, service: EmbeddingService) -> None:
        """Test with very long text."""
        long_text = "This is a very long text. " * 1000
        embeddings = await service.get_embeddings([long_text])

        assert isinstance(embeddings, list)
        assert len(embeddings) == 1
        assert isinstance(embeddings[0], list)
        assert all(isinstance(v, float) for v in embeddings[0])
        expected_dimension = service.get_model_dimension()
        assert len(embeddings[0]) == expected_dimension

    @pytest.mark.asyncio
    async def test_single_character_texts(self, service: EmbeddingService) -> None:
        """Test with single character texts."""
        single_chars = ["a", "b", "c", "1", "!", "字"]
        # '!' is now considered invalid (only special characters), so the whole
        # batch should fail validation.
        from mcp_proxy_adapter.core.errors import ValidationError

        with pytest.raises(ValidationError):
            await service.get_embeddings(single_chars)

    @pytest.mark.asyncio
    async def test_numbers_only_texts(self, service: EmbeddingService) -> None:
        """Test with numbers-only texts."""
        number_texts = ["123", "456.789", "0", "-1"]
        embeddings = await service.get_embeddings(number_texts)

        assert isinstance(embeddings, list)
        assert len(embeddings) == len(number_texts)
        assert all(isinstance(emb, list) for emb in embeddings)
        assert all(isinstance(v, float) for emb in embeddings for v in emb)
        expected_dimension = service.get_model_dimension()
        assert all(len(emb) == expected_dimension for emb in embeddings)
