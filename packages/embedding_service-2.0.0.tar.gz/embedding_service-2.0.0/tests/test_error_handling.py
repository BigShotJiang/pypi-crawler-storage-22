"""
Tests for error handling in commands.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

from embed.services.embedding_service import EmbeddingService


# Use shared client fixture from conftest (no local override)


class TestEmbedCommandErrors:
    """Tests for error handling in embed command."""

    def test_missing_texts(self, client):
        """Test error when texts parameter is missing."""
        response = client.post(
            "/api/jsonrpc",
            json={"jsonrpc": "2.0", "method": "embed", "params": {}, "id": 1},
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32602
        assert "texts" in error["message"].lower()

    def test_invalid_texts_type(self, client):
        """Test error when texts parameter is not a list."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": "not a list"},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32602
        assert "list" in error["message"].lower()

    def test_empty_texts_list(self, client):
        """Test error when texts list is empty."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": []},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32602
        assert "empty" in error["message"].lower()

    def test_invalid_model(self, client):
        """Test error when invalid model is provided."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Hello, world!"], "model": "invalid-model"},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32603  # Internal error for invalid model
        assert "embedding generation failed" in error["message"].lower()


class TestModelsCommandErrors:
    """Tests for models command error handling."""

    def test_service_error(self, client, monkeypatch):
        """Test error when service fails."""

        async def mock_get_instance():
            raise Exception("Service error")

        monkeypatch.setattr(EmbeddingService, "get_instance", mock_get_instance)

        response = client.post(
            "/api/jsonrpc", json={"jsonrpc": "2.0", "method": "models", "id": 1}
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32603
        assert "service initialization failed" in error["message"].lower()

    def test_invalid_jsonrpc_version(self, client):
        """Test error when JSON-RPC version is invalid."""
        response = client.post(
            "/api/jsonrpc",
            json={"jsonrpc": "1.0", "method": "models", "id": 1},  # Invalid version
        )

        assert response.status_code == 200
        result = response.json()
        assert "error" in result
        error = result["error"]
        assert error["code"] == -32600
        assert "jsonrpc: 2.0" in error["message"]

    def test_missing_method(self, client):
        """Test error when method is missing."""
        response = client.post("/api/jsonrpc", json={"jsonrpc": "2.0", "id": 1})

        assert response.status_code == 200
        result = response.json()
        assert "error" in result
        error = result["error"]
        assert error["code"] == -32600
        assert "method is required" in error["message"].lower()

    def test_invalid_method(self, client):
        """Test error when method is invalid."""
        response = client.post(
            "/api/jsonrpc", json={"jsonrpc": "2.0", "method": "invalid_method", "id": 1}
        )

        assert response.status_code == 200
        result = response.json()
        assert "error" in result
        error = result["error"]
        assert error["code"] == -32601
        assert "method not found" in error["message"].lower()

    def test_missing_id(self, client):
        """Test error when id is missing."""
        response = client.post(
            "/api/jsonrpc", json={"jsonrpc": "2.0", "method": "models"}
        )

        assert response.status_code == 200
        result = response.json()
        assert "error" in result
        error = result["error"]
        assert error["code"] == -32601
        assert "method not found" in error["message"].lower()

    def test_invalid_params_type(self, client):
        """Test error when params is not an object."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": "not an object",
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "error" in result
        error = result["error"]
        assert error["code"] == -32600
        assert "params must be an object" in error["message"].lower()

    def test_empty_text_validation(self, client):
        """Test error when text is empty."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": [""]},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32602
        assert "empty" in error["message"].lower()

    def test_whitespace_only_text(self, client):
        """Test error when text contains only whitespace."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["   "]},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32602
        assert "empty" in error["message"].lower()

    def test_non_string_text(self, client):
        """Test error when text is not a string."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": [123]},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32602
        assert "string" in error["message"].lower()

    def test_mixed_invalid_texts(self, client):
        """Test error when some texts are invalid."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["valid", "", "   ", 123]},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32602
        assert "empty" in error["message"].lower()

    def test_special_characters_only(self, client):
        """Test error when text contains only special characters."""
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["!@#$%^&*()"]},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32602
        assert "special characters" in error["message"].lower()

    def test_text_too_long(self, client):
        """Test error when text is too long."""
        long_text = "a" * 10001  # Exceeds MAX_TEXT_LENGTH
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": [long_text]},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32602
        assert "too long" in error["message"].lower()

    def test_batch_too_large(self, client):
        """Test error when batch size is too large."""
        texts = ["text"] * 101  # Exceeds MAX_BATCH_SIZE
        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": texts},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "error" in result["result"]
        error = result["result"]["error"]
        assert error["code"] == -32602
        assert "batch size" in error["message"].lower()
