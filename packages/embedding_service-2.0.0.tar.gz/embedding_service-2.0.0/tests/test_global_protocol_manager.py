#!/usr/bin/env python3
"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Test script for global protocol manager.
"""

import sys
from pathlib import Path

# Add parent directory to import path
sys.path.insert(0, str(Path(__file__).parent))

# Import global protocol manager BEFORE loading config
from mcp_proxy_adapter.core.protocol_manager import (  # noqa: E402
    protocol_manager as _global_protocol_manager,
    ProtocolManager,
)

# Ensure we have a usable protocol manager instance even if global is None
protocol_manager = _global_protocol_manager or ProtocolManager()

print("=== BEFORE LOADING CONFIG ===")
print(f"Global protocol manager enabled: {protocol_manager.enabled}")
print(
    f"Global protocol manager allowed_protocols: {protocol_manager.allowed_protocols}"
)
print(f"Global protocol manager protocols_config: {protocol_manager.protocols_config}")

# Load configuration
from mcp_proxy_adapter.config import config  # noqa: E402

config.load_from_file("config/ssl_config.json")
print("\n✅ Loaded configuration from: config/ssl_config.json")

print("\n=== AFTER LOADING CONFIG ===")
print(f"Global protocol manager enabled: {protocol_manager.enabled}")
print(
    f"Global protocol manager allowed_protocols: {protocol_manager.allowed_protocols}"
)
print(f"Global protocol manager protocols_config: {protocol_manager.protocols_config}")

# Check if protocols config exists
protocols_config = config.get("protocols", {})
print(f"\nConfig protocols: {protocols_config}")

# Test protocol validation
print("\n=== PROTOCOL VALIDATION ===")
print(f"HTTPS allowed: {protocol_manager.is_protocol_allowed('https')}")
print(f"HTTP allowed: {protocol_manager.is_protocol_allowed('http')}")

# Create new protocol manager instance
from mcp_proxy_adapter.core.protocol_manager import ProtocolManager  # noqa: E402

new_protocol_manager = ProtocolManager()

print("\n=== NEW PROTOCOL MANAGER ===")
print(f"New protocol manager enabled: {new_protocol_manager.enabled}")
print(
    f"New protocol manager allowed_protocols: {new_protocol_manager.allowed_protocols}"
)
print(f"New protocol manager protocols_config: {new_protocol_manager.protocols_config}")
print(f"HTTPS allowed: {new_protocol_manager.is_protocol_allowed('https')}")
print(f"HTTP allowed: {new_protocol_manager.is_protocol_allowed('http')}")
