#!/usr/bin/env python3
"""
Simple HTTP endpoints test.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import asyncio
import aiohttp


async def test_http_endpoints():
    """Test HTTP endpoints."""
    base_url = "http://127.0.0.1:10001"

    print(f"Testing HTTP endpoints at: {base_url}")

    async with aiohttp.ClientSession(
        timeout=aiohttp.ClientTimeout(total=10)
    ) as session:
        # Test health endpoint
        print("\n1. Testing /health endpoint...")
        try:
            async with session.get(f"{base_url}/health") as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"✅ Health endpoint: OK - {data}")
                else:
                    print(f"❌ Health endpoint: HTTP {response.status}")
        except Exception as e:
            print(f"❌ Health endpoint: {e}")

        # Test root endpoint
        print("\n2. Testing / endpoint...")
        try:
            async with session.get(f"{base_url}/") as response:
                print(f"Root endpoint status: {response.status}")
                if response.status == 200:
                    text = await response.text()
                    print(f"✅ Root endpoint: OK - {len(text)} chars")
                else:
                    print(f"❌ Root endpoint: HTTP {response.status}")
        except Exception as e:
            print(f"❌ Root endpoint: {e}")

        # Test docs endpoint
        print("\n3. Testing /docs endpoint...")
        try:
            async with session.get(f"{base_url}/docs") as response:
                if response.status == 200:
                    print("✅ Docs endpoint: OK")
                else:
                    print(f"❌ Docs endpoint: HTTP {response.status}")
        except Exception as e:
            print(f"❌ Docs endpoint: {e}")

        # Test openapi endpoint
        print("\n4. Testing /openapi.json endpoint...")
        try:
            async with session.get(f"{base_url}/openapi.json") as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"✅ OpenAPI endpoint: OK - {len(str(data))} chars")
                else:
                    print(f"❌ OpenAPI endpoint: HTTP {response.status}")
                    text = await response.text()
                    print(f"Error response: {text}")
        except Exception as e:
            print(f"❌ OpenAPI endpoint: {e}")

        # Test models endpoint (if exists)
        print("\n5. Testing /models endpoint...")
        try:
            async with session.get(f"{base_url}/models") as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"✅ Models endpoint: OK - {data}")
                else:
                    print(f"❌ Models endpoint: HTTP {response.status}")
                    text = await response.text()
                    print(f"Error response: {text}")
        except Exception as e:
            print(f"❌ Models endpoint: {e}")

        # Test embed endpoint (if exists)
        print("\n6. Testing /embed endpoint...")
        try:
            payload = {"text": "Hello, world!", "model": "text-embedding-ada-002"}
            async with session.post(f"{base_url}/embed", json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"✅ Embed endpoint: OK - {len(str(data))} chars")
                else:
                    print(f"❌ Embed endpoint: HTTP {response.status}")
                    text = await response.text()
                    print(f"Error response: {text}")
        except Exception as e:
            print(f"❌ Embed endpoint: {e}")


if __name__ == "__main__":
    asyncio.run(test_http_endpoints())
