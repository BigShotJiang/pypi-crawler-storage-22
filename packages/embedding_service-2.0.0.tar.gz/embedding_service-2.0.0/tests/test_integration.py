#!/usr/bin/env python3
"""
Test script for MCP Proxy Adapter integration.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

This script tests the integration with the new mcp_proxy_adapter
including all authentication modes and connection types.
"""

import json
import requests
import time
import sys
from typing import Dict, Any, Optional


class IntegrationTester:
    """
    Test integration with MCP Proxy Adapter.
    """

    def __init__(self, base_url: str = "http://localhost:8001"):
        """
        Initialize tester.

        Args:
            base_url: Base URL of the service
        """
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = []

    def log_test(
        self, test_name: str, success: bool, message: str = "", data: Any = None
    ):
        """
        Log test result.

        Args:
            test_name: Name of the test
            success: Whether test passed
            message: Additional message
            data: Test data
        """
        result = {
            "test": test_name,
            "success": success,
            "message": message,
            "data": data,
            "timestamp": time.time(),
        }
        self.test_results.append(result)

        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")

    def test_health_endpoint(self) -> bool:
        """
        Test health endpoint.

        Returns:
            True if test passed
        """
        try:
            response = self.session.get(f"{self.base_url}/health")
            if response.status_code == 200:
                data = response.json()
                self.log_test(
                    "Health Endpoint", True, f"Status: {data.get('status', 'unknown')}"
                )
                return True
            else:
                self.log_test("Health Endpoint", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Health Endpoint", False, f"Error: {e}")
            return False

    def test_commands_endpoint(self) -> bool:
        """
        Test commands endpoint.

        Returns:
            True if test passed
        """
        try:
            response = self.session.get(f"{self.base_url}/commands")
            if response.status_code == 200:
                data = response.json()
                commands = data.get("commands", [])
                self.log_test(
                    "Commands Endpoint", True, f"Found {len(commands)} commands"
                )
                return True
            else:
                self.log_test(
                    "Commands Endpoint", False, f"HTTP {response.status_code}"
                )
                return False
        except Exception as e:
            self.log_test("Commands Endpoint", False, f"Error: {e}")
            return False

    def test_jsonrpc_embed(self, auth_headers: Optional[Dict[str, str]] = None) -> bool:
        """
        Test JSON-RPC embed command.

        Args:
            auth_headers: Authentication headers

        Returns:
            True if test passed
        """
        try:
            headers = {"Content-Type": "application/json"}
            if auth_headers:
                headers.update(auth_headers)

            payload = {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Hello world", "Test text for embedding"]},
                "id": 1,
            }

            response = self.session.post(
                f"{self.base_url}/jsonrpc", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data:
                    result = data["result"]
                    embeddings = result.get("data", {}).get("results", [])
                    self.log_test(
                        "JSON-RPC Embed",
                        True,
                        f"Generated {len(embeddings)} embeddings",
                    )
                    return True
                else:
                    self.log_test(
                        "JSON-RPC Embed",
                        False,
                        f"Error in response: {data.get('error', 'Unknown error')}",
                    )
                    return False
            else:
                self.log_test("JSON-RPC Embed", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("JSON-RPC Embed", False, f"Error: {e}")
            return False

    def test_jsonrpc_models(
        self, auth_headers: Optional[Dict[str, str]] = None
    ) -> bool:
        """
        Test JSON-RPC models command.

        Args:
            auth_headers: Authentication headers

        Returns:
            True if test passed
        """
        try:
            headers = {"Content-Type": "application/json"}
            if auth_headers:
                headers.update(auth_headers)

            payload = {"jsonrpc": "2.0", "method": "models", "id": 1}

            response = self.session.post(
                f"{self.base_url}/jsonrpc", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data:
                    result = data["result"]
                    models = result.get("data", {}).get("models", [])
                    self.log_test(
                        "JSON-RPC Models", True, f"Found {len(models)} models"
                    )
                    return True
                else:
                    self.log_test(
                        "JSON-RPC Models",
                        False,
                        f"Error in response: {data.get('error', 'Unknown error')}",
                    )
                    return False
            else:
                self.log_test("JSON-RPC Models", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("JSON-RPC Models", False, f"Error: {e}")
            return False

    def test_jsonrpc_help(self, auth_headers: Optional[Dict[str, str]] = None) -> bool:
        """
        Test JSON-RPC help command.

        Args:
            auth_headers: Authentication headers

        Returns:
            True if test passed
        """
        try:
            headers = {"Content-Type": "application/json"}
            if auth_headers:
                headers.update(auth_headers)

            payload = {"jsonrpc": "2.0", "method": "help", "id": 1}

            response = self.session.post(
                f"{self.base_url}/jsonrpc", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data:
                    result = data["result"]
                    help_text = result.get("data", {}).get("help", "")
                    self.log_test(
                        "JSON-RPC Help", True, f"Help text length: {len(help_text)}"
                    )
                    return True
                else:
                    self.log_test(
                        "JSON-RPC Help",
                        False,
                        f"Error in response: {data.get('error', 'Unknown error')}",
                    )
                    return False
            else:
                self.log_test("JSON-RPC Help", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("JSON-RPC Help", False, f"Error: {e}")
            return False

    def test_batch_jsonrpc(self, auth_headers: Optional[Dict[str, str]] = None) -> bool:
        """
        Test batch JSON-RPC requests.

        Args:
            auth_headers: Authentication headers

        Returns:
            True if test passed
        """
        try:
            headers = {"Content-Type": "application/json"}
            if auth_headers:
                headers.update(auth_headers)

            payload = [
                {"jsonrpc": "2.0", "method": "models", "id": 1},
                {"jsonrpc": "2.0", "method": "help", "id": 2},
            ]

            response = self.session.post(
                f"{self.base_url}/jsonrpc/batch", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if isinstance(data, list) and len(data) == 2:
                    self.log_test(
                        "Batch JSON-RPC", True, f"Processed {len(data)} requests"
                    )
                    return True
                else:
                    self.log_test("Batch JSON-RPC", False, "Invalid response format")
                    return False
            else:
                self.log_test("Batch JSON-RPC", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Batch JSON-RPC", False, f"Error: {e}")
            return False

    def test_api_key_auth(self) -> bool:
        """
        Test API key authentication.

        Returns:
            True if test passed
        """
        try:
            headers = {"X-API-Key": "admin-secret-key"}
            return self.test_jsonrpc_embed(headers)
        except Exception as e:
            self.log_test("API Key Auth", False, f"Error: {e}")
            return False

    def test_basic_auth(self) -> bool:
        """
        Test basic authentication.

        Returns:
            True if test passed
        """
        try:
            from requests.auth import HTTPBasicAuth

            auth = HTTPBasicAuth("admin", "admin-password")

            # Override session auth for this test
            original_auth = self.session.auth
            self.session.auth = auth

            result = self.test_jsonrpc_embed()

            # Restore original auth
            self.session.auth = original_auth

            return result
        except Exception as e:
            self.log_test("Basic Auth", False, f"Error: {e}")
            return False

    def test_ssl_connection(self) -> bool:
        """
        Test SSL connection (if available).

        Returns:
            True if test passed
        """
        try:
            # Try HTTPS version
            https_url = self.base_url.replace("http://", "https://")
            https_tester = IntegrationTester(https_url)

            # Test basic functionality
            health_result = https_tester.test_health_endpoint()
            if health_result:
                self.log_test("SSL Connection", True, "HTTPS connection successful")
                return True
            else:
                self.log_test("SSL Connection", False, "HTTPS connection failed")
                return False
        except Exception as e:
            self.log_test("SSL Connection", False, f"Error: {e}")
            return False

    def run_all_tests(self) -> Dict[str, Any]:
        """
        Run all integration tests.

        Returns:
            Test results summary
        """
        print("🚀 Starting MCP Proxy Adapter Integration Tests")
        print("=" * 60)

        # Basic functionality tests
        self.test_health_endpoint()
        self.test_commands_endpoint()

        # JSON-RPC tests
        self.test_jsonrpc_embed()
        self.test_jsonrpc_models()
        self.test_jsonrpc_help()
        self.test_batch_jsonrpc()

        # Authentication tests
        self.test_api_key_auth()
        self.test_basic_auth()

        # SSL tests
        self.test_ssl_connection()

        # Calculate summary
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["success"])
        failed_tests = total_tests - passed_tests

        summary = {
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "success_rate": (
                (passed_tests / total_tests * 100) if total_tests > 0 else 0
            ),
            "results": self.test_results,
        }

        print("\n" + "=" * 60)
        print("📊 TEST SUMMARY")
        print("=" * 60)
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {failed_tests}")
        print(f"Success Rate: {summary['success_rate']:.1f}%")

        if failed_tests > 0:
            print("\n❌ FAILED TESTS:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  - {result['test']}: {result['message']}")

        return summary

    def save_results(self, filename: str = "integration_test_results.json"):
        """
        Save test results to file.

        Args:
            filename: Output filename
        """
        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(self.test_results, f, indent=2, ensure_ascii=False)
            print(f"\n💾 Test results saved to: {filename}")
        except Exception as e:
            print(f"\n❌ Failed to save results: {e}")


def main():
    """
    Main function.
    """
    import argparse

    parser = argparse.ArgumentParser(description="Test MCP Proxy Adapter Integration")
    parser.add_argument(
        "--url",
        default="http://localhost:8001",
        help="Base URL of the service (default: http://localhost:8001)",
    )
    parser.add_argument(
        "--output",
        default="integration_test_results.json",
        help="Output file for test results (default: integration_test_results.json)",
    )

    args = parser.parse_args()

    # Create tester
    tester = IntegrationTester(args.url)

    # Run tests
    summary = tester.run_all_tests()

    # Save results
    tester.save_results(args.output)

    # Exit with appropriate code
    if summary["failed_tests"] > 0:
        print(f"\n❌ Integration tests failed: {summary['failed_tests']} failures")
        sys.exit(1)
    else:
        print("\n✅ All integration tests passed!")
        sys.exit(0)


if __name__ == "__main__":
    main()
