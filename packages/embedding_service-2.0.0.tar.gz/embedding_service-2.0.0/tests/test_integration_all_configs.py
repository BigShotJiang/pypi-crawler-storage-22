#!/usr/bin/env python3
"""
Integration testing script for all embedding service configurations.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import asyncio
import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, Any

import aiohttp
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class IntegrationTester:
    """Integration tester for embedding service configurations."""

    def __init__(self, config_dir: str = "config"):
        self.config_dir = Path(config_dir)
        self.results = {}
        self.test_commands = ["list_models", "embed_text", "embed_batch"]

    def load_config(self, config_file: str) -> Dict[str, Any]:
        """Load configuration from file."""
        config_path = self.config_dir / config_file
        with open(config_path, "r") as f:
            return json.load(f)

    async def test_config_with_mcp(self, config_file: str) -> Dict[str, Any]:
        """Test configuration using MCP client."""
        config = self.load_config(config_file)
        result = {
            "config_file": config_file,
            "status": "failed",
            "error": None,
            "commands_tested": {},
            "start_time": time.time(),
            "end_time": None,
        }

        try:
            logger.info(f"Testing configuration: {config_file}")

            # Extract server command from config
            server_cmd = config.get("server", {}).get("command", [])
            if not server_cmd:
                raise ValueError("No server command found in config")

            # Create server parameters
            server_params = StdioServerParameters(
                command=server_cmd[0],
                args=server_cmd[1:] if len(server_cmd) > 1 else [],
                env=config.get("server", {}).get("env", {}),
            )

            # Test MCP connection
            async with stdio_client(server_params) as (read, write):
                async with ClientSession(read, write) as session:
                    # Initialize session
                    await session.initialize()

                    # Test each command
                    for command in self.test_commands:
                        try:
                            if command == "list_models":
                                response = await session.call_tool("list_models", {})
                                result["commands_tested"][command] = {
                                    "status": "success",
                                    "response": str(response.content),
                                }
                            elif command == "embed_text":
                                response = await session.call_tool(
                                    "embed_text",
                                    {
                                        "text": "Hello, world!",
                                        "model": "text-embedding-ada-002",
                                    },
                                )
                                result["commands_tested"][command] = {
                                    "status": "success",
                                    "response": str(response.content),
                                }
                            elif command == "embed_batch":
                                response = await session.call_tool(
                                    "embed_batch",
                                    {
                                        "texts": ["Hello", "World", "Test"],
                                        "model": "text-embedding-ada-002",
                                    },
                                )
                                result["commands_tested"][command] = {
                                    "status": "success",
                                    "response": str(response.content),
                                }
                        except Exception as e:
                            result["commands_tested"][command] = {
                                "status": "failed",
                                "error": str(e),
                            }

                    result["status"] = "success"

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Error testing {config_file}: {e}")

        result["end_time"] = time.time()
        result["duration"] = result["end_time"] - result["start_time"]

        return result

    async def test_config_with_http(self, config_file: str) -> Dict[str, Any]:
        """Test configuration using HTTP client."""
        config = self.load_config(config_file)
        result = {
            "config_file": config_file,
            "status": "failed",
            "error": None,
            "commands_tested": {},
            "start_time": time.time(),
            "end_time": None,
        }

        try:
            logger.info(f"Testing HTTP configuration: {config_file}")

            # Extract HTTP settings
            http_config = config.get("protocols", {}).get("http", {})
            host = http_config.get("host", "localhost")
            port = http_config.get("port", 8000)
            base_url = f"http://{host}:{port}"

            # Test HTTP endpoints
            async with aiohttp.ClientSession() as session:
                # Test health endpoint
                try:
                    async with session.get(f"{base_url}/health") as response:
                        if response.status == 200:
                            result["commands_tested"]["health"] = {
                                "status": "success",
                                "response": await response.text(),
                            }
                        else:
                            result["commands_tested"]["health"] = {
                                "status": "failed",
                                "error": f"HTTP {response.status}",
                            }
                except Exception as e:
                    result["commands_tested"]["health"] = {
                        "status": "failed",
                        "error": str(e),
                    }

                # Test models endpoint
                try:
                    async with session.get(f"{base_url}/models") as response:
                        if response.status == 200:
                            result["commands_tested"]["models"] = {
                                "status": "success",
                                "response": await response.text(),
                            }
                        else:
                            result["commands_tested"]["models"] = {
                                "status": "failed",
                                "error": f"HTTP {response.status}",
                            }
                except Exception as e:
                    result["commands_tested"]["models"] = {
                        "status": "failed",
                        "error": str(e),
                    }

                # Test embed endpoint
                try:
                    payload = {
                        "text": "Hello, world!",
                        "model": "text-embedding-ada-002",
                    }
                    async with session.post(
                        f"{base_url}/embed", json=payload
                    ) as response:
                        if response.status == 200:
                            result["commands_tested"]["embed"] = {
                                "status": "success",
                                "response": await response.text(),
                            }
                        else:
                            result["commands_tested"]["embed"] = {
                                "status": "failed",
                                "error": f"HTTP {response.status}",
                            }
                except Exception as e:
                    result["commands_tested"]["embed"] = {
                        "status": "failed",
                        "error": str(e),
                    }

            result["status"] = "success"

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Error testing HTTP {config_file}: {e}")

        result["end_time"] = time.time()
        result["duration"] = result["end_time"] - result["start_time"]

        return result

    async def run_all_tests(self) -> Dict[str, Any]:
        """Run tests for all configurations."""
        config_files = [
            "http_simple.json",
            "http_token.json",
            "https_simple.json",
            "https_token.json",
            "mtls_simple.json",
            "mtls_roles.json",
        ]

        logger.info(
            f"Starting integration tests for {len(config_files)} configurations"
        )

        for config_file in config_files:
            if config_file.startswith("http"):
                result = await self.test_config_with_http(config_file)
            else:
                result = await self.test_config_with_mcp(config_file)

            self.results[config_file] = result

            # Log result
            status = result["status"]
            duration = result.get("duration", 0)
            logger.info(f"{config_file}: {status} ({duration:.2f}s)")

        return self.results

    def generate_report(self) -> str:
        """Generate test report."""
        total_configs = len(self.results)
        successful_configs = sum(
            1 for r in self.results.values() if r["status"] == "success"
        )

        report = f"""
# Integration Test Report

**Author:** Vasiliy Zdanovskiy
**Email:** vasilyvz@gmail.com
**Date:** {time.strftime('%Y-%m-%d %H:%M:%S')}

## Summary

- **Total Configurations:** {total_configs}
- **Successful:** {successful_configs}
- **Failed:** {total_configs - successful_configs}
- **Success Rate:** {(successful_configs/total_configs)*100:.1f}%

## Detailed Results

"""

        for config_file, result in self.results.items():
            status = result["status"]
            duration = result.get("duration", 0)
            error = result.get("error")

            report += f"### {config_file}\n"
            report += f"- **Status:** {status}\n"
            report += f"- **Duration:** {duration:.2f}s\n"

            if error:
                report += f"- **Error:** {error}\n"

            if result.get("commands_tested"):
                report += "- **Commands Tested:**\n"
                for cmd, cmd_result in result["commands_tested"].items():
                    cmd_status = cmd_result["status"]
                    report += f"  - {cmd}: {cmd_status}\n"

            report += "\n"

        return report


async def main():
    """Main function."""
    tester = IntegrationTester()

    try:
        results = await tester.run_all_tests()
        report = tester.generate_report()

        # Save report
        with open("integration_test_report.md", "w") as f:
            f.write(report)

        # Save results as JSON
        with open("integration_test_results.json", "w") as f:
            json.dump(results, f, indent=2, default=str)

        print(report)

        # Exit with error if any config failed
        failed_configs = sum(1 for r in results.values() if r["status"] != "success")
        if failed_configs > 0:
            sys.exit(1)

    except Exception as e:
        logger.error(f"Integration test failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
