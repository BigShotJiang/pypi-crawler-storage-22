#!/usr/bin/env python3
"""
Simple integration testing script for HTTP configurations.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import asyncio
import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, Any

import aiohttp

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SimpleIntegrationTester:
    """Simple integration tester for HTTP configurations."""

    def __init__(self, config_dir: str = "config"):
        self.config_dir = Path(config_dir)
        self.results = {}

    def load_config(self, config_file: str) -> Dict[str, Any]:
        """Load configuration from file."""
        config_path = self.config_dir / config_file
        with open(config_path, "r") as f:
            return json.load(f)

    async def test_http_config(self, config_file: str) -> Dict[str, Any]:
        """Test HTTP configuration."""
        config = self.load_config(config_file)
        result = {
            "config_file": config_file,
            "status": "failed",
            "error": None,
            "endpoints_tested": {},
            "start_time": time.time(),
            "end_time": None,
        }

        try:
            logger.info(f"Testing HTTP configuration: {config_file}")

            # Extract HTTP settings
            http_config = config.get("protocols", {}).get("http", {})
            host = http_config.get("host", "127.0.0.1")
            port = http_config.get("port", 8000)
            base_url = f"http://{host}:{port}"

            logger.info(f"Testing endpoints at: {base_url}")

            # Test HTTP endpoints
            async with aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=10)
            ) as session:
                # Test health endpoint
                try:
                    async with session.get(f"{base_url}/health") as response:
                        if response.status == 200:
                            result["endpoints_tested"]["health"] = {
                                "status": "success",
                                "response": await response.text(),
                            }
                            logger.info("✅ Health endpoint: OK")
                        else:
                            result["endpoints_tested"]["health"] = {
                                "status": "failed",
                                "error": f"HTTP {response.status}",
                            }
                            logger.error(f"❌ Health endpoint: HTTP {response.status}")
                except Exception as e:
                    result["endpoints_tested"]["health"] = {
                        "status": "failed",
                        "error": str(e),
                    }
                    logger.error(f"❌ Health endpoint: {e}")

                # Test models endpoint
                try:
                    async with session.get(f"{base_url}/models") as response:
                        if response.status == 200:
                            result["endpoints_tested"]["models"] = {
                                "status": "success",
                                "response": await response.text(),
                            }
                            logger.info("✅ Models endpoint: OK")
                        else:
                            result["endpoints_tested"]["models"] = {
                                "status": "failed",
                                "error": f"HTTP {response.status}",
                            }
                            logger.error(f"❌ Models endpoint: HTTP {response.status}")
                except Exception as e:
                    result["endpoints_tested"]["models"] = {
                        "status": "failed",
                        "error": str(e),
                    }
                    logger.error(f"❌ Models endpoint: {e}")

                # Test embed endpoint
                try:
                    payload = {
                        "text": "Hello, world!",
                        "model": "text-embedding-ada-002",
                    }
                    async with session.post(
                        f"{base_url}/embed", json=payload
                    ) as response:
                        if response.status == 200:
                            result["endpoints_tested"]["embed"] = {
                                "status": "success",
                                "response": await response.text(),
                            }
                            logger.info("✅ Embed endpoint: OK")
                        else:
                            result["endpoints_tested"]["embed"] = {
                                "status": "failed",
                                "error": f"HTTP {response.status}",
                            }
                            logger.error(f"❌ Embed endpoint: HTTP {response.status}")
                except Exception as e:
                    result["endpoints_tested"]["embed"] = {
                        "status": "failed",
                        "error": str(e),
                    }
                    logger.error(f"❌ Embed endpoint: {e}")

            # Check if at least one endpoint worked
            successful_endpoints = sum(
                1
                for ep in result["endpoints_tested"].values()
                if ep["status"] == "success"
            )

            if successful_endpoints > 0:
                result["status"] = "success"
                logger.info(
                    f"✅ {config_file}: {successful_endpoints}/3 endpoints working"
                )
            else:
                result["status"] = "failed"
                logger.error(f"❌ {config_file}: No endpoints working")

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Error testing {config_file}: {e}")

        result["end_time"] = time.time()
        result["duration"] = result["end_time"] - result["start_time"]

        return result

    async def run_http_tests(self) -> Dict[str, Any]:
        """Run tests for HTTP configurations."""
        http_config_files = ["http_simple.json", "http_token.json"]

        logger.info(
            "Starting HTTP integration tests for %s configurations",
            len(http_config_files),
        )

        for config_file in http_config_files:
            result = await self.test_http_config(config_file)
            self.results[config_file] = result

            # Log result
            status = result["status"]
            duration = result.get("duration", 0)
            logger.info(f"{config_file}: {status} ({duration:.2f}s)")

        return self.results

    def generate_report(self) -> str:
        """Generate test report."""
        total_configs = len(self.results)
        successful_configs = sum(
            1 for r in self.results.values() if r["status"] == "success"
        )

        report = f"""
# HTTP Integration Test Report

**Author:** Vasiliy Zdanovskiy
**Email:** vasilyvz@gmail.com
**Date:** {time.strftime('%Y-%m-%d %H:%M:%S')}

## Summary

- **Total HTTP Configurations:** {total_configs}
- **Successful:** {successful_configs}
- **Failed:** {total_configs - successful_configs}
- **Success Rate:** {(successful_configs/total_configs)*100:.1f}%

## Detailed Results

"""

        for config_file, result in self.results.items():
            status = result["status"]
            duration = result.get("duration", 0)
            error = result.get("error")

            report += f"### {config_file}\n"
            report += f"- **Status:** {status}\n"
            report += f"- **Duration:** {duration:.2f}s\n"

            if error:
                report += f"- **Error:** {error}\n"

            if result.get("endpoints_tested"):
                report += "- **Endpoints Tested:**\n"
                for endpoint, endpoint_result in result["endpoints_tested"].items():
                    endpoint_status = endpoint_result["status"]
                    report += f"  - {endpoint}: {endpoint_status}\n"

            report += "\n"

        return report


async def main():
    """Main function."""
    tester = SimpleIntegrationTester()

    try:
        results = await tester.run_http_tests()
        report = tester.generate_report()

        # Save report
        with open("http_integration_test_report.md", "w") as f:
            f.write(report)

        # Save results as JSON
        with open("http_integration_test_results.json", "w") as f:
            json.dump(results, f, indent=2, default=str)

        print(report)

        # Exit with error if any config failed
        failed_configs = sum(1 for r in results.values() if r["status"] != "success")
        if failed_configs > 0:
            sys.exit(1)

    except Exception as e:
        logger.error(f"Integration test failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
