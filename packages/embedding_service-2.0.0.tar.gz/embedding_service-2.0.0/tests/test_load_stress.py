#!/usr/bin/env python3
"""
Comprehensive load and stress tests for embedding service.

Tests:
1. Sequential processing (max_concurrent_jobs=1) to avoid GPU overload
2. Device auto-detection for each request
3. GPU to CPU fallback on errors
4. High load with many requests
5. Batch processing performance

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio
import time
import aiohttp
import statistics
from typing import List, Dict, Any, Optional


class LoadTestClient:
    """Client for load testing embedding service."""

    def __init__(self, base_url: str = "http://127.0.0.1:8000", timeout: float = 300.0):
        self.base_url = base_url
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        self.session = aiohttp.ClientSession(timeout=self.timeout)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()

    async def health_check(self) -> Dict[str, Any]:
        """Check service health."""
        async with self.session.get(f"{self.base_url}/health") as resp:
            return await resp.json()

    async def embed_request(
        self,
        texts: List[str],
        device: str = "auto",
        model: Optional[str] = None,
        dimension: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Send embed request.

        Returns:
            Dict with job_id or result
        """
        payload = {
            "jsonrpc": "2.0",
            "method": "embed",
            "params": {
                "texts": texts,
                "device": device,
            },
            "id": 1,
        }

        if model:
            payload["params"]["model"] = model
        if dimension:
            payload["params"]["dimension"] = dimension

        async with self.session.post(
            f"{self.base_url}/api/jsonrpc", json=payload
        ) as resp:
            return await resp.json()

    async def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Get job status."""
        payload = {
            "jsonrpc": "2.0",
            "method": "embed_job_status",
            "params": {"job_id": job_id},
            "id": 1,
        }

        async with self.session.post(
            f"{self.base_url}/api/jsonrpc", json=payload
        ) as resp:
            return await resp.json()

    async def wait_for_job(
        self, job_id: str, max_wait: float = 300.0, poll_interval: float = 0.5
    ) -> Dict[str, Any]:
        """Wait for job completion."""
        start_time = time.time()

        while time.time() - start_time < max_wait:
            status = await self.get_job_status(job_id)

            if "result" in status:
                result = status["result"]
                if isinstance(result, dict):
                    if result.get("success"):
                        data = result.get("data", {})
                        if "results" in data or "embeddings" in data:
                            return status
                    elif result.get("status") in ("pending", "running"):
                        await asyncio.sleep(poll_interval)
                        continue
                    else:
                        return status

            await asyncio.sleep(poll_interval)

        raise TimeoutError(f"Job {job_id} did not complete within {max_wait}s")


class LoadTestResults:
    """Container for test results."""

    def __init__(self):
        self.results: List[Dict[str, Any]] = []
        self.errors: List[Dict[str, Any]] = []
        self.timings: List[float] = []
        self.device_usage: Dict[str, int] = {}

    def add_result(self, result: Dict[str, Any], timing: float):
        """Add successful result."""
        self.results.append(result)
        self.timings.append(timing)

        # Track device usage
        if "result" in result:
            data = result["result"].get("data", {})
            device = data.get("device", "unknown")
            self.device_usage[device] = self.device_usage.get(device, 0) + 1

    def add_error(self, error: Dict[str, Any], timing: float):
        """Add error result."""
        self.errors.append({"error": error, "timing": timing})

    def get_stats(self) -> Dict[str, Any]:
        """Get statistics."""
        if not self.timings:
            return {"error": "No successful requests"}

        return {
            "total_requests": len(self.results) + len(self.errors),
            "successful": len(self.results),
            "failed": len(self.errors),
            "success_rate": (
                len(self.results) / (len(self.results) + len(self.errors)) * 100
                if (len(self.results) + len(self.errors)) > 0
                else 0
            ),
            "timings": {
                "min": min(self.timings),
                "max": max(self.timings),
                "mean": statistics.mean(self.timings),
                "median": statistics.median(self.timings),
                "stdev": statistics.stdev(self.timings) if len(self.timings) > 1 else 0,
            },
            "device_usage": self.device_usage,
        }


async def test_sequential_processing(client: LoadTestClient, num_requests: int = 10):
    """
    Test 1: Sequential processing with max_concurrent_jobs=1.

    This test verifies that requests are processed one at a time,
    preventing GPU overload.
    """
    print(f"\n{'='*60}")
    print("TEST 1: Sequential Processing (max_concurrent_jobs=1)")
    print(f"{'='*60}")
    print(f"Sending {num_requests} requests sequentially...")

    results = LoadTestResults()
    texts = [f"Test text {i} for sequential processing" for i in range(5)]

    start_total = time.time()

    for i in range(num_requests):
        request_start = time.time()
        try:
            # Send request
            response = await client.embed_request(texts, device="auto")

            # Extract job_id
            if "result" in response and isinstance(response["result"], dict):
                job_id = response["result"].get("job_id")
                if not job_id:
                    # Check if result is already complete
                    if "data" in response["result"]:
                        timing = time.time() - request_start
                        results.add_result(response, timing)
                        print(f"  Request {i+1}/{num_requests}: ✅ {timing:.2f}s")
                        continue

                # Wait for completion
                result = await client.wait_for_job(job_id, max_wait=300.0)
                timing = time.time() - request_start
                results.add_result(result, timing)
                print(f"  Request {i+1}/{num_requests}: ✅ {timing:.2f}s")
            else:
                timing = time.time() - request_start
                results.add_error(response, timing)
                print(f"  Request {i+1}/{num_requests}: ❌ {timing:.2f}s")

        except Exception as e:
            timing = time.time() - request_start
            results.add_error({"error": str(e)}, timing)
            print(f"  Request {i+1}/{num_requests}: ❌ {timing:.2f}s - {e}")

    total_time = time.time() - start_total

    stats = results.get_stats()
    print("\nResults:")
    print(f"  Total time: {total_time:.2f}s")
    print(f"  Success rate: {stats['success_rate']:.1f}%")
    print(f"  Avg time per request: {stats['timings']['mean']:.2f}s")
    print(f"  Device usage: {stats['device_usage']}")

    return results


async def test_device_auto_detection(client: LoadTestClient, num_requests: int = 5):
    """
    Test 2: Device auto-detection for each request.

    Verifies that device is determined correctly for each request.
    """
    print(f"\n{'='*60}")
    print("TEST 2: Device Auto-Detection")
    print(f"{'='*60}")

    results = LoadTestResults()
    texts = ["Test text for device detection"]

    devices_to_test = ["auto", "cpu", "cuda"]

    for device in devices_to_test:
        print(f"\nTesting device='{device}'...")
        request_start = time.time()

        try:
            response = await client.embed_request(texts, device=device)

            if "result" in response and isinstance(response["result"], dict):
                job_id = response["result"].get("job_id")
                if job_id:
                    result = await client.wait_for_job(job_id, max_wait=300.0)
                else:
                    result = response

                timing = time.time() - request_start
                results.add_result(result, timing)

                # Extract device from result
                if "result" in result:
                    data = result["result"].get("data", {})
                    actual_device = data.get("device", "unknown")
                    msg = (
                        f"  Requested: {device}, Actual: {actual_device}, "
                        f"Time: {timing:.2f}s"
                    )
                    print(msg)
            else:
                timing = time.time() - request_start
                results.add_error(response, timing)
                print(f"  ❌ Error: {response}")

        except Exception as e:
            timing = time.time() - request_start
            results.add_error({"error": str(e)}, timing)
            print(f"  ❌ Exception: {e}")

    stats = results.get_stats()
    print("\nResults:")
    print(f"  Success rate: {stats['success_rate']:.1f}%")
    print(f"  Device usage: {stats['device_usage']}")

    return results


async def test_high_load(
    client: LoadTestClient, num_requests: int = 50, concurrent: int = 5
):
    """
    Test 3: High load with concurrent requests.

    Even with max_concurrent_jobs=1, we can send many requests.
    They will be queued and processed sequentially.
    """
    print(f"\n{'='*60}")
    print(f"TEST 3: High Load ({num_requests} requests, {concurrent} concurrent)")
    print(f"{'='*60}")

    results = LoadTestResults()
    texts = [f"High load test text {i}" for i in range(3)]

    async def send_request(request_id: int):
        """Send a single request."""
        request_start = time.time()
        try:
            response = await client.embed_request(texts, device="auto")

            if "result" in response and isinstance(response["result"], dict):
                job_id = response["result"].get("job_id")
                if job_id:
                    result = await client.wait_for_job(job_id, max_wait=300.0)
                else:
                    result = response

                timing = time.time() - request_start
                results.add_result(result, timing)
                return True
            else:
                timing = time.time() - request_start
                results.add_error(response, timing)
                return False

        except Exception as e:
            timing = time.time() - request_start
            results.add_error({"error": str(e)}, timing)
            return False

    # Send requests in batches
    start_total = time.time()
    completed = 0

    for batch_start in range(0, num_requests, concurrent):
        batch_end = min(batch_start + concurrent, num_requests)
        batch_size = batch_end - batch_start

        print(
            f"  Sending batch {batch_start//concurrent + 1} ({batch_size} requests)..."
        )

        tasks = [send_request(i) for i in range(batch_start, batch_end)]

        batch_results = await asyncio.gather(*tasks, return_exceptions=True)
        completed += sum(1 for r in batch_results if r is True)

        print(f"    Completed: {completed}/{num_requests}")

    total_time = time.time() - start_total

    stats = results.get_stats()
    print("\nResults:")
    print(f"  Total time: {total_time:.2f}s")
    print(f"  Requests per second: {num_requests / total_time:.2f}")
    print(f"  Success rate: {stats['success_rate']:.1f}%")
    print(f"  Avg time per request: {stats['timings']['mean']:.2f}s")
    min_max = f"{stats['timings']['min']:.2f}s / {stats['timings']['max']:.2f}s"
    print(f"  Min/Max time: {min_max}")
    print(f"  Device usage: {stats['device_usage']}")

    return results


async def test_batch_processing(
    client: LoadTestClient, batch_sizes: List[int] = [1, 5, 10, 20]
):
    """
    Test 4: Batch processing with different batch sizes.
    """
    print(f"\n{'='*60}")
    print("TEST 4: Batch Processing Performance")
    print(f"{'='*60}")

    results_by_batch = {}

    for batch_size in batch_sizes:
        print(f"\nTesting batch size: {batch_size}...")
        texts = [f"Batch test text {i}" for i in range(batch_size)]

        request_start = time.time()
        try:
            response = await client.embed_request(texts, device="auto")

            if "result" in response and isinstance(response["result"], dict):
                job_id = response["result"].get("job_id")
                if job_id:
                    result = await client.wait_for_job(job_id, max_wait=300.0)
                else:
                    result = response

                timing = time.time() - request_start

                if "result" in result:
                    data = result["result"].get("data", {})
                    num_results = len(data.get("results", data.get("embeddings", [])))
                    time_per_text = timing / batch_size if batch_size > 0 else timing

                    results_by_batch[batch_size] = {
                        "total_time": timing,
                        "time_per_text": time_per_text,
                        "num_results": num_results,
                        "success": True,
                    }

                    print(
                        f"  ✅ Total: {timing:.2f}s, Per text: {time_per_text:.3f}s, "
                        f"Results: {num_results}"
                    )
            else:
                timing = time.time() - request_start
                results_by_batch[batch_size] = {
                    "total_time": timing,
                    "success": False,
                    "error": response,
                }
                print(f"  ❌ Error: {response}")

        except Exception as e:
            timing = time.time() - request_start
            results_by_batch[batch_size] = {
                "total_time": timing,
                "success": False,
                "error": str(e),
            }
            print(f"  ❌ Exception: {e}")

    print("\nBatch Processing Summary:")
    for batch_size, result in results_by_batch.items():
        if result.get("success"):
            print(
                f"  Batch {batch_size}: {result['total_time']:.2f}s total, "
                f"{result['time_per_text']:.3f}s per text"
            )
        else:
            print(f"  Batch {batch_size}: ❌ Failed")

    return results_by_batch


async def test_gpu_fallback(client: LoadTestClient):
    """
    Test 5: GPU to CPU fallback on errors.

    This test verifies that if GPU fails, system falls back to CPU.
    """
    print(f"\n{'='*60}")
    print("TEST 5: GPU to CPU Fallback")
    print(f"{'='*60}")

    texts = ["Test text for GPU fallback"]

    # Test with auto device (should handle fallback automatically)
    print("\nTesting device='auto' (should auto-fallback on GPU errors)...")
    request_start = time.time()

    try:
        response = await client.embed_request(texts, device="auto")

        if "result" in response and isinstance(response["result"], dict):
            job_id = response["result"].get("job_id")
            if job_id:
                result = await client.wait_for_job(job_id, max_wait=300.0)
            else:
                result = response

            timing = time.time() - request_start

            if "result" in result:
                data = result["result"].get("data", {})
                device = data.get("device", "unknown")
                print(f"  ✅ Completed in {timing:.2f}s on device: {device}")

                # Check if fallback occurred
                if "cpu" in device.lower():
                    print("  ℹ️  Using CPU (GPU fallback or no GPU)")
                else:
                    print(f"  ℹ️  Using GPU: {device}")

                return True
    except Exception as e:
        timing = time.time() - request_start
        print(f"  ❌ Failed after {timing:.2f}s: {e}")
        return False

    return False


async def main():
    """Run all load tests."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Load and stress tests for embedding service"
    )
    parser.add_argument("--url", default="http://127.0.0.1:8000", help="Service URL")
    parser.add_argument(
        "--test",
        choices=["all", "sequential", "device", "load", "batch", "fallback"],
        default="all",
        help="Test to run",
    )
    parser.add_argument(
        "--num-requests", type=int, default=10, help="Number of requests for load test"
    )
    parser.add_argument(
        "--concurrent", type=int, default=5, help="Concurrent requests for load test"
    )

    args = parser.parse_args()

    print("=" * 60)
    print("EMBEDDING SERVICE LOAD & STRESS TESTS")
    print("=" * 60)
    print(f"Service URL: {args.url}")
    print(f"Test: {args.test}")
    print()

    async with LoadTestClient(args.url) as client:
        # Health check
        print("Checking service health...")
        try:
            health = await client.health_check()
            print(f"✅ Service is healthy: {health}")
        except Exception as e:
            print(f"❌ Service health check failed: {e}")
            print("Make sure the service is running!")
            return

        # Run tests
        if args.test in ("all", "sequential"):
            await test_sequential_processing(client, num_requests=args.num_requests)

        if args.test in ("all", "device"):
            await test_device_auto_detection(client)

        if args.test in ("all", "load"):
            await test_high_load(
                client, num_requests=args.num_requests, concurrent=args.concurrent
            )

        if args.test in ("all", "batch"):
            await test_batch_processing(client)

        if args.test in ("all", "fallback"):
            await test_gpu_fallback(client)

    print(f"\n{'='*60}")
    print("ALL TESTS COMPLETED")
    print(f"{'='*60}")


if __name__ == "__main__":
    asyncio.run(main())
