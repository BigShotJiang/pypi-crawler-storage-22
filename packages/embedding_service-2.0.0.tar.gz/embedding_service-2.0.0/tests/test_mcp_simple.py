#!/usr/bin/env python3
"""
Simple MCP protocol test.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import asyncio
import sys
from pathlib import Path

# Add parent directory to import path
sys.path.insert(0, str(Path(__file__).parent))

from mcp import ClientSession, StdioServerParameters  # noqa: E402
from mcp.client.stdio import stdio_client  # noqa: E402


async def test_mcp_connection():
    """Test MCP connection to the server."""
    print("Testing MCP connection...")

    # Server parameters
    server_params = StdioServerParameters(
        command="python",
        args=["-m", "embed.main", "--config", "config/local_http.json"],
        env={},
    )

    try:
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                print("✅ Connected to server")

                # Initialize session
                await session.initialize()
                print("✅ Session initialized")

                # List tools
                tools = await session.list_tools()
                print(f"✅ Available tools: {len(tools.tools)}")
                for tool in tools.tools:
                    print(f"  - {tool.name}: {tool.description}")

                # Test list_models command
                try:
                    response = await session.call_tool("list_models", {})
                    print(f"✅ list_models response: {response.content}")
                except Exception as e:
                    print(f"❌ list_models failed: {e}")

                # Test embed_text command
                try:
                    response = await session.call_tool(
                        "embed_text",
                        {"text": "Hello, world!", "model": "text-embedding-ada-002"},
                    )
                    print(f"✅ embed_text response: {response.content}")
                except Exception as e:
                    print(f"❌ embed_text failed: {e}")

    except Exception as e:
        print(f"❌ MCP connection failed: {e}")
        return False

    return True


if __name__ == "__main__":
    success = asyncio.run(test_mcp_connection())
    sys.exit(0 if success else 1)
