"""
Performance and stability tests for embedding service.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import pytest
import asyncio
import time


class TestPerformance:
    """Tests for performance and stability."""

    @pytest.mark.asyncio
    async def test_concurrent_requests(self, client):
        """Test handling of concurrent requests."""
        num_requests = 10
        texts = ["Test text" for _ in range(5)]

        async def make_request():
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": texts},
                    "id": 1,
                },
            )
            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            assert len(result["result"]["data"]["embeddings"]) == len(texts)

        tasks = [make_request() for _ in range(num_requests)]
        await asyncio.gather(*tasks)

    @pytest.mark.asyncio
    async def test_request_timing(self, client):
        """Test request timing and response times."""
        texts = ["Test text" for _ in range(10)]
        num_requests = 5
        timings = []

        for _ in range(num_requests):
            start_time = time.time()
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": texts},
                    "id": 1,
                },
            )
            end_time = time.time()
            timings.append(end_time - start_time)

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            assert len(result["result"]["data"]["embeddings"]) == len(texts)

        avg_time = sum(timings) / len(timings)
        assert avg_time < 1.0  # Average response time should be under 1 second

    @pytest.mark.asyncio
    async def test_memory_usage(self, client):
        """Test memory usage with large batches."""
        # Generate a large batch of texts
        texts = ["Test text " + str(i) for i in range(100)]

        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": texts},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "data" in result["result"]
        assert "embeddings" in result["result"]["data"]
        assert len(result["result"]["data"]["embeddings"]) == len(texts)

    @pytest.mark.asyncio
    async def test_error_recovery(self, client):
        """Test recovery after error conditions."""
        # First make an invalid request
        error_response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": []},
                "id": 1,
            },
        )

        assert error_response.status_code == 200
        error_result = error_response.json()
        assert "result" in error_result
        assert "error" in error_result["result"]

        # Then make a valid request - should work
        valid_response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Valid text"]},
                "id": 1,
            },
        )

        assert valid_response.status_code == 200
        valid_result = valid_response.json()
        assert "result" in valid_result
        assert "data" in valid_result["result"]
        assert "embeddings" in valid_result["result"]["data"]

    @pytest.mark.asyncio
    async def test_large_text_processing(self, client):
        """Test processing of large texts."""
        # Create a large text
        large_text = "This is a large text. " * 1000

        response = client.post(
            "/api/jsonrpc",
            json={
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": [large_text]},
                "id": 1,
            },
        )

        assert response.status_code == 200
        result = response.json()
        assert "result" in result
        assert "data" in result["result"]
        assert "embeddings" in result["result"]["data"]
        assert len(result["result"]["data"]["embeddings"]) == 1

    @pytest.mark.asyncio
    async def test_batch_processing_efficiency(self, client):
        """Test efficiency of batch processing."""
        # Test with different batch sizes
        batch_sizes = [1, 5, 10, 20, 50]
        timings = {}

        for batch_size in batch_sizes:
            texts = ["Test text " + str(i) for i in range(batch_size)]
            start_time = time.time()

            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": texts},
                    "id": 1,
                },
            )

            end_time = time.time()
            timings[batch_size] = end_time - start_time

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            assert len(result["result"]["data"]["embeddings"]) == batch_size

        # Verify that larger batches don't take proportionally longer
        # (indicating efficient batch processing)
        for i in range(1, len(batch_sizes)):
            current_size = batch_sizes[i]
            prev_size = batch_sizes[i - 1]
            current_time = timings[current_size]
            prev_time = timings[prev_size]

            # Time increase should be less than size increase
            time_ratio = current_time / prev_time
            size_ratio = current_size / prev_size
            assert time_ratio < size_ratio

    @pytest.mark.asyncio
    async def test_concurrent_model_access(self, client):
        """Test concurrent access to the same model."""
        num_concurrent = 5
        texts = ["Concurrent test text"]

        async def concurrent_request():
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": texts},
                    "id": 1,
                },
            )
            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            return result

        # Run concurrent requests
        tasks = [concurrent_request() for _ in range(num_concurrent)]
        results = await asyncio.gather(*tasks)

        # All results should be successful
        for result in results:
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            assert len(result["result"]["data"]["embeddings"]) == 1

    @pytest.mark.asyncio
    async def test_memory_cleanup(self, client):
        """Test memory cleanup after processing."""
        # Process multiple large batches
        for i in range(5):
            texts = ["Large text " + str(j) * 100 for j in range(20)]

            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": texts},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            assert len(result["result"]["data"]["embeddings"]) == len(texts)

    @pytest.mark.asyncio
    async def test_response_consistency(self, client):
        """Test consistency of responses across multiple requests."""
        text = "Consistency test text"
        responses = []

        # Make multiple identical requests
        for _ in range(10):
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": [text]},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            responses.append(result)

        # All responses should have the same structure
        for response in responses:
            assert "data" in response["result"]
            assert "embeddings" in response["result"]["data"]
            assert "model" in response["result"]["data"]
            assert "dimension" in response["result"]["data"]
            assert len(response["result"]["data"]["embeddings"]) == 1

        # Check that model and dimension are consistent
        first_response = responses[0]["result"]["data"]
        for response in responses[1:]:
            data = response["result"]["data"]
            assert data["model"] == first_response["model"]
            assert data["dimension"] == first_response["dimension"]

    @pytest.mark.asyncio
    async def test_error_handling_performance(self, client):
        """Test performance of error handling."""
        # Test with various error conditions
        error_cases = [
            {"texts": []},  # Empty list
            {"texts": [""]},  # Empty string
            {"texts": ["a" * 10001]},  # Too long
            {"texts": ["text"] * 101},  # Too many texts
        ]

        for error_case in error_cases:
            start_time = time.time()
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": error_case,
                    "id": 1,
                },
            )
            end_time = time.time()

            # Error handling should be fast
            assert end_time - start_time < 0.1

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "error" in result["result"]

    @pytest.mark.asyncio
    async def test_models_endpoint_performance(self, client):
        """Test performance of models endpoint."""
        num_requests = 10
        timings = []

        for _ in range(num_requests):
            start_time = time.time()
            response = client.post(
                "/api/jsonrpc", json={"jsonrpc": "2.0", "method": "models", "id": 1}
            )
            end_time = time.time()
            timings.append(end_time - start_time)

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            assert "models" in result["result"]["data"]

        # Models endpoint should be very fast
        avg_time = sum(timings) / len(timings)
        assert avg_time < 0.1  # Should be under 100ms
