#!/usr/bin/env python3
"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Test script for ProtocolMiddleware debugging.
"""

import sys
from pathlib import Path

# Add parent directory to import path
sys.path.insert(0, str(Path(__file__).parent))

# Import global protocol manager BEFORE loading config
from mcp_proxy_adapter.core.protocol_manager import (  # noqa: E402
    protocol_manager as _global_protocol_manager,
    ProtocolManager,
)

# Ensure we have a usable protocol manager instance even if global is None
protocol_manager = _global_protocol_manager or ProtocolManager()

print("=== BEFORE LOADING CONFIG ===")
print(f"Global protocol manager enabled: {protocol_manager.enabled}")
print(
    f"Global protocol manager allowed_protocols: {protocol_manager.allowed_protocols}"
)
print(f"Global protocol manager protocols_config: {protocol_manager.protocols_config}")

# Load configuration
from mcp_proxy_adapter.config import config  # noqa: E402

config.load_from_file("config/ssl_config.json")
print("\n✅ Loaded configuration from: config/ssl_config.json")

print("\n=== AFTER LOADING CONFIG ===")
print(f"Global protocol manager enabled: {protocol_manager.enabled}")
print(
    f"Global protocol manager allowed_protocols: {protocol_manager.allowed_protocols}"
)
print(f"Global protocol manager protocols_config: {protocol_manager.protocols_config}")

# Check if protocols config exists
protocols_config = config.get("protocols", {})
print(f"\nConfig protocols: {protocols_config}")

# Test protocol validation
print("\n=== PROTOCOL VALIDATION ===")
print(f"HTTPS allowed: {protocol_manager.is_protocol_allowed('https')}")
print(f"HTTP allowed: {protocol_manager.is_protocol_allowed('http')}")

# Check if there's a default protocols configuration
print("\n=== CHECKING FOR DEFAULT PROTOCOLS ===")
all_config = config.get_all()
if "protocols" not in all_config:
    print("No 'protocols' section in config")
else:
    print("'protocols' section found in config")
    print(f"Protocols config: {all_config['protocols']}")

# Check if there's a default protocols configuration in the adapter
print("\n=== CHECKING ADAPTER DEFAULTS ===")
default_config = {
    "server": {"host": "0.0.0.0", "port": 8000},
    "logging": {"level": "INFO"},
    "commands": {"auto_discovery": True},
    "ssl": {"enabled": False},
    "roles": {"enabled": True},
    "transport": {"type": "http"},
    "proxy_registration": {"enabled": False},
    "debug": {"enabled": False},
}

print("Default config sections:")
for key in default_config.keys():
    print(f"  - {key}")

# Check if protocols is missing from defaults
if "protocols" not in default_config:
    print("'protocols' section is MISSING from default config!")
    print("This means ProtocolManager uses empty config and defaults to enabled=True")
