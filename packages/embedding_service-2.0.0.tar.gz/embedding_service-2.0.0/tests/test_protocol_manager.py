#!/usr/bin/env python3
"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Test script for ProtocolManager configuration.
"""

import sys
from pathlib import Path

# Add parent directory to import path
sys.path.insert(0, str(Path(__file__).parent))

# Load configuration first
from mcp_proxy_adapter.config import config  # noqa: E402

config.load_from_file("config/ssl_config.json")
print("✅ Loaded configuration from: config/ssl_config.json")

# Check protocols configuration
protocols_config = config.get("protocols", {})
print(f"Protocols config: {protocols_config}")

# Create new ProtocolManager instance
from mcp_proxy_adapter.core.protocol_manager import ProtocolManager  # noqa: E402

protocol_manager = ProtocolManager()

print("Protocol manager enabled:", protocol_manager.enabled)
print(f"Allowed protocols: {protocol_manager.allowed_protocols}")

# Test protocol validation
print(f"HTTPS allowed: {protocol_manager.is_protocol_allowed('https')}")
print(f"HTTP allowed: {protocol_manager.is_protocol_allowed('http')}")

# Test with different configurations
print("\n--- Testing with protocols.enabled = true ---")
protocols_config["enabled"] = True
protocols_config["allowed_protocols"] = ["https"]
config.set("protocols", protocols_config)

protocol_manager2 = ProtocolManager()
print(f"Protocol manager enabled: {protocol_manager2.enabled}")
print(f"Allowed protocols: {protocol_manager2.allowed_protocols}")
print(f"HTTPS allowed: {protocol_manager2.is_protocol_allowed('https')}")
print(f"HTTP allowed: {protocol_manager2.is_protocol_allowed('http')}")

print("\n--- Testing with protocols.enabled = false ---")
protocols_config["enabled"] = False
config.set("protocols", protocols_config)

protocol_manager3 = ProtocolManager()
print(f"Protocol manager enabled: {protocol_manager3.enabled}")
print(f"Allowed protocols: {protocol_manager3.allowed_protocols}")
print(f"HTTPS allowed: {protocol_manager3.is_protocol_allowed('https')}")
print(f"HTTP allowed: {protocol_manager3.is_protocol_allowed('http')}")
