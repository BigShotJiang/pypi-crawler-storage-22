#!/usr/bin/env python3
"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Real integration test for embedding service with mcp_proxy_adapter.
Tests already running server instead of starting its own.
"""

import json
import requests
import sys


class RealIntegrationTest:
    """
    Test class for real integration testing.
    """

    def __init__(self, config_file: str = "config.json"):
        """Initialize test environment."""
        self.config_file = config_file

        # Read configuration
        try:
            with open(config_file, "r") as f:
                config_data = json.load(f)

            port = config_data.get("server", {}).get("port", 10001)

            # Check if SSL is enabled
            ssl_enabled = config_data.get("ssl", {}).get("enabled", False)
            protocol = "https" if ssl_enabled else "http"

            # Always use 127.0.0.1 for testing, not 0.0.0.0
            self.base_url = f"{protocol}://127.0.0.1:{port}"
            self.session = requests.Session()

            # Disable SSL verification for self-signed certificates
            if ssl_enabled:
                self.session.verify = False
                import urllib3

                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

            # Check if authentication is enabled
            self.auth_enabled = config_data.get("security", {}).get("enabled", False)
            if self.auth_enabled:
                self.api_keys = (
                    config_data.get("security", {}).get("auth", {}).get("api_keys", {})
                )

        except Exception as e:
            print(f"❌ Failed to load config {config_file}: {e}")
            sys.exit(1)

        print("🔧 Test Configuration:")
        print(f"   • Config: {config_file}")
        print(f"   • Base URL: {self.base_url}")
        print(f"   • SSL: {'Enabled' if ssl_enabled else 'Disabled'}")
        print(f"   • Auth: {'Enabled' if self.auth_enabled else 'Disabled'}")
        if self.auth_enabled:
            print(f"   • API Keys: {len(self.api_keys)} configured")
        print()

        self.test_results = []

    def log_test(self, test_name: str, success: bool, message: str):
        """Log test result."""
        self.test_results.append(
            {"test": test_name, "success": success, "message": message}
        )
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")

    def check_server_running(self) -> bool:
        """
        Check if server is running and accessible.

        Returns:
            True if server is accessible
        """
        try:
            print("🔍 Checking if server is running...")
            response = self.session.get(f"{self.base_url}/health", timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "ok":
                    print("✅ Server is running and accessible")
                    return True
                else:
                    print(f"❌ Invalid health response: {data}")
                    return False
            else:
                print(f"❌ Server responded with HTTP {response.status_code}")
                return False
        except requests.exceptions.ConnectionError:
            print("❌ Cannot connect to server - is it running?")
            return False
        except Exception as e:
            print(f"❌ Error checking server: {e}")
            return False

    def make_request(
        self, method: str, params: dict = None, api_key: str = None
    ) -> dict:
        """
        Make JSON-RPC request to server.

        Args:
            method: JSON-RPC method
            params: Method parameters
            api_key: API key for authentication

        Returns:
            Response data
        """
        payload = {"jsonrpc": "2.0", "method": method, "params": params or {}, "id": 1}

        headers = {}
        if api_key:
            headers["X-API-Key"] = api_key

        try:
            response = self.session.post(
                f"{self.base_url}/cmd", json=payload, headers=headers, timeout=30
            )
            return (
                response.json()
                if response.status_code == 200
                else {"error": f"HTTP {response.status_code}"}
            )
        except Exception as e:
            return {"error": f"Request failed: {e}"}

    def test_health_endpoint(self) -> bool:
        """Test health endpoint."""
        try:
            response = self.session.get(f"{self.base_url}/health")
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "ok":
                    self.log_test("Health Endpoint", True, "Health check passed")
                    return True
                else:
                    self.log_test("Health Endpoint", False, "Invalid health response")
                    return False
            else:
                self.log_test("Health Endpoint", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Health Endpoint", False, f"Error: {e}")
            return False

    def test_help_command(self) -> bool:
        """Test help command."""
        try:
            data = self.make_request("help")
            if "result" in data:
                self.log_test(
                    "Help Command", True, "Help command executed successfully"
                )
                return True
            else:
                self.log_test("Help Command", False, f"Invalid response: {data}")
                return False
        except Exception as e:
            self.log_test("Help Command", False, f"Error: {e}")
            return False

    def test_embed_command(self) -> bool:
        """Test embed command."""
        try:
            data = self.make_request("embed", {"texts": ["Test text for embedding"]})
            if "result" in data and data["result"].get("success"):
                embeddings = data["result"].get("data", {}).get("embeddings", [])
                if embeddings and len(embeddings[0]) > 0:
                    self.log_test(
                        "Embed Command",
                        True,
                        f"Generated embedding with {len(embeddings[0])} dimensions",
                    )
                    return True
                else:
                    self.log_test("Embed Command", False, "No embeddings generated")
                    return False
            else:
                self.log_test("Embed Command", False, f"Invalid response: {data}")
                return False
        except Exception as e:
            self.log_test("Embed Command", False, f"Error: {e}")
            return False

    def test_models_command(self) -> bool:
        """Test models command."""
        try:
            data = self.make_request("models")
            if "result" in data and data["result"].get("success"):
                models = data["result"].get("data", {}).get("models", [])
                if isinstance(models, list) and len(models) > 0:
                    self.log_test(
                        "Models Command", True, f"Found {len(models)} available models"
                    )
                    return True
                else:
                    self.log_test("Models Command", False, "No models found")
                    return False
            else:
                self.log_test("Models Command", False, f"Invalid response: {data}")
                return False
        except Exception as e:
            self.log_test("Models Command", False, f"Error: {e}")
            return False

    def test_authentication(self) -> bool:
        """Test authentication if enabled."""
        if not self.auth_enabled:
            self.log_test("Authentication", True, "Authentication disabled - skipping")
            return True

        try:
            # Test without authentication (should fail)
            data = self.make_request("help")
            if "error" in data and "401" in str(data["error"]):
                self.log_test(
                    "Auth Required", True, "Authentication correctly required"
                )
            else:
                self.log_test("Auth Required", False, f"Should require auth: {data}")
                return False

            # Test with valid API key
            if self.api_keys:
                api_key = list(self.api_keys.keys())[0]
                data = self.make_request("help", api_key=api_key)
                if "result" in data:
                    self.log_test("Auth Valid", True, "Valid API key accepted")
                else:
                    self.log_test(
                        "Auth Valid", False, f"Valid API key rejected: {data}"
                    )
                    return False
            else:
                self.log_test("Auth Valid", False, "No API keys configured")
                return False

            # Test with invalid API key
            data = self.make_request("help", api_key="invalid-key")
            if "error" in data and "401" in str(data["error"]):
                self.log_test(
                    "Auth Invalid", True, "Invalid API key correctly rejected"
                )
                return True
            else:
                self.log_test(
                    "Auth Invalid", False, f"Should reject invalid key: {data}"
                )
                return False

        except Exception as e:
            self.log_test("Authentication", False, f"Error: {e}")
            return False

    def test_roles_and_permissions(self) -> bool:
        """Test roles and permissions if authentication is enabled."""
        if not self.auth_enabled or not self.api_keys:
            self.log_test(
                "Roles & Permissions", True, "Authentication disabled - skipping"
            )
            return True

        try:
            # Test admin role
            admin_key = None
            readonly_key = None
            user_key = None  # reserved for future user-scoped tests

            for key, role in self.api_keys.items():
                if role == "admin":
                    admin_key = key
                elif role == "user":
                    user_key = key
                elif role == "readonly":
                    readonly_key = key

            # Reserve user_key for future user-scoped tests; ensure shape if present
            assert user_key is None or isinstance(
                user_key, str
            ), "user key must be str or None"

            if admin_key:
                data = self.make_request(
                    "embed", {"texts": ["Test"]}, api_key=admin_key
                )
                if "result" in data and data["result"].get("success"):
                    self.log_test("Admin Permissions", True, "Admin can execute embed")
                else:
                    self.log_test(
                        "Admin Permissions", False, f"Admin denied embed: {data}"
                    )
                    return False

            if readonly_key:
                data = self.make_request(
                    "embed", {"texts": ["Test"]}, api_key=readonly_key
                )
                if "error" in data and "403" in str(data["error"]):
                    self.log_test(
                        "Readonly Restrictions", True, "Readonly correctly denied embed"
                    )
                else:
                    self.log_test(
                        "Readonly Restrictions",
                        False,
                        f"Readonly should be denied: {data}",
                    )
                    return False

            return True

        except Exception as e:
            self.log_test("Roles & Permissions", False, f"Error: {e}")
            return False

    def run_all_tests(self) -> bool:
        """
        Run all integration tests.

        Returns:
            True if all tests passed
        """
        print("=" * 80)
        print("🧪 REAL INTEGRATION TEST")
        print("=" * 80)

        # Check if server is running
        if not self.check_server_running():
            print("❌ Server is not running. Please start the server first:")
            print(
                f"   python -m embed.server --config {self.config_file} "
                "--host 127.0.0.1 --port 10001 --debug"
            )
            return False

        # Run tests
        tests = [
            self.test_health_endpoint,
            self.test_help_command,
            self.test_embed_command,
            self.test_models_command,
            self.test_authentication,
            self.test_roles_and_permissions,
        ]

        all_passed = True
        for test in tests:
            if not test():
                all_passed = False

        return all_passed

    def print_summary(self):
        """Print test summary."""
        print("\n" + "=" * 80)
        print("📊 TEST SUMMARY")
        print("=" * 80)

        passed = sum(1 for result in self.test_results if result["success"])
        total = len(self.test_results)

        print(f"Total tests: {total}")
        print(f"Passed: {passed}")
        print(f"Failed: {total - passed}")
        print(f"Success rate: {(passed/total)*100:.1f}%")

        if passed == total:
            print("\n🎉 ALL TESTS PASSED!")
        else:
            print("\n❌ SOME TESTS FAILED:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"   • {result['test']}: {result['message']}")


def main():
    """Main function."""
    if len(sys.argv) > 1:
        config_file = sys.argv[1]
    else:
        config_file = "config.json"

    test = RealIntegrationTest(config_file)

    try:
        success = test.run_all_tests()
        test.print_summary()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n💥 Test failed with error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
