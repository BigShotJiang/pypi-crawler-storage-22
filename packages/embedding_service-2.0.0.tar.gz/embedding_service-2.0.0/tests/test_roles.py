#!/usr/bin/env python3
"""
Simple role and permissions testing script.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

This script tests role-based access control functionality.
"""

import json
import requests
import time
import sys
from typing import Dict, Any


class RoleTester:
    """
    Simple role and permissions tester.
    """

    def __init__(self, base_url: str = "http://127.0.0.1:9002"):
        """
        Initialize tester.

        Args:
            base_url: Base URL of the service
        """
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = []

    def log_test(
        self, test_name: str, success: bool, message: str = "", data: Any = None
    ):
        """
        Log test result.

        Args:
            test_name: Name of the test
            success: Whether test passed
            message: Additional message
            data: Test data
        """
        result = {
            "test": test_name,
            "success": success,
            "message": message,
            "data": data,
            "timestamp": time.time(),
        }
        self.test_results.append(result)

        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")

    def test_role_access(
        self, role: str, api_key: str, expected_permissions: Dict[str, bool]
    ):
        """
        Test role access to different commands.

        Args:
            role: Role name
            api_key: API key for the role
            expected_permissions: Dictionary of command -> expected access
        """
        headers = {"X-API-Key": api_key}

        for command, should_work in expected_permissions.items():
            test_name = f"Role {role} - {command}"

            try:
                if command == "embed":
                    payload = {
                        "jsonrpc": "2.0",
                        "method": "embed",
                        "params": {"texts": ["Test text"]},
                        "id": 1,
                    }
                elif command == "models":
                    payload = {"jsonrpc": "2.0", "method": "models", "id": 1}
                elif command == "help":
                    payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
                else:
                    self.log_test(test_name, False, f"Unknown command: {command}")
                    continue

                response = self.session.post(
                    f"{self.base_url}/cmd", headers=headers, json=payload
                )

                if should_work:
                    if response.status_code == 200:
                        data = response.json()
                        if "result" in data:
                            # For help command, just check if result exists
                            if command == "help":
                                if "result" in data and data["result"]:
                                    self.log_test(
                                        test_name, True, "Access granted as expected"
                                    )
                                else:
                                    self.log_test(
                                        test_name,
                                        False,
                                        "Command failed: "
                                        f"{data.get('error', 'Unknown error')}",
                                    )
                            else:
                                # For other commands, check success field
                                if data["result"].get("success"):
                                    self.log_test(
                                        test_name, True, "Access granted as expected"
                                    )
                                else:
                                    self.log_test(
                                        test_name,
                                        False,
                                        "Command failed: "
                                        f"{data.get('error', 'Unknown error')}",
                                    )
                        else:
                            self.log_test(test_name, False, "Invalid response format")
                    else:
                        self.log_test(
                            test_name,
                            False,
                            f"Access denied unexpectedly: {response.status_code}",
                        )
                else:
                    if response.status_code in [401, 403]:
                        self.log_test(test_name, True, "Access correctly denied")
                    else:
                        self.log_test(
                            test_name,
                            False,
                            f"Access not denied as expected: {response.status_code}",
                        )

            except Exception as e:
                self.log_test(test_name, False, f"Error: {e}")

    def test_all_roles(self):
        """
        Test all defined roles.
        """
        print("🔐 Testing Role-Based Access Control")
        print("=" * 50)

        # Define roles and their expected permissions
        roles = {
            "admin": {
                "api_key": "admin-secret-key-12345",
                "permissions": {"embed": True, "models": True, "help": True},
            },
            "user": {
                "api_key": "user-secret-key-67890",
                "permissions": {"embed": True, "models": True, "help": True},
            },
            "readonly": {
                "api_key": "readonly-secret-key-11111",
                "permissions": {"embed": False, "models": True, "help": True},
            },
            "guest": {
                "api_key": "guest-secret-key-22222",
                "permissions": {"embed": False, "models": False, "help": True},
            },
        }

        # Test each role
        for role_name, role_config in roles.items():
            print(f"\n👤 Testing role: {role_name}")
            print("-" * 30)

            self.test_role_access(
                role_name, role_config["api_key"], role_config["permissions"]
            )

        # Test invalid API key
        print("\n🚫 Testing invalid API key")
        print("-" * 30)

        try:
            headers = {"X-API-Key": "invalid-key"}
            payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
            response = self.session.post(
                f"{self.base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code in [401, 403]:
                self.log_test("Invalid API Key", True, "Invalid key correctly rejected")
            else:
                self.log_test(
                    "Invalid API Key",
                    False,
                    f"Invalid key not rejected: {response.status_code}",
                )
        except Exception as e:
            self.log_test("Invalid API Key", False, f"Error: {e}")

        # Test without API key
        print("\n🚫 Testing without API key")
        print("-" * 30)

        try:
            payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
            response = self.session.post(f"{self.base_url}/cmd", json=payload)

            if response.status_code in [401, 403]:
                self.log_test(
                    "No API Key", True, "Request without key correctly rejected"
                )
            else:
                self.log_test(
                    "No API Key",
                    False,
                    f"Request without key not rejected: {response.status_code}",
                )
        except Exception as e:
            self.log_test("No API Key", False, f"Error: {e}")

    def run_tests(self):
        """
        Run all role tests.

        Returns:
            Test results summary
        """
        # Test if server is running
        try:
            response = self.session.get(f"{self.base_url}/health")
            if response.status_code != 200:
                print(f"❌ Server not responding: {response.status_code}")
                return None
        except Exception as e:
            print(f"❌ Cannot connect to server: {e}")
            print("💡 Make sure server is running with roles configuration:")
            print(
                "   python -m embed.server --config config/simple_roles_config.json "
                "--port 9002"
            )
            return None

        # Run role tests
        self.test_all_roles()

        # Calculate summary
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["success"])
        failed_tests = total_tests - passed_tests

        summary = {
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "success_rate": (
                (passed_tests / total_tests * 100) if total_tests > 0 else 0
            ),
            "results": self.test_results,
        }

        print("\n" + "=" * 50)
        print("📊 ROLE TEST SUMMARY")
        print("=" * 50)
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {failed_tests}")
        print(f"Success Rate: {summary['success_rate']:.1f}%")

        if failed_tests > 0:
            print("\n❌ FAILED TESTS:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  - {result['test']}: {result['message']}")

        return summary


def main():
    """
    Main function.
    """
    import argparse

    parser = argparse.ArgumentParser(description="Role-Based Access Control Testing")
    parser.add_argument(
        "--url",
        default="http://127.0.0.1:9002",
        help="Base URL of the service (default: http://127.0.0.1:9002)",
    )
    parser.add_argument(
        "--output",
        default="role_test_results.json",
        help="Output file for test results",
    )

    args = parser.parse_args()

    # Create tester
    tester = RoleTester(args.url)

    # Run tests
    summary = tester.run_tests()

    if summary is None:
        sys.exit(1)

    # Save results
    try:
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(tester.test_results, f, indent=2, ensure_ascii=False)
        print("\n💾 Test results saved to:", args.output)
    except Exception as e:
        print(f"\n❌ Failed to save results: {e}")

    # Exit with appropriate code
    if summary["failed_tests"] > 0:
        print(f"\n❌ Role tests failed: {summary['failed_tests']} failures")
        sys.exit(1)
    else:
        print("\n✅ All role tests passed!")
        sys.exit(0)


if __name__ == "__main__":
    main()
