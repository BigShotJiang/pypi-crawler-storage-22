#!/usr/bin/env python3
"""
Comprehensive security integration testing script.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

This script tests all security features including roles, permissions,
authentication methods, and SSL/TLS configurations.
"""

import json
import requests
import time
import sys
import subprocess
import os
from typing import Any
import urllib3

# Disable SSL warnings for testing
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class SecurityIntegrationTester:
    """
    Comprehensive security integration tester.
    """

    def __init__(self, base_url: str = "http://localhost:9001"):
        """
        Initialize tester.

        Args:
            base_url: Base URL of the service
        """
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = []
        self.server_process = None

    def log_test(
        self, test_name: str, success: bool, message: str = "", data: Any = None
    ):
        """
        Log test result.

        Args:
            test_name: Name of the test
            success: Whether test passed
            message: Additional message
            data: Test data
        """
        result = {
            "test": test_name,
            "success": success,
            "message": message,
            "data": data,
            "timestamp": time.time(),
        }
        self.test_results.append(result)

        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")

    def start_server(self, config_file: str, port: int) -> bool:
        """
        Start server with specific configuration.

        Args:
            config_file: Configuration file path
            port: Port to run on

        Returns:
            True if server started successfully
        """
        try:
            # Kill any existing server
            subprocess.run(
                ["pkill", "-f", "python -m embed.server"],
                capture_output=True,
                check=False,
            )
            time.sleep(2)

            # Start server
            cmd = [
                "python",
                "-m",
                "embed.server",
                "--config",
                config_file,
                "--host",
                "127.0.0.1",
                "--port",
                str(port),
                "--debug",
            ]

            self.server_process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )

            # Wait for server to start
            time.sleep(5)

            # Test if server is responding
            try:
                response = requests.get(f"http://127.0.0.1:{port}/health", timeout=10)
                if response.status_code == 200:
                    self.log_test(
                        f"Server Start ({config_file})",
                        True,
                        f"Server started on port {port}",
                    )
                    return True
                else:
                    self.log_test(
                        f"Server Start ({config_file})",
                        False,
                        f"Server not responding: {response.status_code}",
                    )
                    return False
            except requests.exceptions.RequestException as e:
                self.log_test(
                    f"Server Start ({config_file})",
                    False,
                    f"Server not accessible: {e}",
                )
                return False

        except Exception as e:
            self.log_test(
                f"Server Start ({config_file})", False, f"Failed to start server: {e}"
            )
            return False

    def stop_server(self):
        """
        Stop the running server.
        """
        if self.server_process:
            self.server_process.terminate()
            self.server_process.wait()
            self.server_process = None

    def test_basic_functionality(self, port: int) -> bool:
        """
        Test basic functionality without authentication.

        Args:
            port: Server port

        Returns:
            True if all tests passed
        """
        base_url = f"http://127.0.0.1:{port}"

        # Test health endpoint
        try:
            response = self.session.get(f"{base_url}/health")
            if response.status_code == 200:
                self.log_test("Health Endpoint", True, "Health check passed")
            else:
                self.log_test("Health Endpoint", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Health Endpoint", False, f"Error: {e}")
            return False

        # Test help command
        try:
            payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
            response = self.session.post(f"{base_url}/cmd", json=payload)
            if response.status_code == 200:
                data = response.json()
                if "result" in data:
                    self.log_test("Help Command", True, "Help command works")
                else:
                    self.log_test("Help Command", False, "Invalid response format")
                    return False
            else:
                self.log_test("Help Command", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Help Command", False, f"Error: {e}")
            return False

        return True

    def test_api_key_auth(self, port: int) -> bool:
        """
        Test API key authentication.

        Args:
            port: Server port

        Returns:
            True if all tests passed
        """
        base_url = f"http://127.0.0.1:{port}"

        # Test with admin API key
        try:
            headers = {"X-API-Key": "admin-secret-key-12345"}
            payload = {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Test"]},
                "id": 1,
            }
            response = self.session.post(
                f"{base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    self.log_test("API Key Auth (Admin)", True, "Admin API key works")
                else:
                    self.log_test("API Key Auth (Admin)", False, "Admin API key failed")
                    return False
            else:
                self.log_test(
                    "API Key Auth (Admin)", False, f"HTTP {response.status_code}"
                )
                return False
        except Exception as e:
            self.log_test("API Key Auth (Admin)", False, f"Error: {e}")
            return False

        # Test with user API key
        try:
            headers = {"X-API-Key": "user-secret-key-67890"}
            payload = {"jsonrpc": "2.0", "method": "models", "id": 1}
            response = self.session.post(
                f"{base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    self.log_test("API Key Auth (User)", True, "User API key works")
                else:
                    self.log_test("API Key Auth (User)", False, "User API key failed")
                    return False
            else:
                self.log_test(
                    "API Key Auth (User)", False, f"HTTP {response.status_code}"
                )
                return False
        except Exception as e:
            self.log_test("API Key Auth (User)", False, f"Error: {e}")
            return False

        # Test with invalid API key
        try:
            headers = {"X-API-Key": "invalid-key"}
            payload = {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Test"]},
                "id": 1,
            }
            response = self.session.post(
                f"{base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code in [401, 403]:
                self.log_test(
                    "API Key Auth (Invalid)", True, "Invalid API key correctly rejected"
                )
            else:
                self.log_test(
                    "API Key Auth (Invalid)",
                    False,
                    f"Invalid API key not rejected: {response.status_code}",
                )
                return False
        except Exception as e:
            self.log_test("API Key Auth (Invalid)", False, f"Error: {e}")
            return False

        return True

    def test_basic_auth(self, port: int) -> bool:
        """
        Test basic authentication.

        Args:
            port: Server port

        Returns:
            True if all tests passed
        """
        base_url = f"http://127.0.0.1:{port}"

        # Test with admin credentials
        try:
            from requests.auth import HTTPBasicAuth

            auth = HTTPBasicAuth("admin", "admin-password-123")

            payload = {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Test"]},
                "id": 1,
            }
            response = self.session.post(f"{base_url}/cmd", auth=auth, json=payload)

            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    self.log_test("Basic Auth (Admin)", True, "Admin basic auth works")
                else:
                    self.log_test(
                        "Basic Auth (Admin)", False, "Admin basic auth failed"
                    )
                    return False
            else:
                self.log_test(
                    "Basic Auth (Admin)", False, f"HTTP {response.status_code}"
                )
                return False
        except Exception as e:
            self.log_test("Basic Auth (Admin)", False, f"Error: {e}")
            return False

        # Test with invalid credentials
        try:
            auth = HTTPBasicAuth("admin", "wrong-password")

            payload = {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Test"]},
                "id": 1,
            }
            response = self.session.post(f"{base_url}/cmd", auth=auth, json=payload)

            if response.status_code in [401, 403]:
                self.log_test(
                    "Basic Auth (Invalid)",
                    True,
                    "Invalid credentials correctly rejected",
                )
            else:
                self.log_test(
                    "Basic Auth (Invalid)",
                    False,
                    f"Invalid credentials not rejected: {response.status_code}",
                )
                return False
        except Exception as e:
            self.log_test("Basic Auth (Invalid)", False, f"Error: {e}")
            return False

        return True

    def test_role_permissions(self, port: int) -> bool:
        """
        Test role-based permissions.

        Args:
            port: Server port

        Returns:
            True if all tests passed
        """
        base_url = f"http://127.0.0.1:{port}"

        # Test admin role (should have full access)
        try:
            headers = {"X-API-Key": "admin-secret-key-12345"}

            # Test embed command (should work)
            payload = {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Test"]},
                "id": 1,
            }
            response = self.session.post(
                f"{base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    self.log_test(
                        "Role Permissions (Admin - Embed)", True, "Admin can use embed"
                    )
                else:
                    self.log_test(
                        "Role Permissions (Admin - Embed)",
                        False,
                        "Admin cannot use embed",
                    )
                    return False
            else:
                self.log_test(
                    "Role Permissions (Admin - Embed)",
                    False,
                    f"HTTP {response.status_code}",
                )
                return False
        except Exception as e:
            self.log_test("Role Permissions (Admin - Embed)", False, f"Error: {e}")
            return False

        # Test readonly role (should have limited access)
        try:
            headers = {"X-API-Key": "readonly-secret-key-11111"}

            # Test models command (should work)
            payload = {"jsonrpc": "2.0", "method": "models", "id": 1}
            response = self.session.post(
                f"{base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    self.log_test(
                        "Role Permissions (Readonly - Models)",
                        True,
                        "Readonly can list models",
                    )
                else:
                    self.log_test(
                        "Role Permissions (Readonly - Models)",
                        False,
                        "Readonly cannot list models",
                    )
                    return False
            else:
                self.log_test(
                    "Role Permissions (Readonly - Models)",
                    False,
                    f"HTTP {response.status_code}",
                )
                return False
        except Exception as e:
            self.log_test("Role Permissions (Readonly - Models)", False, f"Error: {e}")
            return False

        # Test readonly role trying to use embed (should be denied)
        try:
            headers = {"X-API-Key": "readonly-secret-key-11111"}

            # Test embed command (should be denied)
            payload = {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Test"]},
                "id": 1,
            }
            response = self.session.post(
                f"{base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code in [401, 403]:
                self.log_test(
                    "Role Permissions (Readonly - Embed Denied)",
                    True,
                    "Readonly correctly denied embed access",
                )
            else:
                self.log_test(
                    "Role Permissions (Readonly - Embed Denied)",
                    False,
                    f"Readonly not denied embed access: {response.status_code}",
                )
                return False
        except Exception as e:
            self.log_test(
                "Role Permissions (Readonly - Embed Denied)", False, f"Error: {e}"
            )
            return False

        return True

    def test_ssl_connection(self, port: int) -> bool:
        """
        Test SSL connection.

        Args:
            port: Server port

        Returns:
            True if SSL works
        """
        base_url = f"https://127.0.0.1:{port}"

        try:
            # Test health endpoint with SSL
            response = requests.get(f"{base_url}/health", verify=False, timeout=10)
            if response.status_code == 200:
                self.log_test(
                    "SSL Connection", True, f"SSL connection works on port {port}"
                )
                return True
            else:
                self.log_test(
                    "SSL Connection",
                    False,
                    f"SSL connection failed: {response.status_code}",
                )
                return False
        except Exception as e:
            self.log_test("SSL Connection", False, f"SSL connection error: {e}")
            return False

    def test_mtls_connection(self, port: int) -> bool:
        """
        Test mTLS connection.

        Args:
            port: Server port

        Returns:
            True if mTLS works
        """
        base_url = f"https://127.0.0.1:{port}"

        try:
            # Test with client certificate
            cert_file = "./certs/client.crt"
            key_file = "./certs/client.key"
            ca_file = "./certs/ca.crt"

            if not all(os.path.exists(f) for f in [cert_file, key_file, ca_file]):
                self.log_test("mTLS Connection", False, "Client certificates not found")
                return False

            response = requests.get(
                f"{base_url}/health",
                cert=(cert_file, key_file),
                verify=ca_file,
                timeout=10,
            )

            if response.status_code == 200:
                self.log_test(
                    "mTLS Connection", True, f"mTLS connection works on port {port}"
                )
                return True
            else:
                self.log_test(
                    "mTLS Connection",
                    False,
                    f"mTLS connection failed: {response.status_code}",
                )
                return False
        except Exception as e:
            self.log_test("mTLS Connection", False, f"mTLS connection error: {e}")
            return False

    def test_rate_limiting(self, port: int) -> bool:
        """
        Test rate limiting.

        Args:
            port: Server port

        Returns:
            True if rate limiting works
        """
        base_url = f"http://127.0.0.1:{port}"

        try:
            headers = {"X-API-Key": "user-secret-key-67890"}

            # Make multiple requests quickly
            success_count = 0
            rate_limited_count = 0

            for i in range(15):
                payload = {"jsonrpc": "2.0", "method": "help", "id": i}
                response = self.session.post(
                    f"{base_url}/cmd", headers=headers, json=payload
                )

                if response.status_code == 200:
                    success_count += 1
                elif response.status_code in [429, 503]:  # Rate limited
                    rate_limited_count += 1

                time.sleep(0.1)  # Small delay

            if rate_limited_count > 0:
                self.log_test(
                    "Rate Limiting",
                    True,
                    f"Rate limiting active: {success_count} success, "
                    f"{rate_limited_count} rate limited",
                )
                return True
            else:
                self.log_test("Rate Limiting", False, "Rate limiting not detected")
                return False
        except Exception as e:
            self.log_test("Rate Limiting", False, f"Rate limiting test error: {e}")
            return False

    def run_configuration_tests(self, config_file: str, port: int, test_name: str):
        """
        Run tests for a specific configuration.

        Args:
            config_file: Configuration file path
            port: Server port
            test_name: Name of the test configuration
        """
        print(f"\n🔧 Testing {test_name} configuration")
        print("=" * 60)

        # Start server
        if not self.start_server(config_file, port):
            print(f"❌ Failed to start server with {config_file}")
            return

        try:
            # Test basic functionality
            self.test_basic_functionality(port)

            # Test authentication if enabled
            if (
                "token" in config_file
                or "roles" in config_file
                or "auth" in config_file
            ):
                self.test_api_key_auth(port)
                self.test_basic_auth(port)

            # Test roles and permissions
            if "roles" in config_file:
                self.test_role_permissions(port)

            # Test SSL if enabled
            if "ssl" in config_file:
                ssl_port = 9443 if "ssl" in config_file else 9444
                self.test_ssl_connection(ssl_port)

            # Test mTLS if enabled
            if "mtls" in config_file:
                self.test_mtls_connection(9444)

            # Test rate limiting
            self.test_rate_limiting(port)

        finally:
            # Stop server
            self.stop_server()

    def run_all_tests(self):
        """
        Run all security integration tests.

        Returns:
            Test results summary
        """
        print("🚀 Starting Comprehensive Security Integration Tests")
        print("=" * 80)

        # Test configurations
        test_configs = [
            ("config.json", 9001, "Basic"),
            ("config/token_config.json", 9001, "Token Authentication"),
            ("config/roles_config.json", 9002, "Role-Based Access Control"),
            ("config/ssl_config.json", 9443, "SSL/TLS"),
            ("config/mtls_config.json", 9444, "mTLS"),
        ]

        for config_file, port, test_name in test_configs:
            if os.path.exists(config_file):
                self.run_configuration_tests(config_file, port, test_name)
            else:
                print(f"⚠️  Configuration file not found: {config_file}")

        # Calculate summary
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["success"])
        failed_tests = total_tests - passed_tests

        summary = {
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "success_rate": (
                (passed_tests / total_tests * 100) if total_tests > 0 else 0
            ),
            "results": self.test_results,
        }

        print("\n" + "=" * 80)
        print("📊 SECURITY TEST SUMMARY")
        print("=" * 80)
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {failed_tests}")
        print(f"Success Rate: {summary['success_rate']:.1f}%")

        if failed_tests > 0:
            print("\n❌ FAILED TESTS:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  - {result['test']}: {result['message']}")

        return summary

    def save_results(self, filename: str = "security_test_results.json"):
        """
        Save test results to file.

        Args:
            filename: Output filename
        """
        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(self.test_results, f, indent=2, ensure_ascii=False)
            print(f"\n💾 Test results saved to: {filename}")
        except Exception as e:
            print(f"\n❌ Failed to save results: {e}")


def main():
    """
    Main function.
    """
    import argparse

    parser = argparse.ArgumentParser(
        description="Comprehensive Security Integration Testing"
    )
    parser.add_argument(
        "--url",
        default="http://localhost:9001",
        help="Base URL of the service (default: http://localhost:9001)",
    )
    parser.add_argument(
        "--output",
        default="security_test_results.json",
        help="Output file for test results (default: security_test_results.json)",
    )
    parser.add_argument(
        "--create-certs", action="store_true", help="Create certificates before testing"
    )

    args = parser.parse_args()

    # Create certificates if requested
    if args.create_certs:
        print("🔐 Creating certificates...")
        subprocess.run(["./scripts/create_certs.sh"], check=True)

    # Create tester
    tester = SecurityIntegrationTester(args.url)

    try:
        # Run tests
        summary = tester.run_all_tests()

        # Save results
        tester.save_results(args.output)

        # Exit with appropriate code
        if summary["failed_tests"] > 0:
            print(f"\n❌ Security tests failed: {summary['failed_tests']} failures")
            sys.exit(1)
        else:
            print("\n✅ All security tests passed!")
            sys.exit(0)

    except KeyboardInterrupt:
        print("\n⚠️  Testing interrupted by user")
        tester.stop_server()
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Testing failed with error: {e}")
        tester.stop_server()
        sys.exit(1)


if __name__ == "__main__":
    main()
