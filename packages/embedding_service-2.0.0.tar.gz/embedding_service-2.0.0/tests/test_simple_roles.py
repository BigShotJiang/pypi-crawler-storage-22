#!/usr/bin/env python3
"""
Simple role testing script.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

This script tests basic role functionality.
"""

import json
import requests
import time
import sys
from typing import Any


class SimpleRoleTester:
    """
    Simple role tester.
    """

    def __init__(self, base_url: str = "http://127.0.0.1:9002"):
        """
        Initialize tester.

        Args:
            base_url: Base URL of the service
        """
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = []

    def log_test(
        self, test_name: str, success: bool, message: str = "", data: Any = None
    ):
        """
        Log test result.

        Args:
            test_name: Name of the test
            success: Whether test passed
            message: Additional message
            data: Test data
        """
        result = {
            "test": test_name,
            "success": success,
            "message": message,
            "data": data,
            "timestamp": time.time(),
        }
        self.test_results.append(result)

        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")

    def test_basic_functionality(self):
        """
        Test basic functionality.
        """
        print("🔧 Testing Basic Functionality")
        print("=" * 40)

        # Test health endpoint
        try:
            response = self.session.get(f"{self.base_url}/health")
            if response.status_code == 200:
                self.log_test("Health Endpoint", True, "Health check passed")
            else:
                self.log_test("Health Endpoint", False, f"HTTP {response.status_code}")
        except Exception as e:
            self.log_test("Health Endpoint", False, f"Error: {e}")

        # Test help command without auth
        try:
            payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
            response = self.session.post(f"{self.base_url}/cmd", json=payload)
            if response.status_code == 200:
                data = response.json()
                if "result" in data:
                    self.log_test(
                        "Help Command (No Auth)",
                        True,
                        "Help command works without auth",
                    )
                else:
                    self.log_test(
                        "Help Command (No Auth)", False, "Invalid response format"
                    )
            else:
                self.log_test(
                    "Help Command (No Auth)", False, f"HTTP {response.status_code}"
                )
        except Exception as e:
            self.log_test("Help Command (No Auth)", False, f"Error: {e}")

    def test_authentication(self):
        """
        Test authentication.
        """
        print("\n🔐 Testing Authentication")
        print("=" * 40)

        # Test with valid API key
        try:
            headers = {"X-API-Key": "admin-secret-key-12345"}
            payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
            response = self.session.post(
                f"{self.base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data:
                    self.log_test("Valid API Key", True, "Valid API key works")
                else:
                    self.log_test("Valid API Key", False, "Invalid response format")
            else:
                self.log_test("Valid API Key", False, f"HTTP {response.status_code}")
        except Exception as e:
            self.log_test("Valid API Key", False, f"Error: {e}")

        # Test with invalid API key
        try:
            headers = {"X-API-Key": "invalid-key"}
            payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
            response = self.session.post(
                f"{self.base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code in [401, 403]:
                self.log_test(
                    "Invalid API Key", True, "Invalid API key correctly rejected"
                )
            else:
                self.log_test(
                    "Invalid API Key",
                    False,
                    f"Invalid API key not rejected: {response.status_code}",
                )
        except Exception as e:
            self.log_test("Invalid API Key", False, f"Error: {e}")

    def test_commands(self):
        """
        Test different commands.
        """
        print("\n📋 Testing Commands")
        print("=" * 40)

        # Test embed command
        try:
            headers = {"X-API-Key": "admin-secret-key-12345"}
            payload = {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Test text"]},
                "id": 1,
            }
            response = self.session.post(
                f"{self.base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    self.log_test("Embed Command", True, "Embed command works")
                else:
                    self.log_test(
                        "Embed Command",
                        False,
                        f"Embed command failed: {data.get('error', 'Unknown error')}",
                    )
            else:
                self.log_test("Embed Command", False, f"HTTP {response.status_code}")
        except Exception as e:
            self.log_test("Embed Command", False, f"Error: {e}")

        # Test models command
        try:
            headers = {"X-API-Key": "admin-secret-key-12345"}
            payload = {"jsonrpc": "2.0", "method": "models", "id": 1}
            response = self.session.post(
                f"{self.base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    self.log_test("Models Command", True, "Models command works")
                else:
                    self.log_test(
                        "Models Command",
                        False,
                        f"Models command failed: {data.get('error', 'Unknown error')}",
                    )
            else:
                self.log_test("Models Command", False, f"HTTP {response.status_code}")
        except Exception as e:
            self.log_test("Models Command", False, f"Error: {e}")

    def test_different_users(self):
        """
        Test different users.
        """
        print("\n👥 Testing Different Users")
        print("=" * 40)

        users = [
            ("admin", "admin-secret-key-12345"),
            ("user", "user-secret-key-67890"),
            ("readonly", "readonly-secret-key-11111"),
            ("guest", "guest-secret-key-22222"),
        ]

        for username, api_key in users:
            try:
                headers = {"X-API-Key": api_key}
                payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
                response = self.session.post(
                    f"{self.base_url}/cmd", headers=headers, json=payload
                )

                if response.status_code == 200:
                    data = response.json()
                    if "result" in data:
                        self.log_test(
                            f"User {username}", True, f"User {username} can access help"
                        )
                    else:
                        self.log_test(
                            f"User {username}",
                            False,
                            f"User {username} got invalid response",
                        )
                else:
                    self.log_test(
                        f"User {username}",
                        False,
                        f"User {username} got HTTP {response.status_code}",
                    )
            except Exception as e:
                self.log_test(f"User {username}", False, f"Error: {e}")

    def run_tests(self):
        """
        Run all tests.

        Returns:
            Test results summary
        """
        # Test if server is running
        try:
            response = self.session.get(f"{self.base_url}/health")
            if response.status_code != 200:
                print(f"❌ Server not responding: {response.status_code}")
                return None
        except Exception as e:
            print(f"❌ Cannot connect to server: {e}")
            print("💡 Make sure server is running:")
            print(
                "   python -m embed.server --config config/simple_roles_config.json "
                "--port 9002"
            )
            return None

        # Run tests
        self.test_basic_functionality()
        self.test_authentication()
        self.test_commands()
        self.test_different_users()

        # Calculate summary
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["success"])
        failed_tests = total_tests - passed_tests

        summary = {
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "success_rate": (
                (passed_tests / total_tests * 100) if total_tests > 0 else 0
            ),
            "results": self.test_results,
        }

        print("\n" + "=" * 50)
        print("📊 TEST SUMMARY")
        print("=" * 50)
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {failed_tests}")
        print(f"Success Rate: {summary['success_rate']:.1f}%")

        if failed_tests > 0:
            print("\n❌ FAILED TESTS:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  - {result['test']}: {result['message']}")

        return summary


def main():
    """
    Main function.
    """
    import argparse

    parser = argparse.ArgumentParser(description="Simple Role Testing")
    parser.add_argument(
        "--url",
        default="http://127.0.0.1:9002",
        help="Base URL of the service (default: http://127.0.0.1:9002)",
    )
    parser.add_argument(
        "--output",
        default="simple_role_test_results.json",
        help="Output file for test results (default: simple_role_test_results.json)",
    )

    args = parser.parse_args()

    # Create tester
    tester = SimpleRoleTester(args.url)

    # Run tests
    summary = tester.run_tests()

    if summary is None:
        sys.exit(1)

    # Save results
    try:
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(tester.test_results, f, indent=2, ensure_ascii=False)
        print("\n💾 Test results saved to:", args.output)
    except Exception as e:
        print(f"\n❌ Failed to save results: {e}")

    # Exit with appropriate code
    if summary["failed_tests"] > 0:
        print(f"\n❌ Tests failed: {summary['failed_tests']} failures")
        sys.exit(1)
    else:
        print("\n✅ All tests passed!")
        sys.exit(0)


if __name__ == "__main__":
    main()
