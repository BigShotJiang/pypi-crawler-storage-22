#!/usr/bin/env python3
"""
Single configuration testing script.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

This script tests a single configuration at a time.
"""

import json
import requests
import time
import sys
import subprocess
import os
from typing import Any
import urllib3

# Disable SSL warnings for testing
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class SingleConfigTester:
    """
    Single configuration tester.
    """

    def __init__(self, config_file: str, port: int):
        """
        Initialize tester.

        Args:
            config_file: Configuration file path
            port: Server port
        """
        self.config_file = config_file
        self.port = port
        self.base_url = f"http://127.0.0.1:{port}"
        self.session = requests.Session()
        self.test_results = []
        self.server_process = None

    def log_test(
        self, test_name: str, success: bool, message: str = "", data: Any = None
    ):
        """
        Log test result.

        Args:
            test_name: Name of the test
            success: Whether test passed
            message: Additional message
            data: Test data
        """
        result = {
            "test": test_name,
            "success": success,
            "message": message,
            "data": data,
            "timestamp": time.time(),
        }
        self.test_results.append(result)

        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")

    def start_server(self) -> bool:
        """
        Start server with configuration.

        Returns:
            True if server started successfully
        """
        try:
            # Kill any existing server
            subprocess.run(
                ["pkill", "-f", "python -m embed.server"],
                capture_output=True,
                check=False,
            )
            time.sleep(2)

            # Start server
            cmd = [
                "python",
                "-m",
                "embed.server",
                "--config",
                self.config_file,
                "--host",
                "127.0.0.1",
                "--port",
                str(self.port),
                "--debug",
            ]

            self.server_process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )

            # Wait for server to start
            time.sleep(5)

            # Test if server is responding
            try:
                response = requests.get(f"{self.base_url}/health", timeout=10)
                if response.status_code == 200:
                    self.log_test(
                        "Server Start", True, f"Server started on port {self.port}"
                    )
                    return True
                else:
                    self.log_test(
                        "Server Start",
                        False,
                        f"Server not responding: {response.status_code}",
                    )
                    return False
            except requests.exceptions.RequestException as e:
                self.log_test("Server Start", False, f"Server not accessible: {e}")
                return False

        except Exception as e:
            self.log_test("Server Start", False, f"Failed to start server: {e}")
            return False

    def stop_server(self):
        """
        Stop the running server.
        """
        if self.server_process:
            self.server_process.terminate()
            self.server_process.wait()
            self.server_process = None

    def test_basic_functionality(self) -> bool:
        """
        Test basic functionality.

        Returns:
            True if all tests passed
        """
        # Test health endpoint
        try:
            response = self.session.get(f"{self.base_url}/health")
            if response.status_code == 200:
                self.log_test("Health Endpoint", True, "Health check passed")
            else:
                self.log_test("Health Endpoint", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Health Endpoint", False, f"Error: {e}")
            return False

        # Test help command
        try:
            payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
            response = self.session.post(f"{self.base_url}/cmd", json=payload)
            if response.status_code == 200:
                data = response.json()
                if "result" in data:
                    self.log_test("Help Command", True, "Help command works")
                else:
                    self.log_test("Help Command", False, "Invalid response format")
                    return False
            else:
                self.log_test("Help Command", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Help Command", False, f"Error: {e}")
            return False

        return True

    def test_embed_command(self) -> bool:
        """
        Test embed command.

        Returns:
            True if test passed
        """
        try:
            payload = {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {"texts": ["Test text"]},
                "id": 1,
            }
            response = self.session.post(f"{self.base_url}/cmd", json=payload)

            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    self.log_test("Embed Command", True, "Embed command works")
                    return True
                else:
                    self.log_test(
                        "Embed Command",
                        False,
                        f"Embed command failed: {data.get('error', 'Unknown error')}",
                    )
                    return False
            else:
                self.log_test("Embed Command", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Embed Command", False, f"Error: {e}")
            return False

    def test_models_command(self) -> bool:
        """
        Test models command.

        Returns:
            True if test passed
        """
        try:
            payload = {"jsonrpc": "2.0", "method": "models", "id": 1}
            response = self.session.post(f"{self.base_url}/cmd", json=payload)

            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    self.log_test("Models Command", True, "Models command works")
                    return True
                else:
                    self.log_test(
                        "Models Command",
                        False,
                        f"Models command failed: {data.get('error', 'Unknown error')}",
                    )
                    return False
            else:
                self.log_test("Models Command", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Models Command", False, f"Error: {e}")
            return False

    def test_api_key_auth(self) -> bool:
        """
        Test API key authentication.

        Returns:
            True if all tests passed
        """
        # Test with admin API key
        try:
            headers = {"X-API-Key": "admin-secret-key-12345"}
            payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
            response = self.session.post(
                f"{self.base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code == 200:
                data = response.json()
                if "result" in data:
                    self.log_test("API Key Auth (Admin)", True, "Admin API key works")
                else:
                    self.log_test("API Key Auth (Admin)", False, "Admin API key failed")
                    return False
            else:
                self.log_test(
                    "API Key Auth (Admin)", False, f"HTTP {response.status_code}"
                )
                return False
        except Exception as e:
            self.log_test("API Key Auth (Admin)", False, f"Error: {e}")
            return False

        # Test with invalid API key
        try:
            headers = {"X-API-Key": "invalid-key"}
            payload = {"jsonrpc": "2.0", "method": "help", "id": 1}
            response = self.session.post(
                f"{self.base_url}/cmd", headers=headers, json=payload
            )

            if response.status_code in [401, 403]:
                self.log_test(
                    "API Key Auth (Invalid)", True, "Invalid API key correctly rejected"
                )
            else:
                self.log_test(
                    "API Key Auth (Invalid)",
                    False,
                    f"Invalid API key not rejected: {response.status_code}",
                )
                return False
        except Exception as e:
            self.log_test("API Key Auth (Invalid)", False, f"Error: {e}")
            return False

        return True

    def test_ssl_connection(self) -> bool:
        """
        Test SSL connection.

        Returns:
            True if SSL works
        """
        try:
            # Test health endpoint with SSL
            ssl_url = f"https://127.0.0.1:{self.port}"
            response = requests.get(f"{ssl_url}/health", verify=False, timeout=10)
            if response.status_code == 200:
                self.log_test(
                    "SSL Connection", True, f"SSL connection works on port {self.port}"
                )
                return True
            else:
                self.log_test(
                    "SSL Connection",
                    False,
                    f"SSL connection failed: {response.status_code}",
                )
                return False
        except Exception as e:
            self.log_test("SSL Connection", False, f"SSL connection error: {e}")
            return False

    def test_mtls_connection(self) -> bool:
        """
        Test mTLS connection.

        Returns:
            True if mTLS works
        """
        try:
            # Test with client certificate
            cert_file = "./certs/client.crt"
            key_file = "./certs/client.key"
            ca_file = "./certs/ca.crt"

            if not all(os.path.exists(f) for f in [cert_file, key_file, ca_file]):
                self.log_test("mTLS Connection", False, "Client certificates not found")
                return False

            ssl_url = f"https://127.0.0.1:{self.port}"
            response = requests.get(
                f"{ssl_url}/health",
                cert=(cert_file, key_file),
                verify=ca_file,
                timeout=10,
            )

            if response.status_code == 200:
                self.log_test(
                    "mTLS Connection",
                    True,
                    f"mTLS connection works on port {self.port}",
                )
                return True
            else:
                self.log_test(
                    "mTLS Connection",
                    False,
                    f"mTLS connection failed: {response.status_code}",
                )
                return False
        except Exception as e:
            self.log_test("mTLS Connection", False, f"mTLS connection error: {e}")
            return False

    def run_tests(self):
        """
        Run all tests for this configuration.

        Returns:
            Test results summary
        """
        config_name = os.path.basename(self.config_file).replace(".json", "")
        print(f"\n🔧 Testing {config_name} configuration")
        print("=" * 60)

        # Start server
        if not self.start_server():
            print(f"❌ Failed to start server with {self.config_file}")
            return None

        try:
            # Test basic functionality
            self.test_basic_functionality()

            # Test commands
            self.test_embed_command()
            self.test_models_command()

            # Test authentication if enabled
            if (
                "token" in self.config_file
                or "roles" in self.config_file
                or "auth" in self.config_file
            ):
                self.test_api_key_auth()

            # Test SSL if enabled
            if "ssl" in self.config_file or "mtls" in self.config_file:
                if "mtls" in self.config_file:
                    self.test_mtls_connection()
                else:
                    self.test_ssl_connection()

        finally:
            # Stop server
            self.stop_server()

        # Calculate summary
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["success"])
        failed_tests = total_tests - passed_tests

        summary = {
            "config": config_name,
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "success_rate": (
                (passed_tests / total_tests * 100) if total_tests > 0 else 0
            ),
            "results": self.test_results,
        }

        print(f"\n📊 {config_name.upper()} TEST SUMMARY")
        print("=" * 60)
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {failed_tests}")
        print(f"Success Rate: {summary['success_rate']:.1f}%")

        if failed_tests > 0:
            print("\n❌ FAILED TESTS:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  - {result['test']}: {result['message']}")

        return summary


def main():
    """
    Main function.
    """
    import argparse

    parser = argparse.ArgumentParser(description="Single Configuration Testing")
    parser.add_argument("config_file", help="Configuration file to test")
    parser.add_argument(
        "--port", type=int, default=9001, help="Port to run server on (default: 9001)"
    )
    parser.add_argument("--output", help="Output file for test results")

    args = parser.parse_args()

    if not os.path.exists(args.config_file):
        print(f"❌ Configuration file not found: {args.config_file}")
        sys.exit(1)

    # Create tester
    tester = SingleConfigTester(args.config_file, args.port)

    # Run tests
    summary = tester.run_tests()

    if summary is None:
        sys.exit(1)

    # Save results
    if args.output:
        try:
            with open(args.output, "w", encoding="utf-8") as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
            print(f"\n💾 Test results saved to: {args.output}")
        except Exception as e:
            print(f"\n❌ Failed to save results: {e}")

    # Exit with appropriate code
    if summary["failed_tests"] > 0:
        print(f"\n❌ Tests failed: {summary['failed_tests']} failures")
        sys.exit(1)
    else:
        print("\n✅ All tests passed!")
        sys.exit(0)


if __name__ == "__main__":
    main()
