#!/usr/bin/env python3
"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

SSL mode integration test for embedding service.
Tests SSL/TLS functionality with self-signed certificates.
"""

import json
import requests
import subprocess
import time
import signal
import os
import sys
from typing import Optional


class SSLModeTest:
    """
    Test class for SSL mode functionality.
    """

    def __init__(self):
        """Initialize test environment."""
        # Read port from config
        try:
            with open("config/ssl_config.json", "r") as f:
                config_data = json.load(f)
            port = config_data.get("server", {}).get("port", 10001)
        except Exception:
            port = 10001

        self.base_url = f"https://127.0.0.1:{port}"
        self.session = requests.Session()
        self.server_process: Optional[subprocess.Popen] = None
        self.test_results = []

        # Disable SSL verification for self-signed certificates
        self.session.verify = False
        import urllib3

        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        print("🔧 Test Configuration:")
        print(f"   • Base URL: {self.base_url}")
        print("   • Config: config/ssl_config.json")
        print("   • SSL Verification: Disabled (self-signed certs)")
        print()

    def log_test(self, test_name: str, success: bool, message: str):
        """Log test result."""
        self.test_results.append(
            {"test": test_name, "success": success, "message": message}
        )
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")

    def wait_for_server(self, timeout: int = 30) -> bool:
        """
        Wait for server to become ready.

        Args:
            timeout: Maximum time to wait in seconds

        Returns:
            True if server is ready
        """
        print("⏳ Waiting for server to start...")
        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                response = requests.get(
                    f"{self.base_url}/health", timeout=5, verify=False
                )
                if response.status_code == 200:
                    print(f"✅ Server is ready after {time.time() - start_time:.1f}s")
                    return True
            except requests.exceptions.RequestException:
                pass

            time.sleep(1)

        print("❌ Server not ready after", timeout, "s")
        return False

    def start_server(self) -> bool:
        """
        Start server in background process.

        Returns:
            True if server started successfully
        """
        try:
            # Kill any existing server processes
            subprocess.run(
                ["pkill", "-f", "python -m embed.server"],
                capture_output=True,
                check=False,
            )
            time.sleep(2)

            # Read port from config
            try:
                with open("config/ssl_config.json", "r") as f:
                    config_data = json.load(f)
                port = config_data.get("server", {}).get("port", 10001)
            except Exception:
                port = 10001

            print(f"🚀 Starting SSL server on port {port}...")

            # Start server in background
            cmd = [
                "bash",
                "-c",
                (
                    "source .venv/bin/activate && python -m embed.server "
                    f"--config config/ssl_config.json --host 127.0.0.1 "
                    f"--port {port} --debug"
                ),
            ]

            self.server_process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                preexec_fn=os.setsid,  # Create new process group
            )

            # Wait for server to be ready
            if self.wait_for_server():
                self.log_test(
                    "Server Start", True, f"SSL server started on port {port}"
                )
                return True
            else:
                self.log_test("Server Start", False, "SSL server failed to start")
                return False

        except Exception as e:
            self.log_test("Server Start", False, f"Failed to start SSL server: {e}")
            return False

    def stop_server(self):
        """Stop the running server."""
        if self.server_process:
            try:
                # Kill the entire process group
                os.killpg(os.getpgid(self.server_process.pid), signal.SIGTERM)
                self.server_process.wait(timeout=5)
            except (subprocess.TimeoutExpired, ProcessLookupError):
                # Force kill if graceful shutdown fails
                try:
                    os.killpg(os.getpgid(self.server_process.pid), signal.SIGKILL)
                except ProcessLookupError:
                    pass
            finally:
                self.server_process = None
                print("🛑 SSL server stopped")

    def test_health_endpoint(self) -> bool:
        """
        Test health endpoint over HTTPS.

        Returns:
            True if test passed
        """
        try:
            response = self.session.get(f"{self.base_url}/health")
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "ok":
                    self.log_test("Health Endpoint", True, "HTTPS health check passed")
                    return True
                else:
                    self.log_test("Health Endpoint", False, "Invalid health response")
                    return False
            else:
                self.log_test("Health Endpoint", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Health Endpoint", False, f"Error: {e}")
            return False

    def test_help_command(self) -> bool:
        """
        Test help command over HTTPS.

        Returns:
            True if test passed
        """
        try:
            payload = {"jsonrpc": "2.0", "method": "help", "params": {}, "id": 1}

            response = self.session.post(f"{self.base_url}/cmd", json=payload)
            if response.status_code == 200:
                data = response.json()
                if "result" in data:
                    self.log_test(
                        "Help Command", True, "HTTPS help command executed successfully"
                    )
                    return True
                else:
                    self.log_test("Help Command", False, f"Invalid response: {data}")
                    return False
            else:
                self.log_test("Help Command", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Help Command", False, f"Error: {e}")
            return False

    def test_embed_command(self) -> bool:
        """
        Test embed command over HTTPS.

        Returns:
            True if test passed
        """
        try:
            payload = {
                "jsonrpc": "2.0",
                "method": "embed",
                "params": {
                    "texts": ["Hello, world!"],
                    "model": "paraphrase-multilingual-MiniLM-L12-v2",
                },
                "id": 1,
            }

            response = self.session.post(f"{self.base_url}/cmd", json=payload)
            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    embeddings = data["result"].get("data", {}).get("embeddings", [])
                    if embeddings and len(embeddings[0]) > 0:
                        self.log_test(
                            "Embed Command",
                            True,
                            f"HTTPS embed generated {len(embeddings[0])} dimensions",
                        )
                        return True
                    else:
                        self.log_test(
                            "Embed Command", False, "Invalid embedding format"
                        )
                        return False
                else:
                    self.log_test("Embed Command", False, f"Invalid response: {data}")
                    return False
            else:
                self.log_test("Embed Command", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Embed Command", False, f"Error: {e}")
            return False

    def test_models_command(self) -> bool:
        """
        Test models command over HTTPS.

        Returns:
            True if test passed
        """
        try:
            payload = {"jsonrpc": "2.0", "method": "models", "params": {}, "id": 1}

            response = self.session.post(f"{self.base_url}/cmd", json=payload)
            if response.status_code == 200:
                data = response.json()
                if "result" in data and data["result"].get("success"):
                    models = data["result"].get("data", {}).get("models", [])
                    if isinstance(models, list) and len(models) > 0:
                        self.log_test(
                            "Models Command",
                            True,
                            f"HTTPS models found {len(models)} available",
                        )
                        return True
                    else:
                        self.log_test("Models Command", False, "No models found")
                        return False
                else:
                    self.log_test("Models Command", False, f"Invalid response: {data}")
                    return False
            else:
                self.log_test("Models Command", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Models Command", False, f"Error: {e}")
            return False

    def test_ssl_connection(self) -> bool:
        """
        Test SSL connection properties.

        Returns:
            True if test passed
        """
        try:
            response = self.session.get(f"{self.base_url}/health")
            if response.status_code == 200:
                # Check if we're actually using HTTPS
                if response.url.startswith("https://"):
                    self.log_test("SSL Connection", True, "Connection is using HTTPS")
                    return True
                else:
                    self.log_test(
                        "SSL Connection", False, "Connection is not using HTTPS"
                    )
                    return False
            else:
                self.log_test("SSL Connection", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("SSL Connection", False, f"Error: {e}")
            return False

    def test_invalid_command(self) -> bool:
        """
        Test invalid command handling over HTTPS.

        Returns:
            True if test passed
        """
        try:
            payload = {
                "jsonrpc": "2.0",
                "method": "invalid_command",
                "params": {},
                "id": 1,
            }

            response = self.session.post(f"{self.base_url}/cmd", json=payload)
            if response.status_code == 200:
                data = response.json()
                if "error" in data:
                    self.log_test(
                        "Invalid Command",
                        True,
                        "HTTPS properly handled invalid command",
                    )
                    return True
                else:
                    self.log_test(
                        "Invalid Command",
                        False,
                        "Should return error for invalid command",
                    )
                    return False
            else:
                self.log_test("Invalid Command", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Invalid Command", False, f"Error: {e}")
            return False

    def run_all_tests(self) -> bool:
        """
        Run all SSL mode tests.

        Returns:
            True if all tests passed
        """
        print("=" * 80)
        print("🔒 SSL MODE INTEGRATION TEST")
        print("=" * 80)

        try:
            # Start server
            if not self.start_server():
                return False

            # Run tests
            tests = [
                self.test_ssl_connection,
                self.test_health_endpoint,
                self.test_help_command,
                self.test_embed_command,
                self.test_models_command,
                self.test_invalid_command,
            ]

            all_passed = True
            for test in tests:
                if not test():
                    all_passed = False

            return all_passed

        finally:
            # Always stop server
            self.stop_server()

    def print_summary(self):
        """Print test summary."""
        print("\n" + "=" * 80)
        print("📊 TEST SUMMARY")
        print("=" * 80)

        passed = sum(1 for result in self.test_results if result["success"])
        total = len(self.test_results)

        print(f"Total tests: {total}")
        print(f"Passed: {passed}")
        print(f"Failed: {total - passed}")
        print(f"Success rate: {(passed/total)*100:.1f}%")

        if passed == total:
            print("\n🎉 ALL TESTS PASSED!")
        else:
            print("\n❌ SOME TESTS FAILED:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"   • {result['test']}: {result['message']}")


def main():
    """Main test runner."""
    test = SSLModeTest()

    try:
        success = test.run_all_tests()
        test.print_summary()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n🛑 Test interrupted by user")
        test.stop_server()
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Test failed with error: {e}")
        test.stop_server()
        sys.exit(1)


if __name__ == "__main__":
    main()
