#!/usr/bin/env python3
"""
Simple SSL test script.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

This script tests basic SSL functionality.
"""

import json
import requests
import time
import sys
import subprocess
from typing import Any
import urllib3

# Disable SSL warnings for testing
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class SimpleSSLTester:
    """
    Simple SSL tester.
    """

    def __init__(self):
        """
        Initialize tester.
        """
        # Read port from config
        try:
            with open("config/ssl_config.json", "r") as f:
                config_data = json.load(f)
            port = config_data.get("server", {}).get("port", 10001)
        except Exception:
            port = 10001

        self.base_url = f"https://127.0.0.1:{port}"
        self.session = requests.Session()
        self.test_results = []
        self.server_process = None

    def log_test(
        self, test_name: str, success: bool, message: str = "", data: Any = None
    ):
        """
        Log test result.
        """
        result = {
            "test": test_name,
            "success": success,
            "message": message,
            "data": data,
            "timestamp": time.time(),
        }
        self.test_results.append(result)

        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")

    def start_server(self) -> bool:
        """
        Start server with SSL configuration.
        """
        try:
            # Kill any existing server
            subprocess.run(
                ["pkill", "-f", "python -m embed.server"],
                capture_output=True,
                check=False,
            )
            time.sleep(2)

            # Read port from config
            try:
                with open("config/ssl_config.json", "r") as f:
                    config_data = json.load(f)
                port = config_data.get("server", {}).get("port", 10001)
            except Exception:
                port = 10001

            # Start server
            cmd = [
                "python",
                "-m",
                "embed.server",
                "--config",
                "config/ssl_config.json",
                "--host",
                "127.0.0.1",
                "--port",
                str(port),
                "--debug",
            ]

            self.server_process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )

            # Wait for server to start
            time.sleep(8)

            # Test if server is responding
            try:
                response = requests.get(
                    f"{self.base_url}/health", verify=False, timeout=10
                )
                if response.status_code == 200:
                    self.log_test(
                        "Server Start", True, f"SSL server started on port {port}"
                    )
                    return True
                else:
                    self.log_test(
                        "Server Start",
                        False,
                        f"Server not responding: {response.status_code}",
                    )
                    return False
            except requests.exceptions.RequestException as e:
                self.log_test("Server Start", False, f"Server not accessible: {e}")
                return False

        except Exception as e:
            self.log_test("Server Start", False, f"Failed to start server: {e}")
            return False

    def stop_server(self):
        """
        Stop the running server.
        """
        if self.server_process:
            self.server_process.terminate()
            self.server_process.wait()
            self.server_process = None

    def test_ssl_connection(self) -> bool:
        """
        Test basic SSL connection.
        """
        try:
            response = self.session.get(f"{self.base_url}/health", verify=False)
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "ok":
                    self.log_test("SSL Connection", True, "SSL connection works")
                    return True
                else:
                    self.log_test("SSL Connection", False, "Invalid response")
                    return False
            else:
                self.log_test(
                    "SSL Connection",
                    False,
                    f"HTTP {response.status_code}: {response.text}",
                )
                return False
        except Exception as e:
            self.log_test("SSL Connection", False, f"Error: {e}")
            return False

    def run_tests(self):
        """
        Run SSL tests.
        """
        print("🔒 Testing Simple SSL Mode")
        print("=" * 60)

        # Start server
        if not self.start_server():
            print("❌ Failed to start server")
            return None

        try:
            # Run tests
            self.test_ssl_connection()

        finally:
            # Stop server
            self.stop_server()

        # Calculate summary
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["success"])
        failed_tests = total_tests - passed_tests

        summary = {
            "mode": "ssl_simple",
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "success_rate": (
                (passed_tests / total_tests * 100) if total_tests > 0 else 0
            ),
            "results": self.test_results,
        }

        print("\n📊 SIMPLE SSL MODE TEST SUMMARY")
        print("=" * 60)
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {failed_tests}")
        print(f"Success Rate: {summary['success_rate']:.1f}%")

        return summary


def main():
    """
    Main function.
    """
    # Create tester
    tester = SimpleSSLTester()

    # Run tests
    summary = tester.run_tests()

    if summary is None:
        sys.exit(1)

    # Save results
    try:
        with open("ssl_simple_test_results.json", "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)
        print("\n💾 Test results saved to: ssl_simple_test_results.json")
    except Exception as e:
        print(f"\n❌ Failed to save results: {e}")

    # Exit with appropriate code
    if summary["failed_tests"] > 0:
        print(f"\n❌ Simple SSL tests failed: {summary['failed_tests']} failures")
        sys.exit(1)
    else:
        print("\n✅ All simple SSL tests passed!")
        sys.exit(0)


if __name__ == "__main__":
    main()
