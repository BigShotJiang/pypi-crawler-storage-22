"""
Stability tests for embedding service.

Author: Vasiliy Zdanovskiy
Email: vasilyvz@gmail.com
"""

import pytest
import asyncio
import time
import random


class TestStability:
    """Tests for service stability."""

    @pytest.mark.asyncio
    async def test_long_term_stability(self, client):
        """Test service stability over a long period."""
        num_iterations = 10
        batch_sizes = [1, 5, 10, 20]

        for i in range(num_iterations):
            # Randomly select batch size
            size = random.choice(batch_sizes)
            texts = [f"Test text {j}" for j in range(size)]

            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": texts},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            assert len(result["result"]["data"]["embeddings"]) == size

            # Add random delay between requests
            await asyncio.sleep(random.uniform(0.1, 0.5))

    @pytest.mark.asyncio
    async def test_error_handling_stability(self, client):
        """Test stability of error handling."""
        test_cases = [
            {"texts": []},  # Empty list
            {"texts": [""]},  # Empty string
            {"texts": [None]},  # None value
            {"texts": [123]},  # Non-string value
            {"texts": ["a" * 1000000]},  # Very long text
            {},  # Missing texts parameter
            {"texts": "not a list"},  # Invalid type
        ]

        for case in test_cases:
            response = client.post(
                "/api/jsonrpc",
                json={"jsonrpc": "2.0", "method": "embed", "params": case, "id": 1},
            )

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "error" in result["result"]
            error = result["result"]["error"]
            assert "code" in error
            assert "message" in error
            await asyncio.sleep(0.1)

    @pytest.mark.asyncio
    async def test_model_switching_stability(self, client):
        """Test stability when switching between models."""
        # First get available models
        models_response = client.post(
            "/api/jsonrpc", json={"jsonrpc": "2.0", "method": "models", "id": 1}
        )

        assert models_response.status_code == 200
        models_result = models_response.json()
        assert "result" in models_result
        assert "data" in models_result["result"]
        assert "models" in models_result["result"]["data"]

        models = models_result["result"]["data"]["models"]
        if len(models) > 1:
            # Test switching between models
            for model in models:
                response = client.post(
                    "/api/jsonrpc",
                    json={
                        "jsonrpc": "2.0",
                        "method": "embed",
                        "params": {"texts": ["Test text"], "model": model["name"]},
                        "id": 1,
                    },
                )

                assert response.status_code == 200
                result = response.json()
                assert "result" in result
                assert "data" in result["result"]
                assert "embeddings" in result["result"]["data"]
                assert len(result["result"]["data"]["embeddings"]) == 1

                await asyncio.sleep(0.1)

    @pytest.mark.asyncio
    async def test_concurrent_stability(self, client):
        """Test stability under concurrent load."""
        num_concurrent = 5
        num_requests_per_thread = 10

        async def worker():
            for _ in range(num_requests_per_thread):
                texts = [f"Concurrent test {i}" for i in range(5)]
                response = client.post(
                    "/api/jsonrpc",
                    json={
                        "jsonrpc": "2.0",
                        "method": "embed",
                        "params": {"texts": texts},
                        "id": 1,
                    },
                )

                assert response.status_code == 200
                result = response.json()
                assert "result" in result
                assert "data" in result["result"]
                assert "embeddings" in result["result"]["data"]
                assert len(result["result"]["data"]["embeddings"]) == len(texts)

                await asyncio.sleep(0.01)

        # Run concurrent workers
        tasks = [worker() for _ in range(num_concurrent)]
        await asyncio.gather(*tasks)

    @pytest.mark.asyncio
    async def test_memory_stability(self, client):
        """Test memory stability over time."""
        num_iterations = 20
        large_texts = ["Large text " + str(i) * 100 for i in range(10)]

        for _ in range(num_iterations):
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": large_texts},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            assert len(result["result"]["data"]["embeddings"]) == len(large_texts)

            await asyncio.sleep(0.1)

    @pytest.mark.asyncio
    async def test_response_consistency_stability(self, client):
        """Test consistency of responses over time."""
        text = "Consistency test text"
        responses = []

        for _ in range(20):
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": [text]},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            responses.append(result)

            await asyncio.sleep(0.05)

        # Check consistency
        first_response = responses[0]["result"]["data"]
        for response in responses[1:]:
            data = response["result"]["data"]
            assert data["model"] == first_response["model"]
            assert data["dimension"] == first_response["dimension"]
            assert len(data["embeddings"]) == 1

    @pytest.mark.asyncio
    async def test_error_recovery_stability(self, client):
        """Test stability of error recovery."""
        # Make multiple error requests followed by valid requests
        for _ in range(10):
            # Error request
            error_response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": []},
                    "id": 1,
                },
            )

            assert error_response.status_code == 200
            error_result = error_response.json()
            assert "result" in error_result
            assert "error" in error_result["result"]

            # Valid request
            valid_response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": ["Valid text"]},
                    "id": 1,
                },
            )

            assert valid_response.status_code == 200
            valid_result = valid_response.json()
            assert "result" in valid_result
            assert "data" in valid_result["result"]
            assert "embeddings" in valid_result["result"]["data"]

            await asyncio.sleep(0.1)

    @pytest.mark.asyncio
    async def test_mixed_workload_stability(self, client):
        """Test stability under mixed workload."""
        workload_types = [
            {"texts": ["Short text"]},
            {"texts": ["Medium length text " * 10]},
            {"texts": ["Long text " * 100]},
            {"texts": ["Text " + str(i) for i in range(20)]},
            {"texts": []},  # Error case
        ]

        for _ in range(10):
            for workload in workload_types:
                response = client.post(
                    "/api/jsonrpc",
                    json={
                        "jsonrpc": "2.0",
                        "method": "embed",
                        "params": workload,
                        "id": 1,
                    },
                )

                assert response.status_code == 200
                result = response.json()
                assert "result" in result

                if "texts" in workload and workload["texts"]:
                    assert "data" in result["result"]
                    assert "embeddings" in result["result"]["data"]
                else:
                    assert "error" in result["result"]

                await asyncio.sleep(0.05)

    @pytest.mark.asyncio
    async def test_continuous_operation_stability(self, client):
        """Test stability during continuous operation."""
        start_time = time.time()
        max_duration = 30  # 30 seconds
        request_count = 0

        while time.time() - start_time < max_duration:
            # Random workload
            if random.random() < 0.8:  # 80% valid requests
                texts = [f"Continuous test {request_count}"]
                response = client.post(
                    "/api/jsonrpc",
                    json={
                        "jsonrpc": "2.0",
                        "method": "embed",
                        "params": {"texts": texts},
                        "id": 1,
                    },
                )

                assert response.status_code == 200
                result = response.json()
                assert "result" in result
                assert "data" in result["result"]
                assert "embeddings" in result["result"]["data"]
            else:  # 20% error requests
                response = client.post(
                    "/api/jsonrpc",
                    json={
                        "jsonrpc": "2.0",
                        "method": "embed",
                        "params": {"texts": []},
                        "id": 1,
                    },
                )

                assert response.status_code == 200
                result = response.json()
                assert "result" in result
                assert "error" in result["result"]

            request_count += 1
            await asyncio.sleep(0.1)

        # Ensure we made a reasonable number of requests
        assert request_count > 50

    @pytest.mark.asyncio
    async def test_resource_cleanup_stability(self, client):
        """Test stability of resource cleanup."""
        # Make heavy requests followed by light requests
        for _ in range(5):
            # Heavy request
            heavy_texts = ["Heavy text " + str(i) * 200 for i in range(50)]
            heavy_response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": heavy_texts},
                    "id": 1,
                },
            )

            assert heavy_response.status_code == 200
            heavy_result = heavy_response.json()
            assert "result" in heavy_result
            assert "data" in heavy_result["result"]
            assert "embeddings" in heavy_result["result"]["data"]

            await asyncio.sleep(0.5)  # Allow cleanup time

            # Light request
            light_response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": ["Light text"]},
                    "id": 1,
                },
            )

            assert light_response.status_code == 200
            light_result = light_response.json()
            assert "result" in light_result
            assert "data" in light_result["result"]
            assert "embeddings" in light_result["result"]["data"]

    @pytest.mark.asyncio
    async def test_model_persistence_stability(self, client):
        """Test stability of model persistence."""
        # Make multiple requests to ensure model stays loaded
        for _ in range(20):
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": ["Persistence test"]},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            assert "model" in result["result"]["data"]

            # Check model consistency
            model_name = result["result"]["data"]["model"]
            assert isinstance(model_name, str)
            assert len(model_name) > 0

            await asyncio.sleep(0.05)

    @pytest.mark.asyncio
    async def test_dimension_consistency_stability(self, client):
        """Test stability of embedding dimensions."""
        # Make multiple requests and check dimension consistency
        dimensions = set()

        for _ in range(20):
            response = client.post(
                "/api/jsonrpc",
                json={
                    "jsonrpc": "2.0",
                    "method": "embed",
                    "params": {"texts": ["Dimension test"]},
                    "id": 1,
                },
            )

            assert response.status_code == 200
            result = response.json()
            assert "result" in result
            assert "data" in result["result"]
            assert "embeddings" in result["result"]["data"]
            assert "dimension" in result["result"]["data"]

            dimension = result["result"]["data"]["dimension"]
            dimensions.add(dimension)

            # Check embedding length matches dimension
            embeddings = result["result"]["data"]["embeddings"]
            assert len(embeddings) == 1
            assert len(embeddings[0]) == dimension

            await asyncio.sleep(0.05)

        # All dimensions should be the same
        assert len(dimensions) == 1

    @pytest.mark.asyncio
    async def test_unicode_stability(self, client):
        """Test stability with unicode text."""
        unicode_texts = [
            "Привет мир!",
            "你好世界！",
            "こんにちは世界！",
            "안녕하세요 세계!",
            "مرحبا بالعالم!",
            "नमस्ते दुनिया!",
            "สวัสดีชาวโลก!",
            "Γεια σου κόσμε!",
            "¡Hola mundo!",
            "Hello world! 🌍",
        ]

        for _ in range(10):
            for text in unicode_texts:
                response = client.post(
                    "/api/jsonrpc",
                    json={
                        "jsonrpc": "2.0",
                        "method": "embed",
                        "params": {"texts": [text]},
                        "id": 1,
                    },
                )

                assert response.status_code == 200
                result = response.json()
                assert "result" in result
                assert "data" in result["result"]
                assert "embeddings" in result["result"]["data"]
                assert len(result["result"]["data"]["embeddings"]) == 1

            await asyncio.sleep(0.1)
