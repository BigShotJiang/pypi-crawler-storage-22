# embeddr

Meta package that installs the Embeddr CLI.

## Install

```bash
uv tool install embeddr
```

## Use

```bash
embeddr --help
```
