"""Meta package for the Embeddr CLI."""
