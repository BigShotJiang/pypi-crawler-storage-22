# Copyright (C) 2025 Embedl AB

"""
Module defining common CLI command options for embedl-hub.
"""

import typer

PROJECT_NAME_OPTION = typer.Option(
    None,
    "--project-name",
    "-pn",
    help="Name of the project to use for the run. (Overrides context set with 'embedl-hub init')",
)

EXPERIMENT_NAME_OPTION = typer.Option(
    None,
    "--experiment-name",
    "-en",
    help="Name of the experiment to use for the run. (Overrides context set with 'embedl-hub init')",
)

RUN_NAME_OPTION = typer.Option(
    None,
    "--run-name",
    "-rn",
    help="Optional name for the run. (If not set, a random name will be generated)",
)
