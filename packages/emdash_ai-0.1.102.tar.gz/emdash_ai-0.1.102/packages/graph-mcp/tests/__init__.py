"""Tests for emdash-graph-mcp."""
