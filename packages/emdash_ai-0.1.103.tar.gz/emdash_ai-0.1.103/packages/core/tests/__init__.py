"""Tests for emdash-core."""
