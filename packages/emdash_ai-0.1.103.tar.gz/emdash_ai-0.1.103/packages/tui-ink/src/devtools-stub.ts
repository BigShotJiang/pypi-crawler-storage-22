// Stub for react-devtools-core - not needed in production bundle
export default {
  connectToDevTools: () => {},
};
