# emdash-web-tools-mcp

MCP server providing web search and fetch tools for the emdash CLI.

## Tools

### web_search

Search the web using various providers:
- **DuckDuckGo** (default) - No API key required
- **Brave Search** - Requires `BRAVE_API_KEY`
- **Serper.dev** - Requires `SERPER_API_KEY`

### web_fetch

Fetch URL content and convert HTML to markdown. Handles:
- Automatic HTTPS upgrade
- Redirect following
- Content truncation for large pages
- Multiple content types (HTML, text, JSON)

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `WEB_SEARCH_PROVIDER` | `duckduckgo` | Search provider (duckduckgo/brave/serper) |
| `BRAVE_API_KEY` | - | API key for Brave Search |
| `SERPER_API_KEY` | - | API key for Serper.dev |
| `WEB_TOOLS_TIMEOUT` | 30 | Request timeout in seconds |
| `WEB_TOOLS_MAX_CONTENT` | 50000 | Max content length for fetch |

## Usage

The server runs over stdio and is typically started by the emdash CLI:

```bash
emdash-web-tools-mcp
```

## Development

```bash
# Install with dev dependencies
uv pip install -e ".[dev]"

# Run tests
pytest
```
