# emdash-server

Multi-tenant control plane for emdash-core. Each user gets their own isolated Fly.io machine.

## URLs

- **Control Plane**: https://emdash-control-plane.fly.dev
- **Workers App**: https://emdash-workers.fly.dev

## API

### Authentication

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/auth/github/login` | GET | Start GitHub OAuth |
| `/api/auth/github/me` | GET | Get current user |
| `/api/auth/github/logout` | POST | Logout |

### Machine Management

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/machines/me` | GET | Get or create your machine |
| `/api/machines/me/start` | POST | Start stopped machine |
| `/api/machines/me/stop` | POST | Stop running machine |
| `/api/machines/me` | DELETE | Destroy machine |

### Proxy to Your Machine

All `/api/user/*` requests are proxied to your dedicated machine.

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/user/health` | GET | Machine health status |
| `/api/user/agent/chat` | POST | Chat with AI agent (SSE) |

## Usage

1. **Login**: https://emdash-control-plane.fly.dev/api/auth/github/login

2. **Create machine**: https://emdash-control-plane.fly.dev/api/machines/me

3. **Use your machine**: https://emdash-control-plane.fly.dev/api/user/health

### Chat Example

```bash
curl -X POST https://emdash-control-plane.fly.dev/api/user/agent/chat \
  -H "Content-Type: application/json" \
  -H "Cookie: session_id=YOUR_SESSION" \
  -d '{"message": "Hello"}'
```

## Local Development

```bash
# Install
uv sync --package emdash-server

# Run
emdash-server --port 8080
```

## Deployment

```bash
# Deploy control plane
fly deploy -c fly.server.toml

# Set secrets
fly secrets set EMDASH_SERVER_FLY_API_TOKEN="..." -a emdash-control-plane
fly secrets set EMDASH_SERVER_GITHUB_CLIENT_ID="..." -a emdash-control-plane
fly secrets set EMDASH_SERVER_GITHUB_CLIENT_SECRET="..." -a emdash-control-plane
```
