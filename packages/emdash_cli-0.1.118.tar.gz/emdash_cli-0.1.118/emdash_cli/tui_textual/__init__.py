"""Textual TUI for EmDash — rich terminal interface in pure Python."""

from .app import EmDashApp, run_textual_tui

__all__ = ["EmDashApp", "run_textual_tui"]
