"""EmDash Textual TUI — main application entry point.

This replaces the Ink (Node.js) TUI with a pure-Python Textual app
that communicates with the FastAPI backend via the same handler
interface used by ``bridge.py``.
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import AsyncIterator, Callable

from textual.app import App
from textual.binding import Binding

from .client import SSEClient
from .screens.chat import ChatScreen
from .screens.kanban import KanbanScreen
from .screens.settings import SettingsScreen
from .state import AppState, Message
from .widgets.command_palette import EmDashCommandProvider

log = logging.getLogger(__name__)

CSS_PATH = Path(__file__).parent / "styles.tcss"


class EmDashApp(App):
    """EmDash Textual TUI application."""

    TITLE = "EmDash"
    SUB_TITLE = "AI Coding Agent"
    CSS_PATH = CSS_PATH
    COMMANDS = {EmDashCommandProvider}

    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit", priority=True),
        Binding("ctrl+c", "cancel", "Cancel", priority=True),
        Binding("escape", "escape_key", "Escape", show=False, priority=True),
        Binding("ctrl+l", "clear", "Clear", show=False),
        Binding("ctrl+k", "push_screen('settings')", "Settings", show=False),
        Binding("ctrl+b", "push_screen('kanban')", "Kanban", show=False),
        Binding("ctrl+n", "new_session", "New Session", show=False),
    ]

    SCREENS = {
        "settings": SettingsScreen,
        "kanban": KanbanScreen,
        "chat": ChatScreen,
    }

    def __init__(
        self,
        handler: Callable,
        model: str = "claude-sonnet-4",
        mode: str = "code",
        initial_task: str | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.state = AppState(model=model, mode=mode)
        self.sse_client = SSEClient(handler=handler, model=model, mode=mode)
        self._initial_task = initial_task

    def on_mount(self) -> None:
        """Push the chat screen and process initial task if provided."""
        self.push_screen(ChatScreen())
        if self._initial_task:
            asyncio.create_task(self._run_initial_task())

    async def _run_initial_task(self) -> None:
        """Send the initial task as a user message."""
        # Use self.screen since ChatScreen was just pushed
        if not isinstance(self.screen, ChatScreen):
            return
        chat = self.screen
        msg = Message(role="user", content=self._initial_task)
        self.state.messages.append(msg)
        from .widgets.message_list import MessageList
        chat.query_one(MessageList).add_message(msg)
        # Yield to let Textual render the user message first
        await asyncio.sleep(0)
        await chat._process_message(self._initial_task)

    # ── actions ─────────────────────────────────────────────────────────

    def action_cancel(self) -> None:
        """Cancel the current running request."""
        if self.state.processing:
            self.sse_client.cancel()
            self.state.processing = False
            # Update UI feedback
            try:
                if isinstance(self.screen, ChatScreen):
                    chat = self.screen
                    from .widgets.message_list import MessageList
                    from .widgets.status_bar import StatusBar
                    from .widgets.input_bar import InputBar
                    msg_list = chat.query_one(MessageList)
                    msg_list.add_message(Message(role="system", content="Cancelled."))
                    chat.query_one(StatusBar).processing = False
                    input_bar = chat.query_one(InputBar)
                    input_bar.set_disabled(False)
                    input_bar.text_area.focus()
            except Exception:
                pass

    def action_escape_key(self) -> None:
        """Handle Escape: dismiss overlays first, then cancel processing."""
        # Check if there's a modal screen on top of ChatScreen (settings, kanban)
        # Only pop if we have more than just ChatScreen
        from .screens.chat import ChatScreen as CS
        if len(self.screen_stack) > 1 and not isinstance(self.screen, CS):
            self.pop_screen()
            return

        # Check if any overlay widget is visible (ConfigWizard, RegistryBrowser, ChoicePrompt, PlanViewer)
        try:
            if isinstance(self.screen, ChatScreen):
                from .widgets.config_wizard import ConfigWizard
                from .widgets.registry_browser import RegistryBrowser
                from .widgets.choice_prompt import ChoicePrompt
                from .widgets.plan_viewer import PlanViewer

                chat = self.screen
                for widget_cls in (ConfigWizard, RegistryBrowser, ChoicePrompt, PlanViewer):
                    try:
                        chat.query_one(widget_cls)
                        # Let the widget handle its own Escape
                        return
                    except Exception:
                        pass
        except Exception:
            pass

        # No overlay — cancel processing if active
        if self.state.processing:
            self.action_cancel()

    def action_clear(self) -> None:
        """Clear the chat display."""
        try:
            if isinstance(self.screen, ChatScreen):
                from .widgets.message_list import MessageList
                self.screen.query_one(MessageList).clear_messages()
        except Exception:
            pass

    def action_new_session(self) -> None:
        """Start a new session."""
        self.sse_client.reset_session()
        self.state.session_id = None
        self.state.messages.clear()
        self.action_clear()
        self.notify("New session")

    # ── slash command dispatch ──────────────────────────────────────────

    def handle_slash_command(self, cmd: str) -> None:
        """Execute a slash command by sending it as a message."""
        # Some commands are handled locally
        if cmd == "/clear":
            self.action_clear()
            return
        if cmd == "/kanban":
            self.push_screen("kanban")
            return
        if cmd == "/settings":
            self.push_screen("settings")
            return
        if cmd == "/plan":
            self.sse_client.set_mode("plan")
            self.state.mode = "plan"
            try:
                from .widgets.status_bar import StatusBar
                self.query_one(StatusBar).mode = "plan"
            except Exception:
                pass
            self.notify("Mode: plan")
            return
        if cmd == "/code":
            self.sse_client.set_mode("code")
            self.state.mode = "code"
            try:
                from .widgets.status_bar import StatusBar
                self.query_one(StatusBar).mode = "code"
            except Exception:
                pass
            self.notify("Mode: code")
            return
        if cmd == "/reset":
            self.action_new_session()
            return
        if cmd == "/model":
            self.push_screen("settings")
            return

        # All other slash commands go to the backend handler
        # Get the ChatScreen - it may be the current screen or we need to switch to it
        if isinstance(self.screen, ChatScreen):
            chat = self.screen
        else:
            # Pop back to chat screen if we're on another screen
            while not isinstance(self.screen, ChatScreen) and len(self.screen_stack) > 1:
                self.pop_screen()
            if not isinstance(self.screen, ChatScreen):
                self.notify("Cannot run command: not on chat screen", severity="error")
                return
            chat = self.screen

        self.state.messages.append(Message(role="user", content=cmd))
        from .widgets.message_list import MessageList
        chat.query_one(MessageList).add_message(Message(role="user", content=cmd))
        asyncio.create_task(chat._process_message(cmd))


async def run_textual_tui(
    on_submit: Callable[[str], AsyncIterator[dict]],
    model: str | None = None,
    mode: str = "code",
    task: str | None = None,
) -> None:
    """Run the Textual TUI with the given handler.

    Drop-in replacement for ``run_ink_tui`` — same signature.

    Args:
        on_submit: Async callable that takes a message and yields event dicts.
        model: Model name to use.
        mode: Agent mode (code or plan).
        task: Optional initial task to run immediately.
    """
    model = model or os.environ.get("EMDASH_MODEL", "claude-sonnet-4")

    app = EmDashApp(
        handler=on_submit,
        model=model,
        mode=mode,
        initial_task=task,
    )
    await app.run_async()
