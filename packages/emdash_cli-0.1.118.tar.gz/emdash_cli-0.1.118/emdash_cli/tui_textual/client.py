"""SSE streaming client for the Textual TUI.

Replaces the Ink bridge.py JSON-over-pipes approach with direct async
HTTP streaming to the FastAPI backend.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, AsyncIterator, Callable, Optional

import httpx

if TYPE_CHECKING:
    from .app import EmDashApp

log = logging.getLogger(__name__)


class SSEClient:
    """Async SSE client that dispatches events back to the Textual app.

    This is a thin wrapper around the same ``create_agent_handler``
    used by the Ink bridge — it reuses the handler's async-iterator
    interface so all slash-command logic, session management, and model
    switching work identically.
    """

    def __init__(
        self,
        handler: Callable,
        model: str,
        mode: str,
    ):
        self.handler = handler
        self.model = model
        self.mode = mode
        self._cancel_event = asyncio.Event()

    # ── public API ──────────────────────────────────────────────────────

    async def send_message(self, content: str, images: list[dict] | None = None) -> AsyncIterator[dict]:
        """Send a user message and yield raw event dicts from the handler."""
        self._cancel_event.clear()
        try:
            async for event in self.handler(content, images):
                if self._cancel_event.is_set():
                    break
                yield event
        except Exception as exc:
            yield {"type": "error", "data": {"message": str(exc)}}

    async def approve_plan(
        self, approved: bool, reply: str | None = None, approval_type: str = "planmode"
    ) -> AsyncIterator[dict]:
        """Approve or reject a plan and yield continuation events."""
        if hasattr(self.handler, "approve_plan_mode"):
            async for event in self.handler.approve_plan_mode(approved, reply, approval_type):
                yield event

    def cancel(self) -> None:
        """Signal the current request to stop."""
        self._cancel_event.set()
        if hasattr(self.handler, "abort_session"):
            asyncio.ensure_future(self.handler.abort_session())

    def reset_session(self) -> None:
        if hasattr(self.handler, "reset_session"):
            self.handler.reset_session()

    def set_mode(self, mode: str) -> None:
        self.mode = mode
        if hasattr(self.handler, "set_mode"):
            self.handler.set_mode(mode)

    def set_model(self, model: str) -> None:
        self.model = model
        if hasattr(self.handler, "set_model"):
            self.handler.set_model(model)
