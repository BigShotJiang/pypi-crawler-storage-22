"""Protocol types for communication between the Textual TUI and the backend.

Mirrors the event types from packages/tui-ink/src/protocol.ts but as
Python dataclasses consumed directly — no JSON serialisation needed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ── Incoming events (backend → TUI) ────────────────────────────────────────

@dataclass
class InitEvent:
    model: str
    mode: str
    cwd: str


@dataclass
class ChatChunkEvent:
    content: str


@dataclass
class ChatCompleteEvent:
    pass


@dataclass
class ChatMessageEvent:
    content: str
    role: str = "assistant"


@dataclass
class ThinkingEvent:
    content: str


@dataclass
class ResponseEvent:
    content: str


@dataclass
class PartialResponseEvent:
    content: str


@dataclass
class ErrorEvent:
    message: str


@dataclass
class SessionStartEvent:
    session_id: str


@dataclass
class ToolStartEvent:
    name: str
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolResultEvent:
    name: str
    success: bool
    result: str | None = None


@dataclass
class ProgressEvent:
    message: str
    percent: float | None = None


@dataclass
class SubagentStartEvent:
    agent_type: str
    prompt: str


@dataclass
class SubagentEndEvent:
    agent_type: str
    success: bool


@dataclass
class PlanModeRequestedEvent:
    reason: str


@dataclass
class PlanSubmittedEvent:
    plan: str


@dataclass
class AskChoiceQuestionsEvent:
    questions: list[dict[str, Any]]


@dataclass
class ClarificationRequestEvent:
    question: str
    options: list[str] | None = None


@dataclass
class RequestApprovalEvent:
    context: dict[str, Any] | None = None


@dataclass
class SetProcessingEvent:
    processing: bool


@dataclass
class SetModeEvent:
    mode: str


@dataclass
class SetModelEvent:
    model: str


@dataclass
class UpdateAvailableModelsEvent:
    models: list[str]


@dataclass
class HistoryStartEvent:
    count: int


@dataclass
class HistoryMessageEvent:
    role: str
    content: str
    display_name: str | None = None


@dataclass
class HistoryEndEvent:
    pass


# ── Multiuser events ───────────────────────────────────────────────────────

@dataclass
class MultiuserStartedEvent:
    session_id: str
    user_id: str
    server_url: str
    is_owner: bool


@dataclass
class MultiuserStoppedEvent:
    pass


@dataclass
class ParticipantJoinedEvent:
    display_name: str
    user_id: str | None = None


@dataclass
class ParticipantLeftEvent:
    display_name: str
    user_id: str | None = None


@dataclass
class UserTypingEvent:
    user_id: str
    display_name: str


@dataclass
class UserStoppedTypingEvent:
    user_id: str


@dataclass
class AgentTypingEvent:
    is_typing: bool


# ── Registry/browse events ─────────────────────────────────────────────────

@dataclass
class RegistryBrowseEvent:
    skills: dict[str, Any]
    rules: dict[str, Any]
    agents: dict[str, Any]
    verifiers: dict[str, Any]


@dataclass
class SkillsBrowseEvent:
    skills: list[dict[str, Any]]


@dataclass
class RulesBrowseEvent:
    rules: list[dict[str, Any]]


@dataclass
class ProjectBrowseEvent:
    projects: list[dict[str, Any]]
    tasks: list[dict[str, Any]]
    sessions: list[dict[str, Any]]
    agents: list[dict[str, Any]]
    skills: list[dict[str, Any]]
    current_user_id: str | None = None
    current_session_id: str | None = None


# ── Helpers ─────────────────────────────────────────────────────────────────

EVENT_TYPE_MAP: dict[str, type] = {
    "init": InitEvent,
    "chat_chunk": ChatChunkEvent,
    "chat_complete": ChatCompleteEvent,
    "chat_message": ChatMessageEvent,
    "thinking": ThinkingEvent,
    "response": ResponseEvent,
    "partial_response": PartialResponseEvent,
    "error": ErrorEvent,
    "session_start": SessionStartEvent,
    "tool_start": ToolStartEvent,
    "tool_result": ToolResultEvent,
    "progress": ProgressEvent,
    "subagent_start": SubagentStartEvent,
    "subagent_end": SubagentEndEvent,
    "plan_mode_requested": PlanModeRequestedEvent,
    "plan_submitted": PlanSubmittedEvent,
    "ask_choice_questions": AskChoiceQuestionsEvent,
    "clarification_request": ClarificationRequestEvent,
    "request_approval": RequestApprovalEvent,
    "set_processing": SetProcessingEvent,
    "set_mode": SetModeEvent,
    "set_model": SetModelEvent,
    "update_available_models": UpdateAvailableModelsEvent,
    "history_start": HistoryStartEvent,
    "history_message": HistoryMessageEvent,
    "history_end": HistoryEndEvent,
    "multiuser_started": MultiuserStartedEvent,
    "multiuser_stopped": MultiuserStoppedEvent,
    "participant_joined": ParticipantJoinedEvent,
    "participant_left": ParticipantLeftEvent,
    "user_typing": UserTypingEvent,
    "user_stopped_typing": UserStoppedTypingEvent,
    "agent_typing": AgentTypingEvent,
    "registry_browse": RegistryBrowseEvent,
    "skills_browse": SkillsBrowseEvent,
    "rules_browse": RulesBrowseEvent,
    "project_browse": ProjectBrowseEvent,
}


def parse_event(event_type: str, data: dict[str, Any]) -> Any:
    """Parse a raw event dict into a typed dataclass, or return the raw dict."""
    cls = EVENT_TYPE_MAP.get(event_type)
    if cls is None:
        return data
    try:
        return cls(**data)
    except TypeError:
        return data
