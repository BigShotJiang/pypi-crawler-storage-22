"""Main chat screen — the primary interactive view."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Static

from ..state import Message
from ..widgets.choice_prompt import ChoicePrompt
from ..widgets.config_wizard import ConfigWizard
from ..widgets.input_bar import InputBar
from ..widgets.message_list import MessageList
from ..widgets.plan_viewer import PlanViewer
from ..widgets.registry_browser import RegistryBrowser
from ..widgets.status_bar import StatusBar
from ..widgets.thinking import ThinkingBlock
from ..widgets.tool_tracker import ToolExecution

if TYPE_CHECKING:
    from ..app import EmDashApp

log = logging.getLogger(__name__)


class ChatScreen(Screen):
    """Interactive chat with the EmDash agent."""

    DEFAULT_CSS = """
    ChatScreen {
        layout: vertical;
    }
    ChatScreen CommandMenu {
        layer: overlay;
        dock: bottom;
        margin-bottom: 3;
        margin-left: 2;
        margin-right: 2;
    }
    ChatScreen FileMenu {
        layer: overlay;
        dock: bottom;
        margin-bottom: 3;
        margin-left: 2;
        margin-right: 2;
    }
    """

    def compose(self) -> ComposeResult:
        from ..widgets.input_bar import CommandMenu, FileMenu
        yield StatusBar()
        yield MessageList()
        yield InputBar()
        # Menus on overlay layer, docked to bottom above input
        yield CommandMenu(id="command-menu")
        yield FileMenu(id="file-menu")

    @property
    def emdash_app(self) -> "EmDashApp":
        return self.app  # type: ignore[return-value]

    # ── event handlers ──────────────────────────────────────────────────

    def on_mount(self) -> None:
        state = self.emdash_app.state
        sb = self.query_one(StatusBar)
        sb.model = state.model
        sb.mode = state.mode
        # Propagate mode to input bar for color theming
        self.query_one(InputBar).mode = state.mode
        # Welcome message so screen isn't empty
        self.query_one(MessageList).add_message(Message(
            role="system",
            content=f"EmDash — model: {state.model}, mode: {state.mode}. Type a message or use / commands.",
        ))

    def on_input_bar_submitted(self, event: InputBar.Submitted) -> None:
        """Handle user message submission."""
        content = event.content
        state = self.emdash_app.state

        # Build image list from attachments
        images = None
        if event.attachments:
            images = [
                {"path": att.path, "name": att.name}
                for att in event.attachments
                if att.is_image
            ]

        # Add user message to list
        msg = Message(role="user", content=content)
        state.messages.append(msg)
        self.query_one(MessageList).add_message(msg)

        # Process message
        asyncio.create_task(self._process_message(content, images=images))

    async def _process_message(self, content: str, images: list[dict] | None = None) -> None:
        """Stream agent response via the SSE client."""
        client = self.emdash_app.sse_client
        state = self.emdash_app.state
        msg_list = self.query_one(MessageList)
        input_bar = self.query_one(InputBar)
        status_bar = self.query_one(StatusBar)

        state.processing = True
        status_bar.processing = True
        input_bar.set_disabled(True)

        accumulated_content = ""
        streaming_started = False
        current_thinking: ThinkingBlock | None = None
        # Track tools by ID to handle concurrent tool calls
        active_tools: dict[str, ToolExecution] = {}
        tool_counter = 0
        subagent_depth = 0

        log.debug(f"Processing message: {content[:50]}...")
        event_count = 0

        # Yield immediately to let Textual render UI changes (user message, disabled input)
        await asyncio.sleep(0)

        try:
            async for event in client.send_message(content, images=images):
                event_count += 1
                log.debug(f"Event #{event_count}: type={event.get('type', 'unknown')}")
                event_type = event.get("type", "")
                data = event.get("data", {})

                # Yield to event loop for UI updates on every event
                await asyncio.sleep(0)

                if event_type == "session_start":
                    sid = data.get("session_id", "")
                    state.session_id = sid
                    status_bar.session_id = sid

                elif event_type == "thinking":
                    text = data.get("content") or data.get("message", "")
                    if text:
                        if current_thinking is None:
                            current_thinking = ThinkingBlock(initial_content=text)
                            msg_list.mount(current_thinking)
                            msg_list.scroll_end(animate=False)
                            await asyncio.sleep(0)  # Yield to render
                        else:
                            current_thinking.content = text

                elif event_type == "tool_start":
                    name = data.get("name", "unknown")
                    args = data.get("args", {})
                    tool_id = data.get("tool_id") or data.get("id") or f"tool_{tool_counter}"
                    tool_counter += 1

                    # Special handling for ask_choice_questions - show interactive widget
                    if name == "ask_choice_questions":
                        questions = args.get("questions", [])
                        for q in questions:
                            prompt = ChoicePrompt(
                                question=q.get("question", ""),
                                options=q.get("options", []),
                                question_id=q.get("id"),
                                multi_select=q.get("multiSelect", False),
                            )
                            msg_list.mount(prompt)
                        msg_list.scroll_end(animate=False)
                        # Don't show as regular tool
                        continue

                    tool_widget = ToolExecution(name, args, depth=subagent_depth)
                    active_tools[tool_id] = tool_widget
                    msg_list.mount(tool_widget)
                    msg_list.scroll_end(animate=False)
                    await asyncio.sleep(0)  # Yield to render

                elif event_type == "tool_result":
                    tool_id = data.get("tool_id") or data.get("id")
                    # Try to find the tool by ID, or use the most recent one
                    tool_widget = None
                    if tool_id and tool_id in active_tools:
                        tool_widget = active_tools.pop(tool_id)
                    elif active_tools:
                        # Fallback: use the oldest active tool (FIFO)
                        oldest_id = next(iter(active_tools))
                        tool_widget = active_tools.pop(oldest_id)

                    if tool_widget is not None:
                        tool_widget.set_result(
                            success=data.get("success", True),
                            result=data.get("result"),
                        )

                elif event_type in ("chat_chunk", "partial_response"):
                    chunk = data.get("content", "")
                    if chunk:
                        if not streaming_started:
                            streaming_started = True
                            if current_thinking:
                                current_thinking.collapse()
                                current_thinking = None
                            msg_list.start_streaming()
                            await asyncio.sleep(0)  # Yield to render
                        accumulated_content += chunk
                        msg_list.update_streaming(accumulated_content)

                elif event_type == "response":
                    resp_content = data.get("content", "")
                    if resp_content:
                        if streaming_started:
                            msg_list.finish_streaming(resp_content)
                        else:
                            if current_thinking:
                                current_thinking.collapse()
                                current_thinking = None
                            msg = Message(role="assistant", content=resp_content)
                            state.messages.append(msg)
                            msg_list.add_message(msg)
                        accumulated_content = ""
                        streaming_started = False
                        # Re-enable input on response
                        state.processing = False
                        status_bar.processing = False
                        self._reenable_input()

                elif event_type == "chat_complete":
                    if streaming_started and accumulated_content:
                        msg_list.finish_streaming(accumulated_content)
                        msg = Message(role="assistant", content=accumulated_content)
                        state.messages.append(msg)
                        accumulated_content = ""
                        streaming_started = False
                    if current_thinking:
                        current_thinking.collapse()
                        current_thinking = None
                    # Re-enable input
                    state.processing = False
                    status_bar.processing = False
                    self._reenable_input()

                elif event_type == "error":
                    error_msg = data.get("message", "Unknown error")
                    msg_list.add_message(Message(role="system", content=f"Error: {error_msg}"))

                elif event_type == "plan_mode_requested":
                    reason = data.get("reason", "Agent wants to switch to plan mode.")
                    viewer = PlanViewer(plan=reason, approval_type="planmode")
                    msg_list.mount(viewer)
                    msg_list.scroll_end(animate=False)

                elif event_type == "plan_submitted":
                    plan_text = data.get("plan", "")
                    viewer = PlanViewer(plan=plan_text, approval_type="plan")
                    msg_list.mount(viewer)
                    msg_list.scroll_end(animate=False)

                elif event_type == "ask_choice_questions":
                    questions = data.get("questions", [])
                    for q in questions:
                        prompt = ChoicePrompt(
                            question=q.get("question", ""),
                            options=q.get("options", []),
                            question_id=q.get("id"),
                        )
                        msg_list.mount(prompt)
                        msg_list.scroll_end(animate=False)

                elif event_type == "clarification_request":
                    question = data.get("question", "")
                    options = data.get("options", [])
                    option_dicts = [{"label": o} for o in options] if options else []
                    prompt = ChoicePrompt(
                        question=question,
                        options=option_dicts,
                    )
                    msg_list.mount(prompt)
                    msg_list.scroll_end(animate=False)

                elif event_type == "set_processing":
                    state.processing = data.get("processing", False)
                    status_bar.processing = state.processing

                elif event_type == "set_mode":
                    new_mode = data.get("mode", "code")
                    state.mode = new_mode
                    status_bar.mode = new_mode
                    input_bar.mode = new_mode

                elif event_type == "set_model":
                    new_model = data.get("model", "")
                    if new_model:
                        state.model = new_model
                        status_bar.model = new_model

                elif event_type == "subagent_start":
                    subagent_depth += 1
                    agent_type = data.get("agent_type", "sub")
                    prompt_text = data.get("prompt", "")[:80]
                    indent = "  " * subagent_depth
                    msg_list.mount(
                        Static(
                            f"{indent}[#9a7ac9]▶[/#9a7ac9] [bold #9a7ac9]{agent_type}[/bold #9a7ac9]"
                            f"  [#8a8a8a]{prompt_text}[/#8a8a8a]",
                            classes="subagent-start",
                            markup=True,
                        )
                    )
                    msg_list.scroll_end(animate=False)

                elif event_type == "subagent_end":
                    if subagent_depth > 0:
                        indent = "  " * subagent_depth
                        agent_type = data.get("agent_type", "sub")
                        msg_list.mount(
                            Static(
                                f"{indent}[#6a6a8a]◀ {agent_type} done[/#6a6a8a]",
                                classes="subagent-end",
                                markup=True,
                            )
                        )
                        msg_list.scroll_end(animate=False)
                        subagent_depth -= 1

                elif event_type == "progress":
                    progress_msg = data.get("message", "")
                    if progress_msg:
                        msg_list.mount(Static(f"  {progress_msg}", classes="progress-msg"))
                        msg_list.scroll_end(animate=False)

                # ── Configuration browse events ──────────────────────
                elif event_type == "skills_browse":
                    items = data.get("skills", [])
                    wizard = ConfigWizard(config_type="skills", items=items)
                    msg_list.mount(wizard)
                    msg_list.scroll_end(animate=False)

                elif event_type == "rules_browse":
                    items = data.get("rules", [])
                    wizard = ConfigWizard(config_type="rules", items=items)
                    msg_list.mount(wizard)
                    msg_list.scroll_end(animate=False)

                elif event_type == "agents_browse":
                    items = data.get("agents", [])
                    wizard = ConfigWizard(config_type="agents", items=items)
                    msg_list.mount(wizard)
                    msg_list.scroll_end(animate=False)

                elif event_type == "hooks_browse":
                    items = data.get("hooks", [])
                    wizard = ConfigWizard(config_type="hooks", items=items)
                    msg_list.mount(wizard)
                    msg_list.scroll_end(animate=False)

                elif event_type == "mcp_browse":
                    items = data.get("servers", [])
                    wizard = ConfigWizard(config_type="mcp", items=items)
                    msg_list.mount(wizard)
                    msg_list.scroll_end(animate=False)

                elif event_type == "verifiers_browse":
                    items = data.get("verifiers", [])
                    wizard = ConfigWizard(config_type="verifiers", items=items)
                    msg_list.mount(wizard)
                    msg_list.scroll_end(animate=False)

                elif event_type == "registry_browse":
                    browser = RegistryBrowser(registry_data={
                        "skills": data.get("skills", {}),
                        "rules": data.get("rules", {}),
                        "agents": data.get("agents", {}),
                        "verifiers": data.get("verifiers", {}),
                    })
                    msg_list.mount(browser)
                    msg_list.scroll_end(animate=False)

                elif event_type == "registry_install_result":
                    success = data.get("success", False)
                    msg_text = data.get("message", "")
                    cat = data.get("category", "")
                    name = data.get("name", "")
                    if success:
                        msg_list.add_message(Message(
                            role="system",
                            content=f"Installed {cat}/{name}: {msg_text}",
                        ))
                    else:
                        msg_list.add_message(Message(
                            role="system",
                            content=f"Install failed: {msg_text}",
                        ))

                # ── History replay ─────────────────────────────────
                elif event_type == "history_start":
                    msg_list.add_message(Message(
                        role="system",
                        content="Restoring session history…",
                    ))

                elif event_type == "history_message":
                    role = data.get("role", "assistant")
                    content = data.get("content", "")
                    display_name = data.get("display_name")
                    if content:
                        hist_msg = Message(
                            role=role,
                            content=content,
                            display_name=display_name,
                        )
                        state.messages.append(hist_msg)
                        msg_list.add_message(hist_msg)

                elif event_type == "history_end":
                    count = data.get("count", len(state.messages))
                    msg_list.add_message(Message(
                        role="system",
                        content=f"Session history restored ({count} messages).",
                    ))

                # ── Execution lifecycle ────────────────────────────
                elif event_type == "execution_started":
                    exec_id = data.get("execution_id", "")
                    label = data.get("label", "Execution started")
                    msg_list.mount(
                        Static(
                            f"[#7a9fc9]▶[/#7a9fc9] [#7a9fc9]{label}[/#7a9fc9]"
                            + (f"  [#6a6a6a]({exec_id})[/#6a6a6a]" if exec_id else ""),
                            classes="execution-event",
                            markup=True,
                        )
                    )
                    msg_list.scroll_end(animate=False)

                elif event_type == "execution_completed":
                    label = data.get("label", "Execution completed")
                    msg_list.mount(
                        Static(
                            f"[#7a9f7a]✓[/#7a9f7a] [#7a9f7a]{label}[/#7a9f7a]",
                            classes="execution-event",
                            markup=True,
                        )
                    )
                    msg_list.scroll_end(animate=False)

                elif event_type == "execution_failed":
                    label = data.get("label", "Execution failed")
                    error = data.get("error", "")
                    msg_list.mount(
                        Static(
                            f"[#d47a7a]✗[/#d47a7a] [#d47a7a]{label}[/#d47a7a]"
                            + (f"  [#8a8a8a]{error[:80]}[/#8a8a8a]" if error else ""),
                            classes="execution-event",
                            markup=True,
                        )
                    )
                    msg_list.scroll_end(animate=False)

                # ── Multiuser events ───────────────────────────────
                elif event_type == "multiuser_started":
                    state.multiuser_session_id = data.get("session_id")
                    state.multiuser_server_url = data.get("server_url")
                    state.multiuser_is_owner = data.get("is_owner", False)
                    msg_list.add_message(Message(
                        role="system",
                        content=f"Multiuser session started"
                                + (f" — {data.get('server_url', '')}" if data.get("server_url") else ""),
                    ))

                elif event_type == "multiuser_stopped":
                    state.multiuser_session_id = None
                    state.participants.clear()
                    state.typing_users.clear()
                    msg_list.add_message(Message(
                        role="system", content="Multiuser session ended.",
                    ))

                elif event_type == "participant_joined":
                    user = data.get("user", {})
                    name = user.get("name", user.get("id", "unknown"))
                    state.participants.append(user)
                    msg_list.mount(
                        Static(
                            f"  [#7a9f7a]→[/#7a9f7a] [#a8a8a8]{name} joined[/#a8a8a8]",
                            classes="multiuser-event",
                            markup=True,
                        )
                    )
                    msg_list.scroll_end(animate=False)

                elif event_type == "participant_left":
                    user = data.get("user", {})
                    name = user.get("name", user.get("id", "unknown"))
                    uid = user.get("id")
                    state.participants = [p for p in state.participants if p.get("id") != uid]
                    state.typing_users.discard(uid or name)
                    msg_list.mount(
                        Static(
                            f"  [#d47a7a]←[/#d47a7a] [#a8a8a8]{name} left[/#a8a8a8]",
                            classes="multiuser-event",
                            markup=True,
                        )
                    )
                    msg_list.scroll_end(animate=False)

                elif event_type == "user_typing":
                    uid = data.get("user_id", data.get("name", ""))
                    if uid:
                        state.typing_users.add(uid)
                        status_bar.update_typing_users(state.typing_users)

                elif event_type == "user_stopped_typing":
                    uid = data.get("user_id", data.get("name", ""))
                    state.typing_users.discard(uid)
                    status_bar.typing_users = state.typing_users

                elif event_type == "agent_typing":
                    pass  # Already shown via streaming spinner

                elif event_type == "project_browse":
                    pass  # Future: project browser widget

        except asyncio.CancelledError:
            log.debug(f"Message processing cancelled after {event_count} events")
            if streaming_started:
                msg_list.finish_streaming(accumulated_content or "*(cancelled)*")
            msg_list.add_message(Message(role="system", content="Cancelled."))
        except Exception as exc:
            log.exception(f"Error processing message after {event_count} events: {exc}")
            if streaming_started:
                msg_list.finish_streaming(accumulated_content or "")
            msg_list.add_message(Message(role="system", content=f"Error: {exc}"))
        finally:
            log.debug(f"Message processing finished with {event_count} events")
            # Clean up any open thinking/tool blocks
            if current_thinking:
                current_thinking.collapse()
            # Mark any still-running tools as cancelled
            for tool_widget in active_tools.values():
                if tool_widget.is_running:
                    tool_widget.set_result(success=False, result="Cancelled")
            active_tools.clear()
            state.processing = False
            status_bar.processing = False
            self._reenable_input()

    def _reenable_input(self) -> None:
        """Re-enable input bar and focus it."""
        try:
            input_bar = self.query_one(InputBar)
            input_bar.set_disabled(False)
            input_bar.refresh()
            input_bar.text_area.focus()
        except Exception:
            pass

    # ── plan approval handlers ──────────────────────────────────────────

    def on_plan_viewer_approved(self, event: PlanViewer.Approved) -> None:
        asyncio.create_task(self._handle_plan_approval(True, event.approval_type))

    def on_plan_viewer_rejected(self, event: PlanViewer.Rejected) -> None:
        asyncio.create_task(
            self._handle_plan_approval(False, event.approval_type, event.feedback)
        )

    async def _handle_plan_approval(
        self, approved: bool, approval_type: str, feedback: str = ""
    ) -> None:
        client = self.emdash_app.sse_client
        msg_list = self.query_one(MessageList)
        status_bar = self.query_one(StatusBar)
        input_bar = self.query_one(InputBar)

        self.emdash_app.state.processing = True
        status_bar.processing = True
        input_bar.set_disabled(True)

        accumulated = ""
        streaming_started = False

        # Yield immediately to let Textual render UI changes
        await asyncio.sleep(0)

        try:
            async for event in client.approve_plan(approved, feedback, approval_type):
                event_type = event.get("type", "")
                data = event.get("data", {})

                # Yield to event loop for UI updates
                await asyncio.sleep(0)

                if event_type in ("chat_chunk", "partial_response"):
                    chunk = data.get("content", "")
                    if chunk:
                        if not streaming_started:
                            streaming_started = True
                            msg_list.start_streaming()
                        accumulated += chunk
                        msg_list.update_streaming(accumulated)

                elif event_type == "response":
                    resp = data.get("content", "")
                    if resp:
                        if streaming_started:
                            msg_list.finish_streaming(resp)
                        else:
                            msg_list.add_message(Message(role="assistant", content=resp))
                        accumulated = ""
                        streaming_started = False

                elif event_type == "chat_complete":
                    if streaming_started and accumulated:
                        msg_list.finish_streaming(accumulated)
                        accumulated = ""
                        streaming_started = False

                elif event_type == "error":
                    msg_list.add_message(
                        Message(role="system", content=f"Error: {data.get('message', '')}")
                    )
        finally:
            self.emdash_app.state.processing = False
            status_bar.processing = False
            self._reenable_input()

    # ── choice answer handler ───────────────────────────────────────────

    def on_choice_prompt_answered(self, event: ChoicePrompt.Answered) -> None:
        """Forward the choice answer as a user message to the agent."""
        asyncio.create_task(self._process_message(event.selected))

    # ── config wizard handlers ───────────────────────────────────────

    def on_config_wizard_action(self, event: ConfigWizard.Action) -> None:
        """Handle config wizard actions (new, delete, toggle, view)."""
        action = event.action
        config_type = event.config_type
        name = event.name

        if action == "new":
            # Prompt the user to describe what they want to create
            msg_list = self.query_one(MessageList)
            msg_list.add_message(Message(
                role="system",
                content=f"To create a new {config_type[:-1] if config_type.endswith('s') else config_type}, "
                        f"describe what you want and I'll help you set it up.",
            ))
            self.query_one(InputBar).focus_input()
        elif action == "view" and name:
            asyncio.create_task(self._process_message(f"/{config_type} view {name}"))
        elif action == "delete" and name:
            asyncio.create_task(self._process_message(f"/{config_type} delete {name}"))
        elif action == "toggle" and name:
            asyncio.create_task(self._process_message(f"/{config_type} toggle {name}"))

    def on_config_wizard_dismissed(self, event: ConfigWizard.Dismissed) -> None:
        """Config wizard was dismissed."""
        self.query_one(InputBar).focus_input()

    # ── registry browser handlers ────────────────────────────────────

    def on_registry_browser_install(self, event: RegistryBrowser.Install) -> None:
        """Install a component from the registry."""
        asyncio.create_task(
            self._process_message(f"/registry install {event.category} {event.name}")
        )

    def on_registry_browser_dismissed(self, event: RegistryBrowser.Dismissed) -> None:
        """Registry browser was dismissed."""
        self.query_one(InputBar).focus_input()

    def on_message_list_request_input_focus(self, event: MessageList.RequestInputFocus) -> None:
        """When clicking on message list, refocus the input."""
        if not self.emdash_app.state.processing:
            self.query_one(InputBar).focus_input()

    # ── command/file menu handlers ───────────────────────────────────────

    def on_command_menu_selected(self, event) -> None:
        """A slash command was selected from the menu."""
        input_bar = self.query_one(InputBar)
        input_bar.text_area.clear()
        input_bar._showing_command_menu = False
        self.emdash_app.handle_slash_command(event.command)

    def on_command_menu_tab_complete(self, event) -> None:
        """Tab-complete a slash command."""
        input_bar = self.query_one(InputBar)
        input_bar.text_area.clear()
        input_bar.text_area.insert(event.command + " ")

    def on_command_menu_dismissed(self, event) -> None:
        self.query_one(InputBar)._showing_command_menu = False

    def on_file_menu_selected(self, event) -> None:
        """A file was selected from the @ menu."""
        input_bar = self.query_one(InputBar)
        ta = input_bar.text_area
        text = ta.text
        at_pos = text.rfind("@")
        if at_pos >= 0:
            ta.clear()
            ta.insert(text[:at_pos])
        input_bar._add_attachment(event.path)
        input_bar._showing_file_menu = False

    def on_file_menu_dismissed(self, event) -> None:
        self.query_one(InputBar)._showing_file_menu = False
