"""Kanban board screen with four-column task layout."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widget import Widget
from textual.widgets import Button, Footer, Static

if TYPE_CHECKING:
    from ..app import EmDashApp

COLUMNS = ["open", "in_progress", "in_review", "done"]
COLUMN_LABELS = {
    "open": "Open",
    "in_progress": "In Progress",
    "in_review": "In Review",
    "done": "Done",
}


class TaskCard(Widget):
    """A single task card in the Kanban board."""

    DEFAULT_CSS = """
    TaskCard {
        height: auto;
        margin: 0 0 1 0;
        padding: 1;
        border: round $primary;
        width: 1fr;
    }
    TaskCard:focus {
        border: round $accent;
    }
    TaskCard .card-title {
        text-style: bold;
    }
    TaskCard .card-priority {
        color: $text-muted;
    }
    TaskCard .card-assignee {
        color: $accent;
    }
    """

    can_focus = True

    def __init__(self, task: dict, **kwargs) -> None:
        super().__init__(**kwargs)
        self.task = task

    def compose(self) -> ComposeResult:
        title = self.task.get("title", "Untitled")
        priority = self.task.get("priority", "medium")
        assignee = self.task.get("assignee_name", "")
        yield Static(title, classes="card-title")
        yield Static(f"  {priority}", classes="card-priority")
        if assignee:
            yield Static(f"  {assignee}", classes="card-assignee")


class KanbanColumn(Widget):
    """A single column in the Kanban board."""

    DEFAULT_CSS = """
    KanbanColumn {
        width: 1fr;
        height: 1fr;
        margin: 0 1;
    }
    KanbanColumn .column-header {
        text-style: bold;
        text-align: center;
        height: 1;
        background: $panel;
        margin: 0 0 1 0;
    }
    KanbanColumn .column-count {
        text-align: center;
        color: $text-muted;
        height: 1;
    }
    KanbanColumn VerticalScroll {
        height: 1fr;
    }
    """

    def __init__(self, status: str, tasks: list[dict], **kwargs) -> None:
        super().__init__(**kwargs)
        self.status = status
        self.tasks = tasks

    def compose(self) -> ComposeResult:
        label = COLUMN_LABELS.get(self.status, self.status)
        yield Static(f" {label} ", classes="column-header")
        yield Static(f"({len(self.tasks)})", classes="column-count")
        with VerticalScroll():
            for task in self.tasks:
                yield TaskCard(task)


class KanbanScreen(Screen):
    """Full-screen Kanban board for task management."""

    BINDINGS = [
        Binding("escape", "pop_screen", "Back to Chat"),
        Binding("r", "refresh", "Refresh"),
        Binding("n", "new_task", "New Task"),
    ]

    DEFAULT_CSS = """
    KanbanScreen {
        layout: vertical;
    }
    KanbanScreen .board-title {
        text-align: center;
        text-style: bold;
        height: 1;
        background: $accent-darken-2;
        color: $text;
    }
    KanbanScreen .board {
        height: 1fr;
    }
    KanbanScreen Footer {
        dock: bottom;
    }
    """

    @property
    def emdash_app(self) -> "EmDashApp":
        return self.app  # type: ignore[return-value]

    def compose(self) -> ComposeResult:
        yield Static("Kanban Board", classes="board-title")
        tasks = self.emdash_app.state.tasks
        with Horizontal(classes="board"):
            for status in COLUMNS:
                col_tasks = [t for t in tasks if t.get("status") == status]
                yield KanbanColumn(status, col_tasks)
        yield Footer()

    def action_pop_screen(self) -> None:
        self.app.pop_screen()

    def action_refresh(self) -> None:
        """Refresh the board by re-fetching tasks."""
        # Send /project command to refresh data
        self.emdash_app.handle_slash_command("/project")

    def action_new_task(self) -> None:
        """Placeholder for new task creation."""
        self.notify("Task creation: use /project task-create in chat")
