"""Settings screen for model selection and configuration."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import Screen
from textual.widget import Widget
from textual.widgets import Button, Footer, RadioButton, RadioSet, Static

if TYPE_CHECKING:
    from ..app import EmDashApp


AVAILABLE_MODELS = [
    "claude-sonnet-4",
    "claude-opus-4",
    "claude-haiku-3.5",
    "gpt-4o",
    "gpt-4o-mini",
    "o3-mini",
    "deepseek-chat",
    "fireworks:accounts/fireworks/models/qwen3-235b",
]

AVAILABLE_MODES = ["code", "plan", "research", "review", "spec"]


class SettingsScreen(Screen):
    """Modal settings screen for model and mode configuration."""

    BINDINGS = [
        Binding("escape", "pop_screen", "Back"),
    ]

    DEFAULT_CSS = """
    SettingsScreen {
        layout: vertical;
        align: center middle;
    }
    SettingsScreen .settings-title {
        text-align: center;
        text-style: bold;
        height: 1;
        background: $accent-darken-2;
        color: $text;
        width: 1fr;
    }
    SettingsScreen .settings-body {
        width: 60;
        max-height: 80%;
        padding: 1 2;
        border: tall $primary;
        background: $surface;
    }
    SettingsScreen .section-label {
        text-style: bold;
        margin: 1 0 0 0;
    }
    SettingsScreen .current-value {
        color: $accent;
        margin: 0 0 1 0;
    }
    SettingsScreen .action-buttons {
        margin: 1 0 0 0;
    }
    SettingsScreen Button {
        margin: 0 1 0 0;
    }
    """

    @property
    def emdash_app(self) -> "EmDashApp":
        return self.app  # type: ignore[return-value]

    def compose(self) -> ComposeResult:
        state = self.emdash_app.state
        with VerticalScroll(classes="settings-body"):
            yield Static("Settings", classes="settings-title")

            yield Static("Model", classes="section-label")
            yield Static(f"Current: {state.model}", classes="current-value")
            with RadioSet(id="model-set"):
                for m in AVAILABLE_MODELS:
                    yield RadioButton(m, value=(m == state.model))

            yield Static("Mode", classes="section-label")
            yield Static(f"Current: {state.mode}", classes="current-value")
            with RadioSet(id="mode-set"):
                for m in AVAILABLE_MODES:
                    yield RadioButton(m, value=(m == state.mode))

            yield Static("Session", classes="section-label")
            sid = state.session_id or "none"
            yield Static(f"ID: {sid}", classes="current-value")
            with Vertical(classes="action-buttons"):
                yield Button("Reset Session", variant="warning", id="btn-reset")
                yield Button("New Session", variant="primary", id="btn-new")

        yield Footer()

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        """Handle model or mode selection changes."""
        set_id = event.radio_set.id
        label = str(event.pressed.label)

        if set_id == "model-set":
            self.emdash_app.sse_client.set_model(label)
            self.emdash_app.state.model = label
            self.notify(f"Model: {label}")
        elif set_id == "mode-set":
            self.emdash_app.sse_client.set_mode(label)
            self.emdash_app.state.mode = label
            self.notify(f"Mode: {label}")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-reset":
            self.emdash_app.sse_client.reset_session()
            self.emdash_app.state.session_id = None
            self.notify("Session reset")
        elif event.button.id == "btn-new":
            self.emdash_app.sse_client.reset_session()
            self.emdash_app.state.session_id = None
            self.emdash_app.state.messages.clear()
            self.notify("New session started")

    def action_pop_screen(self) -> None:
        self.app.pop_screen()
