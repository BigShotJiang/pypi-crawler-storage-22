"""Reactive state container for the Textual TUI.

Centralises application state so widgets can watch for changes via
Textual's reactive system.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Message:
    """A single chat message."""

    role: str  # "user" | "assistant" | "system"
    content: str
    display_name: str | None = None
    is_streaming: bool = False
    timestamp: datetime | None = field(default_factory=datetime.now)


@dataclass
class ToolCall:
    """A tracked tool execution."""

    name: str
    args: dict
    result: str | None = None
    success: bool | None = None  # None while running


@dataclass
class AppState:
    """Central mutable state — the Textual App holds an instance and
    widgets read from it.  Widgets trigger re-renders by posting
    custom Textual messages when state changes.
    """

    model: str = "claude-sonnet-4"
    mode: str = "code"
    session_id: str | None = None
    processing: bool = False

    messages: list[Message] = field(default_factory=list)
    tool_calls: list[ToolCall] = field(default_factory=list)
    thinking_content: str = ""
    current_streaming_content: str = ""

    # Plan mode
    pending_plan: str | None = None
    plan_approval_type: str | None = None  # "planmode" | "plan"

    # Choice / clarification
    pending_questions: list[dict] | None = None
    pending_clarification: dict | None = None

    # Multiuser
    multiuser_session_id: str | None = None
    multiuser_user_id: str | None = None
    multiuser_server_url: str | None = None
    multiuser_is_owner: bool = False
    participants: list[dict] = field(default_factory=list)
    typing_users: set[str] = field(default_factory=set)

    # Kanban
    projects: list[dict] = field(default_factory=list)
    tasks: list[dict] = field(default_factory=list)
