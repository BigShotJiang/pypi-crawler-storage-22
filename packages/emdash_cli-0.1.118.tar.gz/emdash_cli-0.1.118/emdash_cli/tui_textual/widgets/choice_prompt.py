"""Interactive choice prompt with arrow-key navigation and number shortcuts.

Matches the Ink TUI's ChoicePrompt: cursor-based selection, number keys,
multi-select with Space, and inline "Other" input.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.message import Message
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static, TextArea

# Colors matching Ink TUI
BORDER_COLOR = "#7a9fc9"
HEADER_COLOR = "#7a9fc9"
SELECTED_COLOR = "#e8e8e8"
UNSELECTED_COLOR = "#a8a8a8"
CHECKED_COLOR = "#c8c8c8"
CURSOR_COLOR = "#7a9f7a"
DIM_COLOR = "#6a6a6a"


class ChoicePrompt(Widget):
    """Displays a question with selectable options.

    Keyboard:
        Up/Down     Move cursor
        1-9         Jump to option by number
        Enter       Select current option
        Space       Toggle multi-select (if enabled)
        o           Jump to "Other" input
        Esc         Dismiss
    """

    can_focus = True

    BINDINGS = [
        Binding("up", "move_up", "Up", show=False),
        Binding("down", "move_down", "Down", show=False),
        Binding("enter", "select", "Select", show=False),
        Binding("space", "toggle", "Toggle", show=False),
    ]

    DEFAULT_CSS = """
    ChoicePrompt {
        height: auto;
        margin: 1 2;
        padding: 1;
        border: round #7a9fc9;
    }
    ChoicePrompt .choice-header {
        text-style: bold;
        color: #7a9fc9;
        height: auto;
        margin: 0 0 1 0;
    }
    ChoicePrompt .choice-multiselect-hint {
        color: #6a6a6a;
        height: 1;
        margin: 0 0 0 0;
    }
    ChoicePrompt .choice-options {
        height: auto;
    }
    ChoicePrompt .choice-option {
        height: 1;
    }
    ChoicePrompt .choice-hint {
        color: #6a6a6a;
        height: 1;
        margin: 1 0 0 0;
    }
    ChoicePrompt .choice-custom {
        height: 3;
        margin: 1 0 0 0;
        display: none;
    }
    ChoicePrompt .choice-custom.visible {
        display: block;
    }
    """

    selected_index = reactive(0)

    class Answered(Message):
        def __init__(self, question_id: str | None, selected: str, is_other: bool = False) -> None:
            super().__init__()
            self.question_id = question_id
            self.selected = selected
            self.is_other = is_other

    def __init__(
        self,
        question: str,
        options: list[dict],
        question_id: str | None = None,
        multi_select: bool = False,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.question = question
        self.options = options
        self.question_id = question_id
        self.multi_select = multi_select
        self._checked: set[int] = set()
        self._other_mode = False
        # Total items = options + "Other"
        self._total_items = len(options) + 1

    def compose(self) -> ComposeResult:
        yield Static(
            f"[bold {HEADER_COLOR}]? {self.question}[/bold {HEADER_COLOR}]",
            classes="choice-header",
            markup=True,
        )
        if self.multi_select:
            yield Static(
                f"[{DIM_COLOR}](Select multiple with Space, Enter to confirm)[/{DIM_COLOR}]",
                classes="choice-multiselect-hint",
                markup=True,
            )
        with Vertical(classes="choice-options"):
            for i in range(len(self.options)):
                yield Static("", id=f"copt-{i}", classes="choice-option", markup=True)
            # "Other" option
            yield Static("", id="copt-other", classes="choice-option", markup=True)

        hint = "↑↓ navigate, Space toggle, Enter confirm" if self.multi_select else "↑↓ or numbers to select, Enter confirm"
        yield Static(
            f"[{DIM_COLOR}]{hint}[/{DIM_COLOR}]",
            id="choice-hint",
            classes="choice-hint",
            markup=True,
        )
        yield TextArea(id="choice-custom", classes="choice-custom")

    def on_mount(self) -> None:
        ta = self.query_one("#choice-custom", TextArea)
        ta.show_line_numbers = False
        self._render_options()
        # Focus immediately and also after a short delay
        self.focus()
        self.set_timer(0.1, self._grab_focus)

    def _grab_focus(self) -> None:
        """Aggressively grab focus."""
        if not self._other_mode:
            self.focus()

    def on_click(self, event) -> None:
        """Focus when clicked."""
        if not self._other_mode:
            self.focus()

    def _render_options(self) -> None:
        for i, opt in enumerate(self.options):
            label = opt.get("label", opt) if isinstance(opt, dict) else str(opt)
            desc = opt.get("description", "") if isinstance(opt, dict) else ""
            is_sel = i == self.selected_index
            is_checked = i in self._checked

            if self.multi_select:
                checkbox = f"[{CURSOR_COLOR}]◉[/{CURSOR_COLOR}]" if is_checked else f"[{UNSELECTED_COLOR}]○[/{UNSELECTED_COLOR}]"
            else:
                checkbox = ""

            cursor = f"[{CURSOR_COLOR}]❯[/{CURSOR_COLOR}]" if is_sel else " "
            num_color = DIM_COLOR
            text_color = SELECTED_COLOR if is_sel else (CHECKED_COLOR if is_checked else UNSELECTED_COLOR)
            bold = "bold " if is_sel else ""
            desc_str = f"  [{DIM_COLOR}]- {desc}[/{DIM_COLOR}]" if desc else ""

            try:
                self.query_one(f"#copt-{i}", Static).update(
                    f"  {checkbox}{cursor} [{num_color}]{i + 1}.[/{num_color}] "
                    f"[{bold}{text_color}]{label}[/{bold}{text_color}]{desc_str}"
                )
            except Exception:
                pass

        # "Other" option
        other_idx = len(self.options)
        is_sel = self.selected_index == other_idx
        cursor = f"[{CURSOR_COLOR}]❯[/{CURSOR_COLOR}]" if is_sel else " "
        text_color = SELECTED_COLOR if is_sel else UNSELECTED_COLOR
        bold = "bold " if is_sel else ""
        try:
            self.query_one("#copt-other", Static).update(
                f"  {cursor} [{bold}{text_color}]Other...[/{bold}{text_color}]"
            )
        except Exception:
            pass

    def watch_selected_index(self, value: int) -> None:
        self._render_options()

    def action_move_up(self) -> None:
        """Move selection up."""
        if not self._other_mode:
            self.selected_index = (self.selected_index - 1) % self._total_items

    def action_move_down(self) -> None:
        """Move selection down."""
        if not self._other_mode:
            self.selected_index = (self.selected_index + 1) % self._total_items

    def action_select(self) -> None:
        """Select current option."""
        if self._other_mode:
            ta = self.query_one("#choice-custom", TextArea)
            custom = ta.text.strip()
            if custom:
                self.post_message(self.Answered(self.question_id, custom, is_other=True))
                self.remove()
        else:
            self._select_current()

    def action_toggle(self) -> None:
        """Toggle multi-select for current option."""
        if not self._other_mode and self.multi_select:
            if self.selected_index < len(self.options):
                if self.selected_index in self._checked:
                    self._checked.discard(self.selected_index)
                else:
                    self._checked.add(self.selected_index)
                self._render_options()

    def on_key(self, event) -> None:
        if self._other_mode:
            if event.key == "escape":
                self._exit_other_mode()
                event.prevent_default()
                event.stop()
                return
            if event.key == "enter":
                ta = self.query_one("#choice-custom", TextArea)
                custom = ta.text.strip()
                if custom:
                    self.post_message(self.Answered(self.question_id, custom, is_other=True))
                    self.remove()
                event.prevent_default()
                event.stop()
                return
            return

        key = event.key

        if key == "up":
            self.selected_index = (self.selected_index - 1) % self._total_items
            event.prevent_default()
            event.stop()
        elif key == "down":
            self.selected_index = (self.selected_index + 1) % self._total_items
            event.prevent_default()
            event.stop()
        elif key == "space" and self.multi_select:
            if self.selected_index < len(self.options):
                if self.selected_index in self._checked:
                    self._checked.discard(self.selected_index)
                else:
                    self._checked.add(self.selected_index)
                self._render_options()
            event.prevent_default()
            event.stop()
        elif key == "enter":
            self._select_current()
            event.prevent_default()
            event.stop()
        elif key == "o":
            self._enter_other_mode()
            event.prevent_default()
            event.stop()
        elif key in "123456789":
            idx = int(key) - 1
            if idx < len(self.options):
                if self.multi_select:
                    if idx in self._checked:
                        self._checked.discard(idx)
                    else:
                        self._checked.add(idx)
                    self.selected_index = idx
                    self._render_options()
                else:
                    opt = self.options[idx]
                    label = opt.get("label", opt) if isinstance(opt, dict) else str(opt)
                    self.post_message(self.Answered(self.question_id, label))
                    self.remove()
            event.prevent_default()
            event.stop()

    def _select_current(self) -> None:
        if self.selected_index == len(self.options):
            # "Other" selected
            self._enter_other_mode()
            return

        if self.multi_select:
            # Enter confirms multi-select
            if self._checked:
                labels = []
                for idx in sorted(self._checked):
                    opt = self.options[idx]
                    label = opt.get("label", opt) if isinstance(opt, dict) else str(opt)
                    labels.append(label)
                self.post_message(self.Answered(self.question_id, ", ".join(labels)))
                self.remove()
        else:
            idx = self.selected_index
            if idx < len(self.options):
                opt = self.options[idx]
                label = opt.get("label", opt) if isinstance(opt, dict) else str(opt)
                self.post_message(self.Answered(self.question_id, label))
                self.remove()

    def _enter_other_mode(self) -> None:
        self._other_mode = True
        try:
            self.query_one("#choice-hint", Static).update(
                f"[{DIM_COLOR}]Type your answer, Enter to send, Esc to cancel[/{DIM_COLOR}]"
            )
            ta = self.query_one("#choice-custom", TextArea)
            ta.add_class("visible")
            ta.focus()
        except Exception:
            pass

    def _exit_other_mode(self) -> None:
        self._other_mode = False
        hint = "↑↓ navigate, Space toggle, Enter confirm" if self.multi_select else "↑↓ or numbers to select, Enter confirm"
        try:
            self.query_one("#choice-hint", Static).update(
                f"[{DIM_COLOR}]{hint}[/{DIM_COLOR}]"
            )
            self.query_one("#choice-custom", TextArea).remove_class("visible")
            self.focus()
        except Exception:
            pass
