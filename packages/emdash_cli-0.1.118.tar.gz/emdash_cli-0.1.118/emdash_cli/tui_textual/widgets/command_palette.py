"""Slash-command provider for Textual's built-in command palette."""

from __future__ import annotations

from textual.command import Hit, Hits, Provider


SLASH_COMMANDS: list[tuple[str, str]] = [
    ("/plan", "Switch to plan mode"),
    ("/code", "Switch to code mode"),
    ("/model", "Change model"),
    ("/kanban", "Open Kanban board"),
    ("/settings", "Open settings"),
    ("/clear", "Clear chat messages"),
    ("/reset", "Reset session"),
    ("/stats", "Show session statistics"),
    ("/todos", "Show todo list"),
    ("/compact", "Compact conversation history"),
    ("/context", "Show context window usage"),
    ("/messages", "Show conversation messages"),
    ("/diff", "Show git diff"),
    ("/doctor", "Run diagnostics"),
    ("/status", "Show index status"),
    ("/share", "Create shareable session"),
    ("/join", "Join a shared session"),
    ("/who", "Show session participants"),
    ("/leave", "Leave shared session"),
    ("/invite", "Show invite code"),
    ("/skills", "Browse skills"),
    ("/rules", "Browse rules"),
    ("/agents", "Browse agents"),
    ("/hooks", "Browse hooks"),
    ("/mcp", "Browse MCP servers"),
    ("/registry", "Browse community registry"),
    ("/project", "Project management"),
    ("/session", "Session management"),
    ("/research", "Deep research"),
    ("/pr", "Review a pull request"),
    ("/projectmd", "Generate PROJECT.md"),
    ("/export", "Export session"),
]


class EmDashCommandProvider(Provider):
    """Provides slash commands to Textual's command palette."""

    async def search(self, query: str) -> Hits:
        matcher = self.matcher(query)
        for cmd, desc in SLASH_COMMANDS:
            score = matcher.match(f"{cmd} {desc}")
            if score > 0:
                yield Hit(
                    score,
                    matcher.highlight(f"{cmd}  {desc}"),
                    partial=self._make_callback(cmd),
                    help=desc,
                )

    def _make_callback(self, cmd: str):
        """Create a callback that sends the slash command as input."""
        async def callback() -> None:
            # Post the command as user input to the app
            from ..app import EmDashApp
            app = self.app
            if isinstance(app, EmDashApp):
                app.handle_slash_command(cmd)
        return callback
