"""Unified configuration browser for skills, rules, agents, hooks, MCP, verifiers.

Matches the Ink TUI's ConfigWizard.tsx — interactive list with keyboard
navigation and contextual actions (New, Delete, Toggle, View).
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.message import Message
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static

# Colors matching Ink palette
HEADER_COLOR = "#c9a075"
SELECTED_BG = "#3a2a32"
SELECTED_FG = "#f0e8ec"
NORMAL_FG = "#a8a8a8"
DIM_COLOR = "#6a6a6a"
ACCENT_COLOR = "#7a9f7a"
BUILTIN_COLOR = "#9a9a6a"
ENABLED_COLOR = "#7a9f7a"
DISABLED_COLOR = "#9a6a6a"
BUTTON_ACTIVE = "#e8e8e8"
BUTTON_INACTIVE = "#6a6a6a"

# Config types that support toggle
TOGGLEABLE = {"hooks", "mcp", "verifiers"}


class ConfigWizard(Widget):
    """Interactive configuration browser overlay.

    Keyboard:
        Up/Down, j/k   Navigate items
        Tab             Focus buttons
        Left/Right, h/l Navigate buttons
        Enter           Activate button or view item
        n               New item
        d               Delete selected
        t               Toggle selected (hooks/mcp/verifiers)
        Esc             Dismiss
    """

    DEFAULT_CSS = """
    ConfigWizard {
        height: auto;
        max-height: 80%;
        margin: 1 2;
        padding: 1;
        border: round #c9a075;
    }
    ConfigWizard .cw-header {
        text-style: bold;
        color: #c9a075;
        height: 1;
        margin: 0 0 1 0;
    }
    ConfigWizard .cw-list {
        height: auto;
        max-height: 20;
    }
    ConfigWizard .cw-item {
        height: 1;
    }
    ConfigWizard .cw-empty {
        color: #6a6a6a;
        height: 1;
        margin: 1 0;
    }
    ConfigWizard .cw-buttons {
        height: 1;
        margin: 1 0 0 0;
    }
    ConfigWizard .cw-btn {
        margin: 0 1 0 0;
    }
    ConfigWizard .cw-hint {
        color: #6a6a6a;
        height: 1;
        margin: 1 0 0 0;
    }
    """

    selected_index = reactive(0)
    focused_button = reactive(0)
    button_focused = reactive(False)

    class Action(Message):
        """User performed an action on a config item."""

        def __init__(self, config_type: str, action: str, name: str | None = None) -> None:
            super().__init__()
            self.config_type = config_type
            self.action = action
            self.name = name

    class Dismissed(Message):
        pass

    def __init__(
        self,
        config_type: str,
        items: list[dict],
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.config_type = config_type
        self.items = items
        self._buttons = self._make_buttons()

    def _make_buttons(self) -> list[tuple[str, str]]:
        buttons = [("new", "New"), ("delete", "Delete")]
        if self.config_type in TOGGLEABLE:
            buttons.insert(1, ("toggle", "Toggle"))
        buttons.append(("cancel", "Cancel"))
        return buttons

    def _type_label(self) -> str:
        return self.config_type.title()

    def compose(self) -> ComposeResult:
        yield Static("", id="cw-header", classes="cw-header", markup=True)
        with VerticalScroll(classes="cw-list"):
            yield Vertical(id="cw-items")
        with Horizontal(classes="cw-buttons"):
            for i, (action_id, label) in enumerate(self._buttons):
                yield Static("", id=f"cw-btn-{i}", classes="cw-btn", markup=True)
        yield Static("", id="cw-hint", classes="cw-hint", markup=True)

    def on_mount(self) -> None:
        self._update_header()
        self._render_items()
        self._render_buttons()
        self._update_hint()
        self.focus()

    def _update_header(self) -> None:
        count = len(self.items)
        try:
            self.query_one("#cw-header", Static).update(
                f"[bold {HEADER_COLOR}]{self._type_label()} ({count})[/bold {HEADER_COLOR}]"
            )
        except Exception:
            pass

    def _render_items(self) -> None:
        container = self.query_one("#cw-items", Vertical)
        container.remove_children()
        if not self.items:
            container.mount(Static(
                f"[{DIM_COLOR}]No {self.config_type} configured[/{DIM_COLOR}]",
                classes="cw-empty",
                markup=True,
            ))
            return

        for i, item in enumerate(self.items):
            is_sel = i == self.selected_index and not self.button_focused
            name = item.get("name", "unknown")
            desc = self._item_description(item)
            status = self._item_status(item)

            cursor = f"[{ACCENT_COLOR}]❯[/{ACCENT_COLOR}]" if is_sel else " "
            text_color = SELECTED_FG if is_sel else NORMAL_FG
            bold = "bold " if is_sel else ""

            label_parts = [f" {cursor} "]
            if status:
                label_parts.append(f"{status} ")
            label_parts.append(f"[{bold}{text_color}]{name}[/{bold}{text_color}]")
            if desc:
                label_parts.append(f"  [{DIM_COLOR}]{desc}[/{DIM_COLOR}]")

            container.mount(Static("".join(label_parts), classes="cw-item", markup=True))

    def _item_description(self, item: dict) -> str:
        for key in ("description", "preview", "command"):
            val = item.get(key)
            if val:
                val = str(val).replace("\n", " ")
                return val[:60] + ("..." if len(val) > 60 else "")
        if "event" in item:
            return f"on {item['event']}: {item.get('command', '')}"[:60]
        if "args" in item:
            return " ".join(item.get("args", []))[:60]
        return ""

    def _item_status(self, item: dict) -> str:
        if item.get("builtin"):
            return f"[{BUILTIN_COLOR}][built-in][/{BUILTIN_COLOR}]"
        if "enabled" in item:
            if item["enabled"]:
                return f"[{ENABLED_COLOR}]✓[/{ENABLED_COLOR}]"
            else:
                return f"[{DISABLED_COLOR}]○[/{DISABLED_COLOR}]"
        return ""

    def _render_buttons(self) -> None:
        for i, (action_id, label) in enumerate(self._buttons):
            is_focused = self.button_focused and i == self.focused_button
            color = BUTTON_ACTIVE if is_focused else BUTTON_INACTIVE
            bracket = f"[{ACCENT_COLOR}][[/{ACCENT_COLOR}]" if is_focused else "["
            bracket_close = f"[{ACCENT_COLOR}]][/{ACCENT_COLOR}]" if is_focused else "]"
            try:
                self.query_one(f"#cw-btn-{i}", Static).update(
                    f"{bracket}[{color}]{label}[/{color}]{bracket_close}"
                )
            except Exception:
                pass

    def _update_hint(self) -> None:
        if self.button_focused:
            hint = "Enter to activate, Tab back to list"
        else:
            keys = "↑↓/jk navigate, Tab to buttons, n new, d delete"
            if self.config_type in TOGGLEABLE:
                keys += ", t toggle"
            keys += ", Esc dismiss"
            hint = keys
        try:
            self.query_one("#cw-hint", Static).update(f"[{DIM_COLOR}]{hint}[/{DIM_COLOR}]")
        except Exception:
            pass

    # ── Reactive watchers ───────────────────────────────────────────

    def watch_selected_index(self, value: int) -> None:
        self._render_items()

    def watch_focused_button(self, value: int) -> None:
        self._render_buttons()

    def watch_button_focused(self, value: bool) -> None:
        self._render_items()
        self._render_buttons()
        self._update_hint()

    # ── Key handling ────────────────────────────────────────────────

    def on_key(self, event) -> None:
        key = event.key

        if key == "escape":
            self.post_message(self.Dismissed())
            self.remove()
            event.prevent_default()
            event.stop()
            return

        if self.button_focused:
            if key in ("left", "h"):
                self.focused_button = (self.focused_button - 1) % len(self._buttons)
                event.prevent_default()
                event.stop()
            elif key in ("right", "l"):
                self.focused_button = (self.focused_button + 1) % len(self._buttons)
                event.prevent_default()
                event.stop()
            elif key == "tab":
                self.button_focused = False
                event.prevent_default()
                event.stop()
            elif key == "enter":
                self._activate_button()
                event.prevent_default()
                event.stop()
            return

        # List navigation
        if key in ("up", "k"):
            if self.items:
                self.selected_index = (self.selected_index - 1) % len(self.items)
            event.prevent_default()
            event.stop()
        elif key in ("down", "j"):
            if self.items:
                self.selected_index = (self.selected_index + 1) % len(self.items)
            event.prevent_default()
            event.stop()
        elif key == "tab":
            self.button_focused = True
            event.prevent_default()
            event.stop()
        elif key == "enter":
            self._view_selected()
            event.prevent_default()
            event.stop()
        elif key == "n":
            self._do_action("new")
            event.prevent_default()
            event.stop()
        elif key == "d":
            self._do_action("delete")
            event.prevent_default()
            event.stop()
        elif key == "t" and self.config_type in TOGGLEABLE:
            self._do_action("toggle")
            event.prevent_default()
            event.stop()

    def _activate_button(self) -> None:
        if 0 <= self.focused_button < len(self._buttons):
            action_id = self._buttons[self.focused_button][0]
            if action_id == "cancel":
                self.post_message(self.Dismissed())
                self.remove()
            else:
                self._do_action(action_id)

    def _view_selected(self) -> None:
        if self.items and 0 <= self.selected_index < len(self.items):
            name = self.items[self.selected_index].get("name")
            self.post_message(self.Action(self.config_type, "view", name))

    def _do_action(self, action: str) -> None:
        name = None
        if self.items and 0 <= self.selected_index < len(self.items):
            item = self.items[self.selected_index]
            if action == "delete" and item.get("builtin"):
                return  # Can't delete built-in items
            name = item.get("name")
        self.post_message(self.Action(self.config_type, action, name))
        if action in ("delete", "toggle"):
            # Dismiss after mutating action
            self.post_message(self.Dismissed())
            self.remove()
