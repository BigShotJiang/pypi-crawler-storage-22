"""Multi-line input bar with mode-themed styling, @ file tagging,
image paste, and inline slash-command menu.

This is the main input widget — matches the Ink TUI feature set.
"""

from __future__ import annotations

import os
import platform
import subprocess
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.message import Message
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static, TextArea

if TYPE_CHECKING:
    from ..app import EmDashApp


# ── Constants ────────────────────────────────────────────────────────────

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg", ".tiff"}

MODE_COLORS = {
    "code": {"border": "#5a4a3d", "accent": "#ba9f6a", "prompt": "#ba9f6a"},
    "plan": {"border": "#5a3d4a", "accent": "#c97590", "prompt": "#c97590"},
}


def _get_colors(mode: str) -> dict:
    return MODE_COLORS.get(mode, MODE_COLORS["code"])


# ── File attachment dataclass ────────────────────────────────────────────

class FileAttachment:
    __slots__ = ("id", "path", "name", "is_image")

    def __init__(self, path: str) -> None:
        p = Path(path).resolve()
        self.id = f"file-{id(self)}"
        self.path = str(p)
        self.name = p.name
        self.is_image = p.suffix.lower() in IMAGE_EXTENSIONS


# ── Attachment bar ───────────────────────────────────────────────────────

class AttachmentBar(Widget):
    """Shows attached files above the input area."""

    DEFAULT_CSS = """
    AttachmentBar {
        height: auto;
        max-height: 3;
        padding: 0 1;
        display: none;
    }
    AttachmentBar.has-items {
        display: block;
    }
    AttachmentBar .att-label {
        color: #8a8a8a;
    }
    AttachmentBar .att-image {
        color: #9ac9c9;
    }
    AttachmentBar .att-file {
        color: #c9a075;
    }
    AttachmentBar .att-hint {
        color: #5a5a5a;
    }
    """

    def compose(self) -> ComposeResult:
        yield Static("", id="att-content")

    def update_items(self, items: list[FileAttachment]) -> None:
        if not items:
            self.remove_class("has-items")
            return
        self.add_class("has-items")
        parts = ["Attachments: "]
        for att in items:
            name = att.name if len(att.name) <= 25 else att.name[:22] + "..."
            cls = "att-image" if att.is_image else "att-file"
            parts.append(f"[{cls}]{name}[/{cls}]  ")
        parts.append("[att-hint](Ctrl+X remove)[/att-hint]")
        self.query_one("#att-content", Static).update("".join(parts))


# ── Inline file menu ─────────────────────────────────────────────────────

class FileMenu(Widget):
    """Dropdown showing file suggestions when @ is typed."""

    DEFAULT_CSS = """
    FileMenu {
        height: auto;
        max-height: 10;
        display: none;
        border: round #5a4a3d;
        padding: 0 1;
        background: #1a1a1a;
    }
    FileMenu.visible {
        display: block;
    }
    FileMenu .file-item {
        height: 1;
    }
    FileMenu .file-item.selected {
        background: #3a2a32;
        color: #f0e8ec;
    }
    FileMenu .file-hint {
        color: #5a5a5a;
        height: 1;
    }
    """

    selected_index = reactive(0)

    class Selected(Message):
        def __init__(self, path: str) -> None:
            super().__init__()
            self.path = path

    class Dismissed(Message):
        pass

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._files: list[str] = []

    def compose(self) -> ComposeResult:
        yield Vertical(id="file-list")
        yield Static("[↑↓] navigate  [Enter] select  [Esc] dismiss", classes="file-hint")

    def show_files(self, files: list[str]) -> None:
        self._files = files[:8]
        self.selected_index = 0
        self._render_items()
        if files:
            self.add_class("visible")
        else:
            self.remove_class("visible")

    def hide(self) -> None:
        self.remove_class("visible")
        self._files = []

    def _render_items(self) -> None:
        container = self.query_one("#file-list", Vertical)
        container.remove_children()
        for i, f in enumerate(self._files):
            indicator = "› " if i == self.selected_index else "  "
            cls = "file-item selected" if i == self.selected_index else "file-item"
            container.mount(Static(f"{indicator}{f}", classes=cls))

    def move_up(self) -> None:
        if self._files:
            self.selected_index = (self.selected_index - 1) % len(self._files)
            self._render_items()

    def move_down(self) -> None:
        if self._files:
            self.selected_index = (self.selected_index + 1) % len(self._files)
            self._render_items()

    def select_current(self) -> None:
        if self._files and 0 <= self.selected_index < len(self._files):
            self.post_message(self.Selected(self._files[self.selected_index]))
            self.hide()

    @property
    def is_visible(self) -> bool:
        return self.has_class("visible")


# ── Inline command menu ──────────────────────────────────────────────────

SLASH_COMMANDS: list[tuple[str, str, str]] = [
    # (command, description, category)
    ("/help", "Show available commands", "local"),
    ("/copy", "Copy last response", "local"),
    ("/copy all", "Copy entire conversation", "local"),
    ("/plan", "Switch to plan mode", "local"),
    ("/code", "Switch to code mode", "local"),
    ("/mode", "Show current mode", "local"),
    ("/model", "Switch model (picker)", "local"),
    ("/reset", "Reset session", "local"),
    ("/quit", "Exit", "local"),
    ("/stats", "Token usage & cost", "session"),
    ("/todos", "Agent todo list", "session"),
    ("/todo-add", "Add a todo", "session"),
    ("/context", "Context usage", "session"),
    ("/messages", "Conversation history", "session"),
    ("/compact", "Compact conversation", "session"),
    ("/session", "Save/load sessions", "session"),
    ("/status", "Index status", "repository"),
    ("/diff", "Git diff", "repository"),
    ("/doctor", "Run diagnostics", "repository"),
    ("/projectmd", "Generate PROJECT.md", "repository"),
    ("/index", "Manage codebase index", "repository"),
    ("/setup", "Setup wizard", "configuration"),
    ("/registry", "Browse community registry", "configuration"),
    ("/skills", "Manage skills", "configuration"),
    ("/agents", "Manage agents", "configuration"),
    ("/rules", "Manage rules", "configuration"),
    ("/hooks", "Manage hooks", "configuration"),
    ("/verify", "Manage verifiers", "configuration"),
    ("/mcp", "Manage MCP servers", "configuration"),
    ("/share", "Share session", "collaboration"),
    ("/join", "Join session", "collaboration"),
    ("/leave", "Leave session", "collaboration"),
    ("/who", "Participants", "collaboration"),
    ("/invite", "Show invite code", "collaboration"),
    ("/team", "Manage teams", "collaboration"),
    ("/project", "Project management", "collaboration"),
    ("/pr", "Review a PR", "advanced"),
    ("/research", "Deep research", "advanced"),
    ("/auth", "Authentication", "auth"),
    ("/telegram", "Telegram integration", "auth"),
]

CATEGORY_COLORS = {
    "local": "#7a9f7a",
    "session": "#9f9f7a",
    "repository": "#7a9f9f",
    "configuration": "#9f7a9f",
    "collaboration": "#7a7a9f",
    "advanced": "#9f7a7a",
    "auth": "#7a7a7a",
}


class CommandMenu(Widget):
    """Inline dropdown for slash commands with search filtering."""

    DEFAULT_CSS = """
    CommandMenu {
        height: auto;
        max-height: 14;
        display: none;
        border: round #8a6a7a;
        padding: 0 1;
        background: #1a1a1a;
    }
    CommandMenu.visible {
        display: block;
    }
    CommandMenu .cmd-item {
        height: 1;
    }
    CommandMenu .cmd-item.selected {
        background: #3a2a32;
        color: #f0e8ec;
    }
    CommandMenu .cmd-hint {
        color: #5a5a5a;
        height: 1;
    }
    """

    selected_index = reactive(0)

    class Selected(Message):
        def __init__(self, command: str) -> None:
            super().__init__()
            self.command = command

    class TabComplete(Message):
        def __init__(self, command: str) -> None:
            super().__init__()
            self.command = command

    class Dismissed(Message):
        pass

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._items: list[tuple[str, str, str]] = []

    def compose(self) -> ComposeResult:
        yield Vertical(id="cmd-list")
        yield Static(
            "[↑↓] navigate  [Tab] complete  [Enter] send  [Esc] dismiss",
            classes="cmd-hint",
        )

    def filter(self, query: str) -> None:
        """Filter commands by prefix match and display."""
        q = query.lower().lstrip("/")
        if not q:
            self._items = SLASH_COMMANDS[:10]
        else:
            self._items = [
                (c, d, cat) for c, d, cat in SLASH_COMMANDS
                if c.lower().lstrip("/").startswith(q)
            ][:10]
        self.selected_index = 0
        self._render_items()
        if self._items:
            self.add_class("visible")
        else:
            self.remove_class("visible")

    def hide(self) -> None:
        self.remove_class("visible")
        self._items = []

    def _render_items(self) -> None:
        container = self.query_one("#cmd-list", Vertical)
        container.remove_children()
        for i, (cmd, desc, cat) in enumerate(self._items):
            indicator = "› " if i == self.selected_index else "  "
            cls = "cmd-item selected" if i == self.selected_index else "cmd-item"
            color = CATEGORY_COLORS.get(cat, "#8a8a8a")
            label = f"{indicator}[bold {color}]{cmd:<18}[/bold {color}] [{color}]{desc}[/{color}]"
            container.mount(Static(label, classes=cls, markup=True))

    def move_up(self) -> None:
        if self._items:
            self.selected_index = (self.selected_index - 1) % len(self._items)
            self._render_items()

    def move_down(self) -> None:
        if self._items:
            self.selected_index = (self.selected_index + 1) % len(self._items)
            self._render_items()

    def select_current(self) -> None:
        if self._items and 0 <= self.selected_index < len(self._items):
            cmd = self._items[self.selected_index][0]
            self.post_message(self.Selected(cmd))
            self.hide()

    def tab_complete_current(self) -> None:
        if self._items and 0 <= self.selected_index < len(self._items):
            cmd = self._items[self.selected_index][0]
            self.post_message(self.TabComplete(cmd))

    @property
    def is_visible(self) -> bool:
        return self.has_class("visible")


# ── File search utility ──────────────────────────────────────────────────

def search_files(query: str, cwd: str | None = None, max_results: int = 10, max_depth: int = 3) -> list[str]:
    """Recursively search for files matching query, like the Ink TUI."""
    base = Path(cwd or os.getcwd())
    results: list[str] = []
    q = query.lower()

    def _walk(directory: Path, depth: int) -> None:
        if depth > max_depth or len(results) >= max_results:
            return
        try:
            entries = sorted(directory.iterdir(), key=lambda e: e.name.lower())
        except PermissionError:
            return
        for entry in entries:
            if len(results) >= max_results:
                break
            name = entry.name
            if name.startswith(".") or name == "node_modules" or name == "__pycache__":
                continue
            rel = str(entry.relative_to(base))
            if entry.is_dir():
                rel += "/"
            if not q or q in name.lower():
                results.append(rel)
            if entry.is_dir():
                _walk(entry, depth + 1)

    _walk(base, 0)
    return results[:max_results]


# ── Clipboard image detection ────────────────────────────────────────────

def detect_clipboard_image() -> str | None:
    """Try to detect and save a clipboard image. Returns path or None.

    macOS: uses AppleScript to check clipboard for image data.
    Linux: uses xclip.
    """
    system = platform.system()

    if system == "Darwin":
        return _clipboard_image_macos()
    elif system == "Linux":
        return _clipboard_image_linux()
    return None


def _clipboard_image_macos() -> str | None:
    """Detect clipboard image on macOS using osascript."""
    try:
        tmp = Path(tempfile.gettempdir()) / f"clipboard-{os.getpid()}.png"
        # Remove old file if exists
        if tmp.exists():
            tmp.unlink()

        script = '''
use framework "AppKit"
set pb to current application's NSPasteboard's generalPasteboard()
set imgData to pb's dataForType:"public.png"
if imgData is missing value then
    set imgData to pb's dataForType:"public.tiff"
end if
if imgData is not missing value then
    (imgData's writeToFile:"%s" atomically:true)
    return "ok"
end if
return "no"
''' % str(tmp)
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, text=True, timeout=5,
        )
        if "ok" in result.stdout and tmp.exists() and tmp.stat().st_size > 0:
            return str(tmp)
    except Exception:
        pass
    return None


def _clipboard_image_linux() -> str | None:
    """Detect clipboard image on Linux via xclip."""
    try:
        result = subprocess.run(
            ["xclip", "-selection", "clipboard", "-t", "TARGETS", "-o"],
            capture_output=True, text=True, timeout=2,
        )
        if "image/png" in result.stdout:
            tmp = Path(tempfile.gettempdir()) / f"clipboard-{os.getpid()}.png"
            subprocess.run(
                ["xclip", "-selection", "clipboard", "-t", "image/png", "-o"],
                stdout=open(tmp, "wb"), timeout=3,
            )
            if tmp.exists() and tmp.stat().st_size > 0:
                return str(tmp)
    except Exception:
        pass
    return None


# ── Main InputBar widget ─────────────────────────────────────────────────

class InputBar(Widget):
    """Full-featured input bar with mode theming, @ file tagging,
    clipboard image paste, and inline slash command menu.

    - Enter sends message, Shift+Enter inserts newline
    - @ triggers file search dropdown
    - Ctrl+V / @@ pastes clipboard image
    - / at start shows command menu with search
    - Ctrl+X removes last attachment
    """

    BINDINGS = [
        Binding("enter", "submit_message", "Send", show=False, priority=True),
        Binding("ctrl+v", "paste_image", "Paste Image", show=False, priority=True),
    ]

    DEFAULT_CSS = """
    InputBar {
        dock: bottom;
        height: auto;
        margin-bottom: 1;
        border-top: solid #5a4a3d;
    }
    InputBar.plan-mode {
        border-top: solid #5a3d4a;
    }
    InputBar .input-row {
        width: 1fr;
        height: auto;
        padding: 0 1;
    }
    InputBar .input-prompt {
        width: 2;
        height: 1;
        color: #ba9f6a;
        text-style: bold;
    }
    InputBar TextArea {
        width: 1fr;
        height: auto;
        min-height: 1;
        max-height: 10;
        border: none;
        background: transparent;
    }
    InputBar TextArea:focus {
        border: none;
    }
    InputBar.disabled {
        opacity: 0.5;
    }
    """

    mode = reactive("code")

    class Submitted(Message):
        """Fired when the user submits a message."""

        def __init__(self, content: str, attachments: list[FileAttachment] | None = None) -> None:
            super().__init__()
            self.content = content
            self.attachments = attachments or []

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._attachments: list[FileAttachment] = []
        self._added_paths: set[str] = set()
        self._showing_file_menu = False
        self._showing_command_menu = False
        self._at_query = ""

    def compose(self) -> ComposeResult:
        yield AttachmentBar(id="attachment-bar")
        with Horizontal(classes="input-row"):
            yield Static("› ", classes="input-prompt", id="input-prompt")
            yield TextArea(id="input-area", language=None)

    def on_mount(self) -> None:
        ta = self.query_one("#input-area", TextArea)
        ta.show_line_numbers = False
        ta.focus()
        self._update_mode_style()

    def watch_mode(self, value: str) -> None:
        self._update_mode_style()

    def _update_mode_style(self) -> None:
        """Update styling based on current mode."""
        colors = _get_colors(self.mode)
        try:
            if self.mode == "plan":
                self.add_class("plan-mode")
            else:
                self.remove_class("plan-mode")
            self.query_one("#input-prompt", Static).update(
                f"[bold {colors['prompt']}]› [/bold {colors['prompt']}]"
            )
        except Exception:
            pass

    # ── TextArea change handler ──────────────────────────────────────────

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        """React to text changes for @ and / triggers."""
        ta = self.query_one("#input-area", TextArea)
        text = ta.text

        # Slash command menu
        if text.startswith("/"):
            self._showing_command_menu = True
            self.screen.query_one("#command-menu", CommandMenu).filter(text)
            # Hide file menu if open
            if self._showing_file_menu:
                self._showing_file_menu = False
                self.screen.query_one("#file-menu", FileMenu).hide()
            return
        elif self._showing_command_menu:
            self._showing_command_menu = False
            self.screen.query_one("#command-menu", CommandMenu).hide()

        # @@ means paste clipboard image
        if text.endswith("@@"):
            self._try_paste_image()
            ta.clear()
            return

        # @ file tagging - need at least one char after @
        at_pos = text.rfind("@")
        if at_pos >= 0 and at_pos < len(text) - 1:
            # Have @ with chars after it
            query = text[at_pos + 1:]
            if not self._showing_file_menu:
                self._showing_file_menu = True
            self._at_query = query
            files = search_files(query)
            self.screen.query_one("#file-menu", FileMenu).show_files(files)
        elif self._showing_file_menu:
            # No valid @ pattern, hide menu
            self._showing_file_menu = False
            self.screen.query_one("#file-menu", FileMenu).hide()

    # ── Key handling ─────────────────────────────────────────────────────

    def on_key(self, event) -> None:
        """Handle special keys."""
        key = event.key

        # When command menu is showing, intercept navigation keys
        if self._showing_command_menu:
            cmd_menu = self.screen.query_one("#command-menu", CommandMenu)
            if cmd_menu.is_visible:
                if key == "up":
                    cmd_menu.move_up()
                    event.prevent_default()
                    event.stop()
                    return
                elif key == "down":
                    cmd_menu.move_down()
                    event.prevent_default()
                    event.stop()
                    return
                elif key == "tab":
                    cmd_menu.tab_complete_current()
                    event.prevent_default()
                    event.stop()
                    return
                # Enter is handled via action_submit_message binding
                elif key == "escape":
                    cmd_menu.hide()
                    self._showing_command_menu = False
                    ta = self.query_one("#input-area", TextArea)
                    ta.clear()
                    event.prevent_default()
                    event.stop()
                    return

        # When file menu is showing, intercept navigation keys
        if self._showing_file_menu:
            file_menu = self.screen.query_one("#file-menu", FileMenu)
            if file_menu.is_visible:
                if key == "up":
                    file_menu.move_up()
                    event.prevent_default()
                    event.stop()
                    return
                elif key == "down":
                    file_menu.move_down()
                    event.prevent_default()
                    event.stop()
                    return
                # Enter is handled via action_submit_message binding
                elif key == "escape":
                    file_menu.hide()
                    self._showing_file_menu = False
                    event.prevent_default()
                    event.stop()
                    return

        # Ctrl+X — remove last attachment
        if key == "ctrl+x":
            if self._attachments:
                removed = self._attachments.pop()
                self._added_paths.discard(removed.path)
                self.query_one("#attachment-bar", AttachmentBar).update_items(self._attachments)
                event.prevent_default()
                event.stop()
                return

        # Enter is handled via BINDINGS with priority=True
        # Shift+Enter inserts newline (TextArea handles this natively)

    # ── Menu event handlers ──────────────────────────────────────────────

    def on_command_menu_selected(self, event: CommandMenu.Selected) -> None:
        """A slash command was selected from the menu."""
        ta = self.query_one("#input-area", TextArea)
        ta.clear()
        self._showing_command_menu = False
        # Dispatch through the app's slash command handler
        from ..app import EmDashApp
        app = self.app
        if isinstance(app, EmDashApp):
            app.handle_slash_command(event.command)

    def on_command_menu_tab_complete(self, event: CommandMenu.TabComplete) -> None:
        """Tab-complete a slash command (fills input but doesn't send)."""
        ta = self.query_one("#input-area", TextArea)
        ta.clear()
        ta.insert(event.command + " ")

    def on_command_menu_dismissed(self, event: CommandMenu.Dismissed) -> None:
        self._showing_command_menu = False

    def on_file_menu_selected(self, event: FileMenu.Selected) -> None:
        """A file was selected from the @ menu."""
        ta = self.query_one("#input-area", TextArea)

        # Remove the @query from the text
        text = ta.text
        at_pos = text.rfind("@")
        if at_pos >= 0:
            ta.clear()
            ta.insert(text[:at_pos])

        # Add as attachment
        self._add_attachment(event.path)
        self._showing_file_menu = False

    def on_file_menu_dismissed(self, event: FileMenu.Dismissed) -> None:
        self._showing_file_menu = False

    # ── Attachment management ────────────────────────────────────────────

    def _add_attachment(self, path: str) -> None:
        resolved = str(Path(path).resolve())
        if resolved in self._added_paths:
            return
        att = FileAttachment(path)
        self._attachments.append(att)
        self._added_paths.add(resolved)
        self.query_one("#attachment-bar", AttachmentBar).update_items(self._attachments)

    def _try_paste_image(self) -> bool:
        """Try to detect and attach a clipboard image. Returns True if found."""
        path = detect_clipboard_image()
        if path:
            self._add_attachment(path)
            return True
        return False

    def action_paste_image(self) -> None:
        """Handle Ctrl+V binding to paste clipboard image."""
        path = detect_clipboard_image()
        if path:
            self._add_attachment(path)
            self.notify("Image attached", severity="information", timeout=2)
        else:
            # No image found, let the TextArea handle normal paste
            ta = self.query_one("#input-area", TextArea)
            ta.action_paste()

    # ── Submit ───────────────────────────────────────────────────────────

    def action_submit_message(self) -> None:
        """Handle the Enter key binding to submit."""
        # Check if we're in a menu that should handle Enter differently
        if self._showing_command_menu:
            cmd_menu = self.screen.query_one("#command-menu", CommandMenu)
            if cmd_menu.is_visible:
                cmd_menu.select_current()
                return
        if self._showing_file_menu:
            file_menu = self.screen.query_one("#file-menu", FileMenu)
            if file_menu.is_visible:
                file_menu.select_current()
                return
        # Otherwise, submit the message
        self._submit()

    def _submit(self) -> None:
        ta = self.query_one("#input-area", TextArea)
        text = ta.text.strip()
        if not text and not self._attachments:
            return

        attachments = list(self._attachments)
        self._attachments.clear()
        self._added_paths.clear()
        self.query_one("#attachment-bar", AttachmentBar).update_items([])

        self.post_message(self.Submitted(text, attachments))
        ta.clear()

    # ── Focus event handlers ────────────────────────────────────────────

    def on_text_area_focus(self, event) -> None:
        """Update prompt styling when focused."""
        self._update_prompt_style(focused=True)

    def on_text_area_blur(self, event) -> None:
        """Update prompt styling when blurred."""
        self._update_prompt_style(focused=False)

    def _update_prompt_style(self, focused: bool) -> None:
        """Update prompt brightness based on focus state."""
        colors = _get_colors(self.mode)
        try:
            prompt = self.query_one("#input-prompt", Static)
            if focused:
                # Brighter color when focused
                prompt.update(f"[bold #e0c08a]› [/bold #e0c08a]")
            else:
                prompt.update(f"[bold {colors['prompt']}]› [/bold {colors['prompt']}]")
        except Exception:
            pass

    # ── Public API ───────────────────────────────────────────────────────

    @property
    def text_area(self) -> TextArea:
        return self.query_one("#input-area", TextArea)

    def set_disabled(self, disabled: bool) -> None:
        """Enable or disable input."""
        ta = self.query_one("#input-area", TextArea)
        ta.disabled = disabled
        if disabled:
            self.add_class("disabled")
        else:
            self.remove_class("disabled")

    def focus_input(self) -> None:
        self.query_one("#input-area", TextArea).focus()
