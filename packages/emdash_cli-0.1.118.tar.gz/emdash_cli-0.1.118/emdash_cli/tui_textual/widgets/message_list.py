"""Scrollable message history with styled bubbles, streaming, and spinner."""

from __future__ import annotations

import subprocess
import platform
from datetime import datetime

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.message import Message as TextualMessage
from textual.reactive import reactive
from textual.timer import Timer
from textual.widget import Widget
from textual.widgets import Markdown, Static

from ..state import Message


# ── Colors (zen minimal palette) ─────────────────────────────────────────

ROLE_COLORS = {
    "user": "#d4a574",        # warm amber for user
    "assistant": "#a0a0a0",   # soft gray for assistant
    "system": "#7a7a7a",      # dim gray for system
}
USER_PREFIX = "›"
ASSISTANT_PREFIX = "◆"
SYSTEM_PREFIX = "○"

# Braille spinner frames (same as Ink's Spinner.tsx)
SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
SPINNER_INTERVAL = 0.08  # seconds

# Collapse threshold
COLLAPSE_LINE_THRESHOLD = 15


def _format_relative_time(ts: datetime | None) -> str:
    """Format a timestamp as relative time (e.g., 'just now', '2m ago')."""
    if ts is None:
        return ""
    now = datetime.now()
    delta = now - ts
    seconds = int(delta.total_seconds())

    if seconds < 60:
        return "just now"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes}m ago"
    elif seconds < 86400:
        hours = seconds // 3600
        return f"{hours}h ago"
    else:
        days = seconds // 86400
        return f"{days}d ago"


class ClickableStatic(Static):
    """Static that emits a Clicked message when clicked."""

    class Clicked(TextualMessage):
        def __init__(self, widget: "ClickableStatic") -> None:
            super().__init__()
            self.widget = widget

    def on_click(self, event) -> None:
        self.post_message(self.Clicked(self))
        event.stop()


def _copy_to_clipboard(text: str) -> bool:
    """Copy text to system clipboard. Returns True on success."""
    system = platform.system()
    try:
        if system == "Darwin":
            subprocess.run(["pbcopy"], input=text.encode(), check=True)
            return True
        elif system == "Linux":
            subprocess.run(
                ["xclip", "-selection", "clipboard"],
                input=text.encode(),
                check=True,
            )
            return True
        elif system == "Windows":
            subprocess.run(["clip"], input=text.encode(), check=True)
            return True
    except Exception:
        pass
    return False


# ── MessageBubble ────────────────────────────────────────────────────────

class MessageBubble(Widget):
    """A single chat message with colored bullet and role label.

    Features:
    - Focusable with highlight border
    - Press 'c' to copy content to clipboard
    - Long messages (>15 lines) are collapsible
    - Timestamps shown as relative time
    """

    can_focus = True

    BINDINGS = [
        Binding("c", "copy", "Copy"),
        Binding("enter", "toggle_collapse", "Expand/Collapse"),
    ]

    DEFAULT_CSS = """
    MessageBubble {
        width: 1fr;
        height: auto;
        margin: 1 0;
        padding: 0 2;
        background: transparent;
    }
    MessageBubble:focus {
        background: #1a1a1a;
    }
    MessageBubble.user {
        /* No special background - just bold amber text */
    }
    MessageBubble.assistant {
        /* No special background - content speaks for itself */
    }
    MessageBubble.system {
        /* Subtle system messages */
    }
    MessageBubble Horizontal {
        width: 1fr;
        height: auto;
    }
    MessageBubble .msg-prefix {
        width: 3;
        height: auto;
    }
    MessageBubble .msg-body {
        width: 1fr;
        height: auto;
    }
    MessageBubble .msg-content {
        margin: 0;
        height: auto;
    }
    MessageBubble .msg-collapse-toggle {
        color: #5a5a5a;
        margin: 0;
    }
    MessageBubble .msg-collapse-toggle:hover {
        color: #9a9a9a;
    }
    MessageBubble .copy-flash {
        color: #7a9f7a;
        height: 1;
    }
    """

    collapsed = reactive(False)

    def __init__(self, message: Message, **kwargs) -> None:
        super().__init__(**kwargs, classes=message.role)
        self.message = message
        # Ensure content is a string for line counting
        content = message.content if isinstance(message.content, str) else str(message.content)
        self._line_count = content.count('\n') + 1
        self._should_collapse = self._line_count > COLLAPSE_LINE_THRESHOLD
        if self._should_collapse:
            self.collapsed = True

    def compose(self) -> ComposeResult:
        role = self.message.role
        content = self.message.content if isinstance(self.message.content, str) else str(self.message.content)

        # Choose prefix based on role
        if role == "user":
            prefix = USER_PREFIX
            prefix_color = "#d4a574"
        elif role == "assistant":
            prefix = ASSISTANT_PREFIX
            prefix_color = "#7a9f7a"
        else:
            prefix = SYSTEM_PREFIX
            prefix_color = "#d47a7a" if "error" in content.lower() else "#7a7a7a"

        with Horizontal():
            # Prefix column
            yield Static(
                f"[{prefix_color}]{prefix}[/{prefix_color}]",
                classes="msg-prefix",
                markup=True,
            )

            # Content column
            with Vertical(classes="msg-body"):
                if role == "user":
                    # User: bold amber text, no markdown
                    yield Static(
                        f"[bold #d4a574]{content}[/bold #d4a574]",
                        classes="msg-content",
                        markup=True,
                    )
                elif role == "system":
                    # System: dim gray text
                    yield Static(
                        f"[#7a7a7a]{content}[/#7a7a7a]",
                        classes="msg-content",
                        markup=True,
                    )
                else:
                    # Assistant: normal markdown
                    yield Markdown(
                        self._get_display_content(),
                        classes="msg-content",
                        id="msg-md-content",
                    )

                if self._should_collapse:
                    toggle_text = self._get_toggle_text()
                    yield ClickableStatic(toggle_text, classes="msg-collapse-toggle", id="collapse-toggle", markup=True)

                yield Static("", classes="copy-flash", id="copy-flash")

    def _get_display_content(self) -> str:
        """Get content to display, respecting collapsed state."""
        content = self.message.content if isinstance(self.message.content, str) else str(self.message.content)
        if not self._should_collapse or not self.collapsed:
            return content
        lines = content.split('\n')
        preview = '\n'.join(lines[:COLLAPSE_LINE_THRESHOLD])
        return preview + "\n..."

    def _get_toggle_text(self) -> str:
        """Get the text for the collapse/expand toggle."""
        hidden = self._line_count - COLLAPSE_LINE_THRESHOLD
        if self.collapsed:
            return f"[#7a7a7a]▼ Show more ({hidden} more lines)[/#7a7a7a]"
        else:
            return "[#7a7a7a]▲ Show less[/#7a7a7a]"

    def watch_collapsed(self, value: bool) -> None:
        """Update content when collapsed state changes."""
        if self.message.role == "system":
            return
        try:
            md = self.query_one("#msg-md-content", Markdown)
            md.update(self._get_display_content())
            if self._should_collapse:
                toggle = self.query_one("#collapse-toggle", ClickableStatic)
                toggle.update(self._get_toggle_text())
        except Exception:
            pass

    def action_toggle_collapse(self) -> None:
        """Toggle collapsed state."""
        if self._should_collapse:
            self.collapsed = not self.collapsed

    def action_copy(self) -> None:
        """Copy message content to clipboard."""
        content = self.message.content if isinstance(self.message.content, str) else str(self.message.content)
        if _copy_to_clipboard(content):
            self._show_copy_flash("Copied!")
        else:
            self._show_copy_flash("Copy failed")

    def _show_copy_flash(self, text: str) -> None:
        """Briefly show a copy confirmation."""
        try:
            flash = self.query_one("#copy-flash", Static)
            flash.update(f"[#7a9f7a]{text}[/#7a9f7a]")
            self.set_timer(1.5, lambda: flash.update(""))
        except Exception:
            pass

    def on_click(self, event) -> None:
        """Focus on click."""
        self.focus()

    def on_clickable_static_clicked(self, event: ClickableStatic.Clicked) -> None:
        """Handle clicks on the collapse toggle."""
        if event.widget.id == "collapse-toggle" and self._should_collapse:
            self.collapsed = not self.collapsed


# ── StreamingBubble (with animated spinner) ──────────────────────────────

class StreamingBubble(Widget):
    """Assistant message that updates as tokens stream in.

    Shows an animated braille spinner while content is arriving.
    """

    DEFAULT_CSS = """
    StreamingBubble {
        width: 1fr;
        height: auto;
        margin: 1 0;
        padding: 0 2;
        background: transparent;
    }
    StreamingBubble Horizontal {
        width: 1fr;
        height: auto;
    }
    StreamingBubble .stream-prefix {
        width: 3;
        height: auto;
    }
    StreamingBubble .stream-body {
        width: 1fr;
        height: auto;
    }
    StreamingBubble .stream-content {
        margin: 0;
        height: auto;
    }
    """

    content = reactive("", layout=True)

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._spinner_index = 0
        self._spinner_timer: Timer | None = None

    def compose(self) -> ComposeResult:
        with Horizontal():
            yield Static("", id="stream-prefix", classes="stream-prefix", markup=True)
            with Vertical(classes="stream-body"):
                yield Markdown("", classes="stream-content")

    def on_mount(self) -> None:
        self._update_header()
        self._spinner_timer = self.set_interval(SPINNER_INTERVAL, self._tick_spinner)

    def _tick_spinner(self) -> None:
        self._spinner_index = (self._spinner_index + 1) % len(SPINNER_FRAMES)
        self._update_header()

    def _update_header(self) -> None:
        frame = SPINNER_FRAMES[self._spinner_index]
        try:
            self.query_one("#stream-prefix", Static).update(
                f"[#7a9f7a]{frame}[/#7a9f7a]"
            )
        except Exception:
            pass

    def watch_content(self, value: str) -> None:
        try:
            md = self.query_one(".stream-content", Markdown)
            md.update(value)
        except Exception:
            pass

    def stop_spinner(self) -> None:
        if self._spinner_timer is not None:
            self._spinner_timer.stop()
            self._spinner_timer = None
        try:
            self.query_one("#stream-prefix", Static).update(
                f"[#7a9f7a]{ASSISTANT_PREFIX}[/#7a9f7a]"
            )
        except Exception:
            pass


# ── MessageList ──────────────────────────────────────────────────────────

class MessageList(VerticalScroll):
    """Scrollable list of chat messages with auto-scroll."""

    DEFAULT_CSS = """
    MessageList {
        width: 1fr;
        height: 1fr;
        padding: 1 2;
    }
    """

    class NewMessage(TextualMessage):
        """Posted when a new message is added."""

    class RequestInputFocus(TextualMessage):
        """Posted when clicking on empty area to refocus input."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._streaming_bubble: StreamingBubble | None = None

    def add_message(self, message: Message) -> None:
        """Add a completed message to the list."""
        self._clear_streaming()
        bubble = MessageBubble(message)
        self.mount(bubble)
        self.scroll_end(animate=False)

    def start_streaming(self) -> None:
        """Begin a new streaming assistant response."""
        self._clear_streaming()
        self._streaming_bubble = StreamingBubble()
        self.mount(self._streaming_bubble)
        self.scroll_end(animate=False)

    def update_streaming(self, content: str) -> None:
        """Update the current streaming bubble with new content."""
        if self._streaming_bubble is not None:
            self._streaming_bubble.content = content
            self.scroll_end(animate=False)

    def finish_streaming(self, final_content: str) -> None:
        """Finish streaming and replace with a static bubble."""
        self._clear_streaming()
        msg = Message(role="assistant", content=final_content, timestamp=datetime.now())
        self.add_message(msg)

    def _clear_streaming(self) -> None:
        if self._streaming_bubble is not None:
            self._streaming_bubble.stop_spinner()
            self._streaming_bubble.remove()
            self._streaming_bubble = None

    def clear_messages(self) -> None:
        """Remove all messages."""
        self._clear_streaming()
        for child in list(self.children):
            child.remove()

    def on_click(self, event) -> None:
        """When clicking on message list, request input focus."""
        self.post_message(self.RequestInputFocus())
