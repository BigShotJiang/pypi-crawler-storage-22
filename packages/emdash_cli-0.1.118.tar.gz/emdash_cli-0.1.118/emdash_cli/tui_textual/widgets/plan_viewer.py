"""Plan approval widget with keyboard shortcuts and reply mode.

Matches the Ink TUI's ApprovalPrompt: y/n/r shortcuts, cursor-based
option selection, and inline reply input.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.message import Message
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Markdown, Static, TextArea

# Colors matching Ink TUI
BORDER_COLOR = "#c9a075"
HEADER_COLOR = "#c9a075"
SELECTED_COLOR = "#e8e8e8"
UNSELECTED_COLOR = "#a8a8a8"
SHORTCUT_COLOR = "#6a6a6a"
CURSOR_COLOR = "#7a9f7a"


class PlanViewer(Widget):
    """Displays a plan with approve/reject/reply options.

    Keyboard:
        y           Approve
        n           Reject
        r           Enter reply mode
        Up/Down     Move cursor between options
        Enter       Select current option
        Esc         Cancel reply mode
    """

    can_focus = True

    BINDINGS = [
        Binding("up", "move_up", "Up", show=False),
        Binding("down", "move_down", "Down", show=False),
        Binding("enter", "select", "Select", show=False),
        Binding("y", "approve", "Approve", show=False),
        Binding("n", "reject", "Reject", show=False),
        Binding("r", "reply", "Reply", show=False),
    ]

    DEFAULT_CSS = """
    PlanViewer {
        height: auto;
        margin: 1 2;
        padding: 1;
        border: round #c9a075;
    }
    PlanViewer .plan-header {
        text-style: bold;
        color: #c9a075;
        height: 1;
        margin: 0 0 1 0;
    }
    PlanViewer .plan-content {
        margin: 0 0 1 0;
        max-height: 20;
        overflow-y: auto;
    }
    PlanViewer .plan-options {
        height: auto;
    }
    PlanViewer .plan-option {
        height: 1;
    }
    PlanViewer .plan-hint {
        color: #6a6a6a;
        height: 1;
        margin: 1 0 0 0;
    }
    PlanViewer .plan-reply {
        height: 3;
        margin: 1 0 0 0;
        display: none;
    }
    PlanViewer .plan-reply.visible {
        display: block;
    }
    """

    selected_index = reactive(0)

    class Approved(Message):
        def __init__(self, approval_type: str) -> None:
            super().__init__()
            self.approval_type = approval_type

    class Rejected(Message):
        def __init__(self, approval_type: str, feedback: str = "") -> None:
            super().__init__()
            self.approval_type = approval_type
            self.feedback = feedback

    OPTIONS = [
        ("y", "Approve", "Accept and proceed with the plan"),
        ("n", "Reject", "Decline and cancel"),
        ("r", "Reply", "Send feedback or ask questions"),
    ]

    def __init__(self, plan: str, approval_type: str = "plan", **kwargs) -> None:
        super().__init__(**kwargs)
        self.plan = plan
        self.approval_type = approval_type
        self._reply_mode = False

    def compose(self) -> ComposeResult:
        title = "? Plan Mode Requested" if self.approval_type == "planmode" else "? Plan Approval Required"
        yield Static(f"[bold {HEADER_COLOR}]{title}[/bold {HEADER_COLOR}]", classes="plan-header", markup=True)
        yield Markdown(self.plan, classes="plan-content")
        with Vertical(classes="plan-options"):
            for i, (key, label, desc) in enumerate(self.OPTIONS):
                yield Static("", id=f"opt-{i}", classes="plan-option", markup=True)
        yield Static(
            f"[{SHORTCUT_COLOR}]Press y/n/r or use ↑↓ and Enter[/{SHORTCUT_COLOR}]",
            id="plan-hint",
            classes="plan-hint",
            markup=True,
        )
        yield TextArea(id="plan-reply", classes="plan-reply")

    def on_mount(self) -> None:
        ta = self.query_one("#plan-reply", TextArea)
        ta.show_line_numbers = False
        self._render_options()
        # Focus immediately and also after a short delay
        self.focus()
        self.set_timer(0.1, self._grab_focus)

    def _grab_focus(self) -> None:
        """Aggressively grab focus."""
        if not self._reply_mode:
            self.focus()

    def on_click(self, event) -> None:
        """Focus when clicked."""
        if not self._reply_mode:
            self.focus()

    def _render_options(self) -> None:
        for i, (key, label, desc) in enumerate(self.OPTIONS):
            is_sel = i == self.selected_index
            cursor = f"[{CURSOR_COLOR}]❯[/{CURSOR_COLOR}]" if is_sel else " "
            text_color = SELECTED_COLOR if is_sel else UNSELECTED_COLOR
            bold = "bold " if is_sel else ""
            try:
                self.query_one(f"#opt-{i}", Static).update(
                    f" {cursor} [{SHORTCUT_COLOR}][{key}][/{SHORTCUT_COLOR}] "
                    f"[{bold}{text_color}]{label}[/{bold}{text_color}]  "
                    f"[{SHORTCUT_COLOR}]- {desc}[/{SHORTCUT_COLOR}]"
                )
            except Exception:
                pass

    def watch_selected_index(self, value: int) -> None:
        self._render_options()

    def action_move_up(self) -> None:
        """Move selection up."""
        if not self._reply_mode:
            self.selected_index = (self.selected_index - 1) % len(self.OPTIONS)

    def action_move_down(self) -> None:
        """Move selection down."""
        if not self._reply_mode:
            self.selected_index = (self.selected_index + 1) % len(self.OPTIONS)

    def action_select(self) -> None:
        """Select current option."""
        if self._reply_mode:
            ta = self.query_one("#plan-reply", TextArea)
            feedback = ta.text.strip()
            if feedback:
                self.post_message(self.Rejected(self.approval_type, feedback))
                self.remove()
        else:
            self._execute_selected()

    def action_approve(self) -> None:
        """Approve the plan."""
        if not self._reply_mode:
            self.post_message(self.Approved(self.approval_type))
            self.remove()

    def action_reject(self) -> None:
        """Reject the plan."""
        if not self._reply_mode:
            self.post_message(self.Rejected(self.approval_type))
            self.remove()

    def action_reply(self) -> None:
        """Enter reply mode."""
        if not self._reply_mode:
            self._enter_reply_mode()

    def on_key(self, event) -> None:
        if self._reply_mode:
            if event.key == "escape":
                self._exit_reply_mode()
                event.prevent_default()
                event.stop()
                return
            if event.key == "enter":
                ta = self.query_one("#plan-reply", TextArea)
                feedback = ta.text.strip()
                if feedback:
                    self.post_message(self.Rejected(self.approval_type, feedback))
                    self.remove()
                event.prevent_default()
                event.stop()
                return
            return

        key = event.key

        if key == "y":
            self.post_message(self.Approved(self.approval_type))
            self.remove()
            event.prevent_default()
            event.stop()
        elif key == "n":
            self.post_message(self.Rejected(self.approval_type))
            self.remove()
            event.prevent_default()
            event.stop()
        elif key == "r":
            self._enter_reply_mode()
            event.prevent_default()
            event.stop()
        elif key == "up":
            self.selected_index = (self.selected_index - 1) % len(self.OPTIONS)
            event.prevent_default()
            event.stop()
        elif key == "down":
            self.selected_index = (self.selected_index + 1) % len(self.OPTIONS)
            event.prevent_default()
            event.stop()
        elif key == "enter":
            self._execute_selected()
            event.prevent_default()
            event.stop()

    def _execute_selected(self) -> None:
        key = self.OPTIONS[self.selected_index][0]
        if key == "y":
            self.post_message(self.Approved(self.approval_type))
            self.remove()
        elif key == "n":
            self.post_message(self.Rejected(self.approval_type))
            self.remove()
        elif key == "r":
            self._enter_reply_mode()

    def _enter_reply_mode(self) -> None:
        self._reply_mode = True
        try:
            self.query_one("#plan-hint", Static).update(
                f"[{SHORTCUT_COLOR}]Type your reply, Enter to send, Esc to cancel[/{SHORTCUT_COLOR}]"
            )
            ta = self.query_one("#plan-reply", TextArea)
            ta.add_class("visible")
            ta.focus()
        except Exception:
            pass

    def _exit_reply_mode(self) -> None:
        self._reply_mode = False
        try:
            self.query_one("#plan-hint", Static).update(
                f"[{SHORTCUT_COLOR}]Press y/n/r or use ↑↓ and Enter[/{SHORTCUT_COLOR}]"
            )
            self.query_one("#plan-reply", TextArea).remove_class("visible")
            self.focus()
        except Exception:
            pass
