"""Three-stage community registry browser.

Matches the Ink TUI's RegistryBrowser.tsx — Category → Component → Details
with install support.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.message import Message
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static

# Colors
HEADER_COLOR = "#c9a075"
SELECTED_FG = "#f0e8ec"
NORMAL_FG = "#a8a8a8"
DIM_COLOR = "#6a6a6a"
ACCENT_COLOR = "#7a9f7a"
AUTHOR_COLOR = "#9a9fc9"
VERSION_COLOR = "#9ac9c9"
BUTTON_ACTIVE = "#e8e8e8"
BUTTON_INACTIVE = "#6a6a6a"

CATEGORIES = [
    ("skills", "Skills"),
    ("rules", "Rules"),
    ("agents", "Agents"),
    ("verifiers", "Verifiers"),
]


class RegistryBrowser(Widget):
    """Three-stage registry browser.

    Stage 1: Select a category (Skills, Rules, Agents, Verifiers)
    Stage 2: Browse components in that category
    Stage 3: View component details + Install

    Keyboard:
        Up/Down, j/k   Navigate
        Enter           Select / Install
        1-9             Quick-select by number
        Esc/Backspace   Go back one stage / dismiss
    """

    DEFAULT_CSS = """
    RegistryBrowser {
        height: auto;
        max-height: 80%;
        margin: 1 2;
        padding: 1;
        border: round #c9a075;
    }
    RegistryBrowser .rb-header {
        text-style: bold;
        color: #c9a075;
        height: 1;
        margin: 0 0 1 0;
    }
    RegistryBrowser .rb-list {
        height: auto;
        max-height: 18;
    }
    RegistryBrowser .rb-item {
        height: 1;
    }
    RegistryBrowser .rb-empty {
        color: #6a6a6a;
        height: 1;
    }
    RegistryBrowser .rb-detail-field {
        height: auto;
        margin: 0 0 0 2;
    }
    RegistryBrowser .rb-actions {
        height: 1;
        margin: 1 0 0 0;
    }
    RegistryBrowser .rb-hint {
        color: #6a6a6a;
        height: 1;
        margin: 1 0 0 0;
    }
    """

    selected_index = reactive(0)
    stage = reactive(1)

    class Install(Message):
        def __init__(self, category: str, name: str) -> None:
            super().__init__()
            self.category = category
            self.name = name

    class Dismissed(Message):
        pass

    def __init__(self, registry_data: dict, **kwargs) -> None:
        super().__init__(**kwargs)
        self._data = registry_data  # {skills: {name: {...}}, rules: {...}, ...}
        self._category: str | None = None
        self._component_name: str | None = None
        self._component_list: list[tuple[str, dict]] = []
        self._detail_action = 0  # 0=Install, 1=Back

    def compose(self) -> ComposeResult:
        yield Static("", id="rb-header", classes="rb-header", markup=True)
        with VerticalScroll(classes="rb-list"):
            yield Vertical(id="rb-items")
        yield Static("", id="rb-hint", classes="rb-hint", markup=True)

    def on_mount(self) -> None:
        self._render_stage()
        self.focus()

    # ── Stage rendering ─────────────────────────────────────────────

    def _render_stage(self) -> None:
        if self.stage == 1:
            self._render_categories()
        elif self.stage == 2:
            self._render_components()
        elif self.stage == 3:
            self._render_details()

    def _render_categories(self) -> None:
        try:
            self.query_one("#rb-header", Static).update(
                f"[bold {HEADER_COLOR}]Registry — Select Category[/bold {HEADER_COLOR}]"
            )
        except Exception:
            pass

        container = self.query_one("#rb-items", Vertical)
        container.remove_children()

        for i, (key, label) in enumerate(CATEGORIES):
            count = len(self._data.get(key, {}))
            is_sel = i == self.selected_index
            cursor = f"[{ACCENT_COLOR}]❯[/{ACCENT_COLOR}]" if is_sel else " "
            text_color = SELECTED_FG if is_sel else NORMAL_FG
            bold = "bold " if is_sel else ""
            container.mount(Static(
                f" {cursor} [{bold}{text_color}]{label}[/{bold}{text_color}]"
                f"  [{DIM_COLOR}]({count} components)[/{DIM_COLOR}]",
                classes="rb-item",
                markup=True,
            ))

        self._update_hint("↑↓/jk navigate, Enter select, Esc dismiss")

    def _render_components(self) -> None:
        cat_label = dict(CATEGORIES).get(self._category, self._category)
        try:
            self.query_one("#rb-header", Static).update(
                f"[bold {HEADER_COLOR}]Registry — {cat_label}[/bold {HEADER_COLOR}]"
            )
        except Exception:
            pass

        container = self.query_one("#rb-items", Vertical)
        container.remove_children()

        if not self._component_list:
            container.mount(Static(
                f"[{DIM_COLOR}]No components available[/{DIM_COLOR}]",
                classes="rb-empty",
                markup=True,
            ))
            self._update_hint("Esc/Backspace to go back")
            return

        display = self._component_list[:10]
        for i, (name, comp) in enumerate(display):
            is_sel = i == self.selected_index
            cursor = f"[{ACCENT_COLOR}]❯[/{ACCENT_COLOR}]" if is_sel else " "
            text_color = SELECTED_FG if is_sel else NORMAL_FG
            bold = "bold " if is_sel else ""
            desc = comp.get("description", "")[:50]
            if len(comp.get("description", "")) > 50:
                desc += "..."

            container.mount(Static(
                f" {cursor} [{DIM_COLOR}]{i + 1}.[/{DIM_COLOR}] "
                f"[{bold}{text_color}]{name}[/{bold}{text_color}]"
                f"  [{DIM_COLOR}]{desc}[/{DIM_COLOR}]",
                classes="rb-item",
                markup=True,
            ))

        remaining = len(self._component_list) - 10
        if remaining > 0:
            container.mount(Static(
                f"  [{DIM_COLOR}]... and {remaining} more[/{DIM_COLOR}]",
                classes="rb-item",
                markup=True,
            ))

        self._update_hint("↑↓/jk navigate, 1-9 quick select, Enter view, Esc back")

    def _render_details(self) -> None:
        if not self._component_name:
            return

        comp = dict(self._component_list).get(self._component_name, {})
        try:
            self.query_one("#rb-header", Static).update(
                f"[bold {HEADER_COLOR}]{self._component_name}[/bold {HEADER_COLOR}]"
            )
        except Exception:
            pass

        container = self.query_one("#rb-items", Vertical)
        container.remove_children()

        # Description
        desc = comp.get("description", "No description")
        container.mount(Static(
            f"[{NORMAL_FG}]{desc}[/{NORMAL_FG}]",
            classes="rb-detail-field",
            markup=True,
        ))

        # Author
        author = comp.get("author")
        if author:
            container.mount(Static(
                f"[{DIM_COLOR}]Author:[/{DIM_COLOR}] [{AUTHOR_COLOR}]{author}[/{AUTHOR_COLOR}]",
                classes="rb-detail-field",
                markup=True,
            ))

        # Version
        version = comp.get("version")
        if version:
            container.mount(Static(
                f"[{DIM_COLOR}]Version:[/{DIM_COLOR}] [{VERSION_COLOR}]{version}[/{VERSION_COLOR}]",
                classes="rb-detail-field",
                markup=True,
            ))

        # URL
        url = comp.get("url")
        if url:
            container.mount(Static(
                f"[{DIM_COLOR}]URL:[/{DIM_COLOR}] [{DIM_COLOR}]{url}[/{DIM_COLOR}]",
                classes="rb-detail-field",
                markup=True,
            ))

        # Action buttons
        container.mount(Static("", classes="rb-item"))  # spacer
        actions = [("install", "Install"), ("back", "Back")]
        for i, (aid, label) in enumerate(actions):
            is_sel = i == self._detail_action
            cursor = f"[{ACCENT_COLOR}]❯[/{ACCENT_COLOR}]" if is_sel else " "
            color = BUTTON_ACTIVE if is_sel else BUTTON_INACTIVE
            bold = "bold " if is_sel else ""
            container.mount(Static(
                f" {cursor} [{bold}{color}]{label}[/{bold}{color}]",
                classes="rb-item",
                markup=True,
            ))

        self._update_hint("↑↓ select action, Enter confirm, Esc back")

    def _update_hint(self, text: str) -> None:
        try:
            self.query_one("#rb-hint", Static).update(f"[{DIM_COLOR}]{text}[/{DIM_COLOR}]")
        except Exception:
            pass

    # ── Reactive watchers ───────────────────────────────────────────

    def watch_selected_index(self, value: int) -> None:
        self._render_stage()

    def watch_stage(self, value: int) -> None:
        self.selected_index = 0
        self._render_stage()

    # ── Key handling ────────────────────────────────────────────────

    def on_key(self, event) -> None:
        key = event.key

        if key == "escape" or key == "backspace":
            self._go_back()
            event.prevent_default()
            event.stop()
            return

        if self.stage == 1:
            self._handle_stage1(key, event)
        elif self.stage == 2:
            self._handle_stage2(key, event)
        elif self.stage == 3:
            self._handle_stage3(key, event)

    def _handle_stage1(self, key: str, event) -> None:
        if key in ("up", "k"):
            self.selected_index = (self.selected_index - 1) % len(CATEGORIES)
            event.prevent_default()
            event.stop()
        elif key in ("down", "j"):
            self.selected_index = (self.selected_index + 1) % len(CATEGORIES)
            event.prevent_default()
            event.stop()
        elif key == "enter":
            self._select_category()
            event.prevent_default()
            event.stop()

    def _handle_stage2(self, key: str, event) -> None:
        max_idx = min(len(self._component_list), 10)
        if key in ("up", "k"):
            if max_idx:
                self.selected_index = (self.selected_index - 1) % max_idx
            event.prevent_default()
            event.stop()
        elif key in ("down", "j"):
            if max_idx:
                self.selected_index = (self.selected_index + 1) % max_idx
            event.prevent_default()
            event.stop()
        elif key in "123456789":
            idx = int(key) - 1
            if idx < max_idx:
                self.selected_index = idx
                self._select_component()
            event.prevent_default()
            event.stop()
        elif key == "enter":
            self._select_component()
            event.prevent_default()
            event.stop()

    def _handle_stage3(self, key: str, event) -> None:
        if key in ("up", "k"):
            self._detail_action = (self._detail_action - 1) % 2
            self._render_details()
            event.prevent_default()
            event.stop()
        elif key in ("down", "j"):
            self._detail_action = (self._detail_action + 1) % 2
            self._render_details()
            event.prevent_default()
            event.stop()
        elif key == "enter":
            if self._detail_action == 0:
                self._do_install()
            else:
                self._go_back()
            event.prevent_default()
            event.stop()

    # ── Navigation ──────────────────────────────────────────────────

    def _select_category(self) -> None:
        if 0 <= self.selected_index < len(CATEGORIES):
            cat_key = CATEGORIES[self.selected_index][0]
            self._category = cat_key
            components = self._data.get(cat_key, {})
            self._component_list = list(components.items())
            self.stage = 2

    def _select_component(self) -> None:
        display = self._component_list[:10]
        if 0 <= self.selected_index < len(display):
            name, _ = display[self.selected_index]
            self._component_name = name
            self._detail_action = 0
            self.stage = 3

    def _go_back(self) -> None:
        if self.stage == 3:
            self.stage = 2
        elif self.stage == 2:
            self._category = None
            self._component_list = []
            self.stage = 1
        else:
            self.post_message(self.Dismissed())
            self.remove()

    def _do_install(self) -> None:
        if self._category and self._component_name:
            self.post_message(self.Install(self._category, self._component_name))
            self.remove()
