"""Status bar showing model, mode, session, and processing state."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static


class StatusBar(Widget):
    """Footer status bar displaying current model, mode, and session info."""

    DEFAULT_CSS = """
    StatusBar {
        dock: top;
        height: 1;
        background: $accent-darken-2;
        color: $text;
        padding: 0 1;
    }
    StatusBar Horizontal {
        width: 1fr;
        height: 1;
    }
    StatusBar .status-model {
        width: auto;
        color: $text;
        text-style: bold;
    }
    StatusBar .status-mode {
        width: auto;
        margin: 0 0 0 2;
        color: $accent-lighten-2;
    }
    StatusBar .status-session {
        width: auto;
        margin: 0 0 0 2;
        color: $text-muted;
    }
    StatusBar .status-processing {
        width: auto;
        margin: 0 0 0 2;
        color: $warning;
        text-style: bold;
    }
    StatusBar .status-spacer {
        width: 1fr;
    }
    StatusBar .status-help {
        width: auto;
        color: $text-muted;
    }
    """

    model = reactive("claude-sonnet-4")
    mode = reactive("code")
    session_id = reactive("")
    processing = reactive(False)

    def compose(self) -> ComposeResult:
        with Horizontal():
            yield Static("", id="status-model", classes="status-model")
            yield Static("", id="status-mode", classes="status-mode")
            yield Static("", id="status-session", classes="status-session")
            yield Static("", id="status-processing", classes="status-processing")
            yield Static("", id="status-typing", classes="status-session")
            yield Static("", classes="status-spacer")
            yield Static("/ commands  ctrl+c cancel  ctrl+q quit", classes="status-help")

    def watch_model(self, value: str) -> None:
        try:
            self.query_one("#status-model", Static).update(f"[{value}]")
        except Exception:
            pass

    def watch_mode(self, value: str) -> None:
        try:
            self.query_one("#status-mode", Static).update(f"[{value}]")
        except Exception:
            pass

    def watch_session_id(self, value: str) -> None:
        try:
            display = f"[{value[:8]}...]" if value else ""
            self.query_one("#status-session", Static).update(display)
        except Exception:
            pass

    def watch_processing(self, value: bool) -> None:
        try:
            self.query_one("#status-processing", Static).update(
                "processing..." if value else ""
            )
        except Exception:
            pass

    def update_typing_users(self, users: set[str]) -> None:
        """Update the typing indicator with current set of typing users."""
        try:
            if users:
                names = ", ".join(sorted(users)[:3])
                suffix = " ..." if len(users) > 3 else ""
                self.query_one("#status-typing", Static).update(f"{names}{suffix} typing")
            else:
                self.query_one("#status-typing", Static).update("")
        except Exception:
            pass
