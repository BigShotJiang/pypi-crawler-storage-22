"""Animated thinking/reasoning block with live content preview."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.reactive import reactive
from textual.timer import Timer
from textual.widget import Widget
from textual.widgets import Static

# Same spinner as StreamingBubble
SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
SPINNER_INTERVAL = 0.08


class ThinkingBlock(Widget):
    """Shows model reasoning/thinking with an animated spinner.

    - Starts expanded with a braille spinner animation
    - Displays live thinking content as it streams
    - Collapses to a one-line summary when ``collapse()`` is called
    """

    DEFAULT_CSS = """
    ThinkingBlock {
        height: auto;
        margin: 0 2 1 2;
    }
    ThinkingBlock .think-header {
        height: 1;
    }
    ThinkingBlock .think-content {
        color: #8a8a9a;
        margin: 0 0 0 2;
        max-height: 6;
        overflow-y: auto;
    }
    ThinkingBlock .think-content.collapsed {
        display: none;
    }
    """

    content = reactive("", layout=True)

    def __init__(self, initial_content: str = "", **kwargs) -> None:
        super().__init__(**kwargs)
        self._initial = initial_content
        self._spinner_index = 0
        self._spinner_timer: Timer | None = None
        self._collapsed = False

    def compose(self) -> ComposeResult:
        yield Static("", id="think-header", classes="think-header", markup=True)
        yield Static("", id="think-content", classes="think-content", markup=True)

    def on_mount(self) -> None:
        if self._initial:
            self.content = self._initial
        self._update_header()
        self._spinner_timer = self.set_interval(SPINNER_INTERVAL, self._tick_spinner)

    def _tick_spinner(self) -> None:
        if self._collapsed:
            return
        self._spinner_index = (self._spinner_index + 1) % len(SPINNER_FRAMES)
        self._update_header()

    def _update_header(self) -> None:
        if self._collapsed:
            # Collapsed: static icon, one-line summary
            preview = self.content[:80].replace("\n", " ")
            if len(self.content) > 80:
                preview += "..."
            try:
                self.query_one("#think-header", Static).update(
                    f"[#6a6a8a]◐[/#6a6a8a] [#6a6a8a]Thinking:[/#6a6a8a] "
                    f"[#5a5a6a]{preview}[/#5a5a6a]"
                )
            except Exception:
                pass
        else:
            # Expanded: animated spinner
            frame = SPINNER_FRAMES[self._spinner_index]
            try:
                self.query_one("#think-header", Static).update(
                    f"[#6a6a8a]{frame}[/#6a6a8a] [#6a6a8a]Thinking...[/#6a6a8a]"
                )
            except Exception:
                pass

    def watch_content(self, value: str) -> None:
        if self._collapsed:
            self._update_header()
            return
        try:
            # Show last portion to keep it readable as it streams
            display = value
            if len(display) > 500:
                display = "..." + display[-497:]
            self.query_one("#think-content", Static).update(
                f"[#8a8a9a]{display}[/#8a8a9a]"
            )
        except Exception:
            pass

    def collapse(self) -> None:
        """Collapse to a one-line summary and stop the spinner."""
        self._collapsed = True
        if self._spinner_timer is not None:
            self._spinner_timer.stop()
            self._spinner_timer = None
        self._update_header()
        try:
            self.query_one("#think-content", Static).add_class("collapsed")
        except Exception:
            pass
