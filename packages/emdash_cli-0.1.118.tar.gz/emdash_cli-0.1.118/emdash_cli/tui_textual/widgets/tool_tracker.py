"""Animated tool execution tracker with tool-type colors and result output."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.reactive import reactive
from textual.timer import Timer
from textual.widget import Widget
from textual.widgets import Static

# Braille spinner
SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
SPINNER_INTERVAL = 0.08

# Tool-type color mapping (matches Ink TUI)
TOOL_COLORS = {
    "bash": "#7a9fc9",
    "execute_command": "#7a9fc9",
    "write_file": "#c9a075",
    "write": "#c9a075",
    "edit_file": "#c9a075",
    "edit": "#c9a075",
    "create_file": "#c9a075",
    "read_file": "#9a9fc9",
    "read": "#9a9fc9",
    "search": "#9ac9c9",
    "grep": "#9ac9c9",
    "find_files": "#9ac9c9",
    "glob": "#9ac9c9",
    "task": "#9a7ac9",
    "create_task": "#9a7ac9",
    "list_tasks": "#9a7ac9",
    "update_task": "#9a7ac9",
    "list_files": "#9ac9c9",
}

SUCCESS_COLOR = "#7a9f7a"
ERROR_COLOR = "#d47a7a"
BULLET = "●"


class ToolExecution(Widget):
    """Shows a tool call with an animated spinner that becomes a bullet on completion.

    Includes:
    - Animated braille spinner while running
    - Tool-type colored labels
    - Arg summary (file path, command, query)
    - Result output on completion (line count, diff stats, etc.)
    """

    DEFAULT_CSS = """
    ToolExecution {
        height: auto;
        margin: 0 2;
        padding: 0 1;
    }
    ToolExecution .tool-header {
        height: 1;
    }
    ToolExecution .tool-result {
        margin: 0 0 0 4;
        height: auto;
        max-height: 4;
    }
    """

    is_running = reactive(True)

    def __init__(self, name: str, args: dict, depth: int = 0, **kwargs) -> None:
        super().__init__(**kwargs)
        self.tool_name = name
        self.args = args
        self.depth = depth
        self._spinner_index = 0
        self._spinner_timer: Timer | None = None
        self._success: bool = True
        self._result_text: str = ""

    def compose(self) -> ComposeResult:
        yield Static("", id="tool-header", classes="tool-header", markup=True)
        yield Static("", id="tool-result", classes="tool-result", markup=True)

    def on_mount(self) -> None:
        self._update_header()
        self._spinner_timer = self.set_interval(SPINNER_INTERVAL, self._tick_spinner)

    def _tick_spinner(self) -> None:
        self._spinner_index = (self._spinner_index + 1) % len(SPINNER_FRAMES)
        self._update_header()

    def _tool_color(self) -> str:
        name_lower = self.tool_name.lower()
        for key, color in TOOL_COLORS.items():
            if key in name_lower:
                return color
        return "#8a8aaa"

    def _summarise_args(self) -> str:
        """One-line summary of tool arguments."""
        for key in ("path", "file_path"):
            if key in self.args:
                return str(self.args[key])
        if "command" in self.args:
            cmd = str(self.args["command"])
            return cmd[:60] + ("..." if len(cmd) > 60 else "")
        if "query" in self.args:
            return str(self.args["query"])[:60]
        if "pattern" in self.args:
            return str(self.args["pattern"])[:60]
        return ""

    def _format_result(self) -> str:
        """Format the result based on tool type."""
        if not self._result_text:
            return ""

        name_lower = self.tool_name.lower()

        # Line count for bash/read
        if any(k in name_lower for k in ("bash", "execute", "read")):
            lines = self._result_text.count("\n") + 1
            return f"[#8a8a8a]→ {lines} line(s)[/#8a8a8a]"

        # Diff stats for edit/write
        if any(k in name_lower for k in ("edit", "write", "create")):
            added = self._result_text.count("\n+")
            removed = self._result_text.count("\n-")
            if added or removed:
                return (
                    f"[{SUCCESS_COLOR}]+{added}[/{SUCCESS_COLOR}]"
                    f"/[{ERROR_COLOR}]-{removed}[/{ERROR_COLOR}]"
                )
            return f"[{SUCCESS_COLOR}]✓[/{SUCCESS_COLOR}]"

        # Task count
        if "task" in name_lower and "list" in name_lower:
            try:
                import json
                data = json.loads(self._result_text)
                if isinstance(data, list):
                    return f"[#8a8a8a]→ {len(data)} task(s)[/#8a8a8a]"
            except Exception:
                pass

        # Default: truncated preview
        preview = self._result_text[:100].replace("\n", " ")
        if len(self._result_text) > 100:
            preview += "..."
        return f"[#8a8a8a]{preview}[/#8a8a8a]"

    def _update_header(self) -> None:
        color = self._tool_color()
        summary = self._summarise_args()
        summary_str = f" [#9a9a9a]{summary}[/#9a9a9a]" if summary else ""

        if self.is_running:
            frame = SPINNER_FRAMES[self._spinner_index]
            indicator = f"[{color}]{frame}[/{color}]"
            trail = f" [{color}]...[/{color}]"
        else:
            bullet_color = SUCCESS_COLOR if self._success else ERROR_COLOR
            indicator = f"[{bullet_color}]{BULLET}[/{bullet_color}]"
            trail = ""

        indent = "  " * self.depth
        try:
            self.query_one("#tool-header", Static).update(
                f"{indent}  {indicator} [bold {color}]{self.tool_name}[/bold {color}]"
                f"{summary_str}{trail}"
            )
        except Exception:
            pass

    def set_result(self, success: bool, result: str | dict | None = None) -> None:
        """Mark tool as complete and show result."""
        self._success = success
        # Ensure result is a string
        if result is None:
            self._result_text = ""
        elif isinstance(result, str):
            self._result_text = result
        else:
            self._result_text = str(result)
        self.is_running = False

        # Stop spinner
        if self._spinner_timer is not None:
            self._spinner_timer.stop()
            self._spinner_timer = None

        self._update_header()

        # Show formatted result
        formatted = self._format_result()
        if formatted:
            try:
                self.query_one("#tool-result", Static).update(formatted)
            except Exception:
                pass

    def watch_is_running(self, value: bool) -> None:
        self._update_header()
