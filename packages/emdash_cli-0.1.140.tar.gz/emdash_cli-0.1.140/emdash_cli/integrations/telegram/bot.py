"""Backward-compatibility shim — canonical code lives in emdash_core."""

from emdash_core.channels.telegram.bot import *  # noqa: F401,F403
