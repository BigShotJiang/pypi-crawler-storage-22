"""Messaging provider abstractions for slash commands.

Provides a clean layer between CLI slash commands and messaging platforms
(Telegram, Slack, WhatsApp, etc.) so commands can be exposed uniformly
across providers.
"""

from .base import CommandProvider
from .telegram import TelegramCommandProvider

__all__ = [
    "CommandProvider",
    "TelegramCommandProvider",
]
