"""Base class for messaging provider command handling.

Each messaging platform (Telegram, Slack, WhatsApp, etc.) implements this
interface to translate CLI slash commands into platform-specific formats
and define which commands are handled locally vs. forwarded to the agent.
"""

from __future__ import annotations

from abc import ABC, abstractmethod


class CommandProvider(ABC):
    """Abstract base for messaging provider command support.

    Subclasses declare:
      - local commands (handled by the bridge, not forwarded to the agent)
      - provider-specific commands (only available on this platform)
      - command aliases (platform naming constraints)
      - excluded commands (CLI commands that don't make sense on this platform)
    """

    name: str = ""

    # ------------------------------------------------------------------
    # Subclass API
    # ------------------------------------------------------------------

    @abstractmethod
    def get_local_commands(self) -> dict[str, str]:
        """Return commands handled locally by this provider's bridge.

        These are CLI commands (like /plan, /code) that the bridge intercepts
        and handles itself instead of forwarding to the agent.

        Returns:
            Dict mapping command name (e.g. "/plan") to description.
        """
        ...

    @abstractmethod
    def get_provider_commands(self) -> dict[str, str]:
        """Return commands specific to this provider.

        These commands only exist on this platform (e.g. /tgstatus for
        Telegram) and are not part of the CLI command set.

        Returns:
            Dict mapping command name to description.
        """
        ...

    def get_command_aliases(self) -> dict[str, str]:
        """Return platform-specific command aliases.

        Some platforms have naming constraints (e.g. BotFather disallows
        hyphens). This maps the platform format to the canonical CLI format.

        Returns:
            Dict mapping alias (e.g. "/todo_add") to canonical ("/todo-add").
        """
        return {}

    def get_excluded_commands(self) -> set[str]:
        """Return CLI commands to exclude from this provider's command list.

        Some CLI commands don't make sense on messaging platforms
        (e.g. /paste, /telegram, /quit).

        Returns:
            Set of command names to exclude.
        """
        return set()

    @abstractmethod
    def format_command_list(self) -> list[tuple[str, str]]:
        """Format all commands for the platform's command registration.

        Returns a list of (command_name, description) tuples formatted
        for the platform (e.g. BotFather format for Telegram, JSON
        payload for Slack).

        Returns:
            List of (command, description) tuples.
        """
        ...

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    def get_cli_commands(self) -> dict[str, str]:
        """Return the full CLI slash command set."""
        from ...commands.agent.constants import SLASH_COMMANDS
        return dict(SLASH_COMMANDS)

    def get_all_commands(self) -> dict[str, str]:
        """Return all available commands (CLI + provider-specific)."""
        commands = self.get_cli_commands()
        commands.update(self.get_provider_commands())
        return commands

    def get_forwarded_commands(self) -> dict[str, str]:
        """Return commands that should be forwarded to the agent."""
        all_cmds = self.get_cli_commands()
        local = set(self.get_local_commands())
        excluded = self.get_excluded_commands()
        skip = local | excluded
        return {k: v for k, v in all_cmds.items() if k not in skip}

    def is_local_command(self, command: str) -> bool:
        """Check if a command should be handled locally (not forwarded)."""
        return (
            command in self.get_local_commands()
            or command in self.get_provider_commands()
        )

    def resolve_alias(self, command: str) -> str:
        """Resolve a platform-specific alias to the canonical CLI form."""
        return self.get_command_aliases().get(command, command)
