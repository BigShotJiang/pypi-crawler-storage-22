"""Telegram-specific command provider.

Defines which commands are handled locally by the Telegram bridge,
provider-specific commands, aliases for BotFather constraints, and
BotFather-compatible command list formatting.
"""

from __future__ import annotations

from .base import CommandProvider


class TelegramCommandProvider(CommandProvider):
    """Command provider for Telegram Bot API."""

    name = "telegram"

    def get_local_commands(self) -> dict[str, str]:
        """Commands intercepted and handled locally by the Telegram bridge.

        These are real CLI commands that the bridge handles itself
        (e.g. mode switching, session reset) rather than forwarding
        to the agent.
        """
        return {
            "/start": "Start the bot and show welcome message",
            "/stop": "Cancel current operation",
            "/cancel": "Cancel pending interaction",
            "/plan": "Switch to plan mode",
            "/code": "Switch to code mode",
            "/mode": "Show current mode",
            "/reset": "Reset session",
            "/update": "Update emdash and restart",
        }

    def get_provider_commands(self) -> dict[str, str]:
        """Telegram-only commands not present in the CLI."""
        return {
            "/tgstatus": "Show bot connection status",
            "/tgsettings": "Show display settings",
            "/tghelp": "Show Telegram help",
            "/thinking": "Toggle thinking display",
            "/tools": "Toggle tool calls display",
        }

    def get_command_aliases(self) -> dict[str, str]:
        """BotFather doesn't allow hyphens in command names."""
        return {
            "/todo_add": "/todo-add",
            "/verify_loop": "/verify-loop",
            "/team_old": "/team-old",
        }

    def get_excluded_commands(self) -> set[str]:
        """CLI commands that don't make sense on Telegram."""
        return {"/telegram", "/quit", "/paste"}

    def format_command_list(self) -> list[tuple[str, str]]:
        """Format commands for BotFather /setcommands.

        Returns list of (command, description) tuples in BotFather format:
        - No leading slash
        - Underscores instead of hyphens
        - Short descriptions (max 50 chars)
        """
        commands: list[tuple[str, str]] = []
        excluded = self.get_excluded_commands()

        # CLI commands
        for cmd, desc in self.get_cli_commands().items():
            if cmd in excluded:
                continue

            botfather_cmd = cmd.lstrip("/").replace("-", "_")
            # Strip argument placeholders (e.g. "/pr [url]" -> "pr")
            if " " in botfather_cmd:
                botfather_cmd = botfather_cmd.split()[0]

            # Truncate description for BotFather limits
            short_desc = desc.split("(")[0].strip()
            if len(short_desc) > 50:
                short_desc = short_desc[:47] + "..."

            commands.append((botfather_cmd, short_desc))

        # Provider-specific commands
        for cmd, desc in self.get_provider_commands().items():
            botfather_cmd = cmd.lstrip("/")
            short_desc = desc[:50] if len(desc) > 50 else desc
            commands.append((botfather_cmd, short_desc))

        return commands
