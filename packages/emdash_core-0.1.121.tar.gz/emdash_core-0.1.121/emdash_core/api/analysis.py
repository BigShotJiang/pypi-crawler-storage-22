"""Blast Radius and Change Story analysis endpoints."""

from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

router = APIRouter(prefix="/analysis", tags=["analysis"])


# ── Request Models ──


class BlastRadiusRequest(BaseModel):
    repo_path: str
    base_ref: str = "HEAD~1"
    head_ref: str = "HEAD"
    max_hops: int = 3


class ChangeStoryRequest(BaseModel):
    repo_path: str
    base_ref: str = "HEAD~1"
    head_ref: str = "HEAD"


# ── Response Models ──


class BlastRadiusSymbol(BaseModel):
    qualified_name: str
    file_path: str = ""
    change_kind: Optional[str] = None
    symbol_kind: Optional[str] = None
    severity: float = 0.0
    line_start: Optional[int] = None
    line_end: Optional[int] = None
    relation: Optional[str] = None
    details: dict = Field(default_factory=dict)


class BlastRadiusRing(BaseModel):
    hop: int
    label: str
    symbols: list[BlastRadiusSymbol]


class BlastRadiusResponse(BaseModel):
    rings: list[BlastRadiusRing]
    total_affected: int
    risk_level: str
    suggestions: list[str] = Field(default_factory=list)


class ChangeStoryChange(BaseModel):
    qualified_name: str
    file_path: str
    change_kind: str
    symbol_kind: str
    severity: float = 0.0
    line_start: Optional[int] = None
    line_end: Optional[int] = None
    old_qualified_name: Optional[str] = None
    details: dict = Field(default_factory=dict)


class ChangeStoryConsumer(BaseModel):
    qualified_name: str
    file_path: str = ""


class ChangeStory(BaseModel):
    kind: str
    title: str
    severity: str
    icon: str
    changes: list[ChangeStoryChange]
    affected_consumers: list[ChangeStoryConsumer] = Field(default_factory=list)
    summary: str


class ChangeStoryResponse(BaseModel):
    stories: list[ChangeStory]
    total_changes: int
    files_analyzed: int = 0
    summary: str


# ── Shared service logic ──


def _compute_blast_radius(repo_path: str, base_ref: str, head_ref: str, max_hops: int) -> dict:
    """Compute blast radius using AST diff engine.

    This is the shared implementation used by both the API endpoint and MCP tool.
    """
    from ..ingestion.ast_diff import ASTDiffEngine

    engine = ASTDiffEngine(repo_path)
    symbol_diff = engine.diff(base_ref=base_ref, head_ref=head_ref)

    if not symbol_diff.changes:
        return {
            "rings": [],
            "total_affected": 0,
            "risk_level": "low",
            "suggestions": ["No symbol-level changes detected between the refs."],
        }

    ring0_symbols = []
    for change in symbol_diff.changes:
        ring0_symbols.append({
            "qualified_name": change.qualified_name,
            "file_path": change.file_path,
            "change_kind": change.change_kind.value,
            "symbol_kind": change.symbol_kind.value,
            "severity": change.severity,
            "line_start": change.line_start,
            "line_end": change.line_end,
            "details": change.details,
        })

    rings = [{"hop": 0, "label": "Direct Changes", "symbols": ring0_symbols}]
    total_affected = len(ring0_symbols)

    max_severity = max((s["severity"] for s in ring0_symbols), default=0.0)
    if total_affected > 20 or max_severity >= 1.0:
        risk_level = "high"
    elif total_affected > 5:
        risk_level = "medium"
    else:
        risk_level = "low"

    suggestions = []
    sig_changes = [c for c in symbol_diff.changes if c.change_kind.value == "signature_changed"]
    if sig_changes:
        suggestions.append(
            f"{len(sig_changes)} signature change(s) detected. All callers must be updated."
        )
    removed = [c for c in symbol_diff.changes if c.change_kind.value == "removed"]
    if removed:
        suggestions.append(f"{len(removed)} symbol(s) removed. Check for broken references.")
    if symbol_diff.parse_errors:
        suggestions.append(f"{len(symbol_diff.parse_errors)} file(s) had parse errors.")
    suggestions.append(
        "Graph not connected — showing direct changes only. "
        "Run 'emdash ingest' and use MCP tools for full transitive analysis."
    )

    return {
        "rings": rings,
        "total_affected": total_affected,
        "risk_level": risk_level,
        "suggestions": suggestions,
    }


def _compute_change_story(repo_path: str, base_ref: str, head_ref: str) -> dict:
    """Compute change story using AST diff engine."""
    from ..ingestion.ast_diff import ASTDiffEngine

    engine = ASTDiffEngine(repo_path)
    symbol_diff = engine.diff(base_ref=base_ref, head_ref=head_ref)

    if not symbol_diff.changes:
        return {
            "stories": [],
            "total_changes": 0,
            "files_analyzed": 0,
            "summary": "No symbol-level changes detected.",
        }

    STORY_KINDS = {
        "CONTRACT_CHANGE": {"label": "Contract Changes", "severity": "high", "icon": "!"},
        "NEW_CAPABILITY": {"label": "New Capabilities", "severity": "low", "icon": "+"},
        "INTERNAL_CHANGE": {"label": "Internal Changes", "severity": "medium", "icon": "~"},
        "REMOVED": {"label": "Removals", "severity": "high", "icon": "-"},
        "TEST_COVERAGE": {"label": "Test Coverage", "severity": "info", "icon": "T"},
    }

    def _classify(change_kind: str, file_path: str) -> str:
        is_test = any(
            m in file_path
            for m in ("test_", "_test.", "tests/", "test/", "__tests__", ".test.", ".spec.")
        )
        if is_test:
            return "TEST_COVERAGE"
        if change_kind == "signature_changed":
            return "CONTRACT_CHANGE"
        elif change_kind == "added":
            return "NEW_CAPABILITY"
        elif change_kind in ("body_changed", "renamed", "moved"):
            return "INTERNAL_CHANGE"
        elif change_kind == "removed":
            return "REMOVED"
        return "INTERNAL_CHANGE"

    buckets: dict[str, list[dict]] = {k: [] for k in STORY_KINDS}
    for change in symbol_diff.changes:
        kind = _classify(change.change_kind.value, change.file_path)
        buckets[kind].append({
            "qualified_name": change.qualified_name,
            "file_path": change.file_path,
            "change_kind": change.change_kind.value,
            "symbol_kind": change.symbol_kind.value,
            "severity": change.severity,
            "line_start": change.line_start,
            "line_end": change.line_end,
            "old_qualified_name": change.old_qualified_name,
            "details": change.details,
        })

    stories = []
    for kind, changes_list in buckets.items():
        if not changes_list:
            continue
        meta = STORY_KINDS[kind]
        files = sorted({c["file_path"] for c in changes_list})
        title = (
            f"{meta['label']} in {files[0]}"
            if len(files) == 1
            else f"{meta['label']} across {len(files)} files"
        )
        stories.append({
            "kind": kind,
            "title": title,
            "severity": meta["severity"],
            "icon": meta["icon"],
            "changes": changes_list,
            "affected_consumers": [],
            "summary": f"{len(changes_list)} {meta['label'].lower()}.",
        })

    kind_counts = {k: len(v) for k, v in buckets.items() if v}
    parts = [f"{cnt} {STORY_KINDS[k]['label'].lower()}" for k, cnt in kind_counts.items()]
    overall_summary = "; ".join(parts) if parts else "No changes."

    return {
        "stories": stories,
        "total_changes": len(symbol_diff.changes),
        "files_analyzed": symbol_diff.files_analyzed,
        "summary": overall_summary,
    }


# ── Endpoints ──


@router.post("/blast-radius", response_model=BlastRadiusResponse)
async def blast_radius(req: BlastRadiusRequest):
    """Compute the blast radius of changes between two git refs.

    Returns rings of affected symbols expanding outward from direct changes.
    """
    try:
        result = _compute_blast_radius(req.repo_path, req.base_ref, req.head_ref, req.max_hops)
        return BlastRadiusResponse(**result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/change-story", response_model=ChangeStoryResponse)
async def change_story(req: ChangeStoryRequest):
    """Generate a structured narrative of code changes between two git refs.

    Groups changes into stories by kind: contract changes, new capabilities,
    internal changes, removals, and test coverage.
    """
    try:
        result = _compute_change_story(req.repo_path, req.base_ref, req.head_ref)
        return ChangeStoryResponse(**result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
