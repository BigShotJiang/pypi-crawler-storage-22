"""Open Agent - Self-evolving personal assistant with hierarchical memory.

This module provides the OpenAgent, a minimal, self-evolving, user-driven
personal assistant that writes itself based on user needs rather than
having heavy predefined opinions.

Components:
- OpenAgent: Main agent implementation
- PersonaManager: Manages learned user preferences
- CapabilityRegistry: Discovers and manages capabilities
- HierarchicalMemory: Multi-layer memory system (core/long-term/short-term)
- OpenToolkit: Extended toolkit with self-modification tools
"""

from .main_agent import OpenAgent
from .persona import PersonaManager, Preference
from .capabilities import Capability, CapabilityRegistry
from .memory import (
    HierarchicalMemory,
    CoreIdentity,
    LongTermMemory,
    ShortTermMemory,
    MemoryEntry,
)
from .memory_tools import MemoryToolSet
from .toolkit import OpenToolkit
from .tools import (
    LearnPreferenceTool,
    AddCapabilityTool,
    RemoveCapabilityTool,
    ListCapabilitiesTool,
    ExportPersonaTool,
    ImportPersonaTool,
    SuggestSkillTool,
)
from .prompts import build_open_system_prompt, OPEN_BOOTSTRAP_PROMPT

__all__ = [
    # Main agent
    "OpenAgent",
    # Legacy components
    "PersonaManager",
    "Preference",
    "Capability",
    "CapabilityRegistry",
    # Memory system
    "HierarchicalMemory",
    "CoreIdentity",
    "LongTermMemory",
    "ShortTermMemory",
    "MemoryEntry",
    "MemoryToolSet",
    # Toolkit
    "OpenToolkit",
    # Legacy tools
    "LearnPreferenceTool",
    "AddCapabilityTool",
    "RemoveCapabilityTool",
    "ListCapabilitiesTool",
    "ExportPersonaTool",
    "ImportPersonaTool",
    "SuggestSkillTool",
    # Prompts
    "build_open_system_prompt",
    "OPEN_BOOTSTRAP_PROMPT",
]