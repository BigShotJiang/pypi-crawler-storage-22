"""Open Agent - Self-evolving personal assistant with hierarchical memory.

This module provides the OpenAgent, a minimal, self-evolving, user-driven
personal assistant that writes itself based on user needs rather than
having heavy predefined opinions.

Features hierarchical memory:
- Core Identity: Fundamental user traits (role, values, goals)
- Long-term Memory: Learned preferences and patterns
- Short-term Memory: Recent context and session state
"""

import logging
from typing import Optional, TYPE_CHECKING
from pathlib import Path

from ..base import BaseAgent
from ..compaction_strategy import LLMSummaryStrategy
from ..events import AgentEventEmitter
from ..providers.factory import DEFAULT_MODEL
from .toolkit import OpenToolkit
from .persona import PersonaManager
from .capabilities import CapabilityRegistry
from .prompts import OPEN_BOOTSTRAP_PROMPT, build_open_system_prompt
from .memory import HierarchicalMemory
from .memory_tools import MemoryToolSet
if TYPE_CHECKING:
    from ..toolkits.base import BaseToolkit

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Default scaffolding templates — created on first run if missing
# ---------------------------------------------------------------------------

_DEFAULT_RULES_DIR = Path(__file__).parent / "defaults"

_SCAFFOLDING_FILENAMES: tuple[str, ...] = (
    "SOUL.md",
    "IDENTITY.md",
    "USER.md",
    "BOOTSTRAP.md",
)

_BASE_RULE_FILENAMES: tuple[str, ...] = (
    "SOUL.md",
    "USER.md",
    "IDENTITY.md",
)


def _load_default_scaffolding_files() -> dict[str, str]:
    """Load bundled default scaffolding templates from markdown files."""
    templates: dict[str, str] = {}
    for filename in _SCAFFOLDING_FILENAMES:
        template_path = _DEFAULT_RULES_DIR / filename
        try:
            templates[filename] = template_path.read_text(encoding="utf-8")
        except OSError:
            logger.warning("Default scaffolding template missing: %s", template_path)
    return templates


class OpenAgent(BaseAgent):
    """Self-evolving personal assistant with hierarchical memory.

    Key characteristics:
    - Minimal bootstrap prompt (<100 tokens base)
    - Hierarchical memory (core → long-term → short-term)
    - Learns user preferences over time
    - Discovers and adds capabilities dynamically
    - User-driven evolution (not opinionated)
    - Self-modifying through learning tools
    """

    # Agent identity
    name = "Open Assistant"
    agent_type = "open"
    description = "A minimal, self-evolving personal assistant that learns from you"

    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        emitter: Optional[AgentEventEmitter] = None,
        max_iterations: int = 100,
        verbose: bool = False,
        enable_thinking: Optional[bool] = None,
        session_id: Optional[str] = None,
        repo_root: Optional[Path] = None,
        persona_manager: Optional[PersonaManager] = None,
        capability_registry: Optional[CapabilityRegistry] = None,
        hierarchical_memory: Optional[HierarchicalMemory] = None,
    ):
        """Initialize the Open Agent.

        Args:
            model: LLM model to use
            emitter: Event emitter for streaming output
            max_iterations: Maximum tool iterations per run
            verbose: Enable verbose logging
            enable_thinking: Enable extended thinking
            session_id: Session ID for isolation
            repo_root: Repository root path
            persona_manager: Optional pre-configured PersonaManager
            capability_registry: Optional pre-configured CapabilityRegistry
            hierarchical_memory: Optional pre-configured HierarchicalMemory
        """
        # Store fields before calling super() since _get_toolkit() needs them
        self._session_id = session_id
        self._persona_manager = persona_manager
        self._capability_registry = capability_registry
        self._hierarchical_memory = hierarchical_memory
        self._repo_root = repo_root or Path.cwd()
        self._memory_tools: Optional[MemoryToolSet] = None

        # Call parent init (which calls _get_toolkit())
        super().__init__(
            model=model,
            emitter=emitter,
            max_iterations=max_iterations,
            verbose=verbose,
            enable_thinking=enable_thinking,
            session_id=session_id,
        )

        # Wire pre-compaction memory flush into the compaction strategy.
        # When context approaches the compaction threshold, the strategy
        # calls our hook to persist important facts before summarisation
        # destroys message detail (OpenClaw-style memory flush).
        if isinstance(self._compaction_strategy, LLMSummaryStrategy):
            self._compaction_strategy.set_pre_compact_hook(
                self._flush_memory_before_compaction
            )

    def _get_toolkit(self) -> "BaseToolkit":
        """Return the Open Toolkit with learning and memory capabilities."""
        # Initialize managers if not provided
        if self._persona_manager is None:
            self._persona_manager = PersonaManager(
                user_id=self._session_id or "default",
                emdash_dir=self._repo_root / ".emdash",
            )

        if self._capability_registry is None:
            self._capability_registry = CapabilityRegistry(
                emdash_dir=self._repo_root / ".emdash",
            )

        if self._hierarchical_memory is None:
            self._hierarchical_memory = HierarchicalMemory(
                session_id=self._session_id or "default",
                emdash_dir=self._repo_root / ".emdash",
            )

        # Create memory tools wrapper
        self._memory_tools = MemoryToolSet(self._hierarchical_memory)

        # Ensure scaffolding files exist for first-run users
        self._ensure_default_scaffolding()

        # Create toolkit with all capabilities
        return OpenToolkit(
            repo_root=self._repo_root,
            persona_manager=self._persona_manager,
            capability_registry=self._capability_registry,
            hierarchical_memory=self._hierarchical_memory,
            memory_tools=self._memory_tools,
        )

    def _ensure_default_scaffolding(self) -> None:
        """Create default SOUL/IDENTITY/USER/BOOTSTRAP files if they don't exist.

        Non-destructive: existing files are never overwritten.
        Also migrates files found at the repo root into .emdash/rules/.
        """
        scaffolding_files = _load_default_scaffolding_files()
        rules_dir = self._repo_root / ".emdash" / "rules"
        try:
            rules_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            logger.debug("Could not create rules directory: %s", rules_dir)
            return

        for filename in _SCAFFOLDING_FILENAMES:
            dest = rules_dir / filename
            if dest.exists():
                continue

            # Migrate from repo root if the file exists there
            root_file = self._repo_root / filename
            if root_file.exists():
                try:
                    dest.write_text(root_file.read_text(encoding="utf-8"), encoding="utf-8")
                    root_file.unlink()
                    logger.info("Migrated %s from repo root to %s", filename, dest)
                    continue
                except OSError:
                    logger.debug("Could not migrate %s", root_file)

            # Otherwise create the default template
            content = scaffolding_files.get(filename)
            if content is None:
                logger.debug("No bundled default scaffolding template for %s", filename)
                continue
            try:
                dest.write_text(content, encoding="utf-8")
                logger.info("Created default scaffolding file: %s", dest)
            except OSError:
                logger.debug("Could not write scaffolding file: %s", dest)

    def _build_system_prompt(self) -> str:
        """Build a dynamic system prompt with all memory layers."""
        # Ensure toolkit is created
        if not hasattr(self, 'toolkit') or self.toolkit is None:
            return OPEN_BOOTSTRAP_PROMPT

        prompt = build_open_system_prompt(
            persona_manager=self._persona_manager,
            capability_registry=self._capability_registry,
            hierarchical_memory=self._hierarchical_memory,
            toolkit=self.toolkit,
        )

        # Load persona files: project-level first, user-level fallback.
        # BOOTSTRAP.md is intentionally loaded only while onboarding is active.
        for filename in self._get_rule_files_for_prompt():
            content = ""
            for base in [self._repo_root / ".emdash" / "rules", Path.home() / ".emdash" / "rules"]:
                path = base / filename
                if path.exists():
                    try:
                        content = path.read_text().strip()
                        if content:
                            logger.info("Loaded rules file: %s", path)
                            break
                    except Exception:
                        logger.debug("Failed to read rules file: %s", path)
            if content:
                # Annotate so the agent knows which file this content came from
                # and can update it with write_to_file / edit_file.
                annotated = f"<!-- source: .emdash/rules/{filename} -->\n{content}"
                prompt = annotated + "\n\n" + prompt
            else:
                logger.debug("Rules file not found or empty: %s", filename)

        # Append runtime environment context (remote machine + active channel)
        prompt += "\n\n" + self._build_environment_section()

        return prompt

    def _should_include_bootstrap_rule(self) -> bool:
        """Return whether BOOTSTRAP.md should be included in prompt assembly.

        BOOTSTRAP.md is first-run guidance only. Keep it scoped to the
        very first interaction before core identity has been populated.
        """
        if not self._hierarchical_memory:
            return False

        core_count = len(self._hierarchical_memory.core.get_all())
        interaction_count = self._persona_manager.interaction_count if self._persona_manager else 0
        return core_count == 0 and interaction_count <= 1

    def _get_rule_files_for_prompt(self) -> tuple[str, ...]:
        """Select rule files to prepend to the system prompt."""
        if self._should_include_bootstrap_rule():
            return _BASE_RULE_FILENAMES + ("BOOTSTRAP.md",)
        return _BASE_RULE_FILENAMES

    def _build_environment_section(self) -> str:
        """Build a section describing the runtime environment.

        Tells the agent it lives on a remote machine and how the user
        is interacting (via which channel).
        """
        try:
            from ...channels.router import get_channel_router
            router = get_channel_router()
            if router and router.primary:
                channel_name = router.primary.name
            else:
                channel_name = "CLI"
        except Exception:
            channel_name = "CLI"

        return (
            "## Environment\n\n"
            "IMPORTANT: You live on a remote machine, NOT on the user's local computer. "
            "You have full access to this machine's terminal, filesystem, and network. "
            f"The user is interacting with you via **{channel_name}**. "
            "Keep this in mind when referencing files, paths, or system resources — "
            "everything you see and do happens on the remote machine."
        )

    def _get_available_subagents(self) -> dict[str, str]:
        """Return available sub-agent types."""
        return {
            "explore": "Read-only exploration of codebase",
            "plan": "Deep analysis and architecture planning",
            "research": "Web research and information gathering",
            "coder": "Code implementation (when file changes needed)",
        }

    def _pre_run(self, query: str, **kwargs) -> None:
        """Hook called before running the agent.
        
        Adds memory-enhanced context:
        - Capability detection
        - Applicable rule/skill activation
        - Persona interaction tracking
        - Short-term memory logging
        """
        # Check for pending channel messages
        try:
            from ...channels.stored import StoredChannel
            stored = StoredChannel(self._repo_root / ".emdash")
            pending = stored.get_and_clear()
            if pending and self._hierarchical_memory:
                self._hierarchical_memory.short_term.add(
                    content=f"Pending notifications: {pending}",
                    context="channels",
                    importance=0.8,
                )
        except Exception:
            pass  # Channel system not available

        # Record this interaction in short-term memory
        if self._hierarchical_memory:
            self._hierarchical_memory.short_term.add(
                content=f"User query: {query[:200]}",  # Truncate for short-term
                context="session",
                importance=0.5,
            )

        # Track onboarding state in short-term memory
        if self._hierarchical_memory and self._persona_manager:
            core_count = len(self._hierarchical_memory.core.entries)
            interaction_count = self._persona_manager.interaction_count
            if core_count < 5 and interaction_count <= 10:
                self._hierarchical_memory.short_term.add(
                    content=f"Onboarding in progress. Core identity entries: {core_count}/5.",
                    context="onboarding",
                    importance=0.6,
                )

        # Record persona interaction
        if self._persona_manager:
            self._persona_manager.record_interaction()

        # Check for capability matches
        if self._capability_registry:
            matching_caps = self._capability_registry.find_matching(query)
            if matching_caps:
                self._capability_registry.record_usage(matching_caps[0].name)

        # Rebuild system prompt with current context
        self.system_prompt = self._build_system_prompt()

    def run(self, query: str, **kwargs):
        """Run the agent with memory-enhanced context.
        
        Overrides parent to add pre-run memory setup.
        """
        # Set up memory context before running
        self._pre_run(query, **kwargs)
        
        # Run parent implementation synchronously
        return super().run(query, **kwargs)

    def _on_run_complete(self, response: str) -> None:
        """Hook called when a run completes successfully.
        
        Adds completion to short-term memory.
        """
        super()._on_run_complete(response)
        
        # After response, add to short-term memory
        if self._hierarchical_memory:
            self._hierarchical_memory.short_term.add(
                content="Completed processing query",
                context="session",
                importance=0.3,
            )

    # ------------------------------------------------------------------
    # Pre-compaction memory flush
    # ------------------------------------------------------------------

    def _flush_memory_before_compaction(
        self,
        messages: list[dict],
        emitter: Optional[AgentEventEmitter] = None,
    ) -> None:
        """Persist important facts before compaction destroys message detail.

        Called by :class:`LLMSummaryStrategy` at the soft threshold (before
        the hard compaction threshold).  Uses the LLM to extract key facts
        from the conversation and writes them to:

        1. The daily markdown log (``memory/daily/YYYY-MM-DD.md``)
        2. Long-term memory (``HierarchicalMemory.long_term``)

        Inspired by OpenClaw's pre-compaction memory flush mechanism.
        """
        if not self._hierarchical_memory:
            return

        if emitter:
            emitter.emit_thinking("Saving important context before compaction...")

        # Build a lightweight summary of messages for the extraction prompt.
        # Skip the first message (original query) and recent messages (they
        # survive compaction) — focus on the "middle" that will be lost.
        KEEP_RECENT = 6
        if len(messages) <= KEEP_RECENT + 2:
            return  # Too few messages to worry about

        middle_msgs = messages[1:-KEEP_RECENT]
        if not middle_msgs:
            return

        conversation_text = self._format_messages_for_flush(middle_msgs)

        # Ask the LLM to extract durable facts
        prompt = (
            "You are a memory extraction specialist.  The conversation below "
            "is about to be compressed and most detail will be lost.\n\n"
            "Extract ONLY information worth remembering long-term:\n"
            "- User preferences, decisions, or corrections\n"
            "- Key facts about the project or codebase\n"
            "- Important file paths and what they contain\n"
            "- Decisions made and their rationale\n"
            "- Anything the user explicitly asked to remember\n\n"
            "Return a concise bulleted list (Markdown).  "
            "If nothing is worth saving, reply with exactly: NOTHING_TO_SAVE\n\n"
            "---\n\n"
            f"{conversation_text}"
        )

        try:
            from ..providers import get_provider
            from ..providers.factory import _get_default_model_name

            model_name = _get_default_model_name()
            provider = get_provider(model_name)

            response = provider.chat(
                messages=[{"role": "user", "content": prompt}],
                system="Extract durable memories. Be concise — bullet points only.",
            )

            extracted = (response.content or "").strip()

            if not extracted or "NOTHING_TO_SAVE" in extracted:
                logger.debug("Memory flush: nothing worth saving")
                return

            # 1. Write to daily markdown log
            log_path = self._hierarchical_memory.append_daily_log(
                extracted,
                heading="Pre-compaction memory flush",
            )
            logger.info("Memory flush: wrote to %s", log_path)

            # 2. Store key facts in long-term memory
            for line in extracted.splitlines():
                line = line.strip().lstrip("-•*").strip()
                if line and len(line) > 10:
                    self._hierarchical_memory.store(
                        content=line,
                        layer="long_term",
                        importance=0.7,
                        context="compaction_flush",
                        tags=["auto_flush"],
                    )

            if emitter:
                emitter.emit_thinking("Memory flush complete — important context saved.")

        except Exception as exc:
            logger.warning("Memory flush failed (non-fatal): %s", exc)

    @staticmethod
    def _format_messages_for_flush(messages: list[dict], max_chars: int = 12000) -> str:
        """Format messages into a compact text block for the flush LLM call."""
        parts: list[str] = []
        total = 0
        for msg in messages:
            role = msg.get("role", "?")
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    p.get("text", "") for p in content if isinstance(p, dict)
                )
            # Truncate individual messages
            if len(content) > 2000:
                content = content[:2000] + "…"
            part = f"[{role.upper()}] {content}"
            if total + len(part) > max_chars:
                parts.append("[...truncated...]")
                break
            parts.append(part)
            total += len(part)
        return "\n\n".join(parts)

    # Memory Management Interface

    def remember(
        self,
        content: str,
        layer: str = "long_term",
        importance: float = 0.5,
        context: str = "general",
        tags: Optional[list] = None,
    ) -> dict:
        """Store something in memory.

        Args:
            content: Information to remember
            layer: Which layer ("core", "long_term", "short_term")
            importance: Importance score (0.0-1.0)
            context: Category
            tags: Optional tags

        Returns:
            Result dict
        """
        if self._memory_tools:
            return self._memory_tools.remember(
                content=content,
                layer=layer,
                importance=importance,
                context=context,
                tags=tags,
            )
        return {"success": False, "error": "Memory not initialized"}

    def recall(
        self,
        query: str,
        layers: Optional[list] = None,
        context: Optional[str] = None,
        top_k: int = 5,
    ) -> dict:
        """Search memory.

        Args:
            query: Search query
            layers: Which layers to search
            context: Filter by context
            top_k: Max results

        Returns:
            Matching memories
        """
        if self._memory_tools:
            return self._memory_tools.recall(
                query=query,
                layers=layers,
                context=context,
                top_k=top_k,
            )
        return {"success": False, "error": "Memory not initialized"}

    def show_memory_stats(self) -> dict:
        """Get memory statistics."""
        if self._memory_tools:
            return self._memory_tools.get_memory_stats()
        return {"success": False, "error": "Memory not initialized"}

    def export_memory(self) -> dict:
        """Export all memory layers."""
        if self._hierarchical_memory:
            return {
                "success": True,
                "memory": self._hierarchical_memory.export_all(),
            }
        return {"success": False, "error": "Memory not initialized"}

    # Persona Interface (backward compatible)

    def get_persona_summary(self) -> str:
        """Get a summary of the learned persona."""
        if self._persona_manager:
            return self._persona_manager.get_preference_summary()
        return "No persona data available."

    def export_persona(self, file_path: Optional[str] = None) -> dict:
        """Export the current persona."""
        if not self._persona_manager:
            return {}

        data = self._persona_manager.export_persona()

        if file_path:
            import json
            with open(file_path, "w") as f:
                json.dump(data, f, indent=2)

        return data

    def import_persona(self, data: dict) -> None:
        """Import persona data."""
        if self._persona_manager:
            self._persona_manager.import_persona(data)
            self.system_prompt = self._build_system_prompt()

    def reset_persona(self) -> None:
        """Reset the persona to initial state."""
        if self._persona_manager:
            self._persona_manager.reset()
        if self._capability_registry:
            self._capability_registry.reset()
        if self._hierarchical_memory:
            self._hierarchical_memory.reset()

        self.system_prompt = self._build_system_prompt()

    # Capabilities Interface

    def list_capabilities(self) -> list:
        """List all learned capabilities."""
        caps = []
        if self._capability_registry:
            caps.extend([
                {
                    "name": c.name,
                    "description": c.description,
                    "usage_count": c.usage_count,
                    "enabled": c.enabled,
                    "type": "capability",
                }
                for c in self._capability_registry.list_all()
            ])
        return caps

    def suggest_capability(self, message: str) -> Optional[dict]:
        """Suggest creating a new capability based on message."""
        if self._capability_registry:
            history = []
            return self._capability_registry.suggest_new(message, history)
        return None
