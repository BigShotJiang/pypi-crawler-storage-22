"""Tool for generating download URLs for files on the remote machine."""

import os
from pathlib import Path
from urllib.parse import quote

from .base import BaseTool, ToolResult, ToolCategory


class ServeFileTool(BaseTool):
    """Generate a public download URL for a file.

    When the agent creates or finds a file on the machine, this tool
    turns the local path into an HTTP URL the user can open in their
    browser or receive via Telegram/chat.
    """

    name = "serve_file"
    description = """Generate a download URL for a file so the user can access it.

Use this whenever you create or reference a file and the user needs to
download it — especially when running on a remote server where the user
cannot access the filesystem directly.

Examples:
  serve_file(file_path="/tmp/report.pdf")
  serve_file(file_path="/tmp/chart.png", filename="sales-chart.png")"""
    category = ToolCategory.FILE

    def execute(
        self,
        file_path: str = "",
        filename: str = "",
    ) -> ToolResult:
        """Generate a download URL for a file.

        Args:
            file_path: Absolute path to the file on the machine.
            filename: Optional display name for the download (defaults to
                      the original filename).

        Returns:
            ToolResult with the download URL.
        """
        if not file_path:
            return ToolResult.error_result(
                "'file_path' is required.",
                suggestions=["Provide the absolute path to the file."],
            )

        path = Path(file_path).resolve()

        if not path.exists():
            return ToolResult.error_result(
                f"File not found: {file_path}",
                suggestions=["Check the path and try again."],
            )

        if not path.is_file():
            return ToolResult.error_result(
                f"Not a file: {file_path}",
                suggestions=["Provide a path to a file, not a directory."],
            )

        # Build base URL: prefer EMDASH_BASE_URL, fall back to server config
        base_url = os.getenv("EMDASH_BASE_URL", "")
        if not base_url:
            try:
                from ...config import get_config
                cfg = get_config()
                base_url = f"http://{cfg.host}:{cfg.port}"
            except Exception:
                base_url = "http://localhost:8765"

        base_url = base_url.rstrip("/")

        # Construct the URL path (strip leading /)
        url_path = quote(str(path).lstrip("/"), safe="/")
        download_url = f"{base_url}/api/files/{url_path}"

        display_name = filename or path.name

        return ToolResult.success_result(
            data={
                "url": download_url,
                "filename": display_name,
                "size_bytes": path.stat().st_size,
                "path": str(path),
            },
            suggestions=[
                f"Send this URL to the user: {download_url}",
            ],
        )

    def get_schema(self) -> dict:
        return self._make_schema(
            properties={
                "file_path": {
                    "type": "string",
                    "description": "Absolute path to the file on the machine.",
                },
                "filename": {
                    "type": "string",
                    "description": (
                        "Optional display name for the download. "
                        "Defaults to the original filename."
                    ),
                },
            },
            required=["file_path"],
        )
