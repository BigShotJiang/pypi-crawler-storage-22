"""Browser handoff API endpoints.

Provides an HTTP endpoint for the noVNC "Done" button to signal
that the user has finished their browser interaction.

Communication between this API (emdash-core) and the browser-mcp
subprocess uses shared signal files in ``~/.emdash/``:

- ``browser-handoff-active``   — written by browser-mcp when handoff starts
- ``browser-handoff-complete`` — written by this API when user clicks "Done"
"""

import logging
import os
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(prefix="/browser", tags=["browser"])


def _emdash_dir() -> Path:
    """Resolve the shared emdash directory (``~/.emdash``)."""
    return Path(os.getenv("EMDASH_HOME", Path.home() / ".emdash"))


class HandoffCompleteResponse(BaseModel):
    """Response from handoff completion."""

    status: str
    message: str


@router.post("/handoff/complete", response_model=HandoffCompleteResponse)
async def complete_handoff(
    token: str = Query(default="", description="Handoff session token for authentication"),
):
    """Signal that the user has finished their browser interaction.

    Called by the "Done" button in the noVNC overlay. This triggers
    the browser-mcp server to stop VNC streaming and switch the
    browser back to headless mode.

    The token parameter must match the handoff session token to
    prevent unauthorized completion signals.
    """
    try:
        signal_file = _emdash_dir() / "browser-handoff-complete"
        signal_file.parent.mkdir(parents=True, exist_ok=True)

        # Write the token so browser-mcp can verify it
        signal_file.write_text(token or "done")

        log.info("Browser handoff completion signaled (token=%s)", token[:8] if token else "none")

        return HandoffCompleteResponse(
            status="signaled",
            message="Handoff completion signal sent. The browser will return to agent control.",
        )
    except Exception as e:
        log.exception("Failed to signal handoff completion")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/handoff/page")
async def handoff_page():
    """Serve the custom noVNC wrapper page with a 'Done' button.

    Returns an HTML page that embeds the noVNC viewer inside an iframe
    with a header bar, countdown timer, and a "Done" button.
    The user opens this URL instead of the raw noVNC URL.
    """
    from fastapi.responses import HTMLResponse

    status_file = _emdash_dir() / "browser-handoff-active"
    if not status_file.exists():
        raise HTTPException(status_code=404, detail="No active browser handoff")

    import json

    data = json.loads(status_file.read_text())
    vnc_url = data.get("url", "")
    reason = data.get("reason", "Browser interaction needed")
    token = data.get("token", "")

    if not vnc_url:
        raise HTTPException(status_code=404, detail="No VNC URL available")

    # Generate the wrapper page with Done button
    try:
        from emdash_browser_mcp.novnc_page import generate_handoff_page
    except ImportError:
        # browser-mcp not installed alongside core — simple redirect
        return HTMLResponse(
            f'<html><body><script>window.location.href="{vnc_url}";</script></body></html>'
        )

    api_base = os.getenv("BROWSER_MCP_BASE_URL", "")

    html = generate_handoff_page(
        vnc_url=vnc_url,
        reason=reason,
        api_base=api_base,
        token=token,
        timeout=300,
    )
    return HTMLResponse(html)


@router.get("/handoff/status")
async def handoff_status():
    """Check whether a browser handoff is currently active.

    Returns the current handoff state for UI rendering decisions.
    """
    try:
        status_file = _emdash_dir() / "browser-handoff-active"

        if status_file.exists():
            import json

            data = json.loads(status_file.read_text())
            return {"active": True, **data}

        return {"active": False, "state": "agent_controlled"}
    except Exception:
        return {"active": False, "state": "unknown"}
