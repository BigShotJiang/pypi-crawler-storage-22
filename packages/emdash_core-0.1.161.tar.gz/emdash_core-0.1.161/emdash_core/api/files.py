"""File serving endpoint for generated artifacts."""

import mimetypes
import os
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

router = APIRouter(prefix="/files", tags=["files"])


def _get_allowed_dirs() -> list[str]:
    """Build the list of directories from which files may be served.

    Always includes /tmp and /app (Docker).  Also adds the user's home
    directory and the current working directory so agent-generated files
    are reachable.
    """
    dirs = ["/tmp", "/app"]

    home = Path.home()
    if home != Path("/"):
        dirs.append(str(home))

    cwd = Path.cwd()
    if str(cwd) not in dirs:
        dirs.append(str(cwd))

    emdash_home = os.getenv("EMDASH_HOME")
    if emdash_home and emdash_home not in dirs:
        dirs.append(emdash_home)

    return dirs


@router.get("/{file_path:path}")
async def serve_file(file_path: str):
    """Serve a generated file (image, PDF, doc, etc.)."""
    # Reconstruct full path
    full_path = Path("/") / file_path

    # Security: ensure path is in allowed directories
    resolved = full_path.resolve()
    allowed = _get_allowed_dirs()
    if not any(str(resolved).startswith(d) for d in allowed):
        raise HTTPException(status_code=403, detail="Access denied")

    if not resolved.exists():
        raise HTTPException(status_code=404, detail="File not found")

    if not resolved.is_file():
        raise HTTPException(status_code=400, detail="Not a file")

    # Get content type
    content_type, _ = mimetypes.guess_type(str(resolved))

    return FileResponse(
        path=resolved,
        media_type=content_type,
        filename=resolved.name
    )
