from emsutil.inexport.ffdata import FarFieldExporter

