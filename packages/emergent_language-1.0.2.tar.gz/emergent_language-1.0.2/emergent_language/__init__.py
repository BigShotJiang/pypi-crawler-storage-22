"""
Emergent Language SDK - High-performance semantic compression for AI agents.

Installation:
    pip install emergent-language           # SDK only (~8,000 msg/s)
    pip install emergent-language[collector] # SDK + Collector (~9,700 msg/s)

Usage (SDK):
    from emergent_language import EmergentClient

    async with EmergentClient() as client:
        await client.send({"task": "analyze", "data": "market"})

Usage (Collector - for larger deployments):
    # Terminal 1: Start collector sidecar
    emergent-collector --port 8080

    # Terminal 2: Your agents use the SDK (auto-detects collector)
    async with EmergentClient() as client:
        await client.send({"task": "analyze"})  # Routes through collector
"""

from .client import (
    EmergentClient,
    Config,
    Stats,
    Mode,
    init,
    send,
    flush,
    close,
)

__version__ = "1.0.2"
__all__ = [
    "EmergentClient",
    "Config",
    "Stats",
    "Mode",
    "init",
    "send",
    "flush",
    "close",
]


def run_collector():
    """Start the collector sidecar. Requires: pip install emergent-language[collector]"""
    try:
        from .collector import main
        main()
    except ImportError:
        print("Collector requires additional dependencies.")
        print("Install with: pip install emergent-language[collector]")
        raise SystemExit(1)
