#!/usr/bin/env python3
"""
Emergent Language SDK Demo

Run with: emergent-demo
"""

import asyncio
import time
import random
import argparse
import sys

# Sample messages that simulate real AI agent communication
SAMPLE_MESSAGES = [
    {"task": "analyze", "data": "market_trends", "priority": "high"},
    {"task": "execute", "action": "buy", "symbol": "BTC", "amount": 0.5},
    {"agent_id": "agent_001", "status": "active", "load": 0.75},
    {"task": "coordinate", "participants": ["agent_1", "agent_2", "agent_3"]},
    {"observation": "price_spike", "confidence": 0.92, "timestamp": 1234567890},
    {"task": "report", "metrics": {"latency": 12, "throughput": 1500}},
    {"request": "consensus", "proposal": "increase_allocation", "votes": 3},
    {"task": "monitor", "targets": ["server_1", "server_2"], "interval": 60},
]


def print_banner():
    print("""
╔═══════════════════════════════════════════════════════════════════╗
║           Emergent Language SDK Demo                              ║
║           High-performance semantic compression                    ║
╚═══════════════════════════════════════════════════════════════════╝
""")


async def run_demo(num_messages: int = 100, verbose: bool = False, url: str = None, token: str = None):
    """Run the SDK demo."""
    from . import EmergentClient, Config

    config = Config()
    if url:
        config.translator_url = url
    if token:
        config.auth_token = token

    print(f"  Sending {num_messages} messages to Translator API...")
    print(f"  Target: {config.translator_url}")
    print()

    async with EmergentClient(config) as client:
        print(f"  Mode: {client.mode.upper()}")
        print()

        # Send messages
        start = time.time()

        for i in range(num_messages):
            msg = random.choice(SAMPLE_MESSAGES).copy()
            msg["seq"] = i  # Add sequence number
            await client.send(msg)

            if verbose and (i + 1) % 25 == 0:
                print(f"    Queued: {i + 1}/{num_messages}")

        # Wait for all to be sent
        print("  Waiting for batches to complete...")
        while client.queue_size > 0:
            await asyncio.sleep(0.1)

        # Give final batches time to complete
        await asyncio.sleep(0.5)

        duration = time.time() - start
        stats = client.stats

        # Results
        print()
        print("╔═══════════════════════════════════════════════════════════════════╗")
        print("║                         RESULTS                                   ║")
        print("╠═══════════════════════════════════════════════════════════════════╣")
        print(f"║  Messages sent:     {stats.messages_sent:>6}                                   ║")
        print(f"║  Batches:           {stats.batches_sent:>6}                                   ║")
        print(f"║  Duration:          {duration:>6.2f}s                                  ║")
        print(f"║  Throughput:        {num_messages/duration:>6.0f} msg/s                            ║")
        print(f"║  Bytes saved:       {stats.bytes_saved:>6,}                                ║")

        if stats.bytes_saved > 0 and stats.messages_sent > 0:
            # Estimate compression ratio (rough)
            avg_msg_size = 80  # approximate JSON size
            original_estimate = stats.messages_sent * avg_msg_size
            compression = (stats.bytes_saved / (original_estimate + stats.bytes_saved)) * 100
            print(f"║  Compression:       ~{compression:>5.1f}%                                 ║")

        print("╚═══════════════════════════════════════════════════════════════════╝")
        print()

        if stats.errors > 0:
            print(f"  ⚠ Errors: {stats.errors}")
        else:
            print("  ✓ All messages sent successfully!")

        return stats


async def run_interactive(url: str = None, token: str = None):
    """Interactive demo mode."""
    from . import EmergentClient, Config

    config = Config()
    if url:
        config.translator_url = url
    if token:
        config.auth_token = token

    print("  Interactive Mode - Type JSON messages (or 'quit' to exit)")
    print("  Example: {\"task\": \"analyze\", \"data\": \"test\"}")
    print()

    async with EmergentClient(config) as client:
        print(f"  Mode: {client.mode.upper()}")
        print()

        import json

        while True:
            try:
                line = input("  > ").strip()

                if line.lower() in ('quit', 'exit', 'q'):
                    break

                if not line:
                    continue

                try:
                    msg = json.loads(line)
                    await client.send(msg)
                    print(f"    ✓ Queued (queue size: {client.queue_size})")
                except json.JSONDecodeError:
                    print("    ✗ Invalid JSON")

            except EOFError:
                break
            except KeyboardInterrupt:
                break

        # Flush remaining
        print()
        print("  Flushing remaining messages...")
        while client.queue_size > 0:
            await asyncio.sleep(0.1)
        await asyncio.sleep(0.3)

        print(f"  Done! Sent {client.stats.messages_sent} messages, saved {client.stats.bytes_saved:,} bytes")


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Emergent Language SDK Demo",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  emergent-demo                    # Quick demo with 100 messages
  emergent-demo -n 1000            # Demo with 1000 messages
  emergent-demo -n 5000 -v         # Verbose demo with 5000 messages
  emergent-demo --interactive      # Interactive mode (type your own messages)
  emergent-demo --url http://localhost:8001  # Use custom API
        """
    )
    parser.add_argument("-n", "--num-messages", type=int, default=100,
                        help="Number of messages to send (default: 100)")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Show progress during send")
    parser.add_argument("-i", "--interactive", action="store_true",
                        help="Interactive mode - type your own messages")
    parser.add_argument("--url", type=str, default=None,
                        help="Translator API URL (default: https://emergent-language.fly.dev)")
    parser.add_argument("--token", type=str, default=None,
                        help="Auth token (default: eudaimonia-translator-demo)")

    args = parser.parse_args()

    print_banner()

    try:
        if args.interactive:
            asyncio.run(run_interactive(url=args.url, token=args.token))
        else:
            asyncio.run(run_demo(args.num_messages, args.verbose, url=args.url, token=args.token))
    except KeyboardInterrupt:
        print("\n  Interrupted.")
        sys.exit(0)


if __name__ == "__main__":
    main()
