"""
Emergent Language Translator

A high-performance API for translating between traditional AI communication formats
and emergent language symbols with 60x compression efficiency.

Example:
    >>> from emergent_translator import BatchEncoder
    >>> encoder = BatchEncoder()
    >>> result = encoder.encode_batch([{"role": "user", "content": "hello"}])
"""

# --- Always-available imports (no heavy deps) ---
from .batch_encoder import (
    BatchEncoder,
    BatchResult,
    COMMON_KEYS,
    COMMON_VALUES,
)

from .adaptive_codebook import (
    AdaptiveCodebook,
    CodebookVersion,
    FrequencyTracker,
)

from .format_handlers import (
    detect_format,
    get_handler,
    is_binary_format,
)

from .emergent_symbols import EmergentSymbolEncoder

__version__ = "1.3.0"
__author__ = "Emergent Language Team"
__email__ = "hello@emergentlanguage.ai"
__description__ = "60x compression efficiency for AI communication"
__url__ = "https://github.com/maco144/emergent-language"

__all__ = [
    # Batch encoder
    "BatchEncoder",
    "BatchResult",
    "COMMON_KEYS",
    "COMMON_VALUES",

    # Adaptive codebook
    "AdaptiveCodebook",
    "CodebookVersion",
    "FrequencyTracker",

    # Format handlers
    "detect_format",
    "get_handler",
    "is_binary_format",

    # Symbols
    "EmergentSymbolEncoder",

    # Codec
    "EmergentCodec",

    # GPU (lazy-loaded)
    "GPUBatchEncoder",

    # SDK / server components (lazy-loaded, need extra deps)
    "TranslatorSDK",
    "EmergentTranslatorClient",
    "SyncEmergentTranslatorClient",
    "EmergentLanguageTranslator",
    "ChunkCoordinator",
    "ChunkCollector",

    # CaaS (lazy-loaded)
    "CompressionEngine",
    "ContentDetector",
    "CompressedResult",
    "CompressionLevel",

    # CaaS Adaptive (lazy-loaded)
    "AdaptiveLearner",
    "CompressionOutcome",
    "StrategyPerformance",
    "AdaptivePolicy",

    # Lazy collector (lazy-loaded)
    "LocalLazyCollector",
    "LazyCollectorStats",

    # Local pipeline (lazy-loaded)
    "LocalPipeline",
    "LocalPipelineSync",

    # Metadata
    "__version__",
    "__author__",
    "__email__",
    "__description__",
    "__url__",
]

# --- Lazy imports for modules with heavy/optional dependencies ---
_LAZY_IMPORTS = {
    # Codec
    "EmergentCodec": (".nats_codec", "EmergentCodec"),
    # GPU encoder (cupy detection prints at import time)
    "GPUBatchEncoder": (".gpu_batch_encoder", "GPUBatchEncoder"),
    # SDK / client
    "TranslatorSDK": (".client_sdk", "TranslatorSDK"),
    "EmergentTranslatorClient": (".client_sdk", "EmergentTranslatorClient"),
    "SyncEmergentTranslatorClient": (".client_sdk", "SyncEmergentTranslatorClient"),
    # Core (needs eudaimonia)
    "EmergentLanguageTranslator": (".core", "EmergentLanguageTranslator"),
    "TranslationFormat": (".core", "TranslationFormat"),
    "TranslationDirection": (".core", "TranslationDirection"),
    "TranslationResult": (".core", "TranslationResult"),
    "TranslationStats": (".core", "TranslationStats"),
    # Distributed processing
    "ChunkCoordinator": (".chunk_coordinator", "ChunkCoordinator"),
    "DistributedJob": (".chunk_coordinator", "DistributedJob"),
    "Chunk": (".chunk_coordinator", "Chunk"),
    "ChunkStatus": (".chunk_coordinator", "ChunkStatus"),
    "JobStatus": (".chunk_coordinator", "JobStatus"),
    "distributed_process": (".chunk_coordinator", "distributed_process"),
    # Chunk collector
    "ChunkCollector": (".chunk_collector", "ChunkCollector"),
    "create_collector_app": (".chunk_collector", "create_collector_app"),
    "CollectorStats": (".chunk_collector", "CollectorStats"),
    # Claude compression
    "TextCodebook": (".claude_compression", "TextCodebook"),
    "ClaudeCompressor": (".claude_compression", "ClaudeCompressor"),
    "text_compress": (".claude_compression", "compress"),
    "text_decompress": (".claude_compression", "decompress"),
    "estimate_tokens": (".claude_compression", "estimate_tokens"),
    # Code skeleton
    "skeletonize": (".code_skeleton", "skeletonize"),
    "skeletonize_file": (".code_skeleton", "skeletonize_file"),
    "skeletonize_dir": (".code_skeleton", "skeletonize_dir"),
    "SkeletonResult": (".code_skeleton", "SkeletonResult"),
    "CodeSkeleton": (".code_skeleton", "CodeSkeleton"),
    # Tree-sitter skeletonizer (TS/JS/Rust)
    "skeletonize_ts": (".code_skeleton_ts", "skeletonize_ts"),
    "skeletonize_ts_file": (".code_skeleton_ts", "skeletonize_ts_file"),
    "detect_language": (".code_skeleton_ts", "detect_language"),
    # Multi-language facade
    "skeletonize_auto": (".code_skeleton_multi", "skeletonize_auto"),
    "skeletonize_file_auto": (".code_skeleton_multi", "skeletonize_file_auto"),
    "skeletonize_dir_multi": (".code_skeleton_multi", "skeletonize_dir_multi"),
    "MultiLanguageSkeleton": (".code_skeleton_multi", "MultiLanguageSkeleton"),
    # Compression-as-a-Service
    "CompressionEngine": (".caas_engine", "CompressionEngine"),
    "ContentDetector": (".caas_engine", "ContentDetector"),
    "CompressedResult": (".caas_strategies", "CompressedResult"),
    "CompressionLevel": (".caas_strategies", "CompressionLevel"),
    # CaaS Adaptive Learning
    "AdaptiveLearner": (".caas_adaptive", "AdaptiveLearner"),
    "CompressionOutcome": (".caas_adaptive", "CompressionOutcome"),
    "StrategyPerformance": (".caas_adaptive", "StrategyPerformance"),
    "AdaptivePolicy": (".caas_adaptive", "AdaptivePolicy"),
    # Lazy collector
    "LocalLazyCollector": (".lazy_collector", "LocalLazyCollector"),
    "LazyCollectorStats": (".lazy_collector", "LazyCollectorStats"),
    # Local pipeline
    "LocalPipeline": (".local_pipeline", "LocalPipeline"),
    "LocalPipelineSync": (".local_pipeline", "LocalPipelineSync"),
}


def __getattr__(name):
    if name in _LAZY_IMPORTS:
        module_path, attr = _LAZY_IMPORTS[name]
        import importlib
        mod = importlib.import_module(module_path, __name__)
        return getattr(mod, attr)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
