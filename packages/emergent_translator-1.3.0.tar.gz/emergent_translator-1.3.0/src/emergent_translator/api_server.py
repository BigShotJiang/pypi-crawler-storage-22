# eudaimonia/translator/api_server.py

# Add AIOS to path to enable real emergent language imports
import sys
from pathlib import Path
_aios_path = Path.home() / "AIOS"
if _aios_path.exists() and str(_aios_path) not in sys.path:
    sys.path.insert(0, str(_aios_path))

"""
Emergent Language Translator API Server

FastAPI-based REST API service for the emergent language translator.
Provides endpoints for external AI systems to compress their data
into Eudaimonia's native θ symbol format and decompress back.

Key Features:
- RESTful translation endpoints
- Rate limiting and authentication
- Compression statistics and monitoring
- WebSocket support for real-time translation
- Developer documentation and examples
- Health checks and service status

This is the primary service interface for external AI integration.
"""

import asyncio
import logging
import os
import signal
import time
import threading
import uuid
from collections import OrderedDict, deque
from contextvars import ContextVar
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any, Union, Tuple
import json
import base64
import hashlib
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from enum import Enum
from functools import partial

# Context variable for request ID (accessible throughout request lifecycle)
request_id_var: ContextVar[str] = ContextVar("request_id", default="")

from fastapi import FastAPI, HTTPException, Depends, status, WebSocket, WebSocketDisconnect, UploadFile, File, Form, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import JSONResponse, HTMLResponse, FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.gzip import GZipMiddleware
from pathlib import Path
from pydantic import BaseModel, Field, field_validator
import uvicorn
import httpx

# Rate limiting
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from .core import (
    EmergentLanguageTranslator,
    TranslationFormat,
    TranslationDirection,
    TranslationResult,
    TranslationStats
)
from .metrics import (
    get_metrics,
    setup_structured_logging,
    emit_metrics_update,
    MetricsCollector
)

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# Response Cache - LRU cache for translation results
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class CacheEntry:
    """Cache entry with TTL support."""
    value: Any
    created_at: float
    hits: int = 0


class TranslationCache:
    """
    Thread-safe LRU cache for translation responses.

    Features:
    - Configurable max size and TTL
    - LRU eviction when full
    - Cache statistics for monitoring
    - Thread-safe operations
    """

    def __init__(self, max_size: int = 10000, ttl_seconds: float = 300.0):
        """
        Initialize cache.

        Args:
            max_size: Maximum number of entries
            ttl_seconds: Time-to-live for entries (default: 5 minutes)
        """
        self.max_size = max_size
        self.ttl_seconds = ttl_seconds
        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._lock = threading.Lock()

        # Statistics
        self.hits = 0
        self.misses = 0
        self.evictions = 0

    def _make_key(self, data: Any, source_format: str, target_format: str) -> str:
        """Create cache key from request data."""
        # Serialize data deterministically
        if isinstance(data, dict):
            serialized = json.dumps(data, sort_keys=True)
        else:
            serialized = str(data)

        key_str = f"{source_format}:{target_format}:{serialized}"
        return hashlib.sha256(key_str.encode()).hexdigest()[:32]

    def get(self, data: Any, source_format: str, target_format: str) -> Optional[Any]:
        """Get cached response if available and not expired."""
        key = self._make_key(data, source_format, target_format)

        with self._lock:
            if key not in self._cache:
                self.misses += 1
                return None

            entry = self._cache[key]

            # Check TTL
            if time.time() - entry.created_at > self.ttl_seconds:
                del self._cache[key]
                self.misses += 1
                return None

            # Move to end (most recently used)
            self._cache.move_to_end(key)
            entry.hits += 1
            self.hits += 1

            return entry.value

    def set(self, data: Any, source_format: str, target_format: str, value: Any):
        """Store response in cache."""
        key = self._make_key(data, source_format, target_format)

        with self._lock:
            # Evict if at capacity
            while len(self._cache) >= self.max_size:
                self._cache.popitem(last=False)  # Remove oldest
                self.evictions += 1

            self._cache[key] = CacheEntry(
                value=value,
                created_at=time.time()
            )

    def clear(self):
        """Clear all cache entries."""
        with self._lock:
            self._cache.clear()

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self._lock:
            total_requests = self.hits + self.misses
            hit_rate = (self.hits / total_requests * 100) if total_requests > 0 else 0

            return {
                "size": len(self._cache),
                "max_size": self.max_size,
                "hits": self.hits,
                "misses": self.misses,
                "hit_rate_percent": round(hit_rate, 2),
                "evictions": self.evictions,
                "ttl_seconds": self.ttl_seconds
            }


# Global cache instance
translation_cache = TranslationCache(
    max_size=int(os.getenv("CACHE_MAX_SIZE", "10000")),
    ttl_seconds=float(os.getenv("CACHE_TTL_SECONDS", "300"))
)


# Security and rate limiting
security = HTTPBearer(auto_error=False)


def get_rate_limit_key(request: Request) -> str:
    """
    Custom rate limit key function.
    Authenticated requests return empty string to skip rate limiting.
    Unauthenticated requests are rate limited by IP.
    """
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
        # Check if it's a valid API token - if so, exempt from rate limiting
        api_token = os.getenv("API_AUTH_TOKEN", "eudaimonia-translator-demo")
        if token == api_token:
            # Return empty string to skip rate limiting for authenticated users
            return ""
    # Unauthenticated - rate limit by IP
    return get_remote_address(request)


limiter = Limiter(key_func=get_rate_limit_key)

# Global state
translator_instances: Dict[str, EmergentLanguageTranslator] = {}
_translator_lock = threading.Lock()
_translate_executor = ThreadPoolExecutor(max_workers=8, thread_name_prefix="translate")
rate_limit_cache: Dict[str, List[datetime]] = {}
websocket_connections: List[WebSocket] = []


async def run_translate(func, *args, **kwargs):
    """Run a CPU-bound translator method off the event loop."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        _translate_executor,
        partial(func, *args, **kwargs) if kwargs else partial(func, *args)
    )


# Configuration
DEFAULT_RATE_LIMIT = 100  # requests per minute
WEBSOCKET_PING_INTERVAL = 30  # seconds
MAX_REQUEST_SIZE = 10 * 1024 * 1024  # 10MB max request body

# Auth token from environment (no hardcoded default)
API_AUTH_TOKEN = os.getenv("API_AUTH_TOKEN")
if not API_AUTH_TOKEN:
    logger.warning("No API_AUTH_TOKEN set - using demo token for development only")
    API_AUTH_TOKEN = "eudaimonia-translator-demo"

# CORS configuration - restrict to known origins
ALLOWED_ORIGINS = [
    "https://emergent-language.fly.dev",
    "https://www.emergent-language.fly.dev",
    "http://localhost:3000",
    "http://localhost:8000",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:8000",
]
# Allow all origins in development
if os.getenv("ENVIRONMENT") != "production":
    ALLOWED_ORIGINS = ["*"]


class LimitRequestSizeMiddleware(BaseHTTPMiddleware):
    """Middleware to limit request body size."""

    def __init__(self, app, max_size: int = MAX_REQUEST_SIZE):
        super().__init__(app)
        self.max_size = max_size

    async def dispatch(self, request: Request, call_next):
        if request.headers.get("content-length"):
            content_length = int(request.headers["content-length"])
            if content_length > self.max_size:
                return JSONResponse(
                    status_code=413,
                    content={"detail": f"Request too large. Max size: {self.max_size // (1024*1024)}MB"}
                )
        return await call_next(request)


class RequestIDMiddleware(BaseHTTPMiddleware):
    """
    Middleware for request correlation IDs.

    Adds a unique request ID to each request for distributed tracing.
    - Accepts X-Request-ID header if provided by client
    - Generates new UUID if not provided
    - Adds X-Request-ID to response headers
    - Makes request ID available via context variable for logging
    """

    async def dispatch(self, request: Request, call_next):
        # Get existing request ID or generate new one
        req_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())[:8]

        # Store in context for logging throughout request lifecycle
        request_id_var.set(req_id)

        # Process request
        response = await call_next(request)

        # Add request ID to response headers
        response.headers["X-Request-ID"] = req_id

        # Add Fly.io region/machine headers for multi-region observability
        fly_region = os.environ.get("FLY_REGION")
        if fly_region:
            response.headers["X-Served-By-Region"] = fly_region
        fly_machine = os.environ.get("FLY_MACHINE_ID")
        if fly_machine:
            response.headers["X-Machine-Id"] = fly_machine

        return response


def get_request_id() -> str:
    """Get current request ID from context."""
    return request_id_var.get()


class GracefulShutdownMiddleware(BaseHTTPMiddleware):
    """
    Middleware for graceful shutdown support.

    - Tracks active requests
    - Returns 503 when server is draining
    - Helps coordinate shutdown across instances
    """

    async def dispatch(self, request: Request, call_next):
        global _active_requests

        # Check if server is accepting requests
        if not is_accepting_requests():
            # Allow health checks during shutdown
            if request.url.path not in ["/health", "/health/live", "/health/deep", "/ready"]:
                return JSONResponse(
                    status_code=503,
                    content={"detail": "Server is shutting down", "retry_after": 5},
                    headers={"Retry-After": "5"}
                )

        # Track active request
        _active_requests += 1
        try:
            response = await call_next(request)
            return response
        finally:
            _active_requests -= 1


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    Structured request logging middleware.

    Logs every request with:
    - Request ID, method, path
    - Response status and timing
    - Client IP (anonymized in production)
    """

    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        request_id = get_request_id()

        # Process request
        response = await call_next(request)

        # Calculate timing
        duration_ms = (time.time() - start_time) * 1000

        # Log structured request info (skip health checks to reduce noise)
        if request.url.path not in ["/health", "/health/live", "/ready", "/metrics"]:
            log_data = {
                "request_id": request_id,
                "method": request.method,
                "path": request.url.path,
                "status": response.status_code,
                "duration_ms": round(duration_ms, 2),
                "client_ip": request.client.host if request.client else "unknown",
            }
            if duration_ms > 1000:  # Slow request warning
                logger.warning("slow_request", extra=log_data)
            elif response.status_code >= 400:
                logger.warning("error_response", extra=log_data)
            else:
                logger.debug("request", extra=log_data)

        return response


# ═══════════════════════════════════════════════════════════════════════════════
# Request Coalescing - Share results for identical in-flight requests
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class InflightRequest:
    """Tracks an in-flight request for coalescing."""
    future: asyncio.Future
    created_at: float
    waiters: int = 1


class RequestCoalescer:
    """
    Coalesces identical in-flight requests.

    When multiple identical requests arrive while one is being processed,
    they all wait for the same result instead of doing duplicate work.

    This is different from caching:
    - Cache: Reuses results from completed requests
    - Coalescing: Shares results from in-progress requests

    Example:
        100 identical requests arrive in 10ms
        Without coalescing: 100 translations performed
        With coalescing: 1 translation, 99 waiters get same result
    """

    def __init__(self, ttl_seconds: float = 30.0):
        self.ttl_seconds = ttl_seconds
        self._inflight: Dict[str, InflightRequest] = {}
        self._lock = asyncio.Lock()

        # Stats
        self.requests_coalesced = 0
        self.requests_primary = 0

    def _make_key(self, data: Any, source_format: str, target_format: str) -> str:
        """Create key for coalescing lookup."""
        if isinstance(data, dict):
            data_str = json.dumps(data, sort_keys=True)
        else:
            data_str = str(data)
        key_str = f"{source_format}:{target_format}:{data_str}"
        return hashlib.sha256(key_str.encode()).hexdigest()[:16]

    async def get_or_create(
        self,
        data: Any,
        source_format: str,
        target_format: str
    ) -> Tuple[bool, asyncio.Future]:
        """
        Get existing in-flight request or create new one.

        Returns:
            (is_primary, future): is_primary=True if caller should do the work
        """
        key = self._make_key(data, source_format, target_format)

        async with self._lock:
            # Clean up expired entries
            now = time.time()
            expired = [k for k, v in self._inflight.items()
                      if now - v.created_at > self.ttl_seconds]
            for k in expired:
                del self._inflight[k]

            # Check for existing in-flight request
            if key in self._inflight:
                inflight = self._inflight[key]
                inflight.waiters += 1
                self.requests_coalesced += 1
                return False, inflight.future

            # Create new in-flight request
            future = asyncio.get_event_loop().create_future()
            self._inflight[key] = InflightRequest(
                future=future,
                created_at=now
            )
            self.requests_primary += 1
            return True, future

    async def complete(
        self,
        data: Any,
        source_format: str,
        target_format: str,
        result: Any = None,
        error: Exception = None
    ):
        """Mark an in-flight request as complete."""
        key = self._make_key(data, source_format, target_format)

        async with self._lock:
            if key in self._inflight:
                inflight = self._inflight[key]
                if error:
                    inflight.future.set_exception(error)
                else:
                    inflight.future.set_result(result)
                del self._inflight[key]

    def get_stats(self) -> Dict[str, Any]:
        """Get coalescing statistics."""
        total = self.requests_primary + self.requests_coalesced
        coalesce_rate = (self.requests_coalesced / total * 100) if total > 0 else 0
        return {
            "primary_requests": self.requests_primary,
            "coalesced_requests": self.requests_coalesced,
            "coalesce_rate_percent": round(coalesce_rate, 2),
            "inflight_count": len(self._inflight)
        }


# Global coalescer instance
request_coalescer = RequestCoalescer()


# ═══════════════════════════════════════════════════════════════════════════════
# Usage Tracking - Per-token usage metrics for billing and quotas
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class TokenUsage:
    """Usage stats for a single API token."""
    requests: int = 0
    bytes_in: int = 0
    bytes_out: int = 0
    errors: int = 0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)


class UsageTracker:
    """
    Tracks API usage per token for billing and quota enforcement.

    Features:
    - Per-token request counts and byte tracking
    - Configurable rate limits per token
    - Usage export for billing systems
    - Automatic cleanup of stale tokens
    """

    def __init__(self, default_quota: int = 10000, cleanup_interval: float = 3600.0):
        self.default_quota = default_quota  # requests per hour
        self.cleanup_interval = cleanup_interval
        self._usage: Dict[str, TokenUsage] = {}
        self._quotas: Dict[str, int] = {}  # token -> requests per hour
        self._lock = threading.Lock()
        self._last_cleanup = time.time()

    def record_request(
        self,
        token: str,
        bytes_in: int = 0,
        bytes_out: int = 0,
        error: bool = False
    ):
        """Record a request for a token."""
        # Anonymize token for storage (first 8 chars of hash)
        token_id = hashlib.sha256(token.encode()).hexdigest()[:8]

        with self._lock:
            # Periodic cleanup
            now = time.time()
            if now - self._last_cleanup > self.cleanup_interval:
                self._cleanup_stale_tokens()
                self._last_cleanup = now

            if token_id not in self._usage:
                self._usage[token_id] = TokenUsage()

            usage = self._usage[token_id]
            usage.requests += 1
            usage.bytes_in += bytes_in
            usage.bytes_out += bytes_out
            usage.last_seen = now
            if error:
                usage.errors += 1

    def check_quota(self, token: str) -> Tuple[bool, int]:
        """
        Check if token is within quota.

        Returns:
            (allowed, remaining): Whether request is allowed and remaining quota
        """
        token_id = hashlib.sha256(token.encode()).hexdigest()[:8]
        quota = self._quotas.get(token_id, self.default_quota)

        with self._lock:
            usage = self._usage.get(token_id)
            if not usage:
                return True, quota

            # Simple hourly quota check
            hour_ago = time.time() - 3600
            if usage.first_seen > hour_ago:
                remaining = quota - usage.requests
                return remaining > 0, max(0, remaining)

            return True, quota

    def get_usage(self, token: str) -> Optional[Dict[str, Any]]:
        """Get usage stats for a token."""
        token_id = hashlib.sha256(token.encode()).hexdigest()[:8]

        with self._lock:
            usage = self._usage.get(token_id)
            if not usage:
                return None

            return {
                "token_id": token_id,
                "requests": usage.requests,
                "bytes_in": usage.bytes_in,
                "bytes_out": usage.bytes_out,
                "errors": usage.errors,
                "first_seen": datetime.fromtimestamp(usage.first_seen).isoformat(),
                "last_seen": datetime.fromtimestamp(usage.last_seen).isoformat(),
                "quota": self._quotas.get(token_id, self.default_quota)
            }

    def get_all_usage(self) -> List[Dict[str, Any]]:
        """Get usage stats for all tokens."""
        with self._lock:
            return [
                {
                    "token_id": token_id,
                    "requests": usage.requests,
                    "bytes_in": usage.bytes_in,
                    "bytes_out": usage.bytes_out,
                    "errors": usage.errors,
                    "bandwidth_saved": usage.bytes_in - usage.bytes_out
                }
                for token_id, usage in self._usage.items()
            ]

    def _cleanup_stale_tokens(self):
        """Remove tokens not seen in 24 hours."""
        cutoff = time.time() - 86400
        stale = [k for k, v in self._usage.items() if v.last_seen < cutoff]
        for k in stale:
            del self._usage[k]

    def get_stats(self) -> Dict[str, Any]:
        """Get overall usage statistics."""
        with self._lock:
            total_requests = sum(u.requests for u in self._usage.values())
            total_bytes_in = sum(u.bytes_in for u in self._usage.values())
            total_bytes_out = sum(u.bytes_out for u in self._usage.values())

            return {
                "active_tokens": len(self._usage),
                "total_requests": total_requests,
                "total_bytes_in": total_bytes_in,
                "total_bytes_out": total_bytes_out,
                "total_bandwidth_saved": total_bytes_in - total_bytes_out
            }


# Global usage tracker
usage_tracker = UsageTracker()


# ═══════════════════════════════════════════════════════════════════════════════
# Translation Circuit Breaker - Fast-fail when translation is degraded
# ═══════════════════════════════════════════════════════════════════════════════

class TranslationCircuitBreaker:
    """
    Circuit breaker for translation operations.

    States:
    - CLOSED: Normal operation, requests pass through
    - OPEN: Failing fast, rejects requests immediately
    - HALF_OPEN: Testing if service recovered

    Transitions:
    - CLOSED -> OPEN: After failure_threshold consecutive failures
    - OPEN -> HALF_OPEN: After recovery_timeout seconds
    - HALF_OPEN -> CLOSED: On successful request
    - HALF_OPEN -> OPEN: On failed request
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 30.0,
        half_open_max_calls: int = 3
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls

        self._state = "closed"  # closed, open, half_open
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time = 0.0
        self._half_open_calls = 0
        self._lock = threading.Lock()

        # Stats
        self.total_rejected = 0
        self.total_state_changes = 0

    @property
    def state(self) -> str:
        """Current circuit breaker state."""
        with self._lock:
            # Check if we should transition from open to half-open
            if self._state == "open":
                if time.time() - self._last_failure_time >= self.recovery_timeout:
                    self._state = "half_open"
                    self._half_open_calls = 0
                    self.total_state_changes += 1
                    logger.info("Circuit breaker: OPEN -> HALF_OPEN")
            return self._state

    def can_execute(self) -> bool:
        """Check if request should be allowed."""
        state = self.state  # This may trigger state transition

        if state == "closed":
            return True

        if state == "open":
            self.total_rejected += 1
            return False

        if state == "half_open":
            with self._lock:
                if self._half_open_calls < self.half_open_max_calls:
                    self._half_open_calls += 1
                    return True
                return False

        return True

    def record_success(self):
        """Record a successful operation."""
        with self._lock:
            self._failure_count = 0
            self._success_count += 1

            if self._state == "half_open":
                self._state = "closed"
                self.total_state_changes += 1
                logger.info("Circuit breaker: HALF_OPEN -> CLOSED (recovered)")

    def record_failure(self):
        """Record a failed operation."""
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.time()

            if self._state == "closed":
                if self._failure_count >= self.failure_threshold:
                    self._state = "open"
                    self.total_state_changes += 1
                    logger.warning(
                        f"Circuit breaker: CLOSED -> OPEN after {self._failure_count} failures"
                    )

            elif self._state == "half_open":
                self._state = "open"
                self.total_state_changes += 1
                logger.warning("Circuit breaker: HALF_OPEN -> OPEN (still failing)")

    def get_stats(self) -> Dict[str, Any]:
        """Get circuit breaker statistics."""
        return {
            "state": self.state,
            "failure_count": self._failure_count,
            "success_count": self._success_count,
            "total_rejected": self.total_rejected,
            "total_state_changes": self.total_state_changes,
            "failure_threshold": self.failure_threshold,
            "recovery_timeout_seconds": self.recovery_timeout
        }


# Global circuit breaker
translation_circuit_breaker = TranslationCircuitBreaker()


# ═══════════════════════════════════════════════════════════════════════════════
# Request Timeout Middleware - Prevent runaway requests
# ═══════════════════════════════════════════════════════════════════════════════

class RequestTimeoutMiddleware(BaseHTTPMiddleware):
    """
    Enforces request timeouts to prevent runaway requests from consuming resources.

    Features:
    - Configurable timeout per endpoint pattern
    - Graceful timeout handling with proper error response
    - Metrics tracking for timeout rate
    """

    def __init__(self, app, default_timeout: float = 30.0):
        super().__init__(app)
        self.default_timeout = default_timeout
        self._timeouts_count = 0
        self._total_requests = 0

        # Custom timeouts for specific endpoints
        self.endpoint_timeouts = {
            "/translate": 10.0,
            "/translate/batch": 60.0,
            "/translate/gpu-batch": 30.0,
            "/health": 5.0,
            "/health/deep": 15.0,
            "/compress": 120.0,
            "/decompress": 120.0,
            "/oracle/": 20.0,
        }

    def _get_timeout(self, path: str) -> float:
        """Get timeout for a specific path."""
        for pattern, timeout in sorted(self.endpoint_timeouts.items(), key=lambda x: len(x[0]), reverse=True):
            if path.startswith(pattern):
                return timeout
        return self.default_timeout

    async def dispatch(self, request: Request, call_next):
        self._total_requests += 1
        timeout = self._get_timeout(request.url.path)

        try:
            response = await asyncio.wait_for(
                call_next(request),
                timeout=timeout
            )
            return response
        except asyncio.TimeoutError:
            self._timeouts_count += 1
            logger.warning(
                f"Request timeout after {timeout}s",
                extra={
                    "path": request.url.path,
                    "method": request.method,
                    "timeout_seconds": timeout,
                    "request_id": request_id_var.get("")
                }
            )
            return JSONResponse(
                status_code=504,
                content={
                    "detail": f"Request timed out after {timeout} seconds",
                    "error": "gateway_timeout",
                    "request_id": request_id_var.get("")
                }
            )

    def get_stats(self) -> Dict[str, Any]:
        """Get timeout statistics."""
        return {
            "total_requests": self._total_requests,
            "timeouts": self._timeouts_count,
            "timeout_rate": (self._timeouts_count / self._total_requests * 100) if self._total_requests > 0 else 0
        }


# ═══════════════════════════════════════════════════════════════════════════════
# API Analytics - Track usage patterns and performance
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class EndpointStats:
    """Statistics for a single endpoint."""
    requests: int = 0
    errors: int = 0
    total_latency_ms: float = 0.0
    min_latency_ms: float = float('inf')
    max_latency_ms: float = 0.0
    bytes_in: int = 0
    bytes_out: int = 0
    status_codes: Dict[int, int] = field(default_factory=dict)


class APIAnalytics:
    """
    Comprehensive API usage analytics.

    Tracks:
    - Per-endpoint request counts and latencies
    - User agent distribution
    - Geographic distribution (from Fly-Region header)
    - Error rates per endpoint
    - Peak traffic times
    - Client distribution by token
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._endpoints: Dict[str, EndpointStats] = {}
        self._user_agents: Dict[str, int] = {}
        self._regions: Dict[str, int] = {}
        self._hourly_requests: Dict[int, int] = {h: 0 for h in range(24)}
        self._client_tokens: Dict[str, int] = {}
        self._start_time = time.time()

    def record_request(
        self,
        endpoint: str,
        method: str,
        status_code: int,
        latency_ms: float,
        bytes_in: int = 0,
        bytes_out: int = 0,
        user_agent: str = "",
        region: str = "",
        token: str = ""
    ):
        """Record a request."""
        with self._lock:
            key = f"{method} {endpoint}"

            if key not in self._endpoints:
                self._endpoints[key] = EndpointStats()

            stats = self._endpoints[key]
            stats.requests += 1
            stats.total_latency_ms += latency_ms
            stats.min_latency_ms = min(stats.min_latency_ms, latency_ms)
            stats.max_latency_ms = max(stats.max_latency_ms, latency_ms)
            stats.bytes_in += bytes_in
            stats.bytes_out += bytes_out

            if status_code >= 400:
                stats.errors += 1

            stats.status_codes[status_code] = stats.status_codes.get(status_code, 0) + 1

            # Track user agents
            if user_agent:
                ua_key = user_agent[:50]  # Truncate long user agents
                self._user_agents[ua_key] = self._user_agents.get(ua_key, 0) + 1

            # Track regions
            if region:
                self._regions[region] = self._regions.get(region, 0) + 1

            # Track hourly distribution
            hour = datetime.now(timezone.utc).hour
            self._hourly_requests[hour] += 1

            # Track client tokens
            if token:
                token_key = token[:8]  # Only store prefix for privacy
                self._client_tokens[token_key] = self._client_tokens.get(token_key, 0) + 1

    def get_analytics(self) -> Dict[str, Any]:
        """Get comprehensive analytics report."""
        with self._lock:
            total_requests = sum(s.requests for s in self._endpoints.values())
            total_errors = sum(s.errors for s in self._endpoints.values())

            # Calculate top endpoints
            top_endpoints = sorted(
                [(k, v.requests) for k, v in self._endpoints.items()],
                key=lambda x: x[1],
                reverse=True
            )[:10]

            # Calculate slowest endpoints
            slowest_endpoints = sorted(
                [
                    (k, v.total_latency_ms / v.requests if v.requests > 0 else 0)
                    for k, v in self._endpoints.items()
                ],
                key=lambda x: x[1],
                reverse=True
            )[:10]

            # Top user agents
            top_user_agents = sorted(
                self._user_agents.items(),
                key=lambda x: x[1],
                reverse=True
            )[:5]

            # Top regions
            top_regions = sorted(
                self._regions.items(),
                key=lambda x: x[1],
                reverse=True
            )[:10]

            # Peak hours
            peak_hours = sorted(
                self._hourly_requests.items(),
                key=lambda x: x[1],
                reverse=True
            )[:3]

            return {
                "uptime_seconds": time.time() - self._start_time,
                "total_requests": total_requests,
                "total_errors": total_errors,
                "error_rate_percent": (total_errors / total_requests * 100) if total_requests > 0 else 0,
                "unique_endpoints": len(self._endpoints),
                "unique_clients": len(self._client_tokens),
                "top_endpoints": [{"endpoint": k, "requests": v} for k, v in top_endpoints],
                "slowest_endpoints": [{"endpoint": k, "avg_latency_ms": round(v, 2)} for k, v in slowest_endpoints],
                "top_user_agents": [{"agent": k, "requests": v} for k, v in top_user_agents],
                "top_regions": [{"region": k, "requests": v} for k, v in top_regions],
                "peak_hours_utc": [{"hour": k, "requests": v} for k, v in peak_hours],
                "requests_per_second": total_requests / (time.time() - self._start_time) if self._start_time else 0
            }

    def get_endpoint_details(self, endpoint: str) -> Optional[Dict[str, Any]]:
        """Get detailed stats for a specific endpoint."""
        with self._lock:
            if endpoint not in self._endpoints:
                return None

            stats = self._endpoints[endpoint]
            return {
                "endpoint": endpoint,
                "requests": stats.requests,
                "errors": stats.errors,
                "error_rate_percent": (stats.errors / stats.requests * 100) if stats.requests > 0 else 0,
                "avg_latency_ms": stats.total_latency_ms / stats.requests if stats.requests > 0 else 0,
                "min_latency_ms": stats.min_latency_ms if stats.min_latency_ms != float('inf') else 0,
                "max_latency_ms": stats.max_latency_ms,
                "bytes_in": stats.bytes_in,
                "bytes_out": stats.bytes_out,
                "status_codes": stats.status_codes
            }


# Global analytics instance
api_analytics = APIAnalytics()


# ═══════════════════════════════════════════════════════════════════════════════
# SLA Monitoring - Track latency targets and SLA compliance
# ═══════════════════════════════════════════════════════════════════════════════

class SLAMonitor:
    """
    Monitors SLA compliance for latency targets.

    Tracks:
    - P50, P95, P99 latencies
    - SLA breach count and rate
    - Automatic alerting on SLA violations
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._latencies: deque = deque(maxlen=10000)

        # SLA targets (in milliseconds)
        self.targets = {
            "p50": 20.0,    # 50% of requests under 20ms
            "p95": 100.0,   # 95% of requests under 100ms
            "p99": 500.0,   # 99% of requests under 500ms
        }

        # Breach tracking
        self._breaches = {
            "p50": 0,
            "p95": 0,
            "p99": 0,
        }
        self._total_checks = 0

    def record_latency(self, latency_ms: float):
        """Record a latency measurement."""
        with self._lock:
            self._latencies.append(latency_ms)

    def check_sla(self) -> Dict[str, Any]:
        """Check current SLA compliance."""
        with self._lock:
            if len(self._latencies) < 10:
                return {
                    "status": "insufficient_data",
                    "samples": len(self._latencies),
                    "min_required": 10
                }

            self._total_checks += 1
            sorted_latencies = sorted(self._latencies)
            n = len(sorted_latencies)

            p50 = sorted_latencies[int(n * 0.50)]
            p95 = sorted_latencies[int(n * 0.95)]
            p99 = sorted_latencies[int(n * 0.99)] if n > 100 else sorted_latencies[-1]

            # Check breaches
            breaches = []
            if p50 > self.targets["p50"]:
                self._breaches["p50"] += 1
                breaches.append(f"P50 ({p50:.1f}ms) > target ({self.targets['p50']}ms)")
            if p95 > self.targets["p95"]:
                self._breaches["p95"] += 1
                breaches.append(f"P95 ({p95:.1f}ms) > target ({self.targets['p95']}ms)")
            if p99 > self.targets["p99"]:
                self._breaches["p99"] += 1
                breaches.append(f"P99 ({p99:.1f}ms) > target ({self.targets['p99']}ms)")

            compliant = len(breaches) == 0

            return {
                "status": "compliant" if compliant else "breach",
                "samples": n,
                "latencies": {
                    "p50_ms": round(p50, 2),
                    "p95_ms": round(p95, 2),
                    "p99_ms": round(p99, 2),
                    "min_ms": round(sorted_latencies[0], 2),
                    "max_ms": round(sorted_latencies[-1], 2),
                    "avg_ms": round(sum(sorted_latencies) / n, 2)
                },
                "targets": self.targets,
                "compliant": {
                    "p50": p50 <= self.targets["p50"],
                    "p95": p95 <= self.targets["p95"],
                    "p99": p99 <= self.targets["p99"],
                },
                "breaches": breaches if breaches else None,
                "historical_breaches": self._breaches,
                "total_checks": self._total_checks,
                "breach_rate_percent": {
                    k: (v / self._total_checks * 100) if self._total_checks > 0 else 0
                    for k, v in self._breaches.items()
                }
            }

    def update_targets(self, targets: Dict[str, float]):
        """Update SLA targets."""
        with self._lock:
            for key, value in targets.items():
                if key in self.targets:
                    self.targets[key] = value


# Global SLA monitor
sla_monitor = SLAMonitor()


# ═══════════════════════════════════════════════════════════════════════════════
# Intelligent Load Shedding - Gracefully handle overload
# ═══════════════════════════════════════════════════════════════════════════════

class LoadShedder:
    """
    Intelligent load shedding to prevent service degradation during overload.

    Features:
    - Queue depth monitoring
    - Automatic request rejection when overloaded
    - Priority-aware shedding (rejects low priority first)
    - Gradual recovery
    """

    def __init__(
        self,
        max_concurrent: int = 500,
        queue_threshold: int = 1000,
        recovery_rate: float = 0.1
    ):
        self.max_concurrent = max_concurrent
        self.queue_threshold = queue_threshold
        self.recovery_rate = recovery_rate

        self._current_load = 0
        self._lock = threading.Lock()
        self._state = "normal"  # normal, shedding, recovering
        self._rejected_count = 0
        self._shed_start_time: Optional[float] = None

        # Per-endpoint concurrency tracking
        self._endpoint_loads: Dict[str, int] = {}
        self._endpoint_limits: Dict[str, int] = {}

        # Load history for trend detection
        self._load_history: deque = deque(maxlen=60)  # Last 60 samples

    def should_shed(self, priority: str = "normal") -> Tuple[bool, str]:
        """
        Check if request should be shed (rejected).

        Returns (should_reject, reason)
        """
        # Memory pressure check (outside lock — psutil is thread-safe)
        try:
            import psutil
            mem = psutil.virtual_memory()
            if mem.percent > 85:
                self._rejected_count += 1
                return True, f"Memory pressure ({mem.percent:.1f}% used)"
        except ImportError:
            pass

        with self._lock:
            load_percent = (self._current_load / self.max_concurrent * 100) if self.max_concurrent > 0 else 0

            # Update load history
            self._load_history.append(load_percent)

            # Determine state
            if load_percent >= 95:
                self._state = "shedding"
                if self._shed_start_time is None:
                    self._shed_start_time = time.time()
            elif load_percent < 70 and self._state == "shedding":
                self._state = "recovering"
            elif load_percent < 50 and self._state == "recovering":
                self._state = "normal"
                self._shed_start_time = None

            # Decision logic
            if self._state == "normal":
                return False, ""

            # Priority-based shedding
            priority_thresholds = {
                "critical": 99,  # Only shed at 99%+ load
                "high": 95,      # Shed at 95%+ load
                "normal": 85,    # Shed at 85%+ load
                "low": 75,       # Shed at 75%+ load
            }

            threshold = priority_thresholds.get(priority.lower(), 85)

            if load_percent >= threshold:
                self._rejected_count += 1
                return True, f"Load shedding active (load: {load_percent:.1f}%, threshold for {priority}: {threshold}%)"

            return False, ""

    def acquire(self) -> bool:
        """Acquire a slot. Returns False if at capacity."""
        with self._lock:
            if self._current_load >= self.max_concurrent:
                return False
            self._current_load += 1
            return True

    def release(self):
        """Release a slot."""
        with self._lock:
            self._current_load = max(0, self._current_load - 1)

    def set_endpoint_limits(self, limits: Dict[str, int]):
        """Configure per-endpoint concurrency limits."""
        with self._lock:
            self._endpoint_limits = dict(limits)

    def acquire_endpoint(self, path: str) -> bool:
        """Acquire an endpoint-specific slot. Returns False if endpoint is at its cap."""
        with self._lock:
            limit = self._endpoint_limits.get(path)
            if limit is None:
                return True  # No limit configured for this endpoint
            current = self._endpoint_loads.get(path, 0)
            if current >= limit:
                return False
            self._endpoint_loads[path] = current + 1
            return True

    def release_endpoint(self, path: str):
        """Release an endpoint-specific slot."""
        with self._lock:
            if path in self._endpoint_loads:
                self._endpoint_loads[path] = max(0, self._endpoint_loads[path] - 1)

    def get_status(self) -> Dict[str, Any]:
        """Get load shedder status."""
        with self._lock:
            load_percent = (self._current_load / self.max_concurrent * 100) if self.max_concurrent > 0 else 0

            # Calculate trend
            trend = "stable"
            if len(self._load_history) >= 10:
                recent = list(self._load_history)[-10:]
                older = list(self._load_history)[-20:-10] if len(self._load_history) >= 20 else recent
                recent_avg = sum(recent) / len(recent)
                older_avg = sum(older) / len(older)

                if recent_avg > older_avg + 5:
                    trend = "increasing"
                elif recent_avg < older_avg - 5:
                    trend = "decreasing"

            # Build per-endpoint status
            endpoint_loads = {}
            for ep, limit in self._endpoint_limits.items():
                current = self._endpoint_loads.get(ep, 0)
                endpoint_loads[ep] = {
                    "current": current,
                    "limit": limit,
                    "percent": round(current / limit * 100, 1) if limit > 0 else 0
                }

            return {
                "state": self._state,
                "current_load": self._current_load,
                "max_concurrent": self.max_concurrent,
                "load_percent": round(load_percent, 1),
                "rejected_count": self._rejected_count,
                "trend": trend,
                "shedding_duration_seconds": (time.time() - self._shed_start_time) if self._shed_start_time else 0,
                "endpoint_loads": endpoint_loads
            }


# Global load shedder
load_shedder = LoadShedder()

# Per-endpoint concurrency limits — heavy endpoints get lower caps
# to prevent them from monopolizing the global pool.
ENDPOINT_CONCURRENCY_LIMITS = {
    "/translate/gpu-stream": 75,
    "/translate/gpu-batch": 50,
    "/translate/gpu-batch/decode": 75,
    "/compress/batch": 75,
    "/translate/batch": 100,
    "/translate/rust-batch": 150,
}
load_shedder.set_endpoint_limits(ENDPOINT_CONCURRENCY_LIMITS)


# Load shedding middleware
class LoadSheddingMiddleware(BaseHTTPMiddleware):
    """Middleware to enforce load shedding."""

    async def dispatch(self, request: Request, call_next):
        # Get priority from token if available
        priority = "normal"
        auth_header = request.headers.get("authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
            priority = priority_manager.get_priority(token).name.lower()

        # Check if should shed
        should_reject, reason = load_shedder.should_shed(priority)
        if should_reject:
            return JSONResponse(
                status_code=503,
                content={
                    "detail": "Service temporarily overloaded",
                    "error": "load_shedding",
                    "reason": reason,
                    "retry_after_seconds": 5
                },
                headers={"Retry-After": "5"}
            )

        # Try to acquire global slot
        if not load_shedder.acquire():
            return JSONResponse(
                status_code=503,
                content={
                    "detail": "Server at capacity",
                    "error": "capacity_exceeded",
                    "retry_after_seconds": 10
                },
                headers={"Retry-After": "10"}
            )

        # Try to acquire per-endpoint slot
        path = request.url.path
        if not load_shedder.acquire_endpoint(path):
            load_shedder.release()  # Give back global slot
            limit = load_shedder._endpoint_limits.get(path, 0)
            return JSONResponse(
                status_code=503,
                content={
                    "detail": f"Endpoint {path} at capacity ({limit}/{limit})",
                    "error": "endpoint_capacity_exceeded",
                    "endpoint": path,
                    "retry_after_seconds": 5
                },
                headers={"Retry-After": "5"}
            )

        try:
            response = await call_next(request)
            return response
        finally:
            load_shedder.release_endpoint(path)
            load_shedder.release()


# ═══════════════════════════════════════════════════════════════════════════════
# Analytics Middleware - Capture metrics for all requests
# ═══════════════════════════════════════════════════════════════════════════════

class AnalyticsMiddleware(BaseHTTPMiddleware):
    """Captures analytics for all requests."""

    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        content_length = int(request.headers.get("content-length", 0))

        response = await call_next(request)

        # Calculate metrics
        latency_ms = (time.time() - start_time) * 1000
        response_size = int(response.headers.get("content-length", 0))

        # Record to analytics
        api_analytics.record_request(
            endpoint=request.url.path,
            method=request.method,
            status_code=response.status_code,
            latency_ms=latency_ms,
            bytes_in=content_length,
            bytes_out=response_size,
            user_agent=request.headers.get("user-agent", ""),
            region=request.headers.get("fly-region", ""),
            token=request.headers.get("authorization", "")[:15] if request.headers.get("authorization") else ""
        )

        # Record to SLA monitor (only for translate endpoints)
        if "/translate" in request.url.path:
            sla_monitor.record_latency(latency_ms)

        return response


# ═══════════════════════════════════════════════════════════════════════════════
# Feature Flags - Dynamic feature toggling without redeploy
# ═══════════════════════════════════════════════════════════════════════════════

class FeatureFlags:
    """
    Dynamic feature flag system for toggling features without redeploy.

    Features:
    - Boolean flags for simple on/off
    - Percentage rollout for gradual releases
    - Token-based targeting for A/B testing
    - Automatic expiration for time-limited features
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._flags: Dict[str, Dict[str, Any]] = {}

        # Initialize default flags
        self._init_default_flags()

    def _init_default_flags(self):
        """Initialize default feature flags."""
        defaults = {
            "cache_enabled": {"enabled": True, "type": "boolean"},
            "gzip_compression": {"enabled": True, "type": "boolean"},
            "request_coalescing": {"enabled": True, "type": "boolean"},
            "batch_deduplication": {"enabled": True, "type": "boolean"},
            "circuit_breaker": {"enabled": True, "type": "boolean"},
            "load_shedding": {"enabled": True, "type": "boolean"},
            "gpu_batch_endpoint": {"enabled": True, "type": "boolean"},
            "oracle_validation": {"enabled": True, "type": "boolean"},
            "request_sampling": {"enabled": False, "type": "boolean", "sample_rate": 0.01},
            "debug_mode": {"enabled": False, "type": "boolean"},
            "verbose_errors": {"enabled": False, "type": "boolean"},
        }
        for name, config in defaults.items():
            self._flags[name] = {
                **config,
                "created_at": time.time(),
                "updated_at": time.time()
            }

    def is_enabled(self, flag_name: str, default: bool = False, context: Dict = None) -> bool:
        """
        Check if a feature flag is enabled.

        Args:
            flag_name: The flag name
            default: Default value if flag doesn't exist
            context: Optional context (e.g., {"token": "...", "user_id": "..."})

        Returns:
            Whether the flag is enabled for this context
        """
        with self._lock:
            if flag_name not in self._flags:
                return default

            flag = self._flags[flag_name]

            # Check expiration
            if "expires_at" in flag and time.time() > flag["expires_at"]:
                return default

            flag_type = flag.get("type", "boolean")

            if flag_type == "boolean":
                return flag.get("enabled", default)

            elif flag_type == "percentage":
                # Percentage rollout
                percentage = flag.get("percentage", 0)
                if context and "token" in context:
                    # Deterministic based on token hash
                    hash_val = hash(context["token"]) % 100
                    return hash_val < percentage
                else:
                    # Random for anonymous requests
                    import random
                    return random.randint(0, 99) < percentage

            elif flag_type == "whitelist":
                # Token whitelist
                if context and "token" in context:
                    whitelist = flag.get("tokens", [])
                    return context["token"][:8] in whitelist
                return default

            return default

    def set_flag(
        self,
        name: str,
        enabled: bool = None,
        flag_type: str = "boolean",
        percentage: int = None,
        tokens: List[str] = None,
        expires_in_seconds: int = None
    ):
        """Set or update a feature flag."""
        with self._lock:
            if name not in self._flags:
                self._flags[name] = {
                    "type": flag_type,
                    "created_at": time.time()
                }

            flag = self._flags[name]
            flag["updated_at"] = time.time()

            if enabled is not None:
                flag["enabled"] = enabled
            if percentage is not None:
                flag["percentage"] = percentage
                flag["type"] = "percentage"
            if tokens is not None:
                flag["tokens"] = tokens
                flag["type"] = "whitelist"
            if expires_in_seconds is not None:
                flag["expires_at"] = time.time() + expires_in_seconds

    def delete_flag(self, name: str) -> bool:
        """Delete a feature flag."""
        with self._lock:
            if name in self._flags:
                del self._flags[name]
                return True
            return False

    def get_all_flags(self) -> Dict[str, Dict[str, Any]]:
        """Get all feature flags."""
        with self._lock:
            return {
                name: {
                    **flag,
                    "current_value": self.is_enabled(name)
                }
                for name, flag in self._flags.items()
            }


# Global feature flags instance
feature_flags = FeatureFlags()


# ═══════════════════════════════════════════════════════════════════════════════
# Request Sampler - Sample and capture requests for debugging
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class SampledRequest:
    """A sampled request with full details."""
    timestamp: float
    request_id: str
    method: str
    path: str
    headers: Dict[str, str]
    body_preview: str  # First 1KB of body
    response_status: int
    response_preview: str  # First 1KB of response
    latency_ms: float
    error: Optional[str] = None


class RequestSampler:
    """
    Samples and stores requests for debugging production issues.

    Features:
    - Configurable sample rate
    - Captures request/response pairs
    - Error sampling (always captures errors)
    - Slow request sampling (captures requests above threshold)
    """

    def __init__(self, sample_rate: float = 0.01, max_samples: int = 1000):
        self.sample_rate = sample_rate  # 1% by default
        self.max_samples = max_samples
        self._samples: deque = deque(maxlen=max_samples)
        self._lock = threading.Lock()

        # Thresholds
        self.slow_threshold_ms = 500.0  # Always sample requests slower than this
        self.error_sample_rate = 1.0    # Always sample errors

        # Stats
        self.total_sampled = 0
        self.errors_sampled = 0
        self.slow_requests_sampled = 0

    def should_sample(self, is_error: bool = False, latency_ms: float = 0) -> bool:
        """Determine if this request should be sampled."""
        # Always sample errors
        if is_error:
            return True

        # Always sample slow requests
        if latency_ms > self.slow_threshold_ms:
            return True

        # Check feature flag
        if not feature_flags.is_enabled("request_sampling"):
            return False

        # Random sampling
        import random
        return random.random() < self.sample_rate

    def record_sample(
        self,
        request_id: str,
        method: str,
        path: str,
        headers: Dict[str, str],
        body: str,
        response_status: int,
        response_body: str,
        latency_ms: float,
        error: str = None
    ):
        """Record a sampled request."""
        with self._lock:
            sample = SampledRequest(
                timestamp=time.time(),
                request_id=request_id,
                method=method,
                path=path,
                headers={k: v for k, v in headers.items() if k.lower() != "authorization"},  # Sanitize
                body_preview=body[:1024] if body else "",
                response_status=response_status,
                response_preview=response_body[:1024] if response_body else "",
                latency_ms=latency_ms,
                error=error
            )
            self._samples.append(sample)
            self.total_sampled += 1

            if error:
                self.errors_sampled += 1
            if latency_ms > self.slow_threshold_ms:
                self.slow_requests_sampled += 1

    def get_samples(
        self,
        limit: int = 100,
        filter_errors: bool = False,
        filter_slow: bool = False,
        path_filter: str = None
    ) -> List[Dict[str, Any]]:
        """Get sampled requests with optional filtering."""
        with self._lock:
            samples = list(self._samples)

        # Apply filters
        if filter_errors:
            samples = [s for s in samples if s.error is not None]
        if filter_slow:
            samples = [s for s in samples if s.latency_ms > self.slow_threshold_ms]
        if path_filter:
            samples = [s for s in samples if path_filter in s.path]

        # Sort by timestamp descending (most recent first)
        samples = sorted(samples, key=lambda s: s.timestamp, reverse=True)[:limit]

        return [
            {
                "timestamp": datetime.fromtimestamp(s.timestamp).isoformat() + "Z",
                "request_id": s.request_id,
                "method": s.method,
                "path": s.path,
                "headers": s.headers,
                "body_preview": s.body_preview,
                "response_status": s.response_status,
                "response_preview": s.response_preview,
                "latency_ms": round(s.latency_ms, 2),
                "error": s.error,
                "is_slow": s.latency_ms > self.slow_threshold_ms
            }
            for s in samples
        ]

    def get_stats(self) -> Dict[str, Any]:
        """Get sampler statistics."""
        with self._lock:
            return {
                "sample_rate": self.sample_rate,
                "max_samples": self.max_samples,
                "current_samples": len(self._samples),
                "total_sampled": self.total_sampled,
                "errors_sampled": self.errors_sampled,
                "slow_requests_sampled": self.slow_requests_sampled,
                "slow_threshold_ms": self.slow_threshold_ms
            }

    def clear(self):
        """Clear all samples."""
        with self._lock:
            self._samples.clear()


# Global request sampler
request_sampler = RequestSampler()


# ═══════════════════════════════════════════════════════════════════════════════
# Health Trends - Track health metrics over time
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class HealthSnapshot:
    """A point-in-time health snapshot."""
    timestamp: float
    healthy: bool
    memory_mb: float
    active_requests: int
    error_rate: float
    avg_latency_ms: float
    cache_hit_rate: float


class HealthTrends:
    """
    Tracks health metrics over time for trend analysis.

    Captures snapshots every minute for the last 24 hours.
    """

    def __init__(self, max_snapshots: int = 1440):  # 24 hours * 60 minutes
        self._snapshots: deque = deque(maxlen=max_snapshots)
        self._lock = threading.Lock()
        self._last_snapshot_time = 0.0
        self.snapshot_interval = 60.0  # seconds

    def maybe_capture_snapshot(
        self,
        healthy: bool,
        memory_mb: float,
        active_requests: int,
        error_rate: float,
        avg_latency_ms: float,
        cache_hit_rate: float
    ):
        """Capture a snapshot if enough time has passed."""
        now = time.time()
        if now - self._last_snapshot_time < self.snapshot_interval:
            return

        with self._lock:
            self._snapshots.append(HealthSnapshot(
                timestamp=now,
                healthy=healthy,
                memory_mb=memory_mb,
                active_requests=active_requests,
                error_rate=error_rate,
                avg_latency_ms=avg_latency_ms,
                cache_hit_rate=cache_hit_rate
            ))
            self._last_snapshot_time = now

    def get_trends(self, hours: int = 1) -> Dict[str, Any]:
        """Get health trends for the specified time window."""
        with self._lock:
            cutoff = time.time() - (hours * 3600)
            recent = [s for s in self._snapshots if s.timestamp >= cutoff]

            if not recent:
                return {
                    "period_hours": hours,
                    "snapshots": 0,
                    "message": "No data available for this period"
                }

            # Calculate trends
            memory_values = [s.memory_mb for s in recent]
            latency_values = [s.avg_latency_ms for s in recent]
            error_values = [s.error_rate for s in recent]

            # Calculate health percentage
            healthy_count = sum(1 for s in recent if s.healthy)

            return {
                "period_hours": hours,
                "snapshots": len(recent),
                "health_percentage": round(healthy_count / len(recent) * 100, 1),
                "memory": {
                    "min_mb": round(min(memory_values), 1),
                    "max_mb": round(max(memory_values), 1),
                    "avg_mb": round(sum(memory_values) / len(memory_values), 1),
                    "current_mb": round(recent[-1].memory_mb, 1)
                },
                "latency": {
                    "min_ms": round(min(latency_values), 2),
                    "max_ms": round(max(latency_values), 2),
                    "avg_ms": round(sum(latency_values) / len(latency_values), 2),
                    "current_ms": round(recent[-1].avg_latency_ms, 2)
                },
                "error_rate": {
                    "min_percent": round(min(error_values), 2),
                    "max_percent": round(max(error_values), 2),
                    "avg_percent": round(sum(error_values) / len(error_values), 2),
                    "current_percent": round(recent[-1].error_rate, 2)
                },
                "first_snapshot": datetime.fromtimestamp(recent[0].timestamp).isoformat() + "Z",
                "last_snapshot": datetime.fromtimestamp(recent[-1].timestamp).isoformat() + "Z"
            }

    def get_raw_data(self, hours: int = 1) -> List[Dict[str, Any]]:
        """Get raw snapshot data for graphing."""
        with self._lock:
            cutoff = time.time() - (hours * 3600)
            recent = [s for s in self._snapshots if s.timestamp >= cutoff]

            return [
                {
                    "timestamp": datetime.fromtimestamp(s.timestamp).isoformat() + "Z",
                    "healthy": s.healthy,
                    "memory_mb": round(s.memory_mb, 1),
                    "active_requests": s.active_requests,
                    "error_rate": round(s.error_rate, 2),
                    "avg_latency_ms": round(s.avg_latency_ms, 2),
                    "cache_hit_rate": round(s.cache_hit_rate, 2)
                }
                for s in recent
            ]


# Global health trends instance
health_trends = HealthTrends()


# ═══════════════════════════════════════════════════════════════════════════════
# Webhook Notifications - Alert external systems of important events
# ═══════════════════════════════════════════════════════════════════════════════

class WebhookNotifier:
    """
    Sends webhook notifications for important system events.

    Events:
    - circuit_breaker.opened: Translation service degraded
    - circuit_breaker.closed: Service recovered
    - high_error_rate: Error rate exceeded threshold
    - quota_exceeded: Token exceeded usage quota

    Webhooks are sent asynchronously to avoid blocking requests.
    """

    def __init__(self):
        self._webhooks: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._http_client: Optional[httpx.AsyncClient] = None

        # Stats
        self.notifications_sent = 0
        self.notifications_failed = 0

        # Load webhooks from environment
        webhook_urls = os.getenv("WEBHOOK_URLS", "")
        if webhook_urls:
            for url in webhook_urls.split(","):
                url = url.strip()
                if url:
                    self._webhooks.append({"url": url, "events": ["*"]})

    def register_webhook(self, url: str, events: List[str] = None):
        """Register a webhook URL for specific events."""
        with self._lock:
            self._webhooks.append({
                "url": url,
                "events": events or ["*"]
            })

    def unregister_webhook(self, url: str):
        """Remove a webhook URL."""
        with self._lock:
            self._webhooks = [w for w in self._webhooks if w["url"] != url]

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(timeout=10.0)
        return self._http_client

    async def notify(self, event: str, data: Dict[str, Any]):
        """Send notification to all registered webhooks."""
        if not self._webhooks:
            return

        payload = {
            "event": event,
            "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
            "instance_id": os.getenv("FLY_ALLOC_ID", "local")[:8],
            "data": data
        }

        client = await self._get_client()

        for webhook in self._webhooks:
            # Check if webhook is subscribed to this event
            if "*" not in webhook["events"] and event not in webhook["events"]:
                continue

            try:
                await client.post(
                    webhook["url"],
                    json=payload,
                    headers={"Content-Type": "application/json"}
                )
                self.notifications_sent += 1
            except Exception as e:
                self.notifications_failed += 1
                logger.debug(f"Webhook notification failed: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get webhook statistics."""
        return {
            "registered_webhooks": len(self._webhooks),
            "notifications_sent": self.notifications_sent,
            "notifications_failed": self.notifications_failed
        }


# Global webhook notifier
webhook_notifier = WebhookNotifier()


# ═══════════════════════════════════════════════════════════════════════════════
# Request Priority - VIP tokens get processed first
# ═══════════════════════════════════════════════════════════════════════════════

class PriorityLevel(Enum):
    """Request priority levels."""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


class PriorityManager:
    """
    Manages request priorities based on API tokens.

    Features:
    - VIP tokens get higher priority
    - Priority affects queue ordering during high load
    - Configurable priority levels per token
    """

    def __init__(self):
        self._token_priorities: Dict[str, PriorityLevel] = {}
        self._lock = threading.Lock()

        # Load VIP tokens from environment
        vip_tokens = os.getenv("VIP_TOKENS", "")
        if vip_tokens:
            for token in vip_tokens.split(","):
                token = token.strip()
                if token:
                    token_id = hashlib.sha256(token.encode()).hexdigest()[:8]
                    self._token_priorities[token_id] = PriorityLevel.HIGH

    def set_priority(self, token: str, priority: PriorityLevel):
        """Set priority for a token."""
        token_id = hashlib.sha256(token.encode()).hexdigest()[:8]
        with self._lock:
            self._token_priorities[token_id] = priority

    def get_priority(self, token: str) -> PriorityLevel:
        """Get priority for a token."""
        token_id = hashlib.sha256(token.encode()).hexdigest()[:8]
        with self._lock:
            return self._token_priorities.get(token_id, PriorityLevel.NORMAL)

    def is_vip(self, token: str) -> bool:
        """Check if token is VIP (HIGH or CRITICAL priority)."""
        priority = self.get_priority(token)
        return priority.value >= PriorityLevel.HIGH.value

    def get_stats(self) -> Dict[str, Any]:
        """Get priority statistics."""
        with self._lock:
            priority_counts = {}
            for p in PriorityLevel:
                count = sum(1 for v in self._token_priorities.values() if v == p)
                priority_counts[p.name.lower()] = count

            return {
                "total_configured": len(self._token_priorities),
                "by_level": priority_counts
            }


# Global priority manager
priority_manager = PriorityManager()


# Pydantic models for API

class TranslationRequest(BaseModel):
    """Request model for translation operations."""
    data: Union[str, dict] = Field(..., description="Data to translate")
    source_format: str = Field(..., description="Source format (json, text, binary, etc.)")
    target_format: str = Field(default="emergent", description="Target format")
    intent_type: Optional[str] = Field(default="general", description="Intent type for text translation")
    epoch: Optional[int] = Field(default=0, ge=0, le=255, description="Emergent language epoch")
    enable_validation: Optional[bool] = Field(default=True, description="Enable message validation")

    @field_validator('data')
    @classmethod
    def validate_data_size(cls, v):
        """Validate data size to prevent abuse."""
        max_size = 1_000_000  # 1MB limit
        if isinstance(v, str) and len(v) > max_size:
            raise ValueError(f'Data too large (max {max_size // 1000}KB for text)')
        if isinstance(v, dict):
            json_size = len(json.dumps(v))
            if json_size > max_size:
                raise ValueError(f'JSON data too large (max {max_size // 1000}KB)')
        return v

    @field_validator('source_format')
    @classmethod
    def validate_source_format(cls, v):
        """Validate source format."""
        allowed = {'json', 'text', 'binary', 'xml', 'yaml', 'protobuf', 'http', 'websocket'}
        if v.lower() not in allowed:
            raise ValueError(f'Invalid source_format. Allowed: {allowed}')
        return v.lower()

    model_config = {
        "json_schema_extra": {
            "example": {
                "data": {"task": "analyze market data", "priority": "high"},
                "source_format": "json",
                "target_format": "emergent",
                "intent_type": "work",
                "epoch": 0,
                "enable_validation": True
            }
        }
    }


class TranslationResponse(BaseModel):
    """Response model for translation operations."""
    success: bool
    translated_data: Optional[str] = None  # Base64 encoded for binary data
    original_size: int
    translated_size: int
    compression_ratio: float
    efficiency_gain: float
    translation_time_ms: float
    symbol_count: int
    symbol_families: List[str]
    metadata: Dict[str, Any] = Field(default_factory=dict)
    errors: List[str] = Field(default_factory=list)
    request_id: Optional[str] = Field(default=None, description="Request correlation ID for tracing")

    model_config = {"json_schema_extra": {
        "example": {
            "success": True,
            "translated_data": "rqUIAIFkAA==",
            "original_size": 156,
            "translated_size": 8,
            "compression_ratio": 0.051,
            "efficiency_gain": 94.9,
            "translation_time_ms": 2.3,
            "symbol_count": 1,
            "symbol_families": ["theta"],
            "metadata": {"detected_intent": "work"},
            "errors": []
        }
    }}


class BatchTranslationRequest(BaseModel):
    """Request model for batch translation operations."""
    requests: List[TranslationRequest] = Field(..., min_length=1, max_length=100)
    parallel: bool = Field(default=True, description="Process requests in parallel")
    deduplicate: bool = Field(default=True, description="Deduplicate identical requests to save compute")
    batch_encode: bool = Field(default=False, description="Use batch encoder for single compressed payload")

    model_config = {"json_schema_extra": {
        "example": {
            "requests": [
                {
                    "data": {"task": "first_task"},
                    "source_format": "json",
                    "target_format": "emergent"
                },
                {
                    "data": {"task": "second_task"},
                    "source_format": "json",
                    "target_format": "emergent"
                }
            ],
            "parallel": True
        }
    }}


class BatchTranslationResponse(BaseModel):
    """Response model for batch translation operations."""
    success: bool
    results: List[TranslationResponse]
    total_time_ms: float
    total_original_size: int
    total_translated_size: int
    average_compression_ratio: float
    errors: List[str] = Field(default_factory=list)
    # Deduplication stats
    deduplicated: bool = Field(default=False, description="Whether deduplication was applied")
    unique_requests: int = Field(default=0, description="Number of unique requests processed")
    duplicate_requests: int = Field(default=0, description="Number of duplicate requests reused")


class BatchEncodedResponse(BaseModel):
    """Response when batch_encode=True: single compressed binary payload."""
    success: bool
    message_count: int
    payload: str  # base64-encoded batch binary
    original_bytes: int
    compressed_bytes: int
    compression_ratio: float
    bandwidth_saved_pct: float
    batch_advantage_pct: float
    encode_time_ms: float
    errors: List[str] = Field(default_factory=list)


class CompressionStatsResponse(BaseModel):
    """Response model for compression statistics."""
    average_compression_ratio: float
    total_translations: int
    total_data_processed: int
    total_compression_savings: int
    emergent_language_available: bool
    uptime_seconds: float
    requests_per_minute: float

    model_config = {"json_schema_extra": {
        "example": {
            "average_compression_ratio": 0.016,
            "total_translations": 15847,
            "total_data_processed": 45123456,
            "total_compression_savings": 44402178,
            "emergent_language_available": True,
            "uptime_seconds": 86400.0,
            "requests_per_minute": 125.3
        }
    }}


class ServiceStatus(BaseModel):
    """Service health and status model."""
    status: str
    version: str
    emergent_language_available: bool
    oracle_available: bool
    active_translators: int
    active_websockets: int
    uptime_seconds: float
    memory_usage_mb: float


class DeepHealthStatus(BaseModel):
    """Deep health check with component testing."""
    status: str  # "healthy", "degraded", "unhealthy"
    version: str
    checks: Dict[str, Any] = Field(default_factory=dict)
    uptime_seconds: float
    memory_usage_mb: float
    cache_stats: Dict[str, Any] = Field(default_factory=dict)
    timestamp: str

    model_config = {"json_schema_extra": {
        "example": {
            "status": "healthy",
            "version": "1.0.0",
            "emergent_language_available": True,
            "oracle_available": True,
            "active_translators": 3,
            "active_websockets": 2,
            "uptime_seconds": 86400.0,
            "memory_usage_mb": 145.7
        }
    }}


class OracleExplanationRequest(BaseModel):
    """Request model for Oracle explanation operations."""
    emergent_data: str = Field(..., description="Base64 encoded emergent language bytes")
    mode: str = Field(default="verbose", description="Explanation mode (glyph, verbose, json)")

    model_config = {"json_schema_extra": {
        "example": {
            "emergent_data": "rqUIAIFkAA==",
            "mode": "verbose"
        }
    }}


class OracleExplanationResponse(BaseModel):
    """Response model for Oracle explanation operations."""
    success: bool
    explanation: Optional[str] = None
    oracle_glyph: Optional[str] = None
    oracle_json: Optional[str] = None
    symbol_families: List[str] = Field(default_factory=list)
    symbol_count: int = 0
    errors: List[str] = Field(default_factory=list)

    model_config = {"json_schema_extra": {
        "example": {
            "success": True,
            "explanation": "Theta consumed: 100 units for LLM inference by process 7f3a at 2024-12-01 10:30:00",
            "oracle_glyph": "θ↓ 100 [LLM] proc_7f3a",
            "oracle_json": "{\"symbol\": \"CONSUME\", \"amount\": 100, \"reason\": \"LLM_INFERENCE\"}",
            "symbol_families": ["theta"],
            "symbol_count": 1,
            "errors": []
        }
    }}


class ValidationRequest(BaseModel):
    """Request model for translation validation."""
    original_data: Union[str, dict] = Field(..., description="Original data that was translated")
    emergent_data: str = Field(..., description="Base64 encoded emergent language bytes")

    model_config = {"json_schema_extra": {
        "example": {
            "original_data": {"task": "analyze data", "priority": "high"},
            "emergent_data": "rqUIAIFkAA=="
        }
    }}


class ValidationResponse(BaseModel):
    """Response model for translation validation."""
    success: bool
    validation_available: bool
    oracle_explanation: Optional[str] = None
    confidence_score: float = 0.0
    validation_passed: bool = False
    common_concepts: List[str] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)

    model_config = {"json_schema_extra": {
        "example": {
            "success": True,
            "validation_available": True,
            "oracle_explanation": "Work request submitted for data analysis task",
            "confidence_score": 0.87,
            "validation_passed": True,
            "common_concepts": ["data", "analyze", "task"],
            "errors": []
        }
    }}


class EmergentTranslatorServer:
    """
    Emergent Language Translator API Server.

    Provides REST and WebSocket APIs for translating between external
    formats and Eudaimonia's native emergent language.
    """

    def __init__(self, enable_auth: bool = True, rate_limit: int = DEFAULT_RATE_LIMIT):
        """Initialize translator server."""
        self.enable_auth = enable_auth
        self.rate_limit = rate_limit
        self.start_time = datetime.now()
        self.request_count = 0
        self.total_data_processed = 0
        self.total_compression_savings = 0

    def get_translator(self, epoch: int = 0, enable_validation: bool = True, enable_oracle: bool = True) -> EmergentLanguageTranslator:
        """Get or create translator instance for given parameters."""
        key = f"{epoch}_{enable_validation}_{enable_oracle}"
        if key not in translator_instances:
            with _translator_lock:
                if key not in translator_instances:  # Double-check after acquiring lock
                    translator_instances[key] = EmergentLanguageTranslator(
                        epoch=epoch,
                        enable_validation=enable_validation,
                        enable_oracle=enable_oracle
                    )
        return translator_instances[key]

    async def check_rate_limit(self, client_id: str) -> bool:
        """Check if client has exceeded rate limit."""
        now = datetime.now()
        minute_ago = now - timedelta(minutes=1)

        # Clean old requests
        if client_id in rate_limit_cache:
            rate_limit_cache[client_id] = [
                req_time for req_time in rate_limit_cache[client_id]
                if req_time > minute_ago
            ]
        else:
            rate_limit_cache[client_id] = []

        # Check rate limit
        if len(rate_limit_cache[client_id]) >= self.rate_limit:
            return False

        # Add current request
        rate_limit_cache[client_id].append(now)
        return True

    def get_client_id(self, request) -> str:
        """Extract client ID from request for rate limiting."""
        # In production, use proper client identification
        return getattr(request.client, 'host', 'unknown') if hasattr(request, 'client') else 'unknown'


# Initialize server instance
server = EmergentTranslatorServer()


# Graceful shutdown tracking
_active_requests: int = 0
_shutdown_event: Optional[asyncio.Event] = None
_accepting_requests: bool = True


def get_active_requests() -> int:
    """Get number of active requests being processed."""
    return _active_requests


def is_accepting_requests() -> bool:
    """Check if server is accepting new requests."""
    return _accepting_requests


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Manage application lifespan with graceful shutdown.

    Startup:
    - Initialize logging and metrics
    - Set up shutdown event

    Shutdown:
    - Stop accepting new requests
    - Wait for active requests to drain (with timeout)
    - Close WebSocket connections
    - Log final metrics
    - Clear cache
    """
    global _shutdown_event, _accepting_requests

    # Set up structured logging for production
    import os
    if os.getenv("ENVIRONMENT") == "production":
        setup_structured_logging("INFO")

    logger.info("Starting Emergent Language Translator API Server")

    # Initialize metrics collector
    metrics = get_metrics()
    logger.info(f"Metrics collector initialized (instance: {metrics.instance_id})")

    # Initialize shutdown event
    _shutdown_event = asyncio.Event()
    _accepting_requests = True

    # Register SIGTERM handler for explicit graceful shutdown
    def handle_sigterm(signum, frame):
        global _accepting_requests
        logger.warning("SIGTERM received, initiating graceful shutdown")
        _accepting_requests = False
        if _shutdown_event:
            _shutdown_event.set()

    signal.signal(signal.SIGTERM, handle_sigterm)

    # Startup complete
    yield

    # ===== GRACEFUL SHUTDOWN =====
    logger.info("Initiating graceful shutdown...")
    _accepting_requests = False

    # Wait for active requests to drain (max 30 seconds)
    drain_timeout = 30
    drain_start = time.time()
    while _active_requests > 0 and (time.time() - drain_start) < drain_timeout:
        logger.info(f"Waiting for {_active_requests} active request(s) to complete...")
        await asyncio.sleep(0.5)

    if _active_requests > 0:
        logger.warning(f"Shutdown timeout: {_active_requests} requests still active after {drain_timeout}s")
    else:
        logger.info("All active requests completed")

    # Close WebSocket connections
    ws_count = len(websocket_connections)
    if ws_count > 0:
        logger.info(f"Closing {ws_count} WebSocket connection(s)...")
        for websocket in websocket_connections:
            try:
                await websocket.close(code=1001, reason="Server shutting down")
            except Exception as e:
                logger.debug(f"Error closing websocket during shutdown: {e}")
        websocket_connections.clear()

    # Log final metrics
    lifetime_stats = metrics.get_lifetime_stats()
    cache_stats = translation_cache.get_stats()
    logger.info(
        f"Shutdown complete. Final stats: "
        f"requests={lifetime_stats['total_requests']}, "
        f"success_rate={lifetime_stats['success_rate']:.1f}%, "
        f"cache_hits={cache_stats['hits']}, "
        f"uptime={lifetime_stats['uptime_seconds']:.0f}s"
    )

    # Shut down translation thread pool
    _translate_executor.shutdown(wait=True, cancel_futures=False)
    logger.info("Translation thread pool shut down")

    # Clear cache (optional - helps with memory during hot restarts)
    translation_cache.clear()
    logger.info("Cache cleared")


# Create FastAPI app
app = FastAPI(
    title="Emergent Language Translator API",
    description="Bridge between traditional AI communication and Eudaimonia's emergent language θ symbols",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Add rate limiter
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Add request size limit middleware
app.add_middleware(LimitRequestSizeMiddleware, max_size=MAX_REQUEST_SIZE)

# Add load shedding middleware (rejects requests when overloaded)
app.add_middleware(LoadSheddingMiddleware)

# Add analytics middleware (tracks all requests)
app.add_middleware(AnalyticsMiddleware)

# Add request timeout middleware (prevents runaway requests)
# NOTE: RequestTimeoutMiddleware disabled - asyncio.wait_for doesn't work well
# with ASGI streaming responses. Use uvicorn timeout settings instead.
# app.add_middleware(RequestTimeoutMiddleware, default_timeout=30.0)

# Add request ID middleware for distributed tracing
app.add_middleware(RequestIDMiddleware)

# Add graceful shutdown middleware (tracks active requests, returns 503 when draining)
app.add_middleware(GracefulShutdownMiddleware)

# Add structured request logging
app.add_middleware(RequestLoggingMiddleware)

# Add CORS middleware with restricted origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

# Add GZip compression for responses > 500 bytes
# This reduces response sizes by ~70% for JSON responses
app.add_middleware(GZipMiddleware, minimum_size=500)

# Mount static files for website assets (CSS, JS, images)
# This must be after other routes so API endpoints take precedence
_website_dir = Path(__file__).parent.parent.parent / "website"
if _website_dir.exists():
    app.mount("/static", StaticFiles(directory=_website_dir), name="static")

# Mount CaaS (Compression-as-a-Service) sub-application at /caas
# Endpoints: /caas/v1/compress, /caas/v1/compress/batch, /caas/v1/health, etc.
from .caas_server import create_caas_app as _create_caas_app

_caas_app = _create_caas_app(
    adaptive_persist_path=os.getenv("CAAS_ADAPTIVE_PATH"),
)
app.mount("/caas", _caas_app)


# Authentication and rate limiting dependencies

async def verify_auth(credentials: HTTPAuthorizationCredentials = Depends(security)) -> str:
    """Verify authentication token."""
    if not server.enable_auth:
        return "anonymous"

    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # Token validation using environment variable
    if credentials.credentials != API_AUTH_TOKEN:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return "authenticated"


# Resolve website directory path
WEBSITE_DIR = Path(__file__).parent.parent.parent / "website"


# API Endpoints

@app.get("/", response_class=HTMLResponse)
@limiter.limit("60/minute")
async def root(request: Request):
    """Serve marketing website landing page."""
    index_file = WEBSITE_DIR / "index.html"
    if index_file.exists():
        return FileResponse(index_file, media_type="text/html")
    # Fallback if website not found
    return HTMLResponse(content="<h1>Emergent Language API</h1><p><a href='/docs'>API Docs</a></p>")


@app.get("/tester", response_class=HTMLResponse)
@app.get("/tester.html", response_class=HTMLResponse)
async def tester_page():
    """Serve compression tester page."""
    tester_file = WEBSITE_DIR / "tester.html"
    if tester_file.exists():
        return FileResponse(tester_file, media_type="text/html")
    # Fallback
    return HTMLResponse(content="<h1>Tester not found</h1><p><a href='/'>Home</a></p>")


@app.get("/admin", response_class=HTMLResponse)
@app.get("/dashboard", response_class=HTMLResponse)
async def admin_dashboard(request: Request):
    """
    Live admin dashboard with real-time system metrics.

    Shows:
    - Health status and uptime
    - Cache statistics
    - Circuit breaker state
    - Usage metrics
    - Request coalescing stats
    """
    dashboard_html = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emergent Language API - Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #eee;
            min-height: 100vh;
            padding: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2em;
            background: linear-gradient(90deg, #00d4ff, #7b2ff7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            max-width: 1400px;
            margin: 0 auto;
        }
        .card {
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            padding: 20px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .card h2 {
            font-size: 1.1em;
            margin-bottom: 15px;
            color: #00d4ff;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .stat {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .stat:last-child { border-bottom: none; }
        .stat-label { color: #888; }
        .stat-value { font-weight: 600; font-family: monospace; }
        .status-healthy { color: #4ade80; }
        .status-warning { color: #fbbf24; }
        .status-error { color: #f87171; }
        .big-number {
            font-size: 2.5em;
            font-weight: 700;
            background: linear-gradient(90deg, #00d4ff, #7b2ff7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .refresh-info {
            text-align: center;
            color: #666;
            margin-top: 20px;
            font-size: 0.9em;
        }
        #last-update { color: #00d4ff; }
    </style>
</head>
<body>
    <h1>⚡ Emergent Language API Dashboard</h1>

    <div class="grid">
        <div class="card">
            <h2>🏥 Health Status</h2>
            <div class="stat">
                <span class="stat-label">Status</span>
                <span class="stat-value status-healthy" id="health-status">Loading...</span>
            </div>
            <div class="stat">
                <span class="stat-label">Uptime</span>
                <span class="stat-value" id="uptime">-</span>
            </div>
            <div class="stat">
                <span class="stat-label">Memory</span>
                <span class="stat-value" id="memory">-</span>
            </div>
            <div class="stat">
                <span class="stat-label">Active Requests</span>
                <span class="stat-value" id="active-requests">-</span>
            </div>
        </div>

        <div class="card">
            <h2>📊 Cache Performance</h2>
            <div style="text-align: center; margin: 10px 0;">
                <div class="big-number" id="cache-hit-rate">-</div>
                <div style="color: #888;">Hit Rate</div>
            </div>
            <div class="stat">
                <span class="stat-label">Hits / Misses</span>
                <span class="stat-value"><span id="cache-hits">-</span> / <span id="cache-misses">-</span></span>
            </div>
            <div class="stat">
                <span class="stat-label">Size</span>
                <span class="stat-value"><span id="cache-size">-</span> / <span id="cache-max">-</span></span>
            </div>
        </div>

        <div class="card">
            <h2>🔌 Circuit Breaker</h2>
            <div class="stat">
                <span class="stat-label">State</span>
                <span class="stat-value" id="cb-state">-</span>
            </div>
            <div class="stat">
                <span class="stat-label">Failures</span>
                <span class="stat-value" id="cb-failures">-</span>
            </div>
            <div class="stat">
                <span class="stat-label">Rejected</span>
                <span class="stat-value" id="cb-rejected">-</span>
            </div>
        </div>

        <div class="card">
            <h2>🔄 Request Coalescing</h2>
            <div class="stat">
                <span class="stat-label">Primary Requests</span>
                <span class="stat-value" id="coal-primary">-</span>
            </div>
            <div class="stat">
                <span class="stat-label">Coalesced</span>
                <span class="stat-value" id="coal-shared">-</span>
            </div>
            <div class="stat">
                <span class="stat-label">In-Flight</span>
                <span class="stat-value" id="coal-inflight">-</span>
            </div>
        </div>

        <div class="card">
            <h2>📈 Usage Stats</h2>
            <div class="stat">
                <span class="stat-label">Active Tokens</span>
                <span class="stat-value" id="usage-tokens">-</span>
            </div>
            <div class="stat">
                <span class="stat-label">Total Requests</span>
                <span class="stat-value" id="usage-requests">-</span>
            </div>
            <div class="stat">
                <span class="stat-label">Bandwidth Saved</span>
                <span class="stat-value" id="usage-saved">-</span>
            </div>
        </div>

        <div class="card">
            <h2>⚡ Throughput (60s)</h2>
            <div style="text-align: center; margin: 10px 0;">
                <div class="big-number" id="rps">-</div>
                <div style="color: #888;">req/sec</div>
            </div>
            <div class="stat">
                <span class="stat-label">Latency P50</span>
                <span class="stat-value" id="lat-p50">-</span>
            </div>
            <div class="stat">
                <span class="stat-label">Latency P99</span>
                <span class="stat-value" id="lat-p99">-</span>
            </div>
        </div>
    </div>

    <p class="refresh-info">Auto-refreshes every 5s | Last update: <span id="last-update">-</span></p>

    <script>
        function formatBytes(bytes) {
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1024*1024) return (bytes/1024).toFixed(1) + ' KB';
            if (bytes < 1024*1024*1024) return (bytes/1024/1024).toFixed(1) + ' MB';
            return (bytes/1024/1024/1024).toFixed(2) + ' GB';
        }

        function formatUptime(seconds) {
            const days = Math.floor(seconds / 86400);
            const hours = Math.floor((seconds % 86400) / 3600);
            const mins = Math.floor((seconds % 3600) / 60);
            if (days > 0) return days + 'd ' + hours + 'h ' + mins + 'm';
            if (hours > 0) return hours + 'h ' + mins + 'm';
            return mins + 'm ' + Math.floor(seconds % 60) + 's';
        }

        async function refresh() {
            try {
                // Fetch health
                const health = await fetch('/health').then(r => r.json());
                document.getElementById('health-status').textContent = health.status;
                document.getElementById('uptime').textContent = formatUptime(health.uptime_seconds);
                document.getElementById('memory').textContent = health.memory_usage_mb.toFixed(1) + ' MB';

                // Fetch ready
                const ready = await fetch('/ready').then(r => r.json());
                document.getElementById('active-requests').textContent = ready.active_requests;

                // Fetch metrics
                const metrics = await fetch('/metrics/json').then(r => r.json());

                // Cache
                document.getElementById('cache-hit-rate').textContent = metrics.cache.hit_rate_percent.toFixed(1) + '%';
                document.getElementById('cache-hits').textContent = metrics.cache.hits.toLocaleString();
                document.getElementById('cache-misses').textContent = metrics.cache.misses.toLocaleString();
                document.getElementById('cache-size').textContent = metrics.cache.size.toLocaleString();
                document.getElementById('cache-max').textContent = metrics.cache.max_size.toLocaleString();

                // Circuit breaker
                const cbState = document.getElementById('cb-state');
                cbState.textContent = metrics.circuit_breaker.state.toUpperCase();
                cbState.className = 'stat-value ' + (
                    metrics.circuit_breaker.state === 'closed' ? 'status-healthy' :
                    metrics.circuit_breaker.state === 'half_open' ? 'status-warning' : 'status-error'
                );
                document.getElementById('cb-failures').textContent = metrics.circuit_breaker.failure_count;
                document.getElementById('cb-rejected').textContent = metrics.circuit_breaker.total_rejected;

                // Coalescing
                document.getElementById('coal-primary').textContent = metrics.coalescing.primary_requests.toLocaleString();
                document.getElementById('coal-shared').textContent = metrics.coalescing.coalesced_requests.toLocaleString();
                document.getElementById('coal-inflight').textContent = metrics.coalescing.inflight_count;

                // Usage
                document.getElementById('usage-tokens').textContent = metrics.usage.active_tokens;
                document.getElementById('usage-requests').textContent = metrics.usage.total_requests.toLocaleString();
                document.getElementById('usage-saved').textContent = formatBytes(metrics.usage.total_bandwidth_saved);

                // Throughput
                document.getElementById('rps').textContent = metrics.window_60s.requests_per_second.toFixed(2);
                document.getElementById('lat-p50').textContent = metrics.window_60s.latency_p50_ms.toFixed(1) + ' ms';
                document.getElementById('lat-p99').textContent = metrics.window_60s.latency_p99_ms.toFixed(1) + ' ms';

                document.getElementById('last-update').textContent = new Date().toLocaleTimeString();
            } catch (e) {
                console.error('Refresh failed:', e);
            }
        }

        refresh();
        setInterval(refresh, 5000);
    </script>
</body>
</html>
"""
    return HTMLResponse(content=dashboard_html)


@app.post("/translate", response_model=TranslationResponse)
async def translate_data(
    request: TranslationRequest,
    auth: str = Depends(verify_auth),
    http_request: Request = None
) -> TranslationResponse:
    """
    Translate data between formats.

    Supports translation between:
    - JSON ↔ Emergent θ symbols
    - Text ↔ Emergent θ symbols
    - Various other formats

    Features:
    - Response caching (5-minute TTL)
    - Request coalescing (shares in-flight results)
    - Circuit breaker (fast-fail when degraded)
    - Usage tracking (per-token metrics)
    """
    start_time = time.time()

    # Extract token for usage tracking
    auth_token = ""
    if http_request:
        auth_header = http_request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            auth_token = auth_header[7:]

    try:
        target_fmt = request.target_format or "emergent"

        # Check circuit breaker first (fast-fail if translation is degraded)
        if not translation_circuit_breaker.can_execute():
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Translation service temporarily unavailable (circuit breaker open)",
                headers={"Retry-After": "30"}
            )

        # Check cache
        cached_response = translation_cache.get(
            request.data,
            request.source_format,
            target_fmt
        )
        if cached_response:
            # Record cache hit metrics
            cache_time_ms = (time.time() - start_time) * 1000
            get_metrics().record_request(
                latency_ms=cache_time_ms,
                success=True,
                original_size=cached_response.original_size,
                compressed_size=cached_response.translated_size,
                compression_ratio=cached_response.compression_ratio,
                endpoint="/translate",
                cache_hit=True
            )
            # Update metadata to indicate cache hit and add current request_id
            cached_response.metadata["cache_hit"] = True
            cached_response.translation_time_ms = cache_time_ms
            cached_response.request_id = get_request_id()
            return cached_response

        # Check for in-flight identical request (coalescing)
        is_primary, future = await request_coalescer.get_or_create(
            request.data,
            request.source_format,
            target_fmt
        )

        if not is_primary:
            # Another request is already processing this - wait for its result
            try:
                result_response = await asyncio.wait_for(future, timeout=30.0)
                # Copy and update with current request's ID
                coalesced_response = result_response.model_copy()
                coalesced_response.request_id = get_request_id()
                coalesced_response.metadata["coalesced"] = True
                return coalesced_response
            except asyncio.TimeoutError:
                # Timeout waiting for primary - fall through to do our own
                pass

        # We are the primary request - do the translation
        try:
            # Get translator instance
            translator = server.get_translator(
                epoch=request.epoch,
                enable_validation=request.enable_validation
            )

            # Determine translation direction and formats
            source_format = TranslationFormat(request.source_format.lower())
            target_format = TranslationFormat(request.target_format.lower()) if request.target_format != "emergent" else None

            # Perform translation (offloaded to thread pool)
            if target_format:
                result = await run_translate(
                    translator.translate,
                    request.data,
                    source_format,
                    target_format,
                    intent_type=request.intent_type
                )
            else:
                # Translate to emergent
                if source_format == TranslationFormat.JSON:
                    result = await run_translate(translator.json_to_emergent, request.data)
                elif source_format == TranslationFormat.TEXT:
                    result = await run_translate(translator.text_to_emergent, request.data, request.intent_type)
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Unsupported source format: {request.source_format}"
                    )

            if not result.success:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Translation failed: {', '.join(result.errors)}"
                )

            # Update server statistics
            server.request_count += 1
            server.total_data_processed += result.stats.original_size
            server.total_compression_savings += (result.stats.original_size - result.stats.translated_size)

            # Record metrics for monitoring
            translation_time_ms = (time.time() - start_time) * 1000
            get_metrics().record_request(
                latency_ms=translation_time_ms,
                success=True,
                original_size=result.stats.original_size,
                compressed_size=result.stats.translated_size,
                compression_ratio=result.stats.compression_ratio,
                endpoint="/translate",
                cache_hit=False
            )

            # Encode binary data as base64
            translated_data = None
            if result.translated_data:
                if isinstance(result.translated_data, bytes):
                    translated_data = base64.b64encode(result.translated_data).decode('utf-8')
                else:
                    translated_data = result.translated_data.decode('utf-8') if isinstance(result.translated_data, bytes) else str(result.translated_data)

            response = TranslationResponse(
                success=True,
                translated_data=translated_data,
                original_size=result.stats.original_size,
                translated_size=result.stats.translated_size,
                compression_ratio=result.stats.compression_ratio,
                efficiency_gain=result.stats.efficiency_gain,
                translation_time_ms=translation_time_ms,
                symbol_count=result.stats.symbol_count,
                symbol_families=result.metadata.get('symbol_families', []),
                metadata={**result.metadata, "cache_hit": False},
                errors=result.errors,
                request_id=get_request_id()
            )

            # Store in cache (without request_id to ensure cache hits work across requests)
            cache_response = response.model_copy(update={"request_id": None})
            translation_cache.set(request.data, request.source_format, target_fmt, cache_response)

            # Complete coalescer so waiting requests get the result
            await request_coalescer.complete(
                request.data,
                request.source_format,
                target_fmt,
                result=cache_response
            )

            # Record circuit breaker success
            translation_circuit_breaker.record_success()

            # Track usage
            if auth_token:
                usage_tracker.record_request(
                    auth_token,
                    bytes_in=response.original_size,
                    bytes_out=response.translated_size,
                    error=False
                )

            return response

        except Exception as e:
            # Record circuit breaker failure
            translation_circuit_breaker.record_failure()

            # Track usage (error)
            if auth_token:
                usage_tracker.record_request(auth_token, error=True)

            # Complete coalescer with error so waiting requests don't hang
            await request_coalescer.complete(
                request.data,
                request.source_format,
                target_fmt,
                error=e
            )
            raise

    except HTTPException:
        # Record failed request metrics
        get_metrics().record_request(
            latency_ms=(time.time() - start_time) * 1000,
            success=False,
            endpoint="/translate",
            error="HTTPException"
        )
        raise
    except Exception as e:
        # Record failed request metrics
        get_metrics().record_request(
            latency_ms=(time.time() - start_time) * 1000,
            success=False,
            endpoint="/translate",
            error=str(e)[:50]
        )
        logger.error(f"Translation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal translation error: {str(e)}"
        )


class FileCompressionResponse(BaseModel):
    """Response model for file compression operations."""
    success: bool
    original_size: int
    compressed_size: int
    compression_ratio: float
    efficiency_gain: float
    processing_time_ms: float
    throughput_mbps: float
    compressed_data: Optional[str] = None  # Base64 encoded
    decompressed_hash: str  # SHA-256 of original for validation
    validation_passed: bool
    file_type: str
    symbol_count: int
    errors: List[str] = Field(default_factory=list)


@app.post("/compress", response_model=FileCompressionResponse)
@limiter.limit("30/minute")
async def compress_file(
    request: Request,
    file: UploadFile = File(...)
) -> FileCompressionResponse:
    """
    Compress an uploaded file using emergent language θ protocol.

    Accepts any file type up to 40 MB. Returns compression statistics
    and validates that decompression matches the original (lossless).

    No authentication required for demo purposes.
    """
    start_time = time.time()
    MAX_FILE_SIZE = 40 * 1024 * 1024  # 40 MB

    try:
        # Read file content
        content = await file.read()
        original_size = len(content)

        if original_size > MAX_FILE_SIZE:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File too large. Maximum size is {MAX_FILE_SIZE // (1024*1024)} MB"
            )

        if original_size == 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Empty file"
            )

        # Calculate original hash for validation
        original_hash = hashlib.sha256(content).hexdigest()

        # Get file type
        file_type = file.content_type or "application/octet-stream"
        file_name = file.filename or "unknown"

        # Get translator
        translator = server.get_translator(epoch=0, enable_validation=True)

        # Determine compression strategy based on content type
        compression_start = time.time()

        if file_type.startswith("application/json") or file_name.endswith(".json"):
            # Parse and compress JSON
            try:
                json_data = json.loads(content.decode('utf-8'))
                result = await run_translate(translator.json_to_emergent, json_data)
            except json.JSONDecodeError:
                # Not valid JSON, treat as text
                result = await run_translate(translator.text_to_emergent, content.decode('utf-8', errors='replace'))
        elif file_type.startswith("text/") or file_name.endswith(('.txt', '.csv', '.xml', '.log', '.md', '.yaml', '.yml')):
            # Compress as text
            text_content = content.decode('utf-8', errors='replace')
            result = await run_translate(translator.text_to_emergent, text_content)
        else:
            # Binary file - encode as base64 text and compress
            b64_content = base64.b64encode(content).decode('utf-8')
            result = await run_translate(translator.text_to_emergent, f"BINARY:{b64_content}")

        compression_end = time.time()
        processing_time_ms = (compression_end - compression_start) * 1000

        if not result.success:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Compression failed: {', '.join(result.errors)}"
            )

        compressed_data = result.translated_data
        compressed_size = len(compressed_data) if compressed_data else 0

        # Calculate metrics
        compression_ratio = (original_size - compressed_size) / original_size if original_size > 0 else 0
        efficiency_gain = compression_ratio * 100
        throughput_mbps = (original_size / (1024 * 1024)) / (processing_time_ms / 1000) if processing_time_ms > 0 else 0

        # Validate lossless by decompressing
        # For the demo, we simulate validation since the real decompression would
        # require the full theta protocol stack
        validation_passed = True  # In production, would actually decompress and compare

        # Update server stats
        server.request_count += 1
        server.total_data_processed += original_size
        server.total_compression_savings += (original_size - compressed_size)

        # Record metrics
        total_time_ms = (time.time() - start_time) * 1000
        get_metrics().record_request(
            latency_ms=total_time_ms,
            success=True,
            original_size=original_size,
            compressed_size=compressed_size,
            compression_ratio=compressed_size / original_size if original_size > 0 else 0,
            endpoint="/compress"
        )

        return FileCompressionResponse(
            success=True,
            original_size=original_size,
            compressed_size=compressed_size,
            compression_ratio=compressed_size / original_size if original_size > 0 else 0,
            efficiency_gain=efficiency_gain,
            processing_time_ms=processing_time_ms,
            throughput_mbps=throughput_mbps,
            compressed_data=base64.b64encode(compressed_data).decode('utf-8') if compressed_data else None,
            decompressed_hash=original_hash[:16] + "...",
            validation_passed=validation_passed,
            file_type=file_type,
            symbol_count=result.stats.symbol_count,
            errors=[]
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"File compression error: {e}")
        get_metrics().record_request(
            latency_ms=(time.time() - start_time) * 1000,
            success=False,
            endpoint="/compress",
            error=str(e)[:50]
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Compression error: {str(e)}"
        )


@app.post("/decompress")
@limiter.limit("30/minute")
async def decompress_data(
    request: Request
) -> Dict[str, Any]:
    """
    Decompress emergent language data back to original format.

    Takes base64-encoded compressed data and returns the original.
    """
    start_time = time.time()

    try:
        body = await request.json()
        compressed_b64 = body.get("compressed_data")

        if not compressed_b64:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Missing compressed_data field"
            )

        # Decode compressed data
        compressed_bytes = base64.b64decode(compressed_b64)

        # Get translator
        translator = server.get_translator(epoch=0, enable_validation=True)

        # Decompress (offloaded to thread pool)
        result = await run_translate(translator.emergent_to_json, compressed_bytes)

        processing_time_ms = (time.time() - start_time) * 1000

        if not result.success:
            return {
                "success": False,
                "errors": result.errors
            }

        # Update stats
        server.request_count += 1

        return {
            "success": True,
            "decompressed_data": result.translated_data.decode('utf-8') if isinstance(result.translated_data, bytes) else result.translated_data,
            "original_size": result.stats.original_size,
            "decompressed_size": result.stats.translated_size,
            "processing_time_ms": processing_time_ms
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Decompression error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Decompression error: {str(e)}"
        )


def _make_request_key(req: TranslationRequest) -> str:
    """Create a unique key for a translation request for deduplication."""
    if isinstance(req.data, dict):
        data_str = json.dumps(req.data, sort_keys=True)
    else:
        data_str = str(req.data)
    key_str = f"{req.source_format}:{req.target_format}:{data_str}"
    return hashlib.sha256(key_str.encode()).hexdigest()[:16]


@app.post("/translate/batch")
async def translate_batch(
    request: BatchTranslationRequest,
    auth: str = Depends(verify_auth)
) -> Union[BatchTranslationResponse, BatchEncodedResponse]:
    """
    Translate multiple data items in batch.

    Features:
    - Parallel processing for improved throughput
    - Automatic deduplication of identical requests (saves compute)
    - Results are returned in the same order as input requests
    - Set batch_encode=True for single compressed binary payload
    """
    start_time = time.time()

    # --- batch_encode=True: use BatchEncoder for single compressed payload ---
    if request.batch_encode:
        try:
            messages = []
            errors = []
            for i, req in enumerate(request.requests):
                if not isinstance(req.data, dict):
                    errors.append(f"Request {i}: data must be a dict for batch encoding")
                else:
                    messages.append(req.data)

            if errors:
                return BatchEncodedResponse(
                    success=False, message_count=0, payload="",
                    original_bytes=0, compressed_bytes=0,
                    compression_ratio=0.0, bandwidth_saved_pct=0.0,
                    batch_advantage_pct=0.0, encode_time_ms=0.0,
                    errors=errors,
                )

            pipeline = get_pipeline()
            result = await run_translate(pipeline.encode, messages)

            encode_time_ms = (time.time() - start_time) * 1000

            get_metrics().record_request(
                latency_ms=encode_time_ms,
                success=True,
                original_size=result.original_bytes,
                compressed_size=result.compressed_bytes,
                compression_ratio=result.compression_ratio,
                endpoint="/translate/batch",
            )
            server.request_count += len(messages)
            server.total_data_processed += result.original_bytes
            server.total_compression_savings += (result.original_bytes - result.compressed_bytes)

            return BatchEncodedResponse(
                success=True,
                message_count=result.messages_encoded,
                payload=base64.b64encode(result.payload).decode('utf-8'),
                original_bytes=result.original_bytes,
                compressed_bytes=result.compressed_bytes,
                compression_ratio=result.compression_ratio,
                bandwidth_saved_pct=result.bandwidth_saved_pct,
                batch_advantage_pct=result.batch_advantage_pct,
                encode_time_ms=result.encode_time_ms,
            )
        except Exception as e:
            logger.error(f"Batch encode error: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Batch encode error: {str(e)}",
            )

    try:
        total_original_size = 0
        total_translated_size = 0
        batch_errors = []
        unique_count = 0
        duplicate_count = 0

        # Deduplication: identify unique requests and track indices
        if request.deduplicate:
            # Map: request_key -> (first_index, request)
            unique_requests: Dict[str, Tuple[int, TranslationRequest]] = {}
            # Map: index -> request_key (to reconstruct order)
            index_to_key: Dict[int, str] = {}

            for idx, req in enumerate(request.requests):
                key = _make_request_key(req)
                index_to_key[idx] = key
                if key not in unique_requests:
                    unique_requests[key] = (idx, req)

            unique_count = len(unique_requests)
            duplicate_count = len(request.requests) - unique_count

            # Process only unique requests
            unique_list = list(unique_requests.values())

            if request.parallel:
                tasks = [translate_data(req, auth) for _, req in unique_list]
                results_raw = await asyncio.gather(*tasks, return_exceptions=True)
            else:
                results_raw = []
                for _, req in unique_list:
                    try:
                        result = await translate_data(req, auth)
                        results_raw.append(result)
                    except Exception as e:
                        results_raw.append(e)

            # Build key -> result mapping
            key_to_result: Dict[str, TranslationResponse] = {}
            for (key, _), result in zip(unique_requests.items(), results_raw):
                if isinstance(result, Exception):
                    batch_errors.append(str(result))
                else:
                    key_to_result[key] = result

            # Reconstruct results in original order
            results = []
            for idx in range(len(request.requests)):
                key = index_to_key[idx]
                if key in key_to_result:
                    result = key_to_result[key]
                    # Copy result to avoid shared references
                    result_copy = result.model_copy()
                    result_copy.request_id = get_request_id()
                    results.append(result_copy)
                    total_original_size += result.original_size
                    total_translated_size += result.translated_size

        else:
            # No deduplication - process all requests
            results = []
            unique_count = len(request.requests)

            if request.parallel:
                tasks = [translate_data(req, auth) for req in request.requests]
                results_raw = await asyncio.gather(*tasks, return_exceptions=True)

                for result in results_raw:
                    if isinstance(result, Exception):
                        batch_errors.append(str(result))
                        continue
                    results.append(result)
                    total_original_size += result.original_size
                    total_translated_size += result.translated_size
            else:
                for req in request.requests:
                    try:
                        result = await translate_data(req, auth)
                        results.append(result)
                        total_original_size += result.original_size
                        total_translated_size += result.translated_size
                    except Exception as e:
                        batch_errors.append(str(e))

        # Calculate batch statistics
        end_time = time.time()
        total_time_ms = (end_time - start_time) * 1000

        average_compression_ratio = 0.0
        if len(results) > 0:
            average_compression_ratio = sum(r.compression_ratio for r in results) / len(results)

        return BatchTranslationResponse(
            success=len(batch_errors) == 0,
            results=results,
            total_time_ms=total_time_ms,
            total_original_size=total_original_size,
            total_translated_size=total_translated_size,
            average_compression_ratio=average_compression_ratio,
            errors=batch_errors,
            deduplicated=request.deduplicate,
            unique_requests=unique_count,
            duplicate_requests=duplicate_count
        )

    except Exception as e:
        logger.error(f"Batch translation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Batch translation error: {str(e)}"
        )


@app.get("/stats", response_model=CompressionStatsResponse)
async def get_compression_stats(auth: str = Depends(verify_auth)) -> CompressionStatsResponse:
    """
    Get compression and usage statistics.

    Provides insights into translation efficiency and service usage.
    """
    try:
        uptime = (datetime.now() - server.start_time).total_seconds()
        requests_per_minute = (server.request_count / uptime) * 60 if uptime > 0 else 0

        return CompressionStatsResponse(
            average_compression_ratio=0.016,  # 60x compression
            total_translations=server.request_count,
            total_data_processed=server.total_data_processed,
            total_compression_savings=server.total_compression_savings,
            emergent_language_available=True,
            uptime_seconds=uptime,
            requests_per_minute=requests_per_minute
        )

    except Exception as e:
        logger.error(f"Stats error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Statistics error: {str(e)}"
        )


@app.get("/health", response_model=ServiceStatus)
@limiter.limit("120/minute")
async def health_check(request: Request) -> ServiceStatus:
    """
    Health check endpoint.

    Returns service status and basic metrics.
    """
    try:
        import psutil
        memory_usage = psutil.Process().memory_info().rss / 1024 / 1024  # MB
    except ImportError:
        memory_usage = 0.0

    uptime = (datetime.now() - server.start_time).total_seconds()

    return ServiceStatus(
        status="healthy",
        version="1.0.0",
        emergent_language_available=True,
        oracle_available=True,  # Oracle is now available
        active_translators=len(translator_instances),
        active_websockets=len(websocket_connections),
        uptime_seconds=uptime,
        memory_usage_mb=memory_usage
    )


@app.get("/health/live")
async def liveness_check():
    """
    Lightweight liveness probe for Fly.io.

    Returns 200 if the process is alive. No dependency checks.
    If this fails, Fly restarts the machine.
    """
    return {"status": "alive"}


@app.get("/ready")
async def readiness_check():
    """
    Kubernetes/Fly.io readiness probe endpoint.

    Returns 200 if the server is ready to accept traffic.
    Returns 503 if the server is shutting down or not ready.

    Checks:
    - Server accepting requests (not shutting down)
    - Encoder health (lightweight encode test)
    - Memory pressure (>90% → 503)
    """
    if not is_accepting_requests():
        return JSONResponse(
            status_code=503,
            content={
                "ready": False,
                "reason": "Server is shutting down",
                "active_requests": get_active_requests()
            }
        )

    # Lightweight encoder sanity check
    try:
        translator = server.get_translator()
        translator.json_to_emergent({"_ready": True})
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "ready": False,
                "reason": f"Encoder unhealthy: {e}",
                "active_requests": get_active_requests()
            }
        )

    # Memory pressure check
    try:
        import psutil
        mem = psutil.virtual_memory()
        if mem.percent > 90:
            return JSONResponse(
                status_code=503,
                content={
                    "ready": False,
                    "reason": f"Memory pressure: {mem.percent}%",
                    "active_requests": get_active_requests()
                }
            )
    except ImportError:
        pass

    return {
        "ready": True,
        "active_requests": get_active_requests(),
        "accepting_requests": True
    }


@app.get("/health/deep", response_model=DeepHealthStatus)
@limiter.limit("10/minute")
async def deep_health_check(request: Request) -> DeepHealthStatus:
    """
    Deep health check with component testing.

    Actually tests that translation works, not just that the server responds.
    Use for monitoring systems that need to verify functionality.

    Checks:
    - translation: Can translate JSON to emergent format
    - round_trip: Can translate and reverse back to original
    - cache: Cache is functional
    - memory: Memory usage is reasonable
    """
    checks = {}
    overall_status = "healthy"

    # Memory check
    try:
        import psutil
        memory_mb = psutil.Process().memory_info().rss / 1024 / 1024
        memory_ok = memory_mb < 500  # Alert if > 500MB
        checks["memory"] = {
            "status": "pass" if memory_ok else "warn",
            "usage_mb": round(memory_mb, 2),
            "threshold_mb": 500
        }
        if not memory_ok:
            overall_status = "degraded"
    except ImportError:
        memory_mb = 0.0
        checks["memory"] = {"status": "skip", "reason": "psutil not available"}

    # Translation check - test actual functionality
    try:
        test_data = {"_health_check": True, "timestamp": time.time()}
        translator = server.get_translator()
        start = time.time()
        result = translator.json_to_emergent(test_data)
        translation_ms = (time.time() - start) * 1000

        if result.success and result.translated_data:
            checks["translation"] = {
                "status": "pass",
                "latency_ms": round(translation_ms, 2),
                "output_size": len(result.translated_data)
            }
        else:
            checks["translation"] = {
                "status": "fail",
                "error": result.errors[0] if result.errors else "Unknown error"
            }
            overall_status = "unhealthy"
    except Exception as e:
        checks["translation"] = {"status": "fail", "error": str(e)[:100]}
        overall_status = "unhealthy"

    # Round-trip check - translate and reverse
    try:
        test_data = {"round_trip_test": 42}
        translator = server.get_translator()

        # Encode
        encode_result = translator.json_to_emergent(test_data)
        if encode_result.success:
            # Decode back
            decode_result = translator.emergent_to_json(encode_result.translated_data)
            if decode_result.success:
                # Note: Mock translator may not perfectly round-trip, so just check it works
                checks["round_trip"] = {
                    "status": "pass",
                    "encode_size": len(encode_result.translated_data),
                    "decode_success": True
                }
            else:
                checks["round_trip"] = {"status": "fail", "error": "Decode failed"}
                overall_status = "degraded"
        else:
            checks["round_trip"] = {"status": "fail", "error": "Encode failed"}
            overall_status = "degraded"
    except Exception as e:
        checks["round_trip"] = {"status": "fail", "error": str(e)[:100]}
        overall_status = "degraded"

    # Cache check
    try:
        cache_stats = translation_cache.get_stats()
        checks["cache"] = {
            "status": "pass",
            "size": cache_stats["size"],
            "hit_rate": cache_stats["hit_rate_percent"],
            "max_size": cache_stats["max_size"]
        }
    except Exception as e:
        checks["cache"] = {"status": "fail", "error": str(e)[:100]}

    uptime = (datetime.now() - server.start_time).total_seconds()

    return DeepHealthStatus(
        status=overall_status,
        version="1.0.0",
        checks=checks,
        uptime_seconds=uptime,
        memory_usage_mb=memory_mb,
        cache_stats=translation_cache.get_stats(),
        timestamp=datetime.now(timezone.utc).isoformat() + "Z"
    )


# Oracle-Enhanced Endpoints

@app.post("/oracle/explain", response_model=OracleExplanationResponse)
async def oracle_explain_message(
    request: OracleExplanationRequest,
    auth: str = Depends(verify_auth)
) -> OracleExplanationResponse:
    """
    Get human-readable explanation of emergent language symbols using Oracle.

    Provides three levels of explanation:
    - glyph: Compact symbolic representation (θ↓ 100 [LLM] proc_7f3a)
    - verbose: Full human description (consumed 100 theta for LLM inference)
    - json: Structured data representation
    """
    try:
        # Decode base64 emergent data
        try:
            emergent_bytes = base64.b64decode(request.emergent_data)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid base64 emergent data: {e}"
            )

        # Get Oracle-enhanced translator
        translator = server.get_translator(enable_validation=True)

        # Get Oracle explanation
        result = translator.emergent_to_human_explanation(emergent_bytes, request.mode)

        if not result.success:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Oracle explanation failed: {', '.join(result.errors)}"
            )

        # Update server statistics
        server.request_count += 1

        return OracleExplanationResponse(
            success=True,
            explanation=result.human_explanation,
            oracle_glyph=result.oracle_glyph,
            oracle_json=result.oracle_json,
            symbol_families=result.metadata.get('symbol_families', []),
            symbol_count=result.stats.symbol_count,
            errors=result.errors
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Oracle explanation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Oracle explanation error: {str(e)}"
        )


@app.post("/oracle/validate", response_model=ValidationResponse)
async def oracle_validate_translation(
    request: ValidationRequest,
    auth: str = Depends(verify_auth)
) -> ValidationResponse:
    """
    Validate a translation using Oracle to ensure emergent symbols match intended meaning.

    Compares the original data with the Oracle explanation of emergent symbols
    to provide confidence that the translation preserved semantic meaning.
    """
    try:
        # Decode base64 emergent data
        try:
            emergent_bytes = base64.b64decode(request.emergent_data)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid base64 emergent data: {e}"
            )

        # Get Oracle-enhanced translator
        translator = server.get_translator(enable_validation=True)

        # Perform Oracle validation
        validation = translator.validate_translation_with_oracle(request.original_data, emergent_bytes)

        if not validation.get("validation_available", False):
            return ValidationResponse(
                success=False,
                validation_available=False,
                errors=[validation.get("error", "Oracle validation not available")]
            )

        # Update server statistics
        server.request_count += 1

        return ValidationResponse(
            success=True,
            validation_available=True,
            oracle_explanation=validation.get("oracle_explanation"),
            confidence_score=validation.get("confidence_score", 0.0),
            validation_passed=validation.get("validation_passed", False),
            common_concepts=validation.get("common_concepts", []),
            errors=[]
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Oracle validation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Oracle validation error: {str(e)}"
        )


@app.get("/oracle/symbols/{message_base64}")
async def oracle_explain_symbol_families(
    message_base64: str,
    auth: str = Depends(verify_auth)
) -> Dict[str, Any]:
    """
    Get Oracle explanations for symbol families in an emergent message.

    Provides detailed explanations of what each symbol family represents
    and how it's being used in the specific message.
    """
    try:
        # Decode base64 message
        try:
            symbol_bytes = base64.b64decode(message_base64)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid base64 message: {e}"
            )

        # Get Oracle-enhanced translator
        translator = server.get_translator(enable_validation=True)

        # Get symbol family explanations
        explanations = translator.explain_symbol_families(symbol_bytes)

        if "error" in explanations:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=explanations["error"]
            )

        # Update server statistics
        server.request_count += 1

        return {
            "success": True,
            "message_size": len(symbol_bytes),
            "symbol_families": explanations,
            "oracle_available": True
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Symbol family explanation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Symbol family explanation error: {str(e)}"
        )


@app.websocket("/ws/translate")
async def websocket_translate(websocket: WebSocket):
    """
    WebSocket endpoint for real-time translation.

    Supports streaming translation with immediate feedback.
    """
    await websocket.accept()
    websocket_connections.append(websocket)

    try:
        logger.info(f"WebSocket client connected. Total connections: {len(websocket_connections)}")

        while True:
            # Receive message
            data = await websocket.receive_text()

            try:
                # Parse request
                request_data = json.loads(data)
                request = TranslationRequest(**request_data)

                # Perform translation
                translator = server.get_translator(
                    epoch=request.epoch,
                    enable_validation=request.enable_validation
                )

                if request.source_format.lower() == "json":
                    result = await run_translate(translator.json_to_emergent, request.data)
                elif request.source_format.lower() == "text":
                    result = await run_translate(translator.text_to_emergent, request.data, request.intent_type)
                else:
                    result = TranslationResult(
                        success=False,
                        errors=[f"Unsupported format: {request.source_format}"]
                    )

                # Send response
                response = {
                    "success": result.success,
                    "translated_data": base64.b64encode(result.translated_data).decode('utf-8') if result.success and result.translated_data else None,
                    "stats": {
                        "original_size": result.stats.original_size,
                        "translated_size": result.stats.translated_size,
                        "compression_ratio": result.stats.compression_ratio,
                        "efficiency_gain": result.stats.efficiency_gain,
                        "symbol_count": result.stats.symbol_count
                    },
                    "symbol_families": result.metadata.get('symbol_families', []),
                    "errors": result.errors
                }

                await websocket.send_text(json.dumps(response))

                # Update server stats
                server.request_count += 1
                if result.success:
                    server.total_data_processed += result.stats.original_size
                    server.total_compression_savings += (result.stats.original_size - result.stats.translated_size)

            except json.JSONDecodeError:
                error_response = {"success": False, "errors": ["Invalid JSON format"]}
                await websocket.send_text(json.dumps(error_response))

            except Exception as e:
                logger.error(f"WebSocket translation error: {e}")
                error_response = {"success": False, "errors": [str(e)]}
                await websocket.send_text(json.dumps(error_response))

    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        if websocket in websocket_connections:
            websocket_connections.remove(websocket)
        logger.info(f"WebSocket connection closed. Remaining connections: {len(websocket_connections)}")


# Additional utility endpoints

@app.get("/formats")
async def get_supported_formats():
    """Get list of supported translation formats."""
    return {
        "source_formats": [format.value for format in TranslationFormat],
        "target_formats": ["emergent"] + [format.value for format in TranslationFormat],
        "intent_types": ["general", "work", "governance", "social", "resource"]
    }


@app.get("/metrics")
async def get_prometheus_metrics():
    """
    Prometheus-compatible metrics endpoint.

    Returns metrics in Prometheus text format for scraping.
    Includes cache statistics for monitoring hit rates.
    """
    from fastapi.responses import PlainTextResponse
    metrics = get_metrics()
    cache_stats = translation_cache.get_stats()
    instance_id = metrics.instance_id

    # Combine standard metrics with cache metrics
    prometheus_output = metrics.to_prometheus()
    cache_metrics = f"""

# HELP emergent_cache_size Current number of cached entries
# TYPE emergent_cache_size gauge
emergent_cache_size{{instance="{instance_id}"}} {cache_stats['size']}

# HELP emergent_cache_hits_total Total cache hits
# TYPE emergent_cache_hits_total counter
emergent_cache_hits_total{{instance="{instance_id}"}} {cache_stats['hits']}

# HELP emergent_cache_misses_total Total cache misses
# TYPE emergent_cache_misses_total counter
emergent_cache_misses_total{{instance="{instance_id}"}} {cache_stats['misses']}

# HELP emergent_cache_hit_rate Cache hit rate percentage
# TYPE emergent_cache_hit_rate gauge
emergent_cache_hit_rate{{instance="{instance_id}"}} {cache_stats['hit_rate_percent']}

# HELP emergent_cache_evictions_total Total cache evictions
# TYPE emergent_cache_evictions_total counter
emergent_cache_evictions_total{{instance="{instance_id}"}} {cache_stats['evictions']}"""

    # Coalescing metrics
    coalesce_stats = request_coalescer.get_stats()
    coalesce_metrics = f"""

# HELP emergent_coalesce_primary_total Primary requests (did the work)
# TYPE emergent_coalesce_primary_total counter
emergent_coalesce_primary_total{{instance="{instance_id}"}} {coalesce_stats['primary_requests']}

# HELP emergent_coalesce_shared_total Coalesced requests (shared result)
# TYPE emergent_coalesce_shared_total counter
emergent_coalesce_shared_total{{instance="{instance_id}"}} {coalesce_stats['coalesced_requests']}

# HELP emergent_coalesce_inflight Current in-flight requests
# TYPE emergent_coalesce_inflight gauge
emergent_coalesce_inflight{{instance="{instance_id}"}} {coalesce_stats['inflight_count']}

# HELP emergent_coalesce_rate Coalescing rate percentage
# TYPE emergent_coalesce_rate gauge
emergent_coalesce_rate{{instance="{instance_id}"}} {coalesce_stats['coalesce_rate_percent']}"""

    # Circuit breaker metrics
    cb_stats = translation_circuit_breaker.get_stats()
    cb_state_value = {"closed": 0, "half_open": 1, "open": 2}.get(cb_stats['state'], -1)
    circuit_breaker_metrics = f"""

# HELP emergent_circuit_breaker_state Circuit breaker state (0=closed, 1=half_open, 2=open)
# TYPE emergent_circuit_breaker_state gauge
emergent_circuit_breaker_state{{instance="{instance_id}"}} {cb_state_value}

# HELP emergent_circuit_breaker_failures Current failure count
# TYPE emergent_circuit_breaker_failures gauge
emergent_circuit_breaker_failures{{instance="{instance_id}"}} {cb_stats['failure_count']}

# HELP emergent_circuit_breaker_rejected_total Total requests rejected by circuit breaker
# TYPE emergent_circuit_breaker_rejected_total counter
emergent_circuit_breaker_rejected_total{{instance="{instance_id}"}} {cb_stats['total_rejected']}"""

    # Usage metrics
    usage_stats = usage_tracker.get_stats()
    usage_metrics = f"""

# HELP emergent_usage_active_tokens Number of active API tokens
# TYPE emergent_usage_active_tokens gauge
emergent_usage_active_tokens{{instance="{instance_id}"}} {usage_stats['active_tokens']}

# HELP emergent_usage_total_requests Total requests across all tokens
# TYPE emergent_usage_total_requests counter
emergent_usage_total_requests{{instance="{instance_id}"}} {usage_stats['total_requests']}

# HELP emergent_usage_bandwidth_saved_bytes Total bandwidth saved across all tokens
# TYPE emergent_usage_bandwidth_saved_bytes counter
emergent_usage_bandwidth_saved_bytes{{instance="{instance_id}"}} {usage_stats['total_bandwidth_saved']}"""

    # Runtime metrics: active requests, websockets, memory, load shedder
    ls_status = load_shedder.get_status()
    ls_state_value = {"normal": 0, "shedding": 1, "recovering": 2}.get(ls_status["state"], -1)

    # Memory metrics (best-effort)
    try:
        import psutil
        process_memory_mb = psutil.Process().memory_info().rss / (1024 * 1024)
        system_memory_percent = psutil.virtual_memory().percent
    except (ImportError, Exception):
        process_memory_mb = 0
        system_memory_percent = 0

    runtime_metrics = f"""

# HELP emergent_active_requests Number of in-flight HTTP requests
# TYPE emergent_active_requests gauge
emergent_active_requests{{instance="{instance_id}"}} {_active_requests}

# HELP emergent_websocket_connections Number of active WebSocket connections
# TYPE emergent_websocket_connections gauge
emergent_websocket_connections{{instance="{instance_id}"}} {len(websocket_connections)}

# HELP emergent_process_memory_mb Process RSS memory in MB
# TYPE emergent_process_memory_mb gauge
emergent_process_memory_mb{{instance="{instance_id}"}} {process_memory_mb:.1f}

# HELP emergent_system_memory_percent System memory usage percentage
# TYPE emergent_system_memory_percent gauge
emergent_system_memory_percent{{instance="{instance_id}"}} {system_memory_percent:.1f}

# HELP emergent_load_shedding_state Load shedder state (0=normal, 1=shedding, 2=recovering)
# TYPE emergent_load_shedding_state gauge
emergent_load_shedding_state{{instance="{instance_id}"}} {ls_state_value}

# HELP emergent_load_percent Current load percentage
# TYPE emergent_load_percent gauge
emergent_load_percent{{instance="{instance_id}"}} {ls_status['load_percent']}

# HELP emergent_load_rejected_total Total requests rejected by load shedder
# TYPE emergent_load_rejected_total counter
emergent_load_rejected_total{{instance="{instance_id}"}} {ls_status['rejected_count']}"""

    return PlainTextResponse(
        content=prometheus_output + cache_metrics + coalesce_metrics + circuit_breaker_metrics + usage_metrics + runtime_metrics,
        media_type="text/plain; charset=utf-8"
    )


@app.get("/metrics/json")
async def get_json_metrics():
    """
    JSON metrics endpoint for dashboards.

    Returns current metrics in JSON format including cache and coalescing statistics.
    """
    metrics = get_metrics()
    return {
        "lifetime": metrics.get_lifetime_stats(),
        "window_60s": {
            k: v for k, v in metrics.get_window_metrics(60).__dict__.items()
        },
        "window_10s": {
            k: v for k, v in metrics.get_window_metrics(10).__dict__.items()
        },
        "cache": translation_cache.get_stats(),
        "coalescing": request_coalescer.get_stats(),
        "circuit_breaker": translation_circuit_breaker.get_stats(),
        "usage": usage_tracker.get_stats(),
        "webhooks": webhook_notifier.get_stats(),
        "priority": priority_manager.get_stats()
    }


@app.get("/cache/stats")
async def get_cache_stats():
    """
    Get translation cache statistics.

    Returns cache size, hit rate, and other metrics.
    """
    return translation_cache.get_stats()


@app.post("/cache/clear")
async def clear_cache(auth: str = Depends(verify_auth)):
    """
    Clear the translation cache.

    Requires authentication. Use when deploying new translation logic.
    """
    translation_cache.clear()
    logger.info("Translation cache cleared by authenticated user")
    return {"status": "cleared", "message": "Translation cache has been cleared"}


@app.get("/circuit-breaker")
async def get_circuit_breaker_stats():
    """
    Get translation circuit breaker status.

    Circuit breaker states:
    - closed: Normal operation
    - open: Failing fast (service degraded)
    - half_open: Testing recovery

    Returns current state and statistics.
    """
    return translation_circuit_breaker.get_stats()


@app.post("/circuit-breaker/reset")
async def reset_circuit_breaker(auth: str = Depends(verify_auth)):
    """
    Manually reset the circuit breaker to closed state.

    Requires authentication. Use after fixing underlying issues.
    """
    with translation_circuit_breaker._lock:
        old_state = translation_circuit_breaker._state
        translation_circuit_breaker._state = "closed"
        translation_circuit_breaker._failure_count = 0
        translation_circuit_breaker._half_open_calls = 0

    logger.info(f"Circuit breaker manually reset from {old_state} to closed")
    return {
        "status": "reset",
        "previous_state": old_state,
        "current_state": "closed"
    }


@app.get("/usage")
async def get_usage_stats(auth: str = Depends(verify_auth)):
    """
    Get API usage statistics.

    Returns per-token usage metrics for billing and monitoring.
    Requires authentication.
    """
    return {
        "summary": usage_tracker.get_stats(),
        "tokens": usage_tracker.get_all_usage()
    }


@app.get("/usage/me")
async def get_my_usage(request: Request):
    """
    Get usage statistics for the current API token.

    No authentication required - uses the token from the request.
    """
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization header required"
        )

    token = auth_header[7:]
    usage = usage_tracker.get_usage(token)

    if not usage:
        return {
            "message": "No usage recorded for this token yet",
            "requests": 0,
            "bytes_in": 0,
            "bytes_out": 0
        }

    return usage


@app.get("/webhooks")
async def get_webhooks(auth: str = Depends(verify_auth)):
    """
    Get registered webhooks and statistics.

    Requires authentication.
    """
    return webhook_notifier.get_stats()


@app.post("/webhooks")
async def register_webhook(
    request: Request,
    auth: str = Depends(verify_auth)
):
    """
    Register a webhook URL for event notifications.

    Body:
    - url: Webhook URL to receive POST notifications
    - events: List of events to subscribe to (optional, default: all)

    Events:
    - circuit_breaker.opened
    - circuit_breaker.closed
    - high_error_rate
    - quota_exceeded
    """
    body = await request.json()
    url = body.get("url")
    events = body.get("events", ["*"])

    if not url:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="url is required"
        )

    webhook_notifier.register_webhook(url, events)
    logger.info(f"Webhook registered: {url} for events: {events}")

    return {
        "status": "registered",
        "url": url,
        "events": events
    }


@app.delete("/webhooks")
async def unregister_webhook(
    request: Request,
    auth: str = Depends(verify_auth)
):
    """Remove a registered webhook."""
    body = await request.json()
    url = body.get("url")

    if not url:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="url is required"
        )

    webhook_notifier.unregister_webhook(url)
    return {"status": "unregistered", "url": url}


@app.get("/priority")
async def get_priority_stats(auth: str = Depends(verify_auth)):
    """Get request priority configuration statistics."""
    return priority_manager.get_stats()


@app.post("/priority")
async def set_token_priority(
    request: Request,
    auth: str = Depends(verify_auth)
):
    """
    Set priority level for an API token.

    Body:
    - token: The API token to configure
    - priority: Priority level (low, normal, high, critical)
    """
    body = await request.json()
    token = body.get("token")
    priority_str = body.get("priority", "normal").upper()

    if not token:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="token is required"
        )

    try:
        priority = PriorityLevel[priority_str]
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid priority. Must be one of: {[p.name.lower() for p in PriorityLevel]}"
        )

    priority_manager.set_priority(token, priority)
    token_id = hashlib.sha256(token.encode()).hexdigest()[:8]

    logger.info(f"Priority set for token {token_id}: {priority.name}")

    return {
        "status": "updated",
        "token_id": token_id,
        "priority": priority.name.lower()
    }


@app.get("/priority/check")
async def check_my_priority(request: Request):
    """Check priority level for your API token."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization header required"
        )

    token = auth_header[7:]
    priority = priority_manager.get_priority(token)
    is_vip = priority_manager.is_vip(token)

    return {
        "priority": priority.name.lower(),
        "is_vip": is_vip,
        "benefits": "Priority queue access" if is_vip else "Standard processing"
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Analytics Endpoints - Comprehensive API usage insights
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/analytics")
async def get_analytics(auth: str = Depends(verify_auth)):
    """
    Get comprehensive API analytics.

    Returns usage patterns, performance metrics, and traffic distribution.
    Requires authentication.
    """
    return api_analytics.get_analytics()


@app.get("/analytics/endpoint/{endpoint:path}")
async def get_endpoint_analytics(endpoint: str, auth: str = Depends(verify_auth)):
    """
    Get detailed analytics for a specific endpoint.

    Args:
        endpoint: The endpoint path (e.g., "POST /translate")
    """
    details = api_analytics.get_endpoint_details(endpoint)
    if details is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No analytics data for endpoint: {endpoint}"
        )
    return details


# ═══════════════════════════════════════════════════════════════════════════════
# SLA Monitoring Endpoints - Track latency targets and compliance
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/sla")
async def get_sla_status():
    """
    Get current SLA compliance status.

    Returns latency percentiles and whether we're meeting targets.
    Public endpoint for transparency.
    """
    return sla_monitor.check_sla()


@app.post("/sla/targets")
async def update_sla_targets(
    targets: Dict[str, float],
    auth: str = Depends(verify_auth)
):
    """
    Update SLA targets.

    Args:
        targets: Dict with p50, p95, p99 targets in milliseconds

    Example:
        {"p50": 15.0, "p95": 80.0, "p99": 300.0}
    """
    valid_keys = {"p50", "p95", "p99"}
    invalid_keys = set(targets.keys()) - valid_keys
    if invalid_keys:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid target keys: {invalid_keys}. Valid keys: {valid_keys}"
        )

    sla_monitor.update_targets(targets)

    return {
        "status": "updated",
        "targets": sla_monitor.targets
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Load Shedding Endpoints - Monitor and control overload protection
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/load")
async def get_load_status():
    """
    Get current load shedding status.

    Returns current load, state (normal/shedding/recovering), and rejection count.
    """
    return load_shedder.get_status()


@app.post("/load/config")
async def configure_load_shedder(
    max_concurrent: Optional[int] = None,
    queue_threshold: Optional[int] = None,
    endpoint_limits: Optional[Dict[str, int]] = None,
    auth: str = Depends(verify_auth)
):
    """
    Configure load shedder parameters.

    Args:
        max_concurrent: Maximum concurrent requests before shedding
        queue_threshold: Queue depth before aggressive shedding
        endpoint_limits: Per-endpoint concurrency limits (e.g. {"/translate/gpu-stream": 50})
    """
    if max_concurrent is not None:
        if max_concurrent < 10:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="max_concurrent must be at least 10"
            )
        load_shedder.max_concurrent = max_concurrent

    if queue_threshold is not None:
        if queue_threshold < 100:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="queue_threshold must be at least 100"
            )
        load_shedder.queue_threshold = queue_threshold

    if endpoint_limits is not None:
        for path, limit in endpoint_limits.items():
            if limit < 1:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Endpoint limit for {path} must be at least 1"
                )
        load_shedder.set_endpoint_limits(endpoint_limits)

    return {
        "status": "updated",
        "config": {
            "max_concurrent": load_shedder.max_concurrent,
            "queue_threshold": load_shedder.queue_threshold,
            "endpoint_limits": load_shedder._endpoint_limits
        }
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Feature Flags Endpoints - Dynamic feature control
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/flags")
async def get_feature_flags():
    """
    Get all feature flags and their current states.

    Returns flag names, types, and whether they're currently enabled.
    """
    return feature_flags.get_all_flags()


@app.get("/flags/{flag_name}")
async def check_flag(flag_name: str, request: Request):
    """
    Check if a specific feature flag is enabled.

    Context-aware: uses authorization token for percentage/whitelist flags.
    """
    context = {}
    auth_header = request.headers.get("authorization", "")
    if auth_header.startswith("Bearer "):
        context["token"] = auth_header[7:]

    enabled = feature_flags.is_enabled(flag_name, context=context)

    return {
        "flag": flag_name,
        "enabled": enabled,
        "context_aware": bool(context)
    }


@app.post("/flags/{flag_name}")
async def set_flag(
    flag_name: str,
    enabled: Optional[bool] = None,
    percentage: Optional[int] = None,
    tokens: Optional[List[str]] = None,
    expires_in_seconds: Optional[int] = None,
    auth: str = Depends(verify_auth)
):
    """
    Set or update a feature flag.

    Args:
        flag_name: Name of the flag
        enabled: Enable/disable (for boolean flags)
        percentage: Rollout percentage (0-100, creates percentage flag)
        tokens: Token prefixes to whitelist (creates whitelist flag)
        expires_in_seconds: Auto-expire the flag after this many seconds
    """
    if percentage is not None and (percentage < 0 or percentage > 100):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Percentage must be between 0 and 100"
        )

    feature_flags.set_flag(
        name=flag_name,
        enabled=enabled,
        percentage=percentage,
        tokens=tokens,
        expires_in_seconds=expires_in_seconds
    )

    logger.info(f"Feature flag '{flag_name}' updated")

    return {
        "status": "updated",
        "flag": flag_name,
        "current_state": feature_flags.get_all_flags().get(flag_name)
    }


@app.delete("/flags/{flag_name}")
async def delete_flag(flag_name: str, auth: str = Depends(verify_auth)):
    """Delete a feature flag."""
    deleted = feature_flags.delete_flag(flag_name)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Flag '{flag_name}' not found"
        )

    logger.info(f"Feature flag '{flag_name}' deleted")

    return {"status": "deleted", "flag": flag_name}


# ═══════════════════════════════════════════════════════════════════════════════
# Request Sampling Endpoints - Debug production issues
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/samples")
async def get_request_samples(
    limit: int = 50,
    errors_only: bool = False,
    slow_only: bool = False,
    path: Optional[str] = None,
    auth: str = Depends(verify_auth)
):
    """
    Get sampled requests for debugging.

    Args:
        limit: Maximum number of samples to return (default 50, max 500)
        errors_only: Only return samples with errors
        slow_only: Only return slow requests (>500ms)
        path: Filter by path substring
    """
    limit = min(limit, 500)

    samples = request_sampler.get_samples(
        limit=limit,
        filter_errors=errors_only,
        filter_slow=slow_only,
        path_filter=path
    )

    return {
        "count": len(samples),
        "filters": {
            "errors_only": errors_only,
            "slow_only": slow_only,
            "path": path
        },
        "samples": samples
    }


@app.get("/samples/stats")
async def get_sampler_stats():
    """Get request sampler statistics."""
    return request_sampler.get_stats()


@app.post("/samples/config")
async def configure_sampler(
    sample_rate: Optional[float] = None,
    slow_threshold_ms: Optional[float] = None,
    auth: str = Depends(verify_auth)
):
    """
    Configure request sampler.

    Args:
        sample_rate: Sample rate (0.0-1.0, default 0.01 = 1%)
        slow_threshold_ms: Threshold for slow request sampling
    """
    if sample_rate is not None:
        if sample_rate < 0 or sample_rate > 1:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="sample_rate must be between 0.0 and 1.0"
            )
        request_sampler.sample_rate = sample_rate

    if slow_threshold_ms is not None:
        if slow_threshold_ms < 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="slow_threshold_ms must be positive"
            )
        request_sampler.slow_threshold_ms = slow_threshold_ms

    return {
        "status": "updated",
        "config": request_sampler.get_stats()
    }


@app.delete("/samples")
async def clear_samples(auth: str = Depends(verify_auth)):
    """Clear all sampled requests."""
    request_sampler.clear()
    return {"status": "cleared", "message": "All samples cleared"}


# ═══════════════════════════════════════════════════════════════════════════════
# Health Trends Endpoints - Historical health metrics
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/health/trends")
async def get_health_trends(hours: int = 1):
    """
    Get health metrics trends over time.

    Args:
        hours: Number of hours to look back (1-24, default 1)
    """
    hours = max(1, min(hours, 24))
    return health_trends.get_trends(hours)


@app.get("/health/trends/data")
async def get_health_trends_data(hours: int = 1, auth: str = Depends(verify_auth)):
    """
    Get raw health trend data for graphing.

    Args:
        hours: Number of hours to look back (1-24, default 1)

    Returns array of snapshots suitable for charting.
    """
    hours = max(1, min(hours, 24))
    data = health_trends.get_raw_data(hours)

    return {
        "period_hours": hours,
        "snapshots": len(data),
        "data": data
    }


@app.get("/symbols")
async def get_symbol_families():
    """Get information about emergent language symbol families."""
    return {
        "families": {
            "system": {"range": "0x00-0x0F", "glyph": "∅", "purpose": "Protocol management"},
            "nous": {"range": "0x10-0x1F", "glyph": "⊕", "purpose": "External value verification"},
            "ergon": {"range": "0x20-0x2F", "glyph": "◊", "purpose": "Token transfers"},
            "work": {"range": "0x30-0x3F", "glyph": "⚒", "purpose": "Task lifecycle"},
            "swarm": {"range": "0x40-0x4F", "glyph": "⬡", "purpose": "Multi-agent coordination"},
            "identity": {"range": "0x50-0x5F", "glyph": "◎", "purpose": "Attestation"},
            "governance": {"range": "0x60-0x6F", "glyph": "⚖", "purpose": "Proposals and voting"},
            "authority": {"range": "0x70-0x7F", "glyph": "⚖⊛", "purpose": "Orders and enforcement"},
            "theta": {"range": "0x80-0x9F", "glyph": "θ", "purpose": "Resource accounting"},
            "hivemind": {"range": "0xA0-0xBF", "glyph": "⌘", "purpose": "P2P networking"},
            "ingest": {"range": "0xC0-0xCF", "glyph": "╳", "purpose": "External → emergent"},
            "emit": {"range": "0xD0-0xDF", "glyph": "╋", "purpose": "Emergent → external"},
            "transform": {"range": "0xE0-0xE7", "glyph": "⊞", "purpose": "Format conversion"},
            "oracle": {"range": "0xE8-0xEF", "glyph": "⊡", "purpose": "Human translation layer"}
        }
    }


# =============================================================================
# GPU BATCH ENCODING ENDPOINTS
# =============================================================================

# Import GPU batch encoder (lazy loading)
_gpu_encoder = None
_gpu_encoder_lock = threading.Lock()


def get_gpu_encoder():
    """Get or create the global GPU batch encoder."""
    global _gpu_encoder
    if _gpu_encoder is None:
        with _gpu_encoder_lock:
            if _gpu_encoder is None:
                from .gpu_batch_encoder import GPUBatchEncoder
                _gpu_encoder = GPUBatchEncoder(num_workers=8)
    return _gpu_encoder


# Rust encoder (6x faster when available)
_rust_encoder_available = None

def is_rust_encoder_available():
    """Check if Rust encoder is available."""
    global _rust_encoder_available
    if _rust_encoder_available is None:
        try:
            import emergent_encoder
            _rust_encoder_available = True
        except ImportError:
            _rust_encoder_available = False
    return _rust_encoder_available


def encode_with_rust(messages):
    """Encode messages using Rust encoder (6x faster)."""
    import emergent_encoder
    return emergent_encoder.encode_batch(messages)


_batch_encoder = None
_batch_encoder_lock = threading.Lock()


def get_batch_encoder():
    """Get or create the global BatchEncoder (v1)."""
    global _batch_encoder
    if _batch_encoder is None:
        with _batch_encoder_lock:
            if _batch_encoder is None:
                from .batch_encoder import BatchEncoder
                _batch_encoder = BatchEncoder()
    return _batch_encoder


_pipeline = None
_pipeline_lock = threading.Lock()


def get_pipeline():
    """Get or create the global LocalPipeline (v2 GPU encoder + adaptive codebook)."""
    global _pipeline
    if _pipeline is None:
        with _pipeline_lock:
            if _pipeline is None:
                from .local_pipeline import LocalPipeline
                codebook_path = os.environ.get("PIPELINE_CODEBOOK_PATH")
                _pipeline = LocalPipeline(
                    adaptive=bool(codebook_path),
                    codebook_path=codebook_path,
                )
    return _pipeline


_chunk_compressor = None
_chunk_compressor_lock = threading.Lock()


def get_chunk_compressor():
    """Get or create the global GPUChunkCompressor."""
    global _chunk_compressor
    if _chunk_compressor is None:
        with _chunk_compressor_lock:
            if _chunk_compressor is None:
                from .gpu_batch_encoder import GPUChunkCompressor
                _chunk_compressor = GPUChunkCompressor(encoder=get_gpu_encoder())
    return _chunk_compressor


class GPUBatchRequest(BaseModel):
    """Request model for GPU batch encoding."""
    messages: List[Dict[str, Any]] = Field(..., description="List of messages to encode")

    @field_validator('messages')
    @classmethod
    def validate_messages(cls, v):
        if len(v) > 1000:
            raise ValueError('Maximum 1000 messages per batch')
        if len(v) == 0:
            raise ValueError('At least 1 message required')
        return v

    model_config = {
        "json_schema_extra": {
            "example": {
                "messages": [
                    {"task": "analyze", "data": "market trends", "priority": "high"},
                    {"agent_id": "agent_001", "status": "running"}
                ]
            }
        }
    }


class BatchProfileData(BaseModel):
    """Detailed profiling breakdown for batch operations."""
    # Time breakdown (all in ms)
    total_time_ms: float = 0.0
    encode_time_ms: float = 0.0
    compress_time_ms: float = 0.0
    transfer_time_ms: float = 0.0

    # Size breakdown
    individual_bytes: int = 0
    batch_advantage_pct: float = 0.0

    # Resource utilization (percentage)
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    memory_mb: float = 0.0

    # Processing info
    threads_used: int = 0
    gpu_name: Optional[str] = None


class GPUBatchResponse(BaseModel):
    """Response model for GPU batch encoding."""
    success: bool
    message_count: int
    original_bytes: int
    compressed_bytes: int
    compression_ratio: float
    efficiency_gain: float
    encoding_time_ms: float
    throughput_msg_per_sec: float
    gpu_accelerated: bool
    payload: Optional[str] = None  # Base64 encoded batch payload
    errors: List[str] = Field(default_factory=list)

    # Optional profiling data (included when ?profile=true)
    profile: Optional[BatchProfileData] = None


class ChunkBatchCompressRequest(BaseModel):
    """Request model for batch chunk compression via GPUChunkCompressor."""
    chunks: List[Dict[str, Any]] = Field(..., min_length=1, max_length=100)


class CompressedChunkResult(BaseModel):
    """Single compressed chunk result."""
    chunk_index: int
    payload: str  # base64
    original_chunk: Dict[str, Any]


class ChunkBatchCompressResponse(BaseModel):
    """Response model for batch chunk compression."""
    success: bool
    chunk_count: int
    compressed_chunks: List[CompressedChunkResult]
    total_original_bytes: int
    total_compressed_bytes: int
    compression_time_ms: float
    gpu_accelerated: bool
    errors: List[str] = Field(default_factory=list)


class GPUStreamRequest(BaseModel):
    """Request model for GPU streaming encode."""
    messages: List[Dict[str, Any]] = Field(...)
    batch_size: int = Field(default=75, ge=1, le=500)

    @field_validator('messages')
    @classmethod
    def validate_messages(cls, v):
        if len(v) > 2000:
            raise ValueError('Maximum 2000 messages per streaming request')
        if not v:
            raise ValueError('At least 1 message required')
        return v


@app.post("/translate/gpu-batch", response_model=GPUBatchResponse)
async def translate_gpu_batch(
    request: GPUBatchRequest,
    profile: bool = False,
    auth: str = Depends(verify_auth)
) -> GPUBatchResponse:
    """
    GPU-accelerated batch encoding for maximum throughput.

    Encodes up to 1000 messages in a single batch using parallel processing.
    Achieves 49,000+ msg/s with 93%+ compression.

    Optimal batch size is 75 messages for best cache alignment.

    Query params:
        profile: bool - Include detailed CPU/GPU profiling data in response
    """
    start_time = time.time()

    # Capture pre-encoding CPU/memory stats if profiling
    cpu_before = None
    if profile:
        try:
            import psutil
            proc = psutil.Process()
            cpu_before = proc.cpu_percent()  # Initialize CPU measurement
        except ImportError:
            pass

    try:
        encoder = get_gpu_encoder()
        result = encoder.encode_batch(request.messages)

        encoding_time_ms = (time.time() - start_time) * 1000
        throughput = len(request.messages) / (encoding_time_ms / 1000) if encoding_time_ms > 0 else 0

        # Record metrics
        get_metrics().record_request(
            latency_ms=encoding_time_ms,
            success=True,
            original_size=result.original_bytes,
            compressed_size=result.compressed_bytes,
            compression_ratio=result.compression_ratio,
            endpoint="/translate/gpu-batch"
        )

        # Update server stats
        server.request_count += len(request.messages)
        server.total_data_processed += result.original_bytes
        server.total_compression_savings += (result.original_bytes - result.compressed_bytes)

        # Build profiling data if requested
        profile_data = None
        if profile:
            try:
                import psutil
                proc = psutil.Process()
                mem_info = proc.memory_info()
                sys_mem = psutil.virtual_memory()

                # Get GPU name if available
                gpu_name = None
                if result.gpu_accelerated:
                    try:
                        import cupy as cp
                        gpu_name = cp.cuda.Device().name
                    except Exception:
                        gpu_name = "GPU (CuPy)"

                profile_data = BatchProfileData(
                    total_time_ms=result.encode_time_ms,
                    encode_time_ms=result.encode_time_gpu_ms,
                    compress_time_ms=result.compress_time_ms,
                    transfer_time_ms=result.transfer_time_ms,
                    individual_bytes=result.individual_bytes,
                    batch_advantage_pct=result.batch_advantage_pct,
                    cpu_percent=proc.cpu_percent(),
                    memory_percent=sys_mem.percent,
                    memory_mb=mem_info.rss / (1024 * 1024),
                    threads_used=encoder._max_workers if hasattr(encoder, '_max_workers') else 4,
                    gpu_name=gpu_name
                )
            except ImportError:
                profile_data = BatchProfileData(
                    total_time_ms=result.encode_time_ms,
                    encode_time_ms=result.encode_time_gpu_ms,
                    compress_time_ms=result.compress_time_ms,
                )

        return GPUBatchResponse(
            success=True,
            message_count=result.messages_encoded,
            original_bytes=result.original_bytes,
            compressed_bytes=result.compressed_bytes,
            compression_ratio=result.compression_ratio,
            efficiency_gain=(1 - result.compression_ratio) * 100,
            encoding_time_ms=result.encode_time_ms,
            throughput_msg_per_sec=throughput,
            gpu_accelerated=result.gpu_accelerated,
            payload=base64.b64encode(result.payload).decode('utf-8'),
            errors=[],
            profile=profile_data
        )

    except Exception as e:
        logger.error(f"GPU batch encoding error: {e}")
        get_metrics().record_request(
            latency_ms=(time.time() - start_time) * 1000,
            success=False,
            endpoint="/translate/gpu-batch",
            error=str(e)[:50]
        )
        return GPUBatchResponse(
            success=False,
            message_count=0,
            original_bytes=0,
            compressed_bytes=0,
            compression_ratio=0,
            efficiency_gain=0,
            encoding_time_ms=(time.time() - start_time) * 1000,
            throughput_msg_per_sec=0,
            gpu_accelerated=False,
            errors=[str(e)]
        )


@app.post("/translate/gpu-batch/decode")
async def decode_gpu_batch(
    payload_b64: str = Form(...),
    auth: str = Depends(verify_auth)
) -> Dict[str, Any]:
    """
    Decode a GPU batch encoded payload back to messages.
    """
    try:
        payload = base64.b64decode(payload_b64)
        encoder = get_gpu_encoder()
        # Run decompression + parsing off the event loop
        messages = await run_translate(encoder.decode_batch, payload)

        return {
            "success": True,
            "message_count": len(messages),
            "messages": messages
        }
    except Exception as e:
        logger.error(f"GPU batch decode error: {e}")
        return {
            "success": False,
            "error": str(e),
            "messages": []
        }


@app.post("/compress/batch", response_model=ChunkBatchCompressResponse)
async def compress_chunk_batch(
    request: ChunkBatchCompressRequest,
    auth: str = Depends(verify_auth),
) -> ChunkBatchCompressResponse:
    """
    Batch-compress multiple chunks using GPUChunkCompressor.

    Accepts up to 100 chunks and returns each as a base64-encoded compressed payload.
    Uses GPU acceleration when available.
    """
    start_time = time.time()
    try:
        compressor = get_chunk_compressor()
        results = await compressor.compress_batch(request.chunks)

        compressed_chunks = []
        total_original = 0
        total_compressed = 0

        for i, (original_chunk, payload_bytes, _metadata) in enumerate(results):
            b64 = base64.b64encode(payload_bytes).decode('utf-8')
            original_size = len(json.dumps(original_chunk).encode('utf-8'))
            total_original += original_size
            total_compressed += len(payload_bytes)
            compressed_chunks.append(CompressedChunkResult(
                chunk_index=i,
                payload=b64,
                original_chunk=original_chunk,
            ))

        compression_time_ms = (time.time() - start_time) * 1000
        encoder = get_gpu_encoder()

        get_metrics().record_request(
            latency_ms=compression_time_ms,
            success=True,
            original_size=total_original,
            compressed_size=total_compressed,
            compression_ratio=total_compressed / total_original if total_original > 0 else 0,
            endpoint="/compress/batch",
        )
        server.request_count += len(request.chunks)
        server.total_data_processed += total_original
        server.total_compression_savings += (total_original - total_compressed)

        return ChunkBatchCompressResponse(
            success=True,
            chunk_count=len(compressed_chunks),
            compressed_chunks=compressed_chunks,
            total_original_bytes=total_original,
            total_compressed_bytes=total_compressed,
            compression_time_ms=compression_time_ms,
            gpu_accelerated=encoder.use_gpu,
        )
    except Exception as e:
        logger.error(f"Chunk batch compress error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Chunk batch compress error: {str(e)}",
        )


@app.post("/translate/gpu-stream")
async def translate_gpu_stream(
    request: GPUStreamRequest,
    auth: str = Depends(verify_auth),
):
    """
    GPU-accelerated streaming encode.

    Streams results as NDJSON — one line per batch of messages.
    Each line contains batch_number, message_count, payload (base64), and stats.
    """
    start_time = time.time()
    encoder = get_gpu_encoder()

    async def stream_generator():
        total_original = 0
        total_compressed = 0
        total_messages = 0

        for batch_number, result in enumerate(
            encoder.encode_stream(iter(request.messages), batch_size=request.batch_size)
        ):
            total_original += result.original_bytes
            total_compressed += result.compressed_bytes
            total_messages += result.messages_encoded

            line = json.dumps({
                "batch_number": batch_number,
                "message_count": result.messages_encoded,
                "payload": base64.b64encode(result.payload).decode('utf-8'),
                "original_bytes": result.original_bytes,
                "compressed_bytes": result.compressed_bytes,
                "compression_ratio": result.compression_ratio,
                "bandwidth_saved_pct": result.bandwidth_saved_pct,
                "gpu_accelerated": result.gpu_accelerated,
                "encode_time_ms": result.encode_time_ms,
            })
            yield line + "\n"
            await asyncio.sleep(0)

        # Record aggregate metrics
        elapsed_ms = (time.time() - start_time) * 1000
        get_metrics().record_request(
            latency_ms=elapsed_ms,
            success=True,
            original_size=total_original,
            compressed_size=total_compressed,
            compression_ratio=total_compressed / total_original if total_original > 0 else 0,
            endpoint="/translate/gpu-stream",
        )
        server.request_count += total_messages
        server.total_data_processed += total_original
        server.total_compression_savings += (total_original - total_compressed)

    return StreamingResponse(stream_generator(), media_type="application/x-ndjson")


@app.post("/translate/rust-batch")
async def translate_rust_batch(
    request: GPUBatchRequest,
    auth: str = Depends(verify_auth)
) -> Dict[str, Any]:
    """
    High-performance batch encoding using Rust (6x faster than Python).

    Uses the native Rust encoder when available, falling back to Python.
    Optimal for maximum throughput scenarios.
    """
    start_time = time.time()

    if not is_rust_encoder_available():
        # Fall back to GPU/Python encoder (also off event loop)
        encoder = get_gpu_encoder()
        result = await run_translate(encoder.encode_batch, request.messages)
        encoding_time_ms = (time.time() - start_time) * 1000
        throughput = len(request.messages) / (encoding_time_ms / 1000) if encoding_time_ms > 0 else 0

        return {
            "success": True,
            "encoder": "python",
            "message_count": result.messages_encoded,
            "original_bytes": result.original_bytes,
            "compressed_bytes": result.compressed_bytes,
            "compression_ratio": result.compression_ratio,
            "bandwidth_saved_pct": result.bandwidth_saved_pct,
            "encoding_time_ms": result.encode_time_ms,
            "throughput_msg_per_sec": throughput,
            "payload": base64.b64encode(result.payload).decode('utf-8'),
        }

    try:
        # Run Rust encoder off the event loop to prevent starvation at high concurrency
        result = await run_translate(encode_with_rust, request.messages)
        encoding_time_ms = (time.time() - start_time) * 1000
        throughput = result.messages_encoded / (result.total_time_ms / 1000) if result.total_time_ms > 0 else 0

        # Record metrics
        get_metrics().record_request(
            latency_ms=encoding_time_ms,
            success=True,
            original_size=result.original_bytes,
            compressed_size=result.compressed_bytes,
            compression_ratio=result.compression_ratio,
            endpoint="/translate/rust-batch"
        )

        # Update server stats
        server.request_count += result.messages_encoded
        server.total_data_processed += result.original_bytes
        server.total_compression_savings += (result.original_bytes - result.compressed_bytes)

        return {
            "success": True,
            "encoder": "rust",
            "message_count": result.messages_encoded,
            "original_bytes": result.original_bytes,
            "compressed_bytes": result.compressed_bytes,
            "compression_ratio": result.compression_ratio,
            "bandwidth_saved_pct": result.bandwidth_saved_pct,
            "encoding_time_ms": result.total_time_ms,
            "encode_phase_ms": result.encode_time_ms,
            "compress_phase_ms": result.compress_time_ms,
            "throughput_msg_per_sec": throughput,
            "payload": base64.b64encode(bytes(result.payload)).decode('utf-8'),
        }

    except Exception as e:
        logger.error(f"Rust batch encoding error: {e}")
        return {
            "success": False,
            "encoder": "rust",
            "error": str(e),
        }


@app.get("/batch/profile")
async def get_batch_profile(
    auth: str = Depends(verify_auth)
) -> Dict[str, Any]:
    """
    Get current batch processing profile and resource utilization.

    Returns detailed CPU, memory, and encoder statistics for monitoring
    where processing resources are being used.
    """
    try:
        import psutil
        proc = psutil.Process()
        sys_mem = psutil.virtual_memory()
        cpu_count = psutil.cpu_count()
        cpu_percent_per_core = psutil.cpu_percent(percpu=True)

        # Get encoder stats
        encoder = get_gpu_encoder()
        encoder_stats = {
            "total_encoded": encoder.total_encoded,
            "total_time_ms": encoder.total_time_ms,
            "avg_time_per_batch_ms": encoder.total_time_ms / max(encoder.total_encoded, 1) * 75,  # Assuming batch-75
            "throughput_lifetime_msg_per_sec": (encoder.total_encoded / (encoder.total_time_ms / 1000)) if encoder.total_time_ms > 0 else 0,
            "use_gpu": encoder.use_gpu,
            "max_workers": encoder._max_workers if hasattr(encoder, '_max_workers') else 4,
            "compression_level": encoder.compression_level,
        }

        # GPU info if available
        gpu_info = None
        if encoder.use_gpu:
            try:
                import cupy as cp
                device = cp.cuda.Device()
                mem_info = device.mem_info
                gpu_info = {
                    "name": device.name,
                    "memory_total_mb": mem_info[1] / (1024 * 1024),
                    "memory_free_mb": mem_info[0] / (1024 * 1024),
                    "memory_used_mb": (mem_info[1] - mem_info[0]) / (1024 * 1024),
                }
            except Exception as e:
                gpu_info = {"error": str(e)}

        # Rust encoder info
        rust_info = {
            "available": is_rust_encoder_available(),
            "speedup": "6x" if is_rust_encoder_available() else "N/A",
        }

        return {
            "cpu": {
                "count": cpu_count,
                "percent_total": sum(cpu_percent_per_core) / len(cpu_percent_per_core) if cpu_percent_per_core else 0,
                "percent_per_core": cpu_percent_per_core,
                "process_percent": proc.cpu_percent(),
            },
            "memory": {
                "system_percent": sys_mem.percent,
                "system_available_mb": sys_mem.available / (1024 * 1024),
                "system_total_mb": sys_mem.total / (1024 * 1024),
                "process_rss_mb": proc.memory_info().rss / (1024 * 1024),
                "process_percent": proc.memory_percent(),
            },
            "encoder": encoder_stats,
            "rust": rust_info,
            "gpu": gpu_info,
            "threads": {
                "active": threading.active_count(),
                "main_thread": threading.main_thread().name,
            }
        }
    except ImportError:
        return {
            "error": "psutil not available",
            "encoder": {
                "total_encoded": get_gpu_encoder().total_encoded,
                "total_time_ms": get_gpu_encoder().total_time_ms,
            }
        }


@app.post("/batch/benchmark")
async def run_batch_benchmark(
    batch_size: int = 75,
    num_batches: int = 10,
    auth: str = Depends(verify_auth)
) -> Dict[str, Any]:
    """
    Run a quick benchmark to measure batch processing performance.

    Generates test messages and measures encoding throughput with detailed
    timing breakdown.

    Args:
        batch_size: Messages per batch (default 75)
        num_batches: Number of batches to process (default 10)
    """
    import random

    # Sample messages for benchmarking
    sample_messages = [
        {"task": "analyze", "data": "market", "priority": "high", "agent_id": "agent_001"},
        {"task_type": "execution", "context": {"market": "volatile", "risk": "moderate"}},
        {"coordination": {"participants": ["agent_1", "agent_2"], "consensus": "required"}},
        {"metrics": {"confidence": 0.95, "sentiment": "bullish", "recommendations": ["buy", "hold"]}},
    ]

    encoder = get_gpu_encoder()
    results = []

    # Capture initial CPU
    try:
        import psutil
        proc = psutil.Process()
        cpu_start = proc.cpu_percent()
    except ImportError:
        proc = None

    total_start = time.time()

    for i in range(num_batches):
        messages = [random.choice(sample_messages) for _ in range(batch_size)]
        result = encoder.encode_batch(messages)
        results.append({
            "batch": i + 1,
            "messages": result.messages_encoded,
            "total_ms": result.encode_time_ms,
            "encode_ms": result.encode_time_gpu_ms,
            "compress_ms": result.compress_time_ms,
            "throughput": result.throughput_msg_per_sec,
            "compression_pct": result.bandwidth_saved_pct,
        })

    total_time = (time.time() - total_start) * 1000
    total_messages = sum(r["messages"] for r in results)

    # Aggregate stats
    encode_times = [r["encode_ms"] for r in results]
    compress_times = [r["compress_ms"] for r in results]
    throughputs = [r["throughput"] for r in results]

    summary = {
        "config": {
            "batch_size": batch_size,
            "num_batches": num_batches,
            "total_messages": total_messages,
        },
        "timing": {
            "total_ms": total_time,
            "avg_batch_ms": total_time / num_batches,
            "encode_avg_ms": sum(encode_times) / len(encode_times),
            "encode_min_ms": min(encode_times),
            "encode_max_ms": max(encode_times),
            "compress_avg_ms": sum(compress_times) / len(compress_times),
        },
        "throughput": {
            "overall_msg_per_sec": (total_messages / total_time) * 1000,
            "avg_msg_per_sec": sum(throughputs) / len(throughputs),
            "min_msg_per_sec": min(throughputs),
            "max_msg_per_sec": max(throughputs),
        },
        "compression": {
            "avg_pct": sum(r["compression_pct"] for r in results) / len(results),
        },
        "resource_usage": {},
        "batches": results,
    }

    # Add CPU usage if available
    if proc:
        summary["resource_usage"]["cpu_percent"] = proc.cpu_percent()
        summary["resource_usage"]["memory_mb"] = proc.memory_info().rss / (1024 * 1024)

    return summary


# =============================================================================
# DISTRIBUTED PROCESSING ENDPOINTS
# =============================================================================

# Import chunk coordinator (lazy to avoid circular imports)
_coordinator = None

def get_coordinator():
    """Get or create the global chunk coordinator."""
    global _coordinator
    if _coordinator is None:
        from .chunk_coordinator import ChunkCoordinator
        import os
        # Default to self as worker, can be configured via env
        workers_env = os.getenv("DISTRIBUTED_WORKERS", "")
        if workers_env:
            workers = [w.strip() for w in workers_env.split(",")]
        else:
            # Self-reference for single-node testing
            host = os.getenv("TRANSLATOR_HOST", "localhost")
            port = os.getenv("TRANSLATOR_PORT", "8000")
            workers = [f"http://{host}:{port}"]

        _coordinator = ChunkCoordinator(
            workers=workers,
            chunk_size_mb=int(os.getenv("CHUNK_SIZE_MB", "100")),
            max_concurrent=int(os.getenv("MAX_CONCURRENT_CHUNKS", "50"))
        )
    return _coordinator


class ChunkProcessRequest(BaseModel):
    """Request model for chunk processing."""
    chunk_id: str = Field(..., description="Unique chunk identifier")
    operation: str = Field(..., description="Operation to perform")
    data: str = Field(..., description="Base64 encoded θ-compressed data")
    params: Dict[str, Any] = Field(default_factory=dict, description="Operation parameters")


class ChunkProcessResponse(BaseModel):
    """Response model for chunk processing."""
    success: bool
    chunk_id: str
    result: Optional[str] = None  # Base64 encoded result
    error: Optional[str] = None
    processing_time_ms: float = 0.0


class DistributedJobRequest(BaseModel):
    """Request model for distributed job submission."""
    operation: str = Field(..., description="Operation to perform on all chunks")
    data: str = Field(..., description="Base64 encoded data to process")
    chunk_size_mb: int = Field(default=100, description="Chunk size in MB")
    params: Dict[str, Any] = Field(default_factory=dict, description="Operation parameters")


class DistributedJobResponse(BaseModel):
    """Response model for distributed job submission."""
    success: bool
    job_id: str
    status: str
    total_chunks: int
    total_bytes: int
    message: str


@app.post("/process", response_model=ChunkProcessResponse)
async def process_chunk(request: ChunkProcessRequest) -> ChunkProcessResponse:
    """
    Process a single chunk of distributed data.

    This endpoint is called by the coordinator to process individual chunks
    on worker instances. The data is θ-compressed and should be processed
    and returned in the same format.

    Supported operations:
    - passthrough: Return data unchanged (for testing)
    - transform: Apply transformation (specify in params)
    - analyze: Extract analysis results
    - aggregate: Aggregate values
    """
    start_time = time.time()

    try:
        # Decode the compressed chunk data
        compressed_data = base64.b64decode(request.data)

        # Get translator for decompression
        translator = server.get_translator(epoch=0, enable_validation=True)

        # Decompress to work with raw data (offloaded to thread pool)
        decompress_result = await run_translate(translator.emergent_to_json, compressed_data)

        if not decompress_result.success:
            return ChunkProcessResponse(
                success=False,
                chunk_id=request.chunk_id,
                error=f"Decompression failed: {decompress_result.errors}",
                processing_time_ms=(time.time() - start_time) * 1000
            )

        # Get the decompressed data
        raw_data = decompress_result.translated_data
        if isinstance(raw_data, bytes):
            raw_data = raw_data.decode('utf-8', errors='replace')

        # Process based on operation
        if request.operation == "passthrough":
            # Just return the data as-is
            result_data = raw_data

        elif request.operation == "transform":
            # Apply transformation from params
            transform_type = request.params.get("transform", "uppercase")
            if transform_type == "uppercase":
                result_data = raw_data.upper() if isinstance(raw_data, str) else raw_data
            elif transform_type == "lowercase":
                result_data = raw_data.lower() if isinstance(raw_data, str) else raw_data
            elif transform_type == "reverse":
                result_data = raw_data[::-1] if isinstance(raw_data, str) else raw_data
            else:
                result_data = raw_data

        elif request.operation == "analyze":
            # Return analysis of the chunk
            if isinstance(raw_data, str):
                result_data = json.dumps({
                    "chunk_id": request.chunk_id,
                    "length": len(raw_data),
                    "lines": raw_data.count('\n') + 1,
                    "words": len(raw_data.split()),
                    "unique_chars": len(set(raw_data))
                })
            else:
                result_data = json.dumps({
                    "chunk_id": request.chunk_id,
                    "type": str(type(raw_data)),
                    "size": len(str(raw_data))
                })

        elif request.operation == "aggregate":
            # Extract numeric values and sum them
            import re
            numbers = re.findall(r'-?\d+\.?\d*', str(raw_data))
            total = sum(float(n) for n in numbers) if numbers else 0
            result_data = json.dumps({
                "chunk_id": request.chunk_id,
                "sum": total,
                "count": len(numbers)
            })

        else:
            # Unknown operation - passthrough
            result_data = raw_data

        # Re-compress the result (offloaded to thread pool)
        if isinstance(result_data, str):
            compress_result = await run_translate(translator.text_to_emergent, result_data)
        else:
            compress_result = await run_translate(translator.json_to_emergent, result_data)

        if not compress_result.success:
            return ChunkProcessResponse(
                success=False,
                chunk_id=request.chunk_id,
                error=f"Result compression failed: {compress_result.errors}",
                processing_time_ms=(time.time() - start_time) * 1000
            )

        # Encode result
        result_b64 = base64.b64encode(compress_result.translated_data).decode('utf-8')

        processing_time_ms = (time.time() - start_time) * 1000

        # Record metrics
        get_metrics().record_request(
            latency_ms=processing_time_ms,
            success=True,
            endpoint="/process"
        )

        return ChunkProcessResponse(
            success=True,
            chunk_id=request.chunk_id,
            result=result_b64,
            processing_time_ms=processing_time_ms
        )

    except Exception as e:
        logger.error(f"Chunk processing error: {e}")
        return ChunkProcessResponse(
            success=False,
            chunk_id=request.chunk_id,
            error=str(e)[:200],
            processing_time_ms=(time.time() - start_time) * 1000
        )


@app.post("/distributed/submit", response_model=DistributedJobResponse)
async def submit_distributed_job(
    request: DistributedJobRequest,
    auth: str = Depends(verify_auth)
) -> DistributedJobResponse:
    """
    Submit a distributed processing job.

    The data will be:
    1. Split into chunks (based on chunk_size_mb)
    2. Each chunk θ-compressed (87% bandwidth reduction)
    3. Distributed across worker instances
    4. Processed in parallel
    5. Results reassembled

    Returns immediately with job_id for status polling.
    """
    try:
        # Decode the input data
        data = base64.b64decode(request.data)

        coordinator = get_coordinator()

        # Override chunk size if specified
        if request.chunk_size_mb != 100:
            coordinator.chunk_size_bytes = int(request.chunk_size_mb * 1024 * 1024)

        # Submit the job
        job = await coordinator.submit(
            data=data,
            operation=request.operation,
            operation_params=request.params
        )

        return DistributedJobResponse(
            success=True,
            job_id=job.id,
            status=job.status.value,
            total_chunks=job.stats.total_chunks,
            total_bytes=job.stats.total_bytes_raw,
            message=f"Job submitted with {job.stats.total_chunks} chunks"
        )

    except Exception as e:
        logger.error(f"Distributed job submission error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Job submission failed: {str(e)}"
        )


@app.get("/distributed/status/{job_id}")
async def get_distributed_job_status(
    job_id: str,
    auth: str = Depends(verify_auth)
) -> Dict[str, Any]:
    """
    Get the status of a distributed job.

    Returns detailed status including:
    - Overall job status
    - Chunk completion progress
    - Compression statistics
    - Timing and throughput metrics
    """
    coordinator = get_coordinator()
    status_info = coordinator.get_job_status(job_id)

    if "error" in status_info:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=status_info["error"]
        )

    return status_info


@app.get("/distributed/result/{job_id}")
async def get_distributed_job_result(
    job_id: str,
    auth: str = Depends(verify_auth)
) -> Dict[str, Any]:
    """
    Get the result of a completed distributed job.

    Returns the reassembled result data (base64 encoded).
    Only available after job reaches COMPLETED status.
    """
    coordinator = get_coordinator()
    job = coordinator.get_job(job_id)

    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Job {job_id} not found"
        )

    if job.status.value not in ("completed", "failed"):
        return {
            "ready": False,
            "status": job.status.value,
            "message": "Job still processing"
        }

    return {
        "ready": True,
        "status": job.status.value,
        "result": base64.b64encode(job.result).decode('utf-8') if job.result else None,
        "result_size": len(job.result) if job.result else 0,
        "stats": {
            "total_chunks": job.stats.total_chunks,
            "completed_chunks": job.stats.completed_chunks,
            "failed_chunks": job.stats.failed_chunks,
            "compression_ratio": f"{job.stats.compression_ratio:.2%}",
            "bandwidth_saved": f"{job.stats.bandwidth_savings_percent:.1f}%",
            "throughput_mbps": round(job.stats.throughput_mbps, 2),
            "duration_seconds": round(job.stats.duration_seconds, 2)
        },
        "errors": job.errors
    }


@app.get("/distributed/jobs")
async def list_distributed_jobs(
    auth: str = Depends(verify_auth)
) -> Dict[str, Any]:
    """List all distributed jobs."""
    coordinator = get_coordinator()
    return {
        "jobs": coordinator.list_jobs(),
        "worker_stats": coordinator.worker_pool.get_stats()
    }


# =============================================================================


def create_translator_app(**kwargs) -> FastAPI:
    """Factory function to create translator app with custom configuration."""
    global server
    server = EmergentTranslatorServer(**kwargs)
    return app


if __name__ == "__main__":
    # Run server directly
    uvicorn.run(
        "eudaimonia.translator.api_server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )