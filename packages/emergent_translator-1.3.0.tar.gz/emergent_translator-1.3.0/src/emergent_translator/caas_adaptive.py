"""
Compression-as-a-Service: Adaptive Learning Loop

Learns optimal compression levels per (strategy, content_type) pair from
downstream quality signals. Uses UCB scoring for exploration/exploitation
and versioned policy snapshots.

Classes:
    CompressionOutcome — immutable record of a compression + optional quality feedback
    StrategyPerformance — mutable stats per (strategy, content_type, level) triple
    AdaptivePolicy — immutable snapshot of recommended level for a (strategy, content_type)
    AdaptiveLearner — orchestrates recording, feedback, recommendation, and persistence
"""

from __future__ import annotations

import dataclasses
import json
import math
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .caas_strategies import CompressionLevel


# ---------------------------------------------------------------------------
# 1. CompressionOutcome
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CompressionOutcome:
    """Immutable record of a single compression operation."""
    request_id: str
    strategy: str
    content_type: str
    level: CompressionLevel
    original_tokens: int
    compressed_tokens: int
    compression_ratio: float
    token_reduction_pct: float
    timestamp: float
    quality_score: Optional[float] = None


# ---------------------------------------------------------------------------
# 2. StrategyPerformance
# ---------------------------------------------------------------------------

@dataclass
class StrategyPerformance:
    """Mutable stats for a (strategy, content_type, level) triple."""
    observation_count: int = 0
    total_quality: float = 0.0
    total_compression: float = 0.0
    total_reduction: float = 0.0
    consecutive_low_quality: int = 0
    best_quality: float = 0.0
    worst_quality: float = 1.0

    def record(self, outcome: CompressionOutcome) -> None:
        """Accumulate stats from a completed outcome (must have quality_score)."""
        assert outcome.quality_score is not None
        q = outcome.quality_score
        self.observation_count += 1
        self.total_quality += q
        self.total_compression += outcome.compression_ratio
        self.total_reduction += outcome.token_reduction_pct

        if q > self.best_quality:
            self.best_quality = q
        if q < self.worst_quality:
            self.worst_quality = q

        if q < 0.5:
            self.consecutive_low_quality += 1
        else:
            self.consecutive_low_quality = 0

    def avg_quality(self) -> float:
        if self.observation_count == 0:
            return 0.0
        return self.total_quality / self.observation_count

    def avg_compression(self) -> float:
        if self.observation_count == 0:
            return 0.0
        return self.total_compression / self.observation_count

    def avg_token_reduction(self) -> float:
        if self.observation_count == 0:
            return 0.0
        return self.total_reduction / self.observation_count

    def score(
        self,
        quality_weight: float = 0.6,
        compression_weight: float = 0.4,
        exploration_factor: float = 0.1,
    ) -> float:
        """UCB composite score. Returns inf for untested levels."""
        if self.observation_count == 0:
            return float("inf")
        exploit = (
            quality_weight * self.avg_quality()
            + compression_weight * (self.avg_token_reduction() / 100.0)
        )
        explore = exploration_factor / math.sqrt(1 + self.observation_count)
        return exploit + explore

    def is_healthy(self, threshold: int = 3) -> bool:
        """False if consecutive low-quality outcomes exceed threshold."""
        return self.consecutive_low_quality < threshold

    def to_dict(self) -> Dict[str, Any]:
        return {
            "observation_count": self.observation_count,
            "total_quality": self.total_quality,
            "total_compression": self.total_compression,
            "total_reduction": self.total_reduction,
            "consecutive_low_quality": self.consecutive_low_quality,
            "best_quality": self.best_quality,
            "worst_quality": self.worst_quality,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> StrategyPerformance:
        return cls(
            observation_count=d["observation_count"],
            total_quality=d["total_quality"],
            total_compression=d["total_compression"],
            total_reduction=d["total_reduction"],
            consecutive_low_quality=d["consecutive_low_quality"],
            best_quality=d["best_quality"],
            worst_quality=d["worst_quality"],
        )


# ---------------------------------------------------------------------------
# 3. AdaptivePolicy
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AdaptivePolicy:
    """Immutable snapshot of a recommended level for a (strategy, content_type)."""
    version: int
    strategy: str
    content_type: str
    recommended_level: CompressionLevel
    confidence: float
    avg_quality: float
    avg_token_reduction: float
    trained_on: int
    created_at: float


# ---------------------------------------------------------------------------
# 4. AdaptiveLearner
# ---------------------------------------------------------------------------

_PENDING_TTL = 3600.0  # 1 hour


class AdaptiveLearner:
    """Orchestrates adaptive learning from compression quality feedback.

    Args:
        persist_path: File path for saving/loading state (None = no persistence).
        quality_weight: Weight for quality in UCB score (default 0.6).
        compression_weight: Weight for compression in UCB score (default 0.4).
        min_observations: Minimum observations before building a policy.
        exploration_factor: UCB exploration term coefficient.
        low_quality_threshold: Quality score below which counts as low.
        auto_save_interval: Save state every N feedback records.
    """

    def __init__(
        self,
        persist_path: Optional[str] = None,
        quality_weight: float = 0.6,
        compression_weight: float = 0.4,
        min_observations: int = 10,
        exploration_factor: float = 0.1,
        low_quality_threshold: float = 0.5,
        auto_save_interval: int = 50,
    ) -> None:
        self.persist_path = persist_path
        self.quality_weight = quality_weight
        self.compression_weight = compression_weight
        self.min_observations = min_observations
        self.exploration_factor = exploration_factor
        self.low_quality_threshold = low_quality_threshold
        self.auto_save_interval = auto_save_interval

        self._lock = threading.Lock()
        self._pending: Dict[str, CompressionOutcome] = {}
        self._performance: Dict[Tuple[str, str, CompressionLevel], StrategyPerformance] = {}
        self._policies: Dict[Tuple[str, str], AdaptivePolicy] = {}
        self._feedback_count: int = 0
        self._policy_version: int = 0

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------

    def record_compression(
        self,
        request_id: str,
        strategy: str,
        content_type: str,
        level: CompressionLevel,
        original_tokens: int,
        compressed_tokens: int,
        compression_ratio: float,
        token_reduction_pct: float,
    ) -> None:
        """Store a pending compression outcome awaiting quality feedback."""
        outcome = CompressionOutcome(
            request_id=request_id,
            strategy=strategy,
            content_type=content_type,
            level=level,
            original_tokens=original_tokens,
            compressed_tokens=compressed_tokens,
            compression_ratio=compression_ratio,
            token_reduction_pct=token_reduction_pct,
            timestamp=time.time(),
        )
        with self._lock:
            self._evict_expired_pending()
            self._pending[request_id] = outcome

    def record_feedback(self, request_id: str, quality_score: float) -> bool:
        """Match feedback to a pending outcome and update performance stats.

        Returns True if the request_id was found, False otherwise.
        Raises ValueError if quality_score is outside [0, 1].
        """
        if not (0.0 <= quality_score <= 1.0):
            raise ValueError(f"quality_score must be in [0, 1], got {quality_score}")

        with self._lock:
            pending = self._pending.pop(request_id, None)
            if pending is None:
                return False

            completed = dataclasses.replace(pending, quality_score=quality_score)

            key = (completed.strategy, completed.content_type, completed.level)
            if key not in self._performance:
                self._performance[key] = StrategyPerformance()
            self._performance[key].record(completed)

            self._feedback_count += 1
            should_save = (
                self.persist_path is not None
                and self._feedback_count % self.auto_save_interval == 0
            )

        if should_save:
            self.save()

        return True

    # ------------------------------------------------------------------
    # Recommendation
    # ------------------------------------------------------------------

    def recommend_level(
        self, strategy: str, content_type: str
    ) -> CompressionLevel:
        """Return the UCB-scored best compression level for a (strategy, content_type)."""
        with self._lock:
            best_level = CompressionLevel.balanced
            best_score = -1.0

            for level in CompressionLevel:
                key = (strategy, content_type, level)
                perf = self._performance.get(key)

                if perf is None:
                    # Untested levels get a 3x exploration boost
                    score = float("inf")
                else:
                    if not perf.is_healthy():
                        continue
                    score = perf.score(
                        self.quality_weight,
                        self.compression_weight,
                        self.exploration_factor,
                    )
                    # 3x exploration boost for under-observed levels
                    if perf.observation_count < self.min_observations:
                        score *= 3.0

                if score > best_score:
                    best_score = score
                    best_level = level

            return best_level

    # ------------------------------------------------------------------
    # Policy Building
    # ------------------------------------------------------------------

    def rebuild_policies(self, min_observations: Optional[int] = None) -> int:
        """Rebuild policies from accumulated performance data.

        Returns the number of policies created.
        """
        min_obs = min_observations if min_observations is not None else self.min_observations

        with self._lock:
            self._policy_version += 1
            # Group by (strategy, content_type)
            groups: Dict[Tuple[str, str], List[Tuple[CompressionLevel, StrategyPerformance]]] = {}
            for (strat, ct, level), perf in self._performance.items():
                group_key = (strat, ct)
                if group_key not in groups:
                    groups[group_key] = []
                groups[group_key].append((level, perf))

            new_policies: Dict[Tuple[str, str], AdaptivePolicy] = {}
            for (strat, ct), levels in groups.items():
                total_obs = sum(p.observation_count for _, p in levels)
                if total_obs < min_obs:
                    continue

                # Pick best level using score with exploration=0 (pure exploitation)
                best_level = CompressionLevel.balanced
                best_score = -1.0
                best_perf: Optional[StrategyPerformance] = None
                for level, perf in levels:
                    if perf.observation_count == 0:
                        continue
                    s = perf.score(self.quality_weight, self.compression_weight, 0.0)
                    if s > best_score:
                        best_score = s
                        best_level = level
                        best_perf = perf

                if best_perf is None:
                    continue

                confidence = min(1.0, total_obs / (4 * min_obs))
                new_policies[(strat, ct)] = AdaptivePolicy(
                    version=self._policy_version,
                    strategy=strat,
                    content_type=ct,
                    recommended_level=best_level,
                    confidence=confidence,
                    avg_quality=best_perf.avg_quality(),
                    avg_token_reduction=best_perf.avg_token_reduction(),
                    trained_on=total_obs,
                    created_at=time.time(),
                )

            self._policies = new_policies
            return len(new_policies)

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    def get_performance(self) -> Dict[str, Dict[str, Any]]:
        """Return all performance data keyed by pipe-delimited tuple strings."""
        with self._lock:
            return {
                f"{s}|{ct}|{lvl.value}": perf.to_dict()
                for (s, ct, lvl), perf in self._performance.items()
            }

    def get_policies(self) -> List[Dict[str, Any]]:
        """Return all current policies as dicts."""
        with self._lock:
            result = []
            for (strat, ct), policy in self._policies.items():
                result.append({
                    "version": policy.version,
                    "strategy": policy.strategy,
                    "content_type": policy.content_type,
                    "recommended_level": policy.recommended_level.value,
                    "confidence": policy.confidence,
                    "avg_quality": round(policy.avg_quality, 4),
                    "avg_token_reduction": round(policy.avg_token_reduction, 1),
                    "trained_on": policy.trained_on,
                    "created_at": policy.created_at,
                })
            return result

    def get_stats(self) -> Dict[str, Any]:
        """Return aggregate learning stats."""
        with self._lock:
            total_obs = sum(p.observation_count for p in self._performance.values())
            return {
                "total_feedback": self._feedback_count,
                "total_observations": total_obs,
                "pending_count": len(self._pending),
                "tracked_combinations": len(self._performance),
                "active_policies": len(self._policies),
                "policy_version": self._policy_version,
            }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: Optional[str] = None) -> None:
        """Save learner state to JSON."""
        target = path or self.persist_path
        if target is None:
            raise ValueError("No persist_path configured and no path argument given")

        with self._lock:
            data = {
                "version": 1,
                "feedback_count": self._feedback_count,
                "policy_version": self._policy_version,
                "performance": {
                    f"{s}|{ct}|{lvl.value}": perf.to_dict()
                    for (s, ct, lvl), perf in self._performance.items()
                },
                "policies": {
                    f"{s}|{ct}": {
                        "version": p.version,
                        "strategy": p.strategy,
                        "content_type": p.content_type,
                        "recommended_level": p.recommended_level.value,
                        "confidence": p.confidence,
                        "avg_quality": p.avg_quality,
                        "avg_token_reduction": p.avg_token_reduction,
                        "trained_on": p.trained_on,
                        "created_at": p.created_at,
                    }
                    for (s, ct), p in self._policies.items()
                },
            }

        with open(target, "w") as f:
            json.dump(data, f, indent=2)

    def load(self, path: Optional[str] = None) -> None:
        """Load learner state from JSON."""
        target = path or self.persist_path
        if target is None:
            raise ValueError("No persist_path configured and no path argument given")

        with open(target, "r") as f:
            data = json.load(f)

        with self._lock:
            self._feedback_count = data.get("feedback_count", 0)
            self._policy_version = data.get("policy_version", 0)

            self._performance = {}
            for key_str, perf_dict in data.get("performance", {}).items():
                parts = key_str.split("|")
                if len(parts) != 3:
                    continue
                s, ct, lvl_str = parts
                try:
                    lvl = CompressionLevel(lvl_str)
                except ValueError:
                    continue
                self._performance[(s, ct, lvl)] = StrategyPerformance.from_dict(perf_dict)

            self._policies = {}
            for key_str, pol_dict in data.get("policies", {}).items():
                parts = key_str.split("|")
                if len(parts) != 2:
                    continue
                s, ct = parts
                try:
                    rec_level = CompressionLevel(pol_dict["recommended_level"])
                except (ValueError, KeyError):
                    continue
                self._policies[(s, ct)] = AdaptivePolicy(
                    version=pol_dict.get("version", 0),
                    strategy=pol_dict["strategy"],
                    content_type=pol_dict["content_type"],
                    recommended_level=rec_level,
                    confidence=pol_dict.get("confidence", 0.0),
                    avg_quality=pol_dict.get("avg_quality", 0.0),
                    avg_token_reduction=pol_dict.get("avg_token_reduction", 0.0),
                    trained_on=pol_dict.get("trained_on", 0),
                    created_at=pol_dict.get("created_at", 0.0),
                )

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _evict_expired_pending(self) -> None:
        """Remove pending outcomes older than TTL. Called under lock."""
        if len(self._pending) < 100:
            return
        now = time.time()
        expired = [
            rid for rid, outcome in self._pending.items()
            if now - outcome.timestamp > _PENDING_TTL
        ]
        for rid in expired:
            del self._pending[rid]
