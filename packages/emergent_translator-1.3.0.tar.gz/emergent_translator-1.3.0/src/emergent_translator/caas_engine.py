"""
Compression-as-a-Service: Content Detector and Compression Engine

ContentDetector  — auto-detect content type from content, explicit type, or filename
CompressionEngine — dispatch content to the correct strategy and return results
"""

from __future__ import annotations

import json
import re
import uuid
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .caas_adaptive import AdaptiveLearner

from .caas_strategies import (
    ALL_STRATEGIES,
    STRATEGY_MAP,
    CompressedResult,
    CompressionLevel,
    CompressionStrategy,
)


class ContentDetector:
    """Auto-detect content type from content, explicit type hint, or filename."""

    # Extension → content type mapping
    EXTENSION_MAP: Dict[str, str] = {
        ".py": "code/python",
        ".ts": "code/typescript",
        ".tsx": "code/tsx",
        ".js": "code/javascript",
        ".jsx": "code/javascript",
        ".rs": "code/rust",
        ".json": "data/json",
        ".yaml": "data/yaml",
        ".yml": "data/yaml",
        ".toml": "data/toml",
        ".xml": "data/xml",
        ".csv": "data/csv",
        ".md": "text/markdown",
        ".sql": "schema/sql",
        ".graphql": "schema/graphql",
        ".gql": "schema/graphql",
        ".log": "text/log",
        ".txt": "text/prose",
    }

    # All recognized content types
    SUPPORTED_TYPES = set(EXTENSION_MAP.values()) | {"text/prose"}

    @classmethod
    def detect(
        cls,
        content: str,
        explicit_type: Optional[str] = None,
        filename_hint: Optional[str] = None,
    ) -> str:
        """Detect the content type.

        Priority: explicit_type > filename extension > content sniffing.

        Returns:
            A content type string like "code/python" or "data/json".
        """
        # 1. Explicit type
        if explicit_type:
            if explicit_type in cls.SUPPORTED_TYPES:
                return explicit_type
            # Try to match partially (e.g., "json" -> "data/json")
            for ct in cls.SUPPORTED_TYPES:
                if ct.endswith("/" + explicit_type):
                    return ct
            return explicit_type  # Pass through even if unknown

        # 2. Filename extension
        if filename_hint:
            import os
            _, ext = os.path.splitext(filename_hint.lower())
            if ext in cls.EXTENSION_MAP:
                return cls.EXTENSION_MAP[ext]

        # 3. Content sniffing
        return cls._sniff(content)

    @classmethod
    def _sniff(cls, content: str) -> str:
        """Determine content type by examining content patterns."""
        stripped = content.strip()
        if not stripped:
            return "text/prose"

        first_lines = stripped.split("\n", 5)[:5]
        first_line = first_lines[0].strip() if first_lines else ""

        # 1. JSON
        if stripped.startswith(("{", "[")):
            try:
                json.loads(stripped)
                return "data/json"
            except (json.JSONDecodeError, ValueError):
                pass

        # 2. YAML (--- document separator in first 5 lines)
        for line in first_lines:
            if line.strip() == "---":
                return "data/yaml"

        # 3. XML
        if first_line.startswith("<?xml") or first_line.startswith("<root"):
            return "data/xml"

        # 4. TOML — [section] + key = value
        if cls._looks_like_toml(first_lines):
            return "data/toml"

        # 5. SQL
        upper = stripped.upper()
        if "CREATE TABLE" in upper or "ALTER TABLE" in upper:
            return "schema/sql"

        # 6. GraphQL
        if cls._looks_like_graphql(stripped):
            return "schema/graphql"

        # 7. Log file — timestamps + log levels on >30% of lines
        if cls._looks_like_log(stripped):
            return "text/log"

        # 8. Python
        if cls._looks_like_python(stripped):
            return "code/python"

        # 9. TypeScript / JavaScript
        if cls._looks_like_typescript(stripped):
            return "code/typescript"

        # 10. Rust
        if cls._looks_like_rust(stripped):
            return "code/rust"

        # 11. CSV — comma-separated header (checked after code/schema to avoid false positives)
        if cls._looks_like_csv(first_lines):
            return "data/csv"

        # 12. Markdown
        if first_line.startswith("#") or "**" in stripped[:500]:
            return "text/markdown"

        # 13. Fallback
        return "text/prose"

    @staticmethod
    def _looks_like_csv(lines: List[str]) -> bool:
        """Check if content looks like CSV."""
        if not lines:
            return False
        first = lines[0]
        if "," not in first:
            return False
        # Should not contain code keywords
        code_keywords = {
            "def ", "class ", "function ", "import ", "const ", "var ", "let ",
            "CREATE ", "ALTER ", "pub fn", "fn ", "impl ", "type ", "{", "(",
        }
        for kw in code_keywords:
            if kw in first:
                return False
        # Should have consistent comma counts
        comma_count = first.count(",")
        if comma_count < 1:
            return False
        consistent = 0
        for line in lines[1:]:
            if line.strip() and abs(line.count(",") - comma_count) <= 1:
                consistent += 1
        return consistent >= min(2, len(lines) - 1)

    @staticmethod
    def _looks_like_toml(lines: List[str]) -> bool:
        """Check if content looks like TOML."""
        has_section = False
        has_kv = False
        for line in lines:
            stripped = line.strip()
            if re.match(r"^\[[\w.-]+\]$", stripped):
                has_section = True
            if re.match(r"^\w[\w-]*\s*=", stripped):
                has_kv = True
        return has_section and has_kv

    @staticmethod
    def _looks_like_graphql(content: str) -> bool:
        """Check if content looks like GraphQL."""
        # Has "type <Name> {" or "schema {"
        return bool(
            re.search(r"\btype\s+\w+\s*\{", content)
            or re.search(r"\bschema\s*\{", content)
        )

    @staticmethod
    def _looks_like_log(content: str) -> bool:
        """Check if >30% of lines have timestamps + log levels."""
        lines = content.split("\n")
        if len(lines) < 3:
            return False

        log_pattern = re.compile(
            r"(?:\d{4}-\d{2}-\d{2}|\d{2}:\d{2}:\d{2}|"
            r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2})"
            r".*\b(?:DEBUG|TRACE|INFO|WARN(?:ING)?|ERROR|FATAL|CRITICAL)\b",
            re.IGNORECASE,
        )
        matches = sum(1 for line in lines if log_pattern.search(line))
        return matches / len(lines) > 0.3

    @staticmethod
    def _looks_like_python(content: str) -> bool:
        """Check if content looks like Python."""
        indicators = 0
        if re.search(r"^def\s+\w+\s*\(", content, re.MULTILINE):
            indicators += 1
        if re.search(r"^class\s+\w+", content, re.MULTILINE):
            indicators += 1
        if re.search(r"^import\s+\w+", content, re.MULTILINE):
            indicators += 1
        if re.search(r"^from\s+\w+\s+import", content, re.MULTILINE):
            indicators += 1
        return indicators >= 2

    @staticmethod
    def _looks_like_typescript(content: str) -> bool:
        """Check if content looks like TypeScript/JavaScript."""
        indicators = 0
        if re.search(r"\bfunction\s+\w+", content):
            indicators += 1
        if re.search(r"\bconst\s+\w+\s*=.*=>", content):
            indicators += 1
        if re.search(r"\binterface\s+\w+", content):
            indicators += 1
        if re.search(r"\bexport\s+(?:default\s+)?(?:function|class|const)", content):
            indicators += 1
        return indicators >= 1

    @staticmethod
    def _looks_like_rust(content: str) -> bool:
        """Check if content looks like Rust."""
        indicators = 0
        if re.search(r"\bfn\s+\w+\s*\(.*\)\s*->", content):
            indicators += 1
        if re.search(r"\bimpl\s+\w+", content):
            indicators += 1
        if re.search(r"\bpub\s+fn\b", content):
            indicators += 1
        if re.search(r"\blet\s+mut\b", content):
            indicators += 1
        return indicators >= 1


class CompressionEngine:
    """Dispatch content to the correct compression strategy."""

    def __init__(self, learner: Optional["AdaptiveLearner"] = None) -> None:
        self._strategies: Dict[str, CompressionStrategy] = dict(STRATEGY_MAP)
        self._detector = ContentDetector()
        self._learner = learner

    def compress(
        self,
        content: str,
        content_type: Optional[str] = None,
        filename_hint: Optional[str] = None,
        level: CompressionLevel = CompressionLevel.balanced,
        options: Optional[Dict[str, Any]] = None,
    ) -> CompressedResult:
        """Compress content using the appropriate strategy.

        Args:
            content: The content to compress.
            content_type: Explicit content type (auto-detected if None).
            filename_hint: Filename to help auto-detection.
            level: Compression aggressiveness.
            options: Strategy-specific options.

        Returns:
            CompressedResult with compressed content and metrics.

        Raises:
            ValueError: If content_type is not supported.
        """
        detected_type = self._detector.detect(content, content_type, filename_hint)

        strategy = self._strategies.get(detected_type)
        if strategy is None:
            # Fallback to prose for unknown types
            strategy = self._strategies.get("text/prose")
            if strategy is None:
                raise ValueError(f"No strategy for content type: {detected_type}")

        result = strategy.compress(content, detected_type, level, options)
        # Patch the metadata with detected type info
        result.metadata["detected_type"] = detected_type
        if content_type:
            result.metadata["explicit_type"] = content_type
        if filename_hint:
            result.metadata["filename_hint"] = filename_hint

        if self._learner is not None:
            request_id = str(uuid.uuid4())
            result.request_id = request_id
            self._learner.record_compression(
                request_id=request_id,
                strategy=result.strategy,
                content_type=detected_type,
                level=level,
                original_tokens=result.original_tokens,
                compressed_tokens=result.compressed_tokens,
                compression_ratio=result.compression_ratio,
                token_reduction_pct=result.token_reduction_pct,
            )

        return result

    def recommend_level(self, content_type: str) -> CompressionLevel:
        """Get the learner's recommended compression level for a content_type."""
        if self._learner is None:
            return CompressionLevel.balanced
        strategy = self._strategies.get(content_type)
        if strategy is None:
            return CompressionLevel.balanced
        return self._learner.recommend_level(strategy.name, content_type)

    def register_strategy(
        self, content_type: str, strategy: CompressionStrategy
    ) -> None:
        """Register a custom strategy for a content type."""
        self._strategies[content_type] = strategy

    def supported_formats(self) -> List[Dict[str, Any]]:
        """Return list of supported content types with strategy info."""
        formats: List[Dict[str, Any]] = []
        seen: set = set()
        for ct, strategy in sorted(self._strategies.items()):
            if ct not in seen:
                seen.add(ct)
                formats.append(
                    {
                        "content_type": ct,
                        "strategy": strategy.name,
                        "levels": [lvl.value for lvl in CompressionLevel],
                    }
                )
        return formats
